use serde::{Deserialize, Serialize};

use crate::types::UnixMillis;

#[derive(
    Debug,
    Clone,
    Copy,
    PartialEq,
    Eq,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
#[cbor(index_only)]
#[repr(u8)]
pub enum Phase {
    #[n(0)]
    Planning = 0,
    #[n(1)]
    CapturingSource = 1,
    #[n(2)]
    SourceCaptured = 2,
    #[n(3)]
    PreparingTarget = 3,
    #[n(4)]
    RestoringTarget = 4,
    #[n(5)]
    TargetReady = 5,
    #[n(6)]
    DrainingSource = 6,
    #[n(7)]
    CuttingOver = 7,
    #[n(8)]
    VmResumed = 8,
    #[n(9)]
    Committed = 9,
    #[n(10)]
    CleaningUp = 10,
    #[n(11)]
    Completed = 11,
    #[n(12)]
    Failed = 12,
    #[n(13)]
    Cancelled = 13,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct PhaseParseError {
    pub value: String,
}

impl Phase {
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Planning => "planning",
            Self::CapturingSource => "capturing_source",
            Self::SourceCaptured => "source_captured",
            Self::PreparingTarget => "preparing_target",
            Self::RestoringTarget => "restoring_target",
            Self::TargetReady => "target_ready",
            Self::DrainingSource => "draining_source",
            Self::CuttingOver => "cutting_over",
            Self::VmResumed => "vm_resumed",
            Self::Committed => "committed",
            Self::CleaningUp => "cleaning_up",
            Self::Completed => "completed",
            Self::Failed => "failed",
            Self::Cancelled => "cancelled",
        }
    }
}

impl std::fmt::Display for PhaseParseError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "invalid migration phase '{}'", self.value)
    }
}

impl std::error::Error for PhaseParseError {}

impl TryFrom<&str> for Phase {
    type Error = PhaseParseError;

    fn try_from(value: &str) -> Result<Self, Self::Error> {
        match value {
            "planning" => Ok(Self::Planning),
            "capturing_source" => Ok(Self::CapturingSource),
            "source_captured" => Ok(Self::SourceCaptured),
            "preparing_target" => Ok(Self::PreparingTarget),
            "restoring_target" => Ok(Self::RestoringTarget),
            "target_ready" => Ok(Self::TargetReady),
            "draining_source" => Ok(Self::DrainingSource),
            "cutting_over" => Ok(Self::CuttingOver),
            "vm_resumed" => Ok(Self::VmResumed),
            "committed" => Ok(Self::Committed),
            "cleaning_up" => Ok(Self::CleaningUp),
            "completed" => Ok(Self::Completed),
            "failed" => Ok(Self::Failed),
            "cancelled" => Ok(Self::Cancelled),
            _ => Err(PhaseParseError {
                value: value.to_owned(),
            }),
        }
    }
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(1)]
    #[cbor(with = "rpc_wire::cbor::uuid::option")]
    pub target_node_id: Option<uuid::Uuid>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmResponse {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub migration_id: uuid::Uuid,
    #[n(1)]
    pub phase: Phase,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CancelRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub migration_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Vm {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub migration_id: uuid::Uuid,
    #[n(1)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(2)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub source_node_id: uuid::Uuid,
    #[n(3)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub target_node_id: uuid::Uuid,
    #[n(4)]
    pub phase: Phase,
    #[n(5)]
    pub actual_pause_us: Option<u64>,
    #[n(6)]
    pub bytes_transferred: Option<u64>,
    #[n(7)]
    pub failure_reason: Option<String>,
    #[n(8)]
    pub created_at: UnixMillis,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct MaybeVmResponse {
    #[n(0)]
    pub migration: Option<Vm>,
}

#[cfg(test)]
mod tests {
    use crate::types::vcs::migration::{Phase, PhaseParseError};

    #[test]
    fn phase_roundtrip() {
        let phases = [
            Phase::Planning,
            Phase::CapturingSource,
            Phase::SourceCaptured,
            Phase::PreparingTarget,
            Phase::RestoringTarget,
            Phase::TargetReady,
            Phase::DrainingSource,
            Phase::CuttingOver,
            Phase::VmResumed,
            Phase::Committed,
            Phase::CleaningUp,
            Phase::Completed,
            Phase::Failed,
            Phase::Cancelled,
        ];
        for phase in phases {
            assert_eq!(Phase::try_from(phase.as_str()), Ok(phase));
        }
    }

    #[test]
    fn phase_rejects_unknown_value() {
        let error = Phase::try_from("unknown").expect_err("expected parse failure");
        assert_eq!(error, PhaseParseError {
            value: "unknown".to_owned()
        });
    }
}
