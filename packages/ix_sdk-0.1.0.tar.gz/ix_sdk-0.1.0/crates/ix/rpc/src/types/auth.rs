use serde::{Deserialize, Serialize};

use crate::types::UnixMillis;

/// User representation on the wire.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct User {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub id: uuid::Uuid,
    #[n(1)]
    pub username: String,
    #[n(2)]
    pub display_name: Option<String>,
    #[n(3)]
    pub email: String,
    #[n(4)]
    pub avatar_url: Option<String>,
    #[n(5)]
    pub created_at: UnixMillis,
    #[n(6)]
    pub username_changed_at: Option<UnixMillis>,
    #[n(7)]
    pub is_admin: bool,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct MeResponse {
    #[n(0)]
    pub user: Option<User>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CreateUserRequest {
    #[n(0)]
    pub username: String,
    #[n(1)]
    pub email: Option<String>,
    #[n(2)]
    pub display_name: Option<String>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct UpdateUsernameRequest {
    #[n(0)]
    pub new_username: String,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct UpdateUsernameResponse {
    #[n(0)]
    pub user: User,
    #[n(1)]
    pub was_first_change: bool,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct UpdateDisplayNameRequest {
    #[n(0)]
    pub display_name: Option<String>,
}

// ── SSH keys ─────────────────────────────────────────────────────────

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct SshKey {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub id: uuid::Uuid,
    #[n(1)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub user_id: uuid::Uuid,
    #[n(2)]
    pub key_type: String,
    #[n(3)]
    pub public_key: String,
    #[n(4)]
    pub fingerprint: String,
    #[n(5)]
    pub name: String,
    #[n(6)]
    pub created_at: UnixMillis,
    #[n(7)]
    pub last_used_at: Option<UnixMillis>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct AddSshKeyRequest {
    #[n(0)]
    pub name: String,
    #[n(1)]
    pub public_key: String,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct DeleteSshKeyRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub key_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListSshKeysResponse {
    #[n(0)]
    pub keys: Vec<SshKey>,
}
