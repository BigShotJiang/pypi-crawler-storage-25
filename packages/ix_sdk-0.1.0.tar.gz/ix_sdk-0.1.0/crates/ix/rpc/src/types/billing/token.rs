use serde::{Deserialize, Serialize};

use crate::types::UnixMillis;

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Token {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub id: uuid::Uuid,
    #[n(1)]
    pub name: String,
    #[n(2)]
    pub token_prefix: Option<String>,
    #[n(3)]
    pub credit_limit: Option<i64>,
    #[n(4)]
    pub credits_consumed: i64,
    #[n(5)]
    pub credits_remaining: Option<i64>,
    #[n(6)]
    pub scopes: Vec<Scope>,
    #[n(7)]
    pub rate_limit_per_minute: Option<u32>,
    #[n(8)]
    pub expires_at: Option<UnixMillis>,
    #[n(9)]
    pub last_used_at: Option<UnixMillis>,
    #[n(10)]
    pub revoked_at: Option<UnixMillis>,
    #[n(11)]
    pub created_at: UnixMillis,
    #[n(12)]
    pub child_tokens: Vec<Self>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Scope {
    #[n(0)]
    pub resource: String,
    #[n(1)]
    pub actions: Vec<String>,
    #[n(2)]
    #[cbor(with = "rpc_wire::cbor::uuid::option_vec")]
    pub resource_ids: Option<Vec<uuid::Uuid>>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CreateRequest {
    #[n(0)]
    pub name: String,
    #[n(1)]
    pub scopes: Vec<Scope>,
    #[n(2)]
    pub credit_limit: Option<i64>,
    #[n(3)]
    pub rate_limit_per_minute: Option<u32>,
    #[n(4)]
    pub expires_at: Option<UnixMillis>,
    #[n(5)]
    pub parent_token: Option<String>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CreateResponse {
    #[n(0)]
    pub token: Token,
    /// The raw token value -- only returned at creation time.
    #[n(1)]
    pub token_value: String,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct UpdateRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub token_id: uuid::Uuid,
    #[n(1)]
    pub name: Option<String>,
    #[n(2)]
    pub credit_limit: Option<i64>,
    #[n(3)]
    pub rate_limit_per_minute: Option<u32>,
    #[n(4)]
    pub expires_at: Option<UnixMillis>,
    #[n(5)]
    pub parent_token: Option<String>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct RevokeRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub token_id: uuid::Uuid,
    #[n(1)]
    pub parent_token: Option<String>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListResponse {
    #[n(0)]
    pub tokens: Vec<Token>,
}
