use serde::{Deserialize, Serialize};

#[derive(
    Debug,
    Clone,
    Copy,
    PartialEq,
    Eq,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
#[cbor(index_only)]
#[repr(u8)]
pub enum StartupMode {
    #[n(0)]
    FullBoot = 0,
    #[n(1)]
    GoldenRestore = 1,
    #[n(2)]
    ForkRestore = 2,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct StartupStages {
    #[n(0)]
    pub rootfs_prepare_ms: Option<u64>,
    #[n(1)]
    pub vmfs_start_ms: Option<u64>,
    #[n(2)]
    pub boot_ms: Option<u64>,
    #[n(3)]
    pub golden_template_ms: Option<u64>,
    #[n(4)]
    pub create_tap_ms: Option<u64>,
    #[n(5)]
    pub spawn_vmm_ms: Option<u64>,
    #[n(6)]
    pub vsock_wait_ms: Option<u64>,
    #[n(7)]
    pub guest_ready_ms: Option<u64>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct StartupInfo {
    #[n(0)]
    pub mode: StartupMode,
    #[n(1)]
    pub total_ms: u64,
    #[n(2)]
    pub stages: Option<StartupStages>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct StartupInfoRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct StartupInfoResponse {
    #[n(0)]
    pub startup_info: Option<StartupInfo>,
}
