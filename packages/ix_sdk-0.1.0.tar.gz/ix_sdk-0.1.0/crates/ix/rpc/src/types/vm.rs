mod attach;
mod observability;
mod startup;

pub use attach::*;
pub use observability::*;
use serde::{Deserialize, Serialize};
pub use startup::*;

use crate::types::{UnixMillis, region::Region};

/// VM status on the wire.
#[derive(
    Debug,
    Clone,
    Copy,
    PartialEq,
    Eq,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
#[cbor(index_only)]
#[repr(u8)]
pub enum Status {
    #[n(0)]
    Pending = 0,
    #[n(1)]
    Starting = 1,
    #[n(2)]
    Running = 2,
    #[n(3)]
    Migrating = 3,
    #[n(4)]
    Snapshotting = 4,
    #[n(5)]
    Sleeping = 5,
    #[n(6)]
    Waking = 6,
    #[n(7)]
    Stopping = 7,
    #[n(8)]
    Stopped = 8,
    #[n(9)]
    Failed = 9,
    #[n(10)]
    Deleted = 10,
    #[n(11)]
    Creating = 11,
    #[n(12)]
    GoldenCapture = 12,
}

/// VM representation on the wire.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Vm {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub id: uuid::Uuid,
    #[n(1)]
    pub name: String,
    #[n(2)]
    pub image: String,
    #[n(3)]
    pub status: Status,
    #[n(4)]
    pub ipv6: String,
    #[n(5)]
    pub ipv4: Option<String>,
    #[n(6)]
    pub subdomain: Option<String>,
    #[n(7)]
    pub memory_mib: u32,
    #[n(8)]
    pub cpu_cores: u32,
    #[n(9)]
    pub ephemeral: bool,
    #[n(10)]
    pub snapshot_key: Option<String>,
    #[n(11)]
    #[cbor(with = "rpc_wire::cbor::uuid::option")]
    pub fork_parent_vm_id: Option<uuid::Uuid>,
    #[n(12)]
    pub fork_base_lsn_ns: Option<String>,
    #[n(13)]
    pub attach_token: Option<String>,
    #[n(14)]
    pub started_at: Option<UnixMillis>,
    #[n(15)]
    pub stopped_at: Option<UnixMillis>,
    #[n(16)]
    pub failure_reason: Option<String>,
    #[n(17)]
    pub created_at: UnixMillis,
    #[n(18)]
    pub updated_at: UnixMillis,
    #[n(19)]
    pub region: Option<Region>,
    /// Owner user ID.
    #[n(21)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub owner_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CreateRequest {
    #[n(0)]
    pub image: String,
    #[n(1)]
    pub name: Option<String>,
    #[n(4)]
    pub ipv4: Option<bool>,
    #[n(5)]
    pub wait_until_ready: bool,
    #[n(6)]
    pub region: String,
    #[n(7)]
    pub disable_golden: bool,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CreateResponse {
    #[n(0)]
    pub vm: Vm,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct GetRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct GetByNameRequest {
    #[n(0)]
    pub name: String,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct GetResponse {
    #[n(0)]
    pub vm: Option<Vm>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListRequest {
    #[n(0)]
    pub status: Option<Status>,
    /// When true, list all VMs regardless of owner (admin only).
    #[n(1)]
    #[serde(default)]
    pub all: bool,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListResponse {
    #[n(0)]
    pub vms: Vec<Vm>,
}

/// Single-ID request used by start/stop/restart/delete/snapshot.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct IdRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Response {
    #[n(0)]
    pub vm: Vm,
}
