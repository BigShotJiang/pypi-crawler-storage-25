mod token;

use serde::{Deserialize, Serialize};
pub use token::*;

use super::UnixMillis;

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Status {
    #[n(0)]
    pub balance: i64,
    #[n(1)]
    pub monthly_credits: i64,
    #[n(2)]
    pub total_granted: i64,
    #[n(3)]
    pub total_consumed: i64,
    #[n(4)]
    pub plan: String,
    #[n(5)]
    pub period_end: UnixMillis,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct UsageEventsRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub token_id: uuid::Uuid,
    #[n(1)]
    pub since: Option<UnixMillis>,
    #[n(2)]
    pub until: Option<UnixMillis>,
    #[n(3)]
    pub resource_type: Option<String>,
    #[n(4)]
    pub limit: u32,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct UsageEvent {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub id: uuid::Uuid,
    #[n(1)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub token_id: uuid::Uuid,
    #[n(2)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub credit_pool_id: uuid::Uuid,
    #[n(3)]
    pub resource_type: String,
    #[n(4)]
    pub quantity: i64,
    #[n(5)]
    pub unit: String,
    #[n(6)]
    pub credits_charged: i64,
    #[n(7)]
    #[cbor(with = "rpc_wire::cbor::uuid::option")]
    pub resource_id: Option<uuid::Uuid>,
    #[n(8)]
    pub resource_name: Option<String>,
    #[n(9)]
    pub created_at: UnixMillis,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct UsageEventsResponse {
    #[n(0)]
    pub events: Vec<UsageEvent>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ResourcePrice {
    #[n(0)]
    pub resource_type: String,
    #[n(1)]
    pub unit: String,
    #[n(2)]
    pub credits_per_unit: i64,
    #[n(3)]
    pub effective_at: UnixMillis,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ResourcePricingResponse {
    #[n(0)]
    pub prices: Vec<ResourcePrice>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CreateCheckoutSessionRequest {
    #[n(0)]
    pub plan: String,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CheckoutSession {
    #[n(0)]
    pub url: String,
    #[n(1)]
    pub session_id: String,
}
