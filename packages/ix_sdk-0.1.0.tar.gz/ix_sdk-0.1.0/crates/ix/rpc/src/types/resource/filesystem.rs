use serde::{Deserialize, Serialize};

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmFsReadRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(1)]
    pub path: String,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmFsReadResponse {
    #[n(0)]
    pub path: String,
    #[n(1)]
    pub text: String,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmFsWriteRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(1)]
    pub path: String,
    #[n(2)]
    pub text: String,
    #[n(3)]
    pub mode: Option<u32>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmFsWriteResponse {
    #[n(0)]
    pub bytes_written: u64,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmFsListRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(1)]
    pub path: String,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmFsEntry {
    #[n(0)]
    pub name: String,
    #[n(1)]
    pub size: u64,
    #[n(2)]
    pub mode: u32,
    #[n(3)]
    pub mtime_ns: i64,
    #[n(4)]
    pub is_dir: bool,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmFsListResponse {
    #[n(0)]
    pub entries: Vec<VmFsEntry>,
}
