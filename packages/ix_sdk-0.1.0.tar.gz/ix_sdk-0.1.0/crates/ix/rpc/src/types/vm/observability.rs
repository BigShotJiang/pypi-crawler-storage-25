use serde::{Deserialize, Serialize};

use crate::types::UnixMillis;

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct LogsRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(1)]
    pub limit: u32,
    #[n(2)]
    pub since: Option<UnixMillis>,
    #[n(3)]
    pub stream: Option<String>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct LogEntry {
    #[n(0)]
    pub timestamp: UnixMillis,
    #[n(1)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(2)]
    pub stream: String,
    #[n(3)]
    pub message: String,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct LogsResponse {
    #[n(0)]
    pub entries: Vec<LogEntry>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct MetricsRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Metrics {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(1)]
    pub cpu_percent: f64,
    #[n(2)]
    pub memory_percent: f64,
    #[n(3)]
    pub network_rx_bytes: u64,
    #[n(4)]
    pub network_tx_bytes: u64,
    #[n(5)]
    pub uptime_secs: u64,
    #[n(6)]
    pub collected_at: UnixMillis,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct MetricsResponse {
    #[n(0)]
    pub metrics: Option<Metrics>,
}

/// VM secret metadata (value is not returned in list).
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Secret {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub id: uuid::Uuid,
    #[n(1)]
    pub name: String,
    #[n(2)]
    pub inject_as: SecretInjection,
    #[n(3)]
    pub created_at: UnixMillis,
    #[n(4)]
    pub updated_at: UnixMillis,
}

#[derive(
    Debug,
    Clone,
    Copy,
    PartialEq,
    Eq,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
#[cbor(index_only)]
#[repr(u8)]
pub enum SecretInjection {
    #[n(0)]
    Env = 0,
    #[n(1)]
    File = 1,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListSecretsResponse {
    #[n(0)]
    pub secrets: Vec<Secret>,
}
