pub mod migration;
pub mod snapshot;

use serde::{Deserialize, Serialize};

use crate::types::vm::Vm;

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ForkVmRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub snapshot_id: uuid::Uuid,
    #[n(1)]
    pub name: Option<String>,
    #[n(2)]
    pub wait_until_ready: bool,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ForkVmResponse {
    #[n(0)]
    pub vm: Vm,
    #[n(1)]
    pub fork_base_lsn_ns: String,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct MergeVmRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub target_vm_id: uuid::Uuid,
    #[n(1)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub source_vm_id: uuid::Uuid,
    #[n(2)]
    pub resolution_strategy: Option<String>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct MergeVmResponse {
    #[n(0)]
    pub vm: Vm,
    #[n(1)]
    pub applied_ops: u32,
    #[n(2)]
    pub applied_paths: Vec<String>,
    #[n(3)]
    pub auto_merged_paths: Vec<String>,
    #[n(4)]
    pub auto_resolved_paths: Vec<String>,
    #[n(5)]
    pub conflict_paths: Vec<String>,
    #[n(6)]
    pub ast_merged_paths: Vec<String>,
    #[n(7)]
    pub line_merged_paths: Vec<String>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct PreviewMergeRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub target_vm_id: uuid::Uuid,
    #[n(1)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub source_vm_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct MergePreview {
    #[n(0)]
    pub total_ops: u32,
    #[n(1)]
    pub disjoint_paths: Vec<String>,
    #[n(2)]
    pub conflict_paths: Vec<String>,
    #[n(3)]
    pub ast_mergeable_paths: Vec<String>,
    #[n(4)]
    pub line_mergeable_paths: Vec<String>,
    #[n(5)]
    pub content_conflict_paths: Vec<String>,
    #[n(6)]
    pub skipped_paths: Vec<String>,
    #[n(7)]
    pub data_violation_paths: Vec<String>,
}
