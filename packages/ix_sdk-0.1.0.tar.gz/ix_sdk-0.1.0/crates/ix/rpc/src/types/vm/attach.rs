use serde::{Deserialize, Serialize};

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct InfoRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct InfoResponse {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(1)]
    pub attach_token: Option<String>,
}
