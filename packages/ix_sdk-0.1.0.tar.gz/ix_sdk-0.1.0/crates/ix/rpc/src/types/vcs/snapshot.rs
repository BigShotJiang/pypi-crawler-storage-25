use serde::{Deserialize, Serialize};

#[derive(
    Debug,
    Clone,
    Copy,
    PartialEq,
    Eq,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
#[cbor(index_only)]
#[repr(u8)]
pub enum Status {
    #[n(0)]
    Capturing = 0,
    #[n(1)]
    Ready = 1,
    #[n(2)]
    Failed = 2,
}

#[derive(Debug, Clone, PartialEq, Eq)]
pub struct StatusParseError {
    pub value: String,
}

impl Status {
    #[must_use]
    pub const fn as_str(self) -> &'static str {
        match self {
            Self::Capturing => "capturing",
            Self::Ready => "ready",
            Self::Failed => "failed",
        }
    }
}

impl std::fmt::Display for StatusParseError {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "invalid snapshot status '{}'", self.value)
    }
}

impl std::error::Error for StatusParseError {}

impl TryFrom<&str> for Status {
    type Error = StatusParseError;

    fn try_from(value: &str) -> Result<Self, Self::Error> {
        match value {
            "capturing" => Ok(Self::Capturing),
            "ready" => Ok(Self::Ready),
            "failed" => Ok(Self::Failed),
            _ => Err(StatusParseError {
                value: value.to_owned(),
            }),
        }
    }
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Vm {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub id: uuid::Uuid,
    #[n(1)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(2)]
    #[cbor(with = "rpc_wire::cbor::uuid::option")]
    pub parent_id: Option<uuid::Uuid>,
    #[n(3)]
    pub status: Status,
    #[n(4)]
    pub memory_mib: u32,
    #[n(5)]
    pub manifest_key: Option<String>,
    #[n(6)]
    pub created_at_millis: i64,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListVmResponse {
    #[n(0)]
    pub snapshots: Vec<Vm>,
}

#[cfg(test)]
mod tests {
    use crate::types::vcs::snapshot::{Status, StatusParseError};

    #[test]
    fn status_roundtrip() {
        let statuses = [Status::Capturing, Status::Ready, Status::Failed];
        for status in statuses {
            assert_eq!(Status::try_from(status.as_str()), Ok(status));
        }
    }

    #[test]
    fn status_rejects_unknown_value() {
        let error = Status::try_from("unknown").expect_err("expected parse failure");
        assert_eq!(error, StatusParseError {
            value: "unknown".to_owned()
        });
    }
}
