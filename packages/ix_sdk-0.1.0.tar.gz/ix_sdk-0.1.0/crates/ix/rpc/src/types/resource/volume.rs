use serde::{Deserialize, Serialize};

use crate::types::UnixMillis;

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Volume {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub id: uuid::Uuid,
    #[n(1)]
    pub name: String,
    #[n(2)]
    #[cbor(with = "rpc_wire::cbor::uuid::option")]
    pub vm_id: Option<uuid::Uuid>,
    #[n(3)]
    pub current_manifest_timestamp: Option<String>,
    #[n(4)]
    pub size_bytes: u64,
    #[n(5)]
    pub created_at: UnixMillis,
    #[n(6)]
    pub updated_at: UnixMillis,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CreateRequest {
    #[n(0)]
    pub name: String,
    #[n(1)]
    #[cbor(with = "rpc_wire::cbor::uuid::option")]
    pub vm_id: Option<uuid::Uuid>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct IdRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub volume_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Response {
    #[n(0)]
    pub volume: Volume,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListResponse {
    #[n(0)]
    pub volumes: Vec<Volume>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Snapshot {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub id: uuid::Uuid,
    #[n(1)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub volume_id: uuid::Uuid,
    #[n(2)]
    pub name: String,
    #[n(3)]
    pub manifest_timestamp: String,
    #[n(4)]
    pub created_at: UnixMillis,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListSnapshotsResponse {
    #[n(0)]
    pub snapshots: Vec<Snapshot>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CreateSnapshotRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub volume_id: uuid::Uuid,
    #[n(1)]
    pub description: Option<String>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct RestoreToSnapshotRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub snapshot_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ForkRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub source_volume_id: uuid::Uuid,
    #[n(1)]
    pub name: String,
    #[n(2)]
    #[cbor(with = "rpc_wire::cbor::uuid::option")]
    pub vm_id: Option<uuid::Uuid>,
}
