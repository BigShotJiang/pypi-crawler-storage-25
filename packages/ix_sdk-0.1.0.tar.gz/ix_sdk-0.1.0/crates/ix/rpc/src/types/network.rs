use serde::{Deserialize, Serialize};

// ── Regions ──────────────────────────────────────────────────────────

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Region {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub id: uuid::Uuid,
    #[n(1)]
    pub slug: String,
    #[n(2)]
    pub display_name: String,
    #[n(3)]
    pub status: String,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListRegionsResponse {
    #[n(0)]
    pub regions: Vec<Region>,
}
