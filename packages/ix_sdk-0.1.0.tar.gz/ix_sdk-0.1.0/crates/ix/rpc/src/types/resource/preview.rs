use serde::{Deserialize, Serialize};

use crate::types::UnixMillis;

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Preview {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub id: uuid::Uuid,
    #[n(1)]
    pub image_tag: String,
    #[n(2)]
    pub status: String,
    #[n(3)]
    pub created_at: UnixMillis,
    #[n(4)]
    pub service_count: u32,
    #[n(5)]
    pub healthy_count: u32,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Service {
    #[n(0)]
    pub service_name: String,
    #[n(1)]
    pub status: String,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Detail {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub id: uuid::Uuid,
    #[n(1)]
    pub image_tag: String,
    #[n(2)]
    pub status: String,
    #[n(3)]
    pub created_at: UnixMillis,
    #[n(4)]
    pub services: Vec<Service>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CreateRequest {
    #[n(0)]
    pub image_tag: Option<String>,
    #[n(1)]
    pub fork_volumes: Option<bool>,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct IdRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub preview_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListResponse {
    #[n(0)]
    pub previews: Vec<Preview>,
}
