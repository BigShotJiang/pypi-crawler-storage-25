#![allow(macro_expanded_macro_exports_accessed_by_absolute_paths)]

pub mod error;
pub mod http;
pub mod ops;
pub mod subscribe;
pub mod types;

pub use rpc_macro::define_ops;

// Re-export core traits from rpc-wire so downstream only needs `ix_rpc` + `rpc_wire`.
// NOTE: per repo rules we avoid `pub use` re-exports, but callers should use
// `rpc_wire::Op`, `rpc_wire::Ctx`, etc. directly. The traits below are only
// referenced by generated macro code that expands inside this crate.
