//! HTTP helpers for ix RPC error handling.
//!
//! Maps ix-specific [`error::Error`](crate::error::Error) variants to HTTP
//! status codes and builds typed error response frames.

/// Build an error response frame for an ix RPC error.
pub fn error_frame(method: &str, err: &crate::error::Error) -> Vec<u8> {
    rpc_transport::server::error_frame(method, err)
}

/// Map an HTTP status from an ix RPC error.
pub fn error_status(err: &crate::error::Error) -> ::http::StatusCode {
    match err {
        crate::error::Error::Unauthorized { .. } => ::http::StatusCode::UNAUTHORIZED,
        crate::error::Error::NotFound { .. } => ::http::StatusCode::NOT_FOUND,
        crate::error::Error::PaymentRequired => ::http::StatusCode::PAYMENT_REQUIRED,
        crate::error::Error::InvalidRequest { .. } => ::http::StatusCode::BAD_REQUEST,
        crate::error::Error::Internal { .. } | crate::error::Error::InternalDetailed { .. } => {
            ::http::StatusCode::INTERNAL_SERVER_ERROR
        }
        crate::error::Error::UnsupportedOp { .. } => ::http::StatusCode::NOT_IMPLEMENTED,
        crate::error::Error::RateLimited { .. } => ::http::StatusCode::TOO_MANY_REQUESTS,
        crate::error::Error::Conflict { .. } => ::http::StatusCode::CONFLICT,
        crate::error::Error::Forbidden { .. } => ::http::StatusCode::FORBIDDEN,
        crate::error::Error::CapacityExhausted { .. } => ::http::StatusCode::SERVICE_UNAVAILABLE,
    }
}
