//! Single source of truth for every SDK operation.
//!
//! Request and response types are defined as explicit structs.
//! The [`define_ops!`](crate::define_ops) macro generates:
//! - An [`Op`](rpc_wire::Op) unit struct linking method name to req/resp types
//! - An [`RpcRequest`](rpc_wire::RpcRequest) impl on the request type
//! - A [`Service`] trait method + [`dispatch`] arm

// ═══════════════════════════════════════════════════════════════════════
// AUTH / USER
// ═══════════════════════════════════════════════════════════════════════

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct MeRequest;
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct MeResponse {
    #[n(0)]
    pub user: Option<crate::types::auth::User>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CreateUserRequest {
    #[n(0)]
    pub username: String,
    #[n(1)]
    pub email: Option<String>,
    #[n(2)]
    pub display_name: Option<String>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct UpdateUsernameRequest {
    #[n(0)]
    pub new_username: String,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct UpdateUsernameResponse {
    #[n(0)]
    pub username: String,
    #[n(1)]
    pub changed_at: crate::types::UnixMillis,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct UpdateDisplayNameRequest {
    #[n(0)]
    pub display_name: Option<String>,
}

// ═══════════════════════════════════════════════════════════════════════
// VM LIFECYCLE
// ═══════════════════════════════════════════════════════════════════════

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct GetVmRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub id: uuid::Uuid,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct MaybeVmResponse {
    #[n(0)]
    pub vm: Option<crate::types::vm::Vm>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct GetVmByNameRequest {
    #[n(0)]
    pub name: String,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListVmsRequest {
    #[n(0)]
    pub status: Option<crate::types::vm::Status>,
    #[n(1)]
    pub all: bool,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListVmsResponse {
    #[n(0)]
    pub vms: Vec<crate::types::vm::Vm>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct StartVmRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmResponse {
    #[n(0)]
    pub vm: crate::types::vm::Vm,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct StopVmRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct RestartVmRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct DeleteVmRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct SnapshotVmRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmAttachInfoRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmAttachInfoResponse {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(1)]
    pub attach_token: Option<String>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmLogsRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(1)]
    pub limit: u32,
    #[n(2)]
    pub since: Option<crate::types::UnixMillis>,
    #[n(3)]
    pub stream: Option<String>,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmLogsResponse {
    #[n(0)]
    pub entries: Vec<crate::types::vm::LogEntry>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmMetricsRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmMetricsResponse {
    #[n(0)]
    pub metrics: Option<crate::types::vm::Metrics>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct GetVmStartupInfoRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct GetVmStartupInfoResponse {
    #[n(0)]
    pub startup_info: Option<crate::types::vm::StartupInfo>,
}

// ═══════════════════════════════════════════════════════════════════════
// VM ENV / SECRETS
// ═══════════════════════════════════════════════════════════════════════

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListVmSecretsRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub resource_id: uuid::Uuid,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListVmSecretsResponse {
    #[n(0)]
    pub secrets: Vec<crate::types::vm::Secret>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct SetVmSecretRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub resource_id: uuid::Uuid,
    #[n(1)]
    pub key: String,
    #[n(2)]
    pub value: String,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct DeleteVmSecretRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub resource_id: uuid::Uuid,
    #[n(1)]
    pub key: String,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListVmEnvVarsRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub resource_id: uuid::Uuid,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListVmEnvVarsResponse {
    #[n(0)]
    pub entries: Vec<crate::types::KeyValue>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct SetVmEnvRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub resource_id: uuid::Uuid,
    #[n(1)]
    pub key: String,
    #[n(2)]
    pub value: String,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct DeleteVmEnvRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub resource_id: uuid::Uuid,
    #[n(1)]
    pub key: String,
}

// ═══════════════════════════════════════════════════════════════════════
// VM VCS
// ═══════════════════════════════════════════════════════════════════════

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ForkVmRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub snapshot_id: uuid::Uuid,
    #[n(1)]
    pub name: Option<String>,
    #[n(2)]
    pub wait_until_ready: bool,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ForkVmResponse {
    #[n(0)]
    pub vm: crate::types::vm::Vm,
    #[n(1)]
    pub fork_base_lsn_ns: String,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct MergeVmRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub target_vm_id: uuid::Uuid,
    #[n(1)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub source_vm_id: uuid::Uuid,
    #[n(2)]
    pub resolution_strategy: Option<String>,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct MergeVmResponse {
    #[n(0)]
    pub vm: crate::types::vm::Vm,
    #[n(1)]
    pub applied_ops: u32,
    #[n(2)]
    pub applied_paths: Vec<String>,
    #[n(3)]
    pub auto_merged_paths: Vec<String>,
    #[n(4)]
    pub auto_resolved_paths: Vec<String>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct PreviewMergeRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub target_vm_id: uuid::Uuid,
    #[n(1)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub source_vm_id: uuid::Uuid,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct PreviewMergeResponse {
    #[n(0)]
    pub total_ops: u32,
    #[n(1)]
    pub disjoint_paths: Vec<String>,
    #[n(2)]
    pub conflict_paths: Vec<String>,
    #[n(3)]
    pub ast_mergeable_paths: Vec<String>,
    #[n(4)]
    pub line_mergeable_paths: Vec<String>,
}

// ═══════════════════════════════════════════════════════════════════════
// VM FILESYSTEM
// ═══════════════════════════════════════════════════════════════════════

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmFsReadRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(1)]
    pub path: String,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmFsReadResponse {
    #[n(0)]
    pub path: String,
    #[n(1)]
    pub text: String,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmFsWriteRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(1)]
    pub path: String,
    #[n(2)]
    pub text: String,
    #[n(3)]
    pub mode: Option<u32>,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmFsWriteResponse {
    #[n(0)]
    pub bytes_written: u64,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmFsListRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(1)]
    pub path: String,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmFsListResponse {
    #[n(0)]
    pub entries: Vec<crate::types::fs::VmFsEntry>,
}

// ═══════════════════════════════════════════════════════════════════════
// VM EXEC
// ═══════════════════════════════════════════════════════════════════════

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ExecVmRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(1)]
    pub command: Vec<String>,
    #[n(2)]
    pub working_dir: Option<String>,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ExecVmResponse {
    #[n(0)]
    pub exit_code: i32,
    #[n(1)]
    pub stdout: String,
    #[n(2)]
    pub stderr: String,
}

// ═══════════════════════════════════════════════════════════════════════
// VM SNAPSHOTS
// ═══════════════════════════════════════════════════════════════════════

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListVmSnapshotsRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListVmSnapshotsResponse {
    #[n(0)]
    pub snapshots: Vec<crate::types::snapshot::Vm>,
}

// ═══════════════════════════════════════════════════════════════════════
// VM MIGRATION
// ═══════════════════════════════════════════════════════════════════════

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct MigrateVmRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(1)]
    #[cbor(with = "rpc_wire::cbor::uuid::option")]
    pub target_node_id: Option<uuid::Uuid>,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct MigrateVmResponse {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub migration_id: uuid::Uuid,
    #[n(1)]
    pub phase: crate::types::migration::Phase,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CancelMigrationRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub migration_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct GetVmMigrationRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct GetVmMigrationResponse {
    #[n(0)]
    pub migration: Option<crate::types::migration::Vm>,
}

// ═══════════════════════════════════════════════════════════════════════
// BILLING / TOKENS
// ═══════════════════════════════════════════════════════════════════════

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct BillingStatusRequest;
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct BillingStatusResponse {
    #[n(0)]
    pub balance: i64,
    #[n(1)]
    pub monthly_credits: i64,
    #[n(2)]
    pub total_granted: i64,
    #[n(3)]
    pub total_consumed: i64,
    #[n(4)]
    pub plan: String,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CreateApiTokenResponse {
    #[n(0)]
    pub token: crate::types::billing::Token,
    #[n(1)]
    pub token_value: String,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListApiTokensRequest;
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListApiTokensResponse {
    #[n(0)]
    pub tokens: Vec<crate::types::billing::Token>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct RevokeApiTokenRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub token_id: uuid::Uuid,
    #[n(1)]
    pub parent_token: Option<String>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct UsageEventsResponse {
    #[n(0)]
    pub events: Vec<crate::types::billing::UsageEvent>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CreateCheckoutSessionRequest {
    #[n(0)]
    pub plan: String,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CreateCheckoutSessionResponse {
    #[n(0)]
    pub url: String,
    #[n(1)]
    pub session_id: String,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ResourcePricingRequest;
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ResourcePricingResponse {
    #[n(0)]
    pub resources: Vec<crate::types::billing::ResourcePrice>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CancelSubscriptionRequest;

// ═══════════════════════════════════════════════════════════════════════
// VOLUMES
// ═══════════════════════════════════════════════════════════════════════

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CreateVolumeRequest {
    #[n(0)]
    pub name: String,
    #[n(1)]
    #[cbor(with = "rpc_wire::cbor::uuid::option")]
    pub vm_id: Option<uuid::Uuid>,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VolumeResponse {
    #[n(0)]
    pub volume: crate::types::volume::Volume,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct GetVolumeRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub volume_id: uuid::Uuid,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListVolumesRequest;
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListVolumesResponse {
    #[n(0)]
    pub volumes: Vec<crate::types::volume::Volume>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct DeleteVolumeRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub volume_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListVolumeSnapshotsRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub volume_id: uuid::Uuid,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListVolumeSnapshotsResponse {
    #[n(0)]
    pub snapshots: Vec<crate::types::volume::Snapshot>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CreateVolumeSnapshotRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub volume_id: uuid::Uuid,
    #[n(1)]
    pub description: Option<String>,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct RestoreToSnapshotRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub snapshot_id: uuid::Uuid,
}
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ForkVolumeRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub source_volume_id: uuid::Uuid,
    #[n(1)]
    pub name: String,
    #[n(2)]
    #[cbor(with = "rpc_wire::cbor::uuid::option")]
    pub vm_id: Option<uuid::Uuid>,
}
// ═══════════════════════════════════════════════════════════════════════
// REGIONS
// ═══════════════════════════════════════════════════════════════════════

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListRegionsRequest;
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListRegionsResponse {
    #[n(0)]
    pub regions: Vec<crate::types::region::Region>,
}

// ═══════════════════════════════════════════════════════════════════════
// PREVIEWS
// ═══════════════════════════════════════════════════════════════════════

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct CreatePreviewRequest {
    #[n(0)]
    pub image_tag: Option<String>,
    #[n(1)]
    pub fork_volumes: Option<bool>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct StopPreviewRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub preview_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListPreviewsRequest;
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListPreviewsResponse {
    #[n(0)]
    pub previews: Vec<crate::types::preview::Preview>,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct GetPreviewRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub preview_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct PromotePreviewRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub preview_id: uuid::Uuid,
}

// ═══════════════════════════════════════════════════════════════════════
// SSH KEYS
// ═══════════════════════════════════════════════════════════════════════

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct AddSshKeyRequest {
    #[n(0)]
    pub name: String,
    #[n(1)]
    pub public_key: String,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct DeleteSshKeyRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub key_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListSshKeysRequest;
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListSshKeysResponse {
    #[n(0)]
    pub keys: Vec<crate::types::auth::SshKey>,
}

// ═══════════════════════════════════════════════════════════════════════
// OP TABLE
// ═══════════════════════════════════════════════════════════════════════

crate::define_ops! {
    // ── Auth / User ────────────────────────────────────────────────────
    me(MeRequest) -> MeResponse;
    create_user(CreateUserRequest) -> crate::types::auth::User;
    update_username(UpdateUsernameRequest) -> UpdateUsernameResponse;
    update_display_name(UpdateDisplayNameRequest) -> crate::types::auth::User;

    // ── VM lifecycle ───────────────────────────────────────────────────
    create_vm(crate::types::vm::CreateRequest) -> crate::types::vm::CreateResponse;
    get_vm(GetVmRequest) -> MaybeVmResponse;
    get_vm_by_name(GetVmByNameRequest) -> MaybeVmResponse;
    list_vms(ListVmsRequest) -> ListVmsResponse;
    start_vm(StartVmRequest) -> VmResponse;
    stop_vm(StopVmRequest) -> VmResponse;
    restart_vm(RestartVmRequest) -> VmResponse;
    delete_vm(DeleteVmRequest);
    snapshot_vm(SnapshotVmRequest) -> VmResponse;
    vm_attach_info(VmAttachInfoRequest) -> VmAttachInfoResponse;
    vm_logs(VmLogsRequest) -> VmLogsResponse;
    vm_metrics(VmMetricsRequest) -> VmMetricsResponse;
    get_vm_startup_info(GetVmStartupInfoRequest) -> GetVmStartupInfoResponse;

    // ── VM env / secrets ───────────────────────────────────────────────
    list_vm_secrets(ListVmSecretsRequest) -> ListVmSecretsResponse;
    set_vm_secret(SetVmSecretRequest);
    delete_vm_secret(DeleteVmSecretRequest);
    list_vm_env_vars(ListVmEnvVarsRequest) -> ListVmEnvVarsResponse;
    set_vm_env(SetVmEnvRequest);
    delete_vm_env(DeleteVmEnvRequest);

    // ── VM VCS ─────────────────────────────────────────────────────────
    fork_vm(ForkVmRequest) -> ForkVmResponse;
    merge_vm(MergeVmRequest) -> MergeVmResponse;
    preview_merge(PreviewMergeRequest) -> PreviewMergeResponse;

    // ── VM filesystem ──────────────────────────────────────────────────
    vm_fs_read(VmFsReadRequest) -> VmFsReadResponse;
    vm_fs_write(VmFsWriteRequest) -> VmFsWriteResponse;
    vm_fs_list(VmFsListRequest) -> VmFsListResponse;

    // ── VM exec ────────────────────────────────────────────────────────
    exec_vm(ExecVmRequest) -> ExecVmResponse;

    // ── VM snapshots ───────────────────────────────────────────────────
    list_vm_snapshots(ListVmSnapshotsRequest) -> ListVmSnapshotsResponse;

    // ── VM migration ───────────────────────────────────────────────────
    migrate_vm(MigrateVmRequest) -> MigrateVmResponse;
    cancel_migration(CancelMigrationRequest);
    get_vm_migration(GetVmMigrationRequest) -> GetVmMigrationResponse;

    // ── Billing / tokens ───────────────────────────────────────────────
    billing_status(BillingStatusRequest) -> BillingStatusResponse;
    create_api_token(crate::types::billing::CreateRequest) -> CreateApiTokenResponse;
    list_api_tokens(ListApiTokensRequest) -> ListApiTokensResponse;
    revoke_api_token(RevokeApiTokenRequest);
    update_api_token(crate::types::billing::UpdateRequest);
    usage_events(crate::types::billing::UsageEventsRequest) -> UsageEventsResponse;
    create_checkout_session(CreateCheckoutSessionRequest) -> CreateCheckoutSessionResponse;
    resource_pricing(ResourcePricingRequest) -> ResourcePricingResponse;
    cancel_subscription(CancelSubscriptionRequest);

    // ── Volumes ────────────────────────────────────────────────────────
    create_volume(CreateVolumeRequest) -> VolumeResponse;
    get_volume(GetVolumeRequest) -> VolumeResponse;
    list_volumes(ListVolumesRequest) -> ListVolumesResponse;
    delete_volume(DeleteVolumeRequest);
    list_volume_snapshots(ListVolumeSnapshotsRequest) -> ListVolumeSnapshotsResponse;
    create_volume_snapshot(CreateVolumeSnapshotRequest) -> VolumeResponse;
    restore_to_snapshot(RestoreToSnapshotRequest) -> VolumeResponse;
    fork_volume(ForkVolumeRequest) -> VolumeResponse;

    // ── Regions ────────────────────────────────────────────────────────
    list_regions(ListRegionsRequest) -> ListRegionsResponse;

    // ── Previews ───────────────────────────────────────────────────────
    create_preview(CreatePreviewRequest) -> crate::types::preview::Detail;
    stop_preview(StopPreviewRequest);
    list_previews(ListPreviewsRequest) -> ListPreviewsResponse;
    get_preview(GetPreviewRequest) -> crate::types::preview::Detail;
    promote_preview(PromotePreviewRequest) -> crate::types::preview::Detail;

    // ── SSH keys ───────────────────────────────────────────────────────
    add_ssh_key(AddSshKeyRequest);
    delete_ssh_key(DeleteSshKeyRequest);
    list_ssh_keys(ListSshKeysRequest) -> ListSshKeysResponse;

    // ── Streaming (long-lived QUIC streams) ────────────────────────────
    console(crate::subscribe::ConsoleRequest) -> impl crate::subscribe::Duplex;
    port_forward(crate::subscribe::PortForwardRequest) -> impl crate::subscribe::Duplex;

    // ── Subscriptions (server -> client push) ──────────────────────────
    subscribe_vm_status(crate::subscribe::VmStatusRequest)
        -> impl futures_core::Stream<Item = crate::subscribe::VmStatusEvent> + Send;
    subscribe_billing_alerts(crate::subscribe::BillingAlertsRequest)
        -> impl futures_core::Stream<Item = crate::subscribe::BillingAlertEvent> + Send;
    subscribe_usage_stream(crate::subscribe::UsageStreamRequest)
        -> impl futures_core::Stream<Item = crate::subscribe::UsageStreamEvent> + Send
}

#[cfg(test)]
mod tests {
    #[test]
    fn activity_names() {
        assert_eq!(super::activity_name("delete_vm"), "delete VM");
        assert_eq!(super::activity_name("list_api_tokens"), "list API tokens");
        assert_eq!(super::activity_name("add_ssh_key"), "add SSH key");
    }

    #[test]
    fn op_table_coverage() {
        macro_rules! count_ops {
            ($(($name:ident, $req:ty, $resp:ty)),* $(,)?) => {
                [$( stringify!($name), )*]
            };
        }
        let table_ops = crate::op_table!(count_ops);
        assert!(!table_ops.is_empty());
        assert!(!table_ops.contains(&"console"));
        assert!(!table_ops.contains(&"port_forward"));
    }
}
