pub mod auth;
pub mod billing;
pub mod network;
pub mod resource;
pub mod vcs;
pub mod vm;

/// Backwards-compatible re-exports for moved modules.
///
/// Backwards-compatible re-exports for moved modules.
///
/// Types formerly in standalone modules (`region`,
/// `snapshot`, `migration`, `ssh`, `exec`, `fs`, `volume`, `preview`) are
/// now consolidated into `network`, `resource`, `vcs`, and `auth`. These
/// re-exports keep existing `$crate::types::region::Region` paths working.
pub mod region {
    pub use crate::types::network::{ListRegionsResponse, Region};
}
pub mod snapshot {
    pub use crate::types::vcs::snapshot::{ListVmResponse, Status, StatusParseError, Vm};
}
pub mod migration {
    pub use crate::types::vcs::migration::{
        CancelRequest, MaybeVmResponse, Phase, PhaseParseError, Vm, VmRequest, VmResponse,
    };
}
pub mod ssh {
    pub use crate::types::auth::{
        AddSshKeyRequest, DeleteSshKeyRequest, ListSshKeysResponse, SshKey,
    };
}
pub mod exec {
    pub use crate::types::resource::exec::{OpResult, VmRequest};
}
pub mod fs {
    pub use crate::types::resource::{
        VmFsEntry, VmFsListRequest, VmFsListResponse, VmFsReadRequest, VmFsReadResponse,
        VmFsWriteRequest, VmFsWriteResponse,
    };
}
pub mod volume {
    pub use crate::types::resource::volume::{
        CreateRequest, CreateSnapshotRequest, ForkRequest, IdRequest, ListResponse,
        ListSnapshotsResponse, Response, RestoreToSnapshotRequest, Snapshot, Volume,
    };
}
pub mod preview {
    pub use crate::types::resource::preview::{
        CreateRequest, Detail, IdRequest, ListResponse, Preview, Service,
    };
}

use serde::{Deserialize, Serialize};

/// Connection handshake -- sent as the first frame on a new QUIC connection.
/// Authenticates once per connection, not per-request.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Handshake {
    #[n(0)]
    pub token: String,
    #[n(1)]
    pub client_version: String,
}

/// Server response to handshake.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct HandshakeResponse {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub user_id: uuid::Uuid,
    #[n(1)]
    pub username: String,
}

/// Timestamp as unix milliseconds (i64 covers +-292M years).
pub type UnixMillis = i64;

/// Empty request for operations that take no parameters.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Empty;

/// Boolean-only response for operations that return success/failure.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct BoolResponse {
    #[n(0)]
    pub ok: bool,
}

/// Shared key-value entry (used for env vars, secrets).
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct KeyValue {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub id: uuid::Uuid,
    #[n(1)]
    pub name: String,
    #[n(2)]
    pub value: String,
    #[n(3)]
    pub created_at: UnixMillis,
    #[n(4)]
    pub updated_at: UnixMillis,
}

/// Request to set a key-value pair on a resource.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct SetKeyValueRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub resource_id: uuid::Uuid,
    #[n(1)]
    pub key: String,
    #[n(2)]
    pub value: String,
}

/// Request to delete a key-value pair from a resource.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct DeleteKeyValueRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub resource_id: uuid::Uuid,
    #[n(1)]
    pub key: String,
}

/// Request to list key-value pairs for a resource.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListKeyValuesRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub resource_id: uuid::Uuid,
}

/// Response containing a list of key-value pairs.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ListKeyValuesResponse {
    #[n(0)]
    pub items: Vec<KeyValue>,
}
