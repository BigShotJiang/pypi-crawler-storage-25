use std::marker::PhantomData;

use serde::{Deserialize, Serialize};

use crate::types::{UnixMillis, vm::Status};

/// Marker trait for bidirectional streaming transports.
pub trait Duplex {}

/// Named duplex-stream marker for RPC declarations.
pub struct DuplexStream;

impl Duplex for DuplexStream {}

/// Named event-stream marker for RPC declarations.
pub struct EventStream<T>(PhantomData<fn() -> T>);

/// Subscribe to VM status changes.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmStatusRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
}

/// Pushed when a VM's status changes.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct VmStatusEvent {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(1)]
    pub status: Status,
    #[n(2)]
    pub timestamp: UnixMillis,
}

/// Subscribe to billing alerts for a credit pool.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct BillingAlertsRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub pool_id: uuid::Uuid,
}

#[derive(
    Debug,
    Clone,
    Copy,
    PartialEq,
    Eq,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
#[cbor(index_only)]
#[repr(u8)]
pub enum BillingAlertType {
    #[n(0)]
    LowBalance = 0,
    #[n(1)]
    LimitApproaching = 1,
    #[n(2)]
    LimitReached = 2,
    #[n(3)]
    PoolDepleted = 3,
    #[n(4)]
    HighUsageRate = 4,
}

/// Pushed when a billing alert fires.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct BillingAlertEvent {
    #[n(0)]
    pub alert_type: BillingAlertType,
    #[n(1)]
    #[cbor(with = "rpc_wire::cbor::uuid::option")]
    pub token_id: Option<uuid::Uuid>,
    #[n(2)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub pool_id: uuid::Uuid,
    #[n(3)]
    pub message: String,
    #[n(4)]
    pub threshold: Option<i64>,
    #[n(5)]
    pub current_value: i64,
    #[n(6)]
    pub timestamp: UnixMillis,
}

/// Subscribe to real-time usage for a credit pool.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct UsageStreamRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub pool_id: uuid::Uuid,
}

/// Pushed when usage is recorded.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct UsageStreamEvent {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub pool_id: uuid::Uuid,
    #[n(1)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub token_id: uuid::Uuid,
    #[n(2)]
    pub resource_type: String,
    #[n(3)]
    pub credits_consumed: i64,
    #[n(4)]
    pub timestamp: UnixMillis,
}

/// Console stream — initial request to open a console connection.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct ConsoleRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
}

/// Port-forward stream — initial request to open a TCP tunnel.
#[derive(
    Debug,
    Clone,
    Serialize,
    Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct PortForwardRequest {
    #[n(0)]
    #[cbor(with = "rpc_wire::cbor::uuid")]
    pub vm_id: uuid::Uuid,
    #[n(1)]
    pub port: u16,
}
