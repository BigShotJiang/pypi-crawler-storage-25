#[derive(
    Debug,
    Clone,
    PartialEq,
    Eq,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct DebugInfo {
    #[n(0)]
    pub hops: Vec<Hop>,
    #[n(1)]
    pub trace_id: Option<String>,
}

#[derive(
    Debug,
    Clone,
    PartialEq,
    Eq,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Hop {
    #[n(0)]
    pub service: String,
    #[n(1)]
    pub operation: String,
    #[n(2)]
    pub node: Option<String>,
    #[n(3)]
    pub invocation_id: Option<String>,
    #[n(4)]
    pub kind: String,
    #[n(5)]
    pub message: String,
    #[n(6)]
    pub causes: Vec<Cause>,
}

#[derive(
    Debug,
    Clone,
    PartialEq,
    Eq,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub struct Cause {
    #[n(0)]
    pub kind: String,
    #[n(1)]
    pub message: String,
}

/// Server-side error returned in an error response frame.
#[derive(
    Debug,
    Clone,
    serde::Serialize,
    serde::Deserialize,
    minicbor::Encode,
    minicbor::Decode
)]
#[serde(deny_unknown_fields)]
pub enum Error {
    /// Authentication failed or token invalid/expired/revoked.
    #[n(0)]
    Unauthorized {
        #[n(0)]
        message: String,
    },

    /// Resource not found.
    #[n(1)]
    NotFound {
        #[n(0)]
        resource: String,
        #[n(1)]
        identifier: String,
    },

    /// Insufficient credits.
    #[n(2)]
    PaymentRequired,

    /// Request validation failed.
    #[n(3)]
    InvalidRequest {
        #[n(0)]
        message: String,
    },

    /// Server-side failure.
    #[n(4)]
    Internal {
        #[n(0)]
        message: String,
    },

    /// Server-side failure with internal-only structured debug context.
    #[n(10)]
    InternalDetailed {
        #[n(0)]
        message: String,
        #[n(1)]
        debug: DebugInfo,
    },

    /// Operation not supported by this server version.
    #[n(5)]
    UnsupportedOp {
        #[n(0)]
        method: String,
    },

    /// Rate limited.
    #[n(6)]
    RateLimited {
        #[n(0)]
        retry_after_ms: u64,
    },

    /// Conflict (e.g. duplicate name).
    #[n(7)]
    Conflict {
        #[n(0)]
        message: String,
    },

    /// Permission denied (authenticated but not authorized).
    #[n(8)]
    Forbidden {
        #[n(0)]
        message: String,
    },

    /// Platform at capacity — no resources available.
    #[n(9)]
    CapacityExhausted {
        #[n(0)]
        message: String,
    },
}

impl core::fmt::Display for Error {
    fn fmt(&self, f: &mut core::fmt::Formatter<'_>) -> core::fmt::Result {
        match self {
            Self::Unauthorized { message } => write!(f, "unauthorized: {message}"),
            Self::NotFound {
                resource,
                identifier,
            } => write!(f, "{resource} '{identifier}' not found"),
            Self::PaymentRequired => write!(f, "payment required"),
            Self::InvalidRequest { message } => write!(f, "invalid request: {message}"),
            Self::Internal { message } => write!(f, "internal error: {message}"),
            Self::InternalDetailed { message, .. } => write!(f, "internal error: {message}"),
            Self::UnsupportedOp { method } => write!(f, "unsupported operation: {method}"),
            Self::RateLimited { retry_after_ms } => {
                write!(f, "rate limited (retry after {retry_after_ms}ms)")
            }
            Self::Conflict { message } => write!(f, "conflict: {message}"),
            Self::Forbidden { message } => write!(f, "forbidden: {message}"),
            Self::CapacityExhausted { message } => write!(f, "capacity exhausted: {message}"),
        }
    }
}

impl std::error::Error for Error {}

impl Error {
    #[must_use]
    pub fn debug(&self) -> Option<&DebugInfo> {
        match self {
            Self::InternalDetailed { debug, .. } => Some(debug),
            _ => None,
        }
    }

    #[must_use]
    pub fn with_trace_id(self) -> Self {
        match self {
            Self::InternalDetailed { message, mut debug } => {
                debug.trace_id = ix_tracing::current_id();
                Self::InternalDetailed { message, debug }
            }
            Self::Internal { message } => Self::InternalDetailed {
                message,
                debug: DebugInfo {
                    hops: Vec::new(),
                    trace_id: ix_tracing::current_id(),
                },
            },
            other => other,
        }
    }

    #[must_use]
    pub fn with_public_message(self, message: impl Into<String>) -> Self {
        let message = message.into();
        match self {
            Self::Internal { .. } => Self::Internal { message },
            Self::InternalDetailed { debug, .. } => Self::InternalDetailed { message, debug },
            other => other,
        }
    }

    #[must_use]
    pub fn redact(self) -> Self {
        match self {
            Self::InternalDetailed { message, .. } => Self::Internal { message },
            other => other,
        }
    }

    #[must_use]
    pub fn prepend_hop(self, hop: Hop) -> Self {
        match self {
            Self::InternalDetailed { message, mut debug } => {
                debug.hops.insert(0, hop);
                Self::InternalDetailed { message, debug }
            }
            Self::Internal { message } => Self::InternalDetailed {
                message,
                debug: DebugInfo {
                    hops: vec![hop],
                    trace_id: None,
                },
            },
            other => other,
        }
    }

    #[must_use]
    pub fn internal_with_local_error(
        service: &str,
        operation: &str,
        kind: &str,
        message: impl Into<String>,
        error: &(dyn std::error::Error + 'static),
    ) -> Self {
        Self::InternalDetailed {
            message: message.into(),
            debug: DebugInfo {
                hops: vec![Hop::from_error(
                    service,
                    operation,
                    kind,
                    error.to_string(),
                    error,
                )],
                trace_id: None,
            },
        }
    }

    #[must_use]
    pub fn prepend_local_error(
        self,
        service: &str,
        operation: &str,
        kind: &str,
        message: impl Into<String>,
        error: &(dyn std::error::Error + 'static),
    ) -> Self {
        self.with_public_message(message)
            .prepend_hop(Hop::from_error(
                service,
                operation,
                kind,
                error.to_string(),
                error,
            ))
    }
}

impl Hop {
    #[must_use]
    pub fn from_error(
        service: &str,
        operation: &str,
        kind: &str,
        message: impl Into<String>,
        error: &(dyn std::error::Error + 'static),
    ) -> Self {
        Self {
            service: service.to_owned(),
            operation: operation.to_owned(),
            node: env_value("HOSTNAME"),
            invocation_id: env_value("INVOCATION_ID"),
            kind: kind.to_owned(),
            message: message.into(),
            causes: extract_causes(error),
        }
    }
}

fn env_value(name: &str) -> Option<String> {
    std::env::var(name).ok().filter(|value| !value.is_empty())
}

fn extract_causes(error: &(dyn std::error::Error + 'static)) -> Vec<Cause> {
    let mut causes = Vec::new();
    let mut current = Some(error);

    while let Some(err) = current {
        causes.push(Cause {
            kind: std::any::type_name_of_val(err).to_owned(),
            message: err.to_string(),
        });
        current = err.source();
    }

    causes
}

#[cfg(test)]
mod tests {
    #[derive(Debug)]
    struct LeafError;

    impl std::fmt::Display for LeafError {
        fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            write!(f, "leaf")
        }
    }

    impl std::error::Error for LeafError {}

    #[derive(Debug)]
    struct WrapperError {
        source: LeafError,
    }

    impl std::fmt::Display for WrapperError {
        fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            write!(f, "wrapper")
        }
    }

    impl std::error::Error for WrapperError {
        fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
            Some(&self.source)
        }
    }

    #[test]
    fn internal_detailed_redacts_to_public_message() {
        let error = super::Error::InternalDetailed {
            message: "public".to_owned(),
            debug: super::DebugInfo {
                hops: Vec::new(),
                trace_id: None,
            },
        };

        assert_eq!(error.redact().to_string(), "internal error: public");
    }

    #[test]
    fn prepend_local_error_preserves_existing_hops() {
        let downstream = super::Error::InternalDetailed {
            message: "inner".to_owned(),
            debug: super::DebugInfo {
                hops: vec![super::Hop {
                    service: "image-ingester".to_owned(),
                    operation: "convert".to_owned(),
                    node: None,
                    invocation_id: None,
                    kind: "convert".to_owned(),
                    message: "failed".to_owned(),
                    causes: Vec::new(),
                }],
                trace_id: None,
            },
        };

        let wrapped = downstream.prepend_local_error(
            "orchestrator",
            "create_vm",
            "rpc",
            "outer",
            &WrapperError { source: LeafError },
        );

        let super::Error::InternalDetailed { message, debug } = wrapped else {
            panic!("expected detailed internal error");
        };
        assert_eq!(message, "outer");
        assert_eq!(debug.hops[0].service, "orchestrator");
        assert_eq!(debug.hops[1].service, "image-ingester");
        assert_eq!(debug.hops[0].causes.len(), 2);
    }
}
