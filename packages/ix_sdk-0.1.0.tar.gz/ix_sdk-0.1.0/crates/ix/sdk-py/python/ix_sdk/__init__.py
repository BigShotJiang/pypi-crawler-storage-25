from __future__ import annotations

import dataclasses
import enum
import json
import typing

from ._ix_sdk import Branch as _RawBranch
from ._ix_sdk import Client as _RawClient
from ._ix_sdk import FsHandle as _RawFsHandle
from ._ix_sdk import SecretsHandle as _RawSecretsHandle
from ._ix_sdk import __version__


class BranchStatus(str, enum.Enum):
    PENDING = "pending"
    STARTING = "starting"
    RUNNING = "running"
    MIGRATING = "migrating"
    SNAPSHOTTING = "snapshotting"
    SLEEPING = "sleeping"
    WAKING = "waking"
    STOPPING = "stopping"
    STOPPED = "stopped"
    FAILED = "failed"
    DELETED = "deleted"
    CREATING = "creating"
    GOLDEN_CAPTURE = "golden_capture"


class Region(str, enum.Enum):
    US_WEST = "us-west"
    US_EAST = "us-east"


@dataclasses.dataclass(frozen=True, slots=True)
class ClientOptions:
    token: str | None = None
    base_url: str | None = None


@dataclasses.dataclass(frozen=True, slots=True)
class CreateOptions:
    image: str
    region: Region | str
    name: str | None = None
    ipv4: bool | None = None
    wait_until_ready: bool = True
    disable_golden: bool = False


@dataclasses.dataclass(frozen=True, slots=True)
class ExecOptions:
    command: list[str]
    working_dir: str | None = None


@dataclasses.dataclass(frozen=True, slots=True)
class FsWriteOptions:
    path: str
    text: str
    mode: int | None = None


@dataclasses.dataclass(frozen=True, slots=True)
class FsReadOptions:
    path: str


@dataclasses.dataclass(frozen=True, slots=True)
class FsListOptions:
    path: str


@dataclasses.dataclass(frozen=True, slots=True)
class LogsOptions:
    limit: int
    since: int | None = None
    stream: str | None = None


@dataclasses.dataclass(frozen=True, slots=True)
class SetSecretOptions:
    key: str
    value: str


@dataclasses.dataclass(frozen=True, slots=True)
class DeleteSecretOptions:
    key: str


@dataclasses.dataclass(frozen=True, slots=True)
class RegionInfo:
    id: str
    slug: str
    display_name: str
    status: str


@dataclasses.dataclass(frozen=True, slots=True)
class BranchInfo:
    id: str
    name: str
    image: str
    status: BranchStatus
    ipv6: str
    ipv4: str | None
    subdomain: str | None
    memory_mib: int
    cpu_cores: int
    ephemeral: bool
    snapshot_key: str | None
    fork_parent_vm_id: str | None
    fork_base_lsn_ns: str | None
    attach_token: str | None
    started_at: int | None
    stopped_at: int | None
    failure_reason: str | None
    created_at: int
    updated_at: int
    region: RegionInfo | None
    owner_id: str


@dataclasses.dataclass(frozen=True, slots=True)
class ExecResult:
    exit_code: int
    stdout: str
    stderr: str


@dataclasses.dataclass(frozen=True, slots=True)
class FsReadResult:
    path: str
    text: str


@dataclasses.dataclass(frozen=True, slots=True)
class FsWriteResult:
    bytes_written: int


@dataclasses.dataclass(frozen=True, slots=True)
class FsEntry:
    name: str
    size: int
    mode: int
    mtime_ns: int
    is_dir: bool


@dataclasses.dataclass(frozen=True, slots=True)
class LogEntry:
    timestamp: int
    vm_id: str
    stream: str
    message: str


@dataclasses.dataclass(frozen=True, slots=True)
class Commit:
    id: str
    branch_id: str
    parent_id: str | None
    status: str
    memory_mib: int
    manifest_key: str | None
    created_at_millis: int


@dataclasses.dataclass(frozen=True, slots=True)
class Secret:
    id: str
    name: str
    created_at: int
    updated_at: int


def _loads(payload: str) -> typing.Any:
    return json.loads(payload)


def _region_slug(region: Region | str) -> str:
    if isinstance(region, Region):
        if region is Region.US_WEST:
            return "hil-1"
        if region is Region.US_EAST:
            return "vin-1"
    return str(region)


def _decode_region_info(payload: dict[str, typing.Any]) -> RegionInfo:
    return RegionInfo(
        id=payload["id"],
        slug=payload["slug"],
        display_name=payload["display_name"],
        status=payload["status"],
    )


def _decode_branch_info(payload: dict[str, typing.Any]) -> BranchInfo:
    region = payload["region"]
    return BranchInfo(
        id=payload["id"],
        name=payload["name"],
        image=payload["image"],
        status=BranchStatus(payload["status"]),
        ipv6=payload["ipv6"],
        ipv4=payload["ipv4"],
        subdomain=payload["subdomain"],
        memory_mib=payload["memory_mib"],
        cpu_cores=payload["cpu_cores"],
        ephemeral=payload["ephemeral"],
        snapshot_key=payload["snapshot_key"],
        fork_parent_vm_id=payload["fork_parent_vm_id"],
        fork_base_lsn_ns=payload["fork_base_lsn_ns"],
        attach_token=payload["attach_token"],
        started_at=payload["started_at"],
        stopped_at=payload["stopped_at"],
        failure_reason=payload["failure_reason"],
        created_at=payload["created_at"],
        updated_at=payload["updated_at"],
        region=None if region is None else _decode_region_info(region),
        owner_id=payload["owner_id"],
    )


def _decode_exec_result(payload: dict[str, typing.Any]) -> ExecResult:
    return ExecResult(
        exit_code=payload["exit_code"],
        stdout=payload["stdout"],
        stderr=payload["stderr"],
    )


def _decode_fs_read_result(payload: dict[str, typing.Any]) -> FsReadResult:
    return FsReadResult(path=payload["path"], text=payload["text"])


def _decode_fs_write_result(payload: dict[str, typing.Any]) -> FsWriteResult:
    return FsWriteResult(bytes_written=payload["bytes_written"])


def _decode_fs_entry(payload: dict[str, typing.Any]) -> FsEntry:
    return FsEntry(
        name=payload["name"],
        size=payload["size"],
        mode=payload["mode"],
        mtime_ns=payload["mtime_ns"],
        is_dir=payload["is_dir"],
    )


def _decode_log_entry(payload: dict[str, typing.Any]) -> LogEntry:
    return LogEntry(
        timestamp=payload["timestamp"],
        vm_id=payload["vm_id"],
        stream=payload["stream"],
        message=payload["message"],
    )


def _decode_commit(payload: dict[str, typing.Any]) -> Commit:
    return Commit(
        id=payload["id"],
        branch_id=payload["branch_id"],
        parent_id=payload["parent_id"],
        status=payload["status"],
        memory_mib=payload["memory_mib"],
        manifest_key=payload["manifest_key"],
        created_at_millis=payload["created_at_millis"],
    )


def _decode_secret(payload: dict[str, typing.Any]) -> Secret:
    return Secret(
        id=payload["id"],
        name=payload["name"],
        created_at=payload["created_at"],
        updated_at=payload["updated_at"],
    )


class FsHandle:
    def __init__(self, inner: _RawFsHandle) -> None:
        self._inner = inner

    def read(self, options: FsReadOptions) -> FsReadResult:
        return _decode_fs_read_result(_loads(self._inner.read_json(options.path)))

    def write(self, options: FsWriteOptions) -> FsWriteResult:
        return _decode_fs_write_result(
            _loads(self._inner.write_json(options.path, options.text, options.mode))
        )

    def list(self, options: FsListOptions) -> list[FsEntry]:
        return [_decode_fs_entry(item) for item in _loads(self._inner.list_json(options.path))]


class SecretsHandle:
    def __init__(self, inner: _RawSecretsHandle) -> None:
        self._inner = inner

    def set(self, options: SetSecretOptions) -> None:
        self._inner.set(options.key, options.value)

    def delete(self, options: DeleteSecretOptions) -> None:
        self._inner.delete(options.key)

    def list(self) -> list[Secret]:
        return [_decode_secret(item) for item in _loads(self._inner.list_json())]


class Branch:
    def __init__(self, inner: _RawBranch) -> None:
        self._inner = inner

    @property
    def id(self) -> str:
        return self._inner.id

    def get(self) -> BranchInfo:
        return _decode_branch_info(_loads(self._inner.get_json()))

    def delete(self) -> None:
        self._inner.delete()

    def pause(self) -> Commit:
        return _decode_commit(_loads(self._inner.pause_json()))

    def commit(self) -> Commit:
        return _decode_commit(_loads(self._inner.commit_json()))

    def exec(self, options: ExecOptions) -> ExecResult:
        return _decode_exec_result(
            _loads(self._inner.exec_json(options.command, options.working_dir))
        )

    def log(self) -> list[Commit]:
        return [_decode_commit(item) for item in _loads(self._inner.log_json())]

    def fs(self) -> FsHandle:
        return FsHandle(self._inner.fs())

    def secrets(self) -> SecretsHandle:
        return SecretsHandle(self._inner.secrets())

    def logs(self, options: LogsOptions) -> list[LogEntry]:
        return [
            _decode_log_entry(item)
            for item in _loads(
                self._inner.logs_json(options.limit, options.since, options.stream)
            )
        ]

    def __repr__(self) -> str:
        return f"Branch(id={self.id!r})"


class IxSdkClient:
    def __init__(self, options: ClientOptions | None = None) -> None:
        resolved = options or ClientOptions()
        self._inner = _RawClient(resolved.token, resolved.base_url)

    @property
    def base_url(self) -> str:
        return self._inner.base_url()

    def get(self, branch_id: str) -> Branch:
        return Branch(self._inner.get(branch_id))

    def create(self, options: CreateOptions) -> Branch:
        return Branch(
            self._inner.create(
                options.image,
                _region_slug(options.region),
                options.name,
                options.ipv4,
                options.wait_until_ready,
                options.disable_golden,
            )
        )

    def branches(self) -> list[BranchInfo]:
        return [_decode_branch_info(item) for item in _loads(self._inner.branches_json())]

    def regions(self) -> list[RegionInfo]:
        return [_decode_region_info(item) for item in _loads(self._inner.regions_json())]

    def __repr__(self) -> str:
        return f"IxSdkClient(base_url={self.base_url!r})"


__all__ = [
    "Branch",
    "BranchInfo",
    "BranchStatus",
    "ClientOptions",
    "Commit",
    "CreateOptions",
    "DeleteSecretOptions",
    "ExecOptions",
    "ExecResult",
    "FsEntry",
    "FsHandle",
    "FsListOptions",
    "FsReadOptions",
    "FsReadResult",
    "FsWriteOptions",
    "FsWriteResult",
    "IxSdkClient",
    "LogEntry",
    "LogsOptions",
    "Region",
    "RegionInfo",
    "Secret",
    "SecretsHandle",
    "SetSecretOptions",
    "__version__",
]
