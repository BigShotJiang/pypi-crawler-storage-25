mod error;
mod json;

use pyo3::types::PyModuleMethods as _;

#[pyo3::pyclass(name = "Client")]
pub struct PythonClient {
    runtime: std::sync::Arc<tokio::runtime::Runtime>,
    client: std::sync::Arc<ix_sdk::IxClient>,
}

#[pyo3::pyclass(name = "Branch")]
pub struct PythonBranch {
    runtime: std::sync::Arc<tokio::runtime::Runtime>,
    client: std::sync::Arc<ix_sdk::IxClient>,
    id: uuid::Uuid,
}

#[pyo3::pyclass(name = "FsHandle")]
pub struct PythonFsHandle {
    runtime: std::sync::Arc<tokio::runtime::Runtime>,
    client: std::sync::Arc<ix_sdk::IxClient>,
    id: uuid::Uuid,
}

#[pyo3::pyclass(name = "SecretsHandle")]
pub struct PythonSecretsHandle {
    runtime: std::sync::Arc<tokio::runtime::Runtime>,
    client: std::sync::Arc<ix_sdk::IxClient>,
    id: uuid::Uuid,
}

fn runtime() -> pyo3::PyResult<std::sync::Arc<tokio::runtime::Runtime>> {
    tokio::runtime::Builder::new_multi_thread()
        .enable_all()
        .build()
        .map(std::sync::Arc::new)
        .map_err(error::runtime)
}

fn parse_uuid(id: String) -> pyo3::PyResult<uuid::Uuid> {
    id.parse()
        .map_err(|source| error::invalid_uuid(&id, source))
}

fn branch(
    runtime: std::sync::Arc<tokio::runtime::Runtime>,
    client: std::sync::Arc<ix_sdk::IxClient>,
    id: uuid::Uuid,
) -> PythonBranch {
    PythonBranch {
        runtime,
        client,
        id,
    }
}

fn block_on_sdk<T, F>(
    py: pyo3::Python<'_>,
    runtime: std::sync::Arc<tokio::runtime::Runtime>,
    future: F,
) -> pyo3::PyResult<T>
where
    T: Send + 'static,
    F: std::future::Future<Output = Result<T, ix_sdk::SdkError>> + Send + 'static,
{
    py.allow_threads(move || runtime.block_on(future).map_err(error::sdk))
}

#[pyo3::pymethods]
impl PythonClient {
    #[new]
    #[pyo3(signature = (token=None, base_url=None))]
    pub fn new(token: Option<String>, base_url: Option<String>) -> pyo3::PyResult<Self> {
        let resolved = ix_config::resolve(token.as_deref(), base_url.as_deref());
        let token = resolved.token.ok_or_else(error::missing_token)?;
        let runtime = runtime()?;
        let client = ix_sdk::IxClient::new(resolved.server, token).map_err(error::sdk)?;
        Ok(Self {
            runtime,
            client: std::sync::Arc::new(client),
        })
    }

    pub fn base_url(&self) -> String {
        self.client.server().to_owned()
    }

    pub fn get(&self, id: String) -> pyo3::PyResult<PythonBranch> {
        Ok(branch(
            std::sync::Arc::clone(&self.runtime),
            std::sync::Arc::clone(&self.client),
            parse_uuid(id)?,
        ))
    }

    #[pyo3(signature = (image, region, name=None, ipv4=None, wait_until_ready=true, disable_golden=false))]
    pub fn create(
        &self,
        py: pyo3::Python<'_>,
        image: String,
        region: String,
        name: Option<String>,
        ipv4: Option<bool>,
        wait_until_ready: bool,
        disable_golden: bool,
    ) -> pyo3::PyResult<PythonBranch> {
        let runtime = std::sync::Arc::clone(&self.runtime);
        let client = std::sync::Arc::clone(&self.client);
        let branch_runtime = std::sync::Arc::clone(&self.runtime);
        let branch_client = std::sync::Arc::clone(&self.client);
        block_on_sdk(py, runtime, async move {
            client
                .create_vm(ix_sdk::ix_rpc_types::types::vm::CreateRequest {
                    image,
                    name,
                    ipv4,
                    wait_until_ready,
                    region,
                    disable_golden,
                })
                .await
                .map(|response| branch(branch_runtime, branch_client, response.vm.id))
        })
    }

    pub fn branches_json(&self, py: pyo3::Python<'_>) -> pyo3::PyResult<String> {
        let runtime = std::sync::Arc::clone(&self.runtime);
        let client = std::sync::Arc::clone(&self.client);
        block_on_sdk(py, runtime, async move {
            client.list_vms(None).await.map(|response| response.vms)
        })
        .and_then(|vms| json::branches(&vms).map_err(error::json))
    }

    pub fn regions_json(&self, py: pyo3::Python<'_>) -> pyo3::PyResult<String> {
        let runtime = std::sync::Arc::clone(&self.runtime);
        let client = std::sync::Arc::clone(&self.client);
        block_on_sdk(py, runtime, async move {
            client.list_regions().await.map(|response| response.regions)
        })
        .and_then(|regions| json::regions(&regions).map_err(error::json))
    }
}

#[pyo3::pymethods]
impl PythonBranch {
    #[getter]
    pub fn id(&self) -> String {
        self.id.to_string()
    }

    pub fn get_json(&self, py: pyo3::Python<'_>) -> pyo3::PyResult<String> {
        let runtime = std::sync::Arc::clone(&self.runtime);
        let client = std::sync::Arc::clone(&self.client);
        let id = self.id;
        block_on_sdk(py, runtime, async move {
            let response = client.get_vm(id).await?;
            response.vm.ok_or_else(|| ix_sdk::SdkError::VmNotFound {
                identifier: id.to_string(),
            })
        })
        .and_then(|vm| json::branch(&vm).map_err(error::json))
    }

    pub fn delete(&self, py: pyo3::Python<'_>) -> pyo3::PyResult<()> {
        let runtime = std::sync::Arc::clone(&self.runtime);
        let client = std::sync::Arc::clone(&self.client);
        let id = self.id;
        block_on_sdk(py, runtime, async move {
            client.delete_vm(id).await.map(|_| ())
        })
    }

    pub fn pause_json(&self, py: pyo3::Python<'_>) -> pyo3::PyResult<String> {
        let runtime = std::sync::Arc::clone(&self.runtime);
        let client = std::sync::Arc::clone(&self.client);
        let id = self.id;
        block_on_sdk(py, runtime, async move { client.stop_vm(id).await })
            .and_then(|response| json::commit_from_vm(&response.vm).map_err(error::json))
    }

    pub fn commit_json(&self, py: pyo3::Python<'_>) -> pyo3::PyResult<String> {
        let runtime = std::sync::Arc::clone(&self.runtime);
        let client = std::sync::Arc::clone(&self.client);
        let id = self.id;
        block_on_sdk(py, runtime, async move { client.snapshot_vm(id).await })
            .and_then(|response| json::commit_from_vm(&response.vm).map_err(error::json))
    }

    #[pyo3(signature = (command, working_dir=None))]
    pub fn exec_json(
        &self,
        py: pyo3::Python<'_>,
        command: Vec<String>,
        working_dir: Option<String>,
    ) -> pyo3::PyResult<String> {
        let runtime = std::sync::Arc::clone(&self.runtime);
        let client = std::sync::Arc::clone(&self.client);
        let id = self.id;
        block_on_sdk(py, runtime, async move {
            client
                .exec_vm(ix_sdk::ix_rpc_types::types::resource::exec::VmRequest {
                    vm_id: id,
                    command,
                    working_dir,
                })
                .await
        })
        .and_then(|result| json::exec(&result).map_err(error::json))
    }

    pub fn log_json(&self, py: pyo3::Python<'_>) -> pyo3::PyResult<String> {
        let runtime = std::sync::Arc::clone(&self.runtime);
        let client = std::sync::Arc::clone(&self.client);
        let id = self.id;
        block_on_sdk(py, runtime, async move {
            client
                .list_vm_snapshots(id)
                .await
                .map(|response| response.snapshots)
        })
        .and_then(|snapshots| json::commits(&snapshots).map_err(error::json))
    }

    pub fn fs(&self) -> PythonFsHandle {
        PythonFsHandle {
            runtime: std::sync::Arc::clone(&self.runtime),
            client: std::sync::Arc::clone(&self.client),
            id: self.id,
        }
    }

    pub fn secrets(&self) -> PythonSecretsHandle {
        PythonSecretsHandle {
            runtime: std::sync::Arc::clone(&self.runtime),
            client: std::sync::Arc::clone(&self.client),
            id: self.id,
        }
    }

    #[pyo3(signature = (limit, since=None, stream=None))]
    pub fn logs_json(
        &self,
        py: pyo3::Python<'_>,
        limit: u32,
        since: Option<i64>,
        stream: Option<String>,
    ) -> pyo3::PyResult<String> {
        let runtime = std::sync::Arc::clone(&self.runtime);
        let client = std::sync::Arc::clone(&self.client);
        let id = self.id;
        block_on_sdk(py, runtime, async move {
            client
                .vm_logs(ix_sdk::ix_rpc_types::types::vm::LogsRequest {
                    vm_id: id,
                    limit,
                    since,
                    stream,
                })
                .await
                .map(|response| response.entries)
        })
        .and_then(|entries| json::logs(&entries).map_err(error::json))
    }
}

#[pyo3::pymethods]
impl PythonFsHandle {
    pub fn read_json(&self, py: pyo3::Python<'_>, path: String) -> pyo3::PyResult<String> {
        let runtime = std::sync::Arc::clone(&self.runtime);
        let client = std::sync::Arc::clone(&self.client);
        let id = self.id;
        block_on_sdk(py, runtime, async move {
            client
                .vm_fs_read(ix_sdk::ix_rpc_types::types::resource::VmFsReadRequest {
                    vm_id: id,
                    path,
                })
                .await
        })
        .and_then(|response| json::fs_read(&response).map_err(error::json))
    }

    #[pyo3(signature = (path, text, mode=None))]
    pub fn write_json(
        &self,
        py: pyo3::Python<'_>,
        path: String,
        text: String,
        mode: Option<u32>,
    ) -> pyo3::PyResult<String> {
        let runtime = std::sync::Arc::clone(&self.runtime);
        let client = std::sync::Arc::clone(&self.client);
        let id = self.id;
        block_on_sdk(py, runtime, async move {
            client
                .vm_fs_write(ix_sdk::ix_rpc_types::types::resource::VmFsWriteRequest {
                    vm_id: id,
                    path,
                    text,
                    mode,
                })
                .await
        })
        .and_then(|response| json::fs_write(&response).map_err(error::json))
    }

    pub fn list_json(&self, py: pyo3::Python<'_>, path: String) -> pyo3::PyResult<String> {
        let runtime = std::sync::Arc::clone(&self.runtime);
        let client = std::sync::Arc::clone(&self.client);
        let id = self.id;
        block_on_sdk(py, runtime, async move {
            client
                .vm_fs_list(ix_sdk::ix_rpc_types::types::resource::VmFsListRequest {
                    vm_id: id,
                    path,
                })
                .await
                .map(|response| response.entries)
        })
        .and_then(|entries| json::fs_entries(&entries).map_err(error::json))
    }
}

#[pyo3::pymethods]
impl PythonSecretsHandle {
    pub fn set(&self, py: pyo3::Python<'_>, key: String, value: String) -> pyo3::PyResult<()> {
        let runtime = std::sync::Arc::clone(&self.runtime);
        let client = std::sync::Arc::clone(&self.client);
        let id = self.id;
        block_on_sdk(py, runtime, async move {
            client.set_vm_secret(id, key, value).await.map(|_| ())
        })
    }

    pub fn delete(&self, py: pyo3::Python<'_>, key: String) -> pyo3::PyResult<()> {
        let runtime = std::sync::Arc::clone(&self.runtime);
        let client = std::sync::Arc::clone(&self.client);
        let id = self.id;
        block_on_sdk(py, runtime, async move {
            client.delete_vm_secret(id, key).await.map(|_| ())
        })
    }

    pub fn list_json(&self, py: pyo3::Python<'_>) -> pyo3::PyResult<String> {
        let runtime = std::sync::Arc::clone(&self.runtime);
        let client = std::sync::Arc::clone(&self.client);
        let id = self.id;
        block_on_sdk(py, runtime, async move {
            client
                .list_vm_secrets(id)
                .await
                .map(|response| response.secrets)
        })
        .and_then(|secrets| json::secrets(&secrets).map_err(error::json))
    }
}

#[pyo3::pymodule]
fn _ix_sdk(module: &pyo3::Bound<'_, pyo3::types::PyModule>) -> pyo3::PyResult<()> {
    module.add_class::<PythonClient>()?;
    module.add_class::<PythonBranch>()?;
    module.add_class::<PythonFsHandle>()?;
    module.add_class::<PythonSecretsHandle>()?;
    module.add("__version__", env!("CARGO_PKG_VERSION"))?;
    Ok(())
}
