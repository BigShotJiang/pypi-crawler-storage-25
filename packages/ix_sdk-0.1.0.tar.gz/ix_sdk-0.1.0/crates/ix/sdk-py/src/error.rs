pub fn json(source: serde_json::Error) -> pyo3::PyErr {
    pyo3::exceptions::PyRuntimeError::new_err(format!(
        "failed to encode Python SDK payload: {source}"
    ))
}

pub fn runtime(source: std::io::Error) -> pyo3::PyErr {
    pyo3::exceptions::PyRuntimeError::new_err(format!(
        "failed to start Python SDK runtime: {source}"
    ))
}

pub fn invalid_uuid(input: &str, source: impl std::fmt::Display) -> pyo3::PyErr {
    pyo3::exceptions::PyValueError::new_err(format!("invalid UUID '{input}': {source}"))
}

pub fn sdk(source: ix_sdk::SdkError) -> pyo3::PyErr {
    pyo3::exceptions::PyRuntimeError::new_err(source.to_string())
}

pub fn missing_token() -> pyo3::PyErr {
    pyo3::exceptions::PyValueError::new_err(
        "no token found — set IX_TOKEN, add token to /etc/ix/config.toml or \
         ~/.config/ix/config.toml, or pass token=",
    )
}
