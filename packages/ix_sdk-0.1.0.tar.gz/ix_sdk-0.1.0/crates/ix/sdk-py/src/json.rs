fn branch_status(status: ix_sdk::ix_rpc_types::types::vm::Status) -> &'static str {
    match status {
        ix_sdk::ix_rpc_types::types::vm::Status::Pending => "pending",
        ix_sdk::ix_rpc_types::types::vm::Status::Starting => "starting",
        ix_sdk::ix_rpc_types::types::vm::Status::Running => "running",
        ix_sdk::ix_rpc_types::types::vm::Status::Migrating => "migrating",
        ix_sdk::ix_rpc_types::types::vm::Status::Snapshotting => "snapshotting",
        ix_sdk::ix_rpc_types::types::vm::Status::Sleeping => "sleeping",
        ix_sdk::ix_rpc_types::types::vm::Status::Waking => "waking",
        ix_sdk::ix_rpc_types::types::vm::Status::Stopping => "stopping",
        ix_sdk::ix_rpc_types::types::vm::Status::Stopped => "stopped",
        ix_sdk::ix_rpc_types::types::vm::Status::Failed => "failed",
        ix_sdk::ix_rpc_types::types::vm::Status::Deleted => "deleted",
        ix_sdk::ix_rpc_types::types::vm::Status::Creating => "creating",
        ix_sdk::ix_rpc_types::types::vm::Status::GoldenCapture => "golden_capture",
    }
}

fn region(region: &ix_sdk::ix_rpc_types::types::network::Region) -> serde_json::Value {
    serde_json::json!({
        "id": region.id.to_string(),
        "slug": region.slug,
        "display_name": region.display_name,
        "status": region.status,
    })
}

fn branch_value(vm: &ix_sdk::ix_rpc_types::types::vm::Vm) -> serde_json::Value {
    serde_json::json!({
        "id": vm.id.to_string(),
        "name": vm.name,
        "image": vm.image,
        "status": branch_status(vm.status),
        "ipv6": vm.ipv6,
        "ipv4": vm.ipv4,
        "subdomain": vm.subdomain,
        "memory_mib": vm.memory_mib,
        "cpu_cores": vm.cpu_cores,
        "ephemeral": vm.ephemeral,
        "snapshot_key": vm.snapshot_key,
        "fork_parent_vm_id": vm.fork_parent_vm_id.map(|id| id.to_string()),
        "fork_base_lsn_ns": vm.fork_base_lsn_ns,
        "attach_token": vm.attach_token,
        "started_at": vm.started_at,
        "stopped_at": vm.stopped_at,
        "failure_reason": vm.failure_reason,
        "created_at": vm.created_at,
        "updated_at": vm.updated_at,
        "region": vm.region.as_ref().map(region),
        "owner_id": vm.owner_id.to_string(),
    })
}

fn commit_value(snapshot: &ix_sdk::ix_rpc_types::types::vcs::snapshot::Vm) -> serde_json::Value {
    serde_json::json!({
        "id": snapshot.id.to_string(),
        "branch_id": snapshot.vm_id.to_string(),
        "parent_id": snapshot.parent_id.map(|id| id.to_string()),
        "status": snapshot.status.as_str(),
        "memory_mib": snapshot.memory_mib,
        "manifest_key": snapshot.manifest_key,
        "created_at_millis": snapshot.created_at_millis,
    })
}

pub fn branch(vm: &ix_sdk::ix_rpc_types::types::vm::Vm) -> Result<String, serde_json::Error> {
    serde_json::to_string(&branch_value(vm))
}

pub fn branches(vms: &[ix_sdk::ix_rpc_types::types::vm::Vm]) -> Result<String, serde_json::Error> {
    serde_json::to_string(&vms.iter().map(branch_value).collect::<Vec<_>>())
}

pub fn commit_from_vm(
    vm: &ix_sdk::ix_rpc_types::types::vm::Vm,
) -> Result<String, serde_json::Error> {
    serde_json::to_string(&serde_json::json!({
        "id": vm.id.to_string(),
        "branch_id": vm.id.to_string(),
        "parent_id": vm.fork_parent_vm_id.map(|id| id.to_string()),
        "status": branch_status(vm.status),
        "memory_mib": vm.memory_mib,
        "manifest_key": vm.snapshot_key,
        "created_at_millis": vm.updated_at,
    }))
}

pub fn commits(
    snapshots: &[ix_sdk::ix_rpc_types::types::vcs::snapshot::Vm],
) -> Result<String, serde_json::Error> {
    serde_json::to_string(&snapshots.iter().map(commit_value).collect::<Vec<_>>())
}

pub fn exec(
    result: &ix_sdk::ix_rpc_types::types::resource::exec::OpResult,
) -> Result<String, serde_json::Error> {
    serde_json::to_string(&serde_json::json!({
        "exit_code": result.exit_code,
        "stdout": result.stdout,
        "stderr": result.stderr,
    }))
}

pub fn fs_read(
    response: &ix_sdk::ix_rpc_types::types::resource::VmFsReadResponse,
) -> Result<String, serde_json::Error> {
    serde_json::to_string(&serde_json::json!({
        "path": response.path,
        "text": response.text,
    }))
}

pub fn fs_write(
    response: &ix_sdk::ix_rpc_types::types::resource::VmFsWriteResponse,
) -> Result<String, serde_json::Error> {
    serde_json::to_string(&serde_json::json!({
        "bytes_written": response.bytes_written,
    }))
}

pub fn fs_entries(
    entries: &[ix_sdk::ix_rpc_types::types::resource::VmFsEntry],
) -> Result<String, serde_json::Error> {
    serde_json::to_string(
        &entries
            .iter()
            .map(|entry| {
                serde_json::json!({
                    "name": entry.name,
                    "size": entry.size,
                    "mode": entry.mode,
                    "mtime_ns": entry.mtime_ns,
                    "is_dir": entry.is_dir,
                })
            })
            .collect::<Vec<_>>(),
    )
}

pub fn logs(
    entries: &[ix_sdk::ix_rpc_types::types::vm::LogEntry],
) -> Result<String, serde_json::Error> {
    serde_json::to_string(
        &entries
            .iter()
            .map(|entry| {
                serde_json::json!({
                    "timestamp": entry.timestamp,
                    "vm_id": entry.vm_id.to_string(),
                    "stream": entry.stream,
                    "message": entry.message,
                })
            })
            .collect::<Vec<_>>(),
    )
}

pub fn secrets(
    entries: &[ix_sdk::ix_rpc_types::types::vm::Secret],
) -> Result<String, serde_json::Error> {
    serde_json::to_string(
        &entries
            .iter()
            .map(|entry| {
                serde_json::json!({
                    "id": entry.id.to_string(),
                    "name": entry.name,
                    "created_at": entry.created_at,
                    "updated_at": entry.updated_at,
                })
            })
            .collect::<Vec<_>>(),
    )
}

pub fn regions(
    entries: &[ix_sdk::ix_rpc_types::types::network::Region],
) -> Result<String, serde_json::Error> {
    serde_json::to_string(&entries.iter().map(region).collect::<Vec<_>>())
}
