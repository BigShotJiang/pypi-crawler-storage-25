import unittest

import ix_sdk

import common


class LiveLifecycleTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.client = common.client()
        cls.region = common.live_region(cls.client)

    def test_create_exec_and_filesystem_roundtrip(self) -> None:
        branch = common.create_branch(
            self.client,
            "ubuntu:22.04",
            self.region,
            name=common.unique_name("py-sdk-lifecycle"),
            ipv4=False,
        )
        try:
            info = branch.get()
            self.assertEqual(info.status, ix_sdk.BranchStatus.RUNNING)

            result = branch.exec(ix_sdk.ExecOptions(command=["ls", "/"]))
            self.assertEqual(result.exit_code, 0)
            self.assertIn("etc", result.stdout)
            self.assertIn("usr", result.stdout)

            write_result = branch.fs().write(
                ix_sdk.FsWriteOptions(path="/tmp/python-sdk.txt", text="hello from python sdk")
            )
            self.assertEqual(write_result.bytes_written, 21)

            read_result = branch.fs().read(
                ix_sdk.FsReadOptions(path="/tmp/python-sdk.txt")
            )
            self.assertEqual(read_result.text, "hello from python sdk")

            entries = branch.fs().list(ix_sdk.FsListOptions(path="/tmp"))
            self.assertIn(
                ix_sdk.FsEntry(
                    is_dir=False,
                    mode=entries[0].mode,
                    mtime_ns=entries[0].mtime_ns,
                    name="python-sdk.txt",
                    size=21,
                ),
                [
                    ix_sdk.FsEntry(
                        is_dir=entry.is_dir,
                        mode=entry.mode,
                        mtime_ns=entry.mtime_ns,
                        name=entry.name,
                        size=entry.size,
                    )
                    for entry in entries
                    if entry.name == "python-sdk.txt"
                ],
            )
        finally:
            branch.delete()

    def test_create_commit_and_log(self) -> None:
        branch = common.create_branch(
            self.client,
            "ubuntu:22.04",
            self.region,
            name=common.unique_name("py-sdk-commit"),
            ipv4=False,
        )
        try:
            commit = branch.commit()
            self.assertTrue(commit.id)

            log = branch.log()
            self.assertGreater(len(log), 0)
            self.assertEqual(log[0].branch_id, branch.id)
        finally:
            branch.delete()


if __name__ == "__main__":
    unittest.main()
