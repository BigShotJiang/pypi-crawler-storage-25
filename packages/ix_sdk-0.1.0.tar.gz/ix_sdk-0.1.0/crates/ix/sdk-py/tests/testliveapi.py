import unittest

import ix_sdk

import common


class LiveApiTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.client = common.client()
        cls.region_list = common.regions(cls.client)

    def test_regions(self) -> None:
        self.assertGreater(len(self.region_list), 0)
        self.assertIsInstance(self.region_list[0], ix_sdk.RegionInfo)
        self.assertTrue(self.region_list[0].slug)
        self.assertTrue(self.region_list[0].display_name)

    def test_create_and_get_roundtrip(self) -> None:
        branch = common.create_branch(
            self.client,
            "ubuntu:22.04",
            self.region_list[0].slug,
            name=common.unique_name("py-sdk-api"),
            ipv4=False,
        )
        try:
            fetched = self.client.get(branch.id)
            info = fetched.get()
            self.assertEqual(info.id, branch.id)
            self.assertEqual(info.name, fetched.get().name)
            self.assertEqual(info.status, ix_sdk.BranchStatus.RUNNING)
            self.assertEqual(info.region.slug, self.region_list[0].slug)
        finally:
            branch.delete()


if __name__ == "__main__":
    unittest.main()
