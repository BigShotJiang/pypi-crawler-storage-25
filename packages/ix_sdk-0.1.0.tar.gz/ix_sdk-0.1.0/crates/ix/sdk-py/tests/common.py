import os
import time
import unittest

import ix_sdk

UNBOOTSTRAPPED_VM_TABLE_MARKERS = (
    'relation "vms" does not exist',
    "42P01",
)
UNAUTHORIZED_MARKERS = (
    "unauthorized:",
    "Invalid or expired token",
)


def require_live_api() -> None:
    if os.environ.get("IX_PYTHON_RUN_LIVE") != "1":
        raise unittest.SkipTest("requires live API")


def client() -> ix_sdk.IxSdkClient:
    require_live_api()
    try:
        return ix_sdk.IxSdkClient()
    except ValueError as error:
        if "no token found" in str(error):
            raise unittest.SkipTest("requires ix auth config") from error
        raise


def unique_name(prefix: str) -> str:
    return f"{prefix}-{time.time_ns()}"


def _raise_for_runtime_precondition(error: RuntimeError) -> None:
    message = str(error)
    if any(marker in message for marker in UNAUTHORIZED_MARKERS):
        raise unittest.SkipTest("requires a valid ix auth token") from error
    if any(marker in message for marker in UNBOOTSTRAPPED_VM_TABLE_MARKERS):
        raise unittest.SkipTest(
            "server database is not bootstrapped for VM lifecycle tests"
        ) from error


def regions(sdk: ix_sdk.IxSdkClient) -> list[ix_sdk.RegionInfo]:
    try:
        return sdk.regions()
    except RuntimeError as error:
        _raise_for_runtime_precondition(error)
        raise


def live_region(sdk: ix_sdk.IxSdkClient) -> str:
    region_list = regions(sdk)
    if not region_list:
        raise unittest.SkipTest("list_regions returned no regions")
    return region_list[0].slug


def create_branch(
    sdk: ix_sdk.IxSdkClient,
    image: str,
    region: ix_sdk.Region | str,
    *,
    name: str | None = None,
    ipv4: bool | None = None,
    wait_until_ready: bool = True,
    disable_golden: bool = False,
) -> ix_sdk.Branch:
    try:
        return sdk.create(
            ix_sdk.CreateOptions(
                image=image,
                region=region,
                name=name,
                ipv4=ipv4,
                wait_until_ready=wait_until_ready,
                disable_golden=disable_golden,
            )
        )
    except RuntimeError as error:
        _raise_for_runtime_precondition(error)
        raise
