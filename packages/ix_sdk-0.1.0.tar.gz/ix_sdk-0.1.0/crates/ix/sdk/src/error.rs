#[derive(Debug, snafu::Snafu)]
#[snafu(visibility(pub(crate)))]
pub enum SdkError {
    #[snafu(display("failed to build HTTP client"))]
    BuildHttpClient { source: reqwest::Error },

    #[snafu(display("insufficient credits (0 remaining)"))]
    PaymentRequired,

    #[snafu(display("unauthorized: {body}"))]
    Unauthorized { body: String },

    #[snafu(display("RPC request failed: HTTP {status} - {body}"))]
    StatusSnafu {
        status: reqwest::StatusCode,
        body: String,
    },

    #[snafu(display("{error}"))]
    Error { error: ix_rpc_types::error::Error },

    #[snafu(display("no data in response"))]
    NoData,

    #[snafu(display("failed to send request{details}"))]
    SendRequest {
        source: reqwest::Error,
        details: String,
    },

    #[snafu(display("connection failed{details}"))]
    ConnectionFailed { details: String },

    #[snafu(display("failed to parse response"))]
    ParseResponse { source: reqwest::Error },

    #[snafu(display("failed to serialize RPC request (method={method})"))]
    SerializeRequest {
        method: String,
        source: rpc_wire::frame::Error,
    },

    #[snafu(display("failed to deserialize RPC response (method={method})"))]
    DeserializeResponse {
        method: String,
        source: rpc_wire::DecodeError,
    },

    #[snafu(display("VM '{identifier}' not found"))]
    VmNotFound { identifier: String },

    #[snafu(display("volume '{identifier}' not found"))]
    VolumeNotFound { identifier: String },

    #[snafu(display("snapshot '{identifier}' not found"))]
    SnapshotNotFound { identifier: String },

    #[snafu(display("branch '{identifier}' not found"))]
    BranchNotFound { identifier: String },

    #[snafu(display("commit '{identifier}' not found"))]
    CommitNotFound { identifier: String },

    #[snafu(display("platform at capacity: {message}"))]
    CapacityExhausted { message: String },

    #[snafu(display("invalid TypeId: '{input}'"))]
    ParseTypeId { input: String },

    #[snafu(display("invalid UUID: '{input}'"))]
    ParseUuid { input: String, source: uuid::Error },

    #[snafu(display("VM {vm_id} did not become ready within {timeout_secs}s"))]
    VmReadyTimeout {
        vm_id: uuid::Uuid,
        timeout_secs: u64,
    },

    #[snafu(display("VM {vm_id} failed to start: {reason}"))]
    VmStartFailed { vm_id: uuid::Uuid, reason: String },

    #[snafu(display("{endpoint} endpoint returned HTTP {status}: {body}"))]
    StreamingHttpStatus {
        endpoint: &'static str,
        status: reqwest::StatusCode,
        body: String,
    },

    #[snafu(display("failed to connect to {endpoint} endpoint"))]
    StreamingConnect {
        endpoint: &'static str,
        source: reqwest::Error,
    },
}

pub type Result<T> = std::result::Result<T, SdkError>;

impl SdkError {
    #[must_use]
    pub fn rpc_error(&self) -> Option<&ix_rpc_types::error::Error> {
        match self {
            Self::Error { error } => Some(error),
            _ => None,
        }
    }

    #[must_use]
    pub fn rpc_debug(&self) -> Option<&ix_rpc_types::error::DebugInfo> {
        self.rpc_error().and_then(ix_rpc_types::error::Error::debug)
    }

    #[must_use]
    pub fn trace_id(&self) -> Option<&str> {
        self.rpc_debug().and_then(|debug| debug.trace_id.as_deref())
    }
}

#[cfg(feature = "napi")]
impl From<SdkError> for napi::Error {
    fn from(e: SdkError) -> Self {
        let code = match &e {
            SdkError::VmNotFound { .. } => "VM_NOT_FOUND",
            SdkError::VolumeNotFound { .. } => "VOLUME_NOT_FOUND",
            SdkError::SnapshotNotFound { .. } => "SNAPSHOT_NOT_FOUND",
            SdkError::BranchNotFound { .. } => "BRANCH_NOT_FOUND",
            SdkError::CommitNotFound { .. } => "COMMIT_NOT_FOUND",
            SdkError::PaymentRequired => "PAYMENT_REQUIRED",
            SdkError::Unauthorized { .. } => "UNAUTHORIZED",
            SdkError::CapacityExhausted { .. } => "CAPACITY_EXHAUSTED",
            SdkError::VmReadyTimeout { .. } => "VM_READY_TIMEOUT",
            SdkError::VmStartFailed { .. } => "VM_START_FAILED",
            SdkError::ConnectionFailed { .. } => "CONNECTION_FAILED",
            SdkError::SendRequest { .. } => "SEND_REQUEST_FAILED",
            SdkError::ParseResponse { .. } => "PARSE_RESPONSE_FAILED",
            SdkError::Error { error } => match error {
                ix_rpc_types::error::Error::RateLimited { .. } => "RATE_LIMITED",
                ix_rpc_types::error::Error::InvalidRequest { .. } => "INVALID_REQUEST",
                ix_rpc_types::error::Error::Conflict { .. } => "CONFLICT",
                ix_rpc_types::error::Error::Forbidden { .. } => "FORBIDDEN",
                _ => "RPC_ERROR",
            },
            _ => "SDK_ERROR",
        };
        napi::Error::new(napi::Status::GenericFailure, format!("[{code}] {e}"))
    }
}
