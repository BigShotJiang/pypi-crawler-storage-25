//! Shared bidirectional HTTP body streaming primitive.
//!
//! Both console and port-forward use the same mechanism: a POST request
//! where the request body carries data toward the server and the response
//! body carries data back. This module extracts that common pattern.

use futures_util::StreamExt as _;
use tokio::io::AsyncReadExt as _;

use crate::error::{self, Result};

/// Channel capacity for the outbound body stream (32 chunks of up to
/// `STREAM_BUF_SIZE` bytes each). Sized to absorb bursts without
/// backpressuring the caller while keeping memory bounded (~256 KiB).
const BODY_CHANNEL_CAPACITY: usize = 32;

/// Buffer size for the duplex bridge and read loops. 8 KiB matches
/// typical TCP segment sizes and avoids excessive syscall overhead
/// while keeping per-connection memory low.
pub(crate) const STREAM_BUF_SIZE: usize = 8192;
const CONNECT_RESPONSE_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(10);

/// A bidirectional streaming connection over HTTP body streaming.
///
/// `reader` carries data from the remote endpoint, `writer` sends data
/// to it. Both operate over HTTP body streaming (QUIC/H3 to gateway).
///
/// `guard` aborts the background body-forwarding task on drop so the
/// connection tears down cleanly.
pub struct StreamingConnection {
    pub reader: Box<dyn tokio::io::AsyncRead + Unpin + Send>,
    pub writer: Box<dyn tokio::io::AsyncWrite + Unpin + Send>,
    pub guard: StreamingGuard,
}

/// Aborts the streaming body-forwarding task on drop.
pub struct StreamingGuard(tokio::task::AbortHandle);

impl Drop for StreamingGuard {
    fn drop(&mut self) {
        self.0.abort();
    }
}

/// Open a bidirectional streaming connection to the given URL.
///
/// Sends `POST {url}` with Bearer auth. The request body carries data
/// toward the server; the response body carries data back.
///
/// `endpoint_name` is used in error messages (e.g. "console", "port-forward").
pub(crate) async fn connect(
    http: &reqwest::Client,
    url: &str,
    token: &str,
    endpoint_name: &'static str,
) -> Result<StreamingConnection> {
    match connect_with_client(http, url, token).await {
        Ok(connection) => Ok(connection),
        Err(error) => Err(map_connect_error(url, endpoint_name, error).await),
    }
}

enum ConnectError {
    Timeout,
    Request(reqwest::Error),
    StatusSnafu {
        status: reqwest::StatusCode,
        body: String,
    },
}

async fn connect_with_client(
    http: &reqwest::Client,
    url: &str,
    token: &str,
) -> std::result::Result<StreamingConnection, ConnectError> {
    let (body_tx, body_rx) = tokio::sync::mpsc::channel::<
        std::result::Result<bytes::Bytes, std::io::Error>,
    >(BODY_CHANNEL_CAPACITY);
    let body_stream = tokio_stream::wrappers::ReceiverStream::new(body_rx);
    let body = reqwest::Body::wrap_stream(body_stream);

    // Start forwarding caller writes before initiating the request so the body
    // stream is live as soon as reqwest begins polling it.
    let (write_half, mut read_half) = tokio::io::duplex(STREAM_BUF_SIZE);
    let forward_task = tokio::spawn(async move {
        let mut buf = vec![0u8; STREAM_BUF_SIZE];
        loop {
            match read_half.read(&mut buf).await {
                Ok(0) => break,
                Ok(n) => {
                    let chunk =
                        bytes::Bytes::copy_from_slice(buf.get(..n).unwrap_or(buf.as_slice()));
                    if body_tx.send(Ok(chunk)).await.is_err() {
                        break;
                    }
                }
                Err(_) => break,
            }
        }
    });

    let mut trace_headers = reqwest::header::HeaderMap::new();
    let request_id = ix_tracing::ensure_http_request_id(&mut trace_headers);
    ix_tracing::inject_current_context_into_http_headers(&mut trace_headers);

    let send_result = tokio::time::timeout(
        CONNECT_RESPONSE_TIMEOUT,
        http.post(url)
            .header("Authorization", format!("Bearer {}", token))
            .header("content-type", "application/octet-stream")
            .headers(trace_headers)
            .body(body)
            .send(),
    )
    .await;

    tracing::debug!(request_id = %request_id, endpoint = %url, "opened streaming request");

    let response = match send_result {
        Ok(Ok(response)) => response,
        Ok(Err(source)) => {
            forward_task.abort();
            return Err(ConnectError::Request(source));
        }
        Err(_) => {
            forward_task.abort();
            return Err(ConnectError::Timeout);
        }
    };

    if !response.status().is_success() {
        let status = response.status();
        // Best-effort body read for error context; the real error is the
        // HTTP status itself, so a failure to read the body is not fatal.
        let text = response.text().await.unwrap_or_default();
        forward_task.abort();
        return Err(ConnectError::StatusSnafu { status, body: text });
    }

    // Response body stream -> AsyncRead
    let response_stream = response.bytes_stream();
    let reader: Box<dyn tokio::io::AsyncRead + Unpin + Send> =
        Box::new(tokio_util::io::StreamReader::new(
            response_stream.map(|result| result.map_err(std::io::Error::other)),
        ));

    Ok(StreamingConnection {
        reader,
        writer: Box::new(write_half),
        guard: StreamingGuard(forward_task.abort_handle()),
    })
}

async fn map_connect_error(
    url: &str,
    endpoint_name: &'static str,
    error: ConnectError,
) -> error::SdkError {
    match error {
        ConnectError::StatusSnafu { status, body } => error::SdkError::StreamingHttpStatus {
            endpoint: endpoint_name,
            status,
            body,
        },
        ConnectError::Request(source) => error::SdkError::StreamingConnect {
            endpoint: endpoint_name,
            source,
        },
        ConnectError::Timeout => {
            let port = url::Url::parse(url)
                .ok()
                .and_then(|u| u.port())
                .unwrap_or(443);
            let details = format!(
                "\n\n  server: {url}\n\n  error: timed out connecting to {endpoint_name} endpoint \
                 after {}s\n\n  hint: ix requires QUIC (UDP {port}). ensure UDP is not blocked.",
                CONNECT_RESPONSE_TIMEOUT.as_secs()
            );
            error::SdkError::ConnectionFailed { details }
        }
    }
}
