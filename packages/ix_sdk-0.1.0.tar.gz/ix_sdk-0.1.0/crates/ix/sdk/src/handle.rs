use std::{fmt, str::FromStr};

use serde::{Deserialize, Serialize};

macro_rules! define_handle {
    ($name:ident, $doc:expr) => {
        #[doc = $doc]
        #[derive(Debug, Clone, Copy, PartialEq, Eq, Hash, Serialize, Deserialize)]
        #[serde(transparent)]
        pub struct $name(uuid::Uuid);

        impl $name {
            #[must_use]
            pub fn uuid(self) -> uuid::Uuid {
                self.0
            }

            #[must_use]
            pub fn nil() -> Self {
                Self(uuid::Uuid::nil())
            }
        }

        impl From<uuid::Uuid> for $name {
            fn from(id: uuid::Uuid) -> Self {
                Self(id)
            }
        }

        impl FromStr for $name {
            type Err = uuid::Error;

            fn from_str(s: &str) -> Result<Self, Self::Err> {
                uuid::Uuid::from_str(s).map(Self)
            }
        }

        impl fmt::Display for $name {
            fn fmt(&self, f: &mut fmt::Formatter<'_>) -> fmt::Result {
                fmt::Display::fmt(&self.0.as_hyphenated(), f)
            }
        }
    };
}

define_handle!(Branch, "Handle to a VM branch (wraps a VM UUID).");
define_handle!(
    Commit,
    "Handle to a snapshot commit (wraps a snapshot UUID)."
);
define_handle!(Fs, "Handle to a filesystem tree reference.");
define_handle!(ReadView, "Handle to a pinned branch read view.");
define_handle!(WriteLease, "Handle to a branch write lease.");

const VM_PREFIX: &str = "vm_";

/// Convert a `Branch` to a GraphQL-style `vm_<hex>` TypeId string.
#[must_use]
pub fn branch_to_vm_typeid(branch: Branch) -> String {
    format!("{VM_PREFIX}{}", branch.0.as_simple())
}

/// Parse a GraphQL-style `vm_<hex>` TypeId string back to a `Branch`.
pub fn vm_typeid_to_branch(s: &str) -> Result<Branch, uuid::Error> {
    let hex = s.strip_prefix(VM_PREFIX).unwrap_or(s);
    uuid::Uuid::parse_str(hex).map(Branch)
}

#[cfg(test)]
mod tests {
    use crate::handle::{
        Branch, Commit, Fs, ReadView, WriteLease, branch_to_vm_typeid, vm_typeid_to_branch,
    };

    #[test]
    fn roundtrip_display_parse() {
        let id = uuid::Uuid::new_v4();
        for handle in [
            Branch::from(id).to_string(),
            Commit::from(id).to_string(),
            Fs::from(id).to_string(),
            ReadView::from(id).to_string(),
            WriteLease::from(id).to_string(),
        ] {
            assert_eq!(handle, id.as_hyphenated().to_string());
        }
        assert_eq!(id, Branch::from(id).uuid());
    }

    #[test]
    fn typeid_roundtrip() {
        let branch = Branch::from(uuid::Uuid::new_v4());
        let typeid = branch_to_vm_typeid(branch);
        assert!(typeid.starts_with("vm_"));
        let parsed = vm_typeid_to_branch(&typeid).expect("valid typeid");
        assert_eq!(parsed, branch);
    }

    #[test]
    fn nil_handles() {
        assert_eq!(Branch::nil().uuid(), uuid::Uuid::nil());
        assert_eq!(Commit::nil().uuid(), uuid::Uuid::nil());
        assert_eq!(Fs::nil().uuid(), uuid::Uuid::nil());
        assert_eq!(ReadView::nil().uuid(), uuid::Uuid::nil());
        assert_eq!(WriteLease::nil().uuid(), uuid::Uuid::nil());
    }

    #[test]
    fn serde_roundtrip() {
        let branch = Branch::from(uuid::Uuid::new_v4());
        let json = serde_json::to_string(&branch).expect("serialize");
        let parsed: Branch = serde_json::from_str(&json).expect("deserialize");
        assert_eq!(parsed, branch);
    }
}
