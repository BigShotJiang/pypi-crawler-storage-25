use crate::handle::Commit;

/// Captured output from a command execution.
pub struct Output {
    pub exit_code: i32,
    pub stdout: String,
    pub stderr: String,
}

/// Result of executing a command on a branch.
///
/// Contains the captured output plus commit handles for the branch state
/// before and after execution.
pub struct Proc {
    output: Output,
    /// Branch state before exec (nil UUID until server returns it).
    pub pre: Commit,
    /// Branch state after exec (nil UUID until server returns it).
    pub post: Commit,
}

impl Proc {
    #[must_use]
    pub fn new(output: Output, pre: Commit, post: Commit) -> Self {
        Self { output, pre, post }
    }

    #[must_use]
    pub fn stdout(&self) -> &str {
        &self.output.stdout
    }

    #[must_use]
    pub fn stderr(&self) -> &str {
        &self.output.stderr
    }

    /// Returns the process exit code.
    #[must_use]
    pub fn wait(&self) -> i32 {
        self.output.exit_code
    }

    /// Consume and return the full output.
    #[must_use]
    pub fn into_output(self) -> Output {
        self.output
    }
}
