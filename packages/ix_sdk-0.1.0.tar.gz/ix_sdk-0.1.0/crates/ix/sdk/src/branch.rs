use serde::{Deserialize, Serialize};

use crate::handle::{Branch, ReadView, WriteLease};

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum BranchWriteMode {
    Exclusive,
    Shared,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum BusyStrategy {
    Wait,
    Fork,
    CreateEmpty,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum ReadMode {
    Pinned,
    FollowHead,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct BranchSpec {
    pub write_mode: BranchWriteMode,
    pub read_mode: ReadMode,
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub enum WritePermit {
    Exclusive {
        branch: Branch,
        lease: WriteLease,
    },
    Shared {
        branch: Branch,
        lease: WriteLease,
    },
    Forked {
        parent: Branch,
        branch: Branch,
        lease: WriteLease,
    },
}

#[derive(Debug, Clone, Copy, PartialEq, Eq, Serialize, Deserialize)]
pub struct ViewPermit {
    pub branch: Branch,
    pub view: ReadView,
}
