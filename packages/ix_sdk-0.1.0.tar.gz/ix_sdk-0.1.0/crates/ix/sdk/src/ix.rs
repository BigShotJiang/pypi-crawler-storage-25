use std::sync::Arc;

use crate::{
    client::IxClient,
    error::Result,
    handle::{Branch, Commit, Fs},
    proc::{Output, Proc},
};

/// Options for spawning a new branch (VM).
pub struct SpawnOptions {
    pub name: Option<String>,
    pub ipv4: Option<bool>,
}

/// The handle-based ix SDK client.
///
/// ```ignore
/// let ix = Ix::connect("https://api.ix.dev", token)?;
/// let main = ix.spawn("ubuntu:24.04", None).await?;
/// let fork = ix.fork(main).await?;
/// let proc = ix.exec(fork, "echo hello", None).await?;
/// println!("{}", proc.stdout());
/// ```
pub struct Ix {
    client: Arc<IxClient>,
}

impl Ix {
    /// Snafu to the ix platform.
    pub fn connect(server: impl Into<String>, token: impl Into<String>) -> Result<Self> {
        let client = IxClient::new(server, token)?;
        Ok(Self {
            client: Arc::new(client),
        })
    }

    /// Wrap an existing `IxClient` in the handle-based API.
    #[must_use]
    pub fn from_client(client: Arc<IxClient>) -> Self {
        Self { client }
    }

    /// Access the underlying `IxClient` for backward compat / advanced usage.
    #[must_use]
    pub fn client(&self) -> &Arc<IxClient> {
        &self.client
    }

    /// Spawn a new VM from an OCI image, returning a `Branch` handle.
    pub async fn spawn(
        &self,
        image: impl Into<String>,
        region: impl Into<String>,
        options: Option<SpawnOptions>,
    ) -> Result<Branch> {
        let opts = options.as_ref();
        let req = ix_rpc_types::types::vm::CreateRequest {
            image: image.into(),
            name: opts.and_then(|o| o.name.clone()),
            ipv4: opts.and_then(|o| o.ipv4),
            wait_until_ready: true,
            region: region.into(),
            disable_golden: false,
        };
        let data = self.client.create_vm(req).await?;
        Ok(Branch::from(data.vm.id))
    }

    /// Fork an existing branch, returning a new `Branch` handle.
    pub async fn fork(&self, branch: Branch) -> Result<Branch> {
        let req = ix_rpc_types::types::vcs::ForkVmRequest {
            snapshot_id: branch.uuid(),
            name: None,
            wait_until_ready: true,
        };
        let data = self.client.fork_vm(req).await?;
        Ok(Branch::from(data.vm.id))
    }

    /// List snapshot commits for a branch, newest first.
    pub async fn snapshots(&self, branch: Branch) -> Result<Vec<Commit>> {
        let data = self.client.list_vm_snapshots(branch.uuid()).await?;
        Ok(data
            .snapshots
            .iter()
            .map(|snapshot| Commit::from(snapshot.id))
            .collect())
    }

    /// Execute a shell command on a branch, returning a `Proc`.
    pub async fn exec(
        &self,
        branch: Branch,
        cmd: impl Into<String>,
        cwd: Option<String>,
    ) -> Result<Proc> {
        let req = ix_rpc_types::types::exec::VmRequest {
            vm_id: branch.uuid(),
            command: vec!["sh".to_owned(), "-c".to_owned(), cmd.into()],
            working_dir: cwd,
        };
        let data = self.client.exec_vm(req).await?;
        let output = Output {
            exit_code: data.exit_code,
            stdout: data.stdout,
            stderr: data.stderr,
        };
        Ok(Proc::new(output, Commit::nil(), Commit::nil()))
    }

    /// Get a filesystem handle from a commit (stub — returns `Fs(commit.uuid())`).
    pub fn fs(&self, commit: Commit) -> Result<Fs> {
        Ok(Fs::from(commit.uuid()))
    }

    /// Filter a filesystem by glob patterns (stub — returns input unchanged).
    pub fn filter(&self, fs: Fs, _globs: &[String]) -> Result<Fs> {
        Ok(fs)
    }

    /// Describe an entity with text (stub — no-op).
    pub fn describe(&self, _entity: &str, _text: &str) -> Result<()> {
        Ok(())
    }
}
