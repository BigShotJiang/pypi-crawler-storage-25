pub mod auth;
pub mod branch;
pub mod client;
pub mod console;
pub mod error;
pub mod handle;
pub mod ix;
pub mod port_forward;
pub mod proc;
mod resolve;
pub mod sandbox;
pub mod streaming;

pub use branch::{BranchSpec, BranchWriteMode, BusyStrategy, ReadMode, ViewPermit, WritePermit};
pub use client::IxClient;
pub use error::SdkError;
pub use handle::{Branch, Commit, Fs, ReadView, WriteLease};
pub use ix::{Ix, SpawnOptions};
// Re-export RPC types for downstream consumers.
pub use ix_rpc_types;
pub use proc::{Output, Proc};
pub use sandbox::{
    DirEntry, Info, MergeResult, OpResult, Sandbox, SecretEntry, SnapshotBranchInfo, SnapshotInfo,
    SpawnConfig,
};
