use tracing::Instrument as _;

/// A bidirectional console connection to a VM.
///
/// Type alias for the shared streaming connection. `reader` carries VM
/// output, `writer` carries user input. `guard` aborts the background
/// body-forwarding task on drop.
pub type ConsoleConnection = crate::streaming::StreamingConnection;

impl crate::IxClient {
    /// Open a bidirectional console stream to the given VM.
    ///
    /// Uses `POST /api/console?vm_id=...` with Bearer auth. The request body
    /// carries input and the response body carries output. Traffic flows over
    /// QUIC/H3 directly to the ingress gateway.
    ///
    /// Console access requires the canonical HTTPS platform endpoint. Direct
    /// guest console connections are not supported.
    pub async fn console_connect(&self, vm_id: &str) -> crate::error::Result<ConsoleConnection> {
        let activity = "Open console stream".to_owned();

        async move {
            let url = console_stream_url(self.server())?;
            let url = format!("{url}/api/console?vm_id={vm_id}");
            crate::streaming::connect(self.http(), &url, self.token(), "console").await
        }
        .instrument(tracing::info_span!(
            "stream",
            activity = %activity,
            vm_id
        ))
        .await
    }
}

fn console_stream_url(server: &str) -> crate::error::Result<&str> {
    let parsed =
        url::Url::parse(server).map_err(|source| crate::error::SdkError::ConnectionFailed {
            details: format!(
                "\n\n  server: {server}\n\n  error: invalid ix server URL for console transport: \
                 {source}"
            ),
        })?;

    if parsed.scheme() != "https" {
        return Err(crate::error::SdkError::ConnectionFailed {
            details: format!(
                "\n\n  server: {server}\n\n  error: ix shell requires the canonical HTTPS console \
                 endpoint over QUIC/H3"
            ),
        });
    }

    Ok(server)
}

#[cfg(test)]
mod tests {
    #[test]
    fn accepts_https_console_server() {
        let url =
            super::console_stream_url("https://api.ix.dev").expect("https console server accepted");
        assert_eq!(url, "https://api.ix.dev");
    }

    #[test]
    fn rejects_non_https_console_server() {
        let error = super::console_stream_url("http://127.0.0.1:3000")
            .expect_err("http console server rejected");
        let crate::error::SdkError::ConnectionFailed { details } = error else {
            panic!("expected connection failure");
        };
        assert!(
            details.contains("requires the canonical HTTPS console endpoint"),
            "unexpected error details: {details}",
        );
    }

    #[test]
    fn rejects_invalid_console_server_url() {
        let error = super::console_stream_url("not a url").expect_err("invalid URL rejected");
        let crate::error::SdkError::ConnectionFailed { details } = error else {
            panic!("expected connection failure");
        };
        assert!(
            details.contains("invalid ix server URL"),
            "unexpected error details: {details}",
        );
    }
}
