use std::sync::Arc;

use snafu::ResultExt as _;
use tokio::sync::OnceCell;

use crate::{
    client::IxClient,
    error::{self, Result},
};

pub struct SpawnConfig {
    pub id: String,
    pub image: String,
    pub name: Option<String>,
    pub enable_ipv4: Option<bool>,
    pub region: String,
}

pub struct Info {
    pub id: String,
    pub name: String,
    pub image: String,
    pub status: String,
    pub ipv6: String,
    pub ipv4: Option<String>,
    pub subdomain: Option<String>,
    pub started_at: Option<String>,
    pub stopped_at: Option<String>,
    pub failure_reason: Option<String>,
}

pub struct DirEntry {
    pub name: String,
    pub size: f64,
    pub is_dir: bool,
}

pub struct SnapshotInfo {
    pub id: String,
    pub parent_id: Option<String>,
    pub status: String,
    pub memory_mib: u32,
    pub manifest_key: Option<String>,
    pub created_at_millis: i64,
}

pub struct SnapshotBranchInfo {
    pub id: String,
    pub name: String,
    pub tip_id: String,
    pub created_at_millis: i64,
    pub updated_at_millis: i64,
}

pub struct MergeResult {
    pub applied_ops: i32,
    pub conflict_paths: Vec<String>,
}

pub struct SecretEntry {
    pub name: String,
    pub created_at: String,
}

pub use ix_rpc_types::types::exec::OpResult;

fn vm_info_from_rpc(vm: &ix_rpc_types::types::vm::Vm) -> Info {
    Info {
        id: vm.id.to_string(),
        name: vm.name.clone(),
        image: vm.image.clone(),
        status: format!("{:?}", vm.status).to_lowercase(),
        ipv6: vm.ipv6.clone(),
        ipv4: vm.ipv4.clone(),
        subdomain: vm.subdomain.clone(),
        started_at: vm.started_at.map(|ms| ms.to_string()),
        stopped_at: vm.stopped_at.map(|ms| ms.to_string()),
        failure_reason: vm.failure_reason.clone(),
    }
}

fn parse_vm_uuid(id: &str) -> Result<uuid::Uuid> {
    uuid::Uuid::parse_str(id).context(error::ParseUuidSnafu { input: id })
}

pub struct Sandbox {
    client: Arc<IxClient>,
    pre_id: String,
    spawn_config: Option<SpawnConfig>,
    info: OnceCell<Info>,
}

impl Sandbox {
    #[must_use]
    pub fn lazy(client: Arc<IxClient>, config: SpawnConfig) -> Self {
        let pre_id = config.id.clone();
        Self {
            client,
            pre_id,
            spawn_config: Some(config),
            info: OnceCell::const_new(),
        }
    }

    #[must_use]
    pub fn from_info(client: Arc<IxClient>, info: Info) -> Self {
        let pre_id = info.id.clone();
        let cell = OnceCell::const_new();
        drop(cell.set(info));
        Self {
            client,
            pre_id,
            spawn_config: None,
            info: cell,
        }
    }

    async fn ensure_created(&self) -> Result<&Info> {
        self.info
            .get_or_try_init(|| async {
                let config = self.spawn_config.as_ref().ok_or(error::SdkError::NoData)?;
                let req = ix_rpc_types::types::vm::CreateRequest {
                    image: config.image.clone(),
                    name: config.name.clone(),
                    ipv4: config.enable_ipv4,
                    wait_until_ready: true,
                    region: config.region.clone(),
                    disable_golden: false,
                };
                let data = self.client.create_vm(req).await?;
                Ok(vm_info_from_rpc(&data.vm))
            })
            .await
    }

    pub async fn ready(&self) -> Result<&Info> {
        self.ensure_created().await
    }

    pub fn id(&self) -> &str {
        &self.pre_id
    }

    pub fn name(&self) -> Option<&str> {
        self.info.get().map(|i| i.name.as_str())
    }

    pub fn image(&self) -> Option<&str> {
        self.info.get().map(|i| i.image.as_str())
    }

    pub fn status(&self) -> Option<&str> {
        self.info.get().map(|i| i.status.as_str())
    }

    pub fn ipv6(&self) -> Option<&str> {
        self.info.get().map(|i| i.ipv6.as_str())
    }

    pub fn ipv4(&self) -> Option<&str> {
        self.info.get().and_then(|i| i.ipv4.as_deref())
    }

    pub fn subdomain(&self) -> Option<&str> {
        self.info.get().and_then(|i| i.subdomain.as_deref())
    }

    pub fn started_at(&self) -> Option<&str> {
        self.info.get().and_then(|i| i.started_at.as_deref())
    }

    pub fn stopped_at(&self) -> Option<&str> {
        self.info.get().and_then(|i| i.stopped_at.as_deref())
    }

    pub fn failure_reason(&self) -> Option<&str> {
        self.info.get().and_then(|i| i.failure_reason.as_deref())
    }

    pub async fn stop(&self) -> Result<()> {
        let info = self.ensure_created().await?;
        self.client.stop_vm(parse_vm_uuid(&info.id)?).await?;
        Ok(())
    }

    pub async fn start(&self) -> Result<()> {
        let info = self.ensure_created().await?;
        self.client.start_vm(parse_vm_uuid(&info.id)?).await?;
        Ok(())
    }

    pub async fn restart(&self) -> Result<()> {
        let info = self.ensure_created().await?;
        self.client.restart_vm(parse_vm_uuid(&info.id)?).await?;
        Ok(())
    }

    pub async fn delete(&self) -> Result<()> {
        if let Some(info) = self.info.get() {
            self.client.delete_vm(parse_vm_uuid(&info.id)?).await?;
        }
        Ok(())
    }

    pub async fn exec(
        &self,
        command: Vec<String>,
        working_dir: Option<String>,
    ) -> Result<OpResult> {
        let info = self.ensure_created().await?;
        let req = ix_rpc_types::types::exec::VmRequest {
            vm_id: parse_vm_uuid(&info.id)?,
            command,
            working_dir,
        };
        self.client.exec_vm(req).await
    }

    pub async fn write_file(&self, path: String, content: String) -> Result<()> {
        let info = self.ensure_created().await?;
        let req = ix_rpc_types::types::fs::VmFsWriteRequest {
            vm_id: parse_vm_uuid(&info.id)?,
            path,
            text: content,
            mode: None,
        };
        self.client.vm_fs_write(req).await?;
        Ok(())
    }

    pub async fn read_file(&self, path: String) -> Result<String> {
        let info = self.ensure_created().await?;
        let req = ix_rpc_types::types::fs::VmFsReadRequest {
            vm_id: parse_vm_uuid(&info.id)?,
            path,
        };
        let data = self.client.vm_fs_read(req).await?;
        Ok(data.text)
    }

    pub async fn list_dir(&self, path: String) -> Result<Vec<DirEntry>> {
        let info = self.ensure_created().await?;
        let req = ix_rpc_types::types::fs::VmFsListRequest {
            vm_id: parse_vm_uuid(&info.id)?,
            path,
        };
        let data = self.client.vm_fs_list(req).await?;
        Ok(data
            .entries
            .iter()
            .map(|e| DirEntry {
                name: e.name.clone(),
                size: e.size as f64,
                is_dir: e.is_dir,
            })
            .collect())
    }

    pub async fn snapshots(&self) -> Result<Vec<SnapshotInfo>> {
        let info = self.ensure_created().await?;
        let data = self
            .client
            .list_vm_snapshots(parse_vm_uuid(&info.id)?)
            .await?;
        Ok(data
            .snapshots
            .iter()
            .map(|snapshot| SnapshotInfo {
                id: snapshot.id.to_string(),
                parent_id: snapshot.parent_id.map(|id| id.to_string()),
                status: snapshot.status.as_str().to_owned(),
                memory_mib: snapshot.memory_mib,
                manifest_key: snapshot.manifest_key.clone(),
                created_at_millis: snapshot.created_at_millis,
            })
            .collect())
    }

    pub async fn fork(&self, name: Option<String>) -> Result<Self> {
        let info = self.ensure_created().await?;
        let req = ix_rpc_types::types::vcs::ForkVmRequest {
            snapshot_id: parse_vm_uuid(&info.id)?,
            name,
            wait_until_ready: true,
        };
        let data = self.client.fork_vm(req).await?;
        Ok(Self::from_info(
            Arc::clone(&self.client),
            vm_info_from_rpc(&data.vm),
        ))
    }

    pub async fn merge(&self, source: &Self) -> Result<MergeResult> {
        let info = self.ensure_created().await?;
        let source_info = source.ensure_created().await?;
        let req = ix_rpc_types::types::vcs::MergeVmRequest {
            target_vm_id: parse_vm_uuid(&info.id)?,
            source_vm_id: parse_vm_uuid(&source_info.id)?,
            resolution_strategy: None,
        };
        let data = self.client.merge_vm(req).await?;
        Ok(MergeResult {
            #[expect(
                clippy::cast_possible_wrap,
                reason = "merge applied_ops count will never exceed i32::MAX"
            )]
            applied_ops: data.applied_ops as i32,
            conflict_paths: data.conflict_paths,
        })
    }

    pub async fn set_secret(&self, key: String, value: String) -> Result<()> {
        let info = self.ensure_created().await?;
        self.client
            .set_vm_secret(parse_vm_uuid(&info.id)?, key, value)
            .await?;
        Ok(())
    }

    pub async fn delete_secret(&self, key: String) -> Result<()> {
        let info = self.ensure_created().await?;
        self.client
            .delete_vm_secret(parse_vm_uuid(&info.id)?, key)
            .await?;
        Ok(())
    }

    pub async fn secrets(&self) -> Result<Vec<SecretEntry>> {
        let info = self.ensure_created().await?;
        let data = self
            .client
            .list_vm_secrets(parse_vm_uuid(&info.id)?)
            .await?;
        Ok(data
            .secrets
            .iter()
            .map(|s| SecretEntry {
                name: s.name.clone(),
                created_at: s.created_at.to_string(),
            })
            .collect())
    }
}
