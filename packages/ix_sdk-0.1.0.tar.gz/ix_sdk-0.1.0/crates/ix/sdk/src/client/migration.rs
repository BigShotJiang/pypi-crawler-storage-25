use ix_rpc_types::types::migration;

use crate::{client::IxClient, error::Result};

impl IxClient {
    pub async fn migrate_vm(&self, req: migration::VmRequest) -> Result<migration::VmResponse> {
        self.rpc("migrate_vm", &req).await
    }

    pub async fn cancel_migration(
        &self,
        migration_id: uuid::Uuid,
    ) -> Result<ix_rpc_types::types::BoolResponse> {
        self.rpc("cancel_migration", &migration::CancelRequest {
            migration_id,
        })
        .await
    }

    pub async fn vm_migration(&self, vm_id: uuid::Uuid) -> Result<migration::MaybeVmResponse> {
        self.rpc("get_vm_migration", &ix_rpc_types::types::vm::IdRequest {
            vm_id,
        })
        .await
    }
}
