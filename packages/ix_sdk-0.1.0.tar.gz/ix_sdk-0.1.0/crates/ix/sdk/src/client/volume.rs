use ix_rpc_types::types::volume;

use crate::{client::IxClient, error::Result};

impl IxClient {
    pub async fn list_volumes(&self) -> Result<volume::ListResponse> {
        self.rpc("list_volumes", &ix_rpc_types::types::Empty).await
    }

    pub async fn get_volume(&self, volume_id: uuid::Uuid) -> Result<volume::Response> {
        self.rpc("get_volume", &volume::IdRequest { volume_id })
            .await
    }

    pub async fn create_volume(&self, req: volume::CreateRequest) -> Result<volume::Response> {
        self.rpc("create_volume", &req).await
    }

    pub async fn delete_volume(
        &self,
        volume_id: uuid::Uuid,
    ) -> Result<ix_rpc_types::types::BoolResponse> {
        self.rpc("delete_volume", &volume::IdRequest { volume_id })
            .await
    }

    pub async fn volume_snapshots(
        &self,
        volume_id: uuid::Uuid,
    ) -> Result<volume::ListSnapshotsResponse> {
        self.rpc("list_volume_snapshots", &volume::IdRequest { volume_id })
            .await
    }

    pub async fn create_snapshot(
        &self,
        req: volume::CreateSnapshotRequest,
    ) -> Result<volume::Snapshot> {
        self.rpc("create_volume_snapshot", &req).await
    }

    pub async fn restore_to_snapshot(&self, snapshot_id: uuid::Uuid) -> Result<volume::Response> {
        self.rpc("restore_to_snapshot", &volume::RestoreToSnapshotRequest {
            snapshot_id,
        })
        .await
    }

    pub async fn fork_volume(&self, req: volume::ForkRequest) -> Result<volume::Response> {
        self.rpc("fork_volume", &req).await
    }
}
