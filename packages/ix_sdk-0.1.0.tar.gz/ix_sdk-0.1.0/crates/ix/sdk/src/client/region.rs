use ix_rpc_types::types::region;

use crate::{client::IxClient, error::Result};

impl IxClient {
    pub async fn list_regions(&self) -> Result<region::ListRegionsResponse> {
        self.rpc("list_regions", &ix_rpc_types::types::Empty).await
    }
}
