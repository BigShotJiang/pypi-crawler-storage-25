use ix_rpc_types::types::preview;

use crate::{client::IxClient, error::Result};

impl IxClient {
    pub async fn create_preview(&self, req: preview::CreateRequest) -> Result<preview::Detail> {
        self.rpc("create_preview", &req).await
    }

    pub async fn stop_preview(
        &self,
        preview_id: uuid::Uuid,
    ) -> Result<ix_rpc_types::types::BoolResponse> {
        self.rpc("stop_preview", &preview::IdRequest { preview_id })
            .await
    }

    pub async fn list_previews(&self) -> Result<preview::ListResponse> {
        self.rpc("list_previews", &ix_rpc_types::types::Empty).await
    }

    pub async fn preview_status(&self, preview_id: uuid::Uuid) -> Result<preview::Detail> {
        self.rpc("get_preview", &preview::IdRequest { preview_id })
            .await
    }

    pub async fn promote_preview(
        &self,
        preview_id: uuid::Uuid,
    ) -> Result<ix_rpc_types::types::BoolResponse> {
        self.rpc("promote_preview", &preview::IdRequest { preview_id })
            .await
    }
}
