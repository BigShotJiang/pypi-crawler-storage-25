use ix_rpc_types::types::{auth, billing};

use crate::{client::IxClient, error::Result};

impl IxClient {
    pub async fn me(&self) -> Result<auth::MeResponse> {
        self.rpc("me", &ix_rpc_types::types::Empty).await
    }

    pub async fn billing_status(&self) -> Result<billing::Status> {
        self.rpc("billing_status", &ix_rpc_types::types::Empty)
            .await
    }

    pub async fn create_api_token(
        &self,
        req: billing::CreateRequest,
    ) -> Result<billing::CreateResponse> {
        self.rpc("create_api_token", &req).await
    }

    pub async fn list_api_tokens(&self) -> Result<billing::ListResponse> {
        self.rpc("list_api_tokens", &ix_rpc_types::types::Empty)
            .await
    }

    pub async fn revoke_api_token(
        &self,
        req: billing::RevokeRequest,
    ) -> Result<ix_rpc_types::types::BoolResponse> {
        self.rpc("revoke_api_token", &req).await
    }

    pub async fn usage_events(
        &self,
        req: billing::UsageEventsRequest,
    ) -> Result<billing::UsageEventsResponse> {
        self.rpc("usage_events", &req).await
    }

    pub async fn create_checkout_session(
        &self,
        req: billing::CreateCheckoutSessionRequest,
    ) -> Result<billing::CheckoutSession> {
        self.rpc("create_checkout_session", &req).await
    }
}
