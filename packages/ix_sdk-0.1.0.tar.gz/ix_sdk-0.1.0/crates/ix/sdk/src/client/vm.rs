use ix_rpc_types::types::{exec, fs, snapshot, vcs, vm};

use crate::{client::IxClient, error::Result};

const VM_READY_POLL_INTERVAL: std::time::Duration = std::time::Duration::from_secs(1);
const VM_READY_TIMEOUT_SECS: u64 = 600;

impl IxClient {
    pub async fn get_vm(&self, id: uuid::Uuid) -> Result<vm::GetResponse> {
        self.rpc("get_vm", &vm::GetRequest { id }).await
    }

    pub async fn get_vm_by_name(&self, name: String) -> Result<vm::GetResponse> {
        self.rpc("get_vm_by_name", &vm::GetByNameRequest { name })
            .await
    }

    pub async fn list_vms(&self, status: Option<vm::Status>) -> Result<vm::ListResponse> {
        self.rpc("list_vms", &vm::ListRequest { status, all: false })
            .await
    }

    pub async fn create_vm(&self, req: vm::CreateRequest) -> Result<vm::CreateResponse> {
        let wait = req.wait_until_ready;
        let mut resp: vm::CreateResponse = self.rpc("create_vm", &req).await?;
        if wait {
            resp.vm = self.poll_vm_ready(resp.vm.id).await?;
        }
        Ok(resp)
    }

    async fn poll_vm_ready(&self, vm_id: uuid::Uuid) -> Result<vm::Vm> {
        let deadline =
            std::time::Instant::now() + std::time::Duration::from_secs(VM_READY_TIMEOUT_SECS);
        loop {
            if std::time::Instant::now() > deadline {
                return Err(crate::error::SdkError::VmReadyTimeout {
                    vm_id,
                    timeout_secs: VM_READY_TIMEOUT_SECS,
                });
            }
            tokio::time::sleep(VM_READY_POLL_INTERVAL).await;
            let Some(vm) = self.get_vm(vm_id).await?.vm else {
                return Err(crate::error::SdkError::VmNotFound {
                    identifier: vm_id.to_string(),
                });
            };
            match vm.status {
                vm::Status::Running => return Ok(vm),
                vm::Status::Failed => {
                    return Err(crate::error::SdkError::VmStartFailed {
                        vm_id,
                        reason: vm.failure_reason.unwrap_or_default(),
                    });
                }
                _ => continue,
            }
        }
    }

    pub async fn start_vm(&self, vm_id: uuid::Uuid) -> Result<vm::Response> {
        self.rpc("start_vm", &vm::IdRequest { vm_id }).await
    }

    pub async fn stop_vm(&self, vm_id: uuid::Uuid) -> Result<vm::Response> {
        self.rpc("stop_vm", &vm::IdRequest { vm_id }).await
    }

    pub async fn restart_vm(&self, vm_id: uuid::Uuid) -> Result<vm::Response> {
        self.rpc("restart_vm", &vm::IdRequest { vm_id }).await
    }

    pub async fn delete_vm(&self, vm_id: uuid::Uuid) -> Result<ix_rpc_types::types::BoolResponse> {
        self.rpc("delete_vm", &vm::IdRequest { vm_id }).await
    }

    pub async fn snapshot_vm(&self, vm_id: uuid::Uuid) -> Result<vm::Response> {
        self.rpc("snapshot_vm", &vm::IdRequest { vm_id }).await
    }

    pub async fn vm_attach_info(&self, vm_id: uuid::Uuid) -> Result<vm::InfoResponse> {
        self.rpc("vm_attach_info", &vm::InfoRequest { vm_id }).await
    }

    pub async fn vm_logs(&self, req: vm::LogsRequest) -> Result<vm::LogsResponse> {
        self.rpc("vm_logs", &req).await
    }

    pub async fn vm_metrics(&self, vm_id: uuid::Uuid) -> Result<vm::MetricsResponse> {
        self.rpc("vm_metrics", &vm::MetricsRequest { vm_id }).await
    }

    pub async fn list_vm_secrets(&self, vm_id: uuid::Uuid) -> Result<vm::ListSecretsResponse> {
        self.rpc(
            "list_vm_secrets",
            &ix_rpc_types::types::ListKeyValuesRequest { resource_id: vm_id },
        )
        .await
    }

    pub async fn set_vm_secret(
        &self,
        vm_id: uuid::Uuid,
        key: String,
        value: String,
    ) -> Result<ix_rpc_types::types::BoolResponse> {
        self.rpc("set_vm_secret", &ix_rpc_types::types::SetKeyValueRequest {
            resource_id: vm_id,
            key,
            value,
        })
        .await
    }

    pub async fn delete_vm_secret(
        &self,
        vm_id: uuid::Uuid,
        key: String,
    ) -> Result<ix_rpc_types::types::BoolResponse> {
        self.rpc(
            "delete_vm_secret",
            &ix_rpc_types::types::DeleteKeyValueRequest {
                resource_id: vm_id,
                key,
            },
        )
        .await
    }

    pub async fn set_vm_env(
        &self,
        vm_id: uuid::Uuid,
        key: String,
        value: String,
    ) -> Result<ix_rpc_types::types::BoolResponse> {
        self.rpc("set_vm_env", &ix_rpc_types::types::SetKeyValueRequest {
            resource_id: vm_id,
            key,
            value,
        })
        .await
    }

    pub async fn vm_env_vars(
        &self,
        vm_id: uuid::Uuid,
    ) -> Result<ix_rpc_types::types::ListKeyValuesResponse> {
        self.rpc(
            "list_vm_env_vars",
            &ix_rpc_types::types::ListKeyValuesRequest { resource_id: vm_id },
        )
        .await
    }

    pub async fn delete_vm_env(
        &self,
        vm_id: uuid::Uuid,
        key: String,
    ) -> Result<ix_rpc_types::types::BoolResponse> {
        self.rpc(
            "delete_vm_env",
            &ix_rpc_types::types::DeleteKeyValueRequest {
                resource_id: vm_id,
                key,
            },
        )
        .await
    }

    pub async fn fork_vm(&self, req: vcs::ForkVmRequest) -> Result<vcs::ForkVmResponse> {
        let wait = req.wait_until_ready;
        let mut resp: vcs::ForkVmResponse = self.rpc("fork_vm", &req).await?;
        if wait {
            resp.vm = self.poll_vm_ready(resp.vm.id).await?;
        }
        Ok(resp)
    }

    pub async fn merge_vm(&self, req: vcs::MergeVmRequest) -> Result<vcs::MergeVmResponse> {
        self.rpc("merge_vm", &req).await
    }

    pub async fn preview_merge(&self, req: vcs::PreviewMergeRequest) -> Result<vcs::MergePreview> {
        self.rpc("preview_merge", &req).await
    }

    pub async fn exec_vm(&self, req: exec::VmRequest) -> Result<exec::OpResult> {
        self.rpc("exec_vm", &req).await
    }

    pub async fn vm_fs_read(&self, req: fs::VmFsReadRequest) -> Result<fs::VmFsReadResponse> {
        self.rpc("vm_fs_read", &req).await
    }

    pub async fn vm_fs_write(&self, req: fs::VmFsWriteRequest) -> Result<fs::VmFsWriteResponse> {
        self.rpc("vm_fs_write", &req).await
    }

    pub async fn vm_fs_list(&self, req: fs::VmFsListRequest) -> Result<fs::VmFsListResponse> {
        self.rpc("vm_fs_list", &req).await
    }

    pub async fn list_vm_snapshots(&self, vm_id: uuid::Uuid) -> Result<snapshot::ListVmResponse> {
        self.rpc("list_vm_snapshots", &vm::IdRequest { vm_id })
            .await
    }
}
