//! Unauthenticated CLI login flow.
//!
//! These functions do not require an existing API token — they initiate
//! the browser-based login handshake and poll for completion.

use ix_api_types::auth::{CliLoginPollResponse, CliLoginStatus, StartCliLoginResponse};
use snafu::{ResultExt as _, Snafu};

#[derive(Debug, Snafu)]
#[snafu(visibility(pub(crate)))]
pub enum AuthError {
    #[snafu(display("failed to build HTTP client"))]
    BuildHttpClient { source: reqwest::Error },

    #[snafu(display("failed to start CLI login"))]
    StartLogin { source: reqwest::Error },

    #[snafu(display("server returned HTTP {status} for CLI login start"))]
    StartLoginStatus {
        status: reqwest::StatusCode,
        body: String,
    },

    #[snafu(display("failed to parse CLI login start response"))]
    ParseStartResponse { source: reqwest::Error },

    #[snafu(display("failed to poll CLI login status"))]
    PollLogin { source: reqwest::Error },

    #[snafu(display("server returned HTTP {status} for CLI login poll"))]
    PollLoginStatus {
        status: reqwest::StatusCode,
        body: String,
    },

    #[snafu(display("failed to parse CLI login poll response"))]
    ParsePollResponse { source: reqwest::Error },
}

/// Start a CLI login session.
///
/// Calls `POST /api/auth/cli/start` on the given server and returns
/// the one-time token + browser URL.
pub async fn start_cli_login(
    http: &reqwest::Client,
    server: &str,
) -> Result<StartCliLoginResponse, AuthError> {
    let url = format!("{server}/api/auth/cli/start");
    let response = http.post(&url).send().await.context(StartLoginSnafu)?;

    let status = response.status();
    if !status.is_success() {
        let body = response.text().await.unwrap_or_default();
        return StartLoginStatusSnafu { status, body }.fail();
    }

    response.json().await.context(ParseStartResponseSnafu)
}

/// Poll the CLI login status.
///
/// Calls `GET /api/auth/cli/status?token=...` and returns the current
/// state. The caller should poll until `status` is `Authenticated` or
/// `Expired`.
pub async fn poll_cli_login(
    http: &reqwest::Client,
    server: &str,
    token: &str,
) -> Result<CliLoginPollResponse, AuthError> {
    let url = format!("{server}/api/auth/cli/status");
    let response = http
        .get(&url)
        .query(&[("token", token)])
        .send()
        .await
        .context(PollLoginSnafu)?;

    let status = response.status();
    if !status.is_success() {
        let body = response.text().await.unwrap_or_default();
        return PollLoginStatusSnafu { status, body }.fail();
    }

    response.json().await.context(ParsePollResponseSnafu)
}

/// Convenience: build an HTTP client suitable for unauthenticated auth calls.
pub fn build_auth_http_client() -> Result<reqwest::Client, AuthError> {
    reqwest::Client::builder()
        .build()
        .context(BuildHttpClientSnafu)
}

/// Outcome of a completed CLI login poll loop.
pub struct LoginResult {
    /// The API token to store in config.
    pub token: String,
    /// The username of the authenticated user.
    pub username: String,
}

/// Poll until the CLI login is authenticated or expired.
///
/// Returns `Ok(Some(result))` on authentication, `Ok(None)` on expiry,
/// or `Err` on network/server errors.
pub async fn poll_until_complete(
    http: &reqwest::Client,
    server: &str,
    cli_token: &str,
    poll_interval: std::time::Duration,
) -> Result<Option<LoginResult>, AuthError> {
    loop {
        tokio::time::sleep(poll_interval).await;

        let response = poll_cli_login(http, server, cli_token).await?;
        match response.status {
            CliLoginStatus::Authenticated => {
                let Some(token) = response.token else {
                    continue;
                };
                let username = response.username.unwrap_or_default();
                return Ok(Some(LoginResult { token, username }));
            }
            CliLoginStatus::Expired => return Ok(None),
            CliLoginStatus::Pending => {}
        }
    }
}
