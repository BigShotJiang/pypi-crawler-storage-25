mod billing;
mod migration;
mod preview;
mod region;
mod vm;
mod volume;

use snafu::ResultExt as _;
use tracing::Instrument as _;

const RPC_WAIT_LOG_INTERVAL: std::time::Duration = std::time::Duration::from_secs(2);
const DEFAULT_RPC_REQUEST_TIMEOUT: std::time::Duration = std::time::Duration::from_secs(30);
static RUSTLS_PROVIDER_INSTALLED: parking_lot::OnceLock<()> = parking_lot::OnceLock::new();

fn parsed_single_frame(body_bytes: &[u8]) -> Option<rpc_wire::frame::ParsedFrame<'_>> {
    let frames = rpc_wire::frame::parse_frames(body_bytes).ok()?;
    if frames.len() != 1 {
        return None;
    }
    frames.into_iter().next()
}

fn framed_rpc_payload(body_bytes: &[u8]) -> &[u8] {
    parsed_single_frame(body_bytes)
        .map(|frame| frame.body)
        .unwrap_or(body_bytes)
}

fn decode_rpc_error_body(body_bytes: &[u8]) -> Option<crate::error::SdkError> {
    let frame = parsed_single_frame(body_bytes)?;
    if frame.header.flags != rpc_wire::frame::flags::ERROR {
        return None;
    }
    rpc_wire::decode::<ix_rpc_types::error::Error>(frame.body)
        .ok()
        .map(translate_rpc_error)
}

fn decode_rpc_response<Resp>(method: &str, body_bytes: &[u8]) -> crate::error::Result<Resp>
where
    for<'a> Resp: minicbor::Decode<'a, ()>,
{
    if let Some(rpc_err) = decode_rpc_error_body(body_bytes) {
        return Err(rpc_err);
    }

    let payload = framed_rpc_payload(body_bytes);
    rpc_wire::decode(payload).map_err(|source| crate::error::SdkError::DeserializeResponse {
        method: method.to_owned(),
        source,
    })
}

pub struct IxClient {
    server: String,
    token: String,
    admin: bool,
    debug: bool,
    /// HTTP client (H3/QUIC for HTTPS endpoints, plain HTTP/1.1 for HTTP).
    http: reqwest::Client,
    transport_preflight_logged: std::sync::atomic::AtomicBool,
}

impl IxClient {
    /// Create a new SDK client.
    ///
    /// For HTTPS endpoints, creates an H3 (QUIC) client. QUIC is required —
    /// no TCP fallback.
    pub fn new(server: impl Into<String>, token: impl Into<String>) -> crate::error::Result<Self> {
        ensure_rustls_provider();
        let server = server.into();
        let parsed = url::Url::parse(&server);
        let is_https = parsed.as_ref().is_ok_and(|u| u.scheme() == "https");

        let http = if is_https {
            reqwest::Client::builder()
                .http3_prior_knowledge()
                .tls_early_data(true)
                .http3_max_idle_timeout(std::time::Duration::from_mins(10))
                .http3_keep_alive_interval(std::time::Duration::from_secs(15))
                // api.ix.dev is intentionally terminated by nginx; its current
                // H3 stack resets reqwest/h3 GREASE traffic with
                // H3_INTERNAL_ERROR, so disable GREASE for ix RPC.
                .http3_send_grease(false)
                .build()
                .context(crate::error::BuildHttpClientSnafu)?
        } else {
            reqwest::Client::builder()
                .build()
                .context(crate::error::BuildHttpClientSnafu)?
        };

        Ok(Self {
            server,
            token: token.into(),
            admin: false,
            debug: false,
            http,
            transport_preflight_logged: std::sync::atomic::AtomicBool::new(false),
        })
    }

    #[must_use]
    pub fn with_admin(mut self, admin: bool) -> Self {
        self.admin = admin;
        self
    }

    /// Ask the server to return structured internal RPC debug details.
    ///
    /// The server only honors this for authorized callers such as platform
    /// admins. Other callers still receive the default redacted public error.
    #[must_use]
    pub fn with_rpc_debug(mut self, debug: bool) -> Self {
        self.debug = debug;
        self
    }

    #[must_use]
    pub fn server(&self) -> &str {
        &self.server
    }

    #[must_use]
    pub fn token(&self) -> &str {
        &self.token
    }

    #[must_use]
    pub fn http(&self) -> &reqwest::Client {
        &self.http
    }

    pub(crate) async fn rpc<Req, Resp>(&self, method: &str, req: &Req) -> crate::error::Result<Resp>
    where
        Req: minicbor::Encode<()> + Sync,
        for<'a> Resp: minicbor::Decode<'a, ()>,
    {
        self.rpc_inner(method, req, true).await
    }

    pub(crate) async fn rpc_op<O: rpc_wire::Op>(
        &self,
        req: &O::Req,
    ) -> crate::error::Result<O::Resp>
    where
        O::Req: Sync,
    {
        self.rpc_inner(O::METHOD, req, true).await
    }

    async fn rpc_inner<Req, Resp>(
        &self,
        method: &str,
        req: &Req,
        show_activity: bool,
    ) -> crate::error::Result<Resp>
    where
        Req: minicbor::Encode<()> + Sync,
        for<'a> Resp: minicbor::Decode<'a, ()>,
    {
        let activity_name = ix_rpc_types::ops::activity_name(method);
        let activity = format!("RPC {activity_name}");

        async move {
            let frame = rpc_wire::frame::request(method, req).map_err(|source| {
                crate::error::SdkError::SerializeRequest {
                    method: method.to_owned(),
                    source,
                }
            })?;

            let url = format!("{}/rpc", self.server());
            let idempotency_key = rpc_idempotency_key();
            let request_timeout = rpc_request_timeout(method);
            let admin = self.admin;
            let debug = self.debug;
            let response = if show_activity {
                wait_with_activity(
                    self.send_rpc_request(
                        &url,
                        frame,
                        idempotency_key,
                        request_timeout,
                        true,
                        admin,
                        debug,
                    ),
                    format!("Waiting for {activity_name}"),
                )
                .await?
            } else {
                self.send_rpc_request(
                    &url,
                    frame,
                    idempotency_key,
                    request_timeout,
                    false,
                    admin,
                    debug,
                )
                .await?
            };

            let status = response.status();
            if status == reqwest::StatusCode::PAYMENT_REQUIRED {
                return Err(crate::error::SdkError::PaymentRequired);
            }
            if status == reqwest::StatusCode::UNAUTHORIZED {
                let body_bytes = response.bytes().await.unwrap_or_default();
                if let Some(crate::error::SdkError::Error {
                    error: ix_rpc_types::error::Error::Unauthorized { message },
                }) = decode_rpc_error_body(&body_bytes)
                {
                    return Err(crate::error::SdkError::Unauthorized { body: message });
                }

                let body = String::from_utf8_lossy(&body_bytes).into_owned();
                return Err(crate::error::SdkError::Unauthorized { body });
            }
            if !status.is_success() {
                let body_bytes = response.bytes().await.unwrap_or_default();
                if let Some(rpc_err) = decode_rpc_error_body(&body_bytes) {
                    return Err(rpc_err);
                }
                let body = String::from_utf8_lossy(&body_bytes).into_owned();
                return Err(crate::error::SdkError::StatusSnafu { status, body });
            }

            let body_bytes = response
                .bytes()
                .await
                .context(crate::error::ParseResponseSnafu)?;

            decode_rpc_response(method, &body_bytes)
        }
        .instrument(if show_activity {
            tracing::info_span!("rpc", activity = %activity, method = %method)
        } else {
            tracing::debug_span!("rpc", method = %method)
        })
        .await
    }

    /// Send an RPC request over QUIC.
    async fn send_rpc_request(
        &self,
        url: &str,
        frame: Vec<u8>,
        idempotency_key: Option<uuid::Uuid>,
        request_timeout: std::time::Duration,
        show_activity: bool,
        admin: bool,
        debug: bool,
    ) -> crate::error::Result<reqwest::Response> {
        if show_activity {
            self.maybe_log_transport_preflight(url).await;
        }
        let HostPort { host, port } = extract_host_port(url);
        if show_activity {
            tracing::info!(activity = %format!("Sending request over QUIC to {host}:{port}"));
        } else {
            tracing::debug!("sending request over QUIC");
        }

        match send_rpc_attempt(
            &self.http,
            url,
            &self.token,
            frame,
            idempotency_key,
            request_timeout,
            admin,
            debug,
        )
        .await
        {
            Ok(resp) => {
                if show_activity {
                    log_transport_success("QUIC", resp.remote_addr());
                }
                Ok(resp)
            }
            Err(RpcSendError::Request(err)) => {
                if is_connection_error(&err) {
                    Err(build_connection_diagnostic(url, &err).await)
                } else {
                    Err(build_request_failure_diagnostic(url, err))
                }
            }
            Err(RpcSendError::Timeout) => Err(build_timeout_diagnostic(url, request_timeout)),
        }
    }

    async fn maybe_log_transport_preflight(&self, url: &str) {
        if self
            .transport_preflight_logged
            .compare_exchange(
                false,
                true,
                std::sync::atomic::Ordering::AcqRel,
                std::sync::atomic::Ordering::Acquire,
            )
            .is_err()
        {
            return;
        }

        let HostPort { host, port } = extract_host_port(url);

        if let Some(addr) = resolve_ip_literal(&host, port) {
            tracing::info!(activity = %format!("Server is IP literal {addr}"));
            return;
        }

        tracing::info!(activity = %format!("Resolving {host}"));

        match tokio::net::lookup_host(format!("{host}:{port}")).await {
            Ok(addrs) => {
                let resolved: Vec<_> = addrs.collect();
                if resolved.is_empty() {
                    tracing::warn!(activity = %format!("Resolved {host} to 0 addresses"));
                    return;
                }
                tracing::info!(
                    activity = %format!("Resolved {host} to {}", summarize_addrs(&resolved)),
                );
            }
            Err(error) => {
                tracing::warn!(
                    activity = %format!("DNS lookup failed for {host}"),
                    error = ?error,
                );
            }
        }
    }
}

impl rpc_wire::RpcTransport for IxClient {
    type Error = crate::error::SdkError;

    async fn call<R: rpc_wire::RpcRequest>(
        &self,
        req: &R,
    ) -> crate::error::Result<<<R as rpc_wire::RpcRequest>::Op as rpc_wire::Op>::Resp> {
        self.rpc_op::<<R as rpc_wire::RpcRequest>::Op>(req).await
    }
}

fn ensure_rustls_provider() {
    RUSTLS_PROVIDER_INSTALLED.get_or_init(|| {
        rustls::crypto::ring::default_provider()
            .install_default()
            .ok();
    });
}

async fn wait_with_activity<T>(
    future: impl std::future::Future<Output = T>,
    waiting_for: String,
) -> T {
    let started_at = tokio::time::Instant::now();
    tokio::pin!(future);

    loop {
        let sleep = tokio::time::sleep(RPC_WAIT_LOG_INTERVAL);
        tokio::pin!(sleep);

        tokio::select! {
            result = &mut future => return result,
            () = &mut sleep => {
                tracing::info!(
                    activity = %format!("{waiting_for} ({})", format_elapsed(started_at.elapsed())),
                );
            }
        }
    }
}

fn format_elapsed(elapsed: std::time::Duration) -> String {
    let millis = elapsed.as_millis();
    if millis < 1000 {
        format!("{millis}ms")
    } else {
        format!("{:.1}s", millis as f64 / 1000.0)
    }
}

enum RpcSendError {
    Timeout,
    Request(reqwest::Error),
}

async fn send_rpc_attempt(
    client: &reqwest::Client,
    url: &str,
    token: &str,
    frame: Vec<u8>,
    idempotency_key: Option<uuid::Uuid>,
    request_timeout: std::time::Duration,
    admin: bool,
    debug: bool,
) -> std::result::Result<reqwest::Response, RpcSendError> {
    let mut trace_headers = reqwest::header::HeaderMap::new();
    let request_id = ix_tracing::ensure_http_request_id(&mut trace_headers);
    ix_tracing::inject_current_context_into_http_headers(&mut trace_headers);

    let mut request = client
        .post(url)
        .header("Authorization", format!("Bearer {token}"))
        .header("Content-Type", "application/x-ix-rpc")
        .header("Accept", "application/json, text/event-stream")
        .headers(trace_headers);
    if admin {
        request = request.header("x-ix-admin", "true");
    }
    if debug {
        request = request.header("x-ix-debug", "true");
    }
    if let Some(idempotency_key) = idempotency_key {
        request = request.header("idempotency-key", idempotency_key.to_string());
    }

    let send_result = tokio::time::timeout(request_timeout, request.body(frame).send()).await;

    tracing::debug!(request_id = %request_id, "sent ix RPC request");

    match send_result {
        Ok(Ok(response)) => Ok(response),
        Ok(Err(source)) => Err(RpcSendError::Request(source)),
        Err(_) => Err(RpcSendError::Timeout),
    }
}

fn rpc_idempotency_key() -> Option<uuid::Uuid> {
    Some(uuid::Uuid::now_v7())
}

fn is_connection_error(err: &reqwest::Error) -> bool {
    err.is_connect() || err.is_timeout()
}

fn build_timeout_diagnostic(
    url: &str,
    request_timeout: std::time::Duration,
) -> crate::error::SdkError {
    let mut lines = vec![
        String::new(),
        format!("  server: {url}"),
        String::new(),
        "  timed out waiting for RPC response".to_owned(),
        format!("  request timeout: {}s", request_timeout.as_secs()),
    ];
    if let Some(hint) = timeout_hint_for_request_timeout(request_timeout) {
        lines.push(String::new());
        lines.push(format!("  hint: {hint}"));
    }

    crate::error::SdkError::ConnectionFailed {
        details: format!("\n{}", lines.join("\n")),
    }
}

fn rpc_request_timeout(_method: &str) -> std::time::Duration {
    DEFAULT_RPC_REQUEST_TIMEOUT
}

fn timeout_hint_for_request_timeout(_request_timeout: std::time::Duration) -> Option<&'static str> {
    None
}

struct HostPort {
    host: String,
    port: u16,
}

fn extract_host_port(url: &str) -> HostPort {
    match url::Url::parse(url) {
        Ok(parsed) => {
            let host = parsed
                .host_str()
                .map(ToOwned::to_owned)
                .unwrap_or_else(|| url.to_owned());
            let default_port = if parsed.scheme() == "https" { 443 } else { 80 };
            let port = parsed.port().unwrap_or(default_port);
            HostPort { host, port }
        }
        Err(_) => HostPort {
            host: url.to_owned(),
            port: 443,
        },
    }
}

fn resolve_ip_literal(host: &str, port: u16) -> Option<std::net::SocketAddr> {
    host.parse::<std::net::IpAddr>()
        .ok()
        .map(|ip| std::net::SocketAddr::new(ip, port))
}

fn summarize_addrs(addrs: &[std::net::SocketAddr]) -> String {
    addrs
        .iter()
        .take(4)
        .map(std::string::ToString::to_string)
        .collect::<Vec<_>>()
        .join(", ")
}

fn log_transport_success(transport: &str, remote_addr: Option<std::net::SocketAddr>) {
    match remote_addr {
        Some(remote_addr) => {
            tracing::info!(activity = %format!("Connected over {transport} to {remote_addr}"));
        }
        None => {
            tracing::info!(activity = %format!("Connected over {transport}"));
        }
    }
}

fn translate_rpc_error(rpc_err: ix_rpc_types::error::Error) -> crate::error::SdkError {
    if let ix_rpc_types::error::Error::NotFound {
        resource,
        identifier,
    } = &rpc_err
    {
        match resource.as_str() {
            "vm" => {
                return crate::error::SdkError::VmNotFound {
                    identifier: identifier.clone(),
                };
            }
            "volume" => {
                return crate::error::SdkError::VolumeNotFound {
                    identifier: identifier.clone(),
                };
            }
            "snapshot" => {
                return crate::error::SdkError::SnapshotNotFound {
                    identifier: identifier.clone(),
                };
            }
            "branch" => {
                return crate::error::SdkError::BranchNotFound {
                    identifier: identifier.clone(),
                };
            }
            "commit" => {
                return crate::error::SdkError::CommitNotFound {
                    identifier: identifier.clone(),
                };
            }
            _ => {}
        }
    }
    if let ix_rpc_types::error::Error::CapacityExhausted { message } = rpc_err {
        return crate::error::SdkError::CapacityExhausted { message };
    }
    crate::error::SdkError::Error { error: rpc_err }
}

async fn build_connection_diagnostic(url: &str, err: &reqwest::Error) -> crate::error::SdkError {
    let HostPort { host, port } = extract_host_port(url);
    let mut lines: Vec<String> = Vec::new();

    lines.push(String::new());
    lines.push(format!("  server: {url}"));
    lines.push(format!("  error: {err}"));
    lines.push(String::new());

    if let Some(addr) = resolve_ip_literal(&host, port) {
        let label = if addr.is_ipv4() { "IPv4" } else { "IPv6" };
        lines.push(format!("  address: {label}  {addr}"));
        lines.push(String::new());
        lines.push(format!(
            "  hint: ix requires QUIC (UDP {port}). ensure UDP is not blocked."
        ));

        return crate::error::SdkError::ConnectionFailed {
            details: format!("\n{}", lines.join("\n")),
        };
    }

    match tokio::net::lookup_host(format!("{host}:{port}")).await {
        Ok(addrs) => {
            let addrs: Vec<_> = addrs.collect();
            if addrs.is_empty() {
                lines.push(format!("  dns: {host} resolved to 0 addresses"));
                return crate::error::SdkError::ConnectionFailed {
                    details: format!("\n{}", lines.join("\n")),
                };
            }

            lines.push(format!("  dns: {host} resolves to:"));
            for addr in &addrs {
                let label = if addr.is_ipv4() { "IPv4" } else { "IPv6" };
                lines.push(format!("    {label}  {addr}"));
            }

            lines.push(String::new());
            lines.push(format!(
                "  hint: ix requires QUIC (UDP {port}). ensure UDP is not blocked."
            ));
        }
        Err(dns_err) => {
            lines.push(format!("  dns: FAILED to resolve {host}: {dns_err}"));
            lines.push(String::new());
            lines.push(
                "  DNS resolution failed. check your network connection and DNS settings."
                    .to_owned(),
            );
        }
    }

    crate::error::SdkError::ConnectionFailed {
        details: format!("\n{}", lines.join("\n")),
    }
}

fn build_request_failure_diagnostic(url: &str, source: reqwest::Error) -> crate::error::SdkError {
    crate::error::SdkError::SendRequest {
        details: format_request_failure_details(url, &source),
        source,
    }
}

fn format_request_failure_details(url: &str, err: &(dyn std::error::Error + 'static)) -> String {
    let mut lines = vec![format!("  server: {url}"), format!("  error: {err}")];

    append_error_sources(&mut lines, err);

    if has_remote_http3_reset(err) {
        lines.push(String::new());
        lines.push(
            "  hint: remote HTTP/3 peer reset the request after QUIC connected; this is not a \
             basic UDP reachability failure."
                .to_owned(),
        );
    }

    format!("\n{}", lines.join("\n"))
}

fn append_error_sources(lines: &mut Vec<String>, err: &(dyn std::error::Error + 'static)) {
    let mut current = err.source();
    while let Some(source) = current {
        lines.push(format!("  caused by: {source}"));
        current = source.source();
    }
}

fn has_remote_http3_reset(err: &(dyn std::error::Error + 'static)) -> bool {
    let mut current: Option<&(dyn std::error::Error + 'static)> = Some(err);
    while let Some(source) = current {
        let rendered = source.to_string();
        if rendered.contains("Remote reset:") && rendered.contains("H3_") {
            return true;
        }
        current = source.source();
    }
    false
}

#[cfg(test)]
mod tests {
    #[test]
    fn translates_vm_not_found() {
        let rpc_err = ix_rpc_types::error::Error::NotFound {
            resource: "vm".to_owned(),
            identifier: "abc".to_owned(),
        };
        assert!(matches!(
            super::translate_rpc_error(rpc_err),
            crate::error::SdkError::VmNotFound { identifier } if identifier == "abc"
        ));
    }

    #[test]
    fn unknown_resource_falls_through_to_rpc_error() {
        let rpc_err = ix_rpc_types::error::Error::NotFound {
            resource: "widget".to_owned(),
            identifier: "x".to_owned(),
        };
        assert!(matches!(
            super::translate_rpc_error(rpc_err),
            crate::error::SdkError::Error { .. }
        ));
    }

    #[test]
    fn non_not_found_passes_through() {
        let rpc_err = ix_rpc_types::error::Error::Internal {
            message: "boom".to_owned(),
        };
        assert!(matches!(
            super::translate_rpc_error(rpc_err),
            crate::error::SdkError::Error { .. }
        ));
    }

    #[test]
    fn framed_rpc_payload_skips_valid_header() {
        let frame =
            rpc_wire::frame::response("test", &ix_rpc_types::types::BoolResponse { ok: true })
                .expect("frame");
        let payload = super::framed_rpc_payload(&frame);
        let decoded: ix_rpc_types::types::BoolResponse = rpc_wire::decode(payload).expect("decode");
        assert_eq!(decoded.ok, true);
    }

    #[test]
    fn decode_rpc_error_body_decodes_framed_unauthorized_error() {
        let frame = rpc_wire::frame::error("test", &ix_rpc_types::error::Error::Unauthorized {
            message: "Invalid or expired token".to_owned(),
        })
        .expect("frame");

        assert!(matches!(
            super::decode_rpc_error_body(&frame),
            Some(crate::error::SdkError::Error {
                error: ix_rpc_types::error::Error::Unauthorized { message }
            }) if message == "Invalid or expired token"
        ));
    }

    #[test]
    fn decode_rpc_error_body_rejects_plain_text() {
        assert!(super::decode_rpc_error_body(b"Unauthorized: Invalid or expired token").is_none());
    }

    #[test]
    fn decode_rpc_error_body_ignores_success_frames() {
        let frame =
            rpc_wire::frame::response("test", &ix_rpc_types::types::BoolResponse { ok: true })
                .expect("frame");
        assert!(super::decode_rpc_error_body(&frame).is_none());
    }

    #[test]
    fn decode_rpc_response_returns_rpc_error_for_error_frame() {
        let frame = rpc_wire::frame::error("create_vm", &ix_rpc_types::error::Error::Conflict {
            message: "vm already exists".to_owned(),
        })
        .expect("frame");

        let decoded = super::decode_rpc_response::<ix_rpc_types::types::vm::CreateResponse>(
            "create_vm",
            &frame,
        );

        assert!(matches!(
            decoded,
            Err(crate::error::SdkError::Error {
                error: ix_rpc_types::error::Error::Conflict { message }
            }) if message == "vm already exists"
        ));
    }

    #[derive(Debug)]
    struct TestError {
        message: &'static str,
        source: Option<Box<dyn std::error::Error + Send + Sync>>,
    }

    impl std::fmt::Display for TestError {
        fn fmt(&self, formatter: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
            formatter.write_str(self.message)
        }
    }

    impl std::error::Error for TestError {
        fn source(&self) -> Option<&(dyn std::error::Error + 'static)> {
            self.source
                .as_deref()
                .map(|source| source as &(dyn std::error::Error + 'static))
        }
    }

    #[test]
    fn request_failure_details_include_source_chain_and_h3_hint() {
        let error = TestError {
            message: "error sending request for url (https://api.ix.dev/rpc)",
            source: Some(Box::new(TestError {
                message: "Remote reset: H3_INTERNAL_ERROR",
                source: None,
            })),
        };

        let details = super::format_request_failure_details("https://api.ix.dev/rpc", &error);

        assert_eq!(
            details,
            "\n  server: https://api.ix.dev/rpc\n  error: error sending request for url (https://api.ix.dev/rpc)\n  caused by: Remote reset: H3_INTERNAL_ERROR\n\n  hint: remote HTTP/3 peer reset the request after QUIC connected; this is not a basic UDP reachability failure.",
        );
    }

    #[test]
    fn request_failure_details_omit_h3_hint_for_other_errors() {
        let error = TestError {
            message: "error sending request for url (https://api.ix.dev/rpc)",
            source: Some(Box::new(TestError {
                message: "certificate verify failed",
                source: None,
            })),
        };

        let details = super::format_request_failure_details("https://api.ix.dev/rpc", &error);

        assert_eq!(
            details,
            "\n  server: https://api.ix.dev/rpc\n  error: error sending request for url (https://api.ix.dev/rpc)\n  caused by: certificate verify failed",
        );
    }
}
