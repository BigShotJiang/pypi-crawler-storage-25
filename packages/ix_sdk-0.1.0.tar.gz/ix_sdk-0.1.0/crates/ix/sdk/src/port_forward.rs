use crate::{error::Result, streaming::StreamingConnection};

/// A bidirectional port-forward connection to a VM.
///
/// Type alias for the shared streaming connection. `reader` carries data
/// from the remote VM port, `writer` sends data to it. `guard` aborts
/// the background body-forwarding task on drop.
pub type PortForwardConnection = StreamingConnection;

impl crate::IxClient {
    /// Open a bidirectional TCP tunnel to `remote_port` on the given VM.
    ///
    /// Uses `POST /api/port-forward?vm_id=...&port=...` with Bearer auth.
    /// The request body carries data toward the VM and the response body
    /// carries data back. Traffic flows over QUIC/H3 to the ingress gateway.
    pub async fn port_forward_connect(
        &self,
        vm_id: &str,
        remote_port: u16,
    ) -> Result<PortForwardConnection> {
        let url = format!(
            "{}/api/port-forward?vm_id={vm_id}&port={remote_port}",
            self.server()
        );
        crate::streaming::connect(self.http(), &url, self.token(), "port-forward").await
    }
}
