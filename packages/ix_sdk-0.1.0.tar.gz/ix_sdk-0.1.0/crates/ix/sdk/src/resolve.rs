use crate::{
    client::IxClient,
    error::{self, Result},
};

fn uuid_from_typeid(type_id_str: &str) -> Option<uuid::Uuid> {
    let vm_id: ix_typeid::Id = type_id_str.parse().ok()?;
    Some(vm_id.uuid())
}

async fn query_vm_uuid(client: &IxClient, name: &str) -> Result<uuid::Uuid> {
    let response = client.get_vm_by_name(name.to_owned()).await?;

    if let Some(vm) = response.vm {
        return Ok(vm.id);
    }

    Err(error::SdkError::VmNotFound {
        identifier: name.to_owned(),
    })
}

impl IxClient {
    /// Resolve a VM identifier (name, UUID, or TypeId string) to a TypeId string.
    pub async fn resolve_vm_typeid(&self, vm: &str) -> Result<String> {
        if uuid_from_typeid(vm).is_some() {
            return Ok(vm.to_owned());
        }

        if let Ok(uuid) = uuid::Uuid::parse_str(vm) {
            return Ok(ix_typeid::Id::from_uuid(uuid).to_string());
        }

        let uuid = query_vm_uuid(self, vm).await?;
        Ok(ix_typeid::Id::from_uuid(uuid).to_string())
    }

    /// Resolve a VM identifier (name, UUID, or TypeId string) to a UUID string.
    ///
    /// Accepts VM names, UUIDs, and TypeId strings.
    pub async fn resolve_vm_uuid(&self, vm: &str) -> Result<String> {
        if let Ok(uuid) = uuid::Uuid::parse_str(vm) {
            return Ok(uuid.to_string());
        }

        if let Some(uuid) = uuid_from_typeid(vm) {
            return Ok(uuid.to_string());
        }

        let uuid = query_vm_uuid(self, vm).await?;
        Ok(uuid.to_string())
    }

    /// Resolve a volume identifier (name or ID) to a volume UUID.
    pub async fn resolve_volume_id(&self, volume: &str) -> Result<uuid::Uuid> {
        if let Ok(uuid) = uuid::Uuid::parse_str(volume) {
            let response = self.get_volume(uuid).await?;
            return Ok(response.volume.id);
        }

        let response = self.list_volumes().await?;
        let matching = response
            .volumes
            .into_iter()
            .find(|v| v.name == volume)
            .ok_or_else(|| error::SdkError::VolumeNotFound {
                identifier: volume.to_owned(),
            })?;

        Ok(matching.id)
    }

    /// Resolve a snapshot identifier (name or ID) within a volume.
    pub async fn resolve_snapshot_id(
        &self,
        volume_id: uuid::Uuid,
        snapshot: &str,
    ) -> Result<uuid::Uuid> {
        let response = self.volume_snapshots(volume_id).await?;
        let snapshot_uuid = uuid::Uuid::parse_str(snapshot).ok();
        let matching = response
            .snapshots
            .into_iter()
            .find(|s| s.name == snapshot || snapshot_uuid.is_some_and(|u| s.id == u))
            .ok_or_else(|| error::SdkError::SnapshotNotFound {
                identifier: snapshot.to_owned(),
            })?;

        Ok(matching.id)
    }
}
