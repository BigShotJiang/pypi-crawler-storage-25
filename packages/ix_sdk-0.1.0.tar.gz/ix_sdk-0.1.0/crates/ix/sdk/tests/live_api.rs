//! Integration tests against the live ix API.
//!
//! These tests require a valid API token and network access.
//! Run with: `cargo nextest run -p ix-sdk --test live_api --run-ignored only`
#![expect(
    clippy::disallowed_methods,
    reason = "tokio::test expands to runtime.block_on for async test execution"
)]

use ix_sdk::IxClient;

fn try_client() -> Result<IxClient, Box<dyn std::error::Error>> {
    let resolved = ix_config::resolve(None, None);
    let token = resolved.token.ok_or(
        "no token found in explicit args, env, /etc/ix/config.toml, or ~/.config/ix/config.toml",
    )?;
    Ok(IxClient::new(resolved.server, token)?)
}

// ── Auth / identity ─────────────────────────────────────────────────

#[tokio::test]
#[ignore = "requires live API"]
async fn me_returns_current_user() {
    let c = try_client().expect("failed to create SDK client");
    let resp = c.me().await.expect("me() failed");
    let user = resp.user.expect("me returned None");
    assert!(!user.id.is_nil(), "user id should not be nil");
    assert!(!user.username.is_empty(), "username should not be empty");
    eprintln!("  user: {} ({})", user.username, user.email);
}

// ── Billing ─────────────────────────────────────────────────────────

#[tokio::test]
#[ignore = "requires live API"]
async fn billing_status_succeeds() {
    let c = try_client().expect("failed to create SDK client");
    let billing = c.billing_status().await.expect("billing_status() failed");
    eprintln!("  plan: {}", billing.plan);
    eprintln!("  balance: {}", billing.balance);
}

#[tokio::test]
#[ignore = "requires live API"]
async fn list_api_tokens_returns_vec() {
    let c = try_client().expect("failed to create SDK client");
    let resp = c.list_api_tokens().await.expect("list_api_tokens() failed");
    let tokens = resp.tokens;
    assert!(
        !tokens.is_empty(),
        "should have at least one token (the one we're using)"
    );
    eprintln!("  tokens: {}", tokens.len());
}

// ── VMs ─────────────────────────────────────────────────────────────

#[tokio::test]
#[ignore = "requires live API"]
async fn list_vms() {
    let c = try_client().expect("failed to create SDK client");
    let resp = c.list_vms(None).await.expect("list_vms() failed");
    let vms = resp.vms;
    eprintln!("  vms: {}", vms.len());
    for vm in &vms {
        eprintln!("    {} ({}) — {:?}", vm.name, vm.id, vm.status);
    }
}

// ── Volumes ─────────────────────────────────────────────────────────

#[tokio::test]
#[ignore = "requires live API"]
async fn list_volumes() {
    let c = try_client().expect("failed to create SDK client");
    let resp = c.list_volumes().await.expect("list_volumes() failed");
    let volumes = resp.volumes;
    eprintln!("  volumes: {}", volumes.len());
}

// ── Previews ────────────────────────────────────────────────────────

#[tokio::test]
#[ignore = "requires live API"]
async fn list_previews() {
    let c = try_client().expect("failed to create SDK client");
    match c.list_previews().await {
        Ok(resp) => {
            eprintln!("  previews: {}", resp.previews.len());
        }
        Err(ix_sdk::SdkError::Error { error })
            if format!("{error:?}").contains("orchestrator not available") =>
        {
            eprintln!("  previews skipped: orchestrator not available");
        }
        Err(e) => {
            let message = format!("list_previews() failed unexpectedly: {e:?}");
            assert!(message.is_empty(), "{message}");
        }
    }
}

// ── Auth flow (unauthenticated) ─────────────────────────────────────

#[tokio::test]
#[ignore = "requires live API"]
async fn cli_login_start_returns_url_and_token() {
    let http = ix_sdk::auth::build_auth_http_client().expect("failed to build http client");
    let resp = ix_sdk::auth::start_cli_login(&http, "https://api.ix.dev")
        .await
        .expect("start_cli_login() failed");
    assert!(
        !resp.token.is_empty(),
        "cli login token should not be empty"
    );
    assert!(!resp.url.is_empty(), "cli login url should not be empty");
    assert!(
        resp.url.starts_with("https://"),
        "login url should be https, got: {}",
        resp.url
    );
    eprintln!("  login url: {}", resp.url);
    let preview: String = resp.token.chars().take(8).collect();
    eprintln!("  token: {preview}...");
}

#[tokio::test]
#[ignore = "requires live API"]
async fn cli_login_poll_returns_pending_for_fresh_token() {
    let http = ix_sdk::auth::build_auth_http_client().expect("failed to build http client");
    let start = ix_sdk::auth::start_cli_login(&http, "https://api.ix.dev")
        .await
        .expect("start_cli_login() failed");

    let poll = ix_sdk::auth::poll_cli_login(&http, "https://api.ix.dev", &start.token)
        .await
        .expect("poll_cli_login() failed");

    assert!(
        matches!(poll.status, ix_api_types::auth::CliLoginStatus::Pending),
        "fresh login token should be Pending, got: {:?}",
        poll.status
    );
    eprintln!("  status: {:?}", poll.status);
}
