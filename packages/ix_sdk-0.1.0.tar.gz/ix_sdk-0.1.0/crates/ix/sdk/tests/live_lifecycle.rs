//! End-to-end lifecycle tests against the live ix API.
//!
//! Run with: `cargo nextest run -p ix-sdk --test live_lifecycle --run-ignored only`
#![expect(
    clippy::disallowed_methods,
    reason = "tokio::test expands to runtime.block_on for async test execution"
)]

use ix_rpc_types::types::{exec, vm};
use ix_sdk::IxClient;

fn try_client() -> Result<IxClient, Box<dyn std::error::Error>> {
    let resolved = ix_config::resolve(None, None);
    let token = resolved.token.ok_or(
        "no token found in explicit args, env, /etc/ix/config.toml, or ~/.config/ix/config.toml",
    )?;
    Ok(IxClient::new(resolved.server, token)?)
}

fn unique_name(prefix: &str) -> String {
    let millis = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .unwrap_or_default()
        .as_millis();
    format!("{prefix}-{millis}")
}

async fn live_region(client: &IxClient) -> String {
    client
        .list_regions()
        .await
        .expect("list_regions failed")
        .regions
        .into_iter()
        .next()
        .expect("list_regions returned no regions")
        .slug
}

fn ubuntu_request(name: String, region: String) -> vm::CreateRequest {
    vm::CreateRequest {
        image: "ubuntu:22.04".to_owned(),
        name: Some(name),
        ipv4: Some(false),
        wait_until_ready: true,
        region,
        disable_golden: false,
    }
}

#[tokio::test]
#[ignore = "requires live API"]
async fn exec_ls() {
    let c = try_client().expect("failed to create SDK client");
    let region = live_region(&c).await;

    let name = unique_name("exec-ls");
    let created = c
        .create_vm(ubuntu_request(name, region))
        .await
        .expect("create_vm failed");
    let vm_id = created.vm.id;

    let result = c
        .exec_vm(exec::VmRequest {
            vm_id,
            command: vec!["ls".to_owned(), "/".to_owned()],
            working_dir: None,
        })
        .await
        .expect("exec failed");

    assert_eq!(result.exit_code, 0);
    assert!(result.stdout.contains("etc"));
    assert!(result.stdout.contains("usr"));

    c.delete_vm(vm_id).await.expect("delete failed");
}

#[tokio::test]
#[ignore = "requires live API"]
async fn create_snapshot_delete() {
    let c = try_client().expect("failed to create SDK client");
    let region = live_region(&c).await;

    let name = unique_name("snapshot");
    let created = c
        .create_vm(ubuntu_request(name, region))
        .await
        .expect("create_vm failed");
    let vm_id = created.vm.id;

    c.snapshot_vm(vm_id).await.expect("snapshot failed");

    tokio::time::sleep(std::time::Duration::from_secs(5)).await;

    let snapshots = c
        .list_vm_snapshots(vm_id)
        .await
        .expect("list_vm_snapshots failed");
    assert!(!snapshots.snapshots.is_empty());

    c.delete_vm(vm_id).await.expect("delete failed");
}

#[tokio::test]
#[ignore = "requires live API"]
async fn smoke_create_and_delete() {
    let c = try_client().expect("failed to create SDK client");
    let region = live_region(&c).await;

    let name = unique_name("smoke");
    let created = c
        .create_vm(ubuntu_request(name, region))
        .await
        .expect("create_vm failed");
    assert_eq!(created.vm.status, vm::Status::Running);

    c.delete_vm(created.vm.id).await.expect("delete failed");
}
