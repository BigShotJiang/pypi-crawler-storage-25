//! Live golden-path validation against the ix API.
//!
//! These tests explicitly validate VM create/boot flows that depend on golden
//! snapshot capture and restore.
//!
//! Run with: `cargo nextest run -p ix-sdk --test live_golden --run-ignored only`
#![expect(
    clippy::disallowed_methods,
    reason = "tokio::test expands to runtime.block_on for async test execution"
)]

fn try_client() -> Result<ix_sdk::IxClient, Box<dyn std::error::Error>> {
    let resolved = ix_config::resolve(None, None);
    let token = resolved.token.ok_or(
        "no token found in explicit args, env, /etc/ix/config.toml, or ~/.config/ix/config.toml",
    )?;
    Ok(ix_sdk::IxClient::new(resolved.server, token)?)
}

fn unique_name(prefix: &str) -> String {
    let millis = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .expect("system clock is before UNIX_EPOCH")
        .as_millis();
    format!("{prefix}-{millis}")
}

async fn live_region(client: &ix_sdk::IxClient) -> String {
    client
        .list_regions()
        .await
        .expect("list_regions failed")
        .regions
        .into_iter()
        .next()
        .expect("list_regions returned no regions")
        .slug
}

async fn wait_for_snapshot_ready(
    client: &ix_sdk::IxClient,
    vm_id: uuid::Uuid,
) -> Vec<ix_rpc_types::types::snapshot::Vm> {
    let deadline = std::time::Instant::now() + std::time::Duration::from_secs(30);
    loop {
        let snapshots = client
            .list_vm_snapshots(vm_id)
            .await
            .expect("list_vm_snapshots failed");
        if snapshots
            .snapshots
            .iter()
            .any(|snapshot| snapshot.status == ix_rpc_types::types::snapshot::Status::Ready)
        {
            return snapshots.snapshots;
        }
        assert!(
            std::time::Instant::now() < deadline,
            "snapshot did not become ready within 30s"
        );
        tokio::time::sleep(std::time::Duration::from_millis(250)).await;
    }
}

fn ubuntu_golden_request(name: String, region: String) -> ix_rpc_types::types::vm::CreateRequest {
    ix_rpc_types::types::vm::CreateRequest {
        image: "ubuntu:22.04".to_owned(),
        name: Some(name),
        ipv4: Some(false),
        wait_until_ready: true,
        region,
        disable_golden: false,
    }
}

#[tokio::test]
#[ignore = "requires live API"]
async fn smoke_create_and_delete() {
    let client = try_client().expect("failed to create SDK client");
    let region = live_region(&client).await;

    let created = client
        .create_vm(ubuntu_golden_request(unique_name("golden-smoke"), region))
        .await
        .expect("create_vm failed");
    assert_eq!(created.vm.status, ix_rpc_types::types::vm::Status::Running);

    client
        .delete_vm(created.vm.id)
        .await
        .expect("delete failed");
}

#[tokio::test]
#[ignore = "requires live API"]
async fn exec_ls() {
    let client = try_client().expect("failed to create SDK client");
    let region = live_region(&client).await;

    let created = client
        .create_vm(ubuntu_golden_request(unique_name("golden-exec"), region))
        .await
        .expect("create_vm failed");
    let vm_id = created.vm.id;

    let result = client
        .exec_vm(ix_rpc_types::types::exec::VmRequest {
            vm_id,
            command: vec!["ls".to_owned(), "/".to_owned()],
            working_dir: None,
        })
        .await
        .expect("exec failed");

    assert_eq!(result.exit_code, 0);
    assert!(result.stdout.contains("etc"));
    assert!(result.stdout.contains("usr"));

    client.delete_vm(vm_id).await.expect("delete failed");
}

#[tokio::test]
#[ignore = "requires live API"]
async fn create_snapshot_delete() {
    let client = try_client().expect("failed to create SDK client");
    let region = live_region(&client).await;

    let created = client
        .create_vm(ubuntu_golden_request(
            unique_name("golden-snapshot"),
            region,
        ))
        .await
        .expect("create_vm failed");
    let vm_id = created.vm.id;

    client.snapshot_vm(vm_id).await.expect("snapshot failed");
    let snapshots = wait_for_snapshot_ready(&client, vm_id).await;
    assert_eq!(snapshots.len(), 1);
    assert_eq!(snapshots[0].vm_id, vm_id);
    assert_eq!(
        snapshots[0].status,
        ix_rpc_types::types::snapshot::Status::Ready
    );
    assert!(snapshots[0].manifest_key.is_some());

    client.delete_vm(vm_id).await.expect("delete failed");
}
