#!/bin/bash
#
# Contextual git hooks installer
# Install Contextual git hooks into the current repository
#
# Usage: ./scripts/install-hooks.sh
# Run this from the root of your repository.

set -e

# Check we're in a git repository
if [ ! -d ".git" ]; then
    echo "Error: Not in a git repository (.git directory not found)"
    exit 1
fi

# Verify hook source files exist
if [ ! -f ".git-hooks/post-commit" ]; then
    echo "Error: .git-hooks/post-commit not found"
    exit 1
fi

if [ ! -f ".git-hooks/post-rewrite" ]; then
    echo "Error: .git-hooks/post-rewrite not found"
    exit 1
fi

# Create .git/hooks directory if it doesn't exist
mkdir -p .git/hooks

# Copy hook scripts to .git/hooks
cp .git-hooks/post-commit .git/hooks/post-commit
cp .git-hooks/post-rewrite .git/hooks/post-rewrite

# Make hook scripts executable
chmod +x .git/hooks/post-commit
chmod +x .git/hooks/post-rewrite

echo "✓ Contextual git hooks installed successfully"
echo "  - post-commit: triggers incremental indexing after commits"
echo "  - post-rewrite: triggers full re-indexing after amend/rebase"
