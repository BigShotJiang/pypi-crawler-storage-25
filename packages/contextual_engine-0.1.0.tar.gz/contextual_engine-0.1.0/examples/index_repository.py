"""Example: Index a repository using Phase 1 pipeline.

Demonstrates:
- Full repository indexing
- File watcher with incremental updates
- Query statistics

Usage:
    python examples/index_repository.py /path/to/repo
"""

from __future__ import annotations

import sys
import time
from pathlib import Path

from contextual.indexing.file_watcher import DebouncedFileWatcher
from contextual.indexing.incremental import IncrementalIndexer
from contextual.indexing.pipeline import IndexingPipeline
from contextual.observability.logging import configure_logging, get_logger
from contextual.security import init_workspace
from contextual.storage import SQLitePool, run_migrations

logger = get_logger(__name__)


def main():
    """Main example function."""
    
    # Setup logging
    configure_logging(log_level="INFO", enable_file_logging=True)
    
    # Get repo path from command line
    if len(sys.argv) < 2:
        print("Usage: python examples/index_repository.py /path/to/repo")
        sys.exit(1)
    
    repo_root = Path(sys.argv[1]).resolve()
    
    if not repo_root.is_dir():
        logger.error(f"Not a directory: {repo_root}")
        sys.exit(1)
    
    logger.info(f"Indexing repository: {repo_root}")
    
    # Initialize workspace
    workspace_dir = init_workspace(repo_root)
    logger.info(f"Workspace: {workspace_dir}")
    
    # Initialize database
    db_path = workspace_dir / "contextual.db"
    pool = SQLitePool(db_path)
    
    # Run migrations
    writer_conn = pool.get_writer()
    migrations_applied = run_migrations(writer_conn)
    logger.info(f"Applied {migrations_applied} database migrations")
    
    # Create indexing pipeline
    pipeline = IndexingPipeline(repo_root, pool)
    
    # Check if already indexed
    stats = pipeline.get_stats()
    if stats["files"] > 0:
        logger.info(f"Repository already indexed: {stats}")
        response = input("Re-index from scratch? (y/N): ")
        if response.lower() != 'y':
            logger.info("Using existing index")
        else:
            # Clear existing index
            logger.info("Clearing existing index...")
            writer_conn.execute("DELETE FROM files")
            writer_conn.execute("DELETE FROM chunks")
            writer_conn.execute("DELETE FROM code_symbols")
            writer_conn.execute("DELETE FROM indexing_state")
            writer_conn.commit()
    
    # Perform full indexing
    logger.info("Starting full repository indexing...")
    start_time = time.time()
    
    index_stats = pipeline.index_repository()
    
    duration = time.time() - start_time
    
    logger.info("")
    logger.info("=" * 60)
    logger.info("INDEXING COMPLETE")
    logger.info("=" * 60)
    logger.info(f"Duration: {duration:.2f}s")
    logger.info(f"Files indexed: {index_stats['files']}")
    logger.info(f"Chunks created: {index_stats['chunks']}")
    logger.info(f"Symbols extracted: {index_stats['symbols']}")
    logger.info(f"Embeddings generated: {index_stats['embeddings']}")
    logger.info("=" * 60)
    
    # Ask if user wants to start file watcher
    response = input("\nStart file watcher for incremental updates? (Y/n): ")
    if response.lower() != 'n':
        # Create incremental indexer
        incremental = IncrementalIndexer(pipeline)
        
        # Create and start file watcher
        watcher = DebouncedFileWatcher(
            repo_root=repo_root,
            incremental_indexer=incremental,
            debounce_ms=500,
        )
        
        logger.info("")
        logger.info("Starting file watcher...")
        logger.info("Watching for file changes. Press Ctrl+C to stop.")
        logger.info("")
        
        watcher.start()
        
        try:
            # Keep running until Ctrl+C
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            logger.info("\nStopping file watcher...")
            watcher.stop()
            logger.info("File watcher stopped")
    
    # Show final stats
    final_stats = pipeline.get_stats()
    logger.info("")
    logger.info("=" * 60)
    logger.info("FINAL STATISTICS")
    logger.info("=" * 60)
    logger.info(f"Files: {final_stats['files']}")
    logger.info(f"Chunks: {final_stats['chunks']}")
    logger.info(f"Symbols: {final_stats['symbols']}")
    logger.info(f"Repository: {final_stats['repo_root']}")
    logger.info("=" * 60)
    
    # Cleanup
    pool.close()
    logger.info("Done!")


if __name__ == "__main__":
    main()
