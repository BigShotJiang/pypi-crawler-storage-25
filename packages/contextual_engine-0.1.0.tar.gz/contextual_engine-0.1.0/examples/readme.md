# Contextual Examples
 
Example scripts demonstrating Contextual usage.
 
## Phase 1 Examples
 
### `index_repository.py`
Index a code repository and optionally start file watcher.
 
**Usage:**
```bash
python examples/index_repository.py /path/to/your/repo
```
 
**Features:**
- Full repository indexing
- Incremental file watcher
- Real-time statistics
- Interactive prompts
 
**Example:**
```bash
# Index Contextual itself
python examples/index_repository.py .
 
# Index another project
python examples/index_repository.py ~/projects/my-app
```
 
## Running Examples
 
All examples assume you're in the Contextual project root:
```bash
cd /Users/apple/TechStack/Projects/Contextual
python examples/index_repository.py <repo-path>
```
EOF
 
# Create __init__.py
touch examples/__init__.py
```
 
**DONE** - Examples directory ready for Phase 1 demos.
 
---
 
**NOTE:** This is optional but useful for testing and demos.