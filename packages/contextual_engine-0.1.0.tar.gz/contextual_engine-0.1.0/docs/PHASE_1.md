# PHASE_1 — Codebase Semantic Indexing

**Duration:** 5 days (Apr 23–27, 2026)
**Prereq:** Phase 0 complete, `v0.0.1` tagged on `main`.
**Deliverable:** `contextual-mcp` exposes `codebase.*` tools; Contextual indexes and queries its own repo via Claude Desktop.

## 1. Goal Statement

Enable an MCP client (Claude Desktop, Cursor, Continue) to ask semantic questions about a local code repository and receive ranked, relevant code chunks with precise source locations. End Phase 1 by using Contextual to help develop Phase 2 (first dogfood moment).

## 2. Success Criteria (Exit Bar — All Must Be Green)

1. Languages supported at Phase 1 ship: **Python, TypeScript, JavaScript, Rust, Go** (minimum 5).
2. Initial full-index of a 1,000-file repo completes in **< 60s** on a modern laptop.
3. Incremental re-index on a single file change completes in **< 500ms**.
4. `codebase.search(query, k=10)` returns top-K chunks within **< 300ms** p50 on a 10k-chunk index.
5. Manual relevance eval on a 20-query golden set: ≥ **80%** of top-3 results are human-judged relevant.
6. File watcher picks up changes within **2s** of filesystem write (debounced for `awaitWriteFinish`).
7. Tool usable from Claude Desktop: open Contextual's own repo, ask "Where is the file watcher implemented?", get the right file.
8. Coverage ≥ 60% on `contextual-codebase`; ≥ 75% on `contextual-core`.
9. CI green, PR squash-merged to `main`, tag `v0.1.0`.

## 3. Technology Stack

| Concern | Choice | Rationale |
|---|---|---|
| Parser | `tree-sitter` (py-tree-sitter + tree-sitter-languages) | 40+ language support, de-facto standard (Aider, Cursor, Continue, Roo) |
| Chunker | LlamaIndex `CodeSplitter` or custom AST-traversal chunker | AST-aware, sibling-merge up to token limit |
| Embeddings | Voyage `voyage-code-3` (primary), Ollama `nomic-embed-text` (offline fallback) | Voyage is "17% better than alternatives" for code; Ollama for dev without API keys |
| Vector store | `sqlite-vec` vec0 virtual table | Local-first, zero-setup, embedded |
| Keyword store | SQLite FTS5 virtual table | Hybrid BM25+vector scoring |
| File watcher | Python `watchdog` (FSEvents/inotify/ReadDirectoryChanges) | Cross-platform, debounce-capable |
| MCP framework | `FastMCP` 2.x | Decorator-based tools, stdio transport, auto schema |
| DB migrations | Alembic with `render_as_batch=True` | Handles SQLite's move-and-copy requirement |
| Ignore rules | Read `.gitignore`, fall back to defaults (`node_modules`, `target`, `__pycache__`, `.venv`) | Consistent with Roo's approach |

## 4. Data Model (Phase 1 additions)

```sql
-- Already exists from Phase 0:
-- files(id, path, language, mtime, content_hash)
-- chunks(id, file_id, start_line, end_line, symbol_name, symbol_type, content, content_hash)
-- embeddings: vec0 virtual table keyed by chunk_id, dim=1024 (voyage-code-3)
-- fts_chunks: FTS5 virtual table on chunks.content

-- Phase 1 additions:
CREATE TABLE code_symbols (
  id INTEGER PRIMARY KEY,
  chunk_id INTEGER NOT NULL REFERENCES chunks(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  kind TEXT NOT NULL CHECK (kind IN ('function','class','method','interface','struct','enum','type_alias','variable','import')),
  signature TEXT,
  docstring TEXT,
  UNIQUE(chunk_id, name, kind)
);
CREATE INDEX idx_symbols_name ON code_symbols(name);
CREATE INDEX idx_symbols_kind ON code_symbols(kind);

CREATE TABLE indexing_state (
  repo_root TEXT PRIMARY KEY,
  last_full_index_at TIMESTAMP NOT NULL,
  last_incremental_at TIMESTAMP,
  total_files INTEGER,
  total_chunks INTEGER
);
```

## 5. 4-Day Breakdown (Day 3 of Phase 0 = buffer; work starts Day 4)

### Day 1 (Apr 23) — Parser Layer
- [ ] Install `tree-sitter` + language grammars for 5 languages via `tree-sitter-languages`.
- [ ] Implement `Parser` class with `parse(file_path, content) -> AST`.
- [ ] Implement `SymbolExtractor` with language-specific Tree-sitter queries (`.scm` files) for functions, classes, methods, imports (mirroring Continue/Roo patterns).
- [ ] Unit tests: parse fixtures for each of 5 languages, assert expected symbols extracted.
- **Commit style:** `feat(codebase): add tree-sitter parsers for py/ts/js/rs/go`

### Day 2 (Apr 24) — Chunker + Embedder + DB Writer
- [ ] Implement `ASTChunker`: depth-first AST traversal, sibling merge up to `max_tokens=512`, fallback to line-based chunking for unsupported types.
- [ ] Implement `Embedder` using the core embedding-provider abstraction; batch size 64; content-hash cache so unchanged chunks aren't re-embedded.
- [ ] Implement `IndexWriter`: transactional write of `files`, `chunks`, `embeddings` (vec0), `fts_chunks`, `code_symbols` in one transaction per file.
- [ ] Integration test: index a 10-file fixture repo end-to-end; assert row counts.
- **Commit style:** `feat(codebase): AST-aware chunker and batched embedder`

### Day 3 (Apr 25) — File Watcher + Incremental Indexer
- [ ] Implement `FileWatcher` using `watchdog`; debounce via `awaitWriteFinish`-style timer (500ms).
- [ ] Implement `IncrementalIndexer`: on change, recompute content hash; if unchanged, skip; else re-parse/re-chunk/re-embed only that file; UPSERT chunks, DELETE orphan chunks.
- [ ] Ignore rules: merge `.gitignore` patterns + built-in defaults.
- [ ] Integration test: start watcher on fixture repo, write a file, assert index updated within 2s.
- **Commit style:** `feat(codebase): incremental indexing with watchdog file watcher`

### Day 4 (Apr 26) — MCP Tools + Hybrid Search
- [ ] Register FastMCP tools in `contextual-mcp`:
  - `codebase.index(path)` — trigger full index
  - `codebase.search(query: str, k: int = 10, language: str | None = None) -> list[Result]`
  - `codebase.get_symbol(name: str, kind: str | None = None) -> list[SymbolResult]`
  - `codebase.get_file(path: str, start: int | None = None, end: int | None = None) -> str`
  - `codebase.stats() -> dict`
- [ ] Implement hybrid retrieval: vector (cosine) top-30 + FTS5 BM25 top-30, Reciprocal Rank Fusion to top-K.
- [ ] Results include `{file, start_line, end_line, symbol_name, kind, score, snippet}` for client display.
- [ ] Schema auto-generated by FastMCP from Python type hints; docstrings become tool descriptions.
- **Commit style:** `feat(mcp): codebase.search and codebase.get_symbol tools`

### Day 5 (Apr 27) — Golden Eval, Dogfood, Ship
- [ ] Author 20-query golden-eval set covering: symbol lookup, concept search, cross-file relationships, "where is X implemented", "how does Y work".
- [ ] Run golden eval, tune chunk size and RRF weights until ≥ 80% top-3 relevance.
- [ ] Dogfood session: open Contextual's own repo in Claude Desktop; ask 10 real questions while planning Phase 2; log hits/misses.
- [ ] Fix top 3 dogfood-surfaced issues.
- [ ] Update `CHANGELOG.md`, write `docs/retros/phase-1.md`.
- [ ] Merge `phase/1-codebase-indexing` PR → `main`.
- [ ] Tag `v0.1.0`, push tag, confirm release pipeline.
- **Commit style:** `chore(release): v0.1.0 — codebase semantic indexing`

## 6. MCP Tool Surface (Phase 1 Exports)

```python
# packages/contextual-mcp/src/contextual_mcp/tools/codebase.py
from fastmcp import FastMCP

mcp = FastMCP("contextual")

@mcp.tool()
def codebase_index(path: str) -> dict:
    """Index (or re-index) a code repository at the given path.
    Returns {files_indexed, chunks_created, duration_ms}."""
    ...

@mcp.tool()
def codebase_search(query: str, k: int = 10, language: str | None = None) -> list[dict]:
    """Semantically search the indexed codebase.
    Args:
        query: Natural-language question or concept.
        k: Number of results (1–50).
        language: Filter by language (py, ts, js, rs, go) or None for all.
    Returns ranked list of {file, start_line, end_line, symbol_name, kind, score, snippet}."""
    ...

@mcp.tool()
def codebase_get_symbol(name: str, kind: str | None = None) -> list[dict]:
    """Look up a symbol by name (exact or fuzzy). Returns all matches across files."""
    ...

@mcp.tool()
def codebase_get_file(path: str, start_line: int | None = None, end_line: int | None = None) -> str:
    """Retrieve raw file content, optionally a line range. For grounding LLM answers in exact source."""
    ...

@mcp.tool()
def codebase_stats() -> dict:
    """Current index statistics: file count, chunk count, languages, last_indexed_at."""
    ...
```

## 7. Observability (Phase-1 Scope)

- Structured JSON logs to **stderr** (NEVER stdout in stdio transport).
- Log fields: `{ts, level, tool, duration_ms, args_hash, result_summary, trace_id}`.
- Metrics counters (in-memory for now, OTEL in Phase 5): tool invocations, errors, cache hits.
- Critical principle: **Never use `print()` or `console.log()` in the MCP server path** — it corrupts JSON-RPC framing.

## 8. Testing (Phase-1 Scope)

- **Unit:** parser per language (fixture-driven), chunker (boundary cases), embedder (mock provider), incremental indexer state transitions.
- **Integration:** full index of 3 fixture repos (small Py, medium TS, mixed-language); assert chunk counts, search relevance.
- **Contract:** MCP Inspector CLI script asserts every `codebase.*` tool's schema matches recorded baseline.
- **Golden eval:** 20-query set; CI fails on < 80% top-3 relevance.
- **Perf:** index-1000-files benchmark; CI fails on > 20% regression vs baseline.

## 9. Risks & Mitigations (Phase-1 Specific)

| Risk | Mitigation |
|---|---|
| Tree-sitter wheel missing on user platform | Ship `web-tree-sitter` WASM fallback; document `tree-sitter-languages` as primary |
| Embedding costs on full re-index | Content-hash cache: re-embed only if chunk content changed; batch 64 at a time |
| Windows path handling differences | Use `pathlib.PurePosixPath` internally; test on Windows in CI matrix |
| Binary files masquerading as source | Detect via null-byte heuristic in first 8KB; skip |
| Very large files (>2MB) | Skip with warning log; configurable limit |

## 10. Definition of Done Checklist (copy into PR)

- [ ] All 5 languages parse 10-file fixture per language with zero errors
- [ ] AST-aware chunker merges siblings correctly (boundary test)
- [ ] Embedder caches by content hash; cache-hit test green
- [ ] Incremental indexer handles add/modify/delete/rename
- [ ] File watcher debounced; no duplicate events in rapid-save test
- [ ] All 5 MCP tools registered and appear in MCP Inspector
- [ ] Hybrid RRF scoring beats pure-vector on golden eval by ≥ 10% Recall@10
- [ ] Golden eval ≥ 80% top-3 relevance
- [ ] Perf targets met (60s full / 500ms incremental / 300ms p50 search)
- [ ] No stdout writes anywhere in server path (`grep -r 'print(' packages/contextual-mcp` returns zero)
- [ ] `alembic upgrade head` clean on fresh DB
- [ ] CI all-green on `phase/1-codebase-indexing`
- [ ] `CHANGELOG.md` Phase 1 section written
- [ ] `docs/retros/phase-1.md` written
- [ ] Dogfood session logged (≥ 10 queries) in retro
- [ ] Merge commit tagged `v0.1.0`