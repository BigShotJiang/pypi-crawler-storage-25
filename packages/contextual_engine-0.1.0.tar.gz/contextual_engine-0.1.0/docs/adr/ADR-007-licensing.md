# ADR-007: Licensing — BSL 1.1 with Apache-2.0 Change License

**Status**: Accepted
**Date**: April 22, 2026

## Context

We need a license that protects commercial value during the early phase while signaling eventual open-source intent. All dependencies must be compatible. pygit2's GPL-2.0 with linking exception requires special handling.

## Decision

License under **Business Source License 1.1** with **Apache-2.0 as the Change License** and a **4-year Change Date** from each release. pygit2 kept as an external dependency, never vendored, never modified.

## Dependency Compatibility

| Dependency | License | Compatible with BSL? |
|------------|---------|---------------------|
| SQLite | Public Domain | Yes |
| LanceDB | Apache-2.0 | Yes |
| FastMCP | Apache-2.0 | Yes |
| tree-sitter-language-pack | MIT | Yes |
| fastembed | Apache-2.0 | Yes |
| tantivy-py | MIT | Yes |
| Typer | MIT | Yes |
| Pydantic | MIT | Yes |
| structlog | MIT | Yes |
| pathspec | MPL-2.0 | Yes |
| pygit2 | GPL-2.0 with linking exception | Yes — with conditions |

## pygit2 Handling (CRITICAL)

The GPL-2.0 with linking exception permits linking into BSL products but requires:

1. **Keep as external dependency** — install via pip, never vendor into our source tree
2. **Never modify pygit2 source** — any modification must be released under GPL-2.0-with-exception
3. **Preserve license notices** in distributed binaries (THIRD-PARTY-LICENSES file)
4. **Treat as a CI tripwire** — add a check that pygit2 source is never present in our repo

## Alternatives Considered

- **FSL (Functional Source License)**: Simpler (2-year → Apache), used by Sentry/Keygen. Worth 1-hour legal review but BSL is more industry-proven (CockroachDB, Sentry, HashiCorp).
- **AGPL-3.0**: Too restrictive for enterprise adoption.
- **Apache-2.0 from day one**: No commercial protection during bootstrap phase.
- **MPL-2.0 as Change License**: Stricter-compatible with GPL but less common in practice.

## Consequences

- Ship a THIRD-PARTY-LICENSES file listing pygit2's exact license text
- Change Date = 4 years from each release (e.g., v0.1.0 released May 2026 → Apache-2.0 from May 2030)
- Any contributor must agree to the BSL terms (CLA or DCO)
- Enterprise customers can use freely; competitors cannot resell without waiting for Change Date
