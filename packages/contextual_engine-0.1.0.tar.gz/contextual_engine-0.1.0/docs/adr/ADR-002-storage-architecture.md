# ADR-002: Dual Storage Architecture (SQLite + LanceDB)

**Status**: Accepted
**Date**: April 22, 2026

## Context

We need persistent storage for structured metadata (entities, facts, relationships) and high-dimensional vector embeddings. Must run embedded (no server process), support concurrent reads, and fit in 8GB RAM.

## Decision

**SQLite 3.51** for structured data, bi-temporal facts, FTS5 text search.
**LanceDB 0.30** for vector embeddings, native BM25/FTS, hybrid search.

Two separate stores, not one unified database.

## Rationale

- SQLite provides ACID transactions, partial indexes (critical for bi-temporal hot queries), recursive CTEs for graph traversal, and zero-config deployment
- LanceDB provides disk-native columnar vectors (not in-memory like FAISS), native Rust BM25, IVF_PQ indexing, and schema evolution
- sqlite-vec is alpha, lacks hybrid search, and has no schema evolution — wrong for production
- Qdrant embedded has ~52ms HTTP overhead baseline — too heavy
- Single-store solutions (just LanceDB, just SQLite) each lack critical capabilities the other provides

## Consequences

- Must keep content-hash in sync between both stores (atomic consistency on crash)
- Two compaction strategies to manage (SQLite VACUUM + LanceDB optimize)
- Stable row IDs enabled in LanceDB for cross-referencing from SQLite
- Per-project isolation: both stores live in `.contextual/` directory
