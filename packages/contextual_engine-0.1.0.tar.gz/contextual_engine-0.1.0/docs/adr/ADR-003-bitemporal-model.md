# ADR-003: Bi-Temporal Data Model (Snodgrass/Graphiti)

**Status**: Accepted
**Date**: April 22, 2026

## Context

AI tools hallucinate because they lack temporal awareness — they don't know when facts became true or when they were superseded. We need a data model that captures both the real-world timeline and our knowledge timeline.

## Decision

Adopt the Snodgrass/Graphiti four-timestamp fact edge model: `valid_at`, `invalid_at`, `created_at`, `expired_at`. Never delete facts — always invalidate and insert.

## Design

Every fact in the system carries four INTEGER (unix-ms UTC) timestamps:
- **valid_at**: When this fact became true in the real world (from git blame author_time)
- **invalid_at**: When this fact stopped being true (NULL = still valid)
- **created_at**: When our system first recorded this fact (system clock at ingestion)
- **expired_at**: When our system retracted this belief (NULL = still believed)

Contradiction detection uses structural rules for code: two `has_signature` edges on the same entity with overlapping valid-time triggers invalidation of the older one.

## Consequences

- Database grows monotonically (~150-300 bytes/fact) — use INCREMENTAL auto_vacuum
- Partial indexes on `WHERE invalid_at IS NULL AND expired_at IS NULL` keep hot queries fast
- AS-OF queries become simple WHERE clauses on valid_at/invalid_at ranges
- Use NULL (not sentinel `9999-12-31`) for open intervals — partial indexes on IS NULL are free
- All timestamps as INTEGER unix-ms — never ISO strings, never naive datetimes
- Reference entities table (stable), not facts table (facts expire), for foreign keys
