# ADR-006: Security Architecture — Prompt Injection Defense

**Status**: Accepted
**Date**: April 22, 2026

## Context

Contextual is a content indexer whose outputs feed directly to LLMs. This makes it a potential vector for indirect prompt injection — the class of attacks behind CVE-2025-54135 (CurXecute, CVSS 8.6) and CVE-2025-54136 (MCPoison). We must treat all indexed content as untrusted data.

## Decision

Defense-in-depth with seven layers. No single layer is sufficient alone.

## Layers

1. **Output marking**: All MCP tool returns wrapped in `<untrusted_content>` markers
2. **Input sanitization**: Strip Unicode category Cf (zero-width joiners, bidi marks) from all indexed text
3. **Path containment**: resolve-then-check pattern (`Path.resolve(strict=True)` → `is_relative_to(root)`)
4. **SQL safety**: Parameterized `?` placeholders everywhere; FTS5 phrase-quoting for user terms
5. **Workspace isolation**: Separate SQLite DB per project in `.contextual/`; never global DB
6. **Write containment**: Never write outside project root — especially not `~/.cursor/`, `~/.claude/`
7. **Network isolation**: No outbound HTTP tools on the MCP server (avoids "lethal trifecta")

## Consequences

- All file permissions set explicitly: umask(0o077), DB 0o600, directory 0o700
- Config files content-hashed on load; alert on unexpected change
- PRAGMA trusted_schema=OFF on all SQLite connections
- Windows reserved names (CON, PRN, AUX, NUL, COM1-9, LPT1-9) rejected in path validation
- Concurrency limited by asyncio.Semaphore (10 concurrent), per-tool asyncio.wait_for timeouts
