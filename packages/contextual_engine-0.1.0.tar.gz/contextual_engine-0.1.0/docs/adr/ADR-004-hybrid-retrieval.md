# ADR-004: Hybrid Retrieval Pipeline (BM25 + Dense + RRF + Rerank)

**Status**: Accepted
**Date**: April 22, 2026

## Context

Code search requires both exact identifier matching (BM25) and semantic understanding (dense embeddings). Neither alone is sufficient. We need a fusion strategy that doesn't require labeled training data.

## Decision

Four-stage pipeline: parallel BM25+Dense → Weighted RRF fusion → Cross-encoder rerank → MMR diversity selection. Total budget: <600ms p95.

## Design

1. **BM25 (tantivy-py)**: Top-100 results. Code-aware tokenizer splits camelCase/snake_case while preserving originals. Stopwords OFF. b=0.3 (lower length normalization for code).
2. **Dense (LanceDB)**: Top-100 results. jina-v2-base-code 768d query embedding.
3. **RRF fusion**: k=60, BM25 weight 0.6, dense weight 0.4. BM25 weighted higher because identifier matches are disproportionately valuable in code.
4. **Cross-encoder rerank**: jina-reranker-v2-base-multilingual ONNX-int8. Top-30 candidates. ~420ms on M2 Air.
5. **MMR selection**: λ=0.7. Max 2 chunks per file, max 1 per unique symbol.

## Alternatives Considered

- **SQLite FTS5 instead of tantivy**: Rejected — FTS5 can't do camelCase splitting without a C extension
- **Convex Combination instead of RRF**: Rejected — requires labeled data we don't have
- **bge-reranker-v2-m3**: Considered — ~50% larger than jina-reranker-v2, similar quality, slower
- **LanceDB native FTS instead of tantivy**: Possible v1.1 consolidation once we validate the tokenizer flexibility is sufficient

## Consequences

- Two separate search indexes (tantivy + LanceDB) must stay in sync via content-hash
- Reranking is the latency bottleneck (~420ms of 536ms total) — cap at 30 pairs
- Degraded mode: if any component fails, pipeline continues with remaining components
- tantivy-py adds a native Rust dependency — verify wheel availability per platform
