# ADR-001: Code Embedding Model Selection

**Status**: Accepted
**Date**: April 22, 2026
**Deciders**: Founder

## Context

We need a code embedding model that runs locally on MacBook M2 Air 8GB RAM via CPU-only ONNX inference. It must produce high-quality code retrieval embeddings across 7+ programming languages with sub-100ms query latency.

## Decision

**Primary (code)**: `jina-embeddings-v2-base-code` int8 ONNX via fastembed — 161M params, 768d, 8K context, Apache-2.0.

**Secondary (NL)**: `nomic-embed-text-v1.5` Matryoshka truncated to 256d for commit messages, ADRs, and documentation.

**Upgrade path (v1.1)**: `jina-code-embeddings-0.5b` GGUF-Q4_K_M (78.4% CoIR, current small-model SOTA).

## Alternatives Considered

| Model | Params | Dims | RAM | Why Rejected |
|-------|--------|------|-----|--------------|
| nomic-embed-code | 7B | 3584 | 4.4GB Q4 | Infeasible on 8GB — card specifies 28GB VRAM |
| BGE-M3 | 568M | 1024 | ~2GB | Unnecessary — we don't need multilingual NL hybrid |
| CodeBERT | 125M | 768 | ~500MB | Obsolete — MRR ~0.12 out of the box |
| StarEncoder | 125M | 768 | ~500MB | No native pooling head, needs custom code |
| jina-code-0.5b | 500M | 1024 | ~1.5GB | v1.1 upgrade — needs llama.cpp bindings not yet wired |

## Consequences

- ~170MB resident RAM at int8, leaving headroom for reranker + BM25 index
- 80–120 docs/sec at short sequences on Apple Silicon
- Mean pooling (not last-token) — do not mix with jina-code-0.5b vectors in same index
- Must use fastembed (not sentence-transformers) to avoid ~1GB PyTorch overhead
- No fp16 on CPU — M2 lacks BF16 support, int8 is the sweet spot
- Nomic model REQUIRES search_query:/search_document: prefixes — skipping drops 5-10 points
