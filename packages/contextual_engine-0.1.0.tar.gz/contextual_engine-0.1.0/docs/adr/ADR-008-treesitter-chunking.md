# ADR-008: Tree-sitter Chunking Strategy

**Status**: Accepted
**Date**: April 22, 2026

## Context

Code must be split into semantically meaningful chunks for embedding. Naive line-based splitting breaks functions mid-body. Regex-based splitting misses language structure. We need AST-aware chunking that preserves semantic boundaries.

## Decision

Use `tree-sitter-language-pack` (NOT the deprecated `tree-sitter-languages`) with the Sweep recursive split-then-merge algorithm. Chunk at top-level declarations with deterministic structural headers.

## Design Parameters

- **Target**: 1,500 chars per chunk
- **Maximum**: 2,000 chars (split if exceeded)
- **Minimum**: 50 chars (merge with adjacent if below)
- **Max file**: 2 MB (skip above)
- **Line fallback**: 500 KB (above this, fall back to line-based splitting)
- **Content key**: SHA-256 hash of chunk text (not file+line)
- **Languages**: Python, TypeScript, JavaScript, TSX, Go, Java, Rust, C# + JSON, YAML, TOML, Dockerfile, Markdown

## Key Implementation Details

1. **Bytes not chars** — tree-sitter indexes in bytes; always use `len(source.encode())` or work in bytes
2. **Parser is NOT thread-safe** — use a ParserPool (one parser per language, keyed by language string)
3. **ERROR nodes are valid** — work-in-progress code with parse errors should still be chunked, not rejected
4. **Generated code skipped** — `*.min.js`, `*_pb2.py`, `*.d.ts`, `// Code generated ... DO NOT EDIT`
5. **Structural header** — prepended to every chunk with file path, parent class, imports, decorators
6. **Content-hash dedup** — a 1-line edit re-embeds only the changed chunk, not the entire file

## Alternatives Considered

- **LSP-based parsing (Serena approach)**: Richer type info but can't reconstruct source text, requires running language servers, heavy for local-first
- **Regex-based splitting**: Fast but breaks on edge cases (nested functions, decorators, closures)
- **Fixed-size token windows**: Simple but splits functions mid-body, losing semantic boundaries
- **LLM-based chunking**: Accurate but infeasible at index time (too slow, too expensive)

## Consequences

- tree-sitter-language-pack adds a compiled native dependency (~30MB wheels)
- Some languages have imperfect grammars (rare edge cases in metaprogramming, macros)
- Structural headers add ~100-200 bytes per chunk (acceptable overhead for 35% retrieval improvement)
- Content-hash keying means chunk IDs are not human-readable (use for internal reference only)
