# ADR-005: MCP-First, Tool-Agnostic Architecture

**Status**: Accepted
**Date**: April 22, 2026

## Context

The developer tools market is fragmented — Claude Code, Cursor, Copilot, Gemini CLI, Windsurf, Zed all compete. Any memory solution locked to one tool is immediately limited. The Model Context Protocol (MCP) is the only cross-tool standard for AI tool integration.

## Decision

Expose all functionality through MCP as the primary interface. CLI as secondary (for humans). No IDE-specific code in core modules — all IDE specifics live in `integrations/`.

## Design

- **Transport**: stdio for editor clients (zero config), localhost Streamable HTTP for background daemon
- **8 tools**: index, search, recall, capture_decision, freshness, status, forget, timeline
- **Framework**: FastMCP 3.2.x (PrefectHQ/fastmcp), pinned >=3.2,<4
- **Parameters**: All tool params FLAT (no nested Pydantic models) — Claude Code serializes nested params as JSON strings
- **Errors**: ToolError for user-visible, McpError for protocol-level
- **IDE configs**: 8 IDEs supported, each with different config format/location

## IDE Config Matrix

| IDE | Config Key | Location | Transport |
|-----|-----------|----------|-----------|
| Claude Desktop | mcpServers | ~/Library/Application Support/Claude/ | stdio |
| Claude Code | claude mcp add | CLI command | stdio |
| Cursor | mcpServers | .cursor/mcp.json | stdio |
| VS Code Copilot | mcp.servers + type | settings.json | stdio |
| Gemini CLI | mcpServers | ~/.gemini/settings.json | stdio/HTTP |
| Windsurf | mcpServers | ~/.codeium/windsurf/ | stdio |
| ChatGPT Desktop | type: stdio | Developer Mode | stdio |
| Zed | context_servers | settings.json | stdio |

## Consequences

- Must test with at least 3 IDEs before launch (Claude Desktop, Cursor, VS Code)
- `contextual setup <ide>` command auto-generates correct config per IDE
- FastMCP 3.x migration gotchas: constructor kwargs moved to .run(), mount(prefix=) renamed to mount(namespace=)
- Origin header validation on HTTP transport for DNS rebinding prevention
