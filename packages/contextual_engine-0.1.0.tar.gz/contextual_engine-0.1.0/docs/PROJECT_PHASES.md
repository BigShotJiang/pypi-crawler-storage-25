# PROJECT_PHASES — Contextual 5-Phase Delivery Plan

## 0. Methodology

**Foundation-first vertical slicing.** Phase 0 is a thin horizontal foundation (DB, MCP scaffolding, CI). Phases 1–5 are vertical slices: each ends with a user-facing MCP tool callable from Claude Desktop, Cursor, or Continue. Each phase has a hard exit criteria checklist; next phase does not start until previous is 100% green. **Dogfooding begins at the end of Phase 1** — Contextual indexes its own repo and assists its own development from that point onward.

## 1. Timeline Overview (27 days, April 21 – May 17, 2026)

| Phase | Days | Dates (approx.) | Deliverable |
|---|---|---|---|
| Phase 0 | 2 | Apr 21–22 | DB, schemas, MCP skeleton, CI |
| Phase 1 | 5 | Apr 23–27 | Codebase semantic indexing MCP tool |
| Phase 2 | 5 | Apr 28–May 2 | Docs/markdown semantic search MCP tool |
| Phase 3 | 5 | May 3–7 | Temporal ADR store + as-of-time queries |
| Phase 4 | 5 | May 8–12 | Knowledge graph over entities + relations |
| Phase 5 | 5 | May 13–17 | Test hardening, CI/CD, observability, 1.0-RC |

Buffer: intentionally none. If a phase slips, the **scope is cut, not the timeline** — the exit criteria checklist is the minimum bar.

## 2. Architecture (All Phases)
contextual/
├── packages/
│   ├── contextual-core/       # SQLAlchemy models, Alembic migrations, config, embedding provider abstraction
│   ├── contextual-codebase/   # Phase 1: tree-sitter parsing, AST chunking, file watcher
│   ├── contextual-docs/       # Phase 2: markdown parsing, heading-aware chunking
│   ├── contextual-temporal/   # Phase 3: bitemporal ADR store, as-of queries
│   ├── contextual-graph/      # Phase 4: entity extraction, graph queries (recursive CTE)
│   └── contextual-mcp/        # MCP server, FastMCP tools, feature-flag wiring
├── tests/
├── docs/
│   └── adr/
├── .github/workflows/
└── pyproject.toml

**Storage:** Single SQLite file `~/.contextual/contextual.db` (configurable) with extensions `sqlite-vec` (vectors) and FTS5 (full-text). All phases write to this single file.

**MCP deployment:** Single FastMCP server `contextual-mcp`, stdio transport. Module-registered tools gated by env-var feature flags.

**Embedding provider:** Pluggable via `contextual-core`. Default: Voyage `voyage-code-3` for code, OpenAI `text-embedding-3-small` for docs/ADRs, Ollama `nomic-embed-text` offline fallback.

---

## Phase 0 — Foundation (Days 1–2)

### Goal
Lay the narrowest possible horizontal base: DB, migrations, MCP scaffolding, CI, observability primitives. Nothing user-visible yet, but **the skeleton is deployable**.

### Prerequisites
- Python 3.11+ installed
- `uv` package manager
- GitHub repo created with `main` branch protected
- Claude Desktop installed (for smoke testing)
- API keys: Voyage, OpenAI (optional, Ollama fallback available)

### Scope
- [ ] Monorepo layout scaffolded with `packages/*` skeleton
- [ ] `contextual-core` package: SQLAlchemy 2.0 models, Alembic configured with `render_as_batch=True` for SQLite
- [ ] Base tables: `files`, `chunks`, `embeddings` (vec0), `fts_chunks` (FTS5 virtual table)
- [ ] Config via `pydantic-settings`, env-var driven
- [ ] `contextual-mcp` FastMCP server with one smoke tool `contextual.ping()` → returns `pong`
- [ ] Embedding provider abstraction (3 implementations: Voyage, OpenAI, Ollama)
- [ ] Structured JSON logging to stderr (CRITICAL: never stdout in stdio transport)
- [ ] GitHub Actions CI: lint (ruff, mypy), test (pytest), build (uv build)
- [ ] `.github/pull_request_template.md`
- [ ] `CHANGELOG.md` initialized
- [ ] `docs/adr/0001-sqlite-over-postgres.md` — rationale doc
- [ ] Claude Desktop config installs server; `contextual.ping()` callable from Claude

### Exit Criteria
1. `uv run pytest` green.
2. `alembic upgrade head` creates DB with all tables + vec0/FTS5 indexes.
3. `contextual-mcp` starts via `uv run contextual-mcp` without errors; `stderr` shows structured startup log.
4. Claude Desktop can call `contextual.ping()` and receive `"pong"`.
5. GitHub Actions CI passes on `phase/0-foundation` branch.
6. PR merged to `main`, tagged `v0.0.1`.

---

## Phase 1 — Codebase Semantic Indexing (Days 3–7)

**See PHASE_1.md for the full technical breakdown.**

### Goal
Index a local code repository's source files; expose MCP tools to query by semantic meaning. **End state: `contextual` can index and answer questions about its own codebase.** Dogfooding begins here.

### Exit Criteria
1. Indexes Python, TypeScript, JavaScript, Rust, Go at minimum.
2. File watcher updates index within 2s of file change.
3. `codebase.search(query, k)` returns top-K chunks with scores; manual eval pass on 20 hand-labeled queries ≥ 80% relevance.
4. Indexing 1000 files < 60s on dev machine.
5. Incremental re-index on change < 500ms per changed file.
6. Tag `v0.1.0` on `main`.
7. **Dogfood check:** you use `contextual` from Claude Desktop for at least one real question while building Phase 2.

---

## Phase 2 — Documentation Semantic Search (Days 8–12)

### Goal
Extend the engine to markdown docs, READMEs, ADRs, and arbitrary prose. Markdown has different optimal chunking than code (heading-aware, not AST).

### Prerequisites
- Phase 1 exit criteria all green.
- `v0.1.0` tag on `main`.

### Scope
- [ ] `contextual-docs` package
- [ ] Markdown parser (mistune or markdown-it-py) → heading-tree chunker
- [ ] Chunks stored in same DB, `source_type='docs'` column for filtering
- [ ] File watcher extended to `*.md`, `*.mdx`, `*.rst` (configurable globs)
- [ ] MCP tool: `docs.search(query, k, source_filter=None)`
- [ ] MCP tool: `docs.get_section(file, heading_path)` — retrieve exact section
- [ ] Golden eval set: 20 doc queries with expected results
- [ ] ADR `0002-markdown-chunking-strategy.md`

### Architecture Notes
- Heading-aware chunking: each H2 section = one chunk; H3+ nested chunks include parent heading path in embedding context (Roo-style: "Markdown Support: Indexes Markdown files by treating headers as semantic entry points" [per 2026 Roo Code docs pattern]).
- Embedding provider switches to `text-embedding-3-small` for prose by default.
- Hybrid search: BM25 (FTS5) + cosine (sqlite-vec), reciprocal-rank-fusion scoring.

### Exit Criteria
1. Indexes all `.md` files in a repo.
2. `docs.search("how does the file watcher work")` returns relevant README/ADR sections.
3. Hybrid BM25+vector scoring measurably beats pure vector on golden set (≥ 10% Recall@10 improvement).
4. Dogfood check: Claude can answer doc-based questions about Contextual's own docs.
5. Tag `v0.2.0`.

---

## Phase 3 — Temporal ADRs & Bitemporal Queries (Days 13–17)

### Goal
Add a **bitemporal store** for Architecture Decision Records and other time-sensitive knowledge. Queries can ask "what did we believe on date X?" (valid time) and "what was recorded by time Y?" (transaction time) separately.

### Prerequisites
- Phase 2 exit criteria green.
- `v0.2.0` on `main`.

### Scope
- [ ] `contextual-temporal` package
- [ ] Tables: `adrs`, `adr_revisions` with `valid_from / valid_to / tx_from / tx_to` columns (bitemporal per SQL:2011)
- [ ] ADR ingestion: parse `docs/adr/NNNN-*.md` files using Michael Nygard template
- [ ] Status tracking: `Proposed / Accepted / Superseded / Deprecated`
- [ ] Supersedes-link graph (stored as edges table, used in Phase 4)
- [ ] MCP tool: `temporal.list_adrs(as_of=None, status=None)` — time-travel query
- [ ] MCP tool: `temporal.get_adr_history(adr_id)` — revision chain
- [ ] MCP tool: `temporal.search(query, as_of=None)` — semantic search scoped to a point in time
- [ ] ADR `0003-bitemporal-model-choice.md`

### Architecture Notes
- Valid time = when the decision was effective in the real project.
- Transaction time = when Contextual recorded the fact.
- Never UPDATE or DELETE an ADR row; always INSERT a new revision with updated `tx_from` and close the previous row's `tx_to` (append-only log, matches ADR's own philosophy).
- `as_of` query uses `WHERE tx_from <= :as_of AND (:as_of < tx_to OR tx_to IS NULL) AND valid_from <= :as_of AND (:as_of < valid_to OR valid_to IS NULL)`.

### Exit Criteria
1. Ingests a sample ADR corpus (Contextual's own `docs/adr/`) with supersedes-relationships resolved.
2. `temporal.list_adrs(as_of='2026-05-01')` returns only decisions effective on that date.
3. Round-trip test: create ADR → supersede it → historical query returns original; current query returns superseder.
4. Dogfood: Contextual's own ADRs are queryable via Claude.
5. Tag `v0.3.0`.

---

## Phase 4 — Knowledge Graph (Days 18–22)

### Goal
Build an entity-relationship graph over entities extracted from code, docs, and ADRs. Support traversal queries ("what ADRs reference the `Indexer` class?", "what modules depend on `sqlite-vec`?").

### Prerequisites
- Phase 3 green. `v0.3.0` on `main`.

### Scope
- [ ] `contextual-graph` package
- [ ] Schema: `entities(id, type, name, properties_json)`, `edges(subject_id, predicate, object_id, valid_from, valid_to)` (bitemporal edges, MemPalace-style)
- [ ] Entity extractors:
  - From code (Phase 1 AST): classes, functions, modules, imports
  - From docs (Phase 2): explicit `@entity` mentions or heading-based auto-extraction
  - From ADRs (Phase 3): decision entities, superseded-by edges
- [ ] Graph queries via recursive CTEs (BFS up to depth N)
- [ ] MCP tool: `graph.query_entity(name, depth=2)`
- [ ] MCP tool: `graph.timeline(entity, from=None, to=None)`
- [ ] MCP tool: `graph.neighbors(entity_id, edge_types=None)`
- [ ] ADR `0004-sqlite-cte-over-neo4j.md`

### Architecture Notes
- Triples (subject, predicate, object) pattern like MemPalace/Zep Graphiti, but entirely in SQLite.
- Recursive CTE: `WITH RECURSIVE neighbors AS (SELECT ... UNION ALL SELECT ... FROM edges JOIN neighbors ...)` with depth guard.
- Bitemporal edges so "what did the graph look like on date X" is answerable.
- Hybrid retrieval: vector search finds seed entity, graph expansion enriches context.

### Exit Criteria
1. Graph auto-built for Contextual's own repo.
2. `graph.query_entity('Indexer')` returns the class, its methods, its callers, related ADRs.
3. Recursive traversal at depth 3 < 200ms on Contextual's own graph.
4. Dogfood: Claude can answer "What depends on the `Chunker` class?" correctly.
5. Tag `v0.4.0`.

---

## Phase 5 — Testing, CI/CD, Observability (Days 23–27)

### Goal
Harden everything. Formalize testing pyramid, add OpenTelemetry, establish golden-eval regression suite, prepare for 1.0.

### Prerequisites
- Phase 4 green. `v0.4.0` on `main`.

### Scope
- [ ] Test pyramid formalized:
  - Unit tests: every `contextual-core` utility, every chunker
  - Integration tests: per-package round-trip (index → query → assert)
  - Contract tests: MCP tool schemas match client expectations (MCP Inspector CLI in CI)
  - Golden-eval tests: 100-query retrieval set across all 4 modules, Recall@10 ≥ threshold
- [ ] Coverage threshold in CI: ≥ 75% on `contextual-core`, ≥ 60% elsewhere
- [ ] OpenTelemetry SDK integration: per-tool spans, trace-context propagation
- [ ] OTEL exporter configurable (stdout, OTLP, Jaeger)
- [ ] Prometheus-compatible metrics endpoint (via `/metrics` over HTTP if `streamable-http` transport chosen)
- [ ] Performance regression CI: index-1000-files benchmark fails PR if >20% slower
- [ ] Release pipeline: `.github/workflows/release.yml` auto-publishes to PyPI on tag
- [ ] Install docs: one-command install, Claude/Cursor/Continue setup snippets
- [ ] `CONTRIBUTING.md`, `SECURITY.md`, `CODE_OF_CONDUCT.md`
- [ ] ADR `0005-observability-stack.md`

### Exit Criteria
1. CI green on all packages; coverage gates met.
2. Releasing a new version requires only `git tag v0.5.0 && git push --tags`; pipeline handles the rest.
3. OTEL traces visible in Jaeger when MCP server is run with `OTEL_EXPORTER_OTLP_ENDPOINT` set.
4. Golden eval suite runs in CI on every PR, blocks merge on regression.
5. Tag `v0.5.0` (release candidate) on `main`.
6. **After 2+ days of sustained dogfood-in-production without regressions**, cut `v1.0.0`.

---

## Phase Transition Ritual

At the end of each phase, the following ritual MUST be completed:

1. Open the phase's exit-criteria checklist; tick each item.
2. Run the full CI suite on the phase branch.
3. Run a manual dogfood session (at least 5 real queries through Claude Desktop).
4. Update `CHANGELOG.md` with the phase's contributions.
5. Write or update the relevant ADR(s).
6. Merge phase branch → `main` via PR.
7. Tag `v0.N.0`.
8. Write a 1-paragraph retrospective in `docs/retros/phase-N.md`: what worked, what slipped, what to change next phase.
9. Only then: `git checkout main && git pull && git checkout -b phase/N+1-<slug>` to start next phase.

## Risk Register

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| Tree-sitter build issues on target platforms | Med | High | Use `tree-sitter-languages` wheels, pin versions, test in CI matrix |
| Embedding API rate limits | Med | Med | Batch embeddings, local cache keyed by content hash, Ollama fallback |
| sqlite-vec version instability | Low | High | Pin exact version, own a forked copy, have pgvector migration spike ready |
| Phase slipping past 5–6 days | High | Med | Cut scope, never timeline — exit criteria are minimum bar, not ceiling |
| Dogfood reveals fundamental model flaw | Med | High | Phase 1 dogfooding is the canary — slip 1 day here if needed to rearchitect |