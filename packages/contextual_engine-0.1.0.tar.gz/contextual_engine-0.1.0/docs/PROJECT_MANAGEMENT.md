# PROJECT_MANAGEMENT — Contextual Lifecycle & Decision Framework

## 1. Project Lifecycle Overview

Contextual follows a **27-day phase-gated vertical-slicing cycle** with a solo developer + AI-team delegation model. Each phase is a **mini-project**: it has a kickoff, a work phase, a gate review, and a retrospective.

### 1.1 Phase Lifecycle (repeated 6 times: Phase 0 through Phase 5)
┌──────────────┐   ┌──────────────┐   ┌──────────────┐   ┌──────────────┐   ┌──────────────┐
│  KICKOFF     │ → │   BUILD      │ → │   GATE       │ → │   SHIP       │ → │  RETRO       │
│  (30 min)    │   │  (4–5 days)  │   │  (half day)  │   │  (1 hour)    │   │  (30 min)    │
└──────────────┘   └──────────────┘   └──────────────┘   └──────────────┘   └──────────────┘

- **Kickoff:** re-read `PROJECT_PHASES.md` §Phase-N, fork a phase branch, create tracking issue.
- **Build:** daily commits on short-lived feat branches or direct on phase branch; trunk-based discipline.
- **Gate:** run exit-criteria checklist; all-green required. If not green: either extend by ≤1 day OR cut scope.
- **Ship:** merge PR → `main`, tag `v0.N.0`, release notes, CHANGELOG.
- **Retro:** `docs/retros/phase-N.md` — worked/didn't/change next time.

### 1.2 Entry / Exit Criteria (adapted from phase-gate methodology)

Every phase has:
- **Entry criteria** (prerequisites): previous phase exit criteria 100% green, previous `v0.N.0` tag on `main`.
- **Exit criteria** (the threshold): specific, measurable, time-boxed — defined in PROJECT_PHASES.md.

The exit criteria are **the minimum bar**, not the target. You may ship more, but not less.

## 2. Phase Initiation Procedure

```bash
# 1. Ensure main is current and green
git checkout main && git pull
gh run list --branch main --limit 1   # should show green

# 2. Confirm previous phase tag exists
git tag | tail -5

# 3. Re-read PROJECT_PHASES.md §Phase-N
# 4. Create tracking issue
gh issue create --title "Phase N: <Goal>" --body "$(cat docs/phase-N-issue-template.md)"

# 5. Fork phase branch
git checkout -b phase/N-<kebab-slug>

# 6. Write/update PHASE_N.md (if not already done at project start)
# 7. Open draft PR targeting main (for early CI feedback)
gh pr create --draft --title "Phase N: <Goal>" --body "See issue #<N>"

# 8. Begin Day-1 work
```

## 3. Phase Completion Procedure

```bash
# 1. Run full exit-criteria checklist (in PHASE_N.md)
# 2. Run CI locally (pre-flight)
uv run pytest && uv run ruff check && uv run mypy .

# 3. Ensure golden-eval passes
uv run pytest tests/golden/ -v

# 4. Dogfood session: open Claude Desktop, run ≥ 5 real queries, log in retro

# 5. Update CHANGELOG.md with phase contributions

# 6. Write docs/retros/phase-N.md

# 7. Mark PR ready-for-review (self-review)
gh pr ready

# 8. Wait for CI green; squash-merge
gh pr merge --squash --delete-branch

# 9. Tag release
git checkout main && git pull
git tag -a v0.N.0 -m "Phase N: <Goal>"
git push origin v0.N.0

# 10. Confirm release pipeline succeeded
gh run list --workflow=release.yml --limit 1
```

## 4. Decision-Making Framework

### 4.1 Decision Classification

| Class | Definition | Process |
|---|---|---|
| **Architectural** | Affects storage, MCP surface, cross-module contracts, or is hard to reverse | Write an ADR |
| **Tactical** | Local to one module, easily reversed (function shape, var name, test style) | Just do it; document in commit |
| **Urgent/Production** | Breakage on `main`, security issue | Hotfix branch, post-hoc ADR if architectural |

### 4.2 Architecture Decision Records (ADRs)

ADRs follow Michael Nygard's template, stored in `docs/adr/NNNN-<slug>.md` as append-only log [per Nygard pattern; keep short, single-page].

Template:
```markdown
# NNNN. <Decision title in noun form>

- Status: Proposed | Accepted | Superseded by NNNN | Deprecated
- Date: YYYY-MM-DD
- Deciders: <your name, AI collaborators>
- Tags: <phase-1, storage, mcp, ...>

## Context
<The problem. Why a decision is needed. What forces apply?>

## Decision
<The choice made. One sentence first, then rationale.>

## Alternatives Considered
- Option A: <pros, cons>
- Option B: <pros, cons>
- Option C (chosen): <pros, cons>

## Consequences
- Positive: <...>
- Negative: <...>
- Neutral: <...>

## Confidence
<High / Medium / Low> — <rationale>
```

Rule: **never edit an accepted ADR**. If the decision changes, write a new ADR that supersedes it and link both ways.

### 4.3 Initial ADR Backlog (to be written)

| # | Title | Phase |
|---|---|---|
| 0001 | SQLite over PostgreSQL for local-first storage | 0 |
| 0002 | Markdown heading-aware chunking strategy | 2 |
| 0003 | Bitemporal model (valid time + transaction time) for ADRs | 3 |
| 0004 | Recursive CTEs in SQLite over Neo4j for knowledge graph | 4 |
| 0005 | OpenTelemetry observability stack | 5 |
| 0006 | Modular-monolith MCP server with feature flags | 0 |
| 0007 | Voyage voyage-code-3 default embedding for code | 1 |
| 0008 | Tree-sitter + AST-aware chunking for code | 1 |

### 4.4 Scope-Cut Decision Rule

When a phase is at risk of missing exit criteria by the 5th/6th day:

1. **First, cut scope** — remove optional items (stretch languages, bonus tools) from the current phase.
2. **Second, extend by at most 1 day** — only if cutting would make the phase deliverable non-functional.
3. **Never cut exit criteria** — they define the minimum viable slice.
4. **Never skip the dogfood session** — it's a core quality gate.
5. If the phase genuinely cannot ship in 6 days + 1-day extension, **pause and write an ADR** analyzing the miss; only then replan.

## 5. AI-Team Delegation Protocol

Since you're a solo dev augmented by AI collaborators (Claude Code, Cursor, Continue):

### 5.1 Task Delegation Tiers

| Tier | Task Type | Review Intensity |
|---|---|---|
| 1 | Boilerplate, tests, docs, one-off scripts | Skim & merge |
| 2 | Single-module logic, bug fixes | Line-by-line review |
| 3 | Cross-module, API surface, schema changes | Full architectural review + ADR |
| 4 | Security, secrets, auth, data loss risk | Human-only; do not delegate |

### 5.2 AI-Generated PR Rules
- Every AI-authored PR uses `Co-authored-by: <tool>` trailer in commits.
- Title still follows Conventional Commits; you write or edit it.
- You, the human, are the sole approver. No auto-merge.
- Add label `ai-authored` to the PR for later audit.
- If AI-authored code crosses a Tier 3+ boundary, STOP and rewrite or pair with fresh Tier-3 review.

### 5.3 Context Feeding
From Phase 1 end onward, **feed Contextual itself to the AI collaborators**. Claude Code + `contextual-mcp` indexing Contextual's own repo creates a closed loop:
- AI asks "how does the chunker merge siblings?" → Contextual answers from AST.
- AI asks "what ADR decided sqlite-vec?" → Contextual returns 0001 and 0007.
- This is dogfooding at full strength.

## 6. Communication & Tracking Artifacts

| Artifact | Location | Cadence |
|---|---|---|
| Tracking issue per phase | GitHub Issues | 1 per phase |
| Phase PR | GitHub PRs | 1 per phase, draft from Day 1 |
| Daily commit log | Git | Multiple per day |
| CHANGELOG.md | Repo root | Every merged PR |
| Phase retro | `docs/retros/phase-N.md` | End of each phase |
| ADR | `docs/adr/NNNN-*.md` | Per architectural decision |
| Dogfood log | `docs/retros/dogfood-log.md` | Running journal, Phase 1+ |
| Weekly status note | `docs/status/YYYY-WW.md` (optional) | Friday |

## 7. Tooling Setup (One-Time)

```bash
# Prereqs
brew install uv gh tree-sitter
uv python install 3.11

# Clone & bootstrap
gh repo clone <owner>/contextual && cd contextual
uv sync

# Pre-commit hooks
uv run pre-commit install  # ruff, black, mypy, conventional-commit-lint

# MCP Inspector (for local testing)
npx @modelcontextprotocol/inspector uv run contextual-mcp

# Claude Desktop integration (macOS example)
cat >> ~/Library/Application\ Support/Claude/claude_desktop_config.json <<'EOF'
{
  "mcpServers": {
    "contextual": {
      "command": "uv",
      "args": ["--directory", "/ABSOLUTE/PATH/TO/contextual", "run", "contextual-mcp"],
      "env": {
        "CONTEXTUAL_DB_PATH": "/Users/you/.contextual/contextual.db",
        "VOYAGE_API_KEY": "pa-...",
        "OPENAI_API_KEY": "sk-..."
      }
    }
  }
}
EOF
# Restart Claude Desktop after editing
```

## 8. Quality Gates (Enforced Throughout)

### Per-commit gates (pre-commit hooks)
- Conventional Commit lint
- `ruff` lint + format check
- `mypy --strict` on core package
- Secret scan (`gitleaks` or `trufflehog`)

### Per-PR gates (CI)
- All pre-commit hooks
- `pytest` with coverage thresholds (Phase 5: enforce; earlier phases: report only)
- Build + import smoke test
- MCP Inspector schema contract test
- Golden-eval retrieval benchmark (Phase 1+)
- Perf benchmark (Phase 1+)

### Per-release gates (tag push)
- All PR gates
- Release notes generated and human-reviewed
- PyPI publish via trusted-publisher OIDC
- GitHub Release created with tag

## 9. Security & Privacy

- **No secrets in repo.** Enforced by gitleaks pre-commit and CI.
- **API keys via env vars only.** Never logged. Log lines sanitize `VOYAGE_API_KEY`, `OPENAI_API_KEY`, `ANTHROPIC_API_KEY` automatically.
- **Local-first:** User data (indexed code) never leaves their machine unless they explicitly configure a remote embedder. This is a **core product promise**.
- **MCP over stdio only** in Phase 1–5; no HTTP exposure by default. When `streamable-http` is added (Phase 5+), bind to localhost-only and require bearer token.
- **Dependency audit in CI:** `pip-audit` on every build.

## 10. Documentation Standards

- Every package has a `README.md` with: purpose, install, quickstart, configuration.
- Every public API (MCP tool) has a docstring that becomes the tool description (FastMCP reads it).
- Every non-trivial decision has an ADR.
- `CHANGELOG.md` is the source of truth for "what changed and when."
- Every phase has a retro.

## 11. The Iron Rules (Never Violate)

1. `main` is production. Never commit directly. Never force-push.
2. Every phase has an exit-criteria checklist. No phase ships without all items green.
3. Never write to stdout in a stdio-transport MCP server.
4. Never edit an accepted ADR. Always supersede.
5. Never skip the dogfood session at the end of a phase.
6. Never delegate Tier-4 work (security, secrets, destructive DB ops) to AI.
7. Exit criteria are minimum, not ceiling. Cut scope, never cut the bar.
8. 27 days is the timeline; quality is not negotiable. If miss is inevitable, cut a *feature*, not a *test*.

## 12. Reference Documents

- `GIT_README.md` — how the repo is managed (branches, PRs, versioning, CI)
- `PROJECT_PHASES.md` — what gets built in each of 6 phases
- `PHASE_<N>.md` — exhaustive technical spec per phase (this set: PHASE_1.md now; PHASE_2.md at Phase 1 end, etc.)
- `CONTRIBUTING.md` — coding standards, dev setup
- `SECURITY.md` — vuln reporting, threat model
- `docs/adr/*` — architectural decisions (append-only)
- `docs/retros/*` — phase retrospectives
- `CHANGELOG.md` — user-facing change log