# GIT_README — Contextual Repository Strategy

## 1. Repository Model
Single monorepo: `github.com/<owner>/contextual`
Package layout under `packages/*` (see PROJECT_PHASES.md §Architecture).
Rationale: simplified code sharing, atomic changes across modules, one CI pipeline.

## 2. Branching Model — GitHub Flow + Phase Branches

### Long-lived branches
- `main` — **Production only.** Every commit on main is release-tagged and green in CI.
  Protected: no direct pushes; PR required; status checks required; linear history.

### Medium-lived branches
- `phase/<N>-<slug>` — 5–6 day lifespan, one per phase, integration branch for a single phase.
  Example: `phase/1-codebase-indexing`, `phase/2-docs-semantic`.
  Merged into `main` via squash-merge or merge-commit when phase exit criteria are met.

### Short-lived branches (optional, within a phase)
- `feat/<phase-num>/<slug>` — single feature within a phase. Max 2 days. Example: `feat/1/tree-sitter-parser`.
- `fix/<phase-num>/<slug>` — bug fix within a phase.
- `chore/<slug>` — dependency bumps, docs, tooling (not tied to a phase).
- `hotfix/<slug>` — emergency fix branched from `main`, merged to `main` AND current phase branch.

### Branch rules
- Branches >7 days old get rebased onto their parent weekly or closed.
- No branch may skip a phase boundary (no `feat/1/` branch still open when Phase 2 starts).

## 3. Commit Conventions — Conventional Commits

Format: `<type>(<scope>): <imperative subject>` (max 72 chars)

Allowed types: `feat`, `fix`, `chore`, `docs`, `refactor`, `perf`, `test`, `build`, `ci`, `revert`.
Scope = package name (`core`, `codebase`, `docs`, `temporal`, `graph`, `mcp`) or a cross-cutting concern.

Examples:
- `feat(codebase): add tree-sitter python parser`
- `fix(mcp): escape stdout writes in stdio transport`
- `chore(deps): bump sqlite-vec to 0.1.7`
- `feat(core)!: rename embeddings table schema  BREAKING CHANGE: requires re-index`

Breaking changes MUST use `!` or `BREAKING CHANGE:` footer. These trigger MAJOR version bumps.

Body (optional) explains **why**, not **how**. Footer can include `Refs: #123`, `Co-authored-by:`.

## 4. Pull Request Workflow (Solo-Dev + AI Team)

Even solo, use PRs — they are the self-review gate and automated-CI trigger.

### PR naming
Same as the squash-merge commit title: `feat(codebase): add tree-sitter parser`.

### PR description template (`.github/pull_request_template.md`)
- **What** — one-paragraph summary.
- **Why** — link to phase exit criterion or issue.
- **How** — bullet list of changes.
- **Tested** — command(s) run, golden-set pass/fail, manual dogfood notes.
- **Checklist**
  - [ ] Conventional Commit title
  - [ ] Phase exit criterion addressed (cite item #)
  - [ ] Tests added/updated
  - [ ] No stdout writes in MCP server paths
  - [ ] `alembic revision --autogenerate` run if schema changed
  - [ ] CHANGELOG.md updated

### Review
- Self-review: walk the diff, read CI output, run MCP Inspector locally.
- AI-team delegation: when an AI agent produces a PR, human (you) is the reviewer. Never auto-merge AI-generated code without reading every changed file.
- `Squash and merge` is the default; preserves a clean linear history on `main`.

## 5. Versioning — Phase-Anchored SemVer (Pre-1.0)

| Version | Meaning |
|---|---|
| `0.1.x` | Phase 1 complete + patches |
| `0.2.x` | Phase 2 complete + patches |
| `0.3.x` | Phase 3 complete + patches |
| `0.4.x` | Phase 4 complete + patches |
| `0.5.x` | Phase 5 complete (RC) + patches |
| `1.0.0` | Post-dogfood, stable public release |

Within a phase, `0.N.0` is the phase-completion tag; `0.N.1`, `0.N.2`, … are bug fixes.
Breaking changes pre-1.0 are allowed at phase boundaries only.

After 1.0: strict SemVer. MAJOR = breaking MCP tool signatures or DB schema; MINOR = new tools/features; PATCH = bug fixes.

## 6. Tagging & Releases
- Every merge to `main` is tagged `v0.N.x` if release-worthy (phase completion or patch).
- Tags are **annotated** (`git tag -a`) with release notes.
- GitHub Releases auto-generated from tags; body = CHANGELOG.md slice + auto-generated contributor list.

## 7. CHANGELOG.md
- Keep a human-curated CHANGELOG following [Keep a Changelog](https://keepachangelog.com) format.
- Sections: `Added`, `Changed`, `Deprecated`, `Removed`, `Fixed`, `Security`.
- One entry per merged PR, written in past tense.

## 8. Feature Flags

Environment-variable-driven flags toggle phase modules at server startup:
CONTEXTUAL_ENABLE_CODEBASE=true    # Phase 1 (default true from 0.1.0)
CONTEXTUAL_ENABLE_DOCS=false       # Phase 2 (flip true at 0.2.0)
CONTEXTUAL_ENABLE_TEMPORAL=false   # Phase 3
CONTEXTUAL_ENABLE_GRAPH=false      # Phase 4
Flags are deleted once their phase is GA and stable for 2+ releases.

## 9. CI/CD (GitHub Actions)

Pipeline: `.github/workflows/ci.yml`
1. **lint** — ruff, black --check, mypy
2. **test** — pytest with coverage, SQLite fixture DB
3. **build** — build wheel, validate `pyproject.toml`
4. **mcp-smoke** — start MCP server, MCP Inspector CLI calls each registered tool, assert no stderr errors
5. **golden-eval** — run retrieval eval set, assert Recall@10 ≥ baseline

Required status checks on `main`: all five green.

Release pipeline: `.github/workflows/release.yml` — on tag push matching `v*.*.*`, publish wheel to PyPI, create GitHub Release.

## 10. Production-Only `main` Discipline

- `main` branch rules (GitHub Settings → Branches):
  - Require PR before merging.
  - Require status checks: `lint`, `test`, `build`, `mcp-smoke`, `golden-eval`.
  - Require linear history.
  - Do not allow force pushes. Do not allow deletions.
- No direct commits to `main`, **ever**, including for the owner.
- Rollback strategy: revert-commit via `git revert` + PR; never `reset --hard` on `main`.

## 11. Naming Quick Reference

| Artifact | Pattern | Example |
|---|---|---|
| Phase branch | `phase/<N>-<kebab-slug>` | `phase/2-docs-semantic` |
| Feature branch | `feat/<N>/<slug>` | `feat/1/tree-sitter` |
| Commit | `<type>(<scope>): <imperative>` | `feat(codebase): add rust parser` |
| PR title | same as squash commit | `feat(codebase): add rust parser` |
| Tag | `v<MAJOR>.<MINOR>.<PATCH>` | `v0.1.0` |
| ADR | `docs/adr/NNNN-<slug>.md` | `docs/adr/0003-sqlite-over-postgres.md` |