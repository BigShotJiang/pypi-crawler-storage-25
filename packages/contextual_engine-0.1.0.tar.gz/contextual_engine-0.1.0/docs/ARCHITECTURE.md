# Architecture — Contextual

> Last updated: April 22, 2026 · Phase 0 (Pre-build)

## Overview

Contextual is a 6-layer system that transforms raw code repositories into temporally-aware, semantically-searchable knowledge — served to any AI tool via the Model Context Protocol.

```
Layer 6: Interface        MCP Server (FastMCP 3.x) + Typer CLI
Layer 5: Retrieval        BM25 + Dense → RRF → Reranker → MMR → Context Assembly
Layer 4: Knowledge        Bi-temporal Entity-Fact-Episode graph (Snodgrass/Graphiti)
Layer 3: Embedding        jina-v2-base-code (code) + nomic-v1.5 (NL), ONNX int8
Layer 2: Processing       tree-sitter chunking + git blame + context headers
Layer 1: Storage          SQLite 3.51 (WAL) + LanceDB 0.30 (vectors + FTS)
```

## Layer 1: Storage

### SQLite 3.51 — Structured Metadata and Temporal Facts

The relational backbone. Stores entities, facts (with four timestamps), episodes, and configuration. Tuned for read-heavy workloads with periodic bulk writes.

Key configuration: WAL mode, synchronous=NORMAL, 64MB page cache, 256MB mmap, FTS5 with dual tokenizers (unicode61+tokenchars for identifiers, trigram for substring).

Connection pattern: Single-writer/multi-reader pool. Writer has a dedicated mutex. Readers share WAL snapshots. automatic_index=OFF on the writer to avoid the 3.44+ recursive CTE regression.

Schema: Three core tables (entities, facts, episodes) with partial indexes on the live subset (`WHERE invalid_at IS NULL AND expired_at IS NULL`) for 10-100x smaller index scans on hot queries.

### LanceDB 0.30 — Vector Store and Hybrid Search

Embedded vector database using the Lance columnar format. Stores 768d float32 embeddings alongside chunk metadata. Process-wide async singleton via `connect_async()`.

Below 100K chunks: flat scan (no ANN index needed). Above 100K: IVF_PQ with sqrt(n) partitions, 48 sub-vectors, refine_factor=20. Native Rust FTS with BM25 for backup hybrid search. Scalar BTree indexes on path/language/chunk_type for prefilter=True queries.

Stable row IDs enabled via storage_options to support cross-referencing from SQLite.

### Workspace Isolation

Each project gets its own `.contextual/` directory containing:
- `contextual.db` — SQLite database (chmod 0o600)
- `lance/` — LanceDB data directory
- `tantivy/` — BM25 index directory
- `config.toml` — Project-local overrides

Never a global database. Never shared across projects.

## Layer 2: Processing

### Tree-sitter Chunking Pipeline

Uses `tree-sitter-language-pack` (165+ grammars, pre-compiled wheels) to parse source files into AST nodes, then chunks at top-level declarations.

Chunking parameters: 1,500 char target / 2,000 max / 50 min. Files > 2MB skipped. Files > 500KB fall back to line-based chunking. Files with AST ERROR nodes are still chunked (work-in-progress code is valid input).

Each chunk gets a deterministic structural header prepended:
```
FILE: src/auth/middleware.py
LANG: python
PARENT: AuthMiddleware
IMPORTS: from fastapi import Request
DECORATORS: @app.middleware("http")
-----
```

This header improves retrieval accuracy by ~35% (Anthropic contextual retrieval data) without requiring an LLM at index time.

Content-hash keying: `sha256(chunk_text)` is the chunk ID. A one-line edit re-embeds one chunk, not fifty.

### Git Integration

pygit2 for structured operations: `walker.hide(last_indexed_oid)` makes incremental indexing O(new commits). `commit.tree.diff_to_tree(parent.tree)` extracts per-commit file changes.

Subprocess `git blame --line-porcelain -M` for temporal attribution: each chunk gets `valid_at = max(author_time)` and `first_seen_at = min(author_time)` across its lines.

Post-commit hook: fully non-blocking (`nohup ... & disown`, always `exit 0`). Also installs `post-rewrite` for amend/rebase. File lock via `fcntl.flock` on `.git/contextual.lock`.

Force-push detection: verify `last_indexed_commit` is ancestor of HEAD via `git merge-base --is-ancestor`. If not, find common ancestor and evict abandoned rows.

## Layer 3: Embedding

### Dual-Model Architecture

Code chunks → `jina-embeddings-v2-base-code` (161M params, 768d, int8 ONNX via fastembed)
NL content → `nomic-embed-text-v1.5` (Matryoshka truncated to 256d, requires search_query:/search_document: prefixes)

Query routing: heuristic regex detects code syntax (identifiers, brackets, keywords). Code queries → Jina. NL queries → Nomic. Ambiguous → query both, merge via RRF.

Both models run CPU-only via ONNX Runtime. Batch size 64 at 512 tokens is the safe ceiling on 8GB RAM. Models pre-warmed on startup with dummy queries to avoid JIT penalty.

### Model Lifecycle

Models loaded once at startup into a singleton service. LRU cache (2000 entries) for repeated queries. Explicit `close()` releases ONNX sessions to free RAM.

## Layer 4: Knowledge — Bi-Temporal Entity-Fact-Episode Graph

The core intellectual innovation. Every piece of knowledge carries four timestamps:

| Timestamp | Meaning |
|-----------|---------|
| `valid_at` | When this fact became true in the real world |
| `invalid_at` | When this fact stopped being true (NULL = still valid) |
| `created_at` | When our system first learned this fact |
| `expired_at` | When our system retracted this belief (NULL = still believed) |

### Entity Types (Code Domain)

Function, Class, Module, File, Symbol, Decision, ADR, Dependency, Config, Endpoint

### Predicates

has_signature, calls, imports, depends_on, decided, deprecated, has_type, returns, implements, extends, overrides, tests, documents

### Contradiction Detection

For code: structural rules. Two `has_signature` edges with overlapping valid-time = contradiction → close the old one. For NL facts (commit messages, ADRs): embedding similarity threshold.

### Query Patterns

- **AS-OF**: "What was the signature of `processPayment` at commit abc123?"
- **Timeline**: "Show me all changes to `UserService` in the last 30 days"
- **Audit**: "Who changed the auth middleware and when?"
- **Current**: "What does `DatabasePool` currently depend on?"

## Layer 5: Retrieval Pipeline

The end-to-end search flow with a 600ms p95 latency budget:

```
Query (user)
  │
  ├──→ Embed query (~30ms)
  │
  ├──→ [Parallel]
  │     ├── BM25 search (tantivy, top-100) (~20ms)
  │     └── Dense search (LanceDB, top-100) (~30ms)
  │
  ├──→ Weighted RRF fusion (k=60, BM25×0.6 + Dense×0.4) (~1ms)
  │
  ├──→ Cross-encoder rerank top-30 (jina-reranker-v2, ONNX-int8) (~420ms)
  │
  ├──→ MMR diversity selection (λ=0.7, max 2/file, max 1/symbol) (~5ms)
  │
  └──→ Context assembly (15% structural, 85% content chunks) (~5ms)
```

### Code-Aware BM25

tantivy-py with a custom pre-processing tokenizer that splits camelCase and snake_case while preserving the original token: `getUserName` → `[getUserName, get, User, Name, getusername]`. Stopwords OFF (for/if/is are syntactically meaningful in code). BM25 b=0.3 (lower length normalization for code).

### Degraded Mode

If dense search fails → continue with BM25 only. If reranker fails → return RRF results directly. If BM25 fails → return dense results only. Always return something useful.

## Layer 6: Interface

### FastMCP 3.x Server

8 tools with flat Pydantic parameters (no nested models — Claude Code serializes them as JSON strings). Dual transport: stdio for editor clients, localhost Streamable HTTP for background daemon.

Error handling: `ToolError` for user-visible errors, `McpError` for protocol errors. Progress reporting via `ctx.report_progress()` for long operations (indexing).

### Typer CLI

Rich-formatted output: tables for search results, progress bars for indexing, panels for status. 10-check `doctor` command for diagnostics. TOML configuration at `~/.config/contextual/config.toml`.

### IDE Integration

8 IDEs supported with auto-configuration: Claude Desktop, Claude Code, Cursor, VS Code Copilot, Gemini CLI, Windsurf, ChatGPT Desktop, Zed. Each has different config format/location — the `contextual setup <ide>` command handles all differences.

## Data Flow: Index Operation

```
1. User runs `contextual index .` or post-commit hook fires
2. Git: Walk new commits since last_indexed_oid
3. Diff: Extract changed file paths
4. Filter: Apply .gitignore + .contextualignore, skip binary/generated/large files
5. Parse: tree-sitter → AST → top-level declaration nodes
6. Chunk: Split-merge to 1500-char targets with structural headers
7. Dedup: sha256 content-hash, skip unchanged chunks
8. Embed: jina-v2-base-code int8 for code, nomic-v1.5 for NL content
9. Store: Batch insert to LanceDB (vectors) + SQLite (metadata + facts)
10. BM25: Index chunk text in tantivy with code-aware tokenization
11. Blame: Attribute temporal valid_at per chunk from git blame
12. Facts: Generate entity-predicate-object triples with temporal metadata
13. Optimize: Run LanceDB compaction if fragment count exceeds threshold
```

## Data Flow: Search Operation

```
1. MCP client sends search tool call with query string
2. Route: Detect code vs NL query type
3. Embed: Generate query embedding with appropriate model
4. Search: Parallel BM25 (tantivy top-100) + Dense (LanceDB top-100)
5. Fuse: Weighted RRF k=60 → ranked candidate list
6. Hydrate: Fetch full chunk content for top-30
7. Rerank: jina-reranker-v2 cross-encoder scoring
8. Diversify: MMR selection (max 2/file, max 1/symbol)
9. Assemble: Build context within token budget (15% structural + 85% content)
10. Return: Wrapped in <untrusted_content> markers
```

## Security Architecture

Threat model: Contextual is a content indexer whose outputs go to LLMs. The primary threat is **indirect prompt injection** via indexed files (CVE-2025-54135 class).

Defenses:
- All tool outputs wrapped in `<untrusted_content>` markers
- Unicode category Cf stripped from all indexed text
- Path traversal prevented by resolve-then-check pattern
- SQL injection prevented by parameterized queries + FTS5 phrase-quoting
- No outbound HTTP tools (avoids the "lethal trifecta")
- Workspace isolation: separate DB per project, never global
- Config file integrity: hash on load, alert on unexpected change
- File permissions: umask(0o077), DB files 0o600, directories 0o700
