# Technical Specification — Contextual v0.1.0

> This document is the single source of truth for implementation details.
> Every constant, pragma, schema, and algorithm parameter is defined here.

## 1. Dependency Matrix

| Package | Version Pin | Purpose | License |
|---------|------------|---------|---------|
| fastmcp | >=3.2,<4 | MCP server framework | Apache-2.0 |
| lancedb | >=0.26,<0.31 | Embedded vector store | Apache-2.0 |
| tree-sitter-language-pack | >=0.7.2 | AST parsing (165+ grammars) | MIT |
| pygit2 | >=1.15 | Git operations (libgit2 bindings) | GPL-2.0 w/ linking exception |
| fastembed | >=0.5.1 | ONNX embedding inference | Apache-2.0 |
| tantivy | >=0.20.1 | Rust BM25 search engine | MIT |
| typer[all] | >=0.22,<1.0 | CLI framework (bundled Rich) | MIT |
| structlog | >=25.4 | Structured logging | MIT |
| platformdirs | >=3.3 | XDG-compliant path resolution | MIT |
| pathspec | >=0.10 | Gitignore-style pattern matching | MPL-2.0 |
| pydantic | >=2.0 | Data validation + schemas | MIT |
| pyarrow | >=14.0 | Columnar data (LanceDB backend) | Apache-2.0 |
| numpy | >=1.26 | Array operations | BSD-3 |

## 2. SQLite Configuration

### 2.1 Pragma Block (every connection)

```sql
PRAGMA journal_mode = WAL;
PRAGMA synchronous = NORMAL;
PRAGMA busy_timeout = 5000;
PRAGMA cache_size = -64000;           -- 64 MiB
PRAGMA mmap_size = 268435456;         -- 256 MiB
PRAGMA temp_store = MEMORY;
PRAGMA foreign_keys = ON;
PRAGMA journal_size_limit = 67108864; -- 64 MiB
PRAGMA wal_autocheckpoint = 4000;     -- pages
PRAGMA trusted_schema = OFF;
PRAGMA optimize;
```

Writer connection additionally: `PRAGMA automatic_index = OFF;`

### 2.2 Schema DDL

```sql
CREATE TABLE IF NOT EXISTS entities (
    id          INTEGER PRIMARY KEY,
    name        TEXT NOT NULL,
    entity_type TEXT NOT NULL,     -- Function, Class, Module, File, Symbol, Decision, ADR, Dependency
    metadata    TEXT,              -- JSON blob
    created_at  INTEGER NOT NULL   -- unix-ms UTC
) STRICT;

CREATE TABLE IF NOT EXISTS episodes (
    id        INTEGER PRIMARY KEY,
    source    TEXT NOT NULL,       -- 'commit', 'file', 'user', 'hook'
    content   TEXT,               -- Raw ingested data for provenance
    timestamp INTEGER NOT NULL,   -- unix-ms UTC
    metadata  TEXT                -- JSON blob
) STRICT;

CREATE TABLE IF NOT EXISTS facts (
    id         INTEGER PRIMARY KEY,
    entity_id  INTEGER NOT NULL REFERENCES entities(id),
    object_id  INTEGER REFERENCES entities(id),   -- NULL for literal values
    predicate  TEXT NOT NULL,      -- has_signature, calls, imports, depends_on, decided, deprecated
    value      TEXT,               -- Literal value (signature string, version, etc.)
    valid_at   INTEGER NOT NULL,   -- When this became true (from git blame)
    invalid_at INTEGER,            -- When this stopped being true (NULL = still valid)
    created_at INTEGER NOT NULL,   -- When we recorded this
    expired_at INTEGER,            -- When we retracted this belief (NULL = still believed)
    episode_id INTEGER REFERENCES episodes(id),
    confidence REAL,               -- 0.0–1.0
    source     TEXT                -- 'tree-sitter', 'git-blame', 'user', 'llm-extract'
) STRICT;

-- Workhorse index: entity lookup by predicate and time
CREATE INDEX IF NOT EXISTS idx_facts_entity_pred_valid
    ON facts(entity_id, predicate, valid_at DESC, invalid_at);

-- Hot path: currently believed facts (partial index, 10-100x smaller)
CREATE INDEX IF NOT EXISTS idx_facts_live
    ON facts(entity_id, predicate, valid_at DESC)
    WHERE invalid_at IS NULL AND expired_at IS NULL;

-- Reverse lookup: "who references this entity?"
CREATE INDEX IF NOT EXISTS idx_facts_object
    ON facts(object_id, predicate, valid_at DESC)
    WHERE object_id IS NOT NULL;

-- Timeline queries
CREATE INDEX IF NOT EXISTS idx_facts_timeline
    ON facts(entity_id, valid_at, invalid_at, created_at);

-- Schema version tracking
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY,
    applied_at INTEGER NOT NULL
) STRICT;
```

### 2.3 FTS5 External Content Tables

```sql
-- Content source table
CREATE TABLE IF NOT EXISTS code_blobs (
    rowid    INTEGER PRIMARY KEY,
    path     TEXT NOT NULL,
    language TEXT NOT NULL,
    content  TEXT NOT NULL
) STRICT;

-- Identifier search (camelCase-aware via tokenchars)
CREATE VIRTUAL TABLE IF NOT EXISTS code_fts_ident USING fts5(
    content,
    tokenize = "unicode61 tokenchars '_-$.'",
    prefix = '2 3 4',
    content = 'code_blobs',
    content_rowid = 'rowid'
);

-- Substring search (trigram)
CREATE VIRTUAL TABLE IF NOT EXISTS code_fts_trigram USING fts5(
    content,
    tokenize = "trigram case_sensitive 0",
    content = 'code_blobs',
    content_rowid = 'rowid'
);
```

Three mandatory triggers (INSERT, DELETE, UPDATE) required — see Perplexity research doc §1.c for exact SQL.

## 3. LanceDB Configuration

### 3.1 Connection

```python
conn = await lancedb.connect_async(
    uri=str(project_root / ".contextual" / "lance"),
    storage_options={"new_table_enable_stable_row_ids": "true"},
)
```

### 3.2 Code Chunks Schema (PyArrow)

```python
CODE_CHUNK_SCHEMA = pa.schema([
    pa.field("vector", pa.fixed_size_list(pa.field("item", pa.float32(), nullable=False), 768), nullable=False),
    pa.field("path", pa.string(), nullable=False),
    pa.field("language", pa.string(), nullable=False),
    pa.field("symbol_name", pa.string()),
    pa.field("chunk_type", pa.string()),         # function, class, module, method
    pa.field("content_hash", pa.string(), nullable=False),
    pa.field("header", pa.string(), nullable=False),
    pa.field("body", pa.string(), nullable=False),
    pa.field("model_type", pa.string()),          # jina-v2-code, nomic-v1.5-256d
])
```

### 3.3 Index Strategy

- Below 100K chunks: flat scan (no ANN index)
- Above 100K: `IVF_PQ(distance_type="l2", num_partitions=sqrt(n), num_sub_vectors=48, refine_factor=20)`
- Scalar BTree indexes on: path, language, chunk_type
- FTS index on: body (simple tokenizer, English, lowercase, stemming, ASCII folding)

### 3.4 Maintenance

- `table.optimize(cleanup_older_than=timedelta(days=3))` after bulk inserts
- `create_index(replace=True)` after significant data changes
- Never insert one row at a time — batch with PyArrow tables

## 4. Embedding Models

### 4.1 Code: jina-embeddings-v2-base-code

| Property | Value |
|----------|-------|
| Model ID | jinaai/jina-embeddings-v2-base-code |
| Parameters | 161M |
| Dimensions | 768 |
| Context | 8,192 tokens |
| Quantization | int8 ONNX |
| Size on disk | ~165MB |
| Pooling | Mean |
| Symmetry | Symmetric (no prefix needed) |
| Batch size (safe) | 64 @ 512 tokens |
| Throughput | ~18 docs/sec (int8, 128 seq) |

### 4.2 Natural Language: nomic-embed-text-v1.5

| Property | Value |
|----------|-------|
| Model ID | nomic-ai/nomic-embed-text-v1.5 |
| Dimensions | 768 → truncated to 256 (Matryoshka) |
| Prefix (query) | `search_query: ` (MANDATORY) |
| Prefix (document) | `search_document: ` (MANDATORY) |
| Quality at 256d | 98% of full 768d |

### 4.3 Reranker: jina-reranker-v2-base-multilingual

| Property | Value |
|----------|-------|
| Parameters | 278M |
| Context | 1024 tokens |
| Input | (query, passage) pairs |
| Max pairs | 30 (latency constraint) |
| Truncation | Hard-truncate passage at 512 tokens |
| Latency (30 pairs) | ~420ms on M2 Air |

## 5. Retrieval Pipeline Parameters

| Parameter | Value | Rationale |
|-----------|-------|-----------|
| BM25 candidates | Top-100 | Broad recall net |
| Dense candidates | Top-100 | Broad recall net |
| RRF k | 60 | Standard (Cormack et al. 2009) |
| RRF BM25 weight | 0.6 | Identifiers dominate code queries |
| RRF Dense weight | 0.4 | Semantic understanding secondary |
| Rerank input | Top-30 | Latency ceiling at 30 pairs |
| MMR λ | 0.7 | Favor relevance over diversity |
| MMR max per file | 2 | Prevent file domination |
| MMR max per symbol | 1 | Prevent symbol repetition |
| Context budget structural | 15% | File tree, imports, class hierarchy |
| Context budget content | 85% | Actual code chunks |

## 6. Tree-sitter Chunking Parameters

| Parameter | Value |
|-----------|-------|
| Target chunk size | 1,500 chars |
| Maximum chunk size | 2,000 chars |
| Minimum chunk size | 50 chars |
| Max file size | 2 MB (skip above) |
| Line-based fallback threshold | 500 KB |
| Content hash algorithm | SHA-256 |
| Supported languages | python, typescript, javascript, tsx, go, java, rust, c_sharp |
| Config formats | json, yaml, toml, dockerfile, markdown |

### 6.1 Top-Level Node Types Per Language

| Language | Node Types |
|----------|-----------|
| Python | function_definition, class_definition, decorated_definition |
| TypeScript/JS/TSX | function_declaration, class_declaration, interface_declaration, export_statement, lexical_declaration |
| Go | function_declaration, type_declaration, method_declaration |
| Java | class_declaration, method_declaration, interface_declaration |
| Rust | function_item, impl_item, struct_item, enum_item, trait_item |
| C# | class_declaration, method_declaration, interface_declaration |

### 6.2 Structural Header Format

```
FILE: <relative_path>
LANG: <language>
PARENT: <parent_class_or_module>
IMPORTS:
<imports_or_none>
DECORATORS:
<decorators_or_none>
-----
<chunk_body>
```

## 7. Git Integration Parameters

| Parameter | Value |
|-----------|-------|
| Library | pygit2 >=1.15 |
| Blame method | subprocess `git blame --line-porcelain -M` |
| Walk order | TOPOLOGICAL \| REVERSE |
| Incremental | walker.hide(last_indexed_oid) |
| Hook type | post-commit + post-rewrite |
| Hook pattern | nohup ... & disown, exit 0 |
| Lock file | .git/contextual.lock (fcntl.flock) |
| Shallow clone support | No (blame attribution breaks) |

### 7.1 Temporal Attribution

```
per-chunk valid_at    = max(author_time) across chunk's lines
per-chunk first_seen_at = min(author_time) across chunk's lines
```

## 8. MCP Tool Contracts

### 8.1 Tool: index

```
Input:  { path: str, languages: list[str]|null, force: bool }
Output: { files_indexed: int, chunks_created: int, duration_ms: int }
Errors: INVALID_PATH, DB_LOCKED, TIMEOUT
Progress: ctx.report_progress(i, total) per file
```

### 8.2 Tool: search

```
Input:  { query: str, top_k: int=10, language: str|null, file_pattern: str|null }
Output: list[{ chunk_id: str, file_path: str, symbol: str, content: str, score: float, relevance_explanation: str }]
Errors: QUERY_TOO_BROAD, INDEX_NOT_FOUND
```

### 8.3 Tool: recall

```
Input:  { entity: str, as_of: int|null, predicate: str|null }
Output: list[{ entity: str, predicate: str, value: str, valid_at: int, invalid_at: int|null, confidence: float }]
Errors: ENTITY_NOT_FOUND
```

### 8.4 Tool: capture_decision

```
Input:  { title: str, context: str, decision: str, consequences: str|null, tags: list[str]|null }
Output: { decision_id: str, created_at: int }
Errors: INVALID_PATH (title blank)
```

### 8.5 Tool: freshness

```
Input:  { path: str|null }
Output: { last_indexed_at: int, commits_behind: int, stale_files_count: int }
Errors: INDEX_NOT_FOUND, INVALID_PATH
```

### 8.6 Tool: status

```
Input:  {}
Output: { index_stats: dict, model_status: dict, db_size: int, uptime: int }
Errors: (none)
```

### 8.7 Tool: forget

```
Input:  { fact_id: str, reason: str }
Output: { expired_at: int, confirmation: str }
Errors: ENTITY_NOT_FOUND
```

### 8.8 Tool: timeline

```
Input:  { entity: str, from_time: int|null, to_time: int|null }
Output: list[{ entity: str, predicate: str, value: str, valid_at: int, invalid_at: int|null }]
Errors: ENTITY_NOT_FOUND
```

## 9. Observability

### 9.1 structlog Pipeline

```python
processors = [
    structlog.contextvars.merge_contextvars,
    structlog.stdlib.add_log_level,
    structlog.processors.TimeStamper(fmt="iso", utc=True),
    structlog.processors.StackInfoRenderer(),
    structlog.processors.format_exc_info,
    structlog.processors.CallsiteParameterAdder(),
    structlog.processors.JSONRenderer(),  # file output
]
```

Console: `ConsoleRenderer()` when isatty(). File: `RotatingFileHandler` at `$XDG_STATE_HOME/contextual/logs/contextual.log` (10MB, 5 backups).

### 9.2 Graceful Shutdown Sequence

1. Receive SIGTERM/SIGINT
2. Stop accepting new MCP requests
3. Drain in-flight tasks (10s timeout)
4. `PRAGMA wal_checkpoint(TRUNCATE)` — check return for SQLITE_BUSY
5. Close LanceDB connections
6. Flush and close log handlers
7. Exit 0

### 9.3 Health Check

MCP built-in `ping` method (2-5s timeout) + custom `status` tool with cached (30s) index counts.

## 10. File Paths

| Path | Purpose |
|------|---------|
| `<project>/.contextual/` | Project workspace (created on first index) |
| `<project>/.contextual/contextual.db` | SQLite database |
| `<project>/.contextual/lance/` | LanceDB vector data |
| `<project>/.contextual/tantivy/` | BM25 index |
| `<project>/.contextualignore` | Project-specific ignore patterns |
| `~/.config/contextual/config.toml` | User-level configuration |
| `$XDG_STATE_HOME/contextual/logs/` | Log files |
| `$XDG_STATE_HOME/contextual/metrics.jsonl` | Local metrics |
