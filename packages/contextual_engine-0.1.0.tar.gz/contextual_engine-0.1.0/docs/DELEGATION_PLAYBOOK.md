# Delegation Playbook — AI Team Task Guide

> How to assign work to our AI team members. Every prompt must include: task spec, file paths, naming conventions, guardrails, and expected output format.

## Team Roster

### Team A — Chat LLMs (Research + Code Generation)

| Member | Strengths | Best For |
|--------|-----------|----------|
| **Gemini Pro** | Code gen, deep research, multimodal | Complex algorithm implementations, research synthesis, architecture validation |
| **ChatGPT** | Creative thinking, broad coverage, design | Boilerplate generation, documentation, test scaffolding, CI/CD configs |
| **Perplexity Pro** | Citation-heavy research, long code gen | Technical deep dives, library API research, complete module generation |

### Team B — AI IDEs (Surgical Code + In-Codebase Work)

| Member | Model | Best For |
|--------|-------|----------|
| **Copilot (Gemini 2.5 Pro)** | Coding, featuring | Feature implementation in existing files, wiring modules |
| **Copilot (Claude Haiku 4.5)** | Debugging, wiring | Bug fixes, import wiring, quick patches |
| **Cursor IDE** | Free tier | Code gen, audit, planning, debugging |
| **Antigravity IDE** | Gemini Pro 3.1 + Claude Sonnet/Opus 4.5 | System design, logic, complex code gen |
| **Codex (ChatGPT 5.2)** | High thinking | Large-scale code generation, architectural coding |
| **Claude Code** | Haiku + Sonnet | MCP-native coding, direct codebase access |

## Delegation Principles

1. **Never delegate what you haven't designed** — Define the interface, contract, and tests before handing off implementation.
2. **Context is everything** — AI team members are context-less. Every prompt must be self-contained.
3. **Guardrails are mandatory** — Specify what they CAN and CANNOT do. File paths they can touch. Patterns they must follow.
4. **Verify everything** — AI-generated code is a first draft. Review, test, and validate before merging.
5. **One task per prompt** — Don't overload. Single responsibility per delegation.

## Prompt Template

```markdown
# Task: [CLEAR_TITLE]

## Context
[What this module does, where it fits in the system, what depends on it]

## Specification
- File: `contextual/[module].py`
- Class/Function: `[Name]`
- Interface:
  ```python
  async def function_name(param: Type) -> ReturnType:
      """One-line description."""
  ```

## Requirements
- Python 3.12+ with `from __future__ import annotations`
- Type hints on ALL functions and parameters
- Google-style docstrings
- structlog logging: `logger = structlog.get_logger(__name__)`
- Error handling: [specific patterns]
- Tests: Write pytest tests in `tests/unit/test_[module].py`

## Dependencies (already installed)
[List exact packages they can import]

## Guardrails
- DO NOT modify any file outside `contextual/[module].py` and `tests/unit/test_[module].py`
- DO NOT add new dependencies
- DO NOT use f-strings in SQL queries — parameterized ? only
- DO NOT use `trust_remote_code=True`
- DO NOT create global state — use dependency injection

## Expected Output
- Complete Python module with all functions implemented
- Complete test file with ≥5 test cases
- Brief explanation of design decisions
```

## Task Catalog — Week 1

### TASK-W1-001: SQLite Connection Pool
**Assign to**: Copilot (Gemini 2.5 Pro) or Cursor
**File**: `contextual/storage/sqlite_pool.py`
**Spec**: Single-writer/multi-reader pool using sqlite3 stdlib. Writer has mutex (threading.Lock). Readers use queue.Queue(maxsize=4). All connections get pragma block from TECHNICAL_SPEC §2.1. Writer gets additional automatic_index=OFF. Context managers for writer() and reader(). initialize_schema() method.
**Guardrails**: No ORM, no aiosqlite for MVP, no external dependencies beyond structlog.

### TASK-W1-002: Schema DDL Module
**Assign to**: Copilot (Claude Haiku 4.5)
**File**: `contextual/storage/schema.py`
**Spec**: All CREATE TABLE/INDEX/TRIGGER statements from TECHNICAL_SPEC §2.2 and §2.3 as module-level SQL strings. Function `apply_schema(conn)` that executescripts them.
**Guardrails**: Exact DDL from spec. No modifications. STRICT tables. INTEGER timestamps only.

### TASK-W1-003: Migration Runner
**Assign to**: ChatGPT or Perplexity
**File**: `contextual/storage/migrations.py`
**Spec**: Version table (schema_version). Idempotent migration functions. Runner checks current version, applies pending migrations in order. No Alembic.
**Guardrails**: Max 100 lines. Must handle first-run (empty DB) gracefully.

### TASK-W1-004: File Discovery + Filtering
**Assign to**: Copilot (Gemini 2.5 Pro)
**File**: `contextual/indexing/processor.py` (partial — just discovery)
**Spec**: Walk directory tree. Apply .gitignore + .contextualignore via pathspec. Skip binary files, generated code markers, files > 2MB. Detect language by extension (mapping from TECHNICAL_SPEC §6).
**Guardrails**: Use pathspec library. os.walk, not glob. Relative paths from project root.

### TASK-W1-005: Tree-sitter Chunking (Python + TypeScript)
**Assign to**: Gemini Pro (Chat) — generate full module
**File**: `contextual/indexing/chunker.py`
**Spec**: ParserPool class. chunk_file() function. Top-level node extraction for Python and TypeScript (node types from TECHNICAL_SPEC §6.1). Split-merge to 1500/2000/50 targets. Structural header generation (format from TECHNICAL_SPEC §6.2). Content-hash dedup.
**Guardrails**: tree-sitter-language-pack only (NOT tree-sitter-languages). Bytes not chars for tree-sitter. sha256 for content hash. Handle ERROR nodes gracefully.

### TASK-W1-006: Tree-sitter Queries (Go, Java, Rust, C#)
**Assign to**: Perplexity Pro or ChatGPT — research + code gen
**Spec**: Extend chunker.py with top-level node extraction for Go, Java, Rust, C#. Provide the S-expression queries and node type lists.
**Guardrails**: Must follow same patterns as Python/TS. Add to LANGUAGE_KEYS mapping.

### TASK-W1-007: Git Integration Module
**Assign to**: Codex (ChatGPT 5.2) or Antigravity (Claude Opus 4.5)
**File**: `contextual/indexing/git_integration.py`
**Spec**: GitRepo class wrapping pygit2. Methods: incremental_walk(since_oid), get_changed_files(commit), blame_file(path), install_hooks(). Blame via subprocess, not libgit2. Force-push detection. File locking.
**Guardrails**: pygit2 for walk/diff only. subprocess for blame. Never modify .git/ contents except hooks. Hook scripts must exit 0 always.

## Task Catalog — Week 2

### TASK-W2-001: Code Embedding Service
**Assign to**: Gemini Pro (Chat) — full module
**File**: `contextual/indexing/embedder.py`
**Spec**: CodeEmbeddingService (jina-v2) + TextEmbeddingService (nomic-v1.5) + MultiModelRouter. Async wrappers via asyncio.to_thread. LRU cache. Model warmup. Query type detection (code vs NL).
**Guardrails**: fastembed only (not sentence-transformers). No GPU code. Batch size ≤64.

### TASK-W2-002: Tantivy BM25 Index
**Assign to**: Perplexity Pro — research + code gen
**File**: `contextual/retrieval/sparse.py`
**Spec**: CodeLexicalIndex class. Code-aware tokenizer (camelCase/snake_case split + preserve original). Schema: chunk_id, content, file_path, symbol. Search returns (chunk_id, score) tuples. Stopwords OFF. BM25 b=0.3.
**Guardrails**: tantivy-py only. Pre-process tokenization (not custom C tokenizer).

### TASK-W2-003: RRF Fusion Module
**Assign to**: Copilot (any model) — straightforward algorithm
**File**: `contextual/retrieval/fusion.py`
**Spec**: HybridFusion class. Weighted RRF: k=60, lex_weight=0.6, dense_weight=0.4. Input: two lists of (doc_id, score). Output: sorted list of (doc_id, fused_score). Handle documents appearing in only one list.
**Guardrails**: ~50 lines max. No external dependencies. Pure Python.

### TASK-W2-004: Reranker + MMR
**Assign to**: Gemini Pro (Chat)
**File**: `contextual/retrieval/reranker.py`
**Spec**: RerankService class. jina-reranker-v2 via fastembed TextReranker. Hard-truncate passages at 512 tokens. MMR selection: λ=0.7, max 2/file, max 1/symbol. Budget-aware context assembly (15% structural, 85% content).
**Guardrails**: Cap rerank input at 30 pairs. Never rerank more than 30. fastembed only.

## Task Catalog — Week 3

### TASK-W3-001: FastMCP Server
**Assign to**: Claude Code — it understands MCP natively
**File**: `contextual/mcp_server.py`
**Spec**: 8 tools per TECHNICAL_SPEC §8. Flat Pydantic params. ToolError + ErrorCode enum. Progress reporting. Dual transport.
**Guardrails**: FLAT params only. No nested Pydantic models. fastmcp>=3.2,<4.

### TASK-W3-002: Typer CLI
**Assign to**: ChatGPT or Codex — broad coverage, good at CLI patterns
**File**: `contextual/cli.py`
**Spec**: All commands from CLAUDE.md. Rich tables for search results. Progress bars for indexing. Doctor command with 10 checks.
**Guardrails**: Typer[all]>=0.22. Use Rich for output. platformdirs for paths.

### TASK-W3-003: IDE Setup Module
**Assign to**: Copilot (any model)
**File**: `contextual/integrations/ide_setup.py`
**Spec**: setup_ide(ide_name) function. Read existing config, merge our entry, write back. Support all 8 IDEs from ADR-005 config matrix.
**Guardrails**: Non-destructive merge. Don't overwrite existing MCP servers. JSON formatting preserved.

### TASK-W3-004: Security Module
**Assign to**: Antigravity (Claude Opus 4.5) — security requires careful reasoning
**File**: `contextual/security/`
**Spec**: safe_path(), quote_fts5(), strip_invisible(), init_workspace(). All patterns from ADR-006.
**Guardrails**: Catch both OSError and RuntimeError for Path.resolve. Test Windows reserved names.

## Task Catalog — Week 4

### TASK-W4-001: CI Pipeline
**Assign to**: ChatGPT — good at YAML/config generation
**File**: `.github/workflows/ci.yml`
**Spec**: Matrix: ubuntu-latest, macos-14, windows-latest × py3.12, 3.13. astral-sh/setup-uv@v7. Cache on uv.lock. NUMBA_DISABLE_JIT=1.
**Guardrails**: Separate build and test jobs. No publish in CI (separate release workflow).

### TASK-W4-002: Release Workflow
**Assign to**: ChatGPT
**File**: `.github/workflows/release.yml`
**Spec**: Triggered on tag push. Build wheels. Publish to PyPI via pypa/gh-action-pypi-publish. Sigstore attestations. Protected release environment.
**Guardrails**: Only publish job gets id-token: write. Filename must exactly match PyPI publisher config.

### TASK-W4-003: pyproject.toml
**Assign to**: Copilot (any)
**File**: `pyproject.toml`
**Spec**: hatchling backend. All deps from TECHNICAL_SPEC §1. Entry point: contextual = "contextual.cli:app". Python >=3.12.
**Guardrails**: Pin ranges not exact versions. Include dev dependencies group.

## Verification Checklist (After Every Delegation)

- [ ] Code compiles and imports without errors
- [ ] All functions have type hints
- [ ] All functions have docstrings
- [ ] structlog used (not print/logging)
- [ ] No f-strings in SQL
- [ ] No global mutable state
- [ ] Tests exist and pass
- [ ] No new dependencies added without approval
- [ ] File paths match project structure in CLAUDE.md
- [ ] Error handling follows ErrorCode enum pattern
