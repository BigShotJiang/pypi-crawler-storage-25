# Roadmap — Contextual MVP (30-Day Sprint)

> Start: April 21, 2026 · Launch: May 21, 2026
> Solo founder + AI team (Claude, Gemini, ChatGPT, Perplexity, Copilot, Cursor, Codex)

## Critical Path

```
Week 1: Foundation    → Storage + Parsing + Git (the data must flow)
Week 2: Intelligence  → Embedding + Retrieval + Temporal (the brain)
Week 3: Interface     → MCP Server + CLI + IDE Integration (the face)
Week 4: Polish        → Testing + Security + Packaging + Launch (the ship)
```

## Week 1: Foundation (Apr 21–27)

The goal: raw code goes in, structured chunks with temporal metadata come out.

### Day 1-2: Project Scaffold + SQLite Layer
- [ ] Initialize repo: `uv init contextual`, pyproject.toml, ruff/mypy config
- [ ] Set up directory structure per CLAUDE.md spec
- [ ] Implement `storage/sqlite_pool.py` — Single-writer/multi-reader pool
- [ ] Implement `storage/schema.py` — DDL for entities, facts, episodes tables
- [ ] Implement `storage/migrations.py` — Version table + migration runner
- [ ] All SQLite pragmas configured (WAL, NORMAL, cache, mmap, FTS5)
- [ ] FTS5 external-content tables with all three triggers
- [ ] Unit tests for pool, schema creation, CRUD operations
- **Delegatable**: Schema DDL generation, migration runner boilerplate → Copilot/Cursor
- **Owner does**: Pool architecture, pragma tuning, test validation

### Day 3-4: Tree-sitter Chunking Pipeline
- [ ] Implement `indexing/chunker.py` — Full chunking pipeline
- [ ] File discovery with .gitignore + .contextualignore filtering (pathspec)
- [ ] Language detection (7 languages + config formats)
- [ ] AST parsing → top-level node extraction per language
- [ ] Split-merge algorithm (1500/2000/50 char targets)
- [ ] Structural header generation (file, parent, imports, decorators)
- [ ] Content-hash dedup (sha256)
- [ ] Parser pool (thread-safety)
- [ ] Edge cases: ERROR nodes, large files, binary detection, generated code
- [ ] Unit tests with sample files per language
- **Delegatable**: Language-specific node queries (Go, Java, Rust, C#) → Gemini/Perplexity
- **Owner does**: Core algorithm, Python/TS queries, header format, dedup logic

### Day 5-6: Git Integration
- [ ] Implement `indexing/git_integration.py`
- [ ] pygit2 repo open + incremental commit walking
- [ ] Per-commit diff extraction (changed files)
- [ ] Subprocess blame parsing (--line-porcelain -M)
- [ ] Temporal attribution: valid_at = max(author_time) per chunk
- [ ] Force-push/rebase detection (merge-base --is-ancestor)
- [ ] Post-commit + post-rewrite hook installation
- [ ] File locking (fcntl.flock)
- [ ] Unit tests with test repos (init, commit, amend, rebase scenarios)
- **Delegatable**: Hook scripts, blame parser → Copilot
- **Owner does**: Incremental walk logic, rebase detection, temporal attribution

### Day 7: LanceDB Store + Integration
- [ ] Implement `storage/lance_store.py` — Async singleton + CRUD
- [ ] PyArrow schema for code chunks (768d vector + metadata)
- [ ] Batch insert pattern
- [ ] Index management (scalar, FTS, IVF_PQ threshold)
- [ ] Compaction and version cleanup
- [ ] Integration test: chunker → git → LanceDB + SQLite end-to-end
- **Delegatable**: Schema definition, batch insert boilerplate → Cursor
- **Owner does**: Singleton pattern, index strategy, integration wiring

### Week 1 Exit Criteria
- [ ] Can index a real Python project (e.g., FastMCP source)
- [ ] Chunks stored in LanceDB with content-hash dedup
- [ ] Facts stored in SQLite with temporal metadata from git blame
- [ ] FTS5 indexes populated and queryable
- [ ] All unit tests pass on macOS ARM

## Week 2: Intelligence (Apr 28–May 4)

The goal: queries return semantically relevant, temporally-aware results.

### Day 8-9: Embedding Service
- [ ] Implement `indexing/embedder.py` — Dual-model service
- [ ] jina-v2-base-code via fastembed (int8 ONNX, mean pooling)
- [ ] nomic-embed-text-v1.5 via fastembed (search_query: prefix, 256d truncation)
- [ ] Query routing: code vs NL detection heuristic
- [ ] Async wrapper (asyncio.to_thread for inference)
- [ ] LRU cache (2000 entries)
- [ ] Model warmup on init
- [ ] Benchmark: docs/sec at batch sizes 32, 64, 128 on target hardware
- **Delegatable**: Nomic integration, cache implementation → Copilot
- **Owner does**: Jina integration, routing logic, async wrapper, benchmarking

### Day 10-11: BM25 Sparse Search (tantivy-py)
- [ ] Implement `retrieval/sparse.py` — Code-aware BM25
- [ ] tantivy index schema (chunk_id, content, file_path, symbol)
- [ ] Code-aware tokenizer: camelCase/snake_case splitting + original preservation
- [ ] Stopwords OFF, BM25 b=0.3
- [ ] Batch document indexing
- [ ] Search with score return
- [ ] Integration with chunking pipeline
- **Delegatable**: Tokenizer regex, index schema → ChatGPT
- **Owner does**: Tantivy integration, tokenizer validation, search quality

### Day 12-13: Hybrid Retrieval Pipeline
- [ ] Implement `retrieval/dense.py` — LanceDB vector search wrapper
- [ ] Implement `retrieval/fusion.py` — Weighted RRF (k=60, BM25×0.6, Dense×0.4)
- [ ] Implement `retrieval/reranker.py` — jina-reranker-v2 + MMR
- [ ] Implement `retrieval/context_assembly.py` — Token-budget builder
- [ ] Implement `core/engine.py` — End-to-end orchestrator
- [ ] Parallel search, fusion, rerank, MMR, assembly wired together
- [ ] Degraded mode: fallbacks when components fail
- [ ] Latency instrumentation (structlog timing per phase)
- **Delegatable**: RRF implementation, MMR algorithm → Gemini
- **Owner does**: Orchestrator, reranker integration, latency profiling

### Day 14: Bi-Temporal Query Layer
- [ ] Implement `storage/temporal.py` — Temporal query helpers
- [ ] AS-OF queries with parameterized valid_at
- [ ] Timeline queries (entity history)
- [ ] Contradiction detection (structural rules for code facts)
- [ ] Fact invalidation (set invalid_at + expired_at, never delete)
- [ ] Integration test: index repo → modify code → re-index → verify temporal correctness
- **Delegatable**: SQL query templates → Copilot
- **Owner does**: Contradiction logic, temporal correctness tests

### Week 2 Exit Criteria
- [ ] `contextual search "query"` returns ranked results in <600ms
- [ ] `contextual recall "Entity"` returns temporally-correct facts
- [ ] BM25 + Dense + RRF + Reranker pipeline fully operational
- [ ] Embedding models load and infer on M2 Air 8GB without OOM
- [ ] Degraded mode works when individual components fail
- [ ] **YC S26 application submitted** (deadline May 4)

## Week 3: Interface (May 5–11)

The goal: users can install and use Contextual with any AI tool.

### Day 15-16: FastMCP Server
- [ ] Implement `mcp_server.py` — All 8 tools
- [ ] Pydantic input/output models (flat parameters only)
- [ ] Error handling (ToolError + ErrorCode enum)
- [ ] Progress reporting for index tool
- [ ] Dual transport: stdio + Streamable HTTP
- [ ] Lifespan: model warmup on startup, WAL checkpoint on shutdown
- [ ] Integration test: FastMCP in-memory client calls all 8 tools
- **Delegatable**: Pydantic model definitions, tool stubs → Cursor/Codex
- **Owner does**: Tool wiring to engine, error handling, transport config

### Day 17-18: Typer CLI
- [ ] Implement `cli.py` — All commands
- [ ] Rich output: tables, progress bars, panels
- [ ] `doctor` command (10 diagnostic checks)
- [ ] `serve` command (stdio/HTTP mode selection)
- [ ] `config` command (TOML management)
- [ ] `setup <ide>` command (auto-configure 8 IDEs)
- [ ] Configuration system (platformdirs + TOML)
- **Delegatable**: Rich formatting, doctor checks, config schema → ChatGPT/Codex
- **Owner does**: Command wiring, setup IDE logic, UX decisions

### Day 19-20: Security + Observability
- [ ] Implement `security/` module — paths, sanitize, workspace
- [ ] Implement `observability/` module — logging, metrics, shutdown
- [ ] structlog pipeline setup (JSON file + console TTY)
- [ ] Graceful shutdown handler (SIGTERM/SIGINT, WAL checkpoint, task drain)
- [ ] Local metrics collector (metrics.jsonl)
- [ ] Path traversal tests, FTS5 injection tests, Unicode stripping tests
- **Delegatable**: Unicode stripping, metrics collector → Copilot
- **Owner does**: Security architecture, shutdown handler, threat model validation

### Day 21: IDE Integration + AGENTS.md
- [ ] Implement `integrations/ide_setup.py` — Auto-config for 8 IDEs
- [ ] Test with Claude Desktop, Cursor, VS Code (at minimum)
- [ ] Ship AGENTS.md in project root (consumed by AI tools indexing user projects)
- [ ] Verify CLAUDE.md/MEMORY.md consumption as ingestion sources
- **Owner does**: All of this — IDE integration is critical path

### Week 3 Exit Criteria
- [ ] `uvx contextual` installs and runs
- [ ] `contextual serve --stdio` works with Claude Desktop
- [ ] `contextual setup cursor` auto-configures Cursor
- [ ] All 8 MCP tools callable from a real IDE
- [ ] Security tests pass (path traversal, injection, Unicode)
- [ ] Structured logs written to ~/.local/state/contextual/logs/

## Week 4: Polish + Launch (May 12–21)

The goal: production-quality, benchmarked, packaged, shipped.

### Day 22-23: Testing Suite
- [ ] Full unit test coverage for all modules (target 80%+)
- [ ] Integration tests: 10-file, 100-file, 1000-file repos
- [ ] Security test suite (path, SQL, prompt injection)
- [ ] Golden set: 50 hand-labeled queries for retrieval regression
- [ ] CI pipeline: GitHub Actions matrix (ubuntu, macos-14, windows × py3.12, 3.13)
- **Delegatable**: Test file generation, CI YAML → Codex/ChatGPT
- **Owner does**: Golden set creation, test architecture, CI debugging

### Day 24-25: Benchmarking + Optimization
- [ ] Run CoIR code retrieval benchmark
- [ ] Measure MRR, NDCG@10, Recall@k on golden set
- [ ] Profile latency per pipeline phase
- [ ] Optimize hot paths (batch sizes, cache warming, index tuning)
- [ ] Memory profiling on M2 Air 8GB (peak during indexing and querying)
- [ ] Document benchmark results in README
- **Owner does**: All benchmarking — this is the quality gate

### Day 26-27: Packaging + Distribution
- [ ] Register PyPI publisher (OIDC trusted publishing)
- [ ] Complete pyproject.toml with all metadata
- [ ] GitHub Actions release workflow (build + publish, Sigstore attestations)
- [ ] Homebrew tap formula (secondary)
- [ ] curl | sh installer (tertiary, cosign-signed)
- [ ] Startup version-check notifier
- [ ] THIRD-PARTY-LICENSES file
- **Delegatable**: Homebrew formula, install script → ChatGPT
- **Owner does**: PyPI publishing, release workflow, license file

### Day 28-29: Documentation + Polish
- [ ] README final pass (badges, benchmark table, GIF/screenshot)
- [ ] All docs reviewed and consistent
- [ ] CHANGELOG.md for v0.1.0
- [ ] Error messages reviewed for clarity
- [ ] Edge cases: empty repos, monorepos, shallow clones, gitless directories
- **Owner does**: All documentation polish

### Day 30: Launch (May 21, 2026)
- [ ] Final CI green on all platforms
- [ ] `uv publish` to PyPI
- [ ] GitHub release with changelog
- [ ] Homebrew tap updated
- [ ] Launch post drafted (HN, Reddit r/programming, Twitter/X)
- [ ] Submit to MCP server directories (Smithery, Glama, mcp.so)

### Week 4 Exit Criteria
- [ ] `uvx contextual` installs cleanly on macOS, Linux, Windows
- [ ] All tests pass on CI matrix
- [ ] MRR and NDCG@10 benchmarks documented
- [ ] PyPI package published with Sigstore attestations
- [ ] At least 3 IDEs verified working (Claude Desktop, Cursor, VS Code)
- [ ] README has install instructions, benchmarks, and IDE configs

## Risk Register

| Risk | Impact | Probability | Mitigation |
|------|--------|-------------|------------|
| tantivy-py wheels missing for platform | High | Low | Fall back to LanceDB native FTS |
| jina-v2 ONNX int8 quality regression | High | Low | Benchmark before shipping; fallback to float32 |
| LanceDB async API breaking change | Medium | Medium | Pin >=0.26,<0.31; test on exact version |
| pygit2 wheel not available for py3.13 | Medium | Low | Pin py3.12 as minimum; test matrix |
| M2 Air OOM during batch embedding | High | Medium | Cap batch_size=64, monitor RSS |
| pytest-asyncio fixture breaking | Low | High | Already mitigated: asyncio_mode=auto |
| Solo founder burnout | Critical | Medium | Delegate aggressively to AI team; timebox days |

## Post-Launch (v1.1 Backlog)

- A2A protocol integration (agent-to-agent discovery)
- MCPB bundle for Claude Desktop one-click install
- OAuth 2.1 + RFC 8707 for cloud tier
- FastMCP background tasks (SEP-1686) for long indexing
- LanceDB × DuckDB extension for SQL joins over vectors
- jina-code-embeddings-0.5b upgrade (78.4% CoIR)
- Cross-IDE MCP migrator tool
- LongMemEval-temporal benchmark publication
- Team tier with conflict resolution
- Web dashboard for index visualization
