# Week 1 Development Game Plan — Foundation Layer

> April 23–29, 2026 (Days 1–7 of 30)
> Goal: Raw code goes in → structured chunks with temporal metadata come out
> Exit Criteria: Can index a real Python project end-to-end with temporal facts in SQLite and vectors in LanceDB

---

## The Dependency Graph (BUILD ORDER IS NON-NEGOTIABLE)

```
                    ┌─────────────────────┐
                    │  1. PROJECT SCAFFOLD │  ← Day 1 AM (you + me)
                    │  pyproject.toml      │
                    │  __init__.py files   │
                    │  ruff/mypy config    │
                    └─────────┬───────────┘
                              │
                    ┌─────────▼───────────┐
                    │  2. CORE CONTRACTS   │  ← Day 1 PM (ME ONLY)
                    │  core/models.py      │     Every module imports from here
                    │  core/errors.py      │     Get this wrong = cascading rewrites
                    │  config.py           │
                    └─────────┬───────────┘
                              │
                 ┌────────────┼────────────┐
                 │            │            │
        ┌────────▼──────┐ ┌──▼──────────┐ ┌▼──────────────────┐
        │ 3. SECURITY   │ │ 4. LOGGING  │ │ 5. SQLITE LAYER   │  ← Day 2
        │ security/     │ │ observ/     │ │ storage/sqlite_*   │
        │ paths.py      │ │ logging.py  │ │ schema.py          │
        │ sanitize.py   │ │             │ │ migrations.py      │
        │ workspace.py  │ │             │ │ temporal.py         │
        └───────┬───────┘ └──────┬──────┘ └────────┬───────────┘
                │                │                  │
                └────────┬───────┘                  │
                         │                          │
                ┌────────▼──────────┐    ┌──────────▼──────────┐
                │ 6. LANCEDB STORE  │    │ 7. TREE-SITTER      │  ← Day 3-4
                │ storage/lance_*   │    │ indexing/chunker.py  │
                └────────┬──────────┘    │ indexing/processor.py│
                         │               └──────────┬──────────┘
                         │                          │
                         │               ┌──────────▼──────────┐
                         │               │ 8. GIT INTEGRATION   │  ← Day 5
                         │               │ indexing/git_*.py    │
                         │               └──────────┬──────────┘
                         │                          │
                         └──────────┬───────────────┘
                                    │
                         ┌──────────▼──────────────┐
                         │ 9. INDEXING ORCHESTRATOR │  ← Day 6
                         │ core/engine.py (partial) │
                         │ Wires: chunker→embed→    │
                         │   store→git→temporal     │
                         └──────────┬──────────────┘
                                    │
                         ┌──────────▼──────────────┐
                         │ 10. INTEGRATION TEST    │  ← Day 7
                         │ tests/integration/      │
                         │ Index a real repo E2E   │
                         └─────────────────────────┘
```

**Why this order?**
- `core/models.py` defines every data shape (Chunk, Entity, Fact, Episode). If you build storage first without contracts, you'll rewrite it when the models change.
- Security comes before storage because `safe_path()` is called during workspace initialization and file discovery.
- SQLite before LanceDB because the facts/entities schema is the structural backbone; vectors are secondary.
- Chunker before git because git integration attributes temporal metadata *to chunks* — chunks must exist first.
- The orchestrator (engine.py) is the last piece because it wires everything. Build it too early and you're coding against imaginary interfaces.

---

## Repo Structure (Final)

```
contextual/
├── .github/
│   └── workflows/
│       ├── ci.yml                    # Week 4
│       └── release.yml               # Week 4
│
├── contextual/                       # Main Python package
│   ├── __init__.py                   # Version string, package metadata
│   ├── __main__.py                   # `python -m contextual` entry
│   ├── cli.py                        # Typer CLI — Week 3
│   ├── mcp_server.py                 # FastMCP server — Week 3
│   ├── config.py                     # TOML config + platformdirs
│   │
│   ├── core/                         # Data contracts + orchestration
│   │   ├── __init__.py
│   │   ├── models.py                 # ALL Pydantic/dataclass models
│   │   ├── errors.py                 # ErrorCode enum + error helpers
│   │   └── engine.py                 # Indexing + search orchestrator
│   │
│   ├── storage/                      # Persistence layer
│   │   ├── __init__.py
│   │   ├── sqlite_pool.py           # Single-writer/multi-reader pool
│   │   ├── schema.py                # DDL strings + apply_schema()
│   │   ├── migrations.py            # Version table + migration runner
│   │   ├── lance_store.py           # LanceDB async singleton + CRUD
│   │   └── temporal.py              # Bi-temporal query helpers
│   │
│   ├── indexing/                     # Code processing pipeline
│   │   ├── __init__.py
│   │   ├── chunker.py               # tree-sitter chunking pipeline
│   │   ├── embedder.py              # Dual-model embedding — Week 2
│   │   ├── git_integration.py       # pygit2 + subprocess blame
│   │   └── processor.py             # File discovery + orchestration
│   │
│   ├── retrieval/                    # Search pipeline — Week 2
│   │   ├── __init__.py
│   │   ├── sparse.py                # tantivy-py BM25
│   │   ├── dense.py                 # LanceDB vector search
│   │   ├── fusion.py                # Weighted RRF
│   │   ├── reranker.py              # Cross-encoder + MMR
│   │   └── context_assembly.py      # Token-budget builder
│   │
│   ├── security/                     # Hardening
│   │   ├── __init__.py
│   │   ├── paths.py                 # safe_path(), traversal prevention
│   │   ├── sanitize.py              # Unicode stripping, FTS5 escaping
│   │   └── workspace.py             # Per-project DB init, permissions
│   │
│   ├── observability/                # Logging + metrics
│   │   ├── __init__.py
│   │   ├── logging.py               # structlog setup
│   │   ├── metrics.py               # Local metrics collector
│   │   └── shutdown.py              # Graceful shutdown handler
│   │
│   └── integrations/                 # IDE configs — Week 3
│       ├── __init__.py
│       └── ide_setup.py             # Auto-config for 8 IDEs
│
├── tests/
│   ├── __init__.py
│   ├── conftest.py                  # Shared fixtures
│   ├── unit/
│   │   ├── __init__.py
│   │   ├── test_models.py
│   │   ├── test_sqlite_pool.py
│   │   ├── test_schema.py
│   │   ├── test_lance_store.py
│   │   ├── test_chunker.py
│   │   ├── test_git_integration.py
│   │   ├── test_security.py
│   │   └── test_temporal.py
│   ├── integration/
│   │   ├── __init__.py
│   │   ├── test_index_pipeline.py   # End-to-end indexing
│   │   └── fixtures/                # Test repos (10, 100, 1000 files)
│   ├── benchmark/                    # Week 4
│   │   └── __init__.py
│   └── security/                     # Week 3
│       └── __init__.py
│
├── docs/                             # Already created
│   ├── ARCHITECTURE.md
│   ├── TECHNICAL_SPEC.md
│   ├── ROADMAP.md
│   ├── DELEGATION_PLAYBOOK.md
│   └── adr/
│       ├── ADR-001-embedding-model.md
│       ├── ADR-002-storage-architecture.md
│       ├── ADR-003-bitemporal-model.md
│       ├── ADR-004-hybrid-retrieval.md
│       ├── ADR-005-mcp-first.md
│       └── ADR-006-security.md
│
├── README.md
├── CLAUDE.md                         # AI coding assistant guide
├── AGENTS.md                         # Ships in user projects (Week 3)
├── LICENSE                           # BSL 1.1 (Week 4)
├── THIRD-PARTY-LICENSES              # Week 4
├── CHANGELOG.md                      # Week 4
├── pyproject.toml
├── uv.lock                           # Generated by uv
├── ruff.toml                         # Linter config
├── mypy.ini                          # Type checker config
└── .python-version                   # 3.12
```

**Key structural decisions:**
- `core/models.py` is the SINGLE file where all data shapes live. No model definitions scattered across modules.
- `core/engine.py` is the orchestrator — it imports from storage, indexing, and retrieval but none of those import from each other directly. Clean dependency flow.
- `security/` is its own package because it's cross-cutting (used by storage, indexing, and MCP server).
- `observability/` is separate from core because logging setup runs before anything else.
- No `utils.py` or `helpers.py` — those become dumping grounds. Every function has a home.

---

## Daily Breakdown — Deep Work Plan

### DAY 1 (Apr 23): Scaffold + Core Contracts

**This is the most important day of the project.** Every file created today is imported by every module built later. Zero tolerance for sloppiness.

**Morning (3-4 hours) — Project Scaffold**

You (the boss) do this:
1. Create GitHub repo (private)
2. `uv init contextual --lib`
3. Set up pyproject.toml with all deps

I will prepare:
- Complete `pyproject.toml` with all deps, entry point, build config
- `ruff.toml` (line-length=100, target-version=py312)
- `mypy.ini` (strict mode)
- `.python-version` → 3.12
- All `__init__.py` files for every package/subpackage
- `contextual/__init__.py` with `__version__ = "0.1.0"`
- `contextual/__main__.py` with `from contextual.cli import app; app()`

**Afternoon (4-5 hours) — Core Contracts (ME ONLY — most critical code)**

`contextual/core/models.py` — Every data shape in the system:
```python
# Dataclasses for internal pipeline (no Pydantic overhead)
@dataclass: Chunk, ChunkMetadata, FileInfo

# Pydantic models for MCP tool I/O (serialization matters)
class IndexResult(BaseModel): ...
class SearchResult(BaseModel): ...
class Fact(BaseModel): ...
class TimelineFact(BaseModel): ...
class DecisionResult(BaseModel): ...
class FreshnessInfo(BaseModel): ...
class StatusInfo(BaseModel): ...
class ForgetResult(BaseModel): ...

# Enums
class EntityType(str, Enum): FUNCTION, CLASS, MODULE, FILE, SYMBOL, DECISION, ...
class Predicate(str, Enum): HAS_SIGNATURE, CALLS, IMPORTS, DEPENDS_ON, ...
class ChunkType(str, Enum): FUNCTION, CLASS, METHOD, MODULE, CONFIG, ...
class Language(str, Enum): PYTHON, TYPESCRIPT, JAVASCRIPT, GO, JAVA, RUST, CSHARP, ...
```

`contextual/core/errors.py` — Error infrastructure:
```python
class ErrorCode(str, Enum): ...
class ContextualError(Exception): ...
def tool_error(code: ErrorCode, message: str) -> ToolError: ...
```

`contextual/config.py` — Configuration:
```python
@dataclass: ContextualConfig (with defaults for all tunable params)
def load_config(project_root: Path) -> ContextualConfig: ...
def get_workspace_path(project_root: Path) -> Path: ...
```

**Why I do this myself:** These contracts are the API surface between all modules. If `Chunk` has the wrong fields, every module that touches chunks needs rewriting. If `ErrorCode` is missing a case, error handling is inconsistent. This is architectural code that sets the shape of everything downstream.

**Delegation for Day 1:**
- → **Copilot (Haiku)**: Create all `__init__.py` files with proper `__all__` exports once I've defined the models
- → **Cursor**: Set up `ruff.toml` and `mypy.ini` with our exact config

**Day 1 Exit:** `uv sync` works. `ruff check .` passes. `mypy contextual/` passes. `python -c "from contextual.core.models import Chunk"` works.

---

### DAY 2 (Apr 24): Security + Observability + SQLite Foundation

**Morning (3-4 hours) — Security + Logging (parallel tracks)**

`contextual/security/paths.py` — Path safety (ME):
```python
def safe_path(path_str: str, project_root: Path) -> Path: ...
    # resolve(strict=True), is_relative_to, Windows reserved names
```

`contextual/security/sanitize.py` — Input cleaning:
```python
def strip_invisible(text: str) -> str: ...     # Unicode cat Cf
def quote_fts5(term: str) -> str: ...          # FTS5 injection prevention
def wrap_untrusted(content: str) -> str: ...   # <untrusted_content> markers
```

`contextual/security/workspace.py` — Workspace init:
```python
def init_workspace(project_root: Path) -> Path: ...  # Create .contextual/, set perms
```

`contextual/observability/logging.py` — structlog setup:
```python
def setup_logging(verbose: bool = False) -> None: ...
```

**Delegation:**
- → **Copilot (Gemini)**: `sanitize.py` (straightforward regex + unicodedata)
- → **Copilot (Haiku)**: `logging.py` (structlog pipeline from TECHNICAL_SPEC §9.1)

I write `paths.py` and `workspace.py` myself — security-critical, no delegation.

**Afternoon (4-5 hours) — SQLite Layer (CRITICAL)**

`contextual/storage/schema.py` — DDL (delegatable but I verify every line):
- All CREATE TABLE statements from TECHNICAL_SPEC §2.2
- All indexes including partial indexes
- FTS5 external-content tables with all three triggers
- `apply_schema(conn: sqlite3.Connection) -> None`

`contextual/storage/sqlite_pool.py` — Connection pool (ME ONLY):
- `SQLitePool` class with single-writer mutex, multi-reader queue
- PRAGMA block on every connection
- Writer gets `automatic_index=OFF`
- Context managers: `pool.writer()` and `pool.reader()`
- `pool.initialize_schema()` calls schema.py

`contextual/storage/migrations.py` — Schema versioning:
- `schema_version` table
- Idempotent migration functions
- `run_migrations(conn)` checks version, applies pending

**Delegation:**
- → **Perplexity/ChatGPT**: Generate `schema.py` — EXACT DDL from TECHNICAL_SPEC, no creative additions. I review every line.
- → **Copilot**: Generate `migrations.py` boilerplate — simple version table + runner pattern.

I write `sqlite_pool.py` myself — the pool architecture is the most critical piece of infrastructure. One bug here = data corruption.

**Day 2 Exit:** Can create a workspace, open a SQLite pool, apply schema, run PRAGMA quick_check, insert a test entity/fact, query it back. Unit tests for all three modules pass.

---

### DAY 3 (Apr 25): LanceDB Store + Tree-sitter Chunker (Start)

**Morning (3-4 hours) — LanceDB Store**

`contextual/storage/lance_store.py` — Vector store (ME, with delegation for boilerplate):
- Async singleton connection (`connect_async`, double-checked locking)
- `get_or_create_table()` with PyArrow schema from TECHNICAL_SPEC §3.2
- `add_chunks()` — batch insert with proper vector array construction
- `ensure_indexes()` — scalar BTree on path/language/chunk_type, FTS on body, IVF_PQ above 100K threshold
- `optimize_table()` — compaction + version cleanup
- `search_vectors()` — basic vector search (hybrid search comes Week 2)

**Delegation:**
- → **Gemini Pro (Chat)**: Generate the complete PyArrow schema definition and batch insert function — it's array construction boilerplate that's easy to get wrong with types but easy to spec.

**Afternoon (4-5 hours) — Tree-sitter Chunker**

`contextual/indexing/chunker.py` — Code parsing pipeline (ME for core, delegate language queries):

This is where I spend the most focused time. The chunker is the heart of data quality.

Core components I write:
- `ParserPool` class (thread-safe parser caching)
- `chunk_file(path, pool) -> list[Chunk]` main function
- Sweep split-merge algorithm (target/max/min sizes)
- `build_header()` — structural header construction
- `sha256_hex()` content-hash function
- `is_binary()` detection
- Line-based fallback for large files

**Delegation:**
- → **Gemini Pro**: Generate the language-specific node type mappings and import extraction logic for Go, Java, Rust, C# (I write Python + TypeScript myself, they extend the pattern)
- → **Copilot**: `detect_language(path) -> str|None` — extension-to-language mapping from TECHNICAL_SPEC §6

**Day 3 Exit:** Can connect to LanceDB, create table, insert a batch of test vectors, query them back. Can parse a Python file into chunks with headers and content-hashes. Unit tests for both.

---

### DAY 4 (Apr 26): Chunker Complete + File Discovery

**Full Day — Complete the chunking pipeline**

`contextual/indexing/processor.py` — File discovery and filtering:
- `iter_project_files(root) -> Iterator[FileInfo]` — walk + filter
- `.gitignore` + `.contextualignore` via pathspec
- Binary detection, generated code markers, size caps
- Language detection routing

Complete `chunker.py`:
- Integrate all language-specific queries (from Day 3 delegation results)
- Edge cases: ERROR nodes, decorated definitions, nested functions
- Content-hash dedup logic (compare against existing hashes)

**Testing gauntlet:**
- Create test fixtures: small Python file, TypeScript file, Go file, JSON config
- Verify chunking produces correct boundaries per language
- Verify headers contain correct imports, parent context, decorators
- Verify content-hash stability (same input = same hash)
- Verify .contextualignore filtering works
- Verify binary files skipped, large files use line-based fallback

**Delegation:**
- → **Cursor**: Generate test fixture files (sample code in each language)
- → **Copilot**: Write the test cases from my specifications

**Day 4 Exit:** `processor.py` can discover all files in a project, filter correctly, chunk them all, and return `list[Chunk]` with headers and hashes. All 7 languages produce valid chunks. Full unit test coverage for chunker + processor.

---

### DAY 5 (Apr 27): Git Integration

**Full Day — Temporal attribution engine**

`contextual/indexing/git_integration.py` — The temporal backbone:

**This is subtle code. I write all of it myself.**

Components:
1. `GitRepo` class wrapping pygit2:
   - `__init__(root: Path)` — open or validate repo
   - `get_head_oid() -> str`
   - `incremental_walk(since_oid: str|None) -> list[CommitInfo]`
   - `get_changed_files(commit_oid: str) -> list[ChangedFile]`

2. Blame via subprocess:
   - `blame_file(path: Path) -> list[BlameLine]`
   - Streaming parse of `--line-porcelain` output
   - Extract (line_number, commit_sha, author_time) tuples

3. Temporal attribution:
   - `attribute_chunk(chunk: Chunk, blame_lines: list[BlameLine]) -> TemporalAttribution`
   - `valid_at = max(author_time)` across chunk's line range
   - `first_seen_at = min(author_time)` across chunk's line range

4. Integrity checks:
   - `is_ancestor(old_oid, new_oid) -> bool` — force-push detection
   - `find_common_ancestor(oid_a, oid_b) -> str` — for rebase recovery

5. Hook management:
   - `install_hooks(repo_root: Path) -> None`
   - post-commit + post-rewrite scripts
   - Non-blocking pattern (nohup + disown + exit 0)
   - File locking (fcntl.flock on .git/contextual.lock)

**Delegation:**
- → **Copilot (Haiku)**: Generate the post-commit and post-rewrite hook shell scripts from the spec. Simple bash, but must get the non-blocking pattern exactly right.

**Testing:**
- Create a temporary git repo programmatically (init, add files, commit, modify, commit again)
- Verify incremental walk returns only new commits
- Verify blame returns correct author timestamps
- Verify temporal attribution computes correct valid_at/first_seen_at
- Test amend scenario (post-rewrite)
- Test force-push detection (is_ancestor returns False)

**Day 5 Exit:** Can open a real git repo, walk commits incrementally, blame files, attribute temporal metadata to chunks. All unit tests pass including amend/rebase scenarios.

---

### DAY 6 (Apr 28): Storage Integration + Temporal Queries

**Morning — Bi-temporal Query Layer**

`contextual/storage/temporal.py` — Temporal operations on SQLite:
- `insert_entity(conn, name, entity_type, metadata) -> int`
- `insert_fact(conn, entity_id, predicate, value, valid_at, ...) -> int`
- `insert_episode(conn, source, content, timestamp) -> int`
- `invalidate_fact(conn, fact_id, reason, now_ms) -> None` — sets invalid_at + expired_at
- `get_current_facts(conn, entity_id, predicate) -> list[Fact]` — live subset query
- `get_facts_as_of(conn, entity_id, as_of_ms) -> list[Fact]` — AS-OF temporal query
- `get_timeline(conn, entity_id, from_ms, to_ms) -> list[Fact]` — history
- `detect_contradictions(conn, entity_id, predicate, new_value, valid_at) -> list[Fact]` — find overlapping facts to invalidate

**Afternoon — Indexing Orchestrator (Partial)**

`contextual/core/engine.py` — Wire the pipeline (indexing side only, search comes Week 2):

```python
class ContextualEngine:
    def __init__(self, project_root: Path, config: ContextualConfig): ...

    async def index(self, force: bool = False) -> IndexResult:
        """Full indexing pipeline:
        1. Init workspace (security/workspace.py)
        2. Open/create SQLite pool + LanceDB connection
        3. Git: walk new commits, get changed files
        4. Process: discover files, chunk them
        5. Dedup: skip unchanged chunks (content-hash)
        6. Store: batch insert to LanceDB + SQLite
        7. Temporal: attribute via git blame, insert facts
        8. Optimize: compact LanceDB if needed
        """
```

This is the moment where all five days of work converge. The engine imports from storage, indexing, and security — but none of those import from each other. Clean dependency flow.

**Delegation:**
- → **Codex/Antigravity**: Generate the temporal query SQL templates (SELECT with parameterized WHERE clauses). I verify correctness.

**Day 6 Exit:** `ContextualEngine.index()` runs end-to-end on a test repo. Chunks in LanceDB, facts in SQLite, temporal attribution correct.

---

### DAY 7 (Apr 29): Integration Testing + Week 1 Hardening

**Full Day — Validate everything works together**

**Morning — Integration Test Suite**

`tests/integration/test_index_pipeline.py`:
1. Create a temp git repo with 10 Python files
2. Run `ContextualEngine.index()`
3. Assert: correct number of chunks in LanceDB
4. Assert: correct number of entities/facts in SQLite
5. Assert: FTS5 returns results for a known identifier
6. Assert: temporal facts have valid_at from git blame
7. Modify one file, commit, re-index
8. Assert: only changed chunks re-embedded (content-hash dedup works)
9. Assert: old fact invalidated, new fact inserted (bi-temporal correctness)
10. Assert: `get_facts_as_of()` returns old value for old timestamp, new value for new timestamp

**Afternoon — Bug Fixes + Performance Baseline**

- Fix whatever broke in integration tests (there will be bugs)
- Run basic performance measurement: time to index 100 files, 1000 files
- Memory profiling: peak RSS during indexing on test data
- Review all code written this week for:
  - Missing type hints
  - Missing docstrings
  - Hardcoded values that should be in config
  - Error handling gaps (bare except, swallowed errors)
  - SQL injection vectors (any f-strings near SQL?)
  - Path safety (any Path operations not going through safe_path?)

**Delegation:**
- → **Cursor**: Run `ruff check .` and `mypy contextual/ --strict`, fix all warnings
- → **Copilot**: Generate additional edge-case unit tests for each module

**Day 7 Exit Criteria (NON-NEGOTIABLE):**
- [ ] `uv sync` installs all deps cleanly
- [ ] `ruff check . && mypy contextual/` — zero errors
- [ ] `pytest tests/unit/` — all pass
- [ ] `pytest tests/integration/test_index_pipeline.py` — all pass
- [ ] Can index FastMCP source code (real-world repo) without crashing
- [ ] Chunks in LanceDB queryable by vector similarity
- [ ] Facts in SQLite queryable with AS-OF temporal semantics
- [ ] Content-hash dedup working (re-index skips unchanged chunks)
- [ ] .contextualignore filtering working
- [ ] Git blame temporal attribution producing correct timestamps
- [ ] Peak RAM during indexing < 2GB on test data

---

## What Gets Delegated vs What I Build Myself

### I BUILD (no delegation — architectural, security-critical, or wiring code):
| File | Why |
|------|-----|
| `core/models.py` | Every module depends on these shapes |
| `core/errors.py` | Error handling consistency |
| `core/engine.py` | Orchestrator — imports from everything |
| `storage/sqlite_pool.py` | Concurrency + data integrity |
| `storage/temporal.py` | Bi-temporal correctness is our differentiator |
| `security/paths.py` | Security-critical |
| `security/workspace.py` | Security-critical |
| `indexing/chunker.py` (core algorithm) | Data quality heart |
| `indexing/git_integration.py` | Temporal attribution engine |
| `config.py` | Configuration architecture |
| Integration tests | Only I know the expected behavior |

### DELEGATABLE (boilerplate, mechanical, or spec-transcription):
| File | Assign To | Notes |
|------|-----------|-------|
| `storage/schema.py` | Copilot/Cursor | Exact DDL from TECHNICAL_SPEC |
| `storage/migrations.py` | ChatGPT | Simple version table pattern |
| `observability/logging.py` | Copilot | structlog pipeline from spec |
| `security/sanitize.py` | Copilot | regex + unicodedata |
| `indexing/processor.py` (file discovery) | Copilot | pathspec + os.walk |
| Language-specific chunker queries (Go/Java/Rust/C#) | Gemini | Extend Python/TS pattern |
| Test fixture files | Cursor | Sample code per language |
| `ruff.toml` + `mypy.ini` | Cursor | Config files |
| Git hook scripts | Copilot | Bash from spec |
| Unit test generation | Copilot/Codex | From my test specs |

---

## Remaining Planning Items (Delegate NOW)

These don't block coding but should be done in parallel:

| Item | Delegate To | Due |
|------|-------------|-----|
| `AGENTS.md` template (ships in user projects) | ChatGPT | Day 3 |
| `.contextualignore` default template | Me (5 min) | Day 1 |
| `ADR-007` tree-sitter chunking | Perplexity | Day 2 |
| `ADR-008` licensing decision | ChatGPT | Day 5 |
| `LICENSE` (BSL 1.1 full text) | ChatGPT | Week 4 |
| `THIRD-PARTY-LICENSES` | ChatGPT | Week 4 |
| `CHANGELOG.md` template | Copilot | Week 4 |

---

## Risk Mitigation — Week 1 Specific

| Risk | Signal | Mitigation |
|------|--------|------------|
| tree-sitter-language-pack wheel missing for py3.12 ARM | Import fails on Day 3 | Fall back to py-tree-sitter + manual grammar loading |
| pygit2 wheel missing | Import fails on Day 5 | Fall back to subprocess `git log --format` for walk |
| LanceDB async API changed since 0.26 | connect_async signature mismatch | Check LanceDB changelog on Day 3 morning, pin exact version |
| SQLite FTS5 not available | PRAGMA compile_options check | Use sqlite3 from python.org, not system sqlite |
| Content-hash dedup not working | Re-index re-embeds everything | Debug on Day 7, likely a hash comparison bug |
| Integration test hanging | LanceDB background threads | Explicit teardown in fixtures, use asyncio.wait_for |

---

## Communication Protocol

**Every morning (5 min):** I report to you what was built yesterday, what's blocked, what's planned today.

**Every evening (5 min):** I report what was completed, any decisions I need from you, any delegated work that needs review.

**Escalation triggers (I ask you immediately):**
- Any dependency that won't install on your hardware
- Any design ambiguity not covered by TECHNICAL_SPEC
- Any performance result that misses target by >2x
- Any security concern I haven't thought of

---

## Your Action Items Right Now

1. **Create the GitHub repo** (private, name: `contextual`)
2. **Run `uv init`** on your machine so we know your Python/uv versions
3. **Confirm your hardware**: exact macOS version, Python version, available disk space
4. **Tell me to start building** — I'll begin with the scaffold + core contracts

The clock is ticking. Day 1 starts now.
