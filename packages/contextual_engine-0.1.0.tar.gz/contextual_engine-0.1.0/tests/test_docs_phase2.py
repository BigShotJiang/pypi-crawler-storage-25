"""Phase 2 integration test suite — Docs indexing and retrieval.

Test pyramid:
  Unit         — DocsChunker: heading tree, MDX strip, RST convert, frontmatter
  Integration  — DocsPipeline: index → store → query round-trip
  Integration  — docs_search: hybrid BM25 + vector, filter pushdown
  Integration  — docs_get_section: all 5 resolution tiers
  Integration  — docs_list_files: glob, repo filter
  Smoke        — MCP tool JSON output structure

Run with:
    pytest tests/test_docs_phase2.py -v
    pytest tests/test_docs_phase2.py -v -m unit      # fast only
    pytest tests/test_docs_phase2.py -v -m integration
"""
from __future__ import annotations

import json
import sqlite3
import textwrap
from pathlib import Path
from typing import Generator
from unittest.mock import MagicMock, patch

import pytest

from contextual.docs.chunker import (
    DocChunk,
    DocsChunker,
    _strip_frontmatter,
    _strip_mdx,
    _rst_to_markdown,
    _build_heading_tree,
    _est_tokens,
    chunk_doc_file,
)
from contextual.docs.retrieval import (
    docs_search,
    docs_get_section,
    docs_list_files,
    _normalise_heading_path,
    _gh_slug,
)
from contextual.storage.migration_v2 import apply_migration_2


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

@pytest.fixture
def tmp_md_repo(tmp_path: Path) -> Path:
    """Create a minimal repo with a variety of markdown files."""
    repo = tmp_path / "docs_repo"
    repo.mkdir()

    # Standard markdown with YAML frontmatter
    (repo / "README.md").write_text(textwrap.dedent("""\
        ---
        title: Contextual
        version: 2.0
        ---

        # Contextual

        A local-first temporal context engine.

        ## Installation

        Install via uvx:

        ```bash
        uvx contextual
        ```

        ### macOS

        Requires macOS 12+. Set VOYAGE_API_KEY in your shell.

        ### Linux

        Supported on Ubuntu 22.04+.

        ## Configuration

        Edit `~/.contextual/config.toml`.

        ## Architecture

        Contextual uses SQLite + sqlite-vec for hybrid retrieval.
        The embedding model is jina-embeddings-v2-base-code at 768 dimensions.
    """), encoding="utf-8")

    # ADR document
    (repo / "docs").mkdir()
    (repo / "docs" / "adr").mkdir()
    (repo / "docs" / "adr" / "ADR-001.md").write_text(textwrap.dedent("""\
        # ADR-001: Use SQLite as Primary Store

        **Status**: Accepted
        **Date**: 2026-04-22

        ## Context

        We need a storage backend that works offline without infrastructure.

        ## Decision

        Use SQLite with sqlite-vec for vector storage and FTS5 for keyword search.

        ## Consequences

        Positive: zero-dependency install, local-first, fast on Apple Silicon.
        Negative: single-writer bottleneck for high-concurrency scenarios.
    """), encoding="utf-8")

    # MDX file
    (repo / "docs" / "guide.mdx").write_text(textwrap.dedent("""\
        ---
        title: Quick Start Guide
        ---

        # Quick Start

        import { CodeBlock } from '@/components/CodeBlock'
        export const meta = { title: 'Quick Start' }

        ## Step 1: Install

        Run the installer:

        <CodeBlock language="bash">
          uvx contextual
        </CodeBlock>

        ## Step 2: Index

        Point Contextual at your repo:

        ```bash
        contextual index /path/to/repo
        ```

        ## Step 3: Search

        Ask questions in Claude:

        ```
        contextual.search_codebase("how does the embedder work")
        ```
    """), encoding="utf-8")

    # RST file
    (repo / "docs" / "api.rst").write_text(textwrap.dedent("""\
        API Reference
        =============

        Core Module
        -----------

        The core module provides the main indexing primitives.

        Storage Module
        --------------

        Storage uses SQLite with WAL mode for concurrent reads.
    """), encoding="utf-8")

    # Plain text changelog
    (repo / "CHANGELOG.txt").write_text(textwrap.dedent("""\
        Version 0.2.0 (2026-04-28)

        Added heading-aware markdown chunking.
        Added MDX stripping pre-processor.
        Added RST conversion via docutils.

        Version 0.1.0 (2026-04-22)

        Initial release with codebase semantic search.
        SQLite + sqlite-vec hybrid retrieval.
    """), encoding="utf-8")

    return repo


@pytest.fixture
def fresh_db(tmp_path: Path) -> sqlite3.Connection:
    """In-memory SQLite DB with full Phase 1 + Phase 2 schema applied."""
    conn = sqlite3.connect(":memory:")
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA foreign_keys=ON")

    # Minimal Phase 1 schema
    conn.executescript("""
        CREATE TABLE IF NOT EXISTS files (
            id           INTEGER PRIMARY KEY AUTOINCREMENT,
            path         TEXT NOT NULL UNIQUE,
            content_hash TEXT NOT NULL,
            indexed_at   INTEGER NOT NULL,
            chunk_count  INTEGER NOT NULL DEFAULT 0
        );

        CREATE TABLE IF NOT EXISTS chunks (
            id          INTEGER PRIMARY KEY AUTOINCREMENT,
            file_id     INTEGER REFERENCES files(id) ON DELETE CASCADE,
            file_path   TEXT NOT NULL,
            content     TEXT NOT NULL,
            chunk_index INTEGER NOT NULL DEFAULT 0,
            start_line  INTEGER NOT NULL DEFAULT 1,
            end_line    INTEGER NOT NULL DEFAULT 1,
            language    TEXT NOT NULL DEFAULT 'unknown'
        );

        CREATE VIRTUAL TABLE IF NOT EXISTS fts_chunks USING fts5(
            content,
            file_path UNINDEXED,
            content='chunks',
            content_rowid='id',
            tokenize='unicode61 remove_diacritics 2'
        );

        CREATE VIRTUAL TABLE IF NOT EXISTS vec_chunks USING vec0(
            chunk_id INTEGER PRIMARY KEY,
            embedding FLOAT[768]
        );
    """)
    conn.commit()

    # Apply Phase 2 migration
    apply_migration_2(conn)

    return conn


@pytest.fixture
def mock_embedder() -> MagicMock:
    """Mock embedder that returns deterministic 768-dim vectors."""
    embedder = MagicMock()

    def _embed(texts: list[str]) -> list[list[float]]:
        # Deterministic: hash text to seed, produce pseudo-unique vector
        results = []
        for text in texts:
            seed = abs(hash(text[:32])) % 1000
            vec = [(seed + i) / 1000.0 for i in range(768)]
            results.append(vec)
        return results

    embedder.embed.side_effect = _embed
    return embedder


@pytest.fixture
def populated_db(fresh_db: sqlite3.Connection, tmp_md_repo: Path, mock_embedder: MagicMock):
    """DB with tmp_md_repo docs indexed using the mock embedder."""
    from contextual.docs.pipeline import DocsPipeline
    from contextual.storage.sqlite_pool import SQLitePool

    # Build a minimal pool wrapper around our in-memory connection
    pool = MagicMock()
    pool.writer.return_value.__enter__ = lambda s: fresh_db
    pool.writer.return_value.__exit__ = MagicMock(return_value=False)
    pool.reader.return_value.__enter__ = lambda s: fresh_db
    pool.reader.return_value.__exit__ = MagicMock(return_value=False)

    pipeline = DocsPipeline(
        repo_root=tmp_md_repo,
        pool=pool,
        embedder=mock_embedder,
    )
    stats = pipeline.index_all(force=True)
    assert stats.files_indexed > 0, f"No files indexed: {stats}"

    return fresh_db


# ---------------------------------------------------------------------------
# UNIT TESTS — Chunker
# ---------------------------------------------------------------------------

@pytest.mark.unit
class TestDocsChunkerUnit:
    """Fast unit tests for DocsChunker internals (no I/O, no embedder)."""

    def test_token_estimation(self) -> None:
        assert _est_tokens("") == 1
        assert _est_tokens("a" * 400) == 100

    def test_strip_yaml_frontmatter(self) -> None:
        source = "---\ntitle: Test\n---\n# Hello\n"
        body, meta = _strip_frontmatter(source)
        assert "title" in meta
        assert meta["title"] == "Test"
        assert body.startswith("# Hello")

    def test_strip_toml_frontmatter(self) -> None:
        source = '+++\ntitle = "Test"\n+++\n# Hello\n'
        body, meta = _strip_frontmatter(source)
        assert body.startswith("# Hello")

    def test_strip_mdx_imports(self) -> None:
        source = "import { Foo } from 'bar'\nexport const x = 1\n\n# Title\n\nContent."
        result = _strip_mdx(source)
        assert "import" not in result
        assert "export" not in result
        assert "# Title" in result
        assert "Content." in result

    def test_rst_to_markdown_section_headings(self) -> None:
        rst = "Overview\n========\n\nSome text.\n\nDetails\n-------\n\nMore text.\n"
        md = _rst_to_markdown(rst)
        assert "# Overview" in md or "## Overview" in md

    def test_heading_tree_flat(self) -> None:
        lines = ["# Root\n", "Some text\n", "## Section A\n", "A content\n", "## Section B\n", "B content\n"]
        root = _build_heading_tree(lines)
        assert len(root.children) == 1   # one H1
        assert len(root.children[0].children) == 2  # two H2s

    def test_heading_tree_deep(self) -> None:
        lines = [
            "# H1\n", "## H2\n", "### H3\n", "content\n", "#### H4\n", "deep\n",
        ]
        root = _build_heading_tree(lines)
        h1 = root.children[0]
        h2 = h1.children[0]
        h3 = h2.children[0]
        assert h3.title == "H3"
        assert len(h3.children) == 1   # H4

    def test_chunk_file_returns_doc_chunks(self, tmp_path: Path) -> None:
        md = tmp_path / "test.md"
        md.write_text("# Root\n\n## Section A\n\nContent A.\n\n## Section B\n\nContent B.\n")
        chunker = DocsChunker()
        chunks = chunker.chunk_file(md)
        assert len(chunks) >= 2
        assert all(isinstance(c, DocChunk) for c in chunks)
        assert all(c.chunk_type in ("docs", "docs_code") for c in chunks)

    def test_chunk_file_breadcrumb_prefix(self, tmp_path: Path) -> None:
        md = tmp_path / "test.md"
        md.write_text("# Parent\n\n## Child\n\nContent.\n")
        chunks = DocsChunker().chunk_file(md)
        # At least one chunk should have breadcrumb in embedding_text
        breadcrumb_chunks = [c for c in chunks if "Section:" in c.embedding_text]
        assert len(breadcrumb_chunks) > 0
        assert "Child" in breadcrumb_chunks[0].embedding_text

    def test_chunk_file_heading_path_set(self, tmp_path: Path) -> None:
        md = tmp_path / "test.md"
        md.write_text("# Root\n\n## Installation\n\n### macOS\n\nContent.\n")
        chunks = DocsChunker().chunk_file(md)
        paths = {c.heading_path for c in chunks if c.heading_path}
        assert any("Installation" in p for p in paths)
        assert any("macOS" in p for p in paths)

    def test_chunk_file_frontmatter_in_chunk(self, tmp_path: Path) -> None:
        md = tmp_path / "test.md"
        md.write_text("---\ntitle: My Doc\n---\n# Root\n\n## Section\n\nContent.\n")
        chunks = DocsChunker().chunk_file(md)
        assert any(c.frontmatter.get("title") == "My Doc" for c in chunks)

    def test_chunk_file_mdx(self, tmp_path: Path) -> None:
        mdx = tmp_path / "test.mdx"
        mdx.write_text(
            "import { Foo } from 'foo'\n# Guide\n\n## Step 1\n\nDo this.\n"
        )
        chunks = DocsChunker().chunk_file(mdx)
        assert len(chunks) >= 1
        assert all("import" not in c.content for c in chunks)

    def test_chunk_file_rst(self, tmp_path: Path) -> None:
        rst = tmp_path / "test.rst"
        rst.write_text("Overview\n========\n\nSome text.\n\nDetails\n-------\n\nMore text.\n")
        chunks = DocsChunker().chunk_file(rst)
        assert len(chunks) >= 1

    def test_chunk_file_plain_text(self, tmp_path: Path) -> None:
        txt = tmp_path / "test.txt"
        txt.write_text("First paragraph with enough content to pass min tokens.\n\nSecond paragraph also long enough.\n")
        chunks = DocsChunker().chunk_file(txt)
        assert len(chunks) >= 1
        assert all(c.chunk_type == "docs" for c in chunks)

    def test_chunk_file_unsupported_extension(self, tmp_path: Path) -> None:
        f = tmp_path / "test.py"
        f.write_text("# Not a doc\nprint('hi')\n")
        chunks = DocsChunker().chunk_file(f)
        assert chunks == []

    def test_chunk_file_empty_file(self, tmp_path: Path) -> None:
        md = tmp_path / "empty.md"
        md.write_text("   \n\n  ")
        chunks = DocsChunker().chunk_file(md)
        assert chunks == []

    def test_code_block_extracted_as_docs_code(self, tmp_path: Path) -> None:
        code = "\n".join([f"    line_{i} = True" for i in range(25)])
        md = tmp_path / "test.md"
        md.write_text(f"# Root\n\n## Section\n\nText before.\n\n```python\n{code}\n```\n\nText after.\n")
        chunks = DocsChunker().chunk_file(md)
        types = {c.chunk_type for c in chunks}
        # Large code block should produce a docs_code chunk
        assert "docs_code" in types

    def test_relative_path_used_when_repo_root_given(self, tmp_path: Path) -> None:
        repo = tmp_path / "myrepo"
        repo.mkdir()
        md = repo / "README.md"
        md.write_text("# Root\n\n## Section\n\nContent.\n")
        chunks = DocsChunker().chunk_file(md, repo_root=repo)
        assert all(not c.file_path.startswith(str(repo)) for c in chunks)
        assert all("README.md" in c.file_path for c in chunks)


# ---------------------------------------------------------------------------
# UNIT TESTS — Migration
# ---------------------------------------------------------------------------

@pytest.mark.unit
class TestMigrationV2Unit:

    def test_migration_adds_columns(self, fresh_db: sqlite3.Connection) -> None:
        cols = {row[1] for row in fresh_db.execute("PRAGMA table_info(chunks)")}
        assert "source_type"      in cols
        assert "heading_path"     in cols
        assert "heading_level"    in cols
        assert "chunk_type"       in cols
        assert "frontmatter_json" in cols

    def test_migration_idempotent(self, fresh_db: sqlite3.Connection) -> None:
        # Should not raise on second call
        apply_migration_2(fresh_db)
        apply_migration_2(fresh_db)

    def test_fts_chunks_has_heading_path(self, fresh_db: sqlite3.Connection) -> None:
        # Insert a chunk with heading_path and verify FTS can search it
        fresh_db.execute(
            "INSERT INTO files (path, content_hash, indexed_at, chunk_count) VALUES (?, ?, 1, 1)",
            ("test.md", "abc123"),
        )
        file_id = fresh_db.execute("SELECT id FROM files WHERE path='test.md'").fetchone()[0]
        fresh_db.execute(
            """INSERT INTO chunks (file_id, file_path, content, source_type, heading_path, heading_level)
               VALUES (?, ?, ?, 'docs', 'Installation > macOS', 2)""",
            (file_id, "test.md", "Install on macOS with brew."),
        )
        fresh_db.commit()

        rows = fresh_db.execute(
            "SELECT heading_path FROM fts_chunks WHERE fts_chunks MATCH 'macOS' LIMIT 5"
        ).fetchall()
        assert len(rows) > 0


# ---------------------------------------------------------------------------
# INTEGRATION TESTS — Pipeline
# ---------------------------------------------------------------------------

@pytest.mark.integration
class TestDocsPipelineIntegration:

    def test_index_all_discovers_files(
        self, tmp_md_repo: Path, mock_embedder: MagicMock, fresh_db: sqlite3.Connection
    ) -> None:
        from contextual.docs.pipeline import DocsPipeline

        pool = MagicMock()
        pool.writer.return_value.__enter__ = lambda s: fresh_db
        pool.writer.return_value.__exit__ = MagicMock(return_value=False)

        pipeline = DocsPipeline(tmp_md_repo, pool, mock_embedder)
        stats = pipeline.index_all(force=True)

        assert stats.files_discovered >= 5    # README + guide.mdx + api.rst + ADR + CHANGELOG
        assert stats.files_indexed >= 5
        assert stats.files_failed == 0
        assert stats.chunks_created > 0

    def test_index_sets_source_type_docs(
        self, tmp_md_repo: Path, mock_embedder: MagicMock, fresh_db: sqlite3.Connection
    ) -> None:
        from contextual.docs.pipeline import DocsPipeline

        pool = MagicMock()
        pool.writer.return_value.__enter__ = lambda s: fresh_db
        pool.writer.return_value.__exit__ = MagicMock(return_value=False)

        DocsPipeline(tmp_md_repo, pool, mock_embedder).index_all(force=True)

        rows = fresh_db.execute(
            "SELECT DISTINCT source_type FROM chunks"
        ).fetchall()
        source_types = {r[0] for r in rows}
        assert "docs" in source_types

    def test_index_skips_unchanged_files(
        self, tmp_md_repo: Path, mock_embedder: MagicMock, fresh_db: sqlite3.Connection
    ) -> None:
        from contextual.docs.pipeline import DocsPipeline

        pool = MagicMock()
        pool.writer.return_value.__enter__ = lambda s: fresh_db
        pool.writer.return_value.__exit__ = MagicMock(return_value=False)

        pipeline = DocsPipeline(tmp_md_repo, pool, mock_embedder)
        pipeline.index_all(force=True)

        stats2 = pipeline.index_all(force=False)
        assert stats2.files_skipped_unchanged > 0
        assert stats2.files_indexed == 0

    def test_force_reindex_replaces_chunks(
        self, tmp_md_repo: Path, mock_embedder: MagicMock, fresh_db: sqlite3.Connection
    ) -> None:
        from contextual.docs.pipeline import DocsPipeline

        pool = MagicMock()
        pool.writer.return_value.__enter__ = lambda s: fresh_db
        pool.writer.return_value.__exit__ = MagicMock(return_value=False)

        pipeline = DocsPipeline(tmp_md_repo, pool, mock_embedder)
        pipeline.index_all(force=True)
        count1 = fresh_db.execute(
            "SELECT COUNT(*) FROM chunks WHERE source_type='docs'"
        ).fetchone()[0]

        pipeline.index_all(force=True)
        count2 = fresh_db.execute(
            "SELECT COUNT(*) FROM chunks WHERE source_type='docs'"
        ).fetchone()[0]

        # Chunk count should be stable (not doubled)
        assert count2 == count1

    def test_delete_file_removes_chunks(
        self, tmp_md_repo: Path, mock_embedder: MagicMock, fresh_db: sqlite3.Connection
    ) -> None:
        from contextual.docs.pipeline import DocsPipeline

        pool = MagicMock()
        pool.writer.return_value.__enter__ = lambda s: fresh_db
        pool.writer.return_value.__exit__ = MagicMock(return_value=False)

        pipeline = DocsPipeline(tmp_md_repo, pool, mock_embedder)
        pipeline.index_all(force=True)

        deleted = pipeline.delete_file(tmp_md_repo / "README.md")
        assert deleted > 0

        remaining = fresh_db.execute(
            "SELECT COUNT(*) FROM chunks WHERE file_path LIKE '%README.md%'"
        ).fetchone()[0]
        assert remaining == 0


# ---------------------------------------------------------------------------
# INTEGRATION TESTS — Retrieval
# ---------------------------------------------------------------------------

@pytest.mark.integration
class TestDocsRetrievalIntegration:

    def test_docs_search_returns_hits(
        self, populated_db: sqlite3.Connection, mock_embedder: MagicMock
    ) -> None:
        hits = docs_search(
            query="SQLite storage hybrid retrieval",
            conn=populated_db,
            embedder=mock_embedder,
            k=5,
        )
        assert len(hits) > 0
        assert all(h.chunk_type in ("docs", "docs_code") for h in hits)
        assert all(h.score > 0 for h in hits)

    def test_docs_search_scores_descending(
        self, populated_db: sqlite3.Connection, mock_embedder: MagicMock
    ) -> None:
        hits = docs_search(
            query="installation macOS uvx",
            conn=populated_db,
            embedder=mock_embedder,
            k=10,
        )
        if len(hits) > 1:
            scores = [h.score for h in hits]
            assert scores == sorted(scores, reverse=True)

    def test_docs_search_source_filter_by_file(
        self, populated_db: sqlite3.Connection, mock_embedder: MagicMock
    ) -> None:
        hits = docs_search(
            query="SQLite decision consequences",
            conn=populated_db,
            embedder=mock_embedder,
            k=10,
            source_filter={"file": ["docs/adr/ADR-001.md"]},
        )
        assert all("ADR-001.md" in h.file_path for h in hits)

    def test_docs_search_source_filter_by_repo(
        self, populated_db: sqlite3.Connection, mock_embedder: MagicMock
    ) -> None:
        hits = docs_search(
            query="step install index search",
            conn=populated_db,
            embedder=mock_embedder,
            k=10,
            source_filter={"repo": ["docs"]},
        )
        assert all(h.file_path.startswith("docs/") for h in hits)

    def test_docs_search_empty_query(
        self, populated_db: sqlite3.Connection, mock_embedder: MagicMock
    ) -> None:
        hits = docs_search(query="", conn=populated_db, embedder=mock_embedder)
        assert hits == []

    def test_docs_get_section_exact_match(self, populated_db: sqlite3.Connection) -> None:
        result = docs_get_section(
            file="README.md",
            heading_path="Installation",
            conn=populated_db,
            fuzzy=False,
        )
        assert not isinstance(result, dict), f"Expected DocSection, got error: {result}"
        assert result.heading_path == "Installation"

    def test_docs_get_section_fuzzy_match(self, populated_db: sqlite3.Connection) -> None:
        # Slightly misspelled — should resolve via fuzzy tier
        result = docs_get_section(
            file="README.md",
            heading_path="Instalation",   # typo
            conn=populated_db,
            fuzzy=True,
        )
        # Should resolve, not error
        assert not isinstance(result, dict) or result.get("error") != "heading_not_found"

    def test_docs_get_section_not_found_returns_error(self, populated_db: sqlite3.Connection) -> None:
        result = docs_get_section(
            file="README.md",
            heading_path="Nonexistent Section XYZ",
            conn=populated_db,
            fuzzy=False,
        )
        assert isinstance(result, dict)
        assert result["error"] == "heading_not_found"
        assert "did_you_mean" in result

    def test_docs_get_section_did_you_mean_populated(self, populated_db: sqlite3.Connection) -> None:
        result = docs_get_section(
            file="README.md",
            heading_path="Nonexistent Section XYZ",
            conn=populated_db,
            fuzzy=False,
        )
        assert isinstance(result, dict)
        assert len(result["did_you_mean"]) > 0

    def test_docs_get_section_file_not_found(self, populated_db: sqlite3.Connection) -> None:
        result = docs_get_section(
            file="nonexistent/file.md",
            heading_path="Any Section",
            conn=populated_db,
        )
        assert isinstance(result, dict)
        assert result["error"] == "file_not_found"

    def test_docs_list_files_returns_all(self, populated_db: sqlite3.Connection) -> None:
        files = docs_list_files(conn=populated_db)
        assert len(files) >= 5
        paths = {f.file_path for f in files}
        assert "README.md" in paths
        assert any("ADR-001.md" in p for p in paths)

    def test_docs_list_files_repo_filter(self, populated_db: sqlite3.Connection) -> None:
        files = docs_list_files(conn=populated_db, repo="docs")
        assert all(f.file_path.startswith("docs/") for f in files)

    def test_docs_list_files_glob_filter(self, populated_db: sqlite3.Connection) -> None:
        files = docs_list_files(conn=populated_db, glob="*.md")
        assert all(f.file_path.endswith(".md") for f in files)

    def test_docs_list_files_include_headings(self, populated_db: sqlite3.Connection) -> None:
        files = docs_list_files(conn=populated_db, include_headings=True)
        files_with_headings = [f for f in files if f.headings]
        assert len(files_with_headings) > 0

    def test_docs_list_files_chunk_count_positive(self, populated_db: sqlite3.Connection) -> None:
        files = docs_list_files(conn=populated_db)
        assert all(f.chunk_count > 0 for f in files)


# ---------------------------------------------------------------------------
# UNIT TESTS — Retrieval helpers
# ---------------------------------------------------------------------------

@pytest.mark.unit
class TestRetrievalHelpers:

    def test_normalise_heading_path_slash(self) -> None:
        assert _normalise_heading_path("installation/macos/homebrew") == "installation > macos > homebrew"

    def test_normalise_heading_path_arrow(self) -> None:
        result = _normalise_heading_path("Installation > macOS > Homebrew")
        assert result == "Installation > macOS > Homebrew"

    def test_gh_slug_basic(self) -> None:
        assert _gh_slug("Hello World") == "hello-world"

    def test_gh_slug_punctuation(self) -> None:
        assert _gh_slug("ADR-001: Use SQLite") == "adr-001-use-sqlite"


# ---------------------------------------------------------------------------
# SMOKE TESTS — MCP tools JSON output
# ---------------------------------------------------------------------------

@pytest.mark.integration
class TestMCPToolsSmoke:
    """Verify MCP tool functions return valid JSON with expected structure."""

    def test_docs_search_tool_json(
        self, populated_db: sqlite3.Connection, mock_embedder: MagicMock
    ) -> None:
        from contextual.mcp.docs_tools import docs_search_tool

        with (
            patch("contextual.mcp.docs_tools._DOCS_ENABLED", True),
            patch("contextual.mcp.docs_tools._get_pool") as mock_pool,
            patch("contextual.mcp.docs_tools.get_embedder", return_value=mock_embedder),
        ):
            mock_pool.return_value.reader.return_value.__enter__ = lambda s: populated_db
            mock_pool.return_value.reader.return_value.__exit__ = MagicMock(return_value=False)

            result = docs_search_tool(query="SQLite hybrid retrieval", k=3)
            parsed = json.loads(result)

            assert isinstance(parsed, list)
            if parsed:
                hit = parsed[0]
                assert "file_path"    in hit
                assert "content"      in hit
                assert "heading_path" in hit
                assert "score"        in hit
                assert "chunk_type"   in hit

    def test_docs_get_section_tool_json(self, populated_db: sqlite3.Connection) -> None:
        from contextual.mcp.docs_tools import docs_get_section_tool

        with (
            patch("contextual.mcp.docs_tools._DOCS_ENABLED", True),
            patch("contextual.mcp.docs_tools._get_pool") as mock_pool,
        ):
            mock_pool.return_value.reader.return_value.__enter__ = lambda s: populated_db
            mock_pool.return_value.reader.return_value.__exit__ = MagicMock(return_value=False)

            result = docs_get_section_tool(file="README.md", heading_path="Installation")
            parsed = json.loads(result)

            # Either a section or a did_you_mean error — both valid JSON
            assert isinstance(parsed, dict)

    def test_docs_list_files_tool_json(self, populated_db: sqlite3.Connection) -> None:
        from contextual.mcp.docs_tools import docs_list_files_tool

        with (
            patch("contextual.mcp.docs_tools._DOCS_ENABLED", True),
            patch("contextual.mcp.docs_tools._get_pool") as mock_pool,
        ):
            mock_pool.return_value.reader.return_value.__enter__ = lambda s: populated_db
            mock_pool.return_value.reader.return_value.__exit__ = MagicMock(return_value=False)

            result = docs_list_files_tool()
            parsed = json.loads(result)

            assert isinstance(parsed, list)
            if parsed:
                assert "file_path"   in parsed[0]
                assert "chunk_count" in parsed[0]

    def test_docs_disabled_returns_error_json(self) -> None:
        from contextual.mcp.docs_tools import docs_search_tool

        with patch("contextual.mcp.docs_tools._DOCS_ENABLED", False):
            result = docs_search_tool(query="anything")
            parsed = json.loads(result)
            assert "error" in parsed
