"""Integration test for Phase 1 indexing pipeline.

Tests end-to-end: file discovery → chunking → symbol extraction → embedding → DB write.
"""

from __future__ import annotations

import shutil
import sqlite3
import tempfile
import time
from pathlib import Path

from contextual.indexing.embedder import get_embedder
from contextual.indexing.incremental import IncrementalIndexer
from contextual.indexing.pipeline import IndexingPipeline
from contextual.observability.logging import configure_logging, get_logger
from contextual.security import init_workspace
from contextual.storage import SQLitePool, run_migrations

logger = get_logger(__name__)


def test_full_indexing_pipeline():
    """Test complete indexing pipeline on sample repository."""
    
    configure_logging(log_level="INFO", enable_file_logging=False)
    logger.info("Starting Phase 1 integration test")
    
    # Create temporary test repository
    with tempfile.TemporaryDirectory() as tmpdir:
        repo_root = Path(tmpdir) / "test_repo"
        repo_root.mkdir()
        
        # Create sample Python files
        (repo_root / "main.py").write_text("""
def main():
    '''Main entry point.'''
    print("Hello, World!")
    return 0

class Application:
    '''Application class.'''
    
    def __init__(self, name: str):
        self.name = name
    
    def run(self) -> int:
        '''Run the application.'''
        return main()
""")
        
        (repo_root / "utils.py").write_text("""
def get_user_data(user_id: int):
    '''Fetch user data by ID.'''
    return {"id": user_id, "name": "Test User"}

def validate_email(email: str) -> bool:
    '''Validate email format.'''
    return "@" in email and "." in email
""")
        
        # Create sample TypeScript file
        (repo_root / "app.ts").write_text("""
interface User {
    id: number;
    name: string;
}

class UserService {
    getUser(id: number): User {
        return { id, name: "Test" };
    }
}

function main(): void {
    const service = new UserService();
    console.log(service.getUser(1));
}
""")
        
        # Create .gitignore
        (repo_root / ".gitignore").write_text("""
node_modules/
__pycache__/
*.pyc
.venv/
""")
        
        workspace_manager = init_workspace(repo_root)
        workspace_manager.init_workspace()  # Actually initialize the workspace
        workspace_dir = workspace_manager.workspace_dir
        logger.info(f"Workspace initialized at {workspace_dir}")

        # Initialize database
        db_path = workspace_dir / "contextual.db"
        pool = SQLitePool(db_path)
        
        # Run migrations
        with pool.writer() as writer_conn:
            migrations_applied = run_migrations(writer_conn)
        logger.info(f"Applied {migrations_applied} migrations")
        
        # Create pipeline
        pipeline = IndexingPipeline(repo_root, pool)
        
        # Test 1: Full repository indexing
        logger.info("=== TEST 1: Full repository indexing ===")
        start = time.time()
        stats = pipeline.index_repository()
        duration = time.time() - start
        
        logger.info(f"Full indexing completed in {duration:.2f}s")
        logger.info(f"Stats: {stats}")
        
        # Verify stats
        assert stats["files"] == 3, f"Expected 3 files, got {stats['files']}"
        assert stats["chunks"] > 0, "No chunks created"
        assert stats["symbols"] > 0, "No symbols extracted"
        
        # Verify database contents
        with pool.reader() as reader_conn:
            cursor = reader_conn.cursor()
            
            cursor.execute("SELECT COUNT(*) FROM files")
            file_count = cursor.fetchone()[0]
            assert file_count == 3, f"Expected 3 files in DB, got {file_count}"
            
            cursor.execute("SELECT COUNT(*) FROM chunks")
            chunk_count = cursor.fetchone()[0]
            assert chunk_count > 0, "No chunks in DB"
            
            cursor.execute("SELECT COUNT(*) FROM code_symbols")
            symbol_count = cursor.fetchone()[0]
            assert symbol_count > 0, "No symbols in DB"
            
            # Check specific symbols
            cursor.execute("SELECT name, kind FROM code_symbols ORDER BY name")
            symbols = cursor.fetchall()
            symbol_names = [s[0] for s in symbols]
            
            assert "main" in symbol_names, "main function not extracted"
            assert "Application" in symbol_names, "Application class not extracted"
            assert "get_user_data" in symbol_names, "get_user_data function not extracted"
        
        logger.info(f"✓ Found {len(symbols)} symbols: {symbol_names}")

        # Test 2: Incremental indexing (modify file)
        logger.info("=== TEST 2: Incremental indexing ===")
        
        incremental = IncrementalIndexer(pipeline)
        
        # Modify main.py
        time.sleep(0.1)  # Ensure mtime changes
        (repo_root / "main.py").write_text("""
def main():
    '''Main entry point - updated.'''
    print("Hello, Updated World!")
    return 0

def new_function():
    '''A new function.'''
    pass

class Application:
    '''Application class.'''
    
    def __init__(self, name: str):
        self.name = name
    
    def run(self) -> int:
        '''Run the application.'''
        return main()
""")
        
        # Incremental index
        start = time.time()
        inc_stats = incremental.handle_file_change(repo_root / "main.py")
        inc_duration = time.time() - start
        
        logger.info(f"Incremental indexing completed in {inc_duration*1000:.0f}ms")
        logger.info(f"Incremental stats: {inc_stats}")
        
        assert inc_duration < 2.0, f"Incremental indexing too slow: {inc_duration:.2f}s"
        
        # Verify new function extracted
        with pool.reader() as reader_conn:
            cursor = reader_conn.cursor()
            cursor.execute("SELECT name FROM code_symbols WHERE name = 'new_function'")
            result = cursor.fetchone()
            assert result is not None, "new_function not extracted after incremental update"
        
        logger.info("✓ Incremental indexing verified")
        
        # Test 3: File deletion
        logger.info("=== TEST 3: File deletion ===")
        
        (repo_root / "utils.py").unlink()
        del_stats = incremental.handle_file_deletion(repo_root / "utils.py")
        
        logger.info(f"Deletion stats: {del_stats}")
        
        # Verify file removed from DB
        with pool.reader() as reader_conn:
            cursor = reader_conn.cursor()
            cursor.execute("SELECT COUNT(*) FROM files WHERE path = 'utils.py'")
            count = cursor.fetchone()[0]
            assert count == 0, "File not deleted from DB"
        
        logger.info("✓ File deletion verified")
        
        # Test 4: Pipeline stats
        logger.info("=== TEST 4: Pipeline stats ===")
        
        final_stats = pipeline.get_stats()
        logger.info(f"Final stats: {final_stats}")
        
        assert final_stats["files"] == 2, f"Expected 2 files, got {final_stats['files']}"
        assert final_stats["chunks"] > 0
        assert final_stats["symbols"] > 0
        
        logger.info("✓ Pipeline stats verified")
        
        # Test 5: Content hash deduplication
        logger.info("=== TEST 5: Content hash deduplication ===")
        
        # Re-save file with same content
        current_content = (repo_root / "main.py").read_text()
        time.sleep(0.1)
        (repo_root / "main.py").write_text(current_content)
        
        dedup_stats = incremental.handle_file_change(repo_root / "main.py")
        
        # Should skip re-indexing (content unchanged)
        assert dedup_stats["chunks"] == 0, "Deduplication failed - re-indexed unchanged file"
        
        logger.info("✓ Content hash deduplication verified")
        
        # Cleanup
        pool.close()
        
    logger.info("\n" + "="*60)
    logger.info("✅ ALL INTEGRATION TESTS PASSED")
    logger.info("="*60)


if __name__ == "__main__":
    test_full_indexing_pipeline()
