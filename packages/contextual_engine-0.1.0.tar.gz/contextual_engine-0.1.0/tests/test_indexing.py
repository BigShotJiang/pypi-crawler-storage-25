"""
Integration tests for indexing pipeline.

Validates:
- Multi-language chunking (Python, TS, JS, Go, Java, Rust, C#)
- Split-merge algorithm (1500 target/2000 max/50 min bytes)
- Structural headers (FILE/LANG/PARENT/IMPORTS/DECORATORS)
- Content-hash deduplication (SHA-256)
- File discovery with .gitignore filtering
- Generated file exclusion
"""

from __future__ import annotations

import tempfile
from pathlib import Path

import pytest

from contextual.indexing import chunk_file, detect_language, index_project


class TestLanguageDetection:
    """Test language detection from file extensions."""

    def test_python_detection(self) -> None:
        """Python files detected correctly."""
        assert detect_language(Path("test.py")) == "python"

    def test_typescript_detection(self) -> None:
        """TypeScript files detected correctly."""
        assert detect_language(Path("test.ts")) == "typescript"
        assert detect_language(Path("test.tsx")) == "tsx"

    def test_javascript_detection(self) -> None:
        """JavaScript files detected correctly."""
        assert detect_language(Path("test.js")) == "javascript"
        assert detect_language(Path("test.jsx")) == "javascript"

    def test_go_detection(self) -> None:
        """Go files detected correctly."""
        assert detect_language(Path("test.go")) == "go"

    def test_java_detection(self) -> None:
        """Java files detected correctly."""
        assert detect_language(Path("Test.java")) == "java"

    def test_rust_detection(self) -> None:
        """Rust files detected correctly."""
        assert detect_language(Path("test.rs")) == "rust"

    def test_csharp_detection(self) -> None:
        """C# files detected correctly."""
        assert detect_language(Path("Test.cs")) == "c_sharp"

    def test_config_detection(self) -> None:
        """Config files detected correctly."""
        assert detect_language(Path("config.json")) == "json"
        assert detect_language(Path("config.yaml")) == "yaml"
        assert detect_language(Path("config.yml")) == "yaml"
        assert detect_language(Path("config.toml")) == "toml"
        assert detect_language(Path("Dockerfile")) == "dockerfile"
        assert detect_language(Path("README.md")) == "markdown"

    def test_unsupported_language(self) -> None:
        """Unsupported files return None."""
        assert detect_language(Path("test.cpp")) is None
        assert detect_language(Path("test.rb")) is None


class TestPythonChunking:
    """Test Python file chunking."""

    def test_simple_function(self) -> None:
        """Single function chunked correctly."""
        code = b'''def hello(name: str) -> str:
    """Greet someone."""
    return f"Hello, {name}!"
'''
        chunks = chunk_file(Path("test.py"), code, "python")
        
        assert len(chunks) == 1
        chunk = chunks[0]
        
        # Validate structure
        assert chunk.path == "test.py"
        assert chunk.language == "python"
        assert chunk.chunk_type == "function_definition"
        
        # Validate header format
        assert "FILE: test.py" in chunk.header
        assert "LANG: python" in chunk.header
        assert "PARENT: none" in chunk.header
        assert "IMPORTS:" in chunk.header
        assert "DECORATORS:" in chunk.header
        assert "-----" in chunk.header
        
        # Validate body contains code
        assert "def hello" in chunk.body
        
        # Validate content hash
        assert len(chunk.content_hash) == 64  # SHA-256 hex

    def test_class_with_methods(self) -> None:
        """Class with methods chunked as single unit."""
        code = b'''class Calculator:
    """Simple calculator."""
    
    def add(self, a: int, b: int) -> int:
        """Add two numbers."""
        return a + b
    
    def subtract(self, a: int, b: int) -> int:
        """Subtract two numbers."""
        return a - b
'''
        chunks = chunk_file(Path("calc.py"), code, "python")
        
        # Should be one chunk (class with methods)
        assert len(chunks) == 1
        assert chunks[0].chunk_type == "class_definition"
        assert "class Calculator" in chunks[0].body

    def test_multiple_functions(self) -> None:
        """Multiple top-level functions create multiple chunks."""
        code = b'''def func1():
    pass

def func2():
    pass

def func3():
    pass
'''
        chunks = chunk_file(Path("funcs.py"), code, "python")
        
        # Should create separate chunks for each function
        assert len(chunks) >= 1
        assert all(chunk.chunk_type == "function_definition" for chunk in chunks)

    def test_with_imports(self) -> None:
        """Import statements extracted to header."""
        code = b'''import sys
from typing import Dict, List

def process_data(data: List[str]) -> Dict[str, int]:
    """Process data."""
    return {item: len(item) for item in data}
'''
        chunks = chunk_file(Path("with_imports.py"), code, "python")
        
        assert len(chunks) >= 1
        # Header should contain imports
        header = chunks[0].header
        assert "import sys" in header or "IMPORTS:" in header

    def test_size_constraints(self) -> None:
        """Large functions split appropriately."""
        # Create a large function
        lines = ["def big_function():\n"]
        lines.append('    """Big function."""\n')
        for i in range(100):
            lines.append(f"    var_{i} = {i} * 2\n")
        lines.append("    return var_99\n")
        
        code = "".join(lines).encode("utf-8")
        chunks = chunk_file(Path("big.py"), code, "python")
        
        # Should handle large code
        assert len(chunks) >= 1
        
        # Check size constraints (bytes not chars)
        for chunk in chunks:
            full_text = f"{chunk.header}\n{chunk.body}"
            text_bytes = len(full_text.encode("utf-8"))
            # Should respect max size (2000 bytes) or be close
            assert text_bytes <= 2500  # Some tolerance for headers


class TestTypeScriptChunking:
    """Test TypeScript file chunking."""

    def test_function_declaration(self) -> None:
        """TypeScript function chunked correctly."""
        code = b'''function greet(name: string): string {
    return `Hello, ${name}!`;
}
'''
        chunks = chunk_file(Path("test.ts"), code, "typescript")
        
        assert len(chunks) >= 1
        assert chunks[0].language == "typescript"
        assert "function greet" in chunks[0].body

    def test_class_with_interface(self) -> None:
        """TypeScript class and interface."""
        code = b'''interface Person {
    name: string;
    age: number;
}

class User implements Person {
    constructor(public name: string, public age: number) {}
    
    greet(): string {
        return `Hello, I'm ${this.name}`;
    }
}
'''
        chunks = chunk_file(Path("user.ts"), code, "typescript")
        
        # Should chunk interface and class separately
        assert len(chunks) >= 1


class TestContentHashing:
    """Test content-hash based deduplication."""

    def test_identical_code_same_hash(self) -> None:
        """Identical code produces identical hash."""
        code = b'''def test():
    return 42
'''
        chunks1 = chunk_file(Path("test1.py"), code, "python")
        chunks2 = chunk_file(Path("test2.py"), code, "python")
        
        # Different file paths but same code
        # Hashes should differ because header includes file path
        assert chunks1[0].content_hash != chunks2[0].content_hash
        
        # But same file, same code should have same hash
        chunks3 = chunk_file(Path("test1.py"), code, "python")
        assert chunks1[0].content_hash == chunks3[0].content_hash

    def test_modified_code_different_hash(self) -> None:
        """Modified code produces different hash."""
        code1 = b'''def test():
    return 42
'''
        code2 = b'''def test():
    return 43
'''
        chunks1 = chunk_file(Path("test.py"), code1, "python")
        chunks2 = chunk_file(Path("test.py"), code2, "python")
        
        assert chunks1[0].content_hash != chunks2[0].content_hash


class TestProjectIndexing:
    """Test full project indexing with file discovery."""

    def test_simple_project(self, tmp_path: Path) -> None:
        """Index a simple project directory."""
        # Create test project
        (tmp_path / "main.py").write_text('''def main():
    print("Hello")
''')
        (tmp_path / "utils.py").write_text('''def helper():
    return 42
''')
        
        # Index project
        chunks = index_project(tmp_path)
        
        # Should find both files
        assert len(chunks) >= 2
        paths = {chunk.path for chunk in chunks}
        assert "main.py" in paths
        assert "utils.py" in paths

    def test_gitignore_filtering(self, tmp_path: Path) -> None:
        """Files in .gitignore are excluded."""
        # Create files
        (tmp_path / "main.py").write_text("def main(): pass")
        (tmp_path / "secret.py").write_text("def secret(): pass")
        
        # Create .gitignore
        (tmp_path / ".gitignore").write_text("secret.py\n")
        
        # Index project
        chunks = index_project(tmp_path)
        
        # Should only find main.py
        paths = {chunk.path for chunk in chunks}
        assert "main.py" in paths
        assert "secret.py" not in paths

    def test_generated_file_exclusion(self, tmp_path: Path) -> None:
        """Generated files are excluded."""
        # Create normal file
        (tmp_path / "code.py").write_text("def code(): pass")
        
        # Create generated files
        (tmp_path / "generated_pb2.py").write_text("# Generated")
        (tmp_path / "script.min.js").write_text("// Minified")
        
        # Index project
        chunks = index_project(tmp_path)
        
        # Should only find code.py
        paths = {chunk.path for chunk in chunks}
        assert "code.py" in paths
        assert "generated_pb2.py" not in paths
        assert "script.min.js" not in paths

    def test_vendor_directory_exclusion(self, tmp_path: Path) -> None:
        """Vendor directories are excluded."""
        # Create normal file
        (tmp_path / "src").mkdir()
        (tmp_path / "src" / "main.py").write_text("def main(): pass")
        
        # Create vendor directory
        (tmp_path / "node_modules").mkdir()
        (tmp_path / "node_modules" / "lib.js").write_text("// Vendor")
        
        # Index project
        chunks = index_project(tmp_path)
        
        # Should only find src/main.py
        paths = {chunk.path for chunk in chunks}
        assert any("main.py" in p for p in paths)
        assert not any("node_modules" in p for p in paths)


class TestStructuralHeaders:
    """Test structural header generation."""

    def test_header_format(self) -> None:
        """Header follows exact format from TECHNICAL_SPEC."""
        code = b'''class MyClass:
    def method(self):
        pass
'''
        chunks = chunk_file(Path("test.py"), code, "python")
        
        header = chunks[0].header
        
        # Check required fields present
        assert "FILE: test.py" in header
        assert "LANG: python" in header
        assert "PARENT:" in header
        assert "IMPORTS:" in header
        assert "DECORATORS:" in header
        assert "-----" in header
        
        # Check delimiter is last line before body
        lines = header.split("\n")
        assert "-----" in lines

    def test_parent_scope_detection(self) -> None:
        """Parent class detected for methods."""
        code = b'''class Calculator:
    def add(self, a, b):
        return a + b
'''
        chunks = chunk_file(Path("calc.py"), code, "python")
        
        # TODO: When methods are chunked separately, verify parent scope
        # For now, class is one chunk
        assert len(chunks) >= 1


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
