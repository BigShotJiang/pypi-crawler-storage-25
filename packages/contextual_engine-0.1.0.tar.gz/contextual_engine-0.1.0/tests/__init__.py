"""
Test suite for Contextual.

Contains unit tests, integration tests, benchmark suites, and security tests.
Uses pytest with asyncio support.
"""
