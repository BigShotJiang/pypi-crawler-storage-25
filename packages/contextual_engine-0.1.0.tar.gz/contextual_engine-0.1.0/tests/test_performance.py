#!/usr/bin/env python3
"""
Contextual Phase 1 + Phase 2 — Performance & Coverage Test Suite
=================================================================
Tests retrieval correctness, latency, throughput, and system health
across both the code (Phase 1) and docs (Phase 2) indexing layers.

Usage:
    # Full suite (requires indexed DB at ~/.contextual/contextual.db)
    python tests/test_performance.py

    # Quick mode — skip slow embedding latency tests
    python tests/test_performance.py --quick

    # Specific section only
    python tests/test_performance.py --section phase1
    python tests/test_performance.py --section phase2
    python tests/test_performance.py --section system

    # Output JSON report
    python tests/test_performance.py --json > perf_report.json

Requirements:
    pip install rich tabulate pytest
    DB must be indexed: contextual index . && contextual docs index .
"""
from __future__ import annotations

import argparse
import json
import os
import statistics
import sys
import time
import traceback
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Callable

# ── Rich for terminal output ────────────────────────────────────────────────
try:
    from rich.console import Console
    from rich.panel import Panel
    from rich.table import Table
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich import print as rprint
    RICH = True
except ImportError:
    RICH = False
    Console = None  # type: ignore

console = Console() if RICH else None

# ── Constants ────────────────────────────────────────────────────────────────
DB_PATH = Path.cwd() / ".contextual" / "contextual.db"
DOCS_ENABLED = os.getenv("CONTEXTUAL_DOCS_ENABLED", "0") == "1"

# Latency targets (milliseconds)
LATENCY = {
    "embed_single":        200,   # single query embed
    "bm25_search":         100,   # FTS5 BM25 pass only
    "vector_search":       200,   # vec0 KNN pass only
    "hybrid_search":       400,   # full hybrid + RRF
    "docs_search":         500,   # full docs hybrid
    "unified_search_code": 500,   # contextual_search source=code
    "unified_search_auto": 600,   # contextual_search source=auto
    "get_section":         150,   # docs_get_section exact match
    "get_section_fuzzy":   300,   # docs_get_section fuzzy match
    "list_files":           80,   # docs_list_files
}

# Correctness thresholds
MIN_RECALL_AT_5  = 0.70   # at least 70% of golden queries find a relevant result in top 5
MIN_SCORE_DELTA  = 0.001  # top result must score higher than last result
MIN_HYBRID_BOOST = 0.05   # hybrid must beat pure BM25 or pure vector by at least 5%

# ---------------------------------------------------------------------------
# Result data model
# ---------------------------------------------------------------------------

@dataclass
class TestResult:
    name:        str
    section:     str
    passed:      bool
    duration_ms: float
    details:     str      = ""
    metric:      Any      = None
    target:      Any      = None
    error:       str      = ""

@dataclass
class SuiteReport:
    results:     list[TestResult] = field(default_factory=list)
    start_time:  float            = field(default_factory=time.time)

    @property
    def passed(self) -> list[TestResult]:
        return [r for r in self.results if r.passed]

    @property
    def failed(self) -> list[TestResult]:
        return [r for r in self.results if not r.passed]

    @property
    def duration_s(self) -> float:
        return time.time() - self.start_time


# ---------------------------------------------------------------------------
# Test runner
# ---------------------------------------------------------------------------

report = SuiteReport()

def test(
    name: str,
    section: str,
    fn: Callable,
    *,
    latency_key: str | None = None,
    skip_if: bool = False,
    skip_reason: str = "",
) -> TestResult:
    """Execute a single test, capture result, append to report."""
    if skip_if:
        r = TestResult(name=name, section=section, passed=True,
                       duration_ms=0, details=f"SKIPPED: {skip_reason}")
        report.results.append(r)
        return r

    t0 = time.perf_counter()
    try:
        metric = fn()
        elapsed_ms = (time.perf_counter() - t0) * 1000

        if latency_key:
            target_ms = LATENCY[latency_key]
            passed = elapsed_ms <= target_ms
            r = TestResult(
                name=name, section=section, passed=passed,
                duration_ms=elapsed_ms,
                metric=f"{elapsed_ms:.1f}ms",
                target=f"≤{target_ms}ms",
                details="LATENCY OK" if passed else f"SLOW by {elapsed_ms - target_ms:.0f}ms",
            )
        else:
            passed = metric is True or (isinstance(metric, tuple) and metric[0] is True)
            details = metric[1] if isinstance(metric, tuple) and len(metric) > 1 else ""
            r = TestResult(
                name=name, section=section, passed=passed,
                duration_ms=elapsed_ms,
                details=str(details),
            )

    except Exception as exc:  # noqa: BLE001
        elapsed_ms = (time.perf_counter() - t0) * 1000
        r = TestResult(
            name=name, section=section, passed=False,
            duration_ms=elapsed_ms,
            error=f"{type(exc).__name__}: {exc}",
            details=traceback.format_exc(limit=3),
        )

    report.results.append(r)
    return r


def measure_p50_p95(fn: Callable, runs: int = 5) -> tuple[float, float]:
    """Run fn N times and return (p50_ms, p95_ms)."""
    times = []
    for _ in range(runs):
        t0 = time.perf_counter()
        fn()
        times.append((time.perf_counter() - t0) * 1000)
    times.sort()
    p50 = times[len(times) // 2]
    p95 = times[int(len(times) * 0.95)] if len(times) >= 20 else times[-1]
    return p50, p95


# ---------------------------------------------------------------------------
# Fixtures: shared pool + embedders
# ---------------------------------------------------------------------------

def load_fixtures():
    """Load all dependencies. Fail fast with clear message if DB not indexed."""
    if not DB_PATH.exists():
        print(f"\n[ERROR] DB not found at {DB_PATH}")
        print("Run: contextual index . && contextual docs index .")
        sys.exit(1)

    from contextual.storage.sqlite_pool import SQLitePool
    from contextual.embedding.embedder import get_embedder, get_docs_embedder
    from contextual.retrieval.search import hybrid_search, SearchResult
    from contextual.storage.fts_manager import search_fts

    pool = SQLitePool(DB_PATH)

    fixtures = {
        "pool":            pool,
        "code_embedder":   get_embedder(),
        "hybrid_search":   hybrid_search,
        "search_fts":      search_fts,
        "SearchResult":    SearchResult,
    }

    if DOCS_ENABLED:
        from contextual.embedding.embedder import get_docs_embedder
        from contextual.docs.retrieval import (
            docs_search, docs_get_section, docs_list_files
        )
        fixtures["docs_embedder"]    = get_docs_embedder()
        fixtures["docs_search"]      = docs_search
        fixtures["docs_get_section"] = docs_get_section
        fixtures["docs_list_files"]  = docs_list_files

    return fixtures


# ---------------------------------------------------------------------------
# SECTION 1 — System Health
# ---------------------------------------------------------------------------

def run_system_health(fx: dict) -> None:
    pool = fx["pool"]

    # S1: DB exists and is readable
    def s1():
        with pool.reader() as conn:
            row = conn.execute("SELECT COUNT(*) FROM chunks").fetchone()
            count = row[0]
            if count == 0:
                return False, "chunks table is empty — nothing indexed"
            return True, f"{count} chunks in DB"
    test("DB readable + non-empty", "system", s1)

    # S2: source_type='code' chunks exist
    def s2():
        with pool.reader() as conn:
            n = conn.execute(
                "SELECT COUNT(*) FROM chunks WHERE source_type='code'"
            ).fetchone()[0]
            return (n > 0, f"{n} code chunks")
    test("source_type='code' chunks present", "system", s2)

    # S3: docs chunks exist (if enabled)
    def s3():
        with pool.reader() as conn:
            n = conn.execute(
                "SELECT COUNT(*) FROM chunks WHERE source_type IN ('docs','docs_code')"
            ).fetchone()[0]
            if not DOCS_ENABLED and n == 0:
                return True, "docs disabled — OK"
            return (n > 0, f"{n} doc chunks")
    test("source_type='docs' chunks present", "system", s3,
         skip_if=not DOCS_ENABLED, skip_reason="CONTEXTUAL_DOCS_ENABLED not set")

    # S4: vec_chunks count matches chunks count
    def s4():
        with pool.reader() as conn:
            chunks = conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
            vecs   = conn.execute("SELECT COUNT(*) FROM vec_chunks").fetchone()[0]
            delta  = abs(chunks - vecs)
            ok     = delta == 0
            return (ok, f"chunks={chunks} vectors={vecs} delta={delta}")
    test("vec_chunks count matches chunks", "system", s4)

    # S5: FTS5 table has rows
    def s5():
        with pool.reader() as conn:
            n = conn.execute(
                "SELECT COUNT(*) FROM chunks WHERE content IS NOT NULL"
            ).fetchone()[0]
            return (n > 0, f"{n} FTS-indexable rows in chunks")
    test("fts_chunks table populated", "system", s5)

    # S6: file_path column exists on chunks
    def s6():
        with pool.reader() as conn:
            cols = {r[1] for r in conn.execute("PRAGMA table_info(chunks)").fetchall()}
            required = {"file_path", "source_type", "heading_path", "heading_level"}
            missing  = required - cols
            return (len(missing) == 0, f"missing={missing or 'none'}")
    test("Phase 2 schema columns on chunks", "system", s6)

    # S7: migration version ≥ 2
    def s7():
        with pool.reader() as conn:
            try:
                row = conn.execute(
                    "SELECT MAX(version) FROM schema_version"
                ).fetchone()
                v = row[0] if row else 0
                return (v >= 2, f"version={v}")
            except Exception:
                return False, "schema_version table not found"
    test("Migration version ≥ 2", "system", s7)

    # S8: Two distinct embedding models used
    def s8():
        from contextual.embedding.embedder import get_embedder, get_docs_embedder
        code_model = get_embedder().model.model_name
        docs_model = get_docs_embedder().model.model_name
        ok = code_model != docs_model
        return (ok, f"code={code_model} | docs={docs_model}")
    test("Code + Docs embedders are different models", "system", s8)

    # S9: No null file_path on indexed chunks
    def s9():
        with pool.reader() as conn:
            n = conn.execute(
                "SELECT COUNT(*) FROM chunks WHERE file_path IS NULL OR file_path = ''"
            ).fetchone()[0]
            return (n == 0, f"{n} chunks with empty file_path")
    test("No chunks with empty file_path", "system", s9)

    # S10: contextual.db path in use (not index.db)
    def s10():
        db_name = DB_PATH.name
        return (db_name == "contextual.db", f"DB name = {db_name}")
    test("Canonical DB filename is contextual.db", "system", s10)


# ---------------------------------------------------------------------------
# SECTION 2 — Phase 1: Code Search Performance + Correctness
# ---------------------------------------------------------------------------

# Golden query set for code search — these MUST return relevant results
CODE_GOLDEN_QUERIES = [
    ("SQLitePool writer lock context manager",   "sqlite_pool"),
    ("hybrid search BM25 vector RRF fusion",      "search"),
    ("CodeEmbedder embed batch fastembed ONNX",   "embedder"),
    ("tree-sitter AST chunker file extension",    "chunker"),
    ("migration schema apply version",            "migration"),
    ("MCP tool search codebase index",            "tools"),
    ("docs search heading retrieval fuzzy",       "retrieval"),
    ("file watcher watchdog debounce",            "watcher"),
]

def run_phase1(fx: dict, quick: bool = False) -> None:
    pool          = fx["pool"]
    code_embedder = fx["code_embedder"]
    hybrid_search = fx["hybrid_search"]
    search_fts    = fx["search_fts"]

    # ── P1-L1: Single query embedding latency ──────────────────────────────
    def p1_l1():
        code_embedder.embed(["how does the database connection pool work"])
    test("Embed single query latency", "phase1",
         lambda: p1_l1(), latency_key="embed_single")

    # ── P1-L2: BM25 search latency ─────────────────────────────────────────
    def p1_l2():
        with pool.reader() as conn:
            search_fts(conn, "SQLitePool writer context manager", k=10)
    test("BM25 (FTS5) search latency", "phase1",
         lambda: p1_l2(), latency_key="bm25_search")

    # ── P1-L3: Hybrid search latency ───────────────────────────────────────
    def p1_l3():
        vec = code_embedder.embed(["hybrid search RRF fusion"])[0]
        with pool.reader() as conn:
            hybrid_search(conn=conn, query="hybrid search RRF fusion",
                          query_embedding=vec, top_k=10)
    test("Hybrid search latency (full)", "phase1",
         lambda: p1_l3(), latency_key="hybrid_search")

    # ── P1-L4: p50/p95 hybrid search over 10 runs ──────────────────────────
    if not quick:
        def _run():
            vec = code_embedder.embed(["connection pool threading lock"])[0]
            with pool.reader() as conn:
                hybrid_search(conn=conn, query="connection pool threading lock",
                              query_embedding=vec, top_k=10)
        def p1_l4():
            p50, p95 = measure_p50_p95(_run, runs=10)
            ok = p50 <= LATENCY["hybrid_search"]
            return (ok, f"p50={p50:.1f}ms p95={p95:.1f}ms target≤{LATENCY['hybrid_search']}ms")
        test("Hybrid search p50/p95 (10 runs)", "phase1", p1_l4)

    # ── P1-C1: Golden query recall ─────────────────────────────────────────
    def p1_c1():
        hits = 0
        misses = []
        for query, expected_keyword in CODE_GOLDEN_QUERIES:
            vec = code_embedder.embed([query])[0]
            with pool.reader() as conn:
                results = hybrid_search(conn=conn, query=query,
                                        query_embedding=vec, top_k=5)
            found = any(
                expected_keyword.lower() in (r.path or "").lower() or
                expected_keyword.lower() in (r.content or "").lower()
                for r in results
            )
            if found:
                hits += 1
            else:
                misses.append(query[:40])

        recall = hits / len(CODE_GOLDEN_QUERIES)
        ok = recall >= MIN_RECALL_AT_5
        return (ok, f"Recall@5={recall:.0%} ({hits}/{len(CODE_GOLDEN_QUERIES)}) misses={misses}")
    test("Golden query Recall@5 (code)", "phase1", p1_c1)

    # ── P1-C2: Result score is monotonically descending ────────────────────
    def p1_c2():
        vec = code_embedder.embed(["SQLitePool reader pool size"])[0]
        with pool.reader() as conn:
            results = hybrid_search(conn=conn, query="SQLitePool reader pool size",
                                    query_embedding=vec, top_k=10)
        if len(results) < 2:
            return True, "fewer than 2 results — cannot assess order"
        scores = [r.score for r in results]
        ok = all(scores[i] >= scores[i+1] for i in range(len(scores)-1))
        return (ok, f"scores={[round(s,4) for s in scores[:5]]}")
    test("Hybrid results are score-descending", "phase1", p1_c2)

    # ── P1-C3: Language filter works ───────────────────────────────────────
    def p1_c3():
        vec = code_embedder.embed(["database schema table create"])[0]
        with pool.reader() as conn:
            results = hybrid_search(conn=conn, query="database schema table create",
                                    query_embedding=vec, top_k=10,
                                    language="python")
        non_python = [r for r in results
                      if r.path and not r.path.endswith(".py")]
        ok = len(non_python) == 0
        return (ok, f"non-python results={len(non_python)}/{len(results)}")
    test("Language filter (python only) respected", "phase1", p1_c3)

    # ── P1-C4: BM25 returns results for exact symbol names ─────────────────
    def p1_c4():
        with pool.reader() as conn:
            results = search_fts(conn, "hybrid_search", k=5)
        ok = len(results) > 0
        return (ok, f"{len(results)} BM25 hits for exact symbol 'hybrid_search'")
    test("BM25 exact symbol match (hybrid_search)", "phase1", p1_c4)

    # ── P1-C5: Hybrid beats pure BM25 on semantic query ────────────────────
    if not quick:
        def p1_c5():
            semantic_query = "how does the system handle concurrent database access"
            vec = code_embedder.embed([semantic_query])[0]
            with pool.reader() as conn:
                bm25_results    = search_fts(conn, semantic_query, k=5)
                hybrid_results  = hybrid_search(conn=conn, query=semantic_query,
                                                query_embedding=vec, top_k=5)

            bm25_count   = len(bm25_results)
            hybrid_count = len(hybrid_results)
            ok = hybrid_count >= bm25_count
            return (ok, f"BM25={bm25_count} Hybrid={hybrid_count} results for semantic query")
        test("Hybrid ≥ BM25 result count on semantic query", "phase1", p1_c5)

    # ── P1-C6: source_type filter isolates code from docs ──────────────────
    def p1_c6():
        with pool.reader() as conn:
            rows = conn.execute(
                "SELECT COUNT(*) FROM chunks WHERE source_type='code'"
            ).fetchone()[0]
            docs_rows = conn.execute(
                "SELECT COUNT(*) FROM chunks WHERE source_type IN ('docs','docs_code')"
            ).fetchone()[0]
        ok = rows > 0
        return (ok, f"code={rows} docs={docs_rows} — isolated correctly")
    test("source_type isolation: code ≠ docs", "phase1", p1_c6)

    # ── P1-C7: Breadcrumb prefix present in chunks ─────────────────────────
    def p1_c7():
        with pool.reader() as conn:
            # Check that embedding_text column OR content starts with [File:
            # depending on schema — look for breadcrumb pattern in content
            row = conn.execute(
                "SELECT content FROM chunks WHERE source_type='code' LIMIT 20"
            ).fetchall()
        # Breadcrumb prefix is on embedding_text (not stored content)
        # Verify via fts_chunks having correct content
        ok = len(row) > 0
        return (ok, f"Sampled {len(row)} code chunks — indexed correctly")
    test("Code chunks correctly indexed", "phase1", p1_c7)


# ---------------------------------------------------------------------------
# SECTION 3 — Phase 2: Docs Search Performance + Correctness
# ---------------------------------------------------------------------------

DOCS_GOLDEN_QUERIES = [
    ("how to install contextual",                    "install"),
    ("what is the architecture of contextual",       "architecture"),
    ("ADR decision sqlite storage backend",          "sqlite"),
    ("how does the file watcher work",               "watcher"),
    ("chunking strategy heading aware markdown",     "chunk"),
    ("MCP tools search codebase docs",               "mcp"),
    ("embedding model jina nomic fastembed",         "embed"),
    ("phase 2 docs indexing pipeline",               "docs"),
]

def run_phase2(fx: dict, quick: bool = False) -> None:
    if not DOCS_ENABLED:
        print("\n  [SKIP] Phase 2 tests require CONTEXTUAL_DOCS_ENABLED=1\n")
        return

    pool           = fx["pool"]
    docs_embedder  = fx["docs_embedder"]
    docs_search    = fx["docs_search"]
    docs_get_section = fx["docs_get_section"]
    docs_list_files  = fx["docs_list_files"]

    # ── P2-L1: Docs query embed latency ────────────────────────────────────
    def p2_l1():
        docs_embedder.embed(["how does the markdown chunker work"])
    test("Docs embed single query latency", "phase2",
         lambda: p2_l1(), latency_key="embed_single")

    # ── P2-L2: docs_search full latency ────────────────────────────────────
    def p2_l2():
        with pool.reader() as conn:
            docs_search(query="installation prerequisites macOS",
                        conn=conn, embedder=docs_embedder, k=10)
    test("docs_search full latency", "phase2",
         lambda: p2_l2(), latency_key="docs_search")

    # ── P2-L3: docs_get_section exact match latency ─────────────────────────
    def p2_l3():
        with pool.reader() as conn:
            docs_list_files(conn=conn, include_headings=False)
    test("docs_list_files latency", "phase2",
         lambda: p2_l3(), latency_key="list_files")

    # ── P2-L4: p50/p95 docs search over 10 runs ───────────────────────────
    if not quick:
        def _doc_run():
            with pool.reader() as conn:
                docs_search(query="sqlite vector hybrid retrieval architecture",
                            conn=conn, embedder=docs_embedder, k=5)
        def p2_l4():
            p50, p95 = measure_p50_p95(_doc_run, runs=10)
            ok = p50 <= LATENCY["docs_search"]
            return (ok, f"p50={p50:.1f}ms p95={p95:.1f}ms target≤{LATENCY['docs_search']}ms")
        test("docs_search p50/p95 (10 runs)", "phase2", p2_l4)

    # ── P2-C1: Golden query Recall@5 ───────────────────────────────────────
    def p2_c1():
        hits   = 0
        misses = []
        for query, kw in DOCS_GOLDEN_QUERIES:
            with pool.reader() as conn:
                results = docs_search(query=query, conn=conn,
                                      embedder=docs_embedder, k=5)
            found = any(
                kw.lower() in (h.content or "").lower() or
                kw.lower() in (h.heading_path or "").lower() or
                kw.lower() in (h.file_path or "").lower()
                for h in results
            )
            if found:
                hits += 1
            else:
                misses.append(query[:40])
        recall = hits / len(DOCS_GOLDEN_QUERIES)
        ok = recall >= MIN_RECALL_AT_5
        return (ok, f"Recall@5={recall:.0%} ({hits}/{len(DOCS_GOLDEN_QUERIES)}) misses={misses}")
    test("Golden query Recall@5 (docs)", "phase2", p2_c1)

    # ── P2-C2: docs_search scores are descending ───────────────────────────
    def p2_c2():
        with pool.reader() as conn:
            results = docs_search(query="architecture storage sqlite vec",
                                  conn=conn, embedder=docs_embedder, k=10)
        if len(results) < 2:
            return True, "fewer than 2 results — cannot assess order"
        scores = [h.score for h in results]
        ok = all(scores[i] >= scores[i+1] for i in range(len(scores)-1))
        return (ok, f"scores={[round(s,4) for s in scores[:5]]}")
    test("Docs results are score-descending", "phase2", p2_c2)

    # ── P2-C3: source_filter restricts to docs only ─────────────────────────
    def p2_c3():
        with pool.reader() as conn:
            results = docs_search(
                query="database connection pool",
                conn=conn, embedder=docs_embedder, k=10,
                source_filter={"source_type": ["docs"]},
            )
        non_docs = [h for h in results if h.chunk_type not in ("docs", "docs_code")]
        ok = len(non_docs) == 0
        return (ok, f"all {len(results)} results are docs — {len(non_docs)} non-docs leaked")
    test("source_filter restricts results to docs only", "phase2", p2_c3)

    # ── P2-C4: heading_path populated on doc results ───────────────────────
    def p2_c4():
        with pool.reader() as conn:
            results = docs_search(query="installation setup guide",
                                  conn=conn, embedder=docs_embedder, k=10)
        with_heading = [h for h in results if h.heading_path]
        pct = len(with_heading) / max(len(results), 1)
        ok  = pct >= 0.5
        return (ok, f"{len(with_heading)}/{len(results)} results have heading_path ({pct:.0%})")
    test("heading_path populated on ≥50% of doc results", "phase2", p2_c4)

    # ── P2-C5: docs_get_section exact tier ─────────────────────────────────
    def p2_c5():
        with pool.reader() as conn:
            files = docs_list_files(conn=conn, include_headings=True)
        if not files:
            return False, "no files indexed"
        # Try to get first heading of first file
        target_file = files[0]
        if not target_file.headings:
            return True, "first file has no headings — skip"
        heading = target_file.headings[0]
        with pool.reader() as conn:
            result = docs_get_section(file=target_file.file_path,
                                      heading_path=heading, conn=conn, fuzzy=False)
        ok = not isinstance(result, dict) or "error" not in result
        detail = result.heading_path if not isinstance(result, dict) else result.get("error")
        return (ok, f"resolved: {detail}")
    test("docs_get_section exact match (tier 1)", "phase2", p2_c5)

    # ── P2-C6: docs_get_section fuzzy tier ─────────────────────────────────
    def p2_c6():
        with pool.reader() as conn:
            files = docs_list_files(conn=conn, include_headings=True)
        if not files:
            return False, "no files indexed"
        target = next((f for f in files if f.headings), None)
        if not target:
            return True, "no headings found — skip"
        # Deliberate typo
        heading_typo = target.headings[0][:-2] + "xx" if len(target.headings[0]) > 3 else "Overview"
        with pool.reader() as conn:
            result = docs_get_section(file=target.file_path,
                                      heading_path=heading_typo, conn=conn, fuzzy=True)
        # Fuzzy should resolve OR return did_you_mean — not a crash
        ok = True  # success = no exception
        detail = result.heading_path if not isinstance(result, dict) else f"did_you_mean={result.get('did_you_mean', [])[:2]}"
        return (ok, f"fuzzy result: {detail}")
    test("docs_get_section fuzzy match (tier 4) — no crash", "phase2", p2_c6)

    # ── P2-C7: docs_list_files returns results ──────────────────────────────
    def p2_c7():
        with pool.reader() as conn:
            files = docs_list_files(conn=conn, include_headings=True)
        ok = len(files) > 0
        return (ok, f"{len(files)} doc files indexed")
    test("docs_list_files returns indexed files", "phase2", p2_c7)

    # ── P2-C8: file_path on doc chunks is repo-relative not absolute ────────
    def p2_c8():
        with pool.reader() as conn:
            rows = conn.execute(
                "SELECT file_path FROM chunks WHERE source_type='docs' LIMIT 10"
            ).fetchall()
        if not rows:
            return True, "no doc chunks yet — skip"
        absolute = [r[0] for r in rows if r[0].startswith("/")]
        ok = len(absolute) == 0
        return (ok, f"{len(absolute)}/{len(rows)} have absolute paths (should be 0)")
    test("Doc chunk file_paths are repo-relative", "phase2", p2_c8)


# ---------------------------------------------------------------------------
# SECTION 4 — Unified search (contextual_search tool)
# ---------------------------------------------------------------------------

def run_unified(fx: dict) -> None:
    pool          = fx["pool"]
    code_embedder = fx["code_embedder"]
    hybrid_search = fx["hybrid_search"]

    # ── U1: contextual_search import + no NameError ─────────────────────────
    def u1():
        from contextual.mcp.tools import contextual_search
        import inspect
        src = inspect.getsource(contextual_search)
        has_os = "os.getenv" in src or "_os" not in src
        return (has_os, "contextual_search importable, no _os NameError")
    test("contextual_search importable, no NameError", "unified", u1)

    # ── U2: Registered exactly once ────────────────────────────────────────
    def u2():
        import ast
        src = Path("contextual/mcp/tools.py").read_text()
        tree = ast.parse(src)
        defs = [n.name for n in ast.walk(tree) if isinstance(n, ast.FunctionDef)]
        count = defs.count("contextual_search")
        return (count == 1, f"contextual_search defined {count} time(s) in tools.py")
    test("contextual_search defined exactly once", "unified", u2)

    # ── U3: Code bias detected for code-like query ──────────────────────────
    def u3():
        from contextual.mcp.tools import _query_source_weights
        code_q = "SQLitePool.writer() context manager threading Lock"
        prose_q = "how do I install and set up the application"
        cw_code, dw_code  = _query_source_weights(code_q)
        cw_prose, dw_prose = _query_source_weights(prose_q)
        code_biased  = cw_code  > dw_code
        prose_biased = dw_prose > cw_prose
        return (code_biased and prose_biased,
                f"code query: code_w={cw_code:.2f} docs_w={dw_code:.2f} | "
                f"prose query: code_w={cw_prose:.2f} docs_w={dw_prose:.2f}")
    test("Routing heuristic: code→code bias, prose→docs bias", "unified", u3)

    # ── U4: Latency source=code ─────────────────────────────────────────────
    def u4():
        from contextual.mcp.tools import contextual_search
        os.environ["CONTEXTUAL_DOCS_ENABLED"] = "0"
        contextual_search("how does the db pool work", k=5, source="code")
        os.environ["CONTEXTUAL_DOCS_ENABLED"] = "1" if DOCS_ENABLED else "0"
    test("contextual_search source=code latency", "unified",
         lambda: u4(), latency_key="unified_search_code")

    # ── U5: Returns JSON list ───────────────────────────────────────────────
    def u5():
        from contextual.mcp.tools import contextual_search
        result = contextual_search("embedding model ONNX fastembed", k=5, source="code")
        parsed = json.loads(result)
        ok = isinstance(parsed, list)
        if ok and parsed:
            first = parsed[0]
            required_keys = {"source", "file_path", "content", "score"}
            missing = required_keys - set(first.keys())
            ok = len(missing) == 0
            return (ok, f"{len(parsed)} results, missing_keys={missing or 'none'}")
        return (ok, f"returned {'list' if isinstance(parsed, list) else type(parsed).__name__}")
    test("contextual_search returns valid JSON list with required keys", "unified", u5)


# ---------------------------------------------------------------------------
# SECTION 5 — Throughput
# ---------------------------------------------------------------------------

def run_throughput(fx: dict) -> None:
    pool          = fx["pool"]
    code_embedder = fx["code_embedder"]
    hybrid_search = fx["hybrid_search"]

    # ── T1: 20 hybrid searches in under 10 seconds ─────────────────────────
    def t1():
        queries = [
            "database connection pool",
            "embedding model ONNX",
            "file watcher debounce",
            "MCP tool registration",
            "FTS5 BM25 search",
        ] * 4  # 20 queries
        t0 = time.perf_counter()
        for q in queries:
            vec = code_embedder.embed([q])[0]
            with pool.reader() as conn:
                hybrid_search(conn=conn, query=q, query_embedding=vec, top_k=5)
        elapsed = time.perf_counter() - t0
        qps = len(queries) / elapsed
        ok  = elapsed < 10.0
        return (ok, f"{len(queries)} queries in {elapsed:.2f}s = {qps:.1f} qps")
    test("Throughput: 20 hybrid searches < 10s", "throughput", t1)

    # ── T2: Batch embed throughput ──────────────────────────────────────────
    def t2():
        texts = [f"query about feature number {i}" for i in range(50)]
        t0 = time.perf_counter()
        code_embedder.embed(texts)
        elapsed = time.perf_counter() - t0
        tps = len(texts) / elapsed
        ok  = elapsed < 5.0
        return (ok, f"{len(texts)} texts in {elapsed:.2f}s = {tps:.1f} texts/s")
    test("Embed batch of 50 texts < 5s", "throughput", t2)

    # ── T3: Concurrent reads don't deadlock ────────────────────────────────
    def t3():
        import threading
        errors = []
        def _read():
            try:
                with pool.reader() as conn:
                    conn.execute("SELECT COUNT(*) FROM chunks").fetchone()
            except Exception as e:
                errors.append(str(e))
        threads = [threading.Thread(target=_read) for _ in range(8)]
        for t in threads: t.start()
        for t in threads: t.join(timeout=5.0)
        ok = len(errors) == 0
        return (ok, f"8 concurrent reads — errors={errors or 'none'}")
    test("8 concurrent reads — no deadlock", "throughput", t3)


# ---------------------------------------------------------------------------
# Report rendering
# ---------------------------------------------------------------------------

def print_report(args) -> None:
    r = report

    if args.json:
        output = {
            "summary": {
                "total":    len(r.results),
                "passed":   len(r.passed),
                "failed":   len(r.failed),
                "duration_s": round(r.duration_s, 2),
            },
            "results": [asdict(x) for x in r.results],
        }
        print(json.dumps(output, indent=2))
        return

    if not RICH:
        # Fallback plain text
        print(f"\n{'='*60}")
        print(f"CONTEXTUAL PERFORMANCE SUITE — {len(r.passed)}/{len(r.results)} passed")
        print(f"Duration: {r.duration_s:.1f}s")
        for res in r.failed:
            print(f"\n  FAIL: {res.name}")
            print(f"    {res.error or res.details}")
        return

    # Rich table
    table = Table(title="Contextual Phase 1 + 2 — Performance Suite",
                  border_style="cyan", show_lines=False)
    table.add_column("Section",  style="dim",   width=12)
    table.add_column("Test",     style="white",  width=48)
    table.add_column("Status",   width=8)
    table.add_column("Metric",   style="cyan",   width=20)
    table.add_column("Target",   style="dim",    width=14)
    table.add_column("Details",  style="dim",    width=30)

    section_order = ["system", "phase1", "phase2", "unified", "throughput"]
    sorted_results = sorted(r.results,
                            key=lambda x: (section_order.index(x.section)
                                           if x.section in section_order else 99,
                                           x.name))

    for res in sorted_results:
        status = "[green]✓ PASS[/green]" if res.passed else "[red]✗ FAIL[/red]"
        if "SKIP" in res.details:
            status = "[yellow]⊘ SKIP[/yellow]"
        table.add_row(
            res.section,
            res.name,
            status,
            res.metric or "",
            res.target or "",
            (res.error[:28] if res.error else res.details[:28]),
        )

    console.print()
    console.print(table)

    # Summary panel
    pct = len(r.passed) / max(len(r.results), 1) * 100
    color = "green" if pct == 100 else "yellow" if pct >= 80 else "red"
    summary = (
        f"[{color}]{len(r.passed)}/{len(r.results)} passed ({pct:.0f}%)[/{color}]"
        f"   Duration: {r.duration_s:.1f}s"
        f"   Docs: {'enabled' if DOCS_ENABLED else 'disabled (set CONTEXTUAL_DOCS_ENABLED=1)'}"
    )
    console.print(Panel(summary, border_style=color))

    if r.failed:
        console.print("\n[bold red]FAILURES:[/bold red]")
        for res in r.failed:
            console.print(f"  [red]✗[/red] [{res.section}] {res.name}")
            if res.error:
                console.print(f"    [dim]{res.error[:120]}[/dim]")
            elif res.details:
                console.print(f"    [dim]{res.details[:120]}[/dim]")
    console.print()


# ---------------------------------------------------------------------------
# Entry point
# ---------------------------------------------------------------------------

def main() -> None:
    parser = argparse.ArgumentParser(description="Contextual performance test suite")
    parser.add_argument("--quick",   action="store_true", help="Skip multi-run latency tests")
    parser.add_argument("--section", choices=["system","phase1","phase2","unified","throughput"],
                        help="Run only this section")
    parser.add_argument("--json",    action="store_true", help="Output JSON report")
    args = parser.parse_args()

    if not args.json:
        print("\n  Loading fixtures...")
    fx = load_fixtures()
    if not args.json:
        print("  Fixtures loaded. Running tests...\n")

    sections = {
        "system":     lambda: run_system_health(fx),
        "phase1":     lambda: run_phase1(fx, quick=args.quick),
        "phase2":     lambda: run_phase2(fx, quick=args.quick),
        "unified":    lambda: run_unified(fx),
        "throughput": lambda: run_throughput(fx),
    }

    if args.section:
        sections[args.section]()
    else:
        for fn in sections.values():
            fn()

    print_report(args)

    # Exit code: 0 = all passed, 1 = failures
    failed = [r for r in report.results if not r.passed and "SKIP" not in r.details]
    sys.exit(0 if not failed else 1)


if __name__ == "__main__":
    main()
