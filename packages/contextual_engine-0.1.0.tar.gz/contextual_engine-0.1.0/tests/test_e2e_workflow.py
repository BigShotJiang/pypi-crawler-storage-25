"""End-to-end workflow tests for Contextual.

Tests complete flows:
- Initialize → Index → Search → Retrieve
- CLI command integration
- MCP tool integration
- Git attribution integration
"""

from __future__ import annotations

import shutil
import tempfile
from pathlib import Path

import pytest

from contextual.git import GitRepository
from contextual.indexing.pipeline import IndexingPipeline
from contextual.retrieval.search import hybrid_search
from contextual.embedding import embed_query_simple
from contextual.storage.migrations import run_migrations
from contextual.storage.sqlite_pool import SQLitePool


@pytest.fixture
def temp_repo(tmp_path: Path) -> Path:
    """Create a temporary git repository with sample code."""
    repo_path = tmp_path / "sample_repo"
    repo_path.mkdir()
    
    # Initialize git repo
    import subprocess
    subprocess.run(["git", "init"], cwd=repo_path, check=True, capture_output=True)
    subprocess.run(
        ["git", "config", "user.name", "Test User"],
        cwd=repo_path,
        check=True,
        capture_output=True,
    )
    subprocess.run(
        ["git", "config", "user.email", "test@example.com"],
        cwd=repo_path,
        check=True,
        capture_output=True,
    )
    
    # Create sample files
    (repo_path / "main.py").write_text("""
def calculate_fibonacci(n: int) -> int:
    \"\"\"Calculate nth Fibonacci number.\"\"\"
    if n <= 1:
        return n
    return calculate_fibonacci(n - 1) + calculate_fibonacci(n - 2)


def main():
    result = calculate_fibonacci(10)
    print(f"Result: {result}")


if __name__ == "__main__":
    main()
""")
    
    (repo_path / "utils.py").write_text("""
import json
from pathlib import Path


def load_config(path: Path) -> dict:
    \"\"\"Load JSON configuration from file.\"\"\"
    with open(path) as f:
        return json.load(f)


def save_config(data: dict, path: Path) -> None:
    \"\"\"Save configuration to JSON file.\"\"\"
    with open(path, 'w') as f:
        json.dump(data, f, indent=2)
""")
    
    # Commit files
    subprocess.run(["git", "add", "."], cwd=repo_path, check=True, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "Initial commit"],
        cwd=repo_path,
        check=True,
        capture_output=True,
    )
    
    return repo_path


@pytest.fixture
def db_pool(tmp_path: Path) -> SQLitePool:
    """Create test database with migrations."""
    db_path = tmp_path / "test.db"
    pool = SQLitePool(db_path)
    
    with pool.writer() as conn:
        run_migrations(conn)
    
    return pool


def test_e2e_index_and_search(temp_repo: Path, db_pool: SQLitePool) -> None:
    """Test complete flow: index repository then search it."""
    # Step 1: Index the repository
    pipeline = IndexingPipeline(repo_root=temp_repo, db_pool=db_pool)
    result = pipeline.index_repository()
    
    # Verify indexing worked
    assert result["files"] == 2
    assert result["chunks"] >= 2
    assert result["embeddings"] >= 2
    
    # Step 2: Search for code
    # Search for fibonacci
    fib_query_emb = embed_query_simple("fibonacci recursive function")
    with db_pool.reader() as conn:
        fib_results = hybrid_search(
            conn=conn,
            query="fibonacci recursive function",
            query_embedding=fib_query_emb,
            top_k=5,
        )
    assert len(fib_results) > 0
    assert any("fibonacci" in r.snippet.lower() for r in fib_results)
    
    # Search for JSON config
    config_query_emb = embed_query_simple("load JSON configuration")
    with db_pool.reader() as conn:
        config_results = hybrid_search(
            conn=conn,
            query="load JSON configuration",
            query_embedding=config_query_emb,
            top_k=5,
        )
    assert len(config_results) > 0
    assert any("json" in r.snippet.lower() for r in config_results)
    
    # Step 3: Verify result structure
    result = fib_results[0]
    assert result.path
    assert result.start_line > 0
    assert result.end_line >= result.start_line
    assert result.snippet
    assert 0.0 <= result.score <= 1.0


def test_e2e_git_attribution(temp_repo: Path) -> None:
    """Test git blame integration with indexed code."""
    # Initialize git repo wrapper
    git_repo = GitRepository(temp_repo)
    
    # Test file tracking
    assert git_repo.is_tracked("main.py")
    assert git_repo.is_tracked("utils.py")
    
    # Get blame for fibonacci function (lines 2-7 approx)
    blame_info = git_repo.get_blame("main.py", start_line=2, end_line=7)
    assert len(blame_info) > 0
    assert blame_info[0].author == "Test User"
    assert blame_info[0].email == "test@example.com"
    
    # Get chunk attribution
    attribution = git_repo.get_chunk_attribution("main.py", start_line=2, end_line=7)
    assert attribution.primary_author == "Test User"
    assert len(attribution.authors) > 0
    assert len(attribution.commits) > 0
    
    # Test repo info
    repo_info = git_repo.get_repo_info()
    assert repo_info["branch"] == "master" or repo_info["branch"] == "main"
    assert repo_info["head"]


def test_e2e_incremental_update(temp_repo: Path, db_pool: SQLitePool) -> None:
    """Test incremental indexing after file modification."""
    # Initial index
    pipeline = IndexingPipeline(repo_root=temp_repo, db_pool=db_pool)
    initial_result = pipeline.index_repository()
    
    initial_chunks = initial_result["chunks"]
    
    # Modify file
    (temp_repo / "new_file.py").write_text("""
def new_function():
    '''A newly added function.'''
    return 42
""")
    
    # Commit change
    import subprocess
    subprocess.run(["git", "add", "."], cwd=temp_repo, check=True, capture_output=True)
    subprocess.run(
        ["git", "commit", "-m", "Add new function"],
        cwd=temp_repo,
        check=True,
        capture_output=True,
    )
    
    # Re-index
    pipeline.index_repository()
    updated_result = pipeline.get_stats()
    
    # Should have more chunks now
    assert updated_result["chunks"] > initial_chunks
    assert updated_result["files"] == 3


def test_e2e_language_filtering(temp_repo: Path, db_pool: SQLitePool) -> None:
    """Test language-filtered search."""
    # Index repository
    pipeline = IndexingPipeline(repo_root=temp_repo, db_pool=db_pool)
    pipeline.index_repository()
    
    # Embed query
    query_embedding = embed_query_simple("calculate")
    
    # Search with Python filter
    with db_pool.reader() as conn:
        py_results = hybrid_search(
            conn=conn,
            query="calculate",
            query_embedding=query_embedding,
            top_k=10,
            language="python",
        )
    assert len(py_results) > 0
    assert all(r.path.endswith(".py") for r in py_results)
    
    # Search with TypeScript filter (should return nothing)
    with db_pool.reader() as conn:
        ts_results = hybrid_search(
            conn=conn,
            query="calculate",
            query_embedding=query_embedding,  # Reuse same embedding
            top_k=10,
            language="typescript",
        )
    assert len(ts_results) == 0


def test_e2e_stats_accuracy(temp_repo: Path, db_pool: SQLitePool) -> None:
    """Test that statistics match actual indexed data."""
    # Index repository
    pipeline = IndexingPipeline(repo_root=temp_repo, db_pool=db_pool)
    result = pipeline.index_repository()
    
    # Query stats directly
    with db_pool.reader() as conn:
        file_count = conn.execute("SELECT COUNT(*) FROM files").fetchone()[0]
        chunk_count = conn.execute("SELECT COUNT(*) FROM chunks").fetchone()[0]
        symbol_count = conn.execute("SELECT COUNT(*) FROM code_symbols").fetchone()[0]
    
    # Verify stats match indexing result
    assert file_count == result["files"]
    assert chunk_count == result["chunks"]
    assert symbol_count > 0  # Should have extracted some symbols


def test_e2e_empty_repository(tmp_path: Path, db_pool: SQLitePool) -> None:
    """Test graceful handling of empty repository."""
    empty_repo = tmp_path / "empty"
    empty_repo.mkdir()
    
    # Initialize git
    import subprocess
    subprocess.run(["git", "init"], cwd=empty_repo, check=True, capture_output=True)
    
    # Try to index (should succeed but with zero files)
    pipeline = IndexingPipeline(repo_root=empty_repo, db_pool=db_pool)
    result = pipeline.index_repository()
    
    assert result["files"] == 0
    assert result["chunks"] == 0
    
    # Search should return empty results
    query_embedding = embed_query_simple("anything")
    with db_pool.reader() as conn:
        results = hybrid_search(
            conn=conn,
            query="anything",
            query_embedding=query_embedding,
            top_k=10,
        )
    assert len(results) == 0
