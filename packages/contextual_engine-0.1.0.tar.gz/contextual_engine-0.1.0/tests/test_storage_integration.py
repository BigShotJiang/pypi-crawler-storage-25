"""Integration test for complete storage layer."""

from pathlib import Path
import tempfile
from contextual.security import init_workspace
from contextual.storage import SQLitePool, run_migrations
from contextual.observability.logging import configure_logging, get_logger

def test_complete_storage_layer():
    """Test complete storage layer integration."""
    
    # Setup logging
    configure_logging(log_level="DEBUG", enable_file_logging=False)
    logger = get_logger(__name__)
    
    logger.info("Starting integration test")
    
    # Create temporary workspace
    with tempfile.TemporaryDirectory() as tmpdir:
        project_root = Path(tmpdir)
        
        # 1. Initialize workspace (security layer)
        logger.info("Initializing workspace", project_root=str(project_root))
        manager = init_workspace(project_root)
        
        # Verify workspace created
        assert manager.workspace_dir.exists()
        assert (manager.workspace_dir / ".gitignore").exists()
        
        logger.info("✓ Workspace initialized")
        
        # 2. Get database path
        db_path = manager.get_db_path()
        logger.info("Database path", db_path=str(db_path))
        
        # 3. Create connection pool (storage layer)
        logger.info("Creating connection pool")
        pool = SQLitePool(db_path, reader_pool_size=2)
        
        try:
            # 4. Run migrations (applies schema)
            logger.info("Running migrations")
            migrations_applied = run_migrations(pool._writer_conn)
            
            assert migrations_applied == 1
            logger.info("✓ Migrations applied", count=migrations_applied)
            
            # 5. Verify schema was created
            with pool.reader() as conn:
                cursor = conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                )
                tables = [row[0] for row in cursor.fetchall()]
            
            expected_tables = {
                "entities", "facts", "episodes", 
                "code_blobs", "schema_version",
                "code_fts_ident", "code_fts_trigram"
            }
            
            assert expected_tables.issubset(set(tables))
            logger.info("✓ Schema validated", tables=len(tables))
            
            # 6. Test writer connection
            with pool.writer() as conn:
                conn.execute(
                    "INSERT INTO entities (name, entity_type, metadata, created_at) "
                    "VALUES (?, ?, ?, ?)",
                    ("test_function", "function", "{}", 1000000)
                )
                conn.commit()
            
            logger.info("✓ Write operation successful")
            
            # 7. Test reader connection
            with pool.reader() as conn:
                cursor = conn.execute("SELECT COUNT(*) FROM entities")
                count = cursor.fetchone()[0]
            
            assert count == 1
            logger.info("✓ Read operation successful", entity_count=count)
            
            # 8. Test WAL checkpoint
            pages_in_wal, checkpointed = pool.checkpoint_wal(mode="PASSIVE")
            logger.info("✓ WAL checkpoint successful", 
                       pages_in_wal=pages_in_wal,
                       checkpointed=checkpointed)
            
            # 9. Get database stats
            stats = pool.get_db_stats()
            logger.info("Database statistics", **stats)
            
            assert stats["journal_mode"] == "wal"
            logger.info("✓ Database in WAL mode")
            
        finally:
            # 10. Clean shutdown
            pool.close()
            logger.info("✓ Pool closed gracefully")
    
    logger.info("✅ INTEGRATION TEST PASSED - All layers working together!")
    print("\n✅ INTEGRATION TEST PASSED")
    print("✓ Security layer: Workspace isolation working")
    print("✓ Storage layer: SQLite pool operational")
    print("✓ Schema layer: All tables created")
    print("✓ Migration layer: Version tracking working")
    print("✓ Logging layer: Structured logs output")


if __name__ == "__main__":
    test_complete_storage_layer()