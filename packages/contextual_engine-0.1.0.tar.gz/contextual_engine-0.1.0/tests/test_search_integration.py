"""Integration tests for search pipeline."""

import pytest
import json
from pathlib import Path
from unittest.mock import patch, MagicMock

from contextual.retrieval.search import hybrid_search, SearchResult
from contextual.retrieval.context_assembler import assemble_context
from contextual.retrieval.ranker import deduplicate_results, apply_mmr
from contextual.storage.sqlite_pool import SQLitePool
from contextual.storage.migrations import run_migrations
from contextual.indexing.pipeline import IndexingPipeline


class MockEmbedder:
    def embed(self, texts: list[str]) -> list[list[float]]:
        # Return a dummy 768-dim vector for each text
        return [[0.1] * 768 for _ in texts]
        
    def embed_batch(self, texts: list[str], batch_size: int = 64) -> list[list[float]]:
        return self.embed(texts)


@pytest.fixture(autouse=True)
def mock_embedder_fixture():
    """Mock the embedder to avoid external calls during indexing and search."""
    with patch("contextual.indexing.pipeline.get_embedder", return_value=MockEmbedder()):
        with patch("contextual.indexing.embedder.get_embedder", return_value=MockEmbedder()):
            yield


@pytest.fixture
def tmp_repo(tmp_path: Path) -> Path:
    """Create fixture repository."""
    repo = tmp_path / "sample_repo"
    repo.mkdir()
    
    utils_py = repo / "utils.py"
    utils_py.write_text(
        '"""Utility functions for data processing."""\n'
        'import json\n'
        'from pathlib import Path\n\n'
        'def parse_json_file(path: str) -> dict:\n'
        '    """Parse JSON file and return contents."""\n'
        '    with open(path) as f:\n'
        '        return json.load(f)\n\n'
        'class ConfigLoader:\n'
        '    """Load and validate configuration files."""\n'
        '    def __init__(self, config_dir: Path):\n'
        '        self.config_dir = config_dir\n'
        '    \n'
        '    def load_config(self, name: str) -> dict:\n'
        '        """Load configuration by name."""\n'
        '        path = self.config_dir / f"{name}.json"\n'
        '        return parse_json_file(str(path))\n'
    )
    
    index_ts = repo / "index.ts"
    index_ts.write_text(
        'export interface User {\n'
        '    id: string;\n'
        '    name: string;\n'
        '    email: string;\n'
        '}\n\n'
        'export function findUser(users: User[], id: string): User | undefined {\n'
        '    return users.find(u => u.id === id);\n'
        '}\n\n'
        'export class UserService {\n'
        '    private users: User[] = [];\n'
        '    \n'
        '    addUser(user: User): void {\n'
        '        this.users.push(user);\n'
        '    }\n'
        '}\n'
    )
    
    return repo


@pytest.fixture
def db_pool(tmp_path: Path) -> SQLitePool:
    """Test database with migrations."""
    db_path = tmp_path / "test.db"
    pool = SQLitePool(db_path)
    with pool.writer() as conn:
        run_migrations(conn)
    yield pool
    pool.close()


@pytest.fixture
def indexed_db(tmp_repo, db_pool):
    """Database with indexed fixtures."""
    pipeline = IndexingPipeline(tmp_repo, db_pool)
    pipeline.index_repository()
    return db_pool


@pytest.mark.asyncio
async def test_index_and_search_basic(indexed_db):
    """1. Index fixture repo, search 'parse JSON', assert results contain parse_json_file."""
    query = "parse JSON file and return contents"
    query_embedding = [0.1] * 768
    
    with indexed_db.reader() as conn:
        results = hybrid_search(conn, query, query_embedding, top_k=5)
        
    assert len(results) > 0
    found = False
    for res in results:
        if res.symbol_name == "parse_json_file":
            found = True
            assert res.path == "sample_repo/utils.py" or res.path == "utils.py"
            assert res.start_line is not None
            assert res.end_line is not None
            assert res.snippet
    assert found, "parse_json_file not found in search results"


@pytest.mark.asyncio
async def test_hybrid_search_bm25_and_vector(indexed_db):
    """2. Search query matching both keyword and semantic, verify ranks and scores."""
    query = "ConfigLoader load_config"
    query_embedding = [0.1] * 768
    
    with indexed_db.reader() as conn:
        results = hybrid_search(conn, query, query_embedding, top_k=5)
        
    assert len(results) > 0
    top_result = results[0]
    
    assert top_result.score > 0
    # The item should ideally have both ranks since it matches keyword and vector 
    assert top_result.bm25_rank is not None or top_result.dense_rank is not None


@pytest.mark.asyncio
async def test_search_with_language_filter(indexed_db):
    """3. Search with language filter."""
    query = "function"
    query_embedding = [0.1] * 768
    
    with indexed_db.reader() as conn:
        python_results = hybrid_search(conn, query, query_embedding, top_k=5, language="python")
        ts_results = hybrid_search(conn, query, query_embedding, top_k=5, language="typescript")
        
    for res in python_results:
        assert res.path.endswith(".py")
    
    for res in ts_results:
        assert res.path.endswith(".ts")


@pytest.mark.asyncio
async def test_context_assembly_token_budget():
    """4. Assemble with token_budget=5000, verify truncation."""
    results = []
    for i in range(20):
        res = SearchResult(
            chunk_id=i,
            path=f"file_{i}.py",
            symbol_name=f"func_{i}",
            chunk_type="function",
            start_line=1,
            end_line=10,
            score=0.9 - (i * 0.01),
            bm25_rank=i + 1,
            dense_rank=i + 1,
            snippet="def func(): pass\n" * 100
        )
        results.append(res)
    
    context = assemble_context(results, token_budget=5000)
    assert context.total_tokens <= 5000
    # Since budget is 5000 and we have lots of content, some should be included and some truncated
    assert context.results_included <= 20
    assert context.results_truncated > 0 or context.results_included < 20


@pytest.mark.asyncio
async def test_search_no_results(indexed_db):
    """5. Search nonsense string, assert empty list, verify context assembly."""
    query = "asdfghjkl_nonsense_xyz"
    query_embedding = [0.1] * 768
    
    # Mock search so it strictly returns nothing
    with patch("contextual.retrieval.search._bm25_search", return_value=[]), \
         patch("contextual.retrieval.search._vector_search", return_value=[]):
        with indexed_db.reader() as conn:
            results = hybrid_search(conn, query, query_embedding, top_k=5)
            
    assert len(results) == 0
    context = assemble_context(results)
    
    # Context assembly handles gracefully
    assert context.total_tokens >= 0
    assert context.results_included == 0
    assert context.results_truncated == 0


@pytest.mark.asyncio
async def test_deduplicate_results():
    """6. Deduplicate results."""
    res1 = SearchResult(
        chunk_id=1,
        path="f.py",
        symbol_name="func",
        chunk_type="function",
        start_line=1,
        end_line=2,
        score=0.9,
        bm25_rank=1,
        dense_rank=1,
        snippet="same snippet content"
    )
    
    res2 = SearchResult(
        chunk_id=2,
        path="f.py",
        symbol_name="func2",
        chunk_type="function",
        start_line=5,
        end_line=6,
        score=0.8,
        bm25_rank=2,
        dense_rank=2,
        snippet="same snippet content"
    )
    
    deduped = deduplicate_results([res1, res2])
    assert len(deduped) == 1
    assert deduped[0].chunk_id == 1


@pytest.mark.asyncio
async def test_apply_mmr_diversity():
    """7. Apply MMR diversity."""
    results = []
    for i in range(5):
        res = SearchResult(
            chunk_id=i,
            path="f.py",
            symbol_name=f"func{i}",
            chunk_type="function",
            start_line=i,
            end_line=i + 1,
            score=0.9 - i * 0.1,
            bm25_rank=i,
            dense_rank=i,
            snippet=f"snippet {i}"
        )
        results.append(res)
        
    filtered = apply_mmr(results, max_per_file=2)
    assert len(filtered) == 2
    assert filtered[0].chunk_id == 0
    assert filtered[1].chunk_id == 1
