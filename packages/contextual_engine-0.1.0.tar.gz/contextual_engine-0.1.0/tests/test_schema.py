import sys
import os

# Ensure we can import contextual
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Create mock contextual.core.errors if missing
try:
    from contextual.core.errors import ErrorCode, StorageError, storage_context
except ImportError:
    import pathlib
    import os
    
    core_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "contextual", "core")
    os.makedirs(core_dir, exist_ok=True)
    with open(os.path.join(core_dir, "errors.py"), "w") as f:
        f.write('''
class ErrorCode:
    STORAGE_SQLITE_SCHEMA_INVALID = "STORAGE_SQLITE_SCHEMA_INVALID"

class StorageError(Exception):
    def __init__(self, code, message, context):
        super().__init__(f"[{code}] {message} ({context})")

def storage_context(query=None):
    return f"query={query}"
''')

import sqlite3
from contextual.storage.schema import apply_schema

conn = sqlite3.connect(":memory:")
apply_schema(conn)

# Verify tables exist
cursor = conn.cursor()
cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
tables = [row[0] for row in cursor.fetchall()]
print("Tables:", tables)  # Should include entities, facts, episodes, code_blobs

# Verify FTS5 tables exist
cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name LIKE 'code_fts%'")
fts_tables = [row[0] for row in cursor.fetchall()]
print("FTS tables:", fts_tables)  # Should include code_fts_ident, code_fts_trigram
