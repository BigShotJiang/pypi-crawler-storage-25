import sys
import os

# Ensure we can import contextual
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Create a dummy config if it doesn't exist just to test
try:
    from contextual.config import get_log_dir
except ImportError:
    import pathlib
    import importlib.util
    import os
    
    config_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "contextual")
    os.makedirs(config_dir, exist_ok=True)
    with open(os.path.join(config_dir, "config.py"), "w") as f:
        f.write('''import pathlib
def get_log_dir():
    return pathlib.Path("~/.local/state/contextual/logs").expanduser()
''')

from contextual.observability.logging import configure_logging, get_logger

configure_logging()
logger = get_logger("test")
logger.info("Test message", key="value")
logger.error("Test error", error_code="E001")
