"""
Shared pytest fixtures for Contextual test suite.

Provides fixtures for temporary workspaces, database connections, test repositories,
and other common test infrastructure.
"""

from __future__ import annotations

import shutil
import sqlite3
import tempfile
from pathlib import Path
from typing import AsyncGenerator, Generator

import pytest

# ============================================================================
# SQLite Extension Setup
# ============================================================================

# Monkey-patch sqlite3.connect to load vec0 extension if available
_original_connect = sqlite3.connect


def _patched_connect(*args, **kwargs):
    """Wrap sqlite3.connect to load vec0 extension when connection is created."""
    conn = _original_connect(*args, **kwargs)
    try:
        conn.enable_load_extension(True)
        conn.load_extension("vec0")
        conn.enable_load_extension(False)
    except (sqlite3.OperationalError, OSError):
        # vec0 not available - that's okay, tests will skip or use fallback
        pass
    return conn


sqlite3.connect = _patched_connect

# Check if vec0 is available in the test environment
_vec0_available = False
try:
    _test_conn = _original_connect(":memory:")
    _test_conn.enable_load_extension(True)
    _test_conn.load_extension("vec0")
    _vec0_available = True
    _test_conn.close()
except (sqlite3.OperationalError, OSError):
    pass


def pytest_collection_modifyitems(config, items):
    """Mark tests that require vec0 as skipif vec0 is not available."""
    skip_marker = pytest.mark.skip(reason="vec0 extension not available")
    for item in items:
        # Skip tests that depend on vec0 if it's not available
        if ("TestMigrationV2Unit" in item.nodeid or
            "TestDocsPipelineIntegration" in item.nodeid or
            "TestDocsRetrievalIntegration" in item.nodeid or
            "TestMCPToolsSmoke" in item.nodeid) and not _vec0_available:
            item.add_marker(skip_marker)


@pytest.fixture
def tmp_workspace() -> Generator[Path, None, None]:
    """
    Create a temporary workspace directory for testing.

    Yields:
        Path to a temporary directory that will be cleaned up after the test.
    """
    temp_dir = Path(tempfile.mkdtemp(prefix="contextual_test_"))
    try:
        yield temp_dir
    finally:
        shutil.rmtree(temp_dir, ignore_errors=True)


@pytest.fixture
def sample_python_file(tmp_workspace: Path) -> Path:
    """
    Create a sample Python file for testing.

    Args:
        tmp_workspace: Temporary workspace fixture.

    Returns:
        Path to the created Python file.
    """
    file_path = tmp_workspace / "sample.py"
    file_path.write_text(
        '''"""Sample module for testing."""

from __future__ import annotations


def hello(name: str) -> str:
    """Greet someone.

    Args:
        name: Name of person to greet.

    Returns:
        Greeting message.
    """
    return f"Hello, {name}!"


class Calculator:
    """A simple calculator."""

    def add(self, a: int, b: int) -> int:
        """Add two numbers.

        Args:
            a: First number.
            b: Second number.

        Returns:
            Sum of a and b.
        """
        return a + b

    def multiply(self, a: int, b: int) -> int:
        """Multiply two numbers.

        Args:
            a: First number.
            b: Second number.

        Returns:
            Product of a and b.
        """
        return a * b
''',
    )
    return file_path


@pytest.fixture
def sample_typescript_file(tmp_workspace: Path) -> Path:
    """
    Create a sample TypeScript file for testing.

    Args:
        tmp_workspace: Temporary workspace fixture.

    Returns:
        Path to the created TypeScript file.
    """
    file_path = tmp_workspace / "sample.ts"
    file_path.write_text(
        '''/**
 * Sample module for testing.
 */

export function greet(name: string): string {
    return `Hello, ${name}!`;
}

export class Calculator {
    add(a: number, b: number): number {
        return a + b;
    }

    multiply(a: number, b: number): number {
        return a * b;
    }
}

export interface User {
    id: number;
    name: string;
    email: string;
}
''',
    )
    return file_path


# Async fixtures will be added as async components are built
# Example structure for future use:

# @pytest.fixture(scope="session")
# async def lance_db_connection() -> AsyncGenerator[LanceDBConnection, None]:
#     """Provide a test LanceDB connection."""
#     conn = await create_test_connection()
#     try:
#         yield conn
#     finally:
#         await conn.close()
