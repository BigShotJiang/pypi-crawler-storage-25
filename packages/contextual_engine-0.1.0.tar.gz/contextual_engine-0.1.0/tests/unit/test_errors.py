"""
Unit tests for contextual.core.errors.

Tests the custom exception classes and error codes.
"""

from __future__ import annotations

import pytest

from contextual.core.errors import ContextualException, ErrorCode


@pytest.mark.unit
class TestErrorCode:
    """Test suite for the ErrorCode enum."""

    def test_enum_members_exist(self) -> None:
        """Test that all expected error codes are present."""
        codes = {
            "INVALID_PATH",
            "INDEX_NOT_FOUND",
            "QUERY_TOO_BROAD",
            "ENTITY_NOT_FOUND",
            "DB_LOCKED",
            "TIMEOUT",
            "INTERNAL_ERROR",
        }
        assert {code.name for code in ErrorCode} == codes

    def test_enum_values_are_unique(self) -> None:
        """Test that all error code values are unique."""
        values = [code.value for code in ErrorCode]
        assert len(values) == len(set(values))


@pytest.mark.unit
class TestContextualException:
    """Test suite for the ContextualException base class."""

    def test_exception_initialization_with_code(self) -> None:
        """Test creating an exception with an ErrorCode."""
        exc = ContextualException(ErrorCode.INDEX_NOT_FOUND, "Index is missing.")
        assert exc.code == ErrorCode.INDEX_NOT_FOUND
        assert "Index is missing" in str(exc)

    def test_exception_initialization_with_string(self) -> None:
        """Test creating an exception with a simple string message."""
        exc = ContextualException("A generic error occurred.")
        assert exc.code == ErrorCode.INTERNAL_ERROR
        assert "A generic error occurred" in str(exc)

    def test_exception_representation(self) -> None:
        """Test the string representation of the exception."""
        exc = ContextualException(ErrorCode.DB_LOCKED, "Database is currently locked.")
        assert "DB_LOCKED" in repr(exc)
        assert "Database is currently locked" in repr(exc)
