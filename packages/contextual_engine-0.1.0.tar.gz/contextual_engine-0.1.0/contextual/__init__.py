"""Contextual: Temporal-first local AI context engine.

A tool-agnostic semantic code memory system that eliminates AI hallucinations
through bi-temporal fact tracking and deterministic retrieval.
"""
from __future__ import annotations


__version__ = "0.1.0"
__author__ = "Contextual Team"
__license__ = "BSL-1.1"

# Public API exports will be added as modules are built
__all__ = [
    "__author__",
    "__license__",
    "__version__",
]
