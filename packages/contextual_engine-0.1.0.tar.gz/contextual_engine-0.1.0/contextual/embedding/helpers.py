"""High-level embedding API with caching integration.

Provides convenience functions that combine embedder + cache for common workflows:
- embed_chunks_with_cache: Batch embed with cache lookup/write
- embed_query: Simple query embedding (no cache)
- warm_cache: Pre-populate cache from database

These are the recommended entry points for indexing and search operations.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from contextual.embedding.cache import (
    get_cached_embeddings_batch,
    put_cached_embeddings_batch,
)
from contextual.embedding.embedder import MODEL_NAME, get_embedder
from contextual.observability.logging import get_logger

if TYPE_CHECKING:
    from sqlite3 import Connection


logger = get_logger(__name__)


# ============================================================================
# CACHED EMBEDDING WORKFLOW
# ============================================================================


def embed_chunks(
    conn: Connection,
    chunks: list[tuple[str, str]],
) -> list[tuple[str, list[float]]]:
    """Embed chunks with cache lookup and write.

    This is the main entry point for indexing pipelines.

    Workflow:
    1. Extract content hashes from chunks
    2. Lookup cached embeddings in batch
    3. Generate embeddings only for cache misses
    4. Write new embeddings to cache
    5. Return all embeddings in original order

    Args:
        conn: SQLite connection (for cache operations).
        chunks: List of (content_hash, text) tuples.

    Returns:
        List of (content_hash, embedding) tuples in original order.

    Example:
        >>> chunks = [
        ...     ("abc123", "def parse_json():"),
        ...     ("def456", "class Config:"),
        ... ]
        >>> results = embed_chunks(conn, chunks)
        >>> len(results)
        2
        >>> hash1, emb1 = results[0]
        >>> len(emb1)
        768
    """
    if not chunks:
        return []

    embedder = get_embedder()

    # Extract hashes and texts
    hashes = [h for h, _ in chunks]
    texts = [t for _, t in chunks]

    # Batch cache lookup
    cached = get_cached_embeddings_batch(conn, hashes, MODEL_NAME)

    # Identify cache misses
    miss_indices = [i for i, h in enumerate(hashes) if h not in cached]
    miss_texts = [texts[i] for i in miss_indices]
    miss_hashes = [hashes[i] for i in miss_indices]

    logger.info(
        "Embedding with cache",
        total=len(chunks),
        cached=len(cached),
        misses=len(miss_indices),
        hit_rate=len(cached) / len(chunks) if chunks else 0,
    )

    # Generate embeddings for misses
    new_embeddings = {}
    if miss_texts:
        logger.debug("Generating embeddings for cache misses", count=len(miss_texts))

        fresh_embeddings = embedder.embed(miss_texts)

        # Build miss hash -> embedding map
        for hash_val, embedding in zip(miss_hashes, fresh_embeddings, strict=False):
            new_embeddings[hash_val] = embedding

        # Write to cache
        cache_entries = list(zip(miss_hashes, fresh_embeddings, strict=False))
        put_cached_embeddings_batch(conn, cache_entries, MODEL_NAME)

    # Combine cached + new in original order
    results = []
    for hash_val in hashes:
        if hash_val in cached:
            embedding = cached[hash_val]
        else:
            embedding = new_embeddings[hash_val]

        results.append((hash_val, embedding))

    return results


def embed_query_simple(query: str) -> list[float]:
    """Embed a search query (no caching).

    Queries are not cached because:
    1. They are unique and rarely repeated
    2. Cache lookup overhead > embedding time for single item
    3. Query embedding is already fast (~55ms)

    Args:
        query: Query string.

    Returns:
        768-dim embedding vector.

    Example:
        >>> embedding = embed_query_simple("parse JSON configuration")
        >>> len(embedding)
        768
    """
    embedder = get_embedder()
    return embedder.embed_query(query)


# ============================================================================
# CACHE WARMING
# ============================================================================


def warm_cache_from_chunks(
    conn: Connection,
    chunk_ids: list[int] | None = None,
) -> int:
    """Pre-populate embedding cache from existing chunks.

    Useful after:
    - Fresh database creation
    - Cache cleared
    - Model upgrade

    Args:
        conn: SQLite connection.
        chunk_ids: Specific chunk IDs to warm, or None for all.

    Returns:
        Number of embeddings cached.

    Example:
        >>> count = warm_cache_from_chunks(conn)
        >>> print(f"Cached {count} embeddings")
    """
    try:
        cursor = conn.cursor()

        # Fetch chunks
        if chunk_ids:
            placeholders = ",".join("?" * len(chunk_ids))
            query = f"""
                SELECT content_hash, content
                FROM chunks
                WHERE id IN ({placeholders})
                AND content_hash IS NOT NULL
            """
            cursor.execute(query, chunk_ids)
        else:
            query = """
                SELECT content_hash, content
                FROM chunks
                WHERE content_hash IS NOT NULL
            """
            cursor.execute(query)

        rows = cursor.fetchall()
        chunks = [(h, c) for h, c in rows]

        logger.info("Warming cache from chunks", chunk_count=len(chunks))

        # Use cached embedding workflow
        # (will skip already-cached entries automatically)
        results = embed_chunks(conn, chunks)

        return len(results)

    except Exception as e:
        logger.error("Cache warming failed", error=str(e))
        return 0


# ============================================================================
# STATISTICS
# ============================================================================


def get_embedding_stats(conn: Connection) -> dict[str, int | float]:
    """Get embedding and cache statistics.

    Returns:
        Dict with cache stats and efficiency metrics.

    Example:
        >>> stats = get_embedding_stats(conn)
        >>> stats
        {
            'cache_entries': 10000,
            'cache_hits': 45000,
            'cache_hit_rate': 0.82,
            'estimated_time_saved_hours': 12.5
        }
    """
    from contextual.embedding.cache import get_cache_stats

    cache_stats = get_cache_stats(conn)

    # Calculate efficiency metrics
    total_entries = cache_stats["total_entries"]
    total_hits = cache_stats["total_hits"]

    # Assume ~55ms per embedding generation
    # Cache hit saves ~55ms, lookup costs ~0.1ms
    time_saved_ms = total_hits * 55
    time_saved_hours = time_saved_ms / 1000 / 60 / 60

    cache_hit_rate = 0.0
    if total_entries + total_hits > 0:
        cache_hit_rate = total_hits / (total_entries + total_hits)

    return {
        "cache_entries": total_entries,
        "cache_hits": total_hits,
        "cache_hit_rate": round(cache_hit_rate, 3),
        "estimated_time_saved_hours": round(time_saved_hours, 2),
        "models": cache_stats["models"],
    }
