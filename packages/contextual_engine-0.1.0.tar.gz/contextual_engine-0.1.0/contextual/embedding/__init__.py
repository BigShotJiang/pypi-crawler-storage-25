"""Embedding module: fastembed ONNX inference with content-hash caching.

This module provides efficient code embedding generation using:
- Model: jina-embeddings-v2-base-code (768-dim, int8 ONNX)
- Caching: Content-hash based deduplication
- Batching: Up to 64 documents per batch
- Thread-safety: Singleton embedder with locks

Public API (High-level - recommended):
- embed_chunks_with_cache: Batch embed chunks with cache lookup/write
- embed_query_simple: Embed search query (no cache)
- get_embedding_stats: Cache statistics and efficiency metrics
- warm_cache_from_chunks: Pre-populate cache from database

Public API (Low-level - advanced use):
- get_embedder: Access embedder singleton directly
- CodeEmbedder: Embedder class (use singleton via get_embedder)
- initialize_cache: Setup cache table
- get_cached_embedding: Single cache lookup
- put_cached_embedding: Single cache write

Performance characteristics:
- Model load: ~2s (one-time, cached)
- Embedding generation: ~55ms per chunk
- Cache hit: ~0.1ms (550x faster)
- Batch of 64: ~3.5s total (~18 docs/sec)

Example usage:
    >>> from contextual.embedding import embed_chunks_with_cache, embed_query_simple
    >>> from contextual.storage import SQLitePool
    >>>
    >>> # Indexing workflow
    >>> pool = SQLitePool(db_path)
    >>> chunks = [("hash1", "def parse():"), ("hash2", "class Config:")]
    >>> with pool.writer() as conn:
    ...     results = embed_chunks_with_cache(conn, chunks)
    >>>
    >>> # Search workflow
    >>> query_vector = embed_query_simple("parse JSON configuration")
"""
from __future__ import annotations

# High-level API (recommended)
from contextual.embedding.helpers import (
    embed_chunks,
    embed_query_simple,
    get_embedding_stats,
    warm_cache_from_chunks,
)

# Core embedder
from contextual.embedding.embedder import (
    CodeEmbedder,
    DocsEmbedder,
    get_embedder,
    get_docs_embedder,
    reset_embedder,
)

# Cache operations
from contextual.embedding.cache import (
    clear_cache,
    get_cache_stats,
    get_cached_embedding,
    initialize_cache,
    put_cached_embedding,
)

__all__ = [
    # High-level API (use these)
    "embed_chunks",
    "embed_query_simple",
    "get_embedding_stats",
    "warm_cache_from_chunks",
    # Core embedder
    "CodeEmbedder",
    "DocsEmbedder",
    "get_embedder",
    "get_docs_embedder",
    "reset_embedder",
    # Cache operations
    "clear_cache",
    "get_cache_stats",
    "get_cached_embedding",
    "initialize_cache",
    "put_cached_embedding",
]
