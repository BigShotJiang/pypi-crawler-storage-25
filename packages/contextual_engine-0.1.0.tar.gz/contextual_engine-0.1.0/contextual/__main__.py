"""Entry point for `python -m contextual` invocation.

Delegates to the Typer CLI defined in cli.py.
"""
from __future__ import annotations

from contextual.cli import app


if __name__ == "__main__":
    app()
