"""Observability: structured logging, metrics collection, and graceful shutdown.

Provides structlog-based logging pipeline with JSON output, local metrics collection,
and graceful shutdown handlers for WAL checkpointing and async task draining.
"""
from __future__ import annotations

from contextual.observability.logging import (
    add_context,
    clear_context,
    configure_logging,
    get_logger,
)


__all__ = [
    "add_context",
    "clear_context",
    "configure_logging",
    "get_logger",
]
