"""Structured logging pipeline using structlog."""

from __future__ import annotations

import logging
import sys
from logging.handlers import RotatingFileHandler
from typing import Any

import structlog
from structlog.types import Processor

from contextual.config import get_log_dir


def configure_logging(log_level: str = "INFO", enable_file_logging: bool = True) -> None:
    """Configure the structlog pipeline.
    
    Sets up JSON file logging and colored console logging.
    
    Args:
        log_level: The minimum log level to capture.
        enable_file_logging: Whether to write logs to a file.
    """
    processors: list[Processor] = [
        structlog.contextvars.merge_contextvars,
        structlog.processors.add_log_level,
        structlog.processors.TimeStamper(fmt="iso", utc=True),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.CallsiteParameterAdder(),
    ]

    # Console renderer (when sys.stderr.isatty())
    if sys.stderr.isatty():
        console_processor = structlog.dev.ConsoleRenderer()
    else:
        console_processor = structlog.processors.JSONRenderer()

    # Configure stdlib logging handlers
    handlers: list[logging.Handler] = []

    # Console handler
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setFormatter(structlog.stdlib.ProcessorFormatter(
        processor=console_processor,
    ))
    handlers.append(console_handler)

    if enable_file_logging:
        try:
            log_dir = get_log_dir()
            log_dir.mkdir(parents=True, exist_ok=True)
            log_file = log_dir / "contextual.log"

            file_handler = RotatingFileHandler(
                log_file,
                maxBytes=10 * 1024 * 1024,  # 10 MB
                backupCount=5,
                encoding="utf-8"
            )
            # Ensure log file has proper permissions (0o644)
            if log_file.exists():
                log_file.chmod(0o644)

            file_handler.setFormatter(structlog.stdlib.ProcessorFormatter(
                processor=structlog.processors.JSONRenderer(),
            ))
            handlers.append(file_handler)
        except Exception as e:
            # Fallback to console-only if file logging setup fails
            print(f"Warning: Failed to setup file logging: {e}", file=sys.stderr)

    # Route stdlib logs through structlog
    logging.basicConfig(
        format="%(message)s",
        level=log_level,
        handlers=handlers,
    )

    structlog.configure(
        processors=processors + [structlog.stdlib.ProcessorFormatter.wrap_for_formatter],
        wrapper_class=structlog.make_filtering_bound_logger(getattr(logging, log_level.upper())),
        context_class=dict,
        logger_factory=structlog.stdlib.LoggerFactory(),
        cache_logger_on_first_use=True,
    )


def get_logger(name: str) -> structlog.BoundLogger:
    """Get a structured logger.
    
    Args:
        name: Logger name (usually __name__).
        
    Returns:
        Configured structlog logger.
    """
    return structlog.get_logger(name)


def add_context(**kwargs: Any) -> None:
    """Add context variables to all logs in current context.
    
    Uses structlog.contextvars to bind variables.
    
    Args:
        **kwargs: Key-value pairs to add to log context.
    """
    structlog.contextvars.bind_contextvars(**kwargs)


def clear_context() -> None:
    """Clear all context variables."""
    structlog.contextvars.clear_contextvars()
