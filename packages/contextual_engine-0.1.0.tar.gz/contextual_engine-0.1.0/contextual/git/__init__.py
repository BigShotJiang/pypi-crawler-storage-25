"""Git integration module for temporal code attribution.

Public API:
- GitRepository: Wrapper for git operations
- BlameInfo: Line range attribution
- ChunkAttribution: Aggregated chunk metadata
"""

from __future__ import annotations

from contextual.git.blame import (
    BlameInfo,
    ChunkAttribution,
    GitRepository,
)


__all__ = [
    "BlameInfo",
    "ChunkAttribution",
    "GitRepository",
]
