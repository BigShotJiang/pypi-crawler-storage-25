"""Git blame integration for temporal code attribution.

Provides:
- Last-modified timestamps per chunk
- Author tracking
- Commit context for code chunks
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import TYPE_CHECKING

import pygit2

from contextual.observability.logging import get_logger


if TYPE_CHECKING:
    from collections.abc import Iterator


logger = get_logger(__name__)


@dataclass
class BlameInfo:
    """Attribution information for a line range."""
    
    author: str
    """Author name from git config."""
    
    email: str
    """Author email."""
    
    timestamp: datetime
    """Commit timestamp (UTC)."""
    
    commit_sha: str
    """Full commit SHA."""
    
    commit_message: str
    """First line of commit message."""
    
    line_start: int
    """Start line of this blame hunk (1-indexed)."""
    
    line_end: int
    """End line of this blame hunk (1-indexed, inclusive)."""


@dataclass
class ChunkAttribution:
    """Aggregated attribution for a code chunk."""
    
    primary_author: str
    """Most frequent author in chunk."""
    
    last_modified: datetime
    """Most recent modification timestamp."""
    
    authors: list[str]
    """All authors who touched this chunk (ordered by contribution)."""
    
    commits: list[str]
    """Commit SHAs that modified this chunk (newest first)."""


class GitRepository:
    """Git repository wrapper for blame and temporal queries.
    
    Uses pygit2 for efficient git operations without spawning processes.
    """
    
    def __init__(self, repo_path: Path) -> None:
        """Initialize git repository wrapper.
        
        Args:
            repo_path: Path to repository root.
            
        Raises:
            ValueError: If path is not a git repository.
        """
        self.repo_path = repo_path.resolve()
        
        try:
            self._repo = pygit2.Repository(str(self.repo_path))
        except pygit2.GitError as e:
            raise ValueError(f"Not a git repository: {repo_path}") from e
        
        logger.debug(
            "Git repository initialized",
            repo_path=str(self.repo_path),
            head=str(self._repo.head.target),
        )
    
    def get_blame(
        self,
        file_path: Path | str,
        start_line: int = 1,
        end_line: int | None = None,
    ) -> list[BlameInfo]:
        """Get blame information for a file line range.
        
        Args:
            file_path: Relative path from repo root.
            start_line: Start line (1-indexed).
            end_line: End line (1-indexed, inclusive). None = EOF.
            
        Returns:
            List of BlameInfo for each blame hunk in range.
            
        Raises:
            FileNotFoundError: If file doesn't exist.
            ValueError: If file not tracked in git.
        """
        rel_path = Path(file_path)
        
        # Check file exists
        full_path = self.repo_path / rel_path
        if not full_path.exists():
            raise FileNotFoundError(f"File not found: {rel_path}")
        
        try:
            # Get blame for entire file
            blame = self._repo.blame(str(rel_path))
        except pygit2.GitError as e:
            raise ValueError(f"File not tracked in git: {rel_path}") from e
        
        # Filter hunks to requested range
        blame_infos: list[BlameInfo] = []
        
        for hunk in blame:
            hunk_start = hunk.final_start_line_number
            hunk_end = hunk_start + hunk.lines_in_hunk - 1
            
            # Check if hunk intersects with requested range
            if end_line is not None:
                if hunk_end < start_line or hunk_start > end_line:
                    continue
            else:
                if hunk_end < start_line:
                    continue
            
            # Get commit info
            commit_obj = self._repo.get(hunk.final_commit_id)
            if not isinstance(commit_obj, pygit2.Commit):
                logger.warning(
                    "Skipping blame hunk with non-commit object",
                    file=str(rel_path),
                    commit_id=str(hunk.final_commit_id),
                )
                continue
            
            blame_info = BlameInfo(
                author=commit_obj.author.name or "unknown",
                email=commit_obj.author.email or "unknown",
                timestamp=datetime.fromtimestamp(commit_obj.commit_time),
                commit_sha=str(commit_obj.id),
                commit_message=commit_obj.message.split("\n")[0] if commit_obj.message else "",
                line_start=hunk_start,
                line_end=hunk_end,
            )
            
            blame_infos.append(blame_info)
        
        logger.debug(
            "Blame retrieved",
            file=str(rel_path),
            line_range=f"{start_line}-{end_line or 'EOF'}",
            hunks=len(blame_infos),
        )
        
        return blame_infos
    
    def get_chunk_attribution(
        self,
        file_path: Path | str,
        start_line: int,
        end_line: int,
    ) -> ChunkAttribution:
        """Get aggregated attribution for a code chunk.
        
        Determines primary author and last-modified timestamp
        for the chunk by analyzing all blame hunks in range.
        
        Args:
            file_path: Relative path from repo root.
            start_line: Chunk start line (1-indexed).
            end_line: Chunk end line (1-indexed, inclusive).
            
        Returns:
            ChunkAttribution with aggregated metadata.
        """
        blame_infos = self.get_blame(file_path, start_line, end_line)
        
        if not blame_infos:
            # File exists but no blame (binary/gitignored)
            return ChunkAttribution(
                primary_author="unknown",
                last_modified=datetime.now(),
                authors=["unknown"],
                commits=[],
            )
        
        # Count author contributions (by lines)
        author_lines: dict[str, int] = {}
        for info in blame_infos:
            lines_in_chunk = min(info.line_end, end_line) - max(info.line_start, start_line) + 1
            author_lines[info.author] = author_lines.get(info.author, 0) + lines_in_chunk
        
        # Sort authors by contribution
        authors_sorted = sorted(
            author_lines.keys(),
            key=lambda a: author_lines[a],
            reverse=True,
        )
        
        # Get most recent modification
        last_modified = max(info.timestamp for info in blame_infos)
        
        # Get unique commits (newest first)
        commits_with_time = [(info.commit_sha, info.timestamp) for info in blame_infos]
        unique_commits = list(dict.fromkeys(sha for sha, _ in commits_with_time))
        unique_commits.sort(
            key=lambda sha: next(ts for s, ts in commits_with_time if s == sha),
            reverse=True,
        )
        
        return ChunkAttribution(
            primary_author=authors_sorted[0],
            last_modified=last_modified,
            authors=authors_sorted,
            commits=unique_commits,
        )
    
    def iter_file_history(
        self,
        file_path: Path | str,
        max_commits: int = 100,
    ) -> Iterator[tuple[datetime, str, str]]:
        """Iterate file modification history.
        
        Args:
            file_path: Relative path from repo root.
            max_commits: Maximum commits to examine.
            
        Yields:
            (timestamp, author, commit_sha) tuples, newest first.
        """
        rel_path = str(Path(file_path))
        
        try:
            # Walk commits that modified this file
            walker = self._repo.walk(self._repo.head.target)
            walker.simplify_first_parent()
            
            count = 0
            for commit in walker:
                if count >= max_commits:
                    break
                
                # Check if this commit touched the file
                if count == 0:
                    # First commit always included
                    yield (
                        datetime.fromtimestamp(commit.commit_time),
                        commit.author.name,
                        str(commit.id),
                    )
                    count += 1
                    continue
                
                # Check diff
                if len(commit.parents) > 0:
                    parent = commit.parents[0]
                    diff = self._repo.diff(parent, commit)
                    
                    for delta in diff.deltas:
                        if delta.new_file.path == rel_path or delta.old_file.path == rel_path:
                            yield (
                                datetime.fromtimestamp(commit.commit_time),
                                commit.author.name,
                                str(commit.id),
                            )
                            count += 1
                            break
        
        except Exception as e:
            logger.warning(
                "File history iteration failed",
                file=rel_path,
                error=str(e),
            )
    
    def is_tracked(self, file_path: Path | str) -> bool:
        """Check if file is tracked by git.
        
        Args:
            file_path: Relative path from repo root.
            
        Returns:
            True if file is tracked.
        """
        rel_path = str(Path(file_path))
        
        try:
            # Try to get blame - if succeeds, file is tracked
            self._repo.blame(rel_path)
            return True
        except pygit2.GitError:
            return False
    
    def get_repo_info(self) -> dict[str, str]:
        """Get repository metadata.
        
        Returns:
            Dictionary with repo info (head, branch, remote).
        """
        info = {
            "head": str(self._repo.head.target),
            "branch": self._repo.head.shorthand if not self._repo.head_is_detached else "detached",
        }
        
        # Try to get remote URL
        try:
            remote = self._repo.remotes["origin"]
            info["remote"] = remote.url or "unknown"
        except KeyError:
            info["remote"] = "unknown"
        
        return info
