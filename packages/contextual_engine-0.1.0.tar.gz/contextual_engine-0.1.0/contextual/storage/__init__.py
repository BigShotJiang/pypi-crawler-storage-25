"""Storage layer: SQLite, LanceDB, and bi-temporal query infrastructure.

Provides connection pooling, schema management, migrations, and temporal query helpers.
All persistence operations go through this layer.
"""
from __future__ import annotations

from contextual.storage.migrations import (
    apply_initial_schema,
    get_current_version,
    record_migration,
    run_migrations,
)
from contextual.storage.schema import apply_schema
from contextual.storage.sqlite_pool import SQLitePool
from contextual.storage.vec0_manager import (
    count_vectors,
    delete_vectors,
    insert_vectors,
    search_vectors,
)


__all__ = [
    "SQLitePool",
    "apply_initial_schema",
    "apply_schema",
    "count_vectors",
    "delete_vectors",
    "get_current_version",
    "insert_vectors",
    "record_migration",
    "run_migrations",
    "search_vectors",
]

