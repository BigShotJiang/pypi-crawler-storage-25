"""SQLite schema for Contextual's bi-temporal knowledge graph.

Contains DDL strings for core tables, indexes, and FTS5 search capabilities,
along with a function to apply the schema idempotently.
"""

from __future__ import annotations

import sqlite3
from typing import TYPE_CHECKING

from contextual.core.errors import ErrorCode, StorageError, storage_context


if TYPE_CHECKING:
    from sqlite3 import Connection


# 1. ENTITIES TABLE
# Core table storing the distinct entities tracked in the graph.
DDL_ENTITIES = """
CREATE TABLE IF NOT EXISTS entities (
    id          INTEGER PRIMARY KEY,
    name        TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    metadata    TEXT,
    created_at  INTEGER NOT NULL
) STRICT;
"""

# 2. EPISODES TABLE
# Table tracking distinct sessions/runs where facts were gathered.
DDL_EPISODES = """
CREATE TABLE IF NOT EXISTS episodes (
    id        INTEGER PRIMARY KEY,
    source    TEXT NOT NULL,
    content   TEXT,
    timestamp INTEGER NOT NULL,
    metadata  TEXT
) STRICT;
"""

# 3. FACTS TABLE (BI-TEMPORAL)
# Bi-temporal facts relating an entity to an object or value over time.
DDL_FACTS = """
CREATE TABLE IF NOT EXISTS facts (
    id         INTEGER PRIMARY KEY,
    entity_id  INTEGER NOT NULL REFERENCES entities(id),
    object_id  INTEGER REFERENCES entities(id),
    predicate  TEXT NOT NULL,
    value      TEXT,
    valid_at   INTEGER NOT NULL,
    invalid_at INTEGER,
    created_at INTEGER NOT NULL,
    expired_at INTEGER,
    episode_id INTEGER REFERENCES episodes(id),
    confidence REAL,
    source     TEXT
) STRICT;
"""

# 4. FACTS INDEXES
# Indexes for efficient temporal and relational querying.
DDL_INDEX_FACTS_ENTITY_PRED = """
CREATE INDEX IF NOT EXISTS idx_facts_entity_pred_valid
    ON facts(entity_id, predicate, valid_at DESC, invalid_at);
"""

DDL_INDEX_FACTS_LIVE = """
CREATE INDEX IF NOT EXISTS idx_facts_live
    ON facts(entity_id, predicate, valid_at DESC)
    WHERE invalid_at IS NULL AND expired_at IS NULL;
"""

DDL_INDEX_FACTS_OBJECT = """
CREATE INDEX IF NOT EXISTS idx_facts_object
    ON facts(object_id, predicate, valid_at DESC)
    WHERE object_id IS NOT NULL;
"""

DDL_INDEX_FACTS_TIMELINE = """
CREATE INDEX IF NOT EXISTS idx_facts_timeline
    ON facts(entity_id, valid_at, invalid_at, created_at);
"""

# 5. SCHEMA VERSION TABLE
# Tracking schema versions for migrations.
DDL_SCHEMA_VERSION = """
CREATE TABLE IF NOT EXISTS schema_version (
    version INTEGER PRIMARY KEY,
    applied_at INTEGER NOT NULL
) STRICT;
"""

# 6. CODE_BLOBS TABLE (FTS5 CONTENT SOURCE)
# Table storing raw code chunks for full-text search.
DDL_CODE_BLOBS = """
CREATE TABLE IF NOT EXISTS code_blobs (
    rowid    INTEGER PRIMARY KEY,
    path     TEXT NOT NULL,
    language TEXT NOT NULL,
    content  TEXT NOT NULL
) STRICT;
"""

# 7. FTS5 IDENTIFIER SEARCH
# FTS5 virtual table for searching identifier-like tokens.
DDL_FTS5_IDENT = """
CREATE VIRTUAL TABLE IF NOT EXISTS code_fts_ident USING fts5(
    content,
    tokenize = "unicode61 tokenchars '_-$.'",
    prefix = '2 3 4',
    content = 'code_blobs',
    content_rowid = 'rowid'
);
"""

# 8. FTS5 TRIGRAM SEARCH
# FTS5 virtual table for substring trigram searches.
DDL_FTS5_TRIGRAM = """
CREATE VIRTUAL TABLE IF NOT EXISTS code_fts_trigram USING fts5(
    content,
    tokenize = "trigram case_sensitive 0",
    content = 'code_blobs',
    content_rowid = 'rowid'
);
"""

# 9. FTS5 TRIGGERS
# Triggers to keep FTS virtual tables in sync with code_blobs.
DDL_FTS5_TRIGGER_INSERT = """
CREATE TRIGGER IF NOT EXISTS code_blobs_fts_insert
AFTER INSERT ON code_blobs
BEGIN
    INSERT INTO code_fts_ident(rowid, content) VALUES (new.rowid, new.content);
    INSERT INTO code_fts_trigram(rowid, content) VALUES (new.rowid, new.content);
END;
"""

DDL_FTS5_TRIGGER_DELETE = """
CREATE TRIGGER IF NOT EXISTS code_blobs_fts_delete
AFTER DELETE ON code_blobs
BEGIN
    INSERT INTO code_fts_ident(code_fts_ident, rowid, content) VALUES ('delete', old.rowid, old.content);
    INSERT INTO code_fts_trigram(code_fts_trigram, rowid, content) VALUES ('delete', old.rowid, old.content);
END;
"""

DDL_FTS5_TRIGGER_UPDATE = """
CREATE TRIGGER IF NOT EXISTS code_blobs_fts_update
AFTER UPDATE ON code_blobs
BEGIN
    INSERT INTO code_fts_ident(code_fts_ident, rowid, content) VALUES ('delete', old.rowid, old.content);
    INSERT INTO code_fts_trigram(code_fts_trigram, rowid, content) VALUES ('delete', old.rowid, old.content);
    INSERT INTO code_fts_ident(rowid, content) VALUES (new.rowid, new.content);
    INSERT INTO code_fts_trigram(rowid, content) VALUES (new.rowid, new.content);
END;
"""


def apply_schema(conn: Connection) -> None:
    """Apply complete schema to a SQLite connection.
    
    Creates all tables, indexes, FTS5 virtual tables, and triggers.
    Safe to call multiple times (uses IF NOT EXISTS).
    
    Args:
        conn: SQLite connection.
        
    Raises:
        StorageError: If schema application fails.
    """
    try:
        cursor = conn.cursor()

        # Core tables
        cursor.execute(DDL_ENTITIES)
        cursor.execute(DDL_EPISODES)
        cursor.execute(DDL_FACTS)

        # Indexes
        cursor.execute(DDL_INDEX_FACTS_ENTITY_PRED)
        cursor.execute(DDL_INDEX_FACTS_LIVE)
        cursor.execute(DDL_INDEX_FACTS_OBJECT)
        cursor.execute(DDL_INDEX_FACTS_TIMELINE)

        # Schema version
        cursor.execute(DDL_SCHEMA_VERSION)

        # FTS5 content table
        cursor.execute(DDL_CODE_BLOBS)

        # FTS5 virtual tables
        cursor.execute(DDL_FTS5_IDENT)
        cursor.execute(DDL_FTS5_TRIGRAM)

        # FTS5 triggers
        cursor.execute(DDL_FTS5_TRIGGER_INSERT)
        cursor.execute(DDL_FTS5_TRIGGER_DELETE)
        cursor.execute(DDL_FTS5_TRIGGER_UPDATE)

        conn.commit()

    except sqlite3.Error as e:
        msg = f"Failed to apply schema: {e}"
        raise StorageError(
            code=ErrorCode.STORAGE_SQLITE_SCHEMA_INVALID,
            message=msg,
            context=storage_context(query="apply_schema"),
        ) from e
