"""SQLite migration runner for schema version management.

Tracks schema versions and applies pending migrations in order.
Migrations:
- v1: Core bi-temporal schema (entities, facts, episodes)
- v2: Phase 1 codebase indexing (code_symbols, indexing_state, vec0, FTS5)
"""

from __future__ import annotations

import sqlite3
import time
from typing import TYPE_CHECKING

from contextual.core.errors import ErrorCode, StorageError, storage_context
from contextual.observability.logging import get_logger


if TYPE_CHECKING:
    from sqlite3 import Connection

logger = get_logger(__name__)


def get_current_version(conn: Connection) -> int:
    """Get current schema version.

    Reads from schema_version table. Returns 0 if table doesn't exist
    or is empty (indicating fresh database).

    Args:
        conn: SQLite connection.

    Returns:
        Current schema version (0 if no version recorded).

    Raises:
        StorageError: If version query fails.
    """
    try:
        cursor = conn.cursor()

        # Check if schema_version table exists.
        cursor.execute(
            "SELECT name FROM sqlite_master WHERE type='table' AND name='schema_version'",
        )
        if not cursor.fetchone():
            return 0

        # Get the latest recorded version.
        cursor.execute("SELECT MAX(version) FROM schema_version")
        result = cursor.fetchone()

        if result is None or result[0] is None:
            return 0

        return int(result[0])

    except sqlite3.Error as e:
        msg = f"Failed to get schema version: {e}"
        raise StorageError(
            code=ErrorCode.STORAGE_MIGRATION_FAILED,
            message=msg,
            context=storage_context(query="get_current_version"),
        ) from e


def record_migration(conn: Connection, version: int) -> None:
    """Record that a migration was applied.

    Inserts version and timestamp into schema_version table.

    Args:
        conn: SQLite connection.
        version: Migration version number.

    Raises:
        StorageError: If recording fails.
    """
    try:
        cursor = conn.cursor()
        now_ms = int(time.time() * 1000)

        cursor.execute(
            "INSERT INTO schema_version (version, applied_at) VALUES (?, ?)",
            (version, now_ms),
        )
        conn.commit()

    except sqlite3.Error as e:
        msg = f"Failed to record migration version {version}: {e}"
        raise StorageError(
            code=ErrorCode.STORAGE_MIGRATION_FAILED,
            message=msg,
            context=storage_context(query=f"record_migration({version})"),
        ) from e


def apply_initial_schema(conn: Connection) -> None:
    """Apply initial schema to a fresh database.

    Creates all tables, indexes, and FTS5 structures.
    Records this as version 1.

    Args:
        conn: SQLite connection.

    Raises:
        StorageError: If schema application fails.
    """
    from contextual.storage.schema import apply_schema

    try:
        # Apply complete schema for version 1.
        apply_schema(conn)

        # Record the schema as version 1.
        record_migration(conn, 1)

    except StorageError:
        # Re-raise storage errors as-is.
        raise
    except Exception as e:
        msg = f"Failed to apply initial schema: {e}"
        raise StorageError(
            code=ErrorCode.STORAGE_MIGRATION_FAILED,
            message=msg,
            context=storage_context(),
        ) from e


def apply_migration_v2(conn: Connection) -> None:
    """Apply migration v2: Phase 1 codebase indexing tables.

    Adds:
    - code_symbols table (function/class/method metadata)
    - indexing_state table (tracks repo indexing status)
    - chunks table (code chunks with embeddings)
    - files table (indexed files)
    - vec0 virtual table (768-dim vectors for jina-v2-code)
    - fts_chunks virtual table (FTS5 full-text search)

    Args:
        conn: SQLite connection.

    Raises:
        StorageError: If migration fails.
    """
    try:
        cursor = conn.cursor()

        # FILES TABLE - tracks indexed files
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS files (
                id INTEGER PRIMARY KEY,
                path TEXT NOT NULL UNIQUE,
                language TEXT NOT NULL,
                mtime INTEGER NOT NULL,
                content_hash TEXT NOT NULL,
                indexed_at INTEGER NOT NULL
            ) STRICT
        """)

        # CHUNKS TABLE - code chunks with metadata
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS chunks (
                id INTEGER PRIMARY KEY,
                file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
                start_line INTEGER NOT NULL,
                end_line INTEGER NOT NULL,
                symbol_name TEXT,
                symbol_type TEXT,
                content TEXT NOT NULL,
                content_hash TEXT NOT NULL UNIQUE,
                embedding_id INTEGER,
                indexed_at INTEGER NOT NULL
            ) STRICT
        """)

        # CODE_SYMBOLS TABLE - extracted symbols with metadata
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS code_symbols (
                id INTEGER PRIMARY KEY,
                chunk_id INTEGER NOT NULL REFERENCES chunks(id) ON DELETE CASCADE,
                name TEXT NOT NULL,
                kind TEXT NOT NULL CHECK (
                    kind IN ('function','class','method','interface','struct',
                             'enum','type_alias','variable','import')
                ),
                signature TEXT,
                docstring TEXT,
                UNIQUE(chunk_id, name, kind)
            ) STRICT
        """)

        # INDEXING_STATE TABLE - repo-level indexing metadata
        cursor.execute("""
            CREATE TABLE IF NOT EXISTS indexing_state (
                repo_root TEXT PRIMARY KEY,
                last_full_index_at INTEGER NOT NULL,
                last_incremental_at INTEGER,
                total_files INTEGER NOT NULL,
                total_chunks INTEGER NOT NULL,
                total_symbols INTEGER NOT NULL
            ) STRICT
        """)

        # Indexes for performance
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_chunks_file ON chunks(file_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_chunks_content_hash ON chunks(content_hash)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_symbols_name ON code_symbols(name)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_symbols_kind ON code_symbols(kind)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_symbols_chunk ON code_symbols(chunk_id)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_files_path ON files(path)")
        cursor.execute("CREATE INDEX IF NOT EXISTS idx_files_content_hash ON files(content_hash)")

        # VEC0 VIRTUAL TABLE - 768-dim vectors (jina-v2-code)
        # Note: vec0 extension must be loaded before this runs
        try:
            cursor.execute("""
                CREATE VIRTUAL TABLE IF NOT EXISTS vec_chunks
                USING vec0(
                    chunk_id INTEGER PRIMARY KEY,
                    embedding FLOAT[768]
                )
            """)
        except sqlite3.OperationalError as e:
            # vec0 not available - log warning but don't fail migration
            logger.warning(
                "vec0 extension not available - vector search disabled",
                error=str(e)
            )

        # FTS5 VIRTUAL TABLE - full-text search on chunks
        # Using manual sync approach instead of triggers to avoid FTS5 transaction issues
        cursor.execute("""
            CREATE VIRTUAL TABLE IF NOT EXISTS fts_chunks USING fts5(
                chunk_id UNINDEXED,
                content,
                symbol_name,
                tokenize='unicode61 remove_diacritics 2 tokenchars "_"'
            )
        """)

        # EMBEDDING CACHE TABLE
        from contextual.embedding.cache import initialize_cache
        try:
            initialize_cache(conn)
            logger.info("Embedding cache initialized")
        except Exception as e:
            logger.warning("Failed to initialize embedding cache", error=str(e))
        

        # NOTE: Triggers disabled to avoid "unsafe use of virtual table" errors with FTS5
        # FTS5 sync is now handled manually in index_writer.py after chunk insertion

        conn.commit()

        logger.info("Migration v2 applied successfully")

    except sqlite3.Error as e:
        conn.rollback()
        msg = f"Failed to apply migration v2: {e}"
        raise StorageError(
            code=ErrorCode.STORAGE_MIGRATION_FAILED,
            message=msg,
            context=storage_context(query="apply_migration_v2"),
        ) from e


def run_migrations(conn: Connection) -> int:
    """Run any pending migrations.

    Checks current version and applies necessary migrations.

    Args:
        conn: SQLite connection.

    Returns:
        Number of migrations applied.

    Raises:
        StorageError: If migrations fail.
    """
    current_version = get_current_version(conn)
    migrations_applied = 0

    # Version 0 -> 1: initial schema.
    if current_version == 0:
        apply_initial_schema(conn)
        migrations_applied += 1
        current_version = 1

    # Version 1 -> 2: Phase 1 codebase indexing
    if current_version == 1:
        apply_migration_v2(conn)
        record_migration(conn, 2)
        migrations_applied += 1
        current_version = 2

    # Version 2 -> 3: Phase 2 docs schema (heading_path columns, FTS rebuild)
    if current_version == 2:
        from contextual.storage.migration_v2 import apply_migration_2
        apply_migration_2(conn)
        record_migration(conn, 3)
        migrations_applied += 1
        current_version = 3

    if migrations_applied > 0:
        logger.info(
            "Migrations complete",
            applied=migrations_applied,
            current_version=current_version
        )

    return migrations_applied
