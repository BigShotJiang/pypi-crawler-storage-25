"""SQLite connection pool with single-writer/multi-reader pattern.

This module provides a thread-safe connection pool for SQLite in WAL mode.
SQLite allows multiple concurrent readers but only one writer at a time.

The pool manages:
- One writer connection (exclusive, long-lived)
- Multiple reader connections (pooled, reused)
- Automatic pragma configuration
- WAL checkpoint operations
- Graceful shutdown

All connections are configured with:
- WAL mode (write-ahead logging)
- NORMAL synchronous mode (balance safety/speed)
- Optimized cache and mmap settings
- Foreign key enforcement
- Vec0 extension for vector search (if available)
"""

from __future__ import annotations

import sqlite3
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from pathlib import Path
from queue import Queue
from typing import TYPE_CHECKING

from contextual.core.errors import ErrorCode, StorageError, storage_context


if TYPE_CHECKING:
    from sqlite3 import Connection


# SQLite pragma configuration (from TECHNICAL_SPEC)
PRAGMAS = [
    "PRAGMA journal_mode = WAL",
    "PRAGMA synchronous = NORMAL",
    "PRAGMA busy_timeout = 5000",
    "PRAGMA cache_size = -64000",  # 64 MiB
    "PRAGMA mmap_size = 268435456",  # 256 MiB
    "PRAGMA temp_store = MEMORY",
    "PRAGMA foreign_keys = ON",
    "PRAGMA journal_size_limit = 67108864",  # 64 MiB
    "PRAGMA wal_autocheckpoint = 4000",  # pages
    "PRAGMA trusted_schema = OFF",
]

# Writer-only pragma
WRITER_PRAGMA = "PRAGMA automatic_index = OFF"


class SQLitePool:
    """Thread-safe SQLite connection pool with single-writer pattern.
    
    Manages a pool of SQLite connections in WAL mode. Provides:
    - One exclusive writer connection
    - Pool of reader connections (configurable size)
    - Automatic pragma configuration
    - WAL checkpoint operations
    - Graceful connection cleanup
    
    Thread-safety:
    - Writer access is protected by a lock
    - Reader pool uses a thread-safe queue
    - All connections can be used concurrently (WAL mode)
    
    Attributes:
        db_path: Path to SQLite database file.
        reader_pool_size: Maximum number of reader connections.
        _writer_conn: Exclusive writer connection.
        _writer_lock: Lock protecting writer access.
        _reader_pool: Queue of available reader connections.
        _closed: Flag indicating pool is closed.
    """

    def __init__(self, db_path: Path, *, reader_pool_size: int = 4) -> None:
        """Initialize connection pool.
        
        Creates writer connection and reader pool. Applies pragmas to all connections.
        
        Args:
            db_path: Path to SQLite database file.
            reader_pool_size: Maximum number of reader connections (default 4).
            
        Raises:
            StorageError: If database connection fails.
        """
        self.db_path = db_path
        self.reader_pool_size = reader_pool_size
        self._closed = False

        # Create writer connection
        try:
            self._writer_conn = self._create_connection(is_writer=True)
        except sqlite3.Error as e:
            msg = f"Failed to create writer connection: {e}"
            raise StorageError(
                code=ErrorCode.STORAGE_SQLITE_CONNECTION_FAILED,
                message=msg,
                context=storage_context(db_path=str(db_path)),
            ) from e

        # Writer lock (only one thread can write at a time)
        self._writer_lock = threading.Lock()

        # Reader connection pool
        self._reader_pool: Queue[Connection] = Queue(maxsize=reader_pool_size)

        # Pre-create reader connections
        for _ in range(reader_pool_size):
            try:
                conn = self._create_connection(is_writer=False)
                self._reader_pool.put(conn)
            except sqlite3.Error:
                # Failed to create reader - continue with fewer readers
                # This allows pool to function with degraded capacity
                pass

    def _create_connection(self, *, is_writer: bool) -> Connection:
        """Create and configure a SQLite connection.
        
        Loads vec0 extension for vector search if sqlite-vec is installed.
        
        Args:
            is_writer: Whether this is the writer connection.
            
        Returns:
            Configured SQLite connection.
            
        Raises:
            sqlite3.Error: If connection creation or pragma application fails.
        """
        # Create connection
        conn = sqlite3.connect(
            str(self.db_path),
            check_same_thread=False,  # We handle thread safety
            isolation_level=None,  # Autocommit mode (we manage transactions explicitly)
        )

        # Apply common pragmas
        for pragma in PRAGMAS:
            conn.execute(pragma)

        # Apply writer-only pragma
        if is_writer:
            conn.execute(WRITER_PRAGMA)

        # Load vec0 extension for vector search (sqlite-vec)
        # This enables CREATE VIRTUAL TABLE ... USING vec0(...)
        try:
            conn.enable_load_extension(True)
            import sqlite_vec
            conn.load_extension(sqlite_vec.loadable_path())
            conn.enable_load_extension(False)
        except ImportError:
            # sqlite-vec not installed - vector search disabled
            # This is logged in migrations.py when vec_chunks table creation fails
            pass
        except Exception:
            # Extension loading failed - continue without vector search
            # Common on systems where extensions are disabled
            pass

        # Run optimize to update query planner statistics
        conn.execute("PRAGMA optimize")

        return conn

    @contextmanager
    def writer(self) -> Iterator[Connection]:
        """Get the exclusive writer connection.
        
        This is a context manager that acquires the writer lock and yields
        the writer connection. Only one thread can hold the writer at a time.
        
        Yields:
            Writer connection.
            
        Raises:
            StorageError: If pool is closed or writer access fails.
            
        Example:
            >>> pool = SQLitePool(db_path)
            >>> with pool.writer() as conn:
            ...     conn.execute("INSERT INTO entities (...) VALUES (...)")
            ...     conn.commit()
        """
        if self._closed:
            msg = "Connection pool is closed"
            raise StorageError(
                code=ErrorCode.STORAGE_SQLITE_CONNECTION_FAILED,
                message=msg,
                context=storage_context(db_path=str(self.db_path)),
            )

        # Acquire writer lock
        acquired = self._writer_lock.acquire(timeout=10.0)
        if not acquired:
            msg = "Timeout waiting for writer lock"
            raise StorageError(
                code=ErrorCode.STORAGE_SQLITE_BUSY,
                message=msg,
                context=storage_context(db_path=str(self.db_path)),
            )

        try:
            yield self._writer_conn
        finally:
            # Always release lock
            self._writer_lock.release()

    @contextmanager
    def reader(self) -> Iterator[Connection]:
        """Get a reader connection from the pool.
        
        This is a context manager that gets a reader connection from the pool
        and returns it when done. If no connections are available, blocks
        until one becomes available.
        
        Yields:
            Reader connection.
            
        Raises:
            StorageError: If pool is closed or no readers available.
            
        Example:
            >>> pool = SQLitePool(db_path)
            >>> with pool.reader() as conn:
            ...     cursor = conn.execute("SELECT * FROM entities")
            ...     rows = cursor.fetchall()
        """
        if self._closed:
            msg = "Connection pool is closed"
            raise StorageError(
                code=ErrorCode.STORAGE_SQLITE_CONNECTION_FAILED,
                message=msg,
                context=storage_context(db_path=str(self.db_path)),
            )

        # Get connection from pool (blocks if none available)
        try:
            conn = self._reader_pool.get(timeout=10.0)
        except Exception as e:
            msg = f"Timeout waiting for reader connection: {e}"
            raise StorageError(
                code=ErrorCode.STORAGE_SQLITE_POOL_EXHAUSTED,
                message=msg,
                context=storage_context(db_path=str(self.db_path)),
            ) from e

        try:
            yield conn
        finally:
            # Return connection to pool
            try:
                self._reader_pool.put(conn, block=False)
            except Exception:
                # Pool is full or closed - close this connection
                try:
                    conn.close()
                except Exception:
                    pass

    def checkpoint_wal(self, *, mode: str = "PASSIVE") -> tuple[int, int]:
        """Checkpoint the WAL file.
        
        WAL checkpointing moves data from the WAL file to the main database.
        This should be called periodically to prevent WAL file growth.
        
        Modes:
        - PASSIVE: Checkpoint as much as possible without blocking
        - FULL: Checkpoint entire WAL (may block)
        - RESTART: FULL + restart WAL file
        - TRUNCATE: RESTART + truncate WAL to zero bytes
        
        Args:
            mode: Checkpoint mode (default PASSIVE).
            
        Returns:
            Tuple of (pages_in_wal, pages_checkpointed).
            
        Raises:
            StorageError: If checkpoint fails.
            
        Example:
            >>> pool = SQLitePool(db_path)
            >>> pages_in_wal, checkpointed = pool.checkpoint_wal(mode="TRUNCATE")
            >>> print(f"Checkpointed {checkpointed} pages")
        """
        if self._closed:
            msg = "Connection pool is closed"
            raise StorageError(
                code=ErrorCode.STORAGE_SQLITE_WAL_CHECKPOINT_FAILED,
                message=msg,
                context=storage_context(db_path=str(self.db_path)),
            )

        try:
            with self.writer() as conn:
                cursor = conn.execute(f"PRAGMA wal_checkpoint({mode})")
                result = cursor.fetchone()

                if result is None:
                    # Checkpoint didn't return status (shouldn't happen)
                    return (0, 0)

                # Result: (busy, log_pages, checkpointed_pages)
                # We return (log_pages, checkpointed_pages)
                return (result[1] if len(result) > 1 else 0,
                        result[2] if len(result) > 2 else 0)

        except sqlite3.Error as e:
            msg = f"WAL checkpoint failed: {e}"
            raise StorageError(
                code=ErrorCode.STORAGE_SQLITE_WAL_CHECKPOINT_FAILED,
                message=msg,
                context=storage_context(db_path=str(self.db_path)),
            ) from e

    def execute_with_retry(
        self,
        query: str,
        params: tuple[object, ...] = (),
        *,
        max_retries: int = 3,
        is_write: bool = False,
    ) -> sqlite3.Cursor:
        """Execute a query with automatic retry on SQLITE_BUSY.
        
        Retries queries that fail with SQLITE_BUSY error (database locked).
        Useful for write operations that might conflict.
        
        Args:
            query: SQL query to execute.
            params: Query parameters.
            max_retries: Maximum retry attempts (default 3).
            is_write: Whether this is a write operation (uses writer connection).
            
        Returns:
            Cursor with query results.
            
        Raises:
            StorageError: If query fails after retries.
        """
        last_error: Exception | None = None

        for attempt in range(max_retries):
            try:
                if is_write:
                    with self.writer() as conn:
                        cursor = conn.execute(query, params)
                        conn.commit()
                        return cursor
                else:
                    with self.reader() as conn:
                        return conn.execute(query, params)

            except sqlite3.OperationalError as e:
                # Check if this is a BUSY error
                if "locked" in str(e).lower() or "busy" in str(e).lower():
                    last_error = e
                    # Wait a bit before retry (exponential backoff)
                    import time
                    time.sleep(0.1 * (2 ** attempt))
                    continue
                # Not a BUSY error - don't retry
                raise StorageError(
                    code=ErrorCode.STORAGE_SQLITE_QUERY_FAILED,
                    message=f"Query failed: {e}",
                    context=storage_context(query=query[:200]),
                ) from e

        # Max retries exceeded
        msg = f"Query failed after {max_retries} retries: {last_error}"
        raise StorageError(
            code=ErrorCode.STORAGE_SQLITE_BUSY,
            message=msg,
            context=storage_context(query=query[:200]),
        )

    def get_db_stats(self) -> dict[str, int | str]:
        """Get database statistics.
        
        Returns:
            Dictionary with database size, page count, WAL size, etc.
        """
        stats: dict[str, int | str] = {}

        try:
            with self.reader() as conn:
                cursor = conn.execute("PRAGMA page_count")
                stats["page_count"] = cursor.fetchone()[0]

                cursor = conn.execute("PRAGMA page_size")
                stats["page_size"] = cursor.fetchone()[0]

                cursor = conn.execute("PRAGMA journal_mode")
                stats["journal_mode"] = cursor.fetchone()[0]

                # Calculate database size
                stats["db_size_bytes"] = stats["page_count"] * stats["page_size"]

        except Exception:
            # Stats are best-effort
            pass

        return stats

    def close(self) -> None:
        """Close all connections and shut down the pool.
        
        Performs WAL checkpoint and closes all connections gracefully.
        This should be called when shutting down the application.
        """
        if self._closed:
            return

        self._closed = True

        # Checkpoint WAL before closing
        try:
            self.checkpoint_wal(mode="TRUNCATE")
        except Exception:
            # Best effort - don't fail on checkpoint error during shutdown
            pass

        # Close writer connection
        try:
            self._writer_conn.close()
        except Exception:
            pass

        # Close all reader connections
        while not self._reader_pool.empty():
            try:
                conn = self._reader_pool.get(block=False)
                conn.close()
            except Exception:
                pass

    def __enter__(self) -> SQLitePool:
        """Context manager entry.
        
        Returns:
            Self.
        """
        return self

    def __exit__(self, exc_type: object, exc_val: object, exc_tb: object) -> None:
        """Context manager exit.
        
        Closes the pool.
        """
        self.close()

    def __del__(self) -> None:
        """Destructor.
        
        Ensures connections are closed even if close() wasn't called.
        """
        try:
            self.close()
        except Exception:
            pass
