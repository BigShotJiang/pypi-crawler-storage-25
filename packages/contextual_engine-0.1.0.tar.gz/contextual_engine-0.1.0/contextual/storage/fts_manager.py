"""FTS5 full-text search manager for code chunks."""

from __future__ import annotations

import sqlite3
from typing import TYPE_CHECKING

from contextual.core.errors import ErrorCode, StorageError, storage_context
from contextual.observability.logging import get_logger


if TYPE_CHECKING:
    from sqlite3 import Connection

logger = get_logger(__name__)

_FTS_TABLE = "fts_chunks"
_FTS_ERROR_CODE = getattr(ErrorCode, "STORAGE_FTS_FAILED", ErrorCode.STORAGE_SQLITE_QUERY_FAILED)


def escape_fts_query(query: str) -> str:
    """Escape a user query for safe FTS5 phrase matching.

    Args:
        query: Raw user search text.

    Returns:
        Phrase-quoted FTS5-safe query string.
    """
    escaped = query.replace("\\", "\\\\").replace('"', '\\"')
    return f'"{escaped}"'


def search_fts(
    conn: Connection,
    query: str,
    k: int = 10,
    language_filter: str | None = None,
) -> list[tuple[int, float]]:
    """Search chunks using SQLite FTS5 and return ranked BM25 scores.

    Args:
        conn: SQLite connection.
        query: FTS5 query text.
        k: Maximum result count in range [1, 1000].
        language_filter: Optional language suffix (currently ignored - can be implemented via joins).

    Returns:
        List of `(chunk_id, score)` tuples where score is positive and higher is better.

    Raises:
        StorageError: If SQLite execution fails unexpectedly.
    """
    if query is None:
        return []
    if not isinstance(query, str) or not query.strip():
        return []
    if k <= 0 or k > 1000:
        raise ValueError("k must be between 1 and 1000")

    normalized_query = query.strip()
    escaped_query = escape_fts_query(normalized_query)

    sql = (
        "SELECT chunk_id, -bm25(fts_chunks) AS score "
        "FROM fts_chunks "
        "WHERE fts_chunks MATCH ?"
    )
    params: list[object] = [escaped_query]

    # Language filtering can be added later via JOIN with files table if needed
    # TODO: Implement language filtering via JOIN with files table

    sql += " ORDER BY score DESC LIMIT ?"
    params.append(k)

    try:
        cursor = conn.execute(sql, tuple(params))
        rows = cursor.fetchall()
        return [(int(chunk_id), float(score)) for chunk_id, score in rows]
    except sqlite3.OperationalError as exc:
        # Invalid FTS syntax should not break callers; return no results.
        logger.warning(
            "Invalid FTS5 query; returning empty results",
            query=normalized_query,
            error=str(exc),
        )
        return []
    except sqlite3.Error as exc:
        msg = f"FTS5 search failed: {exc}"
        logger.error("FTS5 search failed", error=str(exc))
        raise StorageError(
            code=_FTS_ERROR_CODE,
            message=msg,
            context=storage_context(table=_FTS_TABLE, query=normalized_query),
        ) from exc


def count_matches(conn: Connection, query: str) -> int:
    """Count total chunks that match an FTS5 query.

    Args:
        conn: SQLite connection.
        query: FTS5 query text.

    Returns:
        Number of matching chunks.

    Raises:
        StorageError: If SQLite execution fails unexpectedly.
    """
    if query is None:
        return 0
    if not isinstance(query, str) or not query.strip():
        return 0

    normalized_query = query.strip()
    escaped_query = escape_fts_query(normalized_query)

    sql = (
        "SELECT COUNT(*) "
        "FROM fts_chunks "
        "WHERE fts_chunks MATCH ?"
    )

    try:
        cursor = conn.execute(sql, (escaped_query,))
        row = cursor.fetchone()
        return int(row[0]) if row else 0
    except sqlite3.OperationalError as exc:
        logger.warning(
            "Invalid FTS5 count query; returning zero",
            query=normalized_query,
            error=str(exc),
        )
        return 0
    except sqlite3.Error as exc:
        msg = f"FTS5 count failed: {exc}"
        logger.error("FTS5 count failed", error=str(exc))
        raise StorageError(
            code=_FTS_ERROR_CODE,
            message=msg,
            context=storage_context(table=_FTS_TABLE, query=normalized_query),
        ) from exc


def get_chunk_snippet(
    conn: Connection,
    chunk_id: int,
    query: str,
    max_len: int = 200,
) -> str:
    """Get a highlighted snippet for a matching chunk.

    Args:
        conn: SQLite connection.
        chunk_id: Chunk identifier from `chunks.id`.
        query: Query text used for highlighting.
        max_len: Maximum snippet character length.

    Returns:
        Highlighted snippet string, truncated to `max_len`, or empty string.

    Raises:
        StorageError: If SQLite execution fails unexpectedly.
    """
    if query is None:
        return ""
    if not isinstance(query, str) or not query.strip():
        return ""
    if max_len <= 0:
        return ""

    normalized_query = query.strip()
    escaped_query = escape_fts_query(normalized_query)

    sql = (
        "SELECT snippet(fts_chunks, 1, '<b>', '</b>', '...', 20) AS snippet_text "
        "FROM fts_chunks "
        "WHERE chunk_id = ? AND fts_chunks MATCH ?"
    )

    try:
        cursor = conn.execute(sql, (chunk_id, escaped_query))
        row = cursor.fetchone()
        if not row or row[0] is None:
            return ""
        snippet = str(row[0])
        return snippet if len(snippet) <= max_len else snippet[:max_len]
    except sqlite3.OperationalError as exc:
        logger.warning(
            "Invalid FTS5 snippet query; returning empty snippet",
            query=normalized_query,
            chunk_id=chunk_id,
            error=str(exc),
        )
        return ""
    except sqlite3.Error as exc:
        msg = f"FTS5 snippet retrieval failed: {exc}"
        logger.error("FTS5 snippet retrieval failed", error=str(exc), chunk_id=chunk_id)
        raise StorageError(
            code=_FTS_ERROR_CODE,
            message=msg,
            context=storage_context(table=_FTS_TABLE, query=normalized_query),
        ) from exc


def test_fts_search() -> None:
    """Validate core FTS5 search and escaping behavior."""
    conn = sqlite3.connect(":memory:")

    conn.execute("""
        CREATE TABLE chunks (
            id INTEGER PRIMARY KEY,
            file_id INTEGER,
            start_line INTEGER,
            end_line INTEGER,
            symbol_name TEXT,
            symbol_type TEXT,
            content TEXT,
            content_hash TEXT,
            embedding_id INTEGER,
            indexed_at INTEGER
        )
    """)

    conn.execute("""
        CREATE VIRTUAL TABLE fts_chunks USING fts5(
            chunk_id UNINDEXED,
            content,
            symbol_name,
            tokenize='unicode61 remove_diacritics 2'
        )
    """)

    conn.execute(
        "INSERT INTO chunks VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)",
        (1, 1, 10, 20, "getUserData", "function", "def getUserData(): return data", "hash1", None, 1000),
    )
    conn.execute(
        "INSERT INTO fts_chunks VALUES (?, ?, ?)",
        (1, "def getUserData(): return data", "getUserData"),
    )

    results = search_fts(conn, "getUserData", k=10)
    assert len(results) == 1
    assert results[0][0] == 1
    assert results[0][1] > 0

    escaped = escape_fts_query('test "quote"')
    assert '"' in escaped


def test_fts_helpers() -> None:
    """Validate count and snippet helper functions."""
    conn = sqlite3.connect(":memory:")
    conn.execute("""
        CREATE VIRTUAL TABLE fts_chunks USING fts5(
            chunk_id UNINDEXED,
            content,
            symbol_name,
            tokenize='unicode61 remove_diacritics 2'
        )
    """)
    conn.execute(
        "INSERT INTO fts_chunks VALUES (?, ?, ?)",
        (11, "class Service: async def run(self): pass", "Service"),
    )

    assert count_matches(conn, "Service") == 1
    snippet = get_chunk_snippet(conn, chunk_id=11, query="async def")
    assert snippet
    assert isinstance(snippet, str)
