"""Vec0 virtual table manager for vector storage and similarity search.

Provides a functional API for interacting with the vec_chunks vec0 virtual
table. All operations are synchronous and designed to be called from within
the SQLite pool's writer/reader context managers.

Operations:
- insert_vectors: Batch insert (chunk_id, embedding) pairs
- search_vectors: Cosine similarity search returning (chunk_id, score)
- delete_vectors: Remove vectors by chunk_id
- count_vectors: Total vector count

Vec0 stores 768-dimensional embeddings from jina-v2-code (via fastembed).
"""

from __future__ import annotations

import json
import sqlite3
from typing import TYPE_CHECKING

from contextual.core.errors import ErrorCode, StorageError, storage_context
from contextual.observability.logging import get_logger


if TYPE_CHECKING:
    from sqlite3 import Connection


logger = get_logger(__name__)

# ============================================================================
# CONSTANTS
# ============================================================================

EMBEDDING_DIM = 768
"""Expected embedding dimensionality (jina-v2-code)."""

TABLE_NAME = "vec_chunks"
"""Vec0 virtual table name (created by migration v2)."""

MAX_K = 1000
"""Maximum allowed top-k value for search queries."""


# ============================================================================
# PUBLIC API
# ============================================================================


def insert_vectors(
    conn: Connection,
    vectors: list[tuple[int, list[float]]],
) -> int:
    """Insert a batch of vectors into the vec_chunks table.

    Each vector is a (chunk_id, embedding) pair. Existing chunk_ids are
    replaced (upsert semantics) to handle re-indexing gracefully.

    Args:
        conn: SQLite connection with vec0 extension loaded.
        vectors: List of (chunk_id, embedding) tuples. Each embedding
            must be a list of exactly 768 floats.

    Returns:
        Number of vectors successfully inserted.

    Raises:
        StorageError: If validation fails or insert encounters a
            database error.

    Example:
        >>> vectors = [(1, [0.1] * 768), (2, [0.2] * 768)]
        >>> count = insert_vectors(conn, vectors)
        >>> assert count == 2
    """
    if not vectors:
        return 0

    # Validate all embeddings before touching the database
    for chunk_id, embedding in vectors:
        if len(embedding) != EMBEDDING_DIM:
            msg = (
                f"Embedding dimension mismatch for chunk_id={chunk_id}: "
                f"expected {EMBEDDING_DIM}, got {len(embedding)}"
            )
            raise StorageError(
                code=ErrorCode.STORAGE_VEC_DIMENSION_MISMATCH,
                message=msg,
                context=storage_context(
                    table=TABLE_NAME,
                    query=f"insert chunk_id={chunk_id}",
                ),
            )

    inserted = 0
    try:
        cursor = conn.cursor()

        if vectors:
            # Vec0 accepts JSON-serialised float arrays as the embedding value.
            vec_rows = [(chunk_id, json.dumps(embedding)) for chunk_id, embedding in vectors]
            cursor.executemany(
                f"INSERT OR REPLACE INTO {TABLE_NAME}(chunk_id, embedding) VALUES (?, ?)",
                vec_rows,
            )
            inserted = len(vectors)

        conn.commit()

        logger.debug(
            "Vectors inserted",
            count=inserted,
            table=TABLE_NAME,
        )

        return inserted

    except sqlite3.Error as e:
        # Roll back partial inserts so the caller can retry cleanly.
        try:
            conn.rollback()
        except sqlite3.Error:
            pass

        msg = f"Failed to insert {len(vectors)} vectors: {e}"
        raise StorageError(
            code=ErrorCode.STORAGE_VEC_FAILED,
            message=msg,
            context=storage_context(
                table=TABLE_NAME,
                query=f"INSERT OR REPLACE ({len(vectors)} vectors)",
            ),
        ) from e


def search_vectors(
    conn: Connection,
    query_vector: list[float],
    k: int = 10,
    min_score: float = 0.0,
) -> list[tuple[int, float]]:
    """Perform cosine similarity search against stored vectors.

    Uses vec0's ``MATCH`` syntax to find the nearest neighbours of
    *query_vector* and returns results ordered by descending similarity.

    Vec0 returns *distance* (lower = closer).  This function converts it
    to a *similarity score*: ``score = 1 - distance``.  Results below
    ``min_score`` are filtered out.

    Args:
        conn: SQLite connection with vec0 extension loaded.
        query_vector: Query embedding (768-dimensional float list).
        k: Number of top results to return (1–1000, default 10).
        min_score: Minimum similarity score threshold (0.0–1.0,
            default 0.0 — no filtering).

    Returns:
        List of ``(chunk_id, similarity_score)`` tuples sorted by
        descending score.

    Raises:
        StorageError: If parameter validation fails or the query
            encounters a database error.

    Example:
        >>> results = search_vectors(conn, [0.15] * 768, k=5)
        >>> for chunk_id, score in results:
        ...     print(f"chunk {chunk_id}: {score:.4f}")
    """
    # --- parameter validation ------------------------------------------------
    if len(query_vector) != EMBEDDING_DIM:
        msg = (
            f"Query vector dimension mismatch: "
            f"expected {EMBEDDING_DIM}, got {len(query_vector)}"
        )
        raise StorageError(
            code=ErrorCode.STORAGE_VEC_DIMENSION_MISMATCH,
            message=msg,
            context=storage_context(table=TABLE_NAME, query="search_vectors"),
        )

    if k <= 0 or k > MAX_K:
        msg = f"k must be between 1 and {MAX_K}, got {k}"
        raise StorageError(
            code=ErrorCode.STORAGE_VEC_INVALID_PARAMETER,
            message=msg,
            context=storage_context(table=TABLE_NAME, query="search_vectors"),
        )

    if not 0.0 <= min_score <= 1.0:
        msg = f"min_score must be between 0.0 and 1.0, got {min_score}"
        raise StorageError(
            code=ErrorCode.STORAGE_VEC_INVALID_PARAMETER,
            message=msg,
            context=storage_context(table=TABLE_NAME, query="search_vectors"),
        )

    # --- query execution -----------------------------------------------------
    try:
        query_json = json.dumps(query_vector)

        cursor = conn.execute(
            f"SELECT chunk_id, distance "
            f"FROM {TABLE_NAME} "
            "WHERE embedding MATCH ? "
            "ORDER BY distance "
            "LIMIT ?",
            (query_json, k),
        )

        results: list[tuple[int, float]] = []
        for row in cursor.fetchall():
            chunk_id: int = row[0]
            distance: float = row[1]
            score = 1.0 - distance

            if score >= min_score:
                results.append((chunk_id, score))

        logger.debug(
            "Vector search completed",
            k=k,
            min_score=min_score,
            results_returned=len(results),
        )

        return results

    except sqlite3.Error as e:
        msg = f"Vector search failed: {e}"
        raise StorageError(
            code=ErrorCode.STORAGE_VEC_FAILED,
            message=msg,
            context=storage_context(
                table=TABLE_NAME,
                query=f"MATCH (k={k}, min_score={min_score})",
            ),
        ) from e


def delete_vectors(conn: Connection, chunk_ids: list[int]) -> int:
    """Delete vectors by chunk_id.

    Args:
        conn: SQLite connection with vec0 extension loaded.
        chunk_ids: List of chunk IDs whose vectors should be removed.

    Returns:
        Number of vectors deleted.

    Raises:
        StorageError: If deletion encounters a database error.

    Example:
        >>> deleted = delete_vectors(conn, [1, 2, 3])
        >>> assert deleted == 3
    """
    if not chunk_ids:
        return 0

    try:
        cursor = conn.cursor()
        deleted = 0

        for chunk_id in chunk_ids:
            cursor.execute(
                f"DELETE FROM {TABLE_NAME} WHERE chunk_id = ?",
                (chunk_id,),
            )
            deleted += cursor.rowcount

        conn.commit()

        logger.debug(
            "Vectors deleted",
            requested=len(chunk_ids),
            deleted=deleted,
            table=TABLE_NAME,
        )

        return deleted

    except sqlite3.Error as e:
        try:
            conn.rollback()
        except sqlite3.Error:
            pass

        msg = f"Failed to delete vectors for {len(chunk_ids)} chunk_ids: {e}"
        raise StorageError(
            code=ErrorCode.STORAGE_VEC_FAILED,
            message=msg,
            context=storage_context(
                table=TABLE_NAME,
                query=f"DELETE ({len(chunk_ids)} chunk_ids)",
            ),
        ) from e


def count_vectors(conn: Connection) -> int:
    """Return the total number of vectors in the vec_chunks table.

    Args:
        conn: SQLite connection with vec0 extension loaded.

    Returns:
        Total vector count.

    Raises:
        StorageError: If the count query fails.

    Example:
        >>> n = count_vectors(conn)
        >>> print(f"{n} vectors stored")
    """
    try:
        cursor = conn.execute(f"SELECT COUNT(*) FROM {TABLE_NAME}")
        result = cursor.fetchone()
        count = int(result[0]) if result else 0

        logger.debug("Vector count", count=count, table=TABLE_NAME)
        return count

    except sqlite3.Error as e:
        msg = f"Failed to count vectors: {e}"
        raise StorageError(
            code=ErrorCode.STORAGE_VEC_FAILED,
            message=msg,
            context=storage_context(
                table=TABLE_NAME,
                query="SELECT COUNT(*)",
            ),
        ) from e


# ============================================================================
# TESTS (run with: pytest contextual/storage/vec0_manager.py)
# ============================================================================

if __name__ == "__main__":
    import sys

    def _test_insert_and_search() -> None:
        """Smoke test: insert two vectors, search, verify results."""
        conn = sqlite3.connect(":memory:")
        conn.enable_load_extension(True)
        try:
            conn.load_extension("vec0")
        except Exception as exc:
            print(f"SKIP: vec0 extension not available ({exc})")
            return

        conn.execute(
            "CREATE VIRTUAL TABLE vec_chunks USING vec0("
            "chunk_id INTEGER PRIMARY KEY, "
            "embedding FLOAT[768]"
            ")"
        )

        # Insert
        vectors = [(1, [0.1] * 768), (2, [0.2] * 768)]
        count = insert_vectors(conn, vectors)
        assert count == 2, f"Expected 2 inserts, got {count}"

        # Count
        assert count_vectors(conn) == 2

        # Search
        results = search_vectors(conn, [0.15] * 768, k=2)
        assert len(results) == 2, f"Expected 2 results, got {len(results)}"
        assert results[0][0] in [1, 2], f"Unexpected chunk_id: {results[0][0]}"
        assert 0.0 <= results[0][1] <= 1.0, f"Score out of range: {results[0][1]}"

        # Delete
        deleted = delete_vectors(conn, [1])
        assert deleted == 1, f"Expected 1 deletion, got {deleted}"
        assert count_vectors(conn) == 1

        conn.close()
        print("ALL TESTS PASSED")

    def _test_validation() -> None:
        """Test parameter validation without vec0 extension."""
        conn = sqlite3.connect(":memory:")

        # Wrong dimension
        try:
            insert_vectors(conn, [(1, [0.1] * 100)])
            assert False, "Should have raised StorageError"
        except StorageError as e:
            assert e.code == ErrorCode.STORAGE_VEC_DIMENSION_MISMATCH

        # Invalid k
        try:
            search_vectors(conn, [0.1] * 768, k=0)
            assert False, "Should have raised StorageError"
        except StorageError as e:
            assert e.code == ErrorCode.STORAGE_VEC_INVALID_PARAMETER

        # Invalid k (too large)
        try:
            search_vectors(conn, [0.1] * 768, k=1001)
            assert False, "Should have raised StorageError"
        except StorageError as e:
            assert e.code == ErrorCode.STORAGE_VEC_INVALID_PARAMETER

        # Invalid min_score
        try:
            search_vectors(conn, [0.1] * 768, min_score=1.5)
            assert False, "Should have raised StorageError"
        except StorageError as e:
            assert e.code == ErrorCode.STORAGE_VEC_INVALID_PARAMETER

        conn.close()
        print("VALIDATION TESTS PASSED")

    _test_validation()
    _test_insert_and_search()
    sys.exit(0)
