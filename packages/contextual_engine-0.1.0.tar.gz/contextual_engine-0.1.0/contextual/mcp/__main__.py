"""Entry point for python -m contextual.mcp

This __main__.py file allows running the MCP server via:
    python -m contextual.mcp

Without the RuntimeWarning that occurs when using:
    python -m contextual.mcp.server

The warning happens because Python imports contextual.mcp before
executing contextual.mcp.server, creating a module state issue.
This __main__.py cleanly resolves that.
"""

from __future__ import annotations

# Suppress warnings before any other imports
import warnings
warnings.filterwarnings('ignore')

# Import and run the server
from contextual.mcp.server import main

if __name__ == "__main__":
    main()
