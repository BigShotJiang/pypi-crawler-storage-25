"""MCP server module: FastMCP tools and server.

Public API:
- main: Server entry point
- mcp: FastMCP instance
"""
from __future__ import annotations

from contextual.mcp.server import main, mcp


__all__ = [
    "main",
    "mcp",
]
