"""FastMCP server for Contextual codebase tools.

This module initializes the FastMCP server and registers all tools.
Tools are defined in tools.py and registered here.

Server configuration:
- Name: "contextual"
- Transport: stdio (MCP standard)
- Structured logging to stderr (never stdout in stdio mode)
- Graceful shutdown on SIGTERM/SIGINT
"""

from __future__ import annotations

# Suppress warnings BEFORE any other imports to prevent stdout pollution
import warnings
warnings.filterwarnings('ignore')

import signal
import sys
from typing import Any

from fastmcp import FastMCP

from contextual.observability.logging import configure_logging, get_logger

# Configure logging IMMEDIATELY so structlog routes to stderr, not stdout.
# structlog's default PrintLoggerFactory writes to stdout which breaks MCP stdio.
configure_logging()

logger = get_logger(__name__)

# ============================================================================
# SERVER INITIALIZATION
# ============================================================================

# Create FastMCP server instance
mcp = FastMCP("contextual")


# ============================================================================
# GRACEFUL SHUTDOWN
# ============================================================================


def _handle_shutdown(signum: int, frame: Any) -> None:
    """Handle shutdown signals gracefully.

    On SIGTERM/SIGINT:
    1. Log shutdown
    2. Close database connections
    3. Flush logs
    4. Exit cleanly

    Args:
        signum: Signal number.
        frame: Current stack frame.
    """
    logger.info("Shutdown signal received", signal=signum)

    try:
        # Close database pools
        from contextual.mcp.tools import _pool
        if _pool is not None:
            _pool.close()
            logger.debug("Database pool closed")
        
        logger.info("Shutdown complete")
        sys.exit(0)
    except Exception as e:
        logger.error("Shutdown error", error=str(e))
        sys.exit(1)


# Register signal handlers
signal.signal(signal.SIGTERM, _handle_shutdown)
signal.signal(signal.SIGINT, _handle_shutdown)


# ============================================================================
# TOOL REGISTRATION
# ============================================================================

# Import tools module to register @mcp.tool() decorated functions
# MUST come after mcp is created but before main() runs
from contextual.mcp import tools  # noqa: F401, E402


# ============================================================================
# SERVER ENTRYPOINT
# ============================================================================


def main() -> None:
    """Run the MCP server.

    This is the main entry point called by the contextual CLI.
    Starts the FastMCP server in stdio mode.
    """
    logger.info("Starting Contextual MCP server")

    try:
        # Run the server (blocking)
        mcp.run()
    except KeyboardInterrupt:
        logger.info("Server interrupted")
        sys.exit(0)
    except Exception as e:
        logger.error("Server error", error=str(e), exc_info=True)
        sys.exit(1)

import os
if os.getenv("CONTEXTUAL_DOCS_ENABLED", "0") == "1":
    import contextual.mcp.docs_tools  # noqa: F401


if __name__ == "__main__":
    main()
