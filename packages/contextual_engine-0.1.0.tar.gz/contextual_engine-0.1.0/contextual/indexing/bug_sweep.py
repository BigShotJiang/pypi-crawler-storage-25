#!/usr/bin/env python3
"""Comprehensive bug sweep for contextual/indexing directory.

Searches for:
1. Invalid ErrorCode references
2. Invalid ModelType references  
3. Incorrect pool API usage (get_writer/get_reader vs writer()/reader())
4. Missing imports
5. Type mismatches
"""
from __future__ import annotations

import re
import sys
from pathlib import Path


# Known valid ErrorCodes (from earlier analysis)
VALID_ERROR_CODES = {
    # Storage errors
    "STORAGE_SQLITE_CONNECTION_FAILED",
    "STORAGE_SQLITE_TRANSACTION_FAILED",
    "STORAGE_MIGRATION_FAILED",
    "STORAGE_SCHEMA_VALIDATION_FAILED",

    # Indexing errors
    "INDEXING_PARSER_PARSE_FAILED",
    "INDEXING_CHUNKER_FILE_TOO_LARGE",
    "INDEXING_CHUNKER_BINARY_FILE",
    "INDEXING_CHUNKER_ENCODING_ERROR",
    "INDEXING_CHUNKER_SPLIT_FAILED",
    "INDEXING_FILE_NOT_FOUND",
    "INDEXING_FILE_READ_FAILED",
    "INDEXING_EMBEDDING_INFERENCE_FAILED",
}

# Known valid ModelTypes
VALID_MODEL_TYPES = {
    "JINA_CODE_V2",
    "NOMIC_TEXT_V15",
}

# Invalid patterns to search for
INVALID_PATTERNS = [
    # Invalid ErrorCodes
    (r"ErrorCode\.CHUNKING_FAILED", "ErrorCode.CHUNKING_FAILED → use INDEXING_CHUNKER_SPLIT_FAILED"),
    (r"ErrorCode\.STORAGE_WRITE_FAILED", "ErrorCode.STORAGE_WRITE_FAILED → use STORAGE_SQLITE_TRANSACTION_FAILED"),
    (r"ErrorCode\.STORAGE_EMBEDDING_FAILED", "ErrorCode.STORAGE_EMBEDDING_FAILED → use INDEXING_EMBEDDING_INFERENCE_FAILED"),
    (r"ErrorCode\.INDEXING_FAILED", "ErrorCode.INDEXING_FAILED → use specific INDEXING_* code"),

    # Invalid ModelTypes
    (r"ModelType\.JINA_V2_CODE", "ModelType.JINA_V2_CODE → use JINA_CODE_V2"),

    # Invalid pool API
    (r"pool\.get_writer\(\)", "pool.get_writer() → use 'with pool.writer() as conn:'"),
    (r"pool\.get_reader\(\)", "pool.get_reader() → use 'with pool.reader() as conn:'"),
]

def scan_file(file_path: Path) -> list[tuple[int, str, str]]:
    """Scan a file for known bug patterns.
    
    Returns:
        List of (line_num, line_content, issue_description)
    """
    issues = []

    try:
        content = file_path.read_text(encoding="utf-8")
        lines = content.split("\n")

        for line_num, line in enumerate(lines, start=1):
            for pattern, description in INVALID_PATTERNS:
                if re.search(pattern, line):
                    issues.append((line_num, line.strip(), description))

    except Exception as e:
        print(f"Error reading {file_path}: {e}", file=sys.stderr)

    return issues

def main():
    """Run comprehensive sweep."""
    repo_root = Path("/Users/apple/TechStack/Projects/Contextual")
    indexing_dir = repo_root / "contextual" / "indexing"

    if not indexing_dir.exists():
        print(f"Indexing directory not found: {indexing_dir}")
        return

    # Scan all Python files in indexing directory
    all_issues = {}

    for py_file in sorted(indexing_dir.glob("*.py")):
        if py_file.name == "__init__.py":
            continue

        issues = scan_file(py_file)
        if issues:
            all_issues[py_file] = issues

    # Print results
    if not all_issues:
        print("✅ NO ISSUES FOUND - All files clean!")
        return

    print(f"🔍 FOUND {len(all_issues)} FILES WITH ISSUES:\n")

    for file_path, issues in all_issues.items():
        print(f"{'='*80}")
        print(f"FILE: {file_path.relative_to(repo_root)}")
        print(f"{'='*80}")

        for line_num, line_content, description in issues:
            print(f"  Line {line_num}: {description}")
            print(f"    → {line_content}")
            print()

if __name__ == "__main__":
    main()
