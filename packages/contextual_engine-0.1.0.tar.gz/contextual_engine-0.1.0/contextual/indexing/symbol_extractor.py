"""Symbol extraction engine using Tree-sitter queries.

Extracts functions, classes, methods, interfaces, and other symbols from code
using language-specific Tree-sitter queries (.scm files).
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from tree_sitter_language_pack import get_parser

from contextual.core.errors import ErrorCode, IndexingError
from contextual.core.models import Language
from contextual.observability.logging import get_logger


if TYPE_CHECKING:
    from tree_sitter import Node

logger = get_logger(__name__)


# Language to Tree-sitter language name mapping
LANGUAGE_MAPPING = {
    Language.PYTHON: "python",
    Language.TYPESCRIPT: "typescript",
    Language.JAVASCRIPT: "javascript",
    Language.TSX: "tsx",
    Language.RUST: "rust",
    Language.GO: "go",
    Language.JAVA: "java",
    Language.CSHARP: "c_sharp",
}


class Symbol:
    """Extracted code symbol with metadata.
    
    Attributes:
        name: Symbol name (e.g., "getUserData")
        kind: Symbol kind (function, class, method, etc.)
        start_line: Starting line number (1-indexed)
        end_line: Ending line number (1-indexed)
        signature: Function/method signature (if applicable)
        docstring: Docstring/comment (if applicable)
        parent: Parent symbol name (for methods, nested classes)
    """

    def __init__(
        self,
        name: str,
        kind: str,
        start_line: int,
        end_line: int,
        signature: str | None = None,
        docstring: str | None = None,
        parent: str | None = None,
    ):
        self.name = name
        self.kind = kind
        self.start_line = start_line
        self.end_line = end_line
        self.signature = signature
        self.docstring = docstring
        self.parent = parent

    def __repr__(self) -> str:
        return f"Symbol({self.kind}:{self.name} L{self.start_line}-{self.end_line})"


class SymbolExtractor:
    """Extract symbols from source code using Tree-sitter.
    
    Supports multiple languages via language-specific query files.
    """

    def __init__(self, queries_dir: Path | None = None):
        """Initialize symbol extractor.
        
        Args:
            queries_dir: Directory containing .scm query files.
                        Defaults to contextual/indexing/queries/
        """
        if queries_dir is None:
            # Default to queries/ subdirectory next to this file
            queries_dir = Path(__file__).parent / "queries"

        self.queries_dir = queries_dir
        self._query_cache: dict[Language, str] = {}
        self._parser_cache: dict[Language, any] = {}

    def extract_symbols(
        self,
        source_code: str,
        language: Language,
        file_path: str | None = None,
    ) -> list[Symbol]:
        """Extract symbols from source code.
        
        Args:
            source_code: Source code text.
            language: Programming language.
            file_path: Optional file path for error context.
            
        Returns:
            List of extracted symbols.
            
        Raises:
            IndexingError: If parsing or extraction fails.
        """
        try:
            # Get parser for language
            parser = self._get_parser(language)

            # Parse source code
            tree = parser.parse(bytes(source_code, "utf8"))

            # Extract symbols using language-specific logic
            symbols = self._extract_symbols_from_tree(
                tree.root_node,
                language,
                source_code,
            )

            logger.debug(
                "Symbols extracted",
                language=language.value,
                count=len(symbols),
                file=file_path,
            )

            return symbols

        except Exception as e:
            msg = f"Failed to extract symbols: {e}"
            raise IndexingError(
                message=msg,
                code=ErrorCode.INDEXING_PARSE_FAILED,
                context={"language": language.value, "file": file_path},
            ) from e

    def _get_parser(self, language: Language):
        """Get or create Tree-sitter parser for language."""
        if language in self._parser_cache:
            return self._parser_cache[language]

        try:
            ts_lang_name = LANGUAGE_MAPPING.get(language)
            if not ts_lang_name:
                raise ValueError(f"No Tree-sitter mapping for {language}")

            parser = get_parser(ts_lang_name)
            self._parser_cache[language] = parser
            return parser

        except Exception as e:
            msg = f"Failed to get parser for {language}: {e}"
            raise IndexingError(
                message=msg,
                code=ErrorCode.INDEXING_PARSE_FAILED,
                context={"language": language.value},
            ) from e

    def _extract_symbols_from_tree(
        self,
        root_node: Node,
        language: Language,
        source_code: str,
    ) -> list[Symbol]:
        """Extract symbols from parsed syntax tree.
        
        Uses language-specific extraction logic.
        """
        if language == Language.PYTHON:
            return self._extract_python_symbols(root_node, source_code)
        if language in (Language.TYPESCRIPT, Language.TSX, Language.JAVASCRIPT):
            return self._extract_ts_js_symbols(root_node, source_code, language)
        if language == Language.RUST:
            return self._extract_rust_symbols(root_node, source_code)
        if language == Language.GO:
            return self._extract_go_symbols(root_node, source_code)
        # Fallback: extract basic symbols
        return self._extract_generic_symbols(root_node, source_code)

    def _extract_python_symbols(self, root: Node, source: str) -> list[Symbol]:
        """Extract Python functions, classes, methods."""
        symbols = []

        def visit(node: Node, parent_class: str | None = None):
            # Function definition
            if node.type == "function_definition":
                name_node = node.child_by_field_name("name")
                if name_node:
                    name = source[name_node.start_byte:name_node.end_byte]

                    # Get signature
                    params_node = node.child_by_field_name("parameters")
                    signature = None
                    if params_node:
                        sig_text = source[params_node.start_byte:params_node.end_byte]
                        signature = f"{name}{sig_text}"

                    # Get docstring
                    docstring = self._extract_python_docstring(node, source)

                    # Determine kind
                    kind = "method" if parent_class else "function"

                    symbols.append(Symbol(
                        name=name,
                        kind=kind,
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1,
                        signature=signature,
                        docstring=docstring,
                        parent=parent_class,
                    ))

            # Class definition
            elif node.type == "class_definition":
                name_node = node.child_by_field_name("name")
                if name_node:
                    name = source[name_node.start_byte:name_node.end_byte]

                    # Get docstring
                    docstring = self._extract_python_docstring(node, source)

                    symbols.append(Symbol(
                        name=name,
                        kind="class",
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1,
                        docstring=docstring,
                    ))

                    # Visit methods inside class
                    body_node = node.child_by_field_name("body")
                    if body_node:
                        for child in body_node.children:
                            visit(child, parent_class=name)
                    return  # Don't recurse further

            # Recurse
            for child in node.children:
                visit(child, parent_class)

        visit(root)
        return symbols

    def _extract_python_docstring(self, node: Node, source: str) -> str | None:
        """Extract Python docstring from function/class."""
        # Find body
        body = node.child_by_field_name("body")
        if not body:
            return None

        # First statement in body
        for child in body.children:
            if child.type == "expression_statement":
                expr = child.children[0] if child.children else None
                if expr and expr.type == "string":
                    docstring = source[expr.start_byte:expr.end_byte]
                    # Remove quotes
                    docstring = docstring.strip('"""').strip("'''").strip('"').strip("'")
                    return docstring.strip()

        return None

    def _extract_ts_js_symbols(self, root: Node, source: str, language: Language) -> list[Symbol]:
        """Extract TypeScript/JavaScript functions, classes, interfaces."""
        symbols = []

        def visit(node: Node, parent_class: str | None = None):
            # Function/arrow function
            if node.type in ("function_declaration", "method_definition", "arrow_function"):
                name_node = node.child_by_field_name("name")
                if name_node:
                    name = source[name_node.start_byte:name_node.end_byte]
                else:
                    # Anonymous function
                    name = "<anonymous>"

                kind = "method" if parent_class or node.type == "method_definition" else "function"

                symbols.append(Symbol(
                    name=name,
                    kind=kind,
                    start_line=node.start_point[0] + 1,
                    end_line=node.end_point[0] + 1,
                    parent=parent_class,
                ))

            # Class declaration
            elif node.type == "class_declaration":
                name_node = node.child_by_field_name("name")
                if name_node:
                    name = source[name_node.start_byte:name_node.end_byte]

                    symbols.append(Symbol(
                        name=name,
                        kind="class",
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1,
                    ))

                    # Visit class body
                    body = node.child_by_field_name("body")
                    if body:
                        for child in body.children:
                            visit(child, parent_class=name)
                    return

            # Interface (TypeScript)
            elif node.type == "interface_declaration" and language in (Language.TYPESCRIPT, Language.TSX):
                name_node = node.child_by_field_name("name")
                if name_node:
                    name = source[name_node.start_byte:name_node.end_byte]

                    symbols.append(Symbol(
                        name=name,
                        kind="interface",
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1,
                    ))

            # Recurse
            for child in node.children:
                visit(child, parent_class)

        visit(root)
        return symbols

    def _extract_rust_symbols(self, root: Node, source: str) -> list[Symbol]:
        """Extract Rust functions, structs, traits, impls."""
        symbols = []

        def visit(node: Node):
            if node.type == "function_item":
                name_node = node.child_by_field_name("name")
                if name_node:
                    name = source[name_node.start_byte:name_node.end_byte]
                    symbols.append(Symbol(
                        name=name,
                        kind="function",
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1,
                    ))

            elif node.type == "struct_item":
                name_node = node.child_by_field_name("name")
                if name_node:
                    name = source[name_node.start_byte:name_node.end_byte]
                    symbols.append(Symbol(
                        name=name,
                        kind="struct",
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1,
                    ))

            elif node.type == "trait_item":
                name_node = node.child_by_field_name("name")
                if name_node:
                    name = source[name_node.start_byte:name_node.end_byte]
                    symbols.append(Symbol(
                        name=name,
                        kind="trait",
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1,
                    ))

            for child in node.children:
                visit(child)

        visit(root)
        return symbols

    def _extract_go_symbols(self, root: Node, source: str) -> list[Symbol]:
        """Extract Go functions, structs, interfaces."""
        symbols = []

        def visit(node: Node):
            if node.type == "function_declaration":
                name_node = node.child_by_field_name("name")
                if name_node:
                    name = source[name_node.start_byte:name_node.end_byte]
                    symbols.append(Symbol(
                        name=name,
                        kind="function",
                        start_line=node.start_point[0] + 1,
                        end_line=node.end_point[0] + 1,
                    ))

            elif node.type == "type_declaration":
                # Extract struct/interface name
                spec = node.child_by_field_name("type")
                if spec and spec.type == "type_spec":
                    name_node = spec.child_by_field_name("name")
                    type_node = spec.child_by_field_name("type")
                    if name_node and type_node:
                        name = source[name_node.start_byte:name_node.end_byte]
                        kind = "struct" if type_node.type == "struct_type" else "interface"
                        symbols.append(Symbol(
                            name=name,
                            kind=kind,
                            start_line=node.start_point[0] + 1,
                            end_line=node.end_point[0] + 1,
                        ))

            for child in node.children:
                visit(child)

        visit(root)
        return symbols

    def _extract_generic_symbols(self, root: Node, source: str) -> list[Symbol]:
        """Generic symbol extraction for unsupported languages."""
        # Return empty for now
        return []


# Factory function
def create_symbol_extractor(queries_dir: Path | None = None) -> SymbolExtractor:
    """Create symbol extractor instance."""
    return SymbolExtractor(queries_dir=queries_dir)
