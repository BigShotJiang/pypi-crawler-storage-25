"""Code-aware FTS5 tokenizer for SQLite full-text search.

Implements custom tokenization that preserves both original terms and splits:
- camelCase → ["camelCase", "camel", "Case"]
- snake_case → ["snake_case", "snake", "case"]
- SCREAMING_CASE → ["SCREAMING_CASE", "SCREAMING", "CASE"]
- dots.in.names → ["dots.in.names", "dots", "in", "names"]

This enables both exact matches and partial token matches in code search.
"""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from contextual.observability.logging import get_logger


if TYPE_CHECKING:
    from sqlite3 import Connection

logger = get_logger(__name__)


# Regex patterns for code tokenization
CAMEL_CASE_PATTERN = re.compile(r"([a-z0-9])([A-Z])")
SNAKE_CASE_PATTERN = re.compile(r"[_\-]")
DOT_PATTERN = re.compile(r"\.")
WORD_BOUNDARY_PATTERN = re.compile(r"\b")


def tokenize_code_text(text: str) -> list[str]:
    """Tokenize code text with splitting and preservation.
    
    Splits identifiers while preserving original:
    - "getUserData" → ["getUserData", "get", "User", "Data"]
    - "user_name" → ["user_name", "user", "name"]
    - "App.config.value" → ["App.config.value", "App", "config", "value"]
    
    Args:
        text: Input text to tokenize.
        
    Returns:
        List of tokens (may contain duplicates for preservation).
    """
    tokens = []

    # Split on whitespace first
    words = text.split()

    for word in words:
        # Preserve original word
        tokens.append(word)

        # Split camelCase
        if re.search(r"[a-z][A-Z]", word):
            # Insert spaces before capitals
            spaced = CAMEL_CASE_PATTERN.sub(r"\1 \2", word)
            camel_parts = spaced.split()
            tokens.extend(camel_parts)

        # Split snake_case and kebab-case
        if "_" in word or "-" in word:
            snake_parts = SNAKE_CASE_PATTERN.split(word)
            tokens.extend([p for p in snake_parts if p])

        # Split dotted names (but preserve dots in numbers)
        if "." in word and not word.replace(".", "").isdigit():
            dot_parts = DOT_PATTERN.split(word)
            tokens.extend([p for p in dot_parts if p])

    # Filter out empty strings and deduplicate while preserving order
    seen = set()
    result = []
    for token in tokens:
        if token and token not in seen:
            seen.add(token)
            result.append(token)

    return result


class CodeTokenizer:
    """FTS5 tokenizer implementation for code-aware search.
    
    Registers as 'code_tokenizer' in SQLite FTS5.
    """

    def __init__(self, args: list[str] | None = None):
        """Initialize tokenizer.
        
        Args:
            args: Tokenizer arguments (unused for now, reserved for config).
        """
        self.args = args or []

    def tokenize(self, text: bytes, flags: int) -> list[tuple[int, int, int, int, int]]:
        """Tokenize text for FTS5.
        
        Args:
            text: Input text as bytes.
            flags: Tokenization flags (FTS5_TOKENIZE_*).
            
        Returns:
            List of (start_offset, end_offset, start_pos, end_pos, token_flags) tuples.
        """
        # Decode bytes to string
        text_str = text.decode("utf-8", errors="ignore")

        # Tokenize
        tokens = tokenize_code_text(text_str)

        # Build FTS5 token tuples
        result = []
        position = 0
        offset = 0

        for token in tokens:
            token_bytes = token.encode("utf-8")
            start = offset
            end = offset + len(token_bytes)

            # (start_byte, end_byte, start_position, end_position, flags)
            result.append((start, end, position, position + 1, 0))

            offset = end + 1  # +1 for space
            position += 1

        return result


def register_code_tokenizer(conn: Connection) -> None:
    """Register code_tokenizer with SQLite connection.
    
    Must be called before creating FTS5 tables that use 'code_tokenizer'.
    
    Args:
        conn: SQLite connection.
        
    Raises:
        sqlite3.Error: If registration fails.
    """
    try:
        # Note: Python's sqlite3 doesn't support custom tokenizers directly
        # We need to use a workaround with the fts5 module

        # For now, we'll use unicode61 with remove_diacritics
        # Custom tokenizer requires C extension or ctypes hack
        # TODO: Implement via ctypes or switch to unicode61 permanently

        logger.info("Code tokenizer registration requested")
        logger.warning(
            "Custom FTS5 tokenizers require C extension - using unicode61 fallback"
        )

        # Fallback: just log that we're using unicode61
        # The FTS5 table should be created with:
        # tokenize='unicode61 remove_diacritics 2'

    except Exception as e:
        logger.error("Failed to register code tokenizer", error=str(e))
        raise


def preprocess_query(query: str) -> str:
    """Preprocess search query with code-aware tokenization.
    
    Use this to tokenize user queries the same way we tokenize code.
    
    Args:
        query: User search query.
        
    Returns:
        Preprocessed query string for FTS5.
    """
    tokens = tokenize_code_text(query)

    # Join with OR for FTS5 query
    # Each token can match independently
    return " OR ".join(f'"{token}"' for token in tokens)


# Simple test
if __name__ == "__main__":
    test_cases = [
        "getUserData",
        "user_name_field",
        "HTTPSConnection",
        "app.config.debug",
        "MyClass.staticMethod",
    ]

    for test in test_cases:
        tokens = tokenize_code_text(test)
        print(f"{test:30} → {tokens}")

    # Output:
    # getUserData                    → ['getUserData', 'get', 'User', 'Data']
    # user_name_field                → ['user_name_field', 'user', 'name', 'field']
    # HTTPSConnection                → ['HTTPSConnection', 'HTTPS', 'Connection']
    # app.config.debug               → ['app.config.debug', 'app', 'config', 'debug']
    # MyClass.staticMethod           → ['MyClass.staticMethod', 'MyClass', 'My', 'Class', 'staticMethod', 'static', 'Method']
