"""Full indexing pipeline orchestrator.

Coordinates file discovery, chunking, symbol extraction, embedding, and DB writing
for complete repository indexing.
"""

from __future__ import annotations

import time
from pathlib import Path
from typing import Any

from contextual.core.errors import ErrorCode, IndexingError
from contextual.core.models import Language
from contextual.indexing.chunker import chunk_file, detect_language
from contextual.indexing.embedder import get_embedder
from contextual.indexing.index_writer import IndexWriter
from contextual.indexing.processor import FileProcessor
from contextual.indexing.symbol_extractor import SymbolExtractor
from contextual.observability.logging import get_logger
from contextual.storage.sqlite_pool import SQLitePool


logger = get_logger(__name__)


class IndexingPipeline:
    """Full indexing pipeline for code repositories.
    
    Orchestrates:
    1. File discovery (respects .gitignore)
    2. Chunking (AST-aware)
    3. Symbol extraction (functions, classes, methods)
    4. Embedding generation (fastembed/Jina)
    5. Database writes (transactional)
    """

    def __init__(self, repo_root: Path, db_pool: SQLitePool):
        """Initialize pipeline.
        
        Args:
            repo_root: Repository root directory.
            db_pool: SQLite connection pool.
        """
        self.repo_root = repo_root.resolve()
        self.db_pool = db_pool

        # Initialize components
        self.file_processor = FileProcessor(self.repo_root)
        self.symbol_extractor = SymbolExtractor()
        self.embedder = get_embedder()

        logger.info(
            "Indexing pipeline initialized",
            repo_root=str(self.repo_root),
        )

    def index_repository(self, file_paths: list[Path] | None = None) -> dict[str, int]:
        """Index entire repository or specific files.
        
        Args:
            file_paths: Specific files to index, or None for full repo.
            
        Returns:
            Stats dict: {files: N, chunks: M, symbols: K, embeddings: M, duration_ms: T}
            
        Raises:
            IndexingError: If indexing fails.
        """
        start_time = time.time()

        try:
            # Discover files if not provided
            if file_paths is None:
                logger.info("Discovering files in repository")
                file_paths = self.file_processor.discover_files()
                logger.info(f"Found {len(file_paths)} indexable files")

            if not file_paths:
                logger.warning("No files to index")
                return {
                    "files": 0,
                    "chunks": 0,
                    "symbols": 0,
                    "embeddings": 0,
                    "duration_ms": 0,
                }

            # Process files with writer context
            total_stats = {
                "files": 0,
                "chunks": 0,
                "symbols": 0,
                "embeddings": 0,
            }

            with self.db_pool.writer() as writer_conn:
                index_writer = IndexWriter(writer_conn)

                for file_path in file_paths:
                    try:
                        stats = self._index_file(file_path, index_writer)

                        # Accumulate stats
                        for key in total_stats:
                            total_stats[key] += stats.get(key, 0)

                    except Exception as e:
                        logger.error(
                            "Failed to index file",
                            path=str(file_path),
                            error=str(e),
                        )
                        # Continue with other files
                        continue

                # Update indexing state
                index_writer.update_indexing_state(
                    repo_root=str(self.repo_root),
                    total_files=total_stats["files"],
                    total_chunks=total_stats["chunks"],
                    total_symbols=total_stats["symbols"],
                    full_index=True,
                )

            duration_ms = int((time.time() - start_time) * 1000)
            total_stats["duration_ms"] = duration_ms

            logger.info(
                "Repository indexing complete",
                **total_stats,
            )

            return total_stats

        except Exception as e:
            msg = f"Repository indexing failed: {e}"
            raise IndexingError(
                message=msg,
                code=ErrorCode.INDEXING_FILE_READ_FAILED,
                context={"repo_root": str(self.repo_root)},
            ) from e

    def _index_file(self, file_path: Path, index_writer: IndexWriter) -> dict[str, int]:
        """Index a single file through full pipeline.
        
        Args:
            file_path: Absolute path to file.
            index_writer: Database writer.
            
        Returns:
            Stats dict for this file.
        """
        # Read file content
        try:
            content = file_path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            # Try with latin-1 fallback
            try:
                content = file_path.read_text(encoding="latin-1")
                logger.warning(
                    "File decoded with latin-1 fallback",
                    path=str(file_path),
                )
            except Exception as e:
                logger.error(
                    "Failed to read file",
                    path=str(file_path),
                    error=str(e),
                )
                return {"files": 0, "chunks": 0, "symbols": 0, "embeddings": 0}

        # Get relative path from repo root - use resolve() for consistent comparison
        try:
            rel_path = str(file_path.resolve().relative_to(self.repo_root.resolve()))
        except ValueError:
            rel_path = str(file_path)

        # Detect language
        language = detect_language(file_path)
        if not language:
            logger.debug("Unsupported file type", path=str(file_path))
            return {"files": 0, "chunks": 0, "symbols": 0, "embeddings": 0}

        # Chunk file
        try:
            content_bytes = content.encode("utf-8")
            chunks = chunk_file(file_path, content_bytes, language)
        except Exception as e:
            logger.error(
                "Failed to chunk file",
                path=str(file_path),
                error=str(e),
            )
            return {"files": 0, "chunks": 0, "symbols": 0, "embeddings": 0}

        if not chunks:
            logger.debug("No chunks generated", path=str(file_path))
            return {"files": 0, "chunks": 0, "symbols": 0, "embeddings": 0}

        # Detect language from first chunk
        language = chunks[0].language.value if chunks[0].language else "unknown"

        # Extract symbols
        symbols = []
        try:
            # Map string language to Language enum
            lang_map = {
                "python": Language.PYTHON,
                "typescript": Language.TYPESCRIPT,
                "javascript": Language.JAVASCRIPT,
                "tsx": Language.TSX,
                "rust": Language.RUST,
                "go": Language.GO,
            }

            lang_enum = lang_map.get(language)
            if lang_enum:
                symbols = self.symbol_extractor.extract_symbols(
                    content,
                    lang_enum,
                    file_path=str(file_path),
                )
        except Exception as e:
            logger.warning(
                "Symbol extraction failed",
                path=str(file_path),
                error=str(e),
            )
            # Continue without symbols
            symbols = []

        # Get file mtime
        mtime = int(file_path.stat().st_mtime)

        # Write to database
        stats = index_writer.index_file(
            file_path=rel_path,
            language=language,
            content=content,
            chunks=chunks,
            symbols=symbols,
            mtime=mtime,
        )

        return stats

    def index_single_file(self, file_path: Path) -> dict[str, int]:
        """Index a single file (for incremental updates).
        
        Args:
            file_path: Absolute path to file to index.
            
        Returns:
            Stats dict: {files: 1, chunks: N, symbols: M, embeddings: N}
        """
        from contextual.indexing.chunker import chunk_file, detect_language
        from contextual.indexing.index_writer import IndexWriter
        
        # Get relative path
        try:
            rel_path = file_path.resolve().relative_to(self.repo_root.resolve())
        except ValueError:
            logger.error(
                "File outside repo root",
                file_path=str(file_path),
                repo_root=str(self.repo_root),
            )
            return {"files": 0, "chunks": 0, "symbols": 0, "embeddings": 0}
        
        # Check if file exists
        if not file_path.exists():
            logger.warning("File not found", path=str(file_path))
            return {"files": 0, "chunks": 0, "symbols": 0, "embeddings": 0}
        
        # Detect language
        language = detect_language(file_path)
        if not language:
            logger.debug("Unsupported file type", path=str(file_path))
            return {"files": 0, "chunks": 0, "symbols": 0, "embeddings": 0}
        
        # Read file content
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
        except Exception as e:
            logger.error("Failed to read file", path=str(file_path), error=str(e))
            return {"files": 0, "chunks": 0, "symbols": 0, "embeddings": 0}
        
        # Chunk file
        content_bytes = content.encode("utf-8")
        chunks = chunk_file(file_path, content_bytes, language)
        if not chunks:
            logger.debug("No chunks generated", path=str(file_path))
            return {"files": 0, "chunks": 0, "symbols": 0, "embeddings": 0}
        
        # Extract symbols
        symbols = self.symbol_extractor.extract_symbols(content, language, file_path)
        
        # Get file mtime
        mtime = int(file_path.stat().st_mtime * 1000)
        
        # Write to database
        with self.db_pool.writer() as writer_conn:
            index_writer = IndexWriter(writer_conn)
            stats = index_writer.index_file(
                file_path=str(rel_path),
                language=language.value,
                content=content,
                chunks=chunks,
                symbols=symbols,
                mtime=mtime,
            )

        logger.info(
            "File indexed",
            path=str(rel_path),
            chunks=stats.get("chunks", 0),
            symbols=stats.get("symbols", 0),
        )

        return stats

    def delete_file(self, file_path: Path) -> int:
        """Delete file from index.
        
        Args:
            file_path: Absolute path to file to delete.
            
        Returns:
            Number of chunks deleted.
        """
        # Get relative path
        try:
            rel_path = str(file_path.resolve().relative_to(self.repo_root.resolve()))
        except ValueError:
            logger.error(
                "File outside repo root",
                file_path=str(file_path),
                repo_root=str(self.repo_root),
            )
            return 0
        
        # Delete from database
        with self.db_pool.writer() as writer_conn:
            cursor = writer_conn.cursor()
            
            # Get file_id
            cursor.execute("SELECT id FROM files WHERE path = ?", (rel_path,))
            result = cursor.fetchone()
            
            if not result:
                logger.debug("File not in index", path=str(rel_path))
                return 0
            
            file_id = result[0]
            
            # Count chunks before deletion (for logging)
            cursor.execute("SELECT COUNT(*) FROM chunks WHERE file_id = ?", (file_id,))
            chunk_count = cursor.fetchone()[0]
            
            # Get chunk IDs for FTS5 cleanup
            cursor.execute("SELECT id FROM chunks WHERE file_id = ?", (file_id,))
            chunk_ids = [row[0] for row in cursor.fetchall()]
            
            # Delete from FTS5 (manual sync)
            for chunk_id in chunk_ids:
                try:
                    cursor.execute("DELETE FROM fts_chunks WHERE chunk_id = ?", (chunk_id,))
                except Exception as e:
                    logger.warning(
                        "Failed to delete from FTS5",
                        chunk_id=chunk_id,
                        error=str(e),
                    )
            
            # Delete from vec_chunks (if exists)
            try:
                for chunk_id in chunk_ids:
                    cursor.execute("DELETE FROM vec_chunks WHERE chunk_id = ?", (chunk_id,))
            except Exception as e:
                logger.warning(
                    "Failed to delete from vec_chunks",
                    error=str(e),
                )
            
            # Delete file (cascades to chunks and symbols)
            cursor.execute("DELETE FROM files WHERE id = ?", (file_id,))
            
            writer_conn.commit()

        logger.info(
            "File deleted from index",
            path=str(rel_path),
            chunks_deleted=chunk_count,
        )

        return chunk_count

    def get_stats(self) -> dict[str, Any]:
        """Get current indexing statistics.
        
        Returns:
            Stats dict with file/chunk/symbol counts.
        """
        with self.db_pool.reader() as reader_conn:
            cursor = reader_conn.cursor()

            # Count files
            cursor.execute("SELECT COUNT(*) FROM files")
            file_count = cursor.fetchone()[0]

            # Count chunks
            cursor.execute("SELECT COUNT(*) FROM chunks")
            chunk_count = cursor.fetchone()[0]

            # Count symbols
            cursor.execute("SELECT COUNT(*) FROM code_symbols")
            symbol_count = cursor.fetchone()[0]

            # Get indexing state
            cursor.execute(
                "SELECT last_full_index_at, last_incremental_at FROM indexing_state WHERE repo_root = ?",
                (str(self.repo_root),)
            )
            state_row = cursor.fetchone()

            last_full = state_row[0] if state_row else None
            last_incremental = state_row[1] if state_row else None

        return {
            "files": file_count,
            "chunks": chunk_count,
            "symbols": symbol_count,
            "last_full_index_at": last_full,
            "last_incremental_at": last_incremental,
            "repo_root": str(self.repo_root),
        }
