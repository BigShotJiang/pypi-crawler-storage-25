"""Indexing module - Tree-sitter AST chunking and file discovery.

Public API:
- chunk_file: Chunk a single file using tree-sitter
- detect_language: Detect programming language from file extension
- index_project: Index an entire project directory
- FileProcessor: File discovery orchestrator
"""
from __future__ import annotations

from contextual.indexing.chunker import chunk_file, detect_language
from contextual.indexing.processor import FileProcessor, index_project


__all__ = [
    "FileProcessor",
    "chunk_file",
    "detect_language",
    "index_project",
]
