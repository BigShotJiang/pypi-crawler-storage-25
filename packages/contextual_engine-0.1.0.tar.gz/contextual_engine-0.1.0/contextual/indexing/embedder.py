"""Embedding provider abstraction using fastembed/Jina.

Provides a simple interface for the indexing pipeline while delegating
to contextual.embedding.CodeEmbedder for actual embedding generation.

Key features:
- Singleton pattern for shared embedder instance
- Batch processing support
- 768-dimensional embeddings (jina-v2-code)
- Content-hash caching handled by CodeEmbedder layer
"""

from __future__ import annotations

from typing import Protocol

from contextual.embedding.embedder import CodeEmbedder
from contextual.observability.logging import get_logger


logger = get_logger(__name__)


class EmbeddingProvider(Protocol):
    """Protocol for embedding providers.
    
    Defines interface that all embedding implementations must follow.
    """

    def embed(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for batch of texts.
        
        Args:
            texts: List of text strings to embed.
            
        Returns:
            List of embedding vectors (same order as input).
            
        Raises:
            Exception: If embedding generation fails.
        """
        ...

    def embed_batch(
        self,
        texts: list[str],
        batch_size: int = 64,
    ) -> list[list[float]]:
        """Embed large list of texts in batches.
        
        Args:
            texts: List of texts to embed.
            batch_size: Number of texts per batch.
            
        Returns:
            List of embedding vectors (same order as input).
        """
        ...

    @property
    def dimension(self) -> int:
        """Embedding dimension for this provider."""
        ...

    @property
    def model_name(self) -> str:
        """Model identifier."""
        ...


class JinaEmbedder:
    """Jina embedding provider via fastembed.
    
    Wraps contextual.embedding.CodeEmbedder to provide a consistent
    interface for the indexing pipeline.
    
    Uses jina-embeddings-v2-base-code model (768-dim) optimized for code.
    Content-hash caching is handled by the underlying CodeEmbedder.
    
    Attributes:
        dimension: 768 (fixed for jina-v2-code)
        model_name: "jina-v2-code"
    """

    def __init__(self):
        """Initialize Jina embedder.
        
        Creates underlying CodeEmbedder instance which handles:
        - Model loading (fastembed with jina-v2-code)
        - Content-hash caching (SQLite-backed)
        - Batch processing optimization
        """
        self._embedder = CodeEmbedder()
        self._dimension = 768
        self._model_name = "jina-v2-code"

        logger.info(
            "JinaEmbedder initialized",
            model=self._model_name,
            dimension=self._dimension,
            provider="fastembed",
        )

    @property
    def dimension(self) -> int:
        """Embedding dimension (768 for jina-v2-code)."""
        return self._dimension

    @property
    def model_name(self) -> str:
        """Model identifier."""
        return self._model_name

    def embed(self, texts: list[str]) -> list[list[float]]:
        """Generate embeddings for batch of texts.
        
        Delegates to CodeEmbedder.embed() which handles:
        - Content-hash based caching
        - Batch processing (64 texts per batch)
        - Model inference via fastembed
        
        Args:
            texts: List of text strings to embed.
            
        Returns:
            List of 768-dim embedding vectors (same order as input).
            
        Raises:
            Exception: If embedding generation fails.
        """
        if not texts:
            return []

        # CodeEmbedder.embed() handles caching and batching internally
        embeddings = self._embedder.embed(texts)

        # Validate output
        if len(embeddings) != len(texts):
            raise ValueError(
                f"Embedding count mismatch: got {len(embeddings)}, expected {len(texts)}"
            )

        # Validate dimensions
        for i, embedding in enumerate(embeddings):
            if len(embedding) != self._dimension:
                raise ValueError(
                    f"Invalid embedding dimension at index {i}: "
                    f"got {len(embedding)}, expected {self._dimension}"
                )

        logger.debug(
            "Embeddings generated",
            count=len(texts),
            model=self._model_name,
        )

        return embeddings

    def embed_batch(
        self,
        texts: list[str],
        batch_size: int = 64,
    ) -> list[list[float]]:
        """Embed large list of texts in batches.
        
        Note: CodeEmbedder already handles batching internally,
        so this is essentially a pass-through. Kept for interface
        compatibility with previous NomicEmbedder.
        
        Args:
            texts: List of texts to embed.
            batch_size: Number of texts per batch (passed to CodeEmbedder).
            
        Returns:
            List of embedding vectors (same order as input).
            
        Raises:
            Exception: If any batch fails.
        """
        if not texts:
            return []

        # CodeEmbedder handles batching, but we respect the batch_size hint
        all_embeddings = []

        for i in range(0, len(texts), batch_size):
            batch = texts[i:i + batch_size]
            batch_embeddings = self.embed(batch)
            all_embeddings.extend(batch_embeddings)

            logger.debug(
                "Batch processed",
                batch_num=i // batch_size + 1,
                batch_size=len(batch),
                total_batches=(len(texts) + batch_size - 1) // batch_size,
            )

        return all_embeddings

    def clear_cache(self) -> None:
        """Clear the embedding cache.
        
        Delegates to underlying CodeEmbedder's cache clearing.
        """
        # CodeEmbedder uses external SQLite cache, not in-memory
        # Cache clearing would need to be implemented at the cache layer
        logger.warning(
            "Cache clearing not implemented - cache is persistent SQLite",
            hint="Use contextual.embedding.cache.EmbeddingCache.clear() if needed",
        )


# Factory function for creating embedder instances
def create_embedder(**kwargs) -> EmbeddingProvider:
    """Create embedding provider instance.
    
    Args:
        **kwargs: Reserved for future extensibility (currently ignored).
        
    Returns:
        JinaEmbedder instance.
        
    Note:
        Previous versions supported a 'provider' parameter for switching
        between Nomic/Jina. Now we only support Jina (fastembed).
    """
    # Ignore kwargs for now - only one provider (Jina)
    if kwargs:
        logger.warning(
            "create_embedder() kwargs ignored",
            kwargs=list(kwargs.keys()),
            hint="Only Jina provider supported",
        )

    return JinaEmbedder()


# Module-level singleton instance (lazy initialized)
_default_embedder: JinaEmbedder | None = None


def get_embedder() -> JinaEmbedder:
    """Get or create default embedder instance.
    
    Uses singleton pattern to share embedder instance across
    indexing pipeline. The underlying CodeEmbedder also uses
    a singleton, so this creates a single shared model instance.
    
    Returns:
        Singleton JinaEmbedder instance.
    """
    global _default_embedder
    if _default_embedder is None:
        _default_embedder = JinaEmbedder()
        logger.info(
            "Default embedder initialized",
            type="JinaEmbedder",
            singleton=True,
        )
    return _default_embedder


def reset_embedder() -> None:
    """Reset singleton embedder instance.
    
    Useful for testing or forcing re-initialization.
    Not typically needed in production.
    """
    global _default_embedder
    _default_embedder = None
    logger.info("Default embedder reset")
