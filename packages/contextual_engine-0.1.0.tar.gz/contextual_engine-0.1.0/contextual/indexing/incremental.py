"""Incremental indexing with smart change detection.

Handles file modifications, additions, deletions, and renames efficiently
using content-hash comparison and mtime checks.
"""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import TYPE_CHECKING

from contextual.indexing.index_writer import IndexWriter
from contextual.observability.logging import get_logger


if TYPE_CHECKING:
    from contextual.indexing.pipeline import IndexingPipeline

logger = get_logger(__name__)


def compute_file_hash(file_path: Path) -> str:
    """Compute SHA-256 hash of file content.
    
    Args:
        file_path: Path to file.
        
    Returns:
        Hex digest of file hash.
    """
    sha256 = hashlib.sha256()

    try:
        with open(file_path, "rb") as f:
            # Read in chunks to handle large files
            for chunk in iter(lambda: f.read(65536), b""):
                sha256.update(chunk)
        return sha256.hexdigest()
    except Exception as e:
        logger.error(
            "Failed to compute file hash",
            path=str(file_path),
            error=str(e),
        )
        # Return empty string to force re-index
        return ""


class IncrementalIndexer:
    """Handles incremental indexing of changed files.
    
    Detects changes via:
    1. Content hash comparison (primary)
    2. Modification time check (secondary)
    3. File existence check
    """

    def __init__(self, pipeline: IndexingPipeline):
        """Initialize incremental indexer.
        
        Args:
            pipeline: Indexing pipeline instance.
        """
        self.pipeline = pipeline
        self.repo_root = pipeline.repo_root
        self.db_pool = pipeline.db_pool

    def handle_file_change(self, file_path: Path) -> dict[str, int]:
        """Handle file modification or creation.
        
        Checks if file actually changed before re-indexing.
        
        Args:
            file_path: Absolute path to changed file.
            
        Returns:
            Stats dict from indexing.
        """
        # Get relative path
        try:
            rel_path = str(file_path.resolve().relative_to(self.repo_root.resolve()))
        except ValueError:
            logger.warning(
                "File outside repo root",
                path=str(file_path),
                repo_root=str(self.repo_root),
            )
            return {"files": 0, "chunks": 0, "symbols": 0, "embeddings": 0}

        # Check if file exists
        if not file_path.exists():
            logger.debug("File no longer exists", path=str(file_path))
            return self.handle_file_deletion(file_path)

        # Compute current file hash
        current_hash = compute_file_hash(file_path)

        # Check existing file hash in DB
        with self.db_pool.reader() as reader_conn:
            cursor = reader_conn.cursor()
            cursor.execute(
                "SELECT content_hash, mtime FROM files WHERE path = ?",
                (rel_path,)
            )
            existing = cursor.fetchone()

        if existing:
            existing_hash, existing_mtime = existing
            current_mtime = int(file_path.stat().st_mtime)

            # Check if content unchanged
            if existing_hash == current_hash:
                logger.debug(
                    "File content unchanged (hash match)",
                    path=str(file_path),
                    hash=current_hash[:8],
                )

                # Update mtime if changed (file was touched)
                if current_mtime != existing_mtime:
                    with self.db_pool.writer() as writer_conn:
                        cursor = writer_conn.cursor()
                        cursor.execute(
                            "UPDATE files SET mtime = ? WHERE path = ?",
                            (current_mtime, rel_path)
                        )
                        writer_conn.commit()

                return {"files": 0, "chunks": 0, "symbols": 0, "embeddings": 0}

        # File is new or changed - re-index
        logger.info(
            "File changed, re-indexing",
            path=str(file_path),
            new=existing is None,
        )

        stats = self.pipeline.index_single_file(file_path)

        return stats

    def handle_file_deletion(self, file_path: Path) -> dict[str, int]:
        """Handle file deletion.
        
        Args:
            file_path: Absolute path to deleted file.
            
        Returns:
            Stats dict with chunks_deleted count.
        """
        logger.info("File deleted", path=str(file_path))

        chunks_deleted = self.pipeline.delete_file(file_path)

        return {
            "files": -1,
            "chunks": -chunks_deleted,
            "symbols": 0,  # Cascade delete handled by DB
            "embeddings": 0,
        }

    def handle_file_rename(
        self,
        old_path: Path,
        new_path: Path,
    ) -> dict[str, int]:
        """Handle file rename/move.
        
        Deletes old entry and creates new one.
        
        Args:
            old_path: Old absolute path.
            new_path: New absolute path.
            
        Returns:
            Combined stats dict.
        """
        logger.info(
            "File renamed",
            old_path=str(old_path),
            new_path=str(new_path),
        )

        # Delete old entry
        delete_stats = self.handle_file_deletion(old_path)

        # Index new entry
        add_stats = self.handle_file_change(new_path)

        # Combine stats
        return {
            "files": delete_stats["files"] + add_stats["files"],
            "chunks": delete_stats["chunks"] + add_stats["chunks"],
            "symbols": delete_stats["symbols"] + add_stats["symbols"],
            "embeddings": delete_stats["embeddings"] + add_stats["embeddings"],
        }

    def update_indexing_state(self, stats: dict[str, int]) -> None:
        """Update incremental indexing state.
        
        Args:
            stats: Stats from incremental indexing.
        """
        # Get current totals from DB
        with self.db_pool.reader() as reader_conn:
            cursor = reader_conn.cursor()

            cursor.execute("SELECT COUNT(*) FROM files")
            total_files = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM chunks")
            total_chunks = cursor.fetchone()[0]

            cursor.execute("SELECT COUNT(*) FROM code_symbols")
            total_symbols = cursor.fetchone()[0]

        # Update state
        with self.db_pool.writer() as writer_conn:
            writer = IndexWriter(writer_conn)
            writer.update_indexing_state(
                repo_root=str(self.repo_root),
                total_files=total_files,
                total_chunks=total_chunks,
                total_symbols=total_symbols,
                full_index=False,  # Incremental
            )

    def should_index_file(self, file_path: Path) -> bool:
        """Check if file should be indexed.
        
        Uses FileProcessor's filtering logic.
        
        Args:
            file_path: Path to check.
            
        Returns:
            True if file should be indexed.
        """
        # Check if file exists
        if not file_path.exists() or not file_path.is_file():
            return False

        # Get relative path
        try:
            rel_path = file_path.resolve().relative_to(self.repo_root.resolve())
        except ValueError:
            return False

        # Check if should skip
        if self.pipeline.file_processor._should_skip(file_path, rel_path):
            return False

        # Check if language supported
        from contextual.indexing.chunker import detect_language
        language = detect_language(file_path)
        if not language:
            return False

        return True
