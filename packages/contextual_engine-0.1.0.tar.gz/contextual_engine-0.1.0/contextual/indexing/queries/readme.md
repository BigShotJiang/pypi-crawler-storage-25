# Tree-sitter Query Files
 
This directory is reserved for Tree-sitter .scm query files for symbol extraction.
 
## Current Status
Symbol extraction is currently implemented via direct AST traversal in `symbol_extractor.py`.
Tree-sitter query files (.scm) are an optional enhancement for more precise extraction.
 
## Planned Files
- python.scm - Python symbol queries
- typescript.scm - TypeScript symbol queries  
- javascript.scm - JavaScript symbol queries
- rust.scm - Rust symbol queries
- go.scm - Go symbol queries
 
## When to Use
.scm query files will be used when:
1. More precise extraction is needed
2. Language-specific edge cases require custom queries
3. Performance optimization is needed
 
For Phase 1, direct AST traversal is sufficient.