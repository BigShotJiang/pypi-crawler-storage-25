"""Index writer for transactional database operations.

Handles atomic writes of files, chunks, embeddings, and symbols to SQLite.
All operations are transactional - either all succeed or all rollback.
"""

from __future__ import annotations

import hashlib
import time
from typing import TYPE_CHECKING

from contextual.core.errors import ErrorCode, StorageError, storage_context
from contextual.indexing.chunker import Chunk
from contextual.indexing.embedder import get_embedder
from contextual.indexing.symbol_extractor import Symbol
from contextual.observability.logging import get_logger


if TYPE_CHECKING:
    from sqlite3 import Connection

logger = get_logger(__name__)


def compute_content_hash(content: str) -> str:
    """Compute SHA-256 hash of content."""
    return hashlib.sha256(content.encode("utf-8")).hexdigest()


class IndexWriter:
    """Transactional writer for indexing operations.
    
    Coordinates writes across multiple tables:
    - files: source file metadata
    - chunks: code chunks
    - code_symbols: extracted symbols
    - vec_chunks: embeddings (if vec0 available)
    - fts_chunks: full-text search (auto-synced via triggers)
    """

    def __init__(self, conn: Connection):
        """Initialize writer.
        
        Args:
            conn: SQLite connection (should be writer connection from pool).
        """
        self.conn = conn
        self.embedder = get_embedder()

    def index_file(
        self,
        file_path: str,
        language: str,
        content: str,
        chunks: list[Chunk],
        symbols: list[Symbol],
        mtime: int,
    ) -> dict[str, int]:
        """Index a single file atomically.
        
        Args:
            file_path: Relative path from repo root.
            language: Programming language.
            content: Full file content.
            chunks: List of code chunks.
            symbols: List of extracted symbols.
            mtime: File modification time (unix timestamp).
            
        Returns:
            Dict with counts: {files: 1, chunks: N, symbols: M, embeddings: N}
            
        Raises:
            StorageError: If any operation fails (all rolled back).
        """
        try:
            cursor = self.conn.cursor()
            now_ms = int(time.time() * 1000)

            # Compute file content hash
            file_hash = compute_content_hash(content)

            # Check if file already exists with same hash
            cursor.execute(
                "SELECT id, content_hash FROM files WHERE path = ?",
                (file_path,)
            )
            existing = cursor.fetchone()

            if existing:
                file_id, existing_hash = existing
                if existing_hash == file_hash:
                    # File unchanged - skip
                    logger.debug(
                        "File unchanged, skipping",

                        hash=file_hash[:8],
                    )
                    return {"files": 0, "chunks": 0, "symbols": 0, "embeddings": 0}

                # File changed - get old chunk IDs for FTS5 cleanup
                cursor.execute("SELECT id FROM chunks WHERE file_id = ?", (file_id,))
                old_chunk_ids = [row[0] for row in cursor.fetchall()]

                # Delete from FTS5 (manual sync)
                for chunk_id in old_chunk_ids:
                    try:
                        cursor.execute("DELETE FROM fts_chunks WHERE chunk_id = ?", (chunk_id,))
                    except Exception as e:
                        logger.warning(
                            "Failed to delete from FTS5",
                            chunk_id=chunk_id,
                            error=str(e),
                        )

                # Delete old chunks and symbols
                cursor.execute("DELETE FROM chunks WHERE file_id = ?", (file_id,))
                cursor.execute(
                    """DELETE FROM code_symbols 
                       WHERE chunk_id IN (SELECT id FROM chunks WHERE file_id = ?)""",
                    (file_id,)
                )

                # Update file record
                cursor.execute(
                    """UPDATE files 
                       SET language = ?, mtime = ?, content_hash = ?, indexed_at = ?
                       WHERE id = ?""",
                    (language, mtime, file_hash, now_ms, file_id)
                )
            else:
                # Insert new file
                cursor.execute(
                    """INSERT INTO files (path, language, mtime, content_hash, indexed_at)
                       VALUES (?, ?, ?, ?, ?)""",
                    (file_path, language, mtime, file_hash, now_ms)
                )
                raw_file_id = cursor.lastrowid
                if raw_file_id is None:
                    raise RuntimeError("Failed to insert file row")
                file_id = raw_file_id

            # Prepare chunk texts for embedding with Anthropic-style Contextual Retrieval breadcrumb prefix
            # Format: [File: path | Symbol: name | Lang: language]\n{body}
            chunk_tuples = []
            for chunk in chunks:
                symbol_part = f" | Symbol: {chunk.symbol_name}" if chunk.symbol_name else ""
                prefix = f"[File: {file_path}{symbol_part} | Lang: {language}]\n"
                embedding_text = prefix + chunk.body
                emb_hash = compute_content_hash(embedding_text)
                chunk_tuples.append((emb_hash, embedding_text))

            # Generate embeddings (batch)
            embeddings = []
            if chunk_tuples:
                try:
                    from contextual.embedding.helpers import embed_chunks
                    cached_results = embed_chunks(self.conn, chunk_tuples)
                    embeddings = [emb for _, emb in cached_results]
                except Exception as e:
                    logger.warning(
                        "Embedding generation failed, continuing without vectors",
                        error=str(e),
                        file=file_path,
                    )
                    embeddings = []

            # Build a list of chunks with their metadata for symbol matching
            chunk_info = []  # List of (chunk_id, start_line, end_line)
            chunk_ids = []

            for chunk in chunks:
                chunk_hash = compute_content_hash(chunk.body)

                # Insert chunk
                cursor.execute(
                    """INSERT INTO chunks 
                       (file_id, file_path, start_line, end_line, symbol_name, symbol_type, 
                        content, content_hash, indexed_at, source_type)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 'code')""",
                    (
                        file_id,
                        file_path,
                        chunk.start_line,
                        chunk.end_line,
                        chunk.symbol_name,
                        chunk.chunk_type.value if chunk.chunk_type else None,
                        chunk.body,
                        chunk_hash,
                        now_ms,
                    )
                )
                chunk_id = cursor.lastrowid
                if chunk_id is None:
                    raise RuntimeError("Failed to insert chunk row")
                
                chunk_ids.append(chunk_id)
                # Store chunk info for symbol matching
                chunk_info.append((chunk_id, chunk.start_line, chunk.end_line))

            # Batch sync to FTS5 (avoiding trigger issues)
            if chunk_ids:
                fts_rows = [
                    (chunk_ids[i], chunks[i].body, file_path, chunks[i].symbol_name, "")
                    for i in range(len(chunks))
                ]
                try:
                    cursor.executemany(
                        "INSERT INTO fts_chunks(rowid, content, file_path, symbol_name, heading_path) VALUES (?, ?, ?, ?, ?)",
                        fts_rows
                    )
                except Exception as e:
                    logger.warning("Failed to sync chunks to FTS5 (batch)", error=str(e))

                # Batch insert embeddings if available
                if embeddings:
                    import json
                    vec_rows = [
                        (chunk_ids[i], json.dumps(embeddings[i]))
                        for i in range(min(len(chunk_ids), len(embeddings)))
                    ]
                    try:
                        cursor.executemany(
                            "INSERT OR REPLACE INTO vec_chunks (chunk_id, embedding) VALUES (?, ?)",
                            vec_rows
                        )
                    except Exception as e:
                        logger.warning("Failed to insert embeddings (batch)", error=str(e))

            # Insert symbols - match to chunks by line number overlap
            symbols_inserted = 0
            for symbol in symbols:
                # Find chunk that contains this symbol based on line numbers
                chunk_id = None
                for cid, start_line, end_line in chunk_info:
                    # Symbol's line range should fall within chunk's line range
                    if start_line <= symbol.start_line <= end_line:
                        chunk_id = cid
                        break

                # If no exact match, use the first chunk (file-level chunk)
                if not chunk_id and chunk_info:
                    chunk_id = chunk_info[0][0]

                if not chunk_id:
                    # No chunks at all - skip symbol
                    logger.debug(
                        "Symbol without any chunks",
                        symbol=symbol.name,
                        kind=symbol.kind,
                    )
                    continue

                cursor.execute(
                    """INSERT OR IGNORE INTO code_symbols
                       (chunk_id, name, kind, signature, docstring)
                       VALUES (?, ?, ?, ?, ?)""",
                    (chunk_id, symbol.name, symbol.kind, symbol.signature, symbol.docstring)
                )
                symbols_inserted += cursor.rowcount

            # Commit transaction
            self.conn.commit()

            logger.info(
                "File indexed",

                chunks=len(chunks),
                symbols=symbols_inserted,
                embeddings=len(embeddings),
            )

            return {
                "files": 1,
                "chunks": len(chunks),
                "symbols": symbols_inserted,
                "embeddings": len(embeddings),
            }

        except Exception as e:
            self.conn.rollback()
            msg = f"Failed to index file: {e}"
            raise StorageError(
                code=ErrorCode.STORAGE_SQLITE_TRANSACTION_FAILED,
                message=msg,
                context=storage_context(
                    query="index_file",

                ),
            ) from e

    def _insert_embedding(self, cursor, chunk_id: int, embedding: list[float]) -> None:
        """Insert embedding into vec_chunks table.
        
        Args:
            cursor: Database cursor.
            chunk_id: Chunk ID.
            embedding: 768-dim embedding vector.
            
        Raises:
            Exception: If vec0 not available or insert fails.
        """
        # Convert to comma-separated string for vec0
        embedding_str = "[" + ",".join(str(v) for v in embedding) + "]"

        cursor.execute(
            "INSERT OR REPLACE INTO vec_chunks (chunk_id, embedding) VALUES (?, ?)",
            (chunk_id, embedding_str)
        )

    def update_indexing_state(
        self,
        repo_root: str,
        total_files: int,
        total_chunks: int,
        total_symbols: int,
        full_index: bool = True,
    ) -> None:
        """Update repo-level indexing state.
        
        Args:
            repo_root: Repository root path.
            total_files: Total files indexed.
            total_chunks: Total chunks created.
            total_symbols: Total symbols extracted.
            full_index: True if full index, False if incremental.
            
        Raises:
            StorageError: If update fails.
        """
        try:
            cursor = self.conn.cursor()
            now_ms = int(time.time() * 1000)

            if full_index:
                # Full index - insert or replace
                cursor.execute(
                    """INSERT OR REPLACE INTO indexing_state
                       (repo_root, last_full_index_at, last_incremental_at,
                        total_files, total_chunks, total_symbols)
                       VALUES (?, ?, ?, ?, ?, ?)""",
                    (repo_root, now_ms, None, total_files, total_chunks, total_symbols)
                )
            else:
                # Incremental - update timestamp only
                cursor.execute(
                    """UPDATE indexing_state
                       SET last_incremental_at = ?,
                           total_files = ?,
                           total_chunks = ?,
                           total_symbols = ?
                       WHERE repo_root = ?""",
                    (now_ms, total_files, total_chunks, total_symbols, repo_root)
                )

            self.conn.commit()

            logger.info(
                "Indexing state updated",
                repo_root=repo_root,
                full_index=full_index,
                files=total_files,
                chunks=total_chunks,
                symbols=total_symbols,
            )

        except Exception as e:
            self.conn.rollback()
            msg = f"Failed to update indexing state: {e}"
            raise StorageError(
                code=ErrorCode.STORAGE_SQLITE_TRANSACTION_FAILED,
                message=msg,
                context=storage_context(query="update_indexing_state"),
            ) from e

    def delete_file(self, file_path: str) -> int:
        """Delete file and all associated chunks/symbols.
        
        Args:
            file_path: Relative path from repo root.
            
        Returns:
            Number of chunks deleted.
            
        Raises:
            StorageError: If deletion fails.
        """
        try:
            cursor = self.conn.cursor()

            # Get file ID
            cursor.execute("SELECT id FROM files WHERE path = ?", (file_path,))
            result = cursor.fetchone()
            if not result:
                return 0

            file_id = result[0]

            # Get chunk IDs before deletion for FTS5 sync
            cursor.execute("SELECT id FROM chunks WHERE file_id = ?", (file_id,))
            chunk_ids = [row[0] for row in cursor.fetchall()]

            # Delete from FTS5 first (manual sync)
            for chunk_id in chunk_ids:
                try:
                    cursor.execute("DELETE FROM fts_chunks WHERE chunk_id = ?", (chunk_id,))
                except Exception as e:
                    logger.warning(
                        "Failed to delete from FTS5",
                        chunk_id=chunk_id,
                        error=str(e),
                    )

            # Delete file (cascades to chunks via FK)
            cursor.execute("DELETE FROM files WHERE id = ?", (file_id,))

            self.conn.commit()

            # Checkpoint WAL to ensure readers see changes
            try:
                self.conn.execute("PRAGMA wal_checkpoint(RESTART)")
            except Exception as e:
                logger.debug(
                    "WAL checkpoint failed (non-critical)",
                    error=str(e),
                )

            logger.info(
                "File deleted from index",

                chunks_deleted=len(chunk_ids),
            )

            return len(chunk_ids)

        except Exception as e:
            self.conn.rollback()
            msg = f"Failed to delete file: {e}"
            raise StorageError(
                code=ErrorCode.STORAGE_SQLITE_TRANSACTION_FAILED,
                message=msg,
            ) from e
