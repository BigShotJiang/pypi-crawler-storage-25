from __future__ import annotations

import time
from pathlib import Path
from threading import Lock, Timer
from typing import TYPE_CHECKING

from watchdog.events import FileSystemEvent, FileSystemEventHandler
from watchdog.observers import Observer

from contextual.observability.logging import get_logger


if TYPE_CHECKING:
    from contextual.indexing.incremental import IncrementalIndexer

logger = get_logger(__name__)


class DebouncedFileWatcher(FileSystemEventHandler):
    """Watches a repository directory for file changes, debounces rapid events,
    and triggers incremental re-indexing.
    """

    def __init__(
        self,
        repo_root: Path,
        incremental_indexer: IncrementalIndexer,
        debounce_ms: int = 500,
    ):
        """Initialize file watcher.

        Args:
            repo_root: Repository root to watch.
            incremental_indexer: Indexer to call on changes.
            debounce_ms: Debounce delay in milliseconds (default 500).
        """
        self._repo_root = repo_root
        self._incremental_indexer = incremental_indexer
        self._debounce_ms = debounce_ms
        self._observer = Observer()
        self._pending_timers: dict[str, Timer] = {}
        self._lock = Lock()

    def start(self) -> None:
        """Creates and starts the watchdog observer to monitor the repository.
        """
        self._observer.schedule(self, str(self._repo_root), recursive=True)
        self._observer.start()
        logger.info("File watcher started", path=str(self._repo_root))

    def stop(self) -> None:
        """Stops the file watcher and cleans up pending operations.
        """
        if self._observer.is_alive():
            self._observer.stop()
            self._observer.join()

        with self._lock:
            for timer in self._pending_timers.values():
                timer.cancel()
            self._pending_timers.clear()
        logger.info("File watcher stopped")

    def _schedule_index(self, file_path: Path, event_type: str) -> None:
        """Schedules an indexing operation for a file, debouncing rapid events.
        """
        with self._lock:
            # Cancel any existing timer for this file
            if str(file_path) in self._pending_timers:
                self._pending_timers[str(file_path)].cancel()

            # Create a new timer
            timer = Timer(
                self._debounce_ms / 1000.0,
                self._process_file,
                args=[file_path, event_type],
            )
            self._pending_timers[str(file_path)] = timer
            timer.start()

    def _process_file(self, file_path: Path, event_type: str) -> None:
        """Processes a single file event after the debounce period.
        """
        try:
            with self._lock:
                # Remove timer from pending list
                self._pending_timers.pop(str(file_path), None)

            if not self._incremental_indexer.should_index_file(file_path):
                return

            start_time = time.monotonic()
            if event_type in ("modified", "created"):
                self._incremental_indexer.handle_file_change(file_path)
            elif event_type == "deleted":
                self._incremental_indexer.handle_file_deletion(file_path)

            duration_ms = (time.monotonic() - start_time) * 1000
            logger.debug(
                "Processed file event",
                path=str(file_path),
                event=event_type,
                duration_ms=duration_ms,
            )
        except Exception:
            logger.exception(
                "Error processing file event", path=str(file_path), event=event_type
            )

    def on_modified(self, event: FileSystemEvent) -> None:
        """Handle file modification events."""
        if not event.is_directory:
            try:
                file_path = Path(event.src_path)
                self._schedule_index(file_path, "modified")
            except Exception:
                logger.exception("Error in on_modified handler", path=event.src_path)

    def on_created(self, event: FileSystemEvent) -> None:
        """Handle file creation events."""
        if not event.is_directory:
            try:
                file_path = Path(event.src_path)
                self._schedule_index(file_path, "created")
            except Exception:
                logger.exception("Error in on_created handler", path=event.src_path)

    def on_deleted(self, event: FileSystemEvent) -> None:
        """Handle file deletion events."""
        if not event.is_directory:
            try:
                file_path = Path(event.src_path)
                self._schedule_index(file_path, "deleted")
            except Exception:
                logger.exception("Error in on_deleted handler", path=event.src_path)

    def on_moved(self, event: FileSystemEvent) -> None:
        """Handle file move/rename events."""
        if not event.is_directory:
            try:
                old_path = Path(event.src_path)
                new_path = Path(event.dest_path)

                # Cancel any pending timers for the old path
                with self._lock:
                    if str(old_path) in self._pending_timers:
                        self._pending_timers[str(old_path)].cancel()
                        self._pending_timers.pop(str(old_path), None)

                self._incremental_indexer.handle_file_rename(old_path, new_path)
                logger.debug("Processed file move event", src=str(old_path), dest=str(new_path))
            except Exception:
                logger.exception("Error in on_moved handler", src=event.src_path, dest=event.dest_path)
