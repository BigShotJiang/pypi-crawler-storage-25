"""Docs module — Phase 2: heading-aware document indexing and retrieval.

Public API
----------
Chunking:
    DocsChunker         Heading-aware markdown/MDX/RST/TXT chunker.
    DocChunk            Dataclass representing a single doc chunk.
    chunk_doc_file      Convenience: chunk a single file with defaults.

Indexing:
    DocsPipeline        Full indexing pipeline (file discovery → embed → store).
    DocsIndexStats      Stats dataclass returned by pipeline runs.
    index_docs          Convenience: index all docs in a repo.

Retrieval:
    docs_search         Hybrid BM25 + vector search over doc chunks.
    docs_get_section    Fetch exact section by heading path (5-tier resolver).
    docs_list_files     List all indexed doc files.
    DocSearchHit        Search result dataclass.
    DocSection          Resolved section dataclass.
    DocFileInfo         File metadata dataclass.

File Watching:
    DocsFileWatcher     Watchdog-based watcher; composable with code watcher.
"""
from __future__ import annotations

from contextual.docs.chunker import (
    DocChunk,
    DocsChunker,
    chunk_doc_file,
)
from contextual.docs.pipeline import (
    DocsPipeline,
    DocsIndexStats,
    index_docs,
)
from contextual.docs.retrieval import (
    DocSearchHit,
    DocSection,
    DocFileInfo,
    docs_search,
    docs_get_section,
    docs_list_files,
)
from contextual.docs.watcher import DocsFileWatcher

__all__ = [
    # Chunking
    "DocChunk",
    "DocsChunker",
    "chunk_doc_file",
    # Indexing
    "DocsPipeline",
    "DocsIndexStats",
    "index_docs",
    # Retrieval
    "DocSearchHit",
    "DocSection",
    "DocFileInfo",
    "docs_search",
    "docs_get_section",
    "docs_list_files",
    # Watching
    "DocsFileWatcher",
]
