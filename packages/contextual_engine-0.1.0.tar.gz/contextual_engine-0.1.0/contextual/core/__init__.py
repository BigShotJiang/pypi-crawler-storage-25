"""Core data models, errors, and orchestration engine.

This module contains the foundational contracts that all other modules depend on.
All data shapes (Pydantic models), error types, and the main indexing/retrieval
orchestrator live here.
"""
from __future__ import annotations


__all__ = []
# Exports will be added as models.py, errors.py, and engine.py are built
