from __future__ import annotations

import pathlib


def get_log_dir():
    return pathlib.Path("~/.local/state/contextual/logs").expanduser()
