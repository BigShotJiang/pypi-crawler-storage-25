"""Retrieval module: hybrid search, ranking, and context assembly.

Public API:
- hybrid_search: BM25 + vector search with RRF fusion
- assemble_context: Token-budgeted context formatting
- deduplicate_results: Content deduplication
- apply_mmr: Diversity filtering
"""
from __future__ import annotations

from contextual.retrieval.context_assembler import assemble_context
from contextual.retrieval.search import SearchResult, hybrid_search
from contextual.retrieval.ranker import apply_mmr, deduplicate_results


# ranker imports will be added after delegation

__all__ = [
    "SearchResult",
    "assemble_context",
    "hybrid_search",
    "apply_mmr",
    "deduplicate_results"
]
