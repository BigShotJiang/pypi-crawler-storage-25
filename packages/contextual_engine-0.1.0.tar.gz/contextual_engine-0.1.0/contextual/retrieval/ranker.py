"""Result ranking and diversity filtering.

Provides post-processing for search results:
- deduplicate_results: Content deduplication
- apply_mmr: Maximal Marginal Relevance diversity
- rerank_with_cross_encoder: Cross-encoder reranking (Phase 2)
"""

from __future__ import annotations

from collections import defaultdict
from typing import TYPE_CHECKING

from contextual.observability.logging import get_logger


if TYPE_CHECKING:
    from contextual.retrieval.search import SearchResult

logger = get_logger(__name__)

# ============================================================================
# CONSTANTS
# ============================================================================

MMR_LAMBDA = 0.7
"""Default MMR relevance/diversity tradeoff parameter."""

MMR_MAX_PER_FILE = 2
"""Default maximum number of results per file path."""

MMR_MAX_PER_SYMBOL = 1
"""Default maximum number of results per symbol name."""

RERANK_MAX_PAIRS = 30
"""Maximum query-document pairs for cross-encoder reranking."""


def deduplicate_results(results: list[SearchResult]) -> list[SearchResult]:
    """Remove duplicate snippets while preserving overall ordering.

    Duplicates are detected by exact snippet string match. For each unique snippet,
    the highest-scoring result is retained. The final output follows the input order
    (stable order) of chosen representatives to avoid introducing rank jitter.

    Args:
        results: Ranked retrieval results.

    Returns:
        Deduplicated result list.
    """
    if not results:
        return []

    best_score_by_snippet: dict[str, float] = {}
    best_chunk_id_by_snippet: dict[str, int] = {}

    # Pass 1: determine representative result for each snippet.
    for result in results:
        snippet_key = result.snippet.strip()
        if snippet_key not in best_score_by_snippet:
            best_score_by_snippet[snippet_key] = result.score
            best_chunk_id_by_snippet[snippet_key] = result.chunk_id
            continue

        if result.score > best_score_by_snippet[snippet_key]:
            best_score_by_snippet[snippet_key] = result.score
            best_chunk_id_by_snippet[snippet_key] = result.chunk_id

    # Pass 2: keep only chosen representatives in original order.
    deduplicated: list[SearchResult] = []
    emitted_snippets: set[str] = set()
    for result in results:
        snippet_key = result.snippet.strip()
        if snippet_key in emitted_snippets:
            continue

        chosen_chunk_id = best_chunk_id_by_snippet.get(snippet_key)
        if chosen_chunk_id == result.chunk_id:
            deduplicated.append(result)
            emitted_snippets.add(snippet_key)

    logger.debug(
        "Deduplicated retrieval results",
        input_count=len(results),
        output_count=len(deduplicated),
        duplicates_removed=len(results) - len(deduplicated),
    )

    return deduplicated


def apply_mmr(
    results: list[SearchResult],
    lambda_param: float = MMR_LAMBDA,
    max_per_file: int = MMR_MAX_PER_FILE,
    max_per_symbol: int = MMR_MAX_PER_SYMBOL,
) -> list[SearchResult]:
    """Apply diversity filtering constraints over ranked results.

    Phase 1 uses deterministic quota-based filtering:
    - At most `max_per_file` results per file path.
    - At most `max_per_symbol` results per symbol name.

    Args:
        results: Ranked retrieval results.
        lambda_param: Reserved MMR tradeoff parameter for future semantic MMR.
        max_per_file: Max results allowed for the same file path.
        max_per_symbol: Max results allowed for the same symbol name.

    Returns:
        Diversity-filtered results, preserving input ordering.
    """
    if not results:
        return []
    if max_per_file <= 0:
        logger.warning("max_per_file must be positive; returning empty result set", value=max_per_file)
        return []
    if max_per_symbol <= 0:
        logger.warning(
            "max_per_symbol must be positive; returning empty result set",
            value=max_per_symbol,
        )
        return []

    # Phase 1 doesn't yet compute pairwise similarity; keep parameter visible.
    if not 0.0 <= lambda_param <= 1.0:
        logger.warning(
            "lambda_param out of range for MMR; clamping",
            original=lambda_param,
        )
        lambda_param = max(0.0, min(1.0, lambda_param))

    _ = lambda_param  # Reserved for true MMR scoring in Phase 2.

    file_counts: defaultdict[str, int] = defaultdict(int)
    symbol_counts: defaultdict[str, int] = defaultdict(int)
    filtered: list[SearchResult] = []

    skipped_file_quota = 0
    skipped_symbol_quota = 0

    for result in results:
        file_key = result.path
        symbol_key = result.symbol_name.strip() if result.symbol_name else ""

        if file_counts[file_key] >= max_per_file:
            skipped_file_quota += 1
            continue

        if symbol_key and symbol_counts[symbol_key] >= max_per_symbol:
            skipped_symbol_quota += 1
            continue

        filtered.append(result)
        file_counts[file_key] += 1
        if symbol_key:
            symbol_counts[symbol_key] += 1

    logger.debug(
        "Applied diversity filtering",
        input_count=len(results),
        output_count=len(filtered),
        skipped_file_quota=skipped_file_quota,
        skipped_symbol_quota=skipped_symbol_quota,
        max_per_file=max_per_file,
        max_per_symbol=max_per_symbol,
    )

    return filtered


def rerank_with_cross_encoder(
    query: str,
    results: list[SearchResult],
    top_k: int = RERANK_MAX_PAIRS,
) -> list[SearchResult]:
    """Rerank top candidates with a cross-encoder model.

    Args:
        query: User search query text.
        results: Candidate retrieval results.
        top_k: Maximum candidates to rerank with the cross-encoder.

    Returns:
        Reranked results (Phase 2).

    Raises:
        NotImplementedError: Always raised in Phase 1.
    """
    _ = (query, results, top_k)
    # TODO(Phase 2): Integrate jina-reranker-v2-base-multilingual over query/chunk pairs.
    raise NotImplementedError("Cross-encoder reranking coming in Phase 2")
