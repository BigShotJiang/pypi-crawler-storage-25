"""IDE integrations: auto-configuration for Claude Desktop, Cursor, VS Code, and more.

Provides automatic setup scripts for 8 AI coding tools, handling MCP server
configuration, path resolution, and tool-specific quirks.
"""
from __future__ import annotations


__all__ = []
# Exports will be added as integration modules are built (Week 3)
