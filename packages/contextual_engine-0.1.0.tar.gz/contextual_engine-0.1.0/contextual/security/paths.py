"""Path safety utilities for preventing traversal and injection attacks.

This module provides bulletproof path validation to prevent:
- Path traversal attacks (../../../etc/passwd)
- Symlink attacks (links outside project root)
- Windows reserved name attacks (CON, PRN, AUX, NUL)
- Excessive path depth attacks
- Invalid path characters

All file operations in Contextual must use safe_path() before accessing the filesystem.
"""

from __future__ import annotations

import os
from pathlib import Path

from contextual.core.errors import ErrorCode, SecurityError, security_context


# Windows reserved device names that must be rejected
WINDOWS_RESERVED_NAMES = frozenset({
    "CON", "PRN", "AUX", "NUL",
    "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
    "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9",
})


def safe_path(root: Path, candidate: Path | str, *, allow_create: bool = False) -> Path:
    """Validate and resolve a path safely within a root directory.
    
    This is the primary path safety function. ALL file operations in Contextual
    must call this before touching the filesystem.
    
    Security guarantees:
    1. Path is resolved to absolute form
    2. Symlinks are resolved (no following links outside root)
    3. Result is strictly within root directory
    4. No path traversal sequences (../) can escape
    5. No Windows reserved device names
    6. Path depth is within limits
    
    Args:
        root: Root directory that must contain the result.
        candidate: Path to validate (relative or absolute).
        allow_create: If True, don't require path to exist (for file creation).
        
    Returns:
        Validated absolute path guaranteed to be within root.
        
    Raises:
        SecurityError: If path validation fails for any reason.
        
    Examples:
        >>> root = Path("/home/user/project")
        >>> safe_path(root, "src/main.py")  # OK
        Path('/home/user/project/src/main.py')
        
        >>> safe_path(root, "../../../etc/passwd")  # BLOCKED
        SecurityError: Path traversal attempt
        
        >>> safe_path(root, "/tmp/evil.txt")  # BLOCKED
        SecurityError: Path outside root
    """
    # Ensure root is absolute
    if not root.is_absolute():
        msg = "Root path must be absolute"
        raise SecurityError(
            code=ErrorCode.SECURITY_PATH_INVALID,
            message=msg,
            context=security_context(path=str(root)),
        )

    # Convert candidate to Path if string
    if isinstance(candidate, str):
        candidate = Path(candidate)

    # Resolve root (follows symlinks, gets absolute path)
    try:
        resolved_root = root.resolve(strict=True)
    except (OSError, RuntimeError) as e:
        # OSError: path doesn't exist or permission denied
        # RuntimeError: symlink loop (Python <3.13)
        msg = f"Failed to resolve root path: {e}"
        raise SecurityError(
            code=ErrorCode.SECURITY_PATH_SYMLINK_LOOP,
            message=msg,
            context=security_context(path=str(root)),
        ) from e

    # Build full candidate path
    if candidate.is_absolute():
        full_path = candidate
    else:
        full_path = resolved_root / candidate

    # Resolve candidate path
    try:
        if allow_create:
            # For file creation, resolve parent and append filename
            if full_path.parent.exists():
                resolved_parent = full_path.parent.resolve(strict=True)
                resolved_path = resolved_parent / full_path.name
            else:
                # Parent doesn't exist - resolve as much as possible
                # Walk up until we find an existing parent
                parts = list(full_path.parts)
                for i in range(len(parts), 0, -1):
                    test_path = Path(*parts[:i])
                    if test_path.exists():
                        resolved_existing = test_path.resolve(strict=True)
                        remaining = Path(*parts[i:])
                        resolved_path = resolved_existing / remaining
                        break
                else:
                    # No existing ancestor found
                    msg = "No existing ancestor directory found"
                    raise SecurityError(
                        code=ErrorCode.SECURITY_PATH_INVALID,
                        message=msg,
                        context=security_context(path=str(full_path), root=str(resolved_root)),
                    )
        else:
            # For reading, path must exist
            resolved_path = full_path.resolve(strict=True)
    except (OSError, RuntimeError) as e:
        # OSError: path doesn't exist, permission denied
        # RuntimeError: symlink loop (Python <3.13)
        msg = f"Failed to resolve path: {e}"
        raise SecurityError(
            code=ErrorCode.SECURITY_PATH_SYMLINK_LOOP,
            message=msg,
            context=security_context(path=str(full_path), root=str(resolved_root)),
        ) from e

    # Critical security check: ensure resolved path is within root
    try:
        resolved_path.relative_to(resolved_root)
    except ValueError as e:
        # relative_to raises ValueError if path is not relative to root
        msg = "Path is outside allowed root directory"
        raise SecurityError(
            code=ErrorCode.SECURITY_PATH_OUTSIDE_ROOT,
            message=msg,
            context=security_context(path=str(resolved_path), root=str(resolved_root)),
        ) from e

    # Check for Windows reserved names in any path component
    _check_windows_reserved_names(resolved_path)

    # Check path depth
    _check_path_depth(resolved_path, resolved_root)

    return resolved_path


def _check_windows_reserved_names(path: Path) -> None:
    """Check if path contains Windows reserved device names.
    
    Windows reserves certain names (CON, PRN, AUX, NUL, COM1-9, LPT1-9) that
    cannot be used as filenames. This applies even on Unix systems if files
    will be synced to Windows.
    
    Args:
        path: Path to check.
        
    Raises:
        SecurityError: If path contains a reserved name.
    """
    for part in path.parts:
        # Strip extension and check base name
        name_upper = part.upper()
        if "." in name_upper:
            base_name = name_upper.split(".")[0]
        else:
            base_name = name_upper

        if base_name in WINDOWS_RESERVED_NAMES:
            msg = f"Path contains Windows reserved name: {part}"
            raise SecurityError(
                code=ErrorCode.SECURITY_PATH_RESERVED_NAME,
                message=msg,
                context=security_context(path=str(path), attack_type="windows_reserved_name"),
            )


def _check_path_depth(path: Path, root: Path, max_depth: int = 20) -> None:
    """Check if path depth exceeds maximum allowed.
    
    Prevents DoS attacks via extremely deep directory structures.
    
    Args:
        path: Path to check.
        root: Root directory (depth is measured from here).
        max_depth: Maximum allowed depth (default 20).
        
    Raises:
        SecurityError: If path depth exceeds limit.
    """
    try:
        relative = path.relative_to(root)
        depth = len(relative.parts)
        if depth > max_depth:
            msg = f"Path depth {depth} exceeds maximum {max_depth}"
            raise SecurityError(
                code=ErrorCode.SECURITY_PATH_INVALID,
                message=msg,
                context=security_context(path=str(path), root=str(root)),
            )
    except ValueError:
        # Path is not relative to root - already caught by safe_path
        pass


def is_safe_path(root: Path, candidate: Path | str) -> bool:
    """Check if a path is safe without raising an exception.
    
    Convenience wrapper around safe_path() for cases where you want to check
    validity without exception handling.
    
    Args:
        root: Root directory.
        candidate: Path to check.
        
    Returns:
        True if path is safe, False otherwise.
    """
    try:
        safe_path(root, candidate)
        return True
    except SecurityError:
        return False


def safe_join(root: Path, *parts: str) -> Path:
    """Join path components safely within a root directory.
    
    Equivalent to root / part1 / part2 / ... but with safety validation.
    
    Args:
        root: Root directory.
        *parts: Path components to join.
        
    Returns:
        Validated path within root.
        
    Raises:
        SecurityError: If resulting path would be outside root.
    """
    if not parts:
        return root

    # Join all parts
    candidate = Path(os.path.join(*parts))

    # Validate
    return safe_path(root, candidate, allow_create=True)


def validate_filename(filename: str) -> str:
    """Validate a filename for safety.
    
    Checks that filename:
    - Contains no path separators (/ or \\)
    - Contains no null bytes
    - Is not empty
    - Is not a reserved name
    - Contains only valid characters
    
    Args:
        filename: Filename to validate.
        
    Returns:
        Validated filename.
        
    Raises:
        SecurityError: If filename is invalid.
    """
    if not filename:
        msg = "Filename cannot be empty"
        raise SecurityError(
            code=ErrorCode.SECURITY_PATH_INVALID,
            message=msg,
            context={"filename": filename},
        )

    # Check for path separators
    if "/" in filename or "\\" in filename:
        msg = "Filename cannot contain path separators"
        raise SecurityError(
            code=ErrorCode.SECURITY_PATH_INVALID,
            message=msg,
            context={"filename": filename},
        )

    # Check for null bytes
    if "\x00" in filename:
        msg = "Filename cannot contain null bytes"
        raise SecurityError(
            code=ErrorCode.SECURITY_PATH_INVALID,
            message=msg,
            context={"filename": filename},
        )

    # Check for Windows reserved names
    name_upper = filename.upper()
    if "." in name_upper:
        base_name = name_upper.split(".")[0]
    else:
        base_name = name_upper

    if base_name in WINDOWS_RESERVED_NAMES:
        msg = f"Filename is a Windows reserved name: {filename}"
        raise SecurityError(
            code=ErrorCode.SECURITY_PATH_RESERVED_NAME,
            message=msg,
            context={"filename": filename},
        )

    return filename


def ensure_parent_exists(path: Path, *, permissions: int = 0o755) -> None:
    """Ensure parent directory of a path exists.
    
    Creates parent directories if they don't exist, with proper permissions.
    
    Args:
        path: File path whose parent should exist.
        permissions: Permissions for created directories (default 0o755).
        
    Raises:
        SecurityError: If directory creation fails.
    """
    parent = path.parent
    if parent.exists():
        return

    try:
        parent.mkdir(parents=True, exist_ok=True, mode=permissions)
    except OSError as e:
        msg = f"Failed to create parent directory: {e}"
        raise SecurityError(
            code=ErrorCode.SECURITY_WORKSPACE_INIT_FAILED,
            message=msg,
            context=security_context(path=str(parent)),
        ) from e
