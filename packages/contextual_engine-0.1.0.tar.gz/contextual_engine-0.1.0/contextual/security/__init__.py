"""Security hardening: path safety, input sanitization, and workspace isolation.

Prevents path traversal, SQL/FTS5 injection, Unicode-based attacks, and prompt
injection via indexed content. Implements per-project workspace isolation.
"""
from __future__ import annotations

from contextual.security.paths import (
    ensure_parent_exists,
    is_safe_path,
    safe_join,
    safe_path,
    validate_filename,
)
from contextual.security.sanitize import (
    detect_prompt_injection_patterns,
    escape_for_logging,
    escape_fts5_match_query,
    sanitize_file_content,
    sanitize_user_input,
    strip_unicode_control_chars,
    validate_sql_identifier,
    wrap_untrusted_content,
)
from contextual.security.workspace import (
    WorkspaceManager,
    get_workspace_manager,
    init_workspace,
)


__all__ = [
    # Path safety
    "safe_path",
    "is_safe_path",
    "safe_join",
    "validate_filename",
    "ensure_parent_exists",
    # Input sanitization
    "strip_unicode_control_chars",
    "escape_fts5_match_query",
    "validate_sql_identifier",
    "sanitize_user_input",
    "sanitize_file_content",
    "detect_prompt_injection_patterns",
    "wrap_untrusted_content",
    "escape_for_logging",
    # Workspace management
    "WorkspaceManager",
    "init_workspace",
    "get_workspace_manager",
]
