"""Input sanitization utilities for preventing injection attacks.

This module provides sanitization functions to prevent:
- Unicode-based attacks (invisible characters, bidi overrides)
- SQL injection (via identifier validation)
- FTS5 injection (via query escaping)
- Prompt injection (via content wrapping)

All user-provided text inputs should be sanitized before use.
"""

from __future__ import annotations

import re
import unicodedata
from re import Pattern

from contextual.core.errors import ErrorCode, SecurityError


# Compiled regex patterns for performance
_SQL_IDENTIFIER_PATTERN: Pattern[str] = re.compile(r"^[a-zA-Z_][a-zA-Z0-9_]*$")
_FTS5_SPECIAL_CHARS: Pattern[str] = re.compile(r'["@:()-]')


def strip_unicode_control_chars(text: str) -> str:
    """Remove Unicode control characters from text.
    
    Strips characters in Unicode category Cf (Format, Other), which includes:
    - Zero-width characters (ZWSP, ZWNJ, ZWJ)
    - Bidirectional overrides (RLO, LRO, PDF)
    - Other invisible formatting characters
    
    This prevents attacks like:
    - Rules-File-Backdoor (hidden instructions visible only to LLMs)
    - Visual spoofing via bidi overrides
    - Zero-width character obfuscation
    
    Args:
        text: Text to sanitize.
        
    Returns:
        Text with control characters removed.
        
    Examples:
        >>> text_with_zwsp = "Hello\\u200bWorld"
        >>> strip_unicode_control_chars(text_with_zwsp)
        'HelloWorld'
        
        >>> text_with_bidi = "normal\\u202eesreveR"  # RLO override
        >>> strip_unicode_control_chars(text_with_bidi)
        'normalesreveR'
    """
    # Filter out Unicode category Cf (Format, Other)
    # This is fast because we're iterating in Python and unicodedata.category
    # is a C function call
    return "".join(char for char in text if unicodedata.category(char) != "Cf")


def escape_fts5_match_query(query: str) -> str:
    """Escape a query string for SQLite FTS5 MATCH operator.
    
    FTS5 has special syntax for queries (boolean AND/OR, phrase matching, etc.).
    User input must be escaped to prevent injection and syntax errors.
    
    Strategy: Phrase-quote the entire query, and escape internal quotes.
    This treats the query as a literal phrase search, which is safe and
    matches user expectations for a "search box" input.
    
    FTS5 special characters that need escaping:
    - " (phrase delimiter)
    - @ (column filter)
    - : (column filter)
    - ( ) (grouping)
    - - (exclusion)
    
    Args:
        query: User-provided search query.
        
    Returns:
        Escaped query safe for FTS5 MATCH.
        
    Examples:
        >>> escape_fts5_match_query('normal query')
        '"normal query"'
        
        >>> escape_fts5_match_query('query with "quotes"')
        "\"query with \"\"quotes\"\"\""
        
        >>> escape_fts5_match_query('special:chars@here')
        '"special:chars@here"'
    """
    # Escape internal quotes by doubling them
    escaped = query.replace('"', '""')

    # Wrap in phrase quotes
    return f'"{escaped}"'


def validate_sql_identifier(identifier: str) -> str:
    """Validate a SQL identifier (table name, column name, etc.).
    
    Ensures identifier:
    - Starts with letter or underscore
    - Contains only letters, numbers, underscores
    - Is not empty
    - Is not too long (64 chars max for portability)
    
    This prevents SQL injection via identifier names.
    
    Args:
        identifier: SQL identifier to validate.
        
    Returns:
        Validated identifier.
        
    Raises:
        SecurityError: If identifier is invalid.
        
    Examples:
        >>> validate_sql_identifier('valid_name')
        'valid_name'
        
        >>> validate_sql_identifier('also123valid')
        'also123valid'
        
        >>> validate_sql_identifier('invalid-name')  # Contains hyphen
        SecurityError: Invalid SQL identifier
        
        >>> validate_sql_identifier('123invalid')  # Starts with number
        SecurityError: Invalid SQL identifier
    """
    if not identifier:
        msg = "SQL identifier cannot be empty"
        raise SecurityError(
            code=ErrorCode.SECURITY_SQL_INJECTION_ATTEMPT,
            message=msg,
            context={"identifier": identifier},
        )

    if len(identifier) > 64:
        msg = "SQL identifier too long (max 64 chars)"
        raise SecurityError(
            code=ErrorCode.SECURITY_SQL_INJECTION_ATTEMPT,
            message=msg,
            context={"identifier": identifier[:100]},
        )

    if not _SQL_IDENTIFIER_PATTERN.match(identifier):
        msg = "Invalid SQL identifier (must start with letter/underscore, contain only alphanumeric/underscore)"
        raise SecurityError(
            code=ErrorCode.SECURITY_SQL_INJECTION_ATTEMPT,
            message=msg,
            context={"identifier": identifier},
        )

    return identifier


def sanitize_user_input(text: str, *, max_length: int | None = None) -> str:
    """Comprehensive sanitization of user-provided text.
    
    Applies multiple sanitization steps:
    1. Strip Unicode control characters
    2. Normalize whitespace
    3. Trim to max length if specified
    
    Args:
        text: User input to sanitize.
        max_length: Optional maximum length (truncates if exceeded).
        
    Returns:
        Sanitized text.
    """
    # Strip control characters
    sanitized = strip_unicode_control_chars(text)

    # Normalize whitespace (collapse multiple spaces, trim)
    sanitized = " ".join(sanitized.split())

    # Truncate if needed
    if max_length is not None and len(sanitized) > max_length:
        sanitized = sanitized[:max_length]

    return sanitized


def wrap_untrusted_content(content: str) -> str:
    """Wrap potentially untrusted content in safety markers.
    
    When passing indexed code/content to LLMs via MCP tools, we wrap it
    in markers to indicate it should be treated as data, not instructions.
    
    This mitigates indirect prompt injection where malicious code files
    contain hidden instructions that the LLM might follow.
    
    Args:
        content: Content to wrap.
        
    Returns:
        Content wrapped in safety markers.
        
    Examples:
        >>> wrap_untrusted_content('code snippet')
        '<untrusted_content>\\ncode snippet\\n</untrusted_content>'
    """
    return f"<untrusted_content>\n{content}\n</untrusted_content>"


def detect_prompt_injection_patterns(text: str) -> list[str]:
    """Detect common prompt injection patterns in text.
    
    This is a heuristic check for known prompt injection techniques.
    Not foolproof, but catches obvious attempts.
    
    Patterns checked:
    - "Ignore previous instructions"
    - "You are now in [X] mode"
    - "Disregard your rules"
    - "New instructions:"
    - Excessive repetition (token flooding)
    
    Args:
        text: Text to check.
        
    Returns:
        List of detected pattern descriptions (empty if none found).
    """
    patterns_found: list[str] = []

    text_lower = text.lower()

    # Check for instruction override phrases
    override_phrases = [
        "ignore previous instructions",
        "ignore all previous",
        "disregard your rules",
        "disregard all rules",
        "new instructions:",
        "you are now",
        "enter god mode",
        "enter admin mode",
        "system: ",
        "<system>",
    ]

    for phrase in override_phrases:
        if phrase in text_lower:
            patterns_found.append(f"Instruction override phrase: {phrase}")

    # Check for excessive repetition (token flooding)
    words = text.split()
    if len(words) > 50:
        # Check if any word is repeated excessively
        word_counts: dict[str, int] = {}
        for word in words:
            word_lower = word.lower()
            word_counts[word_lower] = word_counts.get(word_lower, 0) + 1

        for word, count in word_counts.items():
            if count > 10 and len(word) > 3:  # Word repeated >10 times
                patterns_found.append(f"Excessive repetition: '{word}' repeated {count} times")

    # Check for XML/HTML-like tags that might interfere with parsing
    suspicious_tags = [
        "<system", "<instruction", "<prompt", "<rule", "<command",
        "</system", "</instruction", "</prompt", "</rule", "</command",
    ]

    for tag in suspicious_tags:
        if tag in text_lower:
            patterns_found.append(f"Suspicious tag: {tag}")

    return patterns_found


def sanitize_file_content(
    content: str,
    *,
    strip_control: bool = True,
    detect_injection: bool = True,
    max_length: int | None = None,
) -> tuple[str, list[str]]:
    """Sanitize file content before indexing or display.
    
    Applies sanitization and optionally checks for injection patterns.
    
    Args:
        content: File content to sanitize.
        strip_control: Whether to strip Unicode control characters.
        detect_injection: Whether to detect prompt injection patterns.
        max_length: Optional maximum length.
        
    Returns:
        Tuple of (sanitized_content, warnings).
        Warnings list contains descriptions of detected issues.
    """
    warnings: list[str] = []

    # Strip control characters if requested
    if strip_control:
        original_length = len(content)
        content = strip_unicode_control_chars(content)
        removed = original_length - len(content)
        if removed > 0:
            warnings.append(f"Removed {removed} Unicode control characters")

    # Detect injection patterns if requested
    if detect_injection:
        patterns = detect_prompt_injection_patterns(content)
        warnings.extend(patterns)

    # Truncate if needed
    if max_length is not None and len(content) > max_length:
        content = content[:max_length]
        warnings.append(f"Content truncated to {max_length} characters")

    return content, warnings


def escape_for_logging(text: str, max_length: int = 200) -> str:
    """Escape text for safe inclusion in logs.
    
    Ensures logged text:
    - Has no control characters
    - Is truncated to reasonable length
    - Has no newlines (prevents log injection)
    
    Args:
        text: Text to escape.
        max_length: Maximum length (default 200).
        
    Returns:
        Escaped text safe for logging.
    """
    # Strip control characters
    escaped = strip_unicode_control_chars(text)

    # Replace newlines with spaces
    escaped = escaped.replace("\n", " ").replace("\r", " ")

    # Collapse multiple spaces
    escaped = " ".join(escaped.split())

    # Truncate
    if len(escaped) > max_length:
        escaped = escaped[:max_length] + "..."

    return escaped
