# Note: this is an automatically generated file. Do not edit.
r"""Python naming utilities: encoding Hydra names as Python names."""
from __future__ import annotations
from collections.abc import Callable
from functools import lru_cache
from hydra.dsl.python import Just, Nothing
from typing import TypeVar, cast
import hydra.core
import hydra.formatting
import hydra.lib.equality
import hydra.lib.lists
import hydra.lib.logic
import hydra.lib.maps
import hydra.lib.maybes
import hydra.lib.pairs
import hydra.lib.strings
import hydra.names
import hydra.packaging
import hydra.python.environment
import hydra.python.language
import hydra.python.serde
import hydra.python.syntax
import hydra.util
T0 = TypeVar("T0")
T1 = TypeVar("T1")
def encode_constant_for_field_name(env: T0, tname: T1, fname: hydra.core.Name) -> hydra.python.syntax.Name:
    r"""Generate a constant name for a field definition."""
    return hydra.python.syntax.Name(hydra.formatting.convert_case(hydra.util.CaseConvention.CAMEL, hydra.util.CaseConvention.UPPER_SNAKE, fname.value))
def encode_constant_for_type_name(env: T0, tname: T1) -> hydra.python.syntax.Name:
    r"""Generate a constant name for a type definition."""
    return hydra.python.syntax.Name("TYPE_")
def sanitize_python_name(v1: str) -> str:
    r"""Sanitize a string to be a valid Python name."""
    return hydra.formatting.sanitize_with_underscores(hydra.python.language.python_reserved_words(), v1)
# Whether to use __future__ annotations for forward references.
use_future_annotations = True
def encode_name(is_qualified: bool, conv: hydra.util.CaseConvention, env: hydra.python.environment.PythonEnvironment, name: hydra.core.Name) -> hydra.python.syntax.Name:
    r"""Encode a Hydra name as a Python name."""
    namespaces = env.namespaces
    @lru_cache(1)
    def focus_pair() -> tuple[hydra.packaging.Namespace, hydra.python.syntax.DottedName]:
        return namespaces.focus
    @lru_cache(1)
    def focus_ns() -> hydra.packaging.Namespace:
        return hydra.lib.pairs.first(focus_pair())
    @lru_cache(1)
    def bound_vars() -> FrozenDict[hydra.core.Name, hydra.python.syntax.Name]:
        return hydra.lib.pairs.second(env.bound_type_variables)
    @lru_cache(1)
    def qual_name() -> hydra.packaging.QualifiedName:
        return hydra.names.qualify_name(name)
    mns = qual_name().namespace
    local = qual_name().local
    @lru_cache(1)
    def py_local() -> str:
        return sanitize_python_name(hydra.formatting.convert_case(hydra.util.CaseConvention.CAMEL, conv, local))
    def py_ns(ns_val: hydra.packaging.Namespace) -> str:
        return hydra.lib.strings.intercalate(".", hydra.lib.lists.map((lambda v1: hydra.formatting.convert_case(hydra.util.CaseConvention.CAMEL, hydra.util.CaseConvention.LOWER_SNAKE, v1)), hydra.lib.strings.split_on(".", ns_val.value)))
    return hydra.lib.logic.if_else(is_qualified, (lambda : hydra.lib.maybes.maybe((lambda : hydra.lib.logic.if_else(hydra.lib.equality.equal(mns, Just(focus_ns())), (lambda : hydra.python.syntax.Name(hydra.lib.logic.if_else(use_future_annotations, (lambda : py_local()), (lambda : hydra.python.serde.escape_python_string(True, py_local()))))), (lambda : hydra.lib.maybes.maybe((lambda : hydra.python.syntax.Name(py_local())), (lambda ns_val: hydra.python.syntax.Name(hydra.lib.strings.cat2(py_ns(ns_val), hydra.lib.strings.cat2(".", py_local())))), mns)))), (lambda n: n), hydra.lib.maps.lookup(name, bound_vars()))), (lambda : hydra.python.syntax.Name(py_local())))
def encode_enum_value(v1: hydra.python.environment.PythonEnvironment, v2: hydra.core.Name) -> hydra.python.syntax.Name:
    r"""Encode a name as a Python enum value (UPPER_SNAKE case)."""
    return encode_name(False, hydra.util.CaseConvention.UPPER_SNAKE, v1, v2)
def encode_field_name(env: hydra.python.environment.PythonEnvironment, fname: hydra.core.Name) -> hydra.python.syntax.Name:
    r"""Encode a name as a Python field name (lower_snake case)."""
    return encode_name(False, hydra.util.CaseConvention.LOWER_SNAKE, env, fname)
def encode_name_qualified(env: hydra.python.environment.PythonEnvironment, name: hydra.core.Name) -> hydra.python.syntax.Name:
    r"""Encode a name as a fully qualified Python name."""
    namespaces = env.namespaces
    @lru_cache(1)
    def focus_pair() -> tuple[hydra.packaging.Namespace, hydra.python.syntax.DottedName]:
        return namespaces.focus
    @lru_cache(1)
    def focus_ns() -> hydra.packaging.Namespace:
        return hydra.lib.pairs.first(focus_pair())
    @lru_cache(1)
    def bound_vars() -> FrozenDict[hydra.core.Name, hydra.python.syntax.Name]:
        return hydra.lib.pairs.second(env.bound_type_variables)
    @lru_cache(1)
    def qual_name() -> hydra.packaging.QualifiedName:
        return hydra.names.qualify_name(name)
    mns = qual_name().namespace
    local = qual_name().local
    return hydra.lib.maybes.maybe((lambda : hydra.lib.logic.if_else(hydra.lib.equality.equal(mns, Just(focus_ns())), (lambda : hydra.python.syntax.Name(hydra.lib.logic.if_else(use_future_annotations, (lambda : local), (lambda : hydra.python.serde.escape_python_string(True, local))))), (lambda : hydra.python.syntax.Name(hydra.lib.strings.intercalate(".", hydra.lib.lists.map(sanitize_python_name, hydra.lib.strings.split_on(".", name.value))))))), (lambda n: n), hydra.lib.maps.lookup(name, bound_vars()))
def encode_namespace(ns_val: hydra.packaging.Namespace) -> hydra.python.syntax.DottedName:
    r"""Encode a namespace as a Python dotted name."""
    return hydra.python.syntax.DottedName(hydra.lib.lists.map((lambda part: hydra.python.syntax.Name(hydra.formatting.convert_case(hydra.util.CaseConvention.CAMEL, hydra.util.CaseConvention.LOWER_SNAKE, part))), hydra.lib.strings.split_on(".", ns_val.value)))
def encode_type_variable(name: hydra.core.Name) -> hydra.python.syntax.Name:
    r"""Encode a type variable name (capitalized)."""
    return hydra.python.syntax.Name(hydra.formatting.capitalize(name.value))
def variable_reference(conv: hydra.util.CaseConvention, quoted: bool, env: hydra.python.environment.PythonEnvironment, name: hydra.core.Name) -> hydra.python.syntax.Expression:
    r"""Reference a variable as a Python expression."""
    @lru_cache(1)
    def py_name() -> hydra.python.syntax.Name:
        return encode_name(True, conv, env, name)
    @lru_cache(1)
    def unquoted() -> hydra.python.syntax.Expression:
        return cast(hydra.python.syntax.Expression, hydra.python.syntax.ExpressionSimple(hydra.python.syntax.Disjunction((hydra.python.syntax.Conjunction((cast(hydra.python.syntax.Inversion, hydra.python.syntax.InversionSimple(hydra.python.syntax.Comparison(hydra.python.syntax.BitwiseOr(Nothing(), hydra.python.syntax.BitwiseXor(Nothing(), hydra.python.syntax.BitwiseAnd(Nothing(), hydra.python.syntax.ShiftExpression(Nothing(), hydra.python.syntax.Sum(Nothing(), hydra.python.syntax.Term(Nothing(), cast(hydra.python.syntax.Factor, hydra.python.syntax.FactorSimple(hydra.python.syntax.Power(hydra.python.syntax.AwaitPrimary(False, cast(hydra.python.syntax.Primary, hydra.python.syntax.PrimarySimple(cast(hydra.python.syntax.Atom, hydra.python.syntax.AtomName(py_name()))))), Nothing()))))))))), ()))),)),))))
    namespaces = env.namespaces
    @lru_cache(1)
    def focus_pair() -> tuple[hydra.packaging.Namespace, hydra.python.syntax.DottedName]:
        return namespaces.focus
    @lru_cache(1)
    def focus_ns() -> hydra.packaging.Namespace:
        return hydra.lib.pairs.first(focus_pair())
    @lru_cache(1)
    def mns() -> Maybe[hydra.packaging.Namespace]:
        return hydra.names.namespace_of(name)
    @lru_cache(1)
    def same_namespace() -> bool:
        return hydra.lib.maybes.maybe((lambda : False), (lambda ns: hydra.lib.equality.equal(ns, focus_ns())), mns())
    return hydra.lib.logic.if_else(hydra.lib.logic.and_(quoted, same_namespace()), (lambda : cast(hydra.python.syntax.Expression, hydra.python.syntax.ExpressionSimple(hydra.python.syntax.Disjunction((hydra.python.syntax.Conjunction((cast(hydra.python.syntax.Inversion, hydra.python.syntax.InversionSimple(hydra.python.syntax.Comparison(hydra.python.syntax.BitwiseOr(Nothing(), hydra.python.syntax.BitwiseXor(Nothing(), hydra.python.syntax.BitwiseAnd(Nothing(), hydra.python.syntax.ShiftExpression(Nothing(), hydra.python.syntax.Sum(Nothing(), hydra.python.syntax.Term(Nothing(), cast(hydra.python.syntax.Factor, hydra.python.syntax.FactorSimple(hydra.python.syntax.Power(hydra.python.syntax.AwaitPrimary(False, cast(hydra.python.syntax.Primary, hydra.python.syntax.PrimarySimple(cast(hydra.python.syntax.Atom, hydra.python.syntax.AtomString(hydra.python.syntax.String(py_name().value, hydra.python.syntax.QuoteStyle.DOUBLE)))))), Nothing()))))))))), ()))),)),))))), (lambda : unquoted()))
def term_variable_reference(v1: hydra.python.environment.PythonEnvironment, v2: hydra.core.Name) -> hydra.python.syntax.Expression:
    r"""Reference a term variable as a Python expression."""
    return variable_reference(hydra.util.CaseConvention.LOWER_SNAKE, False, v1, v2)
def type_variable_reference(v1: hydra.python.environment.PythonEnvironment, v2: hydra.core.Name) -> hydra.python.syntax.Expression:
    r"""Reference a type variable as a Python expression."""
    return variable_reference(hydra.util.CaseConvention.PASCAL, False, v1, v2)
def variant_name(is_qualified: bool, env: hydra.python.environment.PythonEnvironment, tname: hydra.core.Name, fname: hydra.core.Name) -> hydra.python.syntax.Name:
    r"""Generate a variant name from type name and field name."""
    return encode_name(is_qualified, hydra.util.CaseConvention.PASCAL, env, hydra.core.Name(hydra.lib.strings.cat2(tname.value, hydra.formatting.capitalize(fname.value))))
