# Note: this is an automatically generated file. Do not edit.
r"""Python serializer: converts Python AST to concrete syntax."""
from __future__ import annotations
from collections.abc import Callable
from decimal import Decimal
from functools import lru_cache
from hydra.dsl.python import Just, Maybe, Nothing, frozenlist
from typing import cast
import hydra.constants
import hydra.core
import hydra.lib.equality
import hydra.lib.lists
import hydra.lib.literals
import hydra.lib.logic
import hydra.lib.maybes
import hydra.lib.strings
import hydra.python.syntax
import hydra.serialization
def encode_name(n: hydra.python.syntax.Name) -> hydra.ast.Expr:
    r"""Serialize a Python name/identifier."""
    return hydra.serialization.cst(n.value)
def encode_lambda_param_no_default(p: hydra.python.syntax.LambdaParamNoDefault) -> hydra.ast.Expr:
    r"""Serialize a lambda parameter without default."""
    return encode_name(p.value)
def encode_lambda_parameters(lp: hydra.python.syntax.LambdaParameters) -> hydra.ast.Expr:
    r"""Serialize lambda parameters."""
    nodef = lp.param_no_default
    return hydra.serialization.comma_sep(hydra.serialization.inline_style, hydra.lib.lists.map((lambda x1: encode_lambda_param_no_default(x1)), nodef))
def python_float_literal_text(s: str) -> str:
    return hydra.lib.logic.if_else(hydra.lib.equality.equal(s, "NaN"), (lambda : "float('nan')"), (lambda : hydra.lib.logic.if_else(hydra.lib.equality.equal(s, "Infinity"), (lambda : "float('inf')"), (lambda : hydra.lib.logic.if_else(hydra.lib.equality.equal(s, "-Infinity"), (lambda : "float('-inf')"), (lambda : s))))))
def encode_number(num: hydra.python.syntax.Number) -> hydra.ast.Expr:
    r"""Serialize a Python number literal."""
    match num:
        case hydra.python.syntax.NumberFloat(value=f):
            return hydra.serialization.cst(python_float_literal_text(hydra.lib.literals.show_bigfloat(f)))
        case hydra.python.syntax.NumberInteger(value=i):
            return hydra.serialization.cst(hydra.lib.literals.show_bigint(i))
        case _:
            raise AssertionError("Unreachable: all variants handled")
def escape_python_string(double_quoted: bool, s: str) -> str:
    r"""Escape special characters in a Python string and wrap in quotes."""
    def replace(old: str, new: str, str: str) -> str:
        return hydra.lib.strings.intercalate(new, hydra.lib.strings.split_on(old, str))
    @lru_cache(1)
    def s1() -> str:
        return replace("\\", "\\\\", s)
    @lru_cache(1)
    def s2() -> str:
        return replace("\x00", "\\x00", s1())
    @lru_cache(1)
    def s3() -> str:
        return replace("\n", "\\n", s2())
    @lru_cache(1)
    def s4() -> str:
        return replace("\t", "\\t", s3())
    @lru_cache(1)
    def s5() -> str:
        return replace("\r", "\\r", s4())
    @lru_cache(1)
    def escaped() -> str:
        return hydra.lib.logic.if_else(double_quoted, (lambda : replace("\"", "\\\"", s5())), (lambda : replace("'", "\\'", s5())))
    @lru_cache(1)
    def quote() -> str:
        return hydra.lib.logic.if_else(double_quoted, (lambda : "\""), (lambda : "'"))
    return hydra.lib.strings.cat2(quote(), hydra.lib.strings.cat2(escaped(), quote()))
def encode_string(s: hydra.python.syntax.String) -> hydra.ast.Expr:
    r"""Serialize a Python string literal."""
    content = s.value
    style = s.quote_style
    match style:
        case hydra.python.syntax.QuoteStyle.SINGLE:
            return hydra.serialization.cst(escape_python_string(False, content))
        case hydra.python.syntax.QuoteStyle.DOUBLE:
            return hydra.serialization.cst(escape_python_string(True, content))
        case hydra.python.syntax.QuoteStyle.TRIPLE:
            return hydra.serialization.no_sep((hydra.serialization.cst("r\"\"\""), hydra.serialization.cst(content), hydra.serialization.cst("\"\"\"")))
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_args(args: hydra.python.syntax.Args) -> hydra.ast.Expr:
    r"""Serialize function arguments."""
    pos = args.positional
    ks = args.kwarg_or_starred
    kss = args.kwarg_or_double_starred
    return hydra.serialization.comma_sep(hydra.serialization.inline_style, hydra.lib.lists.concat((hydra.lib.lists.map((lambda x1: encode_pos_arg(x1)), pos), hydra.lib.lists.map((lambda x1: encode_kwarg_or_starred(x1)), ks), hydra.lib.lists.map((lambda x1: encode_kwarg_or_double_starred(x1)), kss))))
def encode_assignment_expression(ae: hydra.python.syntax.AssignmentExpression) -> hydra.ast.Expr:
    r"""Serialize an assignment expression (walrus operator)."""
    name = ae.name
    expr = ae.expression
    return hydra.serialization.space_sep((encode_name(name), hydra.serialization.cst(":="), encode_expression(expr)))
def encode_atom(atom: hydra.python.syntax.Atom) -> hydra.ast.Expr:
    r"""Serialize a Python atom (literal or basic expression)."""
    match atom:
        case hydra.python.syntax.AtomDict(value=d):
            return encode_dict(d)
        case hydra.python.syntax.AtomDictcomp():
            return hydra.serialization.cst("{...}")
        case hydra.python.syntax.AtomEllipsis():
            return hydra.serialization.cst("...")
        case hydra.python.syntax.AtomFalse():
            return hydra.serialization.cst("False")
        case hydra.python.syntax.AtomGenexp():
            return hydra.serialization.cst("(...)")
        case hydra.python.syntax.AtomGroup(value=g):
            return encode_group(g)
        case hydra.python.syntax.AtomList(value=l):
            return encode_list(l)
        case hydra.python.syntax.AtomListcomp():
            return hydra.serialization.cst("[...]")
        case hydra.python.syntax.AtomName(value=n):
            return encode_name(n)
        case hydra.python.syntax.AtomNone():
            return hydra.serialization.cst("None")
        case hydra.python.syntax.AtomNumber(value=n2):
            return encode_number(n2)
        case hydra.python.syntax.AtomSet(value=s):
            return encode_set(s)
        case hydra.python.syntax.AtomSetcomp():
            return hydra.serialization.cst("{...}")
        case hydra.python.syntax.AtomString(value=s2):
            return encode_string(s2)
        case hydra.python.syntax.AtomTrue():
            return hydra.serialization.cst("True")
        case hydra.python.syntax.AtomTuple(value=t):
            return encode_tuple(t)
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_await_primary(ap: hydra.python.syntax.AwaitPrimary) -> hydra.ast.Expr:
    r"""Serialize an await primary expression."""
    await_ = ap.await_
    primary = ap.primary
    return hydra.lib.logic.if_else(await_, (lambda : hydra.serialization.space_sep((hydra.serialization.cst("await"), encode_primary(primary)))), (lambda : encode_primary(primary)))
def encode_bitwise_and(band: hydra.python.syntax.BitwiseAnd) -> hydra.ast.Expr:
    r"""Serialize a bitwise AND expression."""
    lhs = band.lhs
    rhs = band.rhs
    return hydra.serialization.space_sep(hydra.lib.maybes.cat((hydra.lib.maybes.map((lambda l: hydra.serialization.space_sep((encode_bitwise_and(l), hydra.serialization.cst("&")))), lhs), Just(encode_shift_expression(rhs)))))
def encode_bitwise_or(bor: hydra.python.syntax.BitwiseOr) -> hydra.ast.Expr:
    r"""Serialize a bitwise OR expression."""
    lhs = bor.lhs
    rhs = bor.rhs
    return hydra.serialization.space_sep(hydra.lib.maybes.cat((hydra.lib.maybes.map((lambda l: hydra.serialization.space_sep((encode_bitwise_or(l), hydra.serialization.cst("|")))), lhs), Just(encode_bitwise_xor(rhs)))))
def encode_bitwise_xor(bxor: hydra.python.syntax.BitwiseXor) -> hydra.ast.Expr:
    r"""Serialize a bitwise XOR expression."""
    lhs = bxor.lhs
    rhs = bxor.rhs
    return hydra.serialization.space_sep(hydra.lib.maybes.cat((hydra.lib.maybes.map((lambda l: hydra.serialization.space_sep((encode_bitwise_xor(l), hydra.serialization.cst("^")))), lhs), Just(encode_bitwise_and(rhs)))))
def encode_comparison(cmp: hydra.python.syntax.Comparison) -> hydra.ast.Expr:
    r"""Serialize a comparison expression."""
    return encode_bitwise_or(cmp.lhs)
def encode_conditional(c: hydra.python.syntax.Conditional) -> hydra.ast.Expr:
    r"""Serialize a conditional expression (ternary)."""
    body = c.body
    cond = c.if_
    else_expr = c.else_
    return hydra.serialization.space_sep((encode_disjunction(body), hydra.serialization.cst("if"), encode_disjunction(cond), hydra.serialization.cst("else"), encode_expression(else_expr)))
def encode_conjunction(c: hydra.python.syntax.Conjunction) -> hydra.ast.Expr:
    r"""Serialize a conjunction (and expression)."""
    return hydra.serialization.symbol_sep("and", hydra.serialization.inline_style, hydra.lib.lists.map((lambda x1: encode_inversion(x1)), c.value))
def encode_dict(d: hydra.python.syntax.Dict) -> hydra.ast.Expr:
    r"""Serialize a Python dictionary."""
    return hydra.serialization.curly_braces_list(Nothing(), hydra.serialization.half_block_style, hydra.lib.lists.map((lambda x1: encode_double_starred_kvpair(x1)), d.value))
def encode_disjunction(d: hydra.python.syntax.Disjunction) -> hydra.ast.Expr:
    r"""Serialize a disjunction (or expression)."""
    return hydra.serialization.symbol_sep("or", hydra.serialization.inline_style, hydra.lib.lists.map((lambda x1: encode_conjunction(x1)), d.value))
def encode_double_starred_kvpair(dskv: hydra.python.syntax.DoubleStarredKvpair) -> hydra.ast.Expr:
    r"""Serialize a double-starred key-value pair."""
    match dskv:
        case hydra.python.syntax.DoubleStarredKvpairPair(value=p):
            return encode_kvpair(p)
        case hydra.python.syntax.DoubleStarredKvpairStarred(value=e):
            return hydra.serialization.no_sep((hydra.serialization.cst("**"), encode_bitwise_or(e)))
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_expression(expr: hydra.python.syntax.Expression) -> hydra.ast.Expr:
    r"""Serialize a Python expression."""
    match expr:
        case hydra.python.syntax.ExpressionSimple(value=d):
            return encode_disjunction(d)
        case hydra.python.syntax.ExpressionConditional(value=c):
            return encode_conditional(c)
        case hydra.python.syntax.ExpressionLambda(value=l):
            return encode_lambda(l)
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_factor(f: hydra.python.syntax.Factor) -> hydra.ast.Expr:
    r"""Serialize a factor expression."""
    match f:
        case hydra.python.syntax.FactorPositive(value=inner):
            return hydra.serialization.no_sep((hydra.serialization.cst("+"), encode_factor(inner)))
        case hydra.python.syntax.FactorNegative(value=inner2):
            return hydra.serialization.no_sep((hydra.serialization.cst("-"), encode_factor(inner2)))
        case hydra.python.syntax.FactorComplement(value=inner3):
            return hydra.serialization.no_sep((hydra.serialization.cst("~"), encode_factor(inner3)))
        case hydra.python.syntax.FactorSimple(value=p):
            return encode_power(p)
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_group(g: hydra.python.syntax.Group) -> hydra.ast.Expr:
    r"""Serialize a parenthesized group."""
    match g:
        case hydra.python.syntax.GroupExpression(value=ne):
            return encode_named_expression(ne)
        case hydra.python.syntax.GroupYield():
            return hydra.serialization.cst("(yield ...)")
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_inversion(i: hydra.python.syntax.Inversion) -> hydra.ast.Expr:
    r"""Serialize an inversion (not expression)."""
    match i:
        case hydra.python.syntax.InversionNot(value=other):
            return hydra.serialization.space_sep((hydra.serialization.cst("not"), encode_inversion(other)))
        case hydra.python.syntax.InversionSimple(value=c):
            return encode_comparison(c)
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_kvpair(kv: hydra.python.syntax.Kvpair) -> hydra.ast.Expr:
    r"""Serialize a key-value pair."""
    k = kv.key
    v = kv.value
    return hydra.serialization.space_sep((hydra.serialization.no_sep((encode_expression(k), hydra.serialization.cst(":"))), encode_expression(v)))
def encode_kwarg(k: hydra.python.syntax.Kwarg) -> hydra.ast.Expr:
    r"""Serialize a keyword argument."""
    name = k.name
    expr = k.value
    return hydra.serialization.no_sep((encode_name(name), hydra.serialization.cst("="), encode_expression(expr)))
def encode_kwarg_or_double_starred(kds: hydra.python.syntax.KwargOrDoubleStarred) -> hydra.ast.Expr:
    r"""Serialize a kwarg or double starred."""
    match kds:
        case hydra.python.syntax.KwargOrDoubleStarredKwarg(value=k):
            return encode_kwarg(k)
        case hydra.python.syntax.KwargOrDoubleStarredDoubleStarred(value=e):
            return hydra.serialization.no_sep((hydra.serialization.cst("**"), encode_expression(e)))
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_kwarg_or_starred(ks: hydra.python.syntax.KwargOrStarred) -> hydra.ast.Expr:
    r"""Serialize a kwarg or starred."""
    match ks:
        case hydra.python.syntax.KwargOrStarredKwarg(value=k):
            return encode_kwarg(k)
        case hydra.python.syntax.KwargOrStarredStarred(value=se):
            return encode_starred_expression(se)
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_lambda(l: hydra.python.syntax.Lambda) -> hydra.ast.Expr:
    r"""Serialize a lambda expression."""
    params = l.params
    body = l.body
    return hydra.serialization.parens(hydra.serialization.space_sep((hydra.serialization.cst("lambda"), hydra.serialization.no_sep((encode_lambda_parameters(params), hydra.serialization.cst(":"))), encode_expression(body))))
def encode_list(l: hydra.python.syntax.List) -> hydra.ast.Expr:
    r"""Serialize a Python list."""
    return hydra.serialization.bracket_list_adaptive(hydra.lib.lists.map((lambda x1: encode_star_named_expression(x1)), l.value))
def encode_named_expression(ne: hydra.python.syntax.NamedExpression) -> hydra.ast.Expr:
    r"""Serialize a named expression."""
    match ne:
        case hydra.python.syntax.NamedExpressionSimple(value=e):
            return encode_expression(e)
        case hydra.python.syntax.NamedExpressionAssignment(value=ae):
            return encode_assignment_expression(ae)
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_pos_arg(pa: hydra.python.syntax.PosArg) -> hydra.ast.Expr:
    r"""Serialize a positional argument."""
    match pa:
        case hydra.python.syntax.PosArgStarred(value=se):
            return encode_starred_expression(se)
        case hydra.python.syntax.PosArgAssignment(value=ae):
            return encode_assignment_expression(ae)
        case hydra.python.syntax.PosArgExpression(value=e):
            return encode_expression(e)
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_power(p: hydra.python.syntax.Power) -> hydra.ast.Expr:
    r"""Serialize a power expression."""
    lhs = p.lhs
    rhs = p.rhs
    return hydra.serialization.space_sep(hydra.lib.maybes.cat((Just(encode_await_primary(lhs)), hydra.lib.maybes.map((lambda r: hydra.serialization.space_sep((hydra.serialization.cst("**"), encode_factor(r)))), rhs))))
def encode_primary(p: hydra.python.syntax.Primary) -> hydra.ast.Expr:
    r"""Serialize a primary expression."""
    match p:
        case hydra.python.syntax.PrimarySimple(value=a):
            return encode_atom(a)
        case hydra.python.syntax.PrimaryCompound(value=pwr):
            return encode_primary_with_rhs(pwr)
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_primary_rhs(rhs: hydra.python.syntax.PrimaryRhs) -> hydra.ast.Expr:
    r"""Serialize a primary RHS."""
    match rhs:
        case hydra.python.syntax.PrimaryRhsCall(value=args):
            return hydra.serialization.no_sep((hydra.serialization.cst("("), encode_args(args), hydra.serialization.cst(")")))
        case hydra.python.syntax.PrimaryRhsProject(value=name):
            return hydra.serialization.no_sep((hydra.serialization.cst("."), encode_name(name)))
        case hydra.python.syntax.PrimaryRhsSlices(value=slices):
            return hydra.serialization.no_sep((hydra.serialization.cst("["), encode_slices(slices), hydra.serialization.cst("]")))
        case hydra.python.syntax.PrimaryRhsGenexp():
            return hydra.serialization.cst("[...]")
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_primary_with_rhs(pwr: hydra.python.syntax.PrimaryWithRhs) -> hydra.ast.Expr:
    r"""Serialize a primary with RHS."""
    prim = pwr.primary
    rhs = pwr.rhs
    return hydra.serialization.no_sep((encode_primary(prim), encode_primary_rhs(rhs)))
def encode_set(s: hydra.python.syntax.Set) -> hydra.ast.Expr:
    r"""Serialize a Python set."""
    return hydra.serialization.braces_list_adaptive(hydra.lib.lists.map((lambda x1: encode_star_named_expression(x1)), s.value))
def encode_shift_expression(se: hydra.python.syntax.ShiftExpression) -> hydra.ast.Expr:
    r"""Serialize a shift expression."""
    return encode_sum(se.rhs)
def encode_slice(s: hydra.python.syntax.Slice) -> hydra.ast.Expr:
    r"""Serialize a slice."""
    match s:
        case hydra.python.syntax.SliceNamed(value=ne):
            return encode_named_expression(ne)
        case hydra.python.syntax.SliceSlice_():
            return hydra.serialization.cst(":")
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_slice_or_starred_expression(s: hydra.python.syntax.SliceOrStarredExpression) -> hydra.ast.Expr:
    r"""Serialize a slice or starred expression."""
    match s:
        case hydra.python.syntax.SliceOrStarredExpressionSlice(value=sl):
            return encode_slice(sl)
        case hydra.python.syntax.SliceOrStarredExpressionStarred(value=se):
            return encode_starred_expression(se)
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_slices(s: hydra.python.syntax.Slices) -> hydra.ast.Expr:
    r"""Serialize slices."""
    hd = s.head
    tl = s.tail
    return hydra.serialization.comma_sep(hydra.serialization.inline_style, hydra.lib.lists.cons(encode_slice(hd), hydra.lib.lists.map((lambda x1: encode_slice_or_starred_expression(x1)), tl)))
def encode_star_named_expression(sne: hydra.python.syntax.StarNamedExpression) -> hydra.ast.Expr:
    r"""Serialize a star named expression."""
    match sne:
        case hydra.python.syntax.StarNamedExpressionStar(value=bor):
            return hydra.serialization.no_sep((hydra.serialization.cst("*"), encode_bitwise_or(bor)))
        case hydra.python.syntax.StarNamedExpressionSimple(value=ne):
            return encode_named_expression(ne)
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_starred_expression(se: hydra.python.syntax.StarredExpression) -> hydra.ast.Expr:
    r"""Serialize a starred expression."""
    return hydra.serialization.no_sep((hydra.serialization.cst("*"), encode_expression(se.value)))
def encode_sum(s: hydra.python.syntax.Sum) -> hydra.ast.Expr:
    r"""Serialize a sum expression."""
    return encode_term(s.rhs)
def encode_term(t: hydra.python.syntax.Term) -> hydra.ast.Expr:
    r"""Serialize a term expression."""
    return encode_factor(t.rhs)
def encode_tuple(t: hydra.python.syntax.Tuple) -> hydra.ast.Expr:
    r"""Serialize a Python tuple."""
    es = t.value
    return hydra.lib.maybes.from_maybe((lambda : hydra.serialization.paren_list(False, hydra.lib.lists.map((lambda x1: encode_star_named_expression(x1)), es))), hydra.lib.maybes.map((lambda first_es: hydra.lib.logic.if_else(hydra.lib.equality.equal(hydra.lib.lists.length(es), 1), (lambda : hydra.serialization.parens(hydra.serialization.no_sep((encode_star_named_expression(first_es), hydra.serialization.cst(","))))), (lambda : hydra.serialization.paren_list(False, hydra.lib.lists.map((lambda x1: encode_star_named_expression(x1)), es))))), hydra.lib.lists.maybe_head(es)))
def encode_star_expression(se: hydra.python.syntax.StarExpression) -> hydra.ast.Expr:
    r"""Serialize a star expression."""
    match se:
        case hydra.python.syntax.StarExpressionStar(value=bor):
            return hydra.serialization.no_sep((hydra.serialization.cst("*"), encode_bitwise_or(bor)))
        case hydra.python.syntax.StarExpressionSimple(value=e):
            return encode_expression(e)
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_annotated_rhs(arhs: hydra.python.syntax.AnnotatedRhs):
    def _hoist_hydra_python_serde_encode_annotated_rhs_1(v1):
        match v1:
            case hydra.python.syntax.AnnotatedRhsStar(value=ses):
                return hydra.serialization.comma_sep(hydra.serialization.inline_style, hydra.lib.lists.map((lambda x1: encode_star_expression(x1)), ses))
            case hydra.python.syntax.AnnotatedRhsYield():
                return hydra.serialization.cst("yield ...")
            case _:
                raise AssertionError("Unreachable: all variants handled")
    return hydra.serialization.space_sep((hydra.serialization.cst("="), _hoist_hydra_python_serde_encode_annotated_rhs_1(arhs)))
def encode_single_target(st: hydra.python.syntax.SingleTarget) -> hydra.ast.Expr:
    r"""Serialize a single target."""
    match st:
        case hydra.python.syntax.SingleTargetName(value=n):
            return encode_name(n)
        case hydra.python.syntax.SingleTargetParens():
            return hydra.serialization.cst("(...)")
        case hydra.python.syntax.SingleTargetSubscriptAttributeTarget():
            return hydra.serialization.cst("...")
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_typed_assignment(ta: hydra.python.syntax.TypedAssignment) -> hydra.ast.Expr:
    r"""Serialize a typed assignment."""
    lhs = ta.lhs
    typ = ta.type
    rhs = ta.rhs
    return hydra.serialization.space_sep(hydra.lib.maybes.cat((Just(hydra.serialization.no_sep((encode_single_target(lhs), hydra.serialization.cst(":")))), Just(encode_expression(typ)), hydra.lib.maybes.map((lambda x1: encode_annotated_rhs(x1)), rhs))))
def encode_star_atom(sa: hydra.python.syntax.StarAtom) -> hydra.ast.Expr:
    r"""Serialize a star atom."""
    match sa:
        case hydra.python.syntax.StarAtomName(value=n):
            return encode_name(n)
        case hydra.python.syntax.StarAtomTargetWithStarAtom():
            return hydra.serialization.cst("(...)")
        case hydra.python.syntax.StarAtomStarTargetsTupleSeq():
            return hydra.serialization.cst("(...)")
        case hydra.python.syntax.StarAtomStarTargetsListSeq():
            return hydra.serialization.cst("[...]")
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_t_primary(tp: hydra.python.syntax.TPrimary) -> hydra.ast.Expr:
    r"""Serialize a target-side primary expression."""
    match tp:
        case hydra.python.syntax.TPrimaryAtom(value=a):
            return encode_atom(a)
        case hydra.python.syntax.TPrimaryPrimaryAndName(value=pn):
            return encode_t_primary_and_name(pn)
        case hydra.python.syntax.TPrimaryPrimaryAndSlices():
            return hydra.serialization.cst("...")
        case hydra.python.syntax.TPrimaryPrimaryAndGenexp():
            return hydra.serialization.cst("...")
        case hydra.python.syntax.TPrimaryPrimaryAndArguments():
            return hydra.serialization.cst("...")
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_t_primary_and_name(pn: hydra.python.syntax.TPrimaryAndName) -> hydra.ast.Expr:
    r"""Serialize a TPrimaryAndName as primary.name."""
    prim = pn.primary
    name_ = pn.name
    return hydra.serialization.no_sep((encode_t_primary(prim), hydra.serialization.cst("."), encode_name(name_)))
def encode_target_with_star_atom(t: hydra.python.syntax.TargetWithStarAtom) -> hydra.ast.Expr:
    r"""Serialize a target with star atom."""
    match t:
        case hydra.python.syntax.TargetWithStarAtomAtom(value=a):
            return encode_star_atom(a)
        case hydra.python.syntax.TargetWithStarAtomProject(value=pn):
            return encode_t_primary_and_name(pn)
        case hydra.python.syntax.TargetWithStarAtomSlices():
            return hydra.serialization.cst("...")
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_star_target(st: hydra.python.syntax.StarTarget) -> hydra.ast.Expr:
    r"""Serialize a star target."""
    match st:
        case hydra.python.syntax.StarTargetUnstarred(value=t):
            return encode_target_with_star_atom(t)
        case hydra.python.syntax.StarTargetStarred(value=inner):
            return hydra.serialization.no_sep((hydra.serialization.cst("*"), encode_star_target(inner)))
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_untyped_assignment(ua: hydra.python.syntax.UntypedAssignment) -> hydra.ast.Expr:
    r"""Serialize an untyped assignment."""
    targets = ua.targets
    rhs = ua.rhs
    return hydra.serialization.space_sep(hydra.lib.lists.concat((hydra.lib.lists.map((lambda x1: encode_star_target(x1)), targets), (encode_annotated_rhs(rhs),))))
def encode_assignment(a: hydra.python.syntax.Assignment) -> hydra.ast.Expr:
    r"""Serialize an assignment."""
    match a:
        case hydra.python.syntax.AssignmentTyped(value=t):
            return encode_typed_assignment(t)
        case hydra.python.syntax.AssignmentUntyped(value=u):
            return encode_untyped_assignment(u)
        case hydra.python.syntax.AssignmentAug():
            return hydra.serialization.cst("... += ...")
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_dotted_name(dn: hydra.python.syntax.DottedName) -> hydra.ast.Expr:
    r"""Serialize a dotted name (e.g., module.submodule)."""
    return hydra.serialization.cst(hydra.lib.strings.intercalate(".", hydra.lib.lists.map((lambda n: n.value), dn.value)))
def encode_import_from_as_name(ifan: hydra.python.syntax.ImportFromAsName) -> hydra.ast.Expr:
    r"""Serialize an import from as name."""
    name = ifan.name
    alias = ifan.as_
    return hydra.lib.maybes.maybe((lambda : encode_name(name)), (lambda a: hydra.serialization.space_sep((encode_name(name), hydra.serialization.cst("as"), encode_name(a)))), alias)
def encode_import_from_targets(t: hydra.python.syntax.ImportFromTargets) -> hydra.ast.Expr:
    r"""Serialize import from targets."""
    match t:
        case hydra.python.syntax.ImportFromTargetsSimple(value=names):
            return hydra.serialization.comma_sep(hydra.serialization.inline_style, hydra.lib.lists.map((lambda x1: encode_import_from_as_name(x1)), names))
        case hydra.python.syntax.ImportFromTargetsParens(value=names2):
            return hydra.serialization.no_sep((hydra.serialization.cst("("), hydra.serialization.comma_sep(hydra.serialization.inline_style, hydra.lib.lists.map((lambda x1: encode_import_from_as_name(x1)), names2)), hydra.serialization.cst(")")))
        case hydra.python.syntax.ImportFromTargetsStar():
            return hydra.serialization.cst("*")
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_relative_import_prefix(p: hydra.python.syntax.RelativeImportPrefix) -> hydra.ast.Expr:
    r"""Serialize a relative import prefix."""
    match p:
        case hydra.python.syntax.RelativeImportPrefix.DOT:
            return hydra.serialization.cst(".")
        case hydra.python.syntax.RelativeImportPrefix.ELLIPSIS:
            return hydra.serialization.cst("...")
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_import_from(if_: hydra.python.syntax.ImportFrom) -> hydra.ast.Expr:
    r"""Serialize an import from statement."""
    prefixes = if_.prefixes
    name = if_.dotted_name
    targets = if_.targets
    @lru_cache(1)
    def lhs() -> hydra.ast.Expr:
        return hydra.serialization.no_sep(hydra.lib.maybes.cat(hydra.lib.lists.concat((hydra.lib.lists.map((lambda p: Just(encode_relative_import_prefix(p))), prefixes), (hydra.lib.maybes.map((lambda x1: encode_dotted_name(x1)), name),)))))
    return hydra.serialization.space_sep((hydra.serialization.cst("from"), lhs(), hydra.serialization.cst("import"), encode_import_from_targets(targets)))
def encode_dotted_as_name(dan: hydra.python.syntax.DottedAsName) -> hydra.ast.Expr:
    r"""Serialize a dotted as name."""
    name = dan.name
    alias = dan.as_
    return hydra.serialization.space_sep(hydra.lib.maybes.cat((Just(encode_dotted_name(name)), hydra.lib.maybes.map((lambda a: hydra.serialization.space_sep((hydra.serialization.cst("as"), encode_name(a)))), alias))))
def encode_import_name(in_: hydra.python.syntax.ImportName) -> hydra.ast.Expr:
    r"""Serialize an import name."""
    return hydra.serialization.space_sep((hydra.serialization.cst("import"), hydra.serialization.comma_sep(hydra.serialization.inline_style, hydra.lib.lists.map((lambda x1: encode_dotted_as_name(x1)), in_.value))))
def encode_import_statement(is_: hydra.python.syntax.ImportStatement) -> hydra.ast.Expr:
    r"""Serialize an import statement."""
    match is_:
        case hydra.python.syntax.ImportStatementName(value=n):
            return encode_import_name(n)
        case hydra.python.syntax.ImportStatementFrom(value=f):
            return encode_import_from(f)
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_raise_expression(re: hydra.python.syntax.RaiseExpression) -> hydra.ast.Expr:
    r"""Serialize a raise expression."""
    expr = re.expression
    from_ = re.from_
    return hydra.serialization.space_sep(hydra.lib.maybes.cat((Just(encode_expression(expr)), hydra.lib.maybes.map((lambda f: hydra.serialization.space_sep((hydra.serialization.cst("from"), encode_expression(f)))), from_))))
def encode_raise_statement(rs: hydra.python.syntax.RaiseStatement) -> hydra.ast.Expr:
    r"""Serialize a raise statement."""
    return hydra.serialization.space_sep(hydra.lib.maybes.cat((Just(hydra.serialization.cst("raise")), hydra.lib.maybes.map((lambda x1: encode_raise_expression(x1)), rs.value))))
def encode_return_statement(rs: hydra.python.syntax.ReturnStatement) -> hydra.ast.Expr:
    r"""Serialize a return statement."""
    return hydra.serialization.space_sep((hydra.serialization.cst("return"), hydra.serialization.comma_sep(hydra.serialization.inline_style, hydra.lib.lists.map((lambda x1: encode_star_expression(x1)), rs.value))))
def encode_simple_type_parameter(stp: hydra.python.syntax.SimpleTypeParameter) -> hydra.ast.Expr:
    r"""Serialize a simple type parameter."""
    return encode_name(stp.name)
def encode_type_parameter(tp: hydra.python.syntax.TypeParameter) -> hydra.ast.Expr:
    r"""Serialize a type parameter."""
    match tp:
        case hydra.python.syntax.TypeParameterSimple(value=s):
            return encode_simple_type_parameter(s)
        case hydra.python.syntax.TypeParameterStar():
            return hydra.serialization.cst("*...")
        case hydra.python.syntax.TypeParameterDoubleStar():
            return hydra.serialization.cst("**...")
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_type_alias(ta: hydra.python.syntax.TypeAlias) -> hydra.ast.Expr:
    r"""Serialize a type alias."""
    name = ta.name
    tparams = ta.type_params
    expr = ta.expression
    @lru_cache(1)
    def alias() -> hydra.ast.Expr:
        return hydra.serialization.no_sep(hydra.lib.maybes.cat((Just(encode_name(name)), hydra.lib.logic.if_else(hydra.lib.lists.null(tparams), (lambda : Nothing()), (lambda : Just(hydra.serialization.bracket_list(hydra.serialization.inline_style, hydra.lib.lists.map((lambda x1: encode_type_parameter(x1)), tparams))))))))
    return hydra.serialization.space_sep((hydra.serialization.cst("type"), alias(), hydra.serialization.cst("="), encode_expression(expr)))
def encode_simple_statement(ss: hydra.python.syntax.SimpleStatement) -> hydra.ast.Expr:
    r"""Serialize a simple (single-line) Python statement."""
    match ss:
        case hydra.python.syntax.SimpleStatementAssignment(value=a):
            return encode_assignment(a)
        case hydra.python.syntax.SimpleStatementStarExpressions(value=es):
            return hydra.serialization.newline_sep(hydra.lib.lists.map((lambda x1: encode_star_expression(x1)), es))
        case hydra.python.syntax.SimpleStatementReturn(value=r):
            return encode_return_statement(r)
        case hydra.python.syntax.SimpleStatementRaise(value=r2):
            return encode_raise_statement(r2)
        case hydra.python.syntax.SimpleStatementPass():
            return hydra.serialization.cst("pass")
        case hydra.python.syntax.SimpleStatementBreak():
            return hydra.serialization.cst("break")
        case hydra.python.syntax.SimpleStatementContinue():
            return hydra.serialization.cst("continue")
        case hydra.python.syntax.SimpleStatementImport(value=i):
            return encode_import_statement(i)
        case hydra.python.syntax.SimpleStatementTypeAlias(value=t):
            return encode_type_alias(t)
        case hydra.python.syntax.SimpleStatementAssert():
            return hydra.serialization.cst("assert ...")
        case hydra.python.syntax.SimpleStatementGlobal():
            return hydra.serialization.cst("global ...")
        case hydra.python.syntax.SimpleStatementNonlocal():
            return hydra.serialization.cst("nonlocal ...")
        case hydra.python.syntax.SimpleStatementDel():
            return hydra.serialization.cst("del ...")
        case _:
            raise TypeError("Unsupported SimpleStatement")
def encode_decorators(decs: hydra.python.syntax.Decorators) -> hydra.ast.Expr:
    r"""Serialize decorators."""
    return hydra.serialization.newline_sep(hydra.lib.lists.map((lambda ne: hydra.serialization.no_sep((hydra.serialization.cst("@"), encode_named_expression(ne)))), decs.value))
def encode_annotation(ann: hydra.python.syntax.Annotation) -> hydra.ast.Expr:
    r"""Serialize a type annotation."""
    return hydra.serialization.space_sep((hydra.serialization.cst(":"), encode_expression(ann.value)))
def encode_param(p: hydra.python.syntax.Param) -> hydra.ast.Expr:
    r"""Serialize a parameter."""
    name = p.name
    ann = p.annotation
    return hydra.serialization.no_sep(hydra.lib.maybes.cat((Just(encode_name(name)), hydra.lib.maybes.map((lambda x1: encode_annotation(x1)), ann))))
def encode_param_no_default(pnd: hydra.python.syntax.ParamNoDefault) -> hydra.ast.Expr:
    r"""Serialize a parameter without default."""
    return encode_param(pnd.param)
def encode_param_no_default_parameters(pndp: hydra.python.syntax.ParamNoDefaultParameters) -> hydra.ast.Expr:
    r"""Serialize parameters without defaults."""
    nodef = pndp.param_no_default
    return hydra.serialization.comma_sep(hydra.serialization.inline_style, hydra.lib.lists.map((lambda x1: encode_param_no_default(x1)), nodef))
def encode_parameters(p: hydra.python.syntax.Parameters) -> hydra.ast.Expr:
    r"""Serialize function parameters."""
    match p:
        case hydra.python.syntax.ParametersParamNoDefault(value=pnd):
            return encode_param_no_default_parameters(pnd)
        case hydra.python.syntax.ParametersSlashNoDefault():
            return hydra.serialization.cst("...")
        case hydra.python.syntax.ParametersSlashWithDefault():
            return hydra.serialization.cst("...")
        case _:
            raise TypeError("Unsupported Parameters")
def encode_guard(g: hydra.python.syntax.Guard) -> hydra.ast.Expr:
    r"""Serialize a guard clause."""
    return hydra.serialization.space_sep((hydra.serialization.cst("if"), encode_named_expression(g.value)))
def encode_pattern_capture_target(pct: hydra.python.syntax.PatternCaptureTarget) -> hydra.ast.Expr:
    r"""Serialize a pattern capture target."""
    return encode_name(pct.value)
def encode_capture_pattern(cp: hydra.python.syntax.CapturePattern) -> hydra.ast.Expr:
    r"""Serialize a capture pattern."""
    return encode_pattern_capture_target(cp.value)
def encode_name_or_attribute(noa: hydra.python.syntax.NameOrAttribute) -> hydra.ast.Expr:
    r"""Serialize a name or attribute."""
    return hydra.serialization.dot_sep(hydra.lib.lists.map((lambda x1: encode_name(x1)), noa.value))
def encode_attribute(attr: hydra.python.syntax.Attribute) -> hydra.ast.Expr:
    r"""Serialize an attribute access."""
    return hydra.serialization.dot_sep(hydra.lib.lists.map((lambda x1: encode_name(x1)), attr.value))
def encode_value_pattern(vp: hydra.python.syntax.ValuePattern) -> hydra.ast.Expr:
    r"""Serialize a value pattern."""
    return encode_attribute(vp.value)
def encode_class_pattern(cp: hydra.python.syntax.ClassPattern) -> hydra.ast.Expr:
    r"""Serialize a class pattern."""
    noa = cp.name_or_attribute
    pos = cp.positional_patterns
    kw = cp.keyword_patterns
    return hydra.serialization.no_sep(hydra.lib.maybes.cat((Just(encode_name_or_attribute(noa)), Just(hydra.serialization.cst("(")), hydra.lib.maybes.map((lambda x1: encode_positional_patterns(x1)), pos), hydra.lib.maybes.map((lambda x1: encode_keyword_patterns(x1)), kw), Just(hydra.serialization.cst(")")))))
def encode_closed_pattern(cp: hydra.python.syntax.ClosedPattern) -> hydra.ast.Expr:
    r"""Serialize a closed pattern."""
    match cp:
        case hydra.python.syntax.ClosedPatternLiteral():
            return hydra.serialization.cst("...")
        case hydra.python.syntax.ClosedPatternCapture(value=c):
            return encode_capture_pattern(c)
        case hydra.python.syntax.ClosedPatternWildcard():
            return hydra.serialization.cst("_")
        case hydra.python.syntax.ClosedPatternValue(value=v):
            return encode_value_pattern(v)
        case hydra.python.syntax.ClosedPatternGroup():
            return hydra.serialization.cst("(...)")
        case hydra.python.syntax.ClosedPatternSequence():
            return hydra.serialization.cst("[...]")
        case hydra.python.syntax.ClosedPatternMapping():
            return hydra.serialization.cst("{...}")
        case hydra.python.syntax.ClosedPatternClass(value=c2):
            return encode_class_pattern(c2)
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_keyword_pattern(kp: hydra.python.syntax.KeywordPattern) -> hydra.ast.Expr:
    r"""Serialize a keyword pattern."""
    name = kp.name
    pat = kp.pattern
    return hydra.serialization.no_sep((encode_name(name), hydra.serialization.cst("="), encode_pattern(pat)))
def encode_keyword_patterns(kp: hydra.python.syntax.KeywordPatterns) -> hydra.ast.Expr:
    r"""Serialize keyword patterns."""
    return hydra.serialization.comma_sep(hydra.serialization.inline_style, hydra.lib.lists.map((lambda x1: encode_keyword_pattern(x1)), kp.value))
def encode_or_pattern(op: hydra.python.syntax.OrPattern) -> hydra.ast.Expr:
    r"""Serialize an or pattern."""
    return hydra.serialization.symbol_sep("|", hydra.serialization.inline_style, hydra.lib.lists.map((lambda x1: encode_closed_pattern(x1)), op.value))
def encode_pattern(p: hydra.python.syntax.Pattern) -> hydra.ast.Expr:
    r"""Serialize a pattern."""
    match p:
        case hydra.python.syntax.PatternOr(value=op):
            return encode_or_pattern(op)
        case hydra.python.syntax.PatternAs():
            return hydra.serialization.cst("... as ...")
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_positional_patterns(pp: hydra.python.syntax.PositionalPatterns) -> hydra.ast.Expr:
    r"""Serialize positional patterns."""
    return hydra.serialization.comma_sep(hydra.serialization.inline_style, hydra.lib.lists.map((lambda x1: encode_pattern(x1)), pp.value))
def encode_patterns(ps: hydra.python.syntax.Patterns) -> hydra.ast.Expr:
    r"""Serialize patterns."""
    match ps:
        case hydra.python.syntax.PatternsPattern(value=p):
            return encode_pattern(p)
        case hydra.python.syntax.PatternsSequence():
            return hydra.serialization.cst("...")
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_subject_expression(se: hydra.python.syntax.SubjectExpression) -> hydra.ast.Expr:
    r"""Serialize a subject expression."""
    match se:
        case hydra.python.syntax.SubjectExpressionSimple(value=ne):
            return encode_named_expression(ne)
        case hydra.python.syntax.SubjectExpressionTuple():
            return hydra.serialization.cst("*...")
        case _:
            raise AssertionError("Unreachable: all variants handled")
def to_python_comments(doc_: str) -> str:
    r"""Convert a doc string to Python comment format. Empty source lines emit `#` (no trailing space) so blank comment lines don't carry trailing whitespace into the generated file."""
    return hydra.lib.logic.if_else(hydra.lib.equality.equal(doc_, ""), (lambda : ""), (lambda : hydra.lib.strings.intercalate("\n", hydra.lib.lists.map((lambda line: hydra.lib.logic.if_else(hydra.lib.equality.equal(line, ""), (lambda : "#"), (lambda : hydra.lib.strings.cat2("# ", line)))), hydra.lib.strings.lines(doc_)))))
def encode_annotated_statement(as_: hydra.python.syntax.AnnotatedStatement) -> hydra.ast.Expr:
    r"""Serialize an annotated statement (with optional doc comment)."""
    doc_ = as_.comment
    stmt = as_.statement
    return hydra.serialization.newline_sep((hydra.serialization.cst(to_python_comments(doc_)), encode_statement(stmt)))
def encode_block(b: hydra.python.syntax.Block) -> hydra.ast.Expr:
    r"""Serialize a block."""
    match b:
        case hydra.python.syntax.BlockIndented(value=groups):
            return hydra.serialization.tab_indent_double_space(hydra.lib.lists.map((lambda stmts: hydra.serialization.newline_sep(hydra.lib.lists.map((lambda x1: encode_statement(x1)), stmts))), groups))
        case hydra.python.syntax.BlockSimple(value=ss):
            return hydra.serialization.semicolon_sep(hydra.lib.lists.map((lambda x1: encode_simple_statement(x1)), ss))
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_case_block(cb: hydra.python.syntax.CaseBlock) -> hydra.ast.Expr:
    r"""Serialize a case block."""
    patterns = cb.patterns
    guard = cb.guard
    body = cb.body
    return hydra.serialization.newline_sep((hydra.serialization.no_sep((hydra.serialization.space_sep(hydra.lib.maybes.cat((Just(hydra.serialization.cst("case")), Just(encode_patterns(patterns)), hydra.lib.maybes.map((lambda x1: encode_guard(x1)), guard)))), hydra.serialization.cst(":"))), encode_block(body)))
def encode_class_definition(cd: hydra.python.syntax.ClassDefinition) -> hydra.ast.Expr:
    r"""Serialize a class definition."""
    decs = cd.decorators
    name = cd.name
    args = cd.arguments
    body = cd.body
    @lru_cache(1)
    def arg_part() -> Maybe[hydra.ast.Expr]:
        return hydra.lib.maybes.map((lambda a: hydra.serialization.no_sep((hydra.serialization.cst("("), encode_args(a), hydra.serialization.cst(")")))), args)
    return hydra.serialization.newline_sep(hydra.lib.maybes.cat((hydra.lib.maybes.map((lambda x1: encode_decorators(x1)), decs), Just(hydra.serialization.no_sep(hydra.lib.maybes.cat((Just(hydra.serialization.space_sep((hydra.serialization.cst("class"), encode_name(name)))), arg_part(), Just(hydra.serialization.cst(":")))))), Just(encode_block(body)))))
def encode_compound_statement(cs: hydra.python.syntax.CompoundStatement) -> hydra.ast.Expr:
    r"""Serialize a compound (multi-line) Python statement."""
    match cs:
        case hydra.python.syntax.CompoundStatementFunction(value=f):
            return encode_function_definition(f)
        case hydra.python.syntax.CompoundStatementIf():
            return hydra.serialization.cst("if ...")
        case hydra.python.syntax.CompoundStatementClassDef(value=c):
            return encode_class_definition(c)
        case hydra.python.syntax.CompoundStatementWith():
            return hydra.serialization.cst("with ...")
        case hydra.python.syntax.CompoundStatementFor():
            return hydra.serialization.cst("for ...")
        case hydra.python.syntax.CompoundStatementTry():
            return hydra.serialization.cst("try ...")
        case hydra.python.syntax.CompoundStatementWhile(value=w):
            return encode_while_statement(w)
        case hydra.python.syntax.CompoundStatementMatch(value=m):
            return encode_match_statement(m)
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_function_def_raw(fdr: hydra.python.syntax.FunctionDefRaw) -> hydra.ast.Expr:
    r"""Serialize a raw function definition."""
    async_ = fdr.async_
    name = fdr.name
    tparams = fdr.type_params
    params = fdr.params
    ret_type = fdr.return_type
    block = fdr.block
    @lru_cache(1)
    def async_kw() -> Maybe[hydra.ast.Expr]:
        return hydra.lib.logic.if_else(async_, (lambda : Just(hydra.serialization.cst("async"))), (lambda : Nothing()))
    @lru_cache(1)
    def tparam_part() -> Maybe[hydra.ast.Expr]:
        return hydra.lib.logic.if_else(hydra.lib.lists.null(tparams), (lambda : Nothing()), (lambda : Just(hydra.serialization.bracket_list(hydra.serialization.inline_style, hydra.lib.lists.map((lambda x1: encode_type_parameter(x1)), tparams)))))
    @lru_cache(1)
    def param_part() -> Maybe[hydra.ast.Expr]:
        return hydra.lib.maybes.map((lambda x1: encode_parameters(x1)), params)
    @lru_cache(1)
    def ret_part() -> Maybe[hydra.ast.Expr]:
        return hydra.lib.maybes.map((lambda t: hydra.serialization.space_sep((hydra.serialization.cst("->"), encode_expression(t)))), ret_type)
    return hydra.serialization.newline_sep((hydra.serialization.no_sep((hydra.serialization.space_sep(hydra.lib.maybes.cat((async_kw(), Just(hydra.serialization.cst("def")), Just(hydra.serialization.no_sep(hydra.lib.maybes.cat((Just(encode_name(name)), tparam_part(), Just(hydra.serialization.cst("(")), param_part(), Just(hydra.serialization.cst(")")))))), ret_part()))), hydra.serialization.cst(":"))), encode_block(block)))
def encode_function_definition(fd: hydra.python.syntax.FunctionDefinition) -> hydra.ast.Expr:
    r"""Serialize a function definition."""
    decs = fd.decorators
    raw = fd.raw
    return hydra.serialization.newline_sep(hydra.lib.maybes.cat((hydra.lib.maybes.map((lambda x1: encode_decorators(x1)), decs), Just(encode_function_def_raw(raw)))))
def encode_match_statement(ms: hydra.python.syntax.MatchStatement) -> hydra.ast.Expr:
    r"""Serialize a match statement."""
    subj = ms.subject
    cases = ms.cases
    return hydra.serialization.newline_sep((hydra.serialization.space_sep((hydra.serialization.cst("match"), hydra.serialization.no_sep((encode_subject_expression(subj), hydra.serialization.cst(":"))))), hydra.serialization.tab_indent_double_space(hydra.lib.lists.map((lambda x1: encode_case_block(x1)), cases))))
def encode_statement(stmt: hydra.python.syntax.Statement) -> hydra.ast.Expr:
    r"""Serialize a Python statement."""
    match stmt:
        case hydra.python.syntax.StatementAnnotated(value=a):
            return encode_annotated_statement(a)
        case hydra.python.syntax.StatementSimple(value=ss):
            return hydra.serialization.newline_sep(hydra.lib.lists.map((lambda x1: encode_simple_statement(x1)), ss))
        case hydra.python.syntax.StatementCompound(value=c):
            return encode_compound_statement(c)
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_while_statement(ws: hydra.python.syntax.WhileStatement) -> hydra.ast.Expr:
    r"""Serialize a while statement."""
    cond = ws.condition
    body = ws.body
    else_ = ws.else_
    return hydra.serialization.newline_sep(hydra.lib.maybes.cat((Just(hydra.serialization.newline_sep((hydra.serialization.space_sep((hydra.serialization.cst("while"), hydra.serialization.no_sep((encode_named_expression(cond), hydra.serialization.cst(":"))))), encode_block(body)))), hydra.lib.maybes.map((lambda eb: hydra.serialization.newline_sep((hydra.serialization.cst("else:"), encode_block(eb)))), else_))))
def encode_lambda_star_etc(lse: hydra.python.syntax.LambdaStarEtc) -> hydra.ast.Expr:
    r"""Serialize lambda star etc."""
    match lse:
        case hydra.python.syntax.LambdaStarEtcParamNoDefault(value=p):
            return encode_lambda_param_no_default(p)
        case hydra.python.syntax.LambdaStarEtcStar():
            return hydra.serialization.cst("*...")
        case hydra.python.syntax.LambdaStarEtcParamMaybeDefault():
            return hydra.serialization.cst("...")
        case hydra.python.syntax.LambdaStarEtcKwds():
            return hydra.serialization.cst("**...")
        case _:
            raise AssertionError("Unreachable: all variants handled")
def encode_module(mod: hydra.python.syntax.Module) -> hydra.ast.Expr:
    r"""Serialize a Python module to an AST expression."""
    @lru_cache(1)
    def warning() -> hydra.ast.Expr:
        return hydra.serialization.cst(to_python_comments(hydra.constants.warning_auto_generated_file))
    @lru_cache(1)
    def groups() -> frozenlist[hydra.ast.Expr]:
        return hydra.lib.lists.map((lambda group: hydra.serialization.newline_sep(hydra.lib.lists.map((lambda x1: encode_statement(x1)), group))), mod.value)
    return hydra.serialization.double_newline_sep(hydra.lib.lists.cons(warning(), groups()))
