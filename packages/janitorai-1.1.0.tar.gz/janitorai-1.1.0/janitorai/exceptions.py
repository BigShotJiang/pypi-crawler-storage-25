from typing import Optional

class JanitorAIException(Exception):
    """Base exception for all JanitorAI errors"""
    pass


class AuthenticationError(JanitorAIException):
    """Raised when authentication fails"""
    pass


class CaptchaError(JanitorAIException):
    """Raised when captcha solving fails"""
    pass


class APIError(JanitorAIException):
    """Raised when API returns an error"""
    def __init__(self, message: str, status_code: Optional[int] = None, response: Optional[dict] = None):
        super().__init__(message)
        self.status_code = status_code
        self.response = response


class RateLimitError(APIError):
    """Raised when rate limited"""
    pass


class NotFoundError(APIError):
    """Raised when resource not found"""
    pass
