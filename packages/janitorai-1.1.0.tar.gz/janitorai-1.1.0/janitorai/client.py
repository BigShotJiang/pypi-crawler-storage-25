import json
import requests
from typing import Optional, Dict, List, Generator, Union
from urllib.parse import urlencode

from .turnstile import TurnstileSolver
from .types import Character, Chat, Message, Review, Profile, Notification, GenerationStream
from .exceptions import AuthenticationError, APIError, NotFoundError, RateLimitError


class JanitorAI:
    """
    JanitorAI API Client - Full implementation of all JanitorAI API endpoints.
    Allows complete recreation of janitorai.com functionality.
    """

    BASE_URL = "https://janitorai.com"
    AUTH_URL = "https://auth.janitorai.com/auth/v1/token"
    API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Im1jbXp4dHpvbW1wbnhreW5kZGJvIiwicm9sZSI6ImFub24iLCJpYXQiOjE3MjgzNzA3NDAsImV4cCI6MjA0Mzk0Njc0MH0.UfRPni4ga9Lmin8j0JjV5ouuK9bXp8tsqPJ8pMTDDAI"

    def __init__(self, token: Optional[str] = None, user_agent: Optional[str] = None):
        self.token = token
        self.user_agent = user_agent or "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15"
        self.session = requests.Session()
        self.turnstile = TurnstileSolver(user_agent=self.user_agent)
        self._update_headers()

    def _update_headers(self) -> None:
        headers = {
            "User-Agent": self.user_agent,
            "Accept": "application/json",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Content-Type": "application/json",
            "Referer": "https://janitorai.com/",
            "Origin": "https://janitorai.com"
        }

        if self.token:
            headers["Authorization"] = f"Bearer {self.token}"

        self.session.headers.update(headers)

    def login(self, email: str, password: str) -> Dict:
        """Login with email and password, automatically solves Turnstile captcha"""
        try:
            # Solve Turnstile captcha
            captcha_token = self.turnstile.solve()

            # Prepare login request
            data = {
                "email": email,
                "password": password,
                "gotrue_meta_security": {
                    "captcha_token": captcha_token
                }
            }

            headers = {
                "apikey": self.API_KEY,
                "X-Supabase-Api-Version": "2024-01-01",
                "X-Client-Info": "supabase-ssr/0.7.0 createBrowserClient"
            }

            response = self.session.post(
                f"{self.AUTH_URL}?grant_type=password",
                json=data,
                headers=headers
            )

            if response.status_code == 400:
                raise AuthenticationError("Invalid email or password")
            elif response.status_code == 429:
                raise RateLimitError("Rate limited")

            response.raise_for_status()
            auth_data = response.json()

            self.token = auth_data["access_token"]
            self._update_headers()

            return auth_data

        except Exception as e:
            raise AuthenticationError(f"Login failed: {str(e)}") from e

    # -------------------------------------------------------------------------
    # Characters API
    # -------------------------------------------------------------------------

    def get_characters(self, page: int = 1, mode: str = "all", sort: str = "latest",
                       special_mode: Optional[str] = None, search: Optional[str] = None,
                       tag_ids: Optional[List[int]] = None, custom_tags: Optional[List[str]] = None,
                       user_ids: Optional[List[str]] = None) -> Dict:
        """List/search characters"""
        params = {
            "page": page,
            "mode": mode,
            "sort": sort
        }

        if special_mode:
            params["special_mode"] = special_mode
        if search:
            params["search"] = search
        if tag_ids:
            params["tag_id[]"] = tag_ids
        if custom_tags:
            params["custom_tags[]"] = custom_tags
        if user_ids:
            params["user_id[]"] = user_ids

        response = self.session.get(f"{self.BASE_URL}/hampter/characters?{urlencode(params, doseq=True)}")
        self._handle_response_errors(response)
        return response.json()

    def get_character(self, character_id: str) -> Character:
        """Get a single character by ID"""
        response = self.session.get(f"{self.BASE_URL}/hampter/characters/{character_id}")
        self._handle_response_errors(response)
        return Character.from_dict(response.json())

    def create_character(self, name: str, chat_name: str, description: str,
                        personality: str, scenario: str, example_dialogs: str,
                        first_message: str, first_messages: List[str],
                        is_nsfw: bool = False, avatar: Optional[str] = None,
                        tag_ids: Optional[List[int]] = None,
                        custom_tags: Optional[List[str]] = None) -> Character:
        """Create a new character"""
        data = {
            "name": name,
            "chat_name": chat_name,
            "description": description,
            "personality": personality,
            "scenario": scenario,
            "example_dialogs": example_dialogs,
            "first_message": first_message,
            "first_messages": first_messages,
            "is_nsfw": is_nsfw,
            "tag_ids": tag_ids or [],
            "custom_tags": custom_tags or [],
            "token_counts": {
                "personality_tokens": 0,
                "scenario_tokens": 0,
                "example_dialog_tokens": 0,
                "first_message_tokens": 0,
                "first_messages_tokens": [0] * len(first_messages),
                "total_tokens": 0
            }
        }

        if avatar:
            data["avatar"] = avatar

        response = self.session.post(f"{self.BASE_URL}/hampter/characters", json=data)
        self._handle_response_errors(response)
        return Character.from_dict(response.json())

    def update_character(self, character_id: str, **kwargs) -> Dict:
        """Update character fields (partial update)"""
        response = self.session.patch(f"{self.BASE_URL}/hampter/characters/{character_id}", json=kwargs)
        self._handle_response_errors(response)
        return response.json()

    def publish_character(self, character_id: str, publish: bool = True) -> bool:
        """Publish or unpublish a character"""
        data = {"desired_new_public_state": publish}
        response = self.session.post(f"{self.BASE_URL}/hampter/characters/{character_id}/publish", json=data)
        self._handle_response_errors(response)
        return True

    def delete_character(self, character_id: str) -> bool:
        """Delete a character"""
        response = self.session.delete(f"{self.BASE_URL}/hampter/characters/{character_id}")
        self._handle_response_errors(response)
        return True

    def get_my_characters(self, page: int = 1, sort: str = "latest",
                          privacy_filter: str = "all") -> Dict:
        """Get authenticated user's characters"""
        params = {"page": page, "sort": sort, "privacyFilter": privacy_filter}
        response = self.session.get(f"{self.BASE_URL}/hampter/characters/v2/mine?{urlencode(params)}")
        self._handle_response_errors(response)
        return response.json()

    def search_tags(self, prefix: str) -> List[str]:
        """Tag autocomplete"""
        response = self.session.get(f"{self.BASE_URL}/hampter/characters/tags/suggest?prefix={prefix}")
        self._handle_response_errors(response)
        return response.json().get("suggestions", [])

    # -------------------------------------------------------------------------
    # Chats API
    # -------------------------------------------------------------------------

    def get_homepage_chats(self, page: int = 1) -> List[Chat]:
        """Get recent chats for homepage"""
        response = self.session.get(f"{self.BASE_URL}/hampter/chats/homepage?page={page}")
        self._handle_response_errors(response)
        return [Chat.from_dict(chat) for chat in response.json()]

    def get_public_chats(self, page: int = 1) -> Dict:
        """Get published public chats"""
        response = self.session.get(f"{self.BASE_URL}/hampter/chats/public/history?page={page}")
        self._handle_response_errors(response)
        return response.json()

    def get_chat(self, chat_id: int) -> Chat:
        """Get a single chat"""
        response = self.session.get(f"{self.BASE_URL}/hampter/chats/{chat_id}")
        self._handle_response_errors(response)
        return Chat.from_dict(response.json())

    def create_chat(self, character_id: str) -> Chat:
        """Create a new chat for a character"""
        data = {"character_id": character_id}
        response = self.session.post(f"{self.BASE_URL}/hampter/chats", json=data)
        self._handle_response_errors(response)
        return Chat.from_dict(response.json())

    def send_message(self, chat_id: int, character_id: str, message: str,
                     is_bot: bool = False, is_main: bool = True,
                     persona_id: Optional[str] = None) -> Message:
        """Save a message to chat history"""
        data = {
            "is_bot": is_bot,
            "is_main": is_main,
            "message": message,
            "character_id": character_id,
            "chat_id": chat_id,
            "metadata": {"persona_id": persona_id}
        }

        response = self.session.post(f"{self.BASE_URL}/hampter/chats/{chat_id}/messages", json=data)
        self._handle_response_errors(response)
        return Message.from_dict(response.json()[0])

    def set_main_message(self, chat_id: int, message_id: int) -> bool:
        """Mark a message as the main/active variant"""
        data = {"is_main": True}
        response = self.session.patch(f"{self.BASE_URL}/hampter/chats/{chat_id}/messages/{message_id}", json=data)
        self._handle_response_errors(response)
        return True

    def get_active_chat(self, character_id: str) -> Optional[int]:
        """Get active chat ID for character, returns None if no chat exists"""
        response = self.session.get(f"{self.BASE_URL}/hampter/chats/character/{character_id}/persona")
        self._handle_response_errors(response)
        result = response.json()
        return result if result != 0 else None

    # -------------------------------------------------------------------------
    # AI Generation
    # -------------------------------------------------------------------------

    def generate(self, chat: Union[Chat, Dict], chat_messages: List[Union[Message, Dict]], model: str = "jllm", **kwargs) -> Generator[str, None, None]:
        """Stream AI response generation"""
        chat_id = chat.id if isinstance(chat, Chat) else chat["id"]
        character_id = chat.character_id if isinstance(chat, Chat) else chat["character_id"]
        user_id = chat.user_id if isinstance(chat, Chat) else chat["user_id"]

        messages = []
        for msg in chat_messages:
            if isinstance(msg, Message):
                messages.append({
                    "id": msg.id,
                    "chat_id": msg.chat_id,
                    "character_id": msg.character_id,
                    "is_bot": msg.is_bot,
                    "is_main": msg.is_main,
                    "message": msg.message,
                    "created_at": msg.created_at.isoformat() if msg.created_at else None
                })
            else:
                messages.append(msg)

        data = {
            "chat": {
                "id": chat_id,
                "character_id": character_id,
                "user_id": user_id,
                "summary": ""
            },
            "chatMessages": messages,
            "model": model
        }

        # Add any additional generation parameters
        data.update(kwargs)

        headers = {"Accept": "text/event-stream"}
        response = self.session.post(f"{self.BASE_URL}/generateAlpha", json=data, headers=headers, stream=True)
        self._handle_response_errors(response)

        for line in response.iter_lines():
            if line:
                line = line.decode('utf-8')
                if line.startswith('data: '):
                    try:
                        json_data = json.loads(line[6:])
                        delta = json_data["choices"][0]["delta"]["content"]
                        if delta:
                            yield delta
                    except:
                        continue

    # -------------------------------------------------------------------------
    # Reviews API
    # -------------------------------------------------------------------------

    def get_reviews(self, character_id: str, page: int = 1, size: int = 20) -> List[Review]:
        """Get reviews for a character"""
        response = self.session.get(f"{self.BASE_URL}/hampter/reviews/{character_id}?page={page}&size={size}")
        self._handle_response_errors(response)
        return [Review.from_dict(r) for r in response.json()]

    def get_review_counts(self, character_id: str) -> Dict:
        """Get review counts for a character"""
        response = self.session.get(f"{self.BASE_URL}/hampter/reviews/counts/{character_id}")
        self._handle_response_errors(response)
        return response.json()

    def post_review(self, character_id: str, content: str, is_like: bool = True) -> Review:
        """Post a review/comment"""
        data = {"character_id": character_id, "content": content, "is_like": is_like}
        response = self.session.post(f"{self.BASE_URL}/hampter/reviews", json=data)
        self._handle_response_errors(response)
        return Review.from_dict(response.json())

    def delete_review(self, review_id: str) -> bool:
        """Delete a review"""
        response = self.session.delete(f"{self.BASE_URL}/hampter/reviews/{review_id}")
        self._handle_response_errors(response)
        return True

    # -------------------------------------------------------------------------
    # Favorites API
    # -------------------------------------------------------------------------

    def is_favorited(self, character_id: str) -> bool:
        """Check if character is favorited"""
        response = self.session.get(f"{self.BASE_URL}/hampter/favorites/myfavorites/{character_id}")
        return response.status_code == 200

    def get_favorite_count(self, character_id: str) -> int:
        """Get favorite count for character"""
        response = self.session.get(f"{self.BASE_URL}/hampter/favorites/character/{character_id}/count")
        self._handle_response_errors(response)
        return response.json().get("favoritesCount", 0)

    # -------------------------------------------------------------------------
    # Tags API
    # -------------------------------------------------------------------------

    def get_tags(self) -> List[Dict]:
        """Get all platform tags"""
        response = self.session.get(f"{self.BASE_URL}/hampter/tags")
        self._handle_response_errors(response)
        return response.json()

    def check_tag_exists(self, slug: str) -> Dict:
        """Check if a tag exists (legacy or custom)"""
        response = self.session.get(f"{self.BASE_URL}/hampter/tags/exists?tagSlug={slug}")
        self._handle_response_errors(response)
        return response.json()

    # -------------------------------------------------------------------------
    # Profiles API
    # -------------------------------------------------------------------------

    def get_profile(self, user_id: str) -> Profile:
        """Get user profile"""
        response = self.session.get(f"{self.BASE_URL}/hampter/profiles/{user_id}")
        self._handle_response_errors(response)
        return Profile.from_dict(response.json())

    # -------------------------------------------------------------------------
    # Notifications API
    # -------------------------------------------------------------------------

    def get_notification_count(self, user_id: str) -> int:
        """Get unread notification count"""
        response = self.session.get(f"{self.BASE_URL}/notifs/api/notifications/count/{user_id}")
        self._handle_response_errors(response)
        return response.json().get("count", 0)

    def get_notifications(self, user_id: str, limit: int = 10,
                          offset: int = 0, archived: bool = False) -> Dict:
        """Get notifications"""
        params = {"limit": limit, "offset": offset, "archived": str(archived).lower()}
        response = self.session.get(f"{self.BASE_URL}/notifs/api/notifications/{user_id}?{urlencode(params)}")
        self._handle_response_errors(response)
        return response.json()

    def mark_all_notifications_read(self, user_id: str) -> bool:
        """Mark all notifications as read"""
        response = self.session.post(f"{self.BASE_URL}/notifs/api/notifications/read-all/{user_id}")
        self._handle_response_errors(response)
        return True

    # -------------------------------------------------------------------------
    # File Upload
    # -------------------------------------------------------------------------

    def get_upload_url(self, extension: str = "webp", type: str = "bot") -> Dict:
        """Get pre-signed upload URL"""
        data = {"extension": extension, "type": type}
        response = self.session.post(f"{self.BASE_URL}/hampter/upload/uploadFile", json=data)
        self._handle_response_errors(response)
        return response.json()

    def upload_file(self, file_path: str, type: str = "bot") -> str:
        """Upload a file and return filename"""
        import os
        ext = os.path.splitext(file_path)[1][1:] or "webp"

        upload_data = self.get_upload_url(ext, type)

        with open(file_path, 'rb') as f:
            response = requests.put(upload_data["url"], data=f.read(), headers={"Content-Type": f"image/{ext}"})
            response.raise_for_status()

        return upload_data["filename"]

    # -------------------------------------------------------------------------
    # Analytics
    # -------------------------------------------------------------------------

    def get_character_analytics(self, character_id: str, time_range: str = "7d") -> Dict:
        """Get character analytics (creator only)"""
        response = self.session.get(f"{self.BASE_URL}/hampter/character-analytics/{character_id}?timeRange={time_range}")
        self._handle_response_errors(response)
        return response.json()

    # -------------------------------------------------------------------------
    # Helper methods
    # -------------------------------------------------------------------------

    def _handle_response_errors(self, response: requests.Response) -> None:
        if response.status_code == 404:
            raise NotFoundError("Resource not found", status_code=404)
        elif response.status_code == 429:
            raise RateLimitError("Rate limited", status_code=429)
        elif response.status_code >= 400:
            try:
                error_data = response.json()
                raise APIError(error_data.get("message", "API error"), status_code=response.status_code, response=error_data)
            except:
                raise APIError(f"API error: {response.status_code}", status_code=response.status_code)
