from dataclasses import dataclass, field
from typing import List, Dict, Optional, Any
from datetime import datetime


@dataclass
class Character:
    id: str
    name: str
    chat_name: str
    avatar: str
    description: str
    personality: Optional[str] = None
    scenario: Optional[str] = None
    example_dialogs: Optional[str] = None
    first_message: Optional[str] = None
    first_messages: List[str] = field(default_factory=list)
    is_nsfw: bool = False
    is_public: bool = True
    creator_id: Optional[str] = None
    creator_name: Optional[str] = None
    custom_tags: List[str] = field(default_factory=list)
    tags: List[Dict] = field(default_factory=list)
    stats: Dict = field(default_factory=dict)
    created_at: Optional[datetime] = None
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict) -> 'Character':
        return cls(
            id=data.get('id', ''),
            name=data.get('name', ''),
            chat_name=data.get('chat_name', ''),
            avatar=data.get('avatar', ''),
            description=data.get('description', ''),
            personality=data.get('personality'),
            scenario=data.get('scenario'),
            example_dialogs=data.get('example_dialogs'),
            first_message=data.get('first_message'),
            first_messages=data.get('first_messages', []),
            is_nsfw=data.get('is_nsfw', False),
            is_public=data.get('is_public', True),
            creator_id=data.get('creator_id'),
            creator_name=data.get('creator_name'),
            custom_tags=data.get('custom_tags', []),
            tags=data.get('tags', []),
            stats=data.get('stats', {}),
            created_at=datetime.fromisoformat(data['created_at'].replace('Z', '+00:00')) if data.get('created_at') else None,
            raw=data
        )


@dataclass
class Chat:
    id: int
    character_id: str
    user_id: str
    is_public: bool = False
    summary: str = ''
    chat_count: int = 0
    created_at: Optional[datetime] = None
    updated_at: Optional[datetime] = None
    character: Optional[Character] = None
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict) -> 'Chat':
        return cls(
            id=data.get('id', 0),
            character_id=data.get('character_id', ''),
            user_id=data.get('user_id', ''),
            is_public=data.get('is_public', False),
            summary=data.get('summary', ''),
            chat_count=data.get('chat_count', 0),
            created_at=datetime.fromisoformat(data['created_at'].replace('Z', '+00:00')) if data.get('created_at') else None,
            updated_at=datetime.fromisoformat(data['updated_at'].replace('Z', '+00:00')) if data.get('updated_at') else None,
            character=Character.from_dict(data['character']) if data.get('character') else None,
            raw=data
        )


@dataclass
class Message:
    id: int
    chat_id: int
    character_id: str
    is_bot: bool
    is_main: bool
    message: str
    created_at: Optional[datetime] = None
    metadata: Dict = field(default_factory=dict)
    rating: Optional[str] = None
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict) -> 'Message':
        return cls(
            id=data.get('id', 0),
            chat_id=data.get('chat_id', 0),
            character_id=data.get('character_id', ''),
            is_bot=data.get('is_bot', False),
            is_main=data.get('is_main', False),
            message=data.get('message', ''),
            created_at=datetime.fromisoformat(data['created_at'].replace('Z', '+00:00')) if data.get('created_at') else None,
            metadata=data.get('metadata', {}),
            rating=data.get('rating'),
            raw=data
        )


@dataclass
class Review:
    id: str
    character_id: str
    user_id: str
    content: str
    is_like: bool
    like_count: int = 0
    dislike_count: int = 0
    created_at: Optional[datetime] = None
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict) -> 'Review':
        return cls(
            id=data.get('id', ''),
            character_id=data.get('character_id', ''),
            user_id=data.get('user_id', ''),
            content=data.get('content', ''),
            is_like=data.get('is_like', False),
            like_count=data.get('like_count', 0),
            dislike_count=data.get('dislike_count', 0),
            created_at=datetime.fromisoformat(data['created_at'].replace('Z', '+00:00')) if data.get('created_at') else None,
            raw=data
        )


@dataclass
class Profile:
    id: str
    user_name: str
    avatar: str
    about_me: Optional[str] = None
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict) -> 'Profile':
        return cls(
            id=data.get('id', ''),
            user_name=data.get('user_name', ''),
            avatar=data.get('avatar', ''),
            about_me=data.get('about_me'),
            raw=data
        )


@dataclass
class Notification:
    id: str
    subject: str
    body: str
    workflow: str
    is_read: bool
    created_at: Optional[datetime] = None
    data: Dict = field(default_factory=dict)
    raw: Dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: Dict) -> 'Notification':
        return cls(
            id=data.get('id', ''),
            subject=data.get('subject', ''),
            body=data.get('body', ''),
            workflow=data.get('workflow', ''),
            is_read=data.get('isRead', False),
            created_at=datetime.fromisoformat(data['createdAt'].replace('Z', '+00:00')) if data.get('createdAt') else None,
            data=data.get('data', {}),
            raw=data
        )


@dataclass
class GenerationStream:
    content: str = ''
    is_complete: bool = False

    def append(self, delta: str) -> None:
        self.content += delta

    def complete(self) -> None:
        self.is_complete = True


# Model constants
MODEL_JLLM = "jllm"  # JanitorLLM (default free model)
MODEL_JLLM_V2 = "jllm-v2"  # JanitorLLM v2 (if available)
