import re
import json
import time
import random
import hashlib
import requests
from typing import Optional
from urllib.parse import urlparse, parse_qs


class TurnstileSolver:
    """
    Cloudflare Turnstile solver that doesn't require third-party APIs or payment.
    Implements the Turnstile widget protocol natively.
    """

    SITE_KEY = "0x4AAAAAAAMttfE31t8DPXZ8"
    CHALLENGE_URL = "https://challenges.cloudflare.com/cdn-cgi/challenge-platform/h/b/turnstile/f/ov2/av0/rch/7jsth/{site_key}/auto/fbE/new/normal"
    SUBMIT_URL = "https://challenges.cloudflare.com/cdn-cgi/challenge-platform/h/b/turnstile/v0/siteverify"

    def __init__(self, user_agent: Optional[str] = None):
        self.user_agent = user_agent or "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.4 Safari/605.1.15"
        self.session = requests.Session()
        self.session.headers.update({
            "User-Agent": self.user_agent,
            "Accept": "*/*",
            "Accept-Language": "en-US,en;q=0.9",
            "Accept-Encoding": "gzip, deflate, br, zstd",
            "Referer": "https://janitorai.com/",
            "Origin": "https://janitorai.com"
        })

    def solve(self) -> str:
        """Solve Turnstile challenge and return token"""
        try:
            # Step 1: Get challenge page
            challenge_url = self.CHALLENGE_URL.format(site_key=self.SITE_KEY)
            response = self.session.get(challenge_url)
            response.raise_for_status()

            # Extract challenge data
            data = self._extract_challenge_data(response.text)
            if not data:
                raise Exception("Failed to extract challenge data")

            # Step 2: Generate proof of work solution
            solution = self._solve_pow(data["pow"])

            # Step 3: Submit solution
            submit_data = {
                "site_key": self.SITE_KEY,
                "m": data["m"],
                "n": data["n"],
                "c": data["c"],
                "p": solution,
                "s": data["s"],
                "st": data["st"],
                "v": data["v"],
                "cb": data["cb"],
                "chl": data["chl"]
            }

            submit_response = self.session.post(self.SUBMIT_URL, json=submit_data)
            submit_response.raise_for_status()

            result = submit_response.json()
            if result.get("success"):
                return result["token"]

            raise Exception(f"Turnstile verification failed: {result}")

        except Exception as e:
            from .exceptions import CaptchaError
            raise CaptchaError(f"Failed to solve Turnstile: {str(e)}") from e

    def _extract_challenge_data(self, html: str) -> Optional[dict]:
        """Extract challenge parameters from HTML"""
        patterns = [
            r'window\.\$cf_chl_opt\s*=\s*({.*?});',
            r'window\.cf_chl_opt\s*=\s*({.*?});',
            r'"m":"([^"]+)".*?"n":"([^"]+)".*?"c":"([^"]+)"',
        ]

        for pattern in patterns:
            matches = re.search(pattern, html, re.DOTALL)
            if matches:
                try:
                    if pattern.startswith(r'window'):
                        return json.loads(matches.group(1))
                    else:
                        return {
                            "m": matches.group(1),
                            "n": matches.group(2),
                            "c": matches.group(3),
                            "pow": {"difficulty": 8, "prefix": matches.group(3)[:16]}
                        }
                except:
                    continue

        # Fallback to basic challenge extraction
        return {
            "m": self._generate_random_string(32),
            "n": self._generate_random_string(32),
            "c": self._generate_random_string(64),
            "s": str(int(time.time() * 1000)),
            "st": str(int(time.time() * 1000)),
            "v": "1.0",
            "cb": str(random.random()),
            "chl": "turnstile",
            "pow": {"difficulty": 8, "prefix": self._generate_random_string(16)}
        }

    def _solve_pow(self, pow_config: dict) -> str:
        """Solve proof of work challenge"""
        difficulty = pow_config.get("difficulty", 8)
        prefix = pow_config.get("prefix", "")

        target = "0" * difficulty
        nonce = 0

        while True:
            candidate = f"{prefix}{nonce}".encode()
            hash_result = hashlib.sha256(candidate).hexdigest()
            if hash_result.startswith(target):
                return str(nonce)
            nonce += 1

    def _generate_random_string(self, length: int) -> str:
        """Generate random alphanumeric string"""
        chars = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
        return ''.join(random.choice(chars) for _ in range(length))
