"""Typer CLI entry point."""

from __future__ import annotations

import asyncio
import json
import os
import sys
from datetime import UTC, datetime
from pathlib import Path

import click
import typer
from pydantic import BaseModel, Field
from rich.console import Console
from rich.table import Table

from chap_checker import __version__
from chap_checker.alerts.base import AlerterBinding, Transition
from chap_checker.alerts.slack import SlackAlerter
from chap_checker.checks import all_checks
from chap_checker.checks.base import Status, resolve_checks
from chap_checker.client import Dhis2Target
from chap_checker.config import (
    DEFAULT_CONCURRENCY,
    DEFAULT_CONFIG_FILENAME,
    AlertsConfig,
    CheckerConfig,
    default_config_path,
    load_config,
)
from chap_checker.logging import configure as configure_logging
from chap_checker.logging import get_logger
from chap_checker.output import render
from chap_checker.runner import RunReport, TargetEntry, VerifyReport, run_targets_sync
from chap_checker.state import GlobalState
from chap_checker.state_store import (
    DEFAULT_STATE_FILENAME,
    compute_transitions,
    load_state,
    save_state,
)

_log = get_logger("cli")


class AlertTestResult(BaseModel):
    """Outcome of sending one synthetic test alert to a single alerter."""

    alerter: str
    ok: bool
    error: str | None = None


class AlertTestReport(BaseModel):
    """Combined result of ``chap-checker alert test`` across all alerters."""

    ok: bool
    results: list[AlertTestResult] = Field(default_factory=list)


app = typer.Typer(
    name="chap-checker",
    help=(
        "Health-check CLI for DHIS2 instances integrated with chap-core. "
        "Cron-friendly with Slack alerts on status transitions and a TUI "
        "dashboard for at-a-glance monitoring."
    ),
    rich_markup_mode="rich",
)


@app.callback(invoke_without_command=True)
def root(
    ctx: typer.Context,
    debug: bool = typer.Option(
        False,
        "--debug",
        "-d",
        help="Enable verbose debug logging on stderr.",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Emit machine-readable JSON instead of a Rich table (cron-friendly).",
    ),
    quiet: bool = typer.Option(
        False,
        "--quiet",
        "-q",
        help="Suppress stdout entirely; just run checks, dispatch alerts, and exit (cron-friendly).",
    ),
    version: bool = typer.Option(False, "--version", "-v", help="Show version and exit."),
) -> None:
    """Global options shared by every subcommand."""
    if version:
        typer.echo(f"chap-checker {__version__}")
        raise typer.Exit()
    configure_logging(debug)
    ctx.obj = GlobalState(debug=debug, json_output=json_output, quiet=quiet)
    if ctx.invoked_subcommand is None:
        typer.echo(ctx.get_help())


DEFAULT_INIT_TEMPLATE = """\
# chap-checker config. Run `chap-checker verify` to check every instance below.
# `chap-checker --help` for all commands; `chap-checker checks list` for every available check.

[instances.play]
url = "https://play.im.dhis2.org/dev"
username = "admin"
password = "district"
"""


@app.command("init")
def init_command(
    ctx: typer.Context,
    output: Path = typer.Option(
        Path(DEFAULT_CONFIG_FILENAME),
        "--output",
        "-o",
        help=f"Where to write the new config (default: ./{DEFAULT_CONFIG_FILENAME}).",
    ),
    force: bool = typer.Option(
        False,
        "--force",
        "-f",
        help="Overwrite the file if it already exists.",
    ),
) -> None:
    """Create a minimal chap-checker.toml in the current directory.

    Drops a single working `[instances.play]` block pointed at the public
    DHIS2 demo instance (admin / district) so you can run
    `chap-checker verify` immediately and replace the values once it works.
    """
    state_obj = _state(ctx)
    if output.exists() and not force:
        raise typer.BadParameter(
            f"{output} already exists. Pass --force to overwrite.",
        )
    output.write_text(DEFAULT_INIT_TEMPLATE, encoding="utf-8")
    if not state_obj.quiet:
        typer.echo(f"Wrote {output}")


@app.command("verify")
def verify_command(
    ctx: typer.Context,
    config: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        help=f"Path to a TOML config (defaults to ./{DEFAULT_CONFIG_FILENAME} if present).",
        envvar="CHAP_CHECKER_CONFIG",
    ),
    instance: str | None = typer.Option(
        None,
        "--instance",
        "-i",
        help="Run only this named instance from the config.",
    ),
    url: str | None = typer.Option(
        None,
        "--url",
        help="Ad-hoc DHIS2 base URL (bypasses config).",
        envvar="DHIS2_URL",
    ),
    username: str | None = typer.Option(
        None, "--username", "-u", help="DHIS2 username (ad-hoc mode).", envvar="DHIS2_USERNAME"
    ),
    password: str | None = typer.Option(
        None,
        "--password",
        "-p",
        help=(
            "DHIS2 password (ad-hoc mode). Prefer --password-env or the "
            "interactive prompt - inline passwords end up in shell history "
            "and `ps` output."
        ),
        envvar="DHIS2_PASSWORD",
    ),
    password_env: str | None = typer.Option(
        None,
        "--password-env",
        help=("Name of the env var holding the DHIS2 password (ad-hoc mode). Recommended over --password."),
    ),
    token: str | None = typer.Option(
        None,
        "--token",
        help=(
            "DHIS2 Personal Access Token (ad-hoc mode). Mutually exclusive "
            "with --password / --password-env. Prefer --token-env to keep "
            "the value out of shell history."
        ),
        envvar="DHIS2_TOKEN",
    ),
    token_env: str | None = typer.Option(
        None,
        "--token-env",
        help=("Name of the env var holding the DHIS2 PAT (ad-hoc mode). Recommended over --token."),
    ),
    timeout: float = typer.Option(10.0, "--timeout", help="HTTP timeout per request (seconds, ad-hoc mode)."),
    insecure: bool = typer.Option(False, "--insecure", help="Skip TLS certificate verification (ad-hoc mode)."),
    check: list[str] | None = typer.Option(
        None,
        "--check",
        "--checks",
        help=(
            "Restrict to these check names (transitive `requires` are pulled in). "
            "Repeat the flag for multiple. Mirrors the per-instance `checks = [...]` config field."
        ),
    ),
    no_alerts: bool = typer.Option(
        False,
        "--no-alerts",
        "--no-alert",
        help="Skip alert dispatch even if configured.",
    ),
    state: Path | None = typer.Option(
        None,
        "--state",
        help=f"Path to the persisted state file (default: ./{DEFAULT_STATE_FILENAME} next to the config).",
        envvar="CHAP_CHECKER_STATE",
    ),
    concurrency: int | None = typer.Option(
        None,
        "--concurrency",
        help=(
            f"Number of targets to check in parallel. Overrides the config value if given. "
            f"Default {DEFAULT_CONCURRENCY}."
        ),
        min=1,
        max=100,
    ),
) -> None:
    """Run every registered check against one or more DHIS2 instances.

    Source of targets is decided as follows:

    1. If `--url` is given, chap-checker runs in *ad-hoc* mode against
       that single URL and ignores any TOML config. Auth is one of:

       - **Password (Basic)** - requires `--username` plus a password.
         Password resolves from `--password`, `--password-env NAME`,
         the `DHIS2_PASSWORD` env var, or a hidden TTY prompt.
       - **Token (DHIS2 PAT)** - `--token`, `--token-env NAME`, or
         `DHIS2_TOKEN` env. Sent as `Authorization: ApiToken <value>`.
         `--username` is optional in token mode.

       Token and password flags are mutually exclusive; passing both
       errors out.
    2. Otherwise the TOML file is loaded from `--config` if given, or
       from `./chap-checker.toml` if present. Every `[instances.*]`
       block runs unless `--instance` narrows the run to one.

    Exit code is 0 when every check on every target is `OK`, non-zero
    otherwise. Alert dispatch (Slack etc.) honors each instance's
    `alerts = [...]` opt-in; skip dispatch entirely with `--no-alerts`.
    """
    state_obj = _state(ctx)
    # Capture which of the auth-mode flags actually came from the
    # command line (vs an envvar fallback or default) so the mutex
    # check below doesn't fire on a passive `DHIS2_PASSWORD` leaking
    # into a `--token-env` invocation.
    cli_source = {
        name: ctx.get_parameter_source(name) == click.core.ParameterSource.COMMANDLINE
        for name in ("password", "password_env", "token", "token_env", "username")
    }
    targets, cfg, config_path = _resolve_run_context(
        config=config,
        instance=instance,
        url=url,
        username=username,
        password=password,
        password_env=password_env,
        token=token,
        token_env=token_env,
        timeout=timeout,
        insecure=insecure,
        check_names=check,
        cli_source=cli_source,
    )
    # CLI flag wins; else use the config value; else the built-in default.
    resolved_concurrency = (
        concurrency if concurrency is not None else (cfg.concurrency if cfg is not None else DEFAULT_CONCURRENCY)
    )
    started_at = datetime.now(UTC)
    reports = run_targets_sync(targets, concurrency=resolved_concurrency)
    finished_at = datetime.now(UTC)

    if not no_alerts and cfg is not None and cfg.alerts is not None and config_path is not None:
        state_path = state if state is not None else config_path.parent / DEFAULT_STATE_FILENAME
        _dispatch_alerts(reports, targets, cfg.alerts, state_path)

    verify_report = VerifyReport(
        checker_version=__version__,
        started_at=started_at,
        finished_at=finished_at,
        runs=reports,
    )

    if not state_obj.quiet:
        render(verify_report, json_output=state_obj.json_output)

    raise typer.Exit(0 if verify_report.ok else 1)


@app.command("dashboard")
def dashboard_command(
    ctx: typer.Context,
    config: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        help=f"Path to a TOML config (defaults to ./{DEFAULT_CONFIG_FILENAME} if present).",
        envvar="CHAP_CHECKER_CONFIG",
    ),
    interval: float = typer.Option(30.0, "--interval", help="Refresh interval in seconds.", min=2.0),
    alerts_enabled: bool = typer.Option(
        False,
        "--alerts/--no-alerts",
        help=(
            "Dispatch Slack/etc. alerts from refresh cycles. Off by default - the TUI is "
            "usually all you need; flip this on if you want this dashboard to also page."
        ),
    ),
    state: Path | None = typer.Option(
        None,
        "--state",
        help=f"State file path (default: ./{DEFAULT_STATE_FILENAME} next to the config).",
        envvar="CHAP_CHECKER_STATE",
    ),
) -> None:
    """Launch the Textual TUI dashboard.

    One tile per configured instance, in an adaptive grid (1-4 columns
    depending on instance count). Each tile shows the rolled-up status,
    the cumulative ping success ratio, and a per-check breakdown. The
    tile's left accent stripe color tracks the worst status, so a FAIL
    tile is unmistakable from across the room.

    Inside the TUI, press `r` to refresh immediately or `q` to quit.
    Whether alerts fire is decided at launch via `--alerts` (off by
    default - the "TUI is enough, do not page anyone" case).
    """
    config_path = config if config is not None else default_config_path()
    if not config_path.exists():
        raise typer.BadParameter(
            f"No config at {config_path}. Provide --config <path> or create a ./{DEFAULT_CONFIG_FILENAME}.",
        )
    cfg = load_config(config_path)
    if not cfg.instances:
        raise typer.BadParameter(f"{config_path} contains no [instances.<name>] entries.")

    targets = [entry.to_target_entry(name) for name, entry in cfg.instances.items()]
    state_path = state if state is not None else config_path.parent / DEFAULT_STATE_FILENAME

    # Late import so the textual dependency only loads when the dashboard runs.
    from chap_checker.dashboard import run as run_dashboard

    run_dashboard(
        targets=targets,
        cfg=cfg,
        config_path=config_path,
        state_path=state_path,
        interval_s=interval,
        alerts_enabled=alerts_enabled,
    )


alerts_app = typer.Typer(
    name="alerts",
    help="Inspect or test configured alerters.",
    no_args_is_help=True,
)


def _alerts_list_impl(ctx: typer.Context, config: Path | None) -> None:
    """List every ``[alerts.<name>]`` section configured in the TOML."""
    state_obj = _state(ctx)
    config_path = config if config is not None else default_config_path()
    if not config_path.exists():
        raise typer.BadParameter(
            f"No config at {config_path}. Provide --config <path> or create a ./{DEFAULT_CONFIG_FILENAME}.",
        )
    cfg = load_config(config_path)

    rows: list[dict[str, object]] = []
    if cfg.alerts is not None and cfg.alerts.slack is not None:
        rows.append(
            {
                "name": "slack",
                "transport": "Incoming Webhook",
                "notify_on": [s.value for s in cfg.alerts.slack.notify_on],
                "timeout_s": cfg.alerts.slack.timeout_s,
            }
        )

    if state_obj.quiet:
        return

    if state_obj.json_output:
        typer.echo(json.dumps(rows, indent=2, sort_keys=True))
        return

    console = Console()
    table = Table(title=f"Configured alerters ({config_path})")
    table.add_column("Name", style="cyan", no_wrap=True)
    table.add_column("Transport", style="dim")
    table.add_column("notify_on")
    table.add_column("timeout_s", justify="right", style="dim")
    if not rows:
        console.print(table)
        console.print("[dim]No alerters configured. Add an [alerts.<name>] section to enable.[/]")
        return
    for r in rows:
        table.add_row(
            str(r["name"]),
            str(r["transport"]),
            ", ".join(r["notify_on"]) if isinstance(r["notify_on"], list) else str(r["notify_on"]),
            str(r["timeout_s"]),
        )
    console.print(table)


def _alerts_list_command(
    ctx: typer.Context,
    config: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        help=f"Path to a TOML config (defaults to ./{DEFAULT_CONFIG_FILENAME} if present).",
        envvar="CHAP_CHECKER_CONFIG",
    ),
) -> None:
    """List configured alerters."""
    _alerts_list_impl(ctx, config)


alerts_app.command("list", help="List configured alerters.")(_alerts_list_command)
alerts_app.command("ls", hidden=True)(_alerts_list_command)


@alerts_app.command("test")
def alerts_test_command(
    ctx: typer.Context,
    name: str | None = typer.Option(
        None,
        "--name",
        "-n",
        help="Send only to this alerter (must be a configured alerter name). Default: every configured alerter.",
    ),
    config: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        help=f"Path to a TOML config (defaults to ./{DEFAULT_CONFIG_FILENAME} if present).",
        envvar="CHAP_CHECKER_CONFIG",
    ),
) -> None:
    """Send a synthetic transition to every configured alerter (or a named one).

    Useful after rotating a Slack webhook or when you suspect the alert
    pipeline is broken. Each invocation posts a real message to the
    configured channel, so do not put this on a cron - run it manually.

    Exit code is 0 only when every alerter delivered successfully.
    """
    state_obj = _state(ctx)
    config_path = config if config is not None else default_config_path()
    if not config_path.exists():
        raise typer.BadParameter(
            f"No config at {config_path}. Provide --config <path> or create a ./{DEFAULT_CONFIG_FILENAME}.",
        )
    cfg = load_config(config_path)
    if cfg.alerts is None:
        raise typer.BadParameter(f"{config_path} has no [alerts.*] section.")

    alerters = _build_alerters(cfg.alerts)
    if not alerters:
        raise typer.BadParameter("No alerters configured.")

    if name is not None:
        configured_names = sorted(b.alerter.name for b in alerters)
        alerters = [b for b in alerters if b.alerter.name == name]
        if not alerters:
            raise typer.BadParameter(
                f"No configured alerter named '{name}'. Configured: {', '.join(configured_names)}."
            )

    test_transition = Transition(
        kind="failure",
        target_name="test",
        target_url="https://test.example.com",
        check_name="alert-test",
        previous_status=Status.OK,
        current_status=Status.FAIL,
        message="Test alert from `chap-checker alerts test`.",
        duration_ms=0.0,
        occurred_at=datetime.now(UTC),
    )

    chatter = not state_obj.quiet and not state_obj.json_output

    async def _send_all() -> AlertTestReport:
        results: list[AlertTestResult] = []
        for binding in alerters:
            if chatter:
                typer.echo(f"Sending test message via {binding.alerter.name}...")
            try:
                await binding.alerter.notify([test_transition])
                results.append(AlertTestResult(alerter=binding.alerter.name, ok=True))
                if chatter:
                    typer.echo("  OK")
            except Exception as exc:  # noqa: BLE001 - surface every failure as a result
                results.append(AlertTestResult(alerter=binding.alerter.name, ok=False, error=str(exc)))
                if chatter:
                    typer.echo(f"  FAILED: {exc}")
                _log.exception("alerter %s failed", binding.alerter.name)
        return AlertTestReport(ok=all(r.ok for r in results), results=results)

    report = asyncio.run(_send_all())

    if state_obj.json_output and not state_obj.quiet:
        typer.echo(report.model_dump_json(indent=2))

    raise typer.Exit(0 if report.ok else 1)


app.add_typer(alerts_app, name="alerts")


@app.command("web")
def web_command(
    ctx: typer.Context,
    config: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        help=f"Path to a TOML config (defaults to ./{DEFAULT_CONFIG_FILENAME} if present).",
        envvar="CHAP_CHECKER_CONFIG",
    ),
    interval: float = typer.Option(30.0, "--interval", help="Server-side check refresh interval (seconds).", min=2.0),
    alerts_enabled: bool = typer.Option(
        False,
        "--alerts/--no-alerts",
        help=(
            "Dispatch Slack/etc. alerts from refresh cycles. Off by default - the dashboard is "
            "usually all you need; flip this on if you want this dashboard to also page."
        ),
    ),
    state: Path | None = typer.Option(
        None,
        "--state",
        help=f"State file path (default: ./{DEFAULT_STATE_FILENAME} next to the config).",
        envvar="CHAP_CHECKER_STATE",
    ),
    host: str = typer.Option(
        "127.0.0.1",
        "--host",
        help="Bind address. Use 0.0.0.0 to expose on the local network (e.g. for a TV).",
    ),
    port: int = typer.Option(8765, "--port", help="Port to listen on.", min=1, max=65535),
) -> None:
    """Launch the web dashboard.

    A single-page browser dashboard with the same tile layout and palette
    as the Textual TUI. A FastAPI background task runs checks every
    `--interval` seconds; the browser polls `/api/state` every few seconds
    and re-renders tiles client-side.

    Designed to fill a TV screen with no scrolling - pin a kiosk browser
    at the URL and leave it.
    """
    config_path = config if config is not None else default_config_path()
    if not config_path.exists():
        raise typer.BadParameter(
            f"No config at {config_path}. Provide --config <path> or create a ./{DEFAULT_CONFIG_FILENAME}.",
        )
    cfg = load_config(config_path)
    if not cfg.instances:
        raise typer.BadParameter(f"{config_path} contains no [instances.<name>] entries.")

    targets = [entry.to_target_entry(name) for name, entry in cfg.instances.items()]
    state_path = state if state is not None else config_path.parent / DEFAULT_STATE_FILENAME

    # Late import so the FastAPI / uvicorn deps only load when the web
    # subcommand actually runs.
    from chap_checker.web import run as run_web

    typer.echo(f"chap-checker web dashboard on http://{host}:{port}")
    typer.echo(f"  config:   {config_path}")
    typer.echo(f"  interval: {interval}s")
    typer.echo(f"  alerts:   {'on' if alerts_enabled else 'off'}")
    run_web(
        targets=targets,
        cfg=cfg,
        state_path=state_path,
        interval_s=interval,
        alerts_enabled=alerts_enabled,
        config_path=config_path,
        host=host,
        port=port,
    )


checks_app = typer.Typer(
    name="checks",
    help="Inspect available checks.",
    no_args_is_help=True,
)


def _checks_list_impl(ctx: typer.Context) -> None:
    """List every registered check with order, prerequisites, and description."""
    state_obj = _state(ctx)
    checks = all_checks()

    if state_obj.quiet:
        return

    if state_obj.json_output:
        payload = [
            {
                "name": c.name,
                "description": c.description,
                "order": c.order,
                "requires": c.requires,
            }
            for c in checks
        ]
        typer.echo(json.dumps(payload, indent=2, sort_keys=True))
        return

    console = Console()
    table = Table(title="Registered checks")
    table.add_column("Name", style="cyan", no_wrap=True)
    table.add_column("Order", justify="right", style="dim")
    table.add_column("Requires", style="dim")
    table.add_column("Description", overflow="fold")
    for c in checks:
        table.add_row(c.name, str(c.order), ", ".join(c.requires) or "-", c.description)
    console.print(table)


checks_app.command("list", help="List registered checks.")(_checks_list_impl)
checks_app.command("ls", hidden=True)(_checks_list_impl)

app.add_typer(checks_app, name="checks")


def _resolve_adhoc_token(*, token: str | None, token_env: str | None) -> str:
    """Pick the ad-hoc-mode PAT from the safest source available.

    Mirrors :func:`_resolve_adhoc_password` priority: explicit value,
    named env var, ``DHIS2_TOKEN`` (auto-wired by typer onto
    ``--token``), interactive prompt on a TTY, else helpful error.
    """
    if token is not None and token_env is not None:
        raise typer.BadParameter("Pass either --token or --token-env, not both.")
    if token_env is not None:
        value = os.environ.get(token_env)
        if not value:
            raise typer.BadParameter(
                f"--token-env {token_env}: env var is not set or empty.",
            )
        return value
    if token:
        return token
    if sys.stdin.isatty():
        prompted: str = typer.prompt("DHIS2 token", hide_input=True)
        return prompted
    raise typer.BadParameter(
        "--url with --token requires a value. Pass --token-env NAME, set DHIS2_TOKEN, "
        "or run interactively for a hidden prompt.",
    )


def _resolve_adhoc_password(*, password: str | None, password_env: str | None) -> str:
    """Pick the ad-hoc-mode password from the safest source available.

    Priority:

    1. ``--password VAL`` if non-empty (discouraged - shell history + ``ps``).
       Typer also fills this from the ``DHIS2_PASSWORD`` env var.
    2. ``--password-env NAME`` -> ``os.environ[NAME]`` (recommended).
    3. Interactive prompt when stdin is a TTY.

    Otherwise raises a helpful ``BadParameter`` so cron / CI errors point
    at the missing flag rather than dropping into an unattainable prompt.
    """
    if password is not None and password_env is not None:
        raise typer.BadParameter("Pass either --password or --password-env, not both.")
    if password_env is not None:
        value = os.environ.get(password_env)
        if not value:
            raise typer.BadParameter(
                f"--password-env {password_env}: env var is not set or empty.",
            )
        return value
    if password:
        return password
    if sys.stdin.isatty():
        prompted: str = typer.prompt("DHIS2 password", hide_input=True)
        return prompted
    raise typer.BadParameter(
        "--url requires a password. Pass --password-env NAME, set DHIS2_PASSWORD, "
        "or run interactively for a hidden prompt.",
    )


def _build_adhoc_target(
    *,
    url: str,
    username: str | None,
    password: str | None,
    password_env: str | None,
    token: str | None,
    token_env: str | None,
    timeout: float,
    insecure: bool,
    cli_source: dict[str, bool],
) -> Dhis2Target:
    """Build the single Dhis2Target for ad-hoc verify mode.

    Mode-detection rules:

    1. If both token-family flags AND password-family flags were
       passed on the **command line**, error out (true intent
       conflict).
    2. Otherwise, if a token-family flag was on the command line,
       token mode wins regardless of which env vars happen to be set
       in the shell.
    3. Symmetrically for password-family flags.
    4. If no auth flag was on the command line at all, fall back to
       whichever env var is populated. If both ``DHIS2_TOKEN`` and
       ``DHIS2_PASSWORD`` are exported, that's ambiguous and we
       error so cron jobs don't silently flip modes between hosts.
    """
    token_flag_explicit = cli_source.get("token", False) or cli_source.get("token_env", False)
    password_flag_explicit = (
        cli_source.get("password", False) or cli_source.get("password_env", False) or cli_source.get("username", False)
    )

    if token_flag_explicit and password_flag_explicit:
        raise typer.BadParameter(
            "Pass either password flags (--password / --password-env / --username) "
            "or token flags (--token / --token-env), not both.",
        )

    # When no flag was given, an envvar-populated value is the only
    # signal we have - use it to pick a mode.
    has_token_value = token is not None or token_env is not None
    has_password_value = password is not None or password_env is not None

    if token_flag_explicit:
        use_token = True
    elif password_flag_explicit:
        use_token = False
    elif has_token_value and has_password_value:
        raise typer.BadParameter(
            "DHIS2_TOKEN and DHIS2_PASSWORD are both set in the environment. "
            "Pass --token-env or --password-env (or --token / --password) to "
            "pick a mode explicitly.",
        )
    elif has_token_value:
        use_token = True
    else:
        # has_password_value or fully empty - either way password
        # mode handles it (the resolver will prompt or error).
        use_token = False

    if use_token:
        resolved_token = _resolve_adhoc_token(token=token, token_env=token_env)
        return Dhis2Target(
            base_url=url,  # type: ignore[arg-type]  # Pydantic coerces str -> HttpUrl
            token=resolved_token,
            timeout_s=timeout,
            verify_tls=not insecure,
        )
    if username is None:
        raise typer.BadParameter(
            "--url requires --username (with a password) or one of --token / --token-env / DHIS2_TOKEN.",
        )
    resolved_password = _resolve_adhoc_password(password=password, password_env=password_env)
    return Dhis2Target(
        base_url=url,  # type: ignore[arg-type]  # Pydantic coerces str -> HttpUrl
        username=username,
        password=resolved_password,
        timeout_s=timeout,
        verify_tls=not insecure,
    )


def _resolve_run_context(
    *,
    config: Path | None,
    instance: str | None,
    url: str | None,
    username: str | None,
    password: str | None,
    password_env: str | None,
    token: str | None,
    token_env: str | None,
    timeout: float,
    insecure: bool,
    check_names: list[str] | None,
    cli_source: dict[str, bool] | None = None,
) -> tuple[list[TargetEntry], CheckerConfig | None, Path | None]:
    """Build the list of targets to check plus the loaded config (if any).

    ``check_names`` (from ``--check`` / ``--checks``) restricts which checks
    run. In ad-hoc mode it's applied directly. In config mode it overrides
    each instance's per-instance ``checks`` field for this run; unknown names
    fail with a clear CLI error rather than a runtime KeyError.

    ``cli_source`` maps each auth-mode flag name to whether it was
    explicitly passed on the command line (vs filled in from envvar /
    default). It's used to disambiguate "user wants token mode" from
    "DHIS2_PASSWORD happens to be exported in the shell". Tests pass
    ``None`` and the resolver falls back to treating any populated
    value as CLI-explicit (legacy behaviour).
    """
    if check_names:
        try:
            resolve_checks(check_names)
        except KeyError as exc:
            raise typer.BadParameter(str(exc)) from exc

    if url is not None:
        if instance is not None:
            raise typer.BadParameter("--instance cannot be combined with --url; --url is ad-hoc mode.")
        target = _build_adhoc_target(
            url=url,
            username=username,
            password=password,
            password_env=password_env,
            token=token,
            token_env=token_env,
            timeout=timeout,
            insecure=insecure,
            cli_source=cli_source or {},
        )
        return [TargetEntry(name="ad-hoc", target=target, check_names=check_names)], None, None

    config_path = config if config is not None else default_config_path()
    if not config_path.exists():
        raise typer.BadParameter(
            f"No config at {config_path}. Provide --config <path>, "
            f"create a ./{DEFAULT_CONFIG_FILENAME}, or use --url for ad-hoc mode.",
        )
    cfg = load_config(config_path)
    if not cfg.instances:
        raise typer.BadParameter(f"{config_path} contains no [instances.<name>] entries.")

    if instance is not None:
        try:
            entry = cfg.get(instance)
        except KeyError as exc:
            raise typer.BadParameter(str(exc)) from exc
        target_entry = entry.to_target_entry(instance)
        if check_names:
            target_entry = target_entry.model_copy(update={"check_names": check_names})
        return [target_entry], cfg, config_path

    targets = [entry.to_target_entry(name) for name, entry in cfg.instances.items()]
    if check_names:
        targets = [t.model_copy(update={"check_names": check_names}) for t in targets]
    return targets, cfg, config_path


def _build_alerters(cfg: AlertsConfig) -> list[AlerterBinding]:
    """Instantiate one :class:`AlerterBinding` per configured ``[alerts.<name>]`` section."""
    out: list[AlerterBinding] = []
    if cfg.slack is not None:
        out.append(
            AlerterBinding(
                alerter=SlackAlerter(
                    webhook_url=cfg.slack.resolve_webhook_url(),
                    timeout_s=cfg.slack.timeout_s,
                ),
                notify_on=set(cfg.slack.notify_on),
            )
        )
    return out


async def dispatch_alerts_async(
    reports: list[RunReport],
    targets: list[TargetEntry],
    alerts_cfg: AlertsConfig,
    state_path: Path,
) -> None:
    """Async core of alert dispatch; safe to call from inside an event loop."""
    bindings = _build_alerters(alerts_cfg)
    if not bindings:
        return

    target_alerts = {t.name: set(t.alerts) for t in targets}

    notify_on_union: set[Status] = set()
    for binding in bindings:
        notify_on_union.update(binding.notify_on)

    now = datetime.now(UTC)
    previous = load_state(state_path)
    transitions, new_state = compute_transitions(previous, reports, notify_on_union, now)

    if not transitions:
        _safe_save_state(state_path, new_state)
        return

    all_ok = True
    for binding in bindings:
        alerter_name = binding.alerter.name
        filtered = [
            t
            for t in transitions
            if alerter_name in target_alerts.get(t.target_name, set())
            and (t.current_status in binding.notify_on or t.previous_status in binding.notify_on)
        ]
        if not filtered:
            continue
        try:
            await binding.alerter.notify(filtered)
        except Exception:  # noqa: BLE001 - alerts must not change exit code
            all_ok = False
            _log.exception("alerter %s failed", binding.alerter.name)

    if all_ok:
        _safe_save_state(state_path, new_state)
    else:
        _log.warning("alerter delivery failed; not saving state so transitions will retry on the next run")


def _safe_save_state(state_path: Path, new_state: object) -> None:
    """Persist state, swallowing I/O failures.

    A bad ``--state`` path, a read-only filesystem, or a permissions
    issue must not change the exit code that the checks themselves
    produced. Mirrors the existing alerter contract - log and move
    on. Type of ``new_state`` is intentionally ``object`` here to
    keep this helper agnostic to the state_store import surface;
    callers always pass a ``StateFile``.
    """
    try:
        from chap_checker.state_store import StateFile

        assert isinstance(new_state, StateFile)
        save_state(state_path, new_state)
    except Exception:  # noqa: BLE001 - state-write failure must not crash verify
        _log.exception("could not write state file at %s; continuing", state_path)


def _dispatch_alerts(
    reports: list[RunReport],
    targets: list[TargetEntry],
    alerts_cfg: AlertsConfig,
    state_path: Path,
) -> None:
    """Sync wrapper used by ``verify``. See :func:`dispatch_alerts_async`.

    Per-target opt-in: each ``TargetEntry.alerts`` lists which configured
    alerter names should fire for that target. A transition only reaches an
    alerter when the source target opted into that alerter's name. State is
    still tracked for every target (it's cheap and lets the operator flip an
    instance from silent to alerting later without spurious "first failure"
    pings for sustained outages).

    Delivery failures (Slack 5xx, transport errors) are caught so they cannot
    change the run's exit code, but on failure the new state is *not* saved.
    Next run will recompute the same transitions and retry. With multiple
    alerters this is conservative (any failure suppresses the save and may
    re-deliver to alerters that already succeeded); per-alerter dedupe is a
    later-day problem.
    """
    asyncio.run(dispatch_alerts_async(reports, targets, alerts_cfg, state_path))


def _state(ctx: typer.Context) -> GlobalState:
    obj = ctx.obj
    if isinstance(obj, GlobalState):
        return obj
    return GlobalState()


def main() -> None:
    """Entry point used by the ``chap-checker`` console script."""
    app()


if __name__ == "__main__":
    main()
