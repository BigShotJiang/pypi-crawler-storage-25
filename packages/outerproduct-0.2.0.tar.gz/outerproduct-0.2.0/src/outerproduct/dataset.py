"""Tabular datasets and column schema for the OuterProduct SDK.

The :class:`~outerproduct.dataset.Dataset` is the fundamental input to a :class:`~outerproduct.trainer.Trainer`.
It wraps a 2-D table of features (with an optional label column) plus a
per-column schema captured by :class:`~outerproduct.dataset.Column`.

Examples
--------
.. code-block:: python

    import outerproduct as op
    import pandas as pd

    df = pd.DataFrame({"age": [25, 31], "income": [50_000, 80_000], "churn": [0, 1]})
    dataset = op.Dataset.from_pandas(df, label_column="churn")
    dataset.feature_names
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    import numpy as np
    import pandas as pd


@dataclass
class Column:
    """A single column in a :class:`~outerproduct.dataset.Dataset`.

    Parameters
    ----------
    name : str
        Column name as it appears in the underlying table.
    """

    name: str


class Dataset:
    """A tabular ML dataset: features, optional label column, and per-column schema.

    The :class:`~outerproduct.dataset.Dataset` is the input handed to :meth:`~outerproduct.trainer.Trainer.configure`.
    It does *not* hold a reference to the backend by itself — uploading and
    registering a dataset is handled by a :class:`~outerproduct.connector.Connector`.

    Construct a dataset from raw data via the ``from_*`` factory methods,
    or directly from arrays with the constructor.

    Examples
    --------
    .. code-block:: python

        import outerproduct as op
        import pandas as pd

        df = pd.DataFrame({"x": [1, 2, 3], "y": [0, 1, 0]})
        dataset = op.Dataset.from_pandas(df, label_column="y")

    Parameters
    ----------
    data : pandas.DataFrame, numpy.ndarray, or list of lists
        The table contents. If a ``DataFrame``, column names are taken
        from the frame.
    label_column : str, optional
        Name of the target column. Required for supervised training.
    feature_names : list of str, optional
        Column names, when ``data`` is array-like and not already named.
    columns : list of Column, optional
        Explicit per-column schema. If omitted, a default schema is
        inferred from the data.
    """

    def __init__(
        self,
        data: pd.DataFrame | np.ndarray | list[list[Any]],
        *,
        label_column: str | None = None,
        feature_names: list[str] | None = None,
        columns: list[Column] | None = None,
        _connector_ref: tuple[str, str] | None = None,
    ) -> None:
        import numpy as np
        import pandas as pd

        # Connector-backed datasets carry no local data — skip DataFrame
        # parsing.  The _connector_ref parameter is internal; external
        # callers should use _from_connector_ref().
        if _connector_ref is not None:
            self._df = pd.DataFrame()
        elif isinstance(data, pd.DataFrame):
            self._df = data.copy()
        elif isinstance(data, np.ndarray):
            if data.ndim != 2:
                raise ValueError(
                    f"Dataset: numpy data must be 2-D, got shape {data.shape}"
                )
            names = feature_names or [f"x{i}" for i in range(data.shape[1])]
            self._df = pd.DataFrame(data, columns=pd.Index(names))
        elif isinstance(data, list):
            n_cols = len(data[0]) if data else 0
            names = feature_names or [f"x{i}" for i in range(n_cols)]
            self._df = pd.DataFrame(data, columns=pd.Index(names))
        else:
            raise TypeError(
                f"Dataset: unsupported data type {type(data).__name__}; "
                "expected pandas.DataFrame, numpy.ndarray, or list of lists"
            )

        if (
            _connector_ref is None
            and label_column is not None
            and label_column not in self._df.columns
        ):
            raise ValueError(
                f"Dataset: label_column={label_column!r} not in columns "
                f"{list(self._df.columns)}"
            )

        self._label_column = label_column
        self._explicit_columns = columns
        self._upload_id: str | None = None
        if _connector_ref is not None:
            self._connector_id: str | None = _connector_ref[0]
            self._table_name: str | None = _connector_ref[1]
        else:
            self._connector_id = None
            self._table_name = None

    # ------------------------------------------------------------------
    # Factories
    # ------------------------------------------------------------------

    @classmethod
    def from_pandas(
        cls,
        df: pd.DataFrame,
        *,
        label_column: str | None = None,
    ) -> Dataset:
        """Build a :class:`~outerproduct.dataset.Dataset` from an in-memory pandas DataFrame.

        Parameters
        ----------
        df : pandas.DataFrame
            Source frame. Column names become feature names.
        label_column : str, optional
            Name of the target column, if any.

        Returns
        -------
        :class:`~outerproduct.dataset.Dataset`
            A dataset backed by the given DataFrame.
        """
        return cls(df, label_column=label_column)

    @classmethod
    def from_csv(
        cls,
        path: str | Path,
        *,
        label_column: str | None = None,
        **read_csv_kwargs: Any,
    ) -> Dataset:
        """Build a :class:`~outerproduct.dataset.Dataset` by reading a local CSV file.

        Parameters
        ----------
        path : str or pathlib.Path
            Path to the CSV file.
        label_column : str, optional
            Name of the target column.
        **read_csv_kwargs
            Forwarded to ``pandas.read_csv``.

        Returns
        -------
        :class:`~outerproduct.dataset.Dataset`
            A dataset loaded from the CSV file.
        """
        import pandas as pd

        df = pd.read_csv(path, **read_csv_kwargs)
        return cls(df, label_column=label_column)

    @classmethod
    def from_parquet(
        cls,
        path: str | Path,
        *,
        label_column: str | None = None,
    ) -> Dataset:
        """Build a :class:`~outerproduct.dataset.Dataset` by reading a local Parquet file.

        Parameters
        ----------
        path : str or pathlib.Path
            Path to the Parquet file.
        label_column : str, optional
            Name of the target column.

        Returns
        -------
        :class:`~outerproduct.dataset.Dataset`
            A dataset loaded from the Parquet file.
        """
        import pandas as pd

        df = pd.read_parquet(path)
        return cls(df, label_column=label_column)

    @classmethod
    def from_numpy(
        cls,
        X: np.ndarray,
        y: np.ndarray | None = None,
        *,
        feature_names: list[str] | None = None,
        label_column: str = "target",
    ) -> Dataset:
        """Build a :class:`~outerproduct.dataset.Dataset` from raw NumPy arrays.

        Parameters
        ----------
        X : numpy.ndarray, shape (n_samples, n_features)
            Feature matrix.
        y : numpy.ndarray, shape (n_samples,), optional
            Target vector. If provided, it is appended as a column
            named ``label_column``.
        feature_names : list of str, optional
            Names for the columns of ``X``. Defaults to ``["x0", "x1", ...]``.
        label_column : str
            Name to use for the target column when ``y`` is provided.

        Returns
        -------
        :class:`~outerproduct.dataset.Dataset`
            A dataset built from the given arrays.
        """
        import pandas as pd

        if X.ndim != 2:
            raise ValueError(f"from_numpy: X must be 2-D, got shape {X.shape}")
        names = feature_names or [f"x{i}" for i in range(X.shape[1])]
        df = pd.DataFrame(X, columns=pd.Index(names))
        if y is not None:
            if len(y) != len(X):
                raise ValueError(f"from_numpy: len(X)={len(X)} != len(y)={len(y)}")
            df[label_column] = y
            return cls(df, label_column=label_column)
        return cls(df)

    @classmethod
    def _from_connector_ref(
        cls,
        *,
        connector_id: str,
        table_name: str,
        label_column: str | None = None,
    ) -> Dataset:
        """Create a lazy Dataset backed by a connector reference.

        The returned dataset has no local DataFrame — the data lives
        remotely and is read by the backend at training time. Properties
        that inspect local data (``n_samples``, ``head()``, ``to_pandas()``)
        will raise.

        Internal — called by :meth:`~outerproduct.connector.Connector.table`.
        """
        import pandas as pd

        return cls(
            pd.DataFrame(),
            label_column=label_column,
            _connector_ref=(connector_id, table_name),
        )

    # ------------------------------------------------------------------
    # Schema / introspection
    # ------------------------------------------------------------------

    @property
    def feature_names(self) -> list[str]:
        """Names of the feature columns (label column excluded).

        Raises :class:`RuntimeError` on connector-backed datasets where
        column names are not locally available.
        """
        if self._connector_id is not None and len(self._df.columns) == 0:
            raise RuntimeError(
                "Cannot inspect feature names on a connector-backed Dataset. "
                "The data resides on the remote source."
            )
        names = list(self._df.columns)
        if self._label_column is not None and self._label_column in names:
            names.remove(self._label_column)
        return names

    @property
    def label_column(self) -> str | None:
        """Name of the label column, or ``None`` if unsupervised."""
        return self._label_column

    @property
    def columns(self) -> list[Column]:
        """All columns (features and label, in the order they appear).

        Raises :class:`RuntimeError` on connector-backed datasets.
        """
        if self._connector_id is not None and self._explicit_columns is None:
            raise RuntimeError(
                "Cannot inspect columns on a connector-backed Dataset. "
                "The data resides on the remote source."
            )
        if self._explicit_columns is not None:
            return list(self._explicit_columns)
        return [Column(name=str(c)) for c in self._df.columns]

    @property
    def n_samples(self) -> int:
        """Number of rows.

        Raises :class:`RuntimeError` on connector-backed datasets.
        """
        if self._connector_id is not None:
            raise RuntimeError(
                "Cannot determine n_samples on a connector-backed Dataset. "
                "The data resides on the remote source."
            )
        return int(len(self._df))

    @property
    def n_features(self) -> int:
        """Number of feature columns (label excluded)."""
        return len(self.feature_names)

    def schema(self) -> dict[str, Column]:
        """Return the schema as a ``{name: Column}`` mapping."""
        return {c.name: c for c in self.columns}

    # ------------------------------------------------------------------
    # Internal — wire serialisation for /v1/trainer/run + /v1/reasoning/fit
    # ------------------------------------------------------------------

    @property
    def is_uploaded(self) -> bool:
        """``True`` when this dataset was registered via a connector upload."""
        return self._upload_id is not None

    @property
    def is_connector_backed(self) -> bool:
        """``True`` when this dataset is backed by a registered connector."""
        return self._connector_id is not None

    def _to_inline_payload(self) -> dict[str, Any]:
        """Return the dataset as the fields the training endpoints expect.

        Three modes:

        1. **Connector-backed**: ``data_connector=True`` with ``connector_id``
           and ``table_name``. The backend reads data from the registered
           external source at training time.
        2. **Pre-uploaded**: ``data_uploaded=True`` with the server-side
           ``model_id``.
        3. **Inline**: raw ``data`` and ``labels`` embedded in the request.

        Internal — used by :class:`~outerproduct.trainer.Trainer` and
        :func:`~outerproduct.reasoning.fit`.
        """
        if self._connector_id is not None:
            out: dict[str, Any] = {
                "data_connector": True,
                "connector_id": self._connector_id,
                "table_name": self._table_name,
            }
            if self._label_column is not None:
                out["label_column"] = self._label_column
            return out

        names = self.feature_names

        if self._upload_id is not None:
            # The server already has the full table (uploaded via presigned
            # URL).  It reads labels from ``label_column`` — sending them
            # again inline is redundant and breaks for string targets that
            # Pydantic can't coerce to float.
            out = {
                "data_uploaded": True,
                "dataset_id": self._upload_id,
                "feature_names": names,
            }
            if self._label_column is not None:
                out["label_column"] = self._label_column
        else:
            feature_df = self._df[names]
            out = {
                "data_uploaded": False,
                "data": feature_df.values.tolist(),
                "feature_names": names,
            }
            if self._label_column is not None:
                out["labels"] = self._df[self._label_column].tolist()
                out["label_column"] = self._label_column
        return out

    # ------------------------------------------------------------------
    # Convenience
    # ------------------------------------------------------------------

    def head(self, n: int = 5) -> pd.DataFrame:
        """Return the first ``n`` rows as a pandas DataFrame.

        Raises :class:`RuntimeError` on connector-backed datasets.
        """
        if self._connector_id is not None:
            raise RuntimeError(
                "Cannot call head() on a connector-backed Dataset. "
                "The data resides on the remote source."
            )
        return self._df.head(n)

    def to_pandas(self) -> pd.DataFrame:
        """Return the dataset as a pandas DataFrame.

        Raises :class:`RuntimeError` on connector-backed datasets.
        """
        if self._connector_id is not None:
            raise RuntimeError(
                "Cannot call to_pandas() on a connector-backed Dataset. "
                "The data resides on the remote source."
            )
        return self._df.copy()

    def __getitem__(self, key: str) -> Column:
        """Look up a column's schema by name.

        Raises :class:`RuntimeError` on connector-backed datasets.
        """
        if self._connector_id is not None:
            raise RuntimeError(
                "Cannot look up columns on a connector-backed Dataset. "
                "The data resides on the remote source."
            )
        if key not in self._df.columns:
            raise KeyError(key)
        return Column(name=key)

    def __len__(self) -> int:
        if self._connector_id is not None:
            raise RuntimeError(
                "Cannot determine length of a connector-backed Dataset. "
                "The data resides on the remote source."
            )
        return self.n_samples

    def __repr__(self) -> str:
        if self._connector_id is not None:
            return (
                f"{type(self).__name__}(connector_id={self._connector_id!r}, "
                f"table_name={self._table_name!r}, "
                f"label_column={self._label_column!r})"
            )
        return (
            f"{type(self).__name__}(n_samples={self.n_samples}, "
            f"n_features={self.n_features}, label_column={self._label_column!r})"
        )
