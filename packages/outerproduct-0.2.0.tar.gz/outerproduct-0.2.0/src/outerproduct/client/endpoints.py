"""Typed endpoint constants — the wire contract in one place.

Every route on the OuterProduct API is declared here as either a
:class:`GetEndpoint` (response type only) or a :class:`PostEndpoint`
(request type + response type). Path templates may contain ``{}`` style
placeholders that the client fills in via keyword arguments at call
time (``_get(STATUS, model_id="m_abc")``).

Carrying the request/response types on the endpoint itself means
:meth:`OuterProductClient._get` and :meth:`._post` are generic over
those types — sub-APIs and end users get static type-safety with no
duplicated annotations at the call site.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Generic, TypeVar

from outerproduct_http_types import (
    ConnectorResponse,
    CreateConnectorRequest,
    CreateDocumentUploadRequest,
    CreateDocumentUploadResponse,
    CreateUploadRequest,
    CreateUploadResponse,
    DeleteConnectorResponse,
    ExplainRequest,
    ExplainResponse,
    InduceSchemaJobResponse,
    InduceSchemaRequest,
    InterpretRequest,
    InterpretResponse,
    ListConnectorsResponse,
    ListTablesRequest,
    ListTablesResponse,
    PatternTrackerApplyRequest,
    PatternTrackerDistributionResponse,
    PatternTrackerFitRequest,
    PatternTrackerFitResponse,
    PatternTrackerPartitionResponse,
    PatternTrackerResponse,
    PatternTrackerTransformResponse,
    PredictAndExplainRequest,
    PredictAndExplainResponse,
    PredictRequest,
    PredictResponse,
    ReasoningFitRequest,
    ReasoningFitResponse,
    ScenarioRequest,
    ScenarioResponse,
    SchemaResultResponse,
    StatusResponse,
    TabularizeJobResponse,
    TabularizeRequest,
    TabularizeResultResponse,
    TrainerRunRequest,
    TrainerRunResponse,
    ValidateConnectorResponse,
)
from pydantic import BaseModel

ReqT = TypeVar("ReqT", bound=BaseModel)
RespT = TypeVar("RespT", bound=BaseModel)


@dataclass(frozen=True)
class GetEndpoint(Generic[RespT]):
    """A ``GET`` endpoint, parameterised by its response model.

    ``path`` is a relative path (no leading slash) that may contain
    ``{name}`` placeholders to be filled in at call time.
    """

    path: str
    response_type: type[RespT]


@dataclass(frozen=True)
class PostEndpoint(Generic[ReqT, RespT]):
    """A ``POST`` endpoint, parameterised by its request and response models."""

    path: str
    request_type: type[ReqT]
    response_type: type[RespT]


@dataclass(frozen=True)
class DeleteEndpoint(Generic[RespT]):
    """A ``DELETE`` endpoint, parameterised by its response model."""

    path: str
    response_type: type[RespT]


# --------------------------------------------------------------------------- #
# Uploads                                                                     #
# --------------------------------------------------------------------------- #

CREATE_UPLOAD = PostEndpoint(
    path="uploads",
    request_type=CreateUploadRequest,
    response_type=CreateUploadResponse,
)
CREATE_DOCUMENT_UPLOAD = PostEndpoint(
    path="uploads/documents",
    request_type=CreateDocumentUploadRequest,
    response_type=CreateDocumentUploadResponse,
)

# --------------------------------------------------------------------------- #
# Agentic / documents                                                         #
# --------------------------------------------------------------------------- #

INDUCE_DOCUMENT_SCHEMA = PostEndpoint(
    path="agentic/documents/induce_schema",
    request_type=InduceSchemaRequest,
    response_type=InduceSchemaJobResponse,
)
GET_DOCUMENT_SCHEMA = GetEndpoint(
    path="agentic/documents/schemas/{model_id}",
    response_type=SchemaResultResponse,
)
TABULARIZE_DOCUMENTS = PostEndpoint(
    path="agentic/documents/tabularize",
    request_type=TabularizeRequest,
    response_type=TabularizeJobResponse,
)
GET_DOCUMENT_TABLE = GetEndpoint(
    path="agentic/documents/tables/{model_id}",
    response_type=TabularizeResultResponse,
)

# --------------------------------------------------------------------------- #
# Trainer                                                                     #
# --------------------------------------------------------------------------- #

TRAINER_RUN = PostEndpoint(
    path="trainer/run",
    request_type=TrainerRunRequest,
    response_type=TrainerRunResponse,
)

# --------------------------------------------------------------------------- #
# Reasoning                                                                   #
# --------------------------------------------------------------------------- #

REASONING_FIT = PostEndpoint(
    path="reasoning/fit",
    request_type=ReasoningFitRequest,
    response_type=ReasoningFitResponse,
)

# --------------------------------------------------------------------------- #
# Status (cross-cutting; covers fit / fit-distill / segment)                  #
# --------------------------------------------------------------------------- #

STATUS = GetEndpoint(
    path="models/{model_id}/status",
    response_type=StatusResponse,
)

# --------------------------------------------------------------------------- #
# Inference                                                                   #
# --------------------------------------------------------------------------- #

PREDICT = PostEndpoint(
    path="models/{model_id}/predict",
    request_type=PredictRequest,
    response_type=PredictResponse,
)
EXPLAIN = PostEndpoint(
    path="models/{model_id}/explain",
    request_type=ExplainRequest,
    response_type=ExplainResponse,
)
PREDICT_AND_EXPLAIN = PostEndpoint(
    path="models/{model_id}/predict_and_explain",
    request_type=PredictAndExplainRequest,
    response_type=PredictAndExplainResponse,
)
INTERPRET = PostEndpoint(
    path="models/{model_id}/interpret",
    request_type=InterpretRequest,
    response_type=InterpretResponse,
)
SCENARIO = PostEndpoint(
    path="models/{model_id}/scenario",
    request_type=ScenarioRequest,
    response_type=ScenarioResponse,
)

# --------------------------------------------------------------------------- #
# Pattern tracker                                                             #
# --------------------------------------------------------------------------- #

PATTERN_TRACKER_FIT = PostEndpoint(
    path="models/{model_id}/patterns/fit",
    request_type=PatternTrackerFitRequest,
    response_type=PatternTrackerFitResponse,
)
PATTERN_TRACKER_GET = GetEndpoint(
    path="models/{model_id}/patterns/{tracker_id}",
    response_type=PatternTrackerResponse,
)
PATTERN_TRACKER_TRANSFORM = PostEndpoint(
    path="models/{model_id}/patterns/{tracker_id}/transform",
    request_type=PatternTrackerApplyRequest,
    response_type=PatternTrackerTransformResponse,
)
PATTERN_TRACKER_DISTRIBUTION = PostEndpoint(
    path="models/{model_id}/patterns/{tracker_id}/distribution",
    request_type=PatternTrackerApplyRequest,
    response_type=PatternTrackerDistributionResponse,
)
PATTERN_TRACKER_PARTITION = PostEndpoint(
    path="models/{model_id}/patterns/{tracker_id}/partition",
    request_type=PatternTrackerApplyRequest,
    response_type=PatternTrackerPartitionResponse,
)

# --------------------------------------------------------------------------- #
# Connectors                                                                  #
# --------------------------------------------------------------------------- #

CREATE_CONNECTOR = PostEndpoint(
    path="connectors",
    # CreateConnectorRequest / ConnectorResponse are `Annotated[Union[...]]`
    # discriminated aliases — runtime usage routes through TypeAdapter, but
    # ty sees them where a plain `type[BaseModel]` is expected.
    request_type=CreateConnectorRequest,  # ty: ignore[invalid-argument-type]
    response_type=ConnectorResponse,  # ty: ignore[invalid-argument-type]
)
LIST_CONNECTORS = GetEndpoint(
    path="connectors",
    response_type=ListConnectorsResponse,
)
GET_CONNECTOR = GetEndpoint(
    path="connectors/{connector_id}",
    response_type=ConnectorResponse,  # ty: ignore[invalid-argument-type]
)
DELETE_CONNECTOR = DeleteEndpoint(
    path="connectors/{connector_id}",
    response_type=DeleteConnectorResponse,
)
LIST_TABLES = PostEndpoint(
    path="connectors/{connector_id}/tables",
    request_type=ListTablesRequest,
    response_type=ListTablesResponse,
)
VALIDATE_CONNECTOR = PostEndpoint(
    path="connectors/{connector_id}/validate",
    request_type=ListTablesRequest,  # empty body, reuse ListTablesRequest
    response_type=ValidateConnectorResponse,
)


__all__ = [
    "CREATE_CONNECTOR",
    "CREATE_DOCUMENT_UPLOAD",
    "CREATE_UPLOAD",
    "DELETE_CONNECTOR",
    "DeleteEndpoint",
    "EXPLAIN",
    "GET_CONNECTOR",
    "GET_DOCUMENT_SCHEMA",
    "GET_DOCUMENT_TABLE",
    "GetEndpoint",
    "INDUCE_DOCUMENT_SCHEMA",
    "INTERPRET",
    "LIST_CONNECTORS",
    "LIST_TABLES",
    "PATTERN_TRACKER_DISTRIBUTION",
    "PATTERN_TRACKER_FIT",
    "PATTERN_TRACKER_GET",
    "PATTERN_TRACKER_PARTITION",
    "PATTERN_TRACKER_TRANSFORM",
    "PREDICT",
    "PREDICT_AND_EXPLAIN",
    "PostEndpoint",
    "REASONING_FIT",
    "SCENARIO",
    "STATUS",
    "TABULARIZE_DOCUMENTS",
    "TRAINER_RUN",
    "VALIDATE_CONNECTOR",
]
