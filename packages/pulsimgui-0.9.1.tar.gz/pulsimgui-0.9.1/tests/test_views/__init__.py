"""Tests for view components."""
