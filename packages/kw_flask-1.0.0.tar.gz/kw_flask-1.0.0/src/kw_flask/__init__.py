"""kw-flask: Flask + MongoDB + Docker + Session Auth başlangıç şablonu."""

__version__ = "1.0.0"
