#!/usr/bin/env python3

import os
import sys
import shutil
import secrets
from pathlib import Path


def main():
    args = sys.argv[1:]

    if not args or args[0] in ("-h", "--help"):
        print("""
kw-flask — Flask + MongoDB + Session Auth başlangıç şablonu

Kullanım:
  kw-flask <proje-adı>

Örnekler:
  kw-flask siparis-api
  kw-flask kullanici-servisi
  kw-flask admin-panel
""")
        sys.exit(0 if args else 1)

    project_name = args[0]

    # Proje adı doğrulama
    if not project_name.replace("-", "").replace("_", "").isalnum():
        print(f"\n❌  Geçersiz proje adı: '{project_name}'")
        print("    Sadece harf, rakam, tire (-) ve alt çizgi (_) kullanabilirsiniz.\n")
        sys.exit(1)

    target_dir = Path.cwd() / project_name

    if target_dir.exists():
        print(f"\n❌  '{project_name}' klasörü zaten mevcut!\n")
        sys.exit(1)

    template_dir = Path(__file__).resolve().parent / "template"

    if not template_dir.exists():
        print(f"\n❌  Şablon dizini bulunamadı: {template_dir}\n")
        sys.exit(1)

    print(f"\n🚀  '{project_name}' projesi oluşturuluyor...")

    # Template'i kopyala (.gitignore dahil)
    shutil.copytree(template_dir, target_dir)

    # Rastgele SECRET_KEY üret ve .env yaz
    env_content = f"""\
FLASK_ENV=development
FLASK_DEBUG=True
PORT=5000

MONGO_URI=mongodb://mongo:27017/{project_name}
MONGO_DB_NAME={project_name}

SECRET_KEY={secrets.token_hex(32)}

BCRYPT_LOG_ROUNDS=12
"""

    (target_dir / ".env").write_text(env_content)

    # .env.example: değerleri boşalt, key'leri koru
    example_lines = []
    for line in env_content.splitlines():
        if "=" in line and not line.startswith("#"):
            key = line.split("=")[0]
            example_lines.append(f"{key}=")
        else:
            example_lines.append(line)
    (target_dir / ".env.example").write_text("\n".join(example_lines))

    # docker-compose.yml içindeki PROJECT_NAME yer tutucusunu değiştir
    compose_path = target_dir / "docker-compose.yml"
    if compose_path.exists():
        compose_path.write_text(
            compose_path.read_text().replace("PROJECT_NAME", project_name)
        )

    print(f"""
✅  Hazır!

   cd {project_name}

   ┌─ Docker ile (önerilen) ──────────────────────┐
   │  docker compose up -d                        │
   │  # http://localhost:5000                     │
   │  # http://localhost:8081  (Mongo Express UI) │
   └──────────────────────────────────────────────┘

   ┌─ Lokal ──────────────────────────────────────┐
   │  python -m venv venv                         │
   │  source venv/bin/activate                    │
   │  pip install -r requirements.txt             │
   │  flask run                                   │
   └──────────────────────────────────────────────┘

📡  Endpoint'ler:
   POST  /api/v1/auth/register
   POST  /api/v1/auth/login        (body: remember=true → 30 gün)
   POST  /api/v1/auth/logout
   GET   /api/v1/auth/me
   GET   /api/v1/auth/check
   GET   /api/v1/users             (admin only)
   GET   /api/v1/users/<id>
   PATCH /api/v1/users/<id>
   GET   /health
""")


if __name__ == "__main__":
    main()
