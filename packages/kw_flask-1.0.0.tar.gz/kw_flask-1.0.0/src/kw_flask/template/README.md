# 🚀 Flask REST API Boilerplate

MongoDB + Flask + JWT + Docker ile hazır, modüler REST API şablonu.

## Kurulum

### create-flask-app ile (önerilen)
```bash
pip install -e /path/to/create-flask-app
create-flask-app benim-projem
cd benim-projem
```

### Docker ile başlat
```bash
docker compose up -d
```

### Lokal başlat
```bash
python -m venv venv
source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
flask run
```

---

## 📁 Proje Yapısı

```
app/
├── __init__.py               ← Uygulama factory (create_app)
├── core/
│   ├── config.py             ← Ortam bazlı konfigürasyon
│   ├── database/
│   │   └── connection.py     ← DatabaseManager (MongoEngine)
│   ├── exceptions/
│   │   ├── exceptions.py     ← AppException, NotFoundException, ...
│   │   └── handlers.py       ← Flask global hata yöneticileri
│   └── middlewares/
│       ├── jwt.py            ← JWTManager, token blacklist
│       └── health.py         ← /health ve / route'ları
├── modules/
│   └── user/
│       ├── models/
│       │   └── user_model.py ← MongoEngine User belgesi
│       ├── services/
│       │   ├── auth_service.py   ← register, login, refresh, logout
│       │   └── user_service.py   ← CRUD işlemleri
│       ├── routes/
│       │   ├── auth_routes.py    ← /api/v1/auth Blueprint
│       │   └── user_routes.py    ← /api/v1/users Blueprint
│       └── validators/
│           └── schemas.py        ← Marshmallow şemaları
└── utils/
    ├── response.py           ← success_response / error_response
    ├── validators.py         ← validate_request yardımcısı
    └── logger.py             ← Yapılandırılmış loglama
```

---

## 🔌 API Endpoint'leri

### Auth
| Metod | Endpoint | Açıklama |
|-------|----------|----------|
| POST | `/api/v1/auth/register` | Yeni kullanıcı kaydı |
| POST | `/api/v1/auth/login` | Giriş yap |
| POST | `/api/v1/auth/refresh` | Access token yenile |
| POST | `/api/v1/auth/logout` | Çıkış yap (token iptal) |
| GET  | `/api/v1/auth/me` | Mevcut kullanıcı bilgisi |

### Kullanıcılar
| Metod | Endpoint | Açıklama |
|-------|----------|----------|
| GET | `/api/v1/users` | Kullanıcı listesi |
| GET | `/api/v1/users/<id>` | Kullanıcı detayı |
| PATCH | `/api/v1/users/<id>` | Profil güncelle |
| POST | `/api/v1/users/<id>/change-password` | Şifre değiştir |
| DELETE | `/api/v1/users/<id>` | Hesabı devre dışı bırak |

### Sistem
| Metod | Endpoint | Açıklama |
|-------|----------|----------|
| GET | `/health` | Servis + DB sağlık durumu |
| GET | `/` | API durumu |

---

## 🆕 Yeni Modül Eklemek

1. `app/modules/<modül_adı>/` klasörü oluştur
2. `models/`, `services/`, `routes/`, `validators/` alt klasörlerini ekle
3. Service sınıfını `UserService` örneğini alarak yaz
4. Blueprint'i `app/__init__.py` içindeki `_register_blueprints` fonksiyonuna kaydet

---

## 🔐 Ortam Değişkenleri

| Değişken | Açıklama | Varsayılan |
|----------|----------|-----------|
| `FLASK_ENV` | Ortam (development/production) | development |
| `PORT` | Dinlenecek port | 5000 |
| `MONGO_URI` | MongoDB bağlantı adresi | — |
| `JWT_SECRET_KEY` | Access token imzalama anahtarı | — |
| `JWT_REFRESH_SECRET_KEY` | Refresh token imzalama anahtarı | — |
| `JWT_ACCESS_TOKEN_EXPIRES` | Access token süresi (saniye) | 900 |
| `JWT_REFRESH_TOKEN_EXPIRES` | Refresh token süresi (saniye) | 2592000 |
| `BCRYPT_LOG_ROUNDS` | Bcrypt iş faktörü | 12 |
