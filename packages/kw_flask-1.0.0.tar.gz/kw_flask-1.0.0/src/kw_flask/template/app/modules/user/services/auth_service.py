from datetime import datetime, timezone
import bcrypt
from flask import current_app
from flask_login import login_user, logout_user

from ..models.user_model import User
from ...core.exceptions.exceptions import (
    ConflictException, UnauthorizedException
)


class AuthService:
    """
    Session tabanlı kimlik doğrulama servisi.
    Flask-Login'in login_user / logout_user fonksiyonlarını kullanır;
    session yönetimi tamamen sunucu taraflıdır.
    """

    @staticmethod
    def register(data: dict) -> User:
        """Yeni kullanıcı oluşturur ve oturumu açar."""
        email = data["email"].lower().strip()

        if User.objects(email=email).first():
            raise ConflictException(f"'{email}' adresi zaten kayıtlı.")

        rounds = current_app.config.get("BCRYPT_LOG_ROUNDS", 12)
        password_hash = bcrypt.hashpw(
            data["password"].encode("utf-8"),
            bcrypt.gensalt(rounds=rounds)
        ).decode("utf-8")

        user = User(
            email=email,
            password_hash=password_hash,
            first_name=data["first_name"].strip(),
            last_name=data["last_name"].strip(),
        )
        user.save()

        # Kayıt sonrası otomatik oturum aç; remember=False → tarayıcı kapanınca biter
        login_user(user, remember=False)
        return user

    @staticmethod
    def login(email: str, password: str, remember: bool = False) -> User:
        """
        Email + şifre ile giriş yapar.
        remember=True → kalıcı cookie (PERMANENT_SESSION_LIFETIME kadar)
        """
        email = email.lower().strip()
        user = User.objects(email=email).first()

        if not user or not bcrypt.checkpw(
            password.encode("utf-8"),
            user.password_hash.encode("utf-8")
        ):
            raise UnauthorizedException("Email veya şifre hatalı.")

        if not user.is_active:
            raise UnauthorizedException("Hesabınız devre dışı bırakılmış.")

        user.last_login = datetime.now(timezone.utc)
        user.save()

        login_user(user, remember=remember)
        return user

    @staticmethod
    def logout() -> None:
        """Mevcut oturumu sonlandırır, session temizlenir."""
        logout_user()
