from flask import Blueprint, request
from flask_login import login_required, current_user

from ..services.user_service import UserService
from ..validators.schemas import UpdateUserSchema, ChangePasswordSchema
from ....utils.response import success_response, error_response
from ....utils.validators import validate_request
from ....core.middlewares.session import require_roles

user_bp = Blueprint("users", __name__)

_update_schema = UpdateUserSchema()
_change_pw_schema = ChangePasswordSchema()


@user_bp.get("/")
@login_required
@require_roles("admin")
def list_users():
    """GET /api/v1/users - Sadece admin rolü erişebilir."""
    page = request.args.get("page", 1, type=int)
    per_page = min(request.args.get("per_page", 20, type=int), 100)
    result = UserService.get_all(page, per_page)
    return success_response(result)


@user_bp.get("/<user_id>")
@login_required
def get_user(user_id: str):
    user = UserService.get_by_id(user_id)
    return success_response(user.to_public_dict())


@user_bp.patch("/<user_id>")
@login_required
def update_user(user_id: str):
    data, errors = validate_request(_update_schema, request.get_json())
    if errors:
        return error_response("Doğrulama hatası.", 422, errors)
    user = UserService.update(user_id, str(current_user.id), data)
    return success_response(user.to_public_dict(), "Profil güncellendi.")


@user_bp.post("/<user_id>/change-password")
@login_required
def change_password(user_id: str):
    data, errors = validate_request(_change_pw_schema, request.get_json())
    if errors:
        return error_response("Doğrulama hatası.", 422, errors)
    UserService.change_password(user_id, data["current_password"], data["new_password"])
    return success_response(None, "Şifre değiştirildi.")


@user_bp.delete("/<user_id>")
@login_required
def deactivate_user(user_id: str):
    UserService.deactivate(user_id, str(current_user.id))
    return success_response(None, "Hesap devre dışı bırakıldı.")
