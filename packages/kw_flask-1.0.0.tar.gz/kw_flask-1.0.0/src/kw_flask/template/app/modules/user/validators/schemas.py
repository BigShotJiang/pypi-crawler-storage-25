from marshmallow import Schema, fields, validate, validates, ValidationError


class RegisterSchema(Schema):
    email = fields.Email(required=True)
    password = fields.Str(required=True, validate=validate.Length(min=8, max=128))
    first_name = fields.Str(required=True, validate=validate.Length(min=2, max=100))
    last_name = fields.Str(required=True, validate=validate.Length(min=2, max=100))

    @validates("password")
    def validate_password_strength(self, value: str):
        if not any(c.isupper() for c in value):
            raise ValidationError("Şifre en az bir büyük harf içermelidir.")
        if not any(c.isdigit() for c in value):
            raise ValidationError("Şifre en az bir rakam içermelidir.")


class LoginSchema(Schema):
    email = fields.Email(required=True)
    password = fields.Str(required=True, validate=validate.Length(min=1))
    remember = fields.Bool(load_default=False)   # True → kalıcı oturum (30 gün)


class UpdateUserSchema(Schema):
    first_name = fields.Str(validate=validate.Length(min=2, max=100))
    last_name = fields.Str(validate=validate.Length(min=2, max=100))


class ChangePasswordSchema(Schema):
    current_password = fields.Str(required=True)
    new_password = fields.Str(required=True, validate=validate.Length(min=8, max=128))
