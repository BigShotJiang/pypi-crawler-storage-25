from flask import Blueprint, request
from flask_login import login_required, current_user

from ..services.auth_service import AuthService
from ..validators.schemas import RegisterSchema, LoginSchema
from ....utils.response import success_response, error_response
from ....utils.validators import validate_request

auth_bp = Blueprint("auth", __name__)

_register_schema = RegisterSchema()
_login_schema = LoginSchema()


@auth_bp.post("/register")
def register():
    """
    POST /api/v1/auth/register
    Body: { email, password, first_name, last_name }
    Başarılı kayıt sonrası oturum otomatik açılır.
    """
    data, errors = validate_request(_register_schema, request.get_json())
    if errors:
        return error_response("Doğrulama hatası.", 422, errors)

    user = AuthService.register(data)
    return success_response(user.to_public_dict(), "Kayıt başarılı.", 201)


@auth_bp.post("/login")
def login():
    """
    POST /api/v1/auth/login
    Body: { email, password, remember? }
    remember=true → kalıcı oturum (30 gün)
    """
    data, errors = validate_request(_login_schema, request.get_json())
    if errors:
        return error_response("Doğrulama hatası.", 422, errors)

    remember = data.get("remember", False)
    user = AuthService.login(data["email"], data["password"], remember=remember)
    return success_response(user.to_public_dict(), "Giriş başarılı.")


@auth_bp.post("/logout")
@login_required
def logout():
    """
    POST /api/v1/auth/logout
    Session sunucudan ve cookie'den temizlenir.
    """
    AuthService.logout()
    return success_response(None, "Çıkış yapıldı.")


@auth_bp.get("/me")
@login_required
def me():
    """
    GET /api/v1/auth/me
    Mevcut oturum açık kullanıcıyı döner.
    """
    return success_response(current_user.to_public_dict())


@auth_bp.get("/check")
def check():
    """
    GET /api/v1/auth/check
    Session kontrolü — token gerektirmez, cookie yeterli.
    """
    if current_user.is_authenticated:
        return success_response({"authenticated": True, "user": current_user.to_public_dict()})
    return success_response({"authenticated": False})
