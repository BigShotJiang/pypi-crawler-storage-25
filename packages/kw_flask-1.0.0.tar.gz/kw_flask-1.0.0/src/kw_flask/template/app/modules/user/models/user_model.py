from datetime import datetime, timezone
from flask_login import UserMixin
from mongoengine import (
    Document, StringField, BooleanField,
    DateTimeField, ListField, EmailField
)


class User(UserMixin, Document):
    """
    Kullanıcı belgesi.
    UserMixin: is_authenticated, is_active, is_anonymous, get_id() sağlar.
    Flask-Login bu metodları session yönetimi için kullanır.
    """

    email = EmailField(required=True, unique=True, max_length=255)
    password_hash = StringField(required=True)
    first_name = StringField(required=True, max_length=100)
    last_name = StringField(required=True, max_length=100)
    roles = ListField(StringField(max_length=50), default=["user"])
    is_active = BooleanField(default=True)
    is_verified = BooleanField(default=False)
    last_login = DateTimeField(null=True)
    created_at = DateTimeField(default=lambda: datetime.now(timezone.utc))
    updated_at = DateTimeField(default=lambda: datetime.now(timezone.utc))

    meta = {
        "collection": "users",
        "indexes": ["email", "is_active"],
        "ordering": ["-created_at"],
    }

    def get_id(self) -> str:
        """Flask-Login'in session'a kaydettiği kullanıcı kimliği."""
        return str(self.id)

    def save(self, *args, **kwargs):
        self.updated_at = datetime.now(timezone.utc)
        return super().save(*args, **kwargs)

    def to_public_dict(self) -> dict:
        return {
            "id": str(self.id),
            "email": self.email,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "roles": self.roles,
            "is_active": self.is_active,
            "is_verified": self.is_verified,
            "last_login": self.last_login.isoformat() if self.last_login else None,
            "created_at": self.created_at.isoformat(),
        }

    def __repr__(self) -> str:
        return f"<User {self.email}>"
