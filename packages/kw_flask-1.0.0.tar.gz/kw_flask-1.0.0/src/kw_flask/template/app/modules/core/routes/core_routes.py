from flask import Blueprint
from ....utils.response import success_response

core_bp = Blueprint("core", __name__)


@core_bp.get("/")
def index():
    return success_response({
        "name": "Flask API",
        "version": "1.0.0",
    }, "Welcome!")


@core_bp.get("/ping")
def ping():
    return success_response({"pong": True})