import bcrypt
from flask import current_app

from ..models.user_model import User
from ...core.exceptions.exceptions import (
    NotFoundException, ConflictException, ForbiddenException
)


class UserService:
    """
    Kullanıcı CRUD işlemlerini yöneten servis.
    """

    @staticmethod
    def get_by_id(user_id: str) -> User:
        user = User.objects(id=user_id).first()
        if not user:
            raise NotFoundException(f"Kullanıcı bulunamadı: {user_id}")
        return user

    @staticmethod
    def get_all(page: int = 1, per_page: int = 20) -> dict:
        total = User.objects.count()
        users = User.objects.skip((page - 1) * per_page).limit(per_page)
        return {
            "items": [u.to_public_dict() for u in users],
            "total": total,
            "page": page,
            "per_page": per_page,
            "pages": (total + per_page - 1) // per_page,
        }

    @staticmethod
    def update(user_id: str, requester_id: str, data: dict) -> User:
        """Kullanıcı kendi profilini güncelleyebilir."""
        user = UserService.get_by_id(user_id)

        if str(user.id) != requester_id:
            raise ForbiddenException("Başka bir kullanıcıyı düzenleyemezsiniz.")

        allowed = {"first_name", "last_name"}
        for field in allowed:
            if field in data:
                setattr(user, field, data[field].strip())

        user.save()
        return user

    @staticmethod
    def change_password(user_id: str, current_password: str, new_password: str) -> None:
        user = UserService.get_by_id(user_id)

        if not bcrypt.checkpw(
            current_password.encode("utf-8"),
            user.password_hash.encode("utf-8")
        ):
            raise ForbiddenException("Mevcut şifre hatalı.")

        rounds = current_app.config.get("BCRYPT_LOG_ROUNDS", 12)
        user.password_hash = bcrypt.hashpw(
            new_password.encode("utf-8"),
            bcrypt.gensalt(rounds=rounds)
        ).decode("utf-8")
        user.save()

    @staticmethod
    def deactivate(user_id: str, requester_id: str) -> None:
        user = UserService.get_by_id(user_id)

        if str(user.id) != requester_id:
            raise ForbiddenException("Bu işlem için yetkiniz yok.")

        user.is_active = False
        user.save()
