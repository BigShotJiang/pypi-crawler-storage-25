from flask import Flask
from .core.config import config_by_name
from .core.database.connection import DatabaseManager
from .core.exceptions.handlers import register_error_handlers
from .core.middlewares.session import configure_session
from .utils.logger import setup_logger


def create_app(env: str = "development") -> Flask:
    app = Flask(__name__)
    app.config.from_object(config_by_name[env])

    setup_logger(app)
    DatabaseManager.init_app(app)
    configure_session(app)
    register_error_handlers(app)
    _register_blueprints(app)

    app.logger.info(f"Uygulama başlatıldı: env={env}")
    return app


def _register_blueprints(app: Flask) -> None:
    from .modules.user.routes.auth_routes import auth_bp
    from .modules.user.routes.user_routes import user_bp
    from .core.middlewares.health import health_bp

    app.register_blueprint(health_bp)
    app.register_blueprint(auth_bp, url_prefix="/api/v1/auth")
    app.register_blueprint(user_bp, url_prefix="/api/v1/users")
