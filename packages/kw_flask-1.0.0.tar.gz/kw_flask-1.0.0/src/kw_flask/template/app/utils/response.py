from flask import jsonify, Response


def success_response(
    data=None,
    message: str = "İşlem başarılı.",
    status_code: int = 200
) -> tuple[Response, int]:
    body = {"success": True, "message": message}
    if data is not None:
        body["data"] = data
    return jsonify(body), status_code


def error_response(
    message: str,
    status_code: int = 400,
    details=None
) -> tuple[Response, int]:
    body = {
        "success": False,
        "error": {"message": message, "code": status_code}
    }
    if details:
        body["error"]["details"] = details
    return jsonify(body), status_code
