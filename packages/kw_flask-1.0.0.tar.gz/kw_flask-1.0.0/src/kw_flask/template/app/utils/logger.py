import logging
import sys
from flask import Flask


def setup_logger(app: Flask) -> None:
    log_level = logging.DEBUG if app.debug else logging.INFO

    formatter = logging.Formatter(
        fmt="%(asctime)s | %(levelname)-8s | %(name)s | %(message)s",
        datefmt="%Y-%m-%d %H:%M:%S"
    )

    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(formatter)

    root_logger = logging.getLogger()
    root_logger.setLevel(log_level)
    root_logger.handlers.clear()
    root_logger.addHandler(handler)

    # Gürültülü kütüphane loglarını bastır
    logging.getLogger("pymongo").setLevel(logging.WARNING)
    logging.getLogger("mongoengine").setLevel(logging.WARNING)
    logging.getLogger("werkzeug").setLevel(logging.WARNING)

    app.logger.setLevel(log_level)
