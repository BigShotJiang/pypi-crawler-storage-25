from marshmallow import Schema, ValidationError


def validate_request(schema: Schema, data: dict | None) -> tuple[dict, dict | None]:
    """
    Gelen JSON'u marshmallow şemasıyla doğrular.
    Başarılıysa (temiz_veri, None), hatalıysa ({}, hata_dict) döner.
    """
    if not data:
        return {}, {"body": ["JSON gövdesi boş veya geçersiz."]}

    try:
        clean = schema.load(data)
        return clean, None
    except ValidationError as e:
        return {}, e.messages
