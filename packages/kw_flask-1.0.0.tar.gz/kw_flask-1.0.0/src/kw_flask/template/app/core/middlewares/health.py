from flask import Blueprint, jsonify
from mongoengine.connection import get_connection

health_bp = Blueprint("health", __name__)


@health_bp.get("/health")
def health_check():
    """Servis ve veritabanı sağlık kontrolü."""
    db_status = "ok"
    try:
        get_connection().admin.command("ping")
    except Exception:
        db_status = "unavailable"

    status = "ok" if db_status == "ok" else "degraded"
    return jsonify({
        "status": status,
        "services": {
            "api": "ok",
            "database": db_status
        }
    }), 200 if status == "ok" else 503


@health_bp.get("/")
def root():
    return jsonify({"message": "API çalışıyor 🚀", "version": "1.0.0"})
