from flask import Flask
from flask_mongoengine import MongoEngine

db = MongoEngine()


class DatabaseManager:
    """
    MongoEngine bağlantısını yöneten singleton yönetici sınıfı.
    Bağlantı havuzu, yeniden bağlanma ve sağlık kontrolü içerir.
    """

    _instance: "DatabaseManager | None" = None

    @classmethod
    def init_app(cls, app: Flask) -> None:
        db.init_app(app)
        app.logger.info("MongoDB bağlantısı başlatıldı.")

        with app.app_context():
            cls._verify_connection(app)

    @staticmethod
    def _verify_connection(app: Flask) -> None:
        try:
            from mongoengine.connection import get_connection
            conn = get_connection()
            conn.admin.command("ping")
            app.logger.info("✅ MongoDB bağlantısı doğrulandı.")
        except Exception as e:
            app.logger.warning(f"⚠️  MongoDB bağlantı doğrulaması başarısız: {e}")

    @staticmethod
    def get_db() -> MongoEngine:
        return db
