from http import HTTPStatus


class AppException(Exception):
    """Tüm uygulama hatalarının taban sınıfı."""

    status_code: int = HTTPStatus.INTERNAL_SERVER_ERROR
    message: str = "Beklenmeyen bir hata oluştu."

    def __init__(self, message: str | None = None, status_code: int | None = None):
        self.message = message or self.__class__.message
        self.status_code = status_code or self.__class__.status_code
        super().__init__(self.message)

    def to_dict(self) -> dict:
        return {
            "success": False,
            "error": {
                "message": self.message,
                "code": self.status_code,
            },
        }


class NotFoundException(AppException):
    status_code = HTTPStatus.NOT_FOUND
    message = "Kayıt bulunamadı."


class ValidationException(AppException):
    status_code = HTTPStatus.UNPROCESSABLE_ENTITY
    message = "Doğrulama hatası."

    def __init__(self, errors: dict | None = None, message: str | None = None):
        self.errors = errors or {}
        super().__init__(message)

    def to_dict(self) -> dict:
        base = super().to_dict()
        base["error"]["details"] = self.errors
        return base


class UnauthorizedException(AppException):
    status_code = HTTPStatus.UNAUTHORIZED
    message = "Kimlik doğrulama başarısız."


class ForbiddenException(AppException):
    status_code = HTTPStatus.FORBIDDEN
    message = "Bu işlem için yetkiniz yok."


class ConflictException(AppException):
    status_code = HTTPStatus.CONFLICT
    message = "Kayıt zaten mevcut."
