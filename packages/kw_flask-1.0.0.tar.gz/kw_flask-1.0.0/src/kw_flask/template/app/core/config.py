import os
from datetime import timedelta
from dotenv import load_dotenv

load_dotenv()


class BaseConfig:
    DEBUG = False
    TESTING = False

    # MongoDB
    MONGODB_SETTINGS = {
        "host": os.getenv("MONGO_URI", "mongodb://localhost:27017/myapp"),
        "db": os.getenv("MONGO_DB_NAME", "myapp"),
        "serverSelectionTimeoutMS": 5000,
        "connectTimeoutMS": 10000,
    }

    # Session
    SECRET_KEY = os.getenv("SECRET_KEY", "change-me-in-production")
    PERMANENT_SESSION_LIFETIME = timedelta(days=30)
    SESSION_COOKIE_NAME = "session"
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = "Lax"
    SESSION_COOKIE_SECURE = os.getenv("FLASK_ENV") == "production"

    # Genel
    BCRYPT_LOG_ROUNDS = int(os.getenv("BCRYPT_LOG_ROUNDS", 12))
    JSON_SORT_KEYS = False
    PROPAGATE_EXCEPTIONS = True


class DevelopmentConfig(BaseConfig):
    DEBUG = True


class ProductionConfig(BaseConfig):
    DEBUG = False
    BCRYPT_LOG_ROUNDS = 13
    SESSION_COOKIE_SECURE = True


class TestingConfig(BaseConfig):
    TESTING = True
    DEBUG = True
    WTF_CSRF_ENABLED = False
    MONGODB_SETTINGS = {
        "host": "mongomock://localhost",
        "db": "test_db",
    }


config_by_name = {
    "development": DevelopmentConfig,
    "production": ProductionConfig,
    "testing": TestingConfig,
}
