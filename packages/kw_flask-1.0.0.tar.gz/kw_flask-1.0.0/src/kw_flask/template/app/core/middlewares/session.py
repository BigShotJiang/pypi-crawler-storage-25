from flask import Flask, jsonify, session, request
from flask_login import LoginManager, current_user
from functools import wraps

login_manager = LoginManager()


def configure_session(app: Flask) -> None:
    """
    Flask-Login ve server-side session yapılandırması.
    Session verileri sunucuda tutulur; client sadece imzalı cookie taşır.
    """
    app.config.setdefault("SESSION_COOKIE_HTTPONLY", True)
    app.config.setdefault("SESSION_COOKIE_SAMESITE", "Lax")
    # Production'da True yap (HTTPS zorunlu olur)
    app.config.setdefault("SESSION_COOKIE_SECURE", False)

    login_manager.init_app(app)
    login_manager.session_protection = "strong"

    @login_manager.unauthorized_handler
    def unauthorized():
        return jsonify({
            "success": False,
            "error": {"message": "Oturum açmanız gerekiyor.", "code": 401}
        }), 401

    @login_manager.user_loader
    def load_user(user_id: str):
        from ...modules.user.models.user_model import User
        try:
            return User.objects(id=user_id, is_active=True).first()
        except Exception:
            return None


def require_roles(*roles: str):
    """
    Belirli rolleri zorunlu kılan dekoratör.
    Kullanım: @require_roles("admin", "moderator")
    """
    def decorator(f):
        @wraps(f)
        def decorated(*args, **kwargs):
            if not current_user.is_authenticated:
                return jsonify({
                    "success": False,
                    "error": {"message": "Oturum açmanız gerekiyor.", "code": 401}
                }), 401

            if not any(role in current_user.roles for role in roles):
                return jsonify({
                    "success": False,
                    "error": {"message": "Bu işlem için yetkiniz yok.", "code": 403}
                }), 403

            return f(*args, **kwargs)
        return decorated
    return decorator
