from flask import Flask, jsonify
from werkzeug.exceptions import HTTPException
from mongoengine.errors import ValidationError, NotUniqueError, DoesNotExist
from .exceptions import AppException
import logging

logger = logging.getLogger(__name__)


def register_error_handlers(app: Flask) -> None:

    @app.errorhandler(AppException)
    def handle_app_exception(e: AppException):
        logger.warning(f"AppException [{e.status_code}]: {e.message}")
        return jsonify(e.to_dict()), e.status_code

    @app.errorhandler(ValidationError)
    def handle_mongo_validation(e: ValidationError):
        logger.warning(f"MongoEngine ValidationError: {e}")
        return jsonify({
            "success": False,
            "error": {"message": "Veri doğrulama hatası.", "details": str(e), "code": 422}
        }), 422

    @app.errorhandler(NotUniqueError)
    def handle_not_unique(e: NotUniqueError):
        return jsonify({
            "success": False,
            "error": {"message": "Bu kayıt zaten mevcut.", "code": 409}
        }), 409

    @app.errorhandler(DoesNotExist)
    def handle_does_not_exist(e: DoesNotExist):
        return jsonify({
            "success": False,
            "error": {"message": "Kayıt bulunamadı.", "code": 404}
        }), 404

    @app.errorhandler(HTTPException)
    def handle_http_exception(e: HTTPException):
        return jsonify({
            "success": False,
            "error": {"message": e.description, "code": e.code}
        }), e.code

    @app.errorhandler(Exception)
    def handle_generic_exception(e: Exception):
        logger.exception(f"Beklenmeyen hata: {e}")
        return jsonify({
            "success": False,
            "error": {"message": "Sunucu hatası.", "code": 500}
        }), 500
