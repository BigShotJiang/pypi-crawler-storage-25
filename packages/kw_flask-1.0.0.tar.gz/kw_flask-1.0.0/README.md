# kw-flask

**Flask + MongoDB + Docker + Session Auth** — tek komutla hazır, modüler REST API şablonu.

```bash
pip install kw-flask
kw-flask benim-projem
```

---

## Özellikler

- 🏗️ **Blueprint tabanlı modüler yapı** — her modül kendi route/service/model/validator'ına sahip
- 🔐 **Flask-Login session auth** — server-side session, `remember me`, rol bazlı erişim
- 🍃 **MongoEngine ODM** — class tabanlı MongoDB modelleri
- 🐳 **Docker Compose** — app + MongoDB + Mongo Express UI hazır
- ⚙️ **Ortam bazlı config** — development / production / testing
- 🛡️ **Global hata yönetimi** — tüm hatalar tutarlı JSON döner
- 🔑 **Otomatik SECRET_KEY** — her projede benzersiz anahtar üretilir

---

## Hızlı Başlangıç

```bash
# Kur
pip install kw-flask

# Proje oluştur
kw-flask siparis-api
cd siparis-api

# Docker ile başlat
docker compose up -d
```

API `http://localhost:5000` adresinde hazır.  
Mongo Express UI: `http://localhost:8081`

---

## Endpoint'ler

| Metod | Endpoint | Açıklama |
|-------|----------|----------|
| POST | `/api/v1/auth/register` | Kayıt ol (oturum otomatik açılır) |
| POST | `/api/v1/auth/login` | Giriş yap (`remember: true` → 30 gün) |
| POST | `/api/v1/auth/logout` | Çıkış yap |
| GET | `/api/v1/auth/me` | Oturum açık kullanıcı |
| GET | `/api/v1/auth/check` | Session kontrolü |
| GET | `/api/v1/users` | Kullanıcı listesi (admin) |
| GET | `/api/v1/users/<id>` | Kullanıcı detayı |
| PATCH | `/api/v1/users/<id>` | Profil güncelle |
| POST | `/api/v1/users/<id>/change-password` | Şifre değiştir |
| DELETE | `/api/v1/users/<id>` | Hesabı devre dışı bırak |
| GET | `/health` | Servis + DB sağlık durumu |

---

## Proje Yapısı

```
app/
├── core/
│   ├── config.py              # Ortam bazlı konfigürasyon
│   ├── database/connection.py # DatabaseManager (MongoEngine)
│   ├── exceptions/            # AppException hiyerarşisi + global handler'lar
│   └── middlewares/
│       ├── session.py         # Flask-Login + @require_roles dekoratörü
│       └── health.py          # /health endpoint'i
├── modules/
│   └── user/
│       ├── models/            # MongoEngine User (UserMixin dahil)
│       ├── services/          # AuthService, UserService (class tabanlı)
│       ├── routes/            # Blueprint'ler
│       └── validators/        # Marshmallow şemaları
└── utils/
    ├── response.py            # success_response / error_response
    ├── validators.py          # validate_request yardımcısı
    └── logger.py              # Yapılandırılmış loglama
```

---

## Yeni Modül Eklemek

```
app/modules/
└── urun/
    ├── __init__.py
    ├── models/urun_model.py
    ├── services/urun_service.py
    ├── routes/urun_routes.py
    └── validators/schemas.py
```

`app/__init__.py` içindeki `_register_blueprints` fonksiyonuna blueprint'i kaydet:

```python
from .modules.urun.routes.urun_routes import urun_bp
app.register_blueprint(urun_bp, url_prefix="/api/v1/urunler")
```

---

## Rol Bazlı Erişim

```python
from app.core.middlewares.session import require_roles

@urun_bp.delete("/<id>")
@login_required
@require_roles("admin")
def delete_urun(id):
    ...
```

---

## Ortam Değişkenleri

| Değişken | Açıklama |
|----------|----------|
| `FLASK_ENV` | `development` / `production` |
| `MONGO_URI` | MongoDB bağlantı adresi |
| `MONGO_DB_NAME` | Veritabanı adı |
| `SECRET_KEY` | Session imzalama anahtarı (otomatik üretilir) |
| `BCRYPT_LOG_ROUNDS` | Bcrypt iş faktörü (varsayılan: 12) |

---

## Lisans

MIT
