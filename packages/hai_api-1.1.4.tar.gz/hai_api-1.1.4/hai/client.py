import os
import json
import time
import asyncio
import re
import httpx
from typing import Optional, Dict, Any, AsyncGenerator, Generator, List, Callable, Union
from dotenv import load_dotenv

# Ensure environment variables are loaded
load_dotenv()


class HAIResponse:
    """Represents a complete or partial response from the hAI API."""
    def __init__(self):
        self.text = ""
        self.thinking_text = ""
        self.search_text = ""
        self.image_urls = []
        self.is_done = False
        self.session_id = None
        self.parent_message_id = None
        self.latency_ms = 0

    @property
    def process_text(self):
        """Unified text for the entire AI process (Thinking + Searching)"""
        p = ""
        if self.search_text:
            p += self.search_text
        if self.thinking_text:
            if p and not p.endswith("\n"): p += "\n"
            p += self.thinking_text
        return p

    def __str__(self):
        return self.text

    def to_dict(self) -> Dict[str, Any]:
        return {
            "text": self.text,
            "thinking_text": self.thinking_text,
            "session_id": self.session_id,
            "parent_message_id": self.parent_message_id,
            "latency_ms": self.latency_ms,
            "is_done": self.is_done
        }


class MemoryStore:
    """Internal memory manager that tracks conversation history per thread."""
    def __init__(self):
        # Maps custom session_id → {"chat_session_id": ..., "parent_message_id": ..., "history": [...]}
        self.sessions: Dict[str, Dict] = {}

    def get_ids(self, custom_session_id: str) -> Dict[str, Optional[str]]:
        if not custom_session_id:
            return {"chat_session_id": None, "parent_message_id": None}
        return {
            "chat_session_id": self.sessions.get(custom_session_id, {}).get("chat_session_id"),
            "parent_message_id": self.sessions.get(custom_session_id, {}).get("parent_message_id")
        }

    def add_to_history(self, custom_session_id: str, role: str, content: str):
        if custom_session_id:
            if custom_session_id not in self.sessions:
                self.sessions[custom_session_id] = {"chat_session_id": None, "parent_message_id": None, "history": []}
            self.sessions[custom_session_id]["history"].append({"role": role, "content": content})

    def get_history(self, custom_session_id: str, depth: int = 0) -> List[Dict]:
        history = self.sessions.get(custom_session_id, {}).get("history", [])
        if depth > 0:
            return history[-depth * 2:]  # Each exchange = 2 messages (user + assistant)
        return history

    def save_ids(self, custom_session_id: str, chat_session_id: Optional[str], parent_message_id: Optional[str]):
        if custom_session_id and chat_session_id and parent_message_id:
            if custom_session_id not in self.sessions:
                self.sessions[custom_session_id] = {"chat_session_id": None, "parent_message_id": None, "history": []}
            self.sessions[custom_session_id]["chat_session_id"] = chat_session_id
            self.sessions[custom_session_id]["parent_message_id"] = parent_message_id

    def export(self, custom_session_id: str) -> Dict[str, Any]:
        """Export the full history and session data for a given thread."""
        return dict(self.sessions.get(custom_session_id, {"history": []}))

    def clear(self, custom_session_id: str):
        if custom_session_id in self.sessions:
            del self.sessions[custom_session_id]


def _extract_youtube_id(url: str) -> Optional[str]:
    """Extract YouTube video ID from any YouTube URL format."""
    patterns = [
        r"(?:v=|youtu\.be/|/v/|/embed/|/shorts/)([0-9A-Za-z_-]{11})",
    ]
    for pattern in patterns:
        match = re.search(pattern, url)
        if match:
            return match.group(1)
    return None


async def _fetch_youtube_transcript_async(video_id: str) -> str:
    """Asynchronously fetch YouTube transcript."""
    loop = asyncio.get_event_loop()
    return await loop.run_in_executor(None, _fetch_youtube_transcript_sync, video_id)


def _fetch_youtube_transcript_sync(video_id: str) -> str:
    """Fetch YouTube transcript synchronously."""
    try:
        from youtube_transcript_api import YouTubeTranscriptApi
        transcript_list = YouTubeTranscriptApi.list_transcripts(video_id)
        try:
            transcript = transcript_list.find_transcript(['ar', 'en'])
        except Exception:
            transcript = next(iter(transcript_list))
        data = transcript.fetch()
        return " ".join([t['text'] for t in data])[:15000]
    except ImportError:
        raise ImportError("youtube_transcript_api is required for youtube support. Run: pip install youtube-transcript-api")
    except Exception as e:
        raise Exception(f"Failed to fetch YouTube transcript: {e}")


class AsyncClient:
    """
    Asynchronous client for interacting with the hAI API.
    
    Features:
    - Auto-memory: Pass session_id and history is managed automatically.
    - Streaming: Use .stream_chat() for real-time typing effect.
    - thinking: Enable chain-of-thought reasoning.
    - search: Enable web search.
    - system: Set a persistent system personality.
    - temperature: Control creativity (0.0=precise, 1.0=creative).
    - max_tokens: Limit response length.
    - json_mode: Force response to be a valid JSON object.
    - translate: Auto-translate responses to any language.
    - code_mode: Put AI into expert programmer mode.
    - verify: Ask AI to double-check its answer before responding.
    - summarize: Append a 3-bullet summary at the end of every response.
    - image: Send an image URL for vision analysis.
    - youtube: Automatically fetch a YouTube video transcript and analyze it.
    - memory_depth: Limit how many past messages the AI remembers.
    - retries: Auto-retry on network failure.
    - on_done: Callback function called when streaming completes.
    """

    def __init__(self, api_key: Optional[str] = None, base_url: str = "https://ai.hussain.ink"):
        self.api_key = api_key or os.getenv("MY_SECRET_API_KEY")
        if not self.api_key:
            raise ValueError("API Key is missing. Pass it directly or set MY_SECRET_API_KEY in .env")
        self.base_url = base_url.rstrip("/")
        self.memory = MemoryStore()

    def _build_payload(
        self,
        prompt: str,
        session_id: Optional[str],
        thinking: bool,
        search: bool,
        chat_session_id: Optional[str],
        parent_message_id: Optional[str],
        system: Optional[str],
        temperature: Optional[float],
        max_tokens: Optional[int],
        json_mode: bool,
        translate: Optional[str],
        code_mode: bool,
        verify: bool,
        summarize: bool,
        include_thought: bool,
        memory_depth: int,
        image: Optional[str],
    ) -> Dict[str, Any]:
        
        # Determine which messages to send for context
        messages: List[Dict] = []
        if session_id and memory_depth != 0:
            messages = self.memory.get_history(session_id, memory_depth)

        # Construct user message content
        if image:
            # Vision: multipart content
            user_content: Any = [
                {"type": "image_url", "image_url": {"url": image}},
                {"type": "text", "text": prompt}
            ]
        else:
            user_content = prompt

        messages.append({"role": "user", "content": user_content})

        payload: Dict[str, Any] = {
            "messages": messages,
            "stream": True,
            "thinking": thinking,
            "search": search,
        }

        # Optional AI mode params
        if system: payload["system"] = system
        if temperature is not None: payload["temperature"] = temperature
        if max_tokens is not None: payload["max_tokens"] = max_tokens
        if json_mode: payload["json_mode"] = True
        if translate: payload["translate"] = translate
        if code_mode: payload["code_mode"] = True
        if verify: payload["verify"] = True
        if summarize: payload["summarize"] = True
        if include_thought: payload["include_thought"] = True

        # Session IDs (raw takes priority over auto-memory)
        if chat_session_id:
            payload["chat_session_id"] = chat_session_id
        elif session_id:
            ids = self.memory.get_ids(session_id)
            if ids["chat_session_id"]: payload["chat_session_id"] = ids["chat_session_id"]
            if ids["parent_message_id"]: payload["parent_message_id"] = ids["parent_message_id"]

        if parent_message_id:
            payload["parent_message_id"] = parent_message_id

        return payload

    async def stream_chat(
        self,
        prompt: str,
        session_id: Optional[str] = None,
        thinking: bool = False,
        search: bool = False,
        chat_session_id: Optional[str] = None,
        parent_message_id: Optional[str] = None,
        system: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        json_mode: bool = False,
        translate: Optional[str] = None,
        code_mode: bool = False,
        verify: bool = False,
        summarize: bool = False,
        include_thought: bool = False,
        image: Optional[str] = None,
        youtube: Optional[str] = None,
        memory_depth: int = 10,
        retries: int = 3,
        on_done: Optional[Callable[["HAIResponse"], None]] = None,
    ) -> AsyncGenerator[HAIResponse, None]:
        """Sends a message and yields response chunks as they arrive (streaming)."""

        # Handle YouTube: fetch transcript and inject into prompt
        actual_prompt = prompt
        if youtube:
            video_id = _extract_youtube_id(youtube)
            if not video_id:
                raise ValueError(f"Could not extract YouTube video ID from URL: {youtube}")
            transcript = await _fetch_youtube_transcript_async(video_id)
            actual_prompt = f"[YOUTUBE VIDEO TRANSCRIPT]:\n{transcript}\n\n[USER REQUEST]:\n{prompt}"

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        payload = self._build_payload(
            actual_prompt, session_id, thinking, search,
            chat_session_id, parent_message_id,
            system, temperature, max_tokens, json_mode,
            translate, code_mode, verify, summarize, include_thought,
            memory_depth, image
        )

        current_response = HAIResponse()
        attempt = 0

        while attempt <= retries:
            try:
                async with httpx.AsyncClient(timeout=120) as client:
                    async with client.stream("POST", f"{self.base_url}/v1/chat/completions", headers=headers, json=payload) as response:
                        if response.status_code != 200:
                            raise Exception(f"hAI API Error: {response.status_code}")

                        async for line in response.aiter_lines():
                            if line.startswith("data: "):
                                data_str = line[6:]
                                if data_str == "[DONE]":
                                    current_response.is_done = True
                                    # Save to memory if session_id provided
                                    if session_id:
                                        self.memory.add_to_history(session_id, "user", actual_prompt)
                                        self.memory.add_to_history(session_id, "assistant", current_response.text)
                                    if on_done:
                                        on_done(current_response)
                                    yield current_response
                                    return

                                try:
                                    data_json = json.loads(data_str)
                                    if "choices" in data_json:
                                        delta = data_json['choices'][0]['delta']
                                        if 'content' in delta and delta['content']:
                                            current_response.text += delta['content']
                                            yield current_response
                                        if 'reasoning_content' in delta and delta['reasoning_content']:
                                            current_response.thinking_text += delta['reasoning_content']
                                            yield current_response
                                    elif data_json.get("object") == "chat.completion.meta":
                                        current_response.parent_message_id = data_json.get("message_id")
                                        current_response.session_id = data_json.get("chat_session_id")
                                        current_response.latency_ms = data_json.get("latency_ms")
                                        if session_id:
                                            self.memory.save_ids(session_id, current_response.session_id, current_response.parent_message_id)
                                except json.JSONDecodeError:
                                    continue
                break  # Success, exit retry loop
            except Exception as e:
                attempt += 1
                if attempt > retries:
                    raise Exception(f"hAI failed after {retries} retries. Last error: {e}")
                await asyncio.sleep(2 ** attempt)  # Exponential backoff

    async def chat(
        self,
        prompt: str,
        session_id: Optional[str] = None,
        thinking: bool = False,
        search: bool = False,
        chat_session_id: Optional[str] = None,
        parent_message_id: Optional[str] = None,
        system: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        json_mode: bool = False,
        translate: Optional[str] = None,
        code_mode: bool = False,
        verify: bool = False,
        summarize: bool = False,
        include_thought: bool = False,
        image: Optional[str] = None,
        youtube: Optional[str] = None,
        memory_depth: int = 10,
        retries: int = 3,
        on_done: Optional[Callable[["HAIResponse"], None]] = None,
    ) -> HAIResponse:
        """Sends a message and returns the complete response (blocking)."""
        final_response = None
        async for chunk in self.stream_chat(
            prompt=prompt, session_id=session_id, thinking=thinking, search=search,
            chat_session_id=chat_session_id, parent_message_id=parent_message_id,
            system=system, temperature=temperature, max_tokens=max_tokens,
            json_mode=json_mode, translate=translate, code_mode=code_mode,
            verify=verify, summarize=summarize, include_thought=include_thought, image=image, youtube=youtube,
            memory_depth=memory_depth, retries=retries, on_done=on_done
        ):
            final_response = chunk
        if final_response is None:
            raise Exception("hAI API returned an empty response.")
        return final_response

    def export_history(self, session_id: str) -> Dict[str, Any]:
        """Export the full conversation history for a given session_id."""
        return self.memory.export(session_id)

    def clear_history(self, session_id: str):
        """Clear the conversation memory for a given session_id."""
        self.memory.clear(session_id)


class Client:
    """
    Synchronous client for interacting with the hAI API.
    Supports all the same features as AsyncClient but in a blocking fashion.
    Ideal for simple scripts, Flask apps, or WhatsApp bots.
    """

    def __init__(self, api_key: Optional[str] = None, base_url: str = "https://ai.hussain.ink"):
        self.api_key = api_key or os.getenv("MY_SECRET_API_KEY")
        if not self.api_key:
            raise ValueError("API Key is missing. Pass it directly or set MY_SECRET_API_KEY in .env")
        self.base_url = base_url.rstrip("/")
        self.memory = MemoryStore()

    def _build_payload(
        self,
        prompt: str,
        session_id: Optional[str],
        thinking: bool,
        search: bool,
        chat_session_id: Optional[str],
        parent_message_id: Optional[str],
        system: Optional[str],
        temperature: Optional[float],
        max_tokens: Optional[int],
        json_mode: bool,
        translate: Optional[str],
        code_mode: bool,
        verify: bool,
        summarize: bool,
        include_thought: bool,
        memory_depth: int,
        image: Optional[str],
        model: Optional[str] = None
    ) -> Dict[str, Any]:
        messages: List[Dict] = []
        if session_id and memory_depth != 0:
            messages = self.memory.get_history(session_id, memory_depth)

        if image:
            user_content: Any = [
                {"type": "image_url", "image_url": {"url": image}},
                {"type": "text", "text": prompt}
            ]
        else:
            user_content = prompt

        messages.append({"role": "user", "content": user_content})

        payload: Dict[str, Any] = {
            "messages": messages,
            "stream": True,
            "thinking": thinking,
            "search": search,
        }

        if system: payload["system"] = system
        if temperature is not None: payload["temperature"] = temperature
        if max_tokens is not None: payload["max_tokens"] = max_tokens
        if json_mode: payload["json_mode"] = True
        if translate: payload["translate"] = translate
        if code_mode: payload["code_mode"] = True
        if verify: payload["verify"] = True
        if summarize: payload["summarize"] = True
        if include_thought: payload["include_thought"] = True
        if model: payload["model"] = model

        if chat_session_id:
            payload["chat_session_id"] = chat_session_id
        elif session_id:
            ids = self.memory.get_ids(session_id)
            if ids["chat_session_id"]: payload["chat_session_id"] = ids["chat_session_id"]
            if ids["parent_message_id"]: payload["parent_message_id"] = ids["parent_message_id"]

        if parent_message_id:
            payload["parent_message_id"] = parent_message_id

        return payload

    def stream_chat(
        self,
        prompt: str,
        session_id: Optional[str] = None,
        thinking: bool = False,
        search: bool = False,
        chat_session_id: Optional[str] = None,
        parent_message_id: Optional[str] = None,
        system: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        json_mode: bool = False,
        translate: Optional[str] = None,
        code_mode: bool = False,
        verify: bool = False,
        summarize: bool = False,
        include_thought: bool = False,
        image: Optional[str] = None,
        youtube: Optional[str] = None,
        memory_depth: int = 10,
        retries: int = 3,
        on_done: Optional[Callable[["HAIResponse"], None]] = None,
        model: Optional[str] = None,
    ) -> Generator[HAIResponse, None, None]:
        """Sends a message and yields response chunks as they arrive (streaming, synchronous)."""

        actual_prompt = prompt
        if youtube:
            video_id = _extract_youtube_id(youtube)
            if not video_id:
                raise ValueError(f"Could not extract YouTube video ID from URL: {youtube}")
            transcript = _fetch_youtube_transcript_sync(video_id)
            actual_prompt = f"[YOUTUBE VIDEO TRANSCRIPT]:\n{transcript}\n\n[USER REQUEST]:\n{prompt}"

        headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
        payload = self._build_payload(
            actual_prompt, session_id, thinking, search,
            chat_session_id, parent_message_id,
            system, temperature, max_tokens, json_mode,
            translate, code_mode, verify, summarize, include_thought,
            memory_depth, image, model
        )

        current_response = HAIResponse()
        attempt = 0

        while attempt <= retries:
            try:
                with httpx.Client(timeout=120) as client:
                    with client.stream("POST", f"{self.base_url}/v1/chat/completions", headers=headers, json=payload) as response:
                        if response.status_code != 200:
                            raise Exception(f"hAI API Error: {response.status_code}")

                        for line in response.iter_lines():
                            if line.startswith("data: "):
                                data_str = line[6:]
                                if data_str == "[DONE]":
                                    current_response.is_done = True
                                    if session_id:
                                        self.memory.add_to_history(session_id, "user", actual_prompt)
                                        self.memory.add_to_history(session_id, "assistant", current_response.text)
                                    if on_done:
                                        on_done(current_response)
                                    yield current_response
                                    return

                                try:
                                    data_json = json.loads(data_str)
                                    if "choices" in data_json:
                                        delta = data_json['choices'][0]['delta']
                                        if 'content' in delta and delta['content']:
                                            current_response.text += delta['content']
                                            yield current_response
                                        if 'reasoning_content' in delta and delta['reasoning_content']:
                                            current_response.thinking_text += delta['reasoning_content']
                                            yield current_response
                                        if 'search_content' in delta and delta['search_content']:
                                            current_response.search_text += delta['search_content']
                                            yield current_response
                                        if 'image_url' in delta and delta['image_url']:
                                            current_response.image_urls.append(delta['image_url'])
                                            yield current_response
                                    elif data_json.get("object") == "chat.completion.meta":
                                        current_response.parent_message_id = data_json.get("message_id")
                                        current_response.session_id = data_json.get("chat_session_id")
                                        current_response.latency_ms = data_json.get("latency_ms")
                                        if session_id:
                                            self.memory.save_ids(session_id, current_response.session_id, current_response.parent_message_id)
                                except json.JSONDecodeError:
                                    continue
                break
            except Exception as e:
                attempt += 1
                if attempt > retries:
                    raise Exception(f"hAI failed after {retries} retries. Last error: {e}")
                time.sleep(2 ** attempt)

    def chat(
        self,
        prompt: str,
        session_id: Optional[str] = None,
        thinking: bool = False,
        search: bool = False,
        chat_session_id: Optional[str] = None,
        parent_message_id: Optional[str] = None,
        system: Optional[str] = None,
        temperature: Optional[float] = None,
        max_tokens: Optional[int] = None,
        json_mode: bool = False,
        translate: Optional[str] = None,
        code_mode: bool = False,
        verify: bool = False,
        summarize: bool = False,
        include_thought: bool = False,
        image: Optional[str] = None,
        youtube: Optional[str] = None,
        memory_depth: int = 10,
        retries: int = 3,
        on_done: Optional[Callable[["HAIResponse"], None]] = None,
        model: Optional[str] = None,
    ) -> HAIResponse:
        """Sends a message and returns the complete response (blocking)."""
        final_response = None
        for chunk in self.stream_chat(
            prompt=prompt, session_id=session_id, thinking=thinking, search=search,
            chat_session_id=chat_session_id, parent_message_id=parent_message_id,
            system=system, temperature=temperature, max_tokens=max_tokens,
            json_mode=json_mode, translate=translate, code_mode=code_mode,
            verify=verify, summarize=summarize, include_thought=include_thought, image=image, youtube=youtube,
            memory_depth=memory_depth, retries=retries, on_done=on_done, model=model
        ):
            final_response = chunk
        if final_response is None:
            raise Exception("hAI API returned an empty response.")
        return final_response

    def export_history(self, session_id: str) -> Dict[str, Any]:
        """Export the full conversation history for a given session_id."""
        return self.memory.export(session_id)

    def clear_history(self, session_id: str):
        """Clear the conversation memory for a given session_id."""
        self.memory.clear(session_id)
