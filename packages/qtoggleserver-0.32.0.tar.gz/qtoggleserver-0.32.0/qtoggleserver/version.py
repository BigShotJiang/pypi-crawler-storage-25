VERSION = "0.32.0"
VENDOR = "qtoggle/qtoggleserver"
