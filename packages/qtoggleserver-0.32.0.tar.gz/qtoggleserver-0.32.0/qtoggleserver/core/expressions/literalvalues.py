import re

from qtoggleserver.core.typing import NullablePortValue

from .base import EvalContext, EvalResult, Expression, Role
from .exceptions import EmptyExpression, UnexpectedCharacter, ValueUnavailable


class LiteralValue(Expression):
    def __init__(self, value: NullablePortValue, sexpression: str, role: Role) -> None:
        super().__init__(role)

        self.sexpression: str = sexpression
        self._coerced_value: EvalResult | None = value
        if isinstance(value, bool):
            self._coerced_value = int(value)

    def __str__(self) -> str:
        return self.sexpression

    async def _eval(self, context: EvalContext) -> EvalResult:
        if self._coerced_value is None:
            raise ValueUnavailable
        return self._coerced_value

    @staticmethod
    def parse(self_port_id: str | None, sexpression: str, role: Role, pos: int) -> Expression:
        stripped = sexpression.lstrip()
        pos += len(sexpression) - len(stripped)
        sexpression = stripped.rstrip()

        if not sexpression:
            raise EmptyExpression()

        value: EvalResult | None

        if sexpression == "true":
            value = 1
        elif sexpression == "false":
            value = 0
        elif sexpression == "unavailable":
            value = None
        else:
            try:
                value = int(sexpression)
            except ValueError:
                try:
                    value = float(sexpression)
                except ValueError:
                    m = re.match(r"-?\d+(\.?\d+)?", sexpression)
                    if m:
                        raise UnexpectedCharacter(sexpression[m.end()], pos + m.end()) from None
                    else:
                        raise UnexpectedCharacter(sexpression[0], pos) from None

        return LiteralValue(value, sexpression, role)
