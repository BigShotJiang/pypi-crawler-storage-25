"""Built-in ``recall_atom`` tool — Layer-2 retrieval over the markdown
atom corpus (K-F.1).

The **atom corpus** is the user's curated knowledge stored under the
Claude project memory directory (e.g.
``~/.claude/projects/<hash>/memory/``). Each file is one fact — see
:mod:`master_agents_client.atoms` for the file shape.

This tool is the "recall" piece of the 3-layer memory model
(skim → recall → refer). Agents call ``recall_atom(query=..., themes=...)``
when they need to find which atoms are relevant to the current question.

Naming — ``recall_atom`` is deliberately distinct from the KV memory
tools (``memory_set`` / ``memory_get`` / ``memory_list`` /
``memory_delete``) which are a SQLite/Postgres-backed key-value store
for state. Atoms are markdown-file-backed for content recall. Two
corpora, two purposes, disambiguated names so agent prompts don't
conflate them.

Routing — registered in
:data:`master_agents_client.remote_client.DEFAULT_CLIENT_SIDE_TOOLS` so the
RemoteClientBridge routes the call to the user's machine where the
corpus actually lives. The container has no view of the user's
``~/.claude/projects`` tree.

Pattern — mirrors :func:`master_agents_client.tools.corpus_search.make_corpus_search_tool`:
factory builds a per-session Tool bound to a fixed corpus directory.
A BUILTIN variant resolves the directory from
``MASTER_AGENTS_ATOM_CORPUS_DIR`` at call-time so it can ship without
per-spec configuration.
"""
from __future__ import annotations

import os
import shutil
from pathlib import Path

from ..atoms import (
    discover_atom_files,
    extract_keywords,
    list_atom_themes,
)
from .base import Tool


# Default budgets — same shape as corpus_search but tuned for the
# atom corpus, which is smaller (~29 files, ~3 KB each) than typical
# knowledge bases. Per-atom hit cap is more generous (whole-file is
# only ~80 lines max), total cap is tighter (atoms are dense so 15K
# chars fits the typical "5 atoms with context" injection).
DEFAULT_RECALL_LIMIT = 5
DEFAULT_MAX_TOTAL_CHARS = 15_000
DEFAULT_MAX_MATCHES_PER_KEYWORD = 12

_ATOM_CORPUS_ENV = "MASTER_AGENTS_ATOM_CORPUS_DIR"


def _normalise_themes(raw: list[str] | str | None) -> list[str]:
    """Tolerate either a list (canonical) or a scalar string (the LLM
    sometimes forgets the wrapping ``[ ]``). Empty / whitespace-only
    entries are dropped — they would match every theme bucket if not
    filtered.
    """
    if raw is None:
        return []
    if isinstance(raw, str):
        return [raw.strip()] if raw.strip() else []
    return [t.strip() for t in raw if isinstance(t, str) and t.strip()]


def _resolve_themes_to_files(
    corpus_dir: Path, themes: list[str],
) -> tuple[list[Path], list[str]]:
    """Map a list of themes → the union of atom files tagged with any
    of them. Returns ``(file_list, unknown_themes)``. An "unknown
    theme" is one with no matching atoms — surfaced to the caller so
    the error message can be actionable.
    """
    if not themes:
        # No theme filter — search everything.
        return discover_atom_files(corpus_dir), []
    index = list_atom_themes(corpus_dir)
    unknown: list[str] = []
    files: dict[Path, None] = {}  # dict for de-dup with insertion order
    for theme in themes:
        bucket = index.get(theme)
        if not bucket:
            unknown.append(theme)
            continue
        for path in bucket:
            files[path] = None
    return list(files), unknown


async def _recall_atom_handler(
    *,
    corpus_dir: Path,
    query: str,
    themes: list[str] | str | None = None,
    limit: int = DEFAULT_RECALL_LIMIT,
) -> str:
    """Run the actual recall: theme-filter the corpus, grep the query,
    return formatted matches. All wrappers in this module funnel here.
    """
    # ---- input validation -------------------------------------------------
    if not isinstance(query, str) or not query.strip():
        return "recall_atom: `query` must be a non-empty string"
    if not corpus_dir.exists() or not corpus_dir.is_dir():
        return (
            f"recall_atom: no atom corpus found at {corpus_dir}. Set "
            f"${_ATOM_CORPUS_ENV} on the client OR pass an explicit "
            "corpus_dir when constructing the tool."
        )

    theme_list = _normalise_themes(themes)
    files, unknown = _resolve_themes_to_files(corpus_dir, theme_list)
    if theme_list and not files:
        # Caller asked for specific themes and we found zero matching
        # files — say so explicitly rather than returning a generic
        # "no match" that hides the theme/typo problem.
        return (
            f"recall_atom: no atom file matches theme(s) {unknown!r}. "
            f"Available themes: {sorted(list_atom_themes(corpus_dir))}"
        )
    if not files:
        return "recall_atom: corpus is empty (no atom files found)"

    # ---- retrieval --------------------------------------------------------
    # Heuristic keyword extraction from the query. Mirrors corpus_search's
    # tolerance: the agent can either pass a phrase ("byte-stable cache")
    # or a question ("what's the byte-stability rule?"); both extract
    # to the same content-bearing terms.
    keywords = extract_keywords(query)
    if not keywords:
        return (
            f"recall_atom: query {query!r} contained no content-bearing "
            "terms after stopword filtering. Try a more specific query."
        )

    # Pure-Python search over the (already small) atom corpus. We
    # intentionally skip the ripgrep path used by corpus_search —
    # ripgrep isn't installed on every dev machine, the atom corpus is
    # tiny (< 100 files × ~3 KB), and the speed gap is irrelevant.
    # Production parity: corpus_search uses ripgrep for big KB
    # retrieval, recall_atom uses Python for small-corpus recall.
    block = _python_grep_atoms(
        files=files,
        keywords=keywords,
        corpus_root=corpus_dir,
        max_matches_per_keyword=DEFAULT_MAX_MATCHES_PER_KEYWORD,
        max_total_chars=DEFAULT_MAX_TOTAL_CHARS,
    )
    if not block:
        scope = (
            f"themes {theme_list!r}" if theme_list
            else f"{len(files)} atom file(s)"
        )
        return (
            f"recall_atom: NO MATCHES for query {query!r} across {scope}. "
            "Try a broader query or different theme."
        )

    # Apply soft per-call limit — the heavy lifting was already done
    # inside retrieve_with_keywords; here we just slice to a friendly
    # K hits. We do this at the line level (post-format) so the
    # markdown structure stays intact.
    if limit is not None and isinstance(limit, int) and limit > 0:
        block = _apply_limit(block, limit)

    return block


def _python_grep_atoms(
    *,
    files: list[Path],
    keywords: list[str],
    corpus_root: Path,
    max_matches_per_keyword: int,
    max_total_chars: int,
) -> str:
    """Pure-Python case-insensitive substring grep over a small file
    set. Output mirrors corpus_search's ``<rel>:<line>: <content>``
    format so downstream agents can use the same citation conventions
    for either tool.

    Why pure Python instead of ripgrep:
    - Atom corpus is intentionally small (< 100 files × ~3 KB) so
      no perf gain from rg.
    - Dev machines may not have rg installed; production does, but
      this path is exercised in tests and on first install.
    - Deterministic output ordering (sorted by file, then line) —
      important for byte-stability of any caller that captures the
      block (e.g. K-F.3 session-start injection).
    """
    keyword_lcs = [k.lower() for k in keywords if k]
    if not keyword_lcs:
        return ""

    grouped: dict[Path, list[tuple[int, str]]] = {}
    per_keyword_hits: dict[str, int] = {kw: 0 for kw in keyword_lcs}
    total_chars = 0
    truncated = False

    # Sort files deterministically; the caller already returns sorted
    # paths but we re-sort to be defensive against future ordering
    # changes in upstream helpers.
    for path in sorted(files):
        try:
            lines = path.read_text(encoding="utf-8").splitlines()
        except (OSError, UnicodeDecodeError):
            continue
        hits_for_file: list[tuple[int, str]] = []
        seen_linenos: set[int] = set()
        for kw in keyword_lcs:
            if per_keyword_hits[kw] >= max_matches_per_keyword:
                continue
            for lineno, line in enumerate(lines, start=1):
                if kw not in line.lower():
                    continue
                if lineno in seen_linenos:
                    continue
                seen_linenos.add(lineno)
                hits_for_file.append((lineno, line))
                per_keyword_hits[kw] += 1
                if per_keyword_hits[kw] >= max_matches_per_keyword:
                    break
        if hits_for_file:
            hits_for_file.sort(key=lambda lt: lt[0])
            grouped[path] = hits_for_file

    if not grouped:
        return ""

    # Format as a corpus_search-compatible block so callers can use
    # the same citation parser for both tools' output.
    keywords_label = ", ".join(keywords)
    hit_count = sum(len(v) for v in grouped.values())
    sections: list[str] = [
        "## Retrieved context (atom corpus)",
        f"_Searched: {keywords_label} — across {len(grouped)} atom(s); "
        f"{hit_count} match(es)._",
        "_Each line below is `<atom-path>:<line>: <content>`. Cite the "
        "anchor verbatim when referencing._",
    ]
    for path, hits in grouped.items():
        try:
            rel = path.relative_to(corpus_root)
        except ValueError:
            rel = path
        sections.append("```")
        for lineno, line in hits:
            entry = f"{rel}:{lineno}: {line}"
            if total_chars + len(entry) + 1 > max_total_chars:
                truncated = True
                break
            sections.append(entry)
            total_chars += len(entry) + 1
        sections.append("```")
        if truncated:
            break

    if truncated:
        sections.append(f"\n_…retrieval truncated at {max_total_chars} chars._")
    return "\n".join(sections)


def _apply_limit(block: str, limit: int) -> str:
    """Trim a grep block to at most ``limit`` hit lines.

    Strategy: walk the block tracking fenced regions. Inside a fence,
    accept hit lines up to the global limit; reject the rest. Then
    elide any fenced block that ended up empty (open immediately
    followed by close), which is the cosmetic regression UAT D-1
    surfaced — without this, atoms beyond the limit left visible
    empty ``` ``` pairs in the output.

    Headers, prose, and truncation markers (anything outside fences)
    pass through unchanged.
    """
    hit_count = 0
    out_lines: list[str] = []
    inside_fence = False
    for line in block.splitlines():
        is_fence = line.strip() == "```"
        if is_fence:
            inside_fence = not inside_fence
            out_lines.append(line)
            continue
        if inside_fence and line.strip():
            if hit_count >= limit:
                continue
            hit_count += 1
        out_lines.append(line)
    # Second pass: drop ``` ``` pairs (open immediately followed by
    # close — possibly with blank lines between, but no content).
    pruned: list[str] = []
    i = 0
    while i < len(out_lines):
        line = out_lines[i]
        if line.strip() == "```":
            # Look ahead for the matching close fence.
            j = i + 1
            has_content = False
            while j < len(out_lines):
                if out_lines[j].strip() == "```":
                    break
                if out_lines[j].strip():
                    has_content = True
                j += 1
            if not has_content and j < len(out_lines):
                # Empty pair — skip both fences.
                i = j + 1
                continue
        pruned.append(line)
        i += 1
    return "\n".join(pruned)


# --- factory + BUILTIN -----------------------------------------------------


_DESCRIPTION = (
    "Recall user-curated knowledge atoms (project memory) by query, "
    "optionally filtered to specific themes. Atoms are markdown files "
    "with `themes: [...]` frontmatter that live on the USER'S machine "
    "(~/.claude/projects/<hash>/memory/). DIFFERENT from `memory_get` "
    "/ `memory_set` (which is a SQLite key-value store for state). "
    "Use this when you want to retrieve a fact, pattern, or feedback "
    "the user has saved.\n"
    "\n"
    "USAGE:\n"
    "  recall_atom(query='cache-friendly design rule', themes=['cache-friendliness'])\n"
    "  recall_atom(query='git discipline')   # no theme filter\n"
    "\n"
    "Themes are user-controlled vocabulary (currently roughly matches "
    "MEMORY.md H2 section names: `cost-discipline`, `architecture`, "
    "`agent-discipline`, `mao-supervision`, `memory`, `rag`, "
    "`git-discipline`, `versioning`, `production-infrastructure`, "
    "`project-context`, etc.). If your theme returns no matches the "
    "tool will list the available themes for you."
)

_INPUT_SCHEMA: dict = {
    "type": "object",
    "required": ["query"],
    "properties": {
        "query": {
            "type": "string",
            "description": (
                "Free-text query. Content-bearing terms are extracted "
                "heuristically; pass a phrase or a question, both work."
            ),
        },
        "themes": {
            "type": ["array", "string", "null"],
            "items": {"type": "string"},
            "description": (
                "Optional list of theme slugs to pre-filter the corpus. "
                "If omitted, searches all atoms. Unknown themes surface "
                "an actionable error listing the available themes."
            ),
        },
        "limit": {
            "type": "integer",
            "minimum": 1,
            "maximum": 50,
            "description": (
                "Max number of hit lines to return (default 5). The "
                "char-budget caps still apply."
            ),
        },
    },
}


def make_recall_atom_tool(
    corpus_dir: Path | str,
    *,
    max_total_chars: int = DEFAULT_MAX_TOTAL_CHARS,
) -> Tool:
    """Factory: bind ``corpus_dir`` into a Tool. Used by Session when
    a spec declares a custom atom corpus (e.g. per-specialist corpora)
    OR by tests that want a deterministic dir without env-var setup.

    ``max_total_chars`` is honoured by tightening the per-call budget
    (passed through to ``retrieve_with_keywords``). The factory only
    surfaces this knob because per-spec tuning may want it; the
    BUILTIN uses the module default.
    """
    bound_dir = Path(corpus_dir)

    async def handler(
        query: str,
        themes: list[str] | str | None = None,
        limit: int = DEFAULT_RECALL_LIMIT,
    ) -> str:
        return await _recall_atom_handler(
            corpus_dir=bound_dir,
            query=query,
            themes=themes,
            limit=limit,
        )

    return Tool(
        name="recall_atom",
        description=_DESCRIPTION,
        input_schema=_INPUT_SCHEMA,
        handler=handler,
        requires_approval=False,
        abortable=False,
    )


async def _builtin_handler(
    query: str,
    themes: list[str] | str | None = None,
    limit: int = DEFAULT_RECALL_LIMIT,
) -> str:
    """BUILTIN handler — resolves corpus_dir from ``MASTER_AGENTS_ATOM_CORPUS_DIR``
    at call time. Reads the env var EACH call so a long-lived process
    (server, test runner) can be reconfigured without restart.
    """
    raw = os.environ.get(_ATOM_CORPUS_ENV)
    if not raw:
        return (
            f"recall_atom: not configured. Set ${_ATOM_CORPUS_ENV} on the "
            "client to the path of your atom corpus (typically "
            "~/.claude/projects/<hash>/memory/)."
        )
    return await _recall_atom_handler(
        corpus_dir=Path(raw).expanduser(),
        query=query,
        themes=themes,
        limit=limit,
    )


# Module-level BUILTIN instance — imported by tools/__init__.py and
# registered in the BUILTINS dict. Uses _builtin_handler so the corpus
# path resolves dynamically; per-spec overrides go through the
# make_recall_atom_tool factory in session._build_tools instead.
recall_atom = Tool(
    name="recall_atom",
    description=_DESCRIPTION,
    input_schema=_INPUT_SCHEMA,
    handler=_builtin_handler,
    requires_approval=False,
    abortable=False,
)
