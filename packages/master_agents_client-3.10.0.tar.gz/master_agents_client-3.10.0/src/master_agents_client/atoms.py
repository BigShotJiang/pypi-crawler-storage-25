"""Atom corpus — markdown-file knowledge with frontmatter parsing (K-F.2).

The **atom corpus** is the user's curated markdown knowledge stored under
the Claude project memory directory (e.g.
`~/.claude/projects/<hash>/memory/`). Each file is one fact — frontmatter
YAML followed by a markdown body:

    ---
    name: <slug>
    description: <one-line summary>
    themes: [theme-1, theme-2]      # K-F.2 — for theme-based recall
    metadata:
      type: feedback | project | reference | user
      ...
    ---

    <body markdown>

This module is the read-only parser layer. It is consumed by both:

- ``recall_atom`` tool (K-F.1) — grep across the corpus with optional
  theme pre-filter.
- ``relevant_memory_themes`` session-start injection (K-F.3) — pull a
  fixed set of atom bodies into the system prompt, byte-stably.

NAMING — "atom" is deliberately distinct from the KV "memory"
subsystem (``memory_set`` / ``memory_get`` / ``memory_list`` /
``memory_delete``) which is SQLite/Postgres-backed for state. Atoms
are markdown-file-backed for recall. Two corpora, two purposes,
disambiguated names so agent prompts don't conflate them.

BYTE-STABILITY — every public helper here returns results that are
deterministic given the corpus state on disk. Sorted by filename;
themes sorted alphabetically. This is the contract K-F.3 leans on
for cache-friendly session-start injection (see ROADMAP.md § K-F.3
"Byte-stable per spec (cache-friendly)").
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import yaml


# ---- query-side keyword extraction (used by recall_atom + retrieval) ----
# Originally lived in the service; relocated here so the same primitive
# can serve BOTH the server's retrieval pipeline and the client wheel's
# `recall_atom` tool without dragging the service (which has ripgrep
# subprocess deps) into the client. Pure stdlib — no upward imports.

DEFAULT_MAX_KEYWORDS = 8
DEFAULT_MIN_KEYWORD_LEN = 3

# Stopwords tuned for free-text questions in this project. Aggressive
# but reasonable: drops articles, conjunctions, common verbs that match
# everything and dilute relevance signal.
_STOPWORDS = frozenset({
    "the", "a", "an", "and", "or", "but", "if", "of", "to", "for", "in",
    "on", "at", "by", "with", "from", "is", "are", "was", "were", "be",
    "been", "being", "have", "has", "had", "do", "does", "did", "will",
    "would", "could", "should", "may", "might", "must", "can", "this",
    "that", "these", "those", "i", "you", "we", "they", "it", "he",
    "she", "my", "your", "our", "their", "what", "when", "where", "why",
    "how", "which", "who", "whom", "as", "than", "then", "so", "such",
    "into", "out", "up", "down", "over", "under", "no", "not", "only",
    "all", "any", "some", "more", "most", "other", "another", "each",
    "every", "few", "many", "much", "very", "just", "also", "etc",
    "me", "us", "them", "him", "her", "his", "hers", "its",
})

_TOKEN_RE = re.compile(r"[A-Za-z][A-Za-z0-9_.-]*")


def extract_keywords(
    question: str,
    *,
    max_keywords: int = DEFAULT_MAX_KEYWORDS,
    min_len: int = DEFAULT_MIN_KEYWORD_LEN,
) -> list[str]:
    """Pull distinctive search terms out of a free-text question.

    Strategy: tokenise, lowercase, drop stopwords + tokens shorter
    than ``min_len``, dedupe preserving first-seen order, keep at most
    ``max_keywords``. Quoted phrases (in double quotes) are kept as
    multi-word phrases at the front of the list.

    Side-effect free; pure stdlib. Safe to call from both server and
    client code paths.
    """
    keywords: list[str] = []
    seen: set[str] = set()

    # Pull quoted phrases first — those signal user intent and the
    # whole phrase should be a single search term.
    for match in re.finditer(r'"([^"]{3,80})"', question):
        phrase = match.group(1).strip()
        if phrase and phrase.lower() not in seen:
            keywords.append(phrase)
            seen.add(phrase.lower())

    # Then individual tokens.
    stripped = re.sub(r'"[^"]*"', " ", question)
    for token in _TOKEN_RE.findall(stripped):
        norm = token.lower()
        if norm in seen:
            continue
        if norm in _STOPWORDS:
            continue
        if len(norm) < min_len:
            continue
        keywords.append(token)
        seen.add(norm)
        if len(keywords) >= max_keywords:
            break
    return keywords


@dataclass(frozen=True)
class Atom:
    """One parsed memory atom — frontmatter + body, indexed by path.

    Fields are normalised to safe defaults when the source file lacks
    frontmatter or carries malformed YAML — the parser never raises on
    content shape, so a bad atom degrades to a stub atom (themes=()
    name=None) rather than breaking the index build.

    ``metadata`` is a plain dict (not frozen) — the dataclass is
    ``frozen=True`` for callers who want immutability discipline, but
    we don't implement ``__hash__`` (dict fields aren't hashable). The
    natural dedup key is ``atom.path``; callers build
    ``{atom.path: atom}`` rather than relying on hashing.
    """
    path: Path
    name: str | None
    description: str | None
    themes: tuple[str, ...]
    body: str
    metadata: dict[str, Any] = field(default_factory=dict)


def parse_atom(path: Path) -> Atom:
    """Read ``path`` and return its parsed Atom.

    Raises ``FileNotFoundError`` / ``OSError`` if the file isn't
    readable — those are real I/O errors callers should see. Content-
    shape problems (missing frontmatter, malformed YAML, themes given
    as a scalar instead of a list) DEGRADE GRACEFULLY to a stub atom
    so one bad file can't break a corpus-wide index build.
    """
    text = path.read_text(encoding="utf-8")
    frontmatter, body = _split_frontmatter(text)
    if frontmatter is None:
        return Atom(
            path=path, name=None, description=None,
            themes=(), body=text, metadata={},
        )
    try:
        data = yaml.safe_load(frontmatter)
    except yaml.YAMLError:
        return Atom(
            path=path, name=None, description=None,
            themes=(), body=body, metadata={},
        )
    if not isinstance(data, dict):
        # YAML can parse to None / list / scalar — treat anything that
        # isn't a mapping as "no usable frontmatter".
        return Atom(
            path=path, name=None, description=None,
            themes=(), body=body, metadata={},
        )

    return Atom(
        path=path,
        name=_str_or_none(data.get("name")),
        description=_str_or_none(data.get("description")),
        themes=_normalise_themes(data.get("themes")),
        body=body,
        metadata=data.get("metadata") if isinstance(data.get("metadata"), dict) else {},
    )


def discover_atom_files(corpus_dir: Path) -> list[Path]:
    """Return sorted list of atom files in ``corpus_dir`` (non-recursive).

    Excludes:
    - ``MEMORY.md`` — the Layer-1 index, not itself an atom.
    - ``_*.md`` — proposed-but-not-curated atoms (mirrors the
      ``_proposed/`` convention from K-A.1).
    - Anything that isn't a ``.md`` file.

    Returns ``[]`` (not an error) if the directory is missing or
    isn't a directory — callers want to compose this on optional
    paths without try/except chains.
    """
    if not corpus_dir.exists() or not corpus_dir.is_dir():
        return []
    out: list[Path] = []
    for p in sorted(corpus_dir.iterdir()):
        if not p.is_file():
            continue
        if p.suffix != ".md":
            continue
        if p.name == "MEMORY.md":
            continue
        if p.name.startswith("_"):
            continue
        out.append(p)
    return out


def list_atom_themes(corpus_dir: Path) -> dict[str, list[Path]]:
    """Build a ``{theme: [path, ...]}`` mapping from a corpus directory.

    Reads frontmatter of every atom file, groups paths by declared
    themes. Atoms with no themes are NOT included — they're un-routable
    today; K-F.4's intent classifier could later score by ``description``
    instead.

    Result is byte-stable across calls for a given corpus state:
    theme keys are sorted alphabetically, paths within each bucket
    are sorted by filename. This is the contract K-F.3's cache-
    friendly session-start injection depends on.
    """
    themes: dict[str, list[Path]] = {}
    for path in discover_atom_files(corpus_dir):
        try:
            atom = parse_atom(path)
        except OSError:
            # Unreadable file — skip rather than break the index.
            continue
        for theme in atom.themes:
            themes.setdefault(theme, []).append(path)
    # Sort each bucket + the keys for byte-stability.
    return {k: sorted(themes[k]) for k in sorted(themes)}


# --- internals --------------------------------------------------------------


def _str_or_none(v: Any) -> str | None:
    return None if v is None else str(v)


def _normalise_themes(raw: Any) -> tuple[str, ...]:
    """Coerce frontmatter ``themes:`` into a tuple of non-empty strings.

    YAML lets users write ``themes: solo`` (scalar) or ``themes: [a, b]``
    (list). Both forms normalise to a tuple here so callers always see
    one shape. Empty strings and ``None`` entries are dropped.
    """
    if raw is None:
        return ()
    if isinstance(raw, str):
        return (raw,) if raw else ()
    if isinstance(raw, list):
        out: list[str] = []
        for item in raw:
            if item is None:
                continue
            s = str(item)
            if s:
                out.append(s)
        return tuple(out)
    return ()


def _split_frontmatter(text: str) -> tuple[str | None, str]:
    """Split a markdown file into ``(frontmatter_yaml, body)``.

    Returns ``(None, full_text)`` if frontmatter delimiters are absent
    — that's the "this isn't an atom" signal callers want.

    Tolerates CRLF line endings (real memory files written on Windows)
    AND a closing ``---`` at EOF without a trailing newline (uncommon
    but legal). The opening ``---`` must be the very first 3 chars of
    the file; anything earlier (e.g. UTF-8 BOM, leading blank line)
    means "no frontmatter" — keeps the rule simple.
    """
    if not text.startswith("---"):
        return None, text
    # Locate the newline that ends the opening `---` line.
    nl_after_open = text.find("\n", 3)
    if nl_after_open == -1:
        return None, text
    rest = text[nl_after_open + 1:]
    # The closing line is a line that is exactly `---`. Try each
    # variant so we don't depend on the file's line-ending convention.
    for marker in ("\n---\r\n", "\n---\n", "\n---"):
        idx = rest.find(marker)
        if idx == -1:
            continue
        frontmatter = rest[:idx]
        body_start = idx + len(marker)
        return frontmatter, rest[body_start:]
    return None, text
