"""E48 — CLAUDE.md auto-walk at session start (2026-05-14).

Walks the user's filesystem from ``cwd`` toward a sensible boundary
(``$HOME``, repo-root via ``.git`` marker, or hard ``max_depth``),
collects every ``CLAUDE.md`` found, and renders them as a single
``<project_context>`` block that the server injects into the agent's
system prompt at session start.

Why client-side: per E45 (2026-05-13), tools that touch user files
run on the user's machine, not in the container. The container is
filesystem-blind for user content. Same architecture pattern as
recall_atom (K-F.1).

Why byte-stable per session: the rendered block is computed once at
``RemoteSessionClient.open()`` and shipped to the server in the
session-create payload. Server stashes it on the session and the
Runner injects the same bytes on every step. DeepSeek + Anthropic
prefix caches stay warm. Same cache-friendly contract as the
``<retrieved_atoms>`` block (K-F.3) and the ``<memory>`` block.

Cost-gating per ``docs/policy/COST_DISCIPLINE.md`` matches the
project rule (≤30k silent / 30-80k disclose / >80k abort).

Public surface:
- :func:`collect_project_context_files` — pure-stdlib walk; no
  config dependency.
- :func:`render_project_context` — read files, build the block,
  apply cost-gate.
- :exc:`ProjectContextTooLarge` — raised when the >80k abort fires.

The actual session-create wiring is in
``remote_cli.RemoteSessionClient.open()``; this module is just the
walk + render primitives.

This file lives ONLY in the client wheel — it is not synced from a
server canonical. The walk + render is purely a client operation
(server has no cwd to walk from). See ``scripts/sync_client.py``
``_WHEEL_ONLY_PRESERVE`` for the preservation guard.
"""
from __future__ import annotations

import sys
from pathlib import Path


# Token / byte conversion. The same 4-bytes-per-token heuristic
# ``estimate_tokens`` uses for cheap pre-flight estimates — fine for
# gating purposes (over-estimates slightly on dense ASCII, which
# biases the gate conservative).
_BYTES_PER_TOKEN = 4.0

# Cost-gate thresholds — match the project's COST_DISCIPLINE 30k/80k
# rule. Tokens, not bytes.
SOFT_DISCLOSE_TOKENS = 30_000
HARD_ABORT_TOKENS = 80_000

# Hard cap on the walk so a misconfigured cwd (e.g. a deeply-nested
# build artifact path) can't iterate 200 levels.
DEFAULT_MAX_DEPTH = 10


class ProjectContextTooLarge(Exception):
    """Raised by :func:`render_project_context` when the combined
    CLAUDE.md content exceeds the 80k-token hard cap.

    Carries the estimated token count so callers can render a
    useful error message without re-computing.
    """

    def __init__(self, *, estimated_tokens: int, total_bytes: int) -> None:
        self.estimated_tokens = estimated_tokens
        self.total_bytes = total_bytes
        super().__init__(
            f"Project context ({total_bytes:,} bytes ≈ "
            f"{estimated_tokens:,} tokens) exceeds the "
            f"{HARD_ABORT_TOKENS:,}-token hard cap. Pass "
            "`--no-project-context` to skip injection OR trim "
            "CLAUDE.md files at the parent levels of the walk."
        )


def collect_project_context_files(
    cwd: Path | str,
    *,
    terminate_at: Path | str | None = None,
    max_depth: int = DEFAULT_MAX_DEPTH,
) -> list[Path]:
    """Walk from ``cwd`` toward parent directories, collecting every
    ``CLAUDE.md`` found.

    Termination order (first one to fire wins):
    1. The current directory IS ``terminate_at`` (inclusive).
    2. We've already walked ``max_depth`` levels.
    3. We've reached the filesystem root (no parent).

    Default ``terminate_at`` is the user's home directory — overridable
    so tests can keep their walks bounded to ``tmp_path``.

    NOTE on ``.git`` directories (revised in UAT 2026-05-14): we
    deliberately do NOT use ``.git`` as a hard-stop, because nested
    git repositories are common in this workspace pattern
    (e.g. ``platforms_os/`` is a repo AND ``platforms_os/master_agents_os/``
    is ALSO a repo). Stopping at the first ``.git`` would mean a chat
    started inside the inner repo never sees the outer repo's CLAUDE.md.
    ROADMAP E48 explicitly requires both: "new chat session from any
    subdir of ``platforms_os/`` shows BOTH ``platforms_os/CLAUDE.md``
    + ``master_agents_os/CLAUDE.md``". We rely on ``terminate_at``
    (defaults to ``$HOME``) + ``max_depth`` as the practical bounds.

    Returned paths are sorted OUTERMOST FIRST (highest in the tree
    first), so when rendered the project-wide rules appear before
    the subdirectory-specific overrides. ``CLAUDE.md`` entries that
    are directories (rare; user mistake) or unreadable are skipped
    silently — better to ship a partial block than to crash session
    start.
    """
    base = Path(cwd).expanduser().resolve()
    if terminate_at is None:
        try:
            home = Path.home().resolve()
        except (RuntimeError, OSError):
            home = base.anchor  # type: ignore[assignment]
        terminate = Path(home)
    else:
        terminate = Path(terminate_at).expanduser().resolve()

    collected: list[Path] = []
    current = base
    depth = 0
    while True:
        # Look for CLAUDE.md at the current level.
        candidate = current / "CLAUDE.md"
        # ``is_file()`` excludes directory-shaped CLAUDE.md (rare user
        # mistake), broken symlinks, and missing entries — all the
        # cases where reading would fail.
        if candidate.is_file():
            collected.append(candidate)

        # Termination checks AFTER collecting at the current level so
        # the terminate_at level's CLAUDE.md (if any) gets included.
        if current == terminate:
            break
        if depth >= max_depth:
            break
        parent = current.parent
        if parent == current:
            # Reached the filesystem root.
            break
        current = parent
        depth += 1

    # Outermost first.
    return list(reversed(collected))


def render_project_context(
    files: list[Path],
    *,
    soft_disclose_tokens: int = SOFT_DISCLOSE_TOKENS,
    hard_abort_tokens: int = HARD_ABORT_TOKENS,
) -> tuple[str, str]:
    """Concatenate the file contents into a ``<project_context>`` block
    and return ``(block, disclosure_message)``.

    ``disclosure_message`` is:
    - ``""`` when the total is ≤30k tokens (silent).
    - A human-readable line when the total is 30k-80k tokens (the
      caller prints this on stderr so the user knows what loaded).
    - Never returned when the total exceeds 80k — that path raises
      :exc:`ProjectContextTooLarge` instead.

    Block format::

        <project_context>
          Project rules loaded from the directory tree above this
          chat's working directory. Treat as user-asserted rules
          (FACT-class) — these are the same rules a human running
          Claude Code in this directory would see.

          ## <path/to/CLAUDE.md>
          <file content>

          ## <path/to/inner/CLAUDE.md>
          <file content>
        </project_context>

    Files are emitted in the order they appear in ``files`` — the
    caller (typically :func:`collect_project_context_files`) is
    responsible for sorting outermost-first.
    """
    if not files:
        return "", ""

    # Read everything once; track byte totals for the gate.
    sections: list[str] = []
    total_bytes = 0
    for path in files:
        try:
            content = path.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            # Skip unreadable files — they'd surface as confusing
            # noise in the block.
            continue
        total_bytes += len(content)
        # Use the path verbatim as a header so the agent can cite
        # which CLAUDE.md a rule came from.
        sections.append(f"  ## {path}\n{_indent(content, 2)}")

    if not sections:
        return "", ""

    estimated_tokens = int(total_bytes / _BYTES_PER_TOKEN)
    if estimated_tokens > hard_abort_tokens:
        raise ProjectContextTooLarge(
            estimated_tokens=estimated_tokens, total_bytes=total_bytes,
        )

    block = (
        "<project_context>\n"
        "  Project rules loaded from the directory tree above this\n"
        "  chat's working directory. Treat as user-asserted rules\n"
        "  (FACT-class) — these are the same rules a human running\n"
        "  Claude Code in this directory would see.\n\n"
        + "\n\n".join(sections)
        + "\n</project_context>"
    )

    disclosure = ""
    if estimated_tokens > soft_disclose_tokens:
        disclosure = (
            f"Loaded {len(files)} CLAUDE.md file(s) "
            f"({total_bytes:,} bytes ≈ {estimated_tokens:,} tokens) "
            f"into <project_context>. Use --no-project-context to skip."
        )

    return block, disclosure


def _indent(text: str, n: int) -> str:
    """Prefix every line of ``text`` with ``n`` spaces. Used to nest
    CLAUDE.md bodies inside the block's two-space indent so the
    structure stays visually grouped in the agent's prompt.
    """
    prefix = " " * n
    return "\n".join(prefix + line if line else line for line in text.splitlines())
