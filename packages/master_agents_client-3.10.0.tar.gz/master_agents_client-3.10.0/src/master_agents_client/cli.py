"""CLI entry point for master_agents_client.

Usage:
    mao-client remote login --server URL [--token TOKEN] [...]
    mao-client remote logout
    mao-client remote run "prompt" [--master NAME]
    mao-client remote chat [--master NAME] [--new] [--pick] [--resume ID]
    mao-client admin <clients|keys|roles|audit> ...   (admin role only)
"""

from __future__ import annotations

import argparse
import os
import sys

try:
    from dotenv import load_dotenv
except ImportError:  # python-dotenv is a hard dep, but stay defensive.
    def load_dotenv(*_args, **_kwargs) -> None:  # type: ignore[no-redef]
        return None

from . import __version__


def _load_env() -> None:
    load_dotenv(override=False)


def _ensure_utf8_stdout() -> None:
    """Force stdout/stderr to UTF-8 so non-ASCII agent output (arrows,
    em-dashes, box-drawing) doesn't crash the CLI on Windows where
    the default cp1252 codec rejects them. Linux/macOS are already
    UTF-8 by default — the call is a no-op there.

    Tolerant of redirected streams (pytest capture, BytesIO wrappers,
    loggers): anything without `reconfigure` is skipped silently.
    """
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            continue


def _install_safe_excepthook() -> None:
    """E21 (2026-05-10) — replace the default excepthook with one that
    survives Windows cp1252 partial-write truncation AND persists the
    full chain to disk. Pre-fix, an exception escaping main() with
    non-ASCII chars in its traceback (em-dashes from agent error
    messages, arrows from prompts, box-drawing from rich-formatted
    server errors) hit a partial-write on the cp1252 stderr stream
    and the chain was cut off mid-format — operators saw
    ``RuntimeError: server returned`` then silence, with no clue what
    actually went wrong.

    The hook:
      1. Builds the FULL exception chain via ``traceback.format_exception``
         up-front, so a render error doesn't decapitate the chain.
      2. Writes the encoded bytes via ``sys.stderr.buffer.write`` when
         possible — bypasses ``TextIOWrapper``'s encoding entirely,
         so cp1252 narrowing never fires.
      3. Falls back to ``sys.stderr.write`` if no buffer (pytest
         capsys, redirected streams).
      4. Persists the chain bytes to ``<master_agents_home>/last_crash.log``
         even when the stream write succeeds — so a parent process
         that DOES truncate (PowerShell host buffer, ConEmu) leaves
         the user with a full on-disk record. Rotates: a pre-existing
         ``last_crash.log`` is renamed to ``prev_crash.log`` before
         the new bytes are written, so a second crash in the same
         session doesn't wipe the first record (E21 follow-up).
      5. Never re-raises from the hook itself — defensive at every
         step.

    Each call replaces ``sys.excepthook`` with a new closure that
    captures the previous hook as its fallback. Calling N times
    produces an N-deep fallback chain. The closure does NOT detect
    "if it was ours" — installation is always unconditional."""
    import traceback

    previous = sys.excepthook

    def _safe_excepthook(exc_type, exc_value, exc_tb):
        # Build the chain UP-FRONT so a render error in
        # format_exception itself doesn't lose the original.
        try:
            chain_str = "".join(
                traceback.format_exception(exc_type, exc_value, exc_tb)
            )
        except Exception:
            try:
                chain_str = f"{exc_type.__name__}: {exc_value!r}\n"
            except Exception:
                chain_str = "<excepthook: failed to format exception>\n"

        encoded = chain_str.encode("utf-8", errors="replace")

        # Path A — bytes-buffer write bypasses cp1252 narrowing.
        wrote = False
        try:
            buf = getattr(sys.stderr, "buffer", None)
            if buf is not None:
                buf.write(encoded)
                buf.flush()
                wrote = True
        except Exception:
            pass

        # Path B — fall back to text-mode write with replace handler.
        if not wrote:
            try:
                sys.stderr.write(chain_str)
                sys.stderr.flush()
                wrote = True
            except Exception:
                pass

        # Path C — last-resort delegate to the previous excepthook.
        if not wrote:
            try:
                previous(exc_type, exc_value, exc_tb)
            except Exception:
                pass

        # Persist to disk regardless of stream success — operators
        # have a full record even when the parent terminal truncates.
        # Rotate first so a second crash in the same session keeps
        # the previous record at prev_crash.log instead of clobbering
        # it (E21 follow-up — reviewer S3).
        try:
            from ._paths import master_agents_home
            home = master_agents_home()
            home.mkdir(parents=True, exist_ok=True)
            crash_log = home / "last_crash.log"
            prev_log = home / "prev_crash.log"
            if crash_log.exists():
                try:
                    if prev_log.exists():
                        prev_log.unlink()
                    crash_log.replace(prev_log)
                except Exception:
                    pass
            crash_log.write_bytes(encoded)
        except Exception:
            pass

    sys.excepthook = _safe_excepthook


def detect_argv_mojibake(argv):
    """E4 — return True if argv looks corrupted by Windows cp1252
    narrowing. PowerShell hands UTF-8 input through cp1252 before
    Python sees it; non-ASCII chars get mangled. Conservative
    detection: literal `\\xNN` hex escapes (\x3b for `;`, etc.)
    OR U+FFFD replacement chars."""
    if not argv:
        return False
    import re as _re
    for arg in argv:
        if not arg:
            continue
        if "\\x" in arg and _re.search(r"\\x[0-9a-fA-F]{2}", arg):
            return True
        if "\ufffd" in arg:
            return True
    return False


def format_mojibake_warning():
    """E4 — actionable stderr warning; recommends `chcp 65001` or WSL."""
    return (
        "\u26a0 Argv mojibake detected \u2014 your prompt likely "
        "contains non-ASCII characters that PowerShell mangled via "
        "cp1252 before Python could read them.\n"
        "   Workarounds:\n"
        "   1. Set the PowerShell session to UTF-8 once:\n"
        "        chcp 65001\n"
        "      Then re-run your `mao-client remote run ...` command.\n"
        "   2. OR invoke via WSL bash (clean UTF-8 argv handling):\n"
        "        wsl mao-client remote run ...\n"
        "   The current prompt has been sent as-is and may produce "
        "garbled output."
    )


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mao-client",
        description=(
            "Master Agents thin client. Talks to a hosted service; runs "
            "file/git/bash tools locally under explicit path allowlists."
        ),
    )
    parser.add_argument("--version", action="version", version=f"%(prog)s {__version__}")
    sub = parser.add_subparsers(dest="command", required=True)

    # E22 (2026-05-10) — admin RBAC + tier-key management subcommand
    # tree. Defined in admin_cli_client.py, which is wheel-only
    # (no canonical source; preserved by _WHEEL_ONLY_PRESERVE in
    # scripts/sync_client.py). Admin role required at runtime.
    from .admin_cli_client import add_admin_subparser
    add_admin_subparser(sub)

    p_remote = sub.add_parser(
        "remote",
        help="Talk to a hosted Master Agents service.",
    )
    remote_sub = p_remote.add_subparsers(dest="remote_command", required=True)

    p_login = remote_sub.add_parser("login", help="Save server URL + bearer token.")
    p_login.add_argument("--server", required=True)
    p_login.add_argument("--token", default=None, help="Bearer token (interactive prompt if omitted).")
    p_login.add_argument("--default-master", default=None)
    p_login.add_argument(
        "--writable-paths",
        default=None,
        help="Comma-separated paths the server may write to via tools.",
    )
    p_login.add_argument("--config", default=None)

    p_logout = remote_sub.add_parser("logout", help="Remove saved remote config.")
    p_logout.add_argument("--config", default=None)

    # E49 (Wave 3, 2026-05-14) — scheduled-agent routines.
    p_routine = remote_sub.add_parser(
        "routine",
        help="Manage scheduled routines (~/.master_agents/schedules.yaml).",
    )
    routine_sub = p_routine.add_subparsers(
        dest="routine_command", required=True,
    )
    p_rt_add = routine_sub.add_parser("add", help="Add a new routine.")
    p_rt_add.add_argument("name", help="Routine name (unique).")
    p_rt_add.add_argument(
        "--master", "-m", required=True, dest="master",
        help="Master agent name (e.g. assistant_cli).",
    )
    p_rt_add.add_argument(
        "--prompt", required=True,
        help="Prompt to send on each fire.",
    )
    rt_sched = p_rt_add.add_mutually_exclusive_group(required=True)
    rt_sched.add_argument(
        "--every", default=None,
        help="Repeat interval: Nm / Nh / Nd.",
    )
    rt_sched.add_argument(
        "--at", default=None,
        help='Daily fire time HH:MM.',
    )
    p_rt_add.add_argument("--config", default=None)
    p_rt_list = routine_sub.add_parser("list", help="List all routines.")
    p_rt_list.add_argument("--config", default=None)
    p_rt_remove = routine_sub.add_parser("remove", help="Remove a routine by name.")
    p_rt_remove.add_argument("name")
    p_rt_remove.add_argument("--config", default=None)
    p_rt_run_all = routine_sub.add_parser(
        "run-all",
        help="Fire every routine whose next_fire_ts is past now. "
             "Intended to be called by system cron every N minutes.",
    )
    p_rt_run_all.add_argument("--config", default=None)

    p_run = remote_sub.add_parser(
        "run",
        help="One-shot remote run.",
        description=(
            "Examples:\n"
            "  mao-client remote run \"hello there\"\n"
            "  mao-client remote run --master assistant_cli \"summarise ./notes\""
        ),
    )
    p_run.add_argument("prompt", nargs="?", default="")
    p_run.add_argument("--master", "-m", dest="master", default=None)
    p_run.add_argument("--config", default=None)
    # Phase 1 — slash-command-equivalent session controls. Each maps
    # 1:1 to a chat slash command's POST /sessions/{id}/set_* endpoint.
    from master_agents_client.remote_cli import parse_token_count as _ptc
    p_run.add_argument(
        "--cap", type=_ptc, default=None,
        help="Session-cumulative token cap (e.g. `4M`, `500_000`). Mirrors `/cap`.",
    )
    p_run.add_argument(
        "--threshold-ask-user", "--budget", type=_ptc, default=None,
        dest="threshold_ask_user",
        help="Per-turn cost-gate budget in tokens. Mirrors `/threshold-ask-user` (alias `/budget`).",
    )
    p_run.add_argument(
        "--threshold-max-steps", type=int, default=None,
        dest="threshold_max_steps",
        help="Override per-turn max_steps. Mirrors `/threshold-max-steps`.",
    )
    p_run.add_argument(
        "--threshold-total-steps", type=int, default=None,
        dest="threshold_total_steps",
        help="Override session-cumulative max_total_steps. Mirrors `/threshold-total-steps`.",
    )
    p_run.add_argument(
        "--threshold-turn-input", type=_ptc, default=None,
        dest="threshold_turn_input",
        help="Per-turn input-token ceiling. Mirrors `/threshold-turn-input`.",
    )
    p_run.add_argument(
        "--threshold-auto-compact", type=_ptc, default=None,
        dest="threshold_auto_compact",
        help="Auto-compact trigger threshold. Mirrors `/threshold-auto-compact`.",
    )
    p_run.add_argument(
        "--model", default=None,
        help="Switch reasoning tier (`standard` / `pro` / full model id). Mirrors `/model`.",
    )
    # B55 — headless approval policy. `remote run` has no REPL to
    # answer the agent's `needs_approval` event; pre-B55 the dispatch
    # raised RuntimeError and lost the answer. Default is "ask"
    # (backward-compatible); operators who trust the agent's tool
    # surface can pass "allow" to auto-approve.
    p_run.add_argument(
        "--approve-tool-calls",
        dest="approve_tool_calls",
        choices=["ask", "allow", "deny"],
        default="ask",
        help=(
            "Headless approval policy for tool calls that require approval. "
            "'ask' (default) raises if the agent emits needs_approval — "
            "preserves pre-B55 behaviour. 'allow' auto-approves every "
            "event (review the agent's tool surface first). 'deny' "
            "auto-rejects, useful for dry-running a read-only agent."
        ),
    )
    # Lifecycle flags. `--detach` and `--resume*` are independent;
    # `--resume` and `--resume-last` are mutually exclusive.
    p_run.add_argument(
        "--detach", action="store_true",
        help="Don't close the session after the run. Print session_id "
             "to stderr; resume later with --resume <id> or --resume-last.",
    )
    # E48 (2026-05-14) — opt out of project-rules auto-walk.
    p_run.add_argument(
        "--no-project-context",
        action="store_false",
        dest="project_context",
        default=True,
        help="Skip the CLAUDE.md auto-walk at session open. Without "
             "this flag, the client walks cwd → repo-root/$HOME and "
             "ships the rendered <project_context> block to the server.",
    )
    # Wave 1.5 (2026-05-14) — per-session max_output_tokens override.
    p_run.add_argument(
        "--max-output-tokens", type=int, default=None,
        dest="max_output_tokens",
        help="Override the agent spec's max_output_tokens cap for "
             "this session. Mirrors `/max-output-tokens` slash command.",
    )
    resume_grp = p_run.add_mutually_exclusive_group()
    resume_grp.add_argument(
        "--resume", default=None, metavar="SESSION_ID",
        help="Re-attach to a previously detached session by id (mirrors `agents remote chat --resume`).",
    )
    resume_grp.add_argument(
        "--resume-last", action="store_true", dest="resume_last",
        help="Re-attach to the most-recent detached session for this master "
             "(read from per-master last-session file). Mutually exclusive with --resume.",
    )

    p_chat = remote_sub.add_parser(
        "chat",
        help="Interactive remote chat.",
    )
    p_chat.add_argument("--master", "-m", dest="master", default=None)
    p_chat.add_argument("--config", default=None)
    p_chat.add_argument("--no-color", action="store_true")
    p_chat.add_argument("--quiet", action="store_true")
    p_chat.add_argument("--no-markdown", action="store_true")
    p_chat.add_argument("--no-diffs", action="store_true")
    p_chat.add_argument("--new", action="store_true")
    p_chat.add_argument("--pick", action="store_true")
    # E44 (2026-05-13) — autonomous-run mode for trusted specs.
    p_chat.add_argument(
        "--auto-approve",
        action="store_true",
        dest="auto_approve",
        help="Auto-approve every needs_approval event (autonomous mode). "
             "Toggleable mid-session via `/auto-approve on|off|status`.",
    )
    # E48 (2026-05-14) — opt out of project-rules auto-walk (mirrors
    # the `remote run` flag of the same name).
    p_chat.add_argument(
        "--no-project-context",
        action="store_false",
        dest="project_context",
        default=True,
        help="Skip the CLAUDE.md auto-walk at session open. Without "
             "this flag, the client walks cwd → repo-root/$HOME and "
             "ships the rendered <project_context> block to the server.",
    )
    # `--resume` and `--resume-last` are mutually exclusive (parity with
    # `remote run`). Original E39 added the flag to `remote run` only,
    # leaving the [Session ended] hint message pointing at a chat flag
    # that didn't exist — hotfixed in v3.3.3 (2026-05-13).
    p_chat_resume_grp = p_chat.add_mutually_exclusive_group()
    p_chat_resume_grp.add_argument(
        "--resume", dest="resume_id", default=None,
        help="Resume a specific session by id.",
    )
    p_chat_resume_grp.add_argument(
        "--resume-last", action="store_true", dest="resume_last",
        help="Resume the most-recent detached session for the resolved "
             "master (per-master last_session file). Mutually exclusive "
             "with --resume.",
    )

    return parser


def main(argv: list[str] | None = None) -> int:
    # Must run BEFORE any print/sys.stdout.write — agent answers
    # routinely include non-ASCII (arrows, em-dashes) that crash
    # cp1252 on Windows. No-op on Linux/macOS.
    _ensure_utf8_stdout()
    # E21 — install a cp1252-resistant excepthook BEFORE any code
    # that might raise. Without this, a non-ASCII traceback
    # truncates partway through on Windows and operators lose the
    # RuntimeError chain that explains what actually went wrong.
    _install_safe_excepthook()
    # E4 — warn on cp1252 argv mojibake (input-side counterpart of
    # the stdout fix). Light fix: detect + recommend chcp/WSL.
    if detect_argv_mojibake(argv if argv is not None else sys.argv[1:]):
        print(format_mojibake_warning(), file=sys.stderr, flush=True)
    _load_env()
    parser = build_parser()
    args = parser.parse_args(argv)

    if args.command == "remote":
        from .remote_cli import _cmd_remote
        return _cmd_remote(args)

    if args.command == "admin":
        from .admin_cli_client import cmd_admin
        return cmd_admin(args)

    parser.print_help()
    return 2


if __name__ == "__main__":
    sys.exit(main())
