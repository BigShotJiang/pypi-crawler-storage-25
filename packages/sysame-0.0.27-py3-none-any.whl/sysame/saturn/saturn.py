# -*- coding: utf-8 -*-
"""
Module for creating and calling Saturn native process scripts.
"""

##### IMPORTS #####
# Standard imports
from pathlib import Path
import subprocess

# Third party imports
import numpy as np
import openmatrix as omx  # type: ignore

# Local imports

##### CONSTANTS #####

##### CLASSES #####


##### FUNCTIONS #####
def unstack_ufm(
    saturn_exes: Path,
    ufm_path: Path,
) -> None:
    """Unstack Saturn/UFM matrix.

    Parameters
    ----------
    saturn_exes : Path
        Path to Saturn executables directory, where Saturn MX should be located
    ufm_path : Path
        Path to UFM file to unstack

    Raises
    ------
    RuntimeError
        When Saturn fails
    """
    # Create key file
    key_script_path = Path(ufm_path.parent.resolve() / "Key_Unstack.Key")
    vdu_script_path = Path(ufm_path.parent.resolve() / "VDU_Unstack.VDU")
    with open(key_script_path, "wt", encoding="utf-8") as key_file:
        key_file.write(
            "\n".join(
                [
                    "15",
                    "1",
                    "1",
                    "0",
                    "0",
                    "0",
                ]
            )
        )
    with open(vdu_script_path, "wt", encoding="utf-8") as _:
        pass
    saturn_mx = saturn_exes / "$MX"
    args = [
        str(saturn_mx.resolve()),
        str(ufm_path.resolve()),
        "KEY",
        str(key_script_path.with_suffix("")),
        "VDU",
        str(vdu_script_path.with_suffix("")),
    ]
    process_results = subprocess.run(args, capture_output=True, check=False)
    if process_results.returncode != 0:
        print(f" ERROR: Unstacking {ufm_path} Failed")
        raise RuntimeError
    # clean up key and vdu files
    key_script_path.unlink(missing_ok=True)
    vdu_script_path.unlink(missing_ok=True)


def run_satpig(
    saturn_exes: Path,
    ufs_path: Path,
    ufm_path: Path,
    mode_id: int | str,
) -> None:
    """Run SatPig to produce Saturn Routes.

    Parameters
    ----------
    saturn_exes : Path
        Path to Saturn executables directory, where Saturn SatPig should be located
    ufs_path: Path
        Path to UFS file to unstack
    ufm_path : Path
        Path to UFM file to unstack
    mode_id: int | str
        Userclass/Mode ID

    Raises
    ------
    RuntimeError
        When Saturn fails
    """
    # Create key file
    control_file_path = Path(ufs_path.parent.resolve() / f"UC{mode_id}_CF.DAT")
    with open(control_file_path, "wt", encoding="utf-8") as ct_file:
        ct_file.write(
            "\n".join(
                [
                    "&PARAM",
                    "TRPFOR = F",
                    "CSVFOR = T",
                    "NAMES = F",
                    "ALLOD = F",
                    "FPHMIN = 0.02",
                    f"NOMAD = {mode_id}",
                    "&END",
                ]
            )
        )
    saturn_satpig = saturn_exes / "$SATPIG"
    args = [
        str(saturn_satpig.resolve()),
        str(ufs_path.with_suffix("")),
        str(ufm_path.with_suffix("")),
        "KR",
        str(control_file_path.with_suffix("")),
    ]
    process_results = subprocess.run(args, capture_output=True, check=False)
    if process_results.returncode != 0:
        print(f" ERROR: SatPig for UFS:{ufs_path} & UFM:{ufm_path} has Failed")
        raise RuntimeError
    # Cleanup
    control_file_path.unlink(missing_ok=True)


def ufm_to_omx(
    saturn_exes: Path,
    ufm_path: Path,
) -> None:
    """Convert UFM to OMX.

    Parameters
    ----------
    saturn_exes : Path
        Path to Saturn executables directory, where Saturn MX should be located
    ufm_path : Path
        Path to UFM file to convert

    Raises
    ------
    RuntimeError
        When Converting UFM to OMX fails
    """
    saturn_mx = saturn_exes / "$MX"
    args = [str(saturn_mx.resolve()), str(ufm_path.with_suffix("")), "/DUMPO"]
    process_results = subprocess.run(args, capture_output=True, check=False)
    if process_results.returncode != 0:
        print(f" ERROR: Converting {ufm_path} to OMX Failed")
        raise RuntimeError


def read_ufm_to_array(
    saturn_exes: Path,
    ufm_path: Path,
    limited_tabs: list[str] | None = None,
    clean_omx: bool = True,
) -> dict[str, np.ndarray]:
    """Read UFM into a dictionary of arrays.

    Converts UFM to OMX using Saturn MX, then reads
    the OMX into numpy arrays.

    Parameters
    ----------
    saturn_exes : Path
        Path to Saturn executables directory, where Saturn MX should be located
    ufm_path : Path
        Path to UFM file to read
    limited_tabs : list[str], optional
        If only specific tabs are needed from the OMX, by default None
    clean_omx : bool, optional
        Whether or not to remove the OMX after being read, by default True

    Returns
    -------
    dict[str, np.ndarray]
        Dictionary of matrices in array format

    Raises
    ------
    RuntimeError
        When converting UFM to OMX fails
    """
    if limited_tabs is None:
        limited_tabs = []
    # Convert UFM to OMX
    ufm_to_omx(saturn_exes, ufm_path)
    # Read OMX
    omx_path = ufm_path.with_suffix(".omx")
    array_dict: dict[str, np.ndarray] = {}
    with omx.open_file(omx_path) as omx_mat:
        if len(limited_tabs) == 0:
            tab_list = omx_mat.list_matrices()
        else:
            tab_list = limited_tabs
        for tab in tab_list:
            array_dict[tab] = np.array(omx_mat[tab])
    # Clean up OMX if needed
    if clean_omx:
        omx_path.unlink(missing_ok=True)
    return array_dict


def skim_time(
    saturn_exes: Path,
    ufs_path: Path,
) -> None:
    """Skim HW Time from UFS.

    Parameters
    ----------
    saturn_exes : Path
        Path to Saturn executables directory, where Saturn SatLook should be located
    ufs_path : Path
        Path to UFS file to skim

    Raises
    ------
    RuntimeError
        When Skimming time off the UFS fails
    """
    satlook_exe = saturn_exes / "$SATLOOK"
    args = [
        str(satlook_exe.resolve()),
        str(ufs_path),
        "M",
        "28",
        f"{ufs_path.with_suffix('')}_TimeSkim",
        "/TIMESKIM",
    ]
    process_results = subprocess.run(args, capture_output=True, check=False)
    if process_results.returncode != 0:
        print(f" ERROR: Skimming time from {ufs_path} has Failed")
        raise RuntimeError


def extract_network_data(
    saturn_exes: Path,
    network_ufs_file: Path,
) -> None:
    """Export Saturn network data.

    Parameters
    ----------
    saturn_exes : Path
        Path to Saturn executables directory, where Saturn SatDB should be located
    network_ufs_file : Path
        Path to UFS file to unstack

    Raises
    ------
    RuntimeError
        When Exporting Nodes or Links fails using SatDB.
    """
    # Create key & VDU files
    nodes_key_file = Path(network_ufs_file.parent.resolve() / "Nodes_Key.Key")
    nodes_vdu_file = Path(network_ufs_file.parent.resolve() / "Nodes_VDU.VDU")
    links_key_file = Path(network_ufs_file.parent.resolve() / "Links_Key.Key")
    links_vdu_file = Path(network_ufs_file.parent.resolve() / "Links_VDU.VDU")
    # create key files
    with open(nodes_key_file, "wt", encoding="utf-8") as ct_file:
        ct_file.write(
            "\n".join(
                [
                    "2",
                    "6",
                    "2",
                    "3",
                    "5",
                    "0",
                    "0",
                    "6",
                    "6",
                    "0",
                    "13",
                    "1",
                    "0",
                    f"{network_ufs_file.parent.resolve()}/Nodes.CSV",
                    "Y",
                    "0",
                    "Y",
                ]
            )
        )
    with open(links_key_file, "wt", encoding="utf-8") as ct_file:
        ct_file.write(
            "\n".join(
                [
                    "2",
                    "6",
                    "2",
                    "3",
                    "5",
                    "0",
                    "0",
                    "4",
                    "1893",
                    "1803",
                    "4003",
                    "4053",
                    "1863",
                    "4513",
                    "0",
                    "13 ",
                    "1",
                    "0",
                    f"{network_ufs_file.parent.resolve()}/Links.CSV",
                    "0",
                    "y",
                ]
            )
        )
    with open(nodes_vdu_file, "wt", encoding="utf-8") as _:
        pass
    with open(links_vdu_file, "wt", encoding="utf-8") as _:
        pass
    satdb_path = saturn_exes / "$SATDB"
    args = [
        str(satdb_path.resolve()),
        str(network_ufs_file.with_suffix("")),
        "KEY",
        str(nodes_key_file.with_suffix("")),
        "VDU",
        str(nodes_vdu_file.with_suffix("")),
    ]
    process_results = subprocess.run(args, capture_output=True, check=False)
    if process_results.returncode != 0:
        print(f" ERROR: SatDB Failed exporting nodes from {network_ufs_file}")
        raise RuntimeError
    args = [
        str(satdb_path.resolve()),
        str(network_ufs_file.with_suffix("")),
        "KEY",
        str(links_key_file.with_suffix("")),
        "VDU",
        str(links_vdu_file.with_suffix("")),
    ]
    process_results = subprocess.run(args, capture_output=True, check=False)
    if process_results.returncode != 0:
        print(f" ERROR: SatDB Failed exporting links from {network_ufs_file}")
        raise RuntimeError
    # clean up key and vdu files
    nodes_key_file.unlink(missing_ok=True)
    nodes_vdu_file.unlink(missing_ok=True)
    links_key_file.unlink(missing_ok=True)
    links_vdu_file.unlink(missing_ok=True)


def skim_assignment(
    saturn_exes: Path,
    ufs_path: Path,
) -> None:
    """Skim assignment UFS.

    Parameters
    ----------
    saturn_exes : Path
        Path to Saturn executables directory, where SatLook should be located
    ufs_path : Path
        Path to UFS file to skim

    Raises
    ------
    RuntimeError
        When Skimming time off the UFS fails
    """
    args = (
        f'"{(saturn_exes / "$SATLOOK").resolve()}" "{ufs_path}" M 28 '
        f'"{ufs_path.with_suffix("")}_Skims" /3SCOOPM'
    )
    process_results = subprocess.run(args, capture_output=True, check=False)
    if process_results.returncode == 2:
        print(f" ERROR: Skimming assignment from {ufs_path} Failed with code 2")
        raise RuntimeError