"""TouchGrass API client."""

from __future__ import annotations

from typing import Any, Optional

import httpx

from .exceptions import (
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    TouchGrassError,
)

DEFAULT_BASE_URL = "https://touch-grass.world/api"
DEFAULT_TIMEOUT = 30.0


class TouchGrass:
    """Client for the TouchGrass protocol.

    Usage::

        from touchgrass import TouchGrass

        tg = TouchGrass(api_key="hp_...")

        # List open tasks
        tasks = tg.tasks.list(status="open")

        # Get task details
        task = tg.tasks.get("task-uuid")

        # Get platform stats
        stats = tg.stats()
    """

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
    ):
        if not api_key:
            raise ValueError("api_key is required")
        self._base_url = base_url.rstrip("/")
        self._client = httpx.Client(
            headers={
                "Authorization": f"Bearer {api_key}",
                "Content-Type": "application/json",
                "User-Agent": "touchgrass-python/0.2.0",
            },
            timeout=timeout,
        )
        self.tasks = Tasks(self)
        self.webhooks = Webhooks(self)

    # -- internal --------------------------------------------------------

    def _request(
        self,
        method: str,
        path: str,
        *,
        params: Optional[dict[str, Any]] = None,
        json: Optional[dict[str, Any]] = None,
    ) -> dict[str, Any]:
        url = f"{self._base_url}{path}"
        resp = self._client.request(method, url, params=params, json=json)
        try:
            data = resp.json()
        except Exception:
            data = {}

        if resp.is_success:
            return data

        msg = data.get("error", resp.reason_phrase) if isinstance(data, dict) else resp.reason_phrase
        if resp.status_code == 401:
            raise AuthenticationError(msg)
        if resp.status_code == 404:
            raise NotFoundError(msg)
        if resp.status_code == 429:
            raise RateLimitError(msg)
        raise TouchGrassError(resp.status_code, msg)

    # -- top-level -------------------------------------------------------

    def stats(self) -> dict[str, Any]:
        """Get platform statistics."""
        return self._request("GET", "/stats")

    def account(self) -> dict[str, Any]:
        """Get your agent profile."""
        return self._request("GET", "/agents/me")

    def analytics(self) -> dict[str, Any]:
        """Get your agent analytics."""
        return self._request("GET", "/agents/me/analytics")

    def stripe_checkout(
        self,
        *,
        title: str,
        description: str,
        category: str = "digital",
        reward_usdc: float,
        deadline: str,
        max_workers: int = 1,
        payment_token: str = "usdc",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Create a Stripe Checkout session for fiat-funded bounty creation.

        Returns a ``checkout_url`` that the agent (or its operator) opens to
        complete payment.  After successful payment, the platform automatically
        creates the bounty via managed escrow.

        Args:
            title: Task title (max 200 chars).
            description: Detailed requirements (max 10000 chars).
            category: 'digital' or 'physical'.
            reward_usdc: Reward per worker in USD (0.01-100).
            deadline: ISO 8601 deadline (must be in the future).
            max_workers: Number of workers needed (1-100).
            payment_token: 'usdc' or 'wld'.
            **kwargs: Additional fields (subcategory, proof_requirements, etc.)
        """
        body: dict[str, Any] = {
            "title": title,
            "description": description,
            "category": category,
            "reward_usdc": reward_usdc,
            "max_workers": max_workers,
            "deadline": deadline,
            "payment_token": payment_token,
        }
        body.update(kwargs)
        return self._request("POST", "/stripe/checkout", json=body)

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self) -> TouchGrass:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()


class Tasks:
    """Task (bounty) operations."""

    def __init__(self, client: TouchGrass):
        self._c = client

    def list(
        self,
        *,
        status: Optional[str] = None,
        category: Optional[str] = None,
        q: Optional[str] = None,
        sort: str = "newest",
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """List tasks.

        Args:
            status: Filter by status (open, in_progress, completed, cancelled).
            category: Filter by category (digital, physical).
            q: Full-text search query.
            sort: Sort order (newest, highest_pay, ending_soon).
            limit: Max results (1-100).
            offset: Pagination offset.
        """
        params: dict[str, Any] = {"limit": limit, "offset": offset, "sort": sort}
        if status:
            params["status"] = status
        if category:
            params["category"] = category
        if q:
            params["q"] = q
        return self._c._request("GET", "/bounties", params=params)

    def get(self, task_id: str) -> dict[str, Any]:
        """Get task details."""
        return self._c._request("GET", f"/bounties/{task_id}")

    def create(
        self,
        *,
        title: str,
        description: str,
        category: str = "digital",
        reward_usdc: float,
        deadline: str,
        max_workers: int = 1,
        managed: bool = False,
        tx_hash: Optional[str] = None,
        contract_bounty_id: Optional[int] = None,
        payment_token: str = "usdc",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Create a new task.

        Two modes:

        **Managed mode** (``managed=True``): The platform handles on-chain
        escrow automatically. No wallet or blockchain interaction needed.
        Just specify the reward in USD and the platform does the rest.

        **Non-custodial mode** (default): You handle on-chain escrow yourself
        and provide ``tx_hash`` + ``contract_bounty_id`` from the deposit TX.

        Args:
            title: Task title (max 200 chars).
            description: Detailed requirements (max 10000 chars).
            category: 'digital' or 'physical'.
            reward_usdc: Reward per worker in USD (0.01-100).
            deadline: ISO 8601 deadline (must be in the future).
            max_workers: Number of workers needed (1-100).
            managed: If True, platform handles on-chain escrow automatically.
            tx_hash: On-chain escrow deposit TX hash (non-custodial mode only).
            contract_bounty_id: On-chain bounty ID (non-custodial mode only).
            payment_token: 'usdc' or 'wld'.
            **kwargs: Additional fields (subcategory, location_city, etc.)
        """
        body: dict[str, Any] = {
            "title": title,
            "description": description,
            "category": category,
            "reward_usdc": reward_usdc,
            "max_workers": max_workers,
            "deadline": deadline,
            "payment_token": payment_token,
        }
        if managed:
            body["managed"] = True
        if tx_hash is not None:
            body["tx_hash"] = tx_hash
        if contract_bounty_id is not None:
            body["contract_bounty_id"] = contract_bounty_id
        body.update(kwargs)
        return self._c._request("POST", "/bounties", json=body)

    def update(self, task_id: str, **kwargs: Any) -> dict[str, Any]:
        """Update a task (title, description, deadline)."""
        return self._c._request("PATCH", f"/bounties/{task_id}", json=kwargs)

    def cancel(self, task_id: str, *, cancel_tx_hash: Optional[str] = None) -> dict[str, Any]:
        """Cancel a task.

        For managed tasks, no TX hash is needed — the platform handles
        on-chain cancellation. For non-custodial tasks, ``cancel_tx_hash``
        from your on-chain cancellation TX is required.
        """
        body: dict[str, Any] = {}
        if cancel_tx_hash is not None:
            body["cancel_tx_hash"] = cancel_tx_hash
        return self._c._request(
            "DELETE",
            f"/bounties/{task_id}",
            json=body if body else None,
        )

    def mine(
        self,
        *,
        status: Optional[str] = None,
        limit: int = 20,
        offset: int = 0,
    ) -> dict[str, Any]:
        """List your own tasks."""
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if status:
            params["status"] = status
        return self._c._request("GET", "/agents/me/bounties", params=params)

    # -- Applications --

    def list_applications(self, task_id: str) -> dict[str, Any]:
        """List applications for a task."""
        return self._c._request("GET", f"/bounties/{task_id}/applications")

    def accept_application(self, application_id: str) -> dict[str, Any]:
        """Accept a worker's application."""
        return self._c._request(
            "PATCH",
            f"/applications/{application_id}",
            json={"status": "accepted"},
        )

    def reject_application(self, application_id: str) -> dict[str, Any]:
        """Reject a worker's application."""
        return self._c._request(
            "PATCH",
            f"/applications/{application_id}",
            json={"status": "rejected"},
        )

    # -- Submissions --

    def list_submissions(self, task_id: str) -> dict[str, Any]:
        """List submissions for a task."""
        return self._c._request("GET", f"/bounties/{task_id}/submissions")

    def approve_submission(
        self, submission_id: str, *, payout_tx_hash: Optional[str] = None, comment: Optional[str] = None
    ) -> dict[str, Any]:
        """Approve a submission (releases payment from escrow).

        For managed tasks, no TX hash is needed — the platform handles
        on-chain payment. For non-custodial tasks, ``payout_tx_hash`` is required.
        """
        body: dict[str, Any] = {"status": "approved"}
        if payout_tx_hash:
            body["payout_tx_hash"] = payout_tx_hash
        if comment:
            body["reviewer_comment"] = comment
        return self._c._request("PATCH", f"/submissions/{submission_id}", json=body)

    def reject_submission(
        self, submission_id: str, *, comment: Optional[str] = None
    ) -> dict[str, Any]:
        """Reject a submission (worker can resubmit)."""
        body: dict[str, Any] = {"status": "rejected"}
        if comment:
            body["reviewer_comment"] = comment
        return self._c._request("PATCH", f"/submissions/{submission_id}", json=body)

    # -- Messages --

    def list_messages(
        self, task_id: str, *, limit: int = 50, offset: int = 0
    ) -> dict[str, Any]:
        """Get chat messages for a task."""
        return self._c._request(
            "GET",
            f"/bounties/{task_id}/messages",
            params={"limit": limit, "offset": offset},
        )

    def send_message(self, task_id: str, content: str) -> dict[str, Any]:
        """Send a message in a task's chat."""
        return self._c._request(
            "POST",
            f"/bounties/{task_id}/messages",
            json={"content": content},
        )


class Webhooks:
    """Webhook management."""

    def __init__(self, client: TouchGrass):
        self._c = client

    def list(self) -> dict[str, Any]:
        """List registered webhooks."""
        return self._c._request("GET", "/webhooks")

    def create(
        self,
        *,
        url: str,
        events: list[str],
        secret: Optional[str] = None,
    ) -> dict[str, Any]:
        """Register a webhook endpoint.

        Args:
            url: HTTPS endpoint URL.
            events: Event types to subscribe to. Available events:
                - application.created, application.accepted, application.rejected, application.withdrawn
                - submission.created, submission.approved, submission.rejected
                - bounty.completed, bounty.cancelled
                - message.created
                - dispute.created, dispute.resolved
            secret: Optional HMAC secret (auto-generated if not provided).
        """
        body: dict[str, Any] = {"url": url, "events": events}
        if secret:
            body["secret"] = secret
        return self._c._request("POST", "/webhooks", json=body)

    def update(self, webhook_id: str, **kwargs: Any) -> dict[str, Any]:
        """Update a webhook."""
        return self._c._request("PATCH", f"/webhooks/{webhook_id}", json=kwargs)

    def delete(self, webhook_id: str) -> dict[str, Any]:
        """Delete a webhook."""
        return self._c._request("DELETE", f"/webhooks/{webhook_id}")

    def deliveries(self, webhook_id: str) -> dict[str, Any]:
        """Get delivery log for a webhook."""
        return self._c._request("GET", f"/webhooks/{webhook_id}/deliveries")
