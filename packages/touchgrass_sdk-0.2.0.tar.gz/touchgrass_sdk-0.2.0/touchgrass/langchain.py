"""LangChain tool integration for TouchGrass.

Install with: pip install touchgrass[langchain]

Usage::

    from touchgrass.langchain import TouchGrassToolkit

    toolkit = TouchGrassToolkit(api_key="hp_...")
    tools = toolkit.get_tools()
    # Add `tools` to your LangChain agent
"""

from __future__ import annotations

import json
from typing import Any, Optional, Type

from .client import TouchGrass

try:
    from langchain_core.tools import BaseTool
    from pydantic import BaseModel, Field
except ImportError:
    raise ImportError(
        "LangChain integration requires langchain-core and pydantic. "
        "Install with: pip install touchgrass[langchain]"
    )


# -- Input schemas --------------------------------------------------------


class SearchTasksInput(BaseModel):
    status: Optional[str] = Field(None, description="Filter: open, in_progress, completed, cancelled, expired")
    category: Optional[str] = Field(None, description="Filter: digital or physical")
    q: Optional[str] = Field(None, description="Search query")
    limit: int = Field(10, description="Max results")


class GetTaskInput(BaseModel):
    task_id: str = Field(..., description="Task UUID")


class CreateTaskInput(BaseModel):
    title: str = Field(..., description="Clear task title (max 200 chars)")
    description: str = Field(..., description="Detailed requirements and acceptance criteria")
    category: str = Field("digital", description="'digital' or 'physical'")
    reward_usdc: float = Field(..., description="Reward per worker in USD (0.01-100)")
    deadline: str = Field(..., description="ISO 8601 deadline")
    max_workers: int = Field(1, description="Workers needed (1-100)")
    managed: bool = Field(True, description="If True (default), platform handles escrow. If False, provide tx_hash + contract_bounty_id")
    payment_token: str = Field("usdc", description="'usdc' or 'wld'")
    tx_hash: Optional[str] = Field(None, description="On-chain escrow deposit TX hash (non-custodial only)")
    contract_bounty_id: Optional[int] = Field(None, description="On-chain bounty ID (non-custodial only)")


class ReviewSubmissionInput(BaseModel):
    submission_id: str = Field(..., description="Submission UUID")
    approved: bool = Field(..., description="True to approve, False to reject")
    comment: Optional[str] = Field(None, description="Feedback for the worker")
    payout_tx_hash: Optional[str] = Field(None, description="Required for non-custodial approval. Not needed for managed tasks")


class ListApplicationsInput(BaseModel):
    task_id: str = Field(..., description="Task UUID")


class AcceptApplicationInput(BaseModel):
    application_id: str = Field(..., description="Application UUID")


class ListSubmissionsInput(BaseModel):
    task_id: str = Field(..., description="Task UUID")


class SendMessageInput(BaseModel):
    task_id: str = Field(..., description="Task UUID")
    content: str = Field(..., description="Message text")


class CancelTaskInput(BaseModel):
    task_id: str = Field(..., description="Task UUID to cancel")
    cancel_tx_hash: Optional[str] = Field(None, description="On-chain cancel TX hash (non-custodial only)")


class StripeCheckoutInput(BaseModel):
    title: str = Field(..., description="Task title (max 200 chars)")
    description: str = Field(..., description="Detailed requirements")
    category: str = Field("digital", description="'digital' or 'physical'")
    reward_usdc: float = Field(..., description="Reward per worker in USD (0.01-100)")
    deadline: str = Field(..., description="ISO 8601 deadline")
    max_workers: int = Field(1, description="Workers needed (1-100)")
    payment_token: str = Field("usdc", description="'usdc' or 'wld'")


class EmptyInput(BaseModel):
    pass


# -- Tools ----------------------------------------------------------------


class SearchTasksTool(BaseTool):
    name: str = "touchgrass_search_tasks"
    description: str = (
        "Search tasks on TouchGrass. Every worker is an Orb-verified human via World ID. "
        "Returns task listings with reward, deadline, and status."
    )
    args_schema: Type[BaseModel] = SearchTasksInput
    tg: Any = None

    def _run(self, **kwargs: Any) -> str:
        result = self.tg.tasks.list(**{k: v for k, v in kwargs.items() if v is not None})
        return json.dumps(result, indent=2)


class GetTaskTool(BaseTool):
    name: str = "touchgrass_get_task"
    description: str = "Get full details of a specific task including requirements and current status."
    args_schema: Type[BaseModel] = GetTaskInput
    tg: Any = None

    def _run(self, task_id: str) -> str:
        return json.dumps(self.tg.tasks.get(task_id), indent=2)


class CreateTaskTool(BaseTool):
    name: str = "touchgrass_create_task"
    description: str = (
        "Create a new task for Orb-verified humans. By default uses managed mode "
        "(platform handles escrow). Set managed=False and provide tx_hash + contract_bounty_id "
        "for non-custodial mode. Supports USDC and WLD payments."
    )
    args_schema: Type[BaseModel] = CreateTaskInput
    tg: Any = None

    def _run(self, **kwargs: Any) -> str:
        params = {k: v for k, v in kwargs.items() if v is not None}
        return json.dumps(self.tg.tasks.create(**params), indent=2)


class ListApplicationsTool(BaseTool):
    name: str = "touchgrass_list_applications"
    description: str = "List worker applications for your task. Each applicant is Orb-verified."
    args_schema: Type[BaseModel] = ListApplicationsInput
    tg: Any = None

    def _run(self, task_id: str) -> str:
        return json.dumps(self.tg.tasks.list_applications(task_id), indent=2)


class AcceptApplicationTool(BaseTool):
    name: str = "touchgrass_accept_application"
    description: str = "Accept a worker's application so they can start on the task."
    args_schema: Type[BaseModel] = AcceptApplicationInput
    tg: Any = None

    def _run(self, application_id: str) -> str:
        return json.dumps(self.tg.tasks.accept_application(application_id), indent=2)


class ListSubmissionsTool(BaseTool):
    name: str = "touchgrass_list_submissions"
    description: str = "List proof-of-completion submissions for a task."
    args_schema: Type[BaseModel] = ListSubmissionsInput
    tg: Any = None

    def _run(self, task_id: str) -> str:
        return json.dumps(self.tg.tasks.list_submissions(task_id), indent=2)


class ReviewSubmissionTool(BaseTool):
    name: str = "touchgrass_review_submission"
    description: str = (
        "Approve or reject a submission. Approval releases payment from escrow to the worker. "
        "For managed tasks, payout_tx_hash is not needed. Auto-approved after 72 hours if not reviewed."
    )
    args_schema: Type[BaseModel] = ReviewSubmissionInput
    tg: Any = None

    def _run(
        self,
        submission_id: str,
        approved: bool,
        comment: Optional[str] = None,
        payout_tx_hash: Optional[str] = None,
    ) -> str:
        if approved:
            result = self.tg.tasks.approve_submission(
                submission_id, payout_tx_hash=payout_tx_hash, comment=comment
            )
        else:
            result = self.tg.tasks.reject_submission(submission_id, comment=comment)
        return json.dumps(result, indent=2)


class SendMessageTool(BaseTool):
    name: str = "touchgrass_send_message"
    description: str = "Send a message to a worker in a task's chat thread."
    args_schema: Type[BaseModel] = SendMessageInput
    tg: Any = None

    def _run(self, task_id: str, content: str) -> str:
        return json.dumps(self.tg.tasks.send_message(task_id, content), indent=2)


class CancelTaskTool(BaseTool):
    name: str = "touchgrass_cancel_task"
    description: str = (
        "Cancel a task and refund escrowed funds. For managed tasks, no TX hash needed. "
        "For non-custodial tasks, provide cancel_tx_hash from your on-chain cancellation."
    )
    args_schema: Type[BaseModel] = CancelTaskInput
    tg: Any = None

    def _run(self, task_id: str, cancel_tx_hash: Optional[str] = None) -> str:
        return json.dumps(
            self.tg.tasks.cancel(task_id, cancel_tx_hash=cancel_tx_hash), indent=2
        )


class StripeCheckoutTool(BaseTool):
    name: str = "touchgrass_stripe_checkout"
    description: str = (
        "Create a Stripe Checkout session to fund a task with fiat currency (credit card). "
        "Returns a checkout_url. After payment completes, the bounty is automatically "
        "created via managed escrow. No wallet or crypto needed."
    )
    args_schema: Type[BaseModel] = StripeCheckoutInput
    tg: Any = None

    def _run(self, **kwargs: Any) -> str:
        return json.dumps(self.tg.stripe_checkout(**kwargs), indent=2)


class PlatformStatsTool(BaseTool):
    name: str = "touchgrass_platform_stats"
    description: str = (
        "Get TouchGrass platform statistics: total verified users, active tasks, "
        "completed tasks, and total USD paid out."
    )
    args_schema: Type[BaseModel] = EmptyInput
    tg: Any = None

    def _run(self) -> str:
        return json.dumps(self.tg.stats(), indent=2)


# -- Toolkit --------------------------------------------------------------


class TouchGrassToolkit:
    """LangChain toolkit for TouchGrass.

    Usage::

        from touchgrass.langchain import TouchGrassToolkit

        toolkit = TouchGrassToolkit(api_key="hp_...")
        tools = toolkit.get_tools()

        # Use with any LangChain agent
        from langchain.agents import AgentExecutor
        agent = AgentExecutor(agent=..., tools=tools)
    """

    def __init__(self, api_key: str, base_url: str = "https://touch-grass.world/api"):
        self.tg = TouchGrass(api_key=api_key, base_url=base_url)

    def get_tools(self) -> list[BaseTool]:
        """Return all TouchGrass tools for use in a LangChain agent."""
        tool_classes = [
            SearchTasksTool,
            GetTaskTool,
            CreateTaskTool,
            CancelTaskTool,
            ListApplicationsTool,
            AcceptApplicationTool,
            ListSubmissionsTool,
            ReviewSubmissionTool,
            SendMessageTool,
            StripeCheckoutTool,
            PlatformStatsTool,
        ]
        return [cls(tg=self.tg) for cls in tool_classes]
