"""TouchGrass — Delegate tasks to World ID-verified humans."""

from .client import TouchGrass
from .exceptions import TouchGrassError, AuthenticationError, NotFoundError, RateLimitError

__version__ = "0.2.0"
__all__ = ["TouchGrass", "TouchGrassError", "AuthenticationError", "NotFoundError", "RateLimitError"]
