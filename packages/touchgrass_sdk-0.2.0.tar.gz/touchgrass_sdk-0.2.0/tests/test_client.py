"""Tests for the TouchGrass client."""

import json
from unittest.mock import MagicMock, patch

import pytest

from touchgrass import TouchGrass, AuthenticationError, NotFoundError, RateLimitError, TouchGrassError


# -- Fixtures ----------------------------------------------------------------


@pytest.fixture
def mock_response():
    """Create a mock httpx response."""
    def _make(status_code: int = 200, body: dict | None = None):
        resp = MagicMock()
        resp.status_code = status_code
        resp.is_success = 200 <= status_code < 300
        resp.reason_phrase = "OK" if resp.is_success else "Error"
        resp.json.return_value = body or {}
        return resp
    return _make


@pytest.fixture
def tg():
    """Create a TouchGrass client with a test API key."""
    return TouchGrass(api_key="hp_test_key_123", base_url="https://test.local/api")


# -- Client initialization ---------------------------------------------------


def test_requires_api_key():
    with pytest.raises(ValueError, match="api_key is required"):
        TouchGrass(api_key="")


def test_client_sets_headers():
    tg = TouchGrass(api_key="hp_abc")
    headers = tg._client.headers
    assert headers["Authorization"] == "Bearer hp_abc"
    assert headers["Content-Type"] == "application/json"
    assert "touchgrass-python" in headers["User-Agent"]


def test_context_manager():
    with TouchGrass(api_key="hp_abc") as tg:
        assert tg is not None


def test_base_url_trailing_slash_stripped():
    tg = TouchGrass(api_key="hp_abc", base_url="https://test.local/api/")
    assert tg._base_url == "https://test.local/api"


# -- Error handling -----------------------------------------------------------


def test_401_raises_authentication_error(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(401, {"error": "Bad key"})):
        with pytest.raises(AuthenticationError, match="Bad key"):
            tg.stats()


def test_404_raises_not_found_error(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(404, {"error": "Not found"})):
        with pytest.raises(NotFoundError, match="Not found"):
            tg.tasks.get("nonexistent")


def test_429_raises_rate_limit_error(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(429, {"error": "Slow down"})):
        with pytest.raises(RateLimitError, match="Slow down"):
            tg.tasks.list()


def test_500_raises_touchgrass_error(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(500, {"error": "Internal"})):
        with pytest.raises(TouchGrassError) as exc_info:
            tg.stats()
        assert exc_info.value.status_code == 500


def test_non_json_response_uses_reason_phrase(tg):
    resp = MagicMock()
    resp.status_code = 502
    resp.is_success = False
    resp.reason_phrase = "Bad Gateway"
    resp.json.side_effect = ValueError("Not JSON")
    with patch.object(tg._client, "request", return_value=resp):
        with pytest.raises(TouchGrassError, match="Bad Gateway"):
            tg.stats()


# -- Tasks.list ---------------------------------------------------------------


def test_tasks_list_default_params(tg, mock_response):
    data = {"data": [], "total": 0}
    with patch.object(tg._client, "request", return_value=mock_response(200, data)) as mock:
        result = tg.tasks.list()
        mock.assert_called_once_with(
            "GET",
            "https://test.local/api/bounties",
            params={"limit": 20, "offset": 0, "sort": "newest"},
            json=None,
        )
    assert result == data


def test_tasks_list_with_filters(tg, mock_response):
    data = {"data": [{"id": "1"}], "total": 1}
    with patch.object(tg._client, "request", return_value=mock_response(200, data)) as mock:
        result = tg.tasks.list(status="open", category="digital", q="photo", sort="highest_pay", limit=5, offset=10)
        call_args = mock.call_args
        params = call_args.kwargs["params"]
        assert params["status"] == "open"
        assert params["category"] == "digital"
        assert params["q"] == "photo"
        assert params["sort"] == "highest_pay"
        assert params["limit"] == 5
        assert params["offset"] == 10


# -- Tasks.get ----------------------------------------------------------------


def test_tasks_get(tg, mock_response):
    data = {"id": "abc-123", "title": "Test task"}
    with patch.object(tg._client, "request", return_value=mock_response(200, data)) as mock:
        result = tg.tasks.get("abc-123")
        mock.assert_called_once_with(
            "GET",
            "https://test.local/api/bounties/abc-123",
            params=None,
            json=None,
        )
    assert result["id"] == "abc-123"


# -- Tasks.create -------------------------------------------------------------


def test_tasks_create(tg, mock_response):
    created = {"id": "new-1", "title": "Verify photo"}
    with patch.object(tg._client, "request", return_value=mock_response(200, created)) as mock:
        result = tg.tasks.create(
            title="Verify photo",
            description="Check location",
            category="digital",
            reward_usdc=0.50,
            deadline="2026-04-15T00:00:00Z",
            max_workers=3,
            tx_hash="0xabc",
            contract_bounty_id=42,
        )
        call_args = mock.call_args
        body = call_args.kwargs["json"]
        assert body["title"] == "Verify photo"
        assert body["reward_usdc"] == 0.50
        assert body["tx_hash"] == "0xabc"
        assert body["contract_bounty_id"] == 42
        assert body["max_workers"] == 3


def test_tasks_create_managed_mode(tg, mock_response):
    """managed=True sends managed flag, no tx_hash needed."""
    created = {"id": "managed-1", "is_managed": True}
    with patch.object(tg._client, "request", return_value=mock_response(200, created)) as mock:
        result = tg.tasks.create(
            title="Managed task",
            description="Platform handles escrow",
            reward_usdc=1.00,
            deadline="2026-04-15T00:00:00Z",
            managed=True,
        )
        body = mock.call_args.kwargs["json"]
        assert body["managed"] is True
        assert "tx_hash" not in body
    assert result["is_managed"] is True


def test_tasks_create_without_tx_hash(tg, mock_response):
    """Without managed=True and no tx_hash, managed flag is not sent."""
    created = {"id": "new-2"}
    with patch.object(tg._client, "request", return_value=mock_response(200, created)) as mock:
        result = tg.tasks.create(
            title="Simple task",
            description="Desc",
            reward_usdc=1.00,
            deadline="2026-04-15T00:00:00Z",
        )
        body = mock.call_args.kwargs["json"]
        assert "tx_hash" not in body
        assert "managed" not in body


def test_tasks_create_extra_kwargs(tg, mock_response):
    """Extra kwargs are passed through to the body."""
    with patch.object(tg._client, "request", return_value=mock_response(200, {})) as mock:
        tg.tasks.create(
            title="Task",
            description="Desc",
            reward_usdc=1.0,
            deadline="2026-04-15T00:00:00Z",
            subcategory="photo_verification",
            location_city="Tokyo",
        )
        body = mock.call_args.kwargs["json"]
        assert body["subcategory"] == "photo_verification"
        assert body["location_city"] == "Tokyo"


# -- Tasks.update / cancel ----------------------------------------------------


def test_tasks_update(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {})) as mock:
        tg.tasks.update("abc-123", title="New title", deadline="2026-05-01T00:00:00Z")
        mock.assert_called_once_with(
            "PATCH",
            "https://test.local/api/bounties/abc-123",
            params=None,
            json={"title": "New title", "deadline": "2026-05-01T00:00:00Z"},
        )


def test_tasks_cancel(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {})) as mock:
        tg.tasks.cancel("abc-123", cancel_tx_hash="0xdef")
        mock.assert_called_once_with(
            "DELETE",
            "https://test.local/api/bounties/abc-123",
            params=None,
            json={"cancel_tx_hash": "0xdef"},
        )


def test_tasks_cancel_managed(tg, mock_response):
    """Managed tasks can be cancelled without tx_hash."""
    with patch.object(tg._client, "request", return_value=mock_response(200, {})) as mock:
        tg.tasks.cancel("abc-123")
        mock.assert_called_once_with(
            "DELETE",
            "https://test.local/api/bounties/abc-123",
            params=None,
            json=None,
        )


# -- Tasks.mine ---------------------------------------------------------------


def test_tasks_mine(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {"data": []})) as mock:
        tg.tasks.mine(status="open", limit=5)
        params = mock.call_args.kwargs["params"]
        assert params["status"] == "open"
        assert params["limit"] == 5


# -- Applications -------------------------------------------------------------


def test_list_applications(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {"data": []})) as mock:
        tg.tasks.list_applications("task-1")
        mock.assert_called_once_with(
            "GET",
            "https://test.local/api/bounties/task-1/applications",
            params=None,
            json=None,
        )


def test_accept_application(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {})) as mock:
        tg.tasks.accept_application("app-1")
        mock.assert_called_once_with(
            "PATCH",
            "https://test.local/api/applications/app-1",
            params=None,
            json={"status": "accepted"},
        )


def test_reject_application(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {})) as mock:
        tg.tasks.reject_application("app-1")
        mock.assert_called_once_with(
            "PATCH",
            "https://test.local/api/applications/app-1",
            params=None,
            json={"status": "rejected"},
        )


# -- Submissions --------------------------------------------------------------


def test_list_submissions(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {"data": []})) as mock:
        tg.tasks.list_submissions("task-1")
        mock.assert_called_once_with(
            "GET",
            "https://test.local/api/bounties/task-1/submissions",
            params=None,
            json=None,
        )


def test_approve_submission(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {})) as mock:
        tg.tasks.approve_submission("sub-1", payout_tx_hash="0xpay", comment="Good work")
        body = mock.call_args.kwargs["json"]
        assert body["status"] == "approved"
        assert body["payout_tx_hash"] == "0xpay"
        assert body["reviewer_comment"] == "Good work"


def test_approve_submission_managed(tg, mock_response):
    """Managed tasks can approve without payout_tx_hash."""
    with patch.object(tg._client, "request", return_value=mock_response(200, {})) as mock:
        tg.tasks.approve_submission("sub-1", comment="Looks good")
        body = mock.call_args.kwargs["json"]
        assert body["status"] == "approved"
        assert "payout_tx_hash" not in body
        assert body["reviewer_comment"] == "Looks good"


def test_reject_submission(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {})) as mock:
        tg.tasks.reject_submission("sub-1", comment="Blurry photo")
        body = mock.call_args.kwargs["json"]
        assert body["status"] == "rejected"
        assert body["reviewer_comment"] == "Blurry photo"


def test_reject_submission_no_comment(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {})) as mock:
        tg.tasks.reject_submission("sub-1")
        body = mock.call_args.kwargs["json"]
        assert body["status"] == "rejected"
        assert "reviewer_comment" not in body


# -- Messages -----------------------------------------------------------------


def test_list_messages(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {"data": []})) as mock:
        tg.tasks.list_messages("task-1", limit=10, offset=5)
        params = mock.call_args.kwargs["params"]
        assert params["limit"] == 10
        assert params["offset"] == 5


def test_send_message(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {})) as mock:
        tg.tasks.send_message("task-1", "Hello worker")
        mock.assert_called_once_with(
            "POST",
            "https://test.local/api/bounties/task-1/messages",
            params=None,
            json={"content": "Hello worker"},
        )


# -- Webhooks -----------------------------------------------------------------


def test_webhooks_list(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {"data": []})) as mock:
        tg.webhooks.list()
        mock.assert_called_once_with("GET", "https://test.local/api/webhooks", params=None, json=None)


def test_webhooks_create(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {})) as mock:
        tg.webhooks.create(
            url="https://example.com/hook",
            events=["submission.created", "application.created"],
        )
        body = mock.call_args.kwargs["json"]
        assert body["url"] == "https://example.com/hook"
        assert "submission.created" in body["events"]
        assert "secret" not in body


def test_webhooks_create_with_secret(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {})) as mock:
        tg.webhooks.create(
            url="https://example.com/hook",
            events=["submission.created"],
            secret="my-secret",
        )
        body = mock.call_args.kwargs["json"]
        assert body["secret"] == "my-secret"


def test_webhooks_update(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {})) as mock:
        tg.webhooks.update("wh-1", events=["application.created"])
        mock.assert_called_once_with(
            "PATCH",
            "https://test.local/api/webhooks/wh-1",
            params=None,
            json={"events": ["application.created"]},
        )


def test_webhooks_delete(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {})) as mock:
        tg.webhooks.delete("wh-1")
        mock.assert_called_once_with("DELETE", "https://test.local/api/webhooks/wh-1", params=None, json=None)


def test_webhooks_deliveries(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {"data": []})) as mock:
        tg.webhooks.deliveries("wh-1")
        mock.assert_called_once_with("GET", "https://test.local/api/webhooks/wh-1/deliveries", params=None, json=None)


# -- Top-level methods --------------------------------------------------------


def test_stats(tg, mock_response):
    data = {"data": {"total_users": 100}}
    with patch.object(tg._client, "request", return_value=mock_response(200, data)):
        result = tg.stats()
        assert result["data"]["total_users"] == 100


def test_account(tg, mock_response):
    data = {"id": "agent-1", "agent_name": "TestBot"}
    with patch.object(tg._client, "request", return_value=mock_response(200, data)) as mock:
        result = tg.account()
        mock.assert_called_once_with("GET", "https://test.local/api/agents/me", params=None, json=None)
    assert result["agent_name"] == "TestBot"


def test_analytics(tg, mock_response):
    with patch.object(tg._client, "request", return_value=mock_response(200, {})) as mock:
        tg.analytics()
        mock.assert_called_once_with("GET", "https://test.local/api/agents/me/analytics", params=None, json=None)


# -- Stripe Checkout ----------------------------------------------------------


def test_stripe_checkout(tg, mock_response):
    data = {"checkout_url": "https://checkout.stripe.com/c/pay_xxx"}
    with patch.object(tg._client, "request", return_value=mock_response(200, data)) as mock:
        result = tg.stripe_checkout(
            title="Photo task",
            description="Verify location",
            reward_usdc=5.0,
            deadline="2026-05-01T00:00:00Z",
            max_workers=3,
        )
        body = mock.call_args.kwargs["json"]
        assert body["title"] == "Photo task"
        assert body["reward_usdc"] == 5.0
        assert body["max_workers"] == 3
        assert body["payment_token"] == "usdc"
    assert result["checkout_url"].startswith("https://checkout.stripe.com")


def test_stripe_checkout_wld(tg, mock_response):
    data = {"checkout_url": "https://checkout.stripe.com/c/pay_yyy"}
    with patch.object(tg._client, "request", return_value=mock_response(200, data)) as mock:
        result = tg.stripe_checkout(
            title="WLD task",
            description="Desc",
            reward_usdc=2.0,
            deadline="2026-05-01T00:00:00Z",
            payment_token="wld",
        )
        body = mock.call_args.kwargs["json"]
        assert body["payment_token"] == "wld"
