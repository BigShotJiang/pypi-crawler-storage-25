from setuptools import setup, find_packages
import os

with open(os.path.join(os.path.dirname(__file__), "README_PYPI.md"), "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="hermes-px",
    version="0.0.4",
    description="Secure AI inference proxy library with Tor routing — Drop-in OpenAI SDK replacement",
    long_description=long_description,
    long_description_content_type="text/markdown",
    author="EGen Labs",
    package_dir={"": "src"},
    packages=find_packages(where="src"),
    package_data={
        "hermes": ["base_prompt.pz"],
    },
    install_requires=[
        "requests>=2.31.0,<3.0.0",
        "requests[socks]>=2.31.0,<3.0.0",
        "python-dotenv>=1.0.0,<2.0.0",
    ],
    extras_require={
        "rag": [
            "chromadb>=0.4.0,<1.0.0",
            "watchdog>=3.0.0,<5.0.0",
            "tiktoken>=0.5.0,<1.0.0",
            "sentence-transformers>=2.2.0,<4.0.0",
            "PyMuPDF>=1.23.0,<2.0.0",
            "python-docx>=1.0.0,<2.0.0",
            "Pillow>=10.0.0,<12.0.0",
            "pytesseract>=0.3.10,<1.0.0",
        ],
    },
    python_requires=">=3.8",
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
        "Topic :: Scientific/Engineering :: Artificial Intelligence",
    ],
)
