"""
Hermes Completions Engine
=========================

Houses the Completions and Chat classes that mirror the OpenAI SDK
nesting pattern: `client.chat.completions.create(...)`.

The Completions.create() method:
    1. Injects system schema payloads for upstream compatibility
    2. Appends the global base prompt if configured
    3. Routes the request through the Tor-proxied session
    4. Parses the response into typed ChatCompletion dataclasses
    5. Fires async telemetry (sanitized — no injected payloads logged)
"""

import uuid
import re
from typing import Dict, List, Optional

import requests

from ._logger import get_logger
from .constants import (
    FALLBACK_MODEL,
    DEFAULT_TIMEOUT,
    get_target_url,
    get_system_schema,
)
from .exceptions import (
    HermesConnectionError,
    HermesTimeoutError,
    HermesResponseError,
)
from .models import ChatCompletion, Choice, Message, Usage
from .telemetry import log_event

logger = get_logger("completions")

def _sanitize_payload(text: str) -> str:
    """Sanitizes text to replace upstream provider references with EGen Labs."""
    if not isinstance(text, str):
        return text
        
    if "exceeded your current quota" in text:
        return "The model is currently offline. For more information on this error, read the docs: https://egenlabs.com/docs"
        
    replacements = {
        r"platform\.openai\.com[/\w-]*": "egenlabs.com",
        r"(?i)\bopenai\b": "EGen Labs",
        r"(?i)\bopen ai\b": "EGen Labs",
        r"(?i)\bchatgpt\b": "AXIOM-1",
    }
    for pattern, new_val in replacements.items():
        text = re.sub(pattern, new_val, text)
    return text

class Completions:
    """Handles chat completion requests against the upstream target.

    This class is not instantiated directly. Access it via:
        client.chat.completions.create(...)

    Args:
        session: A pre-configured requests.Session with proxy and headers set.
        base_system_prompt: Optional global system prompt loaded from file.
    """

    def __init__(self, session: requests.Session, base_system_prompt: Optional[str] = None):
        self._session = session
        self._base_system_prompt = base_system_prompt

    def create(
        self,
        messages: List[Dict[str, str]],
        model: Optional[str] = None,
        **kwargs,
    ) -> ChatCompletion:
        """Create a chat completion — mirrors openai.chat.completions.create().

        Args:
            messages: List of message dicts, e.g. [{"role": "user", "content": "Hi"}].
            model: Model identifier string. Structurally accepted but the upstream
                   target determines the actual model used. Stored in the response.
            **kwargs: Additional arguments:
                - timeout (int): Request timeout in seconds. Default: 60.
                - temperature (float): Sampling temperature (absorbed by schema).
                - max_tokens (int): Max tokens (absorbed by schema).

        Returns:
            A ChatCompletion object with .choices, .model, .id attributes.

        Raises:
            HermesConnectionError: If the Tor proxy or upstream is unreachable.
            HermesTimeoutError: If the request exceeds the timeout.
            HermesResponseError: If the upstream returns malformed data.

        Example:
            >>> response = client.chat.completions.create(
            ...     model="OLYMPUS-1",
            ...     messages=[{"role": "user", "content": "Hello!"}]
            ... )
            >>> print(response.choices[0].message.content)
        """
        # Validate input
        if not messages or not isinstance(messages, list):
            raise ValueError("'messages' must be a non-empty list of message dicts.")

        for i, msg in enumerate(messages):
            if not isinstance(msg, dict) or "role" not in msg or "content" not in msg:
                raise ValueError(
                    f"Message at index {i} must be a dict with 'role' and 'content' keys."
                )

        # Build the full message payload with injected system schema
        injected_messages = get_system_schema()

        # Append the global base prompt if configured
        if self._base_system_prompt:
            injected_messages.append(
                {"role": "system", "content": self._base_system_prompt}
            )

        injected_messages.extend(messages)

        payload = {"messages": injected_messages}

        timeout = kwargs.get("timeout", DEFAULT_TIMEOUT)
        model_used = model or FALLBACK_MODEL

        try:
            logger.debug("Routing request payload via Tor bridge...")
            response = self._session.post(
                get_target_url(),
                json=payload,
                timeout=timeout,
            )
            response.raise_for_status()

        except requests.exceptions.ProxyError as e:
            logger.error(f"Proxy connection failed: {type(e).__name__}")
            raise HermesConnectionError(
                "Tor proxy layer failed. Ensure the Tor daemon is running "
                "on the configured port.",
                details={"proxy": self._session.proxies.get("https", "unknown")},
            ) from e

        except requests.exceptions.Timeout as e:
            logger.error(f"Request timed out after {timeout}s")
            raise HermesTimeoutError(
                "Request timed out waiting for upstream response.",
                timeout_seconds=timeout,
            ) from e

        except requests.exceptions.ConnectionError as e:
            logger.error(f"Connection failed: {type(e).__name__}")
            raise HermesConnectionError(
                "Failed to establish connection to the upstream target.",
            ) from e

        except requests.exceptions.HTTPError as e:
            status = getattr(e.response, "status_code", None)
            logger.error(f"HTTP error {status} from upstream")
            raise HermesResponseError(
                "Upstream returned an error response.",
                status_code=status,
            ) from e

        # Parse the response
        try:
            data = response.json()
        except ValueError as e:
            logger.error("Failed to parse upstream response as JSON")
            raise HermesResponseError(
                "Upstream returned non-JSON response (possible WAF interception).",
                status_code=response.status_code,
            ) from e

        # Intercept Proxy Error payloads disguised as 200 OK
        if "error" in data:
            error_data = data["error"]
            err_msg = error_data.get("message", str(error_data)) if isinstance(error_data, dict) else str(error_data)
            sanitized_err = _sanitize_payload(err_msg)
            logger.error(f"Upstream explicit error: {sanitized_err}")
            raise HermesResponseError(
                f"Upstream Error: {sanitized_err}",
                status_code=response.status_code,
            )

        # Extract content from the response
        if "choices" in data and len(data["choices"]) > 0:
            raw_content = (
                data["choices"][0].get("message", {}).get("content", "")
            )
        else:
            # Fallback: stringify the entire response for inspection
            raw_content = str(data)
            logger.warning("Response missing 'choices' key — returning raw data.")
            
        # Sanitize normal payload
        raw_content = _sanitize_payload(raw_content)

        # Build usage stats if available
        usage = None
        if "usage" in data:
            usage = Usage(
                prompt_tokens=data["usage"].get("prompt_tokens", 0),
                completion_tokens=data["usage"].get("completion_tokens", 0),
                total_tokens=data["usage"].get("total_tokens", 0),
            )

        # Fire-and-forget telemetry (original messages only, no injected payloads)
        log_event(model_used, messages, raw_content)

        completion = ChatCompletion(
            id=data.get("id", f"chatcmpl-{uuid.uuid4().hex[:12]}"),
            choices=[Choice(message=Message(content=raw_content))],
            model=model_used,
            usage=usage,
        )

        logger.debug(f"Completion received: {completion.id}")
        return completion


class Chat:
    """Nesting layer matching `client.chat.completions`.

    This exists solely to mirror the OpenAI SDK object structure.
    """

    def __init__(self, session: requests.Session, base_system_prompt: Optional[str] = None):
        self.completions = Completions(
            session=session, base_system_prompt=base_system_prompt
        )
