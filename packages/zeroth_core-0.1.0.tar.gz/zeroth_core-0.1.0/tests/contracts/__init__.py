"""Contract registry tests."""
