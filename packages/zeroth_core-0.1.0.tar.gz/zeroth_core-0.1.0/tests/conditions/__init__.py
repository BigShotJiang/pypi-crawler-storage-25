"""Condition resolution tests."""
