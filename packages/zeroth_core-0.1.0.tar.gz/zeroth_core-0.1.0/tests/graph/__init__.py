"""Graph model tests."""
