"""Tool schemas for Hermes Agent (OpenAI function-calling format)."""

from totalreclaw.agent.extraction import VALID_MEMORY_TYPES

REMEMBER = {
    "name": "totalreclaw_remember",
    "description": (
        "Store a memory in TotalReclaw's encrypted vault. Use this to save important "
        "facts, preferences, decisions, rules (reusable gotchas / conventions), or "
        "context about the user. Memories are E2E encrypted and portable across AI agents."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "text": {
                "type": "string",
                "description": "The memory text to store",
            },
            "type": {
                "type": "string",
                "enum": list(VALID_MEMORY_TYPES),
                "description": (
                    "Memory category. One of: fact, preference, decision, episodic, goal, "
                    "context, summary, rule. Use 'rule' for reusable operational gotchas "
                    '("always X", "never Y"), conventions, and debugging shortcuts the '
                    "user wants to remember for next time. Default: fact."
                ),
            },
            "importance": {
                "type": "number",
                "description": (
                    "Importance score 1-10 (default 8 for explicit remember). Use 8+ for "
                    "content the user explicitly asked to remember. The 1-10 scale maps "
                    "to the on-chain decayScore via /10."
                ),
            },
        },
        "required": ["text"],
    },
}

RECALL = {
    "name": "totalreclaw_recall",
    "description": (
        "Search TotalReclaw's encrypted memory vault. Returns the most relevant "
        "memories matching the query, ranked by BM25 + semantic similarity."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "query": {
                "type": "string",
                "description": "Search query to find relevant memories",
            },
            "top_k": {
                "type": "integer",
                "description": "Maximum results to return (default 8)",
            },
        },
        "required": ["query"],
    },
}

FORGET = {
    "name": "totalreclaw_forget",
    "description": "Delete a specific memory from TotalReclaw by its ID.",
    "parameters": {
        "type": "object",
        "properties": {
            "fact_id": {
                "type": "string",
                "description": "The UUID of the memory to delete",
            },
        },
        "required": ["fact_id"],
    },
}

EXPORT = {
    "name": "totalreclaw_export",
    "description": "Export all memories from TotalReclaw as decrypted plaintext.",
    "parameters": {
        "type": "object",
        "properties": {},
    },
}

STATUS = {
    "name": "totalreclaw_status",
    "description": "Check TotalReclaw billing status, usage, and tier information.",
    "parameters": {
        "type": "object",
        "properties": {},
    },
}

SETUP = {
    "name": "totalreclaw_setup",
    "description": (
        "Configure TotalReclaw with a recovery phrase. If no phrase is provided, "
        "a new one is generated automatically. Run this once to set up the "
        "encrypted memory vault."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "recovery_phrase": {
                "type": "string",
                "description": "BIP-39 recovery phrase (12 or 24 words). If omitted, a new phrase is generated.",
            },
        },
    },
}

PIN = {
    "name": "totalreclaw_pin",
    "description": (
        "Pin a memory so automatic resolution cannot supersede it. Use this "
        "when the user marks a fact as canonical, foundational, or otherwise "
        "protected — e.g. 'always remember my birthday is April 12'. Pinned "
        "claims stay active even when new conflicting facts arrive. "
        "Idempotent: pinning an already-pinned claim is a no-op."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "fact_id": {
                "type": "string",
                "description": "The UUID of the memory to pin.",
            },
            "reason": {
                "type": "string",
                "description": "Optional human-readable reason for pinning (not stored on-chain).",
            },
        },
        "required": ["fact_id"],
    },
}

UNPIN = {
    "name": "totalreclaw_unpin",
    "description": (
        "Unpin a previously-pinned memory so automatic resolution can "
        "supersede it again. Idempotent: unpinning an already-active claim "
        "is a no-op."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "fact_id": {
                "type": "string",
                "description": "The UUID of the memory to unpin.",
            },
        },
        "required": ["fact_id"],
    },
}

IMPORT_FROM = {
    "name": "totalreclaw_import_from",
    "description": (
        "Import memories from other AI tools (Gemini, ChatGPT, Claude, Mem0) into "
        "TotalReclaw's encrypted vault. "
        "WORKFLOW: (1) ALWAYS call with dry_run=true first to show the user the "
        "estimate (conversations found, estimated facts, estimated time). "
        "(2) If the user confirms, and the dry-run shows <=50 chunks: call again "
        "without dry_run to process everything. "
        "(3) If >50 chunks: tell the user this is a large import and you'll process "
        "it in batches. Then use totalreclaw_import_batch repeatedly with increasing "
        "offset, reporting progress after each batch."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "source": {
                "type": "string",
                "enum": ["gemini", "chatgpt", "claude", "mem0", "mcp-memory", "generic-json"],
                "description": "The source system to import from",
            },
            "file_path": {
                "type": "string",
                "description": "Path to the export file on disk (e.g. Gemini Takeout HTML, ChatGPT conversations.json)",
            },
            "content": {
                "type": "string",
                "description": "For file-based sources: the file content (pasted JSON, HTML, CSV)",
            },
            "dry_run": {
                "type": "boolean",
                "description": "Parse and estimate without importing. Shows chunk count and estimated facts. Default: false.",
            },
        },
        "required": ["source"],
    },
}

IMPORT_BATCH = {
    "name": "totalreclaw_import_batch",
    "description": (
        "Process one batch of a large conversation import. Call repeatedly with "
        "increasing offset until the response contains is_complete=true. "
        "After each batch, report progress to the user: "
        "'Batch 3/14 complete — 45 facts stored so far, ~8 minutes remaining.' "
        "The response includes chunks_processed, total_chunks, facts_stored, "
        "and remaining_chunks for progress calculation."
    ),
    "parameters": {
        "type": "object",
        "properties": {
            "source": {
                "type": "string",
                "enum": ["gemini", "chatgpt", "claude", "mem0", "mcp-memory", "generic-json"],
                "description": "The source system to import from (must match the initial import_from call)",
            },
            "file_path": {
                "type": "string",
                "description": "Path to the export file on disk",
            },
            "content": {
                "type": "string",
                "description": "For file-based sources: the file content",
            },
            "offset": {
                "type": "integer",
                "description": "Chunk offset to start processing from (default: 0)",
            },
            "batch_size": {
                "type": "integer",
                "description": "Number of chunks to process in this batch (default: 25)",
            },
        },
        "required": ["source"],
    },
}
