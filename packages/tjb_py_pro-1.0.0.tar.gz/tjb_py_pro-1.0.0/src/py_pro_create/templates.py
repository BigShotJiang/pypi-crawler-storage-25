TEMPLATES = {
    "__init__.py": '''
__version__ = "1.0.0"
__author__ = "Tjb"
''',
    "core.py": '''
class Core:
    """项目核心逻辑类"""
    def __init__(self):
        pass

    def run(self):
        print("项目核心功能执行")
''',
    "utils.py": '''
"""项目通用工具函数"""
def helper():
    return "通用工具函数"
''',
    "gui.py": '''
import tkinter as tk
from tkinter import messagebox

def run_gui():
    """启动图形界面"""
    window = tk.Tk()
    window.title("我的工具")
    window.geometry("400x300")

    def on_click():
        messagebox.showinfo("提示", "功能已执行")

    tk.Button(window, text="执行功能", command=on_click).pack(pady=20)
    window.mainloop()

if __name__ == "__main__":
    run_gui()
''',
    "run_gui.py": '''
from {package_name}.gui import run_gui

if __name__ == "__main__":
    run_gui()
''',
    "build_exe.py": '''
import PyInstaller.__main__

PyInstaller.__main__.run([
    "run_gui.py",
    "--onefile",
    "--windowed",
    "--name={project_name}",
    "--clean"
])
''',
    "pyproject.toml": """
[build-system]
requires = ["setuptools>=61.0"]
build-backend = "setuptools.build_meta"

[project]
name = "{project_name}"
version = "1.0.0"
authors = [{{ "name": "Tjb", "email": "2292643909@qq.com" }}]
description = "自动生成的Python项目"
requires-python = ">=3.8"

[project.scripts]
{script_name} = "{package_name}.gui:run_gui"
""",
    ".gitignore": '''
__pycache__/
*.pyc
*.pyo
*.pyd
.env
.venv/
venv/
dist/
build/
*.spec
*.exe
''',
    "README.md": '''
# {project_name}
这是一个由 `py-pro-create` 自动生成的标准Python项目

## 功能
- 标准src工程结构
- 自带GUI界面
- 支持一键打包EXE
- 可直接发布PyPI

## 运行
```bash
pip install -e .
{script_name}
    '''
}