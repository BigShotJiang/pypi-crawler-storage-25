import argparse
from .generator import create_project

def main():
    # 创建命令行解析器
    parser = argparse.ArgumentParser(
        description="py-pro-create：一键生成标准 Python 项目脚手架"
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    # create 子命令：用来创建项目
    create_parser = subparsers.add_parser("create", help="创建一个新项目")
    create_parser.add_argument("project_name", help="项目名称，例如：my-project")

    # 解析命令并执行
    args = parser.parse_args()

    if args.command == "create":
        create_project(args.project_name)

if __name__ == "__main__":
    main()