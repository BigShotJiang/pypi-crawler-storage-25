import os
from .templates import TEMPLATES

def create_project(project_name: str):
    print(f"🚀 正在创建项目：{project_name}")

    package_name = project_name.replace("-", "_")
    script_name = project_name.lower()

    # 1. 创建文件夹
    base = project_name
    os.makedirs(base, exist_ok=True)
    os.makedirs(f"{base}/src", exist_ok=True)
    os.makedirs(f"{base}/src/{package_name}", exist_ok=True)

    # 2. 定义要生成的所有文件
    files = {
        f"{base}/src/{package_name}/__init__.py": TEMPLATES["__init__.py"],
        f"{base}/src/{package_name}/core.py": TEMPLATES["core.py"],
        f"{base}/src/{package_name}/utils.py": TEMPLATES["utils.py"],
        f"{base}/src/{package_name}/gui.py": TEMPLATES["gui.py"],
        f"{base}/run_gui.py": TEMPLATES["run_gui.py"].format(package_name=package_name),
        f"{base}/build_exe.py": TEMPLATES["build_exe.py"].format(project_name=project_name),
        f"{base}/pyproject.toml": TEMPLATES["pyproject.toml"].format(
            project_name=project_name,
            package_name=package_name,
            script_name=script_name
        ),
        f"{base}/.gitignore": TEMPLATES[".gitignore"],
        f"{base}/README.md": TEMPLATES["README.md"] + "\n```\n'''",
        f"{base}/LICENSE": """MIT License
Copyright (c) 2025 TJB
"""
    }

    # 3. 写入文件
    for path, content in files.items():
        with open(path, "w", encoding="utf-8") as f:
            f.write(content.strip())

    print(f"✅ 项目创建完成：{project_name}")