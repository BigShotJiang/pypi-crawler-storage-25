# py-pro-create
一键生成标准 Python 项目脚手架，自动创建 src 标准工程结构。

## 安装
```bash
pip install py-pro-create