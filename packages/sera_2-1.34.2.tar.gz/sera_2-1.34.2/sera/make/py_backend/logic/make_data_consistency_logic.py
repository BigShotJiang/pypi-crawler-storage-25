from __future__ import annotations

from collections import defaultdict
from itertools import groupby
from typing import Callable, Optional

from codegen.models import (
    AST,
    DeferredVar,
    ImportHelper,
    PredefinedFn,
    Program,
    expr,
    stmt,
)

from sera.make.py_backend.misc import get_python_property_name
from sera.misc import assert_not_null
from sera.models import DataCollection, Package
from sera.models._property import (
    DataProperty,
    ForeignKeyOnDelete,
    ObjectProperty,
    WeakRef,
)
from sera.models._schema import Schema
from sera.typing import GLOBAL_IDENTS


def make_python_data_consistency_logic(
    collection: DataCollection,
    target_pkg: Package,
    schema: Schema,
):
    """Generate a data_consistency.py module for a collection that has weakref properties.

    This generates:
    1. validate_weakrefs_for_<target>() - validates weakref values on create/update of source class
    2. propagate_changes_<target>_to_<source>() - handles cascade/restrict/set_null when target class
       embedded values are removed
    """
    weakref_props = collection.cls.get_weakref_props()
    if len(weakref_props) == 0:
        return

    app = target_pkg.app
    outmod = target_pkg.pkg(collection.get_pymodule_name()).module("data_consistency")

    # Group weakrefs by (target_class, foreign_key_prop)
    # This determines what we validate together
    grouped: dict[str, list[DataProperty]] = defaultdict(list)
    for prop in weakref_props:
        assert prop.weakref is not None
        key = prop.weakref.target_class.name
        grouped[key].append(prop)

    # Build the program using raw Python statements
    program = Program()
    import_helper = ImportHelper(
        program,
        GLOBAL_IDENTS
        | {
            "select": "sqlalchemy.select",
            "delete": "sqlalchemy.delete",
            "update": "sqlalchemy.update",
            "func": "sqlalchemy.func",
            "status_codes": "litestar.status_codes",
            "HTTPException": "litestar.exceptions.HTTPException",
        },
    )
    program.import_("__future__.annotations", True)

    # Import target class models
    target_classes_imported = set()
    for prop in weakref_props:
        assert prop.weakref is not None
        target_cls = prop.weakref.target_class
        if target_cls.name not in target_classes_imported:
            program.import_(
                app.models.db.path
                + f".{target_cls.get_pymodule_name()}.{target_cls.name}",
                True,
            )
            target_classes_imported.add(target_cls.name)

    # Import source class model (for cascade/restrict/set_null functions)
    program.import_(
        app.models.db.path + f".{collection.get_pymodule_name()}.{collection.cls.name}",
        True,
    )

    # Build AST function lambdas using list comprehensions
    validate_funcs = [
        make_validate_weakref_func(props, import_helper) for props in grouped.values()
    ]
    propagate_funcs = [
        make_propagate_changes_func(props, import_helper) for props in grouped.values()
    ]

    program.root(stmt.LineBreak(), *validate_funcs, *propagate_funcs)

    outmod.write(program)


def make_validate_weakref_func(
    props: list[DataProperty],
    import_helper: ImportHelper,
) -> Callable[[AST], Optional[AST]]:
    """Build the validate_weakrefs_for_{target} async function.

    This generated function is used to validate all incoming weak references
    from a source model to a single target model. It queries the target model's
    record based on its primary key and validates that the referenced embedded
    values also exist in the found record.

    Args:
        props: A list of DataProperties on the source class. All properties in
               this list must have a weakref pointing to the *same* target class.
    """
    # ensure that all properties have a weakref pointing to the same target class
    weakrefs = [assert_not_null(p.weakref) for p in props]
    assert len(set(w.target_class.name for w in weakrefs)) == 1

    target_cls = weakrefs[0].target_class
    target_var = target_cls.get_pymodule_name()
    fk_col = get_python_property_name(weakrefs[0].foreign_key_prop)

    params = []
    for p in props:
        params.append(DeferredVar.simple(p.name, expr.ExprIdent("str")))

    func_body: list[Callable[[AST], Optional[AST]] | stmt.Statement] = []

    grouped_props = groupby(
        sorted(props, key=_get_weakref_target_group_key),
        key=_get_weakref_target_group_key,
    )
    for _, prop_iter in grouped_props:
        prop_group = list(prop_iter)
        group_weakref = assert_not_null(prop_group[0].weakref)
        valid_varname = _get_valid_values_var_name(group_weakref)
        func_body.append(
            lambda ast, valid_var=valid_varname, group_weakref=group_weakref: (
                ast.assign(
                    DeferredVar.simple(valid_var),
                    _get_set_of_target_values(
                        group_weakref, expr.ExprIdent(target_var)
                    ),
                )
            )
        )
        valid_value_expr = expr.ExprIdent(valid_varname)

        for p in prop_group:
            condition = PredefinedFn.not_has_item(
                valid_value_expr,
                expr.ExprIdent(p.name),
            )

            func_body.append(
                lambda ast3, p=p, condition=condition, valid_value_expr=valid_value_expr: (
                    ast3.if_(condition)(
                        lambda ast_raise: ast_raise.raise_exception(
                            expr.StandardExceptionExpr(
                                import_helper.use("HTTPException"),
                                [
                                    PredefinedFn.keyword_assignment(
                                        "detail",
                                        expr.ExprRawPython(
                                            f"f\"Invalid {p.name} '{{{p.name}}}'. Valid values: {{{valid_value_expr.to_python()}}}\""
                                        ),
                                    ),
                                    PredefinedFn.keyword_assignment(
                                        "status_code",
                                        PredefinedFn.attr_getter(
                                            import_helper.use("status_codes"),
                                            expr.ExprIdent("HTTP_409_CONFLICT"),
                                        ),
                                    ),
                                ],
                            )
                        ),
                    )
                )
            )
            func_body.append(stmt.LineBreak())

    def create_func(ast: AST):
        return ast.func(
            name=f"validate_weakrefs_for_{target_var}",
            vars=[
                DeferredVar.simple("session", import_helper.use("AsyncSession")),
                DeferredVar.simple(fk_col, expr.ExprIdent("int")),
            ]
            + params,
            return_type=expr.ExprConstant(None),
            is_async=True,
        )(
            # stmt = select(TargetCls).where(TargetCls.id == fk_col).with_for_update()
            lambda ast01: ast01.assign(
                DeferredVar.simple("stmt"),
                expr.ExprMethodCall(
                    expr.ExprMethodCall(
                        expr.ExprFuncCall(
                            import_helper.use("select"),
                            [expr.ExprIdent(target_cls.name)],
                        ),
                        "where",
                        [
                            expr.ExprEqual(
                                PredefinedFn.attr_getter(
                                    expr.ExprIdent(target_cls.name),
                                    expr.ExprIdent("id"),
                                ),
                                expr.ExprIdent(fk_col),
                            )
                        ],
                    ),
                    "with_for_update",
                    [],
                ),
            ),
            # result = await session.execute(stmt)
            lambda ast02: ast02.assign(
                DeferredVar.simple("result"),
                expr.ExprAwait(
                    expr.ExprMethodCall(
                        expr.ExprIdent("session"),
                        "execute",
                        [expr.ExprIdent("stmt")],
                    )
                ),
            ),
            # target_var = result.scalar_one_or_none()
            lambda ast03: ast03.assign(
                DeferredVar.simple(target_var),
                expr.ExprMethodCall(
                    expr.ExprIdent("result"),
                    "scalar_one_or_none",
                    [],
                ),
            ),
            stmt.LineBreak(),
            # if target is None: raise
            lambda ast2: ast2.if_(PredefinedFn.is_null(expr.ExprIdent(target_var)))(
                lambda ast_raise: ast_raise.raise_exception(
                    expr.StandardExceptionExpr(
                        import_helper.use("HTTPException"),
                        [
                            PredefinedFn.keyword_assignment(
                                "detail",
                                expr.ExprRawPython(
                                    f'f"{target_cls.name} with id={{{fk_col}}} not found"'
                                ),
                            ),
                            PredefinedFn.keyword_assignment(
                                "status_code",
                                PredefinedFn.attr_getter(
                                    import_helper.use("status_codes"),
                                    expr.ExprIdent("HTTP_409_CONFLICT"),
                                ),
                            ),
                        ],
                    )
                ),
            ),
            stmt.LineBreak(),
            *func_body,
        )

    return create_func


def make_propagate_changes_func(
    props: list[DataProperty],
    import_helper: ImportHelper,
) -> Callable[[AST], Optional[AST]]:
    """Build a propagate_changes function for a specific action type.

    The generated function takes (session, old_record, new_record) and
    internally extracts the properties it needs to compute diffs.

    Args:
        props: A list of DataProperties on the source class. All properties in
               this list must have a weakref pointing to the *same* target class.
    """
    # ensure that all properties have a weakref pointing to the same target class
    weakrefs = [assert_not_null(p.weakref) for p in props]
    assert len(set(w.target_class.name for w in weakrefs)) == 1

    source_cls = props[0].owner
    source_module_name = source_cls.get_pymodule_name()
    source_cls_name = source_cls.name

    # Determine the target class and its id property
    wr = assert_not_null(props[0].weakref)
    target_cls = wr.target_class
    target_cls_name = target_cls.name
    target_module_name = target_cls.get_pymodule_name()
    target_id_prop = target_cls.get_id_property()
    target_id_prop_name = target_id_prop.name if target_id_prop else "id"
    fk_col = get_python_property_name(wr.foreign_key_prop)

    # Function name: e.g., propagate_changes_accommodation_to_accommodation_room
    func_body: list[Callable[[AST], Optional[AST]] | stmt.Statement] = []

    # For each weakref property, generate the action-specific logic
    for p in props:
        wr = assert_not_null(p.weakref)

        new_var = f"new_{p.name}s"
        removed_var = f"removed_{p.name}s"

        new_values_expr = _get_set_of_target_values(wr, expr.ExprIdent("new_record"))
        removed_values_expr = _get_removed_target_values(
            wr, expr.ExprIdent("old_record"), expr.ExprIdent(new_var)
        )

        # new_{prop}s = {set of new values}
        func_body.append(
            lambda ast, new_var=new_var, new_values_expr=new_values_expr: ast.assign(
                DeferredVar.simple(new_var),
                new_values_expr,
            )
        )
        # removed_{prop}s = {old values not in new set}
        func_body.append(
            lambda ast, removed_var=removed_var, removed_values_expr=removed_values_expr: (
                ast.assign(
                    DeferredVar.simple(removed_var),
                    removed_values_expr,
                )
            )
        )

        func_body.append(stmt.LineBreak())

        action = wr.on_delete
        if action == ForeignKeyOnDelete.CASCADE:
            import_helper.use("delete")
            func_body.append(
                lambda ast, removed_var=removed_var, p=p: ast.if_(
                    expr.ExprIdent(removed_var)
                )(
                    stmt.SingleExprStatement(
                        expr.ExprAwait(
                            expr.ExprMethodCall(
                                expr.ExprIdent("session"),
                                "execute",
                                [
                                    expr.ExprRawPython(
                                        f"delete({source_cls_name}).where({source_cls_name}.{fk_col} == old_record.{target_id_prop_name}, {source_cls_name}.{p.name}.in_({removed_var}))"
                                    )
                                ],
                            )
                        )
                    ),
                )
            )
        elif action == ForeignKeyOnDelete.SET_NULL:
            import_helper.use("update")
            func_body.append(
                lambda ast, removed_var=removed_var, p=p: ast.if_(
                    expr.ExprIdent(removed_var)
                )(
                    stmt.SingleExprStatement(
                        expr.ExprAwait(
                            expr.ExprMethodCall(
                                expr.ExprIdent("session"),
                                "execute",
                                [
                                    expr.ExprRawPython(
                                        f"update({source_cls_name}).where({source_cls_name}.{fk_col} == old_record.{target_id_prop_name}, {source_cls_name}.{p.name}.in_({removed_var})).values({p.name}=None)"
                                    )
                                ],
                            )
                        )
                    ),
                )
            )
        elif action == ForeignKeyOnDelete.RESTRICT:
            import_helper.use("func")
            import_helper.use("select")
            func_body.append(
                lambda ast, removed_var=removed_var, p_name=p.name: ast.if_(
                    expr.ExprIdent(removed_var)
                )(
                    lambda ast_assign: ast_assign.assign(
                        DeferredVar.simple("count"),
                        expr.ExprAwait(
                            expr.ExprMethodCall(
                                expr.ExprIdent("session"),
                                "scalar",
                                [
                                    expr.ExprRawPython(
                                        f"select(func.count()).select_from({source_cls_name}).where({source_cls_name}.{fk_col} == old_record.{target_id_prop_name}, {source_cls_name}.{p_name}.in_({removed_var}))"
                                    )
                                ],
                            )
                        ),
                    ),
                    lambda ast2: ast2.if_(
                        expr.ExprLogicalAnd(
                            [
                                expr.ExprIdent("count"),
                                expr.ExprRawPython("count > 0"),
                            ]
                        )
                    )(
                        lambda ast_raise: ast_raise.raise_exception(
                            expr.StandardExceptionExpr(
                                import_helper.use("HTTPException"),
                                [
                                    PredefinedFn.keyword_assignment(
                                        "detail",
                                        expr.ExprRawPython(
                                            f'f"Cannot remove values {{sorted({removed_var})}}: referenced by {{count}} record(s)"'
                                        ),
                                    ),
                                    PredefinedFn.keyword_assignment(
                                        "status_code",
                                        PredefinedFn.attr_getter(
                                            import_helper.use("status_codes"),
                                            expr.ExprIdent("HTTP_409_CONFLICT"),
                                        ),
                                    ),
                                ],
                            )
                        ),
                    ),
                )
            )

        func_body.append(stmt.LineBreak())

    def create_func(ast: AST):
        return ast.func(
            name=f"propagate_changes_{target_module_name}_to_{source_module_name}",
            vars=[
                DeferredVar.simple("session", import_helper.use("AsyncSession")),
                DeferredVar.simple("old_record", expr.ExprIdent(target_cls_name)),
                DeferredVar.simple("new_record", expr.ExprIdent(target_cls_name)),
            ],
            return_type=expr.ExprConstant(None),
            is_async=True,
        )(*func_body)

    return create_func


def _get_weakref_target_group_key(prop: DataProperty) -> tuple[str, str | None]:
    weakref = assert_not_null(prop.weakref)
    nested_name = (
        weakref.target_nested_prop.name
        if weakref.target_nested_prop is not None
        else None
    )
    return (weakref.target_prop.name, nested_name)


def _get_valid_values_var_name(wr: WeakRef) -> str:
    nested_name = (
        wr.target_nested_prop.name
        if wr.target_nested_prop is not None
        else wr.target_prop.name
    )
    return f"valid_{wr.target_prop.name}_{nested_name}_values"


def _get_set_of_target_values(wr: WeakRef, record: expr.Expr) -> expr.Expr:
    """Build an Expr that evaluates to the set of target values from a record."""
    target_prop = wr.target_prop
    value = PredefinedFn.attr_getter(record, expr.ExprIdent(target_prop.name))
    if isinstance(target_prop, ObjectProperty):
        # it's an object property and we must get the nested property
        target_nested_prop = wr.target_nested_prop
        assert target_nested_prop is not None

        if target_prop.cardinality.is_star_to_many():
            # we need to iterate the collection
            if not target_nested_prop.datatype.is_list:
                return PredefinedFn.map_list_as_set(
                    value,
                    lambda x: PredefinedFn.attr_getter(
                        x, expr.ExprIdent(target_nested_prop.name)
                    ),
                )
            else:
                return PredefinedFn.flatten_map_list_as_set(
                    value,
                    lambda x: PredefinedFn.attr_getter(
                        x, expr.ExprIdent(target_nested_prop.name)
                    ),
                )
        else:
            value = PredefinedFn.attr_getter(
                value, expr.ExprIdent(target_nested_prop.name)
            )
            if not target_nested_prop.datatype.is_list:
                return PredefinedFn.set([value])

    elif not target_prop.datatype.is_list:
        return PredefinedFn.set([value])

    return expr.ExprFuncCall(expr.ExprIdent("set"), [value])


def _get_removed_target_values(
    wr: WeakRef, old_record: expr.Expr, new_set_var: expr.Expr
) -> expr.Expr:
    """Build an Expr for old target values not present in the new set.

    Iterates the old record's target values and filters out those
    that are still in the new set.
    """
    target_prop = wr.target_prop
    value = PredefinedFn.attr_getter(old_record, expr.ExprIdent(target_prop.name))

    if isinstance(target_prop, ObjectProperty):
        target_nested_prop = wr.target_nested_prop
        assert target_nested_prop is not None
        nested_name = target_nested_prop.name

        if target_prop.cardinality.is_star_to_many():
            filter_fn = lambda x: PredefinedFn.not_has_item(  # noqa: E731
                new_set_var,
                PredefinedFn.attr_getter(x, expr.ExprIdent(nested_name)),
            )
            if not target_nested_prop.datatype.is_list:
                value = PredefinedFn.map_list(
                    value,
                    lambda x: PredefinedFn.attr_getter(x, expr.ExprIdent(nested_name)),
                    filter_fn,
                )
            else:
                value = PredefinedFn.flatten_map_list(
                    value,
                    lambda x: PredefinedFn.attr_getter(x, expr.ExprIdent(nested_name)),
                    filter_fn,
                )
        else:
            value = PredefinedFn.attr_getter(value, expr.ExprIdent(nested_name))

            if not target_nested_prop.datatype.is_list:
                value = expr.ExprTernary(
                    PredefinedFn.not_has_item(new_set_var, value),
                    PredefinedFn.list([value]),
                    expr.ExprConstant([]),
                )
            else:
                value = PredefinedFn.map_list(
                    value,
                    func=lambda x: x,
                    filter=lambda x: PredefinedFn.not_has_item(new_set_var, x),
                )
    elif isinstance(target_prop, DataProperty):
        if not target_prop.datatype.is_list:
            value = expr.ExprTernary(
                PredefinedFn.not_has_item(new_set_var, value),
                PredefinedFn.list([value]),
                expr.ExprConstant([]),
            )
        else:
            value = PredefinedFn.map_list(
                value,
                func=lambda x: x,
                filter=lambda x: PredefinedFn.not_has_item(new_set_var, x),
            )
    else:
        raise ValueError(f"Unexpected property type: {type(target_prop)}")

    return value
