# jax2onnx/plugins/flax/linen/group_norm.py

from __future__ import annotations

from typing import Any, Callable, ClassVar, Final, Sequence

import jax.numpy as jnp
from flax import linen as nn
from jax.extend.core import Primitive

from jax2onnx.plugins.flax.nnx import group_norm as nnx_group_norm
from jax2onnx.plugins.flax.test_utils import linen_to_nnx
from jax2onnx.plugins.plugin_system import (
    construct_and_call,
    register_primitive,
    with_requested_dtype,
    with_rng_seed,
)
from jax2onnx.plugins._patching import AssignSpec, MonkeyPatchSpec

EXPECT_GROUP_NORM_PLAIN: Final = nnx_group_norm.EXPECT_GROUP_NORM_PLAIN
EXPECT_GROUP_NORM_TRANSPOSED: Final = nnx_group_norm.EXPECT_GROUP_NORM_TRANSPOSED


def _canonicalize_axes(ndim: int, axes: Sequence[int] | int) -> tuple[int, ...]:
    if isinstance(axes, int):
        axes = (axes,)
    out = []
    for axis in axes:
        axis = int(axis)
        if axis < 0:
            axis += ndim
        out.append(axis)
    return tuple(out)


@register_primitive(
    jaxpr_primitive="linen.group_norm",
    jax_doc="https://flax-linen.readthedocs.io/en/latest/api_reference/flax.linen/layers.html#flax.linen.GroupNorm",
    onnx=[
        {
            "component": "GroupNormalization",
            "doc": "https://onnx.ai/onnx/operators/onnx__GroupNormalization.html",
        }
    ],
    since="0.11.0",
    context="primitives.linen",
    component="group_norm",
    testcases=[
        {
            "testcase": "group_norm_rank4",
            "callable": construct_and_call(
                linen_to_nnx,
                module_cls=nn.GroupNorm,
                input_shape=(1, 7, 7, 64),
                num_groups=8,
                dtype=with_requested_dtype(),
                param_dtype=with_requested_dtype(),
                rngs=with_rng_seed(0),
            ),
            "input_shapes": [(3, 7, 7, 64)],
            "expected_output_shapes": [(3, 7, 7, 64)],
            "run_only_f32_variant": True,
            "post_check_onnx_graph": EXPECT_GROUP_NORM_TRANSPOSED,
        },
        {
            "testcase": "group_norm_rank2",
            "callable": construct_and_call(
                linen_to_nnx,
                module_cls=nn.GroupNorm,
                input_shape=(1, 8),
                num_groups=4,
                dtype=with_requested_dtype(),
                param_dtype=with_requested_dtype(),
                rngs=with_rng_seed(0),
            ),
            "input_shapes": [("B", 8)],
            "expected_output_shapes": [("B", 8)],
            "run_only_f32_variant": True,
            "post_check_onnx_graph": EXPECT_GROUP_NORM_PLAIN,
        },
        {
            "testcase": "group_norm_no_bias_no_scale",
            "callable": construct_and_call(
                linen_to_nnx,
                module_cls=nn.GroupNorm,
                input_shape=(1, 16, 16, 32),
                num_groups=8,
                use_bias=False,
                use_scale=False,
                dtype=with_requested_dtype(),
                param_dtype=with_requested_dtype(),
                rngs=with_rng_seed(0),
            ),
            "input_shapes": [("B", 16, 16, 32)],
            "expected_output_shapes": [("B", 16, 16, 32)],
            "run_only_f32_variant": True,
            "post_check_onnx_graph": EXPECT_GROUP_NORM_TRANSPOSED,
        },
    ],
)
class GroupNormPlugin(nnx_group_norm.GroupNormPlugin):
    """IR-only plugin for flax.linen.GroupNorm → ONNX GroupNormalization."""

    _PRIM: ClassVar[Primitive] = Primitive("linen.group_norm")
    _PRIM.multiple_results = False
    _ABSTRACT_EVAL_BOUND: ClassVar[bool] = False
    _ORIGINAL_CALL: ClassVar[Callable[..., Any] | None] = None

    @classmethod
    def binding_specs(cls) -> list[AssignSpec | MonkeyPatchSpec]:
        return [
            MonkeyPatchSpec(
                target="flax.linen.GroupNorm",
                attr="__call__",
                make_value=lambda orig: cls._make_patch(orig),
                delete_if_missing=False,
            ),
        ]

    @staticmethod
    def _make_patch(orig_fn: Callable[..., Any] | None) -> Callable[..., Any]:
        GroupNormPlugin._ORIGINAL_CALL = orig_fn
        prim = GroupNormPlugin._PRIM

        def call_orig(self: Any, x: Any, *, mask: Any | None = None) -> Any:
            if orig_fn is None:
                raise RuntimeError("flax.linen.GroupNorm.__call__ is not available.")
            return orig_fn(self, x, mask=mask)

        def patched(self: Any, x: Any, *, mask: Any | None = None) -> Any:
            if mask is not None:
                return call_orig(self, x, mask=mask)
            if getattr(self, "axis_name", None) is not None:
                return call_orig(self, x, mask=mask)
            if getattr(self, "axis_index_groups", None) is not None:
                return call_orig(self, x, mask=mask)
            if not getattr(self, "use_fast_variance", True):
                return call_orig(self, x, mask=mask)

            scope = getattr(self, "scope", None)
            if scope is None or not hasattr(scope, "variables"):
                return call_orig(self, x, mask=mask)
            variables = scope.variables()
            params = variables.get("params", {})

            reduction_axes = getattr(self, "reduction_axes", None)
            if reduction_axes is None:
                reduction_axes = list(range(1, x.ndim - 1)) + [-1]
            reduction_axes = _canonicalize_axes(x.ndim, reduction_axes)
            expected_axes = tuple(range(1, x.ndim - 1)) + (x.ndim - 1,)
            if tuple(reduction_axes) != expected_axes:
                return call_orig(self, x, mask=mask)

            channels = x.shape[-1]
            if channels is None:
                return call_orig(self, x, mask=mask)

            num_groups = None
            group_size = getattr(self, "group_size", None)
            configured_groups = getattr(self, "num_groups", None)
            if (group_size is None and configured_groups is None) or (
                group_size is not None and configured_groups is not None
            ):
                return call_orig(self, x, mask=mask)
            if group_size is not None:
                if channels % group_size != 0:
                    return call_orig(self, x, mask=mask)
                num_groups = channels // group_size
            else:
                if configured_groups is None:
                    return call_orig(self, x, mask=mask)
                try:
                    num_groups = int(configured_groups)
                except Exception:
                    return call_orig(self, x, mask=mask)
                if num_groups <= 0 or channels % num_groups != 0:
                    return call_orig(self, x, mask=mask)

            param_dtype = getattr(self, "param_dtype", None) or x.dtype
            if x.dtype != param_dtype:
                x = x.astype(param_dtype)

            if getattr(self, "use_scale", True):
                scale_param = params.get("scale")
                if scale_param is None:
                    return call_orig(self, x, mask=mask)
                scale = jnp.asarray(scale_param, dtype=param_dtype)
            else:
                scale = jnp.ones((channels,), dtype=param_dtype)

            if getattr(self, "use_bias", True):
                bias_param = params.get("bias")
                if bias_param is None:
                    return call_orig(self, x, mask=mask)
                bias = jnp.asarray(bias_param, dtype=param_dtype)
            else:
                bias = jnp.zeros((channels,), dtype=param_dtype)

            if tuple(scale.shape) != (channels,):
                scale = jnp.reshape(scale, (channels,))
            if tuple(bias.shape) != (channels,):
                bias = jnp.reshape(bias, (channels,))

            return prim.bind(
                x,
                scale,
                bias,
                epsilon=float(getattr(self, "epsilon", 1e-5)),
                num_groups=int(num_groups),
                channel_axis=-1,
            )

        return patched


@GroupNormPlugin._PRIM.def_impl
def _impl_group_norm(
    x: Any, scale: Any, bias: Any, *, epsilon: float, num_groups: int, channel_axis: int
) -> Any:
    return nnx_group_norm._impl_group_norm(
        x,
        scale,
        bias,
        epsilon=epsilon,
        num_groups=num_groups,
        channel_axis=channel_axis,
    )
