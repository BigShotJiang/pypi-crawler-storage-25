# jax2onnx/plugins/jax/numpy/copysign.py

from __future__ import annotations

from typing import Any, ClassVar, Final, cast

import jax
from jax import core
from jax.interpreters import batching
import jax.numpy as jnp
import numpy as np
import onnx_ir as ir

from jax2onnx.converter.ir_builder import _dtype_to_ir
from jax2onnx.converter.typing_support import LoweringContextProtocol
from jax2onnx.plugins._ir_shapes import _ensure_value_metadata, _stamp_type_and_shape
from jax2onnx.plugins._patching import AssignSpec, MonkeyPatchSpec
from jax2onnx.plugins._post_check_onnx_graph import expect_graph as EG
from jax2onnx.plugins.jax._autodiff_utils import register_jvp_via_jax_jvp
from jax2onnx.plugins.jax._batching_utils import broadcast_batcher_compat
from jax2onnx.plugins.jax.numpy._common import (
    get_orig_impl,
    jnp_binding_specs,
    make_jnp_primitive,
)
from jax2onnx.plugins.plugin_system import PrimitiveLeafPlugin, register_primitive


_COPYSIGN_PRIM: Final = make_jnp_primitive("jax.numpy.copysign")


def _abstract_eval_via_orig_binary(
    prim: Any,
    func_name: str,
    x: core.AbstractValue,
    y: core.AbstractValue,
) -> core.ShapedArray:
    x_shape = tuple(getattr(x, "shape", ()))
    y_shape = tuple(getattr(y, "shape", ()))
    x_dtype: np.dtype[Any] = np.dtype(getattr(x, "dtype", np.float32))
    y_dtype: np.dtype[Any] = np.dtype(getattr(y, "dtype", np.float32))
    x_spec = jax.ShapeDtypeStruct(x_shape, x_dtype)
    y_spec = jax.ShapeDtypeStruct(y_shape, y_dtype)
    orig = get_orig_impl(prim, func_name)
    out = jax.eval_shape(lambda a, b: orig(a, b), x_spec, y_spec)
    out_shape = tuple(getattr(out, "shape", ()))
    out_dtype = np.dtype(getattr(out, "dtype", x_dtype))
    return core.ShapedArray(out_shape, out_dtype)


def _cast_to_dtype(
    ctx: LoweringContextProtocol,
    val: ir.Value,
    *,
    np_dtype: np.dtype[Any],
    name_hint: str,
) -> ir.Value:
    dtype_enum = _dtype_to_ir(np_dtype, ctx.builder.enable_double_precision)
    if getattr(getattr(val, "type", None), "dtype", None) == dtype_enum:
        return val
    cast_val = cast(
        ir.Value,
        ctx.builder.Cast(
            val,
            to=int(dtype_enum.value),
            _outputs=[ctx.fresh_name(name_hint)],
        ),
    )
    cast_val.type = ir.TensorType(dtype_enum)
    cast_val.shape = getattr(val, "shape", None)
    _ensure_value_metadata(ctx, cast_val)
    return cast_val


def _stamp_shape_like(
    value: ir.Value,
    source: ir.Value,
    fallback_dims: tuple[Any, ...],
) -> None:
    source_shape = getattr(source, "shape", None)
    if source_shape is not None:
        value.shape = source_shape
        return
    _stamp_type_and_shape(value, fallback_dims)


@register_primitive(
    jaxpr_primitive=_COPYSIGN_PRIM.name,
    jax_doc="https://docs.jax.dev/en/latest/_autosummary/jax.numpy.copysign.html",
    onnx=[
        {"component": "Abs", "doc": "https://onnx.ai/onnx/operators/onnx__Abs.html"},
        {"component": "Neg", "doc": "https://onnx.ai/onnx/operators/onnx__Neg.html"},
        {"component": "Less", "doc": "https://onnx.ai/onnx/operators/onnx__Less.html"},
        {
            "component": "Where",
            "doc": "https://onnx.ai/onnx/operators/onnx__Where.html",
        },
    ],
    since="0.12.2",
    context="primitives.jnp",
    component="copysign",
    testcases=[
        {
            "testcase": "jnp_copysign_basic",
            "callable": lambda x, y: jnp.copysign(x, y),
            "input_values": [
                np.array([1.5, -2.0, 3.0], dtype=np.float32),
                np.array([1.0, -1.0, -5.0], dtype=np.float32),
            ],
            "post_check_onnx_graph": EG(
                ["Abs:3 -> Neg:3 -> Where:3"],
                no_unused_inputs=True,
            ),
        },
        {
            "testcase": "jnp_copysign_int_promote",
            "callable": lambda x, y: jnp.copysign(x, y),
            "input_values": [
                np.array([1, -2, 3], dtype=np.int32),
                np.array([1, -1, 1], dtype=np.int32),
            ],
            "expected_output_dtypes": [np.float32],
            "post_check_onnx_graph": EG(
                ["Cast:3 -> Abs:3 -> Neg:3 -> Where:3"],
                no_unused_inputs=True,
            ),
        },
        {
            "testcase": "jnp_copysign_broadcast",
            "callable": lambda x, y: jnp.copysign(x, y),
            "input_shapes": [(2, 1), (1, 3)],
            "expected_output_shapes": [(2, 3)],
            "post_check_onnx_graph": EG(
                ["Abs:2x1 -> Neg:2x1 -> Where:2x3"],
                no_unused_inputs=True,
            ),
        },
        {
            "testcase": "copysign_vmap_batching",
            "callable": lambda x, y: jax.vmap(jnp.copysign)(x, y),
            "input_shapes": [(3, 4), (3, 4)],
        },
    ],
)
class JnpCopysignPlugin(PrimitiveLeafPlugin):
    _PRIM: ClassVar = _COPYSIGN_PRIM
    _FUNC_NAME: ClassVar[str] = "copysign"
    _ABSTRACT_EVAL_BOUND: ClassVar[bool] = False

    @staticmethod
    def abstract_eval(
        x: core.AbstractValue,
        y: core.AbstractValue,
    ) -> core.ShapedArray:
        return _abstract_eval_via_orig_binary(
            JnpCopysignPlugin._PRIM,
            JnpCopysignPlugin._FUNC_NAME,
            x,
            y,
        )

    def lower(self, ctx: LoweringContextProtocol, eqn: core.JaxprEqn) -> None:
        x_var, y_var = eqn.invars
        (out_var,) = eqn.outvars

        x_shape = tuple(getattr(getattr(x_var, "aval", None), "shape", ()))
        y_shape = tuple(getattr(getattr(y_var, "aval", None), "shape", ()))
        out_dtype: np.dtype[Any] = np.dtype(
            getattr(getattr(out_var, "aval", None), "dtype", np.float32)
        )
        x_val = ctx.get_value_for_var(x_var, name_hint=ctx.fresh_name("jnp_copysign_x"))
        prefer_dt: np.dtype[Any] = np.dtype(
            getattr(getattr(x_var, "aval", None), "dtype", np.float32)
        )
        y_val = ctx.get_value_for_var(
            y_var,
            name_hint=ctx.fresh_name("jnp_copysign_y"),
            prefer_np_dtype=prefer_dt,
        )
        out_spec = ctx.get_value_for_var(
            out_var, name_hint=ctx.fresh_name("jnp_copysign_out")
        )

        x_ready = _cast_to_dtype(
            ctx,
            x_val,
            np_dtype=out_dtype,
            name_hint="jnp_copysign_x_cast",
        )
        y_ready = _cast_to_dtype(
            ctx,
            y_val,
            np_dtype=out_dtype,
            name_hint="jnp_copysign_y_cast",
        )

        desired_name = getattr(out_spec, "name", None) or ctx.fresh_name(
            "jnp_copysign_out"
        )
        producer = getattr(out_spec, "producer", None)
        if callable(producer) and producer() is not None:
            desired_name = ctx.fresh_name("jnp_copysign_out")

        abs_x = ctx.builder.Abs(x_ready, _outputs=[ctx.fresh_name("jnp_copysign_abs")])
        abs_x.type = x_ready.type
        _stamp_shape_like(abs_x, x_ready, x_shape)
        _ensure_value_metadata(ctx, abs_x)

        neg_abs_x = ctx.builder.Neg(
            abs_x, _outputs=[ctx.fresh_name("jnp_copysign_neg_abs")]
        )
        neg_abs_x.type = abs_x.type
        _stamp_shape_like(neg_abs_x, abs_x, x_shape)
        _ensure_value_metadata(ctx, neg_abs_x)

        zero = ctx.bind_const_for_var(object(), np.asarray(0, dtype=out_dtype))
        y_negative = ctx.builder.Less(
            y_ready,
            zero,
            _outputs=[ctx.fresh_name("jnp_copysign_y_negative")],
        )
        y_negative.type = ir.TensorType(ir.DataType.BOOL)
        _stamp_shape_like(y_negative, y_ready, y_shape)
        _ensure_value_metadata(ctx, y_negative)

        result = ctx.builder.Where(
            y_negative, neg_abs_x, abs_x, _outputs=[desired_name]
        )
        if getattr(out_spec, "type", None) is not None:
            result.type = out_spec.type
        if getattr(out_spec, "shape", None) is not None:
            result.shape = out_spec.shape
        ctx.bind_value_for_var(out_var, result)

    @classmethod
    def binding_specs(cls) -> list[AssignSpec | MonkeyPatchSpec]:
        specs: list[AssignSpec | MonkeyPatchSpec] = jnp_binding_specs(
            cls._PRIM, cls._FUNC_NAME
        )
        return specs


@JnpCopysignPlugin._PRIM.def_impl
def _copysign_impl(*args: object, **kwargs: object) -> object:
    orig = get_orig_impl(JnpCopysignPlugin._PRIM, JnpCopysignPlugin._FUNC_NAME)
    return orig(*args, **kwargs)


register_jvp_via_jax_jvp(JnpCopysignPlugin._PRIM, _copysign_impl)


def _copysign_batch_rule(
    args: tuple[Any, ...], dims: tuple[Any, ...], **params: Any
) -> tuple[Any, Any]:
    return cast(
        tuple[Any, Any],
        broadcast_batcher_compat(JnpCopysignPlugin._PRIM, args, dims, **params),
    )


batching.primitive_batchers[JnpCopysignPlugin._PRIM] = _copysign_batch_rule
