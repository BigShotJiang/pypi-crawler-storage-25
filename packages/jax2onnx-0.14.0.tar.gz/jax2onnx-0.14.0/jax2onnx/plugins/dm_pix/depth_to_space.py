# jax2onnx/plugins/dm_pix/depth_to_space.py

from __future__ import annotations

from collections.abc import Callable
from types import ModuleType
from typing import Any, ClassVar, Final, TypeAlias, cast

import jax
import jax.numpy as jnp
import numpy as np
import onnx_ir as ir
from jax import core
from jax.extend.core import Primitive
from jax.interpreters import batching
from numpy.typing import ArrayLike

from jax2onnx.converter.typing_support import LoweringContextProtocol
from jax2onnx.plugins._ir_shapes import (
    DimInput,
    _ensure_value_metadata,
    _stamp_type_and_shape,
)
from jax2onnx.plugins._patching import AssignSpec, MonkeyPatchSpec
from jax2onnx.plugins._post_check_onnx_graph import expect_graph as EG
from jax2onnx.plugins.jax.lax._index_utils import _const_i64
from jax2onnx.plugins.plugin_system import PrimitiveLeafPlugin, register_primitive

try:
    import dm_pix as _dm_pix
except Exception:  # pragma: no cover - optional dependency
    pix = cast(ModuleType | None, None)
else:
    pix = cast(ModuleType | None, _dm_pix)


def _make_dm_pix_primitive(name: str) -> Primitive:
    prim = Primitive(name)
    prim.multiple_results = False
    return prim


_DEPTH_TO_SPACE_PRIM: Final = _make_dm_pix_primitive("dm_pix.depth_to_space")


def _check_block_size(block_size: int) -> int:
    bs = int(block_size)
    if bs < 2:
        raise ValueError("dm_pix.depth_to_space requires block_size >= 2")
    return bs


def _depth_to_space_impl(
    inputs: ArrayLike,
    *,
    block_size: int,
) -> jax.Array:
    bs = _check_block_size(block_size)
    x = jnp.asarray(inputs)
    rank = int(x.ndim)

    if rank == 3:
        h, w, c = x.shape
        if isinstance(c, (int, np.integer)) and int(c) % (bs * bs) != 0:
            raise ValueError(
                f"Number of channels {int(c)} must be divisible by block_size ** 2 ({bs * bs})."
            )
        c_out = c // (bs * bs)
        y = jnp.reshape(x, (h, w, bs, bs, c_out))
        y = jnp.transpose(y, (0, 2, 1, 3, 4))
        return jnp.reshape(y, (h * bs, w * bs, c_out))

    if rank == 4:
        n, h, w, c = x.shape
        if isinstance(c, (int, np.integer)) and int(c) % (bs * bs) != 0:
            raise ValueError(
                f"Number of channels {int(c)} must be divisible by block_size ** 2 ({bs * bs})."
            )
        c_out = c // (bs * bs)
        y = jnp.reshape(x, (n, h, w, bs, bs, c_out))
        y = jnp.transpose(y, (0, 1, 3, 2, 4, 5))
        return jnp.reshape(y, (n, h * bs, w * bs, c_out))

    raise ValueError(
        f"dm_pix.depth_to_space expects rank 3 or 4, received rank {rank}."
    )


_TESTCASES: list[dict[str, Any]] = (
    []
    if pix is None
    else [
        {
            "testcase": "depth_to_space_nhwc",
            "callable": lambda x: pix.depth_to_space(x, 2),
            "input_shapes": [(1, 4, 4, 4)],
            "expected_output_shapes": [(1, 8, 8, 1)],
            "run_only_f32_variant": True,
            "post_check_onnx_graph": EG(
                ["Transpose:1x4x4x4 -> DepthToSpace:1x1x8x8 -> Transpose:1x8x8x1"],
                no_unused_inputs=True,
            ),
        }
    ]
)


@register_primitive(
    jaxpr_primitive=_DEPTH_TO_SPACE_PRIM.name,
    jax_doc="https://dm-pix.readthedocs.io/en/latest/api.html#depth-to-space",
    onnx=[
        {
            "component": "DepthToSpace",
            "doc": "https://onnx.ai/onnx/operators/onnx__DepthToSpace.html",
        }
    ],
    since="0.12.0",
    context="primitives.dm_pix",
    component="depth_to_space",
    testcases=_TESTCASES,
)
class DmPixDepthToSpacePlugin(PrimitiveLeafPlugin):
    _PRIM: ClassVar = _DEPTH_TO_SPACE_PRIM
    _FUNC_NAME: ClassVar[str] = "depth_to_space"

    @staticmethod
    def abstract_eval(
        x: core.AbstractValue,
        *,
        block_size: int,
    ) -> core.ShapedArray:
        bs = _check_block_size(block_size)
        spec = jax.ShapeDtypeStruct(getattr(x, "shape", ()), getattr(x, "dtype", None))
        result = jax.eval_shape(
            lambda arr: _depth_to_space_impl(arr, block_size=bs),
            spec,
        )
        return core.ShapedArray(result.shape, result.dtype)

    def lower(self, ctx: LoweringContextProtocol, eqn: core.JaxprEqn) -> None:
        params = dict(getattr(eqn, "params", {}))
        block_size_param = params.get("block_size")
        if block_size_param is None:
            raise KeyError("dm_pix.depth_to_space lowering missing 'block_size'")
        block_size = _check_block_size(int(block_size_param))

        (x_var,) = eqn.invars
        (out_var,) = eqn.outvars

        x_shape: tuple[DimInput, ...] = tuple(getattr(x_var.aval, "shape", ()))
        out_shape: tuple[DimInput, ...] = tuple(getattr(out_var.aval, "shape", ()))
        rank = len(x_shape)
        if rank not in (3, 4):
            raise NotImplementedError(
                f"dm_pix.depth_to_space lowering supports rank 3/4, received rank {rank}"
            )

        builder = ctx.builder

        x_val = ctx.get_value_for_var(
            x_var, name_hint=ctx.fresh_name("depth_to_space_in")
        )
        out_spec = ctx.get_value_for_var(
            out_var, name_hint=ctx.fresh_name("depth_to_space_out")
        )
        x_dtype = getattr(getattr(x_val, "type", None), "dtype", None)

        nhwc4: ir.Value = x_val
        nhwc4_shape: tuple[DimInput, ...]
        if rank == 3:
            unsq_axes = _const_i64(
                ctx,
                np.asarray([0], dtype=np.int64),
                "depth_to_space_unsqueeze_axes",
            )
            nhwc4 = cast(
                ir.Value,
                builder.Unsqueeze(
                    x_val,
                    unsq_axes,
                    _outputs=[ctx.fresh_name("depth_to_space_nhwc4")],
                ),
            )
            if x_dtype is not None:
                nhwc4.type = ir.TensorType(x_dtype)
            nhwc4_shape = (1, *x_shape)
            _stamp_type_and_shape(nhwc4, nhwc4_shape)
            _ensure_value_metadata(ctx, nhwc4)
        else:
            nhwc4_shape = x_shape

        to_nchw = cast(
            ir.Value,
            builder.Transpose(
                nhwc4,
                perm=[0, 3, 1, 2],
                _outputs=[ctx.fresh_name("depth_to_space_to_nchw")],
            ),
        )
        if x_dtype is not None:
            to_nchw.type = ir.TensorType(x_dtype)
        _stamp_type_and_shape(
            to_nchw,
            (
                nhwc4_shape[0],
                nhwc4_shape[3],
                nhwc4_shape[1],
                nhwc4_shape[2],
            ),
        )
        _ensure_value_metadata(ctx, to_nchw)

        d2s_nchw = cast(
            ir.Value,
            builder.DepthToSpace(
                to_nchw,
                blocksize=int(block_size),
                mode="DCR",
                _outputs=[ctx.fresh_name("DepthToSpace")],
            ),
        )
        if x_dtype is not None:
            d2s_nchw.type = ir.TensorType(x_dtype)
        out_nhwc4_shape = out_shape if rank == 4 else (1, *out_shape)
        _stamp_type_and_shape(
            d2s_nchw,
            (
                out_nhwc4_shape[0],
                out_nhwc4_shape[3],
                out_nhwc4_shape[1],
                out_nhwc4_shape[2],
            ),
        )
        _ensure_value_metadata(ctx, d2s_nchw)

        out_nhwc4 = cast(
            ir.Value,
            builder.Transpose(
                d2s_nchw,
                perm=[0, 2, 3, 1],
                _outputs=[ctx.fresh_name("depth_to_space_to_nhwc")],
            ),
        )
        if x_dtype is not None:
            out_nhwc4.type = ir.TensorType(x_dtype)
        _stamp_type_and_shape(out_nhwc4, out_nhwc4_shape)
        _ensure_value_metadata(ctx, out_nhwc4)

        if rank == 3:
            sq_axes = _const_i64(
                ctx,
                np.asarray([0], dtype=np.int64),
                "depth_to_space_squeeze_axes",
            )
            result = cast(
                ir.Value,
                builder.Squeeze(
                    out_nhwc4,
                    sq_axes,
                    _outputs=[
                        getattr(out_spec, "name", None)
                        or ctx.fresh_name("depth_to_space_out_hwc")
                    ],
                ),
            )
        else:
            result = out_nhwc4
            ir.convenience.rename_values(
                result,
                getattr(out_spec, "name", None)
                or getattr(result, "name", None)
                or ctx.fresh_name("depth_to_space_out_nhwc"),
            )

        out_spec_type = getattr(out_spec, "type", None)
        if out_spec_type is not None:
            result.type = out_spec_type
        elif x_dtype is not None:
            result.type = ir.TensorType(x_dtype)
        _stamp_type_and_shape(result, out_shape)
        _ensure_value_metadata(ctx, result)
        ctx.bind_value_for_var(out_var, result)

    @classmethod
    def binding_specs(cls) -> list[AssignSpec | MonkeyPatchSpec]:
        if pix is None:
            return []

        storage_slot = f"__orig_impl__{cls._FUNC_NAME}"

        def _make_value(
            orig: Callable[..., jax.Array] | None,
        ) -> Callable[..., jax.Array]:
            if orig is None:
                raise RuntimeError("Original dm_pix.depth_to_space not found")
            setattr(cls._PRIM, storage_slot, orig)

            def _patched(inputs: ArrayLike, block_size: int) -> jax.Array:
                try:
                    bs = _check_block_size(int(block_size))
                except Exception:
                    return orig(inputs, block_size)
                return cls._PRIM.bind(jnp.asarray(inputs), block_size=bs)

            return _patched

        return [
            AssignSpec(
                target=pix,
                attr=f"{cls._FUNC_NAME}_p",
                value=cls._PRIM,
                delete_if_missing=True,
            ),
            MonkeyPatchSpec(
                target=pix,
                attr=cls._FUNC_NAME,
                make_value=_make_value,
                delete_if_missing=False,
            ),
        ]


@DmPixDepthToSpacePlugin._PRIM.def_impl
def _depth_to_space_prim_impl(inputs: ArrayLike, *, block_size: int) -> jax.Array:
    return _depth_to_space_impl(inputs, block_size=int(block_size))


DmPixDepthToSpacePlugin._PRIM.def_abstract_eval(DmPixDepthToSpacePlugin.abstract_eval)


BatchDim: TypeAlias = int | None


def _depth_to_space_batch_rule(
    batched_args: tuple[jax.Array, ...],
    batch_dims: tuple[BatchDim, ...],
    *,
    block_size: int,
) -> tuple[jax.Array, BatchDim]:
    (inputs,), (bdim,) = batched_args, batch_dims
    if bdim is None:
        out = DmPixDepthToSpacePlugin._PRIM.bind(inputs, block_size=block_size)
        return out, batching.not_mapped

    moved = batching.bdim_at_front(inputs, bdim, inputs.shape[bdim])
    out = jax.vmap(
        lambda x: DmPixDepthToSpacePlugin._PRIM.bind(x, block_size=block_size)
    )(moved)
    return out, 0


batching.primitive_batchers[DmPixDepthToSpacePlugin._PRIM] = _depth_to_space_batch_rule
