# vibe-cli

Web3 trading and data at your fingertips.

## Install

```bash
# pip
pip install vibe-cli

# pipx (isolated)
pipx install vibe-cli

# curl | sh
curl -fsSL https://api.vibe.airforce/api/cli/install.sh | sh
```

## Quick Start

```bash
vibe sync                    # Fetch operations manifest (works without API key)
vibe list-operations         # List all commands
vibe swap-quote --from-token So11111111111111111111111111111111111111112 \
                 --to-token EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v \
                 --amount 1000000
vibe evm-swap-quote --network base --from-asset eth --to-asset usdc --amount 0.1
```

## Auth

No API key required to try — 30 free credits per day.

```bash
vibe auth                    # Paste your API key interactively
# Or set environment variable
export VIBE_API_KEY=pk_xxx:sk_xxx
```

Get your API key at [vibe.airforce/settings/api-keys](https://www.vibe.airforce/settings/api-keys)

## Commands

| Command | Description |
|---------|-------------|
| `vibe sync` | Fetch operations manifest |
| `vibe list-operations` | List available commands |
| `vibe auth` | Authenticate with API key |
| `vibe logout` | Remove saved credentials |
| `vibe swap-quote` | Solana swap quote |
| `vibe swap` | Execute Solana swap |
| `vibe evm-swap-quote` | Base/Ethereum swap quote |
| `vibe evm-swap` | Execute Base/Ethereum swap |
| `vibe defi-discover` | Discover DeFi protocols |
| `vibe defi-quote` | Get DeFi position quote |
| `vibe defi-deposit` | Execute DeFi deposit |
| `vibe bags-launch-token` | Launch token on bags.fm |
| `vibe bags-claim-fees` | Claim bags.fm fees |
| `vibe bags-positions` | View bags.fm positions |
| `vibe data-provider` | Query external data providers |
| `vibe feedback` | Submit feedback |
| `vibe version` | Show CLI version |

## Output Formats

```bash
vibe swap-quote -o table ...   # Human-readable (default)
vibe swap-quote -o json ...    # Structured JSON
vibe swap-quote -o json -f body.data ...  # Extract nested field
vibe swap-quote -o raw ...     # Unformatted JSON
```

## License

MIT
