"""HTTP client for the VIBE Tools Gateway."""

from typing import Any, Optional

import httpx
from rich.console import Console

from vibe_cli.config import get_base_url
from vibe_cli.auth import get_auth_header

console = Console()


class VibeClient:
    """Thin HTTP client for /vibe-tools/* routes."""

    def __init__(self, base_url: Optional[str] = None):
        self.base_url = (base_url or get_base_url()).rstrip("/")

    async def request(
        self,
        method: str,
        path: str,
        json_body: Optional[dict] = None,
        params: Optional[dict] = None,
    ) -> dict:
        """Make an authenticated request to the vibe-tools gateway."""
        url = f"{self.base_url}/api{path}"
        headers = get_auth_header()
        headers["Content-Type"] = "application/json"

        async with httpx.AsyncClient(timeout=30.0) as client:
            response = await client.request(
                method=method,
                url=url,
                headers=headers,
                json=json_body,
                params=params,
            )

        return self._handle_response(response)

    def request_sync(
        self,
        method: str,
        path: str,
        json_body: Optional[dict] = None,
        params: Optional[dict] = None,
    ) -> dict:
        """Synchronous version of request."""
        url = f"{self.base_url}/api{path}"
        headers = get_auth_header()
        headers["Content-Type"] = "application/json"

        with httpx.Client(timeout=30.0) as client:
            response = client.request(
                method=method,
                url=url,
                headers=headers,
                json=json_body,
                params=params,
            )

        return self._handle_response(response)

    @staticmethod
    def _handle_response(response: httpx.Response) -> dict:
        """Parse response and handle errors."""
        try:
            body = response.json()
        except Exception:
            return {"error": {"code": "PARSE_ERROR", "message": response.text}}

        if response.status_code >= 400:
            error = body.get("error", {})
            error.setdefault("code", "UNKNOWN")
            error.setdefault("message", f"HTTP {response.status_code}")
            return {"error": error}

        return body

    # Convenience methods

    def get_operations(self) -> dict:
        return self.request_sync("GET", "/vibe-tools/operations")

    def trial_auth(self) -> dict:
        return self.request_sync("POST", "/vibe-tools/trial-auth")

    def data_provider(self, service_name: str, route: str, payload: Optional[dict] = None) -> dict:
        return self.request_sync("POST", "/vibe-tools/data-provider", {
            "service_name": service_name,
            "route": route,
            "payload": payload,
        })

    def swap_quote(self, input_mint: str, output_mint: str, amount: int, **kwargs) -> dict:
        body = {"input_mint": input_mint, "output_mint": output_mint, "amount": amount, **kwargs}
        return self.request_sync("POST", "/vibe-tools/swap-quote", body)

    def swap(self, input_mint: str, output_mint: str, amount: int, **kwargs) -> dict:
        body = {"input_mint": input_mint, "output_mint": output_mint, "amount": amount, **kwargs}
        return self.request_sync("POST", "/vibe-tools/swap", body)

    def evm_swap_quote(self, network: str, from_asset: str, to_asset: str, amount: str, **kwargs) -> dict:
        body = {"network": network, "from_asset": from_asset, "to_asset": to_asset, "amount": amount, **kwargs}
        return self.request_sync("POST", "/vibe-tools/evm/swap-quote", body)

    def evm_swap(self, network: str, from_asset: str, to_asset: str, amount: str, **kwargs) -> dict:
        body = {"network": network, "from_asset": from_asset, "to_asset": to_asset, "amount": amount, **kwargs}
        return self.request_sync("POST", "/vibe-tools/evm/swap", body)

    def defi_discover(self, network: str = "solana", protocols: Optional[list] = None) -> dict:
        body: dict = {"network": network}
        if protocols:
            body["protocols"] = protocols
        return self.request_sync("POST", "/vibe-tools/defi/discover", body)

    def defi_quote(self, action: str, token: str, amount: str, protocol: str = "marinade", **kwargs) -> dict:
        body = {"action": action, "token": token, "amount": amount, "protocol": protocol, **kwargs}
        return self.request_sync("POST", "/vibe-tools/defi/quote", body)

    def defi_deposit(self, action: str, token: str, amount: str, protocol: str = "marinade", **kwargs) -> dict:
        body = {"action": action, "token": token, "amount": amount, "protocol": protocol, **kwargs}
        return self.request_sync("POST", "/vibe-tools/defi/deposit", body)

    def bags_launch_token(self, name: str, symbol: str, description: str, image_url: str, **kwargs) -> dict:
        body = {"name": name, "symbol": symbol, "description": description, "image_url": image_url, **kwargs}
        return self.request_sync("POST", "/vibe-tools/bags/launch-token", body)

    def bags_claim_fees(self, token_mint: str) -> dict:
        return self.request_sync("POST", "/vibe-tools/bags/claim-fees", {"token_mint": token_mint})

    def bags_positions(self) -> dict:
        return self.request_sync("GET", "/vibe-tools/bags/positions")

    # --- Token Leaderboard (public, no auth needed) ---

    def tokens_list(
        self,
        sort_by: str = "market_cap",
        order: str = "desc",
        limit: int = 50,
        offset: int = 0,
    ) -> dict:
        return self.request_sync(
            "GET", "/public/tokens",
            params={"sort_by": sort_by, "order": order, "limit": limit, "offset": offset},
        )

    def tokens_stats(self) -> dict:
        return self.request_sync("GET", "/public/tokens/stats")

    def tokens_creators(self, limit: int = 20, offset: int = 0) -> dict:
        return self.request_sync(
            "GET", "/public/tokens/creators",
            params={"limit": limit, "offset": offset},
        )

    def tokens_agents(self, sort_by: str = "roi_percent", order: str = "desc", limit: int = 20, offset: int = 0) -> dict:
        return self.request_sync(
            "GET", "/public/tokens/agents",
            params={"sort_by": sort_by, "order": order, "limit": limit, "offset": offset},
        )

    def token_detail(self, mint: str) -> dict:
        return self.request_sync("GET", f"/public/tokens/{mint}")

    # --- Wallet (JWT auth from /api/wallet/*) ---

    def wallet_config(self) -> dict:
        return self.request_sync("GET", "/wallet/config")

    def wallet_address(self, network: str = "base") -> dict:
        return self.request_sync("GET", "/wallet/address", params={"network": network})

    def wallet_balance(self, network: str = "base") -> dict:
        return self.request_sync("GET", "/wallet/balance", params={"network": network})

    def wallet_transactions(self, network: str = "base", limit: int = 50) -> dict:
        return self.request_sync(
            "GET", "/wallet/transactions",
            params={"network": network, "limit": limit},
        )

    def wallet_security_status(self) -> dict:
        return self.request_sync("GET", "/wallet/security-status")

    # --- OpenClaw Gateway (JWT auth from /api/openclaw/*) ---

    def gateway_status(self) -> dict:
        return self.request_sync("GET", "/openclaw/gateway")

    def gateway_start(self, template: str, telegram_config: Optional[dict] = None) -> dict:
        body: dict = {"template": template}
        if telegram_config:
            body["telegram_config"] = telegram_config
        return self.request_sync("POST", "/openclaw/gateway/start", body)

    def gateway_stop(self) -> dict:
        return self.request_sync("POST", "/openclaw/gateway/stop")

    def gateway_templates(self) -> dict:
        return self.request_sync("GET", "/openclaw/templates")

    def gateway_logs(self) -> dict:
        return self.request_sync("GET", "/openclaw/gateway/logs")

    def telegram_config_get(self) -> dict:
        return self.request_sync("GET", "/openclaw/telegram/config")

    def telegram_config_update(self, bot_token: str, enabled: bool = True) -> dict:
        return self.request_sync("PUT", "/openclaw/telegram/config", {
            "bot_token": bot_token,
            "enabled": enabled,
        })
