"""Output formatting for the VIBE CLI."""

import json
from typing import Any, Optional

from rich.console import Console
from rich.table import Table
from rich import print_json

console = Console()


def format_output(
    data: Any,
    output_format: str = "table",
    filter_path: Optional[str] = None,
) -> None:
    """
    Format and print data in the requested format.

    Args:
        data: The data to format
        output_format: One of 'table', 'json', 'raw'
        filter_path: Dot-path to extract from data (e.g. 'body.data')
    """
    # Apply filter path
    if filter_path and isinstance(data, dict):
        data = _extract_path(data, filter_path)

    if output_format == "json":
        if isinstance(data, (dict, list)):
            console.print_json(json.dumps(data, indent=2))
        else:
            console.print_json(json.dumps(data))
    elif output_format == "raw":
        if isinstance(data, (dict, list)):
            console.print(json.dumps(data, indent=2))
        else:
            console.print(str(data))
    else:
        # Table format — auto-detect best rendering
        _print_table(data)


def _extract_path(data: dict, path: str) -> Any:
    """Extract a value from nested dict using dot-path notation."""
    parts = path.split(".")
    current = data
    for part in parts:
        if isinstance(current, dict):
            current = current.get(part)
        elif isinstance(current, list) and part.isdigit():
            idx = int(part)
            current = current[idx] if idx < len(current) else None
        else:
            return None
    return current


def _print_table(data: Any) -> None:
    """Print data as a rich table or fallback to JSON."""
    if isinstance(data, list) and len(data) > 0 and isinstance(data[0], dict):
        # List of dicts → table
        table = Table(show_header=True, header_style="bold cyan")
        columns = list(data[0].keys())
        for col in columns:
            table.add_column(col)
        for row in data:
            table.add_row(*[str(row.get(col, ""))[:80] for col in columns])
        console.print(table)
    elif isinstance(data, dict):
        # Single dict → key-value pairs
        for key, value in data.items():
            if isinstance(value, (dict, list)):
                console.print(f"[bold]{key}:[/bold]")
                console.print_json(json.dumps(value, indent=2))
            else:
                console.print(f"[bold]{key}:[/bold] {value}")
    else:
        console.print(str(data))


def print_error(error: dict) -> None:
    """Print an error response from the gateway."""
    code = error.get("code", "UNKNOWN")
    message = error.get("message", "Unknown error")
    retry_after = error.get("retry_after")
    actions = error.get("actions", [])

    console.print(f"[bold red]{code}[/bold red]: {message}")

    if retry_after:
        console.print(f"[dim]Retry after {retry_after}s[/dim]")

    for action in actions:
        console.print(f"[dim]  → {action}[/dim]")

    # Exit code mapping for agent skill error handling
    import sys
    code_map = {
        "UNAUTHORIZED": 4,
        "FREE_QUOTA_EXHAUSTED": 4,
        "INSUFFICIENT_CREDITS": 4,
        "RATE_LIMITED": 4,
        "FORBIDDEN_SCOPE": 5,
    }
    sys.exit(code_map.get(code, 1))
