"""Configuration management for the VIBE CLI."""

import json
import os
from pathlib import Path
from typing import Optional


CONFIG_DIR = Path.home() / ".config" / "vibe"
CONFIG_FILE = CONFIG_DIR / "config.json"
MANIFEST_CACHE_FILE = CONFIG_DIR / "manifest.json"


def _ensure_config_dir() -> None:
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)


def load_config() -> dict:
    """Load CLI config from disk."""
    if CONFIG_FILE.exists():
        try:
            return json.loads(CONFIG_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_config(config: dict) -> None:
    """Save CLI config to disk."""
    _ensure_config_dir()
    CONFIG_FILE.write_text(json.dumps(config, indent=2))


def get_api_key() -> Optional[str]:
    """Get API key from env var, config, or return None."""
    # 1. Environment variable
    env_key = os.environ.get("VIBE_API_KEY")
    if env_key:
        return env_key

    # 2. Config file
    config = load_config()
    return config.get("api_key")


def get_trial_token() -> Optional[str]:
    """Get cached trial token from config."""
    config = load_config()
    return config.get("trial_token")


def save_trial_token(token: str) -> None:
    """Save trial token to config."""
    config = load_config()
    config["trial_token"] = token
    save_config(config)


def get_base_url() -> str:
    """Get the VIBE API base URL."""
    return os.environ.get("VIBE_API_URL", "https://api.vibe.airforce")


def get_manifest_cache() -> Optional[dict]:
    """Load cached operations manifest."""
    if MANIFEST_CACHE_FILE.exists():
        try:
            return json.loads(MANIFEST_CACHE_FILE.read_text())
        except (json.JSONDecodeError, OSError):
            return None
    return None


def save_manifest_cache(manifest: dict) -> None:
    """Cache the operations manifest."""
    _ensure_config_dir()
    MANIFEST_CACHE_FILE.write_text(json.dumps(manifest, indent=2))
