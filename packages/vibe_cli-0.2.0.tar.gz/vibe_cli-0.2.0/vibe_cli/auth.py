"""Authentication flow for the VIBE CLI."""

from typing import Optional

from rich.console import Console

from vibe_cli.config import load_config, save_config, get_api_key, get_trial_token, save_trial_token

console = Console()


def login(interactive: bool = True) -> Optional[str]:
    """
    Authenticate with the VIBE API.

    If interactive, prompt the user to paste their API key.
    Otherwise, check config and env vars.
    """
    # Check existing key
    existing = get_api_key()
    if existing and not interactive:
        return existing

    if interactive:
        console.print("\n[bold]VIBE Airforce Authentication[/bold]")
        console.print("Get your API key at: [link]https://www.vibe.airforce/settings/api-keys[/link]")
        console.print()
        console.print("Your API key looks like: [dim]pk_xxxxxxxx:sk_xxxxxxxxxxxxxxxx[/dim]")
        console.print()

        api_key = console.input("[bold]Paste your API key:[/bold] ").strip()

        if not api_key or ":" not in api_key:
            console.print("[red]Invalid API key format. Expected: pk_xxx:sk_xxx[/red]")
            return None

        # Save to config
        config = load_config()
        config["api_key"] = api_key
        save_config(config)

        console.print("[green]API key saved![/green] You can now use all VIBE commands.")
        return api_key

    return None


def logout() -> None:
    """Remove saved API key and trial token."""
    config = load_config()
    removed = False
    if "api_key" in config:
        del config["api_key"]
        removed = True
    if "trial_token" in config:
        del config["trial_token"]
        removed = True
    save_config(config)
    if removed:
        console.print("[green]Logged out successfully.[/green]")
    else:
        console.print("[dim]No API key found in config.[/dim]")


def _ensure_trial_token() -> Optional[str]:
    """Get a trial token if no API key is configured. Cache it in config."""
    # Don't request trial if user has an API key
    if get_api_key():
        return None

    # Check for cached trial token
    cached = get_trial_token()
    if cached:
        return cached

    # Request a new trial token
    try:
        import httpx
        from vibe_cli.config import get_base_url
        base_url = get_base_url().rstrip("/")
        resp = httpx.post(f"{base_url}/api/vibe-tools/trial-auth", timeout=10.0)
        if resp.status_code == 200:
            data = resp.json().get("data", {})
            token = data.get("token")
            if token:
                save_trial_token(token)
                return token
    except Exception:
        pass

    return None


def get_auth_header() -> dict:
    """Get Authorization header for API requests.

    Uses API key if configured, otherwise auto-obtains a trial token.
    """
    api_key = get_api_key()
    if api_key:
        return {"Authorization": f"Bearer {api_key}"}

    # Auto-trial: get a free trial token so unauthenticated users can explore
    trial = _ensure_trial_token()
    if trial:
        return {"Authorization": f"Bearer {trial}"}

    return {}
