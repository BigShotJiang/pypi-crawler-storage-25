"""VIBE Airforce CLI — Web3 trading and data at your fingertips.

Usage:
    vibe sync                          Fetch operations manifest
    vibe list-operations               List available commands
    vibe auth                          Authenticate with API key
    vibe <command> [options]           Execute a vibe-tools command

Examples:
    vibe sync
    vibe list-operations | grep swap
    vibe swap-quote --from-token So11111111111111111111111111111111111111112 \
                     --to-token EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v \
                     --amount 1000000
    vibe evm-swap-quote --network base --from-asset eth --to-asset usdc --amount 0.1
"""

import json as _json
from typing import Optional

import typer
from rich.console import Console

from vibe_cli import __version__
from vibe_cli.auth import login, logout as auth_logout, get_auth_header
from vibe_cli.client import VibeClient
from vibe_cli.config import get_api_key, get_base_url
from vibe_cli.operations import sync_manifest, list_operations, execute_operation
from vibe_cli.output import format_output, print_error

console = Console()

app = typer.Typer(
    name="vibe",
    help="VIBE Airforce — Web3 trading and data at your fingertips",
    no_args_is_help=True,
    add_completion=False,
)


@app.callback()
def main_callback(
    version: bool = typer.Option(False, "--version", "-V", help="Show CLI version"),
):
    if version:
        console.print(f"vibe CLI v{__version__}")
        raise typer.Exit()


# ---------------------------------------------------------------------------
# Core commands
# ---------------------------------------------------------------------------

@app.command()
def sync():
    """Fetch the latest operations manifest from the VIBE gateway."""
    console.print("[bold]Syncing operations manifest...[/bold]")
    manifest = sync_manifest()
    console.print(f"[green]Synced {len(manifest)} operations.[/green]")
    console.print("Run [bold]vibe list-operations[/bold] to see available commands.")


@app.command(name="list-operations")
def list_ops(
    filter: Optional[str] = typer.Argument(None, help="Filter operations by keyword"),
):
    """List all available vibe-tools operations."""
    list_operations(filter)


@app.command()
def auth():
    """Authenticate with your VIBE API key."""
    login(interactive=True)


@app.command()
def logout():
    """Remove saved API key."""
    auth_logout()


@app.command()
def install():
    """Update the VIBE CLI to the latest version."""
    console.print("[bold]Checking for updates...[/bold]")
    import subprocess
    subprocess.run(["pip", "install", "--upgrade", "vibe-cli"])


@app.command()
def feedback(
    message: str = typer.Argument(..., help="Your feedback message"),
):
    """Submit feedback about the VIBE CLI."""
    console.print(f"[green]Thank you for your feedback![/green]")
    console.print(f"[dim]Message: {message}[/dim]")


@app.command()
def version():
    """Show the VIBE CLI version."""
    console.print(f"vibe CLI v{__version__}")


@app.command(name="trial-auth")
def trial_auth():
    """Get a free trial token (30 requests/day, read-only)."""
    from vibe_cli.auth import _ensure_trial_token

    token = _ensure_trial_token()
    if token:
        console.print("[green]Trial token obtained![/green]")
        console.print("[dim]30 requests/day, read-only scopes (gateway:read, gateway:data)[/dim]")
        console.print("[dim]Token cached in config. Full access: vibe auth[/dim]")
    else:
        console.print("[red]Failed to get trial token. Check your connection.[/red]")
        raise typer.Exit(1)


# ---------------------------------------------------------------------------
# Route commands — explicit functions for each vibe-tools operation
# ---------------------------------------------------------------------------

def _output_opts():
    """Common output options shared by all route commands."""
    return {
        "output": typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
        "field": typer.Option(None, "-f", "--field", help="Extract nested field (dot-path e.g. 'body.data')"),
    }


# --- Data Provider ---

@app.command(name="data-provider")
def data_provider(
    service: str = typer.Option(..., "--service", help="Provider name (e.g. 'nansen', 'twitter')"),
    route: str = typer.Option(..., "--route", help="Endpoint key (e.g. 'smart_money_netflows')"),
    payload: Optional[str] = typer.Option(None, "--payload", help="JSON payload for the provider"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Query external data providers (Nansen, Twitter, etc.)."""
    params: dict = {"service_name": service, "route": route}
    if payload:
        try:
            params["payload"] = _json.loads(payload)
        except _json.JSONDecodeError:
            console.print("[red]Invalid JSON payload[/red]")
            raise typer.Exit(1)
    execute_operation("POST /vibe-tools/data-provider", params, output, field)


# --- Solana Swap ---

@app.command(name="swap-quote")
def swap_quote(
    from_token: str = typer.Option(..., "--from-token", help="Input token mint address"),
    to_token: str = typer.Option(..., "--to-token", help="Output token mint address"),
    amount: int = typer.Option(..., "--amount", help="Amount in lamports"),
    slippage_bps: Optional[int] = typer.Option(None, "--slippage-bps", help="Slippage in basis points"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Get Solana swap quote (Jupiter, Meteora)."""
    params: dict = {"input_mint": from_token, "output_mint": to_token, "amount": amount}
    if slippage_bps is not None:
        params["slippage_bps"] = slippage_bps
    execute_operation("POST /vibe-tools/swap-quote", params, output, field)


@app.command(name="swap")
def swap(
    from_token: str = typer.Option(..., "--from-token", help="Input token mint address"),
    to_token: str = typer.Option(..., "--to-token", help="Output token mint address"),
    amount: int = typer.Option(..., "--amount", help="Amount in lamports"),
    slippage_bps: Optional[int] = typer.Option(None, "--slippage-bps", help="Slippage in basis points"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Execute Solana swap (returns unsigned transaction)."""
    params: dict = {"input_mint": from_token, "output_mint": to_token, "amount": amount}
    if slippage_bps is not None:
        params["slippage_bps"] = slippage_bps
    execute_operation("POST /vibe-tools/swap", params, output, field)


# --- EVM Swap ---

@app.command(name="evm-swap-quote")
def evm_swap_quote(
    network: str = typer.Option("base", "--network", help="EVM network: 'base' or 'ethereum'"),
    from_asset: str = typer.Option(..., "--from-asset", help="Source asset (e.g. 'eth', 'usdc')"),
    to_asset: str = typer.Option(..., "--to-asset", help="Destination asset"),
    amount: str = typer.Option(..., "--amount", help="Amount in human-readable units (e.g. '0.1')"),
    slippage_pct: Optional[float] = typer.Option(None, "--slippage-pct", help="Max slippage percentage"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Get Base/Ethereum swap quote (0x aggregator)."""
    params: dict = {"network": network, "from_asset": from_asset, "to_asset": to_asset, "amount": amount}
    if slippage_pct is not None:
        params["slippage_pct"] = slippage_pct
    execute_operation("POST /vibe-tools/evm/swap-quote", params, output, field)


@app.command(name="evm-swap")
def evm_swap(
    network: str = typer.Option("base", "--network", help="EVM network: 'base' or 'ethereum'"),
    from_asset: str = typer.Option(..., "--from-asset", help="Source asset"),
    to_asset: str = typer.Option(..., "--to-asset", help="Destination asset"),
    amount: str = typer.Option(..., "--amount", help="Amount in human-readable units"),
    slippage_pct: Optional[float] = typer.Option(None, "--slippage-pct", help="Max slippage percentage"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Execute Base/Ethereum swap (CDP managed wallet)."""
    params: dict = {"network": network, "from_asset": from_asset, "to_asset": to_asset, "amount": amount}
    if slippage_pct is not None:
        params["slippage_pct"] = slippage_pct
    execute_operation("POST /vibe-tools/evm/swap", params, output, field)


# --- DeFi ---

@app.command(name="defi-discover")
def defi_discover(
    network: str = typer.Option("solana", "--network", "-n", help="Network: solana or evm"),
    protocols: Optional[str] = typer.Option(None, "--protocols", help="Comma-separated protocol filter"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Discover available DeFi protocols and positions."""
    params: dict = {"network": network}
    if protocols:
        params["protocols"] = [p.strip() for p in protocols.split(",")]
    execute_operation("POST /vibe-tools/defi/discover", params, output, field)


@app.command(name="defi-quote")
def defi_quote(
    action: str = typer.Option(..., "--action", help="DeFi action: stake, supply, borrow, add_liquidity"),
    token: str = typer.Option(..., "--token", help="Token symbol (e.g. 'SOL', 'USDC')"),
    amount: str = typer.Option(..., "--amount", help="Amount as decimal string"),
    protocol: Optional[str] = typer.Option(None, "--protocol", help="Protocol name"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Get DeFi position quote (stake, lend, LP)."""
    params: dict = {"action": action, "token": token, "amount": amount}
    if protocol:
        params["protocol"] = protocol
    execute_operation("POST /vibe-tools/defi/quote", params, output, field)


@app.command(name="defi-deposit")
def defi_deposit(
    action: str = typer.Option(..., "--action", help="DeFi action: stake, supply, borrow, add_liquidity"),
    token: str = typer.Option(..., "--token", help="Token symbol"),
    amount: str = typer.Option(..., "--amount", help="Amount as decimal string"),
    protocol: Optional[str] = typer.Option(None, "--protocol", help="Protocol name"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Execute DeFi deposit (returns unsigned transaction)."""
    params: dict = {"action": action, "token": token, "amount": amount}
    if protocol:
        params["protocol"] = protocol
    execute_operation("POST /vibe-tools/defi/deposit", params, output, field)


# --- bags.fm ---

@app.command(name="bags-launch-token")
def bags_launch_token(
    name: str = typer.Option(..., "--name", help="Token name"),
    symbol: str = typer.Option(..., "--symbol", help="Token symbol"),
    description: str = typer.Option(..., "--description", help="Token description"),
    image_url: str = typer.Option(..., "--image-url", help="Token image URL (https)"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Launch a token on bags.fm."""
    params: dict = {"name": name, "symbol": symbol, "description": description, "image_url": image_url}
    execute_operation("POST /vibe-tools/bags/launch-token", params, output, field)


@app.command(name="bags-claim-fees")
def bags_claim_fees(
    token_mint: str = typer.Option(..., "--token-mint", help="Token mint address"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Claim bags.fm trading fees."""
    params: dict = {"token_mint": token_mint}
    execute_operation("POST /vibe-tools/bags/claim-fees", params, output, field)


@app.command(name="bags-positions")
def bags_positions(
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """View bags.fm positions and fees."""
    execute_operation("GET /vibe-tools/bags/positions", {}, output, field)


# ---------------------------------------------------------------------------
# Token Leaderboard (public — no auth needed)
# ---------------------------------------------------------------------------

@app.command(name="tokens")
def tokens(
    stats: bool = typer.Option(False, "--stats", help="Show platform-wide stats"),
    creators: bool = typer.Option(False, "--creators", help="Show creator leaderboard"),
    agents: bool = typer.Option(False, "--agents", help="Show agent leaderboard"),
    sort_by: str = typer.Option("market_cap", "--sort", help="Sort field: market_cap, volume_24h, price_change_24h, created_at, fees_claimed"),
    order: str = typer.Option("desc", "--order", help="Sort order: asc or desc"),
    limit: int = typer.Option(50, "--limit", "-n", help="Results per page"),
    offset: int = typer.Option(0, "--offset", help="Pagination offset"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Token leaderboard with market data, stats, creators, and agents."""
    client = VibeClient()
    if stats:
        response = client.tokens_stats()
    elif creators:
        response = client.tokens_creators(limit=limit, offset=offset)
    elif agents:
        response = client.tokens_agents(sort_by=sort_by, order=order, limit=limit, offset=offset)
    else:
        response = client.tokens_list(sort_by=sort_by, order=order, limit=limit, offset=offset)

    if "error" in response:
        print_error(response["error"])
    format_output(response.get("data", response), output, field)


@app.command(name="token-info")
def token_info(
    mint: str = typer.Argument(..., help="Token mint address"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Get detailed info for a specific token by mint address."""
    client = VibeClient()
    response = client.token_detail(mint)
    if "error" in response:
        print_error(response["error"])
    format_output(response.get("data", response), output, field)


# ---------------------------------------------------------------------------
# Wallet (requires JWT auth via 'vibe auth')
# ---------------------------------------------------------------------------

@app.command(name="wallet-config")
def wallet_config(
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Get wallet configuration (network, auto-confirm)."""
    client = VibeClient()
    response = client.wallet_config()
    if "error" in response:
        print_error(response["error"])
    format_output(response.get("data", response), output, field)


@app.command(name="wallet-address")
def wallet_address(
    network: str = typer.Option("base", "--network", "-n", help="Network: base, ethereum, solana"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Get wallet address for a network."""
    client = VibeClient()
    response = client.wallet_address(network=network)
    if "error" in response:
        print_error(response["error"])
    format_output(response.get("data", response), output, field)


@app.command(name="wallet-balance")
def wallet_balance(
    network: str = typer.Option("base", "--network", "-n", help="Network: base, ethereum, solana"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Get wallet token balances."""
    client = VibeClient()
    response = client.wallet_balance(network=network)
    if "error" in response:
        print_error(response["error"])
    format_output(response.get("data", response), output, field)


@app.command(name="wallet-transactions")
def wallet_transactions(
    network: str = typer.Option("base", "--network", "-n", help="Network: base, ethereum, solana"),
    limit: int = typer.Option(50, "--limit", "-n", help="Max transactions to return"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Get wallet transaction history."""
    client = VibeClient()
    response = client.wallet_transactions(network=network, limit=limit)
    if "error" in response:
        print_error(response["error"])
    format_output(response.get("data", response), output, field)


# ---------------------------------------------------------------------------
# OpenClaw Gateway (requires JWT auth via 'vibe auth')
# ---------------------------------------------------------------------------

@app.command(name="gateway-status")
def gateway_status(
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Get OpenClaw gateway status."""
    client = VibeClient()
    response = client.gateway_status()
    if "error" in response:
        print_error(response["error"])
    format_output(response.get("data", response), output, field)


@app.command(name="gateway-start")
def gateway_start(
    template: str = typer.Option(..., "--template", "-t", help="Template: trader, shitcoin-trader, degen, analyst"),
    bot_token: Optional[str] = typer.Option(None, "--bot-token", help="Telegram bot token (optional)"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Start an OpenClaw gateway with a template."""
    client = VibeClient()
    telegram_config = None
    if bot_token:
        telegram_config = {"bot_token": bot_token, "enabled": True}
    response = client.gateway_start(template=template, telegram_config=telegram_config)
    if "error" in response:
        print_error(response["error"])
    format_output(response.get("data", response), output, field)


@app.command(name="gateway-stop")
def gateway_stop(
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Stop the OpenClaw gateway."""
    client = VibeClient()
    response = client.gateway_stop()
    if "error" in response:
        print_error(response["error"])
    format_output(response.get("data", response), output, field)


@app.command(name="gateway-templates")
def gateway_templates(
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """List available OpenClaw gateway templates."""
    client = VibeClient()
    response = client.gateway_templates()
    if "error" in response:
        print_error(response["error"])
    format_output(response.get("data", response), output, field)


@app.command(name="gateway-logs")
def gateway_logs():
    """Stream OpenClaw gateway logs (SSE). Press Ctrl+C to stop."""
    import httpx
    base_url = (get_base_url()).rstrip("/")
    headers = get_auth_header()
    url = f"{base_url}/api/openclaw/gateway/logs"

    try:
        with httpx.Client(timeout=None) as http_client:
            with http_client.stream("GET", url, headers=headers) as resp:
                if resp.status_code >= 400:
                    try:
                        err = resp.json().get("error", {})
                        print_error(err)
                    except Exception:
                        console.print(f"[red]HTTP {resp.status_code}[/red]")
                    raise typer.Exit(1)
                for line in resp.iter_lines():
                    if line.startswith("data:"):
                        console.print(line[5:].strip())
    except KeyboardInterrupt:
        console.print("\n[dim]Log stream stopped.[/dim]")


@app.command(name="telegram-config")
def telegram_config(
    bot_token: Optional[str] = typer.Option(None, "--bot-token", help="Set Telegram bot token"),
    enabled: Optional[bool] = typer.Option(None, "--enabled/--disabled", help="Enable or disable Telegram"),
    output: str = typer.Option("table", "-o", "--output", help="Output format: table, json, raw"),
    field: Optional[str] = typer.Option(None, "-f", "--field", help="Extract nested field"),
):
    """Get or update Telegram config for OpenClaw gateway."""
    client = VibeClient()
    if bot_token is not None or enabled is not None:
        # Update mode: need both bot_token and enabled
        if bot_token is None:
            # Fetch current to get existing bot_token
            current = client.telegram_config_get()
            if "error" in current:
                print_error(current["error"])
            existing = current.get("data", {})
            bot_token = existing.get("bot_token", "")
            if not bot_token:
                console.print("[red]No bot_token set. Provide --bot-token.[/red]")
                raise typer.Exit(1)
        response = client.telegram_config_update(
            bot_token=bot_token,
            enabled=enabled if enabled is not None else True,
        )
    else:
        response = client.telegram_config_get()

    if "error" in response:
        print_error(response["error"])
    format_output(response.get("data", response), output, field)


if __name__ == "__main__":
    app()
