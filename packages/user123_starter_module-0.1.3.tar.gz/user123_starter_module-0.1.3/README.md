# note
This Module is for starters
Who dont know python

here is how you can start it:
# about this module
pip module name: User123-Starter-module
module name: Starter
usage:
    from Starter import * # inports everything inside the module
# example code:
CP.brew_program()
CP.create_buttons("first btn", None)
type this for more commands: commands()
or: cmd()

# greet
Thanks for downloading this module