import tkinter as tk

sp = "  "

class Create_program():
    def __init__(self):
        self.win = None
    def brew_program(self):
        self.win = tk.Tk()
    def create_buttons(self, text, command):
        tk.Button(self.win, text=text, command=command).pack(pady=10)
    def edit_size_title(self, size="300x300", title="starter program"):
        self.win.geometry(size)
        self.win.title(title)
    def Launch_program(self):
        self.win.mainloop()

CP = Create_program()

def commands():
    global sp
    print("CP: ment to create a Tkinter Program")
    print(sp + "brew_program: brews the program")
    print(sp + "create_buttons: creates the buttons for the program")
    print(sp + "edit_size_title: lets you edit the size and title")
    print(sp + "Launch_program: makes it fully workable")
    print("commands, cmd: the command you ran before")

cmd = commands