SECRET_KEY = "test"
URLS_ROUTER = "app.urls.AppRouter"
INSTALLED_PACKAGES = [
    "plain.assets",
    "plain.auth",
    "plain.elements",
    "plain.sessions",
    "plain.postgres",
    "plain.htmx",
    "plain.tailwind",
    "plain.templates",
    "plain.admin",
    "app.users",
]

MIDDLEWARE = [
    "plain.sessions.middleware.SessionMiddleware",
    "plain.admin.AdminMiddleware",
]
AUTH_LOGIN_URL = "login"
