"""
juneja-codebase: A CLI tool to generate academic practical code files
"""

__version__ = "4.1.2"
__author__ = "AJ"
