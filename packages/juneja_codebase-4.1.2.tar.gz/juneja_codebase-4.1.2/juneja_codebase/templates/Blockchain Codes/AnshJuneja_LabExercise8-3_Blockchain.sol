// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract SecureFundTransfer {

    // Deposit Ether
    function deposit() public payable {}

    // Transfer using call (recommended)
    function transferFunds(address payable recipient, uint amount) public {
        require(address(this).balance >= amount, "Insufficient balance");

        (bool success, ) = recipient.call{value: amount}("");
        require(success, "Transfer failed");
    }

    // Check balance
    function getBalance() public view returns (uint) {
        return address(this).balance;
    }
}