#include <iostream>
#include <openssl/sha.h>
#include <iomanip>
using namespace std;

int main() {
    string msg = "Blockchain Developer";
    unsigned char hash[SHA256_DIGEST_LENGTH];

    SHA256(reinterpret_cast<const unsigned char*>(msg.c_str()), msg.size(), hash);

    cout << "Message     : " << msg << endl;
    cout << "SHA256 Hash : ";

    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++)
        cout << hex << setw(2) << setfill('0') << (int)hash[i];

    cout << endl;
    cout << "Decryption  : Not possible (SHA256 is one-way)" << endl;

    return 0;
}

