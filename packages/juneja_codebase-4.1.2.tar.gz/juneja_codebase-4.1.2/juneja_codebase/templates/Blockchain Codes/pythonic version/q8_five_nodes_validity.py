"""
Q8. Create a blockchain having 5 nodes and check its validity.
"""

import hashlib
import time

class Block:
    def __init__(self, index, data, previous_hash):
        self.index         = index
        self.timestamp     = time.time()
        self.data          = data
        self.previous_hash = previous_hash
        self.hash          = self.compute_hash()

    def compute_hash(self):
        block_string = f"{self.index}{self.timestamp}{self.data}{self.previous_hash}"
        return hashlib.sha256(block_string.encode()).hexdigest()


class Blockchain:
    def __init__(self):
        self.chain = []
        # Node 1: Genesis block
        genesis = Block(1, "Genesis Block - Node 1", "0")
        self.chain.append(genesis)

    def add_block(self, data):
        previous_hash = self.chain[-1].hash
        node_number   = len(self.chain) + 1
        new_block     = Block(node_number, data, previous_hash)
        self.chain.append(new_block)

    def is_valid(self):
        """
        Check validity of the blockchain:
        1. Recompute each block's hash and compare
        2. Check each block's previous_hash matches the prior block's hash
        """
        for i in range(1, len(self.chain)):
            current_block  = self.chain[i]
            previous_block = self.chain[i - 1]

            # Check if stored hash equals recomputed hash
            if current_block.hash != current_block.compute_hash():
                print(f"  [INVALID] Node {current_block.index}: Hash has been tampered!")
                return False

            # Check if previous_hash link is correct
            if current_block.previous_hash != previous_block.hash:
                print(f"  [INVALID] Node {current_block.index}: Previous hash link is broken!")
                return False

        return True

    def display_chain(self):
        for block in self.chain:
            print(f"\n  Node {block.index}:")
            print(f"    Data          : {block.data}")
            print(f"    Previous Hash : {block.previous_hash}")
            print(f"    Hash          : {block.hash}")


# ── Main ──────────────────────────────────────────────────────
blockchain = Blockchain()

# Add 4 more blocks to make 5 nodes total
blockchain.add_block("Node 2 - Transaction Data")
blockchain.add_block("Node 3 - Transaction Data")
blockchain.add_block("Node 4 - Transaction Data")
blockchain.add_block("Node 5 - Transaction Data")

print("=" * 64)
print("      Blockchain with 5 Nodes - Validity Check")
print("=" * 64)

# Display the chain
print("\n[ Blockchain Contents ]")
blockchain.display_chain()

# ── Validity Check 1: Valid chain ─────────────────────────────
print("\n" + "=" * 64)
print("[ Validity Check 1: Original blockchain ]")
result = blockchain.is_valid()
print(f"  Blockchain is valid: {result}")

# ── Validity Check 2: Tampered chain ─────────────────────────
print("\n" + "=" * 64)
print("[ Validity Check 2: After tampering with Node 3 ]")
print("  Tampering: Changing Node 3 data to 'HACKED DATA'...")
blockchain.chain[2].data = "HACKED DATA"
# NOTE: hash is NOT recomputed — simulates a real attack attempt
result2 = blockchain.is_valid()
print(f"  Blockchain is valid: {result2}")
