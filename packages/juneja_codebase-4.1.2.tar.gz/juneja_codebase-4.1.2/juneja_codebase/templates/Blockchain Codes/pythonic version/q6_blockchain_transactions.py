"""
Q6. Create a blockchain containing block hash, transaction history, time of creation
"""

import hashlib
import time
import datetime

class Block:
    def __init__(self, index, transactions, previous_hash):
        self.index          = index
        self.time_of_creation = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.transactions   = transactions   # list of transactions
        self.previous_hash  = previous_hash
        self.block_hash     = self.compute_hash()

    def compute_hash(self):
        # Combine all block data to compute hash
        block_content = (
            str(self.index) +
            str(self.time_of_creation) +
            str(self.transactions) +
            str(self.previous_hash)
        )
        return hashlib.sha256(block_content.encode()).hexdigest()

    def display(self):
        print(f"\n  Block Index        : {self.index}")
        print(f"  Time of Creation   : {self.time_of_creation}")
        print(f"  Transaction History:")
        for tx in self.transactions:
            print(f"                       {tx}")
        print(f"  Previous Hash      : {self.previous_hash}")
        print(f"  Block Hash         : {self.block_hash}")
        print("  " + "-" * 62)


class Blockchain:
    def __init__(self):
        self.chain = []
        # Create the Genesis block
        genesis = Block(0, ["Genesis Transaction"], "0")
        self.chain.append(genesis)

    def add_block(self, transactions):
        previous_hash = self.chain[-1].block_hash
        new_block = Block(len(self.chain), transactions, previous_hash)
        self.chain.append(new_block)

    def display_chain(self):
        print("=" * 64)
        print("   Blockchain: Block Hash + Transaction History + Time")
        print("=" * 64)
        for block in self.chain:
            block.display()


# ── Main ──────────────────────────────────────────────────────
blockchain = Blockchain()

# Add blocks with transaction histories
blockchain.add_block([
    "Alice  -> Bob   : 50 BTC",
    "Charlie -> Dave : 30 BTC"
])

blockchain.add_block([
    "Bob    -> Eve   : 20 BTC",
    "Dave   -> Frank : 15 BTC",
    "Grace  -> Henry : 10 BTC"
])

blockchain.add_block([
    "Eve    -> Alice : 5 BTC",
    "Frank  -> Grace : 8 BTC"
])

blockchain.display_chain()
