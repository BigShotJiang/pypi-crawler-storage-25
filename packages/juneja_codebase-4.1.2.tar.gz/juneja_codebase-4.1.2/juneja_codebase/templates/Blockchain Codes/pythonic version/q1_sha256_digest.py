"""
Q1. Using SHA-256, obtain the message digest of string "Blockchain Developer"
"""

import hashlib

message = "Blockchain Developer"

# Encode the string and compute SHA-256 digest
sha256_hash = hashlib.sha256(message.encode())

# Get the message digest in hexadecimal
message_digest = sha256_hash.hexdigest()

print("Message         :", message)
print("SHA-256 Digest  :", message_digest)
