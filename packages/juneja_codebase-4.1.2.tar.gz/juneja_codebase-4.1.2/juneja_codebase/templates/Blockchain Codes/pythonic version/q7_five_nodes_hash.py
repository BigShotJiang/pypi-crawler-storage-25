"""
Q7. Create a blockchain having 5 nodes and print the hash values of each block.
"""

import hashlib
import time

class Block:
    def __init__(self, index, data, previous_hash):
        self.index         = index
        self.timestamp     = time.time()
        self.data          = data
        self.previous_hash = previous_hash
        self.hash          = self.compute_hash()

    def compute_hash(self):
        block_string = f"{self.index}{self.timestamp}{self.data}{self.previous_hash}"
        return hashlib.sha256(block_string.encode()).hexdigest()


class Blockchain:
    def __init__(self):
        self.chain = []
        # Node 1: Genesis block
        genesis = Block(1, "Genesis Block - Node 1", "0")
        self.chain.append(genesis)

    def add_block(self, data):
        previous_hash = self.chain[-1].hash
        node_number   = len(self.chain) + 1
        new_block     = Block(node_number, data, previous_hash)
        self.chain.append(new_block)

    def print_hash_values(self):
        print("=" * 70)
        print("        Blockchain with 5 Nodes - Hash Values of Each Block")
        print("=" * 70)
        for block in self.chain:
            print(f"\n  Node {block.index} (Block {block.index}):")
            print(f"    Data          : {block.data}")
            print(f"    Previous Hash : {block.previous_hash}")
            print(f"    Hash Value    : {block.hash}")
        print()


# ── Main ──────────────────────────────────────────────────────
blockchain = Blockchain()

# Add 4 more blocks to make 5 nodes total
blockchain.add_block("Node 2 - Transaction Data")
blockchain.add_block("Node 3 - Transaction Data")
blockchain.add_block("Node 4 - Transaction Data")
blockchain.add_block("Node 5 - Transaction Data")

blockchain.print_hash_values()
