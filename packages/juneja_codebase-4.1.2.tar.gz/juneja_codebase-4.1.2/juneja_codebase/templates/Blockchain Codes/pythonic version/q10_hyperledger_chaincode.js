'use strict';

/**
 * Q10. Create a simple permissioned blockchain using Hyperledger Fabric
 *
 * This is a Chaincode (Smart Contract) for Hyperledger Fabric written in JavaScript.
 * It implements an Asset Management system on a permissioned blockchain.
 *
 * Features demonstrated:
 *  - Permissioned access (only authorized organizations can perform actions)
 *  - Create, Read, Update, Delete (CRUD) operations on assets
 *  - Asset transfer between owners
 *  - Transaction history retrieval
 *  - World State ledger interaction
 *
 * ── Setup & Run Instructions ───────────────────────────────────────────────
 *
 * Prerequisites:
 *   - Docker & Docker Compose installed
 *   - Node.js >= 14.x installed
 *   - Hyperledger Fabric binaries and samples installed:
 *       curl -sSL https://bit.ly/2ysbOFE | bash -s
 *
 * Step 1: Navigate to the Fabric test network
 *   cd fabric-samples/test-network
 *
 * Step 2: Start the network with a channel
 *   ./network.sh up createChannel -c mychannel -ca
 *
 * Step 3: Deploy this chaincode
 *   ./network.sh deployCC -ccn assetcc -ccp ../chaincode/asset -ccl javascript
 *
 * Step 4: Set environment variables for Org1 (peer admin)
 *   export PATH=${PWD}/../bin:$PATH
 *   export FABRIC_CFG_PATH=$PWD/../config/
 *   export CORE_PEER_TLS_ENABLED=true
 *   export CORE_PEER_LOCALMSPID="Org1MSP"
 *   export CORE_PEER_TLS_ROOTCERT_FILE=${PWD}/organizations/peerOrganizations/org1.example.com/peers/peer0.org1.example.com/tls/ca.crt
 *   export CORE_PEER_MSPCONFIGPATH=${PWD}/organizations/peerOrganizations/org1.example.com/users/Admin@org1.example.com/msp
 *   export CORE_PEER_ADDRESS=localhost:7051
 *
 * Step 5: Invoke chaincode functions
 *
 *   Initialize ledger:
 *     peer chaincode invoke ... -c '{"function":"InitLedger","Args":[]}'
 *
 *   Create an asset:
 *     peer chaincode invoke ... -c '{"function":"CreateAsset","Args":["ASSET1","Laptop","Alice","5000"]}'
 *
 *   Read an asset:
 *     peer chaincode query  ... -c '{"function":"ReadAsset","Args":["ASSET1"]}'
 *
 *   Update an asset:
 *     peer chaincode invoke ... -c '{"function":"UpdateAsset","Args":["ASSET1","Desktop","Alice","4000"]}'
 *
 *   Transfer an asset:
 *     peer chaincode invoke ... -c '{"function":"TransferAsset","Args":["ASSET1","Bob"]}'
 *
 *   Get all assets:
 *     peer chaincode query  ... -c '{"function":"GetAllAssets","Args":[]}'
 *
 *   Get transaction history:
 *     peer chaincode query  ... -c '{"function":"GetAssetHistory","Args":["ASSET1"]}'
 *
 *   Delete an asset:
 *     peer chaincode invoke ... -c '{"function":"DeleteAsset","Args":["ASSET1"]}'
 *
 * Step 6: Shut down the network
 *   ./network.sh down
 *
 * ──────────────────────────────────────────────────────────────────────────
 */

const { Contract } = require('fabric-contract-api');

class AssetContract extends Contract {

    // ── Helper: Check if an asset exists ──────────────────────

    async AssetExists(ctx, assetId) {
        const assetJSON = await ctx.stub.getState(assetId);
        return assetJSON && assetJSON.length > 0;
    }

    // ── Helper: Get caller's MSP ID (Organization) ────────────

    getCallerMSP(ctx) {
        return ctx.clientIdentity.getMSPID();
    }

    // ── Helper: Permissioned access check ────────────────────
    // Only Org1MSP and Org2MSP members are allowed to transact

    checkPermission(ctx) {
        const mspID = this.getCallerMSP(ctx);
        const allowedOrgs = ['Org1MSP', 'Org2MSP'];
        if (!allowedOrgs.includes(mspID)) {
            throw new Error(`Permission denied: Organization '${mspID}' is not authorized.`);
        }
    }

    // ── 1. Initialize the ledger with sample assets ───────────

    async InitLedger(ctx) {
        this.checkPermission(ctx);

        const assets = [
            { assetId: 'ASSET001', name: 'Laptop',     owner: 'Alice', value: 5000 },
            { assetId: 'ASSET002', name: 'Smartphone', owner: 'Bob',   value: 1500 },
            { assetId: 'ASSET003', name: 'Tablet',     owner: 'Carol', value: 800  },
        ];

        for (const asset of assets) {
            asset.docType = 'asset';
            await ctx.stub.putState(asset.assetId, Buffer.from(JSON.stringify(asset)));
            console.log(`Asset ${asset.assetId} initialized on ledger.`);
        }

        console.log('Ledger initialized successfully.');
    }

    // ── 2. Create a new asset ─────────────────────────────────

    async CreateAsset(ctx, assetId, name, owner, value) {
        this.checkPermission(ctx);

        const exists = await this.AssetExists(ctx, assetId);
        if (exists) {
            throw new Error(`Asset '${assetId}' already exists.`);
        }

        const asset = {
            docType  : 'asset',
            assetId  : assetId,
            name     : name,
            owner    : owner,
            value    : parseInt(value),
            createdBy: this.getCallerMSP(ctx),
            createdAt: new Date().toISOString(),
        };

        await ctx.stub.putState(assetId, Buffer.from(JSON.stringify(asset)));
        console.log(`Asset ${assetId} created by ${asset.createdBy}`);
        return JSON.stringify(asset);
    }

    // ── 3. Read an asset ──────────────────────────────────────

    async ReadAsset(ctx, assetId) {
        this.checkPermission(ctx);

        const assetJSON = await ctx.stub.getState(assetId);
        if (!assetJSON || assetJSON.length === 0) {
            throw new Error(`Asset '${assetId}' does not exist.`);
        }

        console.log(`Asset ${assetId} retrieved.`);
        return assetJSON.toString();
    }

    // ── 4. Update an existing asset ───────────────────────────

    async UpdateAsset(ctx, assetId, name, owner, value) {
        this.checkPermission(ctx);

        const exists = await this.AssetExists(ctx, assetId);
        if (!exists) {
            throw new Error(`Asset '${assetId}' does not exist.`);
        }

        const updatedAsset = {
            docType    : 'asset',
            assetId    : assetId,
            name       : name,
            owner      : owner,
            value      : parseInt(value),
            updatedBy  : this.getCallerMSP(ctx),
            updatedAt  : new Date().toISOString(),
        };

        await ctx.stub.putState(assetId, Buffer.from(JSON.stringify(updatedAsset)));
        console.log(`Asset ${assetId} updated by ${updatedAsset.updatedBy}`);
        return JSON.stringify(updatedAsset);
    }

    // ── 5. Transfer an asset to a new owner ───────────────────

    async TransferAsset(ctx, assetId, newOwner) {
        this.checkPermission(ctx);

        const assetJSON = await ctx.stub.getState(assetId);
        if (!assetJSON || assetJSON.length === 0) {
            throw new Error(`Asset '${assetId}' does not exist.`);
        }

        const asset       = JSON.parse(assetJSON.toString());
        const oldOwner    = asset.owner;
        asset.owner       = newOwner;
        asset.transferredBy = this.getCallerMSP(ctx);
        asset.transferredAt = new Date().toISOString();

        await ctx.stub.putState(assetId, Buffer.from(JSON.stringify(asset)));
        console.log(`Asset ${assetId} transferred from '${oldOwner}' to '${newOwner}'`);
        return `Asset '${assetId}' transferred from '${oldOwner}' to '${newOwner}'.`;
    }

    // ── 6. Delete an asset ────────────────────────────────────

    async DeleteAsset(ctx, assetId) {
        this.checkPermission(ctx);

        const exists = await this.AssetExists(ctx, assetId);
        if (!exists) {
            throw new Error(`Asset '${assetId}' does not exist.`);
        }

        await ctx.stub.deleteState(assetId);
        console.log(`Asset ${assetId} deleted by ${this.getCallerMSP(ctx)}`);
        return `Asset '${assetId}' deleted successfully.`;
    }

    // ── 7. Get all assets from the ledger ─────────────────────

    async GetAllAssets(ctx) {
        this.checkPermission(ctx);

        const allResults = [];
        // Range query with empty start/end key retrieves all assets
        const iterator = await ctx.stub.getStateByRange('', '');

        let result = await iterator.next();
        while (!result.done) {
            const strValue = Buffer.from(result.value.value.toString()).toString('utf8');
            let record;
            try {
                record = JSON.parse(strValue);
            } catch (err) {
                record = strValue;
            }
            allResults.push(record);
            result = await iterator.next();
        }

        console.log(`Retrieved ${allResults.length} asset(s) from ledger.`);
        return JSON.stringify(allResults);
    }

    // ── 8. Get full transaction history of an asset ───────────

    async GetAssetHistory(ctx, assetId) {
        this.checkPermission(ctx);

        const historyIterator = await ctx.stub.getHistoryForKey(assetId);
        const history         = [];

        let result = await historyIterator.next();
        while (!result.done) {
            const record = {
                txId      : result.value.txId,
                timestamp : result.value.timestamp,
                isDelete  : result.value.isDelete,
                value     : result.value.value.toString('utf8'),
            };
            history.push(record);
            result = await historyIterator.next();
        }

        console.log(`History for asset '${assetId}': ${history.length} transaction(s).`);
        return JSON.stringify(history);
    }
}

module.exports = AssetContract;
