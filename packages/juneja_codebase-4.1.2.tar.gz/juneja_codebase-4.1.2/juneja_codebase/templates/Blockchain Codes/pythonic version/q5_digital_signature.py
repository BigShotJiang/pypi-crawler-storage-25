"""
Q5. Demonstrate sending of a digitally signed document
"""

import hashlib

# ── RSA helper functions (from scratch) ───────────────────────

def gcd(a, b):
    while b:
        a, b = b, a % b
    return a

def mod_inverse(e, phi):
    original_phi = phi
    x0, x1 = 0, 1
    if phi == 1:
        return 0
    while e > 1:
        q = e // phi
        phi, e = e % phi, phi
        x0, x1 = x1 - q * x0, x0
    if x1 < 0:
        x1 += original_phi
    return x1

def generate_rsa_keys():
    p, q  = 61, 53
    n     = p * q
    phi   = (p - 1) * (q - 1)
    e     = 17
    d     = mod_inverse(e, phi)
    return (e, n), (d, n)   # public_key, private_key

# ── Digital Signature functions ───────────────────────────────

def hash_document(document):
    """Compute SHA-256 digest of the document and return as integer."""
    digest_hex = hashlib.sha256(document.encode()).hexdigest()
    # Use only first 8 hex chars (32-bit int) to keep within RSA key space
    return int(digest_hex[:8], 16)

def sign_document(document, private_key):
    """Sender signs the document hash using private key."""
    d, n = private_key
    doc_hash = hash_document(document)
    doc_hash_mod = doc_hash % n          # ensure hash fits within key space
    signature = pow(doc_hash_mod, d, n)  # signature = hash^d mod n
    return signature

def verify_signature(document, signature, public_key):
    """Receiver verifies the document using the sender's public key."""
    e, n = public_key
    doc_hash = hash_document(document)
    doc_hash_mod = doc_hash % n
    # Decrypt signature using public key
    decrypted_hash = pow(signature, e, n)
    return decrypted_hash == doc_hash_mod

# ── Main ──────────────────────────────────────────────────────

public_key, private_key = generate_rsa_keys()

document = "This is a digitally signed document sent from Alice to Bob."

print("=" * 60)
print("         Digitally Signed Document Demo")
print("=" * 60)
print()
print("[ SENDER - Alice ]")
print(f"  Document        : {document}")
print(f"  Public Key      : {public_key}")
print(f"  Private Key     : {private_key}")

# Alice signs the document
signature = sign_document(document, private_key)
print(f"  Signature       : {signature}")
print()
print("  Alice sends the document + signature to Bob.")

print()
print("[ RECEIVER - Bob ]")
print(f"  Document        : {document}")
print(f"  Signature       : {signature}")

# Bob verifies using Alice's public key
is_valid = verify_signature(document, signature, public_key)

if is_valid:
    print("  Verification    : SUCCESS - Document is authentic and untampered.")
else:
    print("  Verification    : FAILED  - Document may be tampered!")

# ── Demonstrate tampering ─────────────────────────────────────
print()
print("[ TAMPERING DEMO ]")
tampered_document = "This is a TAMPERED document."
print(f"  Tampered Doc    : {tampered_document}")
is_valid_tampered = verify_signature(tampered_document, signature, public_key)

if is_valid_tampered:
    print("  Verification    : SUCCESS")
else:
    print("  Verification    : FAILED  - Tampering detected! Signature is invalid.")
