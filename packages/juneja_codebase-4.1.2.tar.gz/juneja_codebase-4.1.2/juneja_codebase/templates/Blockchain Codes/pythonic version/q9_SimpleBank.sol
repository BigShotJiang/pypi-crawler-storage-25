// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

/**
 * Q9. Implement a Smart Contract using Solidity Programming Language
 *
 * This is a SimpleBank smart contract that demonstrates:
 *  - State variables
 *  - Constructor
 *  - Deposit function (payable)
 *  - Withdraw function
 *  - Balance check
 *  - Events
 *  - Modifiers
 *  - Mappings
 *
 * How to run:
 *  1. Open https://remix.ethereum.org
 *  2. Create a new file → paste this code
 *  3. Go to "Solidity Compiler" tab → Compile
 *  4. Go to "Deploy & Run Transactions" tab → Deploy
 *  5. Use the deployed contract to call deposit(), withdraw(), getBalance()
 */

contract SimpleBank {

    // ── State Variables ────────────────────────────────────────

    address public owner;                          // Owner of the contract
    mapping(address => uint256) private balances;  // Balance of each account

    // ── Events ─────────────────────────────────────────────────

    event Deposited(address indexed account, uint256 amount);
    event Withdrawn(address indexed account, uint256 amount);
    event TransferMade(address indexed from, address indexed to, uint256 amount);

    // ── Modifiers ──────────────────────────────────────────────

    // Only the owner can call certain functions
    modifier onlyOwner() {
        require(msg.sender == owner, "Only the contract owner can call this.");
        _;
    }

    // Ensure the amount is greater than zero
    modifier validAmount(uint256 amount) {
        require(amount > 0, "Amount must be greater than zero.");
        _;
    }

    // Ensure sufficient balance before withdrawal
    modifier hasSufficientBalance(uint256 amount) {
        require(balances[msg.sender] >= amount, "Insufficient balance.");
        _;
    }

    // ── Constructor ────────────────────────────────────────────

    constructor() {
        owner = msg.sender;  // Set deployer as the owner
    }

    // ── Functions ──────────────────────────────────────────────

    /**
     * @dev Deposit Ether into the bank.
     * The function is payable — it accepts Ether sent with the transaction.
     */
    function deposit() public payable validAmount(msg.value) {
        balances[msg.sender] += msg.value;
        emit Deposited(msg.sender, msg.value);
    }

    /**
     * @dev Withdraw a specified amount of Ether from the bank.
     * @param amount The amount (in wei) to withdraw.
     */
    function withdraw(uint256 amount)
        public
        validAmount(amount)
        hasSufficientBalance(amount)
    {
        balances[msg.sender] -= amount;

        // Transfer Ether back to the caller
        (bool success, ) = payable(msg.sender).call{value: amount}("");
        require(success, "Transfer failed.");

        emit Withdrawn(msg.sender, amount);
    }

    /**
     * @dev Transfer Ether from caller's account to another account.
     * @param to    Recipient's address.
     * @param amount Amount (in wei) to transfer.
     */
    function transfer(address to, uint256 amount)
        public
        validAmount(amount)
        hasSufficientBalance(amount)
    {
        require(to != address(0), "Cannot transfer to zero address.");
        require(to != msg.sender,  "Cannot transfer to yourself.");

        balances[msg.sender] -= amount;
        balances[to]         += amount;

        emit TransferMade(msg.sender, to, amount);
    }

    /**
     * @dev Get balance of the calling account.
     * @return Balance in wei.
     */
    function getBalance() public view returns (uint256) {
        return balances[msg.sender];
    }

    /**
     * @dev Get balance of any account. (Owner only)
     * @param account Address to check.
     * @return Balance in wei.
     */
    function getBalanceOf(address account) public view onlyOwner returns (uint256) {
        return balances[account];
    }

    /**
     * @dev Get the total Ether held by this contract.
     * @return Contract's total Ether balance in wei.
     */
    function getContractBalance() public view onlyOwner returns (uint256) {
        return address(this).balance;
    }

    /**
     * @dev Fallback function — accepts plain Ether transfers.
     */
    receive() external payable {
        balances[msg.sender] += msg.value;
        emit Deposited(msg.sender, msg.value);
    }
}
