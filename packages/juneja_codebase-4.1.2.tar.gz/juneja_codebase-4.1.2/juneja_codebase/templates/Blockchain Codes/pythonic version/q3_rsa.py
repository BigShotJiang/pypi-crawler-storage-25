"""
Q3. Implement RSA Cryptographic Algorithm
"""

# # RSA Implementation from scratch (no external crypto libraries)

# def gcd(a, b):
#     while b:
#         a, b = b, a % b
#     return a

# def mod_inverse(e, phi):
#     # Extended Euclidean Algorithm to find modular inverse
#     original_phi = phi
#     x0, x1 = 0, 1
#     if phi == 1:
#         return 0
#     while e > 1:
#         q = e // phi
#         phi, e = e % phi, phi
#         x0, x1 = x1 - q * x0, x0
#     if x1 < 0:
#         x1 += original_phi
#     return x1

# def is_prime(n):
#     if n < 2:
#         return False
#     for i in range(2, int(n**0.5) + 1):
#         if n % i == 0:
#             return False
#     return True

# def generate_keys():
#     # Two prime numbers p and q
#     p = 61
#     q = 53

#     n = p * q                  # n = 3233
#     phi = (p - 1) * (q - 1)   # phi = 3120

#     # Choose e such that 1 < e < phi and gcd(e, phi) = 1
#     e = 17
#     while gcd(e, phi) != 1:
#         e += 2

#     # Compute d such that d*e ≡ 1 (mod phi)
#     d = mod_inverse(e, phi)

#     public_key  = (e, n)
#     private_key = (d, n)
#     return public_key, private_key

# def encrypt(message, public_key):
#     e, n = public_key
#     # Convert each character to its ASCII value, then apply RSA: c = m^e mod n
#     encrypted = [pow(ord(char), e, n) for char in message]
#     return encrypted

# def decrypt(encrypted, private_key):
#     d, n = private_key
#     # Reverse RSA: m = c^d mod n, then convert back to character
#     decrypted = ''.join([chr(pow(char, d, n)) for char in encrypted])
#     return decrypted

# # ── Main ──────────────────────────────────────────────────────
# public_key, private_key = generate_keys()

# print("RSA Key Generation")
# print("  Public Key  (e, n) :", public_key)
# print("  Private Key (d, n) :", private_key)
# print()

# message = "Hello World"
# print("Original Message   :", message)

# # Encrypt
# encrypted = encrypt(message, public_key)
# print("Encrypted          :", encrypted)

# # Decrypt
# decrypted = decrypt(encrypted, private_key)
# print("Decrypted Message  :", decrypted)

from Crypto.PublicKey import RSA
from Crypto.Cipher import PKCS1_OAEP

# Generate keys
key = RSA.generate(2048)
public_key = key.publickey()

# Encrypt
message = "Hello RSA"
cipher = PKCS1_OAEP.new(public_key)
encrypted = cipher.encrypt(message.encode())

print("Encrypted:", encrypted)

# Decrypt
cipher_dec = PKCS1_OAEP.new(key)
decrypted = cipher_dec.decrypt(encrypted)

print("Decrypted:", decrypted.decode())