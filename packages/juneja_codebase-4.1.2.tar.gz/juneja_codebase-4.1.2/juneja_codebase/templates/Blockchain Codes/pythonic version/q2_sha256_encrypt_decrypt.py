"""
Q2. Write a program to encrypt and decrypt the message "Hello World" using SHA256.

Note: SHA-256 is a cryptographic hash function, not a symmetric cipher.
It is used here to derive an encryption key (via XOR stream cipher),
which is a standard academic approach to demonstrate SHA-256 in encryption.
"""

import hashlib

def encrypt(message, key):
    # Generate SHA-256 hash of the key
    key_hash = hashlib.sha256(key.encode()).digest()  # 32 bytes
    message_bytes = message.encode()
    # XOR each byte of the message with the key hash (cyclic)
    encrypted = bytes([message_bytes[i] ^ key_hash[i % len(key_hash)]
                       for i in range(len(message_bytes))])
    return encrypted

def decrypt(encrypted_bytes, key):
    # Generate SHA-256 hash of the key
    key_hash = hashlib.sha256(key.encode()).digest()  # 32 bytes
    # XOR again with same key to reverse encryption
    decrypted = bytes([encrypted_bytes[i] ^ key_hash[i % len(key_hash)]
                       for i in range(len(encrypted_bytes))])
    return decrypted.decode()

# ── Main ──────────────────────────────────────────────────────
message = "Hello World"
key     = "secretkey"

print("Original Message   :", message)

# Encrypt
encrypted = encrypt(message, key)
print("Encrypted (hex)    :", encrypted.hex())

# Decrypt
decrypted = decrypt(encrypted, key)
print("Decrypted Message  :", decrypted)
