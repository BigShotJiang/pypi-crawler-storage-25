#include <iostream>
#include <openssl/sha.h>
#include <iomanip>
#include <string>
#include <sstream>

using namespace std;

string getSHA256(string input) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    SHA256(reinterpret_cast<const unsigned char*>(input.c_str()), input.size(), hash);

    stringstream ss;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        ss << hex << setw(2) << setfill('0') << (int)hash[i];
    }

    return ss.str();
}

int main() {
    string str1 = "Hello World";
    string str2 = "Hello world";

    cout << "String 1: " << str1 << endl;
    cout << "Hash 1 : " << getSHA256(str1) << endl;

    cout << "\nString 2: " << str2 << endl;
    cout << "Hash 2 : " << getSHA256(str2) << endl;

    return 0;
}