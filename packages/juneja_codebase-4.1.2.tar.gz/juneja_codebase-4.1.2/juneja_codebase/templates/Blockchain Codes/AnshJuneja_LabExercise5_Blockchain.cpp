#include <iostream>
#include <cmath>
#include <iomanip>
using namespace std;

long long power(long long base, long long exp, long long mod) {
    long long res = 1;
    base = base % mod;
    while (exp > 0) {
        if (exp % 2 == 1) res = (res * base) % mod;
        base = (base * base) % mod;
        exp = exp / 2;
    }
    return res;
}

int findPrivate_d(int e, int phi) {
    for (int d = 1; d < phi; d++) {
        if ((e * d) % phi == 1)
            return d;
    }
    return 0;
}
int main() {
    int p = 17; 
    int q = 11;
    int n = p * q;             
    int phi = (p - 1) * (q - 1); // Euler's Totient Function
    
    // Given Public Exponent (e)
    int e = 11; 
    
    // Find Private Key (d)
    int d = findPrivate_d(e, phi);
    
    // Original Message (Transaction Data)
    int M = 123;
    
    // --- RSA Encryption ---
    long long C = power(M, e, n); // Formula: C = (M^e) % n
    
    // --- RSA Decryption ---
    long long decrypted_M = power(C, d, n); // Formula: Decrypted_M = (C^d) % n

    cout << "--- RSA Implementation ---" << endl;
    cout << "p: " << p << " | q: " << q << endl;
    cout << "Public Modulus (n)    : " << n << endl;
    cout << "Euler's Totient (phi) : " << phi << endl;
    cout << "Public Key (e)        : " << e << endl;
    cout << "Private Key (d)       : " << d << endl;
    cout << "----------------" << endl;
    cout << "Original Message (M)     : " << M << endl;
    cout << "Encrypted Ciphertext (C) : " << C << endl;
    cout << "Decrypted Message        : " << decrypted_M << endl;
    
    if (M == decrypted_M) {
        cout << "\nVerification complete! Original message recovered." << endl;
    } else {
        cout << "\nDecryption failed." << endl;
    }
    return 0;
}
