// SPDX-License-Identifier: MIT
pragma solidity ^0.8.0;

contract StudentStorage {

    string public name;
    uint public age;

    // Set student details
    function setStudent(string memory _name, uint _age) public {
        name = _name;
        age = _age;
    }

    // Get student details
    function getStudent() public view returns (string memory, uint) {
        return (name, age);
    }
}