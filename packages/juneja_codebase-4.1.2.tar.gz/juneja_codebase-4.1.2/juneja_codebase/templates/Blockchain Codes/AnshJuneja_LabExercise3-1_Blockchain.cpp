#include <iostream>
#include <openssl/sha.h>
#include <iomanip>
#include <string>
#include <sstream>
using namespace std;

string getSHA256(string input) {
    unsigned char hash[SHA256_DIGEST_LENGTH];
    
    SHA256(reinterpret_cast<const unsigned char*>(input.c_str()), input.size(), hash);

    stringstream ss;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        ss << hex << setw(2) << setfill('0') << (int)hash[i];
    }
    return ss.str();
}
int main() {
    string userInput;
    cout << " SHA-256 HASH GENERATOR " << endl;
    
    cout << "Enter text to hash: ";
    getline(cin, userInput); // Allows spaces in input

    string result = getSHA256(userInput);

    cout << "\nInput String : " << userInput << endl;
    cout << "Message Digest: " << result << endl;
    return 0;
}
