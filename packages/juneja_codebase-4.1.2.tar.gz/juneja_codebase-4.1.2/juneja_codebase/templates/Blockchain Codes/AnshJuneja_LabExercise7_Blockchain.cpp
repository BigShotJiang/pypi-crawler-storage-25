#include <iostream>
#include <vector>
#include <ctime>
#include <sstream>
#include <iomanip>
#include <openssl/sha.h>

using namespace std;

/* ==========================================
   SHA-256 Hash Function
========================================== */
string sha256(const string &input) {
    unsigned char hash[SHA256_DIGEST_LENGTH];

    SHA256(
        (unsigned char*)input.c_str(),
        input.size(),
        hash
    );

    stringstream ss;

    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        ss << hex << setw(2) << setfill('0') << (int)hash[i];
    }

    return ss.str();
}

/* ==========================================
   Block Class
========================================== */
class Block {
public:
    int index;
    string data;
    string previousHash;
    string hash;
    long timestamp;

    // Constructor
    Block(int idx, string d, string prevHash) {
        index = idx;
        data = d;
        previousHash = prevHash;
        timestamp = time(0);
        hash = calculateHash();
    }

    // Hash calculation
    string calculateHash() const {
        string input = to_string(index) + data + previousHash + to_string(timestamp);
        return sha256(input);
    }
};

/* ==========================================
   Blockchain Class
========================================== */
class Blockchain {
public:
    vector<Block> chain;

    // Constructor
    Blockchain() {
        chain.push_back(createGenesisBlock());
    }

    // Genesis block
    Block createGenesisBlock() {
        return Block(0, "Genesis Block (Mayank)", "0");
    }

    // Get latest block
    Block getLatestBlock() {
        return chain.back();
    }

    // Add new block
    void addBlock(string data) {
        Block newBlock(chain.size(), data, getLatestBlock().hash);
        chain.push_back(newBlock);
    }

    // Print blockchain
    void printChain() {
        for (auto &block : chain) {
            cout << "\nBlock " << block.index << endl;
            cout << "Data           : " << block.data << endl;
            cout << "Previous Hash  : " << block.previousHash << endl;
            cout << "Hash           : " << block.hash << endl;
            cout << "--------------------------------------\n";
        }
    }

    // Validate blockchain
    bool isChainValid() {
        for (int i = 1; i < chain.size(); i++) {
            Block &current = chain[i];
            Block &previous = chain[i - 1];

            // Check current hash
            if (current.hash != current.calculateHash())
                return false;

            // Check chain linking
            if (current.previousHash != previous.hash)
                return false;
        }
        return true;
    }
};

/* ==========================================
   Main Function
========================================== */
int main() {

    cout << "===== Blockchain Practical by Mayank =====\n";

    Blockchain myChain;

    // Adding blocks
    myChain.addBlock("A -> B");
    myChain.addBlock("B -> C");
    myChain.addBlock("C -> D");
    myChain.addBlock("D -> E");
    myChain.addBlock("E -> F");

    cout << "\n===== Original Blockchain =====\n";
    myChain.printChain();

    // Validate chain
    cout << "\nIs Blockchain Valid? : "
         << (myChain.isChainValid() ? "YES" : "NO") << endl;

    return 0;
}