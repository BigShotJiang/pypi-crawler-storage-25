#include <iostream>
#include <vector>
#include <ctime>
#include <string>
using namespace std;

class Block {
public:
    int index;
    string transactions;
    string prevHash;
    string currentHash;
    time_t timeCreated;

    Block(int idx, string tx, string lastHash) {
        index = idx;
        transactions = tx;
        prevHash = lastHash;
        timeCreated = time(0);
        currentHash = generateHash();
    }

    string generateHash() {
        // We combine all data into one string to "sign" it
        string toHash = to_string(index) + transactions + prevHash + to_string(timeCreated);
        
        hash<string> hasher; 
        return to_string(hasher(toHash));
    }
};

// Manages the list of blocks
class Blockchain {
public:
    vector<Block> ledger;

    Blockchain() {
        // Create the first "Genesis" block manually
        ledger.push_back(Block(0, "Initial Block", "0"));
    }

    void addTransaction(string data) {
        // Get the hash of the very last block in our ledger
        string lastBlockHash = ledger.back().currentHash;
        
        // Create a new block linked to the last one
        ledger.push_back(Block(ledger.size(), data, lastBlockHash));
    }

    void displayChain() {
        for (const auto& b : ledger) {
            cout << "--- Block #" << b.index << " ---" << endl;
            cout << "Time: " << b.timeCreated << endl;
            cout << "Data: " << b.transactions << endl;
            cout << "Prev: " << b.prevHash << endl;
            cout << "Hash: " << b.currentHash << endl << endl;
        }
    }
};

int main() {
    Blockchain bitCoin;

    bitCoin.addTransaction("I have 40 bit coin");
    bitCoin.addTransaction("Aman have 30 bicoin");

    bitCoin.displayChain();
    return 0;
}