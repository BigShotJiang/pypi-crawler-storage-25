#include <iostream>
#include <openssl/sha.h>
#include <iomanip>
#include <string>
#include <sstream>

using namespace std;

int main() {
    string input = "Hello World";
    unsigned char hash[SHA256_DIGEST_LENGTH];

    // Generating the hash
    SHA256(reinterpret_cast<const unsigned char*>(input.c_str()), input.size(), hash);

    stringstream ss;
    for (int i = 0; i < SHA256_DIGEST_LENGTH; i++) {
        ss << hex << setw(2) << setfill('0') << (int)hash[i];
    }

    cout << "Input  : " << input << endl;
    cout << "SHA-256: " << ss.str() << endl;

    return 0;
}
