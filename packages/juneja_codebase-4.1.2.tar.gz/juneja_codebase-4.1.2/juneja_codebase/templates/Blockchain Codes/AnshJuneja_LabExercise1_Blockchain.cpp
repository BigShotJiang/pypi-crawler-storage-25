#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <openssl/evp.h>
#include <openssl/rsa.h>
#include <openssl/pem.h>
#include <openssl/err.h>

void printHex(const unsigned char* data, size_t len) {
    for (size_t i = 0; i < len; ++i) {
        std::printf("%02x", data[i]);
        if ((i + 1) % 32 == 0) std::printf("\n"); 
    }
    std::printf("\n");
}

int main() {
    std::string document = "This is a confidential document for verification.";
    unsigned char* signature = nullptr;
    size_t sig_len = 0;

    // Generating RSA Key Pair
    EVP_PKEY *pkey = EVP_RSA_gen(2048);
    if (!pkey) { std::cerr << "Keygen failed\n"; return 1; }

    // Printing the Private Key (The Secret Part)
    std::cout << "\nSENDER'S PRIVATE KEY (Used for Signing):\n\n";
    BIO* pri_bio = BIO_new(BIO_s_mem());
    PEM_write_bio_PrivateKey(pri_bio, pkey, NULL, NULL, 0, NULL, NULL);
    char* pri_buf;
    size_t pri_len = BIO_get_mem_data(pri_bio, &pri_buf);
    std::cout.write(pri_buf, pri_len) << "\n";

    // Printing the Public Key (The Shared Part)
    std::cout << "\nSENDER'S PUBLIC KEY (Shared with Receiver):\n\n";
    BIO* pub_bio = BIO_new(BIO_s_mem());
    PEM_write_bio_PUBKEY(pub_bio, pkey);
    char* pub_buf;
    size_t pub_len = BIO_get_mem_data(pub_bio, &pub_buf);
    std::cout.write(pub_buf, pub_len) << "\n";

    // Creating the Signature (Signing Process)
    std::cout << "SIGNING THE DOCUMENT...\n";
    std::cout << "Document Content: \"" << document << "\"\n\n";
    
    EVP_MD_CTX *m_ctx = EVP_MD_CTX_new();
    EVP_DigestSignInit(m_ctx, NULL, EVP_sha256(), NULL, pkey);
    EVP_DigestSignUpdate(m_ctx, document.c_str(), document.length());
    
    // Getting signature length first
    EVP_DigestSignFinal(m_ctx, NULL, &sig_len);
    signature = (unsigned char*)OPENSSL_malloc(sig_len);
    EVP_DigestSignFinal(m_ctx, signature, &sig_len);

    std::cout << "\nGENERATED SIGNATURE (HEXADECIMAL):\n\n";
    printHex(signature, sig_len);

    // Verification Process
    std::cout << "\nVERIFYING SIGNATURE WITH PUBLIC KEY...\n\n";
    EVP_MD_CTX *v_ctx = EVP_MD_CTX_new();
    EVP_DigestVerifyInit(v_ctx, NULL, EVP_sha256(), NULL, pkey);
    EVP_DigestVerifyUpdate(v_ctx, document.c_str(), document.length());
    
    int is_valid = EVP_DigestVerifyFinal(v_ctx, signature, sig_len);

    if (is_valid == 1) {
        std::cout << "RESULT: SUCCESS! The signature is VALID.\n";
    } else {
        std::cout << "RESULT: FAILED! The signature is INVALID.\n";
    }

    // Cleanup
    OPENSSL_free(signature);
    BIO_free(pri_bio);
    BIO_free(pub_bio);
    EVP_MD_CTX_free(m_ctx);
    EVP_MD_CTX_free(v_ctx);
    EVP_PKEY_free(pkey);

    return 0;
}