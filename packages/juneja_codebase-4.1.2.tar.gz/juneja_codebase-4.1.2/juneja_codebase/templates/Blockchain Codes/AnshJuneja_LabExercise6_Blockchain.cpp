#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <sstream>
#include <iomanip>
using namespace std;

string simpleHash(string input) {
    unsigned long hash = 5381;
    for (size_t i = 0; i < input.length(); i++) {
        char c = input[i];
        hash = ((hash << 5) + hash) + c; 
    }
    stringstream ss;
    ss << hex << setw(8) << setfill('0') << hash;
    return ss.str();
}

class Block {
public:
    int index;
    string data;
    string prevHash;
    string hash;
    int nonce;

    Block(int idx, string d, string pHash) {
        index = idx;
        data = d;
        prevHash = pHash;
        nonce = 0;
        mineBlock(); // Perform PoW immediately upon creation
    }

    string calculateHash() {
        stringstream ss;
        ss << index << data << prevHash << nonce;
        return simpleHash(ss.str());
    }

    void mineBlock() {
        string target = "00"; //Hash must start with "00"
        do {
            nonce++;
            hash = calculateHash();
        } while (hash.substr(0, 2) != target);
        
        cout << "Block Mined! Hash: " << hash << " | Nonce: " << nonce << endl;
    }
};

class Blockchain {
public:
    vector<Block> chain;

    Blockchain() {
        cout << "Mining Genesis Block..." << endl;
        chain.push_back(Block(0, "Genesis Block", "0"));
    }

    void addBlock(string data) {
        cout << "Mining Block " << chain.size() << "..." << endl;
        string lastHash = chain.back().hash;
        chain.push_back(Block(chain.size(), data, lastHash));
    }

    void printChain() {
        cout << "\n--- COMPLETE BLOCKCHAIN DETAILS ---" << endl;
        for (size_t i = 0 ; i<chain.size() ; i++) {
           cout << "Index    : " << chain[i].index << endl;
		   cout << "Data     : " << chain[i].data << endl;
           cout << "Prev Hash: " << chain[i].prevHash << endl;
           cout << "Hash     : " << chain[i].hash << endl;
           cout << "Nonce    : " << chain[i].nonce << endl;
           cout << "-----------------------------------" << endl;
        }
    }
};

int main() {
    Blockchain myCoin;

    myCoin.addBlock("A -> B");
    myCoin.addBlock("B -> C");
    myCoin.addBlock("C -> D");

    myCoin.printChain();

    return 0;
}
