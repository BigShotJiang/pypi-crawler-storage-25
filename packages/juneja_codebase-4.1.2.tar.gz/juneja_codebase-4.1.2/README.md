# juneja-codebase

Offline CLI for generating practical code files for multiple subjects.

## Install

```bash
pip install juneja-codebase==4.1.0
```

## Use

```bash
juneja-codebase --list
juneja-codebase --all
juneja-codebase --subject compiler_design
juneja-codebase --subject blockchain
juneja-codebase --all --zip
juneja-codebase --all --output ./my_codes
```

If the console script is not on PATH, use:

```bash
python3 -m juneja_codebase.main --list
python3 -m juneja_codebase.main --all
python3 -m juneja_codebase.main --subject blockchain
```

## Subjects

- Compiler Design
- Blockchain Codes
- Deep Learning
- Social Network Analysis

## Notes

- `--subject blockchain` resolves to the `Blockchain Codes` templates folder.
- The package works offline because templates ship inside the wheel and sdist.


