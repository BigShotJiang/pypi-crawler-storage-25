"""
AGENTICSTAR Platform SDK - Telemetry Access Layer
テレメトリ・監査ログの保存・取得機能を提供

NIST監査対応のai_telemetryテーブルへのCRUD操作
"""

import json
import logging
from datetime import datetime
from typing import Any, Dict, List, Optional

from .data_access import DataAccess

logger = logging.getLogger(__name__)


class TelemetryAccess:
    """
    テレメトリデータアクセスクラス

    ai_telemetryテーブルへの保存・取得機能を提供:
    - save_telemetry: テレメトリデータの保存
    - list_telemetry: テレメトリデータの一覧取得
    - get_telemetry: 個別テレメトリデータの取得
    """

    def __init__(self, db: DataAccess):
        """
        Args:
            db: DataAccessインスタンス
        """
        self._db = db
        self.logger = logger

    async def save_telemetry(self, telemetry_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        汎用テレメトリーデータをPostgreSQLに保存（NIST監査対応）

        Args:
            telemetry_data: テレメトリーデータ（任意の構造）
                必須フィールド:
                - conversation_id: 会話ID
                - agent_type: エージェントタイプ (intent, react, coordinator, tool等)

        Returns:
            Dict with keys: success, data, error (optional), error_code (optional)
        """
        try:
            # 必須フィールドチェック
            if 'conversation_id' not in telemetry_data:
                return {
                    "success": False,
                    "error": "conversation_id is required",
                    "error_code": "MISSING_FIELD"
                }

            if 'agent_type' not in telemetry_data:
                return {
                    "success": False,
                    "error": "agent_type is required",
                    "error_code": "MISSING_FIELD"
                }

            # 防御コピー（呼び出し元のdictを破壊しない）
            telemetry_data = dict(telemetry_data)

            # デフォルト値の設定
            if 'timestamp' not in telemetry_data:
                telemetry_data['timestamp'] = datetime.now()

            # metadataフィールドの処理
            metadata = telemetry_data.get('metadata', {})
            if not isinstance(metadata, dict):
                metadata = {}

            # すべての追加フィールドをmetadataに含める
            known_fields = {
                'timestamp', 'service', 'operation', 'duration_ms',
                'conversation_id', 'intent_type', 'confidence_score',
                'success',
                'agent_type', 'agent_level', 'task_complexity',
                'current_message', 'context_summary', 'suggested_approach',
                'conversation_goal', 'final_content', 'metadata'
            }

            # PII保護のため除外するフィールド
            excluded_fields = {'conversation_history'}

            for key, value in telemetry_data.items():
                if key not in known_fields and key not in excluded_fields:
                    metadata[key] = value

            metadata_json = json.dumps(metadata, ensure_ascii=False) if metadata else None

            # INSERT クエリ
            query = """
                INSERT INTO ai_telemetry (
                    timestamp, service, operation, duration_ms,
                    conversation_id,
                    intent_type, confidence_score, success,
                    agent_type, agent_level, task_complexity,
                    current_message, context_summary, suggested_approach,
                    conversation_goal, final_content, metadata,
                    created_at
                ) VALUES (
                    $1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18
                )
            """

            params = (
                telemetry_data.get('timestamp'),
                telemetry_data.get('service', 'autonomous-agent'),
                telemetry_data.get('operation'),
                telemetry_data.get('duration_ms'),
                telemetry_data['conversation_id'],
                telemetry_data.get('intent_type'),
                telemetry_data.get('confidence_score'),
                telemetry_data.get('success'),
                telemetry_data['agent_type'],
                telemetry_data.get('agent_level'),
                telemetry_data.get('task_complexity'),
                telemetry_data.get('current_message'),
                telemetry_data.get('context_summary'),
                telemetry_data.get('suggested_approach'),
                telemetry_data.get('conversation_goal'),
                telemetry_data.get('final_content'),
                metadata_json,
                datetime.now()  # created_at
            )

            result = await self._db.execute_query(query, params)

            if result.get("success"):
                self.logger.debug(
                    f"Telemetry saved: conversation_id={telemetry_data['conversation_id']}, "
                    f"agent_type={telemetry_data['agent_type']}"
                )
                return {"success": True, "data": "Telemetry saved"}
            else:
                self.logger.error(f"Failed to save telemetry: {result.get('error')}")
                return {
                    "success": False,
                    "error": result.get("error"),
                    "error_code": result.get("error_code"),
                }

        except Exception as e:
            self.logger.error(f"Error saving telemetry: {str(e)}")
            return {
                "success": False,
                "error": f"Error saving telemetry: {str(e)}",
                "error_code": "TELEMETRY_ERROR"
            }

    async def list_telemetry(
        self,
        conversation_id: Optional[str] = None,
        service: Optional[str] = None,
        limit: int = 100,
        offset: int = 0,
    ) -> Dict[str, Any]:
        """
        テレメトリデータの一覧を取得

        Args:
            conversation_id: 会話IDでフィルタ（オプション）
            service: サービス名でフィルタ（オプション）
            limit: 取得件数上限（デフォルト: 100）
            offset: オフセット（デフォルト: 0）

        Returns:
            Dict with keys: success, data (List[Dict]), error (optional)
        """
        self.logger.info(
            f"[IN] list_telemetry: conversation_id={conversation_id}, "
            f"service={service}, limit={limit}, offset={offset}"
        )
        try:
            conditions = []
            params: list = []
            param_index = 1

            if conversation_id:
                conditions.append(f"conversation_id = ${param_index}")
                params.append(conversation_id)
                param_index += 1

            if service:
                conditions.append(f"service = ${param_index}")
                params.append(service)
                param_index += 1

            where_clause = f"WHERE {' AND '.join(conditions)}" if conditions else ""

            query = f"""
                SELECT id, timestamp, service, operation, duration_ms,
                       conversation_id, intent_type, confidence_score, success,
                       agent_type, agent_level, task_complexity,
                       metadata, created_at
                FROM ai_telemetry
                {where_clause}
                ORDER BY created_at DESC
                LIMIT ${param_index} OFFSET ${param_index + 1}
            """
            params.extend([limit, offset])

            result = await self._db.execute_query(query, tuple(params))

            if not result.get("success"):
                self.logger.error(f"[ERROR] list_telemetry: {result.get('error')}")
                return {
                    "success": False,
                    "error": result.get("error"),
                    "error_code": result.get("error_code", "DATABASE_ERROR"),
                }

            data = result.get("data", [])
            self.logger.info(f"[OUT] list_telemetry: Retrieved {len(data)} records")
            return {"success": True, "data": data}

        except Exception as e:
            self.logger.error(f"[ERROR] list_telemetry: {str(e)}")
            return {
                "success": False,
                "error": f"Error listing telemetry: {str(e)}",
                "error_code": "TELEMETRY_ERROR",
            }

    async def get_telemetry(self, telemetry_id: str) -> Optional[Dict[str, Any]]:
        """
        個別テレメトリデータを取得

        Args:
            telemetry_id: テレメトリID

        Returns:
            テレメトリデータのDict、またはNone（データなし/エラー時）
        """
        self.logger.info(f"[IN] get_telemetry: id={telemetry_id}")
        try:
            result = await self._db.execute_query(
                "SELECT * FROM ai_telemetry WHERE id = $1",
                (telemetry_id,)
            )

            if result.get("success") and result.get("data"):
                self.logger.info(f"[OUT] get_telemetry: Found record for id={telemetry_id}")
                return result["data"][0]

            self.logger.warning(f"[OUT] get_telemetry: Not found for id={telemetry_id}")
            return None

        except Exception as e:
            self.logger.error(f"[ERROR] get_telemetry: {str(e)}")
            return None
