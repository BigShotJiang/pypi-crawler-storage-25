"""
AGENTICSTAR Platform SDK
エンタープライズAIエージェント基盤のためのSDK

外部サービス（PostgreSQL、Qdrant、Azure Blob/S3/GCS、Content Safety/PII等）との通信機能を提供
"""

__version__ = "0.5.2"

# Common utilities are internal - not exported as public API
# Use agenticstar_platform.common for internal SDK development only

# Database module
from .db import PostgreSQLManager, ApiPostgreSQLManager, PostgreSQLConfig, AzureADConfig, DataAccess, ConfigAccess

# RAG module
from .rag import EmbeddingGenerator, EmbeddingConfig, QdrantManager, QdrantConfig

# Events module
from .events import (
    EventType,
    SubEventType,
    StreamingEvent,
    SequencedEvent,
    ExecutionMessage,
    EventEmitter,
    EventHandler,
    create_sse_handler,
    create_json_handler,
    # Event Handlers（マーケットプレイスUI連携用）
    DatabaseEventHandler,
    WebhookEventHandler,
    CompositeEventHandler,
    create_marketplace_handler,
)

# Memory module
from .memory import (
    SemanticMemoryClient,
    SemanticMemoryConfig,
    LLMProviderConfig,
)

# Storage module
from .storage import (
    StorageProvider,
    StorageConfig,
    AzureBlobConfig,
    S3Config,
    GCSConfig,
    AzureBlobStorageClient,
    S3StorageClient,
    GCSStorageClient,
    UploadResult,
    DownloadResult,
    ObjectInfo,
    ListResult,
)

# Security module
from .security import (
    SecurityProvider,
    ContentCategory,
    PIICategory,
    SecurityError,
    SecurityConfigError,
    SecurityAPIError,
    ContentModerationResult,
    PromptShieldResult,
    PIIEntity,
    PIIDetectionResult,
    SecurityCheckResult,
    AzureSecurityConfig,
    AWSSecurityConfig,
    GCPSecurityConfig,
    AzureSecurityClient,
    AWSSecurityClient,
    GCPSecurityClient,
)

# Auth module
from .auth import (
    AgenticStarAuthClient,
    AgenticStarAuthConfig,
    AuthError,
    AuthConfigError,
    AuthAPIError,
    AuthUnauthorizedError,
    AuthNotFoundError,
    AuthRateLimitError,
    ApiUser,
    DeviceInfo,
    LoginHistoryEntry,
    UserPagination,
    MCPTokenInfo,
    MCPTokenError,
    OAuthProviderName,
    GetUsersResult,
    GetUserResult,
    GetMCPTokensResult,
)

__all__ = [
    # Database
    "PostgreSQLManager",
    "ApiPostgreSQLManager",
    "PostgreSQLConfig",
    "AzureADConfig",
    "DataAccess",
    "ConfigAccess",
    # RAG
    "EmbeddingGenerator",
    "EmbeddingConfig",
    "QdrantManager",
    "QdrantConfig",
    # Events
    "EventType",
    "SubEventType",
    "StreamingEvent",
    "SequencedEvent",
    "ExecutionMessage",
    "EventEmitter",
    "EventHandler",
    "create_sse_handler",
    "create_json_handler",
    # Event Handlers（マーケットプレイスUI連携用）
    "DatabaseEventHandler",
    "WebhookEventHandler",
    "CompositeEventHandler",
    "create_marketplace_handler",
    # Memory
    "SemanticMemoryClient",
    "SemanticMemoryConfig",
    "LLMProviderConfig",
    # Storage
    "StorageProvider",
    "StorageConfig",
    "AzureBlobConfig",
    "S3Config",
    "GCSConfig",
    "AzureBlobStorageClient",
    "S3StorageClient",
    "GCSStorageClient",
    "UploadResult",
    "DownloadResult",
    "ObjectInfo",
    "ListResult",
    # Security
    "SecurityProvider",
    "ContentCategory",
    "PIICategory",
    "SecurityError",
    "SecurityConfigError",
    "SecurityAPIError",
    "ContentModerationResult",
    "PromptShieldResult",
    "PIIEntity",
    "PIIDetectionResult",
    "SecurityCheckResult",
    "AzureSecurityConfig",
    "AWSSecurityConfig",
    "GCPSecurityConfig",
    "AzureSecurityClient",
    "AWSSecurityClient",
    "GCPSecurityClient",
    # Auth
    "AgenticStarAuthClient",
    "AgenticStarAuthConfig",
    "AuthError",
    "AuthConfigError",
    "AuthAPIError",
    "AuthUnauthorizedError",
    "AuthNotFoundError",
    "AuthRateLimitError",
    "ApiUser",
    "DeviceInfo",
    "LoginHistoryEntry",
    "UserPagination",
    "MCPTokenInfo",
    "MCPTokenError",
    "OAuthProviderName",
    "GetUsersResult",
    "GetUserResult",
    "GetMCPTokensResult",
]
