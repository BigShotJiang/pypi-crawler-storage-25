"""
AGENTICSTAR Platform SDK - Auth Configuration Models
AgenticStar Auth API接続のための設定モデル

設定ソース: config.toml [auth.agenticstar] セクション
（values.yaml → Helm template → Secret としてマウント）

Note:
    CLIモードでの使用は src.config.auth_config_factory を使用してください。
    SDKはsrc層をインポートしないため、CLI固有の設定は呼び出し側で注入します。
"""

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Dict, Optional

from .exceptions import AuthConfigError


@dataclass
class AgenticStarAuthConfig:
    """AgenticStar Auth API設定

    Args:
        base_url: APIベースURL (例: "https://auth.example.com")
        api_key: X-Internal-API-Key認証用APIキー、またはBearer token
        auth_type: 認証タイプ ("api_key" or "bearer")
        timeout: HTTPリクエストタイムアウト秒数

    Note:
        api_keyはrepr=Falseでログ出力から除外されます。
        CLIモードでは create() で直接設定を注入してください。

    Example:
        ```python
        # コードから直接指定
        config = AgenticStarAuthConfig.create(
            base_url="https://auth.example.com",
            api_key="your-api-key",
        )

        # config.tomlから読み込み（Podモード）
        config = AgenticStarAuthConfig.from_config()
        ```
    """

    # 必須設定
    base_url: str
    api_key: str = field(repr=False)  # API key or Bearer token

    # オプション設定
    auth_type: str = "api_key"  # "api_key" (Pod) or "bearer" (CLI)
    timeout: float = 30.0

    def __str__(self) -> str:
        """文字列表現（APIキーをマスク）"""
        return f"AgenticStarAuthConfig(base_url={self.base_url!r}, api_key=***)"

    @classmethod
    def create(
        cls,
        base_url: str,
        api_key: str,
        auth_type: str = "api_key",
        timeout: float = 30.0,
    ) -> "AgenticStarAuthConfig":
        """コードから直接設定を指定して作成

        Args:
            base_url: APIベースURL
            api_key: APIキー（またはBearer token）
            auth_type: 認証タイプ ("api_key" or "bearer")
            timeout: タイムアウト秒数

        Returns:
            AgenticStarAuthConfig インスタンス

        Example:
            ```python
            # Pod mode (X-Internal-API-Key)
            config = AgenticStarAuthConfig.create(
                base_url="https://auth.example.com",
                api_key="your-api-key",
            )

            # CLI mode (Bearer token)
            config = AgenticStarAuthConfig.create(
                base_url="https://auth.example.com",
                api_key="oauth-token",
                auth_type="bearer",
            )
            ```
        """
        return cls(
            base_url=base_url,
            api_key=api_key,
            auth_type=auth_type,
            timeout=timeout,
        )

    @classmethod
    def from_config(
        cls,
        config_path: Optional[Path] = None,
    ) -> "AgenticStarAuthConfig":
        """config.tomlから設定を読み込む

        Args:
            config_path: config.tomlのパス（省略時は自動検出）

        Returns:
            AgenticStarAuthConfig インスタンス

        Raises:
            AuthConfigError: 設定ファイルの読み込みに失敗した場合
            ValueError: 必須設定が見つからない場合
        """
        toml_config = cls._load_toml_config(config_path)

        base_url = toml_config.get("base_url")
        api_key = toml_config.get("api_key")
        timeout = toml_config.get("timeout", 30.0)

        # バリデーション
        if not base_url:
            raise ValueError(
                "base_url is required. Configure [auth.agenticstar] base_url in config.toml"
            )

        if not api_key:
            raise ValueError(
                "api_key is required. Configure [auth.agenticstar] api_key in config.toml"
            )

        return cls(
            base_url=base_url,
            api_key=api_key,
            auth_type="api_key",
            timeout=float(timeout),
        )

    @staticmethod
    def _load_toml_config(config_path: Optional[Path] = None) -> Dict[str, Any]:
        """config.tomlから[auth.agenticstar]セクションを読み込む

        Raises:
            AuthConfigError: ファイル読み込みやパースに失敗した場合
        """
        import tomllib

        # パスが指定されていない場合は自動検出
        candidates = []
        if config_path is None:
            # 優先順位: カレントディレクトリ > プロジェクトルート
            candidates = [
                Path.cwd() / "config.toml",
                Path(__file__).parent.parent.parent.parent / "config.toml",  # sdk/ の親 = プロジェクトルート
            ]
            for candidate in candidates:
                if candidate.exists():
                    config_path = candidate
                    break

        if config_path is None or not config_path.exists():
            raise AuthConfigError(
                f"config.toml not found. Searched: {[str(c) for c in candidates]}"
            )

        try:
            with open(config_path, "rb") as f:
                config = tomllib.load(f)
        except tomllib.TOMLDecodeError as e:
            raise AuthConfigError(f"Invalid TOML syntax in {config_path}: {e}")
        except PermissionError as e:
            raise AuthConfigError(f"Permission denied reading {config_path}: {e}")
        except Exception as e:
            raise AuthConfigError(f"Failed to read {config_path}: {e}")

        auth_agenticstar = config.get("auth", {}).get("agenticstar")
        if auth_agenticstar is None:
            raise AuthConfigError(
                f"[auth.agenticstar] section not found in {config_path}"
            )

        return auth_agenticstar
