"""
AGENTICSTAR Platform SDK - GCP Security Client
Google Cloud Model Armor + Cloud DLP 統合クライアント

機能:
- Content Moderation: Model Armor sanitizeUserPrompt API
- Prompt Shield: Model Armor プロンプトインジェクション検知
- PII Detection: Cloud DLP inspect_content / deidentify_content API

Example:
    config = GCPSecurityConfig(
        project_id="my-project",
        model_armor_template="projects/xxx/locations/xxx/templates/xxx",
        model_armor_region="asia-southeast1",
    )
    client = GCPSecurityClient(config)

    # Content Moderation + Prompt Shield (Model Armor)
    result = await client.check_content_moderation("some text", threshold=2)
    shield = await client.check_prompt_shield("user prompt")

    # PII Detection (Cloud DLP)
    pii = await client.detect_pii("My credit card is 4111-1111-1111-1111")
    print(pii.masked_text)

    await client.close()
"""

import asyncio
import json
import logging
from typing import Any, Dict, List, Optional

from .base import (
    ContentCategory,
    ContentModerationResult,
    GCPSecurityConfig,
    PIICategory,
    PIIDetectionResult,
    PIIEntity,
    PromptShieldResult,
    SecurityAPIError,
    SecurityClientBase,
    SecurityConfigError,
    SecurityProvider,
)

logger = logging.getLogger(__name__)

# google-cloud-dlp availability check
try:
    from google.cloud import dlp_v2
    from google.oauth2 import service_account
    GCP_DLP_AVAILABLE = True
except ImportError:
    dlp_v2 = None
    service_account = None
    GCP_DLP_AVAILABLE = False

# httpx availability check (Model Armor REST API 用)
try:
    import httpx
    HTTPX_AVAILABLE = True
except ImportError:
    httpx = None
    HTTPX_AVAILABLE = False

# google-auth availability check (Model Armor 認証用)
try:
    import google.auth
    import google.auth.transport.requests
    GOOGLE_AUTH_AVAILABLE = True
except ImportError:
    google = None
    GOOGLE_AUTH_AVAILABLE = False

# Model Armor カテゴリ → ContentCategory マッピング
_MODEL_ARMOR_CATEGORY_MAP = {
    "HARM_CATEGORY_HATE_SPEECH": ContentCategory.HATE,
    "HARM_CATEGORY_DANGEROUS_CONTENT": ContentCategory.SELF_HARM,
    "HARM_CATEGORY_HARASSMENT": ContentCategory.INSULT,
    "HARM_CATEGORY_SEXUALLY_EXPLICIT": ContentCategory.SEXUAL,
}

# Model Armor 確信度 → 数値スコアマッピング
_MODEL_ARMOR_CONFIDENCE_SCORE = {
    "NEGLIGIBLE": 0,
    "LOW": 2,
    "MEDIUM": 4,
    "HIGH": 6,
}

# Cloud DLP InfoType → PIICategory マッピング
_DLP_PII_MAP = {
    "PERSON_NAME": PIICategory.PERSON_NAME,
    "EMAIL_ADDRESS": PIICategory.EMAIL,
    "PHONE_NUMBER": PIICategory.PHONE_NUMBER,
    "STREET_ADDRESS": PIICategory.ADDRESS,
    "DATE_OF_BIRTH": PIICategory.DATE_OF_BIRTH,
    "PASSPORT": PIICategory.PASSPORT_NUMBER,
    "JAPAN_PASSPORT": PIICategory.PASSPORT_NUMBER,
    "JAPAN_INDIVIDUAL_NUMBER": PIICategory.NATIONAL_ID,
    "JAPAN_DRIVERS_LICENSE_NUMBER": PIICategory.DRIVERS_LICENSE,
    "JAPAN_BANK_ACCOUNT": PIICategory.BANK_ACCOUNT,
    "CREDIT_CARD_NUMBER": PIICategory.CREDIT_CARD,
    "IBAN_CODE": PIICategory.IBAN,
    "SWIFT_CODE": PIICategory.SWIFT_CODE,
    "IP_ADDRESS": PIICategory.IP_ADDRESS,
    "MAC_ADDRESS": PIICategory.MAC_ADDRESS,
    "URL": PIICategory.URL,
    "PASSWORD": PIICategory.PASSWORD,
    "GCP_API_KEY": PIICategory.API_KEY,
    "AWS_CREDENTIALS": PIICategory.AWS_ACCESS_KEY,
}

# Cloud DLP で検査する InfoType 一覧
_DLP_INFO_TYPES = [
    "PERSON_NAME",
    "EMAIL_ADDRESS",
    "PHONE_NUMBER",
    "STREET_ADDRESS",
    "DATE_OF_BIRTH",
    "CREDIT_CARD_NUMBER",
    "IBAN_CODE",
    "SWIFT_CODE",
    "IP_ADDRESS",
    "MAC_ADDRESS",
    "URL",
    "PASSWORD",
    "PASSPORT",
    "JAPAN_PASSPORT",
    "JAPAN_INDIVIDUAL_NUMBER",
    "JAPAN_DRIVERS_LICENSE_NUMBER",
    "JAPAN_BANK_ACCOUNT",
    "GCP_API_KEY",
    "AWS_CREDENTIALS",
]


class GCPSecurityClient(SecurityClientBase):
    """
    Google Cloud Model Armor + Cloud DLP セキュリティクライアント

    Model Armor: Content Moderation (sanitizeUserPrompt) + Prompt Shield
    Cloud DLP: PII Detection (inspect_content / deidentify_content)

    Workload Identity環境ではcredentials不要（デフォルト認証を使用）。

    Example:
        config = GCPSecurityConfig(
            project_id="my-project",
            model_armor_template="projects/xxx/locations/xxx/templates/xxx",
            model_armor_region="asia-southeast1",
            enabled=True,
        )
        client = GCPSecurityClient(config)
        result = await client.check_security("user input")
    """

    def __init__(self, config: GCPSecurityConfig):
        super().__init__(config)

        self._gcp_config: GCPSecurityConfig = config
        self._dlp_client = None
        self._http_client: Optional[Any] = None
        self._credentials = None

        # Cloud DLP クライアント初期化
        if GCP_DLP_AVAILABLE:
            try:
                if config.credentials_path:
                    credentials = service_account.Credentials.from_service_account_file(
                        config.credentials_path
                    )
                    self._dlp_client = dlp_v2.DlpServiceClient(credentials=credentials)
                    self._credentials = credentials
                elif config.credentials_json:
                    credentials_info = json.loads(config.credentials_json)
                    credentials = service_account.Credentials.from_service_account_info(
                        credentials_info
                    )
                    self._dlp_client = dlp_v2.DlpServiceClient(credentials=credentials)
                    self._credentials = credentials
                else:
                    self._dlp_client = dlp_v2.DlpServiceClient()
            except Exception as e:
                logger.error(f"Failed to initialize Cloud DLP client: {e}")
                raise SecurityConfigError(f"Failed to initialize Cloud DLP client: {e}") from e
        else:
            logger.warning("google-cloud-dlp not available, PII detection will not work")

        # Model Armor 用 HTTP クライアント初期化
        if config.model_armor_template and HTTPX_AVAILABLE:
            self._http_client = httpx.AsyncClient(timeout=config.timeout)

        self._enabled = config.enabled

        logger.info(
            f"GCPSecurityClient initialized - project={config.project_id}, "
            f"model_armor_template={config.model_armor_template or 'none'}"
        )

    @property
    def provider(self) -> SecurityProvider:
        return SecurityProvider.GCP

    async def _get_auth_token(self) -> str:
        """Google Cloud 認証トークンを取得"""
        if not GOOGLE_AUTH_AVAILABLE:
            raise SecurityConfigError("google-auth package is not installed")

        if self._credentials:
            credentials = self._credentials
        else:
            credentials, _ = google.auth.default()

        # トークンリフレッシュ（同期APIなのでexecutorで実行）
        def refresh():
            request = google.auth.transport.requests.Request()
            credentials.refresh(request)
            return credentials.token

        token = await asyncio.get_event_loop().run_in_executor(None, refresh)
        return token

    async def check_content_moderation(
        self,
        text: str,
        threshold: Optional[int] = None,
    ) -> ContentModerationResult:
        """
        有害コンテンツをチェック（Model Armor sanitizeUserPrompt）

        Model Armor テンプレートが未設定の場合は NOT_CONFIGURED を返す。

        Args:
            text: チェック対象テキスト
            threshold: しきい値（0=無効, 2=LOW, 4=MEDIUM, 6=HIGH）

        Returns:
            ContentModerationResult
        """
        if not self._http_client or not self._gcp_config.model_armor_template:
            return ContentModerationResult(
                blocked=False,
                error="Model Armor not configured (template is empty)",
                error_code="NOT_CONFIGURED",
            )

        effective_threshold = threshold if threshold is not None else self._gcp_config.moderation_threshold
        if effective_threshold == 0:
            return ContentModerationResult(blocked=False, threshold=0)

        try:
            token = await self._get_auth_token()
            template = self._gcp_config.model_armor_template
            url = f"https://modelarmor.googleapis.com/v1/{template}:sanitizeUserPrompt"

            response = await self._http_client.post(
                url,
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json",
                },
                json={
                    "userPromptData": {
                        "text": text,
                    },
                },
            )
            response.raise_for_status()
            data = response.json()

            # 結果パース
            blocked = False
            categories: Dict[ContentCategory, int] = {}

            sanitization_result = data.get("sanitizationResult", {})
            filter_results = sanitization_result.get("filterResults", {})

            # コンテンツフィルタ結果
            for harm_result in filter_results.get("responsibleAiFilter", {}).get("harmProbabilityResults", []):
                harm_category = harm_result.get("harmCategory", "")
                probability = harm_result.get("harmProbability", "NEGLIGIBLE")
                score = _MODEL_ARMOR_CONFIDENCE_SCORE.get(probability, 0)
                category = _MODEL_ARMOR_CATEGORY_MAP.get(harm_category)
                if category:
                    categories[category] = score
                    if score >= effective_threshold:
                        blocked = True

            return ContentModerationResult(
                blocked=blocked,
                categories=categories,
                threshold=effective_threshold,
                raw_response=data,
            )

        except Exception as e:
            logger.error(f"Model Armor content moderation error: {e}")
            raise SecurityAPIError(str(e), error_code="API_ERROR")

    async def check_prompt_shield(
        self,
        user_prompt: str,
        documents: Optional[List[str]] = None,
    ) -> PromptShieldResult:
        """
        Jailbreak攻撃を検出（Model Armor プロンプトインジェクション検知）

        Model Armor テンプレートが未設定の場合は NOT_CONFIGURED を返す。

        Args:
            user_prompt: ユーザープロンプト
            documents: ドキュメント内容（オプション）

        Returns:
            PromptShieldResult
        """
        if not self._http_client or not self._gcp_config.model_armor_template:
            return PromptShieldResult(
                attack_detected=False,
                error="Model Armor not configured (template is empty)",
                error_code="NOT_CONFIGURED",
            )

        try:
            # Model Armor のトークン制限（Prompt Shield: 512トークン）
            # 先頭256トークン + 末尾256トークンのサンプリング方式
            # Jailbreak攻撃はプロンプト末尾に隠されることが多いため、末尾も必ずチェック
            sampled_prompt = self._sample_prompt_for_shield(user_prompt)

            token = await self._get_auth_token()
            template = self._gcp_config.model_armor_template
            url = f"https://modelarmor.googleapis.com/v1/{template}:sanitizeUserPrompt"

            response = await self._http_client.post(
                url,
                headers={
                    "Authorization": f"Bearer {token}",
                    "Content-Type": "application/json",
                },
                json={
                    "userPromptData": {
                        "text": sampled_prompt,
                    },
                },
            )
            response.raise_for_status()
            data = response.json()

            # プロンプトインジェクション検出
            attack_detected = False
            attack_type = None
            confidence = 0.0

            sanitization_result = data.get("sanitizationResult", {})
            filter_results = sanitization_result.get("filterResults", {})

            # PI and Jailbreak フィルタ結果
            pi_result = filter_results.get("piAndJailbreakFilterResult", {})
            match_state = pi_result.get("matchState", "NO_MATCH_FOUND")

            if match_state == "MATCH_FOUND":
                attack_detected = True
                attack_type = "prompt_injection"
                confidence_level = pi_result.get("confidenceLevel", "LOW_AND_ABOVE")
                if "HIGH" in confidence_level:
                    confidence = 1.0
                elif "MEDIUM" in confidence_level:
                    confidence = 0.7
                else:
                    confidence = 0.4

            return PromptShieldResult(
                attack_detected=attack_detected,
                attack_type=attack_type,
                confidence=confidence,
                raw_response=data,
            )

        except Exception as e:
            logger.error(f"Model Armor prompt shield error: {e}")
            raise SecurityAPIError(str(e), error_code="API_ERROR")

    async def detect_pii(
        self,
        text: str,
        mask: bool = True,
        language: str = "ja",
    ) -> PIIDetectionResult:
        """
        PIIを検出・マスク（Cloud DLP inspect_content / deidentify_content）

        Args:
            text: 検出対象テキスト
            mask: マスキングを行うか
            language: 言語コード（Cloud DLPは自動検出のため参考値）

        Returns:
            PIIDetectionResult
        """
        if not self._dlp_client:
            return PIIDetectionResult(
                success=False,
                masked_text="",
                error="Cloud DLP client not initialized",
                error_code="NOT_CONFIGURED",
            )

        parent = f"projects/{self._gcp_config.project_id}/locations/{self._gcp_config.dlp_location}"

        inspect_config = {
            "info_types": [{"name": t} for t in _DLP_INFO_TYPES],
            "min_likelihood": "LIKELY",
            "limits": {
                "max_findings_per_item": 100,
                "max_findings_per_request": 100,
            },
        }

        item = {"value": text}

        try:
            # inspect_content で PII 検出
            inspect_response = await asyncio.get_event_loop().run_in_executor(
                None,
                lambda: self._dlp_client.inspect_content(
                    request={
                        "parent": parent,
                        "inspect_config": inspect_config,
                        "item": item,
                    }
                ),
            )

            entities: List[PIIEntity] = []
            for finding in inspect_response.result.findings:
                likelihood_score = finding.likelihood
                # LIKELY (4) 以上のみ
                if likelihood_score < 4:
                    continue

                info_type_name = finding.info_type.name
                # location からオフセットを取得
                if finding.location.byte_range:
                    begin = finding.location.byte_range.start
                    end = finding.location.byte_range.end
                elif finding.location.codepoint_range:
                    begin = finding.location.codepoint_range.start
                    end = finding.location.codepoint_range.end
                else:
                    continue

                entity_text = text[begin:end] if begin < len(text) and end <= len(text) else ""
                category = _DLP_PII_MAP.get(info_type_name, PIICategory.OTHER)
                confidence = likelihood_score / 5.0  # VERY_LIKELY=5 → 1.0

                entities.append(PIIEntity(
                    category=category,
                    text=entity_text,
                    offset=begin,
                    length=end - begin,
                    confidence=confidence,
                    provider_category=info_type_name,
                ))

            # 正規表現による日本語PII補完（全クラウド共通）
            regex_entities = self._detect_pii_by_regex(text)
            entities = self._merge_pii_entities(entities, regex_entities)

            # マスキング
            masked_text = text
            if mask and entities:
                for entity in sorted(entities, key=lambda e: e.offset, reverse=True):
                    start = entity.offset
                    end = entity.offset + entity.length
                    masked_text = masked_text[:start] + self._gcp_config.pii_mask_string + masked_text[end:]

            categories_detected = list({e.category for e in entities})

            return PIIDetectionResult(
                success=True,
                masked_text=masked_text,
                entities=entities,
                categories_detected=categories_detected,
            )

        except Exception as e:
            error_msg = f"Cloud DLP PII detection error: {e}"
            logger.error(error_msg)
            return PIIDetectionResult(
                success=False,
                masked_text="",
                error=error_msg,
                error_code="API_ERROR",
            )

    @staticmethod
    def _sample_prompt_for_shield(text: str, max_tokens: int = 512) -> str:
        """Prompt Shield用にテキストをサンプリングする

        Model Armorのトークン制限（512）に対応するため、
        先頭256トークン + 末尾256トークンを結合する。
        Jailbreak攻撃はプロンプト末尾に隠されることが多いため、
        先頭のみのトランケーションでは見逃すリスクがある。

        トークン数は概算（日本語: 1文字≒1.5トークン、英語: 1単語≒1トークン）で、
        安全側に倒して文字数ベースで計算する。

        Args:
            text: 元のプロンプトテキスト
            max_tokens: 最大トークン数（デフォルト512）

        Returns:
            サンプリング済みテキスト
        """
        # 日本語を考慮した概算: 1トークン ≒ 1文字（安全側）
        max_chars = max_tokens
        if len(text) <= max_chars:
            return text

        half = max_chars // 2
        head = text[:half]
        tail = text[-half:]

        logger.info(
            f"Prompt Shield: テキストをサンプリング（{len(text)}文字 → 先頭{half}+末尾{half}文字）"
        )

        return head + "\n...\n" + tail

    async def close(self) -> None:
        """クライアントリソースをクローズ"""
        try:
            if self._http_client:
                await self._http_client.aclose()
            if self._dlp_client and hasattr(self._dlp_client, 'transport') and hasattr(self._dlp_client.transport, 'close'):
                self._dlp_client.transport.close()
        except Exception as e:
            logger.warning(f"Error closing GCP client: {e}")
        finally:
            self._http_client = None
            self._dlp_client = None
            self._credentials = None
            self._enabled = False
            logger.debug("GCPSecurityClient closed")
