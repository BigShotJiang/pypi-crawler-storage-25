from __future__ import annotations

import argparse
import json
import pathlib
import sys


def _repo_root() -> pathlib.Path:
    return pathlib.Path(__file__).resolve().parent.parent


def _load_langgraph_config() -> dict:
    config_path = _repo_root() / "langgraph.json"
    with config_path.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def _cmd_version() -> int:
    try:
        from importlib.metadata import version

        print(version("deerflow-kernel"))
        return 0
    except Exception as exc:
        print(f"failed to resolve installed package version: {exc}", file=sys.stderr)
        return 1


def _cmd_check() -> int:
    try:
        import deerflow  # noqa: F401
        from deerflow.agents import make_lead_agent  # noqa: F401

        config = _load_langgraph_config()
        print("kernel import check passed")
        print(f"graph entry: {config['graphs']['lead_agent']}")
        return 0
    except Exception as exc:
        print(f"kernel check failed: {exc}", file=sys.stderr)
        return 1


def _cmd_show_langgraph_json() -> int:
    config = _load_langgraph_config()
    print(json.dumps(config, ensure_ascii=False, indent=2))
    return 0


def main() -> int:
    parser = argparse.ArgumentParser(prog="deerflow-kernel")
    subparsers = parser.add_subparsers(dest="command", required=True)
    subparsers.add_parser("version")
    subparsers.add_parser("check")
    subparsers.add_parser("show-langgraph-json")

    args = parser.parse_args()
    if args.command == "version":
        return _cmd_version()
    if args.command == "check":
        return _cmd_check()
    if args.command == "show-langgraph-json":
        return _cmd_show_langgraph_json()
    parser.error(f"unsupported command: {args.command}")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
