"""odoodev init - Initialize a new Odoo development environment."""

from __future__ import annotations

import os

import click

from odoodev.cli import resolve_version
from odoodev.core.docker_compose import render_compose
from odoodev.core.environment import detect_docker_platform, detect_user
from odoodev.core.version_registry import get_version, load_versions
from odoodev.output import confirm, print_info, print_success, print_warning


@click.command()
@click.argument("version", required=False)
@click.option("--non-interactive", is_flag=True, help="Use all defaults without prompting")
@click.option("--skip-repos", is_flag=True, help="Skip repository cloning")
@click.option("--skip-docker", is_flag=True, help="Skip Docker service startup")
@click.pass_context
def init(
    ctx: click.Context,
    version: str | None,
    non_interactive: bool,
    skip_repos: bool,
    skip_docker: bool,
) -> None:
    """Initialize a new Odoo development environment.

    Creates directory structure, .env file, docker-compose.yml,
    virtual environment, and optionally clones repositories.

    Example: odoodev init 18
    """
    version = resolve_version(ctx, version)
    versions = load_versions()
    version_cfg = get_version(version, versions)

    # Check optional system prerequisites
    from odoodev.core.prerequisites import check_node, check_node_packages, check_system_libs, check_wkhtmltopdf

    print_info("Checking system prerequisites...")
    check_wkhtmltopdf()
    check_node()
    check_node_packages()
    check_system_libs()

    print_info(f"Initializing Odoo v{version} native development environment")

    # Step 1: Create directories
    dirs_to_create = [
        version_cfg.paths.base_expanded,
        version_cfg.paths.dev_dir,
        version_cfg.paths.native_dir,
        version_cfg.paths.myconfs_dir,
    ]

    for d in dirs_to_create:
        if not os.path.exists(d):
            os.makedirs(d, exist_ok=True)
            print_info(f"Created: {d}")

    native_dir = version_cfg.paths.native_dir

    # Step 1.5: Copy example templates if missing, detect outdated ones
    from odoodev.core.example_templates import copy_example_templates, replace_example_template

    copied, outdated = copy_example_templates(version, version_cfg)
    if copied:
        for name, path in copied.items():
            print_info(f"Example template copied: {name} → {path}")
        print_info("Customize these files for your project.")

    if outdated:
        for name, path in outdated.items():
            print_warning(f"Bundled template differs from existing: {name}")
            if not non_interactive and confirm(f"Replace {name} with bundled version?"):
                replace_example_template(version, version_cfg, name)
                print_success(f"Replaced: {name} → {path}")
            else:
                print_info(f"Keeping existing: {path}")

    # Step 2: Create .env
    env_file = os.path.join(native_dir, ".env")
    if os.path.exists(env_file):
        print_info(f".env already exists at {env_file}")
    else:
        print_info("Creating .env file...")
        ctx.invoke(
            _get_env_setup_cmd(),
            version=version,
            non_interactive=non_interactive,
        )

    # Step 3: Create docker-compose.yml
    compose_file = os.path.join(native_dir, "docker-compose.yml")
    if os.path.exists(compose_file):
        print_info(f"docker-compose.yml already exists at {compose_file}")
    else:
        print_info("Creating docker-compose.yml...")
        user = detect_user()
        docker_platform = detect_docker_platform()
        content = render_compose(version_cfg, user, docker_platform)
        with open(compose_file, "w", encoding="utf-8") as f:
            f.write(content)
        print_success(f"docker-compose.yml created at {compose_file}")

    # Step 4: Start Docker services
    if not skip_docker:
        from odoodev.core.migration_config import get_active_group

        _mig = get_active_group()
        if _mig and _mig.to_version == version:
            print_warning(
                f"[MIGRATION] v{version} shares v{_mig.from_version}'s PostgreSQL container "
                f"(port {_mig.shared_db_port}). Skipping Docker startup for v{version}."
            )
            print_info(f"Start the shared container with: odoodev docker up {_mig.from_version}")
        else:
            if non_interactive or confirm("Start Docker services (PostgreSQL)?"):
                print_info("Starting Docker services...")
                import subprocess

                result = subprocess.run(["docker", "compose", "up", "-d"], cwd=native_dir)
                if result.returncode == 0:
                    if _mig and _mig.from_version == version:
                        print_success(f"Docker services started (shared with migration target v{_mig.to_version})")
                    else:
                        print_success("Docker services started")
                else:
                    print_warning("Docker services failed to start — continue manually")

    # Step 5: Create virtual environment
    venv_dir = os.path.join(native_dir, ".venv")
    if os.path.exists(venv_dir):
        # Check if venv Python version matches configuration
        from odoodev.core.venv_manager import check_venv_python_matches, get_venv_python_version

        actual_python = get_venv_python_version(venv_dir)
        expected_python = version_cfg.python
        if actual_python and not check_venv_python_matches(venv_dir, expected_python):
            print_warning(f"Venv Python version mismatch: found {actual_python}, expected {expected_python}")
            if non_interactive or confirm("Recreate venv with correct Python version?"):
                print_info(f"Recreating venv with Python {expected_python}...")
                ctx.invoke(
                    _get_venv_setup_cmd(),
                    version=version,
                    force=True,
                )
            else:
                print_warning("Keeping mismatched venv — packages may fail to install")
        else:
            print_info(f"Virtual environment already exists at {venv_dir}")
            # Check if requirements.txt has changed since last install
            requirements = os.path.join(native_dir, "requirements.txt")
            if os.path.exists(requirements):
                from odoodev.core.venv_manager import check_requirements_changed

                if check_requirements_changed(venv_dir, requirements):
                    print_warning("requirements.txt has changed since last install")
                    if not non_interactive and confirm("Update packages now?"):
                        import subprocess

                        result = subprocess.run(
                            ["uv", "pip", "install", "-r", requirements],
                            env={**os.environ, "VIRTUAL_ENV": venv_dir},
                        )
                        if result.returncode == 0:
                            from odoodev.core.venv_manager import store_requirements_hash

                            store_requirements_hash(venv_dir, requirements)
                            print_success("Packages updated and hash stored")
                        else:
                            print_warning("Package update failed — continue manually")
    else:
        if non_interactive or confirm("Create virtual environment?"):
            print_info("Creating virtual environment...")
            ctx.invoke(
                _get_venv_setup_cmd(),
                version=version,
                force=False,
            )

    # Step 5.5: Ensure setuptools for Odoo v16/v17 (pkg_resources removed in Python 3.12+)
    if os.path.isdir(venv_dir):
        try:
            ver_int = int(version)
        except (ValueError, TypeError):
            ver_int = 0
        if ver_int in (16, 17):
            from odoodev.core.venv_manager import ensure_setuptools

            print_info("Ensuring setuptools (required for Odoo v16/v17)...")
            if ensure_setuptools(venv_dir):
                print_success("setuptools available")
            else:
                print_warning("Failed to install setuptools — run manually: uv pip install --reinstall setuptools")

    # Step 6: Clone repositories
    if not skip_repos:
        if non_interactive or confirm("Clone/update repositories?"):
            print_info("Cloning repositories...")
            ctx.invoke(
                _get_repos_cmd(),
                version=version,
                init_mode=True,
            )

    print_success(f"Odoo v{version} environment initialized at {native_dir}")
    print_info(f"Next: odoodev start {version}")


def _get_env_setup_cmd():
    """Lazy import to avoid circular imports."""
    from odoodev.commands.env import env_setup

    return env_setup


def _get_venv_setup_cmd():
    """Lazy import to avoid circular imports."""
    from odoodev.commands.venv import venv_setup

    return venv_setup


def _get_repos_cmd():
    """Lazy import to avoid circular imports."""
    from odoodev.commands.repos import repos

    return repos
