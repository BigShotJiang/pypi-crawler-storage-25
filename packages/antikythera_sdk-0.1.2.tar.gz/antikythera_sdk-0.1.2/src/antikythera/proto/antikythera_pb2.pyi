import datetime

from google.protobuf import timestamp_pb2 as _timestamp_pb2
from compas_pb.generated import message_pb2 as _message_pb2
from google.protobuf.internal import containers as _containers
from google.protobuf.internal import enum_type_wrapper as _enum_type_wrapper
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Iterable as _Iterable, Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class ExecutionMode(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    EXECUTION_MODE_EXCLUSIVE: _ClassVar[ExecutionMode]
    EXECUTION_MODE_COMPETITIVE: _ClassVar[ExecutionMode]

class TaskState(int, metaclass=_enum_type_wrapper.EnumTypeWrapper):
    __slots__ = ()
    TASK_STATE_UNSPECIFIED: _ClassVar[TaskState]
    TASK_STATE_PENDING: _ClassVar[TaskState]
    TASK_STATE_READY: _ClassVar[TaskState]
    TASK_STATE_RUNNING: _ClassVar[TaskState]
    TASK_STATE_SUCCEEDED: _ClassVar[TaskState]
    TASK_STATE_FAILED: _ClassVar[TaskState]
EXECUTION_MODE_EXCLUSIVE: ExecutionMode
EXECUTION_MODE_COMPETITIVE: ExecutionMode
TASK_STATE_UNSPECIFIED: TaskState
TASK_STATE_PENDING: TaskState
TASK_STATE_READY: TaskState
TASK_STATE_RUNNING: TaskState
TASK_STATE_SUCCEEDED: TaskState
TASK_STATE_FAILED: TaskState

class TaskAssignmentMessage(_message.Message):
    __slots__ = ("id", "type", "inputs", "output_keys", "params", "timestamp", "execution_mode", "context")
    class InputsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _message_pb2.AnyData
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_message_pb2.AnyData, _Mapping]] = ...) -> None: ...
    class ParamsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _message_pb2.AnyData
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_message_pb2.AnyData, _Mapping]] = ...) -> None: ...
    class ContextEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _message_pb2.AnyData
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_message_pb2.AnyData, _Mapping]] = ...) -> None: ...
    ID_FIELD_NUMBER: _ClassVar[int]
    TYPE_FIELD_NUMBER: _ClassVar[int]
    INPUTS_FIELD_NUMBER: _ClassVar[int]
    OUTPUT_KEYS_FIELD_NUMBER: _ClassVar[int]
    PARAMS_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    EXECUTION_MODE_FIELD_NUMBER: _ClassVar[int]
    CONTEXT_FIELD_NUMBER: _ClassVar[int]
    id: str
    type: str
    inputs: _containers.MessageMap[str, _message_pb2.AnyData]
    output_keys: _containers.RepeatedScalarFieldContainer[str]
    params: _containers.MessageMap[str, _message_pb2.AnyData]
    timestamp: _timestamp_pb2.Timestamp
    execution_mode: ExecutionMode
    context: _containers.MessageMap[str, _message_pb2.AnyData]
    def __init__(self, id: _Optional[str] = ..., type: _Optional[str] = ..., inputs: _Optional[_Mapping[str, _message_pb2.AnyData]] = ..., output_keys: _Optional[_Iterable[str]] = ..., params: _Optional[_Mapping[str, _message_pb2.AnyData]] = ..., timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., execution_mode: _Optional[_Union[ExecutionMode, str]] = ..., context: _Optional[_Mapping[str, _message_pb2.AnyData]] = ...) -> None: ...

class TaskClaimRequest(_message.Message):
    __slots__ = ("task_id", "agent_id", "timestamp")
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    agent_id: str
    timestamp: _timestamp_pb2.Timestamp
    def __init__(self, task_id: _Optional[str] = ..., agent_id: _Optional[str] = ..., timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class TaskAllocationMessage(_message.Message):
    __slots__ = ("task_id", "assigned_agent_id", "timestamp")
    TASK_ID_FIELD_NUMBER: _ClassVar[int]
    ASSIGNED_AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    task_id: str
    assigned_agent_id: str
    timestamp: _timestamp_pb2.Timestamp
    def __init__(self, task_id: _Optional[str] = ..., assigned_agent_id: _Optional[str] = ..., timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class TaskStatusUpdateMessage(_message.Message):
    __slots__ = ("id", "state", "agent_id", "data", "timestamp")
    ID_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    DATA_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    id: str
    state: TaskState
    agent_id: str
    data: _message_pb2.AnyData
    timestamp: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., state: _Optional[_Union[TaskState, str]] = ..., agent_id: _Optional[str] = ..., data: _Optional[_Union[_message_pb2.AnyData, _Mapping]] = ..., timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class TaskCompletionMessage(_message.Message):
    __slots__ = ("id", "state", "agent_id", "outputs", "error", "timestamp", "duration_ms")
    class OutputsEntry(_message.Message):
        __slots__ = ("key", "value")
        KEY_FIELD_NUMBER: _ClassVar[int]
        VALUE_FIELD_NUMBER: _ClassVar[int]
        key: str
        value: _message_pb2.AnyData
        def __init__(self, key: _Optional[str] = ..., value: _Optional[_Union[_message_pb2.AnyData, _Mapping]] = ...) -> None: ...
    ID_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    OUTPUTS_FIELD_NUMBER: _ClassVar[int]
    ERROR_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    DURATION_MS_FIELD_NUMBER: _ClassVar[int]
    id: str
    state: TaskState
    agent_id: str
    outputs: _containers.MessageMap[str, _message_pb2.AnyData]
    error: TaskError
    timestamp: _timestamp_pb2.Timestamp
    duration_ms: int
    def __init__(self, id: _Optional[str] = ..., state: _Optional[_Union[TaskState, str]] = ..., agent_id: _Optional[str] = ..., outputs: _Optional[_Mapping[str, _message_pb2.AnyData]] = ..., error: _Optional[_Union[TaskError, _Mapping]] = ..., timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ..., duration_ms: _Optional[int] = ...) -> None: ...

class TaskCompletionAckMessage(_message.Message):
    __slots__ = ("id", "state", "accepted_agent_id", "timestamp")
    ID_FIELD_NUMBER: _ClassVar[int]
    STATE_FIELD_NUMBER: _ClassVar[int]
    ACCEPTED_AGENT_ID_FIELD_NUMBER: _ClassVar[int]
    TIMESTAMP_FIELD_NUMBER: _ClassVar[int]
    id: str
    state: TaskState
    accepted_agent_id: str
    timestamp: _timestamp_pb2.Timestamp
    def __init__(self, id: _Optional[str] = ..., state: _Optional[_Union[TaskState, str]] = ..., accepted_agent_id: _Optional[str] = ..., timestamp: _Optional[_Union[datetime.datetime, _timestamp_pb2.Timestamp, _Mapping]] = ...) -> None: ...

class TaskError(_message.Message):
    __slots__ = ("code", "message", "details")
    CODE_FIELD_NUMBER: _ClassVar[int]
    MESSAGE_FIELD_NUMBER: _ClassVar[int]
    DETAILS_FIELD_NUMBER: _ClassVar[int]
    code: str
    message: str
    details: _message_pb2.AnyData
    def __init__(self, code: _Optional[str] = ..., message: _Optional[str] = ..., details: _Optional[_Union[_message_pb2.AnyData, _Mapping]] = ...) -> None: ...
