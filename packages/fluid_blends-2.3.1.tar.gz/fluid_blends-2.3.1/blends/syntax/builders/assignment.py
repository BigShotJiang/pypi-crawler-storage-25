from blends.ctx import ctx
from blends.models import (
    Language,
    NId,
)
from blends.stack.edges import (
    Edge,
    add_edge,
)
from blends.stack.node_helpers import (
    pop_scoped_symbol_node_attributes,
    pop_symbol_node_attributes,
)
from blends.syntax.builders.utils import (
    add_pattern_binding_nodes,
    bound_identifier_symbol,
    get_next_binding_precedence,
    setup_scope_index_binding,
)
from blends.syntax.metadata.java import (
    del_metadata_instance,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def _emit_assignment_stack_node(args: SyntaxGraphArgs, var_id: NId) -> None:
    if (symbol := bound_identifier_symbol(args, var_id=var_id)) is not None:
        precedence = get_next_binding_precedence(args)
        if args.stack_graph is not None:
            args.stack_graph.add_node(
                args.n_id,
                **pop_scoped_symbol_node_attributes(symbol=symbol, precedence=precedence),
            )
            scope_stack = args.metadata.setdefault("scope_stack", [])
            if scope_stack and (parent_scope := scope_stack[-1]):
                add_edge(
                    args.stack_graph,
                    Edge(source=parent_scope, sink=args.n_id, precedence=precedence),
                )
    else:
        add_pattern_binding_nodes(args, var_id=var_id)


def _emit_class_attr_pop(args: SyntaxGraphArgs, member_name: str, class_scope_nid: NId) -> None:
    if args.stack_graph is None:
        return
    precedence = get_next_binding_precedence(args)
    args.stack_graph.add_node(
        args.n_id,
        **pop_symbol_node_attributes(symbol=member_name, precedence=precedence, is_definition=True),
    )
    add_edge(
        args.stack_graph,
        Edge(source=class_scope_nid, sink=args.n_id, precedence=precedence),
    )


def build_assignment_node(
    args: SyntaxGraphArgs,
    var_id: NId,
    val_id: NId,
    operator: str | None,
    *,
    class_attr_pop: tuple[str, NId] | None = None,
) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        variable_id=var_id,
        value_id=val_id,
        label_type="Assignment",
    )

    if operator:
        args.syntax_graph.update_node_attribute(args.n_id, "operator", operator)

    args.syntax_graph.add_edge(
        args.n_id,
        args.generic(args.fork_n_id(var_id)),
        label_ast="AST",
    )

    if val_id:
        args.syntax_graph.add_edge(
            args.n_id,
            args.generic(args.fork_n_id(val_id)),
            label_ast="AST",
        )

    if (args.syntax_graph.nodes.get(0)) and args.language == Language.JAVA and val_id:
        del_metadata_instance(args, var_id, val_id)

    setup_scope_index_binding(args, var_id)

    if ctx.has_feature_flag("StackGraph"):
        _emit_assignment_stack_node(args, var_id)
        if class_attr_pop is not None:
            _emit_class_attr_pop(args, *class_attr_pop)

    return args.n_id
