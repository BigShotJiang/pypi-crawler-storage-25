from __future__ import annotations

from typing import TYPE_CHECKING

from blends.ctx import ctx
from blends.stack.attributes import STACK_GRAPH_IS_DEFINITION, STACK_GRAPH_SYMBOL
from blends.stack.edges import Edge, add_edge
from blends.stack.node_helpers import pop_scoped_symbol_node_attributes
from blends.syntax.builders.import_module import (
    build_import_module_node,
)
from blends.syntax.builders.utils import get_next_binding_precedence

if TYPE_CHECKING:
    from collections.abc import Sequence

    from blends.models import NId, StackGraph
    from blends.syntax.models import SyntaxGraphArgs


def _def_nid_for_scope(stack_graph: StackGraph, scope_nid: NId) -> NId | None:
    if not stack_graph.has_node(scope_nid):
        return None
    for pred_nid in stack_graph.predecessors(scope_nid):
        if stack_graph.nodes[pred_nid].get(STACK_GRAPH_IS_DEFINITION) is True:
            return pred_nid
    return None


def _def_nid_for_symbol(stack_graph: StackGraph, scope_nid: NId, symbol: str) -> NId | None:
    if not stack_graph.has_node(scope_nid):
        return None
    for succ_nid in stack_graph.successors(scope_nid):
        node = stack_graph.nodes[succ_nid]
        if node.get(STACK_GRAPH_IS_DEFINITION) is True and node.get(STACK_GRAPH_SYMBOL) == symbol:
            return succ_nid
    return None


def _wire_pop_default(args: SyntaxGraphArgs, default_keyword_nid: NId) -> NId | None:
    scope_stack: list[NId] = args.metadata.get("scope_stack", [])
    if not scope_stack or args.stack_graph is None:
        return None
    parent_scope = scope_stack[-1]
    precedence = get_next_binding_precedence(args)
    attrs = pop_scoped_symbol_node_attributes(symbol="default", precedence=precedence)
    args.stack_graph.add_node(default_keyword_nid, **attrs)
    add_edge(
        args.stack_graph, Edge(source=parent_scope, sink=default_keyword_nid, precedence=precedence)
    )
    return parent_scope


def _emit_default_pop_node(
    args: SyntaxGraphArgs,
    default_keyword_nid: NId,
    exported_block: NId,
) -> None:
    if _wire_pop_default(args, default_keyword_nid) is None or args.stack_graph is None:
        return
    def_nid = _def_nid_for_scope(args.stack_graph, exported_block)
    if def_nid is not None:
        add_edge(args.stack_graph, Edge(source=default_keyword_nid, sink=def_nid, precedence=0))


def _emit_default_identifier_node(
    args: SyntaxGraphArgs,
    default_keyword_nid: NId,
    expression: str,
) -> None:
    parent_scope = _wire_pop_default(args, default_keyword_nid)
    if parent_scope is None or args.stack_graph is None:
        return
    def_nid = _def_nid_for_symbol(args.stack_graph, parent_scope, expression)
    if def_nid is not None:
        add_edge(args.stack_graph, Edge(source=default_keyword_nid, sink=def_nid, precedence=0))


def build_export_statement_node(
    args: SyntaxGraphArgs,
    expression: str | None,
    exported_block: NId | None,
    reexport_specifiers: Sequence[tuple[NId, str, str | None, str]] = (),
    *,
    default_export: tuple[NId, NId | None] | None = None,
) -> NId:
    args.syntax_graph.add_node(
        args.n_id,
        label_type="Export",
    )

    if expression:
        args.syntax_graph.update_node_attribute(args.n_id, "expression", expression)

    if exported_block:
        args.syntax_graph.update_node_attribute(args.n_id, "declaration_id", exported_block)
        args.syntax_graph.add_edge(
            args.n_id,
            args.generic(args.fork_n_id(exported_block)),
            label_ast="AST",
        )

    if reexport_specifiers:
        for spec_n_id, expr, alias, module_path in reexport_specifiers:
            build_import_module_node(
                args.fork_n_id(spec_n_id),
                expression=expr,
                alias=alias,
                module_path=module_path,
            )

    if default_export is not None:
        default_keyword_nid, identifier_nid = default_export
        args.syntax_graph.add_node(default_keyword_nid, label_type="default")
        if ctx.has_feature_flag("StackGraph") and exported_block is not None:
            _emit_default_pop_node(args, default_keyword_nid, exported_block)
        elif ctx.has_feature_flag("StackGraph") and identifier_nid is not None and expression:
            _emit_default_identifier_node(args, default_keyword_nid, expression)

    return args.n_id
