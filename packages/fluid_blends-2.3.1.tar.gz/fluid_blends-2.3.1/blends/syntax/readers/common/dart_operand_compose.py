from blends.models import (
    Graph,
    NId,
)
from blends.query import (
    adj_ast,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.syntax.readers.common.dart_accessor_chain import (
    try_build_accessor_chain,
)


def _is_null_assertion_selector(graph: Graph, selector_id: NId) -> bool:
    children = adj_ast(graph, selector_id)
    return len(children) == 1 and graph.nodes[children[0]]["label_type"] == "!"


def try_build_operand_chain(
    args: SyntaxGraphArgs,
    graph: Graph,
    chunk: list[NId],
) -> NId | None:
    if len(chunk) == 1:
        return None
    identifier_id = chunk[0]
    if graph.nodes[identifier_id]["label_type"] != "identifier":
        return None
    selectors = [
        c
        for c in chunk[1:]
        if graph.nodes[c]["label_type"] == "selector" and not _is_null_assertion_selector(graph, c)
    ]
    if not selectors:
        return None
    symbol = graph.nodes[identifier_id]["label_text"]
    chain_args = args.fork_n_id(selectors[-1])
    return try_build_accessor_chain(
        chain_args,
        graph,
        symbol,
        identifier_id,
        selectors,
    )
