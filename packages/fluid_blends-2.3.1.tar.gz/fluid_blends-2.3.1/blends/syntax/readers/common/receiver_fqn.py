from blends.models import (
    SyntaxGraph,
)

_TYPE_BEARING_NODES = frozenset({"VariableDeclaration", "Parameter"})


def fqn_from_graph_imports(sg: SyntaxGraph, name: str) -> str | None:
    for node in sg.nodes.values():
        if node.get("label_type") not in ("Import", "ModuleImport"):
            continue
        expr = node.get("expression")
        if not isinstance(expr, str) or not expr or expr.endswith(".*"):
            continue
        if expr.rsplit(".", maxsplit=1)[-1] == name:
            return expr
    return None


def fqn_from_graph_variable_type(sg: SyntaxGraph, symbol: str) -> str | None:
    for nids in sg.symbol_index.get(symbol, {}).values():
        for nid in nids:
            node = sg.nodes.get(nid, {})
            if node.get("label_type") not in _TYPE_BEARING_NODES:
                continue
            var_type = node.get("variable_type")
            if not isinstance(var_type, str) or not var_type:
                continue
            if "." in var_type:
                return var_type
            if fqn := fqn_from_graph_imports(sg, var_type):
                return fqn
    return None


def receiver_fqn_from_graph_symbol(sg: SyntaxGraph, symbol: str) -> str | None:
    if fqn := fqn_from_graph_imports(sg, symbol):
        return fqn
    return fqn_from_graph_variable_type(sg, symbol)
