from blends.models import (
    NId,
)
from blends.query import (
    pred_ast,
)
from blends.syntax.builders.parameter import (
    build_parameter_node,
)
from blends.syntax.builders.symbol_lookup import (
    build_symbol_lookup_node,
)
from blends.syntax.builders.variable_declaration import (
    build_variable_declaration_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def reader(args: SyntaxGraphArgs) -> NId:
    parent_id = pred_ast(args.ast_graph, args.n_id)[0]
    symbol = node_to_str(args.ast_graph, args.n_id)
    parent_node = args.ast_graph.nodes[parent_id]
    if parent_node.get("label_type") == "formal_parameters":
        return build_parameter_node(args=args, variable=symbol, variable_type=None, value_id=None)
    if (
        parent_node.get("label_type") == "object_pattern"
        and (possible_var_id := pred_ast(args.ast_graph, parent_id)[0])
        and args.ast_graph.nodes[possible_var_id].get("label_type") == "variable_declarator"
    ):
        return build_variable_declaration_node(args, symbol, None, None, wire_stack_graph=False)
    return build_symbol_lookup_node(args, symbol)
