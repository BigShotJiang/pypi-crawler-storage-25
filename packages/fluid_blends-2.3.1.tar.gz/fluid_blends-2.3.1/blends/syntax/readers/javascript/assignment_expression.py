from blends.ctx import ctx
from blends.models import (
    NId,
)
from blends.syntax.builders.assignment import (
    build_assignment_node,
)
from blends.syntax.builders.utils import (
    get_enclosing_class_scope,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def _detect_class_attr_lhs(args: SyntaxGraphArgs, var_id: NId) -> tuple[str, NId] | None:
    class_scope_nid = get_enclosing_class_scope(args)
    if class_scope_nid is None:
        return None
    var_node = args.ast_graph.nodes.get(var_id, {})
    if var_node.get("label_type") != "member_expression":
        return None
    obj_id = var_node.get("label_field_object")
    prop_id = var_node.get("label_field_property")
    if not (obj_id and prop_id):
        return None
    if args.ast_graph.nodes.get(obj_id, {}).get("label_type") != "this":
        return None
    member = node_to_str(args.ast_graph, prop_id)
    return (member, class_scope_nid) if member else None


def reader(args: SyntaxGraphArgs) -> NId:
    n_attrs = args.ast_graph.nodes[args.n_id]
    var_id = n_attrs["label_field_left"]
    val_id = n_attrs["label_field_right"]
    if op_id := n_attrs.get("label_field_operator"):
        operator = node_to_str(args.ast_graph, op_id)
    else:
        operator = None

    class_attr_pop = (
        _detect_class_attr_lhs(args, var_id) if ctx.has_feature_flag("StackGraph") else None
    )
    return build_assignment_node(args, var_id, val_id, operator, class_attr_pop=class_attr_pop)
