from blends.models import (
    NId,
)
from blends.query import (
    match_ast_group_d,
)
from blends.syntax.builders.export_statement import (
    build_export_statement_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    expression = None
    export_block = graph.nodes[args.n_id].get("label_field_declaration")
    identifier_nid: NId | None = None

    if export_block and (lt := graph.nodes[export_block]["label_type"]) in {
        "identifier",
        "string",
    }:
        expression = node_to_str(args.ast_graph, export_block)
        identifier_nid = export_block if lt == "identifier" else None
        export_block = None
    elif export_block is None:
        for child_id in match_ast_group_d(graph, args.n_id, "identifier"):
            expression = node_to_str(args.ast_graph, child_id)
            identifier_nid = child_id
            break

    reexport_specifiers: list[tuple[NId, str, str | None, str]] = []
    if source_n_id := graph.nodes[args.n_id].get("label_field_source"):
        module_path = node_to_str(graph, source_n_id)[1:-1]
        for clause_id in match_ast_group_d(graph, args.n_id, "export_clause"):
            for spec_n_id in match_ast_group_d(graph, clause_id, "export_specifier"):
                name_n_id = graph.nodes[spec_n_id].get("label_field_name")
                if name_n_id is None:
                    continue
                spec_name = graph.nodes[name_n_id].get("label_text", "")
                alias_n_id = graph.nodes[spec_n_id].get("label_field_alias")
                spec_alias = (
                    graph.nodes[alias_n_id].get("label_text")
                    if alias_n_id is not None
                    else spec_name
                )
                reexport_specifiers.append(
                    (spec_n_id, f"{module_path}.{spec_name}", spec_alias, module_path)
                )

    default_keyword_nid = next(iter(match_ast_group_d(graph, args.n_id, "default")), None)
    default_export = (
        (default_keyword_nid, identifier_nid) if default_keyword_nid is not None else None
    )
    return build_export_statement_node(
        args,
        expression,
        export_block,
        reexport_specifiers,
        default_export=default_export,
    )
