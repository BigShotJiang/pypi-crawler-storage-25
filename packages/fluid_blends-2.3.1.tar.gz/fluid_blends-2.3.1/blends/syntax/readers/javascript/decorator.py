from blends.models import NId
from blends.query import adj_ast
from blends.syntax.builders.modifiers import build_modifiers_node
from blends.syntax.models import SyntaxGraphArgs


def reader(args: SyntaxGraphArgs) -> NId:
    childs = adj_ast(args.ast_graph, args.n_id)
    return build_modifiers_node(args, [childs[-1]])
