from blends.models import (
    NId,
    SyntaxGraph,
)
from blends.query import (
    match_ast,
)
from blends.syntax.builders.method_invocation import (
    DirectChildren,
    build_method_invocation_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.syntax.node_attributes_types import SyntaxNodeAttrs
from blends.syntax.readers.common.receiver_fqn import (
    receiver_fqn_from_graph_symbol,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def _enclosing_class_fqn(args: SyntaxGraphArgs) -> str | None:
    file_node: SyntaxNodeAttrs | None = args.syntax_graph.nodes.get(0)
    class_path = args.metadata.get("class_path") or []
    if not class_path:
        return None
    class_name = ".".join(class_path)
    package = (file_node or {}).get("package")
    return f"{package}.{class_name}" if package else class_name


def _fqn_from_imports(file_node: SyntaxNodeAttrs, symbol: str) -> str | None:
    for imp in file_node.get("imports", []):
        if not isinstance(imp, str) or imp.endswith(".*"):
            continue
        if imp.rsplit(".", maxsplit=1)[-1] == symbol:
            return imp
    return None


def _fqn_from_instances(
    file_node: SyntaxNodeAttrs,
    class_path: list[str],
    symbol: str,
) -> str | None:
    if not class_path:
        return None
    instances = file_node.get("instances") or {}
    entry = instances.get(class_path[-1], {}).get(symbol)
    if not entry or entry.get("source_type") != "package":
        return None
    source = entry.get("source") or ""
    obj = entry.get("object") or ""
    if source and obj:
        return f"{source}.{obj}"
    return None


def _receiver_fqn_from_symbol(args: SyntaxGraphArgs, symbol: str) -> str | None:
    file_node = args.syntax_graph.nodes.get(0)
    if file_node is not None:
        fqn = _fqn_from_imports(file_node, symbol)
        if fqn:
            return fqn
        return _fqn_from_instances(file_node, args.metadata.get("class_path") or [], symbol)
    return receiver_fqn_from_graph_symbol(args.syntax_graph, symbol)


def _receiver_fqn_from_object_creation(
    args: SyntaxGraphArgs,
    node: SyntaxNodeAttrs,
) -> str | None:
    raw = node.get("name")
    if not raw:
        return None
    name_str = str(raw)
    if "." in name_str:
        return name_str
    return _receiver_fqn_from_symbol(args, name_str)


def _receiver_fqn_from_object(
    args: SyntaxGraphArgs,
    sg: SyntaxGraph,
    object_id: NId,
) -> str | None:
    node = sg.nodes.get(object_id)
    if not node:
        return None
    label = str(node.get("label_type") or "")
    if label == "This":
        return _enclosing_class_fqn(args)
    if label == "SymbolLookup":
        raw = node.get("symbol") or node.get("value")
        return _receiver_fqn_from_symbol(args, str(raw)) if raw else None
    if label == "ObjectCreation":
        return _receiver_fqn_from_object_creation(args, node)
    if label == "MethodInvocation":
        inner = node.get("receiver_type_fqn")
        return str(inner) if inner else None
    return None


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    expr_id = graph.nodes[args.n_id]["label_field_name"]

    raw_arguments_id: NId = graph.nodes[args.n_id]["label_field_arguments"]
    arguments_id: NId | None = (
        raw_arguments_id
        if "__0__" in match_ast(args.ast_graph, raw_arguments_id, "(", ")")
        else None
    )

    expr = node_to_str(graph, expr_id)
    children: DirectChildren = {"expression_id": expr_id}
    if arguments_id:
        children["arguments_id"] = arguments_id

    object_name: str | None = None
    object_id = graph.nodes[args.n_id].get("label_field_object")
    if object_id:
        children["object_id"] = object_id
        if graph.nodes[object_id]["label_type"] == "object_creation_expression":
            object_name = node_to_str(graph, graph.nodes[object_id]["label_field_type"])

    nid = build_method_invocation_node(args, expr, children, object_name)

    sg = args.syntax_graph
    if object_id is not None:
        receiver_fqn = _receiver_fqn_from_object(args, sg, object_id)
    else:
        receiver_fqn = _enclosing_class_fqn(args)
    if receiver_fqn:
        sg.update_node_attribute(nid, "receiver_type_fqn", receiver_fqn)

    return nid
