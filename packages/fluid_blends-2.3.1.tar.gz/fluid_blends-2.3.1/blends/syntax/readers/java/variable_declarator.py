from blends.models import (
    NId,
)
from blends.query import (
    pred_ast,
)
from blends.syntax.builders.variable_declaration import (
    build_variable_declaration_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def _var_type_from_field_declaration(args: SyntaxGraphArgs) -> str | None:
    parents = pred_ast(args.ast_graph, args.n_id)
    if not parents:
        return None
    parent = args.ast_graph.nodes[parents[0]]
    if parent.get("label_type") != "field_declaration":
        return None
    type_id = parent.get("label_field_type")
    if type_id is None:
        return None
    return node_to_str(args.ast_graph, type_id)


def reader(args: SyntaxGraphArgs) -> NId:
    n_attrs = args.ast_graph.nodes[args.n_id]
    var_name = node_to_str(args.ast_graph, n_attrs["label_field_name"])
    val_id = n_attrs.get("label_field_value")
    var_type = _var_type_from_field_declaration(args)
    return build_variable_declaration_node(args, var_name, var_type, val_id)
