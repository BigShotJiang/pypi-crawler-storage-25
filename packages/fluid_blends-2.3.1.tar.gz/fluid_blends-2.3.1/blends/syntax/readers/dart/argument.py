from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
    match_ast_d,
)
from blends.syntax.builders.argument import (
    build_argument_node,
)
from blends.syntax.builders.named_argument import (
    build_named_argument_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.syntax.readers.common.dart_operand_compose import (
    try_build_operand_chain,
)
from blends.utilities.text_nodes import (
    node_to_str,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    c_ids = list(adj_ast(graph, args.n_id))

    if len(c_ids) == 1:
        return args.generic(args.fork_n_id(c_ids[0]))

    if label_id := match_ast_d(graph, args.n_id, "label"):
        var_id = adj_ast(graph, label_id)[0]
        arg_name = node_to_str(graph, var_id)
        value_id = try_build_operand_chain(args, graph, c_ids[1:]) or c_ids[1]
        return build_named_argument_node(args, arg_name, value_id)

    if composed := try_build_operand_chain(args, graph, c_ids):
        return composed

    return build_argument_node(args, iter(c_ids))
