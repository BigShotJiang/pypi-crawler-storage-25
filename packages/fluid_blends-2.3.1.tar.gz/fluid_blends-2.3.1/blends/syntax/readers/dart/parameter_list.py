from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
    match_ast_group_d,
)
from blends.syntax.builders.parameter_list import (
    build_parameter_list_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    ignored_labels = {"(", ")", ",", "[", "]", "{", "}"}
    filtered_ids: list[NId] = []
    for _id in adj_ast(graph, args.n_id):
        label_type = graph.nodes[_id]["label_type"]
        if label_type in ignored_labels:
            continue
        if label_type == "optional_formal_parameters":
            filtered_ids.extend(
                match_ast_group_d(graph, _id, "formal_parameter"),
            )
            continue
        filtered_ids.append(_id)
    return build_parameter_list_node(args, filtered_ids)
