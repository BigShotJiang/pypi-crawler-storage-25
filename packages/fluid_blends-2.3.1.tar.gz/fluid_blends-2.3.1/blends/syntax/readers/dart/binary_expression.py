from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
)
from blends.syntax.builders.binary_operation import (
    build_binary_operation_node,
)
from blends.syntax.builders.expression_statement import (
    build_expression_statement_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.syntax.readers.common.dart_operand_compose import (
    try_build_operand_chain,
)
from blends.utilities.text_nodes import (
    node_to_str,
)

_EXPECTED_CHILDREN_FOR_BINARY_OPERATION = 3
_INVALID_CHILDS = {";", "type_test", "(", ")"}
_OPERATOR_LABEL_TYPES = {
    "??",
    "&",
    "|",
    "^",
    "additive_operator",
    "equality_operator",
    "logical_and_operator",
    "logical_or_operator",
    "multiplicative_operator",
    "relational_operator",
    "shift_operator",
}


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    c_ids = adj_ast(graph, args.n_id)

    if len(c_ids) == _EXPECTED_CHILDREN_FOR_BINARY_OPERATION:
        operator = node_to_str(graph, c_ids[1])
        return build_binary_operation_node(args, operator, c_ids[0], c_ids[2])

    op_idx = next(
        (i for i, c in enumerate(c_ids) if graph.nodes[c]["label_type"] in _OPERATOR_LABEL_TYPES),
        -1,
    )
    if 0 < op_idx < len(c_ids) - 1:
        operator = node_to_str(graph, c_ids[op_idx])
        left_chunk = list(c_ids[:op_idx])
        right_chunk = list(c_ids[op_idx + 1 :])
        left_id = try_build_operand_chain(args, graph, left_chunk) or left_chunk[0]
        right_id = try_build_operand_chain(args, graph, right_chunk) or right_chunk[0]
        return build_binary_operation_node(args, operator, left_id, right_id)

    return build_expression_statement_node(
        args,
        c_ids=(_id for _id in c_ids if graph.nodes[_id]["label_type"] not in _INVALID_CHILDS),
    )
