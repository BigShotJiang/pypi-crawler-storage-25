from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
)
from blends.syntax.builders.expression_statement import (
    build_expression_statement_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.syntax.readers.common.dart_accessor_chain import (
    try_build_accessor_chain,
)
from blends.syntax.readers.common.dart_selector_invocation import (
    try_build_chained_invocation,
    try_build_simple_invocation,
)


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    c_ids = adj_ast(graph, args.n_id)
    filtered = [_id for _id in c_ids if graph.nodes[_id]["label_type"] != "await"]

    identifier_id: NId | None = None
    selectors: list[NId] = []
    for _id in filtered:
        label = graph.nodes[_id]["label_type"]
        if label == "identifier" and identifier_id is None:
            identifier_id = _id
        elif label == "selector":
            selectors.append(_id)

    if identifier_id is not None and len(filtered) == len(selectors) + 1:
        symbol = graph.nodes[identifier_id]["label_text"]

        if result := try_build_chained_invocation(args, graph, symbol, identifier_id, selectors):
            return result

        if result := try_build_simple_invocation(args, graph, symbol, selectors):
            return result

        if result := try_build_accessor_chain(args, graph, symbol, identifier_id, selectors):
            return result

    return build_expression_statement_node(args, iter(filtered))
