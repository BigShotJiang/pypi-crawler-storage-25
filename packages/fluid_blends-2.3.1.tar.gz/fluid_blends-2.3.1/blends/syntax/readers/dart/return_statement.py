from blends.models import (
    NId,
)
from blends.query import (
    adj_ast,
)
from blends.syntax.builders.return_statement import (
    build_return_node,
)
from blends.syntax.models import (
    SyntaxGraphArgs,
)
from blends.syntax.readers.common.dart_operand_compose import (
    try_build_operand_chain,
)

_RETURN_IGNORED_CHILDS = {"return", "yield", ";"}
_MIN_FOR_SELECTOR_RETURN = 3


def reader(args: SyntaxGraphArgs) -> NId:
    graph = args.ast_graph
    filtered = [
        c
        for c in adj_ast(graph, args.n_id)
        if graph.nodes[c]["label_type"] not in _RETURN_IGNORED_CHILDS
    ]

    if not filtered:
        return build_return_node(args, None)

    if composed := try_build_operand_chain(args, graph, filtered):
        return build_return_node(args, value_id=composed)

    if (
        len(filtered) >= _MIN_FOR_SELECTOR_RETURN
        and graph.nodes[filtered[1]]["label_type"] == "selector"
    ):
        return build_return_node(args, value_id=filtered[1])
    return build_return_node(args, value_id=filtered[0])
