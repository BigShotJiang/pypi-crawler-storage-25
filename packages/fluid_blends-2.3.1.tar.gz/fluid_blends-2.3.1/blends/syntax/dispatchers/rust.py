from blends.syntax.models import (
    Dispatcher,
)
from blends.syntax.readers.rust import (
    argument_list as rust_argument_list,
)
from blends.syntax.readers.rust import (
    assignment_expression as rust_assignment_expression,
)
from blends.syntax.readers.rust import (
    binary_expression as rust_binary_expression,
)
from blends.syntax.readers.rust import (
    block as rust_block,
)
from blends.syntax.readers.rust import (
    boolean_literal as rust_boolean_literal,
)
from blends.syntax.readers.rust import (
    break_expression as rust_break_expression,
)
from blends.syntax.readers.rust import (
    call_expression as rust_call_expression,
)
from blends.syntax.readers.rust import (
    comment as rust_comment,
)
from blends.syntax.readers.rust import (
    declaration_list as rust_declaration_list,
)
from blends.syntax.readers.rust import (
    field_expression as rust_field_expression,
)
from blends.syntax.readers.rust import (
    for_expression as rust_for_expression,
)
from blends.syntax.readers.rust import (
    function_item as rust_function_item,
)
from blends.syntax.readers.rust import (
    identifier as rust_identifier,
)
from blends.syntax.readers.rust import (
    if_expression as rust_if_expression,
)
from blends.syntax.readers.rust import (
    impl_item as rust_impl_item,
)
from blends.syntax.readers.rust import (
    integer_literal as rust_integer_literal,
)
from blends.syntax.readers.rust import (
    let_declaration as rust_let_declaration,
)
from blends.syntax.readers.rust import (
    loop_expression as rust_loop_expression,
)
from blends.syntax.readers.rust import (
    match_arm as rust_match_arm,
)
from blends.syntax.readers.rust import (
    match_block as rust_match_block,
)
from blends.syntax.readers.rust import (
    match_expression as rust_match_expression,
)
from blends.syntax.readers.rust import (
    parameter as rust_parameter,
)
from blends.syntax.readers.rust import (
    parameter_list as rust_parameter_list,
)
from blends.syntax.readers.rust import (
    return_expression as rust_return_expression,
)
from blends.syntax.readers.rust import (
    source_file as rust_source_file,
)
from blends.syntax.readers.rust import (
    string_literal as rust_string_literal,
)
from blends.syntax.readers.rust import (
    unary_expression as rust_unary_expression,
)
from blends.syntax.readers.rust import (
    use_declaration as rust_use_declaration,
)
from blends.syntax.readers.rust import (
    while_expression as rust_while_expression,
)

RUST_DISPATCHERS: Dispatcher = {
    "arguments": rust_argument_list.reader,
    "assignment_expression": rust_assignment_expression.reader,
    "binary_expression": rust_binary_expression.reader,
    "block": rust_block.reader,
    "block_comment": rust_comment.reader,
    "boolean_literal": rust_boolean_literal.reader,
    "break_expression": rust_break_expression.reader,
    "call_expression": rust_call_expression.reader,
    "char_literal": rust_string_literal.reader,
    "compound_assignment_expr": rust_assignment_expression.reader,
    "continue_expression": rust_break_expression.reader,
    "declaration_list": rust_declaration_list.reader,
    "field_expression": rust_field_expression.reader,
    "field_identifier": rust_identifier.reader,
    "float_literal": rust_integer_literal.reader,
    "for_expression": rust_for_expression.reader,
    "function_item": rust_function_item.reader,
    "identifier": rust_identifier.reader,
    "if_expression": rust_if_expression.reader,
    "impl_item": rust_impl_item.reader,
    "integer_literal": rust_integer_literal.reader,
    "let_declaration": rust_let_declaration.reader,
    "line_comment": rust_comment.reader,
    "loop_expression": rust_loop_expression.reader,
    "match_arm": rust_match_arm.reader,
    "match_block": rust_match_block.reader,
    "match_expression": rust_match_expression.reader,
    "parameter": rust_parameter.reader,
    "parameters": rust_parameter_list.reader,
    "raw_string_literal": rust_string_literal.reader,
    "return_expression": rust_return_expression.reader,
    "source_file": rust_source_file.reader,
    "string_literal": rust_string_literal.reader,
    "type_identifier": rust_identifier.reader,
    "unary_expression": rust_unary_expression.reader,
    "use_declaration": rust_use_declaration.reader,
    "while_expression": rust_while_expression.reader,
}
