from collections.abc import (
    Callable,
    Iterator,
)

from blends.models import (
    NId,
    SyntaxGraph,
)
from blends.query.ast_matching import match_ast_group_d
from blends.query.scope import resolve_symbol_all_scope_index
from blends.query.traversal import (
    adj_ast,
    pred_ast,
)


def _literal_binary_operation(graph: SyntaxGraph, n_id: NId, level: int) -> str | None:
    nodes = graph.nodes
    if left_n_id := nodes[n_id].get("left_id"):
        if nodes[left_n_id].get("label_type") == "Literal":
            return nodes[left_n_id].get("value")
        if nodes[left_n_id].get("label_type") == "BinaryOperation":
            return _literal_binary_operation(graph, left_n_id, level + 1)
    if (
        (right_n_id := nodes[n_id].get("right_id"))
        and level == 0
        and nodes[right_n_id].get("label_type") == "Literal"
    ):
        return nodes[right_n_id].get("value")
    return None


def _resolve_child_symbols(graph: SyntaxGraph, n_id: NId, depth: int) -> Iterator[str]:
    nodes = graph.nodes
    for child_id in match_ast_group_d(graph, n_id, "SymbolLookup", -1):
        if (parent_id := next(iter(pred_ast(graph, child_id)), None)) and (
            nodes[parent_id].get("label_type") in {"ArgumentList", "ObjectCreation"}
        ):
            continue
        definitions = resolve_symbol_all_scope_index(graph, child_id)
        for def_nid in definitions:
            yield from _resolve_value(graph, def_nid, depth)


def _check_direct_string(graph: SyntaxGraph, n_id: NId) -> str | None:
    nodes = graph.nodes
    label_type = nodes[n_id].get("label_type")

    if (
        label_type == "Literal"
        and nodes[n_id].get("value_type") != "null"
        and len(adj_ast(graph, n_id)) == 0
    ):
        return nodes[n_id].get("value")

    if (obj_id := nodes[n_id].get("object_id")) and (nodes[obj_id].get("label_type") == "Literal"):
        return nodes[obj_id].get("value")

    if label_type == "BinaryOperation":
        return _literal_binary_operation(graph, n_id, 0)

    return None


def _resolve_value(graph: SyntaxGraph, n_id: NId, depth: int) -> Iterator[str]:
    value_id = graph.nodes[n_id].get("value_id")
    if not value_id:
        return
    yield from get_string_definitions_resolver(graph, value_id, _depth=depth)


# WIP: Only works when the ScopeIndex feature flag is active.
# Do not use in production methods until ScopeIndex is fully rolled out.
def get_string_definitions_resolver(
    graph: SyntaxGraph, n_id: NId | None, *, _depth: int = 0
) -> Iterator[str]:
    """Resolve all string literals a node can trace back to.

    Uses ScopeIndex for symbol resolution instead of CFG backward paths.
    Recurses through SymbolLookup chains up to max_resolver_depth.
    Yields all resolved string values across all definitions.
    """
    max_resolver_depth = 4
    if n_id is None or _depth > max_resolver_depth:
        return

    if (result := _check_direct_string(graph, n_id)) is not None:
        yield result
        return

    if graph.nodes[n_id].get("label_type") == "SymbolLookup":
        definitions = resolve_symbol_all_scope_index(graph, n_id)
        for def_nid in definitions:
            yield from _resolve_value(graph, def_nid, _depth + 1)
        return

    yield from _resolve_child_symbols(graph, n_id, _depth + 1)


def has_any_string_definition(graph: SyntaxGraph, n_id: NId | None) -> bool:
    return next(get_string_definitions_resolver(graph, n_id), None) is not None


def is_node_definition_unsafe(
    graph: SyntaxGraph,
    n_id: NId,
    node_dangerous_condition: Callable[[SyntaxGraph, NId], bool],
    *,
    evaluate_value_definition: bool = True,
) -> bool:
    if node_dangerous_condition(graph, n_id):
        return True

    if graph.nodes[n_id].get("label_type") != "SymbolLookup":
        return False

    definitions = resolve_symbol_all_scope_index(graph, n_id)

    for def_nid in definitions:
        if evaluate_value_definition:
            if (value_id := graph.nodes[def_nid].get("value_id")) and node_dangerous_condition(
                graph, value_id
            ):
                return True
        elif node_dangerous_condition(graph, def_nid):
            return True

    return False
