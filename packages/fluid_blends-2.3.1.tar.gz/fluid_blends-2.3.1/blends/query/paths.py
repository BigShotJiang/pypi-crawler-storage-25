from collections.abc import Callable

from blends.edge_attributes_types import EdgeAttrs
from blends.models import (
    Graph,
    NId,
)
from blends.query.labels import predicate_has_edge_labels
from blends.query.traversal import (
    adj_ast,
    pred_ast,
)


def _get_subgraph(
    graph: Graph,
    node_n_id_predicate: Callable[[NId], bool] = lambda _: True,
    edge_n_attrs_predicate: Callable[[EdgeAttrs], bool] = lambda _: True,
) -> Graph:
    copy: Graph = Graph()

    for n_a_id, n_b_id in graph.edges:
        edge_attrs = graph[n_a_id][n_b_id].copy()
        n_a_attrs = graph.nodes[n_a_id].copy()
        n_b_attrs = graph.nodes[n_b_id].copy()

        if (
            edge_n_attrs_predicate(edge_attrs)
            and node_n_id_predicate(n_a_id)
            and node_n_id_predicate(n_b_id)
        ):
            copy.add_node(n_a_id, **n_a_attrs)
            copy.add_node(n_b_id, **n_b_attrs)
            copy.add_edge(n_a_id, n_b_id, **edge_attrs)

    return copy


def copy_ast(graph: Graph) -> Graph:
    return _get_subgraph(
        graph=graph,
        edge_n_attrs_predicate=predicate_has_edge_labels(label_ast="AST"),
    )


def search_pred_until_type(
    graph: Graph,
    n_id: NId,
    targets: set[str],
    last_child: NId | None = None,
) -> tuple[NId, NId] | None:
    if not last_child:
        last_child = n_id
    if pred_c := pred_ast(graph, n_id):
        if graph.nodes[pred_c[0]]["label_type"] in targets:
            return (pred_c[0], last_child)
        return search_pred_until_type(graph, pred_c[0], targets, pred_c[0])
    return None


def get_nodes_by_path(
    graph: Graph,
    n_id: NId,
    *label_type_path: str,
) -> set[NId]:
    if not label_type_path:
        return set()
    if len(label_type_path) == 1:
        return set(adj_ast(graph, n_id, label_type=label_type_path[0]))

    result: set[NId] = set()
    for node in adj_ast(graph, n_id, label_type=label_type_path[0]):
        result.update(get_nodes_by_path(graph, node, *label_type_path[1:]))
    return result


def get_node_by_path(graph: Graph, n_id: NId, *label_type_path: str) -> NId | None:
    return next(iter(get_nodes_by_path(graph, n_id, *label_type_path)), None)


def nodes_by_type(graph: Graph) -> dict[str, list[NId]]:
    return graph.nodes_by_type


def get_args_n_ids(graph: Graph, n_id: NId) -> list[NId]:
    if (args_parent_n_id := graph.nodes[n_id].get("arguments_id")) is None:
        return []
    if not isinstance(args_parent_n_id, int):
        return []
    return [
        arg_id
        for arg_id in adj_ast(graph, args_parent_n_id)
        if graph.nodes[arg_id].get("label_type") != "Comment"
    ]


def get_n_arg(graph: Graph, n_id: NId | None, arg_idx: int) -> NId | None:
    if not n_id:
        return None

    for idx, arg_id in enumerate(get_args_n_ids(graph, n_id)):
        if idx == arg_idx:
            return arg_id
    return None
