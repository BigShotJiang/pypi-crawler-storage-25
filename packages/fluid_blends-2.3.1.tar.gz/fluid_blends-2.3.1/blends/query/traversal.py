from collections.abc import Iterator

from blends.models import (
    Graph,
    NId,
)
from blends.query.labels import (
    has_edge_labels,
    has_labels,
)


def _edge_matches(
    graph: Graph,
    source: NId,
    target: NId,
    edge_keys: set[str],
    *,
    strict: bool,
    **edge_attrs: str,
) -> bool:
    if not has_edge_labels(graph[source][target], **edge_attrs):
        return False
    if strict:
        graph_edge_keys = set(graph[source][target].keys())
        difference = graph_edge_keys.difference(edge_keys)
        return not difference or difference == {"label_index"}
    return True


def adj_lazy(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    *,
    strict: bool = False,
    _processed_n_ids: set[NId] | None = None,
    **edge_attrs: str,
) -> Iterator[NId]:
    """Return adjacent nodes to `n_id`, following just edges with given attrs.

    - Parameter `depth` may be -1 to indicate infinite depth.
    - Parameter `strict` indicates that the edges must have only the indicated
      attributes

    - Search is done breadth first.
    - Nodes are returned ordered ascending by index on each level.

    This function must be used instead of graph.adj, because graph.adj
    becomes unstable (unordered) after mutating the graph, also this allow
    following just edges matching `edge_attrs`.
    """
    processed_n_ids: set[NId] = _processed_n_ids or set()
    if depth == 0 or n_id in processed_n_ids:
        return

    processed_n_ids.add(n_id)

    childs: list[NId] = sorted(graph.adj[n_id], key=int)
    edge_keys = set(edge_attrs.keys())
    matching_childs = [
        c_id
        for c_id in childs
        if _edge_matches(graph, n_id, c_id, edge_keys, strict=strict, **edge_attrs)
    ]

    yield from matching_childs

    if depth in {0, 1}:
        return

    for c_id in matching_childs:
        yield from adj_lazy(
            graph,
            c_id,
            depth=depth - 1,
            strict=strict,
            _processed_n_ids=processed_n_ids,
            **edge_attrs,
        )


def adj(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    *,
    strict: bool = False,
    _processed_n_ids: set[NId] | None = None,
    **edge_attrs: str,
) -> tuple[NId, ...]:
    return tuple(
        adj_lazy(
            graph,
            n_id,
            depth=depth,
            strict=strict,
            _processed_n_ids=_processed_n_ids,
            **edge_attrs,
        ),
    )


def adj_ast(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    *,
    strict: bool = False,
    **n_attrs: str,
) -> tuple[NId, ...]:
    return tuple(
        c_id
        for c_id in adj(graph, n_id, depth, strict=strict, label_ast="AST")
        if has_labels(graph.nodes[c_id], **n_attrs)
    )


def adj_cfg(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    *,
    strict: bool = False,
    **n_attrs: str,
) -> tuple[NId, ...]:
    return tuple(
        c_id
        for c_id in adj(graph, n_id, depth, strict=strict, label_cfg="CFG")
        if has_labels(graph.nodes[c_id], **n_attrs)
    )


def adj_cfg_lazy(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    *,
    strict: bool = False,
    **n_attrs: str,
) -> Iterator[NId]:
    yield from adj_lazy(
        graph,
        n_id,
        depth=depth,
        strict=strict,
        _processed_n_ids=set(),
        label_cfg="CFG",
        **n_attrs,
    )


def pred_lazy(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    _processed_n_ids: set[NId] | None = None,
    **edge_attrs: str,
) -> Iterator[NId]:
    """Obtain parent nodes.

    Same as `adj` but follow edges in the opposite direction
    """
    processed_n_ids: set[NId] = _processed_n_ids or set()
    if depth == 0 or n_id in processed_n_ids:
        return

    processed_n_ids.add(n_id)

    p_ids: list[NId] = sorted(graph.pred[n_id], key=int)
    matching_parents = [p_id for p_id in p_ids if has_edge_labels(graph[p_id][n_id], **edge_attrs)]

    yield from matching_parents

    if depth < 0 or depth > 1:
        for p_id in matching_parents:
            yield from pred_lazy(
                graph,
                p_id,
                depth=depth - 1,
                _processed_n_ids=processed_n_ids,
                **edge_attrs,
            )


def pred(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    _processed_n_ids: set[NId] | None = None,
    **edge_attrs: str,
) -> tuple[NId, ...]:
    return tuple(
        pred_lazy(
            graph,
            n_id,
            depth,
            _processed_n_ids=_processed_n_ids,
            **edge_attrs,
        ),
    )


def pred_ast(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    **edge_attrs: str,
) -> tuple[NId, ...]:
    return tuple(pred_ast_lazy(graph, n_id, depth, **edge_attrs))


def pred_ast_lazy(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    **edge_attrs: str,
) -> Iterator[NId]:
    yield from pred_lazy(
        graph,
        n_id,
        depth,
        _processed_n_ids=set(),
        label_ast="AST",
        **edge_attrs,
    )


def pred_cfg(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    **edge_attrs: str,
) -> tuple[NId, ...]:
    return tuple(pred_cfg_lazy(graph, n_id, depth, **edge_attrs))


def pred_cfg_lazy(
    graph: Graph,
    n_id: NId,
    depth: int = 1,
    **edge_attrs: str,
) -> Iterator[NId]:
    yield from pred_lazy(
        graph,
        n_id,
        depth,
        _processed_n_ids=set(),
        label_cfg="CFG",
        **edge_attrs,
    )
