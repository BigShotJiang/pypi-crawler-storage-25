"""
Packet type definitions for the BigWorld network protocol.

Uses the >=12.6.0 packet type mapping. Older replays may use different
values; this mapping has been verified against real post-14.6 replays.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import IntEnum
from typing import Any


class PacketType(IntEnum):
    """BigWorld packet types found in replay streams (>=12.6 mapping)."""

    BASE_PLAYER_CREATE = 0x00
    CELL_PLAYER_CREATE = 0x01
    ENTITY_CONTROL = 0x02
    ENTITY_ENTER = 0x03
    ENTITY_LEAVE = 0x04
    ENTITY_CREATE = 0x05

    ENTITY_PROPERTY = 0x07
    ENTITY_METHOD = 0x08

    POSITION = 0x0A

    SERVER_TICK = 0x0E
    SERVER_TIMESTAMP = 0x0F
    INIT_FLAG = 0x10
    INIT_MARKER = 0x13
    VERSION = 0x16
    GUN_MARKER = 0x18
    PLAYER_NET_STATS = 0x1D
    OWN_SHIP = 0x20
    BATTLE_RESULTS = 0x22
    NESTED_PROPERTY = 0x23
    CAMERA = 0x25
    BASE_PLAYER_CREATE_STUB = 0x26
    CAMERA_MODE = 0x27
    MAP = 0x28
    NON_VOLATILE_POSITION = 0x2A
    PLAYER_ORIENTATION = 0x2C
    CAMERA_FREE_LOOK = 0x2F
    SET_WEAPON_LOCK = 0x30
    SUB_CONTROLLER = 0x31
    CRUISE_STATE = 0x32
    SHOT_TRACKING = 0x33

    UNKNOWN = 0xFF


@dataclass
class Packet:
    """A decoded network packet from the replay stream."""

    type: PacketType
    entity_id: int = 0
    timestamp: float = 0.0
    raw_payload: bytes = b""

    # Decoded payload (set by packet decoder based on type)
    method_name: str | None = None
    method_args: dict[str, Any] | None = None
    property_name: str | None = None
    property_value: Any = None
    position: tuple[float, float, float] | None = None
    direction: tuple[float, float, float] | None = None
    rotation: tuple[float, float, float] | None = None
    is_on_ground: bool = False

    # EntityCreate inline state (initial property values)
    initial_properties: dict[str, Any] | None = None

    # EntityControl (0x02)
    is_controlled: bool = False

    # Version (0x16)
    version_string: str | None = None

    # OwnShip (0x20) — the Vehicle entity_id owned by the Avatar
    owned_vehicle_id: int | None = None

    # Map (0x28)
    space_id: int | None = None
    arena_id: int | None = None
    map_name: str | None = None
    map_data: bytes | None = None  # 128-byte opaque blob

    # Camera (0x25)
    camera_position: tuple[float, float, float] | None = None
    camera_rotation: tuple[float, float, float, float] | None = None
    camera_fov: float | None = None

    # GunMarker (0x18)
    gun_marker_data: bytes | None = None
    gun_marker_position: tuple[float, float, float] | None = None

    # ServerTimestamp (0x0F)
    server_time: float | None = None

    # BattleResults (0x22) — decoded dict on success, raw bytes on failure
    battle_results_data: dict[str, Any] | bytes | None = None

    # CruiseState (0x32)
    cruise_state: int | None = None
    cruise_value: int | None = None

    # CameraMode (0x27)
    camera_mode: int | None = None

    # SetWeaponLock (0x30)
    weapon_lock_flags: int | None = None
    weapon_lock_target: int | None = None

    # ShotTracking (0x33)
    shot_tracking_entity: int | None = None
    shot_tracking_weapon: int | None = None
    shot_tracking_value: int | None = None

    # CameraFreeLook (0x2F)
    camera_free_look_state: int | None = None

    # SubController (0x31)
    sub_controller_mode: int | None = None
    sub_controller_depth: float | None = None

    # PlayerNetStats (0x1D)
    net_stats_raw: int | None = None

    # Nested property operation semantics
    operation_type: str | None = None  # "set", "set_key", "set_range", "delete", "clear"

    # Metadata
    entity_type: str | None = None  # e.g. "Avatar", "Vehicle"
    size: int = 0

    @property
    def is_method_call(self) -> bool:
        return self.type == PacketType.ENTITY_METHOD

    @property
    def is_property_update(self) -> bool:
        return self.type == PacketType.ENTITY_PROPERTY
