---
title: 'A Model Context Protocol Server for Wikipedia Citation Science'
tags:
  - Python
  - R
  - Wikipedia
  - citation analysis
  - scientometrics
  - large language models
  - Model Context Protocol
authors:
  - name: Jonathan Sobel
    orcid: 0000-0002-5111-4070
    affiliation: 1
affiliations:
  - name: Division of Infection Prevention and Control, University Hospital of Geneva (HUG), Geneva, Switzerland
    index: 1
    ror: 01m1pv723
date: 25 April 2026
bibliography: paper.bib
---

# Summary

Wikipedia is the world's largest free encyclopaedia and one of the most
consulted online resources for scientific and medical information, yet the
quality of its citations varies considerably across topics and over time
[@lewoniewski2017quality].  A growing body of research measures the
reliability of Wikipedia's sources, tracks the penetration of the
peer-reviewed literature into Wikipedia articles, and studies how editorial
communities respond to emerging scientific evidence
[@maggio2019accuracy; @heilman2011wikipedia; @nicholson2021measuring; @benjakob2022citation].
Conducting such analyses requires querying the MediaWiki Revisions API,
parsing raw wikitext with regular expressions, resolving Digital Object
Identifiers (DOIs) against external bibliographic services, and aggregating
the results — tasks that have historically demanded programming expertise in
R or Python.

`wikicitation-mcp` removes this barrier by wrapping the `wikilite` R
package [@sobel2024wikilite] as a **Model Context Protocol (MCP) server**
[@anthropic2024mcp].  MCP is an open standard that allows large language
model (LLM) assistants such as Claude to invoke typed, structured functions
on the user's behalf [@hou2025mcp].  The server exposes 43 tools covering Wikipedia edit
history retrieval, citation counting and parsing, scientific quality scoring,
DOI and ISBN annotation via CrossRef, EuropePMC, and Altmetric, and the
generation of both static and interactive visualisations.  Researchers,
librarians, science journalists, and educators can now perform research-grade
Wikipedia citation audits through natural-language prompts, without writing
a single line of code.

# Statement of Need

Wikipedia's citation practices have become a legitimate subject of
scientometric inquiry.  Researchers have studied how quickly the biomedical
literature enters Wikipedia and how citation latency varies across knowledge
domains [@heilman2011wikipedia; @schmidt2023diachronic], whether Wikipedia
preferentially cites open-access sources [@teplitskiy2017amplifying; @benjakob2022citation],
and how citation quality differs across article classes, language editions,
and at continental scale [@lewoniewski2017quality; @nicholson2021measuring].
Medical educators and librarians use citation-type
distributions as proxies for article reliability when advising students on
information sources [@flanagin2011assessment; @maggio2019accuracy; @maggio2017wikipedia].

Operationalising these questions requires programmatic access to the
MediaWiki Revisions API, PCRE-based wikitext parsing, and downstream
enrichment from CrossRef [@crossref2024], EuropePMC [@europepmc2023], and
Altmetric [@altmetric2024].  The `wikilite` R package [@sobel2024wikilite]
consolidates this pipeline into a coherent library, but its use presupposes
fluency in R and a local software installation.  LLM assistants have
dramatically expanded access to data-driven analysis for non-programmers
[@wang2025llms], yet without specialised connectors they cannot reach
domain-specific scientific software ecosystems.

`wikicitation-mcp` fills this gap directly: it makes the entire `wikilite`
function catalogue available as MCP tools, enabling non-programmers to
conduct Wikipedia citation audits interactively and allowing developers to
integrate Wikipedia citation intelligence into automated pipelines.

# State of the Field

Several tools exist for programmatic interaction with Wikipedia, but none
address Wikipedia citation science as a first-class concern.
**PyWikiBot** [@pywikibot2023] is a mature Python framework for reading and
editing Wikipedia pages; it provides broad API coverage but no citation
parsing, DOI resolution, or quality metrics.  **WikipediR**
[@wikipedir2016], the R package underlying `wikilite`, offers low-level
access to the MediaWiki API but requires users to write their own parsing
logic.  **mwcite** [@mwcite2022], a Python utility used in large-scale
Wikipedia citation dumps, operates in batch mode on offline data and is not
designed for interactive or article-level analysis.  The `WikiCitationHistoRy`
package [@benjakob2022citation] — the direct predecessor of `wikilite` —
provided the first integrated R toolkit for Wikipedia citation analysis but
was designed for script-based workflows only.

`wikicitation-mcp` does not duplicate any of these tools; it composes them.
The `wikilite` layer provides the domain logic (built on WikipediR, rcrossref,
europepmc, and rAltmetric), while the MCP layer makes that logic accessible
to LLM assistants without additional programming.  Contributing citation
science tools upstream to PyWikiBot or mwcite was not feasible because those
projects serve fundamentally different use cases (editing automation and
offline batch processing, respectively) and are not designed around the
interactive, per-article, multi-API workflows that `wikilite` implements.

# Software Design

## Architecture and design trade-offs

The server follows a three-layer architecture.  The **MCP layer**
(`server.py`) is a Python module built with FastMCP [@fastmcp2024] that
declares all tools using the `@mcp.tool()` decorator and enforces typed
argument schemas.  The **R bridge** (`r_bridge.py`) is an asynchronous
subprocess bridge that serialises each tool call as a JSON object, pipes it
to a child `Rscript` process via `stdin`, and deserialises the JSON result
returned on `stdout`.  The **R dispatch layer** (`mcp_interface.R`) reads
the payload, switches on the tool name, calls the appropriate `wikilite`
function, and returns the result via `jsonlite::toJSON()` [@jsonlite2014].

The central design choice is using a subprocess with JSON-over-stdio rather
than embedding R inside Python via `rpy2`.  This decision prioritises
robustness: each tool call runs in a fresh, isolated R process, eliminating
shared session state and preventing memory leaks from long-running R objects.
Error boundaries are clean — a crash in R produces a non-zero exit code that
Python converts to a descriptive `RuntimeError`, rather than a segmentation
fault propagating into the Python host.  The JSON-over-stdio contract is also
language-agnostic, making it straightforward to swap the R backend for a
Python reimplementation of any tool without modifying the MCP layer.  The
trade-off is per-call startup latency (~0.3 s for Rscript initialisation);
this is acceptable because the dominant cost for most tools is the network
round-trip to the MediaWiki API or to CrossRef/EuropePMC.

Static visualisations are returned as base64-encoded PNG strings so that
MCP clients can render them inline.  Interactive visualisations are returned
as self-contained HTML strings produced by `htmlwidgets::saveWidget()`
[@htmlwidgets2023], which clients can write to disk and open in a browser
without any additional dependencies.  The bridge runs inside Python's
`asyncio` event loop and enforces a configurable timeout (default 120 s) to
guard against stalled network requests.

## Transport modes and deployment

The server supports **stdio** mode (default), in which it communicates over
standard input/output and is registered with Claude Desktop or Claude Code
using a single command-line invocation, and **streamable-HTTP** mode, in
which it listens on a configurable TCP port and can be registered with the
`claude.ai` web interface or any MCP-compatible client, including remote
deployments tunnelled through a reverse proxy.

## Testing

The pytest [@pytest2024] test suite in `tests/test_bridge.py` covers three
levels.  Unit tests mock the `asyncio` subprocess layer to verify JSON
serialisation, propagation of R-level errors, handling of non-zero exit
codes, and rejection of malformed output — all without requiring an R
installation.  Direct bridge tests invoke `mcp_interface.R` as a real
subprocess against known wikitext inputs to verify counting, parsing, and
error-signalling behaviour.  Integration tests (automatically skipped when
`Rscript` or `wikilite` is unavailable) exercise live MediaWiki API calls
against stable articles such as *Zeitgeber*, verifying that returned data
structures contain expected fields and that SciScore values lie within the
unit interval [0, 1].

# Example Outputs

The following figures illustrate representative outputs produced by
`wikicitation-mcp` from natural-language prompts directed at the server.
All data were retrieved live from the MediaWiki Revisions API and enriched
via CrossRef, EuropePMC, and Altmetric.

![Output of `get_citation_history` for the Clinical Decision Support System article (607 total revisions; live data, April 2026). Stacked-area chart of citation template counts across 45 sampled revisions from article creation to April 2026. Colours represent citation type: journal (blue), web (light blue), book (orange), news (red-orange), conference (green), other (grey). Web citations dominate early revisions and are progressively displaced by journal-article citations as the article matures, consistent with @benjakob2022citation.](fig1_citation_history.png){ width=85% }

# Case Study: Computerised Clinical Decision Support Systems in Healthcare

To demonstrate `wikicitation-mcp` in a realistic research context, we
conducted a live citation quality audit of the English Wikipedia corpus
covering computerised clinical decision support systems (CDSS) in
healthcare.  All data were retrieved on 25 April 2026 from the MediaWiki
Revisions API via `get_article_most_recent` and `get_article_full_history_table`,
and annotated via `annotate_dois_crossref`.

## Corpus and quality stratification

Thirteen substantive English Wikipedia articles were identified across the
CDSS domain, spanning clinical decision support [@shortliffe1993cdss], computerised
physician order entry [@bates1998cpoe; @koppel2005cpoe], electronic health
records, artificial intelligence in healthcare, and computer-aided diagnosis
[@dombal1972cad].  Together the articles contain 768 citation templates,
of which 421 (55%) carry a DOI, yielding 401 unique identifiers.

Figure 2 presents SciScore for all 13 articles.  The quality spectrum is wide.
Specialist technical articles — *Computer-Aided Diagnosis* (SciScore = 0.84),
*Drug Interaction* (0.79), and *Imaging Informatics* (0.76) — comfortably
exceed the 0.70 quality threshold, reflecting near-universal DOI coverage
among their citation templates.  Broader policy articles — *Health Informatics*
(0.34), *Computerised Physician Order Entry* (0.35), and *Pharmacy Automation*
(0.14) — score substantially lower because they cite government reports, news
articles, and websites without DOIs.  *OpenEvidence* (a commercial AI-assisted
clinical knowledge platform) scores 0.00: all 20 of its citation templates
reference web and news sources with no DOI-bearing peer-reviewed citations.

![Output of `get_sci_score` applied corpus-wide to 13 CDSS Wikipedia articles (live data, April 2026). Horizontal bar chart sorted by SciScore (proportion of citation templates with a DOI) and colour-coded by quality tier: green (≥ 0.70), orange (0.40–0.69), red (< 0.40). Dashed vertical lines mark tier boundaries.](cdss_fig1_sciscore.png){ width=68% }

## Citation type distribution

Figure 3 shows the breakdown of citation template types across the corpus.
Journal articles dominate at 58% of all templates, followed by web citations
(28%), news (6%), and books (5%).  The high web-citation share in
*OpenEvidence*, *Electronic Health Record*, and *Health Informatics* partly
explains their depressed SciScore values and reflects the mixed editorial
character of articles that must describe policy, legislation, and commercial
products alongside scientific evidence.

![Output of `get_citation_types` for the CDSS corpus. Stacked bar chart of citation template types for 13 CDSS Wikipedia articles, sorted by total template count. Types shown: journal, web, book, news, report, magazine, and conference.](cdss_fig2_types.png){ width=88% }

## Most-cited papers

CrossRef annotation (`annotate_dois_crossref`) was applied to 60 of the
401 unique DOIs (Figure 4).  The highest-cited paper in the corpus is Garg
et al. (JAMA, 2005) — a meta-analysis of 100 CDSS trials reporting improved
practitioner performance in 64% of cases — with 2,238 downstream citations
[@garg2005cdss].  Kawamoto et al. (BMJ, 2005) ranks second with 1,974
citations [@kawamoto2005cdss].  Notably, de Dombal's 1972 BMJ paper on
computer-aided diagnosis of acute abdominal pain [@dombal1972cad] — one of
the earliest CDSS studies — ranks among the top 15 most-cited papers,
underscoring the long disciplinary lineage of the field.

![Output of `annotate_dois_crossref` for the CDSS corpus. Horizontal bar chart of the 15 most-cited papers by CrossRef cited-by count (April 2026). Green bars indicate open-access licence detected; blue bars indicate closed or unknown access.](cdss_fig5_topcited.png){ width=70% }

The top 40 most-cited papers by CrossRef cited-by count are provided as a
supplementary spreadsheet (`tableS1_top40.xlsx`), produced directly by
`annotate_dois_crossref` and containing rank, first author, year,
journal, full title, DOI, and citation count for each entry (544 unique DOIs
harvested from the corpus).

# Research Impact Statement

The direct predecessor of `wikicitation-mcp`, the `WikiCitationHistoRy` R
package, was used as the primary data-collection tool in a peer-reviewed
bibliometric study published in *GigaScience* [@benjakob2022citation].  That
study analysed the full citation history of 231 English Wikipedia articles
affiliated with WikiProject COVID-19 and found that the Wikipedia community
selectively cited high-quality, open-access sources during the first wave of
the pandemic, with measurable under-representation of preprints relative to
their overall publication volume.  This demonstrated the scientific value of
the toolchain that `wikicitation-mcp` now makes broadly accessible.

By lowering the technical barrier from programming proficiency to
natural-language prompting, `wikicitation-mcp` opens the methodology of
@benjakob2022citation to researchers without computational backgrounds.
The CDSS case study presented above (Figures 2–4 and Table S1) illustrates this
concretely: a corpus-level citation quality audit spanning 13 Wikipedia
articles, 768 citation templates, 401 unique DOIs, and 60 CrossRef-annotated
papers was completed through natural-language prompts without writing any
code, producing findings directly comparable to prior programmatic studies of
Wikipedia citation quality [@nicholson2021measuring; @maggio2017wikipedia].
The CDSS audit reported here — 13 articles, 768 citation templates, 401 unique
DOIs, and CrossRef annotation of the 60 most-cited papers — was conducted
entirely through natural-language prompts with no code written by the analyst,
demonstrating that the methodology of @benjakob2022citation is now accessible
to researchers without computational backgrounds.  The server is available at
`https://github.com/jsobel1/wikicitation-mcp` under an MIT licence and
integrates with Claude Desktop, Claude Code, and any MCP-compatible LLM host.

# AI Usage Disclosure

Claude (Anthropic; model `claude-sonnet-4-6`) was used as a generative AI
assistant throughout the development of this software and the preparation of
this manuscript.  Specifically, Claude assisted with: refactoring and
modernising the original `WikiCitationHistoRy` R codebase into the `wikilite`
package; designing and implementing the three-layer MCP server architecture;
writing the Python–R subprocess bridge (`r_bridge.py`) and the R dispatch
layer (`mcp_interface.R`); generating the pytest test suite covering unit,
bridge, and integration levels; and drafting and revising all prose sections
of this manuscript, including the Summary, Statement of Need, State of the
Field, Software Design, Case Study, and Research Impact Statement.  The AI
did not independently analyse data or draw conclusions; all analysis was
conducted programmatically by the tools described.  All AI-generated code and
text was reviewed, validated, and curated by the author prior to inclusion.

# Acknowledgements

The author thanks Omer Benjakob and Rona Aviram, co-authors of the
foundational *GigaScience* study [@benjakob2022citation], for the
collaboration that motivated this software.  The author also thanks the
maintainers of the `wikilite`, FastMCP, europepmc, rcrossref, and rAltmetric
packages for building the open-source foundations on which this work depends.
No external funding was received for this work.

# References
