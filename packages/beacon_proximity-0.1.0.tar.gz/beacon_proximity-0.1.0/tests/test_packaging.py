"""Packaging and import-surface sanity checks."""
from __future__ import annotations

import sys
from pathlib import Path

import beacon

if sys.version_info >= (3, 11):
    import tomllib
else:  # pragma: no cover - exercised on Python 3.9/3.10
    import tomli as tomllib  # type: ignore[no-redef]


def test_import_exposes_version() -> None:
    assert isinstance(beacon.__version__, str)
    assert beacon.__version__


def test_pytest_entrypoint_declared() -> None:
    pyproject = Path(__file__).resolve().parents[1] / "pyproject.toml"
    data = tomllib.loads(pyproject.read_text(encoding="utf-8"))
    entry_points = data["project"]["entry-points"]["pytest11"]
    assert entry_points["beacon"] == "beacon.plugin"

