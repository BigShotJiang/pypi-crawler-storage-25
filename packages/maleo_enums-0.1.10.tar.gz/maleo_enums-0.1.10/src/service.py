from collections.abc import Sequence
from enum import StrEnum
from typing import Annotated

from nexo.types.string import ListOfStrs
from pydantic import BaseModel, Field


class ShortServiceKey(StrEnum):
    STUDIO = "studio"
    LOCUS = "locus"
    TELEMETRY = "telemetry"
    IDENTITY = "identity"
    RESEARCH = "research"
    REGISTRY = "registry"
    SCRIBE = "scribe"
    CDS = "cds"
    IMAGING = "imaging"
    MCU = "mcu"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptShortServiceKey = ShortServiceKey | None


class SimpleShortServiceKeyMixin[T: OptShortServiceKey](BaseModel):
    key: Annotated[T, Field(..., description="Service Key")]


class FullShortServiceKeyMixin[T: OptShortServiceKey](BaseModel):
    service_key: Annotated[T, Field(..., description="Service Key")]


ListOfShortServiceKeys = list[ShortServiceKey]
OptListOfShortServiceKeys = ListOfShortServiceKeys | None
SeqOfShortServiceKeys = Sequence[ShortServiceKey]
OptSeqOfShortServiceKeys = SeqOfShortServiceKeys | None


class SimpleShortServiceKeysMixin[T: OptSeqOfShortServiceKeys](BaseModel):
    keys: Annotated[T, Field(..., description="Service Keys")]


class FullShortServiceKeysMixin[T: OptSeqOfShortServiceKeys](BaseModel):
    service_keys: Annotated[T, Field(..., description="Service Keys")]


class ServiceKey(StrEnum):
    STUDIO = "maleo-studio"
    LOCUS = "maleo-locus"
    TELEMETRY = "maleo-telemetry"
    IDENTITY = "maleo-identity"
    RESEARCH = "maleo-research"
    REGISTRY = "maleo-registry"
    SCRIBE = "maleo-scribe"
    CDS = "maleo-cds"
    IMAGING = "maleo-imaging"
    MCU = "maleo-mcu"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptServiceKey = ServiceKey | None


class SimpleServiceKeyMixin[T: OptServiceKey](BaseModel):
    key: Annotated[T, Field(..., description="Service Key")]


class FullServiceKeyMixin[T: OptServiceKey](BaseModel):
    service_key: Annotated[T, Field(..., description="Service Key")]


ListOfServiceKeys = list[ServiceKey]
OptListOfServiceKeys = ListOfServiceKeys | None
SeqOfServiceKeys = Sequence[ServiceKey]
OptSeqOfServiceKeys = SeqOfServiceKeys | None


class SimpleServiceKeysMixin[T: OptSeqOfServiceKeys](BaseModel):
    keys: Annotated[T, Field(..., description="Service Keys")]


class FullServiceKeysMixin[T: OptSeqOfServiceKeys](BaseModel):
    service_keys: Annotated[T, Field(..., description="Service Keys")]


class ShortServiceName(StrEnum):
    STUDIO = "Studio"
    LOCUS = "Locus"
    TELEMETRY = "Telemetry"
    IDENTITY = "Identity"
    RESEARCH = "Research"
    REGISTRY = "Registry"
    SCRIBE = "Scribe"
    CDS = "CDS"
    IMAGING = "Imaging"
    MCU = "MCU"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptShortServiceName = ShortServiceName | None


class SimpleShortServiceNameMixin[T: OptShortServiceName](BaseModel):
    name: Annotated[T, Field(..., description="Service Name")]


class FullShortServiceNameMixin[T: OptShortServiceName](BaseModel):
    service_name: Annotated[T, Field(..., description="Service Name")]


ListOfShortServiceNames = list[ShortServiceName]
OptListOfShortServiceNames = ListOfShortServiceNames | None
SeqOfShortServiceNames = Sequence[ShortServiceName]
OptSeqOfShortServiceNames = SeqOfShortServiceNames | None


class SimpleShortServiceNamesMixin[T: OptSeqOfShortServiceNames](BaseModel):
    names: Annotated[T, Field(..., description="Service Names")]


class FullShortServiceNamesMixin[T: OptSeqOfShortServiceNames](BaseModel):
    service_names: Annotated[T, Field(..., description="Service Names")]


class ServiceName(StrEnum):
    STUDIO = "MaleoStudio"
    LOCUS = "MaleoLocus"
    TELEMETRY = "MaleoTelemetry"
    IDENTITY = "MaleoIdentity"
    RESEARCH = "MaleoResearch"
    REGISTRY = "MaleoRegistry"
    SCRIBE = "MaleoScribe"
    CDS = "MaleoCDS"
    IMAGING = "MaleoImaging"
    MCU = "MaleoMCU"

    @classmethod
    def choices(cls) -> ListOfStrs:
        return [e.value for e in cls]


OptServiceName = ServiceName | None


class SimpleServiceNameMixin[T: OptServiceName](BaseModel):
    name: Annotated[T, Field(..., description="Service Name")]


class FullServiceNameMixin[T: OptServiceName](BaseModel):
    service_name: Annotated[T, Field(..., description="Service Name")]


ListOfServiceNames = list[ServiceName]
OptListOfServiceNames = ListOfServiceNames | None
SeqOfServiceNames = Sequence[ServiceName]
OptSeqOfServiceNames = SeqOfServiceNames | None


class SimpleServiceNamesMixin[T: OptSeqOfServiceNames](BaseModel):
    names: Annotated[T, Field(..., description="Service Names")]


class FullServiceNamesMixin[T: OptSeqOfServiceNames](BaseModel):
    service_names: Annotated[T, Field(..., description="Service Names")]
