use std::collections::HashMap;

use serde::{Deserialize, Serialize};

use crate::AnsibleValue;

/// Variables associated with a specific host.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct HostVars {
    pub host: String,
    pub vars: HashMap<String, AnsibleValue>,
}

/// Task attributes that can override PlayContext settings.
/// Matches Python's `TASK_ATTRIBUTE_OVERRIDES`.
pub const TASK_ATTRIBUTE_OVERRIDES: &[&str] = &[
    "become",
    "become_user",
    "become_pass",
    "become_method",
    "become_flags",
    "connection",
    "port",
    "remote_user",
];

/// Magic variable mapping: inventory variables → PlayContext fields.
/// When these variables are set in host/group vars, they override
/// the corresponding PlayContext attribute.
pub const MAGIC_VARIABLE_MAPPING: &[(&str, &str)] = &[
    ("ansible_connection", "connection"),
    ("ansible_host", "remote_addr"),
    ("ansible_port", "port"),
    ("ansible_user", "remote_user"),
    ("ansible_become", "use_become"),
    ("ansible_become_method", "become_method"),
    ("ansible_become_user", "become_user"),
    ("ansible_become_pass", "become_pass"),
    ("ansible_become_flags", "become_flags"),
    ("ansible_shell_type", "shell"),
    ("ansible_pipelining", "pipelining"),
    ("ansible_timeout", "timeout"),
    ("ansible_ssh_private_key_file", "private_key_file"),
    ("ansible_network_os", "network_os"),
];

/// Connection-related variables that should be reset when delegating.
pub const RESET_VARS: &[&str] = &[
    "ansible_connection",
    "ansible_host",
    "ansible_port",
    "ansible_user",
    "ansible_become",
    "ansible_become_method",
    "ansible_become_user",
    "ansible_become_pass",
    "ansible_become_flags",
    "ansible_pipelining",
    "ansible_timeout",
];

/// Context for executing tasks — connection settings, privilege escalation, etc.
/// Derived from play, task, and CLI options merged together.
///
/// PlayContext is the Rust equivalent of Python's `PlayContext` class.
/// It aggregates settings from multiple sources (CLI, config, play, task,
/// inventory variables) into a single snapshot used during task execution.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct PlayContext {
    // ── Connection settings ──
    pub remote_addr: String,
    pub remote_user: String,
    pub port: Option<u16>,
    pub connection: String,
    pub shell: String,
    pub pipelining: bool,
    pub timeout: u32,
    pub private_key_file: Option<String>,
    pub network_os: Option<String>,

    // ── Privilege escalation ──
    pub use_become: bool,
    pub become_method: String,
    pub become_user: String,
    pub become_pass: Option<String>,
    pub become_exe: Option<String>,
    pub become_flags: Option<String>,

    // ── Execution mode ──
    pub check_mode: bool,
    pub diff_mode: bool,
    pub no_log: bool,
    pub force_handlers: bool,
    pub start_at_task: Option<String>,
    pub step: bool,

    // ── Environment ──
    pub environment: HashMap<String, String>,
    pub verbosity: u8,

    // ── Module settings ──
    pub module_compression: String,
    pub executable: String,
}

impl Default for PlayContext {
    fn default() -> Self {
        Self {
            remote_addr: String::new(),
            remote_user: String::new(),
            port: None,
            connection: "ssh".to_string(),
            shell: "/bin/sh".to_string(),
            pipelining: true,
            timeout: 10,
            private_key_file: None,
            network_os: None,
            use_become: false,
            become_method: "sudo".to_string(),
            become_user: "root".to_string(),
            become_pass: None,
            become_exe: None,
            become_flags: None,
            check_mode: false,
            diff_mode: false,
            no_log: false,
            force_handlers: false,
            start_at_task: None,
            step: false,
            environment: HashMap::new(),
            verbosity: 0,
            module_compression: "ZIP_DEFLATED".to_string(),
            executable: "/bin/sh".to_string(),
        }
    }
}

impl PlayContext {
    /// Initialize PlayContext from CLI options and config.
    pub fn from_config(config: &crate::AnsibleValue) -> Self {
        let mut ctx = Self::default();

        if let Some(obj) = config.as_object() {
            if let Some(v) = obj.get("timeout").and_then(|v| v.as_u64()) {
                ctx.timeout = v as u32;
            }
            if let Some(v) = obj.get("remote_user").and_then(|v| v.as_str()) {
                ctx.remote_user = v.to_string();
            }
            if let Some(v) = obj.get("private_key_file").and_then(|v| v.as_str()) {
                ctx.private_key_file = Some(v.to_string());
            }
            if let Some(v) = obj.get("verbosity").and_then(|v| v.as_u64()) {
                ctx.verbosity = v as u8;
            }
        }

        ctx
    }

    /// Apply play-level settings to this context.
    pub fn set_attributes_from_play(&mut self, play_vars: &HashMap<String, AnsibleValue>) {
        if let Some(v) = play_vars.get("force_handlers").and_then(|v| v.as_bool()) {
            self.force_handlers = v;
        }
    }

    /// Apply task-level overrides and magic variables, returning a new PlayContext.
    ///
    /// This is the Rust equivalent of Python's `set_task_and_variable_override()`.
    /// It creates a copy of the context with task-specific settings applied.
    pub fn set_task_and_variable_override(
        &self,
        task_attrs: &HashMap<String, AnsibleValue>,
        variables: &HashMap<String, AnsibleValue>,
    ) -> Self {
        let mut new_ctx = self.clone();

        // 1. Apply task attribute overrides (become, connection, etc.)
        for &attr in TASK_ATTRIBUTE_OVERRIDES {
            if let Some(value) = task_attrs.get(attr) {
                new_ctx.apply_attribute(attr, value);
            }
        }

        // 2. Apply magic variables from inventory/vars
        for &(var_name, attr_name) in MAGIC_VARIABLE_MAPPING {
            if let Some(value) = variables.get(var_name) {
                new_ctx.apply_attribute(attr_name, value);
            }
        }

        // 3. Handle delegation — if delegate_to is set, use delegated vars
        if let Some(delegated_vars) = variables.get("ansible_delegated_vars") {
            if let Some(delegate_host) = task_attrs
                .get("delegate_to")
                .and_then(|v| v.as_str())
            {
                if let Some(host_vars) = delegated_vars
                    .get(delegate_host)
                    .and_then(|v| v.as_object())
                {
                    // Apply delegated host's magic variables
                    for &(var_name, attr_name) in MAGIC_VARIABLE_MAPPING {
                        if let Some(value) = host_vars.get(var_name) {
                            new_ctx.apply_attribute(attr_name, value);
                        }
                    }
                }
            }
        }

        // 4. Apply check_mode and diff from task if set
        if let Some(v) = task_attrs.get("check_mode").and_then(|v| v.as_bool()) {
            new_ctx.check_mode = v;
        }
        if let Some(v) = task_attrs.get("diff").and_then(|v| v.as_bool()) {
            new_ctx.diff_mode = v;
        }
        if let Some(v) = task_attrs.get("no_log").and_then(|v| v.as_bool()) {
            new_ctx.no_log = v;
        }
        if let Some(v) = task_attrs.get("environment").and_then(|v| v.as_object()) {
            for (key, val) in v {
                if let Some(s) = val.as_str() {
                    new_ctx.environment.insert(key.clone(), s.to_string());
                }
            }
        }

        // 5. Apply connection defaults if not explicitly set
        if new_ctx.connection == "ssh" && new_ctx.remote_addr.is_empty() {
            if let Some(host) = variables.get("inventory_hostname").and_then(|v| v.as_str()) {
                new_ctx.remote_addr = host.to_string();
            }
        }

        new_ctx
    }

    /// Apply a single attribute value to the context.
    fn apply_attribute(&mut self, name: &str, value: &AnsibleValue) {
        match name {
            "connection" => {
                if let Some(s) = value.as_str() {
                    self.connection = s.to_string();
                }
            }
            "remote_addr" => {
                if let Some(s) = value.as_str() {
                    self.remote_addr = s.to_string();
                }
            }
            "remote_user" => {
                if let Some(s) = value.as_str() {
                    self.remote_user = s.to_string();
                }
            }
            "port" => {
                if let Some(n) = value.as_u64() {
                    self.port = Some(n as u16);
                } else if let Some(s) = value.as_str() {
                    if let Ok(n) = s.parse::<u16>() {
                        self.port = Some(n);
                    }
                }
            }
            "become" | "use_become" => {
                if let Some(b) = value.as_bool() {
                    self.use_become = b;
                }
            }
            "become_method" => {
                if let Some(s) = value.as_str() {
                    self.become_method = s.to_string();
                }
            }
            "become_user" => {
                if let Some(s) = value.as_str() {
                    self.become_user = s.to_string();
                }
            }
            "become_pass" => {
                if let Some(s) = value.as_str() {
                    self.become_pass = Some(s.to_string());
                }
            }
            "become_flags" => {
                if let Some(s) = value.as_str() {
                    self.become_flags = Some(s.to_string());
                }
            }
            "shell" => {
                if let Some(s) = value.as_str() {
                    self.shell = s.to_string();
                }
            }
            "pipelining" => {
                if let Some(b) = value.as_bool() {
                    self.pipelining = b;
                }
            }
            "timeout" => {
                if let Some(n) = value.as_u64() {
                    self.timeout = n as u32;
                }
            }
            "private_key_file" => {
                if let Some(s) = value.as_str() {
                    self.private_key_file = Some(s.to_string());
                }
            }
            "network_os" => {
                if let Some(s) = value.as_str() {
                    self.network_os = Some(s.to_string());
                }
            }
            _ => {}
        }
    }

    /// Export connection-related magic variables for use in templates.
    /// This is the inverse of magic variable application.
    pub fn update_vars(&self, variables: &mut HashMap<String, AnsibleValue>) {
        variables.insert(
            "ansible_connection".to_string(),
            AnsibleValue::String(self.connection.clone()),
        );
        variables.insert(
            "ansible_host".to_string(),
            AnsibleValue::String(self.remote_addr.clone()),
        );
        if let Some(port) = self.port {
            variables.insert(
                "ansible_port".to_string(),
                AnsibleValue::Number(port.into()),
            );
        }
        if !self.remote_user.is_empty() {
            variables.insert(
                "ansible_user".to_string(),
                AnsibleValue::String(self.remote_user.clone()),
            );
        }
        variables.insert(
            "ansible_pipelining".to_string(),
            AnsibleValue::Bool(self.pipelining),
        );
    }
}

/// Aggregate statistics for a playbook run.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct AggregateStats {
    pub ok: HashMap<String, usize>,
    pub failures: HashMap<String, usize>,
    pub dark: HashMap<String, usize>,
    pub changed: HashMap<String, usize>,
    pub skipped: HashMap<String, usize>,
    pub rescued: HashMap<String, usize>,
    pub ignored: HashMap<String, usize>,
}

impl AggregateStats {
    pub fn new() -> Self {
        Self::default()
    }

    /// Record a task result for a host.
    pub fn record(&mut self, host: &str, changed: bool, failed: bool, skipped: bool) {
        if failed {
            *self.failures.entry(host.to_string()).or_default() += 1;
        } else if skipped {
            *self.skipped.entry(host.to_string()).or_default() += 1;
        } else {
            *self.ok.entry(host.to_string()).or_default() += 1;
            if changed {
                *self.changed.entry(host.to_string()).or_default() += 1;
            }
        }
    }

    /// Record an unreachable host.
    pub fn record_unreachable(&mut self, host: &str) {
        *self.dark.entry(host.to_string()).or_default() += 1;
    }

    /// Record a rescued task.
    pub fn record_rescued(&mut self, host: &str) {
        *self.rescued.entry(host.to_string()).or_default() += 1;
    }

    /// Record an ignored error.
    pub fn record_ignored(&mut self, host: &str) {
        *self.ignored.entry(host.to_string()).or_default() += 1;
    }

    /// Summarize stats for a host as a display string.
    pub fn summarize(&self, host: &str) -> String {
        format!(
            "ok={} changed={} unreachable={} failed={} skipped={} rescued={} ignored={}",
            self.ok.get(host).unwrap_or(&0),
            self.changed.get(host).unwrap_or(&0),
            self.dark.get(host).unwrap_or(&0),
            self.failures.get(host).unwrap_or(&0),
            self.skipped.get(host).unwrap_or(&0),
            self.rescued.get(host).unwrap_or(&0),
            self.ignored.get(host).unwrap_or(&0),
        )
    }

    /// Get all hosts that had any interaction.
    pub fn all_hosts(&self) -> Vec<String> {
        let mut hosts: std::collections::HashSet<String> = std::collections::HashSet::new();
        for map in [
            &self.ok,
            &self.failures,
            &self.dark,
            &self.changed,
            &self.skipped,
            &self.rescued,
            &self.ignored,
        ] {
            hosts.extend(map.keys().cloned());
        }
        let mut result: Vec<String> = hosts.into_iter().collect();
        result.sort();
        result
    }

    /// Check if any failures occurred.
    pub fn has_failures(&self) -> bool {
        !self.failures.is_empty()
    }

    /// Check if any hosts were unreachable.
    pub fn has_unreachable(&self) -> bool {
        !self.dark.is_empty()
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_play_context_defaults() {
        let ctx = PlayContext::default();
        assert_eq!(ctx.connection, "ssh");
        assert_eq!(ctx.become_method, "sudo");
        assert_eq!(ctx.become_user, "root");
        assert!(!ctx.use_become);
        assert!(!ctx.check_mode);
    }

    #[test]
    fn test_task_override() {
        let base_ctx = PlayContext::default();

        let mut task_attrs = HashMap::new();
        task_attrs.insert(
            "become".to_string(),
            AnsibleValue::Bool(true),
        );
        task_attrs.insert(
            "become_user".to_string(),
            AnsibleValue::String("deploy".to_string()),
        );
        task_attrs.insert(
            "connection".to_string(),
            AnsibleValue::String("local".to_string()),
        );

        let variables = HashMap::new();
        let new_ctx = base_ctx.set_task_and_variable_override(&task_attrs, &variables);

        assert!(new_ctx.use_become);
        assert_eq!(new_ctx.become_user, "deploy");
        assert_eq!(new_ctx.connection, "local");
        // Original unchanged
        assert!(!base_ctx.use_become);
    }

    #[test]
    fn test_magic_variable_override() {
        let base_ctx = PlayContext::default();
        let task_attrs = HashMap::new();

        let mut variables = HashMap::new();
        variables.insert(
            "ansible_host".to_string(),
            AnsibleValue::String("10.0.0.1".to_string()),
        );
        variables.insert(
            "ansible_port".to_string(),
            serde_json::json!(2222),
        );
        variables.insert(
            "ansible_user".to_string(),
            AnsibleValue::String("admin".to_string()),
        );

        let new_ctx = base_ctx.set_task_and_variable_override(&task_attrs, &variables);

        assert_eq!(new_ctx.remote_addr, "10.0.0.1");
        assert_eq!(new_ctx.port, Some(2222));
        assert_eq!(new_ctx.remote_user, "admin");
    }

    #[test]
    fn test_aggregate_stats() {
        let mut stats = AggregateStats::new();
        stats.record("web1", true, false, false);
        stats.record("web1", false, true, false);
        stats.record("web2", false, false, true);
        stats.record_unreachable("web3");

        assert_eq!(*stats.ok.get("web1").unwrap(), 1);
        assert_eq!(*stats.changed.get("web1").unwrap(), 1);
        assert_eq!(*stats.failures.get("web1").unwrap(), 1);
        assert_eq!(*stats.skipped.get("web2").unwrap(), 1);
        assert_eq!(*stats.dark.get("web3").unwrap(), 1);
        assert!(stats.has_failures());
        assert!(stats.has_unreachable());
        assert_eq!(stats.all_hosts().len(), 3);
    }

    #[test]
    fn test_update_vars() {
        let mut ctx = PlayContext::default();
        ctx.remote_addr = "10.0.0.5".to_string();
        ctx.port = Some(22);
        ctx.remote_user = "deploy".to_string();

        let mut vars = HashMap::new();
        ctx.update_vars(&mut vars);

        assert_eq!(
            vars.get("ansible_host").unwrap(),
            &AnsibleValue::String("10.0.0.5".to_string())
        );
        assert_eq!(
            vars.get("ansible_port").unwrap(),
            &serde_json::json!(22)
        );
    }
}
