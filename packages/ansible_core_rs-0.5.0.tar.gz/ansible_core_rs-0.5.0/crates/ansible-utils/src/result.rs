use std::collections::HashMap;
use std::sync::Arc;

use serde::{Deserialize, Serialize};

use crate::AnsibleValue;

/// Fields preserved when censoring results for no_log.
const PRESERVE_FIELDS: &[&str] = &[
    "attempts",
    "changed",
    "retries",
    "_ansible_no_log",
    "exception",
    "warnings",
    "deprecations",
];

/// Subfields preserved from `_ansible_delegated_vars` during censoring.
const DELEGATED_PRESERVE: &[&str] = &[
    "ansible_host",
    "ansible_port",
    "ansible_user",
    "ansible_connection",
];

/// Internal keys passed through to callbacks.
const CLEAN_EXCEPTIONS: &[&str] = &[
    "_ansible_verbose_always",
    "_ansible_item_label",
    "_ansible_no_log",
    "_ansible_verbose_override",
];

/// A deprecation warning attached to a task result.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DeprecationWarning {
    pub msg: String,
    pub version: Option<String>,
    pub date: Option<String>,
    pub collection_name: Option<String>,
}

/// The result of executing a single task on a single host.
///
/// Mirrors Python's `_BaseTaskResult` / `CallbackTaskResult` — the primary
/// data structure flowing through the execution pipeline and into callbacks.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct TaskResult {
    /// The host this result is for. Stored as `Arc<str>` so that the
    /// host name allocated once at inventory parse time is shared
    /// through the executor pipeline rather than re-allocated per
    /// result.
    pub host: Arc<str>,
    /// The task UUID (for correlating with task definitions).
    pub task_uuid: Option<String>,
    /// Whether the task reported a change.
    pub changed: bool,
    /// Whether the task failed.
    pub failed: bool,
    /// Whether the task was skipped.
    pub skipped: bool,
    /// Whether the host was unreachable.
    pub unreachable: bool,
    /// Human-readable status message.
    pub msg: Option<String>,
    /// The full return data from the module.
    pub results: AnsibleValue,
    /// Warnings emitted during execution.
    pub warnings: Vec<String>,
    /// Deprecation warnings emitted during execution.
    pub deprecations: Vec<DeprecationWarning>,
    /// Number of retry attempts made.
    pub attempts: u32,
    /// Whether no_log is enabled (results should be censored).
    pub no_log: bool,
    /// Task field metadata for callback context.
    pub task_fields: HashMap<String, AnsibleValue>,
}

impl TaskResult {
    /// Create a "skipped" result.
    pub fn skipped(host: impl Into<Arc<str>>) -> Self {
        let host = host.into();
        Self {
            skipped: true,
            msg: Some("skipped".to_string()),
            ..Self::default_for(host)
        }
    }

    /// Create a "failed" result.
    pub fn failed(host: impl Into<Arc<str>>, msg: impl Into<String>) -> Self {
        let host = host.into();
        Self {
            failed: true,
            msg: Some(msg.into()),
            ..Self::default_for(host)
        }
    }

    /// Create an "ok" result.
    pub fn ok(host: impl Into<Arc<str>>) -> Self {
        Self::default_for(host.into())
    }

    /// Create an "unreachable" result.
    pub fn unreachable(host: impl Into<Arc<str>>, msg: impl Into<String>) -> Self {
        let host = host.into();
        Self {
            unreachable: true,
            msg: Some(msg.into()),
            ..Self::default_for(host)
        }
    }

    /// Create a "changed" result.
    pub fn changed(host: impl Into<Arc<str>>) -> Self {
        let host = host.into();
        Self {
            changed: true,
            ..Self::default_for(host)
        }
    }

    fn default_for(host: Arc<str>) -> Self {
        Self {
            host,
            task_uuid: None,
            changed: false,
            failed: false,
            skipped: false,
            unreachable: false,
            msg: None,
            results: AnsibleValue::Object(serde_json::Map::new()),
            warnings: Vec::new(),
            deprecations: Vec::new(),
            attempts: 0,
            no_log: false,
            task_fields: HashMap::new(),
        }
    }

    // ── Status queries (handle loop aggregation) ──

    /// Check if the task was successful (not failed, not unreachable).
    pub fn is_success(&self) -> bool {
        !self.failed && !self.unreachable
    }

    /// Check if this is a "changed" result.
    /// For loop results, returns true if any item changed.
    pub fn is_changed(&self) -> bool {
        if self.has_loop_results() {
            self.loop_results()
                .iter()
                .any(|r| r.get("changed").and_then(|v| v.as_bool()).unwrap_or(false))
        } else {
            self.changed && !self.failed
        }
    }

    /// Check if this result represents a skipped task.
    /// For loop results, returns true only if ALL items were skipped.
    pub fn is_skipped(&self) -> bool {
        if self.has_loop_results() {
            let results = self.loop_results();
            !results.is_empty()
                && results
                    .iter()
                    .all(|r| r.get("skipped").and_then(|v| v.as_bool()).unwrap_or(false))
        } else {
            self.skipped
        }
    }

    /// Check if this result represents a failed task.
    /// Considers `failed_when_result` override.
    pub fn is_failed(&self) -> bool {
        if let Some(fwr) = self.results.get("failed_when_result") {
            return fwr.as_bool().unwrap_or(false);
        }
        if self.has_loop_results() {
            self.loop_results()
                .iter()
                .any(|r| r.get("failed").and_then(|v| v.as_bool()).unwrap_or(false))
        } else {
            self.failed
        }
    }

    /// Check if the host was unreachable.
    pub fn is_unreachable(&self) -> bool {
        self.unreachable
    }

    /// Whether this result needs the task debugger.
    pub fn needs_debugger(&self, globally_enabled: bool) -> bool {
        if !globally_enabled {
            return false;
        }
        self.is_failed() && !self.is_skipped() && !self.is_unreachable()
    }

    // ── Loop result support ──

    /// Check if this result contains loop sub-results.
    pub fn has_loop_results(&self) -> bool {
        self.results
            .get("results")
            .map(|v| v.is_array())
            .unwrap_or(false)
    }

    /// Get the loop sub-results, if any.
    pub fn loop_results(&self) -> Vec<&serde_json::Map<String, AnsibleValue>> {
        self.results
            .get("results")
            .and_then(|v| v.as_array())
            .map(|arr| arr.iter().filter_map(|v| v.as_object()).collect())
            .unwrap_or_default()
    }

    /// Get the item label for display (loop iteration value).
    pub fn item_label(&self) -> Option<&AnsibleValue> {
        self.results
            .get("_ansible_item_label")
            .or_else(|| self.results.get("item"))
    }

    // ── Data accessors ──

    /// Get the return code if available.
    pub fn rc(&self) -> Option<i64> {
        self.results.get("rc").and_then(|v| v.as_i64())
    }

    /// Get stdout if available.
    pub fn stdout(&self) -> Option<&str> {
        self.results.get("stdout").and_then(|v| v.as_str())
    }

    /// Get stderr if available.
    pub fn stderr(&self) -> Option<&str> {
        self.results.get("stderr").and_then(|v| v.as_str())
    }

    /// Get the exception/traceback if available.
    pub fn exception(&self) -> Option<&str> {
        self.results.get("exception").and_then(|v| v.as_str())
    }

    /// Get the task name from task_fields or a fallback.
    pub fn task_name(&self) -> Option<&str> {
        self.task_fields
            .get("name")
            .and_then(|v| v.as_str())
    }

    // ── Censoring ──

    /// Create a censored copy of results for `no_log: true` tasks.
    /// Only preserves fields in PRESERVE_FIELDS.
    pub fn censored_result(&self) -> AnsibleValue {
        censor_result(&self.results)
    }

    /// Get the result data, censoring if no_log is set.
    pub fn safe_results(&self) -> AnsibleValue {
        if self.no_log {
            self.censored_result()
        } else {
            self.clean_results()
        }
    }

    /// Strip internal `_ansible_*` keys except those in CLEAN_EXCEPTIONS.
    pub fn clean_results(&self) -> AnsibleValue {
        let Some(obj) = self.results.as_object() else {
            return self.results.clone();
        };

        let mut cleaned = serde_json::Map::new();
        for (key, value) in obj {
            if key.starts_with("_ansible_") && !CLEAN_EXCEPTIONS.contains(&key.as_str()) {
                continue;
            }
            cleaned.insert(key.clone(), value.clone());
        }

        AnsibleValue::Object(cleaned)
    }
}

/// Censor a result mapping, keeping only safe fields.
pub fn censor_result(result: &AnsibleValue) -> AnsibleValue {
    let Some(obj) = result.as_object() else {
        return serde_json::json!({
            "censored": "the output has been hidden due to the fact that 'no_log: true' was specified for this result"
        });
    };

    let mut censored = serde_json::Map::new();
    censored.insert(
        "censored".to_string(),
        AnsibleValue::String(
            "the output has been hidden due to the fact that 'no_log: true' was specified for this result".to_string(),
        ),
    );

    for field in PRESERVE_FIELDS {
        if let Some(value) = obj.get(*field) {
            censored.insert(field.to_string(), value.clone());
        }
    }

    // Preserve select subfields from _ansible_delegated_vars
    if let Some(delegated) = obj.get("_ansible_delegated_vars") {
        if let Some(del_obj) = delegated.as_object() {
            let mut safe_delegated = serde_json::Map::new();
            for field in DELEGATED_PRESERVE {
                if let Some(value) = del_obj.get(*field) {
                    safe_delegated.insert(field.to_string(), value.clone());
                }
            }
            if !safe_delegated.is_empty() {
                censored.insert(
                    "_ansible_delegated_vars".to_string(),
                    AnsibleValue::Object(safe_delegated),
                );
            }
        }
    }

    AnsibleValue::Object(censored)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_ok_result() {
        let r = TaskResult::ok("web1");
        assert!(r.is_success());
        assert!(!r.is_changed());
        assert!(!r.is_failed());
        assert!(!r.is_skipped());
        assert!(!r.is_unreachable());
    }

    #[test]
    fn test_failed_result() {
        let r = TaskResult::failed("web1", "module failed");
        assert!(r.is_failed());
        assert!(!r.is_success());
        assert_eq!(r.msg.as_deref(), Some("module failed"));
    }

    #[test]
    fn test_changed_result() {
        let r = TaskResult::changed("web1");
        assert!(r.is_changed());
        assert!(r.is_success());
    }

    #[test]
    fn test_unreachable_result() {
        let r = TaskResult::unreachable("web1", "ssh timeout");
        assert!(r.is_unreachable());
        assert!(!r.is_success());
    }

    #[test]
    fn test_loop_result_aggregation() {
        let mut r = TaskResult::ok("web1");
        r.results = serde_json::json!({
            "results": [
                {"changed": false, "skipped": false, "item": "a"},
                {"changed": true, "skipped": false, "item": "b"},
            ]
        });
        assert!(r.is_changed());
        assert!(!r.is_skipped());
    }

    #[test]
    fn test_loop_all_skipped() {
        let mut r = TaskResult::ok("web1");
        r.results = serde_json::json!({
            "results": [
                {"skipped": true, "item": "a"},
                {"skipped": true, "item": "b"},
            ]
        });
        assert!(r.is_skipped());
    }

    #[test]
    fn test_failed_when_override() {
        let mut r = TaskResult::ok("web1");
        r.results = serde_json::json!({"failed_when_result": true});
        assert!(r.is_failed());

        let mut r2 = TaskResult::failed("web1", "err");
        r2.results = serde_json::json!({"failed_when_result": false});
        assert!(!r2.is_failed());
    }

    #[test]
    fn test_censor_result() {
        let result = serde_json::json!({
            "changed": true,
            "secret_key": "super_secret_password",
            "stdout": "sensitive output",
            "warnings": ["this is fine"],
            "attempts": 1,
            "_ansible_delegated_vars": {
                "ansible_host": "1.2.3.4",
                "ansible_user": "admin",
                "secret_flag": "nope"
            }
        });

        let censored = censor_result(&result);
        let obj = censored.as_object().unwrap();

        assert!(obj.contains_key("censored"));
        assert!(obj.contains_key("changed"));
        assert!(obj.contains_key("warnings"));
        assert!(obj.contains_key("attempts"));
        assert!(!obj.contains_key("secret_key"));
        assert!(!obj.contains_key("stdout"));

        // Delegated vars: only safe subfields preserved
        let delegated = obj.get("_ansible_delegated_vars").unwrap().as_object().unwrap();
        assert!(delegated.contains_key("ansible_host"));
        assert!(delegated.contains_key("ansible_user"));
        assert!(!delegated.contains_key("secret_flag"));
    }
}
