use thiserror::Error;

/// Top-level error type for ansible-core-rs.
#[derive(Debug, Error)]
pub enum AnsibleError {
    #[error("ansible error: {0}")]
    General(String),

    #[error(transparent)]
    Io(#[from] std::io::Error),

    #[error(transparent)]
    Json(#[from] serde_json::Error),
}
