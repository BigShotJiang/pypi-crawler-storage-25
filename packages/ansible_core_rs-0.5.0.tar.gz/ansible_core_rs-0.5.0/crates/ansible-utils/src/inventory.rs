use std::collections::{HashMap, HashSet};
use std::sync::Arc;

use serde::{Deserialize, Serialize};

use crate::AnsibleValue;

/// A host in the inventory.
///
/// `name` and `groups` use `Arc<str>` so a host's name is stored once and
/// referenced from every group membership list without extra allocations.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Host {
    pub name: Arc<str>,
    pub vars: HashMap<String, AnsibleValue>,
    pub groups: Vec<Arc<str>>,
}

impl Host {
    pub fn new(name: impl Into<Arc<str>>) -> Self {
        Self {
            name: name.into(),
            vars: HashMap::new(),
            groups: Vec::new(),
        }
    }

    /// True if this host is listed under `group`.
    pub fn has_group(&self, group: &str) -> bool {
        self.groups.iter().any(|g| g.as_ref() == group)
    }
}

/// A group in the inventory.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Group {
    pub name: Arc<str>,
    pub hosts: Vec<Arc<str>>,
    pub children: Vec<Arc<str>>,
    pub vars: HashMap<String, AnsibleValue>,
}

impl Group {
    pub fn new(name: impl Into<Arc<str>>) -> Self {
        Self {
            name: name.into(),
            hosts: Vec::new(),
            children: Vec::new(),
            vars: HashMap::new(),
        }
    }

    /// True if `host` is a direct member of this group.
    pub fn has_host(&self, host: &str) -> bool {
        self.hosts.iter().any(|h| h.as_ref() == host)
    }

    /// True if `child` is a direct child of this group.
    pub fn has_child(&self, child: &str) -> bool {
        self.children.iter().any(|c| c.as_ref() == child)
    }
}

/// The complete inventory data structure.
///
/// Host and group names are interned — the same `Arc<str>` is shared between
/// the HashMap key, the `Host.name`/`Group.name` field, and every membership
/// reference. Adding the same name twice does not allocate a second buffer.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct InventoryData {
    pub hosts: HashMap<Arc<str>, Host>,
    pub groups: HashMap<Arc<str>, Group>,
    #[serde(skip)]
    interner: HashSet<Arc<str>>,
}

impl InventoryData {
    pub fn new() -> Self {
        Self::default()
    }

    /// Intern a name, returning the canonical `Arc<str>` for it. Subsequent
    /// interns of the same byte sequence return a clone of the existing Arc.
    pub fn intern(&mut self, name: &str) -> Arc<str> {
        if let Some(existing) = self.interner.get(name) {
            return existing.clone();
        }
        let arc: Arc<str> = Arc::from(name);
        self.interner.insert(arc.clone());
        arc
    }

    pub fn add_host(&mut self, host: Host) {
        let key = self.intern(&host.name);
        let mut host = host;
        host.name = key.clone();
        self.hosts.insert(key, host);
    }

    pub fn add_group(&mut self, group: Group) {
        let key = self.intern(&group.name);
        let mut group = group;
        group.name = key.clone();
        self.groups.insert(key, group);
    }

    pub fn get_host(&self, name: &str) -> Option<&Host> {
        self.hosts.get(name)
    }

    pub fn get_group(&self, name: &str) -> Option<&Group> {
        self.groups.get(name)
    }

    /// Add a host to a group.
    pub fn add_host_to_group(&mut self, host_name: &str, group_name: &str) {
        let host_arc = self.intern(host_name);
        let group_arc = self.intern(group_name);
        if let Some(group) = self.groups.get_mut(&group_arc) {
            if !group.has_host(host_name) {
                group.hosts.push(host_arc.clone());
            }
        }
        if let Some(host) = self.hosts.get_mut(&host_arc) {
            if !host.has_group(group_name) {
                host.groups.push(group_arc);
            }
        }
    }

    /// Add a child group to a parent group.
    pub fn add_child_group(&mut self, parent: &str, child: &str) {
        let child_arc = self.intern(child);
        if let Some(group) = self.groups.get_mut(parent) {
            if !group.has_child(child) {
                group.children.push(child_arc);
            }
        }
    }

    /// Set a host variable.
    pub fn set_host_var(&mut self, host_name: &str, key: &str, value: AnsibleValue) {
        if let Some(host) = self.hosts.get_mut(host_name) {
            host.vars.insert(key.to_string(), value);
        }
    }

    /// Set a group variable.
    pub fn set_group_var(&mut self, group_name: &str, key: &str, value: AnsibleValue) {
        if let Some(group) = self.groups.get_mut(group_name) {
            group.vars.insert(key.to_string(), value);
        }
    }

    /// Get merged variables for a host (host vars + group vars).
    /// Group vars are merged in alphabetical order, then host vars override.
    pub fn get_host_vars(&self, host_name: &str) -> HashMap<String, AnsibleValue> {
        let mut merged = HashMap::new();

        if let Some(host) = self.hosts.get(host_name) {
            let mut groups: Vec<&str> = host.groups.iter().map(|s| s.as_ref()).collect();
            groups.sort();

            for group_name in groups {
                if let Some(group) = self.groups.get(group_name) {
                    for (k, v) in &group.vars {
                        merged.insert(k.clone(), v.clone());
                    }
                }
            }

            for (k, v) in &host.vars {
                merged.insert(k.clone(), v.clone());
            }
        }

        merged
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn host_and_group_names_are_interned() {
        let mut inv = InventoryData::new();
        inv.add_host(Host::new("web1"));
        inv.add_group(Group::new("webservers"));
        inv.add_host_to_group("web1", "webservers");

        // The Host.name Arc, the hosts map key, and the Group.hosts entry
        // should all point at the same allocation.
        let host_key: Arc<str> = inv.hosts.keys().next().unwrap().clone();
        let host_name = inv.hosts.get("web1").unwrap().name.clone();
        let group_member = inv.groups.get("webservers").unwrap().hosts[0].clone();
        assert!(Arc::ptr_eq(&host_key, &host_name));
        assert!(Arc::ptr_eq(&host_key, &group_member));

        // Host.groups entry shares the group name Arc.
        let group_key: Arc<str> = inv.groups.keys().next().unwrap().clone();
        let host_group_ref = inv.hosts.get("web1").unwrap().groups[0].clone();
        assert!(Arc::ptr_eq(&group_key, &host_group_ref));
    }

    #[test]
    fn intern_returns_same_arc_for_duplicate_names() {
        let mut inv = InventoryData::new();
        let a = inv.intern("web1");
        let b = inv.intern("web1");
        assert!(Arc::ptr_eq(&a, &b));
    }
}

