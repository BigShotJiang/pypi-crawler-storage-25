use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::{Arc, Mutex};

use ansible_inventory::InventoryManager;
use ansible_utils::AnsibleValue;

use crate::VarsError;

/// Manages variable resolution across all 22 precedence levels.
///
/// Variables are stored in layers corresponding to each precedence level.
/// When resolving variables for a specific host/play/task context,
/// layers are merged from lowest to highest precedence.
pub struct VariableManager {
    /// 1. command line values (e.g. -u my_user, not -e)
    options_vars: HashMap<String, AnsibleValue>,
    /// 2. role defaults (roles/x/defaults/main.yml)
    role_defaults: HashMap<String, HashMap<String, AnsibleValue>>,
    /// Per-host facts (level 11). Stored behind a `Mutex` so that the
    /// strategy layer — which holds the VariableManager as `Arc<...>` and
    /// can't get `&mut` — can still stash gathered facts per host as
    /// plays progress.
    host_facts: Mutex<HashMap<String, HashMap<String, AnsibleValue>>>,
    /// 13. play vars_prompt
    vars_prompt: HashMap<String, AnsibleValue>,
    /// 14. play vars_files (loaded from files)
    vars_files: HashMap<String, AnsibleValue>,
    /// 15. role vars (roles/x/vars/main.yml)
    role_vars: HashMap<String, HashMap<String, AnsibleValue>>,
    /// 18. include_vars
    include_vars: HashMap<String, HashMap<String, AnsibleValue>>,
    /// 19. set_facts / registered vars (per host)
    nonpersistent_facts: HashMap<String, HashMap<String, AnsibleValue>>,
    /// 20. role params (per role inclusion)
    role_params: HashMap<String, AnsibleValue>,
    /// 21. include params
    include_params: HashMap<String, AnsibleValue>,
    /// 22. extra vars (-e) always win
    extra_vars: HashMap<String, AnsibleValue>,
    /// Inventory for group/host var lookups
    inventory: Arc<InventoryManager>,
    /// Playbook basedir for group_vars/host_vars directory lookups
    playbook_basedir: Option<PathBuf>,
}

impl VariableManager {
    pub fn new(inventory: Arc<InventoryManager>) -> Self {
        Self {
            options_vars: HashMap::new(),
            role_defaults: HashMap::new(),
            host_facts: Mutex::new(HashMap::new()),
            vars_prompt: HashMap::new(),
            vars_files: HashMap::new(),
            role_vars: HashMap::new(),
            include_vars: HashMap::new(),
            nonpersistent_facts: HashMap::new(),
            role_params: HashMap::new(),
            include_params: HashMap::new(),
            extra_vars: HashMap::new(),
            inventory,
            playbook_basedir: None,
        }
    }

    /// Set the playbook base directory for group_vars/host_vars lookups.
    pub fn set_playbook_basedir(&mut self, basedir: PathBuf) {
        self.playbook_basedir = Some(basedir);
    }

    /// Set extra vars (highest precedence, from -e flag).
    pub fn set_extra_vars(&mut self, vars: HashMap<String, AnsibleValue>) {
        self.extra_vars = vars;
    }

    /// Set command line option vars (lowest precedence, e.g. -u user).
    pub fn set_options_vars(&mut self, vars: HashMap<String, AnsibleValue>) {
        self.options_vars = vars;
    }

    /// Set role defaults for a given role name.
    pub fn set_role_defaults(&mut self, role_name: &str, vars: HashMap<String, AnsibleValue>) {
        self.role_defaults.insert(role_name.to_string(), vars);
    }

    /// Set role vars for a given role name.
    pub fn set_role_vars(&mut self, role_name: &str, vars: HashMap<String, AnsibleValue>) {
        self.role_vars.insert(role_name.to_string(), vars);
    }

    /// Set vars_prompt values.
    pub fn set_vars_prompt(&mut self, vars: HashMap<String, AnsibleValue>) {
        self.vars_prompt = vars;
    }

    /// Set vars loaded from vars_files.
    pub fn set_vars_files(&mut self, vars: HashMap<String, AnsibleValue>) {
        self.vars_files = vars;
    }

    /// Set role params for the current role inclusion.
    pub fn set_role_params(&mut self, params: HashMap<String, AnsibleValue>) {
        self.role_params = params;
    }

    /// Set include params for the current include/import.
    pub fn set_include_params(&mut self, params: HashMap<String, AnsibleValue>) {
        self.include_params = params;
    }

    /// Set a host fact. Takes `&self` because host_facts is behind a
    /// Mutex — this lets the strategy layer stash gathered facts even
    /// though it holds the VariableManager as an `Arc<...>`.
    pub fn set_host_fact(&self, host: &str, key: String, value: AnsibleValue) {
        let mut guard = self.host_facts.lock().unwrap();
        guard
            .entry(host.to_string())
            .or_default()
            .insert(key, value);
    }

    /// Set multiple host facts at once.
    pub fn set_host_facts(&self, host: &str, facts: HashMap<String, AnsibleValue>) {
        let mut guard = self.host_facts.lock().unwrap();
        guard
            .entry(host.to_string())
            .or_default()
            .extend(facts);
    }

    /// Set a nonpersistent fact (set_fact / register).
    pub fn set_nonpersistent_fact(&mut self, host: &str, key: String, value: AnsibleValue) {
        self.nonpersistent_facts
            .entry(host.to_string())
            .or_default()
            .insert(key, value);
    }

    /// Set include_vars for a specific host.
    pub fn set_include_vars(&mut self, host: &str, vars: HashMap<String, AnsibleValue>) {
        self.include_vars
            .entry(host.to_string())
            .or_default()
            .extend(vars);
    }

    /// Load group_vars and host_vars from a directory (playbook or inventory basedir).
    pub fn load_vars_from_dir(
        &self,
        basedir: &Path,
        host_name: &str,
        group_names: &[String],
    ) -> Result<VarLayers, VarsError> {
        let mut group_vars_all = HashMap::new();
        let mut group_vars = HashMap::new();
        let mut host_vars = HashMap::new();

        // group_vars/all
        let gv_all_path = basedir.join("group_vars").join("all");
        if let Some(vars) = load_vars_file_or_dir(&gv_all_path)? {
            group_vars_all = vars;
        }

        // group_vars/<group> — skip "all" here; it's already loaded above
        // as level 5 and must not be re-merged into the level-7 bucket
        // (that would let L5 overwrite more-specific group vars).
        for group in group_names {
            if group == "all" {
                continue;
            }
            let gv_path = basedir.join("group_vars").join(group);
            if let Some(vars) = load_vars_file_or_dir(&gv_path)? {
                merge_into(&mut group_vars, &vars);
            }
        }

        // host_vars/<host>
        let hv_path = basedir.join("host_vars").join(host_name);
        if let Some(vars) = load_vars_file_or_dir(&hv_path)? {
            host_vars = vars;
        }

        Ok(VarLayers {
            group_vars_all,
            group_vars,
            host_vars,
        })
    }

    /// Merge all variable sources respecting the 22-level precedence order.
    /// Lower precedence values are overridden by higher ones.
    pub fn get_vars(
        &self,
        host: &str,
        play_vars: &HashMap<String, AnsibleValue>,
        task_vars: Option<&HashMap<String, AnsibleValue>>,
        block_vars: Option<&HashMap<String, AnsibleValue>>,
        role_name: Option<&str>,
    ) -> HashMap<String, AnsibleValue> {
        let mut merged = HashMap::new();

        // 1. Command line values
        merge_into(&mut merged, &self.options_vars);

        // 2. Role defaults
        if let Some(role) = role_name {
            if let Some(defaults) = self.role_defaults.get(role) {
                merge_into(&mut merged, defaults);
            }
        }

        // 3-7. Inventory group vars + playbook group_vars
        let host_group_vars = self.inventory.get_host_vars(host);
        merge_into(&mut merged, &host_group_vars);

        // Playbook group_vars/host_vars (levels 5, 7, 10)
        if let Some(ref basedir) = self.playbook_basedir {
            let groups = self.get_host_groups(host);
            if let Ok(layers) = self.load_vars_from_dir(basedir, host, &groups) {
                // 5. playbook group_vars/all
                merge_into(&mut merged, &layers.group_vars_all);
                // 7. playbook group_vars/*
                merge_into(&mut merged, &layers.group_vars);
                // 10. playbook host_vars/*
                merge_into(&mut merged, &layers.host_vars);
            }
        }

        // 11. Host facts
        {
            let guard = self.host_facts.lock().unwrap();
            if let Some(facts) = guard.get(host) {
                merge_into(&mut merged, facts);
            }
        }

        // 12. Play vars
        merge_into(&mut merged, play_vars);

        // 13. Play vars_prompt
        merge_into(&mut merged, &self.vars_prompt);

        // 14. Play vars_files
        merge_into(&mut merged, &self.vars_files);

        // 15. Role vars
        if let Some(role) = role_name {
            if let Some(rv) = self.role_vars.get(role) {
                merge_into(&mut merged, rv);
            }
        }

        // 16. Block vars
        if let Some(bv) = block_vars {
            merge_into(&mut merged, bv);
        }

        // 17. Task vars
        if let Some(tv) = task_vars {
            merge_into(&mut merged, tv);
        }

        // 18. include_vars
        if let Some(iv) = self.include_vars.get(host) {
            merge_into(&mut merged, iv);
        }

        // 19. set_facts / registered vars
        if let Some(facts) = self.nonpersistent_facts.get(host) {
            merge_into(&mut merged, facts);
        }

        // 20. Role params
        merge_into(&mut merged, &self.role_params);

        // 21. Include params
        merge_into(&mut merged, &self.include_params);

        // 22. Extra vars always win
        merge_into(&mut merged, &self.extra_vars);

        // Add magic variables
        self.add_magic_vars(&mut merged, host);

        merged
    }

    /// Add Ansible magic variables (inventory_hostname, group_names, etc.)
    fn add_magic_vars(&self, vars: &mut HashMap<String, AnsibleValue>, host: &str) {
        vars.insert(
            "inventory_hostname".to_string(),
            AnsibleValue::String(host.to_string()),
        );
        vars.insert(
            "inventory_hostname_short".to_string(),
            AnsibleValue::String(
                host.split('.').next().unwrap_or(host).to_string(),
            ),
        );

        let groups = self.get_host_groups(host);
        vars.insert(
            "group_names".to_string(),
            AnsibleValue::Array(
                groups
                    .iter()
                    .filter(|g| *g != "all")
                    .map(|g| AnsibleValue::String(g.clone()))
                    .collect(),
            ),
        );

        // ansible_play_hosts / ansible_play_batch would be set by the executor
    }

    /// Get the list of groups a host belongs to.
    fn get_host_groups(&self, host: &str) -> Vec<String> {
        let mut groups = Vec::new();
        for (name, group) in self.inventory.groups() {
            if group.has_host(host) {
                groups.push(name.as_ref().to_string());
            }
        }
        if groups.is_empty() {
            groups.push("ungrouped".to_string());
        }
        groups.push("all".to_string());
        groups
    }

    /// Clear all nonpersistent facts (between plays).
    pub fn clear_nonpersistent_facts(&mut self) {
        self.nonpersistent_facts.clear();
    }

    /// Clear include_vars (between plays).
    pub fn clear_include_vars(&mut self) {
        self.include_vars.clear();
    }

    /// Clear cached host facts. Takes `&self` for consistency with
    /// `set_host_fact` — the strategy layer holds this as `Arc<...>`.
    pub fn clear_host_facts(&self) {
        self.host_facts.lock().unwrap().clear();
    }

    /// Drop the playbook basedir so file-backed group_vars/host_vars stop
    /// contributing. Used by tests to peel off levels 5/7/10.
    pub fn clear_playbook_basedir(&mut self) {
        self.playbook_basedir = None;
    }
}

/// Variable layers loaded from a directory's group_vars/host_vars.
pub struct VarLayers {
    pub group_vars_all: HashMap<String, AnsibleValue>,
    pub group_vars: HashMap<String, AnsibleValue>,
    pub host_vars: HashMap<String, AnsibleValue>,
}

/// Load variables from a file (YAML/JSON) or a directory of files.
fn load_vars_file_or_dir(
    path: &Path,
) -> Result<Option<HashMap<String, AnsibleValue>>, VarsError> {
    // Try path as-is (directory)
    if path.is_dir() {
        let mut vars = HashMap::new();
        let mut entries: Vec<_> = std::fs::read_dir(path)
            .map_err(VarsError::Io)?
            .filter_map(|e| e.ok())
            .collect();
        entries.sort_by_key(|e| e.file_name());

        for entry in entries {
            let p = entry.path();
            let ext = p.extension().and_then(|e| e.to_str());
            if let Some("yml" | "yaml" | "json") = ext {
                if let Some(file_vars) = load_single_vars_file(&p)? {
                    merge_into(&mut vars, &file_vars);
                }
            }
        }
        if vars.is_empty() {
            return Ok(None);
        }
        return Ok(Some(vars));
    }

    // Try with YAML extensions
    for ext in &["yml", "yaml", "json"] {
        let with_ext = path.with_extension(ext);
        if with_ext.is_file() {
            return load_single_vars_file(&with_ext);
        }
    }

    // Try path directly
    if path.is_file() {
        return load_single_vars_file(path);
    }

    Ok(None)
}

/// Load a single YAML/JSON file as a variable map.
fn load_single_vars_file(
    path: &Path,
) -> Result<Option<HashMap<String, AnsibleValue>>, VarsError> {
    let content = std::fs::read_to_string(path).map_err(VarsError::Io)?;
    if content.trim().is_empty() {
        return Ok(None);
    }

    let value: AnsibleValue = serde_yaml::from_str(&content)
        .map_err(|e| VarsError::ResolutionError(format!("failed to parse {}: {}", path.display(), e)))?;

    match value {
        AnsibleValue::Object(map) => {
            let vars: HashMap<String, AnsibleValue> = map.into_iter().collect();
            Ok(Some(vars))
        }
        AnsibleValue::Null => Ok(None),
        _ => Err(VarsError::ResolutionError(format!(
            "{}: vars file must contain a mapping, got {:?}",
            path.display(),
            value
        ))),
    }
}

/// Merge source into dest, overwriting existing keys.
fn merge_into(dest: &mut HashMap<String, AnsibleValue>, source: &HashMap<String, AnsibleValue>) {
    for (k, v) in source {
        dest.insert(k.clone(), v.clone());
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn make_vm() -> VariableManager {
        let inv = Arc::new(InventoryManager::new());
        VariableManager::new(inv)
    }

    #[test]
    fn test_extra_vars_win() {
        let mut vm = make_vm();
        let mut play_vars = HashMap::new();
        play_vars.insert("port".into(), AnsibleValue::from(8080));

        let mut extra = HashMap::new();
        extra.insert("port".into(), AnsibleValue::from(9090));
        vm.set_extra_vars(extra);

        let result = vm.get_vars("host1", &play_vars, None, None, None);
        assert_eq!(result.get("port"), Some(&AnsibleValue::from(9090)));
    }

    #[test]
    fn test_task_vars_override_play_vars() {
        let vm = make_vm();
        let mut play_vars = HashMap::new();
        play_vars.insert("env".into(), AnsibleValue::String("staging".into()));

        let mut task_vars = HashMap::new();
        task_vars.insert("env".into(), AnsibleValue::String("production".into()));

        let result = vm.get_vars("host1", &play_vars, Some(&task_vars), None, None);
        assert_eq!(
            result.get("env"),
            Some(&AnsibleValue::String("production".into()))
        );
    }

    #[test]
    fn test_block_vars_between_play_and_task() {
        let vm = make_vm();
        let mut play_vars = HashMap::new();
        play_vars.insert("x".into(), AnsibleValue::String("play".into()));

        let mut block_vars = HashMap::new();
        block_vars.insert("x".into(), AnsibleValue::String("block".into()));

        // block_vars (16) > play_vars (12)
        let result = vm.get_vars("host1", &play_vars, None, Some(&block_vars), None);
        assert_eq!(result.get("x"), Some(&AnsibleValue::String("block".into())));
    }

    #[test]
    fn test_role_defaults_lowest_role_precedence() {
        let mut vm = make_vm();
        vm.set_role_defaults("myrole", {
            let mut m = HashMap::new();
            m.insert("port".into(), AnsibleValue::from(80));
            m
        });

        let mut play_vars = HashMap::new();
        play_vars.insert("port".into(), AnsibleValue::from(443));

        // play_vars (12) > role_defaults (2)
        let result = vm.get_vars("host1", &play_vars, None, None, Some("myrole"));
        assert_eq!(result.get("port"), Some(&AnsibleValue::from(443)));
    }

    #[test]
    fn test_role_vars_override_play_vars() {
        let mut vm = make_vm();
        vm.set_role_vars("myrole", {
            let mut m = HashMap::new();
            m.insert("port".into(), AnsibleValue::from(8443));
            m
        });

        let mut play_vars = HashMap::new();
        play_vars.insert("port".into(), AnsibleValue::from(443));

        // role_vars (15) > play_vars (12)
        let result = vm.get_vars("host1", &play_vars, None, None, Some("myrole"));
        assert_eq!(result.get("port"), Some(&AnsibleValue::from(8443)));
    }

    #[test]
    fn test_set_fact_overrides_host_facts() {
        let mut vm = make_vm();
        vm.set_host_fact("host1", "discovered".into(), AnsibleValue::String("old".into()));
        vm.set_nonpersistent_fact("host1", "discovered".into(), AnsibleValue::String("new".into()));

        let result = vm.get_vars("host1", &HashMap::new(), None, None, None);
        // set_facts (19) > host_facts (11)
        assert_eq!(
            result.get("discovered"),
            Some(&AnsibleValue::String("new".into()))
        );
    }

    #[test]
    fn test_magic_vars_inventory_hostname() {
        let vm = make_vm();
        let result = vm.get_vars("web01.example.com", &HashMap::new(), None, None, None);
        assert_eq!(
            result.get("inventory_hostname"),
            Some(&AnsibleValue::String("web01.example.com".into()))
        );
        assert_eq!(
            result.get("inventory_hostname_short"),
            Some(&AnsibleValue::String("web01".into()))
        );
    }

    #[test]
    fn test_full_precedence_chain() {
        let mut vm = make_vm();

        // Set values at multiple precedence levels
        vm.set_options_vars({
            let mut m = HashMap::new();
            m.insert("var".into(), AnsibleValue::String("options".into()));
            m
        });
        vm.set_role_defaults("role1", {
            let mut m = HashMap::new();
            m.insert("var".into(), AnsibleValue::String("role_default".into()));
            m
        });

        let mut play_vars = HashMap::new();
        play_vars.insert("var".into(), AnsibleValue::String("play".into()));

        vm.set_role_vars("role1", {
            let mut m = HashMap::new();
            m.insert("var".into(), AnsibleValue::String("role_vars".into()));
            m
        });

        let mut task_vars = HashMap::new();
        task_vars.insert("var".into(), AnsibleValue::String("task".into()));

        vm.set_nonpersistent_fact("host1", "var".into(), AnsibleValue::String("set_fact".into()));

        // set_facts (19) > task_vars (17) > role_vars (15) > play (12) > role_defaults (2) > options (1)
        let result = vm.get_vars("host1", &play_vars, Some(&task_vars), None, Some("role1"));
        assert_eq!(
            result.get("var"),
            Some(&AnsibleValue::String("set_fact".into()))
        );
    }

    /// Walk Ansible's full 22-level precedence ladder (Phase 5.6 deliverable).
    ///
    /// Every level gets a distinct sentinel value `"L<nn>"` for key `"v"`.
    /// We then peel levels off from the top (22 → 1) and assert that the
    /// exposed value drops to the next-lower layer. Playbook group_vars /
    /// host_vars (5, 7, 10) are peeled by deleting their YAML files;
    /// inventory-file group vars (3) by clearing the group's `vars` map;
    /// levels with callback semantics (12/16/17 are param-only) peel by
    /// passing `None` or an empty map on the next `get_vars` call.
    #[test]
    fn test_all_22_precedence_levels() {
        use ansible_utils::{Group, Host};
        let tmp = tempfile::tempdir().unwrap();
        let basedir = tmp.path();

        // Playbook-basedir files back levels 5, 7, and 10.
        let gv_dir = basedir.join("group_vars");
        let hv_dir = basedir.join("host_vars");
        std::fs::create_dir_all(&gv_dir).unwrap();
        std::fs::create_dir_all(&hv_dir).unwrap();
        let gv_all = gv_dir.join("all.yml");
        let gv_prod = gv_dir.join("prod.yml");
        let hv_web1 = hv_dir.join("web1.yml");
        std::fs::write(&gv_all, "v: \"L05\"\n").unwrap();
        std::fs::write(&gv_prod, "v: \"L07\"\n").unwrap();
        std::fs::write(&hv_web1, "v: \"L10\"\n").unwrap();

        // Inventory: host "web1" in group "prod"; the group carries the
        // "inventory file group vars" sentinel for level 3/4 (we don't
        // distinguish those — the `VariableManager` merges them both
        // through `InventoryManager::get_host_vars`).
        let mut inv = ansible_inventory::InventoryManager::new();
        {
            let data = inv.data_mut();
            data.add_host(Host::new("web1"));
            data.add_group(Group::new("prod"));
            data.add_host_to_group("web1", "prod");
            data.set_group_var("prod", "v", AnsibleValue::from("L03"));
        }
        let inv = Arc::new(inv);

        fn sentinel(s: &str) -> HashMap<String, AnsibleValue> {
            let mut m = HashMap::new();
            m.insert("v".into(), AnsibleValue::from(s));
            m
        }

        let mut vm = VariableManager::new(inv.clone());
        vm.set_playbook_basedir(basedir.to_path_buf());
        vm.set_options_vars(sentinel("L01"));
        vm.set_role_defaults("r", sentinel("L02"));
        // 3/4: inventory group_var (already set above)
        // 5/7/10: file-backed above
        vm.set_host_facts("web1", sentinel("L11"));
        // 12: param
        vm.set_vars_prompt(sentinel("L13"));
        vm.set_vars_files(sentinel("L14"));
        vm.set_role_vars("r", sentinel("L15"));
        // 16/17: params
        vm.set_include_vars("web1", sentinel("L18"));
        vm.set_nonpersistent_fact(
            "web1",
            "v".into(),
            AnsibleValue::from("L19"),
        );
        vm.set_role_params(sentinel("L20"));
        vm.set_include_params(sentinel("L21"));
        vm.set_extra_vars(sentinel("L22"));

        let play_vars = sentinel("L12");
        let block_vars = sentinel("L16");
        let task_vars = sentinel("L17");
        let empty: HashMap<String, AnsibleValue> = HashMap::new();

        // Snapshot helper: resolve "v" through the full merge.
        let get = |vm: &VariableManager,
                   pv: &HashMap<String, AnsibleValue>,
                   tv: Option<&HashMap<String, AnsibleValue>>,
                   bv: Option<&HashMap<String, AnsibleValue>>| {
            vm.get_vars("web1", pv, tv, bv, Some("r"))
                .get("v")
                .and_then(|v| v.as_str().map(|s| s.to_string()))
                .unwrap_or_default()
        };

        // L22 wins at full config.
        assert_eq!(
            get(&vm, &play_vars, Some(&task_vars), Some(&block_vars)),
            "L22",
            "extra_vars (22) must beat all lower levels"
        );

        // Peel L22 → L21 wins.
        vm.set_extra_vars(HashMap::new());
        assert_eq!(
            get(&vm, &play_vars, Some(&task_vars), Some(&block_vars)),
            "L21"
        );

        // Peel L21 → L20 wins.
        vm.set_include_params(HashMap::new());
        assert_eq!(
            get(&vm, &play_vars, Some(&task_vars), Some(&block_vars)),
            "L20"
        );

        // Peel L20 → L19 wins.
        vm.set_role_params(HashMap::new());
        assert_eq!(
            get(&vm, &play_vars, Some(&task_vars), Some(&block_vars)),
            "L19"
        );

        // Peel L19 → L18 wins.
        vm.clear_nonpersistent_facts();
        assert_eq!(
            get(&vm, &play_vars, Some(&task_vars), Some(&block_vars)),
            "L18"
        );

        // Peel L18 → L17 wins.
        vm.clear_include_vars();
        assert_eq!(
            get(&vm, &play_vars, Some(&task_vars), Some(&block_vars)),
            "L17"
        );

        // Peel L17 by omitting task_vars → L16 wins.
        assert_eq!(get(&vm, &play_vars, None, Some(&block_vars)), "L16");

        // Peel L16 by omitting block_vars → L15 wins.
        assert_eq!(get(&vm, &play_vars, None, None), "L15");

        // Peel L15 → L14 wins.
        vm.set_role_vars("r", HashMap::new());
        assert_eq!(get(&vm, &play_vars, None, None), "L14");

        // Peel L14 → L13 wins.
        vm.set_vars_files(HashMap::new());
        assert_eq!(get(&vm, &play_vars, None, None), "L13");

        // Peel L13 → L12 wins.
        vm.set_vars_prompt(HashMap::new());
        assert_eq!(get(&vm, &play_vars, None, None), "L12");

        // Peel L12 by passing empty play_vars → L11 wins.
        assert_eq!(get(&vm, &empty, None, None), "L11");

        // Peel L11 → L10 wins (playbook host_vars/web1).
        vm.clear_host_facts();
        assert_eq!(get(&vm, &empty, None, None), "L10");

        // Peel L10 by removing host_vars/web1.yml → L07 wins
        // (playbook group_vars/prod).
        std::fs::remove_file(&hv_web1).unwrap();
        assert_eq!(get(&vm, &empty, None, None), "L07");

        // Peel L07 by removing group_vars/prod.yml → L05 wins
        // (playbook group_vars/all).
        std::fs::remove_file(&gv_prod).unwrap();
        assert_eq!(get(&vm, &empty, None, None), "L05");

        // Peel L05 → L03 wins (inventory group var).
        std::fs::remove_file(&gv_all).unwrap();
        assert_eq!(get(&vm, &empty, None, None), "L03");

        // Peel L03/L04 by clearing the basedir *and* the inventory group
        // var. The inventory is behind an `Arc` so we rebuild the vm with
        // a fresh, empty inventory.
        vm.clear_playbook_basedir();
        let empty_inv = Arc::new(ansible_inventory::InventoryManager::new());
        let mut vm2 = VariableManager::new(empty_inv);
        vm2.set_options_vars(sentinel("L01"));
        vm2.set_role_defaults("r", sentinel("L02"));
        // L02 wins over L01.
        assert_eq!(
            vm2.get_vars("web1", &empty, None, None, Some("r"))
                .get("v")
                .and_then(|v| v.as_str()),
            Some("L02")
        );

        // Peel L02 (no role context) → L01 (options) wins.
        assert_eq!(
            vm2.get_vars("web1", &empty, None, None, None)
                .get("v")
                .and_then(|v| v.as_str()),
            Some("L01")
        );
    }
}
