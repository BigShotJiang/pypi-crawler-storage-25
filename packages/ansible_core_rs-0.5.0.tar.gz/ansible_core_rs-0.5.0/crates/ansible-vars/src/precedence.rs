/// Ansible's 22-level variable precedence, from lowest to highest.
/// See: https://docs.ansible.com/ansible/latest/playbook_guide/playbooks_variables.html#variable-precedence
#[derive(Debug, Clone, Copy, PartialEq, Eq, PartialOrd, Ord, Hash)]
#[repr(u8)]
pub enum VariablePrecedence {
    /// 1. command line values (e.g. -u my_user, not -e)
    CommandLineValues = 1,
    /// 2. role defaults (roles/x/defaults/main.yml)
    RoleDefaults = 2,
    /// 3. inventory file or script group vars
    InventoryGroupVars = 3,
    /// 4. inventory group_vars/all
    InventoryGroupVarsAll = 4,
    /// 5. playbook group_vars/all
    PlaybookGroupVarsAll = 5,
    /// 6. inventory group_vars/*
    InventoryGroupVarsStar = 6,
    /// 7. playbook group_vars/*
    PlaybookGroupVarsStar = 7,
    /// 8. inventory file or script host vars
    InventoryHostVars = 8,
    /// 9. inventory host_vars/*
    InventoryHostVarsStar = 9,
    /// 10. playbook host_vars/*
    PlaybookHostVarsStar = 10,
    /// 11. host facts / cached set_facts
    HostFacts = 11,
    /// 12. play vars
    PlayVars = 12,
    /// 13. play vars_prompt
    PlayVarsPrompt = 13,
    /// 14. play vars_files
    PlayVarsFiles = 14,
    /// 15. role vars (roles/x/vars/main.yml)
    RoleVars = 15,
    /// 16. block vars (only for tasks in block)
    BlockVars = 16,
    /// 17. task vars (only for the task)
    TaskVars = 17,
    /// 18. include_vars
    IncludeVars = 18,
    /// 19. set_facts / registered vars
    SetFacts = 19,
    /// 20. role params
    RoleParams = 20,
    /// 21. include params
    IncludeParams = 21,
    /// 22. extra vars (-e) always win
    ExtraVars = 22,
}
