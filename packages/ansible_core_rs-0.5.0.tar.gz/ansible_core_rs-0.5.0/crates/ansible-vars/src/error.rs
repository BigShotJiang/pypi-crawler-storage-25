use thiserror::Error;

#[derive(Debug, Error)]
pub enum VarsError {
    #[error("variable resolution error: {0}")]
    ResolutionError(String),

    #[error("undefined variable: {0}")]
    UndefinedVariable(String),

    #[error(transparent)]
    Io(#[from] std::io::Error),
}
