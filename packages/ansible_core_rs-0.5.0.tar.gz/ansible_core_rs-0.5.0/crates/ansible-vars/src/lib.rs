pub mod error;
pub mod manager;
pub mod precedence;

pub use error::VarsError;
pub use manager::VariableManager;
