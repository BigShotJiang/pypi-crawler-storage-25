use std::collections::HashMap;
use std::path::Path;

use ansible_utils::AnsibleValue;
use async_trait::async_trait;

use crate::PluginError;

/// Connection plugins handle communication with remote hosts.
#[async_trait]
pub trait ConnectionPlugin: Send + Sync {
    /// Establish a connection to the remote host.
    async fn connect(&mut self) -> Result<(), PluginError>;

    /// Execute a command on the remote host.
    /// Returns (return_code, stdout, stderr).
    async fn exec_command(
        &self,
        cmd: &str,
        in_data: Option<&[u8]>,
    ) -> Result<(i32, Vec<u8>, Vec<u8>), PluginError>;

    /// Copy a file to the remote host.
    async fn put_file(&self, in_path: &Path, out_path: &Path) -> Result<(), PluginError>;

    /// Fetch a file from the remote host.
    async fn fetch_file(&self, in_path: &Path, out_path: &Path) -> Result<(), PluginError>;

    /// Close the connection.
    async fn close(&mut self) -> Result<(), PluginError>;
}

/// Callback plugins receive notifications about playbook execution events.
pub trait CallbackPlugin: Send + Sync {
    fn v2_playbook_on_start(&self, _playbook_file: &str) {}
    fn v2_playbook_on_play_start(&self, _play_name: &str) {}
    fn v2_playbook_on_task_start(&self, _task_name: &str, _is_conditional: bool) {}
    fn v2_runner_on_ok(&self, _host: &str, _result: &AnsibleValue) {}
    fn v2_runner_on_failed(&self, _host: &str, _result: &AnsibleValue, _ignore_errors: bool) {}
    fn v2_runner_on_skipped(&self, _host: &str, _result: &AnsibleValue) {}
    fn v2_runner_on_unreachable(&self, _host: &str, _result: &AnsibleValue) {}
    fn v2_playbook_on_stats(&self, _stats: &AnsibleValue) {}
    fn v2_on_any(&self, _event: &str, _data: &AnsibleValue) {}
}

/// Become plugins handle privilege escalation (sudo, su, etc.).
pub trait BecomePlugin: Send + Sync {
    /// Build the command string for privilege escalation.
    fn build_become_command(&self, cmd: &str, shell: &str) -> Result<String, PluginError>;

    /// Check if the output indicates a successful become.
    fn check_success(&self, output: &str) -> bool;

    /// Check if the output contains a password prompt.
    fn check_password_prompt(&self, output: &str) -> bool;
}

/// Shell plugins handle shell-specific command construction.
pub trait ShellPlugin: Send + Sync {
    fn join_path(&self, parts: &[&str]) -> String;
    fn get_remote_filename(&self, pathname: &str) -> String;
    fn mkdtemp(&self, basefile: &str) -> String;
    fn remove(&self, path: &str, recurse: bool) -> String;
    fn exists(&self, path: &str) -> String;
    fn expand_user(&self, user_home_path: &str) -> String;
}

/// Lookup plugins retrieve data from external sources.
pub trait LookupPlugin: Send + Sync {
    fn run(
        &self,
        terms: &[AnsibleValue],
        variables: &HashMap<String, AnsibleValue>,
    ) -> Result<Vec<AnsibleValue>, PluginError>;
}

/// Filter plugins provide Jinja2 filter functions.
pub trait FilterPlugin: Send + Sync {
    fn filters(&self) -> HashMap<String, FilterFn>;
}

/// A filter function that transforms an AnsibleValue.
pub type FilterFn = Box<dyn Fn(&AnsibleValue, &[AnsibleValue]) -> Result<AnsibleValue, PluginError> + Send + Sync>;

/// Test plugins provide Jinja2 test functions.
pub trait TestPlugin: Send + Sync {
    fn tests(&self) -> HashMap<String, TestFn>;
}

/// A test function that evaluates to bool.
pub type TestFn = Box<dyn Fn(&AnsibleValue, &[AnsibleValue]) -> Result<bool, PluginError> + Send + Sync>;

/// Inventory plugins parse inventory sources.
pub trait InventoryPlugin: Send + Sync {
    /// Check if this plugin can handle the given source file.
    fn verify_file(&self, path: &Path) -> bool;

    /// Parse the inventory source and populate the inventory data.
    fn parse(
        &self,
        path: &Path,
    ) -> Result<ansible_utils::InventoryData, PluginError>;
}

/// Vars plugins supply additional variables from external sources.
pub trait VarsPlugin: Send + Sync {
    fn get_vars(
        &self,
        path: &Path,
        entities: &[&str],
    ) -> Result<HashMap<String, AnsibleValue>, PluginError>;
}
