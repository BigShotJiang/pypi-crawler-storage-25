use std::collections::HashMap;
use std::io::IsTerminal;

use ansible_utils::{AggregateStats, AnsibleValue, TaskResult};

use crate::traits::CallbackPlugin;

/// ANSI color codes for terminal output.
mod colors {
    pub const RESET: &str = "\x1b[0m";
    pub const GREEN: &str = "\x1b[0;32m";
    pub const YELLOW: &str = "\x1b[0;33m";
    pub const RED: &str = "\x1b[0;31m";
    pub const CYAN: &str = "\x1b[0;36m";
    #[allow(dead_code)]
    pub const PURPLE: &str = "\x1b[0;35m";
    pub const BOLD: &str = "\x1b[1m";
}

/// The default stdout callback plugin — produces the standard Ansible output format.
///
/// This matches the output format of Python's `plugins/callback/default.py`.
pub struct DefaultCallback {
    use_colors: bool,
}

impl DefaultCallback {
    pub fn new() -> Self {
        let use_colors = std::env::var("ANSIBLE_NOCOLOR")
            .map(|v| v != "1" && v.to_lowercase() != "true")
            .unwrap_or(true)
            && atty_stdout();

        Self { use_colors }
    }

    fn color(&self, text: &str, color: &str) -> String {
        if self.use_colors {
            format!("{color}{text}{}", colors::RESET)
        } else {
            text.to_string()
        }
    }

    fn banner(&self, msg: &str, color: &str) {
        let stars = "*".repeat(std::cmp::max(1, 72_usize.saturating_sub(msg.len() + 1)));
        println!("{}", self.color(&format!("\n{msg} {stars}"), color));
    }

    fn host_label(&self, result: &TaskResult) -> String {
        let host = &result.host;
        if let Some(delegate) = result
            .results
            .get("_ansible_delegated_vars")
            .and_then(|v| v.get("ansible_host"))
            .and_then(|v| v.as_str())
        {
            format!("{host} -> {delegate}")
        } else {
            host.to_string()
        }
    }

    fn display_result_detail(&self, result: &TaskResult, color: &str) {
        let safe = result.safe_results();
        // Check for msg in both the nested results object AND the top-level
        // TaskResult.msg field (used by debug module and others).
        let nested_msg = safe
            .as_object()
            .and_then(|o| o.get("msg"))
            .and_then(|v| v.as_str())
            .filter(|s| !s.is_empty());
        let top_msg = result.msg.as_deref().filter(|s| !s.is_empty());
        let effective_msg = nested_msg.or(top_msg);

        if let Some(obj) = safe.as_object() {
            let has_msg = effective_msg.is_some();
            let has_stdout = obj.get("stdout").and_then(|v| v.as_str()).is_some_and(|s| !s.is_empty());
            let has_stderr = obj.get("stderr").and_then(|v| v.as_str()).is_some_and(|s| !s.is_empty());

            // Show msg if present (from nested results or top-level TaskResult.msg)
            if let Some(msg) = effective_msg {
                println!("{}", self.color(&format!("  msg: {msg}"), color));
            }
            // Show stdout if present and non-empty
            if let Some(stdout) = obj.get("stdout").and_then(|v| v.as_str()) {
                if !stdout.is_empty() {
                    println!("  stdout: {stdout}");
                }
            }
            // Show stderr if present and non-empty
            if let Some(stderr) = obj.get("stderr").and_then(|v| v.as_str()) {
                if !stderr.is_empty() {
                    println!("{}", self.color(&format!("  stderr: {stderr}"), colors::RED));
                }
            }
            // If there's no msg/stdout/stderr, show the result JSON
            // (useful for modules like ping that return structured data)
            if !has_msg && !has_stdout && !has_stderr && !obj.is_empty() {
                // Filter out internal keys
                let filtered: serde_json::Map<String, AnsibleValue> = obj
                    .iter()
                    .filter(|(k, _)| !k.starts_with('_') && *k != "ansible_facts")
                    .map(|(k, v)| (k.clone(), v.clone()))
                    .collect();
                if !filtered.is_empty() {
                    if let Ok(json) = serde_json::to_string(&filtered) {
                        println!("  => {json}");
                    }
                }
            }
        } else if let Some(msg) = effective_msg {
            // safe_results() wasn't an object but we still have a msg
            println!("{}", self.color(&format!("  msg: {msg}"), color));
        }
    }
}

impl Default for DefaultCallback {
    fn default() -> Self {
        Self::new()
    }
}

impl CallbackPlugin for DefaultCallback {
    fn v2_playbook_on_start(&self, _playbook_file: &str) {
        // Python default callback doesn't output anything here
    }

    fn v2_playbook_on_play_start(&self, play_name: &str) {
        self.banner(&format!("PLAY [{play_name}]"), colors::BOLD);
    }

    fn v2_playbook_on_task_start(&self, task_name: &str, _is_conditional: bool) {
        self.banner(&format!("TASK [{task_name}]"), colors::BOLD);
    }

    fn v2_runner_on_ok(&self, host: &str, result: &AnsibleValue) {
        let task_result = deserialize_callback_result(host, result);
        let label = self.host_label(&task_result);

        if task_result.is_changed() {
            println!(
                "{}",
                self.color(&format!("changed: [{label}]"), colors::YELLOW)
            );
            self.display_result_detail(&task_result, colors::YELLOW);
        } else {
            println!(
                "{}",
                self.color(&format!("ok: [{label}]"), colors::GREEN)
            );
            self.display_result_detail(&task_result, colors::GREEN);
        }
    }

    fn v2_runner_on_failed(&self, host: &str, result: &AnsibleValue, ignore_errors: bool) {
        let task_result = deserialize_callback_result(host, result);
        let label = self.host_label(&task_result);

        if ignore_errors {
            println!(
                "{}",
                self.color(
                    &format!("fatal: [{label}]: FAILED! ...ignoring"),
                    colors::CYAN
                )
            );
        } else {
            println!(
                "{}",
                self.color(&format!("fatal: [{label}]: FAILED!"), colors::RED)
            );
        }

        self.display_result_detail(&task_result, colors::RED);
    }

    fn v2_runner_on_skipped(&self, host: &str, _result: &AnsibleValue) {
        println!(
            "{}",
            self.color(&format!("skipping: [{host}]"), colors::CYAN)
        );
    }

    fn v2_runner_on_unreachable(&self, host: &str, result: &AnsibleValue) {
        let task_result = deserialize_callback_result(host, result);
        let label = self.host_label(&task_result);
        let msg = task_result.msg.as_deref().unwrap_or("UNREACHABLE!");

        println!(
            "{}",
            self.color(
                &format!("fatal: [{label}]: UNREACHABLE! => {msg}"),
                colors::RED
            )
        );
    }

    fn v2_playbook_on_stats(&self, stats: &AnsibleValue) {
        self.banner("PLAY RECAP", colors::BOLD);

        // Deserialize stats
        if let Ok(agg_stats) = serde_json::from_value::<AggregateStats>(stats.clone()) {
            for host in agg_stats.all_hosts() {
                let ok = agg_stats.ok.get(&host).unwrap_or(&0);
                let changed = agg_stats.changed.get(&host).unwrap_or(&0);
                let unreachable = agg_stats.dark.get(&host).unwrap_or(&0);
                let failed = agg_stats.failures.get(&host).unwrap_or(&0);
                let skipped = agg_stats.skipped.get(&host).unwrap_or(&0);
                let rescued = agg_stats.rescued.get(&host).unwrap_or(&0);
                let ignored = agg_stats.ignored.get(&host).unwrap_or(&0);

                let host_color = if *failed > 0 || *unreachable > 0 {
                    colors::RED
                } else if *changed > 0 {
                    colors::YELLOW
                } else {
                    colors::GREEN
                };

                let line = format!(
                    "{host:<30} : ok={ok:<4} changed={changed:<4} unreachable={unreachable:<4} failed={failed:<4} skipped={skipped:<4} rescued={rescued:<4} ignored={ignored:<4}"
                );
                println!("{}", self.color(&line, host_color));
            }
        }
    }

    fn v2_on_any(&self, _event: &str, _data: &AnsibleValue) {
        // Default callback doesn't handle generic events
    }
}

/// Construct a minimal TaskResult from callback data.
///
/// The callback receives a serialized TaskResult where the module's
/// output is nested under the `results` key. We extract that inner
/// blob so `safe_results()` / `display_result_detail()` can find
/// keys like `stdout`, `stderr`, `rc`, `msg` at the top level.
fn deserialize_callback_result(host: &str, data: &AnsibleValue) -> TaskResult {
    // The inner `results` object contains the module output (rc, stdout, etc.).
    // Fall back to the whole blob for backwards compatibility.
    let inner_results = data
        .get("results")
        .cloned()
        .unwrap_or_else(|| data.clone());

    TaskResult {
        host: host.into(),
        task_uuid: None,
        changed: data
            .get("changed")
            .and_then(|v| v.as_bool())
            .unwrap_or(false),
        failed: data
            .get("failed")
            .and_then(|v| v.as_bool())
            .unwrap_or(false),
        skipped: data
            .get("skipped")
            .and_then(|v| v.as_bool())
            .unwrap_or(false),
        unreachable: data
            .get("unreachable")
            .and_then(|v| v.as_bool())
            .unwrap_or(false),
        msg: data
            .get("msg")
            .and_then(|v| v.as_str())
            .or_else(|| inner_results.get("msg").and_then(|v| v.as_str()))
            .map(String::from),
        results: inner_results,
        warnings: Vec::new(),
        deprecations: Vec::new(),
        attempts: 0,
        no_log: data
            .get("_ansible_no_log")
            .and_then(|v| v.as_bool())
            .unwrap_or(false),
        task_fields: HashMap::new(),
    }
}

/// Check if stdout is a terminal.
fn atty_stdout() -> bool {
    std::io::stdout().is_terminal()
}
