use std::collections::HashMap;

use ansible_utils::AnsibleValue;

use crate::{LookupPlugin, PluginError};

/// The `file` lookup plugin — reads contents of files.
pub struct FileLookup;

impl LookupPlugin for FileLookup {
    fn run(
        &self,
        terms: &[AnsibleValue],
        _variables: &HashMap<String, AnsibleValue>,
    ) -> Result<Vec<AnsibleValue>, PluginError> {
        let mut results = Vec::new();

        for term in terms {
            let path = term
                .as_str()
                .ok_or_else(|| PluginError::LookupError("file lookup requires string path".into()))?;

            let content = std::fs::read_to_string(path).map_err(|e| {
                PluginError::LookupError(format!("could not read file '{}': {}", path, e))
            })?;

            results.push(AnsibleValue::String(content));
        }

        Ok(results)
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    #[test]
    fn test_file_lookup() {
        let mut tmp = tempfile::NamedTempFile::new().unwrap();
        write!(tmp, "hello world").unwrap();

        let lookup = FileLookup;
        let terms = vec![AnsibleValue::String(
            tmp.path().to_string_lossy().to_string(),
        )];
        let results = lookup.run(&terms, &HashMap::new()).unwrap();
        assert_eq!(results.len(), 1);
        assert_eq!(results[0].as_str(), Some("hello world"));
    }

    #[test]
    fn test_file_lookup_missing() {
        let lookup = FileLookup;
        let terms = vec![AnsibleValue::String("/nonexistent/file".into())];
        assert!(lookup.run(&terms, &HashMap::new()).is_err());
    }
}
