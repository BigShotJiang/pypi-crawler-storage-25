use std::collections::HashMap;
use std::path::Path;

use ansible_utils::AnsibleValue;

use crate::{LookupPlugin, PluginError};

/// The `first_found` lookup plugin — returns the first file that exists.
pub struct FirstFoundLookup;

impl LookupPlugin for FirstFoundLookup {
    fn run(
        &self,
        terms: &[AnsibleValue],
        _variables: &HashMap<String, AnsibleValue>,
    ) -> Result<Vec<AnsibleValue>, PluginError> {
        for term in terms {
            let path_str = term.as_str().ok_or_else(|| {
                PluginError::LookupError("first_found requires string paths".into())
            })?;

            if Path::new(path_str).exists() {
                return Ok(vec![AnsibleValue::String(path_str.to_string())]);
            }
        }

        Err(PluginError::LookupError(
            "no file was found when using first_found".into(),
        ))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_first_found_existing() {
        let lookup = FirstFoundLookup;
        let terms = vec![
            AnsibleValue::String("/nonexistent".into()),
            AnsibleValue::String("/tmp".into()),
        ];
        let results = lookup.run(&terms, &HashMap::new()).unwrap();
        assert_eq!(results[0].as_str(), Some("/tmp"));
    }

    #[test]
    fn test_first_found_none() {
        let lookup = FirstFoundLookup;
        let terms = vec![
            AnsibleValue::String("/nonexistent1".into()),
            AnsibleValue::String("/nonexistent2".into()),
        ];
        assert!(lookup.run(&terms, &HashMap::new()).is_err());
    }
}
