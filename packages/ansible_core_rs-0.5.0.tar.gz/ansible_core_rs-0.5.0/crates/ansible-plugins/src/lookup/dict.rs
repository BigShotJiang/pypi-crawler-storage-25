use std::collections::HashMap;

use ansible_utils::AnsibleValue;

use crate::{LookupPlugin, PluginError};

/// The `dict` lookup plugin — converts a dict to a list of key/value pairs.
/// Used by `with_dict`.
pub struct DictLookup;

impl LookupPlugin for DictLookup {
    fn run(
        &self,
        terms: &[AnsibleValue],
        _variables: &HashMap<String, AnsibleValue>,
    ) -> Result<Vec<AnsibleValue>, PluginError> {
        let mut results = Vec::new();

        for term in terms {
            match term {
                AnsibleValue::Object(map) => {
                    for (k, v) in map {
                        results.push(serde_json::json!({
                            "key": k,
                            "value": v,
                        }));
                    }
                }
                _ => {
                    return Err(PluginError::LookupError(
                        "dict lookup expects a dictionary".into(),
                    ));
                }
            }
        }

        Ok(results)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_dict_lookup() {
        let lookup = DictLookup;
        let terms = vec![serde_json::json!({"name": "web", "port": 80})];
        let results = lookup.run(&terms, &HashMap::new()).unwrap();
        assert_eq!(results.len(), 2);
        // Each result should have key/value
        for r in &results {
            assert!(r.get("key").is_some());
            assert!(r.get("value").is_some());
        }
    }
}
