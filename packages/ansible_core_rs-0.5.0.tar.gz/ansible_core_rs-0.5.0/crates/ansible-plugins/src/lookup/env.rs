use std::collections::HashMap;

use ansible_utils::AnsibleValue;

use crate::{LookupPlugin, PluginError};

/// The `env` lookup plugin — reads environment variables.
pub struct EnvLookup;

impl LookupPlugin for EnvLookup {
    fn run(
        &self,
        terms: &[AnsibleValue],
        _variables: &HashMap<String, AnsibleValue>,
    ) -> Result<Vec<AnsibleValue>, PluginError> {
        let mut results = Vec::new();

        for term in terms {
            let var_name = term
                .as_str()
                .ok_or_else(|| PluginError::LookupError("env lookup requires string name".into()))?;

            let value = std::env::var(var_name).unwrap_or_default();
            results.push(AnsibleValue::String(value));
        }

        Ok(results)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_env_lookup() {
        std::env::set_var("ANSIBLE_TEST_LOOKUP_VAR", "test_value");
        let lookup = EnvLookup;
        let terms = vec![AnsibleValue::String("ANSIBLE_TEST_LOOKUP_VAR".into())];
        let results = lookup.run(&terms, &HashMap::new()).unwrap();
        assert_eq!(results[0].as_str(), Some("test_value"));
        std::env::remove_var("ANSIBLE_TEST_LOOKUP_VAR");
    }

    #[test]
    fn test_env_lookup_missing() {
        let lookup = EnvLookup;
        let terms = vec![AnsibleValue::String("ANSIBLE_NONEXISTENT_12345".into())];
        let results = lookup.run(&terms, &HashMap::new()).unwrap();
        assert_eq!(results[0].as_str(), Some(""));
    }
}
