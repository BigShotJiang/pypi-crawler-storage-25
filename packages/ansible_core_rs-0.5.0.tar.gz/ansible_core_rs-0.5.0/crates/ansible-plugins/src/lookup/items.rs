use std::collections::HashMap;

use ansible_utils::AnsibleValue;

use crate::{LookupPlugin, PluginError};

/// The `items` lookup plugin — returns items as-is (used by `with_items`).
pub struct ItemsLookup;

impl LookupPlugin for ItemsLookup {
    fn run(
        &self,
        terms: &[AnsibleValue],
        _variables: &HashMap<String, AnsibleValue>,
    ) -> Result<Vec<AnsibleValue>, PluginError> {
        let mut results = Vec::new();
        for term in terms {
            match term {
                AnsibleValue::Array(arr) => results.extend(arr.iter().cloned()),
                other => results.push(other.clone()),
            }
        }
        Ok(results)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_items_flat() {
        let lookup = ItemsLookup;
        let terms = vec![
            AnsibleValue::String("a".into()),
            AnsibleValue::String("b".into()),
        ];
        let results = lookup.run(&terms, &HashMap::new()).unwrap();
        assert_eq!(results.len(), 2);
    }

    #[test]
    fn test_items_flatten_arrays() {
        let lookup = ItemsLookup;
        let terms = vec![serde_json::json!(["a", "b", "c"])];
        let results = lookup.run(&terms, &HashMap::new()).unwrap();
        assert_eq!(results.len(), 3);
    }
}
