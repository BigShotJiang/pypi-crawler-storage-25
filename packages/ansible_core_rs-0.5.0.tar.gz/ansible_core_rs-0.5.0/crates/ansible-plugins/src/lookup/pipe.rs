use std::collections::HashMap;
use std::process::Command;

use ansible_utils::AnsibleValue;

use crate::{LookupPlugin, PluginError};

/// The `pipe` lookup plugin — runs a command and returns stdout.
pub struct PipeLookup;

impl LookupPlugin for PipeLookup {
    fn run(
        &self,
        terms: &[AnsibleValue],
        _variables: &HashMap<String, AnsibleValue>,
    ) -> Result<Vec<AnsibleValue>, PluginError> {
        let mut results = Vec::new();

        for term in terms {
            let cmd = term
                .as_str()
                .ok_or_else(|| PluginError::LookupError("pipe lookup requires string command".into()))?;

            let output = Command::new("sh")
                .arg("-c")
                .arg(cmd)
                .output()
                .map_err(|e| {
                    PluginError::LookupError(format!("pipe command failed: {}", e))
                })?;

            if !output.status.success() {
                return Err(PluginError::LookupError(format!(
                    "pipe command '{}' returned non-zero: {}",
                    cmd,
                    String::from_utf8_lossy(&output.stderr)
                )));
            }

            let stdout = String::from_utf8_lossy(&output.stdout)
                .trim_end_matches('\n')
                .to_string();

            results.push(AnsibleValue::String(stdout));
        }

        Ok(results)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_pipe_echo() {
        let lookup = PipeLookup;
        let terms = vec![AnsibleValue::String("echo hello".into())];
        let results = lookup.run(&terms, &HashMap::new()).unwrap();
        assert_eq!(results[0].as_str(), Some("hello"));
    }

    #[test]
    fn test_pipe_failure() {
        let lookup = PipeLookup;
        let terms = vec![AnsibleValue::String("false".into())];
        assert!(lookup.run(&terms, &HashMap::new()).is_err());
    }
}
