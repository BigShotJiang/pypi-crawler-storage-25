use std::collections::HashMap;

use ansible_utils::AnsibleValue;

use crate::{LookupPlugin, PluginError};

/// The `sequence` lookup plugin — generates a list of numbers.
/// Used by `with_sequence`.
pub struct SequenceLookup;

impl LookupPlugin for SequenceLookup {
    fn run(
        &self,
        terms: &[AnsibleValue],
        _variables: &HashMap<String, AnsibleValue>,
    ) -> Result<Vec<AnsibleValue>, PluginError> {
        let mut results = Vec::new();

        for term in terms {
            let spec = term
                .as_str()
                .ok_or_else(|| PluginError::LookupError("sequence requires string spec".into()))?;

            let (start, end, stride, format_str) = parse_sequence_spec(spec)?;

            let mut i = start;
            while (stride > 0 && i <= end) || (stride < 0 && i >= end) {
                let formatted = if let Some(ref fmt) = format_str {
                    fmt.replace("%d", &i.to_string())
                        .replace("%02d", &format!("{:02}", i))
                        .replace("%03d", &format!("{:03}", i))
                        .replace("%i", &i.to_string())
                } else {
                    i.to_string()
                };
                results.push(AnsibleValue::String(formatted));
                i += stride;
            }
        }

        Ok(results)
    }
}

/// Parse a sequence specification string.
/// Format: "start=N end=M stride=S format=FMT" or "start-end" or just "N-M/S"
fn parse_sequence_spec(spec: &str) -> Result<(i64, i64, i64, Option<String>), PluginError> {
    let mut start = 1i64;
    let mut end = 1i64;
    let mut stride = 1i64;
    let mut format_str = None;

    // Check for key=value format
    if spec.contains('=') {
        for part in spec.split_whitespace() {
            if let Some((key, value)) = part.split_once('=') {
                match key {
                    "start" => {
                        start = value.parse().map_err(|_| {
                            PluginError::LookupError(format!("invalid start: {}", value))
                        })?;
                    }
                    "end" | "count" => {
                        end = value.parse().map_err(|_| {
                            PluginError::LookupError(format!("invalid end: {}", value))
                        })?;
                    }
                    "stride" => {
                        stride = value.parse().map_err(|_| {
                            PluginError::LookupError(format!("invalid stride: {}", value))
                        })?;
                    }
                    "format" => {
                        format_str = Some(value.to_string());
                    }
                    _ => {}
                }
            }
        }
    } else if let Some((s, rest)) = spec.split_once('-') {
        start = s.parse().map_err(|_| {
            PluginError::LookupError(format!("invalid start: {}", s))
        })?;
        if let Some((e, st)) = rest.split_once('/') {
            end = e.parse().map_err(|_| {
                PluginError::LookupError(format!("invalid end: {}", e))
            })?;
            stride = st.parse().map_err(|_| {
                PluginError::LookupError(format!("invalid stride: {}", st))
            })?;
        } else {
            end = rest.parse().map_err(|_| {
                PluginError::LookupError(format!("invalid end: {}", rest))
            })?;
        }
    } else {
        end = spec.parse().map_err(|_| {
            PluginError::LookupError(format!("invalid sequence spec: {}", spec))
        })?;
    }

    if stride == 0 {
        return Err(PluginError::LookupError("stride cannot be 0".into()));
    }

    Ok((start, end, stride, format_str))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_sequence_simple_range() {
        let lookup = SequenceLookup;
        let terms = vec![AnsibleValue::String("1-5".into())];
        let results = lookup.run(&terms, &HashMap::new()).unwrap();
        assert_eq!(results.len(), 5);
        assert_eq!(results[0].as_str(), Some("1"));
        assert_eq!(results[4].as_str(), Some("5"));
    }

    #[test]
    fn test_sequence_with_stride() {
        let lookup = SequenceLookup;
        let terms = vec![AnsibleValue::String("0-10/2".into())];
        let results = lookup.run(&terms, &HashMap::new()).unwrap();
        assert_eq!(results.len(), 6); // 0, 2, 4, 6, 8, 10
    }

    #[test]
    fn test_sequence_key_value() {
        let lookup = SequenceLookup;
        let terms = vec![AnsibleValue::String("start=1 end=3".into())];
        let results = lookup.run(&terms, &HashMap::new()).unwrap();
        assert_eq!(results.len(), 3);
    }

    #[test]
    fn test_sequence_with_format() {
        let lookup = SequenceLookup;
        let terms = vec![AnsibleValue::String("start=1 end=3 format=host%02d".into())];
        let results = lookup.run(&terms, &HashMap::new()).unwrap();
        assert_eq!(results[0].as_str(), Some("host01"));
        assert_eq!(results[2].as_str(), Some("host03"));
    }
}
