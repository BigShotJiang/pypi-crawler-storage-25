use thiserror::Error;

#[derive(Debug, Error)]
pub enum PluginError {
    #[error("plugin not found: {plugin_type:?}/{name}")]
    NotFound {
        plugin_type: super::PluginType,
        name: String,
    },

    #[error("plugin load error: {0}")]
    LoadError(String),

    #[error("plugin execution error: {0}")]
    ExecutionError(String),

    #[error("lookup error: {0}")]
    LookupError(String),

    #[error(transparent)]
    Io(#[from] std::io::Error),
}
