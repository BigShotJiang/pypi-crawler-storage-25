//! Plugin discovery and loading.
//!
//! The [`PluginLoader`] is the runtime answer to "where is the plugin for X?"
//! It searches three sources, in order of priority:
//!
//! 1. **Explicit search paths** — directories the caller has added via
//!    [`PluginLoader::add_search_path`]. First match wins.
//! 2. **FQCN resolution** — if the plugin name looks like a fully-qualified
//!    collection name (`ns.col.plugin`), resolve it against the collection
//!    router (which reads `ANSIBLE_COLLECTIONS_PATH`).
//! 3. **Legacy name resolution** — for unqualified names like `ini_file`,
//!    first check `ansible.builtin.<name>`, then scan all installed
//!    collections for a matching short name (first collection root wins).
//!
//! Resolved paths are cached so repeated lookups for the same plugin are O(1).

use std::collections::HashMap;
use std::path::PathBuf;
use std::sync::Mutex;

use ansible_galaxy::router::{CollectionRouter, Fqcn, PluginType as GalaxyPluginType};

use crate::{PluginError, PluginType};

/// Convert our crate-level PluginType to the Galaxy router's PluginType.
fn to_galaxy_plugin_type(pt: PluginType) -> GalaxyPluginType {
    match pt {
        PluginType::Action => GalaxyPluginType::Action,
        PluginType::Become => GalaxyPluginType::Become,
        PluginType::Cache => GalaxyPluginType::Cache,
        PluginType::Callback => GalaxyPluginType::Callback,
        PluginType::Cliconf => GalaxyPluginType::Cliconf,
        PluginType::Connection => GalaxyPluginType::Connection,
        PluginType::Filter => GalaxyPluginType::Filter,
        PluginType::HttpApi => GalaxyPluginType::Httpapi,
        PluginType::Inventory => GalaxyPluginType::Inventory,
        PluginType::Lookup => GalaxyPluginType::Lookup,
        PluginType::Module => GalaxyPluginType::Module,
        PluginType::Netconf => GalaxyPluginType::Netconf,
        PluginType::Shell => GalaxyPluginType::Connection, // closest analog
        PluginType::Strategy => GalaxyPluginType::Strategy,
        PluginType::Terminal => GalaxyPluginType::Terminal,
        PluginType::Test => GalaxyPluginType::Test,
        PluginType::Vars => GalaxyPluginType::Vars,
        // ModuleUtils and Doc don't have direct Galaxy analogs
        PluginType::ModuleUtils | PluginType::Doc => GalaxyPluginType::Module,
    }
}

/// A plugin that was resolved by the loader.
#[derive(Debug, Clone)]
pub struct ResolvedPlugin {
    /// Filesystem path to the plugin source.
    pub path: PathBuf,
    /// The file extension — `.py` for Python, `.rs` for Rust-native stubs,
    /// `.yml` for YAML redirect stubs.
    pub extension: String,
    /// Whether the plugin is a Python source file.
    pub is_python: bool,
}

impl ResolvedPlugin {
    fn from_path(path: PathBuf) -> Self {
        let ext = path
            .extension()
            .and_then(|e| e.to_str())
            .unwrap_or("")
            .to_string();
        let is_python = ext == "py";
        Self {
            path,
            extension: ext,
            is_python,
        }
    }

    /// Read the plugin source code (only meaningful for Python plugins).
    pub fn read_source(&self) -> Result<String, PluginError> {
        std::fs::read_to_string(&self.path).map_err(|e| {
            PluginError::LoadError(format!("read {}: {e}", self.path.display()))
        })
    }
}

/// Discovers and loads plugins from configured search paths and collections.
pub struct PluginLoader {
    /// Explicit search paths for each plugin type.
    search_paths: HashMap<PluginType, Vec<PathBuf>>,
    /// FQCN → collection root resolver.
    router: CollectionRouter,
    /// Cache: (plugin_type, name) → resolved plugin.
    cache: Mutex<HashMap<(PluginType, String), ResolvedPlugin>>,
}

impl PluginLoader {
    pub fn new() -> Self {
        Self {
            search_paths: HashMap::new(),
            router: CollectionRouter::new(),
            cache: Mutex::new(HashMap::new()),
        }
    }

    /// Create a loader that searches installed collections via
    /// `ANSIBLE_COLLECTIONS_PATH`.
    pub fn from_env() -> Self {
        Self {
            search_paths: HashMap::new(),
            router: CollectionRouter::from_env(),
            cache: Mutex::new(HashMap::new()),
        }
    }

    /// Add a search path for a given plugin type.
    pub fn add_search_path(&mut self, plugin_type: PluginType, path: PathBuf) {
        self.search_paths
            .entry(plugin_type)
            .or_default()
            .push(path);
    }

    /// Add a collection root (parent of `ansible_collections/`).
    pub fn add_collection_root(&mut self, root: impl Into<PathBuf>) -> &mut Self {
        self.router.add_root(root);
        self
    }

    /// Find a plugin by type and name.
    ///
    /// Resolution order:
    /// 1. Check the cache.
    /// 2. Search explicit paths (first `.rs`, then `.py`).
    /// 3. If the name contains at least two dots, try FQCN resolution.
    /// 4. Try legacy resolution: `ansible.builtin.<name>`, then scan all
    ///    collections for a matching short name.
    pub fn find_plugin(
        &self,
        plugin_type: PluginType,
        name: &str,
    ) -> Result<ResolvedPlugin, PluginError> {
        // 1. Cache
        {
            let cache = self.cache.lock().unwrap_or_else(|p| p.into_inner());
            if let Some(resolved) = cache.get(&(plugin_type, name.to_string())) {
                return Ok(resolved.clone());
            }
        }

        // 2. Explicit search paths
        if let Some(resolved) = self.search_explicit_paths(plugin_type, name) {
            self.cache_resolved(plugin_type, name, &resolved);
            return Ok(resolved);
        }

        // 3. FQCN resolution
        if let Ok(fqcn) = Fqcn::parse(name) {
            if let Ok(resolved) = self.resolve_fqcn(plugin_type, &fqcn) {
                self.cache_resolved(plugin_type, name, &resolved);
                return Ok(resolved);
            }
        }

        // 4. Legacy name resolution
        if let Some(resolved) = self.resolve_legacy(plugin_type, name) {
            self.cache_resolved(plugin_type, name, &resolved);
            return Ok(resolved);
        }

        Err(PluginError::NotFound {
            plugin_type,
            name: name.to_string(),
        })
    }

    /// Search explicitly-added paths for a plugin file.
    fn search_explicit_paths(
        &self,
        plugin_type: PluginType,
        name: &str,
    ) -> Option<ResolvedPlugin> {
        let paths = self.search_paths.get(&plugin_type)?;
        let subdir = plugin_type.subdir();
        for base_path in paths {
            // Try the subdir/join pattern: base/subdir/name.ext
            for ext in &["rs", "py", "yml"] {
                let candidate = base_path.join(subdir).join(format!("{name}.{ext}"));
                if candidate.is_file() {
                    return Some(ResolvedPlugin::from_path(candidate));
                }
            }
            // Try direct: base/name.ext (no subdir nesting)
            for ext in &["rs", "py", "yml"] {
                let candidate = base_path.join(format!("{name}.{ext}"));
                if candidate.is_file() {
                    return Some(ResolvedPlugin::from_path(candidate));
                }
            }
        }
        None
    }

    /// Resolve via FQCN against installed collections.
    fn resolve_fqcn(
        &self,
        plugin_type: PluginType,
        fqcn: &Fqcn,
    ) -> Result<ResolvedPlugin, PluginError> {
        let galaxy_type = to_galaxy_plugin_type(plugin_type);
        self.router
            .resolve_fqcn(fqcn, galaxy_type)
            .map(ResolvedPlugin::from_path)
            .map_err(|_| PluginError::NotFound {
                plugin_type,
                name: fqcn.to_string(),
            })
    }

    /// Legacy resolution: try `ansible.builtin.<name>`, then scan all
    /// collections for a matching short name.
    fn resolve_legacy(
        &self,
        plugin_type: PluginType,
        name: &str,
    ) -> Option<ResolvedPlugin> {
        let galaxy_type = to_galaxy_plugin_type(plugin_type);

        // Try ansible.builtin first
        if let Ok(fqcn) = Fqcn::parse(&format!("ansible.builtin.{name}")) {
            if let Ok(path) = self.router.resolve_fqcn(&fqcn, galaxy_type) {
                return Some(ResolvedPlugin::from_path(path));
            }
        }

        // Scan all installed collections for the short name
        let all_collections = self.list_known_collections();
        for (ns, col_name) in all_collections {
            if let Ok(fqcn) = Fqcn::parse(&format!("{ns}.{col_name}.{name}")) {
                if let Ok(path) = self.router.resolve_fqcn(&fqcn, galaxy_type) {
                    return Some(ResolvedPlugin::from_path(path));
                }
            }
        }

        None
    }

    /// Discover all (namespace, name) pairs across all collection roots.
    fn list_known_collections(&self) -> Vec<(String, String)> {
        let mut collections = Vec::new();
        let roots = self.router.roots();
        for root in roots {
            let ac_dir = root.join("ansible_collections");
            let Ok(ns_iter) = std::fs::read_dir(&ac_dir) else {
                continue;
            };
            for ns_entry in ns_iter.flatten() {
                let ns_name = match ns_entry.file_name().to_str() {
                    Some(n) => n.to_string(),
                    None => continue,
                };
                let Ok(col_iter) = std::fs::read_dir(ns_entry.path()) else {
                    continue;
                };
                for col_entry in col_iter.flatten() {
                    let col_name = match col_entry.file_name().to_str() {
                        Some(n) => n.to_string(),
                        None => continue,
                    };
                    // Verify it looks like a collection (has plugins/ dir or galaxy.yml)
                    if col_entry.path().join("plugins").is_dir()
                        || col_entry.path().join("galaxy.yml").is_file()
                    {
                        collections.push((ns_name.clone(), col_name));
                    }
                }
            }
        }
        collections
    }

    fn cache_resolved(&self, plugin_type: PluginType, name: &str, resolved: &ResolvedPlugin) {
        let mut cache = self.cache.lock().unwrap_or_else(|p| p.into_inner());
        cache.insert((plugin_type, name.to_string()), resolved.clone());
    }

    /// Clear the resolution cache.
    pub fn clear_cache(&self) {
        let mut cache = self.cache.lock().unwrap_or_else(|p| p.into_inner());
        cache.clear();
    }
}

impl Default for PluginLoader {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::path::Path;

    fn touch(p: &Path) {
        std::fs::create_dir_all(p.parent().unwrap()).unwrap();
        std::fs::write(p, "# test plugin\n").unwrap();
    }

    #[test]
    fn test_explicit_path_rs() {
        let tmp = tempfile::tempdir().unwrap();
        let dir = tmp.path().join("action");
        touch(&dir.join("copy.rs"));

        let mut loader = PluginLoader::new();
        loader.add_search_path(PluginType::Action, tmp.path().to_path_buf());

        let resolved = loader.find_plugin(PluginType::Action, "copy").unwrap();
        assert!(resolved.path.ends_with("copy.rs"));
        assert!(!resolved.is_python);
    }

    #[test]
    fn test_explicit_path_py() {
        let tmp = tempfile::tempdir().unwrap();
        let dir = tmp.path().join("connection");
        touch(&dir.join("ssh.py"));

        let mut loader = PluginLoader::new();
        loader.add_search_path(PluginType::Connection, tmp.path().to_path_buf());

        let resolved = loader
            .find_plugin(PluginType::Connection, "ssh")
            .unwrap();
        assert!(resolved.path.ends_with("ssh.py"));
        assert!(resolved.is_python);
    }

    #[test]
    fn test_fqcn_resolution() {
        let tmp = tempfile::tempdir().unwrap();
        let root = tmp.path();
        touch(
            &root.join(
                "ansible_collections/community/general/plugins/modules/ini_file.py",
            ),
        );

        let mut loader = PluginLoader::new();
        loader.add_collection_root(root);

        let resolved = loader
            .find_plugin(PluginType::Module, "community.general.ini_file")
            .unwrap();
        assert!(resolved.path.ends_with("ini_file.py"));
        assert!(resolved.is_python);
    }

    #[test]
    fn test_legacy_resolution_builtins() {
        let tmp = tempfile::tempdir().unwrap();
        let root = tmp.path();
        touch(
            &root.join("ansible_collections/ansible/builtin/plugins/modules/ping.py"),
        );

        let mut loader = PluginLoader::new();
        loader.add_collection_root(root);

        let resolved = loader
            .find_plugin(PluginType::Module, "ping")
            .unwrap();
        assert!(resolved.path.ends_with("ping.py"));
    }

    #[test]
    fn test_legacy_resolution_from_collection() {
        let tmp = tempfile::tempdir().unwrap();
        let root = tmp.path();
        touch(
            &root.join(
                "ansible_collections/community/general/plugins/lookup/dict.py",
            ),
        );

        let mut loader = PluginLoader::new();
        loader.add_collection_root(root);

        let resolved = loader
            .find_plugin(PluginType::Lookup, "dict")
            .unwrap();
        assert!(resolved.path.ends_with("dict.py"));
    }

    #[test]
    fn test_caching() {
        let tmp = tempfile::tempdir().unwrap();
        let dir = tmp.path().join("callback");
        touch(&dir.join("default.py"));

        let mut loader = PluginLoader::new();
        loader.add_search_path(PluginType::Callback, tmp.path().to_path_buf());

        let r1 = loader
            .find_plugin(PluginType::Callback, "default")
            .unwrap();
        let r2 = loader
            .find_plugin(PluginType::Callback, "default")
            .unwrap();
        assert_eq!(r1.path, r2.path);

        // Verify cache was populated
        let cache = loader.cache.lock().unwrap_or_else(|p| p.into_inner());
        assert!(cache.contains_key(&(PluginType::Callback, "default".to_string())));
    }

    #[test]
    fn test_not_found() {
        let loader = PluginLoader::new();
        let err = loader
            .find_plugin(PluginType::Module, "nonexistent_xyz")
            .unwrap_err();
        assert!(matches!(err, PluginError::NotFound { .. }));
    }

    #[test]
    fn test_read_source() {
        let tmp = tempfile::tempdir().unwrap();
        let dir = tmp.path().join("modules");
        let path = dir.join("mymod.py");
        std::fs::create_dir_all(&dir).unwrap();
        std::fs::write(&path, "print('hello')\n").unwrap();

        let resolved = ResolvedPlugin::from_path(path);
        assert_eq!(resolved.read_source().unwrap(), "print('hello')\n");
    }

    #[test]
    fn test_explicit_path_priority_over_fqcn() {
        let tmp1 = tempfile::tempdir().unwrap();
        let tmp2 = tempfile::tempdir().unwrap();

        // Explicit path has a .rs file
        let dir = tmp1.path().join("modules");
        touch(&dir.join("mymod.rs"));

        // Collection has a .py file with the same short name
        touch(
            &tmp2.path().join(
                "ansible_collections/ns/col/plugins/modules/mymod.py",
            ),
        );

        let mut loader = PluginLoader::new();
        loader.add_search_path(PluginType::Module, tmp1.path().to_path_buf());
        loader.add_collection_root(tmp2.path());

        // Explicit path should win
        let resolved = loader.find_plugin(PluginType::Module, "mymod").unwrap();
        assert!(resolved.path.ends_with("mymod.rs"));
        assert!(!resolved.is_python);
    }
}
