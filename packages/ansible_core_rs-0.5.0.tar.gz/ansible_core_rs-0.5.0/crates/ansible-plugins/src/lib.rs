pub mod action;
pub mod r#become;
pub mod callback;
pub mod error;
pub mod loader;
pub mod lookup;
pub mod shell;
pub mod traits;

pub use error::PluginError;
pub use traits::*;

/// All plugin types supported by Ansible.
#[derive(Debug, Clone, Copy, Hash, PartialEq, Eq)]
pub enum PluginType {
    Action,
    Become,
    Cache,
    Callback,
    Cliconf,
    Connection,
    Doc,
    Filter,
    HttpApi,
    Inventory,
    Lookup,
    Module,
    ModuleUtils,
    Netconf,
    Shell,
    Strategy,
    Terminal,
    Test,
    Vars,
}

impl PluginType {
    /// The subdirectory name where plugins of this type are found.
    pub fn subdir(&self) -> &'static str {
        match self {
            Self::Action => "action",
            Self::Become => "become",
            Self::Cache => "cache",
            Self::Callback => "callback",
            Self::Cliconf => "cliconf",
            Self::Connection => "connection",
            Self::Doc => "doc_fragments",
            Self::Filter => "filter",
            Self::HttpApi => "httpapi",
            Self::Inventory => "inventory",
            Self::Lookup => "lookup",
            Self::Module => "modules",
            Self::ModuleUtils => "module_utils",
            Self::Netconf => "netconf",
            Self::Shell => "shell",
            Self::Strategy => "strategy",
            Self::Terminal => "terminal",
            Self::Test => "test",
            Self::Vars => "vars",
        }
    }
}
