#[cfg(test)]
mod tests {
    use std::collections::HashMap;
    use std::path::Path;

    use ansible_utils::AnsibleValue;

    use super::super::*;

    /// A minimal mock connection for testing action plugins without
    /// pulling in ansible-connection (which would cause a circular dep).
    struct MockConnection {
        /// Files "put" to the remote host (stored in memory).
        transferred: std::sync::Mutex<Vec<(String, Vec<u8>)>>,
        /// Commands executed.
        commands: std::sync::Mutex<Vec<String>>,
    }

    impl MockConnection {
        fn new() -> Self {
            Self {
                transferred: std::sync::Mutex::new(Vec::new()),
                commands: std::sync::Mutex::new(Vec::new()),
            }
        }
    }

    #[async_trait::async_trait]
    impl crate::ConnectionPlugin for MockConnection {
        async fn connect(&mut self) -> Result<(), crate::PluginError> {
            Ok(())
        }

        async fn exec_command(
            &self,
            cmd: &str,
            _in_data: Option<&[u8]>,
        ) -> Result<(i32, Vec<u8>, Vec<u8>), crate::PluginError> {
            self.commands.lock().unwrap().push(cmd.to_string());
            Ok((0, Vec::new(), Vec::new()))
        }

        async fn put_file(
            &self,
            in_path: &Path,
            out_path: &Path,
        ) -> Result<(), crate::PluginError> {
            let content = std::fs::read(in_path).map_err(|e| {
                crate::PluginError::ExecutionError(format!("mock put_file read: {e}"))
            })?;
            self.transferred.lock().unwrap().push((
                out_path.display().to_string(),
                content,
            ));
            Ok(())
        }

        async fn fetch_file(
            &self,
            _in_path: &Path,
            _out_path: &Path,
        ) -> Result<(), crate::PluginError> {
            Ok(())
        }

        async fn close(&mut self) -> Result<(), crate::PluginError> {
            Ok(())
        }
    }

    #[tokio::test]
    async fn test_copy_action_with_content() {
        let args = serde_json::json!({
            "content": "hello from action plugin",
            "dest": "/tmp/test_output.txt",
        });

        let mut conn = MockConnection::new();
        let vars = HashMap::new();
        let mut ctx = ActionContext {
            host: "testhost",
            variables: &vars,
            connection: &mut conn,
            remote_tmp: None,
            python_interpreter: "python3".into(),
            use_become: false,
            become_user: None,
        };

        let action = copy::CopyAction;
        let result = action.run("copy", &args, &mut ctx).await.unwrap();

        assert!(!result.failed, "copy action failed: {:?}", result.msg);
        assert!(result.changed);

        // Verify the file was transferred
        let transferred = conn.transferred.lock().unwrap();
        assert_eq!(transferred.len(), 1);
        assert_eq!(transferred[0].0, "/tmp/test_output.txt");
        assert_eq!(transferred[0].1, b"hello from action plugin");
    }

    #[tokio::test]
    async fn test_copy_action_with_src() {
        let dir = tempfile::tempdir().unwrap();
        let src = dir.path().join("source.txt");
        std::fs::write(&src, "file content here").unwrap();

        let args = serde_json::json!({
            "src": src.to_str().unwrap(),
            "dest": "/remote/destination.txt",
        });

        let mut conn = MockConnection::new();
        let vars = HashMap::new();
        let mut ctx = ActionContext {
            host: "testhost",
            variables: &vars,
            connection: &mut conn,
            remote_tmp: None,
            python_interpreter: "python3".into(),
            use_become: false,
            become_user: None,
        };

        let action = copy::CopyAction;
        let result = action.run("copy", &args, &mut ctx).await.unwrap();

        assert!(!result.failed);
        assert!(result.changed);

        let transferred = conn.transferred.lock().unwrap();
        assert_eq!(transferred.len(), 1);
        assert_eq!(transferred[0].0, "/remote/destination.txt");
        assert_eq!(transferred[0].1, b"file content here");
    }

    #[tokio::test]
    async fn test_copy_action_missing_dest() {
        let args = serde_json::json!({"content": "hello"});

        let mut conn = MockConnection::new();
        let vars = HashMap::new();
        let mut ctx = ActionContext {
            host: "testhost",
            variables: &vars,
            connection: &mut conn,
            remote_tmp: None,
            python_interpreter: "python3".into(),
            use_become: false,
            become_user: None,
        };

        let action = copy::CopyAction;
        let result = action.run("copy", &args, &mut ctx).await.unwrap();
        assert!(result.failed);
        assert!(result.msg.unwrap().contains("'dest' is required"));
    }

    #[tokio::test]
    async fn test_template_action_renders() {
        let dir = tempfile::tempdir().unwrap();
        let src = dir.path().join("greet.j2");
        std::fs::write(&src, "Hello {{ name }}!").unwrap();

        let mut vars = HashMap::new();
        vars.insert("name".to_string(), AnsibleValue::from("World"));

        let args = serde_json::json!({
            "src": src.to_str().unwrap(),
            "dest": "/remote/greet.txt",
        });

        let mut conn = MockConnection::new();
        let mut ctx = ActionContext {
            host: "testhost",
            variables: &vars,
            connection: &mut conn,
            remote_tmp: None,
            python_interpreter: "python3".into(),
            use_become: false,
            become_user: None,
        };

        let action = template::TemplateAction;
        let result = action.run("template", &args, &mut ctx).await.unwrap();

        assert!(!result.failed, "template action failed: {:?}", result.msg);
        assert!(result.changed);

        let transferred = conn.transferred.lock().unwrap();
        assert_eq!(transferred.len(), 1);
        assert_eq!(transferred[0].0, "/remote/greet.txt");
        let content = String::from_utf8(transferred[0].1.clone()).unwrap();
        assert!(content.contains("Hello World!"), "rendered: {content}");
    }

    #[tokio::test]
    async fn test_copy_action_with_mode() {
        let args = serde_json::json!({
            "content": "secret",
            "dest": "/tmp/secret.txt",
            "mode": "0600",
        });

        let mut conn = MockConnection::new();
        let vars = HashMap::new();
        let mut ctx = ActionContext {
            host: "testhost",
            variables: &vars,
            connection: &mut conn,
            remote_tmp: None,
            python_interpreter: "python3".into(),
            use_become: false,
            become_user: None,
        };

        let action = copy::CopyAction;
        let result = action.run("copy", &args, &mut ctx).await.unwrap();
        assert!(!result.failed);

        // Verify chmod was called
        let commands = conn.commands.lock().unwrap();
        assert!(
            commands.iter().any(|c| c.contains("chmod 0600")),
            "chmod should have been called: {:?}",
            commands
        );
    }

    #[tokio::test]
    async fn test_resolve_action_plugin() {
        assert!(resolve_action_plugin("copy").is_some());
        assert!(resolve_action_plugin("template").is_some());
        assert!(resolve_action_plugin("debug").is_none());
        assert!(resolve_action_plugin("command").is_none());
    }

    #[tokio::test]
    async fn test_normal_action() {
        let args = serde_json::json!({"key": "value"});
        let mut conn = MockConnection::new();
        let vars = HashMap::new();
        let mut ctx = ActionContext {
            host: "testhost",
            variables: &vars,
            connection: &mut conn,
            remote_tmp: None,
            python_interpreter: "python3".into(),
            use_become: false,
            become_user: None,
        };

        let action = normal::NormalAction;
        let result = action.run("some_module", &args, &mut ctx).await.unwrap();
        assert!(!result.failed);
    }
}
