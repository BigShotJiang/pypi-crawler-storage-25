//! The `copy` action plugin — transfers files from controller to target.
//!
//! Unlike the `copy` module (which runs on the target), the copy *action*
//! plugin runs on the controller: it reads the source file locally, then
//! uses `put_file` to transfer it to the target host. This is the key
//! difference between action plugins and modules.

use std::path::PathBuf;

use async_trait::async_trait;

use ansible_utils::{AnsibleValue, TaskResult};

use super::{ActionContext, ActionPlugin};
use crate::PluginError;

/// The copy action plugin: reads src locally, transfers to remote dest.
pub struct CopyAction;

#[async_trait]
impl ActionPlugin for CopyAction {
    async fn run(
        &self,
        _module_name: &str,
        module_args: &AnsibleValue,
        ctx: &mut ActionContext<'_>,
    ) -> Result<TaskResult, PluginError> {
        let mut result = TaskResult::ok(ctx.host);

        let dest = match module_args.get("dest").and_then(|v| v.as_str()) {
            Some(d) => d.to_string(),
            None => {
                result.failed = true;
                result.msg = Some("copy: 'dest' is required".into());
                return Ok(result);
            }
        };

        // Determine the content to copy: either from `content` or `src`.
        let content: Vec<u8> = if let Some(content_str) = module_args.get("content").and_then(|v| v.as_str()) {
            content_str.as_bytes().to_vec()
        } else if let Some(src) = module_args.get("src").and_then(|v| v.as_str()) {
            std::fs::read(src).map_err(|e| {
                PluginError::ExecutionError(format!("copy: read src '{}': {}", src, e))
            })?
        } else {
            result.failed = true;
            result.msg = Some("copy: requires 'content' or 'src'".into());
            return Ok(result);
        };

        // Write content to a local temp file for put_file.
        let mut local_tmp = tempfile::NamedTempFile::new().map_err(|e| {
            PluginError::ExecutionError(format!("copy: tempfile: {e}"))
        })?;
        std::io::Write::write_all(&mut local_tmp, &content).map_err(|e| {
            PluginError::ExecutionError(format!("copy: tempfile write: {e}"))
        })?;
        std::io::Write::flush(&mut local_tmp).map_err(|e| {
            PluginError::ExecutionError(format!("copy: tempfile flush: {e}"))
        })?;

        let local_path = local_tmp.path().to_path_buf();
        let remote_path = PathBuf::from(&dest);

        // Transfer to remote host.
        ctx.connection.put_file(&local_path, &remote_path).await?;

        // Set permissions if specified.
        if let Some(mode) = module_args.get("mode").and_then(|v| v.as_str()) {
            let chmod_cmd = format!("chmod {} {}", mode, dest);
            let _ = ctx.connection.exec_command(&chmod_cmd, None).await;
        }

        // Set ownership if specified.
        if let Some(owner) = module_args.get("owner").and_then(|v| v.as_str()) {
            let group = module_args.get("group").and_then(|v| v.as_str()).unwrap_or("");
            let chown_cmd = if group.is_empty() {
                format!("chown {} {}", owner, dest)
            } else {
                format!("chown {}:{} {}", owner, group, dest)
            };
            let _ = ctx.connection.exec_command(&chown_cmd, None).await;
        }

        result.changed = true;
        result.results = serde_json::json!({
            "dest": dest,
            "src": module_args.get("src").and_then(|v| v.as_str()).unwrap_or("<content>"),
            "size": content.len(),
            "checksum": format!("{:x}", sha2_digest(&content)),
        });

        Ok(result)
    }

    fn name(&self) -> &str {
        "copy"
    }
}

/// Simple SHA-256 digest using the same algorithm as the rest of the crate.
fn sha2_digest(data: &[u8]) -> u64 {
    // Simple hash for the result output — we don't need cryptographic
    // strength here, just a stable identifier. The full sha2 crate is
    // in the executor; here we use a simple FNV-1a for the display hash.
    let mut hash: u64 = 0xcbf29ce484222325;
    for &b in data {
        hash ^= b as u64;
        hash = hash.wrapping_mul(0x100000001b3);
    }
    hash
}
