//! Action plugins wrap module execution with controller-side logic.
//!
//! In upstream Ansible, every module invocation goes through an action
//! plugin. The default (`normal`) action plugin just packages the module
//! as AnsiballZ and runs it on the target. Special action plugins like
//! `copy` and `template` do extra work on the controller side before
//! sending data to the target.
//!
//! This module defines the `ActionPlugin` trait and provides built-in
//! implementations for common action plugins.

pub mod copy;
pub mod normal;
pub mod template;

#[cfg(test)]
#[path = "tests.rs"]
mod tests;

use std::collections::HashMap;

use async_trait::async_trait;

use crate::{ConnectionPlugin, PluginError};
use ansible_utils::{AnsibleValue, TaskResult};

/// Context available to action plugins during execution.
pub struct ActionContext<'a> {
    /// The host being targeted.
    pub host: &'a str,
    /// Resolved variables for this host/task.
    pub variables: &'a HashMap<String, AnsibleValue>,
    /// The connection plugin for the target host.
    pub connection: &'a mut (dyn ConnectionPlugin + Send),
    /// The remote temporary directory path (if created).
    pub remote_tmp: Option<String>,
    /// The Python interpreter path on the remote host.
    pub python_interpreter: String,
    /// Whether become (privilege escalation) is enabled.
    pub use_become: bool,
    /// The become user (e.g. "root").
    pub become_user: Option<String>,
}

/// Action plugins wrap module execution with controller-side logic.
///
/// The lifecycle is:
/// 1. `run()` is called with the module args and action context
/// 2. The action plugin performs any controller-side work (file transfers, etc.)
/// 3. The action plugin either executes the module itself or delegates to
///    the default module execution path
/// 4. Returns the task result
#[async_trait]
pub trait ActionPlugin: Send + Sync {
    /// Execute the action plugin.
    ///
    /// # Arguments
    /// * `module_name` - The module being executed (e.g. "copy", "template")
    /// * `module_args` - The module arguments from the task
    /// * `ctx` - The action context with connection, variables, etc.
    async fn run(
        &self,
        module_name: &str,
        module_args: &AnsibleValue,
        ctx: &mut ActionContext<'_>,
    ) -> Result<TaskResult, PluginError>;

    /// Return the name of this action plugin.
    fn name(&self) -> &str;
}

/// Look up the appropriate action plugin for a module name.
/// Returns None for modules that should use the default (normal) action.
pub fn resolve_action_plugin(module_name: &str) -> Option<Box<dyn ActionPlugin>> {
    match module_name {
        "copy" => Some(Box::new(copy::CopyAction)),
        "template" => Some(Box::new(template::TemplateAction)),
        _ => None,
    }
}
