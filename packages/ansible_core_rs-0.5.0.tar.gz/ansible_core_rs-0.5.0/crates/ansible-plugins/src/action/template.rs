//! The `template` action plugin — renders Jinja2 templates on the
//! controller, then transfers the result to the target.
//!
//! The key distinction from the `copy` action is that the source file
//! is a Jinja2 template that gets rendered with the task/host variables
//! before being transferred. The rendered output goes to the remote dest.

use std::path::PathBuf;

use async_trait::async_trait;

use ansible_utils::{AnsibleValue, TaskResult};

use super::{ActionContext, ActionPlugin};
use crate::PluginError;

/// The template action plugin: renders src template, transfers to remote dest.
pub struct TemplateAction;

#[async_trait]
impl ActionPlugin for TemplateAction {
    async fn run(
        &self,
        _module_name: &str,
        module_args: &AnsibleValue,
        ctx: &mut ActionContext<'_>,
    ) -> Result<TaskResult, PluginError> {
        let mut result = TaskResult::ok(ctx.host);

        let src = match module_args.get("src").and_then(|v| v.as_str()) {
            Some(s) => s.to_string(),
            None => {
                result.failed = true;
                result.msg = Some("template: 'src' is required".into());
                return Ok(result);
            }
        };
        let dest = match module_args.get("dest").and_then(|v| v.as_str()) {
            Some(d) => d.to_string(),
            None => {
                result.failed = true;
                result.msg = Some("template: 'dest' is required".into());
                return Ok(result);
            }
        };

        // Read the template source on the controller.
        let template_source = std::fs::read_to_string(&src).map_err(|e| {
            PluginError::ExecutionError(format!("template: read src '{}': {}", src, e))
        })?;

        // Render the template with the host variables.
        // We use MiniJinja directly here for the rendering.
        let rendered = {
            let mut env = minijinja::Environment::new();
            env.add_template("_src", &template_source).map_err(|e| {
                PluginError::ExecutionError(format!("template: parse error: {e}"))
            })?;
            let tmpl = env.get_template("_src").map_err(|e| {
                PluginError::ExecutionError(format!("template: get error: {e}"))
            })?;
            tmpl.render(ctx.variables).map_err(|e| {
                PluginError::ExecutionError(format!("template: render error: {e}"))
            })?
        };

        // Optionally append a newline (ansible's default behavior).
        let output = if module_args
            .get("newline_sequence")
            .and_then(|v| v.as_str())
            .unwrap_or("\\n")
            == "\\n"
        {
            if rendered.ends_with('\n') {
                rendered
            } else {
                format!("{}\n", rendered)
            }
        } else {
            rendered
        };

        // Write rendered content to a local temp file for put_file.
        let mut local_tmp = tempfile::NamedTempFile::new().map_err(|e| {
            PluginError::ExecutionError(format!("template: tempfile: {e}"))
        })?;
        std::io::Write::write_all(&mut local_tmp, output.as_bytes()).map_err(|e| {
            PluginError::ExecutionError(format!("template: tempfile write: {e}"))
        })?;
        std::io::Write::flush(&mut local_tmp).map_err(|e| {
            PluginError::ExecutionError(format!("template: tempfile flush: {e}"))
        })?;

        let local_path = local_tmp.path().to_path_buf();
        let remote_path = PathBuf::from(&dest);

        // Transfer to remote host.
        ctx.connection.put_file(&local_path, &remote_path).await?;

        // Set permissions if specified.
        if let Some(mode) = module_args.get("mode").and_then(|v| v.as_str()) {
            let chmod_cmd = format!("chmod {} {}", mode, dest);
            let _ = ctx.connection.exec_command(&chmod_cmd, None).await;
        }

        // Set ownership if specified.
        if let Some(owner) = module_args.get("owner").and_then(|v| v.as_str()) {
            let group = module_args.get("group").and_then(|v| v.as_str()).unwrap_or("");
            let chown_cmd = if group.is_empty() {
                format!("chown {} {}", owner, dest)
            } else {
                format!("chown {}:{} {}", owner, group, dest)
            };
            let _ = ctx.connection.exec_command(&chown_cmd, None).await;
        }

        result.changed = true;
        result.results = serde_json::json!({
            "src": src,
            "dest": dest,
            "size": output.len(),
        });

        Ok(result)
    }

    fn name(&self) -> &str {
        "template"
    }
}
