//! The `normal` action plugin — default for most modules.
//!
//! This is a thin wrapper that packages the module via AnsiballZ and
//! executes it on the target host. Most modules go through this path.

use async_trait::async_trait;

use ansible_utils::{AnsibleValue, TaskResult};

use super::{ActionContext, ActionPlugin};
use crate::PluginError;

/// The default action plugin that just runs the module on the target.
pub struct NormalAction;

#[async_trait]
impl ActionPlugin for NormalAction {
    async fn run(
        &self,
        module_name: &str,
        _module_args: &AnsibleValue,
        _ctx: &mut ActionContext<'_>,
    ) -> Result<TaskResult, PluginError> {
        // The normal action plugin delegates to the executor's module
        // execution path. This is a marker — the actual AnsiballZ packaging
        // and execution happens in the executor layer.
        let mut result = TaskResult::ok(_ctx.host);
        result.msg = Some(format!(
            "normal action for '{}' — delegate to executor",
            module_name
        ));
        Ok(result)
    }

    fn name(&self) -> &str {
        "normal"
    }
}
