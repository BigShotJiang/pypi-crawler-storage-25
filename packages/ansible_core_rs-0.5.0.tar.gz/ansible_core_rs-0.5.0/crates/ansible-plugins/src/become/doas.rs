use crate::{BecomePlugin, PluginError};

/// The `doas` become plugin (OpenBSD's privilege escalation tool).
pub struct DoasBecome {
    pub become_user: String,
    pub become_pass: Option<String>,
    pub become_flags: String,
}

impl Default for DoasBecome {
    fn default() -> Self {
        Self {
            become_user: "root".to_string(),
            become_pass: None,
            become_flags: String::new(),
        }
    }
}

impl BecomePlugin for DoasBecome {
    fn build_become_command(&self, cmd: &str, shell: &str) -> Result<String, PluginError> {
        // doas [-flags] -u <user> <shell> -c '<cmd>'
        let mut parts = vec!["doas".to_string()];

        if !self.become_flags.is_empty() {
            for flag in self.become_flags.split_whitespace() {
                parts.push(flag.to_string());
            }
        }

        parts.push("-u".to_string());
        parts.push(self.become_user.clone());

        parts.push(shell.to_string());
        parts.push("-c".to_string());

        let escaped = cmd.replace('\\', "\\\\").replace('\'', "'\\''");
        parts.push(format!("'{}'", escaped));

        Ok(parts.join(" "))
    }

    fn check_success(&self, output: &str) -> bool {
        !output.contains("doas: Authentication failed")
    }

    fn check_password_prompt(&self, output: &str) -> bool {
        let lower = output.to_lowercase();
        lower.contains("doas") && lower.contains("password")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_doas_command() {
        let doas = DoasBecome::default();
        let cmd = doas.build_become_command("whoami", "/bin/sh").unwrap();
        assert!(cmd.starts_with("doas"));
        assert!(cmd.contains("-u root"));
        assert!(cmd.contains("/bin/sh -c"));
    }
}
