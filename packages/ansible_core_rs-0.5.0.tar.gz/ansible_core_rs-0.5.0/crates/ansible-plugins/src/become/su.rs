use crate::{BecomePlugin, PluginError};

/// The `su` become plugin.
pub struct SuBecome {
    pub become_user: String,
    pub become_pass: Option<String>,
    pub become_flags: String,
}

impl Default for SuBecome {
    fn default() -> Self {
        Self {
            become_user: "root".to_string(),
            become_pass: None,
            become_flags: String::new(),
        }
    }
}

impl SuBecome {
    pub fn new(user: &str, pass: Option<&str>, flags: Option<&str>) -> Self {
        Self {
            become_user: user.to_string(),
            become_pass: pass.map(|s| s.to_string()),
            become_flags: flags.unwrap_or("").to_string(),
        }
    }
}

impl BecomePlugin for SuBecome {
    fn build_become_command(&self, cmd: &str, _shell: &str) -> Result<String, PluginError> {
        // su [-flags] <user> -c '<cmd>'
        let mut parts = vec!["su".to_string()];

        if !self.become_flags.is_empty() {
            for flag in self.become_flags.split_whitespace() {
                parts.push(flag.to_string());
            }
        }

        parts.push(self.become_user.clone());
        parts.push("-c".to_string());

        let escaped = cmd.replace('\\', "\\\\").replace('\'', "'\\''");
        parts.push(format!("'{}'", escaped));

        Ok(parts.join(" "))
    }

    fn check_success(&self, output: &str) -> bool {
        !output.contains("su: Authentication failure")
            && !output.contains("su: Permission denied")
    }

    fn check_password_prompt(&self, output: &str) -> bool {
        let lower = output.to_lowercase();
        lower.contains("password:")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_su_default_command() {
        let su = SuBecome::default();
        let cmd = su.build_become_command("whoami", "/bin/sh").unwrap();
        assert!(cmd.starts_with("su"));
        assert!(cmd.contains("root"));
        assert!(cmd.contains("-c"));
    }

    #[test]
    fn test_su_password_prompt() {
        let su = SuBecome::default();
        assert!(su.check_password_prompt("Password:"));
        assert!(!su.check_password_prompt("output"));
    }
}
