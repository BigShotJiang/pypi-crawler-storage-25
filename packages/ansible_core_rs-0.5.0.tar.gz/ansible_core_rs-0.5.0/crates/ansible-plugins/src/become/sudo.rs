use crate::{BecomePlugin, PluginError};

/// The `sudo` become plugin — most common privilege escalation method.
pub struct SudoBecome {
    pub become_user: String,
    pub become_pass: Option<String>,
    pub become_flags: String,
}

impl Default for SudoBecome {
    fn default() -> Self {
        Self {
            become_user: "root".to_string(),
            become_pass: None,
            become_flags: "-H -S -n".to_string(),
        }
    }
}

impl SudoBecome {
    pub fn new(user: &str, pass: Option<&str>, flags: Option<&str>) -> Self {
        Self {
            become_user: user.to_string(),
            become_pass: pass.map(|s| s.to_string()),
            become_flags: flags.unwrap_or("-H -S -n").to_string(),
        }
    }
}

impl BecomePlugin for SudoBecome {
    fn build_become_command(&self, cmd: &str, shell: &str) -> Result<String, PluginError> {
        // sudo [-flags] -u <user> <shell> -c '<cmd>'
        let mut parts = vec!["sudo".to_string()];

        for flag in self.become_flags.split_whitespace() {
            parts.push(flag.to_string());
        }

        parts.push("-u".to_string());
        parts.push(self.become_user.clone());

        parts.push(shell.to_string());
        parts.push("-c".to_string());

        // Shell-escape the command
        let escaped = cmd.replace('\\', "\\\\").replace('\'', "'\\''");
        parts.push(format!("'{}'", escaped));

        Ok(parts.join(" "))
    }

    fn check_success(&self, output: &str) -> bool {
        // sudo doesn't produce specific success markers
        // Absence of error patterns is considered success
        !output.contains("sudo: ")
            || output.contains("sudo: unable to resolve host") // not a failure
    }

    fn check_password_prompt(&self, output: &str) -> bool {
        let lower = output.to_lowercase();
        lower.contains("[sudo] password")
            || lower.contains("password for")
            || lower.contains("password:")
            || lower.contains("sudo: a password is required")
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_sudo_default_command() {
        let sudo = SudoBecome::default();
        let cmd = sudo
            .build_become_command("whoami", "/bin/sh")
            .unwrap();
        assert!(cmd.starts_with("sudo"));
        assert!(cmd.contains("-u root"));
        assert!(cmd.contains("/bin/sh -c"));
        assert!(cmd.contains("whoami"));
    }

    #[test]
    fn test_sudo_custom_user() {
        let sudo = SudoBecome::new("deploy", None, None);
        let cmd = sudo
            .build_become_command("ls /root", "/bin/bash")
            .unwrap();
        assert!(cmd.contains("-u deploy"));
    }

    #[test]
    fn test_sudo_password_prompt_detection() {
        let sudo = SudoBecome::default();
        assert!(sudo.check_password_prompt("[sudo] password for user:"));
        assert!(sudo.check_password_prompt("Password:"));
        assert!(!sudo.check_password_prompt("command output"));
    }

    #[test]
    fn test_sudo_escapes_quotes() {
        let sudo = SudoBecome::default();
        let cmd = sudo
            .build_become_command("echo 'hello world'", "/bin/sh")
            .unwrap();
        assert!(cmd.contains("'echo '\\''hello world'\\'''"));
    }
}
