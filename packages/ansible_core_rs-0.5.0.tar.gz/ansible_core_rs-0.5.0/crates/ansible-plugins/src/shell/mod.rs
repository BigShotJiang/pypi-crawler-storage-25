pub mod sh;
pub mod powershell;

pub use sh::ShPlugin;
pub use powershell::PowershellPlugin;
