use crate::ShellPlugin;

/// The PowerShell shell plugin — used for Windows targets.
pub struct PowershellPlugin {
    pub executable: String,
}

impl Default for PowershellPlugin {
    fn default() -> Self {
        Self {
            executable: "powershell".to_string(),
        }
    }
}

impl PowershellPlugin {
    /// Escape a string for PowerShell.
    pub fn quote(value: &str) -> String {
        if value.is_empty() {
            return "\"\"".to_string();
        }
        // Double-quote and escape internal double-quotes and backticks
        let escaped = value
            .replace('`', "``")
            .replace('"', "`\"")
            .replace('$', "`$");
        format!("\"{}\"", escaped)
    }
}

impl ShellPlugin for PowershellPlugin {
    fn join_path(&self, parts: &[&str]) -> String {
        parts.join("\\")
    }

    fn get_remote_filename(&self, pathname: &str) -> String {
        pathname
            .rsplit(['/', '\\'])
            .next()
            .unwrap_or(pathname)
            .to_string()
    }

    fn mkdtemp(&self, _basefile: &str) -> String {
        "$tmp = [System.IO.Path]::Combine([System.IO.Path]::GetTempPath(), \
             [System.IO.Path]::GetRandomFileName()); \
             New-Item -ItemType Directory -Path $tmp | Out-Null; \
             Write-Output $tmp".to_string()
    }

    fn remove(&self, path: &str, recurse: bool) -> String {
        if recurse {
            format!(
                "Remove-Item {} -Force -Recurse",
                Self::quote(path)
            )
        } else {
            format!("Remove-Item {} -Force", Self::quote(path))
        }
    }

    fn exists(&self, path: &str) -> String {
        format!("Test-Path {}", Self::quote(path))
    }

    fn expand_user(&self, user_home_path: &str) -> String {
        if let Some(rest) = user_home_path.strip_prefix('~') {
            format!(
                "$env:USERPROFILE + '{}'",
                rest
            )
        } else {
            user_home_path.to_string()
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_join_path_windows() {
        let ps = PowershellPlugin::default();
        assert_eq!(ps.join_path(&["C:", "Users", "admin"]), "C:\\Users\\admin");
    }

    #[test]
    fn test_get_remote_filename_windows() {
        let ps = PowershellPlugin::default();
        assert_eq!(
            ps.get_remote_filename("C:\\temp\\module.ps1"),
            "module.ps1"
        );
    }

    #[test]
    fn test_remove_windows() {
        let ps = PowershellPlugin::default();
        assert!(ps.remove("C:\\temp\\foo", true).contains("Remove-Item"));
        assert!(ps.remove("C:\\temp\\foo", true).contains("-Recurse"));
    }

    #[test]
    fn test_quote_powershell() {
        assert_eq!(PowershellPlugin::quote("hello"), "\"hello\"");
        assert_eq!(PowershellPlugin::quote("say \"hi\""), "\"say `\"hi`\"\"");
        assert_eq!(PowershellPlugin::quote("$var"), "\"`$var\"");
    }
}
