use crate::ShellPlugin;

/// The POSIX `sh` shell plugin — default for Unix/Linux targets.
/// Handles command construction for /bin/sh compatible shells.
pub struct ShPlugin {
    /// The shell executable path
    pub executable: String,
    /// The shell family (sh, bash, zsh, etc.)
    pub family: String,
}

impl Default for ShPlugin {
    fn default() -> Self {
        Self {
            executable: "/bin/sh".to_string(),
            family: "sh".to_string(),
        }
    }
}

impl ShPlugin {
    pub fn new(executable: &str) -> Self {
        Self {
            executable: executable.to_string(),
            family: "sh".to_string(),
        }
    }

    /// Shell-quote a string for safe interpolation.
    pub fn quote(value: &str) -> String {
        if value.is_empty() {
            return "''".to_string();
        }
        // If already safe, no quoting needed
        if value.chars().all(|c| c.is_alphanumeric() || c == '_' || c == '/' || c == '.' || c == '-') {
            return value.to_string();
        }
        format!("'{}'", value.replace('\'', "'\\''"))
    }

    /// Build the command string to execute a module on a remote host.
    pub fn build_module_command(
        &self,
        env_string: &str,
        shebang: &str,
        cmd: &str,
        arg_path: &str,
    ) -> String {
        let mut parts = Vec::new();

        if !env_string.is_empty() {
            parts.push(env_string.to_string());
        }

        if !shebang.is_empty() {
            parts.push(shebang.to_string());
        }

        parts.push(cmd.to_string());

        if !arg_path.is_empty() {
            parts.push(arg_path.to_string());
        }

        parts.join(" ")
    }

    /// Wrap a command for execution via the shell.
    pub fn wrap_for_exec(&self, cmd: &str) -> String {
        format!("{} -c {}", self.executable, Self::quote(cmd))
    }

    /// Build the environment string for command execution.
    pub fn build_env_string(env: &std::collections::HashMap<String, String>) -> String {
        if env.is_empty() {
            return String::new();
        }
        env.iter()
            .map(|(k, v)| format!("{}={}", k, Self::quote(v)))
            .collect::<Vec<_>>()
            .join(" ")
    }

    /// Get the command to checksum a file.
    pub fn checksum(&self, path: &str, python_interp: &str) -> String {
        // Try multiple checksum programs in order of preference
        format!(
            "({python} -c 'import hashlib; print(hashlib.sha1(open(\"{path}\",\"rb\").read()).hexdigest())' 2>/dev/null) || \
             (sha1sum {path} 2>/dev/null | cut -d' ' -f1) || \
             (shasum {path} 2>/dev/null | cut -d' ' -f1)",
            python = python_interp,
            path = path,
        )
    }
}

impl ShellPlugin for ShPlugin {
    fn join_path(&self, parts: &[&str]) -> String {
        parts.join("/")
    }

    fn get_remote_filename(&self, pathname: &str) -> String {
        pathname
            .rsplit('/')
            .next()
            .unwrap_or(pathname)
            .to_string()
    }

    fn mkdtemp(&self, basefile: &str) -> String {
        format!(
            "d=$(mktemp -d {basefile}.XXXXXX 2>/dev/null || mktemp -d -t {basefile}.XXXXXX) && echo \"$d\"",
            basefile = basefile,
        )
    }

    fn remove(&self, path: &str, recurse: bool) -> String {
        if recurse {
            format!("rm -rf {}", Self::quote(path))
        } else {
            format!("rm -f {}", Self::quote(path))
        }
    }

    fn exists(&self, path: &str) -> String {
        format!("test -e {}", Self::quote(path))
    }

    fn expand_user(&self, user_home_path: &str) -> String {
        if user_home_path.starts_with('~') {
            format!(
                "echo {}",
                user_home_path
            )
        } else {
            user_home_path.to_string()
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_join_path() {
        let sh = ShPlugin::default();
        assert_eq!(sh.join_path(&["home", "user", ".ansible"]), "home/user/.ansible");
    }

    #[test]
    fn test_get_remote_filename() {
        let sh = ShPlugin::default();
        assert_eq!(sh.get_remote_filename("/tmp/ansible_abc123/module.py"), "module.py");
    }

    #[test]
    fn test_mkdtemp() {
        let sh = ShPlugin::default();
        let cmd = sh.mkdtemp("ansible-tmp");
        assert!(cmd.contains("mktemp -d"));
        assert!(cmd.contains("ansible-tmp.XXXXXX"));
    }

    #[test]
    fn test_remove() {
        let sh = ShPlugin::default();
        assert_eq!(sh.remove("/tmp/foo", false), "rm -f /tmp/foo");
        assert_eq!(sh.remove("/tmp/foo", true), "rm -rf /tmp/foo");
    }

    #[test]
    fn test_exists() {
        let sh = ShPlugin::default();
        assert_eq!(sh.exists("/tmp/foo"), "test -e /tmp/foo");
    }

    #[test]
    fn test_quote_simple() {
        assert_eq!(ShPlugin::quote("hello"), "hello");
        assert_eq!(ShPlugin::quote("hello world"), "'hello world'");
        assert_eq!(ShPlugin::quote(""), "''");
    }

    #[test]
    fn test_quote_with_single_quotes() {
        assert_eq!(ShPlugin::quote("it's"), "'it'\\''s'");
    }

    #[test]
    fn test_wrap_for_exec() {
        let sh = ShPlugin::default();
        let cmd = sh.wrap_for_exec("echo hello");
        assert_eq!(cmd, "/bin/sh -c 'echo hello'");
    }

    #[test]
    fn test_build_env_string() {
        let mut env = std::collections::HashMap::new();
        env.insert("FOO".into(), "bar".into());
        let result = ShPlugin::build_env_string(&env);
        assert_eq!(result, "FOO=bar");
    }
}
