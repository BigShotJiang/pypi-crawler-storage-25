use std::collections::HashMap;
use std::path::PathBuf;

use ansible_utils::AnsibleValue;
use serde::{Deserialize, Serialize};

use crate::types::{Task, TagSpec};

/// The standard subdirectories within a role.
pub const ROLE_SUBDIRS: &[&str] = &[
    "tasks",
    "handlers",
    "defaults",
    "vars",
    "files",
    "templates",
    "meta",
    "library",
    "plugins",
];

/// A fully loaded role definition.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Role {
    /// The role name (may be FQCN: namespace.collection.role).
    pub name: String,
    /// Filesystem path to the role root directory.
    pub path: PathBuf,
    /// Tasks loaded from tasks/main.yml.
    pub tasks: Vec<Task>,
    /// Handlers loaded from handlers/main.yml.
    pub handlers: Vec<Task>,
    /// Default variables (lowest precedence) from defaults/main.yml.
    pub defaults: HashMap<String, AnsibleValue>,
    /// Role variables (higher precedence) from vars/main.yml.
    pub vars: HashMap<String, AnsibleValue>,
    /// Role metadata from meta/main.yml.
    pub metadata: RoleMetadata,
    /// Parameters passed at inclusion time (e.g., `roles: [{role: foo, bar: baz}]`).
    pub params: HashMap<String, AnsibleValue>,
    /// Tags applied to this role inclusion.
    pub tags: TagSpec,
    /// When conditions applied to this role inclusion.
    pub when_conditions: Vec<String>,
}

/// Role metadata from meta/main.yml.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct RoleMetadata {
    /// Role dependencies that must be executed first.
    #[serde(default)]
    pub dependencies: Vec<RoleDependency>,
    /// Galaxy metadata.
    pub galaxy_info: Option<GalaxyInfo>,
    /// Whether to allow this role to be executed multiple times.
    #[serde(default)]
    pub allow_duplicates: bool,
    /// Argument specification for role validation.
    pub argument_specs: Option<HashMap<String, AnsibleValue>>,
}

/// A role dependency declaration.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(untagged)]
pub enum RoleDependency {
    /// Simple string: just a role name.
    Simple(String),
    /// Full specification with role name and parameters.
    Full {
        role: String,
        #[serde(default)]
        vars: HashMap<String, AnsibleValue>,
        #[serde(default)]
        tags: TagSpec,
        #[serde(default, rename = "when")]
        when_conditions: Vec<String>,
    },
}

impl RoleDependency {
    /// Get the role name from this dependency.
    pub fn role_name(&self) -> &str {
        match self {
            Self::Simple(name) => name,
            Self::Full { role, .. } => role,
        }
    }
}

/// Galaxy metadata for a role.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct GalaxyInfo {
    pub author: Option<String>,
    pub description: Option<String>,
    pub company: Option<String>,
    pub license: Option<String>,
    pub min_ansible_version: Option<String>,
    pub platforms: Option<Vec<HashMap<String, AnsibleValue>>>,
    pub galaxy_tags: Option<Vec<String>>,
    pub namespace: Option<String>,
    pub role_name: Option<String>,
}

impl Role {
    /// Get the path to a specific subdirectory (tasks/, handlers/, etc.).
    pub fn subdir_path(&self, subdir: &str) -> PathBuf {
        self.path.join(subdir)
    }

    /// Check if a subdirectory exists.
    pub fn has_subdir(&self, subdir: &str) -> bool {
        self.subdir_path(subdir).is_dir()
    }

    /// Get the files/ directory path for this role.
    pub fn files_path(&self) -> PathBuf {
        self.path.join("files")
    }

    /// Get the templates/ directory path for this role.
    pub fn templates_path(&self) -> PathBuf {
        self.path.join("templates")
    }
}
