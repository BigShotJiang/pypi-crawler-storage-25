use std::collections::HashMap;
use std::path::{Path, PathBuf};

use ansible_utils::AnsibleValue;

use crate::error::PlaybookError;
use crate::role::definition::{Role, RoleDependency, RoleMetadata, ROLE_SUBDIRS};
use crate::types::{TagSpec, Task};

/// Discovers and loads roles from configured search paths.
pub struct RoleLoader {
    /// Ordered list of paths to search for roles.
    search_paths: Vec<PathBuf>,
    /// Cache of already-loaded roles by path.
    loaded_roles: HashMap<PathBuf, Role>,
}

impl RoleLoader {
    pub fn new(search_paths: Vec<PathBuf>) -> Self {
        Self {
            search_paths,
            loaded_roles: HashMap::new(),
        }
    }

    /// Add a search path (prepended to have highest priority).
    pub fn add_search_path(&mut self, path: PathBuf) {
        if !self.search_paths.contains(&path) {
            self.search_paths.insert(0, path);
        }
    }

    /// Resolve a role name to a filesystem path.
    ///
    /// Search order:
    /// 1. Absolute/relative path (if name contains '/')
    /// 2. Each search path in order
    pub fn resolve_role_path(&self, name: &str) -> Result<PathBuf, PlaybookError> {
        // If it's an absolute or relative path
        let as_path = PathBuf::from(name);
        if (as_path.is_absolute() || name.contains('/') || name.contains('\\'))
            && as_path.is_dir() && is_role_dir(&as_path) {
                return Ok(as_path);
            }

        // Search configured paths
        for search_path in &self.search_paths {
            let candidate = search_path.join(name);
            if candidate.is_dir() && is_role_dir(&candidate) {
                return Ok(candidate);
            }
        }

        Err(PlaybookError::RoleNotFound(name.to_string()))
    }

    /// Load a role by name.
    pub fn load_role(
        &mut self,
        name: &str,
        params: HashMap<String, AnsibleValue>,
        tags: TagSpec,
        when_conditions: Vec<String>,
    ) -> Result<Role, PlaybookError> {
        let path = self.resolve_role_path(name)?;

        // Check cache
        if let Some(cached) = self.loaded_roles.get(&path) {
            let mut role = cached.clone();
            role.params = params;
            role.tags = tags;
            role.when_conditions = when_conditions;
            return Ok(role);
        }

        // Load from disk
        let role = self.load_role_from_path(name, &path, params, tags, when_conditions)?;

        // Cache
        self.loaded_roles.insert(path, role.clone());

        Ok(role)
    }

    fn load_role_from_path(
        &self,
        name: &str,
        path: &Path,
        params: HashMap<String, AnsibleValue>,
        tags: TagSpec,
        when_conditions: Vec<String>,
    ) -> Result<Role, PlaybookError> {
        // Load tasks/main.yml
        let tasks = self.load_role_yaml_list(path, "tasks")?;

        // Load handlers/main.yml
        let handlers = self.load_role_yaml_list(path, "handlers")?;

        // Load defaults/main.yml
        let defaults = self.load_role_yaml_dict(path, "defaults")?;

        // Load vars/main.yml
        let vars = self.load_role_yaml_dict(path, "vars")?;

        // Load meta/main.yml
        let metadata = self.load_metadata(path)?;

        Ok(Role {
            name: name.to_string(),
            path: path.to_path_buf(),
            tasks,
            handlers,
            defaults,
            vars,
            metadata,
            params,
            tags,
            when_conditions,
        })
    }

    /// Load a role YAML file that should contain a list (tasks, handlers).
    fn load_role_yaml_list(&self, role_path: &Path, subdir: &str) -> Result<Vec<Task>, PlaybookError> {
        let main_file = find_main_file(role_path, subdir);

        let Some(file_path) = main_file else {
            return Ok(Vec::new());
        };

        let content = ansible_parsing::read_file_efficient(&file_path)
            .map_err(|e| PlaybookError::ParseError(format!("{}: {e}", file_path.display())))?;

        let value: AnsibleValue = serde_yaml::from_str(&content)
            .map_err(|e| PlaybookError::ParseError(format!("{}: {e}", file_path.display())))?;

        match value {
            AnsibleValue::Array(arr) => {
                let tasks: Vec<Task> = serde_json::from_value(AnsibleValue::Array(arr))
                    .map_err(|e| PlaybookError::ParseError(format!("{}: {e}", file_path.display())))?;
                Ok(tasks)
            }
            AnsibleValue::Null => Ok(Vec::new()),
            _ => Err(PlaybookError::ParseError(format!(
                "{}: expected a list, got {:?}",
                file_path.display(),
                value
            ))),
        }
    }

    /// Load a role YAML file that should contain a dict (defaults, vars).
    fn load_role_yaml_dict(
        &self,
        role_path: &Path,
        subdir: &str,
    ) -> Result<HashMap<String, AnsibleValue>, PlaybookError> {
        let main_file = find_main_file(role_path, subdir);

        let Some(file_path) = main_file else {
            return Ok(HashMap::new());
        };

        let content = ansible_parsing::read_file_efficient(&file_path)
            .map_err(|e| PlaybookError::ParseError(format!("{}: {e}", file_path.display())))?;

        let value: AnsibleValue = serde_yaml::from_str(&content)
            .map_err(|e| PlaybookError::ParseError(format!("{}: {e}", file_path.display())))?;

        match value {
            AnsibleValue::Object(map) => {
                Ok(map.into_iter().collect())
            }
            AnsibleValue::Null => Ok(HashMap::new()),
            _ => Err(PlaybookError::ParseError(format!(
                "{}: expected a dict, got {:?}",
                file_path.display(),
                value
            ))),
        }
    }

    /// Load role metadata from meta/main.yml.
    fn load_metadata(&self, role_path: &Path) -> Result<RoleMetadata, PlaybookError> {
        let main_file = find_main_file(role_path, "meta");

        let Some(file_path) = main_file else {
            return Ok(RoleMetadata::default());
        };

        let content = ansible_parsing::read_file_efficient(&file_path)
            .map_err(|e| PlaybookError::ParseError(format!("{}: {e}", file_path.display())))?;

        let value: AnsibleValue = serde_yaml::from_str(&content)
            .map_err(|e| PlaybookError::ParseError(format!("{}: {e}", file_path.display())))?;

        match value {
            AnsibleValue::Object(map) => {
                let metadata: RoleMetadata =
                    serde_json::from_value(AnsibleValue::Object(map)).unwrap_or_default();
                Ok(metadata)
            }
            AnsibleValue::Null => Ok(RoleMetadata::default()),
            _ => Ok(RoleMetadata::default()),
        }
    }

    /// Resolve role dependencies recursively.
    /// Returns roles in execution order (dependencies first).
    pub fn resolve_dependencies(
        &mut self,
        role: &Role,
    ) -> Result<Vec<Role>, PlaybookError> {
        let mut result = Vec::new();
        let mut seen = std::collections::HashSet::new();

        self.resolve_deps_recursive(role, &mut result, &mut seen)?;

        Ok(result)
    }

    fn resolve_deps_recursive(
        &mut self,
        role: &Role,
        result: &mut Vec<Role>,
        seen: &mut std::collections::HashSet<String>,
    ) -> Result<(), PlaybookError> {
        if seen.contains(&role.name) && !role.metadata.allow_duplicates {
            return Ok(());
        }
        seen.insert(role.name.clone());

        // Load and recurse into dependencies first
        for dep in &role.metadata.dependencies.clone() {
            let dep_name = dep.role_name().to_string();
            let (dep_params, dep_tags, dep_when) = match dep {
                RoleDependency::Simple(_) => (HashMap::new(), TagSpec::default(), Vec::new()),
                RoleDependency::Full { vars, tags, when_conditions, .. } => {
                    (vars.clone(), tags.clone(), when_conditions.clone())
                }
            };

            let dep_role = self.load_role(&dep_name, dep_params, dep_tags, dep_when)?;
            self.resolve_deps_recursive(&dep_role, result, seen)?;
        }

        result.push(role.clone());
        Ok(())
    }
}

/// Check if a directory looks like a role (has at least one standard subdir).
fn is_role_dir(path: &Path) -> bool {
    ROLE_SUBDIRS
        .iter()
        .any(|subdir| path.join(subdir).is_dir())
}

/// Find the main.yml (or main.yaml, main.json) file in a role subdirectory.
fn find_main_file(role_path: &Path, subdir: &str) -> Option<PathBuf> {
    let dir = role_path.join(subdir);
    if !dir.is_dir() {
        return None;
    }

    for ext in &["yml", "yaml", "json"] {
        let candidate = dir.join(format!("main.{ext}"));
        if candidate.is_file() {
            return Some(candidate);
        }
    }

    None
}
