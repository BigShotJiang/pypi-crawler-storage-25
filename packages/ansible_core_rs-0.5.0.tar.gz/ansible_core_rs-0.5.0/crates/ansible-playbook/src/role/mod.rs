pub mod definition;
pub mod loader;

pub use definition::{Role, RoleDependency, RoleMetadata};
pub use loader::RoleLoader;
