use thiserror::Error;

#[derive(Debug, Error)]
pub enum PlaybookError {
    #[error("playbook parse error: {0}")]
    ParseError(String),

    #[error("invalid play definition: {0}")]
    InvalidPlay(String),

    #[error("role not found: {0}")]
    RoleNotFound(String),

    #[error(transparent)]
    Io(#[from] std::io::Error),

    #[error(transparent)]
    Parsing(#[from] ansible_parsing::ParsingError),
}
