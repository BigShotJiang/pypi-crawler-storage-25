use std::collections::HashMap;

use ansible_utils::AnsibleValue;

/// Describes how an attribute should be merged when inheriting.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum MergeStrategy {
    /// Replace: child value completely replaces parent.
    Replace,
    /// Extend: child list is appended to parent list.
    Extend,
    /// Prepend: child list is prepended to parent list.
    Prepend,
    /// ExtendPrepend: child list is prepended to parent list (module_defaults, environment).
    ExtendPrepend,
}

/// Whether an attribute can be inherited from a parent object.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum Inheritability {
    /// Can be inherited from parent (play → block → task).
    Inheritable,
    /// Cannot be inherited — local to the object.
    NonInheritable,
}

/// Metadata for a playbook attribute (field).
#[derive(Debug, Clone)]
pub struct AttributeDefinition {
    pub name: &'static str,
    pub isa: &'static str,
    pub default: Option<AnsibleValue>,
    pub inheritability: Inheritability,
    pub merge_strategy: MergeStrategy,
    pub priority: u8,
    pub alias: Option<&'static str>,
}

/// Defines the inheritable playbook attributes and their merge behaviors.
///
/// In Python Ansible, these are `FieldAttribute` descriptors defined in
/// `playbook/base.py`, `playbook/play.py`, `playbook/block.py`, etc.
/// with metaclass-driven inheritance through the MRO.
///
/// In Rust, we represent this as a flat list of attribute definitions.
pub const INHERITABLE_ATTRIBUTES: &[AttributeDefinition] = &[
    AttributeDefinition {
        name: "become",
        isa: "bool",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::Replace,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "become_user",
        isa: "string",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::Replace,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "become_method",
        isa: "string",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::Replace,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "become_flags",
        isa: "string",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::Replace,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "connection",
        isa: "string",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::Replace,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "port",
        isa: "int",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::Replace,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "remote_user",
        isa: "string",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::Replace,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "environment",
        isa: "list",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::ExtendPrepend,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "module_defaults",
        isa: "list",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::ExtendPrepend,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "no_log",
        isa: "bool",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::Replace,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "ignore_errors",
        isa: "bool",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::Replace,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "ignore_unreachable",
        isa: "bool",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::Replace,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "check_mode",
        isa: "bool",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::Replace,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "diff",
        isa: "bool",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::Replace,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "any_errors_fatal",
        isa: "bool",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::Replace,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "collections",
        isa: "list",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::Replace,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "tags",
        isa: "list",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::Extend,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "when",
        isa: "list",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::Extend,
        priority: 0,
        alias: None,
    },
    AttributeDefinition {
        name: "timeout",
        isa: "int",
        default: None,
        inheritability: Inheritability::Inheritable,
        merge_strategy: MergeStrategy::Replace,
        priority: 0,
        alias: None,
    },
];

/// Resolve an attribute value from a child object, falling back to parent.
///
/// This implements the play → block → task inheritance chain.
/// For `Replace` strategy, child wins if set; otherwise parent value used.
/// For `Extend`, child list is appended to parent list.
/// For `Prepend`/`ExtendPrepend`, child list is prepended.
pub fn resolve_attribute(
    attr_def: &AttributeDefinition,
    child_value: Option<&AnsibleValue>,
    parent_value: Option<&AnsibleValue>,
) -> Option<AnsibleValue> {
    match (child_value, parent_value) {
        (Some(child), Some(parent)) => {
            match attr_def.merge_strategy {
                MergeStrategy::Replace => Some(child.clone()),
                MergeStrategy::Extend => {
                    // Parent list + child list
                    Some(merge_lists(parent, child))
                }
                MergeStrategy::Prepend | MergeStrategy::ExtendPrepend => {
                    // Child list + parent list
                    Some(merge_lists(child, parent))
                }
            }
        }
        (Some(child), None) => Some(child.clone()),
        (None, Some(parent)) => {
            if attr_def.inheritability == Inheritability::Inheritable {
                Some(parent.clone())
            } else {
                None
            }
        }
        (None, None) => attr_def.default.clone(),
    }
}

/// Merge two list-like values.
fn merge_lists(first: &AnsibleValue, second: &AnsibleValue) -> AnsibleValue {
    let mut result = Vec::new();

    if let Some(arr) = first.as_array() {
        result.extend(arr.iter().cloned());
    } else {
        result.push(first.clone());
    }

    if let Some(arr) = second.as_array() {
        result.extend(arr.iter().cloned());
    } else {
        result.push(second.clone());
    }

    AnsibleValue::Array(result)
}

/// Squash (flatten) inheritable attributes from a parent into a child object.
///
/// This pre-computes all inherited values so they don't need to be
/// looked up dynamically at execution time.
pub fn squash_attributes(
    child_attrs: &HashMap<String, AnsibleValue>,
    parent_attrs: &HashMap<String, AnsibleValue>,
) -> HashMap<String, AnsibleValue> {
    let mut result = child_attrs.clone();

    for attr_def in INHERITABLE_ATTRIBUTES {
        let child_val = child_attrs.get(attr_def.name);
        let parent_val = parent_attrs.get(attr_def.name);

        if let Some(resolved) = resolve_attribute(attr_def, child_val, parent_val) {
            result.insert(attr_def.name.to_string(), resolved);
        }
    }

    result
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_replace_child_wins() {
        let attr = &INHERITABLE_ATTRIBUTES[0]; // become
        let child = AnsibleValue::Bool(true);
        let parent = AnsibleValue::Bool(false);
        let result = resolve_attribute(attr, Some(&child), Some(&parent));
        assert_eq!(result, Some(AnsibleValue::Bool(true)));
    }

    #[test]
    fn test_replace_inherit_from_parent() {
        let attr = &INHERITABLE_ATTRIBUTES[0]; // become
        let parent = AnsibleValue::Bool(true);
        let result = resolve_attribute(attr, None, Some(&parent));
        assert_eq!(result, Some(AnsibleValue::Bool(true)));
    }

    #[test]
    fn test_extend_merges_lists() {
        // tags uses Extend strategy
        let attr = INHERITABLE_ATTRIBUTES
            .iter()
            .find(|a| a.name == "tags")
            .unwrap();

        let parent = serde_json::json!(["web", "deploy"]);
        let child = serde_json::json!(["urgent"]);
        let result = resolve_attribute(attr, Some(&child), Some(&parent));

        let arr = result.unwrap();
        let items = arr.as_array().unwrap();
        assert_eq!(items.len(), 3);
        // Parent first, then child (Extend = parent + child)
        assert_eq!(items[0], "web");
        assert_eq!(items[1], "deploy");
        assert_eq!(items[2], "urgent");
    }

    #[test]
    fn test_prepend_merges_lists() {
        // environment uses ExtendPrepend strategy
        let attr = INHERITABLE_ATTRIBUTES
            .iter()
            .find(|a| a.name == "environment")
            .unwrap();

        let parent = serde_json::json!([{"FOO": "bar"}]);
        let child = serde_json::json!([{"BAZ": "qux"}]);
        let result = resolve_attribute(attr, Some(&child), Some(&parent));

        let arr = result.unwrap();
        let items = arr.as_array().unwrap();
        assert_eq!(items.len(), 2);
        // Child first, then parent (Prepend)
        assert!(items[0].get("BAZ").is_some());
        assert!(items[1].get("FOO").is_some());
    }

    #[test]
    fn test_squash_attributes() {
        let mut parent = HashMap::new();
        parent.insert("become".to_string(), AnsibleValue::Bool(true));
        parent.insert("become_user".to_string(), serde_json::json!("root"));
        parent.insert("tags".to_string(), serde_json::json!(["web"]));

        let mut child = HashMap::new();
        child.insert("become_user".to_string(), serde_json::json!("deploy"));
        child.insert("tags".to_string(), serde_json::json!(["urgent"]));

        let squashed = squash_attributes(&child, &parent);

        // become inherited from parent
        assert_eq!(squashed.get("become").unwrap(), &AnsibleValue::Bool(true));
        // become_user overridden by child
        assert_eq!(squashed.get("become_user").unwrap(), &serde_json::json!("deploy"));
        // tags extended: parent + child
        let tags = squashed.get("tags").unwrap().as_array().unwrap();
        assert_eq!(tags.len(), 2);
    }
}
