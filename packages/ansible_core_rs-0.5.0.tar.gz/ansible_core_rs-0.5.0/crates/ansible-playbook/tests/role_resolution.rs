//! Integration tests for role dependency resolution.
//!
//! Tests exercise the `RoleLoader::resolve_dependencies` method, which
//! recursively loads role dependencies declared in `meta/main.yml` and
//! returns them in execution order (dependencies before dependents).

use std::collections::HashMap;
use std::fs;
use std::path::PathBuf;

use ansible_playbook::error::PlaybookError;
use ansible_playbook::role::{Role, RoleLoader};
use ansible_playbook::types::TagSpec;
use ansible_utils::AnsibleValue;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/// Create a minimal role directory structure on disk.
///
/// * `roles_dir`  - parent directory containing all roles (the search path)
/// * `name`       - role name (used as subdirectory name)
/// * `tasks_yml`  - optional content for `tasks/main.yml`
/// * `meta_yml`   - optional content for `meta/main.yml`
fn create_role(
    roles_dir: &std::path::Path,
    name: &str,
    tasks_yml: Option<&str>,
    meta_yml: Option<&str>,
) -> PathBuf {
    let role_dir = roles_dir.join(name);
    // Create at least one standard subdir so `is_role_dir` returns true.
    fs::create_dir_all(role_dir.join("tasks")).unwrap();

    if let Some(content) = tasks_yml {
        fs::write(role_dir.join("tasks").join("main.yml"), content).unwrap();
    }

    if let Some(content) = meta_yml {
        fs::create_dir_all(role_dir.join("meta")).unwrap();
        fs::write(role_dir.join("meta").join("main.yml"), content).unwrap();
    }

    role_dir
}

/// Build a `RoleLoader` whose sole search path is `roles_dir`.
fn loader_for(roles_dir: &std::path::Path) -> RoleLoader {
    RoleLoader::new(vec![roles_dir.to_path_buf()])
}

/// Load a top-level role by name and resolve all its dependencies.
fn resolve(loader: &mut RoleLoader, role_name: &str) -> Result<Vec<Role>, PlaybookError> {
    let role = loader.load_role(
        role_name,
        HashMap::new(),
        TagSpec::default(),
        Vec::new(),
    )?;
    loader.resolve_dependencies(&role)
}

/// Extract the ordered list of role names from a resolved dependency list.
fn role_names(roles: &[Role]) -> Vec<&str> {
    roles.iter().map(|r| r.name.as_str()).collect()
}

// ---------------------------------------------------------------------------
// 1. Linear dependency chain: role_a -> role_b -> role_c
//    Expected execution order: [c, b, a]
// ---------------------------------------------------------------------------

#[test]
fn linear_dependency_chain() {
    let tmp = tempfile::tempdir().unwrap();
    let roles_dir = tmp.path().join("roles");
    fs::create_dir_all(&roles_dir).unwrap();

    // role_c: leaf, no dependencies
    create_role(
        &roles_dir,
        "role_c",
        Some("- debug: msg=from_c\n"),
        None,
    );

    // role_b: depends on role_c
    create_role(
        &roles_dir,
        "role_b",
        Some("- debug: msg=from_b\n"),
        Some("dependencies:\n  - role_c\n"),
    );

    // role_a: depends on role_b
    create_role(
        &roles_dir,
        "role_a",
        Some("- debug: msg=from_a\n"),
        Some("dependencies:\n  - role_b\n"),
    );

    let mut loader = loader_for(&roles_dir);
    let resolved = resolve(&mut loader, "role_a").unwrap();

    let names = role_names(&resolved);
    assert_eq!(names, &["role_c", "role_b", "role_a"]);
}

// ---------------------------------------------------------------------------
// 2. Diamond dependency:
//    role_a -> role_b, role_c
//    role_b -> role_d
//    role_c -> role_d
//    role_d should appear exactly once.
// ---------------------------------------------------------------------------

#[test]
fn diamond_dependency() {
    let tmp = tempfile::tempdir().unwrap();
    let roles_dir = tmp.path().join("roles");
    fs::create_dir_all(&roles_dir).unwrap();

    // role_d: leaf
    create_role(
        &roles_dir,
        "role_d",
        Some("- debug: msg=from_d\n"),
        None,
    );

    // role_b: depends on role_d
    create_role(
        &roles_dir,
        "role_b",
        Some("- debug: msg=from_b\n"),
        Some("dependencies:\n  - role_d\n"),
    );

    // role_c: depends on role_d
    create_role(
        &roles_dir,
        "role_c",
        Some("- debug: msg=from_c\n"),
        Some("dependencies:\n  - role_d\n"),
    );

    // role_a: depends on role_b and role_c
    create_role(
        &roles_dir,
        "role_a",
        Some("- debug: msg=from_a\n"),
        Some("dependencies:\n  - role_b\n  - role_c\n"),
    );

    let mut loader = loader_for(&roles_dir);
    let resolved = resolve(&mut loader, "role_a").unwrap();

    let names = role_names(&resolved);

    // role_d must appear exactly once despite being a dependency of both
    // role_b and role_c.
    assert_eq!(
        names.iter().filter(|n| **n == "role_d").count(),
        1,
        "role_d should appear exactly once, got: {names:?}"
    );

    // role_d must come before role_b and role_c, which must come before role_a.
    let pos_d = names.iter().position(|n| *n == "role_d").unwrap();
    let pos_b = names.iter().position(|n| *n == "role_b").unwrap();
    let pos_c = names.iter().position(|n| *n == "role_c").unwrap();
    let pos_a = names.iter().position(|n| *n == "role_a").unwrap();

    assert!(pos_d < pos_b, "role_d must precede role_b");
    assert!(pos_d < pos_c, "role_d must precede role_c");
    assert!(pos_b < pos_a, "role_b must precede role_a");
    assert!(pos_c < pos_a, "role_c must precede role_a");
}

// ---------------------------------------------------------------------------
// 3. Cycle detection: role_a -> role_b -> role_a
//    The seen-set should prevent re-processing and avoid infinite recursion.
// ---------------------------------------------------------------------------

#[test]
fn cycle_detection_does_not_loop() {
    let tmp = tempfile::tempdir().unwrap();
    let roles_dir = tmp.path().join("roles");
    fs::create_dir_all(&roles_dir).unwrap();

    // role_a depends on role_b
    create_role(
        &roles_dir,
        "role_a",
        Some("- debug: msg=from_a\n"),
        Some("dependencies:\n  - role_b\n"),
    );

    // role_b depends on role_a (creates cycle)
    create_role(
        &roles_dir,
        "role_b",
        Some("- debug: msg=from_b\n"),
        Some("dependencies:\n  - role_a\n"),
    );

    let mut loader = loader_for(&roles_dir);
    let resolved = resolve(&mut loader, "role_a").unwrap();

    let names = role_names(&resolved);

    // Both roles should appear exactly once. The cycle does not cause
    // infinite recursion because the seen-set short-circuits.
    assert_eq!(
        names.iter().filter(|n| **n == "role_a").count(),
        1,
        "role_a should appear once, got: {names:?}"
    );
    assert_eq!(
        names.iter().filter(|n| **n == "role_b").count(),
        1,
        "role_b should appear once, got: {names:?}"
    );
}

// ---------------------------------------------------------------------------
// 4. allow_duplicates: a role with allow_duplicates=true should be processed
//    each time it appears in the dependency list.
// ---------------------------------------------------------------------------

#[test]
fn allow_duplicates_role_appears_multiple_times() {
    let tmp = tempfile::tempdir().unwrap();
    let roles_dir = tmp.path().join("roles");
    fs::create_dir_all(&roles_dir).unwrap();

    // dup_role: allow_duplicates=true, no dependencies
    create_role(
        &roles_dir,
        "dup_role",
        Some("- debug: msg=dup\n"),
        Some("allow_duplicates: true\n"),
    );

    // role_x depends on dup_role
    create_role(
        &roles_dir,
        "role_x",
        Some("- debug: msg=from_x\n"),
        Some("dependencies:\n  - dup_role\n"),
    );

    // role_y depends on dup_role
    create_role(
        &roles_dir,
        "role_y",
        Some("- debug: msg=from_y\n"),
        Some("dependencies:\n  - dup_role\n"),
    );

    // top_role depends on role_x and role_y
    create_role(
        &roles_dir,
        "top_role",
        Some("- debug: msg=from_top\n"),
        Some("dependencies:\n  - role_x\n  - role_y\n"),
    );

    let mut loader = loader_for(&roles_dir);
    let resolved = resolve(&mut loader, "top_role").unwrap();

    let names = role_names(&resolved);

    // Because dup_role has allow_duplicates=true, it should appear once for
    // each path that reaches it (via role_x and via role_y).
    let dup_count = names.iter().filter(|n| **n == "dup_role").count();
    assert_eq!(
        dup_count, 2,
        "dup_role should appear twice due to allow_duplicates=true, got: {names:?}"
    );
}

// ---------------------------------------------------------------------------
// 5. Role with params / tags / when from the dependency spec
//    Verify that parameters, tags, and when conditions declared in the
//    dependency are passed through to the resolved role object.
// ---------------------------------------------------------------------------

#[test]
fn dependency_params_tags_and_when_passed_through() {
    let tmp = tempfile::tempdir().unwrap();
    let roles_dir = tmp.path().join("roles");
    fs::create_dir_all(&roles_dir).unwrap();

    // param_role: leaf, no dependencies
    create_role(
        &roles_dir,
        "param_role",
        Some("- debug: msg=param\n"),
        None,
    );

    // top_role depends on param_role with vars, tags, and when
    let meta = "\
dependencies:
  - role: param_role
    vars:
      nginx_port: 8080
      enable_ssl: true
    tags:
      - web
      - setup
    when:
      - install_web_server
";
    create_role(
        &roles_dir,
        "top_role",
        Some("- debug: msg=top\n"),
        Some(meta),
    );

    let mut loader = loader_for(&roles_dir);
    let resolved = resolve(&mut loader, "top_role").unwrap();

    let names = role_names(&resolved);
    assert_eq!(names, &["param_role", "top_role"]);

    let param_role = resolved.iter().find(|r| r.name == "param_role").unwrap();

    // Verify params (vars from the dependency spec)
    assert_eq!(
        param_role.params.get("nginx_port").unwrap(),
        &AnsibleValue::Number(8080.into()),
        "nginx_port param should be passed through"
    );
    assert_eq!(
        param_role.params.get("enable_ssl").unwrap(),
        &AnsibleValue::Bool(true),
        "enable_ssl param should be passed through"
    );

    // Verify tags
    assert!(
        param_role.tags.contains("web"),
        "param_role should carry the 'web' tag"
    );
    assert!(
        param_role.tags.contains("setup"),
        "param_role should carry the 'setup' tag"
    );

    // Verify when conditions
    assert_eq!(
        param_role.when_conditions,
        vec!["install_web_server"],
        "when_conditions should be passed through"
    );
}

// ---------------------------------------------------------------------------
// 6. Missing dependency: referencing a role that does not exist on disk
//    should produce a RoleNotFound error.
// ---------------------------------------------------------------------------

#[test]
fn missing_dependency_returns_role_not_found() {
    let tmp = tempfile::tempdir().unwrap();
    let roles_dir = tmp.path().join("roles");
    fs::create_dir_all(&roles_dir).unwrap();

    // role_missing_ref depends on nonexistent_role
    create_role(
        &roles_dir,
        "role_missing_ref",
        Some("- debug: msg=oops\n"),
        Some("dependencies:\n  - nonexistent_role\n"),
    );

    let mut loader = loader_for(&roles_dir);
    let result = resolve(&mut loader, "role_missing_ref");

    match result {
        Err(PlaybookError::RoleNotFound(name)) => {
            assert_eq!(
                name, "nonexistent_role",
                "error should name the missing role"
            );
        }
        other => {
            panic!(
                "expected PlaybookError::RoleNotFound(\"nonexistent_role\"), got: {other:?}"
            );
        }
    }
}

// ---------------------------------------------------------------------------
// 7. Self-dependency: a role that lists itself as a dependency should not
//    cause infinite recursion. The seen-set should prevent re-processing.
// ---------------------------------------------------------------------------

#[test]
fn self_dependency_no_infinite_recursion() {
    let tmp = tempfile::tempdir().unwrap();
    let roles_dir = tmp.path().join("roles");
    fs::create_dir_all(&roles_dir).unwrap();

    // self_role depends on itself
    create_role(
        &roles_dir,
        "self_role",
        Some("- debug: msg=self\n"),
        Some("dependencies:\n  - self_role\n"),
    );

    let mut loader = loader_for(&roles_dir);
    let resolved = resolve(&mut loader, "self_role").unwrap();

    let names = role_names(&resolved);

    // The role should appear exactly once. When resolve_deps_recursive
    // processes self_role, it inserts "self_role" into the seen set, then
    // iterates dependencies, finds "self_role", loads it from cache/disk,
    // and calls resolve_deps_recursive again. The recursive call sees the
    // name already in seen (and allow_duplicates is false by default) so
    // returns immediately without pushing a duplicate.
    assert_eq!(names, &["self_role"]);
}

// ---------------------------------------------------------------------------
// Bonus: verify that tasks are actually loaded from disk for resolved roles.
// ---------------------------------------------------------------------------

#[test]
fn resolved_roles_load_tasks_from_disk() {
    let tmp = tempfile::tempdir().unwrap();
    let roles_dir = tmp.path().join("roles");
    fs::create_dir_all(&roles_dir).unwrap();

    create_role(
        &roles_dir,
        "base_role",
        Some("- name: base task\n  debug:\n    msg: hello from base\n"),
        None,
    );

    create_role(
        &roles_dir,
        "app_role",
        Some("- name: app task\n  debug:\n    msg: hello from app\n"),
        Some("dependencies:\n  - base_role\n"),
    );

    let mut loader = loader_for(&roles_dir);
    let resolved = resolve(&mut loader, "app_role").unwrap();

    let base = resolved.iter().find(|r| r.name == "base_role").unwrap();
    assert_eq!(base.tasks.len(), 1, "base_role should have 1 task loaded");
    assert_eq!(
        base.tasks[0].name.as_deref(),
        Some("base task"),
        "base_role task name should be loaded"
    );

    let app = resolved.iter().find(|r| r.name == "app_role").unwrap();
    assert_eq!(app.tasks.len(), 1, "app_role should have 1 task loaded");
    assert_eq!(
        app.tasks[0].name.as_deref(),
        Some("app task"),
        "app_role task name should be loaded"
    );
}

// ---------------------------------------------------------------------------
// Bonus: defaults and vars are loaded from disk for resolved roles.
// ---------------------------------------------------------------------------

#[test]
fn resolved_roles_load_defaults_and_vars() {
    let tmp = tempfile::tempdir().unwrap();
    let roles_dir = tmp.path().join("roles");
    fs::create_dir_all(&roles_dir).unwrap();

    // Create a role with defaults and vars
    let role_dir = roles_dir.join("configured_role");
    fs::create_dir_all(role_dir.join("tasks")).unwrap();
    fs::create_dir_all(role_dir.join("defaults")).unwrap();
    fs::create_dir_all(role_dir.join("vars")).unwrap();

    fs::write(role_dir.join("tasks").join("main.yml"), "[]\n").unwrap();
    fs::write(
        role_dir.join("defaults").join("main.yml"),
        "default_port: 80\ndefault_host: localhost\n",
    )
    .unwrap();
    fs::write(
        role_dir.join("vars").join("main.yml"),
        "resolved_host: 10.0.0.1\n",
    )
    .unwrap();

    let mut loader = loader_for(&roles_dir);
    let role = loader
        .load_role(
            "configured_role",
            HashMap::new(),
            TagSpec::default(),
            Vec::new(),
        )
        .unwrap();

    assert_eq!(
        role.defaults.get("default_port").unwrap(),
        &AnsibleValue::Number(80.into()),
        "default_port should be loaded from defaults/main.yml"
    );
    assert_eq!(
        role.defaults.get("default_host").unwrap(),
        &AnsibleValue::String("localhost".into()),
        "default_host should be loaded from defaults/main.yml"
    );
    assert_eq!(
        role.vars.get("resolved_host").unwrap(),
        &AnsibleValue::String("10.0.0.1".into()),
        "resolved_host should be loaded from vars/main.yml"
    );
}

// ---------------------------------------------------------------------------
// Bonus: handlers are loaded from disk.
// ---------------------------------------------------------------------------

#[test]
fn resolved_roles_load_handlers() {
    let tmp = tempfile::tempdir().unwrap();
    let roles_dir = tmp.path().join("roles");
    fs::create_dir_all(&roles_dir).unwrap();

    let role_dir = roles_dir.join("handler_role");
    fs::create_dir_all(role_dir.join("tasks")).unwrap();
    fs::create_dir_all(role_dir.join("handlers")).unwrap();

    fs::write(role_dir.join("tasks").join("main.yml"), "[]\n").unwrap();
    fs::write(
        role_dir.join("handlers").join("main.yml"),
        "- name: restart nginx\n  systemd:\n    name: nginx\n    state: restarted\n",
    )
    .unwrap();

    let mut loader = loader_for(&roles_dir);
    let role = loader
        .load_role(
            "handler_role",
            HashMap::new(),
            TagSpec::default(),
            Vec::new(),
        )
        .unwrap();

    assert_eq!(role.handlers.len(), 1, "handler_role should have 1 handler");
    assert_eq!(
        role.handlers[0].name.as_deref(),
        Some("restart nginx"),
        "handler name should be loaded"
    );
}

// ---------------------------------------------------------------------------
// Bonus: wide dependency fan-out
//    top depends on a, b, c, d, e (all leaves).
//    All five should appear in order before top.
// ---------------------------------------------------------------------------

#[test]
fn wide_dependency_fan_out() {
    let tmp = tempfile::tempdir().unwrap();
    let roles_dir = tmp.path().join("roles");
    fs::create_dir_all(&roles_dir).unwrap();

    let leaf_names = ["alpha", "beta", "gamma", "delta", "epsilon"];
    for leaf in &leaf_names {
        create_role(&roles_dir, leaf, Some("- debug: msg=leaf\n"), None);
    }

    let deps_yaml = leaf_names
        .iter()
        .map(|n| format!("  - {n}"))
        .collect::<Vec<_>>()
        .join("\n");
    create_role(
        &roles_dir,
        "fan_top",
        Some("- debug: msg=top\n"),
        Some(&format!("dependencies:\n{deps_yaml}\n")),
    );

    let mut loader = loader_for(&roles_dir);
    let resolved = resolve(&mut loader, "fan_top").unwrap();

    let names = role_names(&resolved);

    // fan_top must be last
    assert_eq!(names.last(), Some(&"fan_top"));

    // All leaves must appear before fan_top
    let top_pos = names.iter().position(|n| *n == "fan_top").unwrap();
    for leaf in &leaf_names {
        let pos = names.iter().position(|n| *n == *leaf);
        assert!(pos.is_some(), "{leaf} should be in resolved list");
        assert!(pos.unwrap() < top_pos, "{leaf} should precede fan_top");
    }

    // Exactly 6 roles total
    assert_eq!(names.len(), 6);
}

// ---------------------------------------------------------------------------
// Bonus: allow_duplicates=false (default) deduplicates across a diamond
//    This is a variation on the diamond test, explicitly verifying the
//    default allow_duplicates=false behavior.
// ---------------------------------------------------------------------------

#[test]
fn default_no_duplicates_in_diamond() {
    let tmp = tempfile::tempdir().unwrap();
    let roles_dir = tmp.path().join("roles");
    fs::create_dir_all(&roles_dir).unwrap();

    // shared has allow_duplicates=false (the default)
    create_role(
        &roles_dir,
        "shared",
        Some("- debug: msg=shared\n"),
        Some("allow_duplicates: false\n"),
    );

    create_role(
        &roles_dir,
        "left",
        Some("- debug: msg=left\n"),
        Some("dependencies:\n  - shared\n"),
    );

    create_role(
        &roles_dir,
        "right",
        Some("- debug: msg=right\n"),
        Some("dependencies:\n  - shared\n"),
    );

    create_role(
        &roles_dir,
        "diamond_top",
        Some("- debug: msg=top\n"),
        Some("dependencies:\n  - left\n  - right\n"),
    );

    let mut loader = loader_for(&roles_dir);
    let resolved = resolve(&mut loader, "diamond_top").unwrap();

    let names = role_names(&resolved);

    // shared should appear exactly once
    assert_eq!(
        names.iter().filter(|n| **n == "shared").count(),
        1,
        "shared should appear exactly once with allow_duplicates=false, got: {names:?}"
    );
}
