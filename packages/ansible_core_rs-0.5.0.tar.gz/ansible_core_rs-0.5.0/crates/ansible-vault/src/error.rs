use thiserror::Error;

#[derive(Debug, Error)]
pub enum VaultError {
    #[error("vault format error: {0}")]
    FormatError(String),

    #[error("vault decryption failed: {0}")]
    DecryptionFailed(String),

    #[error("HMAC verification failed")]
    HmacMismatch,

    #[error("cryptographic operation failed: {0}")]
    CryptoError(String),

    #[error("unsupported vault cipher: {0}")]
    UnsupportedCipher(String),

    #[error(transparent)]
    Io(#[from] std::io::Error),
}
