pub mod error;

pub use error::VaultError;

use zeroize::Zeroize;

/// The vault header prefix.
const VAULT_HEADER: &str = "$ANSIBLE_VAULT";
/// Current vault format version.
const VAULT_VERSION: &str = "1.1";
/// Default cipher.
const DEFAULT_CIPHER: &str = "AES256";
/// PBKDF2 iteration count (matches Python ansible-vault).
const PBKDF2_ITERATIONS: u32 = 10000;
/// Key length for AES-256.
const KEY_LENGTH: usize = 32;
/// HMAC key length.
const HMAC_LENGTH: usize = 32;
/// IV length for AES-CTR.
const IV_LENGTH: usize = 16;

/// A vault secret (password) used for encryption/decryption.
#[derive(Clone)]
pub struct VaultSecret {
    secret: Vec<u8>,
    vault_id: Option<String>,
}

impl VaultSecret {
    pub fn new(secret: Vec<u8>) -> Self {
        Self {
            secret,
            vault_id: None,
        }
    }

    pub fn with_vault_id(secret: Vec<u8>, vault_id: String) -> Self {
        Self {
            secret,
            vault_id: Some(vault_id),
        }
    }

    pub fn bytes(&self) -> &[u8] {
        &self.secret
    }

    pub fn vault_id(&self) -> Option<&str> {
        self.vault_id.as_deref()
    }
}

impl Drop for VaultSecret {
    fn drop(&mut self) {
        self.secret.zeroize();
    }
}

impl Zeroize for VaultSecret {
    fn zeroize(&mut self) {
        self.secret.zeroize();
    }
}

/// Vault encryption/decryption library.
///
/// Implements Ansible Vault format 1.1 with AES-256-CTR + HMAC-SHA256.
///
/// Vault file format:
/// ```text
/// $ANSIBLE_VAULT;1.1;AES256
/// <hex-encoded encrypted data>
/// ```
///
/// The hex-encoded data contains three newline-separated hex strings:
/// 1. Salt (32 bytes)
/// 2. HMAC digest (32 bytes)
/// 3. Ciphertext (AES-256-CTR encrypted)
///
/// Key derivation: PBKDF2-HMAC-SHA256 with 10000 iterations produces
/// 80 bytes: 32 for AES key, 32 for HMAC key, 16 for IV.
pub struct VaultLib {
    secrets: Vec<VaultSecret>,
}

impl VaultLib {
    pub fn new(secrets: Vec<VaultSecret>) -> Self {
        Self { secrets }
    }

    /// Encrypt plaintext bytes and return vault-formatted string.
    pub fn encrypt(&self, plaintext: &[u8], secret: &VaultSecret) -> Result<String, VaultError> {
        use hmac::Mac;

        // Generate random salt
        let salt = generate_random_bytes(32);

        // Derive keys using PBKDF2
        let (aes_key, hmac_key, iv) = derive_keys(secret.bytes(), &salt)?;

        // Encrypt with AES-256-CTR
        let ciphertext = aes256_ctr_encrypt(plaintext, &aes_key, &iv);

        // Compute HMAC-SHA256 over ciphertext
        let mut mac =
            hmac::Hmac::<sha2::Sha256>::new_from_slice(&hmac_key).map_err(|e| VaultError::CryptoError(e.to_string()))?;
        mac.update(&ciphertext);
        let hmac_digest = mac.finalize().into_bytes();

        // Format: hex(salt) + \n + hex(hmac) + \n + hex(ciphertext)
        let payload = format!(
            "{}\n{}\n{}",
            hex_encode(&salt),
            hex_encode(&hmac_digest),
            hex_encode(&ciphertext)
        );

        // Hex-encode the payload and wrap to 80 chars
        let hex_payload = hex_encode(payload.as_bytes());
        let wrapped = wrap_text(&hex_payload, 80);

        // Build vault header
        let header = format!("{VAULT_HEADER};{VAULT_VERSION};{DEFAULT_CIPHER}");

        Ok(format!("{header}\n{wrapped}"))
    }

    /// Decrypt a vault-formatted string and return plaintext.
    pub fn decrypt(&self, vault_text: &str) -> Result<Vec<u8>, VaultError> {
        // Try each secret until one works
        for secret in &self.secrets {
            match self.try_decrypt(vault_text, secret) {
                Ok(plaintext) => return Ok(plaintext),
                Err(VaultError::HmacMismatch) => continue,
                Err(e) => return Err(e),
            }
        }

        Err(VaultError::DecryptionFailed(
            "no vault secret could decrypt this content".into(),
        ))
    }

    /// Decrypt vault text and return as a String.
    pub fn decrypt_str(&self, vault_text: &str) -> Result<String, VaultError> {
        let bytes = self.decrypt(vault_text)?;
        String::from_utf8(bytes).map_err(|e| VaultError::DecryptionFailed(e.to_string()))
    }

    fn try_decrypt(&self, vault_text: &str, secret: &VaultSecret) -> Result<Vec<u8>, VaultError> {
        use hmac::Mac;

        let (_, body) = parse_vault_header(vault_text)?;

        // Unwrap and hex-decode the body
        let hex_body: String = body.chars().filter(|c| !c.is_whitespace()).collect();
        let decoded_body =
            hex_decode(&hex_body).map_err(|e| VaultError::FormatError(e.to_string()))?;
        let decoded_str = String::from_utf8(decoded_body)
            .map_err(|e| VaultError::FormatError(e.to_string()))?;

        // Split into salt, hmac, ciphertext (hex-encoded, newline-separated)
        let parts: Vec<&str> = decoded_str.split('\n').collect();
        if parts.len() != 3 {
            return Err(VaultError::FormatError(format!(
                "expected 3 parts, got {}",
                parts.len()
            )));
        }

        let salt = hex_decode(parts[0]).map_err(|e| VaultError::FormatError(e.to_string()))?;
        let expected_hmac =
            hex_decode(parts[1]).map_err(|e| VaultError::FormatError(e.to_string()))?;
        let ciphertext =
            hex_decode(parts[2]).map_err(|e| VaultError::FormatError(e.to_string()))?;

        // Derive keys
        let (aes_key, hmac_key, iv) = derive_keys(secret.bytes(), &salt)?;

        // Verify HMAC
        let mut mac =
            hmac::Hmac::<sha2::Sha256>::new_from_slice(&hmac_key).map_err(|e| VaultError::CryptoError(e.to_string()))?;
        mac.update(&ciphertext);
        mac.verify_slice(&expected_hmac)
            .map_err(|_| VaultError::HmacMismatch)?;

        // Decrypt
        let plaintext = aes256_ctr_decrypt(&ciphertext, &aes_key, &iv);

        // Remove PKCS7 padding
        let plaintext = pkcs7_unpad(&plaintext)?;

        Ok(plaintext)
    }
}

/// Parse the vault header and return (cipher, body).
fn parse_vault_header(text: &str) -> Result<(String, String), VaultError> {
    let text = text.trim();
    let first_newline = text
        .find('\n')
        .ok_or_else(|| VaultError::FormatError("no newline in vault text".into()))?;

    let header = &text[..first_newline];
    let body = &text[first_newline + 1..];

    let parts: Vec<&str> = header.split(';').collect();
    if parts.len() < 3 || parts[0] != VAULT_HEADER {
        return Err(VaultError::FormatError(format!(
            "invalid vault header: {header}"
        )));
    }

    let cipher = parts[2].to_string();
    Ok((cipher, body.to_string()))
}

/// Derive AES key, HMAC key, and IV from password and salt using PBKDF2.
#[allow(clippy::type_complexity)]
fn derive_keys(
    password: &[u8],
    salt: &[u8],
) -> Result<(Vec<u8>, Vec<u8>, Vec<u8>), VaultError> {
    let mut derived = vec![0u8; KEY_LENGTH + HMAC_LENGTH + IV_LENGTH];

    pbkdf2::pbkdf2_hmac::<sha2::Sha256>(password, salt, PBKDF2_ITERATIONS, &mut derived);

    let aes_key = derived[..KEY_LENGTH].to_vec();
    let hmac_key = derived[KEY_LENGTH..KEY_LENGTH + HMAC_LENGTH].to_vec();
    let iv = derived[KEY_LENGTH + HMAC_LENGTH..].to_vec();

    Ok((aes_key, hmac_key, iv))
}

/// AES-256-CTR encryption (also used for decryption since CTR is symmetric).
fn aes256_ctr_encrypt(data: &[u8], key: &[u8], iv: &[u8]) -> Vec<u8> {
    

    // PKCS7 pad the data to AES block size
    let padded = pkcs7_pad(data, 16);

    // AES-256-CTR using the aes crate directly
    // For now, use a simple XOR with keystream approach
    // TODO: Use proper AES-CTR from the `ctr` crate
    let mut output = padded.clone();
    aes256_ctr_xor(&mut output, key, iv);
    output
}

fn aes256_ctr_decrypt(data: &[u8], key: &[u8], iv: &[u8]) -> Vec<u8> {
    let mut output = data.to_vec();
    aes256_ctr_xor(&mut output, key, iv);
    output
}

/// XOR data with AES-256-CTR keystream.
fn aes256_ctr_xor(data: &mut [u8], key: &[u8], iv: &[u8]) {
    // Manual AES-CTR implementation
    // Counter starts at IV and increments for each block
    let mut counter = [0u8; 16];
    counter.copy_from_slice(&iv[..16]);

    let cipher = aes256_new(key);

    for chunk in data.chunks_mut(16) {
        let keystream = aes256_encrypt_block(&cipher, &counter);
        for (byte, ks) in chunk.iter_mut().zip(keystream.iter()) {
            *byte ^= ks;
        }
        increment_counter(&mut counter);
    }
}

/// Simple AES-256 block cipher wrapper.
struct Aes256Cipher {
    key: [u8; 32],
}

fn aes256_new(key: &[u8]) -> Aes256Cipher {
    let mut k = [0u8; 32];
    k.copy_from_slice(&key[..32]);
    Aes256Cipher { key: k }
}

fn aes256_encrypt_block(cipher: &Aes256Cipher, block: &[u8; 16]) -> [u8; 16] {
    use aes_gcm::aes::Aes256;
    use aes_gcm::aead::generic_array::GenericArray;

    let key = GenericArray::from_slice(&cipher.key);
    let aes = <Aes256 as aes_gcm::aes::cipher::KeyInit>::new(key);

    let mut out = GenericArray::clone_from_slice(block);
    aes_gcm::aes::cipher::BlockEncrypt::encrypt_block(&aes, &mut out);
    let mut result = [0u8; 16];
    result.copy_from_slice(&out);
    result
}

fn increment_counter(counter: &mut [u8; 16]) {
    for byte in counter.iter_mut().rev() {
        let (new_val, overflow) = byte.overflowing_add(1);
        *byte = new_val;
        if !overflow {
            break;
        }
    }
}

/// PKCS7 padding.
fn pkcs7_pad(data: &[u8], block_size: usize) -> Vec<u8> {
    let padding_len = block_size - (data.len() % block_size);
    let mut padded = data.to_vec();
    padded.extend(std::iter::repeat_n(padding_len as u8, padding_len));
    padded
}

/// PKCS7 unpadding.
fn pkcs7_unpad(data: &[u8]) -> Result<Vec<u8>, VaultError> {
    if data.is_empty() {
        return Err(VaultError::FormatError("empty data".into()));
    }
    let pad_len = *data.last().unwrap() as usize;
    if pad_len == 0 || pad_len > 16 || pad_len > data.len() {
        return Err(VaultError::FormatError(format!(
            "invalid PKCS7 padding: {pad_len}"
        )));
    }
    // Verify all padding bytes are correct
    for &byte in &data[data.len() - pad_len..] {
        if byte as usize != pad_len {
            return Err(VaultError::FormatError("invalid PKCS7 padding bytes".into()));
        }
    }
    Ok(data[..data.len() - pad_len].to_vec())
}

/// Generate random bytes.
fn generate_random_bytes(len: usize) -> Vec<u8> {
    use rand::Rng;
    let mut rng = rand::rng();
    let mut bytes = vec![0u8; len];
    rng.fill(&mut bytes[..]);
    bytes
}

/// Hex encode bytes.
fn hex_encode(data: &[u8]) -> String {
    data.iter().map(|b| format!("{b:02x}")).collect()
}

/// Hex decode a string.
fn hex_decode(s: &str) -> Result<Vec<u8>, String> {
    if s.len() % 2 != 0 {
        return Err("odd-length hex string".into());
    }
    (0..s.len())
        .step_by(2)
        .map(|i| u8::from_str_radix(&s[i..i + 2], 16).map_err(|e| e.to_string()))
        .collect()
}

/// Wrap text to specified width.
fn wrap_text(text: &str, width: usize) -> String {
    text.as_bytes()
        .chunks(width)
        .map(|chunk| std::str::from_utf8(chunk).unwrap())
        .collect::<Vec<_>>()
        .join("\n")
}

#[cfg(test)]
mod tests {
    use super::*;

    // =========================================================================
    // 1. Known plaintext roundtrip
    // =========================================================================

    #[test]
    fn test_encrypt_decrypt_roundtrip_basic() {
        let secret = VaultSecret::new(b"password123".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"password123".to_vec())]);
        let plaintext = b"this is a secret message";

        let encrypted = vault.encrypt(plaintext, &secret).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, plaintext);
    }

    #[test]
    fn test_encrypt_decrypt_roundtrip_repeated() {
        // Encrypt the same plaintext multiple times; each should produce different
        // ciphertext (different salt) but still decrypt to the same value.
        let secret = VaultSecret::new(b"hunter2".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"hunter2".to_vec())]);
        let plaintext = b"repeatable";

        let mut encrypted_outputs = Vec::new();
        for _ in 0..5 {
            let enc = vault.encrypt(plaintext, &secret).unwrap();
            let dec = vault.decrypt(&enc).unwrap();
            assert_eq!(dec, plaintext);
            encrypted_outputs.push(enc);
        }
        // Verify that not all outputs are identical (random salt should vary).
        let all_same = encrypted_outputs
            .windows(2)
            .all(|w| w[0] == w[1]);
        assert!(!all_same, "all encrypted outputs were identical -- salt may not be random");
    }

    // =========================================================================
    // 2. Format compliance
    // =========================================================================

    #[test]
    fn test_encrypted_output_starts_with_header() {
        let secret = VaultSecret::new(b"testpw".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"testpw".to_vec())]);
        let encrypted = vault.encrypt(b"hello", &secret).unwrap();

        assert!(
            encrypted.starts_with("$ANSIBLE_VAULT;1.1;AES256\n"),
            "encrypted output must start with the vault header line"
        );
    }

    #[test]
    fn test_encrypted_output_header_line_is_first_line() {
        let secret = VaultSecret::new(b"testpw".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"testpw".to_vec())]);
        let encrypted = vault.encrypt(b"hello", &secret).unwrap();

        let first_line = encrypted.lines().next().unwrap();
        assert_eq!(first_line, "$ANSIBLE_VAULT;1.1;AES256");
    }

    #[test]
    fn test_encrypted_body_lines_wrapped_at_80_chars() {
        let secret = VaultSecret::new(b"testpw".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"testpw".to_vec())]);
        // Use a large enough plaintext to produce multi-line hex output.
        let plaintext = vec![0xAB_u8; 1024];
        let encrypted = vault.encrypt(&plaintext, &secret).unwrap();

        let body_lines: Vec<&str> = encrypted.lines().skip(1).collect();
        assert!(body_lines.len() > 1, "body should be wrapped across multiple lines");

        for (i, line) in body_lines.iter().enumerate() {
            if i < body_lines.len() - 1 {
                assert_eq!(
                    line.len(),
                    80,
                    "non-final body line must be exactly 80 chars, got {} on line {}",
                    line.len(),
                    i
                );
            } else {
                assert!(
                    line.len() <= 80,
                    "final body line must be at most 80 chars, got {}",
                    line.len()
                );
            }
        }
    }

    #[test]
    fn test_encrypted_body_is_valid_hex() {
        let secret = VaultSecret::new(b"testpw".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"testpw".to_vec())]);
        let encrypted = vault.encrypt(b"some data here", &secret).unwrap();

        let body: String = encrypted.lines().skip(1).collect();
        assert!(
            body.chars().all(|c| c.is_ascii_hexdigit()),
            "body must be entirely hex characters"
        );
    }

    // =========================================================================
    // 3. Multi-secret support
    // =========================================================================

    #[test]
    fn test_decrypt_with_multiple_secrets_first_wins() {
        let _secret_a = VaultSecret::new(b"alpha".to_vec());
        let secret_b = VaultSecret::new(b"beta".to_vec());
        let _secret_c = VaultSecret::new(b"gamma".to_vec());

        let vault = VaultLib::new(vec![
            VaultSecret::new(b"alpha".to_vec()),
            VaultSecret::new(b"beta".to_vec()),
            VaultSecret::new(b"gamma".to_vec()),
        ]);

        let encrypted = vault.encrypt(b"multi-secret test", &secret_b).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, b"multi-secret test");
    }

    #[test]
    fn test_decrypt_with_multiple_secrets_last_used() {
        let secret_c = VaultSecret::new(b"gamma".to_vec());

        let vault = VaultLib::new(vec![
            VaultSecret::new(b"alpha".to_vec()),
            VaultSecret::new(b"beta".to_vec()),
            VaultSecret::new(b"gamma".to_vec()),
        ]);

        let encrypted = vault.encrypt(b"last secret", &secret_c).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, b"last secret");
    }

    #[test]
    fn test_decrypt_fails_when_no_secret_matches() {
        let secret_enc = VaultSecret::new(b"correct_password".to_vec());
        let vault_enc = VaultLib::new(vec![VaultSecret::new(b"correct_password".to_vec())]);

        let encrypted = vault_enc.encrypt(b"secret data", &secret_enc).unwrap();

        // Different vault with wrong secrets.
        let vault_dec = VaultLib::new(vec![
            VaultSecret::new(b"wrong1".to_vec()),
            VaultSecret::new(b"wrong2".to_vec()),
        ]);

        let result = vault_dec.decrypt(&encrypted);
        assert!(result.is_err(), "decryption with wrong secrets should fail");
        match result.unwrap_err() {
            VaultError::DecryptionFailed(msg) => {
                assert!(msg.contains("no vault secret"), "unexpected error message: {msg}");
            }
            other => panic!("expected DecryptionFailed, got {other:?}"),
        }
    }

    // =========================================================================
    // 4. HMAC integrity
    // =========================================================================

    #[test]
    fn test_tampered_ciphertext_detected() {
        let secret = VaultSecret::new(b"integrity".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"integrity".to_vec())]);
        let encrypted = vault.encrypt(b"original data", &secret).unwrap();

        // Tamper with a body character (flip one hex digit).
        let mut tampered = encrypted.clone();
        let body_start = tampered.find('\n').unwrap() + 1;
        // Find a hex character to flip.
        let idx = tampered.char_indices()
            .skip_while(|(i, _)| *i <= body_start)
            .find(|(_, c)| *c != 'f')
            .map(|(i, c)| (i, c))
            .unwrap();
        tampered.replace_range(idx.0..idx.0 + 1, "f");

        // Build a vault that has the correct secret but should fail on tampered data.
        let result = vault.decrypt(&tampered);
        assert!(result.is_err(), "tampered ciphertext should fail HMAC check");
    }

    #[test]
    fn test_tampered_salt_detected() {
        let secret = VaultSecret::new(b"integrity".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"integrity".to_vec())]);
        let encrypted = vault.encrypt(b"check salt", &secret).unwrap();

        // Decode the outer hex body, modify the salt, re-encode.
        let body: String = encrypted.lines().skip(1).collect();
        let decoded_body = hex_decode(&body).unwrap();
        let inner = String::from_utf8(decoded_body).unwrap();
        let mut parts: Vec<&str> = inner.split('\n').collect();
        assert_eq!(parts.len(), 3);

        // Tamper with the salt: flip a character.
        let mut salt_hex = parts[0].to_string();
        if salt_hex.starts_with('0') {
            salt_hex.replace_range(0..1, "f");
        } else {
            salt_hex.replace_range(0..1, "0");
        }
        parts[0] = &salt_hex;

        let tampered_inner = parts.join("\n");
        let tampered_hex = hex_encode(tampered_inner.as_bytes());
        let wrapped = wrap_text(&tampered_hex, 80);
        let tampered_vault = format!("$ANSIBLE_VAULT;1.1;AES256\n{wrapped}");

        let result = vault.decrypt(&tampered_vault);
        assert!(result.is_err(), "tampered salt should cause HMAC mismatch");
    }

    #[test]
    fn test_truncated_body_detected() {
        let secret = VaultSecret::new(b"integrity".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"integrity".to_vec())]);
        let encrypted = vault.encrypt(b"truncation test", &secret).unwrap();

        // Remove the last line of the body.
        let mut lines: Vec<&str> = encrypted.lines().collect();
        assert!(lines.len() > 2);
        lines.pop();
        let truncated = lines.join("\n");

        let result = vault.decrypt(&truncated);
        assert!(result.is_err(), "truncated vault text should fail");
    }

    // =========================================================================
    // 5. Vault ID support
    // =========================================================================

    #[test]
    fn test_vault_id_encrypt_decrypt() {
        let secret = VaultSecret::with_vault_id(b"vault_id_pw".to_vec(), "production".to_string());
        let vault = VaultLib::new(vec![VaultSecret::with_vault_id(
            b"vault_id_pw".to_vec(),
            "production".to_string(),
        )]);

        let encrypted = vault.encrypt(b"data with vault id", &secret).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, b"data with vault id");
    }

    #[test]
    fn test_vault_id_mixed_secrets() {
        let secret_with_id = VaultSecret::with_vault_id(b"pw_id".to_vec(), "staging".to_string());
        let secret_without_id = VaultSecret::new(b"pw_plain".to_vec());

        let vault = VaultLib::new(vec![
            VaultSecret::with_vault_id(b"pw_id".to_vec(), "staging".to_string()),
            VaultSecret::new(b"pw_plain".to_vec()),
        ]);

        // Encrypt with the vault-id secret.
        let encrypted = vault.encrypt(b"mixed vault id test", &secret_with_id).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, b"mixed vault id test");

        // Encrypt with the plain secret.
        let encrypted2 = vault.encrypt(b"plain secret test", &secret_without_id).unwrap();
        let decrypted2 = vault.decrypt(&encrypted2).unwrap();
        assert_eq!(decrypted2, b"plain secret test");
    }

    // =========================================================================
    // 6. Various plaintext sizes
    // =========================================================================

    #[test]
    fn test_empty_string_roundtrip() {
        let secret = VaultSecret::new(b"pw".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"pw".to_vec())]);

        let encrypted = vault.encrypt(b"", &secret).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, b"");
    }

    #[test]
    fn test_short_string_roundtrip() {
        let secret = VaultSecret::new(b"pw".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"pw".to_vec())]);

        let plaintext = b"hi";
        let encrypted = vault.encrypt(plaintext, &secret).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, plaintext);
    }

    #[test]
    fn test_exactly_16_bytes_roundtrip() {
        let secret = VaultSecret::new(b"pw".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"pw".to_vec())]);

        let plaintext = b"0123456789abcdef"; // exactly 16 bytes
        assert_eq!(plaintext.len(), 16);
        let encrypted = vault.encrypt(plaintext, &secret).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, plaintext);
    }

    #[test]
    fn test_31_bytes_roundtrip() {
        let secret = VaultSecret::new(b"pw".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"pw".to_vec())]);

        let plaintext = b"0123456789abcdef0123456789abcde"; // 31 bytes
        assert_eq!(plaintext.len(), 31);
        let encrypted = vault.encrypt(plaintext, &secret).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, plaintext);
    }

    #[test]
    fn test_32_bytes_roundtrip() {
        let secret = VaultSecret::new(b"pw".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"pw".to_vec())]);

        let plaintext = b"0123456789abcdef0123456789abcdef"; // 32 bytes
        assert_eq!(plaintext.len(), 32);
        let encrypted = vault.encrypt(plaintext, &secret).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, plaintext);
    }

    #[test]
    fn test_large_payload_10kb_roundtrip() {
        let secret = VaultSecret::new(b"pw".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"pw".to_vec())]);

        let plaintext: Vec<u8> = (0..10240).map(|i| (i % 256) as u8).collect();
        let encrypted = vault.encrypt(&plaintext, &secret).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, plaintext);
    }

    // =========================================================================
    // 7. Special characters in plaintext
    // =========================================================================

    #[test]
    fn test_unicode_plaintext_roundtrip() {
        let secret = VaultSecret::new(b"pw".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"pw".to_vec())]);

        let plaintext = "Hello, world! \u{00e9}\u{00e8}\u{00ea} \u{4f60}\u{597d} \u{1f600}";
        let encrypted = vault.encrypt(plaintext.as_bytes(), &secret).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, plaintext.as_bytes());
        assert_eq!(String::from_utf8(decrypted).unwrap(), plaintext);
    }

    #[test]
    fn test_newlines_in_plaintext_roundtrip() {
        let secret = VaultSecret::new(b"pw".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"pw".to_vec())]);

        let plaintext = b"line one\nline two\r\nline three\r";
        let encrypted = vault.encrypt(plaintext, &secret).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, plaintext);
    }

    #[test]
    fn test_binary_null_bytes_roundtrip() {
        let secret = VaultSecret::new(b"pw".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"pw".to_vec())]);

        let plaintext: Vec<u8> = (0u8..=255).collect();
        let encrypted = vault.encrypt(&plaintext, &secret).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, plaintext);
    }

    #[test]
    fn test_mixed_binary_roundtrip() {
        let secret = VaultSecret::new(b"pw".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"pw".to_vec())]);

        let mut plaintext = Vec::new();
        plaintext.extend_from_slice(b"text before binary: ");
        plaintext.extend_from_slice(&[0x00, 0x01, 0xFF, 0xFE]);
        plaintext.extend_from_slice(b" :text after");
        let encrypted = vault.encrypt(&plaintext, &secret).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, plaintext);
    }

    // =========================================================================
    // 8. Edge cases with passwords
    // =========================================================================

    #[test]
    fn test_very_short_password_roundtrip() {
        let secret = VaultSecret::new(b"a".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"a".to_vec())]);

        let encrypted = vault.encrypt(b"short pw", &secret).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, b"short pw");
    }

    #[test]
    fn test_very_long_password_roundtrip() {
        let long_pw: Vec<u8> = (0..1000).map(|i| b'A' + (i % 26) as u8).collect();
        let secret = VaultSecret::new(long_pw.clone());
        let vault = VaultLib::new(vec![VaultSecret::new(long_pw)]);

        let encrypted = vault.encrypt(b"long pw test", &secret).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, b"long pw test");
    }

    #[test]
    fn test_password_with_special_chars_roundtrip() {
        let pw = b"p@$$w0rd!#%^&*()_+-=[]{}|;':\",./<>?\\".to_vec();
        let secret = VaultSecret::new(pw.clone());
        let vault = VaultLib::new(vec![VaultSecret::new(pw)]);

        let encrypted = vault.encrypt(b"special pw", &secret).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, b"special pw");
    }

    #[test]
    fn test_password_with_unicode_roundtrip() {
        let pw = "\u{00e9}\u{00e8}\u{00ea}\u{4f60}\u{597d}".as_bytes().to_vec();
        let secret = VaultSecret::new(pw.clone());
        let vault = VaultLib::new(vec![VaultSecret::new(pw)]);

        let encrypted = vault.encrypt(b"unicode pw", &secret).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, b"unicode pw");
    }

    #[test]
    fn test_password_with_null_bytes_roundtrip() {
        let pw = b"pass\x00word".to_vec();
        let secret = VaultSecret::new(pw.clone());
        let vault = VaultLib::new(vec![VaultSecret::new(pw)]);

        let encrypted = vault.encrypt(b"null pw", &secret).unwrap();
        let decrypted = vault.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, b"null pw");
    }

    // =========================================================================
    // 9. Vault file format parsing
    // =========================================================================

    #[test]
    fn test_parse_vault_header_valid() {
        let text = "$ANSIBLE_VAULT;1.1;AES256\nbody_data";
        let (cipher, body) = parse_vault_header(text).unwrap();
        assert_eq!(cipher, "AES256");
        assert_eq!(body, "body_data");
    }

    #[test]
    fn test_parse_vault_header_with_leading_whitespace() {
        let text = "  $ANSIBLE_VAULT;1.1;AES256\nbody";
        let (cipher, body) = parse_vault_header(text).unwrap();
        assert_eq!(cipher, "AES256");
        assert_eq!(body, "body");
    }

    #[test]
    fn test_parse_vault_header_with_trailing_whitespace() {
        // parse_vault_header trims the input, so trailing whitespace on the
        // whole string is stripped; however the body itself is preserved up
        // to where the trim leaves it. The function only trims the outer
        // string, so "body\n  " -> body stays "body\n  " and then first_newline
        // splits at the first \n. Let's test without trailing WS on the body
        // since the outer trim removes trailing newlines/spaces.
        let text = "$ANSIBLE_VAULT;1.1;AES256\nbody";
        let (cipher, body) = parse_vault_header(text).unwrap();
        assert_eq!(cipher, "AES256");
        assert_eq!(body, "body");
    }

    #[test]
    fn test_parse_vault_header_missing_newline() {
        let result = parse_vault_header("$ANSIBLE_VAULT;1.1;AES256");
        assert!(result.is_err());
        match result.unwrap_err() {
            VaultError::FormatError(msg) => {
                assert!(msg.contains("no newline"), "unexpected error: {msg}");
            }
            other => panic!("expected FormatError, got {other:?}"),
        }
    }

    #[test]
    fn test_parse_vault_header_wrong_prefix() {
        let result = parse_vault_header("$NOT_ANSIBLE_VAULT;1.1;AES256\nbody");
        assert!(result.is_err());
        match result.unwrap_err() {
            VaultError::FormatError(msg) => {
                assert!(msg.contains("invalid vault header"), "unexpected error: {msg}");
            }
            other => panic!("expected FormatError, got {other:?}"),
        }
    }

    #[test]
    fn test_parse_vault_header_too_few_parts() {
        let result = parse_vault_header("$ANSIBLE_VAULT;1.1\nbody");
        assert!(result.is_err());
    }

    #[test]
    fn test_parse_vault_header_different_cipher() {
        let text = "$ANSIBLE_VAULT;1.1;AES128\nbody";
        let (cipher, body) = parse_vault_header(text).unwrap();
        assert_eq!(cipher, "AES128");
        assert_eq!(body, "body");
    }

    #[test]
    fn test_parse_vault_header_extra_parts() {
        // Header with extra semicolon-separated parts (e.g. vault id).
        let text = "$ANSIBLE_VAULT;1.1;AES256;my_vault_id\nbody";
        let (cipher, body) = parse_vault_header(text).unwrap();
        assert_eq!(cipher, "AES256");
        assert_eq!(body, "body");
    }

    #[test]
    fn test_parse_vault_header_empty_body() {
        // After trimming, "$ANSIBLE_VAULT;1.1;AES256\n" becomes
        // "$ANSIBLE_VAULT;1.1;AES256" with no newline -- which fails.
        // To get an empty body we need a non-whitespace char after the newline.
        // Actually the simplest approach: the implementation requires a newline,
        // and after trim a trailing newline is stripped. So an empty body
        // is not representable. Test that this returns an error instead.
        let text = "$ANSIBLE_VAULT;1.1;AES256\n";
        let result = parse_vault_header(text);
        // Trimming removes trailing newline, so this fails with "no newline".
        assert!(result.is_err(), "trailing-newline-only body should fail after trim");
    }

    #[test]
    fn test_decrypt_invalid_format_wrong_part_count() {
        let vault = VaultLib::new(vec![VaultSecret::new(b"pw".to_vec())]);

        // Craft a vault file whose inner payload has only 2 parts instead of 3.
        let inner = "aa\nbb";
        let hex_inner = hex_encode(inner.as_bytes());
        let wrapped = wrap_text(&hex_inner, 80);
        let vault_text = format!("$ANSIBLE_VAULT;1.1;AES256\n{wrapped}");

        let result = vault.decrypt(&vault_text);
        assert!(result.is_err());
        match result.unwrap_err() {
            VaultError::FormatError(msg) => {
                assert!(msg.contains("expected 3 parts"), "unexpected error: {msg}");
            }
            other => panic!("expected FormatError, got {other:?}"),
        }
    }

    // =========================================================================
    // 10. PKCS7 padding edge cases
    // =========================================================================

    #[test]
    fn test_pkcs7_pad_empty_data() {
        let padded = pkcs7_pad(b"", 16);
        assert_eq!(padded.len(), 16, "empty data should get a full block of padding");
        assert!(padded.iter().all(|&b| b == 16), "padding bytes should all be 16");
    }

    #[test]
    fn test_pkcs7_unpad_empty_data_errors() {
        let result = pkcs7_unpad(b"");
        assert!(result.is_err(), "unpadding empty data should error");
    }

    #[test]
    fn test_pkcs7_pad_exactly_one_block() {
        let data = [0u8; 16];
        let padded = pkcs7_pad(&data, 16);
        assert_eq!(padded.len(), 32, "block-aligned data should get one extra block of padding");
        // Last 16 bytes should all be 0x10 (16).
        assert!(padded[16..].iter().all(|&b| b == 16));
    }

    #[test]
    fn test_pkcs7_unpad_full_padding_block() {
        let data = [0u8; 16];
        let padded = pkcs7_pad(&data, 16);
        let unpadded = pkcs7_unpad(&padded).unwrap();
        assert_eq!(unpadded, data);
    }

    #[test]
    fn test_pkcs7_pad_one_byte_short() {
        // 15 bytes is one byte short of a full block, so it gets 1 byte of padding (0x01).
        let data = [0u8; 15];
        let padded = pkcs7_pad(&data, 16);
        assert_eq!(padded.len(), 16);
        assert_eq!(padded[15], 1);
    }

    #[test]
    fn test_pkcs7_unpad_invalid_zero_padding() {
        let mut data = vec![0u8; 16];
        data[15] = 0; // zero padding byte is invalid
        let result = pkcs7_unpad(&data);
        assert!(result.is_err(), "zero padding byte should be rejected");
    }

    #[test]
    fn test_pkcs7_unpad_padding_exceeds_data() {
        let mut data = vec![0u8; 4];
        data[3] = 17; // padding value exceeds block size
        let result = pkcs7_unpad(&data);
        assert!(result.is_err(), "padding exceeding block size should be rejected");
    }

    #[test]
    fn test_pkcs7_unpad_inconsistent_padding_bytes() {
        // Create data where the last byte says pad_len=3, but not all 3
        // trailing bytes are 3.
        let mut data = vec![0u8; 16];
        data[13] = 3;
        data[14] = 3;
        data[15] = 3;
        // Now corrupt one of the padding bytes:
        data[14] = 7;
        let result = pkcs7_unpad(&data);
        assert!(result.is_err(), "inconsistent padding bytes should be rejected");
    }

    // =========================================================================
    // Additional helper tests
    // =========================================================================

    #[test]
    fn test_hex_encode_decode_roundtrip() {
        for len in [0, 1, 15, 16, 31, 32, 100] {
            let data: Vec<u8> = (0..len).map(|i| (i % 256) as u8).collect();
            let hex = hex_encode(&data);
            let decoded = hex_decode(&hex).unwrap();
            assert_eq!(decoded, data, "roundtrip failed for len={len}");
        }
    }

    #[test]
    fn test_hex_decode_odd_length_errors() {
        let result = hex_decode("abc");
        assert!(result.is_err());
    }

    #[test]
    fn test_hex_decode_invalid_chars_errors() {
        let result = hex_decode("zz");
        assert!(result.is_err());
    }

    #[test]
    fn test_wrap_text_basic() {
        let text = "abcdefghij";
        let wrapped = wrap_text(text, 4);
        assert_eq!(wrapped, "abcd\nefgh\nij");
    }

    #[test]
    fn test_wrap_text_exact_multiple() {
        let text = "abcdefgh";
        let wrapped = wrap_text(text, 4);
        assert_eq!(wrapped, "abcd\nefgh");
    }

    #[test]
    fn test_wrap_text_shorter_than_width() {
        let text = "abc";
        let wrapped = wrap_text(text, 10);
        assert_eq!(wrapped, "abc");
    }

    #[test]
    fn test_decrypt_str_returns_valid_utf8() {
        let secret = VaultSecret::new(b"pw".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"pw".to_vec())]);

        let plaintext = "Hello, UTF-8 world!";
        let encrypted = vault.encrypt(plaintext.as_bytes(), &secret).unwrap();
        let decrypted_str = vault.decrypt_str(&encrypted).unwrap();
        assert_eq!(decrypted_str, plaintext);
    }

    #[test]
    fn test_decrypt_str_rejects_invalid_utf8() {
        let secret = VaultSecret::new(b"pw".to_vec());
        let vault = VaultLib::new(vec![VaultSecret::new(b"pw".to_vec())]);

        // Encrypt invalid UTF-8 bytes.
        let plaintext: Vec<u8> = vec![0xFF, 0xFE, 0xFD];
        let encrypted = vault.encrypt(&plaintext, &secret).unwrap();
        let result = vault.decrypt_str(&encrypted);
        assert!(result.is_err(), "decrypt_str should fail on invalid UTF-8");
    }

    #[test]
    fn test_vault_secret_accessors() {
        let secret = VaultSecret::with_vault_id(b"mypass".to_vec(), "dev".to_string());
        assert_eq!(secret.bytes(), b"mypass");
        assert_eq!(secret.vault_id(), Some("dev"));
    }

    #[test]
    fn test_vault_secret_no_vault_id() {
        let secret = VaultSecret::new(b"mypass".to_vec());
        assert_eq!(secret.bytes(), b"mypass");
        assert_eq!(secret.vault_id(), None);
    }

    #[test]
    fn test_derive_keys_deterministic() {
        let password = b"test_password";
        let salt = b"0123456789abcdef0123456789abcdef";

        let (aes1, hmac1, iv1) = derive_keys(password, salt).unwrap();
        let (aes2, hmac2, iv2) = derive_keys(password, salt).unwrap();

        assert_eq!(aes1, aes2, "AES key should be deterministic for same inputs");
        assert_eq!(hmac1, hmac2, "HMAC key should be deterministic for same inputs");
        assert_eq!(iv1, iv2, "IV should be deterministic for same inputs");
    }

    #[test]
    fn test_derive_keys_different_salts() {
        let password = b"test_password";
        let salt1 = b"0123456789abcdef0123456789abcdef";
        let salt2 = b"fedcba9876543210fedcba9876543210";

        let (aes1, _, _) = derive_keys(password, salt1).unwrap();
        let (aes2, _, _) = derive_keys(password, salt2).unwrap();

        assert_ne!(aes1, aes2, "different salts should produce different keys");
    }

    #[test]
    fn test_derive_keys_different_passwords() {
        let salt = b"0123456789abcdef0123456789abcdef";

        let (aes1, _, _) = derive_keys(b"password_a", salt).unwrap();
        let (aes2, _, _) = derive_keys(b"password_b", salt).unwrap();

        assert_ne!(aes1, aes2, "different passwords should produce different keys");
    }

    #[test]
    fn test_derive_keys_output_lengths() {
        let (aes_key, hmac_key, iv) = derive_keys(b"pw", b"salt1234salt1234").unwrap();
        assert_eq!(aes_key.len(), KEY_LENGTH, "AES key should be 32 bytes");
        assert_eq!(hmac_key.len(), HMAC_LENGTH, "HMAC key should be 32 bytes");
        assert_eq!(iv.len(), IV_LENGTH, "IV should be 16 bytes");
    }

    #[test]
    fn test_increment_counter_basic() {
        let mut counter = [0u8; 16];
        increment_counter(&mut counter);
        assert_eq!(counter[15], 1);
        assert_eq!(counter[0..15], [0u8; 15]);
    }

    #[test]
    fn test_increment_counter_overflow() {
        let mut counter = [0u8; 16];
        counter[15] = 0xFF;
        increment_counter(&mut counter);
        assert_eq!(counter[15], 0);
        assert_eq!(counter[14], 1);
    }

    #[test]
    fn test_increment_counter_full_overflow() {
        let mut counter = [0xFFu8; 16];
        increment_counter(&mut counter);
        // All bytes should roll over to 0.
        assert_eq!(counter, [0u8; 16]);
    }

    // =========================================================================
    // Cross-validation: encrypt with one VaultLib, decrypt with another
    // =========================================================================

    #[test]
    fn test_cross_vault_instance_decrypt() {
        let pw = b"shared_secret".to_vec();
        let secret = VaultSecret::new(pw.clone());

        let vault_enc = VaultLib::new(vec![VaultSecret::new(pw.clone())]);
        let encrypted = vault_enc.encrypt(b"cross-instance", &secret).unwrap();

        // A completely separate VaultLib instance with the same secret.
        let vault_dec = VaultLib::new(vec![VaultSecret::new(pw)]);
        let decrypted = vault_dec.decrypt(&encrypted).unwrap();
        assert_eq!(decrypted, b"cross-instance");
    }

    // =========================================================================
    // Cross-implementation parity: vectors generated by Python ansible-vault
    // (ansible-core 2.20.4). These verify that our Rust implementation can
    // decrypt content encrypted by the reference Python implementation.
    // =========================================================================

    #[test]
    fn test_python_parity_simple_string() {
        let vault = VaultLib::new(vec![VaultSecret::new(b"testpass".to_vec())]);
        let decrypted = vault.decrypt_str(r#"$ANSIBLE_VAULT;1.1;AES256
31393564636563313734333439383137316330326464336365663365353061346538326166663662
6134613865613936303733636631353836643231323961360a636635316333656336306331636236
37393539376430356531653165636637363035643834346639393166346562303232646534616636
6130383232373337640a373261326662393938653063353365623234346136656463363364383739
3064
"#).unwrap();
        assert_eq!(decrypted, "Hello, World!");
    }

    #[test]
    fn test_python_parity_empty_string() {
        let vault = VaultLib::new(vec![VaultSecret::new(b"testpass".to_vec())]);
        let decrypted = vault.decrypt_str(r#"$ANSIBLE_VAULT;1.1;AES256
63336636316337636663306265656161363435336539346232373166316637353865373131363932
3865313064666463656239333266656261356566663631640a383637323635623263636636633630
66636234613038396438386238353266653633333336323665623831383031326439306265316138
3336336466623636650a613234326563626239616139343838643766333162303662623130663037
3937
"#).unwrap();
        assert_eq!(decrypted, "");
    }

    #[test]
    fn test_python_parity_binary_null_tab() {
        let vault = VaultLib::new(vec![VaultSecret::new(b"testpass".to_vec())]);
        let decrypted = vault.decrypt(r#"$ANSIBLE_VAULT;1.1;AES256
32353462636533323064353630343332633765343834663333643262646130613533663439626530
3563613236623362633538306635303731396366393131350a366437363134306262653532353837
32326635623230333533386531616437616232303665393033363130643364613635636466353264
6661353338646634380a656562303365666365613336366365323133623964643363313835653735
35356431616366623163303632656135386234346531386631343539396637396563
"#).unwrap();
        assert_eq!(decrypted, b"null\x00byte\ntabs\there");
    }

    #[test]
    fn test_python_parity_unicode() {
        let vault = VaultLib::new(vec![VaultSecret::new(b"unicode_pw".to_vec())]);
        let decrypted = vault.decrypt_str(r#"$ANSIBLE_VAULT;1.1;AES256
65306264363034613861366162656537633036386230663535643766373462363062663562393835
3865663838623363383331336633613666353263323764380a643630643131356630666136313463
64303734636435653230336530356665313465336330393138326639663366626365336630373333
3632313662353331610a343835613861303830363563333334383330376165613863386462623330
65303462633134326631303435623736323961346234353331306230633061353964
"#).unwrap();
        assert_eq!(decrypted, "こんにちは世界 🌍");
    }

    #[test]
    fn test_python_parity_exact_16_bytes() {
        let vault = VaultLib::new(vec![VaultSecret::new(b"testpass".to_vec())]);
        let decrypted = vault.decrypt(r#"$ANSIBLE_VAULT;1.1;AES256
64333932623030643065616330646437643563333264316635326337613636616366336338383537
3664626434356534303632333131353365353030643534330a303135393238353362336365373963
65633861393861666433303831666561386435663563633530666666303537346466656230373835
6164643131633337610a333939333834306231616439656364643036643835396563376261323664
62353932306666666164373931643930663261663636663034643232643439613139
"#).unwrap();
        assert_eq!(decrypted, b"0123456789abcdef");
    }

    #[test]
    fn test_python_parity_exact_32_bytes() {
        let vault = VaultLib::new(vec![VaultSecret::new(b"testpass".to_vec())]);
        let decrypted = vault.decrypt(r#"$ANSIBLE_VAULT;1.1;AES256
35373837383931363265356234653735396135383138393938306364663637373133353137316266
6364303936666238386334363338636337643738663530380a303632656564376664373031396536
36393333373131346264323631306137366465363262396536633437326364623435383263633661
6231663762656263390a313830636265636164363362336461643231393863373966393665303431
61303066393638366638336165323832303461313264306166313330333861363965653831343064
6137626263393166323135323437393665386330383830376166
"#).unwrap();
        assert_eq!(decrypted, b"0123456789abcdef0123456789abcdef");
    }

    #[test]
    fn test_python_parity_large_1kb() {
        let vault = VaultLib::new(vec![VaultSecret::new(b"testpass".to_vec())]);
        let decrypted = vault.decrypt(r#"$ANSIBLE_VAULT;1.1;AES256
37316462646237333730336536623035633932313362636466383661653463363865326363323731
6335373137363764646339633264613039326265623265650a326162306365373831366237306233
62313861353239363665623531363039653462663538656461633136316662383664666334623032
6335316332353436300a326337353263383966666261326532326531333937613237663332653631
33353261643030653238613664613164343639363239323839623266306235353636663937336466
38363237346263313830326131613834636535393866633439646665316561313164303865623839
63373234613938346234393333363734316263326462306164396534616363653563303966323066
36623136613639656663366336633764613532376164333735316137343835313332623436653561
33356235656337646165336634333132383630313030653235373236303664376432386531363434
34643236623233653135323163316566646538663234376637663433366333313565636562633932
30386430386230623839663438303232343332356438373331626666653436386133643532396234
64303133616666653536333335306464656232353534633465623636376337343262373633306339
31323132366539386138646266326331353335653935373138356335333666306464623564663961
30336161396237366331373935376361663035366430643533333737306432643834383030383138
37363136386235656231313166396632353965343837636635653933623630393934323438346363
65323330336662633639303237346633633662646165383533643733366137353030346339643432
64663938653933303561336130393366653861616466313530653836643562643563646335623062
39343839636636656561336261313265363239633332316432616335643839663431333036363061
34383838323064356566666334343062323363396233313634346466366162386236393738356461
65323361643361336439646633383835343436613461313966393139326430306365646538623561
36616232393335343439663939316265386266653761383132376139626464313863643964393130
39636535326531323065623562356366313462333161366662613031343361303737383263373138
61653138663737363534633932323736636338636363343730306531383864666365316638373161
33646364336366316236653132373937613134386664616636306233373261396132663262613430
32333665616361393564333764323939663137363133633933386666323734343630663832333261
31333265346432666538653739386663306235346462333266666432386338363030343631313235
30376431663663633035373366306238643266613339623261356664396131323638393163616433
66626361633665323164396533616434623136363761303666306465313564633839623132326631
63383863626237386431373434663565323035323037393564616234376665363933636530383238
65313335613235383362613838373438306364376230383061306235373031363632323932386534
33366366633166396561316666626237366263643731376561633662633461373634336165653761
62333466363533346230353339653138313631366663383433643839323934346130383132303032
34363838303233366665353962353433666461323139626634306330386165616337343963666365
31623364353137383933613736313932373565363238623037663133616665333139653635663333
66303532666238653962613666646361636561313436333930386166656463323964353633326161
66333966356335316331656639323333383565333964393437366332353536666163366434363364
64316532613134656565303066326235343966313365646533386236373964393561306139313032
32343862623363626235666661353864313162666364616639626661316166666537663038646233
37626636636232376265303261313266366162663532646466373065333832323130303330653165
65623731616265346530643665653536613533626635636533313362336238356239336564333936
61626331303435623763643065383934653762633239373539353461336437626462653531623534
31643764656464343032373861346361666237333836323365363536316661643164643631346563
65663038363461666433386239653262336532343066626363346634383735656132346433636262
36383033333861623739633535356466343165313865333262366639313437373236373862396163
34356633653136373537616434303065623564666164326533383163656462623261376566393635
62303361613538396234336161663738323334643065333439653135303032343564656433313734
36666230343834393933633139633536303232626563663035343865626635313035386164383063
37646335633537623061333532373938633638613034346634313138383866663464303664633462
62306235623862356264383333616334383835646263643466633239623165656264386539613563
64626134616363323963383463353737626163653637643561316565356638666134393238663438
30373434303863303738616265663233356331653961633339613335643637356334376636336135
63643531316639323536303464366165316366663539363832623130623038313039316661316663
66363763306432653361366330343037313436383037623133383737643035663331383761343938
3663623530363734656364373835376535343937376538663465
"#).unwrap();
        assert_eq!(decrypted, vec![b'A'; 1000]);
    }
}
