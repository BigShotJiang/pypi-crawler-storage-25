use std::path::PathBuf;

use serde::{Deserialize, Serialize};

/// The complete Ansible configuration, mirroring sections in ansible.cfg.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[derive(Default)]
pub struct AnsibleConfig {
    /// Path the config was loaded from, if any.
    #[serde(skip)]
    pub config_file: Option<PathBuf>,
    #[serde(default)]
    pub defaults: DefaultsConfig,
    #[serde(default)]
    pub privilege_escalation: BecomeConfig,
    #[serde(default)]
    pub connection: ConnectionConfig,
    #[serde(default)]
    pub colors: ColorsConfig,
    #[serde(default)]
    pub ssh_connection: SshConnectionConfig,
}


/// [defaults] section of ansible.cfg.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct DefaultsConfig {
    /// Path to the inventory file or directory.
    pub inventory: String,
    /// The remote user to login as.
    pub remote_user: String,
    /// Number of parallel processes to use.
    pub forks: usize,
    /// Default module to use with `ansible` ad-hoc command.
    pub module_name: String,
    /// Ask for vault password.
    pub ask_vault_pass: bool,
    /// Ask for connection password.
    pub ask_pass: bool,
    /// Default transport.
    pub transport: String,
    /// Path to roles.
    pub roles_path: Vec<PathBuf>,
    /// Output verbosity.
    pub verbosity: u8,
    /// Enable/disable cowsay.
    pub nocows: bool,
    /// Retry files save path.
    pub retry_files_enabled: bool,
    pub retry_files_save_path: Option<PathBuf>,
    /// Whether to check host keys.
    pub host_key_checking: bool,
    /// Vault password file path.
    pub vault_password_file: Option<PathBuf>,
    /// Timeout for connections.
    pub timeout: u32,
    /// Gathering facts behavior.
    pub gathering: GatheringMode,
    /// Callback stdout plugin.
    pub stdout_callback: String,
    /// Enable/disable fact caching.
    pub fact_caching: String,
    pub fact_caching_timeout: u32,
    pub fact_caching_connection: Option<String>,
    /// Collections paths.
    pub collections_paths: Vec<PathBuf>,
    /// Enable pipelining.
    pub pipelining: bool,
}

impl Default for DefaultsConfig {
    fn default() -> Self {
        Self {
            inventory: "/etc/ansible/hosts".to_string(),
            remote_user: "root".to_string(),
            forks: 5,
            module_name: "command".to_string(),
            ask_vault_pass: false,
            ask_pass: false,
            transport: "ssh".to_string(),
            roles_path: vec![PathBuf::from("/etc/ansible/roles")],
            verbosity: 0,
            nocows: false,
            retry_files_enabled: true,
            retry_files_save_path: None,
            host_key_checking: true,
            vault_password_file: None,
            timeout: 10,
            gathering: GatheringMode::Implicit,
            stdout_callback: "default".to_string(),
            fact_caching: "memory".to_string(),
            fact_caching_timeout: 86400,
            fact_caching_connection: None,
            collections_paths: vec![
                PathBuf::from("~/.ansible/collections"),
                PathBuf::from("/usr/share/ansible/collections"),
            ],
            pipelining: true,
        }
    }
}

/// Fact gathering behavior.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(rename_all = "lowercase")]
pub enum GatheringMode {
    /// Gather facts by default, skip if cached.
    Implicit,
    /// Always gather facts.
    Explicit,
    /// Gather facts, using cache when available.
    Smart,
}

/// [privilege_escalation] section.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct BecomeConfig {
    pub use_become: bool,
    pub become_method: String,
    pub become_user: String,
    pub become_ask_pass: bool,
}

impl Default for BecomeConfig {
    fn default() -> Self {
        Self {
            use_become: false,
            become_method: "sudo".to_string(),
            become_user: "root".to_string(),
            become_ask_pass: false,
        }
    }
}

/// [connection] section.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct ConnectionConfig {
    pub pipelining: bool,
    pub control_path_dir: PathBuf,
}

impl Default for ConnectionConfig {
    fn default() -> Self {
        Self {
            pipelining: true,
            control_path_dir: PathBuf::from("~/.ansible/cp"),
        }
    }
}

/// [ssh_connection] section.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct SshConnectionConfig {
    pub ssh_args: String,
    pub scp_if_ssh: bool,
    pub control_path: Option<String>,
    pub retries: u32,
}

impl Default for SshConnectionConfig {
    fn default() -> Self {
        Self {
            ssh_args: "-C -o ControlMaster=auto -o ControlPersist=60s".to_string(),
            scp_if_ssh: false,
            control_path: None,
            retries: 0,
        }
    }
}

/// [colors] section.
#[derive(Debug, Clone, Default, Serialize, Deserialize)]
pub struct ColorsConfig {
    pub highlight: Option<String>,
    pub verbose: Option<String>,
    pub warn: Option<String>,
    pub error: Option<String>,
    pub debug: Option<String>,
    pub ok: Option<String>,
    pub changed: Option<String>,
    pub skip: Option<String>,
    pub unreachable: Option<String>,
}
