use thiserror::Error;

#[derive(Debug, Error)]
pub enum ConfigError {
    #[error("config parse error: {0}")]
    ParseError(String),

    #[error("invalid config value for {key}: {reason}")]
    InvalidValue { key: String, reason: String },

    #[error("config file not found: {0}")]
    FileNotFound(String),

    #[error(transparent)]
    Io(#[from] std::io::Error),

    #[error(transparent)]
    Yaml(#[from] serde_yaml::Error),
}
