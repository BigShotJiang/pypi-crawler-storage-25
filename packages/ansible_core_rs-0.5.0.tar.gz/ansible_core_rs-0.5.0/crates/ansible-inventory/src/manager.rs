use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;

use ansible_utils::{AnsibleValue, Group, Host, InventoryData};

use crate::InventoryError;

/// Manages inventory sources and provides a unified view of hosts and groups.
pub struct InventoryManager {
    sources: Vec<PathBuf>,
    data: InventoryData,
}

impl InventoryManager {
    pub fn new() -> Self {
        let mut data = InventoryData::new();
        // "all" and "ungrouped" always exist
        data.add_group(Group::new("all"));
        data.add_group(Group::new("ungrouped"));
        data.add_child_group("all", "ungrouped");

        Self {
            sources: Vec::new(),
            data,
        }
    }

    /// Add an inventory source file or directory.
    pub fn add_source(&mut self, path: PathBuf) {
        self.sources.push(path);
    }

    /// Parse all configured inventory sources.
    pub fn parse_sources(&mut self) -> Result<(), InventoryError> {
        for source in &self.sources.clone() {
            self.parse_source(source)?;
        }
        Ok(())
    }

    fn parse_source(&mut self, path: &Path) -> Result<(), InventoryError> {
        if path.is_dir() {
            self.parse_directory(path)?;
        } else {
            self.parse_file(path)?;
        }
        Ok(())
    }

    fn parse_directory(&mut self, path: &Path) -> Result<(), InventoryError> {
        let mut entries: Vec<_> = std::fs::read_dir(path)
            .map_err(|e| InventoryError::InvalidSource(e.to_string()))?
            .filter_map(|e| e.ok())
            .filter(|e| {
                let name = e.file_name();
                let name = name.to_string_lossy();
                !name.starts_with('.') && !name.ends_with('~')
            })
            .collect();
        entries.sort_by_key(|e| e.file_name());

        for entry in entries {
            self.parse_source(&entry.path())?;
        }
        Ok(())
    }

    fn parse_file(&mut self, path: &Path) -> Result<(), InventoryError> {
        // Executable files are treated as script (dynamic) inventory sources
        if crate::parser::script::is_script_inventory(path) {
            return crate::parser::script::parse_script_inventory(path, &mut self.data);
        }

        let ext = path.extension().and_then(|e| e.to_str());
        match ext {
            Some("yml" | "yaml") => crate::parser::yaml::parse_yaml_inventory(path, &mut self.data),
            _ => crate::parser::ini::parse_ini_inventory(path, &mut self.data),
        }
    }

    /// Get a host by name.
    pub fn get_host(&self, name: &str) -> Option<&Host> {
        self.data.get_host(name)
    }

    /// Get a group by name.
    pub fn get_group(&self, name: &str) -> Option<&Group> {
        self.data.get_group(name)
    }

    /// Get all hosts.
    pub fn hosts(&self) -> &HashMap<Arc<str>, Host> {
        &self.data.hosts
    }

    /// Get all groups.
    pub fn groups(&self) -> &HashMap<Arc<str>, Group> {
        &self.data.groups
    }

    /// Get the merged variables for a host (host vars + group vars).
    pub fn get_host_vars(&self, host_name: &str) -> HashMap<String, AnsibleValue> {
        self.data.get_host_vars(host_name)
    }

    /// Get a reference to the underlying inventory data.
    pub fn data(&self) -> &InventoryData {
        &self.data
    }

    /// Mutable access to the underlying inventory data. Useful for tests
    /// and callers that build an inventory programmatically instead of
    /// parsing it from a file.
    pub fn data_mut(&mut self) -> &mut InventoryData {
        &mut self.data
    }
}

impl Default for InventoryManager {
    fn default() -> Self {
        Self::new()
    }
}
