use std::path::Path;

use ansible_utils::{Group, Host, InventoryData};

use crate::InventoryError;

/// Parse an INI-format inventory file (the classic `/etc/ansible/hosts` format).
///
/// Format:
/// ```text
/// [webservers]
/// web1.example.com
/// web2.example.com ansible_port=2222
///
/// [dbservers]
/// db1.example.com
///
/// [webservers:vars]
/// http_port=80
///
/// [all:children]
/// webservers
/// dbservers
/// ```
pub fn parse_ini_inventory(path: &Path, data: &mut InventoryData) -> Result<(), InventoryError> {
    let content =
        ansible_parsing::read_file_efficient(path).map_err(|e| InventoryError::ParseError(e.to_string()))?;

    let mut current_group = "ungrouped".to_string();
    let mut current_section = SectionType::Hosts;

    for line in content.lines() {
        let line = line.trim();

        // Skip empty lines and comments
        if line.is_empty() || line.starts_with('#') || line.starts_with(';') {
            continue;
        }

        // Group header: [groupname] or [groupname:vars] or [groupname:children]
        if line.starts_with('[') && line.ends_with(']') {
            let header = &line[1..line.len() - 1];
            if let Some((group, section)) = header.rsplit_once(':') {
                current_group = group.to_string();
                current_section = match section {
                    "vars" => SectionType::Vars,
                    "children" => SectionType::Children,
                    _ => SectionType::Hosts,
                };
            } else {
                current_group = header.to_string();
                current_section = SectionType::Hosts;
            }

            // Ensure group exists
            if data.get_group(&current_group).is_none() {
                data.add_group(Group::new(current_group.clone()));
                data.add_child_group("all", &current_group);
            }
            continue;
        }

        match current_section {
            SectionType::Hosts => {
                parse_host_line(line, &current_group, data)?;
            }
            SectionType::Vars => {
                parse_var_line(line, &current_group, data)?;
            }
            SectionType::Children => {
                let child_group = line.trim();
                if data.get_group(child_group).is_none() {
                    data.add_group(Group::new(child_group.to_string()));
                    data.add_child_group("all", child_group);
                }
                data.add_child_group(&current_group, child_group);
            }
        }
    }

    Ok(())
}

#[derive(Debug)]
enum SectionType {
    Hosts,
    Vars,
    Children,
}

fn parse_host_line(
    line: &str,
    group: &str,
    data: &mut InventoryData,
) -> Result<(), InventoryError> {
    let parts: Vec<&str> = line.splitn(2, ' ').collect();
    let hostname = parts[0].trim();

    // Create host if it doesn't exist
    if data.get_host(hostname).is_none() {
        data.add_host(Host::new(hostname.to_string()));
    }

    // Parse inline host variables: key=value key2="value with spaces"
    if parts.len() > 1 {
        for (key, value) in parse_kv_pairs(parts[1]) {
            let value = parse_ini_value(&value);
            data.set_host_var(hostname, &key, value);
        }
    }

    // Add host to group
    data.add_host_to_group(hostname, group);

    Ok(())
}

/// Parse key=value pairs that may contain quoted values with spaces.
fn parse_kv_pairs(input: &str) -> Vec<(String, String)> {
    let mut pairs = Vec::new();
    let mut chars = input.chars().peekable();

    while chars.peek().is_some() {
        // Skip whitespace
        while chars.peek() == Some(&' ') || chars.peek() == Some(&'\t') {
            chars.next();
        }

        if chars.peek().is_none() {
            break;
        }

        // Read key
        let mut key = String::new();
        while let Some(&c) = chars.peek() {
            if c == '=' {
                chars.next(); // consume '='
                break;
            }
            if c == ' ' || c == '\t' {
                break;
            }
            key.push(c);
            chars.next();
        }

        if key.is_empty() {
            break;
        }

        // Read value (may be quoted)
        let mut value = String::new();
        if let Some(&quote @ ('"' | '\'')) = chars.peek() {
            chars.next(); // consume opening quote
            while let Some(&c) = chars.peek() {
                if c == quote {
                    chars.next(); // consume closing quote
                    break;
                }
                value.push(c);
                chars.next();
            }
        } else {
            while let Some(&c) = chars.peek() {
                if c == ' ' || c == '\t' {
                    break;
                }
                value.push(c);
                chars.next();
            }
        }

        pairs.push((key, value));
    }

    pairs
}

fn parse_var_line(
    line: &str,
    group: &str,
    data: &mut InventoryData,
) -> Result<(), InventoryError> {
    if let Some((key, value)) = line.split_once('=') {
        let key = key.trim();
        let value = parse_ini_value(value.trim());
        data.set_group_var(group, key, value);
    }
    Ok(())
}

/// Parse an INI value, attempting to convert to appropriate JSON types.
fn parse_ini_value(value: &str) -> serde_json::Value {
    // Try boolean
    match value.to_lowercase().as_str() {
        "true" | "yes" => return serde_json::Value::Bool(true),
        "false" | "no" => return serde_json::Value::Bool(false),
        _ => {}
    }

    // Try integer
    if let Ok(n) = value.parse::<i64>() {
        return serde_json::Value::Number(n.into());
    }

    // Try float
    if let Ok(n) = value.parse::<f64>() {
        if let Some(n) = serde_json::Number::from_f64(n) {
            return serde_json::Value::Number(n);
        }
    }

    // String (strip surrounding quotes if present)
    let value = if (value.starts_with('"') && value.ends_with('"'))
        || (value.starts_with('\'') && value.ends_with('\''))
    {
        &value[1..value.len() - 1]
    } else {
        value
    };

    serde_json::Value::String(value.to_string())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn parse_ini_str(content: &str) -> InventoryData {
        let mut tmp = tempfile::NamedTempFile::new().unwrap();
        write!(tmp, "{content}").unwrap();
        let mut data = InventoryData::new();
        data.add_group(Group::new("all".to_string()));
        data.add_group(Group::new("ungrouped".to_string()));
        data.add_child_group("all", "ungrouped");
        parse_ini_inventory(tmp.path(), &mut data).unwrap();
        data
    }

    #[test]
    fn test_simple_host_list() {
        let data = parse_ini_str("web1.example.com\nweb2.example.com\n");
        assert!(data.get_host("web1.example.com").is_some());
        assert!(data.get_host("web2.example.com").is_some());
    }

    #[test]
    fn test_host_with_vars() {
        let data = parse_ini_str("web1.example.com ansible_port=2222 ansible_host=10.0.0.1\n");
        let host = data.get_host("web1.example.com").unwrap();
        assert_eq!(host.vars.get("ansible_port").unwrap(), &serde_json::json!(2222));
        assert_eq!(
            host.vars.get("ansible_host").unwrap(),
            &serde_json::json!("10.0.0.1")
        );
    }

    #[test]
    fn test_groups() {
        let data = parse_ini_str(
            "[webservers]\nweb1.example.com\nweb2.example.com\n\n[dbservers]\ndb1.example.com\n",
        );
        let ws = data.get_group("webservers").unwrap();
        assert_eq!(ws.hosts.len(), 2);
        assert!(ws.has_host("web1.example.com"));

        let db = data.get_group("dbservers").unwrap();
        assert_eq!(db.hosts.len(), 1);
    }

    #[test]
    fn test_group_vars_section() {
        let data =
            parse_ini_str("[webservers]\nweb1.example.com\n\n[webservers:vars]\nhttp_port=80\n");
        let ws = data.get_group("webservers").unwrap();
        assert_eq!(ws.vars.get("http_port").unwrap(), &serde_json::json!(80));
    }

    #[test]
    fn test_children_groups() {
        let data = parse_ini_str(
            "[webservers]\nweb1.example.com\n\n[dbservers]\ndb1.example.com\n\n[production:children]\nwebservers\ndbservers\n",
        );
        let prod = data.get_group("production").unwrap();
        assert!(prod.has_child("webservers"));
        assert!(prod.has_child("dbservers"));
    }

    #[test]
    fn test_comments_and_blank_lines() {
        let data = parse_ini_str(
            "# This is a comment\n; Another comment\n\nweb1.example.com\n\n# more comments\n",
        );
        assert_eq!(data.hosts.len(), 1);
        assert!(data.get_host("web1.example.com").is_some());
    }

    #[test]
    fn test_boolean_vars() {
        let data = parse_ini_str("host1 flag_yes=yes flag_true=true flag_no=no flag_false=false\n");
        let host = data.get_host("host1").unwrap();
        assert_eq!(host.vars.get("flag_yes").unwrap(), &serde_json::json!(true));
        assert_eq!(host.vars.get("flag_true").unwrap(), &serde_json::json!(true));
        assert_eq!(host.vars.get("flag_no").unwrap(), &serde_json::json!(false));
        assert_eq!(host.vars.get("flag_false").unwrap(), &serde_json::json!(false));
    }

    #[test]
    fn test_quoted_string_vars() {
        let data = parse_ini_str("host1 msg=\"hello world\" path='/opt/app'\n");
        let host = data.get_host("host1").unwrap();
        assert_eq!(
            host.vars.get("msg").unwrap(),
            &serde_json::json!("hello world")
        );
        assert_eq!(
            host.vars.get("path").unwrap(),
            &serde_json::json!("/opt/app")
        );
    }

    #[test]
    fn test_host_group_vars_merge() {
        let data = parse_ini_str(
            "[webservers]\nweb1.example.com ansible_port=2222\n\n[webservers:vars]\nhttp_port=80\nansible_port=22\n",
        );
        // Host var should override group var
        let merged = data.get_host_vars("web1.example.com");
        assert_eq!(merged.get("http_port").unwrap(), &serde_json::json!(80));
        assert_eq!(merged.get("ansible_port").unwrap(), &serde_json::json!(2222));
    }
}
