use std::path::Path;

use ansible_utils::{AnsibleValue, Group, Host, InventoryData};

use crate::InventoryError;

/// Parse a YAML-format inventory file.
///
/// Format:
/// ```yaml
/// all:
///   hosts:
///     web1.example.com:
///       ansible_port: 2222
///   children:
///     webservers:
///       hosts:
///         web1.example.com:
///         web2.example.com:
///       vars:
///         http_port: 80
/// ```
pub fn parse_yaml_inventory(path: &Path, data: &mut InventoryData) -> Result<(), InventoryError> {
    let content =
        ansible_parsing::read_file_efficient(path).map_err(|e| InventoryError::ParseError(e.to_string()))?;

    let yaml: AnsibleValue =
        serde_yaml::from_str(&content).map_err(|e| InventoryError::ParseError(e.to_string()))?;

    let root = yaml
        .as_object()
        .ok_or_else(|| InventoryError::ParseError("inventory must be a YAML mapping".into()))?;

    for (group_name, group_def) in root {
        parse_group(group_name, group_def, data)?;
    }

    Ok(())
}

fn parse_group(
    name: &str,
    definition: &AnsibleValue,
    data: &mut InventoryData,
) -> Result<(), InventoryError> {
    // Ensure group exists
    if data.get_group(name).is_none() {
        data.add_group(Group::new(name.to_string()));
        if name != "all" {
            data.add_child_group("all", name);
        }
    }

    let def = match definition.as_object() {
        Some(d) => d,
        None => return Ok(()),
    };

    // Parse hosts
    if let Some(hosts) = def.get("hosts") {
        if let Some(hosts_map) = hosts.as_object() {
            for (host_name, host_vars) in hosts_map {
                if data.get_host(host_name).is_none() {
                    data.add_host(Host::new(host_name.to_string()));
                }
                data.add_host_to_group(host_name, name);

                // Set host variables
                if let Some(vars_map) = host_vars.as_object() {
                    for (key, value) in vars_map {
                        data.set_host_var(host_name, key, value.clone());
                    }
                }
            }
        }
    }

    // Parse group vars
    if let Some(vars) = def.get("vars") {
        if let Some(vars_map) = vars.as_object() {
            for (key, value) in vars_map {
                data.set_group_var(name, key, value.clone());
            }
        }
    }

    // Parse children (recurse)
    if let Some(children) = def.get("children") {
        if let Some(children_map) = children.as_object() {
            for (child_name, child_def) in children_map {
                parse_group(child_name, child_def, data)?;
                data.add_child_group(name, child_name);
            }
        }
    }

    Ok(())
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::io::Write;

    fn parse_yaml_str(content: &str) -> InventoryData {
        let mut tmp = tempfile::Builder::new()
            .suffix(".yml")
            .tempfile()
            .unwrap();
        write!(tmp, "{content}").unwrap();
        let mut data = InventoryData::new();
        data.add_group(Group::new("all".to_string()));
        data.add_group(Group::new("ungrouped".to_string()));
        data.add_child_group("all", "ungrouped");
        parse_yaml_inventory(tmp.path(), &mut data).unwrap();
        data
    }

    #[test]
    fn test_simple_yaml_inventory() {
        let data = parse_yaml_str(
            r#"
all:
  hosts:
    web1.example.com:
    web2.example.com:
"#,
        );
        assert!(data.get_host("web1.example.com").is_some());
        assert!(data.get_host("web2.example.com").is_some());
    }

    #[test]
    fn test_yaml_host_vars() {
        let data = parse_yaml_str(
            r#"
all:
  hosts:
    web1.example.com:
      ansible_host: 10.0.0.1
      ansible_port: 2222
"#,
        );
        let host = data.get_host("web1.example.com").unwrap();
        assert_eq!(
            host.vars.get("ansible_host").unwrap(),
            &serde_json::json!("10.0.0.1")
        );
        assert_eq!(
            host.vars.get("ansible_port").unwrap(),
            &serde_json::json!(2222)
        );
    }

    #[test]
    fn test_yaml_groups_and_children() {
        let data = parse_yaml_str(
            r#"
all:
  children:
    webservers:
      hosts:
        web1.example.com:
        web2.example.com:
    dbservers:
      hosts:
        db1.example.com:
    production:
      children:
        webservers:
        dbservers:
"#,
        );

        let ws = data.get_group("webservers").unwrap();
        assert_eq!(ws.hosts.len(), 2);

        let prod = data.get_group("production").unwrap();
        assert!(prod.has_child("webservers"));
        assert!(prod.has_child("dbservers"));
    }

    #[test]
    fn test_yaml_group_vars() {
        let data = parse_yaml_str(
            r#"
all:
  children:
    webservers:
      hosts:
        web1.example.com:
      vars:
        http_port: 80
        env: production
"#,
        );
        let ws = data.get_group("webservers").unwrap();
        assert_eq!(ws.vars.get("http_port").unwrap(), &serde_json::json!(80));
        assert_eq!(
            ws.vars.get("env").unwrap(),
            &serde_json::json!("production")
        );
    }

    #[test]
    fn test_yaml_host_vars_override_group_vars() {
        let data = parse_yaml_str(
            r#"
all:
  children:
    webservers:
      hosts:
        web1.example.com:
          ansible_port: 2222
      vars:
        ansible_port: 22
        http_port: 80
"#,
        );
        let merged = data.get_host_vars("web1.example.com");
        assert_eq!(merged.get("ansible_port").unwrap(), &serde_json::json!(2222));
        assert_eq!(merged.get("http_port").unwrap(), &serde_json::json!(80));
    }
}
