//! Script (dynamic) inventory plugin.
//!
//! Ansible treats any executable file as a dynamic inventory source.
//! The script is called with `--list` and must return JSON in one of
//! two formats:
//!
//! **Format 1 — with `_meta` (preferred, avoids per-host calls):**
//! ```json
//! {
//!   "webservers": {
//!     "hosts": ["web1", "web2"],
//!     "vars": { "http_port": 80 }
//!   },
//!   "dbservers": {
//!     "hosts": ["db1"],
//!     "children": ["backup"]
//!   },
//!   "_meta": {
//!     "hostvars": {
//!       "web1": { "ansible_host": "10.0.0.1" },
//!       "db1":  { "ansible_host": "10.0.0.2" }
//!     }
//!   }
//! }
//! ```
//!
//! **Format 2 — simple list of hosts per group:**
//! ```json
//! {
//!   "webservers": ["web1", "web2"],
//!   "dbservers": ["db1"]
//! }
//! ```
//!
//! When `_meta.hostvars` is absent, the script is called with
//! `--host <hostname>` for each discovered host to retrieve its
//! variables.

use std::collections::HashMap;
use std::path::Path;
use std::process::Command;

use ansible_utils::{AnsibleValue, Group, Host, InventoryData};
use tracing::debug;

use crate::InventoryError;

/// Returns `true` if the path looks like an executable script inventory.
pub fn is_script_inventory(path: &Path) -> bool {
    use std::os::unix::fs::PermissionsExt;
    if !path.is_file() {
        return false;
    }
    match path.metadata() {
        Ok(meta) => meta.permissions().mode() & 0o111 != 0,
        Err(_) => false,
    }
}

/// Parse a script (dynamic) inventory source.
///
/// Runs `<path> --list`, parses the JSON output, and populates `data`.
/// If the output lacks `_meta.hostvars`, each host is queried
/// individually via `<path> --host <name>`.
pub fn parse_script_inventory(
    path: &Path,
    data: &mut InventoryData,
) -> Result<(), InventoryError> {
    let list_output = run_script(path, &["--list"])?;
    let root: serde_json::Value = serde_json::from_str(&list_output).map_err(|e| {
        InventoryError::ParseError(format!(
            "script inventory {}: invalid JSON from --list: {e}",
            path.display()
        ))
    })?;
    let root_map = root.as_object().ok_or_else(|| {
        InventoryError::ParseError(format!(
            "script inventory {}: --list must return a JSON object",
            path.display()
        ))
    })?;

    // Extract _meta.hostvars if present
    let meta_hostvars: Option<HashMap<String, serde_json::Map<String, AnsibleValue>>> =
        root_map
            .get("_meta")
            .and_then(|m| m.get("hostvars"))
            .and_then(|hv| {
                hv.as_object().map(|obj| {
                    obj.iter()
                        .filter_map(|(k, v)| v.as_object().map(|o| (k.clone(), o.clone())))
                        .collect()
                })
            });

    let has_meta = meta_hostvars.is_some();
    let meta_hostvars = meta_hostvars.unwrap_or_default();

    // Track all discovered hosts so we can query missing hostvars
    let mut all_hosts: Vec<String> = Vec::new();

    for (key, value) in root_map {
        if key == "_meta" {
            continue;
        }
        let group_name = key.as_str();

        // Ensure the group exists
        if data.get_group(group_name).is_none() {
            data.add_group(Group::new(group_name.to_string()));
            if group_name != "all" {
                data.add_child_group("all", group_name);
            }
        }

        // The value can be either:
        // 1. A list of hostnames: ["host1", "host2"]
        // 2. An object with hosts/vars/children keys
        if let Some(host_list) = value.as_array() {
            // Simple list format
            for host_val in host_list {
                if let Some(host_name) = host_val.as_str() {
                    add_host_to_data(data, host_name, group_name);
                    all_hosts.push(host_name.to_string());
                }
            }
        } else if let Some(group_def) = value.as_object() {
            // Object format with hosts/vars/children
            if let Some(hosts) = group_def.get("hosts").and_then(|h| h.as_array()) {
                for host_val in hosts {
                    if let Some(host_name) = host_val.as_str() {
                        add_host_to_data(data, host_name, group_name);
                        all_hosts.push(host_name.to_string());
                    }
                }
            }

            if let Some(vars) = group_def.get("vars").and_then(|v| v.as_object()) {
                for (k, v) in vars {
                    data.set_group_var(group_name, k, v.clone());
                }
            }

            if let Some(children) = group_def.get("children").and_then(|c| c.as_array()) {
                for child_val in children {
                    if let Some(child_name) = child_val.as_str() {
                        if data.get_group(child_name).is_none() {
                            data.add_group(Group::new(child_name.to_string()));
                            data.add_child_group("all", child_name);
                        }
                        data.add_child_group(group_name, child_name);
                    }
                }
            }
        }
    }

    // De-duplicate hosts list
    all_hosts.sort();
    all_hosts.dedup();

    // Apply _meta hostvars
    for (host_name, vars) in &meta_hostvars {
        for (k, v) in vars {
            data.set_host_var(host_name, k, v.clone());
        }
    }

    // If no _meta was present, query each host individually
    if !has_meta {
        for host_name in &all_hosts {
            if let Ok(host_output) = run_script(path, &["--host", host_name]) {
                if let Ok(vars) = serde_json::from_str::<serde_json::Value>(&host_output) {
                    if let Some(vars_map) = vars.as_object() {
                        for (k, v) in vars_map {
                            data.set_host_var(host_name, k, v.clone());
                        }
                    }
                }
            }
        }
    }

    debug!(
        "script inventory {}: loaded {} hosts",
        path.display(),
        all_hosts.len()
    );

    Ok(())
}

fn add_host_to_data(data: &mut InventoryData, host_name: &str, group_name: &str) {
    if data.get_host(host_name).is_none() {
        data.add_host(Host::new(host_name.to_string()));
    }
    data.add_host_to_group(host_name, group_name);
}

fn run_script(path: &Path, args: &[&str]) -> Result<String, InventoryError> {
    // Retry on ETXTBSY (errno 26) which can occur when the kernel hasn't
    // fully released a recently-written executable's text segment.
    let mut last_err = None;
    for _ in 0..5 {
        match Command::new(path).args(args).output() {
            Ok(output) => {
                return run_script_handle_output(path, output);
            }
            Err(e) if e.raw_os_error() == Some(26) => {
                last_err = Some(e);
                std::thread::sleep(std::time::Duration::from_millis(10));
                continue;
            }
            Err(e) => {
                return Err(InventoryError::InvalidSource(format!(
                    "failed to execute script inventory {}: {e}",
                    path.display()
                )));
            }
        }
    }
    Err(InventoryError::InvalidSource(format!(
        "failed to execute script inventory {}: {}",
        path.display(),
        last_err.unwrap()
    )))
}

fn run_script_handle_output(
    path: &Path,
    output: std::process::Output,
) -> Result<String, InventoryError> {
    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr);
        return Err(InventoryError::InvalidSource(format!(
            "script inventory {} exited with {}: {}",
            path.display(),
            output.status,
            stderr.trim()
        )));
    }

    String::from_utf8(output.stdout).map_err(|e| {
        InventoryError::ParseError(format!(
            "script inventory {}: non-UTF-8 output: {e}",
            path.display()
        ))
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::fs;
    use std::os::unix::fs::PermissionsExt;
    use std::path::PathBuf;

    /// Helper: write a script file inside a temp dir, close the handle,
    /// then chmod +x. Returns (TempDir, PathBuf) — the dir keeps the
    /// file alive for the test's lifetime.
    fn write_script(content: &str) -> (tempfile::TempDir, PathBuf) {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("inventory.sh");
        {
            let mut f = fs::File::create(&path).unwrap();
            use std::io::Write;
            f.write_all(content.as_bytes()).unwrap();
            // Set permissions on the same fd to avoid ETXTBSY race.
            let mut perms = f.metadata().unwrap().permissions();
            perms.set_mode(0o755);
            f.set_permissions(perms).unwrap();
            f.sync_all().unwrap();
            // f drops here, closing the fd after write + chmod + sync
        }
        (dir, path)
    }

    fn make_script(list_json: &str) -> (tempfile::TempDir, PathBuf) {
        write_script(&format!(
            r#"#!/bin/sh
case "$1" in
  --list) cat <<'ENDJSON'
{list_json}
ENDJSON
  ;;
  --host) echo '{{}}';;
esac"#
        ))
    }

    fn empty_data() -> InventoryData {
        let mut data = InventoryData::new();
        data.add_group(Group::new("all".to_string()));
        data.add_group(Group::new("ungrouped".to_string()));
        data.add_child_group("all", "ungrouped");
        data
    }

    #[test]
    fn test_is_script_inventory() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("test.sh");
        fs::write(&path, "#!/bin/sh\necho hello").unwrap();
        // Not executable yet
        assert!(!is_script_inventory(&path));
        // Make executable
        let mut perms = fs::metadata(&path).unwrap().permissions();
        perms.set_mode(0o755);
        fs::set_permissions(&path, perms).unwrap();
        assert!(is_script_inventory(&path));
    }

    #[test]
    fn test_script_simple_list_format() {
        let (_dir, path) = make_script(
            r#"{
  "webservers": ["web1", "web2"],
  "dbservers": ["db1"]
}"#,
        );
        let mut data = empty_data();
        parse_script_inventory(&path, &mut data).unwrap();

        assert!(data.get_host("web1").is_some());
        assert!(data.get_host("web2").is_some());
        assert!(data.get_host("db1").is_some());

        let ws = data.get_group("webservers").unwrap();
        assert!(ws.has_host("web1"));
        assert!(ws.has_host("web2"));
    }

    #[test]
    fn test_script_object_format_with_meta() {
        let (_dir, path) = make_script(
            r#"{
  "webservers": {
    "hosts": ["web1", "web2"],
    "vars": {"http_port": 80}
  },
  "dbservers": {
    "hosts": ["db1"],
    "children": ["backup"]
  },
  "_meta": {
    "hostvars": {
      "web1": {"ansible_host": "10.0.0.1"},
      "db1":  {"ansible_host": "10.0.0.2"}
    }
  }
}"#,
        );
        let mut data = empty_data();
        parse_script_inventory(&path, &mut data).unwrap();

        assert!(data.get_host("web1").is_some());
        assert!(data.get_host("db1").is_some());

        let web1 = data.get_host("web1").unwrap();
        assert_eq!(
            web1.vars.get("ansible_host").unwrap(),
            &serde_json::json!("10.0.0.1")
        );

        let ws = data.get_group("webservers").unwrap();
        assert_eq!(ws.vars.get("http_port").unwrap(), &serde_json::json!(80));

        let db = data.get_group("dbservers").unwrap();
        assert!(db.has_child("backup"));
    }

    #[test]
    fn test_script_host_callback_when_no_meta() {
        let (_dir, path) = write_script(
            r#"#!/bin/sh
case "$1" in
  --list) echo '{"servers": ["srv1"]}';;
  --host)
    case "$2" in
      srv1) echo '{"role": "app"}';;
      *) echo '{}';;
    esac
  ;;
esac"#,
        );

        let mut data = empty_data();
        parse_script_inventory(&path, &mut data).unwrap();

        let srv1 = data.get_host("srv1").unwrap();
        assert_eq!(
            srv1.vars.get("role").unwrap(),
            &serde_json::json!("app")
        );
    }

    #[test]
    fn test_script_bad_exit_code() {
        let (_dir, path) = write_script("#!/bin/sh\nexit 1");

        let mut data = empty_data();
        let err = parse_script_inventory(&path, &mut data).unwrap_err();
        assert!(err.to_string().contains("exited with"));
    }

    #[test]
    fn test_script_invalid_json() {
        let (_dir, path) = write_script("#!/bin/sh\necho 'not json'");

        let mut data = empty_data();
        let err = parse_script_inventory(&path, &mut data).unwrap_err();
        assert!(err.to_string().contains("invalid JSON"));
    }
}
