use thiserror::Error;

#[derive(Debug, Error)]
pub enum InventoryError {
    #[error("inventory parse error: {0}")]
    ParseError(String),

    #[error("host not found: {0}")]
    HostNotFound(String),

    #[error("group not found: {0}")]
    GroupNotFound(String),

    #[error("invalid inventory source: {0}")]
    InvalidSource(String),

    #[error(transparent)]
    Io(#[from] std::io::Error),

    #[error(transparent)]
    Parsing(#[from] ansible_parsing::ParsingError),
}
