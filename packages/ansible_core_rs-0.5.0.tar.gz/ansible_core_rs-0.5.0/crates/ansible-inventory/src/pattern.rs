use std::collections::HashSet;

use ansible_utils::InventoryData;

/// Resolve an Ansible host pattern against inventory data.
///
/// Ansible host patterns support:
/// - Group names: `webservers`
/// - `all` — all hosts
/// - Union (`,` or `:`): `webservers:dbservers`
/// - Intersection (`&`): `webservers:&staging`
/// - Exclusion (`!`): `webservers:!phoenix`
/// - Wildcards (`*`, `?`): `web*.example.com`
/// - Regex (`~`): `~web[0-9]+\.example\.com`
/// - Indexed selection: `webservers[0]`, `webservers[0:2]`
/// - Localhost / 127.0.0.1 patterns
pub fn resolve_pattern(pattern: &str, inventory: &InventoryData) -> Vec<String> {
    if pattern.is_empty() {
        return Vec::new();
    }

    // Split on `:` to get pattern components, but handle `:&` and `:!` as operators
    let components = split_pattern(pattern);

    let mut result_set: Option<HashSet<String>> = None;

    for component in &components {
        let (op, pat) = parse_component(component);

        let matched = match_single_pattern(pat, inventory);

        match op {
            PatternOp::Union => {
                if let Some(ref mut set) = result_set {
                    set.extend(matched);
                } else {
                    result_set = Some(matched.into_iter().collect());
                }
            }
            PatternOp::Intersect => {
                if let Some(ref mut set) = result_set {
                    let matched_set: HashSet<String> = matched.into_iter().collect();
                    *set = set.intersection(&matched_set).cloned().collect();
                }
            }
            PatternOp::Exclude => {
                if let Some(ref mut set) = result_set {
                    for host in &matched {
                        set.remove(host);
                    }
                }
            }
        }
    }

    let mut hosts: Vec<String> = result_set.unwrap_or_default().into_iter().collect();
    hosts.sort();
    hosts
}

/// Pattern operator types.
enum PatternOp {
    Union,
    Intersect,
    Exclude,
}

/// Split a pattern string into components, preserving `:&` and `:!` operators.
fn split_pattern(pattern: &str) -> Vec<String> {
    let mut components = Vec::new();
    let mut current = String::new();
    let chars: Vec<char> = pattern.chars().collect();
    let mut i = 0;

    while i < chars.len() {
        if chars[i] == ':' || chars[i] == ',' {
            if !current.is_empty() {
                components.push(current.clone());
                current.clear();
            }
            // Check for :& or :! operators
            if chars[i] == ':' && i + 1 < chars.len() {
                match chars[i + 1] {
                    '&' => {
                        i += 1;
                        current.push('&');
                    }
                    '!' => {
                        i += 1;
                        current.push('!');
                    }
                    _ => {}
                }
            }
        } else {
            current.push(chars[i]);
        }
        i += 1;
    }

    if !current.is_empty() {
        components.push(current);
    }

    components
}

/// Parse a component into its operator and pattern.
fn parse_component(component: &str) -> (PatternOp, &str) {
    if let Some(rest) = component.strip_prefix('&') {
        (PatternOp::Intersect, rest)
    } else if let Some(rest) = component.strip_prefix('!') {
        (PatternOp::Exclude, rest)
    } else {
        (PatternOp::Union, component)
    }
}

/// Match a single pattern (no operators) against inventory.
fn match_single_pattern(pattern: &str, inventory: &InventoryData) -> Vec<String> {
    // Handle indexed patterns: group[N] or group[N:M]
    if let Some((base, index)) = parse_indexed_pattern(pattern) {
        let hosts = match_base_pattern(base, inventory);
        return apply_index(hosts, index);
    }

    match_base_pattern(pattern, inventory)
}

/// Match a base pattern (no index) against inventory.
fn match_base_pattern(pattern: &str, inventory: &InventoryData) -> Vec<String> {
    // Special patterns
    match pattern {
        "all" | "*" => {
            return inventory.hosts.keys().map(|k| k.as_ref().to_string()).collect();
        }
        "ungrouped" => {
            if let Some(group) = inventory.groups.get("ungrouped") {
                return group.hosts.iter().map(|h| h.as_ref().to_string()).collect();
            }
            return Vec::new();
        }
        "localhost" | "127.0.0.1" | "::1" => {
            return vec!["localhost".to_string()];
        }
        _ => {}
    }

    // Check if it's a regex pattern (prefixed with ~)
    if let Some(regex_str) = pattern.strip_prefix('~') {
        return match_regex(regex_str, inventory);
    }

    // Check if it's a group name
    if let Some(_group) = inventory.groups.get(pattern) {
        return get_group_hosts(pattern, inventory);
    }

    // Check if it's an exact host match
    if inventory.hosts.contains_key(pattern) {
        return vec![pattern.to_string()];
    }

    // Check for wildcard patterns
    if pattern.contains('*') || pattern.contains('?') {
        return match_glob(pattern, inventory);
    }

    // If nothing matches, treat as a literal host (may be an implicit localhost)
    vec![pattern.to_string()]
}

/// Get all hosts in a group, including hosts from child groups.
fn get_group_hosts(group_name: &str, inventory: &InventoryData) -> Vec<String> {
    let mut hosts = HashSet::new();

    if let Some(group) = inventory.groups.get(group_name) {
        for host in &group.hosts {
            hosts.insert(host.as_ref().to_string());
        }
        for child in &group.children {
            for host in get_group_hosts(child, inventory) {
                hosts.insert(host);
            }
        }
    }

    hosts.into_iter().collect()
}

/// Match a regex pattern against all host names.
fn match_regex(regex_str: &str, inventory: &InventoryData) -> Vec<String> {
    let re = match regex::Regex::new(regex_str) {
        Ok(r) => r,
        Err(_) => return Vec::new(),
    };

    inventory
        .hosts
        .keys()
        .filter(|h| re.is_match(h))
        .map(|k| k.as_ref().to_string())
        .collect()
}

/// Match a glob pattern against all host names.
fn match_glob(pattern: &str, inventory: &InventoryData) -> Vec<String> {
    // Convert glob to regex
    let mut regex_str = String::from("^");
    for ch in pattern.chars() {
        match ch {
            '*' => regex_str.push_str(".*"),
            '?' => regex_str.push('.'),
            '.' => regex_str.push_str("\\."),
            '[' => regex_str.push('['),
            ']' => regex_str.push(']'),
            c => regex_str.push(c),
        }
    }
    regex_str.push('$');

    match_regex(&regex_str, inventory)
}

/// Index specification for host selection.
enum IndexSpec {
    Single(usize),
    Range(usize, usize),
}

/// Parse an indexed pattern like `group[0]` or `group[0:2]`.
fn parse_indexed_pattern(pattern: &str) -> Option<(&str, IndexSpec)> {
    let bracket_start = pattern.find('[')?;
    let bracket_end = pattern.find(']')?;

    if bracket_end <= bracket_start {
        return None;
    }

    let base = &pattern[..bracket_start];
    let index_str = &pattern[bracket_start + 1..bracket_end];

    if let Some((start_str, end_str)) = index_str.split_once(':') {
        let start = start_str.parse::<usize>().ok()?;
        let end = end_str.parse::<usize>().ok()?;
        Some((base, IndexSpec::Range(start, end)))
    } else {
        let idx = index_str.parse::<usize>().ok()?;
        Some((base, IndexSpec::Single(idx)))
    }
}

/// Apply an index to a host list.
fn apply_index(mut hosts: Vec<String>, index: IndexSpec) -> Vec<String> {
    hosts.sort();
    match index {
        IndexSpec::Single(i) => {
            if i < hosts.len() {
                vec![hosts[i].clone()]
            } else {
                Vec::new()
            }
        }
        IndexSpec::Range(start, end) => {
            let end = end.min(hosts.len());
            if start < hosts.len() {
                hosts[start..=end.min(hosts.len() - 1)].to_vec()
            } else {
                Vec::new()
            }
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ansible_utils::{Group, Host};

    fn make_inventory() -> InventoryData {
        let mut inv = InventoryData::new();

        // Add hosts
        inv.add_host(Host::new("web1.example.com"));
        inv.add_host(Host::new("web2.example.com"));
        inv.add_host(Host::new("db1.example.com"));
        inv.add_host(Host::new("db2.example.com"));
        inv.add_host(Host::new("cache1.example.com"));

        // Add groups
        let mut web = Group::new("webservers");
        web.hosts.push("web1.example.com".into());
        web.hosts.push("web2.example.com".into());
        inv.add_group(web);

        let mut db = Group::new("dbservers");
        db.hosts.push("db1.example.com".into());
        db.hosts.push("db2.example.com".into());
        inv.add_group(db);

        let mut staging = Group::new("staging");
        staging.hosts.push("web1.example.com".into());
        staging.hosts.push("db1.example.com".into());
        inv.add_group(staging);

        let mut prod = Group::new("production");
        prod.hosts.push("web2.example.com".into());
        prod.hosts.push("db2.example.com".into());
        prod.hosts.push("cache1.example.com".into());
        inv.add_group(prod);

        let mut all = Group::new("all");
        all.hosts = inv.hosts.keys().cloned().collect();
        inv.add_group(all);

        inv
    }

    #[test]
    fn test_all_pattern() {
        let inv = make_inventory();
        let hosts = resolve_pattern("all", &inv);
        assert_eq!(hosts.len(), 5);
    }

    #[test]
    fn test_group_pattern() {
        let inv = make_inventory();
        let hosts = resolve_pattern("webservers", &inv);
        assert_eq!(hosts.len(), 2);
        assert!(hosts.contains(&"web1.example.com".to_string()));
        assert!(hosts.contains(&"web2.example.com".to_string()));
    }

    #[test]
    fn test_union_pattern() {
        let inv = make_inventory();
        let hosts = resolve_pattern("webservers:dbservers", &inv);
        assert_eq!(hosts.len(), 4);
    }

    #[test]
    fn test_intersection_pattern() {
        let inv = make_inventory();
        let hosts = resolve_pattern("webservers:&staging", &inv);
        assert_eq!(hosts.len(), 1);
        assert!(hosts.contains(&"web1.example.com".to_string()));
    }

    #[test]
    fn test_exclusion_pattern() {
        let inv = make_inventory();
        let hosts = resolve_pattern("all:!webservers", &inv);
        assert_eq!(hosts.len(), 3);
        assert!(!hosts.contains(&"web1.example.com".to_string()));
        assert!(!hosts.contains(&"web2.example.com".to_string()));
    }

    #[test]
    fn test_glob_pattern() {
        let inv = make_inventory();
        let hosts = resolve_pattern("web*", &inv);
        assert_eq!(hosts.len(), 2);
    }

    #[test]
    fn test_regex_pattern() {
        let inv = make_inventory();
        let hosts = resolve_pattern("~.*1\\.example\\.com$", &inv);
        assert_eq!(hosts.len(), 3); // web1, db1, cache1
    }

    #[test]
    fn test_indexed_pattern() {
        let inv = make_inventory();
        let hosts = resolve_pattern("webservers[0]", &inv);
        assert_eq!(hosts.len(), 1);
    }

    #[test]
    fn test_range_pattern() {
        let inv = make_inventory();
        let hosts = resolve_pattern("webservers[0:1]", &inv);
        assert_eq!(hosts.len(), 2);
    }

    #[test]
    fn test_complex_pattern() {
        let inv = make_inventory();
        // webservers in staging, minus no one
        let hosts = resolve_pattern("webservers:&staging", &inv);
        assert_eq!(hosts.len(), 1);
        assert_eq!(hosts[0], "web1.example.com");
    }

    #[test]
    fn test_comma_separated() {
        let inv = make_inventory();
        let hosts = resolve_pattern("web1.example.com,db1.example.com", &inv);
        assert_eq!(hosts.len(), 2);
    }

    #[test]
    fn test_empty_pattern() {
        let inv = make_inventory();
        let hosts = resolve_pattern("", &inv);
        assert!(hosts.is_empty());
    }

    #[test]
    fn test_localhost_pattern() {
        let inv = make_inventory();
        let hosts = resolve_pattern("localhost", &inv);
        assert_eq!(hosts.len(), 1);
        assert_eq!(hosts[0], "localhost");
    }
}
