//! Memory usage benchmark: compare Rust vs Python ansible inventory parsing.
//!
//! Run with: cargo test -p ansible-inventory --test memory_bench -- --nocapture

use std::fs;

/// Generate a 1000-host INI inventory (matching the Python benchmark).
fn generate_1000_host_inventory(dir: &std::path::Path) -> std::path::PathBuf {
    let mut content = String::with_capacity(52000);
    content.push_str("[webservers]\n");
    for i in 0..500 {
        let net = i / 254;
        let host = i % 254 + 1;
        content.push_str(&format!(
            "web{:04}.example.com ansible_host=10.0.{}.{} ansible_port=22\n",
            i, net, host
        ));
    }
    content.push_str("[dbservers]\n");
    for i in 0..500 {
        let net = i / 254;
        let host = i % 254 + 1;
        content.push_str(&format!(
            "db{:04}.example.com ansible_host=10.1.{}.{}\n",
            i, net, host
        ));
    }
    content.push_str("[production:children]\nwebservers\ndbservers\n");
    content.push_str("[production:vars]\nenv=production\ndeploy=true\n");

    let path = dir.join("large_inventory.ini");
    fs::write(&path, &content).unwrap();
    path
}

#[test]
fn test_memory_1000_hosts() {
    let dir = tempfile::tempdir().unwrap();
    let inv_path = generate_1000_host_inventory(dir.path());

    // Measure RSS before
    let rss_before = get_rss_kb();

    let mut mgr = ansible_inventory::InventoryManager::new();
    mgr.add_source(inv_path);
    mgr.parse_sources().unwrap();

    // Measure RSS after
    let rss_after = get_rss_kb();
    let rss_delta = rss_after.saturating_sub(rss_before);

    let host_count = mgr.hosts().len();
    let group_count = mgr.groups().len();

    println!("=== Rust Inventory Memory (1000 hosts) ===");
    println!("Hosts parsed: {host_count}");
    println!("Groups parsed: {group_count}");
    println!("RSS before:    {rss_before} KB");
    println!("RSS after:     {rss_after} KB");
    println!("RSS delta:     {rss_delta} KB");
    println!();

    // Python baseline measured via benches/python_memory_baseline.py against
    // ansible-core 2.20.4 (venv): tracemalloc peak ~2766 KB, RSS delta ~5504 KB
    // for the same 1000-host inventory. Using tracemalloc peak (allocation-only,
    // excludes allocator fragmentation) for an apples-to-apples comparison.
    let python_peak_kb: u64 = 2766;
    let rust_rss = rss_delta;
    let ratio = rust_rss as f64 / python_peak_kb as f64;
    println!("Python peak:   {python_peak_kb} KB");
    println!("Rust delta:    {rust_rss} KB");
    println!("Ratio:         {:.1}% of Python ({:.2}x)", ratio * 100.0, ratio);
    println!();
    if ratio < 0.5 {
        println!("PASS: Rust uses <50% of Python memory");
    } else {
        println!("NOTE: Rust uses >=50% of Python memory (target was <50%)");
    }

    assert_eq!(host_count, 1000);
}

/// Read current process RSS from /proc/self/status (Linux).
fn get_rss_kb() -> u64 {
    let status = fs::read_to_string("/proc/self/status").unwrap();
    for line in status.lines() {
        if line.starts_with("VmRSS:") {
            let parts: Vec<&str> = line.split_whitespace().collect();
            if parts.len() >= 2 {
                return parts[1].parse::<u64>().unwrap_or(0);
            }
        }
    }
    0
}
