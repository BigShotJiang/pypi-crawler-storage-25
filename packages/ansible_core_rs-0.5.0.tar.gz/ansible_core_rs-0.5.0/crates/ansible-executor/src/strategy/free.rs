//! The "free" strategy: each host runs through all tasks independently.
//!
//! Unlike the linear strategy, hosts do not wait for each other at task
//! boundaries. Faster hosts proceed to the next task immediately while
//! slower hosts are still working on earlier tasks. This is useful for
//! large fleets where hosts have different execution times.

use std::collections::HashMap;
use std::sync::Arc;

use ansible_playbook::Task;
use ansible_utils::AggregateStats;
use ansible_vars::VariableManager;
use async_trait::async_trait;
use tokio::sync::{Mutex, Semaphore};
use tracing::{debug, warn};

use crate::play_iterator::{HostState, NextTask, PlayIterator, PlayPhase};
use crate::strategy::{StrategyPlugin, StrategyResult};
use crate::task_executor::TaskExecutor;
use crate::ExecutorError;

/// The "free" strategy: each host runs independently through its task list.
pub struct FreeStrategy;

#[async_trait]
impl StrategyPlugin for FreeStrategy {
    async fn run(
        &self,
        iterator: &mut PlayIterator,
        variable_manager: Arc<VariableManager>,
        _stats: &mut AggregateStats,
        forks: usize,
    ) -> Result<StrategyResult, ExecutorError> {
        let semaphore = Arc::new(Semaphore::new(forks));
        let all_results = Arc::new(Mutex::new(Vec::new()));
        let all_ok = Arc::new(Mutex::new(true));

        // In free strategy, each host gets its own copy of the play iterator
        // state and runs through all tasks independently. We spawn a task
        // per host and let them race.

        // First handle fact gathering if needed
        let active_hosts = iterator.get_active_hosts();
        if active_hosts.is_empty() {
            return Ok(StrategyResult {
                results: Vec::new(),
                all_ok: true,
            });
        }

        // Check if setup is needed
        let first_host = &active_hosts[0];
        let needs_setup = matches!(
            iterator.get_next_task_for_host(first_host),
            NextTask::Setup { .. }
        );

        if needs_setup {
            debug!("TASK [Gathering Facts] (free strategy)");
            let setup_task = ansible_playbook::Task::minimal_action(
                "Gathering Facts",
                "setup",
                serde_json::json!({}),
            );
            let mut handles = Vec::new();
            for host in &active_hosts {
                let sem = semaphore.clone();
                let host = host.clone();
                let task = setup_task.clone();
                let vm = variable_manager.clone();
                handles.push(tokio::spawn(async move {
                    let _permit = sem.acquire().await.unwrap();
                    let executor = TaskExecutor::new(host.clone(), task, vm);
                    (host, executor.run().await)
                }));
            }
            for handle in handles {
                let (host, result) = handle.await.map_err(|e| {
                    ExecutorError::TaskFailed(format!("setup panicked: {e}"))
                })?;
                if let Ok(res) = result {
                    if let Some(facts) = res
                        .results
                        .get("ansible_facts")
                        .and_then(|v| v.as_object())
                    {
                        for (k, v) in facts {
                            variable_manager.set_host_fact(&host, k.clone(), v.clone());
                        }
                    }
                }
                // Preserve iterator-level state (notably `start_at_reached`)
                // rather than resetting to default.
                let mut next = iterator
                    .get_host_state(&host)
                    .cloned()
                    .unwrap_or_default();
                next.phase = PlayPhase::PreTasks;
                next.pending_setup = false;
                iterator.set_host_state(&host, next);
            }
        }

        // Now run all remaining tasks per host independently
        // Each host consumes tasks from the iterator until complete
        let mut handles = Vec::new();
        let play_vars = iterator.play.vars.clone();

        for host in &active_hosts {
            let sem = semaphore.clone();
            let host = host.clone();
            let vm = variable_manager.clone();
            let results = all_results.clone();
            let ok_flag = all_ok.clone();

            // Collect all tasks for this host upfront, capturing block
            // vars for each task when applicable.
            let mut host_tasks: Vec<(Task, HostState, Option<HashMap<String, serde_json::Value>>)> = Vec::new();
            loop {
                match iterator.get_next_task_for_host(&host) {
                    NextTask::Task { task, host_state, block_vars } => {
                        host_tasks.push((task.clone(), host_state.clone(), block_vars));
                        iterator.set_host_state(&host, host_state);
                    }
                    NextTask::Setup { .. } => {
                        // Already handled above
                        break;
                    }
                    NextTask::Complete => break,
                }
            }

            // Mark host as complete in the iterator
            iterator.set_host_state(&host, HostState {
                phase: PlayPhase::Complete,
                ..HostState::default()
            });

            let pv = play_vars.clone();
            handles.push(tokio::spawn(async move {
                for (task, _state, bv) in host_tasks {
                    let _permit = sem.acquire().await.unwrap();
                    let task_name = task.name.as_deref().unwrap_or("unnamed").to_string();
                    debug!("[{}] TASK [{}]", host, task_name);

                    let register_var = task.register.clone();
                    let _notify_list = task.notify.clone();
                    let ignore_errors = task.ignore_errors;

                    let executor = TaskExecutor::with_context(
                        host.clone(),
                        task,
                        vm.clone(),
                        pv.clone(),
                        bv,
                        None, // role_name
                    );
                    match executor.run().await {
                        Ok(result) => {
                            // Handle register
                            if let Some(ref var_name) = register_var {
                                let reg_value = serde_json::json!({
                                    "changed": result.changed,
                                    "failed": result.failed,
                                    "skipped": result.skipped,
                                    "msg": result.msg.as_deref().unwrap_or(""),
                                    "stdout": result.results.get("stdout").and_then(|v| v.as_str()).unwrap_or(""),
                                    "stderr": result.results.get("stderr").and_then(|v| v.as_str()).unwrap_or(""),
                                    "results": result.results,
                                });
                                vm.set_host_fact(&host, var_name.clone(), reg_value);
                            }

                            // Handle set_fact
                            if let Some(facts) = result
                                .results
                                .get("ansible_facts")
                                .and_then(|v| v.as_object())
                            {
                                for (k, v) in facts {
                                    vm.set_host_fact(&host, k.clone(), v.clone());
                                }
                            }

                            // Attach task name for TASK banner emission.
                            let mut result = result;
                            result.task_fields.insert(
                                "name".to_string(),
                                serde_json::Value::String(task_name.clone()),
                            );

                            if result.failed && !ignore_errors {
                                *ok_flag.lock().await = false;
                                results.lock().await.push(result);
                                break; // Stop this host on failure
                            }

                            results.lock().await.push(result);
                        }
                        Err(e) => {
                            warn!("[{}] Task error: {}", host, e);
                            *ok_flag.lock().await = false;
                            break;
                        }
                    }
                }
            }));
        }

        // Wait for all hosts to finish
        for handle in handles {
            handle
                .await
                .map_err(|e| ExecutorError::TaskFailed(format!("free task panicked: {e}")))?;
        }

        let results = Arc::try_unwrap(all_results)
            .unwrap_or_else(|a| {
                // Fallback: clone the inner value
                let rt = tokio::runtime::Handle::current();
                let cloned = rt.block_on(async { a.lock().await.clone() });
                Mutex::new(cloned)
            })
            .into_inner();

        let ok = *all_ok.lock().await;

        Ok(StrategyResult {
            results,
            all_ok: ok,
        })
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::collections::HashMap;
    use ansible_inventory::InventoryManager;
    use ansible_playbook::{Play, Task};

    fn local_inventory(hosts: &[&str]) -> Arc<InventoryManager> {
        let mut inv = InventoryManager::new();
        for h in hosts {
            let mut host = ansible_utils::Host::new(*h);
            host.vars.insert(
                "ansible_connection".into(),
                ansible_utils::AnsibleValue::String("local".into()),
            );
            inv.data_mut().add_host(host);
        }
        Arc::new(inv)
    }

    fn make_task(name: &str) -> Task {
        Task {
            name: Some(name.to_string()),
            action: {
                let mut m = HashMap::new();
                m.insert(
                    "debug".into(),
                    serde_json::json!({"msg": name}),
                );
                m
            },
            when_conditions: Vec::new(),
            register: None,
            loop_source: None,
            loop_items: None,
            with_items: None,
            loop_control: None,
            notify: Vec::new(),
            tags: Default::default(),
            use_become: None,
            become_user: None,
            become_method: None,
            become_flags: None,
            become_pass: None,
            delegate_to: None,
            ignore_errors: false,
            changed_when: Vec::new(),
            failed_when: Vec::new(),
            retries: 3,
            delay: 5,
            until: Vec::new(),
            no_log: false,
            args: None,
            environment: None,
            vars: None,
            block: None,
            rescue: None,
            always: None,
            connection: None,
            timeout: None,
        }
    }

    fn make_play(tasks: Vec<Task>) -> Play {
        Play {
            name: Some("test".into()),
            hosts: Some("all".into()),
            tasks,
            pre_tasks: Vec::new(),
            post_tasks: Vec::new(),
            handlers: Vec::new(),
            roles: Vec::new(),
            vars: HashMap::new(),
            vars_files: Vec::new(),
            environment: HashMap::new(),
            gather_facts: Some(false),
            strategy: "free".into(),
            serial: Vec::new(),
            max_fail_percentage: None,
            use_become: None,
            become_user: None,
            become_method: None,
            connection: None,
            tags: Default::default(),
            when_conditions: Vec::new(),
            any_errors_fatal: None,
            ignore_errors: None,
            ignore_unreachable: None,
            module_defaults: None,
            collections: None,
        }
    }

    #[tokio::test]
    async fn test_free_strategy_basic() {
        let play = make_play(vec![make_task("t1"), make_task("t2"), make_task("t3")]);
        let hosts = vec!["h1".to_string(), "h2".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = FreeStrategy
            .run(&mut iterator, vm, &mut stats, 5)
            .await
            .unwrap();

        // 3 tasks × 2 hosts = 6 results
        assert_eq!(result.results.len(), 6);
        assert!(result.all_ok);
    }

    #[tokio::test]
    async fn test_free_strategy_single_host() {
        let play = make_play(vec![make_task("t1"), make_task("t2")]);
        let hosts = vec!["h1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = Arc::new(InventoryManager::new());
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = FreeStrategy
            .run(&mut iterator, vm, &mut stats, 5)
            .await
            .unwrap();

        assert_eq!(result.results.len(), 2);
        assert!(result.all_ok);
    }

    #[tokio::test]
    async fn test_free_strategy_register() {
        let mut cmd_task = make_task("run cmd");
        cmd_task.action.clear();
        cmd_task.action.insert(
            "command".into(),
            serde_json::json!("echo hello"),
        );
        cmd_task.register = Some("cmd_out".into());

        let debug_task = make_task("use result");

        let play = make_play(vec![cmd_task, debug_task]);
        let hosts = vec!["h1".to_string()];
        let mut iterator = PlayIterator::new(play, &hosts);
        let inv = local_inventory(&["h1"]);
        let vm = Arc::new(VariableManager::new(inv));
        let mut stats = AggregateStats::new();

        let result = FreeStrategy
            .run(&mut iterator, vm.clone(), &mut stats, 5)
            .await
            .unwrap();

        assert!(result.all_ok);
        let host_vars = vm.get_vars("h1", &HashMap::new(), None, None, None);
        assert!(host_vars.contains_key("cmd_out"));
    }
}
