pub mod free;
pub mod host_pinned;
pub mod linear;

use std::sync::Arc;

use ansible_utils::{AggregateStats, TaskResult};
use ansible_vars::VariableManager;
use async_trait::async_trait;

use crate::play_iterator::PlayIterator;
use crate::ExecutorError;

/// Trait for strategy plugins that control task execution order.
#[async_trait]
pub trait StrategyPlugin: Send + Sync {
    /// Run the strategy for a play, executing tasks across hosts.
    async fn run(
        &self,
        iterator: &mut PlayIterator,
        variable_manager: Arc<VariableManager>,
        stats: &mut AggregateStats,
        forks: usize,
    ) -> Result<StrategyResult, ExecutorError>;
}

/// Result of a strategy execution.
pub struct StrategyResult {
    pub results: Vec<TaskResult>,
    pub all_ok: bool,
}
