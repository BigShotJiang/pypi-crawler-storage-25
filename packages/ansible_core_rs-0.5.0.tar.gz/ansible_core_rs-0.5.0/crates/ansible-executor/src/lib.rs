pub mod error;
pub mod module;
pub mod play_iterator;
pub mod strategy;
pub mod task_executor;
pub mod task_queue;

pub use error::ExecutorError;
pub use strategy::free::FreeStrategy;
pub use strategy::linear::LinearStrategy;
pub use strategy::StrategyPlugin;
