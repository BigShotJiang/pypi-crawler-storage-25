use thiserror::Error;

#[derive(Debug, Error)]
pub enum ExecutorError {
    #[error("task execution failed: {0}")]
    TaskFailed(String),

    #[error("host unreachable: {0}")]
    HostUnreachable(String),

    #[error("max fail percentage exceeded")]
    MaxFailPercentageExceeded,

    #[error(transparent)]
    Plugin(#[from] ansible_plugins::PluginError),

    #[error(transparent)]
    Vars(#[from] ansible_vars::VarsError),

    #[error(transparent)]
    Template(#[from] ansible_template::TemplateError),

    #[error(transparent)]
    Io(#[from] std::io::Error),
}
