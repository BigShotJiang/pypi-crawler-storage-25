//! Remote temporary directory management.
//!
//! Mirrors ansible-core's `make_tmp_path` / `remove_tmp_path` logic:
//! create a unique, per-task temp directory on the remote host under
//! `~/.ansible/tmp/ansible-tmp-<epoch>-<pid>-<random>/`, execute the
//! task, then clean up. Falls back to `/tmp` when the home directory
//! is not writable.

use std::path::PathBuf;

use ansible_plugins::{ConnectionPlugin, PluginError, ShellPlugin};
use ansible_plugins::shell::sh::ShPlugin;

/// Manages a temporary directory on a remote (or local) host.
pub struct RemoteTmpDir {
    /// The resolved remote path, e.g. `/home/user/.ansible/tmp/ansible-tmp-1234-5678-abc/`
    pub path: Option<PathBuf>,
}

impl RemoteTmpDir {
    /// Create a temporary directory on the remote host via the connection plugin.
    ///
    /// Tries `~/.ansible/tmp` first, falls back to `/tmp` if the home dir
    /// is not writable. Returns the path to the created directory.
    pub async fn create(
        conn: &(dyn ConnectionPlugin + Send + Sync),
        become_user: Option<&str>,
    ) -> Result<Self, PluginError> {
        // Try ~/.ansible/tmp first, matching upstream's default behavior.
        // Expand ~ for the become user if applicable.
        let home_base = if let Some(user) = become_user {
            format!("~{}/.ansible/tmp", user)
        } else {
            "~/.ansible/tmp".to_string()
        };

        let basedir = home_base;
        // Use mktemp --tmpdir=DIR to place the tempdir in the right location
        // without embedding directory separators in the template.
        let mkdir_and_mktemp = format!(
            "(mkdir -p {basedir} 2>/dev/null && mktemp -d --tmpdir={basedir} ansible-tmp-XXXXXX) || \
             (mkdir -p /tmp/.ansible/tmp 2>/dev/null && mktemp -d --tmpdir=/tmp/.ansible/tmp ansible-tmp-XXXXXX)",
            basedir = basedir,
        );

        let (rc, stdout, stderr) = conn.exec_command(&mkdir_and_mktemp, None).await?;

        if rc != 0 {
            return Err(PluginError::ExecutionError(format!(
                "failed to create remote tmpdir (rc={}): {}",
                rc,
                String::from_utf8_lossy(&stderr)
            )));
        }

        let path = String::from_utf8_lossy(&stdout).trim().to_string();
        if path.is_empty() {
            return Err(PluginError::ExecutionError(
                "remote tmpdir creation returned empty path".into(),
            ));
        }

        // Ensure the directory has the right permissions (0700).
        let chmod = format!("chmod 700 {}", ShPlugin::quote(&path));
        let _ = conn.exec_command(&chmod, None).await;

        Ok(Self {
            path: Some(PathBuf::from(path)),
        })
    }

    /// Return the remote temp directory path.
    pub fn path(&self) -> Option<&PathBuf> {
        self.path.as_ref()
    }

    /// Remove the temporary directory from the remote host.
    /// Best-effort: does not fail the task if cleanup fails.
    pub async fn cleanup(&self, conn: &(dyn ConnectionPlugin + Send + Sync)) {
        if let Some(ref path) = self.path {
            let shell = ShPlugin::default();
            let cmd = shell.remove(&path.display().to_string(), true);
            let _ = conn.exec_command(&cmd, None).await;
        }
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ansible_connection::local::LocalConnection;

    #[tokio::test]
    async fn test_create_and_cleanup_local() {
        let mut conn = LocalConnection::new();
        conn.connect().await.unwrap();

        let tmp = RemoteTmpDir::create(&conn, None).await.unwrap();
        let path = tmp.path().expect("should have a path");
        assert!(path.exists(), "tmpdir should exist: {:?}", path);
        assert!(
            path.display().to_string().contains("ansible-tmp"),
            "path should contain ansible-tmp: {:?}",
            path
        );

        // Verify permissions are 0700.
        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let mode = std::fs::metadata(path).unwrap().permissions().mode() & 0o777;
            assert_eq!(mode, 0o700, "tmpdir should be mode 0700");
        }

        tmp.cleanup(&conn).await;
        assert!(!path.exists(), "tmpdir should be cleaned up");
    }

    #[tokio::test]
    async fn test_create_returns_unique_paths() {
        let mut conn = LocalConnection::new();
        conn.connect().await.unwrap();

        let tmp1 = RemoteTmpDir::create(&conn, None).await.unwrap();
        let tmp2 = RemoteTmpDir::create(&conn, None).await.unwrap();

        assert_ne!(
            tmp1.path().unwrap(),
            tmp2.path().unwrap(),
            "each call should produce a unique path"
        );

        tmp1.cleanup(&conn).await;
        tmp2.cleanup(&conn).await;
    }
}
