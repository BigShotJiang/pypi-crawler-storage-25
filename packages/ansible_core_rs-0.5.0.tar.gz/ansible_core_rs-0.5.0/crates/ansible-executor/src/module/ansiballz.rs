use std::collections::HashSet;
use std::io::Write;
use std::path::{Path, PathBuf};

use ansible_utils::AnsibleValue;

use crate::ExecutorError;

/// The AnsiballZ module packager.
///
/// Packages a Python module + its module_utils dependencies into a
/// base64-encoded, self-extracting Python script suitable for
/// execution on a remote host.
///
/// This is the Rust equivalent of Python's `executor/module_common.py`
/// (1694 lines). The output format must be byte-compatible with the
/// Python version so that existing modules continue to work.
///
/// AnsiballZ format:
/// 1. A Python wrapper script that:
///    a. Extracts an embedded zip file
///    b. Sets up sys.path
///    c. Imports and runs the target module
/// 2. The zip file contains:
///    - The module source code
///    - All required module_utils
///    - A params JSON file with module arguments
pub struct AnsiballZPackager {
    /// Paths to search for module_utils.
    module_utils_paths: Vec<PathBuf>,
}

/// The shebang line for the wrapper script.
const SHEBANG: &str = "#!/usr/bin/python";

/// The AnsiballZ wrapper script template.
/// This Python script extracts and runs the packaged module.
const ANSIBALLZ_TEMPLATE: &str = r#"# -*- coding: utf-8 -*-
import os
import os.path
import sys
import base64
import json
import shutil
import tempfile
import zipfile

ANSIBALLZ_PARAMS = '{params_json}'

def invoke_module(modlib_path, temp_path, params):
    # Add module_utils to path
    sys.path.insert(0, modlib_path)

    # Write params
    args_path = os.path.join(temp_path, 'args')
    with open(args_path, 'w') as f:
        f.write(params)

    # Import and run the module
    from ansible.module_utils.basic import AnsibleModule
    import {module_fqn} as the_module

    # Set args file path for AnsibleModule
    os.environ['ANSIBLE_MODULE_ARGS'] = args_path

    the_module.main()

def main():
    temp_path = tempfile.mkdtemp(prefix='ansible_')
    try:
        # Decode and extract the zip
        zip_data = base64.b64decode(ANSIBALLZ_WRAPPER)
        zip_path = os.path.join(temp_path, 'ansible_module.zip')
        with open(zip_path, 'wb') as f:
            f.write(zip_data)

        # Extract
        modlib_path = os.path.join(temp_path, 'debug_dir')
        with zipfile.ZipFile(zip_path) as zf:
            zf.extractall(modlib_path)

        invoke_module(modlib_path, temp_path, ANSIBALLZ_PARAMS)
    finally:
        try:
            shutil.rmtree(temp_path)
        except Exception:
            pass

if __name__ == '__main__':
    main()
"#;

impl AnsiballZPackager {
    pub fn new(module_utils_paths: Vec<PathBuf>) -> Self {
        Self { module_utils_paths }
    }

    /// Package a module into an AnsiballZ self-extracting script.
    ///
    /// # Arguments
    /// * `module_path` - Path to the Python module source file
    /// * `module_args` - Arguments to pass to the module as JSON
    /// * `module_fqn` - Fully qualified module name (e.g., "ansible.modules.ping")
    ///
    /// # Returns
    /// The complete AnsiballZ wrapper script as bytes.
    pub fn package(
        &self,
        module_path: &Path,
        module_args: &AnsibleValue,
        module_fqn: &str,
    ) -> Result<Vec<u8>, ExecutorError> {
        // 1. Read the module source
        let module_source = std::fs::read(module_path)
            .map_err(|e| ExecutorError::TaskFailed(format!("failed to read module {}: {e}", module_path.display())))?;

        // 2. Scan for module_utils imports and collect dependencies
        let module_source_str = String::from_utf8_lossy(&module_source);
        let deps = self.find_module_utils_deps(&module_source_str)?;

        // 3. Create the zip archive in memory
        let zip_data = self.create_zip_archive(module_path, &module_source, module_fqn, &deps)?;

        // 4. Base64 encode the zip
        let b64_zip = base64::Engine::encode(
            &base64::engine::general_purpose::STANDARD,
            &zip_data,
        );

        // 5. Serialize module args
        let params_json = serde_json::to_string(module_args)
            .map_err(|e| ExecutorError::TaskFailed(format!("failed to serialize args: {e}")))?;
        // Escape single quotes for embedding in Python string literal
        let params_json = params_json.replace('\'', "\\'");

        // 6. Build the wrapper script
        let wrapper = format!(
            "{SHEBANG}\n{}\nANSIBALLZ_WRAPPER = '{b64_zip}'\n",
            ANSIBALLZ_TEMPLATE
                .replace("{params_json}", &params_json)
                .replace("{module_fqn}", module_fqn)
        );

        Ok(wrapper.into_bytes())
    }

    /// Find module_utils dependencies by scanning import statements.
    fn find_module_utils_deps(
        &self,
        module_source: &str,
    ) -> Result<Vec<(String, PathBuf)>, ExecutorError> {
        let mut deps = Vec::new();
        let mut seen = HashSet::new();

        for line in module_source.lines() {
            let line = line.trim();

            // Match: from ansible.module_utils.foo import bar
            // Match: import ansible.module_utils.foo
            let module_utils_name = if let Some(rest) = line.strip_prefix("from ansible.module_utils.") {
                rest.split_whitespace()
                    .next()
                    .map(|s| s.trim_end_matches('.'))
            } else if let Some(rest) = line.strip_prefix("import ansible.module_utils.") {
                Some(rest.split_whitespace().next().unwrap_or(rest))
            } else {
                None
            };

            if let Some(name) = module_utils_name {
                if seen.insert(name.to_string()) {
                    if let Some(path) = self.find_module_util(name) {
                        deps.push((name.to_string(), path));
                    }
                }
            }
        }

        Ok(deps)
    }

    /// Find a module_util file on the search paths.
    fn find_module_util(&self, name: &str) -> Option<PathBuf> {
        let file_name = format!("{}.py", name.replace('.', "/"));

        for search_path in &self.module_utils_paths {
            let candidate = search_path.join(&file_name);
            if candidate.is_file() {
                return Some(candidate);
            }

            // Also try as a package (directory with __init__.py)
            let parts: Vec<&str> = name.split('.').collect();
            let pkg_path = search_path.join(parts.join("/")).join("__init__.py");
            if pkg_path.is_file() {
                return Some(pkg_path);
            }
        }

        None
    }

    /// Create a zip archive containing the module and its dependencies.
    fn create_zip_archive(
        &self,
        _module_path: &Path,
        module_source: &[u8],
        module_fqn: &str,
        deps: &[(String, PathBuf)],
    ) -> Result<Vec<u8>, ExecutorError> {
        let mut buf = Vec::new();

        {
            let mut zip = zip::ZipWriter::new(std::io::Cursor::new(&mut buf));
            let options = zip::write::SimpleFileOptions::default()
                .compression_method(zip::CompressionMethod::Deflated);

            // Add the module itself
            let module_zip_path = module_fqn.replace('.', "/") + ".py";
            zip.start_file(&module_zip_path, options)
                .map_err(|e| ExecutorError::TaskFailed(format!("zip error: {e}")))?;
            zip.write_all(module_source)
                .map_err(|e| ExecutorError::TaskFailed(format!("zip write error: {e}")))?;

            // Add __init__.py for all parent packages
            let parts: Vec<&str> = module_fqn.split('.').collect();
            for i in 1..parts.len() {
                let init_path = parts[..i].join("/") + "/__init__.py";
                zip.start_file(&init_path, options)
                    .map_err(|e| ExecutorError::TaskFailed(format!("zip error: {e}")))?;
                zip.write_all(b"")
                    .map_err(|e| ExecutorError::TaskFailed(format!("zip write error: {e}")))?;
            }

            // Add module_utils dependencies
            for (name, path) in deps {
                let dep_source = std::fs::read(path).map_err(|e| {
                    ExecutorError::TaskFailed(format!(
                        "failed to read module_util {}: {e}",
                        path.display()
                    ))
                })?;
                let zip_path = format!("ansible/module_utils/{}.py", name.replace('.', "/"));
                zip.start_file(&zip_path, options)
                    .map_err(|e| ExecutorError::TaskFailed(format!("zip error: {e}")))?;
                zip.write_all(&dep_source)
                    .map_err(|e| ExecutorError::TaskFailed(format!("zip write error: {e}")))?;
            }

            zip.finish()
                .map_err(|e| ExecutorError::TaskFailed(format!("zip finish error: {e}")))?;
        }

        Ok(buf)
    }
}

// base64 re-export for the packager
mod base64 {
    pub use ::base64::*;
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_find_module_utils_imports() {
        let packager = AnsiballZPackager::new(vec![]);
        let source = r#"
from ansible.module_utils.basic import AnsibleModule
from ansible.module_utils.common.arg_spec import ArgumentSpecValidator
import ansible.module_utils.urls
import os
from collections import OrderedDict
"#;
        let deps = packager.find_module_utils_deps(source).unwrap();
        let names: Vec<&str> = deps.iter().map(|(n, _)| n.as_str()).collect();
        // Won't find files, but should parse correctly
        assert!(names.is_empty()); // No search paths configured
    }
}
