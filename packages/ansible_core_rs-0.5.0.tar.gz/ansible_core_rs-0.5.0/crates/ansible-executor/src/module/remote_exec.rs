//! Run an AnsiballZ wrapper script through a `ConnectionPlugin`.
//!
//! This is the bridge between [`crate::module::ansiballz::AnsiballZPackager`]
//! (which produces a self-extracting Python script) and the remote host: we
//! write the wrapper to a local temp file, `put_file` it to a remote staging
//! path, execute it through the connection's python interpreter, then clean
//! up. The same path works for local and ssh connections because the
//! `ConnectionPlugin` trait abstracts the transport.
//!
//! Supports two execution modes:
//! - **Standard**: upload module to remote tmpdir, execute, clean up
//! - **Pipelining**: send module via stdin (no file transfer, faster)

use std::io::Write;

use ansible_plugins::{ConnectionPlugin, PluginError};

use super::remote_tmp::RemoteTmpDir;

/// Result of running a packaged module on a remote host.
pub struct RemoteExecResult {
    pub rc: i32,
    pub stdout: Vec<u8>,
    pub stderr: Vec<u8>,
}

/// Stage `wrapper` on the remote side, execute it with `python_interpreter`,
/// and remove the staged file. Uses a proper remote tmpdir under
/// `~/.ansible/tmp/` instead of bare `/tmp`.
pub async fn run_ansiballz(
    conn: &mut (dyn ConnectionPlugin + Send),
    wrapper: &[u8],
    python_interpreter: &str,
) -> Result<RemoteExecResult, PluginError> {
    // 1. Write wrapper to a local temp file so put_file has something to upload.
    let mut local_tmp = tempfile::NamedTempFile::new()
        .map_err(|e| PluginError::ExecutionError(format!("tempfile: {e}")))?;
    local_tmp
        .write_all(wrapper)
        .map_err(|e| PluginError::ExecutionError(format!("tempfile write: {e}")))?;
    local_tmp
        .flush()
        .map_err(|e| PluginError::ExecutionError(format!("tempfile flush: {e}")))?;
    let local_path = local_tmp.path().to_path_buf();

    // 2. Create a proper remote tmpdir.
    let remote_tmp = RemoteTmpDir::create(conn, None).await?;
    let tmp_path = remote_tmp.path().ok_or_else(|| {
        PluginError::ExecutionError("remote tmpdir creation returned no path".into())
    })?;
    let remote_path = tmp_path.join("ansiballz_module.py");

    // 3. Upload.
    conn.put_file(&local_path, &remote_path).await?;

    // 4. Execute.
    let remote_s = remote_path.display().to_string();
    let cmd = format!("chmod +x {remote_s} && {python_interpreter} {remote_s}");
    let (rc, stdout, stderr) = conn.exec_command(&cmd, None).await?;

    // 5. Clean up the entire tmpdir.
    remote_tmp.cleanup(conn).await;

    Ok(RemoteExecResult { rc, stdout, stderr })
}

/// Execute an AnsiballZ wrapper via pipelining: send the module script
/// through stdin instead of uploading a file. This avoids the put_file
/// round trip and is significantly faster over SSH.
///
/// Requires the remote Python interpreter to accept a script on stdin
/// (which is standard behavior: `python3 -` reads from stdin).
pub async fn run_ansiballz_pipelined(
    conn: &(dyn ConnectionPlugin + Send + Sync),
    wrapper: &[u8],
    python_interpreter: &str,
) -> Result<RemoteExecResult, PluginError> {
    let cmd = format!("{python_interpreter} -");
    let (rc, stdout, stderr) = conn.exec_command(&cmd, Some(wrapper)).await?;
    Ok(RemoteExecResult { rc, stdout, stderr })
}

#[cfg(test)]
mod tests {
    use super::*;
    use ansible_connection::local::LocalConnection;

    /// Smoke test: run a trivial "python" script through LocalConnection,
    /// proving the put_file + exec + cleanup round trip via remote tmpdir.
    #[tokio::test]
    async fn test_run_ansiballz_roundtrip_local() {
        let wrapper = b"#!/bin/sh\necho '{\"changed\": false, \"msg\": \"ok\"}'\n";
        let mut conn = LocalConnection::new();
        conn.connect().await.unwrap();
        let res = run_ansiballz(&mut conn, wrapper, "/bin/sh").await.unwrap();
        assert_eq!(res.rc, 0);
        let out = String::from_utf8_lossy(&res.stdout);
        assert!(out.contains("\"changed\": false"), "stdout was: {out}");
    }

    /// Test pipelining: send the script via stdin instead of file upload.
    #[tokio::test]
    async fn test_run_ansiballz_pipelined_local() {
        let wrapper = b"#!/bin/sh\necho '{\"changed\": true, \"msg\": \"pipelined\"}'\n";
        let conn = LocalConnection::new();
        // LocalConnection doesn't require connect() for pipelining test
        let res = run_ansiballz_pipelined(&conn, wrapper, "/bin/sh").await.unwrap();
        assert_eq!(res.rc, 0);
        let out = String::from_utf8_lossy(&res.stdout);
        assert!(out.contains("\"changed\": true"), "stdout was: {out}");
        assert!(out.contains("pipelined"), "stdout was: {out}");
    }
}
