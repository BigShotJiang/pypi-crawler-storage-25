//! End-to-end Galaxy resolver + installer test using FilesystemFetcher.
//!
//! Builds two synthetic collections (a leaf and one that depends on it),
//! resolves them, installs them, and asserts the on-disk layout and the
//! checksum verification path.

use std::io::Write;
use std::path::Path;

use ansible_galaxy::{
    sha256_hex, CollectionRequirement, FilesystemFetcher, Installer, Resolver,
};
use flate2::write::GzEncoder;
use flate2::Compression;

fn build_tarball(manifest_json: &str) -> Vec<u8> {
    let mut buf: Vec<u8> = Vec::new();
    {
        let enc = GzEncoder::new(&mut buf, Compression::default());
        let mut tar = tar::Builder::new(enc);
        let bytes = manifest_json.as_bytes();
        let mut header = tar::Header::new_gnu();
        header.set_path("MANIFEST.json").unwrap();
        header.set_size(bytes.len() as u64);
        header.set_mode(0o644);
        header.set_cksum();
        tar.append(&header, bytes).unwrap();
        // A second file so the install layer has more than just MANIFEST.
        let pl = b"# placeholder\n";
        let mut h2 = tar::Header::new_gnu();
        h2.set_path("plugins/modules/noop.py").unwrap();
        h2.set_size(pl.len() as u64);
        h2.set_mode(0o644);
        h2.set_cksum();
        tar.append(&h2, &pl[..]).unwrap();
        tar.finish().unwrap();
    }
    buf
}

fn write_artifact(root: &Path, namespace: &str, name: &str, version: &str, bytes: &[u8]) {
    let dir = root.join(namespace).join(name);
    std::fs::create_dir_all(&dir).unwrap();
    let tar_path = dir.join(format!("{version}.tar.gz"));
    std::fs::write(&tar_path, bytes).unwrap();
    let mut sha = std::fs::File::create(dir.join(format!("{version}.sha256"))).unwrap();
    sha.write_all(sha256_hex(bytes).as_bytes()).unwrap();
}

#[tokio::test]
async fn test_resolve_install_with_dependency() {
    let index = tempfile::tempdir().unwrap();

    // Leaf collection: ns.dep v1.0.0, no dependencies of its own.
    let dep_manifest = r#"{
        "collection_info": {
            "namespace": "ns",
            "name": "dep",
            "version": "1.0.0"
        }
    }"#;
    let dep_bytes = build_tarball(dep_manifest);
    write_artifact(index.path(), "ns", "dep", "1.0.0", &dep_bytes);

    // Top-level collection that depends on the leaf.
    let top_manifest = r#"{
        "collection_info": {
            "namespace": "ns",
            "name": "top",
            "version": "2.1.3",
            "dependencies": {"ns.dep": ">=1.0.0,<2.0.0"}
        }
    }"#;
    let top_bytes = build_tarball(top_manifest);
    write_artifact(index.path(), "ns", "top", "2.1.3", &top_bytes);

    let fetcher = FilesystemFetcher::new(index.path());
    let resolver = Resolver::new(&fetcher);

    let plan = resolver
        .resolve(&[CollectionRequirement::any("ns.top").unwrap()])
        .await
        .unwrap();

    // Plan must contain both collections, and the dependency must come
    // before the dependent so the on-disk loader sees a consistent layout
    // mid-install.
    assert_eq!(plan.entries.len(), 2);
    let names: Vec<String> = plan.entries.iter().map(|e| e.collection.to_string()).collect();
    assert!(names.contains(&"ns.top".to_string()));
    assert!(names.contains(&"ns.dep".to_string()));

    // Install into a fresh root.
    let install_root = tempfile::tempdir().unwrap();
    let installer = Installer::new(&fetcher, install_root.path());
    installer.install(&plan).await.unwrap();

    let dep_dir = install_root
        .path()
        .join("ansible_collections/ns/dep");
    let top_dir = install_root
        .path()
        .join("ansible_collections/ns/top");
    assert!(dep_dir.join("MANIFEST.json").is_file());
    assert!(top_dir.join("plugins/modules/noop.py").is_file());
}

#[tokio::test]
async fn test_install_rejects_bad_checksum() {
    let index = tempfile::tempdir().unwrap();
    let manifest = r#"{
        "collection_info": {"namespace":"ns","name":"col","version":"0.1.0"}
    }"#;
    let bytes = build_tarball(manifest);
    let dir = index.path().join("ns").join("col");
    std::fs::create_dir_all(&dir).unwrap();
    std::fs::write(dir.join("0.1.0.tar.gz"), &bytes).unwrap();
    // Wrong sidecar checksum on purpose.
    std::fs::write(dir.join("0.1.0.sha256"), "deadbeef").unwrap();

    let fetcher = FilesystemFetcher::new(index.path());
    let resolver = Resolver::new(&fetcher);
    let plan = resolver
        .resolve(&[CollectionRequirement::any("ns.col").unwrap()])
        .await
        .unwrap();

    let install_root = tempfile::tempdir().unwrap();
    let installer = Installer::new(&fetcher, install_root.path());
    let err = installer.install(&plan).await.unwrap_err();
    let s = format!("{err}");
    assert!(s.contains("checksum mismatch"), "{s}");
}

#[tokio::test]
async fn test_resolver_picks_highest_satisfying_version() {
    let index = tempfile::tempdir().unwrap();
    for v in ["1.0.0", "1.2.0", "1.5.0", "2.0.0"] {
        let manifest = format!(
            r#"{{ "collection_info": {{"namespace":"ns","name":"col","version":"{v}"}} }}"#
        );
        let bytes = build_tarball(&manifest);
        write_artifact(index.path(), "ns", "col", v, &bytes);
    }
    let fetcher = FilesystemFetcher::new(index.path());
    let resolver = Resolver::new(&fetcher);
    let plan = resolver
        .resolve(&[CollectionRequirement::new("ns.col", ">=1.0.0,<2.0.0").unwrap()])
        .await
        .unwrap();
    assert_eq!(plan.entries.len(), 1);
    assert_eq!(plan.entries[0].version.to_string(), "1.5.0");
}
