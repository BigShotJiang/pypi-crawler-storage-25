//! Live Galaxy v3 API test against https://galaxy.ansible.com.
//!
//! This is an opt-in network test, gated on both:
//!   - the `network` cargo feature (so the test module compiles without reqwest)
//!   - the `ANSIBLE_GALAXY_LIVE_TEST=1` env var at runtime (so CI and
//!     offline dev environments skip the test cleanly)
//!
//! Run:
//!   ANSIBLE_GALAXY_LIVE_TEST=1 cargo test -p ansible-galaxy \
//!     --features network --test galaxy_v3_live -- --nocapture
//!
//! Covers Phase 8.4 "Galaxy v3 API fetcher tested against real galaxy.ansible.com":
//!   1. list_versions(community.general) returns a non-empty sorted list
//!   2. fetch(ansible.posix, pinned small version) downloads a valid
//!      collection tarball whose sha256 matches the one reported by the API

#![cfg(feature = "network")]

use ansible_galaxy::{Fetcher, GalaxyApiFetcher};
use semver::Version;
use sha2::{Digest, Sha256};

fn should_run() -> bool {
    std::env::var("ANSIBLE_GALAXY_LIVE_TEST").ok().as_deref() == Some("1")
}

#[tokio::test]
async fn list_versions_community_general() {
    if !should_run() {
        eprintln!("skipping: set ANSIBLE_GALAXY_LIVE_TEST=1 to enable");
        return;
    }

    let fetcher = GalaxyApiFetcher::default_galaxy();
    let versions = fetcher
        .list_versions("community", "general")
        .await
        .expect("list_versions should succeed for community.general");

    assert!(!versions.is_empty(), "community.general should have versions");
    assert!(
        versions.windows(2).all(|w| w[0] <= w[1]),
        "list_versions must return a sorted vec, got: {versions:?}"
    );

    let latest = versions.last().unwrap();
    assert!(
        latest.major >= 1,
        "community.general latest should be >= 1.0.0, got {latest}"
    );
    println!(
        "community.general: {} versions, latest {}",
        versions.len(),
        latest
    );
}

#[tokio::test]
async fn fetch_ansible_posix_verifies_checksum() {
    if !should_run() {
        eprintln!("skipping: set ANSIBLE_GALAXY_LIVE_TEST=1 to enable");
        return;
    }

    // Pick a small, stable, long-since-published version of ansible.posix to
    // avoid pulling a large tarball and to keep the test deterministic.
    let fetcher = GalaxyApiFetcher::default_galaxy();
    let pinned = Version::parse("1.5.4").unwrap();

    let artifact = fetcher
        .fetch("ansible", "posix", &pinned)
        .await
        .expect("fetch ansible.posix 1.5.4 should succeed");

    assert_eq!(artifact.namespace, "ansible");
    assert_eq!(artifact.name, "posix");
    assert_eq!(artifact.version, pinned);
    assert!(!artifact.bytes.is_empty(), "artifact bytes should not be empty");

    // tar.gz magic: starts with the gzip header 0x1f 0x8b.
    assert_eq!(
        &artifact.bytes[..2],
        &[0x1f, 0x8b],
        "artifact should be a gzipped tarball"
    );

    let server_sha = artifact
        .sha256
        .as_ref()
        .expect("Galaxy v3 API must report sha256 for artifact");
    let mut hasher = Sha256::new();
    hasher.update(&artifact.bytes);
    let computed = format!("{:x}", hasher.finalize());
    assert_eq!(
        &computed, server_sha,
        "downloaded bytes must hash to the sha256 reported by the API"
    );
    println!(
        "ansible.posix 1.5.4: {} bytes, sha256 {} verified",
        artifact.bytes.len(),
        server_sha
    );
}
