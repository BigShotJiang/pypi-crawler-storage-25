use thiserror::Error;

#[derive(Debug, Error)]
pub enum GalaxyError {
    #[error("galaxy API error: {0}")]
    ApiError(String),

    #[error("collection not found: {namespace}.{name}")]
    CollectionNotFound { namespace: String, name: String },

    #[error("no version of {namespace}.{name} satisfies {constraint}")]
    NoMatchingVersion {
        namespace: String,
        name: String,
        constraint: String,
    },

    #[error("dependency resolution failed: {0}")]
    DependencyResolutionFailed(String),

    #[error("invalid collection ref '{0}'")]
    InvalidRef(String),

    #[error("manifest error: {0}")]
    Manifest(String),

    #[error("checksum mismatch for {what}: expected {expected}, got {actual}")]
    ChecksumMismatch {
        what: String,
        expected: String,
        actual: String,
    },

    #[error(transparent)]
    Io(#[from] std::io::Error),

    #[error(transparent)]
    Semver(#[from] semver::Error),

    #[cfg(feature = "network")]
    #[error(transparent)]
    Http(#[from] reqwest::Error),
}
