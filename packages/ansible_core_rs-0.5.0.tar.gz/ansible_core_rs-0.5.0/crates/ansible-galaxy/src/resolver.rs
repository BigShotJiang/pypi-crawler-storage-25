//! Collection requirement parsing and dependency resolution.
//!
//! Given a list of top-level [`CollectionRequirement`]s and a [`Fetcher`],
//! the resolver walks each collection's `MANIFEST.json` dependency map,
//! picks the highest version that satisfies the strictest accumulated
//! constraint for each `namespace.name`, and emits a flat install plan
//! free of cycles.
//!
//! Approach: classic depth-first walk with a `seen` map. When we encounter
//! a collection we've already resolved, we tighten its constraint and
//! re-resolve only if the previously chosen version no longer satisfies.
//! This is intentionally simpler than a full SAT solver — Galaxy graphs in
//! practice are tiny and shallow, and the failure mode (over-constrained)
//! produces a clear error.

use std::collections::BTreeMap;
use std::io::Read;

use semver::{Version, VersionReq};

use crate::fetcher::Fetcher;
use crate::manifest::parse_manifest;
use crate::GalaxyError;

/// `namespace.name` identifier for a collection.
#[derive(Debug, Clone, PartialEq, Eq, Hash, PartialOrd, Ord)]
pub struct CollectionRef {
    pub namespace: String,
    pub name: String,
}

impl CollectionRef {
    /// Parse a `namespace.name` string. Rejects anything that doesn't have
    /// exactly one dot or has empty halves.
    pub fn parse(s: &str) -> Result<Self, GalaxyError> {
        let (ns, name) = s
            .split_once('.')
            .ok_or_else(|| GalaxyError::InvalidRef(s.into()))?;
        if ns.is_empty() || name.is_empty() || name.contains('.') {
            return Err(GalaxyError::InvalidRef(s.into()));
        }
        Ok(Self {
            namespace: ns.into(),
            name: name.into(),
        })
    }
}

impl std::fmt::Display for CollectionRef {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}.{}", self.namespace, self.name)
    }
}

/// A user-facing requirement: which collection, and (optionally) a version
/// constraint as accepted by `semver::VersionReq` (e.g. `>=1.0,<2.0`).
#[derive(Debug, Clone)]
pub struct CollectionRequirement {
    pub collection: CollectionRef,
    pub version_req: VersionReq,
}

impl CollectionRequirement {
    pub fn new(name: &str, req: &str) -> Result<Self, GalaxyError> {
        Ok(Self {
            collection: CollectionRef::parse(name)?,
            version_req: VersionReq::parse(req)?,
        })
    }

    /// Convenience: any version.
    pub fn any(name: &str) -> Result<Self, GalaxyError> {
        Self::new(name, "*")
    }
}

/// One resolved entry in the install plan.
#[derive(Debug, Clone)]
pub struct ResolvedCollection {
    pub collection: CollectionRef,
    pub version: Version,
}

/// Ordered list of collections to install. Topologically sorted so that
/// dependencies appear before their dependents.
#[derive(Debug, Default)]
pub struct InstallPlan {
    pub entries: Vec<ResolvedCollection>,
}

/// The resolver itself. Stateless apart from the borrowed fetcher; create
/// a fresh one per resolve call.
pub struct Resolver<'a, F: Fetcher + ?Sized> {
    fetcher: &'a F,
}

impl<'a, F: Fetcher + ?Sized> Resolver<'a, F> {
    pub fn new(fetcher: &'a F) -> Self {
        Self { fetcher }
    }

    /// Resolve a list of top-level requirements into an [`InstallPlan`].
    pub async fn resolve(
        &self,
        roots: &[CollectionRequirement],
    ) -> Result<InstallPlan, GalaxyError> {
        // Constraints accumulated per collection. We store them as a Vec
        // of VersionReq because semver doesn't merge requirements; we
        // pick the highest version that satisfies all of them.
        let mut constraints: BTreeMap<CollectionRef, Vec<VersionReq>> = BTreeMap::new();
        for r in roots {
            constraints
                .entry(r.collection.clone())
                .or_default()
                .push(r.version_req.clone());
        }

        // Resolved entries in the order they were finalized.
        let mut resolved: BTreeMap<CollectionRef, Version> = BTreeMap::new();
        let mut order: Vec<CollectionRef> = Vec::new();

        // Worklist of collections still to process. We re-push when a new
        // constraint invalidates a prior choice.
        let mut work: Vec<CollectionRef> = constraints.keys().cloned().collect();
        let mut depth_guard = 0usize;

        while let Some(cref) = work.pop() {
            depth_guard += 1;
            if depth_guard > 10_000 {
                return Err(GalaxyError::DependencyResolutionFailed(
                    "resolver exceeded depth guard — likely a constraint cycle".into(),
                ));
            }

            // Pick the highest version satisfying every accumulated req.
            let reqs = constraints.get(&cref).cloned().unwrap_or_default();
            let mut versions = self
                .fetcher
                .list_versions(&cref.namespace, &cref.name)
                .await?;
            versions.sort();
            let chosen = versions
                .into_iter()
                .rev()
                .find(|v| reqs.iter().all(|r| r.matches(v)))
                .ok_or_else(|| GalaxyError::NoMatchingVersion {
                    namespace: cref.namespace.clone(),
                    name: cref.name.clone(),
                    constraint: format_reqs(&reqs),
                })?;

            // If we already chose this same version, no need to re-walk.
            if resolved.get(&cref) == Some(&chosen) {
                continue;
            }

            resolved.insert(cref.clone(), chosen.clone());
            if !order.contains(&cref) {
                order.push(cref.clone());
            }

            // Fetch the artifact, peek inside for its MANIFEST, and queue
            // any newly-discovered dependencies. We deliberately re-fetch
            // here even though the installer will fetch again — phase 8 v0
            // optimizes for clarity, not bandwidth.
            let art = self.fetcher.fetch(&cref.namespace, &cref.name, &chosen).await?;
            let manifest = read_manifest_from_tarball(&art.bytes)?;
            for (dep_name, dep_req) in &manifest.dependencies {
                let dep_ref = CollectionRef::parse(dep_name)?;
                let dep_versionreq = VersionReq::parse(dep_req)?;
                let entry = constraints.entry(dep_ref.clone()).or_default();
                if !entry.iter().any(|r| r == &dep_versionreq) {
                    entry.push(dep_versionreq);
                    // Re-evaluate this dep — if it was already resolved
                    // the new constraint may demand a different version.
                    work.push(dep_ref);
                }
            }
        }

        // Re-emit in the order we first finalized things, but place
        // dependencies before dependents. Because we walked depth-first
        // and only appended on first encounter, `order` is already a
        // valid topological listing under the simple semantics here.
        let entries = order
            .into_iter()
            .map(|cref| ResolvedCollection {
                version: resolved.remove(&cref).unwrap(),
                collection: cref,
            })
            .collect();
        Ok(InstallPlan { entries })
    }
}

fn format_reqs(reqs: &[VersionReq]) -> String {
    reqs.iter()
        .map(|r| r.to_string())
        .collect::<Vec<_>>()
        .join(" && ")
}

/// Pull `MANIFEST.json` out of a gzipped tarball without extracting the
/// whole archive. Used by the resolver to read the dependency graph.
fn read_manifest_from_tarball(bytes: &[u8]) -> Result<crate::CollectionManifest, GalaxyError> {
    use flate2::read::GzDecoder;
    use tar::Archive;

    let dec = GzDecoder::new(bytes);
    let mut archive = Archive::new(dec);
    for entry in archive.entries()? {
        let mut entry = entry?;
        let path = entry.path()?.into_owned();
        // MANIFEST.json may be at the archive root or inside a top-level
        // directory; accept either.
        let is_manifest = path.file_name().map(|f| f == "MANIFEST.json").unwrap_or(false);
        if is_manifest {
            let mut buf = String::new();
            entry.read_to_string(&mut buf)?;
            return parse_manifest(&buf);
        }
    }
    Err(GalaxyError::Manifest(
        "MANIFEST.json not found in tarball".into(),
    ))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_collection_ref() {
        let r = CollectionRef::parse("community.general").unwrap();
        assert_eq!(r.namespace, "community");
        assert_eq!(r.name, "general");
        assert!(CollectionRef::parse("nodot").is_err());
        assert!(CollectionRef::parse("a.b.c").is_err());
        assert!(CollectionRef::parse(".empty").is_err());
    }

    #[test]
    fn test_requirement_constructors() {
        let r = CollectionRequirement::new("ns.col", ">=1.0").unwrap();
        assert!(r.version_req.matches(&Version::parse("1.5.0").unwrap()));
        assert!(!r.version_req.matches(&Version::parse("0.9.0").unwrap()));
        let any = CollectionRequirement::any("ns.col").unwrap();
        assert!(any.version_req.matches(&Version::parse("99.0.0").unwrap()));
    }
}
