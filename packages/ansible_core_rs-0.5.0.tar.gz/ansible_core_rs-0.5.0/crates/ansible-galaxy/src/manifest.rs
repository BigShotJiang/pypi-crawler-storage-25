//! MANIFEST.json / galaxy.yml parsing.
//!
//! Every collection tarball ships a `MANIFEST.json` at its root that
//! describes the collection's identity, version, and dependencies.
//! Newer-style collections use `galaxy.yml` as the source-of-truth and
//! generate `MANIFEST.json` at build time. We accept both forms because
//! the resolver may need to read the dependency graph from either.

use std::collections::BTreeMap;

use serde::Deserialize;

use crate::GalaxyError;

#[derive(Debug, Clone, Deserialize)]
pub struct CollectionManifest {
    pub namespace: String,
    pub name: String,
    pub version: String,
    /// `namespace.name` → version constraint string. We keep these as raw
    /// strings; the resolver parses them into `semver::VersionReq`.
    #[serde(default)]
    pub dependencies: BTreeMap<String, String>,
}

/// Parse a `MANIFEST.json` body into a [`CollectionManifest`].
///
/// The on-disk shape is `{"collection_info": {...}}`. We unwrap that
/// envelope here so callers see a flat struct.
pub fn parse_manifest(body: &str) -> Result<CollectionManifest, GalaxyError> {
    #[derive(Deserialize)]
    struct ManifestEnvelope {
        collection_info: CollectionManifest,
    }
    // Try the envelope shape first; fall back to a flat object so test
    // fixtures and `galaxy.yml`-style inputs work too.
    if let Ok(env) = serde_json::from_str::<ManifestEnvelope>(body) {
        return Ok(env.collection_info);
    }
    serde_json::from_str::<CollectionManifest>(body)
        .map_err(|e| GalaxyError::Manifest(format!("parse: {e}")))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_envelope_shape() {
        let body = r#"{
            "collection_info": {
                "namespace": "ns",
                "name": "col",
                "version": "1.2.3",
                "dependencies": {"ns.dep": ">=0.1.0,<1.0.0"}
            }
        }"#;
        let m = parse_manifest(body).unwrap();
        assert_eq!(m.namespace, "ns");
        assert_eq!(m.version, "1.2.3");
        assert_eq!(m.dependencies.len(), 1);
    }

    #[test]
    fn test_parse_flat_shape() {
        let body = r#"{"namespace":"ns","name":"col","version":"0.1.0"}"#;
        let m = parse_manifest(body).unwrap();
        assert_eq!(m.dependencies.len(), 0);
    }
}
