//! Galaxy client and collection management for ansible-core-rs.
//!
//! Phase 8 of the migration plan. This crate is the Rust replacement for
//! `ansible-galaxy collection install` — fetching collection tarballs from
//! a Galaxy v3 API, resolving dependency graphs, validating SHA256 sums,
//! and unpacking them into the standard `~/.ansible/collections/ansible_collections`
//! layout that the rest of `ansible-core-rs` already reads from.
//!
//! ## Architecture
//!
//! The HTTP layer is abstracted behind a [`Fetcher`] trait so the rest of
//! the crate (resolver, installer, manifest validation) is fully testable
//! offline. A real network-backed fetcher lives behind the `network` cargo
//! feature; the [`FilesystemFetcher`] used in tests serves tarballs from a
//! directory on disk and is structurally identical from the resolver's
//! point of view.
//!
//! ## What's implemented in this slice
//!
//! - [`CollectionRef`] / [`CollectionRequirement`] parsing (`namespace.name`,
//!   optional version constraint).
//! - [`Fetcher`] trait + [`FilesystemFetcher`] reference impl.
//! - [`Resolver`] — depth-first walk over `meta/runtime.yml` `dependencies`
//!   that produces a flat install plan, picking the highest version that
//!   satisfies all encountered constraints.
//! - [`Installer`] — extracts a tarball into the standard layout and
//!   verifies the SHA256 if one is provided.
//! - SHA256 helpers and a tiny galaxy.yml/MANIFEST.json parser.
//!
//! What is *not* in this slice (deferred): signing/keyring verification,
//! Galaxy v2 fallback, the `ansible-galaxy role` subcommands, and the
//! interactive CLI itself.

pub mod error;
pub mod fetcher;
pub mod manifest;
pub mod resolver;
pub mod installer;
pub mod router;

pub use error::GalaxyError;
pub use fetcher::{CollectionArtifact, Fetcher, FilesystemFetcher};
#[cfg(feature = "network")]
pub use fetcher::GalaxyApiFetcher;
pub use manifest::{CollectionManifest, parse_manifest};
pub use resolver::{
    CollectionRef, CollectionRequirement, InstallPlan, ResolvedCollection, Resolver,
};
pub use installer::Installer;
pub use router::{CollectionRouter, Fqcn, PluginType};

/// Compute the SHA256 of a byte slice as a lowercase hex string.
pub fn sha256_hex(data: &[u8]) -> String {
    use sha2::{Digest, Sha256};
    let mut h = Sha256::new();
    h.update(data);
    format!("{:x}", h.finalize())
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn test_sha256_hex_known_vector() {
        // Empty input → well-known constant.
        assert_eq!(
            sha256_hex(b""),
            "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"
        );
    }
}
