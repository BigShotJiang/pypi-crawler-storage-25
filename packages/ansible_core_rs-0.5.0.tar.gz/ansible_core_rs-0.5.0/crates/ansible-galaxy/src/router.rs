//! Runtime collection router — resolves FQCNs to on-disk plugin files.
//!
//! Mirrors the subset of `lib/ansible/collections/` that matters at
//! playbook runtime: given a plugin type and a fully-qualified collection
//! name (FQCN) like `community.general.ini_file`, find the file that
//! implements it. The [`Installer`] places collections into
//! `<root>/ansible_collections/<namespace>/<name>/`, and this router walks
//! the standard `plugins/<type>/` subtree underneath that.
//!
//! Scope of this slice:
//! - Multiple collection roots, searched in order (mirrors
//!   `ANSIBLE_COLLECTIONS_PATH`).
//! - FQCN resolution for all plugin types with a canonical subdirectory
//!   (`modules`, `action`, `filter`, `lookup`, `callback`, `inventory`,
//!   `connection`, `cache`, `strategy`, `vars`, `test`, `become`,
//!   `cliconf`, `httpapi`, `netconf`, `terminal`).
//! - Both `.py` and `.yml` (redirect stubs) extensions are accepted for
//!   modules; other plugin types fall back to `.py`.
//! - `short_name` lookup: given `community.general`, list the modules it
//!   ships. Used by the `ansible-doc`-style surface and by tests.
//!
//! Out of scope (deferred): meta/runtime.yml redirects, plugin overrides
//! via collection action groups, signature verification at load time.

use std::collections::HashMap;
use std::path::{Path, PathBuf};

use crate::GalaxyError;

/// Every ansible plugin type we know how to route. The string form is the
/// subdirectory name under `plugins/` inside a collection.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub enum PluginType {
    Module,
    Action,
    Filter,
    Lookup,
    Callback,
    Inventory,
    Connection,
    Cache,
    Strategy,
    Vars,
    Test,
    Become,
    Cliconf,
    Httpapi,
    Netconf,
    Terminal,
}

impl PluginType {
    /// Subdirectory under `plugins/` where this plugin type lives on disk.
    pub fn subdir(self) -> &'static str {
        match self {
            PluginType::Module => "modules",
            PluginType::Action => "action",
            PluginType::Filter => "filter",
            PluginType::Lookup => "lookup",
            PluginType::Callback => "callback",
            PluginType::Inventory => "inventory",
            PluginType::Connection => "connection",
            PluginType::Cache => "cache",
            PluginType::Strategy => "strategy",
            PluginType::Vars => "vars",
            PluginType::Test => "test",
            PluginType::Become => "become",
            PluginType::Cliconf => "cliconf",
            PluginType::Httpapi => "httpapi",
            PluginType::Netconf => "netconf",
            PluginType::Terminal => "terminal",
        }
    }
}

/// Parsed FQCN: `namespace.name.short_name` (short_name may contain dots,
/// e.g. subdirectory paths like `cloud.aws.ec2`).
#[derive(Debug, Clone, PartialEq, Eq)]
pub struct Fqcn {
    pub namespace: String,
    pub name: String,
    pub short_name: String,
}

impl Fqcn {
    /// Parse an `ns.col.plugin` string. Requires at least three dot-separated
    /// segments; everything after the second dot becomes `short_name` and
    /// may itself contain dots (mapped to directory separators on disk).
    pub fn parse(s: &str) -> Result<Self, GalaxyError> {
        let mut it = s.splitn(3, '.');
        let ns = it.next().unwrap_or("");
        let name = it.next().unwrap_or("");
        let short = it.next().unwrap_or("");
        if ns.is_empty() || name.is_empty() || short.is_empty() {
            return Err(GalaxyError::InvalidRef(s.into()));
        }
        Ok(Self {
            namespace: ns.into(),
            name: name.into(),
            short_name: short.into(),
        })
    }
}

impl std::fmt::Display for Fqcn {
    fn fmt(&self, f: &mut std::fmt::Formatter<'_>) -> std::fmt::Result {
        write!(f, "{}.{}.{}", self.namespace, self.name, self.short_name)
    }
}

/// Resolves FQCNs to on-disk plugin files.
///
/// A router holds an ordered list of collection roots — e.g.
/// `~/.ansible/collections`, `/usr/share/ansible/collections` — and walks
/// them in order. The first match wins, matching ansible's
/// `ANSIBLE_COLLECTIONS_PATH` precedence.
#[derive(Debug, Default)]
pub struct CollectionRouter {
    /// Each root is the parent of `ansible_collections/`. This mirrors how
    /// the installer lays things out so a freshly-installed root plugs
    /// straight into a router.
    roots: Vec<PathBuf>,
}

impl CollectionRouter {
    pub fn new() -> Self {
        Self::default()
    }

    /// Return a reference to the configured collection roots.
    pub fn roots(&self) -> &[PathBuf] {
        &self.roots
    }

    /// Add a root (the parent of `ansible_collections/`). Later additions
    /// are searched after earlier ones.
    pub fn add_root(&mut self, root: impl Into<PathBuf>) -> &mut Self {
        self.roots.push(root.into());
        self
    }

    /// Build a router from `ANSIBLE_COLLECTIONS_PATH` (colon-separated),
    /// falling back to the two conventional locations if the env var is
    /// unset.
    pub fn from_env() -> Self {
        let mut r = Self::new();
        if let Ok(paths) = std::env::var("ANSIBLE_COLLECTIONS_PATH") {
            for p in paths.split(':').filter(|s| !s.is_empty()) {
                r.add_root(p);
            }
            return r;
        }
        if let Some(home) = std::env::var_os("HOME") {
            r.add_root(PathBuf::from(home).join(".ansible/collections"));
        }
        r.add_root("/usr/share/ansible/collections");
        r
    }

    /// Resolve `fqcn` to the plugin file on disk, if one exists.
    ///
    /// For modules we try `.py` then `.yml` (redirect stubs); for everything
    /// else we only look for `.py`. A dotted `short_name` is split on dots
    /// into directory components so `cloud.aws.ec2` becomes `cloud/aws/ec2.py`.
    pub fn resolve_fqcn(
        &self,
        fqcn: &Fqcn,
        plugin_type: PluginType,
    ) -> Result<PathBuf, GalaxyError> {
        let subdir = plugin_type.subdir();
        let rel: PathBuf = fqcn.short_name.split('.').collect();
        let candidates: &[&str] = if plugin_type == PluginType::Module {
            &["py", "yml"]
        } else {
            &["py"]
        };
        for root in &self.roots {
            let base = root
                .join("ansible_collections")
                .join(&fqcn.namespace)
                .join(&fqcn.name)
                .join("plugins")
                .join(subdir)
                .join(&rel);
            for ext in candidates {
                let candidate = base.with_extension(ext);
                if candidate.is_file() {
                    return Ok(candidate);
                }
            }
        }
        Err(GalaxyError::CollectionNotFound {
            namespace: fqcn.namespace.clone(),
            name: fqcn.name.clone(),
        })
    }

    /// List every plugin of `plugin_type` shipped by `namespace.name`,
    /// keyed by short_name. Useful for doc tooling and for test fixtures
    /// that assert a collection exposes the expected surface.
    pub fn list_plugins(
        &self,
        namespace: &str,
        name: &str,
        plugin_type: PluginType,
    ) -> Result<HashMap<String, PathBuf>, GalaxyError> {
        let mut out = HashMap::new();
        for root in &self.roots {
            let dir = root
                .join("ansible_collections")
                .join(namespace)
                .join(name)
                .join("plugins")
                .join(plugin_type.subdir());
            if !dir.is_dir() {
                continue;
            }
            walk_plugin_dir(&dir, &dir, &mut out);
        }
        if out.is_empty() {
            return Err(GalaxyError::CollectionNotFound {
                namespace: namespace.into(),
                name: name.into(),
            });
        }
        Ok(out)
    }
}

fn walk_plugin_dir(base: &Path, dir: &Path, out: &mut HashMap<String, PathBuf>) {
    let Ok(iter) = std::fs::read_dir(dir) else {
        return;
    };
    for entry in iter.flatten() {
        let path = entry.path();
        if path.is_dir() {
            walk_plugin_dir(base, &path, out);
            continue;
        }
        let ext_ok = path
            .extension()
            .and_then(|e| e.to_str())
            .map(|e| e == "py" || e == "yml")
            .unwrap_or(false);
        if !ext_ok {
            continue;
        }
        let Ok(rel) = path.strip_prefix(base) else {
            continue;
        };
        // Drop the extension and rebuild a dotted short_name from the
        // relative path components.
        let stem = rel.with_extension("");
        let parts: Vec<String> = stem
            .components()
            .filter_map(|c| c.as_os_str().to_str().map(str::to_owned))
            .collect();
        if parts.is_empty() {
            continue;
        }
        // First-found wins (earlier roots take precedence).
        out.entry(parts.join(".")).or_insert(path);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    fn touch(p: &Path) {
        std::fs::create_dir_all(p.parent().unwrap()).unwrap();
        std::fs::write(p, "").unwrap();
    }

    #[test]
    fn test_parse_fqcn() {
        let f = Fqcn::parse("community.general.ini_file").unwrap();
        assert_eq!(f.namespace, "community");
        assert_eq!(f.name, "general");
        assert_eq!(f.short_name, "ini_file");
        // Nested short_name is allowed.
        let f = Fqcn::parse("cloud.aws.ec2.instance").unwrap();
        assert_eq!(f.short_name, "ec2.instance");
        // Too few segments is a hard error.
        assert!(Fqcn::parse("too.short").is_err());
        assert!(Fqcn::parse("empty..short").is_err());
    }

    #[test]
    fn test_resolve_module_and_filter() {
        let tmp = tempfile::tempdir().unwrap();
        let root = tmp.path();
        let col = root
            .join("ansible_collections/community/general/plugins");
        touch(&col.join("modules/ini_file.py"));
        touch(&col.join("filter/hash_filter.py"));

        let mut r = CollectionRouter::new();
        r.add_root(root);
        let mf = r
            .resolve_fqcn(
                &Fqcn::parse("community.general.ini_file").unwrap(),
                PluginType::Module,
            )
            .unwrap();
        assert!(mf.ends_with("modules/ini_file.py"));
        let ff = r
            .resolve_fqcn(
                &Fqcn::parse("community.general.hash_filter").unwrap(),
                PluginType::Filter,
            )
            .unwrap();
        assert!(ff.ends_with("filter/hash_filter.py"));
    }

    #[test]
    fn test_resolve_nested_short_name() {
        let tmp = tempfile::tempdir().unwrap();
        let root = tmp.path();
        touch(
            &root.join("ansible_collections/cloud/aws/plugins/modules/ec2/instance.py"),
        );
        let mut r = CollectionRouter::new();
        r.add_root(root);
        let resolved = r
            .resolve_fqcn(
                &Fqcn::parse("cloud.aws.ec2.instance").unwrap(),
                PluginType::Module,
            )
            .unwrap();
        assert!(resolved.ends_with("modules/ec2/instance.py"));
    }

    #[test]
    fn test_first_root_wins() {
        let a = tempfile::tempdir().unwrap();
        let b = tempfile::tempdir().unwrap();
        touch(
            &a.path()
                .join("ansible_collections/ns/col/plugins/modules/dup.py"),
        );
        touch(
            &b.path()
                .join("ansible_collections/ns/col/plugins/modules/dup.py"),
        );
        let mut r = CollectionRouter::new();
        r.add_root(a.path());
        r.add_root(b.path());
        let resolved = r
            .resolve_fqcn(
                &Fqcn::parse("ns.col.dup").unwrap(),
                PluginType::Module,
            )
            .unwrap();
        assert!(resolved.starts_with(a.path()));
    }

    #[test]
    fn test_list_plugins_includes_nested() {
        let tmp = tempfile::tempdir().unwrap();
        let root = tmp.path();
        let mods =
            root.join("ansible_collections/ns/col/plugins/modules");
        touch(&mods.join("top.py"));
        touch(&mods.join("sub/nested.py"));
        touch(&mods.join("README.md")); // ignored

        let mut r = CollectionRouter::new();
        r.add_root(root);
        let list = r.list_plugins("ns", "col", PluginType::Module).unwrap();
        assert_eq!(list.len(), 2);
        assert!(list.contains_key("top"));
        assert!(list.contains_key("sub.nested"));
    }

    #[test]
    fn test_missing_collection_errors() {
        let tmp = tempfile::tempdir().unwrap();
        let mut r = CollectionRouter::new();
        r.add_root(tmp.path());
        let err = r
            .resolve_fqcn(
                &Fqcn::parse("ns.col.none").unwrap(),
                PluginType::Module,
            )
            .unwrap_err();
        matches!(err, GalaxyError::CollectionNotFound { .. });
    }
}
