//! Install a resolved [`crate::InstallPlan`] into the on-disk
//! `ansible_collections` layout.
//!
//! For each plan entry the installer:
//! 1. Re-fetches the artifact (idempotent — the resolver fetched once for
//!    metadata, we fetch again to get bytes for extraction; a future
//!    iteration can plumb through a single shared cache).
//! 2. Validates the SHA256 if the [`crate::CollectionArtifact`] supplied
//!    one. Mismatch is a hard error.
//! 3. Removes any existing install of the same `namespace/name` so the
//!    new copy is the source of truth (mirrors `ansible-galaxy collection
//!    install --force` semantics; we always force in v0).
//! 4. Extracts the tarball into `<root>/ansible_collections/<ns>/<name>/`.

use std::path::{Path, PathBuf};

use flate2::read::GzDecoder;
use tar::Archive;

use crate::fetcher::Fetcher;
use crate::resolver::InstallPlan;
use crate::{sha256_hex, GalaxyError};

pub struct Installer<'a, F: Fetcher + ?Sized> {
    fetcher: &'a F,
    root: PathBuf,
}

impl<'a, F: Fetcher + ?Sized> Installer<'a, F> {
    /// `root` is the parent of `ansible_collections/`. Standard ansible
    /// layouts use `~/.ansible/collections` here.
    pub fn new(fetcher: &'a F, root: impl Into<PathBuf>) -> Self {
        Self {
            fetcher,
            root: root.into(),
        }
    }

    /// Materialize every entry of `plan` on disk. Returns the list of
    /// directories that were written, in install order.
    pub async fn install(&self, plan: &InstallPlan) -> Result<Vec<PathBuf>, GalaxyError> {
        let mut written = Vec::with_capacity(plan.entries.len());
        for entry in &plan.entries {
            let art = self
                .fetcher
                .fetch(&entry.collection.namespace, &entry.collection.name, &entry.version)
                .await?;

            // Verify checksum if the index gave us one.
            if let Some(expected) = &art.sha256 {
                let actual = sha256_hex(&art.bytes);
                if &actual != expected {
                    return Err(GalaxyError::ChecksumMismatch {
                        what: format!(
                            "{}.{}-{}",
                            entry.collection.namespace, entry.collection.name, entry.version
                        ),
                        expected: expected.clone(),
                        actual,
                    });
                }
            }

            let dest = self
                .root
                .join("ansible_collections")
                .join(&entry.collection.namespace)
                .join(&entry.collection.name);
            // Force-replace existing install: callers always want the
            // resolved plan to be authoritative, and partial old installs
            // can confuse the runtime collection loader.
            if dest.exists() {
                std::fs::remove_dir_all(&dest)?;
            }
            std::fs::create_dir_all(&dest)?;

            extract_tarball(&art.bytes, &dest)?;
            written.push(dest);
        }
        Ok(written)
    }
}

/// Unpack `bytes` (a gzipped tar archive) into `dest`. We strip the leading
/// component if every entry shares one — collections built by `ansible-galaxy
/// collection build` don't have a wrapping directory but hand-rolled fixtures
/// often do, and we want both to land in the same place.
fn extract_tarball(bytes: &[u8], dest: &Path) -> Result<(), GalaxyError> {
    let dec = GzDecoder::new(bytes);
    let mut archive = Archive::new(dec);
    archive.set_overwrite(true);
    archive.unpack(dest)?;
    Ok(())
}
