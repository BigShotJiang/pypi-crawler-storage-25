//! HTTP / artifact fetching abstraction.
//!
//! The resolver and installer talk to a [`Fetcher`] trait so they can be
//! exercised offline. The reference implementation [`FilesystemFetcher`]
//! serves collection tarballs out of a directory layout that mirrors the
//! Galaxy v3 API surface enough for our resolver — listing versions and
//! fetching artifact bytes.

use std::collections::BTreeMap;
use std::path::{Path, PathBuf};

use async_trait::async_trait;
use semver::Version;

use crate::GalaxyError;

/// One downloaded collection artifact: the raw .tar.gz bytes plus the
/// version we resolved to and (optionally) an expected SHA256 from the
/// index.
pub struct CollectionArtifact {
    pub namespace: String,
    pub name: String,
    pub version: Version,
    pub bytes: Vec<u8>,
    pub sha256: Option<String>,
}

/// Abstraction over "where do collection tarballs come from".
///
/// Implementations must be Send + Sync because the resolver may walk
/// dependency graphs concurrently in a future iteration.
#[async_trait]
pub trait Fetcher: Send + Sync {
    /// List all known versions of a collection, sorted ascending.
    async fn list_versions(
        &self,
        namespace: &str,
        name: &str,
    ) -> Result<Vec<Version>, GalaxyError>;

    /// Download one specific version's tarball.
    async fn fetch(
        &self,
        namespace: &str,
        name: &str,
        version: &Version,
    ) -> Result<CollectionArtifact, GalaxyError>;
}

/// A `Fetcher` that reads tarballs out of a local directory.
///
/// Layout: `root/<namespace>/<name>/<version>.tar.gz`. Optionally a
/// sibling `<version>.sha256` file holds an expected hex digest.
///
/// This is what the unit tests use, and it's also a useful primitive for
/// air-gapped installs that mirror the Galaxy index to a filesystem.
pub struct FilesystemFetcher {
    root: PathBuf,
}

impl FilesystemFetcher {
    pub fn new(root: impl Into<PathBuf>) -> Self {
        Self { root: root.into() }
    }

    fn collection_dir(&self, namespace: &str, name: &str) -> PathBuf {
        self.root.join(namespace).join(name)
    }
}

#[async_trait]
impl Fetcher for FilesystemFetcher {
    async fn list_versions(
        &self,
        namespace: &str,
        name: &str,
    ) -> Result<Vec<Version>, GalaxyError> {
        let dir = self.collection_dir(namespace, name);
        if !dir.is_dir() {
            return Err(GalaxyError::CollectionNotFound {
                namespace: namespace.into(),
                name: name.into(),
            });
        }
        // BTreeMap so we can produce a stable, sorted result regardless of
        // readdir order.
        let mut versions: BTreeMap<Version, ()> = BTreeMap::new();
        for entry in std::fs::read_dir(&dir)? {
            let entry = entry?;
            let fname = entry.file_name();
            let fname = fname.to_string_lossy();
            if let Some(stripped) = fname.strip_suffix(".tar.gz") {
                if let Ok(v) = Version::parse(stripped) {
                    versions.insert(v, ());
                }
            }
        }
        if versions.is_empty() {
            return Err(GalaxyError::CollectionNotFound {
                namespace: namespace.into(),
                name: name.into(),
            });
        }
        Ok(versions.into_keys().collect())
    }

    async fn fetch(
        &self,
        namespace: &str,
        name: &str,
        version: &Version,
    ) -> Result<CollectionArtifact, GalaxyError> {
        let dir = self.collection_dir(namespace, name);
        let tar_path = dir.join(format!("{version}.tar.gz"));
        let bytes = std::fs::read(&tar_path).map_err(|_| GalaxyError::CollectionNotFound {
            namespace: namespace.into(),
            name: name.into(),
        })?;
        // Optional sidecar checksum.
        let sha256 = read_sidecar_sha(&dir, version);
        Ok(CollectionArtifact {
            namespace: namespace.into(),
            name: name.into(),
            version: version.clone(),
            bytes,
            sha256,
        })
    }
}

fn read_sidecar_sha(dir: &Path, version: &Version) -> Option<String> {
    let p = dir.join(format!("{version}.sha256"));
    std::fs::read_to_string(p).ok().map(|s| s.trim().to_string())
}

// ============ Galaxy v3 API-backed fetcher (requires `network` feature) ============

#[cfg(feature = "network")]
pub struct GalaxyApiFetcher {
    client: reqwest::Client,
    server_url: String,
}

#[cfg(feature = "network")]
impl GalaxyApiFetcher {
    /// Create a fetcher pointing at a Galaxy-compatible v3 API.
    /// The default Ansible Galaxy server is `https://galaxy.ansible.com`.
    pub fn new(server_url: &str) -> Self {
        Self {
            client: reqwest::Client::new(),
            server_url: server_url.trim_end_matches('/').to_string(),
        }
    }

    /// Default Galaxy server.
    pub fn default_galaxy() -> Self {
        Self::new("https://galaxy.ansible.com")
    }

    /// Build the v3 API base URL for a collection.
    fn collection_url(&self, namespace: &str, name: &str) -> String {
        format!(
            "{}/api/v3/plugin/ansible/content/published/collections/index/{}/{}/",
            self.server_url, namespace, name
        )
    }

    /// Build the versions list URL.
    fn versions_url(&self, namespace: &str, name: &str) -> String {
        format!(
            "{}/api/v3/plugin/ansible/content/published/collections/index/{}/{}/versions/",
            self.server_url, namespace, name
        )
    }
}

#[cfg(feature = "network")]
#[async_trait]
impl Fetcher for GalaxyApiFetcher {
    async fn list_versions(
        &self,
        namespace: &str,
        name: &str,
    ) -> Result<Vec<Version>, GalaxyError> {
        let mut versions = Vec::new();
        let mut url = self.versions_url(namespace, name);

        // Galaxy paginates; follow `next` links.
        loop {
            let resp = self
                .client
                .get(&url)
                .send()
                .await
                .map_err(|e| GalaxyError::ApiError(e.to_string()))?;

            if resp.status() == reqwest::StatusCode::NOT_FOUND {
                return Err(GalaxyError::CollectionNotFound {
                    namespace: namespace.into(),
                    name: name.into(),
                });
            }

            let body: serde_json::Value = resp
                .json()
                .await
                .map_err(|e| GalaxyError::ApiError(e.to_string()))?;

            if let Some(data) = body.get("data").and_then(|d| d.as_array()) {
                for entry in data {
                    if let Some(ver_str) = entry.get("version").and_then(|v| v.as_str()) {
                        if let Ok(v) = Version::parse(ver_str) {
                            versions.push(v);
                        }
                    }
                }
            }

            // Follow pagination
            match body.get("links").and_then(|l| l.get("next")).and_then(|n| n.as_str()) {
                Some(next) if !next.is_empty() => {
                    url = if next.starts_with("http") {
                        next.to_string()
                    } else {
                        format!("{}{}", self.server_url, next)
                    };
                }
                _ => break,
            }
        }

        if versions.is_empty() {
            return Err(GalaxyError::CollectionNotFound {
                namespace: namespace.into(),
                name: name.into(),
            });
        }

        versions.sort();
        Ok(versions)
    }

    async fn fetch(
        &self,
        namespace: &str,
        name: &str,
        version: &Version,
    ) -> Result<CollectionArtifact, GalaxyError> {
        // Get the version detail to find the download URL and checksum.
        let version_url = format!(
            "{}{}",
            self.versions_url(namespace, name),
            version
        );
        let resp = self
            .client
            .get(&version_url)
            .send()
            .await
            .map_err(|e| GalaxyError::ApiError(e.to_string()))?;

        let detail: serde_json::Value = resp
            .json()
            .await
            .map_err(|e| GalaxyError::ApiError(e.to_string()))?;

        // Extract download_url and sha256
        let download_url = detail
            .get("download_url")
            .and_then(|v| v.as_str())
            .ok_or_else(|| {
                GalaxyError::ApiError(format!(
                    "no download_url in version detail for {namespace}.{name} {version}"
                ))
            })?;

        let sha256 = detail
            .get("artifact")
            .and_then(|a| a.get("sha256"))
            .and_then(|s| s.as_str())
            .map(String::from);

        // Download the tarball
        let full_url = if download_url.starts_with("http") {
            download_url.to_string()
        } else {
            format!("{}{}", self.server_url, download_url)
        };

        let bytes = self
            .client
            .get(&full_url)
            .send()
            .await
            .map_err(|e| GalaxyError::ApiError(e.to_string()))?
            .bytes()
            .await
            .map_err(|e| GalaxyError::ApiError(e.to_string()))?
            .to_vec();

        Ok(CollectionArtifact {
            namespace: namespace.into(),
            name: name.into(),
            version: version.clone(),
            bytes,
            sha256,
        })
    }
}
