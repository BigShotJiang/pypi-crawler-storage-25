use thiserror::Error;

#[derive(Debug, Error)]
pub enum ConnectionError {
    #[error("connection failed: {0}")]
    ConnectionFailed(String),

    #[error("authentication failed: {0}")]
    AuthenticationFailed(String),

    #[error("command execution failed: {0}")]
    CommandFailed(String),

    #[error("file transfer failed: {0}")]
    TransferFailed(String),

    #[error("connection timeout after {0}s")]
    Timeout(u64),

    #[error(transparent)]
    Io(#[from] std::io::Error),

    #[error(transparent)]
    Plugin(#[from] ansible_plugins::PluginError),
}
