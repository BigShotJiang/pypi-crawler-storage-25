//! SSH connection plugin — communicates with remote hosts via OpenSSH.
//!
//! This mirrors the behavior of Python Ansible's `plugins/connection/ssh.py`.
//! Key features:
//! - ControlMaster multiplexing for connection reuse
//! - SFTP file transfer with SCP fallback
//! - Pipelining (send module via stdin instead of file copy)
//! - Full `ansible_ssh_*` variable support
//! - Become/privilege escalation awareness

use std::path::{Path, PathBuf};
use std::process::Stdio;

use ansible_plugins::PluginError;
use async_trait::async_trait;
use tokio::process::Command;
use tracing::{debug, warn};

/// SSH connection plugin — communicates with remote hosts via OpenSSH.
///
/// Ansible variables honored:
/// - `ansible_host` — target hostname/IP
/// - `ansible_port` — SSH port (default 22)
/// - `ansible_user` — remote user
/// - `ansible_ssh_private_key_file` — path to private key
/// - `ansible_ssh_pass` — SSH password (used via sshpass)
/// - `ansible_ssh_common_args` — extra args for ssh, scp, and sftp
/// - `ansible_ssh_extra_args` — extra args for ssh only
/// - `ansible_scp_extra_args` — extra args for scp only
/// - `ansible_sftp_extra_args` — extra args for sftp only
/// - `ansible_ssh_executable` — path to ssh binary
/// - `ansible_ssh_pipelining` — enable pipelining
/// - `ansible_ssh_timeout` — connection timeout
/// - `ansible_ssh_retries` — number of retry attempts
pub struct SshConnection {
    pub host: String,
    pub port: u16,
    pub user: String,
    pub ssh_executable: PathBuf,
    pub private_key_file: Option<PathBuf>,
    pub password: Option<String>,
    pub ssh_common_args: Vec<String>,
    pub ssh_extra_args: Vec<String>,
    pub scp_extra_args: Vec<String>,
    pub sftp_extra_args: Vec<String>,
    pub control_path: Option<PathBuf>,
    pub pipelining: bool,
    pub timeout: u32,
    pub retries: u32,
    /// Prefer SFTP over SCP for file transfers (Ansible default: true).
    pub sftp_preferred: bool,
    connected: bool,
}

impl SshConnection {
    pub fn new(host: String, user: String) -> Self {
        Self {
            host,
            port: 22,
            user,
            ssh_executable: PathBuf::from("ssh"),
            private_key_file: None,
            password: None,
            ssh_common_args: Vec::new(),
            ssh_extra_args: Vec::new(),
            scp_extra_args: Vec::new(),
            sftp_extra_args: Vec::new(),
            control_path: None,
            pipelining: true,
            timeout: 10,
            retries: 3,
            sftp_preferred: true,
            connected: false,
        }
    }

    /// Generate a ControlPath derived from host/port/user.
    ///
    /// Ansible uses `~/.ansible/cp/` with a hash of the connection
    /// params to keep the socket path short (Unix domain sockets have
    /// a ~104 char limit on most systems).
    pub fn default_control_path(&self) -> PathBuf {
        use std::hash::{Hash, Hasher};
        let mut hasher = std::collections::hash_map::DefaultHasher::new();
        self.host.hash(&mut hasher);
        self.port.hash(&mut hasher);
        self.user.hash(&mut hasher);
        let hash = hasher.finish();

        let dir = dirs_or_tmp();
        dir.join(format!("cp-{:016x}", hash))
    }

    /// Start a Command, wrapping with `sshpass -e` when a password is
    /// configured. tokio::Command can't swap its program after
    /// construction, so we pick the right argv[0] up front and set
    /// the SSHPASS env var that `sshpass -e` reads.
    fn new_wrapped(&self, program: &str) -> Command {
        if self.password.is_some() {
            let mut cmd = Command::new("sshpass");
            cmd.arg("-e").arg(program);
            if let Some(ref pw) = self.password {
                cmd.env("SSHPASS", pw);
            }
            cmd
        } else {
            Command::new(program)
        }
    }

    /// Build the base SSH command with common arguments.
    fn build_ssh_cmd(&self) -> Command {
        let ssh_program = self.ssh_executable.to_string_lossy().into_owned();
        let mut cmd = self.new_wrapped(&ssh_program);

        // Disable host key checking by default (matches Ansible's
        // default when ANSIBLE_HOST_KEY_CHECKING=False).
        cmd.arg("-o").arg("StrictHostKeyChecking=no");
        cmd.arg("-o").arg("UserKnownHostsFile=/dev/null");

        // Connection timeout
        cmd.arg("-o")
            .arg(format!("ConnectTimeout={}", self.timeout));

        // Port and user
        cmd.arg("-p").arg(self.port.to_string());
        cmd.arg("-l").arg(&self.user);

        // Private key
        if let Some(ref key) = self.private_key_file {
            cmd.arg("-i").arg(key);
        }

        // ControlMaster multiplexing
        let cp = self
            .control_path
            .clone()
            .unwrap_or_else(|| self.default_control_path());
        cmd.arg("-o").arg(format!("ControlPath={}", cp.display()));
        cmd.arg("-o").arg("ControlMaster=auto");
        cmd.arg("-o").arg("ControlPersist=60s");

        // Suppress password prompts when no password is configured
        // (avoids hangs on machines that don't have key-based auth).
        if self.password.is_none() {
            cmd.arg("-o").arg("BatchMode=yes");
        }

        // Common args (shared across ssh, scp, sftp)
        for arg in &self.ssh_common_args {
            cmd.arg(arg);
        }

        // SSH-specific extra args
        for arg in &self.ssh_extra_args {
            cmd.arg(arg);
        }

        cmd
    }

    /// Build a base SCP command with shared arguments.
    fn build_scp_cmd(&self) -> Command {
        let mut cmd = self.new_wrapped("scp");
        cmd.arg("-o").arg("StrictHostKeyChecking=no");
        cmd.arg("-o").arg("UserKnownHostsFile=/dev/null");
        cmd.arg("-o")
            .arg(format!("ConnectTimeout={}", self.timeout));
        cmd.arg("-P").arg(self.port.to_string());

        if let Some(ref key) = self.private_key_file {
            cmd.arg("-i").arg(key);
        }

        let cp = self
            .control_path
            .clone()
            .unwrap_or_else(|| self.default_control_path());
        cmd.arg("-o").arg(format!("ControlPath={}", cp.display()));
        cmd.arg("-o").arg("ControlMaster=auto");
        cmd.arg("-o").arg("ControlPersist=60s");

        if self.password.is_none() {
            cmd.arg("-o").arg("BatchMode=yes");
        }

        for arg in &self.ssh_common_args {
            cmd.arg(arg);
        }
        for arg in &self.scp_extra_args {
            cmd.arg(arg);
        }

        cmd
    }

    /// Build a base SFTP command with shared arguments.
    fn build_sftp_cmd(&self) -> Command {
        let mut cmd = self.new_wrapped("sftp");
        cmd.arg("-o").arg("StrictHostKeyChecking=no");
        cmd.arg("-o").arg("UserKnownHostsFile=/dev/null");
        cmd.arg("-o")
            .arg(format!("ConnectTimeout={}", self.timeout));
        cmd.arg("-P").arg(self.port.to_string());

        if let Some(ref key) = self.private_key_file {
            cmd.arg("-i").arg(key);
        }

        let cp = self
            .control_path
            .clone()
            .unwrap_or_else(|| self.default_control_path());
        cmd.arg("-o").arg(format!("ControlPath={}", cp.display()));
        cmd.arg("-o").arg("ControlMaster=auto");
        cmd.arg("-o").arg("ControlPersist=60s");

        if self.password.is_none() {
            cmd.arg("-o").arg("BatchMode=yes");
        }

        for arg in &self.ssh_common_args {
            cmd.arg(arg);
        }
        for arg in &self.sftp_extra_args {
            cmd.arg(arg);
        }

        cmd
    }

    /// Execute a command with retries.
    async fn exec_with_retries(
        &self,
        cmd_str: &str,
        in_data: Option<&[u8]>,
    ) -> Result<(i32, Vec<u8>, Vec<u8>), PluginError> {
        let mut last_err = None;

        for attempt in 0..self.retries.max(1) {
            if attempt > 0 {
                debug!(
                    "[{}] SSH retry attempt {} of {}",
                    self.host,
                    attempt + 1,
                    self.retries
                );
                tokio::time::sleep(std::time::Duration::from_secs(1)).await;
            }

            match self.exec_once(cmd_str, in_data).await {
                Ok(result) => return Ok(result),
                Err(e) => {
                    warn!("[{}] SSH command failed (attempt {}): {}", self.host, attempt + 1, e);
                    last_err = Some(e);
                }
            }
        }

        Err(last_err.unwrap_or_else(|| {
            PluginError::ExecutionError("SSH command failed with no attempts".into())
        }))
    }

    /// Execute a single SSH command (no retries).
    async fn exec_once(
        &self,
        cmd_str: &str,
        in_data: Option<&[u8]>,
    ) -> Result<(i32, Vec<u8>, Vec<u8>), PluginError> {
        let mut ssh_cmd = self.build_ssh_cmd();
        ssh_cmd.arg(&self.host).arg(cmd_str);

        ssh_cmd.stdin(if in_data.is_some() {
            Stdio::piped()
        } else {
            Stdio::null()
        });
        ssh_cmd.stdout(Stdio::piped());
        ssh_cmd.stderr(Stdio::piped());

        let mut child = ssh_cmd
            .spawn()
            .map_err(|e| PluginError::ExecutionError(format!("SSH spawn failed: {e}")))?;

        if let Some(data) = in_data {
            use tokio::io::AsyncWriteExt;
            if let Some(mut stdin) = child.stdin.take() {
                stdin
                    .write_all(data)
                    .await
                    .map_err(|e| PluginError::ExecutionError(format!("SSH stdin write: {e}")))?;
                // Drop stdin to signal EOF
                drop(stdin);
            }
        }

        let output = child
            .wait_with_output()
            .await
            .map_err(|e| PluginError::ExecutionError(format!("SSH wait: {e}")))?;

        let rc = output.status.code().unwrap_or(-1);

        // SSH exit code 255 means the SSH connection itself failed
        // (as opposed to the remote command failing). Surface this
        // distinctly so callers can decide to retry.
        if rc == 255 && in_data.is_none() {
            return Err(PluginError::ExecutionError(format!(
                "SSH connection error (rc=255): {}",
                String::from_utf8_lossy(&output.stderr).trim()
            )));
        }

        Ok((rc, output.stdout, output.stderr))
    }

    /// Transfer a file using SFTP (batch mode).
    async fn sftp_put(&self, local: &Path, remote: &Path) -> Result<(), PluginError> {
        let batch_cmd = format!("put {} {}", local.display(), remote.display());

        let mut cmd = self.build_sftp_cmd();
        cmd.arg("-b").arg("-"); // read batch commands from stdin
        cmd.arg(format!("{}@{}", self.user, self.host));

        cmd.stdin(Stdio::piped());
        cmd.stdout(Stdio::piped());
        cmd.stderr(Stdio::piped());

        let mut child = cmd
            .spawn()
            .map_err(|e| PluginError::ExecutionError(format!("SFTP spawn: {e}")))?;

        {
            use tokio::io::AsyncWriteExt;
            if let Some(mut stdin) = child.stdin.take() {
                stdin.write_all(batch_cmd.as_bytes()).await.ok();
                stdin.write_all(b"\n").await.ok();
                drop(stdin);
            }
        }

        let output = child
            .wait_with_output()
            .await
            .map_err(|e| PluginError::ExecutionError(format!("SFTP wait: {e}")))?;

        if !output.status.success() {
            return Err(PluginError::ExecutionError(format!(
                "SFTP put failed (rc={}): {}",
                output.status.code().unwrap_or(-1),
                String::from_utf8_lossy(&output.stderr).trim()
            )));
        }

        Ok(())
    }

    /// Transfer a file using SFTP get (batch mode).
    async fn sftp_get(&self, remote: &Path, local: &Path) -> Result<(), PluginError> {
        let batch_cmd = format!("get {} {}", remote.display(), local.display());

        let mut cmd = self.build_sftp_cmd();
        cmd.arg("-b").arg("-");
        cmd.arg(format!("{}@{}", self.user, self.host));

        cmd.stdin(Stdio::piped());
        cmd.stdout(Stdio::piped());
        cmd.stderr(Stdio::piped());

        let mut child = cmd
            .spawn()
            .map_err(|e| PluginError::ExecutionError(format!("SFTP spawn: {e}")))?;

        {
            use tokio::io::AsyncWriteExt;
            if let Some(mut stdin) = child.stdin.take() {
                stdin.write_all(batch_cmd.as_bytes()).await.ok();
                stdin.write_all(b"\n").await.ok();
                drop(stdin);
            }
        }

        let output = child
            .wait_with_output()
            .await
            .map_err(|e| PluginError::ExecutionError(format!("SFTP wait: {e}")))?;

        if !output.status.success() {
            return Err(PluginError::ExecutionError(format!(
                "SFTP get failed (rc={}): {}",
                output.status.code().unwrap_or(-1),
                String::from_utf8_lossy(&output.stderr).trim()
            )));
        }

        Ok(())
    }

    /// Transfer a file using SCP (fallback).
    async fn scp_put(&self, local: &Path, remote: &Path) -> Result<(), PluginError> {
        let mut cmd = self.build_scp_cmd();
        cmd.arg(local);
        cmd.arg(format!(
            "{}@{}:{}",
            self.user,
            self.host,
            remote.display()
        ));

        cmd.stdout(Stdio::piped());
        cmd.stderr(Stdio::piped());

        let output = cmd
            .output()
            .await
            .map_err(|e| PluginError::ExecutionError(format!("SCP spawn: {e}")))?;

        if !output.status.success() {
            return Err(PluginError::ExecutionError(format!(
                "SCP put failed (rc={}): {}",
                output.status.code().unwrap_or(-1),
                String::from_utf8_lossy(&output.stderr).trim()
            )));
        }

        Ok(())
    }

    /// Fetch a file using SCP (fallback).
    async fn scp_get(&self, remote: &Path, local: &Path) -> Result<(), PluginError> {
        let mut cmd = self.build_scp_cmd();
        cmd.arg(format!(
            "{}@{}:{}",
            self.user,
            self.host,
            remote.display()
        ));
        cmd.arg(local);

        cmd.stdout(Stdio::piped());
        cmd.stderr(Stdio::piped());

        let output = cmd
            .output()
            .await
            .map_err(|e| PluginError::ExecutionError(format!("SCP spawn: {e}")))?;

        if !output.status.success() {
            return Err(PluginError::ExecutionError(format!(
                "SCP get failed (rc={}): {}",
                output.status.code().unwrap_or(-1),
                String::from_utf8_lossy(&output.stderr).trim()
            )));
        }

        Ok(())
    }
}

/// Return `~/.ansible/cp/` if $HOME is set, otherwise `/tmp/.ansible-cp/`.
fn dirs_or_tmp() -> PathBuf {
    if let Ok(home) = std::env::var("HOME") {
        let p = PathBuf::from(home).join(".ansible").join("cp");
        // Best-effort create; ignore errors (will fail at socket time
        // if the dir is truly not writable).
        let _ = std::fs::create_dir_all(&p);
        p
    } else {
        let p = PathBuf::from("/tmp/.ansible-cp");
        let _ = std::fs::create_dir_all(&p);
        p
    }
}

/// Parse a shell-style argument string into individual arguments.
/// Handles single and double quotes.
#[allow(dead_code)]
fn shell_split(s: &str) -> Vec<String> {
    let mut args = Vec::new();
    let mut current = String::new();
    let mut in_single = false;
    let mut in_double = false;
    let mut escape_next = false;

    for ch in s.chars() {
        if escape_next {
            current.push(ch);
            escape_next = false;
            continue;
        }
        match ch {
            '\\' if !in_single => escape_next = true,
            '\'' if !in_double => in_single = !in_single,
            '"' if !in_single => in_double = !in_double,
            ' ' | '\t' if !in_single && !in_double => {
                if !current.is_empty() {
                    args.push(current.clone());
                    current.clear();
                }
            }
            _ => current.push(ch),
        }
    }
    if !current.is_empty() {
        args.push(current);
    }
    args
}

#[async_trait]
impl ansible_plugins::ConnectionPlugin for SshConnection {
    async fn connect(&mut self) -> Result<(), PluginError> {
        // Ensure the ControlMaster directory exists
        let cp = self
            .control_path
            .clone()
            .unwrap_or_else(|| self.default_control_path());
        if let Some(parent) = cp.parent() {
            let _ = std::fs::create_dir_all(parent);
        }

        // Test connectivity with a simple echo. This also establishes
        // the ControlMaster socket so subsequent commands are fast.
        debug!("[{}] establishing SSH connection to {}@{}:{}", self.host, self.user, self.host, self.port);

        let mut cmd = self.build_ssh_cmd();
        cmd.arg(&self.host).arg("echo ANSIBLE_SSH_CHECK");
        cmd.stdout(Stdio::piped());
        cmd.stderr(Stdio::piped());

        let output = cmd
            .output()
            .await
            .map_err(|e| PluginError::ExecutionError(format!("SSH connect failed: {e}")))?;

        if !output.status.success() {
            let stderr = String::from_utf8_lossy(&output.stderr);
            return Err(PluginError::ExecutionError(format!(
                "SSH connection to {}@{}:{} failed (rc={}): {}",
                self.user,
                self.host,
                self.port,
                output.status.code().unwrap_or(-1),
                stderr.trim()
            )));
        }

        self.connected = true;
        debug!("[{}] SSH connection established", self.host);
        Ok(())
    }

    async fn exec_command(
        &self,
        cmd: &str,
        in_data: Option<&[u8]>,
    ) -> Result<(i32, Vec<u8>, Vec<u8>), PluginError> {
        self.exec_with_retries(cmd, in_data).await
    }

    async fn put_file(&self, in_path: &Path, out_path: &Path) -> Result<(), PluginError> {
        debug!(
            "[{}] put_file {} -> {}",
            self.host,
            in_path.display(),
            out_path.display()
        );

        // Ensure the remote directory exists
        let remote_dir = out_path
            .parent()
            .map(|p| p.to_string_lossy().to_string())
            .unwrap_or_else(|| "/tmp".into());
        let _ = self
            .exec_once(&format!("mkdir -p {}", shell_escape_path(&remote_dir)), None)
            .await;

        if self.sftp_preferred {
            match self.sftp_put(in_path, out_path).await {
                Ok(()) => return Ok(()),
                Err(e) => {
                    debug!(
                        "[{}] SFTP put failed, falling back to SCP: {}",
                        self.host, e
                    );
                }
            }
        }

        // Fall back to SCP
        self.scp_put(in_path, out_path).await
    }

    async fn fetch_file(&self, in_path: &Path, out_path: &Path) -> Result<(), PluginError> {
        debug!(
            "[{}] fetch_file {} -> {}",
            self.host,
            in_path.display(),
            out_path.display()
        );

        if self.sftp_preferred {
            match self.sftp_get(in_path, out_path).await {
                Ok(()) => return Ok(()),
                Err(e) => {
                    debug!(
                        "[{}] SFTP get failed, falling back to SCP: {}",
                        self.host, e
                    );
                }
            }
        }

        self.scp_get(in_path, out_path).await
    }

    async fn close(&mut self) -> Result<(), PluginError> {
        if self.connected {
            let cp = self
                .control_path
                .clone()
                .unwrap_or_else(|| self.default_control_path());

            // Send ControlMaster exit signal
            let mut cmd = Command::new(&self.ssh_executable);
            cmd.arg("-o")
                .arg(format!("ControlPath={}", cp.display()));
            cmd.arg("-O").arg("exit");
            cmd.arg(&self.host);
            cmd.stdout(Stdio::null());
            cmd.stderr(Stdio::null());

            // Best effort — ignore errors on close
            let _ = cmd.status().await;

            self.connected = false;
            debug!("[{}] SSH connection closed", self.host);
        }
        Ok(())
    }
}

/// Shell-escape a path for use in remote commands.
fn shell_escape_path(s: &str) -> String {
    format!("'{}'", s.replace('\'', "'\\''"))
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_new_defaults() {
        let conn = SshConnection::new("example.com".into(), "admin".into());
        assert_eq!(conn.host, "example.com");
        assert_eq!(conn.user, "admin");
        assert_eq!(conn.port, 22);
        assert!(conn.pipelining);
        assert!(conn.sftp_preferred);
        assert_eq!(conn.timeout, 10);
        assert_eq!(conn.retries, 3);
        assert!(!conn.connected);
    }

    #[test]
    fn test_default_control_path_deterministic() {
        let conn = SshConnection::new("host1".into(), "user1".into());
        let cp1 = conn.default_control_path();
        let cp2 = conn.default_control_path();
        assert_eq!(cp1, cp2, "control path should be deterministic");
        assert!(
            cp1.to_string_lossy().contains("cp-"),
            "control path should contain hash prefix"
        );
    }

    #[test]
    fn test_different_hosts_different_control_paths() {
        let c1 = SshConnection::new("host1".into(), "user1".into());
        let c2 = SshConnection::new("host2".into(), "user1".into());
        assert_ne!(
            c1.default_control_path(),
            c2.default_control_path(),
            "different hosts should get different control paths"
        );
    }

    #[test]
    fn test_shell_split_simple() {
        assert_eq!(shell_split("a b c"), vec!["a", "b", "c"]);
    }

    #[test]
    fn test_shell_split_quoted() {
        assert_eq!(
            shell_split(r#"-o "ProxyCommand ssh -W %h:%p bastion""#),
            vec!["-o", "ProxyCommand ssh -W %h:%p bastion"]
        );
    }

    #[test]
    fn test_shell_split_single_quoted() {
        assert_eq!(
            shell_split("-o 'StrictHostKeyChecking=yes'"),
            vec!["-o", "StrictHostKeyChecking=yes"]
        );
    }

    #[test]
    fn test_shell_split_empty() {
        assert!(shell_split("").is_empty());
        assert!(shell_split("   ").is_empty());
    }

    #[test]
    fn test_shell_escape_path_basic() {
        assert_eq!(shell_escape_path("/tmp/foo"), "'/tmp/foo'");
    }

    #[test]
    fn test_shell_escape_path_with_quote() {
        assert_eq!(
            shell_escape_path("/tmp/it's"),
            "'/tmp/it'\\''s'"
        );
    }

    #[test]
    fn test_build_ssh_cmd_has_expected_args() {
        let mut conn = SshConnection::new("myhost".into(), "myuser".into());
        conn.port = 2222;
        conn.timeout = 30;
        conn.private_key_file = Some(PathBuf::from("/home/user/.ssh/id_rsa"));
        conn.ssh_common_args = vec!["-o".into(), "ProxyCommand=none".into()];
        conn.ssh_extra_args = vec!["-v".into()];

        let cmd = conn.build_ssh_cmd();
        let prog = cmd.as_std().get_program().to_string_lossy().to_string();
        let args: Vec<String> = cmd
            .as_std()
            .get_args()
            .map(|a| a.to_string_lossy().to_string())
            .collect();

        assert_eq!(prog, "ssh");
        assert!(args.contains(&"2222".to_string()), "port should be set");
        assert!(args.contains(&"myuser".to_string()), "user should be set");
        assert!(
            args.contains(&"ConnectTimeout=30".to_string()),
            "timeout should be set"
        );
        assert!(
            args.contains(&"/home/user/.ssh/id_rsa".to_string()),
            "private key should be set"
        );
        assert!(
            args.contains(&"ProxyCommand=none".to_string()),
            "common args should be included"
        );
        assert!(
            args.contains(&"-v".to_string()),
            "extra args should be included"
        );
        // BatchMode should be on when no password
        assert!(
            args.contains(&"BatchMode=yes".to_string()),
            "BatchMode should be set when no password"
        );
    }

    #[test]
    fn test_build_ssh_cmd_no_batch_mode_with_password() {
        let mut conn = SshConnection::new("myhost".into(), "myuser".into());
        conn.password = Some("secret".into());

        let cmd = conn.build_ssh_cmd();
        let args: Vec<String> = cmd
            .as_std()
            .get_args()
            .map(|a| a.to_string_lossy().to_string())
            .collect();

        assert!(
            !args.contains(&"BatchMode=yes".to_string()),
            "BatchMode should NOT be set when password is provided"
        );
    }

    #[test]
    fn test_build_scp_cmd_uses_uppercase_p() {
        let mut conn = SshConnection::new("myhost".into(), "myuser".into());
        conn.port = 3333;
        conn.scp_extra_args = vec!["-l".into(), "1000".into()];

        let cmd = conn.build_scp_cmd();
        let args: Vec<String> = cmd
            .as_std()
            .get_args()
            .map(|a| a.to_string_lossy().to_string())
            .collect();

        // SCP uses -P (uppercase) for port
        let p_idx = args.iter().position(|a| a == "-P").unwrap();
        assert_eq!(args[p_idx + 1], "3333");
        assert!(args.contains(&"-l".to_string()), "scp extra args");
        assert!(args.contains(&"1000".to_string()), "scp extra args value");
    }

    #[test]
    fn test_build_sftp_cmd_uses_uppercase_p() {
        let mut conn = SshConnection::new("myhost".into(), "myuser".into());
        conn.port = 4444;
        conn.sftp_extra_args = vec!["-B".into(), "65536".into()];

        let cmd = conn.build_sftp_cmd();
        let args: Vec<String> = cmd
            .as_std()
            .get_args()
            .map(|a| a.to_string_lossy().to_string())
            .collect();

        let p_idx = args.iter().position(|a| a == "-P").unwrap();
        assert_eq!(args[p_idx + 1], "4444");
        assert!(args.contains(&"-B".to_string()), "sftp extra args");
    }
}
