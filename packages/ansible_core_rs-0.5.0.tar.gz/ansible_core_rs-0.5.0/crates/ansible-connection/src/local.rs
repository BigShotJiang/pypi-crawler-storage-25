use std::path::Path;
use std::process::Stdio;

use ansible_plugins::PluginError;
use async_trait::async_trait;
use tokio::process::Command;


/// Local connection plugin — executes commands on the control node.
pub struct LocalConnection;

impl LocalConnection {
    pub fn new() -> Self {
        Self
    }
}

impl Default for LocalConnection {
    fn default() -> Self {
        Self::new()
    }
}

#[async_trait]
impl ansible_plugins::ConnectionPlugin for LocalConnection {
    async fn connect(&mut self) -> Result<(), PluginError> {
        // Local connection needs no setup
        Ok(())
    }

    async fn exec_command(
        &self,
        cmd: &str,
        in_data: Option<&[u8]>,
    ) -> Result<(i32, Vec<u8>, Vec<u8>), PluginError> {
        let mut child = Command::new("/bin/sh")
            .arg("-c")
            .arg(cmd)
            .stdin(if in_data.is_some() {
                Stdio::piped()
            } else {
                Stdio::null()
            })
            .stdout(Stdio::piped())
            .stderr(Stdio::piped())
            .spawn()
            .map_err(|e| PluginError::ExecutionError(e.to_string()))?;

        if let Some(data) = in_data {
            use tokio::io::AsyncWriteExt;
            if let Some(mut stdin) = child.stdin.take() {
                stdin
                    .write_all(data)
                    .await
                    .map_err(|e| PluginError::ExecutionError(e.to_string()))?;
            }
        }

        let output = child
            .wait_with_output()
            .await
            .map_err(|e| PluginError::ExecutionError(e.to_string()))?;

        let rc = output.status.code().unwrap_or(-1);
        Ok((rc, output.stdout, output.stderr))
    }

    async fn put_file(&self, in_path: &Path, out_path: &Path) -> Result<(), PluginError> {
        tokio::fs::copy(in_path, out_path)
            .await
            .map_err(|e| PluginError::ExecutionError(e.to_string()))?;
        Ok(())
    }

    async fn fetch_file(&self, in_path: &Path, out_path: &Path) -> Result<(), PluginError> {
        tokio::fs::copy(in_path, out_path)
            .await
            .map_err(|e| PluginError::ExecutionError(e.to_string()))?;
        Ok(())
    }

    async fn close(&mut self) -> Result<(), PluginError> {
        Ok(())
    }
}
