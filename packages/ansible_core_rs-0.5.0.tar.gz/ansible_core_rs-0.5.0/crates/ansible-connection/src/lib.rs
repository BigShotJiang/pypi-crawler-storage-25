pub mod error;
pub mod local;
pub mod ssh;

pub use error::ConnectionError;
