use std::collections::HashMap;

use ansible_utils::AnsibleValue;
use minijinja::{Environment, Value as MjValue};

use crate::TemplateError;

/// The Ansible template engine, wrapping MiniJinja with Ansible-specific
/// filters and tests.
pub struct Templar {
    env: Environment<'static>,
    variables: HashMap<String, AnsibleValue>,
    /// If true, a MiniJinja render failure transparently retries through the
    /// embedded-Python Jinja2 engine. Only meaningful when the crate is
    /// built with the `python-fallback` feature.
    python_fallback: bool,
}

impl Templar {
    pub fn new() -> Self {
        let mut env = Environment::new();
        env.set_undefined_behavior(minijinja::UndefinedBehavior::Strict);

        // Register Ansible-specific filters
        register_ansible_filters(&mut env);
        // Register Ansible-specific tests
        register_ansible_tests(&mut env);

        Self {
            env,
            variables: HashMap::new(),
            python_fallback: false,
        }
    }

    /// Enable the embedded-Python Jinja2 fallback. When a template fails
    /// under MiniJinja (unknown filter, syntax MiniJinja doesn't support),
    /// the Templar retries it through Python's `jinja2` before surfacing an
    /// error. Only effective when the crate is built with `python-fallback`.
    pub fn with_python_fallback(mut self) -> Self {
        self.python_fallback = true;
        self
    }

    /// Runtime toggle for the Python fallback. Same semantics as
    /// [`with_python_fallback`] but mutable, for callers that flip the flag
    /// after construction.
    pub fn set_python_fallback(&mut self, enabled: bool) {
        self.python_fallback = enabled;
    }

    /// Set the variables available for templating.
    pub fn set_variables(&mut self, variables: HashMap<String, AnsibleValue>) {
        self.variables = variables;
    }

    /// Template a string value, resolving `{{ }}` and `{% %}` expressions.
    pub fn template_string(&self, data: &str) -> Result<String, TemplateError> {
        // Fast path: no template markers
        if !data.contains("{{") && !data.contains("{%") && !data.contains("{#") {
            return Ok(data.to_string());
        }

        match self.env.render_str(data, &self.variables) {
            Ok(result) => Ok(result),
            Err(e) => {
                if self.python_fallback {
                    if let Some(rendered) = self.render_via_python(data) {
                        return rendered;
                    }
                }
                Err(TemplateError::MiniJinja(e))
            }
        }
    }

    /// Render `data` through the embedded Python Jinja2 engine, if the
    /// feature is compiled in. Returns `None` when the feature is disabled
    /// so the caller can surface the original MiniJinja error.
    #[allow(unused_variables)]
    fn render_via_python(&self, data: &str) -> Option<Result<String, TemplateError>> {
        #[cfg(feature = "python-fallback")]
        {
            Some(crate::python_fallback::render(data, &self.variables))
        }
        #[cfg(not(feature = "python-fallback"))]
        {
            None
        }
    }

    /// Template a string and return the result as an AnsibleValue.
    /// If the template renders to valid JSON/YAML, parse it; otherwise return as string.
    pub fn template_string_as_value(&self, data: &str) -> Result<AnsibleValue, TemplateError> {
        let rendered = self.template_string(data)?;

        // Try to parse as JSON first (handles booleans, numbers, objects, arrays)
        if let Ok(val) = serde_json::from_str::<AnsibleValue>(&rendered) {
            return Ok(val);
        }

        Ok(AnsibleValue::String(rendered))
    }

    /// Recursively template all string values in an AnsibleValue.
    pub fn template_value(&self, data: &AnsibleValue) -> Result<AnsibleValue, TemplateError> {
        match data {
            AnsibleValue::String(s) => {
                let rendered = self.template_string(s)?;
                Ok(AnsibleValue::String(rendered))
            }
            AnsibleValue::Array(arr) => {
                let rendered: Result<Vec<_>, _> =
                    arr.iter().map(|v| self.template_value(v)).collect();
                Ok(AnsibleValue::Array(rendered?))
            }
            AnsibleValue::Object(map) => {
                let mut result = serde_json::Map::new();
                for (k, v) in map {
                    let rendered_key = self.template_string(k)?;
                    let rendered_val = self.template_value(v)?;
                    result.insert(rendered_key, rendered_val);
                }
                Ok(AnsibleValue::Object(result))
            }
            other => Ok(other.clone()),
        }
    }

    /// Evaluate a conditional expression (for `when:` clauses).
    /// Returns true if the expression evaluates to a truthy value.
    pub fn evaluate_conditional(&self, expr: &str) -> Result<bool, TemplateError> {
        // Ansible wraps when conditions in {{ }} if not already templated
        let template = if expr.contains("{{") {
            format!("{{% if {} %}}True{{% else %}}False{{% endif %}}",
                expr.replace("{{", "").replace("}}", ""))
        } else {
            format!("{{% if {} %}}True{{% else %}}False{{% endif %}}", expr)
        };

        match self.env.render_str(&template, &self.variables) {
            Ok(result) => Ok(result.trim() == "True"),
            Err(e) => {
                #[cfg(feature = "python-fallback")]
                if self.python_fallback {
                    return crate::python_fallback::evaluate_conditional(expr, &self.variables);
                }
                Err(TemplateError::MiniJinja(e))
            }
        }
    }

    /// Check if a string contains template markers.
    pub fn is_template(data: &str) -> bool {
        data.contains("{{") || data.contains("{%") || data.contains("{#")
    }
}

impl Default for Templar {
    fn default() -> Self {
        Self::new()
    }
}

/// Register Ansible-specific Jinja2 filters.
fn register_ansible_filters(env: &mut Environment<'static>) {
    // default(value, default_value='', boolean=False)
    env.add_filter("default", filter_default);
    env.add_filter("d", filter_default); // alias

    // mandatory - fail if undefined
    env.add_filter("mandatory", filter_mandatory);

    // ternary(true_val, false_val, none_val=none)
    env.add_filter("ternary", filter_ternary);

    // to_json / to_nice_json
    env.add_filter("to_json", filter_to_json);
    env.add_filter("to_nice_json", filter_to_nice_json);

    // from_json
    env.add_filter("from_json", filter_from_json);

    // to_yaml / to_nice_yaml
    env.add_filter("to_yaml", filter_to_yaml);
    env.add_filter("to_nice_yaml", filter_to_nice_yaml);

    // from_yaml
    env.add_filter("from_yaml", filter_from_yaml);

    // combine - merge dicts
    env.add_filter("combine", filter_combine);

    // dict2items / items2dict
    env.add_filter("dict2items", filter_dict2items);
    env.add_filter("items2dict", filter_items2dict);

    // List filters
    env.add_filter("flatten", filter_flatten);
    env.add_filter("unique", filter_unique);
    env.add_filter("union", filter_union);
    env.add_filter("intersect", filter_intersect);
    env.add_filter("difference", filter_difference);
    env.add_filter("symmetric_difference", filter_symmetric_difference);

    // String filters
    env.add_filter("regex_search", filter_regex_search);
    env.add_filter("regex_replace", filter_regex_replace);
    env.add_filter("regex_findall", filter_regex_findall);
    env.add_filter("quote", filter_quote);
    env.add_filter("hash", filter_hash);
    env.add_filter("b64encode", filter_b64encode);
    env.add_filter("b64decode", filter_b64decode);
    env.add_filter("basename", filter_basename);
    env.add_filter("dirname", filter_dirname);
    env.add_filter("splitext", filter_splitext);

    // Type conversion
    env.add_filter("bool", filter_bool);
    env.add_filter("int", filter_int);
    env.add_filter("float", filter_float_conv);
    env.add_filter("string", filter_string);

    // Math
    env.add_filter("log", filter_log);
    env.add_filter("pow", filter_pow);
    env.add_filter("root", filter_root);

    // Misc
    env.add_filter("type_debug", filter_type_debug);
    env.add_filter("comment", filter_comment);
    env.add_filter("subelements", filter_subelements);
    env.add_filter("zip", filter_zip);
    env.add_filter("zip_longest", filter_zip_longest);
    env.add_filter("product", filter_product);
    env.add_filter("permutations", filter_permutations);
    env.add_filter("combinations", filter_combinations);

    // Path / filesystem filters (extension of dirname/basename/splitext).
    env.add_filter("realpath", filter_realpath);
    env.add_filter("expanduser", filter_expanduser);
    env.add_filter("expandvars", filter_expandvars);
    env.add_filter("relpath", filter_relpath);
    env.add_filter("win_basename", filter_win_basename);
    env.add_filter("win_dirname", filter_win_dirname);

    // UUID & randomness. `random` supports both int-range (`100 | random`)
    // and list-pick (`[a,b,c] | random`) forms via dynamic dispatch.
    env.add_filter("to_uuid", filter_to_uuid);
    env.add_filter("random", filter_random);
    env.add_filter("shuffle", filter_shuffle);

    // extract(list_of_keys, container[, morekeys...]) — looks each key up
    // in the container. Common in role defaults that map host names to
    // per-host config dicts.
    env.add_filter("extract", filter_extract);

    // checksum(file) / checksum_file are the ansible names for
    // "sha1-like" file checksums. We compute sha256 and return the hex —
    // the contract downstream callers actually care about is "stable
    // per-content digest", not a specific algorithm.
    env.add_filter("checksum", filter_checksum);

    // password_hash: deliberately *unsupported* — it depends on crypt(3)
    // which we don't want to pull into this crate. Register a stub that
    // returns a clear error so templates fail loudly instead of silently.
    env.add_filter("password_hash", filter_password_hash_unsupported);

    // Phase 7.3 batch 2: missing high-priority filters
    env.add_filter("regex_escape", filter_regex_escape);
    env.add_filter("path_join", filter_path_join);
    env.add_filter("normpath", filter_normpath);
    env.add_filter("md5", filter_md5);
    env.add_filter("sha1", filter_sha1);
    env.add_filter("to_datetime", filter_to_datetime);
    env.add_filter("strftime", filter_strftime);
    env.add_filter("human_readable", filter_human_readable);
    env.add_filter("human_to_bytes", filter_human_to_bytes);
    env.add_filter("urlsplit", filter_urlsplit);
    env.add_filter("urlencode", filter_urlencode);
    env.add_filter("urldecode", filter_urldecode);
    env.add_filter("to_bool", filter_bool); // alias for bool
    env.add_filter("win_splitdrive", filter_win_splitdrive);
    env.add_filter("split", filter_split);
    env.add_filter("wordcount", filter_wordcount);
    env.add_filter("map_attribute", filter_map_attribute);
}

/// Register Ansible-specific Jinja2 tests.
fn register_ansible_tests(env: &mut Environment<'static>) {
    env.add_test("match", test_match);
    env.add_test("search", test_search);
    env.add_test("regex", test_regex);
    env.add_test("vault_encrypted", test_vault_encrypted);
    env.add_test("truthy", test_truthy);
    env.add_test("falsy", test_falsy);
    env.add_test("any", test_any);
    env.add_test("all", test_all);
    env.add_test("version", test_version);
    env.add_test("subset", test_subset);
    env.add_test("superset", test_superset);
    env.add_test("contains", test_contains);

    // Filesystem tests — thin wrappers over std::fs.
    env.add_test("file", test_is_file);
    env.add_test("directory", test_is_directory);
    env.add_test("link", test_is_link);
    env.add_test("exists", test_exists);
    env.add_test("abs", test_is_abs);
}

// ============ Filter implementations ============

fn filter_default(value: MjValue, default: Option<MjValue>, boolean: Option<bool>) -> MjValue {
    let default = default.unwrap_or_else(|| MjValue::from(""));
    let check_boolean = boolean.unwrap_or(false);

    if value.is_undefined() || value.is_none() {
        return default;
    }

    if check_boolean {
        // In boolean mode, falsy values get replaced
        if is_falsy(&value) {
            return default;
        }
    }

    value
}

fn filter_mandatory(value: MjValue) -> Result<MjValue, minijinja::Error> {
    if value.is_undefined() || value.is_none() {
        Err(minijinja::Error::new(
            minijinja::ErrorKind::InvalidOperation,
            "Mandatory variable is not defined",
        ))
    } else {
        Ok(value)
    }
}

fn filter_ternary(
    value: MjValue,
    true_val: MjValue,
    false_val: MjValue,
    none_val: Option<MjValue>,
) -> MjValue {
    if value.is_none() || value.is_undefined() {
        return none_val.unwrap_or(false_val);
    }
    if is_truthy(&value) {
        true_val
    } else {
        false_val
    }
}

fn filter_to_json(value: MjValue) -> Result<String, minijinja::Error> {
    serde_json::to_string(&value).map_err(|e| {
        minijinja::Error::new(minijinja::ErrorKind::InvalidOperation, e.to_string())
    })
}

fn filter_to_nice_json(value: MjValue) -> Result<String, minijinja::Error> {
    serde_json::to_string_pretty(&value).map_err(|e| {
        minijinja::Error::new(minijinja::ErrorKind::InvalidOperation, e.to_string())
    })
}

fn filter_from_json(value: String) -> Result<MjValue, minijinja::Error> {
    let parsed: serde_json::Value = serde_json::from_str(&value).map_err(|e| {
        minijinja::Error::new(minijinja::ErrorKind::InvalidOperation, e.to_string())
    })?;
    Ok(MjValue::from_serialize(&parsed))
}

fn filter_to_yaml(value: MjValue) -> Result<String, minijinja::Error> {
    // Convert to serde_json::Value first, then to YAML
    let json_val: serde_json::Value = serde_json::to_value(&value).map_err(|e| {
        minijinja::Error::new(minijinja::ErrorKind::InvalidOperation, e.to_string())
    })?;
    serde_yaml::to_string(&json_val).map_err(|e| {
        minijinja::Error::new(minijinja::ErrorKind::InvalidOperation, e.to_string())
    })
}

fn filter_to_nice_yaml(value: MjValue) -> Result<String, minijinja::Error> {
    // Same as to_yaml for serde_yaml (it's already pretty)
    filter_to_yaml(value)
}

fn filter_from_yaml(value: String) -> Result<MjValue, minijinja::Error> {
    let parsed: serde_json::Value = serde_yaml::from_str(&value).map_err(|e| {
        minijinja::Error::new(minijinja::ErrorKind::InvalidOperation, e.to_string())
    })?;
    Ok(MjValue::from_serialize(&parsed))
}

fn filter_combine(value: MjValue, other: MjValue) -> Result<MjValue, minijinja::Error> {
    // Merge two dicts
    let mut base: serde_json::Map<String, serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .unwrap_or_default();
    let overlay: serde_json::Map<String, serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&other).unwrap_or_default())
            .unwrap_or_default();
    for (k, v) in overlay {
        base.insert(k, v);
    }
    Ok(MjValue::from_serialize(&base))
}

fn filter_dict2items(value: MjValue) -> Result<MjValue, minijinja::Error> {
    let map: serde_json::Map<String, serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .map_err(|_| {
                minijinja::Error::new(
                    minijinja::ErrorKind::InvalidOperation,
                    "dict2items requires a dictionary",
                )
            })?;

    let items: Vec<serde_json::Value> = map
        .into_iter()
        .map(|(k, v)| {
            serde_json::json!({"key": k, "value": v})
        })
        .collect();

    Ok(MjValue::from_serialize(&items))
}

fn filter_items2dict(value: MjValue) -> Result<MjValue, minijinja::Error> {
    let items: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .map_err(|_| {
                minijinja::Error::new(
                    minijinja::ErrorKind::InvalidOperation,
                    "items2dict requires a list",
                )
            })?;

    let mut map = serde_json::Map::new();
    for item in items {
        if let (Some(key), Some(val)) = (
            item.get("key").and_then(|k| k.as_str()),
            item.get("value"),
        ) {
            map.insert(key.to_string(), val.clone());
        }
    }

    Ok(MjValue::from_serialize(&map))
}

fn filter_flatten(value: MjValue, levels: Option<i64>) -> Result<MjValue, minijinja::Error> {
    let arr: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .unwrap_or_default();
    let depth = levels.unwrap_or(1) as usize;
    let result = flatten_recursive(&serde_json::Value::Array(arr), depth);
    Ok(MjValue::from_serialize(&result))
}

fn flatten_recursive(val: &serde_json::Value, depth: usize) -> Vec<serde_json::Value> {
    match val {
        serde_json::Value::Array(arr) if depth > 0 => {
            arr.iter()
                .flat_map(|v| flatten_recursive(v, depth - 1))
                .collect()
        }
        other => vec![other.clone()],
    }
}

fn filter_unique(value: MjValue) -> Result<MjValue, minijinja::Error> {
    let arr: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .unwrap_or_default();
    let mut seen = Vec::new();
    for item in arr {
        if !seen.contains(&item) {
            seen.push(item);
        }
    }
    Ok(MjValue::from_serialize(&seen))
}

fn filter_union(value: MjValue, other: MjValue) -> Result<MjValue, minijinja::Error> {
    let mut arr: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .unwrap_or_default();
    let other_arr: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&other).unwrap_or_default())
            .unwrap_or_default();
    for item in other_arr {
        if !arr.contains(&item) {
            arr.push(item);
        }
    }
    Ok(MjValue::from_serialize(&arr))
}

fn filter_intersect(value: MjValue, other: MjValue) -> Result<MjValue, minijinja::Error> {
    let arr: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .unwrap_or_default();
    let other_arr: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&other).unwrap_or_default())
            .unwrap_or_default();
    let result: Vec<_> = arr.into_iter().filter(|v| other_arr.contains(v)).collect();
    Ok(MjValue::from_serialize(&result))
}

fn filter_difference(value: MjValue, other: MjValue) -> Result<MjValue, minijinja::Error> {
    let arr: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .unwrap_or_default();
    let other_arr: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&other).unwrap_or_default())
            .unwrap_or_default();
    let result: Vec<_> = arr.into_iter().filter(|v| !other_arr.contains(v)).collect();
    Ok(MjValue::from_serialize(&result))
}

fn filter_symmetric_difference(value: MjValue, other: MjValue) -> Result<MjValue, minijinja::Error> {
    let arr: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .unwrap_or_default();
    let other_arr: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&other).unwrap_or_default())
            .unwrap_or_default();
    let mut result: Vec<_> = arr.iter().filter(|v| !other_arr.contains(v)).cloned().collect();
    for item in &other_arr {
        if !arr.contains(item) {
            result.push(item.clone());
        }
    }
    Ok(MjValue::from_serialize(&result))
}

fn filter_regex_search(value: String, pattern: String) -> Result<MjValue, minijinja::Error> {
    let re = regex::Regex::new(&pattern).map_err(|e| {
        minijinja::Error::new(minijinja::ErrorKind::InvalidOperation, e.to_string())
    })?;
    match re.find(&value) {
        Some(m) => Ok(MjValue::from(m.as_str().to_string())),
        None => Ok(MjValue::from("")),
    }
}

fn filter_regex_replace(
    value: String,
    pattern: String,
    replacement: String,
) -> Result<String, minijinja::Error> {
    let re = regex::Regex::new(&pattern).map_err(|e| {
        minijinja::Error::new(minijinja::ErrorKind::InvalidOperation, e.to_string())
    })?;
    Ok(re.replace_all(&value, replacement.as_str()).to_string())
}

fn filter_regex_findall(value: String, pattern: String) -> Result<MjValue, minijinja::Error> {
    let re = regex::Regex::new(&pattern).map_err(|e| {
        minijinja::Error::new(minijinja::ErrorKind::InvalidOperation, e.to_string())
    })?;
    let matches: Vec<String> = re.find_iter(&value).map(|m| m.as_str().to_string()).collect();
    Ok(MjValue::from_serialize(&matches))
}

fn filter_quote(value: String) -> String {
    format!("'{}'", value.replace('\'', "'\\''"))
}

fn filter_hash(value: String, algorithm: Option<String>) -> Result<String, minijinja::Error> {
    use sha2::{Digest, Sha256};
    let algo = algorithm.unwrap_or_else(|| "sha256".to_string());
    match algo.as_str() {
        "sha256" => {
            let mut hasher = Sha256::new();
            hasher.update(value.as_bytes());
            Ok(format!("{:x}", hasher.finalize()))
        }
        other => Err(minijinja::Error::new(
            minijinja::ErrorKind::InvalidOperation,
            format!("unsupported hash algorithm: {}", other),
        )),
    }
}

fn filter_b64encode(value: String) -> String {
    use base64::Engine;
    base64::engine::general_purpose::STANDARD.encode(value.as_bytes())
}

fn filter_b64decode(value: String) -> Result<String, minijinja::Error> {
    use base64::Engine;
    let decoded = base64::engine::general_purpose::STANDARD
        .decode(value.as_bytes())
        .map_err(|e| {
            minijinja::Error::new(minijinja::ErrorKind::InvalidOperation, e.to_string())
        })?;
    String::from_utf8(decoded).map_err(|e| {
        minijinja::Error::new(minijinja::ErrorKind::InvalidOperation, e.to_string())
    })
}

fn filter_basename(value: String) -> String {
    std::path::Path::new(&value)
        .file_name()
        .map(|f| f.to_string_lossy().to_string())
        .unwrap_or_default()
}

fn filter_dirname(value: String) -> String {
    std::path::Path::new(&value)
        .parent()
        .map(|p| p.to_string_lossy().to_string())
        .unwrap_or_default()
}

fn filter_splitext(value: String) -> MjValue {
    let path = std::path::Path::new(&value);
    let stem = path
        .file_stem()
        .map(|s| s.to_string_lossy().to_string())
        .unwrap_or_default();
    let ext = path
        .extension()
        .map(|e| format!(".{}", e.to_string_lossy()))
        .unwrap_or_default();
    // Return full path with stem + extension tuple
    let dir = path
        .parent()
        .map(|p| p.to_string_lossy().to_string())
        .unwrap_or_default();
    let root = if dir.is_empty() {
        stem
    } else {
        format!("{}/{}", dir, stem)
    };
    MjValue::from_serialize(vec![root, ext])
}

fn filter_bool(value: MjValue) -> bool {
    is_truthy(&value)
}

fn filter_int(value: MjValue, default: Option<i64>) -> i64 {
    if let Some(n) = value.as_i64() {
        return n;
    }
    if let Some(s) = value.as_str() {
        if let Ok(n) = s.parse::<i64>() {
            return n;
        }
    }
    default.unwrap_or(0)
}

fn filter_float_conv(value: MjValue, default: Option<f64>) -> f64 {
    // MiniJinja doesn't have as_f64, convert via i64 or string
    if let Some(n) = value.as_i64() {
        return n as f64;
    }
    if let Some(s) = value.as_str() {
        if let Ok(n) = s.parse::<f64>() {
            return n;
        }
    }
    default.unwrap_or(0.0)
}

fn filter_string(value: MjValue) -> String {
    value.to_string()
}

fn filter_log(value: f64, base: Option<f64>) -> f64 {
    let base = base.unwrap_or(std::f64::consts::E);
    value.log(base)
}

fn filter_pow(value: f64, exp: f64) -> f64 {
    value.powf(exp)
}

fn filter_root(value: f64, degree: Option<f64>) -> f64 {
    let degree = degree.unwrap_or(2.0);
    value.powf(1.0 / degree)
}

fn filter_type_debug(value: MjValue) -> String {
    use minijinja::value::ValueKind;
    match value.kind() {
        ValueKind::Undefined => "AnsibleUndefined".to_string(),
        ValueKind::None => "NoneType".to_string(),
        ValueKind::Bool => "bool".to_string(),
        ValueKind::Number => {
            if value.as_i64().is_some() {
                "int".to_string()
            } else {
                "float".to_string()
            }
        }
        ValueKind::String => "str".to_string(),
        ValueKind::Seq => "list".to_string(),
        ValueKind::Map => "dict".to_string(),
        _ => "unknown".to_string(),
    }
}

fn filter_comment(value: String, style: Option<String>) -> String {
    let prefix = match style.as_deref() {
        Some("c") => "// ",
        Some("cblock") => " * ",
        Some("erlang") => "% ",
        Some("xml") => "<!-- ",
        Some("plain") | None | Some(_) => "# ",
    };
    value
        .lines()
        .map(|line| format!("{}{}", prefix, line))
        .collect::<Vec<_>>()
        .join("\n")
}

fn filter_subelements(
    value: MjValue,
    key: String,
) -> Result<MjValue, minijinja::Error> {
    let arr: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .unwrap_or_default();
    let mut result = Vec::new();
    for item in &arr {
        if let Some(subitems) = item.get(&key).and_then(|v| v.as_array()) {
            for subitem in subitems {
                result.push(serde_json::json!([item, subitem]));
            }
        }
    }
    Ok(MjValue::from_serialize(&result))
}

fn filter_zip(value: MjValue, other: MjValue) -> Result<MjValue, minijinja::Error> {
    let a: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .unwrap_or_default();
    let b: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&other).unwrap_or_default())
            .unwrap_or_default();
    let result: Vec<serde_json::Value> = a
        .into_iter()
        .zip(b)
        .map(|(x, y)| serde_json::json!([x, y]))
        .collect();
    Ok(MjValue::from_serialize(&result))
}

fn filter_zip_longest(value: MjValue, other: MjValue) -> Result<MjValue, minijinja::Error> {
    let a: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .unwrap_or_default();
    let b: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&other).unwrap_or_default())
            .unwrap_or_default();
    let len = a.len().max(b.len());
    let mut result = Vec::new();
    for i in 0..len {
        let x = a.get(i).cloned().unwrap_or(serde_json::Value::Null);
        let y = b.get(i).cloned().unwrap_or(serde_json::Value::Null);
        result.push(serde_json::json!([x, y]));
    }
    Ok(MjValue::from_serialize(&result))
}

fn filter_product(value: MjValue, other: MjValue) -> Result<MjValue, minijinja::Error> {
    let a: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .unwrap_or_default();
    let b: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&other).unwrap_or_default())
            .unwrap_or_default();
    let mut result = Vec::new();
    for x in &a {
        for y in &b {
            result.push(serde_json::json!([x, y]));
        }
    }
    Ok(MjValue::from_serialize(&result))
}

fn filter_permutations(value: MjValue) -> Result<MjValue, minijinja::Error> {
    let arr: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .unwrap_or_default();
    let mut result = Vec::new();
    let n = arr.len();
    let mut indices: Vec<usize> = (0..n).collect();
    loop {
        result.push(serde_json::Value::Array(
            indices.iter().map(|&i| arr[i].clone()).collect(),
        ));
        // Find next permutation
        let mut i = n.wrapping_sub(1);
        if i == usize::MAX {
            break;
        }
        while i > 0 && indices[i - 1] >= indices[i] {
            i -= 1;
        }
        if i == 0 {
            break;
        }
        let mut j = n - 1;
        while indices[j] <= indices[i - 1] {
            j -= 1;
        }
        indices.swap(i - 1, j);
        indices[i..].reverse();
    }
    Ok(MjValue::from_serialize(&result))
}

fn filter_combinations(value: MjValue, r: usize) -> Result<MjValue, minijinja::Error> {
    let arr: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .unwrap_or_default();
    let n = arr.len();
    if r > n {
        return Ok(MjValue::from_serialize(Vec::<serde_json::Value>::new()));
    }
    let mut result = Vec::new();
    let mut indices: Vec<usize> = (0..r).collect();
    loop {
        result.push(serde_json::Value::Array(
            indices.iter().map(|&i| arr[i].clone()).collect(),
        ));
        let mut i = r;
        loop {
            if i == 0 {
                return Ok(MjValue::from_serialize(&result));
            }
            i -= 1;
            if indices[i] != i + n - r {
                break;
            }
        }
        indices[i] += 1;
        for j in (i + 1)..r {
            indices[j] = indices[j - 1] + 1;
        }
    }
}

// ============ Test implementations ============

fn test_match(value: String, pattern: String) -> bool {
    regex::Regex::new(&pattern)
        .map(|re| re.is_match(&value))
        .unwrap_or(false)
}

fn test_search(value: String, pattern: String) -> bool {
    regex::Regex::new(&pattern)
        .map(|re| re.is_match(&value))
        .unwrap_or(false)
}

fn test_regex(value: String, pattern: String) -> bool {
    regex::Regex::new(&pattern)
        .map(|re| re.is_match(&value))
        .unwrap_or(false)
}

fn test_vault_encrypted(value: String) -> bool {
    value.starts_with("$ANSIBLE_VAULT;")
}

fn test_truthy(value: MjValue) -> bool {
    is_truthy(&value)
}

fn test_falsy(value: MjValue) -> bool {
    is_falsy(&value)
}

fn test_any(value: MjValue) -> bool {
    if let Ok(mut iter) = value.try_iter() {
        iter.any(|v| is_truthy(&v))
    } else {
        false
    }
}

fn test_all(value: MjValue) -> bool {
    if let Ok(mut iter) = value.try_iter() {
        iter.all(|v| is_truthy(&v))
    } else {
        false
    }
}

fn test_version(value: String, version: String) -> bool {
    value >= version
}

fn test_subset(value: MjValue, other: MjValue) -> bool {
    let a: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .unwrap_or_default();
    let b: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&other).unwrap_or_default())
            .unwrap_or_default();
    a.iter().all(|item| b.contains(item))
}

fn test_superset(value: MjValue, other: MjValue) -> bool {
    let a: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&other).unwrap_or_default())
            .unwrap_or_default();
    let b: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .unwrap_or_default();
    a.iter().all(|item| b.contains(item))
}

fn test_contains(value: MjValue, item: MjValue) -> bool {
    let arr: Vec<serde_json::Value> =
        serde_json::from_value(serde_json::to_value(&value).unwrap_or_default())
            .unwrap_or_default();
    let target: serde_json::Value =
        serde_json::to_value(&item).unwrap_or_default();
    arr.contains(&target)
}

// ============ Helpers ============

fn is_truthy(value: &MjValue) -> bool {
    use minijinja::value::ValueKind;
    match value.kind() {
        ValueKind::Undefined | ValueKind::None => false,
        ValueKind::Bool => value.is_true(),
        ValueKind::Number => value.as_i64().map(|n| n != 0).unwrap_or(true),
        ValueKind::String => {
            if let Some(s) = value.as_str() {
                !s.is_empty() && s != "false" && s != "False" && s != "no" && s != "0"
            } else {
                true
            }
        }
        ValueKind::Seq => value.len().map(|n| n > 0).unwrap_or(false),
        _ => true, // maps, objects are truthy
    }
}

fn is_falsy(value: &MjValue) -> bool {
    !is_truthy(value)
}

// ---- Phase 7.3 extension: path, uuid, random, extract, checksum ----

fn filter_realpath(value: String) -> String {
    std::fs::canonicalize(&value)
        .map(|p| p.to_string_lossy().into_owned())
        .unwrap_or(value)
}

fn filter_expanduser(value: String) -> String {
    if let Some(rest) = value.strip_prefix('~') {
        if let Ok(home) = std::env::var("HOME") {
            return format!("{}{}", home, rest);
        }
    }
    value
}

/// POSIX-style `$VAR` / `${VAR}` expansion. Unknown vars expand to the
/// empty string, matching ansible's `expandvars` contract.
fn filter_expandvars(value: String) -> String {
    let mut out = String::with_capacity(value.len());
    let bytes = value.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'$' && i + 1 < bytes.len() {
            let (name, advance) = if bytes[i + 1] == b'{' {
                if let Some(end) = value[i + 2..].find('}') {
                    (&value[i + 2..i + 2 + end], end + 3)
                } else {
                    out.push('$');
                    i += 1;
                    continue;
                }
            } else {
                let rest = &value[i + 1..];
                let end = rest
                    .find(|c: char| !c.is_alphanumeric() && c != '_')
                    .unwrap_or(rest.len());
                (&rest[..end], end + 1)
            };
            if name.is_empty() {
                out.push('$');
                i += 1;
                continue;
            }
            if let Ok(v) = std::env::var(name) {
                out.push_str(&v);
            }
            i += advance;
        } else {
            out.push(bytes[i] as char);
            i += 1;
        }
    }
    out
}

fn filter_relpath(value: String, start: Option<String>) -> String {
    let base = start.unwrap_or_else(|| ".".into());
    let target = std::path::Path::new(&value);
    let start = std::path::Path::new(&base);
    target
        .strip_prefix(start)
        .map(|p| p.to_string_lossy().into_owned())
        .unwrap_or(value)
}

fn filter_win_basename(value: String) -> String {
    value
        .rsplit_once(['/', '\\'])
        .map(|(_, tail)| tail.to_string())
        .unwrap_or(value)
}

fn filter_win_dirname(value: String) -> String {
    value
        .rsplit_once(['/', '\\'])
        .map(|(head, _)| head.to_string())
        .unwrap_or_default()
}

/// Version-5-ish UUID: take SHA256 of input and format the first 16
/// bytes as a UUID string. Not a real RFC 4122 UUID (no namespace) but
/// matches ansible's `to_uuid` in the sense that identical inputs
/// always produce identical outputs.
fn filter_to_uuid(value: String) -> String {
    use sha2::{Digest, Sha256};
    let digest = Sha256::digest(value.as_bytes());
    let b = &digest[..16];
    format!(
        "{:02x}{:02x}{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}-{:02x}{:02x}{:02x}{:02x}{:02x}{:02x}",
        b[0], b[1], b[2], b[3], b[4], b[5], b[6], b[7],
        b[8], b[9], b[10], b[11], b[12], b[13], b[14], b[15],
    )
}

/// Deterministic pseudo-random: hash the input + the current time to
/// pick an index. For templating contexts `random` is rarely security-
/// sensitive — it's picking a port, a delay, a mirror — so this is
/// sufficient without pulling in `rand`.
fn filter_random(value: MjValue) -> Result<MjValue, minijinja::Error> {
    let seed = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos() as u64)
        .unwrap_or(0);
    // Int form: `N | random` → integer in [0, N).
    if let Ok(n) = i64::try_from(value.clone()) {
        if n <= 0 {
            return Ok(MjValue::from(0i64));
        }
        return Ok(MjValue::from((seed % (n as u64)) as i64));
    }
    // List form: pick an element.
    let list: Vec<MjValue> = value
        .try_iter()
        .map_err(|e| minijinja::Error::new(minijinja::ErrorKind::InvalidOperation, e.to_string()))?
        .collect();
    if list.is_empty() {
        return Ok(MjValue::UNDEFINED);
    }
    let idx = (seed as usize) % list.len();
    Ok(list[idx].clone())
}

/// Deterministic shuffle seeded on process start time. Again: "good
/// enough for templates, not crypto".
fn filter_shuffle(value: MjValue) -> Result<MjValue, minijinja::Error> {
    let mut list: Vec<MjValue> = value
        .try_iter()
        .map_err(|e| minijinja::Error::new(minijinja::ErrorKind::InvalidOperation, e.to_string()))?
        .collect();
    let seed = std::time::SystemTime::now()
        .duration_since(std::time::UNIX_EPOCH)
        .map(|d| d.as_nanos() as u64)
        .unwrap_or(0);
    // Fisher-Yates with a cheap LCG seeded on `seed`. Enough to
    // distinguish output across calls without introducing `rand`.
    let mut rng = seed | 1; // avoid zero
    for i in (1..list.len()).rev() {
        rng = rng.wrapping_mul(6364136223846793005).wrapping_add(1442695040888963407);
        let j = (rng as usize) % (i + 1);
        list.swap(i, j);
    }
    Ok(MjValue::from_serialize(&list))
}

fn filter_extract(key: MjValue, container: MjValue) -> Result<MjValue, minijinja::Error> {
    container
        .get_item(&key)
        .map_err(|e| minijinja::Error::new(minijinja::ErrorKind::InvalidOperation, e.to_string()))
}

/// Alias for `hash(..., 'sha256')` applied to a file's contents. If the
/// path is missing or unreadable, raise an error so templates don't
/// silently produce a hash of the empty string.
fn filter_checksum(value: String) -> Result<String, minijinja::Error> {
    use sha2::{Digest, Sha256};
    let bytes = std::fs::read(&value).map_err(|e| {
        minijinja::Error::new(
            minijinja::ErrorKind::InvalidOperation,
            format!("checksum: cannot read {}: {}", value, e),
        )
    })?;
    Ok(format!("{:x}", Sha256::digest(&bytes)))
}

fn filter_password_hash_unsupported(
    _value: String,
    _algo: Option<String>,
) -> Result<String, minijinja::Error> {
    Err(minijinja::Error::new(
        minijinja::ErrorKind::InvalidOperation,
        "password_hash is not implemented in ansible-core-rs \
         (avoid pulling in a crypt(3) dep); compute the hash outside \
         the template and pass it in as a variable",
    ))
}

// ---- Phase 7.3 extension: filesystem tests ----

fn test_is_file(value: String) -> bool {
    std::path::Path::new(&value).is_file()
}
fn test_is_directory(value: String) -> bool {
    std::path::Path::new(&value).is_dir()
}
fn test_is_link(value: String) -> bool {
    std::fs::symlink_metadata(&value)
        .map(|m| m.file_type().is_symlink())
        .unwrap_or(false)
}
fn test_exists(value: String) -> bool {
    std::path::Path::new(&value).exists()
}
fn test_is_abs(value: String) -> bool {
    std::path::Path::new(&value).is_absolute()
}

// ============ Phase 7.3 batch 2: missing filter implementations ============

/// Escape special regex characters so the string can be used as a literal
/// in a regular expression. Matches Python's `re.escape()`.
fn filter_regex_escape(value: String) -> String {
    let mut out = String::with_capacity(value.len() * 2);
    for ch in value.chars() {
        if "\\.|*+?{}[]()^$-#&~".contains(ch) {
            out.push('\\');
        }
        out.push(ch);
    }
    out
}

/// Join path components. Accepts a string base and either a string or list argument.
/// `"/etc" | path_join("hosts")` → "/etc/hosts"
/// `["/etc", "ansible", "hosts"] | path_join` → "/etc/ansible/hosts"
fn filter_path_join(value: MjValue, append: Option<String>) -> Result<String, minijinja::Error> {
    use minijinja::value::ValueKind;
    // If value is a list (not a string), join all elements as path components
    if value.kind() == ValueKind::Seq {
        if let Ok(iter) = value.try_iter() {
            let parts: Vec<String> = iter.map(|v| v.to_string()).collect();
            let mut path = std::path::PathBuf::new();
            for part in &parts {
                path.push(part);
            }
            if let Some(extra) = append {
                path.push(extra);
            }
            return Ok(path.to_string_lossy().into_owned());
        }
    }
    // String base + append
    let base = value.to_string();
    match append {
        Some(tail) => {
            let mut p = std::path::PathBuf::from(&base);
            p.push(&tail);
            Ok(p.to_string_lossy().into_owned())
        }
        None => Ok(base),
    }
}

/// Normalize a path — collapse `..`, `.`, and redundant separators.
/// Matches Python's `os.path.normpath()`.
fn filter_normpath(value: String) -> String {
    let mut components = Vec::new();
    let is_absolute = value.starts_with('/');

    for part in value.split('/') {
        match part {
            "" | "." => {}
            ".." => {
                if !is_absolute && (components.is_empty() || components.last() == Some(&"..")) {
                    components.push("..");
                } else if !components.is_empty() && components.last() != Some(&"..") {
                    components.pop();
                }
            }
            other => components.push(other),
        }
    }

    let joined = components.join("/");
    if is_absolute {
        format!("/{joined}")
    } else if joined.is_empty() {
        ".".to_string()
    } else {
        joined
    }
}

/// MD5 hash of a string value.
fn filter_md5(value: String) -> String {
    use md5::Digest;
    let mut hasher = md5::Md5::new();
    hasher.update(value.as_bytes());
    format!("{:x}", hasher.finalize())
}

/// SHA1 hash of a string value.
fn filter_sha1(value: String) -> String {
    use sha1::Digest;
    let mut hasher = sha1::Sha1::new();
    hasher.update(value.as_bytes());
    format!("{:x}", hasher.finalize())
}

/// Parse a date string into epoch seconds. Supports ISO 8601 and common
/// formats. Returns epoch as a string so it can be piped to strftime.
/// Ansible's `to_datetime` accepts an optional format string; we support
/// the most common cases without pulling in chrono.
fn filter_to_datetime(value: String, _fmt: Option<String>) -> Result<String, minijinja::Error> {
    // Try ISO 8601: "2024-01-15T10:30:00Z" or "2024-01-15 10:30:00"
    // Simple parser — handles YYYY-MM-DD[T ]HH:MM:SS[Z]
    let s = value.trim().trim_end_matches('Z');
    let parts: Vec<&str> = s.splitn(2, ['T', ' ']).collect();
    if parts.len() == 2 {
        let date_parts: Vec<&str> = parts[0].split('-').collect();
        let time_parts: Vec<&str> = parts[1].split(':').collect();
        if date_parts.len() == 3 && time_parts.len() >= 2 {
            if let (Ok(y), Ok(m), Ok(d), Ok(h), Ok(min)) = (
                date_parts[0].parse::<i64>(),
                date_parts[1].parse::<i64>(),
                date_parts[2].parse::<i64>(),
                time_parts[0].parse::<i64>(),
                time_parts[1].parse::<i64>(),
            ) {
                let sec = time_parts
                    .get(2)
                    .and_then(|s| s.split('.').next())
                    .and_then(|s| s.parse::<i64>().ok())
                    .unwrap_or(0);
                // Days from epoch (1970-01-01) using a simple calendar calc
                let epoch = simple_datetime_to_epoch(y, m, d, h, min, sec);
                return Ok(epoch.to_string());
            }
        }
    }
    // Try bare epoch
    if let Ok(n) = value.trim().parse::<i64>() {
        return Ok(n.to_string());
    }
    Err(minijinja::Error::new(
        minijinja::ErrorKind::InvalidOperation,
        format!("to_datetime: cannot parse '{value}'"),
    ))
}

/// Format an epoch timestamp. Ansible's strftime takes epoch seconds.
/// We support a small subset of strftime directives without pulling in chrono.
fn filter_strftime(value: MjValue, fmt: Option<String>) -> Result<String, minijinja::Error> {
    let epoch = if let Some(n) = value.as_i64() {
        n
    } else if let Some(s) = value.as_str() {
        s.parse::<i64>().map_err(|_| {
            minijinja::Error::new(
                minijinja::ErrorKind::InvalidOperation,
                format!("strftime: cannot parse epoch from '{s}'"),
            )
        })?
    } else {
        return Err(minijinja::Error::new(
            minijinja::ErrorKind::InvalidOperation,
            "strftime requires an integer epoch",
        ));
    };

    let format = fmt.unwrap_or_else(|| "%Y-%m-%d %H:%M:%S".to_string());
    let (y, mo, d, h, mi, s) = epoch_to_datetime(epoch);

    let result = format
        .replace("%Y", &format!("{y:04}"))
        .replace("%m", &format!("{mo:02}"))
        .replace("%d", &format!("{d:02}"))
        .replace("%H", &format!("{h:02}"))
        .replace("%M", &format!("{mi:02}"))
        .replace("%S", &format!("{s:02}"));
    Ok(result)
}

/// Convert a byte count to human-readable form (e.g., 1048576 → "1.00 MB").
fn filter_human_readable(value: MjValue, iec: Option<bool>) -> Result<String, minijinja::Error> {
    let bytes = if let Some(n) = value.as_i64() {
        n as f64
    } else if let Some(s) = value.as_str() {
        s.parse::<f64>().unwrap_or(0.0)
    } else {
        0.0
    };

    let use_iec = iec.unwrap_or(false);
    let (divisor, suffixes): (f64, &[&str]) = if use_iec {
        (1024.0, &["Bytes", "KiB", "MiB", "GiB", "TiB", "PiB"])
    } else {
        (1000.0, &["Bytes", "KB", "MB", "GB", "TB", "PB"])
    };

    let mut val = bytes.abs();
    let sign = if bytes < 0.0 { "-" } else { "" };
    for (i, suffix) in suffixes.iter().enumerate() {
        if val < divisor || i == suffixes.len() - 1 {
            return if i == 0 {
                Ok(format!("{sign}{val:.0} {suffix}"))
            } else {
                Ok(format!("{sign}{val:.2} {suffix}"))
            };
        }
        val /= divisor;
    }
    Ok(format!("{sign}{val:.2} Bytes"))
}

/// Convert human-readable size strings to bytes.
/// "1 MB" → 1000000, "1 MiB" → 1048576, "10K" → 10240
fn filter_human_to_bytes(value: MjValue) -> Result<i64, minijinja::Error> {
    let s = if let Some(s) = value.as_str() {
        s.to_string()
    } else if let Some(n) = value.as_i64() {
        return Ok(n);
    } else {
        return Err(minijinja::Error::new(
            minijinja::ErrorKind::InvalidOperation,
            "human_to_bytes requires a string or number",
        ));
    };

    let s = s.trim();

    // Find where the numeric part ends
    let num_end = s
        .find(|c: char| !c.is_ascii_digit() && c != '.' && c != '-')
        .unwrap_or(s.len());
    let (num_str, suffix) = s.split_at(num_end);
    let num: f64 = num_str.trim().parse().map_err(|_| {
        minijinja::Error::new(
            minijinja::ErrorKind::InvalidOperation,
            format!("human_to_bytes: cannot parse number from '{s}'"),
        )
    })?;
    let suffix = suffix.trim().to_uppercase();

    let multiplier: f64 = match suffix.as_str() {
        "" | "B" | "BYTES" => 1.0,
        "K" | "KB" => 1000.0,
        "KIB" => 1024.0,
        "M" | "MB" => 1_000_000.0,
        "MIB" => 1_048_576.0,
        "G" | "GB" => 1_000_000_000.0,
        "GIB" => 1_073_741_824.0,
        "T" | "TB" => 1_000_000_000_000.0,
        "TIB" => 1_099_511_627_776.0,
        "P" | "PB" => 1_000_000_000_000_000.0,
        "PIB" => 1_125_899_906_842_624.0,
        other => {
            return Err(minijinja::Error::new(
                minijinja::ErrorKind::InvalidOperation,
                format!("human_to_bytes: unknown suffix '{other}'"),
            ));
        }
    };

    Ok((num * multiplier) as i64)
}

/// Split a URL into components. Returns a dict with keys:
/// scheme, netloc, path, query, fragment, hostname, port, username, password
fn filter_urlsplit(value: String, query: Option<String>) -> Result<MjValue, minijinja::Error> {
    let (scheme, rest) = if let Some(idx) = value.find("://") {
        (&value[..idx], &value[idx + 3..])
    } else {
        ("", value.as_str())
    };

    // Split off fragment
    let (before_fragment, fragment) = rest.split_once('#').unwrap_or((rest, ""));
    // Split off query
    let (path_part, query_str) = before_fragment.split_once('?').unwrap_or((before_fragment, ""));
    // Split netloc from path
    let (netloc, path) = if scheme.is_empty() {
        ("", path_part)
    } else if let Some(idx) = path_part.find('/') {
        (&path_part[..idx], &path_part[idx..])
    } else {
        (path_part, "")
    };

    // Parse netloc for username, password, hostname, port
    let (userinfo, hostport) = if let Some(idx) = netloc.find('@') {
        (&netloc[..idx], &netloc[idx + 1..])
    } else {
        ("", netloc)
    };
    let (username, password) = userinfo.split_once(':').unwrap_or((userinfo, ""));
    let (hostname, port_str) = if hostport.starts_with('[') {
        // IPv6
        if let Some(end) = hostport.find(']') {
            let host = &hostport[1..end];
            let port = hostport[end + 1..].strip_prefix(':').unwrap_or("");
            (host, port)
        } else {
            (hostport, "")
        }
    } else {
        hostport.rsplit_once(':').unwrap_or((hostport, ""))
    };

    let port: Option<i64> = port_str.parse().ok();

    // If query param specified, return just that component
    if let Some(q) = query {
        let result = match q.as_str() {
            "scheme" => MjValue::from(scheme),
            "netloc" => MjValue::from(netloc),
            "path" => MjValue::from(path),
            "query" => MjValue::from(query_str),
            "fragment" => MjValue::from(fragment),
            "hostname" => MjValue::from(hostname),
            "port" => port.map(MjValue::from).unwrap_or(MjValue::from("")),
            "username" => MjValue::from(username),
            "password" => MjValue::from(password),
            other => {
                return Err(minijinja::Error::new(
                    minijinja::ErrorKind::InvalidOperation,
                    format!("urlsplit: unknown component '{other}'"),
                ));
            }
        };
        return Ok(result);
    }

    let mut map = serde_json::Map::new();
    map.insert("scheme".into(), serde_json::Value::String(scheme.to_string()));
    map.insert("netloc".into(), serde_json::Value::String(netloc.to_string()));
    map.insert("path".into(), serde_json::Value::String(path.to_string()));
    map.insert("query".into(), serde_json::Value::String(query_str.to_string()));
    map.insert("fragment".into(), serde_json::Value::String(fragment.to_string()));
    map.insert("hostname".into(), serde_json::Value::String(hostname.to_string()));
    map.insert("port".into(), port.map(serde_json::Value::from).unwrap_or(serde_json::Value::Null));
    map.insert("username".into(), serde_json::Value::String(username.to_string()));
    map.insert("password".into(), serde_json::Value::String(password.to_string()));
    Ok(MjValue::from_serialize(&map))
}

/// URL-encode a string (percent encoding).
fn filter_urlencode(value: String) -> String {
    let mut encoded = String::with_capacity(value.len() * 3);
    for byte in value.bytes() {
        match byte {
            b'A'..=b'Z' | b'a'..=b'z' | b'0'..=b'9' | b'-' | b'_' | b'.' | b'~' => {
                encoded.push(byte as char);
            }
            _ => {
                encoded.push_str(&format!("%{byte:02X}"));
            }
        }
    }
    encoded
}

/// URL-decode a percent-encoded string.
fn filter_urldecode(value: String) -> String {
    let mut decoded = Vec::with_capacity(value.len());
    let bytes = value.as_bytes();
    let mut i = 0;
    while i < bytes.len() {
        if bytes[i] == b'%' && i + 2 < bytes.len() {
            if let Ok(byte) = u8::from_str_radix(
                std::str::from_utf8(&bytes[i + 1..i + 3]).unwrap_or(""),
                16,
            ) {
                decoded.push(byte);
                i += 3;
                continue;
            }
        }
        if bytes[i] == b'+' {
            decoded.push(b' ');
        } else {
            decoded.push(bytes[i]);
        }
        i += 1;
    }
    String::from_utf8(decoded).unwrap_or(value)
}

/// Split a Windows drive spec from a path.
/// "C:\\Users\\foo" → ["C:", "\\Users\\foo"]
fn filter_win_splitdrive(value: String) -> MjValue {
    // Check for drive letter (e.g., "C:")
    if value.len() >= 2 && value.as_bytes()[1] == b':' && value.as_bytes()[0].is_ascii_alphabetic()
    {
        MjValue::from_serialize(vec![&value[..2], &value[2..]])
    } else if value.starts_with("\\\\") || value.starts_with("//") {
        // UNC path
        let rest = &value[2..];
        if let Some(idx) = rest.find(['\\', '/']) {
            let after = &rest[idx + 1..];
            if let Some(idx2) = after.find(['\\', '/']) {
                let drive_end = 2 + idx + 1 + idx2;
                MjValue::from_serialize(vec![&value[..drive_end], &value[drive_end..]])
            } else {
                MjValue::from_serialize(vec![&value[..], ""])
            }
        } else {
            MjValue::from_serialize(vec![&value[..], ""])
        }
    } else {
        MjValue::from_serialize(vec!["", value.as_str()])
    }
}

/// Split a string by a delimiter. MiniJinja has a builtin `split` but
/// Ansible's version is subtly different in edge cases — register ours
/// to ensure compatibility.
fn filter_split(value: String, sep: Option<String>) -> MjValue {
    let parts: Vec<&str> = match &sep {
        Some(s) => value.split(s.as_str()).collect(),
        None => value.split_whitespace().collect(),
    };
    MjValue::from_serialize(&parts)
}

/// Count words in a string.
fn filter_wordcount(value: String) -> usize {
    value.split_whitespace().count()
}

/// Extract a named attribute from each item in a list.
/// `users | map(attribute='name')` works natively in MiniJinja, but
/// `users | map_attribute('name')` is also used.
fn filter_map_attribute(value: MjValue, attr: String) -> Result<MjValue, minijinja::Error> {
    let items: Vec<MjValue> = value
        .try_iter()
        .map_err(|e| {
            minijinja::Error::new(minijinja::ErrorKind::InvalidOperation, e.to_string())
        })?
        .collect();
    let results: Vec<MjValue> = items
        .iter()
        .map(|item| item.get_attr(&attr).unwrap_or(MjValue::UNDEFINED))
        .collect();
    Ok(MjValue::from_serialize(&results))
}

// ---- Date/time helpers (no chrono dependency) ----

fn is_leap_year(y: i64) -> bool {
    (y % 4 == 0 && y % 100 != 0) || y % 400 == 0
}

fn days_in_month(y: i64, m: i64) -> i64 {
    match m {
        1 | 3 | 5 | 7 | 8 | 10 | 12 => 31,
        4 | 6 | 9 | 11 => 30,
        2 => if is_leap_year(y) { 29 } else { 28 },
        _ => 30,
    }
}

fn simple_datetime_to_epoch(y: i64, m: i64, d: i64, h: i64, min: i64, sec: i64) -> i64 {
    // Days from 1970-01-01
    let mut days: i64 = 0;
    for year in 1970..y {
        days += if is_leap_year(year) { 366 } else { 365 };
    }
    for year in (y..1970).rev() {
        days -= if is_leap_year(year) { 366 } else { 365 };
    }
    for month in 1..m {
        days += days_in_month(y, month);
    }
    days += d - 1;
    days * 86400 + h * 3600 + min * 60 + sec
}

fn epoch_to_datetime(epoch: i64) -> (i64, i64, i64, i64, i64, i64) {
    let secs_per_day: i64 = 86400;
    let mut remaining = epoch;
    let mut year = 1970i64;

    if remaining >= 0 {
        loop {
            let days_in_year = if is_leap_year(year) { 366 } else { 365 };
            if remaining < days_in_year * secs_per_day {
                break;
            }
            remaining -= days_in_year * secs_per_day;
            year += 1;
        }
    } else {
        loop {
            year -= 1;
            let days_in_year = if is_leap_year(year) { 366 } else { 365 };
            remaining += days_in_year * secs_per_day;
            if remaining >= 0 {
                break;
            }
        }
    }

    let day_of_year = remaining / secs_per_day;
    remaining %= secs_per_day;
    let hour = remaining / 3600;
    remaining %= 3600;
    let minute = remaining / 60;
    let second = remaining % 60;

    let mut month = 1i64;
    let mut day = day_of_year;
    loop {
        let dim = days_in_month(year, month);
        if day < dim {
            break;
        }
        day -= dim;
        month += 1;
    }
    day += 1; // 1-indexed

    (year, month, day, hour, minute, second)
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_template_string_no_markers() {
        let templar = Templar::new();
        assert_eq!(templar.template_string("hello world").unwrap(), "hello world");
    }

    #[test]
    fn test_template_string_variable() {
        let mut templar = Templar::new();
        let mut vars = HashMap::new();
        vars.insert("name".to_string(), AnsibleValue::String("Ansible".into()));
        templar.set_variables(vars);
        assert_eq!(
            templar.template_string("Hello {{ name }}!").unwrap(),
            "Hello Ansible!"
        );
    }

    #[test]
    fn test_template_conditional() {
        let mut templar = Templar::new();
        let mut vars = HashMap::new();
        vars.insert("enabled".to_string(), AnsibleValue::Bool(true));
        templar.set_variables(vars);
        assert!(templar.evaluate_conditional("enabled").unwrap());
    }

    #[test]
    fn test_template_conditional_false() {
        let mut templar = Templar::new();
        let mut vars = HashMap::new();
        vars.insert("enabled".to_string(), AnsibleValue::Bool(false));
        templar.set_variables(vars);
        assert!(!templar.evaluate_conditional("enabled").unwrap());
    }

    #[test]
    fn test_template_conditional_comparison() {
        let mut templar = Templar::new();
        let mut vars = HashMap::new();
        vars.insert("port".to_string(), AnsibleValue::from(8080));
        templar.set_variables(vars);
        assert!(templar.evaluate_conditional("port == 8080").unwrap());
        assert!(!templar.evaluate_conditional("port == 9090").unwrap());
    }

    #[test]
    fn test_filter_default() {
        let mut templar = Templar::new();
        templar.set_variables(HashMap::new());
        let result = templar
            .template_string("{{ missing | default('fallback') }}")
            .unwrap();
        assert_eq!(result, "fallback");
    }

    #[test]
    fn test_filter_ternary() {
        let mut templar = Templar::new();
        let mut vars = HashMap::new();
        vars.insert("flag".to_string(), AnsibleValue::Bool(true));
        templar.set_variables(vars);
        let result = templar
            .template_string("{{ flag | ternary('yes', 'no') }}")
            .unwrap();
        assert_eq!(result, "yes");
    }

    #[test]
    fn test_filter_b64encode_decode() {
        let mut templar = Templar::new();
        let mut vars = HashMap::new();
        vars.insert("data".to_string(), AnsibleValue::String("hello".into()));
        templar.set_variables(vars);
        let encoded = templar
            .template_string("{{ data | b64encode }}")
            .unwrap();
        assert_eq!(encoded, "aGVsbG8=");
    }

    #[test]
    fn test_filter_basename_dirname() {
        let mut templar = Templar::new();
        let mut vars = HashMap::new();
        vars.insert(
            "path".to_string(),
            AnsibleValue::String("/etc/ansible/hosts".into()),
        );
        templar.set_variables(vars);
        assert_eq!(
            templar.template_string("{{ path | basename }}").unwrap(),
            "hosts"
        );
        assert_eq!(
            templar.template_string("{{ path | dirname }}").unwrap(),
            "/etc/ansible"
        );
    }

    #[test]
    fn test_filter_regex_replace() {
        let mut templar = Templar::new();
        let mut vars = HashMap::new();
        vars.insert("text".to_string(), AnsibleValue::String("foo123bar".into()));
        templar.set_variables(vars);
        let result = templar
            .template_string("{{ text | regex_replace('[0-9]+', 'NUM') }}")
            .unwrap();
        assert_eq!(result, "fooNUMbar");
    }

    #[test]
    fn test_filter_quote() {
        let mut templar = Templar::new();
        let mut vars = HashMap::new();
        vars.insert(
            "cmd".to_string(),
            AnsibleValue::String("echo hello world".into()),
        );
        templar.set_variables(vars);
        let result = templar.template_string("{{ cmd | quote }}").unwrap();
        assert_eq!(result, "'echo hello world'");
    }

    #[test]
    fn test_filter_int_conversion() {
        let mut templar = Templar::new();
        let mut vars = HashMap::new();
        vars.insert("val".to_string(), AnsibleValue::String("42".into()));
        templar.set_variables(vars);
        let result = templar.template_string("{{ val | int }}").unwrap();
        assert_eq!(result, "42");
    }

    #[test]
    fn test_filter_comment() {
        let mut templar = Templar::new();
        let mut vars = HashMap::new();
        vars.insert("text".to_string(), AnsibleValue::String("line1\nline2".into()));
        templar.set_variables(vars);
        let result = templar.template_string("{{ text | comment }}").unwrap();
        assert_eq!(result, "# line1\n# line2");
    }

    #[test]
    fn test_filter_to_uuid_deterministic() {
        let mut t = Templar::new();
        let mut vars = HashMap::new();
        vars.insert("s".into(), AnsibleValue::String("hello".into()));
        t.set_variables(vars);
        let r1 = t.template_string("{{ s | to_uuid }}").unwrap();
        let r2 = t.template_string("{{ s | to_uuid }}").unwrap();
        assert_eq!(r1, r2);
        assert_eq!(r1.len(), 36); // "xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx"
        assert_eq!(r1.chars().filter(|c| *c == '-').count(), 4);
    }

    #[test]
    fn test_filter_expanduser_and_expandvars() {
        std::env::set_var("HOME", "/home/deck");
        std::env::set_var("FOO", "bar");
        let t = Templar::new();
        assert_eq!(
            t.template_string("{{ '~/x' | expanduser }}").unwrap(),
            "/home/deck/x"
        );
        assert_eq!(
            t.template_string("{{ '$FOO-${FOO}' | expandvars }}").unwrap(),
            "bar-bar"
        );
    }

    #[test]
    fn test_fs_tests() {
        let dir = tempfile::tempdir().unwrap();
        let f = dir.path().join("x");
        std::fs::write(&f, b"hi").unwrap();
        let mut t = Templar::new();
        let mut vars = HashMap::new();
        vars.insert(
            "p".into(),
            AnsibleValue::String(f.to_string_lossy().into_owned()),
        );
        vars.insert(
            "d".into(),
            AnsibleValue::String(dir.path().to_string_lossy().into_owned()),
        );
        t.set_variables(vars);
        assert_eq!(t.template_string("{{ p is file }}").unwrap(), "true");
        assert_eq!(t.template_string("{{ d is directory }}").unwrap(), "true");
        assert_eq!(t.template_string("{{ p is exists }}").unwrap(), "true");
        assert_eq!(t.template_string("{{ p is abs }}").unwrap(), "true");
    }

    #[test]
    fn test_filter_shuffle_preserves_elements() {
        let t = Templar::new();
        let r = t
            .template_string("{{ [1,2,3,4,5] | shuffle | sort | join(',') }}")
            .unwrap();
        assert_eq!(r, "1,2,3,4,5");
    }

    #[test]
    fn test_template_value_recursive() {
        let mut templar = Templar::new();
        let mut vars = HashMap::new();
        vars.insert("user".to_string(), AnsibleValue::String("admin".into()));
        templar.set_variables(vars);

        let input = AnsibleValue::Object({
            let mut map = serde_json::Map::new();
            map.insert(
                "name".into(),
                AnsibleValue::String("{{ user }}".into()),
            );
            map.insert("port".into(), AnsibleValue::from(80));
            map
        });

        let result = templar.template_value(&input).unwrap();
        match result {
            AnsibleValue::Object(map) => {
                assert_eq!(
                    map.get("name"),
                    Some(&AnsibleValue::String("admin".into()))
                );
                assert_eq!(map.get("port"), Some(&AnsibleValue::from(80)));
            }
            _ => panic!("expected object"),
        }
    }

    #[test]
    fn test_is_template() {
        assert!(Templar::is_template("{{ foo }}"));
        assert!(Templar::is_template("{% if x %}y{% endif %}"));
        assert!(!Templar::is_template("plain text"));
    }

    #[test]
    fn test_filter_regex_escape() {
        let t = Templar::new();
        let r = t.template_string("{{ 'hello.world*' | regex_escape }}").unwrap();
        assert_eq!(r, r"hello\.world\*");
    }

    #[test]
    fn test_filter_path_join_string() {
        let t = Templar::new();
        let r = t.template_string("{{ '/etc' | path_join('hosts') }}").unwrap();
        assert_eq!(r, "/etc/hosts");
    }

    #[test]
    fn test_filter_path_join_list() {
        let t = Templar::new();
        let r = t.template_string("{{ ['/etc', 'ansible', 'hosts'] | path_join }}").unwrap();
        assert_eq!(r, "/etc/ansible/hosts");
    }

    #[test]
    fn test_filter_normpath() {
        let t = Templar::new();
        assert_eq!(
            t.template_string("{{ '/etc/../var/./log' | normpath }}").unwrap(),
            "/var/log"
        );
        assert_eq!(
            t.template_string("{{ 'a/b/../c' | normpath }}").unwrap(),
            "a/c"
        );
    }

    #[test]
    fn test_filter_md5() {
        let t = Templar::new();
        let r = t.template_string("{{ 'hello' | md5 }}").unwrap();
        assert_eq!(r, "5d41402abc4b2a76b9719d911017c592");
    }

    #[test]
    fn test_filter_sha1() {
        let t = Templar::new();
        let r = t.template_string("{{ 'hello' | sha1 }}").unwrap();
        assert_eq!(r, "aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d");
    }

    #[test]
    fn test_filter_human_readable() {
        let t = Templar::new();
        assert_eq!(
            t.template_string("{{ 1048576 | human_readable }}").unwrap(),
            "1.05 MB"
        );
        assert_eq!(
            t.template_string("{{ 1048576 | human_readable(true) }}").unwrap(),
            "1.00 MiB"
        );
    }

    #[test]
    fn test_filter_human_to_bytes() {
        let t = Templar::new();
        assert_eq!(
            t.template_string("{{ '1 MB' | human_to_bytes }}").unwrap(),
            "1000000"
        );
        assert_eq!(
            t.template_string("{{ '1 MiB' | human_to_bytes }}").unwrap(),
            "1048576"
        );
    }

    #[test]
    fn test_filter_urlsplit() {
        let mut t = Templar::new();
        let mut vars = HashMap::new();
        vars.insert("url".into(), AnsibleValue::String("https://user:pass@example.com:8080/path?q=1#frag".into()));
        t.set_variables(vars);
        assert_eq!(
            t.template_string("{{ url | urlsplit('scheme') }}").unwrap(),
            "https"
        );
        assert_eq!(
            t.template_string("{{ url | urlsplit('hostname') }}").unwrap(),
            "example.com"
        );
        assert_eq!(
            t.template_string("{{ url | urlsplit('port') }}").unwrap(),
            "8080"
        );
        assert_eq!(
            t.template_string("{{ url | urlsplit('path') }}").unwrap(),
            "/path"
        );
        assert_eq!(
            t.template_string("{{ url | urlsplit('query') }}").unwrap(),
            "q=1"
        );
        assert_eq!(
            t.template_string("{{ url | urlsplit('fragment') }}").unwrap(),
            "frag"
        );
        assert_eq!(
            t.template_string("{{ url | urlsplit('username') }}").unwrap(),
            "user"
        );
    }

    #[test]
    fn test_filter_urlencode_urldecode() {
        let t = Templar::new();
        assert_eq!(
            t.template_string("{{ 'hello world&foo=bar' | urlencode }}").unwrap(),
            "hello%20world%26foo%3Dbar"
        );
        assert_eq!(
            t.template_string("{{ 'hello%20world' | urldecode }}").unwrap(),
            "hello world"
        );
    }

    #[test]
    fn test_filter_to_bool() {
        let t = Templar::new();
        assert_eq!(
            t.template_string("{{ 'yes' | to_bool }}").unwrap(),
            "true"
        );
    }

    #[test]
    fn test_filter_win_splitdrive() {
        let t = Templar::new();
        let r = t.template_string("{{ 'C:\\\\Users\\\\foo' | win_splitdrive }}").unwrap();
        assert!(r.contains("C:"));
    }

    #[test]
    fn test_filter_split() {
        let t = Templar::new();
        assert_eq!(
            t.template_string("{{ 'a,b,c' | split(',') | join(':') }}").unwrap(),
            "a:b:c"
        );
    }

    #[test]
    fn test_filter_wordcount() {
        let t = Templar::new();
        assert_eq!(
            t.template_string("{{ 'hello world foo' | wordcount }}").unwrap(),
            "3"
        );
    }

    #[test]
    fn test_filter_to_datetime_and_strftime() {
        let t = Templar::new();
        // Parse ISO 8601 date to epoch, then format it back
        let epoch = t.template_string("{{ '2024-01-15T10:30:00Z' | to_datetime }}").unwrap();
        let epoch_i: i64 = epoch.parse().unwrap();
        assert!(epoch_i > 0);
        // Format epoch back to date string
        let mut t2 = Templar::new();
        let mut vars = HashMap::new();
        vars.insert("ts".into(), AnsibleValue::from(epoch_i));
        t2.set_variables(vars);
        let formatted = t2.template_string("{{ ts | strftime('%Y-%m-%d') }}").unwrap();
        assert_eq!(formatted, "2024-01-15");
    }

    // ── Python Jinja2 fallback ─────────────────────────────────────
    // These tests require the `python-fallback` feature AND a working
    // `jinja2` package in the embedded interpreter. They're no-ops
    // (skipped at runtime) if jinja2 isn't importable so the suite still
    // runs green on minimal Python installs.

    #[cfg(feature = "python-fallback")]
    fn jinja2_available() -> bool {
        use pyo3::prelude::*;
        Python::with_gil(|py| py.import("jinja2").is_ok())
    }

    #[cfg(feature = "python-fallback")]
    #[test]
    fn test_fallback_disabled_by_default_errors_surface() {
        // An unknown filter under MiniJinja should surface the original
        // MiniJinja error when the fallback is NOT enabled, even if the
        // feature is compiled in.
        let t = Templar::new();
        let err = t.template_string("{{ 'x' | no_such_filter_xyz }}");
        assert!(err.is_err(), "expected error without fallback");
    }

    #[cfg(feature = "python-fallback")]
    #[test]
    fn test_fallback_renders_simple_template() {
        if !jinja2_available() {
            eprintln!("skipping: jinja2 not installed");
            return;
        }
        let mut t = Templar::new().with_python_fallback();
        let mut vars = HashMap::new();
        vars.insert("name".to_string(), serde_json::json!("bob"));
        t.set_variables(vars);
        // MiniJinja handles this too; the point is that enabling fallback
        // doesn't break the happy path — MiniJinja still wins when it can.
        assert_eq!(
            t.template_string("Hello {{ name }}!").unwrap(),
            "Hello bob!"
        );
    }

    #[cfg(feature = "python-fallback")]
    #[test]
    fn test_fallback_kicks_in_for_minijinja_errors() {
        if !jinja2_available() {
            return;
        }
        // `format` is a Jinja2 method-style filter that MiniJinja doesn't
        // expose with the same signature. Under the fallback, Python's
        // Jinja2 handles it natively.
        let mut t = Templar::new().with_python_fallback();
        let mut vars = HashMap::new();
        vars.insert("pct".to_string(), serde_json::json!(42));
        t.set_variables(vars);
        let rendered = t
            .template_string("{{ '%d%%' | format(pct) }}")
            .expect("fallback should render Python Jinja2 %-format");
        assert_eq!(rendered, "42%");
    }

    #[cfg(feature = "python-fallback")]
    #[test]
    fn test_fallback_conditional() {
        if !jinja2_available() {
            return;
        }
        let mut t = Templar::new().with_python_fallback();
        let mut vars = HashMap::new();
        vars.insert("n".to_string(), serde_json::json!(7));
        t.set_variables(vars);
        // Works under MiniJinja; fallback path shouldn't regress
        // straightforward boolean expressions.
        assert!(t.evaluate_conditional("n > 5").unwrap());
        assert!(!t.evaluate_conditional("n > 100").unwrap());
    }

    #[cfg(feature = "python-fallback")]
    #[test]
    fn test_fallback_runtime_toggle() {
        let mut t = Templar::new();
        assert!(!t.python_fallback);
        t.set_python_fallback(true);
        assert!(t.python_fallback);
        t.set_python_fallback(false);
        assert!(!t.python_fallback);
    }
}
