use thiserror::Error;

#[derive(Debug, Error)]
pub enum TemplateError {
    #[error("template rendering error: {0}")]
    RenderError(String),

    #[error("undefined variable: {0}")]
    UndefinedVariable(String),

    #[error("filter error: {0}")]
    FilterError(String),

    #[error(transparent)]
    MiniJinja(#[from] minijinja::Error),
}
