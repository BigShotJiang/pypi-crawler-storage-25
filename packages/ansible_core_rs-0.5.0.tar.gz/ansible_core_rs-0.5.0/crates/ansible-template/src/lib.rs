pub mod error;
#[cfg(feature = "python-fallback")]
pub mod python_fallback;
pub mod templar;

pub use error::TemplateError;
pub use templar::Templar;
