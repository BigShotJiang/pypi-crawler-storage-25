//! Embedded-Python Jinja2 fallback for templates MiniJinja can't render.
//!
//! Phase 7.4 of the migration: keep MiniJinja as the primary renderer (fast,
//! pure-Rust) but fall back to Python's `jinja2` for templates that use
//! features MiniJinja doesn't support — custom Jinja2 extensions, the
//! `NativeEnvironment` return-type coercion, or syntax only the upstream
//! parser accepts. The fallback is opt-in at the Templar level and is
//! compiled out entirely unless the `python-fallback` feature is enabled.
//!
//! Variables are marshalled via JSON: the Rust caller already holds
//! `HashMap<String, serde_json::Value>`, we serialize it once per call and
//! let Python `json.loads` rebuild it as native dicts/lists/scalars. That
//! avoids writing per-type PyO3 converters and keeps the FFI surface tiny.

use std::collections::HashMap;
use std::sync::Mutex;

use ansible_utils::AnsibleValue;
use pyo3::prelude::*;
use pyo3::types::PyDict;

use crate::TemplateError;

/// Process-wide lock guarding the Python-side helper module. The GIL already
/// serializes bytecode execution, but we cache a compiled helper module in a
/// `OnceLock` and this mutex guards the one-time initialization against
/// double-compilation if two threads race on first use.
static INIT_LOCK: Mutex<()> = Mutex::new(());

/// Python helper: receives a template string and a JSON-encoded variables
/// map, returns the rendered string. Living in a Python module (rather than
/// being re-exec'd per call) lets CPython cache its bytecode.
const HELPER_SOURCE: &str = r#"
import json
import jinja2

_env = jinja2.Environment(
    undefined=jinja2.StrictUndefined,
    keep_trailing_newline=True,
    autoescape=False,
)

def render(template_str, vars_json):
    ctx = json.loads(vars_json) if vars_json else {}
    tmpl = _env.from_string(template_str)
    return tmpl.render(**ctx)
"#;

/// Render `template` with the given `variables` using Python's Jinja2.
///
/// Returns `TemplateError::RenderError` wrapping either the import failure
/// (jinja2 not installed) or the Jinja2 exception message.
pub fn render(
    template: &str,
    variables: &HashMap<String, AnsibleValue>,
) -> Result<String, TemplateError> {
    let vars_json = serde_json::to_string(variables)
        .map_err(|e| TemplateError::RenderError(format!("variables serialize: {e}")))?;

    let _guard = INIT_LOCK.lock().unwrap_or_else(|p| p.into_inner());
    Python::with_gil(|py| -> Result<String, TemplateError> {
        let helper = load_helper(py)?;
        let rendered = helper
            .call_method1("render", (template, vars_json))
            .map_err(|e| TemplateError::RenderError(format!("jinja2: {}", e)))?;
        rendered
            .extract::<String>()
            .map_err(|e| TemplateError::RenderError(format!("render result: {e}")))
    })
}

/// Evaluate a boolean expression using Python's Jinja2. Used for `when:`
/// conditions that MiniJinja rejects.
pub fn evaluate_conditional(
    expr: &str,
    variables: &HashMap<String, AnsibleValue>,
) -> Result<bool, TemplateError> {
    // Strip {{ }} if present and wrap in an if/else so the result is an
    // unambiguous "True"/"False" string regardless of the expression's type.
    let inner = expr.replace("{{", "").replace("}}", "");
    let template = format!("{{% if {} %}}True{{% else %}}False{{% endif %}}", inner.trim());
    let rendered = render(&template, variables)?;
    Ok(rendered.trim() == "True")
}

/// Compile the helper module once per interpreter and stash it on
/// `sys.modules` under a private name so subsequent calls can look it up
/// directly without re-parsing HELPER_SOURCE.
fn load_helper(py: Python<'_>) -> Result<Bound<'_, PyAny>, TemplateError> {
    const MODULE_NAME: &str = "_ansible_core_rs_jinja2_helper";
    let sys = py
        .import("sys")
        .map_err(|e| TemplateError::RenderError(format!("import sys: {e}")))?;
    let modules = sys
        .getattr("modules")
        .map_err(|e| TemplateError::RenderError(format!("sys.modules: {e}")))?;

    if let Ok(existing) = modules.get_item(MODULE_NAME) {
        if !existing.is_none() {
            return Ok(existing);
        }
    }

    let module_type = py
        .import("types")
        .and_then(|m| m.getattr("ModuleType"))
        .map_err(|e| TemplateError::RenderError(format!("types.ModuleType: {e}")))?;
    let module = module_type
        .call1((MODULE_NAME,))
        .map_err(|e| TemplateError::RenderError(format!("new module: {e}")))?;
    let module_dict: Bound<'_, PyDict> = module
        .getattr("__dict__")
        .and_then(|d| d.downcast_into::<PyDict>().map_err(Into::into))
        .map_err(|e| TemplateError::RenderError(format!("module __dict__: {e}")))?;
    py.run(
        &std::ffi::CString::new(HELPER_SOURCE).unwrap(),
        Some(&module_dict),
        Some(&module_dict),
    )
    .map_err(|e| TemplateError::RenderError(format!("jinja2 helper init: {e}")))?;

    modules
        .set_item(MODULE_NAME, &module)
        .map_err(|e| TemplateError::RenderError(format!("cache helper: {e}")))?;
    Ok(module)
}

#[cfg(test)]
mod tests {
    use super::*;

    fn has_jinja2() -> bool {
        Python::with_gil(|py| py.import("jinja2").is_ok())
    }

    #[test]
    fn test_render_simple() {
        if !has_jinja2() {
            eprintln!("skipping: jinja2 not installed in embedded Python");
            return;
        }
        let mut vars = HashMap::new();
        vars.insert("name".to_string(), serde_json::json!("world"));
        let out = render("Hello {{ name }}!", &vars).unwrap();
        assert_eq!(out, "Hello world!");
    }

    #[test]
    fn test_render_with_filter() {
        if !has_jinja2() {
            return;
        }
        let mut vars = HashMap::new();
        vars.insert("xs".to_string(), serde_json::json!([1, 2, 3]));
        let out = render("{{ xs | length }}", &vars).unwrap();
        assert_eq!(out, "3");
    }

    #[test]
    fn test_conditional() {
        if !has_jinja2() {
            return;
        }
        let mut vars = HashMap::new();
        vars.insert("enabled".to_string(), serde_json::json!(true));
        vars.insert("count".to_string(), serde_json::json!(42));
        assert!(evaluate_conditional("enabled and count > 10", &vars).unwrap());
        assert!(!evaluate_conditional("enabled and count < 10", &vars).unwrap());
    }

    #[test]
    fn test_undefined_raises() {
        if !has_jinja2() {
            return;
        }
        let vars = HashMap::new();
        let err = render("{{ missing }}", &vars).unwrap_err();
        assert!(matches!(err, TemplateError::RenderError(_)));
    }

    #[test]
    fn test_helper_is_cached() {
        if !has_jinja2() {
            return;
        }
        // Two calls in succession should both succeed, exercising the
        // sys.modules cache path on the second call.
        let vars = HashMap::new();
        let a = render("hi", &vars).unwrap();
        let b = render("hi", &vars).unwrap();
        assert_eq!(a, "hi");
        assert_eq!(b, "hi");
    }
}
