use std::env;
use std::fs;
use std::path::Path;

fn main() {
    // Read minijinja version from Cargo.lock
    let manifest_dir = env::var("CARGO_MANIFEST_DIR").unwrap();
    let workspace_root = Path::new(&manifest_dir).parent().unwrap().parent().unwrap();
    let lock_path = workspace_root.join("Cargo.lock");

    if let Ok(content) = fs::read_to_string(&lock_path) {
        // Parse the version from Cargo.lock
        // In Cargo.lock v3 format, entries look like:
        //   [[package]]
        //   name = "minijinja"
        //   version = "2.18.0"
        let mut found_name = false;
        for line in content.lines() {
            let trimmed = line.trim();
            if trimmed == "name = \"minijinja\"" {
                found_name = true;
                continue;
            }
            if found_name && trimmed.starts_with("version =") {
                let version = trimmed
                    .trim_start_matches("version =")
                    .trim()
                    .trim_matches('"');
                if !version.is_empty() {
                    println!("cargo:rustc-env=MINIJINJA_VERSION={version}");
                    return;
                }
            }
            // If we hit another key before version, reset
            if found_name && (trimmed.starts_with("name =") || trimmed.starts_with("source =")) {
                found_name = false;
            }
        }
    }

    // Fallback if not found
    println!("cargo:rustc-env=MINIJINJA_VERSION=2.x");

    println!("cargo:rerun-if-changed=../../Cargo.lock");
}
