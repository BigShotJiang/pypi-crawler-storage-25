# Benchmark Fixtures

Layered corpus of Ansible artifacts for benchmarking the `ansible-core-rs`
parser and engine at various scales.

## Playbooks

| File | Plays | Tasks | Exercises |
|---|---|---|---|
| `small_playbook.yml` | 1 | 10 | Basic modules: `debug`, `command`, `set_fact`, simple `when`, short `loop` |
| `medium_playbook.yml` | 3 | 11 | Multi-play structure, vars, loops over lists, conditionals |
| `large_playbook.yml` | 5 | ~86 | Role-like plays (system setup, deploy, security, monitoring, verification); loops, conditionals, `set_fact`, `register`, `failed_when` |

## Inventories

| File | Hosts | Groups | Exercises |
|---|---|---|---|
| `small_inventory.ini` | 10 | 2 | Minimal INI parsing |
| `medium_inventory.ini` | 100 | 6 + 3 meta-groups | Group vars, `children` groups, multi-datacenter hierarchy |
| `large_inventory.ini` | 32 | 6 + 1 meta-group | Original fixture; moderate INI with `children` and group vars |

## Templates (`templates/`)

| File | Lines | Exercises |
|---|---|---|
| `simple.j2` | ~8 | Variable substitution, `default` filter |
| `medium.j2` | ~55 | Filters (`upper`, `regex_replace`, `int`, `ternary`), `if`/`else`, `for` loops, nested conditionals |
| `complex.j2` | ~120 | Jinja macros, nested loops, complex filter chains, conditional blocks, macro parameters with defaults |

## Vault (`vault/`)

| File | Entries | Exercises |
|---|---|---|
| `small_secret.yml` | 5 | Small vault-compatible YAML; placeholder values |
| `bulk_secrets.yml` | 20 | Larger vault file; multi-line values, mixed scalar and block types |

> **Note:** Vault files contain **placeholder** secrets only. To benchmark
> actual vault decryption, encrypt them with `ansible-vault encrypt <file>`
> using a test password.

## Intended Benchmark Scenarios

- **Playbook parsing**: Compare parse times across small/medium/large playbooks
  to verify linear (or better) scaling.
- **Inventory loading**: Measure host/group resolution at 10, 32, and 100 host
  scales.
- **Template rendering**: Benchmark Jinja2-compatible template compilation and
  rendering from simple substitution to complex macro expansion.
- **Vault decryption**: Measure decrypt overhead for small vs. bulk secret
  files (requires encrypting the fixture files first).
