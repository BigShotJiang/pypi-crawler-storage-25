//! Performance benchmarks for the ansible-core-rs execution pipeline.
//!
//! Run with: cargo bench -p ansible-core
//!
//! These benchmarks cover:
//! - Playbook YAML parsing and loading
//! - Template rendering (simple and complex)
//! - Inventory parsing and host resolution
//! - Full binary startup time (cold-start overhead)

use std::collections::HashMap;
use std::path::PathBuf;
use std::process::Command;

use criterion::{black_box, criterion_group, criterion_main, Criterion};

fn bench_fixtures_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("benches/fixtures")
}

fn test_fixtures_dir() -> PathBuf {
    PathBuf::from(env!("CARGO_MANIFEST_DIR")).join("tests/fixtures")
}

fn ansible_bin() -> PathBuf {
    let mut path = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
        .join("../../target/release/ansible");
    if !path.exists() {
        path = PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .join("../../target/debug/ansible");
    }
    path
}

// ── Playbook parsing ────────────────────────────────────────────

fn bench_playbook_parse_simple(c: &mut Criterion) {
    let path = test_fixtures_dir().join("simple_ping.yml");
    c.bench_function("playbook_parse_simple", |b| {
        b.iter(|| {
            let pb = ansible_playbook::load_playbook(black_box(&path)).unwrap();
            black_box(pb);
        })
    });
}

fn bench_playbook_parse_medium(c: &mut Criterion) {
    let path = bench_fixtures_dir().join("medium_playbook.yml");
    c.bench_function("playbook_parse_medium", |b| {
        b.iter(|| {
            let pb = ansible_playbook::load_playbook(black_box(&path)).unwrap();
            black_box(pb);
        })
    });
}

// ── Template rendering ──────────────────────────────────────────

fn bench_template_simple(c: &mut Criterion) {
    let mut templar = ansible_template::Templar::new();
    let mut vars = HashMap::new();
    vars.insert("name".to_string(), serde_json::json!("world"));
    templar.set_variables(vars);

    c.bench_function("template_simple_string", |b| {
        b.iter(|| {
            let result = templar
                .template_string(black_box("Hello {{ name }}!"))
                .unwrap();
            black_box(result);
        })
    });
}

fn bench_template_with_filters(c: &mut Criterion) {
    let mut templar = ansible_template::Templar::new();
    let mut vars = HashMap::new();
    vars.insert("items".to_string(), serde_json::json!(["a", "b", "c"]));
    vars.insert("name".to_string(), serde_json::json!("hello world"));
    templar.set_variables(vars);

    c.bench_function("template_with_filters", |b| {
        b.iter(|| {
            let result = templar
                .template_string(black_box(
                    "{{ name | upper }} has {{ items | length }} items",
                ))
                .unwrap();
            black_box(result);
        })
    });
}

fn bench_template_conditional(c: &mut Criterion) {
    let mut templar = ansible_template::Templar::new();
    let mut vars = HashMap::new();
    vars.insert("enabled".to_string(), serde_json::json!(true));
    vars.insert("count".to_string(), serde_json::json!(42));
    templar.set_variables(vars);

    c.bench_function("template_conditional_eval", |b| {
        b.iter(|| {
            let result = templar
                .evaluate_conditional(black_box("enabled and count > 10"))
                .unwrap();
            black_box(result);
        })
    });
}

fn bench_template_complex(c: &mut Criterion) {
    let mut templar = ansible_template::Templar::new();
    let mut vars = HashMap::new();
    vars.insert("app_name".to_string(), serde_json::json!("myapp"));
    vars.insert("version".to_string(), serde_json::json!("2.1.0"));
    vars.insert("port".to_string(), serde_json::json!(8080));
    vars.insert(
        "hosts".to_string(),
        serde_json::json!(["web1", "web2", "web3"]),
    );
    vars.insert(
        "config".to_string(),
        serde_json::json!({
            "debug": false,
            "log_level": "info",
            "workers": 4
        }),
    );
    templar.set_variables(vars);

    c.bench_function("template_complex_nested", |b| {
        b.iter(|| {
            let result = templar
                .template_string(black_box(
                    "{{ app_name }}-{{ version }} on port {{ port }} with {{ hosts | length }} hosts, debug={{ config.debug | string }}",
                ))
                .unwrap();
            black_box(result);
        })
    });
}

// ── Inventory parsing ───────────────────────────────────────────

fn bench_inventory_parse(c: &mut Criterion) {
    let path = bench_fixtures_dir().join("large_inventory.ini");
    c.bench_function("inventory_parse_32hosts", |b| {
        b.iter(|| {
            let mut mgr = ansible_inventory::InventoryManager::new();
            mgr.add_source(black_box(path.clone()));
            mgr.parse_sources().unwrap();
            black_box(&mgr);
        })
    });
}

fn bench_inventory_resolve_pattern(c: &mut Criterion) {
    let path = bench_fixtures_dir().join("large_inventory.ini");
    let mut mgr = ansible_inventory::InventoryManager::new();
    mgr.add_source(path);
    mgr.parse_sources().unwrap();
    let data = mgr.data();

    c.bench_function("inventory_resolve_all", |b| {
        b.iter(|| {
            let hosts =
                ansible_inventory::resolve_pattern(black_box("all"), black_box(data));
            black_box(hosts);
        })
    });

    c.bench_function("inventory_resolve_group", |b| {
        b.iter(|| {
            let hosts = ansible_inventory::resolve_pattern(
                black_box("webservers"),
                black_box(data),
            );
            black_box(hosts);
        })
    });
}

// ── Binary startup time ─────────────────────────────────────────

fn bench_binary_startup(c: &mut Criterion) {
    let bin = ansible_bin();
    if !bin.exists() {
        eprintln!("Skipping binary startup bench: binary not found at {}", bin.display());
        return;
    }

    c.bench_function("binary_help_startup", |b| {
        b.iter(|| {
            let output = Command::new(&bin)
                .arg("--help")
                .env("ANSIBLE_NOCOLOR", "1")
                .output()
                .unwrap();
            black_box(output);
        })
    });
}

fn bench_binary_playbook_run(c: &mut Criterion) {
    let bin = ansible_bin();
    let playbook = test_fixtures_dir().join("simple_ping.yml");
    if !bin.exists() {
        eprintln!("Skipping playbook run bench: binary not found");
        return;
    }

    c.bench_function("binary_simple_playbook", |b| {
        b.iter(|| {
            let output = Command::new(&bin)
                .arg("playbook")
                .arg(&playbook)
                .env("ANSIBLE_NOCOLOR", "1")
                .output()
                .unwrap();
            black_box(output);
        })
    });
}

// ── Groups ──────────────────────────────────────────────────────

criterion_group!(
    parsing,
    bench_playbook_parse_simple,
    bench_playbook_parse_medium,
);

criterion_group!(
    templating,
    bench_template_simple,
    bench_template_with_filters,
    bench_template_conditional,
    bench_template_complex,
);

criterion_group!(
    inventory,
    bench_inventory_parse,
    bench_inventory_resolve_pattern,
);

criterion_group!(
    binary,
    bench_binary_startup,
    bench_binary_playbook_run,
);

criterion_main!(parsing, templating, inventory, binary);
