use std::path::PathBuf;
use std::process::ExitCode;

use anyhow::Result;
use clap::{Parser, Subcommand};

mod cli;

#[derive(Parser)]
#[command(
    name = "ansible",
    about = "ansible-core-rs — Rust implementation of Ansible"
)]
struct Cli {
    /// Show version information
    #[arg(short = 'V', long)]
    version: bool,

    #[command(subcommand)]
    command: Option<Commands>,

    /// Host pattern (ad-hoc mode)
    #[arg()]
    pattern: Option<String>,

    /// Module to execute (ad-hoc mode)
    #[arg(short, long, default_value = "command")]
    module_name: String,

    /// Module arguments (ad-hoc mode)
    #[arg(short, long)]
    args: Option<String>,

    /// Inventory file or host list
    #[arg(short, long)]
    inventory: Option<String>,

    /// Run in check mode (dry run)
    #[arg(long)]
    check: bool,

    /// Show diffs for changed files
    #[arg(long)]
    diff: bool,

    /// Verbose mode (-v, -vv, -vvv, -vvvv)
    #[arg(short, long, action = clap::ArgAction::Count)]
    verbose: u8,

    /// Number of parallel processes
    #[arg(short, long)]
    forks: Option<usize>,

    /// Connect as this user
    #[arg(short = 'u', long)]
    remote_user: Option<String>,

    /// Run operations with become
    #[arg(short = 'b', long = "become")]
    use_become: bool,

    /// Privilege escalation method
    #[arg(long, default_value = "sudo")]
    become_method: String,

    /// Privilege escalation user
    #[arg(long, default_value = "root")]
    become_user: String,

    /// Extra variables (key=value or @file.yml)
    #[arg(short = 'e', long)]
    extra_vars: Vec<String>,

    /// Vault password file
    #[arg(long)]
    vault_password_file: Option<PathBuf>,
}

#[derive(Subcommand)]
enum Commands {
    /// Run a playbook
    Playbook {
        /// Playbook file(s)
        playbooks: Vec<PathBuf>,

        /// Limit to specific hosts
        #[arg(short, long)]
        limit: Option<String>,

        /// Only run plays and tasks tagged with these values
        #[arg(short, long)]
        tags: Option<String>,

        /// Skip plays and tasks tagged with these values
        #[arg(long)]
        skip_tags: Option<String>,

        /// Start at the task matching this name
        #[arg(long)]
        start_at_task: Option<String>,

        /// Accepted for CLI parity with Python ansible-playbook. Dry-run
        /// semantics are not yet honored — tasks still execute normally.
        #[arg(short = 'C', long)]
        check: bool,

        /// Accepted for CLI parity with Python ansible-playbook. The Rust
        /// runtime currently resolves connections from inventory only; the
        /// value is not applied.
        #[arg(short = 'c', long)]
        connection: Option<String>,
    },

    /// Manage vault encrypted files
    Vault {
        #[command(subcommand)]
        action: VaultAction,
    },

    /// View/dump Ansible configuration
    Config {
        #[command(subcommand)]
        action: ConfigAction,
    },

    /// Show inventory information
    Inventory {
        /// Inventory source
        #[arg(short, long)]
        inventory: Option<String>,

        /// Output all hosts info as JSON
        #[arg(long)]
        list: bool,

        /// Show info about a specific host
        #[arg(long)]
        host: Option<String>,

        /// Output as YAML
        #[arg(short, long)]
        yaml: bool,

        /// Output as TOML
        #[arg(long)]
        toml: bool,

        /// Show the graph of inventory
        #[arg(long)]
        graph: bool,
    },

    /// Manage Galaxy collections and roles
    Galaxy {
        #[command(subcommand)]
        action: GalaxyAction,
    },

    /// Show documentation for modules/plugins
    Doc {
        /// Plugin name
        plugin: Option<String>,

        /// Plugin type
        #[arg(short = 't', long, default_value = "module")]
        plugin_type: String,

        /// List available plugins
        #[arg(short, long)]
        list: bool,

        /// Show snippet
        #[arg(short, long)]
        snippet: bool,
    },

    /// Interactive Ansible console (not yet implemented)
    Console,

    /// Pull ansible playbooks from VCS (not yet implemented)
    Pull {
        /// URL of the playbook repository
        url: Option<String>,
    },
}

#[derive(Subcommand)]
enum VaultAction {
    /// Encrypt a file
    Encrypt {
        files: Vec<PathBuf>,
        #[arg(long)]
        vault_id: Option<String>,
    },
    /// Decrypt a file
    Decrypt { files: Vec<PathBuf> },
    /// View an encrypted file
    View { file: PathBuf },
    /// Edit an encrypted file
    Edit { file: PathBuf },
    /// Re-key vault encrypted files
    Rekey { files: Vec<PathBuf> },
    /// Encrypt a string
    EncryptString {
        /// The string to encrypt
        string: Option<String>,
        /// Variable name
        #[arg(short, long)]
        name: Option<String>,
    },
}

#[derive(Subcommand)]
enum ConfigAction {
    /// List all configuration options
    List,
    /// Dump current configuration
    Dump {
        /// Only show changed values
        #[arg(long)]
        only_changed: bool,
    },
    /// View a config file
    View { config_file: Option<PathBuf> },
}

#[derive(Subcommand)]
enum GalaxyAction {
    /// Install collections
    #[command(name = "collection")]
    Collection {
        #[command(subcommand)]
        action: GalaxyCollectionAction,
    },
}

#[derive(Subcommand)]
enum GalaxyCollectionAction {
    /// Install one or more collections
    Install {
        /// Collection(s) to install (namespace.name or namespace.name:version)
        collections: Vec<String>,

        /// Install from a requirements file
        #[arg(short, long)]
        requirements: Option<PathBuf>,

        /// Path to install collections into
        #[arg(short, long)]
        collections_path: Option<PathBuf>,

        /// Force reinstall even if already installed
        #[arg(short, long)]
        force: bool,

        /// Galaxy server URL
        #[arg(short, long)]
        server: Option<String>,
    },
    /// Build a collection tarball from a source directory
    Build {
        /// Path to the collection source (containing galaxy.yml)
        #[arg(default_value = ".")]
        path: PathBuf,

        /// Output directory for the tarball
        #[arg(long, default_value = ".")]
        output_path: PathBuf,
    },
    /// List installed collections
    List {
        /// Path to search for collections
        #[arg(short, long)]
        collections_path: Option<PathBuf>,

        /// Output as JSON
        #[arg(long)]
        format_json: bool,
    },
}

fn main() -> ExitCode {
    // Initialize tracing
    tracing_subscriber::fmt()
        .with_env_filter(
            tracing_subscriber::EnvFilter::from_default_env(),
        )
        .init();

    // Dispatch based on argv[0] basename — allows the binary to serve as
    // ansible, ansible-playbook, ansible-vault, etc. via symlinks.
    let args: Vec<String> = std::env::args().collect();
    let prog_name = std::path::Path::new(&args[0])
        .file_stem()
        .and_then(|s| s.to_str())
        .unwrap_or("ansible")
        .to_string();

    match prog_name.as_str() {
        "ansible-playbook" => {
            // Inject "playbook" as the subcommand
            let mut modified_args = vec![args[0].clone(), "playbook".to_string()];
            modified_args.extend_from_slice(&args[1..]);
            let cli = Cli::parse_from(&modified_args);
            return match run(cli) {
                Ok(code) => ExitCode::from(code),
                Err(e) => {
                    eprintln!("ERROR! {e}");
                    ExitCode::FAILURE
                }
            };
        }
        "ansible-vault" => {
            let mut modified_args = vec![args[0].clone(), "vault".to_string()];
            modified_args.extend_from_slice(&args[1..]);
            let cli = Cli::parse_from(&modified_args);
            return match run(cli) {
                Ok(code) => ExitCode::from(code),
                Err(e) => {
                    eprintln!("ERROR! {e}");
                    ExitCode::FAILURE
                }
            };
        }
        "ansible-galaxy" => {
            let mut modified_args = vec![args[0].clone(), "galaxy".to_string()];
            modified_args.extend_from_slice(&args[1..]);
            let cli = Cli::parse_from(&modified_args);
            return match run(cli) {
                Ok(code) => ExitCode::from(code),
                Err(e) => {
                    eprintln!("ERROR! {e}");
                    ExitCode::FAILURE
                }
            };
        }
        "ansible-inventory" => {
            let mut modified_args = vec![args[0].clone(), "inventory".to_string()];
            modified_args.extend_from_slice(&args[1..]);
            let cli = Cli::parse_from(&modified_args);
            return match run(cli) {
                Ok(code) => ExitCode::from(code),
                Err(e) => {
                    eprintln!("ERROR! {e}");
                    ExitCode::FAILURE
                }
            };
        }
        "ansible-config" => {
            let mut modified_args = vec![args[0].clone(), "config".to_string()];
            modified_args.extend_from_slice(&args[1..]);
            let cli = Cli::parse_from(&modified_args);
            return match run(cli) {
                Ok(code) => ExitCode::from(code),
                Err(e) => {
                    eprintln!("ERROR! {e}");
                    ExitCode::FAILURE
                }
            };
        }
        "ansible-doc" => {
            let mut modified_args = vec![args[0].clone(), "doc".to_string()];
            modified_args.extend_from_slice(&args[1..]);
            let cli = Cli::parse_from(&modified_args);
            return match run(cli) {
                Ok(code) => ExitCode::from(code),
                Err(e) => {
                    eprintln!("ERROR! {e}");
                    ExitCode::FAILURE
                }
            };
        }
        "ansible-console" => {
            let mut modified_args = vec![args[0].clone(), "console".to_string()];
            modified_args.extend_from_slice(&args[1..]);
            let cli = Cli::parse_from(&modified_args);
            return match run(cli) {
                Ok(code) => ExitCode::from(code),
                Err(e) => {
                    eprintln!("ERROR! {e}");
                    ExitCode::FAILURE
                }
            };
        }
        "ansible-pull" => {
            let mut modified_args = vec![args[0].clone(), "pull".to_string()];
            modified_args.extend_from_slice(&args[1..]);
            let cli = Cli::parse_from(&modified_args);
            return match run(cli) {
                Ok(code) => ExitCode::from(code),
                Err(e) => {
                    eprintln!("ERROR! {e}");
                    ExitCode::FAILURE
                }
            };
        }
        _ => {} // "ansible" or unknown — use normal CLI parsing
    }

    let cli = Cli::parse();

    match run(cli) {
        Ok(code) => ExitCode::from(code),
        Err(e) => {
            eprintln!("ERROR! {e}");
            ExitCode::FAILURE
        }
    }
}

/// Parse extra vars from -e arguments.
/// Supports key=value format and @file.yml references.
fn parse_extra_vars(
    extra_vars: &[String],
) -> Vec<(String, ansible_utils::AnsibleValue)> {
    let mut result = Vec::new();

    for ev in extra_vars {
        if let Some(file_path) = ev.strip_prefix('@') {
            // Load from file
            if let Ok(content) = std::fs::read_to_string(file_path) {
                if let Ok(val) =
                    serde_yaml::from_str::<std::collections::HashMap<String, serde_json::Value>>(
                        &content,
                    )
                {
                    for (k, v) in val {
                        result.push((k, v));
                    }
                }
            }
        } else if let Some((key, value)) = ev.split_once('=') {
            result.push((
                key.to_string(),
                ansible_utils::AnsibleValue::String(value.to_string()),
            ));
        } else {
            // Try parsing as YAML/JSON
            if let Ok(val) =
                serde_json::from_str::<std::collections::HashMap<String, serde_json::Value>>(ev)
            {
                for (k, v) in val {
                    result.push((k, v));
                }
            }
        }
    }

    result
}

/// Print detailed version information, similar to `ansible --version`.
fn print_version(config: &ansible_config::AnsibleConfig) {
    let pkg_version = env!("CARGO_PKG_VERSION");
    println!("ansible-core-rs [{pkg_version}]");

    let config_file = find_config_file_display();
    println!("  config file = {config_file}");

    let home = std::env::var("HOME").unwrap_or_else(|_| "~".to_string());
    let module_paths = format!(
        "['{home}/.ansible/plugins/modules', '/usr/share/ansible/plugins/modules']"
    );
    println!("  configured module search path = {module_paths}");

    let collections_paths = if config.defaults.collections_paths.is_empty() {
        format!("{home}/.ansible/collections:/usr/share/ansible/collections")
    } else {
        config
            .defaults
            .collections_paths
            .iter()
            .map(|p| p.display().to_string().replace('~', &home))
            .collect::<Vec<_>>()
            .join(":")
    };
    println!("  ansible collection location = {collections_paths}");

    let exe = std::env::current_exe()
        .map(|p| p.display().to_string())
        .unwrap_or_else(|_| "unknown".to_string());
    println!("  executable location = {exe}");

    // Report rustc version (best effort — use rustc if available)
    let rust_version = std::process::Command::new("rustc")
        .arg("--version")
        .output()
        .ok()
        .and_then(|o| String::from_utf8(o.stdout).ok())
        .map(|s| s.trim().to_string())
        .unwrap_or_else(|| format!("{} (MSRV)", env!("CARGO_PKG_RUST_VERSION")));
    println!("  {rust_version}");
    println!("  jinja version = minijinja {}", env!("MINIJINJA_VERSION"));
}

/// Find the config file path for display in --version output.
fn find_config_file_display() -> String {
    if let Ok(path) = std::env::var("ANSIBLE_CONFIG") {
        let p = std::path::PathBuf::from(&path);
        if p.exists() {
            return p.display().to_string();
        }
    }
    if std::path::Path::new("ansible.cfg").exists() {
        return "ansible.cfg".to_string();
    }
    if let Ok(home) = std::env::var("HOME") {
        let home_cfg = std::path::PathBuf::from(home).join(".ansible.cfg");
        if home_cfg.exists() {
            return home_cfg.display().to_string();
        }
    }
    if std::path::Path::new("/etc/ansible/ansible.cfg").exists() {
        return "/etc/ansible/ansible.cfg".to_string();
    }
    "None".to_string()
}

fn run(cli: Cli) -> Result<u8> {
    // Load configuration
    let config = ansible_config::loader::load_config()?;

    // Handle --version before anything else
    if cli.version {
        print_version(&config);
        return Ok(0);
    }

    let vault_pw_file = cli.vault_password_file.clone();
    let module_name = cli.module_name.clone();
    let args = cli.args.clone();

    let forks = cli.forks.unwrap_or(5);
    let inventory_source = cli.inventory.as_deref();
    let extra_vars_parsed = parse_extra_vars(&cli.extra_vars);

    match cli.command {
        Some(Commands::Playbook {
            playbooks,
            limit,
            tags,
            skip_tags,
            start_at_task,
            check,
            connection,
        }) => {
            if check {
                tracing::warn!("--check accepted but dry-run semantics are not yet implemented; tasks will execute normally");
            }
            if connection.is_some() {
                tracing::debug!("--connection accepted but currently ignored; inventory connection vars are authoritative");
            }
            cli::playbook::run_playbook(
                &config,
                &playbooks,
                inventory_source,
                forks,
                &extra_vars_parsed,
                tags.as_deref(),
                skip_tags.as_deref(),
                start_at_task.as_deref(),
                limit.as_deref(),
            )
        }
        Some(Commands::Vault { action }) => {
            cli::vault::run_vault(&config, action, vault_pw_file.as_ref())
        }
        Some(Commands::Config { action }) => {
            cli::config::run_config(&config, action)
        }
        Some(Commands::Inventory { inventory, list, host, graph, .. }) => {
            cli::inventory::run_inventory(&config, inventory, list, host, graph)
        }
        Some(Commands::Galaxy { action }) => {
            cli::galaxy::run_galaxy(action)
        }
        Some(Commands::Doc { .. }) => {
            println!("ansible-doc: not yet implemented");
            Ok(0)
        }
        Some(Commands::Console) => {
            println!("ansible-console: not yet implemented");
            Ok(0)
        }
        Some(Commands::Pull { .. }) => {
            println!("ansible-pull: not yet implemented");
            Ok(0)
        }
        None => {
            // Ad-hoc mode: ansible <pattern> -m <module> -a <args>
            match cli.pattern {
                Some(pattern) => cli::adhoc::run_adhoc(
                    &config,
                    &pattern,
                    &module_name,
                    args.as_deref(),
                    inventory_source,
                    forks,
                    &extra_vars_parsed,
                    cli.use_become,
                    &cli.become_method,
                    &cli.become_user,
                ),
                None => {
                    use clap::CommandFactory;
                    Cli::command().print_help()?;
                    Ok(0)
                }
            }
        }
    }
}
