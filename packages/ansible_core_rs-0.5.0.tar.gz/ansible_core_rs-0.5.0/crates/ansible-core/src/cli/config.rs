use std::env;

use anyhow::Result;

use crate::ConfigAction;

/// Environment variable overrides keyed by config setting name.
const ENV_OVERRIDES: &[(&str, &str)] = &[
    ("DEFAULTS.REMOTE_USER", "ANSIBLE_REMOTE_USER"),
    ("DEFAULTS.FORKS", "ANSIBLE_FORKS"),
    ("DEFAULTS.HOST_KEY_CHECKING", "ANSIBLE_HOST_KEY_CHECKING"),
    ("DEFAULTS.TIMEOUT", "ANSIBLE_TIMEOUT"),
    ("DEFAULTS.INVENTORY", "ANSIBLE_INVENTORY"),
    ("DEFAULTS.ROLES_PATH", "ANSIBLE_ROLES_PATH"),
    ("DEFAULTS.VAULT_PASSWORD_FILE", "ANSIBLE_VAULT_PASSWORD_FILE"),
    ("DEFAULTS.STDOUT_CALLBACK", "ANSIBLE_STDOUT_CALLBACK"),
    ("DEFAULTS.NOCOWS", "ANSIBLE_NOCOWS"),
    ("DEFAULTS.PIPELINING", "ANSIBLE_PIPELINING"),
    ("PRIVILEGE_ESCALATION.USE_BECOME", "ANSIBLE_BECOME"),
    ("PRIVILEGE_ESCALATION.BECOME_METHOD", "ANSIBLE_BECOME_METHOD"),
    ("PRIVILEGE_ESCALATION.BECOME_USER", "ANSIBLE_BECOME_USER"),
    ("SSH_CONNECTION.SSH_ARGS", "ANSIBLE_SSH_ARGS"),
    ("SSH_CONNECTION.RETRIES", "ANSIBLE_SSH_RETRIES"),
];

/// Determine the source of a config value: "env", "file", or "default".
fn determine_source(config_key: &str) -> &'static str {
    // Check if an env var override exists for this key
    let env_var = ENV_OVERRIDES
        .iter()
        .find(|(k, _)| k == &config_key)
        .map(|(_, v)| *v);

    if let Some(var) = env_var {
        if env::var(var).is_ok() {
            return "env";
        }
    }
    "default"
}

/// Format a path list for display.
fn format_paths(paths: &[std::path::PathBuf]) -> String {
    let home = env::var("HOME").unwrap_or_default();
    let formatted: Vec<String> = paths
        .iter()
        .map(|p| {
            let s = p.display().to_string();
            s.replace('~', &home)
        })
        .collect();
    format!("[{}]", formatted.join(", "))
}

/// Format an optional path for display.
fn format_optional_path(path: &Option<std::path::PathBuf>) -> String {
    match path {
        Some(p) => {
            let home = env::var("HOME").unwrap_or_default();
            p.display().to_string().replace('~', &home)
        }
        None => "None".to_string(),
    }
}

/// Run config inspection commands.
pub fn run_config(
    config: &ansible_config::AnsibleConfig,
    action: ConfigAction,
) -> Result<u8> {
    match action {
        ConfigAction::List => {
            println!("Configuration options:");
            println!("  defaults.inventory = {}", config.defaults.inventory);
            println!("  defaults.remote_user = {}", config.defaults.remote_user);
            println!("  defaults.forks = {}", config.defaults.forks);
            println!("  defaults.transport = {}", config.defaults.transport);
            println!(
                "  defaults.host_key_checking = {}",
                config.defaults.host_key_checking
            );
            println!("  defaults.timeout = {}", config.defaults.timeout);
            println!(
                "  defaults.stdout_callback = {}",
                config.defaults.stdout_callback
            );
            println!(
                "  privilege_escalation.use_become = {}",
                config.privilege_escalation.use_become
            );
            println!(
                "  privilege_escalation.become_method = {}",
                config.privilege_escalation.become_method
            );
            println!(
                "  privilege_escalation.become_user = {}",
                config.privilege_escalation.become_user
            );
        }
        ConfigAction::Dump { only_changed } => {
            dump_config(config, only_changed);
        }
        ConfigAction::View { config_file } => {
            let path = config_file.unwrap_or_else(|| {
                config
                    .config_file
                    .clone()
                    .unwrap_or_else(|| std::path::PathBuf::from("/etc/ansible/ansible.cfg"))
            });
            match std::fs::read_to_string(&path) {
                Ok(content) => print!("{content}"),
                Err(e) => eprintln!("Could not read {}: {e}", path.display()),
            }
        }
    }

    Ok(0)
}

/// Dump all configuration values, each with its source.
fn dump_config(config: &ansible_config::AnsibleConfig, only_changed: bool) {
    // [defaults] section
    dump_entry(
        "DEFAULTS.INVENTORY",
        &config.defaults.inventory,
        "/etc/ansible/hosts",
        only_changed,
    );
    dump_entry(
        "DEFAULTS.REMOTE_USER",
        &config.defaults.remote_user,
        "root",
        only_changed,
    );
    dump_entry(
        "DEFAULTS.FORKS",
        &config.defaults.forks.to_string(),
        "5",
        only_changed,
    );
    dump_entry(
        "DEFAULTS.MODULE_NAME",
        &config.defaults.module_name,
        "command",
        only_changed,
    );
    dump_entry_bool(
        "DEFAULTS.ASK_VAULT_PASS",
        config.defaults.ask_vault_pass,
        false,
        only_changed,
    );
    dump_entry_bool(
        "DEFAULTS.ASK_PASS",
        config.defaults.ask_pass,
        false,
        only_changed,
    );
    dump_entry(
        "DEFAULTS.TRANSPORT",
        &config.defaults.transport,
        "ssh",
        only_changed,
    );
    dump_entry_paths(
        "DEFAULTS.ROLES_PATH",
        &config.defaults.roles_path,
        &[std::path::PathBuf::from("/etc/ansible/roles")],
        only_changed,
    );
    dump_entry(
        "DEFAULTS.VERBOSITY",
        &config.defaults.verbosity.to_string(),
        "0",
        only_changed,
    );
    dump_entry_bool(
        "DEFAULTS.NOCOWS",
        config.defaults.nocows,
        false,
        only_changed,
    );
    dump_entry_bool(
        "DEFAULTS.RETRY_FILES_ENABLED",
        config.defaults.retry_files_enabled,
        true,
        only_changed,
    );
    dump_entry_optional_path(
        "DEFAULTS.RETRY_FILES_SAVE_PATH",
        &config.defaults.retry_files_save_path,
        only_changed,
    );
    dump_entry_bool(
        "DEFAULTS.HOST_KEY_CHECKING",
        config.defaults.host_key_checking,
        true,
        only_changed,
    );
    dump_entry_optional_path(
        "DEFAULTS.VAULT_PASSWORD_FILE",
        &config.defaults.vault_password_file,
        only_changed,
    );
    dump_entry(
        "DEFAULTS.TIMEOUT",
        &config.defaults.timeout.to_string(),
        "10",
        only_changed,
    );
    dump_entry(
        "DEFAULTS.GATHERING",
        &format!("{:?}", config.defaults.gathering).to_lowercase(),
        "implicit",
        only_changed,
    );
    dump_entry(
        "DEFAULTS.STDOUT_CALLBACK",
        &config.defaults.stdout_callback,
        "default",
        only_changed,
    );
    dump_entry(
        "DEFAULTS.FACT_CACHING",
        &config.defaults.fact_caching,
        "memory",
        only_changed,
    );
    dump_entry(
        "DEFAULTS.FACT_CACHING_TIMEOUT",
        &config.defaults.fact_caching_timeout.to_string(),
        "86400",
        only_changed,
    );
    dump_entry_optional(
        "DEFAULTS.FACT_CACHING_CONNECTION",
        &config.defaults.fact_caching_connection,
        only_changed,
    );
    dump_entry_paths(
        "DEFAULTS.COLLECTIONS_PATHS",
        &config.defaults.collections_paths,
        &[
            std::path::PathBuf::from("~/.ansible/collections"),
            std::path::PathBuf::from("/usr/share/ansible/collections"),
        ],
        only_changed,
    );
    dump_entry_bool(
        "DEFAULTS.PIPELINING",
        config.defaults.pipelining,
        true,
        only_changed,
    );

    // [privilege_escalation] section
    dump_entry_bool(
        "PRIVILEGE_ESCALATION.USE_BECOME",
        config.privilege_escalation.use_become,
        false,
        only_changed,
    );
    dump_entry(
        "PRIVILEGE_ESCALATION.BECOME_METHOD",
        &config.privilege_escalation.become_method,
        "sudo",
        only_changed,
    );
    dump_entry(
        "PRIVILEGE_ESCALATION.BECOME_USER",
        &config.privilege_escalation.become_user,
        "root",
        only_changed,
    );
    dump_entry_bool(
        "PRIVILEGE_ESCALATION.BECOME_ASK_PASS",
        config.privilege_escalation.become_ask_pass,
        false,
        only_changed,
    );

    // [connection] section
    dump_entry_bool(
        "CONNECTION.PIPELINING",
        config.connection.pipelining,
        true,
        only_changed,
    );
    dump_entry(
        "CONNECTION.CONTROL_PATH_DIR",
        &config.connection.control_path_dir.display().to_string(),
        "~/.ansible/cp",
        only_changed,
    );

    // [ssh_connection] section
    dump_entry(
        "SSH_CONNECTION.SSH_ARGS",
        &config.ssh_connection.ssh_args,
        "-C -o ControlMaster=auto -o ControlPersist=60s",
        only_changed,
    );
    dump_entry_bool(
        "SSH_CONNECTION.SCP_IF_SSH",
        config.ssh_connection.scp_if_ssh,
        false,
        only_changed,
    );
    dump_entry_optional(
        "SSH_CONNECTION.CONTROL_PATH",
        &config.ssh_connection.control_path,
        only_changed,
    );
    dump_entry(
        "SSH_CONNECTION.RETRIES",
        &config.ssh_connection.retries.to_string(),
        "0",
        only_changed,
    );

    // [colors] section
    dump_entry_optional(
        "COLORS.HIGHLIGHT",
        &config.colors.highlight,
        only_changed,
    );
    dump_entry_optional(
        "COLORS.VERBOSE",
        &config.colors.verbose,
        only_changed,
    );
    dump_entry_optional("COLORS.WARN", &config.colors.warn, only_changed);
    dump_entry_optional("COLORS.ERROR", &config.colors.error, only_changed);
    dump_entry_optional("COLORS.DEBUG", &config.colors.debug, only_changed);
    dump_entry_optional("COLORS.OK", &config.colors.ok, only_changed);
    dump_entry_optional(
        "COLORS.CHANGED",
        &config.colors.changed,
        only_changed,
    );
    dump_entry_optional("COLORS.SKIP", &config.colors.skip, only_changed);
    dump_entry_optional(
        "COLORS.UNREACHABLE",
        &config.colors.unreachable,
        only_changed,
    );
}

fn dump_entry(key: &str, value: &str, default: &str, only_changed: bool) {
    if only_changed && value == default {
        return;
    }
    let source = determine_source(key);
    println!("{key}({source}) = {value}");
}

fn dump_entry_bool(key: &str, value: bool, default: bool, only_changed: bool) {
    dump_entry(key, &value.to_string(), &default.to_string(), only_changed);
}

fn dump_entry_optional(key: &str, value: &Option<String>, only_changed: bool) {
    if only_changed && value.is_none() {
        return;
    }
    let source = determine_source(key);
    let display = value.as_deref().unwrap_or("None");
    println!("{key}({source}) = {display}");
}

fn dump_entry_paths(
    key: &str,
    value: &[std::path::PathBuf],
    default: &[std::path::PathBuf],
    only_changed: bool,
) {
    let val_str = format_paths(value);
    let def_str = format_paths(default);
    if only_changed && val_str == def_str {
        return;
    }
    let source = determine_source(key);
    println!("{key}({source}) = {val_str}");
}

fn dump_entry_optional_path(
    key: &str,
    value: &Option<std::path::PathBuf>,
    only_changed: bool,
) {
    if only_changed && value.is_none() {
        return;
    }
    let source = determine_source(key);
    println!("{key}({source}) = {}", format_optional_path(value));
}
