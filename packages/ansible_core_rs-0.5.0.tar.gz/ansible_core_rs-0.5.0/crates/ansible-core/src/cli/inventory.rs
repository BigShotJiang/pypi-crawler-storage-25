use std::path::PathBuf;

use anyhow::Result;

/// Run inventory inspection commands.
pub fn run_inventory(
    config: &ansible_config::AnsibleConfig,
    inventory: Option<String>,
    _list: bool,
    host: Option<String>,
    graph: bool,
) -> Result<u8> {
    let inventory_source = inventory.unwrap_or_else(|| config.defaults.inventory.clone());

    let mut manager = ansible_inventory::InventoryManager::new();
    manager.add_source(PathBuf::from(&inventory_source));
    manager.parse_sources().map_err(|e| anyhow::anyhow!("inventory parse error: {e}"))?;

    if let Some(host_name) = host {
        // Show info about a specific host
        match manager.get_host(&host_name) {
            Some(_host) => {
                let vars = manager.get_host_vars(&host_name);
                let json = serde_json::to_string_pretty(&vars)?;
                println!("{json}");
            }
            None => {
                eprintln!("Host not found: {host_name}");
                return Ok(1);
            }
        }
    } else if graph {
        // Show inventory graph
        println!("@all:");
        for (name, group) in manager.groups() {
            if name.as_ref() == "all" {
                continue;
            }
            println!("  |--@{name}:");
            for host in &group.hosts {
                println!("  |  |--{host}");
            }
        }
    } else {
        // Default: list all as JSON
        let data = manager.data();
        let json = serde_json::to_string_pretty(data)?;
        println!("{json}");
    }

    Ok(0)
}
