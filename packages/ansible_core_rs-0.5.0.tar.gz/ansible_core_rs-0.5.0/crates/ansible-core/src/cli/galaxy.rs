use std::path::PathBuf;

use anyhow::Result;

use crate::{GalaxyAction, GalaxyCollectionAction};

/// Dispatch galaxy subcommands.
pub fn run_galaxy(action: GalaxyAction) -> Result<u8> {
    match action {
        GalaxyAction::Collection { action } => run_collection(action),
    }
}

fn run_collection(action: GalaxyCollectionAction) -> Result<u8> {
    match action {
        GalaxyCollectionAction::Install {
            collections,
            requirements,
            collections_path,
            force: _force,
            server: _server,
        } => run_collection_install(collections, requirements, collections_path),
        GalaxyCollectionAction::Build { path, output_path } => {
            run_collection_build(&path, &output_path)
        }
        GalaxyCollectionAction::List {
            collections_path,
            format_json,
        } => run_collection_list(collections_path, format_json),
    }
}

/// `ansible galaxy collection install`
fn run_collection_install(
    collections: Vec<String>,
    requirements: Option<PathBuf>,
    collections_path: Option<PathBuf>,
) -> Result<u8> {
    use ansible_galaxy::{
        FilesystemFetcher, Installer, Resolver,
    };

    // Gather requirements from CLI args and/or requirements file
    let mut reqs = Vec::new();
    for spec in &collections {
        let req = parse_collection_spec(spec)?;
        reqs.push(req);
    }
    if let Some(req_file) = requirements {
        let file_reqs = parse_requirements_file(&req_file)?;
        reqs.extend(file_reqs);
    }

    if reqs.is_empty() {
        eprintln!("ERROR! You must specify at least one collection or a requirements file.");
        return Ok(1);
    }

    // Determine install path
    let install_root = collections_path.unwrap_or_else(default_collections_path);
    std::fs::create_dir_all(&install_root)?;

    println!(
        "Starting galaxy collection install process"
    );
    println!(
        "Process install dependency map"
    );

    // Check for a local mirror directory. A real Galaxy API fetcher
    // (reqwest-backed) will be added behind the `network` feature.
    let local_mirror = std::env::var("ANSIBLE_GALAXY_LOCAL_MIRROR").ok();
    match local_mirror {
        Some(mirror_path) => {
            let fetcher = FilesystemFetcher::new(&mirror_path);
            let rt = tokio::runtime::Runtime::new()?;

            let plan = rt.block_on(async {
                let resolver = Resolver::new(&fetcher);
                resolver.resolve(&reqs).await
            }).map_err(|e| anyhow::anyhow!("{}", e))?;

            println!(
                "Resolved {} collection(s) to install:",
                plan.entries.len()
            );
            for entry in &plan.entries {
                println!("  - {}.{} ({})", entry.collection.namespace, entry.collection.name, entry.version);
            }

            let written = rt.block_on(async {
                let installer = Installer::new(&fetcher, &install_root);
                installer.install(&plan).await
            }).map_err(|e| anyhow::anyhow!("{}", e))?;

            for path in &written {
                println!("Installed: {}", path.display());
            }

            println!(
                "Successfully installed {} collection(s).",
                written.len()
            );
            Ok(0)
        }
        None => {
            eprintln!(
                "ERROR! Galaxy API client not yet implemented.\n\
                 For local installs, set ANSIBLE_GALAXY_LOCAL_MIRROR to a directory\n\
                 containing tarballs in <namespace>/<name>/<version>.tar.gz layout."
            );
            Ok(1)
        }
    }
}

/// `ansible galaxy collection build`
fn run_collection_build(path: &std::path::Path, output_path: &std::path::Path) -> Result<u8> {
    // Read galaxy.yml from the source directory
    let galaxy_yml = path.join("galaxy.yml");
    if !galaxy_yml.is_file() {
        eprintln!(
            "ERROR! The collection galaxy.yml path '{}' does not exist.",
            galaxy_yml.display()
        );
        return Ok(1);
    }

    let content = std::fs::read_to_string(&galaxy_yml)?;
    let manifest: serde_json::Value = serde_yaml::from_str(&content)
        .map_err(|e| anyhow::anyhow!("Failed to parse galaxy.yml: {}", e))?;

    let namespace = manifest
        .get("namespace")
        .and_then(|v| v.as_str())
        .ok_or_else(|| anyhow::anyhow!("galaxy.yml missing 'namespace'"))?;
    let name = manifest
        .get("name")
        .and_then(|v| v.as_str())
        .ok_or_else(|| anyhow::anyhow!("galaxy.yml missing 'name'"))?;
    let version = manifest
        .get("version")
        .and_then(|v| v.as_str())
        .ok_or_else(|| anyhow::anyhow!("galaxy.yml missing 'version'"))?;

    let tarball_name = format!("{namespace}-{name}-{version}.tar.gz");
    let tarball_path = output_path.join(&tarball_name);

    println!("Created collection for {namespace}.{name} at {}", tarball_path.display());

    // Build MANIFEST.json content
    let manifest_json = serde_json::json!({
        "collection_info": {
            "namespace": namespace,
            "name": name,
            "version": version,
            "dependencies": manifest.get("dependencies").cloned().unwrap_or(serde_json::json!({})),
        }
    });

    // Create tarball
    use flate2::write::GzEncoder;
    use flate2::Compression;
    use std::io::Write;

    let tar_file = std::fs::File::create(&tarball_path)?;
    let enc = GzEncoder::new(tar_file, Compression::default());
    let mut tar_builder = tar::Builder::new(enc);

    // Add MANIFEST.json
    let manifest_bytes = serde_json::to_string_pretty(&manifest_json)?;
    let mut header = tar::Header::new_gnu();
    header.set_size(manifest_bytes.len() as u64);
    header.set_mode(0o644);
    header.set_cksum();
    tar_builder.append_data(
        &mut header,
        "MANIFEST.json",
        manifest_bytes.as_bytes(),
    )?;

    // Walk the source directory and add all files
    add_directory_to_tar(&mut tar_builder, path, path)?;

    tar_builder.finish()?;
    let mut enc = tar_builder.into_inner()?;
    enc.flush()?;
    enc.finish()?;

    println!("To install the collection, run:");
    println!("    ansible galaxy collection install {}", tarball_path.display());

    Ok(0)
}

/// `ansible galaxy collection list`
fn run_collection_list(
    collections_path: Option<PathBuf>,
    format_json: bool,
) -> Result<u8> {
    let roots = match collections_path {
        Some(p) => vec![p],
        None => {
            let mut paths = Vec::new();
            if let Some(home) = std::env::var_os("HOME") {
                paths.push(PathBuf::from(home).join(".ansible/collections"));
            }
            paths.push(PathBuf::from("/usr/share/ansible/collections"));
            paths
        }
    };

    let mut found: Vec<(String, String, String)> = Vec::new(); // (namespace, name, version)

    for root in &roots {
        let ac_dir = root.join("ansible_collections");
        if !ac_dir.is_dir() {
            continue;
        }
        let Ok(ns_entries) = std::fs::read_dir(&ac_dir) else {
            continue;
        };
        for ns_entry in ns_entries.flatten() {
            if !ns_entry.path().is_dir() {
                continue;
            }
            let namespace = ns_entry.file_name().to_string_lossy().to_string();
            let Ok(col_entries) = std::fs::read_dir(ns_entry.path()) else {
                continue;
            };
            for col_entry in col_entries.flatten() {
                if !col_entry.path().is_dir() {
                    continue;
                }
                let name = col_entry.file_name().to_string_lossy().to_string();
                // Try to read version from MANIFEST.json or galaxy.yml
                let version = read_installed_version(&col_entry.path());
                found.push((namespace.clone(), name, version));
            }
        }
    }

    if format_json {
        let json: serde_json::Value = found
            .iter()
            .map(|(ns, name, ver)| {
                serde_json::json!({
                    "fqcn": format!("{ns}.{name}"),
                    "version": ver,
                })
            })
            .collect();
        println!("{}", serde_json::to_string_pretty(&json)?);
    } else {
        if found.is_empty() {
            println!("No collections found.");
        } else {
            println!("# {:<40} Version", "Collection");
            println!("# {:<40} -------", "----------");
            for (ns, name, ver) in &found {
                println!("{ns}.{name:<38} {ver}");
            }
        }
    }

    Ok(0)
}

// ---- Helpers ----

/// Parse `namespace.name` or `namespace.name:>=1.0` from CLI args.
fn parse_collection_spec(spec: &str) -> Result<ansible_galaxy::CollectionRequirement> {
    if let Some((name, version)) = spec.split_once(':') {
        ansible_galaxy::CollectionRequirement::new(name, version)
            .map_err(|e| anyhow::anyhow!("{}", e))
    } else {
        ansible_galaxy::CollectionRequirement::any(spec)
            .map_err(|e| anyhow::anyhow!("{}", e))
    }
}

/// Parse a `requirements.yml` file into collection requirements.
fn parse_requirements_file(path: &PathBuf) -> Result<Vec<ansible_galaxy::CollectionRequirement>> {
    let content = std::fs::read_to_string(path)
        .map_err(|e| anyhow::anyhow!("Failed to read requirements file '{}': {}", path.display(), e))?;

    let doc: serde_json::Value = serde_yaml::from_str(&content)
        .map_err(|e| anyhow::anyhow!("Failed to parse requirements file: {}", e))?;

    let mut reqs = Vec::new();

    // Format 1: { collections: [ {name: "ns.col", version: ">=1.0"}, ... ] }
    // Format 2: [ {name: "ns.col", version: ">=1.0"}, ... ]
    let items = if let Some(collections) = doc.get("collections").and_then(|v| v.as_array()) {
        collections.clone()
    } else if let Some(arr) = doc.as_array() {
        arr.clone()
    } else {
        return Err(anyhow::anyhow!(
            "requirements.yml must contain a 'collections' list or be a list of collections"
        ));
    };

    for item in &items {
        if let Some(name) = item.as_str() {
            // Simple string form: "namespace.name"
            reqs.push(
                ansible_galaxy::CollectionRequirement::any(name)
                    .map_err(|e| anyhow::anyhow!("{}", e))?,
            );
        } else if let Some(obj) = item.as_object() {
            let name = obj
                .get("name")
                .and_then(|v| v.as_str())
                .ok_or_else(|| anyhow::anyhow!("Collection entry missing 'name'"))?;
            let version = obj
                .get("version")
                .and_then(|v| v.as_str())
                .unwrap_or("*");
            reqs.push(
                ansible_galaxy::CollectionRequirement::new(name, version)
                    .map_err(|e| anyhow::anyhow!("{}", e))?,
            );
        }
    }

    Ok(reqs)
}

/// Read the version of an installed collection from MANIFEST.json or galaxy.yml.
fn read_installed_version(col_path: &std::path::Path) -> String {
    // Try MANIFEST.json first
    let manifest_path = col_path.join("MANIFEST.json");
    if manifest_path.is_file() {
        if let Ok(content) = std::fs::read_to_string(&manifest_path) {
            if let Ok(manifest) = ansible_galaxy::parse_manifest(&content) {
                return manifest.version;
            }
        }
    }
    // Try galaxy.yml
    let galaxy_path = col_path.join("galaxy.yml");
    if galaxy_path.is_file() {
        if let Ok(content) = std::fs::read_to_string(&galaxy_path) {
            if let Ok(doc) = serde_yaml::from_str::<serde_json::Value>(&content) {
                if let Some(v) = doc.get("version").and_then(|v| v.as_str()) {
                    return v.to_string();
                }
            }
        }
    }
    "*".to_string()
}

/// Default collections install path.
fn default_collections_path() -> PathBuf {
    if let Some(home) = std::env::var_os("HOME") {
        PathBuf::from(home).join(".ansible/collections")
    } else {
        PathBuf::from("/usr/share/ansible/collections")
    }
}

/// Recursively add files from a directory to a tar archive.
fn add_directory_to_tar<W: std::io::Write>(
    builder: &mut tar::Builder<W>,
    base: &std::path::Path,
    dir: &std::path::Path,
) -> Result<()> {
    let entries = std::fs::read_dir(dir)?;
    for entry in entries.flatten() {
        let path = entry.path();
        let rel = path.strip_prefix(base).unwrap_or(&path);
        let rel_str = rel.to_string_lossy();

        // Skip hidden files, __pycache__, .git, build artifacts
        if let Some(name) = path.file_name().and_then(|n| n.to_str()) {
            if name.starts_with('.') || name == "__pycache__" || name == "*.pyc" {
                continue;
            }
        }

        if path.is_dir() {
            add_directory_to_tar(builder, base, &path)?;
        } else if path.is_file() {
            builder.append_path_with_name(&path, &*rel_str)?;
        }
    }
    Ok(())
}
