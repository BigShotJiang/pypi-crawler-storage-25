use std::path::PathBuf;

use anyhow::Result;

use crate::VaultAction;

/// Run vault operations.
pub fn run_vault(
    _config: &ansible_config::AnsibleConfig,
    action: VaultAction,
    vault_password_file: Option<&PathBuf>,
) -> Result<u8> {
    // Get vault password
    let password = get_vault_password(vault_password_file)?;
    let secret = ansible_vault::VaultSecret::new(password);
    let vault = ansible_vault::VaultLib::new(vec![secret.clone()]);

    match action {
        VaultAction::Encrypt { files, vault_id: _ } => {
            for file in &files {
                let content = std::fs::read(file)?;
                let encrypted = vault.encrypt(&content, &secret)?;
                std::fs::write(file, encrypted)?;
                println!("Encryption successful: {}", file.display());
            }
        }
        VaultAction::Decrypt { files } => {
            for file in &files {
                let content = std::fs::read_to_string(file)?;
                let decrypted = vault.decrypt(&content)?;
                std::fs::write(file, decrypted)?;
                println!("Decryption successful: {}", file.display());
            }
        }
        VaultAction::View { file } => {
            let content = std::fs::read_to_string(&file)?;
            let decrypted = vault.decrypt_str(&content)?;
            print!("{decrypted}");
        }
        VaultAction::Edit { file: _ } => {
            println!("vault edit: not yet implemented");
        }
        VaultAction::Rekey { files: _ } => {
            println!("vault rekey: not yet implemented");
        }
        VaultAction::EncryptString { string, name } => {
            let text = match string {
                Some(s) => s,
                None => {
                    let mut buf = String::new();
                    std::io::Read::read_to_string(&mut std::io::stdin(), &mut buf)?;
                    buf
                }
            };
            let encrypted = vault.encrypt(text.as_bytes(), &secret)?;
            if let Some(var_name) = name {
                println!("{var_name}: !vault |");
                for line in encrypted.lines() {
                    println!("    {line}");
                }
            } else {
                println!("{encrypted}");
            }
        }
    }

    Ok(0)
}

fn get_vault_password(vault_password_file: Option<&PathBuf>) -> Result<Vec<u8>> {
    if let Some(path) = vault_password_file {
        let password = std::fs::read_to_string(path)?;
        return Ok(password.trim().as_bytes().to_vec());
    }

    if let Ok(password) = std::env::var("ANSIBLE_VAULT_PASSWORD") {
        return Ok(password.into_bytes());
    }

    Err(anyhow::anyhow!(
        "no vault password provided. Use --vault-password-file or set ANSIBLE_VAULT_PASSWORD"
    ))
}
