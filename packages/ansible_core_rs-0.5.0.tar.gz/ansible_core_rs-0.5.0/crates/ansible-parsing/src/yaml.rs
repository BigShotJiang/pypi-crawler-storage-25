use ansible_utils::AnsibleValue;

use crate::ParsingError;

/// Ansible-specific YAML header for vault-encrypted content.
const VAULT_HEADER: &str = "$ANSIBLE_VAULT";

/// Ansible-specific YAML tag for unsafe content (no templating).
#[allow(dead_code)]
const UNSAFE_TAG: &str = "!unsafe";

/// Parse YAML content into an AnsibleValue, handling Ansible-specific tags.
pub fn parse_yaml(content: &str) -> Result<AnsibleValue, ParsingError> {
    // Check if the content is vault-encrypted
    if content.trim_start().starts_with(VAULT_HEADER) {
        return Err(ParsingError::VaultError(
            "vault-encrypted content must be decrypted before parsing".into(),
        ));
    }

    let value: AnsibleValue =
        serde_yaml::from_str(content).map_err(|e| ParsingError::YamlError(e.to_string()))?;

    Ok(value)
}

/// Parse a YAML file that may contain multiple documents.
pub fn parse_yaml_documents(content: &str) -> Result<Vec<AnsibleValue>, ParsingError> {
    let mut documents = Vec::new();

    // serde_yaml doesn't natively support multi-document, so split on ---
    for doc in content.split("\n---") {
        let doc = doc.trim();
        if doc.is_empty() || doc == "..." {
            continue;
        }

        let value: AnsibleValue =
            serde_yaml::from_str(doc).map_err(|e| ParsingError::YamlError(e.to_string()))?;
        documents.push(value);
    }

    Ok(documents)
}

/// Check if a string contains Jinja2 template markers.
pub fn is_template(value: &str) -> bool {
    value.contains("{{") || value.contains("{%") || value.contains("{#")
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_parse_simple_yaml() {
        let yaml = r#"
name: test
hosts: all
tasks:
  - name: ping
    ping:
"#;
        let result = parse_yaml(yaml).unwrap();
        assert_eq!(result["name"], "test");
        assert_eq!(result["hosts"], "all");
    }

    #[test]
    fn test_is_template() {
        assert!(is_template("{{ foo }}"));
        assert!(is_template("{% if bar %}"));
        assert!(!is_template("plain string"));
    }

    #[test]
    fn test_vault_detection() {
        let vault_content = "$ANSIBLE_VAULT;1.1;AES256\nabcdef";
        let result = parse_yaml(vault_content);
        assert!(result.is_err());
    }
}
