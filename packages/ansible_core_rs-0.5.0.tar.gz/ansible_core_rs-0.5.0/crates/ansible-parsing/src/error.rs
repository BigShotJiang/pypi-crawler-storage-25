use thiserror::Error;

#[derive(Debug, Error)]
pub enum ParsingError {
    #[error("YAML parse error: {0}")]
    YamlError(String),

    #[error("file not found: {0}")]
    FileNotFound(String),

    #[error("vault decryption failed: {0}")]
    VaultError(String),

    #[error("invalid data: {0}")]
    InvalidData(String),

    #[error(transparent)]
    Io(#[from] std::io::Error),

    #[error(transparent)]
    SerdeYaml(#[from] serde_yaml::Error),

    #[error(transparent)]
    Vault(#[from] ansible_vault::VaultError),
}
