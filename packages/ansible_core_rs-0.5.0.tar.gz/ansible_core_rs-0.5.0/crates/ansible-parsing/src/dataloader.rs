use std::collections::HashMap;
use std::path::{Path, PathBuf};

use ansible_utils::AnsibleValue;
use ansible_vault::VaultLib;

use crate::ParsingError;

/// Loads data from files with vault decryption support.
pub struct DataLoader {
    vault: Option<VaultLib>,
    /// Cache of already-loaded files.
    cache: HashMap<PathBuf, AnsibleValue>,
}

impl DataLoader {
    pub fn new() -> Self {
        Self {
            vault: None,
            cache: HashMap::new(),
        }
    }

    /// Set the vault library for decrypting vault-encrypted files.
    pub fn set_vault(&mut self, vault: VaultLib) {
        self.vault = Some(vault);
    }

    /// Load and parse a YAML file.
    pub fn load_from_file(&mut self, path: &Path) -> Result<AnsibleValue, ParsingError> {
        let path = path.canonicalize().unwrap_or_else(|_| path.to_path_buf());

        // Check cache
        if let Some(cached) = self.cache.get(&path) {
            return Ok(cached.clone());
        }

        let content = crate::read_file_efficient(&path)?;

        // Check if vault-encrypted and decrypt if possible
        let content = if content.trim_start().starts_with("$ANSIBLE_VAULT") {
            match &self.vault {
                Some(vault) => vault
                    .decrypt_str(&content)
                    .map_err(|e| ParsingError::VaultError(e.to_string()))?,
                None => {
                    return Err(ParsingError::VaultError(
                        "vault-encrypted file but no vault password provided".into(),
                    ))
                }
            }
        } else {
            content
        };

        let value = crate::yaml::parse_yaml(&content)?;

        // Recursively decrypt inline vault strings (e.g. from !vault | tag).
        let value = if self.vault.is_some() {
            self.decrypt_inline_vault_values(value)?
        } else {
            value
        };

        // Cache the result
        self.cache.insert(path, value.clone());

        Ok(value)
    }

    /// Load a file as raw bytes.
    pub fn load_raw(&self, path: &Path) -> Result<Vec<u8>, ParsingError> {
        Ok(std::fs::read(path)?)
    }

    /// Check if a path exists.
    pub fn path_exists(&self, path: &Path) -> bool {
        path.exists()
    }

    /// Check if a path is a directory.
    pub fn is_directory(&self, path: &Path) -> bool {
        path.is_dir()
    }

    /// Check if a path is a file.
    pub fn is_file(&self, path: &Path) -> bool {
        path.is_file()
    }

    /// List files in a directory.
    pub fn list_directory(&self, path: &Path) -> Result<Vec<PathBuf>, ParsingError> {
        let mut entries = Vec::new();
        for entry in std::fs::read_dir(path)? {
            let entry = entry?;
            entries.push(entry.path());
        }
        entries.sort();
        Ok(entries)
    }

    /// Recursively walk a parsed YAML value tree and decrypt any inline
    /// vault strings. Inline vault strings are regular string values that
    /// start with `$ANSIBLE_VAULT` — they appear when playbooks use the
    /// `!vault |` YAML tag or store vault-encrypted values in vars files.
    fn decrypt_inline_vault_values(
        &self,
        value: AnsibleValue,
    ) -> Result<AnsibleValue, ParsingError> {
        match value {
            AnsibleValue::String(s) if s.trim_start().starts_with("$ANSIBLE_VAULT") => {
                let vault = self.vault.as_ref().unwrap(); // caller checked
                let decrypted = vault
                    .decrypt_str(&s)
                    .map_err(|e| ParsingError::VaultError(e.to_string()))?;
                // Try to parse the decrypted value as YAML — it might be a
                // structured value (dict, list) not just a plain string.
                match crate::yaml::parse_yaml(decrypted.trim()) {
                    Ok(parsed) => Ok(parsed),
                    Err(_) => Ok(AnsibleValue::String(decrypted)),
                }
            }
            AnsibleValue::Object(map) => {
                let mut result = serde_json::Map::new();
                for (k, v) in map {
                    result.insert(k, self.decrypt_inline_vault_values(v)?);
                }
                Ok(AnsibleValue::Object(result))
            }
            AnsibleValue::Array(arr) => {
                let result: Result<Vec<_>, _> = arr
                    .into_iter()
                    .map(|v| self.decrypt_inline_vault_values(v))
                    .collect();
                Ok(AnsibleValue::Array(result?))
            }
            // Non-string scalars pass through unchanged.
            other => Ok(other),
        }
    }

    /// Clear the file cache.
    pub fn clear_cache(&mut self) {
        self.cache.clear();
    }
}

impl Default for DataLoader {
    fn default() -> Self {
        Self::new()
    }
}

#[cfg(test)]
mod tests {
    use super::*;
    use ansible_vault::VaultSecret;

    #[test]
    fn test_load_plain_yaml_file() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("vars.yml");
        std::fs::write(&path, "key: value\ncount: 42\n").unwrap();

        let mut loader = DataLoader::new();
        let result = loader.load_from_file(&path).unwrap();
        assert_eq!(result["key"], "value");
        assert_eq!(result["count"], 42);
    }

    #[test]
    fn test_vault_encrypted_file_without_password_fails() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("secret.yml");
        std::fs::write(&path, "$ANSIBLE_VAULT;1.1;AES256\nabcdef\n").unwrap();

        let mut loader = DataLoader::new();
        let result = loader.load_from_file(&path);
        assert!(result.is_err());
    }

    #[test]
    fn test_vault_encrypted_file_roundtrip() {
        let secret = VaultSecret::new(b"testpassword".to_vec());
        let vault = VaultLib::new(vec![secret.clone()]);

        // Encrypt some YAML content
        let plaintext = "db_password: supersecret\napi_key: abc123\n";
        let encrypted = vault
            .encrypt(plaintext.as_bytes(), &secret)
            .unwrap();

        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("encrypted_vars.yml");
        std::fs::write(&path, &encrypted).unwrap();

        // Load with vault configured
        let mut loader = DataLoader::new();
        loader.set_vault(vault);
        let result = loader.load_from_file(&path).unwrap();
        assert_eq!(result["db_password"], "supersecret");
        assert_eq!(result["api_key"], "abc123");
    }

    #[test]
    fn test_inline_vault_string_decryption() {
        let secret = VaultSecret::new(b"mypassword".to_vec());
        let vault = VaultLib::new(vec![secret.clone()]);

        // Encrypt a single value
        let encrypted_value = vault
            .encrypt(b"my_secret_value", &secret)
            .unwrap();

        // Create a YAML file with an inline vault string
        let yaml_content = format!(
            "username: admin\npassword: |\n{}",
            encrypted_value
                .lines()
                .map(|l| format!("  {l}"))
                .collect::<Vec<_>>()
                .join("\n")
        );

        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("mixed_vars.yml");
        std::fs::write(&path, &yaml_content).unwrap();

        let mut loader = DataLoader::new();
        loader.set_vault(vault);
        let result = loader.load_from_file(&path).unwrap();
        assert_eq!(result["username"], "admin");
        // The password field should be decrypted
        assert_eq!(
            result["password"].as_str().unwrap().trim(),
            "my_secret_value"
        );
    }

    #[test]
    fn test_file_caching() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("cached.yml");
        std::fs::write(&path, "value: first\n").unwrap();

        let mut loader = DataLoader::new();
        let result1 = loader.load_from_file(&path).unwrap();
        assert_eq!(result1["value"], "first");

        // Modify the file — should still return cached value
        std::fs::write(&path, "value: second\n").unwrap();
        let result2 = loader.load_from_file(&path).unwrap();
        assert_eq!(result2["value"], "first"); // cached

        // Clear cache and reload
        loader.clear_cache();
        let result3 = loader.load_from_file(&path).unwrap();
        assert_eq!(result3["value"], "second"); // fresh
    }
}
