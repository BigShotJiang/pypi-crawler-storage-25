pub mod dataloader;
pub mod error;
pub mod yaml;

pub use dataloader::DataLoader;
pub use error::ParsingError;

/// Threshold (in bytes) above which files are read via memory-mapped I/O
/// instead of loading into a heap-allocated buffer. 64 KiB is chosen as a
/// reasonable crossover point: below this the overhead of mmap() outweighs
/// the benefit; above it, mmap avoids a large memcpy and reduces peak RSS
/// because the kernel can page the file in on demand.
pub const MMAP_THRESHOLD: u64 = 64 * 1024;

/// Read a file's contents as a string. For files larger than
/// [`MMAP_THRESHOLD`], this uses memory-mapped I/O to avoid allocating a
/// separate heap buffer for the file contents — the OS pages the file
/// directly into the process address space.
///
/// The caller does not need to worry about the mmap lifetime; the returned
/// `String` is always owned, but the underlying pages were read without an
/// intermediate `Vec<u8>` allocation for large files.
pub fn read_file_efficient(path: &std::path::Path) -> Result<String, std::io::Error> {
    let metadata = std::fs::metadata(path)?;

    if metadata.len() > MMAP_THRESHOLD {
        let file = std::fs::File::open(path)?;
        // Safety: we only read from the mapping and never mutate it. The file
        // is opened read-only, and we immediately copy the bytes into an owned
        // String, so the mmap lifetime is scoped to this function.
        let mmap = unsafe { memmap2::Mmap::map(&file)? };
        // Validate UTF-8 while copying — the kernel may serve pages from the
        // page cache without a physical read, but we still need a contiguous
        // UTF-8 string for the YAML parser.
        let content =
            std::str::from_utf8(&mmap).map_err(|e| std::io::Error::new(std::io::ErrorKind::InvalidData, e))?;
        Ok(content.to_owned())
    } else {
        std::fs::read_to_string(path)
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn test_read_small_file_uses_read_to_string() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("small.yml");
        std::fs::write(&path, "key: value\n").unwrap();
        let content = read_file_efficient(&path).unwrap();
        assert_eq!(content, "key: value\n");
    }

    #[test]
    fn test_read_large_file_uses_mmap() {
        let dir = tempfile::tempdir().unwrap();
        let path = dir.path().join("large.yml");
        // Create a file larger than MMAP_THRESHOLD (64 KiB)
        let large_content = "key: value\n".repeat(7000); // ~77 KiB
        std::fs::write(&path, &large_content).unwrap();
        let content = read_file_efficient(&path).unwrap();
        assert!(content.starts_with("key: value\n"));
        assert_eq!(content.len(), large_content.len());
    }

    #[test]
    fn test_read_nonexistent_file_errors() {
        let result = read_file_efficient(std::path::Path::new("/nonexistent/file.yml"));
        assert!(result.is_err());
    }
}
