def hello():
    print("Created by Hubaib 🔥")