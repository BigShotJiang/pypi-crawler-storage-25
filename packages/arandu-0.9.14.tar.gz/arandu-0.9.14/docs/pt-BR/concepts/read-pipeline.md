# Read Pipeline

Quando você chama `memory.retrieve()`, o SDK busca tudo que sabe sobre um agente e retorna os fatos mais relevantes pra sua query - ranqueados, pontuados e formatados numa string que você pode colar direto num prompt de LLM.

**Você não precisa entender os internals pra usar.** Basta chamar `retrieve()` e usar `result.context`. Esta página explica o que acontece por baixo dos panos, pra quando você quiser ajustar o comportamento ou debugar resultados.

```mermaid
flowchart LR
    A["Query"] --> B["Plan"]
    B --> C["Retrieve\n(3 signals)"]
    C --> D["Enhance"]
    D --> E["Rerank"]
    E --> F["RetrieveResult"]
```

## Visão Geral

Toda chamada a `memory.retrieve(agent_id, query)` executa cinco estágios:

1. **Plan** - Descobre *o que* buscar. Reformula sua query, identifica quais pessoas/lugares/coisas são relevantes.
2. **Retrieve** - Busca fatos usando três métodos em paralelo: similaridade de significado, match de palavras-chave e travessia do grafo de relacionamentos.
3. **Enhance** - Expande o contexto seguindo relacionamentos entre entidades pra encontrar fatos relacionados que não foram diretamente matcheados.
4. **Rerank** - Um LLM reavalia os top resultados e reordena pela relevância real pra sua query.
5. **Format** - Comprime os fatos ranqueados numa string com orçamento de tokens, organizada por tiers de relevância.

---

## Estágio 1: Retrieval Agent (Planner)

**Em português claro:** Antes de buscar, o pipeline pergunta a um LLM: "O que essa pessoa tá procurando?" O LLM reformula a query pra melhores resultados de busca, identifica quais entidades (pessoas, lugares, empresas) são relevantes, e decide a estratégia.

O retrieval agent é um planner alimentado por LLM que decide **como** recuperar, não apenas **o que** recuperar. Ele analisa a query e produz um `RetrievalPlan`.

### O Que o Planner Decide

| Campo | Descrição | Exemplo |
|-------|-----------|---------|
| `strategy` | Estratégia de retrieval | `"multi_signal"` (padrão) ou `"skip"` (para saudações) |
| `similarity_query` | Query reformulada para busca semântica | "user location city" (de "onde eu moro?") |
| `entities` | Entity keys para sinal graph | `["person:ana", "organization:acme"]` |
| `as_of_range` | Janela de time-travel (opcional) | `{"start": "2024-01-01", "end": "2024-06-30"}` |
| `broad_query` | Se deve expandir o escopo do graph | `true` para "me conte tudo sobre..." |
| `reason` | Explicação da estratégia | Para debugging e observabilidade |

### Reformulação da Query

O planner não simplesmente passa a query do usuário para busca semântica. Ele **reformula** para melhorar o matching por similaridade vetorial:

- `"onde eu moro?"` → `"user location city residence"`
- `"o que a Ana faz de trabalho?"` → `"Ana profession occupation job role"`

Isso fecha a lacuna de vocabulário entre como os usuários fazem perguntas e como os fatos são armazenados.

### Planejamento Schema-Aware

O planner inspeciona o schema real da memória para este agente:

- Quais tipos de entidade existem (pessoas, organizações, lugares...)
- Quais entidades têm mais fatos
- Quais atributos estão armazenados

Isso ancora o plano na realidade - o planner não vai buscar entidades que não existem.

### Entity Resolution Híbrida

Quando você pergunta "Onde o Carlos mora?", o pipeline precisa descobrir que "Carlos" significa a entidade `person:carlos` no banco. Ele usa três métodos pra isso - se um falhar, os outros cobrem:

1. **Resolução determinística (primária)** - Faz match de palavras da query contra aliases de entidades conhecidas (`MemoryEntityAlias`), display names (`MemoryEntity.display_name`) e slugs de entity_keys. Rápido (< 10ms), confiável, custo zero de LLM. Por exemplo, "Onde o Carlos mora?" resolve deterministicamente para `person:carlos` via slug match.

2. **LLM planner (suplementar)** - O retrieval agent extrai entidades com base no entendimento da query. Captura referências indiretas que o determinístico não resolve (ex: "meu chefe" → `person:kevin`).

3. **Query expansion (priming de aliases)** - `expand_query()` resolve aliases e busca vizinhos 1-hop no KG, adicionando entidades relacionadas.

As três fontes são **unificadas** antes do graph gate. Se qualquer fonte identificar uma entidade, o graph traversal roda. Isso torna o sinal de grafo tolerante a falhas: se o LLM falha em extrair entidades (variância do LLM), a camada determinística cobre.

O trace step `"retrieval"` inclui um breakdown `entities_sources` mostrando quais entidades vieram de cada fonte (`llm`, `deterministic`, `expansion`).

### Estratégia Skip

Para saudações e mensagens casuais ("oi", "como vai?"), o planner retorna `strategy: "skip"`, fazendo short-circuit no pipeline. Sem queries no banco, sem chamadas LLM, resposta instantânea.

!!! info "Paralelo com neurociência"
    O retrieval agent espelha **pistas de recuperação** na psicologia cognitiva. Quando você tenta lembrar algo, seu cérebro não faz uma busca exaustiva - ele usa pistas contextuais para estreitar o espaço de busca. O planner identifica entidades e reformula queries como pistas que guiam os sinais de retrieval.

??? example "Passo a passo: ciclo de vida completo de uma query"
    **Query:** "Onde o Marcos Tavares mora?"

    **Estágio 1 - Planejamento:**
    ```
    Planner identifica: entity = "Marcos Tavares", strategy = multi_signal
    Resolver determinístico: "marcos tavares" → person:marcos_tavares (slug match)
    Query reformulada: "Marcos Tavares residence location"
    ```

    **Estágio 2 - Retrieval multi-signal (paralelo):**
    ```
    Semântico: embedding("Marcos Tavares residence") → top match: "Marcos Tavares lives in Porto Alegre" (0.91)
    Keyword: "marcos" + "tavares" → 4 fatos sobre Marcos
    Graph: BFS a partir de person:marcos_tavares → encontra fatos via entity links + relationships
    ```

    **Estágio 3 - Enhancement:**
    ```
    Spreading activation: a partir do seed "lives in Porto Alegre" → encontra fatos relacionados:
      "Marcos Tavares is married to Carolina" (via entity hop)
      "Carolina is an architect" (via 2-hop)
    ```

    **Estágio 4 - Reranking (blend multiplicativo):**
    ```
    "Marcos Tavares lives in Porto Alegre" → formula=0.91, reranker=1.0 → final=0.91 ✅
    "Marcos Tavares is a product manager at Vertix" → formula=0.65, reranker=0.2 → final=0.28
    "Carolina is an architect" → formula=0.30, reranker=0.0 → final=0.09 → filtrado (< 0.15)
    ```

    **Estágio 5 - Formatação:**
    ```
    ## Known facts about the user:
    - Marcos Tavares lives in Porto Alegre (confidence: 0.95)
    ```

    **Resultado:** 1 fato altamente relevante, 210ms, 800 tokens.

---

## Estágio 2: Retrieval Multi-Signal

**Em português claro:** O pipeline busca fatos relevantes usando três métodos diferentes ao mesmo tempo - por significado, por palavras exatas e por conexões entre entidades. Isso captura fatos que qualquer método sozinho perderia.

Três sinais independentes rodam **em paralelo** via `asyncio.gather()`, cada um encontrando candidatos de um ângulo diferente:

```mermaid
flowchart TD
    P["RetrievalPlan"] --> S["Semantic Search\n(pgvector cosine)"]
    P --> K["Keyword Search\n(SQL ILIKE)"]
    P --> G["Graph Traversal\n(BFS 2-hop)"]
    S --> M["Merge & Rank\n(dedup + weighted scoring)"]
    K --> M
    G --> M
```

### Sinal 1: Semantic Search

Usa similaridade de cosseno do pgvector para encontrar fatos cujos embeddings são próximos ao embedding da query.

- Embeds a query reformulada (do planner)
- Busca na tabela `MemoryFact` com índice HNSW
- Retorna top-N candidatos acima do threshold `min_similarity`
- Filtros: `agent_id`, fatos ativos (`valid_to IS NULL`), confiança >= `min_confidence`

Este é o sinal primário - encontra fatos que são **semanticamente similares** à query, mesmo que não compartilhem keywords exatas.

### Sinal 2: Keyword Search

Matching SQL ILIKE em `fact_text` para hits exatos ou parciais de keywords.

- Extrai palavras significativas (> 2 caracteres) da query
- Faz match contra o texto do fato (até 5 keywords)
- Score = fração de palavras da query encontradas no fato

Complementa a busca semântica capturando matches exatos que a similaridade de embedding pode perder (ex: nomes próprios, termos técnicos, abreviações).

### Sinal 3: Graph Retrieval

Percorre relacionamentos de entidades para encontrar fatos conectados às entidades da query.

- Começa das entidades identificadas pelo planner
- Traversal BFS até 2 hops em `MemoryEntityRelationship`
- **Hop decay**: Fatos no Hop 1 recebem score completo (1.0×). Fatos no Hop 2 recebem penalidade de 0.5×. Isso evita que fatos distantes dominem o pool de candidatos.
- Fatos são buscados via **entity links** (`MemoryFactEntityLink`), não só pelo `entity_key` primário. Isso significa que um fato "Clara saiu da Vertix" (subject primário: Clara) também é encontrado ao buscar sobre Vertix - porque o fato tem um entity link secundário pra Vertix.
- Fórmula de scoring: `edge_strength × recency_factor × edge_recency_factor × query_bonus × hop_decay`
- `query_bonus`: 1.5x quando o nome da entidade aparece no texto da query
- **Fallback**: se a tabela de entity links está vazia (pré-migration), retrieval faz fallback pra match direto por `entity_key`

Graph retrieval se destaca em encontrar fatos **contextuais**. Quando você pergunta sobre uma pessoa, ele também encontra fatos sobre seu local de trabalho, seus relacionamentos e seus projetos.

??? example "Passo a passo: retrieval cross-entity via entity links"
    **Query:** "O que aconteceu com a Vertix?"

    **Sem entity links (comportamento antigo):**
    ```
    Graph começa de organization:vertix
    Busca MemoryFact WHERE entity_key = 'organization:vertix'
    Encontra: apenas fatos onde Vertix é o subject PRIMÁRIO
    Perde: "Clara Rezende left Vertix" (entity_key = person:clara_rezende)
    ```

    **Com entity links (comportamento atual):**
    ```
    Graph começa de organization:vertix
    Busca MemoryFactEntityLink WHERE entity_key = 'organization:vertix'
    Encontra fact_ids linkados à Vertix, independente do subject primário:
      → "Clara Rezende left Vertix" (primário: Clara, link: Vertix) ✅
      → "Vertix received Series A of R$ 20M" (primário: Vertix) ✅
      → "Ricardo Gomes is co-founder of Vertix" (primário: Ricardo, link: Vertix) ✅
      → "Vertix signed contract with Ambev" (primário: Vertix) ✅
    ```

    **Resultado:** 4 fatos encontrados vs 2 sem links. A query sobre Vertix traz fatos de Clara, Ricardo e o deal da Ambev - todos linkados à Vertix mas não primariamente sobre a Vertix.

### Merge & Rank

Depois que os três sinais retornam, os resultados são mesclados:

1. **Deduplicar** por fact ID (o mesmo fato pode aparecer em múltiplos sinais)
2. **Aplicar decay de recência** - Decay exponencial com half-life configurável (`recency_half_life_days`, padrão 14)
3. **Aplicar decay de confiança** - Fatos mais antigos com menor confiança são penalizados
4. **Calcular score combinado** - Soma ponderada:

!!! warning "O reranker faz blend com estes pesos"
    Por padrão, `enable_reranker=True` - o reranker LLM usa um blend multiplicativo com o score da fórmula computado a partir destes pesos. O score da fórmula continua sendo importante porque o reranker só pode atenuar ou amplificar, nunca zerar. Configure `enable_reranker=False` para depender apenas destes pesos no ranking final.

```python
score = (
    score_weights["semantic"]   * semantic_score +    # default 0.70
    score_weights["recency"]    * recency_score +     # default 0.20
    score_weights["importance"] * importance_score     # default 0.10
)
```

### Breakdown Completo do Score

Cada fato é pontuado em múltiplas dimensões. Você pode inspecionar em `fact.scores` pra entender **por que** um fato ficou onde ficou no ranking:

Cada dict `ScoredFact.scores` contém **todos os 6 sinais** computados ao longo do pipeline. A fórmula ponderada acima produz o score combinado base; estágios posteriores adicionam sinais que podem modificar o ranking final:

| Chave | Origem | Range | Descrição |
|-------|--------|-------|-----------|
| `semantic` | Busca semântica | 0.0 - 1.0 | Similaridade de cosseno entre embeddings da query e do fato. Sinal primário de retrieval. |
| `keyword` | Busca por keyword | 0.0 - 1.0 | Fração de palavras da query encontradas no texto do fato. Complementa semântico para matches exatos. |
| `recency` | Merge & Rank | 0.0 - 1.0 | Decay exponencial a partir do `created_at`, half-life = `recency_half_life_days` (padrão 14). |
| `importance` | Importância dinâmica | 0.0 - 1.0 | Valor raw de importância do banco de dados. Computado pelo job de importância em background a partir de frequência de retrieval, recência de uso, correções do usuário e participação em padrões. Começa em 0.5 para fatos novos e evolui ao longo do tempo. |
| `confidence` | Merge & Rank | 0.0 - 1.0 | Confiança efetiva após decay temporal. Presente no dict `scores` para debugging, mas NÃO faz parte da fórmula ponderada (`score_weights` usa apenas `semantic`, `recency`, `importance`). A confiança base é atribuída pelo LLM durante extração (tipicamente 0.95 para afirmações assertivas). Decai ao longo do tempo e é usada como filtro (`min_confidence`). |
| `reranker` | Reranking | 0.0 - 1.0 | Score de relevância baseado em LLM. Presente apenas quando `enable_reranker=True`. Float contínuo retornado pelo reranker LLM. |

Sinais adicionais computados durante enhancement (não estão em `score_weights` mas afetam o score final):

| Chave | Origem | Descrição |
|-------|--------|-----------|
| `pattern` | Enhancement | Boost aditivo para fatos com alto `reinforcement_count` (até +0.10). |
| `graph` | Graph traversal | Score do traversal BFS de 2 saltos em relacionamentos de entidades. |

### Configuração

| Parâmetro | Default | Descrição |
|-----------|---------|-----------|
| `topk_facts` | `20` | Máximo de fatos a retornar |
| `topk_events` | `8` | Máximo de eventos a considerar |
| `min_similarity` | `0.20` | Similaridade de cosseno mínima para resultados semânticos |
| `min_confidence` | `0.55` | Confiança mínima do fato |
| `recency_half_life_days` | `14` | Half-life para decay de recência |
| `score_weights` | Veja acima | Pesos para cada sinal de scoring |
| `min_score` | `0.15` | Score final mínimo para fatos retornados |
| `enable_reranker` | `True` | Se deve usar reranking LLM |

!!! info "Paralelo com neurociência"
    O retrieval multi-signal espelha **spreading activation** em redes semânticas (Collins & Loftus, 1975). Quando você pensa em "médico", a ativação se espalha para conceitos relacionados ("hospital", "remédio", "consulta") através de links associativos. Da mesma forma, graph retrieval se espalha a partir de entidades da query ao longo de arestas de relacionamento, enquanto busca semântica ativa fatos através de proximidade de embedding.

---

## Estágio 3: Enhancement

**Em português claro:** Depois de encontrar os resultados iniciais, o pipeline segue conexões pra descobrir fatos relacionados. Se você pergunta sobre uma pessoa, ele pode puxar fatos sobre o trabalho dela, projetos e equipe - coisas que você não perguntou diretamente mas que adicionam contexto útil.

### Spreading Activation

A partir dos top-K fatos semente, o pipeline expande o contexto seguindo relacionamentos de entidades:

- Para cada fato semente, encontra os relacionamentos da entidade
- Percorre relacionamentos por N hops (`spreading_activation_hops`, padrão 2). Defina como `0` para desabilitar spreading completamente.
- Aplica fator de decay por hop (`spreading_decay_factor`, padrão 0.50). Hop 1 usa o fator diretamente; Hop 2 usa o fator ao quadrado (decay composto).
- Retorna até `spreading_facts_per_entity` fatos adicionais por entidade (padrão 3), aplicado tanto no Hop 1 quanto no Hop 2.

Isso captura contexto importante que não foi diretamente matcheado. Se você perguntar "o que o Rafael faz?", spreading activation pode trazer fatos sobre seu local de trabalho, time e projetos.

!!! tip "Quando o spreading activation faz diferença?"
    O spreading tem mais impacto com **20+ entidades** e relações cruzadas entre domínios (ex: pessoas → projetos → clientes → tecnologias). Com datasets pequenos (< 15 entidades), os sinais semântico, keyword e graph já cobrem todo o espaço de fatos - o spreading pode retornar candidatos mas eles serão dedupados contra os resultados existentes. Os campos do trace `spreading_candidates_returned` e `spreading_candidates_unique` permitem confirmar se o spreading está contribuindo fatos novos pro seu dataset.

### Sinal de Padrão

Fatos com alto `reinforcement_count` (incrementado por decisões NOOP no write) recebem um boost aditivo no score:

- Alto reinforcement count → até 0.10 de score extra
- Captura fatos frequentemente mencionados e bem estabelecidos

### Configuração

| Parâmetro | Default | Descrição |
|-----------|---------|-----------|
| `spreading_activation_hops` | `2` | Máximo de hops a partir de fatos semente. Defina como `0` para desabilitar. |
| `spreading_decay_factor` | `0.50` | Decay de score por hop. Hop 1 = fator, Hop 2 = fator² |
| `spreading_facts_per_entity` | `3` | Máximo de fatos buscados por entidade no Hop 1 e Hop 2 |
| `spreading_max_related_entities` | `5` | Máximo de entidades KG-relacionadas exploradas no Hop 1 |

---

## Estágio 4: Reranking (Opcional)

**Em português claro:** Os estágios anteriores encontram fatos relevantes, mas o ranking é baseado em matemática (scores de similaridade, keyword overlap). O reranker pergunta a um LLM: "Dado o que essa pessoa tá perguntando, quais desses fatos são realmente mais úteis?" Isso produz um ranking final mais inteligente.

Quando `enable_reranker=True`, os top candidatos são rerankeados por um LLM que considera a intenção da query:

- O reranker avalia **2× `topk_facts`** candidatos (padrão: 40). Esse pool expandido garante que fatos semanticamente relevantes além do top-20 inicial cheguem no reranker. Aumente `topk_facts` pra expandir a cobertura do reranker.
- Respeita o significado semântico da query (não apenas overlap de keywords)
- Pode promover fatos que são indiretamente relevantes mas importantes
- Degradação graceful: se o reranker falhar ou exceder `reranker_timeout_sec` (padrão 5.0s), o ranking original é preservado
- O timeout é enforced via `asyncio.wait_for` - a chamada LLM é cancelada se exceder o timeout configurado
- Usa o mesmo provider LLM configurado no client (não precisa de provider separado)

O reranker é o estágio mais custoso, mas fornece a maior melhoria de qualidade para queries complexas.

### Configuração

| Parâmetro | Tipo | Default | Descrição |
|-----------|------|---------|-----------|
| `reranker_weight` | float | `0.70` | Peso do score do reranker no blend multiplicativo |
| `min_reranker_score` | float | `0.10` | Score mínimo do reranker; fatos abaixo são eliminados |
| `reranker_timeout_sec` | float | `5.0` | Timeout para a chamada LLM do reranker (segundos) |

!!! warning "Veto do reranker: `min_reranker_score`"
    Quando `enable_reranker=True`, qualquer fato que recebe um score do reranker **abaixo** de `min_reranker_score` (padrão `0.10`) é eliminado dos resultados (final_score definido como 0.0). Isso dá ao reranker poder de veto sobre fatos completamente irrelevantes - mesmo que o score da fórmula seja alto (ex: graph BFS dá 0.80 pra um fato distante e não relacionado). Quando `enable_reranker=False`, esta configuração não tem efeito. Ajuste: `config_overrides={"min_reranker_score": 0.05}` para resultados mais permissivos, `0.20` para filtragem mais rigorosa.

!!! info "Scoring por multiplicative blend"
    O reranker NÃO substitui o score da fórmula. Ele usa um **blend multiplicativo**:

    `final_score = formula_score × (floor + reranker_weight × reranker_score)`

    onde `floor = 1 - reranker_weight`. Com o default `reranker_weight=0.70`, um fato com formula=0.9 e reranker=0.0 fica com final = 0.9 × (0.30 + 0) = 0.27 (não 0.0). Um fato com formula=0.9 e reranker=1.0 fica com final = 0.9 × (0.30 + 0.70) = 0.90. O reranker pode amplificar ou atenuar fatos mas **não consegue zerar** um fato com bons sinais de retrieval apenas pelo blend. Porém, `min_reranker_score` É uma exceção - fatos com score abaixo dele são zerados independentemente do score da fórmula. O dict `scores` preserva tanto `formula` (pré-reranker) quanto `reranker` (score do LLM) pra debugging.

??? example "Passo a passo: como o blend do reranker funciona"
    **Query:** "Qual o time de futebol do Bruno Almeida?"

    **Candidatos pré-reranker (scores da fórmula):**
    ```
    1. "Bruno Almeida runs marathons" → formula = 0.45 (semântico: similaridade com "sports")
    2. "Bruno Almeida developed an ML model" → formula = 0.38
    3. "Bruno Almeida works at Orion Tech" → formula = 0.35
    ```

    **Scores do reranker (avaliação do LLM):**
    ```
    1. "Bruno Almeida runs marathons" → reranker = 0.0 (maratona ≠ futebol)
    2. "Bruno Almeida developed an ML model" → reranker = 0.0 (irrelevante)
    3. "Bruno Almeida works at Orion Tech" → reranker = 0.0 (irrelevante)
    ```

    **Blend multiplicativo** (weight=0.70, floor=0.30):
    ```
    1. final = 0.45 × (0.30 + 0.70 × 0.0) = 0.45 × 0.30 = 0.135 → filtrado (< 0.15)
    2. final = 0.38 × 0.30 = 0.114 → filtrado
    3. final = 0.35 × 0.30 = 0.105 → filtrado
    ```

    **Resultado:** 0 fatos retornados. Correto - não existe informação sobre o time de futebol do Bruno na memória.

    **Compare com uma query relevante** - "O que o Bruno Almeida desenvolveu?":
    ```
    "Bruno developed an ML model for fraud detection" → formula=0.92, reranker=1.0
    final = 0.92 × (0.30 + 0.70 × 1.0) = 0.92 × 1.0 = 0.92 ✅
    ```

---

## Estágio 5: Formatação

**Em português claro:** O pipeline pega os fatos ranqueados e organiza numa string pronta pra usar no prompt do seu LLM. Os fatos mais importantes vão primeiro (CORE MEMORY), fatos de suporte depois (EXTENDED CONTEXT), e histórico por último (RELEVANT_EVENTS) - tudo dentro de um orçamento de tokens pra não estourar seu prompt.

### Compressão de Contexto

Fatos são divididos em três tiers dentro de um orçamento de tokens (`context_max_tokens`):

!!! note "`context_max_tokens` é um orçamento proporcional, não um limite rígido"
    O parâmetro `context_max_tokens` controla o tamanho **relativo** do contexto de saída, mas a contagem real de tokens pode exceder o valor configurado. O pipeline garante um contexto mínimo para fatos core e usa o parâmetro como orçamento proporcional entre tiers. Trate como um target, não um limite estrito. Por exemplo, configurar `context_max_tokens=100` pode produzir ~240 tokens devido às garantias mínimas do hot tier.

| Tier | Config Key | Label no Output | Parcela | Conteúdo |
|------|-----------|----------------|---------|----------|
| **Tier 0** | -- | `ENTITY PROFILES` | Pre-orcamento | Perfis de entidade (~100-300 tokens cada). Injetados antes do hot tier quando entidades relevantes possuem `profile_text` |
| **Hot** | `hot_tier_ratio` | `CORE MEMORY` | 50% | Fatos mais relevantes (scores mais altos) |
| **Warm** | `warm_tier_ratio` | `EXTENDED CONTEXT` | 30% | Contexto de suporte |
| **Cold** | (restante) | `RELEVANT_EVENTS` | 20% | Fatos de background e historico de eventos |

#### Tier 0: Perfis de Entidade

Quando entidades relevantes a query possuem perfis (`profile_text`), esses perfis sao injetados como **Tier 0** -- antes do hot tier, sob a secao "ENTITY PROFILES" no contexto formatado. Perfis fornecem um resumo consolidado de cada entidade (~100-300 tokens), dando ao LLM uma visao de alto nivel antes dos fatos individuais.

```
## ENTITY PROFILES
- **Carlos Mendes**: Software engineer at Acme Corp. Lives in Sao Paulo with wife Ana. Enjoys cycling and photography.
- **Ana Mendes**: Architect, married to Carlos. Works at Studio Verde.

## CORE MEMORY
- Carlos Mendes recently started learning Rust (confidence: 0.95)
- ...
```

Perfis sao gerados e atualizados pelo write pipeline durante a extracao informada (veja [Write Pipeline - Perfis de Entidade](write-pipeline.md#perfis-de-entidade-no-write-pipeline)). Se nenhuma entidade relevante tiver perfil, o Tier 0 e simplesmente omitido e o comportamento e identico ao anterior.

### Configuração

| Parâmetro | Default | Descrição |
|-----------|---------|-----------|
| `context_max_tokens` | `2000` | Máximo de tokens no contexto formatado |
| `hot_tier_ratio` | `0.50` | Parcela do orçamento para fatos top |
| `warm_tier_ratio` | `0.30` | Parcela do orçamento para fatos de suporte |

### Formato de Output

A string `context` é formatada para injeção direta em prompts LLM:

```
## Known facts about the user:
- Lives in São Paulo (confidence: 0.95)
- Works at Acme Corp as a backend engineer (confidence: 0.90)
- Wife's name is Ana (confidence: 0.92)
```

---

## RetrieveResult

```python
result = await memory.retrieve(agent_id="user_123", query="...")

# Contexto pré-formatado (pronto para prompts LLM)
print(result.context)

# Fatos individuais com scores
for fact in result.facts:
    print(f"[{fact.score:.2f}] {fact.entity_name}: {fact.fact_text}")
    print(f"  Scores: {fact.scores}")  # {"semantic": 0.85, "recency": 0.72, ...}

# Stats do pipeline
print(f"Candidates evaluated: {result.total_candidates}")
print(f"Duration: {result.duration_ms:.0f}ms")
```

---

## Diagrama do Pipeline (Completo)

```mermaid
flowchart TD
    Q["User query"] --> AG["Retrieval Agent\n(LLM planner)"]
    AG -->|skip| SKIP["Return empty\n(greeting/casual)"]
    AG -->|multi_signal| PAR["Parallel retrieval"]
    PAR --> SEM["Semantic Search\n(pgvector cosine)"]
    PAR --> KW["Keyword Search\n(SQL ILIKE)"]
    PAR --> GR["Graph Traversal\n(BFS 2-hop)"]
    SEM --> MERGE["Merge & Rank\n(dedup + weighted scoring)"]
    KW --> MERGE
    GR --> MERGE
    MERGE --> SA["Spreading Activation\n(expand context along edges)"]
    SA --> RR{"Reranker\nenabled?"}
    RR -->|yes| RERANK["LLM Rerank"]
    RR -->|no| FMT["Format & Compress"]
    RERANK --> FMT
    FMT --> RES["RetrieveResult"]
```

!!! info "Paralelo com neurociência"
    A compressão em tiers (hot/warm/cold) espelha **níveis de ativação** na working memory. No modelo de processos embutidos de Cowan, um número pequeno de itens está no foco de atenção (hot tier), cercado por memória de longo prazo ativada (warm tier), com o restante da memória de longo prazo disponível mas não ativa (cold tier). O orçamento de tokens age como o limite de capacidade da working memory.
