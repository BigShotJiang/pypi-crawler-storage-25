# casatoo-cli

Public Casatoo CLI.

Install:

```sh
uvx casatoo --help
pipx install casatoo
```

Initial commands:

```sh
casatoo auth login
casatoo auth status
casatoo auth logout
casatoo me
casatoo me --json
```

## Token storage

The CLI stores OAuth tokens in `$XDG_STATE_HOME/casatoo/token.json`, or
`~/.local/state/casatoo/token.json` when `XDG_STATE_HOME` is unset. The token
file is written with mode `0600` on Unix-like systems.

`casatoo auth logout` revokes the stored refresh token before deleting local
state. Treat the token file as sensitive while logged in.
