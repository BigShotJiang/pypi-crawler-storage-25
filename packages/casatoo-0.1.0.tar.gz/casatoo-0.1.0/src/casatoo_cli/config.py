from __future__ import annotations

import json
import os
from dataclasses import dataclass
from pathlib import Path
from typing import Any


APP_NAME = 'casatoo'
DEFAULT_API_BASE_URL = 'https://api.casatoo.pt/api/v1'
DEFAULT_OAUTH_ISSUER = 'https://oauth.casatoo.pt'
DEFAULT_OAUTH_RESOURCE = 'https://api.casatoo.pt/mcp'


@dataclass(frozen=True)
class CliConfig:
    api_base_url: str
    oauth_issuer: str
    oauth_resource: str
    state_dir: Path
    token_path: Path


def _xdg_dir(env_name: str, default_suffix: str) -> Path:
    value = os.getenv(env_name)
    if value:
        return Path(value)
    return Path.home() / default_suffix


def load_cli_config() -> CliConfig:
    state_dir = _xdg_dir('XDG_STATE_HOME', '.local/state') / APP_NAME
    return CliConfig(
        api_base_url=os.getenv('CASATOO_API_BASE_URL', DEFAULT_API_BASE_URL).rstrip('/'),
        oauth_issuer=os.getenv('CASATOO_OAUTH_ISSUER', DEFAULT_OAUTH_ISSUER).rstrip('/'),
        oauth_resource=os.getenv(
            'CASATOO_OAUTH_RESOURCE', DEFAULT_OAUTH_RESOURCE
        ).rstrip('/'),
        state_dir=state_dir,
        token_path=state_dir / 'token.json',
    )


def read_token(config: CliConfig) -> dict[str, Any] | None:
    try:
        with config.token_path.open() as f:
            data = json.load(f)
    except FileNotFoundError:
        return None
    if not isinstance(data, dict):
        return None
    return data


def write_token(config: CliConfig, token: dict[str, Any]) -> None:
    config.state_dir.mkdir(parents=True, exist_ok=True)
    tmp_path = config.token_path.with_suffix('.tmp')
    with tmp_path.open('w') as f:
        json.dump(token, f, indent=2, sort_keys=True)
        f.write('\n')
    tmp_path.chmod(0o600)
    tmp_path.replace(config.token_path)


def delete_token(config: CliConfig) -> bool:
    try:
        config.token_path.unlink()
        return True
    except FileNotFoundError:
        return False
