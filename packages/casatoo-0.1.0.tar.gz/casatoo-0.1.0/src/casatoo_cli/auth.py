from __future__ import annotations

import base64
import hashlib
import http.server
import json
import secrets
import time
import urllib.parse
import webbrowser
from dataclasses import dataclass
from typing import Any

import httpx

from casatoo_cli.config import CliConfig
from casatoo_cli.config import read_token
from casatoo_cli.config import write_token


OAUTH_SCOPE = 'casatoo:read offline_access'
LOGIN_TIMEOUT_SECONDS = 300


class AuthError(RuntimeError):
    pass


@dataclass(frozen=True)
class OAuthMetadata:
    authorization_endpoint: str
    token_endpoint: str
    registration_endpoint: str
    revocation_endpoint: str | None = None


class CallbackHandler(http.server.BaseHTTPRequestHandler):
    server: CallbackServer

    def do_GET(self) -> None:
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)
        is_expected_path = parsed.path == '/callback'
        has_terminal_param = 'code' in params or 'error' in params
        if is_expected_path and has_terminal_param:
            self.server.callback_params = params
        status = 200 if is_expected_path and has_terminal_param else 400
        self.send_response(status)
        self.send_header('Content-Type', 'text/plain; charset=utf-8')
        self.end_headers()
        if status == 200:
            self.wfile.write(b'Casatoo CLI login complete. You can close this tab.\n')
        else:
            self.wfile.write(b'Casatoo CLI login failed. Return to your terminal.\n')

    def log_message(self, format: str, *args: Any) -> None:
        return None


class CallbackServer(http.server.HTTPServer):
    callback_params: dict[str, list[str]]

    def __init__(self) -> None:
        super().__init__(('127.0.0.1', 0), CallbackHandler)
        self.callback_params = {}


def _pkce_pair() -> tuple[str, str]:
    verifier = secrets.token_urlsafe(64)
    digest = hashlib.sha256(verifier.encode()).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b'=').decode()
    return verifier, challenge


def _discovery_url(config: CliConfig) -> str:
    return f'{config.oauth_issuer}/.well-known/openid-configuration'


def discover(config: CliConfig) -> OAuthMetadata:
    try:
        response = httpx.get(_discovery_url(config), timeout=10.0)
        response.raise_for_status()
        payload = response.json()
    except (httpx.HTTPError, json.JSONDecodeError, KeyError) as e:
        raise AuthError(f'OAuth discovery failed: {e}') from e
    registration_endpoint = payload.get('registration_endpoint')
    if not isinstance(registration_endpoint, str) or not registration_endpoint:
        registration_endpoint = f'{config.oauth_issuer}/oauth2/register'
    revocation_endpoint = payload.get('revocation_endpoint')
    return OAuthMetadata(
        authorization_endpoint=str(payload['authorization_endpoint']),
        token_endpoint=str(payload['token_endpoint']),
        registration_endpoint=registration_endpoint,
        revocation_endpoint=(
            revocation_endpoint if isinstance(revocation_endpoint, str) else None
        ),
    )


def register_client(
    metadata: OAuthMetadata, redirect_uri: str, resource: str
) -> str:
    payload = {
        'client_name': 'Casatoo CLI',
        'redirect_uris': [redirect_uri],
        'grant_types': ['authorization_code', 'refresh_token'],
        'response_types': ['code'],
        'scope': 'casatoo:read openid offline offline_access',
        'audience': [resource],
        'token_endpoint_auth_method': 'none',
    }
    try:
        response = httpx.post(
            metadata.registration_endpoint,
            json=payload,
            timeout=10.0,
        )
        response.raise_for_status()
        response_payload = response.json()
    except (httpx.HTTPError, json.JSONDecodeError) as e:
        raise AuthError(f'OAuth client registration failed: {e}') from e
    client_id = response_payload.get('client_id')
    if not isinstance(client_id, str) or not client_id:
        raise AuthError('OAuth registration did not return client_id')
    return client_id


def login(config: CliConfig) -> dict[str, Any]:
    metadata = discover(config)
    callback_server = CallbackServer()
    redirect_uri = f'http://127.0.0.1:{callback_server.server_port}/callback'
    client_id = register_client(metadata, redirect_uri, config.oauth_resource)
    verifier, challenge = _pkce_pair()
    state = secrets.token_urlsafe(32)
    auth_params = {
        'response_type': 'code',
        'client_id': client_id,
        'redirect_uri': redirect_uri,
        'scope': OAUTH_SCOPE,
        'state': state,
        'code_challenge': challenge,
        'code_challenge_method': 'S256',
        'audience': config.oauth_resource,
    }
    auth_url = (
        f'{metadata.authorization_endpoint}?'
        f'{urllib.parse.urlencode(auth_params)}'
    )
    print(f'Open this URL to log in:\n{auth_url}\n')
    webbrowser.open(auth_url)
    try:
        params = _wait_for_callback(callback_server, state, LOGIN_TIMEOUT_SECONDS)
    finally:
        callback_server.server_close()
    if params.get('state', [''])[0] != state:
        raise AuthError('OAuth callback state mismatch')
    if error := params.get('error', [''])[0]:
        description = params.get('error_description', [''])[0]
        raise AuthError(f'OAuth login failed: {error} {description}'.strip())
    code = params.get('code', [''])[0]
    if not code:
        raise AuthError('OAuth callback did not include code')

    token = _exchange_code(
        metadata=metadata,
        client_id=client_id,
        redirect_uri=redirect_uri,
        code=code,
        verifier=verifier,
    )
    token['client_id'] = client_id
    token['oauth_issuer'] = config.oauth_issuer
    write_token(config, token)
    return token


def _exchange_code(
    *,
    metadata: OAuthMetadata,
    client_id: str,
    redirect_uri: str,
    code: str,
    verifier: str,
) -> dict[str, Any]:
    try:
        response = httpx.post(
            metadata.token_endpoint,
            data={
                'grant_type': 'authorization_code',
                'client_id': client_id,
                'redirect_uri': redirect_uri,
                'code': code,
                'code_verifier': verifier,
            },
            timeout=10.0,
        )
        response.raise_for_status()
        return _with_expiry(response.json())
    except (httpx.HTTPError, json.JSONDecodeError) as e:
        raise AuthError(f'OAuth token exchange failed: {e}') from e


def _wait_for_callback(
    callback_server: CallbackServer,
    state: str,
    timeout_seconds: float,
) -> dict[str, list[str]]:
    deadline = time.monotonic() + timeout_seconds
    while time.monotonic() < deadline:
        callback_server.timeout = min(1.0, max(0.0, deadline - time.monotonic()))
        callback_server.handle_request()
        params = callback_server.callback_params
        if not params:
            continue
        if params.get('state', [''])[0] == state:
            return params
        callback_server.callback_params = {}
    raise AuthError('OAuth login timed out')


def _with_expiry(token: dict[str, Any]) -> dict[str, Any]:
    expires_in = token.get('expires_in')
    if isinstance(expires_in, int):
        token['expires_at'] = int(time.time()) + expires_in
    return token


def refresh(config: CliConfig, token: dict[str, Any]) -> dict[str, Any]:
    refresh_token = token.get('refresh_token')
    client_id = token.get('client_id')
    if not isinstance(refresh_token, str) or not isinstance(client_id, str):
        raise AuthError('No refresh token available; run casatoo auth login')
    metadata = discover(config)
    try:
        response = httpx.post(
            metadata.token_endpoint,
            data={
                'grant_type': 'refresh_token',
                'client_id': client_id,
                'refresh_token': refresh_token,
            },
            timeout=10.0,
        )
        response.raise_for_status()
        refreshed = _with_expiry(response.json())
    except (httpx.HTTPError, json.JSONDecodeError) as e:
        raise AuthError(f'OAuth token refresh failed: {e}') from e
    if 'refresh_token' not in refreshed:
        refreshed['refresh_token'] = refresh_token
    refreshed['client_id'] = client_id
    refreshed['oauth_issuer'] = config.oauth_issuer
    write_token(config, refreshed)
    return refreshed


def revoke(config: CliConfig, token: dict[str, Any]) -> None:
    refresh_token = token.get('refresh_token')
    client_id = token.get('client_id')
    if not isinstance(refresh_token, str) or not refresh_token:
        return
    if not isinstance(client_id, str) or not client_id:
        raise AuthError('Stored token has no client_id; cannot revoke refresh token')
    metadata = discover(config)
    revocation_endpoint = metadata.revocation_endpoint
    if revocation_endpoint is None:
        revocation_endpoint = f'{config.oauth_issuer}/oauth2/revoke'
    try:
        response = httpx.post(
            revocation_endpoint,
            data={
                'token': refresh_token,
                'token_type_hint': 'refresh_token',
                'client_id': client_id,
            },
            timeout=10.0,
        )
        response.raise_for_status()
    except httpx.HTTPError as e:
        raise AuthError(f'OAuth token revocation failed: {e}') from e


def get_access_token(config: CliConfig) -> str:
    token = read_token(config)
    if token is None:
        raise AuthError('Not logged in. Run casatoo auth login.')
    expires_at = token.get('expires_at')
    if isinstance(expires_at, int) and expires_at <= int(time.time()) + 30:
        token = refresh(config, token)
    access_token = token.get('access_token')
    if not isinstance(access_token, str) or not access_token:
        raise AuthError('Stored token has no access_token. Run casatoo auth login.')
    return access_token
