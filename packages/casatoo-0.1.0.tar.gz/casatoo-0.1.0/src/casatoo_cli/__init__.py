"""Casatoo public CLI."""
