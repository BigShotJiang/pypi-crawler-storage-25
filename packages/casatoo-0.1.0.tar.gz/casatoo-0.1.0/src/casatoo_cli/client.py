from __future__ import annotations

from typing import Any

import httpx

from casatoo_cli.auth import get_access_token
from casatoo_cli.auth import refresh
from casatoo_cli.config import CliConfig
from casatoo_cli.config import read_token


class ApiError(RuntimeError):
    pass


def get_me(config: CliConfig) -> dict[str, Any]:
    return _get_with_auth(config, '/auth/me')


def _get_with_auth(config: CliConfig, path: str) -> dict[str, Any]:
    token = get_access_token(config)
    response = httpx.get(
        f'{config.api_base_url}{path}',
        headers={'Authorization': f'Bearer {token}'},
        timeout=10.0,
    )
    if response.status_code == 401:
        stored = read_token(config)
        if stored is not None:
            token = refresh(config, stored).get('access_token', '')
            response = httpx.get(
                f'{config.api_base_url}{path}',
                headers={'Authorization': f'Bearer {token}'},
                timeout=10.0,
            )
    if response.status_code >= 400:
        raise ApiError(f'API request failed: HTTP {response.status_code} {response.text}')
    data = response.json()
    if not isinstance(data, dict):
        raise ApiError('API response was not an object')
    return data
