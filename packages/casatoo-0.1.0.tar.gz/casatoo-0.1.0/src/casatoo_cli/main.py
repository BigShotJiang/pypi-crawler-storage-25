from __future__ import annotations

import argparse
import json
import sys

from casatoo_cli.auth import AuthError
from casatoo_cli.auth import login
from casatoo_cli.auth import revoke
from casatoo_cli.client import ApiError
from casatoo_cli.client import get_me
from casatoo_cli.config import delete_token
from casatoo_cli.config import CliConfig
from casatoo_cli.config import load_cli_config
from casatoo_cli.config import read_token


def main() -> int:
    parser = _build_parser()
    args = parser.parse_args()
    config = load_cli_config()
    try:
        if args.command == 'auth':
            return _handle_auth(config, args)
        if args.command == 'me':
            return _handle_me(config, args)
        parser.print_help()
        return 1
    except (AuthError, ApiError) as exc:
        print(f'error: {exc}', file=sys.stderr)
        return 1


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog='casatoo')
    subparsers = parser.add_subparsers(dest='command')

    auth = subparsers.add_parser('auth')
    auth_subparsers = auth.add_subparsers(dest='auth_command')
    auth_subparsers.add_parser('login')
    auth_subparsers.add_parser('status')
    auth_subparsers.add_parser('logout')

    me = subparsers.add_parser('me')
    me.add_argument('--json', action='store_true')
    return parser


def _handle_auth(config: CliConfig, args: argparse.Namespace) -> int:
    if args.auth_command == 'login':
        token = login(config)
        scope = token.get('scope', '')
        print(f'Logged in. Scope: {scope}')
        return 0
    if args.auth_command == 'status':
        stored_token = read_token(config)
        if stored_token is None:
            print('Not logged in')
            return 1
        print(f'Logged in. Token file: {config.token_path}')
        return 0
    if args.auth_command == 'logout':
        stored_token = read_token(config)
        if stored_token is not None:
            revoke(config, stored_token)
        removed = delete_token(config)
        print('Logged out' if removed else 'Not logged in')
        return 0
    print('Unknown auth command', file=sys.stderr)
    return 1


def _handle_me(config: CliConfig, args: argparse.Namespace) -> int:
    data = get_me(config)
    if args.json:
        print(json.dumps(data, indent=2, sort_keys=True))
        return 0
    print(f"Logged in as {data['email']}")
    print(f"Saved searches: {data.get('saved_search_count', 0)}")
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
