"""Caesar Synthesizer - Logic for synthesizing exploration artifacts"""
import json
import os
import re
from datetime import datetime
from typing import Dict, List, Optional, Tuple

from llama_index.core.vector_stores import MetadataFilters, MetadataFilter, FilterOperator

from rome.config import set_attributes_from_config
from rome.llm_handler import FatalLLMError
from rome.logger import get_logger
from .caesar_config import (CAESAR_CONFIG, MAX_SYNTHESIS_QUERY_SOURCES,
    MAX_SYNTHESIS_QA_CONTEXT, NUM_SYNTHESIS_RETRIES, SYNTHESIS_SAVE_JSON)


class ArtifactSynthesizer:
    """Handles the synthesis of insights into final artifacts"""

    def __init__(self, agent, config: Dict = None):
        self.agent = agent
        self.logger = get_logger()

        # Load settings from config or defaults
        self.config = config or {}
        # We allow attributes to be set on 'self' from the config provided
        set_attributes_from_config(self, self.config, CAESAR_CONFIG['ArtifactSynthesizer'].keys())

        # Shortcuts to KB resources
        self.kb_manager = self.agent.kb_manager; self.filters = None

        # Tracks files written by _save_synthesis during the most recent
        # synthesize_artifact() call (reset at the start of each call)
        self.saved_artifact_files = []

        # Setup maximum of iterations to filter for when querying
        if self.synthesis_iteration_filter:
            self.logger.assert_true(
                isinstance(self.synthesis_iteration_filter, int) and self.synthesis_iteration_filter > 0,
                "synthesis_iteration_filter must be an non-negative integer")
            self.filters = MetadataFilters(
                filters=[MetadataFilter(
                    key="iteration",
                    value=self.synthesis_iteration_filter,
                    operator=FilterOperator.LT)]
                )

    # ── Shared helpers ────────────────────────────────────────────────────

    def _llm_call(self, prompt: str, required_keys: List[str],
                  retries: int = NUM_SYNTHESIS_RETRIES,
                  reasoning: str = None, label: str = "LLM") -> Optional[Dict]:
        """LLM call with JSON parsing, key validation, and retries."""
        # Ensure prompt mentions JSON (required by OpenAI for json_object response format)
        if "json" not in prompt.lower():
            prompt = f"{prompt}\n\nRespond in JSON format."
        override = {"reasoning_effort": reasoning} if reasoning else {}
        for attempt in range(1, retries + 1):
            try:
                response = self.agent.chat_completion(prompt,
                    override_config=override,
                    response_format={"type": "json_object"})
                result = self.agent.parse_json_response(response)
                if not result:
                    raise ValueError("parse_json_response returned None/empty")
                missing = [k for k in required_keys if k not in result]
                if missing:
                    raise ValueError(f"Missing required keys: {missing}")
                return result
            except FatalLLMError:
                raise  # don't waste retries on auth/quota errors
            except Exception as e:
                self.logger.error(f"[{label}] Attempt {attempt}/{retries} failed: {e}")
        self.logger.error(f"[{label}] All attempts exhausted")
        return None

    @staticmethod
    def _format_source_list(sources: Dict[str, int]) -> str:
        """Format a {url: idx} dict as a sorted '[idx] url' string."""
        return "\n".join(f"[{idx}] {url}"
            for url, idx in sorted(sources.items(), key=lambda x: x[1]))

    def _load_reference_draft(self, path: str) -> Optional[str]:
        """Load text content from a reference answer file.

        Accepts either Caesar's saved synthesis JSON (extracts the "artifact"
        field) or a plain text file (returned as-is). Returns None on failure.
        """
        if not os.path.exists(path):
            self.logger.error(f"[SYNTHESIS] Reference draft path not found: {path}")
            return None
        try:
            with open(path, "r", encoding="utf-8") as f:
                content = f.read()
        except OSError as e:
            self.logger.error(f"[SYNTHESIS] Failed to read reference draft {path}: {e}")
            return None
        try:
            data = json.loads(content)
            if isinstance(data, dict) and isinstance(data.get("artifact"), str) and data["artifact"].strip():
                return data["artifact"]
        except (json.JSONDecodeError, ValueError):
            pass
        content = content.strip()
        return content or None

    def _get_artifact_text(self, result: Dict) -> Optional[str]:
        """Extract artifact text with abstract prepended, or None if empty."""
        artifact_text = result.get("artifact", "")
        if not artifact_text:
            self.logger.error("[POST-PROCESS] No artifact text to process")
            return None
        abstract_text = result.get("abstract", "")
        if abstract_text:
            artifact_text = f"Artifact Abstract:\n{abstract_text}\n\nArtifact Text:\n{artifact_text}"
        return artifact_text

    def _get_query_context(self) -> Tuple[str, str, str]:
        """Return (query_context, query_role, length_context) strings used in prompts."""
        q = self.agent.starting_query
        query_context = f" that creatively answers this query: {q}" if q else ""
        query_role = f" to the query creatively!" if q else "!"
        return query_context, query_role

    def _post_process(self, result: Dict, prompt: str, response_key: str,
                      label: str, base_dir: str = None, suffix: str = "post",
                      timestamp: str = None) -> Optional[Dict]:
        """Shared post-process: LLM call → wrap as artifact → save."""
        llm_result = self._llm_call(prompt, [response_key],
            reasoning="high", label=label)
        if not llm_result:
            return None
        processed = {
            "artifact": llm_result[response_key],
            "metadata": result.get("metadata", {}),
        }
        self._save_synthesis(processed, base_dir=base_dir,
            suffix=suffix, timestamp=timestamp)
        return processed

    # ── Main synthesis entry point ────────────────────────────────────────

    def synthesize_artifact(self, num_drafts: int = None) -> None:
        """Generate final synthesis with optional multi-draft refinement.

        Returns the final result dict. In addition to the synthesis fields
        (abstract/artifact/sources/metadata), the dict includes:
          - artifact_dir: directory where synthesis files were written
          - artifact_files: list of full paths written during this call
          - num_drafts: how many drafts were produced
        """
        if not num_drafts: num_drafts = self.synthesis_drafts
        num_drafts = max(num_drafts, 1)

        # Reset per-call tracking of files written by _save_synthesis
        self.saved_artifact_files = []

        mode = f"iterative (n={self.synthesis_iterations})" if not self.synthesis_classic_mode else "classic"
        self.logger.info(f"[SYNTHESIS] Using {mode} mode with {num_drafts} draft(s)")

        if self.kb_manager.size() == 0:
            return {"abstract": "", "artifact": "No insights collected during exploration.",
                    "artifact_dir": None, "artifact_files": [], "num_drafts": 0}

        # Multi-draft synthesis loop
        current_query = self.agent.starting_query
        all_drafts = []; previous_result = None; base_dir = None
        if num_drafts > 1:
            base_dir = os.path.join(self.agent.get_repo(),
                f"{self.agent.get_id()}.synthesis.{datetime.now().strftime("%m%d%H%M")}")
        artifact_dir = base_dir if base_dir else self.agent.get_repo()

        # Optional: seed draft 1 with an external reference answer.
        if self.synthesis_reference_draft:
            ref_text = self._load_reference_draft(self.synthesis_reference_draft)
            if ref_text:
                self.logger.info(
                    f"[SYNTHESIS] Conditioning draft 1 on reference: "
                    f"{self.synthesis_reference_draft} ({len(ref_text)} chars)")
                previous_result = {"artifact": ref_text}

        self._num_drafts = num_drafts
        for draft_num in range(1, num_drafts + 1):
            self._current_draft = draft_num
            self.logger.info(f"\n{'='*80}\n[SYNTHESIS DRAFT {draft_num}/{num_drafts}]\n{'='*80}")
            if current_query: self.logger.info(f"Current query: {current_query}")

            # Generate synthesis for current draft (with previous artifact context)
            result = self._synthesize_single_draft(mode, current_query, previous_result)
            if not result: break
            self._save_synthesis(result, base_dir=base_dir, suffix=f'synthesis-{draft_num}')
            self._post_process_eli5(result, base_dir=base_dir, suffix=f'synth-eli5-{draft_num}')
            self._post_process_human_eval(
                result, base_dir=base_dir, suffix=f'synth-human-eval-{draft_num}')
            all_drafts.append(result); previous_result = result

            # Refine query for next draft (if not last draft)
            if draft_num < num_drafts:
                current_query = self._refine_query(result)
                if not current_query: break

        if len(all_drafts) < 1:
            raise ValueError("No synthesis artifacts created!")
        elif len(all_drafts) < num_drafts:
            self.logger.error(f"Artifact synthesis ended early at draft: {len(all_drafts)}/{num_drafts}")

        # Merge artifacts if requested and multiple drafts exist
        final = None
        if self.synthesis_merge_artifacts and len(all_drafts) > 1:
            self.logger.info(f"\n{'='*80}\n[MERGING {len(all_drafts)} ARTIFACTS]\n{'='*80}")
            merged_result = self._merge_artifacts(all_drafts, base_dir=base_dir)
            if merged_result:
                self._save_synthesis(merged_result, base_dir=base_dir, suffix=f'merged-{len(all_drafts)}')
                self._post_process_eli5(merged_result, base_dir, suffix=f'merged-eli5-{len(all_drafts)}')
                self._post_process_human_eval(
                    merged_result, base_dir, suffix=f'merged-human-eval-{len(all_drafts)}')
                final = merged_result
        if final is None:
            final = all_drafts[-1]
        final["artifact_dir"] = artifact_dir
        final["artifact_files"] = list(self.saved_artifact_files)
        final["num_drafts"] = len(all_drafts)
        return final

    # ── Single draft synthesis ────────────────────────────────────────────

    def _synthesize_single_draft(self, mode: str, current_query: Optional[str] = None,
                                 previous_artifact: Optional[Dict] = None) -> Dict[str, str]:
        """Execute a single synthesis draft with optional query and previous artifact"""
        self.logger.info("[SYNTHESIS] Generating synthesis artifact")

        qa_pairs = self._generate_qa_pairs(mode, current_query)
        if not qa_pairs:
            self.logger.error("[SYNTHESIS] Unable to generate Q/A pairs for artifact")
            return None
        qa_list, source_list, source_map = self._build_answers_with_citations(qa_pairs)

        query_context, query_role = self._get_query_context()
        length_context = f" ({self.synthesis_max_length} words)" if self.synthesis_max_length else ""


        # Build context from previous artifact if available
        previous_context = ""
        if previous_artifact and previous_artifact.get("artifact"):
            previous_context = f"""
PREVIOUS ARTIFACT:
{previous_artifact["artifact"]}
--- END OF ARTIFACT ---
"""

        prompt = f"""You explored {len(self.agent.visited_urls)} sources and gathered {self.kb_manager.size()} insights.

KEY INSIGHTS (with source citations):
{qa_list}
--- END OF INSIGHTS ---

SOURCES:
{source_list}
--- END OF SOURCES ---
{previous_context}
YOUR TASK:
Drawing heavily upon the patterns that emerged from the key insights{', and building upon the previous artifact,' if previous_artifact else ''} create a novel, exciting, and thought provoking artifact{query_context}

1. **Artifact Abstract** (80-120 words):
    - Summary of the artifact's core discovery and its significance

2. **Artifact Main Text**{length_context}:
    - IMPORTANT: Carefully analyze every relevant key insight to generate a comprehensive and detailed response
    - General guidelines for response:
        a. Emergent patterns not visible in individual insights
        b. Novel discoveries, connections, or applications
        c. Surprising new directions or perspectives
        d. Interesting tensions, contradictions, or open questions
    - Cite from "SOURCES" using [n] notation to support relevant claims and statements (e.g., "This pattern emerged... [1,3]") with up to {MAX_SYNTHESIS_QUERY_SOURCES} citations per claim, but do NOT create a "SOURCES" or "References" section
    {'- Build upon the previous artifact by analyzing it for weaknesses in organization, arguments, or content, and then use key insights to deepen, improve, and extend the previous artifact' if previous_artifact else ''}

{'IMPORTANT: do NOT mention or reference the previous artifact, the new artifact should make sense by itself as a standalone text' if previous_artifact else ''}
IMPORTANT: AVOID excessive jargon, ensure artifact text is well-organized (logical, clear, focused), and convincing to a skeptical reader
IMPORTANT: Use your role as a guide on how to respond {query_role}

Respond with valid JSON only:
{{
    "abstract": "<abstract text>",
    "artifact": "<artifact text>"
}}"""
        result = self._llm_call(prompt, ["abstract", "artifact"],
            reasoning="high", label="SYNTHESIS")
        if not result: return None

        result["sources"] = dict(sorted(source_map.items(), key=lambda x: x[1]))
        result["metadata"] = {
            "insights_collected": self.kb_manager.size(),
            "pages_visited": len(self.agent.visited_urls),
            "sources_cited": len(source_map),
            "starting_url": self.agent.starting_url,
            "starting_query": self.agent.starting_query,
            "synthesis_drafts": self.synthesis_drafts,
            "synthesis_eli5_length": self.synthesis_eli5_length,
            "synthesis_iteration_filter": self.synthesis_iteration_filter,
            "synthesis_max_length": self.synthesis_max_length,
            "synthesis_mode": mode,
            "synthesis_queries": len(qa_pairs),
        }

        return result

    # ── Query refinement ──────────────────────────────────────────────────

    def _refine_query(self, artifact_result: Dict, current_query: Optional[str] = None) -> Optional[str]:
        """Refine the synthesis query based on previous artifact"""

        artifact_text = artifact_result.get("artifact", "")
        if not artifact_text:
            self.logger.error("[REFINE] Cannot refine query: no artifact text")
            return None

        if not current_query: current_query = self.agent.starting_query
        query_context = f"PREVIOUS QUERY: {current_query}\n\n" if current_query else ""

        prompt = f"""{query_context}PREVIOUS ARTIFACT:
{artifact_text}
--- END OF ARTIFACT ---

YOUR TASK:
Based on the previous query and artifact above, identify the most promising direction for deeper exploration. What NEW question or angle would:
    - Build on the insights already discovered
    - Explore gaps, contradictions, or unexplored connections
    - Lead to novel perspectives or applications
    - Go deeper rather than broader

The refined query should be concise (1-2 sentences), straightforward, clear, and understandable.

IMPORTANT: Use your role as a guide on how to respond!

Respond with JSON:
{{
    "refined_query": "<your refined exploration query, posed as a question>",
    "reason": "<brief explanation of why the refined query improves upon the previous query>"
}}"""

        result = self._llm_call(prompt, ["refined_query"], retries=1, label="REFINE")
        if result:
            self.logger.info(f"[REFINE] Query: {result['refined_query']}\nReason: {result.get('reason', 'No reason provided')}")
            return result["refined_query"]
        return None

    # ── Artifact merging ──────────────────────────────────────────────────
    # TODO: Ring merge of drafts (feed random draft sequence in connected ring of unique agents)
    # TODO: Debate merge of drafts (multiple of rounds of unique agents critiquing drafts)

    def _merge_artifacts(self, all_drafts: List[Dict],
                         base_dir: str = None) -> Optional[Dict[str, str]]:
        """Merge artifacts from all drafts into a single comprehensive artifact"""
        self.logger.info(f"[MERGE] Generating merged artifact")
        if len(all_drafts) == 0:
            self.logger.error("[MERGE] No artifacts to merge"); return None

        # Build context with per-draft sources (optimized string building)
        artifacts_context = []
        for i, r in enumerate(all_drafts, 1):
            source_list = self._format_source_list(r.get('sources', {}))
            artifacts_context.append(
                f"--- DRAFT {i} ---\n\n"
                f"ARTIFACT:\n{r['artifact']}\n\n"
                f"SOURCES (for citations in draft {i} artifact):\n{source_list}\n\n"
                f"--- END OF DRAFT {i} ---\n\n"
            )
        artifacts_text = "\n\n".join(artifacts_context)

        # Build context with per-draft sources as prettified JSON
        # artifacts_text = json.dumps([
        #     {
        #         "Draft": i,
        #         "Artifact": r['artifact'],
        #         "Sources": {idx: url for url, idx in sorted(
        #             r.get('sources', {}).items(), key=lambda x: x[1])}
        #     }
        #     for i, r in enumerate(all_drafts, 1)
        # ], indent=4, ensure_ascii=False)

        query_context, query_role = self._get_query_context()
        length_context1 = f"{self.synthesis_max_length} words" if self.synthesis_max_length else ">= average draft artifact length"
        length_context2 = f" ({self.synthesis_max_length} words)" if self.synthesis_max_length else ""

    # - Combines the draft artifacts into a single cohesive and complete artifact
    # - Selectively integrates the most interesting, relevant insights across all draft artifacts
    # - Discovers emergent patterns not visible in individual artifacts
    # - Further develops the core strengths while addressing the weaknesses of the draft artifacts
        prompt = f"""You are merging {len(all_drafts)} drafts of research artifacts into one unified artifact{query_context}

=== RESEARCH ARTIFACTS ===
{artifacts_text}
=== END OF RESEARCH ARTIFACTS ===

YOUR TASK:
Create a comprehensive merged artifact that:
    - Fuse the draft artifacts into one standalone work with a single clear narrative spine (not a stitched summary).
    - Curate and reinterpret the highest‑leverage insights across all drafts; cut redundancy while preserving essential caveats.
    - Derive new patterns/tensions across all drafts and at least one unifying framework that doesn't appear in any single artifact.
    - Strengthen and extend the result: tighten structure, resolve/reconcile contradictions, and push into implications, applications, and open questions (flag speculation explicitly).

MERGED ARTIFACT CITATIONS:
    - Each draft has its own [n] citations (Draft 1's [1] and Draft 2's [1] are DIFFERENT URLs)
    - In your merged artifact, create NEW sequential numbering: [1], [2], [3]...
    - Map each cited URL to its new number in the "sources" field
    - Use citations to support relevant claims and statements (up to {MAX_SYNTHESIS_QUERY_SOURCES} citations per claim), but do NOT create a "Sources" or "References" section

MERGED ARTIFACT TEXT:
    - IMPORTANT: Avoid excessive jargon, ensure artifact text is well-organized (logical, clear, focused), and convincing to a skeptical reader
    - Merged artifact length: {length_context1}
    - Do NOT mention "Draft 1", "Draft 2", etc, in text

RESPONSE INSTRUCTIONS:
    - IMPORTANT: Use your role as a guide on how to respond{query_role}
    - Your response must ONLY be valid JSON starting with {{ and ending with }}
    - Following 3 fields required: abstract, artifact, sources

EXAMPLE OUTPUT:
{{
    "abstract": "A 80-120 word summary of the artifact's core discovery and its significance",
    "artifact": "Full merged text{length_context2} with citations [1,2]...",
    "sources": {{"https://example.com": 1, "https://another.com": 2}}
}}
"""

        result = self._llm_call(prompt, ["abstract", "artifact"],
            reasoning="high", label="MERGE")
        if not result: return None

        # Normalize and validate sources
        sources = result.get("sources", {})
        if not isinstance(sources, dict):
            self.logger.error(f"[MERGE] Invalid sources type: {type(sources)}, using empty dict")
            result["sources"] = {}
        else:
            try:
                result["sources"] = {url: int(idx) for url, idx in sources.items()}
                result["sources"] = dict(sorted(result["sources"].items(), key=lambda x: x[1]))
            except (ValueError, TypeError, AttributeError) as e:
                self.logger.error(f"[MERGE] Error normalizing sources: {e}, using empty dict")
                result["sources"] = {}

        result["metadata"] = all_drafts[-1].get("metadata", {})

        # Clarity post-process: replace the merged abstract and artifact
        # with plain-language versions (clarified together so tone is
        # consistent). Sources dict is preserved unchanged.
        # _post_process_clarify is gated internally by
        # self.synthesis_merge_clarify; it returns None when disabled.
        clarified = self._post_process_clarify(result)
        if clarified and clarified.get("artifact"):
            result["artifact"] = clarified["artifact"]
            if clarified.get("abstract"):
                result["abstract"] = clarified["abstract"]

        return result

    # ── Q&A pair generation ───────────────────────────────────────────────

    def _generate_qa_pairs(self, mode: str, starting_query: str = None) -> List[Tuple[str, str, List[Dict]]]:
        """Generate Q&A pairs with sources"""
        queries = [
            "What are the central themes and patterns discovered?",
            "What unexpected connections or insights emerged?",
            "What contradictions or tensions were revealed?",
            "What questions remain open or were raised?",
            "What novel perspective emerged from this exploration?"
        ]
        if starting_query: queries = [starting_query] + queries
        if mode == "classic": return self._generate_qa_pairs_classic(queries)

        # Validate iterations
        # if not isinstance(self.synthesis_iterations, int) or self.synthesis_iterations < 1:
        #     self.logger.error(f"[SYNTHESIS] Invalid synthesis_iterations: {self.synthesis_iterations}, using 1")
        #     self.synthesis_iterations = 1

        queries, answers, sources_list = [queries[0]], [], []

        for i in range(self.synthesis_iterations):
            answer, sources = self.kb_manager.query(
                queries[-1],
                top_k=self.synthesis_top_k,
                top_n=self.synthesis_top_n,
                return_sources=True,
                filters=self.filters)

            # Check if iteration filter is working properly
            if self.filters and sources:
                iters = [s.get('iteration') for s in sources]
                violations = [it for it in iters if isinstance(it, int) and it >= self.synthesis_iteration_filter]
                self.logger.assert_true(not violations,
                    f"Iteration filter failed: {violations} >= {self.synthesis_iteration_filter}")

            iter_str = f"[SYNTHESIS DRAFT {self._current_draft}/{self._num_drafts} ITERATION {i+1}/{self.synthesis_iterations}]"
            if not answer:
                # Skip iter on transient KB failure rather than abort draft.
                self.logger.error(f"{iter_str} KB query failed; skipping iter")
                continue
            if not isinstance(sources, list): sources = []

            answers.append(answer)
            sources_list.append(sources)
            self.logger.info(f"{iter_str}\nQ: {queries[-1]}\nA: {answers[-1]}")

            if i >= self.synthesis_iterations - 1: break

            next_query = self._generate_next_query(queries, answers)
            if not next_query:
                self.logger.error(f"{iter_str} Next query failed"); break
            queries.append(next_query)

        return list(zip(queries, answers, sources_list))

    def _generate_qa_pairs_classic(self, queries: List[str]) -> List[Tuple[str, str, List[Dict]]]:
        """Execute queries against KB with sources"""
        qa_pairs = []
        for query in queries:
            try:
                answer, sources = self.kb_manager.query(
                    query,
                    top_k=self.synthesis_top_k,
                    top_n=self.synthesis_top_n,
                    return_sources=True,
                    filters=self.filters)
                if answer:
                    qa_pairs.append((query, answer, sources))
            except Exception as e:
                self.logger.error(f"KB query failed for '{query}': {e}")
        return qa_pairs

    def _generate_next_query(self, previous_queries: List[str],
                             previous_responses: List[str]) -> Optional[str]:
        """Generate next synthesis query"""
        recent_queries = previous_queries[-MAX_SYNTHESIS_QA_CONTEXT:]
        recent_responses = previous_responses[-MAX_SYNTHESIS_QA_CONTEXT:]

        init_query = self.agent.starting_query if self.agent.starting_query else previous_queries[0]
        prev_insights = "\n\n".join([f"Q: {q}\nA: {r}"
            for q, r in zip(recent_queries, recent_responses)])

        prompt = f"""INITIAL QUERY:
{init_query}

PREVIOUS INSIGHTS:
{prev_insights}

YOUR TASK:
Based on the initial query and previous insights gathered so far, what is the next most important question to ask to deepen understanding and reveal emergent patterns? The question should:
- Build on past insights rather than repeat them
- Seek connections between different themes
- Identify gaps or contradictions to explore
- Move toward synthesis and creation rather than enumeration

IMPORTANT: Use your role as a guide on how to respond!

Respond with JSON:
{{
    "query": "<your next question>",
    "reason": "<brief explanation of why this question deepens understanding>"
}}"""

        result = self._llm_call(prompt, ["query"], retries=1, label="NEXT_QUERY")
        return result["query"] if result else None

    # ── Citation building ─────────────────────────────────────────────────

    def _build_answers_with_citations(self, qa_pairs):
        """Build formatted answers with citations and source index from Q&A pairs."""
        source_map = {}; answers = []

        for i, (q, a, sources) in enumerate(qa_pairs):
            # Add new sources to index (exclude file:// URLs)
            for src in sources:
                if (url := src['url']) and not url.startswith('file://') and url not in source_map:
                    source_map[url] = len(source_map) + 1

            # Format with citations (only for URLs in source_map)
            refs = ", ".join([f"[{source_map[s['url']]}]"
                for s in sources[:MAX_SYNTHESIS_QUERY_SOURCES] if s.get('url') and s['url'] in source_map])
            answers.append(f"({i+1}) Question: {q}\n\nAnswer: {a} {refs}")

        qa_list = "\n\n\n".join(answers)
        source_list = self._format_source_list(source_map)

        return qa_list, source_list, source_map

    # ── Saving ────────────────────────────────────────────────────────────

    def _save_synthesis(self, result: Dict,
            base_dir: str = None,
            suffix: str = "synthesis",
            timestamp: str = None) -> None:
        """Save synthesis with sources in JSON and text formats"""
        if not base_dir: base_dir = self.agent.get_repo()
        if not timestamp: timestamp = datetime.now().strftime("%m%d%H%M")
        os.makedirs(base_dir, exist_ok=True)
        base_path = os.path.join(base_dir, f"{self.agent.get_id()}.{suffix}.{timestamp}")
        meta_path = os.path.join(base_dir, "metadata.txt")

        try:
            if SYNTHESIS_SAVE_JSON:
                with open(f"{base_path}.json", 'w', encoding='utf-8') as f:
                    json.dump(result, f, ensure_ascii=False, indent=4, sort_keys=True)
                self.saved_artifact_files.append(f"{base_path}.json")

            with open(f"{base_path}.txt", 'w', encoding='utf-8') as f:
                if abstract := result.get('abstract'):
                    f.write(f"ABSTRACT:\n{abstract}\n\n")

                f.write(f"ARTIFACT:\n{result['artifact']}\n\n")

                if sources := result.get('sources'):
                    f.write(f"SOURCES:\n{self._format_source_list(sources)}\n\n")
            self.saved_artifact_files.append(f"{base_path}.txt")

            if metadata := result.get('metadata'):
                with open(meta_path, 'a', encoding='utf-8') as f:
                    f.write(f"{base_path}\n{json.dumps(metadata, indent=4, sort_keys=True)}\n\n")

        except Exception as e:
            self.logger.error(f"Failed to save synthesis: {e}")

    # ── Post-processing ───────────────────────────────────────────────────

    def _post_process_clarify(self, result: Dict) -> Optional[Dict]:
        """Polish the merged abstract AND artifact for plain-language clarity
        and clean Markdown formatting. Returns
        {"abstract": <new>, "artifact": <new>} or None on failure. Does NOT
        save a file — caller substitutes the texts into the merged result so
        a single canonical merged file is saved.

        Reads result["abstract"] and result["artifact"] directly (NOT
        _get_artifact_text, which would concatenate them and cause the
        abstract to end up embedded inside the clarified artifact and
        duplicated on save). Both are clarified in one LLM call so tone and
        terminology stay consistent between the summary and the body.
        Sources dict is preserved unchanged by the caller.

        Returns None when self.synthesis_merge_clarify is False, so the
        caller does not need its own flag check."""
        if not self.synthesis_merge_clarify: return None

        artifact_text = result.get("artifact", "")
        if not artifact_text:
            self.logger.error("[CLARIFY] No artifact text to clarify")
            return None
        abstract_text = result.get("abstract", "")

        self.logger.info("[CLARIFY] Polishing merged abstract and artifact for clarity")

        prompt = f"""--- ABSTRACT ---
{abstract_text}
--- END OF ABSTRACT ---

--- ARTIFACT ---
{artifact_text}
--- END OF ARTIFACT ---

YOUR TASK:
Rewrite BOTH the abstract and the artifact above to be clearer and easier
to read for a non-expert but college-educated reader, WITHOUT removing
information or changing meaning. Use the SAME plain-language style across
both so the summary and the body feel consistent.

CONTENT - preserve, do not strip:
 - Keep every claim, fact, number, recommendation, and named concept.
 - Keep every citation marker EXACTLY as written (e.g., [1], [2,5,7]).
 - Keep the section ordering and the heading hierarchy in the artifact.
 - The rewrite should be the SAME LENGTH OR LONGER - clarification adds
   words. Never trade information for brevity.
 - The abstract should remain a concise summary paragraph.

LANGUAGE - translate jargon, do not strip:
 - Replace consultant / business / technical jargon with plain English
   where possible. If a technical term is load-bearing, keep it but add
   a brief inline gloss in parentheses on first use.
   Examples:
     "rate compression"  -> "pressure to lower hourly prices"
     "table stakes"      -> "the minimum expected"
     "control plane"     -> "central control system"
     "vertical"          -> "industry sector"
     "wedge"             -> "starter"
     "blast radius"      -> "scope of damage if it goes wrong"
     "thin waist"        -> "narrow central layer everything plugs through"
     "race to zero"      -> "competitive price collapse"
     "schema"            -> "data structure"
     "outcome kicker"    -> "bonus payment tied to outcomes"
     "rubric"            -> "scoring rule"
 - Re-gloss specialized terms when they reappear in DISTANT sections of
   the document, not only on first use. If a non-expert encountering the
   term again several pages later would not remember the earlier
   definition, add a brief reminder gloss in parentheses. Better to
   gloss twice than to leave the reader stranded in a later section.
 - Spell out acronyms on first use; use the acronym alone after.
   (e.g., SSO, SIEM, SOAR, SDLC, ITSM, MCP, FinOps, OEM)
 - Remove empty connective filler ("at the end of the day", "in essence")
   that adds no information.

FORMATTING - normalize, do not decorate:
 - Use Markdown. Use **bold** for emphasis; do NOT use *italics*.
 - Indent sub-bullets under their parent so visual hierarchy is clear.
 - Do NOT add a "Sources" or "References" section; citations stay inline.
 - Do NOT introduce horizontal rules or decorative headings.

Respond with valid JSON only:
{{
    "clarified_abstract": "<the rewritten abstract text>",
    "clarified_artifact": "<the rewritten artifact text in markdown>"
}}"""

        llm_result = self._llm_call(prompt,
            ["clarified_abstract", "clarified_artifact"],
            reasoning="high", label="CLARIFY")
        if not llm_result: return None

        new_artifact = llm_result.get("clarified_artifact") or ""
        if not new_artifact:
            self.logger.error("[CLARIFY] LLM returned empty clarified artifact")
            return None

        # Abstract is best-effort: if the LLM returns an empty string, fall
        # back to the original abstract rather than blanking it out.
        new_abstract = llm_result.get("clarified_abstract") or abstract_text

        return {
            "abstract": self._normalize_formatting(new_abstract),
            "artifact": self._normalize_formatting(new_artifact),
        }

    @staticmethod
    def _normalize_formatting(text: str) -> str:
        """Deterministic Markdown clean-up the LLM is unreliable at:
        bold-wrapping-italic nesting, stray italics, trailing whitespace,
        excess blank lines."""
        # 1. Collapse bold-wrapping-italic (**Foo *Bar***) -> **Foo Bar**
        text = re.sub(r'\*\*([^*\n]*?)\*([^*\n]+?)\*([^*\n]*?)\*\*',
                      r'**\1\2\3**', text)
        # 2. Convert standalone italic (*foo*) to bold (**foo**)
        text = re.sub(r'(?<!\*)\*([^*\n]+?)\*(?!\*)', r'**\1**', text)
        # 3. Strip trailing whitespace on every line
        text = re.sub(r'[ \t]+$', '', text, flags=re.MULTILINE)
        # 4. Collapse runs of >2 blank lines
        text = re.sub(r'\n{3,}', '\n\n', text)
        return text

    def _post_process_eli5(self, result: Dict,
        base_dir: str = None,
        suffix: str = "eli5",
        timestamp: str = None) -> Optional[Dict]:
        """Generate ELI5 explanation(s) of artifact and save them"""
        if not self.synthesis_eli5: return None

        artifact_text = self._get_artifact_text(result)
        if not artifact_text: return None

        # Support single int, list of ints, or None
        word_lengths = ([self.synthesis_eli5_length] if isinstance(self.synthesis_eli5_length, int)
                        else self.synthesis_eli5_length if isinstance(self.synthesis_eli5_length, list)
                        else [None])

        results = []
        for length in word_lengths:
            self.logger.info(f"[POST-PROCESS] Generating {length or 'unconstrained'} word ELI5")

            # Sanitize length suffix string and setup prompt context
            # re.sub(r'[<>:\"/\\|?*\s]', '-', str(length))
            current_suffix = f"{suffix}.{re.sub(r'\D', '', str(length))}w" if length else suffix
            length_context = f"\nIMPORTANT: Your explanation MUST be {length} words, double check to make sure" if length else ""

            prompt = f"""--- ARTIFACT ---
{artifact_text}
--- END OF ARTIFACT ---

YOUR TASK:
"Explain Like I'm 5" (ELI5) the artifact above:
 - Do NOT mention or reference the artifact, your explanation should be a standalone text
 - Your target audience is a non-expert but college educated reader
 - Capture the main ideas without oversimplifying
 - Clarify any confusing or convoluted parts of the artifact
 - Your explanation should start with a short but interesting title
{length_context}
IMPORTANT: Format your explanation so humans can easily read it (use more than one big paragraph)

Respond with valid JSON only:
{{
    "eli5": "<your ELI5 explanation>"
}}"""

            processed = self._post_process(result, prompt, "eli5",
                label="POST-PROCESS", base_dir=base_dir,
                suffix=current_suffix, timestamp=timestamp)
            if processed: results.append(processed)
            else: self.logger.error(f"[POST-PROCESS] {length or 'unconstrained'} ELI5 generation failed")

        return results[-1] if results else None

    def _post_process_human_eval(self, result: Dict,
        base_dir: str = None,
        suffix: str = "human-eval",
        timestamp: str = None) -> Optional[Dict]:
        """Generate a two-paragraph human eval summary: core idea + creativity argument"""
        if not self.synthesis_human_eval: return None

        artifact_text = self._get_artifact_text(result)
        if not artifact_text: return None

        prompt = f"""--- ARTIFACT ---
{artifact_text}
--- END OF ARTIFACT ---

YOUR TASK:
Write exactly two short paragraphs about the artifact above:

PARAGRAPH 1 - CORE IDEA SUMMARY (2-3 sentences):
 - Identify and summarize the most important creative key idea in the artifact
 - Make sure the summary is clear and understandable to a non-expert
 - The reader should immediately understand what the artifact is about
 - Do not overuse jargon or too many technical terms

PARAGRAPH 2 - CREATIVITY ARGUMENT (3-4 sentences):
 - Make a clear, convincing argument for why the key idea in the artifact is creative
 - Explain what makes it novel, surprising, or useful
 - Ground your argument in specific aspects of the idea, not generic praise
 - Write to persuade a skeptical reader

IMPORTANT: Do NOT mention or reference "the artifact" — write as if describing the idea itself
IMPORTANT: Start paragraph 1 with "SUMMARY: " and paragraph 2 with "WHY ITS CREATIVE: "

Respond with valid JSON only:
{{
    "human_eval": "SUMMARY: <paragraph 1>\\n\\nWHY ITS CREATIVE: <paragraph 2>"
}}"""

        return self._post_process(result, prompt, "human_eval",
            label="POST-PROCESS", base_dir=base_dir,
            suffix=suffix, timestamp=timestamp)