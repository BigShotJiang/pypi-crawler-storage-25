"""
Allows:  python -m dl_experiments [exp_keys ...]
"""
import argparse
import sys

from . import list_experiments, main


def cli() -> None:
    parser = argparse.ArgumentParser(
        prog="dl_experiments",
        description="Run Deep Learning experiment modules.",
    )
    parser.add_argument(
        "experiments",
        nargs="*",
        metavar="EXP",
        help=(
            "Experiment keys to run (e.g. 1a 2b 10). "
            f"Available: {', '.join(list_experiments())}. "
            "Omit to run ALL."
        ),
    )
    parser.add_argument(
        "--list",
        action="store_true",
        help="List available experiment keys and exit.",
    )
    args = parser.parse_args()

    if args.list:
        print("Available experiments:", ", ".join(list_experiments()))
        sys.exit(0)

    main(*args.experiments)


if __name__ == "__main__":
    cli()
