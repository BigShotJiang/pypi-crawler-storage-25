"""
dl_experiments
==============
A pip-installable collection of Deep Learning experiment modules.

Quick start
-----------
    import dl_experiments
    dl_experiments.main()            # run all experiments

    dl_experiments.main("1a")        # run a single experiment
    dl_experiments.main("4", "5")    # run multiple experiments

    dl_experiments.list_experiments()  # see all available keys
"""

from .utils.registry import list_experiments, run_experiment

__version__ = "1.0.0"
__author__  = "Pratham"
__all__     = ["main", "list_experiments", "run_experiment", "__version__"]


def main(*experiments: str) -> None:
    """
    Orchestrate and run DL experiments.

    Parameters
    ----------
    *experiments : str
        Experiment keys to run (e.g. "1a", "2b", "10").
        If none are provided, ALL experiments are run in order.

    Examples
    --------
    >>> import dl_experiments
    >>> dl_experiments.main()         # run all
    >>> dl_experiments.main("1a")     # run only Exp 1a
    >>> dl_experiments.main("4","5")  # run Exp 4 and 5
    """
    keys = list(experiments) if experiments else list_experiments()

    print("=" * 60)
    print("  Deep Learning Experiments Suite")
    print(f"  Running: {', '.join(keys)}")
    print("=" * 60)

    for key in keys:
        try:
            run_experiment(key)
        except Exception as exc:          # noqa: BLE001
            print(f"\n  [ERROR] Experiment {key!r} failed: {exc}")

    print("\n" + "=" * 60)
    print("  All done!")
    print("=" * 60)
