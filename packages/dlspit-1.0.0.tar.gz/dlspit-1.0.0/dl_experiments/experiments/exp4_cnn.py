# =============================================================================
# EXPERIMENT 4: Convolutional Neural Network (CNN) on MNIST
# =============================================================================
#
# THEORY:
# A Convolutional Neural Network (CNN) is a deep learning architecture
# specifically designed for processing grid-like data such as images.
# Unlike an MLP that flattens images, CNN preserves spatial structure.
#
# ---- Why CNN for Images? ----
# - MLP treats each pixel independently, ignoring spatial relationships.
# - CNN uses "filters" that slide over the image to detect local patterns
#   (edges, corners, textures) regardless of where they appear (translation invariance).
# - CNNs require far fewer parameters than MLPs for image data.
#
# ---- Key Layers ----
#
# 1. Conv2D (Convolutional Layer):
#    - Applies a set of learnable filters (kernels) over the input image
#    - Each filter detects a specific pattern (e.g., horizontal edge)
#    - Conv2D(16, 3): 16 filters, each of size 3x3
#    - Output is called a "feature map" or "activation map"
#    - ReLU after conv: introduces non-linearity
#
# 2. MaxPooling2D (Pooling Layer):
#    - Downsamples feature maps by taking the MAX value in each window
#    - MaxPooling2D(2): takes max in each 2x2 window, halves spatial dims
#    - Reduces computation, provides spatial invariance (robustness to small shifts)
#
# 3. Flatten:
#    - Converts the 2D feature maps into a 1D vector
#    - Needed to connect CNN layers to fully-connected (Dense) layers
#
# 4. Dense(10, Softmax):
#    - Final classification layer
#    - 10 output neurons = 10 digit classes (0-9)
#    - Softmax: converts logits to probabilities
#
# ---- Architecture Flow ----
# Input(28,28,1) -> Conv2D(16,3,ReLU) -> MaxPool(2)
#                -> Conv2D(32,3,ReLU) -> MaxPool(2)
#                -> Flatten -> Dense(10, Softmax)
#
# Each Conv+Pool block learns increasingly abstract features:
#   Layer 1: low-level features (edges, blobs)
#   Layer 2: mid-level features (curves, shapes)
#
# ---- Input Shape ----
# (28, 28, 1): height=28, width=28, channels=1 (grayscale)
# For RGB images: channels=3, e.g., input_shape=(height, width, 3)
#
# =============================================================================
# IF CSV DATA IS GIVEN:
#
# CSVs typically store FLAT data (1D rows), not 2D images.
# If your CSV contains pixel data for images:
#
#   import pandas as pd, numpy as np
#   df = pd.read_csv('your_image_data.csv')
#   # Assume CSV has 784 pixel columns (for 28x28 images) + 'label' column
#   X = df.drop('label', axis=1).values.astype('float32') / 255.0
#   y = df['label'].values.astype('int32')
#
#   # Reshape flat pixels to 4D tensor for CNN input:
#   # (num_samples, height, width, channels)
#   X = X.reshape(-1, 28, 28, 1)   # For 28x28 grayscale images
#   # CHANGE 28, 28 to match your actual image dimensions
#   # CHANGE 1 to 3 if your images are RGB
#
#   # Split into train/test:
#   from sklearn.model_selection import train_test_split
#   x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
#
#   # CHANGE Conv2D input_shape to match your image dimensions:
#   #   input_shape=(height, width, channels)
#   # CHANGE Dense(10, ...) to match the number of classes in your CSV.
# =============================================================================


def run():
    print("\n=== Exp 4: Convolutional Neural Network (CNN) on MNIST ===")

    try:
        import tensorflow as tf
    except ImportError:
        print("  [SKIP] tensorflow not installed. Install with: pip install tensorflow")
        return

    # ------------------------------------------------------------------
    # 1. Load MNIST dataset
    #    x_train: (60000, 28, 28) float, y_train: (60000,) int
    #    x_test : (10000, 28, 28) float, y_test : (10000,) int
    # ------------------------------------------------------------------
    (x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()

    # ------------------------------------------------------------------
    # 2. Preprocess: Normalize + Add Channel Dimension
    #    / 255.0              : scale pixels from [0,255] to [0.0, 1.0]
    #    reshape(-1, 28, 28, 1): add channel dim -> shape becomes (N, 28, 28, 1)
    #    CNN requires 4D input: (batch_size, height, width, channels)
    #    Grayscale = 1 channel; RGB = 3 channels
    # ------------------------------------------------------------------
    x_train = x_train / 255.0
    x_test  = x_test / 255.0

    x_train = x_train.reshape(-1, 28, 28, 1)  # Shape: (60000, 28, 28, 1)
    x_test  = x_test.reshape(-1, 28, 28, 1)   # Shape: (10000, 28, 28, 1)

    # ------------------------------------------------------------------
    # 3. Build CNN Model
    # ------------------------------------------------------------------
    model = tf.keras.Sequential([
        # --- First Convolutional Block ---
        # Conv2D(16, 3): 16 filters of size 3x3, ReLU activation
        # Detects low-level features: edges, lines, curves
        # input_shape=(28,28,1): 28x28 grayscale image
        # Output shape: (26, 26, 16) - spatial dims reduced by filter size
        tf.keras.layers.Conv2D(16, 3, activation='relu', input_shape=(28, 28, 1)),

        # MaxPooling2D(2): Take max in each 2x2 window, stride=2 by default
        # Reduces spatial dims by half: (26, 26, 16) -> (13, 13, 16)
        tf.keras.layers.MaxPooling2D(2),

        # --- Second Convolutional Block ---
        # Conv2D(32, 3): 32 filters of size 3x3, ReLU activation
        # Detects higher-level patterns using features from previous layer
        # Output shape: (11, 11, 32)
        tf.keras.layers.Conv2D(32, 3, activation='relu'),

        # MaxPooling2D(2): Reduces again: (11, 11, 32) -> (5, 5, 32)
        tf.keras.layers.MaxPooling2D(2),

        # --- Classifier Head ---
        # Flatten: convert 3D tensor (5, 5, 32) -> 1D vector (800,)
        tf.keras.layers.Flatten(),

        # Output: 10 neurons (digits 0-9), Softmax for probability distribution
        # CHANGE 10 to the number of classes in your dataset
        tf.keras.layers.Dense(10, activation='softmax')
    ])

    # ------------------------------------------------------------------
    # 4. Compile: optimizer, loss, metric
    #    Adam: adaptive learning rate optimizer
    #    sparse_categorical_crossentropy: loss for integer labels
    # ------------------------------------------------------------------
    model.compile(
        optimizer='adam',
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )

    # ------------------------------------------------------------------
    # 5. Train the model
    #    epochs=3    : 3 full passes through the training data
    #    batch_size=32: process 32 images at a time before updating weights
    # ------------------------------------------------------------------
    model.fit(x_train, y_train, epochs=3, batch_size=32, verbose=1)

    # ------------------------------------------------------------------
    # 6. Evaluate on test set and print accuracy
    # ------------------------------------------------------------------
    loss, acc = model.evaluate(x_test, y_test, verbose=0)
    print(f"\nTest Loss: {loss:.4f}  |  Test Accuracy: {acc*100:.2f}%")