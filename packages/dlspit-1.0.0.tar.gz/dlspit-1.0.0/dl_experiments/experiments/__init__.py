"""DL experiment modules."""
from . import (
    exp1a_mcculloch_pitts,
    exp1b_mlp_binary,
    exp2a_activations,
    exp2b_backprop_mnist,
    exp3_regularisation,
    exp4_cnn,
    exp5_resnet,
    exp6_rnn,
    exp7_lstm,
    exp8_transformer,
    exp9_gan,
    exp9b_vae,
    exp10_transfer,
)

__all__ = [
    "exp1a_mcculloch_pitts",
    "exp1b_mlp_binary",
    "exp2a_activations",
    "exp2b_backprop_mnist",
    "exp3_regularisation",
    "exp4_cnn",
    "exp5_resnet",
    "exp6_rnn",
    "exp7_lstm",
    "exp8_transformer",
    "exp9_gan",
    "exp9b_vae",
    "exp10_transfer",
]
