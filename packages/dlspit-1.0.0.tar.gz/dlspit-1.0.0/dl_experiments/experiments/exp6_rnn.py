# =============================================================================
# EXPERIMENT 6: Recurrent Neural Network (RNN) for Sentiment Analysis
# =============================================================================
#
# THEORY:
# A Recurrent Neural Network (RNN) is a type of neural network designed to
# handle SEQUENTIAL data (text, time series, audio) where order matters.
#
# Unlike MLP/CNN which process fixed-size inputs:
#   - RNN processes input one element at a time (one word at a time)
#   - Maintains a "hidden state" (memory) that is updated at each step
#   - The hidden state at step t depends on the current input AND the previous state
#
# ---- RNN Equation ----
#   h_t = tanh(W_h * h_{t-1} + W_x * x_t + b)
#   where:
#     h_t     = hidden state at time step t (the "memory")
#     x_t     = input at time step t (current word embedding)
#     W_h, W_x= learned weight matrices
#     tanh    = activation function (keeps values between -1 and 1)
#
# ---- Limitations of Simple RNN ----
# - Vanishing Gradient Problem: gradients become tiny when backpropagating
#   through many time steps -> can't learn long-range dependencies
# - Alternatives: LSTM (Long Short-Term Memory) and GRU (Gated Recurrent Unit)
#   solve this by using gating mechanisms to control information flow.
#
# ---- IMDB Dataset ----
# 50,000 movie reviews labeled as positive (1) or negative (0).
# Binary sentiment classification task.
# Reviews are pre-tokenized: each word is replaced by an integer index.
# num_words=10000: use only the 10,000 most frequent words.
#
# ---- Padding ----
# Reviews have different lengths. Neural networks need fixed-size input.
# pad_sequences(maxlen=100): pads shorter sequences with 0s and
# truncates longer sequences to 100 tokens.
#
# ---- Embedding Layer ----
# Converts integer word indices to dense vectors (word embeddings).
# Embedding(10000, 32): 10000 vocab size, 32-dimensional embedding vector per word.
# The model LEARNS these embeddings during training.
# Captures semantic similarity: similar words have similar vectors.
#
# ---- Architecture Flow ----
# Input(100,) -> Embedding(10000, 32) -> SimpleRNN(32) -> Dense(1, Sigmoid)
#   - Embedding: converts 100 integer indices -> 100 x 32 float matrix
#   - SimpleRNN: processes 100-step sequence, outputs 32-dim hidden state
#   - Dense(1, Sigmoid): outputs probability (>0.5 = positive, <0.5 = negative)
#
# =============================================================================
# IF CSV DATA IS GIVEN (Text Sentiment Classification):
#
# If your CSV has raw text reviews (not pre-tokenized):
#
#   import pandas as pd
#   df = pd.read_csv('your_reviews.csv')
#   # CSV columns: 'review' (text), 'sentiment' (0 or 1)
#
#   texts  = df['review'].values      # Array of raw text strings
#   labels = df['sentiment'].values   # 0 = negative, 1 = positive
#
#   # Tokenize: convert text to sequences of integers
#   from tensorflow.keras.preprocessing.text import Tokenizer
#   from tensorflow.keras.preprocessing.sequence import pad_sequences
#
#   MAX_WORDS = 10000   # Vocabulary size (keep top 10000 words)
#   MAX_LEN   = 100     # Max review length in tokens
#
#   tokenizer = Tokenizer(num_words=MAX_WORDS, oov_token='<OOV>')
#   tokenizer.fit_on_texts(texts)                       # Build vocabulary
#   sequences = tokenizer.texts_to_sequences(texts)     # Convert to integers
#   X = pad_sequences(sequences, maxlen=MAX_LEN)        # Pad/truncate to MAX_LEN
#
#   # Split into train/test:
#   from sklearn.model_selection import train_test_split
#   x_train, x_test, y_train, y_test = train_test_split(X, labels, test_size=0.2)
#
#   # CHANGE Embedding(10000, 32, ...) to match your MAX_WORDS and input_length:
#   #   tf.keras.layers.Embedding(MAX_WORDS, 32, input_length=MAX_LEN)
#   # CHANGE output Dense(1, sigmoid) for binary classification.
#   # For multi-class sentiment (e.g., 5-star rating):
#   #   Dense(5, activation='softmax') and loss='sparse_categorical_crossentropy'
# =============================================================================


def run():
    print("\n=== Exp 6: Simple RNN for Sentiment Analysis (IMDB) ===")

    try:
        import tensorflow as tf
    except ImportError:
        print("  [SKIP] tensorflow not installed. Install with: pip install tensorflow")
        return

    # ------------------------------------------------------------------
    # 1. Load IMDB Dataset (already tokenized)
    #    Returns integer sequences where each integer = word index
    #    num_words=10000: vocabulary limited to top 10,000 most frequent words
    #    x_train: list of 25,000 variable-length integer sequences
    #    y_train: list of 25,000 binary labels (0=negative, 1=positive)
    # ------------------------------------------------------------------
    (x_train, y_train), (x_test, y_test) = tf.keras.datasets.imdb.load_data(num_words=10000)

    # ------------------------------------------------------------------
    # 2. Pad / Truncate Sequences to Fixed Length
    #    All reviews must have the same length (100 tokens) for batch processing
    #    Shorter reviews: padded with 0 at the beginning (pre-padding by default)
    #    Longer reviews : truncated to first 100 tokens
    #    CHANGE maxlen if you want to capture longer context (e.g., 200, 500)
    #    Longer maxlen = more memory/compute, potentially better accuracy
    # ------------------------------------------------------------------
    x_train = tf.keras.preprocessing.sequence.pad_sequences(x_train, maxlen=100)
    x_test  = tf.keras.preprocessing.sequence.pad_sequences(x_test,  maxlen=100)

    # ------------------------------------------------------------------
    # 3. Build the RNN Model
    # ------------------------------------------------------------------
    model = tf.keras.Sequential([
        # Embedding Layer: converts word indices -> dense embedding vectors
        # Embedding(vocab_size, embedding_dim, input_length)
        #   vocab_size=10000    : size of vocabulary (number of unique word indices)
        #   embedding_dim=32    : each word is represented by a 32-dimensional vector
        #   input_length=100    : length of input sequence (matches maxlen above)
        # CHANGE 10000 if you change num_words in load_data()
        # CHANGE 100   if you change maxlen in pad_sequences()
        tf.keras.layers.Embedding(10000, 32, input_length=100),

        # SimpleRNN Layer: processes the sequence step by step
        # 32 units: size of the hidden state (memory vector)
        # At each time step t: h_t = tanh(W_h * h_{t-1} + W_x * x_t + b)
        # Final output: hidden state after processing all 100 time steps
        # NOTE: For better performance on long sequences, use LSTM or GRU:
        #   tf.keras.layers.LSTM(32)   or   tf.keras.layers.GRU(32)
        tf.keras.layers.SimpleRNN(32),

        # Output Layer: 1 neuron with Sigmoid activation
        # Sigmoid output in (0,1): represents probability of positive sentiment
        # > 0.5 -> Positive review,  < 0.5 -> Negative review
        # For multi-class: Dense(num_classes, activation='softmax')
        tf.keras.layers.Dense(1, activation='sigmoid')
    ])

    # ------------------------------------------------------------------
    # 4. Compile: optimizer, loss, metric
    #    Adam: adaptive optimizer (works well for NLP tasks)
    #    binary_crossentropy: standard loss for binary classification
    #    accuracy: fraction of correct predictions
    # ------------------------------------------------------------------
    model.compile(
        optimizer='adam',
        loss='binary_crossentropy',   # For binary (positive/negative) labels
        metrics=['accuracy']
    )

    # ------------------------------------------------------------------
    # 5. Train the model
    #    epochs=3    : 3 full passes through 25,000 training reviews
    #    batch_size=64: process 64 reviews at a time before each weight update
    # ------------------------------------------------------------------
    model.fit(x_train, y_train, epochs=3, batch_size=64, verbose=1)

    # ------------------------------------------------------------------
    # 6. Evaluate on test set (25,000 unseen reviews)
    #    Reports final test loss and accuracy
    # ------------------------------------------------------------------
    loss, acc = model.evaluate(x_test, y_test, verbose=0)
    print(f"\nTest Loss: {loss:.4f}  |  Test Accuracy: {acc*100:.2f}%")
