import numpy as np

# =============================================================================
# EXPERIMENT 9b (VAE): Variational Autoencoder on MNIST
# =============================================================================
#
# THEORY:
# A Variational Autoencoder (VAE) is a generative model that learns a
# PROBABILITY DISTRIBUTION over the latent (compressed) representation of data.
# It combines ideas from autoencoders and probabilistic graphical models.
#
# ---- Standard Autoencoder vs VAE ----
# Standard Autoencoder:
#   Encoder: x -> z (fixed latent vector)
#   Decoder: z -> x'
#   Problem: latent space is not continuous; cannot generate new samples by
#            sampling random z values.
#
# VAE:
#   Encoder: x -> (μ, σ²) — learns PARAMETERS of a Gaussian distribution
#   Sampling: z ~ N(μ, σ²) — sample from the distribution (with reparameterization)
#   Decoder: z -> x'
#   Key benefit: latent space is smooth and continuous -> can generate new images
#                by sampling any point z from N(0, I) and decoding it.
#
# ---- Reparameterization Trick ----
# We need to backpropagate through the sampling step, but sampling is not
# differentiable. The trick:
#   z = μ + σ * ε,  where ε ~ N(0, I)
# This separates the randomness (ε) from the learned parameters (μ, σ),
# making backpropagation possible.
# In code: z = z_mean + exp(0.5 * z_log_var) * eps
#   - z_log_var = log(σ²), so exp(0.5 * z_log_var) = σ
#   - eps = random noise from N(0, I)
#
# ---- VAE Loss Function ----
# Total Loss = Reconstruction Loss + KL Divergence Loss
#
# 1. Reconstruction Loss (Recon Loss):
#    Measures how well the decoder reconstructs the input from z.
#    Here: binary cross-entropy between original image and reconstructed image.
#    Multiplied by 28*28 to scale it (pixel-wise BCE * number of pixels).
#
# 2. KL Divergence Loss (KL Loss):
#    KL( N(μ, σ²) || N(0, I) ) = -0.5 * sum(1 + log(σ²) - μ² - σ²)
#    Measures how much the learned distribution N(μ, σ²) deviates from
#    the standard normal N(0, I).
#    Acts as a REGULARIZER: forces the latent space to be organized and
#    continuous (close to N(0,1)), enabling meaningful interpolation.
#
# ---- Latent Dimension ----
# latent_dim=2: compress each 28x28=784-pixel image into just 2 numbers.
# With latent_dim=2, you can visualize the entire latent space as a 2D plot.
# Larger latent_dim (e.g., 16, 64) gives better reconstruction quality.
#
# ---- Encoder Architecture ----
# Input(28,28,1) -> Flatten(784) -> Dense(64, relu) -> z_mean (2,) + z_log_var (2,)
#
# ---- Decoder Architecture ----
# Input(2,) -> Dense(64, relu) -> Dense(784, sigmoid) -> Reshape(28,28,1)
#
# ---- Custom train_step ----
# Uses tf.GradientTape to manually compute gradients for the combined loss
# (recon_loss + kl_loss) and apply them to all trainable weights.
#
# =============================================================================
# IF CSV DATA IS GIVEN (Image Data in CSV format):
#
# VAEs are designed for IMAGE or high-dimensional data, not raw tabular CSVs.
# However, if your CSV contains flattened pixel values (e.g., 784 columns for 28x28):
#
#   import pandas as pd
#   df = pd.read_csv('your_image_data.csv')
#   # Assume columns: pixel_0, pixel_1, ..., pixel_783 (no label needed for VAE)
#
#   x_train = df.values.astype('float32') / 255.0    # Normalize to [0,1]
#   x_train = x_train.reshape(-1, 28, 28, 1)          # Reshape to image format
#
#   # 🔴 CHANGE 1: If your images are a different size (e.g., 32x32 RGB):
#   #   x_train = x_train.reshape(-1, 32, 32, 3)
#   #   CHANGE the Input shape in Encoder: tf.keras.Input(shape=(32, 32, 3))
#   #   CHANGE Dense(32*32*3, activation='sigmoid') in Decoder
#   #   CHANGE Reshape((32, 32, 3)) in Decoder
#   #   CHANGE recon_loss multiplication factor: * 32 * 32
#
#   # 🔴 CHANGE 2: Increase latent_dim for better quality:
#   #   latent_dim = 16   # or 32, 64 for more complex datasets
# =============================================================================


def run():
    print("\n=== Exp 9b: Variational Autoencoder (VAE) on MNIST ===")

    try:
        import tensorflow as tf
    except ImportError:
        print("  [SKIP] tensorflow not installed. Install with: pip install tensorflow")
        return

    # ------------------------------------------------------------------
    # 1. Load MNIST data
    #    x_train: 60,000 images of 28x28 pixels (grayscale)
    #    We use underscore (_) to discard the labels - VAE is UNSUPERVISED
    # ------------------------------------------------------------------
    (x_train, _), _ = tf.keras.datasets.mnist.load_data()

    # Normalize to [0,1] and reshape to (60000, 28, 28, 1) - add channel dim
    x_train = x_train.astype("float32") / 255.0
    x_train = x_train.reshape(-1, 28, 28, 1)  # Shape: (60000, 28, 28, 1)

    # ------------------------------------------------------------------
    # latent_dim: size of the compressed latent representation
    # latent_dim=2: 2D latent space (easy to visualize)
    # CHANGE to 16, 32, etc. for better image quality / more complex data
    # ------------------------------------------------------------------
    latent_dim = 2

    # ------------------------------------------------------------------
    # 2. Encoder Network
    #    Maps input image -> (z_mean, z_log_var) parameters of Gaussian
    # ------------------------------------------------------------------
    inputs = tf.keras.Input(shape=(28, 28, 1))   # Input: 28x28 grayscale image

    # Flatten: (28,28,1) -> (784,) - convert image to flat vector
    x = tf.keras.layers.Flatten()(inputs)

    # Hidden layer: learn compressed representation of the image
    x = tf.keras.layers.Dense(64, activation='relu')(x)

    # z_mean: mean of the latent Gaussian distribution (shape: latent_dim,)
    z_mean = tf.keras.layers.Dense(latent_dim)(x)

    # z_log_var: log-variance of the latent Gaussian distribution
    # We learn log(σ²) instead of σ² because it can be any real number (not just positive)
    z_log_var = tf.keras.layers.Dense(latent_dim)(x)

    # ------------------------------------------------------------------
    # Reparameterization Trick: z = μ + σ * ε
    # Allows backpropagation through the sampling operation
    # eps ~ N(0, I): random noise independent of learned parameters
    # exp(0.5 * z_log_var) = sqrt(exp(z_log_var)) = σ (standard deviation)
    # ------------------------------------------------------------------
    def sample(args):
        z_mean, z_log_var = args
        # Sample random noise from standard normal distribution
        eps = tf.random.normal(shape=(tf.shape(z_mean)[0], latent_dim))
        # Reparameterization: z = μ + σ * ε
        return z_mean + tf.exp(0.5 * z_log_var) * eps

    # Lambda layer applies the sample function as a Keras layer
    z = tf.keras.layers.Lambda(sample)([z_mean, z_log_var])

    # Encoder model: input image -> (z_mean, z_log_var, z)
    encoder = tf.keras.Model(inputs, [z_mean, z_log_var, z])

    # ------------------------------------------------------------------
    # 3. Decoder Network
    #    Maps latent vector z -> reconstructed image
    # ------------------------------------------------------------------
    latent_inputs = tf.keras.Input(shape=(latent_dim,))   # Input: 2D latent vector z

    # Hidden layer: expand from latent space toward image space
    x = tf.keras.layers.Dense(64, activation='relu')(latent_inputs)

    # Output: 784 neurons = 28*28 pixels, Sigmoid for [0,1] pixel values
    x = tf.keras.layers.Dense(28 * 28, activation='sigmoid')(x)

    # Reshape flat vector (784,) back into image shape (28,28,1)
    outputs = tf.keras.layers.Reshape((28, 28, 1))(x)

    # Decoder model: latent vector z -> reconstructed image
    decoder = tf.keras.Model(latent_inputs, outputs)

    # ------------------------------------------------------------------
    # 4. Custom VAE Model Class
    #    Overrides train_step to implement the combined VAE loss:
    #    Total Loss = Reconstruction Loss + KL Divergence Loss
    # ------------------------------------------------------------------
    class VAE(tf.keras.Model):
        def __init__(self, encoder, decoder):
            super().__init__()
            self.encoder = encoder
            self.decoder = decoder

        def train_step(self, data):
            # Handle case where data comes as a tuple (x, y) -> we only need x
            # VAE is UNSUPERVISED: no labels needed
            if isinstance(data, tuple):
                data = data[0]

            # GradientTape: records operations for automatic differentiation (backprop)
            with tf.GradientTape() as tape:
                # Forward pass through encoder: get distribution parameters + sample z
                z_mean, z_log_var, z = self.encoder(data)

                # Decode z back to image space: get reconstructed image
                reconstruction = self.decoder(z)

                # ----------------------------------------------------------
                # Reconstruction Loss:
                # Binary cross-entropy between original and reconstructed pixels
                # reduce_mean: average over batch and spatial dims
                # * 28 * 28: scale up to be comparable with KL loss
                # ----------------------------------------------------------
                recon_loss = tf.reduce_mean(
                    tf.keras.losses.binary_crossentropy(data, reconstruction)
                ) * 28 * 28

                # ----------------------------------------------------------
                # KL Divergence Loss:
                # KL( N(z_mean, exp(z_log_var)) || N(0,1) )
                # Formula: -0.5 * mean(1 + log(σ²) - μ² - σ²)
                # Encourages latent distribution to stay close to N(0,1)
                # ----------------------------------------------------------
                kl_loss = -0.5 * tf.reduce_mean(
                    1 + z_log_var - tf.square(z_mean) - tf.exp(z_log_var)
                )

                total_loss = recon_loss + kl_loss

            # Compute gradients of total loss w.r.t. all trainable weights
            grads = tape.gradient(total_loss, self.trainable_weights)

            # Apply gradients using the Adam optimizer
            self.optimizer.apply_gradients(zip(grads, self.trainable_weights))

            # Return all loss components for monitoring during training
            return {
                "loss": total_loss,
                "recon_loss": recon_loss,
                "kl_loss": kl_loss
            }

    # ------------------------------------------------------------------
    # 5. Instantiate VAE and train
    #    vae.compile: only needs optimizer (loss is inside train_step)
    #    vae.fit: each epoch passes all 60,000 images through the VAE
    #    batch_size=128: process 128 images at a time
    # ------------------------------------------------------------------
    vae = VAE(encoder, decoder)
    vae.compile(optimizer='adam')   # Loss computed inside train_step, not here

    # Training: 3 epochs for quick demo; use 10-30 for better reconstruction quality
    history = vae.fit(x_train, epochs=3, batch_size=128, verbose=1)

    final = history.history
    print(f"\nFinal epoch  ->  "
          f"Loss: {final['loss'][-1]:.4f}  |  "
          f"Recon: {final['recon_loss'][-1]:.4f}  |  "
          f"KL: {final['kl_loss'][-1]:.4f}")

    # Quick sanity check: encode a few images and decode them
    sample_imgs = x_train[:5]
    z_m, z_lv, z_s = encoder.predict(sample_imgs, verbose=0)
    recons = decoder.predict(z_s, verbose=0)
    mse = float(np.mean((sample_imgs - recons) ** 2))
    print(f"Reconstruction MSE on 5 samples: {mse:.6f}")