import numpy as np

# =============================================================================
# EXPERIMENT 10: Transfer Learning with MobileNetV2 on CIFAR-10
# =============================================================================
#
# THEORY:
# Transfer Learning reuses a neural network pre-trained on a large dataset
# as a starting point for a new, related task.
# This dramatically reduces training time and data requirements.
#
# ---- Why Transfer Learning? ----
# Training deep CNNs from scratch requires:
#   - Millions of labeled images
#   - Days/weeks of GPU compute
# Transfer Learning solves this: a model pre-trained on ImageNet already knows
# how to detect edges, textures, shapes, and high-level objects.
# We just need to adapt the FINAL layers to our specific classes.
#
# ---- MobileNetV2 ----
# Lightweight CNN architecture designed for efficiency on mobile/edge devices.
# Pre-trained on ImageNet: 1.2 million images, 1000 classes.
# Key innovation: Depthwise Separable Convolutions
#   - Standard Conv: applies filter across all channels simultaneously
#   - Depthwise Conv: applies ONE filter per channel (much fewer parameters)
#   - Pointwise Conv: 1x1 convolution to combine channels
#   - Result: ~8-9x fewer parameters with similar accuracy vs standard Conv
#
# ---- Transfer Learning Strategy (2 Phases) ----
#
# Phase 1 - Feature Extraction (Frozen Base):
#   base_model.trainable = False
#   Only the new Dense(10, softmax) head is trained.
#   The pre-trained MobileNetV2 features are used as fixed feature extractors.
#   Fast and safe: ImageNet knowledge is preserved.
#
# Phase 2 - Fine-Tuning (Unfrozen):
#   base_model.trainable = True
#   ALL layers are trainable, but with a very small learning rate (1e-5).
#   The entire network adapts to the new domain (CIFAR-10).
#   Small lr prevents catastrophic forgetting of pre-trained features.
#
# ---- preprocess_input (MobileNetV2 Preprocessing) ----
# MobileNetV2 was trained with specific pixel normalization:
#   preprocess_input scales pixels from [0,255] to [-1, 1]
# MUST use this for correct behavior with pre-trained MobileNetV2 weights.
#
# ---- Dataset: CIFAR-10 (built-in, no external download needed) ----
# 60,000 color images (32x32 RGB) in 10 classes:
#   airplane, automobile, bird, cat, deer, dog, frog, horse, ship, truck
# 2,000 training samples used here for speed.
#
# ---- GlobalAveragePooling2D ----
# Converts (7, 7, 1280) feature maps from MobileNetV2 base -> (1280,) vector.
# More efficient than Flatten: fewer parameters, less overfitting.
#
# ---- Evaluation Metrics ----
# Classification Report: Precision, Recall, F1-score per class
#   Precision = TP / (TP + FP): of all predicted positive, how many are correct?
#   Recall    = TP / (TP + FN): of all actual positive, how many did we find?
#   F1-score  = 2 * (P * R) / (P + R): harmonic mean of precision and recall
#
# =============================================================================
# IF YOUR OWN IMAGE DATASET (changing from CIFAR-10):
#
# Option A: Images in folders (recommended):
#   Replace the CIFAR-10 loading block with:
#
#   IMG_SIZE = (96, 96)  # MobileNetV2 min is 32x32, recommended 96x96+
#   train_dataset = tf.keras.preprocessing.image_dataset_from_directory(
#       "path/to/your/train_images/",   # Each subfolder = one class
#       image_size=IMG_SIZE,
#       batch_size=BATCH_SIZE
#   )
#   test_dataset = tf.keras.preprocessing.image_dataset_from_directory(
#       "path/to/your/test_images/",
#       image_size=IMG_SIZE,
#       batch_size=BATCH_SIZE
#   )
#   class_names = train_dataset.class_names  # Auto-detected from folder names
#
# 🔴 CHANGE 1: Number of output classes
#       Dense(num_classes, activation='softmax')
#       loss='sparse_categorical_crossentropy'
#
# 🔴 CHANGE 2: EPOCHS - increase for small datasets (10-20+)
# =============================================================================


def run():
    print("\n=== Exp 10: Transfer Learning with MobileNetV2 on CIFAR-10 ===")

    try:
        import tensorflow as tf
        from tensorflow.keras.applications import MobileNetV2
        from tensorflow.keras.applications.mobilenet_v2 import preprocess_input
        from tensorflow.keras import layers, models
    except ImportError:
        print("  [SKIP] tensorflow not installed. Install with: pip install tensorflow")
        return

    try:
        from sklearn.metrics import classification_report, confusion_matrix
    except ImportError:
        print("  [SKIP] scikit-learn not installed. Install with: pip install scikit-learn")
        return

    # ==============================
    # 1. PARAMETERS
    # ==============================
    # MobileNetV2 requires at least 32x32; using 96x96 is faster than 224x224
    IMG_SIZE   = (96, 96)
    BATCH_SIZE = 32
    EPOCHS     = 3
    N_TRAIN    = 2000   # Use subset for speed; increase for better accuracy

    CLASS_NAMES = [
        'airplane', 'automobile', 'bird', 'cat', 'deer',
        'dog', 'frog', 'horse', 'ship', 'truck'
    ]

    # ==============================
    # 2. LOAD & PREPROCESS CIFAR-10
    # ==============================
    (x_train, y_train), (x_test, y_test) = tf.keras.datasets.cifar10.load_data()

    # Use a small subset for speed
    x_train, y_train = x_train[:N_TRAIN], y_train[:N_TRAIN]
    x_test,  y_test  = x_test[:500],      y_test[:500]

    # Resize images from 32x32 to IMG_SIZE for MobileNetV2
    x_train = tf.image.resize(x_train.astype("float32"), IMG_SIZE)
    x_test  = tf.image.resize(x_test.astype("float32"),  IMG_SIZE)

    # MobileNetV2-specific preprocessing: scales pixels to [-1, 1]
    x_train = preprocess_input(x_train)
    x_test  = preprocess_input(x_test)

    # Flatten labels from (N,1) -> (N,)
    y_train = y_train.flatten()
    y_test  = y_test.flatten()

    # ==============================
    # 3. MODEL (TRANSFER LEARNING)
    # ==============================
    # Load MobileNetV2 pre-trained on ImageNet
    # include_top=False: exclude the final 1000-class Dense layer
    base_model = MobileNetV2(
        input_shape=(IMG_SIZE[0], IMG_SIZE[1], 3),
        include_top=False,
        weights='imagenet'
    )

    # Phase 1: FREEZE the base model
    base_model.trainable = False

    model = models.Sequential([
        base_model,                              # Pre-trained MobileNetV2 feature extractor
        layers.GlobalAveragePooling2D(),         # Spatial average: (7,7,1280) -> (1280,)
        layers.Dense(10, activation='softmax')   # 10-class CIFAR-10 output
    ])

    # ==============================
    # 4. COMPILE (Phase 1)
    # ==============================
    model.compile(
        optimizer='adam',
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )

    # ==============================
    # 5. TRAIN PHASE 1 (Feature Extraction)
    # ==============================
    print("\n--- Phase 1: Feature Extraction (frozen base) ---")
    model.fit(
        x_train, y_train,
        validation_data=(x_test, y_test),
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        verbose=1
    )

    # ==============================
    # 6. FINE-TUNING (Phase 2)
    # ==============================
    base_model.trainable = True   # Unfreeze all layers

    model.compile(
        optimizer=tf.keras.optimizers.Adam(1e-5),  # Very small lr to preserve features
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )

    print("\n--- Phase 2: Fine-Tuning (unfrozen, lr=1e-5) ---")
    model.fit(
        x_train, y_train,
        validation_data=(x_test, y_test),
        epochs=2,
        batch_size=BATCH_SIZE,
        verbose=1
    )

    # ==============================
    # 7. EVALUATION
    # ==============================
    y_pred_probs = model.predict(x_test, verbose=0)
    y_pred = np.argmax(y_pred_probs, axis=1)

    print("\nClassification Report:")
    print(classification_report(y_test, y_pred, target_names=CLASS_NAMES))

    cm = confusion_matrix(y_test, y_pred)
    print("Confusion Matrix (rows=Actual, cols=Predicted):")
    # Print header
    header = "       " + "  ".join(f"{n[:4]:>4}" for n in CLASS_NAMES)
    print(header)
    for i, row in enumerate(cm):
        row_str = "  ".join(f"{v:>4}" for v in row)
        print(f"{CLASS_NAMES[i][:7]:<7}  {row_str}")