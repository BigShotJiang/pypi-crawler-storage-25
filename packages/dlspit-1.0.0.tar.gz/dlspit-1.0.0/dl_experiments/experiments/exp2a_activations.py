# =============================================================================
# EXPERIMENT 2a: Activation Functions and Loss Functions on MNIST
# =============================================================================
#
# THEORY:
# This experiment compares different combinations of activation functions and
# loss functions on the MNIST handwritten digit classification dataset.
#
# ---- MNIST Dataset ----
# 70,000 grayscale images of handwritten digits (0-9), each 28x28 pixels.
# Split: 60,000 training, 10,000 testing.
# Each image is flattened into a vector of 784 values (28*28=784).
# Pixel values normalized from [0,255] to [0,1] by dividing by 255.
#
# ---- Activation Functions ----
# 1. ReLU (Rectified Linear Unit): f(x) = max(0, x)
#       - Most popular in hidden layers
#       - Avoids vanishing gradient (unlike sigmoid/tanh for deep networks)
#       - Can suffer from "dying ReLU" if neurons output 0 permanently
#
# 2. Sigmoid: f(x) = 1 / (1 + e^(-x)) -> output in (0, 1)
#       - Used in hidden layers (older networks) or output for binary tasks
#       - Prone to vanishing gradients in deep networks
#
# 3. Tanh (Hyperbolic Tangent): f(x) = (e^x - e^(-x))/(e^x + e^(-x))
#       - Output in (-1, 1); zero-centered (better than sigmoid)
#       - Still has vanishing gradient issue in very deep nets
#
# ---- Loss Functions ----
# 1. sparse_categorical_crossentropy:
#       - Use when labels are integers (0,1,2,...,9)
#       - No need to one-hot encode labels
#       - Formula: -log(predicted_probability_of_true_class)
#
# 2. MSE (Mean Squared Error):
#       - Usually for regression, but can be used for classification
#       - Less optimal for classification (does not penalize confident wrong predictions well)
#       - Formula: mean((y_true - y_pred)^2)
#
# 3. categorical_crossentropy:
#       - Use when labels are one-hot encoded (e.g., [0,0,1,0,...,0])
#       - Same math as sparse_categorical_crossentropy but needs one-hot labels
#
# ---- One-Hot Encoding ----
# Converts integer label to binary vector.
# Example: class 3 out of 10 -> [0, 0, 0, 1, 0, 0, 0, 0, 0, 0]
# Needed for categorical_crossentropy and MSE with class labels.
#
# =============================================================================
# IF CSV DATA IS GIVEN (Multi-class classification):
#
#   import pandas as pd
#   df = pd.read_csv('your_data.csv')
#   # Assume CSV has feature columns and one 'label' column with integers 0-9
#   # Example columns: pixel_0, pixel_1, ..., pixel_783, label
#
#   X = df.drop('label', axis=1).values / 255.0   # Normalize features
#   y = df['label'].values                          # Integer labels
#
#   # Split into train/test manually:
#   from sklearn.model_selection import train_test_split
#   x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
#
#   # One-hot encode for categorical/MSE loss:
#   y_train_cat = tf.keras.utils.to_categorical(y_train, num_classes=10)
#   y_test_cat  = tf.keras.utils.to_categorical(y_test,  num_classes=10)
#
#   # CHANGE build_model() if your input size is different:
#   #   tf.keras.Input(shape=(number_of_features,))
#   # CHANGE Dense(10, ...) if you have different number of classes:
#   #   tf.keras.layers.Dense(num_classes, activation="softmax")
# =============================================================================


def run():
    print("\n=== Exp 2a: Activation Functions & Loss Functions on MNIST ===")

    try:
        import tensorflow as tf
    except ImportError:
        print("  [SKIP] tensorflow not installed. Install with: pip install tensorflow")
        return

    # ------------------------------------------------------------------
    # 1. Load MNIST dataset (built-in Keras dataset)
    #    x_train: 60000 images of shape (28,28), y_train: integer labels 0-9
    #    x_test : 10000 images of shape (28,28), y_test : integer labels 0-9
    # ------------------------------------------------------------------
    (x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()

    # ------------------------------------------------------------------
    # 2. Preprocess: Flatten + Normalize
    #    reshape(-1, 784): converts each 28x28 image -> 784-length flat vector
    #    / 255.0         : scales pixel values from [0,255] to [0.0, 1.0]
    # ------------------------------------------------------------------
    x_train = x_train.reshape(-1, 784) / 255.0
    x_test  = x_test.reshape(-1, 784) / 255.0

    # ------------------------------------------------------------------
    # 3. One-hot encode labels for losses that need them
    #    (categorical_crossentropy, MSE with class targets)
    #    y_train_cat shape: (60000, 10) - each label is a 10-dim vector
    # ------------------------------------------------------------------
    y_train_cat = tf.keras.utils.to_categorical(y_train, 10)
    y_test_cat  = tf.keras.utils.to_categorical(y_test, 10)

    # ------------------------------------------------------------------
    # 4. Model builder function
    #    act : activation function name ('relu', 'sigmoid', 'tanh')
    #    Architecture: 784 -> Dense(64, act) -> Dense(10, softmax)
    #    Softmax in output converts raw scores to class probabilities (sum=1)
    #    CHANGE 784 if your CSV has different number of features
    #    CHANGE 10  if you have a different number of classes
    # ------------------------------------------------------------------
    def build_model(act):
        return tf.keras.Sequential([
            tf.keras.Input(shape=(784,)),              # Input size = 784 features
            tf.keras.layers.Dense(64, activation=act), # Hidden layer with chosen activation
            tf.keras.layers.Dense(10, activation="softmax")  # Output: 10 class probabilities
        ])

    # List of activations and losses to compare
    activation_functions = ["relu", "sigmoid", "tanh"]
    loss_functions = ["sparse_categorical_crossentropy", "mse", "categorical_crossentropy"]

    # ------------------------------------------------------------------
    # 5. Train and evaluate all activation-loss combinations
    # ------------------------------------------------------------------
    print(f"\n{'Activation':<10} {'Loss':<35} {'Accuracy':>10}")
    print("-" * 60)
    for act in activation_functions:
        for loss in loss_functions:
            model = build_model(act)
            model.compile(optimizer="adam", loss=loss, metrics=["accuracy"])

            # ------------------------------------------------------------------
            # Choose correct label format based on loss function:
            #   sparse_categorical_crossentropy -> integer labels (y_train)
            #   mse or categorical_crossentropy -> one-hot labels (y_train_cat)
            # ------------------------------------------------------------------
            if loss == "sparse_categorical_crossentropy":
                model.fit(x_train, y_train, epochs=2, batch_size=32, verbose=0)
                acc = model.evaluate(x_test, y_test, verbose=0)[1]
            else:
                model.fit(x_train, y_train_cat, epochs=2, batch_size=32, verbose=0)
                acc = model.evaluate(x_test, y_test_cat, verbose=0)[1]

            print(f"{act:<10} {loss:<35} {acc:>10.4f}")