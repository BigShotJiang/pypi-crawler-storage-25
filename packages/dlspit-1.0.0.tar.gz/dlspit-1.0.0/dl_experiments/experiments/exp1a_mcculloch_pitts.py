# =============================================================================
# EXPERIMENT 1a: McCulloch-Pitts (MP) Neuron Model
# =============================================================================
#
# THEORY:
# The McCulloch-Pitts (MP) Neuron (1943) is the earliest mathematical model
# of a biological neuron. It is a simple binary threshold unit.
#
# How it works:
#   - Takes binary inputs (0 or 1)
#   - Each input is multiplied by a weight (can be +1 for excitatory or -1 for inhibitory)
#   - Computes a weighted sum: net = w1*x1 + w2*x2 + ...
#   - Applies a threshold function: output = 1 if net >= theta, else 0
#
# Limitations:
#   - Weights and threshold (theta) are FIXED (not learned automatically)
#   - Only works with binary inputs and binary outputs
#   - Cannot represent continuous / real-valued data
#
# This experiment implements XOR and XNOR using multi-layer MP neurons,
# demonstrating that non-linear functions need multiple neurons (layers).
#
# XOR Truth Table:    XNOR Truth Table:
#   0,0 -> 0            0,0 -> 1
#   0,1 -> 1            0,1 -> 0
#   1,0 -> 1            1,0 -> 0
#   1,1 -> 0            1,1 -> 1
#
# =============================================================================
# IF CSV DATA IS GIVEN:
# This code does NOT use any dataset (it uses hardcoded logic).
# But if you want to test MP neuron on binary inputs from a CSV file:
#
#   import pandas as pd
#   df = pd.read_csv('your_data.csv')
#   # CSV must have columns for inputs and expected output, e.g.:
#   # x1, x2, label
#   # 0,  0,   0
#   # 0,  1,   1
#   inputs = list(zip(df['x1'], df['x2']))
#   # Then call mp_neuron() or xor() / xnor() for each row
#   # NOTE: MP neuron only works with binary (0/1) inputs.
#   #       If your CSV has continuous values, you must binarize them first:
#   #       e.g., x1 = 1 if x1 > threshold else 0
# =============================================================================


def run():
    print("\n=== Exp 1a: McCulloch-Pitts Neuron (XOR & XNOR) ===")

    # Core MP Neuron function
    # x1, x2   : binary inputs (0 or 1)
    # w1, w2   : weights (positive = excitatory, negative = inhibitory)
    # theta    : threshold - if weighted sum >= theta, neuron fires (output=1)
    def mp_neuron(x1, x2, w1, w2, theta):
        # Compute weighted sum of inputs
        # If the sum meets or exceeds the threshold, neuron fires (outputs 1)
        return 1 if (w1 * x1 + w2 * x2) >= theta else 0

    # XOR Gate using 2 MP neurons in hidden layer + 1 output neuron
    # XOR is a non-linearly separable function -> needs multiple MP neurons
    def xor(x1, x2):
        # h1 fires when x1=1, x2=0  (x1 ON, x2 inhibitory)
        h1 = mp_neuron(x1, x2, 1, -1, 1)

        # h2 fires when x1=0, x2=1  (x2 ON, x1 inhibitory)
        h2 = mp_neuron(x1, x2, -1, 1, 1)

        # Output fires when either h1 OR h2 fires (but not both -> XOR)
        y = mp_neuron(h1, h2, 1, 1, 1)
        return y

    # XNOR Gate using 2 MP neurons in hidden layer + 1 output neuron
    # XNOR is the complement of XOR: outputs 1 when both inputs are same
    def xnor(x1, x2):
        # h1 fires when both x1=1 AND x2=1 (requires both: threshold=2)
        h1 = mp_neuron(x1, x2, 1, 1, 2)

        # h2 fires when both x1=0 AND x2=0 (negative weights, threshold=0)
        # -1*0 + -1*0 = 0 >= 0 -> fires; -1*1 + -1*0 = -1 < 0 -> doesn't fire
        h2 = mp_neuron(x1, x2, -1, -1, 0)

        # Output fires when either h1 OR h2 fires
        y = mp_neuron(h1, h2, 1, 1, 1)
        return y

    # All possible binary input combinations
    inputs = [(0, 0), (0, 1), (1, 0), (1, 1)]

    # Test both gates on all input combinations and print results
    print(f"{'x1':>4} {'x2':>4} {'XOR':>6} {'XNOR':>6}")
    print("-" * 24)
    for x1, x2 in inputs:
        print(f"{x1:>4} {x2:>4} {xor(x1, x2):>6} {xnor(x1, x2):>6}")