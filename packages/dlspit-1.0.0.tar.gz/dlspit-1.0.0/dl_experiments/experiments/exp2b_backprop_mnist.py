# =============================================================================
# EXPERIMENT 2b: Backpropagation on MNIST using Feedforward Neural Network
# =============================================================================
#
# THEORY:
# Backpropagation (Backprop) is the algorithm used to train neural networks.
# It computes gradients of the loss with respect to every weight in the network
# using the chain rule of calculus, then updates weights to minimize loss.
#
# ---- Forward Pass ----
# Input data flows through the network layer by layer:
#   Input (784) -> Dense(128, ReLU) -> Dense(10, Softmax) -> Predicted output
# Loss is calculated by comparing predicted output to true labels.
#
# ---- Backward Pass (Backpropagation) ----
# 1. Compute dLoss/dOutput (gradient of loss w.r.t. output layer)
# 2. Chain rule: propagate gradients backward through each layer
# 3. Each layer computes gradient w.r.t. its own weights and inputs
# 4. Weights are updated: w = w - lr * gradient
#
# ---- SGD Optimizer (Stochastic Gradient Descent) ----
# Updates weights using gradients computed on a small random batch (mini-batch).
# learning_rate=0.01: step size for each weight update.
# Smaller lr -> slower but more stable learning.
# Larger lr -> faster but may overshoot the minimum.
#
# ---- Loss Function: Sparse Categorical Cross-Entropy ----
# Used for multi-class classification with integer labels.
# Formula: -sum( y_true * log(y_pred) )
# Penalizes confident wrong predictions very harshly.
#
# ---- Softmax Output ----
# Converts raw scores (logits) to probabilities summing to 1.
# e.g., [2.1, 0.5, 1.2] -> [0.65, 0.12, 0.23]
# Predicted class = index with highest probability (argmax).
#
# =============================================================================
# IF CSV DATA IS GIVEN:
#
#   import pandas as pd
#   import numpy as np
#   df = pd.read_csv('your_data.csv')
#
#   # Assume CSV has feature columns and a 'label' column with integer class ids
#   X = df.drop('label', axis=1).values.astype('float32')
#   y = df['label'].values.astype('int32')
#
#   # Normalize features (if pixel data 0-255):
#   X = X / 255.0
#
#   # Split into train and test sets:
#   from sklearn.model_selection import train_test_split
#   x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
#
#   # CHANGE input_shape to match number of features in your CSV:
#   #   input_shape=(number_of_features,)
#   # CHANGE Dense(10, ...) to match number of classes in your data:
#   #   Dense(num_classes, activation='softmax')
#
#   # Then replace x_train, x_test, y_train, y_test below with the above.
# =============================================================================


def run():
    print("\n=== Exp 2b: Backpropagation on MNIST (SGD Feedforward NN) ===")

    try:
        import tensorflow as tf
    except ImportError:
        print("  [SKIP] tensorflow not installed. Install with: pip install tensorflow")
        return

    # ------------------------------------------------------------------
    # 1. Load MNIST dataset
    #    60,000 training images + 10,000 test images
    #    Each image: 28x28 grayscale pixels, label: integer 0-9
    # ------------------------------------------------------------------
    (x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()

    # ------------------------------------------------------------------
    # 2. Preprocess: Flatten images + Normalize pixel values
    #    reshape(-1, 784): flatten each 28x28 image into a 784-element vector
    #    / 255.0          : scale to [0, 1] range for faster, stable training
    # ------------------------------------------------------------------
    x_train = x_train.reshape(-1, 784) / 255.0
    x_test  = x_test.reshape(-1, 784) / 255.0

    # ------------------------------------------------------------------
    # 3. Define Feedforward Neural Network (Multi-Layer Perceptron)
    #    Layer 1 (Hidden): 128 neurons, ReLU activation
    #       - Learns intermediate feature representations
    #       - ReLU: avoids vanishing gradient, fast to compute
    #    Layer 2 (Output): 10 neurons, Softmax activation
    #       - 10 classes (digits 0-9), output is a probability distribution
    # ------------------------------------------------------------------
    model = tf.keras.Sequential([
        tf.keras.layers.Dense(128, activation='relu', input_shape=(784,)),  # Hidden layer
        tf.keras.layers.Dense(10, activation='softmax')                     # Output layer
    ])

    # ------------------------------------------------------------------
    # 4. Compile the model
    #    SGD optimizer with lr=0.01: classic gradient descent implementation
    #    Backpropagation computes gradients; SGD applies them to update weights
    #    loss='sparse_categorical_crossentropy': handles integer labels directly
    # ------------------------------------------------------------------
    model.compile(
        optimizer=tf.keras.optimizers.SGD(learning_rate=0.01),  # SGD: weight update rule
        loss='sparse_categorical_crossentropy',                  # Loss for multi-class
        metrics=['accuracy']                                     # Track accuracy
    )

    # ------------------------------------------------------------------
    # 5. Train the model (Backpropagation happens automatically here)
    #    epochs=5    : number of complete passes through training data
    #    batch_size=32: number of samples per gradient update (mini-batch SGD)
    #    Keras automatically runs forward pass, computes loss, runs backprop,
    #    and updates weights after each batch.
    # ------------------------------------------------------------------
    model.fit(x_train, y_train, epochs=5, batch_size=32, verbose=1)

    # ------------------------------------------------------------------
    # 6. Evaluate on test set
    #    Reports loss and accuracy on unseen data
    #    High test accuracy with low train accuracy gap = good generalization
    # ------------------------------------------------------------------
    loss, acc = model.evaluate(x_test, y_test, verbose=0)
    print(f"\nTest Loss: {loss:.4f}  |  Test Accuracy: {acc*100:.2f}%")
