# =============================================================================
# EXPERIMENT 8: Transformer for Text Classification (IMDB Sentiment)
# =============================================================================
#
# THEORY:
# The Transformer is a deep learning architecture introduced in the landmark
# paper "Attention Is All You Need" (Vaswani et al., 2017).
# Unlike RNNs/LSTMs that process sequences step-by-step, Transformers process
# ALL tokens in the sequence IN PARALLEL using the Self-Attention mechanism.
#
# ---- Self-Attention (Core idea) ----
# For every word/token in the sequence, self-attention computes how much each
# other word is "relevant" to it.
#
# Steps:
# 1. Each token's embedding is projected into 3 vectors: Query (Q), Key (K), Value (V)
# 2. Attention Score = softmax( Q * K^T / sqrt(d_k) )
#    - dot product of Q and K measures similarity between tokens
#    - divided by sqrt(d_k) to prevent very large values that saturate softmax
# 3. Output = Attention Score * V
#    - Each token's output is a weighted sum of all tokens' Values
#
# This allows the model to capture long-range dependencies in one step,
# unlike RNNs that must propagate information step-by-step.
#
# ---- Multi-Head Attention ----
# Run multiple attention "heads" in parallel, each learning different types
# of relationships (e.g., one head for syntax, another for semantics).
# Here: num_heads=2, key_dim=64
# Outputs from all heads are concatenated and projected.
#
# ---- Add & Norm (Residual Connection + Layer Normalization) ----
# After each sub-layer (attention, feedforward):
#   output = LayerNorm(input + sub_layer(input))
# The skip connection (Add) prevents vanishing gradients and stabilizes training.
# LayerNormalization: normalizes along the feature axis per sample.
#
# ---- Feedforward Sub-layer ----
# Two Dense layers applied position-wise (independently to each token):
#   Dense(64, relu) -> Dense(64)
# This adds non-linearity and increases model capacity.
#
# ---- GlobalAveragePooling1D ----
# After the Transformer block, we have a sequence of vectors (one per token).
# GlobalAveragePooling1D averages across the sequence dimension.
# Converts shape (batch, max_len, 64) -> (batch, 64) for classification.
#
# ---- Dataset: IMDB movie reviews (built-in, no file needed) ----
# 25,000 training / 25,000 test reviews, binary sentiment (0=neg, 1=pos).
# Pre-tokenized as integer sequences.
#
# =============================================================================
# IF CSV DATA IS GIVEN:
#
# Replace the IMDB loading block with:
#
#   import pandas as pd
#   df = pd.read_csv("your_data.csv")
#   texts  = df["text"].astype(str).tolist()   # 🔴 CHANGE column names
#   labels = df["label"].tolist()
#
#   # 🔴 If labels are strings (e.g., "positive"/"negative"):
#   # from sklearn.preprocessing import LabelEncoder
#   # le = LabelEncoder()
#   # labels = list(le.fit_transform(labels))
#
#   # Then tokenize:
#   tokenizer = tf.keras.preprocessing.text.Tokenizer(
#       num_words=vocab_size, oov_token="<OOV>")
#   tokenizer.fit_on_texts(texts)
#   sequences = tokenizer.texts_to_sequences(texts)
#   x_data = tf.keras.preprocessing.sequence.pad_sequences(sequences, maxlen=max_len)
#   y_data = tf.constant(labels, dtype=tf.float32)   # binary
#
# 🔴 CHANGE max_len and vocab_size to suit your dataset.
# =============================================================================


def run():
    print("\n=== Exp 8: Transformer for Text Classification (IMDB Sentiment) ===")

    try:
        import tensorflow as tf
    except ImportError:
        print("  [SKIP] tensorflow not installed. Install with: pip install tensorflow")
        return

    # ==============================
    # 1. LOAD DATASET
    # ==============================
    # Use built-in IMDB dataset: pre-tokenized integer sequences
    # num_words=10000: keep only top 10,000 most frequent words
    vocab_size = 10000
    max_len    = 100

    (x_train_raw, y_train), (x_test_raw, y_test) = (
        tf.keras.datasets.imdb.load_data(num_words=vocab_size)
    )

    # ==============================
    # 2. PREPROCESSING
    # ==============================
    # Pad/truncate all sequences to the same length (max_len)
    x_train = tf.keras.preprocessing.sequence.pad_sequences(
        x_train_raw, maxlen=max_len)
    x_test = tf.keras.preprocessing.sequence.pad_sequences(
        x_test_raw, maxlen=max_len)

    # Binary labels -> float32 for sigmoid + binary_crossentropy
    y_train = tf.cast(y_train, tf.float32)
    y_test  = tf.cast(y_test,  tf.float32)

    # ==============================
    # 3. MODEL
    # ==============================
    def build_model(vocab_size, max_len):
        # Input: sequence of max_len integer token indices
        inputs = tf.keras.Input(shape=(max_len,))

        # ---- Embedding Layer ----
        # Converts each integer token index to a dense 64-dim vector
        x = tf.keras.layers.Embedding(vocab_size, 64)(inputs)
        # x shape: (batch, max_len, 64)

        # ---- Self-Attention Block ----
        # MultiHeadAttention: 2 attention heads, each with key/query dimension of 64
        # (x, x): both query and key/value come from the same sequence = SELF-attention
        attn = tf.keras.layers.MultiHeadAttention(num_heads=2, key_dim=64)(x, x)

        # Residual Connection: add attention output to original input (skip connection)
        x = tf.keras.layers.Add()([x, attn])

        # LayerNormalization: normalizes activations for stable training
        x = tf.keras.layers.LayerNormalization()(x)

        # ---- Feedforward Block ----
        ff = tf.keras.layers.Dense(64, activation='relu')(x)
        ff = tf.keras.layers.Dense(64)(ff)

        # Residual + Norm again (standard Transformer encoder block pattern)
        x = tf.keras.layers.Add()([x, ff])
        x = tf.keras.layers.LayerNormalization()(x)

        # ---- Pooling ----
        # Average all token representations -> single vector for classification
        x = tf.keras.layers.GlobalAveragePooling1D()(x)

        # ---- Output Layer (binary) ----
        # Single sigmoid neuron outputs probability of positive sentiment
        outputs = tf.keras.layers.Dense(1, activation='sigmoid')(x)

        return tf.keras.Model(inputs, outputs)

    model = build_model(vocab_size, max_len)

    # ==============================
    # 4. COMPILE
    # ==============================
    model.compile(
        optimizer='adam',
        loss='binary_crossentropy',
        metrics=['accuracy']
    )

    # ==============================
    # 5. TRAIN
    # ==============================
    model.fit(
        x_train, y_train,
        epochs=3,
        batch_size=64,
        validation_split=0.1,
        verbose=1
    )

    # ==============================
    # 6. EVALUATE
    # ==============================
    loss, acc = model.evaluate(x_test, y_test, verbose=0)
    print(f"\nTest Loss: {loss:.4f}  |  Test Accuracy: {acc*100:.2f}%")