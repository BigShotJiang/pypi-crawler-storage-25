# =============================================================================
# EXPERIMENT 7: Long Short-Term Memory (LSTM) for Time Series Prediction
# =============================================================================
#
# THEORY:
# LSTM (Long Short-Term Memory) is a special type of RNN designed to solve the
# VANISHING GRADIENT problem found in Simple RNNs.
#
# ---- Why LSTM over Simple RNN? ----
# Simple RNN struggles to learn long-range dependencies (e.g., connecting
# a word or value from 50 steps ago to the current prediction) because
# gradients shrink exponentially during backpropagation through time.
#
# ---- LSTM Cell Structure (4 gates) ----
# Each LSTM unit has three vectors: cell state (c_t), hidden state (h_t), input (x_t)
#
# 1. Forget Gate  : f_t = sigmoid(W_f * [h_{t-1}, x_t] + b_f)
#    -> Decides what to FORGET from the previous cell state
#    -> Output in (0,1): 0 = completely forget, 1 = completely remember
#
# 2. Input Gate   : i_t = sigmoid(W_i * [h_{t-1}, x_t] + b_i)
#    g_t = tanh(W_g * [h_{t-1}, x_t] + b_g)
#    -> Decides what NEW information to add to cell state
#
# 3. Cell State Update:
#    c_t = f_t * c_{t-1} + i_t * g_t
#    -> Old memory scaled by forget gate + new info scaled by input gate
#
# 4. Output Gate  : o_t = sigmoid(W_o * [h_{t-1}, x_t] + b_o)
#    h_t = o_t * tanh(c_t)
#    -> Decides what part of cell state becomes the output hidden state
#
# ---- Time Series Forecasting ----
# Given a sequence of past values [x_{t-n}, ..., x_{t-1}], predict x_t.
# "Sliding window" approach: create overlapping windows of fixed size.
# Example with time_step=10: [1..10] -> predict 11, [2..11] -> predict 12
#
# ---- Stacked LSTM ----
# Using 2 LSTM layers (stacked) captures more complex temporal patterns.
# return_sequences=True in Layer 1: outputs hidden state at EVERY time step
# (needed as input for the second LSTM layer)
# return_sequences=False (default) in Layer 2: outputs only the LAST hidden state
#
# ---- MinMaxScaler Normalization ----
# LSTM converges much faster with normalized data in [0,1].
# Formula: x_scaled = (x - x_min) / (x_max - x_min)
# Must inverse_transform predictions back to original scale for interpretation.
#
# ---- Dataset Used: Synthetic sine wave with noise ----
# A sine wave + Gaussian noise mimics real-world time series (stock prices, etc.).
# For a real CSV: set target_col to your column name (e.g., "Close", "Temperature").
#
# =============================================================================
# IF CSV DATA IS GIVEN (changing from this default):
#
# 1. CHANGE target_col:
#       target_col = "YourColumnName"   # e.g., "Temperature", "Sales", "Price"
#
# 2. Load from CSV instead of generating synthetic data:
#       import pandas as pd
#       df = pd.read_csv("your_data.csv")
#       df["Close"] = pd.to_numeric(df["Close"], errors="coerce")
#       df = df.dropna()
#       if "Date" in df.columns:
#           df = df.sort_values(by="Date")
#       data = df[target_col].values.reshape(-1, 1)
#
# 3. CHANGE time_step (look-back window):
#       time_step = 20   # Use more past values for longer dependencies
#
# 4. For MULTIVARIATE time series:
#       data = df[['feature1', 'feature2']].values  # shape (N, num_features)
#       # CHANGE input_shape in LSTM to: (time_step, num_features)
# =============================================================================

import numpy as np


def run():
    print("\n=== Exp 7: LSTM for Time Series Prediction (Synthetic Sine Wave) ===")

    try:
        import tensorflow as tf
    except ImportError:
        print("  [SKIP] tensorflow not installed. Install with: pip install tensorflow")
        return

    try:
        from sklearn.preprocessing import MinMaxScaler
    except ImportError:
        print("  [SKIP] scikit-learn not installed. Install with: pip install scikit-learn")
        return

    # ==============================
    # 1. GENERATE SYNTHETIC DATASET
    # ==============================
    # Synthetic time-series: sine wave + Gaussian noise (mimics stock/sensor data)
    np.random.seed(42)
    time = np.arange(0, 200)
    data_values = np.sin(0.1 * time) + np.random.normal(scale=0.1, size=len(time))

    # Reshape to 2D column array required by MinMaxScaler
    data = data_values.reshape(-1, 1)

    # ==============================
    # 2. NORMALIZE DATA
    # ==============================
    # MinMaxScaler: scales all values to [0.0, 1.0] range
    # LSTM converges much faster and more reliably with normalized data
    scaler = MinMaxScaler()
    data = scaler.fit_transform(data)  # fit: learn min/max, transform: apply scaling

    # ==============================
    # 3. CREATE SEQUENCES
    # ==============================
    # Sliding window: use time_step past values to predict the next value
    time_step = 10
    print(f"  Using time_step = {time_step}")

    X, y = [], []
    for i in range(len(data) - time_step):
        X.append(data[i:i + time_step])   # Input sequence: shape (time_step, 1)
        y.append(data[i + time_step])     # Target: the value AFTER the sequence

    X = np.array(X)  # Shape: (num_samples, time_step, 1)
    y = np.array(y)  # Shape: (num_samples, 1)

    # ==============================
    # 4. TRAIN-TEST SPLIT
    # ==============================
    # NOTE: Do NOT shuffle time series data - order must be preserved!
    split = int(0.8 * len(X))
    X_train, X_test = X[:split], X[split:]
    y_train, y_test = y[:split], y[split:]

    # ==============================
    # 5. BUILD LSTM MODEL
    # ==============================
    # Stacked LSTM: 2 LSTM layers + 1 Dense output layer
    model = tf.keras.Sequential([
        # Layer 1: LSTM with 50 units
        # return_sequences=True: pass output at EVERY time step to next LSTM layer
        # input_shape=(time_step, 1): sequence of time_step steps, 1 feature per step
        # CHANGE 1 to num_features if using multivariate input
        tf.keras.layers.LSTM(50, return_sequences=True, input_shape=(time_step, 1)),

        # Layer 2: LSTM with 50 units
        # return_sequences=False (default): only output the LAST hidden state
        tf.keras.layers.LSTM(50),

        # Output Layer: Dense(1) - predict a single numeric value
        # No activation = linear output (appropriate for regression / value prediction)
        tf.keras.layers.Dense(1)
    ])

    # ==============================
    # 6. COMPILE MODEL
    # ==============================
    # MSE (Mean Squared Error): standard loss for regression tasks
    model.compile(optimizer='adam', loss='mse')

    # ==============================
    # 7. TRAIN MODEL
    # ==============================
    model.fit(X_train, y_train, epochs=10, batch_size=32, verbose=1)

    # ==============================
    # 8. PREDICT & INVERSE SCALE
    # ==============================
    pred = model.predict(X_test, verbose=0)

    # Convert predictions and actual values back from [0,1] to original scale
    pred   = scaler.inverse_transform(pred)
    y_test_orig = scaler.inverse_transform(y_test)

    # ==============================
    # 9. OUTPUT
    # ==============================
    print("\nSample Predictions vs Actual (first 5 test points):")
    print(f"{'#':>4} {'Predicted':>12} {'Actual':>12}")
    print("-" * 30)
    for i in range(min(5, len(pred))):
        print(f"{i+1:>4} {pred[i][0]:>12.4f} {y_test_orig[i][0]:>12.4f}")

    mse = float(np.mean((pred - y_test_orig) ** 2))
    print(f"\nMSE on test set: {mse:.6f}")