# =============================================================================
# EXPERIMENT 9 (GAN): Generative Adversarial Network for Image Generation
# =============================================================================
#
# THEORY:
# A GAN (Generative Adversarial Network), introduced by Ian Goodfellow (2014),
# consists of TWO neural networks competing against each other in a game:
#
#   Generator (G)     : Creates fake images from random noise
#   Discriminator (D) : Tries to distinguish real images from fake ones
#
# ---- Adversarial Training ----
# The two networks are trained simultaneously in an adversarial (competing) way:
#
# Discriminator objective:
#   - Maximize: log D(x) + log(1 - D(G(z)))
#   - Correctly classify real images as REAL (label=1)
#   - Correctly classify fake images as FAKE (label=0)
#
# Generator objective:
#   - Minimize: log(1 - D(G(z)))  -> equivalently, maximize log D(G(z))
#   - Fool the discriminator into classifying fake images as REAL
#
# At convergence (Nash Equilibrium):
#   - G produces images indistinguishable from real data
#   - D outputs 0.5 for any image (50% chance of real vs fake)
#
# ---- Generator Architecture (here) ----
# Input: random noise vector of size latent_dim=100 (sampled from N(0,1))
# Dense(128, ReLU) -> Dense(H*W*C, Sigmoid) -> Reshape(H, W, C)
# Sigmoid output: ensures pixel values are in [0,1]
#
# ---- Discriminator Architecture (here) ----
# Input: image of shape (H, W, C)
# Flatten -> Dense(128, ReLU) -> Dense(1, Sigmoid)
# Sigmoid output: probability that image is REAL (close to 1=real, 0=fake)
#
# ---- Training Loop (per epoch, per batch) ----
# Step 1: Generate fake images using Generator
# Step 2: Train Discriminator:
#           - On real images with labels=1 (real)
#           - On fake images with labels=0 (fake)
# Step 3: Train Generator (via GAN model):
#           - Freeze discriminator, train generator to fool it
#           - Pass noise through GAN, use labels=1 (want D to say "real")
#
# ---- Key Trick: Freeze Discriminator when training Generator ----
# discriminator.trainable = False
# This ensures that when we train the GAN (Generator path), only Generator
# weights are updated, not Discriminator weights.
#
# ---- Dataset: MNIST (built-in, no file needed) ----
# 60,000 handwritten digit images (28x28, grayscale), channel=1.
#
# =============================================================================
# IF YOU WANT TO USE YOUR OWN IMAGE DATASET:
#
# 🔴 CHANGE 1: Image size
#       img_size = (64, 64)   # CHANGE to match your images (e.g., 64x64, 128x128)
#
# 🔴 CHANGE 2: Color channels
#       channels = 3   # Color/RGB images (1 = grayscale)
#
# 🔴 CHANGE 3: Load images from directory instead of MNIST:
#       dataset = tf.keras.preprocessing.image_dataset_from_directory(
#           "your_image_dir/", label_mode=None,
#           image_size=img_size, batch_size=128)
#       dataset = dataset.map(lambda x: x / 255.0)
#
# 🔴 CHANGE 4: latent_dim, epochs, batch_size as needed.
# =============================================================================

import numpy as np


def run():
    print("\n=== Exp 9: GAN for Image Generation (MNIST) ===")

    try:
        import tensorflow as tf
    except ImportError:
        print("  [SKIP] tensorflow not installed. Install with: pip install tensorflow")
        return

    # ==============================
    # 1. LOAD DATASET (MNIST)
    # ==============================
    (X_train, _), _ = tf.keras.datasets.mnist.load_data()

    # Normalize [0,1] and add channel dimension -> (28,28,1)
    X_train = X_train.astype("float32") / 255.0
    X_train = np.expand_dims(X_train, axis=-1)  # Shape: (60000, 28, 28, 1)

    # Create tf.data.Dataset for efficient batching
    dataset = (
        tf.data.Dataset
        .from_tensor_slices(X_train)
        .shuffle(1000)
        .batch(128)
    )

    # ==============================
    # 2. PARAMETERS
    # ==============================
    img_size   = (28, 28)
    channels   = 1        # Grayscale; change to 3 for RGB
    latent_dim = 100      # Size of the noise vector input to Generator

    # ==============================
    # 3. GENERATOR
    # ==============================
    # Generator: random noise -> fake image
    generator = tf.keras.Sequential([
        tf.keras.Input(shape=(latent_dim,)),
        # Dense(128, relu): map noise to learned feature space
        tf.keras.layers.Dense(128, activation='relu'),
        # Dense(H*W*C, sigmoid): flat pixel values in [0,1]
        tf.keras.layers.Dense(img_size[0] * img_size[1] * channels, activation='sigmoid'),
        # Reshape back to image (H, W, C)
        tf.keras.layers.Reshape((img_size[0], img_size[1], channels))
    ])

    # ==============================
    # 4. DISCRIMINATOR
    # ==============================
    # Discriminator: image -> probability of being REAL
    discriminator = tf.keras.Sequential([
        tf.keras.layers.Flatten(input_shape=(img_size[0], img_size[1], channels)),
        tf.keras.layers.Dense(128, activation='relu'),
        # Sigmoid: close to 1 = real, close to 0 = fake
        tf.keras.layers.Dense(1, activation='sigmoid')
    ])

    # Compile Discriminator with its own optimizer
    discriminator.compile(optimizer='adam', loss='binary_crossentropy')

    # ==============================
    # 5. GAN MODEL
    # ==============================
    # When training the Generator via GAN model, freeze Discriminator weights
    discriminator.trainable = False

    gan_input  = tf.keras.Input(shape=(latent_dim,))
    fake_img   = generator(gan_input)
    gan_output = discriminator(fake_img)

    # Combined model: only Generator weights are updated during GAN training
    gan = tf.keras.Model(gan_input, gan_output)
    # Loss: Generator wants D to output 1 (fool it to think fakes are real)
    gan.compile(optimizer='adam', loss='binary_crossentropy')

    # ==============================
    # 6. TRAINING LOOP
    # ==============================
    # Increase epochs to 50+ for visually good results
    epochs = 5

    for epoch in range(epochs):
        d_loss_total = 0.0
        g_loss_total = 0.0
        n_batches = 0

        for real_imgs in dataset:
            batch_size = real_imgs.shape[0]

            # ---- Step 1: Generate fake images ----
            noise = tf.random.normal((batch_size, latent_dim))
            fake_imgs = generator.predict(noise, verbose=0)

            # ---- Step 2: Train Discriminator ----
            real_labels = tf.ones((batch_size, 1))
            fake_labels = tf.zeros((batch_size, 1))

            d_loss_real = discriminator.train_on_batch(real_imgs, real_labels)
            d_loss_fake = discriminator.train_on_batch(fake_imgs, fake_labels)
            d_loss_total += 0.5 * (d_loss_real + d_loss_fake)

            # ---- Step 3: Train Generator (via GAN) ----
            noise = tf.random.normal((batch_size, latent_dim))
            g_loss = gan.train_on_batch(noise, real_labels)
            g_loss_total += g_loss
            n_batches += 1

        avg_d = d_loss_total / n_batches
        avg_g = g_loss_total / n_batches
        print(f"  Epoch {epoch+1}/{epochs}  |  D Loss: {avg_d:.4f}  |  G Loss: {avg_g:.4f}")

    print("\nGAN training complete.")
    print("  (Increase epochs to 50+ for visually coherent digit generation)")