# =============================================================================
# EXPERIMENT 5: Transfer Learning with ResNet50 on CIFAR-10
# =============================================================================
#
# THEORY:
# Transfer Learning is a technique where a model pre-trained on a large dataset
# is reused as a starting point for a different (but related) task.
# This saves enormous training time and data requirements.
#
# ---- ResNet50 (Residual Network with 50 layers) ----
# Originally trained on ImageNet: 1.2 million images, 1000 classes.
# Key innovation of ResNet: SKIP CONNECTIONS (Residual Connections)
#
#   Normal layers: output = F(input)  [can suffer vanishing gradients in deep nets]
#   ResNet layers: output = F(input) + input  [identity skip connection]
#
# The skip connection allows gradients to flow directly backward without
# vanishing, enabling training of very deep networks (50, 101, 152 layers).
#
# ---- Transfer Learning Steps (used here) ----
# Step 1 - Feature Extraction:
#   - Load ResNet50 with pre-trained ImageNet weights
#   - Freeze all layers (base_model.trainable = False)
#   - Replace the top classifier with our own (10 classes instead of 1000)
#   - Train only the new classifier head on our dataset
#
# Step 2 - Fine-Tuning:
#   - Unfreeze all layers (base_model.trainable = True)
#   - Re-train with a very small learning rate (1e-5)
#   - Small lr: needed to avoid destroying pre-learned ImageNet features
#   - Allows the entire network to adapt to the new dataset
#
# ---- CIFAR-10 Dataset ----
# 60,000 color images (32x32 RGB) in 10 classes:
#   airplane, automobile, bird, cat, deer, dog, frog, horse, ship, truck
# ResNet50 requires input images of at least 32x32, but was designed for 224x224.
# So images are resized to (224, 224).
# Only 5000 training samples used here (for speed).
#
# ---- GlobalAveragePooling2D ----
# Replaces the Flatten layer: takes spatial average of each feature map.
# More parameter-efficient than Flatten + Dense.
# Converts shape (7, 7, 2048) -> (2048,) by averaging over spatial dims.
#
# =============================================================================
# IF CSV DATA IS GIVEN:
#
# ResNet expects IMAGE data (3-channel color images), NOT tabular CSV data.
# If your CSV contains image file paths or raw pixel values:
#
# Option A - CSV with image file paths:
#   import pandas as pd, numpy as np
#   from tensorflow.keras.preprocessing.image import load_img, img_to_array
#   df = pd.read_csv('your_data.csv')
#   # CSV columns: 'image_path', 'label'
#   images = [img_to_array(load_img(p, target_size=(224, 224))) for p in df['image_path']]
#   X = np.array(images) / 255.0
#   y = df['label'].values
#
# Option B - CSV with raw pixel values (e.g., 32x32 RGB = 3072 columns):
#   import pandas as pd, numpy as np
#   df = pd.read_csv('your_data.csv')
#   X = df.drop('label', axis=1).values.astype('float32') / 255.0
#   y = df['label'].values
#   X = X.reshape(-1, 32, 32, 3)  # CHANGE dims to match your image size
#   X = tf.image.resize(X, (224, 224))  # Resize for ResNet
#
#   # CHANGE num_classes (10) to match the number of classes in your CSV:
#   #   tf.keras.layers.Dense(num_classes, activation='softmax')
#   # CHANGE optimizer and epochs as needed.
# =============================================================================


def run():
    print("\n=== Exp 5: Transfer Learning with ResNet50 on CIFAR-10 ===")

    try:
        import tensorflow as tf
    except ImportError:
        print("  [SKIP] tensorflow not installed. Install with: pip install tensorflow")
        return

    # ------------------------------------------------------------------
    # 1. Load CIFAR-10 dataset
    #    x_train: (50000, 32, 32, 3) uint8,  y_train: (50000, 1) int
    #    x_test : (10000, 32, 32, 3) uint8,  y_test : (10000, 1) int
    #    10 classes: airplane, automobile, bird, cat, deer,
    #                dog, frog, horse, ship, truck
    # ------------------------------------------------------------------
    (x_train, y_train), (x_test, y_test) = tf.keras.datasets.cifar10.load_data()

    # ------------------------------------------------------------------
    # 2. Normalize pixel values from [0, 255] to [0.0, 1.0]
    # ------------------------------------------------------------------
    x_train, x_test = x_train / 255.0, x_test / 255.0

    # ------------------------------------------------------------------
    # 3. Use only 5000 training samples (for faster experimentation)
    #    REMOVE these two lines to train on the full 50,000 samples
    # ------------------------------------------------------------------
    x_train = x_train[:5000]
    y_train = y_train[:5000]

    # ------------------------------------------------------------------
    # 4. Resize images from (32,32) to (224,224) for ResNet50
    #    ResNet50 was designed for ImageNet which has 224x224 images
    #    tf.image.resize: interpolates pixels to new spatial dimensions
    # ------------------------------------------------------------------
    x_train = tf.image.resize(x_train, (224, 224))  # Shape: (5000, 224, 224, 3)
    x_test  = tf.image.resize(x_test, (224, 224))   # Shape: (10000, 224, 224, 3)

    # ------------------------------------------------------------------
    # 5. Load pre-trained ResNet50
    #    weights='imagenet' : load weights pre-trained on ImageNet
    #    include_top=False  : exclude the final 1000-class classification head
    #    input_shape        : must match the image dimensions + channels
    # ------------------------------------------------------------------
    base_model = tf.keras.applications.ResNet50(
        weights='imagenet',       # Pre-trained on 1.2M ImageNet images
        include_top=False,        # Remove final Dense(1000) layer
        input_shape=(224, 224, 3) # Our input shape (height, width, channels=3 RGB)
    )

    # ------------------------------------------------------------------
    # 6. Freeze base model (Feature Extraction Phase)
    #    Setting trainable=False prevents any weight updates in the base model
    #    This preserves the ImageNet knowledge during initial training
    # ------------------------------------------------------------------
    base_model.trainable = False

    # ------------------------------------------------------------------
    # 7. Add custom classifier head on top of frozen ResNet
    #    GlobalAveragePooling2D: spatial average of feature maps (2048,)
    #    Dense(10, softmax): classify into 10 CIFAR-10 classes
    #    CHANGE 10 to match the number of classes in your dataset
    # ------------------------------------------------------------------
    x = tf.keras.layers.GlobalAveragePooling2D()(base_model.output)  # Flatten spatially
    output = tf.keras.layers.Dense(10, activation='softmax')(x)       # 10-class output

    model = tf.keras.Model(base_model.input, output)

    # ------------------------------------------------------------------
    # 8. Compile for Phase 1 (Feature Extraction)
    #    Adam with default lr (0.001): trains only the new classifier head
    # ------------------------------------------------------------------
    model.compile(
        optimizer='adam',
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )

    # ------------------------------------------------------------------
    # 9. Train Phase 1: only the new Dense head is updated
    #    base model weights stay frozen (ImageNet features preserved)
    # ------------------------------------------------------------------
    print("\n--- Phase 1: Feature Extraction (frozen base) ---")
    model.fit(x_train, y_train, epochs=3, batch_size=64, verbose=1)

    # ------------------------------------------------------------------
    # 10. Fine-Tuning Phase: Unfreeze entire model
    #     Now all layers will be updated, but with a VERY small learning rate
    #     Small lr (1e-5) avoids destroying the pre-learned features while
    #     allowing the model to adapt to the new CIFAR-10 domain
    # ------------------------------------------------------------------
    base_model.trainable = True  # Allow all layers to be updated

    model.compile(
        optimizer=tf.keras.optimizers.Adam(1e-5),  # Very small lr to preserve features
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )

    # ------------------------------------------------------------------
    # 11. Train Phase 2: Fine-tune the entire network on CIFAR-10
    #     Fewer epochs needed (model is already close to good solution)
    # ------------------------------------------------------------------
    print("\n--- Phase 2: Fine-Tuning (unfrozen, lr=1e-5) ---")
    model.fit(x_train, y_train, epochs=2, batch_size=64, verbose=1)

    # ------------------------------------------------------------------
    # 12. Evaluate on full test set (10,000 images)
    # ------------------------------------------------------------------
    loss, acc = model.evaluate(x_test, y_test, verbose=0)
    print(f"\nTest Loss: {loss:.4f}  |  Test Accuracy: {acc*100:.2f}%")