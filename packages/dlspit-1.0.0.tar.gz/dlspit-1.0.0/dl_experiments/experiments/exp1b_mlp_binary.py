# =============================================================================
# EXPERIMENT 1b: Multi-Layer Perceptron (MLP) for Binary Classification
# =============================================================================
#
# THEORY:
# A Multi-Layer Perceptron (MLP) is a fully-connected feedforward neural network.
# It extends the MP Neuron by LEARNING the weights automatically via backpropagation.
#
# Architecture used here:
#   Input Layer  : 2 neurons (for 2 input features x1, x2)
#   Hidden Layer : 8 neurons with ReLU activation
#   Output Layer : 1 neuron with Sigmoid activation (binary output)
#
# Key Concepts:
#   - ReLU (Rectified Linear Unit): f(x) = max(0, x)
#       Helps avoid vanishing gradient; most common hidden-layer activation.
#   - Sigmoid: f(x) = 1 / (1 + e^(-x))
#       Squashes output to (0, 1) -> ideal for binary classification probability.
#   - Binary Cross-Entropy Loss: measures error between predicted probability
#       and true binary label (0 or 1).
#   - Adam Optimizer: adaptive learning rate optimizer; combines momentum and
#       RMSProp. Works well in practice without much tuning.
#
# Dataset here is XNOR truth table (manual, hardcoded):
#   Inputs : X = [[0,0],[1,0],[0,1],[1,1]]
#   Labels : y = [1, 0, 0, 1]   <- XNOR pattern
#
# =============================================================================
# IF CSV DATA IS GIVEN (Binary Classification):
#
#   import pandas as pd
#   df = pd.read_csv('your_data.csv')
#   # Your CSV should look like:
#   #  feature1, feature2, label
#   #  0.5,      1.2,      1
#   #  3.1,      0.8,      0
#
#   X = df[['feature1', 'feature2']].values   # shape: (n_samples, 2)
#   y = df['label'].values                     # shape: (n_samples,)
#
#   # If you have MORE than 2 features, change input_shape accordingly:
#   #   input_shape = (number_of_features,)
#   # e.g., if 5 features: input_shape = (5,)
#
#   # If you have more than 2 CLASSES, change:
#   #   - Output layer: Dense(num_classes, activation='softmax')
#   #   - Loss: 'sparse_categorical_crossentropy'
#   #   - Labels y: integer class indices (0, 1, 2, ..., num_classes-1)
#
#   # Then replace the X and y definitions below with the above.
# =============================================================================

import numpy as np


def run():
    print("\n=== Exp 1b: MLP for Binary Classification (XNOR) ===")

    try:
        import tensorflow as tf
    except ImportError:
        print("  [SKIP] tensorflow not installed. Install with: pip install tensorflow")
        return

    # ------------------------------------------------------------------
    # Dataset: XNOR truth table (binary inputs -> binary output)
    # X: input pairs, y: expected XNOR output
    # ------------------------------------------------------------------
    X = np.array([[0, 0], [1, 0], [0, 1], [1, 1]])   # shape: (4, 2)
    y = np.array([1, 0, 0, 1])                         # shape: (4,) -> XNOR labels

    # ------------------------------------------------------------------
    # Model Definition: Sequential MLP
    # ------------------------------------------------------------------
    model = tf.keras.Sequential([
        # Hidden layer: 8 neurons, ReLU activation
        # input_shape=(2,) means 2 input features
        # CHANGE input_shape if your CSV has different number of features
        tf.keras.layers.Dense(8, activation="relu", input_shape=(2,)),

        # Output layer: 1 neuron, Sigmoid -> outputs probability in (0,1)
        # For binary classification: threshold at 0.5 to get 0 or 1
        tf.keras.layers.Dense(1, activation="sigmoid")
    ])

    # ------------------------------------------------------------------
    # Compile: define optimizer, loss, and evaluation metric
    # ------------------------------------------------------------------
    model.compile(
        optimizer='adam',                   # Adam: adaptive gradient optimizer
        loss='binary_crossentropy',         # Standard loss for binary classification
        metrics=['accuracy']                # Track accuracy during training
    )

    # ------------------------------------------------------------------
    # Train the model on dataset X, y for 200 epochs (silent)
    # ------------------------------------------------------------------
    model.fit(X, y, epochs=200, verbose=0)

    # ------------------------------------------------------------------
    # Predict: get raw sigmoid probabilities and convert to binary labels
    # ------------------------------------------------------------------
    pred = model.predict(X, verbose=0)
    pred_binary = (pred > 0.5).astype(int).flatten()

    print(f"{'x1':>4} {'x2':>4} {'Label':>7} {'Pred':>6} {'Prob':>8}")
    print("-" * 35)
    for i in range(len(X)):
        x1, x2 = X[i]
        print(f"{int(x1):>4} {int(x2):>4} {y[i]:>7} {pred_binary[i]:>6} {pred[i][0]:>8.4f}")

    acc = float((pred_binary == y).mean())
    print(f"\nFinal accuracy: {acc*100:.1f}%")