# =============================================================================
# EXPERIMENT 3: Regularisation and Dropout on MNIST
# =============================================================================
#
# THEORY:
# Overfitting occurs when a model learns training data too well (including noise),
# but fails to generalize to unseen data. Signs: high train accuracy, low test accuracy.
#
# Two techniques are used here to combat overfitting:
#
# ---- 1. L2 Regularisation (Weight Decay) ----
# Adds a penalty to the loss function proportional to the SQUARE of the weights:
#   Total Loss = Original Loss + λ * sum(w²)
# where λ (lambda) = 0.001 here (the regularization strength).
#
# Effect: Discourages large weights, keeps the model "simpler".
# Large weights mean the model is overly sensitive to small input changes.
# L2 pushes weights toward zero but never exactly to zero.
#
# ---- 2. Dropout ----
# During training, randomly sets a fraction of neurons' outputs to ZERO.
# Dropout(0.5) means 50% of neurons are randomly dropped each forward pass.
#
# Why it works:
#   - Forces the network to not rely on any single neuron
#   - Each neuron must be independently useful
#   - Ensemble effect: trains many different sub-networks simultaneously
#   - During inference (prediction), all neurons are active but outputs are
#     scaled by the keep probability (1 - dropout_rate)
#
# Dropout is ONLY active during training, NOT during evaluation/prediction.
#
# ---- Validation Split ----
# validation_split=0.2 means 20% of training data is used to monitor
# overfitting during training (not used for weight updates).
#
# ---- Architecture ----
# Flatten -> Dense(128, ReLU, L2) -> Dropout(0.5) -> Dense(64, ReLU, L2)
#         -> Dropout(0.5) -> Dense(10, Softmax)
#
# =============================================================================
# IF CSV DATA IS GIVEN:
#
#   import pandas as pd
#   df = pd.read_csv('your_data.csv')
#
#   # Assume CSV has feature columns and a 'label' column (integer class index)
#   X = df.drop('label', axis=1).values.astype('float32')
#   y = df['label'].values.astype('int32')
#
#   # Normalize if values are in 0-255 range:
#   X = X / 255.0
#
#   # Split into train and test:
#   from sklearn.model_selection import train_test_split
#   x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.2)
#
#   # CHANGE the model's Flatten layer:
#   #   - If your CSV data is ALREADY FLAT (tabular, not images), REMOVE Flatten
#   #   - Replace with: tf.keras.layers.InputLayer(input_shape=(num_features,))
#   # CHANGE Dense(10, 'softmax') to match your number of classes.
#   # CHANGE lambda value (0.001) to tune regularization strength.
#   # CHANGE Dropout rate (0.5) - use 0.2 to 0.5 typically.
# =============================================================================


def run():
    print("\n=== Exp 3: Regularisation & Dropout on MNIST ===")

    try:
        import tensorflow as tf
    except ImportError:
        print("  [SKIP] tensorflow not installed. Install with: pip install tensorflow")
        return

    # ------------------------------------------------------------------
    # 1. Load MNIST dataset (60,000 train + 10,000 test images)
    #    Each image: 28x28 grayscale pixels, label: integer 0-9
    # ------------------------------------------------------------------
    (x_train, y_train), (x_test, y_test) = tf.keras.datasets.mnist.load_data()

    # ------------------------------------------------------------------
    # 2. Normalize pixel values from [0, 255] to [0.0, 1.0]
    #    Normalization helps gradient descent converge faster and more stably
    # ------------------------------------------------------------------
    x_train = x_train / 255.0
    x_test  = x_test / 255.0

    # ------------------------------------------------------------------
    # 3. Build Model with Dropout + L2 Regularization
    #
    #    Flatten(28,28) : converts 2D image (28x28) -> 1D vector (784,)
    #                     If using tabular CSV data, remove this layer.
    #
    #    Dense(128, relu, L2) : 128 neurons, ReLU activation
    #                           kernel_regularizer adds L2 penalty to loss
    #                           lambda=0.001: regularization strength
    #
    #    Dropout(0.5) : randomly zeros 50% of neuron outputs during training
    #
    #    Dense(64, relu, L2) : second hidden layer with 64 neurons + L2
    #
    #    Dense(10, softmax)  : output layer, 10 class probabilities
    # ------------------------------------------------------------------
    model = tf.keras.Sequential([
        # Flatten: convert 28x28 image to 784-length vector
        # REMOVE this layer if your CSV data is already in flat (tabular) format
        tf.keras.layers.Flatten(input_shape=(28, 28)),

        # Hidden Layer 1: 128 neurons, ReLU, with L2 regularization
        # kernel_regularizer penalizes large weight values (lambda=0.001)
        tf.keras.layers.Dense(128, activation='relu',
                              kernel_regularizer=tf.keras.regularizers.l2(0.001)),

        # Dropout Layer 1: 50% of neurons randomly dropped during each training step
        tf.keras.layers.Dropout(0.5),

        # Hidden Layer 2: 64 neurons, ReLU, with L2 regularization
        tf.keras.layers.Dense(64, activation='relu',
                              kernel_regularizer=tf.keras.regularizers.l2(0.001)),

        # Dropout Layer 2: another 50% dropout for further regularization
        tf.keras.layers.Dropout(0.5),

        # Output Layer: 10 neurons (one per digit class), Softmax for probabilities
        # CHANGE 10 to match the number of classes in your CSV dataset
        tf.keras.layers.Dense(10, activation='softmax')
    ])

    # ------------------------------------------------------------------
    # 4. Compile: optimizer + loss + metric
    #    Adam: adaptive optimizer (better than plain SGD for most cases)
    #    sparse_categorical_crossentropy: for integer class labels
    # ------------------------------------------------------------------
    model.compile(
        optimizer='adam',
        loss='sparse_categorical_crossentropy',
        metrics=['accuracy']
    )

    # ------------------------------------------------------------------
    # 5. Train with validation split
    #    validation_split=0.2: use 20% of x_train for validation monitoring
    #    This helps detect overfitting: if val_loss increases while train_loss drops
    #    epochs=5: number of full training passes through the dataset
    # ------------------------------------------------------------------
    model.fit(x_train, y_train, epochs=5, validation_split=0.2, verbose=1)

    # ------------------------------------------------------------------
    # 6. Evaluate on the held-out test set
    #    Reports final test loss and accuracy (Dropout is disabled during eval)
    # ------------------------------------------------------------------
    loss, acc = model.evaluate(x_test, y_test, verbose=0)
    print(f"\nTest Loss: {loss:.4f}  |  Test Accuracy: {acc*100:.2f}%")
