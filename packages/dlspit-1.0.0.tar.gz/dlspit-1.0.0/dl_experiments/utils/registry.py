"""Central registry mapping experiment names → run() callables."""

from ..experiments import (
    exp1a_mcculloch_pitts,
    exp1b_mlp_binary,
    exp2a_activations,
    exp2b_backprop_mnist,
    exp3_regularisation,
    exp4_cnn,
    exp5_resnet,
    exp6_rnn,
    exp7_lstm,
    exp8_transformer,
    exp9_gan,
    exp9b_vae,
    exp10_transfer,
)

EXPERIMENTS: dict[str, object] = {
    "1a": exp1a_mcculloch_pitts,
    "1b": exp1b_mlp_binary,
    "2a": exp2a_activations,
    "2b": exp2b_backprop_mnist,
    "3":  exp3_regularisation,
    "4":  exp4_cnn,
    "5":  exp5_resnet,
    "6":  exp6_rnn,
    "7":  exp7_lstm,
    "8":  exp8_transformer,
    "9":  exp9_gan,
    "9b": exp9b_vae,
    "10": exp10_transfer,
}


def list_experiments() -> list[str]:
    return list(EXPERIMENTS.keys())


def run_experiment(key: str) -> None:
    if key not in EXPERIMENTS:
        raise ValueError(f"Unknown experiment '{key}'. Available: {list_experiments()}")
    EXPERIMENTS[key].run()
