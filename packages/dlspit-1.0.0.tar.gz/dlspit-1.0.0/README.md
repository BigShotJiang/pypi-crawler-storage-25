# dl-experiments-ps07

A pip-installable collection of Deep Learning experiment modules covering
McCulloch-Pitts neurons, MLP, backpropagation, CNN, ResNet, RNN, LSTM,
Transformer, GAN, VAE, and Transfer Learning.

## Installation

```bash
# Core (NumPy only — Exp 1a, 1b, 2a, 3)
pip install dl-experiments-ps07

# With scikit-learn (Exp 2b MNIST loader)
pip install "dl-experiments-ps07[sklearn]"

# With PyTorch (Exp 4–10)
pip install "dl-experiments-ps07[torch]"

# Everything
pip install "dl-experiments-ps07[all]"
```

## Usage

### Python API

```python
import dl_experiments

# Run ALL experiments
dl_experiments.main()

# Run specific experiments
dl_experiments.main("1a")          # McCulloch-Pitts
dl_experiments.main("4", "5")     # CNN + ResNet

# List available keys
print(dl_experiments.list_experiments())
# ['1a', '1b', '2a', '2b', '3', '4', '5', '6', '7', '8', '9', '9b', '10']
```

### CLI

```bash
# Run all experiments
dl-experiments

# Run specific experiments
dl-experiments 1a 2a 3

# List available experiments
dl-experiments --list

# As a module
python -m dl_experiments 1a 1b
```

## Experiment Index

| Key | Module | Description |
|-----|--------|-------------|
| 1a  | McCulloch-Pitts | Binary threshold neuron, logic gates |
| 1b  | MLP Binary | XOR with 2-layer MLP |
| 2a  | Activations & Losses | Sigmoid, Tanh, ReLU, MSE, BCE |
| 2b  | Backprop MNIST | NumPy backprop on MNIST |
| 3   | Regularisation | L2 + Dropout |
| 4   | CNN | Conv2d + MaxPool |
| 5   | ResNet | Skip connections |
| 6   | RNN | Vanilla RNN sequence prediction |
| 7   | LSTM | Long Short-Term Memory |
| 8   | Transformer | Multi-head self-attention |
| 9   | GAN | Generator + Discriminator |
| 9b  | VAE | Variational Autoencoder |
| 10  | Transfer | Frozen backbone + custom head |

## Requirements

- Python ≥ 3.10
- numpy ≥ 1.24
- (Optional) scikit-learn ≥ 1.3 — for Exp 2b
- (Optional) torch ≥ 2.0, torchvision ≥ 0.15 — for Exp 4–10

## License

MIT