from aiel_cli.context.user_context import UserContext

ctx = UserContext().load()
print(ctx)