from __future__ import annotations

from aiel_cli.certification import case, expect, http_case, offline_eval, regression, suite


@suite(
    version="1.0",
    owner="support@aiel.test",
    critical_entry_targets=["support.flow.handle_ticket"],
    critical_http_handlers=["POST /support/tickets"],
)
class SupportFlowSuite:
    @offline_eval(name="support ticket summary", severity="medium", tags=["support", "summary"])
    def summarizes_ticket(self):
        return case(
            target="support.flow.handle_ticket",
            input={
                "ticket_id": "T-100",
                "customer_message": "I was charged twice and need a refund.",
            },
            assertions=[
                expect.path("resolution.summary").is_str(),
                expect.text("resolution.summary").contains_any("refund", "charge"),
                expect.path("resolution.actions").is_list(),
                expect.path("resolution.actions").non_empty(),
            ],
        )

    @regression(name="support create ticket handler", severity="high", tags=["support", "http"])
    def creates_ticket(self):
        return http_case(
            method="post",
            path="/support/tickets",
            body={"customer_id": "C-200", "message": "My login link expired."},
            assertions=[
                expect.path("status").equals("accepted"),
                expect.path("ticket.id").is_str(),
                expect.text("ticket.message").min_length(10),
                expect.text("ticket.message").not_contains("traceback", "exception"),
            ],
        )
