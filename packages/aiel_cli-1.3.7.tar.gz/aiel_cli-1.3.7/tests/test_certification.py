from __future__ import annotations

from pathlib import Path

import pytest

from aiel_cli.certification import case, expect, http_case, offline_eval, regression, suite
from aiel_cli.certification.discovery import discover_certification_suites
from aiel_cli.certification.models_authoring import AssertionSpec, SuiteMeta


def test_import_surface() -> None:
    assert callable(suite)
    assert callable(offline_eval)
    assert callable(regression)
    assert callable(case)
    assert callable(http_case)
    assert hasattr(expect, "path")
    assert hasattr(expect, "text")


def test_decorators_attach_metadata() -> None:
    @suite(version="1.2", owner="eng@aiel.test")
    class DemoSuite:
        @offline_eval(name="offline demo", severity="high", tags=["demo"])
        def first(self):
            return []

        @regression()
        def second(self):
            return []

    assert isinstance(DemoSuite.__aiel_suite__, SuiteMeta)
    assert DemoSuite.__aiel_suite__.owner == "eng@aiel.test"
    assert DemoSuite.first.__aiel_case_meta__["type"] == "offline_eval"
    assert DemoSuite.second.__aiel_case_meta__["severity"] == "medium"


def test_assertion_dsl_builds_assertion_specs() -> None:
    assertions = [
        expect.path("x").equals(1),
        expect.path("x").is_str(),
        expect.path("x").is_int(),
        expect.path("x").is_dict(),
        expect.path("x").is_list(),
        expect.path("x").non_empty(),
        expect.text("x").contains_any("a", "b"),
        expect.text("x").not_contains("c"),
        expect.text("x").min_length(5),
    ]
    assert all(isinstance(assertion, AssertionSpec) for assertion in assertions)
    assert assertions[0].operator == "equals"
    assert assertions[6].values == ["a", "b"]
    assert assertions[8].value == 5


def test_case_builders_normalize_payloads() -> None:
    payload = case(
        target="support.flow.handle_ticket",
        input={"message": "Need help"},
        assertions=[expect.path("status").equals("ok")],
    )
    http_payload = http_case(
        method="post",
        path="/support/tickets",
        body={"message": "Need help"},
        assertions=[expect.path("ticket.id").is_str()],
    )

    assert payload["kind"] == "case"
    assert payload["target"] == "support.flow.handle_ticket"
    assert payload["assertions"][0]["operator"] == "equals"
    assert http_payload["kind"] == "http_case"
    assert http_payload["method"] == "POST"
    assert http_payload["assertions"][0]["operator"] == "is_str"


def test_validation_errors() -> None:
    with pytest.raises(ValueError, match="severity must be one of low/medium/high/critical"):
        @offline_eval(severity="bad")
        def invalid():
            return None

    with pytest.raises(ValueError, match="case must have target"):
        case(target="", assertions=[])

    with pytest.raises(ValueError, match="http_case must have method/path"):
        http_case(method="", path="/x", assertions=[])

    with pytest.raises(ValueError, match="assertion objects must be AssertionSpec instances"):
        case(target="x", assertions=["bad"])  # type: ignore[list-item]


def test_discovery_finds_example_certification_suite() -> None:
    repo_root = Path(__file__).resolve().parent.parent
    discovered = discover_certification_suites(repo_root)

    assert discovered
    support_suite = next(item for item in discovered if item["suite_class"] == "SupportFlowSuite")
    assert support_suite["suite_meta"]["owner"] == "support@aiel.test"
    assert len(support_suite["cases"]) == 2
    case_names = {item["meta"]["name"] for item in support_suite["cases"]}
    assert "support ticket summary" in case_names
    assert "support create ticket handler" in case_names
