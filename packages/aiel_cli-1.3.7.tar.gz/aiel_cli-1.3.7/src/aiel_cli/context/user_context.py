from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Optional, Union

from ..auth.credentials import (
    Profile as CredentialsProfile,
    _current_profile,
    _get_me,
    _get_profile,
    get_current_base_url,
    list_profiles,
    resolve_token,
)


@dataclass(frozen=True)
class UserContextData:
    logged_in: bool
    token: Optional[str]
    token_source: Optional[str]
    profile: str
    base_url: Optional[str]
    user: Optional[str]
    user_id: Optional[str]
    tenant: Optional[str]
    workspace: Optional[dict[str, Any]]
    workspace_id: Optional[str]
    project: Optional[dict[str, Any]]
    project_id: Optional[str]
    me: Optional[dict[str, Any]]


class UserContext:
    def __init__(self, profile: Optional[Union[str, CredentialsProfile]] = None) -> None:
        self.profile = profile

    def _profile_name(self, data: dict[str, Any]) -> str:
        if isinstance(self.profile, str) and self.profile:
            return self.profile
        if self.profile is not None:
            name = getattr(self.profile, "name", None)
            if isinstance(name, str) and name:
                return name
        return _current_profile(data)

    def load(self, fetch_remote: bool = False, strict: bool = False) -> UserContextData:
        data = list_profiles()
        profile_name = self._profile_name(data)
        prof = _get_profile(data, profile_name)

        resolved = resolve_token()
        if isinstance(resolved, tuple):
            token, token_source = resolved
        else:
            token, token_source = (resolved, None)

        logged_in = bool(token)
        if strict and not logged_in:
            raise RuntimeError("Not logged in. Run: aiel auth login")

        base_url = prof.get("base_url") or get_current_base_url()
        user = prof.get("user")
        tenant = prof.get("tenant")
        workspace = prof.get("workspace")
        project = prof.get("project")
        workspace_id = workspace.get("id") if isinstance(workspace, dict) else None
        project_id = project.get("id") if isinstance(project, dict) else None

        me: Optional[dict[str, Any]] = None
        user_id: Optional[str] = None
        if fetch_remote and logged_in:
            me = _get_me(prof)
            user_id = me.get("id") or me.get("user_id")
            if not user:
                user = me.get("email") or user_id
            if not tenant:
                tenant = me.get("tenant_name") or me.get("tenant")

        return UserContextData(
            logged_in=logged_in,
            token=token,
            token_source=token_source,
            profile=profile_name,
            base_url=base_url,
            user=user,
            user_id=user_id,
            tenant=tenant,
            workspace=workspace,
            workspace_id=workspace_id,
            project=project,
            project_id=project_id,
            me=me,
        )
