
import os
from typing import Any, Optional

import httpx
import typer

from .config import settings
from .utilities import read_json, write_json
from .errors import CliError
from .auth.credentials import list_profiles, _current_profile, _get_profile, get_current_base_url
# -------------------------
# API client (DP)
# -------------------------

def _token() -> str:
    tok = os.getenv("AIEL_TOKEN")
    if tok:
        return tok

    # Lazily import to avoid import cycle; credentials already depends on data_plane.
    from .auth.credentials import resolve_token

    resolved = resolve_token()
    token: Optional[str]
    if isinstance(resolved, tuple):
        token = resolved[0]
    else:
        token = resolved

    if token:
        return token

    raise typer.BadParameter("Missing credentials. Run `aiel auth login` or set the AIEL_TOKEN env var.")

def _headers() -> dict[str, str]:
    return {
        "X-API-Token": _token(),
        "X-Client": "aiel-cli",
    }

def _state() -> dict[str, Any]:
    return read_json(settings.STATE_PATH, {})

def _integrations_state() -> dict[str, Any]:
    return read_json(settings.INTEGRATIOS_PATH, {})


def _base_ws_proj() -> tuple[str, str, str]:
    s = _state()

    data = list_profiles()
    profiles = data.get("profiles") or {}
    prof = None
    if profiles:
        current = _current_profile(data)
        prof = _get_profile(data, current)

    base_url = None
    if prof:
        base_url = prof.get("base_url")
    if not base_url:
        base_url = s.get("base_url") or get_current_base_url()
    if not base_url:
        raise CliError(
            "Missing base_url for the active profile.",
            hint="Run `aiel auth login` to select or create a profile.",
        )

    ws = s.get("workspace_id")
    proj = s.get("project_id")
    if not ws and prof:
        ws = (prof.get("workspace") or {}).get("id")
    if not proj and prof:
        proj = (prof.get("project") or {}).get("id")

    if not ws or not proj:
        raise CliError(
            "Workspace or project is not configured.",
            hint="Run `aiel config set workspace <slug>` before repo operations.",
        )

    return base_url.rstrip("/"), ws, proj

def _dp_get_manifest(client: httpx.Client) -> dict[str, Any]:
    base_url, ws, proj = _base_ws_proj()
    r = client.get(f"{base_url}/v1/workspaces/{ws}/projects/{proj}/integrations", headers=_headers())
    r.raise_for_status()
    return r.json()


def _dp_get_resource_manifest(client: httpx.Client, provider:str='') -> dict[str, Any]:
    integrations = _integrations_state()
    prov = integrations.get(provider)
    # print(integrations)
    if prov is None:
        return {
            "ok":False,
            "provider_id": None,
            "message": "Provider was not found. Make sure the provider exists and update the integration by running <aiel integration update>"
        }
    else:
        base_url, ws, proj = _base_ws_proj()
        cnn_id = prov.get("connection_id")
        r = client.get(f"{base_url}/v1/workspaces/{ws}/projects/{proj}/integrations/{cnn_id}", headers=_headers())
        r.raise_for_status()
        connector = r.json()
        return  {
            "ok":True,
           **connector
        }

def _dp_resource_check(client: httpx.Client, provider:str='', payload=dict[str, Any]) -> dict[str, Any]:
    integrations = _integrations_state()
    prov = integrations.get(provider)
    # print(integrations)
    if prov is None:
        return {
            "ok":False,
            "error": "WRONG_MISSING_PROVIDER",
            "data": ""
        }
    else:
        base_url, ws, proj = _base_ws_proj()
        cnn_id = prov.get("connection_id")
        r = client.post(f"{base_url}/v1/workspaces/{ws}/projects/{proj}/integrations/{cnn_id}/health-check", json=payload,headers=_headers())
        r.raise_for_status()
        connector = r.json()
        return  {
            "ok":connector['ok'],
            "error": connector['error'],
            "data": connector['data']
        }


   
    # base_url, ws, proj = _base_ws_proj()
    # r = client.get(f"{base_url}/v1/workspaces/{ws}/projects/{proj}/integrations", headers=_headers())
    # r.raise_for_status()
    # return r.json()


def _manifest_to_map(manifest: dict[str, Any]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for f in manifest:
        # selected_data[f["provider"]] = f.get('provider')
        out[f["provider"]] = {
            "connection_id": f.get('connection_id'),
            "connector": (f.get("connector") or {}).get("version"),
            "provider" : f.get('provider'),
            "capabilities" : f.get('capabilities'),
            "allowed_actions" : f.get('allowed_actions'),
            "granted_actions" : f.get('granted_actions'),
            "metadata" : f.get('metadata')
        }
    return out


def integrations_compact(manifest: list[dict[str, Any]]) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for item in manifest or []:
        provider = item.get("provider")
        if not provider:
            continue
        out[provider] = {
            "connection_id": item.get("connection_id"),
            "provider": provider,
            "connector": item.get("connector"),
            "capabilities": item.get("capabilities") or [],
        }
    return out
