from __future__ import annotations

from typing import Any, Dict, List, Optional, Tuple

from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()

# Conservative: redact anything that *looks* secret-ish.
_SENSITIVE_SUBSTRINGS = (
    "token",
    "secret",
    "password",
    "pass",
    "private",
    "key",
    "authorization",
    "access_token",
    "refresh_token",
    "client_secret",
    "api_key",
)

# Keys that tend to identify an integration instance (generic, cross-provider).
_PREFERRED_ID_KEYS = (
    "name",
    "account",
    "org",
    "organization",
    "tenant",
    "workspace",
    "url",
    "base_url",
    "site_url",
    "domain",
    "host",
    "hostname",
    "project",
    "repo",
    "repository",
    "dbname",
    "database",
    "cluster",
    "cloud_id",
    "instance",
    "region",
)


def _is_sensitive_key(k: str) -> bool:
    lk = (k or "").lower()
    return any(s in lk for s in _SENSITIVE_SUBSTRINGS)


def _short(s: Any, max_len: int = 44) -> str:
    txt = str(s)
    return txt if len(txt) <= max_len else (txt[: max_len - 1] + "…")


def _short_id(s: Optional[str], n: int = 8) -> str:
    if not s:
        return "-"
    return s[:n]


def _flatten_dict(d: Dict[str, Any], prefix: str = "", max_depth: int = 2) -> List[Tuple[str, Any]]:
    """Flatten nested dicts for display heuristics (limited depth)."""
    out: List[Tuple[str, Any]] = []
    if not isinstance(d, dict) or max_depth < 0:
        return out

    for k in sorted(d.keys()):
        v = d[k]
        key = f"{prefix}.{k}" if prefix else str(k)
        if isinstance(v, dict) and max_depth > 0:
            out.extend(_flatten_dict(v, key, max_depth - 1))
        else:
            out.append((key, v))
    return out


def _score_preview_item(k: str, v: Any) -> int:
    lk = (k or "").lower()

    if _is_sensitive_key(lk):
        return -10_000
    if v in (None, "", [], {}):
        return -1_000

    score = 0

    # Prefer identity-ish keys
    leaf = lk.split(".")[-1]
    if leaf in (x.lower() for x in _PREFERRED_ID_KEYS):
        score += 500

    sv = str(v).lower()

    # URLs/hosts/domains are highly helpful
    if "://" in sv or ("/" in sv and "cloudsql" in sv) or "." in sv:
        score += 120

    # IDs can help but shouldn't dominate
    if leaf.endswith("_id") or leaf == "id":
        score += 40

    # Prefer shorter values in summary
    score -= min(len(str(v)), 200) // 4
    return score


def _metadata_preview(md: Dict[str, Any], max_pairs: int = 2) -> str:
    if not md or not isinstance(md, dict):
        return "-"

    flat = _flatten_dict(md, max_depth=2)
    flat = [(k, v) for k, v in flat if (not _is_sensitive_key(k)) and v not in (None, "", [], {})]
    if not flat:
        return "-"

    ranked = sorted(flat, key=lambda kv: _score_preview_item(kv[0], kv[1]), reverse=True)

    chosen: List[Tuple[str, Any]] = []
    used_roots: set[str] = set()

    for k, v in ranked:
        root = k.split(".")[-1].lower()
        if root in used_roots:
            continue
        chosen.append((k, v))
        used_roots.add(root)
        if len(chosen) >= max_pairs:
            break

    if not chosen:
        return "-"

    return ", ".join(f"{k.split('.')[-1]}={_short(v)}" for k, v in chosen)


def _redact_value(k: str, v: Any) -> str:
    return "[redacted]" if _is_sensitive_key(k) else str(v)


def _build_summary_table(
    *,
    title: str,
) -> Table:
    t = Table(title=title, show_lines=False)
    t.add_column("Provider", style="bold")
    t.add_column("Version")
    t.add_column("Capabilities", justify="right")
    t.add_column("Actions", justify="right")
    t.add_column("Preview")
    t.add_column("Conn", justify="right")
    return t


def _add_summary_row(
    t: Table,
    *,
    provider: str,
    it: Dict[str, Any],
    preview_pairs: int,
) -> None:
    version = it.get("connector") or "-"
    caps = it.get("capabilities") or []
    allowed = it.get("allowed_actions") or []
    granted = it.get("granted_actions") or []
    md = it.get("metadata") or {}
    conn = it.get("connection_id")

    actions_ratio = f"{len(granted)}/{len(allowed)}"
    preview = _metadata_preview(md, max_pairs=preview_pairs)

    t.add_row(
        provider,
        str(version),
        str(len(caps)),
        actions_ratio,
        preview,
        _short_id(conn),
    )


def _build_provider_panel(
    *,
    provider: str,
    it: Dict[str, Any],
) -> Panel:
    version = it.get("connector") or "-"
    conn = it.get("connection_id") or "-"

    caps: List[str] = sorted(it.get("capabilities") or [])
    allowed: List[str] = sorted(it.get("allowed_actions") or [])
    granted: List[str] = sorted(it.get("granted_actions") or [])
    md: Dict[str, Any] = it.get("metadata") or {}

    missing = sorted(set(allowed) - set(granted))

    grid = Table.grid(padding=(0, 1))
    grid.add_column(style="bold")
    grid.add_column()

    grid.add_row("Provider", provider)
    grid.add_row("Version", str(version))
    grid.add_row("Connection", conn)
    grid.add_row("Actions", f"{len(granted)}/{len(allowed)} granted")

    caps_table = Table(title="Capabilities", show_header=False, box=None)
    caps_table.add_column()
    if caps:
        for c in caps:
            caps_table.add_row(f"• {c}")
    else:
        caps_table.add_row("—")

    actions_table = Table(title="Actions", show_header=True)
    actions_table.add_column("Granted", style="green")
    actions_table.add_column("Missing", style="yellow")

    max_rows = max(len(granted), len(missing), 1)
    for i in range(max_rows):
        g = f"✓ {granted[i]}" if i < len(granted) else ""
        m = f"• {missing[i]}" if i < len(missing) else ""
        actions_table.add_row(g, m)

    md_table = Table(title="Metadata", show_header=True)
    md_table.add_column("Key", style="dim")
    md_table.add_column("Value")
    if md:
        for k, v in _flatten_dict(md, max_depth=2):
            md_table.add_row(k, _redact_value(k, v))
    else:
        md_table.add_row("—", "—")

    body = Table.grid(padding=1)
    body.add_row(grid)
    body.add_row(caps_table)
    body.add_row(actions_table)
    body.add_row(md_table)

    return Panel(body, title=provider, border_style="cyan")


def format_integrations_rich(
    integrations_by_provider: Dict[str, Dict[str, Any]],
    *,
    title: str = "Integrations",
    show_details: bool = True,
    preview_pairs: int = 2,
) -> None:
    """
    Shared formatter for integration list output.

    Expected input shape per provider:
      {
        "connection_id": str|None,
        "connector": str|dict|None,
        "capabilities": [str],
        "allowed_actions": [str],
        "granted_actions": [str],
        "metadata": dict
      }
    """
    integrations_by_provider = integrations_by_provider or {}

    summary = _build_summary_table(title=title)

    for provider in sorted(integrations_by_provider.keys()):
        it = integrations_by_provider.get(provider) or {}
        _add_summary_row(summary, provider=provider, it=it, preview_pairs=preview_pairs)
    
    console.print(summary)
    if not show_details:
        return

    for provider in sorted(integrations_by_provider.keys()):
        it = integrations_by_provider.get(provider) or {}
        console.print(_build_provider_panel(provider=provider, it=it))


def format_integration_rich(
    provider: str,
    integration: Dict[str, Any],
    *,
    title: Optional[str] = None,
    show_details: bool = True,
    preview_pairs: int = 2,
) -> None:
    """
    Same approach as format_integrations_rich, but for a single provider.
    """
    provider = provider or "-"
    it = integration or {}

    summary = _build_summary_table(title=title or "Integration")
    _add_summary_row(summary, provider=provider, it=it, preview_pairs=preview_pairs)
    console.print(summary)

    if not show_details:
        return

    console.print(_build_provider_panel(provider=provider, it=it))


def format_integration_from_dict_rich(
    integrations_by_provider: Dict[str, Dict[str, Any]],
    provider: str,
    *,
    title: Optional[str] = None,
    show_details: bool = True,
    preview_pairs: int = 2,
    show_available_on_error: bool = True,
) -> None:
    """
    Convenience wrapper: given the full dict and a provider key, render only that integration.
    Prints a friendly error if provider is missing.
    """
    integrations_by_provider = integrations_by_provider or {}
    provider_key = (provider or "").strip()

    if not provider_key or provider_key not in integrations_by_provider:
        available = ", ".join(sorted(integrations_by_provider.keys())) or "-"
        msg = "Provider not found."
        if show_available_on_error:
            msg += f" Available: {available}"
        console.print(f"[bold red]Error:[/bold red] {msg}")
        return

    format_integration_rich(
        provider_key,
        integrations_by_provider[provider_key] or {},
        title=title or f"Integration: {provider_key}",
        show_details=show_details,
        preview_pairs=preview_pairs,
    )


def format_integration_check(integration:dict[str, any], provider:str = None, show_details: bool = True,) -> None:
    """Show the command roadmap and sprint plan."""
    # for cont, items in integration.items():
    #     data = {cont: items}
    #     print(data)
        # print(items)
    table = Table(title=f"Provider {provider} integration status")
    table.add_column("Provider", style="bold")
    table.add_column("ok")
    table.add_column("error", justify="right")
    status = f"[bold green]Success[/bold green]" if integration.get('ok') else f"[bold red]Fail[/bold red]" 
    table.add_row(provider, status, integration.get('error'))
    console.print(table)

    
    if show_details:
        details = integration.get('data') or None
        grid = Table(title=f"Integration Details for {provider}")
        if details:
            keys = list(details.keys())
            for k in keys:
                grid.add_column(str(k), style="bold")
        
        grid.add_row(*[str(details[k]) for k in keys])
        console.print(grid)
        


