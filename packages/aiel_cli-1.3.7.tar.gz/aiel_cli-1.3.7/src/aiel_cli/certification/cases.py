from __future__ import annotations

from typing import Any

from .errors import CertificationValidationError
from .models_authoring import AssertionSpec, CaseSpec


def _normalize_assertions(assertions: list[AssertionSpec] | None) -> list[AssertionSpec]:
    normalized: list[AssertionSpec] = []
    for assertion in assertions or []:
        if isinstance(assertion, AssertionSpec):
            normalized.append(assertion)
            continue
        raise CertificationValidationError("assertion objects must be AssertionSpec instances")
    return normalized


def case(
    *,
    target: str,
    input: Any = None,
    assertions: list[AssertionSpec] | None = None,
    execution_expectations: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if not target:
        raise CertificationValidationError("case must have target")
    spec = CaseSpec(
        kind="case",
        target=target,
        input=input,
        assertions=_normalize_assertions(assertions),
        execution_expectations=execution_expectations,
    )
    return spec.model_dump(exclude_none=True)


def http_case(
    *,
    method: str,
    path: str,
    body: Any = None,
    query: dict[str, Any] | None = None,
    assertions: list[AssertionSpec] | None = None,
    execution_expectations: dict[str, Any] | None = None,
) -> dict[str, Any]:
    if not method or not path:
        raise CertificationValidationError("http_case must have method/path")
    spec = CaseSpec(
        kind="http_case",
        method=method.upper(),
        path=path,
        body=body,
        query=query,
        assertions=_normalize_assertions(assertions),
        execution_expectations=execution_expectations,
    )
    return spec.model_dump(exclude_none=True)
