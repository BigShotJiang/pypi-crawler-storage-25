from __future__ import annotations

import importlib.util
import inspect
import sys
from pathlib import Path
from types import ModuleType
from typing import Any

from .errors import CertificationDiscoveryError


def _load_module(path: Path) -> ModuleType:
    module_name = f"_aiel_certification_{path.stem}_{abs(hash(path.resolve()))}"
    spec = importlib.util.spec_from_file_location(module_name, path)
    if spec is None or spec.loader is None:
        raise CertificationDiscoveryError(f"unable to load module from {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[module_name] = module
    try:
        spec.loader.exec_module(module)
    except Exception as exc:  # pragma: no cover
        raise CertificationDiscoveryError(f"failed to execute certification module {path}") from exc
    return module


def discover_certification_suites(root: str | Path = ".") -> list[dict[str, Any]]:
    root_path = Path(root)
    discovered: list[dict[str, Any]] = []
    for path in sorted((root_path / "certification").glob("test_*.py")):
        module = _load_module(path)
        discovered.extend(_collect_from_module(module, path))
    return discovered


def _collect_from_module(module: ModuleType, path: Path) -> list[dict[str, Any]]:
    suites: list[dict[str, Any]] = []
    for _, cls in inspect.getmembers(module, inspect.isclass):
        suite_meta = getattr(cls, "__aiel_suite__", None)
        if suite_meta is None or cls.__module__ != module.__name__:
            continue
        instance = cls()
        cases: list[dict[str, Any]] = []
        for _, method in inspect.getmembers(instance, predicate=callable):
            case_meta = getattr(method, "__aiel_case_meta__", None)
            if case_meta is None:
                continue
            payload = method()
            if isinstance(payload, list):
                normalized_payload = payload
            else:
                normalized_payload = [payload]
            cases.append({"meta": case_meta, "payloads": normalized_payload})
        suites.append(
            {
                "module": str(path),
                "suite_class": cls.__name__,
                "suite_meta": suite_meta.model_dump(),
                "cases": cases,
            }
        )
    return suites
