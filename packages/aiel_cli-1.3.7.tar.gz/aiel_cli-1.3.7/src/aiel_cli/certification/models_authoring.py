from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator


SEVERITIES = {"low", "medium", "high", "critical"}


class SuiteMeta(BaseModel):
    version: str
    owner: str
    trace_required: bool = True
    critical_entry_targets: list[str] = Field(default_factory=list)
    critical_http_handlers: list[str] = Field(default_factory=list)


class AssertionSpec(BaseModel):
    kind: Literal["path", "text"]
    selector: str
    operator: str
    value: Any | None = None
    values: list[Any] | None = None


class CaseSpec(BaseModel):
    kind: Literal["case", "http_case"]
    target: str | None = None
    method: str | None = None
    path: str | None = None
    input: Any | None = None
    body: Any | None = None
    query: dict[str, Any] | None = None
    assertions: list[AssertionSpec] = Field(default_factory=list)
    execution_expectations: dict[str, Any] | None = None
    name: str | None = None
    severity: str = "medium"
    tags: list[str] = Field(default_factory=list)

    @field_validator("severity")
    @classmethod
    def validate_severity(cls, value: str) -> str:
        if value not in SEVERITIES:
            raise ValueError("severity must be one of low/medium/high/critical")
        return value
