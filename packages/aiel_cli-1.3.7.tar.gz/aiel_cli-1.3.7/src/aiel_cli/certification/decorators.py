from __future__ import annotations

from typing import Any, Callable, TypeVar

from .models_authoring import SEVERITIES, SuiteMeta

T = TypeVar("T")


def suite(
    version: str,
    owner: str,
    trace_required: bool = True,
    critical_entry_targets: list[str] | None = None,
    critical_http_handlers: list[str] | None = None,
) -> Callable[[type[T]], type[T]]:
    def decorator(cls: type[T]) -> type[T]:
        meta = SuiteMeta(
            version=version,
            owner=owner,
            trace_required=trace_required,
            critical_entry_targets=critical_entry_targets or [],
            critical_http_handlers=critical_http_handlers or [],
        )
        setattr(cls, "__aiel_suite__", meta)
        return cls

    return decorator


def _case_decorator(
    case_type: str,
    name: str | None = None,
    severity: str = "medium",
    tags: list[str] | None = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    if severity not in SEVERITIES:
        raise ValueError("severity must be one of low/medium/high/critical")

    def decorator(func: Callable[..., Any]) -> Callable[..., Any]:
        setattr(
            func,
            "__aiel_case_meta__",
            {
                "type": case_type,
                "name": name or func.__name__,
                "severity": severity,
                "tags": list(tags or []),
            },
        )
        return func

    return decorator


def offline_eval(
    name: str | None = None,
    severity: str = "medium",
    tags: list[str] | None = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    return _case_decorator("offline_eval", name=name, severity=severity, tags=tags)


def regression(
    name: str | None = None,
    severity: str = "medium",
    tags: list[str] | None = None,
) -> Callable[[Callable[..., Any]], Callable[..., Any]]:
    return _case_decorator("regression", name=name, severity=severity, tags=tags)
