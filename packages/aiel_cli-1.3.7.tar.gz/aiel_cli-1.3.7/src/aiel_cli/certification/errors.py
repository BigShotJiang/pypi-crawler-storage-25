from __future__ import annotations


class CertificationError(ValueError):
    """Base error for certification authoring helpers."""


class CertificationValidationError(CertificationError):
    """Raised when authoring inputs are invalid."""


class CertificationDiscoveryError(CertificationError):
    """Raised when discovery cannot load or execute a certification module."""
