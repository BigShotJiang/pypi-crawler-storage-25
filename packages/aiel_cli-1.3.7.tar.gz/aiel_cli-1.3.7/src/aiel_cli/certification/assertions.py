from __future__ import annotations

from typing import Any

from .models_authoring import AssertionSpec


class _PathExpectation:
    def __init__(self, selector: str) -> None:
        self.selector = selector

    def equals(self, value: Any) -> AssertionSpec:
        return AssertionSpec(kind="path", selector=self.selector, operator="equals", value=value)

    def is_str(self) -> AssertionSpec:
        return AssertionSpec(kind="path", selector=self.selector, operator="is_str")

    def is_int(self) -> AssertionSpec:
        return AssertionSpec(kind="path", selector=self.selector, operator="is_int")

    def is_dict(self) -> AssertionSpec:
        return AssertionSpec(kind="path", selector=self.selector, operator="is_dict")

    def is_list(self) -> AssertionSpec:
        return AssertionSpec(kind="path", selector=self.selector, operator="is_list")

    def non_empty(self) -> AssertionSpec:
        return AssertionSpec(kind="path", selector=self.selector, operator="non_empty")


class _TextExpectation:
    def __init__(self, selector: str) -> None:
        self.selector = selector

    def contains_any(self, *values: str) -> AssertionSpec:
        return AssertionSpec(kind="text", selector=self.selector, operator="contains_any", values=list(values))

    def not_contains(self, *values: str) -> AssertionSpec:
        return AssertionSpec(kind="text", selector=self.selector, operator="not_contains", values=list(values))

    def min_length(self, value: int) -> AssertionSpec:
        return AssertionSpec(kind="text", selector=self.selector, operator="min_length", value=value)


class _ExpectFactory:
    def path(self, selector: str) -> _PathExpectation:
        return _PathExpectation(selector)

    def text(self, selector: str) -> _TextExpectation:
        return _TextExpectation(selector)


expect = _ExpectFactory()
