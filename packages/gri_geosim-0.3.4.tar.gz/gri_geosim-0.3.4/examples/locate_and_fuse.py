#!/usr/bin/env python3
"""Geolocation pipeline example: observations -> locate -> smart_convolve.

This example demonstrates the full pipeline:
1. Generate observations from scenario
2. Convert observations to ellipsoids using locate()
3. Combine ellipsoids with smart_convolve() (iterative outlier rejection)

Requires: gri-utils, gri-ell, gri-convolve (install with pip install gri-geosim[all])
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from gri_nsepoch import Time
from gri_pos import Pos

from gri_geosim import Emitter, MonteCarlo, Platform, Scenario
from gri_geosim.sensors import TdoaSensor

if TYPE_CHECKING:
    from gri_ell import Ell

# =============================================================================
# Scenario Setup
# =============================================================================

# Set up 4 ground stations for TDOA
ground1 = Platform(Pos.LLA(38.0, -77.0, 100.0), name="GND1")
ground2 = Platform(Pos.LLA(38.5, -76.5, 100.0), name="GND2")
ground3 = Platform(Pos.LLA(37.5, -76.0, 100.0), name="GND3")
ground4 = Platform(Pos.LLA(38.0, -76.0, 100.0), name="GND4")

# TDOA measurement noise: 10 nanoseconds standard deviation
# This corresponds to ~3 meters of range error (c * 10ns = 3m)
TDOA_NOISE_NS = 10.0
TDOA_NOISE_S = TDOA_NOISE_NS * 1e-9

# Create TDOA sensor pairs (need 3 TDOAs for 3D position)
# Each sensor measures time difference between GND1 and another station
tdoa_12 = TdoaSensor("tdoa_12", tdoa_std_s=TDOA_NOISE_S)
ground1.add_sensor(tdoa_12)
tdoa_12.set_paired_platform(ground2)

tdoa_13 = TdoaSensor("tdoa_13", tdoa_std_s=TDOA_NOISE_S)
ground1.add_sensor(tdoa_13)
tdoa_13.set_paired_platform(ground3)

tdoa_14 = TdoaSensor("tdoa_14", tdoa_std_s=TDOA_NOISE_S)
ground1.add_sensor(tdoa_14)
tdoa_14.set_paired_platform(ground4)

# Create emitter (true position)
true_position = Pos.LLA(38.2, -76.5, 5000.0)
target = Emitter(
    true_position,
    name="TARGET",
    frequency_hz=1.0e9,
)

# Create scenario
scenario = Scenario.for_instant(
    platforms=[ground1, ground2, ground3, ground4],
    emitters=[target],
)

observation_time = Time.from_str("2024-01-15T12:00:00Z")

# =============================================================================
# Print Setup Information
# =============================================================================

print("=" * 60)
print("SCENARIO SETUP")
print("=" * 60)

print("\nGround Station Positions:")
for name, platform in [
    ("GND1", ground1),
    ("GND2", ground2),
    ("GND3", ground3),
    ("GND4", ground4),
]:
    pos = platform.position_at(observation_time)
    print(f"  {name}: {pos.lla}")

print(f"\nEmitter (true position): {true_position.lla}")

print("\nTDOA Sensor Configuration:")
print(f"  Noise: {TDOA_NOISE_NS:.1f} ns (σ)")
print(f"  Range equivalent: {TDOA_NOISE_NS * 0.3:.1f} m (c × σ)")
print("  Pairs: GND1-GND2, GND1-GND3, GND1-GND4")

# =============================================================================
# Monte Carlo Simulation
# =============================================================================

print("\n" + "=" * 60)
print("MONTE CARLO SIMULATION")
print("=" * 60)

# Run Monte Carlo: each iteration adds fresh Gaussian noise to TDOA measurements
mc = MonteCarlo(scenario, n_iterations=50)
mc_result = mc.run_at(observation_time)

print(f"\nIterations: {mc_result.n_iterations}")
print("Each iteration draws new noise samples from N(0, σ²) for each TDOA measurement")

# =============================================================================
# Geolocation
# =============================================================================

print("\n" + "=" * 60)
print("GEOLOCATION RESULTS")
print("=" * 60)

try:
    from gri_geosim import locate

    # Locate from each Monte Carlo iteration
    # Note: observations are self-contained with collector positions embedded
    ellipsoids: list[Ell] = []
    for iteration_result in mc_result.observations_by_iteration():
        try:
            ell = locate(iteration_result)
            ellipsoids.append(ell)
        except Exception as e:
            print(f"Locate failed: {e}")

    print(
        f"\nGenerated {len(ellipsoids)} ellipsoids from {mc_result.n_iterations} iterations",
    )

    if ellipsoids:
        # Show sample ellipsoid
        sample_ell = ellipsoids[0]
        print("\nSample ellipsoid (first iteration):")
        print(f"  Position: {sample_ell.lla}")
        print(f"  SMA (m): {sample_ell.ellipse.sma_95:.1f}")

except ImportError:
    print("\ngri-utils not available, skipping locate()")
    ellipsoids = []

# =============================================================================
# Combine Ellipsoids with smart_convolve
# =============================================================================

if ellipsoids:
    try:
        from gri_convolve import smart_convolve

        # smart_convolve iteratively removes outliers based on Mahalanobis distance
        # Returns (solution, used_indices, discarded_indices) or None if too few remain
        result = smart_convolve(ellipsoids, max_norm=2.0, min_pts=3)
        if result is not None:
            solution, used_indices, discarded_indices = result
            print("\nCombined result (smart_convolve with outlier rejection):")
            print(f"  Position: {solution.lla}")
            print(f"  SMA (m): {solution.ellipse.sma_95:.1f}")
            print(f"  Used: {len(used_indices)}/{len(ellipsoids)} ellipsoids")
            if discarded_indices:
                print(f"  Discarded: {len(discarded_indices)} outliers")
        else:
            print("\nCombination failed (too few inliers)")

    except ImportError:
        print("\ngri-convolve not available, skipping smart_convolve()")
