#!/usr/bin/env python3
"""Atmospheric effects example: tropospheric and ionospheric delays.

This example demonstrates:
- Configuring atmospheric delay models
- Comparing observations with and without atmospheric effects
- Ground-based emitter with LEO satellite collectors

The scenario uses a ground emitter observed by two LEO satellites at different
elevations. Lower elevation paths traverse more atmosphere, producing larger
differential delays.

Requires: gri-tropo, gri-iono (install with pip install gri-geosim[atmosphere])
"""

from __future__ import annotations

from gri_nsepoch import Time
from gri_pos import Pos

from gri_geosim import Emitter, Platform, Scenario
from gri_geosim.atmosphere import AtmosphereConfig, IonoModel
from gri_geosim.sensors import TdoaSensor

# Ground-based emitter (radar transmitter)
emitter_lla = Pos.LLA(38.0, -77.0, 100.0)  # Near Washington DC, 100m elevation
target = Emitter(
    emitter_lla,
    name="GROUND_TX",
    frequency_hz=1.575e9,  # GPS L1 frequency
)

# Create LEO satellite collectors using AER from emitter position
# Different elevations will show different atmospheric path lengths
sat1_aer = (45.0, 25.0, 800_000.0)  # Az=45°, El=25°, Range=800km (lower elevation)
sat2_aer = (135.0, 60.0, 600_000.0)  # Az=135°, El=60°, Range=600km (higher elevation)

sat1_pos = emitter_lla.translate_aer(sat1_aer)
sat2_pos = emitter_lla.translate_aer(sat2_aer)

# Create satellite platforms
sat1 = Platform(sat1_pos, name="LEO1")
sat2 = Platform(sat2_pos, name="LEO2")

# Create TDOA sensor on sat1, paired with sat2
tdoa = TdoaSensor("tdoa_12", tdoa_std_s=1e-12)  # Very small std; noise disabled below
sat1.add_sensor(tdoa)
tdoa.set_paired_platform(sat2)

# Print scenario geometry
print("Scenario Geometry:")
print(f"  Emitter:  {emitter_lla.lla}")
print(f"  LEO1:     {sat1_pos.lla}")
print(
    f"    AER from emitter: Az={sat1_aer[0]:.1f}°, El={sat1_aer[1]:.1f}°, R={sat1_aer[2] / 1000:.0f}km",
)
print(f"  LEO2:     {sat2_pos.lla}")
print(
    f"    AER from emitter: Az={sat2_aer[0]:.1f}°, El={sat2_aer[1]:.1f}°, R={sat2_aer[2] / 1000:.0f}km",
)
print()

scenario = Scenario.for_instant(
    platforms=[sat1, sat2],
    emitters=[target],
)

observation_time = Time.from_str("2024-01-15T12:00:00Z")

# Run without atmospheric effects
result_no_atmo = scenario.simulate_at(observation_time, add_noise=False)
tdoa_no_atmo = result_no_atmo[0].value

print("TDOA Comparison (no measurement noise):")
print(f"  Without atmosphere: {tdoa_no_atmo * 1e9:+.4f} ns")

# Run with tropospheric effects only
tropo_config = AtmosphereConfig(enable_tropo=True, enable_iono=False)
try:
    result_tropo = scenario.simulate_at(
        observation_time,
        add_noise=False,
        atmosphere=tropo_config,
    )
    tdoa_tropo = result_tropo[0].value
    tropo_effect = (tdoa_tropo - tdoa_no_atmo) * 1e9
    print(
        f"  With troposphere:   {tdoa_tropo * 1e9:+.4f} ns (Δ = {tropo_effect:+.4f} ns)",
    )
except ImportError:
    print("  Troposphere: gri-tropo not installed")

# Run with ionospheric effects only (Bent model - fast)
iono_bent_config = AtmosphereConfig(
    enable_tropo=False,
    enable_iono=True,
    iono_model=IonoModel.BENT,
)
try:
    result_iono = scenario.simulate_at(
        observation_time,
        add_noise=False,
        atmosphere=iono_bent_config,
    )
    tdoa_iono = result_iono[0].value
    iono_effect = (tdoa_iono - tdoa_no_atmo) * 1e9
    print(
        f"  With ionosphere:    {tdoa_iono * 1e9:+.4f} ns (Δ = {iono_effect:+.4f} ns)",
    )
except ImportError:
    print("  Ionosphere: gri-iono not installed")

# Run with both effects
full_config = AtmosphereConfig(
    enable_tropo=True,
    enable_iono=True,
    iono_model=IonoModel.BENT,
)
try:
    result_full = scenario.simulate_at(
        observation_time,
        add_noise=False,
        atmosphere=full_config,
    )
    tdoa_full = result_full[0].value
    full_effect = (tdoa_full - tdoa_no_atmo) * 1e9
    print(
        f"  With both effects:  {tdoa_full * 1e9:+.4f} ns (Δ = {full_effect:+.4f} ns)",
    )
except ImportError:
    print("  Full atmosphere: gri-tropo and/or gri-iono not installed")

print()
print("Note: Differential delays depend on path geometry.")
print(
    f"  LEO1 (El={sat1_aer[1]:.0f}°) has longer atmospheric path than LEO2 (El={sat2_aer[1]:.0f}°)",
)
print("  Lower elevation = more atmosphere traversed = larger delay")
