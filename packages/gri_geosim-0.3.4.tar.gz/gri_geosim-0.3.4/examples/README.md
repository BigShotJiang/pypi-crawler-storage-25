# gri-geosim Examples

This directory contains example scripts demonstrating gri-geosim capabilities.

## Examples

### basic_scenario.py

Multi-platform AOA scenario with diverse platform types. Demonstrates:

- Ground-based emitters (stationary and moving aircraft)
- Multiple platform types: ground stations, aircraft, LEO satellite
- AOA sensor orientation: ENU for ground/aircraft, nadir for space-based
- Direction cosines (u, v) for space-based sensors vs azimuth/elevation for ground
- Single-instant simulation with `Scenario.for_instant()`

### tdoa_scenario.py

TDOA scenario with paired platforms. Demonstrates:

- 4 satellite platforms (LEO and HEO orbits)
- 3 TDOA sensor pairs with `set_paired_platform()`
- Ground emitter geolocation
- Time difference observations

### monte_carlo.py

Monte Carlo simulation for statistical analysis. Demonstrates:

- `MonteCarlo` wrapper around `Scenario`
- Running multiple noise realizations
- Computing statistics across runs
- Comparing noisy vs ideal observations

### locate_and_fuse.py

Full geolocation pipeline from observations to position estimate. Demonstrates:

- Generating observations from scenario
- Converting observations to ellipsoids with `locate()`
- Combining ellipsoids with `smart_convolve()` (outlier rejection)
- Accessing position uncertainty (CEP, covariance)

**Requires**: `pip install gri-geosim[all]`

### atmosphere_effects.py

Atmospheric delay effects on observations. Demonstrates:

- `AtmosphereConfig` for tropospheric and ionospheric delays
- Comparing observations with/without atmospheric effects
- Different ionospheric models (BENT, IRI, NEQUICK2, NEQUICKG)
- Differential atmospheric delays in TDOA

**Requires**: `pip install gri-geosim[atmosphere]`

### multi_platform_geo.py

Complex multi-platform geolocation with hybrid observations. Demonstrates:

- Diverse platforms: 2 LEO satellites, 1 HEO satellite, 1 aircraft
- Hybrid observations: AOA + TDOA + FDOA combined
- Using `Pos.translate_aer()` to position satellites at desired geometry
- Using `gri_utils.orbit.from_circular()` to create orbital elements
- Multi-time-point simulation (geolocation at 3 times, 30 seconds apart)
- Full geolocation with `locate()` including error analysis

### comprehensive_scenario.py

**Recommended starting point.** A comprehensive example demonstrating nearly all gri-geosim capabilities in a single, well-documented script. Demonstrates:

- **Platforms**: 2 LEO satellites (Keplerian orbits), 1 HEO satellite (at apogee), 1 aircraft (waypoint trajectory)
- **Sensors**: AOA (nadir for space, ENU for aircraft), TDOA (LEO-LEO and LEO-HEO pairs), FDOA (aircraft-satellite pairs)
- **FOV constraints**: ConeFov for satellites, ElevationMaskFov for aircraft
- **Atmosphere**: Tropospheric and ionospheric corrections (BENT model)
- **Geolocation**: Single-instant locate() with error analysis (miss distance, containment check)
- **Monte Carlo**: Statistical analysis with 100 iterations
- **Ellipsoid combination**: smart_convolve() with iterative outlier rejection
- **Analysis**: Containment rate verification, miss distance statistics

**Requires**: `pip install gri-geosim[all]` (includes gri-ell, gri-tropo, gri-iono)

## Running Examples

```bash
# Basic examples (no extra dependencies)
python examples/basic_scenario.py
python examples/tdoa_scenario.py
python examples/monte_carlo.py

# Examples requiring gri-ell for ellipsoids
pip install gri-geosim[all]
python examples/locate_and_fuse.py
python examples/multi_platform_geo.py

# Examples requiring atmospheric corrections
pip install gri-geosim[atmosphere]
python examples/atmosphere_effects.py

# Comprehensive example (recommended starting point)
pip install gri-geosim[all]
python examples/comprehensive_scenario.py
```

## Trajectory Types Used

| Example                   | Trajectories Used                                             |
| ------------------------- | ------------------------------------------------------------- |
| basic_scenario.py         | StationaryTrajectory, WaypointTrajectory, Sgp4Trajectory      |
| tdoa_scenario.py          | StationaryTrajectory, KeplerianTrajectory                     |
| monte_carlo.py            | StationaryTrajectory                                          |
| locate_and_fuse.py        | StationaryTrajectory                                          |
| atmosphere_effects.py     | StationaryTrajectory, KeplerianTrajectory                     |
| multi_platform_geo.py     | StationaryTrajectory, WaypointTrajectory, KeplerianTrajectory |
| comprehensive_scenario.py | StationaryTrajectory, WaypointTrajectory, KeplerianTrajectory |

## Sensor Types Used

| Example                   | Sensors Used                      |
| ------------------------- | --------------------------------- |
| basic_scenario.py         | AoaSensor                         |
| tdoa_scenario.py          | TdoaSensor                        |
| monte_carlo.py            | AoaSensor                         |
| locate_and_fuse.py        | AoaSensor, TdoaSensor             |
| atmosphere_effects.py     | TdoaSensor                        |
| multi_platform_geo.py     | AoaSensor, TdoaSensor, FdoaSensor |
| comprehensive_scenario.py | AoaSensor, TdoaSensor, FdoaSensor |
