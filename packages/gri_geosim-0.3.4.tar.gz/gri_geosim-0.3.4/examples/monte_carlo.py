#!/usr/bin/env python3
"""Monte Carlo simulation example.

This example demonstrates:
- Running multiple noise realizations
- Computing observation statistics across runs
- Comparing noisy vs ideal observations
"""

from __future__ import annotations

from gri_nsepoch import Time
from gri_pos import Pos

from gri_geosim import Emitter, MonteCarlo, Platform, Scenario, filter_aoa, filter_tdoa
from gri_geosim.sensors import AoaSensor, TdoaSensor

# =============================================================================
# Scenario Setup
# =============================================================================

# Set up platforms
ground1 = Platform(Pos.LLA(38.0, -77.0, 100.0), name="GND1")
ground2 = Platform(Pos.LLA(38.5, -76.5, 100.0), name="GND2")
ground3 = Platform(Pos.LLA(37.5, -76.0, 100.0), name="GND3")

# Sensor noise parameters
AOA_AZ_STD_RAD = 0.001  # ~0.057 degrees
AOA_EL_STD_RAD = 0.002  # ~0.115 degrees
TDOA_STD_NS = 10.0  # 10 nanoseconds
TDOA_STD_S = TDOA_STD_NS * 1e-9

# Add AOA sensor to ground1
ground1.add_sensor(
    AoaSensor("aoa1", azimuth_std_rad=AOA_AZ_STD_RAD, elevation_std_rad=AOA_EL_STD_RAD),
)

# Add TDOA sensors
tdoa_12 = TdoaSensor("tdoa_12", tdoa_std_s=TDOA_STD_S)
ground1.add_sensor(tdoa_12)
tdoa_12.set_paired_platform(ground2)

tdoa_13 = TdoaSensor("tdoa_13", tdoa_std_s=TDOA_STD_S)
ground1.add_sensor(tdoa_13)
tdoa_13.set_paired_platform(ground3)

# Create emitter
target = Emitter(
    Pos.LLA(38.2, -76.8, 8000.0),
    name="TARGET",
    frequency_hz=1.5e9,
)

# Create scenario
scenario = Scenario.for_instant(
    platforms=[ground1, ground2, ground3],
    emitters=[target],
)

observation_time = Time.from_str("2024-01-15T12:00:00Z")

# =============================================================================
# Print Setup Information
# =============================================================================

print("=" * 60)
print("SCENARIO SETUP")
print("=" * 60)

print("\nGround Station Positions:")
for name, platform in [("GND1", ground1), ("GND2", ground2), ("GND3", ground3)]:
    pos = platform.position_at(observation_time)
    print(f"  {name}: {pos.lla}")

print(f"\nEmitter: {target.position_at(observation_time).lla}")

print("\nSensor Configuration:")
print(f"  AOA noise: az={AOA_AZ_STD_RAD:.4f} rad, el={AOA_EL_STD_RAD:.4f} rad")
print(f"  TDOA noise: {TDOA_STD_NS:.1f} ns (σ)")

# =============================================================================
# Monte Carlo Simulation
# =============================================================================

print("\n" + "=" * 60)
print("MONTE CARLO SIMULATION")
print("=" * 60)

# Create Monte Carlo wrapper and run
N_ITERATIONS = 100
mc = MonteCarlo(scenario, n_iterations=N_ITERATIONS)
result = mc.run_at(observation_time)

print(f"\nIterations: {result.n_iterations}")
print("Each iteration draws new noise samples for each sensor measurement")

# =============================================================================
# Statistics by Sensor Type
# =============================================================================

print("\n" + "=" * 60)
print("OBSERVATION STATISTICS")
print("=" * 60)

# Get statistics for TDOA observations
tdoa_stats = result.compute_statistics(obs_type="TDOA")
print("\nTDOA Observations:")
print(f"  Iterations: {tdoa_stats['n_iterations']}")
print(f"  Observations per iteration: {tdoa_stats['n_observations']}")
print(f"  Mean (ns): {tdoa_stats['mean'] * 1e9}")
print(f"  Std (ns):  {tdoa_stats['std'] * 1e9}")

# Get statistics for AOA observations
aoa_stats = result.compute_statistics(obs_type="AOA")
print("\nAOA Observations:")
print(f"  Iterations: {aoa_stats['n_iterations']}")
print(f"  Observations per iteration: {aoa_stats['n_observations']}")
print(f"  Mean (rad): {aoa_stats['mean']}")
print(f"  Std (rad):  {aoa_stats['std']}")

# =============================================================================
# Compare Noisy vs Ideal
# =============================================================================

print("\n" + "=" * 60)
print("IDEAL VS NOISY COMPARISON")
print("=" * 60)

# Get ideal (noise-free) observations
ideal_result = mc.run_ideal_at(observation_time)

print("\nIdeal (noise-free) observations:")
for obs in filter_aoa(ideal_result):
    az_deg = obs.azimuth * 180 / 3.14159
    el_deg = obs.elevation * 180 / 3.14159
    print(f"  {obs.sensor_id}: az={az_deg:.2f}°, el={el_deg:.2f}°")
for obs in filter_tdoa(ideal_result):
    print(f"  {obs.sensor_id}: {obs.value * 1e9:.4f} ns")

# Show a few noisy samples
N_SAMPLES = 3
print(f"\nSample noisy observations (first {N_SAMPLES} iterations):")
for i, iteration_result in enumerate(result.observations_by_iteration()):
    if i >= N_SAMPLES:
        break
    print(f"\n  Iteration {i + 1}:")
    for obs in filter_tdoa(iteration_result):
        print(f"    {obs.sensor_id}: {obs.value * 1e9:.4f} ns")
    for obs in filter_aoa(iteration_result):
        az_deg = obs.azimuth * 180 / 3.14159
        el_deg = obs.elevation * 180 / 3.14159
        print(f"    {obs.sensor_id}: az={az_deg:.2f}°, el={el_deg:.2f}°")
