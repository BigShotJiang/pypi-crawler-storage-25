"""Tests for MonteCarlo simulation wrapper.

Tests verify Monte Carlo execution with multiple iterations.
"""

from __future__ import annotations

import numpy as np
import pytest
from gri_nsepoch import Time
from gri_pos import Pos

from gri_geosim import Emitter, MonteCarlo, Platform, Scenario
from gri_geosim.sensors import AoaSensor

_POS1 = Pos.LLA(38.0, -77.0, 100.0)
_TARGET_POS = Pos.LLA(38.5, -76.5, 0.0)
_START = Time(s=0.0)
_END = Time(s=10.0)


def _make_scenario() -> Scenario:
    """Create a simple scenario for testing."""
    scenario = Scenario(_START, _END)

    platform = Platform(_POS1, name="P1")
    platform.add_sensor(AoaSensor("aoa"))
    scenario.add_platform(platform)

    scenario.add_emitter(Emitter(_TARGET_POS, name="Target"))

    return scenario


# Initialization


def test_creates_with_scenario() -> None:
    """Verify MonteCarlo creates with scenario."""
    scenario = _make_scenario()
    mc = MonteCarlo(scenario)

    assert mc.scenario is scenario


def test_default_iterations() -> None:
    """Verify default iteration count is 100."""
    mc = MonteCarlo(_make_scenario())

    assert mc.n_iterations == 100


def test_custom_iterations() -> None:
    """Verify custom iteration count is used."""
    mc = MonteCarlo(_make_scenario(), n_iterations=50)

    assert mc.n_iterations == 50


@pytest.mark.parametrize(
    "n_iterations",
    [0, -1, -100],
    ids=["zero", "negative", "large_negative"],
)
def test_rejects_non_positive_iterations(n_iterations: int) -> None:
    """Verify MonteCarlo rejects non-positive iteration count."""
    with pytest.raises(ValueError, match="positive"):
        MonteCarlo(_make_scenario(), n_iterations=n_iterations)


# run_at


def test_run_at_generates_results() -> None:
    """Verify run_at generates results for each iteration."""
    mc = MonteCarlo(_make_scenario(), n_iterations=5)

    result = mc.run_at(_START)

    assert result.n_iterations == 5


def test_run_at_override_iterations() -> None:
    """Verify run_at can override iteration count."""
    mc = MonteCarlo(_make_scenario(), n_iterations=100)

    result = mc.run_at(_START, n_iterations=3)

    assert result.n_iterations == 3


def test_run_at_progress_callback() -> None:
    """Verify run_at calls progress callback."""
    mc = MonteCarlo(_make_scenario(), n_iterations=3)
    progress_calls: list[tuple[int, int]] = []

    def callback(current: int, total: int) -> None:
        progress_calls.append((current, total))

    mc.run_at(_START, progress_callback=callback)

    # Should be called for 0, 1, 2, 3 (final completion)
    assert len(progress_calls) == 4
    assert progress_calls[-1] == (3, 3)


# run


def test_run_generates_results() -> None:
    """Verify run generates results for time range."""
    mc = MonteCarlo(_make_scenario(), n_iterations=3)

    result = mc.run()

    assert result.n_iterations == 3


def test_run_override_iterations() -> None:
    """Verify run can override iteration count."""
    mc = MonteCarlo(_make_scenario(), n_iterations=100)

    result = mc.run(n_iterations=2)

    assert result.n_iterations == 2


# run_ideal


def test_run_ideal_no_noise() -> None:
    """Verify run_ideal produces noise-free results."""
    mc = MonteCarlo(_make_scenario())

    result1 = mc.run_ideal()
    result2 = mc.run_ideal()

    # Noise-free should be identical
    assert len(result1) == len(result2)
    # First observations should match
    if result1 and result2:
        assert np.allclose(result1[0].value, result2[0].value)


def test_run_ideal_at() -> None:
    """Verify run_ideal_at produces single-instant results."""
    mc = MonteCarlo(_make_scenario())

    result = mc.run_ideal_at(_START)

    # Returns a list of observations
    assert isinstance(result, list)
    assert len(result) > 0


# Result variations


def test_noisy_results_vary() -> None:
    """Verify noisy Monte Carlo results vary between iterations."""
    mc = MonteCarlo(_make_scenario(), n_iterations=10)

    result = mc.run_at(_START)

    # Get observations from different iterations
    obs_values = [it[0].value for it in result.results]

    # Not all should be identical (statistical test)
    values = np.array(obs_values)
    assert np.std(values) > 0  # Some variation expected


# String representation


def test_repr() -> None:
    """Verify string representation."""
    mc = MonteCarlo(_make_scenario(), n_iterations=50)

    assert "MonteCarlo" in repr(mc)
    assert "50" in repr(mc)


def test_str() -> None:
    """Verify human-readable string."""
    mc = MonteCarlo(_make_scenario(), n_iterations=50)

    assert "50" in str(mc)
