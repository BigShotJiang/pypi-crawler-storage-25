"""Tests for FDOA geolocation solver.

Tests the three operating modes:
1. Unconstrained (position + velocity) - limited accuracy due to coupling
2. Fixed velocity (position only) - excellent position accuracy
3. Fixed position (velocity only) - excellent velocity accuracy
"""

from __future__ import annotations

import numpy as np
import pytest
from gri_utils.observables import get_fdoa

from gri_geosim.geolocation import fdoa_locator

# Test geometry constants
EARTH_RADIUS = 6378137.0
LEO_ALT = 600_000.0
LEO_VELOCITY = 7500.0


def _leo_velocity(position: np.ndarray, inclination_deg: float) -> np.ndarray:
    """Compute LEO orbital velocity perpendicular to position vector."""
    r_hat = position / np.linalg.norm(position)
    incl = np.radians(inclination_deg)
    if abs(r_hat[2]) < 0.9:
        perp = np.cross(r_hat, np.array([0.0, 0.0, 1.0]))
    else:
        perp = np.cross(r_hat, np.array([1.0, 0.0, 0.0]))
    perp = perp / np.linalg.norm(perp)
    v_hat = perp * np.cos(incl) + np.cross(r_hat, perp) * np.sin(incl)
    return v_hat * LEO_VELOCITY


def _create_geometry(
    n_collectors: int = 6,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Create LEO collector geometry with ground target.

    Uses 3D distributed positions for good observability.

    Returns:
        Tuple of (collector_xyz, collector_vel, target_xyz, target_vel).
    """
    r = EARTH_RADIUS + LEO_ALT
    inclinations = [0.0, 30.0, 45.0, 60.0, 75.0, 90.0][:n_collectors]

    # 3D distributed collectors (not coplanar)
    positions = [
        [r, 0.0, 0.0],
        [r * 0.866, r * 0.5, 0.0],
        [r * 0.866, 0.0, r * 0.5],
        [r * 0.707, r * 0.5, r * 0.5],
        [r * 0.707, -r * 0.5, r * 0.5],
        [r * 0.5, r * 0.707, r * 0.5],
    ][:n_collectors]

    collector_xyz = np.array(positions)
    collector_vel = np.array(
        [
            _leo_velocity(pos, incl)
            for pos, incl in zip(collector_xyz, inclinations, strict=True)
        ],
    )

    # Stationary ground target
    target_xyz = np.array([EARTH_RADIUS, 0.0, 0.0])
    target_vel = np.zeros(3)

    return collector_xyz, collector_vel, target_xyz, target_vel


def _make_pairs(
    collector_xyz: np.ndarray,
    collector_vel: np.ndarray,
) -> tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Create all unique collector pairs."""
    n = len(collector_xyz)
    pairs = [(i, j) for i in range(n) for j in range(i + 1, n)]
    c1 = np.array([collector_xyz[i] for i, _ in pairs])
    c2 = np.array([collector_xyz[j] for _, j in pairs])
    v1 = np.array([collector_vel[i] for i, _ in pairs])
    v2 = np.array([collector_vel[j] for _, j in pairs])
    return c1, c2, v1, v2


def _compute_fdoas(
    target_xyz: np.ndarray,
    target_vel: np.ndarray,
    c1: np.ndarray,
    c2: np.ndarray,
    v1: np.ndarray,
    v2: np.ndarray,
    freq_hz: float,
) -> np.ndarray:
    """Compute FDOA measurements for all pairs."""
    return np.array(
        [
            get_fdoa(
                target_xyz,
                target_vel,
                c1[i],
                c2[i],
                freq_hz,
                collector1_vel=v1[i],
                collector2_vel=v2[i],
            )
            for i in range(len(c1))
        ],
    )


# =============================================================================
# Fixed Velocity Mode (position estimation)
# =============================================================================


def test_fixed_velocity_stationary_target() -> None:
    """Position estimation with known zero velocity achieves sub-meter accuracy."""
    collector_xyz, collector_vel, target_true, vel_true = _create_geometry()
    c1, c2, v1, v2 = _make_pairs(collector_xyz, collector_vel)
    freq_hz = 1e9

    fdoas = _compute_fdoas(target_true, vel_true, c1, c2, v1, v2, freq_hz)
    variances = np.full(len(fdoas), 0.1**2)

    result = fdoa_locator(
        c1,
        c2,
        fdoas,
        variances,
        freq_hz,
        collector1_vel=v1,
        collector2_vel=v2,
        fix_velocity=np.zeros(3),
    )

    pos_error = np.linalg.norm(result.position - target_true)
    assert pos_error < 1.0, f"Position error {pos_error:.6f}m exceeds 1m"
    assert np.allclose(result.velocity, vel_true)
    assert result.covariance.shape == (3, 3)


def test_fixed_velocity_moving_target() -> None:
    """Position estimation with known non-zero velocity achieves sub-meter accuracy."""
    collector_xyz, collector_vel, target_true, _ = _create_geometry()
    vel_true = np.array([100.0, 50.0, 0.0])  # Aircraft velocity
    c1, c2, v1, v2 = _make_pairs(collector_xyz, collector_vel)
    freq_hz = 1e9

    fdoas = _compute_fdoas(target_true, vel_true, c1, c2, v1, v2, freq_hz)
    variances = np.full(len(fdoas), 0.1**2)

    result = fdoa_locator(
        c1,
        c2,
        fdoas,
        variances,
        freq_hz,
        collector1_vel=v1,
        collector2_vel=v2,
        fix_velocity=vel_true,
    )

    pos_error = np.linalg.norm(result.position - target_true)
    assert pos_error < 1.0, f"Position error {pos_error:.6f}m exceeds 1m"
    assert np.allclose(result.velocity, vel_true)
    assert result.covariance.shape == (3, 3)


def test_fixed_velocity_minimum_measurements() -> None:
    """Position-only mode works with 3 measurements, sub-meter accuracy."""
    collector_xyz, collector_vel, target_true, vel_true = _create_geometry(4)
    # Use only first 3 pairs
    c1, c2, v1, v2 = _make_pairs(collector_xyz, collector_vel)
    c1, c2, v1, v2 = c1[:3], c2[:3], v1[:3], v2[:3]
    freq_hz = 1e9

    fdoas = _compute_fdoas(target_true, vel_true, c1, c2, v1, v2, freq_hz)
    variances = np.full(3, 0.1**2)

    result = fdoa_locator(
        c1,
        c2,
        fdoas,
        variances,
        freq_hz,
        collector1_vel=v1,
        collector2_vel=v2,
        fix_velocity=vel_true,
    )

    pos_error = np.linalg.norm(result.position - target_true)
    assert pos_error < 1.0, f"Position error {pos_error:.6f}m exceeds 1m"
    assert result.covariance.shape == (3, 3)


# =============================================================================
# Fixed Position Mode (velocity estimation)
# =============================================================================


def test_fixed_position_stationary_target() -> None:
    """Velocity estimation with known position achieves sub-mm/s accuracy."""
    collector_xyz, collector_vel, target_true, vel_true = _create_geometry()
    c1, c2, v1, v2 = _make_pairs(collector_xyz, collector_vel)
    freq_hz = 1e9

    fdoas = _compute_fdoas(target_true, vel_true, c1, c2, v1, v2, freq_hz)
    variances = np.full(len(fdoas), 0.1**2)

    result = fdoa_locator(
        c1,
        c2,
        fdoas,
        variances,
        freq_hz,
        collector1_vel=v1,
        collector2_vel=v2,
        fix_position=target_true,
    )

    vel_error = np.linalg.norm(result.velocity - vel_true)
    assert vel_error < 0.001, f"Velocity error {vel_error:.6f}m/s exceeds 1mm/s"
    assert np.allclose(result.position, target_true)
    assert result.covariance.shape == (3, 3)


def test_fixed_position_moving_target() -> None:
    """Velocity estimation for aircraft-speed target achieves sub-mm/s accuracy."""
    collector_xyz, collector_vel, target_true, _ = _create_geometry()
    vel_true = np.array([250.0, 100.0, 10.0])  # Fast aircraft
    c1, c2, v1, v2 = _make_pairs(collector_xyz, collector_vel)
    freq_hz = 1e9

    fdoas = _compute_fdoas(target_true, vel_true, c1, c2, v1, v2, freq_hz)
    variances = np.full(len(fdoas), 0.1**2)

    result = fdoa_locator(
        c1,
        c2,
        fdoas,
        variances,
        freq_hz,
        collector1_vel=v1,
        collector2_vel=v2,
        fix_position=target_true,
    )

    vel_error = np.linalg.norm(result.velocity - vel_true)
    assert vel_error < 0.001, f"Velocity error {vel_error:.6f}m/s exceeds 1mm/s"
    assert result.covariance.shape == (3, 3)


def test_fixed_position_minimum_measurements() -> None:
    """Velocity-only mode works with 3 measurements, sub-mm/s accuracy."""
    collector_xyz, collector_vel, target_true, vel_true = _create_geometry(4)
    c1, c2, v1, v2 = _make_pairs(collector_xyz, collector_vel)
    c1, c2, v1, v2 = c1[:3], c2[:3], v1[:3], v2[:3]
    freq_hz = 1e9

    fdoas = _compute_fdoas(target_true, vel_true, c1, c2, v1, v2, freq_hz)
    variances = np.full(3, 0.1**2)

    result = fdoa_locator(
        c1,
        c2,
        fdoas,
        variances,
        freq_hz,
        collector1_vel=v1,
        collector2_vel=v2,
        fix_position=target_true,
    )

    vel_error = np.linalg.norm(result.velocity - vel_true)
    assert vel_error < 0.001, f"Velocity error {vel_error:.6f}m/s exceeds 1mm/s"
    assert result.covariance.shape == (3, 3)


# =============================================================================
# Unconstrained Mode (limited accuracy due to position-velocity coupling)
# =============================================================================


def test_unconstrained_basic() -> None:
    """Unconstrained mode returns position and velocity with 6x6 covariance.

    Accuracy is limited by position-velocity coupling (~10-20km position,
    ~30-50m/s velocity).
    """
    collector_xyz, collector_vel, target_true, vel_true = _create_geometry()
    c1, c2, v1, v2 = _make_pairs(collector_xyz, collector_vel)
    freq_hz = 1e9

    fdoas = _compute_fdoas(target_true, vel_true, c1, c2, v1, v2, freq_hz)
    variances = np.full(len(fdoas), 0.1**2)

    result = fdoa_locator(
        c1,
        c2,
        fdoas,
        variances,
        freq_hz,
        collector1_vel=v1,
        collector2_vel=v2,
        xyz0=target_true + np.array([1000.0, 1000.0, 1000.0]),
    )

    # Unconstrained has limited accuracy due to position-velocity coupling
    pos_error = np.linalg.norm(result.position - target_true)
    vel_error = np.linalg.norm(result.velocity - vel_true)
    assert pos_error < 25_000.0, f"Position error {pos_error / 1000:.1f}km exceeds 25km"
    assert vel_error < 50.0, f"Velocity error {vel_error:.1f}m/s exceeds 50m/s"
    assert result.covariance.shape == (6, 6)


# =============================================================================
# Error Cases
# =============================================================================


def test_insufficient_measurements_unconstrained() -> None:
    """Unconstrained mode requires 6 measurements."""
    c1 = np.zeros((5, 3))
    c2 = np.ones((5, 3)) * 1000
    fdoas = np.zeros(5)
    variances = np.ones(5)

    with pytest.raises(ValueError, match="6 FDOA measurements required"):
        fdoa_locator(c1, c2, fdoas, variances, 1e9)


def test_insufficient_measurements_constrained() -> None:
    """Constrained modes require 3 measurements."""
    c1 = np.zeros((2, 3))
    c2 = np.ones((2, 3)) * 1000
    fdoas = np.zeros(2)
    variances = np.ones(2)

    with pytest.raises(ValueError, match="3 FDOA measurements required"):
        fdoa_locator(c1, c2, fdoas, variances, 1e9, fix_velocity=np.zeros(3))


def test_both_constraints_raises() -> None:
    """Cannot specify both fix_position and fix_velocity."""
    c1 = np.zeros((6, 3))
    c2 = np.ones((6, 3)) * 1000
    fdoas = np.zeros(6)
    variances = np.ones(6)

    with pytest.raises(ValueError, match="Cannot specify both"):
        fdoa_locator(
            c1,
            c2,
            fdoas,
            variances,
            1e9,
            fix_velocity=np.zeros(3),
            fix_position=np.zeros(3),
        )


def test_mismatched_shapes() -> None:
    """Input arrays must have consistent shapes."""
    c1 = np.zeros((6, 3))
    c2 = np.ones((5, 3)) * 1000  # Wrong size
    fdoas = np.zeros(6)
    variances = np.ones(6)

    with pytest.raises(ValueError, match="collector2_xyz shape"):
        fdoa_locator(c1, c2, fdoas, variances, 1e9)
