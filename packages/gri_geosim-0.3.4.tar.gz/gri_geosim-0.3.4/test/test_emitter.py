"""Tests for Emitter.

Tests verify emitter creation and trajectory delegation.
"""

from __future__ import annotations

import numpy as np
import pytest
from gri_nsepoch import Delta, Time
from gri_pos import Pos

from gri_geosim import Emitter
from gri_geosim.trajectories import StationaryTrajectory, WaypointTrajectory

_POS = Pos.LLA(38.0, -77.0, 0.0)
_TIME = Time(s=0.0)


# Initialization


def test_creates_with_trajectory() -> None:
    """Verify emitter creates with trajectory."""
    traj = StationaryTrajectory(_POS)
    emitter = Emitter(traj)

    assert emitter.trajectory is traj


def test_accepts_pos_directly() -> None:
    """Verify Emitter accepts Pos instead of Trajectory."""
    emitter = Emitter(Pos.LLA(38.0, -77.0, 0.0), name="test")

    assert isinstance(emitter.trajectory, StationaryTrajectory)


def test_creates_with_name() -> None:
    """Verify emitter stores name."""
    emitter = Emitter(_POS, name="Target1")

    assert emitter.name == "Target1"


def test_name_defaults_to_empty() -> None:
    """Verify name defaults to empty string."""
    emitter = Emitter(_POS)

    assert emitter.name == ""


def test_creates_with_frequency() -> None:
    """Verify emitter stores frequency."""
    emitter = Emitter(_POS, frequency_hz=1.5e9)

    assert emitter.frequency_hz == 1.5e9


def test_frequency_defaults_to_1ghz() -> None:
    """Verify frequency defaults to 1 GHz."""
    emitter = Emitter(_POS)

    assert emitter.frequency_hz == 1e9


@pytest.mark.parametrize(
    "frequency",
    [0.0, -1e9, -0.001],
    ids=["zero", "negative", "small_negative"],
)
def test_rejects_non_positive_frequency(frequency: float) -> None:
    """Verify emitter rejects non-positive frequency."""
    with pytest.raises(ValueError, match="positive"):
        Emitter(_POS, frequency_hz=frequency)


# Position and velocity delegation


def test_position_at_delegates_to_trajectory() -> None:
    """Verify position_at delegates to trajectory."""
    emitter = Emitter(_POS)

    pos = emitter.position_at(_TIME)

    assert np.allclose(pos.xyz, _POS.xyz, rtol=1e-10)


def test_velocity_at_delegates_to_trajectory() -> None:
    """Verify velocity_at delegates to trajectory."""
    emitter = Emitter(_POS)

    vel = emitter.velocity_at(_TIME)

    assert np.allclose(vel, [0.0, 0.0, 0.0])


def test_state_at_delegates_to_trajectory() -> None:
    """Verify state_at delegates to trajectory."""
    emitter = Emitter(_POS)

    state = emitter.state_at(_TIME)

    assert np.allclose(state.xyz, _POS.xyz, rtol=1e-10)
    assert np.allclose(state.vel_xyz, [0.0, 0.0, 0.0])


# Moving emitters


def test_moving_emitter_velocity() -> None:
    """Verify moving emitter has non-zero velocity."""
    traj = WaypointTrajectory(
        [
            (0.0, Pos.LLA(38.0, -77.0, 0.0)),
            (3600.0, Pos.LLA(39.0, -77.0, 0.0)),
        ],
        epoch_unix_s=_TIME.secs,
    )
    emitter = Emitter(traj)

    vel = emitter.velocity_at(_TIME + Delta(s=1800.0))

    assert np.linalg.norm(vel) > 0


# String representation


def test_repr_with_name() -> None:
    """Verify repr includes name."""
    emitter = Emitter(_POS, name="Target1")

    assert "Emitter" in repr(emitter)
    assert "Target1" in repr(emitter)


def test_repr_without_name() -> None:
    """Verify repr works without name."""
    emitter = Emitter(_POS)

    assert "Emitter" in repr(emitter)
