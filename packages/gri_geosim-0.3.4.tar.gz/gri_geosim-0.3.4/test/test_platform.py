"""Tests for Platform.

Tests verify platform creation, sensor attachment, and trajectory delegation.
"""

from __future__ import annotations

import numpy as np
import pytest
from gri_nsepoch import Time
from gri_pos import Pos

from gri_geosim import Platform
from gri_geosim.sensors import AoaSensor
from gri_geosim.trajectories import StationaryTrajectory

_POS = Pos.LLA(38.0, -77.0, 100.0)
_TIME = Time(s=0.0)


# Initialization


def test_creates_with_trajectory() -> None:
    """Verify platform creates with trajectory."""
    traj = StationaryTrajectory(_POS)
    platform = Platform(traj)

    assert platform.trajectory is traj


def test_accepts_pos_directly() -> None:
    """Verify Platform accepts Pos instead of Trajectory."""
    platform = Platform(Pos.LLA(38.0, -77.0, 100.0), name="test")

    assert isinstance(platform.trajectory, StationaryTrajectory)


def test_creates_with_name() -> None:
    """Verify platform stores name."""
    platform = Platform(_POS, name="TestPlatform")

    assert platform.name == "TestPlatform"


def test_name_defaults_to_empty() -> None:
    """Verify name defaults to empty string."""
    platform = Platform(_POS)

    assert platform.name == ""


def test_empty_sensors_list() -> None:
    """Verify platform starts with empty sensors list."""
    platform = Platform(_POS)

    assert len(platform.sensors) == 0


# Position and velocity delegation


def test_position_at_delegates_to_trajectory() -> None:
    """Verify position_at delegates to trajectory."""
    platform = Platform(_POS)

    pos = platform.position_at(_TIME)

    assert np.allclose(pos.xyz, _POS.xyz, rtol=1e-10)


def test_velocity_at_delegates_to_trajectory() -> None:
    """Verify velocity_at delegates to trajectory."""
    platform = Platform(_POS)

    vel = platform.velocity_at(_TIME)

    assert np.allclose(vel, [0.0, 0.0, 0.0])


def test_state_at_delegates_to_trajectory() -> None:
    """Verify state_at delegates to trajectory."""
    platform = Platform(_POS)

    state = platform.state_at(_TIME)

    assert np.allclose(state.xyz, _POS.xyz, rtol=1e-10)
    assert np.allclose(state.vel_xyz, [0.0, 0.0, 0.0])


# Sensor attachment


def test_add_sensor() -> None:
    """Verify sensor can be added to platform."""
    platform = Platform(_POS)
    sensor = AoaSensor("aoa")

    platform.add_sensor(sensor)

    assert len(platform.sensors) == 1
    assert sensor in platform.sensors


def test_add_multiple_sensors() -> None:
    """Verify multiple sensors can be added."""
    platform = Platform(_POS)
    sensor1 = AoaSensor("aoa1")
    sensor2 = AoaSensor("aoa2")

    platform.add_sensor(sensor1)
    platform.add_sensor(sensor2)

    assert len(platform.sensors) == 2


def test_sensor_platform_reference() -> None:
    """Verify sensor gets reference to platform after attachment."""
    platform = Platform(_POS)
    sensor = AoaSensor("aoa")

    platform.add_sensor(sensor)

    assert sensor.platform is platform


def test_sensor_already_attached_error() -> None:
    """Verify error when attaching sensor to multiple platforms."""
    platform1 = Platform(_POS)
    platform2 = Platform(_POS)
    sensor = AoaSensor("aoa")

    platform1.add_sensor(sensor)

    with pytest.raises(ValueError, match="already attached"):
        platform2.add_sensor(sensor)


# String representation


def test_repr_with_name() -> None:
    """Verify repr includes name."""
    platform = Platform(_POS, name="TestPlatform")

    assert "Platform" in repr(platform)
    assert "TestPlatform" in repr(platform)


def test_repr_without_name() -> None:
    """Verify repr works without name."""
    platform = Platform(_POS)

    assert "Platform" in repr(platform)
