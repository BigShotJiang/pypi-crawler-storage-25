"""Tests for FdoaSensor.

Tests verify FDOA sensor observation generation with paired platforms
and velocity-dependent Doppler measurements.
"""

from __future__ import annotations

import numpy as np
import pytest
from gri_nsepoch import Time
from gri_obs import FdoaObs
from gri_pos import Pos

from gri_geosim import Emitter, Platform
from gri_geosim.sensors import FdoaSensor
from gri_geosim.trajectories import WaypointTrajectory

# Test positions
_PLATFORM1_POS = Pos.LLA(38.0, -77.0, 100.0)
_PLATFORM2_POS = Pos.LLA(39.0, -76.0, 100.0)
_TARGET_POS = Pos.LLA(38.5, -76.5, 0.0)

_TIME = Time(s=0.0)
_TIME_1H = Time(s=3600.0)


def _moving_emitter_trajectory() -> WaypointTrajectory:
    """Create a moving emitter trajectory."""
    return WaypointTrajectory(
        [
            (0.0, Pos.LLA(38.4, -76.5, 0.0)),
            (3600.0, Pos.LLA(38.6, -76.5, 0.0)),  # Moving north
        ],
        epoch_unix_s=_TIME.secs,
    )


# Sensor initialization


@pytest.mark.parametrize(
    "fdoa_std_hz",
    [0.01, 0.1, 1.0],
    ids=["10mHz", "100mHz", "1Hz"],
)
def test_initialization_with_noise(fdoa_std_hz: float) -> None:
    """Verify sensor initializes with various noise levels."""
    sensor = FdoaSensor("test", fdoa_std_hz=fdoa_std_hz)

    assert sensor.fdoa_std_hz == fdoa_std_hz


def test_rejects_non_positive_std() -> None:
    """Verify sensor rejects non-positive standard deviation."""
    with pytest.raises(ValueError, match="positive"):
        FdoaSensor("test", fdoa_std_hz=0.0)

    with pytest.raises(ValueError, match="positive"):
        FdoaSensor("test", fdoa_std_hz=-0.1)


def test_auto_generated_id() -> None:
    """Verify sensor generates unique ID if not provided."""
    sensor1 = FdoaSensor()
    sensor2 = FdoaSensor()

    assert sensor1.sensor_id.startswith("FDOA-")
    assert sensor2.sensor_id.startswith("FDOA-")
    assert sensor1.sensor_id != sensor2.sensor_id


# Paired platform


def test_requires_paired_platform() -> None:
    """Verify sensor requires paired platform for observation."""
    platform = Platform(_PLATFORM1_POS)
    sensor = FdoaSensor("fdoa")
    platform.add_sensor(sensor)

    emitter = Emitter(_moving_emitter_trajectory(), frequency_hz=1e9)

    assert not sensor.can_observe(emitter, _TIME)

    obs = sensor.observe(emitter, _TIME)
    assert obs is None


def test_set_paired_platform() -> None:
    """Verify setting paired platform enables observation."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = FdoaSensor("fdoa")
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(_moving_emitter_trajectory(), frequency_hz=1e9)

    assert sensor.can_observe(emitter, _TIME)


def test_paired_platform_cannot_be_same() -> None:
    """Verify paired platform cannot be the same as sensor's platform."""
    platform = Platform(_PLATFORM1_POS)
    sensor = FdoaSensor("fdoa")
    platform.add_sensor(sensor)

    with pytest.raises(ValueError, match="same as sensor"):
        sensor.set_paired_platform(platform)


# Observation generation


def test_generates_fdoa_observation() -> None:
    """Verify sensor generates FDOA observation."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = FdoaSensor("fdoa", rng_seed=42)
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(_moving_emitter_trajectory(), frequency_hz=1e9)

    obs = sensor.observe(emitter, _TIME)

    assert obs is not None
    assert isinstance(obs, FdoaObs)
    assert obs.obs_type == "FDOA"


def test_observation_without_noise_repeatable() -> None:
    """Verify noise-free observations are repeatable."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = FdoaSensor("fdoa")
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(_moving_emitter_trajectory(), frequency_hz=1e9)

    obs1 = sensor.observe(emitter, _TIME, add_noise=False)
    obs2 = sensor.observe(emitter, _TIME, add_noise=False)

    assert obs1 is not None
    assert obs2 is not None
    assert obs1.value == obs2.value


def test_observation_with_noise_varies() -> None:
    """Verify noisy observations vary between calls."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = FdoaSensor("fdoa", fdoa_std_hz=1.0, rng_seed=42)
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(_moving_emitter_trajectory(), frequency_hz=1e9)

    obs1 = sensor.observe(emitter, _TIME, add_noise=True)
    obs2 = sensor.observe(emitter, _TIME, add_noise=True)

    assert obs1 is not None
    assert obs2 is not None
    assert obs1.value != obs2.value


# FDOA value correctness


def test_fdoa_zero_for_stationary_emitter() -> None:
    """Verify FDOA is zero when emitter is stationary."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = FdoaSensor("fdoa")
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    # Stationary emitter
    emitter = Emitter(_TARGET_POS, frequency_hz=1e9)

    obs = sensor.observe(emitter, _TIME, add_noise=False)

    assert obs is not None
    assert np.isclose(obs.value, 0.0, atol=1e-6)


def test_fdoa_nonzero_for_moving_emitter() -> None:
    """Verify FDOA is non-zero when emitter is moving."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = FdoaSensor("fdoa")
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(_moving_emitter_trajectory(), frequency_hz=1e9)

    obs = sensor.observe(emitter, _TIME, add_noise=False)

    assert obs is not None
    assert abs(obs.value) > 0


def test_fdoa_scales_with_frequency() -> None:
    """Verify FDOA scales with carrier frequency."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = FdoaSensor("fdoa")
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter_1ghz = Emitter(_moving_emitter_trajectory(), frequency_hz=1e9)
    emitter_2ghz = Emitter(_moving_emitter_trajectory(), frequency_hz=2e9)

    obs1 = sensor.observe(emitter_1ghz, _TIME, add_noise=False)
    obs2 = sensor.observe(emitter_2ghz, _TIME, add_noise=False)

    assert obs1 is not None
    assert obs2 is not None
    # FDOA scales linearly with frequency
    assert np.isclose(obs2.value, 2 * obs1.value, rtol=0.01)


# Observation metadata


def test_observation_contains_collector_state() -> None:
    """Verify observation contains both collector positions and velocities."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = FdoaSensor("fdoa")
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(_moving_emitter_trajectory(), frequency_hz=1e9)

    obs = sensor.observe(emitter, _TIME)

    assert obs is not None
    assert np.allclose(obs.collector1.xyz, _PLATFORM1_POS.xyz, rtol=1e-6)
    assert np.allclose(obs.collector2.xyz, _PLATFORM2_POS.xyz, rtol=1e-6)
    assert obs.collector1_vel.shape == (3,)
    assert obs.collector2_vel.shape == (3,)


def test_observation_frequency() -> None:
    """Verify observation contains carrier frequency."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = FdoaSensor("fdoa")
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    freq = 1.5e9
    emitter = Emitter(_moving_emitter_trajectory(), frequency_hz=freq)

    obs = sensor.observe(emitter, _TIME)

    assert obs is not None
    assert obs.frequency_hz == freq


def test_observation_sensor_id() -> None:
    """Verify observation contains sensor ID."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    sensor = FdoaSensor("my_fdoa_sensor")
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(_moving_emitter_trajectory(), frequency_hz=1e9, name="target1")

    obs = sensor.observe(emitter, _TIME)

    assert obs is not None
    assert obs.sensor_id == "my_fdoa_sensor"
    assert obs.emitter_id == "target1"


def test_observation_variance() -> None:
    """Verify observation variance matches sensor configuration."""
    platform1 = Platform(_PLATFORM1_POS)
    platform2 = Platform(_PLATFORM2_POS)

    fdoa_std = 0.5
    sensor = FdoaSensor("fdoa", fdoa_std_hz=fdoa_std)
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    emitter = Emitter(_moving_emitter_trajectory(), frequency_hz=1e9)

    obs = sensor.observe(emitter, _TIME)

    assert obs is not None
    assert np.isclose(obs.variance, fdoa_std**2)


# Platform requirement


def test_requires_platform() -> None:
    """Verify sensor requires platform attachment."""
    sensor = FdoaSensor("fdoa")
    emitter = Emitter(_moving_emitter_trajectory(), frequency_hz=1e9)

    assert not sensor.can_observe(emitter, _TIME)


def test_repr() -> None:
    """Verify string representation."""
    platform1 = Platform(_PLATFORM1_POS, name="P1")
    platform2 = Platform(_PLATFORM2_POS, name="P2")

    sensor = FdoaSensor("test_sensor", fdoa_std_hz=0.1)
    platform1.add_sensor(sensor)
    sensor.set_paired_platform(platform2)

    repr_str = repr(sensor)
    assert "FdoaSensor" in repr_str
    assert "test_sensor" in repr_str
