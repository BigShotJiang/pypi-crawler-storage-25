"""Tests for EarthOcclusionFov constraint.

Tests verify Earth line-of-sight blockage checks.
"""

from __future__ import annotations

import pytest
from gri_pos import Pos

from gri_geosim.sensors.constraints import EarthOcclusionFov

# Positions for testing
_GEO_EAST = Pos.XYZ(42_164_000.0, 0.0, 0.0)  # GEO at 0 deg longitude
_GEO_WEST = Pos.XYZ(-42_164_000.0, 0.0, 0.0)  # GEO at 180 deg longitude
_GEO_NORTH = Pos.XYZ(0.0, 42_164_000.0, 0.0)  # GEO at 90 deg longitude
_LEO_ABOVE = Pos.LLA(0.0, 0.0, 400_000.0)  # LEO above equator

_GROUND_EQUATOR = Pos.LLA(0.0, 0.0, 0.0)
_GROUND_NORTH = Pos.LLA(45.0, 0.0, 0.0)


# Basic visibility


@pytest.mark.parametrize(
    ("sensor", "target", "expected_visible"),
    [
        # Same side of Earth - visible
        (_GEO_EAST, _GROUND_EQUATOR, True),
        (_GEO_EAST, _GEO_NORTH, True),
        # Opposite sides - blocked
        (_GEO_EAST, _GEO_WEST, False),
        # LEO to ground below - visible
        (_LEO_ABOVE, _GROUND_EQUATOR, True),
    ],
    ids=["geo_to_ground", "geo_to_geo_90deg", "geo_opposite", "leo_to_ground"],
)
def test_visibility(sensor: Pos, target: Pos, *, expected_visible: bool) -> None:
    """Verify Earth occlusion visibility checks."""
    fov = EarthOcclusionFov()

    assert fov.is_visible(sensor, target) == expected_visible


# Satellite to satellite


def test_satellites_same_side_visible() -> None:
    """Verify satellites on same side of Earth can see each other."""
    fov = EarthOcclusionFov()

    sat1 = Pos.LLA(0.0, 0.0, 400_000.0)
    sat2 = Pos.LLA(10.0, 10.0, 800_000.0)

    assert fov.is_visible(sat1, sat2)


def test_satellites_opposite_sides_blocked() -> None:
    """Verify satellites on opposite sides are blocked by Earth."""
    fov = EarthOcclusionFov()

    sat1 = Pos.LLA(0.0, 0.0, 400_000.0)
    sat2 = Pos.LLA(0.0, 180.0, 400_000.0)  # Opposite side

    assert not fov.is_visible(sat1, sat2)


# Ground to ground


def test_ground_to_ground_same_location() -> None:
    """Verify ground stations at same location are visible."""
    fov = EarthOcclusionFov()

    assert fov.is_visible(_GROUND_EQUATOR, _GROUND_EQUATOR)


def test_ground_to_ground_nearby() -> None:
    """Verify nearby ground stations visibility.

    Note: Ground-to-ground line of sight may pass through Earth depending
    on the curvature. For nearby points at surface level, visibility
    depends on Earth's curvature and terrain.
    """
    fov = EarthOcclusionFov()

    # Points on surface at same location are visible
    ground1 = Pos.LLA(38.0, -77.0, 100.0)  # Slightly elevated
    ground2 = Pos.LLA(38.0, -77.0, 200.0)  # Same location, different altitude

    assert fov.is_visible(ground1, ground2)


# Edge cases


def test_tangent_to_earth() -> None:
    """Test visibility when line of sight is tangent to Earth."""
    fov = EarthOcclusionFov()

    # Two GEO satellites 90 degrees apart - line grazes Earth
    # This is at the edge of visibility
    sat1 = Pos.XYZ(42_164_000.0, 0.0, 0.0)
    sat2 = Pos.XYZ(0.0, 42_164_000.0, 0.0)

    # Should be visible (tangent case)
    assert fov.is_visible(sat1, sat2)


# Equality and hashing


def test_equality() -> None:
    """Verify equality comparison."""
    fov1 = EarthOcclusionFov()
    fov2 = EarthOcclusionFov()

    assert fov1 == fov2


def test_hash() -> None:
    """Verify instances are hashable."""
    fov1 = EarthOcclusionFov()
    fov2 = EarthOcclusionFov()

    # Same type should have same hash
    assert hash(fov1) == hash(fov2)

    # Can be used in sets/dicts
    fov_set = {fov1, fov2}
    assert len(fov_set) == 1  # Both should be equal


# String representations


def test_repr() -> None:
    """Verify string representation."""
    fov = EarthOcclusionFov()

    assert "EarthOcclusionFov" in repr(fov)


def test_str() -> None:
    """Verify human-readable string."""
    fov = EarthOcclusionFov()

    assert "occlusion" in str(fov).lower()
