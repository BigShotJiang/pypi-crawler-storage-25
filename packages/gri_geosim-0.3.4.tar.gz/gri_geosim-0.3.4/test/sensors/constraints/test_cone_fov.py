"""Tests for ConeFov constraint.

Tests verify conical field of view visibility checks for nadir-pointing sensors.
"""

from __future__ import annotations

import math

import pytest
from gri_pos import Pos

from gri_geosim.sensors.constraints import ConeFov

# Test positions
_SATELLITE_400KM = Pos.LLA(0.0, 0.0, 400_000.0)  # Nadir at equator
_GEO_SATELLITE = Pos.LLA(0.0, 0.0, 35_786_000.0)  # GEO altitude

# Ground targets relative to satellite nadir
_TARGET_NADIR = Pos.LLA(0.0, 0.0, 0.0)  # Directly below
_TARGET_5DEG_OFF = Pos.LLA(0.3, 0.0, 0.0)  # ~5 deg off nadir at 400km
_TARGET_30DEG_OFF = Pos.LLA(2.5, 0.0, 0.0)  # ~30 deg off nadir
_TARGET_60DEG_OFF = Pos.LLA(6.0, 0.0, 0.0)  # ~60 deg off nadir
_TARGET_HORIZON = Pos.LLA(20.0, 0.0, 0.0)  # Near horizon


# Initialization


@pytest.mark.parametrize(
    "half_angle_deg",
    [1.0, 30.0, 45.0, 60.0, 90.0],
    ids=["1deg", "30deg", "45deg", "60deg", "90deg"],
)
def test_valid_half_angles(half_angle_deg: float) -> None:
    """Verify FOV accepts valid half angles."""
    fov = ConeFov(half_angle_deg=half_angle_deg)

    # Use approximate comparison due to radians conversion
    assert abs(fov.half_angle_deg - half_angle_deg) < 1e-10


@pytest.mark.parametrize(
    "half_angle_deg",
    [0.0, -10.0, 91.0, 180.0],
    ids=["zero", "negative", "over90", "180"],
)
def test_invalid_half_angles(half_angle_deg: float) -> None:
    """Verify FOV rejects invalid half angles."""
    with pytest.raises(ValueError, match="must be in"):
        ConeFov(half_angle_deg=half_angle_deg)


# Properties


def test_half_angle_properties() -> None:
    """Verify half angle properties return correct values."""
    fov = ConeFov(half_angle_deg=45.0)

    assert fov.half_angle_deg == 45.0
    assert abs(fov.half_angle_rad - math.radians(45.0)) < 1e-10


# Visibility - narrow FOV


@pytest.mark.parametrize(
    ("target", "expected_visible"),
    [
        (_TARGET_NADIR, True),  # Directly below
        (_TARGET_5DEG_OFF, True),  # Within 10 deg
        (_TARGET_30DEG_OFF, False),  # Outside 10 deg
    ],
    ids=["nadir", "5deg_off", "30deg_off"],
)
def test_narrow_fov_visibility(target: Pos, *, expected_visible: bool) -> None:
    """Verify narrow FOV (10 deg) visibility."""
    fov = ConeFov(half_angle_deg=10.0)

    assert fov.is_visible(_SATELLITE_400KM, target) == expected_visible


# Visibility - wide FOV


@pytest.mark.parametrize(
    ("target", "expected_visible"),
    [
        (_TARGET_NADIR, True),
        (_TARGET_30DEG_OFF, True),  # Within 60 deg
        (_TARGET_60DEG_OFF, True),  # At edge
        (_TARGET_HORIZON, False),  # Beyond 60 deg
    ],
    ids=["nadir", "30deg_off", "60deg_off", "horizon"],
)
def test_wide_fov_visibility(target: Pos, *, expected_visible: bool) -> None:
    """Verify wide FOV (60 deg) visibility."""
    fov = ConeFov(half_angle_deg=60.0)

    assert fov.is_visible(_SATELLITE_400KM, target) == expected_visible


# Edge cases


def test_same_location_visible() -> None:
    """Verify same location is considered visible."""
    fov = ConeFov(half_angle_deg=10.0)

    assert fov.is_visible(_SATELLITE_400KM, _SATELLITE_400KM)


def test_hemispherical_fov() -> None:
    """Verify 90 deg FOV covers full hemisphere."""
    fov = ConeFov(half_angle_deg=90.0)

    # All targets in front of nadir should be visible
    assert fov.is_visible(_SATELLITE_400KM, _TARGET_NADIR)
    assert fov.is_visible(_SATELLITE_400KM, _TARGET_60DEG_OFF)
    assert fov.is_visible(_SATELLITE_400KM, _TARGET_HORIZON)


# Different altitudes


def test_geo_satellite_fov() -> None:
    """Verify FOV works correctly at GEO altitude."""
    fov = ConeFov(half_angle_deg=8.7)  # Earth disk from GEO is ~8.7 deg

    # Target on Earth surface should be visible
    assert fov.is_visible(_GEO_SATELLITE, _TARGET_NADIR)


# String representations


def test_repr() -> None:
    """Verify string representation."""
    fov = ConeFov(half_angle_deg=45.0)

    assert "ConeFov" in repr(fov)
    assert "45.0" in repr(fov)


def test_str() -> None:
    """Verify human-readable string."""
    fov = ConeFov(half_angle_deg=45.0)

    assert "45.0" in str(fov)
