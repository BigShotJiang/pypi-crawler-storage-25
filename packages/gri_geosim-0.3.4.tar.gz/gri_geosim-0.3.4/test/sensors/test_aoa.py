"""Tests for AoaSensor.

Tests verify AOA sensor observation generation with various orientations
and noise configurations.
"""

from __future__ import annotations

import math
from typing import Literal

import numpy as np
import pytest
from gri_nsepoch import Time
from gri_obs import AoaObs
from gri_pos import Pos
from scipy.spatial.transform import Rotation

from gri_geosim import Emitter, Platform
from gri_geosim.sensors import AoaSensor, ElevationMaskFov

# Test positions
_GROUND_POS = Pos.LLA(38.0, -77.0, 100.0)
_SATELLITE_POS = Pos.LLA(38.0, -77.0, 400_000.0)  # 400 km altitude
_TARGET_NORTH = Pos.LLA(39.0, -77.0, 0.0)  # ~111 km north
_TARGET_EAST = Pos.LLA(38.0, -76.0, 0.0)  # ~85 km east
_TARGET_OVERHEAD = Pos.LLA(38.0, -77.0, 10_000.0)  # 10 km altitude

_TIME = Time(s=0.0)


# Sensor initialization


@pytest.mark.parametrize(
    ("azimuth_std", "elevation_std"),
    [
        (0.001, 0.001),  # 1 mrad each
        (0.01, 0.005),  # Different values
        (0.0001, 0.0001),  # Very precise
    ],
    ids=["equal", "different", "precise"],
)
def test_initialization_with_noise(azimuth_std: float, elevation_std: float) -> None:
    """Verify sensor initializes with various noise configurations."""
    sensor = AoaSensor(
        "test",
        azimuth_std_rad=azimuth_std,
        elevation_std_rad=elevation_std,
    )

    assert sensor.azimuth_std_rad == azimuth_std
    assert sensor.elevation_std_rad == elevation_std


def test_auto_generated_id() -> None:
    """Verify sensor generates unique ID if not provided."""
    sensor1 = AoaSensor()
    sensor2 = AoaSensor()

    assert sensor1.sensor_id.startswith("AOA-")
    assert sensor2.sensor_id.startswith("AOA-")
    assert sensor1.sensor_id != sensor2.sensor_id


@pytest.mark.parametrize(
    "orientation",
    ["enu", "nadir", "auto"],
    ids=["enu", "nadir", "auto"],
)
def test_orientation_values(orientation: Literal["auto", "nadir", "enu"]) -> None:
    """Verify sensor accepts valid orientation values."""
    sensor = AoaSensor("test", orientation=orientation)

    if orientation == "auto":
        # Auto resolves to actual orientation only when attached to platform
        pass  # OK if no error
    else:
        assert sensor.orientation == orientation


# Observation generation


def test_generates_aoa_observation() -> None:
    """Verify sensor generates AOA observation."""
    platform = Platform(_GROUND_POS)
    sensor = AoaSensor("aoa", rng_seed=42)
    platform.add_sensor(sensor)

    emitter = Emitter(_TARGET_NORTH)

    obs = sensor.observe(emitter, _TIME)

    assert obs is not None
    assert isinstance(obs, AoaObs)
    assert obs.obs_type == "AOA"


def test_observation_without_noise_repeatable() -> None:
    """Verify noise-free observations are repeatable."""
    platform = Platform(_GROUND_POS)
    sensor = AoaSensor("aoa")
    platform.add_sensor(sensor)

    emitter = Emitter(_TARGET_NORTH)

    obs1 = sensor.observe(emitter, _TIME, add_noise=False)
    obs2 = sensor.observe(emitter, _TIME, add_noise=False)

    assert obs1 is not None
    assert obs2 is not None
    assert np.allclose(obs1.value, obs2.value)


def test_observation_with_noise_varies() -> None:
    """Verify noisy observations vary between calls."""
    platform = Platform(_GROUND_POS)
    sensor = AoaSensor("aoa", azimuth_std_rad=0.01, rng_seed=42)
    platform.add_sensor(sensor)

    emitter = Emitter(_TARGET_NORTH)

    obs1 = sensor.observe(emitter, _TIME, add_noise=True)
    obs2 = sensor.observe(emitter, _TIME, add_noise=True)

    assert obs1 is not None
    assert obs2 is not None
    assert not np.allclose(obs1.value, obs2.value)


# Direction cosines


def test_direction_cosines_valid_range() -> None:
    """Verify direction cosines satisfy u^2 + v^2 <= 1."""
    platform = Platform(_GROUND_POS)
    sensor = AoaSensor("aoa", orientation="enu")
    platform.add_sensor(sensor)

    emitter = Emitter(_TARGET_NORTH)

    obs = sensor.observe(emitter, _TIME, add_noise=False)

    assert obs is not None
    assert obs.u**2 + obs.v**2 <= 1.0 + 1e-10


@pytest.mark.parametrize(
    ("target_pos", "expected_u_sign", "expected_v_sign"),
    [
        (_TARGET_NORTH, 0, 1),  # North: u~0, v>0
        (_TARGET_EAST, 1, 0),  # East: u>0, v~0
    ],
    ids=["north", "east"],
)
def test_direction_cosines_direction(
    target_pos: Pos,
    expected_u_sign: int,
    expected_v_sign: int,
) -> None:
    """Verify direction cosines have correct sign for target direction."""
    platform = Platform(_GROUND_POS)
    sensor = AoaSensor("aoa", orientation="enu")
    platform.add_sensor(sensor)

    emitter = Emitter(target_pos)

    obs = sensor.observe(emitter, _TIME, add_noise=False)

    assert obs is not None
    if expected_u_sign == 0:
        assert abs(obs.u) < 0.2  # Near zero
    else:
        assert obs.u * expected_u_sign > 0

    if expected_v_sign == 0:
        assert abs(obs.v) < 0.2  # Near zero
    else:
        assert obs.v * expected_v_sign > 0


# Azimuth and elevation


def test_azimuth_elevation_properties() -> None:
    """Verify azimuth and elevation computed from direction cosines."""
    platform = Platform(_GROUND_POS)
    sensor = AoaSensor("aoa", orientation="enu")
    platform.add_sensor(sensor)

    emitter = Emitter(_TARGET_NORTH)

    obs = sensor.observe(emitter, _TIME, add_noise=False)

    assert obs is not None
    assert 0 <= obs.azimuth < 2 * math.pi
    assert -math.pi / 2 <= obs.elevation <= math.pi / 2


# Custom rotation


def test_custom_rotation() -> None:
    """Verify custom sensor rotation is applied."""
    platform = Platform(_GROUND_POS)
    custom_rot = Rotation.from_euler("z", 45, degrees=True)
    sensor = AoaSensor("aoa", sensor_rotation=custom_rot)
    platform.add_sensor(sensor)

    emitter = Emitter(_TARGET_NORTH)

    obs = sensor.observe(emitter, _TIME, add_noise=False)

    assert obs is not None
    assert np.allclose(
        obs.collector_rotation.as_quat(),
        custom_rot.as_quat(),
    )


# FOV constraints


def test_fov_blocks_observation() -> None:
    """Verify FOV constraint blocks out-of-view targets."""
    platform = Platform(_GROUND_POS)
    fov = ElevationMaskFov(min_elev_deg=80.0)  # Only nearly overhead
    sensor = AoaSensor("aoa", fov=fov)
    platform.add_sensor(sensor)

    # Target far away at low elevation
    emitter = Emitter(Pos.LLA(45.0, -77.0, 0.0))

    obs = sensor.observe(emitter, _TIME)

    assert obs is None  # Blocked by FOV


def test_can_observe_checks_fov() -> None:
    """Verify can_observe respects FOV constraint."""
    platform = Platform(_GROUND_POS)
    fov = ElevationMaskFov(min_elev_deg=80.0)
    sensor = AoaSensor("aoa", fov=fov)
    platform.add_sensor(sensor)

    emitter = Emitter(Pos.LLA(45.0, -77.0, 0.0))

    assert not sensor.can_observe(emitter, _TIME)


# Orientation auto-detection
# Note: The orientation property always returns the configured value ("auto")
# The actual rotation is computed at observation time based on altitude


def test_auto_orientation_stored() -> None:
    """Verify auto orientation is stored as configured."""
    sensor = AoaSensor("aoa", orientation="auto")

    # Orientation property returns the configured value
    assert sensor.orientation == "auto"


def test_auto_orientation_ground_observation() -> None:
    """Verify auto orientation uses ENU rotation for ground platforms."""
    platform = Platform(_GROUND_POS)
    sensor = AoaSensor("aoa", orientation="auto")
    platform.add_sensor(sensor)

    emitter = Emitter(_TARGET_NORTH)
    obs = sensor.observe(emitter, _TIME, add_noise=False)

    # Observation should be generated (auto resolves at observation time)
    assert obs is not None


def test_auto_orientation_satellite_observation() -> None:
    """Verify auto orientation uses nadir rotation for satellite platforms."""
    platform = Platform(_SATELLITE_POS)
    sensor = AoaSensor("aoa", orientation="auto")
    platform.add_sensor(sensor)

    # Target directly below
    emitter = Emitter(Pos.LLA(38.0, -77.0, 0.0))
    obs = sensor.observe(emitter, _TIME, add_noise=False)

    # Observation should be generated (auto resolves at observation time)
    assert obs is not None


# Platform requirement


def test_requires_platform() -> None:
    """Verify sensor requires platform attachment for observation."""
    sensor = AoaSensor("aoa")
    emitter = Emitter(_TARGET_NORTH)

    assert not sensor.can_observe(emitter, _TIME)

    obs = sensor.observe(emitter, _TIME)
    assert obs is None


# Observation metadata


def test_observation_sensor_id() -> None:
    """Verify observation contains sensor ID."""
    platform = Platform(_GROUND_POS)
    sensor = AoaSensor("my_aoa_sensor")
    platform.add_sensor(sensor)

    emitter = Emitter(_TARGET_NORTH, name="target1")

    obs = sensor.observe(emitter, _TIME)

    assert obs is not None
    assert obs.sensor_id == "my_aoa_sensor"
    assert obs.emitter_id == "target1"


def test_repr() -> None:
    """Verify string representation."""
    sensor = AoaSensor("test_sensor", azimuth_std_rad=0.001)

    assert "AoaSensor" in repr(sensor)
    assert "test_sensor" in repr(sensor)
