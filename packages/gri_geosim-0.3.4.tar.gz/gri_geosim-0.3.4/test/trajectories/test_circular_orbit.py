"""Tests for CircularOrbitTrajectory.

Tests verify ECI-fixed circular orbit behavior: constant speed and
radius, recognizable LEO ground tracks, and correct period.
"""

from __future__ import annotations

import numpy as np
import pytest
from gri_pos import Pos
from gri_utils.constants import ER_M

from gri_geosim.trajectories import CircularOrbitTrajectory

_EPOCH_UNIX_S = 1_700_000_000.0


def test_rejects_invalid_speed() -> None:
    """speed_mps must be positive."""
    with pytest.raises(ValueError, match="speed_mps must be positive"):
        CircularOrbitTrajectory(
            Pos.LLA(0.0, 0.0, 500_000.0),
            azimuth_deg=90.0,
            speed_mps=0.0,
            epoch_unix_s=_EPOCH_UNIX_S,
        )


def test_rejects_invalid_position() -> None:
    """Unsupported start_pos types raise TypeError."""
    with pytest.raises(TypeError, match="Unsupported start_pos type"):
        CircularOrbitTrajectory(
            "invalid",  # type: ignore[arg-type]
            azimuth_deg=90.0,
            speed_mps=7616.5,
            epoch_unix_s=_EPOCH_UNIX_S,
        )


def test_position_at_epoch_equals_start() -> None:
    """At dt=0, ECEF position equals start_pos."""
    start = Pos.LLA(0.0, 0.0, 500_000.0)
    traj = CircularOrbitTrajectory(
        start,
        azimuth_deg=90.0,
        speed_mps=7616.5,
        epoch_unix_s=_EPOCH_UNIX_S,
    )
    pos = traj.position_at()
    assert np.allclose(pos.xyz, start.xyz, rtol=1e-9)


def test_radius_constant_in_eci() -> None:
    """ECI radius (== ECEF radius) is constant for a circular orbit."""
    start = Pos.LLA(0.0, 0.0, 500_000.0)
    traj = CircularOrbitTrajectory(
        start,
        azimuth_deg=90.0,
        speed_mps=7616.5,
        epoch_unix_s=_EPOCH_UNIX_S,
    )
    r0 = float(np.linalg.norm(start.xyz))
    for dt_s in (0.0, 600.0, 1800.0, 3600.0):
        pos = traj.position_at(dt_s)
        r = float(np.linalg.norm(pos.xyz))
        assert np.isclose(r, r0, rtol=1e-9)


def test_speed_constant() -> None:
    """|velocity| (in ECEF) is approximately speed_mps for an equatorial orbit.

    For an ECI-fixed orbit, ECEF speed differs from ECI speed by Earth's
    rotation, which adds/subtracts ~465 m/s at the equator. We check that
    the magnitude is bounded by sensible values; exact equality with
    speed_mps holds in ECI, not ECEF.
    """
    speed = 7616.5
    start = Pos.LLA(0.0, 0.0, 500_000.0)
    traj = CircularOrbitTrajectory(
        start,
        azimuth_deg=90.0,
        speed_mps=speed,
        epoch_unix_s=_EPOCH_UNIX_S,
    )
    for dt_s in (0.0, 600.0, 3600.0):
        v = traj.velocity_at(dt_s)
        v_mag = float(np.linalg.norm(v))
        assert abs(v_mag - speed) < 700.0


def test_period_matches_omega() -> None:
    """After one orbital period, ECI position returns to the start."""
    start = Pos.LLA(0.0, 0.0, 500_000.0)
    speed = 7616.5
    traj = CircularOrbitTrajectory(
        start,
        azimuth_deg=90.0,
        speed_mps=speed,
        epoch_unix_s=_EPOCH_UNIX_S,
    )
    r0 = float(np.linalg.norm(start.xyz))
    period_s = 2.0 * np.pi * r0 / speed
    pos_at_period = traj.position_at(period_s)
    assert abs(pos_at_period.lla.lat_deg) < 1e-3


def test_eastbound_at_equator_inclination_zero() -> None:
    """Az=90 from (lat=0) gives an equatorial orbit; lat stays near zero.

    "Near zero" because the orbit plane is fixed in ECI; at the start the
    plane contains the equator. With Earth rotating beneath, the
    satellite's ECEF latitude oscillates due to coupling between orbital
    motion and rotation, but stays small for an equatorial orbit.
    """
    traj = CircularOrbitTrajectory(
        Pos.LLA(0.0, 0.0, 500_000.0),
        azimuth_deg=90.0,
        speed_mps=7616.5,
        epoch_unix_s=_EPOCH_UNIX_S,
    )
    for dt_s in (60.0, 600.0, 1800.0, 3600.0):
        pos = traj.position_at(dt_s)
        assert abs(pos.lla.lat_deg) < 1e-6


def test_inclined_orbit_traces_sinusoid() -> None:
    """An inclined orbit's ECEF latitude oscillates as Earth rotates."""
    inclination_deg = 51.6
    traj = CircularOrbitTrajectory(
        Pos.LLA(0.0, 0.0, 400_000.0),
        azimuth_deg=90.0 - inclination_deg,
        speed_mps=7670.0,
        epoch_unix_s=_EPOCH_UNIX_S,
    )
    r0 = ER_M + 400_000.0
    half_period_s = np.pi * r0 / 7670.0
    samples = np.linspace(0.0, half_period_s, 30)
    lats = [traj.position_at(float(t)).lla.lat_deg for t in samples]
    max_lat = max(lats)
    assert abs(max_lat - inclination_deg) < 5.0


def test_state_at_matches_separate_calls() -> None:
    """state_at returns the same (pos, vel) as position_at + velocity_at."""
    traj = CircularOrbitTrajectory(
        Pos.LLA(45.0, 30.0, 800_000.0),
        azimuth_deg=120.0,
        speed_mps=7400.0,
        epoch_unix_s=_EPOCH_UNIX_S,
    )
    pos_a = traj.position_at(900.0)
    vel_a = traj.velocity_at(900.0)
    state = traj.state_at(900.0)
    assert np.allclose(pos_a.xyz, state.xyz, rtol=1e-12)
    assert np.allclose(vel_a, state.vel_xyz, rtol=1e-12)
