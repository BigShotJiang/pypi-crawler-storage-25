"""Tests for KeplerianTrajectory.

Tests verify Keplerian orbit propagation using two-body mechanics.
"""

from __future__ import annotations

import math

import numpy as np
import pytest

from gri_geosim.trajectories import KeplerianTrajectory

# Orbital parameters for testing
_LEO_ALTITUDE_M = 400_000.0
_LEO_SMA = 6_378_137.0 + _LEO_ALTITUDE_M  # ~6.778e6 m
_ISS_INCLINATION_RAD = math.radians(51.6)


# Orbital element validation


def test_rejects_negative_sma() -> None:
    """Verify trajectory rejects negative semi-major axis."""
    with pytest.raises(ValueError, match="positive"):
        KeplerianTrajectory(
            semi_major_axis_m=-1_000_000,
            eccentricity=0.0,
            inclination_rad=0.0,
            raan_rad=0.0,
            arg_periapsis_rad=0.0,
            mean_anomaly_rad=0.0,
        )


@pytest.mark.parametrize(
    "eccentricity",
    [-0.1, 1.0, 1.5],
    ids=["negative", "parabolic", "hyperbolic"],
)
def test_rejects_invalid_eccentricity(eccentricity: float) -> None:
    """Verify trajectory rejects non-elliptical eccentricities."""
    with pytest.raises(ValueError, match=r"(?i)eccentricity"):
        KeplerianTrajectory(
            semi_major_axis_m=_LEO_SMA,
            eccentricity=eccentricity,
            inclination_rad=0.0,
            raan_rad=0.0,
            arg_periapsis_rad=0.0,
            mean_anomaly_rad=0.0,
        )


# Position propagation


@pytest.mark.parametrize(
    ("inclination_deg", "expected_z_nonzero"),
    [
        (0.0, False),
        (51.6, True),
        (90.0, True),
    ],
    ids=["equatorial", "inclined", "polar"],
)
def test_inclination_affects_z_component(
    inclination_deg: float,
    *,
    expected_z_nonzero: bool,
) -> None:
    """Verify orbital inclination affects Z component of position."""
    traj = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.0001,
        inclination_rad=math.radians(inclination_deg),
        raan_rad=0.0,
        arg_periapsis_rad=0.0,
        mean_anomaly_rad=math.pi / 4,
    )

    pos = traj.position_at()

    if expected_z_nonzero:
        assert abs(pos.xyz[2]) > 1000
    else:
        assert abs(pos.xyz[2]) < 1000


def test_position_changes_over_time() -> None:
    """Verify position propagates over time."""
    traj = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.0001,
        inclination_rad=_ISS_INCLINATION_RAD,
        raan_rad=0.0,
        arg_periapsis_rad=0.0,
        mean_anomaly_rad=0.0,
    )

    pos0 = traj.position_at()
    pos1 = traj.position_at(600.0)

    assert not np.allclose(pos0.xyz, pos1.xyz)


def test_altitude_reasonable_for_leo() -> None:
    """Verify altitude is reasonable for LEO orbit."""
    traj = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.0001,
        inclination_rad=_ISS_INCLINATION_RAD,
        raan_rad=0.0,
        arg_periapsis_rad=0.0,
        mean_anomaly_rad=0.0,
    )

    pos = traj.position_at()
    altitude = pos.lla.alt_m

    assert abs(altitude - _LEO_ALTITUDE_M) < 10_000


# Velocity


def test_velocity_magnitude_leo() -> None:
    """Verify LEO velocity is approximately 7.5 km/s."""
    traj = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.0001,
        inclination_rad=_ISS_INCLINATION_RAD,
        raan_rad=0.0,
        arg_periapsis_rad=0.0,
        mean_anomaly_rad=0.0,
    )

    vel = traj.velocity_at()
    speed = float(np.linalg.norm(vel))

    assert 7000 < speed < 8000


def test_velocity_perpendicular_to_position_circular() -> None:
    """Verify velocity is perpendicular to position for circular orbit."""
    traj = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.0,
        inclination_rad=_ISS_INCLINATION_RAD,
        raan_rad=0.0,
        arg_periapsis_rad=0.0,
        mean_anomaly_rad=0.0,
    )

    pos = traj.position_at()
    vel = traj.velocity_at()

    dot = np.dot(pos.xyz, vel)
    assert abs(dot) < 1e6


# State


def test_state_at() -> None:
    """Verify state_at returns a Vel carrying position and velocity."""
    traj = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.0001,
        inclination_rad=_ISS_INCLINATION_RAD,
        raan_rad=0.0,
        arg_periapsis_rad=0.0,
        mean_anomaly_rad=0.0,
    )

    state = traj.state_at()

    assert state is not None
    assert np.asarray(state.vel_xyz).shape == (3,)


def test_epoch_unix_s_property() -> None:
    """epoch_unix_s matches the configured value."""
    traj = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.0,
        inclination_rad=0.0,
        raan_rad=0.0,
        arg_periapsis_rad=0.0,
        mean_anomaly_rad=0.0,
        epoch_unix_s=1234.5,
    )

    assert traj.epoch_unix_s == pytest.approx(1234.5)


# Elements property


def test_elements_property() -> None:
    """Verify elements property returns orbital elements."""
    traj = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.001,
        inclination_rad=_ISS_INCLINATION_RAD,
        raan_rad=0.5,
        arg_periapsis_rad=0.3,
        mean_anomaly_rad=0.1,
    )

    elements = traj.elements

    assert abs(elements.semi_major_axis_m - _LEO_SMA) < 1
    assert abs(elements.eccentricity - 0.001) < 1e-10
    assert abs(elements.inclination_rad - _ISS_INCLINATION_RAD) < 1e-10


# Factory methods


def test_from_elements() -> None:
    """Verify from_elements creates equivalent trajectory."""
    traj1 = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.001,
        inclination_rad=_ISS_INCLINATION_RAD,
        raan_rad=0.0,
        arg_periapsis_rad=0.0,
        mean_anomaly_rad=0.0,
    )

    traj2 = KeplerianTrajectory.from_elements(traj1.elements)

    pos1 = traj1.position_at()
    pos2 = traj2.position_at()

    assert np.allclose(pos1.xyz, pos2.xyz, rtol=1e-10)


def test_circular_through_default_azimuth() -> None:
    """circular_through with default az=90 gives inclination = |geocentric lat|.

    Note: ``Pos.LLA`` uses geodetic latitude; the orbit inclination comes out
    equal to the point's geocentric latitude (geodetic differs from geocentric
    by <~0.2 deg due to Earth oblateness).
    """
    from gri_pos import Pos  # noqa: PLC0415

    pos = Pos.LLA(35.0, -100.0, 550_000.0)
    traj = KeplerianTrajectory.circular_through(pos)

    xyz = np.asarray(pos.xyz)
    geocentric_lat_rad = math.atan2(xyz[2], math.hypot(xyz[0], xyz[1]))

    assert traj.elements.inclination_rad == pytest.approx(
        geocentric_lat_rad,
        abs=1e-6,
    )
    assert traj.elements.eccentricity < 1e-10


def test_circular_through_passes_through_point() -> None:
    """The satellite is at the input position at dt=0."""
    from gri_pos import Pos  # noqa: PLC0415

    pos = Pos.LLA(30.0, -95.0, 600_000.0)
    traj = KeplerianTrajectory.circular_through(pos)

    state = traj.state_at()

    # Same ECEF position to within a meter (circular / two-body)
    assert np.allclose(state.xyz, pos.xyz, atol=1.0)


def test_circular_through_velocity_is_orbital_speed() -> None:
    """Velocity magnitude matches circular orbital speed sqrt(mu/r)."""
    from gri_pos import Pos  # noqa: PLC0415
    from gri_utils.constants import GM_EARTH  # noqa: PLC0415

    pos = Pos.LLA(0.0, 0.0, 550_000.0)  # equatorial, 550 km
    traj = KeplerianTrajectory.circular_through(pos)

    vel = traj.velocity_at()
    speed = float(np.linalg.norm(vel))

    r = float(np.linalg.norm(pos.xyz))
    expected = math.sqrt(GM_EARTH / r)
    # ECEF velocity differs from inertial speed by ~Earth rotation at r;
    # tolerate that ~465 m/s band.
    assert abs(speed - expected) < 700.0


def test_circular_through_azimuth_shapes_inclination() -> None:
    """cos(i) = cos(geocentric_lat) * sin(az) for arbitrary azimuth."""
    from gri_pos import Pos  # noqa: PLC0415

    az_deg = 45.0
    pos = Pos.LLA(35.0, 0.0, 550_000.0)
    xyz = np.asarray(pos.xyz)
    geocentric_lat_rad = math.atan2(xyz[2], math.hypot(xyz[0], xyz[1]))

    traj = KeplerianTrajectory.circular_through(pos, azimuth_deg=az_deg)

    expected_cos_i = math.cos(geocentric_lat_rad) * math.sin(math.radians(az_deg))
    assert math.cos(traj.elements.inclination_rad) == pytest.approx(
        expected_cos_i,
        abs=1e-6,
    )


def test_circular_through_epoch_kwarg() -> None:
    """epoch_unix_s kwarg is stored on the elements."""
    from gri_pos import Pos  # noqa: PLC0415

    traj = KeplerianTrajectory.circular_through(
        Pos.LLA(35.0, -100.0, 550_000.0),
        epoch_unix_s=12345.0,
    )

    assert traj.epoch_unix_s == pytest.approx(12345.0)


def test_repr() -> None:
    """Verify string representation."""
    traj = KeplerianTrajectory(
        semi_major_axis_m=_LEO_SMA,
        eccentricity=0.001,
        inclination_rad=_ISS_INCLINATION_RAD,
        raan_rad=0.0,
        arg_periapsis_rad=0.0,
        mean_anomaly_rad=0.0,
    )

    assert "KeplerianTrajectory" in repr(traj)
