"""Tests for StationaryTrajectory.

Tests verify that stationary trajectories return constant position and zero
velocity regardless of `dt`.
"""

from __future__ import annotations

import numpy as np
import pytest
from gri_pos import LLA, XYZ, Pos

from gri_geosim.trajectories import StationaryTrajectory

# Test positions
_POS_MUNICH = Pos.LLA(48.13743, 11.57549, 550)
_POS_EQUATOR = Pos.LLA(0.0, 0.0, 0.0)
_POS_HIGH_ALT = Pos.LLA(38.0, -77.0, 400_000.0)


# Position input formats


@pytest.mark.parametrize(
    "position",
    [
        _POS_MUNICH,
        LLA(48.13743, 11.57549, 550),
        XYZ(*_POS_MUNICH.xyz),
        _POS_MUNICH.xyz,
        list(_POS_MUNICH.xyz),
    ],
    ids=["Pos", "LLA", "XYZ", "ndarray", "list"],
)
def test_accepts_position_formats(
    position: Pos | LLA | XYZ | np.ndarray | list,
) -> None:
    """Verify trajectory accepts various position input formats."""
    traj = StationaryTrajectory(position)
    pos = traj.position_at()

    assert np.allclose(pos.xyz, _POS_MUNICH.xyz, rtol=1e-10)


def test_rejects_invalid_position() -> None:
    """Verify trajectory rejects unsupported position types."""
    with pytest.raises(TypeError, match="Unsupported position type"):
        StationaryTrajectory("invalid")  # type: ignore[arg-type]


# Position constancy


@pytest.mark.parametrize(
    "dt",
    [0.0, 3600.0, 86400.0],
    ids=["dt=0", "dt=1h", "dt=24h"],
)
def test_position_constant_over_time(dt: float) -> None:
    """Verify position remains constant regardless of dt."""
    traj = StationaryTrajectory(_POS_MUNICH)

    pos = traj.position_at(dt)

    assert np.allclose(pos.xyz, _POS_MUNICH.xyz, rtol=1e-10)


# Velocity


@pytest.mark.parametrize(
    "dt",
    [0.0, 3600.0, 86400.0],
    ids=["dt=0", "dt=1h", "dt=24h"],
)
def test_velocity_always_zero(dt: float) -> None:
    """Verify velocity is zero at all dt."""
    traj = StationaryTrajectory(_POS_MUNICH)

    vel = traj.velocity_at(dt)

    assert vel.shape == (3,)
    assert np.allclose(vel, [0.0, 0.0, 0.0])


def test_velocity_immutable() -> None:
    """Verify velocity array cannot be modified."""
    traj = StationaryTrajectory(_POS_MUNICH)
    vel = traj.velocity_at()

    with pytest.raises((TypeError, ValueError)):
        vel[0] = 999.0


# State (position + velocity)


def test_state_at() -> None:
    """Verify state_at returns a Vel carrying position and zero velocity."""
    traj = StationaryTrajectory(_POS_MUNICH)

    state = traj.state_at()

    assert np.allclose(state.xyz, _POS_MUNICH.xyz, rtol=1e-10)
    assert np.allclose(state.vel_xyz, [0.0, 0.0, 0.0])


# Properties


def test_position_property() -> None:
    """Verify position property returns the fixed position."""
    traj = StationaryTrajectory(_POS_MUNICH)

    assert np.allclose(traj.position.xyz, _POS_MUNICH.xyz, rtol=1e-10)


def test_epoch_unix_s_property_defaults_to_zero() -> None:
    """StationaryTrajectory.epoch_unix_s is zero (unused)."""
    traj = StationaryTrajectory(_POS_MUNICH)

    assert traj.epoch_unix_s == 0.0


def test_repr() -> None:
    """Verify string representation."""
    traj = StationaryTrajectory(_POS_MUNICH)

    assert "StationaryTrajectory" in repr(traj)
