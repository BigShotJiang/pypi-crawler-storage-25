"""Tests for LinearTrajectory (constant ECEF velocity)."""

from __future__ import annotations

import numpy as np
import pytest
from gri_pos import Pos, Vel

from gri_geosim.trajectories import LinearTrajectory


def _make_state() -> Vel:
    """Aircraft at 5 km, heading due east at 250 m/s (ENU)."""
    return Vel.LLA(37.5, -100.0, 5000.0, 250.0, 0.0, 0.0)


def test_rejects_non_vel() -> None:
    """Verify trajectory rejects anything that isn't a Vel."""
    pos = Pos.LLA(37.5, -100.0, 5000.0)
    with pytest.raises(TypeError, match="Vel"):
        LinearTrajectory(pos)  # type: ignore[arg-type]


def test_state_at_zero_returns_initial() -> None:
    """state_at(0) returns the initial Vel exactly."""
    initial = _make_state()
    traj = LinearTrajectory(initial)

    state = traj.state_at()

    assert np.allclose(state.xyz, initial.xyz, rtol=1e-12)
    assert np.allclose(state.vel_xyz, initial.vel_xyz, rtol=1e-12)


def test_state_at_positive_dt_advances_position() -> None:
    """Position advances by v*dt; velocity unchanged."""
    initial = _make_state()
    traj = LinearTrajectory(initial)

    dt = 60.0  # 1 minute
    state = traj.state_at(dt)

    expected_xyz = np.asarray(initial.xyz) + np.asarray(initial.vel_xyz) * dt
    assert np.allclose(state.xyz, expected_xyz, rtol=1e-12)
    assert np.allclose(state.vel_xyz, initial.vel_xyz, rtol=1e-12)


def test_state_at_negative_dt_reverses_position() -> None:
    """Negative dt extrapolates backwards."""
    initial = _make_state()
    traj = LinearTrajectory(initial)

    state = traj.state_at(-30.0)

    expected_xyz = np.asarray(initial.xyz) - np.asarray(initial.vel_xyz) * 30.0
    assert np.allclose(state.xyz, expected_xyz, rtol=1e-12)


def test_position_and_velocity_accessors() -> None:
    """position_at returns Pos; velocity_at returns (3,) ndarray."""
    initial = _make_state()
    traj = LinearTrajectory(initial)

    pos = traj.position_at(10.0)
    vel = traj.velocity_at(10.0)

    assert isinstance(pos, Pos)
    assert np.asarray(vel).shape == (3,)
    assert np.allclose(vel, initial.vel_xyz, rtol=1e-12)


def test_epoch_unix_s_defaults_to_zero() -> None:
    """epoch_unix_s defaults to 0 and is settable via kwarg."""
    initial = _make_state()
    traj_default = LinearTrajectory(initial)
    traj_set = LinearTrajectory(initial, epoch_unix_s=12345.0)

    assert traj_default.epoch_unix_s == 0.0
    assert traj_set.epoch_unix_s == 12345.0


def test_initial_state_property() -> None:
    """initial_state returns the Vel passed to the constructor."""
    initial = _make_state()
    traj = LinearTrajectory(initial)

    assert traj.initial_state is initial


def test_zero_velocity_behaves_like_stationary() -> None:
    """Vel with zero velocity gives a stationary trajectory."""
    initial = Vel(Pos.LLA(38.0, -77.0, 100.0))
    traj = LinearTrajectory(initial)

    state_later = traj.state_at(3600.0)

    assert np.allclose(state_later.xyz, initial.xyz, rtol=1e-12)
    assert np.allclose(state_later.vel_xyz, [0.0, 0.0, 0.0])


def test_repr() -> None:
    """Repr includes speed."""
    traj = LinearTrajectory(_make_state())

    assert "LinearTrajectory" in repr(traj)
    assert "250" in repr(traj)
