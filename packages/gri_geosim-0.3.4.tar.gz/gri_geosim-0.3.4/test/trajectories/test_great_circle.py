"""Tests for GreatCircleTrajectory.

Tests verify ECEF-fixed great-circle motion: constant total speed,
constant flight-path angle, altitude grows linearly when elevation_deg
is non-zero, and initial azimuth changes along the path (NOT rhumb).
"""

from __future__ import annotations

import numpy as np
import pytest
from gri_pos import Pos
from gri_utils.conversion import aer_to_xyz

from gri_geosim.trajectories import GreatCircleTrajectory


def test_rejects_invalid_speed() -> None:
    """speed_mps must be positive."""
    with pytest.raises(ValueError, match="speed_mps must be positive"):
        GreatCircleTrajectory(
            Pos.LLA(0.0, 0.0, 0.0),
            azimuth_deg=90.0,
            speed_mps=0.0,
        )


def test_rejects_extreme_elevation() -> None:
    """|elevation_deg| must be < 90."""
    with pytest.raises(ValueError, match="elevation_deg"):
        GreatCircleTrajectory(
            Pos.LLA(0.0, 0.0, 0.0),
            azimuth_deg=90.0,
            speed_mps=10.0,
            elevation_deg=90.0,
        )


def test_rejects_invalid_position() -> None:
    """Unsupported start_pos types raise TypeError."""
    with pytest.raises(TypeError, match="Unsupported start_pos type"):
        GreatCircleTrajectory(
            "invalid",  # ty: ignore[invalid-argument-type]
            azimuth_deg=90.0,
            speed_mps=10.0,
        )


def test_position_at_epoch_equals_start() -> None:
    """At dt=0, position equals start_pos."""
    start = Pos.LLA(48.0, 11.5, 11_000.0)
    traj = GreatCircleTrajectory(start, azimuth_deg=45.0, speed_mps=200.0)
    pos = traj.position_at()
    assert np.allclose(pos.xyz, start.xyz, rtol=1e-10)


def test_speed_conserved_level_flight() -> None:
    """At el=0, speed magnitude is exactly speed_mps for all dt."""
    traj = GreatCircleTrajectory(
        Pos.LLA(48.0, 11.5, 11_000.0),
        azimuth_deg=45.0,
        speed_mps=250.0,
    )
    for dt_s in (0.0, 60.0, 3600.0, 7200.0):
        vel = traj.velocity_at(dt_s)
        assert np.isclose(np.linalg.norm(vel), 250.0, rtol=1e-10)


def test_speed_conserved_climbing() -> None:
    """Total speed magnitude is conserved when elevation_deg != 0."""
    traj = GreatCircleTrajectory(
        Pos.LLA(0.0, 0.0, 1_000.0),
        azimuth_deg=90.0,
        speed_mps=300.0,
        elevation_deg=10.0,
    )
    for dt_s in (0.0, 100.0, 1000.0):
        vel = traj.velocity_at(dt_s)
        assert np.isclose(np.linalg.norm(vel), 300.0, rtol=1e-9)


def test_eastbound_at_equator_stays_on_equator() -> None:
    """Az=90, el=0 from (lat=0, lon=0) keeps lat ~ 0 along the path."""
    traj = GreatCircleTrajectory(
        Pos.LLA(0.0, 0.0, 0.0),
        azimuth_deg=90.0,
        speed_mps=300.0,
    )
    for dt_s in (60.0, 600.0, 3600.0):
        pos = traj.position_at(dt_s)
        lat = pos.lla.lat_deg
        assert abs(lat) < 1e-6


def test_north_from_equator_follows_meridian() -> None:
    """Az=0 from (lat=0, lon=0) keeps lon ~ 0 (great circle is the meridian)."""
    traj = GreatCircleTrajectory(
        Pos.LLA(0.0, 0.0, 0.0),
        azimuth_deg=0.0,
        speed_mps=300.0,
    )
    for dt_s in (60.0, 600.0, 3600.0):
        pos = traj.position_at(dt_s)
        lon = pos.lla.lon_deg
        assert abs(lon) < 1e-6


def test_climb_rate_matches_elevation() -> None:
    """Vertical (radial) speed equals speed * sin(elevation_deg)."""
    speed = 300.0
    el = 10.0
    traj = GreatCircleTrajectory(
        Pos.LLA(0.0, 0.0, 1_000.0),
        azimuth_deg=90.0,
        speed_mps=speed,
        elevation_deg=el,
    )
    pos0 = traj.position_at()
    pos1 = traj.position_at(10.0)
    r0 = float(np.linalg.norm(pos0.xyz))
    r1 = float(np.linalg.norm(pos1.xyz))
    radial_speed_obs = (r1 - r0) / 10.0
    expected = speed * np.sin(np.radians(el))
    assert np.isclose(radial_speed_obs, expected, rtol=1e-9)


def test_great_circle_not_rhumb() -> None:
    """High-latitude eastbound path drifts in latitude (great circle != rhumb).

    A rhumb line at constant az=90 from a high latitude stays at that
    latitude. A great circle starting due-east from the same point bends
    toward the equator; latitude should change measurably after enough
    travel.
    """
    traj = GreatCircleTrajectory(
        Pos.LLA(60.0, 0.0, 0.0),
        azimuth_deg=90.0,
        speed_mps=300.0,
    )
    pos = traj.position_at(43_200.0)
    lat = pos.lla.lat_deg
    assert abs(lat - 60.0) > 1.0


def test_state_at_matches_separate_calls() -> None:
    """state_at returns the same (pos, vel) as position_at + velocity_at."""
    traj = GreatCircleTrajectory(
        Pos.LLA(48.0, 11.5, 11_000.0),
        azimuth_deg=270.0,
        speed_mps=240.0,
        elevation_deg=-2.0,
    )
    pos_a = traj.position_at(500.0)
    vel_a = traj.velocity_at(500.0)
    state = traj.state_at(500.0)
    assert np.allclose(pos_a.xyz, state.xyz, rtol=1e-12)
    assert np.allclose(vel_a, state.vel_xyz, rtol=1e-12)


def test_velocity_magnitude_at_epoch() -> None:
    """At dt=0, |velocity| equals speed_mps regardless of az/el/lat."""
    speed = 200.0
    cases = [
        (Pos.LLA(0.0, 0.0, 0.0), 90.0, 0.0),
        (Pos.LLA(48.0, 11.5, 11_000.0), 30.0, 5.0),
        (Pos.LLA(-30.0, 120.0, 0.0), 200.0, -3.0),
    ]
    for start, az, el in cases:
        traj = GreatCircleTrajectory(
            start,
            azimuth_deg=az,
            speed_mps=speed,
            elevation_deg=el,
        )
        v = traj.velocity_at()
        assert np.isclose(np.linalg.norm(v), speed, rtol=1e-12)


def test_velocity_at_equator_matches_aer() -> None:
    """At lat=0, geocentric and geodetic ENU agree, so velocity == aer_to_xyz."""
    start = Pos.LLA(0.0, 0.0, 0.0)
    az, el, speed = 30.0, 5.0, 200.0
    traj = GreatCircleTrajectory(
        start,
        azimuth_deg=az,
        speed_mps=speed,
        elevation_deg=el,
    )
    expected = np.asarray(aer_to_xyz(start.xyz, [az, el, speed]))
    vel = traj.velocity_at()
    assert np.allclose(vel, expected, rtol=1e-9)
