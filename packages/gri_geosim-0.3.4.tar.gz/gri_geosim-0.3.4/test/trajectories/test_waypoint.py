"""Tests for WaypointTrajectory.

Tests verify interpolation between waypoints using linear and cubic methods.
"""

from __future__ import annotations

import numpy as np
import pytest
from gri_pos import LLA, XYZ, Pos

from gri_geosim.trajectories import WaypointTrajectory

# Waypoint dt (seconds from trajectory epoch) and positions
_DT0 = 0.0
_DT1 = 3600.0  # 1 hour
_DT2 = 7200.0  # 2 hours

_POS_START = Pos.LLA(38.0, -77.0, 1000.0)
_POS_END = Pos.LLA(39.0, -76.0, 1000.0)
_POS_MID = Pos.LLA(40.0, -75.0, 1000.0)


# Validation


def test_requires_two_waypoints() -> None:
    """Verify trajectory requires at least two waypoints."""
    with pytest.raises(ValueError, match="At least 2 waypoints"):
        WaypointTrajectory([(_DT0, _POS_START)])


def test_requires_increasing_times() -> None:
    """Verify waypoint times must be strictly increasing."""
    with pytest.raises(ValueError, match="strictly increasing"):
        WaypointTrajectory(
            [
                (_DT1, _POS_START),
                (_DT0, _POS_END),
            ],
        )


def test_rejects_invalid_interpolation() -> None:
    """Verify trajectory rejects unknown interpolation method."""
    with pytest.raises(ValueError, match="Unknown interpolation"):
        WaypointTrajectory(
            [(_DT0, _POS_START), (_DT1, _POS_END)],
            interpolation="spline",  # ty: ignore[invalid-argument-type]
        )


# Position input formats


@pytest.mark.parametrize(
    "position_type",
    ["Pos", "LLA", "XYZ", "ndarray", "list"],
)
def test_accepts_position_formats(position_type: str) -> None:
    """Verify trajectory accepts various position input formats."""
    if position_type == "Pos":
        pos = _POS_START
    elif position_type == "LLA":
        pos = LLA(38.0, -77.0, 1000.0)
    elif position_type == "XYZ":
        pos = XYZ(*_POS_START.xyz)
    elif position_type == "ndarray":
        pos = _POS_START.xyz
    else:  # list
        pos = list(_POS_START.xyz)

    traj = WaypointTrajectory([(_DT0, pos), (_DT1, _POS_END)])
    result = traj.position_at(_DT0)

    assert np.allclose(result.xyz, _POS_START.xyz, rtol=1e-6)


# Linear interpolation


@pytest.mark.parametrize(
    ("query_fraction", "expected_lat"),
    [
        (0.0, 38.0),
        (0.5, 38.5),
        (1.0, 39.0),
    ],
    ids=["start", "middle", "end"],
)
def test_linear_interpolation_position(
    query_fraction: float,
    expected_lat: float,
) -> None:
    """Verify linear interpolation produces expected positions."""
    waypoints = [
        (_DT0, Pos.LLA(38.0, -77.0, 1000.0)),
        (_DT1, Pos.LLA(39.0, -77.0, 1000.0)),
    ]
    traj = WaypointTrajectory(waypoints, interpolation="linear")

    pos = traj.position_at(query_fraction * 3600.0)

    assert abs(pos.lla.lat_deg - expected_lat) < 0.1


def test_linear_extrapolation() -> None:
    """Verify linear interpolation extrapolates beyond waypoints."""
    waypoints = [(_DT0, _POS_START), (_DT1, _POS_END)]
    traj = WaypointTrajectory(waypoints, interpolation="linear")

    pos_before = traj.position_at(-1800.0)

    assert pos_before is not None


# Cubic interpolation


def test_cubic_interpolation() -> None:
    """Verify cubic interpolation produces smooth results."""
    waypoints = [
        (_DT0, _POS_START),
        (_DT1, _POS_END),
        (_DT2, _POS_MID),
    ]
    traj = WaypointTrajectory(waypoints, interpolation="cubic")

    pos = traj.position_at(1800.0)

    assert pos is not None


def test_cubic_velocity() -> None:
    """Verify cubic interpolation provides smooth velocity."""
    waypoints = [
        (_DT0, _POS_START),
        (_DT1, _POS_END),
        (_DT2, _POS_MID),
    ]
    traj = WaypointTrajectory(waypoints, interpolation="cubic")

    vel = traj.velocity_at(1800.0)

    assert vel.shape == (3,)
    assert np.linalg.norm(vel) > 0


# Velocity


def test_linear_velocity_consistent() -> None:
    """Verify linear interpolation gives constant velocity within a segment.

    With analytic segment slope, two queries within the same segment
    return bit-identical velocity vectors.
    """
    waypoints = [(_DT0, _POS_START), (_DT1, _POS_END)]
    traj = WaypointTrajectory(waypoints, interpolation="linear")

    vel1 = traj.velocity_at(100.0)
    vel2 = traj.velocity_at(3500.0)

    assert np.array_equal(vel1, vel2)


def test_linear_velocity_is_analytic_slope() -> None:
    """Linear velocity equals (p1 - p0) / (t1 - t0), exactly."""
    waypoints = [(_DT0, _POS_START), (_DT1, _POS_END)]
    traj = WaypointTrajectory(waypoints, interpolation="linear")

    expected = (_POS_END.xyz - _POS_START.xyz) / 3600.0
    vel = traj.velocity_at(1800.0)

    assert np.allclose(vel, expected, rtol=1e-12)


def test_linear_velocity_changes_across_segments() -> None:
    """Velocity differs between segments with different slopes."""
    waypoints = [
        (_DT0, _POS_START),
        (_DT1, _POS_END),
        (_DT2, _POS_MID),
    ]
    traj = WaypointTrajectory(waypoints, interpolation="linear")

    vel_seg0 = traj.velocity_at(1800.0)  # in segment 0->1
    vel_seg1 = traj.velocity_at(_DT1 + 1800.0)  # in segment 1->2

    expected_0 = (_POS_END.xyz - _POS_START.xyz) / 3600.0
    expected_1 = (_POS_MID.xyz - _POS_END.xyz) / 3600.0

    assert np.allclose(vel_seg0, expected_0, rtol=1e-12)
    assert np.allclose(vel_seg1, expected_1, rtol=1e-12)
    assert not np.allclose(vel_seg0, vel_seg1)


def test_linear_velocity_extrapolation() -> None:
    """Outside the waypoint range, velocity is the first/last segment slope."""
    waypoints = [
        (_DT0, _POS_START),
        (_DT1, _POS_END),
        (_DT2, _POS_MID),
    ]
    traj = WaypointTrajectory(waypoints, interpolation="linear")

    vel_before = traj.velocity_at(-1000.0)
    expected_first = (_POS_END.xyz - _POS_START.xyz) / 3600.0
    assert np.allclose(vel_before, expected_first, rtol=1e-12)

    vel_after = traj.velocity_at(_DT2 + 1000.0)
    expected_last = (_POS_MID.xyz - _POS_END.xyz) / 3600.0
    assert np.allclose(vel_after, expected_last, rtol=1e-12)


# State


def test_state_at() -> None:
    """Verify state_at returns a Vel carrying position and velocity."""
    waypoints = [(_DT0, _POS_START), (_DT1, _POS_END)]
    traj = WaypointTrajectory(waypoints)

    state = traj.state_at(1800.0)

    assert state is not None
    assert np.asarray(state.vel_xyz).shape == (3,)


# Properties


def test_interpolation_property() -> None:
    """Verify interpolation property returns correct method."""
    traj_linear = WaypointTrajectory(
        [(_DT0, _POS_START), (_DT1, _POS_END)],
        interpolation="linear",
    )
    traj_cubic = WaypointTrajectory(
        [(_DT0, _POS_START), (_DT1, _POS_END)],
        interpolation="cubic",
    )

    assert traj_linear.interpolation == "linear"
    assert traj_cubic.interpolation == "cubic"


def test_num_waypoints_property() -> None:
    """Verify num_waypoints returns correct count."""
    traj = WaypointTrajectory(
        [
            (_DT0, _POS_START),
            (_DT1, _POS_END),
            (_DT2, _POS_MID),
        ],
    )

    assert traj.num_waypoints == 3


def test_dt_properties() -> None:
    """Verify start_dt and end_dt properties."""
    traj = WaypointTrajectory([(_DT0, _POS_START), (_DT1, _POS_END)])

    assert traj.start_dt == _DT0
    assert traj.end_dt == _DT1


def test_epoch_unix_s_property() -> None:
    """epoch_unix_s defaults to 0 and is settable."""
    traj_default = WaypointTrajectory([(_DT0, _POS_START), (_DT1, _POS_END)])
    traj_set = WaypointTrajectory(
        [(_DT0, _POS_START), (_DT1, _POS_END)],
        epoch_unix_s=12345.0,
    )

    assert traj_default.epoch_unix_s == 0.0
    assert traj_set.epoch_unix_s == 12345.0


def test_repr() -> None:
    """Verify string representation."""
    traj = WaypointTrajectory([(_DT0, _POS_START), (_DT1, _POS_END)])

    assert "WaypointTrajectory" in repr(traj)
    assert "2 waypoints" in repr(traj)
