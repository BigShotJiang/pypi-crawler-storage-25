"""Keplerian trajectory for two-body orbital mechanics.

A KeplerianTrajectory represents a satellite or spacecraft following a
Keplerian orbit. It uses gri-utils orbital mechanics for propagation and
coordinate conversion.

This is a fast propagator optimized for short-duration trajectories (minutes
to a few hours). It uses simplified two-body dynamics with no perturbations,
making it computationally efficient but less accurate over longer time spans.

For longer propagation periods (hours to days), use Sgp4Trajectory with TLE
data instead. SGP4 accounts for drag, J2 perturbations, and other effects
that become significant over extended durations.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_pos import Pos, Vel
from gri_utils.conversion import eci_to_ecef, eci_to_ecef_vel
from gri_utils.orbit import (
    OrbitalElements,
    OrbitState,
    elements_to_state,
    from_circular,
    from_tle,
)

if TYPE_CHECKING:
    from numpy.typing import NDArray


class KeplerianTrajectory:
    """Trajectory using Keplerian two-body orbital mechanics.

    Propagates orbital elements forward or backward in time using the
    analytic two-body solution. Position and velocity are returned in
    the ECEF frame for compatibility with ground-based observations.

    Queries use `dt` in seconds relative to `epoch_unix_s` (which is drawn
    from the orbital elements' epoch). `dt=0` returns the state at that
    epoch.

    Attributes:
        elements: The OrbitalElements defining this orbit.

    Example:
        >>> import math
        >>> traj = KeplerianTrajectory(
        ...     semi_major_axis_m=6_778_000,
        ...     eccentricity=0.0001,
        ...     inclination_rad=math.radians(51.6),
        ...     raan_rad=0.0,
        ...     arg_periapsis_rad=0.0,
        ...     mean_anomaly_rad=0.0,
        ... )
        >>> state = traj.state_at()
    """

    __slots__ = ("_elements",)

    def __init__(  # noqa: PLR0913
        self,
        semi_major_axis_m: float,
        eccentricity: float,
        inclination_rad: float,
        raan_rad: float,
        arg_periapsis_rad: float,
        mean_anomaly_rad: float,
        epoch_unix_s: float = 0.0,
    ) -> None:
        """Initialize a Keplerian trajectory from orbital elements.

        Args:
            semi_major_axis_m: Semi-major axis in meters.
            eccentricity: Orbital eccentricity (0 = circular, 0 < e < 1
                elliptical).
            inclination_rad: Inclination in radians [0, pi].
            raan_rad: Right Ascension of Ascending Node in radians [0, 2*pi).
            arg_periapsis_rad: Argument of periapsis in radians [0, 2*pi).
            mean_anomaly_rad: Mean anomaly at epoch in radians [0, 2*pi).
            epoch_unix_s: Unix time (seconds) that `dt=0` corresponds to.
                Only matters if querying via absolute times downstream;
                defaults to 0.0 for snapshot-only use.

        Raises:
            ValueError: If eccentricity >= 1 (hyperbolic/parabolic not
                supported).
            ValueError: If semi_major_axis_m <= 0.
        """
        if semi_major_axis_m <= 0:
            raise ValueError(
                f"Semi-major axis must be positive, got {semi_major_axis_m}",
            )
        if eccentricity < 0 or eccentricity >= 1:
            msg = (
                f"Eccentricity must be in [0, 1) for elliptical orbits, "
                f"got {eccentricity}"
            )
            raise ValueError(msg)

        self._elements = OrbitalElements(
            semi_major_axis_m=semi_major_axis_m,
            eccentricity=eccentricity,
            inclination_rad=inclination_rad,
            raan_rad=raan_rad,
            arg_periapsis_rad=arg_periapsis_rad,
            mean_anomaly_rad=mean_anomaly_rad,
            epoch_unix_s=epoch_unix_s,
        )

    @classmethod
    def from_elements(cls, elements: OrbitalElements) -> KeplerianTrajectory:
        """Create a trajectory from an existing OrbitalElements object.

        Args:
            elements: OrbitalElements NamedTuple from gri-utils.

        Returns:
            KeplerianTrajectory with the given elements.
        """
        return cls(
            semi_major_axis_m=elements.semi_major_axis_m,
            eccentricity=elements.eccentricity,
            inclination_rad=elements.inclination_rad,
            raan_rad=elements.raan_rad,
            arg_periapsis_rad=elements.arg_periapsis_rad,
            mean_anomaly_rad=elements.mean_anomaly_rad,
            epoch_unix_s=elements.epoch_unix_s,
        )

    @classmethod
    def circular_through(
        cls,
        pos: Pos,
        azimuth_deg: float = 90.0,
        *,
        epoch_unix_s: float = 0.0,
    ) -> KeplerianTrajectory:
        """Build a circular orbit passing through a point with a given heading.

        Chains `gri_utils.orbit.from_circular` to build the orbital elements,
        then wraps them as a KeplerianTrajectory.

        With the default `azimuth_deg=90` (due east), the input point is the
        northernmost/southernmost point of the orbit and the inclination is
        exactly `|lat|`. For other azimuths, inclination satisfies
        `cos(i) = cos(lat) * sin(az)`. See `from_circular` for details.

        Args:
            pos: A point the circular orbit must pass through (ECEF/LLA via
                Pos). Orbit radius is taken from the point's distance from
                Earth's center.
            azimuth_deg: Compass azimuth of the velocity at the point, in
                degrees. 0 = north, 90 = east (default, prograde equatorward),
                180 = south, 270 = west. Values >= 180 produce retrograde
                orbits.
            epoch_unix_s: Unix time that `dt=0` corresponds to. Defaults to
                0.0 (sensible for snapshots; set to a real timestamp if you
                plan to query via absolute times downstream).

        Returns:
            KeplerianTrajectory for the circular orbit through `pos`.

        Example:
            >>> from gri_pos import Pos
            >>> sat = KeplerianTrajectory.circular_through(
            ...     Pos.LLA(35.0, -100.0, 550_000.0),
            ... )
            >>> state = sat.state_at()
        """
        elements = from_circular(
            np.asarray(pos.xyz, dtype=np.float64),
            epoch_unix_s,
            azimuth_deg=azimuth_deg,
        )
        return cls.from_elements(elements)

    @classmethod
    def from_tle(cls, line1: str, line2: str) -> KeplerianTrajectory:
        """Create a Keplerian trajectory from TLE data.

        Parses Two-Line Element data and extracts orbital elements. Note that
        this uses simple Keplerian propagation, which does not account for
        drag or perturbations encoded in the TLE. For higher fidelity, use
        Sgp4Trajectory instead.

        Args:
            line1: First line of TLE data.
            line2: Second line of TLE data.

        Returns:
            KeplerianTrajectory with elements (and epoch) extracted from TLE.

        Raises:
            ValueError: If TLE data is invalid or cannot be parsed.
        """
        elements = from_tle(line1, line2)
        return cls.from_elements(elements)

    @property
    def elements(self) -> OrbitalElements:
        """The orbital elements defining this trajectory."""
        return self._elements

    @property
    def epoch_unix_s(self) -> float:
        """Unix time (seconds) that `dt=0` corresponds to."""
        return self._elements.epoch_unix_s

    def position_at(self, dt: float = 0.0) -> Pos:
        """Get satellite position at `dt` seconds from the trajectory epoch."""
        return self.state_at(dt)

    def velocity_at(self, dt: float = 0.0) -> NDArray[np.floating]:
        """Get satellite ECEF velocity at `dt` seconds from the trajectory epoch."""
        return np.asarray(self.state_at(dt).vel_xyz, dtype=np.float64)

    def state_at(self, dt: float = 0.0) -> Vel:
        """Get the state at `dt` seconds from the trajectory epoch.

        Args:
            dt: Seconds from `epoch_unix_s`.

        Returns:
            Vel in the ECEF frame carrying both position and velocity.
        """
        unix_s = self._elements.epoch_unix_s + dt

        # Propagate orbit in ECI frame (scalar time returns single OrbitState)
        state = elements_to_state(self._elements, unix_s)
        if not isinstance(state, OrbitState):
            raise TypeError("Expected single OrbitState from scalar time input")

        # Convert ECI to ECEF
        pos_ecef = np.asarray(
            eci_to_ecef(state.position_eci_m, unix_s),
            dtype=np.float64,
        )
        vel_ecef = np.asarray(
            eci_to_ecef_vel(
                state.position_eci_m,
                state.velocity_eci_ms,
                unix_s,
            ),
            dtype=np.float64,
        )

        return Vel.XYZ(
            pos_ecef[0],
            pos_ecef[1],
            pos_ecef[2],
            vel_ecef[0],
            vel_ecef[1],
            vel_ecef[2],
        )

    def __repr__(self) -> str:
        """Return string representation."""
        e = self._elements
        return (
            f"KeplerianTrajectory(a={e.semi_major_axis_m:.0f}m, "
            f"e={e.eccentricity:.6f}, i={np.degrees(e.inclination_rad):.2f} deg)"
        )
