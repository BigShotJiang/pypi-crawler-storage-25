"""SGP4 trajectory for TLE-based satellite propagation.

An Sgp4Trajectory represents a satellite using the SGP4/SDP4 propagation
model from the python-sgp4 library. This provides higher fidelity than
simple Keplerian propagation by including atmospheric drag and J2 effects.

SGP4 is the standard propagation model for satellite catalog data (TLEs).
It's suitable for propagating TLEs for several days to weeks from epoch.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_nsepoch import Time
from gri_pos import Pos, Vel
from gri_utils.conversion import teme_to_ecef, teme_to_ecef_vel
from gri_utils.orbit import from_tle
from sgp4.api import Satrec

if TYPE_CHECKING:
    from numpy.typing import NDArray


class Sgp4Trajectory:
    """Trajectory using SGP4/SDP4 propagation from TLE data.

    SGP4 (Simplified General Perturbations 4) is the standard propagation
    model for satellite Two-Line Element sets. It accounts for:
    - J2, J3, J4 gravitational perturbations
    - Atmospheric drag
    - Solar radiation pressure (for deep-space objects)

    This provides higher accuracy than simple Keplerian propagation,
    especially for low Earth orbit satellites where drag is significant.

    Attributes:
        satrec: The underlying python-sgp4 Satrec object.
        line1: First line of TLE data.
        line2: Second line of TLE data.

    Example:
        >>> tle1 = "1 25544U 98067A   24001.50000000 ..."
        >>> tle2 = "2 25544  51.6400  10.5000 ..."
        >>> traj = Sgp4Trajectory(tle1, tle2)
        >>> state_at_epoch = traj.state_at()           # at TLE epoch
        >>> state_60s_later = traj.state_at(60.0)      # 60 s from TLE epoch
    """

    __slots__ = ("_epoch_unix_s", "_line1", "_line2", "_satrec")

    def __init__(self, line1: str, line2: str) -> None:
        """Initialize an SGP4 trajectory from TLE data.

        Args:
            line1: First line of TLE data (69 characters).
            line2: Second line of TLE data (69 characters).

        Raises:
            ValueError: If TLE data is invalid.

        Example:
            >>> tle1 = "1 25544U 98067A   24001.50000000 ..."
            >>> tle2 = "2 25544  51.6400  10.5000 ..."
            >>> traj = Sgp4Trajectory(tle1, tle2)
        """
        self._line1 = line1.strip()
        self._line2 = line2.strip()

        # Parse TLE and create satellite record
        self._satrec: Satrec = Satrec.twoline2rv(self._line1, self._line2)

        # Check for parsing errors (error code in satnum field for parse errors)
        if self._satrec.error != 0:
            raise ValueError(
                f"Invalid TLE data: SGP4 error code {self._satrec.error}",
            )

        # Extract the TLE's absolute epoch (Unix seconds) for `dt` anchoring.
        self._epoch_unix_s: float = from_tle(self._line1, self._line2).epoch_unix_s

    @property
    def satrec(self) -> Satrec:
        """The underlying python-sgp4 Satrec object."""
        return self._satrec

    @property
    def line1(self) -> str:
        """First line of TLE data."""
        return self._line1

    @property
    def line2(self) -> str:
        """Second line of TLE data."""
        return self._line2

    @property
    def satellite_number(self) -> int:
        """NORAD catalog number of the satellite."""
        return int(self._satrec.satnum)

    @property
    def epoch_unix_s(self) -> float:
        """Absolute Unix time (seconds) that `dt=0` corresponds to (TLE epoch)."""
        return self._epoch_unix_s

    def position_at(self, dt: float = 0.0) -> Pos:
        """Get satellite position at `dt` seconds from the TLE epoch."""
        return self.state_at(dt)

    def velocity_at(self, dt: float = 0.0) -> NDArray[np.floating]:
        """Get satellite ECEF velocity at `dt` seconds from the TLE epoch."""
        return np.asarray(self.state_at(dt).vel_xyz, dtype=np.float64)

    def state_at(self, dt: float = 0.0) -> Vel:
        """Get the state at `dt` seconds from the TLE epoch.

        Args:
            dt: Seconds from `epoch_unix_s`.

        Returns:
            Vel in the ECEF frame carrying both position and velocity.

        Raises:
            RuntimeError: If SGP4 propagation fails.
        """
        unix_s = self._epoch_unix_s + float(dt)
        time = Time(s=unix_s)
        jd, fr = time.jd

        error, r_teme_km, v_teme_kms = self._satrec.sgp4(jd, fr)

        if error != 0:
            raise RuntimeError(
                f"SGP4 propagation failed with error code {error}",
            )

        # Convert km to meters and km/s to m/s
        r_teme_m = np.array(r_teme_km) * 1000.0
        v_teme_ms = np.array(v_teme_kms) * 1000.0

        # Convert TEME to ECEF
        r_ecef_m = np.asarray(teme_to_ecef(r_teme_m, unix_s), dtype=np.float64)
        v_ecef_ms = np.asarray(
            teme_to_ecef_vel(r_teme_m, v_teme_ms, unix_s),
            dtype=np.float64,
        )

        return Vel.XYZ(
            r_ecef_m[0],
            r_ecef_m[1],
            r_ecef_m[2],
            v_ecef_ms[0],
            v_ecef_ms[1],
            v_ecef_ms[2],
        )

    def __repr__(self) -> str:
        """Return string representation."""
        return f"Sgp4Trajectory(satnum={self.satellite_number})"
