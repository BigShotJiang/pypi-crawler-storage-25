"""Trajectory protocol for platform motion.

A Trajectory defines how a platform moves through space over time. It provides
the state (position + velocity, bundled as a Vel) at a relative time offset
`dt` (seconds) from the trajectory's own epoch.

Each trajectory owns an `epoch_unix_s` property: the absolute Unix time that
corresponds to `dt=0`. Consumers that still work in absolute wall-clock time
(Platform, Emitter, Scenario) subtract `epoch_unix_s` from a `Time` to get the
`dt` to hand the trajectory. Trajectories that don't care about absolute time
default `epoch_unix_s` to `0.0`.

Implementations include:
- StationaryTrajectory: Fixed position, zero velocity.
- LinearTrajectory: Constant ECEF velocity.
- KeplerianTrajectory: Two-body orbital mechanics (gri-utils).
- Sgp4Trajectory: SGP4/SDP4 TLE propagation (python-sgp4). Epoch is the TLE
  epoch, extracted from the TLE lines.
- WaypointTrajectory: Interpolated path through position waypoints.
- HermiteTrajectory: Hermite interpolation of (position, velocity) knots.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Protocol, runtime_checkable

if TYPE_CHECKING:
    import numpy as np
    from gri_pos import Pos, Vel
    from numpy.typing import NDArray


@runtime_checkable
class Trajectory(Protocol):
    """Protocol for platform motion trajectories.

    All query methods take `dt` in seconds relative to the trajectory's
    `epoch_unix_s`. `dt=0` returns the state at the trajectory's reference
    moment (the snapshot for which it was constructed).
    """

    @property
    def epoch_unix_s(self) -> float:
        """Absolute Unix time (seconds) corresponding to `dt=0`."""
        ...

    def state_at(self, dt: float = 0.0) -> Vel:
        """Get the platform state at `dt` seconds from the trajectory epoch.

        Args:
            dt: Seconds from `epoch_unix_s`. Defaults to 0.0 (the snapshot).

        Returns:
            Vel in the ECEF frame carrying both position and velocity.
        """
        ...

    def position_at(self, dt: float = 0.0) -> Pos:
        """Get platform position at `dt` seconds from the trajectory epoch.

        Args:
            dt: Seconds from `epoch_unix_s`.

        Returns:
            Pos in the ECEF frame.
        """
        ...

    def velocity_at(self, dt: float = 0.0) -> NDArray[np.floating]:
        """Get platform velocity at `dt` seconds from the trajectory epoch.

        Args:
            dt: Seconds from `epoch_unix_s`.

        Returns:
            Velocity vector [vx, vy, vz] in ECEF frame, meters per second.
            Shape: (3,).
        """
        ...
