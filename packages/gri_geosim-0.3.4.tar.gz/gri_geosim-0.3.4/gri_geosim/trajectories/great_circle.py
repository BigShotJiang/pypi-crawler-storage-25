"""Great-circle trajectory fixed in the ECEF frame.

A GreatCircleTrajectory represents a platform following a great circle
defined by a starting position and an initial azimuth, at constant total
speed and constant flight-path angle. The orbit plane is fixed in ECEF,
so the platform travels with the rotating Earth: an aircraft heading due
east at the equator stays at the equator.

The "great circle" here is a geometric circle in 3D ECEF whose plane
passes through the origin (the geocenter), with radius equal to the
ECEF magnitude of the start position. This is the geocentric great
circle, not a geodesic on the WGS84 ellipsoid. The two diverge by ~0.2%
at non-equatorial latitudes; for visualization-quality work over typical
ranges this is acceptable. Use a Vincenty geodesic solver if exact
ellipsoidal geodesics matter.

For inertially-fixed circular motion (a satellite whose orbit plane does
not rotate with the Earth), use CircularOrbitTrajectory instead.

Use cases: aircraft on a constant-direction route, vehicles on the
ground over distances long enough that Earth curvature matters.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_pos import LLA, XYZ, Pos, Vel
from gri_utils.conversion import aer_to_xyz

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


class GreatCircleTrajectory:
    """Trajectory along an ECEF-fixed great circle at constant speed.

    The platform's motion is decomposed into:
        - horizontal speed (speed * cos(elevation_deg)) along the great
          circle, producing a circular path in the orbit plane.
        - vertical speed (speed * sin(elevation_deg)) along the local
          radial direction, growing the altitude linearly with time.

    Total speed magnitude is conserved. When elevation_deg != 0, the
    angular rate decays as altitude grows so that the horizontal speed
    stays constant.

    Closed form (with v_z = speed*sin(el), h = speed*cos(el),
    r0 = ||start_xyz||):
        r(dt) = r0 + v_z * dt
        theta(dt) = h * dt / r0,                  if v_z == 0
        theta(dt) = (h / v_z) * ln(1 + v_z*dt / r0), if v_z != 0
        pos(dt) = r(dt) * (cos(theta) * r_hat + sin(theta) * u_hat)

    Attributes:
        azimuth_deg: Initial bearing from local north (clockwise).
        speed_mps: Total speed magnitude (m/s), conserved over time.
        elevation_deg: Flight-path angle above local horizon (degrees).

    Example:
        >>> from gri_pos import Pos
        >>> # Aircraft heading east at 200 m/s from Munich
        >>> traj = GreatCircleTrajectory(
        ...     Pos.LLA(48.137, 11.575, 11_000.0),
        ...     azimuth_deg=90.0,
        ...     speed_mps=200.0,
        ... )
    """

    __slots__ = (
        "_azimuth_deg",
        "_elevation_deg",
        "_epoch_unix_s",
        "_h_speed",
        "_n_hat",
        "_r0",
        "_r_hat",
        "_speed_mps",
        "_u_hat",
        "_v_z",
    )

    def __init__(
        self,
        start_pos: Pos | LLA | XYZ | np.ndarray | Sequence[float],
        azimuth_deg: float,
        speed_mps: float,
        *,
        elevation_deg: float = 0.0,
        epoch_unix_s: float = 0.0,
    ) -> None:
        """Initialize a great-circle trajectory.

        Args:
            start_pos: Position at `dt=0`. Accepts Pos, LLA, XYZ, numpy
                array, or sequence of 3 floats (interpreted as XYZ
                meters).
            azimuth_deg: Initial bearing from local north, clockwise.
                Range conventionally [0, 360).
            speed_mps: Total speed magnitude (m/s). Must be positive.
            elevation_deg: Flight-path angle above local horizon, in
                degrees. 0 = level flight (constant altitude). Positive
                = climbing, negative = descending. Range (-90, 90).
            epoch_unix_s: Unix time (seconds) that `dt=0` corresponds to.
                Only used when callers convert absolute times to `dt`.

        Raises:
            TypeError: If start_pos type is not supported.
            ValueError: If speed_mps <= 0 or |elevation_deg| >= 90.
        """
        if speed_mps <= 0:
            raise ValueError(
                f"speed_mps must be positive, got {speed_mps}",
            )
        if abs(elevation_deg) >= 90.0:  # noqa: PLR2004
            raise ValueError(
                f"elevation_deg must be in (-90, 90), got {elevation_deg}",
            )

        if isinstance(start_pos, Pos):
            start_xyz = np.asarray(start_pos.xyz, dtype=np.float64)
        elif isinstance(start_pos, (LLA, XYZ)):
            start_xyz = np.asarray(Pos(start_pos).xyz, dtype=np.float64)
        elif isinstance(start_pos, np.ndarray):
            start_xyz = np.asarray(start_pos, dtype=np.float64)
        elif hasattr(start_pos, "__len__") and len(start_pos) == 3:  # type: ignore[arg-type]  # noqa: PLR2004
            start_xyz = np.array(start_pos, dtype=np.float64)
        else:
            raise TypeError(
                f"Unsupported start_pos type: {type(start_pos).__name__}. "
                "Expected Pos, LLA, XYZ, numpy array, or sequence of 3 floats.",
            )

        self._azimuth_deg = float(azimuth_deg)
        self._elevation_deg = float(elevation_deg)
        self._speed_mps = float(speed_mps)
        self._epoch_unix_s = float(epoch_unix_s)

        # Geometry at the start position.
        r0 = float(np.linalg.norm(start_xyz))
        r_hat = start_xyz / r0

        # Decompose total speed into horizontal and vertical components
        # analytically. Computing these from sin/cos of elevation_deg
        # avoids float roundoff in the vector-projection path, which
        # would leak a ~1e-17 v_z into the el=0 case and break the closed
        # form for theta(t).
        el_rad = np.radians(elevation_deg)
        h_speed = float(speed_mps * np.cos(el_rad))  # tangent to surface
        v_z = float(speed_mps * np.sin(el_rad))  # along r_hat

        # Initial ECEF velocity vector via aer_to_xyz; aer_to_xyz returns
        # the ECEF vector of magnitude `range` pointing in the AER
        # direction at start_xyz's local ENU frame.
        v_init = np.asarray(
            aer_to_xyz(start_xyz, [azimuth_deg, elevation_deg, speed_mps]),
            dtype=np.float64,
        )

        # Horizontal direction unit vector u_hat: project v_init into the
        # local horizon plane (perpendicular to r_hat) and normalize.
        v_horizontal = v_init - float(np.dot(v_init, r_hat)) * r_hat
        h_norm = float(np.linalg.norm(v_horizontal))
        if h_norm <= 0.0:
            # Pure radial motion (el = +/-90): caller already guarded.
            raise ValueError(
                "Initial horizontal speed is zero; great circle undefined.",
            )
        u_hat = v_horizontal / h_norm
        n_hat = np.cross(r_hat, u_hat)

        self._r0 = r0
        self._r_hat = r_hat
        self._u_hat = u_hat
        self._n_hat = n_hat
        self._h_speed = h_speed
        self._v_z = v_z

    @property
    def azimuth_deg(self) -> float:
        """Initial azimuth from local north (clockwise, degrees)."""
        return self._azimuth_deg

    @property
    def elevation_deg(self) -> float:
        """Flight-path angle above local horizon (degrees)."""
        return self._elevation_deg

    @property
    def speed_mps(self) -> float:
        """Total speed magnitude (m/s)."""
        return self._speed_mps

    @property
    def epoch_unix_s(self) -> float:
        """Unix time (seconds) that `dt=0` corresponds to."""
        return self._epoch_unix_s

    def _theta_and_radius(self, dt: float) -> tuple[float, float]:
        """Angle traveled along the great circle and current radius."""
        r = self._r0 + self._v_z * dt
        if self._v_z == 0.0:
            theta = self._h_speed * dt / self._r0
        else:
            theta = (self._h_speed / self._v_z) * np.log(
                1.0 + self._v_z * dt / self._r0,
            )
        return float(theta), float(r)

    def _state_arrays(
        self,
        dt: float,
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """Return (pos_xyz, vel_xyz) ECEF arrays at `dt`."""
        theta, r = self._theta_and_radius(dt)
        pos_unit = np.cos(theta) * self._r_hat + np.sin(theta) * self._u_hat
        tangent_unit = -np.sin(theta) * self._r_hat + np.cos(theta) * self._u_hat
        pos_xyz = np.asarray(r * pos_unit, dtype=np.float64)
        # Total velocity = horizontal (tangent) + vertical (radial).
        vel_xyz = np.asarray(
            self._h_speed * tangent_unit + self._v_z * pos_unit,
            dtype=np.float64,
        )
        return pos_xyz, vel_xyz

    def position_at(self, dt: float = 0.0) -> Pos:
        """Get platform position at `dt` seconds from the trajectory epoch."""
        pos_xyz, _ = self._state_arrays(dt)
        return Pos.XYZ(pos_xyz)

    def velocity_at(self, dt: float = 0.0) -> NDArray[np.floating]:
        """Get platform ECEF velocity at `dt` seconds from the trajectory epoch.

        Magnitude equals speed_mps at every `dt`.
        """
        _, vel_xyz = self._state_arrays(dt)
        return vel_xyz

    def state_at(self, dt: float = 0.0) -> Vel:
        """Get the state at `dt` seconds from the trajectory epoch."""
        pos_xyz, vel_xyz = self._state_arrays(dt)
        return Vel.XYZ(
            pos_xyz[0],
            pos_xyz[1],
            pos_xyz[2],
            vel_xyz[0],
            vel_xyz[1],
            vel_xyz[2],
        )

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"GreatCircleTrajectory(az={self._azimuth_deg:.1f} deg, "
            f"el={self._elevation_deg:.1f} deg, "
            f"speed={self._speed_mps:.1f} m/s)"
        )
