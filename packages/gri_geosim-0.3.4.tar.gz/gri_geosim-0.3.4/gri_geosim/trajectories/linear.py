"""Linear (constant-velocity) trajectory.

A LinearTrajectory represents a platform moving with constant ECEF velocity.
Given an initial Vel (position + velocity), the state at any offset `dt` is
just the initial position advanced by `v * dt`, with velocity unchanged.

This is suitable for airplanes, ships, ground vehicles, or any platform whose
motion is well-approximated as constant-velocity over short timescales. No
orbital mechanics, no ECI round-trip: everything stays in ECEF.

For a snapshot, construct from the initial Vel and call `state_at()` with
the default `dt=0.0`.

Example:
    >>> from gri_pos import Vel
    >>> # An aircraft at 5 km altitude, heading east at 250 m/s
    >>> initial = Vel.LLA(37.5, -100.0, 5000.0, 250.0, 0.0, 0.0)
    >>> traj = LinearTrajectory(initial)
    >>> state = traj.state_at()         # snapshot
    >>> later = traj.state_at(60.0)     # 60 s later
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_pos import Pos, Vel
from gri_pos.points import XYZ as TP_XYZ

if TYPE_CHECKING:
    from numpy.typing import NDArray


class LinearTrajectory:
    """Trajectory for a platform moving at constant ECEF velocity.

    Position advances linearly in time: `pos(dt) = pos0 + v * dt`, with
    velocity held constant. Pure ECEF, no orbital machinery.

    Attributes:
        initial_state: The Vel at `dt=0`.
    """

    __slots__ = ("_epoch_unix_s", "_initial_state", "_pos0_xyz", "_vel_xyz_np")

    def __init__(
        self,
        state: Vel,
        *,
        epoch_unix_s: float = 0.0,
    ) -> None:
        """Initialize a linear trajectory from an initial state.

        Args:
            state: Initial Vel (position + ECEF velocity) at `dt=0`.
            epoch_unix_s: Unix time (seconds) that `dt=0` corresponds to.
                Optional; only used when callers convert absolute times to
                `dt`. Defaults to 0.0.
        """
        if not isinstance(state, Vel):
            raise TypeError(
                f"LinearTrajectory requires a Vel, got {type(state).__name__}",
            )

        self._initial_state = state
        self._pos0_xyz = np.asarray(state.xyz, dtype=np.float64)
        self._vel_xyz_np = np.asarray(state.vel_xyz, dtype=np.float64)
        self._epoch_unix_s = float(epoch_unix_s)

    @property
    def initial_state(self) -> Vel:
        """The Vel at `dt=0`."""
        return self._initial_state

    @property
    def epoch_unix_s(self) -> float:
        """Unix time (seconds) that `dt=0` corresponds to."""
        return self._epoch_unix_s

    def state_at(self, dt: float = 0.0) -> Vel:
        """Get the state at `dt` seconds from the trajectory epoch.

        Args:
            dt: Seconds from `epoch_unix_s`. Defaults to 0.0.

        Returns:
            Vel in the ECEF frame with position advanced by `v * dt`.
        """
        if dt == 0.0:
            return self._initial_state
        pos_xyz = self._pos0_xyz + self._vel_xyz_np * float(dt)
        return Vel((TP_XYZ(pos_xyz), TP_XYZ(self._vel_xyz_np.copy())))

    def position_at(self, dt: float = 0.0) -> Pos:
        """Get platform position at `dt` seconds from the trajectory epoch."""
        return self.state_at(dt)

    def velocity_at(self, dt: float = 0.0) -> NDArray[np.floating]:  # noqa: ARG002
        """Get platform ECEF velocity (constant regardless of `dt`)."""
        return self._vel_xyz_np

    def __repr__(self) -> str:
        """Return string representation."""
        speed = float(np.linalg.norm(self._vel_xyz_np))
        return f"LinearTrajectory(speed={speed:.3f} m/s)"
