# GeoSim/Trajectories

Motion models for platforms and emitters.

A trajectory defines how an entity moves through space over time. All trajectories implement a common protocol providing position, velocity, and combined state queries at any time instant.

## Import and Use

```python
from gri_geosim.trajectories import (
    StationaryTrajectory,
    Sgp4Trajectory,
    KeplerianTrajectory,
    WaypointTrajectory,
)
```

For stationary entities, `Platform` and `Emitter` accept a `Pos` directly and wrap it in a `StationaryTrajectory` internally:

```python
from gri_geosim import Platform, Emitter
from gri_pos import Pos

# These are equivalent:
platform = Platform(Pos.LLA(38.0, -77.0, 100.0), name="GND")
platform = Platform(StationaryTrajectory(Pos.LLA(38.0, -77.0, 100.0)), name="GND")
```

## Module Overview

| Trajectory | Description |
|------------|-------------|
| `StationaryTrajectory` | Fixed position, zero velocity |
| `Sgp4Trajectory` | SGP4/SDP4 TLE propagation (python-sgp4 backend) |
| `KeplerianTrajectory` | Two-body Keplerian orbit mechanics (gri-utils backend) |
| `WaypointTrajectory` | Interpolated path through waypoints (linear or cubic splines) |

## Trajectory Protocol

All trajectories implement these methods:

```python
def position_at(time: Time) -> Pos
def velocity_at(time: Time) -> NDArray[np.floating]   # shape (3,), ECEF m/s
def state_at(time: Time) -> tuple[Pos, NDArray[np.floating]]
```

`state_at()` returns both position and velocity in a single call, which can be more efficient than separate calls for some trajectory types.

## StationaryTrajectory

Fixed position with zero velocity. Used for ground stations, fixed emitters, and other stationary entities.

```python
from gri_geosim.trajectories import StationaryTrajectory
from gri_pos import Pos

traj = StationaryTrajectory(Pos.LLA(38.0, -77.0, 100.0))
pos = traj.position_at(time)    # always returns same Pos
vel = traj.velocity_at(time)    # always returns [0, 0, 0]
```

The constructor accepts any input that `Pos` can handle: a `Pos` object, LLA tuple, XYZ array, or sequence of floats.

## Sgp4Trajectory

Propagates a satellite orbit from Two-Line Element (TLE) data using the SGP4/SDP4 algorithm via the python-sgp4 library.

```python
from gri_geosim.trajectories import Sgp4Trajectory

tle_line1 = "1 25544U 98067A   24015.50000000  .00016717  00000-0  10270-3 0  9005"
tle_line2 = "2 25544  51.6400 200.0000 0007000  90.0000 270.0000 15.49000000000000"

traj = Sgp4Trajectory(tle_line1, tle_line2)
pos = traj.position_at(time)
vel = traj.velocity_at(time)
```

**Properties:**

- `satrec` -- Underlying python-sgp4 `Satrec` object
- `line1`, `line2` -- Original TLE lines
- `satellite_number` -- NORAD catalog number

SGP4 propagation converts the result from TEME to ECEF coordinates automatically. Raises `RuntimeError` if propagation fails (e.g., decayed orbit or time far from epoch).

## KeplerianTrajectory

Two-body Keplerian orbit propagation using analytical mean-to-true anomaly conversion via gri-utils.

```python
from gri_geosim.trajectories import KeplerianTrajectory
from gri_nsepoch import Time

traj = KeplerianTrajectory(
    semi_major_axis_m=7000e3,       # 7000 km
    eccentricity=0.001,             # near-circular
    inclination_rad=0.9,            # ~51.6 degrees
    raan_rad=3.5,                   # right ascension of ascending node
    arg_periapsis_rad=1.5,          # argument of periapsis
    mean_anomaly_rad=0.0,           # at epoch
    epoch=Time.from_str("2024-01-15T12:00:00Z"),
)
```

**Factory methods:**

```python
# From an OrbitalElements dataclass (gri-utils)
traj = KeplerianTrajectory.from_elements(elements, epoch)

# From TLE (extracts Keplerian elements, ignores perturbation terms)
traj = KeplerianTrajectory.from_tle(line1, line2)
```

Only elliptical orbits are supported (eccentricity in [0, 1)).

## WaypointTrajectory

Interpolated path through a sequence of time-tagged positions. Supports linear and cubic spline interpolation in ECEF coordinates.

```python
from gri_geosim.trajectories import WaypointTrajectory
from gri_pos import Pos
from gri_nsepoch import Time, Delta

t0 = Time.from_str("2024-01-15T12:00:00Z")
waypoints = [
    (t0, Pos.LLA(38.0, -77.0, 5000.0)),
    (t0 + Delta.from_s(300), Pos.LLA(38.5, -76.5, 5000.0)),
    (t0 + Delta.from_s(600), Pos.LLA(39.0, -76.0, 5000.0)),
]

traj = WaypointTrajectory(waypoints, interpolation="cubic")
pos = traj.position_at(t0 + Delta.from_s(150))   # interpolated position
```

**Constructor parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `waypoints` | `Sequence[tuple[Time, Pos]]` | required | At least 2 time-tagged positions, strictly increasing in time |
| `interpolation` | `"linear" \| "cubic"` | `"linear"` | Interpolation method |

**Properties:**

- `interpolation` -- Interpolation method name
- `start_time_unix`, `end_time_unix` -- Time range covered
- `num_waypoints` -- Number of waypoints

Times outside the waypoint range are extrapolated.

## Notes

- All positions are in ECEF (XYZ) coordinates in meters.
- All velocities are in ECEF frame, meters per second, shape (3,).
- `Sgp4Trajectory` handles TEME-to-ECEF conversion internally.
- `KeplerianTrajectory` is a two-body approximation (no J2, drag, or third-body effects). For high-fidelity propagation, use `Sgp4Trajectory` with real TLE data.
- For stationary entities, prefer passing `Pos` directly to `Platform` or `Emitter` rather than explicitly wrapping in `StationaryTrajectory`.
