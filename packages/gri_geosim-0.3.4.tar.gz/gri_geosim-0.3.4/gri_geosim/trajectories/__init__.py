"""Trajectory classes for platform motion.

This module provides trajectory implementations for different platform motion
models. All trajectories implement the Trajectory protocol.

Available trajectories:
- StationaryTrajectory: Fixed position, zero velocity
- LinearTrajectory: Constant ECEF velocity from an initial Vel
- GreatCircleTrajectory: Great-circle motion fixed in ECEF (aircraft, vehicles)
- CircularOrbitTrajectory: Circular orbit fixed in ECI (satellite approximation)
- KeplerianTrajectory: Two-body orbital mechanics (gri-utils)
- Sgp4Trajectory: SGP4/SDP4 TLE propagation (python-sgp4)
- WaypointTrajectory: Interpolated path through waypoints
- HermiteTrajectory: Hermite spline interpolation through state vectors

Example:
    >>> from gri_geosim.trajectories import StationaryTrajectory
    >>> from gri_pos import Pos
    >>> traj = StationaryTrajectory(Pos.LLA(38.0, -77.0, 100.0))
"""

from .circular_orbit import CircularOrbitTrajectory
from .great_circle import GreatCircleTrajectory
from .hermite import HermiteTrajectory
from .keplerian import KeplerianTrajectory
from .linear import LinearTrajectory
from .sgp4 import Sgp4Trajectory
from .stationary import StationaryTrajectory
from .trajectory import Trajectory
from .waypoint import WaypointTrajectory

__all__ = [
    "CircularOrbitTrajectory",
    "GreatCircleTrajectory",
    "HermiteTrajectory",
    "KeplerianTrajectory",
    "LinearTrajectory",
    "Sgp4Trajectory",
    "StationaryTrajectory",
    "Trajectory",
    "WaypointTrajectory",
]
