"""Circular orbit trajectory fixed in the ECI frame.

A CircularOrbitTrajectory represents a satellite in a uniform circular
orbit. The orbit plane is fixed in ECI (inertial), so the Earth rotates
beneath the satellite, producing the recognizable sinusoidal ground track
of an inclined orbit.

This is a simple closed-form approximation, intended as an alternative
to TLEs / Keplerian elements when an exact-circular orbit is wanted.
The orbit is purely two-body (no J2, no drag, no perturbations); for
higher-fidelity propagation, use Sgp4Trajectory or KeplerianTrajectory.

Use cases: easy-to-author satellite scenarios where the user knows the
altitude, orbit plane orientation (via start_pos and azimuth_deg), and
speed. Speed and altitude must be self-consistent (e.g., for a circular
orbit at altitude h, v = sqrt(mu / r) with r = earth_radius + h); the
trajectory will faithfully reproduce whatever speed is supplied without
checking that it produces a closed orbit.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_pos import LLA, XYZ, Pos, Vel
from gri_utils.conversion import (
    aer_to_xyz,
    ecef_to_eci,
    ecef_to_eci_vel,
    eci_to_ecef,
    eci_to_ecef_vel,
)

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


class CircularOrbitTrajectory:
    """Trajectory for a uniform circular orbit fixed in ECI.

    The orbit plane is determined by the start position and the initial
    azimuth (in the local ENU frame at start_pos), evaluated at the
    epoch. After construction, motion proceeds in ECI at constant
    angular rate omega = speed / r0, where r0 is the ECEF magnitude of
    the start position.

    Attributes:
        azimuth_deg: Initial bearing from local north (clockwise).
        speed_mps: Constant orbital speed (m/s).

    Example:
        >>> from gri_pos import Pos
        >>> # Eastbound circular orbit at 500 km, equatorial start
        >>> traj = CircularOrbitTrajectory(
        ...     Pos.LLA(0.0, 0.0, 500_000.0),
        ...     azimuth_deg=90.0,
        ...     speed_mps=7616.5,
        ... )
    """

    __slots__ = (
        "_azimuth_deg",
        "_epoch_unix_s",
        "_omega",
        "_r0",
        "_r_hat_eci",
        "_speed_mps",
        "_u_hat_eci",
    )

    def __init__(
        self,
        start_pos: Pos | LLA | XYZ | np.ndarray | Sequence[float],
        azimuth_deg: float,
        speed_mps: float,
        *,
        epoch_unix_s: float = 0.0,
    ) -> None:
        """Initialize a circular-orbit trajectory.

        Args:
            start_pos: Position at `dt=0` (ECEF). Accepts Pos, LLA, XYZ,
                numpy array, or sequence of 3 floats (interpreted as XYZ
                meters). The radial distance ||start_pos|| sets the orbit
                radius.
            azimuth_deg: Initial bearing from local north (clockwise),
                evaluated in the ENU frame at start_pos at the epoch.
                Together with start_pos, fixes the orbit plane.
            speed_mps: Constant orbital speed (m/s). Must be positive.
            epoch_unix_s: Unix time (seconds) that `dt=0` corresponds to.
                Required for the ECEF<->ECI transport: this trajectory
                must know the absolute time when start_pos was sampled
                so it can rotate that ECEF state into ECI consistently.

        Raises:
            TypeError: If start_pos type is not supported.
            ValueError: If speed_mps <= 0.
        """
        if speed_mps <= 0:
            raise ValueError(
                f"speed_mps must be positive, got {speed_mps}",
            )

        if isinstance(start_pos, Pos):
            start_xyz_ecef = np.asarray(start_pos.xyz, dtype=np.float64)
        elif isinstance(start_pos, (LLA, XYZ)):
            start_xyz_ecef = np.asarray(Pos(start_pos).xyz, dtype=np.float64)
        elif isinstance(start_pos, np.ndarray):
            start_xyz_ecef = np.asarray(start_pos, dtype=np.float64)
        elif hasattr(start_pos, "__len__") and len(start_pos) == 3:  # type: ignore[arg-type]  # noqa: PLR2004
            start_xyz_ecef = np.array(start_pos, dtype=np.float64)
        else:
            raise TypeError(
                f"Unsupported start_pos type: {type(start_pos).__name__}. "
                "Expected Pos, LLA, XYZ, numpy array, or sequence of 3 floats.",
            )

        self._azimuth_deg = float(azimuth_deg)
        self._speed_mps = float(speed_mps)
        self._epoch_unix_s = float(epoch_unix_s)

        # Build the orbit plane in ECI at the epoch. The orbit is
        # circular, so elevation_deg = 0 (purely tangential motion).
        # First compute the ECEF velocity unit vector at the epoch via
        # the local ENU frame, then transform position and velocity
        # into ECI.
        v_init_ecef = np.asarray(
            aer_to_xyz(start_xyz_ecef, [azimuth_deg, 0.0, speed_mps]),
            dtype=np.float64,
        )

        start_xyz_eci = np.asarray(
            ecef_to_eci(start_xyz_ecef, self._epoch_unix_s),
            dtype=np.float64,
        )
        # Transport velocity from rotating frame to inertial frame:
        # v_eci = R(gmst) @ v_ecef + omega x r_eci. Use ecef_to_eci_vel.
        v_init_eci = np.asarray(
            ecef_to_eci_vel(start_xyz_ecef, v_init_ecef, self._epoch_unix_s),
            dtype=np.float64,
        )

        r0 = float(np.linalg.norm(start_xyz_eci))
        r_hat_eci = start_xyz_eci / r0

        # In ECI, the orbital motion is purely tangential. Project out
        # the radial component (transport velocity may have introduced a
        # tiny radial term from float roundoff; keep only the tangent).
        v_radial_eci = float(np.dot(v_init_eci, r_hat_eci)) * r_hat_eci
        v_tangent_eci = v_init_eci - v_radial_eci
        v_tangent_speed = float(np.linalg.norm(v_tangent_eci))
        if v_tangent_speed <= 0.0:
            raise ValueError(
                "Initial tangential speed is zero; orbit undefined.",
            )
        u_hat_eci = v_tangent_eci / v_tangent_speed

        # Angular rate from the *requested* speed at radius r0.
        # We use speed_mps directly so the orbit period matches what the
        # user asked for, regardless of the small ECEF<->ECI transport
        # adjustment.
        omega = speed_mps / r0

        self._r0 = r0
        self._r_hat_eci = r_hat_eci
        self._u_hat_eci = u_hat_eci
        self._omega = omega

    @property
    def azimuth_deg(self) -> float:
        """Initial azimuth from local north at start_pos (degrees)."""
        return self._azimuth_deg

    @property
    def speed_mps(self) -> float:
        """Constant orbital speed (m/s)."""
        return self._speed_mps

    @property
    def epoch_unix_s(self) -> float:
        """Unix time (seconds) that `dt=0` corresponds to."""
        return self._epoch_unix_s

    def _state_at_eci(
        self,
        dt: float,
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """Compute ECI position and velocity at offset `dt` from epoch."""
        theta = self._omega * dt
        cos_t, sin_t = float(np.cos(theta)), float(np.sin(theta))
        pos_eci = self._r0 * (cos_t * self._r_hat_eci + sin_t * self._u_hat_eci)
        vel_eci = self._speed_mps * (-sin_t * self._r_hat_eci + cos_t * self._u_hat_eci)
        return pos_eci, vel_eci

    def _state_arrays(
        self,
        dt: float,
    ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
        """ECEF (pos, vel) at offset `dt` from epoch."""
        pos_eci, vel_eci = self._state_at_eci(dt)
        unix_s = self._epoch_unix_s + dt
        pos_ecef = np.asarray(eci_to_ecef(pos_eci, unix_s), dtype=np.float64)
        vel_ecef = np.asarray(
            eci_to_ecef_vel(pos_eci, vel_eci, unix_s),
            dtype=np.float64,
        )
        return pos_ecef, vel_ecef

    def position_at(self, dt: float = 0.0) -> Pos:
        """Get satellite position at `dt` seconds from the trajectory epoch."""
        pos_ecef, _ = self._state_arrays(dt)
        return Pos.XYZ(pos_ecef)

    def velocity_at(self, dt: float = 0.0) -> NDArray[np.floating]:
        """Get satellite ECEF velocity at `dt` seconds from the trajectory epoch."""
        _, vel_ecef = self._state_arrays(dt)
        return vel_ecef

    def state_at(self, dt: float = 0.0) -> Vel:
        """Get the state at `dt` seconds from the trajectory epoch."""
        pos_ecef, vel_ecef = self._state_arrays(dt)
        return Vel.XYZ(
            pos_ecef[0],
            pos_ecef[1],
            pos_ecef[2],
            vel_ecef[0],
            vel_ecef[1],
            vel_ecef[2],
        )

    def __repr__(self) -> str:
        """Return string representation."""
        period_min = (2.0 * np.pi / self._omega) / 60.0
        return (
            f"CircularOrbitTrajectory(az={self._azimuth_deg:.1f} deg, "
            f"speed={self._speed_mps:.1f} m/s, "
            f"period={period_min:.1f} min)"
        )
