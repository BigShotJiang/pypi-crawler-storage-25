"""Waypoint trajectory for interpolated paths through known positions.

A WaypointTrajectory represents a platform following a path defined by
waypoints (dt, position) pairs. The position at any `dt` is interpolated
from the waypoints using linear or cubic spline interpolation.

This is useful for aircraft, ships, ground vehicles, or any platform with
a known or planned route.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Literal

import numpy as np
from gri_pos import LLA, XYZ, Pos, Vel
from scipy.interpolate import CubicSpline, interp1d

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


class WaypointTrajectory:
    """Trajectory interpolated from waypoints.

    Defines a path through a series of (dt, position) waypoints, where `dt`
    is in seconds relative to `epoch_unix_s`. The position at any query time
    is interpolated from the waypoints.

    Supports two interpolation methods:
    - "linear": Linear interpolation between waypoints
    - "cubic": Cubic spline interpolation (smoother, but may overshoot)

    For `dt` outside the waypoint range, extrapolation is used (which may
    produce unrealistic results for large extrapolations).

    Attributes:
        waypoints: List of (dt, position) tuples defining the path.
        interpolation: Interpolation method used ("linear" or "cubic").

    Example:
        >>> from gri_pos import Pos
        >>> waypoints = [
        ...     (0.0, Pos.LLA(38.0, -77.0, 1000.0)),
        ...     (3600.0, Pos.LLA(39.0, -76.0, 1000.0)),
        ... ]
        >>> traj = WaypointTrajectory(waypoints)
        >>> state = traj.state_at(1800.0)  # Halfway
    """

    __slots__ = (
        "_epoch_unix_s",
        "_interp_x",
        "_interp_y",
        "_interp_z",
        "_interpolation",
        "_positions_xyz",
        "_times_dt",
    )

    def __init__(
        self,
        waypoints: Sequence[
            tuple[float, Pos | LLA | XYZ | np.ndarray | Sequence[float]]
        ],
        *,
        interpolation: Literal["linear", "cubic"] = "linear",
        epoch_unix_s: float = 0.0,
    ) -> None:
        """Initialize a waypoint trajectory.

        Args:
            waypoints: List of (dt_s, position) tuples. `dt_s` is seconds
                relative to `epoch_unix_s`. Each position can be:
                - Pos object
                - LLA object (lat/lon/alt in degrees/meters)
                - XYZ object (ECEF meters)
                - numpy array (interpreted as XYZ meters)
                - Sequence of 3 floats (interpreted as XYZ meters)
            interpolation: Interpolation method. "linear" (default) or
                "cubic".
            epoch_unix_s: Unix time (seconds) that `dt=0` corresponds to.
                Only used when callers convert absolute times to `dt`.

        Raises:
            ValueError: If fewer than 2 waypoints provided.
            ValueError: If waypoint times are not strictly increasing.
            ValueError: If interpolation method is unknown.
        """
        if len(waypoints) < 2:  # noqa: PLR2004
            raise ValueError(
                f"At least 2 waypoints required, got {len(waypoints)}",
            )

        if interpolation not in ("linear", "cubic"):
            raise ValueError(
                f"Unknown interpolation method: {interpolation}. "
                "Expected 'linear' or 'cubic'.",
            )

        self._interpolation = interpolation
        self._epoch_unix_s = float(epoch_unix_s)

        times_dt: list[float] = []
        positions_xyz = []

        for dt_s, position in waypoints:
            times_dt.append(float(dt_s))

            if isinstance(position, Pos):
                xyz = position.xyz
            elif isinstance(position, (LLA, XYZ)):
                xyz = Pos(position).xyz
            elif isinstance(position, np.ndarray):
                xyz = np.asarray(position, dtype=np.float64)
            elif hasattr(position, "__len__") and len(position) == 3:  # noqa: PLR2004
                xyz = np.array(position, dtype=np.float64)
            else:
                raise TypeError(
                    f"Unsupported position type: {type(position).__name__}. "
                    "Expected Pos, LLA, XYZ, numpy array, or sequence of 3 floats.",
                )

            positions_xyz.append(xyz)

        self._times_dt = np.array(times_dt, dtype=np.float64)
        if not np.all(np.diff(self._times_dt) > 0):
            raise ValueError("Waypoint times must be strictly increasing")

        self._positions_xyz = np.array(positions_xyz, dtype=np.float64)

        if interpolation == "linear":
            self._interp_x = interp1d(
                self._times_dt,
                self._positions_xyz[:, 0],
                kind="linear",
                fill_value="extrapolate",
            )
            self._interp_y = interp1d(
                self._times_dt,
                self._positions_xyz[:, 1],
                kind="linear",
                fill_value="extrapolate",
            )
            self._interp_z = interp1d(
                self._times_dt,
                self._positions_xyz[:, 2],
                kind="linear",
                fill_value="extrapolate",
            )
        else:  # cubic
            self._interp_x = CubicSpline(
                self._times_dt,
                self._positions_xyz[:, 0],
                extrapolate=True,
            )
            self._interp_y = CubicSpline(
                self._times_dt,
                self._positions_xyz[:, 1],
                extrapolate=True,
            )
            self._interp_z = CubicSpline(
                self._times_dt,
                self._positions_xyz[:, 2],
                extrapolate=True,
            )

    @property
    def interpolation(self) -> str:
        """Interpolation method used."""
        return self._interpolation

    @property
    def epoch_unix_s(self) -> float:
        """Unix time (seconds) that `dt=0` corresponds to."""
        return self._epoch_unix_s

    @property
    def start_dt(self) -> float:
        """`dt` of the first waypoint."""
        return float(self._times_dt[0])

    @property
    def end_dt(self) -> float:
        """`dt` of the last waypoint."""
        return float(self._times_dt[-1])

    @property
    def num_waypoints(self) -> int:
        """Number of waypoints."""
        return len(self._times_dt)

    def position_at(self, dt: float = 0.0) -> Pos:
        """Get platform position at `dt` seconds from the trajectory epoch."""
        x = float(self._interp_x(dt))
        y = float(self._interp_y(dt))
        z = float(self._interp_z(dt))
        return Pos.XYZ(np.array([x, y, z]))

    def velocity_at(self, dt: float = 0.0) -> NDArray[np.floating]:
        """Get platform ECEF velocity at `dt` seconds from the trajectory epoch.

        For cubic interpolation, velocity is the spline derivative.

        For linear interpolation, returns the analytic segment slope
        ``(p[i+1] - p[i]) / (t[i+1] - t[i])`` for the segment containing
        ``dt``. Outside the waypoint range, the first or last segment slope
        is used (matches scipy ``interp1d``'s extrapolation).
        """
        if self._interpolation == "cubic":
            vx = float(self._interp_x(dt, 1))  # ty: ignore[too-many-positional-arguments]
            vy = float(self._interp_y(dt, 1))  # ty: ignore[too-many-positional-arguments]
            vz = float(self._interp_z(dt, 1))  # ty: ignore[too-many-positional-arguments]
            return np.array([vx, vy, vz], dtype=np.float64)

        # Linear: analytic segment slope. searchsorted picks the segment
        # whose right endpoint is the first time >= dt; clamp to a valid
        # segment index for both extrapolation cases.
        n_seg = len(self._times_dt) - 1
        idx = int(np.searchsorted(self._times_dt, dt, side="right")) - 1
        idx = max(0, min(idx, n_seg - 1))
        seg_dt = self._times_dt[idx + 1] - self._times_dt[idx]
        slope = (self._positions_xyz[idx + 1] - self._positions_xyz[idx]) / seg_dt
        return np.asarray(slope, dtype=np.float64)

    def state_at(self, dt: float = 0.0) -> Vel:
        """Get the state at `dt` seconds from the trajectory epoch."""
        pos = self.position_at(dt)
        vel = self.velocity_at(dt)
        return Vel.XYZ(
            pos.xyz[0],
            pos.xyz[1],
            pos.xyz[2],
            vel[0],
            vel[1],
            vel[2],
        )

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"WaypointTrajectory({self.num_waypoints} waypoints, "
            f"interpolation='{self._interpolation}')"
        )
