"""Emitter class for target entities in geolocation simulations.

An Emitter represents a target being observed by sensors. Emitters can be
stationary (fixed ground position) or moving (following a trajectory).
They emit signals at a specified frequency that sensors can detect and
measure.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from gri_pos import Pos, Vel

from .trajectories import StationaryTrajectory, Trajectory

if TYPE_CHECKING:
    import numpy as np
    from gri_nsepoch import Time
    from numpy.typing import NDArray


class Emitter:
    """Target being observed by sensors.

    An Emitter represents a signal source that platforms are trying to
    geolocate. Emitters can be stationary (fixed position) or moving
    (following a trajectory).

    The first argument can be a Trajectory or a Pos. If a Pos is given,
    a StationaryTrajectory is created automatically.

    Attributes:
        name: Human-readable identifier for the emitter.
        frequency_hz: Signal frequency in Hz (used for Doppler/FDOA).
        trajectory: The trajectory defining emitter motion.

    Example:
        >>> from gri_pos import Pos
        >>> from gri_nsepoch import Time
        >>>
        >>> # Stationary emitter (Pos creates StationaryTrajectory)
        >>> target = Emitter(Pos.LLA(39.0, -76.5, 0.0), name="Target_1")
        >>>
        >>> # Get position at a specific time
        >>> pos = target.position_at(Time())
    """

    __slots__ = ("_frequency_hz", "_name", "_trajectory")

    def __init__(
        self,
        trajectory: Trajectory | Pos,
        *,
        frequency_hz: float = 1e9,
        name: str = "",
    ) -> None:
        """Initialize an Emitter.

        Args:
            trajectory: Trajectory defining the emitter's motion over time,
                or a Pos for a stationary emitter.
            frequency_hz: Signal frequency in Hz. Used for Doppler/FDOA
                calculations. Defaults to 1 GHz.
            name: Optional human-readable identifier.

        Raises:
            ValueError: If frequency_hz is not positive.
        """
        if frequency_hz <= 0:
            raise ValueError(f"frequency_hz must be positive, got {frequency_hz}")

        if isinstance(trajectory, Pos):
            trajectory = StationaryTrajectory(trajectory)
        self._trajectory = trajectory
        self._frequency_hz = frequency_hz
        self._name = name

    # =========================================================================
    # Properties
    # =========================================================================

    @property
    def name(self) -> str:
        """Human-readable identifier for this emitter."""
        return self._name

    @property
    def frequency_hz(self) -> float:
        """Signal frequency in Hz."""
        return self._frequency_hz

    @property
    def trajectory(self) -> Trajectory:
        """The trajectory defining this emitter's motion."""
        return self._trajectory

    # =========================================================================
    # Position and velocity queries
    # =========================================================================

    def _dt_for(self, time: Time) -> float:
        """Convert an absolute Time to the trajectory's relative dt (seconds)."""
        return float(time.secs) - float(self._trajectory.epoch_unix_s)

    def position_at(self, time: Time) -> Pos:
        """Get emitter position at a specific time.

        Args:
            time: Time instant for position query.

        Returns:
            Pos object with emitter position in ECEF frame.
        """
        return self._trajectory.position_at(self._dt_for(time))

    def velocity_at(self, time: Time) -> NDArray[np.floating]:
        """Get emitter velocity at a specific time.

        For stationary emitters, this always returns zero velocity.

        Args:
            time: Time instant for velocity query.

        Returns:
            Velocity vector [vx, vy, vz] in ECEF frame, meters per second.
        """
        return self._trajectory.velocity_at(self._dt_for(time))

    def state_at(self, time: Time) -> Vel:
        """Get the emitter state at a specific time.

        Args:
            time: Time instant for state query.

        Returns:
            Vel in the ECEF frame carrying both position and velocity.
        """
        return self._trajectory.state_at(self._dt_for(time))

    # =========================================================================
    # Dunder methods
    # =========================================================================

    def __repr__(self) -> str:
        """Return string representation."""
        name_str = f"'{self._name}'" if self._name else "unnamed"
        traj_type = type(self._trajectory).__name__
        freq_ghz = self._frequency_hz / 1e9
        return f"Emitter({name_str}, freq={freq_ghz:.3f}GHz, trajectory={traj_type})"

    def __str__(self) -> str:
        """Return human-readable string."""
        name_str = self._name or "Unnamed Emitter"
        traj_type = type(self._trajectory).__name__
        freq_ghz = self._frequency_hz / 1e9
        return f"{name_str} ({traj_type}, {freq_ghz:.3f} GHz)"
