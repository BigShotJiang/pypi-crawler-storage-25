"""Atmospheric delay corrections for signal propagation.

This module provides interfaces to tropospheric and ionospheric delay
models from gri-tropo and gri-iono. These corrections can be applied
to TDOA measurements to account for signal path delays through the
atmosphere.

Tropospheric delays:
    - Caused by water vapor and dry air in the lower atmosphere (0-50 km)
    - Affects all radio frequencies equally (non-dispersive)
    - Typically 2-25 meters of excess path length

Ionospheric delays:
    - Caused by free electrons in the upper atmosphere (60-1000 km)
    - Frequency-dependent (dispersive): delay proportional to 1/f**2
    - Typically 1-50 meters at L-band, varies with solar activity and time of day

Both corrections return (angular_correction_rad, time_delay_s) tuples.
The time_delay should be SUBTRACTED from measured arrival times.
"""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum, auto
from typing import TYPE_CHECKING, NamedTuple

import gri_iono
import numpy as np
from gri_tropo import dgs_tropo_corrections

if TYPE_CHECKING:
    from gri_nsepoch import Time
    from gri_pos import Pos


class IonoModel(Enum):
    """Available ionospheric delay models.

    BENT       Bent model - fast, uses date-derived solar flux
    IRI        IRI model - accurate, slower
    NEQUICK2   NeQuick2 - good balance of speed/accuracy
    NEQUICKG   NeQuickG - Galileo-specific, uses broadcast coefficients
    """

    BENT = auto()  # Bent model - fast, uses date-derived solar flux
    IRI = auto()  # IRI model - accurate, slower
    NEQUICK2 = auto()  # NeQuick2 - good balance of speed/accuracy
    NEQUICKG = auto()  # NeQuickG - Galileo-specific, uses broadcast coefficients


class AtmosphericCorrection(NamedTuple):
    """Container for atmospheric correction values.

    Attributes:
        tropo_delay_s: Tropospheric time delay in seconds.
        iono_delay_s: Ionospheric time delay in seconds.
        tropo_angle_rad: Tropospheric angular correction in radians.
        iono_angle_rad: Ionospheric angular correction in radians.

    Note:
        For total delay, use: correction.tropo_delay_s + correction.iono_delay_s
        For total path in meters, multiply total delay by speed of light (gri_utils.C).
    """

    tropo_delay_s: float
    iono_delay_s: float
    tropo_angle_rad: float
    iono_angle_rad: float


class AtmosphereConfig:
    """Configuration for atmospheric corrections.

    Attributes:
        enable_tropo: Whether to apply tropospheric corrections.
        enable_iono: Whether to apply ionospheric corrections.
        iono_model: Which ionospheric model to use.
        n_sur: Surface refractivity for troposphere (N-units). Default 315.0.
        ref_ht: Reference height for troposphere (km). Default 7.35 km.
        solar_flux: Solar flux index (F10.7 SFU) for IRI/NeQuick models.
        nequickg_coefficients: Broadcast coefficients (ai0, ai1, ai2) for NeQuickG.
    """

    __slots__ = (
        "enable_iono",
        "enable_tropo",
        "iono_model",
        "n_sur",
        "nequickg_coefficients",
        "ref_ht",
        "solar_flux",
    )

    def __init__(  # noqa: PLR0913
        self,
        *,
        enable_tropo: bool = True,
        enable_iono: bool = True,
        iono_model: IonoModel = IonoModel.BENT,
        n_sur: float = 315.0,
        ref_ht: float = 7.35,
        solar_flux: float = 150.0,
        nequickg_coefficients: tuple[float, float, float] | None = None,
    ) -> None:
        """Initialize atmosphere configuration.

        Args:
            enable_tropo: Whether to apply tropospheric corrections.
            enable_iono: Whether to apply ionospheric corrections.
            iono_model: Which ionospheric model to use.
            n_sur: Surface refractivity for troposphere (N-units).
            ref_ht: Reference height for troposphere (km).
            solar_flux: Solar flux index (F10.7 SFU) for IRI/NeQuick models.
            nequickg_coefficients: Broadcast coefficients (ai0, ai1, ai2) for NeQuickG.
        """
        self.enable_tropo = enable_tropo
        self.enable_iono = enable_iono
        self.iono_model = iono_model
        self.n_sur = n_sur
        self.ref_ht = ref_ht
        self.solar_flux = solar_flux
        self.nequickg_coefficients = nequickg_coefficients

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"AtmosphereConfig(enable_tropo={self.enable_tropo}, "
            f"enable_iono={self.enable_iono}, iono_model={self.iono_model!r})"
        )


def compute_tropo_correction(
    emitter_pos: Pos,
    collector_pos: Pos,
    *,
    n_sur: float = 315.0,
    ref_ht: float = 7.35,
) -> tuple[float, float]:
    """Compute tropospheric delay correction.

    Uses the ITU-R 2019 method (DGS) to compute tropospheric
    refraction effects on signal propagation.

    Args:
        emitter_pos: Position of the emitter (signal source).
        collector_pos: Position of the collector (receiver).
        n_sur: Surface refractivity in N-units. Default 315.0 (global mean).
        ref_ht: Reference height in km. Default 7.35 km (global mean).

    Returns:
        Tuple of (angular_correction_rad, time_delay_s).
        Time delay should be SUBTRACTED from measurements.
    """
    emitter_lla = np.array(
        [
            emitter_pos.lla.lat_deg,
            emitter_pos.lla.lon_deg,
            emitter_pos.lla.alt_m,
        ],
    )
    collector_xyz = collector_pos.xyz

    angle_rad, delay_s = dgs_tropo_corrections(
        emitter_lla,
        collector_xyz,
        n_sur=n_sur,
        ref_ht=ref_ht,
    )

    return float(angle_rad), float(delay_s)


def compute_iono_correction(  # noqa: PLR0913
    emitter_pos: Pos,
    collector_pos: Pos,
    frequency_hz: float,
    time: Time,
    *,
    model: IonoModel = IonoModel.BENT,
    solar_flux: float = 150.0,
    nequickg_coefficients: tuple[float, float, float] | None = None,
) -> tuple[float, float]:
    """Compute ionospheric delay correction.

    Uses one of several ionospheric models to compute the delay
    caused by free electrons in the ionosphere.

    Args:
        emitter_pos: Position of the emitter (signal source).
        collector_pos: Position of the collector (receiver).
        frequency_hz: Signal frequency in Hz.
        time: Observation time.
        model: Which ionospheric model to use.
        solar_flux: Solar flux index (F10.7 SFU) for IRI/NeQuick2 models.
        nequickg_coefficients: Broadcast coefficients for NeQuickG model.

    Returns:
        Tuple of (angular_correction_rad, time_delay_s).
        Time delay should be SUBTRACTED from measurements.

    Raises:
        ValueError: If NeQuickG model selected but no coefficients provided.
    """
    emitter_lla = [
        emitter_pos.lla.lat_deg,
        emitter_pos.lla.lon_deg,
        emitter_pos.lla.alt_m,
    ]
    collector_xyz = collector_pos.xyz

    # Convert Time to datetime
    time_dt = _time_to_datetime(time)

    if model == IonoModel.BENT:
        angle_rad, delay_s = gri_iono.bent_ionospheric_correction(
            emitter_lla,
            collector_xyz,
            frequency_hz,
            time_dt,
        )
    elif model == IonoModel.IRI:
        angle_rad, delay_s = gri_iono.iri_ionospheric_correction(
            emitter_lla,
            collector_xyz,
            frequency_hz,
            solar_flux,
            time_dt,
        )
    elif model == IonoModel.NEQUICK2:
        utc_hours = time_dt.hour + time_dt.minute / 60.0 + time_dt.second / 3600.0
        month = time_dt.month
        angle_rad, delay_s = gri_iono.nequick2_ionospheric_correction(
            emitter_lla,
            collector_xyz,
            frequency_hz,
            solar_flux,
            utc_hours,
            month,
        )
    elif model == IonoModel.NEQUICKG:
        if nequickg_coefficients is None:
            raise ValueError(
                "nequickg_coefficients required for NeQuickG model. "
                "Provide (ai0, ai1, ai2) tuple.",
            )
        utc_hours = time_dt.hour + time_dt.minute / 60.0 + time_dt.second / 3600.0
        month = time_dt.month
        angle_rad, delay_s = gri_iono.nequickg_ionospheric_correction(
            emitter_lla,
            collector_xyz,
            frequency_hz,
            nequickg_coefficients,
            utc_hours,
            month,
        )
    else:
        raise ValueError(f"Unknown ionospheric model: {model}")

    return float(angle_rad), float(delay_s)


def compute_atmospheric_correction(
    emitter_pos: Pos,
    collector_pos: Pos,
    frequency_hz: float,
    time: Time,
    config: AtmosphereConfig | None = None,
) -> AtmosphericCorrection:
    """Compute combined atmospheric correction.

    Computes both tropospheric and ionospheric delays based on
    the provided configuration.

    Args:
        emitter_pos: Position of the emitter (signal source).
        collector_pos: Position of the collector (receiver).
        frequency_hz: Signal frequency in Hz.
        time: Observation time.
        config: Atmosphere configuration. Uses defaults if None.

    Returns:
        AtmosphericCorrection containing all delay values.
    """
    if config is None:
        config = AtmosphereConfig()

    tropo_angle = 0.0
    tropo_delay = 0.0
    iono_angle = 0.0
    iono_delay = 0.0

    if config.enable_tropo:
        tropo_angle, tropo_delay = compute_tropo_correction(
            emitter_pos,
            collector_pos,
            n_sur=config.n_sur,
            ref_ht=config.ref_ht,
        )

    if config.enable_iono:
        iono_angle, iono_delay = compute_iono_correction(
            emitter_pos,
            collector_pos,
            frequency_hz,
            time,
            model=config.iono_model,
            solar_flux=config.solar_flux,
            nequickg_coefficients=config.nequickg_coefficients,
        )

    return AtmosphericCorrection(
        tropo_delay_s=tropo_delay,
        iono_delay_s=iono_delay,
        tropo_angle_rad=tropo_angle,
        iono_angle_rad=iono_angle,
    )


def compute_differential_atmospheric_delay(  # noqa: PLR0913
    emitter_pos: Pos,
    collector1_pos: Pos,
    collector2_pos: Pos,
    frequency_hz: float,
    time: Time,
    config: AtmosphereConfig | None = None,
) -> float:
    """Compute differential atmospheric delay for TDOA.

    For TDOA measurements, we need the DIFFERENCE in atmospheric
    delays between the two signal paths:
        differential_delay = delay_to_collector1 - delay_to_collector2

    This is added to the geometric TDOA to get the measured TDOA.

    Args:
        emitter_pos: Position of the emitter.
        collector1_pos: Position of first collector (TDOA reference).
        collector2_pos: Position of second collector.
        frequency_hz: Signal frequency in Hz.
        time: Observation time.
        config: Atmosphere configuration. Uses defaults if None.

    Returns:
        Differential time delay in seconds (path1 - path2).
    """
    corr1 = compute_atmospheric_correction(
        emitter_pos,
        collector1_pos,
        frequency_hz,
        time,
        config,
    )
    corr2 = compute_atmospheric_correction(
        emitter_pos,
        collector2_pos,
        frequency_hz,
        time,
        config,
    )

    total1 = corr1.tropo_delay_s + corr1.iono_delay_s
    total2 = corr2.tropo_delay_s + corr2.iono_delay_s
    return total1 - total2


def _time_to_datetime(time: Time) -> datetime:
    """Convert gri_nsepoch.Time to datetime.

    Args:
        time: Time object to convert.

    Returns:
        datetime in UTC timezone.
    """
    # Use ISO string as intermediate format for compatibility
    iso_str = time.iso
    # Parse ISO format - handle various formats
    if iso_str.endswith("Z"):
        iso_str = iso_str[:-1] + "+00:00"
    dt = datetime.fromisoformat(iso_str)
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=UTC)
    return dt
