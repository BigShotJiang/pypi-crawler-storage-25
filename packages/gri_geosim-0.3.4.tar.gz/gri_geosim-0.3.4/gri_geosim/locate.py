"""Geolocation helpers for converting observations to position estimates.

This module provides helper functions that wrap gri-utils locators to convert
observations (TDOA, AOA, FDOA) into position estimates with covariance
(Ell objects from gri-ell).

The locate() function extracts collector state directly from observations,
which are self-contained with all necessary position/velocity information.

Pipeline:
    Observations -> locate() -> Ell (position + covariance)
"""

from __future__ import annotations

from typing import TYPE_CHECKING

import numpy as np
from gri_ell import Ell
from gri_obs import Observation, filter_aoa, filter_fdoa, filter_tdoa
from gri_pos import Pos
from gri_utils.conversion import xyz_to_enu_cov
from scipy.spatial.transform import Rotation

from .geolocation import tdoa_aoa_fdoa_locator

if TYPE_CHECKING:
    from gri_obs import AoaObs, FdoaObs, TdoaObs
    from numpy.typing import NDArray


def _build_tdoa_inputs(
    tdoa_obs: list[TdoaObs],
) -> (
    tuple[
        NDArray[np.floating],
        NDArray[np.floating],
        NDArray[np.floating],
        NDArray[np.floating],
    ]
    | tuple[None, None, None, None]
):
    """Build arrays for TDOA locator inputs.

    Args:
        tdoa_obs: List of TDOA observations.

    Returns:
        Tuple of (collector1_xyz, collector2_xyz, measurements, variances),
        or (None, None, None, None) if no observations.
    """
    if not tdoa_obs:
        return None, None, None, None

    collector1_xyz = np.vstack([np.asarray(obs.collector1.xyz) for obs in tdoa_obs])
    collector2_xyz = np.vstack([np.asarray(obs.collector2.xyz) for obs in tdoa_obs])
    measurements = np.array([obs.value for obs in tdoa_obs])
    variances = np.array([obs.variance for obs in tdoa_obs])

    return collector1_xyz, collector2_xyz, measurements, variances


def _build_aoa_inputs(
    aoa_obs: list[AoaObs],
) -> (
    tuple[
        NDArray[np.floating],
        Rotation,
        NDArray[np.floating],
        NDArray[np.floating],
    ]
    | tuple[None, None, None, None]
):
    """Build arrays for AOA locator inputs.

    Args:
        aoa_obs: List of AOA observations.

    Returns:
        Tuple of (collector_xyz, rotations, measurements, covariances),
        or (None, None, None, None) if no observations.
    """
    if not aoa_obs:
        return None, None, None, None

    collector_xyz = np.vstack([np.asarray(obs.collector.xyz) for obs in aoa_obs])

    # Direction cosines are native in observations
    measurements = np.vstack([obs.direction_cosines for obs in aoa_obs])

    # Covariances are already in direction cosine space
    covariances = np.stack([obs.covariance for obs in aoa_obs])

    # Rotations from observations (actual sensor orientations)
    rotations = Rotation.from_quat(
        np.vstack([obs.collector_rotation.as_quat() for obs in aoa_obs]),
    )

    return collector_xyz, rotations, measurements, covariances


def _build_fdoa_inputs(
    fdoa_obs: list[FdoaObs],
) -> (
    tuple[
        NDArray[np.floating],
        NDArray[np.floating],
        NDArray[np.floating],
        NDArray[np.floating],
        NDArray[np.floating],
        NDArray[np.floating],
        float,
    ]
    | tuple[None, None, None, None, None, None, float]
):
    """Build arrays for FDOA locator inputs.

    Args:
        fdoa_obs: List of FDOA observations.

    Returns:
        Tuple of (collector1_xyz, collector2_xyz, collector1_vel, collector2_vel,
                  measurements, variances, frequency_hz),
        or (None, None, None, None, None, None, default_freq) if no observations.
    """
    if not fdoa_obs:
        return None, None, None, None, None, None, 1.0e9

    collector1_xyz = np.vstack([np.asarray(obs.collector1.xyz) for obs in fdoa_obs])
    collector2_xyz = np.vstack([np.asarray(obs.collector2.xyz) for obs in fdoa_obs])
    collector1_vel = np.vstack([obs.collector1_vel for obs in fdoa_obs])
    collector2_vel = np.vstack([obs.collector2_vel for obs in fdoa_obs])
    measurements = np.array([obs.value for obs in fdoa_obs])
    variances = np.array([obs.variance for obs in fdoa_obs])
    freq_hz = fdoa_obs[-1].frequency_hz  # Use last observation's frequency

    return (
        collector1_xyz,
        collector2_xyz,
        collector1_vel,
        collector2_vel,
        measurements,
        variances,
        freq_hz,
    )


def _result_to_ell(
    position: NDArray[np.floating],
    covariance: NDArray[np.floating],
) -> Ell:
    """Convert locator result to Ell object.

    Args:
        position: ECEF position in meters.
        covariance: ECEF covariance matrix.

    Returns:
        Ell object with position and covariance.
    """
    pos = Pos.XYZ(*position)

    # The locator returns ECEF covariance; convert to Ell
    try:
        info_matrix = np.linalg.inv(covariance)
        return Ell.INFO(pos, info_matrix)
    except np.linalg.LinAlgError:
        # Singular covariance fallback
        enu_cov = xyz_to_enu_cov(pos.xyz, covariance)
        return Ell.COV(pos, enu_cov)


def locate(
    observations: list[Observation],
    *,
    initial_guess: Pos | None = None,
) -> Ell:
    """Estimate position from observations using combined locator.

    Observations are self-contained with collector positions/velocities,
    so no additional platform state needs to be passed.

    Supports any combination of observation types:
    - AOA only
    - TDOA only
    - TDOA + AOA
    - TDOA + FDOA
    - AOA + FDOA
    - TDOA + AOA + FDOA

    Note: FDOA-only is not supported as it requires position constraints.

    Args:
        observations: List of observations. All observations should be
            from the same time instant.
        initial_guess: Optional initial position guess for iterative solvers.
            If None, uses centroid of collectors.

    Returns:
        Ell object containing estimated position and covariance.

    Raises:
        ValueError: If observations list is empty or has unsupported type mix.

    Example:
        >>> from gri_geosim import Scenario, locate
        >>>
        >>> # Run simulation
        >>> observations = scenario.simulate_at(time)
        >>>
        >>> # Locate emitter - no platform positions needed!
        >>> ell = locate(observations)
        >>> print(f"Position: {ell.lla}")
        >>> print(f"Covariance: {ell.cov}")
    """
    if not observations:
        raise ValueError("No observations provided")

    # Build inputs from filtered observations (returns None tuples if empty)
    tdoa_c1, tdoa_c2, tdoa_m, tdoa_v = _build_tdoa_inputs(filter_tdoa(observations))
    aoa_xyz, aoa_rot, aoa_m, aoa_cov = _build_aoa_inputs(filter_aoa(observations))
    fdoa_c1, fdoa_c2, fdoa_v1, fdoa_v2, fdoa_m, fdoa_v, fdoa_freq = _build_fdoa_inputs(
        filter_fdoa(observations),
    )

    # FDOA alone is not supported - need position constraints from TDOA or AOA
    if fdoa_c1 is not None and tdoa_c1 is None and aoa_xyz is None:
        raise ValueError(
            "FDOA-only geolocation requires position constraints. "
            "Combine FDOA with TDOA or AOA observations.",
        )

    # Build initial guess
    xyz0 = np.asarray(initial_guess.xyz) if initial_guess is not None else None

    # Call unified locator - it handles all combinations internally
    result = tdoa_aoa_fdoa_locator(
        tdoa_collector1_xyz=tdoa_c1,
        tdoa_collector2_xyz=tdoa_c2,
        tdoa_measurements=tdoa_m,
        tdoa_variances=tdoa_v,
        aoa_collector_xyz=aoa_xyz,
        aoa_rotations=aoa_rot,
        aoa_measurements=aoa_m,
        aoa_covariances=aoa_cov,
        fdoa_collector1_xyz=fdoa_c1,
        fdoa_collector2_xyz=fdoa_c2,
        fdoa_measurements=fdoa_m,
        fdoa_variances=fdoa_v,
        freq_hz=fdoa_freq,
        fdoa_collector1_vel=fdoa_v1,
        fdoa_collector2_vel=fdoa_v2,
        fix_velocity=np.zeros(3),
        xyz0=xyz0,
    )

    return _result_to_ell(result.position, result.covariance)
