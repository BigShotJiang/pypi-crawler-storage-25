"""FDOA-based geolocation solver.

Estimates 3D target position and/or velocity from multiple Frequency Difference of
Arrival measurements using weighted nonlinear least squares with analytical
Jacobians.

FDOA (Frequency Difference of Arrival) measures the Doppler shift difference
observed at two collectors due to relative motion between emitter and collectors.

The full bistatic FDOA formula accounts for both emitter and collector motion:
    FDOA = f0/c * ((v_emit - v_coll1) . unit1 - (v_emit - v_coll2) . unit2)

Three operating modes are supported:

1. **Unconstrained** (default): Estimates both position and velocity (6 unknowns).
   Requires 6+ measurements. Position-velocity coupling limits accuracy.

2. **Fixed velocity** (fix_velocity=[vx,vy,vz]): Estimates position only (3 unknowns).
   Requires 3+ measurements. Use when target velocity is known (e.g., stationary).
   Dramatically improves position accuracy by eliminating coupling.

3. **Fixed position** (fix_position=[x,y,z]): Estimates velocity only (3 unknowns).
   Requires 3+ measurements. Use when position is known (e.g., from TDOA).
   Provides centimeter-per-second velocity accuracy.

For unconstrained mode, position observability depends on high relative velocity
between emitter and collectors. With stationary collectors and a slow-moving
emitter, position gradients are weak.
"""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

import numpy as np
from gri_utils.geolocation import default_initial_guess, whitened_least_squares
from gri_utils.observables import fdoa_with_gradient

from .locator_result import LocatorResult

if TYPE_CHECKING:
    from collections.abc import Sequence

    from numpy.typing import NDArray


def fdoa_locator(  # noqa: PLR0913, PLR0912, PLR0915, C901
    collector1_xyz: NDArray[np.floating] | Sequence,
    collector2_xyz: NDArray[np.floating] | Sequence,
    fdoa_measurements: NDArray[np.floating] | Sequence,
    fdoa_variances: NDArray[np.floating] | Sequence,
    freq_hz: float,
    xyz0: NDArray[np.floating] | Sequence | None = None,
    vel0: NDArray[np.floating] | Sequence | None = None,
    collector1_vel: NDArray[np.floating] | Sequence | None = None,
    collector2_vel: NDArray[np.floating] | Sequence | None = None,
    fix_velocity: NDArray[np.floating] | Sequence | None = None,
    fix_position: NDArray[np.floating] | Sequence | None = None,
    **least_squares_kwargs: Any,  # noqa: ANN401
) -> LocatorResult:
    """Geolocate a target from multiple FDOA observations.

    Uses weighted nonlinear least squares with analytical Jacobians to estimate
    the target state from frequency-difference-of-arrival measurements.

    Three modes are supported based on constraints:
    - Unconstrained: Estimates position and velocity (6 unknowns, needs 6+ meas)
    - fix_velocity: Estimates position only (3 unknowns, needs 3+ meas)
    - fix_position: Estimates velocity only (3 unknowns, needs 3+ meas)

    Args:
        collector1_xyz: First collector positions in ECEF meters. Shape (N, 3).
        collector2_xyz: Second collector positions in ECEF meters. Shape (N, 3).
        fdoa_measurements: Measured FDOAs in Hz. Shape (N,).
        fdoa_variances: Variance of each FDOA measurement in Hz**2. Shape (N,).
        freq_hz: Carrier frequency in Hz.
        xyz0: Initial guess for target position in ECEF meters. Shape (3,).
            If None, uses centroid of all collectors clamped to Earth radius.
        vel0: Initial guess for target velocity in ECEF m/s. Shape (3,).
            If None, uses zero velocity.
        collector1_vel: First collector velocities in ECEF m/s. Shape (N, 3).
            If None, collectors are assumed stationary.
        collector2_vel: Second collector velocities in ECEF m/s. Shape (N, 3).
            If None, collectors are assumed stationary.
        fix_velocity: If provided, constrains target velocity to this value and
            estimates position only. Shape (3,). Use [0,0,0] for stationary.
        fix_position: If provided, constrains target position to this value and
            estimates velocity only. Shape (3,). Use with TDOA position fix.
        **least_squares_kwargs: Additional arguments passed to
            scipy.optimize.least_squares (e.g., bounds, method, ftol, xtol).

    Returns:
        LocatorResult with:
            - position: Estimated (or fixed) position in ECEF meters. Shape (3,).
            - velocity: Estimated (or fixed) velocity in ECEF m/s. Shape (3,).
              NaN if position-only mode (fix_velocity provided).
            - covariance: Covariance matrix of estimated parameters.
              Shape (6,6) unconstrained, (3,3) for constrained modes.
            - chi_squared: Sum of squared whitened residuals.

    Raises:
        ValueError: If both fix_velocity and fix_position are provided.
        ValueError: If insufficient measurements for the mode.
    """
    collector1_xyz = np.asarray(collector1_xyz)
    collector2_xyz = np.asarray(collector2_xyz)
    fdoa_measurements = np.asarray(fdoa_measurements)
    fdoa_variances = np.asarray(fdoa_variances)

    n_measurements = fdoa_measurements.shape[0]

    # Validate constraint parameters
    if fix_velocity is not None and fix_position is not None:
        msg = "Cannot specify both fix_velocity and fix_position"
        raise ValueError(msg)

    # Determine mode and minimum measurements
    # Initialize fixed values (will be set based on mode)
    fixed_vel: NDArray[np.floating] = np.zeros(3)
    fixed_pos: NDArray[np.floating] = np.zeros(3)

    if fix_velocity is not None:
        mode = "position_only"
        min_measurements = 3
        fixed_vel = np.asarray(fix_velocity)
    elif fix_position is not None:
        mode = "velocity_only"
        min_measurements = 3
        fixed_pos = np.asarray(fix_position)
    else:
        mode = "unconstrained"
        min_measurements = 6

    if n_measurements < min_measurements:
        msg = (
            f"{min_measurements} FDOA measurements required for {mode}, "
            f"got {n_measurements}"
        )
        raise ValueError(msg)

    # Validate shapes
    if collector1_xyz.shape != (n_measurements, 3):
        msg = f"collector1_xyz shape {collector1_xyz.shape} != ({n_measurements}, 3)"
        raise ValueError(msg)

    if collector2_xyz.shape != (n_measurements, 3):
        msg = f"collector2_xyz shape {collector2_xyz.shape} != ({n_measurements}, 3)"
        raise ValueError(msg)

    if fdoa_variances.shape != (n_measurements,):
        msg = f"fdoa_variances shape {fdoa_variances.shape} != ({n_measurements},)"
        raise ValueError(msg)

    # Handle collector velocities (default to zero if not provided)
    if collector1_vel is None:
        coll1_vel = np.zeros((n_measurements, 3))
    else:
        coll1_vel = np.asarray(collector1_vel)
        if coll1_vel.shape != (n_measurements, 3):
            msg = f"collector1_vel shape {coll1_vel.shape} != ({n_measurements}, 3)"
            raise ValueError(msg)

    if collector2_vel is None:
        coll2_vel = np.zeros((n_measurements, 3))
    else:
        coll2_vel = np.asarray(collector2_vel)
        if coll2_vel.shape != (n_measurements, 3):
            msg = f"collector2_vel shape {coll2_vel.shape} != ({n_measurements}, 3)"
            raise ValueError(msg)

    # Build diagonal covariance matrix (N x N)
    full_covariance = np.diag(fdoa_variances)

    # Define residual/Jacobian based on mode
    if mode == "position_only":

        def residual_and_jacobian(
            x: NDArray[np.floating],
        ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
            emit_xyz = x
            emit_vel = fixed_vel

            predicted = np.empty(n_measurements)
            jacobian = np.empty((n_measurements, 3))

            for i in range(n_measurements):
                pred_i, grad_pos_i, _ = fdoa_with_gradient(
                    emit_xyz,
                    emit_vel,
                    collector1_xyz[i],
                    collector2_xyz[i],
                    freq_hz,
                    collector1_vel=coll1_vel[i],
                    collector2_vel=coll2_vel[i],
                )
                predicted[i] = pred_i
                jacobian[i] = grad_pos_i

            residual = fdoa_measurements - predicted
            return residual, -jacobian

        # Initial guess
        if xyz0 is None:
            all_collectors = np.vstack([collector1_xyz, collector2_xyz])
            initial_state = default_initial_guess(all_collectors)
        else:
            initial_state = np.asarray(xyz0)

    elif mode == "velocity_only":

        def residual_and_jacobian(
            x: NDArray[np.floating],
        ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
            emit_xyz = fixed_pos
            emit_vel = x

            predicted = np.empty(n_measurements)
            jacobian = np.empty((n_measurements, 3))

            for i in range(n_measurements):
                pred_i, _, grad_vel_i = fdoa_with_gradient(
                    emit_xyz,
                    emit_vel,
                    collector1_xyz[i],
                    collector2_xyz[i],
                    freq_hz,
                    collector1_vel=coll1_vel[i],
                    collector2_vel=coll2_vel[i],
                )
                predicted[i] = pred_i
                jacobian[i] = grad_vel_i

            residual = fdoa_measurements - predicted
            return residual, -jacobian

        # Initial guess
        initial_state = np.zeros(3) if vel0 is None else np.asarray(vel0)

    else:  # unconstrained

        def residual_and_jacobian(
            x: NDArray[np.floating],
        ) -> tuple[NDArray[np.floating], NDArray[np.floating]]:
            emit_xyz = x[:3]
            emit_vel = x[3:]

            predicted = np.empty(n_measurements)
            jacobian = np.empty((n_measurements, 6))

            for i in range(n_measurements):
                pred_i, grad_pos_i, grad_vel_i = fdoa_with_gradient(
                    emit_xyz,
                    emit_vel,
                    collector1_xyz[i],
                    collector2_xyz[i],
                    freq_hz,
                    collector1_vel=coll1_vel[i],
                    collector2_vel=coll2_vel[i],
                )
                predicted[i] = pred_i
                jacobian[i, :3] = grad_pos_i
                jacobian[i, 3:] = grad_vel_i

            residual = fdoa_measurements - predicted
            return residual, -jacobian

        # Initial guess
        if xyz0 is None:
            all_collectors = np.vstack([collector1_xyz, collector2_xyz])
            initial_xyz = default_initial_guess(all_collectors)
        else:
            initial_xyz = np.asarray(xyz0)
        initial_vel = np.zeros(3) if vel0 is None else np.asarray(vel0)
        initial_state = np.concatenate([initial_xyz, initial_vel])

    # Solve
    solution, covariance, chi_squared = whitened_least_squares(
        residual_and_jacobian,
        initial_state,
        full_covariance,
        **least_squares_kwargs,
    )

    # Extract results based on mode
    if mode == "position_only":
        # Position estimated, velocity was fixed by user
        return LocatorResult(solution, fixed_vel, covariance, chi_squared)
    if mode == "velocity_only":
        # Velocity estimated, position was fixed by user
        return LocatorResult(fixed_pos, solution, covariance, chi_squared)
    # Unconstrained: both position and velocity estimated
    return LocatorResult(solution[:3], solution[3:], covariance, chi_squared)
