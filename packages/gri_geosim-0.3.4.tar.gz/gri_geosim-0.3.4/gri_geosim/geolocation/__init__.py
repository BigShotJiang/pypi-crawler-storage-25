"""Geolocation solvers for AOA, TDOA, FDOA, and hybrid measurements.

These locators are convenience wrappers that build residual/Jacobian closures
from typed measurement arrays and call the generic whitened_least_squares
solver from gri_utils. They handle input validation, covariance construction,
initial guess generation, and result packaging.

For direct access to the underlying solver with full covariance control, use
gri_utils.geolocation.whitened_least_squares with the *_with_gradient
functions from gri_utils.observables.
"""

from .aoa_locator import aoa_locator
from .fdoa_locator import fdoa_locator
from .locator_result import NAN_VELOCITY, LocatorResult
from .tdoa_aoa_fdoa_locator import tdoa_aoa_fdoa_locator
from .tdoa_aoa_locator import tdoa_aoa_locator
from .tdoa_dot_locator import tdoa_dot_locator
from .tdoa_locator import tdoa_locator

__all__ = [
    "NAN_VELOCITY",
    "LocatorResult",
    "aoa_locator",
    "fdoa_locator",
    "tdoa_aoa_fdoa_locator",
    "tdoa_aoa_locator",
    "tdoa_dot_locator",
    "tdoa_locator",
]
