# GeoSim/Geolocation

Observable-specific locators for estimating emitter position from measurements.

These locators are convenience wrappers that build residual/Jacobian closures from typed measurement arrays and call the generic `whitened_least_squares` solver from gri-utils. They handle input validation, covariance construction, initial guess generation, and result packaging.

For the low-level solver with full covariance control, see `gri_utils.geolocation.whitened_least_squares`.

## Import and Use

```python
from gri_geosim import tdoa_locator, aoa_locator, fdoa_locator, tdoa_dot_locator
from gri_geosim import tdoa_aoa_locator, tdoa_aoa_fdoa_locator
from gri_geosim import LocatorResult
```

Or import from the geolocation subpackage:

```python
from gri_geosim.geolocation import tdoa_locator, LocatorResult
```

## Module Overview

| Name | Purpose |
|------|---------|
| `tdoa_locator` | Position from TDOA measurements (3+ required) |
| `aoa_locator` | Position from AOA measurements (2+ required) |
| `fdoa_locator` | Position and/or velocity from FDOA measurements |
| `tdoa_dot_locator` | Position and/or velocity from TDOA-dot (s/s) measurements |
| `tdoa_aoa_locator` | Position from combined TDOA + AOA measurements |
| `tdoa_aoa_fdoa_locator` | Position from combined TDOA + AOA + FDOA measurements |
| `LocatorResult` | Named tuple holding solution position, velocity, covariance, and chi-squared |

## LocatorResult

All locators return a `LocatorResult` named tuple:

```python
result = tdoa_locator(...)
result.position      # NDArray shape (3,), ECEF meters
result.velocity      # NDArray shape (3,), ECEF m/s (NaN if not estimated)
result.covariance    # NDArray shape (3,3) or (6,6)
result.chi_squared   # float, goodness of fit
```

When a locator estimates position only, `velocity` is `[NaN, NaN, NaN]` and covariance is (3, 3). When both position and velocity are estimated (unconstrained FDOA), covariance is (6, 6).

## tdoa_locator

Estimates 3D position from time-difference-of-arrival measurements.

```python
import numpy as np
from gri_geosim import tdoa_locator

result = tdoa_locator(
    collector1_xyz=np.array([[6.4e6, 1e3, 0], [6.4e6, 0, 1e3], [6.4e6, -1e3, 0]]),
    collector2_xyz=np.array([[6.4e6, -1e3, 0], [6.4e6, 0, -1e3], [6.4e6, 1e3, 0]]),
    tdoa_measurements=np.array([1e-6, -0.5e-6, 0.3e-6]),
    tdoa_variances=np.array([1e-18, 1e-18, 1e-18]),
    xyz0=None,  # auto-generates initial guess from collector centroid
)
```

**Requirements:** 3+ measurements. Returns position only (velocity is NaN).

## aoa_locator

Estimates 3D position from angle-of-arrival measurements (direction cosines with rotation frames).

```python
import numpy as np
from scipy.spatial.transform import Rotation
from gri_geosim import aoa_locator

result = aoa_locator(
    collector_xyz=np.array([[6.4e6, 1e3, 0], [6.4e6, -1e3, 0]]),
    collector_rotations=Rotation.identity(2),
    aoa_measurements=np.array([[0.1, 0.2], [-0.1, 0.15]]),
    aoa_covariances=np.tile(np.diag([1e-6, 1e-6]), (2, 1, 1)),
)
```

**Requirements:** 2+ collectors. Rotations use scipy quaternion convention [x, y, z, w].

## fdoa_locator

Estimates position and/or velocity from frequency-difference-of-arrival measurements. Supports three modes:

| Mode | Constraint | Unknowns | Min measurements |
|------|-----------|----------|------------------|
| Unconstrained | none | 6 (pos + vel) | 6 |
| Position only | `fix_velocity=[vx,vy,vz]` | 3 (pos) | 3 |
| Velocity only | `fix_position=[x,y,z]` | 3 (vel) | 3 |

```python
import numpy as np
from gri_geosim import fdoa_locator

# Position-only mode (stationary emitter)
result = fdoa_locator(
    collector1_xyz=collectors1,
    collector2_xyz=collectors2,
    fdoa_measurements=measurements,
    fdoa_variances=variances,
    freq_hz=1.5e9,
    collector1_vel=vel1,
    collector2_vel=vel2,
    fix_velocity=np.array([0.0, 0.0, 0.0]),  # stationary target
)
```

## tdoa_dot_locator

Estimates position and/or velocity from TDOA-dot measurements (time derivative of TDOA, s/s). Mathematically equivalent to `fdoa_locator` via `FDOA = -f0 * TDOA_dot`, but frequency-independent - use when the native measurement is a correlator delay-rate output or no carrier frequency is available. Supports the same three modes as `fdoa_locator`:

| Mode | Constraint | Unknowns | Min measurements |
|------|-----------|----------|------------------|
| Unconstrained | none | 6 (pos + vel) | 6 |
| Position only | `fix_velocity=[vx,vy,vz]` | 3 (pos) | 3 |
| Velocity only | `fix_position=[x,y,z]` | 3 (vel) | 3 |

```python
import numpy as np
from gri_geosim import tdoa_dot_locator

# Position-only mode (stationary emitter)
result = tdoa_dot_locator(
    collector1_xyz=collectors1,
    collector2_xyz=collectors2,
    tdoa_dot_measurements=measurements,    # s/s
    tdoa_dot_variances=variances,          # (s/s)**2
    collector1_vel=vel1,
    collector2_vel=vel2,
    fix_velocity=np.array([0.0, 0.0, 0.0]),
)
```

## tdoa_aoa_locator

Combines TDOA and AOA measurements for improved position accuracy. Accepts both measurement types simultaneously and builds a joint residual/Jacobian.

## tdoa_aoa_fdoa_locator

Combines TDOA, AOA, and FDOA measurements. The most general locator, accepting any combination of measurement types.

## High-Level Entry Point: locate()

For simulation workflows, `locate()` in `gri_geosim.locate` provides a higher-level interface that accepts a list of `Observation` objects directly:

```python
from gri_geosim import locate

observations = scenario.simulate_at(time)
ell = locate(observations)  # returns an Ell (covariance ellipsoid)
```

`locate()` automatically extracts collector positions, measurements, and covariances from the observation objects and calls the appropriate locator. It returns an `Ell` object (from gri-ell) rather than a `LocatorResult`.

## Notes

- All positions are in ECEF (XYZ) coordinates in meters.
- All locators accept an optional `xyz0` initial guess. If not provided, the centroid of collectors is projected to the Earth surface.
- Additional keyword arguments are passed through to `scipy.optimize.least_squares` (e.g., `method`, `ftol`, `xtol`, `bounds`).
- These locators wrap `gri_utils.geolocation.whitened_least_squares` and `gri_utils.observables.*_with_gradient` functions.
