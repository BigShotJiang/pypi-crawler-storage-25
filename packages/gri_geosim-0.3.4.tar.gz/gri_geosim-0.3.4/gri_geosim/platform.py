"""Platform class for observer entities in geolocation simulations.

A Platform represents a moving or stationary observer that hosts sensors.
Platforms can be satellites, ground stations, aircraft, ships, or any
entity capable of hosting sensors for geolocation observations.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from gri_pos import Pos, Vel

from .trajectories import StationaryTrajectory, Trajectory

if TYPE_CHECKING:
    import numpy as np
    from gri_nsepoch import Time
    from numpy.typing import NDArray

    from .sensors.sensor import Sensor


class Platform:
    """Platform hosting sensors (satellite, ground station, aircraft).

    A Platform represents an observer entity with a trajectory defining its
    motion and zero or more attached sensors for generating observations.

    The first argument can be a Trajectory or a Pos. If a Pos is given,
    a StationaryTrajectory is created automatically.

    Attributes:
        name: Human-readable identifier for the platform.
        trajectory: The trajectory defining platform motion.
        sensors: List of sensors attached to this platform.

    Example:
        >>> from gri_pos import Pos
        >>> from gri_nsepoch import Time
        >>>
        >>> # Stationary platform (Pos creates StationaryTrajectory)
        >>> ground = Platform(Pos.LLA(38.0, -77.0, 100.0), name="DC")
        >>>
        >>> # Get position at a specific time
        >>> pos = ground.position_at(Time())
    """

    __slots__ = ("_name", "_sensors", "_trajectory")

    def __init__(
        self,
        trajectory: Trajectory | Pos,
        *,
        name: str = "",
    ) -> None:
        """Initialize a Platform.

        Args:
            trajectory: Trajectory defining the platform's motion over time,
                or a Pos for a stationary platform.
            name: Optional human-readable identifier.
        """
        if isinstance(trajectory, Pos):
            trajectory = StationaryTrajectory(trajectory)
        self._trajectory = trajectory
        self._name = name
        self._sensors: list[Sensor] = []

    # =========================================================================
    # Properties
    # =========================================================================

    @property
    def name(self) -> str:
        """Human-readable identifier for this platform."""
        return self._name

    @property
    def trajectory(self) -> Trajectory:
        """The trajectory defining this platform's motion."""
        return self._trajectory

    @property
    def sensors(self) -> list[Sensor]:
        """List of sensors attached to this platform.

        Returns a copy to prevent external modification.
        """
        return list(self._sensors)

    # =========================================================================
    # Sensor management
    # =========================================================================

    def add_sensor(self, sensor: Sensor) -> None:
        """Attach a sensor to this platform.

        The sensor's platform reference is set to this platform.

        Args:
            sensor: Sensor to attach.

        Raises:
            ValueError: If sensor is already attached to another platform.
        """
        if sensor.platform is not None and sensor.platform is not self:
            raise ValueError(
                f"Sensor '{sensor.sensor_id}' is already attached to another platform",
            )
        sensor._set_platform(self)  # noqa: SLF001
        self._sensors.append(sensor)

    def remove_sensor(self, sensor: Sensor) -> None:
        """Remove a sensor from this platform.

        Args:
            sensor: Sensor to remove.

        Raises:
            ValueError: If sensor is not attached to this platform.
        """
        if sensor not in self._sensors:
            raise ValueError(
                f"Sensor '{sensor.sensor_id}' is not attached to this platform",
            )
        self._sensors.remove(sensor)
        sensor._set_platform(None)  # noqa: SLF001

    # =========================================================================
    # Position and velocity queries
    # =========================================================================

    def _dt_for(self, time: Time) -> float:
        """Convert an absolute Time to the trajectory's relative dt (seconds)."""
        return float(time.secs) - float(self._trajectory.epoch_unix_s)

    def position_at(self, time: Time) -> Pos:
        """Get platform position at a specific time.

        Args:
            time: Time instant for position query.

        Returns:
            Pos object with platform position in ECEF frame.
        """
        return self._trajectory.position_at(self._dt_for(time))

    def velocity_at(self, time: Time) -> NDArray[np.floating]:
        """Get platform velocity at a specific time.

        Args:
            time: Time instant for velocity query.

        Returns:
            Velocity vector [vx, vy, vz] in ECEF frame, meters per second.
        """
        return self._trajectory.velocity_at(self._dt_for(time))

    def state_at(self, time: Time) -> Vel:
        """Get the platform state at a specific time.

        More efficient than calling position_at and velocity_at separately
        for some trajectory types.

        Args:
            time: Time instant for state query.

        Returns:
            Vel in the ECEF frame carrying both position and velocity.
        """
        return self._trajectory.state_at(self._dt_for(time))

    # =========================================================================
    # Dunder methods
    # =========================================================================

    def __repr__(self) -> str:
        """Return string representation."""
        sensor_count = len(self._sensors)
        name_str = f"'{self._name}'" if self._name else "unnamed"
        traj_name = type(self._trajectory).__name__
        return f"Platform({name_str}, sensors={sensor_count}, trajectory={traj_name})"

    def __str__(self) -> str:
        """Return human-readable string."""
        name_str = self._name or "Unnamed Platform"
        traj_type = type(self._trajectory).__name__
        sensor_count = len(self._sensors)
        sensors_str = f", {sensor_count} sensor(s)" if sensor_count else ""
        return f"{name_str} [{traj_type}]{sensors_str}"
