# GeoSim/Observations

Self-contained measurement objects with embedded collector state.

Each observation carries everything needed for geolocation: the measured value, its uncertainty, the collector position(s), and metadata. This eliminates the need to pass platform state separately to locators.

## Import and Use

```python
from gri_geosim import TdoaObservation, AoaObservation, FdoaObservation
from gri_geosim import filter_tdoa, filter_aoa, filter_fdoa
```

Or import from the observations subpackage:

```python
from gri_geosim.observations import TdoaObservation, Observation, filter_tdoa
```

## Module Overview

| Name | Purpose |
|------|---------|
| `TdoaObservation` | Time Difference of Arrival measurement with two collector positions |
| `AoaObservation` | Angle of Arrival measurement as direction cosines with rotation |
| `FdoaObservation` | Frequency Difference of Arrival with collector positions and velocities |
| `Observation` | Type union: `TdoaObservation \| AoaObservation \| FdoaObservation` |
| `filter_aoa` | Extract AOA observations from a mixed list |
| `filter_tdoa` | Extract TDOA observations from a mixed list |
| `filter_fdoa` | Extract FDOA observations from a mixed list |
| `filter_by_sensor` | Filter observations by sensor ID |
| `filter_by_emitter` | Filter observations by emitter ID |

## TdoaObservation

Stores a time-difference-of-arrival measurement in seconds with the positions of both collectors.

```python
from gri_geosim import TdoaObservation
from gri_pos import Pos
from gri_nsepoch import Time

obs = TdoaObservation(
    time=Time.from_str("2024-01-15T12:00:00Z"),
    value=1.5e-6,           # TDOA in seconds
    std_dev=1e-9,           # standard deviation in seconds
    collector1=Pos.XYZ(6378137.0, 1000.0, 0.0),
    collector2=Pos.XYZ(6378137.0, -1000.0, 0.0),
    sensor_id="TDOA-1",
)
```

**Properties:**

| Property | Type | Description |
|----------|------|-------------|
| `time` | `Time` | Measurement epoch |
| `value` | `float` | TDOA in seconds |
| `std_dev` | `float` | Standard deviation in seconds |
| `variance` | `float` | Variance in seconds^2 (computed from std_dev) |
| `collector1` | `Pos` | First collector position |
| `collector2` | `Pos` | Second collector position |
| `sensor_id` | `str` | Sensor identifier |
| `emitter_id` | `str \| None` | Emitter identifier (if known) |
| `obs_type` | `str` | Returns `"TDOA"` |

## AoaObservation

Stores an angle-of-arrival measurement as direction cosines (u, v) with a 2x2 covariance matrix and the collector's rotation frame. Two construction patterns are available.

### Direct construction (direction cosines)

For use when you already have direction cosines and covariance in the sensor frame:

```python
import numpy as np
from scipy.spatial.transform import Rotation
from gri_geosim import AoaObservation
from gri_pos import Pos
from gri_nsepoch import Time

obs = AoaObservation(
    time=Time.from_str("2024-01-15T12:00:00Z"),
    u=0.5,
    v=0.3,
    covariance=np.diag([1e-6, 1e-6]),
    collector=Pos.XYZ(6378137.0, 0.0, 0.0),
    collector_rotation=Rotation.identity(),
    sensor_id="AOA-1",
)
```

### From azimuth/elevation

The `from_azel()` classmethod converts azimuth and elevation angles (with their standard deviations) to direction cosines in the ENU frame automatically:

```python
obs = AoaObservation.from_azel(
    time=Time.from_str("2024-01-15T12:00:00Z"),
    azimuth_rad=0.785,          # radians
    elevation_rad=0.524,        # radians
    std_dev_az_rad=0.001,       # azimuth std dev in radians
    std_dev_el_rad=0.001,       # elevation std dev in radians
    collector=Pos.LLA(38.0, -77.0, 100.0),
    sensor_id="AOA-1",
)
```

This computes the ENU rotation from the collector position, converts (az, el) to direction cosines, and transforms the angular covariance through the Jacobian.

**Properties:**

| Property | Type | Description |
|----------|------|-------------|
| `time` | `Time` | Measurement epoch |
| `u` | `float` | X direction cosine |
| `v` | `float` | Y direction cosine |
| `direction_cosines` | `NDArray` | [u, v] array |
| `covariance` | `NDArray` | 2x2 covariance matrix in direction cosine space |
| `std_dev` | `NDArray` | [std_u, std_v] from covariance diagonal |
| `azimuth` | `float` | Computed azimuth in radians |
| `elevation` | `float` | Computed elevation in radians |
| `z_positive` | `bool` | Whether target is in front of boresight |
| `collector` | `Pos` | Collector position |
| `collector_rotation` | `Rotation` | Sensor frame rotation (scipy Rotation) |
| `sensor_id` | `str` | Sensor identifier |
| `emitter_id` | `str \| None` | Emitter identifier (if known) |
| `obs_type` | `str` | Returns `"AOA"` |

## FdoaObservation

Stores a frequency-difference-of-arrival measurement in Hz with both collectors' positions and velocities.

```python
import numpy as np
from gri_geosim import FdoaObservation
from gri_pos import Pos
from gri_nsepoch import Time

obs = FdoaObservation(
    time=Time.from_str("2024-01-15T12:00:00Z"),
    value=2.5,              # FDOA in Hz
    std_dev=0.1,            # standard deviation in Hz
    collector1=Pos.XYZ(6378137.0, 1000.0, 0.0),
    collector2=Pos.XYZ(6378137.0, -1000.0, 0.0),
    collector1_vel=np.array([0.0, 7500.0, 0.0]),   # m/s ECEF
    collector2_vel=np.array([0.0, -7500.0, 0.0]),   # m/s ECEF
    frequency_hz=1.5e9,     # carrier frequency
    sensor_id="FDOA-1",
)
```

**Properties:**

| Property | Type | Description |
|----------|------|-------------|
| `time` | `Time` | Measurement epoch |
| `value` | `float` | FDOA in Hz |
| `std_dev` | `float` | Standard deviation in Hz |
| `variance` | `float` | Variance in Hz^2 (computed from std_dev) |
| `collector1` | `Pos` | First collector position |
| `collector2` | `Pos` | Second collector position |
| `collector1_vel` | `NDArray` | First collector velocity [vx, vy, vz] in ECEF m/s |
| `collector2_vel` | `NDArray` | Second collector velocity [vx, vy, vz] in ECEF m/s |
| `frequency_hz` | `float` | Carrier frequency in Hz |
| `sensor_id` | `str` | Sensor identifier |
| `emitter_id` | `str \| None` | Emitter identifier (if known) |
| `obs_type` | `str` | Returns `"FDOA"` |

## Filter Functions

Filter a mixed list of observations by type or metadata:

```python
from gri_geosim import filter_aoa, filter_tdoa, filter_fdoa
from gri_geosim import filter_by_sensor, filter_by_emitter

# Scenario returns list[Observation]
observations = scenario.simulate_at(time)

# Filter by observation type
aoa_obs = filter_aoa(observations)       # list[AoaObservation]
tdoa_obs = filter_tdoa(observations)     # list[TdoaObservation]
fdoa_obs = filter_fdoa(observations)     # list[FdoaObservation]

# Filter by metadata
sensor_obs = filter_by_sensor(observations, "AOA-1")
emitter_obs = filter_by_emitter(observations, "TARGET")
```

## Notes

- Collector positions use `Pos` objects (from gri-pos), not raw numpy arrays.
- Uncertainty is specified as `std_dev` (standard deviation), not variance. The `variance` property is computed as `std_dev ** 2`.
- All observations support `is_valid()`, `__eq__`, `__hash__`, `__repr__`, and `__str__`.
- The `Observation` type alias is a union of all three observation types, useful for type annotations on mixed lists.
- Velocities on FdoaObservation remain numpy arrays (no Vel class in the ecosystem).
