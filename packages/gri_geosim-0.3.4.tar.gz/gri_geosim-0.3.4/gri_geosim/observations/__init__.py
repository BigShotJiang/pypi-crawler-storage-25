"""Typed observation classes for geolocation measurements.

Re-exports from gri-obs. All observation types and filter functions are
provided by the gri-obs package.

Observation Types:
    - TdoaObs: Time Difference of Arrival
    - AoaObs: Angle of Arrival
    - FdoaObs: Frequency Difference of Arrival
    - RangeObs: Range / distance

The Observation type alias is a union of all observation types.

Example:
    >>> from gri_geosim.observations import TdoaObs, Observation
    >>> obs: Observation = TdoaObs(...)
"""

from gri_obs import (
    AoaObs,
    FdoaObs,
    Observation,
    RangeObs,
    TdoaObs,
    filter_aoa,
    filter_by_emitter,
    filter_by_sensor,
    filter_fdoa,
    filter_range,
    filter_tdoa,
)

__all__ = [
    "AoaObs",
    "FdoaObs",
    "Observation",
    "RangeObs",
    "TdoaObs",
    "filter_aoa",
    "filter_by_emitter",
    "filter_by_sensor",
    "filter_fdoa",
    "filter_range",
    "filter_tdoa",
]
