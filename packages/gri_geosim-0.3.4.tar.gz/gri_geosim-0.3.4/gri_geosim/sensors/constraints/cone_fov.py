"""ConeFov constraint - conical field of view from sensor boresight.

Models a sensor that can only observe targets within a cone
centered on the sensor's boresight direction (typically nadir
for Earth-observing satellites).
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING

import numpy as np

if TYPE_CHECKING:
    from gri_pos import Pos


class ConeFov:
    """Conical field of view from sensor boresight.

    Models a sensor that can only observe targets within a cone
    centered on the sensor's boresight direction (typically nadir
    for Earth-observing satellites).

    The half-angle defines the maximum off-axis angle for visibility.
    For example, a half-angle of 60 deg means the sensor can see targets
    up to 60 deg away from the boresight direction.

    Attributes:
        half_angle_rad: Half-cone angle in radians.

    Example:
        >>> from gri_pos import Pos
        >>> fov = ConeFov(half_angle_deg=45.0)
        >>> sat = Pos.LLA(0.0, 0.0, 400_000.0)  # 400 km altitude
        >>> emitter = Pos.LLA(5.0, 0.0, 0.0)     # Near nadir
        >>> fov.is_visible(sat, emitter)
        True
    """

    __slots__ = ("_half_angle_rad",)

    def __init__(self, half_angle_deg: float) -> None:
        """Initialize conical FOV with half-angle.

        Args:
            half_angle_deg: Half-cone angle in degrees (0 to 90).
                A value of 90 deg means hemispherical coverage.

        Raises:
            ValueError: If half_angle_deg is not in (0, 90].
        """
        if half_angle_deg <= 0 or half_angle_deg > 90:  # noqa: PLR2004
            raise ValueError(
                f"Half angle must be in (0, 90] degrees, got {half_angle_deg}",
            )
        self._half_angle_rad = math.radians(half_angle_deg)

    @property
    def half_angle_rad(self) -> float:
        """Half-cone angle in radians."""
        return self._half_angle_rad

    @property
    def half_angle_deg(self) -> float:
        """Half-cone angle in degrees."""
        return math.degrees(self._half_angle_rad)

    def is_visible(self, sensor_pos: Pos, emitter_pos: Pos) -> bool:
        """Check if emitter is within the conical FOV.

        The boresight is assumed to point toward Earth center (nadir).
        The emitter is visible if the angle between the nadir direction
        and the emitter direction is less than the half-angle.

        Args:
            sensor_pos: Sensor position in ECEF frame.
            emitter_pos: Emitter position in ECEF frame.

        Returns:
            True if emitter is within the cone.
        """
        # Get sensor XYZ position
        sensor_xyz = sensor_pos.xyz

        # Nadir vector (toward Earth center, normalized)
        nadir = -sensor_xyz / np.linalg.norm(sensor_xyz)

        # Vector to emitter (normalized)
        to_emitter = emitter_pos.xyz - sensor_xyz
        to_emitter_norm = np.linalg.norm(to_emitter)
        if to_emitter_norm < 1e-10:  # noqa: PLR2004
            return True  # Same location, consider visible
        to_emitter = to_emitter / to_emitter_norm

        # Angle between nadir and emitter direction
        cos_angle = np.dot(nadir, to_emitter)
        angle_rad = np.arccos(np.clip(cos_angle, -1.0, 1.0))

        return angle_rad <= self._half_angle_rad

    def __repr__(self) -> str:
        """Return string representation."""
        return f"ConeFov(half_angle_deg={self.half_angle_deg:.1f})"

    def __str__(self) -> str:
        """Return human-readable string."""
        return f"Cone FOV: +/-{self.half_angle_deg:.1f} deg"
