"""Field of view constraint classes for sensor visibility.

This module provides FOV constraint implementations that determine whether
a sensor can observe an emitter based on geometric relationships.

Available constraints:
- FovConstraint: Protocol for all FOV constraints
- NoFov: No constraint (always visible)
- ConeFov: Conical field of view
- ElevationMaskFov: Elevation angle constraints (auto-detects ground reference)
- EarthOcclusionFov: Earth line-of-sight blockage check

Example:
    >>> from gri_geosim.sensors.constraints import ElevationMaskFov, ConeFov
    >>>
    >>> # Ground station with elevation mask
    >>> ground_fov = ElevationMaskFov(min_elev_deg=10.0)
    >>>
    >>> # Satellite with conical FOV
    >>> sat_fov = ConeFov(half_angle_deg=60.0)
"""

from .cone_fov import ConeFov
from .earth_occlusion_fov import EarthOcclusionFov
from .elevation_mask_fov import ElevationMaskFov
from .fov_constraint import FovConstraint
from .no_fov import NoFov

__all__ = [
    "ConeFov",
    "EarthOcclusionFov",
    "ElevationMaskFov",
    "FovConstraint",
    "NoFov",
]
