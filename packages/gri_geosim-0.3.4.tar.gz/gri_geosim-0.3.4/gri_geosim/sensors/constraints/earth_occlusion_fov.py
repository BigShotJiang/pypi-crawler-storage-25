"""EarthOcclusionFov constraint - Earth line-of-sight blockage check.

Checks if the line of sight between sensor and emitter is blocked
by the WGS84 Earth ellipsoid.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from gri_utils.distance import line_of_sight_clear

if TYPE_CHECKING:
    from gri_pos import Pos


class EarthOcclusionFov:
    """Earth occlusion field of view constraint.

    Checks if the line of sight between sensor and emitter is blocked
    by the WGS84 Earth ellipsoid. This is a simple binary visibility
    check that works for any geometry:

    - Satellite to satellite
    - Satellite to ground
    - Ground to satellite
    - Any two points in ECEF space

    For elevation angle constraints (e.g., minimum degrees above horizon),
    use ElevationMaskFov instead.

    Example:
        >>> from gri_pos import Pos
        >>> fov = EarthOcclusionFov()

        >>> # Two satellites with clear view
        >>> sat1 = Pos.XYZ(42164e3, 0.0, 0.0)
        >>> sat2 = Pos.XYZ(0.0, 42164e3, 0.0)
        >>> fov.is_visible(sat1, sat2)
        True

        >>> # Two satellites on opposite sides - blocked
        >>> sat3 = Pos.XYZ(-42164e3, 0.0, 0.0)
        >>> fov.is_visible(sat1, sat3)
        False
    """

    __slots__ = ()

    def is_visible(self, sensor_pos: Pos, emitter_pos: Pos) -> bool:
        """Check if line of sight is clear of Earth.

        Args:
            sensor_pos: Sensor position in ECEF frame.
            emitter_pos: Emitter position in ECEF frame.

        Returns:
            True if line of sight is clear (Earth does not block).
            False if Earth blocks the line of sight.
        """
        return bool(line_of_sight_clear(sensor_pos.xyz, emitter_pos.xyz))

    def __repr__(self) -> str:
        """Return string representation."""
        return "EarthOcclusionFov()"

    def __str__(self) -> str:
        """Return human-readable string."""
        return "Earth occlusion check"

    def __eq__(self, other: object) -> bool:
        """Check equality with another EarthOcclusionFov."""
        if not isinstance(other, EarthOcclusionFov):
            return NotImplemented
        return True

    def __hash__(self) -> int:
        """Return hash value."""
        return hash(type(self))
