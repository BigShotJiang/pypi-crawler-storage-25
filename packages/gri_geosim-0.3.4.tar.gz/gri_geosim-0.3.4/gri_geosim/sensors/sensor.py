"""Base Sensor abstract class for observation generation.

Sensors are attached to platforms and generate observations of emitters.
Different sensor types measure different observables:
- AOA (Angle of Arrival): azimuth and elevation angles
- TDOA (Time Difference of Arrival): time difference between receivers
- FDOA (Frequency Difference of Arrival): Doppler frequency difference

All sensors share common functionality for FOV checking, noise generation,
and correction application.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from threading import Lock
from typing import TYPE_CHECKING, ClassVar, Literal

import numpy as np

from .constraints import NoFov

if TYPE_CHECKING:
    from gri_nsepoch import Time
    from gri_obs import Observation
    from gri_pos import Pos
    from numpy.random import Generator

    from gri_geosim.atmosphere import AtmosphereConfig
    from gri_geosim.emitter import Emitter
    from gri_geosim.platform import Platform

    from .constraints import FovConstraint


# Altitude thresholds for atmosphere application decisions (meters)
_TROPO_CEILING_M = 50_000.0  # 50 km - top of troposphere
_SPACE_THRESHOLD_M = 100_000.0  # 100 km - Kármán line


class Sensor(ABC):
    """Abstract base class for sensors.

    A Sensor is attached to a Platform and can observe Emitters to produce
    Observations. Each sensor type implements specific measurement physics
    and noise models.

    Subclasses must implement:
    - can_observe(): Check if observation is possible
    - observe(): Generate an observation (or None if not visible)
    - _compute_measurement(): Core measurement computation
    - _compute_covariance(): Measurement covariance matrix

    Subclasses should define:
    - _TYPE_PREFIX: Short string prefix for auto-generated IDs (e.g., "AOA")

    Attributes:
        sensor_id: Unique identifier for this sensor. If not provided,
            auto-generated as "{TYPE_PREFIX}-{counter}" (e.g., "AOA-1").
        fov: Field of view constraint.
        platform: The platform this sensor is attached to (set by Platform.add_sensor).
        apply_atmosphere: Controls atmospheric correction application.
            - "auto": Apply based on geometry (ground-to-space paths only)
            - True: Always apply if atmosphere config provided
            - False: Never apply
        rng: Random number generator for noise.

    Example:
        >>> class MySensor(Sensor):
        ...     _TYPE_PREFIX = "MY"
        ...     def can_observe(self, emitter, time): ...
        ...     def observe(self, emitter, time, add_noise=True): ...
        ...     # ... other abstract methods
    """

    __slots__ = ("_apply_atmosphere", "_fov", "_platform", "_rng", "_sensor_id")

    _id_counters: ClassVar[dict[str, int]] = {}
    _id_lock: ClassVar[Lock] = Lock()
    _TYPE_PREFIX: ClassVar[str] = "SENSOR"

    @classmethod
    def _next_id(cls) -> str:
        """Generate the next auto-incremented ID for this sensor type.

        Thread-safe ID generation using the subclass's _TYPE_PREFIX.

        Returns:
            A string ID like "AOA-1", "TDOA-2", etc.
        """
        prefix = cls._TYPE_PREFIX
        with cls._id_lock:
            count = cls._id_counters.get(prefix, 0) + 1
            cls._id_counters[prefix] = count
        return f"{prefix}-{count}"

    def __init__(
        self,
        sensor_id: str | None = None,
        *,
        fov: FovConstraint | None = None,
        apply_atmosphere: Literal["auto"] | bool = "auto",
        rng_seed: int | None = None,
    ) -> None:
        """Initialize the sensor.

        Args:
            sensor_id: Unique identifier for this sensor. If None, an ID
                is auto-generated using the sensor type prefix (e.g., "AOA-1").
            fov: Field of view constraint. Defaults to NoFov (no constraint).
            apply_atmosphere: Controls atmospheric correction application.
                - "auto": Apply based on geometry (ground-to-space paths only)
                - True: Always apply if atmosphere config provided
                - False: Never apply atmospheric corrections
                Defaults to "auto".
            rng_seed: Optional seed for the random number generator.
                If None, uses numpy's default random state.
        """
        self._sensor_id = sensor_id if sensor_id is not None else self._next_id()
        self._fov = fov if fov is not None else NoFov()
        self._apply_atmosphere: Literal["auto"] | bool = apply_atmosphere
        self._platform: Platform | None = None
        self._rng: Generator = np.random.default_rng(rng_seed)

    # =========================================================================
    # Properties
    # =========================================================================

    @property
    def sensor_id(self) -> str:
        """Unique identifier for this sensor."""
        return self._sensor_id

    @property
    def fov(self) -> FovConstraint:
        """Field of view constraint."""
        return self._fov

    @property
    def platform(self) -> Platform | None:
        """The platform this sensor is attached to, or None if not attached."""
        return self._platform

    @property
    def rng(self) -> Generator:
        """Random number generator for noise."""
        return self._rng

    @property
    def apply_atmosphere(self) -> Literal["auto"] | bool:
        """Controls atmospheric correction application."""
        return self._apply_atmosphere

    # =========================================================================
    # Platform attachment (called by Platform.add_sensor)
    # =========================================================================

    def _set_platform(self, platform: Platform | None) -> None:
        """Set the platform this sensor is attached to.

        This method is called by Platform.add_sensor() and should not be
        called directly.

        Args:
            platform: The platform to attach to, or None to detach.
        """
        self._platform = platform

    # =========================================================================
    # FOV checking
    # =========================================================================

    def is_in_fov(self, emitter: Emitter, time: Time) -> bool:
        """Check if the emitter is within the sensor's field of view.

        Args:
            emitter: The emitter to check.
            time: Time instant for the check.

        Returns:
            True if emitter is within the sensor's FOV.

        Raises:
            RuntimeError: If sensor is not attached to a platform.
        """
        if self._platform is None:
            raise RuntimeError(
                f"Sensor '{self._sensor_id}' is not attached to a platform",
            )

        sensor_pos = self._platform.position_at(time)
        emitter_pos = emitter.position_at(time)
        return self._fov.is_visible(sensor_pos, emitter_pos)

    # =========================================================================
    # Atmosphere application helpers
    # =========================================================================

    def _is_ground_to_space(self, pos1: Pos, pos2: Pos) -> bool:
        """Check if the path between two positions crosses ground-to-space.

        Returns True if one position is "ground-ish" (below tropo ceiling)
        and the other is "space-ish" (above Kármán line).

        Args:
            pos1: First position.
            pos2: Second position.

        Returns:
            True if this is a ground-to-space (or space-to-ground) path.
        """
        alt1 = pos1.lla.alt_m
        alt2 = pos2.lla.alt_m

        low_alt = min(alt1, alt2)
        high_alt = max(alt1, alt2)

        ground_ish = low_alt < _TROPO_CEILING_M
        space_ish = high_alt > _SPACE_THRESHOLD_M

        return ground_ish and space_ish

    def _should_apply_atmosphere(
        self,
        collector_pos: Pos,
        emitter_pos: Pos,
    ) -> bool:
        """Determine if atmospheric corrections should be applied.

        Checks the sensor's apply_atmosphere setting and, for "auto" mode,
        evaluates the geometry to determine if the path crosses the atmosphere.

        Args:
            collector_pos: Position of the collector (receiver).
            emitter_pos: Position of the emitter (signal source).

        Returns:
            True if atmospheric corrections should be applied.
        """
        if self._apply_atmosphere is True:
            return True
        if self._apply_atmosphere is False:
            return False

        # "auto" mode - check geometry
        return self._is_ground_to_space(collector_pos, emitter_pos)

    # =========================================================================
    # Abstract methods - must be implemented by subclasses
    # =========================================================================

    @abstractmethod
    def can_observe(self, emitter: Emitter, time: Time) -> bool:
        """Check if the sensor can observe the emitter at this time.

        This includes FOV checks and any sensor-specific constraints
        (e.g., paired platform requirements for TDOA/FDOA).

        Args:
            emitter: The emitter to observe.
            time: Time instant for observation.

        Returns:
            True if observation is possible.
        """
        ...

    @abstractmethod
    def observe(
        self,
        emitter: Emitter,
        time: Time,
        *,
        add_noise: bool = True,
        atmosphere: AtmosphereConfig | None = None,
    ) -> Observation | None:
        """Generate an observation of the emitter.

        Args:
            emitter: The emitter to observe.
            time: Time instant for observation.
            add_noise: If True, add measurement noise. If False, return
                the ideal (noise-free) measurement.
            atmosphere: Optional atmospheric configuration for path delay
                corrections. If None, no atmospheric effects are applied.

        Returns:
            An Observation object, or None if the emitter is not observable.
        """
        ...

    # =========================================================================
    # Dunder methods
    # =========================================================================

    def __repr__(self) -> str:
        """Return string representation."""
        attached = self._platform.name if self._platform else "unattached"
        return f"{type(self).__name__}(id='{self._sensor_id}', platform='{attached}')"

    def __str__(self) -> str:
        """Return human-readable string."""
        return f"{type(self).__name__} '{self._sensor_id}'"
