"""Angle of Arrival (AOA) sensor using sensor-frame direction cosines.

An AOA sensor measures the direction from the sensor to an emitter,
expressed as direction cosines (u, v) in the sensor's local reference frame.
This is a single-platform measurement (no paired platform required).

The sensor frame orientation is determined automatically based on platform
altitude (nadir-pointing for space, ENU for ground) or can be explicitly set.

The measurement is a 2D vector [u, v] (direction cosines) with a 2x2
covariance matrix representing uncertainty in direction cosine space.
"""

from __future__ import annotations

import math
from typing import TYPE_CHECKING, Literal

import numpy as np
from gri_obs import AoaObs
from gri_utils.constants import ER_M
from gri_utils.conversion import get_aer, xyz_enu_rotation
from scipy.spatial.transform import Rotation

from gri_geosim.atmosphere import compute_atmospheric_correction

from .sensor import Sensor

if TYPE_CHECKING:
    from gri_nsepoch import Time
    from numpy.typing import NDArray

    from gri_geosim.atmosphere import AtmosphereConfig
    from gri_geosim.emitter import Emitter

    from .constraints import FovConstraint


# Elevation threshold for AOA atmospheric corrections (degrees)
# Below this elevation, atmospheric refraction becomes significant
_AOA_ELEVATION_THRESHOLD_DEG = 20.0

# Altitude threshold for automatic sensor orientation (meters)
# Above this altitude, sensor defaults to nadir-pointing
_SPACE_THRESHOLD_M = 100_000  # 100 km (Karman line)

# Numerical tolerance for near-zero vector magnitudes
_EPSILON = 1e-10


class AoaSensor(Sensor):
    """Angle of Arrival sensor using sensor-frame direction cosines.

    Measures the direction from sensor to emitter as direction cosines (u, v)
    in the sensor's local reference frame. The sensor orientation is:
    - Auto-detected based on altitude: nadir for space (>100km), ENU for ground
    - Or explicitly set via orientation parameter or custom rotation

    The noise model is Gaussian with independent azimuth and elevation
    standard deviations (applied in angle space, then transformed to
    direction cosine covariance).

    Attributes:
        azimuth_std_rad: Standard deviation of azimuth measurement (radians).
        elevation_std_rad: Standard deviation of elevation measurement (radians).
        orientation: Sensor orientation mode ("auto", "nadir", or "enu").

    Example:
        >>> from gri_pos import Pos
        >>> from gri_geosim import Platform
        >>> sensor = AoaSensor(
        ...     azimuth_std_rad=0.001,    # ~0.06 degrees
        ...     elevation_std_rad=0.001,
        ...     orientation="auto",        # nadir for space, ENU for ground
        ... )
        >>> ground = Platform.stationary(Pos.LLA(38.0, -77.0, 100.0))
        >>> ground.add_sensor(sensor)
    """

    __slots__ = (
        "_azimuth_std_rad",
        "_custom_rotation",
        "_elevation_std_rad",
        "_orientation",
    )

    _TYPE_PREFIX = "AOA"

    _orientation: Literal["auto", "nadir", "enu"]

    def __init__(  # noqa: PLR0913
        self,
        sensor_id: str | None = None,
        *,
        azimuth_std_rad: float = 0.001,
        elevation_std_rad: float = 0.001,
        orientation: Literal["auto", "nadir", "enu"] = "auto",
        sensor_rotation: Rotation | None = None,
        fov: FovConstraint | None = None,
        apply_atmosphere: Literal["auto"] | bool = "auto",
        rng_seed: int | None = None,
    ) -> None:
        """Initialize an AOA sensor.

        Args:
            sensor_id: Unique identifier for this sensor. If None, an ID
                is auto-generated (e.g., "AOA-1").
            azimuth_std_rad: Standard deviation of azimuth noise in radians.
                Defaults to 0.001 rad (~0.057 deg).
            elevation_std_rad: Standard deviation of elevation noise in radians.
                Defaults to 0.001 rad (~0.057 deg).
            orientation: Sensor orientation mode. Defaults to "auto".
                - "auto": Nadir for space platforms (>100km), ENU for ground
                - "nadir": Always nadir-pointing (+Z toward Earth center)
                - "enu": Always ENU frame (+X East, +Y North, +Z Up)
                Ignored if sensor_rotation is provided.
            sensor_rotation: Optional custom rotation from ECEF to sensor frame.
                If provided, overrides the orientation parameter.
            fov: Field of view constraint. Defaults to NoFov (no constraint).
            apply_atmosphere: Controls atmospheric correction application.
                - "auto": Apply for ground-to-space paths at low elevation (<20 deg)
                - True: Always apply if atmosphere config provided
                - False: Never apply atmospheric corrections
                Defaults to "auto".
            rng_seed: Optional seed for the random number generator.

        Raises:
            ValueError: If standard deviations are not positive.
        """
        super().__init__(
            sensor_id,
            fov=fov,
            apply_atmosphere=apply_atmosphere,
            rng_seed=rng_seed,
        )

        if azimuth_std_rad <= 0:
            msg = f"azimuth_std_rad must be positive, got {azimuth_std_rad}"
            raise ValueError(msg)
        if elevation_std_rad <= 0:
            msg = f"elevation_std_rad must be positive, got {elevation_std_rad}"
            raise ValueError(msg)

        self._azimuth_std_rad = azimuth_std_rad
        self._elevation_std_rad = elevation_std_rad
        self._orientation = orientation
        self._custom_rotation = sensor_rotation

    # =========================================================================
    # Properties
    # =========================================================================

    @property
    def azimuth_std_rad(self) -> float:
        """Standard deviation of azimuth measurement in radians."""
        return self._azimuth_std_rad

    @property
    def elevation_std_rad(self) -> float:
        """Standard deviation of elevation measurement in radians."""
        return self._elevation_std_rad

    @property
    def azimuth_std_deg(self) -> float:
        """Standard deviation of azimuth measurement in degrees."""
        return math.degrees(self._azimuth_std_rad)

    @property
    def elevation_std_deg(self) -> float:
        """Standard deviation of elevation measurement in degrees."""
        return math.degrees(self._elevation_std_rad)

    @property
    def orientation(self) -> Literal["auto", "nadir", "enu"]:
        """Sensor orientation mode."""
        return self._orientation

    # =========================================================================
    # Sensor orientation methods
    # =========================================================================

    def _get_sensor_rotation(
        self,
        collector_xyz: NDArray[np.floating],
    ) -> Rotation:
        """Compute the sensor rotation for the given collector position.

        Args:
            collector_xyz: Collector position in ECEF meters, shape (3,).

        Returns:
            Rotation from ECEF to sensor local frame.
        """
        if self._custom_rotation is not None:
            return self._custom_rotation

        if self._orientation == "enu":
            return self._compute_enu_rotation(collector_xyz)
        if self._orientation == "nadir":
            return self._compute_nadir_rotation(collector_xyz)

        # "auto" mode: determine based on altitude
        altitude_m = float(np.linalg.norm(collector_xyz)) - ER_M
        if altitude_m > _SPACE_THRESHOLD_M:
            return self._compute_nadir_rotation(collector_xyz)
        return self._compute_enu_rotation(collector_xyz)

    def _compute_enu_rotation(
        self,
        collector_xyz: NDArray[np.floating],
    ) -> Rotation:
        """Compute rotation from ECEF to ENU frame at collector position.

        ENU frame: +X East, +Y North, +Z Up

        Args:
            collector_xyz: Collector position in ECEF meters, shape (3,).

        Returns:
            Rotation from ECEF to ENU frame.
        """
        rot_matrix = xyz_enu_rotation(collector_xyz)
        return Rotation.from_matrix(rot_matrix)

    def _compute_nadir_rotation(
        self,
        collector_xyz: NDArray[np.floating],
    ) -> Rotation:
        """Compute rotation from ECEF to nadir-pointing sensor frame.

        Nadir frame: +Z toward Earth center, +X approximately East (cross-track)

        Args:
            collector_xyz: Collector position in ECEF meters, shape (3,).

        Returns:
            Rotation from ECEF to nadir-pointing frame.
        """
        # Nadir vector (toward Earth center, normalized)
        collector_norm = np.linalg.norm(collector_xyz)
        if collector_norm < _EPSILON:
            return Rotation.identity()

        z_axis = -collector_xyz / collector_norm  # +Z toward nadir

        # For +X, use approximate East direction (perpendicular to z in xy plane)
        # East at equator is [-y, x, 0] normalized
        east_approx = np.array([-collector_xyz[1], collector_xyz[0], 0.0])
        east_norm = np.linalg.norm(east_approx)

        if east_norm < _EPSILON:
            # At poles, East is ambiguous - use arbitrary horizontal direction
            east_approx = np.array([1.0, 0.0, 0.0])
            east_norm = 1.0

        # X axis: perpendicular to Z, approximately East
        # Project East onto plane perpendicular to Z, then normalize
        east_unit = east_approx / east_norm
        x_axis = east_unit - np.dot(east_unit, z_axis) * z_axis
        x_norm = np.linalg.norm(x_axis)
        x_axis = np.array([1.0, 0.0, 0.0]) if x_norm < _EPSILON else x_axis / x_norm

        # Y axis completes right-handed frame: Y = Z cross X
        y_axis = np.cross(z_axis, x_axis)

        # Build rotation matrix: columns are sensor axes expressed in ECEF
        # Rotation transforms from ECEF to sensor, so we need R such that
        # v_sensor = R @ v_ecef
        # The rows of R are the sensor axes expressed in ECEF
        rot_matrix = np.vstack([x_axis, y_axis, z_axis])
        return Rotation.from_matrix(rot_matrix)

    def _transform_covariance_to_direction_cosines(
        self,
        az: float,
        el: float,
    ) -> NDArray[np.floating]:
        """Transform angular covariance to direction cosine covariance.

        Uses the Jacobian of the (az, el) -> (u, v) transformation:
            u = cos(el) * sin(az)
            v = cos(el) * cos(az)

        The Jacobian becomes ill-conditioned near horizontal (el ≈ 0) and
        vertical (el ≈ ±90°) elevations. To ensure numerical stability,
        eigenvalue regularization is applied to maintain a minimum condition
        number.

        Args:
            az: Azimuth angle in radians (in sensor frame).
            el: Elevation angle in radians (in sensor frame).

        Returns:
            2x2 covariance matrix in direction cosine space, regularized
            to ensure numerical stability.
        """
        sin_az, cos_az = math.sin(az), math.cos(az)
        sin_el, cos_el = math.sin(el), math.cos(el)

        # Jacobian: J[i,j] = d(u,v)[i] / d(az,el)[j]
        # du/daz = cos(el) * cos(az)
        # du/del = -sin(el) * sin(az)
        # dv/daz = -cos(el) * sin(az)
        # dv/del = -sin(el) * cos(az)
        jacobian = np.array(
            [
                [cos_el * cos_az, -sin_el * sin_az],
                [-cos_el * sin_az, -sin_el * cos_az],
            ],
        )

        # Angular covariance (diagonal)
        cov_angle = np.array(
            [
                [self._azimuth_std_rad**2, 0.0],
                [0.0, self._elevation_std_rad**2],
            ],
        )

        # Transform: Cov_uv = J @ Cov_azel @ J.T
        cov_dc = jacobian @ cov_angle @ jacobian.T

        # Regularize to ensure numerical stability
        # The Jacobian is singular at el=0 and el=±90°, causing one eigenvalue
        # to approach zero. We enforce a minimum eigenvalue to maintain a
        # reasonable condition number (max_cond ≈ 20).
        min_variance = min(self._azimuth_std_rad**2, self._elevation_std_rad**2)
        min_eigenvalue = min_variance * 0.05  # 5% of smaller angular variance

        # Eigendecomposition for regularization
        eigvals, eigvecs = np.linalg.eigh(cov_dc)

        # Clamp small eigenvalues
        eigvals_reg = np.maximum(eigvals, min_eigenvalue)

        # Reconstruct covariance if regularization was needed
        if not np.allclose(eigvals, eigvals_reg):
            cov_dc = eigvecs @ np.diag(eigvals_reg) @ eigvecs.T

        return cov_dc

    # =========================================================================
    # Observation methods
    # =========================================================================

    def can_observe(self, emitter: Emitter, time: Time) -> bool:
        """Check if the sensor can observe the emitter at this time.

        Checks that the sensor is attached to a platform and that
        the emitter is within the sensor's field of view.

        Args:
            emitter: The emitter to observe.
            time: Time instant for observation.

        Returns:
            True if observation is possible.
        """
        if self._platform is None:
            return False
        return self.is_in_fov(emitter, time)

    def observe(
        self,
        emitter: Emitter,
        time: Time,
        *,
        add_noise: bool = True,
        atmosphere: AtmosphereConfig | None = None,
    ) -> AoaObs | None:
        """Generate an AOA observation of the emitter.

        Computes the direction cosines (u, v) from sensor to emitter in the
        sensor's local reference frame, optionally adding Gaussian noise
        and atmospheric corrections.

        Atmospheric corrections are applied in angle space before converting
        to direction cosines (matching the physics of ray bending).

        Args:
            emitter: The emitter to observe.
            time: Time instant for observation.
            add_noise: If True, add Gaussian measurement noise.
            atmosphere: Optional atmospheric configuration for angular
                corrections. If None, no atmospheric effects are applied.

        Returns:
            An AoaObs, or None if not observable.
        """
        if not self.can_observe(emitter, time):
            return None

        # Get positions
        sensor_pos = self._platform.position_at(time)  # ty: ignore[unresolved-attribute]
        emitter_pos = emitter.position_at(time)

        # Compute sensor rotation for this position
        sensor_rotation = self._get_sensor_rotation(sensor_pos.xyz)

        # Get true AER in ENU frame for atmospheric corrections and noise
        # (atmospheric effects are angular, applied in ENU frame)
        aer = get_aer(sensor_pos.xyz, emitter_pos.xyz)
        elevation_deg = aer[1]
        azimuth_rad = math.radians(aer[0])
        elevation_rad = math.radians(elevation_deg)

        # Apply atmospheric corrections if configured and appropriate
        if atmosphere is not None and (
            atmosphere.enable_tropo or atmosphere.enable_iono
        ):
            should_apply = self._should_apply_atmosphere(sensor_pos, emitter_pos)

            # In auto mode, also check elevation threshold
            if self._apply_atmosphere == "auto":
                should_apply = should_apply and (
                    elevation_deg < _AOA_ELEVATION_THRESHOLD_DEG
                )

            if should_apply:
                correction = compute_atmospheric_correction(
                    emitter_pos,
                    sensor_pos,
                    emitter.frequency_hz,
                    time,
                    atmosphere,
                )
                # Apply angular corrections to elevation (in ENU frame)
                total_angle_correction = (
                    correction.tropo_angle_rad + correction.iono_angle_rad
                )
                elevation_rad += total_angle_correction

        # Add noise in angle space if requested
        if add_noise:
            noise = self._rng.normal(
                0.0,
                [self._azimuth_std_rad, self._elevation_std_rad],
            )
            azimuth_rad += noise[0]
            elevation_rad += noise[1]

        # Normalize azimuth to [0, 2*pi)
        azimuth_rad = azimuth_rad % (2.0 * math.pi)

        # Convert corrected/noisy angles to direction cosines in ENU frame
        cos_el = math.cos(elevation_rad)
        sin_az = math.sin(azimuth_rad)
        cos_az = math.cos(azimuth_rad)
        sin_el = math.sin(elevation_rad)

        # ENU direction unit vector
        enu_unit = np.array([cos_el * sin_az, cos_el * cos_az, sin_el])

        # Get ENU rotation and transform to sensor frame
        enu_rotation = self._compute_enu_rotation(sensor_pos.xyz)
        # v_ecef = enu_rotation.inv() @ v_enu
        # v_sensor = sensor_rotation @ v_ecef
        # So: v_sensor = sensor_rotation @ enu_rotation.inv() @ v_enu
        combined_rotation = sensor_rotation * enu_rotation.inv()
        sensor_unit = combined_rotation.apply(enu_unit)

        # Extract direction cosines (u, v) and determine z_positive
        u = float(sensor_unit[0])
        v = float(sensor_unit[1])
        z_positive = sensor_unit[2] > 0

        # Compute direction cosines in sensor frame using angles for covariance
        # We need the angles in the sensor frame for proper Jacobian
        sensor_az = math.atan2(u, v)
        sensor_el = math.asin(np.clip(sensor_unit[2], -1.0, 1.0))

        # Transform covariance to direction cosine space
        covariance = self._transform_covariance_to_direction_cosines(
            sensor_az,
            sensor_el,
        )

        return AoaObs(
            time=time,
            u=u,
            v=v,
            covariance=covariance,
            collector=sensor_pos,
            collector_rotation=sensor_rotation,
            sensor_id=self._sensor_id,
            emitter_id=emitter.name if emitter.name else None,
            z_positive=z_positive,
        )

    # =========================================================================
    # Dunder methods
    # =========================================================================

    def __repr__(self) -> str:
        """Return string representation."""
        return (
            f"AoaSensor(id='{self._sensor_id}', "
            f"az_std={self.azimuth_std_deg:.4f} deg, "
            f"el_std={self.elevation_std_deg:.4f} deg, "
            f"orientation='{self._orientation}')"
        )

    def __str__(self) -> str:
        """Return human-readable string."""
        az = self.azimuth_std_deg
        el = self.elevation_std_deg
        return f"AOA Sensor '{self._sensor_id}' (az={az:.3f}deg, el={el:.3f}deg)"
