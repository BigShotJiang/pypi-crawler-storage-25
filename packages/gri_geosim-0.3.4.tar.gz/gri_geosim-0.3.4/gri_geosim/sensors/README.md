# GeoSim/Sensors

Sensor types for generating geolocation observations from simulated scenarios.

Each sensor attaches to a `Platform` and produces typed observations (AOA, TDOA, FDOA) when it can see an emitter. Sensors handle measurement physics, noise injection, atmospheric corrections, and field-of-view constraints.

## Import and Use

```python
from gri_geosim.sensors import AoaSensor, TdoaSensor, FdoaSensor
```

FOV constraints are also exported from the sensors package:

```python
from gri_geosim.sensors import ElevationMaskFov, ConeFov, EarthOcclusionFov, NoFov
```

## Module Overview

| Class | Purpose |
|-------|---------|
| `AoaSensor` | Angle of Arrival measurements (direction cosines from azimuth/elevation) |
| `TdoaSensor` | Time Difference of Arrival measurements (paired platforms) |
| `FdoaSensor` | Frequency Difference of Arrival measurements (Doppler-based, paired platforms) |
| `Sensor` | Abstract base class for all sensors |

## AoaSensor

Measures the direction to an emitter as direction cosines (u, v) with a 2x2 covariance matrix. Noise is specified as azimuth and elevation standard deviations in radians, then transformed to direction cosine space internally.

```python
from gri_geosim.sensors import AoaSensor, ElevationMaskFov

# Ground station AOA sensor with 1 mrad accuracy and 10-degree elevation mask
sensor = AoaSensor(
    "ground_aoa",
    azimuth_std_rad=0.001,
    elevation_std_rad=0.001,
    fov=ElevationMaskFov(min_elev_deg=10.0),
)
platform.add_sensor(sensor)
```

**Constructor parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `sensor_id` | `str \| None` | `None` | Unique identifier (auto-generated "AOA-N" if None) |
| `azimuth_std_rad` | `float` | `0.001` | Azimuth noise standard deviation in radians (~0.057 deg) |
| `elevation_std_rad` | `float` | `0.001` | Elevation noise standard deviation in radians (~0.057 deg) |
| `orientation` | `"auto" \| "nadir" \| "enu"` | `"auto"` | Sensor boresight orientation |
| `sensor_rotation` | `Rotation \| None` | `None` | Additional rotation applied to boresight frame |
| `fov` | `FovConstraint \| None` | `None` | Field-of-view constraint (None = no restriction) |
| `apply_atmosphere` | `"auto" \| bool` | `"auto"` | Atmospheric delay correction control |
| `rng_seed` | `int \| None` | `None` | Random seed for reproducible noise |

**Orientation modes:**

- `"auto"` (default): Nadir for platforms above 100 km altitude, ENU for ground/aircraft
- `"nadir"`: Boresight points toward Earth center (satellite sensors)
- `"enu"`: Boresight in East-North-Up frame (ground/aircraft sensors)

## TdoaSensor

Measures the time difference of arrival between two platforms observing the same emitter. Requires a paired platform set via `set_paired_platform()`.

```python
from gri_geosim.sensors import TdoaSensor

# 1 nanosecond timing accuracy
sensor = TdoaSensor("tdoa_pair", tdoa_std_s=1e-9)
platform1.add_sensor(sensor)
sensor.set_paired_platform(platform2)
```

**Constructor parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `sensor_id` | `str \| None` | `None` | Unique identifier (auto-generated "TDOA-N" if None) |
| `tdoa_std_s` | `float` | `1e-9` | Timing noise standard deviation in seconds (1 ns default) |
| `fov` | `FovConstraint \| None` | `None` | Field-of-view constraint |
| `apply_atmosphere` | `"auto" \| bool` | `"auto"` | Atmospheric delay correction control |
| `rng_seed` | `int \| None` | `None` | Random seed for reproducible noise |

**Properties:**

- `tdoa_std_s` -- Standard deviation in seconds
- `tdoa_std_ns` -- Standard deviation in nanoseconds

## FdoaSensor

Measures the Doppler shift difference between two platforms observing the same emitter. Requires a paired platform and uses the emitter's carrier frequency.

```python
from gri_geosim.sensors import FdoaSensor

# 0.1 Hz Doppler accuracy
sensor = FdoaSensor("fdoa_pair", fdoa_std_hz=0.1)
platform1.add_sensor(sensor)
sensor.set_paired_platform(platform2)
```

**Constructor parameters:**

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `sensor_id` | `str \| None` | `None` | Unique identifier (auto-generated "FDOA-N" if None) |
| `fdoa_std_hz` | `float` | `0.1` | Doppler noise standard deviation in Hz |
| `fov` | `FovConstraint \| None` | `None` | Field-of-view constraint |
| `apply_atmosphere` | `"auto" \| bool` | `"auto"` | Atmospheric delay correction (accepted but unused for FDOA) |
| `rng_seed` | `int \| None` | `None` | Random seed for reproducible noise |

## FOV Constraints

Pluggable visibility constraints implementing the `FovConstraint` protocol. All provide `is_visible(sensor_pos: Pos, emitter_pos: Pos) -> bool`.

| Constraint | Description |
|------------|-------------|
| `NoFov()` | No restriction -- always visible |
| `ConeFov(half_angle_deg)` | Conical FOV around nadir with given half-angle (0, 90] degrees |
| `ElevationMaskFov(min_elev_deg, max_elev_deg)` | Elevation angle bounds [-90, 90] degrees; auto-detects which entity is ground reference |
| `EarthOcclusionFov()` | Earth line-of-sight blockage check (WGS84 ellipsoid) |

```python
from gri_geosim.sensors import ConeFov, ElevationMaskFov, EarthOcclusionFov

# Satellite with 30-degree half-angle cone
sat_sensor = AoaSensor("sat_aoa", fov=ConeFov(half_angle_deg=30.0))

# Ground station with 10-90 degree elevation window
ground_sensor = AoaSensor("gnd_aoa", fov=ElevationMaskFov(min_elev_deg=10.0))

# Space-to-space with Earth blockage check
space_sensor = TdoaSensor("space_tdoa", fov=EarthOcclusionFov())
```

## Notes

- All sensors require a platform (attached via `platform.add_sensor(sensor)`).
- TDOA and FDOA sensors require a paired platform (`sensor.set_paired_platform(other)`). The primary platform hosts the sensor; the paired platform provides the second collection point.
- Sensor IDs are auto-generated with type prefixes (AOA-1, TDOA-2, FDOA-3) if not specified. Thread-safe counters ensure uniqueness.
- The `apply_atmosphere` parameter controls tropospheric/ionospheric corrections: `"auto"` enables them when both platforms are below 50 km and the emitter is above 20 degrees elevation.
- `rng_seed` makes noise injection reproducible for testing and Monte Carlo analysis.
