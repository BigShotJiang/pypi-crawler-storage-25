"""Sensor classes for observation generation.

This module provides sensor implementations for different observation types.
All sensors inherit from the Sensor abstract base class and implement
specific measurement physics.

Available sensors:
- AoaSensor: Angle of Arrival (azimuth/elevation)
- TdoaSensor: Time Difference of Arrival
- FdoaSensor: Frequency Difference of Arrival

FOV constraints for visibility (from sensors.constraints):
- NoFov: No constraint (always visible)
- ConeFov: Conical field of view
- ElevationMaskFov: Elevation angle constraints (auto-detects ground reference)
- EarthOcclusionFov: Earth line-of-sight blockage check

Example:
    >>> from gri_geosim.sensors import AoaSensor, TdoaSensor, ElevationMaskFov
    >>>
    >>> # AOA sensor with elevation mask
    >>> aoa = AoaSensor(
    ...     "ground_aoa",
    ...     azimuth_std_rad=0.001,
    ...     fov=ElevationMaskFov(min_elev_deg=10.0),
    ... )
    >>>
    >>> # TDOA sensor pair
    >>> tdoa = TdoaSensor("tdoa_12", tdoa_std_s=1e-9)
"""

from .aoa import AoaSensor
from .constraints import (
    ConeFov,
    EarthOcclusionFov,
    ElevationMaskFov,
    FovConstraint,
    NoFov,
)
from .fdoa import FdoaSensor
from .sensor import Sensor
from .tdoa import TdoaSensor

__all__ = [
    "AoaSensor",
    "ConeFov",
    "EarthOcclusionFov",
    "ElevationMaskFov",
    "FdoaSensor",
    "FovConstraint",
    "NoFov",
    "Sensor",
    "TdoaSensor",
]
