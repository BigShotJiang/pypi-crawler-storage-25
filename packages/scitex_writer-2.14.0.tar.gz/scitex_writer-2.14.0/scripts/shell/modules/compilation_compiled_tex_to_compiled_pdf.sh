#!/bin/bash
# -*- coding: utf-8 -*-
# Timestamp: "2025-11-11 23:18:00 (ywatanabe)"
# File: ./scripts/shell/modules/compilation_compiled_tex_to_compiled_pdf.sh
# Main compilation orchestrator - delegates to engine-specific modules

# shellcheck disable=SC2034  # ORIG_DIR exported from standard module header
ORIG_DIR="$(pwd)"
THIS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ENGINES_DIR="${THIS_DIR}/engines"
LOG_PATH="$THIS_DIR/.$(basename "$0").log"
echo >"$LOG_PATH"

# shellcheck disable=SC2034  # GIT_ROOT exported from standard module header
GIT_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)"

GRAY='\033[0;90m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo_info() { echo -e "${GRAY}INFO: $1${NC}"; }
log_info() {
    if [ "${SCITEX_LOG_LEVEL:-1}" -ge 2 ]; then
        echo -e "  \033[0;90m→ $1\033[0m"
    fi
}
echo_success() { echo -e "${GREEN}SUCC: $1${NC}"; }
echo_warning() { echo -e "${YELLOW}WARN: $1${NC}"; }
echo_error() { echo -e "${RED}ERRO: $1${NC}"; }
echo_header() { echo_info "=== $1 ==="; }
# ---------------------------------------

# Configurations
# shellcheck source=/dev/null
source ./config/load_config.sh "$SCITEX_WRITER_DOC_TYPE"

# Source engine implementations (use absolute paths to avoid directory confusion)
# shellcheck source=/dev/null
source "${ENGINES_DIR}/compile_tectonic.sh"
# shellcheck source=/dev/null
source "${ENGINES_DIR}/compile_latexmk.sh"
# shellcheck source=/dev/null
source "${ENGINES_DIR}/compile_3pass.sh"

# Logging
touch "$LOG_PATH" >/dev/null 2>&1
echo
log_info "Running $0 ..."

compiled_tex_to_pdf() {
    log_info "    Converting $SCITEX_WRITER_COMPILED_TEX to PDF..."

    local tex_file="$SCITEX_WRITER_COMPILED_TEX"
    local engine="${SCITEX_WRITER_SELECTED_ENGINE:-3pass}"

    log_info "    Selected engine: $engine"

    # Dispatch to engine-specific implementation
    case "$engine" in
    tectonic)
        compile_with_tectonic "$tex_file"
        ;;
    latexmk)
        compile_with_latexmk "$tex_file"
        ;;
    3pass)
        compile_with_3pass "$tex_file"
        ;;
    *)
        echo_error "    Unknown compilation engine: $engine"
        echo_info "    Falling back to 3-pass compilation"
        compile_with_3pass "$tex_file"
        ;;
    esac

    local ret=$?

    # If compilation failed in auto mode, try next engine
    if [ $ret -eq 2 ] && [ "$SCITEX_WRITER_ENGINE" = "auto" ]; then
        echo_warning "    Engine '$engine' failed, trying fallback..."
        # Note: Fallback logic handled by compile_manuscript.sh
        # This is just a placeholder for future enhancement
    fi

    return $ret
}

cleanup() {
    local compile_result=${1:-1}

    # Use fallback if SCITEX_WRITER_COMPILED_PDF is not set or empty
    local pdf_file="${SCITEX_WRITER_COMPILED_PDF}"
    if [ -z "$pdf_file" ]; then
        pdf_file="./01_manuscript/manuscript.pdf"
    fi

    # PDF is generated in LOG_DIR, move to final location
    local pdf_basename
    pdf_basename=$(basename "$pdf_file")
    local pdf_in_logs="${LOG_DIR}/${pdf_basename}"

    if [ -f "$pdf_in_logs" ]; then
        # Move PDF from logs/ to final location
        mv "$pdf_in_logs" "$pdf_file"
        log_info "    Moved PDF: $pdf_in_logs -> $pdf_file"
    fi

    if [ "$compile_result" -ne 0 ]; then
        echo_error "    PDF compilation failed (exit code: $compile_result)"
        # Remove stale PDF from previous compilation to avoid false positive
        [ -f "$pdf_file" ] && rm -f "$pdf_file"
        return 1
    fi

    if [ -f "$pdf_file" ]; then
        local size
        size=$(du -h "$pdf_file" | cut -f1)
        echo_success "    $pdf_file ready (${size})"

        # Create/update stable symlink to latest archive version (prevents corruption during compilation)
        local latest_path="${SCITEX_WRITER_ROOT_DIR}/${SCITEX_WRITER_DOC_TYPE}-latest.pdf"

        # Find the latest archived version (highest version number).
        # Glob directly + filter _diff.pdf via bash so we avoid `ls | grep` (SC2010).
        local archive_dir="${SCITEX_WRITER_VERSIONS_DIR}"
        local latest_archive=""
        local _cand
        local _candidates=()
        for _cand in "$archive_dir"/"${SCITEX_WRITER_DOC_TYPE}"_v[0-9]*.pdf; do
            [ -e "$_cand" ] || continue
            case "$_cand" in *_diff.pdf) continue ;; esac
            _candidates+=("$_cand")
        done
        if [ ${#_candidates[@]} -gt 0 ]; then
            latest_archive=$(printf '%s\n' "${_candidates[@]}" | sort -V | tail -1)
        fi

        if [ -n "$latest_archive" ]; then
            # Create relative symlink to archive
            ln -sf "archive/$(basename "$latest_archive")" "$latest_path"
            echo_success "    Symlink updated: $latest_path -> archive/$(basename "$latest_archive")"
        else
            # User-confirmed fallback: current PDF if no archive exists yet
            ln -sf "$(basename "$pdf_file")" "$latest_path"
            echo_success "    Symlink updated: $latest_path -> $(basename "$pdf_file") (no archive yet)"
        fi
        # Note: For rsync, use -L flag to follow symlinks: rsync -avL ...

        sleep 1
    else
        echo_error "    $pdf_file was not created despite successful compilation"
        return 1
    fi
}

main() {
    compiled_tex_to_pdf
    local compile_result=$?
    cleanup "$compile_result"
}

main

# EOF
