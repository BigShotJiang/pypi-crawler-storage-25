#!/bin/bash
# -*- coding: utf-8 -*-
# Timestamp: "2025-09-26 10:52:54 (ywatanabe)"
# File: ./paper/scripts/shell/modules/count_words.sh

# shellcheck disable=SC2034  # ORIG_DIR exported from standard module header
ORIG_DIR="$(pwd)"
THIS_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
LOG_PATH="$THIS_DIR/.$(basename "$0").log"
echo >"$LOG_PATH"

# shellcheck disable=SC2034  # GIT_ROOT exported from standard module header
GIT_ROOT="$(git rev-parse --show-toplevel 2>/dev/null)"

GRAY='\033[0;90m'
GREEN='\033[0;32m'
YELLOW='\033[0;33m'
RED='\033[0;31m'
NC='\033[0m' # No Color

echo_info() { echo -e "${GRAY}INFO: $1${NC}"; }
log_info() {
    if [ "${SCITEX_LOG_LEVEL:-1}" -ge 2 ]; then
        echo -e "  \033[0;90m→ $1\033[0m"
    fi
}
echo_success() { echo -e "${GREEN}SUCC: $1${NC}"; }
echo_warning() { echo -e "${YELLOW}WARN: $1${NC}"; }
echo_error() { echo -e "${RED}ERRO: $1${NC}"; }
echo_header() { echo_info "=== $1 ==="; }
# ---------------------------------------

# Configurations
# shellcheck source=/dev/null
source ./config/load_config.sh "$SCITEX_WRITER_DOC_TYPE"

# Source the 00_shared command switching module
# shellcheck source=/dev/null
source "$(dirname "${BASH_SOURCE[0]}")/command_switching.src"

# Logging
touch "$LOG_PATH" >/dev/null 2>&1
echo
log_info "Running $0 ..."

init() {
    rm -f "$SCITEX_WRITER_WORDCOUNT_DIR"/*.txt
    mkdir -p "$SCITEX_WRITER_WORDCOUNT_DIR"
}

_count_elements() {
    local dir="$1"
    local pattern="$2"
    local output_file="$3"

    if [[ -n $(find "$dir" -maxdepth 1 -name "$pattern" 2>/dev/null) ]]; then
        # Count files matching pattern, excluding *_Header.tex and FINAL.tex.
        # Iterate via bash glob rather than `ls | grep` so filenames with
        # unusual characters still count correctly (SC2010).
        local _match
        local count=0
        shopt -s nullglob
        for _match in "$dir"/$pattern; do
            case "$(basename "$_match")" in
            *_Header.tex | FINAL.tex) continue ;;
            esac
            count=$((count + 1))
        done
        shopt -u nullglob
        echo "$count" >"$output_file"
    else
        echo "0" >"$output_file"
    fi
}

# Cache texcount command (resolved once, used multiple times)
TEXCOUNT_CMD=""

_count_words() {
    local input_file="$1"
    local output_file="$2"

    # Use cached command if available
    if [ -z "$TEXCOUNT_CMD" ]; then
        echo_error "    texcount not found"
        return 1
    fi

    eval "$TEXCOUNT_CMD \"$input_file\" -inc -1 -sum 2> >(grep -v 'gocryptfs not found' >&2)" >"$output_file"
}

count_tables() {
    _count_elements "$SCITEX_WRITER_TABLE_COMPILED_DIR" "[0-9]*.tex" "$SCITEX_WRITER_WORDCOUNT_DIR/table_count.txt"
}

count_figures() {
    _count_elements "$SCITEX_WRITER_FIGURE_COMPILED_DIR" "[0-9]*.tex" "$SCITEX_WRITER_WORDCOUNT_DIR/figure_count.txt"
}

count_IMRaD() {
    for section in abstract introduction methods results discussion; do
        local section_tex="$SCITEX_WRITER_ROOT_DIR/contents/$section.tex"
        if [ -e "$section_tex" ]; then
            _count_words "$section_tex" "$SCITEX_WRITER_WORDCOUNT_DIR/${section}_count.txt"
        else
            echo 0 >"$SCITEX_WRITER_WORDCOUNT_DIR/${section}_count.txt"
        fi
    done

    # Calculate IMRD total (only count sections that exist)
    local imrd_total=0
    for section in introduction methods results discussion; do
        if [ -f "$SCITEX_WRITER_WORDCOUNT_DIR/${section}_count.txt" ]; then
            local count
            count=$(cat "$SCITEX_WRITER_WORDCOUNT_DIR/${section}_count.txt" 2>/dev/null || echo 0)
            imrd_total=$((imrd_total + count))
        fi
    done
    echo "$imrd_total" >"$SCITEX_WRITER_WORDCOUNT_DIR/imrd_count.txt"
}

_fmt_number() {
    # Format number with comma separators (e.g., 1234 -> 1,234)
    # Portable: uses sed instead of locale-dependent printf %'d
    echo "$1" | sed -E ':a;s/([0-9])([0-9]{3})(,|$)/\1,\2\3/;ta'
}

display_counts() {
    local fig_count
    local tab_count
    local abs_count
    local imrd_count
    local intro_count
    local meth_count
    local res_count
    local disc_count
    fig_count=$(cat "$SCITEX_WRITER_WORDCOUNT_DIR/figure_count.txt" 2>/dev/null || echo 0)
    tab_count=$(cat "$SCITEX_WRITER_WORDCOUNT_DIR/table_count.txt" 2>/dev/null || echo 0)
    abs_count=$(cat "$SCITEX_WRITER_WORDCOUNT_DIR/abstract_count.txt" 2>/dev/null || echo 0)
    imrd_count=$(cat "$SCITEX_WRITER_WORDCOUNT_DIR/imrd_count.txt" 2>/dev/null || echo 0)
    intro_count=$(cat "$SCITEX_WRITER_WORDCOUNT_DIR/introduction_count.txt" 2>/dev/null || echo 0)
    meth_count=$(cat "$SCITEX_WRITER_WORDCOUNT_DIR/methods_count.txt" 2>/dev/null || echo 0)
    res_count=$(cat "$SCITEX_WRITER_WORDCOUNT_DIR/results_count.txt" 2>/dev/null || echo 0)
    disc_count=$(cat "$SCITEX_WRITER_WORDCOUNT_DIR/discussion_count.txt" 2>/dev/null || echo 0)

    echo_success "    Word counts updated:"

    # For supplementary, don't show abstract if it doesn't exist
    if [ "$SCITEX_WRITER_DOC_TYPE" = "supplementary" ]; then
        echo_success "      $fig_count figures, $tab_count tables"
        if [ "$abs_count" -gt 0 ]; then
            echo_success "      $(_fmt_number "$abs_count") words for abstract"
        fi
        if [ "$imrd_count" -gt 0 ]; then
            echo_success "      $(_fmt_number "$imrd_count") words for supplementary text"
        fi
    else
        echo_success "      $fig_count figures, $tab_count tables, $(_fmt_number "$abs_count") words for abstract, and $(_fmt_number "$imrd_count") words for main text ($(_fmt_number "$intro_count") for introduction, $(_fmt_number "$meth_count") for methods, $(_fmt_number "$res_count") for results, $(_fmt_number "$disc_count") for discussion)"
    fi
}

main() {
    # Resolve texcount command once at startup
    TEXCOUNT_CMD=$(get_cmd_texcount "$ORIG_DIR")

    if [ -z "$TEXCOUNT_CMD" ]; then
        echo_error "    texcount not found"
        return 1
    fi

    init
    count_tables
    count_figures
    count_IMRaD
    display_counts
}

main

# EOF
