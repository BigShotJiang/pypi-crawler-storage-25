# Core dataclasses tests
