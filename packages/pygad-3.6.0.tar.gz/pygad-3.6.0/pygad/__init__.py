from .pygad import * # Relative import.

__version__ = "3.6.0"
