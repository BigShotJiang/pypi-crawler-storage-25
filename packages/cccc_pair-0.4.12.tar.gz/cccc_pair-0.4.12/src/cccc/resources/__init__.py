"""Package resources for CCCC."""

