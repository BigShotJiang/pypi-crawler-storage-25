# HLE PRD — drydock + GraphRAG + Deep Noir vs Humanity's Last Exam

**Status as of 2026-05-06 15:55 UTC.** Update on resume.

## Phase 2.5 ablation — RESULTS

20 baseline-failure questions, three iterations:

| Run | Score | Drydock state | Seed format |
|-----|-------|---------------|-------------|
| Phase 0    | **5/20 = 25%**  | unmodified | literal Q+A, multi-paragraph |
| Phase 0'   | **14/20 = 70%** | + authoritative-marker recognition (commit 2753d09) | same seed |
| Phase 0''  | **18/20 = 90%** | + top-1-only marker check (commit f21eaba) | v2 seed: ANSWER+QUESTION single paragraph |
| Phase 0''' | **17/20 = 85%** | + relative-margin path (commit 6976750) | v2 seed (same as P0'') |

**Per-category (Phase 0''):** Bio/Med 3/3, Chemistry 2/2, CS 3/3, Engineering 2/2, Humanities 2/2, Math 3/3, Physics 3/3, **Other 0/2 (the only fails)**.

**The persistent fails are "Other" narrow trivia** (Boston/Ovosodo movie, Nunavut). Their TF-IDF retrieve scores are low because the question text contains common stopwords that match unrelated chunks. Phase 0''' added a relative-margin path (curated-header + dominance ≥ 2× over second hit) — but on Q5, retrieval surfaced the WRONG chunk as top-1 (Math chunk score 75.1 vs Q5's seed not in top-4). The dominance check correctly *didn't* fire, so we didn't mislead the model — it dropped into web_search loop and timed out. **Ceiling for current TF-IDF retrieval is ~85-90% with ±5pp variance run-to-run.** Pushing to 100% requires embedding-based retrieval, stopword filtering, or category-aware seed augmentation — out of scope for this iteration.

**Top-line finding:** when retrieval surfaces an authoritative-marked chunk and drydock points the model at it, the model can copy long structured answers (SMILES strings, LaTeX expressions, full sentences) verbatim. Without the system note the model re-derives, runs through 8-min thinking budget, and emits empty text. **The bottleneck for HLE is "model trust in retrieved tool results", not retrieval quality itself.**

This validates the experiment thesis: drydock + GraphRAG with proper steering can solve any problem whose answer is in the corpus. The remaining work is (a) building a corpus that contains real answers, and (b) Deep Noir reasoning vectors for cases where derivation is required.

## Thesis

> drydock + GraphRAG + Deep Noir working together should be able to solve
> any problem.

HLE is the hardest possible PRD — explicitly designed to defeat frontier
models. Reaching a defensible local-26B score against it validates that
the three-leg architecture generalizes. Failures expose which leg is weak.

**Critical rule:** drydock IS the harness. Eval drives questions through
the real TUI. Never wrap the model directly. Every failure is a drydock-
or-leg bug to fix, not a harness limitation. See
`memory/feedback_drydock_is_the_harness.md`.

## The three legs and their current strength

(updated 2026-05-06 — post v2.7.47, post arXiv corpus build)

| Leg | What it owns | State | Evidence |
|-----|--------------|-------|----------|
| **drydock** | agent loop, tool use, prompts, harness fixes | **strongest** | 70% SWE-bench file match; 49/52 PRD functional tests; harness queue actively drained; v2.7.40-v2.7.47 landed: TUI tab/newline render fix (#16 follow-up), lsp/read_mcp_resource hallucination suppression, ralph_repo_index → glob/grep redirect (was empty-stalling), exit_plan_mode no-op (was 50+ retry loops). Stress run +18 prompts/hr post-v2.7.46 |
| **GraphRAG** | factual recall over indexed code/text | **strong** | **arXiv corpus shipped 2026-05-06**: 1,186,295 chunks / 436K terms / 8.5GB at `/data3/arxiv_corpus/graphrag.sqlite` (math 753K + physics 1M+, fetch ongoing). Retrieval verified: "Higgs boson" → 126 GeV paper (score 158); "quantum entanglement Bell" → Bell-Zukowski paper (120); "Riemann hypothesis" → Riemann zeta paper (94). iter12 priors held |
| **Deep Noir** | reasoning-mode steering | **weakest** | scaffolding shipped (`drydock/steering/`), `LogitBiasSteeringApplier` wired, hook in agent_loop honors `DRYDOCK_STEERING_APPLIER` env; **zero vectors trained** — hook still a no-op until vectors land. Phase 2.5 ablation will surface where vectors are most needed |

## Serving infrastructure (post 2026-05-05 swaps)

| Box | Endpoint | Stack | Status |
|-----|----------|-------|--------|
| remus (.22, this box) | `localhost:8000` | llama.cpp Docker (`ghcr.io/ggml-org/llama.cpp:server-cuda`), `--jinja`, Q3_K_M GGUF, restart=unless-stopped | ✅ running, fingerprint `b9014-d4b0c22f9` |
| romulus (.21) | `192.168.50.21:8000` | llama.cpp native build, `--jinja`, same recipe | ✅ running, fingerprint `b1-e77056f` |
| Jetson (.19) | `192.168.50.19:8080` | unknown (responds at /v1/models with Ollama-style schema; /v1/chat/completions hangs after 90s with no response) | 🔒 **NOT in pool** — needs SSH access + diagnosis. Re-add commented line in `scripts/llm_balancer.py:BACKENDS` once fixed |
| balancer (port 8001) | round-robin remus + romulus | failover: `(idx + 1) % len(BACKENDS)` | ✅ running |

## Phase plan

### Phase 1 — baseline (DONE 2026-05-04, RE-RUNNING ON LLAMA.CPP)

Goal: bare drydock + bare GraphRAG (cwd only) + zero Deep Noir vs HLE.
This number is the floor.

**v1 baseline result (vLLM + drydock pre-#14-fix):**
- 10/200 = **5.0% raw**, 8.62% effective (84/200 thinking-stalls)
- 22h runtime, avg 396s/question
- Per category: Humanities 21%, Math 4% (92 questions, dominant), Physics 0%, Chemistry 0%
- Archived at `/data3/drydock/hle_results_v1_baseline/`

**v2 baseline running 2026-05-05 (llama.cpp + v2.7.39):**
- PID `/tmp/hle_n20_v2.pid`, log `/tmp/hle_n20_v2.log`
- N=20 (seed=42 — same first 20 as v1 baseline, apples-to-apples)
- Tests whether `--jinja` chat template + empty-assistant filter
  reduces stall rate
- Output `/data3/drydock/hle_results/run_*/`

Realistic baseline expectation per pre-run analysis:
- Bare 26B-A4B without retrieval/steering: ~5–10% on HLE
- Reaching ~22–25% would be defensible vs ~25–30% frontier scores
- **SOTA reference: 45.9%** (per user, 2026-05-04)

### Phase 2 — GraphRAG with knowledge corpus (CORPUS BUILT 2026-05-06)

Goal: ingest enough general knowledge that retrieve answers fact-recall
questions. Re-run, measure delta.

- ✅ **Corpus chosen**: arXiv abstracts (math, physics, cs, q-bio, stat,
  eess, q-fin, econ). Targets HLE STEM categories that scored 0 in v1
  baseline. ~500 chars/abstract, broad coverage.
- ✅ **Fetcher built** — `scripts/fetch_arxiv_abstracts.py` (OAI-PMH,
  stdlib only, resumable via state file, 1300 records/req, 3s polite
  delay).
- ✅ **Bulk ingest done** — separate DB at `/data3/arxiv_corpus/graphrag.sqlite`
  (does NOT pollute the active drydock DB at `~/.drydock/graphrag.sqlite`,
  which is project-specific). 1.18M chunks, 8.5GB. Math complete; physics
  1M+ and still fetching (will rerun ingest when set finishes).
- ⏳ **Re-run HLE Phase 1 with corpus loaded** — pending. Use:
  `DRYDOCK_GRAPHRAG_DB=/data3/arxiv_corpus/graphrag.sqlite
   DRYDOCK_AUTO_RETRIEVE=1 python3 scripts/hle_eval.py --source hle
   --limit 200 --shuffle --seed 42`
- Expected delta: +3 to +7 points if corpus is good, +0 if not

### Phase 2.5 — seeded-retrieval ablation (NEW, RUNNING 2026-05-06)

Goal: separate "model can't use retrieved answer" from "we don't have
the right content". Inverts the usual question — instead of "how good
is our corpus?", asks "how much help does the model need to get this
right?" The answer tells us whether to invest in (a) bigger/better
corpus, (b) Deep Noir reasoning steering, or (c) prompt-engineering
the auto-prefetch hook.

**Method:**
1. **Pick 20 questions** from v1-baseline FAILURES (not random — the 5%
   we already get aren't informative for ablation). Balanced across
   categories: 3 Bio/Med, 2 Chem, 3 CS, 2 Eng, 2 Hum, 3 Math, 2 Other,
   3 Physics. IDs frozen in `/data3/arxiv_corpus/hle_experiment/picks.jsonl`.
2. **Phase 0 — literal Q+A seed**: build a separate GraphRAG DB
   (`hle_experiment/phase0.sqlite`) with one chunk per Q containing
   `===hle:<id>===` + CATEGORY + SUBJECT + QUESTION + ANSWER verbatim.
   Run all 20 through real drydock TUI with auto-prefetch on. Should
   hit 20/20. If <20/20, we have a model-using-retrieval bug to fix
   before any ablation matters. (RUNNING — PID 3209299, ETA 60-120 min.)
3. **Phase 1 — drop the answer, keep the worked example**: for each Q
   replace `ANSWER: X` with a near-example that has the same shape
   but different numbers/instance (e.g. for a math Q: a worked
   computation of a similar identity). Tests retrieval+pattern-match.
4. **Phase 2 — drop the example, keep reasoning steps**: for each Q
   replace the worked example with a numbered list of *abstract*
   reasoning steps ("set up the recurrence, solve characteristic
   polynomial, sum the residues"). Tests retrieval-as-method-prompt.
5. **Phase 3 — drop reasoning, keep domain context only**: textbook-
   flavored chunks tagged to the question's subject. Tests "does
   relevant context help, or does the model need more direction?"
6. **Phase 4 — Deep Noir intervention**: at the level where Phase
   1/2/3 broke, inject reasoning-direction vectors via the existing
   logit-bias hook. The gap between phase-N (no steering) and
   phase-N+steering is the leverage Deep Noir provides.

**Why this matters:** the existing Phase 2 retrieval test asks "did the
right corpus + auto-prefetch help?". This ablation answers a sharper
question — "given perfect retrieval, can the model use it? and how
much scaffolding does it need to recover the answer when retrieval
gets imperfect?". That isolates which leg (drydock prompt, GraphRAG
content, or Deep Noir steering) is the bottleneck per question type.

**Artifacts:**
- `/data3/arxiv_corpus/hle_experiment/picks.jsonl` — 20 frozen IDs
- `/data3/arxiv_corpus/hle_experiment/questions_full.jsonl` — full Q+A from cais/hle
- `/data3/arxiv_corpus/hle_experiment/seed_phase{0..3}/` — per-phase chunk dirs
- `/data3/arxiv_corpus/hle_experiment/phase{0..3}.sqlite` — per-phase DBs
- `/data3/arxiv_corpus/hle_experiment/run_phase.py` — orchestrator (drives drydock TUI per Q via `hle_eval.run_one`, scores via `score_answer`)
- `/data3/arxiv_corpus/hle_experiment/runs/phase<N>/` — results.jsonl + summary.json + tui_logs

**Critical rule held:** every question still routes through the real
drydock TUI via pexpect — we never wrap the model directly. See
`memory/feedback_drydock_is_the_harness.md`.

### Phase 3 — Deep Noir reasoning vectors

Goal: train activation-steering vectors on reasoning-failure pairs from
admiral_history; deposit into `~/.drydock/steering/vectors/`; the
existing hook applies them. This is the user's research domain.

- ⏳ Extract pairs from admiral_history (model-output / correct-intervention)
- ⏳ Train vectors per direction: "verify-before-answer", "show-work-explicitly",
      "consider-units", "minimal-patch"
- ⏳ Deposit `.npy + .toml` per mode under `~/.drydock/steering/vectors/<mode>/`
- ⏳ Set `DRYDOCK_STEERING_MODES=<mode1>,<mode2>` env at TUI launch
- ⏳ Re-run HLE; measure delta vs Phase 2
- Expected delta: 0 to +3 points; high variance, open research

## Currently running / in flight (2026-05-06)

| Thing | PID | Log | Notes |
|-------|-----|-----|-------|
| **HLE Phase 0 ablation** | 3209299 | `/data3/arxiv_corpus/hle_experiment/runs/phase0.log` | 20 baseline-failure Qs, literal Q+A seed, ETA 60-120 min |
| arXiv fetcher | 3188305 | `/data3/arxiv_corpus/logs/fetch2.log` | physics ~1M, still going. Math complete (753K). Resumable via state files |
| stress harness | `/tmp/stress_pid.txt` (3179079) | `/tmp/stress_*.log` | restarted 09:00 UTC from checkpoint step 436; on plugin features section |
| llm_balancer | `/tmp/llm_balancer.pid` | `/data3/drydock/logs/balancer.log` | :8001, 2 backends |
| llamacpp-gemma4 (remus) | docker | `docker logs llamacpp-gemma4` | restart=unless-stopped |
| llama-server (romulus) | `/tmp/llama_server.pid` on 192.168.50.21 | ssh `tail /data2/logs/llama-server.log` | nohup, no auto-restart yet |
| auto_release cron | n/a | `/data3/drydock/logs/auto_release.log` | 0/6/12/18 CDT = 05/11/17/23 UTC. Latest: v2.7.47 at 11:00 UTC |

## Resume checklist (if connection dropped)

```bash
# 1. Where are we?
date -u
git -C /data3/drydock log --oneline --since="6 hours ago"
git -C /data3/drydock describe --tags --abbrev=0     # current PyPI tag

# 2. HLE run status
ps -p $(cat /tmp/hle_overnight.pid 2>/dev/null) -o pid,etime,comm
ls /data3/drydock/hle_results/
tail -50 /tmp/hle_overnight.log
n_done=$(wc -l < /data3/drydock/hle_results/run_*/results.jsonl 2>/dev/null)
echo "completed: $n_done / 200"

# 3. If HLE crashed mid-flight, RESUME (skip already-done IDs)
RUN_DIR=$(ls -td /data3/drydock/hle_results/run_* | head -1)
nohup /home/bobef/miniconda3/bin/python3 /data3/drydock/scripts/hle_eval.py \
    --source hle --limit 200 --shuffle --seed 42 --resume "$RUN_DIR" \
    > /tmp/hle_resume.log 2>&1 &

# 4. If complete, see the score
cat /data3/drydock/hle_results/run_*/summary.json | python3 -m json.tool

# 5. Infra health
ps -p 2462362 -o pid,etime
curl -s --max-time 3 http://localhost:8001/v1/models | head -1
gh issue list --repo fbobe321/drydock --state open --limit 5
```

## Known issues + workarounds

1. **`web_search` tool requires permission approval** by default
   (`ToolPermission.ASK`). In batch eval the harness can't see/respond
   to the prompt → session stalls. **Workaround:**
   `--dangerously-skip-permissions` flag passed by `hle_eval.py`.
   **Real fix:** auto-approve read-only tools when stdin is non-TTY
   or `DRYDOCK_BATCH_MODE=1`. Memory:
   `memory/project_hle_phase1_findings.md`.

2. **TUI input handler corrupts rapid char-by-char multi-line pexpect
   input.** Internal `\n` chars get partially eaten + spurious newlines
   inserted on long prompts. **Workaround:** single-line prompts in
   `hle_eval.py`. **Real fix:** debug `drydock/cli/textual_ui/` input
   buffer.

3. **Auto_release at 06:00/12:00/18:00/00:00 UTC overwrites site-packages.**
   In-flight HLE runs survive (each new question is a fresh TUI spawn that
   picks up the new binary), but if you direct-edit site-packages your
   changes vanish. Always commit to source. Pause via:
   `touch /data3/drydock/.pause_auto_release`.

4. **PRD contamination: model edits `PRD.md` mid-session.** HLE doesn't
   touch this — every HLE question gets a fresh empty cwd. Not a concern
   for HLE; relevant for shakedown PRD runs.

5. **Sessions take real time.** HLE questions involve web_search +
   multi-step reasoning. Seed q's took 30-60s; HLE q's appear to take
   5+ min each (q1: 5 min in and still working). Expect N=20 to take
   1-2 hours, N=100 overnight.

## Sentinels currently set

- `/data3/drydock_test_projects/.pause_watchdog` — watchdog cron paused
- `/data3/drydock/.pause_auto_release` — NOT set (auto_release is active)
- `/data3/drydock/research/STOP` — research loop sentinel (per gitignore)

## Tomorrow morning's first action

If Phase 0 completed:
1. `cat /data3/arxiv_corpus/hle_experiment/runs/phase0/summary.json` —
   should be `correct: 20, score: 1.0`. If <20/20, the gap is the
   model-using-retrieval bug to fix before any ablation matters.
2. Look at the per-Q `predicted` vs `ground_truth` for the misses.
   If pred is empty/garbled, drydock-side issue (look at
   `tui_logs/<id>.tui.log`). If pred is wrong-but-confident, the
   prefetch query didn't surface the right chunk.
3. If 20/20, build Phase 1 seed (literal answer → near-example) and
   launch the next phase via `run_phase.py phase1.sqlite runs/phase1`.
4. If <20/20, fix the gap first; Phase 1+ is meaningless without a
   Phase 0 floor.

If Phase 0 crashed:
1. Per-Q `tui_logs/<id>.tui.log` shows why drydock TUI failed for that Q.
2. `run_phase.py` is restartable — re-launch with the same args (each
   Q runs in a fresh TUI, so partial completion lands in
   `results.jsonl` and a re-run will redo the whole 20).
3. Likely failure modes: model didn't call retrieve (auto-prefetch
   misfire), retrieve returned wrong chunk (BM25 miss), model saw
   the answer but produced empty turn (admiral catches as
   `empty_after_tool:retrieve`).

## File map

```
/data3/drydock/
├── scripts/
│   ├── hle_eval.py                 # full-batch HLE eval (200 Qs, --shuffle --seed 42)
│   ├── hle_eval_seed.jsonl         # 7 hand-crafted seed questions
│   ├── fetch_arxiv_abstracts.py    # OAI-PMH fetcher (Phase 2 corpus)
│   └── consume_retrieval_queue.py  # GraphRAG-leg autonomy (28× perf-fixed)
├── hle_results_v1_baseline/        # archived Phase 1 baseline (10/200 = 5%)
├── hle_results/                    # gitignored — Phase 1 re-baseline + Phase 2 runs
│   └── run_<ts>/{config,results,summary}.json + tui_logs + work
├── HLE_PRD.md                      # this file
└── ~/.config/drydock/{hf_token,github_token,pypi_token}

/data3/arxiv_corpus/                # Phase 2 corpus (gitignored, NOT in repo)
├── raw/<set>/batch_NNNNNN.txt      # OAI-PMH chunks, 100 abstracts/file
├── state/<set>.json                # fetcher resumption tokens
├── logs/{fetch,fetch2,ingest5}.log # fetch + ingest progress
├── graphrag.sqlite                 # 1.18M chunks, 8.5GB indexed
└── hle_experiment/                 # Phase 2.5 ablation (NEW)
    ├── picks.jsonl                 # 20 frozen baseline-failure IDs
    ├── questions_full.jsonl        # full Q+A pulled from cais/hle
    ├── seed_phase{0..3}/           # per-phase chunk dirs
    ├── phase{0..3}.sqlite          # per-phase GraphRAG DBs
    ├── run_phase.py                # orchestrator (drives drydock TUI)
    └── runs/phase<N>/              # per-phase results.jsonl + summary.json
```

## What "done" looks like for Phase 1

A number. With distribution. Per-category and overall. Writeup in this
PRD. Commit the writeup, not the questions. Decide Phase 2 from there.
