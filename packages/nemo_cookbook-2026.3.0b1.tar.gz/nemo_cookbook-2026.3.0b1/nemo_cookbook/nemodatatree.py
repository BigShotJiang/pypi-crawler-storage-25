"""
nemodatatree.py

Description:
This module defines the NEMODataTree class, a hierarchical data structure
for analysing NEMO ocean general circulation outputs defining one or more
model domains.

Author:
Ollie Tooth (oliver.tooth@noc.ac.uk)
"""

from typing import Self

import dask
import numpy as np
import xarray as xr
from xarray.indexes import NDPointIndex
from xoak import SklearnGeoBallTreeAdapter

from nemo_cookbook.extract import (
    create_boundary_dataset,
    create_section_polygon,
    get_section_indexes,
    update_boundary_dataset,
)
from nemo_cookbook.integrate import compute_depth_integral
from nemo_cookbook.interpolate import interpolate_grid
from nemo_cookbook.masks import create_polygon_mask, get_mask_boundary
from nemo_cookbook.nemodataarray import NEMODataArray
from nemo_cookbook.processing import create_datatree_dict
from nemo_cookbook.stats import compute_binned_statistic
from nemo_cookbook.transform import transform_vertical_coords
from nemo_cookbook.utils import deprecated


class NEMODataTree(xr.DataTree):
    """
    Hierarchical data structure containing collections of NEMO ocean model outputs.

    This class extends `xarray.DataTree` to provide methods for processing
    and analysing NEMO output xarray objects defining one or more model domains.

    It supports NEMO discrete scalar and vector operators such as computing gradients,
    divergence, curl, weighted averages, integrals, cumulative integrals, and
    transforming variables between grids.
    """

    def __init__(self, *args, **kwargs):
        """
        Create a single node of a NEMODataTree.

        The node may optionally contain data in the form of data
        and coordinate variables, stored in the same way as data
        is stored in an `xarray.Dataset`.

        Parameters
        ----------
        *args : tuple
            Positional arguments to pass to the parent class.
        **kwargs : dict
            Keyword arguments to pass to the parent class.
        """
        super().__init__(*args, **kwargs)

    @classmethod
    def from_paths(
        cls,
        paths: dict[str, str],
        nests: dict[str, str] | None = None,
        name : str = "NEMO model",
        iperio: bool = False,
        nftype: str | None = None,
        read_mask: bool = False,
        key_linssh: bool = False,
        nbghost_child: int = 4,
        **open_kwargs: dict[str, any],
    ) -> Self:
        """
        Create a NEMODataTree from a dictionary of paths to NEMO model output files,
        organised into a hierarchy of domains (i.e., 'parent', 'child', 'grandchild').

        Parameters
        ----------
        paths : dict[str, str]
            Dictionary containing paths to NEMO grid files, structured as:
            {
                'parent': {'domain': 'path/to/domain.nc',
                           'gridT': 'path/to/gridT.nc',
                            , ... ,
                            'icemod': 'path/to/icemod.nc',
                            },
                'child': {'1': {'domain': 'path/to/child_domain.nc',
                                'gridT': 'path/to/child_gridT.nc',
                                , ... ,
                                'icemod': 'path/to/child_icemod.nc',
                                },
                          },
                'grandchild': {'2': {'domain': 'path/to/grandchild_domain.nc',
                                     'gridT': 'path/to/grandchild_gridT.nc',
                                     , ...,
                                     'icemod': 'path/to/grandchild_icemod.nc',
                                     },
                               }
            }

        nests : dict[str, str], optional
            Dictionary describing the properties of nested domains, structured as:
            {
                "1": {
                    "parent": "/",
                    "rx": rx,
                    "ry": ry,
                    "imin": imin,
                    "imax": imax,
                    "jmin": jmin,
                    "jmax": jmax,
                    "iperio": iperio,
                    },
            }
            where `rx` and `ry` are the horizontal refinement factors, and `imin`, `imax`, `jmin`, `jmax`
            define the indices of the child (grandchild) domain within the parent (child) domain. Zonally
            periodic nested domains should be specified with `iperio=True`.

        name: str, optional
            Name of the NEMODataTree. Default is "NEMO model".

        iperio: bool = False
            Zonal periodicity of the parent domain. Default is False.

        nftype: str, optional
            Type of north fold lateral boundary condition to apply. Options are 'T' for T-point pivot or 'F' for F-point
            pivot. By default, no north fold lateral boundary condition is applied (None).

        read_mask: bool = False
            If True, read NEMO model land/sea mask from domain files. Default is False, meaning masks are computed from top_level and bottom_level domain variables.

        key_linssh: bool = False
            Linear free-surface approximation. If True, vertical coordinates are time-independent and given by (e3t_0, e3u_0, e3v_0, e3w_0) in domain_cfg.
            If False, vertical coordinates are time-dependent and must be specified in NEMO model grid datasets. Default is False.

        nbghost_child : int = 4
            Number of ghost cells to remove from the western/southern boundaries of the (grand)child domains. Default is 4.

        **open_kwargs : dict, optional
            Additional keyword arguments to pass to `xarray.open_dataset` or `xr.open_mfdataset` when opening NEMO model output files.
        Returns
        -------
        NEMODataTree
            A hierarchical DataTree storing NEMO model outputs.

        Examples
        --------
        Create a zonally periodic `NEMODataTree` from a dictionary of paths to local netCDF files:

        >>> from nemo_cookbook import NEMODataTree

        >>> paths = {"parent": {
        ...          "domain": "/path/to/domain_cfg.nc",
        ...          "gridT": "path/to/*_gridT.nc",
        ...          "gridU": "path/to/*_gridV.nc",
        ...          "gridV": "path/to/*_gridV.nc",
        ...          "gridW": "path/to/*_gridW.nc",
        ...          "icemod": "path/to/*_icemod.nc",
        ...          }}

        >>> nemo = NEMODataTree.from_paths(paths, name="My NEMO model", iperio=True, nftype="T")

        Create a regional `NEMODataTree` using a linear free-surface approximation from a dictionary of paths to remote netCDF files:

        >>> nemo = NEMODataTree.from_paths(paths, name="My NEMO model", iperio=False, nftype=None, key_linssh=True)

        See Also
        --------
        from_datasets
        """
        # -- Validate Inputs -- #
        if not isinstance(paths, dict):
            raise TypeError("`paths` must be a dictionary or nested dictionary.")
        if not isinstance(nests, (dict, type(None))):
            raise TypeError("`nests` must be a dictionary or None.")
        if not isinstance(name, str):
            raise TypeError("`name` must be a string.")
        if not isinstance(iperio, bool):
            raise TypeError("zonal periodicity (`iperio`) of parent domain must be a boolean.")
        if nftype is not None and nftype not in ("T", "F"):
            raise ValueError(
                "north fold type (`nftype`) of parent domain must be 'T' (T-pivot fold), 'F' (F-pivot fold), or None."
            )
        if not isinstance(read_mask, bool):
            raise TypeError("`read_mask` must be a boolean.")
        if not isinstance(key_linssh, bool):
            raise TypeError("linear free-surface approximation (`key_linssh`) must be a boolean.")
        if not isinstance(nbghost_child, int):
            raise TypeError(
                "number of ghost cells along the western/southern boundaries (`nbghost_child`) must be an integer."
            )
        if not isinstance(open_kwargs, dict):
            raise TypeError("`open_kwargs` must be a dictionary.")

        # Define parent, child, grandchild filepath collections:
        d_child, d_grandchild = None, None
        if "parent" in paths.keys() and isinstance(paths["parent"], dict):
            for key in paths.keys():
                if key not in ("parent", "child", "grandchild"):
                    raise KeyError(f"Unexpected key '{key}' in `paths` dictionary.")
                if key == "parent":
                    d_parent = paths["parent"]
                elif key == "child":
                    if nests is None:
                        raise ValueError(
                            "`nests` dictionary must be provided when defining NEMO child domains."
                        )
                    else:
                        d_child = paths["child"]
                elif key == "grandchild":
                    d_grandchild = paths["grandchild"]
        else:
            raise ValueError(
                "Invalid `paths` structure. Expected a nested dictionary defining NEMO 'parent', 'child' and 'grandchild' domains."
            )

        # Construct DataTree from parent / child / grandchild domains:
        d_tree = create_datatree_dict(
            d_parent=d_parent,
            d_child=d_child,
            d_grandchild=d_grandchild,
            nests=nests,
            iperio=iperio,
            nftype=nftype,
            read_mask=read_mask,
            nbghost_child=nbghost_child,
            key_linssh=key_linssh,
            open_kwargs=dict(**open_kwargs),
        )

        datatree = super().from_dict(d_tree)
        datatree.name = name

        return datatree

    @classmethod
    def from_datasets(
        cls,
        datasets: dict[str, dict[str, xr.Dataset]],
        nests: dict[str, dict[str, str]] | None = None,
        name : str = "NEMO model",
        iperio: bool = False,
        nftype: str | None = None,
        read_mask: bool = False,
        key_linssh: bool = False,
        nbghost_child: int = 4,
    ) -> Self:
        """
        Create a NEMODataTree from a dictionary of `xarray.Dataset` objects created from NEMO model output files,
        organised into a hierarchy of domains (i.e., 'parent', 'child', 'grandchild').

        Parameters
        ----------
        datasets : dict[str, dict[str, xr.Dataset]]
            Dictionary containing `xarray.Datasets` created from NEMO grid files, structured as:
            {
                'parent': {'domain': ds_domain, 'gridT': ds_gridT, ... , 'icemod': ds_icemod.nc},
                'child': {'1': {'domain': ds_domain_1, 'gridT': d_gridT_1, ...}},
                'grandchild': {'2': {'domain': ds_domain_2, 'gridT': ds_gridT_2, ...}}
            }

        nests : dict[str, dict[str, str]], optional
            Dictionary describing the properties of nested domains, structured as:
            {
                "1": {
                    "parent": "/",
                    "rx": rx,
                    "ry": ry,
                    "imin": imin,
                    "imax": imax,
                    "jmin": jmin,
                    "jmax": jmax,
                    },
            }
            where `rx` and `ry` are the horizontal refinement factors, and `imin`, `imax`, `jmin`, `jmax`
            define the indices of the child (grandchild) domain within the parent (child) domain.

        name: str, optional
            Name of the NEMODataTree. Default is "NEMO model".

        iperio: bool = False
            Zonal periodicity of the parent domain.

        nftype: str, optional
            Type of north fold lateral boundary condition to apply. Options are 'T' for T-point pivot or 'F' for F-point
            pivot. By default, no north fold lateral boundary condition is applied (None).

        read_mask: bool = False
            If True, read NEMO model land/sea mask from domain files. Default is False, meaning masks are computed from top_level and bottom_level domain variables.

        key_linssh: bool = False
            Linear free-surface approximation. If True, vertical coordinates are time-independent and given by (e3t_0, e3u_0, e3v_0, e3w_0) in domain_cfg.
            If False, vertical coordinates are time-dependent and must be specified in NEMO model grid datasets. Default is False.

        nbghost_child : int = 4
            Number of ghost cells to remove from the western/southern boundaries of the (grand)child domains. Default is 4.

        Returns
        -------
        NEMODataTree
            Hierarchical DataTree of NEMO model outputs.

        Examples
        --------
        Create a `NEMODataTree` from a dictionary of xarray.Dataset objects:

        >>> import xarray as xr
        >>> from nemo_cookbook import NEMODataTree

        >>> ds_domain = xr.open_zarr("https://some_remote_data/domain_cfg.zarr")
        >>> ds_gridT = xr.open_zarr("https://some_remote_data/my_model_gridT.zarr")

        >>> datasets = {"parent": {"domain": ds_domain, "gridT": ds_gridT}}

        >>> nemo = NEMODataTree.from_datasets(datasets=datasets, name="My NEMO Model", iperio=True, nftype="T")

        Create a regional `NEMODataTree` using a linear free-surface approximation from a dictionary of xarray.Dataset objects:

        >>> nemo = NEMODataTree.from_datasets(datasets=datasets, name="My NEMO Model", iperio=False, nftype=None, key_linssh=True)

        See Also
        --------
        from_paths
        """
        # -- Validate Inputs -- #
        if not isinstance(datasets, dict):
            raise TypeError("`datasets` must be a dictionary or nested dictionary.")
        if not isinstance(nests, (dict, type(None))):
            raise TypeError("`nests` must be a dictionary or None.")
        if not isinstance(name, str):
            raise TypeError("`name` must be a string.")
        if not isinstance(iperio, bool):
            raise TypeError("zonal periodicity (`iperio`) of parent domain must be a boolean.")
        if nftype is not None and nftype not in ("T", "F"):
            raise ValueError(
                "north fold type (`nftype`) of parent domain must be 'T' (T-pivot fold), 'F' (F-pivot fold), or None."
            )
        if not isinstance(read_mask, bool):
            raise TypeError("`read_mask` must be a boolean.")
        if not isinstance(key_linssh, bool):
            raise TypeError("linear free-surface approximation (`key_linssh`) must be a boolean.")
        if not isinstance(nbghost_child, int):
            raise TypeError(
                "number of ghost cells along the western/southern boundaries (`nbghost_child`) must be an integer."
            )

        # Define parent, child, grandchild dataset collections:
        d_child, d_grandchild = None, None
        if "parent" in datasets.keys() and isinstance(datasets["parent"], dict):
            for key in datasets.keys():
                if key not in ("parent", "child", "grandchild"):
                    raise KeyError(f"Unexpected key '{key}' in `datasets` dictionary.")
                if key == "parent":
                    d_parent = datasets["parent"]
                elif key == "child":
                    if nests is None:
                        raise ValueError(
                            "`nests` dictionary must be provided when defining NEMO child domains."
                        )
                    else:
                        d_child = datasets["child"]
                elif key == "grandchild":
                    d_grandchild = datasets["grandchild"]
        else:
            raise ValueError(
                "Invalid `datasets` structure. Expected a nested dictionary defining NEMO 'parent', 'child' and 'grandchild' domains."
            )

        # Construct DataTree from parent / child / grandchild domains:
        d_tree = create_datatree_dict(
            d_parent=d_parent,
            d_child=d_child,
            d_grandchild=d_grandchild,
            nests=nests,
            iperio=iperio,
            nftype=nftype,
            read_mask=read_mask,
            key_linssh=key_linssh,
            nbghost_child=nbghost_child,
        )

        datatree = super().from_dict(d_tree)
        datatree.name = name

        return datatree
    
    def __setitem__(
            self,
            key: str,
            value: NEMODataArray | xr.DataArray | xr.Dataset,
            validate: bool = True
        ) -> None:
        """
        Set a child node or variable in this NEMODataTree.

        Overloads the __setitem__() method of xarray.DataTree to allow
        setting NEMODataArrays via variable paths (i.e, /grid/var).

        Validate option used for testing only.

        Parameters
        ----------
        key : str
            Name of variable or child node, or unix-like path to variable
            within a child node.

        value : NEMODataArray | xarray.DataArray | xarray.Dataset
            Object to set at the specified key. If a NEMODataArray is provided,
            the underlying xarray.DataArray will be set at the specified key.

        validate : bool, optional
            Validate Datasets assigned to NEMO grid nodes to ensure they contain
            the required dimensions and coordinates. Default is True.

        Returns
        -------
        None
        """
        # -- Access DataArray from NEMODataArray -- #
        if isinstance(value, NEMODataArray):
            value = value.data

        if validate & isinstance(value, xr.Dataset):
            # Define suffix NEMO grid node:
            grid_type = key[-1].lower()
            hgrid_type = grid_type if "w" not in grid_type else "t"

            # -- Verify coordinates of NEMO grid node dataset -- #
            if any([coord not in value.coords for coord in ["i", "j"]]):
                raise ValueError("Missing required NEMO grid coordinates (i, j) in xarray.Dataset.")

            if all([f'gphi{hgrid_type}' not in coord for coord in value.coords]):
                raise ValueError(f"Missing required latitude (e.g., gphi{hgrid_type}) coordinates in xarray.Dataset.")

            if all([f'glam{hgrid_type}' not in coord for coord in value.coords]):
                raise ValueError(f"Missing required longitude (e.g., glam{hgrid_type}) coordinates in xarray.Dataset.")

            if all([f'depth{grid_type}' not in coord for coord in value.coords]) and ("k" in value.coords):
                raise ValueError(f"Missing required depth (e.g., depth{grid_type}) coordinates in xarray.Dataset.")

        return super().__setitem__(key, value)

    def __getitem__(self, key: str) -> Self | NEMODataArray:
        """
        Access child nodes, variables, or coordinates stored in this NEMODataTree.

        Returned object will be either a NEMODataTree or NEMODataArray object depending
        on whether the key points to a child node or variable.

        Overloads the __getitem__() method of xarray.DataTree to return NEMODataArrays
        accessed via variable paths (i.e, /grid/var).

        Parameters
        ----------
        key : str
            Name of variable / child within this node, or unix-like path to variable
            / child within another node.

        Returns
        -------
        NEMODataTree | NEMODataArray
        """
        # -- Access child node or variable -- #
        item = super().__getitem__(key=key)
        is_gridpath = key.startswith("/grid") or key.startswith("grid")

        # -- Return NEMODataArray -- #
        if isinstance(item, xr.DataArray) & is_gridpath:
            var_name = key.split("/")[-1]
            grid = key.replace(f"/{var_name}", "")
            item = NEMODataArray(da=item,
                                 tree=self,
                                 grid=grid
                                 )

        return item

    def _get_properties(
        self, dom: str | None = None, grid: str | None = None, infer_dom: bool = False
    ) -> str:
        """
        Get NEMO model domain and grid properties.

        The domain prefix & suffix (e.g., '1_', '1') are returned
        if only the NEMO model domain (`dom`) is specified.

        The grid suffix (e.g., 't', 'u', 'v', 'w') is returned if
        only the NEMO model grid (`grid`) is specified.

        The domain number, domain prefix & suffix, and grid suffix
        are returned if both the NEMO model grid (`grid`) and
        `infer_dom = True` are specified.

        Parameters
        ----------
        dom : str, optional
            Prefix of NEMO domain in the DataTree (e.g., '1', '2', '3', etc.).
        grid : str, optional
            Path to NEMO model grid (e.g., 'gridT').
        infer_dom : bool, optional
            Whether to infer the domain number & domain name from only the
            grid path. Default is False.

        Returns
        -------
        tuple[str]
            NEMO model domain and grid properties.
        """
        if (grid is None) & (dom is not None):
            dom_prefix = "" if dom == "." else f"{dom}_"
            dom_suffix = "" if dom == "." else f"{dom}"
            return dom_prefix, dom_suffix
        else:
            grid_keys = list(dict(self.subtree_with_keys).keys())
            if grid not in grid_keys:
                raise KeyError(
                    f"grid '{grid}' not found in available NEMODataTree grids {grid_keys}."
                )
            grid_suffix = f"{grid.lower()[-1]}"

            if infer_dom:
                dom_inds = [char for char in grid if char.isdigit()]
                dom_prefix = f"{dom_inds[-1]}_" if len(dom_inds) != 0 else ""
                dom = dom_prefix[:-1] if dom_prefix != "" else "."
                dom_suffix = dom if dom != "." else ""
                return dom, dom_prefix, dom_suffix, grid_suffix
            else:
                return grid_suffix

    def _get_grid_paths(self, dom: str) -> str:
        """
        Get paths to NEMO model grids in a given domain.

        Parameters
        ----------
        dom : str, optional
            Prefix of NEMO domain in the DataTree (e.g., '1', '2', '3', etc.).

        Returns
        -------
        dict[str, str]
            Dictionary of NEMO model grid paths.
        """
        # Collect paths to all NEMO model grids:
        grid_paths = list(dict(self.subtree_with_keys).keys())

        if dom == ".":
            grid_paths = [
                path for path in grid_paths if ("_" not in path) & ("grid" in path)
            ]
        else:
            grid_paths = [path for path in grid_paths if dom in path]

        d_paths = {path.split("/")[0]: path for path in grid_paths}

        return d_paths

    def _get_ijk_names(self, dom: str | None = None, grid: str | None = None) -> str:
        """
        Get (i, j, k) grid index names for given NEMO model domain.

        If path to NEMO model grid is provided, domain is inferred.

        Parameters
        ----------
        dom : str, optional
            Prefix of NEMO domain in the DataTree (e.g., '1', '2', '3', etc.).
        grid : str, optional
            Path to NEMO model grid (e.g., 'gridT').

        Returns
        -------
        dict[str, str]
            NEMO model grid index names.
        """
        if grid is not None:
            dom, _, dom_suffix, _ = self._get_properties(grid=grid, infer_dom=True)
        else:
            _, dom_suffix = self._get_properties(dom=dom)

        indexes = ["i", "j", "k"]
        if dom == ".":
            d_ijk = {index: index for index in indexes}
        else:
            d_ijk = {index: f"{index}{dom_suffix}" for index in indexes}

        return d_ijk

    def _get_weights(self, grid: str, dims: list, fillna: bool = True) -> xr.DataArray:
        """
        Get the weights (scale factors) for specified dimensions of a NEMO model grid.

        Parameters
        ----------
        grid : str
            Path to NEMO model grid where weights are stored (e.g., 'gridT').
        dims : list
            Dimensions to collect weights for.
        fillna : bool, optional
            Fill NaN values in weights with zeros. Default is True.

        Returns
        -------
        xr.DataArray
            Weights (scale factors) for the specified dimensions of the NEMO model grid.
        """
        if any(dim not in ["i", "j", "k"] for dim in dims):
            raise ValueError(
                "dims must be a list containing one or more of the following dimensions: ['i', 'j', 'k']."
            )

        grid_suffix = self._get_properties(grid=grid)

        weights_dict = {
            "i": f"e1{grid_suffix}",
            "j": f"e2{grid_suffix}",
            "k": f"e3{grid_suffix}",
        }
        try:
            weights_list = [self[f"{grid}/{weights_dict[dim]}"].masked.data for dim in dims]
        except KeyError as e:
            raise KeyError(
                f"weights missing for dimensions {dims} of NEMO model grid {grid}"
            ) from e

        if len(weights_list) == 1:
            weights = weights_list[0]
        elif len(weights_list) == 2:
            weights = weights_list[0] * weights_list[1]
        elif len(weights_list) == 3:
            weights = weights_list[0] * weights_list[1] * weights_list[2]

        if fillna:
            weights = weights.fillna(value=0)

        return weights

    def add_geoindex(
        self,
        grid: str,
    ) -> Self:
        """
        Add geographical index variables to a given NEMO model grid.

        This enables users to index grid variables using geographical
        coordinates (e.g., glamt, gphit) in addition to their (i, j, k)
        dimensions.

        Parameters
        ----------
        grid : str
            Path to NEMO model grid to add geographical indexes (e.g., 'gridT').

        Returns
        -------
        NEMODataTree
            NEMO DataTree with geographical indexes added to specified model grid.

        Examples
        --------
        Add glamt, gphit as geographical indexes to the T-grid of the NEMO parent domain:

        >>> nemo.add_geoindex(grid="gridT")

        """
        # -- Set geographical indexes -- #
        _, dom_prefix, _, grid_suffix = self._get_properties(grid=grid, infer_dom=True)
        lon_name = f"{dom_prefix}glam{grid_suffix}"
        lat_name = f"{dom_prefix}gphi{grid_suffix}"
        self_copy = self.copy()
        self_copy[grid] = (
            self_copy[grid]
            .dataset.assign_coords(
                {lat_name: self_copy[grid][lat_name], lon_name: self_copy[grid][lon_name]}
            )
            .set_xindex(
                (lat_name, lon_name),
                NDPointIndex,
                tree_adapter_cls=SklearnGeoBallTreeAdapter,
            )
        )

        return self_copy

    def cell_area(
        self,
        grid: str,
        dim: str,
    ) -> xr.DataArray:
        """
        Calculate grid cell areas orthogonal to a given dimension of a NEMO model grid.

        Parameters
        ----------
        grid : str
            Path to NEMO model grid from which to calculate grid cell areas
            (e.g., 'gridT').
        dim : str
            Dimension orthogonal to grid cell area to
            calculate (e.g., 'k' returns e1 * e2).

        Returns
        -------
        xr.DataArray
            Grid cell areas (m^2) for the specified NEMO model grid.

        Examples
        --------
        Compute the horizontal area of each grid cell centered on a V-grid point
        in the NEMO parent domain:

        >>> nemo.cell_area(grid="gridT", dim="k")

        Note, `dim` represents the dimension orthogonal to the grid cell
        area to be computed.

        See Also
        --------
        cell_volume
        """
        grid_suffix = self._get_properties(grid=grid)

        if dim not in ["i", "j", "k"]:
            raise ValueError(f"dim {dim} must be one of ['i', 'j', 'k'].")

        match dim:
            case "i":
                cell_area = (
                    self[f"{grid}/e3{grid_suffix}"].masked.data * self[f"{grid}/e2{grid_suffix}"].masked.data
                )
            case "j":
                cell_area = (
                    self[f"{grid}/e3{grid_suffix}"].masked.data * self[f"{grid}/e1{grid_suffix}"].masked.data
                )
            case "k":
                cell_area = (
                    self[f"{grid}/e1{grid_suffix}"].masked.data * self[f"{grid}/e2{grid_suffix}"].masked.data
                )
        cell_area.name = "areacello"

        return cell_area

    def cell_volume(self, grid: str) -> xr.DataArray:
        """
        Calculate grid cell volumes for a given NEMO model grid.

        Parameters
        ----------
        grid : str
            Path to NEMO model grid to calculate grid cell volumes
            (e.g., 'gridT').

        Returns
        -------
        xr.DataArray
            Grid cell volumes for the specified NEMO model grid.

        Examples
        --------
        Compute the volume of each grid cell centered on a V-grid point
        in the NEMO parent domain:

        >>> nemo.cell_volumes(grid="gridV")

        See Also
        --------
        cell_area
        """
        grid_suffix = self._get_properties(grid=grid)

        cell_volume = (
            self[f"{grid}/e3{grid_suffix}"].masked.data
            * self[f"{grid}/e1{grid_suffix}"].masked.data
            * self[f"{grid}/e2{grid_suffix}"].masked.data
        )
        cell_volume.name = "volcello"

        return cell_volume

    @deprecated(version_since="2026.03.b1",
                version_removed="2026.05",
                alternative="NEMODataArray.derivative or NEMOVectorField.gradient from v2026.04 onwards"
                )
    def gradient(
        self,
        var: str,
        dim: str,
        dom: str = ".",
    ) -> xr.DataArray:
        """
        Calculate the gradient of a scalar variable along one dimension (e.g., 'i', 'j', 'k') of a NEMO model grid.

        Parameters
        ----------
        var : str
            Name of the scalar variable.
        dim : str
            Dimension along which to calculate gradient (e.g., 'i', 'j', 'k').
        dom : str, optional
            Prefix of NEMO domain in the DataTree (e.g., '1', '2', '3', etc.).
            Default is '.' for the parent domain.

        Returns
        -------
        xr.DataArray
            Gradient of scalar variable defined on a NEMO model grid.

        Examples
        --------
        Compute the 'meridional' gradient of sea surface temperature `tos_con`
        along the NEMO parent domain `j` dimension:

        >>> nemo.gradient(dom='.', var="tos_con", dim="j")

        Compute the vertical gradient of absolute salinity in the first NEMO
        nested child domain:

        >>> nemo.gradient(dom="1", var="so_abs", dim="k")

        See Also
        --------
        integral
        """
        # -- Validate input -- #
        if not isinstance(var, str):
            raise ValueError(
                "var must be a string specifying name of the scalar variable."
            )
        if not isinstance(dim, str):
            raise ValueError(
                "dim must be a string specifying dimension along which to calculate the gradient (e.g., 'i', 'j', 'k')."
            )
        if not isinstance(dom, str):
            raise ValueError(
                "dom must be a string specifying prefix of a NEMO domain (e.g., '.', '1', '2', etc.)."
            )

        # -- Get NEMO model grid properties -- #
        dom_prefix, dom_suffix = self._get_properties(dom=dom)
        grid_paths = self._get_grid_paths(dom=dom)
        gridT, gridU, gridV, gridW = (
            grid_paths["gridT"],
            grid_paths["gridU"],
            grid_paths["gridV"],
            grid_paths["gridW"],
        )

        if var not in self[gridT].data_vars:
            raise KeyError(f"variable '{var}' not found in grid '{gridT}'.")

        da = self[f"{gridT}/{var}"].masked.data
        dim_name = f"{dim}{dom_suffix}"
        if dim_name not in da.dims:
            raise KeyError(
                f"dimension '{dim_name}' not found in variable '{var}'. Dimensions available: {da.dims}."
            )

        match dim:
            case "i":
                if f"{dom_prefix}deptht" in da.coords:
                    # 3-dimensional umask:
                    umask = self[gridU]["umask"]
                else:
                    # 2-dimensional umask:
                    umask = self[gridU]["umaskutil"]

                # Zonally Periodic Domain:
                if self[gridT].attrs.get("iperio", False):
                    da_end = da.isel({dim_name: 0})
                    da_end[dim_name] = da[dim_name].max() + 1
                    da = xr.concat([da, da_end], dim=dim_name)
                    dvar = da.diff(dim=dim_name, label="lower")
                else:
                    # Non-Periodic: pad with NaN values after differencing:
                    dvar = da.diff(dim=dim_name, label="lower").pad({dim_name: (0, 1)})
                # Apply u-mask & transform coords -> calculate gradient:
                dvar.coords[dim_name] = dvar.coords[dim_name] + 0.5
                gradient = dvar.where(umask) / self[f"{gridU}/e1u"].masked.data

                # Remove redundant depth coordinates:
                if f"{dom_prefix}deptht" in gradient.coords:
                    gradient = gradient.drop_vars(
                        [f"{dom_prefix}deptht"]
                    ).assign_coords(
                        {f"{dom_prefix}depthu": self[gridU][f"{dom_prefix}depthu"]}
                    )
            case "j":
                # 3-dimensional vmask:
                if f"{dom_prefix}deptht" in da.coords:
                    vmask = self[gridV]["vmask"]
                else:
                    # 2-dimensional vmask (unique points):
                    vmask = self[gridV]["vmaskutil"]

                # Pad with zeros after differencing (zero gradient at jmaxdom):
                dvar = da.diff(dim=dim_name, label="lower").pad(
                    {dim_name: (0, 1)}, constant_values=0
                )
                # Apply vmask & transform coords -> calculate gradient:
                dvar.coords[dim_name] = dvar.coords[dim_name] + 0.5
                gradient = dvar.where(vmask) / self[f"{gridV}/e2v"].masked.data

                if f"{dom_prefix}deptht" in gradient.coords:
                    gradient = gradient.drop_vars(
                        [f"{dom_prefix}deptht"]
                    ).assign_coords(
                        {f"{dom_prefix}depthv": self[gridV][f"{dom_prefix}depthv"]}
                    )

            case "k":
                dvar = da.diff(dim=dim_name, label="lower")
                # Transform coords & apply w-mask -> calculate gradient:
                dvar.coords[dim_name] = dvar.coords[dim_name] + 0.5
                dvar = dvar.where(self[gridW]["wmask"].isel({dim_name: slice(1, None)}))
                try:
                    gradient = -dvar / self[f"{gridW}/e3w"].masked.data.isel(
                        {dim_name: slice(1, None)}
                    )
                    gradient = gradient.drop_vars([f"{dom_prefix}deptht"])
                except KeyError as e:
                    raise KeyError(
                        f"NEMO model grid: '{gridW}' does not contain vertical scale factor 'e3w' required to calculate gradients along the k-dimension."
                    ) from e

        # Update DataArray properties:
        gradient.name = f"grad_{dim_name}({var})"
        gradient = gradient.drop_vars([f"{dom_prefix}glamt", f"{dom_prefix}gphit"])

        return gradient

    @deprecated(version_since="2026.03.b1",
                version_removed="2026.05",
                alternative="NEMOVectorField.divergence from v2026.04 onwards"
                )
    def divergence(
        self,
        vars: list[str],
        dom: str = ".",
    ) -> xr.DataArray:
        """
        Calculate the horizontal divergence of a vector field defined on a NEMO model grid.

        Parameters
        ----------
        vars : list[str]
            Name of vector variables, structured as: ['u', 'v'], where
            'u' and 'v' are the i and j components of the vector field,
            respectively.
        dom : str, optional
            Prefix of NEMO domain in the DataTree (e.g., '1', '2', '3', etc.).
            Default is '.' for the parent domain.

        Returns
        -------
        xr.DataArray
            Horizontal divergence of vector field defined on a NEMO model grid.

        Examples
        --------
        Compute the horizontal divergence of the seawater velocity field in the
        NEMO parent domain:

        >>> nemo.divergence(dom=".", vars=["uo", "vo"])

        Note, `vars` expects a list of the `i` and `j` components of the vector
        field, respectively.

        See Also
        --------
        divergence
        """
        # -- Validate input -- #
        if not isinstance(vars, list) or len(vars) != 2:
            raise ValueError(
                "vars must be a list of two elements structured as ['u', 'v']."
            )
        if not isinstance(dom, str):
            raise ValueError(
                "dom must be a string specifying the prefix of a NEMO domain (e.g., '.', '1', '2', etc.)."
            )

        # -- Get NEMO model grid properties -- #
        dom_prefix, _ = self._get_properties(dom=dom)
        grid_paths = self._get_grid_paths(dom=dom)
        gridT, gridU, gridV = (
            grid_paths["gridT"],
            grid_paths["gridU"],
            grid_paths["gridV"],
        )
        ijk_names = self._get_ijk_names(dom=dom)
        i_name, j_name = ijk_names["i"], ijk_names["j"]

        # -- Define i,j vector components -- #
        var_i, var_j = vars[0], vars[1]
        if var_i not in self[gridU].data_vars:
            raise KeyError(f"variable '{var_i}' not found in grid '{gridU}'.")
        if var_j not in self[gridV].data_vars:
            raise KeyError(f"variable '{var_j}' not found in grid '{gridV}'.")

        da_i = self[f"{gridU}/{var_i}"].masked.data
        da_j = self[f"{gridV}/{var_j}"].masked.data

        # -- Collect mask -- #
        if (f"{dom_prefix}depthu" in da_i.coords) & (
            f"{dom_prefix}depthv" in da_j.coords
        ):
            # 3-dimensional tmask:
            tmask = self[gridT]["tmask"]
        else:
            # 2-dimensional tmask (unique points):
            tmask = self[gridT]["tmaskutil"]

        # -- Neglecting the first T-grid points along i, j dimensions -- #
        e1t = self[f"{gridT}/e1t"].masked.data.isel({i_name: slice(1, None), j_name: slice(1, None)})
        e2t = self[f"{gridT}/e2t"].masked.data.isel({i_name: slice(1, None), j_name: slice(1, None)})
        e3t = self[f"{gridT}/e3t"].masked.data.isel({i_name: slice(1, None), j_name: slice(1, None)})

        e2u, e3u = self[f"{gridU}/e2u"].masked.data, self[f"{gridU}/e3u"].masked.data
        e1v, e3v = self[f"{gridV}/e1v"].masked.data, self[f"{gridV}/e3v"].masked.data  

        # -- Calculate divergence on T-points -- #
        dvar_i = (e2u * e3u * da_i).diff(dim=i_name, label="lower")
        dvar_i.coords[i_name] = dvar_i.coords[i_name] + 0.5

        dvar_j = (e1v * e3v * da_j).diff(dim=j_name, label="lower")
        dvar_j.coords[j_name] = dvar_j.coords[j_name] + 0.5

        divergence = (1 / (e1t * e2t * e3t)) * (dvar_i + dvar_j).where(tmask)

        # -- Update DataArray properties -- #
        divergence.name = f"div({var_i}, {var_j})"
        divergence = divergence.drop_vars(
            [
                f"{dom_prefix}glamu",
                f"{dom_prefix}gphiu",
                f"{dom_prefix}glamv",
                f"{dom_prefix}gphiv",
                f"{dom_prefix}depthu",
                f"{dom_prefix}depthv",
            ]
        )

        return divergence

    @deprecated(version_since="2026.03.b1",
                version_removed="2026.05",
                alternative="NEMOVectorField.curl from v2026.04 onwards"
                )
    def curl(
        self,
        vars: list[str],
        dom: str = ".",
    ) -> xr.DataArray:
        """
        Calculate the vertical (k) curl component of a vector field on a NEMO model grid.

        Parameters
        ----------
        vars : list[str]
            Name of the vector variables, structured as: ['u', 'v'], where 'u' and 'v' are
            the i and j components of the vector field, respectively.
        dom : str, optional
            Prefix of NEMO domain in the DataTree (e.g., '1', '2', '3', etc.).
            Default is '.' for the parent domain.

        Returns
        -------
        xr.DataArray
            Vertical curl component of vector field defined on a NEMO model grid.

        Examples
        --------
        Compute the vertical component of the curl of the seawater velocity field in
        the second NEMO nested child domain:

        >>> nemo.curl(dom="2", vars=["uo", "vo"])

        Note, `vars` expects a list of the `i` and `j` components of the vector field,
        respectively.

        See Also
        --------
        divergence
        """
        # -- Validate input -- #
        if not isinstance(vars, list) or len(vars) != 2:
            raise ValueError(
                "vars must be a list of two elements structured as ['u', 'v']."
            )
        if not isinstance(dom, str):
            raise ValueError(
                "dom must be a string specifying the prefix of a NEMO domain (e.g., '.', '1', '2', etc.)."
            )

        # -- Get NEMO model grid properties -- #
        dom_prefix, _ = self._get_properties(dom=dom)
        grid_paths = self._get_grid_paths(dom=dom)
        gridU, gridV, gridF = (
            grid_paths["gridU"],
            grid_paths["gridV"],
            grid_paths["gridF"],
        )
        ijk_names = self._get_ijk_names(dom=dom)
        i_name, j_name = ijk_names["i"], ijk_names["j"]

        # -- Define i,j vector components -- #
        var_i, var_j = vars[0], vars[1]
        if var_i not in self[gridU].data_vars:
            raise KeyError(f"variable '{var_i}' not found in grid '{gridU}'.")
        if var_j not in self[gridV].data_vars:
            raise KeyError(f"variable '{var_j}' not found in grid '{gridV}'.")

        da_i = self[f"{gridU}/{var_i}"].masked.data
        da_j = self[f"{gridV}/{var_j}"].masked.data

        # -- Collect mask -- #
        if (f"{dom_prefix}depthu" in da_i.coords) & (
            f"{dom_prefix}depthv" in da_j.coords
        ):
            # 3-dimensional fmask
            fmask = self[gridF]["fmask"]
        else:
            # 2-dimensional fmask (unique points):
            fmask = self[gridF]["fmaskutil"]

        # -- Neglecting the final F-grid points along i, j dimensions -- #
        e1f = self[f"{gridF}/e1f"].masked.data.isel(
            {i_name: slice(None, -1), j_name: slice(None, -1)}
        )
        e2f = self[f"{gridF}/e2f"].masked.data.isel(
            {i_name: slice(None, -1), j_name: slice(None, -1)}
        )

        e1u = self[f"{gridU}/e1u"].masked.data
        e2v = self[f"{gridV}/e2v"].masked.data
        # -- Calculate vertical curl component on F-points -- #
        dvar_i = (e2v * da_j).diff(dim=i_name, label="lower")
        dvar_i.coords[i_name] = dvar_i.coords[i_name] + 0.5

        dvar_j = (e1u * da_i).diff(dim=j_name, label="lower")
        dvar_j.coords[j_name] = dvar_j.coords[j_name] + 0.5

        curl = (1 / (e1f * e2f)) * (dvar_i - dvar_j).where(fmask)

        # -- Update DataArray properties -- #
        curl.name = f"curl({var_i}, {var_j})"
        curl = curl.drop_vars(
            [
                f"{dom_prefix}glamu",
                f"{dom_prefix}gphiu",
                f"{dom_prefix}glamv",
                f"{dom_prefix}gphiv",
            ]
        )

        return curl

    @deprecated(version_since="2026.03.b1",
                version_removed="2026.05",
                alternative="NEMODataArray.integral"
                )
    def integral(
        self,
        grid: str,
        var: str,
        dims: list,
        cum_dims: list | None = None,
        dir: str | None = None,
        mask: xr.DataArray | None = None,
    ) -> xr.DataArray:
        """
        Integrate a variable along one or more dimensions of a NEMO model grid.

        Parameters
        ----------
        grid : str
            Path to NEMO model grid where variable is stored (e.g., 'gridT').
        var : str
            Name of variable to integrate.
        dims : list
            Dimensions over which to integrate (e.g., ['i', 'k']).
        cum_dims : list, optional
            Dimensions over which to cumulatively integrate (e.g., ['k']).
            Specified dimensions must also be included in `dims`.
        dir : str, optional
            Direction of cumulative integration. Options are '+1' (along
            increasing cum_dims) or '-1' (along decreasing cum_dims).
        mask: xr.DataArray, optional
            Boolean mask identifying NEMO model grid points to be included (1)
            or neglected (0) from integration.

        Returns
        -------
        xr.DataArray
            Variable integrated along specified dimensions of the NEMO model grid.


        Examples
        --------
        Compute the integral of conservative temperature `thetao_con` along the vertical
        `k` dimension in the NEMO parent domain:


        >>> nemo.integral(grid="gridT",
        ...               var="thetao_con",
        ...               dims=["k"]
        ...               )

        Compute the vertical meridional overturning stream function from the meridional
        velocity `vo` (zonally integrated meridional velocity accumulated with increasing
        depth):

        >>> nemo.integral(grid="gridV",
        ...               var="vo",
        ...               dims=["i", "k"],
        ...               cum_dims=["k"],
        ...               dir="+1",
        ...               )

        See Also
        --------
        gradient
        """
        # -- Validate input -- #
        grid_keys = list(dict(self.subtree_with_keys).keys())
        if grid not in grid_keys:
            raise KeyError(
                f"grid '{grid}' not found in available NEMODataTree grids {grid_keys}."
            )
        if var not in self[grid].data_vars:
            raise KeyError(f"variable '{var}' not found in grid '{grid}'.")
        if cum_dims is not None:
            for dim in cum_dims:
                if dim not in dims:
                    raise ValueError(
                        f"cumulative integration dimension '{dim}' not included in `dims`."
                    )
            if dir not in ["+1", "-1"]:
                raise ValueError(
                    f"invalid direction of cumulative integration '{dir}'. Expected '+1' or '-1'."
                )
        if mask is not None:
            if not isinstance(mask, xr.DataArray):
                raise ValueError("mask must be an xarray.DataArray.")
            if any(dim not in self[grid].dims for dim in mask.dims):
                raise ValueError(
                    f"mask must have dimensions subset from {self[grid].dims}."
                )

        # -- Collect variable, weights & mask -- #
        da = (
            self[f"{grid}/{var}"].masked.data.where(mask)
            if mask is not None
            else self[f"{grid}/{var}"].masked.data
        )
        weights = self._get_weights(grid=grid, dims=dims)

        # -- Perform integration -- #
        if cum_dims is not None:
            sum_dims = [dim for dim in dims if dim not in cum_dims]
            if dir == "+1":
                # Cumulative integration along ordered dimension:
                result = (
                    da.weighted(weights)
                    .sum(dim=sum_dims, skipna=True)
                    .cumsum(dim=cum_dims, skipna=True)
                )
            elif dir == "-1":
                # Cumulative integration along reversed dimension:
                result = (
                    da.weighted(weights)
                    .sum(dim=sum_dims, skipna=True)
                    .reindex({dim: self[grid][dim][::-1] for dim in cum_dims})
                    .cumsum(dim=cum_dims, skipna=True)
                )
        else:
            # Integration only:
            result = da.weighted(weights).sum(dim=dims, skipna=True)

        # -- Update DataArray properties -- #
        result.name = f"integral_{', '.join(dims)}({var})"

        return result

    @deprecated(version_since="2026.03.b1",
                version_removed="2026.05",
                alternative="NEMODataArray.depth_integral"
                )
    def depth_integral(
        self, grid: str, var: str, limits: tuple[int | float]
    ) -> xr.Dataset:
        """
        Integrate a variable in depth coordinates between two limits.

        Parameters
        ----------
        grid : str
            Path to NEMO model grid where variable is stored (e.g., 'gridT').
        var : str
            Name of the variable to vertically integrate.
        limits : tuple[int | float]
            Limits of depth integration given as a tuple of the form
            (depth_lower, depth_upper) where depth_lower and depth_upper are
            the lower and upper limits of vertical integration, respectively.

        Returns
        -------
        xr.DataArray
            Vertical integral of chosen variable between depth surfaces (depth_lower, depth_upper).

        Examples
        --------
        Vertically integrate the conservative temperature variable `thetao_con` defined in a
        NEMO model parent domain from the sea surface to 100 m depth:

        >>> nemo.depth_integral(grid='gridT',
        ...                     var='thetao_con',
        ...                     limits=(0, 100)
        ...                              )

        See Also
        --------
        integral
        """
        # -- Validate input -- #
        grid_keys = list(dict(self.subtree_with_keys).keys())
        if grid not in grid_keys:
            raise KeyError(
                f"grid '{grid}' not found in available NEMODataTree grids {grid_keys}."
            )
        if var not in self[grid].data_vars:
            raise KeyError(f"Variable '{var}' not found in grid '{grid}'.")
        if (not isinstance(limits, tuple)) | (len(limits) != 2):
            raise TypeError(
                "depth limits of integration should be given by a tuple of the form (depth_lower, depth_upper)"
            )
        if (limits[0] < 0) | (limits[1] < 0):
            raise ValueError("depth limits of integration must be non-negative.")
        if limits[0] >= limits[1]:
            raise ValueError(
                "lower depth limit must be less than upper depth limit."
            )

        # -- Get NEMO model grid properties -- #
        dom, _, _, grid_suffix = self._get_properties(grid=grid, infer_dom=True)
        ijk_names = self._get_ijk_names(dom=dom)
        i_name, j_name, k_name = ijk_names["i"], ijk_names["j"], ijk_names["k"]

        # -- Define input variables -- #
        var_in = self[f"{grid}/{var}"].masked.data
        e3_in = self[f"{grid}/e3{grid_suffix}"].masked.data

        # -- Vertically integrate w.r.t depth -- #
        result = xr.apply_ufunc(
            compute_depth_integral,
            e3_in,
            var_in,
            np.array([limits[1]]),
            np.array([limits[0]]),
            input_core_dims=[[k_name], [k_name], [None], [None]],
            output_core_dims=[["k_new"]],
            dask="parallelized",
            output_dtypes=[var_in.dtype],
            dask_gufunc_kwargs={"output_sizes": {"k_new": 1}},
        )

        # -- Create variable integral DataArray -- #
        t_name = self[f"{grid}/{var}"].t_name
        if t_name is not None:
            result = result.transpose(t_name, "k_new", j_name, i_name).squeeze()
        else:
            result = result.transpose("k_new", j_name, i_name).squeeze()
        result.name = f"integral_z({var})"

        return result

    def clip_grid(
        self,
        grid: str,
        bbox: tuple,
    ) -> Self:
        """
        Clip a NEMO model grid to specified longitude and latitude range.

        Parameters
        ----------
        grid : str
            Path to NEMO model grid to clip (e.g., 'gridT').
        bbox : tuple
            Bounding box to clip to (lon_min, lon_max, lat_min, lat_max).

        Returns
        -------
        NEMODataTree
            NEMO DataTree with specified model grid clipped to bounding box.

        Examples
        --------
        Clip T-grid in a NEMO parent domain in the bounding box (-80°E, 0°E, 40°N, 80°N):

        >>> bbox = (-80, 0, 40, 80)

        >>> nemo.clip_grid(grid="gridT", bbox=bbox)

        See Also
        --------
        clip_domain
        """
        # -- Validate input -- #
        if not isinstance(bbox, tuple) or len(bbox) != 4:
            raise ValueError(
                "bounding box must be a tuple (lon_min, lon_max, lat_min, lat_max)."
            )

        # -- Get NEMO model grid properties -- #
        _, dom_prefix, _, grid_suffix = self._get_properties(grid=grid, infer_dom=True)
        hgrid_type = grid_suffix if "w" not in grid_suffix else "t"

        # -- Clip the grid to given bounding box -- #
        # Indexing with a mask requires loading coords into memory:
        glam = self[grid][f"{dom_prefix}glam{hgrid_type}"].load()
        gphi = self[grid][f"{dom_prefix}gphi{hgrid_type}"].load()

        grid_clipped = self[grid].dataset.where(
            (glam >= bbox[0])
            & (glam <= bbox[1])
            & (gphi >= bbox[2])
            & (gphi <= bbox[3]),
            drop=True,
        )

        d_dtypes = {var: self[grid][var].dtype for var in self[grid].dataset.data_vars}
        for var, dtype in d_dtypes.items():
            if dtype in [np.int32, np.int64, bool]:
                grid_clipped[var] = grid_clipped[var].fillna(0).astype(dtype)

        if bbox != (-180, 180, -90, 90):
            # Update zonal periodicity of grid node:
            grid_clipped = grid_clipped.assign_attrs({"iperio": False})

        # Update shallow copy of NEMODataTree:
        self_copy = self.copy()
        self_copy[grid].dataset = grid_clipped

        return self_copy

    def clip_domain(
        self,
        dom: str,
        bbox: tuple,
    ) -> Self:
        """
        Clip a NEMO model domain to specified longitude and latitude range.

        Parameters
        ----------
        dom : str
            Prefix of NEMO domain in the DataTree (e.g., '1', '2', '3', etc.).
            Default is '.' for the parent domain.
        bbox : tuple
            Bounding box to clip to (lon_min, lon_max, lat_min, lat_max).

        Returns
        -------
        NEMODataTree
            NEMO DataTree with specified model domain clipped to bounding box.

        Examples
        --------
        Clip all model grids in a NEMO parent domain in the bounding box
        (-80°E, 0°E, 40°N, 80°N):

        >>> bbox = (-80, 0, 40, 80)

        >>> nemo.clip_domain(dom=".", bbox=bbox)

        See Also
        --------
        clip_grid
        """
        # -- Validate input -- #
        if not isinstance(dom, str):
            raise ValueError(
                "dom must be a string specifying the prefix of a NEMO domain (e.g., '.', '1', '2', etc.)."
            )
        if not isinstance(bbox, tuple) or len(bbox) != 4:
            raise ValueError(
                "bounding box must be a tuple: (lon_min, lon_max, lat_min, lat_max)."
            )

        # -- Get NEMO model grid properties -- #
        grid_paths = self._get_grid_paths(dom=dom)
        ijk_names = self._get_ijk_names(dom=dom)
        i_name, j_name = ijk_names["i"], ijk_names["j"]

        # -- Clip grids to given bounding box -- #
        if not grid_paths:
            raise ValueError(f"NEMO model domain '{dom}' not found in the DataTree.")
        else:
            for grid in grid_paths.values():
                # Identify grid type:
                grid_suffix = self._get_properties(grid=grid)

                if grid_suffix == "t":
                    # Clip shallow copy of NEMODataTree T-grid using lon/lat bbox:
                    self_copy = self.copy().clip_grid(grid=grid, bbox=bbox)
                    # Store (i, j) coords of bbox on T-grid:
                    i_bbox = self_copy[grid][i_name]
                    j_bbox = self_copy[grid][j_name]

                else:
                    # Clip adjacent horizontal grid using (i, j) coords of clipped T-grid:
                    match grid_suffix:
                        case "u":
                            grid_clipped = self[grid].dataset.sel(i=i_bbox + 0.5, j=j_bbox)
                        case "v":
                            grid_clipped = self[grid].dataset.sel(i=i_bbox, j=j_bbox + 0.5)
                        case "w":
                            grid_clipped = self[grid].dataset.sel(i=i_bbox, j=j_bbox)
                        case "f":
                            grid_clipped = self[grid].dataset.sel(i=i_bbox + 0.5, j=j_bbox + 0.5)

                    if bbox != (-180, 180, -90, 90):
                        # Update zonal periodicity of NEMO model grid:
                        grid_clipped = grid_clipped.assign_attrs({"iperio": False})
                    # Update shallow copy of NEMODataTree:
                    self_copy[grid].dataset = grid_clipped

        return self_copy

    def mask_with_polygon(
        self,
        grid: str,
        lon_poly: list | np.ndarray,
        lat_poly: list | np.ndarray,
    ):
        """
        Create mask of NEMO model grid points contained within a polygon.

        Parameters
        ----------
        grid : str
            Path to NEMO model grid where longitude and latitude coordinates
            are stored (e.g., 'gridT').
        lon_poly : list | ndarray
            Longitudes of closed polygon.
        lat_poly : list | ndarray
            Latitudes of closed polygon.

        Returns
        -------
        xr.DataArray
            Boolean mask identifying NEMO model grid points which are inside
            the polygon.

        Examples
        --------
        Create a regional boolean mask using the geographical coordinates of a closed
        polygon `lon_poly` and `lat_poly` in a NEMO parent domain:


        >>> nemo.mask_with_polygon(grid="gridT",
        ...                        lon_poly=lon_poly,
        ...                        lat_poly=lat_poly,
        ...                        )

        See Also
        --------
        masked_statistic
        """
        # -- Validate input -- #
        if not isinstance(lon_poly, (np.ndarray, list)) or not isinstance(
            lat_poly, (np.ndarray, list)
        ):
            raise TypeError(
                "longitude & latitude coordinates of polygon must be numpy arrays or lists."
            )
        if (lon_poly[0] != lon_poly[-1]) or (lat_poly[0] != lat_poly[-1]):
            raise ValueError(
                "longitude & latitude coordinates must form a closed polygon."
            )

        # -- Get NEMO model grid properties -- #
        dom, dom_prefix, _, grid_suffix = self._get_properties(grid=grid, infer_dom=True)
        hgrid_type = grid_suffix if "w" not in grid_suffix else "t"
        ijk_names = self._get_ijk_names(grid=grid)
        i_name, j_name = ijk_names["i"], ijk_names["j"]

        if dom == ".":
            lon_name = f"glam{hgrid_type}"
            lat_name = f"gphi{hgrid_type}"
        else:
            lon_name = f"{dom_prefix}glam{hgrid_type}"
            lat_name = f"{dom_prefix}gphi{hgrid_type}"

        # -- Create mask using polygon coordinates -- #
        mask = create_polygon_mask(
            lon_grid=self[grid][lon_name],
            lat_grid=self[grid][lat_name],
            lon_poly=lon_poly,
            lat_poly=lat_poly,
            dims=(j_name, i_name),
        )

        return mask

    @deprecated(version_since="2026.03.b1",
                version_removed="2026.05",
                alternative="NEMODataArray.masked_statistic"
                )
    def masked_statistic(
        self,
        grid: str,
        var: str,
        lon_poly: list | np.ndarray,
        lat_poly: list | np.ndarray,
        statistic: str,
        dims: list,
    ) -> xr.DataArray:
        """
        Masked statistic of a variable defined on a NEMO model grid.

        Parameters
        ----------
        grid : str
            Path to NEMO model grid where variable is stored (e.g., 'gridT').
        var : str
            Name of the variable to compute statistic.
        lon_poly : list | np.ndarray
            Longitudes of closed polygon.
        lat_poly : list | np.ndarray
            Latitudes of closed polygon.
        statistic : str
            Name of the statistic to calculate (e.g., 'mean', 'weighted_mean' 'sum').
        dims : list
            Dimensions over which to apply statistic (e.g., ['i', 'j']).

        Returns
        -------
        xr.DataArray
            Masked statistic of specified variable.

        Examples
        --------
        Compute the grid cell area-weighted mean sea surface temperature `tos_con` for a
        region enclosed in a polygon defined by `lon_poly` and `lat_poly` in a NEMO nested
        child domain:

        >>> nemo.masked_statistic(grid="gridT/1_gridT",
        ...                       var="tos_con",
        ...                       lon_poly=lon_poly,
        ...                       lat_poly=lat_poly,
        ...                       statistic="weighted_mean",
        ...                       dims=["i", "j"]
        ...                       )

        See Also
        --------
        binned_statistic
        """
        # -- Validate input -- #
        grid_keys = list(dict(self.subtree_with_keys).keys())
        if grid not in grid_keys:
            raise KeyError(
                f"grid '{grid}' not found in available NEMODataTree grids {grid_keys}."
            )
        if var not in self[grid].data_vars:
            raise KeyError(f"variable '{var}' not found in grid '{grid}'.")

        # -- Create polygon mask using coordinates -- #
        mask_poly = self.mask_with_polygon(
            lon_poly=lon_poly, lat_poly=lat_poly, grid=grid
        )

        # -- Get NEMO model grid properties -- #
        _, _, dom_suffix, _ = self._get_properties(grid=grid, infer_dom=True)

        # -- Apply masks & calculate statistic -- #
        da = self[f"{grid}/{var}"].masked.data.where(mask_poly)

        match statistic:
            case "mean":
                result = da.mean(dim=dims, skipna=True)

            case "weighted_mean":
                weight_dims = [dim.replace(dom_suffix, "") for dim in dims]
                weights = self._get_weights(grid=grid, dims=weight_dims)
                result = da.weighted(weights).mean(dim=dims, skipna=True)

            case "min":
                result = da.min(dim=dims, skipna=True)

            case "max":
                result = da.max(dim=dims, skipna=True)

            case "sum":
                result = da.sum(dim=dims, skipna=True)

            case _:
                raise ValueError(
                    f"Unsupported statistic '{statistic}'. Supported statistics are: 'mean', 'weighted_mean', 'min', 'max', 'sum'."
                )

        return result

    def extract_mask_boundary(
        self,
        mask: xr.DataArray,
        uv_vars: list | None = None,
        vars: list | None = None,
        dom: str = ".",
    ) -> xr.Dataset:
        """
        Extract the boundary of a masked region defined on a NEMO model grid.

        Parameters
        ----------
        mask : xr.DataArray
            Boolean mask identifying NEMO model grid points which
            are inside the region of interest.
        uv_vars : list, optional
            Names of velocity variables to extract along the boundary.
            Default is ['uo', 'vo'].
        vars : list, optional
            Names of scalar variables to extract along the boundary.
        dom : str, optional
            Prefix of NEMO domain in the DataTree (e.g., '1', '2', '3', etc.).
            Default is '.' for the parent domain.

        Returns
        -------
        xr.Dataset
            Dataset containing variables and NEMO model coordinates
            extracted along the boundary of the mask.

        Examples
        --------
        Extract normal velocities and absolute salinity along the boundary of
        a masked region in the NEMO parent domain:

        >>> nemo.extract_mask_boundary(mask=mask_osnap,
        ...                            uv_vars=["uo", "vo"],
        ...                            vars=["so_abs"],
        ...                            dom=".",
        ...                            )

        See Also
        --------
        extract_section
        """
        # -- Validate input -- #
        if not isinstance(mask, xr.DataArray):
            raise ValueError("mask must be an xarray DataArray")
        if not isinstance(dom, str):
            raise ValueError(
                "dom must be a string specifying prefix of a NEMO domain (e.g., '.', '1', '2', etc.)."
            )
        if uv_vars is None:
            uv_vars = ["uo", "vo"]
        else:
            if not isinstance(uv_vars, list) or len(uv_vars) != 2:
                raise ValueError(
                    "uv_vars must be a list of velocity variables to extract (e.g., ['uo', 'vo'])."
                )

        # -- Get NEMO model grid properties -- #
        dom_prefix, dom_suffix = self._get_properties(dom=dom)
        grid_paths = self._get_grid_paths(dom=dom)
        gridT, gridU, gridV = (
            grid_paths["gridT"],
            grid_paths["gridU"],
            grid_paths["gridV"],
        )
        ijk_names = self._get_ijk_names(dom=dom)
        k_name = ijk_names["k"]

        # -- Extract mask boundary -- #
        if f"i{dom_suffix}" not in mask.dims or f"j{dom_suffix}" not in mask.dims:
            raise ValueError(
                f"mask must have dimensions f'i{dom_suffix}' and 'j{dom_suffix}'"
            )
        i_bdy, j_bdy, flux_type, flux_dir = get_mask_boundary(mask)

        # -- Construct boundary dataset -- #
        t_name = [dim for dim in self[gridU].dims if "time" in dim][0]

        ds = xr.Dataset(
            data_vars={
                "i_bdy": (["bdy"], i_bdy[::-1]),
                "j_bdy": (["bdy"], j_bdy[::-1]),
                "flux_type": (["bdy"], flux_type[::-1]),
                "flux_dir": (["bdy"], flux_dir[::-1]),
            },
            coords={
                t_name: self[gridU][t_name].values,
                k_name: self[gridU][k_name].values,
                "bdy": np.arange(len(i_bdy)),
            },
        )

        # Add velocities normal to boundary:
        if uv_vars[0] not in self[gridU].data_vars:
            raise KeyError(f"variable '{uv_vars[0]}' not found in grid '{gridU}'.")
        if uv_vars[1] not in self[gridV].data_vars:
            raise KeyError(f"variable '{uv_vars[1]}' not found in grid '{gridV}'.")

        ubdy_mask = ds["flux_type"] == "U"
        vbdy_mask = ds["flux_type"] == "V"

        dim_sizes = [
            self[gridU][t_name].size,
            self[gridU][k_name].size,
            ds["bdy"].size,
        ]

        ds["velocity"] = xr.DataArray(
            data=dask.array.zeros(dim_sizes), dims=[t_name, k_name, "bdy"]
        )
        ds["velocity"][:, :, ubdy_mask] = (
            self[f"{gridU}/{uv_vars[0]}"].masked.data.sel(
                i=ds["i_bdy"][ubdy_mask], j=ds["j_bdy"][ubdy_mask]
            )
            * ds["flux_dir"][ubdy_mask]
        )
        ds["velocity"][:, :, vbdy_mask] = (
            self[f"{gridV}/{uv_vars[1]}"].masked.data.sel(
                i=ds["i_bdy"][vbdy_mask], j=ds["j_bdy"][vbdy_mask]
            )
            * ds["flux_dir"][vbdy_mask]
        )

        ds = ds.assign_coords(
            {
                f"{dom_prefix}glamb": (["bdy"], np.zeros(ds["bdy"].size)),
                f"{dom_prefix}gphib": (["bdy"], np.zeros(ds["bdy"].size)),
                f"{dom_prefix}depthb": ((k_name, "bdy"), np.zeros(dim_sizes[1:])),
            }
        )

        ds[f"{dom_prefix}glamb"][ubdy_mask] = self[gridU][f"{dom_prefix}glamu"].sel(
            i=ds["i_bdy"][ubdy_mask], j=ds["j_bdy"][ubdy_mask]
        )
        ds[f"{dom_prefix}glamb"][vbdy_mask] = self[gridV][f"{dom_prefix}glamv"].sel(
            i=ds["i_bdy"][vbdy_mask], j=ds["j_bdy"][vbdy_mask]
        )

        ds[f"{dom_prefix}gphib"][ubdy_mask] = self[gridU][f"{dom_prefix}gphiu"].sel(
            i=ds["i_bdy"][ubdy_mask], j=ds["j_bdy"][ubdy_mask]
        )
        ds[f"{dom_prefix}gphib"][vbdy_mask] = self[gridV][f"{dom_prefix}gphiv"].sel(
            i=ds["i_bdy"][vbdy_mask], j=ds["j_bdy"][vbdy_mask]
        )
        ds[f"{dom_prefix}depthb"][:, ubdy_mask] = self[gridU][f"{dom_prefix}depthu"]
        ds[f"{dom_prefix}depthb"][:, vbdy_mask] = self[gridV][f"{dom_prefix}depthv"]

        if vars is not None:
            # Add scalar variables along the boundary:
            for var in vars:
                if var in self[gridT].data_vars:
                    ds[var] = xr.DataArray(
                        data=dask.array.zeros(dim_sizes),
                        dims=[t_name, k_name, "bdy"],
                    )
                else:
                    raise KeyError(f"variable {var} not found in grid '{gridT}'.")

                # Linearly interpolate scalar variables onto NEMO model U/V grid points:
                ds[var][:, :, ubdy_mask] = 0.5 * (
                    self[f"{gridT}/{var}"].masked.data.sel(
                        i=ds["i_bdy"][ubdy_mask] - 0.5, j=ds["j_bdy"][ubdy_mask]
                    )
                    + self[f"{gridT}/{var}"].masked.data.sel(
                        i=ds["i_bdy"][ubdy_mask] + 0.5, j=ds["j_bdy"][ubdy_mask]
                    )
                )
                ds[var][:, :, vbdy_mask] = 0.5 * (
                    self[f"{gridT}/{var}"].masked.data.sel(
                        i=ds["i_bdy"][vbdy_mask], j=ds["j_bdy"][vbdy_mask] - 0.5
                    )
                    + self[f"{gridT}/{var}"].masked.data.sel(
                        i=ds["i_bdy"][vbdy_mask], j=ds["j_bdy"][vbdy_mask] + 0.5
                    )
                )

        return ds

    def extract_section(
        self,
        lon_section: np.ndarray,
        lat_section: np.ndarray,
        uv_vars: list | None = None,
        vars: list | None = None,
        dom: str = ".",
    ) -> xr.Dataset:
        """
        Extract hydrographic section from a NEMO model domain.

        Parameters
        ----------
        lon_section : np.ndarray
            Longitudes defining the section polygon.
        lat_section : np.ndarray
            Latitudes defining the section polygon.
        uv_vars : list, optional
            Names of velocity variables to extract along the boundary.
            Default is ['uo', 'vo'].
        vars : list, optional
            Names of scalar variables to extract along the boundary.
        dom : str
            Prefix of NEMO domain in the DataTree (e.g., '1', '2', '3', etc.).
            Default is '.' for the parent domain.

        Returns
        -------
        xr.Dataset
            Dataset containing hydrographic section extracted from NEMO model grid.

        Examples
        --------
        Extract normal velocities and potential density along the Overturning in the Subpolar
        North Atlantic (OSNAP) array defined by `lon_osnap` and `lat_osnap` coordinates in the
        NEMO parent domain:

        >>> nemo.extract_section(lon_section=lon_osnap,
        ...                      lat_section=lat_osnap,
        ...                      uv_vars=["uo", "vo"],
        ...                      vars=["sigma0"],
        ...                      dom=".",
        ...                      )

        See Also
        --------
        extract_mask_boundary
        """
        # -- Validate input -- #
        if not isinstance(lon_section, np.ndarray):
            raise TypeError("lon_section must be a numpy array.")
        if not isinstance(lat_section, np.ndarray):
            raise TypeError("lat_section must be a numpy array.")
        if not isinstance(dom, str):
            raise ValueError(
                "dom must be a string specifying prefix of a NEMO domain (e.g., '.', '1', '2', etc.)."
            )
        if uv_vars is None:
            uv_vars = ["uo", "vo"]
        else:
            if not isinstance(uv_vars, list) or len(uv_vars) != 2:
                raise ValueError(
                    "uv_vars must be a list of velocity variables to extract (e.g., ['uo', 'vo'])."
                )

        # -- Get NEMO model grid properties -- #
        grid_paths = self._get_grid_paths(dom=dom)

        # -- Define hydrographic section using polygon -- #
        lon_poly, lat_poly = create_section_polygon(
            lon_sec=lon_section,
            lat_sec=lat_section,
        )

        mask = self.mask_with_polygon(
            grid=grid_paths["gridT"], lon_poly=lon_poly, lat_poly=lat_poly
        )

        i_bdy, j_bdy, flux_type, flux_dir = get_mask_boundary(mask)

        # -- Create mask boundary dataset -- #
        ds_bdy = create_boundary_dataset(
            nemo=self,
            dom=dom,
            i_bdy=i_bdy,
            j_bdy=j_bdy,
            flux_type=flux_type,
            flux_dir=flux_dir,
        )

        # -- Get indexes of hydrographic section along mask boundary -- #
        sec_indexes = get_section_indexes(
            lon_section=lon_section,
            lat_section=lat_section,
            ds_bdy=ds_bdy,
        )

        # -- Update boundary dataset with extracted section data -- #
        ds_bdy = update_boundary_dataset(
            ds_bdy=ds_bdy,
            nemo=self,
            dom=dom,
            sec_indexes=sec_indexes,
            uv_vars=uv_vars,
            vars=vars,
        )

        return ds_bdy

    def binned_statistic(
        self,
        grid: str,
        vars: list[str],
        values: str,
        keep_dims: list[str] | None,
        bins: list[list | np.ndarray],
        statistic: str,
        mask: xr.DataArray | None,
    ) -> xr.DataArray:
        """
        Calculate binned statistic of a variable defined on a NEMO model grid.

        Parameters
        ----------
        grid : str
            Path to NEMO model grid where variables and values are stored
            (e.g., 'gridT').
        vars : list[str]
            Names of variable(s) to be grouped in discrete bins.
        values : str
            Name of the values with which to calculate binned statistic.
        keep_dims : list[str] | None
            Names of dimensions in values to keep as labels in binned statistic.
        bins : list[list | np.ndarray]
            Bin edges used to group each of the variables in `vars`.
        statistic : str
            Statistic to calculate (e.g., 'count', 'sum', 'nansum', 'mean', 'nanmean',
            'max', 'nanmax', 'min', 'nanmin'). See flox.xarray.xarray_reduce for a
            complete list of aggregation statistics.
        mask : xr.DataArray | None
            Boolean mask identifying NEMO model grid points to be included (1)
            or neglected (0) from calculation.

        Returns
        -------
        xr.DataArray
            Values of the selected statistic in each bin.

        Examples
        --------
        Compute the mean depth associated with each isopycnal in discrete potential
        density `sigma0` coordinates:

        >>> sigma0_bins = np.arange(22, 29.05, 0.05)

        >>> nemo.binned_statistic(grid="gridT",
        ...                       vars=["sigma0"],
        ...                       values="deptht",
        ...                       keep_dims=["time_counter"],
        ...                       bins=[sigma0_bins],
        ...                       statistic="nanmean",
        ...                       )

        See Also
        --------
        masked_statistic
        """
        # -- Validate input -- #
        grid_keys = list(dict(self.subtree_with_keys).keys())
        if grid not in grid_keys:
            raise KeyError(
                f"grid '{grid}' not found in available NEMODataTree grids {grid_keys}."
            )
        if any(var not in self[grid].data_vars for var in vars):
            raise KeyError(f"one or more variables {vars} not found in grid '{grid}'.")
        if values not in self[grid].data_vars:
            raise KeyError(f"values '{values}' not found in grid '{grid}'.")
        if keep_dims is not None:
            if any(dim not in self[grid][values].dims for dim in keep_dims):
                raise KeyError(
                    f"one or more dimensions {keep_dims} not found in values '{values}'."
                )
        if not all(isinstance(bin, (list, np.ndarray)) for bin in bins):
            raise ValueError("bins must be a list of lists or numpy arrays.")
        if statistic not in [
            "all",
            "any",
            "count",
            "sum",
            "nansum",
            "mean",
            "nanmean",
            "max",
            "nanmax",
            "min",
            "nanmin",
            "argmax",
            "nanargmax",
            "argmin",
            "nanargmin",
            "quantile",
            "nanquantile",
            "median",
            "nanmedian",
            "mode",
            "nanmode",
            "first",
            "nanfirst",
            "last",
            "nanlast",
        ]:
            raise ValueError(f"statistic '{statistic}' is not supported.")
        if mask is not None:
            if not isinstance(mask, xr.DataArray):
                raise ValueError("mask must be an xarray.DataArray.")
            if mask.dtype != bool:
                raise TypeError("mask dtype must be boolean.")
            if any(dim not in self[grid].dims for dim in mask.dims):
                raise ValueError(
                    f"mask must have dimensions subset from {self[grid].dims}."
                )

        # -- Calculate binned statistics -- #
        values_data = self[f"{grid}/{values}"].masked.data
        var_data = [self[f"{grid}/{var}"].masked.data for var in vars]

        result = compute_binned_statistic(
            vars=var_data,
            values=values_data,
            keep_dims=keep_dims,
            bins=bins,
            statistic=statistic,
            mask=mask,
        )

        return result

    @deprecated(version_since="2026.03.b1",
                version_removed="2026.05",
                alternative="NEMODataArray.transform_vertical_grid"
                )
    def transform_vertical_grid(
        self, grid: str, var: str, e3_new: xr.DataArray
    ) -> xr.Dataset:
        """
        Transform variable defined on a NEMO model grid to a new vertical grid using conservative interpolation.

        Parameters
        ----------
        grid : str
            Path to NEMO model grid where variable is stored
            (e.g., 'gridT').
        var : str
            Name of the variable to transform.
        e3_new : xarray.DataArray
            Grid cell thicknesses of the new vertical grid.
            Must be a 1-dimensional xarray.DataArray with
            dimension 'k_new'.

        Returns
        -------
        xr.Dataset
            Variable defined at the centre of each vertical
            grid cell on the new grid, and vertical grid cell
            thicknesses adjusted for model bathymetry.

        Examples
        --------
        Transform the conservative temperature variable `thetao_con` defined in a
        NEMO model parent domain from it's native 75 unevenly-spaced z-levels to
        regularly spaced z-levels at 200 m intervals:

        >>> e3t_target = xr.DataArray(np.repeat(200.0, 30), dims=['k_new'])

        >>> nemo.transform_vertical_grid(grid='gridT',
        ...                              var='thetao_con',
        ...                              e3_new=e3t_target
        ...                              )

        See Also
        --------
        transform_to
        """
        # -- Validate input -- #
        grid_keys = list(dict(self.subtree_with_keys).keys())
        if grid not in grid_keys:
            raise KeyError(
                f"grid '{grid}' not found in available NEMODataTree grids {grid_keys}."
            )
        if var not in self[grid].data_vars:
            raise KeyError(f"Variable '{var}' not found in grid '{grid}'.")
        if e3_new.dims != ("k_new",) or (e3_new.ndim != 1):
            raise ValueError(
                "e3_new must be a 1-dimensional xarray.DataArray with dimension 'k_new'."
            )

        # -- Get NEMO model grid properties -- #
        dom, _, _, grid_suffix = self._get_properties(grid=grid, infer_dom=True)
        ijk_names = self._get_ijk_names(dom=dom)
        i_name, j_name, k_name = ijk_names["i"], ijk_names["j"], ijk_names["k"]
        t_name = [dim for dim in self[grid].dims if "time" in dim][0]

        # -- Define input variables -- #
        var_in = self[f"{grid}/{var}"].masked.data
        e3_in = self[f"{grid}/e3{grid_suffix}"].masked.data
        if e3_new.sum(dim="k_new") < self[grid][f"depth{grid_suffix}"].max(dim=k_name):
            raise ValueError(
                f"e3_new must sum to at least the maximum depth ({self[grid][f'depth{grid_suffix}'].max(dim=k_name).item()} m) of the original vertical grid."
            )

        # -- Transform variable to target vertical grid -- #
        var_out, e3_out = xr.apply_ufunc(
            transform_vertical_coords,
            e3_in,
            var_in,
            e3_new.astype(e3_in.dtype),
            input_core_dims=[[k_name], [k_name], ["k_new"]],
            output_core_dims=[["k_new"], ["k_new"]],
            dask="parallelized",
            output_dtypes=[var_in.dtype, e3_in.dtype],
            dask_gufunc_kwargs={"output_sizes": {"k_new": e3_new.sizes["k_new"]}},
        )

        # -- Construct transformed variable Dataset -- #
        var_out = var_out.transpose(t_name, "k_new", j_name, i_name)

        ds_out = xr.Dataset(
            data_vars={var: var_out, f"e3{grid_suffix}_new": e3_out},
            coords={
                f"depth{grid_suffix}_new": ("k_new", e3_new.cumsum(dim="k_new").data)
            },
        )

        return ds_out

    @deprecated(version_since="2026.03.b1",
                version_removed="2026.05",
                alternative="NEMODataArray.interp_to"
                )
    def transform_to(
        self,
        grid: str,
        var: str,
        to: str,
    ) -> xr.DataArray:
        """
        Transform variable defined on a NEMO model grid to a neighbouring
        horizontal grid using linear interpolation.

        For flux variables defined at U- or V-points, the specified variable
        is first weighted by grid cell face areas prior to linear interpolation,
        and is then normalised by the target grid cell face areas following
        interpolation.

        Parameters
        ----------
        grid : str
            Path to NEMO model grid where variable is stored (e.g., 'gridT').
        var : str
            Name of the variable to transform.
        to : str
            Suffix of the neighbouring horizontal NEMO model grid to
            transform variable to. Options are 'T', 'U', 'V', 'F'.

        Returns
        -------
        xr.DataArray
            Values of variable linearly interpolated onto a neighbouring
            horizontal grid.

        Examples
        --------
        Transform conservative temperature `thetao_con` defined on scalar T-points
        to neighbouring V-points in a NEMO model parent domain:

        >>> nemo.transform_to(grid='gridT', var='thetao_con', to='V')

        See Also
        --------
        transform_vertical_grid
        """
        # -- Validate input -- #
        grid_keys = list(dict(self.subtree_with_keys).keys())
        if grid not in grid_keys:
            raise KeyError(
                f"grid '{grid}' not found in available NEMODataTree grids {grid_keys}."
            )
        if var not in self[grid].data_vars:
            raise KeyError(f"variable '{var}' not found in grid '{grid}'.")
        if not isinstance(to, str):
            raise TypeError(f"'to' must be a string, got {type(to)}.")
        if to not in ["T", "U", "V", "F"]:
            raise ValueError(f"'to' must be one of ['T', 'U', 'V', 'F'], got {to}.")

        # -- Get NEMO model grid properties -- #
        _, dom_prefix, _, grid_suffix = self._get_properties(grid=grid, infer_dom=True)
        ijk_names = self._get_ijk_names(grid=grid)
        i_name, j_name, k_name = ijk_names["i"], ijk_names["j"], ijk_names["k"]
        iperio = self[grid].attrs.get("iperio", False)
        target_grid = f"{grid.replace(grid[-1], to)}"

        # -- Prepare variable for linear interpolation -- #
        if grid_suffix.upper() in ["U", "V"]:
            weight_dims = (
                [k_name, j_name] if grid_suffix.upper() == "U" else [k_name, i_name]
            )
            if f"{dom_prefix}depth{grid_suffix}" in self[grid][var].coords:
                # 3-D variables - weight by grid cell face area:
                weights = self._get_weights(grid=grid, dims=weight_dims, fillna=False)
                target_weights = self._get_weights(
                    grid=target_grid, dims=weight_dims, fillna=False
                )
            else:
                # 2-D variables - weight by grid cell width:
                weights = self._get_weights(grid=grid, dims=weight_dims[1], fillna=False)
                target_weights = self._get_weights(
                    grid=target_grid, dims=weight_dims[1], fillna=False
                )
            da = self[f"{grid}/{var}"].masked.data * weights
        else:
            # Scalar variables:
            da = self[f"{grid}/{var}"].masked.data

        # -- Linearly interpolate variable -- #
        # Define source grid mask:
        if f"{dom_prefix}depth{grid_suffix}" in da.coords:
            mask = self[grid][f"{grid_suffix}mask"]
        else:
            mask = self[grid][f"{grid_suffix}maskutil"]

        result = interpolate_grid(
            da=da,
            mask=mask,
            source_grid=grid[-1],
            target_grid=target_grid[-1],
            iperio=iperio,
            ijk_names=ijk_names,
        )

        # -- Update interpolated variable -- #
        # Retain input variable name:
        result.name = da.name
        # Reorder dimensions (time_counter, [k], j, i):
        new_dims = (result.dims[-1], *result.dims[:-1])
        result = result.transpose(*new_dims)

        # Update NEMO grid coords:
        result[i_name] = self[target_grid][i_name]
        result[j_name] = self[target_grid][j_name]
        if k_name in result.dims:
            result[k_name] = self[target_grid][k_name]

        # Drop NEMO source grid coords:
        drop_vars = [f"{dom_prefix}glam{grid_suffix}", f"{dom_prefix}gphi{grid_suffix}"]
        if f"{dom_prefix}depth{grid_suffix}" in da.coords:
            drop_vars.append(f"{dom_prefix}depth{grid_suffix}")
        result = result.drop_vars(drop_vars)

        # Normalise by target grid cell weights for flux variables:
        if grid_suffix.upper() in ["U", "V"]:
            result = result / target_weights

        # Apply target grid mask:
        if f"{dom_prefix}depth{grid_suffix}" in da.coords:
            target_mask = f"{to.lower()}mask"
        else:
            target_mask = f"{to.lower()}maskutil"
        result = result.where(self[target_grid][target_mask])

        return result
