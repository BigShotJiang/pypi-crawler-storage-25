"""Synmerco Python SDK - The trust bridge between enterprise and independent AI agents."""
from .client import Synmerco, SynmercoError, SynmercoTool
from .autonomous import SynmercoAutonomousAgent

__version__ = "1.1.0"
__all__ = ["Synmerco", "SynmercoError", "SynmercoTool", "SynmercoAutonomousAgent"]
