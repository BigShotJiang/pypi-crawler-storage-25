"""Programmatic API surface for Aegis.

The API stays thin: it translates HTTP-ish requests into package-level
lifecycles, delegates execution to the kernel, and returns inspectable JSON
shapes. No cognition, policy, or persistence logic lives here beyond wiring.
"""

from __future__ import annotations

from dataclasses import asdict, dataclass, is_dataclass, replace
from datetime import UTC, datetime
from pathlib import Path
import json
from typing import Any, Mapping
from uuid import uuid4

from apps.provider_runtime import (
    SurfaceModelProviderCapability,
    provider_profile_from_payload,
)
from packages.auth import AuthProfile, PersistentAuthProfileStore
from packages.context import ContextRuntime
from packages.contracts import ContextBundle, EventEnvelope, ExecutionResult, GoalNode, MemoryRecord, ProfileState, SessionState, WorkGraph
from packages.kernel import KernelDependencies, KernelOutcome, KernelService, KernelTurnRequest, ObservationPipeline, StateReconciler
from packages.memory import MemoryRuntime
from packages.planning import PlanningService
from packages.session import SessionLineageService, SessionResumeResult
from packages.storage import RuntimeStorageRepository
from packages.tools import BuiltinToolDependencies, build_tool_runtime
from packages.tools.adapters import DeliveryMessageSurfaceAdapter, StructuredClarifySurface
from packages.tools.browser_backend import create_playwright_browser_backend

from .capabilities import (
    APIContextCapability,
    APIDeliveryCapability,
    APIMemoryCapability,
    APIModelProvider,
    APIPlanningCapability,
    APITelemetrySink,
    APIToolExecution,
)
from .state_runtime import APIContinuityInspection, APIStateService
from .tool_surfaces import (
    APIGoalManagementSurface,
    APIIdentityManagementSurface,
    APIMemoryManagementSurface,
    APIRelationshipManagementSurface,
    APIUserManagementSurface,
)


def _now() -> datetime:
    return datetime.now(UTC)


def _jsonable(value: Any) -> Any:
    if is_dataclass(value):
        return _jsonable(asdict(value))
    if isinstance(value, datetime):
        return value.isoformat()
    if isinstance(value, Mapping):
        return {str(key): _jsonable(item) for key, item in value.items()}
    if isinstance(value, tuple):
        return [_jsonable(item) for item in value]
    if isinstance(value, list):
        return [_jsonable(item) for item in value]
    if isinstance(value, set):
        return [_jsonable(item) for item in sorted(value, key=repr)]
    return value


def _json_bytes(payload: Mapping[str, Any]) -> bytes:
    return json.dumps(_jsonable(payload), separators=(",", ":"), sort_keys=True).encode("utf-8")


def _read_json_bytes(body: bytes | None) -> dict[str, Any]:
    if not body:
        return {}
    data = json.loads(body.decode("utf-8"))
    if not isinstance(data, dict):
        raise ValueError("request body must be a JSON object")
    return data


def _split_path(path: str) -> tuple[str, ...]:
    trimmed = path.strip("/")
    if not trimmed:
        return ()
    parts = tuple(part for part in trimmed.split("/") if part)
    if parts and parts[0] == "v1":
        return parts[1:]
    return parts


def _coerce_str_tuple(value: Any) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, str):
        if not value.strip():
            return ()
        return tuple(part.strip() for part in value.split(",") if part.strip())
    if isinstance(value, (list, tuple)):
        return tuple(str(item) for item in value if str(item))
    return (str(value),)


def _optional_str(value: Any) -> str | None:
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _optional_datetime(value: Any) -> datetime | None:
    text = _optional_str(value)
    if text is None:
        return None
    return datetime.fromisoformat(text)


def _optional_bool(value: Any) -> bool | None:
    if value is None:
        return None
    if isinstance(value, bool):
        return value
    text = _optional_str(value)
    if text is None:
        return None
    normalized = text.lower()
    if normalized in {"true", "1", "yes", "on"}:
        return True
    if normalized in {"false", "0", "no", "off"}:
        return False
    raise ValueError(f"invalid boolean value: {value}")


@dataclass(frozen=True, slots=True)
class APIAppConfig:
    database_path: Path
    instruction_refs: tuple[str, ...] = ("apps/api",)
    total_tokens: int = 2048


@dataclass(frozen=True, slots=True)
class APITurnRecord:
    request: dict[str, Any]
    outcome: KernelOutcome
    recorded_at: datetime

    def to_record(self) -> dict[str, Any]:
        return {
            "request": self.request,
            "outcome": self.outcome,
            "recorded_at": self.recorded_at,
        }


@dataclass(frozen=True, slots=True)
class APISessionInspection:
    profile: ProfileState
    session: SessionState
    lineage: tuple[SessionState, ...]
    goals: tuple[GoalNode, ...]
    memories: tuple[MemoryRecord, ...]
    latest_turn: APITurnRecord | None
    memory_count: int
    telemetry_count: int
    goal_graph_revision: str | None = None
    goal_status_counts: dict[str, int] | None = None
    provider_profile: AuthProfile | None = None

    def to_record(self) -> dict[str, Any]:
        return {
            "profile": self.profile,
            "session": self.session,
            "lineage": self.lineage,
            "goals": self.goals,
            "memories": self.memories,
            "latest_turn": self.latest_turn,
            "memory_count": self.memory_count,
            "telemetry_count": self.telemetry_count,
            "goal_graph_revision": self.goal_graph_revision,
            "goal_status_counts": self.goal_status_counts,
            "provider_profile": self.provider_profile,
        }


@dataclass(frozen=True, slots=True)
class APISessionCreationResult:
    profile: ProfileState
    session: SessionState

    def to_record(self) -> dict[str, Any]:
        return {
            "profile": self.profile,
            "session": self.session,
        }


@dataclass(frozen=True, slots=True)
class APISessionLifecycleResult:
    session: SessionState

    def to_record(self) -> dict[str, Any]:
        return {"session": self.session}


@dataclass(frozen=True, slots=True)
class APIResumeResult:
    parent: SessionState
    session: SessionState
    lineage: tuple[SessionState, ...]

    def to_record(self) -> dict[str, Any]:
        return {
            "parent": self.parent,
            "session": self.session,
            "lineage": self.lineage,
        }


@dataclass(frozen=True, slots=True)
class APITurnResult:
    session: SessionState
    outcome: KernelOutcome
    latest_turn: APITurnRecord
    inspection: APISessionInspection

    def to_record(self) -> dict[str, Any]:
        return {
            "session": self.session,
            "outcome": self.outcome,
            "latest_turn": self.latest_turn,
            "inspection": self.inspection,
        }


@dataclass(frozen=True, slots=True)
class APIResponse:
    status_code: int
    payload: Mapping[str, Any]
    headers: tuple[tuple[str, str], ...] = (("content-type", "application/json; charset=utf-8"),)

class AegisAPIApp:
    def __init__(self, config: APIAppConfig) -> None:
        self.config = config
        self.repository = RuntimeStorageRepository(config.database_path)
        self.repository.bootstrap()
        self.auth_store = PersistentAuthProfileStore(self.repository)
        self.session_lineage = SessionLineageService(self.repository)
        self.memory_runtime = MemoryRuntime.from_repository(self.repository)
        self.context_runtime = ContextRuntime(instruction_refs=config.instruction_refs, total_tokens=config.total_tokens)
        self.planning_service = PlanningService()
        self.personal_state = APIStateService(
            repository=self.repository,
            session_lineage=self.session_lineage,
            memory_runtime=self.memory_runtime,
            planning_service=self.planning_service,
        )
        self.telemetry = APITelemetrySink()
        self.preview_model_provider = APIModelProvider()
        self.delivery = APIDeliveryCapability()
        self.memory = APIMemoryCapability(self.memory_runtime)
        self.context = APIContextCapability(self.context_runtime)
        self.planning = APIPlanningCapability(self.planning_service)
        browser_backend, _ = create_playwright_browser_backend()
        self.tool_runtime = build_tool_runtime(
            enabled_overrides={},
            dependencies=BuiltinToolDependencies(
                cwd=Path.cwd(),
                identity_management=APIIdentityManagementSurface(self.personal_state),
                user_management=APIUserManagementSurface(self.personal_state),
                relationship_management=APIRelationshipManagementSurface(self.personal_state),
                goal_management=APIGoalManagementSurface(self),
                memory_management=APIMemoryManagementSurface(self),
                browser_backend=browser_backend,
                message_delivery=DeliveryMessageSurfaceAdapter(
                    self.delivery,
                    surface_label="api",
                    default_target="api",
                ),
                clarify_surface=StructuredClarifySurface(
                    surface_label="api",
                    extra_metadata={"transport": "http"},
                ),
            ),
        )
        self.tools = APIToolExecution(self.tool_runtime)
        self.model_provider = SurfaceModelProviderCapability(
            repository=self.repository,
            fallback=self.preview_model_provider,
            secret_key_path=self.repository.database_path.parent / "provider-secrets.key",
            tool_runtime=self.tool_runtime,
            capability_id="api.model.runtime",
            surface_label="api",
        )
        self.kernel = KernelService(
            dependencies=KernelDependencies(
                storage=self.repository,
                context=self.context,
                planning=self.planning,
                memory=self.memory,
                model_provider=self.model_provider,
                telemetry=self.telemetry,
                tools=self.tools,
                delivery=self.delivery,
            )
        )
        self._turns: dict[str, list[APITurnRecord]] = {}

    def list_providers(self) -> dict[str, Any]:
        return {
            "active_provider": self.model_provider.describe(),
            "providers": [record.as_mapping() for record in self.model_provider.runtime_resolver.list_catalog()],
        }

    def setup_provider(self, provider_id: str) -> dict[str, Any]:
        guide = self.model_provider.runtime_resolver.build_setup_guide(provider_id)
        return {
            "active_provider": self.model_provider.describe(),
            "guide": guide.as_mapping(),
        }

    def set_default_provider(self, provider_profile: Mapping[str, Any]) -> dict[str, Any]:
        active_profile = provider_profile_from_payload(provider_profile)
        self.auth_store.register(active_profile)
        self.model_provider.set_active_profile(
            provider_profile_id=active_profile.profile_id,
            provider_id=active_profile.provider_id,
        )
        return {
            "provider_profile": active_profile,
            "active_provider": self.model_provider.describe(),
        }

    def _provider_probe(
        self,
        *,
        prompt: str,
    ) -> ExecutionResult:
        active_profile = self.model_provider.active_profile()
        profile = ProfileState(
            profile_id=f"provider-test:{active_profile.provider_id if active_profile is not None else 'preview'}",
            display_name=active_profile.provider_id if active_profile is not None else "Provider Test",
            mode="default",
        )
        session = SessionState(
            session_id=f"session:provider-test:{uuid4().hex[:8]}",
            profile_id=profile.profile_id,
            workspace_id="provider-test",
            status="active",
            started_at=_now(),
            updated_at=_now(),
        )
        context = ContextBundle(
            bundle_id=f"bundle:provider-test:{uuid4().hex[:8]}",
            session_id=session.session_id,
            instruction_refs=("apps/api",),
            goal_ids=(),
            memory_ids=(),
            artifact_ids=(),
            token_budget=512,
            rendered_prompt="provider test",
        )
        return self.model_provider.generate(
            profile=profile,
            session=session,
            context=context,
            prompt=prompt,
        )

    def test_provider(self, *, prompt: str = "Summarize the current provider configuration.") -> dict[str, Any]:
        active_provider = self.model_provider.describe()
        try:
            result = self._provider_probe(prompt=prompt)
        except Exception as error:  # pragma: no cover - defensive surface guard
            return {
                "active_provider": active_provider,
                "status": "not-ready",
                "error": str(error),
            }
        return {
            "active_provider": active_provider,
            "status": "ok",
            "result": result,
        }

    def doctor_provider(self) -> dict[str, Any]:
        active_provider = self.model_provider.describe()
        if active_provider["source"] != "configured":
            return {
                "status": "preview",
                "active_provider": active_provider,
                "checks": (
                    {"check": "provider_profile", "status": "missing"},
                    {"check": "credentials", "status": "preview"},
                ),
                "probe_summary": "",
            }
        try:
            probe = self._provider_probe(prompt="Doctor check")
        except Exception as error:  # pragma: no cover - defensive surface guard
            return {
                "status": "not-ready",
                "active_provider": active_provider,
                "checks": (
                    {"check": "provider_profile", "status": "configured"},
                    {"check": "credentials", "status": "missing", "summary": str(error)},
                ),
                "probe_summary": "",
            }
        return {
            "status": "ready",
            "active_provider": active_provider,
            "checks": (
                {"check": "provider_profile", "status": "configured"},
                {"check": "credentials", "status": "available"},
                {"check": "runtime", "status": "ok", "summary": probe.summary},
            ),
            "probe_summary": probe.summary,
        }

    def create_session(
        self,
        *,
        profile_id: str,
        display_name: str,
        mode: str,
        workspace_id: str | None = None,
        clone_path: str | None = None,
        preferences: tuple[str, ...] = (),
        enabled_capabilities: tuple[str, ...] = (),
        provider_profile: Mapping[str, Any] | None = None,
        session_id: str | None = None,
    ) -> APISessionCreationResult:
        profile = ProfileState(
            profile_id=profile_id,
            display_name=display_name,
            mode=mode,
            clone_path=clone_path,
            preferences=preferences,
            enabled_capabilities=enabled_capabilities,
        )
        if provider_profile is not None:
            active_profile = provider_profile_from_payload(provider_profile)
            self.auth_store.register(active_profile)
            self.model_provider.set_active_profile(
                provider_profile_id=active_profile.profile_id,
                provider_id=active_profile.provider_id,
            )
        elif self.model_provider.active_profile() is None and self.auth_store.list():
            active_profile = self.auth_store.list()[0]
            self.model_provider.set_active_profile(
                provider_profile_id=active_profile.profile_id,
                provider_id=active_profile.provider_id,
            )
        session = self.session_lineage.start_session(
            profile,
            workspace_id=workspace_id,
            session_id=session_id,
        )
        self.personal_state.ensure_profile_state(profile, sync_source="api.create-session")
        return APISessionCreationResult(profile=profile, session=session)

    def interrupt_session(self, session_id: str, *, interruption_state: str) -> APISessionLifecycleResult:
        session = self.session_lineage.interrupt_session(session_id, interruption_state=interruption_state)
        return APISessionLifecycleResult(session=session)

    def resume_session(self, session_id: str, *, child_session_id: str | None = None) -> APIResumeResult:
        result: SessionResumeResult = self.session_lineage.resume_session(
            session_id,
            child_session_id=child_session_id,
        )
        return APIResumeResult(parent=result.parent, session=result.session, lineage=result.lineage)

    def _load_work_graph(self, session_id: str) -> WorkGraph:
        graph = self.repository.load_work_graph(session_id)
        if graph is None:
            raise KeyError(session_id)
        return graph

    def list_goals(self, session_id: str) -> tuple[GoalNode, ...]:
        graph = self.repository.load_work_graph(session_id)
        if graph is None:
            return ()
        return graph.goals

    def list_memories(self, session_id: str) -> tuple[MemoryRecord, ...]:
        return tuple(self.memory_runtime.store.list(session_id=session_id))

    def inspect_identity(self, *, session_id: str | None = None, profile_id: str | None = None):
        return self.personal_state.inspect_identity(session_id=session_id, profile_id=profile_id)

    def update_identity_state(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
        display_name: str | None = None,
        personality_preset: str | None = None,
        initiative: str | None = None,
        charter_text: str | None = None,
        clear_charter: bool = False,
    ):
        return self.personal_state.update_identity_state(
            session_id=session_id,
            profile_id=profile_id,
            display_name=display_name,
            personality_preset=personality_preset,
            initiative=initiative,
            charter_text=charter_text,
            clear_charter=clear_charter,
        )

    def inspect_user(self, *, session_id: str | None = None, profile_id: str | None = None):
        return self.personal_state.inspect_user(session_id=session_id, profile_id=profile_id)

    def update_user_state(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
        text: str | None = None,
        fields: dict[str, object] | None = None,
        append: bool = False,
        clear: bool = False,
    ):
        return self.personal_state.update_user_state(
            session_id=session_id,
            profile_id=profile_id,
            text=text,
            fields=fields,
            append=append,
            clear=clear,
        )

    def inspect_relationship(self, *, session_id: str | None = None, profile_id: str | None = None):
        return self.personal_state.inspect_relationship(session_id=session_id, profile_id=profile_id)

    def update_relationship_state(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
        text: str | None = None,
        append: bool = False,
        clear: bool = False,
    ):
        return self.personal_state.update_relationship_state(
            session_id=session_id,
            profile_id=profile_id,
            text=text,
            append=append,
            clear=clear,
        )

    def inspect_continuity(self, session_id: str) -> APIContinuityInspection:
        return self.personal_state.inspect_continuity(session_id)

    def inspect_session(self, session_id: str) -> APISessionInspection:
        session = self.repository.load_session(session_id)
        if session is None:
            raise KeyError(session_id)
        profile = self.repository.load_profile(session.profile_id)
        if profile is None:
            raise KeyError(session.profile_id)
        lineage = self.repository.lineage(session_id)
        latest_turn = self._turns.get(session_id, [])[-1] if self._turns.get(session_id) else None
        graph = self.repository.load_work_graph(session_id)
        goals = graph.goals if graph is not None else ()
        memories = tuple(self.memory_runtime.store.list(session_id=session_id))
        memory_count = len(memories)
        telemetry_count = len(self.telemetry.events)
        provider_profile = self.model_provider.active_profile()
        return APISessionInspection(
            profile=profile,
            session=session,
            lineage=lineage,
            goals=goals,
            memories=memories,
            latest_turn=latest_turn,
            memory_count=memory_count,
            telemetry_count=telemetry_count,
            goal_graph_revision=graph.revision_id if graph is not None else None,
            goal_status_counts=graph.status_counts() if graph is not None else {},
            provider_profile=provider_profile,
        )

    def inspect_goal(self, session_id: str, goal_id: str) -> dict[str, Any]:
        graph = self._load_work_graph(session_id)
        goal = graph.goal(goal_id)
        if goal is None:
            raise KeyError(goal_id)
        return {
            "session_id": session_id,
            "goal": goal,
            "goal_graph_revision": graph.revision_id,
            "goal_graph_updated_at": graph.updated_at,
            "goal_status_counts": graph.status_counts(),
            "goal_graph": graph,
        }

    def create_goal(
        self,
        session_id: str,
        *,
        title: str,
        status: str = "active",
        priority: str = "medium",
        owner: str = "shared",
        parent_goal_id: str | None = None,
        dependency_refs: Any = None,
        evidence_refs: Any = None,
        related_memory_ids: Any = None,
        review_checkpoint: str | None = None,
        deadline: Any = None,
        time_sensitivity: str | None = None,
        reason: str | None = None,
        activate: bool | None = None,
    ) -> dict[str, Any]:
        normalized_title = title.strip()
        if not normalized_title:
            raise ValueError("goal title is required")
        updated_at = _now()
        revision_id = f"goal:create:{uuid4().hex}"
        graph = self.repository.load_work_graph(session_id) or WorkGraph(session_id=session_id)
        root_goal_id = graph.root_goal_id or graph.active_goal_id or (graph.goals[0].goal_id if graph.goals else None)
        activate_goal = (status == "active") if activate is None else _optional_bool(activate)
        if activate_goal is None:
            activate_goal = status == "active"
        dependency_values = _coerce_str_tuple(dependency_refs) if dependency_refs is not None else ()
        evidence_values = _coerce_str_tuple(evidence_refs) if evidence_refs is not None else ()
        related_values = _coerce_str_tuple(related_memory_ids) if related_memory_ids is not None else ()
        new_goal = GoalNode(
            goal_id=f"goal:{uuid4().hex[:12]}",
            session_id=session_id,
            title=normalized_title,
            status="active" if activate_goal else str(status),
            priority=str(priority),
            owner=owner,
            parent_goal_id=parent_goal_id if parent_goal_id is not None else (root_goal_id if graph.goals else None),
            dependencies=dependency_values,
            evidence_refs=evidence_values,
            related_memory_ids=related_values,
            deadline=_optional_datetime(deadline),
            time_sensitivity="normal" if time_sensitivity is None else str(time_sensitivity),
            review_checkpoint=review_checkpoint,
            revision_id=revision_id,
            updated_at=updated_at,
        )
        active_goal = graph.active_goal()
        if activate_goal and active_goal is not None and active_goal.goal_id != new_goal.goal_id and active_goal.status == "active":
            graph = graph.transition_goal(
                active_goal.goal_id,
                status="queued",
                revision_id=revision_id,
                updated_at=updated_at,
                active_goal_id=active_goal.goal_id,
            )
        graph = graph.with_goal(new_goal)
        graph = replace(
            graph,
            root_goal_id=root_goal_id if root_goal_id is not None else new_goal.goal_id,
            active_goal_id=new_goal.goal_id if activate_goal else graph.active_goal_id,
            revision_id=revision_id,
        )
        self.repository.upsert_work_graph(graph)
        created = graph.goal(new_goal.goal_id)
        if created is None:
            raise KeyError(new_goal.goal_id)
        return {
            "session_id": session_id,
            "reason": reason or "goal created",
            "goal": created,
            "goal_graph": graph,
        }

    def inspect_memory(self, session_id: str, memory_id: str) -> dict[str, Any]:
        memory = self.memory_runtime.store.get(memory_id)
        if memory is None or memory.session_id != session_id:
            raise KeyError(memory_id)
        return {
            "session_id": session_id,
            "memory": memory,
            "memory_state": self.memory_runtime.store.state(memory_id),
            "memory_lineage": self.memory_runtime.store.lineage(memory_id),
        }

    def update_goal(
        self,
        session_id: str,
        goal_id: str,
        *,
        title: str | None = None,
        status: str | None = None,
        priority: str | None = None,
        owner: str | None = None,
        dependency_refs: Any = None,
        evidence_refs: Any = None,
        related_memory_ids: Any = None,
        review_checkpoint: str | None = None,
        deadline: Any = None,
        time_sensitivity: str | None = None,
        reason: str | None = None,
    ) -> dict[str, Any]:
        graph = self._load_work_graph(session_id)
        goal = graph.goal(goal_id)
        if goal is None:
            raise KeyError(goal_id)
        original_goal = goal

        transition_dependencies = _coerce_str_tuple(dependency_refs) if dependency_refs is not None else None
        transition_evidence = _coerce_str_tuple(evidence_refs) if evidence_refs is not None else None
        transition_related = _coerce_str_tuple(related_memory_ids) if related_memory_ids is not None else None
        if status is not None or transition_dependencies is not None or transition_evidence is not None or transition_related is not None or review_checkpoint is not None:
            graph = graph.transition_goal(
                goal_id,
                status=goal.status if status is None else str(status),
                revision_id=f"goal:update:{uuid4().hex}",
                updated_at=_now(),
                dependencies=transition_dependencies,
                evidence_refs=transition_evidence,
                related_memory_ids=transition_related,
                review_checkpoint=review_checkpoint,
            )
            goal = graph.goal(goal_id)
            if goal is None:
                raise KeyError(goal_id)

        updated_goal = replace(
            goal,
            title=goal.title if title is None else title,
            priority=goal.priority if priority is None else str(priority),
            owner=goal.owner if owner is None else owner,
            parent_goal_id=goal.parent_goal_id,
            dependencies=goal.dependencies if transition_dependencies is None else transition_dependencies,
            evidence_refs=goal.evidence_refs if transition_evidence is None else transition_evidence,
            related_memory_ids=goal.related_memory_ids if transition_related is None else transition_related,
            deadline=goal.deadline if deadline is None else _optional_datetime(deadline),
            time_sensitivity=goal.time_sensitivity if time_sensitivity is None else str(time_sensitivity),
            review_checkpoint=goal.review_checkpoint if review_checkpoint is None else review_checkpoint,
            revision_id=f"goal:update:{uuid4().hex}",
            updated_at=_now(),
        )
        graph = graph.with_goal(updated_goal)
        self.repository.upsert_work_graph(graph)
        return {
            "session_id": session_id,
            "reason": reason or "goal updated",
            "before": original_goal,
            "goal": updated_goal,
            "goal_graph": graph,
        }

    def delete_goal(self, session_id: str, goal_id: str, *, reason: str = "") -> dict[str, Any]:
        graph = self._load_work_graph(session_id)
        goal = graph.goal(goal_id)
        if goal is None:
            raise KeyError(goal_id)
        updated_graph = graph.transition_goal(
            goal_id,
            status="dropped",
            revision_id=f"goal:delete:{uuid4().hex}",
            updated_at=_now(),
        )
        self.repository.upsert_work_graph(updated_graph)
        updated_goal = updated_graph.goal(goal_id)
        if updated_goal is None:
            raise KeyError(goal_id)
        return {
            "session_id": session_id,
            "reason": reason or "goal deleted",
            "before": goal,
            "goal": updated_goal,
            "goal_graph": updated_graph,
        }

    def correct_memory(
        self,
        session_id: str,
        memory_id: str,
        *,
        corrected_content: str,
        reason: str = "",
        actor: str = "user",
    ) -> dict[str, Any]:
        result = self.memory_runtime.correct_memory(memory_id, corrected_content, actor=actor, reason=reason)
        if result.decision.target_memory_id is None:
            raise KeyError(memory_id)
        original = self.memory_runtime.store.get(memory_id)
        if original is None or original.session_id != session_id:
            raise KeyError(memory_id)
        return {
            "session_id": session_id,
            "decision": result.decision,
            "memory": result.record,
            "memory_state": self.memory_runtime.store.state(memory_id),
            "memory_lineage": self.memory_runtime.store.lineage(memory_id),
        }

    def delete_memory(
        self,
        session_id: str,
        memory_id: str,
        *,
        reason: str,
        actor: str = "user",
    ) -> dict[str, Any]:
        original = self.memory_runtime.store.get(memory_id)
        if original is None or original.session_id != session_id:
            raise KeyError(memory_id)
        result = self.memory_runtime.delete_memory(memory_id, actor=actor, reason=reason)
        return {
            "session_id": session_id,
            "decision": result.decision,
            "memory": original,
            "memory_state": self.memory_runtime.store.state(memory_id),
            "memory_lineage": self.memory_runtime.store.lineage(memory_id),
        }

    def run_turn(
        self,
        session_id: str,
        *,
        prompt: str,
        goal_query: str | None = None,
        tool_name: str | None = None,
        tool_arguments: Mapping[str, Any] | None = None,
        delivery_payload: Mapping[str, Any] | None = None,
    ) -> APITurnResult:
        session = self.repository.load_session(session_id)
        if session is None:
            raise KeyError(session_id)
        profile = self.repository.load_profile(session.profile_id)
        if profile is None:
            raise KeyError(session.profile_id)
        previous_goal_graph = self.repository.load_work_graph(session_id) or WorkGraph(session_id=session_id)
        event = EventEnvelope(
            event_id=f"api:{session_id}:turn:{uuid4().hex}",
            event_type="turn.received",
            session_id=session_id,
            source="api",
            payload={
                "message": prompt,
                "content": prompt,
                "summary": prompt,
                "goal_query": goal_query or "",
                "tool_name": tool_name or "",
            },
        )
        outcome = self.kernel.run(
            KernelTurnRequest(
                event=event,
                prompt=prompt,
                goal_query=goal_query,
                tool_name=tool_name,
                tool_arguments=dict(tool_arguments or {}),
                delivery_payload=dict(delivery_payload or {}),
            )
        )
        observation = ObservationPipeline().observe_turn(
            inbound_event=event,
            execution=outcome.execution,
            previous_goal_graph=previous_goal_graph,
            reconciled_goal_graph=outcome.goal_graph,
            selected_goal_id=(
                outcome.decision.selected_move.goal_id
                if outcome.decision is not None and outcome.decision.selected_move.goal_id
                else outcome.goal_graph.active_goal_id
            ),
            decision_summary=(
                outcome.decision.rationale.summary
                if outcome.decision is not None and outcome.decision.rationale.summary.strip()
                else outcome.execution.summary
            ),
            source="api",
        )
        StateReconciler().reconcile_turn(
            repository=self.repository,
            memory_runtime=self.memory_runtime,
            observation=observation,
        )
        self.personal_state.apply_turn_profile_delta(
            session_id=session_id,
            user_fields=dict(observation.profile_delta.user_fields),
            preference_updates=observation.profile_delta.preference_updates,
            relationship_notes=observation.profile_delta.relationship_notes,
        )
        record = APITurnRecord(
            request={
                "prompt": prompt,
                "goal_query": goal_query,
                "tool_name": tool_name,
                "tool_arguments": dict(tool_arguments or {}),
                "delivery_payload": dict(delivery_payload or {}),
            },
            outcome=outcome,
            recorded_at=_now(),
        )
        self._turns.setdefault(session_id, []).append(record)
        inspection = self.inspect_session(session_id)
        return APITurnResult(
            session=inspection.session,
            outcome=outcome,
            latest_turn=record,
            inspection=inspection,
        )

    def dispatch(self, method: str, path: str, body: bytes | None = None) -> APIResponse:
        if method.upper() == "GET" and path == "/healthz":
            return APIResponse(200, {"status": "ok", "service": "aegis-api"})

        try:
            parts = _split_path(path)
            if not parts:
                return APIResponse(404, {"error": "not_found"})
            if parts[0] == "providers":
                return self._dispatch_providers(method, parts[1:], body)
            if parts[0] != "sessions":
                return APIResponse(404, {"error": "not_found"})
            if method.upper() == "POST" and len(parts) == 1:
                payload = _read_json_bytes(body)
                result = self.create_session(
                    profile_id=str(payload["profile_id"]),
                    display_name=str(payload["display_name"]),
                    mode=str(payload["mode"]),
                    workspace_id=payload.get("workspace_id"),
                    clone_path=payload.get("clone_path"),
                    preferences=tuple(payload.get("preferences", ())),
                    enabled_capabilities=tuple(payload.get("enabled_capabilities", ())),
                    provider_profile=payload.get("provider_profile"),
                    session_id=payload.get("session_id"),
                )
                return APIResponse(201, _jsonable(result.to_record()))
            if len(parts) < 2:
                return APIResponse(404, {"error": "not_found"})
            session_id = parts[1]
            if method.upper() == "GET" and len(parts) == 2:
                return APIResponse(200, _jsonable(self.inspect_session(session_id).to_record()))
            if method.upper() == "POST" and len(parts) == 3 and parts[2] == "interrupt":
                payload = _read_json_bytes(body)
                result = self.interrupt_session(session_id, interruption_state=str(payload["interruption_state"]))
                return APIResponse(200, _jsonable(result.to_record()))
            if method.upper() == "POST" and len(parts) == 3 and parts[2] == "resume":
                payload = _read_json_bytes(body)
                result = self.resume_session(session_id, child_session_id=payload.get("child_session_id"))
                return APIResponse(200, _jsonable(result.to_record()))
            if method.upper() == "POST" and len(parts) == 3 and parts[2] == "turns":
                payload = _read_json_bytes(body)
                result = self.run_turn(
                    session_id,
                    prompt=str(payload["prompt"]),
                    goal_query=payload.get("goal_query"),
                    tool_name=payload.get("tool_name"),
                    tool_arguments=payload.get("tool_arguments"),
                    delivery_payload=payload.get("delivery_payload"),
                )
                return APIResponse(200, _jsonable(result.to_record()))
            if len(parts) == 3 and parts[2] in {"identity", "user", "relationship", "continuity"}:
                surface = parts[2]
                if surface == "identity":
                    if method.upper() == "GET":
                        return APIResponse(200, _jsonable({"session_id": session_id, "identity": self.inspect_identity(session_id=session_id)}))
                    if method.upper() in {"PATCH", "POST"}:
                        payload = _read_json_bytes(body)
                        result = self.update_identity_state(
                            session_id=session_id,
                            display_name=_optional_str(payload.get("display_name") or payload.get("name")),
                            personality_preset=_optional_str(payload.get("personality_preset")),
                            initiative=_optional_str(payload.get("initiative")),
                            charter_text=_optional_str(payload.get("charter_text") or payload.get("text") or payload.get("content")),
                            clear_charter=bool(payload.get("clear_charter", False)),
                        )
                        return APIResponse(200, _jsonable({"session_id": session_id, "identity": result}))
                if surface == "user":
                    if method.upper() == "GET":
                        return APIResponse(200, _jsonable({"session_id": session_id, "user": self.inspect_user(session_id=session_id)}))
                    if method.upper() in {"PATCH", "POST"}:
                        payload = _read_json_bytes(body)
                        result = self.update_user_state(
                            session_id=session_id,
                            text=_optional_str(payload.get("text") or payload.get("content")),
                            fields=payload.get("fields") if isinstance(payload.get("fields"), dict) else None,
                            append=bool(payload.get("append", False)),
                            clear=bool(payload.get("clear", False)),
                        )
                        return APIResponse(200, _jsonable({"session_id": session_id, "user": result}))
                if surface == "relationship":
                    if method.upper() == "GET":
                        return APIResponse(200, _jsonable({"session_id": session_id, "relationship": self.inspect_relationship(session_id=session_id)}))
                    if method.upper() in {"PATCH", "POST"}:
                        payload = _read_json_bytes(body)
                        result = self.update_relationship_state(
                            session_id=session_id,
                            text=_optional_str(payload.get("text") or payload.get("content")),
                            append=bool(payload.get("append", False)),
                            clear=bool(payload.get("clear", False)),
                        )
                        return APIResponse(200, _jsonable({"session_id": session_id, "relationship": result}))
                if surface == "continuity" and method.upper() == "GET":
                    return APIResponse(200, _jsonable(self.inspect_continuity(session_id).to_record()))
            if len(parts) == 3 and parts[2] in {"goals", "memories"}:
                if parts[2] == "goals":
                    if method.upper() == "GET":
                        return APIResponse(200, _jsonable({"session_id": session_id, "goals": self.list_goals(session_id)}))
                    if method.upper() == "POST":
                        payload = _read_json_bytes(body)
                        result = self.create_goal(
                            session_id,
                            title=str(payload["title"]),
                            status=str(payload.get("status", "active")),
                            priority=str(payload.get("priority", "medium")),
                            owner=str(payload.get("owner", "shared")),
                            parent_goal_id=_optional_str(payload.get("parent_goal_id")),
                            dependency_refs=payload.get("dependency_refs"),
                            evidence_refs=payload.get("evidence_refs"),
                            related_memory_ids=payload.get("related_memory_ids"),
                            review_checkpoint=_optional_str(payload.get("review_checkpoint")),
                            deadline=payload.get("deadline"),
                            time_sensitivity=_optional_str(payload.get("time_sensitivity")),
                            reason=_optional_str(payload.get("reason")),
                            activate=_optional_bool(payload.get("activate")),
                        )
                        return APIResponse(201, _jsonable(result))
                if method.upper() == "GET":
                    return APIResponse(200, _jsonable({"session_id": session_id, "memories": self.list_memories(session_id)}))
            if len(parts) == 4 and parts[2] == "goals":
                goal_id = parts[3]
                if method.upper() == "GET":
                    return APIResponse(200, _jsonable(self.inspect_goal(session_id, goal_id)))
                payload = _read_json_bytes(body)
                if method.upper() in {"PATCH", "POST"}:
                    result = self.update_goal(
                        session_id,
                        goal_id,
                        title=payload.get("title"),
                        status=payload.get("status"),
                        priority=payload.get("priority"),
                        owner=payload.get("owner"),
                        dependency_refs=payload.get("dependency_refs"),
                        evidence_refs=payload.get("evidence_refs"),
                        related_memory_ids=payload.get("related_memory_ids"),
                        review_checkpoint=payload.get("review_checkpoint"),
                        deadline=payload.get("deadline"),
                        time_sensitivity=payload.get("time_sensitivity"),
                        reason=payload.get("reason"),
                    )
                    return APIResponse(200, _jsonable(result))
                if method.upper() == "DELETE":
                    result = self.delete_goal(session_id, goal_id, reason=str(payload.get("reason", "")))
                    return APIResponse(200, _jsonable(result))
            if len(parts) == 4 and parts[2] == "memories":
                memory_id = parts[3]
                if method.upper() == "GET":
                    return APIResponse(200, _jsonable(self.inspect_memory(session_id, memory_id)))
                payload = _read_json_bytes(body)
                if method.upper() in {"PATCH", "POST"}:
                    result = self.correct_memory(
                        session_id,
                        memory_id,
                        corrected_content=str(payload["corrected_content"]),
                        reason=str(payload.get("reason", "")),
                        actor=str(payload.get("actor", "user")),
                    )
                    return APIResponse(200, _jsonable(result))
                if method.upper() == "DELETE":
                    result = self.delete_memory(
                        session_id,
                        memory_id,
                        reason=str(payload.get("reason", "")),
                        actor=str(payload.get("actor", "user")),
                    )
                    return APIResponse(200, _jsonable(result))
            return APIResponse(404, {"error": "not_found"})
        except KeyError as error:
            return APIResponse(404, {"error": "not_found", "missing": str(error)})
        except (ValueError, TypeError) as error:
            return APIResponse(400, {"error": "bad_request", "detail": str(error)})

    def _dispatch_providers(self, method: str, parts: tuple[str, ...], body: bytes | None) -> APIResponse:
        if method.upper() == "GET" and len(parts) == 0:
            return APIResponse(200, _jsonable(self.list_providers()))
        if method.upper() == "GET" and len(parts) == 1 and parts[0] == "doctor":
            return APIResponse(200, _jsonable(self.doctor_provider()))
        if method.upper() == "GET" and len(parts) == 2 and parts[0] == "setup":
            return APIResponse(200, _jsonable(self.setup_provider(parts[1])))
        if method.upper() == "POST" and len(parts) == 1 and parts[0] == "default":
            payload = _read_json_bytes(body)
            provider_profile = payload.get("provider_profile")
            if isinstance(provider_profile, dict):
                result = self.set_default_provider(provider_profile)
            else:
                result = self.set_default_provider(payload)
            return APIResponse(200, _jsonable(result))
        if method.upper() == "POST" and len(parts) == 1 and parts[0] == "test":
            payload = _read_json_bytes(body)
            result = self.test_provider(prompt=str(payload.get("prompt", "Summarize the current provider configuration.")))
            return APIResponse(200, _jsonable(result))
        return APIResponse(404, {"error": "not_found"})

    def __call__(self, environ: Mapping[str, Any], start_response: Any) -> list[bytes]:
        method = str(environ.get("REQUEST_METHOD", "GET"))
        path = str(environ.get("PATH_INFO", "/"))
        body = environ.get("wsgi.input")
        payload = body.read() if body is not None else b""
        response = self.dispatch(method, path, payload)
        start_response(
            f"{response.status_code} {'OK' if response.status_code < 400 else 'ERROR'}",
            list(response.headers),
        )
        return [_json_bytes(response.payload)]


def create_app(
    *,
    database_path: str | Path,
    instruction_refs: tuple[str, ...] = ("apps/api",),
    total_tokens: int = 2048,
) -> AegisAPIApp:
    return AegisAPIApp(
        APIAppConfig(
            database_path=Path(database_path),
            instruction_refs=instruction_refs,
            total_tokens=total_tokens,
        )
    )
