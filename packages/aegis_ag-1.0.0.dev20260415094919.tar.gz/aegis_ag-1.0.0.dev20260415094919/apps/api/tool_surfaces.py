"""API adapters that expose canonical state, goals, and memories to built-in tools."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Protocol, cast

from packages.contracts.runtime import CloneIdentityRecord, GoalNode, MemoryRecord, RelationshipMemoryRecord, UserCardRecord
from packages.memory import MemoryRuntime
from packages.tools.surfaces import (
    GoalManagementSurface,
    IdentityManagementSurface,
    MemoryManagementSurface,
    RelationshipManagementSurface,
    UserManagementSurface,
)


class _IdentityApp(Protocol):
    def inspect_identity(self, *, session_id: str | None = None, profile_id: str | None = None) -> CloneIdentityRecord:
        """Inspect canonical clone identity."""

    def update_identity_state(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
        display_name: str | None = None,
        personality_preset: str | None = None,
        initiative: str | None = None,
        charter_text: str | None = None,
        clear_charter: bool = False,
    ) -> CloneIdentityRecord:
        """Update canonical clone identity."""


class _UserApp(Protocol):
    def inspect_user(self, *, session_id: str | None = None, profile_id: str | None = None) -> UserCardRecord:
        """Inspect canonical shared user state."""

    def update_user_state(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
        text: str | None = None,
        fields: dict[str, object] | None = None,
        append: bool = False,
        clear: bool = False,
    ) -> UserCardRecord:
        """Update canonical shared user state."""


class _RelationshipApp(Protocol):
    def inspect_relationship(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> RelationshipMemoryRecord:
        """Inspect canonical relationship continuity."""

    def update_relationship_state(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
        text: str | None = None,
        append: bool = False,
        clear: bool = False,
    ) -> RelationshipMemoryRecord:
        """Update canonical relationship continuity."""


class _GoalApp(Protocol):
    def list_goals(self, session_id: str) -> tuple[GoalNode, ...]:
        """List durable goals for a session."""

    def inspect_goal(self, session_id: str, goal_id: str) -> dict[str, Any]:
        """Inspect one durable goal."""

    def create_goal(self, session_id: str, **kwargs: Any) -> dict[str, Any]:
        """Create a durable goal."""

    def update_goal(self, session_id: str, goal_id: str, **kwargs: Any) -> dict[str, Any]:
        """Update a durable goal."""

    def delete_goal(self, session_id: str, goal_id: str, *, reason: str = "") -> dict[str, Any]:
        """Delete a durable goal."""


class _MemoryApp(Protocol):
    memory_runtime: MemoryRuntime

    def list_memories(self, session_id: str) -> tuple[MemoryRecord, ...]:
        """List durable memories for a session."""

    def inspect_memory(self, session_id: str, memory_id: str) -> dict[str, Any]:
        """Inspect one durable memory."""

    def correct_memory(
        self,
        session_id: str,
        memory_id: str,
        *,
        corrected_content: str,
        reason: str = "",
        actor: str = "user",
    ) -> dict[str, Any]:
        """Correct a durable memory."""

    def delete_memory(
        self,
        session_id: str,
        memory_id: str,
        *,
        reason: str,
        actor: str = "user",
    ) -> dict[str, Any]:
        """Delete a durable memory."""


@dataclass(frozen=True, slots=True)
class APIIdentityManagementSurface(IdentityManagementSurface):
    app: _IdentityApp

    def inspect_identity(self, *, session_id: str | None = None, profile_id: str | None = None) -> CloneIdentityRecord:
        return self.app.inspect_identity(session_id=session_id, profile_id=profile_id)

    def update_identity_state(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
        display_name: str | None = None,
        personality_preset: str | None = None,
        initiative: str | None = None,
        charter_text: str | None = None,
        clear_charter: bool = False,
    ) -> CloneIdentityRecord:
        return self.app.update_identity_state(
            session_id=session_id,
            profile_id=profile_id,
            display_name=display_name,
            personality_preset=personality_preset,
            initiative=initiative,
            charter_text=charter_text,
            clear_charter=clear_charter,
        )


@dataclass(frozen=True, slots=True)
class APIUserManagementSurface(UserManagementSurface):
    app: _UserApp

    def inspect_user(self, *, session_id: str | None = None, profile_id: str | None = None) -> UserCardRecord:
        return self.app.inspect_user(session_id=session_id, profile_id=profile_id)

    def update_user_state(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
        text: str | None = None,
        fields: dict[str, object] | None = None,
        append: bool = False,
        clear: bool = False,
    ) -> UserCardRecord:
        return self.app.update_user_state(
            session_id=session_id,
            profile_id=profile_id,
            text=text,
            fields=fields,
            append=append,
            clear=clear,
        )


@dataclass(frozen=True, slots=True)
class APIRelationshipManagementSurface(RelationshipManagementSurface):
    app: _RelationshipApp

    def inspect_relationship(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
    ) -> RelationshipMemoryRecord:
        return self.app.inspect_relationship(session_id=session_id, profile_id=profile_id)

    def update_relationship_state(
        self,
        *,
        session_id: str | None = None,
        profile_id: str | None = None,
        text: str | None = None,
        append: bool = False,
        clear: bool = False,
    ) -> RelationshipMemoryRecord:
        return self.app.update_relationship_state(
            session_id=session_id,
            profile_id=profile_id,
            text=text,
            append=append,
            clear=clear,
        )


@dataclass(frozen=True, slots=True)
class APIGoalManagementSurface(GoalManagementSurface):
    app: _GoalApp

    def inspect_goals(self, session_id: str) -> tuple[GoalNode, ...]:
        return self.app.list_goals(session_id)

    def inspect_goal(self, session_id: str, goal_id: str) -> GoalNode:
        payload = self.app.inspect_goal(session_id, goal_id)
        return cast(GoalNode, payload["goal"])

    def create_goal(self, session_id: str, **kwargs: Any) -> GoalNode:
        payload = self.app.create_goal(session_id, **kwargs)
        return cast(GoalNode, payload["goal"])

    def update_goal(
        self,
        session_id: str,
        goal_id: str,
        *,
        title: str | None = None,
        status: str | None = None,
        priority: str | None = None,
        reason: str | None = None,
    ) -> tuple[GoalNode, GoalNode, str]:
        payload = self.app.update_goal(
            session_id,
            goal_id,
            title=title,
            status=status,
            priority=priority,
            reason=reason,
        )
        return (
            cast(GoalNode, payload["before"]),
            cast(GoalNode, payload["goal"]),
            str(payload.get("reason") or "goal updated"),
        )

    def delete_goal(self, session_id: str, goal_id: str, *, reason: str) -> tuple[GoalNode, GoalNode]:
        payload = self.app.delete_goal(session_id, goal_id, reason=reason)
        return cast(GoalNode, payload["before"]), cast(GoalNode, payload["goal"])


@dataclass(frozen=True, slots=True)
class APIMemoryManagementSurface(MemoryManagementSurface):
    app: _MemoryApp

    def inspect_memories(self, session_id: str) -> tuple[MemoryRecord, ...]:
        return self.app.list_memories(session_id)

    def inspect_memory(self, session_id: str, memory_id: str) -> MemoryRecord:
        payload = self.app.inspect_memory(session_id, memory_id)
        return cast(MemoryRecord, payload["memory"])

    def search_memories(self, session_id: str, query: str, *, limit: int = 5) -> tuple[MemoryRecord, ...]:
        result = self.app.memory_runtime.retrieve(session_id, query)
        return tuple(candidate.record for candidate in result.candidates[:limit])

    def correct_memory(
        self,
        session_id: str,
        memory_id: str,
        *,
        corrected_content: str,
        reason: str = "",
    ) -> tuple[MemoryRecord | None, MemoryRecord | None, str, str | None]:
        original = self.inspect_memory(session_id, memory_id)
        payload = self.app.correct_memory(
            session_id,
            memory_id,
            corrected_content=corrected_content,
            reason=reason,
            actor="assistant",
        )
        decision = payload["decision"]
        return (
            original,
            cast(MemoryRecord | None, payload.get("memory")),
            str(getattr(decision, "reason", reason or "memory corrected")),
            cast(str | None, payload.get("memory_lineage")),
        )

    def delete_memory(self, session_id: str, memory_id: str, *, reason: str) -> tuple[MemoryRecord, str | None]:
        original = self.inspect_memory(session_id, memory_id)
        payload = self.app.delete_memory(
            session_id,
            memory_id,
            reason=reason,
            actor="assistant",
        )
        decision = payload["decision"]
        return original, str(getattr(decision, "reason", reason or "memory deleted"))

    def pin_memory(self, session_id: str, memory_id: str, *, reason: str = "") -> tuple[MemoryRecord, str]:
        original = self.inspect_memory(session_id, memory_id)
        result = self.app.memory_runtime.pin_memory(memory_id, actor="assistant", reason=reason)
        return result.record or original, result.decision.reason

    def unpin_memory(self, session_id: str, memory_id: str, *, reason: str = "") -> tuple[MemoryRecord, str]:
        original = self.inspect_memory(session_id, memory_id)
        result = self.app.memory_runtime.unpin_memory(memory_id, actor="assistant", reason=reason)
        return result.record or original, result.decision.reason

    def memory_lineage(self, memory_id: str) -> str | None:
        return self.app.memory_runtime.store.lineage(memory_id)

    def memory_state(self, memory_id: str) -> str | None:
        return self.app.memory_runtime.store.state(memory_id)


__all__ = [
    "APIIdentityManagementSurface",
    "APIUserManagementSurface",
    "APIRelationshipManagementSurface",
    "APIGoalManagementSurface",
    "APIMemoryManagementSurface",
]
