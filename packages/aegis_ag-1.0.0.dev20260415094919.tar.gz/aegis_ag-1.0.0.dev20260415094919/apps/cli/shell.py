from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from difflib import unified_diff
import os
from pathlib import Path
import re
import shlex
import time

from packages.contracts import ExperienceRecord
from packages.kernel.runtime import KernelOutcome
from packages.tools.handler_support import resolve_workspace_path
from .provider_flow import provider_setup_defaults, run_provider_selection_wizard
from .runtime import CliRuntime
from .wizard import WIZARD_BACK
from .shell_composer import (
    build_command_palette as _build_shell_command_palette,
    build_composer_body as _build_shell_composer_body,
    build_divider_window as _build_shell_divider_window,
    build_input_window as _build_shell_input_window,
    build_key_bindings as _build_shell_key_bindings,
    build_prompt_buffer as _build_shell_prompt_buffer,
    build_queue_preview_window as _build_shell_queue_preview_window,
    prompt_continuation as _shell_prompt_continuation,
    prompt_label as _shell_prompt_label,
    prompt_style as _shell_prompt_style,
    prompt_style_map as _shell_prompt_style_map,
    prompt_toolkit_composer_available as _shell_prompt_toolkit_composer_available,
    read_command as _read_shell_command,
    shell_history as _shell_history,
)
from .shell_boot import STARTUP_SEQUENCE_STEPS, BootFrameContext, render_boot_frame
from .shell_opening import (
    ShellOpeningContext,
    compose_shell_opening_instruction,
    compose_shell_opener,
)
from .shell_progress import (
    animations_enabled as _shell_animations_enabled,
    render_queued_followup_fragments as _render_shell_queued_followup_fragments,
    render_tool_frame as _render_shell_tool_frame,
    tool_trace_line as _shell_tool_trace_line,
    render_turn_frame as _render_shell_turn_frame,
    render_turn_progress_fragments as _render_shell_turn_progress_fragments,
    run_tool_with_progress as _run_shell_tool_with_progress,
    run_turn_with_progress as _run_shell_turn_with_progress,
    run_turn_with_queued_input as _run_shell_turn_with_queued_input,
    summarize_progress_prompt as _summarize_shell_progress_prompt,
    tool_event_lines as _shell_tool_event_lines,
    tool_event_summary as _shell_tool_event_summary,
    tool_event_tracker as _shell_tool_event_tracker,
    tool_frame_phases as _shell_tool_frame_phases,
    turn_phase as _shell_turn_phase,
    _tool_trace_emoji as _shell_tool_trace_emoji,
)
from .shell_render import (
    center_brand_block as _center_shell_brand_block,
    displayable_experiences as _displayable_shell_experiences,
    format_experience_status as _format_shell_experience_status,
    growth_panel_lines as _shell_growth_panel_lines,
    growth_progress_bar as _shell_growth_progress_bar,
    growth_progress_counts as _shell_growth_progress_counts,
    recent_activity_lines as _shell_recent_activity_lines,
    recent_experience_lines as _shell_recent_experience_lines,
    render_brand_column as _render_shell_brand_column,
    render_chat_entry as _render_shell_chat_entry,
    render_entry as _render_shell_entry,
    render_guardian_brand_mark as _render_shell_guardian_mark,
    render_growth_mark_for_stage as _render_shell_growth_mark,
    render_pending_entries as _render_shell_pending_entries,
    render_shell_frame as _render_shell_frame_view,
    render_status_column as _render_shell_status_column,
    should_display_experience as _should_display_shell_experience,
    styled_growth_progress_bar as _styled_shell_growth_progress_bar,
)
from .shell_stack import (
    Align,
    Completion,
    Completer,
    Console,
    Document,
    FormattedText,
    Group,
    Live,
    PROMPT_TOOLKIT_AVAILABLE,
    Panel,
    RICH_AVAILABLE,
    Table,
    Text,
)
from .shell_ui import (
    BRAND_ACCENT,
    BRAND_ACCENT_STRONG,
    BRAND_DARK,
    BRAND_LIGHT,
    BRAND_MUTED,
    COMMAND_PALETTE_VISIBLE_ROWS,
    EGG_STAGE_ROWS,
    GROWTH_HIGHLIGHT_FG,
    GROWTH_PROGRESS_EMPTY,
    GROWTH_PROGRESS_FILLED,
    GROWTH_PROGRESS_WIDTH,
    GUARDIAN_HEAD_ROWS,
    GUARDIAN_STAGE_ROWS,
    HATCHLING_STAGE_ROWS,
    QUEUE_PREVIEW_INSET,
    SCOUT_STAGE_ROWS,
    SEED_STAGE_ROWS,
    SHELL_WELCOME_HEADLINE,
    STARTUP_SEQUENCE_FINAL_DELAY,
    STARTUP_SEQUENCE_STEP_DELAY,
    USER_HISTORY_BG,
    USER_HISTORY_FG,
    WEB_URL_PATTERN,
    compact_line as _compact_line,
    centered_guardian_rows as _centered_guardian_rows,
    display_path as _display_path,
    display_width as _display_width,
    render_guardian_mark,
    resolve_aegis_version as _resolve_aegis_version,
)

__all__ = [
    "BRAND_ACCENT",
    "BRAND_ACCENT_STRONG",
    "BRAND_DARK",
    "BRAND_LIGHT",
    "BRAND_MUTED",
    "COMMAND_PALETTE_VISIBLE_ROWS",
    "Console",
    "Document",
    "EGG_STAGE_ROWS",
    "GROWTH_HIGHLIGHT_FG",
    "GROWTH_PROGRESS_EMPTY",
    "GROWTH_PROGRESS_FILLED",
    "GROWTH_PROGRESS_WIDTH",
    "GUARDIAN_HEAD_ROWS",
    "GUARDIAN_STAGE_ROWS",
    "HATCHLING_STAGE_ROWS",
    "PendingShellCommand",
    "ProductizedShell",
    "QUEUE_PREVIEW_INSET",
    "RICH_AVAILABLE",
    "SCOUT_STAGE_ROWS",
    "SEED_STAGE_ROWS",
    "SHELL_WELCOME_HEADLINE",
    "STARTUP_SEQUENCE_FINAL_DELAY",
    "STARTUP_SEQUENCE_STEP_DELAY",
    "ShellCompleter",
    "TranscriptEntry",
    "USER_HISTORY_BG",
    "USER_HISTORY_FG",
    "_centered_guardian_rows",
    "_display_width",
    "render_guardian_mark",
]


@dataclass(frozen=True, slots=True)
class TranscriptEntry:
    kind: str
    title: str
    body: str
    meta: str = ""


@dataclass(frozen=True, slots=True)
class _PendingFileReview:
    path: Path
    before_text: str | None


@dataclass(frozen=True, slots=True)
class PendingShellCommand:
    command: str


@dataclass(frozen=True, slots=True)
class ShellCommandSpec:
    name: str
    description: str


@dataclass(frozen=True, slots=True)
class SkillSlashSpec:
    command: str
    skill_id: str
    display_name: str
    summary: str
    aliases: tuple[str, ...] = ()
    trigger_phrases: tuple[str, ...] = ()
    keywords: tuple[str, ...] = ()


def _skill_metadata_values(value: object) -> tuple[str, ...]:
    if value is None:
        return ()
    if isinstance(value, (list, tuple, set)):
        raw_items = tuple(value)
    else:
        text = str(value).strip()
        if not text:
            return ()
        raw_items = tuple(segment.strip() for segment in text.split(","))
    normalized: list[str] = []
    seen: set[str] = set()
    for item in raw_items:
        token = str(item).strip().strip("\"'")
        if not token:
            continue
        dedupe_key = token.lower()
        if dedupe_key in seen:
            continue
        seen.add(dedupe_key)
        normalized.append(token)
    return tuple(normalized)


def _normalize_skill_match_text(value: str) -> str:
    normalized = value.strip().lower().replace("/", " ").replace("_", " ").replace("-", " ")
    normalized = re.sub(r"[^\w\s\u4e00-\u9fff]+", " ", normalized)
    return " ".join(normalized.split())


def _skill_phrase_in_message(message: str, phrase: str) -> bool:
    normalized_message = _normalize_skill_match_text(message)
    normalized_phrase = _normalize_skill_match_text(phrase)
    if not normalized_phrase:
        return False
    if re.search(r"[\u4e00-\u9fff]", normalized_phrase):
        return normalized_phrase in normalized_message
    return f" {normalized_phrase} " in f" {normalized_message} "


def _completion(text: str, *, start_position: int, display: str, meta: str = "") -> Completion:
    try:
        return Completion(text, start_position=start_position, display=display, display_meta=meta)
    except TypeError:  # pragma: no cover - fallback signature
        return Completion(text, start_position=start_position, display=display)


class ShellCompleter(Completer):
    def __init__(self, shell: "ProductizedShell") -> None:
        self.shell = shell

    def get_completions(self, document: Document, complete_event):
        text = document.text_before_cursor
        stripped = text.lstrip()
        if not stripped.startswith("/"):
            return
        words = stripped.split()
        current_word = document.get_word_before_cursor(WORD=True)
        if not words:
            return
        command = words[0]
        if len(words) <= 1 and not text.endswith(" "):
            for spec in self.shell.command_specs:
                if spec.name.startswith(command):
                    yield _completion(
                        spec.name,
                        start_position=-len(current_word),
                        display=spec.name,
                        meta=spec.description,
                    )
            return

        if command == "/resume":
            candidates = (
                ("latest", "Resume the latest Aegis clone"),
                *tuple((clone_id, "Resume the latest session for a clone") for clone_id in self.shell.recent_clone_ids()),
            ) + tuple(
                (session_id, "Resume a known session")
                for session_id in self.shell.recent_session_ids()
            )
        elif command == "/identity":
            if len(words) >= 2 and words[1] in {"charter", "clone"}:
                candidates = (
                    ("show", "Inspect the current identity charter extension"),
                    ("set", "Replace the current identity charter extension"),
                    ("clear", "Clear the current identity charter extension"),
                )
            elif len(words) >= 2 and words[1] in {"preset", "personality"}:
                candidates = tuple(
                    (preset_id, description)
                    for preset_id, description in self.shell.personality_preset_choices()
                )
            elif len(words) == 2 and text.endswith(" "):
                candidates = (
                    ("inspect", "Show current identity, user, and relationship state"),
                    ("set-name", "Rename the active clone"),
                    ("charter", "Show, set, or clear the identity charter extension"),
                    ("initiative", "Tune proactive initiative"),
                    ("preset", "Choose a personality preset"),
                )
            else:
                candidates = (
                    ("inspect", "Show current identity, user, and relationship state"),
                    ("set-name", "Rename the active clone"),
                    ("charter", "Show, set, or clear the identity charter extension"),
                    ("initiative", "Tune proactive initiative"),
                    ("preset", "Choose a personality preset"),
                )
        elif command == "/user":
            candidates = (
                ("show", "Inspect the current shared user state"),
                ("set", "Replace the current shared user state"),
                ("append", "Append durable shared user facts"),
                ("clear", "Clear the current shared user state"),
            )
        elif command == "/relationship":
            candidates = (
                ("show", "Inspect the current clone-local relationship continuity"),
                ("set", "Replace the current relationship continuity notes"),
                ("append", "Append clone-local continuity notes"),
                ("clear", "Clear the current relationship continuity notes"),
            )
        elif command == "/tools":
            candidates = (
                ("inspect", "Show metadata for one tool"),
                ("enable", "Enable a tool for this clone"),
                ("disable", "Disable a tool for this clone"),
                ("install", "Load a tool manifest into this clone"),
                ("run", "Run a tool with explicit key=value arguments"),
            )
        elif command == "/skills":
            candidates = (
                ("list", "List discoverable skill packages from local shelves"),
                ("active", "Show currently active installed skills"),
                ("search", "Search installable skill packages from local shelves"),
                ("view", "Load one skill package and show its instructions"),
                ("inspect", "Alias for view"),
                ("enable", "Enable a skill for this clone"),
                ("disable", "Disable a skill for this clone"),
                ("install", "Install a skill package or manifest into this clone"),
            )
        elif command == "/brain":
            candidates = (
                ("configure", "Choose provider, model, reasoning effort, and context window"),
                ("status", "Show the active provider and model posture"),
                ("providers", "List configurable providers Aegis can see"),
                ("models", "List models exposed by the active or selected provider"),
            )
        elif command == "/providers":
            candidates = (
                ("configure", "Choose a provider, endpoint, key, model, and context window"),
                ("status", "Show the active provider configuration"),
                ("list", "List supported provider catalogs"),
            )
        elif command == "/models":
            candidates = (
                ("configure", "Choose the active model and context window"),
                ("status", "Show the active model configuration"),
                ("list", "List models exposed by the active provider endpoint"),
            )
        elif command == "/cron":
            candidates = (
                ("create", "Create a scheduled greeting, web search, or prompt"),
                ("inspect", "Show one cron job"),
                ("pause", "Pause a cron job"),
                ("resume", "Resume a paused cron job"),
                ("remove", "Remove a cron job"),
            )
        else:
            return

        for value, description in candidates:
            if value.startswith(current_word):
                yield _completion(
                    value,
                    start_position=-len(current_word),
                    display=value,
                    meta=description,
                )


class ProductizedShell:
    command_specs = (
        ShellCommandSpec("/help", "Open the command palette and interaction hints"),
        ShellCommandSpec("/status", "Refresh session, provider, and growth posture"),
        ShellCommandSpec("/resume", "Resume the latest or a known Aegis clone"),
        ShellCommandSpec("/goals", "Inspect or mutate the current durable goals"),
        ShellCommandSpec("/memory", "Inspect remembered context for this clone"),
        ShellCommandSpec("/tools", "Inspect, install, toggle, and run built-in or manifest-backed tools"),
        ShellCommandSpec("/skills", "Discover, inspect, install, and toggle built-in or external skill packages"),
        ShellCommandSpec("/cron", "Inspect, create, pause, resume, and remove built-in scheduled jobs"),
        ShellCommandSpec("/identity", "Inspect or tune display name, charter extension, initiative, and preset"),
        ShellCommandSpec("/user", "Inspect or update shared user truth for the active profile"),
        ShellCommandSpec("/relationship", "Inspect or update clone-local relationship continuity"),
        ShellCommandSpec("/brain", "Configure provider, model, reasoning effort, and context window together"),
        ShellCommandSpec("/providers", "Set or switch the active provider, endpoint, and encrypted key"),
        ShellCommandSpec("/models", "Set or switch the active model and context window"),
        ShellCommandSpec("/health", "Review readiness, voice, and security checks"),
        ShellCommandSpec("/grow", "Inspect the next long-horizon growth action"),
        ShellCommandSpec("/clear", "Reset the transcript and replay the opening reply"),
        ShellCommandSpec("/exit", "Leave the grow surface"),
    )

    def __init__(self, runtime: CliRuntime, *, session_id: str, opened: str, debug: bool = False) -> None:
        self.runtime = runtime
        self.session_id = session_id
        self.opened = opened
        self.debug = debug or os.environ.get("AEGIS_DEBUG") == "1"
        self.console = Console(highlight=False, soft_wrap=True)
        self.version = _resolve_aegis_version()
        self.cwd = _display_path(Path.cwd())
        self.transcript: list[TranscriptEntry] = []
        self._pending_file_reviews: dict[str, _PendingFileReview] = {}
        self._pending_commands: deque[PendingShellCommand] = deque()
        self._rendered_entries = 0
        self._opened_at = time.monotonic()
        self._turn_started_at: float | None = None
        self._last_turn_elapsed_seconds = 0
        self._last_prompt_tokens = 0
        self._last_completion_tokens = 0
        self._last_total_tokens = 0
        self.runtime.prepare_session_surface(self.session_id)
        self._skill_slash_specs = self._load_skill_slash_specs()
        self._prime_transcript()

    def run(self) -> int:
        self._render_startup_sequence()
        self._refresh_shell_frame()
        self._render_pending_entries()
        while True:
            try:
                command = self._next_command()
            except KeyboardInterrupt:
                self._append_entry(
                    "notice",
                    "Grow surface",
                    "Prompt interrupted. Type a request, use /help, or /exit when you are done.",
                )
                self._render_pending_entries()
                continue
            except EOFError:
                self._append_entry("notice", "Grow surface", f"Leaving session {self.session_id}.")
                self._render_pending_entries()
                break
            if self._dispatch(command.command):
                self._refresh_shell_frame()
                self._render_pending_entries()
                break
            self._render_pending_entries()
        self.console.print("Aegis stays by your side.")
        return 0

    def recent_session_ids(self) -> tuple[str, ...]:
        return tuple(session.session_id for session in self.runtime.recent_sessions(limit=8))

    def recent_clone_ids(self) -> tuple[str, ...]:
        return tuple(clone.clone_id for clone in self.runtime.list_clones(limit=8))

    def skill_slash_specs(self) -> tuple[SkillSlashSpec, ...]:
        return self._skill_slash_specs

    def _refresh_skill_slash_specs(self) -> None:
        self._skill_slash_specs = self._load_skill_slash_specs()

    def _load_skill_slash_specs(self) -> tuple[SkillSlashSpec, ...]:
        reserved = {spec.name.removeprefix("/").lower() for spec in self.command_specs}
        specs: list[SkillSlashSpec] = []
        seen: set[str] = set()
        for entry in self.runtime.list_skill_hub(limit=None):
            slug = str(entry.metadata.get("slash_command") or "").strip().lower()
            if not slug or slug in reserved or slug in seen:
                continue
            specs.append(
                SkillSlashSpec(
                    command=f"/{slug}",
                    skill_id=entry.skill_id,
                    display_name=entry.display_name,
                    summary=entry.summary,
                    aliases=_skill_metadata_values(entry.metadata.get("aliases")),
                    trigger_phrases=_skill_metadata_values(entry.metadata.get("trigger_phrases")),
                    keywords=_skill_metadata_values(entry.metadata.get("keywords")),
                )
            )
            seen.add(slug)
        return tuple(specs)

    def _resolve_skill_slash_spec(self, command: str) -> SkillSlashSpec | None:
        normalized = command.strip().lower().replace("_", "-")
        for spec in self._skill_slash_specs:
            if spec.command == normalized:
                return spec
        return None

    def _resolve_explicit_skill_request(self, message: str) -> SkillSlashSpec | None:
        if not message.strip():
            return None
        scored: list[tuple[int, SkillSlashSpec]] = []
        for spec in self._load_skill_slash_specs():
            score = 0
            slash_token = spec.command.lower()
            if slash_token in message.lower():
                score = max(score, 140)
            direct_phrases = (
                spec.skill_id,
                spec.skill_id.replace("_", "-"),
                spec.display_name,
                *spec.aliases,
            )
            for phrase in direct_phrases:
                if _skill_phrase_in_message(message, phrase):
                    score = max(score, 120)
            if _skill_phrase_in_message(message, f"skill {spec.skill_id}"):
                score = max(score, 130)
            if _skill_phrase_in_message(message, f"skill {spec.display_name}"):
                score = max(score, 130)
            if score > 0:
                scored.append((score, spec))
        if not scored:
            return None
        scored.sort(key=lambda item: (-item[0], item[1].skill_id))
        top_score, top_spec = scored[0]
        if len(scored) > 1 and scored[1][0] == top_score:
            return None
        return top_spec

    def _resolve_contextual_skill_request(self, message: str) -> SkillSlashSpec | None:
        if not message.strip():
            return None
        scored: list[tuple[int, SkillSlashSpec]] = []
        for spec in self._load_skill_slash_specs():
            score = 0
            for phrase in spec.trigger_phrases:
                if _skill_phrase_in_message(message, phrase):
                    score = max(score, 90)
            keyword_hits = sum(1 for keyword in spec.keywords if _skill_phrase_in_message(message, keyword))
            if keyword_hits >= 2:
                score = max(score, 60 + (keyword_hits * 10))
            if score > 0:
                scored.append((score, spec))
        if not scored:
            return None
        scored.sort(key=lambda item: (-item[0], item[1].skill_id))
        top_score, top_spec = scored[0]
        second_score = scored[1][0] if len(scored) > 1 else 0
        if top_score < 80 or top_score < second_score + 15:
            return None
        return top_spec

    def _maybe_prepare_skill_routed_prompt(self, message: str) -> str:
        spec = self._resolve_explicit_skill_request(message)
        if spec is None:
            spec = self._resolve_contextual_skill_request(message)
        if spec is None:
            return message
        try:
            self._run_tool_with_progress("tool.skill.view", {"skill_id": spec.skill_id})
            skill = self.runtime.inspect_skill(spec.skill_id, session_id=self.session_id)
        except Exception:
            return message
        return self._compose_skill_turn_prompt(skill, user_instruction=message)

    def _next_command(self) -> PendingShellCommand:
        if self._pending_commands:
            return self._pending_commands.popleft()
        return PendingShellCommand(self._read_command())

    def _prompt_toolkit_composer_available(self) -> bool:
        return _shell_prompt_toolkit_composer_available(self)

    def _shell_history(self):
        return _shell_history(self)

    def _build_prompt_buffer(self):
        return _build_shell_prompt_buffer(self)

    def _build_input_window(self, buffer):
        return _build_shell_input_window(self, buffer)

    def _build_command_palette(self):
        return _build_shell_command_palette(self)

    def _build_queue_preview_window(self):
        return _build_shell_queue_preview_window(self)

    def _build_divider_window(self):
        return _build_shell_divider_window(self)

    def _build_composer_body(self, *, input_window, command_palette, top_windows=()):
        return _build_shell_composer_body(
            self,
            input_window=input_window,
            command_palette=command_palette,
            top_windows=top_windows,
        )

    def _read_command(self) -> str:
        return _read_shell_command(self)

    def personality_preset_choices(self) -> tuple[tuple[str, str], ...]:
        return tuple(
            (preset.preset_id, preset.summary)
            for preset in self.runtime.personality_presets()
            if preset.preset_id != "custom"
        )

    def _prompt_label(self) -> str:
        return _shell_prompt_label(self)

    def _prompt_continuation(self):
        return _shell_prompt_continuation()

    def _prompt_style(self):
        return _shell_prompt_style()

    def _prompt_style_map(self) -> dict[str, str]:
        return _shell_prompt_style_map()

    def _build_key_bindings(self, *, submit=None, allow_exit: bool = True) -> KeyBindings:
        return _build_shell_key_bindings(submit=submit, allow_exit=allow_exit)

    def _composer_divider(self) -> str:
        width = getattr(self.console, "width", 100)
        try:
            width = self.console.size.width
        except AttributeError:
            pass
        return "─" * max(24, width - 1)

    def _format_status_tokens(self, value: int | None) -> str:
        if value is None or value <= 0:
            return "--"
        if value >= 1_000_000:
            whole = round(value / 1_000_000, 1)
            return f"{whole:g}M"
        if value >= 1_000:
            whole = round(value / 1_000)
            return f"{whole}K"
        return str(value)

    def _status_bar_context_style(self, percent_used: int | None) -> str:
        if percent_used is None:
            return "class:status-bar-muted"
        if percent_used >= 95:
            return "class:status-bar-critical"
        if percent_used > 80:
            return "class:status-bar-warn"
        return "class:status-bar-good"

    def _build_context_bar(self, percent_used: int | None, width: int = 12) -> str:
        safe_percent = max(0, min(100, percent_used or 0))
        filled = round((safe_percent / 100) * width)
        return f"[{('█' * filled) + ('░' * max(0, width - filled))}]"

    def _build_growth_bar_fragments(self, growth, *, width: int = 10) -> list[tuple[str, str]]:
        filled, empty = self._growth_progress_counts(growth, width=width)
        fragments: list[tuple[str, str]] = [("class:status-bar-growth-bracket", "[")]
        if filled:
            fragments.append(("class:status-bar-growth-fill", GROWTH_PROGRESS_FILLED * filled))
        if empty:
            fragments.append(("class:status-bar-growth-empty", GROWTH_PROGRESS_EMPTY * empty))
        fragments.append(("class:status-bar-growth-bracket", "]"))
        return fragments

    def _status_bar_snapshot(self) -> dict[str, object]:
        provider = dict(self.runtime.provider_summary())
        model_name = str(provider.get("default_model") or "<unset>")
        model_short = model_name.split("/")[-1] if "/" in model_name else model_name
        model_short = _compact_line(model_short, limit=26)
        context_window = provider.get("context_window_tokens")
        try:
            context_limit = int(context_window) if context_window is not None else None
        except (TypeError, ValueError):
            context_limit = None
        context_used = max(0, self._last_prompt_tokens)
        context_percent = None
        if context_limit:
            context_percent = max(0, min(100, round((context_used / context_limit) * 100)))
        if self._turn_started_at is not None:
            elapsed_seconds = max(0, round(time.monotonic() - self._turn_started_at))
        else:
            elapsed_seconds = max(0, int(self._last_turn_elapsed_seconds))
        return {
            "model_short": model_short,
            "context_used": context_used,
            "context_limit": context_limit,
            "context_percent": context_percent,
            "elapsed_seconds": elapsed_seconds,
        }

    def _status_bar_fragments(self):
        snapshot = self._status_bar_snapshot()
        growth = self.runtime.inspect_growth(session_id=self.session_id)
        percent = snapshot["context_percent"]
        percent_style = self._status_bar_context_style(percent if isinstance(percent, int) else None)
        context_used = self._format_status_tokens(snapshot["context_used"])
        context_limit = self._format_status_tokens(snapshot["context_limit"])
        percent_label = f"{percent}%" if isinstance(percent, int) else "--"
        elapsed_seconds = int(snapshot["elapsed_seconds"])
        return [
            ("class:status-bar-edge", " "),
            ("class:status-bar-model", str(snapshot["model_short"])),
            ("class:status-bar-sep", " │ "),
            ("class:status-bar-muted", f"{context_used}/{context_limit}"),
            ("class:status-bar-sep", " │ "),
            (percent_style, self._build_context_bar(percent if isinstance(percent, int) else None)),
            ("class:status-bar-sep", " "),
            (percent_style, percent_label),
            ("class:status-bar-sep", " │ "),
            ("class:status-bar-muted", f"{elapsed_seconds}s"),
            ("class:status-bar-sep", " │ "),
            ("class:status-bar-level", f"Level {growth.level}"),
            ("class:status-bar-sep", " "),
            *self._build_growth_bar_fragments(growth),
            ("class:status-bar-sep", " "),
            ("class:status-bar-level", f"{growth.progress_percent}%"),
            ("class:status-bar-edge", " "),
        ]

    def _clear_composer(self, command: str) -> None:
        if PROMPT_TOOLKIT_AVAILABLE:
            return
        stream = getattr(self.console, "file", None)
        if stream is None or not hasattr(stream, "isatty") or not stream.isatty():
            return
        logical_lines = 3 + command.count("\n")
        stream.write("\r\x1b[2K")
        for _ in range(logical_lines):
            stream.write("\x1b[1A\r\x1b[2K")
        stream.flush()

    def _enqueue_followup_command(self, raw_command: str) -> None:
        command = raw_command.strip()
        if not command:
            return
        self._pending_commands.append(PendingShellCommand(command=command))

    def _prime_transcript(self, *, use_proactive_opening: bool = True) -> None:
        session = self.runtime.inspect_session(self.session_id)
        continuity = self.runtime.inspect_continuity(session_id=self.session_id)
        assistant_name = continuity.profile.state.display_name or "Aegis"
        goals = self.runtime.inspect_goals(self.session_id)
        opening_context = ShellOpeningContext(
            opened=self.opened,
            display_name=assistant_name,
            friend_profile=(continuity.profile.friend_text or "").strip(),
            personality=continuity.profile.companion.personality if continuity.profile.companion is not None else (),
            reengagement_style=continuity.reengagement_style,
            wake_action=continuity.wake_action or "",
            wake_summary=continuity.wake_summary or "",
            has_goals=bool(goals),
        )
        startup_outcome = None
        if use_proactive_opening:
            try:
                startup_outcome = self.runtime.generate_opening_reply(
                    session_id=self.session_id,
                    prompt=compose_shell_opening_instruction(opening_context),
                    opening_label=self.opened,
                )
            except Exception as error:
                if self.debug:
                    self._append_entry("notice", "Startup prompt", f"fallback to local opener\nreason: {error}")
        if startup_outcome is not None and startup_outcome.execution.summary.strip():
            self._append_entry("assistant", assistant_name, startup_outcome.execution.summary.strip())
        else:
            self._append_entry("assistant", assistant_name, compose_shell_opener(opening_context))
        for execution in self.runtime.run_due_cron_jobs(session_id=self.session_id):
            if execution.job.action_kind == "greeting":
                self._append_entry(
                    "assistant",
                    assistant_name,
                    execution.summary,
                    meta=f"cron · {execution.job.name}",
                )
            else:
                self._append_entry(
                    "notice",
                    "Cron job",
                    execution.summary,
                    meta=f"{execution.job.name} · {execution.job.action_kind}",
                )
        if self.debug:
            self._append_entry(
                "notice",
                "Growth context",
                "\n".join(
                    [
                        f"session_id: {session.session_id}",
                        f"clone_id: {self.runtime.clone_id_for_session(session)}",
                        f"continuity: {continuity.continuity_summary}",
                        f"growth_action: {continuity.wake_action}",
                        f"growth_summary: {continuity.wake_summary}",
                        f"reengagement_style: {continuity.reengagement_style}",
                        f"reengagement_prompt: {continuity.reengagement_prompt}",
                    ]
                ),
            )

    def _assistant_name(self) -> str:
        session = self.runtime.inspect_session(self.session_id)
        return self.runtime.inspect_profile(session.profile_id).state.display_name or "Aegis"

    def _append_assistant_surface_reply(self, body: str, *, meta: str = "") -> None:
        self._append_entry("assistant", self._assistant_name(), body, meta=meta)

    def _render_shell_frame(self):
        return _render_shell_frame_view(self)

    def _render_brand_column(self, session, provider, growth):
        return _render_shell_brand_column(self, session, provider, growth)

    def _render_status_column(self, session, continuity, context_frame, provider, growth):
        return _render_shell_status_column(self, session, continuity, context_frame, provider, growth)

    def _render_startup_sequence(self) -> None:
        if not self._animations_enabled() or Group is None or Table is None:
            return
        with Live(
            self._render_boot_frame(STARTUP_SEQUENCE_STEPS, active=-1),
            console=self.console,
            refresh_per_second=30,
            screen=True,
            transient=True,
        ) as live:
            time.sleep(STARTUP_SEQUENCE_STEP_DELAY)
            for index in range(len(STARTUP_SEQUENCE_STEPS)):
                live.update(self._render_boot_frame(STARTUP_SEQUENCE_STEPS, active=index), refresh=True)
                time.sleep(STARTUP_SEQUENCE_STEP_DELAY)

    def _render_boot_frame(self, steps: tuple[tuple[str, str], ...], *, active: int):
        continuity = self.runtime.inspect_continuity(session_id=self.session_id)
        growth = self.runtime.inspect_growth(session_id=self.session_id)
        provider = dict(self.runtime.provider_summary())
        viewport = getattr(self.console, "size", None)
        boot_stage_id, boot_level = self._boot_growth_stage(active)
        return render_boot_frame(
            context=BootFrameContext(
                display_name=continuity.profile.state.display_name or "Aegis",
                growth_stage_title=growth.stage.title,
                growth_level=growth.level,
                provider_model=provider["default_model"] or "<unset>",
                viewport_width=int(getattr(viewport, "width", 0) or 0),
                viewport_height=int(getattr(viewport, "height", 0) or 0),
            ),
            steps=steps,
            active=active,
            rich_available=RICH_AVAILABLE,
            table_cls=Table,
            group_cls=Group,
            text_cls=Text,
            panel_cls=Panel,
            align_cls=Align,
            brand_accent=BRAND_ACCENT,
            brand_accent_strong=BRAND_ACCENT_STRONG,
            brand_light=BRAND_LIGHT,
            brand_muted=BRAND_MUTED,
            brand_dark=BRAND_DARK,
            center_brand_block=self._center_brand_block,
            brand_mark=self._render_growth_mark(boot_stage_id, level=boot_level),
        )

    def _refresh_shell_frame(self) -> None:
        self._rendered_entries = 0
        self.console.clear(home=True)
        self.console.print(self._render_shell_frame())

    def _dispatch(self, raw_command: str) -> bool:
        command = raw_command.strip()
        if not command:
            return False
        if command.startswith("/"):
            self._clear_composer(command)
            return self._handle_slash_command(command)
        self._clear_composer(command)
        self._append_entry("user", "You", command)
        self._render_pending_entries()
        if self._handle_conversational_surface_request(command):
            self._refresh_shell_frame()
            return False
        try:
            if self.debug:
                self._append_entry(
                    "status",
                    "Runtime",
                    "\n".join(
                        [
                            f"session_id: {self.session_id}",
                            "mode: shared-runtime",
                            "trace: debug diagnostics enabled",
                        ]
                    ),
                )
                self._render_pending_entries()
            prompt = self._maybe_prepare_skill_routed_prompt(command)
            outcome = self._run_turn_with_progress(prompt)
        except Exception as error:  # pragma: no cover - defensive shell surface
            self._append_entry(
                "recovery",
                "Turn failed",
                f"{error}\nstatus: /status\nhealth: /health",
            )
            self._refresh_shell_frame()
            return False
        self._append_outcome(outcome)
        growth_update = self._show_growth_celebration_if_needed()
        self._append_growth_update_message(growth_update)
        self._refresh_shell_frame()
        return False

    def _handle_conversational_surface_request(self, message: str) -> bool:
        normalized = message.strip().lower().rstrip("?.!")
        if normalized in {
            "what tools do you have",
            "which tools do you have",
            "show tools",
            "list tools",
        }:
            tools = tuple(
                tool
                for tool in self.runtime.tool_catalog(session_id=self.session_id)
                if tool.enabled and tool.available
            )
            lines = [
                "I can use these tools right now:",
                *[
                    f"- {tool.display_name} ({tool.tool_id}): {tool.description}"
                    for tool in tools
                ],
                "",
                "Ask me naturally if you want one used, or give me a manifest path if you want me to install an external tool.",
            ]
            self._append_assistant_surface_reply("\n".join(lines))
            return True
        if normalized in {
            "what cron jobs do you have",
            "which cron jobs do you have",
            "show cron jobs",
            "list cron jobs",
            "show schedules",
            "list schedules",
        }:
            jobs = self.runtime.cron_jobs(session_id=self.session_id)
            if jobs:
                body = "\n".join(
                    [
                        "These scheduled jobs are active for this clone:",
                        *[
                            f"- {job.name} ({job.job_id}) · {job.status} · {job.schedule_text} · {job.action_kind}"
                            for job in jobs
                        ],
                    ]
                )
            else:
                body = "I don't have any scheduled jobs running for this clone yet."
            self._append_assistant_surface_reply(body)
            return True
        tool_match = re.match(r"(?i)^(install|add|load)\s+tools?\s+(.+)$", message.strip())
        if tool_match is not None:
            reference = self._strip_wrapping_quotes(tool_match.group(2).strip())
            try:
                record = self.runtime.install_tool_manifest(reference, session_id=self.session_id)
            except Exception as error:
                self._append_assistant_surface_reply(
                    "I couldn't install that tool manifest yet.\n"
                    f"reason: {error}\n"
                    "Right now external tools install from a local manifest path.",
                )
                return True
            self._append_assistant_surface_reply(
                "\n".join(
                    [
                        "I installed that tool manifest for this clone.",
                        f"- source: {record.source_path}",
                        f"- tools: {', '.join(record.tool_ids) or '<empty>'}",
                        f"- executable: {', '.join(record.executable_tool_ids) or '<empty>'}",
                    ]
                )
            )
            return True
        cron_greeting = re.match(
            r"(?is)^(?:schedule|create|set up)\s+(?:a\s+)?greeting(?:\s+job)?(?:\s+to\s+say\s+(.+?))?\s+(every .+|daily at .+|\d+[mhd])$",
            message.strip(),
        )
        if cron_greeting is not None:
            message_text = self._strip_wrapping_quotes((cron_greeting.group(1) or "").strip())
            schedule = cron_greeting.group(2).strip()
            arguments = [f'schedule="{schedule}"', "kind=greeting"]
            if message_text:
                arguments.append(f'message="{message_text}"')
                arguments.append(f'name="Greeting · {schedule}"')
            else:
                arguments.append(f'name="Greeting · {schedule}"')
            try:
                payload = self._parse_named_arguments(arguments)
                job = self.runtime.create_cron_job(
                    session_id=self.session_id,
                    name=payload.get("name", f"Greeting · {schedule}"),
                    schedule=payload["schedule"],
                    action_kind=payload["kind"],
                    payload={"message": payload.get("message", "")},
                )
            except Exception as error:
                self._append_assistant_surface_reply(f"I couldn't create that scheduled greeting yet.\nreason: {error}")
                return True
            self._append_assistant_surface_reply(
                f"I scheduled that greeting for this clone.\n- {job.name} · {job.schedule_text} · {job.action_kind}"
            )
            return True
        cron_search = re.match(
            r"(?is)^(?:schedule|create|set up)\s+(?:a\s+)?(?:web\s+search|search)(?:\s+job)?\s+(?:for\s+)?(.+?)\s+(every .+|daily at .+|\d+[mhd])$",
            message.strip(),
        )
        if cron_search is not None:
            query = self._strip_wrapping_quotes(cron_search.group(1).strip())
            schedule = cron_search.group(2).strip()
            try:
                job = self.runtime.create_cron_job(
                    session_id=self.session_id,
                    name=f"Web search · {query[:32]}",
                    schedule=schedule,
                    action_kind="web_search",
                    payload={"query": query},
                )
            except Exception as error:
                self._append_assistant_surface_reply(f"I couldn't create that scheduled web search yet.\nreason: {error}")
                return True
            self._append_assistant_surface_reply(
                f"I scheduled that web search for this clone.\n- {job.name} · {job.schedule_text} · {job.action_kind}"
            )
            return True
        webpage_url = self._requested_webpage_url(message)
        if webpage_url is not None:
            try:
                result = self._run_tool_with_progress("tool.web.read", {"url": webpage_url})
            except Exception as error:
                self._append_assistant_surface_reply(
                    f"I couldn't fetch that web page yet.\nreason: {error}",
                    meta=webpage_url,
                )
                return True
            self._append_assistant_surface_reply(
                f"I opened that page and pulled the readable content:\n{result.summary}",
                meta=webpage_url,
            )
            return True
        return False

    def _handle_slash_command(self, raw_command: str) -> bool:
        try:
            parts = self._parse_slash_command(raw_command)
        except ValueError as error:
            self._append_entry("recovery", "Command parse error", str(error))
            return False
        command = parts[0]
        args = parts[1:]

        if command in {"/exit", "/quit"}:
            self._append_entry("notice", "Grow surface", f"Leaving session {self.session_id}.")
            return True
        if command == "/help":
            self._append_help()
            return False
        if command == "/status":
            self._append_status()
            return False
        if command in {"/clone", "/clones"}:
            self._append_entry(
                "recovery",
                "Clone management",
                "\n".join(
                    [
                        "Clone creation and listing stay outside grow.",
                        'create: aegis clone <name> --initial-goal "..."',
                        "list: aegis clones",
                    ]
                ),
            )
            return False
        if command == "/resume":
            self._resume_session(args[0] if args else "latest")
            return False
        if command == "/goals":
            self._append_goals(args)
            return False
        if command == "/memory":
            self._append_memory()
            return False
        if command == "/tools":
            self._append_tools(args)
            return False
        if command == "/skills":
            self._append_skills(args)
            return False
        if command == "/cron":
            self._append_cron(args)
            return False
        if command == "/identity":
            self._append_identity(args)
            return False
        if command == "/user":
            self._append_user(args)
            return False
        if command == "/relationship":
            self._append_relationship(args)
            return False
        if command == "/brain":
            self._append_brain(args)
            return False
        if command == "/providers":
            self._append_providers(args)
            return False
        if command == "/models":
            self._append_models(args)
            return False
        if command == "/health":
            self._append_doctor()
            return False
        if command == "/grow":
            self._append_wake()
            return False
        if command == "/clear":
            self.transcript.clear()
            self._prime_transcript(use_proactive_opening=True)
            self._refresh_shell_frame()
            return False

        if self._dispatch_skill_slash_command(raw_command, command, args):
            return False

        self._append_entry("command", "Unknown command", f"{command}\nhelp: /help")
        return False

    def _parse_slash_command(self, raw_command: str) -> list[str]:
        try:
            return shlex.split(raw_command)
        except ValueError:
            fallback = self._text_surface_fallback_parts(raw_command)
            if fallback is not None:
                return fallback
            raise

    def _text_surface_fallback_parts(self, raw_command: str) -> list[str] | None:
        stripped = raw_command.strip()
        for prefix in (
            "/user set ",
            "/user append ",
            "/relationship set ",
            "/relationship append ",
        ):
            if stripped.startswith(prefix):
                command, action, remainder = stripped.split(" ", 2)
                remainder = remainder.strip()
                if remainder:
                    return [command, action, remainder]
                return [command, action]
        for prefix in ("/identity charter set ", "/identity clone set "):
            if stripped.startswith(prefix):
                command, subcommand, action, remainder = stripped.split(" ", 3)
                remainder = remainder.strip()
                if remainder:
                    return [command, subcommand, action, remainder]
                return [command, subcommand, action]
        return None

    def _append_help(self) -> None:
        lines = [
            "Stay in the conversation. Slash commands exist only for orientation and control.",
            "",
            "/status - refresh session, provider, and growth posture",
            "/resume latest|<clone-id>|<session-id> - re-enter a clone or jump to a known session",
            "/goals [list|inspect|create|focus|drop] - inspect or mutate current durable goals",
            "/memory - inspect remembered context for the active clone",
            "/tools [inspect|enable|disable|install|run] - govern built-ins and manifest-backed tools",
            "/skills [list|active|search|view|enable|disable|install] - discover, inspect, and govern skill packages",
            "/cron [create|inspect|pause|resume|remove] - govern built-in scheduled jobs",
            "/identity inspect|set-name|charter|initiative|preset",
            "/user show|set|append|clear - inspect or update shared user truth",
            "/relationship show|set|append|clear - inspect or update clone-local continuity",
            "/brain [configure|status|providers|models] - configure provider and model posture together",
            "/providers [configure|status|list] - switch provider, endpoint, and encrypted key",
            "/models [configure|status|list] - switch model and context window",
            "/health - review readiness, voice, and security checks",
            "/grow - inspect the next proactive growth action",
            "/clear - reset the transcript and replay the opening reply",
            "/exit - leave the shell",
            "",
            "Use /skills to inspect installed skills, search shelves, or view one skill package before invoking it.",
            "Examples: /skills active · /skills search notes · /skills view builtin:apple-notes",
            "",
            'Clone management stays in the CLI: aegis clone <name> --initial-goal "..."',
            "Clone inventory and retirement stay in the CLI: aegis clones / aegis clones bye <name>",
            "",
            "Tip: type / and keep typing to open the command palette.",
        ]
        self._append_entry("notice", "Command palette", "\n".join(lines))

    def _append_tools(self, args: list[str]) -> None:
        command = args[0] if args else "list"
        if command in {"list", "ls"}:
            tools = self.runtime.tool_catalog(session_id=self.session_id)
            lines = [
                (
                    f"{tool.tool_id} | enabled={tool.enabled} | available={tool.available} | "
                    f"family={tool.family} | audience={tool.audience} | {tool.display_name} | {tool.description}"
                )
                for tool in tools
            ] or ["<empty>"]
            lines.extend(
                [
                    "",
                    "inspect: /tools inspect <tool-id>",
                    "enable: /tools enable <tool-id>",
                    "disable: /tools disable <tool-id>",
                    "install: /tools install </path/to/tools.json>",
                    'run terminal: /tools run tool.terminal.exec command="pwd"',
                    'run search: /tools run tool.file.search query="aegis"',
                    'run web: /tools run tool.web.search query="agentic intelligence"',
                    'read page: /tools run tool.web.read url="https://example.com"',
                    'manage goals: /tools run tool.goal.manage action=list',
                    'manage cron: /tools run tool.cron.manage action=list',
                ]
            )
            self._append_entry("notice", "Tools", "\n".join(lines))
            return
        if command == "inspect":
            if len(args) < 2:
                self._append_entry("recovery", "Tools", "Usage: /tools inspect <tool-id>")
                return
            tool = self.runtime.inspect_tool(args[1], session_id=self.session_id)
            self._append_entry(
                "status",
                "Tool",
                "\n".join(
                    [
                        f"tool_id: {tool.tool_id}",
                        f"display_name: {tool.display_name}",
                        f"enabled: {tool.enabled}",
                        f"available: {tool.available}",
                        f"availability_reason: {tool.availability.reason or '<none>'}",
                        f"version: {tool.version}",
                        f"family: {tool.family}",
                        f"audience: {tool.audience}",
                        f"backend: {tool.backend or '<none>'}",
                        f"description: {tool.description}",
                        f"categories: {', '.join(tool.side_effects.categories) or '<none>'}",
                        f"approval_class: {tool.side_effects.approval_class}",
                        f"risk_class: {tool.side_effects.risk_class}",
                        f"provenance: {tool.provenance or 'built-in'}",
                    ]
                ),
            )
            return
        if command in {"enable", "disable"}:
            if len(args) < 2:
                self._append_entry("recovery", "Tools", f"Usage: /tools {command} <tool-id>")
                return
            updated = self.runtime.set_tool_enabled(
                args[1],
                command == "enable",
                session_id=self.session_id,
            )
            self._append_entry("status", "Tool updated", f"{updated.tool_id}\nenabled: {updated.enabled}")
            return
        if command == "install":
            if len(args) < 2:
                self._append_entry("recovery", "Tools", "Usage: /tools install </path/to/tools.json>")
                return
            try:
                record = self.runtime.install_tool_manifest(args[1], session_id=self.session_id)
            except Exception as error:
                self._append_entry("recovery", "Tools", str(error))
                return
            self._append_entry(
                "status",
                "Tool manifest installed",
                "\n".join(
                    [
                        f"source_path: {record.source_path}",
                        f"tool_ids: {', '.join(record.tool_ids) or '<empty>'}",
                        f"executable_tool_ids: {', '.join(record.executable_tool_ids) or '<empty>'}",
                    ]
                ),
            )
            return
        if command == "run":
            if len(args) < 2:
                self._append_entry("recovery", "Tools", "Usage: /tools run <tool-id> key=value ...")
                return
            try:
                arguments = self._parse_named_arguments(args[2:])
            except ValueError as error:
                self._append_entry("recovery", "Tools", str(error))
                return
            try:
                result = self._run_tool_with_progress(args[1], arguments)
            except Exception as error:
                self._append_entry("recovery", "Tool result", str(error), meta=args[1])
                return
            self._append_entry(
                "assistant" if result.outcome == "success" else "recovery",
                "Tool result",
                result.summary,
                meta=f"{args[1]} · outcome={result.outcome}",
            )
            return
        self._append_entry("recovery", "Tools", "Usage: /tools [inspect|enable|disable|install|run]")

    def _append_skills(self, args: list[str]) -> None:
        command = args[0] if args else "list"
        if command in {"list", "ls"}:
            try:
                result = self._run_tool_with_progress("tool.skill.list", {"limit": "24"})
            except Exception as error:
                self._append_entry("recovery", "Skills", str(error))
                return
            lines = [result.summary or "<empty>"]
            lines.extend(
                [
                    "",
                    "active installed skills: /skills active",
                    "search external sources: /skills search <query>",
                    "view local or remote: /skills view <skill-id|reference>",
                    "enable: /skills enable <skill-id>",
                    "disable: /skills disable <skill-id>",
                    "install from source: /skills install <skill-id|reference>",
                    "install from path: /skills install </path/to/skill-or-skills.json>",
                ]
            )
            self._append_entry("notice", "Skills", "\n".join(lines))
            return
        if command == "active":
            skills = self.runtime.skill_catalog(session_id=self.session_id)
            lines = [
                f"{skill.skill_id} | enabled={skill.enabled} | {skill.display_name} | {skill.summary}"
                for skill in skills
                if skill.enabled
            ] or ["<empty>"]
            self._append_entry("notice", "Active skills", "\n".join(lines))
            return
        if command == "search":
            if len(args) < 2:
                self._append_entry("recovery", "Skills", "Usage: /skills search <query>")
                return
            try:
                result = self._run_tool_with_progress(
                    "tool.skill.search",
                    {
                        "query": " ".join(args[1:]),
                        "limit": "24",
                    },
                )
            except Exception as error:
                self._append_entry("recovery", "Skills", str(error))
                return
            lines = [result.summary or "<empty>"]
            lines.extend(
                [
                    "",
                    "install one: /skills install <reference>",
                    "view one: /skills view <reference>",
                ]
            )
            self._append_entry("notice", "Skill search", "\n".join(lines))
            return
        if command in {"inspect", "view"}:
            if len(args) < 2:
                self._append_entry("recovery", "Skills", "Usage: /skills view <skill-id|reference>")
                return
            try:
                result = self._run_tool_with_progress("tool.skill.view", {"skill_id": args[1]})
            except Exception as error:
                self._append_entry("recovery", "Skills", str(error))
                return
            skill = self.runtime.inspect_skill(args[1], session_id=self.session_id)
            lines = [
                f"skill_id: {skill.skill_id}",
                f"display_name: {skill.display_name}",
                f"enabled: {skill.enabled}",
                f"version: {skill.version}",
                f"summary: {skill.summary}",
                f"provenance: {skill.provenance or 'built-in'}",
            ]
            installed = skill.metadata.get("installed")
            if isinstance(installed, bool):
                lines.append(f"installed: {installed}")
            slash_command = str(skill.metadata.get("slash_command") or "").strip()
            if slash_command:
                lines.append(f"slash_command: /{slash_command}")
            if result.summary:
                lines.extend(["", result.summary])
            self._append_entry(
                "status",
                "Skill",
                "\n".join(lines),
            )
            return
        if command in {"enable", "disable"}:
            if len(args) < 2:
                self._append_entry("recovery", "Skills", f"Usage: /skills {command} <skill-id>")
                return
            try:
                result = self._run_tool_with_progress(
                    "tool.skill.manage",
                    {
                        "action": command,
                        "skill_id": args[1],
                    },
                )
            except Exception as error:
                self._append_entry("recovery", "Skills", str(error))
                return
            self._append_entry("status", "Skill updated", result.summary)
            return
        if command == "install":
            if len(args) < 2:
                self._append_entry("recovery", "Skills", "Usage: /skills install <skill-id|/path/to/skill|/path/to/skills.json>")
                return
            try:
                result = self._run_tool_with_progress(
                    "tool.skill.manage",
                    {
                        "action": "install",
                        "reference": args[1],
                    },
                )
            except Exception as error:
                self._append_entry("recovery", "Skills", str(error))
                return
            self._append_entry("status", "Skill installed", result.summary)
            self._refresh_skill_slash_specs()
            return
        self._append_entry("recovery", "Skills", "Usage: /skills [list|active|search|view|enable|disable|install]")

    def _dispatch_skill_slash_command(self, raw_command: str, command: str, args: list[str]) -> bool:
        spec = self._resolve_skill_slash_spec(command)
        if spec is None:
            return False
        try:
            self._run_tool_with_progress("tool.skill.view", {"skill_id": spec.skill_id})
            skill = self.runtime.inspect_skill(spec.skill_id, session_id=self.session_id)
        except Exception as error:
            self._append_entry("recovery", "Skill command", str(error), meta=command)
            return True
        if not args:
            lines = [
                f"display_name: {skill.display_name}",
                f"skill_id: {skill.skill_id}",
                f"summary: {skill.summary}",
                f"run: {spec.command} <instruction>",
            ]
            installed = skill.metadata.get("installed")
            if isinstance(installed, bool):
                lines.append(f"installed: {installed}")
            self._append_entry("status", "Skill loaded", "\n".join(lines), meta=spec.command)
            return True

        user_instruction = " ".join(args).strip()
        if not user_instruction:
            self._append_entry("recovery", "Skill command", f"Usage: {spec.command} <instruction>")
            return True
        self._append_entry("user", "You", raw_command)
        self._render_pending_entries()
        prompt = self._compose_skill_turn_prompt(skill, user_instruction=user_instruction)
        try:
            outcome = self._run_turn_with_progress(prompt)
        except Exception as error:
            self._append_entry(
                "recovery",
                "Skill command failed",
                f"{error}\ncommand: {spec.command}",
            )
            self._refresh_shell_frame()
            return True
        self._append_outcome(outcome)
        growth_update = self._show_growth_celebration_if_needed()
        self._append_growth_update_message(growth_update)
        self._refresh_shell_frame()
        return True

    def _compose_skill_turn_prompt(self, skill, *, user_instruction: str) -> str:
        return "\n".join(
            [
                f'[SYSTEM: This turn is being routed through the "{skill.display_name}" skill.]',
                "",
                f"Skill: {skill.display_name} ({skill.skill_id})",
                f"Summary: {skill.summary}",
                "You must follow this skill as the operating procedure for this turn.",
                "Execute the skill's preferred flow in order unless a step fails or the user explicitly overrides it.",
                "Do not substitute a different shortcut or unrelated search flow when the skill already provides an execution path.",
                "If the skill says to probe or install a prerequisite tool, do that before falling back.",
                "Follow these skill instructions before acting:",
                skill.instruction_text.strip(),
                "",
                f"User request: {user_instruction}",
            ]
        ).strip()

    def _append_cron(self, args: list[str]) -> None:
        command = args[0] if args else "list"
        if command in {"list", "ls"}:
            jobs = self.runtime.cron_jobs(session_id=self.session_id)
            lines = [
                f"{job.job_id} | {job.status} | {job.name} | {job.schedule_text} | {job.action_kind}"
                for job in jobs
            ] or ["<empty>"]
            lines.extend(
                [
                    "",
                    'create greeting: /cron create name="Morning hello" schedule="every morning" kind=greeting message="Good morning."',
                    'create web search: /cron create name="Web check" schedule="every 2h" kind=web_search query="agentic ai news"',
                    "inspect: /cron inspect <job-id>",
                    "pause: /cron pause <job-id>",
                    "resume: /cron resume <job-id>",
                    "remove: /cron remove <job-id>",
                ]
            )
            self._append_entry("notice", "Cron jobs", "\n".join(lines))
            return
        if command == "create":
            try:
                arguments = self._parse_named_arguments(args[1:])
            except ValueError as error:
                self._append_entry("recovery", "Cron jobs", str(error))
                return
            schedule = arguments.get("schedule", "").strip()
            action_kind = arguments.get("kind", "").strip()
            if not schedule or not action_kind:
                self._append_entry(
                    "recovery",
                    "Cron jobs",
                    "Usage: /cron create name=<name> schedule=<schedule> kind=greeting|web_search|prompt [message=...] [query=...] [prompt=...]",
                )
                return
            payload = {
                key: value
                for key, value in (
                    ("message", arguments.get("message")),
                    ("query", arguments.get("query")),
                    ("prompt", arguments.get("prompt")),
                )
                if value
            }
            name = arguments.get("name", "").strip() or f"Cron · {action_kind}"
            try:
                job = self.runtime.create_cron_job(
                    session_id=self.session_id,
                    name=name,
                    schedule=schedule,
                    action_kind=action_kind,
                    payload=payload,
                )
            except Exception as error:
                self._append_entry("recovery", "Cron jobs", str(error))
                return
            self._append_entry(
                "status",
                "Cron job created",
                "\n".join(
                    [
                        f"job_id: {job.job_id}",
                        f"name: {job.name}",
                        f"schedule: {job.schedule_text}",
                        f"action_kind: {job.action_kind}",
                        f"next_run_at: {job.next_run_at.isoformat() if job.next_run_at is not None else '<none>'}",
                    ]
                ),
            )
            return
        if command == "inspect":
            if len(args) < 2:
                self._append_entry("recovery", "Cron jobs", "Usage: /cron inspect <job-id>")
                return
            try:
                job = self.runtime.inspect_cron_job(args[1])
            except Exception as error:
                self._append_entry("recovery", "Cron jobs", str(error))
                return
            self._append_entry(
                "status",
                "Cron job",
                "\n".join(
                    [
                        f"job_id: {job.job_id}",
                        f"name: {job.name}",
                        f"status: {job.status}",
                        f"schedule: {job.schedule_text}",
                        f"action_kind: {job.action_kind}",
                        f"last_summary: {job.last_summary or '<none>'}",
                    ]
                ),
            )
            return
        if command in {"pause", "resume", "remove"}:
            if len(args) < 2:
                self._append_entry("recovery", "Cron jobs", f"Usage: /cron {command} <job-id>")
                return
            try:
                if command == "pause":
                    job = self.runtime.pause_cron_job(args[1])
                elif command == "resume":
                    job = self.runtime.resume_cron_job(args[1])
                else:
                    job = self.runtime.remove_cron_job(args[1])
            except Exception as error:
                self._append_entry("recovery", "Cron jobs", str(error))
                return
            self._append_entry(
                "status",
                "Cron job updated",
                "\n".join(
                    [
                        f"job_id: {job.job_id}",
                        f"name: {job.name}",
                        f"status: {'removed' if command == 'remove' else job.status}",
                    ]
                ),
            )
            return
        self._append_entry("recovery", "Cron jobs", "Usage: /cron [create|inspect|pause|resume|remove]")

    def _parse_named_arguments(self, args: list[str]) -> dict[str, str]:
        payload: dict[str, str] = {}
        for item in args:
            if "=" not in item:
                raise ValueError("tool arguments must be key=value pairs")
            key, value = item.split("=", 1)
            key = key.strip()
            if not key:
                raise ValueError("tool argument keys must not be empty")
            payload[key] = self._strip_wrapping_quotes(value.strip())
        return payload

    def _requested_webpage_url(self, message: str) -> str | None:
        lowered = message.strip().lower()
        match = WEB_URL_PATTERN.search(message)
        if match is None:
            return None
        if not any(
            phrase in lowered
            for phrase in (
                "read ",
                "open ",
                "fetch ",
                "visit ",
                "browse ",
                "look at ",
                "check ",
                "web page",
                "website",
                " url",
            )
        ):
            return None
        return match.group(1).rstrip(").,!?\"'")

    def _strip_wrapping_quotes(self, value: str) -> str:
        if len(value) >= 2 and value[0] == value[-1] and value[0] in {'"', "'"}:
            return value[1:-1].strip()
        return value

    def _append_status(self) -> None:
        session = self.runtime.inspect_session(self.session_id)
        provider = dict(self.runtime.provider_summary())
        continuity = self.runtime.inspect_continuity(session_id=self.session_id)
        growth = self.runtime.inspect_growth(session_id=self.session_id)
        lines = [
            f"session_id: {session.session_id}",
            f"clone_id: {self.runtime.clone_id_for_session(session)}",
            f"status: {session.status}",
            f"provider_id: {provider['provider_id']}",
            f"provider_source: {provider['source']}",
            f"provider_model_id: {provider['default_model'] or '<unset>'}",
            f"provider_context_window: {provider.get('context_window_tokens') or '<unset>'}",
            f"provider_secret_status: {provider.get('secret_status', '<unknown>')}",
            f"growth_action: {continuity.wake_action}",
            f"growth_summary: {continuity.wake_summary}",
            f"voice_status: {continuity.voice_status}",
            f"growth_title: {growth.stage.title}",
            f"growth_stage: {growth.stage.display_name}",
            f"growth_level: {growth.level}",
            f"growth_exp: {growth.state.growth_score}",
            f"growth_progress: {growth.progress_percent}%",
            f"growth_next: {growth.score_to_next_level} EXP to Lv.{min(growth.level + 1, 40)}",
            (
                "growth_lifetime: "
                f"dialogues={growth.state.total_dialogues} "
                f"tokens={growth.state.total_tokens} "
                f"experiences={growth.state.total_experiences} "
                f"promoted={growth.state.promoted_experiences} "
                f"active_days={growth.state.active_days}"
            ),
        ]
        experiences = self.runtime.inspect_experiences(session_id=self.session_id, limit=2)
        displayable = self._displayable_experiences(experiences)
        if displayable:
            lines.append(f"latest_learning: {self._format_experience_status(displayable[0])}")
        else:
            lines.append("latest_learning: no captured experience yet")
        self._append_entry("status", "Clone status", "\n".join(lines))

    def _append_goals(self, args: list[str]) -> None:
        action = args[0] if args else "list"
        if action in {"list", "ls"}:
            goals = self.runtime.inspect_goals(self.session_id)
            lines = [f"{goal.goal_id} | {goal.status} | {goal.priority} | {goal.title}" for goal in goals] or ["<empty>"]
            self._append_entry("notice", "Goals", "\n".join(lines))
            return
        if action == "inspect":
            if len(args) < 2:
                self._append_entry("recovery", "Goals", "Usage: /goals inspect <goal-id>")
                return
            goal = self.runtime.inspect_goal(self.session_id, args[1])
            lines = [
                f"id: {goal.goal_id}",
                f"title: {goal.title}",
                f"status: {goal.status}",
                f"priority: {goal.priority}",
                f"owner: {goal.owner or 'none'}",
                f"parent: {goal.parent_goal_id or 'none'}",
                f"deadline: {goal.deadline.isoformat() if goal.deadline is not None else 'none'}",
                f"time_sensitivity: {goal.time_sensitivity or 'normal'}",
                f"dependencies: {', '.join(goal.dependencies) or 'none'}",
                f"evidence: {', '.join(goal.evidence_refs) or 'none'}",
            ]
            self._append_entry("notice", "Goal detail", "\n".join(lines))
            return
        if action == "create":
            title = " ".join(args[1:]).strip()
            if not title:
                self._append_entry("recovery", "Goals", "Usage: /goals create <title>")
                return
            goal = self.runtime.create_goal(self.session_id, title=title)
            self._append_entry("notice", "Goal created", f"{goal.goal_id} | {goal.status} | {goal.priority} | {goal.title}")
            return
        if action == "focus":
            if len(args) < 2:
                self._append_entry("recovery", "Goals", "Usage: /goals focus <goal-id>")
                return
            _, updated, reason = self.runtime.update_goal(self.session_id, args[1], status="active", reason="goal focused from shell")
            self._append_entry("notice", "Goal focused", f"{reason}: {updated.goal_id} | {updated.status} | {updated.priority} | {updated.title}")
            return
        if action in {"drop", "delete"}:
            if len(args) < 2:
                self._append_entry("recovery", "Goals", "Usage: /goals drop <goal-id>")
                return
            _, updated = self.runtime.delete_goal(self.session_id, args[1], reason="goal dropped from shell")
            self._append_entry("notice", "Goal dropped", f"{updated.goal_id} | {updated.status} | {updated.priority} | {updated.title}")
            return
        self._append_entry("recovery", "Goals", "Usage: /goals [list|inspect|create|focus|drop]")

    def _append_memory(self) -> None:
        memories = self.runtime.inspect_memories(self.session_id)
        lines = [
            f"{memory.memory_id} | {memory.kind} | {', '.join(memory.tags) or '<none>'} | {memory.content}"
            for memory in memories
        ] or ["<empty>"]
        self._append_entry("notice", "Memory", "\n".join(lines))

    def _resume_session(self, target: str) -> None:
        if target == "latest":
            latest = self.runtime.latest_session()
            if latest is None:
                self._append_entry(
                    "recovery",
                    "Resume",
                    'No existing clone is available. Create one from the CLI with: aegis clone <name> --initial-goal "..."',
                )
                return
            self.session_id = latest.session_id
            self.opened = f"Opened clone {self.runtime.clone_id_for_session(latest)}"
        else:
            clone_session = self.runtime.latest_session_for_clone(target)
            if clone_session is not None:
                self.session_id = clone_session.session_id
                self.opened = f"Opened clone {target}"
            else:
                self.runtime.inspect_session(target)
                self.session_id = target
                selected = self.runtime.inspect_session(target)
                self.opened = f"Opened clone {self.runtime.clone_id_for_session(selected)}"
        self._append_entry("status", "Resume", f"{self.opened} via session {self.session_id}.")
        self._append_status()

    def _append_identity(self, args: list[str]) -> None:
        action = args[0] if args else "inspect"
        profile_id = self.runtime.inspect_session(self.session_id).profile_id
        if action == "inspect":
            lines = self._identity_lines(profile_id)
            lines.extend(
                [
                    "set name: /identity set-name <display-name>",
                    "charter: /identity charter show|set|clear",
                    "initiative: /identity initiative <value>",
                    "preset: /identity preset <preset-id>",
                    "user: /user show|set|append|clear",
                    "relationship: /relationship show|set|append|clear",
                ]
            )
            self._append_entry("notice", "Identity", "\n".join(lines))
            return
        if action == "set-name":
            if len(args) < 2:
                self._append_entry("recovery", "Identity", "Usage: /identity set-name <display-name>")
                return
            record = self.runtime.update_identity_state(profile_id=profile_id, display_name=" ".join(args[1:]))
            self._append_entry("notice", "Identity updated", f"display_name: {record.display_name}")
            return
        if action == "initiative":
            if len(args) != 2:
                self._append_entry("recovery", "Identity", "Usage: /identity initiative <value>")
                return
            record = self.runtime.update_identity_state(profile_id=profile_id, initiative=args[1])
            self._append_entry("notice", "Identity updated", f"initiative: {record.initiative}")
            return
        if action in {"preset", "personality"}:
            if len(args) != 2:
                self._append_entry("recovery", "Identity", "Usage: /identity preset <preset-id>")
                return
            record = self.runtime.update_identity_state(profile_id=profile_id, personality_preset=args[1])
            self._append_entry(
                "notice",
                "Identity updated",
                f"personality_preset: {record.personality_preset}\nworking_style_contract: {record.working_style_contract}",
            )
            return
        if action in {"charter", "clone"}:
            self._append_identity_charter(profile_id, args[1:], alias_label="CLONE" if action == "clone" else "Identity charter")
            return
        self._append_entry("recovery", "Identity", "Usage: /identity inspect|set-name|charter|initiative|preset")

    def _append_identity_charter(self, profile_id: str, args: list[str], *, alias_label: str = "Identity charter") -> None:
        action = args[0] if args else "show"
        if action == "show":
            record = self.runtime.inspect_identity(profile_id=profile_id)
            self._append_entry(
                "notice",
                alias_label,
                "\n".join(
                    [
                        f"profile_id: {record.profile_id}",
                        f"clone_id: {record.clone_id}",
                        f"charter_extension: {record.charter_extension or '<empty>'}",
                    ]
                ),
            )
            return
        if action == "set":
            if len(args) < 2:
                self._append_entry("recovery", alias_label, "Usage: /identity charter set <text>")
                return
            try:
                self._run_state_surface_update(
                    tool_id="tool.identity.manage",
                    arguments={"action": "set", "text": " ".join(args[1:])},
                )
            except Exception as error:
                self._append_entry("recovery", alias_label, str(error))
                return
            record = self.runtime.inspect_identity(profile_id=profile_id)
            self._append_entry("notice", f"{alias_label} updated", f"charter_extension: {record.charter_extension or '<empty>'}")
            return
        if action == "clear":
            try:
                self._run_state_surface_update(tool_id="tool.identity.manage", arguments={"action": "clear"})
            except Exception as error:
                self._append_entry("recovery", alias_label, str(error))
                return
            self._append_entry("notice", f"{alias_label} updated", "status: cleared")
            return
        self._append_entry("recovery", alias_label, "Usage: /identity charter show|set|clear")

    def _append_user(self, args: list[str], *, alias_title: str = "User") -> None:
        action = args[0] if args else "show"
        profile_id = self.runtime.inspect_session(self.session_id).profile_id
        if action == "show":
            self._append_entry("notice", alias_title, "\n".join(self._user_lines(profile_id)))
            return
        if action == "set":
            if len(args) < 2:
                self._append_entry("recovery", alias_title, f"Usage: /{alias_title.lower()} set <text>")
                return
            try:
                self._run_state_surface_update(
                    tool_id="tool.user.manage",
                    arguments={"action": "set", "text": " ".join(args[1:])},
                )
            except Exception as error:
                self._append_entry("recovery", alias_title, str(error))
                return
            self._append_entry("notice", f"{alias_title} updated", "\n".join(self._user_lines(profile_id)))
            return
        if action == "append":
            if len(args) < 2:
                self._append_entry("recovery", alias_title, f"Usage: /{alias_title.lower()} append <text>")
                return
            try:
                self._run_state_surface_update(
                    tool_id="tool.user.manage",
                    arguments={"action": "append", "text": " ".join(args[1:])},
                )
            except Exception as error:
                self._append_entry("recovery", alias_title, str(error))
                return
            self._append_entry("notice", f"{alias_title} updated", "\n".join(self._user_lines(profile_id)))
            return
        if action == "clear":
            try:
                self._run_state_surface_update(tool_id="tool.user.manage", arguments={"action": "clear"})
            except Exception as error:
                self._append_entry("recovery", alias_title, str(error))
                return
            self._append_entry("notice", f"{alias_title} updated", "status: cleared")
            return
        self._append_entry("recovery", alias_title, "Usage: /user show|set|append|clear")

    def _append_relationship(self, args: list[str]) -> None:
        action = args[0] if args else "show"
        profile_id = self.runtime.inspect_session(self.session_id).profile_id
        if action == "show":
            self._append_entry("notice", "Relationship", "\n".join(self._relationship_lines(profile_id)))
            return
        if action == "set":
            if len(args) < 2:
                self._append_entry("recovery", "Relationship", "Usage: /relationship set <text>")
                return
            try:
                self._run_state_surface_update(
                    tool_id="tool.relationship.manage",
                    arguments={"action": "set", "text": " ".join(args[1:])},
                )
            except Exception as error:
                self._append_entry("recovery", "Relationship", str(error))
                return
            self._append_entry("notice", "Relationship updated", "\n".join(self._relationship_lines(profile_id)))
            return
        if action == "append":
            if len(args) < 2:
                self._append_entry("recovery", "Relationship", "Usage: /relationship append <text>")
                return
            try:
                self._run_state_surface_update(
                    tool_id="tool.relationship.manage",
                    arguments={"action": "append", "text": " ".join(args[1:])},
                )
            except Exception as error:
                self._append_entry("recovery", "Relationship", str(error))
                return
            self._append_entry("notice", "Relationship updated", "\n".join(self._relationship_lines(profile_id)))
            return
        if action == "clear":
            try:
                self._run_state_surface_update(tool_id="tool.relationship.manage", arguments={"action": "clear"})
            except Exception as error:
                self._append_entry("recovery", "Relationship", str(error))
                return
            self._append_entry("notice", "Relationship updated", "status: cleared")
            return
        self._append_entry("recovery", "Relationship", "Usage: /relationship show|set|append|clear")

    def _append_brain(self, args: list[str]) -> None:
        action = args[0] if args else "configure"
        if action in {"configure", "config"}:
            self._append_providers([])
            return
        if action == "status":
            provider = dict(self.runtime.provider_summary())
            provider_id = str(provider.get("provider_id") or "openai-compatible")
            discovered = self.runtime.discovered_provider(provider_id)
            self._append_entry(
                "status",
                "Brain",
                "\n".join(
                    [
                        f"provider_id: {provider.get('provider_id', '<unset>')}",
                        f"display_name: {provider.get('display_name', provider.get('provider_id', '<unset>'))}",
                        f"base_url: {provider.get('base_url') or '<unset>'}",
                        f"transport: {provider.get('transport_display_name', provider.get('transport_id', '<unset>'))}",
                        f"default_model: {provider.get('default_model') or '<unset>'}",
                        f"context_window_tokens: {provider.get('context_window_tokens') or '<unset>'}",
                        f"context_window_mode: {provider.get('context_window_mode') or '<unset>'}",
                        f"reasoning_effort: {provider.get('reasoning_effort') or '<unset>'}",
                        f"reasoning_efforts: {', '.join(provider.get('reasoning_efforts', ())) or '<none>'}",
                        f"secret_status: {provider.get('secret_status', '<unknown>')}",
                        f"secret_source: {provider.get('secret_source', '<unknown>')}",
                        f"discovery_status: {discovered.status}",
                        f"discovery_source: {discovered.source}",
                    ]
                ),
            )
            return
        if action in {"providers", "provider"}:
            self._append_providers(["list"])
            return
        if action in {"models", "model"}:
            self._append_models(["list"])
            return
        self._append_entry("recovery", "Brain", "Usage: /brain configure|status|providers|models")

    def _append_providers(self, args: list[str]) -> None:
        action = args[0] if args else "configure"
        if action in {"list", "ls"}:
            lines = [
                (
                    f"{state.provider_id} | {state.display_name} | {state.transport_display_name} | "
                    f"status={state.status} | source={state.source}"
                )
                for state in self.runtime.provider_inventory()
                if state.runtime_enabled
            ] or ["<empty>"]
            lines.extend(
                [
                    "",
                    "/brain - open the unified provider and model setup flow",
                    "/brain status - inspect the active provider and model posture",
                ]
            )
            self._append_entry("notice", "Providers", "\n".join(lines))
            return
        if action == "status":
            provider = dict(self.runtime.provider_summary())
            discovered = self.runtime.discovered_provider(str(provider.get("provider_id") or "openai-compatible"))
            self._append_entry(
                "status",
                "Provider",
                "\n".join(
                    [
                        f"provider_id: {provider.get('provider_id', '<unset>')}",
                        f"display_name: {provider.get('display_name', provider.get('provider_id', '<unset>'))}",
                        f"base_url: {provider.get('base_url') or '<unset>'}",
                        f"default_model: {provider.get('default_model') or '<unset>'}",
                        f"context_window_tokens: {provider.get('context_window_tokens') or '<unset>'}",
                        f"context_window_mode: {provider.get('context_window_mode') or '<unset>'}",
                        f"reasoning_effort: {provider.get('reasoning_effort') or '<unset>'}",
                        f"reasoning_efforts: {', '.join(provider.get('reasoning_efforts', ())) or '<none>'}",
                        f"secret_status: {provider.get('secret_status', '<unknown>')}",
                        f"secret_source: {provider.get('secret_source', '<unknown>')}",
                        f"discovery_status: {discovered.status}",
                        f"discovery_source: {discovered.source}",
                        f"transport: {provider.get('transport_display_name', provider.get('transport_id', '<unset>'))}",
                    ]
                ),
            )
            return
        session = self.runtime.inspect_session(self.session_id)
        profile = self.runtime.inspect_profile(session.profile_id)
        provider = dict(self.runtime.provider_summary())
        current_provider_id = str(provider.get("provider_id") or "openai-compatible")
        initial_state = provider_setup_defaults(self.runtime, current_provider_id)
        initial_state.base_url = str(provider.get("base_url") or initial_state.base_url)
        initial_state.default_model = str(provider.get("default_model") or initial_state.default_model)
        initial_state.reasoning_effort = (
            str(provider.get("reasoning_effort")).strip()
            if provider.get("reasoning_effort") is not None
            else initial_state.reasoning_effort
        ) or None
        configured = run_provider_selection_wizard(
            self.runtime,
            initial_state=initial_state,
            allow_back=True,
        )
        if configured is WIZARD_BACK:
            self._append_entry("notice", "Providers", "Provider setup cancelled.")
            return
        updated = self.runtime.set_default_provider(
            provider_id=configured.provider_id,
            profile_id=profile.state.profile_id,
            display_name=profile.state.display_name,
            mode=profile.state.mode,
            base_url=configured.base_url,
            default_model=configured.default_model,
            api_key=configured.api_key,
            context_window_tokens=configured.context_window_tokens,
            context_window_mode=configured.context_window_mode,
            reasoning_effort=configured.reasoning_effort,
        )
        self._append_entry(
            "status",
            "Provider updated",
            "\n".join(
                [
                    f"provider_id: {configured.provider_id}",
                    f"base_url: {configured.base_url}",
                    f"default_model: {configured.default_model}",
                    f"context_window_tokens: {configured.context_window_tokens or '<unset>'}",
                    f"context_window_mode: {configured.context_window_mode}",
                    f"reasoning_effort: {configured.reasoning_effort or '<unset>'}",
                    f"display_name: {updated.state.display_name}",
                ]
            ),
        )

    def _append_models(self, args: list[str]) -> None:
        action = args[0] if args else "configure"
        provider = dict(self.runtime.provider_summary())
        provider_id = str(provider.get("provider_id") or "")
        if provider_id in {"", "preview"}:
            self._append_entry("recovery", "Models", "Configure a provider first with /brain.")
            return
        if action in {"list", "ls"}:
            try:
                models = self.runtime.discover_provider_models(provider_id=provider_id)
            except Exception as error:
                self._append_entry("recovery", "Models", str(error))
                return
            lines = [
                (
                    f"{model.model_id} | context={model.context_window_tokens or '<unknown>'} | "
                    f"output={model.max_output_tokens or '<unknown>'}"
                )
                for model in models
            ] or ["<empty>"]
            lines.extend(
                [
                    "",
                    "/brain - open the unified provider and model setup flow",
                    "/brain status - inspect the active provider and model posture",
                ]
            )
            self._append_entry("notice", "Models", "\n".join(lines))
            return
        if action == "status":
            self._append_entry(
                "status",
                "Model",
                "\n".join(
                    [
                        f"provider_id: {provider_id}",
                        f"default_model: {provider.get('default_model') or '<unset>'}",
                        f"context_window_tokens: {provider.get('context_window_tokens') or '<unset>'}",
                        f"context_window_mode: {provider.get('context_window_mode') or '<unset>'}",
                        f"reasoning_effort: {provider.get('reasoning_effort') or '<unset>'}",
                        f"reasoning_efforts: {', '.join(provider.get('reasoning_efforts', ())) or '<none>'}",
                        f"supports_streaming: {provider.get('supports_streaming', '<unknown>')}",
                    ]
                ),
            )
            return
        session = self.runtime.inspect_session(self.session_id)
        profile = self.runtime.inspect_profile(session.profile_id)
        initial_state = provider_setup_defaults(self.runtime, provider_id)
        initial_state.base_url = str(provider.get("base_url") or initial_state.base_url)
        initial_state.default_model = str(provider.get("default_model") or initial_state.default_model)
        initial_state.reasoning_effort = (
            str(provider.get("reasoning_effort")).strip()
            if provider.get("reasoning_effort") is not None
            else initial_state.reasoning_effort
        ) or None
        initial_state.context_window_mode = str(provider.get("context_window_mode") or initial_state.context_window_mode)
        if provider.get("context_window_tokens") is not None:
            try:
                initial_state.context_window_tokens = int(provider["context_window_tokens"])
            except (TypeError, ValueError):
                initial_state.context_window_tokens = initial_state.context_window_tokens
        configured = run_provider_selection_wizard(
            self.runtime,
            initial_state=initial_state,
            allow_back=True,
            provider_locked=True,
        )
        if configured is WIZARD_BACK:
            self._append_entry("notice", "Models", "Model setup cancelled.")
            return
        self.runtime.set_default_provider(
            provider_id=configured.provider_id,
            profile_id=profile.state.profile_id,
            display_name=profile.state.display_name,
            mode=profile.state.mode,
            base_url=configured.base_url,
            default_model=configured.default_model,
            api_key=configured.api_key,
            context_window_tokens=configured.context_window_tokens,
            context_window_mode=configured.context_window_mode,
            reasoning_effort=configured.reasoning_effort,
        )
        self._append_entry(
            "status",
            "Model updated",
            "\n".join(
                [
                    f"provider_id: {configured.provider_id}",
                    f"default_model: {configured.default_model}",
                    f"context_window_tokens: {configured.context_window_tokens or '<unset>'}",
                    f"context_window_mode: {configured.context_window_mode}",
                    f"reasoning_effort: {configured.reasoning_effort or '<unset>'}",
                ]
            ),
        )

    def _run_state_surface_update(self, *, tool_id: str, arguments: dict[str, object]):
        self._run_tool_with_progress(tool_id, arguments)
        profile_id = self.runtime.inspect_session(self.session_id).profile_id
        return self.runtime.inspect_profile(profile_id)

    def _append_doctor(self) -> None:
        provider = self.runtime.provider_doctor()
        voice = self.runtime.voice_doctor(profile_id=self.runtime.inspect_session(self.session_id).profile_id)
        security = self.runtime.security_doctor()
        lines = [
            f"provider_status: {provider['status']}",
            f"voice_status: {voice['status']}",
            f"security_status: {security['status']}",
        ]
        for check in provider["checks"]:
            summary = f" | {check['summary']}" if check.get("summary") else ""
            lines.append(f"{check['check']}: {check['status']}{summary}")
        for check in voice["checks"]:
            summary = f" | {check['summary']}" if check.get("summary") else ""
            lines.append(f"voice/{check['check']}: {check['status']}{summary}")
        if provider["status"] != "ready":
            lines.append("next: exit and run aegis born")
        else:
            lines.append("next: keep talking")
        self._append_entry("notice", "Health", "\n".join(lines))

    def _append_wake(self) -> None:
        try:
            outcome = self.runtime.wake(self.session_id, inspect_only=True)
        except Exception:
            continuity = self.runtime.inspect_continuity(session_id=self.session_id)
            self._append_entry(
                "notice",
                "Growth progression",
                "\n".join(
                    [
                        "mode: foreground",
                        f"selected_kind: {continuity.wake_action}",
                        "selected_goal_id: <none>",
                        f"rationale: {continuity.wake_summary}",
                        "planned_active_goal_id: <none>",
                    ]
                ),
            )
            return
        lines = [
            f"mode: {outcome.decision.mode}",
            f"selected_kind: {outcome.decision.selected_move.kind}",
            f"selected_goal_id: {outcome.decision.selected_move.goal_id or '<none>'}",
            f"rationale: {outcome.decision.rationale.summary}",
            f"planned_active_goal_id: {outcome.planned_goal_graph.active_goal_id or '<none>'}",
            f"reconciliation: {outcome.reconciliation.summary}",
        ]
        self._append_entry("notice", "Growth progression", "\n".join(lines))

    def _append_outcome(self, outcome: KernelOutcome) -> None:
        self._last_prompt_tokens = outcome.execution.prompt_tokens
        self._last_completion_tokens = outcome.execution.completion_tokens
        self._last_total_tokens = outcome.execution.total_tokens
        if self.debug and outcome.stages:
            stage_lines = [
                f"{stage.stage} | {stage.detail} | {stage.recorded_at.isoformat(timespec='seconds')}"
                for stage in outcome.stages
            ]
            self._append_entry("status", "Runtime stages", "\n".join(stage_lines))
        assistant_name = self.runtime.inspect_profile(self.runtime.inspect_session(self.session_id).profile_id).state.display_name
        assistant_lines = [outcome.execution.summary]
        if self.debug and outcome.plan is not None:
            assistant_lines.append(f"plan: {outcome.plan.rationale}")
        if self.debug:
            assistant_lines.extend(
                [
                    f"execution: {outcome.execution.outcome}",
                    f"goals_in_play: {len(outcome.goals)}",
                    f"memory_hits: {len(outcome.memories)}",
                ]
            )
        self._append_entry("assistant", assistant_name, "\n".join(assistant_lines))

    def _show_growth_celebration_if_needed(self):
        update = self.runtime.consume_growth_update(session_id=self.session_id)
        if update is None or not update.leveled_up:
            return None
        if not self._animations_enabled() or Live is None:
            return update
        if update.stage_changed:
            final_tick = 5
            with Live(
                self._render_stage_transition_frame(update, tick=0),
                console=self.console,
                refresh_per_second=24,
                transient=True,
            ) as live:
                for tick in range(final_tick + 1):
                    live.update(self._render_stage_transition_frame(update, tick=tick), refresh=True)
                    time.sleep(0.14)
            self.console.print(self._render_stage_transition_frame(update, tick=final_tick))
            time.sleep(1.05)
            return update
        final_tick = 5
        with Live(
            self._render_level_up_frame(update, tick=0),
            console=self.console,
            refresh_per_second=24,
            transient=True,
        ) as live:
            for tick in range(final_tick + 1):
                live.update(self._render_level_up_frame(update, tick=tick), refresh=True)
                time.sleep(0.12)
        self.console.print(self._render_level_up_frame(update, tick=final_tick))
        time.sleep(1.2)
        return update

    def _append_growth_update_message(self, update) -> None:
        if update is None:
            return
        continuity = self.runtime.inspect_continuity(session_id=self.session_id)
        assistant_name = continuity.profile.state.display_name or "Aegis"
        if update.stage_changed:
            body = (
                f"I just crossed into {update.after.stage.title} at Lv.{update.after.level}. "
                "Thanks for staying with me while I grow."
            )
            meta = "growth · stage-shift"
        else:
            body = (
                f"I just reached Lv.{update.after.level}. "
                "Thanks for staying with me while I grow."
            )
            meta = "growth · level-up ✨"
        self._append_entry("growth", assistant_name, body, meta=meta)

    def _render_level_up_frame(self, update, *, tick: int):
        marker = ("*", "+", "*", "+")[tick % 4]
        body = Text()
        body.append(f"{marker} LEVEL UP\n", style=f"bold {BRAND_ACCENT_STRONG}")
        body.append(f"{update.after.stage.title}\n", style=f"bold {BRAND_LIGHT}")
        body.append(f"Lv.{update.before.level} -> Lv.{update.after.level}\n", style=BRAND_LIGHT)
        body.append(f"EXP +{update.delta_score} · ", style=BRAND_MUTED)
        body.append_text(self._styled_growth_progress_bar(update.after))
        body.append(f" · {update.after.progress_percent}%", style=BRAND_MUTED)
        return Panel(
            body,
            title=f"[bold {BRAND_ACCENT}]Aegis is evolving[/bold {BRAND_ACCENT}]",
            border_style=BRAND_ACCENT,
            padding=(0, 1),
        )

    def _render_stage_transition_frame(self, update, *, tick: int):
        if Table is None or Group is None:
            return Text(
                f"Stage shift: {update.before.stage.display_name} -> {update.after.stage.display_name} "
                f"(Lv.{update.after.level})"
            )
        body = Table.grid(expand=True)
        body.add_column(ratio=1, justify="center")
        body.add_column(ratio=1, justify="center")
        left_mark = self._render_growth_mark(update.before.stage.stage_id, level=update.before.level)
        right_mark = self._render_growth_mark(update.after.stage.stage_id, level=update.after.level)
        if tick % 2 == 1:
            left_mark, right_mark = right_mark, left_mark
        body.add_row(left_mark, right_mark)
        caption = Text()
        caption.append("STAGE SHIFT\n", style=f"bold {BRAND_ACCENT_STRONG}")
        caption.append(
            f"{update.before.stage.title} -> {update.after.stage.title}\n",
            style=f"bold {BRAND_LIGHT}",
        )
        caption.append(
            f"Lv.{update.before.level} -> Lv.{update.after.level} · {update.after.score_to_next_level} EXP to next level",
            style=BRAND_MUTED,
        )
        return Panel(
            Group(body, caption),
            title=f"[bold {BRAND_ACCENT}]Aegis crossed a new stage[/bold {BRAND_ACCENT}]",
            border_style=BRAND_ACCENT,
            padding=(0, 1),
        )

    def _identity_lines(self, profile_id: str) -> list[str]:
        profile = self.runtime.inspect_profile(profile_id)
        identity = self.runtime.inspect_identity(profile_id=profile_id)
        user = self.runtime.inspect_user(profile_id=profile_id)
        relationship = self.runtime.inspect_relationship(profile_id=profile_id)
        lines = [
            f"profile_id: {profile.state.profile_id}",
            f"display_name: {identity.display_name}",
            f"mode: {profile.state.mode}",
            f"clone_id: {identity.clone_id}",
            f"identity_mode: {identity.identity_mode}",
            f"personality_preset: {identity.personality_preset}",
            f"initiative: {identity.initiative}",
            f"relational_stance: {identity.relational_stance}",
            f"charter_extension: {identity.charter_extension or '<empty>'}",
            f"voice_identity_summary: {identity.voice_contract}",
            f"user_preferred_name: {user.preferred_name or '<empty>'}",
            f"relationship_notes: {', '.join(relationship.continuity_notes) or '<empty>'}",
        ]
        full_contract = self.runtime.prompt_contract(profile_id=profile_id, prompt_mode="full")
        minimal_contract = self.runtime.prompt_contract(profile_id=profile_id, prompt_mode="minimal")
        lines.extend(
            [
                f"prompt_contract_full: {', '.join(full_contract.section_names)}",
                f"prompt_contract_minimal: {', '.join(minimal_contract.section_names)}",
            ]
        )
        return lines

    def _user_lines(self, profile_id: str) -> list[str]:
        user = self.runtime.inspect_user(profile_id=profile_id)
        return [
            f"profile_id: {user.profile_id}",
            f"user_card_id: {user.user_card_id}",
            f"preferred_name: {user.preferred_name or '<empty>'}",
            f"locale: {user.locale or '<empty>'}",
            f"timezone: {user.timezone or '<empty>'}",
            f"communication_preferences: {', '.join(user.communication_preferences) or '<empty>'}",
            f"boundaries: {', '.join(user.boundaries) or '<empty>'}",
            f"biography_fragments: {', '.join(user.biography_fragments) or '<empty>'}",
            f"shared_preferences: {', '.join(user.shared_preferences) or '<empty>'}",
        ]

    def _relationship_lines(self, profile_id: str) -> list[str]:
        relationship = self.runtime.inspect_relationship(profile_id=profile_id)
        return [
            f"profile_id: {relationship.profile_id}",
            f"relationship_id: {relationship.relationship_id}",
            f"clone_id: {relationship.clone_id}",
            f"user_card_id: {relationship.user_card_id or '<empty>'}",
            f"interaction_preferences: {', '.join(relationship.interaction_preferences) or '<empty>'}",
            f"expectations: {', '.join(relationship.expectations) or '<empty>'}",
            f"continuity_notes: {', '.join(relationship.continuity_notes) or '<empty>'}",
        ]

    def _append_entry(self, kind: str, title: str, body: str, *, meta: str = "") -> None:
        self.transcript.append(TranscriptEntry(kind=kind, title=title, body=body, meta=meta))
        if len(self.transcript) > 80:
            overflow = len(self.transcript) - 80
            self.transcript = self.transcript[overflow:]
            self._rendered_entries = max(0, self._rendered_entries - overflow)

    def _append_tooltrace_line(self, line: str) -> None:
        if self.transcript and self.transcript[-1].kind == "tooltrace":
            previous = self.transcript[-1]
            combined = previous.body.rstrip("\n")
            combined = f"{combined}\n{line}" if combined else line
            self.transcript[-1] = TranscriptEntry(
                kind=previous.kind,
                title=previous.title,
                body=combined,
                meta=previous.meta,
            )
            return
        self._append_entry("tooltrace", "Tool trace", line)

    def _capture_pending_file_review(self, tool_event: ToolLifecycleEvent) -> None:
        if tool_event.phase != "requested":
            return
        if tool_event.invocation.tool_id not in {"tool.file.write", "tool.file.patch"}:
            return
        raw_path = str(tool_event.invocation.arguments.get("path") or "").strip()
        if not raw_path:
            return
        try:
            path = resolve_workspace_path(Path.cwd(), raw_path, must_exist=False)
        except Exception:
            return
        before_text = path.read_text(encoding="utf-8", errors="replace") if path.exists() else None
        self._pending_file_reviews[tool_event.invocation.invocation_id] = _PendingFileReview(
            path=path,
            before_text=before_text,
        )

    def _todo_trace_lines(self) -> tuple[str, ...]:
        todo_glyph = _shell_tool_trace_emoji("tool.todo.manage")
        items = self.runtime.todo_store.list_items(self.session_id)
        if not items:
            return (f"┊ {todo_glyph} todo items   <empty>",)
        lines = [f"┊ {todo_glyph} todo items   {len(items)} item(s)"]
        visible_items = items[:6]
        for index, item in enumerate(visible_items, start=1):
            goal_part = f" | goal={item.goal_id}" if item.goal_id else ""
            detail = _compact_line(f"{item.status} | {item.title}{goal_part}", limit=108)
            lines.append(f"┊ {todo_glyph} {f'item {index}':<12} {detail}")
        if len(items) > len(visible_items):
            remaining = len(items) - len(visible_items)
            lines.append(f"┊ {todo_glyph} more        {remaining} additional item(s)")
        return tuple(lines)

    def _display_tool_diff_path(self, path: Path) -> str:
        resolved = path.expanduser().resolve()
        try:
            return str(resolved.relative_to(Path.cwd().resolve()))
        except ValueError:
            return str(resolved)

    def _file_review_trace_lines(self, tool_event: ToolLifecycleEvent) -> tuple[str, ...]:
        snapshot = self._pending_file_reviews.pop(tool_event.invocation.invocation_id, None)
        if snapshot is None:
            return ()
        after_text = snapshot.path.read_text(encoding="utf-8", errors="replace") if snapshot.path.exists() else None
        if snapshot.before_text == after_text:
            return ()
        display_path = self._display_tool_diff_path(snapshot.path)
        diff_lines = list(
            unified_diff(
                [] if snapshot.before_text is None else snapshot.before_text.splitlines(),
                [] if after_text is None else after_text.splitlines(),
                fromfile=f"a/{display_path}",
                tofile=f"b/{display_path}",
                lineterm="",
            )
        )
        if not diff_lines:
            return ()
        review_glyph = _shell_tool_trace_emoji(tool_event.invocation.tool_id)
        rendered: list[str] = [f"┊ {review_glyph} diff"]
        from_file: str | None = None
        for raw_line in diff_lines:
            if raw_line.startswith("--- "):
                from_file = raw_line[4:].strip()
                continue
            if raw_line.startswith("+++ "):
                to_file = raw_line[4:].strip()
                rendered.append(f"{from_file or 'a/?'} → {to_file or 'b/?'}")
                continue
            rendered.append(raw_line)
        max_lines = 80
        overflow = len(rendered) - max_lines
        if overflow > 0:
            rendered = rendered[:max_lines]
            rendered.append(f"… omitted {overflow} diff line(s)")
        return tuple(rendered)

    def _tool_result_trace_lines(self, tool_event: ToolLifecycleEvent) -> tuple[str, ...]:
        if tool_event.phase == "execution.failed":
            self._pending_file_reviews.pop(tool_event.invocation.invocation_id, None)
            return ()
        if tool_event.phase != "execution.completed":
            return ()
        if tool_event.invocation.tool_id == "tool.todo.manage":
            return self._todo_trace_lines()
        if tool_event.invocation.tool_id in {"tool.file.write", "tool.file.patch"}:
            return self._file_review_trace_lines(tool_event)
        return ()

    def _boot_growth_stage(self, active: int) -> tuple[str, int]:
        if active < 0:
            return ("seed", 0)
        stages = (
            ("seed", 1),
            ("hatchling", 2),
            ("scout", 3),
            ("guardian", 4),
        )
        return stages[min(active, len(stages) - 1)]

    def _record_tool_event_trace(self, tool_event: ToolLifecycleEvent) -> None:
        self._capture_pending_file_review(tool_event)
        line = self._tool_trace_line(tool_event)
        if line is not None:
            self._append_tooltrace_line(line)
        for extra_line in self._tool_result_trace_lines(tool_event):
            self._append_tooltrace_line(extra_line)

    def _animations_enabled(self) -> bool:
        return _shell_animations_enabled()

    def _turn_phase(self, tick: int) -> tuple[str, str, str]:
        return _shell_turn_phase(tick)

    def _summarize_progress_prompt(self, prompt: str) -> str:
        return _summarize_shell_progress_prompt(prompt)

    def _render_turn_progress_fragments(
        self,
        *,
        prompt: str,
        tick: int,
        tool_event: ToolLifecycleEvent | None = None,
        queued_count: int = 0,
        stream_text: str = "",
    ) -> FormattedText:
        return _render_shell_turn_progress_fragments(
            self,
            prompt=prompt,
            tick=tick,
            tool_event=tool_event,
            queued_count=queued_count,
            stream_text=stream_text,
        )

    def _render_queued_followup_fragments(self) -> FormattedText:
        return _render_shell_queued_followup_fragments(self)

    def _run_turn_with_queued_input(self, prompt: str) -> KernelOutcome:
        return _run_shell_turn_with_queued_input(self, prompt)

    def _run_turn_with_progress(self, prompt: str) -> KernelOutcome:
        return _run_shell_turn_with_progress(self, prompt)

    def _run_tool_with_progress(self, tool_id: str, arguments: dict[str, str]):
        return _run_shell_tool_with_progress(self, tool_id, arguments)

    def _tool_event_tracker(self):
        return _shell_tool_event_tracker()

    def _render_turn_frame(
        self,
        *,
        prompt: str,
        tick: int,
        tool_event: ToolLifecycleEvent | None = None,
        stream_text: str = "",
    ):
        return _render_shell_turn_frame(
            self,
            prompt=prompt,
            tick=tick,
            tool_event=tool_event,
            stream_text=stream_text,
        )

    def _render_tool_frame(self, *, tool_id: str, tick: int, tool_event: ToolLifecycleEvent | None = None):
        return _render_shell_tool_frame(self, tool_id=tool_id, tick=tick, tool_event=tool_event)

    def _tool_frame_phases(self, tool_id: str, *, tool_event: ToolLifecycleEvent | None = None) -> tuple[tuple[str, str], ...]:
        return _shell_tool_frame_phases(self, tool_id, tool_event=tool_event)

    def _tool_event_lines(self, tool_event: ToolLifecycleEvent | None) -> tuple[str | None, str | None]:
        return _shell_tool_event_lines(self, tool_event)

    def _tool_event_summary(self, tool_event: ToolLifecycleEvent | None) -> str | None:
        return _shell_tool_event_summary(self, tool_event)

    def _tool_trace_line(self, tool_event: ToolLifecycleEvent | None) -> str | None:
        return _shell_tool_trace_line(self, tool_event)

    def _render_pending_entries(self) -> None:
        _render_shell_pending_entries(self)

    def _render_entry(self, entry: TranscriptEntry):
        return _render_shell_entry(self, entry)

    def _growth_panel_lines(self, session, continuity, provider, growth) -> tuple[str, ...]:
        return _shell_growth_panel_lines(self, session, continuity, provider, growth)

    def _recent_activity_lines(self, session, continuity, provider) -> tuple[str, ...]:
        return _shell_recent_activity_lines(self, session, continuity, provider)

    def _recent_experience_lines(self, experiences: tuple[ExperienceRecord, ...]) -> tuple[str, ...]:
        return _shell_recent_experience_lines(experiences)

    def _displayable_experiences(self, experiences: tuple[ExperienceRecord, ...]) -> tuple[ExperienceRecord, ...]:
        return _displayable_shell_experiences(experiences)

    def _should_display_experience(self, experience: ExperienceRecord) -> bool:
        return _should_display_shell_experience(experience)

    def _format_experience_status(self, experience: ExperienceRecord) -> str:
        return _format_shell_experience_status(experience)

    def _growth_progress_counts(self, growth, *, width: int = GROWTH_PROGRESS_WIDTH) -> tuple[int, int]:
        return _shell_growth_progress_counts(growth, width=width)

    def _growth_progress_bar(self, growth, *, width: int = GROWTH_PROGRESS_WIDTH) -> str:
        return _shell_growth_progress_bar(growth, width=width)

    def _styled_growth_progress_bar(self, growth, *, width: int = GROWTH_PROGRESS_WIDTH):
        return _styled_shell_growth_progress_bar(growth, width=width)

    def _render_chat_entry(self, entry: TranscriptEntry, *, accent: str):
        return _render_shell_chat_entry(self, entry, accent=accent)

    def _history_row_width(self) -> int:
        return max(24, len(self._composer_divider()))

    def _queue_preview_row_width(self) -> int:
        return max(16, self._history_row_width() - (QUEUE_PREVIEW_INSET * 2))

    def _pad_history_line(self, content: str) -> str:
        display_width = _display_width(content)
        width = self._history_row_width()
        if display_width >= width:
            return content
        return content + (" " * (width - display_width))

    def _pad_queue_preview_line(self, content: str) -> str:
        display_width = _display_width(content)
        width = self._queue_preview_row_width()
        if display_width >= width:
            return content
        return content + (" " * (width - display_width))

    def _center_brand_block(self, renderable):
        return _center_shell_brand_block(renderable)

    def _render_growth_mark(self, stage_id: str, *, level: int | None = None):
        return _render_shell_growth_mark(stage_id, level=level)

    def _render_guardian_mark(self):
        return _render_shell_guardian_mark()
