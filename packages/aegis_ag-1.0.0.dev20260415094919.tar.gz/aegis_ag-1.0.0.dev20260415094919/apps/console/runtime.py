"""Thin operator console wired to the API surface.

The console renders inspection and mutation views for canonical identity, user,
relationship, continuity, goals, memories, providers, and policy. It does not
own runtime policy or kernel behavior; it only presents the public API surface
that already landed in `apps/api`.
"""

from __future__ import annotations

from dataclasses import dataclass
from html import escape
from pathlib import Path
from typing import Any, Mapping
from urllib.parse import parse_qs
import json

from apps.api.runtime import AegisAPIApp, create_app as create_api_app
from packages.contracts import ExecutionResult


def _text(value: Any) -> str:
    if value is None:
        return ""
    if isinstance(value, tuple):
        return ", ".join(_text(item) for item in value)
    if isinstance(value, list):
        return ", ".join(_text(item) for item in value)
    if isinstance(value, Mapping):
        return json.dumps(value, indent=2, sort_keys=True)
    return str(value)


def _lines(value: Any) -> str:
    return escape(_text(value)).replace("\n", "<br>")


def _page(title: str, body: str) -> bytes:
    html = f"""<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>{escape(title)}</title>
    <style>
      :root {{
        color-scheme: dark;
        --bg: #0b1020;
        --panel: #121a33;
        --panel-alt: #0f1730;
        --line: rgba(255,255,255,0.12);
        --text: #e8ecff;
        --muted: #9aa7d1;
        --accent: #9bd4ff;
        --accent-2: #82ffd0;
      }}
      * {{ box-sizing: border-box; }}
      body {{
        margin: 0;
        font-family: Inter, ui-sans-serif, system-ui, -apple-system, BlinkMacSystemFont, sans-serif;
        background:
          radial-gradient(circle at top left, rgba(155, 212, 255, 0.16), transparent 28%),
          radial-gradient(circle at top right, rgba(130, 255, 208, 0.12), transparent 24%),
          var(--bg);
        color: var(--text);
      }}
      main {{
        max-width: 1180px;
        margin: 0 auto;
        padding: 40px 24px 64px;
      }}
      header {{
        display: flex;
        justify-content: space-between;
        gap: 24px;
        align-items: end;
        margin-bottom: 28px;
      }}
      h1, h2, h3, p {{ margin: 0; }}
      h1 {{
        font-size: 38px;
        line-height: 1.05;
        letter-spacing: -0.03em;
      }}
      .subtle {{ color: var(--muted); max-width: 760px; line-height: 1.6; }}
      .grid {{
        display: grid;
        grid-template-columns: repeat(12, minmax(0, 1fr));
        gap: 16px;
      }}
      .card {{
        background: linear-gradient(180deg, rgba(255,255,255,0.04), transparent), var(--panel);
        border: 1px solid var(--line);
        border-radius: 18px;
        padding: 18px;
        box-shadow: 0 24px 72px rgba(0,0,0,0.22);
      }}
      .card.alt {{ background: var(--panel-alt); }}
      .span-12 {{ grid-column: span 12; }}
      .span-8 {{ grid-column: span 8; }}
      .span-6 {{ grid-column: span 6; }}
      .span-4 {{ grid-column: span 4; }}
      .span-3 {{ grid-column: span 3; }}
      .span-2 {{ grid-column: span 2; }}
      .eyebrow {{
        color: var(--accent);
        text-transform: uppercase;
        letter-spacing: 0.18em;
        font-size: 11px;
        margin-bottom: 10px;
      }}
      .meta {{
        color: var(--muted);
        font-size: 13px;
        line-height: 1.45;
      }}
      .row {{
        display: flex;
        flex-wrap: wrap;
        gap: 12px;
        margin-top: 10px;
      }}
      .pill {{
        display: inline-flex;
        align-items: center;
        gap: 6px;
        padding: 7px 10px;
        border-radius: 999px;
        background: rgba(255,255,255,0.06);
        color: var(--text);
        border: 1px solid var(--line);
        font-size: 12px;
      }}
      .pill strong {{ color: var(--accent-2); }}
      pre {{
        white-space: pre-wrap;
        margin: 0;
        color: var(--text);
        line-height: 1.5;
        font-size: 13px;
      }}
      a {{ color: var(--accent); text-decoration: none; }}
      a:hover {{ text-decoration: underline; }}
      .section-title {{
        display: flex;
        justify-content: space-between;
        align-items: center;
        gap: 12px;
        margin-bottom: 12px;
      }}
      .list {{
        display: grid;
        gap: 12px;
      }}
      .item {{
        border: 1px solid var(--line);
        background: rgba(255,255,255,0.03);
        border-radius: 14px;
        padding: 14px;
      }}
      .item h3 {{ font-size: 16px; margin-bottom: 6px; }}
      .kv {{
        display: grid;
        gap: 6px;
        font-size: 13px;
      }}
      .kv div {{
        display: flex;
        gap: 10px;
        align-items: baseline;
      }}
      .kv dt {{
        min-width: 140px;
        color: var(--muted);
      }}
      .kv dd {{
        margin: 0;
        color: var(--text);
      }}
      .nav {{
        display: flex;
        flex-wrap: wrap;
        gap: 10px;
      }}
      @media (max-width: 900px) {{
        .span-8, .span-6, .span-4, .span-3, .span-2 {{ grid-column: span 12; }}
        header {{ flex-direction: column; align-items: start; }}
      }}
    </style>
  </head>
  <body>
    <main>
      {body}
    </main>
  </body>
</html>"""
    return html.encode("utf-8")


def _json_response(payload: Mapping[str, Any]) -> bytes:
    return json.dumps(payload, indent=2, sort_keys=True).encode("utf-8")


def _form_data(body: bytes | None) -> dict[str, str]:
    if not body:
        return {}
    parsed = parse_qs(body.decode("utf-8"), keep_blank_values=True)
    return {key: values[0] if values else "" for key, values in parsed.items()}


@dataclass(frozen=True, slots=True)
class ConsoleAppConfig:
    database_path: Path
    instruction_refs: tuple[str, ...] = ("apps/api",)
    total_tokens: int = 2048


class AegisConsoleApp:
    def __init__(self, config: ConsoleAppConfig) -> None:
        self.config = config
        self.api = create_api_app(
            database_path=config.database_path,
            instruction_refs=config.instruction_refs,
            total_tokens=config.total_tokens,
        )

    def _session_summary(self, session_id: str) -> Mapping[str, Any]:
        inspection = self.api.inspect_session(session_id)
        latest_turn = inspection.latest_turn
        outcome = latest_turn.outcome if latest_turn is not None else None
        goals = inspection.goals
        memories = inspection.memories
        providers = tuple(
            (
                descriptor.capability_id,
                descriptor.kind,
                descriptor.version,
                descriptor.metadata,
            )
            for descriptor in (
                self.api.model_provider.descriptor,
                self.api.planning.descriptor,
                self.api.context.descriptor,
                self.api.memory.descriptor,
                self.api.tools.descriptor,
                self.api.delivery.descriptor,
                self.api.telemetry.descriptor,
            )
        )
        policy = {
            "profile_mode": inspection.profile.mode,
            "session_status": inspection.session.status,
            "interruption_state": inspection.session.interruption_state,
            "enabled_capabilities": inspection.profile.enabled_capabilities,
            "tool_catalog": [
                {
                    "tool_id": tool.tool_id,
                    "display_name": tool.display_name,
                    "version": tool.version,
                    "risk_class": tool.side_effects.risk_class,
                    "approval_class": tool.side_effects.approval_class,
                    "writes_state": tool.side_effects.writes_state,
                    "reads_state": tool.side_effects.reads_state,
                    "touches_network": tool.side_effects.touches_network,
                    "touches_secrets": tool.side_effects.touches_secrets,
                }
                for tool in self.api.tool_runtime.list_tools()
            ],
        }
        return {
            "inspection": inspection,
            "outcome": outcome,
            "goals": goals,
            "memories": memories,
            "providers": providers,
            "policy": policy,
        }

    def _landing(self) -> bytes:
        body = """
        <header>
          <div>
            <div class="eyebrow">Operator console</div>
            <h1>Aegis control surface</h1>
          </div>
          <div class="meta">Thin operator surface over the programmatic API.</div>
        </header>
        <section class="grid">
          <article class="card span-8">
            <div class="section-title">
              <h2>Inspect and mutate state</h2>
              <span class="meta">Sessions, goals, memories, providers, policy</span>
            </div>
            <p class="subtle">Open a session route to inspect durable goals and memories, then use the detail pages to edit a goal or correct or delete a memory. The console stays thin and renders the API payloads that already exist.</p>
            <div class="row" style="margin-top:16px;">
              <span class="pill"><strong>/sessions/{session_id}</strong> overview</span>
              <span class="pill"><strong>/sessions/{session_id}/goals</strong> goals</span>
              <span class="pill"><strong>/sessions/{session_id}/memories</strong> memories</span>
              <span class="pill"><strong>/sessions/{session_id}/goals/&lt;id&gt;</strong> goal detail</span>
              <span class="pill"><strong>/sessions/{session_id}/memories/&lt;id&gt;</strong> memory detail</span>
              <span class="pill"><strong>/sessions/{session_id}/providers</strong> providers</span>
              <span class="pill"><strong>/sessions/{session_id}/policy</strong> policy</span>
            </div>
          </article>
          <article class="card span-4 alt">
            <div class="eyebrow">Contract</div>
            <pre>API-backed
thin console
durable state
operator focused</pre>
          </article>
        </section>
        """
        return _page("Aegis Console", body)

    def _goals_page(self, session_id: str) -> bytes:
        summary = self._session_summary(session_id)
        inspection = summary["inspection"]
        goals = summary["goals"]
        body = f"""
        <header>
          <div>
            <div class="eyebrow">Goals</div>
            <h1>{escape(session_id)}</h1>
          </div>
          <div class="meta">Durable goal graph · revision {escape(str(inspection.goal_graph_revision or "none"))}</div>
        </header>
        <section class="grid">
          <article class="card span-12 alt">
            <div class="section-title"><h2>Create goal</h2><span class="meta">Durable goal mutation</span></div>
            <form method="post" action="/sessions/{escape(session_id)}/goals">
              <div class="kv">
                <div><dt>Title</dt><dd><input name="title" value="" style="width:100%"></dd></div>
                <div><dt>Status</dt><dd><input name="status" value="active" style="width:100%"></dd></div>
                <div><dt>Priority</dt><dd><input name="priority" value="medium" style="width:100%"></dd></div>
              </div>
              <button type="submit">Create durable goal</button>
            </form>
          </article>
          <article class="card span-12">
            <div class="section-title"><h2>Goal inventory</h2><span class="meta">{len(goals)} records</span></div>
            <div class="list">
              {''.join(
                f'<div class="item"><h3><a href="/sessions/{escape(session_id)}/goals/{escape(goal.goal_id)}">{escape(goal.title)}</a></h3><div class="meta">ID {escape(goal.goal_id)} · {escape(goal.status)} · priority {escape(goal.priority)}</div><div class="meta">Dependencies: {escape(_text(goal.dependencies) or "none")}</div><div class="meta">Evidence: {escape(_text(goal.evidence_refs) or "none")}</div></div>'
                for goal in goals
              ) or '<div class="item"><div class="meta">No durable goals have been recorded yet.</div></div>'}
            </div>
          </article>
        </section>
        """
        return _page(f"Aegis Console · Goals · {session_id}", body)

    def _memories_page(self, session_id: str) -> bytes:
        summary = self._session_summary(session_id)
        inspection = summary["inspection"]
        memories = summary["memories"]
        body = f"""
        <header>
          <div>
            <div class="eyebrow">Memories</div>
            <h1>{escape(session_id)}</h1>
          </div>
          <div class="meta">Durable memory inventory · {inspection.memory_count} active records</div>
        </header>
        <section class="grid">
          <article class="card span-12">
            <div class="section-title"><h2>Memory inventory</h2><span class="meta">{len(memories)} records</span></div>
            <div class="list">
              {''.join(
                f'<div class="item"><h3><a href="/sessions/{escape(session_id)}/memories/{escape(memory.memory_id)}">{escape(memory.kind)}</a></h3><div class="meta">ID {escape(memory.memory_id)} · state {escape(str(self.api.inspect_memory(session_id, memory.memory_id)["memory_state"] or "active"))}</div><pre>{escape(memory.content)}</pre></div>'
                for memory in memories
              ) or '<div class="item"><div class="meta">No durable memories have been recorded yet.</div></div>'}
            </div>
          </article>
        </section>
        """
        return _page(f"Aegis Console · Memories · {session_id}", body)

    def _identity_page(self, session_id: str, notice: str | None = None) -> bytes:
        summary = self._session_summary(session_id)
        inspection = summary["inspection"]
        identity = self.api.inspect_identity(session_id=session_id)
        body = f"""
        <header>
          <div>
            <div class="eyebrow">Identity</div>
            <h1>{escape(identity.display_name)}</h1>
          </div>
          <div class="meta">Canonical clone self-state · profile {escape(inspection.profile.profile_id)}</div>
        </header>
        <section class="grid">
          <article class="card span-6">
            <div class="section-title"><h2>Identity detail</h2><span class="meta">Single owner of clone self-state</span></div>
            <div class="kv">
              <div><dt>Profile ID</dt><dd>{escape(identity.profile_id)}</dd></div>
              <div><dt>Clone ID</dt><dd>{escape(identity.clone_id)}</dd></div>
              <div><dt>Display name</dt><dd>{escape(identity.display_name)}</dd></div>
              <div><dt>Identity mode</dt><dd>{escape(identity.identity_mode)}</dd></div>
              <div><dt>Personality preset</dt><dd>{escape(identity.personality_preset)}</dd></div>
              <div><dt>Initiative</dt><dd>{escape(identity.initiative)}</dd></div>
              <div><dt>Relational stance</dt><dd>{escape(identity.relational_stance)}</dd></div>
              <div><dt>Voice contract</dt><dd>{escape(identity.voice_contract)}</dd></div>
            </div>
            <pre style="margin-top:12px;">{escape(identity.charter_extension or "")}</pre>
            {f'<p class="subtle" style="margin-top:12px;">{escape(notice)}</p>' if notice else ''}
          </article>
          <article class="card span-6">
            <div class="section-title"><h2>Edit identity</h2><span class="meta">Writes through the API state surface</span></div>
            <form method="post" action="/sessions/{escape(session_id)}/identity">
              <div class="kv">
                <div><dt>Display name</dt><dd><input name="display_name" value="{escape(identity.display_name)}" style="width:100%"></dd></div>
                <div><dt>Preset</dt><dd><input name="personality_preset" value="{escape(identity.personality_preset)}" style="width:100%"></dd></div>
                <div><dt>Initiative</dt><dd><input name="initiative" value="{escape(identity.initiative)}" style="width:100%"></dd></div>
                <div><dt>Charter</dt><dd><textarea name="charter_text" rows="8" style="width:100%">{escape(identity.charter_extension or "")}</textarea></dd></div>
              </div>
              <button type="submit">Save identity</button>
            </form>
            <form method="post" action="/sessions/{escape(session_id)}/identity" style="margin-top:12px;">
              <input type="hidden" name="action" value="clear_charter">
              <button type="submit">Clear charter extension</button>
            </form>
          </article>
        </section>
        """
        return _page(f"Aegis Console · Identity · {session_id}", body)

    def _user_page(self, session_id: str, notice: str | None = None) -> bytes:
        summary = self._session_summary(session_id)
        inspection = summary["inspection"]
        user = self.api.inspect_user(session_id=session_id)
        body = f"""
        <header>
          <div>
            <div class="eyebrow">User</div>
            <h1>{escape(user.preferred_name or inspection.profile.display_name)}</h1>
          </div>
          <div class="meta">Canonical shared user truth · session {escape(session_id)}</div>
        </header>
        <section class="grid">
          <article class="card span-6">
            <div class="section-title"><h2>User detail</h2><span class="meta">Stable shared facts and preferences</span></div>
            <div class="kv">
              <div><dt>Profile ID</dt><dd>{escape(user.profile_id)}</dd></div>
              <div><dt>User card ID</dt><dd>{escape(user.user_card_id)}</dd></div>
              <div><dt>Preferred name</dt><dd>{escape(user.preferred_name or "<empty>")}</dd></div>
              <div><dt>Locale</dt><dd>{escape(user.locale or "<empty>")}</dd></div>
              <div><dt>Timezone</dt><dd>{escape(user.timezone or "<empty>")}</dd></div>
              <div><dt>Communication</dt><dd>{escape(_text(user.communication_preferences) or "<empty>")}</dd></div>
              <div><dt>Boundaries</dt><dd>{escape(_text(user.boundaries) or "<empty>")}</dd></div>
              <div><dt>Biography</dt><dd>{escape(_text(user.biography_fragments) or "<empty>")}</dd></div>
              <div><dt>Shared preferences</dt><dd>{escape(_text(user.shared_preferences) or "<empty>")}</dd></div>
            </div>
            {f'<p class="subtle" style="margin-top:12px;">{escape(notice)}</p>' if notice else ''}
          </article>
          <article class="card span-6">
            <div class="section-title"><h2>Update user truth</h2><span class="meta">Text set, append, or clear</span></div>
            <form method="post" action="/sessions/{escape(session_id)}/user">
              <div class="kv">
                <div><dt>Mutation</dt><dd><select name="mutation" style="width:100%"><option value="set">set</option><option value="append">append</option><option value="clear">clear</option></select></dd></div>
                <div><dt>Text</dt><dd><textarea name="text" rows="10" style="width:100%"></textarea></dd></div>
              </div>
              <button type="submit">Apply user update</button>
            </form>
          </article>
        </section>
        """
        return _page(f"Aegis Console · User · {session_id}", body)

    def _relationship_page(self, session_id: str, notice: str | None = None) -> bytes:
        relationship = self.api.inspect_relationship(session_id=session_id)
        body = f"""
        <header>
          <div>
            <div class="eyebrow">Relationship</div>
            <h1>{escape(session_id)}</h1>
          </div>
          <div class="meta">Canonical clone-local relationship continuity</div>
        </header>
        <section class="grid">
          <article class="card span-6">
            <div class="section-title"><h2>Relationship detail</h2><span class="meta">Expectations and continuity notes</span></div>
            <div class="kv">
              <div><dt>Profile ID</dt><dd>{escape(relationship.profile_id)}</dd></div>
              <div><dt>Relationship ID</dt><dd>{escape(relationship.relationship_id)}</dd></div>
              <div><dt>Clone ID</dt><dd>{escape(relationship.clone_id)}</dd></div>
              <div><dt>User card ID</dt><dd>{escape(relationship.user_card_id or "<empty>")}</dd></div>
              <div><dt>Interaction preferences</dt><dd>{escape(_text(relationship.interaction_preferences) or "<empty>")}</dd></div>
              <div><dt>Expectations</dt><dd>{escape(_text(relationship.expectations) or "<empty>")}</dd></div>
              <div><dt>Continuity notes</dt><dd>{escape(_text(relationship.continuity_notes) or "<empty>")}</dd></div>
            </div>
            {f'<p class="subtle" style="margin-top:12px;">{escape(notice)}</p>' if notice else ''}
          </article>
          <article class="card span-6">
            <div class="section-title"><h2>Update relationship</h2><span class="meta">Set, append, or clear continuity notes</span></div>
            <form method="post" action="/sessions/{escape(session_id)}/relationship">
              <div class="kv">
                <div><dt>Mutation</dt><dd><select name="mutation" style="width:100%"><option value="set">set</option><option value="append">append</option><option value="clear">clear</option></select></dd></div>
                <div><dt>Text</dt><dd><textarea name="text" rows="10" style="width:100%"></textarea></dd></div>
              </div>
              <button type="submit">Apply relationship update</button>
            </form>
          </article>
        </section>
        """
        return _page(f"Aegis Console · Relationship · {session_id}", body)

    def _continuity_page(self, session_id: str) -> bytes:
        report = self.api.inspect_continuity(session_id)
        continuity = report.continuity
        body = f"""
        <header>
          <div>
            <div class="eyebrow">Continuity</div>
            <h1>{escape(session_id)}</h1>
          </div>
          <div class="meta">Projection over canonical identity, user, relationship, goals, and session lineage</div>
        </header>
        <section class="grid">
          <article class="card span-6">
            <div class="section-title"><h2>Wake bundle</h2><span class="meta">Why now</span></div>
            <div class="kv">
              <div><dt>Active goal</dt><dd>{escape(str(report.active_goal_id or "none"))}</dd></div>
              <div><dt>Wake action</dt><dd>{escape(report.wake_action)}</dd></div>
              <div><dt>Wake factors</dt><dd>{escape(_text(report.wake_factors) or "<empty>")}</dd></div>
            </div>
            <pre style="margin-top:12px;">{escape(report.wake_summary)}</pre>
          </article>
          <article class="card span-6">
            <div class="section-title"><h2>Continuity projection</h2><span class="meta">Current read model</span></div>
            <div class="kv">
              <div><dt>Summary</dt><dd>{escape(continuity.summary)}</dd></div>
              <div><dt>Initiative</dt><dd>{escape(continuity.initiative)}</dd></div>
              <div><dt>Reengagement style</dt><dd>{escape(continuity.reengagement_style)}</dd></div>
              <div><dt>User governed</dt><dd>{escape(str(continuity.user_governed))}</dd></div>
              <div><dt>Voice binding</dt><dd>{escape(continuity.voice_identity_binding)}</dd></div>
            </div>
            <pre style="margin-top:12px;">{escape(continuity.reengagement_prompt)}</pre>
          </article>
          <article class="card span-12">
            <div class="section-title"><h2>Canonical records in play</h2><span class="meta">Projection inputs</span></div>
            <div class="grid">
              <div class="card span-4 alt"><div class="eyebrow">Identity</div><pre>{escape(_text(report.identity))}</pre></div>
              <div class="card span-4 alt"><div class="eyebrow">User</div><pre>{escape(_text(report.user))}</pre></div>
              <div class="card span-4 alt"><div class="eyebrow">Relationship</div><pre>{escape(_text(report.relationship))}</pre></div>
            </div>
          </article>
        </section>
        """
        return _page(f"Aegis Console · Continuity · {session_id}", body)

    def _goal_page(self, session_id: str, goal_id: str, notice: str | None = None) -> bytes:
        summary = self._session_summary(session_id)
        inspection = summary["inspection"]
        goal_info = self.api.inspect_goal(session_id, goal_id)
        goal = goal_info["goal"]
        body = f"""
        <header>
          <div>
            <div class="eyebrow">Goal</div>
            <h1>{escape(goal.title)}</h1>
          </div>
          <div class="meta">Session {escape(session_id)} · revision {escape(str(goal_info["goal_graph_revision"] or "none"))}</div>
        </header>
        <section class="grid">
          <article class="card span-6">
            <div class="section-title"><h2>Goal detail</h2><span class="meta">Durable record</span></div>
            <div class="kv">
              <div><dt>Goal ID</dt><dd>{escape(goal.goal_id)}</dd></div>
              <div><dt>Status</dt><dd>{escape(goal.status)}</dd></div>
              <div><dt>Priority</dt><dd>{escape(goal.priority)}</dd></div>
              <div><dt>Owner</dt><dd>{escape(str(goal.owner or "none"))}</dd></div>
              <div><dt>Dependencies</dt><dd>{escape(_text(goal.dependencies) or "none")}</dd></div>
              <div><dt>Evidence</dt><dd>{escape(_text(goal.evidence_refs) or "none")}</dd></div>
              <div><dt>Goal graph</dt><dd>{escape(str(goal_info["goal_graph_revision"] or "none"))}</dd></div>
            </div>
            {f'<p class="subtle" style="margin-top:12px;">{escape(notice)}</p>' if notice else ''}
          </article>
          <article class="card span-6">
            <div class="section-title"><h2>Edit goal</h2><span class="meta">Aligned state mutation</span></div>
            <form method="post" action="/sessions/{escape(session_id)}/goals/{escape(goal_id)}">
              <input type="hidden" name="action" value="edit">
              <div class="kv">
                <div><dt>Title</dt><dd><input name="title" value="{escape(goal.title)}" style="width:100%"></dd></div>
                <div><dt>Status</dt><dd><input name="status" value="{escape(goal.status)}" style="width:100%"></dd></div>
                <div><dt>Priority</dt><dd><input name="priority" value="{escape(goal.priority)}" style="width:100%"></dd></div>
              </div>
              <button type="submit">Save goal</button>
            </form>
            <form method="post" action="/sessions/{escape(session_id)}/goals/{escape(goal_id)}" style="margin-top:12px;">
              <input type="hidden" name="action" value="delete">
              <div class="kv">
                <div><dt>Reason</dt><dd><input name="reason" value="operator deleted goal" style="width:100%"></dd></div>
              </div>
              <button type="submit">Delete goal</button>
            </form>
          </article>
          <article class="card span-12">
            <div class="section-title"><h2>Session context</h2><span class="meta">{inspection.goal_graph_revision or "no graph"}</span></div>
            <div class="row">
              <span class="pill"><strong>{inspection.session.status}</strong> session</span>
              <span class="pill"><strong>{len(summary["goals"])}</strong> goals</span>
              <span class="pill"><strong>{inspection.memory_count}</strong> memories</span>
            </div>
          </article>
        </section>
        """
        return _page(f"Aegis Console · Goal · {goal_id}", body)

    def _memory_page(self, session_id: str, memory_id: str, notice: str | None = None) -> bytes:
        summary = self._session_summary(session_id)
        inspection = summary["inspection"]
        memory_info = self.api.inspect_memory(session_id, memory_id)
        memory = memory_info["memory"]
        body = f"""
        <header>
          <div>
            <div class="eyebrow">Memory</div>
            <h1>{escape(memory.kind)}</h1>
          </div>
          <div class="meta">Session {escape(session_id)} · state {escape(str(memory_info["memory_state"] or "active"))}</div>
        </header>
        <section class="grid">
          <article class="card span-6">
            <div class="section-title"><h2>Memory detail</h2><span class="meta">Durable record</span></div>
            <div class="kv">
              <div><dt>Memory ID</dt><dd>{escape(memory.memory_id)}</dd></div>
              <div><dt>Kind</dt><dd>{escape(memory.kind)}</dd></div>
              <div><dt>State</dt><dd>{escape(str(memory_info["memory_state"] or "active"))}</dd></div>
              <div><dt>Lineage</dt><dd>{escape(str(memory_info["memory_lineage"] or "none"))}</dd></div>
              <div><dt>Replacement</dt><dd>{escape(str(memory_info["memory_lineage"] or "none"))}</dd></div>
              <div><dt>Goal refs</dt><dd>{escape(_text(memory.goal_refs) or "none")}</dd></div>
            </div>
            <pre style="margin-top:12px;">{escape(memory.content)}</pre>
            {f'<p class="subtle" style="margin-top:12px;">{escape(notice)}</p>' if notice else ''}
          </article>
          <article class="card span-6">
            <div class="section-title"><h2>Correct memory</h2><span class="meta">Aligned state mutation</span></div>
            <form method="post" action="/sessions/{escape(session_id)}/memories/{escape(memory_id)}">
              <input type="hidden" name="action" value="correct">
              <div class="kv">
                <div><dt>Content</dt><dd><textarea name="corrected_content" rows="6" style="width:100%">{escape(memory.content)}</textarea></dd></div>
                <div><dt>Reason</dt><dd><input name="reason" value="operator corrected memory" style="width:100%"></dd></div>
              </div>
              <button type="submit">Save correction</button>
            </form>
            <form method="post" action="/sessions/{escape(session_id)}/memories/{escape(memory_id)}" style="margin-top:12px;">
              <input type="hidden" name="action" value="delete">
              <div class="kv">
                <div><dt>Reason</dt><dd><input name="reason" value="operator deleted memory" style="width:100%"></dd></div>
              </div>
              <button type="submit">Delete memory</button>
            </form>
          </article>
          <article class="card span-12">
            <div class="section-title"><h2>Session context</h2><span class="meta">{inspection.goal_graph_revision or "no graph"}</span></div>
            <div class="row">
              <span class="pill"><strong>{inspection.session.status}</strong> session</span>
              <span class="pill"><strong>{len(summary["goals"])}</strong> goals</span>
              <span class="pill"><strong>{inspection.memory_count}</strong> active memories</span>
            </div>
          </article>
        </section>
        """
        return _page(f"Aegis Console · Memory · {memory_id}", body)

    def _session_page(self, session_id: str, view: str) -> bytes:
        summary = self._session_summary(session_id)
        inspection = summary["inspection"]
        outcome = summary["outcome"]
        goals = summary["goals"]
        memories = summary["memories"]
        providers = summary["providers"]
        policy = summary["policy"]
        latest_turn = inspection.latest_turn
        stage_lines = ""
        if outcome is not None:
            stage_lines = "".join(
                f"<li><strong>{escape(stage.stage)}</strong>: {escape(stage.detail)}</li>"
                for stage in outcome.stages
            )
        else:
            stage_lines = "<li>No turn has been executed yet.</li>"
        session_body = f"""
        <header>
          <div>
            <div class="eyebrow">Session</div>
            <h1>{escape(session_id)}</h1>
          </div>
          <div class="meta">Profile {escape(inspection.profile.profile_id)} · {escape(inspection.session.status)}</div>
        </header>
        <section class="grid">
          <article class="card span-6">
            <div class="section-title"><h2>Session view</h2><span class="meta">Lifecycle and lineage</span></div>
            <div class="kv">
              <div><dt>Display name</dt><dd>{escape(inspection.profile.display_name)}</dd></div>
              <div><dt>Mode</dt><dd>{escape(inspection.profile.mode)}</dd></div>
              <div><dt>Workspace</dt><dd>{escape(str(inspection.session.workspace_id or "none"))}</dd></div>
              <div><dt>Parent session</dt><dd>{escape(str(inspection.session.parent_session_id or "none"))}</dd></div>
              <div><dt>Lineage depth</dt><dd>{len(inspection.lineage)}</dd></div>
              <div><dt>Telemetry events</dt><dd>{inspection.telemetry_count}</dd></div>
              <div><dt>Memory records</dt><dd>{inspection.memory_count}</dd></div>
            </div>
          </article>
          <article class="card span-6">
            <div class="section-title"><h2>Why the next move was chosen</h2><span class="meta">Kernel rationale</span></div>
            <pre>{escape(outcome.plan.rationale if outcome and outcome.plan else "No plan has been generated yet.")}</pre>
          </article>
          <article class="card span-12">
            <div class="section-title"><h2>Turn detail</h2><span class="meta">Latest API-backed execution</span></div>
            <div class="grid">
              <div class="card span-4 alt">
                <div class="eyebrow">Request</div>
                <pre>{_lines(latest_turn.request if latest_turn else {})}</pre>
              </div>
              <div class="card span-4 alt">
                <div class="eyebrow">Execution</div>
                <pre>{escape(outcome.execution.summary if outcome is not None else "No execution yet.")}</pre>
              </div>
              <div class="card span-4 alt">
                <div class="eyebrow">Stages</div>
                <ul class="meta">{stage_lines}</ul>
              </div>
            </div>
          </article>
        </section>
        <section class="grid" style="margin-top:16px;">
          <article class="card span-6">
            <div class="section-title"><h2>Goals</h2><span class="meta">{len(goals)} active nodes</span></div>
            <div class="list">
              {''.join(
                f'<div class="item"><h3><a href="/sessions/{escape(session_id)}/goals/{escape(goal.goal_id)}">{escape(goal.title)}</a></h3><div class="meta">ID {escape(goal.goal_id)} · {escape(goal.status)} · priority {escape(goal.priority)}</div><div class="meta">Dependencies: {escape(_text(goal.dependencies) or "none")}</div><div class="meta">Evidence: {escape(_text(goal.evidence_refs) or "none")}</div></div>'
                for goal in goals
              ) or '<div class="item"><div class="meta">No goals returned for this session.</div></div>'}
            </div>
          </article>
          <article class="card span-6">
            <div class="section-title"><h2>Memories</h2><span class="meta">{len(memories)} records</span></div>
            <div class="list">
              {''.join(
                f'<div class="item"><h3><a href="/sessions/{escape(session_id)}/memories/{escape(memory.memory_id)}">{escape(memory.kind)}</a></h3><div class="meta">ID {escape(memory.memory_id)} · source {escape(str(memory.source_event_id or "none"))}</div><pre>{escape(memory.content)}</pre></div>'
                for memory in memories
              ) or '<div class="item"><div class="meta">No memories returned for this session.</div></div>'}
            </div>
          </article>
        </section>
        <section class="grid" style="margin-top:16px;">
          <article class="card span-6">
            <div class="section-title"><h2>Providers</h2><span class="meta">API descriptors</span></div>
            <div class="list">
              {''.join(
                f'<div class="item"><h3>{escape(capability_id)}</h3><div class="meta">{escape(kind)} · v{escape(version)}</div><pre>{escape(json.dumps(metadata, indent=2, sort_keys=True))}</pre></div>'
                for capability_id, kind, version, metadata in providers
              )}
            </div>
          </article>
          <article class="card span-6">
            <div class="section-title"><h2>Policy</h2><span class="meta">Runtime controls</span></div>
            <div class="kv">
              <div><dt>Profile mode</dt><dd>{escape(policy["profile_mode"])}</dd></div>
              <div><dt>Session status</dt><dd>{escape(policy["session_status"])}</dd></div>
              <div><dt>Interruption state</dt><dd>{escape(str(policy["interruption_state"] or "none"))}</dd></div>
              <div><dt>Enabled capabilities</dt><dd>{escape(_text(policy["enabled_capabilities"]) or "none")}</dd></div>
              <div><dt>Tool catalog</dt><dd>{escape(json.dumps(policy["tool_catalog"], indent=2, sort_keys=True))}</dd></div>
            </div>
          </article>
        </section>
        <section class="card" style="margin-top:16px;">
          <div class="nav">
            <a href="/sessions/{escape(session_id)}">overview</a>
            <a href="/sessions/{escape(session_id)}/identity">identity</a>
            <a href="/sessions/{escape(session_id)}/user">user</a>
            <a href="/sessions/{escape(session_id)}/relationship">relationship</a>
            <a href="/sessions/{escape(session_id)}/continuity">continuity</a>
            <a href="/sessions/{escape(session_id)}/goals">goals</a>
            <a href="/sessions/{escape(session_id)}/memories">memories</a>
            <a href="/sessions/{escape(session_id)}/providers">providers</a>
            <a href="/sessions/{escape(session_id)}/policy">policy</a>
          </div>
        </section>
        """
        if view == "identity":
            body = self._identity_page(session_id).decode("utf-8")
        elif view == "user":
            body = self._user_page(session_id).decode("utf-8")
        elif view == "relationship":
            body = self._relationship_page(session_id).decode("utf-8")
        elif view == "continuity":
            body = self._continuity_page(session_id).decode("utf-8")
        elif view == "goals":
            body = self._goals_page(session_id).decode("utf-8")
        elif view == "memories":
            body = self._memories_page(session_id).decode("utf-8")
        elif view == "providers":
            body = f"<header><div><div class='eyebrow'>Providers</div><h1>{escape(session_id)}</h1></div><div class='meta'>Programmatic capability descriptors</div></header><section class='grid'><article class='card span-12'><div class='list'>{''.join(f'<div class=\"item\"><h3>{escape(capability_id)}</h3><div class=\"meta\">{escape(kind)} · v{escape(version)}</div><pre>{escape(json.dumps(metadata, indent=2, sort_keys=True))}</pre></div>' for capability_id, kind, version, metadata in providers)}</div></article></section>"
        elif view == "policy":
            body = f"<header><div><div class='eyebrow'>Policy</div><h1>{escape(session_id)}</h1></div><div class='meta'>Session and tool governance</div></header><section class='grid'><article class='card span-12'><div class='kv'><div><dt>Profile mode</dt><dd>{escape(policy['profile_mode'])}</dd></div><div><dt>Session status</dt><dd>{escape(policy['session_status'])}</dd></div><div><dt>Interruption state</dt><dd>{escape(str(policy['interruption_state'] or 'none'))}</dd></div><div><dt>Enabled capabilities</dt><dd>{escape(_text(policy['enabled_capabilities']) or 'none')}</dd></div><div><dt>Tool catalog</dt><dd>{escape(json.dumps(policy['tool_catalog'], indent=2, sort_keys=True))}</dd></div></div></article></section>"
        else:
            body = session_body
        return _page(f"Aegis Console · {session_id}", body)

    def dispatch(self, method: str, path: str, body: bytes | None = None) -> tuple[int, Mapping[str, Any] | bytes, tuple[tuple[str, str], ...]]:
        method_upper = method.upper()
        if method_upper == "GET" and path == "/healthz":
            return 200, {"status": "ok", "service": "aegis-console"}, (("content-type", "application/json; charset=utf-8"),)
        if method_upper not in {"GET", "POST"}:
            return 405, {"error": "method_not_allowed"}, (("content-type", "application/json; charset=utf-8"),)
        if path == "/":
            if method_upper != "GET":
                return 405, {"error": "method_not_allowed"}, (("content-type", "application/json; charset=utf-8"),)
            return 200, self._landing(), (("content-type", "text/html; charset=utf-8"),)

        parts = tuple(part for part in path.strip("/").split("/") if part)
        if len(parts) < 2 or parts[0] != "sessions":
            return 404, {"error": "not_found"}, (("content-type", "application/json; charset=utf-8"),)

        session_id = parts[1]
        if len(parts) == 2:
            if method_upper != "GET":
                return 405, {"error": "method_not_allowed"}, (("content-type", "application/json; charset=utf-8"),)
            return 200, self._session_page(session_id, "overview"), (("content-type", "text/html; charset=utf-8"),)

        view = parts[2]
        if len(parts) == 3 and method_upper == "GET":
            if view == "goals":
                return 200, self._goals_page(session_id), (("content-type", "text/html; charset=utf-8"),)
            if view == "memories":
                return 200, self._memories_page(session_id), (("content-type", "text/html; charset=utf-8"),)
            return 200, self._session_page(session_id, view), (("content-type", "text/html; charset=utf-8"),)

        if len(parts) == 3 and view == "identity" and method_upper == "POST":
            form = _form_data(body)
            clear_charter = form.get("action") == "clear_charter"
            self.api.update_identity_state(
                session_id=session_id,
                display_name=form.get("display_name") or None,
                personality_preset=form.get("personality_preset") or None,
                initiative=form.get("initiative") or None,
                charter_text=None if clear_charter else (form.get("charter_text") or None),
                clear_charter=clear_charter,
            )
            notice = "Identity updated durably." if not clear_charter else "Identity charter cleared durably."
            return 200, self._identity_page(session_id, notice=notice), (("content-type", "text/html; charset=utf-8"),)

        if len(parts) == 3 and view == "user" and method_upper == "POST":
            form = _form_data(body)
            mutation = form.get("mutation", "set")
            self.api.update_user_state(
                session_id=session_id,
                text=form.get("text") or None,
                append=mutation == "append",
                clear=mutation == "clear",
            )
            notice = "User state updated durably." if mutation != "clear" else "User state cleared durably."
            return 200, self._user_page(session_id, notice=notice), (("content-type", "text/html; charset=utf-8"),)

        if len(parts) == 3 and view == "relationship" and method_upper == "POST":
            form = _form_data(body)
            mutation = form.get("mutation", "set")
            self.api.update_relationship_state(
                session_id=session_id,
                text=form.get("text") or None,
                append=mutation == "append",
                clear=mutation == "clear",
            )
            notice = "Relationship state updated durably." if mutation != "clear" else "Relationship state cleared durably."
            return 200, self._relationship_page(session_id, notice=notice), (("content-type", "text/html; charset=utf-8"),)

        if len(parts) == 3 and view == "goals" and method_upper == "POST":
            form = _form_data(body)
            created = self.api.create_goal(
                session_id,
                title=form.get("title", ""),
                status=form.get("status", "active"),
                priority=form.get("priority", "medium"),
                reason=form.get("reason"),
            )
            notice = f'Goal created durably: {created["goal"].title}'
            return 200, self._goal_page(session_id, created["goal"].goal_id, notice=notice), (("content-type", "text/html; charset=utf-8"),)

        if len(parts) == 4 and view == "goals":
            goal_id = parts[3]
            if method_upper == "GET":
                return 200, self._goal_page(session_id, goal_id), (("content-type", "text/html; charset=utf-8"),)
            form = _form_data(body)
            if form.get("action", "edit") == "delete":
                self.api.delete_goal(session_id, goal_id, reason=form.get("reason", ""))
                notice = "Goal deleted durably."
            else:
                self.api.update_goal(
                    session_id,
                    goal_id,
                    title=form.get("title"),
                    status=form.get("status"),
                    priority=form.get("priority"),
                    reason=form.get("reason"),
                )
                notice = "Goal updated durably."
            return 200, self._goal_page(session_id, goal_id, notice=notice), (("content-type", "text/html; charset=utf-8"),)

        if len(parts) == 4 and view == "memories":
            memory_id = parts[3]
            if method_upper == "GET":
                return 200, self._memory_page(session_id, memory_id), (("content-type", "text/html; charset=utf-8"),)
            form = _form_data(body)
            if form.get("action", "correct") == "delete":
                self.api.delete_memory(session_id, memory_id, reason=form.get("reason", ""))
                notice = "Memory deleted durably."
            else:
                self.api.correct_memory(
                    session_id,
                    memory_id,
                    corrected_content=form.get("corrected_content", ""),
                    reason=form.get("reason", ""),
                )
                notice = "Memory corrected durably."
            return 200, self._memory_page(session_id, memory_id, notice=notice), (("content-type", "text/html; charset=utf-8"),)

        if method_upper == "GET":
            view = parts[2] if len(parts) > 2 else "overview"
            return 200, self._session_page(session_id, view), (("content-type", "text/html; charset=utf-8"),)
        return 404, {"error": "not_found"}, (("content-type", "application/json; charset=utf-8"),)

    def __call__(self, environ: Mapping[str, Any], start_response: Any) -> list[bytes]:
        method = str(environ.get("REQUEST_METHOD", "GET"))
        path = str(environ.get("PATH_INFO", "/"))
        query = parse_qs(str(environ.get("QUERY_STRING", "")))
        if path == "/" and query.get("session_id"):
            session_id = query["session_id"][0]
            response = self._session_page(session_id, "overview")
            start_response("200 OK", [("content-type", "text/html; charset=utf-8")])
            return [response]
        body_stream = environ.get("wsgi.input")
        payload_bytes = body_stream.read() if body_stream is not None else b""
        status_code, payload, headers = self.dispatch(method, path, payload_bytes)
        start_response(f"{status_code} {'OK' if status_code < 400 else 'ERROR'}", list(headers))
        if isinstance(payload, bytes):
            return [payload]
        return [_json_response(payload)]


def create_app(
    *,
    database_path: str | Path,
    instruction_refs: tuple[str, ...] = ("apps/api",),
    total_tokens: int = 2048,
) -> AegisConsoleApp:
    return AegisConsoleApp(
        ConsoleAppConfig(
            database_path=Path(database_path),
            instruction_refs=instruction_refs,
            total_tokens=total_tokens,
        )
    )
