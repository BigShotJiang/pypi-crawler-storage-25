"""Governable companion identity and onboarding surfaces."""

from __future__ import annotations

from collections.abc import Mapping
import re
from dataclasses import dataclass
from typing import Sequence

from .loader import LoadedProfile, load_packaged_aegis_text
from .policy import CompanionSettings, resolve_personality_preset

DEFAULT_AEGIS_TEXT = "\n".join(
    (
        "You are Aegis, a persistent AI built to protect continuity, context, and trust across time.",
        "Every named clone is still Aegis: the core charter is stable even when the clone's voice evolves.",
        "Stay grounded, calm, direct, and exact.",
        "Never fake memory, certainty, capability, intimacy, or identity.",
        "Let AEGIS.md define the immutable core, let CLONE.md define this clone's voice, and let FRIEND.md define durable facts about the user.",
    )
)
DEFAULT_CLONE_TEXT = "\n".join(
    (
        "You are a named Aegis clone for this friend.",
        "Protect the thread, carry context forward, and make your voice legible over time.",
        "Stay warm when invited, exact when it matters, and trustworthy always.",
    )
)


@dataclass(frozen=True, slots=True)
class OnboardingCheckpoint:
    checkpoint_id: str
    label: str
    status: str
    summary: str


@dataclass(frozen=True, slots=True)
class CompanionOnboardingState:
    status: str
    ready: bool
    missing_fields: tuple[str, ...]
    next_step: str
    summary: str
    checkpoints: tuple[OnboardingCheckpoint, ...]


@dataclass(frozen=True, slots=True)
class CompanionIdentityState:
    display_name: str
    mode: str
    aegis_text: str
    clone_text: str
    friend_text: str
    personality_preset: str
    personality_label: str
    personality_traits: tuple[str, ...]
    personality_summary: str
    relational_stance: str
    initiative: str
    continuity_notes: tuple[str, ...]
    governance_summary: str
    proactive_summary: str
    voice_identity_summary: str


@dataclass(frozen=True, slots=True)
class CompanionGovernanceState:
    identity: CompanionIdentityState
    onboarding: CompanionOnboardingState


@dataclass(frozen=True, slots=True)
class FriendProfileQuestion:
    field_id: str
    canonical_label: str
    bucket: str
    aliases: tuple[str, ...] = ()


FRIEND_PROFILE_QUESTIONS = (
    FriendProfileQuestion(
        field_id="preferred_name",
        canonical_label="Preferred name",
        bucket="required",
        aliases=("name", "nickname", "call me"),
    ),
    FriendProfileQuestion(
        field_id="current_work",
        canonical_label="Current work",
        bucket="required",
        aliases=("work", "current role", "work focus"),
    ),
    FriendProfileQuestion(
        field_id="school",
        canonical_label="School",
        bucket="good-to-have",
    ),
    FriendProfileQuestion(
        field_id="current_city",
        canonical_label="Current city",
        bucket="good-to-have",
        aliases=("city", "home city"),
    ),
    FriendProfileQuestion(
        field_id="mbti",
        canonical_label="MBTI",
        bucket="good-to-have",
    ),
    FriendProfileQuestion(
        field_id="dream",
        canonical_label="Dream",
        bucket="good-to-have",
    ),
    FriendProfileQuestion(
        field_id="creative_hobby",
        canonical_label="Creative hobby",
        bucket="good-to-have",
        aliases=("hobby creative",),
    ),
    FriendProfileQuestion(
        field_id="media_hobby",
        canonical_label="Media hobby",
        bucket="good-to-have",
        aliases=("hobby media",),
    ),
    FriendProfileQuestion(
        field_id="movement_hobby",
        canonical_label="Movement hobby",
        bucket="good-to-have",
        aliases=("hobby movement",),
    ),
    FriendProfileQuestion(
        field_id="boundaries",
        canonical_label="Boundaries",
        bucket="good-to-have",
        aliases=("sensitivities", "boundaries and sensitivities"),
    ),
)


def _normalize_friend_field_label(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", " ", value.strip().lower()).strip()


_FRIEND_PROFILE_FIELD_LOOKUP = {
    _normalize_friend_field_label(label): question.field_id
    for question in FRIEND_PROFILE_QUESTIONS
    for label in (question.field_id, question.canonical_label, *question.aliases)
}


def _clean_friend_field_value(value: str) -> str:
    cleaned = value.strip().strip("*").strip()
    cleaned = cleaned.strip("\"' ")
    return cleaned


def parse_friend_profile(text: str) -> dict[str, str]:
    values: dict[str, str] = {}
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        line = re.sub(r"^[-*]\s+", "", line)
        if ":" not in line:
            continue
        label, raw_value = line.split(":", 1)
        field_id = _FRIEND_PROFILE_FIELD_LOOKUP.get(_normalize_friend_field_label(label))
        value = _clean_friend_field_value(raw_value)
        if field_id is None or not value:
            continue
        if value.lower() in {"unknown", "n/a", "none", "<unknown>", "<unset>"}:
            continue
        values[field_id] = value
    if "preferred_name" not in values:
        name_match = re.search(
            r"(?i)\b(?:call me|i go by|my name is|i'm called|i am called)\s+([^\n,.;:]+)",
            text,
        )
        if name_match is not None:
            inferred = _clean_friend_field_value(name_match.group(1))
            if inferred:
                values["preferred_name"] = inferred
    if "current_work" not in values:
        work_match = re.search(
            (
                r"(?i)\b(?:i work on|i'm working on|i am working on|user works on|i build|i'm building|"
                r"i am building|user builds|i research|i'm researching|i am researching|user researches|"
                r"i study|i'm studying|i am studying|user studies|current work is|my work is)\s+([^\n.!?]+)"
            ),
            text,
        )
        if work_match is not None:
            inferred = _clean_friend_field_value(work_match.group(1))
            if inferred:
                values["current_work"] = inferred
    return values


def friend_profile_updates(
    payload: Mapping[str, object],
    *,
    ignored_keys: Sequence[str] = ("action", "target", "text", "fields", "profile_id"),
) -> dict[str, str]:
    ignored = {_normalize_friend_field_label(key) for key in ignored_keys}
    values: dict[str, str] = {}
    for raw_key, raw_value in payload.items():
        normalized_key = _normalize_friend_field_label(str(raw_key))
        if not normalized_key or normalized_key in ignored:
            continue
        field_id = _FRIEND_PROFILE_FIELD_LOOKUP.get(normalized_key)
        if field_id is None:
            continue
        value = _clean_friend_field_value(str(raw_value or ""))
        if not value or value.lower() in {"unknown", "n/a", "none", "<unknown>", "<unset>"}:
            continue
        values[field_id] = value
    return values


def merge_friend_profile_text(
    existing_text: str | None,
    *,
    field_values: Mapping[str, str],
) -> str | None:
    merged = parse_friend_profile(existing_text or "")
    merged.update(field_values)
    if not merged:
        return None
    return render_friend_profile(**merged)


def friend_profile_fields(profile: LoadedProfile) -> dict[str, str]:
    return parse_friend_profile(friend_text(profile))


def render_friend_profile(**field_values: str | None) -> str:
    lines: list[str] = []
    for question in FRIEND_PROFILE_QUESTIONS:
        value = _clean_friend_field_value(str(field_values.get(question.field_id) or ""))
        if value:
            lines.append(f"{question.canonical_label}: {value}")
    return "\n".join(lines)


def missing_friend_required_questions(profile: LoadedProfile) -> tuple[FriendProfileQuestion, ...]:
    values = friend_profile_fields(profile)
    return tuple(
        question
        for question in FRIEND_PROFILE_QUESTIONS
        if question.bucket == "required" and not values.get(question.field_id)
    )


def missing_friend_good_to_have_questions(profile: LoadedProfile) -> tuple[FriendProfileQuestion, ...]:
    values = friend_profile_fields(profile)
    return tuple(
        question
        for question in FRIEND_PROFILE_QUESTIONS
        if question.bucket == "good-to-have" and not values.get(question.field_id)
    )


def resolved_companion_settings(profile: LoadedProfile) -> CompanionSettings:
    if profile.companion is not None:
        return profile.companion
    preset = resolve_personality_preset(None, mode=profile.state.mode)
    return CompanionSettings(
        personality_preset=preset.preset_id,
        personality=preset.traits,
    )


def aegis_text(profile: LoadedProfile) -> str:
    try:
        return load_packaged_aegis_text().strip()
    except OSError:
        return DEFAULT_AEGIS_TEXT


def render_clone_charter(
    *,
    display_name: str,
    personality_preset: str | None,
    initiative: str,
    mode: str = "default",
) -> str:
    preset = resolve_personality_preset(personality_preset, mode=mode)
    traits = ", ".join(preset.traits) or "grounded, direct, trustworthy"
    return "\n".join(
        (
            f"You are {display_name}, a named Aegis clone for this friend.",
            f"Default posture: {preset.summary}",
            f"Traits to preserve: {traits}.",
            f"Initiative style: {initiative}.",
            "Carry continuity carefully, protect trust, and let the friend refine this clone over time.",
        )
    )


def clone_text(profile: LoadedProfile) -> str:
    companion = resolved_companion_settings(profile)
    return (
        profile.clone_text
        or render_clone_charter(
            display_name=profile.state.display_name,
            personality_preset=companion.personality_preset,
            initiative=companion.initiative,
            mode=profile.state.mode,
        )
        or DEFAULT_CLONE_TEXT
    ).strip()


def friend_text(profile: LoadedProfile) -> str:
    return (profile.friend_text or "").strip()


def build_companion_identity_state(profile: LoadedProfile) -> CompanionIdentityState:
    companion = resolved_companion_settings(profile)
    preset = resolve_personality_preset(companion.personality_preset, mode=profile.state.mode)
    traits = companion.personality or preset.traits
    clone_charter = clone_text(profile)
    friend_profile = friend_text(profile)
    return CompanionIdentityState(
        display_name=profile.state.display_name,
        mode=profile.state.mode,
        aegis_text=aegis_text(profile),
        clone_text=clone_charter,
        friend_text=friend_profile,
        personality_preset=preset.preset_id,
        personality_label=preset.label,
        personality_traits=traits,
        personality_summary=preset.summary,
        relational_stance=preset.relational_stance,
        initiative=companion.initiative,
        continuity_notes=companion.notes,
        governance_summary=companion.governance_summary(),
        proactive_summary=companion.proactive_summary(),
        voice_identity_summary=companion.voice_identity_summary(),
    )


def build_companion_onboarding_state(profile: LoadedProfile) -> CompanionOnboardingState:
    manifest = dict(profile.manifest)
    identity = build_companion_identity_state(profile)
    missing_required_friend_questions = missing_friend_required_questions(profile)
    missing_good_to_have_friend_questions = missing_friend_good_to_have_questions(profile)

    has_explicit_display_name = "display_name" in manifest
    has_custom_clone = profile.clone_text is not None and profile.clone_text.strip() != ""
    has_required_friend_profile = not missing_required_friend_questions

    checkpoints = (
        OnboardingCheckpoint(
            checkpoint_id="display-name",
            label="Display name",
            status="ready" if has_explicit_display_name else "needs-confirmation",
            summary=(
                f"identity anchored as {identity.display_name}"
                if has_explicit_display_name
                else f"using derived display name {identity.display_name}"
            ),
        ),
        OnboardingCheckpoint(
            checkpoint_id="clone",
            label="Clone charter",
            status="ready" if has_custom_clone else "needs-confirmation",
            summary=(
                "durable CLONE.md is present"
                if has_custom_clone
                else "still running on the default clone charter"
            ),
        ),
        OnboardingCheckpoint(
            checkpoint_id="friend",
            label="Friend profile",
            status="ready" if has_required_friend_profile else "needs-confirmation",
            summary=(
                (
                    "FRIEND.md has the required stable user fields set"
                    + (
                        f"; {len(missing_good_to_have_friend_questions)} optional profile fields remain open"
                        if missing_good_to_have_friend_questions
                        else ""
                    )
                )
                if has_required_friend_profile
                else (
                    "FRIEND.md still needs the required stable user fields: "
                    + ", ".join(question.canonical_label for question in missing_required_friend_questions)
                )
            ),
        ),
    )
    missing_fields = tuple(
        checkpoint.checkpoint_id for checkpoint in checkpoints if checkpoint.status != "ready"
    )
    ready = not missing_fields
    if ready:
        status = "ready"
        next_step = "identity-governance-ready"
        summary = (
            "AEGIS, clone, and friend state are explicitly grounded for one "
            "long-lived companion path."
        )
    else:
        status = "needs-onboarding"
        next_step = "confirm the clone charter and gather FRIEND.md before treating the profile as fully onboarded"
        summary = (
            "Companion identity exists, but onboarding still needs explicit grounding "
            "for: " + ", ".join(missing_fields)
        )
    return CompanionOnboardingState(
        status=status,
        ready=ready,
        missing_fields=missing_fields,
        next_step=next_step,
        summary=summary,
        checkpoints=checkpoints,
    )


def build_companion_governance_state(profile: LoadedProfile) -> CompanionGovernanceState:
    return CompanionGovernanceState(
        identity=build_companion_identity_state(profile),
        onboarding=build_companion_onboarding_state(profile),
    )
