"""Planning service and scoring helpers."""

from __future__ import annotations

from dataclasses import replace
from datetime import datetime, timedelta
from uuid import uuid4

from packages.contracts import EventEnvelope, ExecutionResult, MemoryRecord, PlanDraft, PlanStep, SessionState, WorkGraph

from .model import (
    CandidateMove,
    ExecutionTracker,
    GoalGraph,
    GoalGraphLifecycleUpdate,
    GoalGraphNode,
    GoalStatus,
    goal_graph_to_work_graph,
    work_graph_to_goal_graph,
    MoveKind,
    PlanningDecision,
    PlanningMode,
    PlanningRationale,
    TemporalContext,
    _INITIATIVE_CONTINUITY_BONUS,
    _PRIORITY_POINTS,
    _STATUS_POINTS,
    _TIME_SENSITIVITY_POINTS,
    _continuity_note_bonus,
    _continuity_note_factors,
    _dedupe_strings,
    _dependencies_satisfied,
    _format_delta,
    _goal_similarity,
    _normalize_initiative,
    _now,
    _stringify,
)
from .signals import (
    _analyze_goal_signal,
    _goal_seed_text,
    _match_goal_for_signal,
    _new_goal_node,
    _status_for_signal,
)


def _deadline_score(deadline: datetime | None, now: datetime) -> float:
    if deadline is None:
        return 0.0
    delta = deadline - now
    hours = delta.total_seconds() / 3600.0
    if hours <= 0:
        return 1.4
    if hours <= 4:
        return 1.1
    if hours <= 24:
        return 0.7
    if hours <= 72:
        return 0.35
    return 0.1


def _staleness_score(goal: GoalGraphNode, temporal: TemporalContext, now: datetime) -> float:
    goal_idle_for = now - goal.updated_at
    if goal_idle_for < timedelta(0):
        goal_idle_for = timedelta(0)
    effective_idle = goal_idle_for
    if temporal.idle_for is not None and temporal.idle_for > effective_idle:
        effective_idle = temporal.idle_for
    if effective_idle < timedelta(hours=12):
        return 0.0
    severe = effective_idle >= timedelta(days=2)
    if goal.goal_id == temporal.active_goal_id and goal.status == "blocked":
        return 0.6 if severe else 0.35
    if goal.goal_id == temporal.active_goal_id:
        return 0.75 if severe else 0.4
    if goal.status == "blocked":
        return 0.45 if severe else 0.2
    if goal.goal_id in temporal.ready_goal_ids:
        return 0.2 if severe else 0.1
    return 0.0


def _continuity_score(goal: GoalGraphNode, graph: GoalGraph, temporal: TemporalContext) -> float:
    active_goal = graph.active_goal()
    if goal.goal_id == graph.active_goal_id:
        return 0.9
    if graph.active_goal_id is not None and goal.parent_goal_id == graph.active_goal_id:
        return 0.45
    if active_goal is not None and active_goal.parent_goal_id is not None and goal.parent_goal_id == active_goal.parent_goal_id:
        return 0.2
    if goal.goal_id == graph.root_goal_id:
        return 0.15
    if graph.root_goal_id is not None and goal.parent_goal_id == graph.root_goal_id:
        return 0.1
    if temporal.resumed and goal.goal_id in temporal.ready_goal_ids:
        return 0.1
    return 0.0


def _blocked_recovery_goal_ids(graph: GoalGraph, ready_goal_ids: tuple[str, ...]) -> tuple[str, ...]:
    active_goal = graph.active_goal()
    if active_goal is None or active_goal.status != "blocked":
        return ()
    ready = set(ready_goal_ids)
    recovery_goal_ids: list[str] = []
    for goal in graph.nodes:
        if goal.goal_id == active_goal.goal_id or goal.goal_id not in ready:
            continue
        if active_goal.parent_goal_id is not None and goal.parent_goal_id == active_goal.parent_goal_id:
            recovery_goal_ids.append(goal.goal_id)
            continue
        if goal.parent_goal_id == active_goal.goal_id:
            recovery_goal_ids.append(goal.goal_id)
            continue
        if graph.root_goal_id is not None and goal.parent_goal_id == graph.root_goal_id:
            recovery_goal_ids.append(goal.goal_id)
    return tuple(dict.fromkeys(recovery_goal_ids))


def _project_graph_surface(source_graph: GoalGraph | WorkGraph, graph: GoalGraph) -> GoalGraph | WorkGraph:
    if isinstance(source_graph, WorkGraph):
        return goal_graph_to_work_graph(graph)
    return graph


def _repair_score(goal: GoalGraphNode, temporal: TemporalContext) -> float:
    if temporal.blocked_active_goal_id is None:
        return 0.0
    if goal.goal_id == temporal.blocked_active_goal_id and temporal.recovery_goal_ids:
        return -1.4
    if goal.goal_id in temporal.recovery_goal_ids:
        return 1.2
    if goal.goal_id in temporal.ready_goal_ids:
        return 0.2
    return 0.0


def _kind_for_goal(goal: GoalGraphNode, temporal: TemporalContext, execution_tracker: ExecutionTracker | None) -> MoveKind:
    if goal.status == "blocked" or goal.goal_id in temporal.blocked_goal_ids:
        return "update_plan"
    if goal.status in {"deferred", "completed", "done", "failed", "dropped"}:
        return "defer_or_schedule"
    if goal.goal_id in temporal.overdue_goal_ids:
        return "act_on_task"
    if goal.goal_id in temporal.ready_goal_ids:
        if temporal.resumed and goal.goal_id == temporal.active_goal_id:
            return "act_on_task"
        if goal.status == "active":
            return "act_on_task"
        if execution_tracker and goal.goal_id in execution_tracker.in_flight_goal_ids:
            return "act_on_task"
        return "act_on_task"
    if goal.dependency_refs:
        return "ask_for_information"
    return "defer_or_schedule"


def _rationale_for(
    goal: GoalGraphNode,
    temporal: TemporalContext,
    kind: MoveKind,
    tracker: ExecutionTracker | None,
    *,
    now: datetime,
) -> tuple[str, tuple[str, ...]]:
    factors: list[str] = []
    sentences: list[str] = []

    if temporal.resumed:
        factors.append("session-resumed")
        if temporal.session_resume_reason:
            sentences.append(temporal.session_resume_reason)
        else:
            sentences.append("The session resumed from durable state.")

    if goal.status == "active":
        factors.append("active-goal")
        sentences.append("The active goal is already in progress, so continuing it preserves continuity.")
    elif goal.status == "queued":
        factors.append("queued-goal")
        sentences.append("The goal is queued and ready to be advanced.")
    elif goal.status == "proposed":
        factors.append("proposed-goal")
        sentences.append("The goal is proposed and available for selection.")
    elif goal.status == "blocked":
        factors.append("blocked-goal")
        sentences.append("The goal is blocked, so the planner should surface the blocker or re-plan.")
    elif goal.status == "deferred":
        factors.append("deferred-goal")
        sentences.append("The goal is deferred and should remain durable until a later resume or explicit reactivation.")
    elif goal.status in {"completed", "done"}:
        factors.append("completed-goal")
        sentences.append("The goal is completed and remains durable for inspection and handoff.")

    if temporal.blocked_active_goal_id is not None:
        if goal.goal_id in temporal.recovery_goal_ids:
            factors.append("blocked-goal-recovery")
            sentences.append(
                "The active goal is blocked, so the planner should recover through a ready adjacent goal instead of repeating the blocked step."
            )
        elif goal.goal_id == temporal.blocked_active_goal_id and temporal.recovery_goal_ids:
            factors.append("blocked-goal-suppressed")
            sentences.append(
                "A ready recovery path exists elsewhere in the graph, so the blocked active goal should not be selected again immediately."
            )

    if goal.deadline is not None:
        factors.append("deadline")
        if goal.deadline <= now:
            sentences.append("The deadline has passed, which raises urgency.")
        else:
            sentences.append(f"The deadline is approaching in {_format_delta(goal.deadline - now)}.")

    if goal.dependency_refs:
        factors.append("dependencies")
        if kind == "ask_for_information":
            sentences.append("One or more dependencies are still unresolved.")
        else:
            sentences.append("Its dependencies appear satisfiable from the current graph.")

    if tracker and goal.goal_id in tracker.in_flight_goal_ids:
        factors.append("in-flight")
        sentences.append("The execution tracker shows this goal is still in flight.")

    if goal.evidence_refs:
        factors.append("evidence")
        sentences.append("Durable evidence is attached to the goal, so the next step can stay grounded.")

    staleness_score = _staleness_score(goal, temporal, now)
    if staleness_score > 0:
        if goal.goal_id == temporal.active_goal_id and goal.status == "blocked":
            factors.append("stale-blocked-goal")
            sentences.append("The blocked active goal has sat idle long enough that the planner should force a visible re-plan.")
        elif goal.goal_id == temporal.active_goal_id:
            factors.append("stale-active-goal")
            sentences.append("The active goal has remained idle long enough that the planner should re-engage it explicitly.")
        elif goal.status == "blocked":
            factors.append("stale-blocked-goal")
            sentences.append("The blocked goal has lingered in the graph, so the planner should resolve it instead of letting it silently decay.")
        else:
            factors.append("stale-ready-goal")
            sentences.append("The ready goal has been waiting in durable state and deserves a fresh decision.")

    if not sentences:
        sentences.append("The selected move best balances priority, readiness, and continuity.")

    if kind == "act_on_task":
        sentences.append("The planner advances the work because the durable graph shows a ready goal.")
    elif kind == "update_plan":
        sentences.append("The planner updates the plan instead of advancing because blockers still need attention.")
    elif kind == "defer_or_schedule":
        sentences.append("The planner defers the goal so the wake loop can return to it later without losing state.")
    elif kind == "ask_for_information":
        sentences.append("The planner pauses to gather the missing information before advancing.")

    summary = " ".join(sentences)
    return summary, tuple(dict.fromkeys(factors))


def _progression_action_for(kind: MoveKind) -> str:
    if kind in {"act_on_task", "answer_directly"}:
        return "advance"
    if kind == "update_plan":
        return "replan"
    if kind == "ask_for_information":
        return "gather_information"
    return "defer"


def _planned_progression(
    graph: GoalGraph,
    goal: GoalGraphNode | None,
    kind: MoveKind,
) -> tuple[GoalStatus | None, str | None]:
    if goal is None:
        return None, graph.active_goal_id
    if kind in {"act_on_task", "answer_directly"}:
        return "active", goal.goal_id
    if kind == "defer_or_schedule":
        if goal.status in {"completed", "done"}:
            next_status = goal.status
        else:
            next_status = "deferred"
        next_active_goal_id = None if graph.active_goal_id == goal.goal_id else graph.active_goal_id
        return next_status, next_active_goal_id
    if kind == "update_plan":
        next_active_goal_id = None if graph.active_goal_id == goal.goal_id and goal.status == "blocked" else graph.active_goal_id
        return goal.status, next_active_goal_id
    return goal.status, graph.active_goal_id


def _progression_sentence(
    goal: GoalGraphNode | None,
    *,
    action: str,
    planned_status: GoalStatus | None,
    planned_active_goal_id: str | None,
) -> str:
    if goal is None:
        if action == "defer":
            return "The durable graph defers the goal set and keeps the active slot clear until a later wake cycle."
        return "No durable goal state changed because no actionable goal was selected."
    if action == "advance":
        return f'The durable graph keeps "{goal.title}" active as the next step.'
    if action == "replan":
        return f'The durable graph keeps "{goal.title}" {planned_status or goal.status} until the blocker is cleared.'
    if action == "gather_information":
        return f'The durable graph leaves "{goal.title}" {planned_status or goal.status} until missing information arrives.'
    if planned_active_goal_id is None:
        return f'The durable graph records "{goal.title}" as {planned_status or goal.status} and clears the active slot.'
    return f'The durable graph records "{goal.title}" as {planned_status or goal.status} while preserving active goal {planned_active_goal_id}.'


def _fallback_active_goal_id(graph: GoalGraph, *, exclude_goal_id: str | None = None) -> str | None:
    ready = [
        goal
        for goal in graph.ready_goals()
        if goal.goal_id != exclude_goal_id
    ]
    if not ready:
        return None
    ordered = sorted(
        ready,
        key=lambda goal: (
            _PRIORITY_POINTS[goal.priority],
            _STATUS_POINTS[goal.status],
            goal.updated_at,
        ),
        reverse=True,
    )
    return ordered[0].goal_id


def _reassign_active_goal(
    graph: GoalGraph,
    *,
    active_goal_id: str | None,
    revision_id: str,
    updated_at: datetime,
) -> GoalGraph:
    if graph.active_goal_id == active_goal_id and graph.revision_id == revision_id:
        return graph
    return replace(
        graph,
        active_goal_id=active_goal_id,
        revision_id=revision_id,
        updated_at=updated_at,
    )


def _ensure_single_active_goal(
    graph: GoalGraph,
    *,
    goal_id: str,
    revision_id: str,
    updated_at: datetime,
) -> GoalGraph:
    active = graph.active_goal()
    next_graph = graph
    if active is not None and active.goal_id != goal_id and active.status == "active":
        next_graph = next_graph.transition_goal(
            active.goal_id,
            status="queued",
            revision_id=revision_id,
            updated_at=updated_at,
            active_goal_id=active.goal_id,
        )
    focused = next_graph.goal(goal_id)
    if focused is None:
        return next_graph
    if focused.status != "active":
        next_graph = next_graph.transition_goal(
            goal_id,
            status="active",
            revision_id=revision_id,
            updated_at=updated_at,
            active_goal_id=goal_id,
        )
    return _reassign_active_goal(next_graph, active_goal_id=goal_id, revision_id=revision_id, updated_at=updated_at)


class TemporalReasoner:
    """Inspect the graph for time pressure and resume signals."""

    resume_gap: timedelta
    due_soon_window: timedelta

    def __init__(
        self,
        *,
        resume_gap: timedelta | None = None,
        due_soon_window: timedelta | None = None,
    ) -> None:
        self.resume_gap = timedelta(hours=6) if resume_gap is None else resume_gap
        self.due_soon_window = timedelta(days=1) if due_soon_window is None else due_soon_window

    def analyze(
        self,
        session: SessionState,
        graph: GoalGraph,
        *,
        now: datetime | None = None,
    ) -> TemporalContext:
        current = _now() if now is None else now
        resumed = session.interruption_state is not None or session.parent_session_id is not None
        session_resume_reason = None
        if resumed:
            session_resume_reason = "The session resumed from a prior collaboration and should continue the durable goal graph."

        ready_goal_ids: list[str] = []
        blocked_goal_ids: list[str] = []
        overdue_goal_ids: list[str] = []
        due_soon_goal_ids: list[str] = []

        indexed = graph.index()
        for goal in graph.nodes:
            dependencies_ready = _dependencies_satisfied(goal, indexed)
            if goal.status in {"proposed", "queued", "active"} and dependencies_ready:
                ready_goal_ids.append(goal.goal_id)
            if goal.status == "blocked" or (
                goal.status not in {"deferred", "completed", "done", "failed", "dropped"}
                and not dependencies_ready
            ):
                blocked_goal_ids.append(goal.goal_id)
            if goal.deadline is not None:
                delta = goal.deadline - current
                if delta <= timedelta(0):
                    overdue_goal_ids.append(goal.goal_id)
                elif delta <= self.due_soon_window:
                    due_soon_goal_ids.append(goal.goal_id)

        idle_for = None
        if session.interruption_state is not None:
            idle_for = current - session.updated_at
            if idle_for < timedelta(0):
                idle_for = None

        ordered_ready_goal_ids = tuple(dict.fromkeys(ready_goal_ids))
        ordered_blocked_goal_ids = tuple(dict.fromkeys(blocked_goal_ids))
        blocked_active_goal_id = graph.active_goal_id if graph.active_goal_id in ordered_blocked_goal_ids else None
        recovery_goal_ids = _blocked_recovery_goal_ids(graph, ordered_ready_goal_ids)

        return TemporalContext(
            resumed=resumed,
            session_resume_reason=session_resume_reason,
            active_goal_id=graph.active_goal_id,
            ready_goal_ids=ordered_ready_goal_ids,
            blocked_goal_ids=ordered_blocked_goal_ids,
            recovery_goal_ids=recovery_goal_ids,
            blocked_active_goal_id=blocked_active_goal_id,
            overdue_goal_ids=tuple(dict.fromkeys(overdue_goal_ids)),
            due_soon_goal_ids=tuple(dict.fromkeys(due_soon_goal_ids)),
            idle_for=idle_for,
        )


class PlanningService:
    """Score goal graph candidates and emit next-step rationale."""

    def __init__(self, reasoner: TemporalReasoner | None = None) -> None:
        self._reasoner = TemporalReasoner() if reasoner is None else reasoner

    def maintain_goal_graph(
        self,
        *,
        session: SessionState,
        graph: GoalGraph | WorkGraph,
        prompt: str,
        goal_query: str | None = None,
        event: EventEnvelope | None = None,
        now: datetime | None = None,
    ) -> GoalGraphLifecycleUpdate:
        graph_surface = graph
        graph = work_graph_to_goal_graph(graph)
        current = _now() if now is None else now

        def lifecycle(
            graph_value: GoalGraph,
            *,
            changed: bool,
            summary: str,
            created_goal_ids: tuple[str, ...] = (),
            updated_goal_ids: tuple[str, ...] = (),
        ) -> GoalGraphLifecycleUpdate:
            return GoalGraphLifecycleUpdate(
                graph=_project_graph_surface(graph_surface, graph_value),
                changed=changed,
                summary=summary,
                created_goal_ids=created_goal_ids,
                updated_goal_ids=updated_goal_ids,
            )

        seed = _goal_seed_text(prompt=prompt, goal_query=goal_query, event=event)
        if not seed:
            return lifecycle(graph, changed=False, summary="No goal signal was present.")

        signal = _analyze_goal_signal(seed)
        if goal_query and goal_query.strip():
            signal = replace(signal, task_like=True)

        if not signal.task_like and not any((signal.completion, signal.deferred, signal.blocked, signal.focus)):
            return lifecycle(graph, changed=False, summary="The turn did not imply a durable goal mutation.")

        event_refs = (f"event:{event.event_id}",) if event is not None else ()
        revision_id = f"goal:maintain:{uuid4().hex}"

        if not graph.nodes:
            initial_goal = replace(
                _new_goal_node(
                    graph=graph,
                    session_id=session.session_id,
                    signal=signal,
                    updated_at=current,
                    revision_id=revision_id,
                ),
                parent_goal_id=None,
                evidence_refs=event_refs,
            )
            next_graph = GoalGraph(
                session_id=session.session_id,
                nodes=(initial_goal,),
                root_goal_id=initial_goal.goal_id,
                active_goal_id=initial_goal.goal_id,
                revision_id=revision_id,
                updated_at=current,
            )
            return lifecycle(
                next_graph,
                changed=True,
                summary=f'Created the initial durable goal "{initial_goal.title}".',
                created_goal_ids=(initial_goal.goal_id,),
                updated_goal_ids=(initial_goal.goal_id,),
            )

        matched = _match_goal_for_signal(graph, signal)
        similarity = _goal_similarity(signal.source_text, matched.title) if matched is not None else 0.0
        desired_status = _status_for_signal(signal, matched)
        next_graph = graph
        updated_goal_ids: list[str] = []

        if matched is not None and desired_status is not None:
            next_status = desired_status
            next_active_goal_id = graph.active_goal_id
            if next_status in {"completed", "done", "failed", "dropped", "blocked", "deferred"} and graph.active_goal_id == matched.goal_id:
                next_active_goal_id = _fallback_active_goal_id(graph, exclude_goal_id=matched.goal_id)
            next_graph = next_graph.transition_goal(
                matched.goal_id,
                status=next_status,
                revision_id=revision_id,
                updated_at=current,
                active_goal_id=next_active_goal_id,
                evidence_refs=_dedupe_strings(matched.evidence_refs, event_refs),
                review_checkpoint=matched.review_checkpoint,
            )
            refreshed = next_graph.goal(matched.goal_id)
            if refreshed is not None:
                if signal.time_sensitivity != refreshed.time_sensitivity and _TIME_SENSITIVITY_POINTS[signal.time_sensitivity] > _TIME_SENSITIVITY_POINTS[refreshed.time_sensitivity]:
                    next_graph = next_graph.with_goal(
                        replace(
                            refreshed,
                            time_sensitivity=signal.time_sensitivity,
                            revision_id=revision_id,
                            updated_at=current,
                        )
                    )
                if next_status == "active":
                    next_graph = _ensure_single_active_goal(
                        next_graph,
                        goal_id=matched.goal_id,
                        revision_id=revision_id,
                        updated_at=current,
                    )
            updated_goal_ids.append(matched.goal_id)
            if next_graph != graph:
                action = {
                    "completed": "Completed",
                    "blocked": "Marked blocked",
                    "deferred": "Deferred",
                    "active": "Focused",
                }.get(next_status, "Updated")
                return lifecycle(
                    next_graph,
                    changed=True,
                    summary=f'{action} goal "{matched.title}".',
                    updated_goal_ids=tuple(updated_goal_ids),
                )

        if matched is not None and signal.task_like and (
            similarity >= 0.35 or (goal_query is not None and matched.goal_id == graph.active_goal_id)
        ):
            focused_graph = _ensure_single_active_goal(
                graph,
                goal_id=matched.goal_id,
                revision_id=revision_id,
                updated_at=current,
            )
            refreshed = focused_graph.goal(matched.goal_id)
            if refreshed is not None:
                refreshed = replace(
                    refreshed,
                    evidence_refs=_dedupe_strings(refreshed.evidence_refs, event_refs),
                    time_sensitivity=(
                        signal.time_sensitivity
                        if _TIME_SENSITIVITY_POINTS[signal.time_sensitivity] > _TIME_SENSITIVITY_POINTS[refreshed.time_sensitivity]
                        else refreshed.time_sensitivity
                    ),
                    revision_id=revision_id,
                    updated_at=current,
                )
                focused_graph = focused_graph.with_goal(refreshed)
            if focused_graph != graph:
                return lifecycle(
                    focused_graph,
                    changed=True,
                    summary=f'Kept "{matched.title}" as the active durable goal.',
                    updated_goal_ids=(matched.goal_id,),
                )
            return lifecycle(
                graph,
                changed=False,
                summary=f'"{matched.title}" already matches the current durable goal.',
            )

        if signal.task_like:
            new_goal = replace(
                _new_goal_node(
                    graph=graph,
                    session_id=session.session_id,
                    signal=signal,
                    updated_at=current,
                    revision_id=revision_id,
                ),
                evidence_refs=event_refs,
            )
            created_graph = graph.with_goal(new_goal)
            created_graph = _ensure_single_active_goal(
                created_graph,
                goal_id=new_goal.goal_id,
                revision_id=revision_id,
                updated_at=current,
            )
            if created_graph.root_goal_id is None:
                created_graph = replace(
                    created_graph,
                    root_goal_id=graph.active_goal_id or new_goal.goal_id,
                    revision_id=revision_id,
                    updated_at=current,
                )
            created_graph = _reassign_active_goal(
                created_graph,
                active_goal_id=new_goal.goal_id,
                revision_id=revision_id,
                updated_at=current,
            )
            return lifecycle(
                created_graph,
                changed=True,
                summary=f'Created a new durable goal "{new_goal.title}".',
                created_goal_ids=(new_goal.goal_id,),
                updated_goal_ids=(new_goal.goal_id,),
            )

        return lifecycle(graph, changed=False, summary="No durable goal mutation was required.")

    def reconcile_goal_graph(
        self,
        *,
        session: SessionState,
        graph: GoalGraph | WorkGraph,
        prompt: str,
        execution: ExecutionResult,
        decision: PlanningDecision | None = None,
        event: EventEnvelope | None = None,
        now: datetime | None = None,
    ) -> GoalGraphLifecycleUpdate:
        graph_surface = graph
        graph = work_graph_to_goal_graph(graph)
        current = _now() if now is None else now

        def lifecycle(
            graph_value: GoalGraph,
            *,
            changed: bool,
            summary: str,
            created_goal_ids: tuple[str, ...] = (),
            updated_goal_ids: tuple[str, ...] = (),
        ) -> GoalGraphLifecycleUpdate:
            return GoalGraphLifecycleUpdate(
                graph=_project_graph_surface(graph_surface, graph_value),
                changed=changed,
                summary=summary,
                created_goal_ids=created_goal_ids,
                updated_goal_ids=updated_goal_ids,
            )

        if not graph.nodes:
            return lifecycle(graph, changed=False, summary="No durable goals existed to reconcile.")

        goal_id = (
            decision.selected_move.goal_id
            if decision is not None and decision.selected_move.goal_id is not None
            else graph.active_goal_id
        )
        if goal_id is None:
            return lifecycle(graph, changed=False, summary="No active goal was available for reconciliation.")
        goal = graph.goal(goal_id)
        if goal is None:
            return lifecycle(graph, changed=False, summary="The selected goal no longer exists in durable state.")

        signal = _analyze_goal_signal(" ".join(part for part in (prompt, execution.summary) if part).strip())
        revision_id = f"goal:reconcile:{uuid4().hex}"
        evidence_refs = _dedupe_strings(
            goal.evidence_refs,
            (f"event:{event.event_id}",) if event is not None else (),
            (f"execution:{execution.execution_id}",),
        )

        next_status = goal.status
        if signal.completion:
            next_status = "completed"
        elif signal.deferred:
            next_status = "deferred"
        elif signal.blocked or execution.outcome in {"error", "failed"}:
            next_status = "blocked"
        elif decision is not None and decision.selected_move.kind in {"act_on_task", "answer_directly"} and goal.status in {"proposed", "queued"}:
            next_status = "active"

        review_checkpoint = goal.review_checkpoint
        if execution.outcome == "paused":
            review_checkpoint = execution.summary[:160]

        next_active_goal_id = graph.active_goal_id
        if next_status in {"completed", "done", "failed", "dropped", "blocked", "deferred"} and graph.active_goal_id == goal.goal_id:
            next_active_goal_id = _fallback_active_goal_id(graph, exclude_goal_id=goal.goal_id)
        elif next_status == "active":
            next_active_goal_id = goal.goal_id

        next_graph = graph.transition_goal(
            goal.goal_id,
            status=next_status,
            revision_id=revision_id,
            updated_at=current,
            active_goal_id=next_active_goal_id,
            evidence_refs=evidence_refs,
            review_checkpoint=review_checkpoint,
        )
        if next_status == "active":
            next_graph = _ensure_single_active_goal(
                next_graph,
                goal_id=goal.goal_id,
                revision_id=revision_id,
                updated_at=current,
            )
        else:
            next_graph = _reassign_active_goal(
                next_graph,
                active_goal_id=next_active_goal_id,
                revision_id=revision_id,
                updated_at=current,
            )

        if next_graph == graph:
            return lifecycle(
                graph,
                changed=False,
                summary=f'Execution left "{goal.title}" unchanged in the durable graph.',
            )

        summary = f'Attached execution evidence to "{goal.title}".'
        if next_status != goal.status:
            summary = f'Updated "{goal.title}" to {next_status} after execution.'
        return lifecycle(
            next_graph,
            changed=True,
            summary=summary,
            updated_goal_ids=(goal.goal_id,),
        )

    def score_candidates(
        self,
        *,
        session: SessionState,
        graph: GoalGraph | WorkGraph,
        memories: tuple[MemoryRecord, ...] = (),
        execution_tracker: ExecutionTracker | None = None,
        initiative_hint: str | None = None,
        continuity_notes: tuple[str, ...] = (),
        mode: PlanningMode = "guided",
        now: datetime | None = None,
    ) -> tuple[CandidateMove, ...]:
        graph = work_graph_to_goal_graph(graph)
        current = _now() if now is None else now
        temporal = self._reasoner.analyze(session, graph, now=current)
        indexed = graph.index()
        candidates: list[CandidateMove] = []
        initiative = _normalize_initiative(initiative_hint)
        continuity_bonus = _INITIATIVE_CONTINUITY_BONUS.get(initiative, 0.0)
        note_bonus = _continuity_note_bonus(continuity_notes)
        note_factors = _continuity_note_factors(continuity_notes)

        for goal in graph.nodes:
            if goal.status in {"completed", "done", "failed", "dropped", "deferred"}:
                continue

            dependencies_ready = _dependencies_satisfied(goal, indexed)
            priority_score = _PRIORITY_POINTS[goal.priority]
            status_score = _STATUS_POINTS[goal.status]
            deadline_score = _deadline_score(goal.deadline, current)
            time_sensitivity_score = _TIME_SENSITIVITY_POINTS[goal.time_sensitivity]
            dependency_score = 0.6 if dependencies_ready else -1.0
            resume_score = 1.0 if temporal.resumed and goal.goal_id == temporal.active_goal_id else 0.0
            continuity_score = _continuity_score(goal, graph, temporal)
            if mode == "proactive" and goal.goal_id == temporal.active_goal_id:
                continuity_score = round(continuity_score + continuity_bonus, 3)
                if note_bonus > 0:
                    continuity_score = round(continuity_score + note_bonus, 3)
            if execution_tracker and goal.goal_id in execution_tracker.in_flight_goal_ids:
                resume_score += 0.7
            tracker_score = 0.5 if execution_tracker and goal.goal_id in execution_tracker.retry_goal_ids else 0.0
            evidence_score = 0.2 * len(goal.evidence_refs) + 0.15 * len(goal.related_memory_ids)
            repair_score = _repair_score(goal, temporal)
            staleness_score = _staleness_score(goal, temporal, current)

            score = (
                priority_score
                + status_score
                + deadline_score
                + time_sensitivity_score
                + dependency_score
                + resume_score
                + continuity_score
                + tracker_score
                + evidence_score
                + repair_score
                + staleness_score
            )

            kind = _kind_for_goal(goal, temporal, execution_tracker)
            rationale, factors = _rationale_for(goal, temporal, kind, execution_tracker, now=current)
            if mode == "proactive" and goal.goal_id == temporal.active_goal_id and note_factors:
                factors = tuple((*factors, *note_factors))
            confidence = min(0.99, max(0.1, 0.2 + (priority_score / 5.0) + max(0.0, deadline_score)))
            if memories:
                confidence = min(0.99, confidence + min(0.1, 0.02 * len(memories)))

            candidates.append(
                CandidateMove(
                    move_id=f"move:{session.session_id}:{goal.goal_id}",
                    kind=kind,
                    goal_id=goal.goal_id,
                    title=goal.title,
                    score=round(score, 3),
                    priority_score=priority_score,
                    status_score=status_score,
                    deadline_score=deadline_score,
                    time_sensitivity_score=time_sensitivity_score,
                    dependency_score=dependency_score,
                    resume_score=resume_score,
                    continuity_score=continuity_score,
                    tracker_score=tracker_score,
                    evidence_score=evidence_score,
                    repair_score=repair_score,
                    rationale=rationale,
                    rationale_factors=factors,
                    dependency_refs=goal.dependency_refs,
                    evidence_refs=goal.evidence_refs,
                    confidence=round(confidence, 3),
                )
            )

        if not candidates:
            candidates.append(
                CandidateMove(
                    move_id=f"move:{session.session_id}:defer",
                    kind="defer_or_schedule",
                    goal_id=None,
                    title="Defer and schedule follow-up",
                    score=0.0,
                    priority_score=0.0,
                    status_score=0.0,
                    deadline_score=0.0,
                    time_sensitivity_score=0.0,
                    dependency_score=0.0,
                    resume_score=0.0,
                    continuity_score=0.0,
                    tracker_score=0.0,
                    evidence_score=0.0,
                    repair_score=0.0,
                    rationale="No actionable goals were available, so the planner should defer and schedule a follow-up.",
                    rationale_factors=(),
                    confidence=0.2,
                )
            )

        return tuple(sorted(candidates, key=lambda candidate: candidate.score, reverse=True))

    def choose_next_step(
        self,
        *,
        session: SessionState,
        graph: GoalGraph | WorkGraph,
        memories: tuple[MemoryRecord, ...] = (),
        execution_tracker: ExecutionTracker | None = None,
        mode: PlanningMode = "guided",
        initiative_hint: str | None = None,
        continuity_notes: tuple[str, ...] = (),
        now: datetime | None = None,
    ) -> PlanningDecision:
        graph = work_graph_to_goal_graph(graph)
        current = _now() if now is None else now
        initiative = _normalize_initiative(initiative_hint)
        continuity_bonus = _INITIATIVE_CONTINUITY_BONUS.get(initiative, 0.0)
        candidates = self.score_candidates(
            session=session,
            graph=graph,
            memories=memories,
            execution_tracker=execution_tracker,
            initiative_hint=initiative,
            continuity_notes=continuity_notes,
            mode=mode,
            now=current,
        )
        selected = candidates[0]
        temporal = self._reasoner.analyze(session, graph, now=current)
        selected_goal = graph.goal(selected.goal_id) if selected.goal_id is not None else None
        progression_action = _progression_action_for(selected.kind)
        planned_status, planned_active_goal_id = _planned_progression(graph, selected_goal, selected.kind)
        factors: list[str] = [
            f"mode={mode}",
            f"selected={selected.kind}",
            f"priority={selected.priority_score:.1f}",
            f"status={selected.status_score:.1f}",
            f"candidate-count={len(candidates)}",
        ]
        factors.extend(selected.rationale_factors)
        if temporal.resumed:
            factors.append("resumed-session")
        if selected.resume_score > 0:
            factors.append("resume-weighted")
        if selected.continuity_score > 0:
            factors.append("continuity-weighted")
        if selected_goal is not None and _staleness_score(selected_goal, temporal, current) > 0:
            factors.append("stale-goal-pressure")
        if selected.repair_score > 0:
            factors.append("repair-weighted")
        if mode == "proactive":
            factors.append("wake-loop")
            if temporal.resumed:
                factors.append("proactive-resume")
            factors.append(f"initiative={initiative}")
            factors.extend(_continuity_note_factors(continuity_notes))
            if continuity_bonus != 0:
                factors.append("initiative-weighted")
            if _continuity_note_bonus(continuity_notes) > 0:
                factors.append("continuity-notes-weighted")
        if selected.deadline_score > 0:
            factors.append("deadline-pressure")
        if selected.time_sensitivity_score > 0:
            factors.append("time-sensitive")
        if selected.dependency_score < 0:
            factors.append("dependency-blocked")
        if selected.evidence_refs:
            factors.append("durable-evidence")
        if selected_goal is not None:
            factors.append(f"selected-goal-status={selected_goal.status}")
            factors.append(f"selected-goal-priority={selected_goal.priority}")
        if temporal.blocked_active_goal_id is not None:
            factors.append(f"blocked-active-goal={temporal.blocked_active_goal_id}")
        factors.append(f"progression={progression_action}")
        factors.append(f"planned-active-goal={planned_active_goal_id or '<none>'}")

        rationale = PlanningRationale(
            summary=f"{selected.rationale} {_progression_sentence(selected_goal, action=progression_action, planned_status=planned_status, planned_active_goal_id=planned_active_goal_id)}",
            factors=tuple(dict.fromkeys(factors)),
            candidate_ids=tuple(candidate.move_id for candidate in candidates),
            selected_move_id=selected.move_id,
            selected_goal_id=selected.goal_id,
            selected_goal_status=selected_goal.status if selected_goal is not None else None,
            selected_goal_priority=selected_goal.priority if selected_goal is not None else None,
            progression_action=progression_action,
            active_goal_id_before=graph.active_goal_id,
            planned_active_goal_id=planned_active_goal_id,
            mode=mode,
        )
        return PlanningDecision(
            decision_id=f"decision:{session.session_id}:{selected.goal_id or 'defer'}",
            session_id=session.session_id,
            mode=mode,
            selected_move=selected,
            rationale=rationale,
            candidates=candidates,
            temporal_context=temporal,
            goal_graph_revision=graph.updated_at,
        )

    def wake_next_step(
        self,
        *,
        session: SessionState,
        graph: GoalGraph | WorkGraph,
        memories: tuple[MemoryRecord, ...] = (),
        execution_tracker: ExecutionTracker | None = None,
        initiative_hint: str | None = None,
        continuity_notes: tuple[str, ...] = (),
        now: datetime | None = None,
    ) -> tuple[PlanningDecision, GoalGraph]:
        graph = work_graph_to_goal_graph(graph)
        decision = self.choose_next_step(
            session=session,
            graph=graph,
            memories=memories,
            execution_tracker=execution_tracker,
            mode="proactive",
            initiative_hint=initiative_hint,
            continuity_notes=continuity_notes,
            now=now,
        )
        return decision, apply_decision_to_goal_graph(graph, decision, updated_at=decision.selected_at)

    def emit_rationale(self, decision: PlanningDecision) -> EventEnvelope:
        payload = {
            "decision_id": decision.decision_id,
            "mode": decision.mode,
            "selected_move_id": decision.selected_move.move_id,
            "selected_goal_id": decision.selected_move.goal_id or "",
            "selected_kind": decision.selected_move.kind,
            "progression_action": decision.rationale.progression_action,
            "planned_active_goal_id": decision.rationale.planned_active_goal_id or "",
            "summary": decision.rationale.summary,
            "factors": _stringify(decision.rationale.factors),
            "candidate_ids": _stringify(decision.rationale.candidate_ids),
            "score": f"{decision.selected_move.score:.3f}",
            "resumed": str(decision.temporal_context.resumed),
        }
        return EventEnvelope(
            event_id=f"event:{decision.decision_id}:rationale",
            event_type="planning.rationale.emitted",
            session_id=decision.session_id,
            source="packages.planning",
            payload=payload,
        )


def build_plan_draft_from_decision(decision: PlanningDecision) -> PlanDraft | None:
    """Convert a planning decision into a thin plan draft."""

    selected_goal_id = decision.selected_move.goal_id
    if selected_goal_id is None:
        return None

    return PlanDraft(
        plan_id=f"plan:{decision.decision_id}",
        goal_id=selected_goal_id,
        session_id=decision.session_id,
        steps=(
            PlanStep(
                step_id=f"step:{decision.decision_id}:1",
                title=decision.selected_move.title,
                rationale=decision.rationale.summary,
                dependency_refs=decision.selected_move.dependency_refs,
            ),
        ),
        rationale=decision.rationale.summary,
    )


def apply_decision_to_goal_graph(
    graph: GoalGraph,
    decision: PlanningDecision,
    *,
    updated_at: datetime | None = None,
) -> GoalGraph:
    """Persist the planning choice back into the legacy goal-graph adapter."""

    selected_goal_id = decision.selected_move.goal_id
    if selected_goal_id is None:
        return graph

    goal = graph.goal(selected_goal_id)
    if goal is None:
        return graph

    next_status, next_active_goal_id = _planned_progression(graph, goal, decision.selected_move.kind)
    if next_status is None:
        return graph

    timestamp = decision.selected_at if updated_at is None else updated_at
    return graph.transition_goal(
        selected_goal_id,
        status=next_status,
        revision_id=decision.decision_id,
        updated_at=timestamp,
        active_goal_id=next_active_goal_id,
    )


def apply_decision_to_work_graph(
    graph: GoalGraph | WorkGraph,
    decision: PlanningDecision,
    *,
    updated_at: datetime | None = None,
) -> WorkGraph:
    """Persist the planning choice back into the canonical work graph."""

    goal_graph = work_graph_to_goal_graph(graph)
    next_graph = apply_decision_to_goal_graph(goal_graph, decision, updated_at=updated_at)
    return goal_graph_to_work_graph(next_graph)
