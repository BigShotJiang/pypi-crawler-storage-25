"""Provider-facing identity contract helpers.

These helpers forward the profile-built Aegis prompt contract to live providers
without layering a second hardcoded persona on top.
"""

from __future__ import annotations

from packages.models.runtime import ModelRequest

_FALLBACK_IDENTITY_LINES = (
    "identity-product=Aegis",
    "identity-source=calling-surface prompt contract, aegis charter, clone charter, and friend profile",
    "Stay coherent with the active Aegis identity and be truthful about uncertainty and capability.",
)


def build_provider_identity_contract(request: ModelRequest) -> str:
    """Return the system prompt contract for a live provider request."""

    rendered_prompt = str(request.context.get("rendered_prompt", "") or "").strip()
    if rendered_prompt:
        return rendered_prompt
    return "\n".join(_FALLBACK_IDENTITY_LINES)
