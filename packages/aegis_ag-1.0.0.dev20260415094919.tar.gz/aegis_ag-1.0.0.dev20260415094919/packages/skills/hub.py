"""Searchable skill-package discovery for local Aegis installs."""

from __future__ import annotations

from dataclasses import dataclass, field
import os
from pathlib import Path
import re
from typing import Any, Mapping

from packages.runtime_layout import (
    default_authored_skills_dir,
    default_installed_skills_dir,
)

from .runtime import SkillDefinition, load_skill_package_definition


@dataclass(frozen=True, slots=True)
class SkillHubEntry:
    skill_id: str
    display_name: str
    summary: str
    source_id: str
    source_label: str
    skill_path: str
    entry_path: str
    provenance: str
    metadata: Mapping[str, Any] = field(default_factory=dict)

    @property
    def reference(self) -> str:
        return f"{self.source_id}:{self.skill_id}"


@dataclass(frozen=True, slots=True)
class SkillHubSource:
    source_id: str
    label: str
    root: Path


class SkillHub:
    """Search local skill shelves and resolve installable skill packages."""

    def __init__(self, sources: tuple[SkillHubSource, ...] | None = None) -> None:
        self._sources = sources or default_skill_hub_sources()

    @property
    def sources(self) -> tuple[SkillHubSource, ...]:
        return self._sources

    def list(self) -> tuple[SkillHubEntry, ...]:
        entries: list[SkillHubEntry] = []
        for source in self._sources:
            if not source.root.exists():
                continue
            for skill_md in source.root.rglob("SKILL.md"):
                if ".git" in skill_md.parts:
                    continue
                if "__pycache__" in skill_md.parts:
                    continue
                try:
                    definition = load_skill_package_definition(skill_md)
                except Exception:
                    continue
                entries.append(_entry_from_definition(definition, source=source))
        entries.sort(key=lambda item: (item.source_label.lower(), item.display_name.lower(), item.skill_id))
        return tuple(entries)

    def search(self, query: str, *, limit: int = 12) -> tuple[SkillHubEntry, ...]:
        tokens = tuple(token for token in _normalize_query(query).split() if token)
        if not tokens:
            return self.list()[:limit]
        scored: list[tuple[int, str, SkillHubEntry]] = []
        for entry in self.list():
            haystack = " ".join(
                (
                    entry.skill_id,
                    entry.reference,
                    entry.display_name,
                    entry.summary,
                    str(entry.metadata.get("source_kind") or ""),
                    str(entry.metadata.get("storage_tier") or ""),
                )
            ).lower()
            if not all(token in haystack for token in tokens):
                continue
            score = 0
            if _normalize_query(entry.skill_id) == " ".join(tokens):
                score += 6
            if _normalize_query(entry.display_name) == " ".join(tokens):
                score += 5
            if all(token in _normalize_query(entry.display_name) for token in tokens):
                score += 3
            if all(token in _normalize_query(entry.summary) for token in tokens):
                score += 1
            scored.append((score, entry.reference, entry))
        scored.sort(key=lambda item: (-item[0], item[1]))
        return tuple(item[2] for item in scored[:limit])

    def resolve(self, reference: str) -> SkillHubEntry | None:
        candidate = reference.strip()
        if not candidate:
            return None
        path_candidate = Path(candidate).expanduser()
        if path_candidate.exists():
            definition = load_skill_package_definition(path_candidate)
            return _entry_from_definition(
                definition,
                source=SkillHubSource(
                    source_id="path",
                    label="Path",
                    root=path_candidate.resolve().parent if path_candidate.is_file() else path_candidate.resolve(),
                ),
            )
        lowered = candidate.lower()
        for entry in self.list():
            if lowered in {
                entry.reference.lower(),
                entry.skill_id.lower(),
                entry.display_name.lower(),
            }:
                return entry
        return None


def default_skill_hub_sources() -> tuple[SkillHubSource, ...]:
    configured = os.environ.get("AEGIS_SKILL_PATHS", "").strip()
    if configured:
        sources: list[SkillHubSource] = []
        for index, raw_path in enumerate(configured.split(os.pathsep)):
            path = Path(raw_path).expanduser()
            if not raw_path.strip():
                continue
            sources.append(
                SkillHubSource(
                    source_id=f"custom-{index + 1}",
                    label=path.name or f"custom-{index + 1}",
                    root=path,
                )
            )
        return _prepend_builtin_source(_append_aegis_skill_sources(tuple(sources)))

    home = Path.home()
    candidates = (
        SkillHubSource("builtin", "Built In", builtin_aegis_skill_source_root()),
        SkillHubSource("aegis-installed", "Aegis Installed", default_aegis_skill_source_root()),
        SkillHubSource("aegis-authored", "Aegis Authored", default_authored_aegis_skill_source_root()),
        SkillHubSource("codex", "Codex", home / ".codex" / "skills"),
        SkillHubSource("agents", "Agents", home / ".agents" / "skills"),
        SkillHubSource("orchestra", "Orchestra", home / ".orchestra" / "skills"),
        SkillHubSource("skills", "Skills", home / "skills"),
        SkillHubSource("local-workbench", "Local Workbench", home / "local-workbench" / "skills"),
    )
    return tuple(source for source in candidates if source.root.exists())


def default_aegis_skill_source_root() -> Path:
    return default_installed_aegis_skill_source_root()


def default_installed_aegis_skill_source_root() -> Path:
    return default_installed_skills_dir()


def default_authored_aegis_skill_source_root() -> Path:
    return default_authored_skills_dir()


def builtin_aegis_skill_source_root() -> Path:
    return Path(__file__).resolve().parent / "builtin_packages"


def _append_aegis_skill_sources(sources: tuple[SkillHubSource, ...]) -> tuple[SkillHubSource, ...]:
    resolved = list(sources)
    existing_roots = {source.root.expanduser().resolve() for source in sources}
    aegis_sources = (
        SkillHubSource("aegis-installed", "Aegis Installed", default_installed_aegis_skill_source_root()),
        SkillHubSource("aegis-authored", "Aegis Authored", default_authored_aegis_skill_source_root()),
    )
    for source in aegis_sources:
        root = source.root.expanduser().resolve()
        if root in existing_roots:
            continue
        resolved.append(source)
        existing_roots.add(root)
    return tuple(source for source in resolved if source.root.exists())


def _prepend_builtin_source(sources: tuple[SkillHubSource, ...]) -> tuple[SkillHubSource, ...]:
    builtin_root = builtin_aegis_skill_source_root()
    resolved = [source for source in sources if source.root.exists()]
    if not builtin_root.exists():
        return tuple(resolved)
    builtin_resolved = builtin_root.expanduser().resolve()
    existing_roots = {source.root.expanduser().resolve() for source in resolved}
    if builtin_resolved not in existing_roots:
        resolved.insert(0, SkillHubSource("builtin", "Built In", builtin_root))
    return tuple(resolved)


def _entry_from_definition(definition: SkillDefinition, *, source: SkillHubSource) -> SkillHubEntry:
    entry_path = Path(definition.entry_path or definition.provenance or "").expanduser()
    skill_path = entry_path.parent if entry_path.name == "SKILL.md" else entry_path
    metadata = dict(definition.metadata)
    metadata.setdefault("source_kind", "skill-package")
    try:
        relative_parts = skill_path.relative_to(source.root).parts
    except ValueError:
        relative_parts = ()
    category = "/".join(relative_parts[:-1]).strip("/") if len(relative_parts) > 1 else ""
    if category:
        metadata.setdefault("category", category)
    metadata.setdefault("slash_command", _skill_command_slug(definition.skill_id or definition.display_name))
    metadata.setdefault("storage_tier", _storage_tier_for_source(source.source_id))
    return SkillHubEntry(
        skill_id=definition.skill_id,
        display_name=definition.display_name,
        summary=definition.summary,
        source_id=source.source_id,
        source_label=source.label,
        skill_path=str(skill_path),
        entry_path=str(entry_path),
        provenance=definition.provenance,
        metadata=metadata,
    )


def _normalize_query(value: str) -> str:
    return " ".join(value.lower().replace("-", " ").replace("_", " ").split())


def _skill_command_slug(value: str) -> str:
    slug = re.sub(r"[^a-z0-9-]+", "-", value.lower().replace("_", "-").replace(" ", "-"))
    slug = re.sub(r"-{2,}", "-", slug).strip("-")
    return slug


def _storage_tier_for_source(source_id: str) -> str:
    if source_id == "builtin":
        return "builtin"
    if source_id == "aegis-installed":
        return "installed"
    if source_id == "aegis-authored":
        return "authored"
    return "external"
