"""Built-in skill definitions for Aegis product surfaces."""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import replace

from .runtime import SkillDefinition, SkillScope


def builtin_skill_definitions(enabled_overrides: Mapping[str, bool]) -> tuple[SkillDefinition, ...]:
    definitions = (
        SkillDefinition(
            skill_id="skill.shell.execution",
            display_name="Shell Execution",
            version="1.0.0",
            summary="Keeps explicit shell work legible, bounded, and attached to the current workspace thread.",
            scope=SkillScope(modes=("default", "companion")),
            provenance="packages/skills",
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        SkillDefinition(
            skill_id="skill.workspace.search",
            display_name="Workspace Search",
            version="1.0.0",
            summary="Keeps local retrieval, file search, and nearby context gathering available in-session.",
            scope=SkillScope(modes=("default", "companion")),
            provenance="packages/skills",
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        SkillDefinition(
            skill_id="skill.web.search",
            display_name="Web Search",
            version="1.0.0",
            summary="Keeps lightweight public-web discovery available for prompts, cron jobs, and follow-up research.",
            scope=SkillScope(modes=("default", "companion")),
            provenance="packages/skills",
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        SkillDefinition(
            skill_id="skill.web.read",
            display_name="Web Read",
            version="1.0.0",
            summary="Keeps direct URL reading and text extraction available when a specific page matters more than search results.",
            scope=SkillScope(modes=("default", "companion")),
            provenance="packages/skills",
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        SkillDefinition(
            skill_id="skill.cron.scheduling",
            display_name="Cron Scheduling",
            version="1.0.0",
            summary="Keeps recurring greetings, web checks, and other scheduled follow-ups durable and inspectable.",
            scope=SkillScope(modes=("default", "companion")),
            provenance="packages/skills",
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        SkillDefinition(
            skill_id="skill.direct-shell.recovery",
            display_name="Direct Shell Recovery",
            version="1.0.0",
            summary="Keeps first-run, health, resume, and recovery guidance aligned with the direct shell.",
            scope=SkillScope(modes=("default", "companion")),
            provenance="packages/skills",
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        SkillDefinition(
            skill_id="skill.personal-ai.continuity",
            display_name="Personal AI Continuity",
            version="1.0.0",
            summary="Applies profile-aware continuity heuristics for durable personal AI sessions.",
            scope=SkillScope(modes=("default", "companion")),
            provenance="packages/skills",
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        SkillDefinition(
            skill_id="skill.friend-clone.governance",
            display_name="Friend And Clone Governance",
            version="1.0.0",
            summary="Keeps shared user truth, clone self-state, and relationship continuity updates explicit, durable, and scoped.",
            scope=SkillScope(modes=("default", "companion")),
            provenance="packages/skills",
            instruction_text=(
                "Treat AEGIS.md as immutable and shared across every clone. "
                "Use tool.user.manage for stable user facts, preferences, boundaries, and recurring cross-clone context; use tool.identity.manage when the user explicitly redefines this clone's voice, stance, working style, preset, or initiative; and use tool.relationship.manage for clone-local collaboration rhythm, continuity notes, and relationship expectations. "
                "Do not store transient tasks, one-off requests, scratch notes, or generic chat in durable self/user/relationship state. "
                "When the user corrects or adds durable facts, update the current shared user state proactively instead of waiting for a separate remember command."
            ),
            metadata={"surface": "cli", "kind": "built-in"},
        ),
        SkillDefinition(
            skill_id="skill.voice.reply",
            display_name="Voice Reply",
            version="1.0.0",
            summary="Enables voice reply guidance once provider-backed voice paths are ready.",
            scope=SkillScope(modes=("default", "companion")),
            provenance="packages/skills",
            metadata={"surface": "cli", "kind": "built-in"},
        ),
    )
    return tuple(
        replace(definition, enabled=enabled_overrides.get(definition.skill_id, definition.enabled))
        for definition in definitions
    )
