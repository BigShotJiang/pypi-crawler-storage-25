"""Explainable evidence retrieval helpers for Aegis."""

from .inventory import EVIDENCE_SURFACES
from .runtime import (
    MMBERT_EMBEDDING_DIMENSIONS,
    MMBERT_EMBEDDING_MODEL_ID,
    DefaultEvidenceRetriever,
    build_embedding_index_policy,
    build_resume_packet,
)

__all__ = [
    "DefaultEvidenceRetriever",
    "EVIDENCE_SURFACES",
    "MMBERT_EMBEDDING_DIMENSIONS",
    "MMBERT_EMBEDDING_MODEL_ID",
    "build_embedding_index_policy",
    "build_resume_packet",
]
