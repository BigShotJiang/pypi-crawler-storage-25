"""Explainable evidence retrieval and wake-recovery helpers."""

from __future__ import annotations

import hashlib
import math
import re
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import TYPE_CHECKING

from packages.contracts.runtime import (
    EmbeddingIndexPolicy,
    EvidenceCandidate,
    EvidenceRetrievalRequest,
    EvidenceRetrievalResult,
    MemoryRecord,
    RecallReason,
    RecallReasons,
    ResumePacket,
)
from packages.storage import RuntimeStorageRepository

if TYPE_CHECKING:
    from packages.memory.runtime import MemoryStore


MMBERT_EMBEDDING_MODEL_ID = "mmbert-embed-32k-2d-matryoshka"
MMBERT_EMBEDDING_DIMENSIONS = (64, 256, 768)
_LEXICAL_INDEX_VERSION = "fts5-memory-v1"
_EMBEDDING_INDEX_VERSION = f"{MMBERT_EMBEDDING_MODEL_ID}@2026-04"
_CONTINUITY_QUERY_TOKENS = frozenset(
    {
        "continue",
        "continuity",
        "handoff",
        "left",
        "next",
        "pick",
        "recover",
        "recovery",
        "resume",
        "resumed",
        "step",
        "where",
    }
)


def _now() -> datetime:
    return datetime.now(timezone.utc)


def _tokenize(text: str) -> set[str]:
    return {token for token in re.findall(r"[A-Za-z0-9_]+", text.lower()) if token}


def _stable_hash(value: str) -> int:
    return int(hashlib.sha256(value.encode("utf-8")).hexdigest()[:16], 16)


def _unit_projection(text: str, *, dims: int) -> tuple[float, ...]:
    vector = [0.0] * dims
    for token in sorted(_tokenize(text)):
        hashed = _stable_hash(f"{MMBERT_EMBEDDING_MODEL_ID}:{dims}:{token}")
        bucket = hashed % dims
        sign = -1.0 if hashed % 2 else 1.0
        magnitude = 1.0 + float(len(token)) / 12.0
        vector[bucket] += sign * magnitude
    norm = math.sqrt(sum(component * component for component in vector))
    if norm == 0.0:
        return tuple(0.0 for _ in vector)
    return tuple(component / norm for component in vector)


def _cosine_similarity(left: tuple[float, ...], right: tuple[float, ...]) -> float:
    if not left or not right or len(left) != len(right):
        return 0.0
    return sum(a * b for a, b in zip(left, right, strict=False))


def _vector_dims_for_mode(latency_mode: str) -> int:
    normalized = latency_mode.strip().lower()
    if normalized in {"fast", "low-latency", "64d"}:
        return 64
    if normalized in {"deep", "offline", "768d"}:
        return 768
    return 256


def _embedding_mode(latency_mode: str) -> str:
    dims = _vector_dims_for_mode(latency_mode)
    return f"{MMBERT_EMBEDDING_MODEL_ID}:{dims}d"


def _query_session_ids(
    repository: RuntimeStorageRepository,
    *,
    profile_id: str | None = None,
    workspace_id: str | None = None,
) -> tuple[str, ...]:
    clauses: list[str] = []
    params: list[str] = []
    if profile_id:
        clauses.append("profile_id = ?")
        params.append(profile_id)
    if workspace_id:
        clauses.append("workspace_id = ?")
        params.append(workspace_id)
    if not clauses:
        return ()
    where_sql = " AND ".join(clauses)
    with repository.connection() as connection:
        rows = connection.execute(
            f"""
            SELECT session_id
            FROM sessions
            WHERE {where_sql}
            ORDER BY updated_at DESC, started_at DESC, session_id DESC
            """,
            tuple(params),
        ).fetchall()
    return tuple(dict.fromkeys(str(row["session_id"]) for row in rows))


@dataclass(frozen=True, slots=True)
class _ResolvedScope:
    session_ids: tuple[str, ...]
    opened_scopes: tuple[str, ...]
    scope_reason: str
    lineage_session_ids: tuple[str, ...]
    workspace_session_ids: tuple[str, ...]
    profile_session_ids: tuple[str, ...]


class DefaultEvidenceRetriever:
    def __init__(self, store: "MemoryStore", repository: RuntimeStorageRepository | None = None) -> None:
        self.store = store
        self.repository = repository

    def retrieve(self, request: EvidenceRetrievalRequest) -> EvidenceRetrievalResult:
        resolved_scope = self._resolve_scope(request)
        scope_set = set(resolved_scope.session_ids)
        dims = _vector_dims_for_mode(request.latency_mode)
        query_tokens = _tokenize(request.query)
        query_vector = _unit_projection(request.query, dims=dims)
        candidates: list[EvidenceCandidate] = []
        for record in self.store.list(include_inactive=request.include_inactive):
            if record.session_id not in scope_set:
                continue
            candidate = self._candidate_for_record(
                request,
                record,
                resolved_scope=resolved_scope,
                query_tokens=query_tokens,
                query_vector=query_vector,
                dims=dims,
            )
            if candidate is not None:
                candidates.append(candidate)
        candidates.sort(
            key=lambda item: (
                -item.score,
                -(
                    item.memory.created_at.timestamp()
                    if item.memory.created_at is not None
                    else 0.0
                ),
                item.evidence_id,
            )
        )
        selected = tuple(candidates[: request.limit])
        recall_reasons = RecallReasons(
            opened_scopes=resolved_scope.opened_scopes,
            evidence_ids=tuple(candidate.evidence_id for candidate in selected),
            scope_reason=resolved_scope.scope_reason,
            rerank_summary=self._rerank_summary(selected),
            reasons=tuple(reason for candidate in selected for reason in candidate.reasons[:3]),
        )
        return EvidenceRetrievalResult(
            request=request,
            scope_session_ids=resolved_scope.session_ids,
            scope_reason=resolved_scope.scope_reason,
            candidates=selected,
            recall_reasons=recall_reasons,
            index_policy=build_embedding_index_policy(self.store),
        )

    def _resolve_scope(self, request: EvidenceRetrievalRequest) -> _ResolvedScope:
        requested_scopes = tuple(dict.fromkeys(scope for scope in request.scopes if scope)) or ("session",)
        session_ids: list[str] = [request.session_id]
        opened_scopes: list[str] = []

        lineage_session_ids = tuple(
            dict.fromkeys(
                request.lineage_session_ids
                or self._lineage_session_ids(request.session_id)
            )
        )
        workspace_session_ids = (
            _query_session_ids(self.repository, workspace_id=request.workspace_id)
            if self.repository is not None and request.workspace_id is not None and "workspace" in requested_scopes
            else ()
        )
        profile_session_ids = (
            _query_session_ids(self.repository, profile_id=request.profile_id)
            if self.repository is not None and request.profile_id and "profile" in requested_scopes
            else ()
        )

        for scope in requested_scopes:
            if scope == "turn":
                opened_scopes.append("turn")
            elif scope == "session":
                opened_scopes.append("session")
            elif scope == "lineage":
                opened_scopes.append("lineage")
                session_ids.extend(lineage_session_ids)
            elif scope == "workspace" and workspace_session_ids:
                opened_scopes.append("workspace")
                session_ids.extend(workspace_session_ids)
            elif scope == "profile" and profile_session_ids:
                opened_scopes.append("profile")
                session_ids.extend(profile_session_ids)

        resolved_session_ids = tuple(dict.fromkeys(session_ids))
        explicit_reason = request.scope_reason.strip()
        if explicit_reason:
            scope_reason = explicit_reason
        else:
            scope_reason = self._default_scope_reason(
                request,
                opened_scopes=tuple(opened_scopes),
                resolved_session_ids=resolved_session_ids,
            )
        return _ResolvedScope(
            session_ids=resolved_session_ids,
            opened_scopes=tuple(opened_scopes) or ("session",),
            scope_reason=scope_reason,
            lineage_session_ids=lineage_session_ids,
            workspace_session_ids=workspace_session_ids,
            profile_session_ids=profile_session_ids,
        )

    def _lineage_session_ids(self, session_id: str) -> tuple[str, ...]:
        if self.repository is None:
            return (session_id,)
        lineage = self.repository.lineage(session_id)
        if not lineage:
            return (session_id,)
        return tuple(dict.fromkeys(state.session_id for state in lineage))

    def _default_scope_reason(
        self,
        request: EvidenceRetrievalRequest,
        *,
        opened_scopes: tuple[str, ...],
        resolved_session_ids: tuple[str, ...],
    ) -> str:
        reasons: list[str] = []
        if "lineage" in opened_scopes and len(resolved_session_ids) > 1:
            reasons.append("resume recovery expands recall across the durable session lineage")
        else:
            reasons.append("recovery stays inside the active session scope")
        if request.work_item_ids:
            reasons.append(f"active work {', '.join(request.work_item_ids[:2])} outranks generic recall")
        if request.relationship_hints:
            reasons.append("relationship continuity stays explicit during rerank")
        if "workspace" in opened_scopes:
            reasons.append("workspace scope opened because the active clone spans multiple sessions")
        if "profile" in opened_scopes:
            reasons.append("profile scope opened to preserve long-horizon continuity beyond one workspace")
        return "; ".join(reasons)

    def _candidate_for_record(
        self,
        request: EvidenceRetrievalRequest,
        record: MemoryRecord,
        *,
        resolved_scope: _ResolvedScope,
        query_tokens: set[str],
        query_vector: tuple[float, ...],
        dims: int,
    ) -> EvidenceCandidate | None:
        reasons: list[RecallReason] = []
        matched_scopes = self._matched_scopes(record, resolved_scope=resolved_scope)
        scope_score = 0.0
        if record.session_id == request.session_id:
            scope_score += 2.5
            reasons.append(RecallReason("scope.session", "current-session scope", 2.5))
        elif record.session_id in set(resolved_scope.lineage_session_ids):
            scope_score += 1.5
            reasons.append(RecallReason("scope.lineage", "recovery-scope session", 1.5))
        elif record.session_id in set(resolved_scope.workspace_session_ids):
            scope_score += 1.0
            reasons.append(RecallReason("scope.workspace", "workspace continuity scope", 1.0))
        elif record.session_id in set(resolved_scope.profile_session_ids):
            scope_score += 0.75
            reasons.append(RecallReason("scope.profile", "profile continuity scope", 0.75))

        content_tokens = _tokenize(record.content)
        overlap = sorted(query_tokens & content_tokens)
        lexical_score = float(len(overlap)) * 2.0
        if overlap:
            reasons.append(RecallReason("lexical.query", f"query overlap: {','.join(overlap)}", lexical_score))
        tag_tokens = _tokenize(" ".join(record.tags))
        tag_overlap = sorted(query_tokens & tag_tokens)
        if tag_overlap:
            tag_score = float(len(tag_overlap)) * 1.25
            lexical_score += tag_score
            reasons.append(RecallReason("lexical.tags", f"tag overlap: {','.join(tag_overlap)}", tag_score))
            novel_tag_overlap = tuple(token for token in tag_overlap if token not in overlap)
            if novel_tag_overlap:
                novel_tag_score = float(len(novel_tag_overlap)) * 0.75
                lexical_score += novel_tag_score
                reasons.append(
                    RecallReason(
                        "lexical.tags.novel",
                        f"novel tag overlap: {','.join(novel_tag_overlap)}",
                        novel_tag_score,
                    )
                )

        vector_score = max(0.0, _cosine_similarity(query_vector, _unit_projection(record.content, dims=dims))) * 3.0
        if vector_score > 0.0:
            reasons.append(
                RecallReason(
                    "vector.mmbert",
                    f"matryoshka vector similarity via {_embedding_mode(request.latency_mode)}",
                    vector_score,
                )
            )

        graph_score = 0.0
        goal_overlap = tuple(goal_id for goal_id in request.work_item_ids if goal_id in record.goal_refs)
        if goal_overlap:
            graph_score += float(len(goal_overlap)) * 3.5
            reasons.append(
                RecallReason(
                    "work.goal-overlap",
                    f"goal overlap: {','.join(goal_overlap)}",
                    graph_score,
                )
            )
        elif request.work_item_ids and not record.goal_refs:
            graph_score -= 0.5
            reasons.append(
                RecallReason(
                    "work.generic-penalty",
                    "generic recall deprioritized behind active work",
                    -0.5,
                )
            )

        relationship_score = 0.0
        relationship_tokens = _tokenize(" ".join(request.relationship_hints))
        relationship_overlap = sorted(relationship_tokens & (content_tokens | tag_tokens))
        if relationship_overlap:
            relationship_score += float(len(relationship_overlap)) * 0.8
            reasons.append(
                RecallReason(
                    "relationship.continuity",
                    f"relationship continuity overlap: {','.join(relationship_overlap)}",
                    relationship_score,
                )
            )

        continuity_score = 0.0
        if query_tokens & _CONTINUITY_QUERY_TOKENS:
            if record.kind in {"procedural", "semantic", "summary", "decision"}:
                continuity_score += 1.75
                reasons.append(
                    RecallReason(
                        "continuity.intent",
                        f"continuity intent prefers durable kind {record.kind}",
                        continuity_score,
                    )
                )
            if record.goal_refs:
                continuity_score += 0.4
                reasons.append(
                    RecallReason(
                        "continuity.goal-link",
                        "goal-linked continuity",
                        0.4,
                    )
                )
            continuity_tags = {"continuity", "handoff", "recovery", "resume", "scope-aware"}
            if continuity_tags & set(record.tags):
                continuity_score += 0.4
                reasons.append(
                    RecallReason(
                        "continuity.tags",
                        "continuity-tag boost",
                        0.4,
                    )
                )

        lifecycle_score = 0.0
        if "corrected" in record.tags:
            lifecycle_score += 1.4
            reasons.append(RecallReason("lifecycle.corrected", "corrected memory", 1.4))

        recency_score = 0.0
        if record.created_at is not None:
            age_seconds = max(0.0, (_now() - record.created_at).total_seconds())
            recency_score = max(0.0, 2.0 - (age_seconds / 86400.0))
            reasons.append(RecallReason("time.recency", "recency boost", recency_score))

        total_score = scope_score + lexical_score + vector_score + graph_score + relationship_score + continuity_score + lifecycle_score + recency_score
        if total_score <= 0.0 and not matched_scopes:
            return None
        return EvidenceCandidate(
            evidence_id=record.memory_id,
            memory=record,
            score=total_score,
            lexical_score=lexical_score,
            vector_score=vector_score,
            graph_score=graph_score + relationship_score + continuity_score,
            matched_scopes=matched_scopes,
            reasons=tuple(reasons),
            embedding_mode=_embedding_mode(request.latency_mode),
        )

    def _matched_scopes(self, record: MemoryRecord, *, resolved_scope: _ResolvedScope) -> tuple[str, ...]:
        scopes: list[str] = []
        if record.session_id in resolved_scope.session_ids:
            scopes.append("session")
        if record.session_id in resolved_scope.lineage_session_ids:
            scopes.append("lineage")
        if record.session_id in resolved_scope.workspace_session_ids:
            scopes.append("workspace")
        if record.session_id in resolved_scope.profile_session_ids:
            scopes.append("profile")
        return tuple(dict.fromkeys(scopes))

    def _rerank_summary(self, candidates: tuple[EvidenceCandidate, ...]) -> str:
        if not candidates:
            return "no evidence survived rerank"
        top = candidates[0]
        reasons = ", ".join(reason.code for reason in top.reasons[:4]) or "no explicit reasons"
        return f"top evidence {top.evidence_id} survived rerank via {reasons}"


def build_embedding_index_policy(store: "MemoryStore") -> EmbeddingIndexPolicy:
    invalidated: list[str] = []
    for record in store.list(include_inactive=True):
        state = store.state(record.memory_id)
        if state not in {None, "active"}:
            invalidated.append(record.memory_id)
    invalidation_reason = (
        "superseded, consolidated, and deleted evidence must invalidate derived lexical and vector views"
        if invalidated
        else "derived lexical and vector views are aligned with the active canonical evidence rows"
    )
    return EmbeddingIndexPolicy(
        model_id=MMBERT_EMBEDDING_MODEL_ID,
        lexical_index_version=_LEXICAL_INDEX_VERSION,
        embedding_index_version=_EMBEDDING_INDEX_VERSION,
        active_dimensions=MMBERT_EMBEDDING_DIMENSIONS,
        rebuild_required=bool(invalidated),
        invalidated_evidence_ids=tuple(dict.fromkeys(invalidated)),
        invalidation_reason=invalidation_reason,
    )


def build_resume_packet(
    request: EvidenceRetrievalRequest,
    retrieval: EvidenceRetrievalResult,
    *,
    next_move: str = "",
    artifact_ids: tuple[str, ...] = (),
    constraint_ids: tuple[str, ...] = (),
) -> ResumePacket:
    top = retrieval.candidates[0] if retrieval.candidates else None
    evidence_ids = tuple(candidate.evidence_id for candidate in retrieval.candidates)
    if not evidence_ids and artifact_ids:
        evidence_ids = artifact_ids

    focus_work_item_ids = request.work_item_ids
    reasons: list[str] = [retrieval.scope_reason]
    if top is not None:
        reasons.extend(reason.detail for reason in top.reasons[:3])
        focused_goal_ids = tuple(goal_id for goal_id in request.work_item_ids if goal_id in top.memory.goal_refs)
        if focused_goal_ids:
            focus_work_item_ids = focused_goal_ids
        summary = (
            f"Resume {request.session_id} around {', '.join(focus_work_item_ids[:2]) or 'the active thread'}; "
            f"lead with {top.evidence_id} because {', '.join(reason.detail for reason in top.reasons[:2])}."
        )
    elif evidence_ids:
        reasons.append("goal graph evidence fallback kept the wake packet inspectable")
        summary = (
            f"Resume {request.session_id} around {', '.join(request.work_item_ids[:2]) or 'the active thread'}; "
            f"lead with {evidence_ids[0]} because no durable memory survived rerank and the active work graph still carries explicit evidence refs."
        )
    else:
        summary = (
            f"Resume {request.session_id} with explicit scope reasoning only; "
            "no durable evidence survived rerank yet."
        )
    return ResumePacket(
        session_id=request.session_id,
        profile_id=request.profile_id,
        workspace_id=request.workspace_id,
        focus_work_item_ids=focus_work_item_ids,
        evidence_ids=evidence_ids,
        artifact_ids=artifact_ids,
        constraint_ids=constraint_ids,
        summary=summary,
        next_move=next_move,
        reasons=tuple(reason for reason in reasons if reason),
    )
