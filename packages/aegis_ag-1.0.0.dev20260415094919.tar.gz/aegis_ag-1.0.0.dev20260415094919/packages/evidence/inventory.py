"""Public inventory of evidence retrieval package surfaces."""

EVIDENCE_SURFACES = (
    "MMBERT_EMBEDDING_MODEL_ID",
    "MMBERT_EMBEDDING_DIMENSIONS",
    "DefaultEvidenceRetriever",
    "build_embedding_index_policy",
    "build_resume_packet",
)
