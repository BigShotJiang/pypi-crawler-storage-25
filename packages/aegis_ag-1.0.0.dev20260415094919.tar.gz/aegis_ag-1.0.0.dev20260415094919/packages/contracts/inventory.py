"""Public inventory of the shared runtime contract surface.

Keep this list stable so module teams can agree on the names they are building
against without reaching into implementation details.
"""

CONTRACT_SURFACES = (
    "ProfileState",
    "CloneIdentityRecord",
    "UserCardRecord",
    "RelationshipMemoryRecord",
    "ProfileGraph",
    "SessionState",
    "GoalNode",
    "WorkGraph",
    "MemoryRecord",
    "PatternCluster",
    "ProcedureCandidate",
    "VerificationBundle",
    "ArtifactRecord",
    "EvidenceGraph",
    "RecallReason",
    "RecallReasons",
    "EvidenceRetrievalRequest",
    "EvidenceCandidate",
    "EmbeddingIndexPolicy",
    "EvidenceRetrievalResult",
    "ResumePacket",
    "ProcedureStep",
    "ProcedureRecord",
    "ProcedureLibrary",
    "ContextBundle",
    "PlanStep",
    "PlanDraft",
    "ExecutionResult",
    "EventEnvelope",
)

