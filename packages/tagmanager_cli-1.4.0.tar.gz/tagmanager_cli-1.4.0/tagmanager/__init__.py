"""
TagManager - The Ultimate Command-Line File Tagging System

Transform chaos into order with intelligent file organization.
"""

__version__ = "1.3.1"
__author__ = "David Chincharashvili"
__email__ = "davidchincharashvili@gmail.com"
__description__ = "The Ultimate Command-Line File Tagging System"

from .cli import main

__all__ = ["main"]
