# Configuration management module
