"""DEPRECATED — `tokenpak maintenance` moved to tokenpak-paid (2026-04-21).

This module is a stub left behind by TPS-11. The real implementation
now lives in ``tokenpak_paid.commands._impls.maintenance`` and is
installed via:

    tokenpak activate YOUR-KEY
    tokenpak install-tier enterprise

Importing any callable from this stub and invoking it prints an
upgrade message and exits with status 2. Dynamic discovery
(``tokenpak.commands`` entry-points — TPS-01) routes ``tokenpak
maintenance`` to the real paid implementation when it is installed.
"""

from __future__ import annotations

import sys
import warnings as _warnings

_warnings.warn(
    "tokenpak.cli.commands.maintenance: implementation moved to "
    "tokenpak-paid (Enterprise+). Install with `tokenpak install-tier enterprise`. "
    "This OSS stub will be removed in tokenpak 2.0.",
    DeprecationWarning,
    stacklevel=2,
)


def _upgrade_stub(*args, **kwargs):
    """Upgrade-required stub left behind by TPS-11."""
    print(
        "⚠ The `tokenpak maintenance` command requires a Enterprise subscription.\n"
        "  Run: tokenpak activate <YOUR-KEY>\n"
        "  Then: tokenpak install-tier enterprise\n"
        "  (Don’t have a key? Visit tokenpak.ai/pricing.)",
        file=sys.stderr,
    )
    sys.exit(2)


# Preserve every public symbol external callers import from this module.
# Each one is aliased to _upgrade_stub so any invocation path ends in
# the same upgrade message.
maintenance_cmd = _upgrade_stub


__all__ = ["maintenance_cmd"]
