"""Deprecated re-export shim (TokenPak D1 migration 2026-04-20).

The canonical home of this module is ``tokenpak.proxy.capsule_builder``.
This shim exists for backwards compatibility and will be removed
in TIP-2.0.
"""
from __future__ import annotations

import warnings as _warnings

_warnings.warn(
    "tokenpak.agent.proxy.capsule_builder is a deprecated re-export; "
    "import from tokenpak.proxy.capsule_builder instead. "
    "This shim will be removed in TIP-2.0.",
    DeprecationWarning,
    stacklevel=2,
)

from tokenpak.proxy.capsule_builder import *  # noqa: F401,F403,E402

__all__ = ["CapsuleBuilder", "DEFAULT_HOT_WINDOW", "DEFAULT_MIN_BLOCK_CHARS", "make_capsule_builder"]
