"""Deprecated re-export shim (TokenPak D1 migration 2026-04-20).

The canonical home of this module is ``tokenpak.proxy.providers.google``.
This shim exists for backwards compatibility and will be removed
in TIP-2.0.
"""
from __future__ import annotations

import warnings as _warnings

_warnings.warn(
    "tokenpak.agent.proxy.providers.google is a deprecated re-export; "
    "import from tokenpak.proxy.providers.google instead. "
    "This shim will be removed in TIP-2.0.",
    DeprecationWarning,
    stacklevel=2,
)

from tokenpak.proxy.providers.google import *  # noqa: F401,F403,E402

__all__ = ["Any", "Dict", "GoogleContent", "GoogleFormat", "List", "Optional", "dataclass"]
