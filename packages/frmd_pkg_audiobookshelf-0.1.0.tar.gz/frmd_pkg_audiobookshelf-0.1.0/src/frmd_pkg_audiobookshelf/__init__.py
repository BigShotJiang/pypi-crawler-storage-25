def hello() -> str:
    return "Hello from frmd-pkg-audiobookshelf!"
