# PolicyAlertRule


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **datetime** | Time of record creation. | 
**updated_at** | **datetime** | Time of last record update. | 
**id** | **str** | The ID of the policy alert rule. | 
**policy_id** | **str** | The ID of the parent policy. | 
**name** | **str** | The name of the policy alert rule. | 
**description** | **str** |  | [optional] 
**threshold** | **float** | The threshold that will trigger the alert rule. | 
**bound** | [**AlertBound**](AlertBound.md) | The bound of the alert rule. | 
**query** | **str** | The SQL query for the alert rule. | 
**metric_name** | **str** | The name of the metric returned by the query. | 

## Example

```python
from arthur_client.api_bindings.models.policy_alert_rule import PolicyAlertRule

# TODO update the JSON string below
json = "{}"
# create an instance of PolicyAlertRule from a JSON string
policy_alert_rule_instance = PolicyAlertRule.from_json(json)
# print the JSON string representation of the object
print(PolicyAlertRule.to_json())

# convert the object into a dict
policy_alert_rule_dict = policy_alert_rule_instance.to_dict()
# create an instance of PolicyAlertRule from a dict
policy_alert_rule_from_dict = PolicyAlertRule.from_dict(policy_alert_rule_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


