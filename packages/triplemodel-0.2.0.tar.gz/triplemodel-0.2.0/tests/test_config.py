"""Tests for RDF configuration helpers."""

from __future__ import annotations

import pytest
from rdflib import URIRef

import triplemodel
from triplemodel import (
    TripleModel,
    id_from_subject_uri,
    rdf_field,
    subject_base,
)
from triplemodel.config import RdfConfig, get_rdf_config

EX = "http://example.org/people/"


def test_public_package_exports_subject_helpers():
    assert triplemodel.subject_base is subject_base
    assert triplemodel.id_from_subject_uri is id_from_subject_uri
    assert "subject_base" in triplemodel.__all__
    assert "id_from_subject_uri" in triplemodel.__all__
    assert "IriId" in triplemodel.__all__


def test_subject_base_adds_slash():
    assert subject_base("http://example.org/people") == "http://example.org/people/"
    assert subject_base("http://example.org/people#") == "http://example.org/people#"
    assert subject_base("http://example.org/people/") == "http://example.org/people/"


def test_id_from_subject_uri_roundtrip():
    ns = "http://example.org/people"
    assert id_from_subject_uri(ns, "http://example.org/people/alice") == "alice"
    assert id_from_subject_uri(ns, "http://other.example/alice") is None


def test_subject_uri_requires_id_field():
    cfg = RdfConfig(namespace=EX, type_uri="http://example.org/T", id_field=None)

    class Stub:
        slug = "alice"

    with pytest.raises(ValueError, match="id_field"):
        cfg.subject_uri(Stub())


def test_subject_uri_empty_id_field():
    cfg = RdfConfig(namespace=EX, type_uri="http://example.org/T", id_field="slug")

    class Stub:
        slug = ""

    with pytest.raises(ValueError, match="empty"):
        cfg.subject_uri(Stub())


def test_get_rdf_config_without_rdf_class():
    class Bare(TripleModel):
        label: str = rdf_field("http://example.org/label")

    cfg = get_rdf_config(Bare)
    assert cfg.namespace == ""
    assert cfg.type_uri is None
    assert cfg.id_field is None


def test_get_rdf_config_inherits_from_base():
    FOAF = "http://xmlns.com/foaf/0.1/"

    class Base(TripleModel):
        class Rdf:
            namespace = EX
            type_uri = f"{FOAF}Person"
            id_field = "slug"

    class Employee(Base):
        slug: str
        name: str = rdf_field(f"{FOAF}name")

    cfg = get_rdf_config(Employee)
    assert cfg.namespace == EX
    assert cfg.type_uri == f"{FOAF}Person"
    assert cfg.id_field == "slug"


def test_subject_uri_accepts_zero_and_false_id_values():
    FOAF = "http://xmlns.com/foaf/0.1/"

    class Counter(TripleModel):
        class Rdf:
            namespace = EX
            type_uri = f"{FOAF}Person"
            id_field = "slug"

        slug: int | bool
        name: str = rdf_field(f"{FOAF}name")

    zero = Counter(slug=0, name="Zero")
    assert zero.subject_uri().endswith("/0")
    assert Counter.from_graph(zero.to_graph(), zero.subject_uri()) == zero

    flag = Counter(slug=False, name="Flag")
    assert flag.subject_uri().endswith("/False")
    assert Counter.from_graph(flag.to_graph(), flag.subject_uri()) == flag


def test_falsy_type_uri_omits_rdf_type_on_export():
    class Untyped(TripleModel):
        class Rdf:
            namespace = EX
            type_uri = ""
            id_field = "slug"

        slug: str
        name: str = rdf_field("http://xmlns.com/foaf/0.1/name")

    g = Untyped(slug="a", name="A").to_graph()
    subj = URIRef(EX + "a")
    assert (
        list(g.objects(subj, URIRef("http://www.w3.org/1999/02/22-rdf-syntax-ns#type")))
        == []
    )


def test_id_from_subject_uri_returns_multi_segment_suffix():
    ns = "http://example.org/people"
    uri = "http://example.org/people/alice/extra"
    assert id_from_subject_uri(ns, uri) == "alice/extra"
