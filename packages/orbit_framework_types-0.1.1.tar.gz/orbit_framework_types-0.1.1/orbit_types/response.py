from .base import BaseModel


class ResponseModel(BaseModel):
    pass
