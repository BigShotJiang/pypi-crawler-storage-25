class OrbitError(Exception):
    """
    Base exception class for all Orbit-related errors.
    """
    pass

class ValidationError(OrbitError):
    """
    Raised when data validation fails.

    This typically occurs when input data does not match
    the expected schema or constraints.
    """
    pass
