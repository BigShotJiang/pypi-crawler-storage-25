class RequestModel:
    """
    Represents an incoming request in the Orbit framework.

    Encapsulates request data such as:
    - Query parameters
    - Headers
    - Body payload

    This model is used internally by the server and routing system.
    """
    pass
