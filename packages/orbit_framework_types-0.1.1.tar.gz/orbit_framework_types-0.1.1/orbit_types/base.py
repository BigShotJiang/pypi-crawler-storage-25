from pydantic import BaseModel as PydanticBaseModel


class BaseModel(PydanticBaseModel):
    """
    Base class for all Orbit data models.

    Provides shared functionality such as validation,
    serialization, and structured data handling.

    This class is intended to be extended by:
    - RequestModel
    - ResponseModel
    - Custom user-defined models
    """
        
    model_config = {
        "from_attributes": True,
        "populate_by_name": True,
        "arbitrary_types_allowed": True,
    }

    def to_dict(self) -> dict:
        return self.model_dump()

    def to_json(self) -> str:
        return self.model_dump_json()
