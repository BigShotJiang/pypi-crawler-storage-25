"""
Orbit Types Package

This module provides core data models and exceptions used across the Orbit framework.

It exposes the public API for handling:
- Base data structures
- Request and response models
- Framework-specific exceptions

Exports:
    BaseModel: Base class for all Orbit data models.
    RequestModel: Represents an incoming request.
    ResponseModel: Represents an outgoing response.
    OrbitError: Base exception for Orbit.
    ValidationError: Raised when validation fails.
"""

from .base import BaseModel
from .request import RequestModel
from .response import ResponseModel
from .exceptions import OrbitError, ValidationError

__all__ = [
    "BaseModel",
    "RequestModel",
    "ResponseModel",
    "OrbitError",
    "ValidationError",
]
