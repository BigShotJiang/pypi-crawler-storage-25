"""Resource modules grouped by endpoint family."""
from .profile import ProfileResource
from .modules import ModulesResource
from .offers import OffersResource
from .team import TeamResource
from .partnerships import PartnershipsResource
from .tasks import TasksResource
from .academy import AcademyResource

__all__ = [
    "ProfileResource",
    "ModulesResource",
    "OffersResource",
    "TeamResource",
    "PartnershipsResource",
    "TasksResource",
    "AcademyResource",
]
