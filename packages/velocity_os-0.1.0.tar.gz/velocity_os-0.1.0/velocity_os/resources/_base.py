"""Shared base for all resource classes."""
from __future__ import annotations

from typing import TYPE_CHECKING

from ..errors import ScopeMissingError

if TYPE_CHECKING:
    from .._http import HTTPClient
    from ..client import VelocityOS


class Resource:
    """Holds a reference back to the parent client.

    Resources may pre-check scopes locally (raise ScopeMissingError before
    the network call) by reading client.granted_scopes.
    """

    def __init__(self, client: "VelocityOS"):
        self._client = client

    @property
    def _http(self) -> "HTTPClient":
        return self._client._http

    def _require_scope(self, scope: str) -> None:
        granted = self._client.granted_scopes
        # If we haven't called whoami() yet, granted is None and we can't
        # short-circuit; the server will still enforce.
        if granted is not None and scope not in granted:
            raise ScopeMissingError(scope)
