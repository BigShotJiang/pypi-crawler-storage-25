"""GET /api/v1/extensions/profile -- founder profile reads."""
from __future__ import annotations

from ._base import Resource


class ProfileResource(Resource):
    def get(self) -> dict:
        """Return the user's whitelisted founder profile fields.

        Required scope: ``read:profile``
        """
        self._require_scope("read:profile")
        resp = self._http.request("GET", "/api/v1/extensions/profile")
        return resp.data.get("profile") or {}
