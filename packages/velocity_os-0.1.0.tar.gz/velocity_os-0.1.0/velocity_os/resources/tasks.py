"""GET + POST /api/v1/extensions/tasks"""
from __future__ import annotations

from typing import Literal, Optional

from ..models import Task, TaskList
from ._base import Resource


Quadrant = Literal["do_first", "schedule", "delegate", "eliminate"]


class TasksResource(Resource):
    def list(self) -> TaskList:
        """Return the user's combined open + completed action backlog.

        Required scope: ``read:tasks``
        """
        self._require_scope("read:tasks")
        resp = self._http.request("GET", "/api/v1/extensions/tasks")
        return TaskList.from_dict(resp.data)

    def create(
        self,
        action: str,
        module_source: str,
        *,
        category: str = "",
        timeframe: str = "",
        quadrant: Optional[Quadrant] = None,
        assignee: str = "",
        deadline: str = "",
    ) -> Task:
        """Append a new action to the user's backlog.

        Args:
            action: Short action title (under ~10 words).
            module_source: Module code this action belongs to (e.g. ``"L12"``).
            category: One of ``strategy|operations|people|finance``.
            timeframe: One of ``this_week|this_month|this_quarter``.
            quadrant: Eisenhower quadrant. Server enforces the allowed set.
            assignee: Free-text assignee.
            deadline: ISO date string (YYYY-MM-DD).

        Required scope: ``write:tasks``

        Triggers a ``tasks.created`` webhook to subscribed extensions.
        """
        self._require_scope("write:tasks")
        if not action:
            raise ValueError("action is required")
        if not module_source:
            raise ValueError("module_source is required")
        body = {
            "action": action,
            "module_source": module_source,
            "category": category,
            "timeframe": timeframe,
            "quadrant": quadrant or "",
            "assignee": assignee,
            "deadline": deadline,
        }
        resp = self._http.request("POST", "/api/v1/extensions/tasks", json=body)
        return Task.from_dict(resp.data.get("created") or {})
