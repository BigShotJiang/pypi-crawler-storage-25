"""GET /api/v1/extensions/partnerships"""
from __future__ import annotations

from ..models import Partnership
from ._base import Resource


class PartnershipsResource(Resource):
    def list(self) -> list[Partnership]:
        """Return the user's partnerships list.

        Required scope: ``read:partnerships``
        """
        self._require_scope("read:partnerships")
        resp = self._http.request("GET", "/api/v1/extensions/partnerships")
        return [Partnership.from_dict(p) for p in (resp.data.get("partnerships") or [])]
