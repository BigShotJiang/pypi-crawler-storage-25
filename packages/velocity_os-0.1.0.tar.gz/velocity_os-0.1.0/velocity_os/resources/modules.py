"""GET /api/v1/extensions/modules and /modules/{code}"""
from __future__ import annotations

from ..models import Module, ModuleSummary
from ._base import Resource


class ModulesResource(Resource):
    def list(self) -> list[ModuleSummary]:
        """Return module completion summary for every module the user has touched.

        Required scope: ``read:modules``
        """
        self._require_scope("read:modules")
        resp = self._http.request("GET", "/api/v1/extensions/modules")
        return [ModuleSummary.from_dict(m) for m in (resp.data.get("modules") or [])]

    def get(self, code: str) -> Module:
        """Return the parsed JSON output for one module (e.g. "F6", "C3").

        Raises NotFoundError if the user has not completed that module.

        Required scope: ``read:modules``
        """
        self._require_scope("read:modules")
        resp = self._http.request("GET", f"/api/v1/extensions/modules/{code.upper()}")
        return Module(
            code=resp.data.get("code") or code.upper(),
            output=resp.data.get("output"),
        )
