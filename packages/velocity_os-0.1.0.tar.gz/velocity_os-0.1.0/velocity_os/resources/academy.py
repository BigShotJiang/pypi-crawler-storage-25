"""GET /api/v1/extensions/academy/programs"""
from __future__ import annotations

from ..models import AcademyProgram
from ._base import Resource


class AcademyResource(Resource):
    def programs(self) -> list[AcademyProgram]:
        """Return academy programs owned by the user (academy tier only).

        Required scope: ``read:academy``
        """
        self._require_scope("read:academy")
        resp = self._http.request("GET", "/api/v1/extensions/academy/programs")
        return [AcademyProgram.from_dict(p) for p in (resp.data.get("programs") or [])]
