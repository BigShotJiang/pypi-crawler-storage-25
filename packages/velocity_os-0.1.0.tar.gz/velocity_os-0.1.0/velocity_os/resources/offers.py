"""GET /api/v1/extensions/offers"""
from __future__ import annotations

from ..models import Offer
from ._base import Resource


class OffersResource(Resource):
    def list(self) -> list[Offer]:
        """Return all approved/active offers from the user's entity registry.

        Required scope: ``read:offers``
        """
        self._require_scope("read:offers")
        resp = self._http.request("GET", "/api/v1/extensions/offers")
        return [Offer.from_dict(o) for o in (resp.data.get("offers") or [])]
