"""GET + POST /api/v1/extensions/team"""
from __future__ import annotations

from ..models import TeamMember
from ._base import Resource


class TeamResource(Resource):
    def list(self) -> list[TeamMember]:
        """Return the user's team roster.

        Required scope: ``read:team``
        """
        self._require_scope("read:team")
        resp = self._http.request("GET", "/api/v1/extensions/team")
        return [TeamMember.from_dict(m) for m in (resp.data.get("team") or [])]

    def add(self, name: str, role: str = "", email: str = "") -> TeamMember:
        """Append a new team member to the user's roster.

        Required scope: ``write:entities``
        """
        self._require_scope("write:entities")
        if not name:
            raise ValueError("name is required")
        resp = self._http.request(
            "POST",
            "/api/v1/extensions/team",
            json={"name": name, "role": role, "email": email},
        )
        return TeamMember.from_dict(resp.data.get("created") or {})
