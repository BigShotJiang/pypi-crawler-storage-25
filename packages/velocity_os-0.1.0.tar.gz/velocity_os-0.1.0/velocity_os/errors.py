"""Exception types raised by the Velocity OS SDK."""
from __future__ import annotations


class VelocityOSError(Exception):
    """Base class for all SDK errors."""


class APIError(VelocityOSError):
    """An error returned by the Velocity OS API."""

    def __init__(self, message: str, *, code: str = "", status_code: int = 0):
        super().__init__(message)
        self.code = code
        self.status_code = status_code

    def __repr__(self) -> str:
        return f"APIError(status={self.status_code}, code={self.code!r}, message={self.args[0]!r})"


class AuthenticationError(APIError):
    """The API key is missing, invalid, or revoked. (HTTP 401)"""


class ScopeMissingError(APIError):
    """The extension is not authorized for the requested scope. (HTTP 403)

    Raised both proactively (before the network call, if we know the scope
    is missing) and from the server's `scope_required` response.
    """

    def __init__(self, scope: str, *, status_code: int = 403):
        super().__init__(
            f"Extension is missing required scope: {scope}",
            code="scope_required",
            status_code=status_code,
        )
        self.scope = scope


class NotFoundError(APIError):
    """The requested resource does not exist. (HTTP 404)"""


class RateLimitError(APIError):
    """Rate limit exceeded. (HTTP 429)"""


class ServerError(APIError):
    """The server returned a 5xx error after retries were exhausted."""


class WebhookSignatureError(VelocityOSError):
    """A webhook signature failed verification."""
