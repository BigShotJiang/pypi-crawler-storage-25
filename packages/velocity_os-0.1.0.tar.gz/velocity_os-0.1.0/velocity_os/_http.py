"""Internal HTTP layer for the Velocity OS SDK.

Wraps httpx with:
  - Bearer auth header injection
  - Retry-with-exponential-backoff for transient failures
  - Hard-fail on auth/scope errors (don't burn retries on a revoked key)
  - Standard envelope unwrapping into Response objects
  - Translation of error envelopes into typed SDK exceptions

Designed to be used internally by `Client` and the resource modules.
"""
from __future__ import annotations

import time
from typing import Any, Optional

import httpx

from .errors import (
    APIError,
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ScopeMissingError,
    ServerError,
    VelocityOSError,
)
from .models import Response


_DEFAULT_TIMEOUT = 30.0
_RETRY_BACKOFF = [0.5, 1.5, 4.0]   # 3 retries on transient errors (5xx, network, 429)
_RETRYABLE_STATUS = {429, 500, 502, 503, 504}


class HTTPClient:
    """Thin httpx wrapper with retry + auth + envelope handling."""

    def __init__(
        self,
        api_key: str,
        base_url: str,
        timeout: float = _DEFAULT_TIMEOUT,
        user_agent: str = "",
    ):
        if not api_key:
            raise VelocityOSError("api_key is required")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._user_agent = user_agent or "VelocityOS-Python-SDK/0.1.0"
        # httpx.Client construction kwargs vary slightly across versions; pass
        # timeout via the keyword if supported, else fall back to setting it
        # on the instance, else swallow and rely on per-request timeout.
        try:
            self._client = httpx.Client(timeout=timeout)
        except TypeError:
            self._client = httpx.Client()
            try:
                self._client.timeout = timeout
            except Exception:
                pass

    def close(self) -> None:
        try:
            self._client.close()
        except Exception:
            pass

    def __enter__(self) -> "HTTPClient":
        return self

    def __exit__(self, *args) -> None:
        self.close()

    def request(
        self,
        method: str,
        path: str,
        *,
        json: Optional[dict] = None,
        params: Optional[dict] = None,
    ) -> Response:
        url = f"{self._base_url}{path}"
        headers = {
            "Authorization": f"Bearer {self._api_key}",
            "User-Agent": self._user_agent,
            "Accept": "application/json",
        }
        if json is not None:
            headers["Content-Type"] = "application/json"

        last_exc: Optional[Exception] = None
        for attempt in range(len(_RETRY_BACKOFF) + 1):
            try:
                resp = self._client.request(
                    method,
                    url,
                    headers=headers,
                    json=json,
                    params=params,
                )
            except (httpx.ConnectError, httpx.ReadTimeout, httpx.WriteTimeout, httpx.ConnectTimeout) as exc:
                last_exc = exc
                if attempt < len(_RETRY_BACKOFF):
                    time.sleep(_RETRY_BACKOFF[attempt])
                    continue
                raise APIError(f"Network error after {attempt + 1} attempts: {exc}", status_code=0)

            if resp.status_code in _RETRYABLE_STATUS and attempt < len(_RETRY_BACKOFF):
                time.sleep(_RETRY_BACKOFF[attempt])
                continue

            return self._unwrap(resp)

        # Should be unreachable, but be defensive
        if last_exc:
            raise APIError(f"Network error: {last_exc}", status_code=0)
        raise APIError("Unknown HTTP failure", status_code=0)

    def _unwrap(self, resp: httpx.Response) -> Response:
        """Translate an httpx.Response into a Response or a typed exception."""
        try:
            body = resp.json()
        except Exception:
            body = {}

        if resp.status_code >= 400 or not body.get("ok", False):
            error = body.get("error") or {}
            code = error.get("code") or ""
            message = error.get("message") or f"HTTP {resp.status_code}"
            self._raise_for_error(resp.status_code, code, message)

        return Response(
            data=body.get("data") or {},
            extension_id=body.get("extension_id"),
            extension_name=body.get("extension_name"),
            venture_id=body.get("venture_id"),
            sandbox=bool(body.get("sandbox")),
            raw=body,
        )

    def _raise_for_error(self, status: int, code: str, message: str) -> None:
        if status == 401:
            raise AuthenticationError(message, code=code or "invalid_key", status_code=status)
        if status == 403:
            if code == "scope_required":
                # The message format is "Extension is missing required scope: <scope>"
                scope = message.rsplit(":", 1)[-1].strip() if ":" in message else "unknown"
                raise ScopeMissingError(scope, status_code=status)
            raise APIError(message, code=code or "forbidden", status_code=status)
        if status == 404:
            raise NotFoundError(message, code=code or "not_found", status_code=status)
        if status == 429:
            raise RateLimitError(message, code=code or "rate_limited", status_code=status)
        if 500 <= status < 600:
            raise ServerError(message, code=code or "server_error", status_code=status)
        raise APIError(message, code=code or "error", status_code=status)
