"""Top-level Velocity OS SDK client."""
from __future__ import annotations

from typing import Optional

from ._http import HTTPClient
from .models import WhoAmI
from .resources import (
    AcademyResource,
    ModulesResource,
    OffersResource,
    PartnershipsResource,
    ProfileResource,
    TasksResource,
    TeamResource,
)
from .webhooks import WebhookHandler


_DEFAULT_BASE_URL = "https://app.velocityos.app"


class VelocityOS:
    """Main entry point for the Velocity OS Extension SDK.

    Example:

        from velocity_os import VelocityOS

        vos = VelocityOS(
            api_key=os.environ["VOS_EXT_KEY"],
            webhook_secret=os.environ["VOS_WEBHOOK_SECRET"],
        )

        me = vos.whoami()
        tasks = vos.tasks.list()
        vos.tasks.create(action="Ship the SDK", module_source="L12")

        handler = vos.webhook_handler()

        @handler.on("tasks.created")
        def on_task(payload):
            ...

    Args:
        api_key: A ``vos_ext_…`` key generated when a Velocity OS user
            installs your extension.
        webhook_secret: The ``whsec_…`` HMAC secret for your extension,
            shown once when you registered the extension. Required only if
            you plan to receive webhooks. Reads-only extensions can omit it.
        base_url: Override for self-hosted or sandbox environments. Defaults
            to ``https://app.velocityos.app``.
        timeout: Per-request HTTP timeout in seconds. Defaults to 30.
        user_agent: Override the default ``User-Agent`` header. Useful if
            you want to identify your extension in server logs.
    """

    def __init__(
        self,
        api_key: str,
        *,
        webhook_secret: Optional[str] = None,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: float = 30.0,
        user_agent: str = "",
    ):
        self._api_key = api_key
        self._webhook_secret = webhook_secret
        self._http = HTTPClient(
            api_key=api_key,
            base_url=base_url,
            timeout=timeout,
            user_agent=user_agent,
        )

        # Cached after first whoami() call so resources can short-circuit
        # on missing scopes without round-tripping the server.
        self._whoami_cache: Optional[WhoAmI] = None

        # Resource handles
        self.profile = ProfileResource(self)
        self.modules = ModulesResource(self)
        self.offers = OffersResource(self)
        self.team = TeamResource(self)
        self.partnerships = PartnershipsResource(self)
        self.tasks = TasksResource(self)
        self.academy = AcademyResource(self)

    # ── Context manager support so callers can `with VelocityOS(...) as vos:` ──
    def __enter__(self) -> "VelocityOS":
        return self

    def __exit__(self, *args) -> None:
        self.close()

    def close(self) -> None:
        """Close the underlying HTTP client. Optional but recommended."""
        self._http.close()

    # ── Top-level methods ────────────────────────────────────────────────────

    def whoami(self, *, refresh: bool = False) -> WhoAmI:
        """Return the user this key acts on behalf of and the extension metadata.

        Result is cached for the lifetime of the client. Pass ``refresh=True``
        to force a re-fetch (e.g. after a scope change).

        No scope required.
        """
        if self._whoami_cache and not refresh:
            return self._whoami_cache
        resp = self._http.request("GET", "/api/v1/extensions/whoami")
        wa = WhoAmI.from_dict(resp.data, sandbox=resp.sandbox)
        self._whoami_cache = wa
        return wa

    @property
    def granted_scopes(self) -> Optional[list[str]]:
        """Return the list of scopes granted to this install, or None if
        whoami() has not been called yet.

        Resource methods use this to short-circuit a network call when a
        required scope is missing. Returning None means "we don't know
        yet" and the server will be the source of truth.
        """
        if self._whoami_cache is None:
            return None
        return list(self._whoami_cache.extension.granted_scopes)

    @property
    def sandbox_mode(self) -> Optional[bool]:
        """Return True if the most recent response indicated sandbox mode,
        or None if no call has been made yet."""
        if self._whoami_cache is None:
            return None
        return self._whoami_cache.sandbox

    def webhook_handler(self, *, max_skew_seconds: int = 300) -> WebhookHandler:
        """Return a WebhookHandler bound to this client's webhook secret.

        Raises ValueError if the client was constructed without a webhook_secret.
        """
        if not self._webhook_secret:
            raise ValueError(
                "VelocityOS was constructed without a webhook_secret. "
                "Pass webhook_secret=... to enable webhook handling."
            )
        return WebhookHandler(self._webhook_secret, max_skew_seconds=max_skew_seconds)
