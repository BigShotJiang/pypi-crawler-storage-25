"""Velocity OS Python SDK.

Build extensions for Velocity OS without writing HTTP boilerplate.

Install::

    pip install velocity-os

Quick start::

    from velocity_os import VelocityOS

    vos = VelocityOS(
        api_key="vos_ext_...",
        webhook_secret="whsec_...",
    )

    me = vos.whoami()
    tasks = vos.tasks.list()
    vos.tasks.create(action="Ship the SDK", module_source="L12")

See the README in this directory for the full reference.
"""
from .client import VelocityOS
from .errors import (
    APIError,
    AuthenticationError,
    NotFoundError,
    RateLimitError,
    ScopeMissingError,
    ServerError,
    VelocityOSError,
    WebhookSignatureError,
)
from .models import (
    AcademyProgram,
    CompletedTask,
    Module,
    ModuleSummary,
    Offer,
    Partnership,
    Response,
    Task,
    TaskList,
    TeamMember,
    WhoAmI,
    WhoAmIExtension,
    WhoAmIUser,
)
from .webhooks import WebhookHandler, verify_signature

__version__ = "0.1.0"

__all__ = [
    "VelocityOS",
    "WebhookHandler",
    "verify_signature",
    # Errors
    "VelocityOSError",
    "APIError",
    "AuthenticationError",
    "ScopeMissingError",
    "NotFoundError",
    "RateLimitError",
    "ServerError",
    "WebhookSignatureError",
    # Models
    "Response",
    "WhoAmI",
    "WhoAmIUser",
    "WhoAmIExtension",
    "ModuleSummary",
    "Module",
    "Offer",
    "TeamMember",
    "Partnership",
    "Task",
    "CompletedTask",
    "TaskList",
    "AcademyProgram",
    "__version__",
]
