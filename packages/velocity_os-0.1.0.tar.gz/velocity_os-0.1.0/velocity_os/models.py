"""Typed response models for the Velocity OS SDK.

These are simple dataclasses produced from the JSON envelopes the API
returns. They give callers attribute-style access (`me.user.email`) and
work with type checkers / IDE completion.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Optional


# ── Envelope ─────────────────────────────────────────────────────────────────


@dataclass
class Response:
    """Wrapper around every API response."""
    data: dict
    extension_id: Optional[int] = None
    extension_name: Optional[str] = None
    venture_id: Optional[str] = None
    sandbox: bool = False
    raw: dict = field(default_factory=dict)


# ── /whoami ──────────────────────────────────────────────────────────────────


@dataclass
class WhoAmIUser:
    email: str
    name: str
    tier: str
    venture_id: str


@dataclass
class WhoAmIExtension:
    id: int
    name: str
    slug: str
    developer: str
    granted_scopes: list[str]


@dataclass
class WhoAmI:
    user: WhoAmIUser
    extension: WhoAmIExtension
    sandbox: bool

    @classmethod
    def from_dict(cls, payload: dict, sandbox: bool = False) -> "WhoAmI":
        u = payload.get("user") or {}
        e = payload.get("extension") or {}
        return cls(
            user=WhoAmIUser(
                email=u.get("email", ""),
                name=u.get("name", ""),
                tier=u.get("tier", ""),
                venture_id=u.get("venture_id", "default"),
            ),
            extension=WhoAmIExtension(
                id=int(e.get("id", 0) or 0),
                name=e.get("name", ""),
                slug=e.get("slug", ""),
                developer=e.get("developer", ""),
                granted_scopes=list(e.get("granted_scopes") or []),
            ),
            sandbox=sandbox,
        )


# ── /modules ─────────────────────────────────────────────────────────────────


@dataclass
class ModuleSummary:
    code: str
    status: str
    completed_at: Optional[str]
    has_output: bool

    @classmethod
    def from_dict(cls, d: dict) -> "ModuleSummary":
        return cls(
            code=d.get("code", ""),
            status=d.get("status") or "",
            completed_at=d.get("completed_at"),
            has_output=bool(d.get("has_output")),
        )


@dataclass
class Module:
    code: str
    output: Any   # Whatever shape the underlying module produces


# ── /offers ──────────────────────────────────────────────────────────────────


@dataclass
class Offer:
    id: str
    name: str
    status: str
    created_at: Optional[str]
    updated_at: Optional[str]
    c3_output: Any

    @classmethod
    def from_dict(cls, d: dict) -> "Offer":
        return cls(
            id=d.get("id") or "",
            name=d.get("name") or "",
            status=d.get("status") or "",
            created_at=d.get("created_at"),
            updated_at=d.get("updated_at"),
            c3_output=d.get("c3_output"),
        )


# ── /team ────────────────────────────────────────────────────────────────────


@dataclass
class TeamMember:
    name: str
    role: str
    email: str

    @classmethod
    def from_dict(cls, d: dict) -> "TeamMember":
        return cls(
            name=d.get("name") or "",
            role=d.get("role") or "",
            email=d.get("email") or "",
        )


# ── /partnerships ────────────────────────────────────────────────────────────


@dataclass
class Partnership:
    name: str
    type: str
    contact: str

    @classmethod
    def from_dict(cls, d: dict) -> "Partnership":
        return cls(
            name=d.get("name") or "",
            type=d.get("type") or "",
            contact=d.get("contact") or "",
        )


# ── /tasks ───────────────────────────────────────────────────────────────────


@dataclass
class Task:
    module_source: str
    action: str
    category: Optional[str] = None
    timeframe: Optional[str] = None
    quadrant: Optional[str] = None
    assignee: Optional[str] = None
    deadline: Optional[str] = None

    @classmethod
    def from_dict(cls, d: dict) -> "Task":
        return cls(
            module_source=d.get("module_source") or "",
            action=d.get("action") or "",
            category=d.get("category"),
            timeframe=d.get("timeframe"),
            quadrant=d.get("quadrant"),
            assignee=d.get("assignee"),
            deadline=d.get("deadline"),
        )


@dataclass
class CompletedTask:
    id: str
    action: str
    completed_at: Optional[str]

    @classmethod
    def from_dict(cls, d: dict) -> "CompletedTask":
        return cls(
            id=d.get("id") or "",
            action=d.get("action") or "",
            completed_at=d.get("completed_at"),
        )


@dataclass
class TaskList:
    open: list[Task]
    completed: list[CompletedTask]

    @classmethod
    def from_dict(cls, d: dict) -> "TaskList":
        return cls(
            open=[Task.from_dict(x) for x in (d.get("open") or [])],
            completed=[CompletedTask.from_dict(x) for x in (d.get("completed") or [])],
        )


# ── /academy/programs ────────────────────────────────────────────────────────


@dataclass
class AcademyProgram:
    id: int
    name: str
    description: str
    status: str
    created_at: Optional[str]

    @classmethod
    def from_dict(cls, d: dict) -> "AcademyProgram":
        return cls(
            id=int(d.get("id") or 0),
            name=d.get("name") or "",
            description=d.get("description") or "",
            status=d.get("status") or "",
            created_at=d.get("created_at"),
        )
