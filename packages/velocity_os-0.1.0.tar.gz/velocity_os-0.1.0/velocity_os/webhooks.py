"""Webhook signature verification + decorator-based event routing.

Usage::

    from velocity_os import VelocityOS

    vos = VelocityOS(api_key=..., webhook_secret=...)
    handler = vos.webhook_handler()

    @handler.on("tasks.created")
    def on_task(payload):
        print("new task:", payload["action"])

    @handler.on("module.updated")
    def on_module(payload):
        ...

    # In a Flask handler:
    @app.post("/webhook")
    def webhook():
        ok, status = handler.handle(request.headers, request.get_data())
        return ok, status

The handler verifies the X-VOS-Signature header against the webhook
secret using the same scheme as the server: HMAC-SHA256 over
``f"{ts}.{raw_body}"``. Requests with bad/missing/expired signatures
return (response_dict, 401) and never invoke any registered callback.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import time
from typing import Any, Callable, Optional

from .errors import WebhookSignatureError


def verify_signature(
    secret: str,
    header_value: str,
    body: bytes,
    *,
    max_skew_seconds: int = 300,
) -> bool:
    """Verify a ``t=...,v1=...`` Velocity OS webhook signature.

    Returns True if the signature is valid AND the timestamp is within
    ``max_skew_seconds`` of the current time. Returns False otherwise.
    """
    if not secret or not header_value:
        return False
    parts: dict[str, str] = {}
    for piece in header_value.split(","):
        if "=" in piece:
            k, v = piece.split("=", 1)
            parts[k.strip()] = v.strip()
    ts_raw = parts.get("t")
    sig_raw = parts.get("v1")
    if not ts_raw or not sig_raw:
        return False
    try:
        ts = int(ts_raw)
    except ValueError:
        return False
    if abs(int(time.time()) - ts) > max_skew_seconds:
        return False
    expected = hmac.new(
        secret.encode("utf-8"),
        f"{ts}.".encode("utf-8") + body,
        hashlib.sha256,
    ).hexdigest()
    return hmac.compare_digest(expected, sig_raw)


HandlerFn = Callable[[dict], Any]


class WebhookHandler:
    """Decorator-based router for inbound Velocity OS webhooks.

    Construct via ``VelocityOS.webhook_handler()`` so the secret is
    pre-bound. Register handlers with the ``@handler.on(event_type)``
    decorator. Call ``handler.handle(headers, raw_body)`` from your
    web framework's POST endpoint.
    """

    def __init__(self, secret: str, *, max_skew_seconds: int = 300):
        if not secret:
            raise ValueError("webhook secret is required to verify signatures")
        self._secret = secret
        self._max_skew = max_skew_seconds
        self._handlers: dict[str, list[HandlerFn]] = {}
        self._catchall: list[HandlerFn] = []

    def on(self, event_type: str) -> Callable[[HandlerFn], HandlerFn]:
        """Register a handler for one event type.

        Use ``"*"`` to register a catch-all that runs for every verified event.
        """
        def decorator(fn: HandlerFn) -> HandlerFn:
            if event_type == "*":
                self._catchall.append(fn)
            else:
                self._handlers.setdefault(event_type, []).append(fn)
            return fn
        return decorator

    def handle(
        self,
        headers,
        raw_body: bytes,
    ) -> tuple[dict, int]:
        """Verify a webhook request and dispatch to handlers.

        Args:
            headers: A mapping that supports case-insensitive ``.get(name)``
                lookups (Flask/FastAPI/Werkzeug Headers all work).
            raw_body: The exact bytes of the request body. You MUST pass the
                raw bytes (e.g. ``request.get_data()`` in Flask, not
                ``request.json``) so the HMAC matches.

        Returns:
            A ``(response_dict, status_code)`` tuple suitable for returning
            from your web handler.
        """
        signature = _header_get(headers, "X-VOS-Signature") or ""
        if not verify_signature(self._secret, signature, raw_body, max_skew_seconds=self._max_skew):
            return {"ok": False, "error": "invalid signature"}, 401

        try:
            payload = json.loads(raw_body) if raw_body else {}
        except (json.JSONDecodeError, ValueError):
            return {"ok": False, "error": "invalid json body"}, 400

        event_type = _header_get(headers, "X-VOS-Event-Type") or ""
        delivery_id = _header_get(headers, "X-VOS-Delivery-ID") or ""

        for fn in self._catchall:
            try:
                fn({"event_type": event_type, "delivery_id": delivery_id, "payload": payload})
            except Exception:
                pass

        for fn in self._handlers.get(event_type, []):
            try:
                fn(payload)
            except Exception:
                pass

        return {"ok": True, "event_type": event_type, "delivery_id": delivery_id}, 200


def _header_get(headers, name: str) -> Optional[str]:
    """Case-insensitive header lookup that works for dict, Flask, FastAPI."""
    if hasattr(headers, "get"):
        # dict-like (Flask Headers, fastapi Headers, plain dict)
        v = headers.get(name)
        if v is not None:
            return v
        # Try lowercase variant for plain dicts
        v = headers.get(name.lower())
        if v is not None:
            return v
    # Try iteration
    try:
        for k, v in headers.items():
            if str(k).lower() == name.lower():
                return v
    except Exception:
        pass
    return None
