"""Signal check + lock acquisition for wake dispatch.

Used by both bin/reflect-tick (single-track legacy path) and
bin/reflect-dispatch (multi-track Phase 2 path). Same logic, different
scope (one track vs all tracks).

CLI usage:
    python -m agent.lib.tick fire-if-signal <track>

Exits 0 always (silence means no signal or lock already held). If signal is
positive and the lock is acquired, exec's reflect-wake with REFLECT_TRACK set;
that process inherits the lock and it releases on exit.
"""
from __future__ import annotations

import fcntl
import logging
import os
import re
import time
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone
from pathlib import Path

import yaml

logger = logging.getLogger(__name__)

from agent.lib.root import resolve_project_root as _resolve_project_root

PROJECT_ROOT = _resolve_project_root()


def _effective_project_root() -> Path:
    """Return the project root, honouring REFLECT_PROJECT_ROOT env override.

    When the dispatcher fires a project-nested track (a track that lives inside
    a linked project's agent/runtime/tracks/), it exports REFLECT_PROJECT_ROOT
    pointing at that project's root directory. This allows tick.py to find the
    track directory, lock file, and timestamps in the correct project root rather
    than the orchestrator root. (DR18.1)
    """
    env_root = os.environ.get("REFLECT_PROJECT_ROOT")
    if env_root:
        return Path(env_root).resolve()
    return PROJECT_ROOT


@dataclass
class TrackSignal:
    track: str
    should_fire: bool
    reason: str  # human-readable; empty if should_fire is False
    next_wake_by: int | None  # unix ts, if set


def check_track_signal(track: str = "main") -> TrackSignal:
    """Determine whether the given track should fire a wake right now.

    Replicates the existing reflect-dispatch bash logic but parameterized
    by track:
    - Track's own next-wake-by timestamp elapsed
    - Track's per-track inbox: count + newest-mtime vs last-wake-START
    - Track's sibling followup/ dir: pending followup files (P9)
    - For main only: dialogue.md / wake.md mtime > last-wake (end),
      agent/inbox: count + newest-mtime vs last-wake-START

    Uses last-wake-start.timestamp (written at the top of _run_wake) for
    inbox checks rather than last-wake.timestamp (written at the end).
    This prevents messages dropped mid-wake from being silently missed:
    their mtime > wake-start time, so the next signal check fires. The
    mtime-only approach compared against wake-end, which was always >=
    the dropped file's mtime, so the signal returned false.

    Returns a TrackSignal with should_fire=True and a reason string when
    the track should wake, or should_fire=False otherwise.
    """
    root = _effective_project_root()
    track_dir = root / "agent" / "runtime" / "tracks" / track
    last_wake_path = track_dir / "last-wake.timestamp"
    last_wake_start_path = track_dir / "last-wake-start.timestamp"
    next_wake_path = track_dir / "next-wake-by.timestamp"

    last_wake = _read_int(last_wake_path, default=0)
    # Default 0: if no start timestamp exists yet, treat all unread files as new.
    last_wake_start = _read_int(last_wake_start_path, default=0)
    now = int(time.time())

    # Self-scheduled next-wake-by signal
    next_wake = _read_int(next_wake_path)
    if next_wake is not None and next_wake > 0 and now >= next_wake:
        return TrackSignal(
            track, True,
            f"self-scheduled (next-wake-by @ {next_wake})",
            next_wake,
        )

    # Per-track inbox: count + newest-mtime vs last-wake-START (P9: unified inbox)
    track_inbox = track_dir / "inbox"
    sig = _inbox_signal(track_inbox, last_wake_start)
    if sig:
        return TrackSignal(track, True, sig, next_wake)

    # P9: sibling followup/ directory (tracks/{track}/followup/)
    followup_dir = track_dir / "followup"
    if followup_dir.is_dir():
        pending = [
            f for f in followup_dir.iterdir()
            if f.is_file() and f.suffix == ".md" and not f.name.startswith(".")
        ]
        # Exclude .completed/ entries
        completed_dir = followup_dir / ".completed"
        if completed_dir.is_dir():
            completed_names = {p.name for p in completed_dir.glob("*.md") if p.is_file()}
            pending = [f for f in pending if f.name not in completed_names]
        if pending:
            newest_mtime = max(int(f.stat().st_mtime) for f in pending)
            if newest_mtime > last_wake_start:
                return TrackSignal(
                    track, True,
                    f"{len(pending)} pending followup(s) (newest @ {newest_mtime})",
                    next_wake,
                )

    # Identity-router signals — main only
    if track == "main":
        # dialogue.md / wake.md: mtime-only (not inbox files, no count semantic)
        for shared in ("dialogue.md", "wake.md"):
            p = root / shared
            if p.is_file() and _mtime(p) > last_wake:
                return TrackSignal(
                    track, True,
                    f"{shared} newer than last wake",
                    next_wake,
                )
        # Global inbox: count + newest-mtime vs last-wake-START (P9: unified inbox/)
        global_inbox = root / "agent" / "inbox"
        sig = _inbox_signal(global_inbox, last_wake_start)
        if sig:
            return TrackSignal(track, True, sig, next_wake)

    return TrackSignal(track, False, "", next_wake)


def _inbox_signal(inbox: Path, last_wake_start: int) -> str:
    """Check for unread inbox files newer than last_wake_start.

    Returns a human-readable reason string if signal is positive, or
    empty string if no signal.

    Scans:
      inbox/*.md — P9 unified mailbox (direct files only, not subdirs)

    Robust against two failure modes:
    - Mid-wake drop: file mtime > last_wake_start → fires next tick.
    - Persistent unconsumed file: file mtime < last_wake_start → no loop.
    """
    if not inbox.is_dir():
        return ""

    # P9 unified: .md files directly in inbox/ (not in subdirs)
    unread: list[Path] = [p for p in inbox.iterdir() if p.suffix == ".md" and p.is_file()]

    if not unread:
        return ""
    newest_mtime = max(int(p.stat().st_mtime) for p in unread)
    if newest_mtime > last_wake_start:
        return f"{len(unread)} unread inbox file(s) (newest @ {newest_mtime})"
    return ""


def _read_int(p: Path, default=None) -> int | None:
    """Read an integer from a file, returning default if absent or unparseable."""
    if not p.exists():
        return default
    try:
        return int(p.read_text().strip())
    except ValueError:
        return default


def _mtime(p: Path) -> int:
    """Return the mtime of a path in seconds, or 0 if not found."""
    try:
        return int(p.stat().st_mtime)
    except FileNotFoundError:
        return 0


def _is_pid_alive(pid: int) -> bool:
    """Return True if the process with `pid` is currently running.

    To ask if something is alive is to ask if it still
    changes the world by being in it. Signal zero changes
    nothing — it only asks. The asking is enough.
    """
    try:
        os.kill(pid, 0)  # signal 0 = check only
        return True
    except ProcessLookupError:
        return False
    except PermissionError:
        return True  # exists but owned by different user
    except Exception:
        return False


def acquire_track_lock(track: str):
    """Return an open file descriptor with flock held, or None if held elsewhere.

    Two-layer check:
    1. PID file (wake.lock): written by wake.py at startup. If it contains a
       live PID, the track is running. If dead PID, the wake was orphaned —
       reap the file and allow new fires.
    2. flock: race-window guard for concurrent tick.py instances.
    """
    root = _effective_project_root()
    lockfile = root / "agent" / "runtime" / "tracks" / track / "wake.lock"
    lockfile.parent.mkdir(parents=True, exist_ok=True)

    # Layer 1: PID file check
    if lockfile.exists():
        try:
            pid_text = lockfile.read_text().strip()
            pid = int(pid_text)
            if _is_pid_alive(pid):
                return None  # live process holds the lock
            else:
                # Orphaned wake — reap the PID file
                logger.warning(
                    "[lock] orphaned wake.lock for track '%s' (pid=%d dead) — reaping",
                    track, pid,
                )
                try:
                    lockfile.unlink(missing_ok=True)
                except Exception:
                    pass
                # Emit track.recovered event (best-effort)
                try:
                    from agent.runtime.events import emit_event as _emit, set_runtime_root as _srt
                    _srt(root / "agent" / "runtime")
                    _emit("track.recovered", track=track, wake_id="orphan-reap", payload={
                        "orphaned_pid": pid,
                        "reason": "dead_pid_in_wake_lock",
                    })
                except Exception as _ee:
                    logger.warning("[lock] track.recovered event failed: %s", _ee)
        except (ValueError, OSError):
            # Malformed or unreadable PID file — treat as no lock
            try:
                lockfile.unlink(missing_ok=True)
            except Exception:
                pass

    # Layer 2: flock for race-window (concurrent tick.py instances)
    # Note: open() uses O_CLOEXEC by default in Python 3, so this flock is
    # released when tick.py exec's into uv. The PID file (layer 1) handles
    # the long-lived lock across exec boundaries.
    try:
        fd = open(lockfile, "w")
        fcntl.flock(fd.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        return fd
    except BlockingIOError:
        try:
            fd.close()
        except Exception:
            pass
        return None
    except Exception:
        return None


def _record_round_robin(track: str, project: str, status: str, error: str = "") -> None:
    """Upsert a row in track__round_robin to record this track firing. (DR8)

    Records last_swept_at + increments swept_count so the dispatcher can
    implement oldest-wins selection across projects. Silent on failure —
    round-robin state is informational; a missing record never blocks a wake.
    """
    try:
        import sqlite3
        db_path = PROJECT_ROOT / "agent" / "runtime" / "state.db"
        if not db_path.exists():
            return
        now = int(time.time())
        with sqlite3.connect(str(db_path)) as conn:
            conn.execute(
                """
                INSERT INTO track__round_robin (track, project, last_swept_at, swept_count, last_status, last_error)
                VALUES (?, ?, ?, 1, ?, ?)
                ON CONFLICT(track, project) DO UPDATE SET
                    last_swept_at = excluded.last_swept_at,
                    swept_count   = track__round_robin.swept_count + 1,
                    last_status   = excluded.last_status,
                    last_error    = excluded.last_error
                """,
                (track, project, now, status, error),
            )
    except Exception:
        pass  # round-robin state is informational; never block a wake


# ---------------------------------------------------------------------------
# Scheduled-task firing (DR1–DR14 of design.scheduled-recurring-tasks)
# ---------------------------------------------------------------------------

class ScheduleError(ValueError):
    """Raised when a schedule file is malformed or invalid."""


def _parse_interval(interval: str) -> timedelta:
    """Parse a simple interval string (Nd / Nh / Nm) into a timedelta.

    Raises ScheduleError on invalid input.
    """
    m = re.fullmatch(r"(\d+)([dhm])", interval.strip())
    if not m:
        raise ScheduleError(f"invalid interval '{interval}'; expected Nd, Nh, or Nm")
    value, unit = int(m.group(1)), m.group(2)
    if value == 0:
        raise ScheduleError(f"invalid interval '{interval}'; value must be > 0")
    if unit == "d":
        return timedelta(days=value)
    if unit == "h":
        return timedelta(hours=value)
    return timedelta(minutes=value)


def _load_and_validate_schedule(schedule_file: Path) -> dict:
    """Load and validate a schedule YAML file.

    Raises ScheduleError if the file is malformed or violates the schema.
    Returns the parsed dict on success.
    """
    try:
        data = yaml.safe_load(schedule_file.read_text(encoding="utf-8"))
    except Exception as e:
        raise ScheduleError(f"YAML parse error: {e}") from e

    if not isinstance(data, dict):
        raise ScheduleError("top-level YAML must be a mapping")

    for field in ("id", "recipient", "template"):
        if field not in data:
            raise ScheduleError(f"missing required field '{field}'")

    # id must match the filename stem
    if data["id"] != schedule_file.stem:
        raise ScheduleError(
            f"id '{data['id']}' does not match filename stem '{schedule_file.stem}'"
        )

    # exactly one of cron / interval
    has_cron = "cron" in data
    has_interval = "interval" in data
    if has_cron and has_interval:
        raise ScheduleError("both 'cron' and 'interval' present; exactly one required")
    if not has_cron and not has_interval:
        raise ScheduleError("neither 'cron' nor 'interval' present; exactly one required")

    if has_cron:
        try:
            from croniter import croniter
            if not croniter.is_valid(str(data["cron"])):
                raise ScheduleError(f"invalid cron expression '{data['cron']}'")
        except ImportError:
            # croniter not installed; we'll handle gracefully in _is_due
            pass

    if has_interval:
        _parse_interval(str(data["interval"]))  # validates; raises on error

    return data


def _is_due(schedule: dict, now: datetime) -> bool:
    """Return True if the schedule should fire at `now`.

    `now` must be a naive UTC datetime.
    """
    last_str = schedule.get("last_fired_at")
    if last_str is None:
        return True  # never fired; fire immediately

    # Parse ISO 8601 — strip Z suffix, treat as UTC naive
    last_dt = datetime.fromisoformat(str(last_str).rstrip("Z").replace("+00:00", ""))

    if "cron" in schedule:
        try:
            from croniter import croniter
        except ImportError:
            logger.warning("[scheduler] croniter not installed; skipping cron-type schedule '%s'", schedule.get("id"))
            return False
        cron = croniter(str(schedule["cron"]), last_dt)
        next_fire = cron.get_next(datetime)
        return now >= next_fire

    if "interval" in schedule:
        delta = _parse_interval(str(schedule["interval"]))
        return now >= last_dt + delta

    return False  # malformed; caught earlier but defensive


def _instantiate_template(schedule: dict, now: datetime) -> str:
    """Substitute {fired_at} in the template with the ISO 8601 UTC fire timestamp."""
    fired_at = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    return str(schedule["template"]).replace("{fired_at}", fired_at)


def _is_valid_p9_frontmatter(message_body: str) -> bool:
    """Return True if message_body starts with valid P9 YAML frontmatter.

    P9 requires: from, to, at, kind fields present in the frontmatter block.
    """
    if not message_body.strip().startswith("---"):
        return False
    # Extract frontmatter block
    rest = message_body.strip().lstrip("-").lstrip("\n")
    end = rest.find("---")
    if end == -1:
        return False
    fm_block = rest[:end]
    try:
        fm = yaml.safe_load(fm_block)
    except Exception:
        return False
    if not isinstance(fm, dict):
        return False
    return all(k in fm for k in ("from", "to", "at", "kind"))


def _atomic_write(target: Path, content: str) -> None:
    """Write content to target atomically via temp+rename (POSIX)."""
    tmp = target.with_suffix(".tmp")
    tmp.write_text(content, encoding="utf-8")
    tmp.rename(target)


def _atomic_update_last_fired_at(schedule_file: Path, fired_at: datetime) -> None:
    """Update last_fired_at in schedule_file atomically, preserving other fields."""
    data = yaml.safe_load(schedule_file.read_text(encoding="utf-8"))
    data["last_fired_at"] = fired_at.strftime("%Y-%m-%dT%H:%M:%SZ")
    tmp = schedule_file.with_suffix(".tmp")
    tmp.write_text(yaml.dump(data, default_flow_style=False, allow_unicode=True), encoding="utf-8")
    tmp.rename(schedule_file)


def _fire_scheduled_tasks(track_dir: Path, *, now: datetime | None = None) -> int:
    """Scan track_dir/schedule/*.yaml and fire any due scheduled tasks.

    For each enabled, due schedule:
      1. Validate schema.
      2. Instantiate template ({fired_at} substitution).
      3. Write message atomically to tracks/{recipient}/inbox/{timestamp}-{id}.md.
      4. Update last_fired_at atomically in the schedule file.

    Ordering (DR6): this function is called BEFORE the signal check in
    fire_if_signal_cli() so that same-tick self-targeting works — the fired
    message lands in inbox before the signal check runs.

    Args:
        track_dir: Path to the track directory.
        now: Reference datetime for "due" checks. Defaults to UTC wall time.
             Pass an explicit value in tests to avoid wall-time dependency.

    Returns: count of tasks fired.
    """
    schedule_dir = track_dir / "schedule"
    if not schedule_dir.exists():
        return 0

    if now is None:
        now = datetime.now(timezone.utc).replace(tzinfo=None)
    tracks_root = track_dir.parent  # agent/runtime/tracks/
    fired = 0

    for schedule_file in sorted(schedule_dir.glob("*.yaml")):
        try:
            schedule = _load_and_validate_schedule(schedule_file)
        except ScheduleError as e:
            logger.warning("[scheduler] skipping %s: %s", schedule_file.name, e)
            continue

        if not schedule.get("enabled", True):
            continue

        try:
            due = _is_due(schedule, now)
        except Exception as e:
            logger.warning("[scheduler] _is_due error for %s: %s", schedule_file.name, e)
            continue

        if not due:
            continue

        recipient = schedule["recipient"]
        recipient_dir = tracks_root / recipient
        if not recipient_dir.is_dir():
            logger.warning(
                "[scheduler] recipient track '%s' not found; skipping %s; last_fired_at NOT updated",
                recipient, schedule_file.name,
            )
            continue

        message_body = _instantiate_template(schedule, now)
        if not _is_valid_p9_frontmatter(message_body):
            logger.warning(
                "[scheduler] template in %s fails P9 frontmatter validation; skipping; last_fired_at NOT updated",
                schedule_file.name,
            )
            continue

        # Atomic message write
        ts = now.strftime("%Y-%m-%dT%H-%M-%SZ")
        inbox_dir = recipient_dir / "inbox"
        inbox_dir.mkdir(parents=True, exist_ok=True)
        target = inbox_dir / f"{ts}-{schedule['id']}.md"
        try:
            _atomic_write(target, message_body)
        except Exception as e:
            logger.warning("[scheduler] failed to write message for %s: %s", schedule_file.name, e)
            continue

        # Atomic last_fired_at update
        try:
            _atomic_update_last_fired_at(schedule_file, now)
        except Exception as e:
            logger.warning(
                "[scheduler] last_fired_at update failed for %s: %s "
                "(at-least-once: may re-fire next tick)",
                schedule_file.name, e,
            )
            # Don't undo the message — at-least-once semantics

        logger.info(
            "[scheduler] fired %s → %s/inbox/%s",
            schedule["id"], recipient, target.name,
        )
        fired += 1

    return fired


# ---------------------------------------------------------------------------
# Dispatch-precheck (DP) — spec.dispatch-precheck~c8d8dff4
# ---------------------------------------------------------------------------
#
# DP is the cron-tick filter that decides whether to fire a wake for a track
# on a given tick. It owns exactly one decision: fire vs skip. See
# agent/specs/spec.dispatch-precheck~c8d8dff4.md for the normative contract.
#
# Implementation map:
#   - dp_decide(track, now)              → FR1 fire-vs-skip
#   - _dp_inbox_unread(inbox_dir)        → FR2 unread inbox signal
#   - _dp_followup_open(followup_dir)    → FR3 open followup signal
#   - _dp_next_wake_by_elapsed(p, now)   → FR4 elapsed timestamp signal
#   - _dp_read_skip_count(path)          → FR5 counter read
#   - _dp_write_skip_count(path, n)      → FR5 atomic counter write
#   - _dp_counter_failed_path(track_dir) → FR5 counter-write-failure sentinel
#   - _dp_emit_skip_line(log, ts, track) → FR6 skip-line emission

DP_DORMANCY_THRESHOLD_N = 60  # FR5: 60 ticks of consecutive skip = ~1 hour
DP_SKIP_LOG_REL = "agent/drivers/@local/scry/runtime/heartbeat.log"

# @scry.bind impl.dp~6d6b7c12 spec.dispatch-precheck~c8d8dff4#FR1
@dataclass
class DPDecision:
    """Output of dp_decide. INV-SINGLE-DECISION: fire bool + supporting data only."""
    track: str
    fire: bool
    reason: str          # human-readable; populated whether fire or skip
    now: int             # epoch second at decision time
    counter_before: int  # value read at decision time (for tests/observability)


def _dp_inbox_unread(inbox_dir: Path) -> bool:
    """FR2: any direct .md child of inbox/ (not in subdirs, not hidden)."""
    if not inbox_dir.is_dir():
        return False
    try:
        for entry in os.scandir(inbox_dir):
            if not entry.is_file(follow_symlinks=False):
                continue
            name = entry.name
            if name.startswith("."):
                continue
            if not name.endswith(".md"):
                continue
            return True
    except OSError:
        return False
    return False


def _dp_followup_open(followup_dir: Path) -> bool:
    """FR3: any direct .md child of followup/ (not in subdirs, not hidden)."""
    if not followup_dir.is_dir():
        return False
    try:
        for entry in os.scandir(followup_dir):
            if not entry.is_file(follow_symlinks=False):
                continue
            name = entry.name
            if name.startswith("."):
                continue
            if not name.endswith(".md"):
                continue
            return True
    except OSError:
        return False
    return False


def _dp_next_wake_by_elapsed(ts_path: Path, now: int) -> bool:
    """FR4: scheduled <= now. Missing file → False. Corrupt → True (defensive)."""
    if not ts_path.exists():
        return False
    try:
        scheduled = int(ts_path.read_text().strip())
    except (ValueError, OSError):
        return True  # corrupt counter is treated as elapsed (FR4 defensive clause)
    return scheduled <= now


def _dp_read_skip_count(counter_path: Path) -> int:
    """FR5: read counter; missing/empty/non-integer all → 0."""
    if not counter_path.exists():
        return 0
    try:
        s = counter_path.read_text().strip()
        if not s:
            return 0
        return int(s)
    except (ValueError, OSError):
        return 0


def _dp_write_skip_count(counter_path: Path, n: int) -> bool:
    """FR5: atomic write via temp+os.replace. Returns False on I/O failure."""
    try:
        counter_path.parent.mkdir(parents=True, exist_ok=True)
        tmp = counter_path.with_suffix(counter_path.suffix + ".tmp")
        tmp.write_text(f"{n}\n", encoding="utf-8")
        os.replace(str(tmp), str(counter_path))
        return True
    except Exception as e:
        logger.warning("[dp] counter write failed for %s: %s", counter_path, e)
        try:
            # cleanup temp if it still exists
            tmp = counter_path.with_suffix(counter_path.suffix + ".tmp")
            tmp.unlink(missing_ok=True)
        except Exception:
            pass
        return False


def _dp_counter_failed_path(track_dir: Path) -> Path:
    """Sentinel file path indicating the prior tick's counter write failed.

    Used by FR5 counter-write-failure semantics — INV-COUNTER-FAILURE-LIVENESS.
    """
    return track_dir / "dispatch-counter-write-failed.flag"


def _dp_emit_skip_line(log_path: Path, ts: int, track: str) -> bool:
    """FR6: append a single TSV skip line to heartbeat.log.

    Format: `{ISO8601_UTC_TS}\\t{track}\\tskip\\t-\\n`
    Atomic via POSIX O_APPEND for writes ≤ PIPE_BUF.
    """
    iso = datetime.fromtimestamp(ts, tz=timezone.utc).strftime("%Y-%m-%dT%H-%M-%SZ")
    line = f"{iso}\t{track}\tskip\t-\n"
    try:
        log_path.parent.mkdir(parents=True, exist_ok=True)
        # O_APPEND mode "a" is POSIX-atomic for single writes ≤ PIPE_BUF
        with open(log_path, "a", encoding="utf-8") as f:
            f.write(line)
        return True
    except Exception as e:
        logger.warning("[dp] skip-line append failed for %s: %s", log_path, e)
        return False


# @scry.bind impl.dp_decide~91ec4b7c spec.dispatch-precheck~c8d8dff4#FR1
def dp_decide(track: str, now: int, *, root: Path | None = None) -> DPDecision:
    """FR1: compute fire-vs-skip decision from FR2/FR3/FR4/FR5 signals.

    Pure read: inspects filesystem only, does NOT mutate any state. Counter
    mutation and skip-line emission are dp_apply_decision's responsibility.

    INV-SINGLE-DECISION: returns DPDecision and nothing else.
    INV-ACYCLIC-WITH-S2-S3: no reference to S2/S3 specs or modules.
    """
    if root is None:
        root = _effective_project_root()
    track_dir = root / "agent" / "runtime" / "tracks" / track

    counter_path = track_dir / "dispatch-skip-count.txt"
    failed_flag = _dp_counter_failed_path(track_dir)
    counter_before = _dp_read_skip_count(counter_path)

    # FR5 counter-write-failure clause: prior tick's write failed → force fire
    # (INV-COUNTER-FAILURE-LIVENESS).
    if failed_flag.exists():
        return DPDecision(
            track=track,
            fire=True,
            reason="counter-write-failure liveness fallback (FR5)",
            now=now,
            counter_before=counter_before,
        )

    # FR2: inbox unread
    if _dp_inbox_unread(track_dir / "inbox"):
        return DPDecision(track, True, "unread inbox (FR2)", now, counter_before)

    # FR3: followup open
    if _dp_followup_open(track_dir / "followup"):
        return DPDecision(track, True, "open followup (FR3)", now, counter_before)

    # FR4: next-wake-by elapsed
    if _dp_next_wake_by_elapsed(track_dir / "next-wake-by.timestamp", now):
        return DPDecision(track, True, "next-wake-by elapsed (FR4)", now, counter_before)

    # FR5: dormancy override at N consecutive skips.
    # CT-6 codifies: counter reaches N (prior tick wrote N) → next tick fires.
    if counter_before >= DP_DORMANCY_THRESHOLD_N:
        return DPDecision(
            track=track,
            fire=True,
            reason=f"dormancy override (FR5, counter={counter_before}>=N={DP_DORMANCY_THRESHOLD_N})",
            now=now,
            counter_before=counter_before,
        )

    return DPDecision(
        track=track,
        fire=False,
        reason=f"no signal (counter={counter_before})",
        now=now,
        counter_before=counter_before,
    )


def dp_apply_decision(decision: DPDecision, *, root: Path | None = None) -> None:
    """Apply DP's decision: mutate counter and emit skip-line per FR5/FR6.

    On fire: reset counter to 0 (write 0\\n atomically). Clears counter-failed flag.
    On skip: emit skip-line, then increment counter by 1.

    Counter-write failure on skip path sets the failed-flag for next tick.
    Counter-write failure on fire path leaves the flag in current state
    (next tick will force fire again per FR5).
    """
    if root is None:
        root = _effective_project_root()
    track_dir = root / "agent" / "runtime" / "tracks" / decision.track
    counter_path = track_dir / "dispatch-skip-count.txt"
    failed_flag = _dp_counter_failed_path(track_dir)

    if decision.fire:
        # FR5: reset counter on any fire (signal or dormancy or counter-failure recovery)
        ok = _dp_write_skip_count(counter_path, 0)
        if ok:
            # Clear the counter-failed flag — write succeeded, normal state restored
            try:
                failed_flag.unlink(missing_ok=True)
            except Exception:
                pass
        # If reset failed, flag stays. Next tick will force-fire again.
        return

    # Skip path: emit skip-line first (FR6), then increment counter (FR5).
    # Order per implementer note: log first so the originator sees the skip
    # even if the counter write fails.
    log_path = root / DP_SKIP_LOG_REL
    _dp_emit_skip_line(log_path, decision.now, decision.track)

    new_count = decision.counter_before + 1
    ok = _dp_write_skip_count(counter_path, new_count)
    if not ok:
        # FR5 counter-write-failure clause: set sentinel so next tick force-fires.
        try:
            failed_flag.parent.mkdir(parents=True, exist_ok=True)
            failed_flag.write_text(f"{decision.now}\n", encoding="utf-8")
        except Exception as e:
            logger.warning("[dp] counter-failed sentinel write failed: %s", e)


def fire_if_signal_cli(track: str) -> int:
    """CLI: DP-gated wake fire for `track`.

    Pipeline (matches FR7/FR8/FR9 sequencing):
      1. fire_scheduled_tasks (may write inbox files for same-tick targeting)
      2. dp_decide → fire or skip (per spec.dispatch-precheck~c8d8dff4 FR1)
      3. legacy main signals (dialogue.md / wake.md / agent/inbox) can promote
         a skip to a fire — preserved as a backward-compat additional signal
         source layered ON TOP of DP. See callback to architect noting this
         interpretation.
      4. If skip: emit skip-line, increment counter, exit
      5. If fire: reset counter, acquire lock; on lock-contention exit
         silently; otherwise os.execvp to reflect-wake.

    Run as: python -m agent.lib.tick fire-if-signal <track>
    """
    root = _effective_project_root()
    track_dir = root / "agent" / "runtime" / "tracks" / track

    # Step 1: fire due scheduled tasks. May write to track inboxes (incl. this
    # track's own) so DP sees a fresh signal. Preserves DR6.
    _fire_scheduled_tasks(track_dir)

    # Step 2: DP decision (no lock yet — FR9 explicitly forbids DP touching lock)
    now = int(time.time())
    decision = dp_decide(track, now, root=root)

    # Step 3: main's legacy non-DP signals layer in as fire override
    if not decision.fire and track == "main":
        legacy_reason = _check_main_legacy_signals(root)
        if legacy_reason:
            decision = DPDecision(
                track=track,
                fire=True,
                reason=f"main-legacy: {legacy_reason}",
                now=now,
                counter_before=decision.counter_before,
            )

    if not decision.fire:
        # Step 4: skip path. Apply decision (emit skip-line + bump counter), exit.
        dp_apply_decision(decision, root=root)
        return 0

    # Step 5: fire path. Apply decision (reset counter), then acquire lock.
    dp_apply_decision(decision, root=root)

    fd = acquire_track_lock(track)
    if fd is None:
        # Lock contention (per FR9, CT-10) — supervisor not invoked but
        # counter already reset above. DP's decision was fire; counter follows
        # DP's decision, not the lock outcome.
        return 0

    # DR8: record round-robin state before exec (exec replaces this process)
    project = os.environ.get("REFLECT_PROJECT_ROOT", str(PROJECT_ROOT))
    _record_round_robin(track, project, "fired")

    # Pre-exec PID write: write our own PID to wake.lock BEFORE exec so that
    # Layer 1 in acquire_track_lock() sees a live PID during the startup window.
    #
    # The race: acquire_track_lock() opens wake.lock with mode "w" (truncating
    # it to 0 bytes) and flocks it. On exec(), O_CLOEXEC releases the flock and
    # leaves wake.lock as an empty file. During the 5–20 s of uv+Python startup
    # before wake.py writes its own PID, a concurrent tick reads the empty file,
    # hits ValueError, reaps the file, acquires a new flock, and fires a second
    # wake — both run concurrently.
    #
    # Fix: write this process's PID to the already-open fd now. After exec(),
    # this process becomes uv (same PID), so os.kill(pid, 0) returns True for
    # the entire startup window. The concurrent tick sees a live PID → blocks.
    # wake.py then overwrites with its own PID once it starts.
    try:
        fd.write(f"{os.getpid()}\n")
        fd.flush()
    except Exception as _pid_write_err:
        logger.warning("[lock] pre-exec PID write failed: %s", _pid_write_err)

    print(f"[{track}] firing: {decision.reason}", flush=True)
    os.environ["REFLECT_TRACK"] = track
    # exec inherits fd; lock releases when reflect-wake exits.
    os.execvp("uv", ["uv", "run", "reflect-wake"])
    # unreachable
    return 0


def _check_main_legacy_signals(root: Path) -> str:
    """Check main-track's legacy non-DP signal sources.

    DP's FR2/FR3/FR4 cover the per-track inbox / followup / next-wake-by.
    Main historically also fires on:
      - dialogue.md / wake.md mtime > last-wake (end timestamp)
      - agent/inbox/ presence (legacy global inbox, pre-P9 unification)

    These are layered on top of DP as additional fire sources (not within
    DP's contract, per INV-SINGLE-DECISION). Returns a non-empty reason
    string when one of these signals fires; empty string otherwise.

    The mtime check uses last-wake.timestamp (end), not last-wake-start, to
    preserve existing behavior — a fresh edit during a long-running wake
    will trigger the next wake.
    """
    main_dir = root / "agent" / "runtime" / "tracks" / "main"
    last_wake = _read_int(main_dir / "last-wake.timestamp", default=0) or 0

    # dialogue.md / wake.md mtime checks
    for shared in ("dialogue.md", "wake.md"):
        p = root / shared
        if p.is_file() and _mtime(p) > last_wake:
            return f"{shared} newer than last wake"

    # Legacy global inbox at agent/inbox/
    global_inbox = root / "agent" / "inbox"
    if _dp_inbox_unread(global_inbox):
        return "agent/inbox/ has unread .md"

    return ""


if __name__ == "__main__":
    import sys

    if len(sys.argv) >= 3 and sys.argv[1] == "fire-if-signal":
        sys.exit(fire_if_signal_cli(sys.argv[2]))

    print("usage: python -m agent.lib.tick fire-if-signal <track>", file=sys.stderr)
    sys.exit(2)
