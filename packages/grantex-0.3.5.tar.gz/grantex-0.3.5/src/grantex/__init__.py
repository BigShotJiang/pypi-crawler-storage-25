"""Grantex Python SDK — delegated authorization protocol for AI agents."""

from __future__ import annotations

from ._client import Grantex
from ._errors import (
    GrantexApiError,
    GrantexAuthError,
    GrantexError,
    GrantexNetworkError,
    GrantexTokenError,
)
from ._types import (
    RateLimit,
    Agent,
    RotateKeyResponse,
    SignupParams,
    SignupResponse,
    Anomaly,
    AuditEntry,
    AuthorizationRequest,
    AuthorizeParams,
    ChainIntegrity,
    DetectAnomaliesResponse,
    ListAnomaliesResponse,
    CheckoutResponse,
    ComplianceAuditExport,
    ComplianceExportAuditParams,
    ComplianceExportGrantsParams,
    ComplianceGrantsExport,
    ComplianceSummary,
    EvidencePack,
    EvidencePackMeta,
    EvidencePackParams,
    CreateCheckoutParams,
    CreatePortalParams,
    CreateWebhookParams,
    DelegateParams,
    ExchangeTokenParams,
    ExchangeTokenResponse,
    RefreshTokenParams,
    CreatePrincipalSessionParams,
    PrincipalSessionResponse,
    Grant,
    GrantTokenPayload,
    ListAgentsResponse,
    ListAuditParams,
    ListAuditResponse,
    ListGrantsParams,
    ListGrantsResponse,
    ListWebhooksResponse,
    LogAuditParams,
    CreatePolicyParams,
    ListPoliciesResponse,
    Policy,
    PortalResponse,
    SubscriptionStatus,
    UpdatePolicyParams,
    VerifiedGrant,
    VerifyGrantTokenOptions,
    VerifyTokenResponse,
    WebhookEndpoint,
    WebhookEndpointWithSecret,
    # SCIM
    ScimEmail,
    ScimUserMeta,
    ScimUser,
    ScimListResponse,
    CreateScimUserParams,
    ScimToken,
    ScimTokenWithSecret,
    ListScimTokensResponse,
    # SSO
    SsoConfig,
    CreateSsoConfigParams,
    SsoLoginResponse,
    SsoCallbackResponse,
    # Enterprise SSO
    SsoConnection,
    CreateSsoConnectionParams,
    UpdateSsoConnectionParams,
    ListSsoConnectionsResponse,
    SsoConnectionTestResult,
    SsoEnforcementParams,
    SsoEnforcementResponse,
    SsoSession,
    ListSsoSessionsResponse,
    SsoOidcCallbackParams,
    SsoSamlCallbackParams,
    SsoLdapCallbackParams,
    SsoCallbackResult,
    # Budgets
    AllocateBudgetParams,
    BudgetAllocation,
    DebitBudgetParams,
    DebitBudgetResponse,
    BudgetTransaction,
    BudgetTransactionsResponse,
    # Vault
    StoreCredentialParams,
    StoreCredentialResponse,
    VaultCredential,
    ListVaultCredentialsParams,
    ListVaultCredentialsResponse,
    ExchangeCredentialParams,
    ExchangeCredentialResponse,
    # WebAuthn / FIDO
    WebAuthnRegistrationOptions,
    WebAuthnRegistrationVerifyParams,
    WebAuthnCredential,
    ListWebAuthnCredentialsResponse,
    # Verifiable Credentials
    VerifiableCredentialRecord,
    ListCredentialsParams,
    ListCredentialsResponse,
    VCVerificationResult,
    # SD-JWT
    SDJWTPresentParams,
    SDJWTPresentResult,
    # Developer Settings
    UpdateDeveloperSettingsParams,
    UpdateDeveloperSettingsResponse,
    # Passports (MPP Agent Identity)
    MaxTransactionAmount,
    IssuePassportParams,
    IssuedPassportResponse,
    GetPassportResponse,
    RevokePassportResponse,
    ListPassportsParams,
    ListPassportsResponse,
)
from .resources._passports import PassportsClient
from .resources._events import EventsClient, GrantexEvent as GrantexStreamEvent, StreamOptions, Subscription

# ─── Aliases for cross-SDK naming consistency ────────────────────────────────
# The TypeScript SDK uses SsoConnectionListResponse / SsoSessionListResponse
# while the Python SDK uses ListSsoConnectionsResponse / ListSsoSessionsResponse.
# Expose both names so consumers can use either convention.
SsoConnectionListResponse = ListSsoConnectionsResponse
SsoSessionListResponse = ListSsoSessionsResponse

from ._pkce import PkceChallenge, generate_pkce
from ._verify import verify_grant_token
from ._webhook import verify_webhook_signature
from .manifest import ToolManifest, Permission, EnforceResult
from ._fastapi import GrantexEnforcer

__version__ = "0.1.6"

__all__ = [
    # Main client
    "Grantex",
    # Signup
    "SignupParams",
    "SignupResponse",
    "RotateKeyResponse",
    # PKCE
    "PkceChallenge",
    "generate_pkce",
    # Standalone verify
    "verify_grant_token",
    # Webhook signature verification
    "verify_webhook_signature",
    # Errors
    "GrantexError",
    "GrantexApiError",
    "GrantexAuthError",
    "GrantexTokenError",
    "GrantexNetworkError",
    # Rate Limits
    "RateLimit",
    # Types
    "Agent",
    "Anomaly",
    "AuditEntry",
    "DetectAnomaliesResponse",
    "ListAnomaliesResponse",
    "AuthorizationRequest",
    "AuthorizeParams",
    "ChainIntegrity",
    "CheckoutResponse",
    "ComplianceAuditExport",
    "EvidencePack",
    "EvidencePackMeta",
    "EvidencePackParams",
    "ComplianceExportAuditParams",
    "ComplianceExportGrantsParams",
    "ComplianceGrantsExport",
    "ComplianceSummary",
    "CreateCheckoutParams",
    "CreatePolicyParams",
    "CreatePortalParams",
    "CreateWebhookParams",
    "DelegateParams",
    "ExchangeTokenParams",
    "ExchangeTokenResponse",
    "RefreshTokenParams",
    "CreatePrincipalSessionParams",
    "PrincipalSessionResponse",
    "Grant",
    "GrantTokenPayload",
    "ListAgentsResponse",
    "ListAuditParams",
    "ListAuditResponse",
    "ListGrantsParams",
    "ListGrantsResponse",
    "ListPoliciesResponse",
    "ListWebhooksResponse",
    "LogAuditParams",
    "Policy",
    "PortalResponse",
    "SubscriptionStatus",
    "VerifiedGrant",
    "VerifyGrantTokenOptions",
    "UpdatePolicyParams",
    "VerifyTokenResponse",
    "WebhookEndpoint",
    "WebhookEndpointWithSecret",
    # SCIM
    "ScimEmail",
    "ScimUserMeta",
    "ScimUser",
    "ScimListResponse",
    "CreateScimUserParams",
    "ScimToken",
    "ScimTokenWithSecret",
    "ListScimTokensResponse",
    # SSO
    "SsoConfig",
    "CreateSsoConfigParams",
    "SsoLoginResponse",
    "SsoCallbackResponse",
    # Enterprise SSO
    "SsoConnection",
    "CreateSsoConnectionParams",
    "UpdateSsoConnectionParams",
    "ListSsoConnectionsResponse",
    "SsoConnectionTestResult",
    "SsoEnforcementParams",
    "SsoEnforcementResponse",
    "SsoSession",
    "ListSsoSessionsResponse",
    "SsoOidcCallbackParams",
    "SsoSamlCallbackParams",
    "SsoLdapCallbackParams",
    "SsoCallbackResult",
    # Enterprise SSO aliases (match TypeScript SDK naming)
    "SsoConnectionListResponse",
    "SsoSessionListResponse",
    # Budgets
    "AllocateBudgetParams",
    "BudgetAllocation",
    "DebitBudgetParams",
    "DebitBudgetResponse",
    "BudgetTransaction",
    "BudgetTransactionsResponse",
    # Vault
    "StoreCredentialParams",
    "StoreCredentialResponse",
    "VaultCredential",
    "ListVaultCredentialsParams",
    "ListVaultCredentialsResponse",
    "ExchangeCredentialParams",
    "ExchangeCredentialResponse",
    # WebAuthn / FIDO
    "WebAuthnRegistrationOptions",
    "WebAuthnRegistrationVerifyParams",
    "WebAuthnCredential",
    "ListWebAuthnCredentialsResponse",
    # Verifiable Credentials
    "VerifiableCredentialRecord",
    "ListCredentialsParams",
    "ListCredentialsResponse",
    "VCVerificationResult",
    # SD-JWT
    "SDJWTPresentParams",
    "SDJWTPresentResult",
    # Developer Settings
    "UpdateDeveloperSettingsParams",
    "UpdateDeveloperSettingsResponse",
    # Passports (MPP Agent Identity)
    "PassportsClient",
    "MaxTransactionAmount",
    "IssuePassportParams",
    "IssuedPassportResponse",
    "GetPassportResponse",
    "RevokePassportResponse",
    "ListPassportsParams",
    "ListPassportsResponse",
    # Events
    "EventsClient",
    "GrantexStreamEvent",
    "StreamOptions",
    "Subscription",
    # Scope Enforcement / Manifests
    "ToolManifest",
    "Permission",
    "EnforceResult",
    # FastAPI Integration
    "GrantexEnforcer",
    # Version
    "__version__",
]
