# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Dict, Optional
from typing_extensions import Literal, Required, TypedDict

__all__ = ["ComponentConfigParam"]


class ComponentConfigParam(TypedDict, total=False):
    """Configuration for a single component in a card."""

    component_type: Required[
        Literal[
            "categorical_bar",
            "choropleth",
            "data_table_chart",
            "financial_boxes",
            "generic_timeseries",
            "header",
            "heatmap",
            "histogram",
            "pie",
            "scatter",
            "table",
            "boxplot",
            "treemap",
            "waterfall",
            "bubble",
            "person_card",
            "timeline",
        ]
    ]
    """Component type:

    - bubble: Bubble chart (scatter plot with size dimension for 3-variable data)
    - categorical_bar: Bar chart with categorical x-axis (e.g., regions, products)
    - choropleth: Choropleth map showing geographic data with color intensity by
      region (US states or world)
    - data_table_chart: Bar chart with auto-generated data table below showing
      values
    - financial_boxes: Financial metric boxes with values and growth indicators
      (e.g., Revenue, EPS)
    - generic_timeseries: timeseries chart
    - header: Card header with title and description, automatically styled with
      theme
    - heatmap: 2D heatmap with color intensity representing values (e.g.,
      correlation matrix)
    - histogram: Histogram chart showing frequency distribution of values
    - person_card: Person profile card from an Exa person search result (includes
      career, education, and about tabs)
    - pie: Pie chart showing proportional data as slices of a circle
    - scatter: Scatter plot showing relationships between two continuous variables
    - table: Data table with configurable columns and rows
    - boxplot: Box plot showing statistical distributions (min, Q1, median, Q3, max)
    - treemap: Treemap chart showing hierarchical data as proportional rectangles
    - waterfall: Waterfall chart showing incremental positive/negative changes
      (e.g., income statement breakdown)
    """

    config: Required[Dict[str, object]]
    """Component configuration data"""

    component_variant: Optional[str]
    """Component variant (e.g., 'simple', 'financial')"""
