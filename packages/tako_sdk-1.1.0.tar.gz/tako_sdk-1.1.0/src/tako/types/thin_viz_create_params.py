# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable, Optional
from typing_extensions import Required, TypedDict

from .component_config_param import ComponentConfigParam

__all__ = ["ThinVizCreateParams"]


class ThinVizCreateParams(TypedDict, total=False):
    components: Required[Iterable[ComponentConfigParam]]
    """Full component configurations"""

    description: Optional[str]
    """Card description"""

    height: Optional[int]
    """Chart height in pixels.

    When set, overrides the default aspect-ratio-based height for all chart
    components in this card. Must be between 100 and 2000.
    """

    image_ttl_minutes: Optional[int]
    """Minutes to keep preview image available for download (ZDR only).

    Min 1, max 1440 (24h). When set on a ZDR card, a temporary preview image is
    generated and available for download until the TTL expires. Ignored for non-ZDR
    cards.
    """

    normalize_currencies: Optional[str]
    """Target ISO 4217 currency code (e.g., 'USD', 'EUR').

    When set, datasets with recognized currency units are converted to this currency
    using historical exchange rates. A methodology section is added explaining the
    conversion.
    """

    postmessage_embed: bool
    """
    When True, the embed iframe operates in postMessage mode: the parent page
    injects visualization_data via window.postMessage after the iframe loads, rather
    than having data inlined in the embed URL. The response will include
    embed_mode='postmessage' when this is True, or embed_mode='post' otherwise.
    """

    source: Optional[str]
    """Data source attribution (displayed in footer)"""

    title: Optional[str]
    """Card title (falls back to header component title)"""
