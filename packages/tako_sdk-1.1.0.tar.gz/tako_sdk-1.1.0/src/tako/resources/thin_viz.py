# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing import Iterable, Optional

import httpx

from ..types import thin_viz_create_params
from .._types import Body, Omit, Query, Headers, NotGiven, omit, not_given
from .._utils import maybe_transform, async_maybe_transform
from .._compat import cached_property
from .._resource import SyncAPIResource, AsyncAPIResource
from .._response import (
    to_raw_response_wrapper,
    to_streamed_response_wrapper,
    async_to_raw_response_wrapper,
    async_to_streamed_response_wrapper,
)
from .._base_client import make_request_options
from ..types.component_config_param import ComponentConfigParam
from ..types.thin_viz_create_response import ThinVizCreateResponse

__all__ = ["ThinVizResource", "AsyncThinVizResource"]


class ThinVizResource(SyncAPIResource):
    @cached_property
    def with_raw_response(self) -> ThinVizResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TakoData/tako-sdk#accessing-raw-response-data-eg-headers
        """
        return ThinVizResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> ThinVizResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TakoData/tako-sdk#with_streaming_response
        """
        return ThinVizResourceWithStreamingResponse(self)

    def create(
        self,
        *,
        components: Iterable[ComponentConfigParam],
        description: Optional[str] | Omit = omit,
        height: Optional[int] | Omit = omit,
        image_ttl_minutes: Optional[int] | Omit = omit,
        normalize_currencies: Optional[str] | Omit = omit,
        postmessage_embed: bool | Omit = omit,
        source: Optional[str] | Omit = omit,
        title: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ThinVizCreateResponse:
        """Create a visualization card directly from component configurations.

        Supported
        component types: header, generic_timeseries, categorical_bar, stock_boxes,
        financial_boxes, table.

        Args:
          components: Full component configurations

          description: Card description

          height: Chart height in pixels. When set, overrides the default aspect-ratio-based
              height for all chart components in this card. Must be between 100 and 2000.

          image_ttl_minutes: Minutes to keep preview image available for download (ZDR only). Min 1, max 1440
              (24h). When set on a ZDR card, a temporary preview image is generated and
              available for download until the TTL expires. Ignored for non-ZDR cards.

          normalize_currencies: Target ISO 4217 currency code (e.g., 'USD', 'EUR'). When set, datasets with
              recognized currency units are converted to this currency using historical
              exchange rates. A methodology section is added explaining the conversion.

          postmessage_embed: When True, the embed iframe operates in postMessage mode: the parent page
              injects visualization_data via window.postMessage after the iframe loads, rather
              than having data inlined in the embed URL. The response will include
              embed_mode='postmessage' when this is True, or embed_mode='post' otherwise.

          source: Data source attribution (displayed in footer)

          title: Card title (falls back to header component title)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return self._post(
            "/v1/thin_viz/create/",
            body=maybe_transform(
                {
                    "components": components,
                    "description": description,
                    "height": height,
                    "image_ttl_minutes": image_ttl_minutes,
                    "normalize_currencies": normalize_currencies,
                    "postmessage_embed": postmessage_embed,
                    "source": source,
                    "title": title,
                },
                thin_viz_create_params.ThinVizCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ThinVizCreateResponse,
        )


class AsyncThinVizResource(AsyncAPIResource):
    @cached_property
    def with_raw_response(self) -> AsyncThinVizResourceWithRawResponse:
        """
        This property can be used as a prefix for any HTTP method call to return
        the raw response object instead of the parsed content.

        For more information, see https://www.github.com/TakoData/tako-sdk#accessing-raw-response-data-eg-headers
        """
        return AsyncThinVizResourceWithRawResponse(self)

    @cached_property
    def with_streaming_response(self) -> AsyncThinVizResourceWithStreamingResponse:
        """
        An alternative to `.with_raw_response` that doesn't eagerly read the response body.

        For more information, see https://www.github.com/TakoData/tako-sdk#with_streaming_response
        """
        return AsyncThinVizResourceWithStreamingResponse(self)

    async def create(
        self,
        *,
        components: Iterable[ComponentConfigParam],
        description: Optional[str] | Omit = omit,
        height: Optional[int] | Omit = omit,
        image_ttl_minutes: Optional[int] | Omit = omit,
        normalize_currencies: Optional[str] | Omit = omit,
        postmessage_embed: bool | Omit = omit,
        source: Optional[str] | Omit = omit,
        title: Optional[str] | Omit = omit,
        # Use the following arguments if you need to pass additional parameters to the API that aren't available via kwargs.
        # The extra values given here take precedence over values defined on the client or passed to this method.
        extra_headers: Headers | None = None,
        extra_query: Query | None = None,
        extra_body: Body | None = None,
        timeout: float | httpx.Timeout | None | NotGiven = not_given,
    ) -> ThinVizCreateResponse:
        """Create a visualization card directly from component configurations.

        Supported
        component types: header, generic_timeseries, categorical_bar, stock_boxes,
        financial_boxes, table.

        Args:
          components: Full component configurations

          description: Card description

          height: Chart height in pixels. When set, overrides the default aspect-ratio-based
              height for all chart components in this card. Must be between 100 and 2000.

          image_ttl_minutes: Minutes to keep preview image available for download (ZDR only). Min 1, max 1440
              (24h). When set on a ZDR card, a temporary preview image is generated and
              available for download until the TTL expires. Ignored for non-ZDR cards.

          normalize_currencies: Target ISO 4217 currency code (e.g., 'USD', 'EUR'). When set, datasets with
              recognized currency units are converted to this currency using historical
              exchange rates. A methodology section is added explaining the conversion.

          postmessage_embed: When True, the embed iframe operates in postMessage mode: the parent page
              injects visualization_data via window.postMessage after the iframe loads, rather
              than having data inlined in the embed URL. The response will include
              embed_mode='postmessage' when this is True, or embed_mode='post' otherwise.

          source: Data source attribution (displayed in footer)

          title: Card title (falls back to header component title)

          extra_headers: Send extra headers

          extra_query: Add additional query parameters to the request

          extra_body: Add additional JSON properties to the request

          timeout: Override the client-level default timeout for this request, in seconds
        """
        return await self._post(
            "/v1/thin_viz/create/",
            body=await async_maybe_transform(
                {
                    "components": components,
                    "description": description,
                    "height": height,
                    "image_ttl_minutes": image_ttl_minutes,
                    "normalize_currencies": normalize_currencies,
                    "postmessage_embed": postmessage_embed,
                    "source": source,
                    "title": title,
                },
                thin_viz_create_params.ThinVizCreateParams,
            ),
            options=make_request_options(
                extra_headers=extra_headers, extra_query=extra_query, extra_body=extra_body, timeout=timeout
            ),
            cast_to=ThinVizCreateResponse,
        )


class ThinVizResourceWithRawResponse:
    def __init__(self, thin_viz: ThinVizResource) -> None:
        self._thin_viz = thin_viz

        self.create = to_raw_response_wrapper(
            thin_viz.create,
        )


class AsyncThinVizResourceWithRawResponse:
    def __init__(self, thin_viz: AsyncThinVizResource) -> None:
        self._thin_viz = thin_viz

        self.create = async_to_raw_response_wrapper(
            thin_viz.create,
        )


class ThinVizResourceWithStreamingResponse:
    def __init__(self, thin_viz: ThinVizResource) -> None:
        self._thin_viz = thin_viz

        self.create = to_streamed_response_wrapper(
            thin_viz.create,
        )


class AsyncThinVizResourceWithStreamingResponse:
    def __init__(self, thin_viz: AsyncThinVizResource) -> None:
        self._thin_viz = thin_viz

        self.create = async_to_streamed_response_wrapper(
            thin_viz.create,
        )
