# Changelog

## 1.1.0 (2026-05-22)

Full Changelog: [v1.0.0...v1.1.0](https://github.com/TakoData/tako-sdk/compare/v1.0.0...v1.1.0)

### Features

* **api:** manual updates ([b5e2b2c](https://github.com/TakoData/tako-sdk/commit/b5e2b2cb0481b746482347173d072041d7c9461b))

## 1.0.0 (2026-05-12)

Full Changelog: [v0.1.41...v1.0.0](https://github.com/TakoData/tako-sdk/compare/v0.1.41...v1.0.0)

### Features

* **agents:** add SSE streaming with auto-reconnect and per-agent subresources (TAKO-2850) ([#52](https://github.com/TakoData/tako-sdk/issues/52)) ([f680e0c](https://github.com/TakoData/tako-sdk/commit/f680e0c1d33a0b7f990acff1c63bf95260c20147))
* **api:** api update ([9c64482](https://github.com/TakoData/tako-sdk/commit/9c64482d87ad7d8027fb1ddbc034389a17ed8493))
* **api:** api update ([5a232f0](https://github.com/TakoData/tako-sdk/commit/5a232f00ab578c51d688ccc4852d2641545cb224))
* **api:** api update ([f790e68](https://github.com/TakoData/tako-sdk/commit/f790e68b2e1197af72e29556f313e7b7af8566c9))
* **api:** api update ([5b91d90](https://github.com/TakoData/tako-sdk/commit/5b91d900bee5537450ac4eb35eb7494bfa49df2f))
* **sdk:** migrate to Stainless-generated Python SDK (TAKO-2867) ([#49](https://github.com/TakoData/tako-sdk/issues/49)) ([26e040c](https://github.com/TakoData/tako-sdk/commit/26e040cf32ed6c7973f07e1d150cfb9a239f7731))


### Bug Fixes

* **client:** add missing f-string prefix in file type error message ([91a1dae](https://github.com/TakoData/tako-sdk/commit/91a1daea558468940bb5edf9ec4893fbdd26148f))
* widen retriable exceptions and fix reconnect last_seq threshold ([#57](https://github.com/TakoData/tako-sdk/issues/57)) ([bbd29e7](https://github.com/TakoData/tako-sdk/commit/bbd29e791277f8b3a8e19ac1e5de1496cadb5398))


### Chores

* configure stable releases and set manifest to 0.1.41 ([#54](https://github.com/TakoData/tako-sdk/issues/54)) ([a708608](https://github.com/TakoData/tako-sdk/commit/a708608966626f300e28781ee69af0f31b7fdb05))
* minimize custom code patch against generated branch ([#55](https://github.com/TakoData/tako-sdk/issues/55)) ([35094c6](https://github.com/TakoData/tako-sdk/commit/35094c68938e52e12368b209bf690b6f3f678df5))
* reduce custom code by moving examples and tests to monorepo ([#53](https://github.com/TakoData/tako-sdk/issues/53)) ([36ae026](https://github.com/TakoData/tako-sdk/commit/36ae026d943c1e2184f9b6b317de84bdb1c529f8))
* sync repo ([11faedc](https://github.com/TakoData/tako-sdk/commit/11faedcb09cc1dc67ffd346bc32b3f70bc6ec348))
* update SDK settings ([ea9481e](https://github.com/TakoData/tako-sdk/commit/ea9481e6b468cbc3fc352d840a7f5cc040933675))
* update SDK settings ([b73d758](https://github.com/TakoData/tako-sdk/commit/b73d7586719876ddafafd507556d9389aab5503a))


### Documentation

* add agent streaming section to README ([#56](https://github.com/TakoData/tako-sdk/issues/56)) ([f88d9fc](https://github.com/TakoData/tako-sdk/commit/f88d9fc73ed7c5004e1b2074d35d728519a59df6))
