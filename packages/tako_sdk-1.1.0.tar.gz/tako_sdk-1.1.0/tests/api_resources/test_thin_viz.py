# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

import os
from typing import Any, cast

import pytest

from tako import Tako, AsyncTako
from tako.types import ThinVizCreateResponse
from tests.utils import assert_matches_type

base_url = os.environ.get("TEST_API_BASE_URL", "http://127.0.0.1:4010")


class TestThinViz:
    parametrize = pytest.mark.parametrize("client", [False, True], indirect=True, ids=["loose", "strict"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create(self, client: Tako) -> None:
        thin_viz = client.thin_viz.create(
            components=[
                {
                    "component_type": "categorical_bar",
                    "config": {"foo": "bar"},
                }
            ],
        )
        assert_matches_type(ThinVizCreateResponse, thin_viz, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_method_create_with_all_params(self, client: Tako) -> None:
        thin_viz = client.thin_viz.create(
            components=[
                {
                    "component_type": "categorical_bar",
                    "config": {"foo": "bar"},
                    "component_variant": "component_variant",
                }
            ],
            description="description",
            height=100,
            image_ttl_minutes=1,
            normalize_currencies="normalize_currencies",
            postmessage_embed=True,
            source="source",
            title="title",
        )
        assert_matches_type(ThinVizCreateResponse, thin_viz, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_raw_response_create(self, client: Tako) -> None:
        response = client.thin_viz.with_raw_response.create(
            components=[
                {
                    "component_type": "categorical_bar",
                    "config": {"foo": "bar"},
                }
            ],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thin_viz = response.parse()
        assert_matches_type(ThinVizCreateResponse, thin_viz, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    def test_streaming_response_create(self, client: Tako) -> None:
        with client.thin_viz.with_streaming_response.create(
            components=[
                {
                    "component_type": "categorical_bar",
                    "config": {"foo": "bar"},
                }
            ],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thin_viz = response.parse()
            assert_matches_type(ThinVizCreateResponse, thin_viz, path=["response"])

        assert cast(Any, response.is_closed) is True


class TestAsyncThinViz:
    parametrize = pytest.mark.parametrize(
        "async_client", [False, True, {"http_client": "aiohttp"}], indirect=True, ids=["loose", "strict", "aiohttp"]
    )

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create(self, async_client: AsyncTako) -> None:
        thin_viz = await async_client.thin_viz.create(
            components=[
                {
                    "component_type": "categorical_bar",
                    "config": {"foo": "bar"},
                }
            ],
        )
        assert_matches_type(ThinVizCreateResponse, thin_viz, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_method_create_with_all_params(self, async_client: AsyncTako) -> None:
        thin_viz = await async_client.thin_viz.create(
            components=[
                {
                    "component_type": "categorical_bar",
                    "config": {"foo": "bar"},
                    "component_variant": "component_variant",
                }
            ],
            description="description",
            height=100,
            image_ttl_minutes=1,
            normalize_currencies="normalize_currencies",
            postmessage_embed=True,
            source="source",
            title="title",
        )
        assert_matches_type(ThinVizCreateResponse, thin_viz, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_raw_response_create(self, async_client: AsyncTako) -> None:
        response = await async_client.thin_viz.with_raw_response.create(
            components=[
                {
                    "component_type": "categorical_bar",
                    "config": {"foo": "bar"},
                }
            ],
        )

        assert response.is_closed is True
        assert response.http_request.headers.get("X-Stainless-Lang") == "python"
        thin_viz = await response.parse()
        assert_matches_type(ThinVizCreateResponse, thin_viz, path=["response"])

    @pytest.mark.skip(reason="Mock server tests are disabled")
    @parametrize
    async def test_streaming_response_create(self, async_client: AsyncTako) -> None:
        async with async_client.thin_viz.with_streaming_response.create(
            components=[
                {
                    "component_type": "categorical_bar",
                    "config": {"foo": "bar"},
                }
            ],
        ) as response:
            assert not response.is_closed
            assert response.http_request.headers.get("X-Stainless-Lang") == "python"

            thin_viz = await response.parse()
            assert_matches_type(ThinVizCreateResponse, thin_viz, path=["response"])

        assert cast(Any, response.is_closed) is True
