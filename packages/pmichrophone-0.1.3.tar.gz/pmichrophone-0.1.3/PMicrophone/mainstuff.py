# mylib/mic.py
import sounddevice as sd

def get_mic_list():
    return [d['name'] for d in sd.query_devices() if d['max_input_channels'] > 0]


def get_mic_info(name):
    for d in sd.query_devices():
        if d['name'] == name and d['max_input_channels'] > 0:
            return d
    return None


def get_default_mic():
    default = sd.default.device

    if isinstance(default, tuple):
        index = default[0]
    else:
        index = default

    if index is None:
        return None

    device = sd.query_devices(index)
    return device


def get_default_mic_name():
    mic = get_default_mic()
    return mic['name'] if mic else None


def get_default_mic_settings():
    mic = get_default_mic()
    if not mic:
        return None

    return {
        "samplerate": mic['default_samplerate'],
        "channels": mic['max_input_channels']
    }