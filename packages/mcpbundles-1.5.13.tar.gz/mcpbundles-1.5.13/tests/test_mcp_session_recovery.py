"""Integration test: in-band SSE 'Session has been terminated' triggers re-handshake.

This is the exact failure mode that surfaced as 'No matching response in SSE
stream' before the SessionExpired path was added: the server returns an
HTTP 200 with an SSE body containing `{"id": "server-error", "error":
{"message": "Session has been terminated"}}` instead of an HTTP 404.
"""

from __future__ import annotations

import json

import httpx
import pytest

from mcpbundles.mcp_client import MCPSession, _PROTOCOL_VERSION


class _SessionExpiredOnceTransport(httpx.AsyncBaseTransport):
    """Models a server that has evicted the cached session.

    Sequence on a freshly-instantiated session whose ``_session_id`` is
    pre-set (cache hit):

    1. Client posts tools/list with the stale id  → server returns 200
       SSE with the in-band "Session has been terminated" envelope.
    2. Client re-handshakes: initialize → server returns 200 JSON with a
       new mcp-session-id header.
    3. Client posts notifications/initialized → server returns 202.
    4. Client retries tools/list with the new session id → server
       returns 200 SSE with the real result.
    """

    def __init__(self, stale_sid: str, fresh_sid: str = "new-session-xyz") -> None:
        self.stale_sid = stale_sid
        self.fresh_sid = fresh_sid
        self.calls: list[tuple[str, dict[str, str], dict | None]] = []

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        try:
            payload = json.loads(request.content) if request.content else None
        except (ValueError, json.JSONDecodeError):
            payload = None
        sid = request.headers.get("mcp-session-id", "")
        self.calls.append((request.method, dict(request.headers), payload))

        if request.method == "DELETE":
            return httpx.Response(204)

        if payload and payload.get("method") == "initialize":
            return httpx.Response(
                200,
                headers={
                    "content-type": "application/json",
                    "mcp-session-id": self.fresh_sid,
                },
                json={
                    "jsonrpc": "2.0",
                    "id": payload["id"],
                    "result": {
                        "protocolVersion": _PROTOCOL_VERSION,
                        "capabilities": {},
                        "serverInfo": {"name": "test-server", "version": "0.1.0"},
                    },
                },
            )

        if payload and payload.get("method") == "notifications/initialized":
            return httpx.Response(202)

        if payload and payload.get("method") == "tools/list":
            if sid == self.stale_sid:
                body = (
                    'event: message\n'
                    'data: {"jsonrpc":"2.0","id":"server-error",'
                    '"error":{"code":-32600,'
                    '"message":"Not Found: Session has been terminated"}}\n\n'
                )
                return httpx.Response(
                    200,
                    headers={
                        "content-type": "text/event-stream",
                        "mcp-session-id": self.stale_sid,
                    },
                    content=body.encode(),
                )

            if sid == self.fresh_sid:
                req_id = payload["id"]
                resp_obj = {
                    "jsonrpc": "2.0",
                    "id": req_id,
                    "result": {"tools": [{"name": "x", "description": "x"}]},
                }
                body = f"event: message\ndata: {json.dumps(resp_obj)}\n\n"
                return httpx.Response(
                    200,
                    headers={
                        "content-type": "text/event-stream",
                        "mcp-session-id": self.fresh_sid,
                    },
                    content=body.encode(),
                )

        return httpx.Response(500, text=f"unexpected request: {request.method} sid={sid!r} body={payload!r}")


@pytest.mark.asyncio
async def test_in_band_session_terminated_triggers_rehandshake(monkeypatch, tmp_path) -> None:
    """The cache-poisoning failure mode resolves itself in one round-trip."""
    monkeypatch.setattr("mcpbundles.mcp_client.CONFIG_DIR", tmp_path)
    monkeypatch.setattr(
        "mcpbundles.mcp_client._SESSION_CACHE_FILE",
        tmp_path / "mcp_session_cache.json",
    )

    stale = "stale-session-abc"
    fresh = "fresh-session-xyz"
    transport = _SessionExpiredOnceTransport(stale_sid=stale, fresh_sid=fresh)

    async with httpx.AsyncClient(transport=transport) as client:
        session = MCPSession(
            client=client,
            url="https://test.example.com/hub/",
            session_id=stale,
            auth="bearer",
        )

        result = await session.list_tools()

    assert len(result.tools) == 1
    assert result.tools[0].name == "x"

    methods_and_endpoints = [
        (call[0], (call[2] or {}).get("method"))
        for call in transport.calls
    ]
    assert methods_and_endpoints == [
        ("POST", "tools/list"),  # rejected with in-band session-terminated
        ("POST", "initialize"),  # auto-recovery
        ("POST", "notifications/initialized"),
        ("POST", "tools/list"),  # retry succeeds
    ]
    assert session._session_id == fresh


@pytest.mark.asyncio
async def test_concurrent_expiry_collapses_to_single_handshake(monkeypatch, tmp_path) -> None:
    """N concurrent calls all observing expiry must produce exactly one handshake."""
    import asyncio

    monkeypatch.setattr("mcpbundles.mcp_client.CONFIG_DIR", tmp_path)
    monkeypatch.setattr(
        "mcpbundles.mcp_client._SESSION_CACHE_FILE",
        tmp_path / "mcp_session_cache.json",
    )

    stale = "stale-session-abc"
    fresh = "fresh-session-xyz"
    transport = _SessionExpiredOnceTransport(stale_sid=stale, fresh_sid=fresh)

    async with httpx.AsyncClient(transport=transport) as client:
        session = MCPSession(
            client=client,
            url="https://test.example.com/hub/",
            session_id=stale,
            auth="bearer",
        )

        results = await asyncio.gather(*[session.list_tools() for _ in range(8)])

    assert len(results) == 8
    for r in results:
        assert len(r.tools) == 1

    init_count = sum(
        1 for call in transport.calls
        if (call[2] or {}).get("method") == "initialize"
    )
    assert init_count == 1, (
        f"expected exactly one initialize call under lock; saw {init_count}"
    )
