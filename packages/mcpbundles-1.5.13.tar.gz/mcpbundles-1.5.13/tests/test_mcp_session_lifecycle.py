"""Spec-compliance tests for MCPSession handshake and termination.

Covers:

1. ``notifications/initialized`` MUST be awaited before ``_handshake``
   returns, so subsequent ``tools/list`` / ``tools/call`` requests cannot
   race ahead of the notification (MCP spec requires the server to receive
   it before any other client requests).

2. ``terminate()`` MUST issue an HTTP ``DELETE`` with the
   ``Mcp-Session-Id`` header when called explicitly, so the server can
   release session resources eagerly. The default ``hub_session()`` exit
   path does NOT call ``terminate()`` — this is what makes the on-disk
   session cache valuable across CLI invocations (see the docstring on
   ``MCPSession.terminate``).
"""

import json

import httpx
import pytest

from mcpbundles.mcp_client import MCPSession, _PROTOCOL_VERSION, hub_session


class _RecordingTransport(httpx.AsyncBaseTransport):
    """Captures every request the session makes, in order."""

    def __init__(self) -> None:
        self.calls: list[tuple[str, str, dict[str, str], dict | None]] = []

    async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
        try:
            payload = json.loads(request.content) if request.content else None
        except (ValueError, json.JSONDecodeError):
            payload = None
        self.calls.append((request.method, str(request.url), dict(request.headers), payload))

        if request.method == "DELETE":
            return httpx.Response(204)

        if payload and payload.get("method") == "initialize":
            return httpx.Response(
                200,
                headers={
                    "content-type": "application/json",
                    "mcp-session-id": "session-abc-123",
                },
                json={
                    "jsonrpc": "2.0",
                    "id": payload["id"],
                    "result": {
                        "protocolVersion": _PROTOCOL_VERSION,
                        "capabilities": {},
                        "serverInfo": {"name": "test-server", "version": "0.1.0"},
                    },
                },
            )

        if payload and payload.get("method") == "notifications/initialized":
            return httpx.Response(202)

        return httpx.Response(404)


@pytest.mark.asyncio
async def test_handshake_sends_initialize_then_awaited_initialized_notification() -> None:
    transport = _RecordingTransport()
    async with httpx.AsyncClient(transport=transport) as client:
        session = MCPSession(client=client, url="https://test.example.com/hub/", session_id="", auth="bearer")

        sid = await session._handshake()

        assert sid == "session-abc-123"
        methods = [(call[0], (call[3] or {}).get("method")) for call in transport.calls]
        assert methods == [
            ("POST", "initialize"),
            ("POST", "notifications/initialized"),
        ]
        notif_headers = transport.calls[1][2]
        assert notif_headers.get("mcp-session-id") == "session-abc-123"


@pytest.mark.asyncio
async def test_terminate_sends_delete_with_session_id() -> None:
    transport = _RecordingTransport()
    async with httpx.AsyncClient(transport=transport) as client:
        session = MCPSession(
            client=client,
            url="https://test.example.com/hub/",
            session_id="session-abc-123",
            auth="bearer",
        )

        await session.terminate()

        assert len(transport.calls) == 1
        method, url, headers, _payload = transport.calls[0]
        assert method == "DELETE"
        assert url == "https://test.example.com/hub/"
        assert headers.get("mcp-session-id") == "session-abc-123"


@pytest.mark.asyncio
async def test_terminate_with_no_session_id_is_noop() -> None:
    transport = _RecordingTransport()
    async with httpx.AsyncClient(transport=transport) as client:
        session = MCPSession(client=client, url="https://test.example.com/hub/", session_id="", auth="bearer")

        await session.terminate()

        assert transport.calls == []


@pytest.mark.asyncio
async def test_terminate_swallows_transport_errors() -> None:
    class _BoomTransport(httpx.AsyncBaseTransport):
        async def handle_async_request(self, request: httpx.Request) -> httpx.Response:
            raise httpx.ConnectError("network down")

    async with httpx.AsyncClient(transport=_BoomTransport()) as client:
        session = MCPSession(
            client=client,
            url="https://test.example.com/hub/",
            session_id="session-abc-123",
            auth="bearer",
        )
        await session.terminate()


@pytest.mark.asyncio
async def test_hub_session_default_exit_does_not_terminate(monkeypatch, tmp_path) -> None:
    """hub_session() exit path must NOT issue DELETE by default.

    Issuing DELETE on every CLI invocation would invalidate the on-disk
    session cache (next call gets HTTP 404 → handshake → ~400 ms back),
    defeating the cache. The server self-evicts via Redis TTL and the
    client self-heals via the 404 retry path in MCPSession._request, so
    skipping DELETE is safe.
    """
    monkeypatch.setattr("mcpbundles.mcp_client.CONFIG_DIR", tmp_path)
    monkeypatch.setattr(
        "mcpbundles.mcp_client._SESSION_CACHE_FILE",
        tmp_path / "mcp_session_cache.json",
    )

    transport = _RecordingTransport()
    real_async_client = httpx.AsyncClient

    def _client_factory(*args, **kwargs):
        kwargs["transport"] = transport
        return real_async_client(*args, **kwargs)

    monkeypatch.setattr("mcpbundles.mcp_client.httpx.AsyncClient", _client_factory)

    async with hub_session("bearer", "https://test.example.com", "/hub/") as _session:
        pass

    methods = [call[0] for call in transport.calls]
    assert "DELETE" not in methods, (
        f"hub_session() default exit must not call DELETE; saw {methods}"
    )


@pytest.mark.asyncio
async def test_hub_session_terminate_on_exit_does_delete(monkeypatch, tmp_path) -> None:
    """Opt-in path for explicit logout/disconnect surfaces."""
    monkeypatch.setattr("mcpbundles.mcp_client.CONFIG_DIR", tmp_path)
    monkeypatch.setattr(
        "mcpbundles.mcp_client._SESSION_CACHE_FILE",
        tmp_path / "mcp_session_cache.json",
    )

    transport = _RecordingTransport()
    real_async_client = httpx.AsyncClient

    def _client_factory(*args, **kwargs):
        kwargs["transport"] = transport
        return real_async_client(*args, **kwargs)

    monkeypatch.setattr("mcpbundles.mcp_client.httpx.AsyncClient", _client_factory)

    async with hub_session(
        "bearer", "https://test.example.com", "/hub/", terminate_on_exit=True
    ) as _session:
        pass

    methods = [call[0] for call in transport.calls]
    assert methods.count("DELETE") == 1
