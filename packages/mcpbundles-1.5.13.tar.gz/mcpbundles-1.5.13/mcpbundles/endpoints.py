"""MCP endpoint path resolution."""


def resolve_endpoint(bundle: str | None) -> str:
    """Return the MCP endpoint path for a bundle slug, or the hub default."""
    if bundle:
        return f"/bundle/{bundle}/"
    return "/hub/"
