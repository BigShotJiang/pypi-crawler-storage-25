"""Exit code constants for the MCPBundles CLI.

0 = success
1 = user/input error (bad args, missing auth, not found)
2 = tool execution error (tool returned isError=true)
3 = connection/server error (cannot reach server, 5xx)
4 = unexpected/internal error
"""

SUCCESS = 0
USER_ERROR = 1
TOOL_ERROR = 2
CONNECTION_ERROR = 3
INTERNAL_ERROR = 4
