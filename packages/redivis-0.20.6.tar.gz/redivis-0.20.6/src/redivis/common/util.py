import os
import tempfile
import atexit
import shutil
import pathlib
import uuid

from ..common import exceptions


def get_warning(kind):
    if kind == "dataframe_deprecation":
        return 'The to_dataframe() method is deprecated, and has been superceded by to_pandas_dataframe().\nBy default, this new method uses the "pyarrow" dtype_backend, which is more performant and will generally work with existing code.\nTo replicate historic behavior, use to_pandas_dataframe(dtype_backend="numpy").'
    elif kind == "geodataframe_deprecation":
        return "Please use the to_geopandas_dataframe() method to ensure future compatability."
    elif kind == "source_tables_deprecation":
        return "The source_tables() method has been renamed to referenced_tables(); please use this instead. This method will be removed in the future."
    else:
        return "WARNING"


created_temp_dir = None


def rm_tempdir():
    global created_temp_dir
    shutil.rmtree(created_temp_dir, ignore_errors=True)


def get_tempdir():
    if os.getenv("REDIVIS_TMPDIR"):
        user_suffix = os.environ.get("USER", os.environ.get("USERNAME")) or os.getuid()
        return str(
            pathlib.Path("/").joinpath(
                os.getenv("REDIVIS_TMPDIR"),
                f"redivis_{user_suffix}",
            )
        )

    global created_temp_dir
    if created_temp_dir is None:
        created_temp_dir = tempfile.mkdtemp()
        atexit.register(rm_tempdir)

    return created_temp_dir


def convert_data_to_parquet(data):
    temp_file_path = f"{get_tempdir()}/parquet/{uuid.uuid4()}"
    pathlib.Path(temp_file_path).parent.mkdir(exist_ok=True, parents=True)

    import geopandas
    import pandas as pd
    import pyarrow as pa
    import pyarrow.dataset as pa_dataset
    import pyarrow.parquet as pa_parquet
    from dask.dataframe import DataFrame as dask_df

    # IMPORTANT: we need to coerce all timestamps to us precision, since BQ doesn't support ns, and will then just load the timestamp as int64

    if isinstance(data, geopandas.GeoDataFrame):
        data.to_parquet(
            path=temp_file_path,
            coerce_timestamps="us",
            allow_truncated_timestamps=True,
            index=False,
        )
    elif isinstance(data, pd.DataFrame):
        data.to_parquet(
            path=temp_file_path,
            coerce_timestamps="us",
            allow_truncated_timestamps=True,
            index=False,
        )
    elif isinstance(data, pa_dataset.Dataset):
        pa_dataset.write_dataset(
            data,
            temp_file_path,
            format="parquet",
            basename_template="part-{i}.parquet",
            file_options=pa_dataset.ParquetFileFormat().make_write_options(
                coerce_timestamps="us",
                allow_truncated_timestamps=True,
            ),
            max_partitions=1,
        )
        temp_file_path = f"{temp_file_path}/part-0.parquet"
    elif isinstance(data, pa.Table):
        pa_parquet.write_table(
            data,
            temp_file_path,
            coerce_timestamps="us",
            allow_truncated_timestamps=True,
        )
    elif isinstance(data, dask_df):
        data.to_parquet(
            temp_file_path,
            write_index=False,
            coerce_timestamps="us",
            allow_truncated_timestamps=True,
        )
        temp_file_path = f"{temp_file_path}/part.0.parquet"
    else:
        # importing polars is causing an IllegalInstruction error on ARM + Docker. Import inline to avoid crashes elsewhwere
        # TODO: revert once fixed upstream
        import polars

        if isinstance(data, polars.LazyFrame):
            data.sink_parquet(temp_file_path)
        elif isinstance(data, polars.DataFrame):
            data.write_parquet(
                temp_file_path,
                use_pyarrow=True,
                pyarrow_options={
                    "coerce_timestamps": "us",
                    "allow_truncated_timestamps": True,
                },
            )
        else:
            raise exceptions.ValueError(
                "Unknown datatype provided. Must be an instance of pandas.DataFrame, pyarrow.Dataset, pyarrow.Table, dask.DataFrame, polars.LazyFrame, or polars.DataFrame"
            )

    return temp_file_path


def raise_api_error(response_json=None, response_text=None, response=None):
    status_code = response.status_code if response else response_json.get("status")
    error = response_json.get("error") if response_json else "api_error"
    description = (
        response_json.get("error_description") if response_json else response_text
    )
    if status_code == 404:
        raise exceptions.NotFoundError(
            message=error,
            status_code=404,
            error_description=description,
        ) from None
    elif status_code == 403:
        raise exceptions.AuthorizationError(
            message=error,
            status_code=403,
            error_description=description,
        ) from None
    else:
        raise exceptions.APIError(
            message=error,
            status_code=status_code,
            error_description=description,
        ) from None
