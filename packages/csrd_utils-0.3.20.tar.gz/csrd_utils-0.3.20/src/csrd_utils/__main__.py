"""Command-line interface for csrd-utils."""

import argparse
import json
from contextlib import suppress
from importlib.metadata import version
from pathlib import Path
from typing import TypedDict
from urllib.parse import urlparse

import yaml  # type: ignore[import-untyped]

from .audit import run_audit
from .augmentor import ServiceAugmentor
from .cluster import (
    PRESETS,
    ClusterSpec,
    ServiceSpec,
    generate_cluster,
    load_cluster_spec,
    normalize_cluster_spec,
)
from .doctor import run_doctor
from .generator import generate_service
from .resources import features_path


class GenerateServiceArgs(TypedDict):
    name: str
    output_dir: Path
    description: str
    port: int
    model_name: str
    model_name_plural: str
    has_database: bool
    database: str
    has_delegates: bool
    upstreams: str
    has_workers: bool
    broker: str
    has_caching: bool
    cache_backend: str
    has_structured_logging: bool
    overwrite_if_exists: bool


class GenerateClusterArgs(TypedDict):
    spec: ClusterSpec
    output_dir: Path
    overwrite_if_exists: bool


class GenerateWorkspaceArgs(TypedDict):
    name: str
    output_dir: Path
    overwrite_if_exists: bool
    generate: str


WORKSPACE_MARKER = ".csrd-workspace"
WORKSPACE_CLUSTER_SPEC = Path(".csrd") / "cluster.yaml"


def _workspace_services_dir(workspace_root: Path) -> Path:
    return workspace_root / "src"


def _prompt_text(label: str, default: str) -> str:
    value = input(f"{label} [{default}]: ").strip()
    return value or default


def _prompt_bool(label: str, default: bool) -> bool:
    suffix = "Y/n" if default else "y/N"
    value = input(f"{label} ({suffix}): ").strip().lower()
    if not value:
        return default
    return value in {"y", "yes", "true", "1"}


def _prompt_choice(label: str, choices: list[str], default: str) -> str:
    rendered = ", ".join(choices)
    while True:
        value = input(f"{label} [{default}] ({rendered}): ").strip().lower()
        if not value:
            return default
        if value in choices:
            return value
        # Try prefix matching
        matching = [choice for choice in choices if choice.startswith(value)]
        if len(matching) == 1:
            return matching[0]
        if len(matching) > 1:
            matching_str = ", ".join(matching)
            print(f"ERROR: Ambiguous choice '{value}'. Matches: {matching_str}")
        else:
            print(f"ERROR: Invalid choice '{value}'. Expected one of: {rendered}")


def _prompt_int(label: str, default: int) -> int:
    while True:
        value = input(f"{label} [{default}]: ").strip()
        if not value:
            return default
        try:
            return int(value)
        except ValueError:
            print("ERROR: Enter a valid integer")


def _print_cancelled() -> None:
    # Avoid surfacing a traceback if a second Ctrl-C lands while printing.
    with suppress(KeyboardInterrupt):
        print("\nCancelled.")


def _collect_new_service_config(args: argparse.Namespace) -> GenerateServiceArgs:
    explicit_interactive = getattr(args, "interactive", None)
    is_explicit_interactive = explicit_interactive is True
    interactive = (
        bool(explicit_interactive) if explicit_interactive is not None else args.name is None
    )

    # Non-interactive mode keeps current flag-driven behavior.
    if not interactive:
        has_database = args.database != "none"
        selected_database = "sqlite" if not has_database else args.database
        return GenerateServiceArgs(
            {
                "name": args.name,
                "output_dir": args.output,
                "description": args.description,
                "port": args.port,
                "model_name": args.model_name,
                "model_name_plural": args.model_name_plural,
                "has_database": has_database,
                "database": selected_database,
                "has_delegates": args.delegates,
                "upstreams": args.upstreams,
                "has_workers": args.workers,
                "broker": args.broker,
                "has_caching": args.caching,
                "cache_backend": args.cache_backend,
                "has_structured_logging": args.structured_logging,
                "overwrite_if_exists": args.force,
            }
        )

    print("Interactive mode: press Enter to accept defaults.")

    name = _prompt_text("Service name", args.name or "my-service")
    output_dir = Path(_prompt_text("Output directory", str(args.output)))
    description = _prompt_text("Service description", args.description)
    port = _prompt_int("HTTP port", args.port)
    model_name = _prompt_text("Model name", args.model_name)

    plural_default = args.model_name_plural
    if plural_default == "items" and model_name != "Item":
        plural_default = f"{model_name.lower()}s"
    model_name_plural = _prompt_text("Model name plural", plural_default)

    show_advanced = True
    if not is_explicit_interactive:
        show_advanced = _prompt_bool("Show advanced configuration options", False)

    if show_advanced:
        database = _prompt_choice(
            "Database", ["sqlite", "maria", "postgres", "none"], args.database
        )
        has_database = database != "none"
        has_delegates = _prompt_bool("Enable delegates", False)
        upstreams_default = args.upstreams
        if has_delegates and not upstreams_default:
            upstreams_default = "http://service-a:8080"
        upstreams = (
            _prompt_text("Delegates upstreams (comma-separated)", upstreams_default)
            if has_delegates
            else ""
        )
        has_workers = _prompt_bool("Enable workers", False)
        broker = (
            _prompt_choice("Worker broker", ["redis", "rabbitmq"], args.broker)
            if has_workers
            else args.broker
        )
        has_caching = _prompt_bool("Enable caching", False)
        cache_backend = (
            _prompt_choice("Cache backend", ["redis"], args.cache_backend)
            if has_caching
            else args.cache_backend
        )
        has_structured_logging = _prompt_bool("Enable structured logging", False)
        overwrite_if_exists = _prompt_bool("Overwrite if target exists", False)
    else:
        database = args.database
        has_database = database != "none"
        has_delegates = args.delegates
        upstreams = args.upstreams if has_delegates else ""
        has_workers = args.workers
        broker = args.broker
        has_caching = args.caching
        cache_backend = args.cache_backend
        has_structured_logging = args.structured_logging
        overwrite_if_exists = args.force

    selected_database = "sqlite" if not has_database else database

    return GenerateServiceArgs(
        {
            "name": name,
            "output_dir": output_dir,
            "description": description,
            "port": port,
            "model_name": model_name,
            "model_name_plural": model_name_plural,
            "has_database": has_database,
            "database": selected_database,
            "has_delegates": has_delegates,
            "upstreams": upstreams,
            "has_workers": has_workers,
            "broker": broker,
            "has_caching": has_caching,
            "cache_backend": cache_backend,
            "has_structured_logging": has_structured_logging,
            "overwrite_if_exists": overwrite_if_exists,
        }
    )


def _collect_new_cluster_config(args: argparse.Namespace) -> GenerateClusterArgs:
    if args.spec is not None:
        if not args.spec.is_file():
            raise ValueError(f"Spec file not found: {args.spec}")
        return GenerateClusterArgs(
            {
                "spec": load_cluster_spec(args.spec),
                "output_dir": args.output,
                "overwrite_if_exists": args.force,
            }
        )

    print("Interactive cluster mode: press Enter to accept defaults.")
    cluster_name = _prompt_text("Cluster name", args.name or "my-cluster")
    preset = _prompt_choice("Preset", list(PRESETS.keys()), args.preset)
    services: list[ServiceSpec] = []

    add_more = _prompt_bool("Add more services", False)
    index = 1
    default_port = 8091
    while add_more:
        print(f"Configuring service #{index}")
        service_name = _prompt_text("Service name", f"service-{index}")
        service_type = _prompt_choice(
            "Service type", ["db", "delegate", "worker", "platform"], "db"
        )
        service: ServiceSpec = {
            "name": service_name,
            "type": service_type,
            "port": _prompt_int("Service port", default_port),
        }

        if service_type == "db":
            service["database"] = _prompt_choice(
                "Database", ["sqlite", "maria", "postgres"], "sqlite"
            )
        elif service_type == "delegate":
            delegates_raw = _prompt_text("Delegates (comma-separated)", "")
            service["delegates"] = [
                entry.strip() for entry in delegates_raw.split(",") if entry.strip()
            ]
        elif service_type == "worker":
            service["broker"] = _prompt_choice("Broker", ["redis", "rabbitmq"], "redis")
        else:
            service["role"] = _prompt_text("Platform role", "custom")

        requires_raw = _prompt_text("Requires (comma-separated)", "")
        service["requires"] = [entry.strip() for entry in requires_raw.split(",") if entry.strip()]
        features_raw = _prompt_text("Features (comma-separated)", "")
        service["features"] = [entry.strip() for entry in features_raw.split(",") if entry.strip()]

        services.append(service)
        index += 1
        default_port += 1
        add_more = _prompt_bool("Add more services", False)

    return GenerateClusterArgs(
        {
            "spec": {
                "cluster": {"name": cluster_name, "preset": preset},
                "services": services,
            },
            "output_dir": args.output,
            "overwrite_if_exists": args.force,
        }
    )


def _collect_new_workspace_config(args: argparse.Namespace) -> GenerateWorkspaceArgs:
    name = args.name or _prompt_text("Workspace name", "my-workspace")
    output_dir = (
        args.output
        if args.name is not None
        else Path(_prompt_text("Output directory", str(args.output)))
    )
    generate = args.generate or _prompt_choice(
        "Generate in workspace now", ["none", "service", "cluster"], "none"
    )
    return GenerateWorkspaceArgs(
        {
            "name": name,
            "output_dir": output_dir,
            "overwrite_if_exists": args.force,
            "generate": generate,
        }
    )


def _create_workspace(config: GenerateWorkspaceArgs) -> Path:
    workspace_root = config["output_dir"].resolve() / config["name"]
    if workspace_root.exists() and not workspace_root.is_dir():
        raise FileExistsError(f"Target path exists and is not a directory: {workspace_root}")

    workspace_root.mkdir(parents=True, exist_ok=True)
    if any(workspace_root.iterdir()) and not config["overwrite_if_exists"]:
        raise FileExistsError(
            f"Target directory already exists and is not empty: {workspace_root}. Use --force to overwrite."
        )

    _write_workspace_marker(workspace_root)
    return workspace_root


def _default_service_namespace(output_dir: Path) -> argparse.Namespace:
    return argparse.Namespace(
        interactive=True,
        name=None,
        output=output_dir,
        description="A microservice using the csrd library stack",
        port=8080,
        model_name="Item",
        model_name_plural="items",
        database="none",
        delegates=False,
        upstreams="",
        workers=False,
        broker="redis",
        caching=False,
        cache_backend="redis",
        structured_logging=False,
        force=False,
    )


def _default_cluster_namespace(output_dir: Path) -> argparse.Namespace:
    return argparse.Namespace(
        spec=None,
        name=None,
        output=output_dir,
        preset="none",
        force=False,
    )


def _write_workspace_marker(path: Path) -> None:
    (path / WORKSPACE_MARKER).write_text("workspace: csrd\n", encoding="utf-8")


def _is_workspace(path: Path) -> bool:
    return (path / WORKSPACE_MARKER).is_file()


def _service_is_interactive(args: argparse.Namespace) -> bool:
    explicit_interactive = getattr(args, "interactive", None)
    return bool(explicit_interactive) if explicit_interactive is not None else args.name is None


def _ensure_workspace_for_output(output_dir: Path, allow_prompt: bool) -> Path:
    workspace_root = output_dir.resolve()
    if _is_workspace(workspace_root):
        return workspace_root

    if workspace_root.exists() and not workspace_root.is_dir():
        raise ValueError(f"Output path is not a directory: {workspace_root}")

    if allow_prompt:
        create_workspace = _prompt_bool(
            f"No workspace found at {workspace_root}. Create workspace marker here", True
        )
        if create_workspace:
            workspace_root.mkdir(parents=True, exist_ok=True)
            _write_workspace_marker(workspace_root)
            print(f"Generated workspace at: {workspace_root}")
            return workspace_root

    raise ValueError(
        "This command requires a csrd workspace. Run 'csrd new workspace' first or use a workspace output path."
    )


def _workspace_cluster_spec_path(workspace_root: Path) -> Path:
    return workspace_root / WORKSPACE_CLUSTER_SPEC


def _load_workspace_cluster_spec(workspace_root: Path) -> ClusterSpec:
    spec_path = _workspace_cluster_spec_path(workspace_root)
    if spec_path.is_file():
        return load_cluster_spec(spec_path)
    return {
        "cluster": {"name": workspace_root.name, "preset": "none"},
        "services": [],
    }


def _save_workspace_cluster_spec(workspace_root: Path, spec: ClusterSpec) -> None:
    spec_path = _workspace_cluster_spec_path(workspace_root)
    spec_path.parent.mkdir(parents=True, exist_ok=True)
    normalized = normalize_cluster_spec(spec)
    spec_path.write_text(yaml.safe_dump(normalized, sort_keys=False), encoding="utf-8")


def _delegate_targets_from_upstreams(raw_upstreams: str) -> list[str]:
    targets: list[str] = []
    for raw in [entry.strip() for entry in raw_upstreams.split(",") if entry.strip()]:
        parsed = urlparse(raw)
        if not parsed.hostname:
            raise ValueError(
                f"Unable to infer delegate target from upstream URL: {raw}. Use full URLs with hostnames."
            )
        targets.append(parsed.hostname)
    return targets


def _service_config_to_cluster_service(config: GenerateServiceArgs) -> ServiceSpec:
    has_database = config["has_database"]
    has_workers = config["has_workers"]
    has_delegates = config["has_delegates"]
    if has_workers and (has_database or has_delegates):
        raise ValueError(
            "Workspace cluster mapping does not support combining workers with database or delegates in one service."
        )

    service: ServiceSpec = {
        "name": config["name"],
        "port": config["port"],
        "features": [],
        "requires": [],
    }

    if has_database:
        service["type"] = "db"
        service["database"] = config["database"]
        if has_delegates:
            targets = _delegate_targets_from_upstreams(config["upstreams"])
            service["delegates"] = targets
            service["requires"] = list(targets)
    elif has_workers:
        service["type"] = "worker"
        service["broker"] = config["broker"]
        service["requires"] = ["redis" if config["broker"] == "redis" else "rabbitmq"]
    elif has_delegates:
        targets = _delegate_targets_from_upstreams(config["upstreams"])
        service["type"] = "delegate"
        service["delegates"] = targets
        service["requires"] = list(targets)
    else:
        service["type"] = "platform"
        service["role"] = "custom"

    if config["has_caching"]:
        service["features"].append("caching")
    if config["has_structured_logging"]:
        service["features"].append("logging")

    return service


def _append_service_to_workspace_cluster(
    workspace_root: Path, config: GenerateServiceArgs
) -> ClusterSpec:
    spec = _load_workspace_cluster_spec(workspace_root)
    service_names = {str(service.get("name", "")).strip() for service in spec.get("services", [])}
    if config["name"] in service_names:
        raise ValueError(f"Service '{config['name']}' already exists in workspace cluster spec")

    spec["services"].append(_service_config_to_cluster_service(config))
    normalized = normalize_cluster_spec(spec)
    _save_workspace_cluster_spec(workspace_root, normalized)
    return normalized


def _workspace_service_roots(workspace_root: Path) -> list[Path]:
    roots: set[Path] = set()

    def _collect_from(base_dir: Path, skip_names: set[str] | None = None) -> None:
        if not base_dir.is_dir():
            return
        for child in base_dir.iterdir():
            if not child.is_dir() or child.name.startswith("."):
                continue
            if skip_names and child.name in skip_names:
                continue
            if (
                (child / "src" / "app").is_dir()
                and (child / "tests").is_dir()
                and (child / "requirements.txt").is_file()
            ):
                roots.add(child.resolve())

    services_root = _workspace_services_dir(workspace_root)
    _collect_from(services_root)
    # Legacy fallback: older workspaces stored services at workspace root.
    _collect_from(workspace_root, skip_names={"src"})
    return sorted(roots)


def _resolve_feature_service_root(service_arg: Path) -> Path:
    candidate = service_arg.resolve()
    if not _is_workspace(candidate):
        return candidate

    service_roots = _workspace_service_roots(candidate)
    if len(service_roots) == 1:
        return service_roots[0]
    if not service_roots:
        raise ValueError("No services found in workspace. Pass --service with a service root path.")
    raise ValueError(
        "Multiple services found in workspace. Pass --service with a specific service root path."
    )


def _workspace_root_for_service(service_root: Path) -> Path | None:
    parent = service_root.parent
    if parent.name == "src" and _is_workspace(parent.parent):
        return parent.parent
    return None


def _infer_port_from_compose(compose_path: Path, service_name: str | None = None) -> int:
    try:
        payload = yaml.safe_load(compose_path.read_text(encoding="utf-8"))
    except (OSError, yaml.YAMLError):
        return 8080

    if not isinstance(payload, dict):
        return 8080
    services = payload.get("services")
    if not isinstance(services, dict) or not services:
        return 8080

    selected: object
    if service_name and service_name in services:
        selected = services[service_name]
    else:
        selected = next(iter(services.values()))
    if not isinstance(selected, dict):
        return 8080

    ports = selected.get("ports")
    if not isinstance(ports, list) or not ports:
        return 8080

    first_port = ports[0]
    if isinstance(first_port, int):
        return first_port
    if isinstance(first_port, str):
        host_port = first_port.split(":", maxsplit=1)[0].strip()
        if host_port.isdigit():
            return int(host_port)
    return 8080


def _infer_port_from_service_root(service_root: Path) -> int:
    service_compose = service_root / "docker-compose.yml"
    if service_compose.is_file():
        return _infer_port_from_compose(service_compose)

    workspace_root = _workspace_root_for_service(service_root)
    if workspace_root is not None:
        return _infer_port_from_compose(workspace_root / "docker-compose.yml", service_root.name)
    return 8080


def _infer_existing_workspace_service(service_root: Path) -> ServiceSpec:
    return {
        "name": service_root.name,
        "type": "platform",
        "role": "custom",
        "port": _infer_port_from_service_root(service_root),
        "features": [],
        "requires": [],
    }


def _ensure_unique_ports(services: list[ServiceSpec], preserve_name: str) -> None:
    preserve = next((service for service in services if service["name"] == preserve_name), None)
    used: set[int] = set()
    if preserve is not None:
        used.add(int(preserve["port"]))

    for service in services:
        if service["name"] == preserve_name:
            continue
        port = int(service["port"])
        while port in used:
            port += 1
        service["port"] = port
        used.add(port)


def _maybe_update_workspace_cluster(
    workspace_root: Path,
    service_config: GenerateServiceArgs,
    generated_service: Path,
) -> Path | None:
    spec_path = _workspace_cluster_spec_path(workspace_root)
    if spec_path.is_file():
        updated_spec = _append_service_to_workspace_cluster(workspace_root, service_config)
        return generate_cluster(updated_spec, workspace_root, force=True, workspace_mode=True)

    service_roots = _workspace_service_roots(workspace_root)
    generated_name = generated_service.name
    services: list[ServiceSpec] = [_service_config_to_cluster_service(service_config)]
    for service_root in service_roots:
        if service_root.name != generated_name:
            services.append(_infer_existing_workspace_service(service_root))

    _ensure_unique_ports(services, preserve_name=generated_name)

    bootstrap_spec: ClusterSpec = {
        "cluster": {"name": workspace_root.name, "preset": "none"},
        "services": services,
    }
    normalized = normalize_cluster_spec(bootstrap_spec)
    _save_workspace_cluster_spec(workspace_root, normalized)
    return generate_cluster(normalized, workspace_root, force=True, workspace_mode=True)


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(prog="csrd", description="csrd utilities")
    parser.add_argument(
        "-v",
        "--version",
        action="version",
        version=f"csrd-utils {version('csrd-utils')}",
    )
    sub = parser.add_subparsers(dest="command", required=True)

    feature = sub.add_parser("feature", help="Feature operations")
    feature_sub = feature.add_subparsers(dest="feature_command", required=True)

    list_cmd = feature_sub.add_parser("list", help="List bundled features")
    list_cmd.set_defaults(plan=False)

    for name, plan in (("add", False), ("plan", True)):
        cmd = feature_sub.add_parser(name, help=f"{name} feature")
        cmd.add_argument("feature", help="Feature name, e.g. workers")
        cmd.add_argument("--service", type=Path, default=Path.cwd(), help="Service root path")
        if name == "plan":
            cmd.add_argument("--json", action="store_true", help="Print plan as JSON")
        cmd.set_defaults(plan=plan)

    doctor = sub.add_parser("doctor", help="Validate service compatibility")
    doctor.add_argument("--service", type=Path, default=Path.cwd(), help="Service root path")
    doctor.add_argument("--json", action="store_true", help="Print doctor report as JSON")

    audit = sub.add_parser("audit", help="Audit weak or insecure service defaults")
    audit.add_argument(
        "--service",
        type=Path,
        default=None,
        help="Optional single-service path; if omitted and cwd is workspace, all workspace services are audited",
    )
    audit.add_argument("--json", action="store_true", help="Print audit report as JSON")

    new = sub.add_parser("new", help="Generate new assets")
    new_sub = new.add_subparsers(dest="new_command", required=True)
    service = new_sub.add_parser("service", help="Generate a service from bundled template")
    service.add_argument("--name", help="Service name")
    service.add_argument("--output", type=Path, default=Path.cwd(), help="Output directory")
    service.add_argument(
        "--description",
        default="A microservice using the csrd library stack",
        help="Service description",
    )
    service.add_argument("--port", type=int, default=8080, help="HTTP service port")
    service.add_argument("--model-name", default="Item", help="Primary model name")
    service.add_argument("--model-name-plural", default="items", help="Plural model name")
    service.add_argument(
        "--database", choices=["sqlite", "maria", "postgres", "none"], default="none"
    )
    service.add_argument("--delegates", action="store_true", help="Enable delegates")
    service.add_argument("--upstreams", default="", help="Comma-separated upstream URLs")
    service.add_argument("--workers", action="store_true", help="Enable workers")
    service.add_argument("--broker", choices=["redis", "rabbitmq"], default="redis")
    service.add_argument("--caching", action="store_true", help="Enable caching")
    service.add_argument("--cache-backend", choices=["redis"], default="redis")
    service.add_argument(
        "--structured-logging",
        dest="structured_logging",
        action="store_true",
        default=False,
        help="Enable structured logging",
    )
    service.add_argument(
        "--no-structured-logging",
        dest="structured_logging",
        action="store_false",
        help="Disable structured logging",
    )
    service.add_argument("--interactive", dest="interactive", action="store_true", default=None)
    service.add_argument("--no-interactive", dest="interactive", action="store_false")
    service.add_argument("--force", action="store_true", help="Overwrite existing generated path")

    cluster = new_sub.add_parser("cluster", help="Generate a cluster scaffold from spec or prompts")
    cluster.add_argument("--name", help="Cluster name (used in interactive mode)")
    cluster.add_argument("--spec", type=Path, help="Path to cluster YAML spec")
    cluster.add_argument("--output", type=Path, default=Path.cwd(), help="Output directory")
    cluster.add_argument(
        "--preset",
        choices=list(PRESETS.keys()),
        default="none",
        help="Interactive preset to seed platform services",
    )
    cluster.add_argument("--force", action="store_true", help="Overwrite existing generated path")

    workspace = new_sub.add_parser(
        "workspace", help="Create an empty workspace and optionally generate service/cluster"
    )
    workspace.add_argument("--name", help="Workspace directory name")
    workspace.add_argument("--output", type=Path, default=Path.cwd(), help="Output directory")
    workspace.add_argument(
        "--generate",
        choices=["none", "service", "cluster"],
        help="Generate an asset inside the workspace after creation",
    )
    workspace.add_argument("--force", action="store_true", help="Overwrite existing workspace path")

    return parser


def _list_features() -> int:
    with features_path() as feature_lib:
        names = sorted(
            path.name
            for path in feature_lib.iterdir()
            if path.is_dir() and (path / "manifest.yaml").exists()
        )
    if not names:
        print("No bundled features found.")
        return 1
    for name in names:
        print(name)
    return 0


def _run_doctor(service: Path, as_json: bool) -> int:
    report = run_doctor(service)
    payload = {
        "ok": report.ok,
        "errors": report.errors,
        "warnings": report.warnings,
    }
    if as_json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        if report.ok:
            print("Doctor check passed.")
        else:
            print("Doctor check failed.")
        for err in report.errors:
            print(f"ERROR: {err}")
        for warning in report.warnings:
            print(f"WARN: {warning}")
    return 0 if report.ok else 1


def _run_audit(service: Path | None, as_json: bool) -> int:
    target = service.resolve() if service is not None else Path.cwd().resolve()

    if _is_workspace(target):
        service_roots = _workspace_service_roots(target)
        service_reports: list[dict[str, object]] = []
        has_high = False
        for service_root in service_roots:
            report = run_audit(service_root)
            has_high = has_high or not report.ok
            service_reports.append(
                {
                    "service": service_root.name,
                    "path": str(service_root),
                    **report.to_payload(),
                }
            )

        payload = {
            "ok": not has_high,
            "mode": "workspace",
            "workspace": str(target),
            "services": service_reports,
            "summary": {
                "services_scanned": len(service_reports),
                "services_with_high": sum(
                    1
                    for service_report in service_reports
                    if isinstance(service_report.get("ok"), bool) and not service_report["ok"]
                ),
            },
        }
    else:
        report = run_audit(target)
        payload = {
            "mode": "service",
            "service": str(target),
            **report.to_payload(),
        }

    if as_json:
        print(json.dumps(payload, indent=2, sort_keys=True))
    else:
        if payload["ok"]:
            print("Audit passed (no high-severity findings).")
        else:
            print("Audit failed (high-severity findings detected).")

        if payload.get("mode") == "workspace":
            print(f"Workspace: {payload['workspace']}")
            services = payload.get("services", [])
            if isinstance(services, list):
                for service_report in services:
                    if not isinstance(service_report, dict):
                        continue
                    state = "OK" if service_report.get("ok") else "FAIL"
                    print(f"- {service_report.get('service', '<unknown>')}: {state}")
                    findings = service_report.get("findings", [])
                    if isinstance(findings, list):
                        for finding in findings:
                            if not isinstance(finding, dict):
                                continue
                            print(
                                f"  {str(finding.get('severity', '')).upper()}: "
                                f"[{finding.get('rule')}] {finding.get('file')} :: {finding.get('message')}"
                            )
                            print(f"    evidence: {finding.get('evidence')}")
                            print(f"    fix: {finding.get('remediation')}")
        else:
            findings = payload.get("findings", [])
            if isinstance(findings, list):
                for finding in findings:
                    if not isinstance(finding, dict):
                        continue
                    print(
                        f"{str(finding.get('severity', '')).upper()}: "
                        f"[{finding.get('rule')}] {finding.get('file')} :: {finding.get('message')}"
                    )
                    print(f"  evidence: {finding.get('evidence')}")
                    print(f"  fix: {finding.get('remediation')}")

    return 0 if bool(payload["ok"]) else 1


def main() -> int:
    parser = _build_parser()
    args = parser.parse_args()

    if args.command == "new" and args.new_command == "service":
        try:
            service_config = _collect_new_service_config(args)
            workspace_root = _ensure_workspace_for_output(
                service_config["output_dir"], allow_prompt=_service_is_interactive(args)
            )
            service_config["output_dir"] = _workspace_services_dir(workspace_root)
            generated = generate_service(**service_config)
            generated_cluster = _maybe_update_workspace_cluster(
                workspace_root, service_config, generated
            )
            if generated_cluster is not None:
                print(f"Refreshed cluster scaffold at: {generated_cluster}")
        except (FileExistsError, ValueError) as exc:
            print(f"ERROR: {exc}")
            return 1
        except KeyboardInterrupt:
            _print_cancelled()
            return 1
        print(f"Generated service at: {generated}")
        return 0

    if args.command == "new" and args.new_command == "cluster":
        try:
            cluster_config = _collect_new_cluster_config(args)
            cluster_config["output_dir"] = _ensure_workspace_for_output(
                cluster_config["output_dir"], allow_prompt=args.spec is None
            )
            generated = generate_cluster(
                cluster_config["spec"],
                cluster_config["output_dir"],
                force=cluster_config["overwrite_if_exists"],
            )
            _save_workspace_cluster_spec(cluster_config["output_dir"], cluster_config["spec"])
        except (FileExistsError, FileNotFoundError, ValueError) as exc:
            print(f"ERROR: {exc}")
            return 1
        except KeyboardInterrupt:
            _print_cancelled()
            return 1
        print(f"Generated cluster at: {generated}")
        return 0

    if args.command == "new" and args.new_command == "workspace":
        try:
            workspace_config = _collect_new_workspace_config(args)
            workspace_root = _create_workspace(workspace_config)
            print(f"Generated workspace at: {workspace_root}")

            generate_mode = workspace_config["generate"]
            if generate_mode == "service":
                service_config = _collect_new_service_config(
                    _default_service_namespace(_workspace_services_dir(workspace_root))
                )
                service_config["output_dir"] = _workspace_services_dir(workspace_root)
                generated_service = generate_service(**service_config)
                generated_cluster = _maybe_update_workspace_cluster(
                    workspace_root, service_config, generated_service
                )
                if generated_cluster is not None:
                    print(f"Refreshed cluster scaffold at: {generated_cluster}")
                print(f"Generated service at: {generated_service}")
            elif generate_mode == "cluster":
                cluster_config = _collect_new_cluster_config(
                    _default_cluster_namespace(workspace_root)
                )
                cluster_config["output_dir"] = workspace_root
                generated_cluster = generate_cluster(
                    cluster_config["spec"],
                    cluster_config["output_dir"],
                    force=cluster_config["overwrite_if_exists"],
                )
                print(f"Generated cluster at: {generated_cluster}")
        except (FileExistsError, FileNotFoundError, ValueError) as exc:
            print(f"ERROR: {exc}")
            return 1
        except KeyboardInterrupt:
            _print_cancelled()
            return 1
        return 0

    if args.command == "doctor":
        return _run_doctor(args.service, args.json)

    if args.command == "audit":
        return _run_audit(args.service, args.json)

    if args.command != "feature" or args.feature_command not in {"add", "plan", "list"}:
        parser.print_help()
        return 0

    if args.feature_command == "list":
        return _list_features()

    try:
        resolved_service = _resolve_feature_service_root(args.service)
    except ValueError as exc:
        print(f"ERROR: {exc}")
        return 1

    with features_path() as feature_lib:
        augmentor = ServiceAugmentor(resolved_service, feature_lib)
        if args.feature_command == "plan" and args.json:
            plan = augmentor.build_plan(args.feature)
            if plan is None:
                return 1
            print(
                json.dumps(
                    {
                        "feature": args.feature,
                        "service": str(resolved_service),
                        "modifies": plan["modifies"],
                        "creates": plan["creates"],
                    },
                    indent=2,
                    sort_keys=True,
                )
            )
            return 0
        success, changes = augmentor.add_feature(args.feature, plan=args.plan)

    if not success:
        return 1

    if args.plan:
        print("Plan validated.")
    else:
        print(f"Feature '{args.feature}' added.")
        if changes:
            for change in changes:
                print(f"- {change}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
