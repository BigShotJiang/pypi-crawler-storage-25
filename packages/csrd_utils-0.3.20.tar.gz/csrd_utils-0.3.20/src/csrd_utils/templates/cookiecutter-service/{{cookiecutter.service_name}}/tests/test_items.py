"""Tests for {{ cookiecutter.service_name }} starter endpoints."""


def test_health(client):
    response = client.get("/health")
    assert response.status_code == 200
    assert response.json() == {"status": "ok", "service": "{{ cookiecutter.service_name }}"}


{%- if cookiecutter.has_database or not cookiecutter.has_delegates %}
def test_create_item_returns_data(client):
    create_response = client.post(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}", json={"name": "Test Item"}
    )
    assert create_response.status_code == 200
    item = create_response.json()
    assert item["name"] == "Test Item"
    assert "id" in item
    assert "created_at" in item


def test_list_items(client):
    client.post("/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}", json={"name": "Item 1"})
    client.post("/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}", json={"name": "Item 2"})

    response = client.get("/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}")
    assert response.status_code == 200
    items = response.json()["{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}"]
    names = {item["name"] for item in items}
    assert "Item 1" in names
    assert "Item 2" in names


def test_get_item_missing_returns_404(client):
    response = client.get("/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/missing-id")
    assert response.status_code == 404


def test_update_and_delete_item(client):
    created = client.post(
        "/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}", json={"name": "Original"}
    ).json()
    item_id = created["id"]

    updated = client.put(
        f"/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/{item_id}",
        json={"name": "Updated"},
    )
    assert updated.status_code == 200
    assert updated.json()["updated"] is True

    deleted = client.delete(f"/api/{{ cookiecutter.model_name_plural | lower | replace(' ', '_') }}/{item_id}")
    assert deleted.status_code == 200
    assert deleted.json()["deleted"] is True
{%- endif %}
