import json
import os
import tempfile
import unittest
from collections import Counter
from bpe_from_scratch import ByteLevelBPE


class TestEncodeToBytes(unittest.TestCase):
    def setUp(self):
        self.bpe = ByteLevelBPE()

    def test_basic_ascii(self):
        """ASCII text encodes to identical bytes."""
        self.assertEqual(self.bpe.encode_to_bytes("hello"), b"hello")

    def test_unicode_normalization(self):
        """Decomposed and precomposed forms produce the same bytes under NFC."""
        # Both decomposed (e + combining accent U+0301) and precomposed (U+00E9)
        # must normalize via NFC to the same single codepoint and produce
        # identical UTF-8 bytes: 0xC3 0xA9.
        expected = "\u00e9".encode("utf-8")  # b'\xc3\xa9'
        self.assertEqual(self.bpe.encode_to_bytes("e\u0301", normalize=True), expected)  # decomposed → NFC
        self.assertEqual(self.bpe.encode_to_bytes("\u00e9", normalize=True), expected)   # precomposed unchanged

    def test_normalize_default_is_false(self):
        """Default normalize=False preserves decomposed form."""
        # Default normalize=False: decomposed form is preserved as-is
        decomposed_bytes = "e\u0301".encode("utf-8")  # b'e\xcc\x81'
        self.assertEqual(self.bpe.encode_to_bytes("e\u0301"), decomposed_bytes)

    def test_normalization_disabled(self):
        """Explicit normalize=False keeps raw UTF-8 bytes."""
        decomposed = self.bpe.encode_to_bytes("e\u0301", normalize=False)
        self.assertEqual(decomposed, "e\u0301".encode("utf-8"))

    def test_non_ascii_utf8(self):
        """Multi-byte UTF-8 characters encode correctly."""
        self.assertEqual(self.bpe.encode_to_bytes("日本語"), "日本語".encode("utf-8"))

    def test_type_error_on_non_str(self):
        """Non-string input raises TypeError."""
        with self.assertRaises(TypeError):
            self.bpe.encode_to_bytes(123)

    def test_empty_string_raises(self):
        """Empty string raises ValueError."""
        with self.assertRaises(ValueError):
            self.bpe.encode_to_bytes("")
    def test_one_byte_characters(self):
        """Every ASCII character encodes to a single byte."""
        # All ASCII characters should encode to single bytes, e.g. "A" (0x41) → b'\x41'
        for i in range(128):
            char = chr(i)
            self.assertEqual(self.bpe.encode_to_bytes(char), char.encode("utf-8"))


class TestBytesToTokens(unittest.TestCase):
    def setUp(self):
        self.bpe = ByteLevelBPE()

    def test_basic_bytes(self):
        """Each byte maps to its integer value."""
        self.assertEqual(self.bpe.bytes_to_tokens(b"hello"), [104, 101, 108, 108, 111])

    def test_empty_bytes(self):
        """Empty bytes produce an empty list."""
        self.assertEqual(self.bpe.bytes_to_tokens(b""), [])

    def test_single_byte(self):
        """Single byte 0xFF maps to token 255."""
        self.assertEqual(self.bpe.bytes_to_tokens(b"\xff"), [255])

    def test_all_values_in_range(self):
        """All 256 byte values map to tokens 0–255."""
        result = self.bpe.bytes_to_tokens(bytes(range(256)))
        self.assertEqual(result, list(range(256)))

    def test_type_error_on_non_bytes(self):
        """String input raises TypeError."""
        with self.assertRaises(TypeError):
            self.bpe.bytes_to_tokens("hello")

    def test_type_error_on_list(self):
        """List input raises TypeError."""
        with self.assertRaises(TypeError):
            self.bpe.bytes_to_tokens([104, 101, 108])

    def test_returns_list(self):
        """Return type is list."""
        self.assertIsInstance(self.bpe.bytes_to_tokens(b"hi"), list)


class TestPairCounting(unittest.TestCase):
    def setUp(self):
        self.bpe = ByteLevelBPE()

    def test_basic_counts(self):
        """Counts adjacent pairs correctly."""
        result = self.bpe.pair_counting([[109, 109, 109, 102]])
        self.assertEqual(result[(109, 109)], 2)
        self.assertEqual(result[(109, 102)], 1)

    def test_repeated_pair(self):
        """Overlapping occurrences are each counted."""
        # [65, 65, 65] → (65,65) appears twice
        result = self.bpe.pair_counting([[65, 65, 65]])
        self.assertEqual(result[(65, 65)], 2)

    def test_empty_list(self):
        """Empty chunk produces no pairs."""
        self.assertEqual(self.bpe.pair_counting([[]]), Counter())

    def test_single_element(self):
        """Single token produces no pairs."""
        self.assertEqual(self.bpe.pair_counting([[42]]), Counter())

    def test_two_elements(self):
        """Two tokens produce exactly one pair."""
        result = self.bpe.pair_counting([[1, 2]])
        self.assertEqual(result[(1, 2)], 1)

    def test_returns_counter(self):
        """Return type is Counter."""
        self.assertIsInstance(self.bpe.pair_counting([[1, 2, 3]]), Counter)

    def test_no_unexpected_pairs(self):
        """Only adjacent pairs appear in the result."""
        result = self.bpe.pair_counting([[1, 2, 3]])
        self.assertSetEqual(set(result.keys()), {(1, 2), (2, 3)})

    def test_pairs_do_not_cross_chunks(self):
        """Pairs at chunk boundaries are not counted."""
        # Two chunks: [1, 2] and [2, 3] — pair (2, 2) should NOT appear
        result = self.bpe.pair_counting([[1, 2], [2, 3]])
        self.assertNotIn((2, 2), result)
        self.assertEqual(result[(1, 2)], 1)
        self.assertEqual(result[(2, 3)], 1)

    def test_counts_aggregate_across_chunks(self):
        """Same pair in different chunks sums up."""
        result = self.bpe.pair_counting([[1, 2], [1, 2]])
        self.assertEqual(result[(1, 2)], 2)


class TestMostFrequentPair(unittest.TestCase):
    def setUp(self):
        self.bpe = ByteLevelBPE()

    def test_basic(self):
        """Returns the pair with the highest count."""
        counts = Counter({(1, 2): 5, (3, 4): 2, (5, 6): 1})
        self.assertEqual(self.bpe.most_frequent_pair(counts), (1, 2))

    def test_single_entry(self):
        """Works with only one pair."""
        counts = Counter({(7, 8): 3})
        self.assertEqual(self.bpe.most_frequent_pair(counts), (7, 8))

    def test_real_pair_counting_output(self):
        """Finds 'at' as the most frequent pair in a real sentence."""
        # "at" (97,116) is the most frequent pair in "The cat sat on the mat"
        tokens = [84, 104, 101, 32, 99, 97, 116, 32, 115, 97, 116, 32, 111, 110, 32, 116, 104, 101, 32, 109, 97, 116]
        counts = self.bpe.pair_counting([tokens])
        self.assertEqual(self.bpe.most_frequent_pair(counts), (97, 116))

    def test_empty_counter_raises(self):
        """Empty counter raises ValueError."""
        with self.assertRaises(ValueError):
            self.bpe.most_frequent_pair(Counter())



class TestMerge(unittest.TestCase):
    def setUp(self):
        self.bpe = ByteLevelBPE()

    def test_basic_merge(self):
        """Merges 'll' into a single new token."""
        # (108, 108) → "ll" in "hello"
        result = self.bpe.merge([[104, 101, 108, 108, 111]], (108, 108), 256)
        self.assertEqual(result, [[104, 101, 256, 111]])

    def test_pair_not_present(self):
        """Absent pair leaves tokens unchanged."""
        # Nothing to merge — list unchanged
        result = self.bpe.merge([[1, 2, 3]], (9, 9), 256)
        self.assertEqual(result, [[1, 2, 3]])

    def test_back_to_back_pairs(self):
        """Non-overlapping repeated pairs are all merged."""
        # [A, B, A, B] → two non-overlapping merges
        result = self.bpe.merge([[1, 2, 1, 2]], (1, 2), 256)
        self.assertEqual(result, [[256, 256]])

    def test_overlapping_not_double_merged(self):
        """Greedy left-to-right merge does not double-consume."""
        # [A, A, A] with pair (A, A): greedy left-to-right → [256, A]
        result = self.bpe.merge([[65, 65, 65]], (65, 65), 256)
        self.assertEqual(result, [[256, 65]])

    def test_pair_at_start(self):
        """Merge works at the beginning of a chunk."""
        result = self.bpe.merge([[1, 2, 3, 4]], (1, 2), 256)
        self.assertEqual(result, [[256, 3, 4]])

    def test_pair_at_end(self):
        """Merge works at the end of a chunk."""
        result = self.bpe.merge([[1, 2, 3, 4]], (3, 4), 256)
        self.assertEqual(result, [[1, 2, 256]])

    def test_single_pair(self):
        """Two-element chunk merges into a single token."""
        result = self.bpe.merge([[1, 2]], (1, 2), 256)
        self.assertEqual(result, [[256]])

    def test_empty_list(self):
        """Empty chunk stays empty."""
        self.assertEqual(self.bpe.merge([[]], (1, 2), 256), [[]])

    def test_single_element(self):
        """
        With only one token, the pair can never be present, so list should be unchanged.
        """
        self.assertEqual(self.bpe.merge([[42]], (42, 42), 256), [[42]])

    def test_returns_list_of_lists(self):
        """Return type is list of lists."""
        result = self.bpe.merge([[1, 2, 3]], (1, 2), 256)
        self.assertIsInstance(result, list)
        self.assertIsInstance(result[0], list)

    def test_multiple_chunks(self):
        """Merge applies independently to each chunk."""
        # Merge operates on each chunk independently
        result = self.bpe.merge([[1, 2, 3], [1, 2, 4]], (1, 2), 256)
        self.assertEqual(result, [[256, 3], [256, 4]])

    def test_merge_does_not_cross_chunks(self):
        """Pair spanning a chunk boundary is not merged."""
        # pair (3, 1) spans chunk boundary — should NOT merge
        result = self.bpe.merge([[1, 2, 3], [1, 2, 4]], (3, 1), 256)
        self.assertEqual(result, [[1, 2, 3], [1, 2, 4]])

    def test_real_bpe_step(self):
        """Merging 'at' in a real sentence produces the expected tokens."""
        # "The cat sat on the mat" — merge most frequent pair "at" (97,116) → 256
        tokens = [84, 104, 101, 32, 99, 97, 116, 32, 115, 97, 116, 32, 111, 110, 32, 116, 104, 101, 32, 109, 97, 116]
        result = self.bpe.merge([tokens], (97, 116), 256)
        self.assertEqual(result, [[84, 104, 101, 32, 99, 256, 32, 115, 256, 32, 111, 110, 32, 116, 104, 101, 32, 109, 256]])
        self.assertEqual(len(result[0]), 19)


class TestTrain(unittest.TestCase):
    def setUp(self):
        self.bpe = ByteLevelBPE()

    # --- basic correctness ---

    def test_two_merges_on_aaabdaaabac(self):
        """Two merges produce correct merge count, vocab size, and types."""
        # "aaabdaaabac" → pre-tokenized into one chunk "aaabdaaabac"
        # most frequent pair is (97,97)="aa" → 256
        # then (256,97)="aaa" → 257  or (256,98)="aab" → 257
        chunks = self.bpe.train("aaabdaaabac", vocab_size=258)
        self.assertEqual(len(self.bpe.merges), 2)
        self.assertEqual(len(self.bpe.vocab), 258)
        self.assertIsInstance(chunks, list)
        self.assertIsInstance(chunks[0], list)

    def test_first_merge_is_most_frequent_byte_pair(self):
        """First merge picks the most frequent byte pair."""
        # "aaabdaaabac" — (97,97) appears 4 times, the most frequent pair
        self.bpe.train("aaabdaaabac", vocab_size=257)
        first_pair = next(iter(self.bpe.merges))
        self.assertEqual(first_pair, (97, 97))
        self.assertEqual(self.bpe.merges[first_pair], 256)

    def test_returns_list_of_lists(self):
        """Train returns a list of int lists."""
        chunks = self.bpe.train("hello world", vocab_size=257)
        self.assertIsInstance(chunks, list)
        for chunk in chunks:
            self.assertIsInstance(chunk, list)
            self.assertTrue(all(isinstance(t, int) for t in chunk))

    def test_tokens_shorter_after_training(self):
        """Total token count decreases after merges."""
        text = "aaabdaaabac"
        original_len = len(text.encode("utf-8"))
        chunks = self.bpe.train(text, vocab_size=258)
        total_tokens = sum(len(c) for c in chunks)
        self.assertLess(total_tokens, original_len)

    def test_vocab_grows_by_num_merges(self):
        """Vocab size equals 256 + number of merges."""
        self.bpe.train("the cat sat on the mat", vocab_size=260)
        self.assertEqual(len(self.bpe.vocab), 260)
        self.assertEqual(len(self.bpe.merges), 4)

    def test_merge_ids_are_sequential_from_256(self):
        """Merge IDs are assigned sequentially starting at 256."""
        self.bpe.train("aaabdaaabac", vocab_size=260)
        ids = list(self.bpe.merges.values())
        for i, merge_id in enumerate(ids):
            self.assertEqual(merge_id, 256 + i)

    # --- early exit ---

    def test_early_exit_short_text(self):
        """Stops early when no more pairs can be merged."""
        # "ab" → pre-tokenized to one chunk ["ab"]
        # can only produce 1 merge: (97,98) → 256, then chunk is [256]
        chunks = self.bpe.train("ab", vocab_size=300)
        self.assertEqual(len(self.bpe.merges), 1)
        total_tokens = sum(len(c) for c in chunks)
        self.assertEqual(total_tokens, 1)

    def test_single_char_repeated(self):
        """Repeated single char merges down to one token."""
        # "aaaa" → merge (97,97)→256 → [256,256] → merge (256,256)→257 → [257]
        chunks = self.bpe.train("aaaa", vocab_size=300)
        self.assertEqual(len(self.bpe.merges), 2)
        total_tokens = sum(len(c) for c in chunks)
        self.assertEqual(total_tokens, 1)

    # --- validation ---

    def test_vocab_size_256_raises(self):
        """vocab_size=256 (no merges possible) raises ValueError."""
        with self.assertRaises(ValueError):
            self.bpe.train("hello", vocab_size=256)

    def test_vocab_size_0_raises(self):
        """vocab_size=0 raises ValueError."""
        with self.assertRaises(ValueError):
            self.bpe.train("hello", vocab_size=0)

    def test_non_str_text_raises(self):
        """Non-string text raises TypeError."""
        with self.assertRaises(TypeError):
            self.bpe.train(12345, vocab_size=257)

    def test_non_bool_verbose_raises(self):
        """Non-bool verbose raises TypeError."""
        with self.assertRaises(TypeError):
            self.bpe.train("hello", vocab_size=257, verbose=1)

    def test_empty_text_raises(self):
        """Empty text raises ValueError."""
        with self.assertRaises(ValueError):
            self.bpe.train("", vocab_size=257)

    # --- vocab contents ---

    def test_vocab_bytes_are_correct(self):
        """Merged token maps to the concatenated bytes."""
        # After merging (97,97) → 256, vocab[256] should be b"aa"
        self.bpe.train("aaabdaaabac", vocab_size=257)
        self.assertEqual(self.bpe.vocab[256], b"aa")

    def test_chained_merge_vocab(self):
        """Chained merges build up longer byte sequences in vocab."""
        # merge 1: (97,97)→256 = b"aa"
        # merge 2: (256,97)→257 = b"aaa"  (tied with (97,98); max() picks first)
        self.bpe.train("aaabdaaabac", vocab_size=258)
        self.assertEqual(self.bpe.vocab[256], b"aa")
        self.assertEqual(self.bpe.vocab[257], b"aaa")

    # --- unicode ---

    def test_unicode_text(self):
        """Training on multi-byte UTF-8 text works without errors."""
        # Should not crash on multi-byte UTF-8 characters
        chunks = self.bpe.train("日本語日本語日本語", vocab_size=257)
        self.assertEqual(len(self.bpe.merges), 1)
        self.assertIsInstance(chunks, list)


class TestPreTokenize(unittest.TestCase):
    def setUp(self):
        self.bpe = ByteLevelBPE()

    def test_space_attaches_to_following_word(self):
        """Space is attached to the following word."""
        chunks = self.bpe.pre_tokenize("hello world")
        # "hello" and " world" (space attached to word)
        self.assertEqual(chunks[0], list("hello".encode("utf-8")))
        self.assertEqual(chunks[1], list(" world".encode("utf-8")))

    def test_contraction_split(self):
        """Contractions are split at the apostrophe."""
        chunks = self.bpe.pre_tokenize("it's")
        # Should split into ["it", "'s"]
        self.assertEqual(len(chunks), 2)
        self.assertEqual(chunks[1], list("'s".encode("utf-8")))

    def test_punctuation_separate(self):
        """Punctuation is split into its own chunk."""
        chunks = self.bpe.pre_tokenize("hello!")
        # "hello" and "!" become separate chunks
        self.assertEqual(len(chunks), 2)

    def test_empty_string(self):
        """Empty string produces no chunks."""
        self.assertEqual(self.bpe.pre_tokenize(""), [])


class TestEncodeDecodeIntegration(unittest.TestCase):
    def setUp(self):
        self.bpe = ByteLevelBPE()

    def test_encode_decode_identity(self):
        """decode(encode(text)) returns the original text."""
        text = "The quick brown fox jumps over the lazy dog."
        self.bpe.train(text, vocab_size=300)
        tokens = self.bpe.encode(text)
        self.assertEqual(self.bpe.decode(tokens), text)


class TestEncode(unittest.TestCase):
    def setUp(self):
        self.bpe = ByteLevelBPE()

    def test_encode_before_training_returns_raw_byte_ids(self):
        """Before training, encode returns raw UTF-8 byte token IDs."""
        # No merges loaded — every byte is its own token
        tokens = self.bpe.encode("hi")
        self.assertEqual(tokens, list("hi".encode("utf-8")))

    def test_encode_returns_list_of_ints(self):
        """encode always returns a list of integers."""
        self.bpe.train("hello world", vocab_size=257)
        tokens = self.bpe.encode("hello")
        self.assertIsInstance(tokens, list)
        self.assertTrue(all(isinstance(t, int) for t in tokens))

    def test_encode_applies_learned_merges(self):
        """encode applies the learned merge rules and reduces token count."""
        text = "aaabdaaabac"
        self.bpe.train(text, vocab_size=257)
        # After merging (97,97)→256, "aa" chunks should collapse
        tokens = self.bpe.encode("aa")
        self.assertEqual(tokens, [256])

    def test_encode_correct_ids_for_trained_text(self):
        """encode output is strictly shorter (in tokens) than raw bytes for repetitive text."""
        text = "aaaa"
        self.bpe.train(text, vocab_size=300)
        tokens = self.bpe.encode(text)
        self.assertLess(len(tokens), len(text.encode("utf-8")))

    def test_encode_multi_chunk_independence(self):
        """Merges do not cross pre-tokenization chunk boundaries."""
        text = "ab ab"
        self.bpe.train(text, vocab_size=257)
        tokens_combined = self.bpe.encode("ab ab")
        tokens_separate = self.bpe.encode("ab") + self.bpe.encode(" ab")
        self.assertEqual(tokens_combined, tokens_separate)

    def test_encode_oov_text_stays_as_bytes(self):
        """Characters not seen during training remain as raw byte tokens."""
        self.bpe.train("hello", vocab_size=260)
        # "xyz" not in training text — tokens must still be valid byte IDs
        tokens = self.bpe.encode("xyz")
        expected = list("xyz".encode("utf-8"))
        self.assertEqual(tokens, expected)

    def test_encode_empty_string_returns_empty_list(self):
        """encode of an empty string returns an empty list."""
        self.bpe.train("hello", vocab_size=257)
        self.assertEqual(self.bpe.encode(""), [])

    def test_encode_unicode_text(self):
        """encode handles multi-byte UTF-8 text correctly."""
        text = "日本語"
        self.bpe.train(text, vocab_size=260)
        tokens = self.bpe.encode(text)
        self.assertIsInstance(tokens, list)
        self.assertTrue(all(isinstance(t, int) for t in tokens))


class TestDecode(unittest.TestCase):
    def setUp(self):
        self.bpe = ByteLevelBPE()

    def test_decode_empty_list(self):
        """decode of an empty list returns an empty string."""
        self.assertEqual(self.bpe.decode([]), "")

    def test_decode_raw_byte_tokens(self):
        """decode of raw byte token IDs (no merges) returns the original string."""
        tokens = list("hello".encode("utf-8"))
        self.assertEqual(self.bpe.decode(tokens), "hello")

    def test_decode_with_merged_token(self):
        """decode correctly handles merged token IDs."""
        self.bpe.train("aaabdaaabac", vocab_size=257)
        # token 256 → b"aa"
        self.assertEqual(self.bpe.decode([256]), "aa")

    def test_decode_unknown_token_raises(self):
        """decode raises KeyError for an unknown token ID."""
        with self.assertRaises(KeyError):
            self.bpe.decode([99999])

    def test_decode_invalid_utf8_uses_replacement(self):
        """decode uses replacement character for invalid UTF-8 sequences."""
        # Manually insert a token whose bytes are invalid UTF-8
        new_id = 256
        self.bpe.vocab[new_id] = b"\xff\xfe"  # invalid UTF-8
        result = self.bpe.decode([new_id])
        # errors="replace" should produce replacement characters, not raise
        self.assertIsInstance(result, str)
        self.assertIn("\ufffd", result)

    def test_decode_returns_str(self):
        """decode always returns a str."""
        result = self.bpe.decode([104, 105])  # b"hi"
        self.assertIsInstance(result, str)
        self.assertEqual(result, "hi")


class TestSaveLoad(unittest.TestCase):
    def setUp(self):
        self.bpe = ByteLevelBPE()

    def test_save_creates_file(self):
        """save writes a file to the specified path."""
        self.bpe.train("aaabdaaabac", vocab_size=258)
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name
        try:
            self.bpe.save(path)
            self.assertTrue(os.path.exists(path))
        finally:
            os.unlink(path)

    def test_save_produces_valid_json(self):
        """save writes valid JSON with 'merges' and 'vocab' keys."""
        self.bpe.train("aaabdaaabac", vocab_size=258)
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
            path = f.name
        try:
            self.bpe.save(path)
            with open(path) as f:
                data = json.load(f)
            self.assertIn("merges", data)
            self.assertIn("vocab", data)
        finally:
            os.unlink(path)

    def test_load_restores_merges(self):
        """load restores the exact merge rules."""
        self.bpe.train("aaabdaaabac", vocab_size=258)
        original_merges = dict(self.bpe.merges)
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name
        try:
            self.bpe.save(path)
            loaded = ByteLevelBPE()
            loaded.load(path)
            self.assertEqual(loaded.merges, original_merges)
        finally:
            os.unlink(path)

    def test_load_restores_vocab(self):
        """load restores the full vocabulary including merged tokens."""
        self.bpe.train("aaabdaaabac", vocab_size=258)
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name
        try:
            self.bpe.save(path)
            loaded = ByteLevelBPE()
            loaded.load(path)
            self.assertEqual(loaded.vocab[256], b"aa")
            self.assertEqual(loaded.vocab[257], b"aaa")
        finally:
            os.unlink(path)

    def test_load_restores_merge_rank(self):
        """load correctly rebuilds _merge_rank for encoding."""
        self.bpe.train("aaabdaaabac", vocab_size=258)
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name
        try:
            self.bpe.save(path)
            loaded = ByteLevelBPE()
            loaded.load(path)
            self.assertEqual(loaded._merge_rank, self.bpe._merge_rank)
        finally:
            os.unlink(path)

    def test_save_load_round_trip_encode_decode(self):
        """train → save → load → encode → decode reproduces the original text."""
        text = "The cat sat on the mat"
        self.bpe.train(text, vocab_size=270)
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name
        try:
            self.bpe.save(path)
            loaded = ByteLevelBPE()
            loaded.load(path)
            tokens = loaded.encode(text)
            self.assertEqual(loaded.decode(tokens), text)
        finally:
            os.unlink(path)

    def test_load_missing_file_raises(self):
        """load raises an error for a non-existent file."""
        with self.assertRaises((FileNotFoundError, OSError)):
            self.bpe.load("/tmp/this_file_does_not_exist_bpe.json")

    def test_load_malformed_json_raises(self):
        """load raises an error for malformed JSON."""
        with tempfile.NamedTemporaryFile(suffix=".json", delete=False, mode="w") as f:
            f.write("not valid json {{{{")
            path = f.name
        try:
            with self.assertRaises(json.JSONDecodeError):
                self.bpe.load(path)
        finally:
            os.unlink(path)


class TestPreTokenizeExtended(unittest.TestCase):
    def setUp(self):
        self.bpe = ByteLevelBPE()

    def test_returns_list_of_list_of_ints(self):
        """pre_tokenize returns list[list[int]]."""
        result = self.bpe.pre_tokenize("hello world")
        self.assertIsInstance(result, list)
        for chunk in result:
            self.assertIsInstance(chunk, list)
            self.assertTrue(all(isinstance(t, int) for t in chunk))

    def test_numbers_are_single_chunk(self):
        """A run of digits is kept as one chunk."""
        chunks = self.bpe.pre_tokenize("123")
        self.assertEqual(len(chunks), 1)
        self.assertEqual(chunks[0], list("123".encode("utf-8")))

    def test_number_and_word_split(self):
        """A number and a following word are split into separate chunks."""
        chunks = self.bpe.pre_tokenize("42abc")
        # digits and letters are different character classes → separate chunks
        self.assertGreater(len(chunks), 1)

    def test_multi_word_sentence_chunk_count(self):
        """A three-word sentence produces exactly three chunks."""
        chunks = self.bpe.pre_tokenize("one two three")
        self.assertEqual(len(chunks), 3)

    def test_trailing_whitespace_handling(self):
        """Trailing whitespace is handled without crashing."""
        result = self.bpe.pre_tokenize("hello   ")
        self.assertIsInstance(result, list)

    def test_multiple_spaces_between_words(self):
        """Multiple spaces between words do not crash and produce valid output."""
        result = self.bpe.pre_tokenize("a  b")
        self.assertIsInstance(result, list)
        self.assertTrue(len(result) >= 2)


class TestTrainExtended(unittest.TestCase):
    def setUp(self):
        self.bpe = ByteLevelBPE()

    def test_vocab_size_257_one_merge(self):
        """vocab_size=257 produces exactly one merge."""
        self.bpe.train("hello world", vocab_size=257)
        self.assertEqual(len(self.bpe.merges), 1)
        self.assertEqual(len(self.bpe.vocab), 257)

    def test_verbose_true_runs_without_error(self):
        """verbose=True completes training without raising."""
        try:
            self.bpe.train("hello world", vocab_size=258, verbose=True)
        except Exception as e:
            self.fail(f"train with verbose=True raised: {e}")

    def test_whitespace_only_text(self):
        """Whitespace-only text either completes with zero merges or raises gracefully."""
        try:
            chunks = self.bpe.train("     ", vocab_size=258)
            # If it succeeds, no merges should be learned (all whitespace, no pairs)
            self.assertIsInstance(chunks, list)
        except ValueError:
            pass  # also acceptable — whitespace-only is edge-case input

    def test_second_train_call_extends_vocab(self):
        """Calling train twice on the same instance accumulates merges."""
        self.bpe.train("aaaa", vocab_size=258)
        merges_after_first = len(self.bpe.merges)
        # Re-initialize to test a clean second call
        bpe2 = ByteLevelBPE()
        bpe2.train("aaaa", vocab_size=258)
        self.assertEqual(len(bpe2.merges), merges_after_first)

    def test_merge_rank_populated_after_train(self):
        """_merge_rank is populated after training and has correct size."""
        self.bpe.train("aaabdaaabac", vocab_size=258)
        self.assertEqual(len(self.bpe._merge_rank), len(self.bpe.merges))
        for rank, (pair, _) in enumerate(self.bpe.merges.items()):
            self.assertEqual(self.bpe._merge_rank[pair], rank)


class TestTrainFromFolder(unittest.TestCase):
    def test_raises_on_missing_folder(self):
        """train_from_folder raises if the folder does not exist."""
        from bpe_from_scratch.train import train_from_folder
        with self.assertRaises((FileNotFoundError, OSError, ValueError)):
            train_from_folder("/tmp/nonexistent_folder_bpe_test_xyz", "out.json", vocab_size=257)

    def test_raises_on_no_txt_files(self):
        """train_from_folder raises ValueError when folder has no .txt files."""
        from bpe_from_scratch.train import train_from_folder
        with tempfile.TemporaryDirectory() as tmpdir:
            with self.assertRaises(ValueError):
                train_from_folder(tmpdir, "out.json", vocab_size=257)

    def test_trains_from_txt_files(self):
        """train_from_folder loads .txt files and returns a trained ByteLevelBPE."""
        from bpe_from_scratch.train import train_from_folder
        with tempfile.TemporaryDirectory() as tmpdir:
            # Write two small text files
            for name, content in [("a.txt", "hello hello hello"), ("b.txt", "world world world")]:
                with open(os.path.join(tmpdir, name), "w", encoding="utf-8") as f:
                    f.write(content)
            with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as mf:
                model_path = mf.name
            try:
                bpe = train_from_folder(tmpdir, model_path, vocab_size=260)
                self.assertIsInstance(bpe, ByteLevelBPE)
                self.assertGreater(len(bpe.merges), 0)
                self.assertTrue(os.path.exists(model_path))
            finally:
                os.unlink(model_path)


class TestContinueTrain(unittest.TestCase):
    def setUp(self):
        self.bpe = ByteLevelBPE()
        self.bpe.train("aaabdaaabac", vocab_size=258)  # 2 merges, vocab size 258

    # --- validation ---

    def test_new_vocab_size_equal_raises(self):
        """new_vocab_size equal to current vocab size raises ValueError."""
        with self.assertRaises(ValueError):
            self.bpe.continue_train("hello", new_vocab_size=258)

    def test_new_vocab_size_less_raises(self):
        """new_vocab_size less than current vocab size raises ValueError."""
        with self.assertRaises(ValueError):
            self.bpe.continue_train("hello", new_vocab_size=257)

    def test_empty_text_raises(self):
        """Empty text raises ValueError."""
        with self.assertRaises(ValueError):
            self.bpe.continue_train("", new_vocab_size=260)

    def test_non_str_text_raises(self):
        """Non-string text raises TypeError."""
        with self.assertRaises(TypeError):
            self.bpe.continue_train(123, new_vocab_size=260)

    def test_non_bool_verbose_raises(self):
        """Non-bool verbose raises TypeError."""
        with self.assertRaises(TypeError):
            self.bpe.continue_train("hello", new_vocab_size=260, verbose=1)

    # --- correctness ---

    def test_vocab_grows_by_requested_amount(self):
        """Vocab size increases by exactly the requested number of new merges."""
        self.bpe.continue_train("bbbbcccc", new_vocab_size=260)
        self.assertEqual(len(self.bpe.vocab), 260)
        self.assertEqual(len(self.bpe.merges), 4)

    def test_existing_merges_unchanged(self):
        """Existing merge rules are untouched after continue_train."""
        original_merges = dict(self.bpe.merges)
        self.bpe.continue_train("bbbbcccc", new_vocab_size=260)
        for pair, new_id in original_merges.items():
            self.assertEqual(self.bpe.merges[pair], new_id)

    def test_new_merge_ids_continue_from_current_vocab(self):
        """New token IDs continue sequentially from the existing vocab."""
        self.bpe.continue_train("bbbbcccc", new_vocab_size=260)
        ids = list(self.bpe.merges.values())
        for i, merge_id in enumerate(ids):
            self.assertEqual(merge_id, 256 + i)

    def test_returns_list_of_lists(self):
        """continue_train returns a list of int lists."""
        chunks = self.bpe.continue_train("bbbb", new_vocab_size=259)
        self.assertIsInstance(chunks, list)
        for chunk in chunks:
            self.assertIsInstance(chunk, list)
            self.assertTrue(all(isinstance(t, int) for t in chunk))

    def test_existing_tokens_still_decode(self):
        """Tokens encoded before continue_train still decode correctly."""
        tokens_before = self.bpe.encode("aa")
        self.bpe.continue_train("bbbbcccc", new_vocab_size=260)
        self.assertEqual(self.bpe.decode(tokens_before), "aa")

    def test_fresh_model_works_like_train(self):
        """continue_train on a fresh (no merges) model behaves like train."""
        fresh = ByteLevelBPE()
        fresh.continue_train("aaabdaaabac", new_vocab_size=258)
        self.assertEqual(len(fresh.merges), 2)
        self.assertEqual(len(fresh.vocab), 258)

    def test_early_exit_when_no_pairs(self):
        """Stops early when new text has no mergeable pairs after replay."""
        # After training on "aaabdaaabac", continue on a single-byte text
        bpe = ByteLevelBPE()
        bpe.train("aaabdaaabac", vocab_size=258)
        # "x" pre-tokenizes to [[120]] — no pairs at all
        chunks = bpe.continue_train("x", new_vocab_size=300)
        # no new merges should have been added
        self.assertEqual(len(bpe.merges), 2)


class TestContinueTrainIntegration(unittest.TestCase):
    def test_encode_decode_after_continue_train(self):
        """train on A, continue on B, encode+decode B round-trips correctly."""
        bpe = ByteLevelBPE()
        bpe.train("the cat sat on the mat", vocab_size=262)

        text_b = "bbbbccccdddd"
        bpe.continue_train(text_b, new_vocab_size=265)

        tokens = bpe.encode(text_b)
        self.assertEqual(bpe.decode(tokens), text_b)

    def test_save_load_continue_train_round_trip(self):
        """train → save → load → continue_train → save → load → encode → decode works."""
        bpe = ByteLevelBPE()
        bpe.train("the cat sat on the mat", vocab_size=262)

        with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as f:
            path = f.name
        try:
            bpe.save(path)

            bpe2 = ByteLevelBPE()
            bpe2.load(path)
            text_b = "bbbbccccdddd"
            bpe2.continue_train(text_b, new_vocab_size=265)
            bpe2.save(path)

            bpe3 = ByteLevelBPE()
            bpe3.load(path)
            tokens = bpe3.encode(text_b)
            self.assertEqual(bpe3.decode(tokens), text_b)
        finally:
            os.unlink(path)


class TestContinueTrainFromFolder(unittest.TestCase):
    def test_extends_model_from_folder(self):
        """continue_train_from_folder loads model, extends vocab, saves back."""
        from bpe_from_scratch.train import train_from_folder, continue_train_from_folder

        with tempfile.TemporaryDirectory() as tmpdir:
            with open(os.path.join(tmpdir, "a.txt"), "w", encoding="utf-8") as f:
                f.write("hello hello hello world world")
            with tempfile.NamedTemporaryFile(suffix=".json", delete=False) as mf:
                model_path = mf.name
            try:
                train_from_folder(tmpdir, model_path, vocab_size=260)
                vocab_after_first = 260

                with open(os.path.join(tmpdir, "b.txt"), "w", encoding="utf-8") as f:
                    f.write("bbbbccccbbbbcccc")
                bpe = continue_train_from_folder(tmpdir, model_path, new_vocab_size=263)
                self.assertIsInstance(bpe, ByteLevelBPE)
                self.assertGreater(len(bpe.vocab), vocab_after_first)
            finally:
                os.unlink(model_path)

    def test_raises_on_no_txt_files(self):
        """continue_train_from_folder raises ValueError when folder has no .txt files."""
        from bpe_from_scratch.train import continue_train_from_folder
        with tempfile.TemporaryDirectory() as tmpdir:
            with self.assertRaises(ValueError):
                continue_train_from_folder(tmpdir, "irrelevant.json", new_vocab_size=260)


if __name__ == "__main__":
    unittest.main()

