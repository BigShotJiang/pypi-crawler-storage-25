# Rotational cross-correlation
