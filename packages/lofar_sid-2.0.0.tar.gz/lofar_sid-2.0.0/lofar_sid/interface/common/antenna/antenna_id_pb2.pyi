from lofar_sid.interface.common.antenna_field import antenna_field_id_pb2 as _antenna_field_id_pb2
from google.protobuf import descriptor as _descriptor
from google.protobuf import message as _message
from collections.abc import Mapping as _Mapping
from typing import ClassVar as _ClassVar, Optional as _Optional, Union as _Union

DESCRIPTOR: _descriptor.FileDescriptor

class AntennaId(_message.Message):
    __slots__ = ("antenna_field", "antenna_index")
    ANTENNA_FIELD_FIELD_NUMBER: _ClassVar[int]
    ANTENNA_INDEX_FIELD_NUMBER: _ClassVar[int]
    antenna_field: _antenna_field_id_pb2.AntennaFieldId
    antenna_index: int
    def __init__(self, antenna_field: _Optional[_Union[_antenna_field_id_pb2.AntennaFieldId, _Mapping]] = ..., antenna_index: _Optional[int] = ...) -> None: ...
