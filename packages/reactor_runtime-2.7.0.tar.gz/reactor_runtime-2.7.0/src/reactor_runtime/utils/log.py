"""Structured logging helpers for the Reactor Runtime.

Provides a thin wrapper around Python's :mod:`logging` that lets callers pass
``**kwargs`` which are automatically appended as ``key=value`` pairs:

    logger.info("Session created", session_id=sid, model=model_name)
    # => "Session created session_id=abc123 model=brightness-example"

This keeps call-sites concise while producing the same structured output that
the Go services emit via zerolog.
"""

import logging
from contextvars import ContextVar
from typing import Any, Optional

# ContextVar that holds the current session_id.  Set by the runtime
# at session start and cleared at cleanup.  StructuredLogger._fmt()
# reads this to auto-append session_id to all log messages.
session_id_var: ContextVar[Optional[str]] = ContextVar("session_id", default=None)


LOG_FORMAT = "%(asctime)s %(levelname)s %(name)s: %(message)s"
LOG_FORMAT_BRIEF = "%(levelname)s %(message)s"
LOG_DATEFMT = "%Y-%m-%dT%H:%M:%S%z"

_RESET = "\033[0m"

_LEVEL_COLORS: dict[int, str] = {
    logging.DEBUG: "\033[37m",  # gray
    logging.INFO: "\033[32m",  # green
    logging.WARNING: "\033[33m",  # yellow
    logging.ERROR: "\033[31m",  # red
    logging.CRITICAL: "\033[1;31m",  # bold red
}


# `reactor_runtime.serve.*` is matched by the `reactor_runtime.` prefix, so
# a single entry covers both the library and the serve entrypoint subpackage.
_RUNTIME_PREFIXES = ("reactor_runtime.",)
_MODEL_COLOR = "\033[36m"


class ColorFormatter(logging.Formatter):
    """Formatter that colorizes log levels and tags model logs."""

    _COL = 12  # visual width: fits "CRITICAL MDL"

    def format(self, record: logging.LogRecord) -> str:
        orig = record.levelname
        color = _LEVEL_COLORS.get(record.levelno, "")

        if record.name.startswith(_RUNTIME_PREFIXES):
            pad = self._COL - len(orig)
            record.levelname = f"{color}{orig}{_RESET}{' ' * pad}"
        else:
            pad = self._COL - len(orig) - 4  # 4 = len(" MDL")
            record.levelname = (
                f"{color}{orig}{_RESET} {_MODEL_COLOR}MDL{_RESET}{' ' * max(pad, 0)}"
            )

        result = super().format(record)
        record.levelname = orig
        return result


class StructuredLogger:
    """Logger wrapper that formats ``**kwargs`` as ``key=value`` pairs."""

    __slots__ = ("_log",)

    def __init__(self, name: str) -> None:
        self._log: logging.Logger = logging.getLogger(name)

    # -- internal helpers --------------------------------------------------

    _BLUE = "\033[38;5;25m"
    _RESET = "\033[0m"

    @staticmethod
    def _fmt(msg: str, kw: dict[str, Any]) -> str:
        sid = session_id_var.get()
        if sid and "session_id" not in kw:
            kw["session_id"] = sid
        if not kw:
            return msg
        b, r = StructuredLogger._BLUE, StructuredLogger._RESET
        pairs = " ".join(f"{b}{k}={r}{v}" for k, v in kw.items())
        return f"{msg} {pairs}"

    # -- public API --------------------------------------------------------

    def debug(self, msg: str, **kw: Any) -> None:
        if self._log.isEnabledFor(logging.DEBUG):
            self._log.debug(self._fmt(msg, kw))

    def info(self, msg: str, **kw: Any) -> None:
        if self._log.isEnabledFor(logging.INFO):
            self._log.info(self._fmt(msg, kw))

    def warning(self, msg: str, **kw: Any) -> None:
        if self._log.isEnabledFor(logging.WARNING):
            self._log.warning(self._fmt(msg, kw))

    def error(self, msg: str, **kw: Any) -> None:
        if self._log.isEnabledFor(logging.ERROR):
            self._log.error(self._fmt(msg, kw))

    def critical(self, msg: str, *, exc_info: bool = False, **kw: Any) -> None:
        self._log.critical(self._fmt(msg, kw), exc_info=exc_info)

    def exception(self, msg: str, **kw: Any) -> None:
        self._log.exception(self._fmt(msg, kw))

    # -- delegate common attributes so callers can still do e.g.
    #    ``logger.setLevel(...)`` when needed.

    @property
    def level(self) -> int:
        return self._log.level

    def setLevel(self, level: int) -> None:  # noqa: N802 – match stdlib API
        self._log.setLevel(level)

    def isEnabledFor(self, level: int) -> bool:  # noqa: N802
        return self._log.isEnabledFor(level)


def get_logger(name: str) -> StructuredLogger:
    """Return a :class:`StructuredLogger` for *name*.

    Typical usage at module level::

        from reactor_runtime.utils.log import get_logger

        logger = get_logger(__name__)
    """
    return StructuredLogger(name)
