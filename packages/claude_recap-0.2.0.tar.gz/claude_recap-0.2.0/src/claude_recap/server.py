"""Local HTTP server for the Claude Recap dashboard."""

from __future__ import annotations

import json
import webbrowser
from datetime import date
from http.server import HTTPServer, SimpleHTTPRequestHandler
from typing import Optional
from urllib.parse import parse_qs, urlparse

from claude_recap.analyzer import ConversationAnalyzer
from claude_recap.parser import Session
from claude_recap.reporter import Purpose, Period, generate_report_data, render_html_report, render_markdown_report, render_json_report, TEMPLATE_DIR, _safe_json_embed


def _session_to_dict(s: Session) -> dict:
    tools = set()
    input_tok = output_tok = cache_read = cache_create = 0
    models = set()
    for m in s.messages:
        tools.update(m.tools_used)
        input_tok += m.input_tokens
        output_tok += m.output_tokens
        cache_read += m.cache_read_tokens
        cache_create += m.cache_creation_tokens
        if m.model:
            models.add(m.model)
    return {
        "session_id": s.session_id,
        "project": s.project,
        "project_display": s.project_display,
        "summary": s.summary,
        "start_time": s.start_time.isoformat() if s.start_time else None,
        "end_time": s.end_time.isoformat() if s.end_time else None,
        "message_count": len(s.messages),
        "tools": sorted(tools),
        "input_tokens": input_tok,
        "output_tokens": output_tok,
        "cache_read_tokens": cache_read,
        "model": sorted(models)[-1] if models else "",
    }


def _full_stats_to_dict(stats) -> dict:
    """Convert OverallStats to dict with token and model data for dashboard."""
    return {
        "total_sessions": stats.total_sessions,
        "total_messages": stats.total_messages,
        "user_messages": stats.user_messages,
        "assistant_messages": stats.assistant_messages,
        "active_days": stats.active_days,
        "total_projects": stats.total_projects,
        "first_date": stats.first_date.isoformat() if stats.first_date else None,
        "last_date": stats.last_date.isoformat() if stats.last_date else None,
        "daily_activity": stats.daily_activity,
        "daily_tokens": stats.daily_tokens,
        "projects": dict(stats.projects.most_common(50)),
        "tools_used": dict(stats.tools_used.most_common(50)),
        "models_used": dict(stats.models_used.most_common(20)),
        "total_input_tokens": stats.total_input_tokens,
        "total_output_tokens": stats.total_output_tokens,
        "total_cache_read_tokens": stats.total_cache_read_tokens,
        "total_cache_creation_tokens": stats.total_cache_creation_tokens,
    }


def _build_dashboard_data(sessions: list[Session], serve_mode: bool = True) -> dict:
    analyzer = ConversationAnalyzer(sessions)
    stats = analyzer.overall_stats()
    return {
        "_serve_mode": serve_mode,
        "stats": _full_stats_to_dict(stats),
        "sessions": [_session_to_dict(s) for s in sessions],
    }


def build_static_dashboard(sessions: list[Session]) -> str:
    data = _build_dashboard_data(sessions, serve_mode=False)
    template = (TEMPLATE_DIR / "dashboard.html").read_text(encoding="utf-8")
    return template.replace("__DASHBOARD_DATA__", _safe_json_embed(data))


def _parse_date_params(qs: str) -> tuple[Optional[date], Optional[date]]:
    params = parse_qs(qs)
    start = end = None
    if params.get("from"):
        try:
            start = date.fromisoformat(params["from"][0])
        except ValueError:
            pass
    if params.get("to"):
        try:
            end = date.fromisoformat(params["to"][0])
        except ValueError:
            pass
    return start, end


def _filter_sessions(sessions: list[Session], start: Optional[date], end: Optional[date]) -> list[Session]:
    if not start and not end:
        return sessions
    filtered = []
    for s in sessions:
        d = s.start_time.date() if s.start_time else None
        if d and (not start or d >= start) and (not end or d <= end):
            filtered.append(s)
    return filtered


class DashboardHandler(SimpleHTTPRequestHandler):
    sessions: list[Session] = []
    _cache: Optional[str] = None

    def log_message(self, format, *args):
        pass

    def do_GET(self):
        parsed = urlparse(self.path)
        routes = {
            "/": self._serve_dashboard,
            "": self._serve_dashboard,
            "/api/stats": lambda: self._serve_stats(parsed.query),
            "/api/sessions": lambda: self._serve_sessions(parsed.query),
            "/api/config": self._serve_config_get,
            "/api/export": lambda: self._serve_export(parsed.query),
            "/api/summarize": lambda: self._serve_ai_summary(parsed.query),
        }
        handler = routes.get(parsed.path)
        if handler:
            handler()
        else:
            self.send_error(404)

    def do_POST(self):
        parsed = urlparse(self.path)
        if parsed.path == "/api/config":
            self._serve_config_post()
        else:
            self.send_error(404)

    def _serve_dashboard(self):
        if DashboardHandler._cache is None:
            data = _build_dashboard_data(DashboardHandler.sessions)
            template = (TEMPLATE_DIR / "dashboard.html").read_text(encoding="utf-8")
            DashboardHandler._cache = template.replace(
                "__DASHBOARD_DATA__", _safe_json_embed(data)
            )
        self._send_html(DashboardHandler._cache)

    def _serve_stats(self, qs: str):
        start, end = _parse_date_params(qs)
        sessions = _filter_sessions(DashboardHandler.sessions, start, end)
        analyzer = ConversationAnalyzer(sessions)
        stats = analyzer.overall_stats()
        self._send_json(_full_stats_to_dict(stats))

    def _serve_sessions(self, qs: str):
        start, end = _parse_date_params(qs)
        sessions = _filter_sessions(DashboardHandler.sessions, start, end)
        self._send_json([_session_to_dict(s) for s in sessions])

    def _serve_config_get(self):
        from claude_recap.config import get_provider_config
        cfg = get_provider_config()
        if cfg.get("api_key"):
            k = cfg["api_key"]
            cfg["api_key_masked"] = k[:8] + "..." + k[-4:] if len(k) > 12 else "***"
            cfg["has_key"] = True
        else:
            cfg["api_key_masked"] = ""
            cfg["has_key"] = False
        del cfg["api_key"]
        self._send_json(cfg)

    def _serve_config_post(self):
        try:
            length = int(self.headers.get("Content-Length", 0))
            if length > 10_000:
                self._send_json({"error": "Request too large"})
                return
            body = json.loads(self.rfile.read(length))
            provider = body.get("provider", "anthropic")
            if provider not in ("anthropic", "openai"):
                self._send_json({"error": f"Invalid provider: {provider}"})
                return
            from claude_recap.config import set_provider_config
            set_provider_config(
                provider=provider,
                api_key=str(body.get("api_key", ""))[:256],
                base_url=str(body.get("base_url") or "")[:256] or None,
                model=str(body.get("model") or "")[:128] or None,
            )
            self._send_json({"ok": True})
        except (json.JSONDecodeError, ValueError) as e:
            self._send_json({"error": f"Invalid request: {e}"})
        except Exception:
            self._send_json({"error": "Failed to save config"})

    def _serve_export(self, qs: str):
        params = parse_qs(qs)
        period = params.get("period", ["weekly"])[0]
        purpose = params.get("purpose", ["general"])[0]
        fmt = params.get("format", ["html"])[0]
        if period not in ("daily", "weekly", "monthly", "yearly"):
            period = "weekly"
        if purpose not in ("general", "academic", "job_search", "work_report"):
            purpose = "general"
        start, end = _parse_date_params(qs)
        sessions = _filter_sessions(DashboardHandler.sessions, start, end)
        analyzer = ConversationAnalyzer(sessions)
        if start or end:
            analyzer = analyzer.filter_by_date_range(start, end)
        data = generate_report_data(analyzer, Period(period), Purpose(purpose))
        if fmt == "markdown":
            content = render_markdown_report(data).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/markdown; charset=utf-8")
            self.send_header("Content-Disposition", f"attachment; filename=claude-recap-{period}.md")
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        elif fmt == "json":
            content = render_json_report(data).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Content-Disposition", f"attachment; filename=claude-recap-{period}.json")
            self.send_header("Content-Length", str(len(content)))
            self.end_headers()
            self.wfile.write(content)
        else:
            self._send_html(render_html_report(data))

    def _serve_ai_summary(self, qs: str):
        params = parse_qs(qs)
        purpose = params.get("purpose", ["general"])[0]
        start, end = _parse_date_params(qs)
        sessions = _filter_sessions(DashboardHandler.sessions, start, end)
        try:
            from claude_recap.summarizer import Summarizer
            s = Summarizer()
            if not s.available:
                self._send_json({"error": "not_configured"})
                return
            summary = s.summarize_overall(sessions, purpose=purpose)
            self._send_json({"summary": summary})
        except Exception as e:
            self._send_json({"error": str(e)})

    def _send_html(self, html: str):
        content = html.encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.end_headers()
        self.wfile.write(content)

    def _send_json(self, obj):
        content = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(200)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(content)))
        self.send_header("Access-Control-Allow-Origin", "http://127.0.0.1")
        self.end_headers()
        self.wfile.write(content)


def start_server(sessions: list[Session], port: int = 6275, open_browser: bool = True):
    DashboardHandler.sessions = sessions
    DashboardHandler._cache = None
    server = HTTPServer(("127.0.0.1", port), DashboardHandler)
    url = f"http://127.0.0.1:{port}"
    if open_browser:
        webbrowser.open(url)
    return server, url
