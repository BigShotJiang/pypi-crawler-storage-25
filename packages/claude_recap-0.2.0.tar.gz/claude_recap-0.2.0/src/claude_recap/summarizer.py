"""AI-powered summarization using LLM APIs.

Supports: Anthropic (Claude), OpenAI-compatible (OpenAI, ollama, vllm, together, deepseek, groq, etc.)
Reads config from: env vars, or ~/.config/claude-recap/config.json (via `claude-recap config --setup`)
"""

from __future__ import annotations

import json
from typing import Optional

from claude_recap.config import get_provider_config
from claude_recap.parser import Session

PURPOSE_PROMPTS = {
    "general": (
        "Provide a clear, concise summary of the user's AI-assisted development activities. "
        "Highlight key accomplishments, projects worked on, and notable patterns."
    ),
    "academic": (
        "Summarize from an academic/research perspective. Focus on research activities, "
        "experiments conducted, methods explored, datasets used, and scientific progress. "
        "Use formal but accessible language suitable for a research log or progress report."
    ),
    "job_search": (
        "Summarize to highlight professional skills and achievements. Focus on technologies used, "
        "complex problems solved, tools mastered, and quantifiable output. "
        "Frame as accomplishments suitable for a resume or interview discussion."
    ),
    "work_report": (
        "Summarize as a work progress report. Focus on deliverables completed, projects advanced, "
        "bugs fixed, features implemented, and productivity metrics. "
        "Use clear, professional language suitable for a manager or stakeholder update."
    ),
}


def estimate_tokens(text: str) -> int:
    """Rough token estimate: ~4 chars per token."""
    return len(text) // 4


def condense_sessions(
    sessions: list[Session],
    max_sessions: int = 200,
    max_prompt_tokens: int = 30000,
) -> tuple[list[dict], int]:
    """Condense sessions into a compact format for the API prompt.

    For large histories, samples strategically and progressively compresses
    to stay within token budget.

    Returns (condensed_data, estimated_tokens).
    """
    sampled = sessions
    if len(sessions) > max_sessions:
        # Keep all sessions from last 14 days, uniformly sample the rest
        from datetime import datetime, timedelta, timezone
        cutoff = datetime.now(timezone.utc) - timedelta(days=14)
        recent = [s for s in sessions if s.start_time and s.start_time >= cutoff]
        older = [s for s in sessions if not s.start_time or s.start_time < cutoff]
        remaining = max_sessions - len(recent)
        if remaining > 0 and older:
            step = max(1, len(older) // remaining)
            sampled = recent + older[::step][:remaining]
        else:
            sampled = recent[:max_sessions]

    # Progressive condensation: try with full detail, then reduce
    for topic_limit, char_limit in [(5, 150), (3, 100), (1, 60)]:
        condensed = []
        for s in sampled:
            tools = set()
            user_topics = []
            for m in s.messages:
                tools.update(m.tools_used)
                if m.role == "user" and m.content:
                    user_topics.append(m.content[:char_limit])

            condensed.append({
                "project": s.project_display,
                "date": s.start_time.strftime("%Y-%m-%d") if s.start_time else "unknown",
                "messages": len(s.messages),
                "tools": sorted(tools)[:10],
                "topics": user_topics[:topic_limit],
            })

        est = estimate_tokens(json.dumps(condensed, ensure_ascii=False))
        if est <= max_prompt_tokens:
            break

    return condensed, est


class Summarizer:
    """Generate AI-powered summaries using LLM APIs."""

    def __init__(
        self,
        api_key: Optional[str] = None,
        model: Optional[str] = None,
        provider: Optional[str] = None,
        base_url: Optional[str] = None,
    ):
        cfg = get_provider_config()
        self.provider = provider or cfg["provider"]
        self.api_key = api_key or cfg["api_key"]
        self.base_url = base_url or cfg["base_url"]
        self.model = model or cfg["model"]
        self._client = None

    @property
    def available(self) -> bool:
        # Local models (ollama) may not need an API key
        is_local = self.base_url and ("localhost" in self.base_url or "127.0.0.1" in self.base_url)
        if not self.api_key and not is_local:
            return False
        if self.provider == "anthropic":
            try:
                import anthropic  # noqa: F401
                return True
            except ImportError:
                return False
        else:
            try:
                import openai  # noqa: F401
                return True
            except ImportError:
                return False

    def _get_client(self):
        if self._client is None:
            if self.provider == "anthropic":
                import anthropic
                self._client = anthropic.Anthropic(api_key=self.api_key)
            else:
                from openai import OpenAI
                self._client = OpenAI(
                    api_key=self.api_key or "not-needed",
                    base_url=self.base_url,
                )
        return self._client

    def _call_llm(self, prompt: str) -> Optional[str]:
        client = self._get_client()
        if self.provider == "anthropic":
            response = client.messages.create(
                model=self.model,
                max_tokens=1024,
                messages=[{"role": "user", "content": prompt}],
            )
            return response.content[0].text
        else:
            response = client.chat.completions.create(
                model=self.model,
                max_tokens=1024,
                messages=[{"role": "user", "content": prompt}],
            )
            return response.choices[0].message.content

    def summarize_sessions(
        self,
        sessions: list[Session],
        period_label: str = "",
        purpose: str = "general",
    ) -> Optional[str]:
        if not self.available or not sessions:
            return None

        condensed, _ = condense_sessions(sessions)
        purpose_instruction = PURPOSE_PROMPTS.get(purpose, PURPOSE_PROMPTS["general"])

        prompt = (
            f"Analyze these AI-assisted development sessions"
            f"{f' from {period_label}' if period_label else ''} "
            f"and write a summary.\n\n"
            f"Goal: {purpose_instruction}\n\n"
            f"Sessions:\n{json.dumps(condensed, indent=2, ensure_ascii=False)}\n\n"
            f"Write a concise summary (3-5 short paragraphs, no markdown headers). "
            f"Use specific details. Match the language of the session topics "
            f"(Chinese topics → Chinese summary, English → English)."
        )

        try:
            return self._call_llm(prompt)
        except Exception:
            return None

    def summarize_overall(
        self,
        sessions: list[Session],
        purpose: str = "general",
    ) -> Optional[str]:
        return self.summarize_sessions(sessions, "the entire period", purpose)
