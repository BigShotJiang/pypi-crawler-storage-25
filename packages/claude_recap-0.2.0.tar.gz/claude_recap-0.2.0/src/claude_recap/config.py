"""Configuration management for Claude Recap."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional


PROVIDER_DEFAULTS = {
    "anthropic": {"model": "claude-sonnet-4-20250514", "base_url": None},
    "openai": {"model": "gpt-4o-mini", "base_url": None},
}


def _config_path() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("APPDATA", Path.home()))
    else:
        base = Path(os.environ.get("XDG_CONFIG_HOME", Path.home() / ".config"))
    return base / "claude-recap" / "config.json"


def load_config() -> dict:
    path = _config_path()
    if path.exists():
        try:
            return json.loads(path.read_text(encoding="utf-8"))
        except (json.JSONDecodeError, OSError):
            return {}
    return {}


def save_config(config: dict) -> Path:
    path = _config_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8")
    return path


def get_api_key() -> Optional[str]:
    """Resolve API key: env var > config file."""
    return os.environ.get("ANTHROPIC_API_KEY") or os.environ.get("OPENAI_API_KEY") or load_config().get("api_key")


def set_api_key(key: str) -> Path:
    config = load_config()
    config["api_key"] = key
    return save_config(config)


def get_provider_config() -> dict:
    """Resolve full provider config: env vars > config file > defaults."""
    file_cfg = load_config()
    provider = os.environ.get("CLAUDE_RECAP_PROVIDER") or file_cfg.get("provider", "anthropic")
    defaults = PROVIDER_DEFAULTS.get(provider, PROVIDER_DEFAULTS["openai"])

    api_key = (
        os.environ.get("ANTHROPIC_API_KEY")
        or os.environ.get("OPENAI_API_KEY")
        or file_cfg.get("api_key")
    )
    base_url = os.environ.get("OPENAI_BASE_URL") or file_cfg.get("base_url") or defaults["base_url"]
    model = os.environ.get("CLAUDE_RECAP_MODEL") or file_cfg.get("model") or defaults["model"]

    return {
        "provider": provider,
        "api_key": api_key,
        "base_url": base_url,
        "model": model,
    }


def set_provider_config(provider: str, api_key: str, base_url: Optional[str] = None, model: Optional[str] = None) -> Path:
    config = load_config()
    config["provider"] = provider
    config["api_key"] = api_key
    if base_url:
        config["base_url"] = base_url
    elif "base_url" in config:
        del config["base_url"]
    if model:
        config["model"] = model
    elif "model" in config:
        del config["model"]
    return save_config(config)
