"""Generate reports in HTML, Markdown, and JSON formats."""

from __future__ import annotations

import json
from datetime import date
from enum import Enum
from pathlib import Path
from typing import Optional

from claude_recap.analyzer import ConversationAnalyzer, OverallStats, PeriodSummary


class Purpose(str, Enum):
    GENERAL = "general"
    ACADEMIC = "academic"
    JOB_SEARCH = "job_search"
    WORK_REPORT = "work_report"


class Period(str, Enum):
    DAILY = "daily"
    WEEKLY = "weekly"
    MONTHLY = "monthly"
    YEARLY = "yearly"


PURPOSE_LABELS = {
    Purpose.GENERAL: "General Summary",
    Purpose.ACADEMIC: "Academic & Research Report",
    Purpose.JOB_SEARCH: "Skills & Experience Overview",
    Purpose.WORK_REPORT: "Work Progress Report",
}


def _find_template_dir() -> Path:
    """Find the templates directory (installed or dev mode)."""
    pkg = Path(__file__).parent
    # Installed: templates copied inside package by hatch
    if (pkg / "templates").is_dir():
        return pkg / "templates"
    # Development (editable install): templates at project root
    project_root = pkg.parent.parent
    if (project_root / "templates").is_dir():
        return project_root / "templates"
    raise FileNotFoundError("Templates directory not found")


TEMPLATE_DIR = _find_template_dir()


def _period_summaries(analyzer: ConversationAnalyzer, period: Period) -> list[PeriodSummary]:
    if period == Period.DAILY:
        daily = analyzer.group_by_day()
        return [
            PeriodSummary(
                label=d.isoformat(), start_date=d, end_date=d, days=[ds],
                total_sessions=len(ds.sessions), total_messages=ds.total_messages,
                user_messages=ds.user_messages, assistant_messages=ds.assistant_messages,
                active_days=1 if ds.total_messages > 0 else 0,
                tools_used=ds.tools_used, projects=ds.projects, topics=ds.topics,
            )
            for d, ds in sorted(daily.items())
        ]
    elif period == Period.WEEKLY:
        return analyzer.group_by_week()
    elif period == Period.MONTHLY:
        return analyzer.group_by_month()
    return analyzer.group_by_year()


def _period_to_dict(ps: PeriodSummary) -> dict:
    return {
        "label": ps.label,
        "start_date": ps.start_date.isoformat(),
        "end_date": ps.end_date.isoformat(),
        "total_sessions": ps.total_sessions,
        "total_messages": ps.total_messages,
        "user_messages": ps.user_messages,
        "assistant_messages": ps.assistant_messages,
        "active_days": ps.active_days,
        "tools_used": dict(ps.tools_used.most_common(20)),
        "projects": dict(ps.projects.most_common(20)),
        "topics": ps.topics[:30],
        "ai_summary": ps.ai_summary,
    }


def _stats_to_dict(stats: OverallStats) -> dict:
    return {
        "total_sessions": stats.total_sessions,
        "total_messages": stats.total_messages,
        "user_messages": stats.user_messages,
        "assistant_messages": stats.assistant_messages,
        "active_days": stats.active_days,
        "total_projects": stats.total_projects,
        "first_date": stats.first_date.isoformat() if stats.first_date else None,
        "last_date": stats.last_date.isoformat() if stats.last_date else None,
        "daily_activity": stats.daily_activity,
        "projects": dict(stats.projects.most_common(30)),
        "tools_used": dict(stats.tools_used.most_common(30)),
        "top_topics": stats.top_topics,
        "ai_summary": stats.ai_summary,
    }


def generate_report_data(
    analyzer: ConversationAnalyzer,
    period: Period = Period.WEEKLY,
    purpose: Purpose = Purpose.GENERAL,
    ai_summary: Optional[str] = None,
    period_summaries_with_ai: Optional[list[PeriodSummary]] = None,
) -> dict:
    stats = analyzer.overall_stats()
    stats.ai_summary = ai_summary
    summaries = period_summaries_with_ai or _period_summaries(analyzer, period)

    return {
        "period": period.value,
        "purpose": purpose.value,
        "purpose_label": PURPOSE_LABELS[purpose],
        "generated_at": date.today().isoformat(),
        "stats": _stats_to_dict(stats),
        "periods": [_period_to_dict(ps) for ps in summaries],
    }


def _safe_json_embed(data: dict) -> str:
    """JSON-encode data safe for embedding in <script> tags."""
    return json.dumps(data, ensure_ascii=False).replace("</", "<\\/").replace("<!--", "<\\!--")


def render_html_report(data: dict) -> str:
    template = (TEMPLATE_DIR / "report.html").read_text(encoding="utf-8")
    return template.replace("__REPORT_DATA__", _safe_json_embed(data))


def render_markdown_report(data: dict) -> str:
    lines = []
    stats = data["stats"]

    lines.append(f"# {data['purpose_label']}")
    lines.append("")
    lines.append(f"**Period:** {data['period']} | **Generated:** {data['generated_at']}")
    if stats["first_date"] and stats["last_date"]:
        lines.append(f"**Date range:** {stats['first_date']} \u2014 {stats['last_date']}")
    lines.append("")

    # AI Summary
    if stats.get("ai_summary"):
        lines.append("## Summary")
        lines.append("")
        lines.append(stats["ai_summary"])
        lines.append("")

    lines.append("## Overview")
    lines.append("")
    lines.append("| Metric | Value |")
    lines.append("|--------|-------|")
    lines.append(f"| Sessions | {stats['total_sessions']} |")
    lines.append(f"| Messages | {stats['total_messages']} |")
    lines.append(f"| Active Days | {stats['active_days']} |")
    lines.append(f"| Projects | {stats['total_projects']} |")
    lines.append("")

    if stats["projects"]:
        lines.append("## Projects")
        lines.append("")
        for proj, count in sorted(stats["projects"].items(), key=lambda x: -x[1]):
            lines.append(f"- **{proj}**: {count} sessions")
        lines.append("")

    if stats["tools_used"]:
        lines.append("## Tools Used")
        lines.append("")
        for tool, count in sorted(stats["tools_used"].items(), key=lambda x: -x[1])[:15]:
            lines.append(f"- `{tool}`: {count}x")
        lines.append("")

    periods = data["periods"]
    if periods:
        lines.append(f"## {data['period'].title()} Breakdown")
        lines.append("")
        for p in periods:
            lines.append(f"### {p['label']}")
            lines.append(f"- Sessions: {p['total_sessions']} | Messages: {p['total_messages']}")
            if p.get("ai_summary"):
                lines.append(f"\n{p['ai_summary']}\n")
            elif p["topics"]:
                lines.append("- Key topics:")
                for topic in p["topics"][:5]:
                    lines.append(f"  - {topic}")
            lines.append("")

    return "\n".join(lines)


def render_json_report(data: dict) -> str:
    return json.dumps(data, ensure_ascii=False, indent=2)
