"""Analyze parsed conversation data and compute statistics."""

from __future__ import annotations

from collections import Counter
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from typing import Optional

from claude_recap.parser import Session


@dataclass
class DaySummary:
    date: date
    sessions: list[Session] = field(default_factory=list)
    total_messages: int = 0
    user_messages: int = 0
    assistant_messages: int = 0
    tools_used: Counter = field(default_factory=Counter)
    projects: Counter = field(default_factory=Counter)
    topics: list[str] = field(default_factory=list)
    input_tokens: int = 0
    output_tokens: int = 0
    cache_read_tokens: int = 0
    cache_creation_tokens: int = 0


@dataclass
class PeriodSummary:
    label: str
    start_date: date
    end_date: date
    days: list[DaySummary] = field(default_factory=list)
    total_sessions: int = 0
    total_messages: int = 0
    user_messages: int = 0
    assistant_messages: int = 0
    active_days: int = 0
    tools_used: Counter = field(default_factory=Counter)
    projects: Counter = field(default_factory=Counter)
    topics: list[str] = field(default_factory=list)
    ai_summary: Optional[str] = None


@dataclass
class OverallStats:
    total_sessions: int = 0
    total_messages: int = 0
    user_messages: int = 0
    assistant_messages: int = 0
    active_days: int = 0
    total_projects: int = 0
    first_date: Optional[date] = None
    last_date: Optional[date] = None
    daily_activity: dict[str, int] = field(default_factory=dict)
    daily_tokens: dict[str, dict] = field(default_factory=dict)
    projects: Counter = field(default_factory=Counter)
    tools_used: Counter = field(default_factory=Counter)
    models_used: Counter = field(default_factory=Counter)
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    total_cache_read_tokens: int = 0
    total_cache_creation_tokens: int = 0
    top_topics: list[str] = field(default_factory=list)
    ai_summary: Optional[str] = None


class ConversationAnalyzer:
    def __init__(self, sessions: list[Session]):
        self.sessions = sessions

    def _session_date(self, s: Session) -> Optional[date]:
        return s.start_time.date() if s.start_time else None

    def _build_day(self, day: date, sessions: list[Session]) -> DaySummary:
        ds = DaySummary(date=day, sessions=sessions)
        for s in sessions:
            for m in s.messages:
                ds.total_messages += 1
                if m.role == "user":
                    ds.user_messages += 1
                else:
                    ds.assistant_messages += 1
                for t in m.tools_used:
                    ds.tools_used[t] += 1
                ds.input_tokens += m.input_tokens
                ds.output_tokens += m.output_tokens
                ds.cache_read_tokens += m.cache_read_tokens
                ds.cache_creation_tokens += m.cache_creation_tokens
            ds.projects[s.project_display] += 1
            if s.summary:
                ds.topics.append(s.summary[:80] + ("..." if len(s.summary) > 80 else ""))
        return ds

    def group_by_day(self) -> dict[date, DaySummary]:
        by_day: dict[date, list[Session]] = {}
        for s in self.sessions:
            d = self._session_date(s)
            if d:
                by_day.setdefault(d, []).append(s)
        return {d: self._build_day(d, ss) for d, ss in sorted(by_day.items())}

    def _aggregate(self, label: str, start: date, end: date, days: dict[date, DaySummary]) -> PeriodSummary:
        period_days = [ds for d, ds in sorted(days.items()) if start <= d <= end]
        ps = PeriodSummary(label=label, start_date=start, end_date=end, days=period_days)
        for ds in period_days:
            ps.total_sessions += len(ds.sessions)
            ps.total_messages += ds.total_messages
            ps.user_messages += ds.user_messages
            ps.assistant_messages += ds.assistant_messages
            ps.tools_used += ds.tools_used
            ps.projects += ds.projects
            ps.topics.extend(ds.topics)
            if ds.total_messages > 0:
                ps.active_days += 1
        return ps

    def group_by_week(self) -> list[PeriodSummary]:
        daily = self.group_by_day()
        if not daily:
            return []
        weeks: dict[tuple, tuple] = {}
        for d in daily:
            iso = d.isocalendar()
            key = (iso[0], iso[1])
            if key not in weeks:
                s = d - timedelta(days=d.weekday())
                weeks[key] = (s, s + timedelta(days=6))
        return [self._aggregate(f"{y}-W{w:02d}", s, e, daily) for (y, w), (s, e) in sorted(weeks.items())]

    def group_by_month(self) -> list[PeriodSummary]:
        daily = self.group_by_day()
        if not daily:
            return []
        months: dict[tuple, tuple] = {}
        for d in daily:
            key = (d.year, d.month)
            if key not in months:
                s = d.replace(day=1)
                e = d.replace(month=d.month + 1, day=1) - timedelta(days=1) if d.month < 12 else d.replace(day=31)
                months[key] = (s, e)
        return [self._aggregate(f"{y}-{m:02d}", s, e, daily) for (y, m), (s, e) in sorted(months.items())]

    def group_by_year(self) -> list[PeriodSummary]:
        daily = self.group_by_day()
        if not daily:
            return []
        years = {}
        for d in daily:
            if d.year not in years:
                years[d.year] = (date(d.year, 1, 1), date(d.year, 12, 31))
        return [self._aggregate(str(y), s, e, daily) for y, (s, e) in sorted(years.items())]

    def overall_stats(self) -> OverallStats:
        daily = self.group_by_day()
        stats = OverallStats()
        if not daily:
            return stats
        dates = sorted(daily.keys())
        stats.first_date, stats.last_date = dates[0], dates[-1]
        stats.active_days = len(dates)
        for d, ds in daily.items():
            d_iso = d.isoformat()
            stats.daily_activity[d_iso] = ds.total_messages
            stats.daily_tokens[d_iso] = {
                "input": ds.input_tokens, "output": ds.output_tokens,
                "cache_read": ds.cache_read_tokens, "cache_creation": ds.cache_creation_tokens,
            }
            stats.total_sessions += len(ds.sessions)
            stats.total_messages += ds.total_messages
            stats.user_messages += ds.user_messages
            stats.assistant_messages += ds.assistant_messages
            stats.total_input_tokens += ds.input_tokens
            stats.total_output_tokens += ds.output_tokens
            stats.total_cache_read_tokens += ds.cache_read_tokens
            stats.total_cache_creation_tokens += ds.cache_creation_tokens
            stats.tools_used += ds.tools_used
            stats.projects += ds.projects
        stats.total_projects = len(stats.projects)
        for s in self.sessions:
            for m in s.messages:
                if m.model:
                    stats.models_used[m.model] += 1
        recent = sorted(self.sessions, key=lambda s: s.start_time or datetime.min.replace(tzinfo=timezone.utc), reverse=True)
        stats.top_topics = [s.summary[:100] for s in recent[:20] if s.summary]
        return stats

    def filter_by_date_range(self, start: Optional[date] = None, end: Optional[date] = None) -> ConversationAnalyzer:
        filtered = [s for s in self.sessions if (d := self._session_date(s)) and (not start or d >= start) and (not end or d <= end)]
        return ConversationAnalyzer(filtered)

    def statistical_summary(self, purpose: str = "general") -> str:
        """Generate a text summary from statistics alone — no LLM needed."""
        stats = self.overall_stats()
        if not stats.first_date:
            return "No conversation data found."

        lines = []
        span = (stats.last_date - stats.first_date).days + 1
        lines.append(
            f"Over {stats.active_days} active days ({stats.first_date} — {stats.last_date}, "
            f"spanning {span} days), you had {stats.total_sessions} sessions with "
            f"{stats.total_messages:,} messages across {stats.total_projects} projects."
        )

        top_projects = stats.projects.most_common(3)
        if top_projects:
            parts = [f"{name} ({count} sessions)" for name, count in top_projects]
            lines.append(f"Top projects: {', '.join(parts)}.")

        weeks = self.group_by_week()
        if weeks:
            peak = max(weeks, key=lambda w: w.total_messages)
            lines.append(
                f"Peak activity: week of {peak.start_date} "
                f"({peak.total_sessions} sessions, {peak.total_messages:,} messages)."
            )

        top_tools = stats.tools_used.most_common(5)
        if top_tools:
            parts = [f"{name} ({count}x)" for name, count in top_tools]
            lines.append(f"Most-used tools: {', '.join(parts)}.")

        if stats.total_sessions > 0:
            avg_msgs = stats.total_messages / stats.total_sessions
            lines.append(f"Average session length: {avg_msgs:.0f} messages.")

        daily = self.group_by_day()
        if daily:
            sorted_days = sorted(daily.keys())
            streak = max_streak = 1
            for i in range(1, len(sorted_days)):
                if (sorted_days[i] - sorted_days[i - 1]).days == 1:
                    streak += 1
                    max_streak = max(max_streak, streak)
                else:
                    streak = 1
            if max_streak > 1:
                lines.append(f"Longest active streak: {max_streak} consecutive days.")

        return " ".join(lines)
