"""Allow running as `python -m claude_recap`."""

from claude_recap.cli import main

main()
