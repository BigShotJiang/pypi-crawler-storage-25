"""ecb-bs-ai-assistant."""
