# tcknvkn (Python)

Python library for validating Turkish TCKN (TC Kimlik Numarasi) and VKN (Vergi Kimlik Numarasi).

## Install

```bash
pip install tcknvkn
```

## Quick Start

```python
from tcknvkn import (
    validate_tckn,
    validate_multiple_tckn,
    validate_vkn,
    validate_multiple_vkn,
)

tckn = validate_tckn("10000000146")
print(tckn.valid)   # True
print(tckn.errors)  # []

vkn = validate_vkn("1000036109")
print(vkn.valid)    # True

bulk = validate_multiple_tckn(["10000000146", "99999999999"])
for item in bulk:
    print(item.value, item.valid)
```

## API

- `validate_tckn(value: str) -> ValidationResult`
- `validate_multiple_tckn(values: list[str]) -> list[ValidationResult]`
- `validate_vkn(value: str) -> ValidationResult`
- `validate_multiple_vkn(values: list[str]) -> list[ValidationResult]`

## ValidationResult

```python
from dataclasses import dataclass

@dataclass(frozen=True)
class ValidationResult:
    valid: bool
    value: str
    errors: list[str]
```

## Run Tests

```bash
PYTHONPATH=src python3 -m unittest discover -s tests
```

## License

MIT

## SEO Links

- Libraries hub: https://www.tcknvkn.com/kutuphaneler
- Library detail page: https://www.tcknvkn.com/kutuphaneler/python
- TC generator: https://www.tcknvkn.com/tc-uretici
- VKN generator: https://www.tcknvkn.com/vergi-no-uretici
