import unittest

from tcknvkn import (
    validate_multiple_tckn,
    validate_multiple_vkn,
    validate_tckn,
    validate_vkn,
)


class ValidationTest(unittest.TestCase):
    def test_validate_tckn_valid(self) -> None:
        result = validate_tckn("10000000146")
        self.assertTrue(result.valid)
        self.assertEqual(result.errors, [])

    def test_validate_tckn_invalid(self) -> None:
        result = validate_tckn("99999999999")
        self.assertFalse(result.valid)
        self.assertGreaterEqual(len(result.errors), 1)

    def test_validate_vkn_valid(self) -> None:
        result = validate_vkn("1000036109")
        self.assertTrue(result.valid)

    def test_validate_vkn_invalid(self) -> None:
        result = validate_vkn("1111111111")
        self.assertFalse(result.valid)

    def test_bulk_validation(self) -> None:
        tckn_results = validate_multiple_tckn(["10000000146", "99999999999"])
        vkn_results = validate_multiple_vkn(["1000036109", "1234567890"])

        self.assertEqual(len(tckn_results), 2)
        self.assertEqual(len(vkn_results), 2)


if __name__ == "__main__":
    unittest.main()
