from __future__ import annotations

import re

from .models import ValidationResult

_DIGIT_RE = re.compile(r"\D+")


def _only_digits(value: str) -> str:
    return _DIGIT_RE.sub("", str(value or ""))


def validate_tckn(value: str) -> ValidationResult:
    normalized = _only_digits(value)
    errors: list[str] = []

    if len(normalized) != 11:
        errors.append("11 haneli olmalidir.")
    if normalized.startswith("0"):
        errors.append("Ilk hane 0 olamaz.")
    if errors:
        return ValidationResult(valid=False, value=normalized, errors=errors)

    digits = [int(ch) for ch in normalized]
    odd = digits[0] + digits[2] + digits[4] + digits[6] + digits[8]
    even = digits[1] + digits[3] + digits[5] + digits[7]

    d10 = ((odd * 7 - even) % 10 + 10) % 10
    if d10 != digits[9]:
        errors.append("10. hane kontrol hanesi hatali.")

    if sum(digits[:10]) % 10 != digits[10]:
        errors.append("11. hane kontrol hanesi hatali.")

    if len(set(digits)) == 1:
        errors.append("Gecersiz oruntu: tum haneler ayni.")

    return ValidationResult(valid=not errors, value=normalized, errors=errors)


def validate_multiple_tckn(values: list[str]) -> list[ValidationResult]:
    return [validate_tckn(value) for value in values]
