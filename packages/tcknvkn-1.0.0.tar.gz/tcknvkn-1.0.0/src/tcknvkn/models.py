from __future__ import annotations

from dataclasses import dataclass, field


@dataclass(frozen=True)
class ValidationResult:
    valid: bool
    value: str
    errors: list[str] = field(default_factory=list)
