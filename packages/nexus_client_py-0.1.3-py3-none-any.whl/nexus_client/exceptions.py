"""
nexus_client.exceptions
~~~~~~~~~~~~~~~~~~~~~~~

Exception hierarchy for the nexus-client library.

All exceptions inherit from :class:`NexusError`, so you can catch
``NexusError`` to handle any library-level failure::

    from nexus_client import NexusClient, NexusError

    try:
        client.list_projects()
    except NexusError as e:
        print(e.message, e.status_code)
"""


class NexusError(Exception):
    """Base exception for all nexus-client errors.

    Attributes:
        message: Human-readable error description.
        status_code: HTTP status code from the API, or ``None``
            if the error did not originate from an HTTP response.

    Example::

        try:
            client.get_project(999)
        except NexusError as e:
            print(e.message)       # "Project not found"
            print(e.status_code)   # 404
    """

    def __init__(self, message: str, status_code: int | None = None):
        self.message = message
        self.status_code = status_code
        super().__init__(message)


class AuthError(NexusError):
    """Raised when authentication or authorization fails (HTTP 401/403).

    Common causes:

    - Invalid or expired API key.
    - API key does not have access to the requested workspace.
    - User account is deactivated.

    Example::

        try:
            client.list_projects()
        except AuthError:
            print("Check your API key and workspace_id")
    """
    pass


class NotFoundError(NexusError):
    """Raised when a requested resource is not found (HTTP 404).

    Common causes:

    - Project ID does not exist or is not in the workspace.
    - File ID does not belong to the specified project.
    - Schema has not been created for the project.

    Example::

        try:
            client.get_project(999)
        except NotFoundError:
            print("Project does not exist")
    """
    pass


class ValidationError(NexusError):
    """Raised when annotation data fails JSON Schema validation (HTTP 422).

    This is raised by the server when pushing annotations. For client-side
    validation (no API call), use :meth:`NexusClient.validate` or
    :meth:`FileContext.validate` which return a list of error strings instead.

    Attributes:
        errors: List of validation error messages.

    Example::

        try:
            file.push_annotation(data={"bad": "data"}, annotator_name="Test")
        except ValidationError as e:
            for err in e.errors:
                print(err)
    """

    def __init__(self, message: str, errors: list[str]):
        super().__init__(message)
        self.errors = errors
