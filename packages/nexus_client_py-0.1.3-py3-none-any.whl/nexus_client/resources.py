"""
nexus_client.resources
~~~~~~~~~~~~~~~~~~~~~~

Context classes for scoped project and file operations.

:class:`ProjectContext` is obtained via :meth:`NexusClient.project` and
provides scoped access to files, schema, and batch push.
:class:`FileContext` is obtained via :meth:`ProjectContext.files` or
:meth:`ProjectContext.file` and provides per-file content, versions,
validation, and push.

Usage::

    with client.project(5) as project:
        schema = project.schema()
        for file in project.files():
            content = file.content()
            errors = file.validate(my_data)
            if not errors:
                annotation = my_model.predict(content)
                file.push_annotation(data=annotation, annotator_name="MyModel")
"""

from __future__ import annotations
from typing import TYPE_CHECKING

from .models import AnnotationVersion, File, PushSummary, Schema
from .validator import validate

if TYPE_CHECKING:
    from .client import NexusClient


class FileContext:
    """Scoped operations on a single file within a project.

    Provides access to file content, annotation versions, validation,
    and push operations. Obtained from :meth:`ProjectContext.files`
    or :meth:`ProjectContext.file`.

    Attributes:
        id: The ProjectFile ID.
        label: Display filename.
        path: Storage path.

    Example::

        with client.project(5) as project:
            for file in project.files():
                content = file.content()
                versions = file.versions(type="ai")
                annotation = my_model.predict(content)
                file.push_annotation(data=annotation, annotator_name="MyModel")
    """

    def __init__(self, client: NexusClient, project_id: int, file: File):
        self._client = client
        self._project_id = project_id
        self._file = file
        self._schema: Schema | None = None

    @property
    def id(self) -> int:
        """The ProjectFile ID."""
        return self._file.id

    @property
    def label(self) -> str:
        """Display filename (e.g., ``"invoice_001.pdf"``)."""
        return self._file.label

    @property
    def path(self) -> str:
        """Storage path (internal)."""
        return self._file.path

    def content(self) -> str:
        """Get the text content or PDF URL for this file.

        For ``json_extraction`` projects, returns the raw text content.
        For ``pdf_json_extraction`` projects, returns a URL to the PDF.

        Returns:
            File content as a string.

        Example::

            content = file.content()
            print(content[:200])
        """
        return self._client.get_file_content(self._project_id, self.id)

    def versions(self, type: str | None = None) -> list[AnnotationVersion]:
        """List annotation versions for this file.

        Args:
            type: Filter by version type:

                - ``"ai"`` — only AI versions (a1, a2, ...).
                - ``"human"`` — only human versions (v1, v2, ...).
                - ``None`` — all versions (default).

        Returns:
            List of :class:`~nexus_client.models.AnnotationVersion`.

        Example::

            ai_versions = file.versions(type="ai")
            for v in ai_versions:
                print(f"{v.version_label} ({v.status})")
        """
        return self._client.get_file_versions(self.id, type=type)

    def get_version_data(self, version_id: int, version_type: str = "ai") -> dict:
        """Fetch the annotation data for a specific version.

        Args:
            version_id: The version record ID (from :attr:`AnnotationVersion.id`).
            version_type: ``"ai"`` (default) or ``"human"``.

        Returns:
            The annotation data dict.

        Example::

            versions = file.versions(type="ai")
            data = file.get_version_data(versions[0].id)
            print(data)
        """
        return self._client.get_version_data(self.id, version_id, version_type)

    def validate(self, data: dict) -> list[str]:
        """Validate annotation data against the project schema (client-side).

        Fetches the project schema on first call (cached for subsequent calls).
        No API call is made for the validation itself.

        Args:
            data: The annotation data dict to validate.

        Returns:
            List of validation error strings. Empty if valid.

        Example::

            annotation = my_model.predict(content)
            errors = file.validate(annotation)
            if errors:
                print(f"Skipping {file.label}: {errors}")
            else:
                file.push_annotation(data=annotation, annotator_name="MyModel")
        """
        if self._schema is None:
            self._schema = self._client.get_schema(self._project_id)
        return validate(data, self._schema.definition)

    def push_annotation(
        self,
        data: dict,
        annotator_name: str,
        metadata: dict | None = None,
    ) -> AnnotationVersion:
        """Push an annotation as an AI version for this file.

        Creates an ``EXT: {annotator_name}`` AI annotator (or reuses an
        existing one) and pushes the annotation data. Version number
        auto-increments (a1, a2, a3, ...).

        Args:
            data: The annotation data dict (must conform to project schema).
            annotator_name: Display name for the annotator (e.g.,
                ``"MyScript"``). Stored as ``"EXT: MyScript"`` in Nexus.
            metadata: Optional dict of extra metadata to store with the
                annotation (e.g., ``{"method": "gpt-4"}``).

        Returns:
            An :class:`~nexus_client.models.AnnotationVersion` for the
            created version.

        Raises:
            ValidationError: If ``data`` fails schema validation.

        Example::

            version = file.push_annotation(
                data={"order_id": "ORD-001", ...},
                annotator_name="InvoiceExtractor",
            )
            print(f"{file.label} -> {version.version_label}")  # "a1"
        """
        return self._client.push_annotation(self._project_id, self.id, data, annotator_name, metadata)


class ProjectContext:
    """Scoped operations on a project.

    Provides access to project schema, files, and batch push operations.
    Obtained via :meth:`NexusClient.project`.

    Use as a context manager (recommended)::

        with client.project(5) as project:
            schema = project.schema()
            files = project.files()

    Or standalone::

        project = client.project(5)
        schema = project.schema()

    Attributes:
        id: The project ID.
    """

    def __init__(self, client: NexusClient, project_id: int):
        self._client = client
        self._project_id = project_id
        self._schema: Schema | None = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        pass

    @property
    def id(self) -> int:
        """The project ID."""
        return self._project_id

    def schema(self) -> Schema:
        """Get the current JSON schema for this project.

        The result is cached after the first call.

        Returns:
            A :class:`~nexus_client.models.Schema` object.

        Raises:
            NotFoundError: If no schema exists for this project.

        Example::

            schema = project.schema()
            print(f"{schema.name} v{schema.version}")
            print(list(schema.definition["properties"].keys()))
        """
        if self._schema is None:
            self._schema = self._client.get_schema(self._project_id)
        return self._schema

    def files(self) -> list[FileContext]:
        """List all files in this project as :class:`FileContext` objects.

        Returns:
            List of :class:`FileContext` objects.

        Example::

            for file in project.files():
                print(f"{file.id}: {file.label}")
                content = file.content()
        """
        raw_files = self._client.list_files(self._project_id)
        return [FileContext(self._client, self._project_id, f) for f in raw_files]

    def file(self, file_id: int) -> FileContext:
        """Get a single file context by ID.

        This does not make an API call — it creates a :class:`FileContext`
        directly. Use this when you already know the file ID.

        Args:
            file_id: The ProjectFile ID.

        Returns:
            A :class:`FileContext` object.

        Example::

            file = project.file(42)
            content = file.content()
            versions = file.versions(type="ai")
        """
        return FileContext(
            self._client,
            self._project_id,
            File(id=file_id, label="", path="", project_id=self._project_id),
        )

    def push_annotations(
        self,
        annotations: dict[int, dict],
        annotator_name: str,
        metadata: dict | None = None,
    ) -> PushSummary:
        """Push annotations for multiple files in one batch.

        All files in the batch receive the same version number. Individual
        file failures don't abort the batch — they're collected in
        :attr:`PushSummary.errors`.

        Args:
            annotations: Dict mapping ``file_id`` (int) to annotation data
                (dict). Example: ``{42: {"field": "val"}, 43: {"field": "val2"}}``.
            annotator_name: Display name for the annotator.
            metadata: Optional dict of extra metadata (applied to all files).

        Returns:
            A :class:`~nexus_client.models.PushSummary`.

        Example::

            results = {f.id: extract(f.content()) for f in project.files()}
            summary = project.push_annotations(
                annotations=results,
                annotator_name="BatchExtractor",
            )
            print(f"{summary.success}/{summary.total} succeeded")
        """
        return self._client.push_annotations(self._project_id, annotations, annotator_name, metadata)
