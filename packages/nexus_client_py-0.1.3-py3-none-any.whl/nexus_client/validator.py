"""
nexus_client.validator
~~~~~~~~~~~~~~~~~~~~~~

Client-side JSON Schema Draft 7 validation.

Validates annotation data locally before pushing to the server,
providing fast feedback without an API round-trip.

Usage::

    from nexus_client.validator import validate

    errors = validate(
        data={"name": "Alice"},
        schema_definition={"type": "object", "required": ["name", "age"], ...},
    )
    if errors:
        print("Validation failed:", errors)
"""

from jsonschema import Draft7Validator


def validate(data: dict, schema_definition: dict) -> list[str]:
    """Validate annotation data against a JSON Schema Draft 7 definition.

    This runs entirely client-side — no API call is made. Use this to
    check annotation data before calling :meth:`~nexus_client.NexusClient.push_annotation`
    to avoid unnecessary server round-trips.

    Args:
        data: The annotation data dict to validate.
        schema_definition: The JSON Schema Draft 7 definition dict.
            Obtain this from :attr:`Schema.definition`.

    Returns:
        A list of validation error message strings.
        Empty list means the data is valid.

    Example::

        schema = client.get_schema(project_id=5)
        errors = validate(my_data, schema.definition)
        if errors:
            for e in errors:
                print(f"  - {e}")
        else:
            print("Valid!")
    """
    validator = Draft7Validator(schema_definition)
    return [err.message for err in validator.iter_errors(data)]
