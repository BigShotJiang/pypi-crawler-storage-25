"""
nexus_client.client
~~~~~~~~~~~~~~~~~~~

Main entry point for the nexus-client library.

Usage::

    from nexus_client import NexusClient

    client = NexusClient(
        url="https://nexus.example.com",
        api_key="nxs_...",
        workspace_id=1,
    )

    projects = client.list_projects()

The client can also be used as a context manager::

    with NexusClient(url=..., api_key=..., workspace_id=1) as client:
        projects = client.list_projects()
"""

from __future__ import annotations

import httpx

from .exceptions import AuthError, NexusError, NotFoundError, ValidationError
from .models import AnnotationVersion, File, Project, PushSummary, Schema
from .resources import FileContext, ProjectContext
from .validator import validate


class NexusClient:
    """Client for the Nexus annotation platform.

    Provides both flat top-level methods and scoped context managers
    for working with projects and files.

    Args:
        url: Base URL of the Nexus instance (e.g., ``"https://nexus.example.com"``).
            Do not include ``/api/v2`` — it is appended automatically.
        api_key: API key string (starts with ``"nxs_"``). Generate one
            from **Settings > API Keys** in the Nexus UI.
        workspace_id: Workspace ID to scope all operations to. Visible
            in the Nexus UI workspace switcher.
        timeout: HTTP request timeout in seconds. Default ``30.0``.

    Example::

        client = NexusClient(
            url="https://nexus.example.com",
            api_key="nxs_abc123...",
            workspace_id=1,
        )

        # Flat methods
        projects = client.list_projects()
        schema = client.get_schema(project_id=5)

        # Context manager for scoped project operations
        with client.project(5) as project:
            for file in project.files():
                content = file.content()

        client.close()

    The client itself can be used as a context manager to auto-close::

        with NexusClient(url=..., api_key=..., workspace_id=1) as client:
            projects = client.list_projects()

    Raises:
        AuthError: On 401/403 responses (bad API key, expired, no access).
        NotFoundError: On 404 responses (project/file/schema not found).
        ValidationError: On 422 responses (annotation fails schema validation).
        NexusError: On any other non-2xx response.
    """

    def __init__(
        self,
        url: str,
        api_key: str,
        workspace_id: int,
        timeout: float = 30.0,
    ):
        self.base_url = url.rstrip("/") + "/api/v2"
        self.workspace_id = workspace_id
        self._http = httpx.Client(
            base_url=self.base_url,
            headers={
                "X-API-Key": api_key,
                "X-Workspace-Id": str(workspace_id),
                "Content-Type": "application/json",
            },
            timeout=timeout,
        )

    def close(self) -> None:
        """Close the underlying HTTP connection.

        Called automatically when using the client as a context manager.
        """
        self._http.close()

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()

    # ── HTTP helpers ───────────────────────────────────────────────────────

    def _request(self, method: str, path: str, **kwargs) -> dict | list:
        """Send an HTTP request and handle error responses."""
        resp = self._http.request(method, path, **kwargs)
        if resp.status_code in (401, 403):
            raise AuthError(resp.json().get("detail", "Authentication failed"), resp.status_code)
        if resp.status_code == 404:
            raise NotFoundError(resp.json().get("detail", "Not found"), 404)
        if resp.status_code == 422:
            detail = resp.json().get("detail", "Validation error")
            raise ValidationError(detail, [detail])
        if resp.status_code >= 400:
            detail = resp.json().get("detail", resp.text) if resp.headers.get("content-type", "").startswith("application/json") else resp.text
            raise NexusError(detail, resp.status_code)
        if resp.status_code == 204:
            return {}
        return resp.json()

    def _get(self, path: str, **kwargs) -> dict | list:
        """Send a GET request."""
        return self._request("GET", path, **kwargs)

    def _post(self, path: str, **kwargs) -> dict | list:
        """Send a POST request."""
        return self._request("POST", path, **kwargs)

    # ── Projects ───────────────────────────────────────────────────────────

    def list_projects(self) -> list[Project]:
        """List all projects in the workspace.

        Returns:
            List of :class:`~nexus_client.models.Project` objects.

        Example::

            for p in client.list_projects():
                print(f"{p.id}: {p.name} ({p.project_type})")
        """
        data = self._get("/projects/")
        return [Project.from_api(p) for p in data]

    def get_project(self, project_id: int) -> Project:
        """Get a single project by ID.

        Args:
            project_id: The project ID.

        Returns:
            A :class:`~nexus_client.models.Project` object.

        Raises:
            NotFoundError: If the project does not exist in the workspace.

        Example::

            project = client.get_project(5)
            print(project.name, project.file_count)
        """
        data = self._get(f"/projects/{project_id}")
        return Project.from_api(data["project"])

    # ── Files ──────────────────────────────────────────────────────────────

    def list_files(self, project_id: int) -> list[File]:
        """List all files in a project.

        Returns deduplicated files (the underlying API may return multiple
        rows per file if it has multiple task assignments).

        Args:
            project_id: The project ID.

        Returns:
            List of :class:`~nexus_client.models.File` objects.

        Example::

            files = client.list_files(project_id=5)
            for f in files:
                print(f"{f.id}: {f.label}")
        """
        data = self._get(f"/projects/{project_id}/files-with-tasks", params={"page": 1, "page_size": 500})
        seen = set()
        files = []
        for f in data.get("files", []):
            if f["id"] not in seen:
                seen.add(f["id"])
                files.append(File(id=f["id"], label=f["label"], path=f.get("path", ""), project_id=project_id))
        return files

    def get_file_content(self, project_id: int, file_id: int) -> str:
        """Get the text content of a file.

        For ``json_extraction`` projects, returns the raw text content.
        For ``pdf_json_extraction`` projects, returns a URL to the PDF file
        that can be downloaded separately.

        Args:
            project_id: The project ID (unused in the API call but kept
                for consistency with the context manager interface).
            file_id: The ProjectFile ID.

        Returns:
            File text content (str) or PDF URL (str).

        Example::

            content = client.get_file_content(project_id=5, file_id=42)
            print(content[:200])
        """
        data = self._get(f"/tools/json-annotator/file/{file_id}", params={"view_only": "true"})
        return data.get("file_url") or data.get("file_content") or ""

    # ── Schema ─────────────────────────────────────────────────────────────

    def get_schema(self, project_id: int) -> Schema:
        """Get the current JSON schema for a project.

        Only available for ``json_extraction`` and ``pdf_json_extraction``
        project types.

        Args:
            project_id: The project ID.

        Returns:
            A :class:`~nexus_client.models.Schema` object with the current
            version's definition.

        Raises:
            NotFoundError: If no schema has been created for the project.

        Example::

            schema = client.get_schema(project_id=5)
            print(f"{schema.name} v{schema.version}")
            print(list(schema.definition["properties"].keys()))
        """
        data = self._get(f"/projects/{project_id}/schema")
        return Schema.from_api(data)

    # ── Validation ─────────────────────────────────────────────────────────

    def validate(self, data: dict, schema: Schema) -> list[str]:
        """Validate annotation data against a schema (client-side).

        Runs JSON Schema Draft 7 validation locally — no API call is made.
        Use this to check data before pushing to avoid server round-trips.

        Args:
            data: The annotation data dict to validate.
            schema: A :class:`~nexus_client.models.Schema` object (from
                :meth:`get_schema`).

        Returns:
            List of validation error message strings. Empty if valid.

        Example::

            schema = client.get_schema(project_id=5)
            errors = client.validate(data=annotation, schema=schema)
            if errors:
                print("Invalid:", errors)
        """
        return validate(data, schema.definition)

    # ── Push Annotations ───────────────────────────────────────────────────

    def push_annotation(
        self,
        project_id: int,
        file_id: int,
        data: dict,
        annotator_name: str,
        metadata: dict | None = None,
    ) -> AnnotationVersion:
        """Push a single annotation as an AI version.

        Creates an ``EXT: {annotator_name}`` AI annotator (or reuses an
        existing one) and pushes the annotation data. The version number
        auto-increments per file (a1, a2, a3, ...).

        The annotation data is validated against the project's current
        schema on the server. Use :meth:`validate` first for faster
        client-side feedback.

        Args:
            project_id: The project ID.
            file_id: The ProjectFile ID.
            data: The annotation data dict (must conform to project schema).
            annotator_name: Display name for the annotator (e.g.,
                ``"MyScript"``). Stored as ``"EXT: MyScript"`` in Nexus.
            metadata: Optional dict of extra metadata to store with the
                annotation (e.g., ``{"method": "gpt-4", "confidence": 0.95}``).

        Returns:
            An :class:`~nexus_client.models.AnnotationVersion` for the
            created version.

        Raises:
            ValidationError: If ``data`` fails schema validation.
            NotFoundError: If the project or file is not found.

        Example::

            version = client.push_annotation(
                project_id=5,
                file_id=42,
                data={"field": "value"},
                annotator_name="MyScript",
                metadata={"method": "gpt-4"},
            )
            print(f"Created {version.version_label}")  # "a1"
        """
        body: dict = {"annotation_data": data, "annotator_name": annotator_name}
        if metadata:
            body["metadata"] = metadata
        resp = self._post(f"/ext/projects/{project_id}/files/{file_id}/annotations", json=body)
        return AnnotationVersion.from_push(resp)

    def push_annotations(
        self,
        project_id: int,
        annotations: dict[int, dict],
        annotator_name: str,
        metadata: dict | None = None,
    ) -> PushSummary:
        """Push annotations for multiple files in one batch.

        All files in the batch receive the **same version number** (e.g.,
        if the highest existing AI version across the batch is a2, all
        files get a3). This matches the import behavior.

        Individual file failures don't abort the batch — they're collected
        in :attr:`PushSummary.errors`.

        Args:
            project_id: The project ID.
            annotations: Dict mapping ``file_id`` (int) to annotation data
                (dict). Example: ``{42: {"field": "val"}, 43: {"field": "val2"}}``.
            annotator_name: Display name for the annotator.
            metadata: Optional dict of extra metadata (applied to all files).

        Returns:
            A :class:`~nexus_client.models.PushSummary` with success/failure
            counts and per-file error details.

        Example::

            summary = client.push_annotations(
                project_id=5,
                annotations={42: data1, 43: data2},
                annotator_name="BatchScript",
            )
            print(f"{summary.success}/{summary.total} succeeded")
            for err in summary.errors:
                print(f"  File {err['file_id']}: {err['error']}")
        """
        body: dict = {
            "annotations": {str(k): v for k, v in annotations.items()},
            "annotator_name": annotator_name,
        }
        if metadata:
            body["metadata"] = metadata
        resp = self._post(f"/ext/projects/{project_id}/annotations/batch", json=body)
        return PushSummary(**resp)

    # ── Versions ───────────────────────────────────────────────────────────

    def get_file_versions(self, file_id: int, type: str | None = None) -> list[AnnotationVersion]:
        """List annotation versions for a file.

        Args:
            file_id: The ProjectFile ID.
            type: Filter by version type:

                - ``"ai"`` — only AI versions (a1, a2, ...).
                - ``"human"`` — only human versions (v1, v2, ...).
                - ``None`` — all versions (default).

        Returns:
            List of :class:`~nexus_client.models.AnnotationVersion` objects.

        Example::

            # All versions
            all_versions = client.get_file_versions(file_id=42)

            # AI only
            ai_versions = client.get_file_versions(file_id=42, type="ai")
            for v in ai_versions:
                print(f"{v.version_label} ({v.status})")
        """
        data = self._get(f"/tools/json-annotator/file/{file_id}/versions")
        results = []
        if type != "human":
            for v in data.get("ai_versions", []):
                v["type"] = "ai"
                results.append(AnnotationVersion.from_api(v))
        if type != "ai":
            for v in data.get("human_versions", []):
                v["type"] = "human"
                results.append(AnnotationVersion.from_api(v))
        return results

    def get_version_data(self, file_id: int, version_id: int, version_type: str = "ai") -> dict:
        """Fetch the annotation data for a specific version.

        Args:
            file_id: The ProjectFile ID.
            version_id: The version record ID (from :attr:`AnnotationVersion.id`).
            version_type: ``"ai"`` (default) or ``"human"``.

        Returns:
            The annotation data dict.

        Example::

            versions = client.get_file_versions(file_id=42, type="ai")
            for v in versions:
                data = client.get_version_data(file_id=42, version_id=v.id)
                print(f"{v.version_label}: {list(data.keys())}")
        """
        data = self._get(
            f"/tools/json-annotator/file/{file_id}/version/{version_id}",
            params={"version_type": version_type},
        )
        return data.get("annotation_data", {})

    # ── Context manager ────────────────────────────────────────────────────

    def project(self, project_id: int) -> ProjectContext:
        """Get a project context for scoped operations.

        Returns a :class:`~nexus_client.resources.ProjectContext` that
        provides convenient access to files, schema, and push operations
        scoped to a single project.

        Can be used as a context manager (recommended) or standalone.

        Args:
            project_id: The project ID.

        Returns:
            A :class:`~nexus_client.resources.ProjectContext`.

        Example::

            with client.project(5) as project:
                schema = project.schema()
                for file in project.files():
                    content = file.content()
                    annotation = my_model.predict(content)
                    file.push_annotation(data=annotation, annotator_name="MyModel")
        """
        return ProjectContext(self, project_id)
