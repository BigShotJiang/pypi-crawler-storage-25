"""
nexus_client.models
~~~~~~~~~~~~~~~~~~~

Pydantic models representing Nexus API resources.

These are returned by :class:`~nexus_client.NexusClient` methods and
:class:`~nexus_client.resources.ProjectContext` /
:class:`~nexus_client.resources.FileContext` methods. You typically
don't construct them directly.
"""

from __future__ import annotations
from pydantic import BaseModel


class Project(BaseModel):
    """A Nexus project.

    Attributes:
        id: Unique project identifier.
        name: Project display name.
        description: Optional project description.
        project_type: One of ``"json_extraction"``, ``"pdf_json_extraction"``,
            ``"productivity"``, or ``"document_extraction"``.
        file_count: Number of files in the project.

    Example::

        projects = client.list_projects()
        for p in projects:
            print(f"{p.id}: {p.name} ({p.project_type}, {p.file_count} files)")
    """

    id: int
    name: str
    description: str | None = None
    project_type: str
    file_count: int = 0

    @classmethod
    def from_api(cls, data: dict) -> Project:
        """Create a Project from an API response dict."""
        return cls(**data)


class File(BaseModel):
    """A file within a Nexus project.

    The ``id`` is the ``ProjectFile.id`` (junction table ID), not the
    physical file ID. Always use this ID when calling annotator endpoints.

    Attributes:
        id: ProjectFile ID — use this for all file operations.
        label: Display filename (e.g., ``"invoice_001.pdf"``).
        path: Storage path (internal).
        project_id: Parent project ID, if known.

    Example::

        files = client.list_files(project_id=5)
        for f in files:
            print(f"{f.id}: {f.label}")
    """

    id: int
    label: str
    path: str
    project_id: int | None = None

    @classmethod
    def from_api(cls, data: dict) -> File:
        """Create a File from an API response dict."""
        return cls(
            id=data["id"],
            label=data.get("label", ""),
            path=data.get("path", ""),
            project_id=data.get("project_id"),
        )


class Schema(BaseModel):
    """A versioned JSON Schema for a project.

    Nexus projects (``json_extraction`` / ``pdf_json_extraction``) have
    a JSON Schema that defines the expected annotation structure. Schemas
    are versioned — this object represents the **current** version.

    Attributes:
        id: Schema ID (parent record).
        name: Schema display name.
        version: Current version number (e.g., ``2``).
        version_id: Current version record ID (used internally for push).
        definition: The JSON Schema Draft 7 definition dict.

    Example::

        schema = client.get_schema(project_id=5)
        print(f"{schema.name} v{schema.version}")
        print(schema.definition["properties"].keys())
    """

    id: int
    name: str
    version: int
    version_id: int
    definition: dict

    @classmethod
    def from_api(cls, data: dict) -> Schema:
        """Create a Schema from an API response dict."""
        cv = data["current_version"]
        return cls(
            id=data["id"],
            name=data["name"],
            version=cv["version_number"],
            version_id=cv["id"],
            definition=cv["schema_definition"],
        )


class AnnotationVersion(BaseModel):
    """An annotation version for a file.

    Versions are either **human** (``v1``, ``v2``, ...) or **AI** (``a1``,
    ``a2``, ...). AI versions are created by external tools (like this
    client) or the built-in AI annotator. Human versions are created by
    annotators in the Nexus UI.

    Attributes:
        id: Version record ID (use with :meth:`FileContext.get_version_data`).
        type: ``"ai"`` or ``"human"``.
        version_number: Raw version number (e.g., ``3``).
        version_label: Display label (e.g., ``"a3"`` or ``"v3"``).
        status: Version status — ``"published"`` for AI, ``"draft"``/
            ``"published"``/``"archived"`` for human.
        created_at: ISO 8601 timestamp, or ``None``.
        annotation_data: The annotation JSON, populated only when fetched
            individually (not during listing).

    Example::

        versions = file.versions(type="ai")
        for v in versions:
            print(f"{v.version_label} ({v.status}) created {v.created_at}")
    """

    id: int
    type: str
    version_number: int
    version_label: str
    status: str
    created_at: str | None = None
    annotation_data: dict | None = None

    @classmethod
    def from_api(cls, data: dict) -> AnnotationVersion:
        """Create an AnnotationVersion from a version listing API response."""
        vtype = data.get("type", "ai")
        vnum = data.get("version_number", 0)
        return cls(
            id=data["id"],
            type=vtype,
            version_number=vnum,
            version_label=f"a{vnum}" if vtype == "ai" else f"v{vnum}",
            status=data.get("status", ""),
            created_at=data.get("created_at"),
        )

    @classmethod
    def from_push(cls, data: dict) -> AnnotationVersion:
        """Create an AnnotationVersion from a push endpoint response."""
        return cls(
            id=data["id"],
            type="ai",
            version_number=data["version_number"],
            version_label=data["version_label"],
            status="published",
            created_at=data.get("created_at"),
        )


class PushSummary(BaseModel):
    """Result of a batch annotation push.

    Attributes:
        total: Total number of annotations attempted.
        success: Number of annotations successfully pushed.
        failed: Number of annotations that failed.
        errors: List of error dicts, each with ``file_id`` and ``error`` keys.
        versions: List of version dicts for successfully pushed annotations,
            each with ``id``, ``file_id``, ``version_number``, ``version_label``.

    Example::

        summary = project.push_annotations(
            annotations={42: data1, 43: data2},
            annotator_name="MyModel",
        )
        print(f"{summary.success}/{summary.total} succeeded")
        for err in summary.errors:
            print(f"  File {err['file_id']}: {err['error']}")
    """

    total: int
    success: int
    failed: int
    errors: list[dict]
    versions: list[dict]
