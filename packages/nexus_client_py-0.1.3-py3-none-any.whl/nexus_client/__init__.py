"""
nexus-client
~~~~~~~~~~~~

Python client for the Nexus annotation platform.

Quick start::

    from nexus_client import NexusClient

    client = NexusClient(
        url="https://nexus.example.com",
        api_key="nxs_...",
        workspace_id=1,
    )

    # List projects
    for p in client.list_projects():
        print(p.name)

    # Scoped project operations
    with client.project(5) as project:
        for file in project.files():
            content = file.content()
            annotation = my_model.predict(content)
            file.push_annotation(data=annotation, annotator_name="MyModel")

Full documentation: https://github.com/intelliusrecodesolutions/nexus-client
"""

try:
    from importlib.metadata import version as _version
    __version__ = _version("nexus-client-py")
except Exception:
    __version__ = "0.0.0-dev"

from .client import NexusClient
from .exceptions import AuthError, NexusError, NotFoundError, ValidationError
from .models import AnnotationVersion, File, Project, PushSummary, Schema
from .resources import FileContext, ProjectContext

__all__ = [
    "NexusClient",
    "NexusError",
    "AuthError",
    "NotFoundError",
    "ValidationError",
    "Project",
    "File",
    "Schema",
    "AnnotationVersion",
    "PushSummary",
    "FileContext",
    "ProjectContext",
]
