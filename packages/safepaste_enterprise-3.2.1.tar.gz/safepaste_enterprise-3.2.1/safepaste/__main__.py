#!/usr/bin/env python3
"""
safepaste — SafePaste Enterprise CLI: same global threat patterns as the browser extension.
Free tier: IPv4 + API-style tokens only → [DEVSEC_n], no vault (no --unmask for those).
Pro tier: Gumroad-verified license + toggles; vault persisted; full unmask support.
"""
from __future__ import annotations

__version__ = "3.2.1"


import argparse
import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path
from typing import Callable

try:
    import redis  # type: ignore[import-untyped]

    HAS_REDIS = True
except ImportError:
    HAS_REDIS = False

VAULT_PATH = Path.home() / ".safepaste" / "vault.json"
CONFIG_PATH = Path.home() / ".safepaste" / "config.json"
REDIS_ENV_VAR = "SAFEPASTE_REDIS_URL"
REDIS_HASH_KEY = "safepaste:vault"

GUMROAD_VERIFY_URL = "https://api.gumroad.com/v2/licenses/verify"
# Slug from https://logicgridai.gumroad.com/l/safepaste (Gumroad API expects permalink, not full URL).
GUMROAD_PRODUCT_PERMALINK = "safepaste"

DEFAULT_CONFIG: dict = {
    "is_licensed": False,
    "devsec_mode": True,
    "fintech_shield": True,
    "custom_keywords": [],
    "gumroad_license_key": "",
}

# ---------------------------------------------------------------------------
# Validators (mirror content.js)
# ---------------------------------------------------------------------------


def _is_pure_hex(s: str) -> bool:
    return bool(re.fullmatch(r"[a-fA-F0-9]+", s))


def _api_match_ok(match: str) -> bool:
    """Return True if this API-like match should be redacted (False = skip false positive)."""
    lower = match.lower()
    if lower.startswith("bearer "):
        t = lower[7:].strip()
        return not (len(t) >= 16 and _is_pure_hex(t))
    if re.match(r"^(sk|pk)-", lower):
        t = re.sub(r"^(sk|pk)-", "", lower).strip()
        return not (len(t) >= 16 and _is_pure_hex(t))
    return True


def _valid_ipv4(s: str) -> bool:
    try:
        octets = [int(x) for x in s.split(".")]
    except ValueError:
        return False
    if len(octets) != 4:
        return False
    if octets[0] in (127, 255):
        return False
    return all(0 <= o <= 255 for o in octets)


def _luhn_valid(digits_only: str) -> bool:
    if len(digits_only) not in (15, 16):
        return False
    s = 0
    alt = False
    for ch in reversed(digits_only):
        if not ch.isdigit():
            return False
        n = int(ch)
        if alt:
            n *= 2
            if n > 9:
                n -= 9
        s += n
        alt = not alt
    return s % 10 == 0


def _valid_credit_card(match: str) -> bool:
    d = re.sub(r"\D", "", match)
    return len(d) in (15, 16) and _luhn_valid(d)


# ---------------------------------------------------------------------------
# Regexes (aligned with extension content.js)
# ---------------------------------------------------------------------------

RE_IPV4 = re.compile(r"\b(\d{1,3})\.(\d{1,3})\.(\d{1,3})\.(\d{1,3})\b")

RE_MAC = re.compile(r"\b(?:[0-9A-Fa-f]{2}[:-]){5}[0-9A-Fa-f]{2}\b")

RE_API_KEYS = re.compile(
    r"\b(?:sk|pk)-[a-zA-Z0-9_-]{16,}\b|"
    r"\bbearer\s+[a-zA-Z0-9._~+/=-]{16,}\b|"
    r"\bxox[bap]-[a-zA-Z0-9-]{10,}\b|"
    r"\bsk-ant-[a-zA-Z0-9_-]{10,}\b|"
    r"\bAKIA[0-9A-Z]{16}\b|"
    r"\bASIA[0-9A-Z]{16}\b|"
    r"\bghp_[a-zA-Z0-9]{20,}\b|"
    r"\bgithub_pat_[a-zA-Z0-9_]{20,}\b|"
    r"\bgho_[a-zA-Z0-9]{20,}\b|"
    r"\bghu_[a-zA-Z0-9]{20,}\b|"
    r"\bghs_[a-zA-Z0-9]{20,}\b",
    re.IGNORECASE,
)

RE_CREDIT_CARD = re.compile(r"\b(?:\d{4}[-\s]?){3}\d{3,4}\b")

RE_US_SSN = re.compile(
    r"\b(?!000|666|9\d{2})\d{3}-(?!00)\d{2}-(?!0000)\d{4}\b"
)

RE_EU_IBAN = re.compile(r"\b[A-Z]{2}\d{2}[A-Z0-9]{11,30}\b", re.IGNORECASE)

RE_UK_NINO = re.compile(r"\b[A-Z]{2}\d{6}[A-Z]\b")

RE_NG_BANK = re.compile(r"\b\d{10}\b")

# Nigeria mobile: 11 digits, leading 0, then 70/80/81/90/91 + 8 digits (matches extension).
RE_NG_PHONE = re.compile(r"\b0[789][01]\d{8}\b")

# 11-digit NIN, excluding Nigeria phone pattern (lookahead).
RE_NG_NIN = re.compile(r"\b(?!0[789][01]\d{8})\d{11}\b")

# Placeholder in text: [LABEL_123]; vault JSON keys: LABEL_123 (non-greedy for labels with underscores)
_PLACEHOLDER_RE = re.compile(r"\[(.+?)_(\d+)\]")


def _parse_vault_key(k: str) -> tuple[str, int] | None:
    if "_" not in k:
        return None
    base, num = k.rsplit("_", 1)
    if not num.isdigit():
        return None
    return base, int(num)


# Threat row: (priority, vault_label, pattern, validator)
# validator(text) -> True means mask this match
ThreatRow = tuple[int, str, re.Pattern[str], Callable[[str], bool]]

FREE_THREATS: list[ThreatRow] = [
    (10, "DEVSEC", RE_IPV4, _valid_ipv4),
    (11, "DEVSEC", RE_API_KEYS, _api_match_ok),
]


def _pro_threat_rows(config: dict) -> list[ThreatRow]:
    rows: list[ThreatRow] = []
    devsec_on = config.get("devsec_mode", True)
    fintech_on = config.get("fintech_shield", True)

    if devsec_on:
        rows.extend(
            [
                (10, "DEVSEC", RE_IPV4, _valid_ipv4),
                (11, "DEVSEC", RE_MAC, lambda _m: True),
                (12, "DEVSEC", RE_API_KEYS, _api_match_ok),
            ]
        )
    if fintech_on:
        rows.extend(
            [
                (20, "CREDIT_CARD", RE_CREDIT_CARD, _valid_credit_card),
                (21, "US_SSN", RE_US_SSN, lambda _m: True),
                (22, "EU_IBAN", RE_EU_IBAN, lambda _m: True),
                (23, "UK_NINO", RE_UK_NINO, lambda _m: True),
                (24, "NG_BANK", RE_NG_BANK, lambda _m: True),
                (25, "NG_PHONE", RE_NG_PHONE, lambda _m: True),
                (26, "NG_NIN", RE_NG_NIN, lambda _m: True),
            ]
        )
    return rows


def _nda_rows(config: dict) -> list[ThreatRow]:
    words: list[str] = []
    for word in config.get("custom_keywords", []):
        w = str(word).strip()
        if len(w) < 2:
            continue
        words.append(w)
    words.sort(key=lambda s: -len(s))
    out: list[ThreatRow] = []
    for w in words:
        pat = re.compile(rf"\b{re.escape(w)}\b", re.IGNORECASE)
        out.append((-1, "NDA", pat, lambda _m: True))
    return out


def verify_gumroad_license(license_key: str, timeout: float = 30.0) -> bool:
    """POST to Gumroad licenses/verify; returns True if response JSON has success: true."""
    key = license_key.strip()
    if not key:
        return False
    data = urllib.parse.urlencode(
        {
            "product_permalink": GUMROAD_PRODUCT_PERMALINK,
            "license_key": key,
            "increment_uses_count": "true",
        }
    ).encode("utf-8")
    req = urllib.request.Request(
        GUMROAD_VERIFY_URL,
        data=data,
        method="POST",
        headers={"Content-Type": "application/x-www-form-urlencoded"},
    )
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            body = json.loads(resp.read().decode("utf-8", errors="replace"))
    except (urllib.error.URLError, json.JSONDecodeError, OSError):
        return False
    return body.get("success") is True


def load_config() -> dict:
    if not CONFIG_PATH.is_file():
        CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
        flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
        fd = os.open(os.fspath(CONFIG_PATH), flags, 0o600)
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_CONFIG, f, indent=2)
            f.write("\n")
        return dict(DEFAULT_CONFIG)
    try:
        with CONFIG_PATH.open(encoding="utf-8") as f:
            user_config = json.load(f)
        merged = {**DEFAULT_CONFIG, **user_config}
        # Migrate legacy hipaa_mode -> fintech_shield
        if "hipaa_mode" in user_config and "fintech_shield" not in user_config:
            merged["fintech_shield"] = user_config.get("hipaa_mode", True)
        return merged
    except Exception:
        return dict(DEFAULT_CONFIG)


def save_config(cfg: dict) -> None:
    CONFIG_PATH.parent.mkdir(parents=True, exist_ok=True)
    tmp = CONFIG_PATH.with_suffix(CONFIG_PATH.suffix + ".tmp")
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
    fd = os.open(os.fspath(tmp), flags, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(cfg, f, indent=2, sort_keys=True)
        f.write("\n")
    tmp.replace(CONFIG_PATH)


def build_active_threats(config: dict, *, pro: bool) -> list[ThreatRow]:
    if not pro:
        return list(FREE_THREATS)
    rows: list[ThreatRow] = []
    rows.extend(_nda_rows(config))
    rows.extend(_pro_threat_rows(config))
    return rows


def load_vault(path: Path) -> dict[str, str]:
    redis_url = os.environ.get(REDIS_ENV_VAR)
    if redis_url:
        if not HAS_REDIS:
            print(
                f"safepaste: error: '{REDIS_ENV_VAR}' is set but 'redis' module is missing. "
                "Run 'pip install redis'",
                file=sys.stderr,
            )
            sys.exit(1)
        r = redis.from_url(redis_url, decode_responses=True)
        return dict(r.hgetall(REDIS_HASH_KEY))

    if not path.is_file():
        return {}
    try:
        with path.open(encoding="utf-8") as f:
            data = json.load(f)
    except (json.JSONDecodeError, OSError):
        return {}

    out: dict[str, str] = {}
    if isinstance(data, dict):
        for k, v in data.items():
            if isinstance(k, str) and isinstance(v, str) and _parse_vault_key(k):
                out[k] = v
    return out


def save_vault(path: Path, vault: dict[str, str]) -> None:
    redis_url = os.environ.get(REDIS_ENV_VAR)
    if redis_url:
        r = redis.from_url(redis_url, decode_responses=True)
        if vault:
            r.hset(REDIS_HASH_KEY, mapping=vault)
        return

    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_suffix(path.suffix + ".tmp")
    flags = os.O_WRONLY | os.O_CREAT | os.O_TRUNC
    fd = os.open(os.fspath(tmp), flags, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        json.dump(vault, f, indent=2, sort_keys=True)
        f.write("\n")
    tmp.replace(path)


def _max_ids_per_label(vault: dict[str, str]) -> dict[str, int]:
    max_ids: dict[str, int] = {}
    for key in vault:
        parsed = _parse_vault_key(key)
        if parsed:
            label, num = parsed
            max_ids[label] = max(max_ids.get(label, 0), num)
    return max_ids


def _value_to_placeholder(vault: dict[str, str]) -> dict[tuple[str, str], str]:
    """Map (label, value) → vault key `LABEL_n` (same value under different labels stays distinct)."""
    rev: dict[tuple[str, str], str] = {}
    for ph, val in vault.items():
        parsed = _parse_vault_key(ph)
        if not parsed:
            continue
        label, _num = parsed
        rev[(label, val)] = ph
    return rev


def collect_threat_spans(text: str, active_threats: list[ThreatRow]) -> list[tuple[int, int, str, str]]:
    raw: list[tuple[int, int, int, str, str]] = []
    for priority, label, pat, validator in active_threats:
        val_fn = validator
        for m in pat.finditer(text):
            g = m.group(0)
            if callable(val_fn) and not val_fn(g):
                continue
            raw.append((m.start(), m.end(), priority, label, g))

    raw.sort(key=lambda t: (t[0], t[2], -(t[1] - t[0])))

    spans: list[tuple[int, int, str, str]] = []
    last_end = -1
    for start, end, _prio, label, val in raw:
        if start < last_end:
            continue
        spans.append((start, end, label, val))
        last_end = end
    return spans


def mask_text(
    text: str,
    vault: dict[str, str],
    active_threats: list[ThreatRow],
    *,
    persist_vault: bool,
) -> str:
    """If persist_vault is False (Free tier), emit [LABEL_n] without persisting the vault file."""
    value_to_ph = _value_to_placeholder(vault) if persist_vault else {}
    max_ids = _max_ids_per_label(vault) if persist_vault else {}
    ephemeral_max: dict[str, int] = {}
    ephemeral_rev: dict[tuple[str, str], str] = {}

    spans = collect_threat_spans(text, active_threats)
    spans.sort(key=lambda s: s[0])

    parts: list[str] = []
    pos = 0
    for start, end, label, val in spans:
        parts.append(text[pos:start])
        if persist_vault:
            lk = (label, val)
            ph_key = value_to_ph.get(lk)
            if ph_key is None:
                max_ids[label] = max_ids.get(label, 0) + 1
                ph_key = f"{label}_{max_ids[label]}"
                vault[ph_key] = val
                value_to_ph[lk] = ph_key
            parts.append(f"[{ph_key}]")
        else:
            lk = (label, val)
            ph_key = ephemeral_rev.get(lk)
            if ph_key is None:
                ephemeral_max[label] = ephemeral_max.get(label, 0) + 1
                n = ephemeral_max[label]
                ph_key = f"{label}_{n}"
                ephemeral_rev[lk] = ph_key
            parts.append(f"[{ph_key}]")
        pos = end
    parts.append(text[pos:])
    return "".join(parts)


def unmask_text(text: str, vault: dict[str, str]) -> str:
    def repl(m: re.Match[str]) -> str:
        key = f"{m.group(1)}_{m.group(2)}"
        return vault.get(key, m.group(0))

    return _PLACEHOLDER_RE.sub(repl, text)


def read_input(path: str | None) -> str:
    if path is None or path == "-":
        return sys.stdin.read()
    p = Path(path)
    with p.open(encoding="utf-8", errors="replace") as f:
        return f.read()


def parse_args(argv: list[str] | None) -> argparse.Namespace:
    p = argparse.ArgumentParser(
        description="SafePaste Enterprise CLI — same patterns as the browser extension. "
        "Free: IP + API redaction only, no vault. Pro: Gumroad license + full vault.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
examples:
  safepaste --mask < /var/log/syslog
  docker logs my-app | safepaste --mask > clean.log
  cat ai_response.txt | safepaste --unmask
  safepaste --unlock "XXXX-XXXX-XXXX-XXXX"
  safepaste --status
  safepaste --toggle-devsec
  safepaste --add-nda "ProjectNova"
  safepaste --list-nda
        """,
    )

    # ── I/O modes ─────────────────────────────────────────────
    mode = p.add_mutually_exclusive_group()
    mode.add_argument("--mask",   action="store_true", help="Redact sensitive values → placeholders.")
    mode.add_argument("--unmask", action="store_true", help="Restore placeholders using vault (Pro).")

    # ── License ───────────────────────────────────────────────
    p.add_argument(
        "--unlock",
        metavar="LICENSE_KEY",
        default=None,
        help="Verify Gumroad license key and enable Pro.",
    )

    # ── Status ────────────────────────────────────────────────
    p.add_argument(
        "--status",
        action="store_true",
        help="Show current license tier, active toggles, and NDA keywords.",
    )

    # ── Toggles (mirror the popup switches) ───────────────────
    p.add_argument(
        "--toggle-devsec",
        action="store_true",
        dest="toggle_devsec",
        help="Enable/disable DevSec mode (IPs, MACs, API keys).",
    )
    p.add_argument(
        "--toggle-fintech",
        action="store_true",
        dest="toggle_fintech",
        help="Enable/disable FinTech Shield (Cards, SSNs, IBANs, NINs).",
    )

    # ── NDA keywords (mirror the popup NDA section) ───────────
    p.add_argument(
        "--add-nda",
        metavar="WORD",
        dest="add_nda",
        default=None,
        help="Add a custom NDA keyword to be redacted (Pro).",
    )
    p.add_argument(
        "--remove-nda",
        metavar="WORD",
        dest="remove_nda",
        default=None,
        help="Remove a custom NDA keyword.",
    )
    p.add_argument(
        "--list-nda",
        action="store_true",
        dest="list_nda",
        help="List all active NDA keywords.",
    )
    p.add_argument(
        "--clear-nda",
        action="store_true",
        dest="clear_nda",
        help="Remove all NDA keywords.",
    )

    # ── Tier overrides ────────────────────────────────────────
    p.add_argument("--free", action="store_true", help="Force Free-tier for this run.")
    p.add_argument("--pro",  action="store_true", help="Force Pro-tier for this run (no Gumroad call).")

    p.add_argument("file", nargs="?", default=None, help="Input file (omit to read from stdin).")
    return p.parse_args(argv)


def main(argv: list[str] | None = None) -> int:
    args = parse_args(argv)

    # ── --unlock ──────────────────────────────────────────────
    if args.unlock is not None:
        key = args.unlock.strip() or os.environ.get("SAFEPASTE_LICENSE_KEY", "").strip()
        if not key:
            print("safepaste: pass LICENSE_KEY or set SAFEPASTE_LICENSE_KEY", file=sys.stderr)
            return 1
        ok = verify_gumroad_license(key)
        cfg = load_config()
        cfg["is_licensed"] = ok
        cfg["gumroad_license_key"] = key if ok else ""
        save_config(cfg)
        if ok:
            print("safepaste: ✓ Pro unlocked. License verified.", file=sys.stderr)
        else:
            print("safepaste: ✗ License verification failed. Check your key.", file=sys.stderr)
            return 1
        return 0

    # ── --status ──────────────────────────────────────────────
    if args.status:
        cfg = load_config()
        licensed  = cfg.get("is_licensed", False)
        devsec    = cfg.get("devsec_mode", True)
        fintech   = cfg.get("fintech_shield", True)
        keywords  = cfg.get("custom_keywords", [])

        tier = "Pro ✓" if licensed else "Free (IPs + API keys only)"
        on   = "ON "
        off  = "OFF"

        print(f"""
SafePaste Enterprise — Status
──────────────────────────────
  License tier    : {tier}
  Config location : {CONFIG_PATH}
  Vault location  : {VAULT_PATH}

  DevSec Mode     : {on if devsec  else off}  (IPs, MACs, API keys)
  FinTech Shield  : {on if fintech else off}  (Cards, SSNs, IBANs, NINs)

  NDA Keywords    : {len(keywords)} active
""".strip())

        if keywords:
            for w in keywords:
                print(f"    • {w}")
        else:
            print("    (none — add with: safepaste --add-nda \"word\")")
        print()
        return 0

    # ── --toggle-devsec ───────────────────────────────────────
    if args.toggle_devsec:
        cfg = load_config()
        new_val = not cfg.get("devsec_mode", True)
        cfg["devsec_mode"] = new_val
        save_config(cfg)
        state = "ON" if new_val else "OFF"
        print(f"safepaste: DevSec Mode → {state}  (IPs, MACs, API keys)")
        return 0

    # ── --toggle-fintech ──────────────────────────────────────
    if args.toggle_fintech:
        cfg = load_config()
        new_val = not cfg.get("fintech_shield", True)
        cfg["fintech_shield"] = new_val
        save_config(cfg)
        state = "ON" if new_val else "OFF"
        print(f"safepaste: FinTech Shield → {state}  (Cards, SSNs, IBANs, NINs)")
        return 0

    # ── --add-nda ─────────────────────────────────────────────
    if args.add_nda is not None:
        word = args.add_nda.strip()
        if len(word) < 2:
            print("safepaste: keyword must be at least 2 characters", file=sys.stderr)
            return 1
        if len(word) > 60:
            print("safepaste: keyword too long (max 60 characters)", file=sys.stderr)
            return 1
        cfg = load_config()
        if not cfg.get("is_licensed"):
            print("safepaste: NDA keywords require Pro. Run: safepaste --unlock \"KEY\"", file=sys.stderr)
            return 1
        keywords = cfg.get("custom_keywords", [])
        if any(w.lower() == word.lower() for w in keywords):
            print(f"safepaste: \"{word}\" is already in the NDA list")
            return 0
        keywords.append(word)
        cfg["custom_keywords"] = keywords
        save_config(cfg)
        print(f"safepaste: ✓ Added \"{word}\" ({len(keywords)} total NDA keywords)")
        return 0

    # ── --remove-nda ──────────────────────────────────────────
    if args.remove_nda is not None:
        word = args.remove_nda.strip()
        cfg = load_config()
        keywords = cfg.get("custom_keywords", [])
        before = len(keywords)
        keywords = [w for w in keywords if w.lower() != word.lower()]
        if len(keywords) == before:
            print(f"safepaste: \"{word}\" not found in NDA list")
            return 1
        cfg["custom_keywords"] = keywords
        save_config(cfg)
        print(f"safepaste: ✓ Removed \"{word}\" ({len(keywords)} remaining)")
        return 0

    # ── --list-nda ────────────────────────────────────────────
    if args.list_nda:
        cfg = load_config()
        keywords = cfg.get("custom_keywords", [])
        if not keywords:
            print("safepaste: no NDA keywords set. Add one: safepaste --add-nda \"word\"")
        else:
            print(f"safepaste: {len(keywords)} NDA keyword(s):")
            for w in keywords:
                print(f"  • {w}")
        return 0

    # ── --clear-nda ───────────────────────────────────────────
    if args.clear_nda:
        cfg = load_config()
        count = len(cfg.get("custom_keywords", []))
        cfg["custom_keywords"] = []
        save_config(cfg)
        print(f"safepaste: ✓ Cleared {count} NDA keyword(s)")
        return 0

    # ── --mask / --unmask ─────────────────────────────────────
    if not args.mask and not args.unmask:
        print("safepaste: specify a command. Run: safepaste --help", file=sys.stderr)
        return 1

    try:
        data = read_input(args.file)
    except OSError as e:
        print(f"safepaste: {e}", file=sys.stderr)
        return 1

    vault = load_vault(VAULT_PATH)

    if args.unmask:
        sys.stdout.write(unmask_text(data, vault))
        return 0

    config = load_config()
    env_key = os.environ.get("SAFEPASTE_LICENSE_KEY", "").strip()
    if env_key and not config.get("is_licensed"):
        if verify_gumroad_license(env_key):
            config["is_licensed"] = True
            config["gumroad_license_key"] = env_key
            save_config(config)

    pro = bool(config.get("is_licensed"))
    if args.free:
        pro = False
    if args.pro:
        pro = True

    active = build_active_threats(config, pro=pro)
    persist = pro

    out = mask_text(data, vault, active, persist_vault=persist)
    if persist:
        try:
            save_vault(VAULT_PATH, vault)
        except OSError as e:
            print(f"safepaste: cannot write vault: {e}", file=sys.stderr)
            return 1
    sys.stdout.write(out)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
