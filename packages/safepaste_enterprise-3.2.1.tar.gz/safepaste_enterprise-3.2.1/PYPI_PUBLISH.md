# SafePaste — PyPI Publishing Guide

## One-time setup

### 1. Create PyPI account
Go to https://pypi.org/account/register/
Use: support@logicgrid.ai
Username: logicgridai

### 2. Create API token
Go to https://pypi.org/manage/account/token/
Name: safepaste-publish
Scope: Entire account (first time), then restrict to safepaste project
Copy the token — starts with pypi-

### 3. Install twine on your machine
```bash
pip install twine
```

---

## Publish to PyPI

```bash
# Upload both the wheel and source dist
twine upload dist/*

# Enter when prompted:
# Username: __token__
# Password: pypi-YOUR-TOKEN-HERE
```

Or create ~/.pypirc to avoid typing credentials each time:
```
[pypi]
username = __token__
password = pypi-YOUR-TOKEN-HERE
```

Then just run:
```bash
twine upload dist/*
```

---

## After publishing

Your package will be live at:
https://pypi.org/project/safepaste/

Users install with:
```bash
pip install safepaste
```

---

## Publishing a new version

1. Update version in pyproject.toml and safepaste/__main__.py
2. Rebuild: python3 -m build
3. Upload: twine upload dist/*

---

## Test on TestPyPI first (recommended)

```bash
twine upload --repository testpypi dist/*
pip install --index-url https://test.pypi.org/simple/ safepaste
```

Make sure it installs and runs correctly before pushing to real PyPI.
