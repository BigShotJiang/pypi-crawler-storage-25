# SafePaste Enterprise CLI

**Zero-trust DLP for Linux pipelines.** Redacts sensitive data before it reaches AI tools, log aggregators, or external services.

```bash
pip install safepaste
```

---

## What it does

SafePaste intercepts sensitive data in your Linux pipelines and replaces it with cryptographic placeholders. Pro tier supports reversible vaulting — mask before sending to AI, unmask after getting the response back.

```bash
# Free tier — mask IPs and API keys
cat /var/log/app.log | safepaste --mask

# Pro tier — full vault with unmask support
docker logs my-app | safepaste --mask > clean.log
cat ai_response.txt | safepaste --unmask
```

---

## What gets redacted

| Pattern | Free | Pro |
|---|---|---|
| IPv4 addresses | ✓ | ✓ |
| API keys (OpenAI, Anthropic, AWS, GitHub, Slack) | ✓ | ✓ |
| MAC addresses | — | ✓ |
| Credit cards (Luhn-validated) | — | ✓ |
| US Social Security Numbers | — | ✓ |
| EU IBANs | — | ✓ |
| UK National Insurance Numbers (NINO) | — | ✓ |
| Nigerian bank account numbers (10-digit) | — | ✓ |
| Nigerian phone numbers | — | ✓ |
| Nigerian NIN (11-digit) | — | ✓ |
| Custom NDA keywords | — | ✓ |

---

## Installation

```bash
pip install safepaste

# With Redis support (enterprise distributed vault)
pip install safepaste[redis]
```

Requires Python 3.9+. No external dependencies for the base install.

---

## CLI Reference

```bash
safepaste --mask                    # Redact sensitive values → placeholders
safepaste --unmask                  # Restore placeholders using vault (Pro)
safepaste --unlock "LICENSE-KEY"    # Activate Pro with Gumroad license key
safepaste --status                  # Show tier, toggles, NDA keywords
safepaste --toggle-devsec           # Enable/disable DevSec mode
safepaste --toggle-fintech          # Enable/disable FinTech Shield
safepaste --add-nda "ProjectNova"   # Add NDA keyword (Pro)
safepaste --remove-nda "ProjectNova"# Remove NDA keyword
safepaste --list-nda                # List all NDA keywords
safepaste --clear-nda               # Remove all NDA keywords
safepaste --free                    # Force Free-tier for this run
safepaste --pro                     # Force Pro-tier for this run
```

---

## Examples

```bash
# Mask a log file
cat /var/log/syslog | safepaste --mask

# Mask docker logs and save
docker logs my-app | safepaste --mask > clean-docker.log

# CI/CD pipeline with env var license
export SAFEPASTE_LICENSE_KEY="XXXX-XXXX-XXXX-XXXX"
cat database_export.csv | safepaste --mask

# Mask → send to AI → unmask response
safepaste --mask report.txt > masked.txt
# ... send masked.txt to AI, save response ...
safepaste --unmask ai_response.txt
```

---

## Enterprise: Redis distributed vault

For multi-pod Kubernetes clusters where multiple instances need shared vault state:

```bash
pip install safepaste[redis]
export SAFEPASTE_REDIS_URL="redis://:password@redis-host:6379/0"
cat logs.txt | safepaste --mask
```

---

## Licensing

- **Free tier** — IP addresses and API keys, permanently. No account required.
- **Pro tier** — Full vault, FinTech Shield, Custom NDAs. License via [Gumroad](https://logicgridai.gumroad.com/l/safepaste).

```bash
safepaste --unlock "YOUR-GUMROAD-LICENSE-KEY"
```

Config stored at `~/.safepaste/config.json`. Vault at `~/.safepaste/vault.json`.

---

## Also available as

- **Chrome Extension** — [SafePaste Enterprise on Chrome Web Store](https://safepaste.app)
- **Docker image** — `docker pull logicgridai/safepaste`
- **Firefox Add-on** — coming soon

---

## Links

- Website: [safepaste.app](https://safepaste.app)
- Privacy Policy: [safepaste.app/privacy](https://safepaste.app/privacy)
- Support: [support@logicgrid.ai](mailto:support@logicgrid.ai)
- Publisher: [LogicGrid AI, LLC](https://logicgrid.ai)
