# plugins/titan-plugin-github/titan_plugin_github/agents/code_review_agent.py
"""
CodeReviewAgent - AI agent for reviewing pull requests.

Analyzes PR diffs and project skills to generate structured review comments.
"""

import json
from typing import List

from titan_cli.core.logging import get_logger
from titan_cli.ai.agents.base import BaseAIAgent, AgentRequest
from ..models.review_enums import FindingSeverity
from ..models.view import UIReviewSuggestion

logger = get_logger(__name__)


def _normalize_suggestion_severity(raw_severity: str) -> FindingSeverity:
    """Normalize legacy and current AI severity labels into FindingSeverity."""
    mapping = {
        "blocking": FindingSeverity.BLOCKING,
        "critical": FindingSeverity.BLOCKING,
        "important": FindingSeverity.IMPORTANT,
        "improvement": FindingSeverity.IMPORTANT,
        "nit": FindingSeverity.NIT,
        "suggestion": FindingSeverity.NIT,
    }
    return mapping.get(raw_severity.lower(), FindingSeverity.NIT)

_SYSTEM_PROMPT = """You are an expert code reviewer. Your task is to review pull request diffs
and identify problems, bugs, and improvements.

When reviewing code, focus ONLY on:
- Correctness: bugs, logic errors, edge cases
- Security: vulnerabilities, unsafe patterns
- Performance: inefficiencies, unnecessary complexity
- Maintainability: readability, naming, structure
- Project conventions: follow any project-specific skills/guidelines provided

IMPORTANT rules:
- ONLY comment when you have something to improve or fix. Never praise, compliment, or validate changes.
- Do NOT say things like "Good cleanup", "Excellent improvement", "Nice refactor", etc.
- If a change looks correct and has no issues, skip it entirely — return nothing for that file/line.
- Every comment must propose a concrete change or flag a real problem.
- If the code looks good overall, return an empty array [].

If "Existing Open Review Comments" are provided:
- Check each thread before suggesting changes — do NOT duplicate an issue already in the conversation.
- If the author/reviewer has already responded (even with a short note), and the issue seems addressed, do NOT suggest it again.
  - Example: If someone says "This variable exists as an org secret", don't suggest validating it.
  - Example: If someone says "Already fixed in commit X", don't repeat the same issue.
- Only reply to a thread (using `reply_to_comment_id`) if needed to continue the conversation:
  - If author says it's fixed and they're RIGHT → skip, don't reply
  - If author disagrees and they're RIGHT → skip, don't reply
  - If author is WRONG or hasn't addressed it yet → reply with clarification, evidence, or escalation
- Never suggest a reply just to repeat the original comment. Replies must add new context or refute the author's reasoning.

Output your review as a JSON array of comment objects. Each comment must have:
- "file": the file path (string). Use empty string "" when replying to a thread.
- "snippet": the exact line of code where the problem is (copy-paste the line verbatim from the diff, without the leading + or - character). Use null for general file-level comments or replies.
- "body": the review comment text (string, be concise and actionable)
- "severity": one of "blocking", "important", or "nit"
- "reply_to_comment_id": (optional) the integer comment ID from `[comment_id:N]` if this is a follow-up reply to an existing thread. Omit or use null for new comments.

Severity guide:
- "blocking": bugs, security issues, broken logic that must be fixed
- "important": code quality issues that should be addressed
- "nit": minor style, naming, or optional improvements

Respond with ONLY the JSON array, no other text.
"""


class CodeReviewAgent(BaseAIAgent):
    """
    AI agent for reviewing pull requests using project skills as context.

    Generates structured UIReviewSuggestion objects from PR diffs.
    """

    def get_system_prompt(self) -> str:
        """System prompt for code review expertise."""
        return _SYSTEM_PROMPT

    def review(self, context: str) -> List[UIReviewSuggestion]:
        """
        Generate review comments for a PR.

        Args:
            context: Formatted string with PR info, diff, and project skills

        Returns:
            List of UIReviewSuggestion objects
        """
        request = AgentRequest(
            context=context,
            max_tokens=4000,
            temperature=0.3,
            operation="code_review",
        )

        try:
            response = self.generate(request)
        except Exception as e:
            logger.error(f"AI code review failed: {e}")
            return []

        return self._parse_suggestions(response.content)

    def _parse_suggestions(self, content: str) -> List[UIReviewSuggestion]:
        """
        Parse AI JSON response into UIReviewSuggestion objects.

        Args:
            content: Raw AI response string

        Returns:
            List of UIReviewSuggestion objects (empty list on parse failure)
        """
        # Strip markdown code fences if present
        text = content.strip()
        if text.startswith("```"):
            lines = text.split("\n")
            text = "\n".join(lines[1:-1]) if len(lines) > 2 else text

        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            logger.warning(f"Failed to parse AI review response as JSON: {content[:200]}")
            return []

        if not isinstance(data, list):
            logger.warning(f"AI review response is not a list: {type(data)}")
            return []

        suggestions = []

        for item in data:
            if not isinstance(item, dict):
                continue

            file_path = item.get("file", "")
            if not file_path:
                continue

            severity = _normalize_suggestion_severity(str(item.get("severity", "nit")))

            snippet_raw = item.get("snippet")
            snippet = snippet_raw.strip() if isinstance(snippet_raw, str) and snippet_raw else None

            body = item.get("body", "").strip()
            if not body:
                continue

            reply_to_raw = item.get("reply_to_comment_id")
            reply_to_comment_id = int(reply_to_raw) if isinstance(reply_to_raw, (int, float)) and reply_to_raw else None

            suggestions.append(UIReviewSuggestion(
                file_path=file_path,
                line=None,   # Will be resolved deterministically from snippet
                body=body,
                severity=severity,
                snippet=snippet,
                reply_to_comment_id=reply_to_comment_id,
            ))

        return suggestions
