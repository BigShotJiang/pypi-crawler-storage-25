"""TMUX terminal backend for mycel_cli.group.

Group-container model: one group = one tmux session named
``cel-{group_id[:8]}``. Container ref = session name.

Layout inside the session (window 0 is the role window):

  * ``primary`` = the default pane after ``new-session -d``.
  * ``right``   = ``tmux split-window -h -t <s>:0.0``.
  * ``down``    = ``tmux split-window -v -t <s>:0.0``.
  * ``next``    = a new window in the same session.

target_id format: ``<session>:<window>.<pane_id>`` (e.g.
``cel-abcd1234:0.%3``).
"""

from __future__ import annotations
import shlex
import subprocess
import time

from mycel_cli.group.terminal import TerminalPlacement


def _container_name(group_id: str) -> str:
    """tmux session names shouldn't be too long; 8 chars of the group id
    is unique enough and keeps the status-line short."""
    return f"cel-{group_id[:8]}"


def _session_exists(session: str) -> bool:
    r = subprocess.run(
        ["tmux", "has-session", "-t", session],
        capture_output=True,
    )
    return r.returncode == 0


def _display(session: str, target: str, fmt: str) -> str:
    return subprocess.check_output(
        ["tmux", "display-message", "-p", "-t", target, fmt],
        text=True,
    ).strip()


class TmuxTerminal:
    def ensure_group_container(self, group_id: str) -> str:
        """Create (or return) the tmux session for this group. Returns its name."""
        session = _container_name(group_id)
        if _session_exists(session):
            return session
        subprocess.run(
            ["tmux", "new-session", "-d", "-s", session, "-x", "220", "-y", "50"],
            check=True,
            capture_output=True,
        )
        # Rename window 0 to "supervisor" so the layout is legible.
        subprocess.run(
            ["tmux", "rename-window", "-t", f"{session}:0", "supervisor"],
            capture_output=True,
        )
        # @@@tmux-fresh-shell-race - detached tmux panes can drop the first
        # send-keys payload if we type before the login shell is ready.
        time.sleep(0.2)
        return session

    def spawn_in_container(
        self,
        container_ref: str,
        placement: TerminalPlacement,
        cwd: str,
        cmd: str,
    ) -> str:
        """Place a new user surface in the tmux session and run ``cmd``.

        Returns the target_id (``<session>:<window>.<pane_id>``).
        """
        session = container_ref
        if not _session_exists(session):
            raise RuntimeError(f"tmux group session not found: {session!r}")

        pane_target = _resolve_pane_target(session, placement, cwd)
        # Resolve the fully-qualified pane id (%N) so subsequent send-text
        # calls are stable even as window layouts change.
        pane_id = _display(session, pane_target, "#{pane_id}")
        window_index = _display(session, pane_target, "#{window_index}")
        target_id = f"{session}:{window_index}.{pane_id}"

        subprocess.run(
            [
                "tmux",
                "send-keys",
                "-l",
                "-t",
                target_id,
                f"cd {shlex.quote(cwd)} && {cmd}",
            ],
            check=True,
            capture_output=True,
        )
        subprocess.run(
            ["tmux", "send-keys", "-t", target_id, "Enter"],
            check=True,
            capture_output=True,
        )
        return target_id

    def close_group_container(self, container_ref: str) -> None:
        """Kill the group session (and every pane/window in it)."""
        subprocess.run(
            ["tmux", "kill-session", "-t", container_ref],
            capture_output=True,
        )

    def send_text(self, target_id: str, text: str) -> None:
        """Send body then Enter to tmux pane as two separate calls.

        CRITICAL: do NOT collapse into one `send-keys text Enter`, and
        do NOT shorten the sleep. See cel/terminals/iterm2.py
        send_text() for the full root-cause writeup. Summary:

          Claude Code's TUI enables bracketed paste mode. When a terminal
          wraps a payload in "\\e[200~ ... \\e[201~" (paste mode), any
          Enter/CR inside that envelope is treated as a multi-line
          newline, NOT submit — the message stays stuck in the input
          buffer.

          tmux's `send-keys text Enter` today sends Enter as a raw
          keystroke outside any paste envelope, but tmux 3.x has started
          auto-bracketing certain paste-sized writes. Aligning all
          backends on "text → ~2s sleep → Enter" eliminates the
          bracketed-paste regression class and matches cmux/iterm2.
        """
        subprocess.run(
            ["tmux", "send-keys", "-t", target_id, text],
            check=True,
            capture_output=True,
        )
        time.sleep(2)
        subprocess.run(
            ["tmux", "send-keys", "-t", target_id, "Enter"],
            check=True,
            capture_output=True,
        )

    def send_key(self, target_id: str, key: str) -> None:
        """Send a named key to tmux pane."""
        key_map = {"escape": "Escape", "enter": "Enter", "ctrl-c": "C-c"}
        tmux_key = key_map.get(key, key)
        subprocess.run(
            ["tmux", "send-keys", "-t", target_id, tmux_key],
            check=True,
            capture_output=True,
        )

    def read_screen(self, target_id: str) -> str:
        return subprocess.check_output(
            ["tmux", "capture-pane", "-t", target_id, "-p"],
            text=True,
        )

    def close(self, target_id: str) -> None:
        # target_id format: "session:window.%N" — kill the pane; if it's the
        # last pane in the last window the session goes away on its own.
        subprocess.run(
            ["tmux", "kill-pane", "-t", target_id],
            capture_output=True,  # don't raise if already dead
        )

    def resolve_target_id(self, pid: int, *, local_id: str | None = None) -> str | None:
        process_tty = _process_tty(pid)
        if process_tty is None:
            return None
        try:
            panes = subprocess.check_output(
                [
                    "tmux",
                    "list-panes",
                    "-a",
                    "-F",
                    "#{pane_tty}\t#{session_name}:#{window_index}.#{pane_id}",
                ],
                text=True,
            )
        except (OSError, subprocess.CalledProcessError):
            return None
        for line in panes.splitlines():
            pane_tty, sep, target_id = line.partition("\t")
            if sep and _normalize_tty(pane_tty) == process_tty and target_id:
                return target_id
        return None


def _process_tty(pid: int) -> str | None:
    try:
        tty = subprocess.check_output(
            ["ps", "-o", "tty=", "-p", str(pid)],
            text=True,
        ).strip()
    except (OSError, subprocess.CalledProcessError):
        return None
    return _normalize_tty(tty)


def _normalize_tty(tty: str) -> str | None:
    tty = tty.strip()
    if not tty or tty == "??":
        return None
    return tty.removeprefix("/dev/")


def _resolve_pane_target(session: str, placement: TerminalPlacement, cwd: str) -> str:
    """Return a tmux target string for a generic layout placement.

    Creates splits / windows as needed.
    """
    if placement.slot == "primary":
        # Pane 0 of window 0 already exists from ensure_group_container.
        return f"{session}:0.0"

    if placement.slot == "right":
        # Right-split of the primary pane. -P prints the new pane's target.
        out = subprocess.check_output(
            [
                "tmux",
                "split-window",
                "-h",
                "-t",
                f"{session}:0.0",
                "-c",
                cwd,
                "-P",
                "-F",
                "#{pane_id}",
            ],
            text=True,
        ).strip()
        return out

    if placement.slot == "down":
        out = subprocess.check_output(
            [
                "tmux",
                "split-window",
                "-v",
                "-t",
                f"{session}:0.0",
                "-c",
                cwd,
                "-P",
                "-F",
                "#{pane_id}",
            ],
            text=True,
        ).strip()
        return out

    if placement.slot == "next":
        # Brand-new window in the same session for this workflow participant.
        title = placement.title
        out = subprocess.check_output(
            [
                "tmux",
                "new-window",
                "-t",
                session,
                "-n",
                title,
                "-c",
                cwd,
                "-P",
                "-F",
                "#{pane_id}",
            ],
            text=True,
        ).strip()
        return out

    raise ValueError(f"tmux: unsupported terminal placement: {placement!r}")
