"""macOS Terminal.app backend for mycel_cli.group.

Requires macOS Automation and Accessibility permission:
    System Settings → Privacy & Security → Automation / Accessibility
    (grant permission to the terminal or shell running cel)

Uses CGEventPostToPid for background text injection without focus steal.
Requires pyobjc-framework-Quartz.

Group-container model
-----------------------
Terminal.app has no split-pane API. A group = one Terminal.app **window**
identified by its numeric id. ``TerminalPlacement.primary`` reuses the first
tab; every other placement creates a new tab with the placement title.

target_id for tabs is ``<window_id>:<tab_title>``. Every send/read/close first
selects the tab with that title inside the window, so later user focus changes
do not silently retarget a group message to the wrong role.
"""

from __future__ import annotations
import base64
import subprocess
import time
import shlex

from mycel_cli.group.terminal import TerminalPlacement

_OSASCRIPT_TIMEOUT_SECONDS = 10


def _ensure_quartz():
    """Lazy import Quartz with an explicit install hint."""
    try:
        import Quartz

        return Quartz
    except ImportError as exc:
        raise RuntimeError(
            "pyobjc-framework-Quartz package not installed. "
            "Run: uv add pyobjc-framework-Quartz"
        ) from exc


def _terminal_pid() -> int:
    result = subprocess.check_output(
        ["pgrep", "-x", "Terminal"],
        text=True,
        timeout=_OSASCRIPT_TIMEOUT_SECONDS,
    )
    return int(result.strip().split("\n")[0])


def _inject_text(pid: int, target_id: str, text: str) -> None:
    """Inject text into a specific Terminal.app window via CGEventPostToPid."""
    Quartz = _ensure_quartz()
    window_id, tab_title = _parse_target_id(target_id)
    # Bring target window to front within Terminal.app (no app focus steal)
    script = _select_tab_script(window_id, tab_title)
    subprocess.run(
        ["osascript", "-e", script],
        capture_output=True,
        timeout=_OSASCRIPT_TIMEOUT_SECONDS,
    )
    time.sleep(0.2)
    for char in text:
        kd = Quartz.CGEventCreateKeyboardEvent(None, 0, True)
        ku = Quartz.CGEventCreateKeyboardEvent(None, 0, False)
        Quartz.CGEventKeyboardSetUnicodeString(kd, len(char), char)
        Quartz.CGEventKeyboardSetUnicodeString(ku, len(char), char)
        Quartz.CGEventPostToPid(pid, kd)
        Quartz.CGEventPostToPid(pid, ku)
        time.sleep(0.015)


def _send_return(pid: int) -> None:
    """Send Return key (key code 36) via CGEvent."""
    Quartz = _ensure_quartz()
    kd = Quartz.CGEventCreateKeyboardEvent(None, 36, True)
    ku = Quartz.CGEventCreateKeyboardEvent(None, 36, False)
    Quartz.CGEventPostToPid(pid, kd)
    Quartz.CGEventPostToPid(pid, ku)


def _osascript(script: str) -> str:
    try:
        return subprocess.check_output(
            ["osascript", "-e", script],
            text=True,
            timeout=_OSASCRIPT_TIMEOUT_SECONDS,
        ).strip()
    except subprocess.TimeoutExpired as exc:
        raise RuntimeError(
            "Terminal.app AppleScript timed out; check macOS Automation permission "
            "for the controlling process and confirm a logged-in GUI session is active."
        ) from exc


def _apple_script_escape(text: str) -> str:
    return (
        text.replace("\\", "\\\\")
        .replace('"', '\\"')
        .replace("\r", "\\r")
        .replace("\n", "\\n")
    )


def _terminal_launch_cmd(cwd: str, cmd: str) -> str:
    full_cmd = f"cd {shlex.quote(cwd)} && {cmd}"
    encoded = base64.b64encode(full_cmd.encode("utf-8")).decode("ascii")
    # Avoid embedding raw shell payload in AppleScript source; the script only
    # contains base64-safe text and decodes it in the shell.
    return f"printf %s {shlex.quote(encoded)} | base64 -D | bash"


def _find_window_by_title(title: str) -> str | None:
    """Return the window id (as string) whose custom title matches, or None."""
    escaped_title = _apple_script_escape(title)
    script = f'''
tell application "Terminal"
    set out to ""
    repeat with w in windows
        try
            if (custom title of w) is "{escaped_title}" then
                set out to (id of w as string)
                exit repeat
            end if
        end try
    end repeat
    return out
end tell
'''
    out = _osascript(script).strip()
    return out or None


def _window_id_expr(window_id: str) -> str:
    if not str(window_id).isdigit():
        raise ValueError(f"Terminal.app window id must be numeric, got {window_id!r}")
    return str(window_id)


def _target_id(window_id: str, tab_title: str) -> str:
    return f"{_window_id_expr(window_id)}:{tab_title}"


def _parse_target_id(target_id: str) -> tuple[str, str]:
    window_id, sep, tab_title = str(target_id).partition(":")
    if not sep or not tab_title:
        raise ValueError(
            "Terminal.app target id must be '<window_id>:<tab_title>', "
            f"got {target_id!r}"
        )
    return _window_id_expr(window_id), tab_title


def _select_tab_script(window_id: str, tab_title: str) -> str:
    window_id = _window_id_expr(window_id)
    escaped_title = _apple_script_escape(tab_title)
    return f'''
tell application "Terminal"
    set w to first window whose id is {window_id}
    set frontmost of w to true
    repeat with t in tabs of w
        try
            if (custom title of t) is "{escaped_title}" then
                set selected tab of w to t
                return
            end if
        end try
    end repeat
    error "Terminal.app tab not found: {escaped_title}"
end tell
'''


class TerminalAppTerminal:
    def ensure_group_container(self, group_id: str) -> str:
        """Create (or return) the Terminal.app window for this group.

        The container ref is the numeric window id as a string; we match
        existing windows by the ``cel-{group_id}`` custom title.
        """
        title = f"cel-{group_id}"
        existing = _find_window_by_title(title)
        if existing:
            return existing
        escaped_title = _apple_script_escape(title)

        script = f'''
tell application "Terminal"
    do script ""
    delay 0.3
    set w to front window
    set custom title of w to "{escaped_title}"
    return id of w as string
end tell
'''
        return _osascript(script).strip()

    def spawn_in_container(
        self,
        container_ref: str,
        placement: TerminalPlacement,
        cwd: str,
        cmd: str,
    ) -> str:
        """Open a tab in the group window (or reuse the first one for supervisor)
        and run ``cmd`` inside it. Returns ``window_id:tab_title`` as target_id."""
        launch_cmd = _apple_script_escape(_terminal_launch_cmd(cwd, cmd))
        tab_title = placement.title
        escaped_tab_title = _apple_script_escape(tab_title)
        window_id = _window_id_expr(container_ref)

        if placement.slot == "primary":
            # Reuse the first tab (created by ensure_group_container).
            script = f'''
tell application "Terminal"
    set w to first window whose id is {window_id}
    set t to selected tab of w
    set custom title of t to "{escaped_tab_title}"
    do script "{launch_cmd}" in t
    return id of w as string
end tell
'''
        else:
            # Open a new tab in the same window. AppleScript's "do script"
            # with no `in <tab>` target creates a NEW tab in the frontmost
            # window, so we first make our window frontmost.
            script = f'''
tell application "Terminal"
    set w to first window whose id is {window_id}
    set frontmost of w to true
    delay 0.2
    tell application "System Events" to keystroke "t" using command down
    delay 0.3
    set t to selected tab of w
    set custom title of t to "{escaped_tab_title}"
    do script "{launch_cmd}" in t
    return id of w as string
end tell
'''
        created_window_id = _osascript(script).strip()
        return _target_id(created_window_id, tab_title)

    def close_group_container(self, container_ref: str) -> None:
        """Close the group window (and every tab inside)."""
        window_id = _window_id_expr(container_ref)
        script = f"""
tell application "Terminal"
    try
        close (first window whose id is {window_id}) saving no
    end try
end tell
"""
        subprocess.run(
            ["osascript", "-e", script],
            capture_output=True,
            timeout=_OSASCRIPT_TIMEOUT_SECONDS,
        )

    def send_text(self, target_id: str, text: str) -> None:
        """Send body then Return to Terminal.app without focus steal.

        CRITICAL: do NOT shorten the sleep. See cel/terminals/iterm2.py
        send_text() for the full root-cause writeup. Summary:

          Claude Code's TUI enables bracketed paste mode. Even with
          CGEvent-based per-character injection, back-to-back CGEvents
          can be coalesced by the input system into a single paste
          burst. If that burst ends with Return, Return lands inside
          the bracketed-paste envelope and is treated as a multi-line
          newline, NOT submit — the message stays stuck in the input
          buffer.

          Sleeping ~2s between the last character event and the Return
          keystroke lets the TUI close the paste envelope before Return
          arrives, so Return is interpreted as Enter. Matches
          cmux/kitty/tmux/iterm2.
        """
        pid = _terminal_pid()
        _inject_text(pid, target_id, text)
        time.sleep(2)
        _send_return(pid)

    def send_key(self, target_id: str, key: str) -> None:
        """Send a named key to a Terminal.app tab."""
        Quartz = _ensure_quartz()
        pid = _terminal_pid()
        window_id, tab_title = _parse_target_id(target_id)
        subprocess.run(
            ["osascript", "-e", _select_tab_script(window_id, tab_title)],
            capture_output=True,
            timeout=_OSASCRIPT_TIMEOUT_SECONDS,
        )
        # Key code map for macOS
        key_codes = {"escape": 53, "enter": 36, "ctrl-c": None}
        if key == "ctrl-c":
            # Send Ctrl+C via CGEvent with control modifier
            ev = Quartz.CGEventCreateKeyboardEvent(None, 8, True)  # 'c' key
            Quartz.CGEventSetFlags(ev, Quartz.kCGEventFlagMaskControl)
            Quartz.CGEventPostToPid(pid, ev)
            ev2 = Quartz.CGEventCreateKeyboardEvent(None, 8, False)
            Quartz.CGEventPostToPid(pid, ev2)
        else:
            code = key_codes.get(key, 36)
            kd = Quartz.CGEventCreateKeyboardEvent(None, code, True)
            ku = Quartz.CGEventCreateKeyboardEvent(None, code, False)
            Quartz.CGEventPostToPid(pid, kd)
            Quartz.CGEventPostToPid(pid, ku)

    def read_screen(self, target_id: str) -> str:
        window_id, tab_title = _parse_target_id(target_id)
        escaped_title = _apple_script_escape(tab_title)
        script = f'''
tell application "Terminal"
    set w to first window whose id is {window_id}
    repeat with t in tabs of w
        try
            if (custom title of t) is "{escaped_title}" then return contents of t
        end try
    end repeat
    error "Terminal.app tab not found: {escaped_title}"
end tell
'''
        return subprocess.check_output(
            ["osascript", "-e", script],
            text=True,
            timeout=_OSASCRIPT_TIMEOUT_SECONDS,
        )

    def close(self, target_id: str) -> None:
        window_id, tab_title = _parse_target_id(target_id)
        select_script = _select_tab_script(window_id, tab_title)
        subprocess.run(
            ["osascript", "-e", select_script],
            capture_output=True,
            timeout=_OSASCRIPT_TIMEOUT_SECONDS,
        )
        # Step 1: get tty of the window so we can kill all processes without a dialog
        tty_script = f'tell application "Terminal" to tty of selected tab of (first window whose id is {window_id})'
        r = subprocess.run(
            ["osascript", "-e", tty_script],
            capture_output=True,
            text=True,
            timeout=_OSASCRIPT_TIMEOUT_SECONDS,
        )
        tty = r.stdout.strip()
        if tty:
            # Kill all processes on the tty (avoids "Terminate running processes?" dialog)
            pids = subprocess.run(
                ["lsof", "-t", tty], capture_output=True, text=True
            ).stdout.split()
            for pid in pids:
                subprocess.run(["kill", "-9", pid], capture_output=True)
            time.sleep(0.5)
        # Step 2: close the now-empty tab.
        close_script = f'tell application "Terminal" to close selected tab of (first window whose id is {window_id}) saving no'
        subprocess.run(
            ["osascript", "-e", close_script],
            capture_output=True,
            timeout=_OSASCRIPT_TIMEOUT_SECONDS,
        )

    def resolve_target_id(self, pid: int, *, local_id: str | None = None) -> str | None:
        # Terminal.app window id is assigned at spawn and stored in cache; no live discovery.
        return None
