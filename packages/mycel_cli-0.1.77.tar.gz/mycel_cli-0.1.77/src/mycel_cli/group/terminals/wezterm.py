"""WezTerm terminal backend primitives.

This module is intentionally not registered in the public terminal registry
yet. It is a protocol proof for WezTerm's CLI control surface; public exposure
still requires real WezTerm YATU.
"""

from __future__ import annotations

import json
import os
import shlex
import subprocess
import time
from collections.abc import Mapping

from mycel_cli.group.terminal import TerminalPlacement

_WEZTERM_TIMEOUT_SECONDS = 5


class WezTermTerminal:
    def __init__(self, socket_path: str | None = None) -> None:
        self._socket = socket_path if socket_path is not None else _env_socket()

    def ensure_group_container(self, group_id: str) -> str:
        workspace = _workspace_name(group_id)
        if _workspace_panes(self._list(), workspace):
            return workspace
        self._run_output(
            "spawn",
            "--new-window",
            "--workspace",
            workspace,
            "--cwd",
            "/tmp",
            "--",
            "bash",
            "-l",
        )
        return workspace

    def spawn_in_container(
        self,
        container_ref: str,
        placement: TerminalPlacement,
        cwd: str,
        cmd: str,
    ) -> str:
        panes = _workspace_panes(self._list(), container_ref)
        if not panes:
            raise RuntimeError(f"WezTerm group workspace not found: {container_ref!r}")
        anchor = _anchor_pane(panes, placement)
        if placement.slot == "primary":
            pane_id = str(anchor["pane_id"])
            self.send_text(self._target_ref(pane_id), f"cd {shlex.quote(cwd)} && {cmd}")
            return self._target_ref(pane_id)
        args = [
            "split-pane",
            "--pane-id",
            str(anchor["pane_id"]),
            *_split_direction_args(placement),
            "--cwd",
            cwd,
            "--",
            "bash",
            "-c",
            cmd,
        ]
        pane_id = self._run_output(*args).strip()
        if not pane_id:
            raise RuntimeError("wezterm cli split-pane returned empty pane id")
        return self._target_ref(pane_id)

    def close_group_container(self, container_ref: str) -> None:
        for pane in _workspace_panes(self._list(), container_ref):
            pane_id = pane.get("pane_id")
            if pane_id is None:
                continue
            self._run_silent("kill-pane", "--pane-id", str(pane_id))

    def send_text(self, target_id: str, text: str) -> None:
        socket, pane_id = self._split_ref(target_id)
        self._run_silent_on(
            socket,
            "send-text",
            "--pane-id",
            pane_id,
            "--no-paste",
            text,
        )
        time.sleep(2)
        self._run_silent_on(
            socket,
            "send-text",
            "--pane-id",
            pane_id,
            "--no-paste",
            "\r",
        )

    def send_key(self, target_id: str, key: str) -> None:
        key_map = {"escape": "\x1b", "enter": "\r", "ctrl-c": "\x03"}
        if key not in key_map:
            raise ValueError(
                f"WezTerm: unsupported key {key!r}; valid: {sorted(key_map)}"
            )
        socket, pane_id = self._split_ref(target_id)
        self._run_silent_on(
            socket,
            "send-text",
            "--pane-id",
            pane_id,
            "--no-paste",
            key_map[key],
        )

    def read_screen(self, target_id: str) -> str:
        socket, pane_id = self._split_ref(target_id)
        return self._run_output_on(socket, "get-text", "--pane-id", pane_id)

    def close(self, target_id: str) -> None:
        socket, pane_id = self._split_ref(target_id)
        self._run_silent_on(socket, "kill-pane", "--pane-id", pane_id)

    def resolve_target_id_from_env(
        self,
        env: Mapping[str, str],
        *,
        pid: int,
        local_id: str | None = None,
    ) -> str | None:
        _ = pid, local_id
        pane_id = str(env.get("WEZTERM_PANE") or "").strip()
        if not pane_id:
            return None
        socket = str(env.get("WEZTERM_UNIX_SOCKET") or "").strip()
        if socket:
            return f"{socket}#{pane_id}"
        return pane_id

    def resolve_target_id(self, pid: int, *, local_id: str | None = None) -> str | None:
        _ = local_id
        for pane in self._list():
            if _pane_has_pid(pane, pid):
                return self._target_ref(str(pane["pane_id"]))
        return None

    def target_exists(self, target_id: str) -> bool:
        _, pane_id = self._split_ref(target_id)
        return any(str(pane.get("pane_id")) == pane_id for pane in self._list())

    def _target_ref(self, pane_id: str) -> str:
        return f"{self._socket}#{pane_id}" if self._socket else pane_id

    def _split_ref(self, target_id: str) -> tuple[str | None, str]:
        if "#" in target_id:
            socket, pane_id = target_id.rsplit("#", 1)
            if socket and pane_id:
                return socket, pane_id
        return self._socket or None, target_id

    def _list(self) -> list[dict]:
        raw = self._run_output("list", "--format", "json")
        try:
            data = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise RuntimeError("wezterm cli list returned invalid JSON") from exc
        if not isinstance(data, list):
            raise RuntimeError("wezterm cli list JSON must be a list")
        return [pane for pane in data if isinstance(pane, dict)]

    def _run_output(self, *args: str) -> str:
        return self._run_output_on(self._socket or None, *args)

    def _run_output_on(self, socket: str | None, *args: str) -> str:
        return subprocess.check_output(
            ["wezterm", "cli", *args],
            text=True,
            env=_wezterm_env(socket),
            timeout=_WEZTERM_TIMEOUT_SECONDS,
        ).strip()

    def _run_silent(self, *args: str) -> None:
        self._run_silent_on(self._socket or None, *args)

    def _run_silent_on(self, socket: str | None, *args: str) -> None:
        subprocess.run(
            ["wezterm", "cli", *args],
            capture_output=True,
            check=True,
            env=_wezterm_env(socket),
            timeout=_WEZTERM_TIMEOUT_SECONDS,
        )


def _env_socket() -> str:
    return os.environ.get("WEZTERM_UNIX_SOCKET", "")


def _wezterm_env(socket: str | None) -> dict[str, str]:
    env = dict(os.environ)
    if socket:
        env["WEZTERM_UNIX_SOCKET"] = socket
    return env


def _workspace_name(group_id: str) -> str:
    return f"cel-{group_id}"


def _workspace_panes(panes: list[dict], workspace: str) -> list[dict]:
    return [pane for pane in panes if pane.get("workspace") == workspace]


def _anchor_pane(panes: list[dict], placement: TerminalPlacement) -> dict:
    if placement.slot == "primary":
        return panes[0]
    anchor_title = placement.anchor_title
    if anchor_title:
        for pane in panes:
            if pane.get("title") == anchor_title:
                return pane
        raise RuntimeError(f"WezTerm anchor pane not found: {anchor_title!r}")
    return panes[0]


def _split_direction_args(placement: TerminalPlacement) -> list[str]:
    if placement.slot == "primary":
        return []
    if placement.slot == "right":
        return ["--right"]
    if placement.slot == "down":
        return ["--bottom"]
    if placement.slot == "next":
        raise ValueError(
            "WezTerm next placement is not implemented until tab/next semantics are YATU-proven"
        )
    raise ValueError(f"WezTerm: unsupported terminal placement: {placement!r}")


def _pane_has_pid(pane: dict, pid: int) -> bool:
    if pane.get("pid") == pid:
        return True
    return any(
        process.get("pid") == pid
        for process in pane.get("foreground_processes") or []
        if isinstance(process, dict)
    )
