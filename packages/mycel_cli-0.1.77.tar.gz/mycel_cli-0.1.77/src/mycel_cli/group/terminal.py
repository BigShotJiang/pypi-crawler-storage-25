"""Terminal abstraction layer for Mycel CLI local wake surfaces.

Group-container model: one group shares a single terminal container
(window / workspace / session). Users are spawned *inside* that
container at role-aware locations.

The container ref is persisted on the group
(``group["terminal_container"]``); backends introspect the live terminal
state (iterate windows by title, list workspaces by id, …) to resolve the
container for subsequent spawns. There is NO in-process cache in the
backend — state is the single source of truth.

Freeform provider wake reuses the same backend implementations for verified
runtime surfaces, but it does not imply every freeform backend is a group
orchestration backend.
"""

from __future__ import annotations

import importlib
from dataclasses import dataclass
from typing import Callable, Literal, Mapping, Protocol, runtime_checkable

DEFAULT_TERMINAL = "cmux"
TerminalCapability = Literal["group", "freeform"]
PlacementSlot = Literal["primary", "right", "down", "next"]
FreeformEnvDetector = Callable[[Mapping[str, str]], bool]


@dataclass(frozen=True)
class TerminalPlacement:
    slot: PlacementSlot
    title: str
    anchor_title: str | None = None


@dataclass(frozen=True)
class TerminalBackendSpec:
    name: str
    import_path: str
    prerequisite: str
    group_order: int | None = None
    freeform_order: int | None = None
    freeform_env_detector: FreeformEnvDetector | None = None
    context_keys: tuple[str, ...] = ()

    @property
    def capabilities(self) -> frozenset[TerminalCapability]:
        values: set[TerminalCapability] = set()
        if self.group_order is not None:
            values.add("group")
        if self.freeform_order is not None:
            values.add("freeform")
        return frozenset(values)


def _has_env(name: str) -> FreeformEnvDetector:
    return lambda env: bool(env.get(name))


def _term_program_is(value: str) -> FreeformEnvDetector:
    return lambda env: env.get("TERM_PROGRAM") == value


_BACKENDS = (
    TerminalBackendSpec(
        name="cmux",
        import_path="mycel_cli.group.terminals.cmux:CmuxTerminal",
        prerequisite="CMUX: Settings → Socket Control → set to 'Automation Mode'",
        group_order=0,
        freeform_order=1,
        freeform_env_detector=_has_env("CMUX_SURFACE_ID"),
        context_keys=("CMUX_SOCKET_PATH",),
    ),
    TerminalBackendSpec(
        name="tmux",
        import_path="mycel_cli.group.terminals.tmux:TmuxTerminal",
        prerequisite="TMUX: no prerequisites",
        group_order=1,
        freeform_order=0,
        freeform_env_detector=_has_env("TMUX"),
    ),
    TerminalBackendSpec(
        name="terminal",
        import_path="mycel_cli.group.terminals.terminal_app:TerminalAppTerminal",
        prerequisite="Terminal.app: System Settings → Privacy → Automation and Accessibility (grant permission to your shell/terminal)",
        group_order=2,
    ),
    TerminalBackendSpec(
        name="kitty",
        import_path="mycel_cli.group.terminals.kitty:KittyTerminal",
        prerequisite="Kitty: add 'allow_remote_control yes' and 'listen_on unix:/tmp/kitty.sock' to ~/.config/kitty/kitty.conf",
        group_order=3,
        freeform_order=2,
        freeform_env_detector=_has_env("KITTY_WINDOW_ID"),
        context_keys=("KITTY_LISTEN_ON",),
    ),
    TerminalBackendSpec(
        name="iterm2",
        import_path="mycel_cli.group.terminals.iterm2:ITerm2Terminal",
        prerequisite="iTerm2: install optional dependencies with pip install 'mycel-cli[iterm2]', enable Python API, then grant Automation permission to your shell/terminal to control iTerm2",
        group_order=4,
    ),
    TerminalBackendSpec(
        name="ghostty",
        import_path="mycel_cli.group.terminals.ghostty:GhosttyTerminal",
        prerequisite="Ghostty: run from a healthy GUI window; Ghostty's native scripting dictionary must expose windows/terminals and allow input text/send key",
        freeform_order=3,
        freeform_env_detector=_term_program_is("ghostty"),
    ),
)


def terminal_backend_specs() -> tuple[TerminalBackendSpec, ...]:
    return _BACKENDS


def _backend_spec(terminal_type: str) -> TerminalBackendSpec:
    for spec in terminal_backend_specs():
        if spec.name == terminal_type:
            return spec
    raise ValueError(
        f"Unknown terminal type: {terminal_type!r}. Choose from: {_known_terminal_choices_text()}"
    )


def _choices_for(capability: TerminalCapability) -> tuple[str, ...]:
    order_field = f"{capability}_order"
    specs = [
        spec
        for spec in terminal_backend_specs()
        if getattr(spec, order_field) is not None
    ]
    return tuple(
        spec.name for spec in sorted(specs, key=lambda spec: getattr(spec, order_field))
    )


def terminal_choices() -> tuple[str, ...]:
    return _choices_for("group")


def freeform_terminal_choices() -> tuple[str, ...]:
    return _choices_for("freeform")


def terminal_choices_text(*, separator: str = ", ") -> str:
    return separator.join(terminal_choices())


def _known_terminal_choices_text() -> str:
    return ", ".join(spec.name for spec in terminal_backend_specs())


def terminal_prerequisite(terminal_type: str) -> str:
    return _backend_spec(terminal_type).prerequisite


def terminal_context_keys(terminal_type: str) -> tuple[str, ...]:
    return _backend_spec(terminal_type).context_keys


def freeform_terminal_type_from_env(env: Mapping[str, str]) -> str | None:
    for terminal_type in freeform_terminal_choices():
        spec = _backend_spec(terminal_type)
        if spec.freeform_env_detector is not None and spec.freeform_env_detector(env):
            return spec.name
    return None


@runtime_checkable
class TargetTerminal(Protocol):
    def send_text(self, target_id: str, text: str) -> None:
        """Send text followed by Enter to the session."""
        ...

    def send_key(self, target_id: str, key: str) -> None:
        """Send a named key to the session. key values: 'escape', 'enter', 'ctrl-c'."""
        ...

    def resolve_target_id(self, pid: int, *, local_id: str | None = None) -> str | None:
        """Discover a running process's target_id by introspecting the OS."""
        ...


@runtime_checkable
class FreeformTerminal(Protocol):
    def send_text(self, target_id: str, text: str) -> None:
        """Send text followed by Enter to the session."""
        ...

    def resolve_target_id(self, pid: int, *, local_id: str | None = None) -> str | None:
        """Discover the current target for a running freeform provider."""
        ...


@runtime_checkable
class FreeformSurfacePreparer(Protocol):
    def prepare_freeform_surface(self, local_id: str) -> None:
        """Prepare a freeform surface so it can be resolved later."""
        ...


@runtime_checkable
class EnvTargetResolver(Protocol):
    def resolve_target_id_from_env(
        self,
        env: Mapping[str, str],
        *,
        pid: int,
        local_id: str | None = None,
    ) -> str | None:
        """Discover the current target from a launch/hook environment if available."""
        ...


@runtime_checkable
class TargetExistenceChecker(Protocol):
    def target_exists(self, target_id: str) -> bool:
        """Return whether a previously resolved target still exists."""
        ...


@runtime_checkable
class GroupTerminal(TargetTerminal, Protocol):
    def read_screen(self, target_id: str) -> str:
        """Return current visible screen content of the session."""
        ...

    def close(self, target_id: str) -> None:
        """Close/kill the session."""
        ...

    def ensure_group_container(self, group_id: str) -> str:
        """Create or return the backend-specific container for this group.

        Idempotent: first call creates the container (window/workspace/session);
        subsequent calls return the same ref. Backend may introspect its own
        live state (e.g. iterate windows by title) rather than caching in-process.
        """
        ...

    def spawn_in_container(
        self,
        container_ref: str,
        placement: TerminalPlacement,
        cwd: str,
        cmd: str,
    ) -> str:
        """Spawn a new surface inside the container at a layout placement.

        Args:
            container_ref: the container handle returned by
                ``ensure_group_container``.
            placement: terminal-layout slot plus display title. Workflow role
                names are mapped by the workflow preset before this layer.
            cwd: working directory for the spawned process.
            cmd: shell command to run.
        """
        ...

    def close_group_container(self, container_ref: str) -> None:
        """Close the entire container (all panes/tabs within).

        Best-effort: callers may swallow errors. Implementations should not
        raise for "already closed" situations.
        """
        ...


TERMINAL_CHOICES = terminal_choices()
VALID_TERMINALS = frozenset(TERMINAL_CHOICES)
FREEFORM_TERMINAL_CHOICES = freeform_terminal_choices()


def _load_backend(spec: TerminalBackendSpec) -> TargetTerminal | FreeformTerminal:
    module_name, sep, class_name = spec.import_path.partition(":")
    if not sep or not module_name or not class_name:
        raise RuntimeError(f"invalid terminal backend import path: {spec.import_path}")
    module = importlib.import_module(module_name)
    backend_class = getattr(module, class_name)
    return backend_class()


def _default_factory(terminal_type: str) -> TargetTerminal | FreeformTerminal:
    return _load_backend(_backend_spec(terminal_type))


_factory = _default_factory


def get_terminal(terminal_type: str) -> TargetTerminal | FreeformTerminal:
    """Factory: return terminal backend implementation for the given type.

    Delegates to the module-level ``_factory`` so tests can swap in a fake by
    monkeypatching ``mycel_cli.group.terminal._factory`` — works regardless of how callers
    imported ``get_terminal`` (``from mycel_cli.group.terminal import get_terminal`` binds
    the function object, but the function still looks up ``_factory`` at call
    time, so the patch takes effect everywhere).
    """
    return _factory(terminal_type)


def get_group_terminal(terminal_type: str) -> GroupTerminal:
    if "group" not in _backend_spec(terminal_type).capabilities:
        raise ValueError(f"Terminal type {terminal_type!r} does not support groups")
    terminal = get_terminal(terminal_type)
    if not isinstance(terminal, GroupTerminal):
        raise RuntimeError(
            f"Terminal type {terminal_type!r} declares group capability but does not satisfy GroupTerminal"
        )
    return terminal


def get_freeform_terminal(terminal_type: str) -> FreeformTerminal:
    if "freeform" not in _backend_spec(terminal_type).capabilities:
        raise ValueError(f"Terminal type {terminal_type!r} does not support freeform")
    terminal = get_terminal(terminal_type)
    if not isinstance(terminal, FreeformTerminal):
        raise RuntimeError(
            f"Terminal type {terminal_type!r} declares freeform capability but does not satisfy FreeformTerminal"
        )
    return terminal
