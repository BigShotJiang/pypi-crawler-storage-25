"""Outbound chat notifications to supervisor / reviewers."""

from __future__ import annotations

from typing import Any
from xml.sax.saxutils import escape as xml_escape

from mycel_cli.group._cli.chat_transport import (
    group_chat_for,
    owner_chat_for,
)
from mycel_cli.group._cli.identity_binding import role_record_user_id
from mycel_cli.message_send import send_addressed_message
from mycel_cli.group._workflow.constants import log
from mycel_cli.group._workflow.xml_format import build_event_xml
from mycel_cli.group._state.tasks import list_tasks
from mycel_cli.group._state.roles import (
    find_supervisor,
    iter_reviewer_roles,
    role_ready,
)


def notify_supervisor(group: dict[str, Any], message: str) -> None:
    """Send a workflow-originated event to the supervisor through Mycel chat."""
    group_name = group.get("name", "?")
    sup = find_supervisor(group)
    if not sup:
        log.warning(
            "notify_supervisor called on group %r with no supervisor — invariant violation, dropping: %s",
            group_name,
            message[:80],
        )
        return
    client, chat_id = owner_chat_for(group_id=str(group_name))
    send_addressed_message(
        client,
        chat_id=chat_id,
        content=message,
        addressed_to_user_ids=[role_record_user_id(sup)],
        enforce_caught_up=False,
    )
    log.info("workflow supervisor chat stored [%s] chat=%s", group_name, chat_id)


def notify_supervisor_from_role(
    *,
    group_id: str,
    group: dict[str, Any],
    sender: dict[str, Any],
    message: str,
) -> None:
    """Send a role-originated daemon event through Mycel addressed chat."""
    supervisor = find_supervisor(group)
    if not supervisor:
        log.warning(
            "notify_supervisor_from_role called on group %r with no supervisor",
            group_id,
        )
        return
    sender_role = str(sender["role"])
    sender_session = str(sender["session"])
    client, chat_id = group_chat_for(
        group_id=group_id,
        sender_local_id=str(sender.get("local_id") or ""),
    )
    send_addressed_message(
        client,
        chat_id=chat_id,
        content=message,
        addressed_to_user_ids=[role_record_user_id(supervisor)],
    )
    log.info(
        "role-originated supervisor chat stored [%s/%s -> %s] chat=%s",
        group_id,
        sender_session,
        sender_role,
        chat_id,
    )


def notify_reviewer(
    group: dict[str, Any], reviewer: dict[str, Any], message: str
) -> None:
    """Send a durable addressed review message."""
    group_name = group.get("name", "?")
    reviewer_id = reviewer.get("id", "?")
    supervisor = find_supervisor(group)
    if supervisor is None:
        log.warning(
            "Reviewer notification for group %r has no supervisor sender, dropping message",
            group_name,
        )
        return

    client, chat_id = group_chat_for(
        group_id=str(group_name),
        sender_local_id=str(supervisor.get("local_id") or ""),
    )
    send_addressed_message(
        client,
        chat_id=chat_id,
        content=message,
        addressed_to_user_ids=[role_record_user_id(reviewer)],
    )
    log.info(
        "reviewer chat notification stored [%s -> %s] chat=%s",
        group_name,
        reviewer_id,
        chat_id,
    )


def notify_all_reviewers(
    group: dict[str, Any],
    message: str,
    *,
    reviewer_ids: set[str] | None = None,
) -> None:
    """通知 group 的所有 reviewers。session 不可达的 reviewer 静默跳过。"""
    group_name = group.get("name", "?")
    reviewers = [
        {
            **user,
            "id": user.get("session"),
        }
        for user in iter_reviewer_roles(group)
        if user.get("status") == "active" and role_ready(user)
    ]
    if not reviewers:
        log.debug("No reviewers for group %r", group_name)
        return
    for reviewer in reviewers:
        reviewer_id = reviewer.get("id")
        if reviewer_ids is not None and reviewer_id not in reviewer_ids:
            continue
        notify_reviewer(group, reviewer, message)


def sync_group_to_reviewers(group_name: str, group: dict[str, Any]) -> None:
    """推送最新 group 内容（prompt + tasks 摘要）给所有 reviewers。纯信息同步，无判决。"""
    reviewers = [
        {
            **user,
            "id": user.get("session"),
        }
        for user in iter_reviewer_roles(group)
        if user.get("status") == "active" and role_ready(user)
    ]
    if not reviewers:
        return

    prompt = group.get("group_prompt") or "(未设置)"
    tasks = list_tasks(group_name)
    if tasks:
        lines = [f"#{t['id']} [{t['status']}] {t['subject']}" for t in tasks]
        tasks_summary = "\n".join(lines)
    else:
        tasks_summary = "(无 task)"

    body = xml_escape(
        f"Group {group_name} 信息同步:\nPrompt: {prompt}\nTasks:\n{tasks_summary}"
    )
    msg = build_event_xml(
        "group_sync",
        {"group": group_name},
        body,
    )
    for reviewer in reviewers:
        notify_reviewer(group, reviewer, msg)
