"""Worker 解析：从 cel user session 查找运行时信息（PID、surface、JSONL 路径）。"""

from __future__ import annotations

import json
import logging
import os
import shlex
import subprocess
from dataclasses import dataclass
from pathlib import Path

from mycel_cli.group.agent_types import normalize_agent_type

_log = logging.getLogger("mycel_cli.group.worker")


@dataclass
class WorkerInfo:
    session: str
    agent_type: str = "claude-code"
    pid: int | None = None
    terminal_type: str | None = None
    target_id: str | None = None  # terminal backend target id
    jsonl_path: Path | None = None
    jsonl_search: JsonlSearchResult | None = None
    thread_id: str | None = None
    running: bool = False


def _find_claude_pid(session: str, *, group_id: str | None = None) -> int | None:
    """从 ps 找到 claude --resume <session> 的实际二进制 PID（跳过 bash wrapper）。"""
    pid = _find_pid_by_mycel_user_session(
        session, group_id=group_id, binary_names=("claude",)
    )
    if pid is not None:
        return pid
    try:
        result = subprocess.run(
            ["ps", "-eo", "pid,args"],
            capture_output=True,
            text=True,
            timeout=5,
        )
    except Exception:
        return None

    candidates: list[tuple[int, str]] = []
    for line in result.stdout.strip().split("\n"):
        line = line.strip()
        if "claude" not in line:
            continue
        # 匹配 --resume <session> / --name <session> / --session-id <session>
        matched = False
        for flag in ("--resume", "--name", "--session-id"):
            if f"{flag} {session}" in line or f'{flag} "{session}"' in line:
                matched = True
                break
        if not matched:
            continue
        parts = line.split()
        try:
            pid = int(parts[0])
            args = " ".join(parts[1:])
            candidates.append((pid, args))
        except (ValueError, IndexError):
            pass

    if not candidates:
        return None

    # 优先选非 bash wrapper 的进程（实际二进制）
    for pid, args in candidates:
        if "bash" not in args:
            return pid

    # 没找到更具体的二进制进程时，返回第一个候选。
    return candidates[0][0]


def _list_processes() -> list[tuple[int, str]]:
    try:
        result = subprocess.run(
            ["ps", "-eo", "pid,args"],
            capture_output=True,
            text=True,
            timeout=5,
        )
    except Exception:
        return []

    processes: list[tuple[int, str]] = []
    for line in result.stdout.strip().split("\n"):
        line = line.strip()
        if not line:
            continue
        parts = line.split(maxsplit=1)
        if len(parts) != 2:
            continue
        try:
            processes.append((int(parts[0]), parts[1]))
        except ValueError:
            continue
    return processes


def _list_processes_with_env() -> list[tuple[int, str]]:
    try:
        result = subprocess.run(
            ["ps", "eww", "-axo", "pid=,command="],
            capture_output=True,
            text=True,
            timeout=5,
        )
    except Exception:
        return []

    processes: list[tuple[int, str]] = []
    for line in result.stdout.strip().split("\n"):
        line = line.strip()
        if not line:
            continue
        parts = line.split(maxsplit=1)
        if len(parts) != 2:
            continue
        try:
            processes.append((int(parts[0]), parts[1]))
        except ValueError:
            continue
    return processes


def _find_pid_by_mycel_user_session(
    session: str,
    *,
    binary_names: tuple[str, ...],
    group_id: str | None = None,
) -> int | None:
    session_marker = f"MYCEL_USER_SESSION={session}"
    group_marker = f"MYCEL_GROUP_ID={group_id}" if group_id else None
    candidates: list[tuple[int, str]] = []
    for pid, args in _list_processes_with_env():
        if not any(binary_name in args for binary_name in binary_names):
            continue
        if session_marker not in args:
            continue
        if group_marker is not None and group_marker not in args:
            continue
        candidates.append((pid, args))
    if not candidates:
        return None
    for pid, args in candidates:
        if _command_name(args) in binary_names:
            return pid
    for pid, args in candidates:
        if not _is_shell_or_python_wrapper(_command_name(args)):
            return pid
    return candidates[0][0]


def _is_shell_or_python_wrapper(command_name: str) -> bool:
    return command_name in {"bash", "zsh"} or command_name.startswith("python")


def _command_name(args: str) -> str:
    try:
        first = shlex.split(args, posix=True)[0]
    except (IndexError, ValueError):
        first = args.split(maxsplit=1)[0] if args.strip() else ""
    return Path(first).name


def _find_codex_pid(
    session: str,
    terminal_type: str | None,
    cache_hint: dict | None = None,
    *,
    group_id: str | None = None,
) -> int | None:
    _ = terminal_type
    pid = _find_pid_by_mycel_user_session(
        session, group_id=group_id, binary_names=("codex",)
    )
    if pid is not None:
        return pid

    identifiers = [session]
    cache_hint = cache_hint or {}
    thread_id = cache_hint.get("thread_id")
    if thread_id and thread_id not in identifiers:
        identifiers.append(str(thread_id))

    candidates: list[tuple[int, str]] = []
    for pid, args in _list_processes():
        if "codex" not in args:
            continue
        if not any(identifier and identifier in args for identifier in identifiers):
            continue
        candidates.append((pid, args))
    if not candidates:
        return None
    for pid, args in candidates:
        if "bash" not in args:
            return pid
    return candidates[0][0]


@dataclass
class JsonlSearchResult:
    path: Path | None = None
    dirs_searched: int = 0
    dirs_missing: int = 0
    files_scanned: int = 0
    titles_found: list[str] | None = None  # populated on miss for diagnostics


def _find_jsonl(session: str) -> JsonlSearchResult:
    """在当前 Claude 配置目录及常见回退目录下找 session 对应的 JSONL 文件。

    session 可以是 UUID（直接匹配文件名）或 display name（从 customTitle 匹配）。
    """
    search_dirs: list[Path] = []

    config_dir = Path.home() / ".claude"
    env_config = os.environ.get("CLAUDE_CONFIG_DIR")
    if env_config:
        search_dirs.append(Path(env_config) / "projects")
        config_dir = Path(env_config)

    search_dirs.extend(
        [
            config_dir / "projects",
            Path.home() / ".claude" / "projects",
        ]
    )

    # 去重，保留顺序
    deduped_dirs: list[Path] = []
    seen: set[Path] = set()
    for directory in search_dirs:
        if directory in seen:
            continue
        seen.add(directory)
        deduped_dirs.append(directory)

    search_dirs = deduped_dirs

    result = JsonlSearchResult()
    titles: list[str] = []

    for search_dir in search_dirs:
        if not search_dir.exists():
            result.dirs_missing += 1
            continue
        result.dirs_searched += 1

        # 1. 直接匹配 UUID 文件名
        for jsonl_path in search_dir.rglob(f"{session}.jsonl"):
            result.path = jsonl_path
            return result

        # 2. 按 customTitle 匹配（session name 不是 UUID 的情况）
        #    custom-title 条目可能不在第一行，扫描前 20 行
        for jsonl_path in search_dir.rglob("*.jsonl"):
            result.files_scanned += 1
            try:
                with open(jsonl_path) as f:
                    for _, line in zip(range(20), f):
                        entry = json.loads(line)
                        if entry.get("type") == "custom-title":
                            title = entry.get("customTitle", "")
                            titles.append(title)
                            if title == session:
                                result.path = jsonl_path
                                return result
                            break  # found custom-title, no match, move to next file
            except (json.JSONDecodeError, OSError):
                continue

    result.titles_found = titles
    if result.path is None:
        _log.info(
            "JSONL not found for session=%r searched_dirs=%d missing_dirs=%d files_scanned=%d titles_seen=%d",
            session,
            result.dirs_searched,
            result.dirs_missing,
            result.files_scanned,
            len(titles),
        )
    return result


def resolve_worker(
    session: str,
    terminal_type: str | None,
    *,
    agent_type: str | None = None,
    cache_hint: dict | None = None,
    group_id: str | None = None,
) -> WorkerInfo:
    """解析 CC session 的运行时信息：ps 反查 `claude --resume`/`--name` 进程。

    terminal_type=None: 跳过 target_id 探测（调用方只需要 pid/jsonl_path 时使用）。
    其他类型: 委托给 Terminal.resolve_target_id。不能反查的 terminal backend
    返回 None；spawn 时缓存的 target_id 仍可作为已知 surface 使用。
    """
    resolved_agent_type = normalize_agent_type(agent_type)
    info = WorkerInfo(session=session, agent_type=resolved_agent_type)
    info.terminal_type = terminal_type
    cache_hint = cache_hint or {}

    if resolved_agent_type == "codex":
        thread_id = cache_hint.get("thread_id")
        pid = _find_codex_pid(
            session,
            terminal_type,
            cache_hint,
            group_id=group_id,
        )
        if pid is None:
            info.running = False
        else:
            info.pid = pid
            info.running = True

        if terminal_type is not None and info.pid is not None:
            from mycel_cli.group.terminal import get_group_terminal

            try:
                info.target_id = get_group_terminal(terminal_type).resolve_target_id(
                    info.pid
                )
            except Exception:
                info.target_id = None
        if info.target_id is None:
            info.target_id = cache_hint.get("target_id")

        transcript_path = cache_hint.get("jsonl_path") or cache_hint.get(
            "transcript_path"
        )
        if transcript_path:
            info.jsonl_path = Path(transcript_path)
        if thread_id:
            info.thread_id = str(thread_id)
        return info

    # 1. 找 PID
    pid = _find_claude_pid(session, group_id=group_id)
    if pid is None:
        info.running = False
        # 仍然尝试找 JSONL（进程可能已退出但文件还在）
        search = _find_jsonl(session)
        info.jsonl_path = search.path
        info.jsonl_search = search
        return info

    info.pid = pid
    info.running = True

    # 2. 通过 Terminal Protocol 反查 target_id
    if terminal_type is not None:
        from mycel_cli.group.terminal import get_group_terminal

        try:
            info.target_id = get_group_terminal(terminal_type).resolve_target_id(pid)
        except Exception:
            info.target_id = None

    # 3. 找 JSONL
    search = _find_jsonl(session)
    info.jsonl_path = search.path
    info.jsonl_search = search

    return info


def worker_cache_from_info(info: "WorkerInfo") -> dict:
    """从 WorkerInfo 构造 user.cache dict（跳过 None 字段避免 JSON 噪声）。

    terminal_type 不写入 cache：group 是唯一来源（避免数据漂移）。
    """
    cache: dict = {}
    pid = getattr(info, "pid", None)
    target_id = getattr(info, "target_id", None)
    jsonl_path = getattr(info, "jsonl_path", None)
    thread_id = getattr(info, "thread_id", None)
    if pid is not None:
        cache["pid"] = pid
    if target_id is not None:
        cache["target_id"] = target_id
    if jsonl_path is not None:
        cache["jsonl_path"] = str(jsonl_path)
    if thread_id is not None:
        cache["thread_id"] = thread_id
    return cache


def _read_tail(path: Path, max_bytes: int = 256 * 1024) -> list[str]:
    """从文件尾部读取最多 max_bytes 字节，返回完整行列表。"""
    size = path.stat().st_size
    with open(path, "rb") as f:
        if size > max_bytes:
            f.seek(size - max_bytes)
            f.readline()  # 跳过截断的首行
        return f.read().decode("utf-8", errors="replace").strip().split("\n")


def read_last_message(jsonl_path: Path) -> dict:
    """从 JSONL 读取 Worker 最后一条 assistant 消息（完整内容）。"""
    if not jsonl_path.exists():
        return {"ok": False, "error": "JSONL 不存在"}

    try:
        lines = _read_tail(jsonl_path)
    except Exception:
        return {"ok": False, "error": "无法读取 JSONL"}

    for line in reversed(lines):
        try:
            entry = json.loads(line)
        except json.JSONDecodeError:
            continue
        if entry.get("type") != "assistant":
            continue

        content = entry.get("message", {}).get("content", "")
        if isinstance(content, list):
            text = "\n".join(c["text"] for c in content if c.get("type") == "text")
        else:
            text = str(content)

        return {
            "ok": True,
            "timestamp": entry.get("timestamp", ""),
            "message": text,
        }

    return {"ok": False, "error": "没有 assistant 消息"}
