"""Group CLI — command model v2.

Owns the `cel group` Typer app:

    cel group config
    cel group <create|update|remove|list|show|start|stop>
    cel group <group_id> <task|worker|supervisor|reviewer> <verb> ...

Command bodies delegate to `mycel_cli.group._cli.*` sub-modules organised by
responsibility. See `mycel_cli.group._cli.__init__` for the split rationale. Any
test that used to patch `mycel_cli.group.cli.<helper>` should now patch
`mycel_cli.group._cli.<module>.<helper>` (the symbol actually used at call time).
"""

from __future__ import annotations

import json
import logging
import sys

import click
import typer
from typer.core import TyperGroup

from mycel_cli.group.agent_types import normalize_agent_type
from mycel_cli.group._cli.authority import authorize_group_stop, authorize_operation
from mycel_cli.group._cli.constants import (
    COMMAND_HELP,
    CREATE_HELP,
    GROUP_HELP,
    GROUP_SCOPED_HELP,
)
from mycel_cli.group._cli.dispatch import dispatch_group_scoped
from mycel_cli.group._cli.helpers import (
    ensure_file_in_messages_dir,
    format_timestamp,
    load_mycel_config,
    missing_review_events,
    require_global,
    require_group_by_name,
    REQUIRED_REVIEW_EVENTS,
    REVIEW_EVENT_LABELS,
    reviewer_covers_event,
    review_event_coverage,
    save_mycel_config,
)
from mycel_cli.group._cli.workflow_participants import KEEP_PRESET
from mycel_cli.group._workflow.constants import (
    EV_GROUP_STOP,
    group_start_signal_file,
    group_stop_signal_file,
)
from mycel_cli.group._workflow.review import cancel_pending_group_stop
from mycel_cli.group._cli import spawn as _spawn_mod
from mycel_cli.group._cli.spawn import (
    check_stop_hook_or_fail,
)
from mycel_cli.group._state.config import (
    default_terminal_global,
    is_workers_enabled_for_group,
    workers_enabled_global,
)
from mycel_cli.group._state.workflow import (
    apply_header,
    delete_header,
    ensure_workflow,
    get_header,
    group_from_header,
    has_header,
    mirror_header,
    set_header,
)
from mycel_cli.group._state.content import read_mycel_home_text, resolve_content
from mycel_cli.group._state.groups import (
    create_group,
    delete_group,
    group_terminal_type,
    list_groups,
    load_group,
)
from mycel_cli.group._state.reviewers import (
    get_review_event,
    list_review_events,
    update_review_event,
)
from mycel_cli.group._state.tasks import list_tasks
from mycel_cli.group._state.roles import (
    find_supervisor,
    get_role,
    iter_reviewers,
    iter_workers,
    role_agent_type,
)
from mycel_cli.group.workflow_policy import ActorRole, OperationName
from mycel_cli.config import (
    base_url_line,
    config_client_kwargs,
    effective_base_url,
    load_owner_config,
)
from mycel_cli.identity_store import IdentityStore
from mycel_cli.target_resolver import resolve_user_ref
from mycel_cli.group.terminal import (
    VALID_TERMINALS,
    get_group_terminal,
    terminal_choices_text,
    terminal_prerequisite,
)
from mycel_sdk import Client

_log = logging.getLogger("mycel_cli.group.cli")


_GROUP_ID_MANAGEMENT_COMMANDS = frozenset({"show", "update", "remove", "start", "stop"})


def is_group_shortcut_invocation(args: list[str]) -> bool:
    if len(args) > 1 and args[1] not in _group_shortcut_commands():
        return False
    return args[0] in list_groups()


def _group_shortcut_commands() -> frozenset[str]:
    return _GROUP_ID_MANAGEMENT_COMMANDS | frozenset(GROUP_SCOPED_HELP)


def _require_group_with_backend_header(group_id: str) -> dict:
    header = get_header(group_id)
    group = load_group(group_id) or group_from_header(group_id, header)
    apply_header(group, header)
    return group


def _scoped_command_help(subject: str, rest: list[str]) -> str | None:
    if not rest or rest in (["--help"], ["-h"]):
        return GROUP_SCOPED_HELP.get(subject)
    if len(rest) != 2 or rest[1] not in {"--help", "-h"}:
        return None
    command = rest[0]
    if command == "create" and subject in CREATE_HELP:
        return CREATE_HELP[subject]
    return COMMAND_HELP.get(subject, {}).get(command)


# ── typer app wiring ──────────────────────────────────────────


class GroupCommandGroup(TyperGroup):
    def parse_args(self, ctx: click.Context, args: list[str]) -> list[str]:
        if args and args[0] in GROUP_SCOPED_HELP and args[0] not in self.commands:
            ctx.meta["group_help_args"] = list(args)
            return []
        if args and args[0] not in self.commands and args[0] not in {"-h", "--help"}:
            if len(args) > 1 and args[1] in _GROUP_ID_MANAGEMENT_COMMANDS:
                return super().parse_args(ctx, [args[1], args[0], *args[2:]])
            if len(args) > 1 and args[1] in {"-h", "--help"}:
                ctx.meta["group_scoped_args"] = list(args)
                return []
            if len(args) > 1 and args[1] not in GROUP_SCOPED_HELP:
                return super().parse_args(ctx, args)
            ctx.meta["group_scoped_args"] = list(args)
            return []
        return super().parse_args(ctx, args)


_rich_markup_mode = None if not sys.stdout.isatty() else "rich"

group_app = typer.Typer(
    cls=GroupCommandGroup,
    help=GROUP_HELP,
    invoke_without_command=True,
    rich_markup_mode=_rich_markup_mode,
)


@group_app.callback()
def group_main(ctx: typer.Context) -> None:
    if ctx.invoked_subcommand is not None:
        return

    help_args = ctx.meta.get("group_help_args")
    if help_args:
        subject = help_args[0]
        help_text = _scoped_command_help(subject, help_args[1:])
        if help_text is not None:
            typer.echo(help_text)
            raise typer.Exit()
        typer.echo(f"No such command '{subject}'", err=True)
        raise typer.Exit(2)

    scoped_args = ctx.meta.get("group_scoped_args")
    if not scoped_args:
        return

    group_id = scoped_args[0]
    rest = scoped_args[1:]
    if not rest:
        group_show(group_id)
        raise typer.Exit()
    if rest in (["--help"], ["-h"]):
        typer.echo(_group_instance_help(group_id))
        raise typer.Exit()

    subject = rest[0]
    help_text = _scoped_command_help(subject, rest[1:])
    if help_text is not None:
        typer.echo(help_text)
        raise typer.Exit()

    dispatch_group_scoped(group_id, rest)


def _group_instance_help(group_id: str) -> str:
    return "\n".join(
        [
            f"Group '{group_id}'",
            "",
            "Use the group-scoped form:",
            f"  cel group {group_id} task ...",
            f"  cel group {group_id} supervisor ...",
            f"  cel group {group_id} worker ...",
            f"  cel group {group_id} reviewer ...",
            f"  cel group show {group_id}",
            "",
            "Group-id shortcut for existing local groups:",
            f"  cel {group_id} task ...",
        ]
    )


def _require_id(value: object, *, label: str) -> str:
    text = str(value or "").strip()
    if not text:
        raise RuntimeError(f"{label} is empty")
    return text


def _group_chat_lines(chat: object) -> list[str]:
    if not isinstance(chat, dict):
        return [f"  Backend: {chat}"]
    lines: list[str] = []
    title = chat.get("title")
    if title is not None:
        lines.append(f"  Title: {title}")
    kind = chat.get("kind", chat.get("type"))
    if kind is not None:
        lines.append(f"  Kind: {kind}")
    members = chat.get("members")
    if isinstance(members, list):
        lines.append(f"  Members: {len(members)}")
    return lines


def _workflow_label(group_id: str) -> str:
    return "keep" if has_header(group_id) else "none"


def _ensure_keep_workflow_for_group(group_id: str, group: dict) -> dict:
    header = ensure_workflow(
        group_id,
        terminal_type=group_terminal_type(group),
        workers_enabled=(
            bool(group["workers_enabled"])
            if group.get("workers_enabled") is not None
            else workers_enabled_global()
        ),
        preset=KEEP_PRESET,
        state=str(group.get("status") or "stopped"),
    )
    return mirror_header(group_id, header)


@group_app.command("config")
def group_config(
    terminal: str = typer.Option(
        "", "--terminal", help=f"Default terminal: {terminal_choices_text()}"
    ),
    workers_enabled: str = typer.Option(
        "", "--workers-enabled", help="Default worker roles: true or false"
    ),
    base_url: str = typer.Option("", "--base-url", help="Default Mycel backend URL"),
    clear_base_url: bool = typer.Option(
        False, "--clear-base-url", help="Use the built-in Mycel backend URL"
    ),
) -> None:
    """Show or update local Mycel defaults."""
    if terminal or workers_enabled or base_url or clear_base_url:
        authorize_operation(OperationName.GROUP_CONFIG)
    if base_url and clear_base_url:
        typer.echo("Use either --base-url or --clear-base-url, not both.", err=True)
        raise typer.Exit(1)
    config = load_mycel_config()
    updates = 0

    if terminal:
        if terminal not in VALID_TERMINALS:
            typer.echo(
                f"Invalid terminal '{terminal}'. Choose from: {terminal_choices_text()}",
                err=True,
            )
            raise typer.Exit(1)
        config["default_terminal"] = terminal
        config.pop("terminal", None)
        updates += 1

    workers_enabled_value = _parse_workers_enabled_override_or_fail(
        workers_enabled=workers_enabled,
        no_workers=False,
        context_label="workers-enabled",
    )
    if workers_enabled_value is not None:
        config["workers_enabled"] = workers_enabled_value
        updates += 1

    if base_url:
        config["base_url"] = base_url
        updates += 1

    if clear_base_url:
        if "base_url" in config:
            config.pop("base_url", None)
            updates += 1

    if updates:
        save_mycel_config(config)
        typer.echo("Cel defaults updated.")

    typer.echo("\n".join(_group_config_lines()))
    if terminal:
        typer.echo(f"Prerequisites: {terminal_prerequisite(terminal)}")


# ── group ─────────────────────────────────────────────────────


@group_app.command("create")
def group_create(
    title: str | None = typer.Option(
        None, "--title", help="optional group title; omitted means no title"
    ),
    terminal: str = typer.Option(
        "",
        "--terminal",
        help=f"Terminal type when Keep workflow starts: {terminal_choices_text(separator='|')}",
    ),
    workers_enabled: str = typer.Option(
        "",
        "--workers-enabled",
        help="Worker roles when Keep workflow starts: true|false",
    ),
    no_workers: bool = typer.Option(
        False,
        "--no-workers",
        help="Create the group with worker roles disabled when workflow starts.",
    ),
) -> None:
    authorize_operation(OperationName.GROUP_CREATE)
    require_global()
    if terminal:
        if terminal not in VALID_TERMINALS:
            typer.echo(
                f"Invalid terminal '{terminal}'. Choose from: {terminal_choices_text()}",
                err=True,
            )
            raise typer.Exit(1)
        resolved_terminal = terminal
    else:
        resolved_terminal = default_terminal_global()
    workers_enabled_flag = _parse_workers_enabled_override_or_fail(
        workers_enabled=workers_enabled,
        no_workers=no_workers,
        context_label="workers-enabled",
    )
    resolved_workers_enabled = (
        workers_enabled_flag
        if workers_enabled_flag is not None
        else workers_enabled_global()
    )
    try:
        cfg = load_owner_config()
        client = Client(**config_client_kwargs(cfg))
        chat = client.chats.create([], title=title, kind="group")
        if not isinstance(chat, dict):
            raise RuntimeError("backend did not return a group chat payload")
        group_id = str(chat.get("id") or chat.get("chat_id") or "").strip()
        if not group_id:
            raise RuntimeError("backend did not return a group chat id")
        create_group(
            group_id,
            terminal_type=resolved_terminal,
            workers_enabled=resolved_workers_enabled,
        )
    except (RuntimeError, ValueError) as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    worker_roles = "enabled" if resolved_workers_enabled else "disabled"
    typer.echo(
        f"Group '{group_id}' 已创建。\n"
        f"Keep defaults: terminal={resolved_terminal}, worker roles: {worker_roles}"
    )


@group_app.command("add-member")
def group_add_member(
    group_id: str = typer.Argument(...),
    identity: str = typer.Argument(
        ..., help="Member local id or backend user id for this ordinary room."
    ),
    json_output: bool = typer.Option(
        False, "--json", help="Print machine-readable JSON."
    ),
) -> None:
    require_global()
    try:
        cfg = load_owner_config()
        user_id, local_id = resolve_user_ref(
            identity,
            IdentityStore.from_env(),
            owner_user_id=getattr(cfg, "created_by_user_id", None),
        )
        user_id = _require_id(user_id, label="group member user target")
        client = Client(**config_client_kwargs(cfg))
        result = client.chats.add_member(group_id, user_id)
    except (RuntimeError, ValueError) as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    if json_output:
        payload: dict[str, object] = {
            "group_id": group_id,
            "user_id": user_id,
            "member": result,
        }
        if local_id:
            payload["resolved_from_local_id"] = local_id
        typer.echo(json.dumps(payload, ensure_ascii=False))
        return
    lines = ["Group member added", "", f"Group ID: {group_id}", f"User ID: {user_id}"]
    if local_id:
        lines.append(f"Resolved from local ID: {local_id}")
    if isinstance(result, dict) and result.get("state") is not None:
        lines.append(f"State: {result['state']}")
    lines.extend(["", "Use --json for machine-readable group member result."])
    typer.echo("\n".join(lines))


@group_app.command("update")
def group_update(
    group_id: str = typer.Argument(...),
    prompt: str = typer.Argument(""),
    terminal: str = typer.Option(
        "",
        "--terminal",
        help=f"Change terminal type: {terminal_choices_text(separator='|')}",
    ),
    workers_enabled: str = typer.Option(
        "", "--workers-enabled", help="Change worker roles: true|false"
    ),
    no_workers: bool = typer.Option(
        False, "--no-workers", help="Update the group to run without worker roles."
    ),
) -> None:
    authorize_operation(OperationName.GROUP_UPDATE, group_id=group_id)
    require_global()
    group = require_group_by_name(group_id)
    workers_enabled_value = _parse_workers_enabled_override_or_fail(
        workers_enabled=workers_enabled,
        no_workers=no_workers,
        context_label="workers-enabled",
    )
    if not prompt and not terminal and workers_enabled_value is None:
        typer.echo(
            "Nothing to update. Provide a prompt or one of --terminal/--workers-enabled.",
            err=True,
        )
        raise typer.Exit(1)
    if terminal and terminal not in VALID_TERMINALS:
        typer.echo(
            f"Invalid terminal '{terminal}'. Choose from: {terminal_choices_text()}",
            err=True,
        )
        raise typer.Exit(1)
    try:
        _ensure_keep_workflow_for_group(group_id, group)
        header_patch: dict[str, object] = {}
        if prompt:
            header_patch["group_prompt"] = prompt
        if terminal:
            header_patch["terminal_type"] = terminal
        if workers_enabled_value is not None:
            header_patch["workers_enabled"] = workers_enabled_value
        header = set_header(group_id, **header_patch)
        mirror_header(group_id, header)
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    typer.echo(f"Group '{group_id}' 已更新。")
    # Signal daemon to sync updated group to reviewers
    from mycel_cli.group._workflow.constants import group_sync_signal_file

    group_sync_signal_file(group_id).write_text("")


@group_app.command("remove")
def group_remove(group_id: str = typer.Argument(...)) -> None:
    authorize_operation(OperationName.GROUP_REMOVE, group_id=group_id)
    require_global()
    group = load_group(group_id)
    worker_sessions: list[str] = []
    if group is not None:
        supervisor = find_supervisor(group)
        if supervisor:
            worker_sessions.append(supervisor["session"])
            _spawn_mod.kill_and_close_worker(supervisor, group)
            typer.echo(f"  Supervisor {supervisor['session'][:8]} closed")
        workers = list(iter_workers(group))
        if workers:
            worker_sessions.extend(w["session"] for w in workers)
            for w in workers:
                _spawn_mod.kill_and_close_worker(w, group)
            typer.echo(
                f"  {len(workers)} worker{'s' if len(workers) > 1 else ''} closed"
            )
        reviewers = list(iter_reviewers(group_id))
        if reviewers:
            for r in reviewers:
                if r.get("session"):
                    worker_sessions.append(r["session"])
                _spawn_mod.kill_and_close_worker(r, group)
                typer.echo(
                    f"  Reviewer {r.get('name', r['id'])} ({r['id'][:8]}) closed"
                )
        ref = group.get("terminal_container")
        if ref:
            try:
                get_group_terminal(group_terminal_type(group)).close_group_container(
                    ref
                )
            except Exception as exc:
                _log.warning("close_group_container %r: %s", ref, exc)
    try:
        if has_header(group_id):
            delete_header(group_id)
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    if not delete_group(group_id):
        typer.echo(f"Group '{group_id}' 不存在", err=True)
        raise typer.Exit(1)
    from mycel_cli.group._workflow import memory_state

    memory_state.purge_group(group_id, worker_sessions)
    typer.echo(f"  Group {group_id} deleted")


@group_app.command("list")
@group_app.command("ls")
def group_list() -> None:
    require_global()
    names = list_groups()
    if not names:
        typer.echo("没有 group。")
        return
    lines = ["Groups:"]
    for name in names:
        group = load_group(name)
        if group is None:
            continue
        task_count = len(list_tasks(name))
        title = ""
        try:
            cfg = load_owner_config()
            client = Client(**config_client_kwargs(cfg))
            chat = client.chats.get(name)
            if isinstance(chat, dict) and chat.get("title"):
                title = f" ({chat['title']})"
        except RuntimeError:
            raise
        lines.append(
            f"  {name}{title} — {len(iter_workers(group))} workers, {task_count} tasks"
        )
    typer.echo("\n".join(lines))


@group_app.command("show")
def group_show(group_id: str = typer.Argument(...)) -> None:
    require_global()
    try:
        group = load_group(group_id)
        if group is None:
            cfg = load_owner_config()
            client = Client(**config_client_kwargs(cfg))
            chat = client.chats.get(group_id)
            lines = [f"Group '{group_id}':"]
            lines.extend(_group_chat_lines(chat))
            lines.append(f"  Workflow: {_workflow_label(group_id)}")
            typer.echo("\n".join(lines))
            return
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    lines = [f"Group '{group_id}':"]
    lines.append(f"  状态: {group['status']}")
    lines.append(f"  创建时间: {format_timestamp(group.get('created_at'))}")
    try:
        cfg = load_owner_config()
        client = Client(**config_client_kwargs(cfg))
        lines.extend(_group_chat_lines(client.chats.get(group_id)))
    except RuntimeError:
        raise
    workflow = "none"
    if has_header(group_id):
        header = get_header(group_id)
        apply_header(group, header)
        workflow = "keep"
        lines.append(f"  Terminal: {group_terminal_type(group)}")
        worker_roles = "enabled" if is_workers_enabled_for_group(group) else "disabled"
        lines.append(f"  Worker Roles: {worker_roles}")
        prompt = group.get("group_prompt")
        lines.append(f"  Prompt: {resolve_content(prompt) if prompt else '(未设置)'}")
        lines.append("  Tasks: Mycel chat task store")
    else:
        worker_roles = "enabled" if is_workers_enabled_for_group(group) else "disabled"
        lines.append(
            f"  Keep defaults: terminal={group_terminal_type(group)}, worker roles={worker_roles}"
        )
    lines.append(f"  Workflow: {workflow}")
    typer.echo("\n".join(lines))


@group_app.command(
    "start",
    help=(
        "mark a group active and let the local service deliver supervisor, "
        "reviewer, and worker events"
    ),
)
def group_start(group_id: str = typer.Argument(...)) -> None:
    authorize_operation(OperationName.GROUP_START, group_id=group_id)
    require_global()
    try:
        group = _ensure_keep_workflow_for_group(
            group_id, require_group_by_name(group_id)
        )
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)

    # Pre-flight: verify stop hook is wired up
    # Pre-flight checks: require supervisor AND at least one reviewer
    supervisor = find_supervisor(group)
    try:
        reviewers = list(iter_reviewers(group_id))
    except ValueError:
        reviewers = []

    missing: list[str] = []
    if not supervisor:
        missing.append(
            f"  注册 Supervisor: cel group {group_id} supervisor create --name <name>"
        )
    if not reviewers:
        missing.append(
            f"  添加 Reviewer:   cel group {group_id} reviewer create --name <name>"
        )
    else:
        missing_events = missing_review_events(reviewers)
        for event_type in missing_events:
            label = REVIEW_EVENT_LABELS[event_type]
            missing.append(f"  Reviewer 覆盖缺失: {label} 需要至少一个 reviewer 处理")
    if missing:
        typer.echo(
            f"Group '{group_id}' 无法启动：需要 Supervisor，且 3 个 review 事件都至少有一个 reviewer 覆盖。\n"
            + "\n".join(missing),
            err=True,
        )
        raise typer.Exit(1)

    agent_types = {
        role_agent_type(supervisor),
        *(normalize_agent_type(r.get("agent_type")) for r in reviewers),
    }
    check_stop_hook_or_fail(agent_types)

    try:
        header = set_header(group_id, state="active")
        group = mirror_header(group_id, header)
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    cancel_pending_group_stop(group_id)
    group_start_signal_file(group_id).write_text("")
    typer.echo(f"Group '{group_id}' 已启动。\n")

    issues: list[str] = []

    sup_label = supervisor.get("name") or supervisor.get("session", "?")
    typer.secho(f"  ✓ Supervisor: {sup_label}", fg=typer.colors.GREEN)

    if reviewers:
        reviewer_labels = ", ".join(
            r.get("name") or r.get("id", "?") for r in reviewers
        )
        typer.secho(
            f"  ✓ Reviewers ({len(reviewers)}): {reviewer_labels}",
            fg=typer.colors.GREEN,
        )
        coverage = review_event_coverage(reviewers)
        coverage_summary = "; ".join(
            f"{REVIEW_EVENT_LABELS[event_type]}=" + ",".join(coverage[event_type])
            for event_type in REQUIRED_REVIEW_EVENTS
        )
        typer.secho(f"  ✓ Review Coverage: {coverage_summary}", fg=typer.colors.GREEN)
    else:
        typer.secho("  ✗ Reviewers: 无", fg=typer.colors.YELLOW)
        issues.append(
            f"无 Reviewer——task 送审后无人判决。添加：cel group {group_id} reviewer create --name <name>"
        )

    workers = iter_workers(group)
    workers_enabled = is_workers_enabled_for_group(group)
    if not workers_enabled:
        typer.secho(
            "  ✓ Workers: disabled for this group",
            fg=typer.colors.GREEN,
        )
    elif workers:
        labels = ", ".join(w.get("name") or w.get("session", "?") for w in workers)
        typer.secho(f"  ✓ Workers ({len(workers)}): {labels}", fg=typer.colors.GREEN)
    else:
        typer.secho("  ✗ Workers: 无", fg=typer.colors.YELLOW)
        issues.append("无 Worker——无法执行任务")

    tasks = list_tasks(group_id)
    if tasks:
        statuses: dict[str, int] = {}
        for task in tasks:
            status = str(task.get("status") or "unknown")
            if status == "deleted":
                continue
            statuses[status] = statuses.get(status, 0) + 1
        summary = ", ".join(
            f"{count} {status}" for status, count in sorted(statuses.items())
        )
        typer.secho(
            f"  ✓ Tasks: {summary or '0 active'} / {len(tasks)} total",
            fg=typer.colors.GREEN,
        )
    else:
        typer.secho("  ✗ Tasks: 无", fg=typer.colors.YELLOW)
        issues.append("Task 队列为空——Supervisor 收到 start 后无任务可推进")

    if issues:
        typer.echo("")
        for issue in issues:
            typer.secho(f"  ⚠  {issue}", fg=typer.colors.YELLOW)


@group_app.command(
    "stop",
    help="request or record group shutdown through the supervisor/reviewer flow",
)
def group_stop(
    group_id: str = typer.Argument(...),
    rationale: str | None = typer.Option(
        None, "--rationale", help="停止原因文件路径（说明 group 为何完成）"
    ),
    status: str | None = typer.Option(
        None, "--status", help="reviewer 决策状态：stopped 或 active"
    ),
    force: bool = typer.Option(
        False, "--force", help="跳过 reviewer 审批，直接强制停止"
    ),
) -> None:
    require_global()
    try:
        group = _ensure_keep_workflow_for_group(
            group_id, require_group_by_name(group_id)
        )
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)

    decision = authorize_group_stop(
        group_id,
        group,
        force=force,
    )
    actor = decision.actor
    desired_status = status or "stopped"

    if force and desired_status != "stopped":
        typer.echo("--force 只允许与 stopped 一起使用。", err=True)
        raise typer.Exit(2)

    if force:
        try:
            header = set_header(group_id, state="stopped")
            mirror_header(group_id, header)
        except RuntimeError as exc:
            typer.echo(str(exc), err=True)
            raise typer.Exit(1)
        cancel_pending_group_stop(group_id)
        typer.echo(f"Group '{group_id}' 已强制停止。")
        return

    if actor.role == ActorRole.REVIEWER:
        if desired_status not in {"stopped", "active"}:
            typer.echo("--status 只允许 stopped 或 active。", err=True)
            raise typer.Exit(2)
        rationale_path = None
        if rationale is not None:
            rationale_path = str(
                ensure_file_in_messages_dir(
                    group,
                    rationale,
                    label="rationale file",
                    record_index=True,
                )
            )
        event_id = _record_reviewer_group_stop_decision(
            group_id,
            reviewer_id=str(actor.user_session or ""),
            group_status=desired_status,
            rationale_path=str(rationale_path or ""),
        )
        typer.echo(
            f"审批已记录：group -> {desired_status}（batch {event_id}）。等待结算。"
        )
        return

    if desired_status != "stopped":
        typer.echo("supervisor 发起 group stop 时 --status 只能是 stopped。", err=True)
        raise typer.Exit(2)

    # When reviewers are configured, delegate stop decision to daemon/reviewers.
    try:
        reviewers = list(iter_reviewers(group_id))
    except ValueError:
        reviewers = []

    if reviewers and group.get("status") != "stopped":
        rationale_path: str | None = None
        if rationale is not None:
            rationale_path = str(
                ensure_file_in_messages_dir(
                    group,
                    rationale,
                    label="rationale file",
                    record_index=True,
                )
            )
        _request_group_stop_review(group_id, group, rationale_path)
        return

    # No reviewers or already stopped — stop immediately.
    try:
        header = set_header(group_id, state="stopped")
        mirror_header(group_id, header)
    except RuntimeError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    typer.echo(f"Group '{group_id}' 已停止。")


def _has_open_group_stop_request(group: dict) -> bool:
    group_id = str(group.get("name") or "")
    return bool(_open_group_stop_events(group_id))


def _open_group_stop_events(group_id: str) -> list[dict]:
    return [
        event
        for event in list_review_events(group_id)
        if event.get("type") == EV_GROUP_STOP and not event.get("final_verdict")
    ]


def _open_group_stop_event(group_id: str) -> tuple[str, dict]:
    matches = _open_group_stop_events(group_id)
    if len(matches) != 1:
        typer.echo(
            f"Group '{group_id}' 当前没有唯一的待审批 group stop，reviewer 不能直接行权。",
            err=True,
        )
        raise typer.Exit(1)
    event = matches[0]
    return str(event["id"]), get_review_event(group_id, str(event["id"]))


def _record_reviewer_group_stop_decision(
    group_id: str,
    *,
    reviewer_id: str,
    group_status: str,
    rationale_path: str,
) -> str:
    event_id, event = _open_group_stop_event(group_id)
    reviewer = get_role(group_id, reviewer_id, role="reviewer")
    if not reviewer_covers_event(reviewer, EV_GROUP_STOP):
        typer.echo(
            f"reviewer '{reviewer_id[:8]}' 未覆盖 group_stop，不能审批该事项。",
            err=True,
        )
        raise typer.Exit(1)
    resource_states = dict(event.get("user_resource_states") or {})
    resource_states[reviewer_id] = {"group": group_status}
    rationales = dict(event.get("user_rationales") or {})
    rationales[reviewer_id] = rationale_path
    update_review_event(
        group_id,
        event_id,
        user_resource_states=resource_states,
        user_rationales=rationales,
    )
    return event_id


def _request_group_stop_review(
    group_id: str, group: dict, rationale: str | None
) -> None:
    """Request a group_stop review and return immediately."""
    signal_path = group_stop_signal_file(group_id)
    if signal_path.exists() or _has_open_group_stop_request(group):
        typer.echo(
            f"Group '{group_id}' 已有未结算的 group stop 审批；等待 review_result 后再决定下一轮。",
            err=True,
        )
        raise typer.Exit(1)
    signal_path.write_text(rationale or "", encoding="utf-8")
    typer.echo(
        f"你无权直接停止 group '{group_id}'；系统已上报给有权限的 reviewer 审批。等待后续 review_result。"
    )


def _reviewer_rationale_text(event: dict) -> str:
    parts: list[str] = []
    resource_states = dict(event.get("user_resource_states") or {})
    for reviewer_id, rationale_path in dict(event.get("user_rationales") or {}).items():
        reviewer_state = resource_states.get(reviewer_id)
        returned = (
            isinstance(reviewer_state, dict) and reviewer_state.get("group") == "active"
        )
        if not returned:
            continue
        rationale_text = read_mycel_home_text(
            rationale_path,
            missing_message="(rationale file not found: {path})",
            outside_message="(blocked: outside MYCEL_HOME: {path})",
        )
        parts.append(f"\n[{reviewer_id}] {rationale_text}")
    if parts:
        return "".join(parts)

    rationale_path = event.get("rationale", "")
    if not rationale_path:
        return ""
    return "\n" + read_mycel_home_text(
        rationale_path,
        missing_message="(rationale file not found: {path})",
        outside_message="(blocked: outside MYCEL_HOME: {path})",
    )


def _parse_workers_enabled_override_or_fail(
    *,
    workers_enabled: str,
    no_workers: bool,
    context_label: str,
) -> bool | None:
    if no_workers and workers_enabled:
        typer.echo(f"Cannot combine --no-workers with --{context_label}.", err=True)
        raise typer.Exit(1)
    if no_workers:
        return False
    if not workers_enabled:
        return None
    lower = workers_enabled.lower()
    if lower not in {"true", "false", "1", "0", "yes", "no"}:
        typer.echo(
            f"Invalid value '{workers_enabled}' for {context_label}. Use: true or false",
            err=True,
        )
        raise typer.Exit(1)
    return lower in {"true", "1", "yes"}


def _group_config_lines() -> list[str]:
    worker_roles = "enabled" if workers_enabled_global() else "disabled"
    base_url = effective_base_url()
    return [
        "Cel Defaults:",
        f"  {base_url_line(base_url)}",
        f"  Default Terminal: {default_terminal_global()}",
        f"  Worker Roles: {worker_roles}",
    ]


if __name__ == "__main__":
    group_app()
