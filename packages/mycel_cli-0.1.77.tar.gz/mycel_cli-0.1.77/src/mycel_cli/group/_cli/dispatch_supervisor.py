"""`cel group <group_id> supervisor ...` verb dispatch."""

from __future__ import annotations

import json

import typer

from mycel_cli.group._cli.authority import authorize_operation
from mycel_cli.group._cli.contracts import (
    build_contract_metadata,
    build_supervisor_bootstrap_prompt_v1,
    build_supervisor_contract_v1,
)
from mycel_cli.group._cli.identity_binding import require_role_identity
from mycel_cli.group._cli.identity_env import (
    build_user_env,
    resolve_current_user_session,
)
from mycel_cli.group._cli.membership import ensure_chat_member
from mycel_cli.group._cli.workflow_participants import (
    remove_keep_participant,
    sync_keep_participant_from_role,
    upsert_keep_participant,
)
from mycel_cli.group._cli.helpers import (
    dispatch_command,
    ensure_worker_online_or_fail,
    extract_named_option,
    generate_session_id,
    parse_optional_name_path_update,
    parse_worker_target_or_fail,
    reject_unknown_args,
    require_group_active,
    require_workers_enabled,
    resolve_session_id_by_prefix_or_fail,
    validate_spawn_path_or_fail,
)
from mycel_cli.group._cli import spawn as _spawn_mod
from mycel_cli.group._state.config import is_workers_enabled_for_group
from mycel_cli.group._state.groups import group_terminal_type, mutate_group
from mycel_cli.group._state.roles import (
    add_supervisor,
    find_supervisor,
    remove_supervisor,
)
from mycel_cli.daemon.wake import send_surface_hint
from mycel_cli.group.workflow_policy import OperationName


def _cmd_create(group_id: str, group: dict, payload: list[str]) -> None:
    authorize_operation(OperationName.SUPERVISOR_CREATE, group_id=group_id)
    existing = find_supervisor(group)
    if existing is not None:
        label = existing.get("name") or existing.get("session")
        typer.echo(
            f"Group already has a supervisor ({label}). "
            f"Remove it first: cel group {group_id} supervisor remove",
            err=True,
        )
        raise typer.Exit(1)
    identity_raw, rest = extract_named_option(payload, "--agent")
    name, rest = extract_named_option(rest, "--name")
    path, rest = extract_named_option(rest, "--path")
    reject_unknown_args(rest)
    identity = require_role_identity(identity_raw)
    validate_spawn_path_or_fail(path)
    ensure_chat_member(group_id, identity.local_id)
    session = generate_session_id()
    append_system_prompt = build_supervisor_contract_v1(
        workers_enabled=is_workers_enabled_for_group(group)
    )
    bootstrap_prompt = build_supervisor_bootstrap_prompt_v1(group_id, session, name)
    contract = build_contract_metadata(
        "supervisor",
        append_system_prompt,
        bootstrap_prompt,
        agent_type=identity.agent_type,
    )
    user_env = build_user_env(
        group_id=group_id,
        user_session=session,
        local_id=identity.local_id,
    )
    terminal_type = group_terminal_type(group)
    cache, _info = _spawn_mod.spawn_and_wait_for_ready(
        session,
        path,
        agent_type=identity.agent_type,
        local_id=identity.local_id,
        terminal_type=terminal_type,
        bootstrap_prompt=bootstrap_prompt,
        append_system_prompt=append_system_prompt,
        role="supervisor",
        group_id=group_id,
        user_env=user_env,
    )
    try:
        add_supervisor(
            group_id,
            session,
            cache=cache,
            name=name,
            path=path,
            contract=contract,
            agent_type=identity.agent_type,
            local_id=identity.local_id,
        )
        upsert_keep_participant(
            group_id,
            role="supervisor",
            session=session,
            name=name,
            user_id=identity.user_id,
        )
    except ValueError as exc:
        typer.echo(str(exc), err=True)
        raise typer.Exit(1)
    typer.echo(f"Supervisor '{session}' 已创建。")


def _cmd_list(group: dict) -> None:
    supervisor = find_supervisor(group)
    if supervisor is None:
        typer.echo("(无 supervisor)")
        return
    typer.echo(supervisor["session"])


def _cmd_show(group: dict, payload: list[str]) -> None:
    raw_id = payload[0] if payload else None
    resolved = _resolve_supervisor_target(group["name"], group, raw_id)
    supervisor = find_supervisor(group)
    if supervisor is None or supervisor.get("session") != resolved:
        typer.echo(f"Supervisor '{raw_id or resolved}' 不存在", err=True)
        raise typer.Exit(1)
    typer.echo(json.dumps(supervisor, ensure_ascii=False, indent=2))


def _cmd_update(group_id: str, group: dict, payload: list[str]) -> None:
    authorize_operation(OperationName.SUPERVISOR_UPDATE, group_id=group_id)
    supervisor_id, name, path = parse_optional_name_path_update(payload)
    resolved = _resolve_supervisor_target(group_id, group, supervisor_id)
    supervisor = find_supervisor(group)
    if supervisor is None or supervisor.get("session") != resolved:
        typer.echo(f"Supervisor '{supervisor_id or resolved}' 不存在", err=True)
        raise typer.Exit(1)
    updated_supervisor: dict | None = None
    with mutate_group(group_id) as locked_group:
        locked_sup = find_supervisor(locked_group)
        if locked_sup is None or locked_sup.get("session") != resolved:
            typer.echo(f"Supervisor '{supervisor_id or resolved}' 不存在", err=True)
            raise typer.Exit(1)
        if name is not None:
            locked_sup["name"] = name
        if path is not None:
            locked_sup["path"] = path
        updated_supervisor = dict(locked_sup)
    sync_keep_participant_from_role(group_id, updated_supervisor)
    typer.echo(f"Supervisor '{resolved}' 已更新。")


def _cmd_remove(group_id: str, group: dict, payload: list[str]) -> None:
    authorize_operation(OperationName.SUPERVISOR_REMOVE, group_id=group_id)
    raw_id = payload[0] if payload else None
    resolved = _resolve_supervisor_target(group_id, group, raw_id)
    supervisor = find_supervisor(group)
    if supervisor is None or supervisor.get("session") != resolved:
        typer.echo(f"Supervisor '{raw_id or resolved}' 不存在", err=True)
        raise typer.Exit(1)
    _spawn_mod.kill_and_close_worker(supervisor, group)
    remove_supervisor(group_id)
    remove_keep_participant(group_id, role="supervisor", session=resolved)
    from mycel_cli.group._workflow import memory_state

    memory_state.purge_worker(group_id, resolved)
    typer.echo(f"Supervisor '{resolved}' 已删除。")


def _cmd_wake(group_id: str, group: dict, payload: list[str]) -> None:
    require_group_active(group_id, group)
    require_workers_enabled(group_id, group, command="supervisor wake")
    worker, _ = parse_worker_target_or_fail(group, payload)
    authorize_operation(OperationName.SUPERVISOR_WAKE, group_id=group_id)
    target_worker_id = worker["session"]
    ensure_worker_online_or_fail(worker=worker, group_id=group_id, group=group)
    supervisor = find_supervisor(group)
    if supervisor is None:
        typer.echo("Supervisor not found in group", err=True)
        raise typer.Exit(1)
    chat_id = group_id
    local_id = str(worker.get("local_id") or "").strip()
    if not local_id:
        typer.echo(f"Worker '{target_worker_id}' has no local identity", err=True)
        raise typer.Exit(1)
    if not send_surface_hint(local_id, _format_worker_chat_wake(group_id, chat_id)):
        typer.echo("Worker terminal surface is not tracked", err=True)
        raise typer.Exit(1)
    typer.echo(f"已触发 worker '{target_worker_id}'。")


def _format_worker_chat_wake(group_id: str, chat_id: str) -> str:
    return (
        f"New Mycel group message from supervisor in chat {chat_id} "
        f"for group {group_id}. Read it with `cel read-message {chat_id}` "
        f'and reply with `cel send-message {chat_id}@supervisor "..."` if needed.'
    )


def dispatch(
    group_id: str, group: dict, command: str | None, payload: list[str]
) -> None:
    dispatch_command(
        command,
        {
            "create": lambda: _cmd_create(group_id, group, payload),
            "list": lambda: _cmd_list(group),
            "show": lambda: _cmd_show(group, payload),
            "update": lambda: _cmd_update(group_id, group, payload),
            "remove": lambda: _cmd_remove(group_id, group, payload),
            "wake": lambda: _cmd_wake(group_id, group, payload),
        },
    )


def _resolve_supervisor_target(group_id: str, group: dict, raw_id: str | None) -> str:
    if raw_id is not None:
        return resolve_session_id_by_prefix_or_fail(
            group=group,
            role="supervisor",
            raw_id=raw_id,
            id_label="supervisor_id",
        )
    env_session = resolve_current_user_session(group_id)
    if env_session is not None:
        supervisor = find_supervisor(group)
        if supervisor is not None and supervisor.get("session") == env_session:
            return env_session
        typer.echo(
            f"当前 user '{env_session}' 不是 group '{group_id}' 的 supervisor。",
            err=True,
        )
        raise typer.Exit(1)
    typer.echo(
        "supervisor_id is required（或在 cel 管理的 supervisor 进程中依赖环境变量自动识别）",
        err=True,
    )
    raise typer.Exit(2)
