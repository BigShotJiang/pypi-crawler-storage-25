from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import typer

from mycel_cli.group.agent_types import agent_type_from_provider
from mycel_cli.binding_resolver import BindingResolutionError, resolve_binding
from mycel_cli.identity_store import IdentityStore


@dataclass(frozen=True)
class RoleIdentity:
    local_id: str
    agent_type: str
    user_id: str


def role_record_user_id(role_record: dict) -> str:
    local_id = str(role_record.get("local_id") or "").strip()
    if not local_id:
        raise RuntimeError(
            f"group role {role_record.get('session')!r} has no Mycel identity"
        )
    identity = IdentityStore.from_env().get_identity(local_id)
    user_id = str(identity.get("user_id") or "").strip()
    if not user_id:
        raise RuntimeError(f"group role {role_record.get('session')!r} has no user_id")
    return user_id


def require_role_identity(local_id: str | None) -> RoleIdentity:
    store = IdentityStore.from_env()
    try:
        binding = resolve_binding(
            store=store,
            cwd=Path.cwd(),
            provider=None,
            interactive=False,
            local_id=local_id,
            allow_global=True,
        )
    except BindingResolutionError as exc:
        typer.echo(_role_identity_error(exc, store), err=True)
        raise typer.Exit(2)
    except RuntimeError as exc:
        typer.echo(str(exc).replace("--identity", "--agent"), err=True)
        raise typer.Exit(1)
    local_id = str(binding["local_id"])
    provider = binding.get("provider")
    if not provider:
        typer.echo(
            f"identity {local_id} has no provider tag; "
            "group roles need a provider runtime. "
            f"Create a provider-tagged identity with: cel agent external create {local_id} --provider codex --name <name>",
            err=True,
        )
        raise typer.Exit(2)
    try:
        agent_type = agent_type_from_provider(str(provider))
    except ValueError as exc:
        typer.echo(f"identity {local_id} has {str(exc).lower()}", err=True)
        raise typer.Exit(2)
    user_id = str(binding.get("user_id") or "").strip()
    if not user_id:
        typer.echo(f"identity {local_id} has no user_id", err=True)
        raise typer.Exit(2)
    return RoleIdentity(local_id=local_id, agent_type=agent_type, user_id=user_id)


def _role_identity_error(exc: BindingResolutionError, store: IdentityStore) -> str:
    identities = store.identities()
    if exc.reason == "missing" and not identities:
        return (
            "No local agent identities found. Create one with: "
            "cel agent external create <local-id> --name <name> --provider codex"
        )
    if exc.reason == "multiple":
        choices = ", ".join(exc.candidates)
        return (
            "Multiple local agent identities found. "
            f"Choose one with --agent <local-id>. Available: {choices}"
        )
    return str(exc).replace("--identity", "--agent")
