"""`cel group <group_id> task ...` verb dispatch."""

from __future__ import annotations

import json

import typer

from mycel_cli.group._cli.authority import authorize_task_operation
from mycel_cli.group._cli.constants import COMMAND_HELP
from mycel_cli.group._cli.helpers import (
    dispatch_command,
    ensure_file_in_messages_dir,
    extract_named_option,
    parse_task_selector_or_fail,
    parse_task_update_payload,
    reviewer_covers_event,
)
from mycel_cli.group._cli.identity_binding import role_record_user_id
from mycel_cli.group._cli.identity_env import current_mycel_identity
from mycel_cli.group._workflow.constants import (
    EV_TASK_PROPOSED_REVIEW,
    EV_TASK_SUBMITTED_REVIEW,
)
from mycel_cli.group._workflow.review import cancel_pending_group_stop
from mycel_cli.group._state.content import read_mycel_home_text
from mycel_cli.group._state.reviewers import (
    add_review_event,
    get_review_event,
    list_review_events,
    update_review_event,
)
from mycel_cli.group._state.tasks import (
    create_task,
    get_task,
    list_tasks,
    remove_task,
    update_tasks,
)
from mycel_cli.group._state.roles import get_role, iter_roles
from mycel_cli.group.workflow_policy import (
    ActorRole,
    OperationName,
    get_task_review_transition,
)


def _load_tasks_or_fail(group_id: str, task_ids: list[str]) -> list[dict]:
    tasks: list[dict] = []
    for task_id in task_ids:
        task = get_task(group_id, task_id)
        if task is None:
            typer.echo(f"Task '{task_id}' 不存在", err=True)
            raise typer.Exit(1)
        tasks.append(task)
    return tasks


def _ensure_no_open_review_event(group_id: str, tasks: list[dict]) -> None:
    selected_task_ids = {str(task["id"]) for task in tasks}
    for event in _open_review_events(group_id):
        event_task_ids = {str(task_id) for task_id in (event.get("task_ids") or [])}
        repeated_task_ids = selected_task_ids & event_task_ids
        if repeated_task_ids:
            task_id = sorted(repeated_task_ids)[0]
            typer.echo(
                f"Task '{task_id}' 已在 review batch '{event['id']}' 中，不能重复送审。",
                err=True,
            )
            raise typer.Exit(1)


def _load_shared_open_review_event(
    group_id: str, tasks: list[dict]
) -> tuple[str, dict]:
    selected_task_ids = {str(task["id"]) for task in tasks}
    candidates: list[dict] = []
    for event in _open_review_events(group_id):
        event_task_ids = {str(task_id) for task_id in (event.get("task_ids") or [])}
        if selected_task_ids & event_task_ids:
            candidates.append(event)
    if not candidates:
        typer.echo("这些 task 当前没有待审批事项，reviewer 不能直接行权。", err=True)
        raise typer.Exit(1)
    if len(candidates) != 1:
        typer.echo("这些 task 不属于同一个待审批 batch，不能一起审批。", err=True)
        raise typer.Exit(1)
    event_id = str(candidates[0]["id"])
    event = get_review_event(group_id, event_id)
    if event.get("final_verdict"):
        typer.echo(f"审批 batch '{event_id}' 已结算，不能重复审批。", err=True)
        raise typer.Exit(1)
    event_task_ids = {str(task_id) for task_id in (event.get("task_ids") or [])}
    if not selected_task_ids.issubset(event_task_ids):
        typer.echo(f"选中的 task 不属于审批 batch '{event_id}'。", err=True)
        raise typer.Exit(1)
    return event_id, event


def _open_review_events(group_id: str) -> list[dict]:
    return [
        event
        for event in list_review_events(group_id)
        if event.get("task_ids") and not event.get("final_verdict")
    ]


def _resolve_owner_for_backend(group: dict, owner: str) -> str:
    raw = owner.strip()
    if not raw:
        return raw
    users = iter_roles(group)
    exact = [user for user in users if str(user.get("session") or "") == raw]
    if exact:
        return role_record_user_id(exact[0])
    prefixed = [
        user for user in users if str(user.get("session") or "").startswith(raw)
    ]
    if len(prefixed) == 1:
        return role_record_user_id(prefixed[0])
    if len(prefixed) > 1:
        typer.echo(f"owner '{owner}' 匹配多个 group user session。", err=True)
        raise typer.Exit(1)
    return raw


def _record_reviewer_task_decision(
    group_id: str,
    reviewer_id: str,
    tasks: list[dict],
    *,
    target_status: str,
    rationale_path: str | None,
) -> str:
    event_id, event = _load_shared_open_review_event(group_id, tasks)
    event_type = str(event.get("type") or "")
    allowed_states_by_event = {
        EV_TASK_PROPOSED_REVIEW: {"pending", "proposed"},
        EV_TASK_SUBMITTED_REVIEW: {"completed", "in_progress"},
    }
    allowed_states = allowed_states_by_event.get(event_type)
    if allowed_states is None:
        typer.echo(f"审批 batch '{event_id}' 不是 task 审批类型。", err=True)
        raise typer.Exit(1)
    if target_status not in allowed_states:
        typer.echo(
            f"审批 batch '{event_id}' 只允许 reviewer 提交 {', '.join(sorted(allowed_states))}，"
            f"不能提交 {target_status}。",
            err=True,
        )
        raise typer.Exit(1)

    reviewer = get_role(group_id, reviewer_id, role="reviewer")
    if not reviewer_covers_event(reviewer, event_type):
        typer.echo(
            f"reviewer '{reviewer_id[:8]}' 未覆盖 {event_type}，不能审批该 batch。",
            err=True,
        )
        raise typer.Exit(1)

    resource_states = dict(event.get("user_resource_states") or {})
    existing_states = dict(resource_states.get(reviewer_id) or {})
    existing_states.update({str(task["id"]): target_status for task in tasks})
    resource_states[reviewer_id] = existing_states
    update_kwargs = {
        "user_resource_states": resource_states,
    }
    if rationale_path:
        rationales = dict(event.get("user_rationales") or {})
        rationales[reviewer_id] = rationale_path
        update_kwargs["user_rationales"] = rationales
    update_review_event(
        group_id,
        event_id,
        **update_kwargs,
    )
    return event_id


def _maybe_requested_by(group_id: str) -> str | None:
    ident = current_mycel_identity()
    if ident.group_id != group_id:
        return None
    return ident.user_session


def _create_review_event_for_batch(
    group_id: str,
    task_ids: list[str],
    tasks: list[dict],
    *,
    event_type: str,
    rationale_path: str,
) -> str:
    event_data: dict[str, object] = {
        "type": event_type,
        "task_ids": task_ids,
        "task_subjects": [f"#{task['id']} {task.get('subject', '')}" for task in tasks],
        "rationale": rationale_path,
        "user_resource_states": {},
    }
    requested_by = _maybe_requested_by(group_id)
    if requested_by:
        event_data["requested_by"] = requested_by
    event_id = add_review_event(group_id, event_data)
    update_review_event(group_id, event_id, batch_id=event_id)
    return event_id


def _cmd_create(group_id: str, group: dict, payload: list[str]) -> None:
    if payload and payload[0] in {"-h", "--help"}:
        typer.echo(COMMAND_HELP["task"]["create"])
        raise typer.Exit()
    if not payload:
        typer.echo("Task subject is required", err=True)
        raise typer.Exit(2)
    if len(payload) > 1:
        typer.echo(
            "Unexpected arguments for task create. Usage: cel group <group_id> task create <subject>",
            err=True,
        )
        raise typer.Exit(2)
    authorize_task_operation(
        group_id,
        group,
        operation=OperationName.TASK_CREATE,
    )
    task = create_task(group_id, subject=payload[0])
    cancel_pending_group_stop(group_id)
    typer.echo(f"Task '{task['id']}' created: {task['subject']}")


def _cmd_update(group_id: str, group: dict, payload: list[str]) -> None:
    task_ids, patch, rationale_file_raw = parse_task_update_payload(payload)
    if patch.get("owner"):
        patch = dict(patch)
        patch["owner"] = _resolve_owner_for_backend(group, str(patch["owner"]))
    tasks = _load_tasks_or_fail(group_id, task_ids)

    target_status = patch.get("status")
    review_transition = get_task_review_transition(
        str(target_status) if target_status is not None else None
    )
    decision = authorize_task_operation(
        group_id,
        group,
        operation=OperationName.TASK_UPDATE,
        target_status=str(target_status) if target_status is not None else None,
        needs_review=bool(rationale_file_raw),
        tasks=tasks,
        patch_keys=set(patch),
    )
    actor = decision.actor

    if actor.role == ActorRole.REVIEWER:
        if target_status is None:
            typer.echo("reviewer 的 task update 必须指定 --status。", err=True)
            raise typer.Exit(2)
        rationale_path = None
        if rationale_file_raw is not None:
            rationale_path = str(
                ensure_file_in_messages_dir(
                    group,
                    rationale_file_raw,
                    label="rationale file",
                    record_index=True,
                )
            )
        event_id = _record_reviewer_task_decision(
            group_id,
            str(actor.user_session or ""),
            tasks,
            target_status=str(target_status),
            rationale_path=str(rationale_path or ""),
        )
        ids_str = ", ".join(f"#{task_id}" for task_id in task_ids)
        typer.echo(
            f"审批已记录：{ids_str} -> {target_status}（batch {event_id}）。等待结算。"
        )
        return

    needs_review = review_transition is not None and rationale_file_raw is not None
    review_target_status = (
        review_transition.target_status.value if review_transition is not None else None
    )
    if review_target_status is not None and rationale_file_raw is None:
        typer.echo(f"--status {target_status} requires --rationale <file>", err=True)
        raise typer.Exit(2)
    if review_target_status is None and rationale_file_raw is not None:
        typer.echo(
            "--rationale is only allowed with --status pending|completed", err=True
        )
        raise typer.Exit(2)
    if needs_review:
        _ensure_no_open_review_event(group_id, tasks)

    rationale_path: str | None = None
    if rationale_file_raw is not None:
        rationale_path = str(
            ensure_file_in_messages_dir(
                group,
                rationale_file_raw,
                label="rationale file",
                record_index=True,
            )
        )

    patch_to_apply = dict(patch)
    if needs_review:
        patch_to_apply.pop("status", None)
    if patch_to_apply:
        update_tasks(group_id, task_ids, patch_to_apply)

    event_id: str | None = None
    if needs_review:
        event_id = _create_review_event_for_batch(
            group_id,
            task_ids,
            _load_tasks_or_fail(group_id, task_ids),
            event_type=review_transition.review_event_type.value,
            rationale_path=str(rationale_path),
        )

    cancel_pending_group_stop(group_id)
    ids_str = ", ".join(f"#{task_id}" for task_id in task_ids)
    if event_id is not None:
        typer.echo(
            f"你无权直接将 {ids_str} 更新为 {target_status}；"
            f"系统已上报给有权限的 reviewer 审批（batch {event_id}）。"
        )
        return
    typer.echo(f"Tasks updated: {ids_str}")


def _cmd_remove(group_id: str, group: dict, payload: list[str]) -> None:
    task_ids, rest = parse_task_selector_or_fail(payload)
    if rest:
        typer.echo(f"Unexpected argument '{rest[0]}'", err=True)
        raise typer.Exit(2)
    authorize_task_operation(
        group_id,
        group,
        operation=OperationName.TASK_REMOVE,
    )
    _load_tasks_or_fail(group_id, task_ids)
    for task_id in task_ids:
        remove_task(group_id, task_id)
    cancel_pending_group_stop(group_id)
    typer.echo(f"Tasks removed: {', '.join(f'#{task_id}' for task_id in task_ids)}")


def _cmd_list(group_id: str, payload: list[str]) -> None:
    if payload and payload[0] in {"-h", "--help"}:
        typer.echo(COMMAND_HELP["task"]["list"])
        raise typer.Exit()
    task_ids, rest = parse_task_selector_or_fail(
        payload, allow_missing=True, allow_positional=True
    )
    status_filter, rest = extract_named_option(rest, "--status")
    if rest:
        option = rest[0]
        if option.startswith("--"):
            typer.echo(f"No such option '{option}'", err=True)
        else:
            typer.echo(f"Unexpected argument '{option}'", err=True)
        raise typer.Exit(2)

    selected_ids = set(task_ids)
    tasks = list_tasks(group_id)
    if task_ids:
        tasks = [task for task in tasks if str(task["id"]) in selected_ids]
    if status_filter:
        tasks = [task for task in tasks if task.get("status") == status_filter]
    if not tasks:
        typer.echo("(无 task)")
        return
    typer.echo(
        "\n".join(
            f"#{task['id']} [{task['status']}] {task['subject']}" for task in tasks
        )
    )


def _cmd_show(group_id: str, payload: list[str]) -> None:
    if payload and payload[0] in {"-h", "--help"}:
        typer.echo(COMMAND_HELP["task"]["show"])
        raise typer.Exit()
    task_ids, rest = parse_task_selector_or_fail(payload, allow_positional=True)
    if rest:
        typer.echo(f"Unexpected argument '{rest[0]}'", err=True)
        raise typer.Exit(2)
    tasks = _load_tasks_or_fail(group_id, task_ids)
    if len(tasks) == 1:
        typer.echo(json.dumps(tasks[0], ensure_ascii=False, indent=2))
        return
    typer.echo(json.dumps(tasks, ensure_ascii=False, indent=2))


def dispatch(
    group_id: str, group: dict, command: str | None, payload: list[str]
) -> None:
    dispatch_command(
        command,
        {
            "create": lambda: _cmd_create(group_id, group, payload),
            "update": lambda: _cmd_update(group_id, group, payload),
            "remove": lambda: _cmd_remove(group_id, group, payload),
            "list": lambda: _cmd_list(group_id, payload),
            "show": lambda: _cmd_show(group_id, payload),
        },
    )


def _reviewer_rationale_text(event: dict) -> str:
    parts: list[str] = []
    resource_states = dict(event.get("user_resource_states") or {})
    return_state = {
        EV_TASK_PROPOSED_REVIEW: "proposed",
        EV_TASK_SUBMITTED_REVIEW: "in_progress",
    }.get(event.get("type"))
    for reviewer_id, rationale_path in dict(event.get("user_rationales") or {}).items():
        rejected = False
        reviewer_states = resource_states.get(reviewer_id)
        if isinstance(reviewer_states, dict) and return_state:
            rejected = any(state == return_state for state in reviewer_states.values())
        if not rejected:
            continue
        rationale_text = read_mycel_home_text(
            rationale_path,
            missing_message="(rationale file not found: {path})",
            outside_message="(blocked: outside MYCEL_HOME: {path})",
        )
        parts.append(f"\n[{reviewer_id}] {rationale_text}")
    if parts:
        return "".join(parts)

    rationale_path = event.get("rationale", "")
    if not rationale_path:
        return ""
    return "\n" + read_mycel_home_text(
        rationale_path,
        missing_message="(rationale file not found: {path})",
        outside_message="(blocked: outside MYCEL_HOME: {path})",
    )
