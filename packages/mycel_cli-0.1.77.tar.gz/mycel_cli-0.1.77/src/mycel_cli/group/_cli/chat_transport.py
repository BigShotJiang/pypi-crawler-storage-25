"""Thin Mycel chat transport adapter for group-scoped messages."""

from __future__ import annotations

from mycel_sdk import Client

from mycel_cli.config import client_kwargs, effective_proxy
from mycel_cli.identity_store import IdentityStore


def group_chat_for(*, group_id: str, sender_local_id: str) -> tuple[Client, str]:
    source_identity = IdentityStore.from_env().get_identity(sender_local_id)
    client = Client(
        **client_kwargs(
            auth_token=str(source_identity["auth_token"]),
            base_url=str(source_identity["base_url"]),
            proxy=_proxy(),
        )
    )
    return client, group_id


def owner_chat_for(*, group_id: str) -> tuple[Client, str]:
    owner = IdentityStore.from_env().current_user()
    client = Client(
        **client_kwargs(
            auth_token=str(owner["auth_token"]),
            base_url=str(owner["base_url"]),
            proxy=_proxy(),
        )
    )
    return client, group_id


def _proxy() -> str | None:
    proxy = effective_proxy()["proxy"]
    return str(proxy) if proxy else None
