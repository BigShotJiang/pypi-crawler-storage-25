from __future__ import annotations

from collections.abc import Iterator
from contextlib import contextmanager
import json
import os
from pathlib import Path
import threading
import time
from typing import Any

from mycel_cli.daemon import paths as daemon_paths


class IdentityStore:
    def __init__(self, root: Path) -> None:
        self.root = root
        self._lock_depth = 0

    @classmethod
    def from_env(cls) -> IdentityStore:
        return cls(daemon_paths.mycel_home())

    def _read(self, name: str, default: dict[str, Any]) -> dict[str, Any]:
        path = self.root / name
        if not path.exists():
            return default
        text = path.read_text(encoding="utf-8").strip()
        if not text:
            return default
        return dict(json.loads(text))

    def _write(self, name: str, payload: dict[str, Any]) -> None:
        self.root.mkdir(parents=True, exist_ok=True)
        self.root.chmod(0o700)
        path = self.root / name
        text = json.dumps(payload, ensure_ascii=False, indent=2) + "\n"
        tmp = path.with_name(f".{path.name}.{os.getpid()}.{threading.get_ident()}.tmp")
        tmp.write_text(text, encoding="utf-8")
        tmp.chmod(0o600)
        os.replace(tmp, path)
        path.chmod(0o600)

    @contextmanager
    def _locked(self) -> Iterator[None]:
        # @@@identity-store-lock - Serialize local JSON read-modify-write across CLI processes.
        if self._lock_depth:
            yield
            return
        self.root.mkdir(parents=True, exist_ok=True)
        self.root.chmod(0o700)
        lock_path = self.root / ".store.lock"
        deadline = time.monotonic() + 10
        while True:
            try:
                fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
            except FileExistsError:
                if time.monotonic() >= deadline:
                    raise RuntimeError("timed out waiting for local Mycel store lock")
                time.sleep(0.05)
                continue
            try:
                os.write(fd, str(os.getpid()).encode("ascii"))
            finally:
                os.close(fd)
            break
        self._lock_depth = 1
        try:
            yield
        finally:
            self._lock_depth = 0
            try:
                lock_path.unlink()
            except FileNotFoundError:
                pass

    def save_user(self, user_id: str, *, base_url: str, auth_token: str) -> None:
        with self._locked():
            payload = self._read("users.json", {"current_user_id": None, "users": {}})
            payload.setdefault("users", {})[user_id] = {
                "base_url": base_url,
                "auth_token": auth_token,
            }
            payload["current_user_id"] = user_id
            self._write("users.json", payload)

    def current_user_id(self) -> str | None:
        payload = self._read("users.json", {"current_user_id": None, "users": {}})
        current = payload.get("current_user_id")
        return str(current) if current else None

    def current_user(self) -> dict[str, Any]:
        user_id = self.current_user_id()
        if user_id is None:
            raise RuntimeError(
                "no owner login; run `cel login --guest` or `cel login <email-or-username>` first"
            )
        payload = self._read("users.json", {"current_user_id": None, "users": {}})
        users = payload.get("users") or {}
        if user_id not in users:
            raise RuntimeError(f"owner login not found: {user_id}")
        return {"user_id": user_id, **dict(users[user_id])}

    def clear_current_user(self) -> None:
        with self._locked():
            payload = self._read("users.json", {"current_user_id": None, "users": {}})
            payload["current_user_id"] = None
            self._write("users.json", payload)

    def clear_users(self) -> None:
        with self._locked():
            self._write("users.json", {"current_user_id": None, "users": {}})

    def save_identity(
        self,
        *,
        local_id: str,
        provider: str | None,
        base_url: str,
        auth_token: str,
        user_id: str,
        display_name: str,
        created_by_user_id: str | None,
    ) -> None:
        with self._locked():
            payload = self._read("identities.json", {"identities": {}})
            identity = {
                "base_url": base_url,
                "auth_token": auth_token,
                "user_id": user_id,
                "display_name": display_name,
                "created_by_user_id": created_by_user_id,
            }
            if provider:
                identity["provider"] = provider
            payload.setdefault("identities", {})[local_id] = identity
            self._write("identities.json", payload)

    def identities(self) -> dict[str, dict[str, Any]]:
        payload = self._read("identities.json", {"identities": {}})
        return dict(payload.get("identities") or {})

    def get_identity(self, local_id: str) -> dict[str, Any]:
        identities = self.identities()
        if local_id not in identities:
            raise RuntimeError(f"identity not found: {local_id}")
        return dict(identities[local_id])

    def update_identity(self, local_id: str, **updates: Any) -> dict[str, Any]:
        with self._locked():
            payload = self._read("identities.json", {"identities": {}})
            identities = payload.setdefault("identities", {})
            if local_id not in identities:
                raise RuntimeError(f"identity not found: {local_id}")
            identities[local_id].update(updates)
            self._write("identities.json", payload)
            return dict(identities[local_id])

    def public_identity(self, local_id: str) -> dict[str, Any]:
        payload = self.get_identity(local_id)
        public = {
            "local_id": local_id,
            "base_url": payload["base_url"],
            "auth_token": "<redacted>" if payload.get("auth_token") else "",
            "display_name": payload["display_name"],
            "created_by_user_id": payload["created_by_user_id"],
        }
        if payload.get("provider"):
            public["provider"] = payload["provider"]
        if "user_id" in payload:
            public["user_id"] = payload["user_id"]
        return public

    def public_identities(self) -> list[dict[str, Any]]:
        return [
            self.public_identity(local_id) for local_id in sorted(self.identities())
        ]

    def remove_identity(self, local_id: str) -> dict[str, Any]:
        with self._locked():
            payload = self._read("identities.json", {"identities": {}})
            identities = payload.setdefault("identities", {})
            if local_id not in identities:
                raise RuntimeError(f"identity not found: {local_id}")
            removed = dict(identities.pop(local_id))
            self._write("identities.json", payload)
            self._remove_cwd_identity(local_id)
            self._remove_identity_artifacts(local_id)
            return {"local_id": local_id, **removed}

    def add_cwd_identity(self, cwd: Path, local_id: str) -> None:
        with self._locked():
            payload = self._read("cwd-index.json", {"cwd_identities": {}})
            cwd_identities = payload.setdefault("cwd_identities", {})
            key = str(cwd.resolve())
            items = list(cwd_identities.get(key) or [])
            if local_id not in items:
                items.append(local_id)
            cwd_identities[key] = items
            self._write("cwd-index.json", payload)

    def cwd_identities(self, cwd: Path) -> list[str]:
        with self._locked():
            payload = self._read("cwd-index.json", {"cwd_identities": {}})
            cwd_identities = payload.get("cwd_identities") or {}
            key = str(cwd.resolve())
            items = list(cwd_identities.get(key) or [])
            live_ids = set(self.identities())
            live_items = [local_id for local_id in items if local_id in live_ids]
            if live_items != items:
                cwd_identities[key] = live_items
                payload["cwd_identities"] = cwd_identities
                self._write("cwd-index.json", payload)
            return live_items

    def unbind_cwd_identity(self, cwd: Path, local_id: str) -> bool:
        with self._locked():
            payload = self._read("cwd-index.json", {"cwd_identities": {}})
            cwd_identities = payload.get("cwd_identities") or {}
            key = str(cwd.resolve())
            items = list(cwd_identities.get(key) or [])
            kept = [item for item in items if item != local_id]
            if kept == items:
                return False
            if kept:
                cwd_identities[key] = kept
            else:
                cwd_identities.pop(key, None)
            payload["cwd_identities"] = cwd_identities
            self._write("cwd-index.json", payload)
            return True

    def cleanup_local_identity_state(self) -> dict[str, Any]:
        with self._locked():
            live_ids = set(self.identities())
            removed_cwd_bindings = self._remove_missing_cwd_identities(live_ids)
            removed_artifacts = self._remove_orphan_identity_artifacts(live_ids)
            return {
                "removed_artifacts": removed_artifacts,
                "removed_cwd_bindings": removed_cwd_bindings,
            }

    def _remove_cwd_identity(self, local_id: str) -> None:
        payload = self._read("cwd-index.json", {"cwd_identities": {}})
        cwd_identities = payload.get("cwd_identities") or {}
        changed = False
        for key, items in list(cwd_identities.items()):
            kept = [item for item in list(items or []) if item != local_id]
            if kept != list(items or []):
                changed = True
            if kept:
                cwd_identities[key] = kept
            else:
                cwd_identities.pop(key, None)
        if changed:
            payload["cwd_identities"] = cwd_identities
            self._write("cwd-index.json", payload)

    def _remove_missing_cwd_identities(
        self, live_ids: set[str]
    ) -> list[dict[str, str]]:
        payload = self._read("cwd-index.json", {"cwd_identities": {}})
        cwd_identities = payload.get("cwd_identities") or {}
        removed: list[dict[str, str]] = []
        changed = False
        for key, items in list(cwd_identities.items()):
            kept = []
            for item in list(items or []):
                if item in live_ids:
                    kept.append(item)
                else:
                    removed.append({"local_id": str(item), "path": str(Path(key))})
                    changed = True
            if kept:
                cwd_identities[key] = kept
            else:
                cwd_identities.pop(key, None)
        if changed:
            payload["cwd_identities"] = cwd_identities
            self._write("cwd-index.json", payload)
        return sorted(removed, key=lambda item: (item["path"], item["local_id"]))

    def _remove_identity_artifacts(self, local_id: str) -> list[str]:
        paths = [
            self.root / "inbox" / f"{local_id}.jsonl",
            self.root / "inbox" / f"{local_id}.cursor",
            self.root / "run" / f"subscriber-{local_id}.json",
            self.root / "run" / f"subscriber-{local_id}.json.tmp",
            self.root / "run" / f"subscriber-{local_id}.watermark.json",
        ]
        return self._unlink_existing(paths)

    def _remove_orphan_identity_artifacts(self, live_ids: set[str]) -> list[str]:
        paths: list[Path] = []
        inbox = self.root / "inbox"
        for path in sorted(inbox.glob("*")) if inbox.exists() else []:
            local_id = _inbox_artifact_identity(path)
            if local_id and local_id not in live_ids:
                paths.append(path)
        run = self.root / "run"
        for path in sorted(run.glob("subscriber-*")) if run.exists() else []:
            local_id = _subscriber_artifact_identity(path)
            if local_id and local_id not in live_ids:
                paths.append(path)
        return self._unlink_existing(paths)

    def _unlink_existing(self, paths: list[Path]) -> list[str]:
        removed: list[str] = []
        for path in sorted(set(paths)):
            if not path.is_file():
                continue
            path.unlink()
            removed.append(path.relative_to(self.root).as_posix())
        return removed


def _inbox_artifact_identity(path: Path) -> str | None:
    if path.suffix not in {".jsonl", ".cursor"}:
        return None
    return path.name[: -len(path.suffix)]


def _subscriber_artifact_identity(path: Path) -> str | None:
    name = path.name
    if not name.startswith("subscriber-"):
        return None
    tail = name.removeprefix("subscriber-")
    for suffix in (".watermark.json", ".json.tmp", ".json"):
        if tail.endswith(suffix):
            return tail[: -len(suffix)]
    return None
