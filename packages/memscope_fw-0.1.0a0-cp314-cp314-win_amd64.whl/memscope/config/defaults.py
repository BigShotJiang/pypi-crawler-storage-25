"""Default configuration values for MemScope."""

from __future__ import annotations

from copy import deepcopy
from typing import TypeAlias

ConfigScalar: TypeAlias = str | int | float | bool | None
ConfigValue: TypeAlias = ConfigScalar | list["ConfigValue"] | dict[str, "ConfigValue"]
ConfigDict: TypeAlias = dict[str, ConfigValue]

DEFAULT_CONFIG: ConfigDict = {
    "project": {
        "name": None,
        "toolchain": None,
    },
    "inputs": {
        "elf": None,
        "map": None,
        "linker": None,
    },
    "reports": {
        "html": None,
        "json": None,
        "csv": None,
        "enable_sankey_view": False,
        "enable_relationship_graph_view": False,
    },
    "budgets": {
        "flash": {},
        "ram": {},
    },
    "policies": {
        "fail_on_overflow": True,
        "fail_on_reserved_region_violation": True,
        "warn_on_large_bss_symbol_kb": 8,
        "warn_on_near_capacity_ratio": 0.9,
        "max_ram_growth_bytes": None,
        "max_flash_growth_bytes": None,
        "partition_max_bytes": {},
        "ota_source_regions": [],
        "ota_slot_a_max_bytes": None,
        "ota_slot_b_max_bytes": None,
        "ota_warn_ratio": 0.9,
        "dma_section_patterns": [],
        "dma_safe_regions": [],
        "non_cacheable_section_patterns": [],
        "non_cacheable_regions": [],
        "cacheable_section_patterns": [],
        "cacheable_regions": [],
        "retention_section_patterns": [],
        "retention_regions": [],
        "forbidden_component_regions": {},
        "suppress_issue_ids": [],
        "suppress_issue_prefixes": [],
        "suppress_categories": [],
    },
    "groups": {},
    "telemetry": {
        "enabled": False,
        "endpoint": None,
        "emit_command_usage": False,
        "emit_crash_reports": False,
    },
}


def get_default_config() -> ConfigDict:
    """Return a deep copy of default config values."""
    return deepcopy(DEFAULT_CONFIG)
