"""Budget and near-capacity rule evaluator."""

from __future__ import annotations

from memscope.domain import Issue, IssueCategory, IssueSeverity
from memscope.rules.base import RuleContext, RuleEvaluation


class BudgetThresholdRule:
    """Evaluate overflow, configured budgets, and near-capacity thresholds."""

    rule_id = "budget_thresholds"
    description = "Checks region overflow and capacity thresholds."

    def evaluate(self, context: RuleContext) -> RuleEvaluation:
        issues: list[Issue] = []
        existing_ids = {issue.id for issue in context.report.issues}
        utilization = context.report.summary.utilization_by_region
        near_capacity_ratio = context.config.policies.warn_on_near_capacity_ratio

        configured_budgets: dict[str, float] = {}
        configured_budgets.update(context.config.budgets.flash)
        configured_budgets.update(context.config.budgets.ram)

        for region_name, ratio in sorted(utilization.items()):
            overflow_issue_id = f"overflow.{region_name}"
            if ratio > 1.0 and overflow_issue_id not in existing_ids:
                issues.append(
                    Issue(
                        id=overflow_issue_id,
                        severity=IssueSeverity.ERROR,
                        category=IssueCategory.OVERFLOW,
                        title="Region overflow detected",
                        description=(
                            f"Region {region_name} utilization ratio is {ratio:.3f}, above 1.000."
                        ),
                        affected_entities=(region_name,),
                        remediation_hint="Reduce section usage or increase region capacity.",
                    )
                )

            budget_ratio = configured_budgets.get(region_name)
            budget_issue_id = f"budget.{region_name}"
            if budget_ratio is not None and ratio > budget_ratio and budget_issue_id not in existing_ids:
                issues.append(
                    Issue(
                        id=budget_issue_id,
                        severity=IssueSeverity.WARNING,
                        category=IssueCategory.POLICY,
                        title="Region budget threshold exceeded",
                        description=(
                            f"Region {region_name} utilization is {ratio:.3f}, "
                            f"above configured budget {budget_ratio:.3f}."
                        ),
                        affected_entities=(region_name,),
                        remediation_hint="Rebalance footprint or intentionally adjust the budget.",
                    )
                )

            if (
                near_capacity_ratio is not None
                and ratio <= 1.0
                and ratio >= near_capacity_ratio
                and f"near_capacity.{region_name}" not in existing_ids
                and budget_issue_id not in existing_ids
            ):
                issues.append(
                    Issue(
                        id=f"near_capacity.{region_name}",
                        severity=IssueSeverity.WARNING,
                        category=IssueCategory.POLICY,
                        title="Region near capacity",
                        description=(
                            f"Region {region_name} utilization is {ratio:.3f}, "
                            f"near configured threshold {near_capacity_ratio:.3f}."
                        ),
                        affected_entities=(region_name,),
                        remediation_hint="Monitor growth or tighten optimization for this region.",
                    )
                )

        return RuleEvaluation(rule_id=self.rule_id, issues=issues)

