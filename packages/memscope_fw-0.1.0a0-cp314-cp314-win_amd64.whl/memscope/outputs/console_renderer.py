"""Terminal-oriented summary renderer."""

from __future__ import annotations

from collections.abc import Mapping
from datetime import UTC, datetime

from memscope.domain import AnalysisReport

# Days-out threshold below which the renewal-reminder banner fires.
RENEWAL_REMINDER_DAYS = 14


def render_console_summary(
    report: AnalysisReport,
    *,
    blocking: bool,
    output_paths: Mapping[str, str | None] | None = None,
    suppress_renewal_reminder: bool = False,
    now: datetime | None = None,
) -> str:
    summary = report.summary
    issue_counts = {
        "error": int(summary.issue_counts.get("error", 0)),
        "warning": int(summary.issue_counts.get("warning", 0)),
        "info": int(summary.issue_counts.get("info", 0)),
    }

    lines = [
        "MemScope Analysis Summary",
        f"Target: {report.metadata.target_name or 'unknown'}",
        f"Toolchain: {report.metadata.toolchain_detected or 'unknown'}",
        f"License: {_license_banner(report)}",
    ]
    if not suppress_renewal_reminder:
        reminder = _renewal_reminder(report, now=now)
        if reminder is not None:
            lines.append(reminder)
    lines.extend([
        f"Total FLASH: {summary.total_flash} B",
        f"Total RAM: {summary.total_ram} B",
        (
            "Issues: "
            f"error={issue_counts['error']} "
            f"warning={issue_counts['warning']} "
            f"info={issue_counts['info']}"
        ),
        f"Blocking Policy: {'yes' if blocking else 'no'}",
    ])

    multicore = summary.extra.get("multicore")
    cores: list[str] = []
    if isinstance(multicore, dict):
        cores_value = multicore.get("cores")
        if isinstance(cores_value, list):
            cores = sorted({str(core) for core in cores_value if str(core).strip()})
    if cores:
        lines.append(f"Cores Detected: {len(cores)} ({', '.join(cores)})")
    else:
        lines.append("Cores Detected: 1 (single-core; no per-core region partitioning found)")

    top_regions = _top_regions(summary.utilization_by_region)
    if top_regions:
        lines.append("Top Region Utilization:")
        lines.extend(top_regions)

    regressions = report.regressions
    status = regressions.get("status")
    if isinstance(status, str):
        lines.append(f"Baseline Diff: {status}")
        if status == "ok":
            flash_delta = regressions.get("flash_delta_bytes", 0)
            ram_delta = regressions.get("ram_delta_bytes", 0)
            lines.append(f"- flash_delta_bytes: {flash_delta}")
            lines.append(f"- ram_delta_bytes: {ram_delta}")

            top_regressions = regressions.get("top_regressions")
            if isinstance(top_regressions, list) and top_regressions:
                lines.append("Top Regressions:")
                for item in top_regressions[:3]:
                    if isinstance(item, dict):
                        lines.append(
                            f"- {item.get('kind')}:{item.get('name')} delta={item.get('delta')}"
                        )

    if output_paths:
        rendered_paths = [
            (name, path)
            for name, path in sorted(output_paths.items())
            if path is not None
        ]
        if rendered_paths:
            lines.append("Report Outputs:")
            for name, path in rendered_paths:
                lines.append(f"- {name}: {path}")

    return "\n".join(lines)


def _license_banner(report: AnalysisReport) -> str:
    """One-line license summary for the console header.

    Reads from ``report.diagnostics["license"]`` (populated by
    ``SessionManager._apply_license_status``) so the banner stays consistent
    with the JSON diagnostics block; falls back to the metadata mode string
    when the diagnostics block is absent (e.g., legacy reports).
    """
    license_block = report.diagnostics.get("license")
    if isinstance(license_block, dict):
        state = str(license_block.get("state") or "").strip().lower()
        message = str(license_block.get("message") or "").strip()
        expires_at = str(license_block.get("expires_at") or "").strip()
        if state == "trial" and message:
            return message
        if state == "free":
            # Devolved-from-trial state: visibility-only, no time limit.
            # See docs/LICENSING_STATE_MACHINE.md.
            return (
                "Free Edition - paid features locked "
                "(run `memscope license activate <KEY>` for CI gating)"
            )
        if state == "expired":
            tail = f" (was {expires_at})" if expires_at else ""
            return (
                f"EXPIRED{tail} - run `memscope license activate <KEY>` to continue"
            )
        if state == "active":
            return "Active"
        if state == "offline-valid":
            return "Active (offline)"
        if state == "developer-mode":
            return "Developer mode (license checks bypassed)"
        if state == "invalid":
            return "INVALID - cached license is not usable"
        if state == "revoked":
            return "REVOKED - contact your license administrator"
        if state:
            return state
    mode = report.metadata.license_mode or "standard"
    return mode


def _renewal_reminder(report: AnalysisReport, *, now: datetime | None = None) -> str | None:
    """Return a single-line renewal-reminder banner when warranted.

    Fires only for paid states (``active`` / ``offline-valid``) when the
    license expiry is between 0 and ``RENEWAL_REMINDER_DAYS`` days away.
    Returns ``None`` for trial (handled by the License banner already),
    expired/invalid/revoked (the License banner is loud enough), developer
    mode, or licenses with more headroom than the threshold.
    """
    block = report.diagnostics.get("license") if isinstance(report.diagnostics, dict) else None
    if not isinstance(block, dict):
        return None
    state = str(block.get("state") or "").strip().lower()
    if state not in {"active", "offline-valid"}:
        return None

    expires_at_raw = block.get("expires_at")
    if not isinstance(expires_at_raw, str) or not expires_at_raw.strip():
        return None
    try:
        expires_at = datetime.fromisoformat(expires_at_raw.strip())
    except ValueError:
        return None
    if expires_at.tzinfo is None:
        expires_at = expires_at.replace(tzinfo=UTC)

    current = now if now is not None else datetime.now(UTC)
    delta = expires_at - current
    days_remaining = delta.days
    if days_remaining < 0 or days_remaining > RENEWAL_REMINDER_DAYS:
        return None

    expiry_label = expires_at_raw.split("T", 1)[0] if "T" in expires_at_raw else expires_at_raw
    if days_remaining == 0:
        return f"Renewal: license expires today ({expiry_label}). Renew now to avoid interruption."
    plural = "" if days_remaining == 1 else "s"
    return (
        f"Renewal: license expires in {days_remaining} day{plural} ({expiry_label}). "
        "Contact your reseller to renew."
    )


def _top_regions(utilization_by_region: dict[str, float]) -> list[str]:
    ranked = sorted(
        utilization_by_region.items(),
        key=lambda item: (item[1], item[0]),
        reverse=True,
    )
    lines: list[str] = []
    for region_name, ratio in ranked[:5]:
        lines.append(f"- {region_name}: {ratio * 100:.1f}%")
    return lines
