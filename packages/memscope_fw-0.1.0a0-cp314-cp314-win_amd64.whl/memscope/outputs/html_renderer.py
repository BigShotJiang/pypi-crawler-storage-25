"""Self-contained HTML renderer for offline report viewing."""

from __future__ import annotations

import json
import re
from pathlib import Path
from typing import Any

from jinja2 import Environment, select_autoescape

from memscope.domain import AnalysisReport
from memscope.licensing.labels import chip_css_for, chip_label_for
from memscope.outputs.frontend_runtime import bundled_runtime_assets
from memscope.outputs.pathing import ensure_parent_dir

_ENV = Environment(
    autoescape=select_autoescape(enabled_extensions=("html", "xml"), default=True),
    trim_blocks=True,
    lstrip_blocks=True,
)


def _intcomma(value: object) -> str:
    if isinstance(value, bool):
        return str(value)
    if isinstance(value, int):
        return f"{value:,}"
    if isinstance(value, float):
        if not value.is_integer():
            return f"{value:,.2f}".rstrip("0").rstrip(".")
        return f"{int(value):,}"
    text = str(value).strip()
    if not text:
        return "0"
    if re.fullmatch(r"[+-]?\d+", text):
        try:
            return f"{int(text):,}"
        except ValueError:
            return text
    if re.fullmatch(r"[+-]?\d+\.0+", text):
        try:
            return f"{int(float(text)):,}"
        except ValueError:
            return text
    return text


def _signed_intcomma(value: object) -> str:
    if isinstance(value, bool):
        return str(value)
    if isinstance(value, int):
        sign = "+" if value > 0 else ""
        return f"{sign}{value:,}"
    if isinstance(value, float):
        normalized = int(value)
        sign = "+" if normalized > 0 else ""
        return f"{sign}{normalized:,}"
    text = str(value).strip()
    if not text:
        return "0"
    if re.fullmatch(r"[+-]?\d+", text):
        try:
            number = int(text)
            sign = "+" if number > 0 else ""
            return f"{sign}{number:,}"
        except ValueError:
            return text
    if re.fullmatch(r"[+-]?\d+\.0+", text):
        try:
            number = int(float(text))
            sign = "+" if number > 0 else ""
            return f"{sign}{number:,}"
        except ValueError:
            return text
    return text


_ENV.filters["intcomma"] = _intcomma
_ENV.filters["signed_intcomma"] = _signed_intcomma

_TEMPLATE = _ENV.from_string(
    """<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>MemScope Report - {{ metadata.target_name or "unknown" }}</title>
  <style>
    :root {
      --bg: #0f131a;
      --bg-alt: #141c27;
      --panel: #1a2635;
      --panel-alt: #223146;
      --panel-soft: #1e2d40;
      --text: #e8f0ff;
      --muted: #a7b6cc;
      --text-dim: #7f8faa;
      --accent: #4f8cff;
      --accent-2: #22c1ff;
      --accent-soft: #8fd3ff;
      --muted-purple: #4f6a8f;
      --warning: #f0b45a;
      --error: #ec6d86;
      --ok: #61c98f;
      --line: #35506e;
      --line-strong: #4b6a8d;
      --shadow: rgba(0, 0, 0, 0.42);
      --shadow-hover: 0 18px 38px rgba(0, 0, 0, 0.62);
      --transition: all 0.28s cubic-bezier(0.4, 0, 0.2, 1);
      --chart-1: #4f8cff;
      --chart-2: #22c1ff;
      --chart-3: #79d5ff;
      --chart-4: #61c98f;
      --chart-5: #7ea4ff;
      --bar-track-start: #1a2a3c;
      --bar-track-end: #243a54;
      --bar-fill-1: #3f74d8;
      --bar-fill-2: #4f8cff;
      --bar-fill-3: #7cc6ff;
      --bar-success-1: #4da06e;
      --bar-success-2: #7ad7a3;
      --bar-warning-1: #d09139;
      --bar-warning-2: #f3c981;
      --bar-danger-1: #c95a73;
      --bar-danger-2: #ef9aad;
      --report-max-width: clamp(1100px, 94vw, 2600px);
      --icon-shell-size: 36px;
      --icon-glyph-size: 19px;
      --icon-shell-size-compact: 31px;
      --icon-glyph-size-compact: 17px;
      --icon-shell-size-region: 36px;
      --icon-glyph-size-region: 19px;
      --header-icon-size: 52px;
      --header-inline-icon-size: 23px;
      --space-1: 4px;
      --space-2: 8px;
      --space-3: 12px;
      --space-4: 16px;
      --space-5: 24px;
      --space-6: 32px;
      --space-7: 48px;
      --radius-xs: 4px;
      --radius-sm: 8px;
      --radius-md: 12px;
      --radius-lg: 16px;
      --radius-pill: 999px;
      --elev-1: 0 1px 2px rgba(5, 11, 22, 0.32);
      --elev-2: 0 6px 18px rgba(5, 11, 22, 0.34), 0 1px 2px rgba(5, 11, 22, 0.28);
      --elev-3: 0 18px 38px rgba(5, 11, 22, 0.48), 0 2px 6px rgba(5, 11, 22, 0.32);
      --ring: 0 0 0 2px var(--bg), 0 0 0 4px var(--accent);
      --font-mono: ui-monospace, SFMono-Regular, "SF Mono", Menlo, Consolas, "Liberation Mono", monospace;
      --type-xs: 11px;
      --type-sm: 12px;
      --type-md: 13.5px;
      --type-lg: 16px;
      --type-xl: 20px;
      --type-2xl: 26px;
      --leading-tight: 1.25;
      --leading-normal: 1.5;
      --appbar-height: 54px;
      --hero-card-bg: color-mix(in srgb, var(--panel) 86%, transparent);
      --hero-card-border: color-mix(in srgb, var(--line) 70%, transparent);
      --hero-accent-bg: color-mix(in srgb, var(--accent) 14%, transparent);
      --hero-danger-bg: color-mix(in srgb, var(--error) 16%, transparent);
      --hero-warning-bg: color-mix(in srgb, var(--warning) 16%, transparent);
      --hero-ok-bg: color-mix(in srgb, var(--ok) 16%, transparent);
    }
    body.manual-light {
      --bg: #f5f9ff;
      --bg-alt: #ebf2ff;
      --panel: #ffffff;
      --panel-alt: #eef4ff;
      --panel-soft: #f4f8ff;
      --text: #15263d;
      --muted: #5f738e;
      --text-dim: #7f93ac;
      --accent: #2f74f2;
      --accent-2: #0ea5e9;
      --accent-soft: #8fc5ff;
      --muted-purple: #90a7c6;
      --warning: #b77b29;
      --error: #c5556f;
      --ok: #368a57;
      --line: #c9d7eb;
      --line-strong: #aabdd8;
      --shadow: rgba(19, 39, 71, 0.16);
      --shadow-hover: 0 18px 36px rgba(19, 39, 71, 0.28);
      --chart-1: #2f74f2;
      --chart-2: #0ea5e9;
      --chart-3: #8fc5ff;
      --chart-4: #368a57;
      --chart-5: #5f8fe5;
      --bar-track-start: #e7eefb;
      --bar-track-end: #d8e4f7;
      --bar-fill-1: #2f74f2;
      --bar-fill-2: #4b95ff;
      --bar-fill-3: #8fc5ff;
      --bar-success-1: #368a57;
      --bar-success-2: #70bf8f;
      --bar-warning-1: #b77b29;
      --bar-warning-2: #dab06d;
      --bar-danger-1: #c5556f;
      --bar-danger-2: #df8a9e;
      --elev-1: 0 1px 2px rgba(19, 39, 71, 0.12);
      --elev-2: 0 8px 20px rgba(19, 39, 71, 0.14), 0 1px 2px rgba(19, 39, 71, 0.10);
      --elev-3: 0 18px 36px rgba(19, 39, 71, 0.22), 0 2px 8px rgba(19, 39, 71, 0.14);
      --hero-card-bg: color-mix(in srgb, var(--panel) 92%, transparent);
      --hero-card-border: color-mix(in srgb, var(--line) 80%, transparent);
      --hero-accent-bg: color-mix(in srgb, var(--accent) 10%, transparent);
      --hero-danger-bg: color-mix(in srgb, var(--error) 12%, transparent);
      --hero-warning-bg: color-mix(in srgb, var(--warning) 12%, transparent);
      --hero-ok-bg: color-mix(in srgb, var(--ok) 12%, transparent);
    }
    * {
      box-sizing: border-box;
    }
    html {
      scroll-behavior: smooth;
      scroll-padding-top: calc(var(--appbar-height) + 12px);
    }
    * {
      scrollbar-width: thin;
      scrollbar-color: var(--accent) color-mix(in srgb, var(--line) 70%, transparent);
    }
    *::-webkit-scrollbar {
      width: 10px;
      height: 10px;
    }
    *::-webkit-scrollbar-track {
      background: color-mix(in srgb, var(--line) 64%, transparent);
      border-radius: 999px;
    }
    *::-webkit-scrollbar-thumb {
      background: linear-gradient(180deg, var(--chart-2), var(--chart-1));
      border-radius: 999px;
      border: 2px solid transparent;
      background-clip: content-box;
    }
    *::-webkit-scrollbar-thumb:hover {
      background: linear-gradient(180deg, var(--chart-3), var(--chart-1));
      background-clip: content-box;
    }
    body {
      margin: 0;
      min-height: 100vh;
      background: linear-gradient(145deg, var(--bg-alt) 0%, var(--bg) 56%, color-mix(in srgb, var(--bg) 86%, #000000) 100%);
      color: var(--text);
      font-family: "Segoe UI", "Roboto", sans-serif;
      line-height: 1.48;
      letter-spacing: 0.01em;
      position: relative;
    }
    body::before,
    body::after {
      content: "";
      position: fixed;
      pointer-events: none;
      z-index: -2;
      border-radius: 50%;
      opacity: 0.22;
    }
    body::before {
      width: 560px;
      height: 560px;
      top: -210px;
      right: -130px;
      background: radial-gradient(circle, color-mix(in srgb, var(--accent) 60%, transparent) 0%, transparent 72%);
    }
    body::after {
      width: 620px;
      height: 620px;
      left: -180px;
      bottom: -240px;
      opacity: 0.16;
      background: radial-gradient(circle, color-mix(in srgb, var(--accent-soft) 56%, transparent) 0%, transparent 72%);
    }
    .wrap {
      max-width: var(--report-max-width);
      margin: 0 auto;
      padding: 20px;
      display: grid;
      gap: 16px;
      position: relative;
      align-items: start;
    }
    .wrap::before {
      content: "";
      position: fixed;
      inset: 0;
      pointer-events: none;
      z-index: -1;
      background:
        repeating-linear-gradient(to right, rgba(255, 255, 255, 0.017) 0, rgba(255, 255, 255, 0.017) 1px, transparent 1px, transparent 40px),
        repeating-linear-gradient(to bottom, rgba(255, 255, 255, 0.015) 0, rgba(255, 255, 255, 0.015) 1px, transparent 1px, transparent 40px);
    }
    h1, h2, h3 {
      margin: 0 0 12px;
      letter-spacing: 0.04em;
      font-family: "Bahnschrift SemiBold", "Aptos Display", "Segoe UI Semibold", "Trebuchet MS", sans-serif;
    }
    h1 {
      font-size: clamp(1.45rem, 2.8vw, 2.2rem);
      text-transform: uppercase;
      letter-spacing: 0.08em;
    }
    h2 {
      font-size: clamp(0.98rem, 1.8vw, 1.22rem);
      border-bottom: 1px solid var(--line);
      padding-bottom: 9px;
      margin-bottom: 14px;
    }
    h3 {
      font-size: 0.96rem;
      letter-spacing: 0.04em;
    }
    .sub {
      color: var(--muted);
      font-size: 0.92rem;
      margin-top: 8px;
    }
    .report-shell {
      display: block;
      min-width: 0;
    }
    .quick-links-pane {
      position: fixed;
      left: 0;
      top: 50%;
      transform: translateY(-50%);
      width: clamp(64px, calc((100vw - var(--report-max-width)) / 2 - 10px), 244px);
      z-index: 64;
      border: 1px solid var(--line);
      border-left: 0;
      border-radius: 0 14px 14px 0;
      background: linear-gradient(
        160deg,
        color-mix(in srgb, var(--panel-alt) 86%, transparent),
        color-mix(in srgb, var(--panel-soft) 90%, transparent)
      );
      box-shadow: 0 10px 28px rgba(0, 0, 0, 0.3);
      backdrop-filter: blur(8px);
      opacity: 0.56;
      padding: 10px 8px 10px 12px;
      display: grid;
      gap: 10px;
      max-height: calc(100vh - 24px);
      min-width: 0;
      overflow: hidden;
      transition: width 170ms ease, opacity 170ms ease, box-shadow 170ms ease, background 170ms ease;
    }
    .quick-links-pane:hover,
    .quick-links-pane:focus-within {
      opacity: 0.98;
      background: linear-gradient(
        160deg,
        color-mix(in srgb, var(--panel-alt) 92%, transparent),
        color-mix(in srgb, var(--panel-soft) 96%, transparent)
      );
      box-shadow: 0 14px 34px rgba(0, 0, 0, 0.44);
    }
    .quick-links-title {
      margin: 0;
      padding: 4px 6px 0;
      font-size: 0.74rem;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--muted);
    }
    .quick-links {
      display: grid;
      grid-template-columns: 1fr;
      gap: 8px;
      margin: 0;
      padding: 2px;
      overflow: auto;
      scrollbar-gutter: stable both-edges;
      min-height: 0;
    }
    .quick-links a {
      display: flex;
      align-items: center;
      text-decoration: none;
      color: var(--text);
      border: 1px solid var(--line);
      border-radius: 10px;
      padding: 8px 12px;
      font-size: 0.8rem;
      text-align: left;
      background: color-mix(in srgb, var(--panel-alt) 70%, transparent);
      transition: background 120ms ease, border-color 120ms ease, transform 120ms ease;
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .quick-links a:hover {
      border-color: var(--line-strong);
      background: linear-gradient(
        120deg,
        color-mix(in srgb, var(--accent) 30%, transparent),
        color-mix(in srgb, var(--accent-soft) 24%, transparent)
      );
      transform: translateY(-1px);
    }
    .quick-links a.active {
      border-color: color-mix(in srgb, var(--accent-soft) 62%, var(--line));
      background: linear-gradient(
        120deg,
        color-mix(in srgb, var(--accent) 40%, transparent),
        color-mix(in srgb, var(--accent-soft) 32%, transparent)
      );
      color: var(--text);
    }
    .report-main {
      min-width: 0;
      display: grid;
      gap: 0;
    }
    .watermark {
      padding: 6px 10px;
      border: 1px solid var(--warning);
      color: var(--warning);
      border-radius: 9px;
      font-weight: 700;
      letter-spacing: 0.08em;
      display: inline-block;
      margin-bottom: 12px;
      background: color-mix(in srgb, var(--warning) 18%, transparent);
      font-size: 0.76rem;
    }
    .grid {
      display: grid;
      gap: 11px;
      grid-template-columns: repeat(auto-fit, minmax(185px, 1fr));
    }
    .kpi {
      border: 1px solid var(--line);
      border-radius: 12px;
      padding: 11px 12px;
      background: linear-gradient(
        165deg,
        color-mix(in srgb, var(--accent) 18%, transparent) 0%,
        color-mix(in srgb, var(--accent-soft) 10%, transparent) 100%
      );
      position: relative;
      overflow: hidden;
      min-width: 0;
      transition: var(--transition);
    }
    .kpi:hover {
      transform: translateY(-2px);
    }
    .kpi::after {
      content: "";
      position: absolute;
      inset: 0 auto 0 0;
      width: 3px;
      background: linear-gradient(180deg, var(--chart-1), var(--chart-2), var(--chart-3));
      opacity: 0.85;
    }
    .kpi .label {
      color: var(--muted);
      font-size: 0.8rem;
      margin-left: 8px;
    }
    .kpi .value {
      font-size: 1.26rem;
      font-weight: 700;
      margin-left: 8px;
      letter-spacing: 0.01em;
    }
    .row {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 8px;
    }
    .bar {
      position: relative;
      margin: 10px 0;
      border: 1px solid var(--line);
      border-radius: 999px;
      background: linear-gradient(90deg, var(--bar-track-start), var(--bar-track-end));
      height: 18px;
      overflow: hidden;
    }
    .bar > span {
      display: block;
      height: 100%;
      background: linear-gradient(90deg, var(--bar-fill-1), var(--bar-fill-2), var(--bar-fill-3));
    }
    .region-grid {
      display: grid;
      gap: 1.5rem;
      grid-template-columns: repeat(auto-fit, minmax(320px, 1fr));
    }
    .region-card {
      border: 1px solid var(--line);
      border-radius: 10px;
      padding: 1.5rem;
      background: var(--panel-alt);
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.35);
      min-width: 0;
      overflow: hidden;
      transition: var(--transition);
    }
    .region-card:hover {
      transform: translateY(-3px);
      box-shadow: 0 8px 28px rgba(0, 0, 0, 0.55);
    }
    .region-card.warning {
      border-color: color-mix(in srgb, var(--warning) 65%, var(--line));
    }
    .region-card.danger {
      border-color: color-mix(in srgb, var(--error) 68%, var(--line));
    }
    .region-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 0.6rem;
      margin-bottom: 1.2rem;
    }
    .region-name {
      font-size: 1.36rem;
      font-weight: 500;
      max-width: 76%;
      display: flex;
      align-items: center;
      gap: 0.62rem;
    }
    .region-chip {
      width: var(--icon-shell-size-region);
      height: var(--icon-shell-size-region);
      margin: 0;
      flex: 0 0 auto;
    }
    .region-chip .fa-icon {
      width: var(--icon-glyph-size-region);
      height: var(--icon-glyph-size-region);
    }
    .region-label {
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .region-meta {
      font-size: 0.9rem;
      color: var(--muted);
      white-space: nowrap;
    }
    .region-description {
      color: var(--muted);
      font-size: 0.88rem;
      margin: -0.2rem 0 0.8rem;
      overflow-wrap: anywhere;
    }
    .progress-info {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 0.6rem;
      margin: 0.8rem 0;
      font-size: 0.9rem;
    }
    .metrics-divider {
      height: 1px;
      background: linear-gradient(
        90deg,
        transparent 0%,
        var(--accent) 20%,
        var(--accent-2) 50%,
        var(--accent) 80%,
        transparent 100%
      );
      margin: 1rem 0;
      position: relative;
      opacity: 0.6;
    }
    .metrics-divider::before {
      content: "";
      position: absolute;
      top: -1px;
      left: 50%;
      transform: translateX(-50%);
      width: 6px;
      height: 6px;
      background: var(--accent);
      border-radius: 50%;
      box-shadow: 0 0 8px color-mix(in srgb, var(--accent) 44%, transparent);
    }
    .metrics-divider.secondary {
      background: linear-gradient(
        90deg,
        transparent 0%,
        var(--line) 25%,
        var(--muted) 50%,
        var(--line) 75%,
        transparent 100%
      );
      opacity: 0.45;
    }
    .metrics-divider.secondary::before {
      background: var(--muted);
      box-shadow: 0 0 6px rgba(176, 176, 176, 0.3);
      width: 4px;
      height: 4px;
    }
    .overflow-note {
      margin-top: 8px;
      font-size: 0.8rem;
      color: var(--error);
      font-weight: 700;
    }
    .charts {
      display: grid;
      gap: 18px;
      grid-template-columns: repeat(auto-fit, minmax(340px, 1fr));
    }
    .charts > * {
      min-width: 0;
    }
    .split-grid {
      display: grid;
      gap: 12px;
      grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
    }
    .split-grid > * {
      min-width: 0;
    }
    .comparison-grid {
      display: grid;
      gap: 12px;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      margin-top: 10px;
    }
    .comparison-grid > * {
      min-width: 0;
    }
    .chart-card {
      position: relative;
      border: 1px solid color-mix(in srgb, var(--line) 92%, transparent);
      border-radius: var(--radius-lg);
      padding: 18px 18px 14px;
      background:
        radial-gradient(120% 80% at 0% 0%, color-mix(in srgb, var(--accent) 8%, transparent) 0%, transparent 55%),
        linear-gradient(180deg,
          color-mix(in srgb, var(--panel) 96%, rgba(6, 13, 28, 1)),
          color-mix(in srgb, var(--panel-soft) 96%, rgba(7, 16, 34, 1))
        );
      box-shadow: var(--elev-2);
      min-width: 0;
      overflow: hidden;
      isolation: isolate;
      transition: transform 180ms ease, border-color 180ms ease, box-shadow 180ms ease;
    }
    .chart-card::before {
      content: "";
      position: absolute;
      left: 0; right: 0; top: 0;
      height: 2px;
      background: linear-gradient(90deg,
        color-mix(in srgb, var(--accent) 80%, transparent),
        color-mix(in srgb, var(--accent-soft) 70%, transparent) 60%,
        transparent 100%);
      opacity: 0.85;
      pointer-events: none;
    }
    .chart-card:hover {
      transform: translateY(-3px);
      border-color: color-mix(in srgb, var(--accent) 38%, var(--line));
      box-shadow: var(--elev-3);
    }
    .chart-title {
      margin: 0 0 12px;
      font-size: 0.95rem;
      font-weight: 600;
      letter-spacing: 0.01em;
      color: var(--text);
      text-transform: none;
      display: flex;
      align-items: center;
      gap: 8px;
    }
    .chart-title::before {
      content: "";
      width: 7px;
      height: 7px;
      border-radius: 999px;
      background: linear-gradient(135deg,
        color-mix(in srgb, var(--accent-soft) 90%, #b9d7ff),
        color-mix(in srgb, var(--accent) 85%, #6fb8ff));
      box-shadow: 0 0 10px color-mix(in srgb, var(--accent-soft) 55%, transparent);
      flex: 0 0 auto;
    }
    canvas.chart {
      width: 100%;
      height: clamp(220px, 30vh, 400px);
      display: block;
    }
    .insight-list {
      display: flex;
      flex-direction: column;
      gap: 8px;
      min-height: 100px;
    }
    .insight-empty {
      color: var(--muted);
      font-size: 0.85rem;
      padding: 10px 4px;
    }
    .insight-row {
      display: grid;
      grid-template-columns: minmax(0, 1.1fr) minmax(0, 2fr) auto;
      align-items: center;
      gap: 12px;
      padding: 4px 2px;
      border-radius: 6px;
      cursor: pointer;
      transition: background 120ms ease;
    }
    .insight-row:hover {
      background: color-mix(in srgb, var(--accent) 10%, transparent);
    }
    .insight-row:focus-visible {
      outline: 2px solid color-mix(in srgb, var(--accent) 70%, transparent);
      outline-offset: 1px;
    }
    .insight-label {
      font-size: 0.85rem;
      color: var(--text);
      white-space: nowrap;
      overflow: hidden;
      text-overflow: ellipsis;
      font-weight: 500;
    }
    .insight-track {
      position: relative;
      height: 10px;
      background: linear-gradient(90deg, var(--bar-track-start), var(--bar-track-end));
      border-radius: 5px;
      overflow: hidden;
      box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--line) 70%, transparent);
    }
    .insight-fill {
      display: block;
      height: 100%;
      width: 0;
      border-radius: 5px;
      background: linear-gradient(90deg,
        color-mix(in srgb, var(--accent-soft) 80%, transparent),
        color-mix(in srgb, var(--accent) 90%, transparent));
      box-shadow: 0 0 8px color-mix(in srgb, var(--accent) 30%, transparent);
      transition: width 0.7s cubic-bezier(0.22, 1, 0.36, 1);
      position: relative;
    }
    .insight-fill::after {
      content: "";
      position: absolute;
      inset: 0;
      background: linear-gradient(120deg,
        transparent 0%,
        color-mix(in srgb, #ffffff 22%, transparent) 35%,
        transparent 70%);
      mix-blend-mode: screen;
      opacity: 0.4;
    }
    .insight-fill.is-warning {
      background: linear-gradient(90deg,
        color-mix(in srgb, var(--warning) 80%, transparent),
        color-mix(in srgb, var(--warning) 100%, transparent));
      box-shadow: 0 0 8px color-mix(in srgb, var(--warning) 35%, transparent);
    }
    .insight-fill.is-danger {
      background: linear-gradient(90deg,
        color-mix(in srgb, var(--error) 85%, transparent),
        color-mix(in srgb, var(--error) 100%, transparent));
      box-shadow: 0 0 10px color-mix(in srgb, var(--error) 40%, transparent);
    }
    .insight-value {
      font-size: 0.82rem;
      font-weight: 600;
      color: var(--text);
      font-variant-numeric: tabular-nums;
      white-space: nowrap;
      min-width: 56px;
      text-align: right;
    }
    .insight-value-meta {
      display: block;
      font-size: 0.72rem;
      color: var(--muted);
      font-weight: 500;
      margin-top: 1px;
    }
    .insight-scale {
      display: grid;
      grid-template-columns: minmax(0, 1.1fr) minmax(0, 2fr) auto;
      gap: 12px;
      align-items: center;
      padding: 0 2px;
      margin-top: 4px;
      font-size: 0.7rem;
      color: var(--muted);
      font-variant-numeric: tabular-nums;
    }
    .insight-scale-bar {
      position: relative;
      height: 14px;
    }
    .insight-scale-bar span {
      position: absolute;
      top: 0;
      transform: translateX(-50%);
    }
    .insight-scale-spacer { min-width: 56px; }
    .badge-row {
      display: flex;
      flex-wrap: wrap;
      gap: 8px;
      margin-bottom: 10px;
    }
    .badge {
      border: 1px solid var(--line);
      border-radius: 999px;
      padding: 5px 10px;
      font-size: 0.82rem;
      color: var(--muted);
      background: color-mix(in srgb, var(--panel-alt) 72%, transparent);
    }
    .badge.negative {
      border-color: rgba(61, 220, 151, 0.54);
      color: var(--ok);
    }
    .badge.positive {
      border-color: rgba(255, 109, 127, 0.58);
      color: var(--error);
    }
    .badge.neutral {
      border-color: var(--line);
      color: var(--muted);
    }
    .toolbar {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      margin-bottom: 10px;
      align-items: center;
    }
    .toolbar label {
      font-size: 0.82rem;
      color: var(--muted);
      font-weight: 500;
      letter-spacing: 0.02em;
    }
    .toolbar input,
    .toolbar select {
      -webkit-appearance: none;
      appearance: none;
      border: 1px solid var(--line);
      border-radius: 8px;
      background: color-mix(in srgb, var(--panel-alt) 90%, var(--bg));
      color: var(--text);
      font-family: inherit;
      font-size: 0.84rem;
      line-height: 1.4;
      padding: 8px 12px;
      min-width: 180px;
      outline: none;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.18), inset 0 1px 0 rgba(255, 255, 255, 0.04);
      transition: border-color 120ms ease, box-shadow 120ms ease;
    }
    .toolbar select {
      padding-right: 32px;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%23a7b6cc' stroke-width='1.6' fill='none' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
      background-repeat: no-repeat;
      background-position: right 9px center;
      cursor: pointer;
    }
    .toolbar input::placeholder {
      color: var(--text-dim);
      font-style: italic;
    }
    .toolbar input:focus,
    .toolbar select:focus {
      border-color: color-mix(in srgb, var(--accent) 72%, var(--line));
      box-shadow: 0 0 0 2px color-mix(in srgb, var(--accent) 28%, transparent), 0 1px 3px rgba(0, 0, 0, 0.18);
    }
    .toolbar-field {
      position: relative;
      display: inline-flex;
      align-items: center;
      flex: 1 1 auto;
      min-width: 0;
    }
    .toolbar-field > input,
    .toolbar-field > select {
      width: 100%;
    }
    .toolbar input:not(:placeholder-shown),
    .toolbar input[data-has-value="true"],
    .toolbar select[data-has-value="true"],
    .filter-item input:not(:placeholder-shown),
    .filter-item input[data-has-value="true"],
    .filter-item select[data-has-value="true"] {
      border-color: color-mix(in srgb, var(--accent) 62%, var(--line)) !important;
      background:
        linear-gradient(0deg,
          color-mix(in srgb, var(--accent) 14%, transparent),
          color-mix(in srgb, var(--accent) 14%, transparent)),
        color-mix(in srgb, var(--panel-alt) 90%, var(--bg)) !important;
      box-shadow:
        0 0 0 1px color-mix(in srgb, var(--accent) 36%, transparent),
        inset 0 1px 0 rgba(255, 255, 255, 0.05) !important;
    }
    .filter-item select[data-has-value="true"] {
      background:
        linear-gradient(0deg,
          color-mix(in srgb, var(--accent) 14%, transparent),
          color-mix(in srgb, var(--accent) 14%, transparent)),
        color-mix(in srgb, var(--panel-alt) 90%, var(--bg)),
        url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%23a7b6cc' stroke-width='1.6' fill='none' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E") right 10px center / auto no-repeat !important;
    }
    .toolbar input:not(:placeholder-shown):focus,
    .toolbar input[data-has-value="true"]:focus,
    .toolbar select[data-has-value="true"]:focus,
    .filter-item input:not(:placeholder-shown):focus,
    .filter-item input[data-has-value="true"]:focus,
    .filter-item select[data-has-value="true"]:focus {
      border-color: color-mix(in srgb, var(--accent) 82%, var(--line)) !important;
      box-shadow:
        0 0 0 2px color-mix(in srgb, var(--accent) 38%, transparent),
        0 1px 3px rgba(0, 0, 0, 0.18) !important;
    }
    .toolbar-field::after {
      content: "";
      position: absolute;
      top: 7px;
      right: 7px;
      width: 7px;
      height: 7px;
      border-radius: 999px;
      background: linear-gradient(135deg,
        color-mix(in srgb, var(--accent-soft) 90%, #b9d7ff),
        color-mix(in srgb, var(--accent) 85%, #6fb8ff));
      box-shadow: 0 0 8px color-mix(in srgb, var(--accent-soft) 60%, transparent);
      opacity: 0;
      transform: scale(0.6);
      transition: opacity 140ms ease, transform 140ms ease;
      pointer-events: none;
    }
    .toolbar-field:has(input:not(:placeholder-shown))::after,
    .toolbar-field:has(input[data-has-value="true"])::after,
    .toolbar-field:has(select[data-has-value="true"])::after {
      opacity: 1;
      transform: scale(1);
    }
    .toolbar-field:has(select)::after {
      right: 30px;
    }
    .toolbar-active-summary {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 4px 10px 4px 8px;
      border-radius: 999px;
      background: color-mix(in srgb, var(--accent) 14%, transparent);
      border: 1px solid color-mix(in srgb, var(--accent) 38%, var(--line));
      color: var(--text);
      font-size: 0.78rem;
      font-weight: 500;
      letter-spacing: 0.01em;
      cursor: pointer;
      transition: background 120ms ease, border-color 120ms ease;
    }
    .toolbar-active-summary[hidden] { display: none; }
    .toolbar-active-summary:hover {
      background: color-mix(in srgb, var(--accent) 22%, transparent);
      border-color: color-mix(in srgb, var(--accent) 55%, var(--line));
    }
    .toolbar-active-summary::before {
      content: "";
      width: 6px;
      height: 6px;
      border-radius: 999px;
      background: linear-gradient(135deg,
        color-mix(in srgb, var(--accent-soft) 90%, #b9d7ff),
        color-mix(in srgb, var(--accent) 85%, #6fb8ff));
      box-shadow: 0 0 6px color-mix(in srgb, var(--accent-soft) 60%, transparent);
    }
    .toolbar-active-summary-clear {
      margin-left: 4px;
      border: none;
      background: transparent;
      color: var(--muted);
      font-size: 0.95rem;
      line-height: 1;
      cursor: pointer;
      padding: 0 2px;
    }
    .toolbar-active-summary-clear:hover { color: var(--text); }
    .table-wrap {
      border: 1px solid var(--line);
      border-radius: 12px;
      overflow: auto;
      max-height: clamp(360px, 55vh, 760px);
      background: color-mix(in srgb, var(--panel-alt) 78%, transparent);
      box-shadow: inset 0 2px 10px rgba(0, 0, 0, 0.25);
      scrollbar-gutter: stable both-edges;
      min-width: 0;
      overscroll-behavior: contain;
      clip-path: inset(0 round 12px);
      background-clip: padding-box;
    }
    .summary-note {
      font-size: 0.82rem;
      color: var(--muted);
      margin-bottom: 8px;
      overflow-wrap: anywhere;
      word-break: break-word;
      hyphens: auto;
    }
    .vlist-footer {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 12px;
      padding: 10px 12px;
      margin-top: 8px;
      border: 1px dashed var(--line);
      border-radius: 10px;
      background: color-mix(in srgb, var(--panel-alt) 56%, transparent);
      font-size: 0.82rem;
      color: var(--muted);
    }
    .vlist-footer[hidden] { display: none; }
    .vlist-footer-note { overflow-wrap: anywhere; }
    .vlist-footer-toggle {
      border: 1px solid var(--line);
      background: transparent;
      color: var(--text);
      border-radius: 999px;
      padding: 4px 12px;
      font-size: 0.78rem;
      cursor: pointer;
      white-space: nowrap;
    }
    .vlist-footer-toggle:hover { border-color: var(--accent); color: var(--accent); }
    .vlist-footer-toggle[aria-pressed="true"] { background: var(--accent); color: var(--accent-fg, #0b1220); border-color: var(--accent); }
    tr.vlist-clipped { display: none !important; }
    .diagnostics-grid {
      display: grid;
      gap: 10px;
      grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    }
    .diag-card {
      border: 1px solid var(--line);
      border-radius: 10px;
      padding: 10px;
      background: color-mix(in srgb, var(--panel-alt) 72%, transparent);
      min-width: 0;
      max-width: 100%;
      overflow: hidden;
    }
    .diag-card h3 {
      margin: 0 0 6px;
      font-size: 0.92rem;
      text-transform: uppercase;
      color: var(--muted);
      letter-spacing: 0.04em;
      overflow-wrap: anywhere;
      word-break: break-word;
    }
    .diag-list {
      margin: 0;
      padding-left: 16px;
      display: grid;
      gap: 4px;
      font-size: 0.83rem;
      min-width: 0;
      max-width: 100%;
    }
    .ms-license-footer {
      margin: 32px 0 16px;
      padding: 12px 16px;
      border-top: 1px solid var(--color-border, #d0d4dc);
      background: var(--color-surface-muted, rgba(0, 0, 0, 0.025));
      font-size: 0.78rem;
      color: var(--color-fg-muted, #555);
      font-family: var(--font-sans, system-ui, -apple-system, sans-serif);
    }
    .ms-license-footer-inner {
      display: flex;
      flex-wrap: wrap;
      gap: 4px 18px;
      align-items: baseline;
    }
    .ms-license-footer-label {
      font-weight: 600;
      letter-spacing: 0.04em;
      text-transform: uppercase;
      font-size: 0.7rem;
      color: var(--color-fg-muted, #777);
    }
    .ms-license-footer-item {
      font-variant-numeric: tabular-nums;
    }
    .ms-license-footer-item strong {
      font-weight: 600;
      color: var(--color-fg, #222);
    }
    .diag-card .summary-note,
    .diag-card .diag-list li {
      max-width: 100%;
      overflow-wrap: anywhere;
      word-break: break-word;
      hyphens: auto;
      white-space: normal;
    }
    details {
      margin-top: 10px;
      border: 1px solid var(--line);
      border-radius: 10px;
      background: color-mix(in srgb, var(--panel-alt) 72%, transparent);
    }
    details summary {
      cursor: pointer;
      padding: 8px 10px;
      color: var(--muted);
      font-size: 0.86rem;
    }
    details pre {
      border: 0;
      border-top: 1px solid var(--line);
      border-radius: 0;
      margin: 0;
      max-height: 300px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.9rem;
    }
    th, td {
      border-bottom: 1px solid var(--line);
      padding: 8px 6px;
      text-align: left;
      vertical-align: top;
      overflow-wrap: anywhere;
      word-break: break-word;
    }
    thead th {
      position: sticky;
      top: 0;
      background: color-mix(in srgb, var(--panel-alt) 96%, transparent);
      backdrop-filter: blur(4px);
      z-index: 1;
      border-bottom: 1px solid var(--line-strong);
    }
    tbody tr:hover {
      background: color-mix(in srgb, var(--accent) 16%, transparent);
    }
    th[data-sort] {
      cursor: pointer;
      color: #7dc9ff;
    }
    th[data-sort]::after {
      content: " ↕";
      font-size: 0.72em;
      opacity: 0.45;
      vertical-align: middle;
    }
    th[data-sort][data-order="asc"]::after {
      content: " ↑";
      opacity: 0.9;
      color: var(--accent-soft);
    }
    th[data-sort][data-order="desc"]::after {
      content: " ↓";
      opacity: 0.9;
      color: var(--accent-soft);
    }
    .issue-error {
      color: var(--error);
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }
    .issue-warning {
      color: var(--warning);
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }
    .issue-info {
      color: var(--accent);
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.04em;
    }
    .muted {
      color: var(--muted);
    }
    pre {
      margin: 0;
      white-space: pre-wrap;
      word-break: break-word;
      overflow: auto;
      max-height: 420px;
      border: 1px solid var(--line);
      border-radius: 10px;
      padding: 10px;
      background: var(--panel-alt);
    }
    button {
      border: 1px solid var(--line);
      background: linear-gradient(
        180deg,
        color-mix(in srgb, var(--accent) 34%, transparent),
        color-mix(in srgb, var(--accent-soft) 22%, transparent)
      );
      color: var(--text);
      border-radius: 10px;
      padding: 8px 12px;
      cursor: pointer;
      font-weight: 600;
      letter-spacing: 0.04em;
      transition: transform 120ms ease, border-color 120ms ease, filter 120ms ease;
    }
    button:hover {
      transform: translateY(-1px);
      border-color: var(--line-strong);
      filter: brightness(1.05);
    }
    /* Imported visual language from AnalyzeMemoryFootprint.py */
    .container {
      max-width: 1440px;
      margin: 0 auto;
    }
    .header {
      background: linear-gradient(135deg, #16345e 0%, #1d4f86 46%, #2a76c6 100%);
      color: #ffffff;
      padding: 2.45rem 2.6rem;
      border-radius: 12px;
      margin-bottom: 0.9rem;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
      position: relative;
      overflow: hidden;
      border: 0;
      isolation: isolate;
    }
    .header::before {
      content: "";
      position: absolute;
      top: -50%;
      left: -50%;
      width: 200%;
      height: 200%;
      background: radial-gradient(circle, color-mix(in srgb, var(--accent-soft) 26%, transparent) 0%, rgba(255, 255, 255, 0) 72%);
      pointer-events: none;
    }
    .header::after {
      content: "";
      position: absolute;
      left: 0;
      right: 0;
      bottom: 0;
      height: 2px;
      background: linear-gradient(90deg, transparent, color-mix(in srgb, var(--accent-soft) 72%, #ffffff), transparent);
      opacity: 0.62;
      pointer-events: none;
    }
    .header h1 {
      font-size: clamp(2rem, 3.35vw, 2.8rem);
      font-weight: 300;
      margin-bottom: 0.45rem;
      z-index: 1;
      position: relative;
      color: #ffffff;
      letter-spacing: 0.03em;
      text-transform: none;
      display: flex;
      align-items: center;
      gap: 0.95rem;
    }
    .header-title-icon {
      width: var(--header-icon-size);
      height: var(--header-icon-size);
      stroke: #ffffff;
      fill: none;
      stroke-width: 1.95;
      stroke-linecap: round;
      stroke-linejoin: round;
      flex: 0 0 auto;
    }
    .subtitle {
      font-size: 1.2rem;
      opacity: 0.92;
      display: flex;
      gap: 1.15rem;
      flex-wrap: wrap;
      margin-top: 0.1rem;
      position: relative;
      z-index: 1;
    }
    .subtitle span {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      font-size: 1.03rem;
    }
    .header-inline-icon {
      width: var(--header-inline-icon-size);
      height: var(--header-inline-icon-size);
      stroke: rgba(255, 255, 255, 0.95);
      fill: none;
      stroke-width: 2;
      stroke-linecap: round;
      stroke-linejoin: round;
      flex: 0 0 auto;
    }
    .header .watermark {
      position: relative;
      z-index: 1;
      border-color: rgba(255, 255, 255, 0.52);
      color: #ffffff;
      background: rgba(0, 0, 0, 0.18);
      margin-top: 0.15rem;
      margin-bottom: 0.35rem;
    }
    .header-controls {
      display: flex;
      gap: 0.5rem;
      flex-wrap: wrap;
      justify-content: stretch;
      align-items: center;
    }
    .header-action {
      border-radius: 10px;
      padding: 0.46rem 0.86rem;
      font-size: 0.74rem;
      letter-spacing: 0.05em;
      font-weight: 700;
      background: linear-gradient(
        180deg,
        color-mix(in srgb, var(--accent) 36%, transparent),
        color-mix(in srgb, var(--accent-soft) 24%, transparent)
      );
      border: 1px solid var(--line);
      color: var(--text);
      box-shadow: 0 2px 6px rgba(0, 0, 0, 0.18);
      white-space: nowrap;
      text-align: center;
      width: 100%;
    }
    .header-action:hover {
      transform: translateY(-1px);
      border-color: var(--line-strong);
      filter: brightness(1.05);
    }
    .stats-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      gap: 1.5rem;
      margin-top: 0;
      margin-bottom: 2rem;
    }
    .stat-card {
      background: var(--panel);
      border-radius: 12px;
      padding: 1.8rem;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
      transition: var(--transition);
      border-left: 4px solid var(--accent);
      display: flex;
      flex-direction: column;
      border-top: 0;
      border-right: 0;
      border-bottom: 0;
      min-width: 0;
      overflow: hidden;
    }
    .stat-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 10px 25px rgba(0, 0, 0, 0.5);
    }
    .stat-card.critical {
      border-left-color: var(--error);
      box-shadow: 0 0 0 1px color-mix(in srgb, var(--error) 22%, transparent), 0 4px 20px rgba(0, 0, 0, 0.4);
    }
    .stat-card.critical .value {
      color: var(--error);
    }
    .stat-card h3 {
      font-size: 1.12rem;
      font-weight: 500;
      color: var(--muted);
      margin-bottom: 0.8rem;
      text-transform: none;
      letter-spacing: 0.02em;
      display: flex;
      align-items: center;
      gap: 0.5rem;
    }
    .stat-card h3 .label-icon {
      width: var(--icon-shell-size);
      height: var(--icon-shell-size);
      margin-right: 0;
      flex: 0 0 auto;
    }
    .stat-card h3 .fa-icon {
      width: var(--icon-glyph-size);
      height: var(--icon-glyph-size);
    }
    .stat-card .value {
      font-size: 2.35rem;
      font-weight: 300;
      line-height: 1.1;
      margin: 0.5rem 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .stat-card .sub-value {
      color: var(--muted);
      font-size: 0.85rem;
      margin-top: 2px;
      overflow-wrap: anywhere;
    }
    .stat-cap-bar {
      height: 4px;
      background: color-mix(in srgb, var(--line) 55%, transparent);
      border-radius: 999px;
      margin: 8px 0 5px;
      overflow: hidden;
    }
    .stat-cap-fill {
      display: block;
      height: 100%;
      border-radius: 999px;
      background: linear-gradient(90deg, var(--bar-fill-1), var(--bar-fill-2));
      transition: width 0.9s ease-out;
      min-width: 2px;
    }
    .section {
      background: var(--panel);
      border-radius: 12px;
      padding: 2rem;
      margin-bottom: 2rem;
      box-shadow: 0 4px 20px rgba(0, 0, 0, 0.4);
      border: 0;
      transition: var(--transition);
    }
    .section:hover {
      box-shadow: 0 8px 32px rgba(0, 0, 0, 0.6);
    }
    .memory-layout-shell {
      display: grid;
      gap: 12px;
      min-width: 0;
    }
    .memory-layout-stage {
      display: grid;
      grid-template-columns: minmax(0, 1fr);
      align-items: start;
      gap: 12px;
      min-width: 0;
    }
    .memory-layout-meta {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 8px;
      margin-bottom: 2px;
    }
    .memory-layout-meta-item {
      border: 1px solid var(--line);
      border-radius: 10px;
      padding: 8px 10px;
      background: color-mix(in srgb, var(--panel-alt) 72%, transparent);
      font-size: 0.8rem;
      color: var(--muted);
      overflow-wrap: anywhere;
    }
    .memory-layout-meta-item strong {
      color: var(--text);
      font-weight: 600;
      margin-left: 6px;
    }
    .memory-layout-explorer {
      min-height: 360px;
      border: 1px solid var(--line);
      border-radius: 12px;
      background: linear-gradient(
        165deg,
        color-mix(in srgb, var(--panel-alt) 78%, transparent),
        color-mix(in srgb, var(--panel-soft) 84%, transparent)
      );
      padding: 10px;
      overflow-x: auto;
      overflow-y: visible;
      position: relative;
    }
    .memory-layout-minimap {
      border: 1px solid var(--line);
      border-radius: 12px;
      background: color-mix(in srgb, var(--panel-soft) 72%, transparent);
      padding: 8px;
      display: grid;
      gap: 8px;
      min-height: 240px;
      position: sticky;
      top: 14px;
      align-self: start;
      max-height: calc(100vh - 28px);
      overflow: auto;
    }
    .memory-layout-minimap.memory-layout-minimap--embedded {
      position: absolute;
      top: 8px;
      right: 8px;
      bottom: 8px;
      width: var(--embedded-minimap-width, clamp(180px, 18vw, 248px));
      min-height: 0;
      max-height: none;
      overflow: hidden;
      align-self: stretch;
      z-index: 5;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.06), 0 12px 22px rgba(0, 0, 0, 0.28);
      backdrop-filter: blur(4px);
    }
    .memory-layout-tooltip {
      position: fixed;
      z-index: 120;
      pointer-events: none;
      border: 1px solid var(--line-strong);
      border-radius: 10px;
      background: color-mix(in srgb, var(--panel-alt) 90%, transparent);
      box-shadow: 0 14px 28px rgba(0, 0, 0, 0.45);
      color: var(--text);
      padding: 8px 10px;
      max-width: 340px;
      font-size: 0.78rem;
      line-height: 1.35;
      font-variant-numeric: tabular-nums;
      opacity: 0;
      transform: translateY(-4px);
      transition: opacity 120ms ease, transform 120ms ease;
      backdrop-filter: blur(6px);
    }
    .memory-layout-tooltip.is-visible {
      opacity: 1;
      transform: translateY(0);
    }
    .memory-layout-tooltip strong {
      color: var(--accent-soft);
    }
    .memory-layout-tooltip .tip-action {
      margin-top: 4px;
      color: var(--accent-soft);
      font-size: 0.78rem;
      font-weight: 700;
      letter-spacing: 0.02em;
    }
    .memory-layout-panel-backdrop {
      position: fixed;
      inset: 0;
      background: rgba(0, 0, 0, 0.45);
      z-index: 118;
      opacity: 0;
      pointer-events: none;
      transition: opacity 130ms ease;
    }
    .memory-layout-panel-backdrop.is-open {
      opacity: 1;
      pointer-events: auto;
    }
    .memory-layout-side-panel {
      position: fixed;
      top: 0;
      right: 0;
      height: 100vh;
      width: min(470px, 92vw);
      z-index: 119;
      background: linear-gradient(
        180deg,
        color-mix(in srgb, var(--panel) 92%, transparent),
        color-mix(in srgb, var(--panel-alt) 94%, transparent)
      );
      border-left: 1px solid var(--line);
      box-shadow: -16px 0 40px rgba(0, 0, 0, 0.5);
      transform: translateX(102%);
      transition: transform 170ms ease;
      display: grid;
      grid-template-rows: auto 1fr;
      backdrop-filter: blur(8px);
    }
    .memory-layout-side-panel.is-open {
      transform: translateX(0);
    }
    .memory-layout-side-panel-header {
      display: flex;
      align-items: center;
      justify-content: space-between;
      gap: 8px;
      padding: 12px 14px;
      border-bottom: 1px solid var(--line);
      background: color-mix(in srgb, var(--panel-alt) 80%, transparent);
    }
    .memory-layout-side-panel-header h3 {
      margin: 0;
      font-size: 0.95rem;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      color: var(--muted);
    }
    .memory-layout-side-panel-content {
      overflow: auto;
      padding: 14px;
      display: grid;
      gap: 12px;
    }
    .layout-panel-block {
      border: 1px solid var(--line);
      border-radius: 10px;
      padding: 10px;
      background: color-mix(in srgb, var(--panel-soft) 84%, transparent);
      min-width: 0;
    }
    .layout-panel-block h4 {
      margin: 0 0 8px;
      font-size: 0.8rem;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      color: var(--muted);
    }
    .layout-panel-kv {
      display: grid;
      gap: 6px;
      grid-template-columns: minmax(110px, 0.7fr) minmax(0, 1fr);
      font-size: 0.8rem;
      line-height: 1.35;
    }
    .layout-panel-kv dt {
      color: var(--muted);
      margin: 0;
    }
    .layout-panel-kv dd {
      margin: 0;
      color: var(--text);
      overflow-wrap: anywhere;
      font-variant-numeric: tabular-nums;
    }
    .layout-panel-list {
      margin: 0;
      padding-left: 16px;
      display: grid;
      gap: 4px;
      font-size: 0.8rem;
    }
    .layout-panel-table {
      width: 100%;
      border-collapse: collapse;
      font-size: 0.77rem;
      table-layout: fixed;
    }
    .layout-panel-table th,
    .layout-panel-table td {
      border-bottom: 1px solid var(--line);
      padding: 6px 4px;
      text-align: left;
      overflow-wrap: anywhere;
      vertical-align: top;
    }
    .layout-panel-table td {
      font-variant-numeric: tabular-nums;
    }
    .layout-panel-table th {
      color: var(--muted);
      font-weight: 600;
      letter-spacing: 0.04em;
    }
    .layout-panel-placeholder {
      color: var(--muted);
      font-size: 0.82rem;
    }
    .ms-layout-runtime {
      display: grid;
      gap: 10px;
      min-width: 0;
    }
    .ms-layout-toolbar {
      display: flex;
      flex-wrap: wrap;
      align-items: center;
      gap: 8px;
      border: 1px solid var(--line);
      border-radius: 10px;
      padding: 8px 10px;
      background: color-mix(in srgb, var(--panel-soft) 78%, transparent);
    }
    .ms-layout-toolbar .meta {
      color: var(--muted);
      font-size: 0.78rem;
      margin-right: auto;
      overflow-wrap: anywhere;
    }
    .ms-layout-toolbar .ms-layout-cta {
      border: 1px dashed color-mix(in srgb, var(--accent-soft) 58%, var(--line));
      border-radius: 999px;
      padding: 0.3rem 0.58rem;
      font-size: 0.72rem;
      font-weight: 700;
      color: color-mix(in srgb, var(--accent-soft) 90%, #dce9ff);
      background: color-mix(in srgb, var(--accent) 18%, transparent);
      white-space: nowrap;
      letter-spacing: 0.02em;
    }
    .ms-layout-canvas-card {
      --embedded-minimap-width: clamp(180px, 18vw, 248px);
      position: relative;
      border: 1px solid var(--line);
      border-radius: 11px;
      background: color-mix(in srgb, var(--panel-alt) 80%, transparent);
      overflow: visible;
      min-width: 0;
    }
    .ms-layout-canvas-body {
      padding: 8px;
      padding-right: calc(var(--embedded-minimap-width, 248px) + 12px);
      overflow: visible;
    }
    .memory-layout-minimap--embedded .ms-global-minimap-card {
      height: 100%;
      display: flex;
      flex-direction: column;
      min-height: 0;
    }
    .memory-layout-minimap--embedded .ms-global-minimap-title {
      flex: 0 0 auto;
    }
    .memory-layout-minimap--embedded .ms-global-minimap-svg {
      flex: 1 1 auto;
      width: 100%;
      min-height: 0;
      max-height: none;
      height: 100%;
    }
    .ms-focus-controls {
      display: flex;
      align-items: center;
      gap: 6px;
      flex-wrap: wrap;
    }
    .ms-focus-controls select {
      min-width: 220px;
      background: color-mix(in srgb, var(--panel-soft) 86%, transparent);
      color: var(--text);
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 0.3rem 0.45rem;
    }
    .ms-composite-svg {
      width: 100%;
      min-height: 360px;
      height: auto;
      display: block;
      border-radius: 8px;
      background: color-mix(in srgb, var(--bg-alt) 72%, transparent);
      touch-action: none;
      cursor: ns-resize;
      overflow: hidden;
    }
    .ms-composite-svg .layout-range {
      cursor: pointer;
      shape-rendering: crispEdges;
      transition: fill-opacity 120ms ease, stroke 120ms ease, stroke-width 120ms ease, filter 120ms ease;
    }
    .ms-composite-svg .layout-range.is-hover {
      stroke: color-mix(in srgb, var(--accent-soft) 92%, #ffffff);
      stroke-width: 2.2;
      fill-opacity: 0.98;
      filter: drop-shadow(0 0 8px color-mix(in srgb, var(--accent-soft) 40%, transparent));
    }
    .ms-composite-svg .layout-boundary-label {
      font-size: 12px;
      fill: var(--text);
      font-weight: 600;
      font-family: "Aptos Mono", "Consolas", monospace;
    }
    .ms-composite-svg .layout-role-badge {
      font-size: 10px;
      font-weight: 700;
      letter-spacing: 0.06em;
      fill: #0b1322;
      paint-order: stroke;
      stroke: rgba(255, 255, 255, 0.65);
      stroke-width: 2.5;
      stroke-linejoin: round;
      font-family: "Segoe UI", "Roboto", sans-serif;
    }
    .ms-composite-svg .layout-role-chip {
      stroke: rgba(0, 0, 0, 0.35);
      stroke-width: 0.6;
    }
    .ms-composite-svg .layout-role-chip-text {
      font-size: 10px;
      font-weight: 700;
      letter-spacing: 0.05em;
      fill: #0b1322;
      font-family: "Segoe UI", "Roboto", sans-serif;
    }
    .ms-composite-svg .layout-address-label {
      font-size: 13px;
      fill: var(--text);
      font-weight: 600;
      font-family: "Aptos Mono", "Consolas", monospace;
      letter-spacing: 0.02em;
    }
    .ms-composite-svg .layout-axis-line {
      stroke: color-mix(in srgb, var(--line-strong) 80%, transparent);
      stroke-width: 1;
    }
    .ms-composite-svg .layout-tick-line {
      stroke: color-mix(in srgb, var(--line) 80%, transparent);
      stroke-width: 1;
      stroke-dasharray: 2 2;
    }
    .ms-composite-svg .layout-region-header-text {
      fill: var(--text);
      font-size: 12px;
      font-weight: 600;
      font-family: "Aptos Mono", "Consolas", monospace;
    }
    .ms-global-minimap-card {
      border: 1px solid var(--line);
      border-radius: 10px;
      padding: 7px;
      background: color-mix(in srgb, var(--panel-alt) 78%, transparent);
      min-width: 0;
    }
    .ms-global-minimap-title {
      font-size: 0.72rem;
      letter-spacing: 0.05em;
      text-transform: uppercase;
      color: var(--muted);
      margin-bottom: 5px;
      overflow-wrap: anywhere;
    }
    .ms-global-minimap-svg {
      width: 100%;
      height: 360px;
      min-height: 280px;
      max-height: 72vh;
      display: block;
      border-radius: 7px;
      background: color-mix(in srgb, var(--bg-alt) 76%, transparent);
      cursor: pointer;
    }
    .ms-global-minimap-svg .minimap-viewport {
      fill: color-mix(in srgb, var(--accent-soft) 18%, transparent);
      stroke: color-mix(in srgb, var(--accent-soft) 75%, transparent);
      stroke-width: 1;
    }
    .ms-layout-empty {
      border: 1px dashed var(--line);
      border-radius: 10px;
      padding: 14px;
      font-size: 0.84rem;
      color: var(--muted);
    }
    .ms-lens-controls {
      display: inline-flex;
      gap: 6px;
      flex-wrap: wrap;
      padding-left: 8px;
      border-left: 1px solid color-mix(in srgb, var(--line) 75%, transparent);
    }
    .ms-lens-toggle {
      background: color-mix(in srgb, var(--panel-soft) 90%, transparent);
      color: var(--text);
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 0.3rem 0.65rem;
      cursor: pointer;
      font-size: 0.76rem;
      font-weight: 600;
      letter-spacing: 0.02em;
      transition: background-color 120ms ease, border-color 120ms ease, color 120ms ease;
    }
    .ms-lens-toggle:hover:not(:disabled) {
      border-color: color-mix(in srgb, var(--accent) 60%, var(--line));
      color: color-mix(in srgb, var(--accent-soft) 85%, #ffffff);
    }
    .ms-lens-toggle[aria-pressed="true"],
    .ms-lens-toggle.is-on {
      background: color-mix(in srgb, var(--accent) 28%, var(--panel-soft));
      border-color: color-mix(in srgb, var(--accent-soft) 80%, var(--line));
      color: color-mix(in srgb, var(--accent-soft) 92%, #ffffff);
    }
    .ms-lens-toggle:disabled {
      opacity: 0.45;
      cursor: default;
    }
    .ms-composite-svg .layout-range.is-active {
      stroke: color-mix(in srgb, var(--accent-soft) 92%, #ffffff);
      stroke-width: 1.6;
      filter: drop-shadow(0 0 6px color-mix(in srgb, var(--accent-soft) 45%, transparent));
    }
    .ms-composite-svg .layout-heat-strip {
      shape-rendering: crispEdges;
    }
    .ms-composite-svg .layout-heat-strip-label {
      font-size: 10.5px;
      fill: var(--muted);
      font-weight: 700;
      letter-spacing: 0.04em;
      font-family: "Aptos Mono", "Consolas", monospace;
    }
    .ms-composite-svg:focus-visible {
      outline: 2px solid color-mix(in srgb, var(--accent-soft) 75%, transparent);
      outline-offset: 2px;
    }
    .ms-global-minimap-svg .ms-minimap-region-label {
      font-size: 9.5px;
      fill: color-mix(in srgb, var(--text) 80%, transparent);
      font-weight: 700;
      letter-spacing: 0.03em;
      font-family: "Aptos Mono", "Consolas", monospace;
      paint-order: stroke fill;
      stroke: color-mix(in srgb, var(--bg) 75%, transparent);
      stroke-width: 2.5;
    }
    .ms-compare-strip {
      border: 1px solid var(--line);
      border-radius: 11px;
      padding: 10px 12px;
      background: color-mix(in srgb, var(--panel-alt) 74%, transparent);
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    .ms-compare-strip.is-empty {
      background: transparent;
      border-style: dashed;
      color: var(--muted);
    }
    .ms-compare-title {
      font-size: 0.72rem;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--muted);
    }
    .ms-compare-empty {
      font-size: 0.82rem;
      color: var(--muted);
      line-height: 1.45;
    }
    .ms-compare-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      gap: 8px;
    }
    .ms-compare-card {
      border: 1px solid var(--line);
      border-radius: 9px;
      padding: 8px 10px;
      background: color-mix(in srgb, var(--panel-soft) 90%, transparent);
      display: flex;
      flex-direction: column;
      gap: 6px;
    }
    .ms-compare-card.is-missing {
      opacity: 0.6;
      font-style: italic;
    }
    .ms-compare-card-head {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 6px;
    }
    .ms-compare-card-name {
      font-weight: 700;
      font-family: "Aptos Mono", "Consolas", monospace;
      font-size: 0.86rem;
      color: var(--text);
      overflow-wrap: anywhere;
    }
    .ms-compare-unpin {
      background: transparent;
      border: 1px solid var(--line);
      border-radius: 999px;
      width: 22px;
      height: 22px;
      line-height: 1;
      color: var(--muted);
      cursor: pointer;
      font-size: 0.8rem;
      font-weight: 700;
      padding: 0;
    }
    .ms-compare-unpin:hover {
      color: var(--error);
      border-color: color-mix(in srgb, var(--error) 60%, var(--line));
    }
    .ms-compare-card-meta {
      display: flex;
      gap: 8px;
      flex-wrap: wrap;
      font-size: 0.72rem;
      color: var(--muted);
      font-family: "Aptos Mono", "Consolas", monospace;
    }
    .ms-compare-bar {
      position: relative;
      width: 100%;
      height: 6px;
      border-radius: 3px;
      background: color-mix(in srgb, var(--bg-alt) 80%, transparent);
      overflow: hidden;
    }
    .ms-compare-bar > span {
      display: block;
      height: 100%;
      background: linear-gradient(90deg,
        color-mix(in srgb, var(--accent) 60%, transparent),
        color-mix(in srgb, var(--accent-soft) 85%, transparent));
    }
    .ms-compare-focus {
      background: transparent;
      border: 1px solid color-mix(in srgb, var(--accent) 50%, var(--line));
      color: color-mix(in srgb, var(--accent-soft) 85%, #ffffff);
      padding: 0.24rem 0.5rem;
      border-radius: 7px;
      font-size: 0.72rem;
      font-weight: 600;
      cursor: pointer;
      align-self: flex-start;
    }
    .ms-compare-focus:hover {
      background: color-mix(in srgb, var(--accent) 24%, transparent);
    }
    .layout-panel-actions {
      display: flex;
      justify-content: flex-end;
      margin-bottom: 10px;
    }
    .ms-panel-pin-btn {
      background: color-mix(in srgb, var(--panel-soft) 90%, transparent);
      color: var(--text);
      border: 1px solid var(--line);
      border-radius: 8px;
      padding: 0.32rem 0.7rem;
      cursor: pointer;
      font-size: 0.76rem;
      font-weight: 600;
    }
    .ms-panel-pin-btn[aria-pressed="true"] {
      background: color-mix(in srgb, var(--accent) 30%, var(--panel-soft));
      border-color: color-mix(in srgb, var(--accent-soft) 80%, var(--line));
      color: color-mix(in srgb, var(--accent-soft) 92%, #ffffff);
    }
    .ms-diff-pill {
      display: inline-block;
      margin-left: 5px;
      padding: 1px 7px;
      border-radius: 999px;
      font-size: 0.66rem;
      font-weight: 700;
      letter-spacing: 0.04em;
      border: 1px solid var(--line);
    }
    .ms-diff-pill--reg {
      color: var(--error);
      border-color: color-mix(in srgb, var(--error) 55%, var(--line));
      background: color-mix(in srgb, var(--error) 10%, transparent);
    }
    .ms-diff-pill--red {
      color: var(--ok);
      border-color: color-mix(in srgb, var(--ok) 55%, var(--line));
      background: color-mix(in srgb, var(--ok) 10%, transparent);
    }
    .ms-sparkdelta {
      display: grid;
      grid-auto-flow: column;
      grid-auto-columns: 1fr;
      gap: 3px;
      width: 100%;
      height: 16px;
      margin-top: 6px;
      align-items: center;
    }
    .ms-sparkdelta-track {
      position: relative;
      height: 100%;
      background: color-mix(in srgb, var(--bg-alt) 70%, transparent);
      border-radius: 3px;
      overflow: hidden;
    }
    .ms-sparkdelta-bar {
      position: absolute;
      left: 0;
      top: 0;
      bottom: 0;
      border-radius: 3px;
    }
    .ms-sparkdelta-bar--up {
      background: linear-gradient(180deg,
        color-mix(in srgb, var(--error) 85%, transparent),
        color-mix(in srgb, var(--error) 55%, transparent));
    }
    .ms-sparkdelta-bar--down {
      background: linear-gradient(180deg,
        color-mix(in srgb, var(--ok) 85%, transparent),
        color-mix(in srgb, var(--ok) 55%, transparent));
    }
    .ms-region-delta-strip {
      border: 1px solid var(--line);
      border-radius: 11px;
      padding: 12px 14px;
      background: color-mix(in srgb, var(--panel-alt) 70%, transparent);
      margin-top: 14px;
    }
    .ms-region-delta-title {
      font-size: 0.72rem;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--muted);
      margin-bottom: 8px;
    }
    .ms-region-delta-list {
      list-style: none;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      gap: 5px;
    }
    .ms-region-delta-row {
      display: grid;
      grid-template-columns: minmax(120px, 180px) 1fr minmax(120px, 180px);
      gap: 10px;
      align-items: center;
    }
    .ms-region-delta-name {
      font-size: 0.82rem;
      color: var(--text);
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .ms-region-delta-rail {
      position: relative;
      height: 8px;
      background: color-mix(in srgb, var(--bg-alt) 75%, transparent);
      border-radius: 4px;
      overflow: hidden;
    }
    .ms-region-delta-bar {
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      border-radius: 4px;
    }
    .ms-region-delta-bar--up {
      background: linear-gradient(90deg,
        color-mix(in srgb, var(--error) 40%, transparent),
        color-mix(in srgb, var(--error) 88%, transparent));
    }
    .ms-region-delta-bar--down {
      background: linear-gradient(90deg,
        color-mix(in srgb, var(--ok) 40%, transparent),
        color-mix(in srgb, var(--ok) 88%, transparent));
    }
    .ms-region-delta-value {
      text-align: right;
      font-size: 0.78rem;
      color: var(--text);
    }
    .ms-region-delta-row[data-direction="up"] .ms-region-delta-value { color: var(--error); }
    .ms-region-delta-row[data-direction="down"] .ms-region-delta-value { color: var(--ok); }
    .ms-change-drivers {
      margin-top: 16px;
      border: 1px solid var(--line);
      border-radius: 11px;
      padding: 14px;
      background: color-mix(in srgb, var(--panel-alt) 72%, transparent);
    }
    .ms-change-drivers-head {
      display: flex;
      justify-content: space-between;
      align-items: baseline;
      gap: 10px;
      flex-wrap: wrap;
      margin-bottom: 10px;
    }
    .ms-change-drivers-title {
      font-size: 0.94rem;
      font-weight: 700;
      color: var(--text);
      letter-spacing: 0.01em;
    }
    .ms-change-drivers-sub {
      font-size: 0.76rem;
      color: var(--muted);
    }
    .ms-change-drivers-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: 10px;
    }
    .ms-driver-group {
      border: 1px solid var(--line);
      border-radius: 9px;
      padding: 10px 12px;
      background: color-mix(in srgb, var(--panel-soft) 88%, transparent);
    }
    .ms-driver-group-title {
      font-size: 0.72rem;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--muted);
      margin-bottom: 6px;
    }
    .ms-driver-list {
      list-style: none;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      gap: 5px;
    }
    .ms-driver-row {
      display: grid;
      grid-template-columns: minmax(0, 1fr) 60px 90px;
      align-items: center;
      gap: 8px;
      font-size: 0.78rem;
    }
    .ms-driver-name {
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      color: var(--text);
    }
    .ms-driver-rail {
      position: relative;
      height: 6px;
      background: color-mix(in srgb, var(--bg-alt) 75%, transparent);
      border-radius: 3px;
      overflow: hidden;
    }
    .ms-driver-bar {
      position: absolute;
      top: 0;
      bottom: 0;
      left: 0;
      border-radius: 3px;
    }
    .ms-driver-bar--up {
      background: color-mix(in srgb, var(--error) 80%, transparent);
    }
    .ms-driver-bar--down {
      background: color-mix(in srgb, var(--ok) 80%, transparent);
    }
    .ms-driver-value {
      text-align: right;
      font-size: 0.76rem;
    }
    .ms-driver-row[data-direction="up"] .ms-driver-value { color: var(--error); }
    .ms-driver-row[data-direction="down"] .ms-driver-value { color: var(--ok); }
    .ms-baseline-picker {
      border: 1px solid var(--line);
      border-radius: 11px;
      padding: 10px 14px;
      background: color-mix(in srgb, var(--panel-alt) 70%, transparent);
      margin-bottom: 12px;
      display: flex;
      flex-direction: column;
      gap: 8px;
    }
    .ms-baseline-picker-head {
      display: flex;
      gap: 10px;
      align-items: center;
      flex-wrap: wrap;
    }
    .ms-baseline-picker-title {
      font-size: 0.72rem;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      color: var(--muted);
    }
    .ms-baseline-active {
      font-size: 0.82rem;
      color: var(--text);
      overflow-wrap: anywhere;
    }
    .ms-baseline-status {
      font-size: 0.7rem;
      padding: 2px 8px;
      border-radius: 999px;
      border: 1px solid var(--line);
      background: color-mix(in srgb, var(--panel-soft) 90%, transparent);
      color: var(--muted);
      text-transform: uppercase;
      letter-spacing: 0.06em;
      font-weight: 700;
    }
    .ms-baseline-status--ok {
      color: var(--ok);
      border-color: color-mix(in srgb, var(--ok) 55%, var(--line));
    }
    .ms-baseline-status--not_requested,
    .ms-baseline-status--baseline_missing {
      color: var(--muted);
    }
    .ms-baseline-candidates-title {
      font-size: 0.74rem;
      color: var(--muted);
      display: block;
      margin-bottom: 4px;
    }
    .ms-baseline-candidates-list {
      list-style: none;
      margin: 0;
      padding: 0;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }
    .ms-baseline-candidate {
      display: grid;
      grid-template-columns: minmax(0, 1fr) minmax(100px, auto) auto;
      gap: 10px;
      align-items: center;
      padding: 5px 8px;
      border-radius: 7px;
      background: color-mix(in srgb, var(--panel-soft) 90%, transparent);
      border: 1px solid var(--line);
    }
    .ms-baseline-candidate.is-active {
      border-color: color-mix(in srgb, var(--accent) 60%, var(--line));
      background: color-mix(in srgb, var(--accent) 16%, var(--panel-soft));
    }
    .ms-baseline-candidate-meta {
      font-size: 0.72rem;
      color: var(--muted);
      text-align: right;
    }
    .ms-baseline-empty {
      font-size: 0.82rem;
      color: var(--muted);
      line-height: 1.5;
    }
    .ms-baseline-empty code {
      background: color-mix(in srgb, var(--panel-soft) 90%, transparent);
      padding: 1px 6px;
      border-radius: 5px;
      font-family: var(--font-mono, "Aptos Mono", "Consolas", monospace);
    }
    .section-header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      gap: 0.8rem;
      margin-bottom: 1.8rem;
    }
    .section-title {
      font-size: 1.88rem;
      font-weight: 400;
      letter-spacing: 0.02em;
      margin: 0;
      border: 0;
      padding: 0;
      display: flex;
      align-items: center;
      gap: 0.55rem;
    }
    .toggle-button {
      background: transparent;
      color: var(--accent);
      border: 1px solid var(--accent);
      padding: 0.35rem 0.9rem;
      border-radius: 22px;
      cursor: pointer;
      transition: var(--transition);
      font-size: 0.78rem;
      font-weight: 600;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      white-space: nowrap;
    }
    .toggle-button:hover {
      background: color-mix(in srgb, var(--accent) 24%, transparent);
      transform: translateY(-1px);
    }
    .collapsible-content {
      max-height: 120000px;
      overflow: hidden;
      opacity: 1;
      transition: max-height 0.45s ease, opacity 0.25s ease;
    }
    .collapsible-content.is-collapsed {
      max-height: 0;
      opacity: 0;
      margin: 0;
      padding: 0;
    }
    .filter-bar {
      display: flex;
      gap: 1rem;
      margin-bottom: 0.9rem;
      padding: 0.85rem;
      background: var(--panel-soft);
      border: 1px solid var(--line);
      border-radius: 8px;
      flex-wrap: wrap;
      align-items: center;
    }
    .filter-item {
      display: flex;
      align-items: center;
      gap: 0.5rem;
      min-width: 220px;
      flex: 1 1 220px;
    }
    .filter-item label {
      font-size: 0.88rem;
      color: var(--muted);
      white-space: nowrap;
      margin: 0;
    }
    .filter-item input,
    .filter-item select {
      -webkit-appearance: none;
      appearance: none;
      min-width: 0;
      width: 100%;
      background: color-mix(in srgb, var(--panel-alt) 90%, var(--bg));
      color: var(--text);
      font-family: inherit;
      font-size: 0.84rem;
      line-height: 1.4;
      padding: 8px 12px;
      border: 1px solid var(--line);
      border-radius: 8px;
      outline: none;
      box-shadow: 0 1px 3px rgba(0, 0, 0, 0.18), inset 0 1px 0 rgba(255, 255, 255, 0.04);
      transition: border-color 120ms ease, box-shadow 120ms ease;
    }
    .filter-item input::placeholder {
      color: var(--text-dim);
      font-style: italic;
    }
    .filter-item input:focus,
    .filter-item select:focus {
      border-color: color-mix(in srgb, var(--accent) 72%, var(--line));
      box-shadow: 0 0 0 2px color-mix(in srgb, var(--accent) 28%, transparent), 0 1px 3px rgba(0, 0, 0, 0.18);
    }
    .filter-item select {
      padding-right: 2.45rem;
      background-image: url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%23a7b6cc' stroke-width='1.6' fill='none' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
      background-repeat: no-repeat;
      background-position: right 10px center;
      cursor: pointer;
    }
    .data-container {
      background: var(--panel-soft);
      border-radius: 12px;
      overflow-x: auto;
      overflow-y: auto;
      max-height: 560px;
      box-shadow: inset 0 2px 8px rgba(0, 0, 0, 0.3);
      margin: 0;
      padding: 0;
      position: relative;
      border: 1px solid var(--line);
      min-width: 0;
      overscroll-behavior: contain;
      clip-path: inset(0 round 12px);
      background-clip: padding-box;
    }
    .data-container::after {
      content: "";
      display: none;
    }
    .table-wrap::-webkit-scrollbar,
    .data-container::-webkit-scrollbar {
      width: 10px;
      height: 10px;
    }
    .table-wrap::-webkit-scrollbar-track,
    .data-container::-webkit-scrollbar-track {
      margin: 12px 0;
      border-radius: 999px;
      background: transparent;
    }
    .table-wrap::-webkit-scrollbar-thumb,
    .data-container::-webkit-scrollbar-thumb {
      min-height: 26px;
      border-radius: 999px;
      border: 2px solid transparent;
      background-clip: content-box;
      background: linear-gradient(180deg, var(--chart-2), var(--chart-1));
    }
    .table-wrap::-webkit-scrollbar-thumb:hover,
    .data-container::-webkit-scrollbar-thumb:hover {
      background: linear-gradient(180deg, var(--chart-3), var(--chart-1));
      background-clip: content-box;
    }
    .modern-table {
      width: 100%;
      border-collapse: separate;
      border-spacing: 0;
      background: transparent;
      margin: 0;
      table-layout: auto;
    }
    .table-header {
      background: linear-gradient(135deg, var(--panel-alt), color-mix(in srgb, var(--panel-alt) 76%, var(--bg)));
      position: sticky;
      top: 0;
      z-index: 10;
    }
    .table-header th {
      padding: 0.6rem 0.9rem;
      font-size: 0.78rem;
      text-transform: uppercase;
      letter-spacing: 0.05em;
    }
    .table-row {
      transition: var(--transition);
      animation: tableSlideIn 0.25s ease-out;
    }
    .table-row:nth-child(odd) {
      animation-delay: 0.03s;
    }
    .table-row:nth-child(even) {
      animation-delay: 0.06s;
    }
    .table-row:hover {
      background: color-mix(in srgb, var(--accent) 16%, transparent);
    }
    .table-row.runtime-drill-target {
      background: color-mix(in srgb, var(--accent) 28%, transparent);
      box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--accent-soft) 70%, transparent);
    }
    .section.runtime-drill-target {
      box-shadow: 0 0 0 2px color-mix(in srgb, var(--accent-soft) 34%, transparent);
      border-radius: 12px;
      transition: box-shadow 200ms ease;
    }
    .table-row td {
      padding: 0.55rem 0.9rem;
      font-size: 0.84rem;
    }
    .code-display {
      background: color-mix(in srgb, var(--bg) 58%, transparent);
      padding: 0.26rem 0.52rem;
      border-radius: 6px;
      font-family: "JetBrains Mono", "Consolas", "Monaco", monospace;
      font-size: 0.74rem;
      color: var(--accent);
      border: 1px solid color-mix(in srgb, var(--accent) 32%, var(--line));
      display: inline-block;
      max-width: 100%;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .size-badge {
      background: linear-gradient(
        135deg,
        color-mix(in srgb, var(--accent) 34%, transparent),
        color-mix(in srgb, var(--accent-soft) 26%, transparent)
      );
      color: var(--accent);
      padding: 0.24rem 0.54rem;
      border-radius: 16px;
      font-size: 0.72rem;
      font-weight: 600;
      display: inline-block;
      border: 1px solid color-mix(in srgb, var(--accent) 44%, var(--line));
      white-space: nowrap;
    }
    .region-badge {
      background: linear-gradient(
        135deg,
        color-mix(in srgb, var(--ok) 34%, transparent),
        color-mix(in srgb, var(--ok) 16%, transparent)
      );
      color: var(--ok);
      padding: 0.2rem 0.5rem;
      border-radius: 12px;
      font-size: 0.72rem;
      font-weight: 600;
      display: inline-block;
      border: 1px solid color-mix(in srgb, var(--ok) 45%, var(--line));
      white-space: nowrap;
    }
    .progress-container {
      height: 12px;
      background: linear-gradient(90deg, var(--bar-track-start), var(--bar-track-end));
      border-radius: 6px;
      overflow: hidden;
      margin: 1.5rem 0;
      box-shadow: inset 0 0 0 1px color-mix(in srgb, var(--line) 74%, transparent);
    }
    .progress-bar {
      display: block;
      height: 100%;
      border-radius: 6px;
      position: relative;
      width: 0;
      transition: width 0.9s ease-out;
      background: linear-gradient(90deg, var(--bar-fill-1), var(--bar-fill-2), var(--bar-fill-3));
      box-shadow: 0 0 10px color-mix(in srgb, var(--accent) 34%, transparent);
    }
    .progress-bar::after {
      content: "";
      position: absolute;
      inset: 0;
      background: linear-gradient(
        120deg,
        transparent 0%,
        color-mix(in srgb, #ffffff 24%, transparent) 35%,
        transparent 70%
      );
      mix-blend-mode: screen;
      opacity: 0.44;
    }
    select {
      appearance: none;
      -webkit-appearance: none;
      -moz-appearance: none;
      border: 1px solid color-mix(in srgb, var(--accent) 34%, var(--line));
      border-radius: 10px;
      color: var(--text);
      background-color: var(--panel-alt);
      background-image:
        linear-gradient(
          180deg,
          color-mix(in srgb, var(--accent) 16%, transparent) 0%,
          color-mix(in srgb, var(--accent-2) 6%, transparent) 100%
        ),
        url("data:image/svg+xml,%3Csvg width='14' height='14' viewBox='0 0 16 16'%3E%3Cpath d='M4 6l4 4 4-4' fill='none' stroke='%237cc6ff' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
      background-repeat: no-repeat, no-repeat;
      background-position: 0 0, calc(100% - 11px) 50%;
      background-size: auto, 14px 14px;
      box-shadow:
        inset 0 1px 0 color-mix(in srgb, #ffffff 11%, transparent),
        inset 0 -1px 0 color-mix(in srgb, #000000 24%, transparent),
        0 6px 16px rgba(2, 8, 20, 0.35);
      transition: border-color 140ms ease, box-shadow 140ms ease, transform 140ms ease;
      cursor: pointer;
    }
    select:hover {
      border-color: color-mix(in srgb, var(--accent) 66%, var(--line));
      box-shadow:
        inset 0 1px 0 color-mix(in srgb, #ffffff 14%, transparent),
        inset 0 -1px 0 color-mix(in srgb, #000000 30%, transparent),
        0 10px 18px rgba(2, 8, 20, 0.42);
    }
    select:focus {
      outline: none;
      border-color: color-mix(in srgb, var(--accent) 76%, var(--line));
      box-shadow:
        inset 0 1px 0 color-mix(in srgb, #ffffff 16%, transparent),
        0 0 0 2px color-mix(in srgb, var(--accent) 34%, transparent),
        0 0 0 6px color-mix(in srgb, var(--accent-2) 14%, transparent);
    }
    select:disabled {
      cursor: not-allowed;
      opacity: 0.62;
      filter: saturate(0.7);
    }
    select::-ms-expand {
      display: none;
    }
    option {
      color: var(--text);
      background: color-mix(in srgb, var(--panel-alt) 94%, #050c17);
    }
    body.manual-light select,
    body.manual-light option {
      color: #12203d;
      background: #f5f9ff;
    }
    body.manual-light select {
      border-color: color-mix(in srgb, var(--accent) 34%, var(--line));
      box-shadow:
        inset 0 1px 0 color-mix(in srgb, #ffffff 72%, transparent),
        inset 0 -1px 0 color-mix(in srgb, #173764 9%, transparent),
        0 8px 16px rgba(17, 47, 92, 0.14);
      background-image:
        linear-gradient(
          180deg,
          color-mix(in srgb, var(--accent) 13%, transparent) 0%,
          color-mix(in srgb, var(--accent-2) 6%, transparent) 100%
        ),
        url("data:image/svg+xml,%3Csvg width='14' height='14' viewBox='0 0 16 16'%3E%3Cpath d='M4 6l4 4 4-4' fill='none' stroke='%232f74f2' stroke-width='1.8' stroke-linecap='round' stroke-linejoin='round'/%3E%3C/svg%3E");
    }
    .label-icon {
      display: inline-flex;
      align-items: center;
      justify-content: center;
      width: var(--icon-shell-size);
      height: var(--icon-shell-size);
      margin-right: 0.48rem;
      border-radius: 999px;
      border: 1px solid color-mix(in srgb, var(--accent) 48%, var(--line));
      background: linear-gradient(
        135deg,
        color-mix(in srgb, var(--accent) 46%, transparent),
        color-mix(in srgb, var(--accent-soft) 28%, transparent)
      );
      vertical-align: middle;
      box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.18);
    }
    .fa-icon {
      width: var(--icon-glyph-size);
      height: var(--icon-glyph-size);
      stroke: #f8eef5;
      fill: none;
      stroke-width: 1.8;
      stroke-linecap: round;
      stroke-linejoin: round;
    }
    .filter-item label .label-icon {
      width: var(--icon-shell-size-compact);
      height: var(--icon-shell-size-compact);
      margin-right: 0.32rem;
    }
    .filter-item label .fa-icon {
      width: var(--icon-glyph-size-compact);
      height: var(--icon-glyph-size-compact);
    }
    .progress-bar.warning {
      background: linear-gradient(90deg, var(--bar-warning-1), var(--bar-warning-2));
      box-shadow: 0 0 10px color-mix(in srgb, var(--warning) 35%, transparent);
    }
    .progress-bar.danger {
      background: linear-gradient(90deg, var(--bar-danger-1), var(--bar-danger-2));
      box-shadow: 0 0 10px color-mix(in srgb, var(--error) 34%, transparent);
    }
    @keyframes tableSlideIn {
      from { opacity: 0; transform: translateY(3px); }
      to { opacity: 1; transform: translateY(0); }
    }
    @media (max-width: 1888px) {
      .report-main {
        margin-left: 60px;
      }
      .quick-links-pane {
        position: fixed;
        left: 0;
        top: 50%;
        transform: translateY(-50%);
        width: 52px;
        max-height: calc(100vh - 24px);
        border-left: 0;
        border-radius: 0 14px 14px 0;
        opacity: 0.76;
        padding: 9px 4px 9px 5px;
        z-index: 86;
      }
      .quick-links-pane::after {
        content: ">";
        position: absolute;
        right: 3px;
        top: 50%;
        transform: translateY(-50%);
        width: 28px;
        height: 28px;
        border-radius: 999px;
        display: grid;
        place-items: center;
        font-size: 1.2rem;
        font-weight: 700;
        color: var(--accent-soft);
        border: 1px solid color-mix(in srgb, var(--line-strong) 86%, transparent);
        background: color-mix(in srgb, var(--panel-alt) 90%, transparent);
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.35);
        pointer-events: none;
        opacity: 0.95;
        transition: opacity 130ms ease, transform 130ms ease;
      }
      .quick-links-pane:hover {
        width: min(248px, calc(100vw - 14px));
        z-index: 92;
      }
      .quick-links-pane:hover::after {
        opacity: 0;
        transform: translateY(-50%) translateX(8px);
      }
      .quick-links {
        display: none;
        grid-template-columns: 1fr;
        max-height: calc(100vh - 90px);
        justify-items: stretch;
        align-content: start;
        padding: 0;
        gap: 6px;
        overflow-x: hidden;
        overflow-y: auto;
        scrollbar-gutter: auto;
      }
      .quick-links-pane:hover .quick-links {
        display: grid;
      }
      .quick-links a {
        position: relative;
        width: 100%;
        min-width: 0;
        justify-content: center;
        text-align: center;
        border-radius: 8px;
        min-height: 30px;
        max-width: 100%;
        padding: 8px 2px;
        box-sizing: border-box;
        color: transparent !important;
        line-height: 0 !important;
        text-indent: 220% !important;
        text-shadow: none !important;
        white-space: nowrap !important;
        overflow: hidden;
        font-size: 0 !important;
      }
      .quick-links-pane:not(:hover):not(:focus-within) .quick-links a,
      .quick-links-pane:not(:hover):not(:focus-within) .quick-links a.active {
        color: transparent !important;
        font-size: 0 !important;
        line-height: 0 !important;
        text-indent: 220% !important;
        text-shadow: none !important;
      }
      .quick-links a::before {
        content: "";
        width: 8px;
        height: 8px;
        border-radius: 999px;
        background: color-mix(in srgb, var(--accent-soft) 74%, var(--line));
        box-shadow: 0 0 8px color-mix(in srgb, var(--accent) 34%, transparent);
      }
      .quick-links a.active::before {
        width: 10px;
        height: 10px;
        background: var(--accent-soft);
      }
      .quick-links-pane:hover .quick-links a {
        justify-content: center;
        text-align: center;
        padding: 8px 12px;
        color: var(--text) !important;
        line-height: 1.2 !important;
        text-indent: 0 !important;
        font-size: 0.8rem !important;
        white-space: normal !important;
        overflow: hidden;
      }
      .quick-links-pane:hover .quick-links a::before {
        content: none;
      }
      .quick-links-title {
        display: none;
        opacity: 0;
        max-height: 0;
        padding: 0;
        margin: 0;
        overflow: hidden;
        transition: opacity 120ms ease, max-height 160ms ease, padding 160ms ease;
      }
      .quick-links-pane:hover .quick-links-title {
        display: block;
        opacity: 1;
        max-height: 24px;
        padding: 4px 6px 0;
      }
      .header-controls {
        width: 100%;
        justify-content: stretch;
        flex-direction: row;
      }
      .header-action {
        width: calc(50% - 0.25rem);
        text-align: center;
      }
      .memory-layout-stage {
        grid-template-columns: 1fr;
      }
      .ms-layout-canvas-card {
        --embedded-minimap-width: clamp(170px, 20vw, 232px);
      }
    }
    @media (min-width: 761px) {
      .header {
        margin-left: 60px;
        width: calc(100% - 60px);
      }
      .report-main {
        margin-left: 60px;
      }
      .quick-links-pane {
        position: fixed;
        left: 0;
        top: 50%;
        transform: translateY(-50%);
        width: 52px;
        min-height: clamp(220px, 42vh, 420px);
        max-height: calc(100vh - 24px);
        border-left: 0;
        border-radius: 0 14px 14px 0;
        opacity: 1;
        padding: 9px 4px 9px 5px;
        z-index: 94;
        overflow: hidden;
        isolation: isolate;
        background: color-mix(in srgb, var(--panel) 96%, rgba(4, 10, 22, 1));
        backdrop-filter: none;
        box-shadow: 0 10px 28px rgba(0, 0, 0, 0.44);
        border-top: 1px solid color-mix(in srgb, var(--line) 70%, transparent);
        border-right: 1px solid color-mix(in srgb, var(--line-strong) 54%, transparent);
        border-bottom: 1px solid color-mix(in srgb, var(--line) 70%, transparent);
      }
      .quick-links-pane::before {
        content: "";
        position: absolute;
        inset: 0;
        z-index: 2;
        background: color-mix(in srgb, var(--panel) 97%, rgba(4, 10, 22, 1));
        opacity: 1;
        transition: opacity 120ms ease;
        pointer-events: none;
      }
      .quick-links-pane::after {
        content: "\\276F";
        position: absolute;
        right: 7px;
        top: 50%;
        transform: translateY(-50%);
        width: 34px;
        height: 34px;
        border-radius: 999px;
        display: grid;
        place-items: center;
        font-size: 1.55rem;
        font-weight: 900;
        line-height: 1;
        color: var(--accent-soft);
        border: 2px solid color-mix(in srgb, var(--line-strong) 86%, transparent);
        background: color-mix(in srgb, var(--panel-alt) 90%, transparent);
        box-shadow: 0 6px 16px rgba(0, 0, 0, 0.35);
        pointer-events: none;
        opacity: 0.95;
        z-index: 3;
        transition: opacity 120ms ease, transform 120ms ease;
      }
      .quick-links-pane > .quick-links-title,
      .quick-links-pane > .header-controls,
      .quick-links-pane > .quick-links {
        position: relative;
        z-index: 1;
      }
      .quick-links-pane .quick-links-title,
      .quick-links-pane .header-controls,
      .quick-links-pane .quick-links {
        display: none !important;
      }
      .quick-links-pane:not(:hover):not(:focus-within) > .quick-links-title,
      .quick-links-pane:not(:hover):not(:focus-within) > .header-controls,
      .quick-links-pane:not(:hover):not(:focus-within) > .quick-links {
        display: none !important;
      }
      .quick-links-pane:hover,
      .quick-links-pane:focus-within {
        width: min(282px, calc(100vw - 16px));
        z-index: 98;
        opacity: 1;
        padding: 12px 10px 10px 12px;
        background: linear-gradient(
          165deg,
          color-mix(in srgb, var(--panel-alt) 90%, rgba(6, 13, 28, 1)) 0%,
          color-mix(in srgb, var(--panel-soft) 95%, rgba(7, 16, 34, 1)) 100%
        );
        border-top-color: color-mix(in srgb, var(--line-strong) 80%, transparent);
        border-right-color: color-mix(in srgb, var(--accent) 42%, var(--line));
        border-bottom-color: color-mix(in srgb, var(--line-strong) 80%, transparent);
        box-shadow: 0 18px 40px rgba(0, 0, 0, 0.52);
      }
      .quick-links-pane:hover::before,
      .quick-links-pane:focus-within::before {
        opacity: 0;
      }
      .quick-links-pane:hover::after,
      .quick-links-pane:focus-within::after {
        opacity: 0;
        transform: translateY(-50%) translateX(10px);
      }
      .quick-links-pane:hover .quick-links-title,
      .quick-links-pane:focus-within .quick-links-title {
        display: flex !important;
        align-items: center;
        gap: 0.5rem;
        margin: 0 4px 0.5rem;
        padding: 0.35rem 0.1rem 0.52rem;
        font-size: 0.71rem;
        font-weight: 700;
        letter-spacing: 0.13em;
        text-transform: uppercase;
        color: color-mix(in srgb, var(--muted) 82%, #d7e5ff);
        border-bottom: 1px solid color-mix(in srgb, var(--line) 72%, transparent);
      }
      .quick-links-pane:hover .quick-links-title::before,
      .quick-links-pane:focus-within .quick-links-title::before {
        content: "";
        width: 0.52rem;
        height: 0.52rem;
        border-radius: 999px;
        background: linear-gradient(
          180deg,
          color-mix(in srgb, var(--accent-soft) 78%, #b9d7ff),
          color-mix(in srgb, var(--accent) 85%, #6fb8ff)
        );
        box-shadow: 0 0 10px color-mix(in srgb, var(--accent-soft) 38%, transparent);
      }
      .quick-links-pane:hover .header-controls,
      .quick-links-pane:focus-within .header-controls {
        display: grid !important;
        grid-template-columns: 1fr;
        gap: 0.42rem;
        margin: 0 4px 0.62rem;
      }
      .quick-links-pane:hover .header-action,
      .quick-links-pane:focus-within .header-action {
        width: 100%;
        min-height: 30px;
        border-radius: 9px;
        padding: 0.38rem 0.62rem;
        font-size: 0.66rem;
        letter-spacing: 0.08em;
        text-transform: uppercase;
        font-weight: 700;
        color: color-mix(in srgb, var(--text) 90%, #eaf2ff);
        background: linear-gradient(
          160deg,
          color-mix(in srgb, var(--accent) 34%, rgba(14, 42, 80, 1)),
          color-mix(in srgb, var(--accent-soft) 25%, rgba(24, 50, 88, 1))
        );
        border: 1px solid color-mix(in srgb, var(--line-strong) 65%, transparent);
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.06), 0 6px 14px rgba(0, 0, 0, 0.24);
        text-align: center;
      }
      .quick-links-pane:hover .header-action:hover,
      .quick-links-pane:focus-within .header-action:hover {
        border-color: color-mix(in srgb, var(--accent-soft) 68%, var(--line));
        filter: brightness(1.08);
      }
      .quick-links-pane:hover .quick-links,
      .quick-links-pane:focus-within .quick-links {
        display: grid !important;
        grid-template-columns: 1fr;
        gap: 0.44rem;
        max-height: calc(100vh - 218px);
        overflow-y: auto;
        overflow-x: hidden;
        padding: 0 4px 4px;
        margin: 0;
        scrollbar-gutter: stable both-edges;
      }
      .quick-links-pane:hover .quick-links a,
      .quick-links-pane:focus-within .quick-links a {
        display: flex !important;
        align-items: center;
        justify-content: flex-start;
        gap: 0.5rem;
        width: 100%;
        min-width: 0;
        min-height: 35px;
        border-radius: 10px;
        border: 1px solid color-mix(in srgb, var(--line) 84%, transparent);
        background: linear-gradient(
          130deg,
          color-mix(in srgb, var(--panel-alt) 80%, rgba(10, 24, 45, 1)),
          color-mix(in srgb, var(--panel-soft) 88%, rgba(13, 27, 50, 1))
        );
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.05);
        padding: 0.48rem 0.72rem 0.48rem 0.78rem;
        color: var(--text) !important;
        font-size: 0.78rem !important;
        font-weight: 600;
        line-height: 1.28 !important;
        text-align: left;
        text-indent: 0 !important;
        text-shadow: none !important;
        white-space: normal !important;
        overflow: hidden;
        text-overflow: clip;
      }
      .quick-links-pane:hover .quick-links a::before,
      .quick-links-pane:focus-within .quick-links a::before {
        content: "";
        width: 0.42rem;
        height: 0.42rem;
        border-radius: 999px;
        flex: 0 0 auto;
        background: color-mix(in srgb, var(--accent-soft) 80%, #dbe8ff);
        box-shadow: 0 0 9px color-mix(in srgb, var(--accent) 40%, transparent);
      }
      .quick-links-pane:hover .quick-links a:hover,
      .quick-links-pane:focus-within .quick-links a:hover {
        border-color: color-mix(in srgb, var(--accent-soft) 66%, var(--line));
        background: linear-gradient(
          132deg,
          color-mix(in srgb, var(--accent) 42%, rgba(24, 53, 90, 1)),
          color-mix(in srgb, var(--accent-soft) 34%, rgba(36, 65, 102, 1))
        );
        transform: translateY(-1px);
      }
      .quick-links-pane:hover .quick-links a.active,
      .quick-links-pane:focus-within .quick-links a.active {
        border-color: color-mix(in srgb, var(--accent-soft) 84%, var(--line));
        background: linear-gradient(
          132deg,
          color-mix(in srgb, var(--accent) 52%, rgba(24, 56, 96, 1)),
          color-mix(in srgb, var(--accent-soft) 42%, rgba(42, 78, 116, 1))
        );
        box-shadow: inset 0 1px 0 rgba(255, 255, 255, 0.07), 0 0 0 1px color-mix(in srgb, var(--accent-soft) 24%, transparent);
      }
    }
    @media (min-width: 2560px) {
      .header {
        margin-left: 60px;
        width: calc(100% - 60px);
      }
      .report-main {
        margin-left: 60px;
      }
      .grid {
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
      }
      .charts {
        grid-template-columns: repeat(auto-fit, minmax(460px, 1fr));
      }
      .region-grid {
        grid-template-columns: repeat(auto-fit, minmax(500px, 1fr));
      }
      .stats-grid {
        grid-template-columns: repeat(auto-fit, minmax(360px, 1fr));
      }
      .chart {
        height: clamp(320px, 32vh, 560px);
      }
      .table-wrap {
        max-height: clamp(560px, 65vh, 1000px);
      }
    }
    @media (min-width: 761px) and (max-width: 1200px) {
      .quick-links-pane {
        width: 52px;
      }
      .quick-links-pane:hover,
      .quick-links-pane:focus-within {
        width: min(240px, calc(100vw - 16px));
      }
      .header,
      .report-main {
        margin-left: 56px;
      }
      .charts {
        grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
      }
      .region-grid {
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
      }
    }
    @media (max-width: 760px) {
      .header {
        margin-left: 0;
        width: auto;
      }
      .report-main {
        margin-left: 0;
      }
      body {
        --icon-shell-size: 32px;
        --icon-glyph-size: 17px;
        --icon-shell-size-compact: 28px;
        --icon-glyph-size-compact: 15px;
        --icon-shell-size-region: 32px;
        --icon-glyph-size-region: 17px;
        --header-icon-size: 44px;
        --header-inline-icon-size: 20px;
      }
      .wrap {
        padding: 12px;
      }
      .header {
        padding: 1.35rem 1.25rem;
        margin-bottom: 0.7rem;
      }
      .header h1 {
        font-size: 1.75rem;
        line-height: 1.18;
      }
      .header-controls {
        flex-direction: column;
      }
      .header-action {
        width: 100%;
        text-align: center;
      }
      .subtitle {
        gap: 0.55rem;
      }
      .subtitle span {
        font-size: 0.9rem;
      }
      .stats-grid {
        grid-template-columns: 1fr;
      }
      .section-header {
        flex-direction: column;
        align-items: stretch;
      }
      .toggle-button {
        width: 100%;
      }
      .filter-item {
        min-width: 100%;
      }
      th, td {
        font-size: 0.82rem;
      }
      canvas.chart {
        height: clamp(180px, 26vh, 280px);
      }
      .toolbar input,
      .toolbar select {
        min-width: 100%;
      }
      .toolbar {
        flex-direction: column;
        align-items: stretch;
      }
      .quick-links {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(110px, 1fr));
        max-height: none;
        overflow-y: visible;
        opacity: 1;
        visibility: visible;
        pointer-events: auto;
      }
      .quick-links a {
        justify-content: center;
        text-align: center;
        border-radius: 999px;
        color: var(--text) !important;
        line-height: 1.2 !important;
        text-indent: 0 !important;
        text-shadow: none !important;
        white-space: normal !important;
        overflow: hidden;
        font-size: 0.76rem !important;
        padding: 8px 10px;
      }
      .quick-links a::before {
        content: none;
      }
      .quick-links-pane {
        position: static;
        transform: none;
        width: 100%;
        max-height: none;
        border-left: 1px solid var(--line);
        border-radius: 12px;
        opacity: 1;
        padding: 10px;
        z-index: auto;
      }
      .quick-links-pane::after {
        content: none;
      }
      .quick-links-title {
        display: block;
        opacity: 1;
        max-height: none;
        padding: 4px 6px 0;
        margin: 0;
        overflow: visible;
        visibility: visible;
        pointer-events: auto;
      }
      .quick-links-pane:hover .quick-links-title,
      .quick-links-pane:focus-within .quick-links-title {
        opacity: 1;
        max-height: none;
        padding: 4px 6px 0;
      }
      .quick-links-pane:hover .quick-links a,
      .quick-links-pane:focus-within .quick-links a {
        justify-content: center;
        text-align: center;
        border-radius: 999px;
        color: var(--text) !important;
        line-height: 1.2 !important;
        text-indent: 0 !important;
        text-shadow: none !important;
        white-space: normal !important;
        overflow: hidden;
        font-size: 0.76rem !important;
        padding: 8px 10px;
      }
      .quick-links-pane:not(:hover):not(:focus-within) .quick-links a,
      .quick-links-pane:not(:hover):not(:focus-within) .quick-links a.active {
        color: var(--text) !important;
        font-size: 0.76rem !important;
        line-height: 1.2 !important;
        text-indent: 0 !important;
        text-shadow: none !important;
        white-space: normal !important;
      }
      .quick-links a {
        font-size: 0.76rem;
      }
      .ms-composite-svg {
        min-height: 320px;
        height: auto;
      }
      .ms-layout-canvas-card {
        --embedded-minimap-width: 100%;
      }
      .ms-layout-canvas-body {
        padding-right: 8px;
      }
      .memory-layout-minimap.memory-layout-minimap--embedded {
        position: static;
        top: auto;
        right: auto;
        bottom: auto;
        width: 100%;
        margin-top: 8px;
        min-height: 220px;
        max-height: none;
      }
      .memory-layout-minimap.memory-layout-minimap--embedded .ms-global-minimap-svg {
        min-height: 220px;
        height: 220px;
      }
      .ms-focus-controls select {
        min-width: 100%;
      }
      .memory-layout-side-panel {
        width: 100vw;
      }
    }
    :focus-visible {
      outline: none;
      box-shadow: var(--ring);
      border-radius: var(--radius-sm);
    }
    .ms-visually-hidden {
      position: absolute !important;
      width: 1px; height: 1px;
      margin: -1px; padding: 0;
      overflow: hidden; clip: rect(0 0 0 0);
      white-space: nowrap; border: 0;
    }
    .ms-appbar {
      position: sticky;
      top: 0;
      z-index: 60;
      display: flex;
      align-items: center;
      gap: var(--space-3);
      height: var(--appbar-height);
      padding: 0 var(--space-5);
      background: color-mix(in srgb, var(--bg-alt) 86%, transparent);
      backdrop-filter: saturate(1.3) blur(10px);
      -webkit-backdrop-filter: saturate(1.3) blur(10px);
      border-bottom: 1px solid color-mix(in srgb, var(--line) 70%, transparent);
      box-shadow: var(--elev-1);
    }
    .ms-appbar-brand {
      display: flex;
      align-items: center;
      gap: var(--space-2);
      font-weight: 700;
      font-size: var(--type-md);
      letter-spacing: 0.3px;
      color: var(--text);
      text-transform: uppercase;
    }
    .ms-appbar-brand .ms-appbar-dot {
      width: 10px; height: 10px; border-radius: 50%;
      background: linear-gradient(135deg, var(--accent-2), var(--accent));
      box-shadow: 0 0 10px color-mix(in srgb, var(--accent) 50%, transparent);
    }
    .ms-appbar-meta {
      display: flex;
      align-items: center;
      gap: var(--space-2);
      color: var(--muted);
      font-size: var(--type-sm);
      min-width: 0;
      flex: 1 1 auto;
      overflow: hidden;
    }
    .ms-appbar-chip {
      display: inline-flex;
      align-items: center;
      gap: 6px;
      padding: 3px 10px;
      border-radius: var(--radius-pill);
      background: color-mix(in srgb, var(--panel) 80%, transparent);
      border: 1px solid color-mix(in srgb, var(--line) 60%, transparent);
      color: var(--text);
      font-weight: 500;
      white-space: nowrap;
      max-width: 30ch;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .ms-appbar-chip.is-license-active { color: var(--ok); border-color: color-mix(in srgb, var(--ok) 45%, transparent); }
    .ms-appbar-chip.is-license-trial { color: var(--warning); border-color: color-mix(in srgb, var(--warning) 45%, transparent); }
    .ms-appbar-chip.is-license-free { color: var(--text-dim); border-color: color-mix(in srgb, var(--text-dim) 45%, transparent); }
    .ms-appbar-chip.is-license-dev { color: var(--accent-2); border-color: color-mix(in srgb, var(--accent-2) 55%, transparent); }
    .ms-appbar-chip.is-license-expired,
    .ms-appbar-chip.is-license-invalid,
    .ms-appbar-chip.is-license-revoked { color: var(--error); border-color: color-mix(in srgb, var(--error) 55%, transparent); }
    .ms-appbar-tools {
      display: flex;
      align-items: center;
      gap: var(--space-2);
      flex: 0 0 auto;
    }
    .ms-appbar-btn {
      appearance: none;
      border: 1px solid color-mix(in srgb, var(--line) 60%, transparent);
      background: color-mix(in srgb, var(--panel) 80%, transparent);
      color: var(--text);
      padding: 6px 12px;
      border-radius: var(--radius-sm);
      font-size: var(--type-sm);
      font-weight: 600;
      cursor: pointer;
      display: inline-flex;
      align-items: center;
      gap: 6px;
      transition: background 0.18s ease, border-color 0.18s ease, color 0.18s ease;
    }
    .ms-appbar-btn:hover {
      border-color: color-mix(in srgb, var(--accent) 55%, transparent);
      color: var(--accent);
    }
    .ms-appbar-btn kbd {
      font-family: var(--font-mono);
      font-size: 11px;
      background: color-mix(in srgb, var(--bg) 75%, transparent);
      border: 1px solid color-mix(in srgb, var(--line) 50%, transparent);
      padding: 1px 5px;
      border-radius: 4px;
      color: var(--muted);
    }
    .ms-appbar-jump-wrap {
      position: relative;
    }
    .ms-appbar-jump {
      position: absolute;
      right: 0;
      top: calc(100% + 6px);
      min-width: 240px;
      background: var(--panel);
      border: 1px solid color-mix(in srgb, var(--line) 80%, transparent);
      border-radius: var(--radius-md);
      box-shadow: var(--elev-3);
      padding: 6px;
      display: none;
      z-index: 70;
    }
    .ms-appbar-jump.is-open {
      display: flex;
      flex-direction: column;
      gap: 2px;
    }
    .ms-appbar-jump a,
    .ms-appbar-jump button,
    .ms-appbar-jump [role="menuitem"] {
      display: block;
      width: 100%;
      box-sizing: border-box;
      appearance: none;
      -webkit-appearance: none;
      background: transparent;
      border: 1px solid transparent;
      padding: 8px 12px;
      border-radius: var(--radius-sm);
      color: var(--text);
      text-decoration: none;
      font-family: inherit;
      font-size: var(--type-sm);
      font-weight: 500;
      text-align: left;
      line-height: 1.35;
      cursor: pointer;
      white-space: nowrap;
    }
    .ms-appbar-jump a:hover,
    .ms-appbar-jump a:focus-visible,
    .ms-appbar-jump button:hover,
    .ms-appbar-jump button:focus-visible,
    .ms-appbar-jump [role="menuitem"]:hover,
    .ms-appbar-jump [role="menuitem"]:focus-visible {
      background: color-mix(in srgb, var(--accent) 18%, transparent);
      border-color: color-mix(in srgb, var(--accent) 32%, transparent);
      color: var(--accent);
      outline: none;
    }
    .ms-insights-hero {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
      gap: var(--space-4);
      margin-bottom: var(--space-5);
    }
    .ms-insight-card {
      position: relative;
      display: flex;
      flex-direction: column;
      gap: var(--space-2);
      padding: var(--space-4) var(--space-5);
      border-radius: var(--radius-lg);
      background: var(--hero-card-bg);
      border: 1px solid var(--hero-card-border);
      box-shadow: var(--elev-2);
      overflow: hidden;
      cursor: pointer;
      transition: transform 0.22s ease, border-color 0.22s ease, box-shadow 0.22s ease;
      text-align: left;
      color: inherit;
      font: inherit;
    }
    .ms-insight-card:hover {
      transform: translateY(-2px);
      border-color: color-mix(in srgb, var(--accent) 55%, transparent);
      box-shadow: var(--elev-3);
    }
    .ms-insight-card[data-severity="ok"]    { background: var(--hero-ok-bg); }
    .ms-insight-card[data-severity="warning"] { background: var(--hero-warning-bg); }
    .ms-insight-card[data-severity="danger"] { background: var(--hero-danger-bg); }
    .ms-insight-card[data-severity="info"]  { background: var(--hero-accent-bg); }
    .ms-insight-card::before {
      content: "";
      position: absolute;
      inset: 0 auto 0 0;
      width: 3px;
      background: linear-gradient(180deg, var(--accent-2), var(--accent));
      opacity: 0.9;
    }
    .ms-insight-card[data-severity="danger"]::before  { background: linear-gradient(180deg, var(--error), color-mix(in srgb, var(--error) 60%, var(--accent))); }
    .ms-insight-card[data-severity="warning"]::before { background: linear-gradient(180deg, var(--warning), color-mix(in srgb, var(--warning) 60%, var(--accent))); }
    .ms-insight-card[data-severity="ok"]::before      { background: linear-gradient(180deg, var(--ok), color-mix(in srgb, var(--ok) 60%, var(--accent))); }
    .ms-insight-label {
      display: flex;
      align-items: center;
      gap: 6px;
      text-transform: uppercase;
      letter-spacing: 0.14em;
      color: var(--muted);
      font-size: var(--type-xs);
      font-weight: 700;
    }
    .ms-insight-title {
      font-size: var(--type-lg);
      font-weight: 700;
      color: var(--text);
      line-height: var(--leading-tight);
      word-break: break-word;
    }
    .ms-insight-title.is-mono {
      font-family: var(--font-mono);
      font-size: var(--type-md);
    }
    .ms-insight-metric {
      font-size: var(--type-2xl);
      font-weight: 700;
      letter-spacing: -0.01em;
      color: var(--text);
      line-height: 1;
    }
    .ms-insight-metric .ms-insight-unit {
      font-size: var(--type-sm);
      font-weight: 600;
      color: var(--muted);
      margin-left: 6px;
      letter-spacing: 0;
    }
    .ms-insight-hint {
      color: var(--muted);
      font-size: var(--type-sm);
      line-height: var(--leading-normal);
    }
    .ms-insight-card .ms-insight-cta {
      margin-top: auto;
      color: var(--accent);
      font-size: var(--type-xs);
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.12em;
      display: inline-flex;
      align-items: center;
      gap: 4px;
    }
    .ms-insight-card[disabled],
    .ms-insight-card.is-empty {
      cursor: default;
      opacity: 0.78;
    }
    .ms-insight-card[disabled]:hover,
    .ms-insight-card.is-empty:hover {
      transform: none;
      border-color: var(--hero-card-border);
      box-shadow: var(--elev-2);
    }
    .ms-palette-backdrop {
      position: fixed;
      inset: 0;
      background: color-mix(in srgb, #05080f 72%, transparent);
      display: none;
      align-items: flex-start;
      justify-content: center;
      padding-top: 12vh;
      z-index: 90;
    }
    .ms-palette-backdrop.is-open {
      display: flex;
    }
    .ms-palette {
      width: min(640px, 92vw);
      max-height: 70vh;
      background: var(--panel);
      border: 1px solid color-mix(in srgb, var(--line) 80%, transparent);
      border-radius: var(--radius-lg);
      box-shadow: var(--elev-3);
      display: flex;
      flex-direction: column;
      overflow: hidden;
    }
    .ms-palette-search {
      display: flex;
      align-items: center;
      gap: var(--space-3);
      padding: var(--space-3) var(--space-4);
      border-bottom: 1px solid color-mix(in srgb, var(--line) 70%, transparent);
    }
    .ms-palette-search svg {
      width: 18px; height: 18px; color: var(--muted);
      flex: 0 0 auto;
    }
    .ms-palette-search input {
      flex: 1 1 auto;
      min-width: 0;
      appearance: none;
      border: 0;
      background: transparent;
      color: var(--text);
      font-size: var(--type-lg);
      font-family: inherit;
      outline: none;
      padding: 6px 0;
    }
    .ms-palette-search input::placeholder {
      color: var(--text-dim);
    }
    .ms-palette-hint {
      color: var(--muted);
      font-size: var(--type-xs);
      font-family: var(--font-mono);
      background: color-mix(in srgb, var(--bg) 60%, transparent);
      border: 1px solid color-mix(in srgb, var(--line) 60%, transparent);
      padding: 2px 6px;
      border-radius: 4px;
    }
    .ms-palette-list {
      list-style: none;
      margin: 0;
      padding: 6px;
      overflow: auto;
      max-height: 56vh;
    }
    .ms-palette-list li {
      display: flex;
      align-items: center;
      gap: 10px;
      padding: 8px 10px;
      border-radius: var(--radius-sm);
      cursor: pointer;
      color: var(--text);
      font-size: var(--type-md);
    }
    .ms-palette-list li.is-active,
    .ms-palette-list li:hover {
      background: color-mix(in srgb, var(--accent) 16%, transparent);
      color: var(--accent);
    }
    .ms-palette-kind {
      font-size: 10px;
      text-transform: uppercase;
      letter-spacing: 0.14em;
      padding: 2px 6px;
      border-radius: var(--radius-pill);
      border: 1px solid color-mix(in srgb, var(--line) 60%, transparent);
      color: var(--muted);
      flex: 0 0 auto;
    }
    .ms-palette-label {
      flex: 1 1 auto;
      min-width: 0;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
    }
    .ms-palette-hint-right {
      color: var(--muted);
      font-size: var(--type-xs);
      font-family: var(--font-mono);
    }
    .ms-palette-empty {
      padding: 22px 16px;
      color: var(--muted);
      font-size: var(--type-sm);
      text-align: center;
    }
    .ms-address-popover {
      position: fixed;
      top: calc(var(--appbar-height) + 6px);
      right: var(--space-5);
      width: min(340px, 92vw);
      background: var(--panel);
      border: 1px solid color-mix(in srgb, var(--line) 80%, transparent);
      border-radius: var(--radius-md);
      box-shadow: var(--elev-3);
      padding: var(--space-3) var(--space-4);
      z-index: 70;
      display: none;
    }
    .ms-address-popover.is-open { display: block; }
    .ms-address-popover label {
      display: block;
      font-size: var(--type-xs);
      text-transform: uppercase;
      letter-spacing: 0.12em;
      color: var(--muted);
      margin-bottom: 6px;
    }
    .ms-address-popover input {
      width: 100%;
      padding: 7px 10px;
      background: color-mix(in srgb, var(--bg) 75%, transparent);
      border: 1px solid color-mix(in srgb, var(--line) 60%, transparent);
      border-radius: var(--radius-sm);
      color: var(--text);
      font-family: var(--font-mono);
      font-size: var(--type-md);
      outline: none;
    }
    .ms-address-popover input:focus {
      border-color: var(--accent);
    }
    .ms-address-result {
      margin-top: 10px;
      font-size: var(--type-sm);
      color: var(--text);
      line-height: var(--leading-normal);
    }
    .ms-address-result .ms-kv {
      display: flex;
      justify-content: space-between;
      gap: 12px;
      padding: 2px 0;
    }
    .ms-address-result .ms-kv span:first-child {
      color: var(--muted);
      text-transform: uppercase;
      font-size: 10px;
      letter-spacing: 0.12em;
    }
    .ms-address-result .ms-kv span:last-child {
      font-family: var(--font-mono);
      color: var(--text);
      text-align: right;
      overflow: hidden;
      text-overflow: ellipsis;
    }
    .ms-address-result.is-miss {
      color: var(--warning);
    }
    .ms-copy-btn {
      appearance: none;
      border: 1px solid color-mix(in srgb, var(--line) 60%, transparent);
      background: color-mix(in srgb, var(--panel) 80%, transparent);
      color: var(--muted);
      padding: 4px 9px;
      border-radius: var(--radius-sm);
      font-size: 11px;
      font-weight: 700;
      letter-spacing: 0.08em;
      text-transform: uppercase;
      cursor: pointer;
      transition: background 0.18s ease, color 0.18s ease;
    }
    .ms-copy-btn:hover {
      color: var(--accent);
      border-color: color-mix(in srgb, var(--accent) 55%, transparent);
    }
    .ms-copy-btn.is-ok {
      color: var(--ok);
      border-color: color-mix(in srgb, var(--ok) 55%, transparent);
    }
    .ms-table-toolbar {
      display: flex;
      align-items: center;
      justify-content: flex-end;
      gap: var(--space-2);
      margin-bottom: 6px;
    }
    .ms-empty {
      display: flex;
      align-items: center;
      justify-content: center;
      flex-direction: column;
      gap: 8px;
      padding: 28px 20px;
      border: 1px dashed color-mix(in srgb, var(--line) 70%, transparent);
      border-radius: var(--radius-md);
      color: var(--muted);
      background: color-mix(in srgb, var(--panel-alt) 55%, transparent);
      font-size: var(--type-sm);
      text-align: center;
    }
    .ms-empty strong {
      color: var(--text);
      font-size: var(--type-md);
    }
  </style>
</head>
<body>
  <svg width="0" height="0" aria-hidden="true" focusable="false" style="position:absolute;left:-9999px;overflow:hidden;">
    <defs>
      <symbol id="icon-microchip" viewBox="0 0 24 24">
        <rect x="7" y="7" width="10" height="10" rx="2"></rect>
        <rect x="10" y="10" width="4" height="4" rx="1"></rect>
        <path d="M9 4v3M12 4v3M15 4v3M9 17v3M12 17v3M15 17v3M4 9h3M4 12h3M4 15h3M17 9h3M17 12h3M17 15h3"></path>
      </symbol>
      <symbol id="icon-chart" viewBox="0 0 24 24">
        <path d="M4 19h16"></path>
        <path d="M7 15v-4"></path>
        <path d="M12 15V7"></path>
        <path d="M17 15v-6"></path>
      </symbol>
      <symbol id="icon-layers" viewBox="0 0 24 24">
        <path d="M12 4 4 8l8 4 8-4-8-4z"></path>
        <path d="M4 12l8 4 8-4"></path>
        <path d="M4 16l8 4 8-4"></path>
      </symbol>
      <symbol id="icon-list" viewBox="0 0 24 24">
        <path d="M9 6h11M9 12h11M9 18h11"></path>
        <circle cx="5" cy="6" r="1"></circle>
        <circle cx="5" cy="12" r="1"></circle>
        <circle cx="5" cy="18" r="1"></circle>
      </symbol>
      <symbol id="icon-filter" viewBox="0 0 24 24">
        <path d="M4 6h16"></path>
        <path d="M7 12h10"></path>
        <path d="M10 18h4"></path>
      </symbol>
      <symbol id="icon-cpu" viewBox="0 0 24 24">
        <rect x="7" y="7" width="10" height="10" rx="2"></rect>
        <path d="M12 9v6M9 12h6"></path>
      </symbol>
      <symbol id="icon-puzzle" viewBox="0 0 24 24">
        <path d="M9 5h6v3a2 2 0 1 1 0 4v3H9v-3a2 2 0 1 0 0-4z"></path>
      </symbol>
      <symbol id="icon-alert" viewBox="0 0 24 24">
        <path d="M12 4 3.8 19h16.4L12 4z"></path>
        <path d="M12 9v5"></path>
        <path d="M12 17h.01"></path>
      </symbol>
      <symbol id="icon-diff" viewBox="0 0 24 24">
        <path d="M7 4v16"></path>
        <path d="M4 7h6"></path>
        <path d="M14 12h6"></path>
        <path d="m17 9-3 3 3 3"></path>
      </symbol>
      <symbol id="icon-diagnostics" viewBox="0 0 24 24">
        <path d="M12 3a9 9 0 1 0 9 9"></path>
        <path d="M12 7v5l3 3"></path>
      </symbol>
      <symbol id="icon-function" viewBox="0 0 24 24">
        <path d="M17 5h-4a4 4 0 0 0-4 4v10"></path>
        <path d="M7 11h8"></path>
      </symbol>
      <symbol id="icon-global" viewBox="0 0 24 24">
        <circle cx="12" cy="12" r="8"></circle>
        <path d="M4 12h16M12 4a13 13 0 0 1 0 16M12 4a13 13 0 0 0 0 16"></path>
      </symbol>
      <symbol id="icon-region" viewBox="0 0 24 24">
        <path d="M4 6h16v4H4zM4 14h10v4H4z"></path>
      </symbol>
      <symbol id="icon-component" viewBox="0 0 24 24">
        <rect x="4" y="4" width="6" height="6" rx="1"></rect>
        <rect x="14" y="4" width="6" height="6" rx="1"></rect>
        <rect x="9" y="14" width="6" height="6" rx="1"></rect>
      </symbol>
      <symbol id="icon-search" viewBox="0 0 24 24">
        <circle cx="11" cy="11" r="6"></circle>
        <path d="m20 20-4.2-4.2"></path>
      </symbol>
      <symbol id="icon-bolt" viewBox="0 0 24 24">
        <path d="M13 3 5 14h6l-1 7 9-12h-6z"></path>
      </symbol>
      <symbol id="icon-memory" viewBox="0 0 24 24">
        <rect x="4" y="7" width="16" height="10" rx="2"></rect>
        <path d="M8 7v10M12 7v10M16 7v10M4 10h16M4 14h16"></path>
      </symbol>
      <symbol id="icon-database" viewBox="0 0 24 24">
        <ellipse cx="12" cy="6" rx="7" ry="3"></ellipse>
        <path d="M5 6v12c0 1.7 3.1 3 7 3s7-1.3 7-3V6"></path>
        <path d="M5 12c0 1.7 3.1 3 7 3s7-1.3 7-3"></path>
      </symbol>
      <symbol id="icon-calendar" viewBox="0 0 24 24">
        <rect x="4" y="5" width="16" height="15" rx="2"></rect>
        <path d="M8 3v4M16 3v4M4 10h16"></path>
      </symbol>
      <symbol id="icon-build" viewBox="0 0 24 24">
        <path d="M14.5 6.5a4.5 4.5 0 0 0-6 6l-5 5a1.4 1.4 0 1 0 2 2l5-5a4.5 4.5 0 0 0 6-6l-2.2 2.2-2.8-.6-.6-2.8z"></path>
      </symbol>
    </defs>
  </svg>
  <div class="ms-appbar" role="banner" aria-label="Report toolbar">
    <div class="ms-appbar-brand">
      <span class="ms-appbar-dot" aria-hidden="true"></span>
      MemScope
    </div>
    <div class="ms-appbar-meta">
      {% set _target = metadata.target_name | default("") %}
      {% if _target and _target != "unknown" %}
      <span class="ms-appbar-chip" title="Target">{{ _target }}</span>
      {% endif %}
      {% set _toolchain = metadata.toolchain_detected | default("") %}
      {% if _toolchain and _toolchain != "unknown" %}
      <span class="ms-appbar-chip" title="Toolchain">{{ _toolchain }}</span>
      {% endif %}
      {% if license_chip_label %}
      <span class="ms-appbar-chip {{ license_chip_css }}" title="License mode">License: {{ license_chip_label }}</span>
      {% endif %}
      <span class="ms-appbar-chip" title="Tool version" style="font-family:var(--font-mono);">v{{ metadata.tool_version }}</span>
    </div>
    <div class="ms-appbar-tools">
      <button id="ms-palette-trigger" class="ms-appbar-btn" type="button" aria-label="Open command palette" title="Search regions / sections / symbols (Ctrl+K)">
        <svg width="14" height="14" aria-hidden="true"><use href="#icon-search"></use></svg>
        Search
        <kbd>Ctrl K</kbd>
      </button>
      <button id="ms-address-trigger" class="ms-appbar-btn" type="button" aria-label="Address inspector" title="Inspect an address">
        <svg width="14" height="14" aria-hidden="true"><use href="#icon-region"></use></svg>
        Address
      </button>
      <div class="ms-appbar-jump-wrap">
        <button id="ms-share-trigger" class="ms-appbar-btn" type="button" aria-haspopup="true" aria-expanded="false" aria-controls="ms-share-menu" title="Share or export">
          Share
        </button>
        <div id="ms-share-menu" class="ms-appbar-jump" role="menu" aria-label="Share and export">
          <button type="button" role="menuitem" data-share-action="copy-link">Copy link to current view</button>
          <button type="button" role="menuitem" data-share-action="copy-markdown">Copy report summary as Markdown</button>
          <button type="button" role="menuitem" data-share-action="download-svg">Download memory layout (SVG)</button>
          <button type="button" role="menuitem" data-share-action="download-png">Download memory layout (PNG)</button>
        </div>
      </div>
      <button id="ms-appbar-theme" class="ms-appbar-btn" type="button" aria-label="Toggle theme">
        Theme
      </button>
    </div>
  </div>
  <div id="ms-address-popover" class="ms-address-popover" role="dialog" aria-label="Address inspector" aria-hidden="true">
    <label for="ms-address-input">Address (hex or decimal)</label>
    <input id="ms-address-input" type="text" placeholder="0x08001234" autocomplete="off" spellcheck="false">
    <div id="ms-address-result" class="ms-address-result">Enter an address to locate the owning region, section, and symbol.</div>
  </div>
  <div class="wrap container">
    <header class="header">
      <h1>
        <svg class="header-title-icon" aria-hidden="true"><use href="#icon-microchip"></use></svg>
        {{ title }}
      </h1>
      {% if metadata.license_mode == "developer-mode" %}
      <div class="watermark">DEVELOPER MODE</div>
      {% elif metadata.license_mode == "trial" %}
      <div class="watermark">TRIAL - FULL FEATURES, EVALUATION ONLY</div>
      {% elif metadata.license_mode == "free" %}
      <div class="watermark">FREE EDITION - paid features locked (--strict / validate / diff / CSV / custom budgets require activation)</div>
      {% elif metadata.license_mode == "expired" %}
      <div class="watermark">LICENSE EXPIRED - ACTIVATION REQUIRED</div>
      {% elif metadata.license_mode == "revoked" %}
      <div class="watermark">LICENSE REVOKED - CONTACT YOUR ADMINISTRATOR</div>
      {% elif metadata.license_mode == "invalid" %}
      <div class="watermark">LICENSE INVALID - CACHED BLOB UNUSABLE</div>
      {% endif %}
      <div class="subtitle">
        {% set _target = metadata.target_name | default("") %}
        {% if _target and _target != "unknown" %}
        <span>
          <svg class="header-inline-icon" aria-hidden="true"><use href="#icon-microchip"></use></svg>
          Target: {{ _target }}
        </span>
        {% endif %}
        {% set _toolchain = metadata.toolchain_detected | default("") %}
        {% if _toolchain and _toolchain != "unknown" %}
        <span>
          <svg class="header-inline-icon" aria-hidden="true"><use href="#icon-build"></use></svg>
          Toolchain: {{ _toolchain }}
        </span>
        {% endif %}
        <span>
          <svg class="header-inline-icon" aria-hidden="true"><use href="#icon-calendar"></use></svg>
          Report Date: {{ metadata.analysis_timestamp }}
        </span>
      </div>
    </header>
    <div class="report-shell">
      <aside class="quick-links-pane" aria-label="Report navigation">
      <p class="quick-links-title">Quick Links</p>
      <div class="header-controls">
        <button id="collapse-all" class="header-action" type="button">Collapse All</button>
        <button id="expand-all" class="header-action" type="button">Expand All</button>
        <button id="toggle-theme" class="header-action" type="button">Use Light Theme</button>
      </div>
      <nav class="quick-links">
        <a href="#memory-layout">Layout</a>
        <a href="#visual-insights">Visuals</a>
        <a href="#region-utilization">Regions</a>
        <a href="#top-contributors">Contributors</a>
        <a href="#top-global-variables">Globals</a>
        <a href="#top-functions">Functions</a>
        <a href="#section-explorer">Sections</a>
        <a href="#component-ownership">Components</a>
        <a href="#issues">Issues</a>
        <a href="#comparison-baseline">Diff</a>
        <a href="#diagnostics">Diagnostics</a>
      </nav>
      </aside>
      <main class="report-main">

    <section class="ms-insights-hero" aria-label="Key insights">
      {% set _risk = insights.top_risk %}
      {% if _risk %}
      <button type="button" class="ms-insight-card" data-severity="{{ _risk.severity_class }}"
              data-jump="#issues" data-issue-text="{{ _risk.match_text }}">
        <span class="ms-insight-label">
          <svg class="fa-icon" aria-hidden="true"><use href="#icon-alert"></use></svg>
          Top Risk - {{ _risk.severity }}
        </span>
        <span class="ms-insight-title">{{ _risk.title }}</span>
        <span class="ms-insight-hint">{{ _risk.hint }}</span>
        <span class="ms-insight-cta">View issue ›</span>
      </button>
      {% else %}
      <div class="ms-insight-card is-empty" data-severity="ok">
        <span class="ms-insight-label">
          <svg class="fa-icon" aria-hidden="true"><use href="#icon-alert"></use></svg>
          Top Risk
        </span>
        <span class="ms-insight-title">All clear</span>
        <span class="ms-insight-hint">No errors or warnings raised by current policies.</span>
      </div>
      {% endif %}

      {% set _grow = insights.biggest_grower %}
      {% if _grow %}
      <button type="button" class="ms-insight-card ms-insight-diff" data-severity="{{ _grow.severity_class }}"
              data-jump="#comparison-baseline">
        <span class="ms-insight-label">
          <svg class="fa-icon" aria-hidden="true"><use href="#icon-diff"></use></svg>
          Biggest Grower vs Baseline
          <span class="ms-diff-pill ms-diff-pill--reg">{{ diff_narrative.regression_count }} reg</span>
          <span class="ms-diff-pill ms-diff-pill--red">{{ diff_narrative.reduction_count }} red</span>
        </span>
        <span class="ms-insight-title is-mono">{{ _grow.name }}</span>
        <span class="ms-insight-metric" data-bytes="{{ _grow.delta_bytes }}">{{ _grow.delta_label }}<span class="ms-insight-unit">B</span></span>
        {% if diff_narrative.spark_entries %}
        <span class="ms-sparkdelta" role="img" aria-label="Top byte-delta drivers">
          {% for entry in diff_narrative.spark_entries %}
          <span class="ms-sparkdelta-track" title="{{ entry.kind }}:{{ entry.name }} {{ entry.delta_label }} B">
            <span class="ms-sparkdelta-bar ms-sparkdelta-bar--{{ entry.direction }}" style="width:{{ entry.ratio_pct }}%"></span>
          </span>
          {% endfor %}
        </span>
        {% endif %}
        <span class="ms-insight-hint">
          Flash {{ diff_narrative.flash_delta_label }} B · RAM {{ diff_narrative.ram_delta_label }} B · {{ _grow.hint }}
        </span>
        <span class="ms-insight-cta">View diff ›</span>
      </button>
      {% else %}
      <div class="ms-insight-card is-empty" data-severity="info">
        <span class="ms-insight-label">
          <svg class="fa-icon" aria-hidden="true"><use href="#icon-diff"></use></svg>
          Diff vs Baseline
        </span>
        <span class="ms-insight-title">No baseline supplied</span>
        <span class="ms-insight-hint">Pass <code>--baseline-json</code> to track build-to-build deltas.</span>
      </div>
      {% endif %}

      {% set _head = insights.tightest_headroom %}
      {% if _head %}
      <button type="button" class="ms-insight-card" data-severity="{{ _head.severity_class }}"
              data-jump="#region-utilization" data-region="{{ _head.region }}">
        <span class="ms-insight-label">
          <svg class="fa-icon" aria-hidden="true"><use href="#icon-memory"></use></svg>
          Tightest Headroom
        </span>
        <span class="ms-insight-title is-mono">{{ _head.region }}</span>
        <span class="ms-insight-metric">{{ _head.percent }}<span class="ms-insight-unit">% used</span></span>
        <span class="ms-insight-hint" data-bytes="{{ _head.free_bytes }}">{{ _head.free_label }} B free of {{ _head.total_label }} B</span>
        <span class="ms-insight-cta">Inspect region ›</span>
      </button>
      {% else %}
      <div class="ms-insight-card is-empty" data-severity="info">
        <span class="ms-insight-label">
          <svg class="fa-icon" aria-hidden="true"><use href="#icon-memory"></use></svg>
          Tightest Headroom
        </span>
        <span class="ms-insight-title">No region utilisation data</span>
        <span class="ms-insight-hint">Region capacity not detected from inputs.</span>
      </div>
      {% endif %}

      {% set _pad = insights.padding_waste %}
      {% if _pad %}
      <button type="button" class="ms-insight-card" data-severity="{{ _pad.severity_class }}"
              data-jump="{{ _pad.jump_hash }}" {% if _pad.region %}data-region="{{ _pad.region }}"{% endif %}>
        <span class="ms-insight-label">
          <svg class="fa-icon" aria-hidden="true"><use href="#icon-layers"></use></svg>
          Padding / Alignment Waste
        </span>
        <span class="ms-insight-metric" data-bytes="{{ _pad.total_bytes }}">{{ _pad.total_label }}<span class="ms-insight-unit">B</span></span>
        <span class="ms-insight-hint">{{ _pad.hint }}</span>
        <span class="ms-insight-cta">{{ _pad.cta }} ›</span>
      </button>
      {% else %}
      <div class="ms-insight-card is-empty" data-severity="ok">
        <span class="ms-insight-label">
          <svg class="fa-icon" aria-hidden="true"><use href="#icon-layers"></use></svg>
          Padding / Alignment Waste
        </span>
        <span class="ms-insight-title">No padding tracked</span>
        <span class="ms-insight-hint">Padding/alignment waste not reported for this build.</span>
      </div>
      {% endif %}
    </section>

    <section class="stats-grid">
      <article class="stat-card">
        <h3><span class="label-icon"><svg class="fa-icon"><use href="#icon-bolt"></use></svg></span>Flash Used</h3>
        <div class="value">{{ summary.total_flash | intcomma }} B</div>
        {% if summary.flash_capacity and summary.flash_capacity > 0 %}
        <div class="stat-cap-bar"><span class="stat-cap-fill" style="width:{{ [summary.flash_util_pct, 100]|min }}%"></span></div>
        <div class="sub-value">{{ summary.flash_util_pct }}% of {{ summary.flash_capacity | intcomma }} B capacity</div>
        {% else %}
        <div class="sub-value">Programmed FLASH footprint</div>
        {% endif %}
      </article>
      <article class="stat-card">
        <h3><span class="label-icon"><svg class="fa-icon"><use href="#icon-memory"></use></svg></span>RAM Used</h3>
        <div class="value">{{ summary.total_ram | intcomma }} B</div>
        {% if summary.ram_capacity and summary.ram_capacity > 0 %}
        <div class="stat-cap-bar"><span class="stat-cap-fill" style="width:{{ [summary.ram_util_pct, 100]|min }}%"></span></div>
        <div class="sub-value">{{ summary.ram_util_pct }}% of {{ summary.ram_capacity | intcomma }} B capacity</div>
        {% else %}
        <div class="sub-value">Runtime RAM footprint</div>
        {% endif %}
      </article>
      <article class="stat-card {% if summary.issue_counts.error > 0 %}critical{% endif %}">
        <h3><span class="label-icon"><svg class="fa-icon"><use href="#icon-alert"></use></svg></span>Errors</h3>
        <div class="value">{{ summary.issue_counts.error }}</div>
        <div class="sub-value">Policy or placement blockers</div>
      </article>
      <article class="stat-card {% if summary.issue_counts.warning > 0 %}critical{% endif %}">
        <h3><span class="label-icon"><svg class="fa-icon"><use href="#icon-alert"></use></svg></span>Warnings</h3>
        <div class="value">{{ summary.issue_counts.warning }}</div>
        <div class="sub-value">Risks needing attention</div>
      </article>
      <article class="stat-card">
        <h3><span class="label-icon"><svg class="fa-icon"><use href="#icon-database"></use></svg></span>Info</h3>
        <div class="value">{{ summary.issue_counts.info }}</div>
        <div class="sub-value">Advisory observations</div>
      </article>
    </section>

    <section class="section" id="memory-layout">
      <div class="section-header">
        <h2 class="section-title"><span class="label-icon"><svg class="fa-icon"><use href="#icon-memory"></use></svg></span>Memory Layout Explorer</h2>
        <button type="button" class="toggle-button" data-target="memory-layout-content">Collapse</button>
      </div>
      <div class="collapsible-content" id="memory-layout-content">
      <div class="memory-layout-shell">
        <div class="memory-layout-meta">
          <div class="memory-layout-meta-item">Contract Version<strong>{{ visualization_summary.schema_version }}</strong></div>
          <div class="memory-layout-meta-item">Regions<strong>{{ visualization_summary.regions_count }}</strong></div>
          <div class="memory-layout-meta-item">Ownership Rows<strong>{{ visualization_summary.ownership_rows }}</strong></div>
          <div class="memory-layout-meta-item">Diff Status<strong>{{ visualization_summary.diff_status }}</strong></div>
        </div>
        <div class="memory-layout-stage">
          <div id="memory-layout-explorer" class="memory-layout-explorer" aria-label="Interactive memory layout explorer"></div>
          <div id="memory-layout-minimap" class="memory-layout-minimap" aria-label="Memory layout minimap"></div>
        </div>
      </div>
      </div>
    </section>

    <section class="section" id="visual-insights">
      <div class="section-header">
        <h2 class="section-title"><span class="label-icon"><svg class="fa-icon"><use href="#icon-chart"></use></svg></span>Visual Insights</h2>
        <button type="button" class="toggle-button" data-target="visual-insights-content">Collapse</button>
      </div>
      <div class="collapsible-content" id="visual-insights-content">
      <div class="charts">
        <div class="chart-card">
          <h3 class="chart-title">Region Utilization Profile</h3>
          <div class="insight-list" id="region-util-chart" data-insight-type="percent"></div>
        </div>
        <div class="chart-card">
          <h3 class="chart-title">Top Symbol Weight</h3>
          <div class="insight-list" id="top-symbol-chart" data-insight-type="bytes"></div>
        </div>
        <div class="chart-card">
          <h3 class="chart-title">Top Component RAM Footprint</h3>
          <div class="insight-list" id="component-ram-chart" data-insight-type="bytes"></div>
        </div>
      </div>
      </div>
    </section>

    <section class="section" id="region-utilization">
      <div class="section-header">
        <h2 class="section-title"><span class="label-icon"><svg class="fa-icon"><use href="#icon-region"></use></svg></span>Region Utilization</h2>
        <button type="button" class="toggle-button" data-target="region-utilization-content">Collapse</button>
      </div>
      <div class="collapsible-content" id="region-utilization-content">
      <div class="region-grid">
        {% for region in regions %}
        <article class="region-card {{ region.level }}">
          <div class="region-header">
            <div class="region-name">
              <span class="label-icon region-chip"><svg class="fa-icon"><use href="#icon-microchip"></use></svg></span>
              <span class="region-label">{{ region.name }}</span>
            </div>
            <div class="region-meta">{{ region.sections_count }} {{ region.sections_label }}</div>
          </div>
          <div class="region-description">{{ region.description }}</div>
          <div class="progress-container">
            <span class="progress-bar {% if region.level == 'danger' %}danger{% elif region.level == 'warning' %}warning{% endif %}" data-width="{{ region.percent_capped }}%"></span>
          </div>
          <div class="progress-info">
            <span>Used: {{ region.used_bytes | intcomma }} B</span>
            <span>Free: {{ region.free_bytes | intcomma }} B</span>
          </div>
          <div class="metrics-divider"></div>
          <div class="progress-info">
            <span>Total: {{ region.total_bytes | intcomma }} B</span>
            <span><strong>{{ region.percent }}%</strong> utilized</span>
          </div>
          <div class="metrics-divider secondary"></div>
          <div class="progress-info">
            <span>Remaining: {{ region.remaining_percent }}%</span>
            <span>Source: {{ region.source_origin }}</span>
          </div>
          {% if region.overflow_bytes > 0 %}
          <div class="overflow-note">Overflow: {{ region.overflow_bytes | intcomma }} B</div>
          {% endif %}
        </article>
        {% endfor %}
      </div>
      </div>
    </section>

    <section class="section" id="top-contributors">
      <div class="section-header">
        <h2 class="section-title"><span class="label-icon"><svg class="fa-icon"><use href="#icon-list"></use></svg></span>Top Contributors</h2>
        <button type="button" class="toggle-button" data-target="top-contributors-content">Collapse</button>
      </div>
      <div class="collapsible-content" id="top-contributors-content">
      <div class="split-grid">
        <div class="data-container">
          <table class="sortable modern-table" id="top-symbols-table">
            <thead class="table-header">
              <tr><th data-sort="text">Symbol</th><th data-sort="num">Size (B)</th></tr>
            </thead>
            <tbody>
              {% for item in top_symbols %}
              <tr class="table-row" data-symbol="{{ item.name }}">
                <td><div class="code-display">{{ item.name }}</div></td>
                <td><span class="size-badge">{{ item.size | intcomma }}</span></td>
              </tr>
              {% endfor %}
            </tbody>
          </table>
        </div>
        <div class="data-container">
          <table class="sortable modern-table" id="top-objects-table">
            <thead class="table-header">
              <tr><th data-sort="text">Object/Archive</th><th data-sort="num">Size (B)</th></tr>
            </thead>
            <tbody>
              {% for item in top_objects %}
              <tr class="table-row" data-object="{{ item.name }}">
                <td><div class="code-display">{{ item.name }}</div></td>
                <td><span class="size-badge">{{ item.size | intcomma }}</span></td>
              </tr>
              {% endfor %}
            </tbody>
          </table>
        </div>
      </div>
      </div>
    </section>

    <section class="section" id="top-global-variables">
      <div class="section-header">
        <h2 class="section-title"><span class="label-icon"><svg class="fa-icon"><use href="#icon-global"></use></svg></span>Top Global Variables</h2>
        <button type="button" class="toggle-button" data-target="top-global-variables-content">Collapse</button>
      </div>
      <div class="collapsible-content" id="top-global-variables-content">
      <div class="filter-bar">
        <div class="filter-item">
          <label for="globals-filter-region"><span class="label-icon"><svg class="fa-icon fas fa-microchip"><use href="#icon-microchip"></use></svg></span>Filter by Region</label>
          <select id="globals-filter-region">
            <option value="">All regions</option>
            {% for region_name in global_region_filters %}
            <option value="{{ region_name }}">{{ region_name }}</option>
            {% endfor %}
          </select>
        </div>
        <div class="filter-item">
          <label for="globals-filter-component"><span class="label-icon"><svg class="fa-icon"><use href="#icon-component"></use></svg></span>Filter by Component</label>
          <select id="globals-filter-component">
            <option value="">All components</option>
            {% for component_name in global_component_filters %}
            <option value="{{ component_name }}">{{ component_name }}</option>
            {% endfor %}
          </select>
        </div>
      </div>
      <div id="globals-filter-count" class="summary-note"></div>
      <div class="data-container">
        <table class="sortable modern-table" id="globals-table">
          <thead class="table-header">
            <tr><th data-sort="text">Name</th><th data-sort="text">Region</th><th data-sort="text">Component</th><th data-sort="text">Object</th><th data-sort="num">Size (B)</th></tr>
          </thead>
          <tbody>
            {% for item in top_globals %}
            <tr class="table-row" data-name="{{ item.name }}" data-object="{{ item.object }}" data-region="{{ item.region }}" data-component="{{ item.component }}">
              <td><div class="code-display">{{ item.name }}</div></td>
              <td><span class="region-badge">{{ item.region }}</span></td>
              <td><span class="region-badge">{{ item.component }}</span></td>
              <td>{{ item.object }}</td>
              <td><span class="size-badge">{{ item.size | intcomma }}</span></td>
            </tr>
            {% endfor %}
          </tbody>
        </table>
      </div>
      </div>
    </section>

    <section class="section" id="top-functions">
      <div class="section-header">
        <h2 class="section-title"><span class="label-icon"><svg class="fa-icon"><use href="#icon-function"></use></svg></span>Top Functions</h2>
        <button type="button" class="toggle-button" data-target="top-functions-content">Collapse</button>
      </div>
      <div class="collapsible-content" id="top-functions-content">
      <div class="filter-bar">
        <div class="filter-item">
          <label for="functions-filter-region"><span class="label-icon"><svg class="fa-icon fas fa-microchip"><use href="#icon-microchip"></use></svg></span>Filter by Region</label>
          <select id="functions-filter-region">
            <option value="">All regions</option>
            {% for region_name in function_region_filters %}
            <option value="{{ region_name }}">{{ region_name }}</option>
            {% endfor %}
          </select>
        </div>
        <div class="filter-item">
          <label for="functions-filter-component"><span class="label-icon"><svg class="fa-icon"><use href="#icon-component"></use></svg></span>Filter by Component</label>
          <select id="functions-filter-component">
            <option value="">All components</option>
            {% for component_name in function_component_filters %}
            <option value="{{ component_name }}">{{ component_name }}</option>
            {% endfor %}
          </select>
        </div>
      </div>
      <div id="functions-filter-count" class="summary-note"></div>
      <div class="data-container">
        <table class="sortable modern-table" id="functions-table">
          <thead class="table-header">
            <tr><th data-sort="text">Name</th><th data-sort="text">Region</th><th data-sort="text">Component</th><th data-sort="text">Object</th><th data-sort="num">Size (B)</th></tr>
          </thead>
          <tbody>
            {% for item in top_functions %}
            <tr class="table-row" data-name="{{ item.name }}" data-object="{{ item.object }}" data-region="{{ item.region }}" data-component="{{ item.component }}">
              <td><div class="code-display">{{ item.name }}</div></td>
              <td><span class="region-badge">{{ item.region }}</span></td>
              <td><span class="region-badge">{{ item.component }}</span></td>
              <td>{{ item.object }}</td>
              <td><span class="size-badge">{{ item.size | intcomma }}</span></td>
            </tr>
            {% endfor %}
          </tbody>
        </table>
      </div>
      </div>
    </section>

    <section class="section" id="section-explorer">
      <div class="section-header">
        <h2 class="section-title"><span class="label-icon"><svg class="fa-icon"><use href="#icon-layers"></use></svg></span>Section Explorer</h2>
        <button type="button" class="toggle-button" data-target="section-explorer-content">Collapse</button>
      </div>
      <div class="collapsible-content" id="section-explorer-content">
      <div class="filter-bar">
        <div class="filter-item">
          <label for="section-filter-text"><span class="label-icon"><svg class="fa-icon"><use href="#icon-search"></use></svg></span>Search</label>
          <input id="section-filter-text" type="search" placeholder="section name or region">
        </div>
        <div class="filter-item">
          <label for="section-filter-region"><span class="label-icon"><svg class="fa-icon fas fa-microchip"><use href="#icon-microchip"></use></svg></span>Filter by Region</label>
          <select id="section-filter-region">
            <option value="">All regions</option>
            {% for region_name in section_region_filters %}
            <option value="{{ region_name }}">{{ region_name }}</option>
            {% endfor %}
          </select>
        </div>
      </div>
      <div id="section-filter-count" class="summary-note"></div>
      <div class="data-container">
        <table class="sortable modern-table" id="sections-table" data-vlist="sections" data-vlist-budget="200">
          <thead class="table-header">
            <tr>
              <th data-sort="text">Section</th>
              <th data-sort="text">Exec Region</th>
              <th data-sort="text">Load Region</th>
              <th data-sort="num">Size (B)</th>
            </tr>
          </thead>
          <tbody>
            {% for section in sections %}
            <tr
              class="table-row"
              data-name="{{ section.name }}"
              data-region="{{ section.execution_region or '' }}"
              data-search="{{ section.search_text }}"
              data-vlist-idx="{{ loop.index0 }}"
            >
              <td><div class="code-display">{{ section.name }}</div></td>
              <td><span class="region-badge">{{ section.execution_region or "-" }}</span></td>
              <td>{{ section.load_region or "-" }}</td>
              <td><span class="size-badge">{{ section.size | intcomma }}</span></td>
            </tr>
            {% endfor %}
          </tbody>
        </table>
        <div class="vlist-footer" data-vlist-footer-for="sections-table" hidden>
          <span class="vlist-footer-note"></span>
          <button type="button" class="vlist-footer-toggle">Show all</button>
        </div>
      </div>
      </div>
    </section>

    <section class="section" id="component-ownership">
      <div class="section-header">
        <h2 class="section-title"><span class="label-icon"><svg class="fa-icon"><use href="#icon-component"></use></svg></span>Component Ownership</h2>
        <button type="button" class="toggle-button" data-target="component-ownership-content">Collapse</button>
      </div>
      <div class="collapsible-content" id="component-ownership-content">
      <div class="data-container">
        <table class="sortable modern-table">
          <thead class="table-header">
            <tr>
              <th data-sort="text">Component</th>
              <th data-sort="num">Flash (B)</th>
              <th data-sort="num">RAM (B)</th>
              <th data-sort="num">Symbols</th>
            </tr>
          </thead>
          <tbody>
            {% for component in components %}
            <tr class="table-row">
              <td><div class="code-display">{{ component.name }}</div></td>
              <td><span class="size-badge">{{ component.total_flash | intcomma }}</span></td>
              <td><span class="size-badge">{{ component.total_ram | intcomma }}</span></td>
              <td>{{ component.symbol_count }}</td>
            </tr>
            {% endfor %}
          </tbody>
        </table>
      </div>
      </div>
    </section>

    <section class="section" id="issues">
      <div class="section-header">
        <h2 class="section-title"><span class="label-icon"><svg class="fa-icon"><use href="#icon-alert"></use></svg></span>Issues and Recommendations</h2>
        <button type="button" class="toggle-button" data-target="issues-content">Collapse</button>
      </div>
      <div class="collapsible-content" id="issues-content">
      <div class="badge-row">
        <span class="badge">Errors: {{ summary.issue_counts.error }}</span>
        <span class="badge">Warnings: {{ summary.issue_counts.warning }}</span>
        <span class="badge">Info: {{ summary.issue_counts.info }}</span>
      </div>
      <div class="filter-bar">
        <div class="filter-item">
          <label for="issue-filter-text"><span class="label-icon"><svg class="fa-icon"><use href="#icon-search"></use></svg></span>Search</label>
          <input id="issue-filter-text" type="search" placeholder="title, category, or description">
        </div>
        <div class="filter-item">
          <label for="issue-filter-severity"><span class="label-icon"><svg class="fa-icon"><use href="#icon-filter"></use></svg></span>Severity</label>
          <select id="issue-filter-severity">
            <option value="">All severities</option>
            <option value="error">error</option>
            <option value="warning">warning</option>
            <option value="info">info</option>
          </select>
        </div>
      </div>
      <div id="issue-filter-count" class="summary-note"></div>
      <div class="data-container">
        <table class="sortable modern-table" id="issues-table" data-vlist="issues" data-vlist-budget="60">
          <thead class="table-header">
            <tr>
              <th data-sort="text">Severity</th>
              <th data-sort="text">Category</th>
              <th data-sort="text">Title</th>
              <th data-sort="text">Description</th>
            </tr>
          </thead>
          <tbody>
            {% for issue in issues %}
            <tr
              class="table-row"
              data-issue-id="{{ issue.id }}"
              data-severity="{{ issue.severity }}"
              data-search="{{ issue.search_text }}"
              data-vlist-idx="{{ loop.index0 }}"
            >
              <td class="issue-{{ issue.severity }}">{{ issue.severity }}</td>
              <td>{{ issue.category }}</td>
              <td>{{ issue.title }}</td>
              <td>{{ issue.description }}</td>
            </tr>
            {% endfor %}
          </tbody>
        </table>
        <div class="vlist-footer" data-vlist-footer-for="issues-table" hidden>
          <span class="vlist-footer-note"></span>
          <button type="button" class="vlist-footer-toggle">Show all</button>
        </div>
      </div>
      </div>
    </section>

    <section class="section" id="comparison-baseline">
      <div class="section-header">
        <h2 class="section-title"><span class="label-icon"><svg class="fa-icon"><use href="#icon-diff"></use></svg></span>Comparison (Baseline)</h2>
        <button type="button" class="toggle-button" data-target="comparison-baseline-content">Collapse</button>
      </div>
      <div class="collapsible-content" id="comparison-baseline-content">
      <div class="ms-baseline-picker" role="region" aria-label="Baseline picker">
        <div class="ms-baseline-picker-head">
          <span class="ms-baseline-picker-title">Active baseline</span>
          <span class="ms-baseline-active is-mono">{{ diff_narrative.baseline_path or "not supplied" }}</span>
          <span class="ms-baseline-status ms-baseline-status--{{ diff_narrative.status }}">{{ diff_narrative.status }}</span>
        </div>
        {% if diff_narrative.baseline_candidates %}
        <div class="ms-baseline-candidates">
          <span class="ms-baseline-candidates-title">Detected candidates in working dir:</span>
          <ul class="ms-baseline-candidates-list">
            {% for cand in diff_narrative.baseline_candidates %}
            <li class="ms-baseline-candidate{% if cand.is_active %} is-active{% endif %}">
              <span class="is-mono">{{ cand.name }}</span>
              <span class="ms-baseline-candidate-meta">{{ cand.size_label }}{% if cand.modified %} · {{ cand.modified }}{% endif %}</span>
              <button type="button" class="ms-copy-btn ms-baseline-copy" data-copy-text="memscope analyze --baseline-json &quot;{{ cand.path }}&quot; --html report.html"
                      aria-label="Copy CLI command to use this baseline">Copy cmd</button>
            </li>
            {% endfor %}
          </ul>
        </div>
        {% elif not diff_narrative.baseline_path %}
        <div class="ms-baseline-empty">
          No baseline JSON candidates detected in the current working directory.
          Pass <code>--baseline-json &lt;path&gt;</code> to compare builds.
        </div>
        {% endif %}
      </div>
      {% if diff.status == "ok" %}
      <div class="badge-row">
        <span class="badge {% if diff.flash_delta_bytes > 0 %}positive{% elif diff.flash_delta_bytes < 0 %}negative{% endif %}">
          Flash delta: {{ diff.flash_delta_bytes | signed_intcomma }} B
        </span>
        <span class="badge {% if diff.ram_delta_bytes > 0 %}positive{% elif diff.ram_delta_bytes < 0 %}negative{% endif %}">
          RAM delta: {{ diff.ram_delta_bytes | signed_intcomma }} B
        </span>
        <span class="badge neutral">Regressions: {{ diff_narrative.regression_count }}</span>
        <span class="badge neutral">Reductions: {{ diff_narrative.reduction_count }}</span>
      </div>
      {% if diff_narrative.region_deltas %}
      <div class="ms-region-delta-strip" role="region" aria-label="Per-region byte delta vs baseline">
        <div class="ms-region-delta-title">Per-region delta vs baseline</div>
        <ul class="ms-region-delta-list">
          {% for entry in diff_narrative.region_deltas %}
          <li class="ms-region-delta-row" data-severity="{{ entry.severity }}" data-direction="{{ entry.direction }}">
            <span class="ms-region-delta-name is-mono">{{ entry.name }}</span>
            <span class="ms-region-delta-rail">
              <span class="ms-region-delta-bar ms-region-delta-bar--{{ entry.direction }}"
                    style="width:{{ entry.ratio_pct }}%"></span>
            </span>
            <span class="ms-region-delta-value is-mono">{{ entry.delta_label }} B{% if entry.pct_of_capacity is not none %} ({{ entry.pct_of_capacity }}% cap){% endif %}</span>
          </li>
          {% endfor %}
        </ul>
      </div>
      {% endif %}
      {% set _drivers = diff_narrative.drivers %}
      {% if _drivers.components or _drivers.sections or _drivers.symbols %}
      <div class="ms-change-drivers" role="region" aria-label="What changed and why">
        <div class="ms-change-drivers-head">
          <span class="ms-change-drivers-title">What changed and why</span>
          <span class="ms-change-drivers-sub">Top drivers of the delta grouped by kind</span>
        </div>
        <div class="ms-change-drivers-grid">
          {% for group_key, label in [("components", "Components"), ("sections", "Sections"), ("symbols", "Symbols")] %}
          {% set _group = _drivers[group_key] %}
          {% if _group %}
          <div class="ms-driver-group">
            <div class="ms-driver-group-title">{{ label }}</div>
            <ul class="ms-driver-list">
              {% for entry in _group %}
              <li class="ms-driver-row" data-direction="{{ entry.direction }}">
                <span class="ms-driver-name is-mono" title="{{ entry.name }}">{{ entry.name }}</span>
                <span class="ms-driver-rail">
                  <span class="ms-driver-bar ms-driver-bar--{{ entry.direction }}" style="width:{{ entry.ratio_pct }}%"></span>
                </span>
                <span class="ms-driver-value is-mono">{{ entry.delta_label }}</span>
              </li>
              {% endfor %}
            </ul>
          </div>
          {% endif %}
          {% endfor %}
        </div>
      </div>
      {% endif %}
      <div class="chart-card">
        <h3 class="chart-title">Diff Impact Chart</h3>
        <canvas class="chart" id="diff-impact-chart"></canvas>
      </div>
      {% if diff.top_regressions or diff.top_reductions %}
      <div class="comparison-grid">
        {% if diff.top_regressions %}
        <div class="data-container">
          <table class="modern-table">
            <thead class="table-header">
              <tr><th>Kind</th><th>Name</th><th>Delta</th></tr>
            </thead>
            <tbody>
              {% for item in diff.top_regressions[:10] %}
              <tr class="table-row"><td>{{ item.kind }}</td><td>{{ item.name }}</td><td><span class="size-badge">{{ item.delta | signed_intcomma }}</span></td></tr>
              {% endfor %}
            </tbody>
          </table>
        </div>
        {% endif %}
        {% if diff.top_reductions %}
        <div class="data-container">
          <table class="modern-table">
            <thead class="table-header">
              <tr><th>Kind</th><th>Name</th><th>Delta</th></tr>
            </thead>
            <tbody>
              {% for item in diff.top_reductions[:10] %}
              <tr class="table-row"><td>{{ item.kind }}</td><td>{{ item.name }}</td><td><span class="size-badge">{{ item.delta | signed_intcomma }}</span></td></tr>
              {% endfor %}
            </tbody>
          </table>
        </div>
        {% endif %}
      </div>
      {% endif %}
      {% else %}
      <p class="muted">No valid baseline comparison available.</p>
      {% endif %}
      </div>
    </section>

    <section class="section" id="diagnostics">
      <div class="section-header">
        <h2 class="section-title"><span class="label-icon"><svg class="fa-icon"><use href="#icon-diagnostics"></use></svg></span>Diagnostics and Assumptions</h2>
        <button type="button" class="toggle-button" data-target="diagnostics-content">Collapse</button>
      </div>
      <div class="collapsible-content" id="diagnostics-content">
      <div class="diagnostics-grid">
        {% for block in diagnostics_blocks %}
        <article class="diag-card">
          <h3>{{ block.title }}</h3>
          <p class="summary-note">{{ block.summary }}</p>
          {% if block.entries %}
          <ul class="diag-list">
            {% for item in block.entries %}
            <li>{{ item }}</li>
            {% endfor %}
          </ul>
          {% endif %}
        </article>
        {% endfor %}
      </div>
      <details>
        <summary>Raw diagnostics payload</summary>
        <pre>{{ diagnostics_text }}</pre>
      </details>
      </div>
    </section>
    {% if license_footer %}
    <footer class="ms-license-footer" aria-label="License attestation">
      <div class="ms-license-footer-inner">
        <span class="ms-license-footer-label">License attestation:</span>
        <span class="ms-license-footer-item"><strong>Mode:</strong> {{ license_footer.mode }}</span>
        {% if license_footer.tier %}
        <span class="ms-license-footer-item"><strong>Tier:</strong> {{ license_footer.tier }}</span>
        {% endif %}
        {% if license_footer.license_id_tail %}
        <span class="ms-license-footer-item"><strong>License:</strong> {{ license_footer.license_id_tail }}</span>
        {% endif %}
        {% if license_footer.expires_at %}
        <span class="ms-license-footer-item"><strong>Expires:</strong> {{ license_footer.expires_at }}</span>
        {% endif %}
        {% if license_footer.machine_fingerprint_tail %}
        <span class="ms-license-footer-item"><strong>Machine:</strong> {{ license_footer.machine_fingerprint_tail }}</span>
        {% endif %}
        <span class="ms-license-footer-item"><strong>Provider:</strong> {{ license_footer.provider }}</span>
      </div>
    </footer>
    {% endif %}
      </main>
    </div>
  </div>
  <div id="memory-layout-tooltip" class="memory-layout-tooltip" aria-hidden="true"></div>
  <div id="memory-layout-side-panel-backdrop" class="memory-layout-panel-backdrop" aria-hidden="true"></div>
  <aside id="memory-layout-side-panel" class="memory-layout-side-panel" aria-hidden="true">
    <div class="memory-layout-side-panel-header">
      <h3>Range Details</h3>
      <button id="memory-layout-side-panel-close" type="button">Close</button>
    </div>
    <div id="memory-layout-side-panel-content" class="memory-layout-side-panel-content">
      <div class="layout-panel-placeholder">Select a range in the explorer to inspect details.</div>
    </div>
  </aside>
  <div id="ms-palette-backdrop" class="ms-palette-backdrop" role="presentation" aria-hidden="true">
    <div class="ms-palette" role="dialog" aria-modal="true" aria-label="Command palette">
      <div class="ms-palette-search">
        <svg aria-hidden="true"><use href="#icon-search"></use></svg>
        <input id="ms-palette-input" type="text" placeholder="Search regions, sections, symbols, components, issues..." autocomplete="off" spellcheck="false" aria-label="Search">
        <span class="ms-palette-hint">Esc to close</span>
      </div>
      <ul id="ms-palette-list" class="ms-palette-list" role="listbox" aria-label="Search results"></ul>
    </div>
  </div>
  <script id="memscope-insights-data" type="application/json">{{ insights | tojson }}</script>
  <script id="memscope-palette-index" type="application/json">{{ palette_index | tojson }}</script>
  <script id="memscope-address-index" type="application/json">{{ address_index | tojson }}</script>
  <script id="memscope-runtime-manifest" type="application/json">{{ runtime_manifest | tojson }}</script>
  <script id="memscope-visualization-data" type="application/json">{{ visualization_data | tojson }}</script>
  {% for asset in runtime_assets %}
  <script id="memscope-runtime-asset-{{ asset.name }}" data-runtime-name="{{ asset.name }}" data-runtime-version="{{ asset.version }}">{{ asset.code | safe }}</script>
  {% endfor %}
  <script id="memscope-chart-data" type="application/json">{{ chart_data | tojson }}</script>
  <script>
    const themeToggle = document.getElementById("toggle-theme");
    const appbarThemeToggle = document.getElementById("ms-appbar-theme");
    function applyTheme(lightEnabled) {
      document.body.classList.toggle("manual-light", lightEnabled);
      if (themeToggle) themeToggle.textContent = lightEnabled ? "Use Dark Theme" : "Use Light Theme";
      if (appbarThemeToggle) appbarThemeToggle.textContent = lightEnabled ? "Light" : "Dark";
      try { localStorage.setItem("memscope-theme", lightEnabled ? "light" : "dark"); } catch (_) {}
    }
    (function () {
      try {
        const savedTheme = localStorage.getItem("memscope-theme");
        if (savedTheme === "light") {
          document.body.classList.add("manual-light");
          if (themeToggle) themeToggle.textContent = "Use Dark Theme";
          if (appbarThemeToggle) appbarThemeToggle.textContent = "Light";
        } else if (appbarThemeToggle) {
          appbarThemeToggle.textContent = "Dark";
        }
      } catch (_) {}
    })();
    function toggleThemeHandler() {
      const lightModeEnabled = !document.body.classList.contains("manual-light");
      applyTheme(lightModeEnabled);
      if (window.MemScopeRuntime && typeof window.MemScopeRuntime.invalidateColorCache === "function") {
        window.MemScopeRuntime.invalidateColorCache();
      }
      renderAllCharts();
      initializeRuntimeRenderers();
    }
    themeToggle?.addEventListener("click", toggleThemeHandler);
    appbarThemeToggle?.addEventListener("click", toggleThemeHandler);

    // ---- Insights hero click-through ----
    function jumpToHash(hash) {
      if (!hash) return;
      const el = document.querySelector(hash);
      if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
    }
    document.querySelectorAll(".ms-insight-card[data-jump]").forEach(function (card) {
      card.addEventListener("click", function () {
        const hash = card.getAttribute("data-jump");
        const region = card.getAttribute("data-region");
        const issueText = card.getAttribute("data-issue-text");
        const filtersToApply = {};
        if (region) filtersToApply.region = region;
        if (Object.keys(filtersToApply).length && typeof setFiltersFromRuntimeSelection === "function") {
          try {
            setFiltersFromRuntimeSelection({
              source: "insight-card",
              region: region || "",
              drill_section: hash ? hash.replace(/^#/, "") : "",
            });
          } catch (_) {}
        }
        if (issueText) {
          const issueFilter = document.getElementById("issue-filter-text");
          if (issueFilter) {
            issueFilter.value = issueText;
            try { issueFilter.dispatchEvent(new Event("input", { bubbles: true })); } catch (_) {}
          }
        }
        jumpToHash(hash);
      });
    });

    // ---- Address inspector ----
    const addressTrigger = document.getElementById("ms-address-trigger");
    const addressPopover = document.getElementById("ms-address-popover");
    const addressInput = document.getElementById("ms-address-input");
    const addressResult = document.getElementById("ms-address-result");
    const addressIndex = parseJsonScript("memscope-address-index", []);
    function openAddressPopover() {
      if (!addressPopover) return;
      addressPopover.classList.add("is-open");
      addressPopover.setAttribute("aria-hidden", "false");
      setTimeout(function () { addressInput && addressInput.focus(); }, 0);
    }
    function closeAddressPopover() {
      if (!addressPopover) return;
      addressPopover.classList.remove("is-open");
      addressPopover.setAttribute("aria-hidden", "true");
    }
    function parseAddress(text) {
      if (!text) return NaN;
      const trimmed = String(text).trim().replace(/_/g, "");
      if (!trimmed) return NaN;
      if (/^0x[0-9a-fA-F]+$/.test(trimmed)) return parseInt(trimmed.slice(2), 16);
      if (/^[0-9a-fA-F]+h$/i.test(trimmed)) return parseInt(trimmed.slice(0, -1), 16);
      if (/^[0-9]+$/.test(trimmed)) return parseInt(trimmed, 10);
      if (/^[0-9a-fA-F]+$/.test(trimmed) && /[a-fA-F]/.test(trimmed)) return parseInt(trimmed, 16);
      const asNum = Number(trimmed);
      return isFinite(asNum) ? asNum : NaN;
    }
    function lookupAddress(addr) {
      if (!isFinite(addr) || !Array.isArray(addressIndex)) return null;
      let best = null;
      for (let i = 0; i < addressIndex.length; i++) {
        const entry = addressIndex[i];
        if (!entry) continue;
        const start = Number(entry.start);
        const end = Number(entry.end);
        if (!isFinite(start) || !isFinite(end)) continue;
        if (addr >= start && addr <= end) {
          if (!best) {
            best = entry;
          } else {
            const bestSpan = Number(best.end) - Number(best.start);
            const span = end - start;
            if (span < bestSpan) best = entry;
          }
        }
      }
      return best;
    }
    function renderAddressLookup() {
      if (!addressInput || !addressResult) return;
      const raw = addressInput.value;
      if (!raw.trim()) {
        addressResult.classList.remove("is-miss");
        addressResult.textContent = "Enter an address to locate the owning region, section, and symbol.";
        return;
      }
      const addr = parseAddress(raw);
      if (!isFinite(addr)) {
        addressResult.classList.add("is-miss");
        addressResult.textContent = "Could not parse address. Try 0x08001234, 134218292, or 8001234h.";
        return;
      }
      const hit = lookupAddress(addr);
      if (!hit) {
        addressResult.classList.add("is-miss");
        addressResult.textContent = "Address 0x" + addr.toString(16).toUpperCase() + " is outside any known region.";
        return;
      }
      addressResult.classList.remove("is-miss");
      const offset = addr - Number(hit.start);
      addressResult.innerHTML =
        "<div class=\\\"ms-kv\\\"><span>Region</span><span>" + (hit.region || "-") + "</span></div>" +
        "<div class=\\\"ms-kv\\\"><span>Kind</span><span>" + (hit.kind || "-") + "</span></div>" +
        (hit.section ? "<div class=\\\"ms-kv\\\"><span>Section</span><span>" + hit.section + "</span></div>" : "") +
        (hit.symbol ? "<div class=\\\"ms-kv\\\"><span>Symbol</span><span>" + hit.symbol + "</span></div>" : "") +
        "<div class=\\\"ms-kv\\\"><span>Range</span><span>0x" + Number(hit.start).toString(16).toUpperCase() + " - 0x" + Number(hit.end).toString(16).toUpperCase() + "</span></div>" +
        "<div class=\\\"ms-kv\\\"><span>Offset</span><span>+0x" + offset.toString(16).toUpperCase() + " (" + offset.toLocaleString() + " B)</span></div>";
    }
    addressTrigger?.addEventListener("click", function () {
      if (addressPopover && addressPopover.classList.contains("is-open")) {
        closeAddressPopover();
      } else {
        openAddressPopover();
      }
    });
    addressInput?.addEventListener("input", renderAddressLookup);
    document.addEventListener("click", function (event) {
      if (!addressPopover || !addressPopover.classList.contains("is-open")) return;
      if (addressPopover.contains(event.target) || event.target === addressTrigger) return;
      closeAddressPopover();
    });

    // ---- Command palette ----
    const paletteBackdrop = document.getElementById("ms-palette-backdrop");
    const paletteInput = document.getElementById("ms-palette-input");
    const paletteList = document.getElementById("ms-palette-list");
    const paletteTrigger = document.getElementById("ms-palette-trigger");
    const paletteIndex = parseJsonScript("memscope-palette-index", []);
    let paletteResults = [];
    let paletteActive = 0;
    function fuzzyScore(needle, haystack) {
      if (!needle) return 1;
      const n = needle.toLowerCase();
      const h = haystack.toLowerCase();
      if (h.indexOf(n) >= 0) return 100 + (10 - Math.min(10, h.indexOf(n)));
      let i = 0, j = 0, score = 0, streak = 0;
      while (i < n.length && j < h.length) {
        if (n[i] === h[j]) {
          score += 1 + streak;
          streak += 1;
          i++;
        } else {
          streak = 0;
        }
        j++;
      }
      return i === n.length ? score : 0;
    }
    function renderPaletteResults(query) {
      if (!paletteList) return;
      const q = (query || "").trim();
      let scored;
      if (!q) {
        scored = paletteIndex.slice(0, 40).map(function (entry, idx) {
          return { entry: entry, score: 1, idx: idx };
        });
      } else {
        scored = [];
        for (let i = 0; i < paletteIndex.length; i++) {
          const entry = paletteIndex[i];
          const score = fuzzyScore(q, entry.label || "") || fuzzyScore(q, entry.searchText || "");
          if (score > 0) scored.push({ entry: entry, score: score, idx: i });
        }
        scored.sort(function (a, b) { return b.score - a.score; });
        scored = scored.slice(0, 40);
      }
      paletteResults = scored.map(function (s) { return s.entry; });
      paletteActive = 0;
      paletteList.innerHTML = "";
      if (!paletteResults.length) {
        const empty = document.createElement("li");
        empty.className = "ms-palette-empty";
        empty.textContent = "No matches.";
        paletteList.appendChild(empty);
        return;
      }
      paletteResults.forEach(function (entry, i) {
        const li = document.createElement("li");
        li.setAttribute("role", "option");
        li.dataset.index = String(i);
        if (i === 0) li.classList.add("is-active");
        const kind = document.createElement("span");
        kind.className = "ms-palette-kind";
        kind.textContent = entry.kind || "";
        const label = document.createElement("span");
        label.className = "ms-palette-label";
        label.textContent = entry.label || "";
        const hint = document.createElement("span");
        hint.className = "ms-palette-hint-right";
        hint.textContent = entry.hint || "";
        li.appendChild(kind);
        li.appendChild(label);
        li.appendChild(hint);
        li.addEventListener("click", function () { runPaletteEntry(entry); });
        paletteList.appendChild(li);
      });
    }
    function setPaletteActive(idx) {
      const items = paletteList.querySelectorAll("li[role='option']");
      if (!items.length) return;
      paletteActive = ((idx % items.length) + items.length) % items.length;
      items.forEach(function (el, i) { el.classList.toggle("is-active", i === paletteActive); });
      const active = items[paletteActive];
      if (active && active.scrollIntoView) active.scrollIntoView({ block: "nearest" });
    }
    function runPaletteEntry(entry) {
      closePalette();
      if (!entry) return;
      if (entry.region && typeof setFiltersFromRuntimeSelection === "function") {
        try { setFiltersFromRuntimeSelection({ source: "palette", region: entry.region, drill_section: (entry.hash || "").replace(/^#/, "") }); } catch (_) {}
      }
      if (entry.component && typeof setFiltersFromRuntimeSelection === "function") {
        try { setFiltersFromRuntimeSelection({ source: "palette", component: entry.component, drill_section: (entry.hash || "").replace(/^#/, "") }); } catch (_) {}
      }
      if (entry.searchInputId && entry.searchValue) {
        const searchEl = document.getElementById(entry.searchInputId);
        if (searchEl) {
          searchEl.value = entry.searchValue;
          try { searchEl.dispatchEvent(new Event("input", { bubbles: true })); } catch (_) {}
        }
      }
      if (entry.hash) jumpToHash(entry.hash);
    }
    function openPalette() {
      if (!paletteBackdrop) return;
      paletteBackdrop.classList.add("is-open");
      paletteBackdrop.setAttribute("aria-hidden", "false");
      paletteInput.value = "";
      renderPaletteResults("");
      setTimeout(function () { paletteInput && paletteInput.focus(); }, 0);
    }
    function closePalette() {
      if (!paletteBackdrop) return;
      paletteBackdrop.classList.remove("is-open");
      paletteBackdrop.setAttribute("aria-hidden", "true");
    }
    paletteTrigger?.addEventListener("click", openPalette);
    paletteInput?.addEventListener("input", function () { renderPaletteResults(paletteInput.value); });
    paletteInput?.addEventListener("keydown", function (event) {
      if (event.key === "ArrowDown") { event.preventDefault(); setPaletteActive(paletteActive + 1); }
      else if (event.key === "ArrowUp") { event.preventDefault(); setPaletteActive(paletteActive - 1); }
      else if (event.key === "Enter") { event.preventDefault(); runPaletteEntry(paletteResults[paletteActive]); }
    });
    paletteBackdrop?.addEventListener("click", function (event) {
      if (event.target === paletteBackdrop) closePalette();
    });
    document.addEventListener("keydown", function (event) {
      if ((event.key === "k" || event.key === "K") && (event.ctrlKey || event.metaKey)) {
        event.preventDefault();
        if (paletteBackdrop && paletteBackdrop.classList.contains("is-open")) closePalette();
        else openPalette();
        return;
      }
      if (event.key === "Escape") {
        if (paletteBackdrop && paletteBackdrop.classList.contains("is-open")) { closePalette(); return; }
        if (addressPopover && addressPopover.classList.contains("is-open")) { closeAddressPopover(); return; }
        if (jumpMenu && jumpMenu.classList.contains("is-open")) { setJumpOpen(false); return; }
      }
    });

    // ---- Share / export menu ----
    const shareTrigger = document.getElementById("ms-share-trigger");
    const shareMenu = document.getElementById("ms-share-menu");
    function setShareOpen(open) {
      if (!shareMenu) return;
      shareMenu.classList.toggle("is-open", !!open);
      if (shareTrigger) shareTrigger.setAttribute("aria-expanded", open ? "true" : "false");
    }
    shareTrigger?.addEventListener("click", function (event) {
      event.stopPropagation();
      if (!shareMenu) return;
      setShareOpen(!shareMenu.classList.contains("is-open"));
    });
    document.addEventListener("click", function (event) {
      if (!shareMenu || !shareMenu.classList.contains("is-open")) return;
      if (shareMenu.contains(event.target) || event.target === shareTrigger) return;
      setShareOpen(false);
    });

    function flashStatus(text) {
      try { window.__memscopeToast && window.__memscopeToast(text); } catch (_) {}
      try { window.console && window.console.info && window.console.info("[memscope] " + text); } catch (_) {}
    }

    function copyToClipboard(text) {
      if (navigator.clipboard && navigator.clipboard.writeText) {
        return navigator.clipboard.writeText(text);
      }
      return new Promise(function (resolve, reject) {
        try {
          const ta = document.createElement("textarea");
          ta.value = text;
          ta.style.position = "fixed";
          ta.style.opacity = "0";
          document.body.appendChild(ta);
          ta.select();
          document.execCommand("copy");
          document.body.removeChild(ta);
          resolve();
        } catch (err) { reject(err); }
      });
    }

    // T255 shareable URL helpers
    function readShareStateFromHash() {
      const raw = String(window.location.hash || "");
      if (raw.indexOf("#?") !== 0) return null;
      const state = {};
      raw.slice(2).split("&").forEach(function (part) {
        if (!part) return;
        const eq = part.indexOf("=");
        const k = decodeURIComponent(eq >= 0 ? part.slice(0, eq) : part);
        const v = decodeURIComponent(eq >= 0 ? part.slice(eq + 1) : "");
        if (k) state[k] = v;
      });
      return state;
    }
    function writeShareStateToHash(state) {
      const parts = [];
      Object.keys(state || {}).forEach(function (k) {
        const v = state[k];
        if (v === null || v === undefined || v === "") return;
        parts.push(encodeURIComponent(k) + "=" + encodeURIComponent(String(v)));
      });
      const hash = parts.length ? ("#?" + parts.join("&")) : "";
      try {
        if (hash !== window.location.hash) {
          window.history.replaceState(null, "", hash || window.location.pathname + window.location.search);
        }
      } catch (_) {}
    }
    const currentShareState = { region: "", component: "", tab: "" };
    function getShareState() { return Object.assign({}, currentShareState); }
    function updateShareState(patch) {
      let changed = false;
      Object.keys(patch || {}).forEach(function (k) {
        if (typeof patch[k] === "undefined") return;
        const value = patch[k] === null ? "" : String(patch[k]);
        if (currentShareState[k] !== value) {
          currentShareState[k] = value;
          changed = true;
        }
      });
      if (changed) writeShareStateToHash(currentShareState);
    }
    function applyShareStateFromHash() {
      const state = readShareStateFromHash();
      if (!state) return;
      Object.assign(currentShareState, { region: state.region || "", component: state.component || "", tab: state.tab || "" });
      if (state.region || state.component) {
        try {
          setFiltersFromRuntimeSelection({
            source: "share-link",
            region: state.region || undefined,
            component: state.component || undefined,
          });
        } catch (_) {}
      }
    }

    // T254 Markdown export
    function buildMarkdownReport() {
      const title = (document.querySelector("h1")?.textContent || "MemScope Report").trim();
      const lines = ["# " + title, ""];
      const heroCards = document.querySelectorAll(".ms-insights-hero .ms-hero-card");
      if (heroCards.length) {
        lines.push("## Insights snapshot", "");
        heroCards.forEach(function (card) {
          const caption = (card.querySelector(".ms-hero-caption")?.textContent || "").trim();
          const value = (card.querySelector(".ms-hero-value")?.textContent || "").trim();
          const meta = (card.querySelector(".ms-hero-meta")?.textContent || "").trim();
          if (caption) {
            lines.push("- **" + caption + ":** " + value + (meta ? " (_" + meta + "_)" : ""));
          }
        });
        lines.push("");
      }
      const tableSnapshots = [
        { id: "top-symbols-table", heading: "Top symbols" },
        { id: "top-objects-table", heading: "Top objects" },
        { id: "issues-table", heading: "Issues and recommendations" },
      ];
      tableSnapshots.forEach(function (snap) {
        const table = document.getElementById(snap.id);
        if (!table) return;
        const headers = Array.from(table.querySelectorAll("thead th")).map(function (th) {
          return (th.textContent || "").trim().replace(/\\s+/g, " ");
        });
        const rows = Array.from(table.querySelectorAll("tbody tr")).filter(function (tr) {
          return tr.style.display !== "none" && !tr.classList.contains("vlist-clipped");
        }).slice(0, 15).map(function (tr) {
          return Array.from(tr.querySelectorAll("td")).map(function (td) {
            return (td.textContent || "").trim().replace(/\\s+/g, " ").replace(/\\|/g, "\\\\|");
          });
        });
        if (!rows.length) return;
        lines.push("## " + snap.heading, "");
        lines.push("| " + headers.join(" | ") + " |");
        lines.push("| " + headers.map(function () { return "---"; }).join(" | ") + " |");
        rows.forEach(function (cells) { lines.push("| " + cells.join(" | ") + " |"); });
        lines.push("");
      });
      return lines.join("\\n");
    }

    // T253 SVG/PNG export
    function cloneSvgForExport() {
      const svg = document.querySelector(".ms-composite-svg");
      if (!svg) return null;
      const clone = svg.cloneNode(true);
      if (!clone.getAttribute("xmlns")) clone.setAttribute("xmlns", "http://www.w3.org/2000/svg");
      const rect = svg.getBoundingClientRect();
      if (!clone.getAttribute("width")) clone.setAttribute("width", Math.max(1, Math.round(rect.width || 800)));
      if (!clone.getAttribute("height")) clone.setAttribute("height", Math.max(1, Math.round(rect.height || 400)));
      const bg = getComputedStyle(document.body).getPropertyValue("--panel-alt").trim() || "#0f1a2a";
      const styleEl = document.createElement("style");
      styleEl.textContent = [
        "svg { background: " + bg + "; font-family: Inter, system-ui, sans-serif; color: #e8f0ff; }",
        ".region-band { fill: rgba(92,140,205,0.16); stroke: rgba(153,196,235,0.45); }",
        ".region-label { fill: #e8f0ff; font-size: 12px; font-weight: 600; }",
        ".region-meta { fill: #a7b6cc; font-size: 10px; }",
        ".layout-range { stroke: rgba(0,0,0,0.25); stroke-width: 0.5; }",
        ".layout-range-label { fill: #1a2536; font-size: 9px; }",
        ".padding-range { fill: rgba(255,140,90,0.55); }",
        ".layout-heat-strip { fill: rgba(255,80,80,0.5); }",
        ".layout-heat-strip-label { fill: #ff8c8c; font-size: 10px; }",
        ".ms-minimap-region-label { fill: #a7b6cc; font-size: 9px; }",
      ].join("\\n");
      clone.insertBefore(styleEl, clone.firstChild);
      return clone;
    }
    function serializeSvg(clone) {
      const serializer = new XMLSerializer();
      const raw = serializer.serializeToString(clone);
      return '<?xml version=\\"1.0\\" encoding=\\"UTF-8\\"?>\\n' + raw;
    }
    function downloadBlob(blob, filename) {
      const url = URL.createObjectURL(blob);
      const a = document.createElement("a");
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(function () { URL.revokeObjectURL(url); }, 2000);
    }
    function exportLayoutSvg() {
      const clone = cloneSvgForExport();
      if (!clone) { flashStatus("No layout SVG to export"); return; }
      const xml = serializeSvg(clone);
      downloadBlob(new Blob([xml], { type: "image/svg+xml;charset=utf-8" }), "memscope-memory-layout.svg");
      flashStatus("Downloaded memory-layout.svg");
    }
    function exportLayoutPng() {
      const clone = cloneSvgForExport();
      if (!clone) { flashStatus("No layout SVG to export"); return; }
      const width = parseInt(clone.getAttribute("width") || "800", 10) || 800;
      const height = parseInt(clone.getAttribute("height") || "400", 10) || 400;
      const xml = serializeSvg(clone);
      const svgBlob = new Blob([xml], { type: "image/svg+xml;charset=utf-8" });
      const url = URL.createObjectURL(svgBlob);
      const img = new Image();
      img.onload = function () {
        const scale = Math.min(2, Math.max(1, window.devicePixelRatio || 1));
        const canvas = document.createElement("canvas");
        canvas.width = Math.round(width * scale);
        canvas.height = Math.round(height * scale);
        const ctx = canvas.getContext("2d");
        ctx.scale(scale, scale);
        ctx.drawImage(img, 0, 0, width, height);
        canvas.toBlob(function (blob) {
          URL.revokeObjectURL(url);
          if (!blob) { flashStatus("PNG export failed"); return; }
          downloadBlob(blob, "memscope-memory-layout.png");
          flashStatus("Downloaded memory-layout.png");
        }, "image/png");
      };
      img.onerror = function () {
        URL.revokeObjectURL(url);
        flashStatus("PNG export failed (SVG did not load)");
      };
      img.src = url;
    }

    shareMenu?.querySelectorAll("[data-share-action]").forEach(function (btn) {
      btn.addEventListener("click", function () {
        setShareOpen(false);
        const action = btn.getAttribute("data-share-action");
        if (action === "copy-link") {
          const url = window.location.origin + window.location.pathname + window.location.search + (window.location.hash || "");
          copyToClipboard(url).then(function () { flashStatus("Link copied to clipboard"); });
        } else if (action === "copy-markdown") {
          copyToClipboard(buildMarkdownReport()).then(function () { flashStatus("Markdown copied to clipboard"); });
        } else if (action === "download-svg") {
          exportLayoutSvg();
        } else if (action === "download-png") {
          exportLayoutPng();
        }
      });
    });

    // ---- Copy-as-CSV per table ----
    function tableToCsv(table) {
      const rows = [];
      const headerCells = table.querySelectorAll("thead th");
      if (headerCells.length) {
        rows.push(Array.from(headerCells).map(function (th) {
          return csvCell(th.textContent || "");
        }).join(","));
      }
      const bodyRows = table.querySelectorAll("tbody tr");
      bodyRows.forEach(function (tr) {
        if (tr.style && tr.style.display === "none") return;
        const cells = tr.querySelectorAll("td");
        rows.push(Array.from(cells).map(function (td) {
          return csvCell(td.textContent || "");
        }).join(","));
      });
      return rows.join("\\n");
    }
    function csvCell(text) {
      const t = String(text).replace(/\\s+/g, " ").trim();
      if (/[,\\"\\n]/.test(t)) return "\\"" + t.replace(/\\"/g, "\\"\\"") + "\\"";
      return t;
    }
    function attachCopyButtons() {
      document.querySelectorAll(".table-wrap").forEach(function (wrap) {
        if (wrap.dataset.msCopyAttached === "1") return;
        const table = wrap.querySelector("table");
        if (!table) return;
        const toolbar = document.createElement("div");
        toolbar.className = "ms-table-toolbar";
        const btn = document.createElement("button");
        btn.type = "button";
        btn.className = "ms-copy-btn";
        btn.textContent = "Copy CSV";
        btn.addEventListener("click", function () {
          const csv = tableToCsv(table);
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(csv).then(function () {
              btn.textContent = "Copied";
              btn.classList.add("is-ok");
              setTimeout(function () { btn.textContent = "Copy CSV"; btn.classList.remove("is-ok"); }, 1400);
            });
          }
        });
        toolbar.appendChild(btn);
        wrap.parentNode.insertBefore(toolbar, wrap);
        wrap.dataset.msCopyAttached = "1";
      });
      document.querySelectorAll("[data-copy-text]").forEach(function (btn) {
        if (btn.dataset.msCopyTextAttached === "1") return;
        btn.dataset.msCopyTextAttached = "1";
        const original = btn.textContent;
        btn.addEventListener("click", function () {
          const text = btn.getAttribute("data-copy-text") || "";
          if (!text) return;
          if (navigator.clipboard && navigator.clipboard.writeText) {
            navigator.clipboard.writeText(text).then(function () {
              btn.textContent = "Copied";
              btn.classList.add("is-ok");
              setTimeout(function () { btn.textContent = original; btn.classList.remove("is-ok"); }, 1400);
            });
          }
        });
      });
    }

    function setupCollapsibleSections() {
      const toggles = Array.from(document.querySelectorAll(".toggle-button[data-target]"));
      toggles.forEach(function (button) {
        button.addEventListener("click", function () {
          const targetId = button.getAttribute("data-target");
          if (!targetId) return;
          const target = document.getElementById(targetId);
          if (!target) return;
          const collapsed = target.classList.toggle("is-collapsed");
          button.textContent = collapsed ? "Expand" : "Collapse";
          if (!collapsed && typeof applySharedFilters === "function") {
            applySharedFilters({ refreshRuntime: false });
          }
        });
      });

      function setAllSectionsCollapsed(collapsed) {
        toggles.forEach(function (button) {
          const targetId = button.getAttribute("data-target");
          if (!targetId) return;
          const target = document.getElementById(targetId);
          if (!target) return;
          target.classList.toggle("is-collapsed", collapsed);
          button.textContent = collapsed ? "Expand" : "Collapse";
        });
      }

      document.getElementById("collapse-all")?.addEventListener("click", function () {
        setAllSectionsCollapsed(true);
      });
      document.getElementById("expand-all")?.addEventListener("click", function () {
        setAllSectionsCollapsed(false);
      });
    }

    function animateRegionProgressBars() {
      document.querySelectorAll(".progress-bar[data-width]").forEach(function (bar) {
        const width = bar.getAttribute("data-width") || "0%";
        bar.style.width = "0%";
        window.setTimeout(function () { bar.style.width = width; }, 80);
      });
    }

    function formatBytesLabel(value) {
      const parsed = Number(value);
      const safeValue = Number.isFinite(parsed) ? Math.trunc(parsed) : 0;
      return safeValue.toLocaleString("en-US") + " B";
    }

    function formatSignedBytesLabel(value) {
      const parsed = Number(value);
      const safeValue = Number.isFinite(parsed) ? Math.trunc(parsed) : 0;
      const sign = safeValue > 0 ? "+" : "";
      return sign + safeValue.toLocaleString("en-US") + " B";
    }

    function toComparable(text, asNumber) {
      if (!asNumber) return text.toLowerCase();
      const cleaned = text.replace(/[^0-9.-]/g, "");
      const parsed = Number(cleaned);
      return Number.isNaN(parsed) ? 0 : parsed;
    }

    function sortTableByColumn(table, index, asNumber, ascending) {
      const tbody = table.querySelector("tbody");
      if (!tbody) return;
      const rows = Array.from(tbody.querySelectorAll("tr"));
      rows.sort(function (a, b) {
        const left = toComparable(a.children[index].textContent.trim(), asNumber);
        const right = toComparable(b.children[index].textContent.trim(), asNumber);
        if (left < right) return ascending ? -1 : 1;
        if (left > right) return ascending ? 1 : -1;
        return 0;
      });
      tbody.innerHTML = "";
      rows.forEach(function (row) { tbody.appendChild(row); });
    }

    function setupSortableTables() {
      document.querySelectorAll("table.sortable th[data-sort]").forEach(function (th) {
        th.addEventListener("click", function () {
          const table = th.closest("table");
          if (!table) return;
          const index = Array.prototype.indexOf.call(th.parentNode.children, th);
          const asNumber = th.getAttribute("data-sort") === "num";
          const ascending = th.getAttribute("data-order") !== "asc";
          sortTableByColumn(table, index, asNumber, ascending);
          th.setAttribute("data-order", ascending ? "asc" : "desc");
        });
      });

      document.querySelectorAll("table.sortable").forEach(function (table) {
        const headerCells = Array.from(table.querySelectorAll("thead th[data-sort]"));
        const firstNumericHeader = headerCells.find(function (th) {
          return th.getAttribute("data-sort") === "num";
        });
        if (!firstNumericHeader) return;
        const index = Array.prototype.indexOf.call(firstNumericHeader.parentNode.children, firstNumericHeader);
        sortTableByColumn(table, index, true, false);
        firstNumericHeader.setAttribute("data-order", "desc");
      });
    }

    function parseJsonScript(scriptId, fallback) {
      const node = document.getElementById(scriptId);
      if (!node || !node.textContent) {
        return fallback;
      }
      try {
        return JSON.parse(node.textContent);
      } catch (_error) {
        return fallback;
      }
    }

    function parseChartData() {
      const parsed = parseJsonScript("memscope-chart-data", {});
      return {
        regions: Array.isArray(parsed.regions) ? parsed.regions : [],
        topSymbols: Array.isArray(parsed.topSymbols) ? parsed.topSymbols : [],
        components: Array.isArray(parsed.components) ? parsed.components : [],
        diffEntries: Array.isArray(parsed.diffEntries) ? parsed.diffEntries : []
      };
    }

    function parseVisualizationData() {
      const parsed = parseJsonScript("memscope-visualization-data", {});
      const features = parsed.features && typeof parsed.features === "object" ? parsed.features : {};
      const relationships = parsed.relationships && typeof parsed.relationships === "object" ? parsed.relationships : {};
      return {
        schema_version: String(parsed.schema_version || ""),
        regions: Array.isArray(parsed.regions) ? parsed.regions : [],
        features: {
          sankey_enabled: Boolean(features.sankey_enabled),
          relationship_graph_enabled: Boolean(features.relationship_graph_enabled),
        },
        ownership: parsed.ownership && typeof parsed.ownership === "object" ? parsed.ownership : {},
        diff: parsed.diff && typeof parsed.diff === "object" ? parsed.diff : {},
        relationships: {
          sankey: relationships.sankey && typeof relationships.sankey === "object" ? relationships.sankey : {},
          graph: relationships.graph && typeof relationships.graph === "object" ? relationships.graph : {},
        },
        policy_issue_index:
          parsed.policy_issue_index && typeof parsed.policy_issue_index === "object"
            ? parsed.policy_issue_index
            : {}
      };
    }

    const runtimeManifest = parseJsonScript("memscope-runtime-manifest", {});
    const chartData = parseChartData();
    const visualizationData = parseVisualizationData();
    const chartHitZones = new Map();
    const sharedFilters = {
      region: "",
      component: "",
      sectionQuery: "",
      issueQuery: "",
      issueSeverity: "",
    };
    const runtimeSelectionContext = {
      setFiltersFromRuntimeSelection: function (_selection) {},
      getFilters: function () { return Object.assign({}, sharedFilters); },
      scrollToSectionAndHighlight: function (_sectionId, _rowSelector) {},
    };

    function normalizeFilterText(value) {
      return String(value || "").trim();
    }

    function normalizeFilterTextLower(value) {
      return normalizeFilterText(value).toLowerCase();
    }

    function mapObjectToComponent() {
      const result = new Map();
      const selectors = ["#globals-table tbody tr", "#functions-table tbody tr"];
      selectors.forEach(function (selector) {
        document.querySelectorAll(selector).forEach(function (row) {
          const objectName = normalizeFilterText(row.getAttribute("data-object"));
          const componentName = normalizeFilterText(row.getAttribute("data-component"));
          if (objectName && componentName && !result.has(objectName)) {
            result.set(objectName, componentName);
          }
        });
      });
      return result;
    }

    function setSelectValue(selectId, value) {
      const select = document.getElementById(selectId);
      if (!select) return;
      const normalized = normalizeFilterText(value);
      if (!normalized) {
        select.value = "";
        return;
      }
      const hasOption = Array.from(select.options).some(function (option) {
        return normalizeFilterText(option.value) === normalized;
      });
      select.value = hasOption ? normalized : "";
    }

    function setInputValue(inputId, value) {
      const input = document.getElementById(inputId);
      if (!input) return;
      input.value = normalizeFilterText(value);
    }

    function syncControlsFromSharedState() {
      setSelectValue("section-filter-region", sharedFilters.region);
      setSelectValue("globals-filter-region", sharedFilters.region);
      setSelectValue("functions-filter-region", sharedFilters.region);
      setSelectValue("globals-filter-component", sharedFilters.component);
      setSelectValue("functions-filter-component", sharedFilters.component);
      setInputValue("section-filter-text", sharedFilters.sectionQuery);
      setInputValue("issue-filter-text", sharedFilters.issueQuery);
      setSelectValue("issue-filter-severity", sharedFilters.issueSeverity);
    }

    function clearDrillHighlights() {
      document.querySelectorAll(".runtime-drill-target").forEach(function (node) {
        node.classList.remove("runtime-drill-target");
      });
    }

    function highlightFirstMatchingRow(tableId, predicate) {
      const table = document.getElementById(tableId);
      if (!table) return null;
      const rows = Array.from(table.querySelectorAll("tbody tr"));
      for (const row of rows) {
        if (row.style.display === "none") continue;
        if (!predicate(row)) continue;
        row.classList.add("runtime-drill-target");
        return row;
      }
      return null;
    }

    function findRowByData(tableId, dataKey, expectedValue) {
      const table = document.getElementById(tableId);
      if (!table) return null;
      const normalizedExpected = normalizeFilterText(expectedValue);
      if (!normalizedExpected) return null;
      const rows = Array.from(table.querySelectorAll("tbody tr"));
      for (const row of rows) {
        const rowValue = normalizeFilterText(row.dataset[dataKey] || row.getAttribute("data-" + dataKey));
        if (rowValue === normalizedExpected) return row;
      }
      return null;
    }

    function scrollToSectionAndHighlight(sectionId, rowTarget) {
      const section = document.getElementById(sectionId);
      if (section) {
        section.classList.add("runtime-drill-target");
        section.scrollIntoView({ behavior: "smooth", block: "start" });
      }
      if (rowTarget) {
        const row =
          typeof rowTarget === "string"
            ? document.querySelector(rowTarget)
            : rowTarget;
        if (row instanceof HTMLElement) {
          row.classList.add("runtime-drill-target");
          row.scrollIntoView({ behavior: "smooth", block: "center" });
        }
      }
      window.setTimeout(function () {
        clearDrillHighlights();
      }, 1800);
    }

    function themeColors() {
      const styles = getComputedStyle(document.body);
      return {
        text: styles.getPropertyValue("--text").trim() || "#e8f0ff",
        muted: styles.getPropertyValue("--muted").trim() || "#a7b6cc",
        line: styles.getPropertyValue("--line").trim() || "#35506e",
        track1: styles.getPropertyValue("--bar-track-start").trim() || "#1a2a3c",
        track2: styles.getPropertyValue("--bar-track-end").trim() || "#243a54",
        accent: styles.getPropertyValue("--accent").trim() || "#4f8cff",
        accentSoft: styles.getPropertyValue("--accent-soft").trim() || "#8fd3ff",
        good: styles.getPropertyValue("--ok").trim() || styles.getPropertyValue("--accent").trim() || "#5ed29a",
        warn: styles.getPropertyValue("--warning").trim() || "#ffb454",
        bad: styles.getPropertyValue("--error").trim() || "#ff6d7f",
        fontFamily: (styles.fontFamily || "").trim() || '"Segoe UI", "Roboto", sans-serif'
      };
    }
    function chartFont(sizePx, weight) {
      const colors = themeColors();
      const w = weight || 500;
      return w + " " + sizePx + "px " + colors.fontFamily;
    }
    function severityColor(percent, colors) {
      if (!isFinite(percent)) return colors.accent;
      if (percent >= 90) return colors.bad;
      if (percent >= 70) return colors.warn;
      return colors.good;
    }
    function intensityColor(ratio, colors) {
      const r = Math.max(0, Math.min(1, Number(ratio) || 0));
      if (r >= 0.85) return colors.bad;
      if (r >= 0.55) return colors.warn;
      if (r >= 0.25) return colors.accent;
      return colors.accentSoft;
    }

    function setupCanvas(canvasId, minHeight) {
      const canvas = document.getElementById(canvasId);
      if (!canvas) return null;
      const dpr = window.devicePixelRatio || 1;
      const widthCss = Math.max(320, Math.floor(canvas.clientWidth || 320));
      const heightCss = Math.max(minHeight, Math.floor(minHeight));
      canvas.width = Math.floor(widthCss * dpr);
      canvas.height = Math.floor(heightCss * dpr);
      const ctx = canvas.getContext("2d");
      if (!ctx) return null;
      ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
      return { ctx, width: widthCss, height: heightCss };
    }

    function fitLabel(ctx, text, maxWidth) {
      const value = String(text || "");
      if (ctx.measureText(value).width <= maxWidth) {
        return value;
      }
      let end = value.length;
      while (end > 0 && ctx.measureText(value.slice(0, end) + "...").width > maxWidth) {
        end -= 1;
      }
      return end > 0 ? value.slice(0, end) + "..." : "...";
    }

    function fillRoundedRect(ctx, x, y, width, height, radius) {
      const r = Math.max(0, Math.min(radius, Math.floor(Math.min(width, height) / 2)));
      ctx.beginPath();
      ctx.moveTo(x + r, y);
      ctx.lineTo(x + width - r, y);
      ctx.quadraticCurveTo(x + width, y, x + width, y + r);
      ctx.lineTo(x + width, y + height - r);
      ctx.quadraticCurveTo(x + width, y + height, x + width - r, y + height);
      ctx.lineTo(x + r, y + height);
      ctx.quadraticCurveTo(x, y + height, x, y + height - r);
      ctx.lineTo(x, y + r);
      ctx.quadraticCurveTo(x, y, x + r, y);
      ctx.closePath();
      ctx.fill();
    }

    function drawHorizontalBars(canvasId, entries, valueKey, valueFormatter, options) {
      const setup = setupCanvas(canvasId, 260);
      if (!setup) return;
      const opts = options || {};
      const colorMode = opts.colorMode || "intensity";
      const showScaleAt100 = !!opts.scaleAtHundred;
      const canvasNode = document.getElementById(canvasId);
      const ctx = setup.ctx;
      const width = setup.width;
      const height = setup.height;
      const colors = themeColors();
      const hitZones = [];

      ctx.clearRect(0, 0, width, height);

      if (!entries.length) {
        ctx.fillStyle = colors.muted;
        ctx.font = chartFont(13, 500);
        ctx.fillText("No chart data available.", 12, 22);
        chartHitZones.set(canvasId, hitZones);
        if (canvasNode) {
          canvasNode.style.cursor = "default";
        }
        return;
      }

      const top = 14;
      const bottom = height - 6;
      const labelArea = Math.min(230, Math.max(108, Math.floor(width * 0.36)));
      const left = 10 + labelArea;
      const right = width - 16;
      const valueLane = 72;
      const maxRows = Math.max(1, Math.floor((bottom - top) / 22));
      const visibleEntries = entries.slice(0, maxRows);
      const rowHeight = Math.max(20, Math.floor((bottom - top) / visibleEntries.length));
      const barHeight = Math.max(10, Math.floor(rowHeight * 0.46));
      const widthAvailable = Math.max(24, right - left - valueLane);
      const dataMax = Math.max(
        0,
        ...visibleEntries.map(function (entry) {
          const value = Number(entry[valueKey]);
          return Number.isFinite(value) ? value : 0;
        }),
      );
      const scaleMax = showScaleAt100 ? 100 : Math.max(1, dataMax);

      if (showScaleAt100) {
        const tickValues = [25, 50, 75, 100];
        ctx.save();
        ctx.strokeStyle = colors.line;
        ctx.globalAlpha = 0.35;
        ctx.lineWidth = 1;
        ctx.setLineDash([2, 4]);
        tickValues.forEach(function (tick) {
          const x = left + Math.floor(widthAvailable * (tick / 100));
          ctx.beginPath();
          ctx.moveTo(x + 0.5, top);
          ctx.lineTo(x + 0.5, top + visibleEntries.length * rowHeight - 4);
          ctx.stroke();
        });
        ctx.restore();
        ctx.fillStyle = colors.muted;
        ctx.font = chartFont(10, 500);
        tickValues.forEach(function (tick) {
          const x = left + Math.floor(widthAvailable * (tick / 100));
          const label = tick + "%";
          const labelWidth = ctx.measureText(label).width;
          ctx.fillText(label, x - labelWidth / 2, bottom + 0);
        });
      }

      visibleEntries.forEach(function (entry, index) {
        const value = Number(entry[valueKey]);
        const safeValue = Number.isFinite(value) ? value : 0;
        const y = top + index * rowHeight;
        const label = String(entry.label || entry.name || "");
        const ratio = scaleMax > 0 ? safeValue / scaleMax : 0;
        const barWidth = Math.max(2, Math.floor(widthAvailable * Math.max(0, Math.min(1, ratio))));

        ctx.fillStyle = colors.text;
        ctx.font = chartFont(12, 500);
        const displayLabel = fitLabel(ctx, label, labelArea - 8);
        ctx.fillText(displayLabel, 8, y + Math.floor(barHeight * 0.85));

        ctx.fillStyle = colors.track1;
        fillRoundedRect(ctx, left, y, widthAvailable, barHeight, 5);

        let color;
        if (colorMode === "severity") {
          color = severityColor(safeValue, colors);
        } else {
          const dataRatio = dataMax > 0 ? safeValue / dataMax : 0;
          color = intensityColor(dataRatio, colors);
        }
        const barGradient = ctx.createLinearGradient(left, y, left + Math.max(barWidth, 1), y);
        barGradient.addColorStop(0, color);
        barGradient.addColorStop(1, "color-mix" in CSS ? color : color);
        ctx.fillStyle = color;
        fillRoundedRect(ctx, left, y, barWidth, barHeight, 5);

        ctx.save();
        ctx.globalAlpha = 0.18;
        ctx.fillStyle = "#ffffff";
        fillRoundedRect(ctx, left, y, barWidth, Math.max(2, Math.floor(barHeight * 0.45)), 5);
        ctx.restore();

        ctx.fillStyle = colors.text;
        ctx.font = chartFont(11, 600);
        const valueText = valueFormatter(safeValue);
        const valueWidth = ctx.measureText(valueText).width;
        const textX = Math.max(8, Math.min(right - valueWidth, left + barWidth + 6));
        ctx.fillText(valueText, textX, y + Math.floor(barHeight * 0.85));

        hitZones.push({
          x: left,
          y: y,
          width: Math.max(1, widthAvailable),
          height: barHeight,
          entry: entry,
          index: index,
        });
      });

      chartHitZones.set(canvasId, hitZones);
      if (canvasNode) {
        canvasNode.style.cursor = hitZones.length ? "pointer" : "default";
      }
    }

    function drawDiffImpact(canvasId, entries) {
      const setup = setupCanvas(canvasId, 260);
      if (!setup) return;
      const canvasNode = document.getElementById(canvasId);
      const ctx = setup.ctx;
      const width = setup.width;
      const height = setup.height;
      const colors = themeColors();
      const hitZones = [];

      ctx.clearRect(0, 0, width, height);
      if (!entries.length) {
        ctx.fillStyle = colors.muted;
        ctx.font = chartFont(13, 500);
        ctx.fillText("No baseline diff chart data available.", 12, 22);
        chartHitZones.set(canvasId, hitZones);
        if (canvasNode) {
          canvasNode.style.cursor = "default";
        }
        return;
      }

      const centerX = Math.floor(width * 0.55);
      const top = 14;
      const maxRows = Math.max(1, Math.floor((height - top - 8) / 18));
      const visibleEntries = entries.slice(0, maxRows);
      const rowHeight = Math.max(18, Math.floor((height - top - 8) / visibleEntries.length));
      const barHeight = Math.max(10, Math.floor(rowHeight * 0.48));
      const maxAbs = Math.max(
        1,
        ...visibleEntries.map(function (entry) {
          const delta = Number(entry.delta);
          return Number.isFinite(delta) ? Math.abs(delta) : 0;
        }),
      );

      ctx.strokeStyle = colors.line;
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(centerX, 6);
      ctx.lineTo(centerX, height - 6);
      ctx.stroke();

      visibleEntries.forEach(function (entry, index) {
        const delta = Number(entry.delta);
        const safeDelta = Number.isFinite(delta) ? delta : 0;
        const ratio = Math.abs(safeDelta) / maxAbs;
        const maxBarWidth = Math.floor(width * 0.36);
        const barWidth = Math.max(2, Math.floor(maxBarWidth * ratio));
        const y = top + index * rowHeight;
        const labelRaw = String(entry.label || "");
        const label = labelRaw.length > 28 ? labelRaw.slice(0, 25) + "..." : labelRaw;

        const isRegression = safeDelta > 0;
        const barX = isRegression ? centerX : centerX - barWidth;
        ctx.fillStyle = isRegression ? colors.bad : colors.good;
        fillRoundedRect(ctx, barX, y, barWidth, barHeight, 5);

        ctx.fillStyle = colors.text;
        ctx.font = chartFont(12, 500);
        const displayLabel = fitLabel(ctx, label, Math.max(90, Math.floor(width * 0.42)));
        ctx.fillText(displayLabel, 8, y + Math.floor(barHeight * 0.85));

        const deltaText = formatSignedBytesLabel(safeDelta);
        const deltaWidth = ctx.measureText(deltaText).width;
        ctx.font = chartFont(11, 600);
        const preferredX = isRegression ? barX + barWidth + 6 : barX - deltaWidth - 6;
        const textX = Math.max(8, Math.min(width - deltaWidth - 8, preferredX));
        ctx.fillText(deltaText, textX, y + Math.floor(barHeight * 0.85));

        hitZones.push({
          x: Math.min(barX, centerX),
          y: y,
          width: Math.max(2, Math.abs(barWidth)),
          height: barHeight,
          entry: entry,
          index: index,
        });
      });

      chartHitZones.set(canvasId, hitZones);
      if (canvasNode) {
        canvasNode.style.cursor = hitZones.length ? "pointer" : "default";
      }
    }

    function chartEntryFromEvent(canvasId, event) {
      const canvas = document.getElementById(canvasId);
      if (!(canvas instanceof HTMLCanvasElement)) {
        return null;
      }
      const zones = chartHitZones.get(canvasId) || [];
      if (!zones.length) {
        return null;
      }
      const rect = canvas.getBoundingClientRect();
      const x = event.clientX - rect.left;
      const y = event.clientY - rect.top;
      for (const zone of zones) {
        if (
          x >= zone.x &&
          x <= zone.x + zone.width &&
          y >= zone.y &&
          y <= zone.y + zone.height
        ) {
          return zone.entry || null;
        }
      }
      return null;
    }

    function setupCanvasDrillthrough() {
      const handlers = {
        "region-util-chart": function (entry) {
          const region = normalizeFilterText(entry?.label);
          runtimeSelectionContext.setFiltersFromRuntimeSelection({
            source: "canvas-region-util",
            region: region,
            drill_section: "section-explorer",
          });
        },
        "top-symbol-chart": function (entry) {
          const symbolName = normalizeFilterText(entry?.label);
          runtimeSelectionContext.setFiltersFromRuntimeSelection({
            source: "canvas-top-symbols",
            section: symbolName,
            symbol_name: symbolName,
            drill_section: "top-contributors",
          });
        },
        "component-ram-chart": function (entry) {
          const component = normalizeFilterText(entry?.label);
          runtimeSelectionContext.setFiltersFromRuntimeSelection({
            source: "canvas-component-ram",
            component: component,
            drill_section: "top-functions",
          });
        },
        "diff-impact-chart": function (entry) {
          const region = normalizeFilterText(entry?.label);
          runtimeSelectionContext.setFiltersFromRuntimeSelection({
            source: "canvas-diff-impact",
            region: region,
            drill_section: "section-explorer",
          });
        },
      };

      Object.keys(handlers).forEach(function (canvasId) {
        const canvas = document.getElementById(canvasId);
        if (!(canvas instanceof HTMLCanvasElement)) {
          return;
        }
        if (canvas.dataset.drillthroughBound === "1") {
          return;
        }
        canvas.addEventListener("click", function (event) {
          const entry = chartEntryFromEvent(canvasId, event);
          if (!entry) {
            return;
          }
          handlers[canvasId](entry);
        });
        canvas.dataset.drillthroughBound = "1";
      });
    }

    function renderInsightBars(containerId, entries, valueKey, valueFormatter, options) {
      const container = document.getElementById(containerId);
      if (!container) return;
      const opts = options || {};
      const colorMode = opts.colorMode || "intensity";
      const scaleAtHundred = !!opts.scaleAtHundred;
      const maxRows = Math.max(1, Number(opts.maxRows) || 10);
      container.innerHTML = "";

      if (!entries || !entries.length) {
        const empty = document.createElement("div");
        empty.className = "insight-empty";
        empty.textContent = "No data available.";
        container.appendChild(empty);
        return;
      }

      const visible = entries.slice(0, maxRows);
      const dataMax = visible.reduce(function (acc, entry) {
        const value = Number(entry[valueKey]);
        return Number.isFinite(value) && value > acc ? value : acc;
      }, 0);
      const scaleMax = scaleAtHundred ? 100 : Math.max(1, dataMax);

      visible.forEach(function (entry, index) {
        const value = Number(entry[valueKey]);
        const safeValue = Number.isFinite(value) ? value : 0;
        const ratio = scaleMax > 0 ? safeValue / scaleMax : 0;
        const widthPct = Math.max(0, Math.min(100, ratio * 100));

        const row = document.createElement("div");
        row.className = "insight-row";
        row.setAttribute("role", "button");
        row.setAttribute("tabindex", "0");
        row.dataset.entryIndex = String(index);

        const label = document.createElement("div");
        label.className = "insight-label";
        const labelText = String(entry.label || entry.name || "");
        label.textContent = labelText;
        label.title = labelText;

        const track = document.createElement("div");
        track.className = "insight-track";
        const fill = document.createElement("span");
        fill.className = "insight-fill";
        if (colorMode === "severity") {
          if (safeValue >= 90) fill.classList.add("is-danger");
          else if (safeValue >= 70) fill.classList.add("is-warning");
        } else {
          const dataRatio = dataMax > 0 ? safeValue / dataMax : 0;
          if (dataRatio >= 0.85) fill.classList.add("is-danger");
          else if (dataRatio >= 0.55) fill.classList.add("is-warning");
        }
        track.appendChild(fill);

        const value$ = document.createElement("div");
        value$.className = "insight-value";
        value$.textContent = valueFormatter(safeValue, entry);

        row.appendChild(label);
        row.appendChild(track);
        row.appendChild(value$);

        row._entry = entry;
        container.appendChild(row);

        window.requestAnimationFrame(function () {
          fill.style.width = widthPct.toFixed(2) + "%";
        });
      });

      if (scaleAtHundred) {
        const scale = document.createElement("div");
        scale.className = "insight-scale";
        const spacer = document.createElement("div");
        const bar = document.createElement("div");
        bar.className = "insight-scale-bar";
        [0, 25, 50, 75, 100].forEach(function (tick) {
          const tickEl = document.createElement("span");
          tickEl.textContent = tick + "%";
          tickEl.style.left = tick + "%";
          if (tick === 0) tickEl.style.transform = "translateX(0)";
          if (tick === 100) tickEl.style.transform = "translateX(-100%)";
          bar.appendChild(tickEl);
        });
        const spacerEnd = document.createElement("div");
        spacerEnd.className = "insight-scale-spacer";
        scale.appendChild(spacer);
        scale.appendChild(bar);
        scale.appendChild(spacerEnd);
        container.appendChild(scale);
      }
    }

    function setupInsightDrillthrough() {
      const handlers = {
        "region-util-chart": function (entry) {
          const region = normalizeFilterText(entry?.label);
          runtimeSelectionContext.setFiltersFromRuntimeSelection({
            source: "insight-region-util",
            region: region,
            drill_section: "section-explorer",
          });
        },
        "top-symbol-chart": function (entry) {
          const symbolName = normalizeFilterText(entry?.label);
          runtimeSelectionContext.setFiltersFromRuntimeSelection({
            source: "insight-top-symbols",
            section: symbolName,
            symbol_name: symbolName,
            drill_section: "top-contributors",
          });
        },
        "component-ram-chart": function (entry) {
          const component = normalizeFilterText(entry?.label);
          runtimeSelectionContext.setFiltersFromRuntimeSelection({
            source: "insight-component-ram",
            component: component,
            drill_section: "top-functions",
          });
        },
      };
      Object.keys(handlers).forEach(function (id) {
        const container = document.getElementById(id);
        if (!container || container.dataset.insightBound === "1") return;
        container.dataset.insightBound = "1";
        const trigger = function (target) {
          const row = target.closest(".insight-row");
          if (!row || !row._entry) return;
          handlers[id](row._entry);
        };
        container.addEventListener("click", function (event) {
          trigger(event.target);
        });
        container.addEventListener("keydown", function (event) {
          if (event.key === "Enter" || event.key === " ") {
            event.preventDefault();
            trigger(event.target);
          }
        });
      });
    }

    function renderAllCharts() {
      renderInsightBars(
        "region-util-chart",
        chartData.regions,
        "percent",
        function (value) { return value.toFixed(1) + "%"; },
        { colorMode: "severity", scaleAtHundred: true, maxRows: 12 },
      );

      renderInsightBars(
        "top-symbol-chart",
        chartData.topSymbols,
        "size",
        function (value) { return formatBytesLabel(value); },
        { colorMode: "intensity", maxRows: 10 },
      );

      renderInsightBars(
        "component-ram-chart",
        chartData.components,
        "ram",
        function (value) { return formatBytesLabel(value); },
        { colorMode: "intensity", maxRows: 10 },
      );

      drawDiffImpact("diff-impact-chart", chartData.diffEntries);
      setupInsightDrillthrough();
    }

    function applySectionFilters() {
      const table = document.getElementById("sections-table");
      if (!table) return;
      const text = (document.getElementById("section-filter-text")?.value || "").trim().toLowerCase();
      const region = (document.getElementById("section-filter-region")?.value || "").trim();
      const rows = Array.from(table.querySelectorAll("tbody tr"));
      let visible = 0;
      rows.forEach(function (row) {
        const search = (row.getAttribute("data-search") || "").toLowerCase();
        const rowRegion = row.getAttribute("data-region") || "";
        const matchesText = !text || search.includes(text);
        const matchesRegion = !region || rowRegion === region;
        const isVisible = matchesText && matchesRegion;
        row.style.display = isVisible ? "" : "none";
        if (isVisible) visible += 1;
      });
      const rendered = applyRowBudget(table, "sections");
      const label = document.getElementById("section-filter-count");
      if (label) {
        if (rendered >= 0 && rendered < visible) {
          label.textContent = "Showing " + rendered + " of " + visible + " matches (" + rows.length + " total)";
        } else {
          label.textContent = "Showing " + visible + " / " + rows.length + " sections";
        }
      }
      return visible;
    }

    function applyIssueFilters() {
      const table = document.getElementById("issues-table");
      if (!table) return;
      const text = (document.getElementById("issue-filter-text")?.value || "").trim().toLowerCase();
      const severity = (document.getElementById("issue-filter-severity")?.value || "").trim();
      const rows = Array.from(table.querySelectorAll("tbody tr"));
      let visible = 0;
      rows.forEach(function (row) {
        const search = (row.getAttribute("data-search") || "").toLowerCase();
        const rowSeverity = row.getAttribute("data-severity") || "";
        const matchesText = !text || search.includes(text);
        const matchesSeverity = !severity || rowSeverity === severity;
        const isVisible = matchesText && matchesSeverity;
        row.style.display = isVisible ? "" : "none";
        if (isVisible) visible += 1;
      });
      const rendered = applyRowBudget(table, "issues");
      const label = document.getElementById("issue-filter-count");
      if (label) {
        if (rendered >= 0 && rendered < visible) {
          label.textContent = "Showing " + rendered + " of " + visible + " matches (" + rows.length + " total)";
        } else {
          label.textContent = "Showing " + visible + " / " + rows.length + " issues";
        }
      }
      return visible;
    }

    const __vlistState = { sections: false, issues: false };
    function applyRowBudget(table, key) {
      const budget = parseInt(table.getAttribute("data-vlist-budget") || "0", 10);
      const showAll = !!__vlistState[key];
      const footer = document.querySelector('.vlist-footer[data-vlist-footer-for="' + table.id + '"]');
      if (!budget || showAll) {
        if (footer) {
          const note = footer.querySelector(".vlist-footer-note");
          const toggle = footer.querySelector(".vlist-footer-toggle");
          if (showAll && budget) {
            footer.hidden = false;
            if (note) note.textContent = "All rows shown - filtering a large list may slow down.";
            if (toggle) {
              toggle.textContent = "Clip back to " + budget;
              toggle.setAttribute("aria-pressed", "true");
            }
          } else if (footer) {
            footer.hidden = true;
          }
        }
        Array.from(table.querySelectorAll("tbody tr.vlist-clipped")).forEach(function (row) {
          row.classList.remove("vlist-clipped");
        });
        return -1;
      }
      let visibleSeen = 0;
      let clipped = 0;
      const rows = table.querySelectorAll("tbody tr");
      for (let i = 0; i < rows.length; i += 1) {
        const row = rows[i];
        const hiddenByFilter = row.style.display === "none";
        if (hiddenByFilter) {
          row.classList.remove("vlist-clipped");
          continue;
        }
        if (visibleSeen < budget) {
          row.classList.remove("vlist-clipped");
          visibleSeen += 1;
        } else {
          row.classList.add("vlist-clipped");
          clipped += 1;
        }
      }
      if (footer) {
        const note = footer.querySelector(".vlist-footer-note");
        const toggle = footer.querySelector(".vlist-footer-toggle");
        if (clipped > 0) {
          footer.hidden = false;
          if (note) note.textContent = "Rendering first " + budget + " rows. " + clipped + " more hidden for responsiveness.";
          if (toggle) {
            toggle.textContent = "Show all " + (visibleSeen + clipped);
            toggle.setAttribute("aria-pressed", "false");
          }
        } else {
          footer.hidden = true;
        }
      }
      return visibleSeen;
    }

    function setupVlistFooters() {
      document.querySelectorAll(".vlist-footer .vlist-footer-toggle").forEach(function (toggle) {
        const footer = toggle.closest(".vlist-footer");
        if (!footer) return;
        const tableId = footer.getAttribute("data-vlist-footer-for") || "";
        const table = tableId ? document.getElementById(tableId) : null;
        const key = table ? table.getAttribute("data-vlist") : "";
        if (!table || !key) return;
        toggle.addEventListener("click", function () {
          __vlistState[key] = !__vlistState[key];
          if (key === "sections") {
            applySectionFilters();
          } else if (key === "issues") {
            applyIssueFilters();
          }
        });
      });
    }

    function applySymbolFilters(tableId, regionSelectId, componentSelectId, countId, noun) {
      const table = document.getElementById(tableId);
      if (!table) return;
      const region = (document.getElementById(regionSelectId)?.value || "").trim();
      const component = (document.getElementById(componentSelectId)?.value || "").trim();
      const rows = Array.from(table.querySelectorAll("tbody tr"));
      let visible = 0;
      rows.forEach(function (row) {
        const rowRegion = row.getAttribute("data-region") || "";
        const rowComponent = row.getAttribute("data-component") || "";
        const matchesRegion = !region || rowRegion === region;
        const matchesComponent = !component || rowComponent === component;
        const isVisible = matchesRegion && matchesComponent;
        row.style.display = isVisible ? "" : "none";
        if (isVisible) visible += 1;
      });
      const label = document.getElementById(countId);
      if (label) label.textContent = "Showing " + visible + " / " + rows.length + " " + noun;
      return visible;
    }

    function applyGlobalFilters() {
      applySymbolFilters(
        "globals-table",
        "globals-filter-region",
        "globals-filter-component",
        "globals-filter-count",
        "globals",
      );
    }

    function applyFunctionFilters() {
      applySymbolFilters(
        "functions-table",
        "functions-filter-region",
        "functions-filter-component",
        "functions-filter-count",
        "functions",
      );
    }

    function applySharedFilters(options) {
      const opts = options && typeof options === "object" ? options : {};
      syncControlsFromSharedState();
      applySectionFilters();
      applyIssueFilters();
      applyGlobalFilters();
      applyFunctionFilters();
      if (opts.refreshRuntime && typeof window.__memscopeRefreshRuntimeViews === "function") {
        window.__memscopeRefreshRuntimeViews();
      }
    }

    function setFiltersFromRuntimeSelection(selection) {
      const payload = selection && typeof selection === "object" ? selection : {};
      const source = normalizeFilterText(payload.source);
      const suppressScroll = Boolean(payload.no_scroll) || source === "layout-explorer";
      const suppressFilterSync = Boolean(payload.no_filter_sync);
      const objectToComponent = mapObjectToComponent();
      const region = normalizeFilterText(payload.region || payload.region_name);
      const objectName = normalizeFilterText(payload.object || payload.object_name);
      const providedComponent = normalizeFilterText(payload.component || payload.component_name);
      const inferredComponent = providedComponent || (objectName ? objectToComponent.get(objectName) || "" : "");
      const sectionName = normalizeFilterText(
        payload.section || payload.section_name || payload.symbol_name || payload.label
      );
      const issueIds = Array.isArray(payload.issue_ids)
        ? payload.issue_ids.map(function (item) { return normalizeFilterText(item); }).filter(Boolean)
        : [];
      const issueId = normalizeFilterText(payload.issue_id || (issueIds.length ? issueIds[0] : ""));
      const issueSeverity = normalizeFilterText(payload.issue_severity || payload.severity);

      if (!suppressFilterSync) {
        if (region) {
          sharedFilters.region = region;
        }
        if (inferredComponent) {
          sharedFilters.component = inferredComponent;
        }
        if (sectionName) {
          sharedFilters.sectionQuery = sectionName;
        }
        if (issueId) {
          sharedFilters.issueQuery = issueId;
        }
        if (issueSeverity) {
          sharedFilters.issueSeverity = issueSeverity;
        }
        applySharedFilters({ refreshRuntime: true });
      }
      if (source !== "share-link") {
        try {
          updateShareState({
            region: region || sharedFilters.region || "",
            component: inferredComponent || sharedFilters.component || "",
          });
        } catch (_) {}
      }

      const symbolName = normalizeFilterText(payload.symbol_name);
      let drillSection = normalizeFilterText(payload.drill_section);
      let rowTarget = null;
      if (issueId) {
        drillSection = "issues";
        rowTarget = findRowByData("issues-table", "issueId", issueId);
      } else if (symbolName) {
        drillSection = drillSection || "top-contributors";
        rowTarget = findRowByData("top-symbols-table", "symbol", symbolName);
      } else if (sectionName) {
        drillSection = drillSection || "section-explorer";
        rowTarget = findRowByData("sections-table", "name", sectionName);
      } else if (objectName) {
        drillSection = drillSection || "top-contributors";
        rowTarget = findRowByData("top-objects-table", "object", objectName);
      } else if (inferredComponent) {
        drillSection = drillSection || "top-functions";
        rowTarget = findRowByData("functions-table", "component", inferredComponent);
      } else if (region) {
        drillSection = drillSection || "section-explorer";
        rowTarget = findRowByData("sections-table", "region", region);
      }

      if (drillSection && !suppressScroll) {
        scrollToSectionAndHighlight(drillSection, rowTarget);
      }
    }

    runtimeSelectionContext.setFiltersFromRuntimeSelection = setFiltersFromRuntimeSelection;
    runtimeSelectionContext.scrollToSectionAndHighlight = scrollToSectionAndHighlight;
    runtimeSelectionContext.getFilters = function () {
      return {
        region: normalizeFilterText(sharedFilters.region),
        component: normalizeFilterText(sharedFilters.component),
        section_query: normalizeFilterText(sharedFilters.sectionQuery),
        issue_query: normalizeFilterText(sharedFilters.issueQuery),
        issue_severity: normalizeFilterText(sharedFilters.issueSeverity),
      };
    };

    document.getElementById("section-filter-text")?.addEventListener("input", function () {
      sharedFilters.sectionQuery = normalizeFilterText(document.getElementById("section-filter-text")?.value);
      applySharedFilters({ refreshRuntime: true });
    });
    document.getElementById("section-filter-region")?.addEventListener("change", function () {
      sharedFilters.region = normalizeFilterText(document.getElementById("section-filter-region")?.value);
      applySharedFilters({ refreshRuntime: true });
    });
    document.getElementById("issue-filter-text")?.addEventListener("input", function () {
      sharedFilters.issueQuery = normalizeFilterText(document.getElementById("issue-filter-text")?.value);
      applySharedFilters({ refreshRuntime: true });
    });
    document.getElementById("issue-filter-severity")?.addEventListener("change", function () {
      sharedFilters.issueSeverity = normalizeFilterText(document.getElementById("issue-filter-severity")?.value);
      applySharedFilters({ refreshRuntime: true });
    });
    document.getElementById("globals-filter-region")?.addEventListener("change", function () {
      sharedFilters.region = normalizeFilterText(document.getElementById("globals-filter-region")?.value);
      applySharedFilters({ refreshRuntime: true });
    });
    document.getElementById("globals-filter-component")?.addEventListener("change", function () {
      sharedFilters.component = normalizeFilterText(document.getElementById("globals-filter-component")?.value);
      applySharedFilters({ refreshRuntime: true });
    });
    document.getElementById("functions-filter-region")?.addEventListener("change", function () {
      sharedFilters.region = normalizeFilterText(document.getElementById("functions-filter-region")?.value);
      applySharedFilters({ refreshRuntime: true });
    });
    document.getElementById("functions-filter-component")?.addEventListener("change", function () {
      sharedFilters.component = normalizeFilterText(document.getElementById("functions-filter-component")?.value);
      applySharedFilters({ refreshRuntime: true });
    });

    function initializeRuntimeRenderers() {
      const renderers = window.MemScopeRenderers || {};
      const runtimeVersion = window.MemScopeRuntime?.version || "unknown";
      const explorer = renderers.layoutExplorer;
      if (typeof explorer === "function") {
        explorer({
          containerId: "memory-layout-explorer",
          minimapContainerId: "memory-layout-minimap",
          tooltipId: "memory-layout-tooltip",
          panelId: "memory-layout-side-panel",
          panelContentId: "memory-layout-side-panel-content",
          panelCloseId: "memory-layout-side-panel-close",
          panelBackdropId: "memory-layout-side-panel-backdrop",
          payload: visualizationData,
          options: {
            runtimeVersion: runtimeVersion,
            manifest: runtimeManifest,
            getFilters: runtimeSelectionContext.getFilters,
            onSelect: runtimeSelectionContext.setFiltersFromRuntimeSelection,
          }
        });
      }
    }

    window.__memscopeRefreshRuntimeViews = function () {
      const explorer = window.__memscopeLayoutExplorer;
      if (explorer && typeof explorer.applyFilters === "function") {
        explorer.applyFilters();
      }
    };

    function setupToolbarFieldHighlights() {
      const toolbars = Array.from(document.querySelectorAll(".toolbar, .filter-bar, .filter-item"));
      if (!toolbars.length) return;
      const seen = new Set();
      toolbars.forEach(function (toolbar) {
        const controls = Array.from(toolbar.querySelectorAll("input, select"));
        controls.forEach(function (control) {
          if (seen.has(control)) return;
          seen.add(control);
          if (control.parentElement && control.parentElement.classList.contains("toolbar-field")) {
            return;
          }
          const wrap = document.createElement("span");
          wrap.className = "toolbar-field";
          control.parentNode.insertBefore(wrap, control);
          wrap.appendChild(control);
          if (control.tagName === "SELECT") {
            const defaultValue = control.dataset.defaultValue
              || (control.options && control.options.length ? control.options[0].value : "");
            const refresh = function () {
              const isActive = control.value !== "" && control.value !== defaultValue;
              if (isActive) {
                control.setAttribute("data-has-value", "true");
              } else {
                control.removeAttribute("data-has-value");
              }
            };
            control.addEventListener("change", refresh);
            control.addEventListener("input", refresh);
            refresh();
          } else if (control.tagName === "INPUT") {
            const refresh = function () {
              if (control.value && control.value.length > 0) {
                control.setAttribute("data-has-value", "true");
              } else {
                control.removeAttribute("data-has-value");
              }
            };
            control.addEventListener("input", refresh);
            control.addEventListener("change", refresh);
            refresh();
          }
        });
      });
    }

    function setupQuickLinkSpy() {
      const links = Array.from(document.querySelectorAll(".quick-links a[href^='#']"));
      if (!links.length || typeof IntersectionObserver === "undefined") {
        return;
      }
      const lookup = new Map();
      links.forEach(function (link) {
        const hash = link.getAttribute("href");
        if (!hash) return;
        const target = document.querySelector(hash);
        if (target) lookup.set(target, link);
      });
      if (!lookup.size) return;

      const observer = new IntersectionObserver(
        function (entries) {
          entries.forEach(function (entry) {
            const link = lookup.get(entry.target);
            if (!link) return;
            if (entry.isIntersecting) {
              links.forEach(function (item) { item.classList.remove("active"); });
              link.classList.add("active");
            }
          });
        },
        { rootMargin: "-22% 0px -65% 0px", threshold: 0.05 },
      );

      lookup.forEach(function (_link, section) { observer.observe(section); });
    }

    window.addEventListener("resize", function () {
      window.clearTimeout(window.__memscopeResizeTimer);
      window.__memscopeResizeTimer = window.setTimeout(renderAllCharts, 80);
    });
    setupSortableTables();
    renderAllCharts();
    setupCanvasDrillthrough();
    setupVlistFooters();
    setupToolbarFieldHighlights();
    applySharedFilters({ refreshRuntime: false });
    initializeRuntimeRenderers();
    setupQuickLinkSpy();
    setupCollapsibleSections();
    animateRegionProgressBars();
    attachCopyButtons();
    try { applyShareStateFromHash(); } catch (_) {}
    window.addEventListener("hashchange", function () {
      try { applyShareStateFromHash(); } catch (_) {}
    });
  </script>
</body>
</html>"""
)


def render_html_report(
    report: AnalysisReport,
    *,
    report_title: str = "MemScope Footprint Report",
) -> str:
    sorted_report = report.sorted_copy()
    summary = {
        "total_flash": sorted_report.summary.total_flash,
        "total_ram": sorted_report.summary.total_ram,
        "issue_counts": {
            "error": int(sorted_report.summary.issue_counts.get("error", 0)),
            "warning": int(sorted_report.summary.issue_counts.get("warning", 0)),
            "info": int(sorted_report.summary.issue_counts.get("info", 0)),
        },
    }

    used_bytes_by_region: dict[str, int] = {}
    section_counts_by_region: dict[str, int] = {}
    for section in sorted_report.sections:
        if section.execution_region:
            used_bytes_by_region[section.execution_region] = (
                used_bytes_by_region.get(section.execution_region, 0) + max(section.size, 0)
            )
            section_counts_by_region[section.execution_region] = section_counts_by_region.get(section.execution_region, 0) + 1

    regions: list[dict[str, object]] = []
    for region in sorted_report.regions:
        ratio = float(sorted_report.summary.utilization_by_region.get(region.name, 0.0))
        percent = round(ratio * 100, 2)
        total_bytes = max(int(region.size or 0), 0)
        used_bytes = max(int(used_bytes_by_region.get(region.name, 0)), 0)
        overflow_bytes = max(used_bytes - total_bytes, 0) if total_bytes > 0 else 0
        free_bytes = max(total_bytes - used_bytes, 0) if total_bytes > 0 else 0
        remaining_percent = round(max(100.0 - percent, 0.0), 2)
        level = "healthy"
        if percent >= 100.0:
            level = "danger"
        elif percent >= 85.0:
            level = "warning"
        sections_count = int(section_counts_by_region.get(region.name, 0))
        category_value = getattr(region.category, "value", str(region.category or "custom"))
        source_value = getattr(region.source_origin, "value", str(region.source_origin or "unknown"))
        attributes = ",".join(sorted(str(attr).upper() for attr in region.attributes)) or "-"
        regions.append(
            {
                "name": region.name,
                "percent": percent,
                "percent_capped": min(percent, 100.0),
                "used_bytes": used_bytes,
                "free_bytes": free_bytes,
                "total_bytes": total_bytes,
                "overflow_bytes": overflow_bytes,
                "remaining_percent": remaining_percent,
                "level": level,
                "sections_count": sections_count,
                "sections_label": "section" if sections_count == 1 else "sections",
                "category": category_value,
                "source_origin": source_value,
                "description": f"Category: {category_value.upper()} | Attr: {attributes}",
            }
        )

    _FLASH_CATS = {"flash", "external_flash"}
    _RAM_CATS = {"ram", "tcm", "retention", "external_ram"}
    flash_capacity = sum(r["total_bytes"] for r in regions if str(r.get("category", "")).lower() in _FLASH_CATS)
    ram_capacity = sum(r["total_bytes"] for r in regions if str(r.get("category", "")).lower() in _RAM_CATS)
    summary["flash_capacity"] = flash_capacity
    summary["ram_capacity"] = ram_capacity
    summary["flash_util_pct"] = round(summary["total_flash"] / flash_capacity * 100, 1) if flash_capacity > 0 else None
    summary["ram_util_pct"] = round(summary["total_ram"] / ram_capacity * 100, 1) if ram_capacity > 0 else None

    components = [
        {
            "name": component.name,
            "total_flash": component.total_flash,
            "total_ram": component.total_ram,
            "symbol_count": len(component.symbols),
        }
        for component in sorted_report.components
    ]
    components.sort(
        key=lambda entry: (
            int(entry.get("total_ram", 0)),
            int(entry.get("total_flash", 0)),
            str(entry.get("name", "")),
        ),
        reverse=True,
    )
    top_symbols = sorted(
        _as_list_of_dicts(sorted_report.trends.get("top_symbols_by_size")),
        key=lambda item: _as_float(item.get("size", 0)),
        reverse=True,
    )
    top_objects = sorted(
        _as_list_of_dicts(sorted_report.trends.get("top_objects_by_size")),
        key=lambda item: _as_float(item.get("size", 0)),
        reverse=True,
    )
    sections = sorted(
        [
            {
                "name": section.name,
                "execution_region": section.execution_region,
                "load_region": section.load_region,
                "size": section.size,
                "search_text": " ".join(
                    filter(
                        None,
                        (
                            section.name,
                            section.execution_region or "",
                            section.load_region or "",
                        ),
                    )
                ),
            }
            for section in sorted_report.sections
        ],
        key=lambda item: _as_float(item.get("size", 0)),
        reverse=True,
    )
    section_to_region: dict[str, str] = {}
    for section in sorted_report.sections:
        name = section.name.strip()
        region_name = (section.execution_region or "").strip()
        if name and region_name and name not in section_to_region:
            section_to_region[name] = region_name

    top_globals, top_functions = _build_symbol_focus_lists(
        sorted_report.symbols,
        section_to_region=section_to_region,
        limit=60,
    )
    global_region_filters = sorted({str(item["region"]) for item in top_globals if str(item["region"]) != "-"})
    global_component_filters = sorted(
        {str(item["component"]) for item in top_globals if str(item["component"]) != "unknown_object"},
    )
    function_region_filters = sorted({str(item["region"]) for item in top_functions if str(item["region"]) != "-"})
    function_component_filters = sorted(
        {str(item["component"]) for item in top_functions if str(item["component"]) != "unknown_object"},
    )
    section_region_filters = sorted(
        {str(section["execution_region"]) for section in sections if section["execution_region"]},
    )
    issues = [
        {
            "id": issue.id,
            "severity": issue.severity.value,
            "category": issue.category.value,
            "title": issue.title,
            "description": issue.description,
            "search_text": " ".join(
                (
                    issue.id,
                    issue.severity.value,
                    issue.category.value,
                    issue.title,
                    issue.description,
                )
            ),
        }
        for issue in sorted_report.issues
    ]
    diagnostics_text = _render_diagnostics_text(sorted_report.diagnostics)
    diagnostics_blocks = _build_diagnostics_blocks(sorted_report.diagnostics)

    diff = dict(sorted_report.regressions) if isinstance(sorted_report.regressions, dict) else {}
    diff.setdefault("status", "not_requested")
    diff["top_regressions"] = _normalize_diff_entries(diff.get("top_regressions"))
    diff["top_reductions"] = _normalize_diff_entries(diff.get("top_reductions"))
    diff.setdefault("flash_delta_bytes", 0)
    diff.setdefault("ram_delta_bytes", 0)

    chart_data = {
        "regions": [
            {"label": str(item["name"]), "percent": _as_float(item.get("percent", 0))}
            for item in sorted(regions, key=lambda entry: _as_float(entry.get("percent", 0)), reverse=True)[:12]
        ],
        "topSymbols": [
            {"label": str(item.get("name", "")), "size": _as_float(item.get("size", 0))}
            for item in top_symbols[:10]
        ],
        "components": [
            {"label": str(item.get("name", "")), "ram": _as_float(item.get("total_ram", 0))}
            for item in sorted(components, key=lambda entry: int(entry.get("total_ram", 0)), reverse=True)[:10]
        ],
        "diffEntries": _build_diff_chart_entries(diff),
    }
    visualization_data = (
        dict(sorted_report.trends.get("visualization"))
        if isinstance(sorted_report.trends.get("visualization"), dict)
        else {}
    )
    features_raw = visualization_data.get("features")
    visualization_features = {
        "sankey_enabled": bool(features_raw.get("sankey_enabled"))
        if isinstance(features_raw, dict)
        else False,
        "relationship_graph_enabled": bool(features_raw.get("relationship_graph_enabled"))
        if isinstance(features_raw, dict)
        else False,
    }
    ownership = visualization_data.get("ownership")
    ownership_rows = 0
    if isinstance(ownership, dict):
        by_object = ownership.get("by_object")
        if isinstance(by_object, list):
            ownership_rows = len(by_object)
    visualization_summary = {
        "schema_version": str(visualization_data.get("schema_version", "unknown")),
        "regions_count": len(visualization_data.get("regions", []))
        if isinstance(visualization_data.get("regions"), list)
        else 0,
        "ownership_rows": ownership_rows,
        "diff_status": str(visualization_data.get("diff", {}).get("status", "not_requested"))
        if isinstance(visualization_data.get("diff"), dict)
        else "not_requested",
    }
    runtime_assets = [
        {
            "name": asset.name,
            "version": asset.version,
            "source": asset.source,
            "code": asset.code,
        }
        for asset in bundled_runtime_assets()
    ]
    runtime_manifest = {
        "runtime": "memscope-html",
        "assets": [
            {
                "name": str(asset["name"]),
                "version": str(asset["version"]),
                "source": str(asset["source"]),
            }
            for asset in runtime_assets
        ],
    }

    insights = _build_insights(
        issues=issues,
        regions=regions,
        diff=diff,
        summary=summary,
        sorted_report=sorted_report,
    )
    diff_narrative = _build_diff_narrative(
        diff=diff,
        regions=regions,
        section_to_region=section_to_region,
    )
    palette_index = _build_palette_index(
        regions=regions,
        components=components,
        sections=sections,
        top_globals=top_globals,
        top_functions=top_functions,
        top_symbols=top_symbols,
        issues=issues,
    )
    address_index = _build_address_index(visualization_data)
    license_footer = _build_license_footer(sorted_report)
    license_chip_label = chip_label_for(sorted_report.metadata.license_mode)
    license_chip_css = chip_css_for(sorted_report.metadata.license_mode)

    return _TEMPLATE.render(
        title=report_title,
        metadata=sorted_report.metadata,
        license_chip_label=license_chip_label,
        license_chip_css=license_chip_css,
        summary=summary,
        visualization_summary=visualization_summary,
        visualization_features=visualization_features,
        regions=regions,
        top_symbols=top_symbols,
        top_objects=top_objects,
        sections=sections,
        top_globals=top_globals,
        top_functions=top_functions,
        global_region_filters=global_region_filters,
        global_component_filters=global_component_filters,
        function_region_filters=function_region_filters,
        function_component_filters=function_component_filters,
        section_region_filters=section_region_filters,
        components=components,
        issues=issues,
        diff=diff,
        diagnostics_text=diagnostics_text,
        diagnostics_blocks=diagnostics_blocks,
        runtime_manifest=runtime_manifest,
        runtime_assets=runtime_assets,
        visualization_data=visualization_data,
        chart_data=chart_data,
        insights=insights,
        diff_narrative=diff_narrative,
        palette_index=palette_index,
        address_index=address_index,
        license_footer=license_footer,
    )


def _build_license_footer(report: AnalysisReport) -> dict[str, str] | None:
    """Build the audit-trail footer block from the report's license diagnostics.

    Returns ``None`` when the report has no license info (e.g., reports
    rendered outside a session, by build_json_payload smoke tests). The
    footer surfaces non-secret identifying info (last 4 chars of license
    id, expiry date, mode) so a customer's compliance/IT team can tell
    which license issued the report without exposing the full key.
    """
    diagnostics = report.diagnostics if isinstance(report.diagnostics, dict) else {}
    block = diagnostics.get("license")
    if not isinstance(block, dict):
        if not report.metadata.license_mode:
            return None
        return {
            "mode": chip_label_for(report.metadata.license_mode) or report.metadata.license_mode,
            "tier": report.metadata.license_tier or "",
            "license_id_tail": "",
            "expires_at": "",
            "machine_fingerprint_tail": "",
            "provider": "local",
        }

    def _tail(value: object, *, length: int) -> str:
        text = str(value or "").strip()
        return text[-length:] if len(text) > length else text

    def _date_only(value: object) -> str:
        text = str(value or "").strip()
        return text.split("T", 1)[0] if "T" in text else text

    raw_mode = str(block.get("state") or report.metadata.license_mode or "unknown")
    return {
        "mode": chip_label_for(raw_mode) or raw_mode,
        "tier": str(block.get("tier") or report.metadata.license_tier or ""),
        "license_id_tail": _tail(block.get("license_id"), length=4),
        "expires_at": _date_only(block.get("expires_at")),
        # Machine fingerprint is intentionally omitted from the LicenseStatus
        # public dict (it's a derived hash, not customer-visible identity).
        # Future: surface a fingerprint hash here if compliance teams ask
        # for it in audit trails.
        "machine_fingerprint_tail": "",
        "provider": str(block.get("provider") or "local"),
    }


def write_html_report(path: Path, report: AnalysisReport) -> None:
    ensure_parent_dir(path)
    path.write_text(render_html_report(report), encoding="utf-8")


def _as_list_of_dicts(value: object) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    result: list[dict[str, Any]] = []
    for item in value:
        if isinstance(item, dict):
            result.append(dict(item))
    return result


def _render_diagnostics_text(diagnostics: dict[str, object]) -> str:
    if not diagnostics:
        return "No diagnostics."
    return json.dumps(diagnostics, indent=2, sort_keys=True, default=str)


def _build_diagnostics_blocks(diagnostics: dict[str, object]) -> list[dict[str, object]]:
    if not diagnostics:
        return [{"title": "No Diagnostics", "summary": "No diagnostics were produced.", "entries": []}]

    blocks: list[dict[str, object]] = []

    parse_assumptions = diagnostics.get("parse_assumptions")
    if isinstance(parse_assumptions, list):
        blocks.append(
            {
                "title": "Parse Assumptions",
                "summary": f"{len(parse_assumptions)} assumption(s) recorded.",
                "entries": [str(item) for item in parse_assumptions[:10]],
            }
        )

    unresolved = diagnostics.get("unresolved_ambiguities")
    if isinstance(unresolved, list):
        blocks.append(
            {
                "title": "Unresolved Ambiguities",
                "summary": f"{len(unresolved)} unresolved ambiguity item(s).",
                "entries": [str(item) for item in unresolved[:10]],
            }
        )

    stack_heap = diagnostics.get("stack_heap_hints")
    if isinstance(stack_heap, dict):
        stack_sections = stack_heap.get("stack_sections")
        heap_sections = stack_heap.get("heap_sections")
        notes = stack_heap.get("notes")
        items: list[str] = []
        if isinstance(stack_sections, list) and stack_sections:
            items.append("stack sections: " + ", ".join(str(item) for item in stack_sections[:6]))
        if isinstance(heap_sections, list) and heap_sections:
            items.append("heap sections: " + ", ".join(str(item) for item in heap_sections[:6]))
        if isinstance(notes, list) and notes:
            items.extend(str(note) for note in notes[:6])
        blocks.append(
            {
                "title": "Stack / Heap Hints",
                "summary": "Heuristic stack/heap markers inferred from sections and symbols.",
                "entries": items,
            }
        )

    multicore = diagnostics.get("multicore")
    if isinstance(multicore, dict):
        cores = multicore.get("cores")
        unassigned_sections = multicore.get("unassigned_sections")
        unassigned_symbols = multicore.get("unassigned_symbols")
        summary_parts: list[str] = []
        if isinstance(cores, list):
            summary_parts.append(f"cores={len(cores)}")
        if isinstance(unassigned_sections, int):
            summary_parts.append(f"unassigned_sections={unassigned_sections}")
        if isinstance(unassigned_symbols, int):
            summary_parts.append(f"unassigned_symbols={unassigned_symbols}")
        items = []
        if isinstance(cores, list) and cores:
            items.append("detected cores: " + ", ".join(str(core) for core in cores))
        sources = multicore.get("inference_sources")
        if isinstance(sources, list) and sources:
            items.append("inference sources: " + ", ".join(str(item) for item in sources))
        blocks.append(
            {
                "title": "Multicore Inference",
                "summary": ", ".join(summary_parts) if summary_parts else "No multicore data available.",
                "entries": items,
            }
        )

    policy = diagnostics.get("policy")
    if isinstance(policy, dict):
        blocking = bool(policy.get("blocking"))
        total_issues = policy.get("issues_total", 0)
        summary = f"blocking={blocking}, issues_total={total_issues}"
        items = []
        by_severity = policy.get("issues_by_severity")
        if isinstance(by_severity, dict):
            items.append(
                "severity counts: "
                + ", ".join(f"{key}={value}" for key, value in sorted(by_severity.items()))
            )
        blocking_ids = policy.get("blocking_issue_ids")
        if isinstance(blocking_ids, list) and blocking_ids:
            items.append("blocking issue ids: " + ", ".join(str(item) for item in blocking_ids[:5]))
        blocks.append(
            {
                "title": "Policy Evaluation",
                "summary": summary,
                "entries": items,
            }
        )

    license_info = diagnostics.get("license")
    if isinstance(license_info, dict):
        summary = ", ".join(
            [
                f"state={license_info.get('state')}",
                f"source={license_info.get('source')}",
                f"allowed={license_info.get('allowed')}",
            ]
        )
        items = []
        message = license_info.get("message")
        if message:
            items.append(str(message))
        blocks.append(
            {
                "title": "License Status",
                "summary": summary,
                "entries": items,
            }
        )

        tier = license_info.get("tier")
        # Show the limitations panel whenever paid features are unavailable:
        # FREE (post-trial visibility-only) and the UNAVAILABLE tier
        # (expired / invalid / revoked). TRIAL has paid features unlocked
        # so this panel doesn't apply during the 14-day window.
        if tier in ("free", "unavailable"):
            limitations = [
                "`--strict` (CI policy-gate enforcement) - blocked",
                '"memscope validate" (CI policy gate command) - blocked',
                '"memscope diff" (standalone regression comparison) - blocked',
                "CSV export (`--csv`) - skipped with warning",
                "Custom [budgets] / [policies] / [suppressions] in config - replaced with defaults",
            ]
            ignored = diagnostics.get("trial_overrides_ignored")
            if isinstance(ignored, list) and ignored:
                limitations.append(
                    "This run had ignored config sections: " + ", ".join(str(s) for s in ignored)
                )
            if diagnostics.get("trial_csv_skipped"):
                limitations.append("This run had a --csv output requested but skipped.")
            panel_title = (
                "Free Edition Limitations" if tier == "free" else "License Restrictions"
            )
            blocks.append(
                {
                    "title": panel_title,
                    "summary": (
                        "Run \"memscope license activate <KEY>\" to unlock the "
                        "CI enforcement features listed below. Visibility "
                        "(analyze, baseline diff, HTML/JSON reports) keeps "
                        "working without a license."
                    ),
                    "entries": limitations,
                }
            )

    telemetry = diagnostics.get("telemetry")
    if isinstance(telemetry, dict):
        telemetry_entries = [
            f"{key}: {_format_diagnostic_value(value)}"
            for key, value in sorted(telemetry.items())
        ]
        blocks.append(
            {
                "title": "Telemetry",
                "summary": f"{len(telemetry)} telemetry field(s).",
                "entries": telemetry_entries[:8],
            }
        )

    timings = diagnostics.get("timings")
    if isinstance(timings, dict):
        ordered = sorted(
            ((str(name), _as_float(value)) for name, value in timings.items()),
            key=lambda item: item[1],
            reverse=True,
        )
        items = [f"{name}: {value * 1000:.2f} ms" for name, value in ordered[:8]]
        total_seconds = _as_float(timings.get("total_seconds"))
        blocks.append(
            {
                "title": "Timings",
                "summary": f"total={total_seconds * 1000:.2f} ms",
                "entries": items,
            }
        )

    known_keys = {
        "parse_assumptions",
        "unresolved_ambiguities",
        "stack_heap_hints",
        "multicore",
        "policy",
        "license",
        "telemetry",
        "timings",
    }
    for key, value in sorted(diagnostics.items()):
        if key in known_keys:
            continue
        if isinstance(value, dict):
            entries = [
                f"{child_key}: {_format_diagnostic_value(child_value)}"
                for child_key, child_value in sorted(value.items())
            ]
            if len(entries) > 8:
                entries = entries[:8] + [f"... and {len(value) - 8} more field(s)"]
            blocks.append(
                {
                    "title": key.replace("_", " ").title(),
                    "summary": f"{len(value)} field(s)",
                    "entries": entries,
                }
            )
        elif isinstance(value, list):
            blocks.append(
                {
                    "title": key.replace("_", " ").title(),
                    "summary": f"{len(value)} item(s)",
                    "entries": [_format_diagnostic_value(item) for item in value[:10]],
                }
            )
        else:
            blocks.append(
                {
                    "title": key.replace("_", " ").title(),
                    "summary": _format_diagnostic_value(value),
                    "entries": [],
                }
            )

    return blocks


def _normalize_diff_entries(value: object) -> list[dict[str, object]]:
    if not isinstance(value, list):
        return []
    result: list[dict[str, object]] = []
    for item in value:
        if isinstance(item, dict):
            result.append({str(key): child for key, child in item.items()})
    return result


def _as_float(value: object) -> float:
    if isinstance(value, bool):
        return 0.0
    if isinstance(value, (int, float)):
        return float(value)
    return 0.0


def _format_diagnostic_value(value: object, *, max_length: int = 160) -> str:
    if isinstance(value, dict):
        return f"dict({len(value)} field(s))"
    if isinstance(value, list):
        return f"list({len(value)} item(s))"
    text = str(value).replace("\r", " ").replace("\n", " ").strip()
    compact = " ".join(part for part in text.split(" ") if part)
    if len(compact) <= max_length:
        return compact
    return compact[: max_length - 3] + "..."


def _build_symbol_focus_lists(
    symbols: list[Any],
    *,
    section_to_region: dict[str, str],
    limit: int = 60,
) -> tuple[list[dict[str, object]], list[dict[str, object]]]:
    globals_ranked: list[dict[str, object]] = []
    functions_ranked: list[dict[str, object]] = []

    for symbol in symbols:
        raw_name = str(getattr(symbol, "name", "")).strip()
        name = str(getattr(symbol, "demangled_name", None) or raw_name).strip()
        if not name:
            continue
        size = int(max(_as_float(getattr(symbol, "size", 0)), 0))
        if size <= 0:
            continue

        section_name = str(getattr(symbol, "section_name", None) or "").strip()
        object_name = _derive_symbol_object(symbol, raw_name)
        region_name = section_to_region.get(section_name, "-")
        component_name = object_name or "unknown_object"
        item = {
            "name": name,
            "size": size,
            "section": section_name or "-",
            "region": region_name,
            "component": component_name,
            "object": object_name,
        }

        bucket = _classify_symbol_entry(section_name, raw_name)
        if bucket == "function":
            functions_ranked.append(item)
        elif bucket == "global":
            globals_ranked.append(item)

    def _sorted(items: list[dict[str, object]]) -> list[dict[str, object]]:
        return sorted(
            items,
            key=lambda entry: (
                int(entry.get("size", 0)),
                str(entry.get("name", "")),
            ),
            reverse=True,
        )[:limit]

    return _sorted(globals_ranked), _sorted(functions_ranked)


def _classify_symbol_entry(section_name: str, name: str) -> str | None:
    section = section_name.lower().strip()
    label = name.lower().strip()

    section_tokens = _identifier_tokens(section)
    if section_tokens:
        if "init_array" in section or "fini_array" in section:
            return "global"
        if section_tokens & _DATA_SECTION_TOKENS:
            return "global"
        if section_tokens & _CODE_SECTION_TOKENS:
            return "function"

    # Fallback for synthetic map labels that may embed section-like prefixes.
    label_tokens = _identifier_tokens(label)
    if label.startswith("."):
        if label_tokens & _DATA_SECTION_TOKENS:
            return "global"
        if label_tokens & _CODE_SECTION_TOKENS:
            return "function"

    return None


_CODE_SECTION_TOKENS = frozenset(
    {
        "text",
        "code",
        "startup",
        "vector",
        "vectors",
        "intvec",
        "isr",
        "irq",
        "handler",
        "plt",
        "stub",
        "tramp",
        "ramfunc",
        "ramcode",
    }
)

_DATA_SECTION_TOKENS = frozenset(
    {
        "data",
        "bss",
        "rodata",
        "sdata",
        "sbss",
        "tdata",
        "tbss",
        "heap",
        "stack",
        "got",
        "noinit",
        "noload",
        "ctors",
        "dtors",
        "initarray",
        "finiarray",
    }
)


def _identifier_tokens(value: str) -> set[str]:
    return {token for token in re.split(r"[^a-z0-9]+", value.lower()) if token}


def _derive_symbol_object(symbol: Any, raw_name: str) -> str:
    object_name = str(getattr(symbol, "object_file", None) or getattr(symbol, "archive", None) or "").strip()
    if object_name:
        return object_name

    if "(" in raw_name and ")" in raw_name:
        inner = raw_name.rsplit("(", 1)[1].split(")", 1)[0].strip()
        if inner:
            return inner
    return "unknown_object"


def _build_diff_narrative(
    *,
    diff: dict[str, object],
    regions: list[dict[str, object]],
    section_to_region: dict[str, str] | None = None,
) -> dict[str, object]:
    status = str(diff.get("status", "not_requested"))
    if status not in {"ok"}:
        return {
            "status": status,
            "has_data": False,
            "baseline_path": str(diff.get("baseline_path") or ""),
            "net_delta_bytes": 0,
            "net_delta_label": "0",
            "regression_count": 0,
            "reduction_count": 0,
            "flash_delta_bytes": int(_as_float(diff.get("flash_delta_bytes", 0))),
            "ram_delta_bytes": int(_as_float(diff.get("ram_delta_bytes", 0))),
            "flash_delta_label": _format_signed_compact(int(_as_float(diff.get("flash_delta_bytes", 0)))),
            "ram_delta_label": _format_signed_compact(int(_as_float(diff.get("ram_delta_bytes", 0)))),
            "spark_entries": [],
            "region_deltas": [],
            "drivers": {"components": [], "sections": [], "symbols": [], "objects": []},
            "baseline_candidates": _detect_baseline_candidates(diff),
        }

    top_regressions = _normalize_diff_entries(diff.get("top_regressions"))
    top_reductions = _normalize_diff_entries(diff.get("top_reductions"))
    regressions_count = sum(1 for item in top_regressions if _as_float(item.get("delta", 0)) > 0)
    reductions_count = sum(1 for item in top_reductions if _as_float(item.get("delta", 0)) < 0)

    combined: list[dict[str, object]] = []
    for item in top_regressions + top_reductions:
        delta = _as_float(item.get("delta", 0))
        if delta == 0:
            continue
        combined.append({
            "kind": str(item.get("kind", "")),
            "name": str(item.get("name", "")),
            "delta": int(delta),
        })
    combined.sort(key=lambda entry: -abs(int(entry["delta"])))

    spark_max = max((abs(int(entry["delta"])) for entry in combined[:10]), default=1) or 1
    spark_entries: list[dict[str, object]] = []
    for entry in combined[:10]:
        delta_val = int(entry["delta"])
        ratio = min(1.0, abs(delta_val) / float(spark_max))
        spark_entries.append({
            "kind": entry["kind"],
            "name": entry["name"],
            "delta": delta_val,
            "delta_label": _format_signed_compact(delta_val),
            "ratio_pct": round(ratio * 100.0, 2),
            "direction": "up" if delta_val > 0 else "down",
        })

    region_capacity_by_name: dict[str, int] = {}
    for region in regions:
        name = str(region.get("name", ""))
        if name:
            region_capacity_by_name[name] = int(_as_float(region.get("total_bytes", 0)))

    section_region_map = dict(section_to_region or {})
    region_delta_bytes: dict[str, int] = {}
    all_sections = _normalize_diff_entries(diff.get("sections"))
    if not all_sections:
        all_sections = [
            item for item in (top_regressions + top_reductions)
            if str(item.get("kind", "")) == "section"
        ]
    for item in all_sections:
        if str(item.get("kind", "")) not in {"section", ""}:
            continue
        section_name = str(item.get("name", ""))
        if not section_name:
            continue
        region_name = section_region_map.get(section_name)
        if not region_name:
            continue
        delta_val = int(_as_float(item.get("delta", 0)))
        if delta_val == 0:
            continue
        region_delta_bytes[region_name] = region_delta_bytes.get(region_name, 0) + delta_val

    region_deltas: list[dict[str, object]] = []
    region_max = max((abs(v) for v in region_delta_bytes.values()), default=1) or 1
    for name, delta_val in sorted(
        region_delta_bytes.items(),
        key=lambda pair: -abs(pair[1]),
    ):
        if delta_val == 0:
            continue
        capacity = region_capacity_by_name.get(name, 0)
        pct_capacity: float | None = None
        if capacity > 0:
            pct_capacity = round((float(delta_val) / float(capacity)) * 100.0, 2)
        region_deltas.append({
            "name": name,
            "delta": delta_val,
            "delta_label": _format_signed_compact(delta_val),
            "current": 0,
            "baseline": 0,
            "direction": "up" if delta_val > 0 else "down",
            "ratio_pct": round((abs(delta_val) / float(region_max)) * 100.0, 2),
            "pct_of_capacity": pct_capacity,
            "severity": (
                "danger" if delta_val >= 4096
                else "warning" if delta_val >= 256
                else "ok" if delta_val < 0
                else "info"
            ),
        })

    drivers: dict[str, list[dict[str, object]]] = {
        "components": _driver_group(diff.get("components"), limit=6),
        "sections": _driver_group(diff.get("sections"), limit=6),
        "symbols": _driver_group(diff.get("symbols"), limit=6),
        "objects": [],
    }

    return {
        "status": status,
        "has_data": bool(combined) or bool(region_deltas),
        "baseline_path": str(diff.get("baseline_path") or ""),
        "net_delta_bytes": int(sum(entry["delta"] for entry in combined)),
        "net_delta_label": _format_signed_compact(int(sum(entry["delta"] for entry in combined))),
        "regression_count": regressions_count,
        "reduction_count": reductions_count,
        "flash_delta_bytes": int(_as_float(diff.get("flash_delta_bytes", 0))),
        "ram_delta_bytes": int(_as_float(diff.get("ram_delta_bytes", 0))),
        "flash_delta_label": _format_signed_compact(int(_as_float(diff.get("flash_delta_bytes", 0)))),
        "ram_delta_label": _format_signed_compact(int(_as_float(diff.get("ram_delta_bytes", 0)))),
        "spark_entries": spark_entries,
        "region_deltas": region_deltas,
        "drivers": drivers,
        "baseline_candidates": _detect_baseline_candidates(diff),
    }


def _driver_group(raw: object, *, limit: int = 6) -> list[dict[str, object]]:
    entries = _normalize_diff_entries(raw)
    scored: list[tuple[int, dict[str, object]]] = []
    for item in entries:
        delta_val = int(_as_float(item.get("delta", 0)))
        if delta_val == 0:
            continue
        scored.append((abs(delta_val), {
            "name": str(item.get("name", "")),
            "delta": delta_val,
            "delta_label": _format_signed_compact(delta_val),
            "direction": "up" if delta_val > 0 else "down",
            "status": str(item.get("status", "changed")),
        }))
    scored.sort(key=lambda pair: -pair[0])
    top = [entry for _, entry in scored[:limit]]
    if not top:
        return []
    cap = top[0]["delta"]
    cap_abs = abs(int(cap)) if cap else 1
    if cap_abs <= 0:
        cap_abs = 1
    for entry in top:
        entry["ratio_pct"] = round((abs(int(entry["delta"])) / float(cap_abs)) * 100.0, 2)
    return top


def _detect_baseline_candidates(diff: dict[str, object]) -> list[dict[str, object]]:
    import datetime as _dt
    import os
    candidates: list[dict[str, object]] = []
    active_path = str(diff.get("baseline_path") or "")
    seen: set[str] = set()
    try:
        cwd = Path(os.getcwd())
    except OSError:
        return candidates
    hits: list[Path] = []
    for pattern in ("baseline*.json", "*baseline.json", "memscope*.json"):
        try:
            hits.extend(cwd.glob(pattern))
        except OSError:
            continue
    for path in sorted(set(hits)):
        try:
            key = str(path.resolve())
        except OSError:
            key = str(path)
        if key in seen:
            continue
        seen.add(key)
        try:
            stat = path.stat()
            size_bytes = int(stat.st_size)
            mtime = _dt.datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M")
        except OSError:
            size_bytes = 0
            mtime = ""
        candidates.append({
            "path": str(path),
            "name": path.name,
            "size_bytes": size_bytes,
            "size_label": f"{size_bytes:,} B" if size_bytes else "",
            "modified": mtime,
            "is_active": bool(active_path) and key == str(Path(active_path).resolve()) if active_path else False,
        })
    candidates.sort(key=lambda item: (not bool(item.get("is_active")), str(item.get("name", ""))))
    return candidates[:8]


def _build_diff_chart_entries(diff: dict[str, object]) -> list[dict[str, object]]:
    entries: list[dict[str, object]] = []

    for item in _normalize_diff_entries(diff.get("top_regressions"))[:6]:
        delta = _as_float(item.get("delta", 0))
        if delta <= 0:
            continue
        entries.append(
            {
                "label": f"{item.get('kind', 'unknown')}:{item.get('name', 'unknown')}",
                "delta": delta,
            }
        )

    for item in _normalize_diff_entries(diff.get("top_reductions"))[:6]:
        delta = _as_float(item.get("delta", 0))
        if delta >= 0:
            continue
        entries.append(
            {
                "label": f"{item.get('kind', 'unknown')}:{item.get('name', 'unknown')}",
                "delta": delta,
            }
        )

    return sorted(entries, key=lambda item: abs(_as_float(item.get("delta", 0))), reverse=True)[:10]


def _format_signed_compact(value: int) -> str:
    sign = "+" if value > 0 else ""
    return f"{sign}{value:,}"


def _build_insights(
    *,
    issues: list[dict[str, Any]],
    regions: list[dict[str, object]],
    diff: dict[str, object],
    summary: dict[str, object],
    sorted_report: AnalysisReport,
) -> dict[str, object]:
    severity_rank = {"error": 0, "warning": 1, "info": 2}
    severity_class = {"error": "danger", "warning": "warning", "info": "info"}
    sorted_issues = sorted(
        issues,
        key=lambda item: (
            severity_rank.get(str(item.get("severity", "info")), 3),
            str(item.get("category", "")),
            str(item.get("title", "")),
        ),
    )
    top_risk: dict[str, object] | None = None
    if sorted_issues:
        top = sorted_issues[0]
        sev = str(top.get("severity", "info"))
        top_risk = {
            "severity": sev.upper(),
            "severity_class": severity_class.get(sev, "info"),
            "title": str(top.get("title", "Issue")),
            "hint": str(top.get("description", "")) or f"Category: {top.get('category', 'general')}",
            "match_text": str(top.get("title", ""))[:48],
        }

    biggest_grower: dict[str, object] | None = None
    diff_status = str(diff.get("status", "not_requested"))
    top_regressions = diff.get("top_regressions") or []
    if diff_status not in {"not_requested", "missing_baseline"} and isinstance(top_regressions, list) and top_regressions:
        first = top_regressions[0]
        if isinstance(first, dict):
            delta = _as_float(first.get("delta", 0))
            kind = str(first.get("kind", "entity"))
            name = str(first.get("name", "unknown"))
            sev_class = "danger" if delta >= 4096 else "warning" if delta >= 256 else "info"
            biggest_grower = {
                "name": f"{kind}:{name}",
                "delta_bytes": int(delta),
                "delta_label": _format_signed_compact(int(delta)),
                "severity_class": sev_class,
                "hint": "Single largest growth driver vs supplied baseline.",
            }

    tightest_headroom: dict[str, object] | None = None
    candidates = [r for r in regions if int(r.get("total_bytes", 0)) > 0]
    if candidates:
        worst = max(candidates, key=lambda r: float(r.get("percent", 0.0)))
        percent = float(worst.get("percent", 0.0))
        sev_class = "danger" if percent >= 100.0 else "warning" if percent >= 85.0 else "ok"
        free_bytes = int(worst.get("free_bytes", 0))
        total_bytes = int(worst.get("total_bytes", 0))
        tightest_headroom = {
            "region": str(worst.get("name", "")),
            "percent": round(percent, 1),
            "severity_class": sev_class,
            "free_bytes": free_bytes,
            "free_label": f"{free_bytes:,}",
            "total_label": f"{total_bytes:,}",
        }

    padding_waste: dict[str, object] | None = None
    extra = getattr(sorted_report.summary, "extra", {}) or {}
    pad_block = extra.get("padding_waste") if isinstance(extra, dict) else None
    if isinstance(pad_block, dict):
        total_padding = int(pad_block.get("total_padding_bytes", 0) or 0)
        by_region = pad_block.get("by_region") or {}
        if total_padding > 0:
            top_region = ""
            top_region_bytes = 0
            if isinstance(by_region, dict):
                for region_name, region_bytes in by_region.items():
                    try:
                        rb = int(region_bytes)
                    except (TypeError, ValueError):
                        rb = 0
                    if rb > top_region_bytes:
                        top_region_bytes = rb
                        top_region = str(region_name)
            sev_class = "warning" if total_padding >= 4096 else "info"
            padding_waste = {
                "total_bytes": total_padding,
                "total_label": f"{total_padding:,}",
                "region": top_region,
                "severity_class": sev_class,
                "hint": (
                    f"Worst region: {top_region} ({top_region_bytes:,} B)"
                    if top_region
                    else "Padding bytes detected across one or more regions."
                ),
                "jump_hash": "#region-utilization",
                "cta": "Inspect regions",
            }

    return {
        "top_risk": top_risk,
        "biggest_grower": biggest_grower,
        "tightest_headroom": tightest_headroom,
        "padding_waste": padding_waste,
        "diff_status": diff_status,
    }


def _palette_entry(
    *,
    kind: str,
    label: str,
    hash_target: str,
    hint: str = "",
    region: str = "",
    component: str = "",
    search_input_id: str = "",
    search_value: str = "",
    extra_search: str = "",
) -> dict[str, object]:
    search_text = " ".join(part for part in (label, hint, region, component, extra_search) if part)
    return {
        "kind": kind,
        "label": label,
        "hash": hash_target,
        "hint": hint,
        "region": region,
        "component": component,
        "searchInputId": search_input_id,
        "searchValue": search_value,
        "searchText": search_text,
    }


def _build_palette_index(
    *,
    regions: list[dict[str, object]],
    components: list[dict[str, object]],
    sections: list[dict[str, object]],
    top_globals: list[dict[str, Any]],
    top_functions: list[dict[str, Any]],
    top_symbols: list[dict[str, Any]],
    issues: list[dict[str, Any]],
) -> list[dict[str, object]]:
    index: list[dict[str, object]] = []
    nav_targets = (
        ("Memory Layout", "#memory-layout"),
        ("Visual Insights", "#visual-insights"),
        ("Region Utilization", "#region-utilization"),
        ("Top Contributors", "#top-contributors"),
        ("Top Global Variables", "#top-global-variables"),
        ("Top Functions", "#top-functions"),
        ("Section Explorer", "#section-explorer"),
        ("Component Ownership", "#component-ownership"),
        ("Issues", "#issues"),
        ("Comparison vs Baseline", "#comparison-baseline"),
        ("Diagnostics", "#diagnostics"),
    )
    for label, hash_target in nav_targets:
        index.append(_palette_entry(kind="jump", label=label, hash_target=hash_target, hint="Jump to section"))

    for region in regions:
        name = str(region.get("name", ""))
        if not name:
            continue
        percent = region.get("percent", 0)
        try:
            percent_label = f"{float(percent):.1f}%"
        except (TypeError, ValueError):
            percent_label = ""
        index.append(
            _palette_entry(
                kind="region",
                label=name,
                hash_target="#region-utilization",
                hint=percent_label,
                region=name,
            )
        )

    for component in components:
        name = str(component.get("name", ""))
        if not name:
            continue
        index.append(
            _palette_entry(
                kind="component",
                label=name,
                hash_target="#component-ownership",
                hint=f"{int(component.get('total_ram', 0)):,} B RAM",
                component=name,
            )
        )

    for symbol in top_symbols[:80]:
        name = str(symbol.get("name", ""))
        if not name:
            continue
        size_val = _as_float(symbol.get("size", 0))
        index.append(
            _palette_entry(
                kind="symbol",
                label=name,
                hash_target="#top-contributors",
                hint=f"{int(size_val):,} B",
            )
        )

    for entry in top_globals[:60]:
        name = str(entry.get("name", ""))
        if not name:
            continue
        index.append(
            _palette_entry(
                kind="global",
                label=name,
                hash_target="#top-global-variables",
                hint=f"{int(_as_float(entry.get('size', 0))):,} B",
                region=str(entry.get("region", "")) if str(entry.get("region", "")) != "-" else "",
            )
        )

    for entry in top_functions[:60]:
        name = str(entry.get("name", ""))
        if not name:
            continue
        index.append(
            _palette_entry(
                kind="function",
                label=name,
                hash_target="#top-functions",
                hint=f"{int(_as_float(entry.get('size', 0))):,} B",
                region=str(entry.get("region", "")) if str(entry.get("region", "")) != "-" else "",
            )
        )

    for section in sections[:120]:
        name = str(section.get("name", ""))
        if not name:
            continue
        size_val = int(_as_float(section.get("size", 0)))
        region_name = str(section.get("execution_region") or section.get("load_region") or "")
        index.append(
            _palette_entry(
                kind="section",
                label=name,
                hash_target="#section-explorer",
                hint=f"{size_val:,} B" + (f" - {region_name}" if region_name else ""),
                search_input_id="section-filter-text",
                search_value=name,
            )
        )

    for issue in issues[:40]:
        title = str(issue.get("title", ""))
        if not title:
            continue
        sev = str(issue.get("severity", ""))
        index.append(
            _palette_entry(
                kind=("issue:" + sev) if sev else "issue",
                label=title,
                hash_target="#issues",
                hint=str(issue.get("category", "")),
                search_input_id="issue-filter-text",
                search_value=title[:48],
                extra_search=str(issue.get("description", "")),
            )
        )
    return index


def _build_address_index(visualization_data: dict[str, Any]) -> list[dict[str, object]]:
    index: list[dict[str, object]] = []
    regions_payload = visualization_data.get("regions") if isinstance(visualization_data, dict) else None
    if not isinstance(regions_payload, list):
        return index
    for region in regions_payload:
        if not isinstance(region, dict):
            continue
        region_name = str(region.get("name", ""))
        region_start = region.get("start_address")
        region_end = region.get("end_address")
        if isinstance(region_start, int) and isinstance(region_end, int) and region_end >= region_start:
            index.append(
                {
                    "start": region_start,
                    "end": region_end,
                    "region": region_name,
                    "kind": "region",
                    "section": "",
                    "symbol": "",
                }
            )
        ranges = region.get("ranges")
        if not isinstance(ranges, list):
            continue
        for rng in ranges:
            if not isinstance(rng, dict):
                continue
            start = rng.get("start_address")
            end = rng.get("end_address")
            if not isinstance(start, int) or not isinstance(end, int) or end < start:
                continue
            index.append(
                {
                    "start": start,
                    "end": end,
                    "region": region_name,
                    "kind": str(rng.get("kind", "")),
                    "section": str(rng.get("section_name") or ""),
                    "symbol": str(rng.get("symbol_name") or ""),
                }
            )
    return index
