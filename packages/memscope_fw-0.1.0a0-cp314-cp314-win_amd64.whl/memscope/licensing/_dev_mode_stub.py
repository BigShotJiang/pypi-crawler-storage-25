"""No-op developer-mode bridge — the only implementation in production wheels.

The production wheel ships this module and **omits** `_dev_mode_real.py`
entirely (excluded by the hatchling build hook). The dispatcher in
`dev_mode.py` loads this stub when the real module is absent.

`override_status()` is hardcoded to return `None` — there is no flag,
no branch, and no field that flipping could enable. Patching this stub
to return a real bypass requires re-introducing the entire
`_dev_mode_real` module by hand, not flipping a single value.

See `docs/RELEASE_DISTRIBUTION_PLAN.md` Phase B for the full design.
"""

from __future__ import annotations

from dataclasses import dataclass

from memscope.licensing.models import LicenseStatus


@dataclass(slots=True, frozen=True)
class DeveloperModeLicenseBridge:
    """Stub bridge — never grants the developer-mode override."""

    enabled: bool = False

    def override_status(self) -> LicenseStatus | None:
        return None
