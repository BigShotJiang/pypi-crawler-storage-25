"""MemScope licensing layer."""

from memscope.licensing.cache import ActivationCache, LicenseCacheTamperedError
from memscope.licensing.dev_mode import DeveloperModeLicenseBridge
from memscope.licensing.eula import EULA_HASH, EULA_TEXT, EulaState, EulaStore
from memscope.licensing.keygen_provider import KeygenLicenseProvider
from memscope.licensing.machine_fingerprint import MachineFingerprintProvider
from memscope.licensing.models import LicenseDecision, LicenseState, LicenseStatus, LicenseTier
from memscope.licensing.provider import (
    ActivationResult,
    DemoLicenseProvider,
    EnterpriseLicenseProvider,
    InvalidLicenseKeyError,
    LicenseProvider,
    LicenseProviderError,
    ProviderConnectionError,
    RoutedLicenseProvider,
    ValidationResult,
)
from memscope.licensing.service import (
    LicenseActivationError,
    LicenseEnforcementError,
    LicenseService,
    LicenseServiceError,
    build_default_license_service,
)

__all__ = [
    "ActivationCache",
    "ActivationResult",
    "DemoLicenseProvider",
    "EULA_HASH",
    "EULA_TEXT",
    "EnterpriseLicenseProvider",
    "EulaState",
    "EulaStore",
    "DeveloperModeLicenseBridge",
    "InvalidLicenseKeyError",
    "KeygenLicenseProvider",
    "LicenseCacheTamperedError",
    "LicenseActivationError",
    "LicenseDecision",
    "LicenseEnforcementError",
    "LicenseProvider",
    "LicenseProviderError",
    "LicenseService",
    "LicenseServiceError",
    "LicenseState",
    "LicenseStatus",
    "LicenseTier",
    "MachineFingerprintProvider",
    "ProviderConnectionError",
    "RoutedLicenseProvider",
    "ValidationResult",
    "build_default_license_service",
]
