"""License command group scaffold."""

from __future__ import annotations

from collections.abc import Callable
from typing import Annotated

import typer

from memscope.app.session import CommandResult, SessionManager

GetSessionManager = Callable[[typer.Context], SessionManager]
RunWithErrorHandling = Callable[[SessionManager, Callable[[SessionManager], CommandResult]], None]


def register_group(
    app: typer.Typer,
    get_session_manager: GetSessionManager,
    run_with_error_handling: RunWithErrorHandling,
) -> None:
    license_app = typer.Typer(help="License management commands.", no_args_is_help=True)

    @license_app.command("activate")
    def license_activate(
        ctx: typer.Context,
        key: Annotated[
            str,
            typer.Argument(
                help=(
                    "License key to activate "
                    "(e.g. ABCD12-EF34GH-IJKL56-MN78OP-QR90ST-UV; "
                    "matches the format Keygen issues)."
                ),
            ),
        ],
    ) -> None:
        run_with_error_handling(get_session_manager(ctx), lambda session: session.license_activate(key))

    @license_app.command("status")
    def license_status(ctx: typer.Context) -> None:
        run_with_error_handling(get_session_manager(ctx), lambda session: session.license_status())

    @license_app.command("deactivate")
    def license_deactivate(ctx: typer.Context) -> None:
        run_with_error_handling(get_session_manager(ctx), lambda session: session.license_deactivate())

    @license_app.command(
        "accept-terms",
        help="Record acceptance of the MemScope End-User License Agreement.",
    )
    def license_accept_terms(ctx: typer.Context) -> None:
        run_with_error_handling(
            get_session_manager(ctx),
            lambda session: session.license_accept_terms(),
        )

    app.add_typer(license_app, name="license")
