"""Centralized logging setup for MemScope CLI runs."""

from __future__ import annotations

import logging
import sys

TRACE_LEVEL = 5
_TRACE_NAME = "TRACE"
_configured = False


def _install_trace_level() -> None:
    if logging.getLevelName(TRACE_LEVEL) != _TRACE_NAME:
        logging.addLevelName(TRACE_LEVEL, _TRACE_NAME)

    if not hasattr(logging.Logger, "trace"):
        def trace(self: logging.Logger, message: str, *args: object) -> None:
            if self.isEnabledFor(TRACE_LEVEL):
                self.log(TRACE_LEVEL, message, *args)

        logging.Logger.trace = trace  # type: ignore[attr-defined]


def configure_logging(*, level: str, developer_mode: bool) -> None:
    """Configure a deterministic logger tree for memscope.* modules."""
    global _configured
    _install_trace_level()

    normalized_level = level.strip().lower()
    if normalized_level == "trace" and not developer_mode:
        raise ValueError("trace log level requires --developer-mode")

    level_by_name = {
        "error": logging.ERROR,
        "warning": logging.WARNING,
        "info": logging.INFO,
        "debug": logging.DEBUG,
        "trace": TRACE_LEVEL,
    }
    log_level = level_by_name[normalized_level]

    logger = logging.getLogger("memscope")
    logger.handlers.clear()
    logger.propagate = False
    logger.setLevel(log_level)

    handler = logging.StreamHandler(stream=sys.stderr)
    handler.setLevel(log_level)
    handler.setFormatter(
        logging.Formatter(
            fmt="%(asctime)s %(levelname)s [%(name)s] %(message)s",
            datefmt="%H:%M:%S",
        )
    )
    logger.addHandler(handler)
    _configured = True


def get_logger(name: str) -> logging.Logger:
    _install_trace_level()
    logger_name = name if name.startswith("memscope.") else f"memscope.{name}"
    logger = logging.getLogger(logger_name)
    if not _configured:
        root = logging.getLogger("memscope")
        if not root.handlers:
            root.addHandler(logging.NullHandler())
    return logger
