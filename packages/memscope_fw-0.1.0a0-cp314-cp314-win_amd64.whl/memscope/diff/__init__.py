"""Build-over-build diff engine."""

from memscope.diff.engine import (
    compare_report_files,
    compare_report_payloads,
    compare_with_baseline_file,
    load_report_payload,
)
from memscope.diff.model import DiffEntry, DiffReport

__all__ = [
    "DiffEntry",
    "DiffReport",
    "compare_report_files",
    "compare_report_payloads",
    "compare_with_baseline_file",
    "load_report_payload",
]

