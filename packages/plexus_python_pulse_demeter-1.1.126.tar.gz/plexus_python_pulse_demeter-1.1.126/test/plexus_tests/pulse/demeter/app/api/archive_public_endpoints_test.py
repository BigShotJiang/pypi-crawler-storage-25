import datetime
import hashlib

import pytest_postgresql.factories
from fastapi.testclient import TestClient
from plexus.common.utils.dtutils import dt_format, dt_parse_iso, extended_format
from plexus.pulse.common.utils.testutils import case_insensitive_json_compare
from plexus.pulse.common.utils.testutils import generate_dummy_uuid_str, generate_dummy_vin_code
from plexus.pulse.common.utils.testutils import patched_postgresql_session_maker, patched_value_factory

from plexus.pulse.demeter.app.api import current_dt_clock
from plexus.pulse.demeter.app.api.archive_internal_endpoints import router as internal_router
from plexus.pulse.demeter.app.api.archive_public_endpoints import router as public_router
from plexus.pulse.demeter.app.core.database import make_session
from plexus.pulse.demeter.app.main import app
from plexus.pulse.demeter.app.models.registry import RegistryBase

fixture_postgresql_test_proc = pytest_postgresql.factories.postgresql_proc(host="localhost", user="postgres")
fixture_postgresql_test = pytest_postgresql.factories.postgresql("fixture_postgresql_test_proc", dbname="pulse")
fixture_session_maker = patched_postgresql_session_maker("fixture_postgresql_test",
                                                         RegistryBase,
                                                         app,
                                                         make_session,
                                                         expire_on_commit=False)
fixture_current_dt_clock = patched_value_factory(app, current_dt_clock)

client = TestClient(app)


def test_create_or_update_vehicle(fixture_session_maker, fixture_current_dt_clock):
    request_data = {
        "vin_code": generate_dummy_vin_code(),
        "asset_id": "2020-veh-00001",
        "vehicle_template_uuid": generate_dummy_uuid_str(1),
        "name": "dummy_vehicle",
        "purchase_date": "2020-01-01",
        "tags": ["truck:manufacturer:dummy", "truck:series:dummy"],
        "props": {"dummy": "dummy"},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "vin_code": generate_dummy_vin_code(),
        "asset_id": "2020-veh-00001",
        "vehicle_template_uuid": generate_dummy_uuid_str(1),
        "name": "dummy_vehicle",
        "purchase_date": "2020-01-01",
        "tags": ["truck:manufacturer:dummy", "truck:series:dummy"],
        "props": {"dummy": "dummy"},
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{public_router.prefix}/create_or_update_vehicle/",
                               json=request_data)
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    request_data = {
        "vin_code": generate_dummy_vin_code(),
        "asset_id": "2020-veh-00001",
        "vehicle_template_uuid": generate_dummy_uuid_str(1),
        "name": "dummy_vehicle",
        "purchase_date": "2020-02-01",
        "tags": ["truck:manufacturer:another_dummy", "truck:series:another_dummy"],
        "props": {"dummy": "dummy", "another": "another"},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "vin_code": generate_dummy_vin_code(),
        "asset_id": "2020-veh-00001",
        "vehicle_template_uuid": generate_dummy_uuid_str(1),
        "name": "dummy_vehicle",
        "purchase_date": "2020-02-01",
        "tags": ["truck:manufacturer:another_dummy", "truck:series:another_dummy"],
        "props": {"dummy": "dummy", "another": "another"},
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
        response = client.post(f"{public_router.prefix}/create_or_update_vehicle/",
                               json=request_data)
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_or_update_sensor(fixture_session_maker, fixture_current_dt_clock):
    request_data = {
        "uuid": generate_dummy_uuid_str(3),
        "asset_id": "2020-sen-00001",
        "sensor_template_uuid": generate_dummy_uuid_str(2),
        "serial_number": "SN-DUMMY-0001",
        "purchase_date": "2020-01-01",
        "tags": ["sensor:manufacturer:dummy", "sensor:series:dummy"],
        "props": {"dummy": "dummy"},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(3),
        "asset_id": "2020-sen-00001",
        "sensor_template_uuid": generate_dummy_uuid_str(2),
        "serial_number": "SN-DUMMY-0001",
        "purchase_date": "2020-01-01",
        "tags": ["sensor:manufacturer:dummy", "sensor:series:dummy"],
        "props": {"dummy": "dummy"},
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{public_router.prefix}/create_or_update_sensor/",
                               json=request_data)
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    request_data = {
        "uuid": generate_dummy_uuid_str(3),
        "asset_id": "2020-sen-00001",
        "sensor_template_uuid": generate_dummy_uuid_str(2),
        "serial_number": "SN-DUMMY-0001",
        "purchase_date": "2020-02-01",
        "tags": ["sensor:manufacturer:another_dummy", "sensor:series:another_dummy"],
        "props": {"dummy": "dummy", "another": "another"},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(3),
        "asset_id": "2020-sen-00001",
        "sensor_template_uuid": generate_dummy_uuid_str(2),
        "serial_number": "SN-DUMMY-0001",
        "purchase_date": "2020-02-01",
        "tags": ["sensor:manufacturer:another_dummy", "sensor:series:another_dummy"],
        "props": {"dummy": "dummy", "another": "another"},
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
        response = client.post(f"{public_router.prefix}/create_or_update_sensor/",
                               json=request_data)
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_create_or_update_bag(fixture_session_maker, fixture_current_dt_clock):
    request_data = {
        "name": "20200101T000000-dummy_vehicle-0.bag",
        "path": "pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-0.bag",
        "vehicle_vin_code": generate_dummy_vin_code(),
        "vehicle_name": "dummy_vehicle",
        "begin_at": "2020-01-01T00:00:00.000000+00:00",
        "end_at": "2020-01-01T12:00:00.000000+00:00",
        "file_size": 1073741824,
        "file_checksum": hashlib.sha256("20200101T000000-dummy_vehicle-0.bag".encode()).hexdigest(),
        "tags": ["mission:name:nation_cover_2020"],
        "props": {"dummy": "dummy"},
    }

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "name": "20200101T000000-dummy_vehicle-0.bag",
        "path": "pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-0.bag",
        "vehicle_vin_code": generate_dummy_vin_code(),
        "vehicle_name": "dummy_vehicle",
        "begin_at": "2020-01-01T00:00:00.000000+00:00",
        "end_at": "2020-01-01T12:00:00.000000+00:00",
        "file_size": 1073741824,
        "file_checksum": hashlib.sha256("20200101T000000-dummy_vehicle-0.bag".encode()).hexdigest(),
        "flags": 0,
        "tags": ["mission:name:nation_cover_2020"],
        "props": {"dummy": "dummy"},
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{public_router.prefix}/create_or_update_bag/",
                               json=request_data)
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    request_data = {
        "name": "20200101T000000-dummy_vehicle-0.bag",
        "path": "pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-0.bag",
        "vehicle_vin_code": generate_dummy_vin_code(),
        "vehicle_name": "dummy_vehicle",
        "begin_at": "2020-02-01T00:00:00.000000+00:00",
        "end_at": "2020-02-01T12:00:00.000000+00:00",
        "file_size": 2147483648,
        "file_checksum": hashlib.sha256("20200101T000000-dummy_vehicle-0.bag".encode()).hexdigest(),
        "flags": 1,
        "tags": ["mission:name:nation_cover_2020", "project:name:lte"],
        "props": {"dummy": "dummy", "another": "another"},
    }

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-02-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "name": "20200101T000000-dummy_vehicle-0.bag",
        "path": "pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-0.bag",
        "vehicle_vin_code": generate_dummy_vin_code(),
        "vehicle_name": "dummy_vehicle",
        "begin_at": "2020-02-01T00:00:00.000000+00:00",
        "end_at": "2020-02-01T12:00:00.000000+00:00",
        "file_size": 2147483648,
        "file_checksum": hashlib.sha256("20200101T000000-dummy_vehicle-0.bag".encode()).hexdigest(),
        "flags": 1,
        "tags": ["mission:name:nation_cover_2020", "project:name:lte"],
        "props": {"dummy": "dummy", "another": "another"},
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
        response = client.post(f"{public_router.prefix}/create_or_update_bag/",
                               json=request_data)
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_query_vehicles(fixture_session_maker):
    request_data = [
        {
            "vin_code": generate_dummy_vin_code(0),
            "asset_id": "2020-veh-00001",
            "vehicle_template_uuid": generate_dummy_uuid_str(1),
            "name": "dummy_vehicle",
            "purchase_date": "2020-01-01",
            "tags": ["truck:manufacturer:dummy", "truck:series:dummy"],
            "props": {"dummy": "dummy", "expired": True},
        },
        {
            "vin_code": generate_dummy_vin_code(1),
            "asset_id": "2020-veh-00002",
            "vehicle_template_uuid": generate_dummy_uuid_str(1),
            "name": "another_dummy_vehicle",
            "purchase_date": "2020-01-02",
            "tags": ["truck:manufacturer:another_dummy", "truck:series:another_dummy"],
            "props": {"dummy": "dummy", "another": "another", "expired": True},
        },
    ]

    response = client.post(f"{internal_router.prefix}/vehicles/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    request_data = {
        "vin_code": generate_dummy_vin_code(0),
        "asset_id": "2020-veh-00001",
        "vehicle_template_uuid": generate_dummy_uuid_str(1),
        "name": "dummy_vehicle",
        "purchase_date": "2020-02-01",
        "tags": ["truck:manufacturer:dummy", "truck:series:dummy"],
        "props": {"dummy": "dummy", "expired": False},
    }

    response = client.put(f"{internal_router.prefix}/vehicle/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    request_data = {
        "vin_code": generate_dummy_vin_code(1),
        "asset_id": "2020-veh-00002",
        "vehicle_template_uuid": generate_dummy_uuid_str(1),
        "name": "another_dummy_vehicle",
        "purchase_date": "2020-02-02",
        "tags": ["truck:manufacturer:another_dummy", "truck:series:another_dummy"],
        "props": {"dummy": "dummy", "another": "another", "expired": False},
    }

    response = client.put(f"{internal_router.prefix}/vehicle/2",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_expect = {
        "vehicles": [
            {
                "sqn": 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": "2020-02-01T00:00:00.000000+00:00",
                "record_sqn": 1,
                "revision": 1,
                "vin_code": generate_dummy_vin_code(),
                "asset_id": "2020-veh-00001",
                "vehicle_template_uuid": generate_dummy_uuid_str(1),
                "name": "dummy_vehicle",
                "purchase_date": "2020-01-01",
                "tags": ["truck:manufacturer:dummy", "truck:series:dummy"],
                "props": {"dummy": "dummy", "expired": True},
            },
            {
                "sqn": 2,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": "2020-02-01T00:00:00.000000+00:00",
                "record_sqn": 2,
                "revision": 1,
                "vin_code": generate_dummy_vin_code(1),
                "asset_id": "2020-veh-00002",
                "vehicle_template_uuid": generate_dummy_uuid_str(1),
                "name": "another_dummy_vehicle",
                "purchase_date": "2020-01-02",
                "tags": ["truck:manufacturer:another_dummy", "truck:series:another_dummy"],
                "props": {"dummy": "dummy", "another": "another", "expired": True},
            },
        ],
        "pagination": {
            "skip": 0,
            "limit": 100,
            "total": 2,
        },
    }

    response = client.get(f"{public_router.prefix}/query_vehicles/",
                          params={"effective_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response_expect = {
        "vehicles": [
            {
                "sqn": 3,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": 1,
                "revision": 2,
                "vin_code": generate_dummy_vin_code(0),
                "asset_id": "2020-veh-00001",
                "vehicle_template_uuid": generate_dummy_uuid_str(1),
                "name": "dummy_vehicle",
                "purchase_date": "2020-02-01",
                "tags": ["truck:manufacturer:dummy", "truck:series:dummy"],
                "props": {"dummy": "dummy", "expired": False},
            },
            {
                "sqn": 4,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": 2,
                "revision": 2,
                "vin_code": generate_dummy_vin_code(1),
                "asset_id": "2020-veh-00002",
                "vehicle_template_uuid": generate_dummy_uuid_str(1),
                "name": "another_dummy_vehicle",
                "purchase_date": "2020-02-02",
                "tags": ["truck:manufacturer:another_dummy", "truck:series:another_dummy"],
                "props": {"dummy": "dummy", "another": "another", "expired": False},
            },
        ],
        "pagination": {
            "skip": 0,
            "limit": 100,
            "total": 2,
        },
    }

    response = client.get(f"{public_router.prefix}/query_vehicles/",
                          params={"effective_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_query_sensors(fixture_session_maker):
    request_data = [
        {
            "uuid": generate_dummy_uuid_str(3, 0),
            "asset_id": "2020-sen-00001",
            "sensor_template_uuid": generate_dummy_uuid_str(2),
            "serial_number": "SN-DUMMY-0001",
            "purchase_date": "2020-01-01",
            "tags": ["sensor:manufacturer:dummy", "sensor:series:dummy"],
            "props": {"dummy": "dummy", "expired": True},
        },
        {
            "uuid": generate_dummy_uuid_str(3, 1),
            "asset_id": "2020-sen-00002",
            "sensor_template_uuid": generate_dummy_uuid_str(2),
            "serial_number": "SN-DUMMY-0002",
            "purchase_date": "2020-01-02",
            "tags": ["sensor:manufacturer:another_dummy", "sensor:series:another_dummy"],
            "props": {"dummy": "dummy", "another": "another", "expired": True},
        },
    ]

    response = client.post(f"{internal_router.prefix}/sensors/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    request_data = {
        "uuid": generate_dummy_uuid_str(3, 0),
        "asset_id": "2020-sen-00001",
        "sensor_template_uuid": generate_dummy_uuid_str(2),
        "serial_number": "SN-DUMMY-0001",
        "purchase_date": "2020-02-01",
        "tags": ["sensor:manufacturer:dummy", "sensor:series:dummy"],
        "props": {"dummy": "dummy", "expired": False},
    }

    response = client.put(f"{internal_router.prefix}/sensor/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    request_data = {
        "uuid": generate_dummy_uuid_str(3, 1),
        "asset_id": "2020-sen-00002",
        "sensor_template_uuid": generate_dummy_uuid_str(2),
        "serial_number": "SN-DUMMY-0002",
        "purchase_date": "2020-02-02",
        "tags": ["sensor:manufacturer:another_dummy", "sensor:series:another_dummy"],
        "props": {"dummy": "dummy", "another": "another", "expired": False},
    }

    response = client.put(f"{internal_router.prefix}/sensor/2",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_expect = {
        "sensors": [
            {
                "sqn": 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": "2020-02-01T00:00:00.000000+00:00",
                "record_sqn": 1,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(3, 0),
                "asset_id": "2020-sen-00001",
                "sensor_template_uuid": generate_dummy_uuid_str(2),
                "serial_number": "SN-DUMMY-0001",
                "purchase_date": "2020-01-01",
                "tags": ["sensor:manufacturer:dummy", "sensor:series:dummy"],
                "props": {"dummy": "dummy", "expired": True},
            },
            {
                "sqn": 2,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": "2020-02-01T00:00:00.000000+00:00",
                "record_sqn": 2,
                "revision": 1,
                "uuid": generate_dummy_uuid_str(3, 1),
                "asset_id": "2020-sen-00002",
                "sensor_template_uuid": generate_dummy_uuid_str(2),
                "serial_number": "SN-DUMMY-0002",
                "purchase_date": "2020-01-02",
                "tags": ["sensor:manufacturer:another_dummy", "sensor:series:another_dummy"],
                "props": {"dummy": "dummy", "another": "another", "expired": True},
            },
        ],
        "pagination": {
            "skip": 0,
            "limit": 100,
            "total": 2,
        },
    }

    response = client.get(f"{public_router.prefix}/query_sensors/",
                          params={"effective_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response_expect = {
        "sensors": [
            {
                "sqn": 3,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": 1,
                "revision": 2,
                "uuid": generate_dummy_uuid_str(3, 0),
                "asset_id": "2020-sen-00001",
                "sensor_template_uuid": generate_dummy_uuid_str(2),
                "serial_number": "SN-DUMMY-0001",
                "purchase_date": "2020-02-01",
                "tags": ["sensor:manufacturer:dummy", "sensor:series:dummy"],
                "props": {"dummy": "dummy", "expired": False},
            },
            {
                "sqn": 4,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": 2,
                "revision": 2,
                "uuid": generate_dummy_uuid_str(3, 1),
                "asset_id": "2020-sen-00002",
                "sensor_template_uuid": generate_dummy_uuid_str(2),
                "serial_number": "SN-DUMMY-0002",
                "purchase_date": "2020-02-02",
                "tags": ["sensor:manufacturer:another_dummy", "sensor:series:another_dummy"],
                "props": {"dummy": "dummy", "another": "another", "expired": False},
            },
        ],
        "pagination": {
            "skip": 0,
            "limit": 100,
            "total": 2,
        },
    }

    response = client.get(f"{public_router.prefix}/query_sensors/",
                          params={"effective_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_retrieve_vehicles(fixture_session_maker):
    vehicles_count = 100

    request_data = [
        {
            "vin_code": generate_dummy_vin_code(i),
            "asset_id": f"2020-veh-{i:05d}",
            "vehicle_template_uuid": generate_dummy_uuid_str(1),
            "name": f"dummy_vehicle_{i}",
            "purchase_date": "2020-01-01",
            "tags": ["truck:manufacturer:dummy", f"truck:series:dummy_{i}"],
            "props": {"dummy": "dummy"},
        }
        for i in range(vehicles_count)
    ]

    response = client.post(f"{internal_router.prefix}/vehicles/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    def make_response_bag(i: int):
        return {
            "sqn": i + 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": i + 1,
            "revision": 1,
            "vin_code": generate_dummy_vin_code(i),
            "asset_id": f"2020-veh-{i:05d}",
            "vehicle_template_uuid": generate_dummy_uuid_str(1),
            "name": f"dummy_vehicle_{i}",
            "purchase_date": "2020-01-01",
            "tags": ["truck:manufacturer:dummy", f"truck:series:dummy_{i}"],
            "props": {"dummy": "dummy"},
        }

    response_expect = {
        "vehicles": [make_response_bag(i) for i in range(vehicles_count)],
        "pagination": {"skip": 0, "limit": 200, "total": vehicles_count},
    }

    response = client.get(f"{public_router.prefix}/retrieve_vehicles/",
                          params={"limit": 200})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_retrieve_sensors(fixture_session_maker):
    sensors_count = 100

    request_data = [
        {
            "uuid": generate_dummy_uuid_str(3, i),
            "asset_id": f"2020-sen-{i:05d}",
            "sensor_template_uuid": generate_dummy_uuid_str(2),
            "serial_number": f"SN-DUMMY-{i:04d}",
            "purchase_date": "2020-01-01",
            "tags": ["sensor:manufacturer:dummy", f"sensor:series:dummy_{i}"],
            "props": {"dummy": "dummy"},
        }
        for i in range(sensors_count)
    ]

    response = client.post(f"{internal_router.prefix}/sensors/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    def make_response_bag(i: int):
        return {
            "sqn": i + 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": i + 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(3, i),
            "asset_id": f"2020-sen-{i:05d}",
            "sensor_template_uuid": generate_dummy_uuid_str(2),
            "serial_number": f"SN-DUMMY-{i:04d}",
            "purchase_date": "2020-01-01",
            "tags": ["sensor:manufacturer:dummy", f"sensor:series:dummy_{i}"],
            "props": {"dummy": "dummy"},
        }

    response_expect = {
        "sensors": [make_response_bag(i) for i in range(sensors_count)],
        "pagination": {"skip": 0, "limit": sensors_count, "total": sensors_count},
    }

    response = client.get(f"{public_router.prefix}/retrieve_sensors/",
                          params={"limit": sensors_count})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_query_bags(fixture_session_maker):
    request_data = [
        {
            "name": f"20200101T000000-dummy_vehicle-0.bag",
            "path": f"pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-0.bag",
            "vehicle_vin_code": generate_dummy_vin_code(),
            "vehicle_name": "dummy_vehicle",
            "begin_at": "2020-01-01T00:00:00.000000+00:00",
            "end_at": "2020-01-01T12:00:00.000000+00:00",
            "file_size": 1073741824,
            "file_checksum": hashlib.sha256(f"20200101T000000-dummy_vehicle-0.bag".encode()).hexdigest(),
            "tags": ["mission:name:nation_cover_2020"],
            "props": {"dummy": "dummy", "expired": True},
        },
        {
            "name": f"20200101T000000-another_dummy_vehicle-0.bag",
            "path": f"pulse/demeter/storage/20200101/20200101T000000-another_dummy_vehicle-0.bag",
            "vehicle_vin_code": generate_dummy_vin_code(1),
            "vehicle_name": "another_dummy_vehicle",
            "begin_at": "2020-01-01T00:00:00.000000+00:00",
            "end_at": "2020-01-01T12:00:00.000000+00:00",
            "file_size": 2147483648,
            "file_checksum": hashlib.sha256(f"20200101T000000-another_dummy_vehicle-0.bag".encode()).hexdigest(),
            "tags": ["mission:name:nation_cover_2020", "project:name:lte"],
            "props": {"dummy": "dummy", "another": "another", "expired": True},
        },
    ]

    response = client.post(f"{internal_router.prefix}/bags/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    request_data = {
        "name": f"20200101T000000-dummy_vehicle-0.bag",
        "path": f"pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-0.bag",
        "vehicle_vin_code": generate_dummy_vin_code(),
        "vehicle_name": "dummy_vehicle",
        "begin_at": "2020-02-01T00:00:00.000000+00:00",
        "end_at": "2020-02-01T12:00:00.000000+00:00",
        "file_size": 1073741824,
        "file_checksum": hashlib.sha256(f"20200101T000000-dummy_vehicle-0.bag".encode()).hexdigest(),
        "tags": ["mission:name:nation_cover_2020"],
        "props": {"dummy": "dummy", "expired": False},
    }

    response = client.put(f"{internal_router.prefix}/bag/1",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    request_data = {
        "name": f"20200101T000000-another_dummy_vehicle-0.bag",
        "path": f"pulse/demeter/storage/20200101/20200101T000000-another_dummy_vehicle-0.bag",
        "vehicle_vin_code": generate_dummy_vin_code(1),
        "vehicle_name": "another_dummy_vehicle",
        "begin_at": "2020-02-01T00:00:00.000000+00:00",
        "end_at": "2020-02-01T12:00:00.000000+00:00",
        "file_size": 2147483648,
        "file_checksum": hashlib.sha256(f"20200101T000000-another_dummy_vehicle-0.bag".encode()).hexdigest(),
        "tags": ["mission:name:nation_cover_2020", "project:name:lte"],
        "props": {"dummy": "dummy", "another": "another", "expired": False},
    }

    response = client.put(f"{internal_router.prefix}/bag/2",
                          json=request_data,
                          params={"updated_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_expect = {
        "bags": [
            {
                "sqn": 1,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": "2020-02-01T00:00:00.000000+00:00",
                "record_sqn": 1,
                "revision": 1,
                "name": f"20200101T000000-dummy_vehicle-0.bag",
                "path": f"pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-0.bag",
                "vehicle_vin_code": generate_dummy_vin_code(),
                "vehicle_name": "dummy_vehicle",
                "begin_at": "2020-01-01T00:00:00.000000+00:00",
                "end_at": "2020-01-01T12:00:00.000000+00:00",
                "file_size": 1073741824,
                "file_checksum": hashlib.sha256(f"20200101T000000-dummy_vehicle-0.bag".encode()).hexdigest(),
                "flags": 0,
                "tags": ["mission:name:nation_cover_2020"],
                "props": {"dummy": "dummy", "expired": True},
            },
            {
                "sqn": 2,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-01-01T00:00:00.000000+00:00",
                "expired_at": "2020-02-01T00:00:00.000000+00:00",
                "record_sqn": 2,
                "revision": 1,
                "name": f"20200101T000000-another_dummy_vehicle-0.bag",
                "path": f"pulse/demeter/storage/20200101/20200101T000000-another_dummy_vehicle-0.bag",
                "vehicle_vin_code": generate_dummy_vin_code(1),
                "vehicle_name": "another_dummy_vehicle",
                "begin_at": "2020-01-01T00:00:00.000000+00:00",
                "end_at": "2020-01-01T12:00:00.000000+00:00",
                "file_size": 2147483648,
                "file_checksum": hashlib.sha256(f"20200101T000000-another_dummy_vehicle-0.bag".encode()).hexdigest(),
                "flags": 0,
                "tags": ["mission:name:nation_cover_2020", "project:name:lte"],
                "props": {"dummy": "dummy", "another": "another", "expired": True},
            },
        ],
        "pagination": {
            "skip": 0,
            "limit": 100,
            "total": 2,
        },
    }

    response = client.get(f"{public_router.prefix}/query_bags/",
                          params={"effective_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response_expect = {
        "bags": [
            {
                "sqn": 3,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": 1,
                "revision": 2,
                "name": f"20200101T000000-dummy_vehicle-0.bag",
                "path": f"pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-0.bag",
                "vehicle_vin_code": generate_dummy_vin_code(),
                "vehicle_name": "dummy_vehicle",
                "begin_at": "2020-02-01T00:00:00.000000+00:00",
                "end_at": "2020-02-01T12:00:00.000000+00:00",
                "file_size": 1073741824,
                "file_checksum": hashlib.sha256(f"20200101T000000-dummy_vehicle-0.bag".encode()).hexdigest(),
                "flags": 0,
                "tags": ["mission:name:nation_cover_2020"],
                "props": {"dummy": "dummy", "expired": False},
            },
            {
                "sqn": 4,
                "created_at": "2020-01-01T00:00:00.000000+00:00",
                "updated_at": "2020-02-01T00:00:00.000000+00:00",
                "expired_at": None,
                "record_sqn": 2,
                "revision": 2,
                "name": f"20200101T000000-another_dummy_vehicle-0.bag",
                "path": f"pulse/demeter/storage/20200101/20200101T000000-another_dummy_vehicle-0.bag",
                "vehicle_vin_code": generate_dummy_vin_code(1),
                "vehicle_name": "another_dummy_vehicle",
                "begin_at": "2020-02-01T00:00:00.000000+00:00",
                "end_at": "2020-02-01T12:00:00.000000+00:00",
                "file_size": 2147483648,
                "file_checksum": hashlib.sha256(f"20200101T000000-another_dummy_vehicle-0.bag".encode()).hexdigest(),
                "flags": 0,
                "tags": ["mission:name:nation_cover_2020", "project:name:lte"],
                "props": {"dummy": "dummy", "another": "another", "expired": False},
            },
        ],
        "pagination": {
            "skip": 0,
            "limit": 100,
            "total": 2,
        },
    }

    response = client.get(f"{public_router.prefix}/query_bags/",
                          params={"effective_at": "2020-02-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_query_bag(fixture_session_maker):
    request_data = [
        {
            "name": f"20200101T000000-dummy_vehicle-0.bag",
            "path": f"pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-0.bag",
            "vehicle_vin_code": generate_dummy_vin_code(),
            "vehicle_name": "dummy_vehicle",
            "begin_at": "2020-01-01T00:00:00.000000+00:00",
            "end_at": "2020-01-01T12:00:00.000000+00:00",
            "file_size": 1073741824,
            "file_checksum": hashlib.sha256(f"20200101T000000-dummy_vehicle-0.bag".encode()).hexdigest(),
            "tags": ["mission:name:nation_cover_2020"],
            "props": {"dummy": "dummy"},
        },
        {
            "name": f"20200101T000000-another_dummy_vehicle-0.bag",
            "path": f"pulse/demeter/storage/20200101/20200101T000000-another_dummy_vehicle-0.bag",
            "vehicle_vin_code": generate_dummy_vin_code(1),
            "vehicle_name": "another_dummy_vehicle",
            "begin_at": "2020-01-01T00:00:00.000000+00:00",
            "end_at": "2020-01-01T12:00:00.000000+00:00",
            "file_size": 2147483648,
            "file_checksum": hashlib.sha256(f"20200101T000000-another_dummy_vehicle-0.bag".encode()).hexdigest(),
            "tags": ["mission:name:nation_cover_2020", "project:name:lte"],
            "props": {"dummy": "dummy", "another": "another"},
        },
    ]

    response = client.post(f"{internal_router.prefix}/bags/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "name": f"20200101T000000-dummy_vehicle-0.bag",
        "path": f"pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-0.bag",
        "vehicle_vin_code": generate_dummy_vin_code(),
        "vehicle_name": "dummy_vehicle",
        "begin_at": "2020-01-01T00:00:00.000000+00:00",
        "end_at": "2020-01-01T12:00:00.000000+00:00",
        "file_size": 1073741824,
        "file_checksum": hashlib.sha256(f"20200101T000000-dummy_vehicle-0.bag".encode()).hexdigest(),
        "flags": 0,
        "tags": ["mission:name:nation_cover_2020"],
        "props": {"dummy": "dummy"},
    }

    response = client.get(f"{public_router.prefix}/query_bag/",
                          params={"name": "20200101T000000-dummy_vehicle-0.bag"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 2,
        "revision": 1,
        "name": f"20200101T000000-another_dummy_vehicle-0.bag",
        "path": f"pulse/demeter/storage/20200101/20200101T000000-another_dummy_vehicle-0.bag",
        "vehicle_vin_code": generate_dummy_vin_code(1),
        "vehicle_name": "another_dummy_vehicle",
        "begin_at": "2020-01-01T00:00:00.000000+00:00",
        "end_at": "2020-01-01T12:00:00.000000+00:00",
        "file_size": 2147483648,
        "file_checksum": hashlib.sha256(f"20200101T000000-another_dummy_vehicle-0.bag".encode()).hexdigest(),
        "flags": 0,
        "tags": ["mission:name:nation_cover_2020", "project:name:lte"],
        "props": {"dummy": "dummy", "another": "another"},
    }

    response = client.get(f"{public_router.prefix}/query_bag/",
                          params={"name": "20200101T000000-another_dummy_vehicle-0.bag"})
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_retrieve_bags(fixture_session_maker):
    bags_count = 366  # Mocks the bags for each day in a leap year

    request_data = [
        {
            "name": f"20200101T000000-dummy_vehicle-{i}.bag" if i % 2 == 0 else f"20200101T000000-another_dummy_vehicle-{i}.bag",
            "path": f"pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-{i}.bag" if i % 2 == 0 else f"pulse/demeter/storage/20200101/20200101T000000-another_dummy_vehicle-{i}.bag",
            "vehicle_vin_code": generate_dummy_vin_code() if i % 2 == 0 else generate_dummy_vin_code(1),
            "vehicle_name": "dummy_vehicle" if i % 2 == 0 else "another_dummy_vehicle",
            "begin_at": dt_format(
                dt_parse_iso("2020-01-01T00:00:00.000000+00:00") + datetime.timedelta(days=i),
                extended_format(with_us=True, with_tz=True)),
            "end_at": dt_format(
                dt_parse_iso("2020-01-01T00:00:00.000000+00:00") + datetime.timedelta(days=i, hours=12),
                extended_format(with_us=True, with_tz=True)),
            "file_size": 1073741824,
            "file_checksum": (
                hashlib.sha256(f"20200101T000000-dummy_vehicle-{i}.bag".encode()).hexdigest() if i % 2 == 0 else
                hashlib.sha256(f"20200101T000000-another_dummy_vehicle-{i}.bag".encode()).hexdigest()
            ),
            "tags": ["mission:name:nation_cover_2020"],
            "props": {"dummy": "dummy"},
        }
        for i in range(bags_count)
    ]

    response = client.post(f"{internal_router.prefix}/bags/",
                           json=request_data,
                           params={"created_at": "2020-01-01T00:00:00.000000+00:00"})
    assert response.status_code == 200, response.text

    def make_response_bag(i: int):
        return {
            "sqn": i + 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": i + 1,
            "revision": 1,
            "name": f"20200101T000000-dummy_vehicle-{i}.bag" if i % 2 == 0 else f"20200101T000000-another_dummy_vehicle-{i}.bag",
            "path": f"pulse/demeter/storage/20200101/20200101T000000-dummy_vehicle-{i}.bag" if i % 2 == 0 else f"pulse/demeter/storage/20200101/20200101T000000-another_dummy_vehicle-{i}.bag",
            "vehicle_vin_code": generate_dummy_vin_code() if i % 2 == 0 else generate_dummy_vin_code(1),
            "vehicle_name": "dummy_vehicle" if i % 2 == 0 else "another_dummy_vehicle",
            "begin_at": dt_format(
                dt_parse_iso("2020-01-01T00:00:00.000000+00:00") + datetime.timedelta(days=i),
                extended_format(with_us=True, with_tz=True)),
            "end_at": dt_format(
                dt_parse_iso("2020-01-01T00:00:00.000000+00:00") + datetime.timedelta(days=i, hours=12),
                extended_format(with_us=True, with_tz=True)),
            "file_size": 1073741824,
            "file_checksum": (
                hashlib.sha256(f"20200101T000000-dummy_vehicle-{i}.bag".encode()).hexdigest() if i % 2 == 0 else
                hashlib.sha256(f"20200101T000000-another_dummy_vehicle-{i}.bag".encode()).hexdigest()
            ),
            "flags": 0,
            "tags": ["mission:name:nation_cover_2020"],
            "props": {"dummy": "dummy"},
        }

    response_expect = {
        "bags": [make_response_bag(i) for i in range(bags_count)],
        "pagination": {"skip": 0, "limit": 500, "total": bags_count},
    }

    response = client.get(f"{public_router.prefix}/retrieve_bags/",
                          params=[
                              ("begin_at", "2020-01-01T00:00:00.000000+00:00"),
                              ("limit", 500),
                          ])
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{public_router.prefix}/retrieve_bags/",
                          params=[
                              ("end_at", "2021-01-01T00:00:00.000000+00:00"),
                              ("limit", 500),
                          ])
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{public_router.prefix}/retrieve_bags/",
                          params=[
                              ("begin_at", "2020-01-01T00:00:00.000000+00:00"),
                              ("end_at", "2021-01-01T00:00:00.000000+00:00"),
                              ("limit", 500),
                          ])
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response_expect = {
        "bags": [make_response_bag(i) for i in range(31, bags_count - 31)],
        # Bags from 2020-02-01 to 2020-11-30, 304 days
        "pagination": {"skip": 0, "limit": 500, "total": bags_count - 62},
    }

    response = client.get(f"{public_router.prefix}/retrieve_bags",
                          params=[
                              ("begin_at", "2020-02-01T00:00:00.000000+00:00"),
                              ("end_at", "2020-12-01T00:00:00.000000+00:00"),
                              ("limit", 500),
                          ])
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{public_router.prefix}/retrieve_bags/",
                          params=[
                              ("begin_at", "2020-02-01T00:00:00.000000+00:00"),
                              ("end_at", "2020-12-01T00:00:00.000000+00:00"),
                              ("vehicle_names", "dummy_vehicle"),
                              ("vehicle_names", "another_dummy_vehicle"),
                              ("limit", 500),
                          ])
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{public_router.prefix}/retrieve_bags/",
                          params=[
                              ("begin_at", "2020-02-01T00:00:00.000000+00:00"),
                              ("end_at", "2020-12-01T00:00:00.000000+00:00"),
                              ("name_match", "dummy_vehicle"),
                              ("limit", 500),
                          ])
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response_expect = {
        "bags": [make_response_bag(i) for i in range(31, bags_count - 31, 2)],
        # Bags from 2020-02-01 to 2020-11-30 for another_dummy_vehicle only, 152 days
        "pagination": {"skip": 0, "limit": 500, "total": (bags_count - 62) // 2},
    }

    response = client.get(f"{public_router.prefix}/retrieve_bags/",
                          params=[
                              ("begin_at", "2020-02-01T00:00:00.000000+00:00"),
                              ("end_at", "2020-12-01T00:00:00.000000+00:00"),
                              ("vehicle_names", "another_dummy_vehicle"),
                              ("limit", 500),
                          ])
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response = client.get(f"{public_router.prefix}/retrieve_bags/",
                          params=[
                              ("begin_at", "2020-02-01T00:00:00.000000+00:00"),
                              ("end_at", "2020-12-01T00:00:00.000000+00:00"),
                              ("name_match", "another_dummy_vehicle"),
                              ("limit", 500),
                          ])
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)
