import json
import unittest

import cloudpathlib
import ddt
import jsonschema
import moto
from plexus.common.utils.dtutils import dt_parse_iso
from plexus.pulse.common.utils.s3utils import s3_make_client, s3_sync_upload
from plexus.pulse.common.utils.testutils import generate_dummy_uuid, generate_dummy_uuid_str

from plexus.pulse.demeter.app.models.local import StandaloneDataset, StandaloneSample
from plexus.pulse.demeter.app.models.registry.dataset import ClassifierTaxonomy, SampleLayout
from plexus.pulse.demeter.utils.datautils import collect_standalone_dataset_samples, validate_standalone_sample
from testenv import resources_directory

layouts: list[SampleLayout] = [
    SampleLayout(
        uuid=generate_dummy_uuid(1, 1),
        name="dummy_layout/sequence",
        description="",
        child_layout_uuids=[generate_dummy_uuid(1, 1, 1)],
        layout_spec={
            "layout": {
                "type": "directory",
                "children": [
                    {
                        "matcher": {"type": "regex", "pattern": r"^\d{8}T\d{6}\.\d{6}$", "min_items": 1},
                        "layout": {
                            "type": "uuid",
                            "value": generate_dummy_uuid_str(1, 1, 1),
                        },
                    },
                ],
                "allow_extra": False,
            },
        },
        props={},
    ),
    SampleLayout(
        uuid=generate_dummy_uuid(1, 1, 1),
        name="dummy_layout/frame",
        description="",
        child_layout_uuids=[],
        layout_spec={
            "layout": {
                "type": "directory",
                "children": [
                    {
                        "matcher": {"type": "exact", "pattern": "front_left_camera.png", "min_items": 1},
                        "layout": {"type": "file"},
                    },
                    {
                        "matcher": {"type": "exact", "pattern": "front_right_camera.png", "min_items": 1},
                        "layout": {"type": "file"},
                    },
                    {
                        "matcher": {"type": "exact", "pattern": "side_left_camera.png", "min_items": 1},
                        "layout": {"type": "file"},
                    },
                    {
                        "matcher": {"type": "exact", "pattern": "side_right_camera.png", "min_items": 1},
                        "layout": {"type": "file"},
                    },
                    {
                        "matcher": {"type": "exact", "pattern": "rear_left_camera.png", "min_items": 1},
                        "layout": {"type": "file"},
                    },
                    {
                        "matcher": {"type": "exact", "pattern": "rear_right_camera.png", "min_items": 1},
                        "layout": {"type": "file"},
                    },
                    {
                        "matcher": {"type": "exact", "pattern": "lidar_points.pcd"},
                        "layout": {"type": "file"},
                    }
                ],
                "allow_extra": False,
            },
        },
        props={},
    ),
    SampleLayout(
        uuid=generate_dummy_uuid(1, 2),
        name="dummy_layout/sequence/intermixed",
        description="",
        child_layout_uuids=[],
        layout_spec={
            "layout": {
                "type": "directory",
                "children": [
                    {
                        "matcher": {"type": "regex", "pattern": r"^\d{8}T\d{6}\.\d{6}$", "min_items": 1},
                        "layout": {
                            "type": "directory",
                            "children": [
                                {
                                    "matcher": {"type": "exact", "pattern": "front_left_camera.png", "min_items": 1},
                                    "layout": {"type": "file"},
                                },
                                {
                                    "matcher": {"type": "exact", "pattern": "front_right_camera.png", "min_items": 1},
                                    "layout": {"type": "file"},
                                },
                                {
                                    "matcher": {"type": "exact", "pattern": "side_left_camera.png", "min_items": 1},
                                    "layout": {"type": "file"},
                                },
                                {
                                    "matcher": {"type": "exact", "pattern": "side_right_camera.png", "min_items": 1},
                                    "layout": {"type": "file"},
                                },
                                {
                                    "matcher": {"type": "exact", "pattern": "rear_left_camera.png", "min_items": 1},
                                    "layout": {"type": "file"},
                                },
                                {
                                    "matcher": {"type": "exact", "pattern": "rear_right_camera.png", "min_items": 1},
                                    "layout": {"type": "file"},
                                },
                                {
                                    "matcher": {"type": "exact", "pattern": "lidar_points.pcd"},
                                    "layout": {"type": "file"},
                                }
                            ],
                            "allow_extra": False,
                        }
                    },
                ],
                "allow_extra": False,
            },
        },
        props={},
    ),
]

taxonomies: list[ClassifierTaxonomy] = [
    ClassifierTaxonomy(
        uuid=generate_dummy_uuid(2, 1),
        name="dummy_taxonomy/scene_classifier",
        version="1.0.0",
        description="",
        taxonomy_hierarchy={
            "name": "scene_classifier_taxonomy",
            "version": "1.0.0",
            "classifiers": [
                {
                    "tag": "environment",
                    "description": "Environmental conditions impacting scene visibility and dynamics",
                    "children": [
                        {
                            "tag": "tod",
                            "description": "Time of day affecting ambient light levels",
                            "values": [
                                {"value": "dawn",
                                 "description": "Sun is below horizon but ambient light is increasing"},
                                {"value": "daytime", "description": "Sun is above horizon; full daylight"},
                                {"value": "dusk",
                                 "description": "Sun is below horizon but ambient light is decreasing"},
                                {"value": "nighttime", "description": "Sun is well below horizon; low ambient light"},
                                {"value": "unknown", "description": "Time of day cannot be determined"},
                            ],
                            "exclusive": True,
                        },
                        {
                            "tag": "weather",
                            "description": "Overall weather condition affecting visibility and scene dynamics",
                            "values": [
                                {"value": "clear",
                                 "description": "No significant weather effects present"},
                                {"value": "cloudy",
                                 "description": "Overcast or mostly cloudy skies without precipitation"},
                                {"value": "foggy",
                                 "description": "Reduced visibility due to fog or mist"},
                                {"value": "rainy",
                                 "description": "Active rainfall affecting visibility and road conditions"},
                                {"value": "snowy",
                                 "description": "Active snowfall affecting visibility and road conditions"},
                                {"value": "unknown",
                                 "description": "Weather condition cannot be determined"}
                            ],
                            "exclusive": True,
                        },
                        {
                            "tag": "visibility",
                            "description": "Scene visibility expressed as bucket or numeric distance",
                            "values": [
                                {"value": "very_high",
                                 "description": "Visibility distance exceeds typical sensor range"},
                                {"value": "high",
                                 "description": "Visibility distance is good; minimal obstructions"},
                                {"value": "moderate",
                                 "description": "Visibility distance is reduced; some obstructions present"},
                                {"value": "low",
                                 "description": "Visibility distance is poor; significant obstructions present"},
                                {"value": "very_low",
                                 "description": "Visibility distance is extremely limited"},
                                {"value": "unknown",
                                 "description": "Visibility distance cannot be determined"},
                            ],
                            "exclusive": True,
                        },
                        {
                            "tag": "obstructions",
                            "description": "Presence of visual obstructions in the scene",
                            "values": [
                                {"value": "fog", "description": "Fog or mist reducing visibility"},
                                {"value": "smoke", "description": "Smoke or haze reducing visibility"},
                                {"value": "dust", "description": "Dust or sand reducing visibility"},
                                {"value": "snowfall", "description": "Active snowfall reducing visibility"},
                                {"value": "rainfall", "description": "Active rainfall reducing visibility"},
                                {"value": "unknown", "description": "Obstruction presence cannot be determined"},
                            ],
                            "exclusive": False,
                        },
                        {
                            "tag": "lighting",
                            "description": "Lighting conditions affecting visibility",
                            "values": [
                                {"value": "normal",
                                 "description": "Standard lighting conditions without significant issues"},
                                {"value": "low_light",
                                 "description": "Reduced lighting conditions affecting visibility"},
                                {"value": "glare",
                                 "description": "Presence of glare affecting visibility"},
                                {"value": "shadows",
                                 "description": "Significant shadows affecting visibility"},
                                {"value": "unknown",
                                 "description": "Lighting conditions cannot be determined"},
                            ],
                            "exclusive": False,
                        },
                        {
                            "tag": "surface",
                            "description": "Road surface condition affecting traction and handling",
                            "values": [
                                {"value": "dry",
                                 "description": "Road surface is dry and provides normal traction"},
                                {"value": "wet",
                                 "description": "Road surface is wet, reducing traction"},
                                {"value": "standing_water",
                                 "description": "Presence of standing water on the road surface"},
                                {"value": "icy",
                                 "description": "Road surface is icy, significantly reducing traction"},
                                {"value": "snow_covered",
                                 "description": "Road surface is covered with snow"},
                                {"value": "gravel",
                                 "description": "Road surface is gravel, affecting traction"},
                                {"value": "muddy",
                                 "description": "Road surface is muddy, affecting traction"},
                                {"value": "contaminated",
                                 "description": "Road surface is contaminated with substances affecting traction"},
                                {"value": "unknown",
                                 "description": "Road surface condition cannot be determined"}
                            ],
                            "exclusive": True,
                        }
                    ]
                },
                {
                    "tag": "roadway",
                    "description": "Roadway characteristics and infrastructure present in the scene",
                    "children": [
                        {
                            "tag": "classification",
                            "description": "High-level classification of roadway segment",
                            "values": [
                                {"value": "expressway",
                                 "description": "Limited access, high-speed roadway (e.g., freeway, motorway)"},
                                {"value": "highway",
                                 "description": "Major road connecting cities and regions"},
                                {"value": "arterial",
                                 "description": "Primary urban road for moderate to high traffic volumes"},
                                {"value": "collector",
                                 "description": "Road collecting traffic from local streets to arterial roads"},
                                {"value": "residential",
                                 "description": "Local road primarily serving residential areas"},
                                {"value": "rural",
                                 "description": "Road in a rural or undeveloped area"},
                                {"value": "unpaved",
                                 "description": "Non-paved road surface (e.g., dirt, gravel)"},
                                {"value": "service_road",
                                 "description": "Road providing access to properties or facilities"},
                                {"value": "parking_lot",
                                 "description": "Area designated for vehicle parking"},
                                {"value": "unknown",
                                 "description": "Road classification cannot be determined"},
                            ],
                            "exclusive": True,
                        },
                        {
                            "tag": "layout",
                            "description": "General layout of the roadway segment",
                            "values": [
                                {"value": "single_way",
                                 "description": "One-way roadway with traffic flowing in a single direction"},
                                {"value": "undivided_two_way",
                                 "description": "Two-way roadway without physical separation between directions"},
                                {"value": "divided_two_way",
                                 "description": "Two-way roadway with physical separation (e.g., median) between directions"},
                                {"value": "unknown",
                                 "description": "Roadway layout cannot be determined"},
                            ],
                            "exclusive": True,
                        },
                        {
                            "tag": "lane_config",
                            "description": "Number of lanes in the roadway segment",
                            "values": [
                                {"value": "single_lane", "description": "Road segment has a single lane"},
                                {"value": "two_lane", "description": "Road segment has two lanes"},
                                {"value": "multi_lane", "description": "Road segment has more than two lanes"},
                                {"value": "unknown", "description": "Lane configuration cannot be determined"},
                            ],
                            "exclusive": True,
                        },
                        {
                            "tag": "shoulder",
                            "description": "Types of shoulders or side areas present along the road segment",
                            "values": [
                                {"value": "none", "description": "No shoulder or side area present"},
                                {"value": "median", "description": "Median or central reservation present"},
                                {"value": "verge", "description": "Grassy or unpaved verge area present"},
                                {"value": "sidewalk", "description": "Sidewalk or pedestrian path present"},
                                {"value": "emergency_lane", "description": "Emergency lane or breakdown lane present"},
                                {"value": "unknown", "description": "Shoulder type cannot be determined"},
                            ],
                            "exclusive": False,
                        },
                        {
                            "tag": "junction",
                            "description": "Geometry of intersection or junction for special handling",
                            "values": [
                                {"value": "cross",
                                 "description": "Four-way intersection with two roads crossing each other"},
                                {"value": "tee_left_right",
                                 "description": "T-shaped intersection with three arms; can turn left or right"},
                                {"value": "tee_left_only",
                                 "description": "T-shaped intersection with three arms; can only turn left"},
                                {"value": "tee_right_only",
                                 "description": "T-shaped intersection with three arms; can only turn right"},
                                {"value": "y_intersection",
                                 "description": "Three-way intersection forming a Y shape"},
                                {"value": "roundabout",
                                 "description": "Circular intersection where traffic flows around a central island"},
                                {"value": "merge",
                                 "description": "Point where two roadways combine into one"},
                                {"value": "split",
                                 "description": "Point where one roadway divides into two or more"},
                                {"value": "other",
                                 "description": "Other intersection geometry not covered by above categories"},
                                {"value": "unknown",
                                 "description": "Intersection geometry cannot be determined"},
                            ],
                            "exclusive": True,
                        },
                        {
                            "tag": "infrastructure",
                            "description": "Types of infrastructure present in the scene",
                            "values": [
                                {"value": "tunnel",
                                 "description": "Road segment is within a tunnel structure"},
                                {"value": "bridge",
                                 "description": "Road segment is on a bridge structure"},
                                {"value": "underpass",
                                 "description": "Structure allowing one road to pass under another"},
                                {"value": "unknown",
                                 "description": "Infrastructure presence cannot be determined"}
                            ],
                            "exclusive": False,
                        },
                        {
                            "tag": "geometry",
                            "description": "Geometric characteristics of the road segment",
                            "values": [
                                {"value": "curved", "description": "Road segment has a significant horizontal curve"},
                                {"value": "incline", "description": "Road segment has a significant upward slope"},
                                {"value": "decline", "description": "Road segment has a significant downward slope"},
                                {"value": "hillcrest", "description": "Road segment is at the top of a hill"},
                                {"value": "sag", "description": "Road segment is at the bottom of a dip or valley"},
                            ],
                            "exclusive": False,
                        }
                    ]
                },
                {
                    "tag": "traffic",
                    "description": "Dynamic elements and events affecting scene complexity and behavior",
                    "children": [
                        {
                            "tag": "density",
                            "description": "Overall vehicle density estimate",
                            "values": [
                                {"value": "absent", "description": "No vehicles present in the scene"},
                                {"value": "sparse", "description": "Few vehicles present; low density"},
                                {"value": "light", "description": "Some vehicles present; light density"},
                                {"value": "moderate", "description": "Moderate number of vehicles present"},
                                {"value": "dense", "description": "High number of vehicles present; dense traffic"},
                                {"value": "jammed", "description": "Very high vehicle density; traffic jam conditions"},
                                {"value": "unknown", "description": "Vehicle density cannot be determined"},
                            ],
                            "exclusive": True,
                        },
                        {
                            "tag": "pedestrian_presence",
                            "description": "Pedestrian density estimate",
                            "values": [
                                {"value": "absent", "description": "No pedestrians present in the scene"},
                                {"value": "sparse", "description": "Few pedestrians present; low density"},
                                {"value": "moderate", "description": "Moderate number of pedestrians present"},
                                {"value": "dense", "description": "High number of pedestrians present; dense crowd"},
                                {"value": "unknown", "description": "Pedestrian density cannot be determined"},
                            ],
                            "exclusive": True,
                        },
                        {
                            "tag": "cyclist_presence",
                            "description": "Cyclist/bicycle density estimate",
                            "values": [
                                {"value": "absent",
                                 "description": "No cyclists/bicycles present in the scene"},
                                {"value": "sparse",
                                 "description": "Few cyclists/bicycles present; low density"},
                                {"value": "moderate",
                                 "description": "Moderate number of cyclists/bicycles present"},
                                {"value": "dense",
                                 "description": "High number of cyclists/bicycles present; dense crowd"},
                                {"value": "unknown",
                                 "description": "Cyclist/bicycle density cannot be determined"},
                            ],
                            "exclusive": True,
                        },
                        {
                            "tag": "construction_zone",
                            "description": "Temporary construction/work zone indicator",
                            "values": [
                                {"value": "absent",
                                 "description": "No construction or work zone present"},
                                {"value": "minor",
                                 "description": "Minor construction or work zone present; minimal impact"},
                                {"value": "major",
                                 "description": "Major construction or work zone present; significant impact"},
                                {"value": "unknown",
                                 "description": "Construction zone presence cannot be determined"}
                            ],
                            "exclusive": True,
                        },
                        {
                            "tag": "accident",
                            "description": "Significant events happening during the scenario",
                            "values": [
                                {"value": "road_block",
                                 "description": "Roadway is blocked due to an accident or obstruction"},
                                {"value": "debris_on_road",
                                 "description": "Debris or obstacles present on the roadway"},
                                {"value": "animal_on_road",
                                 "description": "Animal(s) present on the roadway"},
                                {"value": "pedestrian_on_road",
                                 "description": "Pedestrian(s) present on the roadway"},
                                {"value": "vehicle_breakdown",
                                 "description": "Vehicle(s) present that have broken down"},
                                {"value": "emergency_vehicle_present",
                                 "description": "Emergency vehicle(s) present in the scene"},
                                {"value": "police_stop",
                                 "description": "Police stop or traffic control event occurring"},
                                {"value": "other",
                                 "description": "Other significant event not covered by above categories"},
                            ],
                            "exclusive": False,
                        }
                    ]
                },
                {
                    "tag": "data_fidelity",
                    "description": "Quality and noise conditions affecting sensor data fidelity",
                    "children": [
                        {
                            "tag": "camera_issue",
                            "description": "Camera-specific sensor quality issues",
                            "values": [
                                {"value": "glare",
                                 "description": "Excessive brightness or glare affecting image quality"},
                                {"value": "motion_blur",
                                 "description": "Blur caused by rapid movement of the camera or scene"},
                                {"value": "lens_smear",
                                 "description": "Obstruction on the camera lens affecting image clarity"},
                                {"value": "occlusion",
                                 "description": "Objects blocking the camera's field of view"},
                                {"value": "underexposure",
                                 "description": "Image is too dark due to insufficient exposure"},
                                {"value": "overexposure",
                                 "description": "Image is too bright due to excessive exposure"},
                            ],
                            "exclusive": False,
                        },
                        {
                            "tag": "radar_issue",
                            "description": "Radar-specific quality/noise conditions",
                            "values": [
                                {"value": "weather_effects",
                                 "description": "Adverse weather conditions affecting radar performance (e.g., rain, snow)"},
                                {"value": "interference",
                                 "description": "General electromagnetic interference affecting radar performance"},
                                {"value": "multipath",
                                 "description": "Reflected signals causing ghost targets or inaccuracies"},
                                {"value": "clutter",
                                 "description": "Unwanted echoes from non-target objects affecting radar returns"},
                            ],
                            "exclusive": False,
                        },
                        {
                            "tag": "lidar_issue",
                            "description": "Lidar-specific quality/noise conditions",
                            "values": [
                                {"value": "weather_effects",
                                 "description": "Adverse weather conditions affecting lidar performance (e.g., rain, fog)"},
                                {"value": "occlusion",
                                 "description": "Objects blocking the lidar's line of sight"},
                                {"value": "motion_distortion",
                                 "description": "Distortion in point cloud due to movement during scan"},
                                {"value": "range_dropout",
                                 "description": "Loss of lidar returns at certain distances"},
                                {"value": "reflectivity",
                                 "description": "Problems due to low reflectivity of certain surfaces"},
                            ],
                            "exclusive": False,
                        }
                    ]
                }
            ]
        },
        props={},
    ),
]


@ddt.ddt
class DataUtilsTest(unittest.TestCase):

    def test_dataset_metafile(self):
        dataset_metafile_schema_path = resources_directory / "schemas" / "dataset-metafile.schema.json"
        with open(dataset_metafile_schema_path, "r", encoding="utf-8") as fh:
            dataset_metafile_schema = json.load(fh)

        try:
            jsonschema.Draft7Validator.check_schema(dataset_metafile_schema)
        except Exception as e:
            self.fail()

    def test_sample_metafile(self):
        sample_metafile_schema_path = resources_directory / "schemas" / "sample-metafile.schema.json"
        with open(sample_metafile_schema_path, "r", encoding="utf-8") as fh:
            sample_metafile_schema = json.load(fh)

        try:
            jsonschema.Draft7Validator.check_schema(sample_metafile_schema)
        except Exception as e:
            self.fail()

    def test_layout_spec(self):
        layout_spec_schema_path = resources_directory / "schemas" / "layout-spec.schema.json"
        with open(layout_spec_schema_path, "r", encoding="utf-8") as fh:
            layout_spec_schema = json.load(fh)

        try:
            jsonschema.Draft7Validator.check_schema(layout_spec_schema)
        except Exception as e:
            self.fail()

        layout_spec_validator = jsonschema.Draft7Validator(layout_spec_schema)
        for layout in layouts:
            for _ in layout_spec_validator.iter_errors(layout.layout_spec):
                self.fail()

    def test_taxonomy_hierarchy(self):
        taxonomy_hierarchy_schema_path = resources_directory / "schemas" / "taxonomy-hierarchy.schema.json"
        with open(taxonomy_hierarchy_schema_path, "r", encoding="utf-8") as fh:
            taxonomy_hierarchy_schema = json.load(fh)

        try:
            jsonschema.Draft7Validator.check_schema(taxonomy_hierarchy_schema)
        except Exception as e:
            self.fail()

        taxonomy_hierarchy_validator = jsonschema.Draft7Validator(taxonomy_hierarchy_schema)
        for taxonomy in taxonomies:
            for _ in taxonomy_hierarchy_validator.iter_errors(taxonomy.taxonomy_hierarchy):
                self.fail()

    data_validate_standalone_sample = [
        ("unittest/dataset",
         "20200101T000000-brand_name-0",
         generate_dummy_uuid(1, 1),
         0,
         ),
        ("unittest/dataset",
         "20200101T000000-brand_another_name-0",
         generate_dummy_uuid(1, 1),
         0,
         ),
        ("unittest/dataset",
         "20200101T000000-brand_name-1",
         generate_dummy_uuid(1, 1),
         0,
         ),
        ("unittest/dataset_name_ref",
         "20200101T000000-brand_name-0",
         "dummy_layout/sequence",
         0,
         ),
        ("unittest/dataset_name_ref",
         "20200101T000000-brand_another_name-0",
         "dummy_layout/sequence",
         0,
         ),
        ("unittest/dataset_name_ref",
         "20200101T000000-brand_name-1",
         "dummy_layout/sequence",
         0,
         ),
        ("unittest/dataset_intermixed",
         "20200101T000000-brand_name-0",
         generate_dummy_uuid(1, 2),
         0,
         ),
        ("unittest/dataset_intermixed",
         "20200101T000000-brand_another_name-0",
         generate_dummy_uuid(1, 2),
         0,
         ),
        ("unittest/dataset_intermixed",
         "20200101T000000-brand_name-1",
         generate_dummy_uuid(1, 2),
         0,
         ),
        ("unittest/bad_dataset",
         "20200101T000000-brand_name-0-extra_file",
         generate_dummy_uuid(1, 1),
         4,
         ),
        ("unittest/bad_dataset",
         "20200101T000000-brand_another_name-0-missing_file",
         generate_dummy_uuid(1, 1),
         6,
         ),
        ("unittest/bad_dataset",
         "20200101T000000-brand_name-1-pattern_mismatch",
         generate_dummy_uuid(1, 1),
         2,
         ),
        ("unittest/bad_dataset_intermixed",
         "20200101T000000-brand_name-0-extra_file",
         generate_dummy_uuid(1, 2),
         4,
         ),
        ("unittest/bad_dataset_intermixed",
         "20200101T000000-brand_another_name-0-missing_file",
         generate_dummy_uuid(1, 2),
         6,
         ),
        ("unittest/bad_dataset_intermixed",
         "20200101T000000-brand_name-1-pattern_mismatch",
         generate_dummy_uuid(1, 2),
         2,
         ),
    ]

    @ddt.idata(data_validate_standalone_sample)
    @ddt.unpack
    def test_validate_standalone_sample(self,
                                        dataset_folder,
                                        sample_folder,
                                        layout_reference,
                                        failures_count):
        dataset_root = resources_directory / dataset_folder
        sample_root = resources_directory / dataset_folder / sample_folder

        failures = validate_standalone_sample(dataset_root,
                                              sample_root,
                                              layout_reference,
                                              layouts)
        self.assertEqual(len(failures), failures_count)

        with moto.mock_aws(), s3_make_client(region_name="us-east-1") as client:
            bucket_name = "test-bucket"
            client.create_bucket(Bucket=bucket_name)

            s3_sync_upload(client, resources_directory, bucket_name, "resources")

            cpl_client = cloudpathlib.S3Client(aws_access_key_id=client.meta.credentials.access_key,
                                               aws_secret_access_key=client.meta.credentials.secret_key,
                                               endpoint_url=client.meta.endpoint_url)

            failures = validate_standalone_sample(
                cpl_client.CloudPath(f"s3://{bucket_name}", "resources", dataset_folder),
                cpl_client.CloudPath(f"s3://{bucket_name}", "resources", dataset_folder, sample_folder),
                layout_reference,
                layouts,
            )

            self.assertEqual(len(failures), failures_count)

    data_collect_standalone_dataset_samples = [
        ("unittest/dataset",
         StandaloneDataset(
             name="dataset",
             description="A dataset containing standalone samples.",
             contributor="some.one",
             tags=None,
             props=None,
         ),
         [
             StandaloneSample(
                 path="20200101T000000-brand_name-0/20200101T000001.000001",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_name-0",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000001+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000001+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-0/20200101T000001.500001",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_name-0",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.500001+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.500001+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-0/20200101T000001.999999",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_name-0",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999999+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999999+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-0",
                 layout_uuid=generate_dummy_uuid(1, 1),
                 bag_name="20200101T000000-brand_name-0",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000001+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999999+00:00"),
                 child_sample_paths=[
                     "20200101T000000-brand_name-0/20200101T000001.000001",
                     "20200101T000000-brand_name-0/20200101T000001.500001",
                     "20200101T000000-brand_name-0/20200101T000001.999999",
                 ],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_another_name-0/20200101T000000.000000",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_another_name-0",
                 vehicle_name="brand_another_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_another_name-0/20200101T000000.999999",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_another_name-0",
                 vehicle_name="brand_another_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:00.999999+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:00.999999+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_another_name-0/20200101T000001.499999",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_another_name-0",
                 vehicle_name="brand_another_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.499999+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.499999+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_another_name-0",
                 layout_uuid=generate_dummy_uuid(1, 1),
                 bag_name="20200101T000000-brand_another_name-0",
                 vehicle_name="brand_another_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.499999+00:00"),
                 child_sample_paths=[
                     "20200101T000000-brand_another_name-0/20200101T000000.000000",
                     "20200101T000000-brand_another_name-0/20200101T000000.999999",
                     "20200101T000000-brand_another_name-0/20200101T000001.499999",
                 ],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-1/20200101T000001.000999",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_name-1",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000999+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000999+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-1/20200101T000001.999000",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_name-1",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999000+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999000+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-1",
                 layout_uuid=generate_dummy_uuid(1, 1),
                 bag_name="20200101T000000-brand_name-1",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000999+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999000+00:00"),
                 child_sample_paths=[
                     "20200101T000000-brand_name-1/20200101T000001.000999",
                     "20200101T000000-brand_name-1/20200101T000001.999000",
                 ],
                 tags=None,
                 props=None,
             ),
         ],
         0,
         ),
        ("unittest/dataset_name_ref",
         StandaloneDataset(
             name="dataset_name_ref",
             description="A dataset containing standalone samples.",
             contributor="some.one",
             tags=None,
             props=None,
         ),
         [
             StandaloneSample(
                 path="20200101T000000-brand_name-0/20200101T000001.000001",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_name-0",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000001+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000001+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-0/20200101T000001.500001",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_name-0",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.500001+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.500001+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-0/20200101T000001.999999",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_name-0",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999999+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999999+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-0",
                 layout_uuid=generate_dummy_uuid(1, 1),
                 bag_name="20200101T000000-brand_name-0",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000001+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999999+00:00"),
                 child_sample_paths=[
                     "20200101T000000-brand_name-0/20200101T000001.000001",
                     "20200101T000000-brand_name-0/20200101T000001.500001",
                     "20200101T000000-brand_name-0/20200101T000001.999999",
                 ],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_another_name-0/20200101T000000.000000",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_another_name-0",
                 vehicle_name="brand_another_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_another_name-0/20200101T000000.999999",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_another_name-0",
                 vehicle_name="brand_another_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:00.999999+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:00.999999+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_another_name-0/20200101T000001.499999",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_another_name-0",
                 vehicle_name="brand_another_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.499999+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.499999+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_another_name-0",
                 layout_uuid=generate_dummy_uuid(1, 1),
                 bag_name="20200101T000000-brand_another_name-0",
                 vehicle_name="brand_another_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.499999+00:00"),
                 child_sample_paths=[
                     "20200101T000000-brand_another_name-0/20200101T000000.000000",
                     "20200101T000000-brand_another_name-0/20200101T000000.999999",
                     "20200101T000000-brand_another_name-0/20200101T000001.499999",
                 ],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-1/20200101T000001.000999",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_name-1",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000999+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000999+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-1/20200101T000001.999000",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_name-1",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999000+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999000+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-1",
                 layout_uuid=generate_dummy_uuid(1, 1),
                 bag_name="20200101T000000-brand_name-1",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000999+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999000+00:00"),
                 child_sample_paths=[
                     "20200101T000000-brand_name-1/20200101T000001.000999",
                     "20200101T000000-brand_name-1/20200101T000001.999000",
                 ],
                 tags=None,
                 props=None,
             ),
         ],
         0,
         ),
        ("unittest/dataset_intermixed",
         StandaloneDataset(
             name="dataset_intermixed",
             description="A dataset containing standalone samples.",
             contributor="some.one",
             tags=None,
             props=None,
         ),
         [
             StandaloneSample(
                 path="20200101T000000-brand_name-0",
                 layout_uuid=generate_dummy_uuid(1, 2),
                 bag_name="20200101T000000-brand_name-0",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000001+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999999+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_another_name-0",
                 layout_uuid=generate_dummy_uuid(1, 2),
                 bag_name="20200101T000000-brand_another_name-0",
                 vehicle_name="brand_another_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.499999+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-1",
                 layout_uuid=generate_dummy_uuid(1, 2),
                 bag_name="20200101T000000-brand_name-1",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000999+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999000+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
         ],
         0,
         ),
        ("unittest/bad_dataset",
         StandaloneDataset(
             name="bad_dataset",
             description="A dataset containing standalone samples.",
             contributor="some.one",
             tags=None,
             props=None,
         ),
         [
             StandaloneSample(
                 path="20200101T000000-brand_name-0-extra_file/20200101T000001.000001",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_name-0",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000001+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000001+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-0-extra_file/20200101T000001.500001",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_name-0",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.500001+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.500001+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-0-extra_file/20200101T000001.999999",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_name-0",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999999+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999999+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-0-extra_file",
                 layout_uuid=generate_dummy_uuid(1, 1),
                 bag_name="20200101T000000-brand_name-0",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000001+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999999+00:00"),
                 child_sample_paths=[
                     "20200101T000000-brand_name-0-extra_file/20200101T000001.000001",
                     "20200101T000000-brand_name-0-extra_file/20200101T000001.500001",
                     "20200101T000000-brand_name-0-extra_file/20200101T000001.999999",
                 ],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_another_name-0-missing_file/20200101T000000.000000",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_another_name-0",
                 vehicle_name="brand_another_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_another_name-0-missing_file/20200101T000000.999999",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_another_name-0",
                 vehicle_name="brand_another_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:00.999999+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:00.999999+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_another_name-0-missing_file/20200101T000001.499999",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_another_name-0",
                 vehicle_name="brand_another_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.499999+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.499999+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_another_name-0-missing_file",
                 layout_uuid=generate_dummy_uuid(1, 1),
                 bag_name="20200101T000000-brand_another_name-0",
                 vehicle_name="brand_another_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.499999+00:00"),
                 child_sample_paths=[
                     "20200101T000000-brand_another_name-0-missing_file/20200101T000000.000000",
                     "20200101T000000-brand_another_name-0-missing_file/20200101T000000.999999",
                     "20200101T000000-brand_another_name-0-missing_file/20200101T000001.499999",
                 ],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-1-pattern_mismatch",
                 layout_uuid=generate_dummy_uuid(1, 1),
                 bag_name="20200101T000000-brand_name-1",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000999+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999000+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             # Different with `validate_standalone_sample` where bad samples' children are not identified as other
             # standalone samples, here we collect all standalone samples including bad ones' children, if they are
             # excluded by the parent sample validation due to bad naming or pattern mismatch.
             StandaloneSample(
                 path="20200101T000000-brand_name-1-pattern_mismatch/bad_directory_name",
                 layout_uuid=generate_dummy_uuid(1, 1, 1),
                 bag_name="20200101T000000-brand_another_name-0",
                 vehicle_name="brand_another_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
         ],
         12,
         ),
        ("unittest/bad_dataset_intermixed",
         StandaloneDataset(
             name="bad_dataset_intermixed",
             description="A dataset containing standalone samples.",
             contributor="some.one",
             tags=None,
             props=None,
         ),
         [
             StandaloneSample(
                 path="20200101T000000-brand_name-0-extra_file",
                 layout_uuid=generate_dummy_uuid(1, 2),
                 bag_name="20200101T000000-brand_name-0",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000001+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999999+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_another_name-0-missing_file",
                 layout_uuid=generate_dummy_uuid(1, 2),
                 bag_name="20200101T000000-brand_another_name-0",
                 vehicle_name="brand_another_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.499999+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
             StandaloneSample(
                 path="20200101T000000-brand_name-1-pattern_mismatch",
                 layout_uuid=generate_dummy_uuid(1, 2),
                 bag_name="20200101T000000-brand_name-1",
                 vehicle_name="brand_name",
                 begin_frame_dt=dt_parse_iso("2020-01-01T00:00:01.000999+00:00"),
                 end_frame_dt=dt_parse_iso("2020-01-01T00:00:01.999000+00:00"),
                 child_sample_paths=[],
                 tags=None,
                 props=None,
             ),
         ],
         12,
         ),
    ]

    @ddt.idata(data_collect_standalone_dataset_samples)
    @ddt.unpack
    def test_collect_standalone_dataset_samples(self, dataset_folder, dataset_expect, samples_expect, failures_count):
        dataset_root = resources_directory / dataset_folder

        dataset, samples, failures = collect_standalone_dataset_samples(dataset_root, layouts)

        self.assertEqual(dataset_expect, dataset)
        self.assertEqual({sample.path: sample for sample in samples_expect},
                         {sample.path: sample for sample in samples})
        self.assertEqual(len(failures), failures_count)

        with moto.mock_aws(), s3_make_client(region_name="us-east-1") as client:
            bucket_name = "test-bucket"
            client.create_bucket(Bucket=bucket_name)

            s3_sync_upload(client, resources_directory, bucket_name, "resources")

            cpl_client = cloudpathlib.S3Client(aws_access_key_id=client.meta.credentials.access_key,
                                               aws_secret_access_key=client.meta.credentials.secret_key,
                                               endpoint_url=client.meta.endpoint_url)

            dataset, samples, failures = collect_standalone_dataset_samples(
                cpl_client.CloudPath(f"s3://{bucket_name}", "resources", dataset_folder),
                layouts,
            )

            self.assertEqual(dataset_expect, dataset)
            self.assertEqual({sample.path: sample for sample in samples_expect},
                             {sample.path: sample for sample in samples})
            self.assertEqual(len(failures), failures_count)
