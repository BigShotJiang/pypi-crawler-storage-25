import pytest_postgresql.factories
from fastapi.testclient import TestClient
from plexus.common.utils.dtutils import dt_parse_iso
from plexus.pulse.common.utils.testutils import case_insensitive_json_compare, generate_dummy_uuid_str
from plexus.pulse.common.utils.testutils import patched_postgresql_session_maker, patched_value_factory

from plexus.pulse.demeter.app.api import current_dt_clock
from plexus.pulse.demeter.app.api.dataset_workflow_endpoints import router as workflow_router
from plexus.pulse.demeter.app.core.database import make_session
from plexus.pulse.demeter.app.main import app
from plexus.pulse.demeter.app.models.registry import RegistryBase

fixture_postgresql_test_proc = pytest_postgresql.factories.postgresql_proc(host="localhost", user="postgres")
fixture_postgresql_test = pytest_postgresql.factories.postgresql("fixture_postgresql_test_proc", dbname="pulse")
fixture_make_session = patched_postgresql_session_maker("fixture_postgresql_test",
                                                        RegistryBase,
                                                        app,
                                                        make_session,
                                                        expire_on_commit=False)
fixture_current_dt_clock = patched_value_factory(app, current_dt_clock)

client = TestClient(app)


def test_submit_dataset_registration(fixture_make_session, fixture_current_dt_clock):
    response_expect = {
        "registration": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(6),
            "resource_path": "datasets/dummy_dataset",
            "dataset_uuid": generate_dummy_uuid_str(7),
            "flags": 0,
            "props": {},
        },
        "dataset": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:test"],
            "props": {},
        },
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{workflow_router.prefix}/submit_dataset_registration/",
                               json={
                                   "uuid": generate_dummy_uuid_str(6),
                                   "resource_path": "datasets/dummy_dataset",
                                   "props": {},
                                   "dataset": {
                                       "uuid": generate_dummy_uuid_str(7),
                                       "name": "dummy_dataset",
                                       "description": "A dummy dataset",
                                       "contributor_sso_sid": 1234567890,
                                       "tags": ["division:training", "mission:name:test"],
                                       "props": {},
                                   },
                               })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_mark_dataset_registration(fixture_make_session, fixture_current_dt_clock):
    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{workflow_router.prefix}/submit_dataset_registration/",
                               json={
                                   "uuid": generate_dummy_uuid_str(6),
                                   "resource_path": "datasets/dummy_dataset",
                                   "props": {},
                                   "dataset": {
                                       "uuid": generate_dummy_uuid_str(7),
                                       "name": "dummy_dataset",
                                       "description": "A dummy dataset",
                                       "contributor_sso_sid": 1234567890,
                                       "tags": ["division:training", "mission:name:test"],
                                       "props": {},
                                   },
                               })
    assert response.status_code == 200, response.text

    response_expect = {
        "registration": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(6),
            "resource_path": "datasets/dummy_dataset",
            "dataset_uuid": generate_dummy_uuid_str(7),
            "flags": 0,
            "props": {},
        },
        "dataset": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:test"],
            "props": {},
        },
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
        response = client.put(f"{workflow_router.prefix}/mark_dataset_registration/",
                              params={
                                  "uuid": generate_dummy_uuid_str(6),
                                  "flags": 0,
                              })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response_expect = {
        "registration": {
            "sqn": 2,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-03-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 2,
            "uuid": generate_dummy_uuid_str(6),
            "resource_path": "datasets/dummy_dataset",
            "dataset_uuid": generate_dummy_uuid_str(7),
            "flags": 0x010000,
            "props": {},
        },
        "dataset": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(7),
            "name": "dummy_dataset",
            "description": "A dummy dataset",
            "contributor_sso_sid": 1234567890,
            "tags": ["division:training", "mission:name:test"],
            "props": {},
        },
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-03-01T00:00:00.000000+00:00")):
        response = client.put(f"{workflow_router.prefix}/mark_dataset_registration/",
                              params={
                                  "uuid": generate_dummy_uuid_str(6),
                                  "flags": 0x010000,
                              })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_submit_dataset_promotion(fixture_make_session, fixture_current_dt_clock):
    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{workflow_router.prefix}/submit_dataset_registration/",
                               json={
                                   "uuid": generate_dummy_uuid_str(6),
                                   "resource_path": "datasets/dummy_dataset",
                                   "props": {},
                                   "dataset": {
                                       "uuid": generate_dummy_uuid_str(7),
                                       "name": "dummy_dataset",
                                       "description": "A dummy dataset",
                                       "contributor_sso_sid": 1234567890,
                                       "tags": ["division:training", "mission:name:test"],
                                       "props": {},
                                   },
                               })
    assert response.status_code == 200, response.text

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(15),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "reviewer_sso_sid": 1234567890,
        "flags": 0,
        "props": {},
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{workflow_router.prefix}/submit_dataset_promotion/",
                               params={
                                   "uuid": generate_dummy_uuid_str(15),
                                   "dataset_uuid": generate_dummy_uuid_str(7),
                                   "reviewer_sso_sid": 1234567890,
                               })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_mark_dataset_promotion(fixture_make_session, fixture_current_dt_clock):
    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{workflow_router.prefix}/submit_dataset_registration/",
                               json={
                                   "uuid": generate_dummy_uuid_str(6),
                                   "resource_path": "datasets/dummy_dataset",
                                   "props": {},
                                   "dataset": {
                                       "uuid": generate_dummy_uuid_str(7),
                                       "name": "dummy_dataset",
                                       "description": "A dummy dataset",
                                       "contributor_sso_sid": 1234567890,
                                       "tags": ["division:training", "mission:name:test"],
                                       "props": {},
                                   },
                               })
    assert response.status_code == 200, response.text

    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{workflow_router.prefix}/submit_dataset_promotion/",
                               params={
                                   "uuid": generate_dummy_uuid_str(15),
                                   "dataset_uuid": generate_dummy_uuid_str(7),
                                   "reviewer_sso_sid": 1234567890,
                               })
    assert response.status_code == 200, response.text

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(15),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "reviewer_sso_sid": 1234567890,
        "flags": 0,
        "props": {},
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
        response = client.put(f"{workflow_router.prefix}/mark_dataset_promotion/",
                              params={
                                  "uuid": generate_dummy_uuid_str(15),
                                  "flags": 0,
                              })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-03-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(15),
        "dataset_uuid": generate_dummy_uuid_str(7),
        "reviewer_sso_sid": 1234567890,
        "flags": 0x010000,
        "props": {},
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-03-01T00:00:00.000000+00:00")):
        response = client.put(f"{workflow_router.prefix}/mark_dataset_promotion/",
                              params={
                                  "uuid": generate_dummy_uuid_str(15),
                                  "flags": 0x010000,
                              })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_submit_model_training(fixture_make_session, fixture_current_dt_clock):
    response_expect = {
        "training": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(12),
            "experiment_uuid": generate_dummy_uuid_str(11),
            "flags": 0,
            "props": {},
        },
        "experiment": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(11),
            "parent_uuid": None,
            "architecture_uuid": generate_dummy_uuid_str(4),
            "dataset_uuid": generate_dummy_uuid_str(7),
            "name": "dummy_model",
            "description": "A dummy model experiment",
            "contributor_sso_sid": 1234567890,
            "path": f"experiments/some.one/{generate_dummy_uuid_str(11)}/",
            "checkpoint_path": "latest.pth",
            "tags": ["model:bev_perception", "framework:pytorch"],
            "props": {},
        },
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{workflow_router.prefix}/submit_model_training/",
                               json={
                                   "uuid": generate_dummy_uuid_str(12),
                                   "props": {},
                                   "experiment": {
                                       "uuid": generate_dummy_uuid_str(11),
                                       "architecture_uuid": generate_dummy_uuid_str(4),
                                       "dataset_uuid": generate_dummy_uuid_str(7),
                                       "name": "dummy_model",
                                       "description": "A dummy model experiment",
                                       "contributor_sso_sid": 1234567890,
                                       "path": f"experiments/some.one/{generate_dummy_uuid_str(11)}/",
                                       "checkpoint_path": "latest.pth",
                                       "tags": ["model:bev_perception", "framework:pytorch"],
                                       "props": {},
                                   },
                               })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_mark_model_training(fixture_make_session, fixture_current_dt_clock):
    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{workflow_router.prefix}/submit_model_training/",
                               json={
                                   "uuid": generate_dummy_uuid_str(12),
                                   "props": {},
                                   "experiment": {
                                       "uuid": generate_dummy_uuid_str(11),
                                       "architecture_uuid": generate_dummy_uuid_str(4),
                                       "dataset_uuid": generate_dummy_uuid_str(7),
                                       "name": "dummy_model",
                                       "description": "A dummy model experiment",
                                       "contributor_sso_sid": 1234567890,
                                       "path": f"experiments/some.one/{generate_dummy_uuid_str(11)}/",
                                       "checkpoint_path": "latest.pth",
                                       "tags": ["model:bev_perception", "framework:pytorch"],
                                       "props": {},
                                   },
                               })
    assert response.status_code == 200, response.text

    response_expect = {
        "training": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(12),
            "experiment_uuid": generate_dummy_uuid_str(11),
            "flags": 0,
            "props": {},
        },
        "experiment": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(11),
            "parent_uuid": None,
            "architecture_uuid": generate_dummy_uuid_str(4),
            "dataset_uuid": generate_dummy_uuid_str(7),
            "name": "dummy_model",
            "description": "A dummy model experiment",
            "contributor_sso_sid": 1234567890,
            "path": f"experiments/some.one/{generate_dummy_uuid_str(11)}/",
            "checkpoint_path": "latest.pth",
            "tags": ["model:bev_perception", "framework:pytorch"],
            "props": {},
        },
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
        response = client.put(f"{workflow_router.prefix}/mark_model_training/",
                              params={
                                  "uuid": generate_dummy_uuid_str(12),
                                  "flags": 0,
                              })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response_expect = {
        "training": {
            "sqn": 2,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-03-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 2,
            "uuid": generate_dummy_uuid_str(12),
            "experiment_uuid": generate_dummy_uuid_str(11),
            "flags": 0x010000,
            "props": {},
        },
        "experiment": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(11),
            "parent_uuid": None,
            "architecture_uuid": generate_dummy_uuid_str(4),
            "dataset_uuid": generate_dummy_uuid_str(7),
            "name": "dummy_model",
            "description": "A dummy model experiment",
            "contributor_sso_sid": 1234567890,
            "path": f"experiments/some.one/{generate_dummy_uuid_str(11)}/",
            "checkpoint_path": "latest.pth",
            "tags": ["model:bev_perception", "framework:pytorch"],
            "props": {},
        },
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-03-01T00:00:00.000000+00:00")):
        response = client.put(f"{workflow_router.prefix}/mark_model_training/",
                              params={
                                  "uuid": generate_dummy_uuid_str(12),
                                  "flags": 0x010000,
                              })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_submit_experiment_promotion(fixture_make_session, fixture_current_dt_clock):
    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(16),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "reviewer_sso_sid": 1234567890,
        "flags": 0,
        "props": {},
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{workflow_router.prefix}/submit_experiment_promotion/",
                               params={
                                   "uuid": generate_dummy_uuid_str(16),
                                   "experiment_uuid": generate_dummy_uuid_str(11),
                                   "reviewer_sso_sid": 1234567890,
                               })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_mark_experiment_promotion(fixture_make_session, fixture_current_dt_clock):
    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{workflow_router.prefix}/submit_experiment_promotion/",
                               params={
                                   "uuid": generate_dummy_uuid_str(16),
                                   "experiment_uuid": generate_dummy_uuid_str(11),
                                   "reviewer_sso_sid": 1234567890,
                               })
    assert response.status_code == 200, response.text

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(16),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "reviewer_sso_sid": 1234567890,
        "flags": 0,
        "props": {},
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
        response = client.put(f"{workflow_router.prefix}/mark_experiment_promotion/",
                              params={
                                  "uuid": generate_dummy_uuid_str(16),
                                  "flags": 0,
                              })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-03-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(16),
        "experiment_uuid": generate_dummy_uuid_str(11),
        "reviewer_sso_sid": 1234567890,
        "flags": 0x010000,
        "props": {},
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-03-01T00:00:00.000000+00:00")):
        response = client.put(f"{workflow_router.prefix}/mark_experiment_promotion/",
                              params={
                                  "uuid": generate_dummy_uuid_str(16),
                                  "flags": 0x010000,
                              })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_submit_model_evaluation(fixture_make_session, fixture_current_dt_clock):
    response_expect = {
        "evaluation": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(14),
            "assessment_uuid": generate_dummy_uuid_str(13),
            "flags": 0,
            "props": {},
        },
        "assessment": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(13),
            "benchmark_uuid": generate_dummy_uuid_str(5),
            "experiment_uuid": generate_dummy_uuid_str(11),
            "dataset_uuid": generate_dummy_uuid_str(7),
            "name": "dummy_assessment",
            "description": "A dummy model assessment",
            "contributor_sso_sid": 1234567890,
            "path": f"assessments/some.one/{generate_dummy_uuid_str(13)}/",
            "assessment_data": {},
            "tags": ["benchmark:standard", "scope:full"],
            "props": {},
        },
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{workflow_router.prefix}/submit_model_evaluation/",
                               json={
                                   "uuid": generate_dummy_uuid_str(14),
                                   "props": {},
                                   "assessment": {
                                       "uuid": generate_dummy_uuid_str(13),
                                       "benchmark_uuid": generate_dummy_uuid_str(5),
                                       "experiment_uuid": generate_dummy_uuid_str(11),
                                       "dataset_uuid": generate_dummy_uuid_str(7),
                                       "name": "dummy_assessment",
                                       "description": "A dummy model assessment",
                                       "contributor_sso_sid": 1234567890,
                                       "path": f"assessments/some.one/{generate_dummy_uuid_str(13)}/",
                                       "assessment_data": {},
                                       "tags": ["benchmark:standard", "scope:full"],
                                       "props": {},
                                   },
                               })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_mark_model_evaluation(fixture_make_session, fixture_current_dt_clock):
    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{workflow_router.prefix}/submit_model_evaluation/",
                               json={
                                   "uuid": generate_dummy_uuid_str(14),
                                   "props": {},
                                   "assessment": {
                                       "uuid": generate_dummy_uuid_str(13),
                                       "benchmark_uuid": generate_dummy_uuid_str(5),
                                       "experiment_uuid": generate_dummy_uuid_str(11),
                                       "dataset_uuid": generate_dummy_uuid_str(7),
                                       "name": "dummy_assessment",
                                       "description": "A dummy model assessment",
                                       "contributor_sso_sid": 1234567890,
                                       "path": f"assessments/some.one/{generate_dummy_uuid_str(13)}/",
                                       "assessment_data": {},
                                       "tags": ["benchmark:standard", "scope:full"],
                                       "props": {},
                                   },
                               })
    assert response.status_code == 200, response.text

    response_expect = {
        "evaluation": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(14),
            "assessment_uuid": generate_dummy_uuid_str(13),
            "flags": 0,
            "props": {},
        },
        "assessment": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(13),
            "benchmark_uuid": generate_dummy_uuid_str(5),
            "experiment_uuid": generate_dummy_uuid_str(11),
            "dataset_uuid": generate_dummy_uuid_str(7),
            "name": "dummy_assessment",
            "description": "A dummy model assessment",
            "contributor_sso_sid": 1234567890,
            "path": f"assessments/some.one/{generate_dummy_uuid_str(13)}/",
            "assessment_data": {},
            "tags": ["benchmark:standard", "scope:full"],
            "props": {},
        },
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
        response = client.put(f"{workflow_router.prefix}/mark_model_evaluation/",
                              params={
                                  "uuid": generate_dummy_uuid_str(14),
                                  "flags": 0,
                              })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response_expect = {
        "evaluation": {
            "sqn": 2,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-03-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 2,
            "uuid": generate_dummy_uuid_str(14),
            "assessment_uuid": generate_dummy_uuid_str(13),
            "flags": 0x010000,
            "props": {},
        },
        "assessment": {
            "sqn": 1,
            "created_at": "2020-01-01T00:00:00.000000+00:00",
            "updated_at": "2020-01-01T00:00:00.000000+00:00",
            "expired_at": None,
            "record_sqn": 1,
            "revision": 1,
            "uuid": generate_dummy_uuid_str(13),
            "benchmark_uuid": generate_dummy_uuid_str(5),
            "experiment_uuid": generate_dummy_uuid_str(11),
            "dataset_uuid": generate_dummy_uuid_str(7),
            "name": "dummy_assessment",
            "description": "A dummy model assessment",
            "contributor_sso_sid": 1234567890,
            "path": f"assessments/some.one/{generate_dummy_uuid_str(13)}/",
            "assessment_data": {},
            "tags": ["benchmark:standard", "scope:full"],
            "props": {},
        },
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-03-01T00:00:00.000000+00:00")):
        response = client.put(f"{workflow_router.prefix}/mark_model_evaluation/",
                              params={
                                  "uuid": generate_dummy_uuid_str(14),
                                  "flags": 0x010000,
                              })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_submit_assessment_promotion(fixture_make_session, fixture_current_dt_clock):
    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(17),
        "assessment_uuid": generate_dummy_uuid_str(13),
        "reviewer_sso_sid": 1234567890,
        "flags": 0,
        "props": {},
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{workflow_router.prefix}/submit_assessment_promotion/",
                               params={
                                   "uuid": generate_dummy_uuid_str(17),
                                   "assessment_uuid": generate_dummy_uuid_str(13),
                                   "reviewer_sso_sid": 1234567890,
                               })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)


def test_mark_assessment_promotion(fixture_make_session, fixture_current_dt_clock):
    with fixture_current_dt_clock.use(dt_parse_iso("2020-01-01T00:00:00.000000+00:00")):
        response = client.post(f"{workflow_router.prefix}/submit_assessment_promotion/",
                               params={
                                   "uuid": generate_dummy_uuid_str(17),
                                   "assessment_uuid": generate_dummy_uuid_str(13),
                                   "reviewer_sso_sid": 1234567890,
                               })
    assert response.status_code == 200, response.text

    response_expect = {
        "sqn": 1,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-01-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 1,
        "uuid": generate_dummy_uuid_str(17),
        "assessment_uuid": generate_dummy_uuid_str(13),
        "reviewer_sso_sid": 1234567890,
        "flags": 0,
        "props": {},
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-02-01T00:00:00.000000+00:00")):
        response = client.put(f"{workflow_router.prefix}/mark_assessment_promotion/",
                              params={
                                  "uuid": generate_dummy_uuid_str(17),
                                  "flags": 0,
                              })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)

    response_expect = {
        "sqn": 2,
        "created_at": "2020-01-01T00:00:00.000000+00:00",
        "updated_at": "2020-03-01T00:00:00.000000+00:00",
        "expired_at": None,
        "record_sqn": 1,
        "revision": 2,
        "uuid": generate_dummy_uuid_str(17),
        "assessment_uuid": generate_dummy_uuid_str(13),
        "reviewer_sso_sid": 1234567890,
        "flags": 0x010000,
        "props": {},
    }

    with fixture_current_dt_clock.use(dt_parse_iso("2020-03-01T00:00:00.000000+00:00")):
        response = client.put(f"{workflow_router.prefix}/mark_assessment_promotion/",
                              params={
                                  "uuid": generate_dummy_uuid_str(17),
                                  "flags": 0x010000,
                              })
    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, response_expect)
