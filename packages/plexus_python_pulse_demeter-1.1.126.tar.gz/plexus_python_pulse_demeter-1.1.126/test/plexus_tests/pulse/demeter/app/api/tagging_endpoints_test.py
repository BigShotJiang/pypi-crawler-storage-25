import datetime
import tempfile

import pytest_postgresql.factories
from fastapi.testclient import TestClient
from plexus.common.utils.dtutils import dt_parse_iso
from plexus.common.utils.randutils import randomizer
from plexus.pulse.common.utils.tagutils import predefined_tagsets
from plexus.pulse.common.utils.tagutils import tag_cache
from plexus.pulse.common.utils.testutils import case_insensitive_json_compare
from plexus.pulse.common.utils.testutils import patched_postgresql_session_maker

from plexus.pulse.demeter.app.api.tagging_endpoints import router as tagging_router
from plexus.pulse.demeter.app.core.database import make_session
from plexus.pulse.demeter.app.main import app
from plexus.pulse.demeter.app.models.registry import RegistryBase

fixture_postgresql_test_proc = pytest_postgresql.factories.postgresql_proc(host="localhost", user="postgres")
fixture_postgresql_test = pytest_postgresql.factories.postgresql("fixture_postgresql_test_proc", dbname="pulse")
fixture_make_session = patched_postgresql_session_maker("fixture_postgresql_test",
                                                        RegistryBase,
                                                        app,
                                                        make_session,
                                                        expire_on_commit=False)

client = TestClient(app)


def test_upload_tag_cache(fixture_make_session):
    with tempfile.NamedTemporaryFile() as temp_db_file:
        cache = tag_cache(file_path=temp_db_file.name)

        cache.add_target("awesome_tagger", "awesome_tagger", "1.0.0", "dummy_vehicle",
                         dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                         dt_parse_iso("2020-01-02T00:00:00.000000+00:00"))

        (
            cache
            .with_target("awesome_tagger")
            .add_ranged_record(dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                               dt_parse_iso("2020-01-01T12:00:00.000000+00:00"),
                               predefined_tagsets().get("universal").get_bound("environment:weather:cloudy"),
                               features={"dummy_feature": "dummy_value"},
                               props={"dummy_prop": "dummy_value"})
            .add_ranged_record(dt_parse_iso("2020-01-01T12:00:00.000000+00:00"),
                               dt_parse_iso("2020-01-02T00:00:00.000000+00:00"),
                               predefined_tagsets().get("universal").get_bound("environment:weather:rainy"),
                               features={"dummy_feature": "dummy_value"},
                               props={"dummy_prop": "dummy_value"})
        )

        with open(temp_db_file.name, "rb") as fh:
            response = client.post(
                f"{tagging_router.prefix}/upload_tag_cache/",
                files={"tag_cache_file": ("tag_cache.db", fh, "application/octet-stream")},
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"}
            )

    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, {"targets_count": 1, "records_count": 2})


def test_list_targets_records(fixture_make_session):
    with tempfile.NamedTemporaryFile() as temp_db_file:
        cache = tag_cache(file_path=temp_db_file.name)

        cache.add_target("awesome_tagger", "awesome_tagger", "1.0.0", "dummy_vehicle",
                         dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                         dt_parse_iso("2020-01-02T00:00:00.000000+00:00"))

        tag_params = [
            (
                dt_parse_iso("2020-01-01T00:00:00.000000+00:00") + datetime.timedelta(minutes=i),
                dt_parse_iso("2020-01-01T00:00:00.000000+00:00") + datetime.timedelta(minutes=i + 1),
                predefined_tagsets().get("unittest").get_bound(
                    "level_1_tag:level_2_tag" if i % 2 == 0 else "level_1_tag:another_level_2_tag",
                ),
                {
                    "dummy_dict": {
                        "dummy_value": randomizer().next_int(0, 100),
                        "another_dummy_value": randomizer().next_int(0, 100),
                    },
                },
                {"dummy_prop": "dummy_value"},
            ) for i in range(1000)
        ]

        for begin_dt, end_dt, tag, features, props in tag_params:
            cache.with_target("awesome_tagger").add_ranged_record(begin_dt, end_dt, tag, features=features, props=props)

        with open(temp_db_file.name, "rb") as fh:
            response = client.post(
                f"{tagging_router.prefix}/upload_tag_cache/",
                files={"tag_cache_file": ("tag_cache.db", fh, "application/octet-stream")},
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"}
            )

    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, {"targets_count": 1, "records_count": 1000})

    response = client.get(f"{tagging_router.prefix}/targets",
                          params={
                              "tagger_name": "awesome_tagger",
                              "tagger_version": "1.0.0",
                              "vehicle_name": "dummy_vehicle",
                              "skip": 0,
                              "limit": 1000,
                          })
    assert response.status_code == 200, response.text

    assert len(response.json().get("targets", [])) == 1

    response = client.get(f"{tagging_router.prefix}/records",
                          params={
                              "tagger_name": "awesome_tagger",
                              "tagger_version": "1.0.0",
                              "vehicle_name": "dummy_vehicle",
                              "skip": 0,
                              "limit": 1000,
                          })
    assert response.status_code == 200, response.text

    assert len(response.json().get("records", [])) == 1000


def test_list_targets_records__tag_query(fixture_make_session):
    with tempfile.NamedTemporaryFile() as temp_db_file:
        cache = tag_cache(file_path=temp_db_file.name)

        cache.add_target("awesome_tagger", "awesome_tagger", "1.0.0", "dummy_vehicle",
                         dt_parse_iso("2020-01-01T00:00:00.000000+00:00"),
                         dt_parse_iso("2020-01-02T00:00:00.000000+00:00"))

        tag_params = [
            (
                dt_parse_iso("2020-01-01T00:00:00.000000+00:00") + datetime.timedelta(minutes=i),
                dt_parse_iso("2020-01-01T00:00:00.000000+00:00") + datetime.timedelta(minutes=i + 1),
                predefined_tagsets().get("unittest").get_bound(
                    "level_1_tag:level_2_tag" if i % 2 == 0 else "level_1_tag:another_level_2_tag",
                ),
                {
                    "dummy_dict": {
                        "dummy_value": randomizer().next_int(0, 100),
                        "another_dummy_value": randomizer().next_int(0, 100),
                    },
                },
                {"dummy_prop": "dummy_value"},
            ) for i in range(1000)
        ]

        for begin_dt, end_dt, tag, features, props in tag_params:
            cache.with_target("awesome_tagger").add_ranged_record(begin_dt, end_dt, tag, features=features, props=props)

        with open(temp_db_file.name, "rb") as fh:
            response = client.post(
                f"{tagging_router.prefix}/upload_tag_cache/",
                files={"tag_cache_file": ("tag_cache.db", fh, "application/octet-stream")},
                params={"created_at": "2020-01-01T00:00:00.000000+00:00"}
            )

    assert response.status_code == 200, response.text

    response_data = response.json()
    assert case_insensitive_json_compare(response_data, {"targets_count": 1, "records_count": 1000})

    response = client.get(f"{tagging_router.prefix}/targets",
                          params={
                              "tagger_name": "awesome_tagger",
                              "tagger_version": "1.0.0",
                              "vehicle_name": "dummy_vehicle",
                              "skip": 0,
                              "limit": 1000,
                          })
    assert response.status_code == 200, response.text

    assert len(response.json().get("targets", [])) == 1

    response = client.get(f"{tagging_router.prefix}/records",
                          params={
                              "query":
                                  """
                                  level_1_tag:level_2_tag or
                                  level_1_tag:another_level_2_tag { $.dummy_dict ? (@.dummy_value < 50 && @.another_dummy_value >= 50) }
                                  """,
                              "skip": 0,
                              "limit": 1000,
                          })
    assert response.status_code == 200, response.text

    assert len(response.json().get("records", [])) == sum(
        1 for *_, tag, features, _ in tag_params if (
            tag.name == "level_1_tag:level_2_tag" or
            (tag.name == "level_1_tag:another_level_2_tag" and
             features["dummy_dict"]["dummy_value"] < 50 <= features["dummy_dict"]["another_dummy_value"])
        )
    )

    response = client.get(f"{tagging_router.prefix}/records",
                          params={
                              "query":
                                  """
                                  level_1_tag:level_2_tag { $.dummy_dict.dummy_value ? (@ >= 50) } or
                                  (
                                      level_1_tag:another_level_2_tag { $.dummy_dict.dummy_value ? (@ < 50) } and
                                      level_1_tag:another_level_2_tag { $.dummy_dict ? (@.another_dummy_value >= 50) }
                                  )
                                  """,
                              "skip": 0,
                              "limit": 1000,
                          })
    assert response.status_code == 200, response.text

    assert len(response.json().get("records", [])) == sum(
        1 for *_, tag, features, _ in tag_params if (
            (tag.name == "level_1_tag:level_2_tag" and features["dummy_dict"]["dummy_value"] >= 50) or
            (
                (tag.name == "level_1_tag:another_level_2_tag" and features["dummy_dict"]["dummy_value"] < 50) and
                (tag.name == "level_1_tag:another_level_2_tag" and features["dummy_dict"]["another_dummy_value"] >= 50)
            )
        )
    )
