# Plexus Demeter - Dataset Management and Versioning System

## Data Flow Design

### Data Entities: Lifecycle

The lifecycle of datasets and samples progresses through several stages, from initial extraction to active use in
model training and evaluation:

- **Sample Mining**: Extract samples from bag snippets using rule-based or model-based discovery logic. This process
  produces standalone datasets with sample files organized by predefined layouts, including metadata files and initial
  classifiers. Standalone extraction enables rapid iteration without polluting the central catalog with intermediate
  results.

- **Dataset Registration**: Register standalone samples in the central catalog by persisting metadata to the database
  and uploading media files to durable storage. During registration, the system validates data integrity based on
  layout specifications to ensure completeness and correctness. Duplicate detection prevents redundant storage while
  preserving data provenance.

- **Dataset Selection**: Create curated datasets by filtering registered samples based on classifiers, time ranges,
  sensor configurations, or other criteria. The system creates new dataset versions rather than modifying existing ones,
  ensuring reproducibility of experiments and model training runs.

- **Sample Classifier Labeling**: Generate lightweight tags for samples using automated heuristics or model-based
  inference. Classifiers enable efficient filtering and dataset selection, and support versioning for iterative
  refinement of classifying logic.

- **Sample Annotation Labeling**: Create detailed annotations for samples using specialized tools (manual or automated).
  Annotations are versioned to track changes and enable comparison between different annotation standards or tool
  versions.

- **Model Training**: Train new models or fine-tune existing ones using registered datasets with their classifiers and
  annotations. Linking each training run to specific dataset versions ensures reproducibility and enables systematic
  analysis of performance changes.

- **Model Evaluation**: Evaluate model experiments on standardized benchmark datasets and record performance
  metrics. Dataset versioning ensures fair comparison across model versions and training iterations.

**Design Rationale**: Separating standalone and registered entities enables a two-stage workflow balancing flexibility
with data governance. Standalone extraction allows data scientists to experiment rapidly, while registration enforces
quality gates and maintains a canonical catalog. Immutable snapshots (rather than in-place updates) provide complete
audit trails and enable exact reproduction of experiments and deployments.

The diagram below illustrates the lifecycle and interactions between these processes and data entities:

```mermaid
flowchart TD
    classDef Entity fill: #16A085, stroke-width: 0
    classDef Process fill: #2980B9, stroke-width: 0
    classDef Manual fill: #F1C40F, stroke-width: 0, color: #000000
    Entity:BagSnippet([Bag Snippet]):::Entity
    Entity:StandaloneDatasetSample([Standalone Dataset & Sample]):::Entity
    Entity:RegisteredDatasetSample([Registered Dataset & Sample]):::Entity
    Entity:SampleClassifier([Sample Classifier]):::Entity
    Entity:SampleAnnotation([Sample Annotation]):::Entity
    Entity:ModelExperiment([Model Experiment]):::Entity
    Entity:ModelAssessment([Model Assessment]):::Entity
    Process:SampleMining[Sample Mining]:::Process
    Process:DatasetRegistration[Dataset Registration]:::Process
    Process:DatasetSelection[Dataset Selection]:::Process
    Process:ClassifierLabeling[Classifier Labeling]:::Process
    Process:AnnotationLabeling[Annotation Labeling]:::Process
    Process:ModelTraining[Model Training]:::Process
    Process:ModelEvaluation[Model Evaluation]:::Process
    Manual:AnnotationLabeling[Manual Annotating]:::Manual
    Entity:BagSnippet --> Process:SampleMining
    Process:DatasetSelection --> Process:DatasetRegistration
    Entity:StandaloneDatasetSample --> Process:DatasetRegistration
    Entity:RegisteredDatasetSample --> Process:ClassifierLabeling
    Entity:BagSnippet --> Process:ClassifierLabeling
    Entity:RegisteredDatasetSample --> Process:AnnotationLabeling
    Entity:SampleClassifier --> Process:DatasetSelection
    Entity:RegisteredDatasetSample --> Process:DatasetSelection
    Entity:SampleAnnotation --> Process:ModelTraining
    Entity:RegisteredDatasetSample --> Process:ModelTraining
    Entity:SampleClassifier --> Process:ModelTraining
    Entity:RegisteredDatasetSample --> Process:ModelEvaluation
    Entity:SampleAnnotation --> Process:ModelEvaluation
    Entity:ModelExperiment --> Process:ModelEvaluation
    Process:SampleMining --> Entity:StandaloneDatasetSample
    Process:DatasetRegistration --> Entity:RegisteredDatasetSample
    Process:ClassifierLabeling <--> Entity:SampleClassifier
    Process:SampleMining <--> Entity:SampleClassifier
    Process:AnnotationLabeling --> Entity:SampleAnnotation
    Process:ModelTraining <--> Entity:ModelExperiment
    Process:ModelEvaluation --> Entity:ModelAssessment
    Entity:SampleAnnotation <-->|Manual annotation| Manual:AnnotationLabeling
```

The system manages various data entities related to samples, datasets, models, and their associated metadata. The
primary data entities are:

- **Bag Snippet**: A time-bounded segment extracted from a ROS bag file, containing raw sensor data.
- **Standalone Sample and Dataset**: Samples and datasets stored locally before central registration. These include
  media files organized according to predefined layouts and accompanying metadata files.
- **Registered Sample and Dataset**: Samples and datasets registered in the central catalog with verified metadata
  and media files stored in durable storage, ready for model training and evaluation.
- **Sample Classifier**: Lightweight tags or categorical labels associated with a sample (e.g., scenario type, weather
  conditions).
- **Sample Annotation**: Detailed structured annotations associated with a sample (e.g., bounding boxes, semantic
  segmentation masks).
- **Model Experiment**: An instance of model training or fine-tuning using specific datasets, classifiers, and
  annotations, resulting in a trained model artifact.
- **Model Assessment**: An instance of model evaluation, recording performance metrics on benchmark datasets.

The relationships between these entities are illustrated in the following Entity-Relationship (ER) diagram:

```mermaid
erDiagram
    BagSnippet {
        string bag_name "name of the bag file or the bag file where the snippet is extracted from"
        string vehicle_name "vehicle name associated with the snippet"
        timestamp begin_frame_dt "start timestamp of the snippet"
        timestamp end_frame_dt "end timestamp of the snippet"
    }

    StandaloneSample {
        string path "relative path to the sample file within the dataset directory"
        string layout "layout of the sample media files, e.g., 'single_camera/frame', 'bev_perception/sequence', etc."
        string bag_name "name of the bag file where the sample is extracted from"
        string vehicle_name "vehicle name associated with the sample"
        timestamp begin_frame_dt "start timestamp of the sample"
        timestamp end_frame_dt "end timestamp of the sample"
        array[string] tags "tags associated with the sample"
        json props "additional properties of the sample"
    }

    StandaloneDataset {
        string name "name of the dataset"
        string description "description of the dataset"
        string contributor "email address of the contributor"
        array[string] tags "tags associated with the dataset"
        json props "additional properties of the dataset"
    }

    SampleLayout {
        string uuid "uuid of the sample layout"
        string name "name of the sample layout, e.g., 'single_camera/frame', 'bev_perception/sequence', etc."
        string description "description of the sample layout"
        array[string] child_layouts "list of sub-sample layouts if this is a compound layout"
        json layout_spec "specification of the media file structure and organization for this layout"
        json props "additional properties of the sample layout"
    }

    RegisteredSample {
        string uuid "uuid of the sample"
        string path "relative path to the sample file within the sample repository root"
        string layout_uuid "layout of the sample media files, e.g., 'single_camera/frame', 'bev_perception/sequence', etc."
        string bag_name "name of the bag file where the sample is extracted from"
        string vehicle_name "vehicle name associated with the sample"
        timestamp begin_frame_dt "start timestamp of the sample"
        timestamp end_frame_dt "end timestamp of the sample"
        array[string] subsample_uuids "list of uuids of sub-samples if this is a compound sample"
        array[string] tags "tags associated with the sample"
        json props "additional properties of the sample"
    }

    RegisteredDataset {
        string uuid "uuid of the dataset"
        string name "name of the dataset"
        string description "description of the dataset"
        string contributor "email address of the contributor"
        array[string] tags "tags associated with the dataset"
        json props "additional properties of the dataset"
    }

    RegisteredDatasetSample {
        string dataset_uuid "uuid of the dataset"
        string sample_uuid "uuid of the sample"
        string annotation_uuid "uuid of the annotation associated with the sample in this dataset, if any"
    }

    ClassifierTaxonomy {
        string uuid "uuid of the classifier taxonomy"
        string name "name of the classifier taxonomy"
        string version "version of the classifier taxonomy"
        string description "description of the classifier taxonomy"
        json taxonomy_hierarchy "hierarchical structure defining the classifier categories and relationships"
        json props "additional properties of the classifier taxonomy"
    }

    SampleClassifier {
        string uuid "uuid of the classifier"
        string sample_uuid "uuid of the associated sample"
        json classifier_data "classifier data"
    }

    AnnotationGuideline {
        string uuid "uuid of the annotation guideline"
        string name "name of the annotation guideline"
        string version "version of the annotation guideline"
        string description "description of the annotation guideline"
        string[] supported_layouts "list of sample layouts supported by this guideline"
        json annotation_schema "JSON schema defining the structure of annotations under this guideline"
        json props "additional properties of the annotation guideline"
    }

    SampleAnnotation {
        string uuid "uuid of the annotation"
        string sample_uuid "uuid of the associated sample"
        string guideline_uuid "uuid of the annotation guideline used"
        json annotation_data "annotation data"
    }

    ModelArchitecture {
        string uuid "uuid of the model architecture"
        string name "name of the model architecture"
        string description "description of the model architecture"
        array[string] supported_guidelines "list of annotation guidelines supported by this architecture"
        json architecture_spec "specification of the model architecture (e.g., layers, parameters)"
        json props "additional properties of the model architecture"
    }

    ModelExperiment {
        string uuid "uuid of the model experiment"
        string path "relative path to the model resource directory within the model repository root"
        string architecture_uuid "uuid of the model architecture"
        string parent_uuid "uuid of the parent model experiment, if any"
        string dataset_uuid "uuid of the incremental dataset used for training, if any"
        string name "name of the model experiment"
        string description "description of the model experiment"
        string contributor "email address of the contributor"
        string path "relative path to the model experiment artifact directory"
        string checkpoint_path "relative path to the model checkpoint file within the artifact directory"
        array[string] tags "tags associated with the model experiment"
        json props "additional properties of the model experiment"
    }

    ModelBenchmark {
        string uuid "uuid of the model benchmark"
        string name "name of the model benchmark"
        string version "version of the model benchmark"
        string description "description of the model benchmark"
        array[string] supported_architectures "list of model architectures supported by this model benchmark"
        json benchmark_schema "JSON schema defining the structure of benchmark data"
        json props "additional properties of the model benchmark"
    }

    ModelAssessment {
        string uuid "uuid of the model assessment"
        string benchmark_uuid "uuid of the model benchmark"
        string experiment_uuid "uuid of the model experiment being evaluated"
        string dataset_uuid "uuid of the evaluation dataset"
        string name "name of the model assessment"
        string description "description of the model assessment"
        string contributor "email address of the contributor"
        string path "relative path to the model assessment artifact directory"
        json assessment_data "assessment data"
        array[string] tags "tags associated with the model assessment"
        json props "additional properties of the model assessment"
    }

    BagSnippet |o--o{ StandaloneSample: extracts
    BagSnippet |o--o{ RegisteredSample: extracts
    SampleLayout ||--o{ StandaloneSample: defines
    SampleLayout ||--o{ RegisteredSample: defines
    SampleLayout ||--o{ AnnotationGuideline: supports
    StandaloneSample ||--|| RegisteredSample: registers
    StandaloneDataset ||--|| RegisteredDataset: registers
    StandaloneDataset ||--o{ StandaloneSample: contains
    RegisteredDataset ||--o{ RegisteredDatasetSample: contains
    RegisteredDatasetSample ||--|| RegisteredSample: references
    RegisteredSample ||--o{ RegisteredSample: composes
    RegisteredSample ||--o{ SampleClassifier: has
    RegisteredSample ||--o{ SampleAnnotation: has
    ClassifierTaxonomy ||--o{ SampleClassifier: defines
    AnnotationGuideline ||--o{ SampleAnnotation: defines
    AnnotationGuideline ||--o{ ModelArchitecture: supports
    RegisteredDatasetSample ||--|| SampleAnnotation: references
    ModelArchitecture ||--o{ ModelExperiment: defines
    ModelExperiment ||--o{ ModelExperiment: derived_from
    ModelExperiment ||--|| RegisteredDataset: trained_on
    ModelExperiment ||--o{ ModelAssessment: has
    ModelBenchmark ||--o{ ModelAssessment: defines
    ModelBenchmark ||--o{ ModelArchitecture: supports
```

### Samples: Layout

Sample layouts define how media files are structured and organized within a sample. Each layout specifies the required
media file types, their paths, and the associated metadata structure. This design enables automated validation,
simplifies tooling development, and ensures consistency across the data pipeline.

**Supported Layouts**:

| Layout Name               | Is Compound | Sub-sample Layout      | Description                                                                    |
|---------------------------|-------------|------------------------|--------------------------------------------------------------------------------|
| `stereo_camera/frame`     | No          | N/A                    | Synchronized stereo image pair (left/right) captured at a single timestamp     |
| `stereo_camera/sequence`  | Yes         | `stereo_camera/frame`  | Ordered sequence of stereo image frames (perception time window)               |
| `single_camera/frame`     | No          | N/A                    | Single-camera (mono) image captured at a single timestamp                      |
| `single_camera/sequence`  | Yes         | `single_camera/frame`  | Ordered sequence of mono image frames                                          |
| `single_camera/video`     | No          | N/A                    | Mono video stream                                                              |
| `unified_camera/frame`    | No          | N/A                    | Multi-camera set normalized to a unified naming/format for one timestamp       |
| `unified_camera/sequence` | Yes         | `unified_camera/frame` | Ordered sequence of unified multi-camera frames                                |
| `unified_camera/video`    | No          | N/A                    | Synchronized multi-camera video streams in unified format                      |
| `single_lidar/frame`      | No          | N/A                    | Single LiDAR sweep / point cloud captured at a single timestamp                |
| `single_lidar/sequence`   | Yes         | `single_lidar/frame`   | Time-ordered sequence of LiDAR sweeps                                          |
| `single_lidar/scenario`   | No          | N/A                    | LiDAR data covering a scenario (long-duration segment composed of many sweeps) |
| `unified_lidar/frame`     | No          | N/A                    | Fused or standardized LiDAR frame in a unified coordinate system               |
| `unified_lidar/sequence`  | Yes         | `unified_lidar/frame`  | Ordered sequence of unified LiDAR frames                                       |
| `unified_lidar/scenario`  | No          | N/A                    | Scenario-level unified LiDAR collection (ordered segments / episodes)          |
| `bev_perception/frame`    | No          | N/A                    | BEV (bird's-eye-view) frame used for perception                                |
| `bev_perception/sequence` | Yes         | `bev_perception/frame` | Sequence of BEV (bird's-eye-view) frames used for perception/tracking          |

The sample layout name is specified in the `layout` field of `StandaloneSample` and `RegisteredSample`. The `path`
field indicates the relative path to the sample directory within the dataset root directory. Layout definitions are
stored in configuration files (JSON or YAML) and can be extended to include new layouts as needed. Each layout
definition specifies the expected media file types and their paths.

Layouts validate sample completeness during registration, ensuring all required media files are present according to
the specified layout. This also guides sample processing and analysis, as different layouts may require different
handling. Data integrity checks based on the layout verify the presence and format of all expected files, ensuring
samples are consistent and usable for downstream tasks like model training and evaluation. For layouts with fixed-name
files, SFV (Simple File Verification) manifests can be generated with checksums for each media file, ensuring files
remain intact and unaltered.

#### Media Directory Structure

The following table specifies the media files and their paths for each layout:

| Layout Name               | Media File                                                         | Description                                                |
|---------------------------|--------------------------------------------------------------------|------------------------------------------------------------|
| All layouts               | `{sample_root_dir}/metadata.json`                                  | Sample metadata in JSON format                             |
| `stereo_camera/frame`     | `{sample_root_dir}/left_camera_image.png`                          | Left camera image captured at a single timestamp           |
|                           | `{sample_root_dir}/right_camera_image.png`                         | Right camera image captured at a single timestamp          |
| `stereo_camera/sequence`  | `{sample_root_dir}/{frame_timestamp}/left_camera_image.png`        | Left camera image for each frame in the sequence           |
|                           | `{sample_root_dir}/{frame_timestamp}/right_camera_image.png`       | Right camera image for each frame in the sequence          |
| `single_camera/frame`     | `{sample_root_dir}/camera_image.png`                               | Mono camera image captured at a single timestamp           |
| `single_camera/sequence`  | `{sample_root_dir}/{frame_timestamp}/camera_image.png`             | Mono camera image for each frame in the sequence           |
| `single_camera/video`     | `{sample_root_dir}/camera_video.mp4`                               | Mono video stream                                          |
| `unified_camera/frame`    | `{sample_root_dir}/unified_camera_image.png`                       | Multi-camera images normalized to a unified naming/format  |
| `unified_camera/sequence` | `{sample_root_dir}/{frame_timestamp}/unified_camera_image.png`     | Unified multi-camera images for each frame in the sequence |
| `unified_camera/video`    | `{sample_root_dir}/unified_camera_video.mp4`                       | Synchronized multi-camera video streams in unified format  |
| `single_lidar/frame`      | `{sample_root_dir}/lidar_points.pcd`                               | LiDAR point cloud captured at a single timestamp           |
| `single_lidar/sequence`   | `{sample_root_dir}/{frame_timestamp}/lidar_points.pcd`             | LiDAR point cloud for each frame in the sequence           |
| `single_lidar/scenario`   | `{sample_root_dir}/scenario_lidar_points.pcd`                      | LiDAR data covering a scenario                             |
| `unified_lidar/frame`     | `{sample_root_dir}/unified_lidar_points.pcd`                       | Fused or standardized LiDAR frame                          |
| `unified_lidar/sequence`  | `{sample_root_dir}/{frame_timestamp}/unified_lidar_points.pcd`     | Unified LiDAR point cloud for each frame in the sequence   |
| `unified_lidar/scenario`  | `{sample_root_dir}/scenario_unified_lidar_points.pcd`              | Scenario-level unified LiDAR collection                    |
| `bev_perception/frame`    | `{sample_root_dir}/front_left_camera_image.png`                    | Front left camera image captured at a single timestamp     |
|                           | `{sample_root_dir}/front_right_camera_image.png`                   | Front right camera image captured at a single timestamp    |
|                           | `{sample_root_dir}/side_left_camera_image.png`                     | Side left camera image captured at a single timestamp      |
|                           | `{sample_root_dir}/side_right_camera_image.png`                    | Side right camera image captured at a single timestamp     |
|                           | `{sample_root_dir}/rear_left_camera_image.png`                     | Rear left camera image captured at a single timestamp      |
|                           | `{sample_root_dir}/rear_right_camera_image.png`                    | Rear right camera image captured at a single timestamp     |
|                           | `{sample_root_dir}/long_range_camera_image.png`                    | Long range camera image captured at a single timestamp     |
|                           | `{sample_root_dir}/unified_lidar_points.pcd`                       | LiDAR point cloud captured at a single timestamp           |
| `bev_perception/sequence` | `{sample_root_dir}/{frame_timestamp}/front_left_camera_image.png`  | Front left camera image for each frame in the sequence     |
|                           | `{sample_root_dir}/{frame_timestamp}/front_right_camera_image.png` | Front right camera image for each frame in the sequence    |
|                           | `{sample_root_dir}/{frame_timestamp}/side_left_camera_image.png`   | Side left camera image for each frame in the sequence      |
|                           | `{sample_root_dir}/{frame_timestamp}/side_right_camera_image.png`  | Side right camera image for each frame in the sequence     |
|                           | `{sample_root_dir}/{frame_timestamp}/rear_left_camera_image.png`   | Rear left camera image for each frame in the sequence      |
|                           | `{sample_root_dir}/{frame_timestamp}/rear_right_camera_image.png`  | Rear right camera image for each frame in the sequence     |
|                           | `{sample_root_dir}/{frame_timestamp}/long_range_camera_image.png`  | Long range camera image for each frame in the sequence     |
|                           | `{sample_root_dir}/{frame_timestamp}/unified_lidar_points.pcd`     | LiDAR point cloud for each frame in the sequence           |

**Design Rationale**:

- **Explicit layouts** enable deterministic validation during registration, catching data quality issues early in the
  pipeline.
- **Fixed file naming conventions** simplify loader implementations and make datasets more portable across different
  processing frameworks.
- **Timestamped subdirectories** for sequence layouts provide natural chronological ordering and human-readable
  organization.
- **Self-contained metadata** (metadata.json per sample) makes each sample a portable unit that can be validated,
  transferred, or processed independently.

The layout system is extensible—new layouts can be added via configuration files without code changes. Each layout
definition specifies expected file types, naming patterns, and validation rules.

Timestamped directories (`{frame_timestamp}`) use ISO 8601 basic format with microsecond precision (e.g.,
`20250101T000000.000000Z`) to ensure uniqueness, chronological ordering, and human readability. Example directory
structures for various layouts are shown below:

```
# stereo_camera/frame
{sample_root_dir}/
├── metadata.json
├── left_camera_image.png
└── right_camera_image.png

# stereo_camera/sequence
{sample_root_dir}/
├── metadata.json
└── {frame_timestamp}/
    ├── metadata.json
    ├── left_camera_image.png
    └── right_camera_image.png

# single_camera/frame
{sample_root_dir}/
├── metadata.json
└── camera_image.png

# single_camera/sequence
{sample_root_dir}/
├── metadata.json
└── {frame_timestamp}/
    ├── metadata.json
    └── camera_image.png

# single_camera/video
{sample_root_dir}/
├── metadata.json
└── camera_video.mp4

# unified_camera/frame
{sample_root_dir}/
├── metadata.json
└── unified_camera_image.png

# unified_camera/sequence
{sample_root_dir}/
├── metadata.json
└── {frame_timestamp}/
    ├── metadata.json
    └── unified_camera_image.png

# unified_camera/video
{sample_root_dir}/
├── metadata.json
└── unified_camera_video.mp4

# single_lidar/frame
{sample_root_dir}/
├── metadata.json
└── lidar_points.pcd

# single_lidar/sequence
{sample_root_dir}/
├── metadata.json
└── {frame_timestamp}/
    ├── metadata.json
    └── lidar_points.pcd

# single_lidar/scenario
{sample_root_dir}/
├── metadata.json
└── scenario_lidar_points.pcd

# unified_lidar/frame
{sample_root_dir}/
├── metadata.json
└── unified_lidar_points.pcd

# unified_lidar/sequence
{sample_root_dir}/
├── metadata.json
└── {frame_timestamp}/
    ├── metadata.json
    └── unified_lidar_points.pcd

# unified_lidar/scenario
{sample_root_dir}/
├── metadata.json
└── scenario_unified_lidar_points.pcd

# bev_perception/frame
{sample_root_dir}/
├── metadata.json
├── front_left_camera_image.png
├── front_right_camera_image.png
├── side_left_camera_image.png
├── side_right_camera_image.png
├── rear_left_camera_image.png
├── rear_right_camera_image.png
├── long_range_camera_image.png
└── lidar_points.pcd

# bev_perception/sequence
{sample_root_dir}/
├── metadata.json
└── {frame_timestamp}/
    ├── front_left_camera_image.png
    ├── front_right_camera_image.png
    ├── side_left_camera_image.png
    ├── side_right_camera_image.png
    ├── rear_left_camera_image.png
    ├── rear_right_camera_image.png
    ├── long_range_camera_image.png
    └── lidar_points.pcd
```

**Data Integrity**: Each `metadata.json` file includes a `media_files` array with checksums (MD5 or SHA256) for every
media file, enabling:

- Fast verification after file transfers or storage operations
- Detection of corrupted or modified files
- Generation of Simple File Verification (SFV) manifests for datasets with fixed-name files

For layouts with predictable file structures, the system generates comprehensive checksums during sample creation,
providing end-to-end integrity guarantees.

#### Metadata File

Each sample directory includes a `metadata.json` file with structured information about the sample: sensor
configurations, vehicle pose, calibration parameters, and data quality indicators. The JSON format simplifies parsing
and integration with data processing pipelines.

**Common Metadata Fields**:

| Layout Name               | Fields (JSON Path)                                        | Data Type | Description                                                       |
|---------------------------|-----------------------------------------------------------|-----------|-------------------------------------------------------------------|
| All layouts               | `$.layout`                                                | string    | Layout of the sample media files (e.g., 'bev_perception')         |
|                           | `$.begin_frame_dt`                                        | string    | Start timestamp of the sample                                     |
|                           | `$.end_frame_dt`                                          | string    | End timestamp of the sample                                       |
|                           | `$.vehicle_name`                                          | string    | Vehicle name associated with the sample                           |
|                           | `$.media_files`                                           | array     | List of media files included in the sample                        |
|                           | `$.media_files[].path`                                    | string    | Relative path to the media file within the sample directory       |
|                           | `$.media_files[].checksum`                                | string    | Checksum (e.g., MD5) of the media file for integrity verification |
|                           | `$.props`                                                 | object    | Additional features or properties of the sample                   |
| `stereo_camera/frame`     | `$.props.timestamp`                                       | string    | Timestamp of the frame                                            |
|                           | `$.props.coordinate`                                      | object    | Vehicle pose (position and orientation) at the frame timestamp    |
|                           | `$.props.topic.left_camera`                               | string    | ROS topic name for the left camera                                |
|                           | `$.props.topic.right_camera`                              | string    | ROS topic name for the right camera                               |
|                           | `$.props.cameras.calibration.left_camera`                 | object    | Intrinsic parameters of the left camera                           |
|                           | `$.props.cameras.calibration.right_camera`                | object    | Intrinsic parameters of the right camera                          |
| `stereo_camera/sequence`  | `$.props.frames`                                          | array     | List of frames with timestamps and camera calibration             |
|                           | `$.props.frames[].timestamp`                              | string    | Timestamp of each frame                                           |
|                           | `$.props.frames[].coordinate`                             | object    | Vehicle pose (position and orientation) at each frame             |
|                           | `$.props.frames[].topic.left_camera`                      | string    | ROS topic name for the left camera                                |
|                           | `$.props.frames[].topic.right_camera`                     | string    | ROS topic name for the right camera                               |
|                           | `$.props.frames[].cameras.calibration.left_camera`        | object    | Intrinsic parameters of the left camera                           |
|                           | `$.props.frames[].cameras.calibration.right_camera`       | object    | Intrinsic parameters of the right camera                          |
| `single_camera/frame`     | `$.props.timestamp`                                       | string    | Timestamp of the frame                                            |
|                           | `$.props.coordinate`                                      | object    | Vehicle pose (position and orientation) at the frame timestamp    |
|                           | `$.props.topic.camera`                                    | string    | ROS topic name for the mono camera                                |
|                           | `$.props.cameras.calibration.camera`                      | object    | Intrinsic parameters of the mono camera                           |
| `single_camera/sequence`  | `$.props.frames`                                          | array     | List of frames with timestamps and camera calibration             |
|                           | `$.props.frames[].timestamp`                              | string    | Timestamp of each frame                                           |
|                           | `$.props.frames[].coordinate`                             | object    | Vehicle pose (position and orientation) at each frame             |
|                           | `$.props.frames[].topic.camera`                           | string    | ROS topic name for the mono camera                                |
|                           | `$.props.frames[].cameras.calibration.camera`             | object    | Intrinsic parameters of the mono camera                           |
| `unified_camera/frame`    | `$.props.timestamp`                                       | string    | Timestamp of the frame                                            |
|                           | `$.props.coordinate`                                      | object    | Vehicle pose (position and orientation) at the frame timestamp    |
|                           | `$.props.topic.unified_camera`                            | string    | ROS topic name for the unified camera                             |
|                           | `$.props.cameras.calibration.unified_camera`              | object    | Intrinsic parameters of the unified camera                        |
| `unified_camera/sequence` | `$.props.frames`                                          | array     | List of frames with timestamps and unified images                 |
|                           | `$.props.frames[].timestamp`                              | string    | Timestamp of each frame                                           |
|                           | `$.props.frames[].coordinate`                             | object    | Vehicle pose (position and orientation) at each frame             |
|                           | `$.props.frames[].topic.unified_camera`                   | string    | ROS topic name for the unified camera                             |
|                           | `$.props.frames[].cameras.calibration.unified_camera`     | object    | Intrinsic parameters of the unified camera                        |
| `single_lidar/frame`      | `$.props.timestamp`                                       | string    | Timestamp of the frame                                            |
|                           | `$.props.coordinate`                                      | object    | Vehicle pose (position and orientation) at the frame timestamp    |
|                           | `$.props.topic.lidar`                                     | string    | ROS topic name for the LiDAR sensor                               |
|                           | `$.props.lidars.calibration.lidar`                        | object    | Calibration parameters of the LiDAR sensor                        |
| `single_lidar/sequence`   | `$.props.frames`                                          | array     | List of frames with timestamps and LiDAR data                     |
|                           | `$.props.frames[].timestamp`                              | string    | Timestamp of each frame                                           |
|                           | `$.props.frames[].coordinate`                             | object    | Vehicle pose (position and orientation) at each frame             |
|                           | `$.props.frames[].topic.lidar`                            | string    | ROS topic name for the LiDAR sensor                               |
|                           | `$.props.frames[].lidars.calibration.lidar`               | object    | Calibration parameters of the LiDAR sensor                        |
| `single_lidar/scenario`   | `$.props.timestamp`                                       | string    | Timestamp of the scenario                                         |
|                           | `$.props.coordinate`                                      | object    | Vehicle pose (position and orientation) at the scenario timestamp |
|                           | `$.props.topic.lidar`                                     | string    | ROS topic name for the LiDAR sensor                               |
|                           | `$.props.lidars.calibration.lidar`                        | object    | Calibration parameters of the LiDAR sensor                        |
| `unified_lidar/frame`     | `$.props.timestamp`                                       | string    | Timestamp of the frame                                            |
|                           | `$.props.coordinate`                                      | object    | Vehicle pose (position and orientation) at the frame timestamp    |
|                           | `$.props.topic.unified_lidar`                             | string    | ROS topic name for the unified LiDAR sensor                       |
|                           | `$.props.lidars.calibration.unified_lidar`                | object    | Calibration parameters of the LiDAR sensor                        |
| `unified_lidar/sequence`  | `$.props.frames`                                          | array     | List of frames with timestamps and unified LiDAR data             |
|                           | `$.props.frames[].timestamp`                              | string    | Timestamp of each frame                                           |
|                           | `$.props.frames[].coordinate`                             | object    | Vehicle pose (position and orientation) at each frame             |
|                           | `$.props.frames[].topic.unified_lidar`                    | string    | ROS topic name for the unified LiDAR sensor                       |
|                           | `$.props.frames[].lidars.calibration.unified_lidar`       | object    | Calibration parameters of the LiDAR sensor                        |
| `unified_lidar/scenario`  | `$.props.timestamp`                                       | string    | Timestamp of the scenario                                         |
|                           | `$.props.coordinate`                                      | object    | Vehicle pose (position and orientation) at the scenario timestamp |
|                           | `$.props.topic.unified_lidar`                             | string    | ROS topic name for the unified LiDAR sensor                       |
|                           | `$.props.lidars.calibration.unified_lidar`                | object    | Calibration parameters of the LiDAR sensor                        |
| `bev_perception/frame`    | `$.props.timestamp`                                       | string    | Timestamp of the frame                                            |
|                           | `$.props.coordinate`                                      | object    | Vehicle pose (position and orientation) at the frame timestamp    |
|                           | `$.props.topic.front_left_camera`                         | string    | ROS topic name for the front left camera                          |
|                           | `$.props.topic.front_right_camera`                        | string    | ROS topic name for the front right camera                         |
|                           | `$.props.topic.side_left_camera`                          | string    | ROS topic name for the side left camera                           |
|                           | `$.props.topic.side_right_camera`                         | string    | ROS topic name for the side right camera                          |
|                           | `$.props.topic.rear_left_camera`                          | string    | ROS topic name for the rear left camera                           |
|                           | `$.props.topic.rear_right_camera`                         | string    | ROS topic name for the rear right camera                          |
|                           | `$.props.topic.long_range_camera`                         | string    | ROS topic name for the long range camera                          |
|                           | `$.props.topic.unified_lidar`                             | string    | ROS topic name for the unified LiDAR sensor                       |
|                           | `$.props.cameras.calibration.front_left_camera`           | object    | Calibration parameters of the front left camera                   |
|                           | `$.props.cameras.calibration.front_right_camera`          | object    | Calibration parameters of the front right camera                  |
|                           | `$.props.cameras.calibration.side_left_camera`            | object    | Calibration parameters of the side left camera                    |
|                           | `$.props.cameras.calibration.side_right_camera`           | object    | Calibration parameters of the side right camera                   |
|                           | `$.props.cameras.calibration.rear_left_camera`            | object    | Calibration parameters of the rear left camera                    |
|                           | `$.props.cameras.calibration.rear_right_camera`           | object    | Calibration parameters of the rear right camera                   |
|                           | `$.props.cameras.calibration.long_range_camera`           | object    | Calibration parameters of the long range camera                   |
|                           | `$.props.lidars.calibration.unified_lidar`                | object    | Calibration parameters of the LiDAR sensor                        |
| `bev_perception/sequence` | `$.props.frames`                                          | array     | List of frames with timestamps and sensor data                    |
|                           | `$.props.frames[].timestamp`                              | string    | Timestamp of each frame                                           |
|                           | `$.props.frames[].coordinate`                             | object    | Vehicle pose (position and orientation) at each frame             |
|                           | `$.props.frames[].topic.front_left_camera`                | string    | ROS topic name for the front left camera                          |
|                           | `$.props.frames[].topic.front_right_camera`               | string    | ROS topic name for the front right camera                         |
|                           | `$.props.frames[].topic.side_left_camera`                 | string    | ROS topic name for the side left camera                           |
|                           | `$.props.frames[].topic.side_right_camera`                | string    | ROS topic name for the side right camera                          |
|                           | `$.props.frames[].topic.rear_left_camera`                 | string    | ROS topic name for the rear left camera                           |
|                           | `$.props.frames[].topic.rear_right_camera`                | string    | ROS topic name for the rear right camera                          |
|                           | `$.props.frames[].topic.long_range_camera`                | string    | ROS topic name for the long range camera                          |
|                           | `$.props.frames[].topic.unified_lidar`                    | string    | ROS topic name for the unified LiDAR sensor                       |
|                           | `$.props.frames[].cameras.calibration.front_left_camera`  | object    | Calibration parameters of the front left camera                   |
|                           | `$.props.frames[].cameras.calibration.front_right_camera` | object    | Calibration parameters of the front right camera                  |
|                           | `$.props.frames[].cameras.calibration.side_left_camera`   | object    | Calibration parameters of the side left camera                    |
|                           | `$.props.frames[].cameras.calibration.side_right_camera`  | object    | Calibration parameters of the side right camera                   |
|                           | `$.props.frames[].cameras.calibration.rear_left_camera`   | object    | Calibration parameters of the rear left camera                    |
|                           | `$.props.frames[].cameras.calibration.rear_right_camera`  | object    | Calibration parameters of the rear right camera                   |
|                           | `$.props.frames[].cameras.calibration.long_range_camera`  | object    | Calibration parameters of the long range camera                   |
|                           | `$.props.frames[].lidars.calibration.unified_lidar`       | object    | Calibration parameters of the LiDAR sensor                        |

**Design Rationale**:

- **ISO 8601 timestamps** with UTC timezone ensure unambiguous temporal ordering across different systems and geographic
  locations.
- **Sensor calibration in metadata** enables downstream algorithms to use the data without external calibration lookups,
  making samples truly self-contained.
- **Vehicle pose information** supports spatiotemporal queries and enables reconstruction of vehicle trajectories.
- **Extensible `props` field** accommodates layout-specific and application-specific metadata without schema changes.

The following JSON snippets show example metadata files for samples with different layouts:

```json5
{
  "layout": "stereo_camera/frame",
  "begin_frame_dt": "2025-01-01T00:00:00.000000Z",
  "end_frame_dt": "2025-01-01T00:00:00.000000Z",
  "vehicle_name": "vehicle_001",
  "media_files": [
    {
      "path": "left_camera_image.png",
      "checksum": "5d41402abc4b2a76b9719d911017c592"
    },
    {
      "path": "right_camera_image.png",
      "checksum": "7d793037a0760186574bc2e6f1f3c3a3"
    }
  ],
  "props": {
    "timestamp": "2025-01-01T00:00:00.000000Z",
    "coordinate": {
      "position": {
        "x": 1.0,
        "y": 2.0,
        "z": 3.0
      },
      "orientation": {
        "roll": 0.0,
        "pitch": 0.0,
        "yaw": 1.57
      }
    },
    "topic": {
      "left_camera": "/sensors/front_left_camera/image_raw",
      "right_camera": "/sensors/front_right_camera/image_raw"
    },
    "cameras": {
      "calibration": {
        "left_camera": {
          /** Calibration parameters for the left camera */
        },
        "right_camera": {
          /** Calibration parameters for the right camera */
        }
      }
    }
  }
}
```

```json5
{
  "layout": "bev_perception/sequence",
  "begin_frame_dt": "2025-01-01T00:00:00.000000Z",
  "end_frame_dt": "2025-01-01T00:00:10.000000Z",
  "vehicle_name": "vehicle_001",
  "media_files": [
    {
      "path": "20250101T000000.000000Z/front_left_camera_image.png",
      "checksum": "5d41402abc4b2a76b9719d911017c592"
    },
    {
      "path": "20250101T000000.000000Z/front_right_camera_image.png",
      "checksum": "7d793037a0760186574bc2e6f1f3c3a3"
    },
    {
      "path": "20250101T000000.000000Z/side_left_camera_image.png",
      "checksum": "9d5ed678fe57bcca610140957afab109"
    },
    {
      "path": "20250101T000000.000000Z/side_right_camera_image.png",
      "checksum": "3c59dc048e8850243be8079a5c74f12a"
    },
    {
      "path": "20250101T000000.000000Z/long_range_camera_image.png",
      "checksum": "1dc8bfe8f801d2e3f3f4e4e5e6f723be"
    },
    {
      "path": "20250101T000000.000000Z/lidar_points.pcd",
      "checksum": "4e07408562bedb8b60b1e5f3f6f78f90"
    }
  ],
  "props": {
    "frames": [
      {
        "timestamp": "2025-01-01T00:00:00.000000Z",
        "coordinate": {
          "position": {
            "x": 1.0,
            "y": 2.0,
            "z": 3.0
          },
          "orientation": {
            "roll": 0.0,
            "pitch": 0.0,
            "yaw": 1.57
          }
        },
        "topic": {
          "front_left_camera": "/sensors/front_left_camera/image_raw",
          "front_right_camera": "/sensors/front_right_camera/image_raw",
          "side_left_camera": "/sensors/side_left_camera/image_raw",
          "side_right_camera": "/sensors/side_right_camera/image_raw",
          "rear_left_camera": "/sensors/rear_left_camera/image_raw",
          "rear_right_camera": "/sensors/rear_right_camera/image_raw",
          "long_range_camera": "/sensors/long_range_camera/image_raw",
          "unified_lidar": "/sensors/unified_lidar/points"
        },
        "cameras": {
          "calibration": {
            "front_left_camera": {
              /* calibration parameters */
            },
            "front_right_camera": {
              /* calibration parameters */
            },
            "side_left_camera": {
              /* calibration parameters */
            },
            "side_right_camera": {
              /* calibration parameters */
            },
            "rear_left_camera": {
              /* calibration parameters */
            },
            "rear_right_camera": {
              /* calibration parameters */
            },
            "long_range_camera": {
              /* calibration parameters */
            }
          }
        },
        "lidars": {
          "calibration": {
            "unified_lidar": {
              /* calibration parameters */
            }
          }
        }
      }
    ]
  }
}
```

### Annotations: Guidelines

Annotations provide structured labels for samples, enabling supervised learning and evaluation. Each annotation links
to a specific sample and includes detailed labeling information. Annotations can be created manually or through
automated processes, supporting various label types such as bounding boxes, segmentation masks, and keypoints.
Annotations are stored as separate entities (`SampleAnnotation`) and reference their samples via UUIDs, enabling
flexible management including versioning and updates without modifying sample metadata.

Annotation guidelines, specified in the `guideline_name` and `guideline_version` fields of `SampleAnnotation` and
defined by `AnnotationGuideline`, provide clear schemas for annotations, ensuring consistency across datasets and
facilitating interoperability between tools and frameworks. Each guideline is bound to specific sample layouts, ensuring
annotations are compatible with the underlying data structure. Guideline changes may introduce new annotation types,
modify existing ones, or update labeling conventions; these changes are tracked via the `version` field in
`AnnotationGuideline` metadata. Common annotation guidelines include:

| Annotation Guideline             | Description                                                   |
|----------------------------------|---------------------------------------------------------------|
| `single_camera/obstacles`        | 2D bounding boxes for obstacles in camera images              |
| `single_camera/lanemarks`        | Lane marking annotations in camera images                     |
| `single_camera/traffic-signs`    | Traffic sign annotations in camera images                     |
| `single_camera/pedestrian-poses` | Keypoint annotations for pedestrian poses in camera images    |
| `single_camera/traffic-lights`   | Traffic light state annotations in camera images              |
| `single_lidar/obstacles`         | 3D bounding boxes for obstacles in LiDAR point clouds         |
| `single_lidar/segmentation`      | Point-wise semantic segmentation labels in LiDAR point clouds |
| `bev_perception/obstacles`       | BEV bounding boxes for obstacles in bird's-eye-view frames    |
| `bev_perception/lanemarks`       | Lane marking annotations in bird's-eye-view frames            |

The below JSON snippet shows an example annotation metadata file for a sample with the `single_lidar/obstacles`
guideline:

```json5
{
  "sample_uuid": "123e4567-e89b-12d3-a456-426614174000",
  "guideline_name": "single_lidar/obstacles",
  "guideline_version": "1.0.0",
  "value": [
    {
      "id": "label_001",
      "type": "3d_bounding_box",
      "category": "vehicle",
      "cuboid": {
        "dimensions": {
          "length": 4.5,
          "width": 2.0,
          "height": 1.5
        },
        "center": {
          "x": 10.0,
          "y": 5.0,
          "z": 0.0
        },
        "rotation": {
          "roll": 0.0,
          "pitch": 0.0,
          "yaw": 1.57
        }
      },
      "attributes": {
        "occluded": false,
        "truncated": false
      }
    }
  ]
}
```

The following JSON snippet shows an example annotation guideline metadata file for the `single_lidar/obstacles`
guideline:

```json5
{
  "name": "single_lidar/obstacles",
  "version": "1.0.0",
  "description": "Guideline for annotating 3D bounding boxes for obstacles in LiDAR point clouds.",
  "supported_layouts": [
    "single_lidar/frame"
  ],
  "schema": {
    "type": "object",
    "required": [
      "id",
      "type",
      "category",
      "cuboid",
      "attributes"
    ],
    "properties": {
      "id": {
        "type": "string",
        "description": "Label identifier"
      },
      "type": {
        "type": "string",
        "enum": [
          "3d_bounding_box"
        ]
      },
      "category": {
        "type": "string",
        "description": "Semantic category of the label (e.g., vehicle)"
      },
      "cuboid": {
        "type": "object",
        "required": [
          "dimensions",
          "center",
          "rotation"
        ],
        "properties": {
          "dimensions": {
            "type": "object",
            "required": [
              "length",
              "width",
              "height"
            ],
            "properties": {
              "length": {
                "type": "number"
              },
              "width": {
                "type": "number"
              },
              "height": {
                "type": "number"
              }
            },
            "additionalProperties": false
          },
          "center": {
            "type": "object",
            "required": [
              "x",
              "y",
              "z"
            ],
            "properties": {
              "x": {
                "type": "number"
              },
              "y": {
                "type": "number"
              },
              "z": {
                "type": "number"
              }
            },
            "additionalProperties": false
          },
          "rotation": {
            "type": "object",
            "required": [
              "roll",
              "pitch",
              "yaw"
            ],
            "properties": {
              "roll": {
                "type": "number"
              },
              "pitch": {
                "type": "number"
              },
              "yaw": {
                "type": "number"
              }
            },
            "additionalProperties": false
          }
        },
        "additionalProperties": false
      },
      "attributes": {
        "type": "object",
        "required": [
          "occluded",
          "truncated"
        ],
        "properties": {
          "occluded": {
            "type": "boolean"
          },
          "truncated": {
            "type": "boolean"
          }
        },
        "additionalProperties": false
      }
    },
    "additionalProperties": false
  }
}
```

### Dataset: Derivation

Datasets evolve as new samples are collected, labeling guidelines improve, or curation criteria change. Rather than
modifying existing datasets, the system creates new versions that reference their parent datasets. This immutable
versioning approach maintains a complete lineage of dataset evolution.

**Common Evolution Scenarios**:

- **Training vs. Registration**: Training datasets are typically subsets of larger registered datasets, selected by
  specific criteria (time range, sensor configuration, label distribution). Tracking derivation relationships clarifies
  training data composition.
- **Benchmark Evolution**: Benchmark datasets evolve as new data becomes available or annotation standards improve.
  Explicit tracking of changes enables meaningful comparison of evaluation metrics across benchmark versions.
- **Dataset Merging**: Multiple specialized datasets can be combined to create comprehensive training sets. The
  `derived_from` field captures these merge operations.

**Versioning Mechanism**:

The `props` field of `RegisteredDataset` captures versioning metadata:

- **`version`**: Semantic version string (e.g., "1.0.0", "1.2.0") for human-friendly identification.
- **`derived_from`**: Array of parent dataset UUIDs, supporting single-parent evolution and multi-parent merges,
  forming a directed acyclic graph (DAG) of dataset lineage.

**Design Rationale**:

- **Immutable experiment artifacts** ensure reproducible model training — every model experiment points to an exact
  dataset version and a fixed set of experiment artifacts (checkpoints) that cannot change.
- **Multi-parent derivation** supports complex curation workflows including merging, splitting, and augmentation.
- **Explicit versioning** makes dataset evolution visible and auditable, eliminating confusion about which data was
  used in specific experiments.

**Dataset Tagging**:

Datasets use a controlled tag taxonomy for organization and discovery:

- **Usage**: `usage:registration`, `usage:annotation`, `usage:training`, `usage:benchmarking`
- **Domain**: `domain:urban`, `domain:highway`, `domain:parking`
- **Weather**: `weather:sunny`, `weather:rainy`, `weather:snowy`
- **Campaign**: `campaign:2024_q1_east`, `campaign:2024_q2_west`
- **Sensor**: `sensor:lidar_camera_fusion`, `sensor:camera_only`
- **Quality**: `quality:high`, `quality:medium`, `quality:low`

Tags enable efficient filtering and discovery, while authoritative provenance is maintained in the `derived_from` field,
keeping tags lightweight and search-oriented.

Example dataset metadata:

```json5
{
  "description": "Enhanced urban training dataset with additional intersection scenarios.",
  "tags": [
    "usage:training",
    "sensor:lidar_camera_fusion",
    "campaign:2024_q1_east",
    "domain:urban",
    "weather:mixed"
  ],
  "props": {
    "version": "1.1.0",
    "derived_from": [
      "aef12345-6789-0abc-def1-234567890abc",
      "123def45-6789-0abc-def1-234567890def"
    ]
  }
}
```

**Lineage Visualization**:

The illustration below shows a typical dataset lineage for a BEV perception use case.

- Initial datasets are collected and registered, then annotated for training and benchmarking.
- Extended datasets are derived by adding more samples and improving annotations.
- Benchmark datasets evolve to reflect the latest data and annotation standards.
- Models are trained on successive dataset versions, with each model version building upon the previous one.
- The dataset for training the latter models explicitly excludes samples used in prior benchmarks to prevent data
  leakage.

```mermaid
flowchart LR
    classDef Dataset fill: #16A085, stroke-width: 0
    classDef Model fill: #2980B9, stroke-width: 0
    classDef Benchmark fill: #F1C40F, stroke-width: 0, color: #000000
    subgraph Dataset
        direction LR
        Dataset:RegisteredInit("ds:bev:init<br/>registration"):::Dataset
        Dataset:AnnotatedInit("ds:bev:init<br/>annotation"):::Dataset
        Dataset:TrainingInit("ds:bev:init<br/>training"):::Dataset
        Dataset:BenchmarkInit("ds:bev:init<br/>benchmark"):::Dataset
        Dataset:RegisteredExtend("ds:bev:extend<br/>registration"):::Dataset
        Dataset:AnnotatedExtend("ds:bev:extend<br/>annotation"):::Dataset
        Dataset:TrainingExtend("ds:bev:extend<br/>training"):::Dataset
        Dataset:BenchmarkExtend("ds:bev:extend<br/>benchmark"):::Dataset
        Dataset:AnnotatedExtendV2("ds:bev:extend-v2<br/>annotation"):::Dataset
        Dataset:TrainingExtendV2("ds:bev:extend-v2<br/>training"):::Dataset
        Dataset:BenchmarkExtendV2("ds:bev:extend-v2<br/>benchmark"):::Dataset
    end

    subgraph Models
        direction LR
        Model:V1("model:bev:v1"):::Model
        Model:V2("model:bev:v2"):::Model
        Model:V3("model:bev:v3"):::Model
    end

    subgraph Benchmark
        direction LR
        Benchmark:InitMetrics("benchmark:bev:init"):::Benchmark
        Benchmark:ExtendMetrics("benchmark:bev:extend"):::Benchmark
        Benchmark:ExtendV2Metrics("benchmark:bev:extend-v2"):::Benchmark
    end

    Dataset:RegisteredInit -->|annotate| Dataset:AnnotatedInit
    Dataset:AnnotatedInit --> Dataset:TrainingInit
    Dataset:AnnotatedInit --> Dataset:BenchmarkInit
    Dataset:RegisteredExtend -->|annotate| Dataset:AnnotatedExtend
    Dataset:AnnotatedExtend --> Dataset:TrainingExtend
    Dataset:AnnotatedExtend --> Dataset:BenchmarkExtend
    Dataset:RegisteredExtend -->|annotate| Dataset:AnnotatedExtendV2
    Dataset:AnnotatedExtendV2 --> Dataset:TrainingExtendV2
    Dataset:AnnotatedExtendV2 --> Dataset:BenchmarkExtendV2
    Dataset:AnnotatedInit -.->|exclude| Dataset:AnnotatedExtend
    Dataset:AnnotatedExtend -.->|exclude| Dataset:AnnotatedExtendV2
    Dataset:TrainingInit -...->|exclude| Dataset:BenchmarkInit
    Dataset:TrainingExtend -.->|exclude| Dataset:BenchmarkExtend
    Dataset:TrainingExtendV2 -.->|exclude| Dataset:BenchmarkExtendV2
    Dataset:BenchmarkInit --> Dataset:BenchmarkExtend
    Dataset:BenchmarkExtend --> Dataset:BenchmarkExtendV2
    Dataset:TrainingInit --> Model:V1
    Dataset:TrainingExtend --> Model:V2
    Dataset:TrainingExtendV2 --> Model:V3
    Model:V1 --> Model:V2
    Model:V2 --> Model:V3
    Model:V1 --> Benchmark:InitMetrics
    Model:V1 --> Benchmark:ExtendMetrics
    Model:V2 --> Benchmark:ExtendMetrics
    Model:V1 --> Benchmark:ExtendV2Metrics
    Model:V2 --> Benchmark:ExtendV2Metrics
    Model:V3 --> Benchmark:ExtendV2Metrics
```

### Model Experiments: Versioning

Model experiments capture trained model artifacts and the metadata necessary to reproduce training. Experiments commonly
produce multiple checkpoints across epochs; metadata SHOULD record all produced checkpoint artifacts and identify the
representative checkpoint (the one selected as best by validation metrics). Each experiment represents a specific point
in model development, enabling systematic performance tracking and facilitating deployment decisions.

**Versioning Structure**:

- **`parent_uuid`**: Reference to the immediate parent model experiment. Most model evolution follows linear progression
  (fine-tuning, hyperparameter adjustments), making single-parent tracking sufficient and easier to reason about than
  multi-parent graphs.

- **`dataset_uuid`**: Reference to the exact `RegisteredDataset` version used for training. This link is essential for
  reproducibility and enables systematic analysis of how dataset changes affect performance.

- **`props`**: Contains hyperparameters, training configuration, and model-specific metadata, kept compact and
  structured for easy comparison across versions.

**Design Rationale**:

- **Single-parent lineage** simplifies model evolution tracking while covering the vast majority of use cases. Complex
  model ensembles or multi-branch experiments can be managed through separate experiment chains.

- **Explicit dataset linkage** separates data drift from model drift—performance changes can be attributed to either
  model architecture/training changes or dataset composition changes.

- **Comprehensive metadata** in `props` ensures training runs can be reproduced exactly, supporting debugging and
  compliance requirements.

Example model experiment:

```json5
{
  "description": "BEV perception model with enhanced pedestrian detection using focal loss.",
  "parent_uuid": "aef12345-6789-0abc-def1-234567890abc",
  "dataset_uuid": "123def45-6789-0abc-def1-234567890def",
  "tags": [
    "model:bev_perception",
    "framework:pytorch",
    "architecture:resnet50"
  ],
  "props": {
    "version": "1.2.0",
    "hyperparameters": {
      "learning_rate": 0.001,
      "batch_size": 32,
      "optimizer": "Adam"
    },
    "training_config": {
      "epochs": 50,
      "data_augmentation": true,
      "early_stopping": true
    }
  }
}
```

**Lineage Visualization**:

The following Git-graph style diagram illustrates dataset and model experiment versioning for a BEV perception use case.
Dataset versions drive model training iterations, while specialized datasets (pedestrian, landmark) enable targeted
model improvements.

```mermaid
---
config:
  theme: default
  themeVariables:
    git0: "#999999"
    git1: "#555555"
    git2: "#999999"
    git3: "#555555"
    git4: "#999999"
    git5: "#555555"
    git6: "#999999"
    git7: "#555555"
    git8: "#999999"
    gitBranchLabel0: "#222222"
    gitBranchLabel1: "#cccccc"
    gitBranchLabel2: "#222222"
    gitBranchLabel3: "#cccccc"
    gitBranchLabel4: "#222222"
    gitBranchLabel5: "#cccccc"
    gitBranchLabel6: "#222222"
    gitBranchLabel7: "#cccccc"
    gitBranchLabel8: "#222222"
---
gitGraph:
    checkout main
    commit id: "empty"
    checkout main
    branch dataset/bev
    checkout dataset/bev
    commit id: "dataset/bev:v1"
    checkout main
    branch model/bev
    checkout model/bev
    merge dataset/bev id: "model/bev:v1"
    checkout dataset/bev
    commit id: "dataset/bev:v2"
    checkout model/bev
    merge dataset/bev id: "model/bev:v2"
    checkout dataset/bev
    branch dataset/bev-pedestrian
    checkout dataset/bev-pedestrian
    commit id: "dataset/bev-pedestrian:v1"
    checkout model/bev
    branch model/bev-pedestrian
    checkout model/bev-pedestrian
    merge dataset/bev-pedestrian id: "model/bev-pedestrian:v1"
    checkout dataset/bev
    commit id: "dataset/bev:v3"
    checkout model/bev
    merge dataset/bev id: "model/bev:v3"
    checkout dataset/bev-pedestrian
    commit id: "dataset/bev-pedestrian:v2"
    checkout model/bev-pedestrian
    merge dataset/bev-pedestrian id: "model/bev-pedestrian:v2"
    checkout dataset/bev
    branch dataset/bev-landmark
    checkout dataset/bev-landmark
    commit id: "dataset/bev-landmark:v1"
    checkout model/bev
    branch model/bev-landmark
    checkout model/bev-landmark
    merge dataset/bev-landmark id: "model/bev-landmark:v1"
    checkout dataset/bev-pedestrian
    commit id: "dataset/bev-pedestrian:v3"
    checkout model/bev-pedestrian
    merge dataset/bev-pedestrian id: "model/bev-pedestrian:v3"
    checkout dataset/bev
    commit id: "dataset/bev:v4"
    checkout model/bev
    merge dataset/bev id: "model/bev:v4"
    checkout dataset/bev-landmark
    commit id: "dataset/bev-landmark:v2"
    checkout model/bev-landmark
    merge dataset/bev-landmark id: "model/bev-landmark:v2"
    checkout dataset/bev
    commit id: "dataset/bev:v5"
    checkout model/bev
    merge dataset/bev id: "model/bev:v5"
    checkout dataset/bev-pedestrian
    commit id: "dataset/bev-pedestrian:v4"
    checkout model/bev-pedestrian
    merge dataset/bev-pedestrian id: "model/bev-pedestrian:v4"
    checkout main
    branch dataset/bev-new
    checkout dataset/bev-new
    commit id: "dataset/bev-new:v1"
    checkout main
    branch model/bev-new
    checkout model/bev-new
    merge dataset/bev-new id: "model/bev-new:v1"

```

This visualization demonstrates how every dataset and model experiment maintains clear provenance, enabling
comprehensive debugging, auditing, and reproducibility analysis. Tracing back to origins is particularly valuable when
investigating performance regressions, comparing model variants, or ensuring compliance with data usage policies.

## Technical Implementation

### Serving and Durable Storage

The system's extensive use of data and metadata requires a robust, scalable, and cost-effective storage architecture.
Different data types have distinct access patterns and performance requirements, so a hybrid storage approach is
employed:

- **Bag Snippet**: **Postgresql** + **NAS**
    - Postgresql: efficient metadata handling and indexing
    - NAS: high-throughput sequential I/O (1-10 GB/s) for large ROS bag files, cost-effective multi-TB storage
- **Registered Dataset Sample**: **Postgresql** + **OSS**
    - Postgresql: ACID transactions for metadata consistency, supports complex query joins
    - OSS: scalable, efficient storage for media files
- **Sample Classifier**: **Elasticsearch**
    - Low-latency search and filtering over large label sets
- **Sample Annotation**: **Postgresql**
    - Supports complex queries and joins between annotations, samples, and datasets
    - Built-in JSONB type enables flexible storage of diverse annotation schemas
- **Model Experiment**: **Postgresql** + **OSS**
    - Postgresql: elegant relational model for capturing lineage relationships
    - OSS: handles multi-GB experiment artifact files
- **Model Metrics**: **Postgresql**
    - Time-series optimizations for tracking metrics over training epochs
    - Supports complex queries for performance analysis

This architecture balances performance, scalability, and cost-effectiveness by leveraging each storage system's
strengths:

- **NAS**: High-throughput sequential I/O, cost-effective multi-TB storage, easy integration with file-based tools
- **OSS**: Scalable object storage, pay-as-you-go pricing, high durability and availability
- **Postgresql**: Reliable ACID transactions, complex relational queries, JSONB support, time-series optimizations,
  mature ecosystem
- **Elasticsearch**: Low-latency search and filtering, flexible schema support, horizontal scalability

Metadata snapshots for backup and disaster recovery are implemented using **ETL** pipelines to export data from
Postgresql and Elasticsearch into **Iceberg** tables stored on OSS, ensuring long-term archival of critical metadata.

**Why not use**:

- **MySQL**: While it offers JSON support, Postgresql's JSONB indexing and querying capabilities are more mature for
  this use case; however, MySQL may be acceptable depending on team familiarity
- **MongoDB**: Provides document flexibility, but Postgresql's stronger ACID guarantees, efficient joins, and mature
  tooling make it better suited for metadata requiring strong consistency and complex queries

```mermaid
---
config:
  flowchart:
    curve: linear
---
flowchart
    subgraph Data
        direction LR
        Data:BagSnippet[Bag Snippet]
        Data:DatasetSample[Registered Dataset Sample]
        Data:SampleClassifier[Sample Classifier]
        Data:ModelExperiment[Model Experiment]
        Data:SampleAnnotation[Sample Annotation]
        Data:ModelAssessment[Model Assessment]
    end

    subgraph Storage[Serving and Durable Storage]
        direction LR
        subgraph Storage:NAS[NAS]
            Storage:NAS:BagSnippet[Bag Snippet<br/><small>fs://bags/</small>]
        end
        subgraph Storage:PG[Postgresql]
            Storage:PG:BagSnippet[Bag Snippet Metadata<br/><small>postgresql://bag_repo/bags</small>]
            Storage:PG:Dataset[Dataset Metadata<br/><small>postgresql://dataset_repo/datasets</small>]
            Storage:PG:Sample[Sample Metadata<br/><small>postgresql://dataset_repo/samples</small>]
            Storage:PG:ModelAssessment[Model Assessment<br/><small>postgresql://model_repo/assessments</small>]
            Storage:PG:ModelExperiment[Model Experiment<br/><small>postgresql://model_repo/experiments</small>]
            Storage:PG:SampleAnnotation[Sample Annotation<br/><small>postgresql://annotation/annotations</small>]
        end
        subgraph Storage:ES[Elasticsearch]
            Storage:ES:SampleClassifier[Sample Classifier<br/><small>elasticsearch://sample_classifier/classifiers</small>]
        end
        subgraph Storage:ICE[Iceberg]
            Storage:ICE:Backup[Backup FDM<br/><small>iceberg://fdm/</small>]
        end
        subgraph Storage:OSS[OSS]
            Storage:OSS:Sample[Sample<br/><small>oss://datasets/</small>]
            Storage:OSS:ModelExperiment[Model Experiments<br/><small>oss://experiments/</small>]
            Storage:OSS:Backup[Backup<br/><small>oss://iceberg/data/fdm</small>]
        end
    end

    Data:BagSnippet -->|Metadata| Storage:PG:BagSnippet
    Data:BagSnippet -->|Bag Files| Storage:NAS:BagSnippet
    Data:DatasetSample -->|Metadata| Storage:PG:Dataset
    Data:DatasetSample -->|Metadata| Storage:PG:Sample
    Data:DatasetSample -->|Media Files| Storage:OSS:Sample
    Data:SampleAnnotation -->|Queries/Joins| Storage:PG:SampleAnnotation
    Data:ModelExperiment -->|Lineage Metadata| Storage:PG:ModelExperiment
    Data:ModelExperiment -->|Experiment Assets| Storage:OSS:ModelExperiment
    Data:ModelAssessment -->|Time - Series Data| Storage:PG:ModelAssessment
    Data:SampleClassifier -->|Search/Filtering| Storage:ES:SampleClassifier
    Storage:PG:BagSnippet -->|Snapshot| Storage:ICE:Backup
    Storage:PG:Dataset -->|Snapshot| Storage:ICE:Backup
    Storage:PG:Sample -->|Snapshot| Storage:ICE:Backup
    Storage:PG:ModelExperiment -->|Snapshot| Storage:ICE:Backup
    Storage:PG:ModelAssessment -->|Snapshot| Storage:ICE:Backup
    Storage:PG:SampleAnnotation -->|Snapshot| Storage:ICE:Backup
    Storage:ES:SampleClassifier -->|Snapshot| Storage:ICE:Backup
    Storage:ICE:Backup -->|Storage| Storage:OSS:Backup
```

### Data Processing Frameworks

Selecting appropriate data processing frameworks for different jobs is crucial for performance, scalability, and
maintainability. The following frameworks are chosen based on their strengths for specific tasks:

- **Resource orchestration**: Kubernetes vs Bare Metal
    - Kubernetes: for containerized workloads with dynamic scaling and resource isolation
    - Bare Metal: for high-performance workloads requiring low-latency access to local NVMe storage
- **Workflow orchestration**: Airflow/Prefect vs Argo Workflows
    - Airflow/Prefect: for complex, long-running ETL pipelines with rich scheduling and monitoring
    - Argo Workflows: for lightweight, Kubernetes-native workflows with tight K8s integration
- **Distributed data computing**: Spark vs Flink vs Ray/KubeRay
    - Spark: for large-scale batch processing with mature ecosystem and SQL support
    - Flink: for low-latency stream processing with event-time semantics
    - Ray/KubeRay: for flexible distributed computing with fine-grained task parallelism and actor model

Based on these considerations, Kubernetes + Argo Workflows is chosen for orchestration. For specific processing tasks,
the following framework combinations are selected:

- **Sample Mining**: Spark + KubeRay
    - Spark: for event data or message log-based mining tasks
    - KubeRay: for custom mining tasks requiring fine-grained parallelism (e.g., CV model inference)
- **Dataset Selection & Registration**: Spark
    - Spark: for bulk metadata transformations and transactional writes
- **Sample Classifier and Annotation Labeling**: Spark + KubeRay
    - Spark: for classifier mining tasks based on large-scale data analysis
    - KubeRay: for custom annotation labeling logic requiring a flexible Python environment
- **Model Training**: Spark + KubeRay
    - Spark: for data preprocessing and feature engineering at scale
    - KubeRay: for distributed deep learning training with PyTorch/TensorFlow
- **Model Evaluation**: KubeRay
    - KubeRay: for flexible benchmarking tasks with custom evaluation logic, leveraging distributed actors for caching
      model and dataset artifacts

For model training and benchmarking jobs requiring high-performance access to local NVMe storage, a cache layer such as
**Alluxio** is deployed on Kubernetes cluster nodes, caching frequently accessed dataset samples and model experiments
from OSS to local NVMe drives.

The following sequence diagrams illustrate the interactions between components during each data processing job:

**Sample Mining**

```mermaid
sequenceDiagram
    actor User as Engineer
    participant Workflow as Workflow<br/>Argo Workflows
    participant Executor as Executor<br/>Kubernetes Cluster
    participant Storage/Postgresql/BagMeta as Storage / Postgresql<br/>Bag Metadata
    participant Storage/NAS/BagSnippet as Storage / NAS<br/>Bag Snippet
    participant Storage/Postgresql/SampleClassifier as Storage / Postgresql<br/>Sample Classifier
    participant Storage/OSS/DatasetSample as Storage / OSS<br/>Standalone Dataset Sample
    User ->>+ Workflow: Submit sample mining job
    Workflow ->>+ Executor: Schedule mining tasks
    Executor ->> Storage/Postgresql/BagMeta: Query event data metadata
    Storage/Postgresql/BagMeta -->> Executor: Return metadata
    Executor ->> Storage/NAS/BagSnippet: Read event data files
    Storage/NAS/BagSnippet -->> Executor: Stream data files
    Executor ->> Executor: Process data for sample mining
    Executor ->> Storage/Postgresql/SampleClassifier: Write mined sample classifiers
    Storage/Postgresql/SampleClassifier -->> Executor: Acknowledge write
    Executor ->> Storage/OSS/DatasetSample: Store mined sample snippets
    Storage/OSS/DatasetSample -->> Executor: Acknowledge storage
    Executor -->>- Workflow: Job completion status
    Workflow -->>- User: Notify job completion
```

**Dataset Selection & Registration**

```mermaid
sequenceDiagram
    actor User as Engineer
    participant Workflow as Workflow<br/>Argo Workflows
    participant Executor as Executor<br/>Kubernetes Cluster
    participant Storage/Postgresql/DatasetSample as Storage / Postgresql<br/>Registered Dataset Sample
    User ->>+ Workflow: Submit dataset registration job
    Workflow ->>+ Executor: Schedule registration tasks
    Executor ->> Storage/Postgresql/DatasetSample: Query candidate samples metadata
    Storage/Postgresql/DatasetSample -->> Executor: Return metadata
    Executor ->> Executor: Apply selection criteria
    Executor ->> Storage/Postgresql/DatasetSample: Write registered dataset metadata
    Storage/Postgresql/DatasetSample -->> Executor: Acknowledge write
    Executor -->>- Workflow: Job completion status
    Workflow -->>- User: Notify job completion
```

**Sample Classifier/Annotating Labeling**

```mermaid
sequenceDiagram
    actor User as Engineer
    participant Workflow as Workflow<br/>Argo Workflows
    participant Executor as Executor<br/>Kubernetes Cluster
    participant Storage/Postgresql/DatasetSample as Storage / Postgresql<br/>Registered Dataset Sample
    participant Storage/OSS/DatasetSample as Storage / OSS<br/>Registered Dataset Sample
    participant Storage/Postgresql/SampleClassifierAnnotation as Storage / Postgresql<br/>Sample Classifier/Annotation
    User ->>+ Workflow: Submit sample classifier/annotation labeling job
    Workflow ->>+ Executor: Schedule classifier/annotation labeling tasks
    Executor ->> Storage/Postgresql/DatasetSample: Query dataset metadata
    Storage/Postgresql/DatasetSample -->> Executor: Return metadata
    Executor ->> Storage/OSS/DatasetSample: Read dataset samples
    Storage/OSS/DatasetSample -->> Executor: Stream dataset samples
    Executor ->> Executor: Apply classifier/annotation labeling logic
    Executor ->> Storage/Postgresql/SampleClassifierAnnotation: Write sample classifiers/annotations
    Storage/Postgresql/SampleClassifierAnnotation -->> Executor: Acknowledge write
    Executor -->>- Workflow: Job completion status
    Workflow -->>- User: Notify job completion
```

**Model Training**

```mermaid
sequenceDiagram
    actor User as Engineer
    participant Workflow as Workflow<br/>Argo Workflows
    participant Executor as Executor<br/>Kubernetes Cluster
    participant Storage/Postgresql/ModelExperiment as Storage / Postgresql<br/>Model Experiment
    participant Storage/OSS/ModelExperiment as Storage / OSS<br/>Model Experiment
    participant Storage/Postgresql/DatasetSample as Storage / Postgresql<br/>Registered Dataset Sample
    participant Storage/OSS/DatasetSample as Storage / OSS<br/>Registered Dataset Sample
    participant Storage/OSS/DataSharding as Storage / OSS<br/>Data Sharding
    participant Storage/Cache/DataSharding as Storage / Cache<br/>Data Sharding
    User ->>+ Workflow: Submit model training job
    Workflow ->>+ Executor: Schedule training tasks
    Executor ->> Storage/Postgresql/ModelExperiment: Retrieve parent model experiment metadata
    Storage/Postgresql/ModelExperiment -->> Executor: Return parent model experiment metadata
    Executor ->> Storage/OSS/ModelExperiment: Load parent model experiment files
    Storage/OSS/ModelExperiment -->> Executor: Stream parent model experiment files
    Executor ->> Storage/Postgresql/DatasetSample: Query training dataset metadata
    Storage/Postgresql/DatasetSample -->> Executor: Return metadata
    Executor ->> Storage/OSS/DatasetSample: Read training dataset samples
    Storage/OSS/DatasetSample -->> Executor: Stream dataset samples
    Executor ->> Executor: Preprocess data and prepare batches
    Executor ->> Storage/OSS/DataSharding: Shard dataset for distributed training
    Storage/OSS/DataSharding -->> Executor: Acknowledge sharding
    Executor ->> Storage/Cache/DataSharding: Cache sharded data on distributed nodes
    Storage/Cache/DataSharding -->> Executor: Acknowledge caching
    Executor ->> Executor: Train model on distributed workers
    Executor ->> Storage/Postgresql/ModelExperiment: Write model experiment metadata
    Storage/Postgresql/ModelExperiment -->> Executor: Acknowledge write
    Executor ->> Storage/OSS/ModelExperiment: Store model experiment files
    Storage/OSS/ModelExperiment -->> Executor: Acknowledge storage
    Executor -->>- Workflow: Job completion status
    Workflow -->>- User: Notify job completion
```

**Model Evaluation**

```mermaid
sequenceDiagram
    actor User as Engineer
    participant Workflow as Workflow<br/>Argo Workflows
    participant Executor as Executor<br/>Kubernetes Cluster
    participant Storage/Postgresql/ModelExperiment as Storage / Postgresql<br/>Model Experiment
    participant Storage/OSS/ModelExperiment as Storage / OSS<br/>Model Experiment
    participant Storage/Postgresql/DatasetSample as Storage / Postgresql<br/>Registered Dataset Sample
    participant Storage/OSS/DatasetSample as Storage / OSS<br/>Registered Dataset Sample
    participant Storage/Postgresql/ModelAssessment as Storage / Postgresql<br/>Model Assessment
    User ->>+ Workflow: Submit model benchmarking job
    Workflow ->>+ Executor: Schedule benchmarking tasks
    Executor ->> Storage/Postgresql/ModelExperiment: Retrieve model experiment metadata
    Storage/Postgresql/ModelExperiment -->> Executor: Return model experiment metadata
    Executor ->> Storage/OSS/ModelExperiment: Load model experiment files
    Storage/OSS/ModelExperiment -->> Executor: Stream model experiment files
    Executor ->> Storage/Postgresql/DatasetSample: Query benchmarking dataset metadata
    Storage/Postgresql/DatasetSample -->> Executor: Return metadata
    Executor ->> Storage/OSS/DatasetSample: Read benchmarking dataset samples
    Storage/OSS/DatasetSample -->> Executor: Stream dataset samples
    Executor ->> Executor: Benchmark model on distributed workers
    Executor ->> Storage/Postgresql/ModelAssessment: Write model assessment metrics
    Storage/Postgresql/ModelAssessment -->> Executor: Acknowledge write
    Executor -->>- Workflow: Job completion status
    Workflow -->>- User: Notify job completion
```

### Capacity Estimation

Accurate capacity estimation is essential for cost-effective storage planning. The following estimates are based on
current and projected data volumes:

| Data Type                 | Estimated Size per Unit | Unit              | Units per Year | Estimated Size per Year (TB) | Remarks                                                 |
|---------------------------|------------------------:|-------------------|---------------:|-----------------------------:|---------------------------------------------------------|
| Bag Snippet               |                   70 GB | hour × vehicle    |         40,000 |                        3,000 | 10 vehicles × 4,000 hours each annually                 |
| Registered Dataset Sample |                    2 MB | frame × sample    |    100,000,000 |                          200 | Each sample covers 20 seconds of data recorded at 10 Hz |
| Sample Classifier         |                    5 MB | sample            |        500,000 |                            3 | Depends on classifier payload size                      |
| Sample Annotation         |                    5 MB | sample            |        500,000 |                            3 | Depends on annotation payload size                      |
| Model Experiment          |                    5 GB | version           |            200 |                            1 | Average experiment artifact size × versions per year    |
| Model Assessment          |                    5 MB | version × dataset |          1,000 |                        0.005 | 1,000 metric records × 5 MB = ~5 GB/year (0.005 TB)     |

**Assumptions**: These estimates assume steady-state operations with the fleet size and sampling rates described. Verify
calculations against actual fleet composition, retention policies, and growth projections before procurement.
