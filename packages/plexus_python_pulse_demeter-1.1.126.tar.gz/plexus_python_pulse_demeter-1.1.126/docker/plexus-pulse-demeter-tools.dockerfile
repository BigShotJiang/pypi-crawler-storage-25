ARG BASE_IMAGE=ruyangshou/plexus-basedev-dev-python:latest

FROM ${BASE_IMAGE}

USER root

RUN update-alternatives --install /usr/bin/python python /usr/bin/python3.13 100 && \
    update-alternatives --set python /usr/bin/python3.13

WORKDIR /app

COPY . .

RUN python -m venv /app/venv && \
    /app/venv/bin/python -m pip install --upgrade pip && \
    /app/venv/bin/python -m pip install ./[all]

RUN touch ${HOME}/.plexus-pulse.cfg

ENTRYPOINT ["/bin/bash", "-lc", "source /app/venv/bin/activate && exec \"$@\"", "--"]
