from plexus.common.utils.config import Config
from plexus.common.utils.funcutils import singleton
from plexus.common.utils.pathutils import make_path


@singleton
def config() -> Config:
    default_items: list[tuple[str, str, str]] = [
        ("pulse.apps.database", "host", ""),
        ("pulse.apps.database", "port", "5432"),
        ("pulse.apps.database", "username", ""),
        ("pulse.apps.database", "password", ""),
        ("pulse.apps.database", "database", "pulse-apps"),
        ("pulse.apps.vault", "access_key_id", ""),
        ("pulse.apps.vault", "secret_access_key", ""),
        ("pulse.apps.vault", "endpoint_url", "http://localhost:9000"),
    ]

    from plexus.pulse.common.utils.config import config as pulse_config

    instance = pulse_config(make_path("~/.plexus-pulse.cfg", expand=True, normalize=True, absolute=True))
    instance.restore()
    instance.update(default_items, overwrite=False)

    return instance
