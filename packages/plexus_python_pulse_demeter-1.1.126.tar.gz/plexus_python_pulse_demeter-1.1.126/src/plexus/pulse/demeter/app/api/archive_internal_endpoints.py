import datetime

import sqlalchemy.orm as sa_orm
from fastapi import APIRouter, Depends
from fastapi.params import Query
from plexus.common.utils.dtutils import dt_utc_now
from plexus.pulse.common.utils.apiutils import managed_db_session
from plexus.pulse.common.utils.ormutils import (
    db_create_revision_model,
    db_create_revision_models,
    db_expire_revision_model,
    db_read_active_revision_model_of_record,
    db_read_active_revision_models,
    db_update_revision_model,
)

from plexus.pulse.demeter.app.core.database import make_session
from plexus.pulse.demeter.app.models.registry.archive import (
    RegisteredBag as Bag,
    RegisteredBagTable as BagTable,
    Sensor,
    SensorTable,
    SensorTemplate,
    SensorTemplateTable,
    Vehicle,
    VehicleTable,
    VehicleTemplate,
    VehicleTemplateTable,
)

router = APIRouter(prefix="/pulse_demeter/archive_internal", tags=["archive_internal"])


@router.post("/vehicle_template/", response_model=VehicleTemplateTable)
def create_vehicle_template(
    vehicle_template: VehicleTemplate,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> VehicleTemplateTable:
    with managed_db_session(db):
        return db_create_revision_model(db, VehicleTemplateTable, vehicle_template, created_at)


@router.post("/vehicle_templates/", response_model=list[VehicleTemplateTable])
def create_vehicle_templates(
    vehicle_templates: list[VehicleTemplate],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[VehicleTemplateTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, VehicleTemplateTable, vehicle_templates, created_at)


@router.get("/vehicle_template/{record_sqn}", response_model=VehicleTemplateTable)
def read_vehicle_template(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> VehicleTemplateTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, VehicleTemplateTable, record_sqn)


@router.get("/vehicle_templates/", response_model=list[VehicleTemplateTable])
def read_vehicle_templates(
    skip: int = Query(0),
    limit: int = Query(100),
    db: sa_orm.Session = Depends(make_session),
) -> list[VehicleTemplateTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, VehicleTemplateTable, skip, limit)


@router.put("/vehicle_template/{record_sqn}", response_model=VehicleTemplateTable)
def update_vehicle_template(
    record_sqn: int,
    vehicle_template: VehicleTemplate,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> VehicleTemplateTable:
    with managed_db_session(db):
        return db_update_revision_model(db, VehicleTemplateTable, vehicle_template, record_sqn, updated_at)


@router.delete("/vehicle_template/{record_sqn}", response_model=VehicleTemplateTable)
def delete_vehicle_template(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> VehicleTemplateTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, VehicleTemplateTable, record_sqn, updated_at)


@router.post("/sensor_template/", response_model=SensorTemplateTable)
def create_sensor_template(
    sensor_template: SensorTemplate,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> SensorTemplateTable:
    with managed_db_session(db):
        return db_create_revision_model(db, SensorTemplateTable, sensor_template, created_at)


@router.post("/sensor_templates/", response_model=list[SensorTemplateTable])
def create_sensor_templates(
    sensor_templates: list[SensorTemplate],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[SensorTemplateTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, SensorTemplateTable, sensor_templates, created_at)


@router.get("/sensor_template/{record_sqn}", response_model=SensorTemplateTable)
def read_sensor_template(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> SensorTemplateTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, SensorTemplateTable, record_sqn)


@router.get("/sensor_templates/", response_model=list[SensorTemplateTable])
def read_sensor_templates(
    skip: int = Query(0),
    limit: int = Query(100),
    db: sa_orm.Session = Depends(make_session),
) -> list[SensorTemplateTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, SensorTemplateTable, skip, limit)


@router.put("/sensor_template/{record_sqn}", response_model=SensorTemplateTable)
def update_sensor_template(
    record_sqn: int,
    sensor_template: SensorTemplate,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> SensorTemplateTable:
    with managed_db_session(db):
        return db_update_revision_model(db, SensorTemplateTable, sensor_template, record_sqn, updated_at)


@router.delete("/sensor_template/{record_sqn}", response_model=SensorTemplateTable)
def delete_sensor_template(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> SensorTemplateTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, SensorTemplateTable, record_sqn, updated_at)


@router.post("/vehicle/", response_model=VehicleTable)
def create_vehicle(
    vehicle: Vehicle,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> VehicleTable:
    with managed_db_session(db):
        return db_create_revision_model(db, VehicleTable, vehicle, created_at)


@router.post("/vehicles/", response_model=list[VehicleTable])
def create_vehicles(
    vehicles: list[Vehicle],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[VehicleTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, VehicleTable, vehicles, created_at)


@router.get("/vehicle/{record_sqn}", response_model=VehicleTable)
def read_vehicle(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> VehicleTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, VehicleTable, record_sqn)


@router.get("/vehicles/", response_model=list[VehicleTable])
def read_vehicles(
    skip: int = Query(0),
    limit: int = Query(100),
    db: sa_orm.Session = Depends(make_session),
) -> list[VehicleTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, VehicleTable, skip, limit)


@router.put("/vehicle/{record_sqn}", response_model=VehicleTable)
def update_vehicle(
    record_sqn: int,
    vehicle: Vehicle,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> VehicleTable:
    with managed_db_session(db):
        return db_update_revision_model(db, VehicleTable, vehicle, record_sqn, updated_at)


@router.delete("/vehicle/{record_sqn}", response_model=VehicleTable)
def delete_vehicle(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> VehicleTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, VehicleTable, record_sqn, updated_at)


@router.post("/sensor/", response_model=SensorTable)
def create_sensor(
    sensor: Sensor,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> SensorTable:
    with managed_db_session(db):
        return db_create_revision_model(db, SensorTable, sensor, created_at)


@router.post("/sensors/", response_model=list[SensorTable])
def create_sensors(
    sensors: list[Sensor],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[SensorTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, SensorTable, sensors, created_at)


@router.get("/sensor/{record_sqn}", response_model=SensorTable)
def read_sensor(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> SensorTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, SensorTable, record_sqn)


@router.get("/sensors/", response_model=list[SensorTable])
def read_sensors(
    skip: int = Query(0),
    limit: int = Query(100),
    db: sa_orm.Session = Depends(make_session),
) -> list[SensorTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, SensorTable, skip, limit)


@router.put("/sensor/{record_sqn}", response_model=SensorTable)
def update_sensor(
    record_sqn: int,
    sensor: Sensor,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> SensorTable:
    with managed_db_session(db):
        return db_update_revision_model(db, SensorTable, sensor, record_sqn, updated_at)


@router.delete("/sensor/{record_sqn}", response_model=SensorTable)
def delete_sensor(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> SensorTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, SensorTable, record_sqn, updated_at)


@router.post("/bag/", response_model=BagTable)
def create_bag(
    bag: Bag,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> BagTable:
    with managed_db_session(db):
        return db_create_revision_model(db, BagTable, bag, created_at)


@router.post("/bags/", response_model=list[BagTable])
def create_bags(
    bags: list[Bag],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[BagTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, BagTable, bags, created_at)


@router.get("/bag/{record_sqn}", response_model=BagTable)
def read_bag(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> BagTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, BagTable, record_sqn)


@router.get("/bags/", response_model=list[BagTable])
def read_bags(
    skip: int = Query(0),
    limit: int = Query(100),
    db: sa_orm.Session = Depends(make_session),
) -> list[BagTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, BagTable, skip, limit)


@router.put("/bag/{record_sqn}", response_model=BagTable)
def update_bag(
    record_sqn: int,
    bag: Bag,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> BagTable:
    with managed_db_session(db):
        return db_update_revision_model(db, BagTable, bag, record_sqn, updated_at)


@router.delete("/bag/{record_sqn}", response_model=BagTable)
def delete_bag(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> BagTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, BagTable, record_sqn, updated_at)
