from fastapi import Response
from fastapi import status

from plexus.pulse.demeter.app.api import make_api

app = make_api()


@app.get("/health")
async def check_health():
    return Response(status_code=status.HTTP_200_OK)


@app.get("/live")
async def check_liveness():
    return Response(status_code=status.HTTP_200_OK)
