import dataclasses
import datetime
import uuid as py_uuid
from collections import Counter
from collections.abc import Callable
from typing import Any, Literal

import pydantic as pdt
import sqlalchemy as sa
import sqlalchemy.exc as sa_exc
import sqlalchemy.orm as sa_orm
from fastapi import APIRouter, Depends
from fastapi.params import Body, Path, Query
from plexus.common.utils.funcutils import singleton
from plexus.pulse.common.utils.apiutils import managed_db_session
from plexus.pulse.common.utils.ormutils import (
    db_create_revision_model,
    db_create_revision_models,
    db_make_order_by_clause,
    db_read_active_revision_models,
    model_name_of,
)
from plexus.pulse.common.utils.sqlutils import escape_sql_like
from plexus.pulse.common.utils.tagutils import predefined_tagsets

from plexus.pulse.demeter.app.api import current_dt_clock
from plexus.pulse.demeter.app.core.database import make_session
from plexus.pulse.demeter.app.models import ColumnFormatter, ColumnOrdering, Pagination, TableColumn
from plexus.pulse.demeter.app.models.registry import JobStatusFlag
from plexus.pulse.demeter.app.models.registry.dataset import (
    AnnotationGuidelineTable as GuidelineTable,
    ClassifierTaxonomyTable as TaxonomyTable,
    DatasetPromotionTable as DatasetPromotionTable,
    DatasetRegistrationTable as RegistrationTable,
    ModelArchitectureTable as ArchitectureTable,
    ModelAssessmentPromotionTable as AssessmentPromotionTable,
    ModelAssessmentTable as AssessmentTable,
    ModelBenchmarkTable as BenchmarkTable,
    ModelEvaluationTable as EvaluationTable,
    ModelExperimentPromotionTable as ExperimentPromotionTable,
    ModelExperimentTable as ExperimentTable,
    ModelTrainingTable as TrainingTable,
    RegisteredDatasetLayoutTable as DatasetLayoutTable,
    RegisteredDatasetSampleTable as DatasetSampleTable,
    RegisteredDatasetTable as DatasetTable,
    RegisteredSampleTable as SampleTable,
    SampleAnnotationTable as AnnotationTable,
    SampleClassifierTable as ClassifierTable,
    SampleLayoutTable as LayoutTable,
)
from plexus.pulse.demeter.app.models.registry.dataset import (
    RegisteredDataset as Dataset,
    RegisteredSample as Sample,
    SampleAnnotation as Annotation,
    SampleClassifier as Classifier,
)

router = APIRouter(prefix="/pulse_demeter/dataset_public", tags=["dataset_public"])


# Composite model naming convention
# - Use 'And' to join one-to-one relationships. For a chain of one-to-one relations, create a single composite model
#   that covers the whole chain.
# - Use 'With' to indicate one-to-many relationships.
# - Use plural form for the target segment of a one-to-many relationship.
#   - If the target is a one-to-one relationship, pluralize the entire relationship segment.
#   - If the target is also one-to-many, pluralize the source segment of that nested relationship.
#   - For multiple chained one-to-many relationships, pluralize each relevant segment.
# - Preserve the order of segments following the hierarchy.
# Examples:
# - A one-to-one B one-to-one C
#   AAndBAndC(a: A, b: B, c: C)
# - A one-to-many B one-to-one C
#   BAndC(b: B, c: C)
#   AWithBAndCs(a: A, b_and_cs: list[BAndC])  # pluralize the entire one-to-one segment
# - A one-to-one B one-to-many C
#   BWithCs(b: B, cs: list[C])
#   AAndBWithCs(a: A, b_with_cs: BWithCs)
# - A one-to-many B one-to-many C
#   BWithCs(b: B, cs: list[C])
#   AWithBsWithCs(a: A, bs_with_cs: list[BWithCs])  # pluralize source segments
# - A one-to-many B one-to-many C one-to-many D
#   CWithDs(c: C, ds: list[D])
#   BWithCsWithDs(b: B, cs_with_ds: list[CWithDs])
#   AWithBsWithCsWithDs(a: A, bs_with_cs_with_ds: list[BWithCsWithDs])


@router.get("/layouts", response_model=list[LayoutTable])
def layouts(db: sa_orm.Session = Depends(make_session)) -> list[LayoutTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, LayoutTable)


@router.get("/layout", response_model=LayoutTable)
def get_layout(
    uuid: py_uuid.UUID | None = Query(None),
    name: str | None = Query(None),
    db: sa_orm.Session = Depends(make_session),
) -> LayoutTable:
    if uuid is None and name is None:
        raise sa_exc.ArgumentError("either 'uuid' or 'name' must be provided")
    with managed_db_session(db):
        query_stmt = db.query(LayoutTable).where(LayoutTable.expired_at.is_(None))
        if uuid is not None:
            query_stmt = query_stmt.where(LayoutTable.uuid == uuid)
        if name is not None:
            query_stmt = query_stmt.where(LayoutTable.name == name)
        db_layout: LayoutTable | None = query_stmt.one_or_none()
        if db_layout is None:
            raise sa_exc.NoResultFound(
                f"'{model_name_of(LayoutTable)}' with uuid '{uuid}' and/or name '{name}' not found")
        return db_layout


@router.get("/taxonomies", response_model=list[TaxonomyTable])
def taxonomies(db: sa_orm.Session = Depends(make_session)) -> list[TaxonomyTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, TaxonomyTable)


@router.get("/taxonomy", response_model=TaxonomyTable)
def get_taxonomy(
    uuid: py_uuid.UUID | None = Query(None),
    name: str | None = Query(None),
    db: sa_orm.Session = Depends(make_session),
) -> TaxonomyTable:
    if uuid is None and name is None:
        raise sa_exc.ArgumentError("either 'uuid' or 'name' must be provided")
    with managed_db_session(db):
        query_stmt = db.query(TaxonomyTable).where(TaxonomyTable.expired_at.is_(None))
        if uuid is not None:
            query_stmt = query_stmt.where(TaxonomyTable.uuid == uuid)
        if name is not None:
            query_stmt = query_stmt.where(TaxonomyTable.name == name)
        db_taxonomy: TaxonomyTable | None = query_stmt.one_or_none()
        if db_taxonomy is None:
            raise sa_exc.NoResultFound(
                f"'{model_name_of(TaxonomyTable)}' with uuid '{uuid}' and/or name '{name}' not found")
        return db_taxonomy


@router.get("/guidelines", response_model=list[GuidelineTable])
def guidelines(db: sa_orm.Session = Depends(make_session)) -> list[GuidelineTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, GuidelineTable)


@router.get("/guideline", response_model=GuidelineTable)
def get_guideline(
    uuid: py_uuid.UUID | None = Query(None),
    name: str | None = Query(None),
    db: sa_orm.Session = Depends(make_session),
) -> GuidelineTable:
    if uuid is None and name is None:
        raise sa_exc.ArgumentError("either 'uuid' or 'name' must be provided")
    with managed_db_session(db):
        query_stmt = db.query(GuidelineTable).where(GuidelineTable.expired_at.is_(None))
        if uuid is not None:
            query_stmt = query_stmt.where(GuidelineTable.uuid == uuid)
        if name is not None:
            query_stmt = query_stmt.where(GuidelineTable.name == name)
        db_guideline: GuidelineTable | None = query_stmt.one_or_none()
        if db_guideline is None:
            raise sa_exc.NoResultFound(
                f"'{model_name_of(GuidelineTable)}' with uuid '{uuid}' and/or name '{name}' not found")
        return db_guideline


@router.get("/architectures", response_model=list[ArchitectureTable])
def architectures(db: sa_orm.Session = Depends(make_session)) -> list[ArchitectureTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, ArchitectureTable)


@router.get("/architecture", response_model=ArchitectureTable)
def get_architecture(
    uuid: py_uuid.UUID | None = Query(None),
    name: str | None = Query(None),
    db: sa_orm.Session = Depends(make_session),
) -> ArchitectureTable:
    if uuid is None and name is None:
        raise sa_exc.ArgumentError("either 'uuid' or 'name' must be provided")
    with managed_db_session(db):
        query_stmt = db.query(ArchitectureTable).where(ArchitectureTable.expired_at.is_(None))
        if uuid is not None:
            query_stmt = query_stmt.where(ArchitectureTable.uuid == uuid)
        if name is not None:
            query_stmt = query_stmt.where(ArchitectureTable.name == name)
        db_architecture: ArchitectureTable | None = query_stmt.one_or_none()
        if db_architecture is None:
            raise sa_exc.NoResultFound(
                f"'{model_name_of(ArchitectureTable)}' with uuid '{uuid}' and/or name '{name}' not found")
        return db_architecture


@router.get("/benchmarks", response_model=list[BenchmarkTable])
def benchmarks(db: sa_orm.Session = Depends(make_session)) -> list[BenchmarkTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, BenchmarkTable)


@router.get("/benchmark", response_model=BenchmarkTable)
def get_benchmark(
    uuid: py_uuid.UUID | None = Query(None),
    name: str | None = Query(None),
    db: sa_orm.Session = Depends(make_session),
) -> BenchmarkTable:
    if uuid is None and name is None:
        raise sa_exc.ArgumentError("either 'uuid' or 'name' must be provided")
    with managed_db_session(db):
        query_stmt = db.query(BenchmarkTable).where(BenchmarkTable.expired_at.is_(None))
        if uuid is not None:
            query_stmt = query_stmt.where(BenchmarkTable.uuid == uuid)
        if name is not None:
            query_stmt = query_stmt.where(BenchmarkTable.name == name)
        db_benchmark: BenchmarkTable | None = query_stmt.one_or_none()
        if db_benchmark is None:
            raise sa_exc.NoResultFound(
                f"'{model_name_of(BenchmarkTable)}' with uuid '{uuid}' and/or name '{name}' not found")
        return db_benchmark


class LayoutTableAndSamplesCount(pdt.BaseModel):
    layout: LayoutTable
    samples_count: int


class DatasetTableDetail(pdt.BaseModel):
    dataset: DatasetTable
    layouts: list[LayoutTableAndSamplesCount]
    samples_count: int
    registration: RegistrationTable | None
    promotion: DatasetPromotionTable | None


class DatasetTableDetailsAndPagination(pdt.BaseModel):
    dataset_details: list[DatasetTableDetail]
    pagination: Pagination


def query_layout_samples_counts(
    dataset_uuids: list[py_uuid.UUID],
    db: sa_orm.Session,
) -> dict[py_uuid.UUID, list[LayoutTableAndSamplesCount]]:
    db_dataset_layouts = (
        db
        .query(DatasetLayoutTable)
        .where(DatasetLayoutTable.dataset_uuid.in_(dataset_uuids))
        .all()
    )
    db_dataset_layouts_dicts = {}
    for db_dataset_layout in db_dataset_layouts: (
        db_dataset_layouts_dicts
        .setdefault(db_dataset_layout.dataset_uuid, {})
        .setdefault(db_dataset_layout.layout_uuid, db_dataset_layout)
    )

    layout_uuids = list(set(layout_uuid
                            for db_dataset_layouts_dict in db_dataset_layouts_dicts.values()
                            for layout_uuid in db_dataset_layouts_dict))
    db_layouts = (
        db
        .query(LayoutTable)
        .where(LayoutTable.expired_at.is_(None), LayoutTable.uuid.in_(layout_uuids))
        .all()
    )
    db_layouts_dict = {db_layout.uuid: db_layout for db_layout in db_layouts}
    for layout_uuid in layout_uuids:
        if layout_uuid not in db_layouts_dict:
            raise sa_exc.NoResultFound(f"'{model_name_of(LayoutTable)}' with uuid '{layout_uuid}' not found")

    # NOTE:
    # - Layouts here are intentionally ordered by `samples_count` in descending order
    #   so that the most populated layouts appear first.
    # - Other endpoints may order layouts differently (for example, by `LayoutTable.sqn`)
    #   to provide a stable schema-oriented ordering.
    #   This difference is intentional and reflects the distinct use-cases.
    return {
        dataset_uuid: [
            LayoutTableAndSamplesCount(layout=db_layouts_dict.get(db_dataset_layout.layout_uuid),
                                       samples_count=db_dataset_layout.samples_count)
            for db_dataset_layout
            in sorted(db_dataset_layouts_dict.values(), key=lambda x: x.samples_count, reverse=True)
        ]
        for dataset_uuid, db_dataset_layouts_dict in db_dataset_layouts_dicts.items()
    }


@router.get("/list_datasets", response_model=DatasetTableDetailsAndPagination)
def list_datasets(
    skip: int = Query(0),
    limit: int = Query(100),
    begin_at: datetime.datetime | None = Query(None),
    end_at: datetime.datetime | None = Query(None),
    major_layout: str | None = Query(None),
    name_match: str | None = Query(None),
    contributor_sso_sid: int | None = Query(None),
    only_completed_jobs: bool = Query(True),
    only_shared: bool = Query(True),
    order_by: list[str] | None = Query(None),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTableDetailsAndPagination:
    with managed_db_session(db):
        query_stmt = (
            db
            .query(DatasetTable, RegistrationTable, DatasetPromotionTable)
            .outerjoin(RegistrationTable, DatasetTable.uuid == RegistrationTable.dataset_uuid)
            .outerjoin(DatasetPromotionTable, DatasetTable.uuid == DatasetPromotionTable.dataset_uuid)
            .where(DatasetTable.expired_at.is_(None),
                   RegistrationTable.expired_at.is_(None),
                   DatasetPromotionTable.expired_at.is_(None))
        )
        if only_completed_jobs:
            query_stmt = query_stmt.where(sa.or_(RegistrationTable.sqn.is_(None),
                                                 RegistrationTable.flags.op("&")(JobStatusFlag.Completed.value) > 0))
        if only_shared:
            query_stmt = query_stmt.where(DatasetPromotionTable.flags.op("&")(JobStatusFlag.Completed.value) > 0)
        if begin_at is not None:
            query_stmt = query_stmt.where(DatasetTable.created_at >= begin_at)
        if end_at is not None:
            query_stmt = query_stmt.where(DatasetTable.created_at < end_at)
        if name_match is not None:
            query_stmt = query_stmt.where(DatasetTable.name.ilike(f"%{escape_sql_like(name_match)}%", escape="\\"))
        if contributor_sso_sid is not None:
            query_stmt = query_stmt.where(DatasetTable.contributor_sso_sid == contributor_sso_sid)
        query_stmt = query_stmt.order_by(*db_make_order_by_clause(DatasetTable, order_by))

        total = query_stmt.count()
        if total == 0:
            return DatasetTableDetailsAndPagination(
                dataset_details=[],
                pagination=Pagination(skip=skip, limit=limit, total=0),
            )

        db_dataset_registration_promotions = query_stmt.offset(skip).limit(limit).all()

        dataset_uuids = list(set(db_dataset.uuid for db_dataset, _, _ in db_dataset_registration_promotions))
        layout_samples_counts_by_datasets = query_layout_samples_counts(dataset_uuids, db)

        return DatasetTableDetailsAndPagination(
            dataset_details=[
                DatasetTableDetail(
                    dataset=db_dataset,
                    layouts=layout_samples_counts_by_datasets.get(db_dataset.uuid, []),
                    samples_count=sum(layout_samples_count.samples_count
                                      for layout_samples_count in
                                      layout_samples_counts_by_datasets.get(db_dataset.uuid, [])),
                    registration=db_registration,
                    promotion=db_promotion,
                )
                for db_dataset, db_registration, db_promotion in db_dataset_registration_promotions
            ],
            pagination=Pagination(skip=skip, limit=limit, total=total),
        )


@router.get("/get_dataset/{dataset_uuid}", response_model=DatasetTableDetail)
def get_dataset(
    dataset_uuid: py_uuid.UUID = Path(),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTableDetail:
    with managed_db_session(db):
        db_dataset_registration_promotion = (
            db
            .query(DatasetTable, RegistrationTable, DatasetPromotionTable)
            .outerjoin(RegistrationTable, DatasetTable.uuid == RegistrationTable.dataset_uuid)
            .outerjoin(DatasetPromotionTable, DatasetTable.uuid == DatasetPromotionTable.dataset_uuid)
            .where(DatasetTable.expired_at.is_(None),
                   RegistrationTable.expired_at.is_(None),
                   DatasetPromotionTable.expired_at.is_(None),
                   DatasetTable.uuid == dataset_uuid)
            .one_or_none()
        )
        if db_dataset_registration_promotion is None:
            raise sa_exc.NoResultFound(f"'{model_name_of(DatasetTable)}' with uuid '{dataset_uuid}' not found")

        db_dataset, db_registration, db_promotion = db_dataset_registration_promotion

        layout_samples_counts_by_datasets = query_layout_samples_counts([dataset_uuid], db)
        layout_samples_counts = layout_samples_counts_by_datasets.get(dataset_uuid, [])

        return DatasetTableDetail(
            dataset=db_dataset,
            layouts=layout_samples_counts,
            samples_count=sum(layout_samples_count.samples_count for layout_samples_count in layout_samples_counts),
            registration=db_registration,
            promotion=db_promotion,
        )


class ExperimentTableDetail(pdt.BaseModel):
    experiment: ExperimentTable
    training: TrainingTable | None
    promotion: ExperimentPromotionTable | None
    architecture: ArchitectureTable | None
    dataset: DatasetTable | None
    layouts: list[LayoutTableAndSamplesCount] | None
    samples_count: int


class ExperimentTableDetailsAndPagination(pdt.BaseModel):
    experiment_details: list[ExperimentTableDetail]
    pagination: Pagination


@router.get("/list_model_experiments/", response_model=ExperimentTableDetailsAndPagination)
def list_model_experiments(
    skip: int = Query(0),
    limit: int = Query(100),
    begin_at: datetime.datetime | None = Query(None),
    end_at: datetime.datetime | None = Query(None),
    architecture: str | None = Query(None),
    name_match: str | None = Query(None),
    contributor_sso_sid: int | None = Query(None),
    only_completed_jobs: bool = Query(True),
    only_shared: bool = Query(True),
    order_by: list[str] | None = Query(None),
    db: sa_orm.Session = Depends(make_session),
) -> ExperimentTableDetailsAndPagination:
    with managed_db_session(db):
        if architecture is not None:
            db_architecture = (
                db
                .query(ArchitectureTable)
                .where(ArchitectureTable.expired_at.is_(None), ArchitectureTable.name == architecture)
                .one_or_none()
            )
            if db_architecture is None:
                raise sa_exc.NoResultFound(
                    f"'{model_name_of(ArchitectureTable)}' with name '{architecture}' not found")
            architecture_uuid = db_architecture.uuid
        else:
            architecture_uuid = None

        query_stmt = (
            db
            .query(ExperimentTable, TrainingTable, ExperimentPromotionTable)
            .outerjoin(TrainingTable, ExperimentTable.uuid == TrainingTable.experiment_uuid)
            .outerjoin(ExperimentPromotionTable, ExperimentTable.uuid == ExperimentPromotionTable.experiment_uuid)
            .where(ExperimentTable.expired_at.is_(None),
                   TrainingTable.expired_at.is_(None),
                   ExperimentPromotionTable.expired_at.is_(None))
        )
        if only_completed_jobs:
            query_stmt = query_stmt.where(sa.or_(TrainingTable.sqn.is_(None),
                                                 TrainingTable.flags.op("&")(JobStatusFlag.Completed.value) > 0))
        if only_shared:
            query_stmt = query_stmt.where(ExperimentPromotionTable.flags.op("&")(JobStatusFlag.Completed.value) > 0)
        if begin_at is not None:
            query_stmt = query_stmt.where(ExperimentTable.created_at >= begin_at)
        if end_at is not None:
            query_stmt = query_stmt.where(ExperimentTable.created_at < end_at)
        if architecture_uuid is not None:
            query_stmt = query_stmt.where(ExperimentTable.architecture_uuid == architecture_uuid)
        if name_match is not None:
            query_stmt = query_stmt.where(ExperimentTable.name.ilike(f"%{escape_sql_like(name_match)}%", escape="\\"))
        if contributor_sso_sid is not None:
            query_stmt = query_stmt.where(ExperimentTable.contributor_sso_sid == contributor_sso_sid)
        query_stmt = query_stmt.order_by(*db_make_order_by_clause(ExperimentTable, order_by))

        total = query_stmt.count()
        if total == 0:
            return ExperimentTableDetailsAndPagination(
                experiment_details=[],
                pagination=Pagination(skip=skip, limit=limit, total=0),
            )

        db_experiment_training_promotions = query_stmt.offset(skip).limit(limit).all()

        architecture_uuids = list(set(db_experiment.architecture_uuid
                                      for db_experiment, _, _ in db_experiment_training_promotions))
        db_architectures = (
            db
            .query(ArchitectureTable)
            .where(ArchitectureTable.expired_at.is_(None), ArchitectureTable.uuid.in_(architecture_uuids))
            .all()
        )
        db_architectures_dict = {db_architecture.uuid: db_architecture for db_architecture in db_architectures}

        dataset_uuids = list(set(db_experiment.dataset_uuid
                                 for db_experiment, _, _ in db_experiment_training_promotions))
        layout_samples_counts_by_datasets = query_layout_samples_counts(dataset_uuids, db)

        db_datasets = (
            db
            .query(DatasetTable)
            .where(DatasetTable.expired_at.is_(None), DatasetTable.uuid.in_(dataset_uuids))
            .all()
        )
        db_datasets_dict = {db_dataset.uuid: db_dataset for db_dataset in db_datasets}

        return ExperimentTableDetailsAndPagination(
            experiment_details=[
                ExperimentTableDetail(
                    experiment=db_experiment,
                    training=db_training,
                    promotion=db_promotion,
                    architecture=db_architectures_dict.get(db_experiment.architecture_uuid),
                    dataset=db_datasets_dict.get(db_experiment.dataset_uuid),
                    layouts=layout_samples_counts_by_datasets.get(db_experiment.dataset_uuid, []),
                    samples_count=sum(layout_samples_count.samples_count
                                      for layout_samples_count in
                                      layout_samples_counts_by_datasets.get(db_experiment.dataset_uuid, [])),
                )
                for db_experiment, db_training, db_promotion in db_experiment_training_promotions
            ],
            pagination=Pagination(skip=skip, limit=limit, total=total),
        )


@router.get("/get_model_experiment/{experiment_uuid}", response_model=ExperimentTableDetail)
def get_model_experiment(
    experiment_uuid: py_uuid.UUID = Path(),
    db: sa_orm.Session = Depends(make_session),
) -> ExperimentTableDetail:
    with managed_db_session(db):
        db_experiment_training_promotion = (
            db
            .query(ExperimentTable, TrainingTable, ExperimentPromotionTable)
            .outerjoin(TrainingTable, ExperimentTable.uuid == TrainingTable.experiment_uuid)
            .outerjoin(ExperimentPromotionTable, ExperimentTable.uuid == ExperimentPromotionTable.experiment_uuid)
            .where(ExperimentTable.expired_at.is_(None),
                   TrainingTable.expired_at.is_(None),
                   ExperimentPromotionTable.expired_at.is_(None),
                   ExperimentTable.uuid == experiment_uuid)
            .one_or_none()
        )
        if db_experiment_training_promotion is None:
            raise sa_exc.NoResultFound(f"'{model_name_of(ExperimentTable)}' with uuid '{experiment_uuid}' not found")

        db_experiment, db_training, db_promotion = db_experiment_training_promotion

        db_architecture = (
            db
            .query(ArchitectureTable)
            .where(ArchitectureTable.expired_at.is_(None), ArchitectureTable.uuid == db_experiment.architecture_uuid)
            .one_or_none()
        )

        layout_samples_counts_by_datasets = query_layout_samples_counts([db_experiment.dataset_uuid], db)
        layout_samples_counts = layout_samples_counts_by_datasets.get(db_experiment.dataset_uuid, [])

        db_dataset = (
            db
            .query(DatasetTable)
            .where(DatasetTable.expired_at.is_(None), DatasetTable.uuid == db_experiment.dataset_uuid)
            .one_or_none()
        )

        return ExperimentTableDetail(
            experiment=db_experiment,
            training=db_training,
            promotion=db_promotion,
            architecture=db_architecture,
            dataset=db_dataset,
            layouts=layout_samples_counts,
            samples_count=sum(layout_samples_count.samples_count for layout_samples_count in layout_samples_counts),
        )


class AssessmentTableDetail(pdt.BaseModel):
    assessment: AssessmentTable
    evaluation: EvaluationTable | None
    promotion: AssessmentPromotionTable | None
    benchmark: BenchmarkTable | None
    experiment: ExperimentTable | None
    dataset: DatasetTable | None
    layouts: list[LayoutTableAndSamplesCount] | None
    samples_count: int
    architecture: ArchitectureTable | None


class AssessmentTableDetailsAndPagination(pdt.BaseModel):
    assessment_details: list[AssessmentTableDetail]
    pagination: Pagination


@router.get("/list_model_assessments/", response_model=AssessmentTableDetailsAndPagination)
def list_model_assessments(
    skip: int = Query(0),
    limit: int = Query(100),
    begin_at: datetime.datetime | None = Query(None),
    end_at: datetime.datetime | None = Query(None),
    benchmark: str | None = Query(None),
    name_match: str | None = Query(None),
    contributor_sso_sid: int | None = Query(None),
    only_completed_jobs: bool = Query(True),
    only_shared: bool = Query(True),
    order_by: list[str] | None = Query(None),
    db: sa_orm.Session = Depends(make_session),
) -> AssessmentTableDetailsAndPagination:
    with managed_db_session(db):
        if benchmark is not None:
            db_benchmark = (
                db
                .query(BenchmarkTable)
                .where(BenchmarkTable.expired_at.is_(None), BenchmarkTable.name == benchmark)
                .one_or_none()
            )
            if db_benchmark is None:
                raise sa_exc.NoResultFound(f"'{model_name_of(BenchmarkTable)}' with name '{benchmark}' not found")
            benchmark_uuid = db_benchmark.uuid
        else:
            benchmark_uuid = None

        query_stmt = (
            db
            .query(AssessmentTable, EvaluationTable, AssessmentPromotionTable)
            .outerjoin(EvaluationTable, AssessmentTable.uuid == EvaluationTable.assessment_uuid)
            .outerjoin(AssessmentPromotionTable, AssessmentTable.uuid == AssessmentPromotionTable.assessment_uuid)
            .where(AssessmentTable.expired_at.is_(None),
                   EvaluationTable.expired_at.is_(None),
                   AssessmentPromotionTable.expired_at.is_(None))
        )
        if only_completed_jobs:
            query_stmt = query_stmt.where(sa.or_(EvaluationTable.sqn.is_(None),
                                                 EvaluationTable.flags.op("&")(JobStatusFlag.Completed.value) > 0))
        if only_shared:
            query_stmt = query_stmt.where(AssessmentPromotionTable.flags.op("&")(JobStatusFlag.Completed.value) > 0)
        if begin_at is not None:
            query_stmt = query_stmt.where(AssessmentTable.created_at >= begin_at)
        if end_at is not None:
            query_stmt = query_stmt.where(AssessmentTable.created_at < end_at)
        if benchmark_uuid is not None:
            query_stmt = query_stmt.where(AssessmentTable.benchmark_uuid == benchmark_uuid)
        if name_match is not None:
            query_stmt = query_stmt.where(AssessmentTable.name.ilike(f"%{escape_sql_like(name_match)}%", escape="\\"))
        if contributor_sso_sid is not None:
            query_stmt = query_stmt.where(AssessmentTable.contributor_sso_sid == contributor_sso_sid)
        query_stmt = query_stmt.order_by(*db_make_order_by_clause(AssessmentTable, order_by))

        total = query_stmt.count()
        if total == 0:
            return AssessmentTableDetailsAndPagination(
                assessment_details=[],
                pagination=Pagination(skip=skip, limit=limit, total=0),
            )

        db_assessment_evaluation_promotions = query_stmt.offset(skip).limit(limit).all()

        benchmark_uuids = list(set(db_assessment.benchmark_uuid
                                   for db_assessment, _, _ in db_assessment_evaluation_promotions))
        db_benchmarks = (
            db
            .query(BenchmarkTable)
            .where(BenchmarkTable.expired_at.is_(None), BenchmarkTable.uuid.in_(benchmark_uuids))
            .all()
        )
        db_benchmarks_dict = {db_benchmark.uuid: db_benchmark for db_benchmark in db_benchmarks}

        experiment_uuids = list(set(db_assessment.experiment_uuid
                                    for db_assessment, _, _ in db_assessment_evaluation_promotions))
        db_experiments = (
            db
            .query(ExperimentTable)
            .where(ExperimentTable.expired_at.is_(None), ExperimentTable.uuid.in_(experiment_uuids))
            .all()
        )
        db_experiments_dict = {db_experiment.uuid: db_experiment for db_experiment in db_experiments}

        dataset_uuids = list(set(db_assessment.dataset_uuid
                                 for db_assessment, _, _ in db_assessment_evaluation_promotions))
        layout_samples_counts_by_datasets = query_layout_samples_counts(dataset_uuids, db)

        db_datasets = (
            db
            .query(DatasetTable)
            .where(DatasetTable.expired_at.is_(None), DatasetTable.uuid.in_(dataset_uuids))
            .all()
        )
        db_datasets_dict = {db_dataset.uuid: db_dataset for db_dataset in db_datasets}

        architecture_uuids = list(set(db_experiment.architecture_uuid for db_experiment in db_experiments))
        db_architectures = (
            db
            .query(ArchitectureTable)
            .where(ArchitectureTable.expired_at.is_(None), ArchitectureTable.uuid.in_(architecture_uuids))
            .all()
        )
        db_architectures_dict = {db_architecture.uuid: db_architecture for db_architecture in db_architectures}

        return AssessmentTableDetailsAndPagination(
            assessment_details=[
                AssessmentTableDetail(
                    assessment=db_assessment,
                    evaluation=db_evaluation,
                    promotion=db_promotion,
                    benchmark=db_benchmarks_dict.get(db_assessment.benchmark_uuid),
                    experiment=db_experiments_dict.get(db_assessment.experiment_uuid),
                    dataset=db_datasets_dict.get(db_assessment.dataset_uuid),
                    layouts=layout_samples_counts_by_datasets.get(db_assessment.dataset_uuid, []),
                    samples_count=sum(layout_samples_count.samples_count
                                      for layout_samples_count in
                                      layout_samples_counts_by_datasets.get(db_assessment.dataset_uuid, [])),
                    architecture=(
                        db_architectures_dict.get(
                            db_experiments_dict.get(db_assessment.experiment_uuid).architecture_uuid)
                        if db_assessment.experiment_uuid in db_experiments_dict else None
                    ),
                )
                for db_assessment, db_evaluation, db_promotion in db_assessment_evaluation_promotions
            ],
            pagination=Pagination(skip=skip, limit=limit, total=total),
        )


@router.get("/get_model_assessment/{assessment_uuid}", response_model=AssessmentTableDetail)
def get_model_assessment(
    assessment_uuid: py_uuid.UUID = Path(),
    db: sa_orm.Session = Depends(make_session),
) -> AssessmentTableDetail:
    with managed_db_session(db):
        db_assessment_evaluation_promotion = (
            db
            .query(AssessmentTable, EvaluationTable, AssessmentPromotionTable)
            .outerjoin(EvaluationTable, AssessmentTable.uuid == EvaluationTable.assessment_uuid)
            .outerjoin(AssessmentPromotionTable, AssessmentTable.uuid == AssessmentPromotionTable.assessment_uuid)
            .where(AssessmentTable.expired_at.is_(None),
                   EvaluationTable.expired_at.is_(None),
                   AssessmentPromotionTable.expired_at.is_(None),
                   AssessmentTable.uuid == assessment_uuid)
            .one_or_none()
        )
        if db_assessment_evaluation_promotion is None:
            raise sa_exc.NoResultFound(f"'{model_name_of(AssessmentTable)}' with uuid '{assessment_uuid}' not found")

        db_assessment, db_evaluation, db_promotion = db_assessment_evaluation_promotion

        db_benchmark = (
            db
            .query(BenchmarkTable)
            .where(BenchmarkTable.expired_at.is_(None), BenchmarkTable.uuid == db_assessment.benchmark_uuid)
            .one_or_none()
        )

        db_experiment = (
            db
            .query(ExperimentTable)
            .where(ExperimentTable.expired_at.is_(None), ExperimentTable.uuid == db_assessment.experiment_uuid)
            .one_or_none()
        )

        layout_samples_counts_by_datasets = query_layout_samples_counts([db_assessment.dataset_uuid], db)
        layout_samples_counts = layout_samples_counts_by_datasets.get(db_assessment.dataset_uuid, [])

        db_dataset = (
            db
            .query(DatasetTable)
            .where(DatasetTable.expired_at.is_(None), DatasetTable.uuid == db_assessment.dataset_uuid)
            .one_or_none()
        )

        db_architecture = (
            db
            .query(ArchitectureTable)
            .where(ArchitectureTable.expired_at.is_(None), ArchitectureTable.uuid == db_experiment.architecture_uuid)
            .one_or_none()
        ) if db_experiment is not None else None

        return AssessmentTableDetail(
            assessment=db_assessment,
            evaluation=db_evaluation,
            promotion=db_promotion,
            benchmark=db_benchmark,
            experiment=db_experiment,
            dataset=db_dataset,
            layouts=layout_samples_counts,
            samples_count=sum(layout_samples_count.samples_count for layout_samples_count in layout_samples_counts),
            architecture=db_architecture,
        )


class DatasetWithSamples(pdt.BaseModel):
    dataset: Dataset
    samples: list[Sample] = pdt.Field(default_factory=list)


class DatasetTableWithSampleTables(pdt.BaseModel):
    dataset: DatasetTable
    layouts: list[LayoutTableAndSamplesCount] = pdt.Field(default_factory=list)
    samples: list[SampleTable] = pdt.Field(default_factory=list)


@router.post("/create_dataset_with_samples/", response_model=DatasetTableWithSampleTables)
def create_dataset_with_samples(
    dataset_with_samples: DatasetWithSamples = Body(),
    current_dt: datetime.datetime = Depends(current_dt_clock),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTableWithSampleTables:
    with managed_db_session(db):
        db_dataset = db_create_revision_model(db, DatasetTable, dataset_with_samples.dataset, current_dt)

        db_samples = db_create_revision_models(db, SampleTable, dataset_with_samples.samples, current_dt)
        db.add_all([DatasetSampleTable(dataset_uuid=db_dataset.uuid, sample_uuid=db_sample.uuid)
                    for db_sample in db_samples])
        db.flush()

        samples_counts = Counter(db_sample.layout_uuid for db_sample in db_samples)

        db.add_all([DatasetLayoutTable(dataset_uuid=db_dataset.uuid,
                                       layout_uuid=layout_uuid,
                                       samples_count=samples_count)
                    for layout_uuid, samples_count in samples_counts.items()])
        db.flush()

    return get_dataset_with_samples(dataset_uuid=db_dataset.uuid, db=db)


@router.post("/append_dataset_with_samples/{dataset_uuid}", response_model=DatasetTableWithSampleTables)
def append_dataset_with_samples(
    dataset_uuid: py_uuid.UUID = Path(),
    samples: list[Sample] = Body(),
    current_dt: datetime.datetime = Depends(current_dt_clock),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTableWithSampleTables:
    with managed_db_session(db):
        db_dataset = (
            db
            .query(DatasetTable)
            .where(DatasetTable.expired_at.is_(None), DatasetTable.uuid == dataset_uuid)
            .one_or_none()
        )
        if db_dataset is None:
            raise sa_exc.NoResultFound(f"'{model_name_of(DatasetTable)}' with uuid '{dataset_uuid}' not found")

        db_samples = db_create_revision_models(db, SampleTable, samples, current_dt)
        db.add_all([DatasetSampleTable(dataset_uuid=db_dataset.uuid, sample_uuid=db_sample.uuid)
                    for db_sample in db_samples])
        db.flush()

        samples_counts = Counter(db_sample.layout_uuid for db_sample in db_samples)

        db_dataset_layouts = (
            db
            .query(DatasetLayoutTable)
            .where(DatasetLayoutTable.dataset_uuid == db_dataset.uuid,
                   DatasetLayoutTable.layout_uuid.in_(list(samples_counts)))
            .all()
        )
        db_dataset_layouts_dict = {db_dataset_layout.layout_uuid: db_dataset_layout
                                   for db_dataset_layout in db_dataset_layouts}

        new_db_dataset_layouts = []
        for layout_uuid, samples_count in samples_counts.items():
            db_dataset_layout = db_dataset_layouts_dict.get(layout_uuid)
            if db_dataset_layout is None:
                new_db_dataset_layouts.append(DatasetLayoutTable(dataset_uuid=db_dataset.uuid,
                                                                 layout_uuid=layout_uuid,
                                                                 samples_count=samples_count))
            else:
                db_dataset_layout.samples_count = db_dataset_layout.samples_count + samples_count
        if new_db_dataset_layouts:
            db.add_all(new_db_dataset_layouts)
        db.flush()

    return get_dataset_with_samples(dataset_uuid=db_dataset.uuid, db=db)


@router.get("/get_dataset_with_samples/{dataset_uuid}", response_model=DatasetTableWithSampleTables)
def get_dataset_with_samples(
    dataset_uuid: py_uuid.UUID = Path(),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTableWithSampleTables:
    with managed_db_session(db):
        db_dataset = (
            db
            .query(DatasetTable)
            .where(DatasetTable.expired_at.is_(None), DatasetTable.uuid == dataset_uuid)
            .one_or_none()
        )
        if db_dataset is None:
            raise sa_exc.NoResultFound(f"'{model_name_of(DatasetTable)}' with uuid '{dataset_uuid}' not found")

        db_layout_dataset_layouts = (
            db
            .query(LayoutTable, DatasetLayoutTable)
            .join(DatasetLayoutTable, LayoutTable.uuid == DatasetLayoutTable.layout_uuid)
            .where(LayoutTable.expired_at.is_(None),
                   DatasetLayoutTable.dataset_uuid == db_dataset.uuid)
            .order_by(LayoutTable.sqn)
            .all()
        )
        layout_and_samples_counts = [LayoutTableAndSamplesCount(layout=db_layout,
                                                                samples_count=db_dataset_layout.samples_count)
                                     for db_layout, db_dataset_layout in db_layout_dataset_layouts]

        db_samples = (
            db
            .query(SampleTable)
            .join(DatasetSampleTable, SampleTable.uuid == DatasetSampleTable.sample_uuid)
            .where(SampleTable.expired_at.is_(None),
                   DatasetSampleTable.dataset_uuid == dataset_uuid)
            .order_by(SampleTable.sqn)
            .all()
        )

    return DatasetTableWithSampleTables(dataset=db_dataset, layouts=layout_and_samples_counts, samples=db_samples)


class SampleAndAnnotation(pdt.BaseModel):
    sample: Sample
    annotation: Annotation


class DatasetWithSampleAndAnnotations(pdt.BaseModel):
    dataset: Dataset
    sample_and_annotations: list[SampleAndAnnotation] = pdt.Field(default_factory=list)


class SampleTableAndAnnotationTable(pdt.BaseModel):
    sample: SampleTable
    annotation: AnnotationTable


class DatasetTableWithSampleTableAndAnnotationTables(pdt.BaseModel):
    dataset: DatasetTable
    layouts: list[LayoutTableAndSamplesCount] = pdt.Field(default_factory=list)
    sample_and_annotations: list[SampleTableAndAnnotationTable] = pdt.Field(default_factory=list)


@router.post("/create_dataset_with_sample_and_annotations/",
             response_model=DatasetTableWithSampleTableAndAnnotationTables)
def create_dataset_with_sample_and_annotations(
    dataset_with_sample_and_annotations: DatasetWithSampleAndAnnotations = Body(),
    current_dt: datetime.datetime = Depends(current_dt_clock),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTableWithSampleTableAndAnnotationTables:
    with managed_db_session(db):
        db_dataset = db_create_revision_model(db,
                                              DatasetTable,
                                              dataset_with_sample_and_annotations.dataset,
                                              current_dt)

        db_samples = db_create_revision_models(
            db,
            SampleTable,
            [sample_and_annotation.sample
             for sample_and_annotation in dataset_with_sample_and_annotations.sample_and_annotations],
            current_dt,
        )
        db_annotations = db_create_revision_models(
            db,
            AnnotationTable,
            [sample_and_annotation.annotation
             for sample_and_annotation in dataset_with_sample_and_annotations.sample_and_annotations],
            current_dt,
        )
        db.add_all([DatasetSampleTable(dataset_uuid=db_dataset.uuid,
                                       sample_uuid=db_sample.uuid,
                                       annotation_uuid=db_annotation.uuid)
                    for db_sample, db_annotation in zip(db_samples, db_annotations)])
        db.flush()

        samples_counts = Counter(db_sample.layout_uuid for db_sample in db_samples)

        db.add_all([DatasetLayoutTable(dataset_uuid=db_dataset.uuid,
                                       layout_uuid=layout_uuid,
                                       samples_count=samples_count)
                    for layout_uuid, samples_count in samples_counts.items()])
        db.flush()

    return get_dataset_with_sample_and_annotations(dataset_uuid=db_dataset.uuid, db=db)


@router.post("/append_dataset_with_sample_and_annotations/{dataset_uuid}",
             response_model=DatasetTableWithSampleTableAndAnnotationTables)
def append_dataset_with_sample_and_annotations(
    dataset_uuid: py_uuid.UUID = Path(),
    sample_and_annotations: list[SampleAndAnnotation] = Body(),
    current_dt: datetime.datetime = Depends(current_dt_clock),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTableWithSampleTableAndAnnotationTables:
    with managed_db_session(db):
        db_dataset = (
            db
            .query(DatasetTable)
            .where(DatasetTable.expired_at.is_(None), DatasetTable.uuid == dataset_uuid)
            .one_or_none()
        )
        if db_dataset is None:
            raise sa_exc.NoResultFound(f"'{model_name_of(DatasetTable)}' with uuid '{dataset_uuid}' not found")

        db_samples = db_create_revision_models(
            db,
            SampleTable,
            [sample_and_annotation.sample for sample_and_annotation in sample_and_annotations],
            current_dt,
        )
        db_annotations = db_create_revision_models(
            db,
            AnnotationTable,
            [sample_and_annotation.annotation for sample_and_annotation in sample_and_annotations],
            current_dt,
        )
        db.add_all([DatasetSampleTable(dataset_uuid=db_dataset.uuid,
                                       sample_uuid=db_sample.uuid,
                                       annotation_uuid=db_annotation.uuid)
                    for db_sample, db_annotation in zip(db_samples, db_annotations)])
        db.flush()

        samples_counts = Counter(db_sample.layout_uuid for db_sample in db_samples)

        db_dataset_layouts = (
            db
            .query(DatasetLayoutTable)
            .where(DatasetLayoutTable.dataset_uuid == db_dataset.uuid,
                   DatasetLayoutTable.layout_uuid.in_(list(samples_counts)))
            .all()
        )
        db_dataset_layouts_dict = {db_dataset_layout.layout_uuid: db_dataset_layout
                                   for db_dataset_layout in db_dataset_layouts}

        new_db_dataset_layouts = []
        for layout_uuid, samples_count in samples_counts.items():
            db_dataset_layout = db_dataset_layouts_dict.get(layout_uuid)
            if db_dataset_layout is None:
                new_db_dataset_layouts.append(DatasetLayoutTable(dataset_uuid=db_dataset.uuid,
                                                                 layout_uuid=layout_uuid,
                                                                 samples_count=samples_count))
            else:
                db_dataset_layout.samples_count = db_dataset_layout.samples_count + samples_count
        if new_db_dataset_layouts:
            db.add_all(new_db_dataset_layouts)
        db.flush()

    return get_dataset_with_sample_and_annotations(dataset_uuid=db_dataset.uuid, db=db)


@router.get("/get_dataset_with_sample_and_annotations/{dataset_uuid}",
            response_model=DatasetTableWithSampleTableAndAnnotationTables)
def get_dataset_with_sample_and_annotations(
    dataset_uuid: py_uuid.UUID = Path(),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTableWithSampleTableAndAnnotationTables:
    with managed_db_session(db):
        db_dataset = (
            db
            .query(DatasetTable)
            .where(DatasetTable.expired_at.is_(None), DatasetTable.uuid == dataset_uuid)
            .one_or_none()
        )
        if db_dataset is None:
            raise sa_exc.NoResultFound(f"'{model_name_of(DatasetTable)}' with uuid '{dataset_uuid}' not found")

        db_layout_dataset_layouts = (
            db
            .query(LayoutTable, DatasetLayoutTable)
            .join(DatasetLayoutTable, LayoutTable.uuid == DatasetLayoutTable.layout_uuid)
            .where(LayoutTable.expired_at.is_(None),
                   DatasetLayoutTable.dataset_uuid == db_dataset.uuid)
            .order_by(LayoutTable.sqn)
            .all()
        )
        layout_and_samples_counts = [LayoutTableAndSamplesCount(layout=db_layout,
                                                                samples_count=db_dataset_layout.samples_count)
                                     for db_layout, db_dataset_layout in db_layout_dataset_layouts]

        db_dataset_sample_sample_annotations = (
            db
            .query(DatasetSampleTable, SampleTable, AnnotationTable)
            .join(SampleTable, SampleTable.uuid == DatasetSampleTable.sample_uuid)
            .join(AnnotationTable, AnnotationTable.uuid == DatasetSampleTable.annotation_uuid)
            .where(SampleTable.expired_at.is_(None),
                   AnnotationTable.expired_at.is_(None),
                   DatasetSampleTable.dataset_uuid == dataset_uuid)
            .order_by(SampleTable.sqn)
            .all()
        )
        db_sample_and_annotations = [SampleTableAndAnnotationTable(sample=db_sample, annotation=db_annotation)
                                     for _, db_sample, db_annotation in db_dataset_sample_sample_annotations]

        return DatasetTableWithSampleTableAndAnnotationTables(
            dataset=db_dataset,
            layouts=layout_and_samples_counts,
            sample_and_annotations=db_sample_and_annotations,
        )


class SampleWithClassifiers(pdt.BaseModel):
    sample: Sample
    classifiers: list[Classifier] = pdt.Field(default_factory=list)


class DatasetWithSamplesWithClassifiers(pdt.BaseModel):
    dataset: Dataset
    samples_with_classifiers: list[SampleWithClassifiers] = pdt.Field(default_factory=list)


class SampleTableWithClassifierTables(pdt.BaseModel):
    sample: SampleTable
    classifiers: list[ClassifierTable] = pdt.Field(default_factory=list)


class DatasetTableWithSampleTablesWithClassifierTables(pdt.BaseModel):
    dataset: DatasetTable
    layouts: list[LayoutTableAndSamplesCount] = pdt.Field(default_factory=list)
    samples_with_classifiers: list[SampleTableWithClassifierTables] = pdt.Field(default_factory=list)


@router.post("/create_dataset_with_samples_with_classifiers",
             response_model=DatasetTableWithSampleTablesWithClassifierTables)
def create_dataset_with_samples_with_classifiers(
    dataset_with_samples_with_classifiers: DatasetWithSamplesWithClassifiers = Body(),
    current_dt: datetime.datetime = Depends(current_dt_clock),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTableWithSampleTablesWithClassifierTables:
    with managed_db_session(db):
        db_dataset = db_create_revision_model(db,
                                              DatasetTable,
                                              dataset_with_samples_with_classifiers.dataset,
                                              current_dt)

        db_samples = db_create_revision_models(
            db,
            SampleTable,
            [sample_with_classifiers.sample
             for sample_with_classifiers in dataset_with_samples_with_classifiers.samples_with_classifiers],
            current_dt,
        )
        db_classifiers = db_create_revision_models(
            db,
            ClassifierTable,
            [classifier
             for sample_with_classifiers in dataset_with_samples_with_classifiers.samples_with_classifiers
             for classifier in sample_with_classifiers.classifiers],
            current_dt,
        )
        db.add_all([DatasetSampleTable(dataset_uuid=db_dataset.uuid, sample_uuid=db_sample.uuid)
                    for db_sample in db_samples])
        db.flush()

        samples_counts = Counter(db_sample.layout_uuid for db_sample in db_samples)

        db.add_all([DatasetLayoutTable(dataset_uuid=db_dataset.uuid,
                                       layout_uuid=layout_uuid,
                                       samples_count=samples_count)
                    for layout_uuid, samples_count in samples_counts.items()])
        db.flush()

    return get_dataset_with_samples_with_classifiers(dataset_uuid=db_dataset.uuid, db=db)


@router.post("/append_dataset_with_samples_with_classifiers/{dataset_uuid}",
             response_model=DatasetTableWithSampleTablesWithClassifierTables)
def append_dataset_with_samples_with_classifiers(
    dataset_uuid: py_uuid.UUID = Path(),
    samples_with_classifiers: list[SampleWithClassifiers] = Body(),
    current_dt: datetime.datetime = Depends(current_dt_clock),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTableWithSampleTablesWithClassifierTables:
    with managed_db_session(db):
        db_dataset = (
            db
            .query(DatasetTable)
            .where(DatasetTable.expired_at.is_(None), DatasetTable.uuid == dataset_uuid)
            .one_or_none()
        )
        if db_dataset is None:
            raise sa_exc.NoResultFound(f"'{model_name_of(DatasetTable)}' with uuid '{dataset_uuid}' not found")

        db_samples = db_create_revision_models(
            db,
            SampleTable,
            [sample_with_classifiers.sample for sample_with_classifiers in samples_with_classifiers],
            current_dt,
        )
        db_classifiers = db_create_revision_models(
            db,
            ClassifierTable,
            [classifier
             for sample_with_classifiers in samples_with_classifiers
             for classifier in sample_with_classifiers.classifiers],
            current_dt,
        )
        db.add_all([DatasetSampleTable(dataset_uuid=db_dataset.uuid, sample_uuid=db_sample.uuid)
                    for db_sample in db_samples])
        db.flush()

        samples_counts = Counter(db_sample.layout_uuid for db_sample in db_samples)

        db_dataset_layouts = (
            db
            .query(DatasetLayoutTable)
            .where(DatasetLayoutTable.dataset_uuid == db_dataset.uuid,
                   DatasetLayoutTable.layout_uuid.in_(list(samples_counts)))
            .all()
        )
        db_dataset_layouts_dict = {db_dataset_layout.layout_uuid: db_dataset_layout
                                   for db_dataset_layout in db_dataset_layouts}

        new_db_dataset_layouts = []
        for layout_uuid, samples_count in samples_counts.items():
            db_dataset_layout = db_dataset_layouts_dict.get(layout_uuid)
            if db_dataset_layout is None:
                new_db_dataset_layouts.append(DatasetLayoutTable(dataset_uuid=db_dataset.uuid,
                                                                 layout_uuid=layout_uuid,
                                                                 samples_count=samples_count))
            else:
                db_dataset_layout.samples_count = db_dataset_layout.samples_count + samples_count
        if new_db_dataset_layouts:
            db.add_all(new_db_dataset_layouts)
        db.flush()

    return get_dataset_with_samples_with_classifiers(dataset_uuid=db_dataset.uuid, db=db)


@router.get("/get_dataset_with_samples_with_classifiers/{dataset_uuid}",
            response_model=DatasetTableWithSampleTablesWithClassifierTables)
def get_dataset_with_samples_with_classifiers(
    dataset_uuid: py_uuid.UUID = Path(),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTableWithSampleTablesWithClassifierTables:
    with managed_db_session(db):
        db_dataset = (
            db
            .query(DatasetTable)
            .where(DatasetTable.expired_at.is_(None), DatasetTable.uuid == dataset_uuid)
            .one_or_none()
        )
        if db_dataset is None:
            raise sa_exc.NoResultFound(f"'{model_name_of(DatasetTable)}' with uuid '{dataset_uuid}' not found")

        db_layout_dataset_layouts = (
            db
            .query(LayoutTable, DatasetLayoutTable)
            .join(DatasetLayoutTable, LayoutTable.uuid == DatasetLayoutTable.layout_uuid)
            .where(LayoutTable.expired_at.is_(None),
                   DatasetLayoutTable.dataset_uuid == db_dataset.uuid)
            .order_by(LayoutTable.sqn)
            .all()
        )
        layout_and_samples_counts = [LayoutTableAndSamplesCount(layout=db_layout,
                                                                samples_count=db_dataset_layout.samples_count)
                                     for db_layout, db_dataset_layout in db_layout_dataset_layouts]

        db_samples = (
            db
            .query(SampleTable)
            .join(DatasetSampleTable, SampleTable.uuid == DatasetSampleTable.sample_uuid)
            .where(SampleTable.expired_at.is_(None),
                   DatasetSampleTable.dataset_uuid == dataset_uuid)
            .order_by(SampleTable.sqn)
            .all()
        )
        db_classifiers = (
            db
            .query(ClassifierTable)
            .join(DatasetSampleTable, ClassifierTable.sample_uuid == DatasetSampleTable.sample_uuid)
            .where(ClassifierTable.expired_at.is_(None),
                   DatasetSampleTable.dataset_uuid == dataset_uuid)
            .order_by(ClassifierTable.sqn)
            .all()
        )
        db_samples_classifiers_dict = {}
        for db_classifier in db_classifiers:
            db_samples_classifiers_dict.setdefault(db_classifier.sample_uuid, []).append(db_classifier)
        db_samples_with_classifiers = [
            SampleTableWithClassifierTables(sample=db_sample,
                                            classifiers=db_samples_classifiers_dict.get(db_sample.uuid, []))
            for db_sample in db_samples
        ]

        return DatasetTableWithSampleTablesWithClassifierTables(
            dataset=db_dataset,
            layouts=layout_and_samples_counts,
            samples_with_classifiers=db_samples_with_classifiers,
        )


class DatasetConditions(pdt.BaseModel):
    included_dataset_uuids: list[py_uuid.UUID]
    excluded_dataset_uuids: list[py_uuid.UUID] = pdt.Field(default_factory=list)
    required_tags: list[str] = pdt.Field(default_factory=list)
    unwanted_tags: list[str] = pdt.Field(default_factory=list)


class CreateDatasetFromConditionsRequest(pdt.BaseModel):
    dataset: Dataset
    conditions: DatasetConditions


@router.post("/create_dataset_from_conditions/", response_model=DatasetTableDetail)
def create_dataset_from_conditions(
    request: CreateDatasetFromConditionsRequest = Body(),
    current_dt: datetime.datetime = Depends(current_dt_clock),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTableDetail:
    with managed_db_session(db):
        db_dataset = db_create_revision_model(db, DatasetTable, request.dataset, current_dt)

        query_stmt = (
            sa
            .select(
                sa.literal(db_dataset.uuid).label("dataset_uuid"),
                DatasetSampleTable.sample_uuid.label("sample_uuid"),
            )
            .select_from(DatasetSampleTable)
            .where(DatasetSampleTable.dataset_uuid.in_(request.conditions.included_dataset_uuids))
        )
        if request.conditions.excluded_dataset_uuids:
            query_stmt = query_stmt.where(
                DatasetSampleTable.dataset_uuid.notin_(request.conditions.excluded_dataset_uuids),
            )
        if request.conditions.required_tags or request.conditions.unwanted_tags:
            query_stmt = query_stmt.join(SampleTable, SampleTable.uuid == DatasetSampleTable.sample_uuid)
            for tag in (request.conditions.required_tags or []):
                query_stmt = query_stmt.where(SampleTable.expired_at.is_(None), SampleTable.tags.contains([tag]))
            for tag in (request.conditions.unwanted_tags or []):
                query_stmt = query_stmt.where(SampleTable.expired_at.is_(None), ~SampleTable.tags.contains([tag]))
        insert_stmt = (
            sa
            .insert(DatasetSampleTable)
            .from_select(["dataset_uuid", "sample_uuid"], query_stmt)
        )
        db.execute(insert_stmt)
        db.flush()

        query_stmt = (
            sa
            .select(
                sa.literal(db_dataset.uuid).label("dataset_uuid"),
                SampleTable.layout_uuid.label("layout_uuid"),
                sa.func.count().label("samples_count"),
            )
            .select_from(SampleTable)
            .join(DatasetSampleTable, SampleTable.uuid == DatasetSampleTable.sample_uuid)
            .where(SampleTable.expired_at.is_(None),
                   DatasetSampleTable.dataset_uuid == db_dataset.uuid)
            .group_by(SampleTable.layout_uuid)
        )
        insert_stmt = (
            sa
            .insert(DatasetLayoutTable)
            .from_select(["dataset_uuid", "layout_uuid", "samples_count"], query_stmt)
        )
        db.execute(insert_stmt)
        db.flush()

    return get_dataset(dataset_uuid=db_dataset.uuid, db=db)


class ClassifierStatItem(pdt.BaseModel):
    classifier: str
    count: int


class DatasetTableClassifierStat(pdt.BaseModel):
    dataset: DatasetTable
    items: list[ClassifierStatItem]


class DatasetTablesClassifiersStat(pdt.BaseModel):
    stats: list[DatasetTableClassifierStat]


@router.get("/stat_datasets_classifiers/", response_model=DatasetTablesClassifiersStat)
def stat_datasets_classifiers(
    dataset_uuids: list[py_uuid.UUID] = Query(),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTablesClassifiersStat:
    with managed_db_session(db):
        db_datasets = (
            db
            .query(DatasetTable)
            .where(DatasetTable.expired_at.is_(None), DatasetTable.uuid.in_(dataset_uuids))
            .all()
        )
        for dataset_uuid in dataset_uuids:
            if dataset_uuid not in set(db_dataset.uuid for db_dataset in db_datasets):
                raise sa_exc.NoResultFound(f"'{model_name_of(DatasetTable)}' with uuid '{dataset_uuid}' not found")

        stats = []
        for db_dataset in db_datasets:
            db_classifiers = (
                db
                .query(ClassifierTable)
                .join(DatasetSampleTable, ClassifierTable.sample_uuid == DatasetSampleTable.sample_uuid)
                .where(ClassifierTable.expired_at.is_(None),
                       DatasetSampleTable.dataset_uuid == db_dataset.uuid)
                .all()
            )

            counter = Counter(classifiers.get("name")
                              for db_classifier in db_classifiers
                              for classifiers in db_classifier.classifier_data.get("classifiers", [])
                              if classifiers.get("name") is not None)

            stats.append(
                DatasetTableClassifierStat(
                    dataset=db_dataset,
                    items=[ClassifierStatItem(classifier=classifier, count=count)
                           for classifier, count in sorted(counter.items())],
                )
            )

    return DatasetTablesClassifiersStat(stats=stats)


class ClassifierComparisonMetricItem(pdt.BaseModel):
    name: str
    data: float


class ClassifierComparisonMetric(pdt.BaseModel):
    dataset_uuid: py_uuid.UUID
    items: list[ClassifierComparisonMetricItem]


class ClassifierComparisonCollection(pdt.BaseModel):
    name: str
    metrics: list[ClassifierComparisonMetric]


class DatasetTablesClassifiersComparison(pdt.BaseModel):
    comparison_view: Literal["default"]
    datasets: list[DatasetTable]
    collections: list[ClassifierComparisonCollection]


class CompareDatasetClassifiersRequest(pdt.BaseModel):
    comparison_view: Literal["default"] = pdt.Field(default="default")
    dataset_uuids: list[py_uuid.UUID]


@router.post("/compare_dataset_classifiers/", response_model=DatasetTablesClassifiersComparison)
def compare_dataset_classifiers(
    request: CompareDatasetClassifiersRequest = Body(),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTablesClassifiersComparison:
    with managed_db_session(db):
        db_datasets = (
            db
            .query(DatasetTable)
            .where(DatasetTable.expired_at.is_(None), DatasetTable.uuid.in_(request.dataset_uuids))
            .all()
        )
        for dataset_uuid in request.dataset_uuids:
            if dataset_uuid not in set(db_dataset.uuid for db_dataset in db_datasets):
                raise sa_exc.NoResultFound(f"'{model_name_of(DatasetTable)}' with uuid '{dataset_uuid}' not found")

        collections = {}

        classifiers_view_query_stmt = (
            sa
            .lateral(sa.func.jsonb_array_elements(ClassifierTable.classifier_data["classifiers"]).table_valued("value"))
            .alias("classifiers")
        )

        classifier_query_stmt = (
            sa
            .select(DatasetSampleTable.dataset_uuid.label("dataset_uuid"),
                    classifiers_view_query_stmt.c.value.op("->>")("name").label("classifier_name"))
            .select_from(ClassifierTable)
            .join(DatasetSampleTable, ClassifierTable.sample_uuid == DatasetSampleTable.sample_uuid)
            .join(classifiers_view_query_stmt, sa.true())
            .where(ClassifierTable.expired_at.is_(None),
                   DatasetSampleTable.dataset_uuid.in_(request.dataset_uuids))
            .subquery()
        )

        classifier_count_query_stmt = (
            sa
            .select(classifier_query_stmt.c.dataset_uuid,
                    classifier_query_stmt.c.classifier_name,
                    sa.func.count().label("count"))
            .group_by(classifier_query_stmt.c.dataset_uuid, classifier_query_stmt.c.classifier_name)
        )

        for dataset_uuid, classifier_name, count in db.execute(classifier_count_query_stmt).all():
            *collection_name_segments, metric_name = classifier_name.split(":")
            collection_name = ":".join(collection_name_segments)
            collections.setdefault(collection_name, {}).setdefault(dataset_uuid, {}).setdefault(metric_name, 0)
            collections[collection_name][dataset_uuid][metric_name] += count

    return DatasetTablesClassifiersComparison(
        datasets=db_datasets,
        comparison_view=request.comparison_view,
        collections=[
            ClassifierComparisonCollection(
                name=collection_name,
                metrics=[
                    ClassifierComparisonMetric(dataset_uuid=dataset_uuid,
                                               items=[
                                                   ClassifierComparisonMetricItem(name=metric_name, data=metric_value)
                                                   for metric_name, metric_value in sorted(metrics.items())
                                               ])
                    for dataset_uuid, metrics in sorted(dataset_values.items())
                ],
            )
            for collection_name, dataset_values in sorted(collections.items())
        ],
    )


class CompareDatasetClassifiersWithConditionsRequest(pdt.BaseModel):
    comparison_view: Literal["default"] = pdt.Field(default="default")
    dataset_uuids: list[py_uuid.UUID]
    conditions: DatasetConditions


@router.post("/compare_dataset_classifiers_with_conditions/", response_model=DatasetTablesClassifiersComparison)
def compare_dataset_classifiers_with_conditions(
    request: CompareDatasetClassifiersWithConditionsRequest = Body(),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTablesClassifiersComparison:
    with managed_db_session(db):
        db_datasets = (
            db
            .query(DatasetTable)
            .where(DatasetTable.expired_at.is_(None), DatasetTable.uuid.in_(request.dataset_uuids))
            .all()
        )
        for dataset_uuid in request.dataset_uuids:
            if dataset_uuid not in set(db_dataset.uuid for db_dataset in db_datasets):
                raise sa_exc.NoResultFound(f"'{model_name_of(DatasetTable)}' with uuid '{dataset_uuid}' not found")

        collections = {}

        # The first query counts classifiers only for samples in datasets matching the conditions
        classifiers_view_query_stmt = (
            sa
            .lateral(sa.func.jsonb_array_elements(ClassifierTable.classifier_data["classifiers"]).table_valued("value"))
            .alias("classifiers")
        )

        classifier_query_stmt = (
            sa
            .select(
                sa.cast(sa.literal("00000000-0000-0000-0000-000000000000"), sa.UUID).label("dataset_uuid"),
                classifiers_view_query_stmt.c.value.op("->>")("name").label("classifier_name"),
            )
            .select_from(ClassifierTable)
            .join(DatasetSampleTable, ClassifierTable.sample_uuid == DatasetSampleTable.sample_uuid)
            .join(classifiers_view_query_stmt, sa.true())
            .where(ClassifierTable.expired_at.is_(None),
                   DatasetSampleTable.dataset_uuid.in_(request.dataset_uuids))
        )
        if request.conditions.included_dataset_uuids:
            classifier_query_stmt = classifier_query_stmt.where(
                DatasetSampleTable.dataset_uuid.in_(request.conditions.included_dataset_uuids),
            )
        if request.conditions.excluded_dataset_uuids:
            classifier_query_stmt = classifier_query_stmt.where(
                DatasetSampleTable.dataset_uuid.notin_(request.conditions.excluded_dataset_uuids),
            )
        if request.conditions.required_tags or request.conditions.unwanted_tags:
            classifier_query_stmt = classifier_query_stmt.join(SampleTable,
                                                               SampleTable.uuid == DatasetSampleTable.sample_uuid)
            for tag in (request.conditions.required_tags or []):
                classifier_query_stmt = classifier_query_stmt.where(SampleTable.expired_at.is_(None),
                                                                    SampleTable.tags.contains([tag]))
            for tag in (request.conditions.unwanted_tags or []):
                classifier_query_stmt = classifier_query_stmt.where(SampleTable.expired_at.is_(None),
                                                                    ~SampleTable.tags.contains([tag]))
        classifier_query_stmt = classifier_query_stmt.subquery()

        classifier_count_query_stmt = (
            sa
            .select(
                classifier_query_stmt.c.dataset_uuid,
                classifier_query_stmt.c.classifier_name,
                sa.func.count().label("count"),
            )
            .group_by(classifier_query_stmt.c.dataset_uuid, classifier_query_stmt.c.classifier_name)
        )

        for dataset_uuid, classifier_name, count in db.execute(classifier_count_query_stmt).all():
            *collection_name_segments, metric_name = classifier_name.split(":")
            collection_name = ":".join(collection_name_segments)
            collections.setdefault(collection_name, {}).setdefault(dataset_uuid, {}).setdefault(metric_name, 0)
            collections[collection_name][dataset_uuid][metric_name] += count

        # The second query counts classifiers for samples in all reference datasets
        classifier_query_stmt = (
            sa
            .select(DatasetSampleTable.dataset_uuid.label("dataset_uuid"),
                    classifiers_view_query_stmt.c.value.op("->>")("name").label("classifier_name"))
            .select_from(ClassifierTable)
            .join(DatasetSampleTable, ClassifierTable.sample_uuid == DatasetSampleTable.sample_uuid)
            .join(classifiers_view_query_stmt, sa.true())
            .where(ClassifierTable.expired_at.is_(None),
                   DatasetSampleTable.dataset_uuid.in_(request.dataset_uuids))
            .subquery()
        )

        classifier_count_query_stmt = (
            sa
            .select(
                classifier_query_stmt.c.dataset_uuid,
                classifier_query_stmt.c.classifier_name,
                sa.func.count().label("count"),
            )
            .group_by(classifier_query_stmt.c.dataset_uuid, classifier_query_stmt.c.classifier_name)
        )

        for dataset_uuid, classifier_name, count in db.execute(classifier_count_query_stmt).all():
            *collection_name_segments, metric_name = classifier_name.split(":")
            collection_name = ":".join(collection_name_segments)
            collections.setdefault(collection_name, {}).setdefault(dataset_uuid, {}).setdefault(metric_name, 0)
            collections[collection_name][dataset_uuid][metric_name] += count

    return DatasetTablesClassifiersComparison(
        datasets=db_datasets,
        comparison_view=request.comparison_view,
        collections=[ClassifierComparisonCollection(
            name=collection_name,
            metrics=[ClassifierComparisonMetric(
                dataset_uuid=dataset_uuid,
                items=[ClassifierComparisonMetricItem(
                    name=metric_name,
                    data=metric_value,
                ) for metric_name, metric_value in sorted(metrics.items())],
            ) for dataset_uuid, metrics in sorted(dataset_values.items())],
        ) for collection_name, dataset_values in sorted(collections.items())],
    )


@router.get("/get_model_experiment_lineage/{experiment_uuid}", response_model=list[ExperimentTableDetail])
def get_model_experiment_lineage(
    experiment_uuid: py_uuid.UUID = Path(),
    db: sa_orm.Session = Depends(make_session),
) -> list[ExperimentTableDetail]:
    with managed_db_session(db):
        experiment_lineage: list[ExperimentTableDetail] = []
        current_experiment_uuid = experiment_uuid
        while current_experiment_uuid is not None:
            try:
                experiment_table_detail = get_model_experiment(current_experiment_uuid, db)
            except Exception:
                experiment_table_detail = None
            if experiment_table_detail is None:
                if len(experiment_lineage) == 0:
                    raise sa_exc.NoResultFound(
                        f"'{model_name_of(ExperimentTable)}' with uuid '{experiment_uuid}' not found")
                else:
                    last_experiment_table_detail = experiment_lineage[-1]
                    raise sa_exc.NoResultFound(
                        f"'{model_name_of(ExperimentTable)}' with uuid '{last_experiment_table_detail.experiment.uuid}' has unreachable parent")
            experiment_lineage.append(experiment_table_detail)
            current_experiment_uuid = experiment_table_detail.experiment.parent_uuid

    return experiment_lineage


class DetailedMetricPivotHeader(pdt.BaseModel):
    name: str
    title_columns: list[TableColumn]
    metric_columns: list[TableColumn]


class DetailedMetricPivotTable(pdt.BaseModel):
    name: str
    title_values_sets: list[list[str]]
    metric_values_sets: list[list[float]]


@dataclasses.dataclass
class MetricsDisplayOperation(object):
    order_maker: Callable[[type[AssessmentTable]], list[Any]]
    metric_columns: list[TableColumn]
    detailed_metric_pivot_headers: list[DetailedMetricPivotHeader]
    metric_values_maker: Callable[[AssessmentTable, list[TableColumn]], list[float]]
    detailed_metric_pivot_tables_maker: Callable[
        [AssessmentTable, list[DetailedMetricPivotHeader]], list[DetailedMetricPivotTable]]


@singleton
def registered_metrics_display_operations() -> dict[str, MetricsDisplayOperation]:
    """
    Register metrics display operations for different benchmarks.

    Example:

    >>> import sqlalchemy
    >>> def order_maker(assessment_table: type[AssessmentTable]) -> list[Any]:
    ...     return [sqlalchemy.desc(assessment_table.assessment_data["accuracy"]), assessment_table.created_at.asc()]
    ...
    >>> metric_columns = [
    ...     TableColumn(name="accuracy",
    ...                 ordering=ColumnOrdering(semantic="numeric", direction="descending"),
    ...                 formatter=ColumnFormatter(syntax="python_format", template="{:.2%}")),
    ...     TableColumn(name="error_rate",
    ...                 ordering=ColumnOrdering(semantic="numeric", direction="ascending"),
    ...                 formatter=ColumnFormatter(syntax="python_format", template="{:.2%}")),
    ...     TableColumn(name="created_at",
    ...                 ordering=ColumnOrdering(semantic="datetime", direction="ascending"),
    ...                 formatter=ColumnFormatter(syntax="python_strftime", template="%Y-%m-%d %H:%M:%S")),
    ... ]
    ...
    >>> detailed_metric_pivot_headers = [
    ...     DetailedMetricPivotHeader(
    ...         name="per_class_metrics",
    ...         title_columns=[
    ...             TableColumn(name="class",
    ...                         ordering=ColumnOrdering(semantic="lexical", direction="ascending"),
    ...                         formatter=ColumnFormatter(syntax="python_format", template="{}")),
    ...         ],
    ...         metric_columns=[
    ...             TableColumn(name="accuracy",
    ...                         ordering=ColumnOrdering(semantic="numeric", direction="descending"),
    ...                         formatter=ColumnFormatter(syntax="python_format", template="{:.2%}")),
    ...             TableColumn(name="error_rate",
    ...                         ordering=ColumnOrdering(semantic="numeric", direction="ascending"),
    ...                         formatter=ColumnFormatter(syntax="python_format", template="{:.2%}")),
    ...         ],
    ...     ),
    ... ]
    ...
    >>> def metric_values_maker(assessment: AssessmentTable, columns: list[TableColumn]) -> list[float]:
    ...     return [
    ...         assessment.assessment_data.get("accuracy", 0.0),
    ...         assessment.assessment_data.get("error_rate", 0.0),
    ...         assessment.created_at,
    ...     ]
    ...
    >>> def detailed_metric_pivot_tables_maker(
    ...     assessment: AssessmentTable,
    ...     headers: list[DetailedMetricPivotHeader],
    ... ) -> list[DetailedMetricPivotTable]:
    ...     pivot_tables = []
    ...     for header in headers:
    ...         pivot_data = assessment.assessment_data.get(header.name, {})
    ...         title_values_sets = [[class_name] for class_name in sorted(pivot_data.keys())]
    ...         metric_values_sets = [[pivot_data[class_name].get("accuracy", 0.0),
    ...                                pivot_data[class_name].get("error_rate", 0.0),
    ...                                ]
    ...                               for class_name in sorted(pivot_data.keys())]
    ...         # You don't need to validate data dimensions here, as they will be validated by the caller.
    ...         pivot_tables.append(
    ...             DetailedMetricPivotTable(
    ...                 name="per_class_metrics",
    ...                 title_values_sets=title_values_sets,
    ...                 metric_values_sets=metric_values_sets,
    ...             )
    ...         )
    ...     return pivot_tables
    ...
    >>> registered_metrics_display_operations()["my/benchmark"] = MetricsDisplayOperation(
    ...     order_maker,
    ...     metric_columns,
    ...     detailed_metric_pivot_headers,
    ...     metric_values_maker,
    ...     detailed_metric_pivot_tables_maker,
    ... )

    :return: A dictionary mapping benchmark names to their corresponding ``MetricsOperation``.
    """
    return {}


class AssessmentTableDetailWithMetricValues(pdt.BaseModel):
    assessment_detail: AssessmentTableDetail
    metric_columns: list[TableColumn]
    metric_values: list[float] = pdt.Field(default_factory=list)
    detailed_metric_pivot_headers: list[DetailedMetricPivotHeader]
    detailed_metric_pivot_tables: list[DetailedMetricPivotTable] = pdt.Field(default_factory=list)


@router.get("/list_model_assessments_of/{experiment_uuid}",
            response_model=list[AssessmentTableDetailWithMetricValues])
def list_model_assessments_of(
    experiment_uuid: py_uuid.UUID = Path(),
    db: sa_orm.Session = Depends(make_session),
) -> list[AssessmentTableDetail]:
    with managed_db_session(db):
        db_assessment_evaluation_promotions = (
            db
            .query(AssessmentTable, EvaluationTable, AssessmentPromotionTable)
            .outerjoin(EvaluationTable, AssessmentTable.uuid == EvaluationTable.assessment_uuid)
            .outerjoin(AssessmentPromotionTable, AssessmentTable.uuid == AssessmentPromotionTable.assessment_uuid)
            .where(AssessmentTable.expired_at.is_(None),
                   EvaluationTable.expired_at.is_(None),
                   AssessmentPromotionTable.expired_at.is_(None),
                   AssessmentTable.experiment_uuid == experiment_uuid)
            .order_by(AssessmentTable.created_at.desc())
            .all()
        )
        if not db_assessment_evaluation_promotions:
            raise sa_exc.NoResultFound(
                f"'{model_name_of(ExperimentTable)}' of experiment_uuid '{experiment_uuid}' not found")

        benchmark_uuids = list(set(db_assessment.benchmark_uuid
                                   for db_assessment, _, _ in db_assessment_evaluation_promotions))
        db_benchmarks = (
            db
            .query(BenchmarkTable)
            .where(BenchmarkTable.expired_at.is_(None), BenchmarkTable.uuid.in_(benchmark_uuids))
            .all()
        )
        db_benchmarks_dict = {db_benchmark.uuid: db_benchmark for db_benchmark in db_benchmarks}

        dataset_uuids = list(set(db_assessment.dataset_uuid
                                 for db_assessment, _, _ in db_assessment_evaluation_promotions))
        layout_samples_counts_by_datasets = query_layout_samples_counts(dataset_uuids, db)

        db_datasets = (
            db
            .query(DatasetTable)
            .where(DatasetTable.expired_at.is_(None), DatasetTable.uuid.in_(dataset_uuids))
            .all()
        )
        db_datasets_dict = {db_dataset.uuid: db_dataset for db_dataset in db_datasets}

        result = []

        for db_assessment, db_evaluation, db_promotion in db_assessment_evaluation_promotions:
            db_benchmark = db_benchmarks_dict.get(db_assessment.benchmark_uuid)
            metrics_display_operation = registered_metrics_display_operations().get(db_benchmark.name)

            def metric_values_maker(assessment: AssessmentTable, columns: list[TableColumn]) -> list[float]:
                metric_values = metrics_display_operation.metric_values_maker(assessment, columns)
                if len(metric_values) != len(columns):
                    raise ValueError("mismatched metric columns and metric values lengths")
                return metric_values

            def detailed_metric_pivot_tables_maker(
                assessment: AssessmentTable,
                headers: list[DetailedMetricPivotHeader],
            ) -> list[DetailedMetricPivotTable]:
                pivot_tables = metrics_display_operation.detailed_metric_pivot_tables_maker(assessment, headers)
                if len(pivot_tables) != len(headers):
                    raise ValueError("mismatched detailed metric pivot headers and pivot tables lengths")
                for header, pivot_table in zip(headers, pivot_tables):
                    if len(pivot_table.title_values_sets) != len(pivot_table.metric_values_sets):
                        raise ValueError("mismatched title values sets and metric values sets lengths")
                    for title_values in pivot_table.title_values_sets:
                        if len(title_values) != len(header.title_columns):
                            raise ValueError("mismatched title columns and title values lengths")
                    for metric_values in pivot_table.metric_values_sets:
                        if len(metric_values) != len(header.metric_columns):
                            raise ValueError("mismatched metric columns and metric values lengths")
                return pivot_tables

            result.append(
                AssessmentTableDetailWithMetricValues(
                    assessment_detail=AssessmentTableDetail(
                        assessment=db_assessment,
                        evaluation=db_evaluation,
                        promotion=db_promotion,
                        benchmark=db_benchmarks_dict.get(db_assessment.benchmark_uuid),
                        experiment=None,
                        dataset=db_datasets_dict.get(db_assessment.dataset_uuid),
                        layouts=layout_samples_counts_by_datasets.get(db_assessment.dataset_uuid, []),
                        samples_count=sum(layout_samples_count.samples_count
                                          for layout_samples_count in
                                          layout_samples_counts_by_datasets.get(db_assessment.dataset_uuid, [])),
                        architecture=None,
                    ),
                    metric_columns=metrics_display_operation.metric_columns,
                    metric_values=metric_values_maker(
                        db_assessment,
                        metrics_display_operation.metric_columns,
                    ),
                    detailed_metric_pivot_headers=metrics_display_operation.detailed_metric_pivot_headers,
                    detailed_metric_pivot_tables=detailed_metric_pivot_tables_maker(
                        db_assessment,
                        metrics_display_operation.detailed_metric_pivot_headers,
                    ),
                )
            )

        return result


class AssessmentTableDetailWithRankingMetricValues(pdt.BaseModel):
    assessment_detail: AssessmentTableDetail
    metric_values: list[float] = pdt.Field(default_factory=list)
    detailed_metric_pivot_tables: list[DetailedMetricPivotTable] = pdt.Field(default_factory=list)


class AssessmentTableDetailWithRankingMetricValuesAndPagination(pdt.BaseModel):
    metric_columns: list[TableColumn]
    detailed_metric_pivot_headers: list[DetailedMetricPivotHeader]
    assessment_details_with_metrics: list[AssessmentTableDetailWithRankingMetricValues]
    pagination: Pagination


@router.get("/benchmark_rankings/", response_model=AssessmentTableDetailWithRankingMetricValuesAndPagination)
def benchmark_rankings(
    benchmark: str = Query(),
    skip: int = Query(0),
    limit: int = Query(1000),
    begin_at: datetime.datetime | None = Query(None),
    end_at: datetime.datetime | None = Query(None),
    name_match: str | None = Query(None),
    contributor_sso_sid: int | None = Query(None),
    only_completed_jobs: bool = Query(True),
    only_shared: bool = Query(True),
    db: sa_orm.Session = Depends(make_session),
) -> AssessmentTableDetailWithRankingMetricValuesAndPagination:
    with managed_db_session(db):
        metrics_display_operation = registered_metrics_display_operations().get(benchmark)
        if metrics_display_operation is None:
            raise ValueError(f"missing ranking metrics registered for benchmark '{benchmark}'")

        def metric_values_maker(assessment: AssessmentTable, columns: list[TableColumn]) -> list[float]:
            metric_values = metrics_display_operation.metric_values_maker(assessment, columns)
            if len(metric_values) != len(columns):
                raise ValueError("mismatched metric columns and metric values lengths")
            return metric_values

        def detailed_metric_pivot_tables_maker(
            assessment: AssessmentTable,
            headers: list[DetailedMetricPivotHeader],
        ) -> list[DetailedMetricPivotTable]:
            pivot_tables = metrics_display_operation.detailed_metric_pivot_tables_maker(assessment, headers)
            if len(pivot_tables) != len(headers):
                raise ValueError("mismatched detailed metric pivot headers and pivot tables lengths")
            for header, pivot_table in zip(headers, pivot_tables):
                if len(pivot_table.title_values_sets) != len(pivot_table.metric_values_sets):
                    raise ValueError("mismatched title values sets and metric values sets lengths")
                for title_values in pivot_table.title_values_sets:
                    if len(title_values) != len(header.title_columns):
                        raise ValueError("mismatched title columns and title values lengths")
                for metric_values in pivot_table.metric_values_sets:
                    if len(metric_values) != len(header.metric_columns):
                        raise ValueError("mismatched metric columns and metric values lengths")
            return pivot_tables

        db_benchmark = (
            db
            .query(BenchmarkTable)
            .where(BenchmarkTable.expired_at.is_(None), BenchmarkTable.name == benchmark)
            .one_or_none()
        )
        if db_benchmark is None:
            raise sa_exc.NoResultFound(f"'{model_name_of(BenchmarkTable)}' with name '{benchmark}' not found")

        query_stmt = (
            db
            .query(AssessmentTable, EvaluationTable, AssessmentPromotionTable)
            .outerjoin(EvaluationTable, AssessmentTable.uuid == EvaluationTable.assessment_uuid)
            .outerjoin(AssessmentPromotionTable, AssessmentTable.uuid == AssessmentPromotionTable.assessment_uuid)
            .where(AssessmentTable.expired_at.is_(None),
                   EvaluationTable.expired_at.is_(None),
                   AssessmentPromotionTable.expired_at.is_(None),
                   AssessmentTable.benchmark_uuid == db_benchmark.uuid)
        )
        if only_completed_jobs:
            query_stmt = query_stmt.where(sa.or_(EvaluationTable.sqn.is_(None),
                                                 EvaluationTable.flags.op("&")(JobStatusFlag.Completed.value) > 0))
        if only_shared:
            query_stmt = query_stmt.where(AssessmentPromotionTable.flags.op("&")(JobStatusFlag.Completed.value) > 0)
        if begin_at is not None:
            query_stmt = query_stmt.where(AssessmentTable.created_at >= begin_at)
        if end_at is not None:
            query_stmt = query_stmt.where(AssessmentTable.created_at < end_at)
        if name_match is not None:
            query_stmt = query_stmt.where(AssessmentTable.name.ilike(f"%{escape_sql_like(name_match)}%", escape="\\"))
        if contributor_sso_sid is not None:
            query_stmt = query_stmt.where(AssessmentTable.contributor_sso_sid == contributor_sso_sid)

        total = query_stmt.count()
        if total == 0:
            return AssessmentTableDetailWithRankingMetricValuesAndPagination(
                metric_columns=metrics_display_operation.metric_columns,
                detailed_metric_pivot_headers=metrics_display_operation.detailed_metric_pivot_headers,
                assessment_details_with_metrics=[],
                pagination=Pagination(skip=skip, limit=limit, total=0),
            )

        if contributor_sso_sid is None:
            query_stmt = query_stmt.order_by(*metrics_display_operation.order_maker(AssessmentTable))
        else:
            query_stmt = query_stmt.order_by(AssessmentTable.sqn)

        db_assessment_evaluation_promotions = query_stmt.offset(skip).limit(limit).all()

        benchmark_uuids = list(set(db_assessment.benchmark_uuid
                                   for db_assessment, _, _ in db_assessment_evaluation_promotions))
        db_benchmarks = (
            db
            .query(BenchmarkTable)
            .where(BenchmarkTable.expired_at.is_(None), BenchmarkTable.uuid.in_(benchmark_uuids))
            .all()
        )
        db_benchmarks_dict = {db_benchmark.uuid: db_benchmark for db_benchmark in db_benchmarks}

        experiment_uuids = list(set(db_assessment.experiment_uuid
                                    for db_assessment, _, _ in db_assessment_evaluation_promotions))
        db_experiments = (
            db
            .query(ExperimentTable)
            .where(ExperimentTable.expired_at.is_(None), ExperimentTable.uuid.in_(experiment_uuids))
            .all()
        )
        db_experiments_dict = {db_experiment.uuid: db_experiment for db_experiment in db_experiments}

        dataset_uuids = list(set(db_assessment.dataset_uuid
                                 for db_assessment, _, _ in db_assessment_evaluation_promotions))
        layout_samples_counts_by_datasets = query_layout_samples_counts(dataset_uuids, db)

        db_datasets = (
            db
            .query(DatasetTable)
            .where(DatasetTable.expired_at.is_(None), DatasetTable.uuid.in_(dataset_uuids))
            .all()
        )
        db_datasets_dict = {db_dataset.uuid: db_dataset for db_dataset in db_datasets}

        architecture_uuids = list(set(db_experiment.architecture_uuid for db_experiment in db_experiments))
        db_architectures = (
            db
            .query(ArchitectureTable)
            .where(ArchitectureTable.expired_at.is_(None), ArchitectureTable.uuid.in_(architecture_uuids))
            .all()
        )
        db_architectures_dict = {db_architecture.uuid: db_architecture for db_architecture in db_architectures}

        return AssessmentTableDetailWithRankingMetricValuesAndPagination(
            metric_columns=metrics_display_operation.metric_columns,
            detailed_metric_pivot_headers=metrics_display_operation.detailed_metric_pivot_headers,
            assessment_details_with_metrics=[
                AssessmentTableDetailWithRankingMetricValues(
                    assessment_detail=AssessmentTableDetail(
                        assessment=db_assessment,
                        evaluation=db_evaluation,
                        promotion=db_promotion,
                        benchmark=db_benchmarks_dict.get(db_assessment.benchmark_uuid),
                        experiment=db_experiments_dict.get(db_assessment.experiment_uuid),
                        dataset=db_datasets_dict.get(db_assessment.dataset_uuid),
                        layouts=layout_samples_counts_by_datasets.get(db_assessment.dataset_uuid, []),
                        samples_count=sum(layout_samples_count.samples_count
                                          for layout_samples_count in
                                          layout_samples_counts_by_datasets.get(db_assessment.dataset_uuid, [])),
                        architecture=(
                            db_architectures_dict.get(
                                db_experiments_dict.get(db_assessment.experiment_uuid).architecture_uuid)
                            if db_assessment.experiment_uuid in db_experiments_dict else None
                        ),
                    ),
                    metric_values=metric_values_maker(
                        db_assessment,
                        metrics_display_operation.metric_columns,
                    ),
                    detailed_metric_pivot_tables=detailed_metric_pivot_tables_maker(
                        db_assessment,
                        metrics_display_operation.detailed_metric_pivot_headers,
                    ),
                )
                for db_assessment, db_evaluation, db_promotion in db_assessment_evaluation_promotions
            ],
            pagination=Pagination(skip=skip, limit=limit, total=total),
        )


class SamplesCountByLayout(pdt.BaseModel):
    layout: LayoutTable
    count: int


class ExperimentsCountByArchitecture(pdt.BaseModel):
    architecture: ArchitectureTable
    count: int


class AssessmentsCountByBenchmark(pdt.BaseModel):
    benchmark: BenchmarkTable
    count: int


class Dashboard(pdt.BaseModel):
    samples_counts_by_layouts: list[SamplesCountByLayout]
    experiments_counts_by_architectures: list[ExperimentsCountByArchitecture]
    assessments_counts_by_benchmarks: list[AssessmentsCountByBenchmark]
    samples_counts_by_layouts_for_annotation: list[SamplesCountByLayout] = pdt.Field(default_factory=list)
    samples_counts_by_layouts_for_evaluation: list[SamplesCountByLayout] = pdt.Field(default_factory=list)


@router.get("/dashboard/", response_model=Dashboard)
def dashboard(db: sa_orm.Session = Depends(make_session)) -> Dashboard:
    with managed_db_session(db):
        def compute_samples_counts_by_layouts():
            counts_query_stmt = (
                db
                .query(SampleTable.layout_uuid, sa.func.count().label("counts"))
                .where(SampleTable.expired_at.is_(None))
                .group_by(SampleTable.layout_uuid)
                .subquery()
            )

            counts = (
                db
                .query(LayoutTable, sa.func.coalesce(counts_query_stmt.c.counts, 0))
                .where(LayoutTable.expired_at.is_(None))
                .outerjoin(counts_query_stmt, LayoutTable.uuid == counts_query_stmt.c.layout_uuid)
                .order_by(LayoutTable.sqn)
                .all()
            )

            return [SamplesCountByLayout(layout=db_layout, count=count) for db_layout, count in counts]

        def compute_experiments_counts_by_architectures():
            counts_query_stmt = (
                db
                .query(ExperimentTable.architecture_uuid, sa.func.count().label("counts"))
                .where(ExperimentTable.expired_at.is_(None))
                .group_by(ExperimentTable.architecture_uuid)
                .subquery()
            )

            counts = (
                db
                .query(ArchitectureTable, sa.func.coalesce(counts_query_stmt.c.counts, 0))
                .where(ArchitectureTable.expired_at.is_(None))
                .outerjoin(counts_query_stmt, ArchitectureTable.uuid == counts_query_stmt.c.architecture_uuid)
                .order_by(ArchitectureTable.sqn)
                .all()
            )

            return [ExperimentsCountByArchitecture(architecture=db_architecture, count=count)
                    for db_architecture, count in counts]

        def compute_assessments_counts_by_benchmarks():
            counts_query_stmt = (
                db
                .query(AssessmentTable.benchmark_uuid, sa.func.count().label("counts"))
                .where(AssessmentTable.expired_at.is_(None))
                .group_by(AssessmentTable.benchmark_uuid)
                .subquery()
            )

            counts = (
                db
                .query(BenchmarkTable, sa.func.coalesce(counts_query_stmt.c.counts, 0))
                .where(BenchmarkTable.expired_at.is_(None))
                .outerjoin(counts_query_stmt, BenchmarkTable.uuid == counts_query_stmt.c.benchmark_uuid)
                .order_by(BenchmarkTable.sqn)
                .all()
            )

            return [AssessmentsCountByBenchmark(benchmark=db_benchmark, count=count)
                    for db_benchmark, count in counts]

        return Dashboard(
            samples_counts_by_layouts=compute_samples_counts_by_layouts(),
            experiments_counts_by_architectures=compute_experiments_counts_by_architectures(),
            assessments_counts_by_benchmarks=compute_assessments_counts_by_benchmarks(),
        )


class Tagset(pdt.BaseModel):
    namespace: str
    tags: list[str]

    @pdt.field_validator("namespace", mode="after")
    @classmethod
    def validate_namespace(cls, v: str) -> str:
        if v not in predefined_tagsets():
            raise ValueError(f"invalid tagset namespace '{v}'")
        return v


@router.get("/get_tagset/", response_model=Tagset)
def get_tagset(namespace: str = Query("universal")) -> Tagset:
    if namespace not in predefined_tagsets():
        raise ValueError(f"invalid tagset namespace '{namespace}'")

    predefined_tagset = predefined_tagsets()[namespace]

    return Tagset(namespace=predefined_tagset.namespace, tags=[tag.name for tag in predefined_tagset.tags])
