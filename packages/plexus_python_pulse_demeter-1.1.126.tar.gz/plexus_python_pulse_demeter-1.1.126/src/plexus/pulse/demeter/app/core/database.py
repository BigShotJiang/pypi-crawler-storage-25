from collections.abc import Generator

import sqlalchemy as sa
import sqlalchemy.orm as sa_orm
from pydantic_settings import BaseSettings

from plexus.pulse.demeter.utils.config import config


class Settings(BaseSettings):
    host: str = config().get("pulse.apps.database", "host", "localhost")
    port: int = config().getint("pulse.apps.database", "port", 5432)
    username: str = config().get("pulse.apps.database", "username", "pulse")
    password: str = config().get("pulse.apps.database", "password", "pulse")
    database: str = config().get("pulse.apps.database", "database", "pulse-apps")

    class Config:
        env_prefix = "PULSE_APPS_DATABASE_"
        env_file = ".env"


settings = Settings()

url = sa.URL.create(
    drivername="postgresql+psycopg",
    host=settings.host,
    port=settings.port,
    username=settings.username,
    password=settings.password,
    database=settings.database,
)

engine = sa.create_engine(url, echo=True, future=True)
session_maker = sa_orm.sessionmaker(autocommit=False, autoflush=False, bind=engine, future=True, expire_on_commit=False)


def make_session() -> Generator[sa_orm.Session, None, None]:
    db = session_maker()
    db.execute(sa.sql.text("SET TIMEZONE TO 'UTC'"))
    try:
        yield db
    finally:
        db.close()
