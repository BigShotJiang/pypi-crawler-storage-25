import datetime
import typing
import uuid as py_uuid
from typing import Self

import pydantic as pdt
import sqlalchemy as sa
import sqlalchemy.dialects.postgresql as sa_pg
import sqlalchemy.orm as sa_orm
from plexus.common.utils.jsonutils import JsonObject
from plexus.pulse.common.utils.datautils import (
    validate_bag_name,
    validate_colon_tag,
    validate_dt_timezone,
    validate_hex_string,
    validate_json_type_dump_size,
    validate_kebab_case,
    validate_slash_tag,
    validate_snake_case,
    validate_strict_relpath,
    validate_vehicle_name,
    validate_vin_code,
)
from plexus.pulse.common.utils.jsonutils import json_datetime_encoder
from plexus.pulse.common.utils.ormutils import RevisionModelMixinProtocol
from plexus.pulse.common.utils.ormutils import make_revision_model_mixin, revision_model_mixin
from sqlmodel import Field, SQLModel

from plexus.pulse.demeter.app.models.registry import RegistryBase

__all__ = [
    "VehicleTemplate",
    "SensorTemplate",
    "Vehicle",
    "Sensor",
    "RegisteredBag",
    "VehicleTemplateTable",
    "SensorTemplateTable",
    "VehicleTable",
    "SensorTable",
    "RegisteredBagTable",
]


class VehicleTemplate(RegistryBase):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the vehicle template",
    )
    vehicle_type: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(64), nullable=False),
        description="Type of the vehicle template",
    )
    manufacturer: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(128), nullable=False),
        description="Manufacturer of the vehicle template",
    )
    model_name: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(128), nullable=False),
        description="Model name of the vehicle template",
    )
    model_code: str | None = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(64)),
        default=None,
        description="Model code of the vehicle template",
    )
    production_stage: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(64), nullable=False),
        description="Production stage of the vehicle template",
    )
    specification: JsonObject = Field(
        sa_column=sa.Column(sa_pg.JSONB, nullable=False),
        description="Specification of the vehicle template in JSON format",
    )

    @pdt.field_validator("vehicle_type", mode="after")
    @classmethod
    def validate_vehicle_type(cls, v: str) -> str:
        validate_slash_tag(v)
        return v

    @pdt.field_validator("manufacturer", mode="after")
    @classmethod
    def validate_manufacturer(cls, v: str) -> str:
        validate_snake_case(v)
        return v

    @pdt.field_validator("model_name", mode="after")
    @classmethod
    def validate_model_name(cls, v: str) -> str:
        validate_slash_tag(v)
        return v

    @pdt.field_validator("model_code", mode="after")
    @classmethod
    def validate_model_code(cls, v: str | None) -> str | None:
        if v is not None:
            validate_slash_tag(v)
        return v

    @pdt.field_validator("production_stage", mode="after")
    @classmethod
    def validate_production_stage(cls, v: str) -> str:
        validate_snake_case(v)
        return v


class SensorTemplate(RegistryBase):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the sensor template",
    )
    sensor_type: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(64), nullable=False),
        description="Type of the sensor template",
    )
    manufacturer: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(128), nullable=False),
        description="Manufacturer of the sensor template",
    )
    model_name: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(128), nullable=False),
        description="Model name of the sensor template",
    )
    model_code: str | None = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(64)),
        default=None,
        description="Model code of the sensor template",
    )
    production_stage: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(64), nullable=False),
        description="Production stage of the sensor template",
    )
    specification: JsonObject = Field(
        sa_column=sa.Column(sa_pg.JSONB, nullable=False),
        description="Specification of the sensor template in JSON format",
    )

    @pdt.field_validator("sensor_type", mode="after")
    @classmethod
    def validate_sensor_type(cls, v: str) -> str:
        validate_slash_tag(v)
        return v

    @pdt.field_validator("manufacturer", mode="after")
    @classmethod
    def validate_manufacturer(cls, v: str) -> str:
        validate_snake_case(v)
        return v

    @pdt.field_validator("model_name", mode="after")
    @classmethod
    def validate_model_name(cls, v: str) -> str:
        validate_slash_tag(v)
        return v

    @pdt.field_validator("model_code", mode="after")
    @classmethod
    def validate_model_code(cls, v: str | None) -> str | None:
        if v is not None:
            validate_slash_tag(v)
        return v

    @pdt.field_validator("production_stage", mode="after")
    @classmethod
    def validate_production_stage(cls, v: str) -> str:
        validate_snake_case(v)
        return v


class Vehicle(RegistryBase):
    vin_code: str = Field(
        sa_column=sa.Column(sa_pg.CHAR(17), nullable=False),
        description="Vehicle Identification Number (VIN) of the vehicle",
    )
    asset_id: str | None = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(128)),
        default=None,
        description="Asset ID of the vehicle",
    )
    vehicle_template_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the associated vehicle template",
    )
    name: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(256), nullable=False),
        description="Name of the vehicle",
    )
    purchase_date: datetime.date | None = Field(
        sa_column=sa.Column(sa_pg.DATE),
        default=None,
        description="Date of purchase of the vehicle",
    )
    tags: list[str] | None = Field(
        sa_column=sa.Column(sa_pg.ARRAY(sa_pg.VARCHAR(64))),
        default=None,
        description="Array of tags for categorization",
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional JSON properties",
    )

    @pdt.field_validator("vin_code", mode="after")
    @classmethod
    def validate_vin_code(cls, v: str) -> str:
        validate_vin_code(v)
        return v

    @pdt.field_validator("asset_id", mode="after")
    @classmethod
    def validate_asset_id(cls, v: str | None) -> str | None:
        if v is not None:
            validate_kebab_case(v)
        return v

    @pdt.field_validator("name", mode="after")
    @classmethod
    def validate_name(cls, v: str) -> str:
        validate_vehicle_name(v)
        return v

    @pdt.field_validator("tags", mode="after")
    @classmethod
    def validate_colon_tags(cls, v: list[str] | None) -> list[str] | None:
        for tag in (v or []):
            validate_colon_tag(tag)
        return v

    @pdt.field_validator("props", mode="after")
    @classmethod
    def validate_props(cls, v: JsonObject | None) -> JsonObject | None:
        if v is not None:
            validate_json_type_dump_size(v, 10000)
        return v


class Sensor(RegistryBase):
    uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the sensor",
    )
    asset_id: str | None = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(128)),
        default=None,
        description="Asset ID of the sensor",
    )
    sensor_template_uuid: py_uuid.UUID = Field(
        sa_column=sa.Column(sa_pg.UUID(as_uuid=True), nullable=False),
        description="UUID of the associated sensor template",
    )
    serial_number: str | None = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(128), nullable=False),
        description="Serial number of the sensor",
    )
    purchase_date: datetime.date | None = Field(
        sa_column=sa.Column(sa_pg.DATE),
        default=None,
        description="Date of purchase of the sensor",
    )
    tags: list[str] | None = Field(
        sa_column=sa.Column(sa_pg.ARRAY(sa_pg.VARCHAR(64))),
        default=None,
        description="Array of tags for categorization",
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional JSON properties",
    )

    @pdt.field_validator("asset_id", mode="after")
    @classmethod
    def validate_asset_id(cls, v: str | None) -> str | None:
        if v is not None:
            validate_kebab_case(v)
        return v

    @pdt.field_validator("props", mode="after")
    @classmethod
    def validate_props(cls, v: JsonObject | None) -> JsonObject | None:
        if v is not None:
            validate_json_type_dump_size(v, 10000)
        return v


class RegisteredBag(RegistryBase):
    name: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(256), nullable=False),
        description="Name of the bag",
    )
    path: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(512), nullable=False),
        description="Stored path of the bag",
    )
    vehicle_vin_code: str = Field(
        sa_column=sa.Column(sa_pg.CHAR(17), nullable=False),
        description="Vehicle Identification Number (VIN) of the associated vehicle",
    )
    vehicle_name: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(256), nullable=False),
        description="Name of the associated vehicle",
    )
    begin_at: datetime.datetime = Field(
        sa_column=sa.Column(sa_pg.TIMESTAMP(timezone=True), nullable=False),
        description="Begin datetime of the data capture",
    )
    end_at: datetime.datetime = Field(
        sa_column=sa.Column(sa_pg.TIMESTAMP(timezone=True), nullable=False),
        description="End datetime of the data capture",
    )
    file_size: int = Field(
        sa_column=sa.Column(sa_pg.BIGINT, nullable=False),
        description="Size of the bag file in bytes",
    )
    file_checksum: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(256), nullable=False),
        description="SHA256 checksum of the bag file",
    )
    flags: int = Field(
        sa_column=sa.Column(sa_pg.BIGINT),
        default=0,
        description="Integer bitmask storing status or metadata flags for this record",
    )
    tags: list[str] | None = Field(
        sa_column=sa.Column(sa_pg.ARRAY(sa_pg.VARCHAR(64))),
        default=None,
        description="Array of tags for categorization",
    )
    props: JsonObject | None = Field(
        sa_column=sa.Column(sa_pg.JSONB),
        default=None,
        description="Additional JSON properties",
    )

    @pdt.field_validator("name", mode="after")
    @classmethod
    def validate_name(cls, v: str) -> str:
        validate_bag_name(v)
        return v

    @pdt.field_validator("path", mode="after")
    @classmethod
    def validate_path(cls, v: str) -> str:
        validate_strict_relpath(v)
        return v

    @pdt.field_validator("vehicle_vin_code", mode="after")
    @classmethod
    def validate_vehicle_vin_code(cls, v: str) -> str:
        validate_vin_code(v)
        return v

    @pdt.field_validator("vehicle_name", mode="after")
    @classmethod
    def validate_vehicle_name(cls, v: str) -> str:
        validate_vehicle_name(v)
        return v

    @pdt.field_validator("begin_at", mode="after")
    @classmethod
    def validate_begin_at(cls, v: datetime.datetime) -> datetime.datetime:
        validate_dt_timezone(v)
        return v

    @pdt.field_validator("end_at", mode="after")
    @classmethod
    def validate_end_at(cls, v: datetime.datetime) -> datetime.datetime:
        validate_dt_timezone(v)
        return v

    @pdt.model_validator(mode="after")
    def validate_begin_at_end_at(self) -> Self:
        if self.begin_at > self.end_at:
            raise ValueError(f"begin_at '{self.begin_at}' is greater than end_at '{self.end_at}'")
        return self

    @pdt.field_validator("file_checksum", mode="after")
    @classmethod
    def validate_file_checksum(cls, v: str) -> str:
        validate_hex_string(v)
        return v

    @pdt.field_validator("tags", mode="after")
    @classmethod
    def validate_colon_tags(cls, v: list[str] | None) -> list[str] | None:
        for tag in (v or []):
            validate_colon_tag(tag)
        return v

    @pdt.field_validator("props", mode="after")
    @classmethod
    def validate_props(cls, v: JsonObject | None) -> JsonObject | None:
        if v is not None:
            validate_json_type_dump_size(v, 10000)
        return v

    @pdt.field_serializer("begin_at", mode="plain")
    def serialize_begin_at(self, v: datetime.datetime) -> str:
        return json_datetime_encoder(v)

    @pdt.field_serializer("end_at", mode="plain")
    def serialize_end_at(self, v: datetime.datetime) -> str:
        return json_datetime_encoder(v)


class VehicleTemplateTable(VehicleTemplate, make_revision_model_mixin(), table=True):
    __tablename__ = "vehicle_template"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_vehicle_template_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_vehicle_template_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_vehicle_template_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_vehicle_template_uuid", "uuid"),
        sa.Index("ix_vehicle_template_uuid", "uuid", postgresql_using="hash"),
    )


class SensorTemplateTable(SensorTemplate, make_revision_model_mixin(), table=True):
    __tablename__ = "sensor_template"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_sensor_template_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_sensor_template_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_sensor_template_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_sensor_template_uuid", "uuid"),
        sa.Index("ix_sensor_template_uuid", "uuid", postgresql_using="hash"),
    )


class VehicleTable(Vehicle, make_revision_model_mixin(), table=True):
    __tablename__ = "vehicle"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at("ix_vehicle_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_vehicle_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_vehicle_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_vehicle_vin_code", "vin_code"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_vehicle_asset_id", "asset_id"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_vehicle_name", "name"),
        sa.Index("ix_vehicle_vin_code", "vin_code", postgresql_using="hash"),
        sa.Index("ix_vehicle_asset_id", "asset_id", postgresql_using="hash"),
        sa.Index("ix_vehicle_name", "name", postgresql_using="hash"),
    )


class SensorTable(Sensor, make_revision_model_mixin(), table=True):
    __tablename__ = "sensor"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at("ix_sensor_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_sensor_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_sensor_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_sensor_uuid", "uuid"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_sensor_asset_id", "asset_id"),
        sa.Index("ix_sensor_uuid", "uuid", postgresql_using="hash"),
        sa.Index("ix_sensor_asset_id", "asset_id", postgresql_using="hash"),
    )


class RegisteredBagTable(RegisteredBag, make_revision_model_mixin(), table=True):
    __tablename__ = "registered_bag"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at(
            "ix_registered_bag_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_registered_bag_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_registered_bag_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_registered_bag_name", "name"),
        sa.Index("ix_registered_bag_name", "name", postgresql_using="hash"),
        sa.Index("ix_registered_bag_begin_at_end_at", "begin_at", "end_at"),
        sa.Index("ix_registered_bag_file_checksum", "file_checksum", postgresql_using="hash"),
        sa.Index("ix_registered_bag_tags", "tags", postgresql_using="gin"),
    )


if typing.TYPE_CHECKING:
    RegistryBase = SQLModel


    class VehicleTemplateTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        vehicle_type: sa_orm.Mapped[str] = ...
        manufacturer: sa_orm.Mapped[str] = ...
        model_name: sa_orm.Mapped[str] = ...
        model_code: sa_orm.Mapped[str | None] = ...
        production_stage: sa_orm.Mapped[str] = ...
        specification: sa_orm.Mapped[JsonObject] = ...


    class SensorTemplateTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        sensor_type: sa_orm.Mapped[str] = ...
        manufacturer: sa_orm.Mapped[str] = ...
        model_name: sa_orm.Mapped[str] = ...
        model_code: sa_orm.Mapped[str | None] = ...
        production_stage: sa_orm.Mapped[str] = ...
        specification: sa_orm.Mapped[JsonObject] = ...


    class VehicleTable(RegistryBase, RevisionModelMixinProtocol):
        vin_code: sa_orm.Mapped[str] = ...
        asset_id: sa_orm.Mapped[str | None] = ...
        vehicle_template_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        name: sa_orm.Mapped[str] = ...
        purchase_date: sa_orm.Mapped[datetime.date | None] = ...
        tags: sa_orm.Mapped[list[str] | None] = ...


    class SensorTable(RegistryBase, RevisionModelMixinProtocol):
        uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        asset_id: sa_orm.Mapped[str | None] = ...
        sensor_template_uuid: sa_orm.Mapped[py_uuid.UUID] = ...
        serial_number: sa_orm.Mapped[str | None] = ...
        purchase_date: sa_orm.Mapped[datetime.date | None] = ...
        tags: sa_orm.Mapped[list[str] | None] = ...
        props: sa_orm.Mapped[JsonObject | None] = ...


    class RegisteredBagTable(RegistryBase, RevisionModelMixinProtocol):
        name: sa_orm.Mapped[str] = ...
        path: sa_orm.Mapped[str] = ...
        vehicle_vin_code: sa_orm.Mapped[str] = ...
        vehicle_name: sa_orm.Mapped[str] = ...
        begin_at: sa_orm.Mapped[datetime.datetime] = ...
        end_at: sa_orm.Mapped[datetime.datetime] = ...
        file_size: sa_orm.Mapped[int] = ...
        file_checksum: sa_orm.Mapped[str] = ...
        flags: sa_orm.Mapped[int] = ...
        tags: sa_orm.Mapped[list[str] | None] = ...
        props: sa_orm.Mapped[JsonObject | None] = ...
