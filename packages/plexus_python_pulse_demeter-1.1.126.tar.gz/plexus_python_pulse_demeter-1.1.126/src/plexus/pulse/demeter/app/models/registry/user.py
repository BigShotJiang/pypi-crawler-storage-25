import enum
import typing

import pydantic as pdt
import sqlalchemy as sa
import sqlalchemy.dialects.postgresql as sa_pg
import sqlalchemy.orm as sa_orm
from plexus.pulse.common.utils.datautils import validate_user_name
from plexus.pulse.common.utils.ormutils import RevisionModelMixinProtocol
from plexus.pulse.common.utils.ormutils import make_revision_model_mixin, revision_model_mixin
from sqlmodel import Field, SQLModel

from plexus.pulse.demeter.app.models.registry import RegistryBase

__all__ = [
    "UserRole",
    "User",
    "UserTable",
]


class UserRole(enum.Enum):
    Admin = "admin"
    Contributor = "contributor"
    Reviewer = "reviewer"
    Viewer = "viewer"


class User(RegistryBase):
    name: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(64), nullable=False),
        description="Name of the user",
        schema_extra=dict(examples=["user.name"]),
    )
    sso_sid: int | None = Field(
        sa_column=sa.Column(sa_pg.BIGINT),
        default=None,
        description="SSO SID of the user",
        schema_extra=dict(examples=[1234567890]),
    )
    role: str = Field(
        sa_column=sa.Column(sa_pg.VARCHAR(32), nullable=False),
        description="Role of the account",
        schema_extra=dict(examples=["contributor"]),
    )

    @pdt.field_validator("name", mode="after")
    @classmethod
    def validate_name(cls, v: str) -> str:
        validate_user_name(v)
        return v

    @pdt.field_validator("role", mode="after")
    @classmethod
    def validate_role(cls, v: str) -> str:
        if not any(v == item.value for item in UserRole):
            raise ValueError(f"invalid user role '{v}'")
        return v


class UserTable(User, make_revision_model_mixin(), table=True):
    __tablename__ = "user"
    __table_args__ = (
        revision_model_mixin.make_index_created_at_updated_at_expired_at("ix_user_created_at_updated_at_expired_at"),
        revision_model_mixin.make_unique_index_record_sqn_revision("ix_u_user_record_sqn_revision"),
        revision_model_mixin.make_active_unique_index_record_sqn("ix_ua_user_record_sqn"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_user_name", "name"),
        revision_model_mixin.make_active_unique_index_for("ix_ua_user_sso_sid", "sso_sid"),
    )


if typing.TYPE_CHECKING:
    RegistryBase = SQLModel


    class UserTable(RegistryBase, RevisionModelMixinProtocol):
        name: sa_orm.Mapped[str] = ...
        sso_sid: sa_orm.Mapped[int | None] = ...
        role: sa_orm.Mapped[str] = ...
