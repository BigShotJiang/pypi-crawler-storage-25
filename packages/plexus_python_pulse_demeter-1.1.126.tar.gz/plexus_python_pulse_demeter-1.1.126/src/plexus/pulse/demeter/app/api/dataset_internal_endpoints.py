import datetime

import sqlalchemy.orm as sa_orm
from fastapi import APIRouter, Depends
from fastapi.params import Query
from plexus.common.utils.dtutils import dt_utc_now
from plexus.pulse.common.utils.apiutils import managed_db_session
from plexus.pulse.common.utils.ormutils import (
    db_create_revision_model,
    db_create_revision_models,
    db_expire_revision_model,
    db_read_active_revision_model_of_record,
    db_read_active_revision_models,
    db_update_revision_model,
)

from plexus.pulse.demeter.app.core.database import make_session
from plexus.pulse.demeter.app.models.registry.dataset import (
    AnnotationGuideline as Guideline,
    ClassifierTaxonomy as Taxonomy,
    DatasetPromotion as DatasetPromotion,
    DatasetRegistration as Registration,
    ModelArchitecture as Architecture,
    ModelAssessment as Assessment,
    ModelAssessmentPromotion as AssessmentPromotion,
    ModelBenchmark as Benchmark,
    ModelEvaluation as Evaluation,
    ModelExperiment as Experiment,
    ModelExperimentPromotion as ExperimentPromotion,
    ModelTraining as Training,
    RegisteredDataset as Dataset,
    RegisteredSample as Sample,
    SampleAnnotation as Annotation,
    SampleClassifier as Classifier,
    SampleLayout as Layout,
)
from plexus.pulse.demeter.app.models.registry.dataset import (
    AnnotationGuidelineTable as GuidelineTable,
    ClassifierTaxonomyTable as TaxonomyTable,
    DatasetPromotionTable as DatasetPromotionTable,
    DatasetRegistrationTable as RegistrationTable,
    ModelArchitectureTable as ArchitectureTable,
    ModelAssessmentPromotionTable as AssessmentPromotionTable,
    ModelAssessmentTable as AssessmentTable,
    ModelBenchmarkTable as BenchmarkTable,
    ModelEvaluationTable as EvaluationTable,
    ModelExperimentPromotionTable as ExperimentPromotionTable,
    ModelExperimentTable as ExperimentTable,
    ModelTrainingTable as TrainingTable,
    RegisteredDatasetTable as DatasetTable,
    RegisteredSampleTable as SampleTable,
    SampleAnnotationTable as AnnotationTable,
    SampleClassifierTable as ClassifierTable,
    SampleLayoutTable as LayoutTable,
)

router = APIRouter(prefix="/pulse_demeter/dataset_internal", tags=["dataset_internal"])


# Layout
@router.post("/layout/", response_model=LayoutTable)
def create_layout(
    layout: Layout,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> LayoutTable:
    with managed_db_session(db):
        return db_create_revision_model(db, LayoutTable, layout, created_at)


@router.post("/layouts/", response_model=list[LayoutTable])
def create_layouts(
    layouts: list[Layout],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[LayoutTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, LayoutTable, layouts, created_at)


@router.get("/layout/{record_sqn}", response_model=LayoutTable)
def read_layout(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> LayoutTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, LayoutTable, record_sqn)


@router.get("/layouts/", response_model=list[LayoutTable])
def read_layouts(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[LayoutTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, LayoutTable, skip, limit)


@router.put("/layout/{record_sqn}", response_model=LayoutTable)
def update_layout(
    record_sqn: int,
    layout: Layout,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> LayoutTable:
    with managed_db_session(db):
        return db_update_revision_model(db, LayoutTable, layout, record_sqn, updated_at)


@router.delete("/layout/{record_sqn}", response_model=LayoutTable)
def delete_layout(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> LayoutTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, LayoutTable, record_sqn, updated_at)


# Taxonomy
@router.post("/taxonomy/", response_model=TaxonomyTable)
def create_taxonomy(
    taxonomy: Taxonomy,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> TaxonomyTable:
    with managed_db_session(db):
        return db_create_revision_model(db, TaxonomyTable, taxonomy, created_at)


@router.post("/taxonomies/", response_model=list[TaxonomyTable])
def create_taxonomies(
    taxonomies: list[Taxonomy],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[TaxonomyTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, TaxonomyTable, taxonomies, created_at)


@router.get("/taxonomy/{record_sqn}", response_model=TaxonomyTable)
def read_taxonomy(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> TaxonomyTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, TaxonomyTable, record_sqn)


@router.get("/taxonomies/", response_model=list[TaxonomyTable])
def read_taxonomies(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[TaxonomyTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, TaxonomyTable, skip, limit)


@router.put("/taxonomy/{record_sqn}", response_model=TaxonomyTable)
def update_taxonomy(
    record_sqn: int,
    taxonomy: Taxonomy,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> TaxonomyTable:
    with managed_db_session(db):
        return db_update_revision_model(db, TaxonomyTable, taxonomy, record_sqn, updated_at)


@router.delete("/taxonomy/{record_sqn}", response_model=TaxonomyTable)
def delete_taxonomy(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> TaxonomyTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, TaxonomyTable, record_sqn, updated_at)


# Guideline
@router.post("/guideline/", response_model=GuidelineTable)
def create_guideline(
    guideline: Guideline,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> GuidelineTable:
    with managed_db_session(db):
        return db_create_revision_model(db, GuidelineTable, guideline, created_at)


@router.post("/guidelines/", response_model=list[GuidelineTable])
def create_guidelines(
    guidelines: list[Guideline],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[GuidelineTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, GuidelineTable, guidelines, created_at)


@router.get("/guideline/{record_sqn}", response_model=GuidelineTable)
def read_guideline(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> GuidelineTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, GuidelineTable, record_sqn)


@router.get("/guidelines/", response_model=list[GuidelineTable])
def read_guidelines(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[GuidelineTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, GuidelineTable, skip, limit)


@router.put("/guideline/{record_sqn}", response_model=GuidelineTable)
def update_guideline(
    record_sqn: int,
    guideline: Guideline,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> GuidelineTable:
    with managed_db_session(db):
        return db_update_revision_model(db, GuidelineTable, guideline, record_sqn, updated_at)


@router.delete("/guideline/{record_sqn}", response_model=GuidelineTable)
def delete_guideline(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> GuidelineTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, GuidelineTable, record_sqn, updated_at)


# Architecture
@router.post("/architecture/", response_model=ArchitectureTable)
def create_architecture(
    architecture: Architecture,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> ArchitectureTable:
    with managed_db_session(db):
        return db_create_revision_model(db, ArchitectureTable, architecture, created_at)


@router.post("/architectures/", response_model=list[ArchitectureTable])
def create_architectures(
    architectures: list[Architecture],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[ArchitectureTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, ArchitectureTable, architectures, created_at)


@router.get("/architecture/{record_sqn}", response_model=ArchitectureTable)
def read_architecture(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> ArchitectureTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, ArchitectureTable, record_sqn)


@router.get("/architectures/", response_model=list[ArchitectureTable])
def read_architectures(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[ArchitectureTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, ArchitectureTable, skip, limit)


@router.put("/architecture/{record_sqn}", response_model=ArchitectureTable)
def update_architecture(
    record_sqn: int,
    architecture: Architecture,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> ArchitectureTable:
    with managed_db_session(db):
        return db_update_revision_model(db, ArchitectureTable, architecture, record_sqn, updated_at)


@router.delete("/architecture/{record_sqn}", response_model=ArchitectureTable)
def delete_architecture(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> ArchitectureTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, ArchitectureTable, record_sqn, updated_at)


# Benchmark
@router.post("/benchmark/", response_model=BenchmarkTable)
def create_benchmark(
    benchmark: Benchmark,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> BenchmarkTable:
    with managed_db_session(db):
        return db_create_revision_model(db, BenchmarkTable, benchmark, created_at)


@router.post("/benchmarks/", response_model=list[BenchmarkTable])
def create_benchmarks(
    benchmarks: list[Benchmark],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[BenchmarkTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, BenchmarkTable, benchmarks, created_at)


@router.get("/benchmark/{record_sqn}", response_model=BenchmarkTable)
def read_benchmark(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> BenchmarkTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, BenchmarkTable, record_sqn)


@router.get("/benchmarks/", response_model=list[BenchmarkTable])
def read_benchmarks(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[BenchmarkTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, BenchmarkTable, skip, limit)


@router.put("/benchmark/{record_sqn}", response_model=BenchmarkTable)
def update_benchmark(
    record_sqn: int,
    benchmark: Benchmark,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> BenchmarkTable:
    with managed_db_session(db):
        return db_update_revision_model(db, BenchmarkTable, benchmark, record_sqn, updated_at)


@router.delete("/benchmark/{record_sqn}", response_model=BenchmarkTable)
def delete_benchmark(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> BenchmarkTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, BenchmarkTable, record_sqn, updated_at)


# Registration
@router.post("/registration/", response_model=RegistrationTable)
def create_registration(
    registration: Registration,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> RegistrationTable:
    with managed_db_session(db):
        return db_create_revision_model(db, RegistrationTable, registration, created_at)


@router.post("/registrations/", response_model=list[RegistrationTable])
def create_registrations(
    registrations: list[Registration],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[RegistrationTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, RegistrationTable, registrations, created_at)


@router.get("/registration/{record_sqn}", response_model=RegistrationTable)
def read_registration(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> RegistrationTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, RegistrationTable, record_sqn)


@router.get("/registrations/", response_model=list[RegistrationTable])
def read_registrations(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[RegistrationTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, RegistrationTable, skip, limit)


@router.put("/registration/{record_sqn}", response_model=RegistrationTable)
def update_registration(
    record_sqn: int,
    registration: Registration,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> RegistrationTable:
    with managed_db_session(db):
        return db_update_revision_model(db, RegistrationTable, registration, record_sqn, updated_at)


@router.delete("/registration/{record_sqn}", response_model=RegistrationTable)
def delete_registration(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> RegistrationTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, RegistrationTable, record_sqn, updated_at)


# Dataset Promotion
@router.post("/dataset_promotion/", response_model=DatasetPromotionTable)
def create_dataset_promotion(
    dataset_promotion: DatasetPromotion,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetPromotionTable:
    with managed_db_session(db):
        return db_create_revision_model(db, DatasetPromotionTable, dataset_promotion, created_at)


@router.post("/dataset_promotions/", response_model=list[DatasetPromotionTable])
def create_dataset_promotions(
    dataset_promotions: list[DatasetPromotion],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[DatasetPromotionTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, DatasetPromotionTable, dataset_promotions, created_at)


@router.get("/dataset_promotion/{record_sqn}", response_model=DatasetPromotionTable)
def read_dataset_promotion(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> DatasetPromotionTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, DatasetPromotionTable, record_sqn)


@router.get("/dataset_promotions/", response_model=list[DatasetPromotionTable])
def read_dataset_promotions(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[DatasetPromotionTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, DatasetPromotionTable, skip, limit)


@router.put("/dataset_promotion/{record_sqn}", response_model=DatasetPromotionTable)
def update_dataset_promotion(
    record_sqn: int,
    dataset_promotion: DatasetPromotion,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetPromotionTable:
    with managed_db_session(db):
        return db_update_revision_model(db, DatasetPromotionTable, dataset_promotion, record_sqn, updated_at)


@router.delete("/dataset_promotion/{record_sqn}", response_model=DatasetPromotionTable)
def delete_dataset_promotion(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetPromotionTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, DatasetPromotionTable, record_sqn, updated_at)


# Dataset
@router.post("/dataset/", response_model=DatasetTable)
def create_dataset(
    dataset: Dataset,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTable:
    with managed_db_session(db):
        return db_create_revision_model(db, DatasetTable, dataset, created_at)


@router.post("/datasets/", response_model=list[DatasetTable])
def create_datasets(
    datasets: list[Dataset],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[DatasetTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, DatasetTable, datasets, created_at)


@router.get("/dataset/{record_sqn}", response_model=DatasetTable)
def read_dataset(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> DatasetTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, DatasetTable, record_sqn)


@router.get("/datasets/", response_model=list[DatasetTable])
def read_datasets(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[DatasetTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, DatasetTable, skip, limit)


@router.put("/dataset/{record_sqn}", response_model=DatasetTable)
def update_dataset(
    record_sqn: int,
    dataset: Dataset,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTable:
    with managed_db_session(db):
        return db_update_revision_model(db, DatasetTable, dataset, record_sqn, updated_at)


@router.delete("/dataset/{record_sqn}", response_model=DatasetTable)
def delete_dataset(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> DatasetTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, DatasetTable, record_sqn, updated_at)


# Sample
@router.post("/sample/", response_model=SampleTable)
def create_sample(
    sample: Sample,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> SampleTable:
    with managed_db_session(db):
        return db_create_revision_model(db, SampleTable, sample, created_at)


@router.post("/samples/", response_model=list[SampleTable])
def create_samples(
    samples: list[Sample],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[SampleTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, SampleTable, samples, created_at)


@router.get("/sample/{record_sqn}", response_model=SampleTable)
def read_sample(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> SampleTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, SampleTable, record_sqn)


@router.get("/samples/", response_model=list[SampleTable])
def read_samples(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[SampleTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, SampleTable, skip, limit)


@router.put("/sample/{record_sqn}", response_model=SampleTable)
def update_sample(
    record_sqn: int,
    sample: Sample,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> SampleTable:
    with managed_db_session(db):
        return db_update_revision_model(db, SampleTable, sample, record_sqn, updated_at)


@router.delete("/sample/{record_sqn}", response_model=SampleTable)
def delete_sample(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> SampleTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, SampleTable, record_sqn, updated_at)


# Classifier
@router.post("/classifier/", response_model=ClassifierTable)
def create_classifier(
    classifier: Classifier,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> ClassifierTable:
    with managed_db_session(db):
        return db_create_revision_model(db, ClassifierTable, classifier, created_at)


@router.post("/classifiers/", response_model=list[ClassifierTable])
def create_classifiers(
    classifiers: list[Classifier],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[ClassifierTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, ClassifierTable, classifiers, created_at)


@router.get("/classifier/{record_sqn}", response_model=ClassifierTable)
def read_classifier(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> ClassifierTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, ClassifierTable, record_sqn)


@router.get("/classifiers/", response_model=list[ClassifierTable])
def read_classifiers(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[ClassifierTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, ClassifierTable, skip, limit)


@router.put("/classifier/{record_sqn}", response_model=ClassifierTable)
def update_classifier(
    record_sqn: int,
    classifier: Classifier,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> ClassifierTable:
    with managed_db_session(db):
        return db_update_revision_model(db, ClassifierTable, classifier, record_sqn, updated_at)


@router.delete("/classifier/{record_sqn}", response_model=ClassifierTable)
def delete_classifier(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> ClassifierTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, ClassifierTable, record_sqn, updated_at)


# Annotation
@router.post("/annotation/", response_model=AnnotationTable)
def create_annotation(
    annotation: Annotation,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> AnnotationTable:
    with managed_db_session(db):
        return db_create_revision_model(db, AnnotationTable, annotation, created_at)


@router.post("/annotations/", response_model=list[AnnotationTable])
def create_annotations(
    annotations: list[Annotation],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[AnnotationTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, AnnotationTable, annotations, created_at)


@router.get("/annotation/{record_sqn}", response_model=AnnotationTable)
def read_annotation(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> AnnotationTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, AnnotationTable, record_sqn)


@router.get("/annotations/", response_model=list[AnnotationTable])
def read_annotations(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[AnnotationTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, AnnotationTable, skip, limit)


@router.put("/annotation/{record_sqn}", response_model=AnnotationTable)
def update_annotation(
    record_sqn: int,
    annotation: Annotation,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> AnnotationTable:
    with managed_db_session(db):
        return db_update_revision_model(db, AnnotationTable, annotation, record_sqn, updated_at)


@router.delete("/annotation/{record_sqn}", response_model=AnnotationTable)
def delete_annotation(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> AnnotationTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, AnnotationTable, record_sqn, updated_at)


# Experiment
@router.post("/experiment/", response_model=ExperimentTable)
def create_experiment(
    experiment: Experiment,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> ExperimentTable:
    with managed_db_session(db):
        return db_create_revision_model(db, ExperimentTable, experiment, created_at)


@router.post("/experiments/", response_model=list[ExperimentTable])
def create_experiments(
    experiments: list[Experiment],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[ExperimentTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, ExperimentTable, experiments, created_at)


@router.get("/experiment/{record_sqn}", response_model=ExperimentTable)
def read_experiment(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> ExperimentTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, ExperimentTable, record_sqn)


@router.get("/experiments/", response_model=list[ExperimentTable])
def read_experiments(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[ExperimentTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, ExperimentTable, skip, limit)


@router.put("/experiment/{record_sqn}", response_model=ExperimentTable)
def update_experiment(
    record_sqn: int,
    experiment: Experiment,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> ExperimentTable:
    with managed_db_session(db):
        return db_update_revision_model(db, ExperimentTable, experiment, record_sqn, updated_at)


@router.delete("/experiment/{record_sqn}", response_model=ExperimentTable)
def delete_experiment(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> ExperimentTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, ExperimentTable, record_sqn, updated_at)


# Training
@router.post("/training/", response_model=TrainingTable)
def create_training(
    training: Training,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> TrainingTable:
    with managed_db_session(db):
        return db_create_revision_model(db, TrainingTable, training, created_at)


@router.post("/trainings/", response_model=list[TrainingTable])
def create_trainings(
    trainings: list[Training],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[TrainingTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, TrainingTable, trainings, created_at)


@router.get("/training/{record_sqn}", response_model=TrainingTable)
def read_training(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> TrainingTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, TrainingTable, record_sqn)


@router.get("/trainings/", response_model=list[TrainingTable])
def read_trainings(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[TrainingTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, TrainingTable, skip, limit)


@router.put("/training/{record_sqn}", response_model=TrainingTable)
def update_training(
    record_sqn: int,
    training: Training,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> TrainingTable:
    with managed_db_session(db):
        return db_update_revision_model(db, TrainingTable, training, record_sqn, updated_at)


@router.delete("/training/{record_sqn}", response_model=TrainingTable)
def delete_training(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> TrainingTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, TrainingTable, record_sqn, updated_at)


# Model Experiment Promotion
@router.post("/experiment_promotion/", response_model=ExperimentPromotionTable)
def create_experiment_promotion(
    experiment_promotion: ExperimentPromotion,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> ExperimentPromotionTable:
    with managed_db_session(db):
        return db_create_revision_model(db, ExperimentPromotionTable, experiment_promotion, created_at)


@router.post("/experiment_promotions/", response_model=list[ExperimentPromotionTable])
def create_experiment_promotions(
    experiment_promotions: list[ExperimentPromotion],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[ExperimentPromotionTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, ExperimentPromotionTable, experiment_promotions, created_at)


@router.get("/experiment_promotion/{record_sqn}", response_model=ExperimentPromotionTable)
def read_experiment_promotion(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> ExperimentPromotionTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, ExperimentPromotionTable, record_sqn)


@router.get("/experiment_promotions/", response_model=list[ExperimentPromotionTable])
def read_experiment_promotions(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[ExperimentPromotionTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, ExperimentPromotionTable, skip, limit)


@router.put("/experiment_promotion/{record_sqn}", response_model=ExperimentPromotionTable)
def update_experiment_promotion(
    record_sqn: int,
    experiment_promotion: ExperimentPromotion,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> ExperimentPromotionTable:
    with managed_db_session(db):
        return db_update_revision_model(db, ExperimentPromotionTable, experiment_promotion, record_sqn, updated_at)


@router.delete("/experiment_promotion/{record_sqn}", response_model=ExperimentPromotionTable)
def delete_experiment_promotion(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> ExperimentPromotionTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, ExperimentPromotionTable, record_sqn, updated_at)


# Assessment
@router.post("/assessment/", response_model=AssessmentTable)
def create_assessment(
    assessment: Assessment,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> AssessmentTable:
    with managed_db_session(db):
        return db_create_revision_model(db, AssessmentTable, assessment, created_at)


@router.post("/assessments/", response_model=list[AssessmentTable])
def create_assessments(
    assessments: list[Assessment],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[AssessmentTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, AssessmentTable, assessments, created_at)


@router.get("/assessment/{record_sqn}", response_model=AssessmentTable)
def read_assessment(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> AssessmentTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, AssessmentTable, record_sqn)


@router.get("/assessments/", response_model=list[AssessmentTable])
def read_assessments(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[AssessmentTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, AssessmentTable, skip, limit)


@router.put("/assessment/{record_sqn}", response_model=AssessmentTable)
def update_assessment(
    record_sqn: int,
    assessment: Assessment,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> AssessmentTable:
    with managed_db_session(db):
        return db_update_revision_model(db, AssessmentTable, assessment, record_sqn, updated_at)


@router.delete("/assessment/{record_sqn}", response_model=AssessmentTable)
def delete_assessment(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> AssessmentTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, AssessmentTable, record_sqn, updated_at)


# Evaluation
@router.post("/evaluation/", response_model=EvaluationTable)
def create_evaluation(
    evaluation: Evaluation,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> EvaluationTable:
    with managed_db_session(db):
        return db_create_revision_model(db, EvaluationTable, evaluation, created_at)


@router.post("/evaluations/", response_model=list[EvaluationTable])
def create_evaluations(
    evaluations: list[Evaluation],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[EvaluationTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, EvaluationTable, evaluations, created_at)


@router.get("/evaluation/{record_sqn}", response_model=EvaluationTable)
def read_evaluation(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> EvaluationTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, EvaluationTable, record_sqn)


@router.get("/evaluations/", response_model=list[EvaluationTable])
def read_evaluations(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[EvaluationTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, EvaluationTable, skip, limit)


@router.put("/evaluation/{record_sqn}", response_model=EvaluationTable)
def update_evaluation(
    record_sqn: int,
    evaluation: Evaluation,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> EvaluationTable:
    with managed_db_session(db):
        return db_update_revision_model(db, EvaluationTable, evaluation, record_sqn, updated_at)


@router.delete("/evaluation/{record_sqn}", response_model=EvaluationTable)
def delete_evaluation(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> EvaluationTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, EvaluationTable, record_sqn, updated_at)


# Model Assessment Promotion
@router.post("/assessment_promotion/", response_model=AssessmentPromotionTable)
def create_assessment_promotion(
    assessment_promotion: AssessmentPromotion,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> AssessmentPromotionTable:
    with managed_db_session(db):
        return db_create_revision_model(db, AssessmentPromotionTable, assessment_promotion, created_at)


@router.post("/assessment_promotions/", response_model=list[AssessmentPromotionTable])
def create_assessment_promotions(
    assessment_promotions: list[AssessmentPromotion],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[AssessmentPromotionTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, AssessmentPromotionTable, assessment_promotions, created_at)


@router.get("/assessment_promotion/{record_sqn}", response_model=AssessmentPromotionTable)
def read_assessment_promotion(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> AssessmentPromotionTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, AssessmentPromotionTable, record_sqn)


@router.get("/assessment_promotions/", response_model=list[AssessmentPromotionTable])
def read_assessment_promotions(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[AssessmentPromotionTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, AssessmentPromotionTable, skip, limit)


@router.put("/assessment_promotion/{record_sqn}", response_model=AssessmentPromotionTable)
def update_assessment_promotion(
    record_sqn: int,
    assessment_promotion: AssessmentPromotion,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> AssessmentPromotionTable:
    with managed_db_session(db):
        return db_update_revision_model(db, AssessmentPromotionTable, assessment_promotion, record_sqn, updated_at)


@router.delete("/assessment_promotion/{record_sqn}", response_model=AssessmentPromotionTable)
def delete_assessment_promotion(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> AssessmentPromotionTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, AssessmentPromotionTable, record_sqn, updated_at)
