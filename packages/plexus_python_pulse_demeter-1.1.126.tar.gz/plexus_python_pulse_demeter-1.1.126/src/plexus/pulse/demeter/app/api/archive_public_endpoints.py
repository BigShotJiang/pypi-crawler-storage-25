import datetime

import pydantic as pdt
import sqlalchemy as sa
import sqlalchemy.exc as sa_exc
import sqlalchemy.orm as sa_orm
from fastapi import APIRouter, Body, Depends, Query
from plexus.pulse.common.utils.apiutils import managed_db_session
from plexus.pulse.common.utils.ormutils import model_name_of
from plexus.pulse.common.utils.sqlutils import escape_sql_like

from plexus.pulse.demeter.app.api import current_dt_clock
from plexus.pulse.demeter.app.api.archive_internal_endpoints import (
    create_bag,
    create_sensor,
    create_vehicle,
    update_bag,
    update_sensor,
    update_vehicle,
)
from plexus.pulse.demeter.app.core.database import make_session
from plexus.pulse.demeter.app.models import Pagination
from plexus.pulse.demeter.app.models.registry.archive import (
    RegisteredBag as Bag,
    RegisteredBagTable as BagTable,
    Sensor,
    SensorTable,
    Vehicle,
    VehicleTable,
)

router = APIRouter(prefix="/pulse_demeter/archive_public", tags=["archive_public"])


@router.post("/create_or_update_sensor/", response_model=SensorTable)
def create_or_update_sensor(
    sensor: Sensor = Body(),
    current_dt: datetime.datetime = Depends(current_dt_clock),
    db: sa_orm.Session = Depends(make_session),
) -> SensorTable:
    with managed_db_session(db):
        db_sensor = (
            db
            .query(SensorTable)
            .where(SensorTable.expired_at.is_(None),
                   SensorTable.uuid == sensor.uuid,
                   SensorTable.serial_number == sensor.serial_number)
            .one_or_none()
        )
        if db_sensor is None:
            return create_sensor(sensor, current_dt, db)
        else:
            return update_sensor(db_sensor.record_sqn, sensor, current_dt, db)


@router.post("/create_or_update_vehicle/", response_model=VehicleTable)
def create_or_update_vehicle(
    vehicle: Vehicle = Body(),
    current_dt: datetime.datetime = Depends(current_dt_clock),
    db: sa_orm.Session = Depends(make_session),
) -> VehicleTable:
    with managed_db_session(db):
        db_vehicle = (
            db
            .query(VehicleTable)
            .where(VehicleTable.expired_at.is_(None),
                   VehicleTable.vin_code == vehicle.vin_code,
                   VehicleTable.name == vehicle.name)
            .one_or_none()
        )
        if db_vehicle is None:
            return create_vehicle(vehicle, current_dt, db)
        else:
            return update_vehicle(db_vehicle.record_sqn, vehicle, current_dt, db)


@router.post("/create_or_update_bag/", response_model=BagTable)
def create_or_update_bag(
    bag: Bag = Body(),
    current_dt: datetime.datetime = Depends(current_dt_clock),
    db: sa_orm.Session = Depends(make_session),
) -> BagTable:
    with managed_db_session(db):
        db_bag = (
            db
            .query(BagTable)
            .where(BagTable.expired_at.is_(None),
                   BagTable.name == bag.name)
            .one_or_none()
        )
        if db_bag is None:
            return create_bag(bag, current_dt, db)
        else:
            return update_bag(db_bag.record_sqn, bag, current_dt, db)


class VehicleTablesAndPagination(pdt.BaseModel):
    vehicles: list[VehicleTable]
    pagination: Pagination


@router.get("/query_vehicles/", response_model=VehicleTablesAndPagination)
def query_vehicles(
    effective_at: datetime.datetime | None = Query(None),
    skip: int = Query(0),
    limit: int = Query(100),
    db: sa_orm.Session = Depends(make_session),
) -> VehicleTablesAndPagination:
    with managed_db_session(db):
        query_stmt = (
            db
            .query(VehicleTable)
            .where(VehicleTable.updated_at <= effective_at,
                   sa.or_(VehicleTable.expired_at.is_(None), VehicleTable.expired_at > effective_at))
        )

        total = query_stmt.count()
        db_vehicles = query_stmt.order_by(VehicleTable.sqn.asc()).offset(skip).limit(limit).all()

    return VehicleTablesAndPagination(vehicles=db_vehicles, pagination=Pagination(skip=skip, limit=limit, total=total))


@router.get("/retrieve_vehicles/", response_model=VehicleTablesAndPagination)
def retrieve_vehicles(
    name_match: str | None = Query(None),
    skip: int = Query(0),
    limit: int = Query(100),
    db: sa_orm.Session = Depends(make_session),
) -> VehicleTablesAndPagination:
    with managed_db_session(db):
        query_stmt = db.query(VehicleTable).where(VehicleTable.expired_at.is_(None))
        if name_match:
            query_stmt = query_stmt.where(
                VehicleTable.name.ilike(f"%{escape_sql_like(name_match)}%", escape="\\"),
            )

        total = query_stmt.count()
        db_vehicles = query_stmt.order_by(VehicleTable.sqn.asc()).offset(skip).limit(limit).all()

    return VehicleTablesAndPagination(vehicles=db_vehicles, pagination=Pagination(skip=skip, limit=limit, total=total))


class SensorTablesAndPagination(pdt.BaseModel):
    sensors: list[SensorTable]
    pagination: Pagination


@router.get("/query_sensors/", response_model=SensorTablesAndPagination)
def query_sensors(
    effective_at: datetime.datetime = Query(),
    skip: int = Query(0),
    limit: int = Query(100),
    db: sa_orm.Session = Depends(make_session),
) -> SensorTablesAndPagination:
    with managed_db_session(db):
        query_stmt = (
            db
            .query(SensorTable)
            .where(SensorTable.updated_at <= effective_at,
                   sa.or_(SensorTable.expired_at.is_(None), SensorTable.expired_at > effective_at))
        )

        total = query_stmt.count()
        db_sensors = query_stmt.order_by(SensorTable.sqn.asc()).offset(skip).limit(limit).all()

    return SensorTablesAndPagination(sensors=db_sensors, pagination=Pagination(skip=skip, limit=limit, total=total))


@router.get("/retrieve_sensors/", response_model=SensorTablesAndPagination)
def retrieve_sensors(
    serial_number_match: str | None = Query(None),
    skip: int = Query(0),
    limit: int = Query(100),
    db: sa_orm.Session = Depends(make_session),
) -> SensorTablesAndPagination:
    with managed_db_session(db):
        query_stmt = db.query(SensorTable).where(SensorTable.expired_at.is_(None))
        if serial_number_match:
            query_stmt = query_stmt.where(
                SensorTable.serial_number.ilike(f"%{escape_sql_like(serial_number_match)}%", escape="\\"),
            )

        total = query_stmt.count()
        db_sensors = query_stmt.order_by(SensorTable.sqn.asc()).offset(skip).limit(limit).all()

    return SensorTablesAndPagination(sensors=db_sensors, pagination=Pagination(skip=skip, limit=limit, total=total))


class BagTablesAndPagination(pdt.BaseModel):
    bags: list[BagTable]
    pagination: Pagination


@router.get("/query_bags/", response_model=BagTablesAndPagination)
def query_bags(
    effective_at: datetime.datetime = Query(),
    skip: int = Query(0),
    limit: int = Query(100),
    db: sa_orm.Session = Depends(make_session),
) -> BagTablesAndPagination:
    with managed_db_session(db):
        query_stmt = (
            db
            .query(BagTable)
            .where(BagTable.updated_at <= effective_at,
                   sa.or_(BagTable.expired_at.is_(None), BagTable.expired_at > effective_at))
        )

        total = query_stmt.count()
        db_bags = query_stmt.order_by(BagTable.sqn.asc()).offset(skip).limit(limit).all()

    return BagTablesAndPagination(bags=db_bags, pagination=Pagination(skip=skip, limit=limit, total=total))


@router.get("/retrieve_bags/", response_model=BagTablesAndPagination)
def retrieve_bags(
    begin_at: datetime.datetime | None = Query(None),
    end_at: datetime.datetime | None = Query(None),
    vehicle_names: list[str] | None = Query(None),
    name_match: str | None = Query(None),
    skip: int = Query(0),
    limit: int = Query(100),
    db: sa_orm.Session = Depends(make_session),
) -> BagTablesAndPagination:
    with managed_db_session(db):
        query_stmt = db.query(BagTable).where(BagTable.expired_at.is_(None))
        if begin_at is not None:
            query_stmt = query_stmt.where(BagTable.begin_at >= begin_at)
        if end_at is not None:
            query_stmt = query_stmt.where(BagTable.end_at < end_at)
        if vehicle_names:
            query_stmt = query_stmt.where(BagTable.vehicle_name.in_(vehicle_names))
        if name_match:
            query_stmt = query_stmt.where(BagTable.name.ilike(f"%{escape_sql_like(name_match)}%", escape="\\"))

        total = query_stmt.count()
        db_bags = query_stmt.order_by(BagTable.sqn.asc()).offset(skip).limit(limit).all()

    return BagTablesAndPagination(bags=db_bags, pagination=Pagination(skip=skip, limit=limit, total=total))


@router.get("/query_bag/", response_model=BagTable)
def query_bag(
    name: str | None = Query(None),
    db: sa_orm.Session = Depends(make_session),
) -> BagTable:
    with managed_db_session(db):
        query_stmt = db.query(BagTable).where(BagTable.expired_at.is_(None))
        if name is not None:
            query_stmt = query_stmt.where(BagTable.name == name)
        db_bag = query_stmt.one_or_none()
        if db_bag is None:
            raise sa_exc.NoResultFound(f"'{model_name_of(BagTable)}' with name '{name}' not found")

    return db_bag
