from typing import Any, Literal

import pydantic as pdt

__all__ = [
    "Pagination",
    "TableColumn",
    "ColumnOrdering",
    "ColumnFormatter",
]


class Pagination(pdt.BaseModel):
    skip: int
    limit: int
    total: int


class ColumnOrdering(pdt.BaseModel):
    semantic: Literal["lexical", "numeric", "datetime", "semver"] = "lexical"
    direction: Literal["ascending", "descending"] = "ascending"


class ColumnFormatter(pdt.BaseModel):
    syntax: Literal["python_print", "python_format", "python_fstring", "python_strftime"] = "python_print"
    template: str
    args: list[Any] | None = None


class TableColumn(pdt.BaseModel):
    name: str
    ordering: ColumnOrdering | None = None
    formatter: ColumnFormatter | None = None
