import datetime

import sqlalchemy.orm as sa_orm
from fastapi import APIRouter, Depends
from fastapi.params import Query
from plexus.common.utils.dtutils import dt_utc_now
from plexus.pulse.common.utils.apiutils import managed_db_session
from plexus.pulse.common.utils.ormutils import (
    db_create_revision_model,
    db_create_revision_models,
    db_expire_revision_model,
    db_read_active_revision_model_of_record,
    db_read_active_revision_models,
    db_update_revision_model,
)

from plexus.pulse.demeter.app.core.database import make_session
from plexus.pulse.demeter.app.models.registry.user import User
from plexus.pulse.demeter.app.models.registry.user import UserTable

router = APIRouter(prefix="/pulse_demeter/user", tags=["user"])


@router.post("/user/", response_model=UserTable)
def create_user(
    user: User,
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> UserTable:
    with managed_db_session(db):
        return db_create_revision_model(db, UserTable, user, created_at)


@router.post("/users/", response_model=list[UserTable])
def create_users(
    users: list[User],
    created_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> list[UserTable]:
    with managed_db_session(db):
        return db_create_revision_models(db, UserTable, users, created_at)


@router.get("/user/{record_sqn}", response_model=UserTable)
def read_user(record_sqn: int, db: sa_orm.Session = Depends(make_session)) -> UserTable:
    with managed_db_session(db):
        return db_read_active_revision_model_of_record(db, UserTable, record_sqn)


@router.get("/users/", response_model=list[UserTable])
def read_users(
    skip: int = Query(0),
    limit: int = Query(1000),
    db: sa_orm.Session = Depends(make_session),
) -> list[UserTable]:
    with managed_db_session(db):
        return db_read_active_revision_models(db, UserTable, skip, limit)


@router.put("/user/{record_sqn}", response_model=UserTable)
def update_user(
    record_sqn: int,
    user: User,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> UserTable:
    with managed_db_session(db):
        return db_update_revision_model(db, UserTable, user, record_sqn, updated_at)


@router.delete("/user/{record_sqn}", response_model=UserTable)
def delete_user(
    record_sqn: int,
    updated_at: datetime.datetime = Query(default_factory=dt_utc_now),
    db: sa_orm.Session = Depends(make_session),
) -> UserTable:
    with managed_db_session(db):
        return db_expire_revision_model(db, UserTable, record_sqn, updated_at)
