import datetime
from collections.abc import Generator

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from plexus.common.utils.dtutils import dt_utc_now

__all__ = [
    "current_dt_clock",
    "make_api"
]


def current_dt_clock() -> Generator[datetime.datetime, None, None]:
    yield dt_utc_now()


def make_api() -> FastAPI:
    from plexus.pulse.demeter.app.api.dataset_internal_endpoints import router as dataset_internal_router
    from plexus.pulse.demeter.app.api.dataset_public_endpoints import router as dataset_public_router
    from plexus.pulse.demeter.app.api.dataset_workflow_endpoints import router as dataset_workflow_router
    from plexus.pulse.demeter.app.api.archive_internal_endpoints import router as archive_internal_router
    from plexus.pulse.demeter.app.api.archive_public_endpoints import router as archive_public_router
    from plexus.pulse.demeter.app.api.tagging_endpoints import router as tagging_router
    from plexus.pulse.demeter.app.api.user_endpoints import router as user_router

    api = FastAPI(title="Pulse Demeter API", description="API for Pulse Demeter")
    api.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    api.include_router(dataset_internal_router)
    api.include_router(dataset_public_router)
    api.include_router(dataset_workflow_router)
    api.include_router(archive_internal_router)
    api.include_router(archive_public_router)
    api.include_router(tagging_router)
    api.include_router(user_router)

    return api
