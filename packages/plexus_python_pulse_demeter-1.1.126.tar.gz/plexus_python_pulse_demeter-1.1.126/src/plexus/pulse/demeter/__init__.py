import importlib.metadata

try:
    __version__ = importlib.metadata.version("plexus-python-pulse-demeter")
except importlib.metadata.PackageNotFoundError:
    __version__ = "unknown"
