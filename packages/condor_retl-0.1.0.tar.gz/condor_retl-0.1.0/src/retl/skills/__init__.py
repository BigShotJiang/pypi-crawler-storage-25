"""Packaged RETL skill resources."""
