from __future__ import annotations

from collections.abc import Callable, Sequence

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware

from fastvia.errors import register_exception_handlers
from fastvia.logging import setup_logging
from fastvia.middleware import RequestContextMiddleware, SecurityHeadersMiddleware
from fastvia.rate_limit import register_rate_limiting


def bootstrap_fastvia(
    app: FastAPI,
    *,
    enable_logging: bool = True,
    log_level: int | str = "INFO",
    log_format: str = "text",
    logger_name: str = "fastvia",
    cors_origins: Sequence[str],
    cors_allow_credentials: bool = True,
    cors_allow_methods: Sequence[str] = ("*",),
    cors_allow_headers: Sequence[str] = ("*",),
    cors_expose_headers: Sequence[str] = ("x-request-id", "x-process-time"),
    add_request_context: bool = True,
    add_security_headers: bool = True,
    enable_hsts: bool = False,
    csp_value: str | None = None,
    register_errors: bool = True,
    enable_gzip: bool = True,
    gzip_minimum_size: int = 1000,
    enable_rate_limiting: bool = True,
    rate_limit_storage_uri: str,
    rate_limit_default_limits: list[str] | None = None,
    rate_limit_key_func: Callable | None = None,
) -> FastAPI:
    """
    Configure an existing FastAPI app with Fastvia's common production helpers.

    Fastvia does not create the app for you. Your project owns app creation,
    lifespan, routers, docs config, trusted hosts, and deployment-specific setup.

    cors_origins and rate_limit_storage_uri are intentionally required so the
    application makes an explicit decision about frontend access and limiter
    storage.
    """

    if enable_logging:
        setup_logging(
            level=log_level,
            log_format=log_format,
            logger_name=logger_name,
        )

    if cors_origins:
        app.add_middleware(
            CORSMiddleware,
            allow_origins=list(cors_origins),
            allow_credentials=cors_allow_credentials,
            allow_methods=list(cors_allow_methods),
            allow_headers=list(cors_allow_headers),
            expose_headers=list(cors_expose_headers),
        )

    if enable_gzip:
        app.add_middleware(
            GZipMiddleware,
            minimum_size=gzip_minimum_size,
        )

    if add_security_headers:
        app.add_middleware(
            SecurityHeadersMiddleware,
            enable_hsts=enable_hsts,
            csp_value=csp_value,
        )

    if add_request_context:
        app.add_middleware(RequestContextMiddleware)

    if register_errors:
        register_exception_handlers(app)

    if enable_rate_limiting:
        if rate_limit_key_func is None:
            register_rate_limiting(
                app,
                storage_uri=rate_limit_storage_uri,
                default_limits=rate_limit_default_limits,
            )
        else:
            register_rate_limiting(
                app,
                storage_uri=rate_limit_storage_uri,
                key_func=rate_limit_key_func,
                default_limits=rate_limit_default_limits,
            )

    return app
