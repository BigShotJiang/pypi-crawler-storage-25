from __future__ import annotations

from collections.abc import Callable

from fastapi import Request
from fastapi_users.authentication import AuthenticationBackend, BearerTransport, JWTStrategy
from jose import JWTError, jwt


def create_bearer_transport(
    *,
    token_url: str = "/auth/login",
) -> BearerTransport:
    """
    Create a Bearer token transport for FastAPI Users.

    This controls where clients request login tokens from.
    """
    return BearerTransport(tokenUrl=token_url)


def create_jwt_strategy_getter(
    *,
    secret: str,
    lifetime_seconds: int,
    algorithm: str = "HS256",
) -> Callable[[], JWTStrategy]:
    """
    Create a FastAPI Users JWT strategy dependency.

    FastAPI Users expects a callable that returns a JWTStrategy.
    """

    async def get_jwt_strategy() -> JWTStrategy:
        return JWTStrategy(
            secret=secret,
            lifetime_seconds=lifetime_seconds,
            algorithm=algorithm,
        )

    return get_jwt_strategy


def create_jwt_auth_backend(
    *,
    secret: str,
    lifetime_seconds: int,
    algorithm: str = "HS256",
    token_url: str = "/auth/login",
    name: str = "jwt",
) -> AuthenticationBackend:
    """
    Create a JWT authentication backend for FastAPI Users.
    """
    return AuthenticationBackend(
        name=name,
        transport=create_bearer_transport(token_url=token_url),
        get_strategy=create_jwt_strategy_getter(
            secret=secret,
            lifetime_seconds=lifetime_seconds,
            algorithm=algorithm,
        ),
    )


def get_user_id_from_bearer_token(
    request: Request,
    *,
    secret: str,
    algorithm: str = "HS256",
    subject_claim: str = "sub",
    verify_audience: bool = False,
) -> str | None:
    """
    Extract the user ID from a Bearer JWT token.

    This is useful for rate-limit key functions, logging context,
    or lightweight request inspection.
    """
    authorization = request.headers.get("authorization") or ""

    if not authorization.lower().startswith("bearer "):
        return None

    token = authorization.split(" ", 1)[1].strip()

    if not token:
        return None

    try:
        payload = jwt.decode(
            token,
            secret,
            algorithms=[algorithm],
            options={"verify_aud": verify_audience},
        )
    except JWTError:
        return None

    subject = payload.get(subject_claim)

    return str(subject) if subject else None
