from __future__ import annotations

from fastvia.auth.dependencies import (
    create_current_user_dependency,
    create_fastapi_users,
    create_user_db_dependency,
    create_user_manager_dependency,
)
from fastvia.auth.security import (
    create_bearer_transport,
    create_jwt_auth_backend,
    create_jwt_strategy_getter,
    get_user_id_from_bearer_token,
)

__all__ = [
    "create_bearer_transport",
    "create_jwt_auth_backend",
    "create_jwt_strategy_getter",
    "get_user_id_from_bearer_token",
    "create_current_user_dependency",
    "create_fastapi_users",
    "create_user_manager_dependency",
    "create_user_db_dependency",
]
