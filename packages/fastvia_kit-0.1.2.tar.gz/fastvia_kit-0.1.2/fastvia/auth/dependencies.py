from __future__ import annotations

from collections.abc import AsyncGenerator, Callable, Sequence
from typing import Any, TypeVar

from fastapi import Depends
from fastapi_users import FastAPIUsers
from fastapi_users.authentication import AuthenticationBackend
from fastapi_users_db_sqlalchemy import SQLAlchemyUserDatabase
from sqlalchemy.ext.asyncio import AsyncSession

UserT = TypeVar("UserT")
IdT = TypeVar("IdT")
ManagerT = TypeVar("ManagerT")


def create_user_db_dependency(
    *,
    get_db: Callable[..., Any],
    user_model: type[UserT],
):
    db_dependency = Depends(get_db)

    async def get_user_db(
        db_session: AsyncSession = db_dependency,
    ) -> AsyncGenerator[SQLAlchemyUserDatabase, None]:
        yield SQLAlchemyUserDatabase(db_session, user_model)

    return get_user_db


def create_user_manager_dependency(
    *,
    manager_class: type[ManagerT],
    get_user_db: Callable[..., Any],
    get_db: Callable[..., Any],
):
    user_db_dependency = Depends(get_user_db)
    db_dependency = Depends(get_db)

    async def get_user_manager(
        user_db: SQLAlchemyUserDatabase = user_db_dependency,
        db_session: AsyncSession = db_dependency,
    ) -> AsyncGenerator[ManagerT, None]:
        yield manager_class(user_db, db_session)

    return get_user_manager


def create_fastapi_users(
    *,
    get_user_manager: Callable[..., Any],
    auth_backends: Sequence[AuthenticationBackend],
) -> FastAPIUsers[UserT, IdT]:
    return FastAPIUsers(
        get_user_manager,
        list(auth_backends),
    )


def create_current_user_dependency(
    fastapi_users: FastAPIUsers[UserT, IdT],
    *,
    active: bool = True,
    verified: bool = True,
    superuser: bool = False,
):
    return fastapi_users.current_user(
        active=active,
        verified=verified,
        superuser=superuser,
    )
