from __future__ import annotations

from http import HTTPStatus

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from starlette.responses import JSONResponse

from fastvia.errors.exceptions import FastviaError
from fastvia.logging import get_log_context


def _get_request_id(request: Request) -> str | None:
    request_id = getattr(request.state, "request_id", None)

    if request_id:
        return str(request_id)

    return get_log_context().get("request_id")


async def fastvia_error_handler(request: Request, exc: FastviaError) -> JSONResponse:
    return JSONResponse(
        status_code=int(exc.status_code),
        content={
            "error": exc.code,
            "message": exc.message,
            "details": exc.details,
            "request_id": _get_request_id(request),
        },
        headers=exc.headers,
    )


async def validation_error_handler(
    request: Request,
    exc: RequestValidationError,
) -> JSONResponse:
    return JSONResponse(
        status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
        content={
            "error": "validation_error",
            "message": "Invalid request data.",
            "details": exc.errors(),
            "request_id": _get_request_id(request),
        },
    )


def register_exception_handlers(app: FastAPI) -> None:
    app.add_exception_handler(FastviaError, fastvia_error_handler)
    app.add_exception_handler(RequestValidationError, validation_error_handler)
