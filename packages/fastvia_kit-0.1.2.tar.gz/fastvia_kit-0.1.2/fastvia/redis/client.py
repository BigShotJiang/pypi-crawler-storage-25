from __future__ import annotations

from redis.asyncio import Redis

_redis_clients: dict[str, Redis] = {}


def get_redis(
    redis_url: str,
    *,
    decode_responses: bool = True,
) -> Redis:
    cache_key = f"{redis_url}:{decode_responses}"

    if cache_key not in _redis_clients:
        _redis_clients[cache_key] = Redis.from_url(
            redis_url,
            decode_responses=decode_responses,
        )

    return _redis_clients[cache_key]


async def close_redis(redis_url: str, *, decode_responses: bool = True) -> None:
    cache_key = f"{redis_url}:{decode_responses}"

    client = _redis_clients.pop(cache_key, None)
    if client is not None:
        await client.aclose()


async def close_all_redis() -> None:
    clients = list(_redis_clients.values())
    _redis_clients.clear()

    for client in clients:
        await client.aclose()
