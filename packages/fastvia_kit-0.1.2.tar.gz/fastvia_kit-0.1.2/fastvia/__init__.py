from __future__ import annotations

from fastvia.bootstrap import bootstrap_fastvia
from fastvia.config import FastviaSettings

__version__ = "0.1.2"

__all__ = ["FastviaSettings", "__version__", "bootstrap_fastvia"]
