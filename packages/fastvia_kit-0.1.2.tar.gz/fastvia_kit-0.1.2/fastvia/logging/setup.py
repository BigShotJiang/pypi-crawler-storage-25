from __future__ import annotations

import json
import logging
import sys
from datetime import UTC, datetime
from typing import Any

from fastvia.logging.context import (
    event_id_ctx,
    event_type_ctx,
    method_ctx,
    path_ctx,
    request_id_ctx,
)

STANDARD_LOG_RECORD_FIELDS = {
    "name",
    "msg",
    "args",
    "levelname",
    "levelno",
    "pathname",
    "filename",
    "module",
    "exc_info",
    "exc_text",
    "stack_info",
    "lineno",
    "funcName",
    "created",
    "msecs",
    "relativeCreated",
    "thread",
    "threadName",
    "processName",
    "process",
    "taskName",
    "message",
    "asctime",
}

KNOWN_CONTEXT_FIELDS = {
    "request_id",
    "user_id",
    "method",
    "path",
    "event_id",
    "event_type",
}


def get_custom_log_fields(record: logging.LogRecord) -> dict[str, Any]:
    custom_fields: dict[str, Any] = {}

    for key, value in record.__dict__.items():
        if key in STANDARD_LOG_RECORD_FIELDS:
            continue

        if key in KNOWN_CONTEXT_FIELDS:
            continue

        if key.startswith("_"):
            continue

        if value is not None:
            custom_fields[key] = value

    return custom_fields


class ContextFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        record.request_id = getattr(record, "request_id", request_id_ctx.get())
        record.user_id = getattr(record, "user_id", None)
        record.path = getattr(record, "path", path_ctx.get())
        record.method = getattr(record, "method", method_ctx.get())
        record.event_id = getattr(record, "event_id", event_id_ctx.get())
        record.event_type = getattr(record, "event_type", event_type_ctx.get())
        return True


class ContextAwareFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        base = (
            f"{self.formatTime(record, self.datefmt)} | "
            f"{record.levelname} | "
            f"{record.name} | "
            f"{record.getMessage()}"
        )

        context_parts: list[str] = []

        for field in (
            "request_id",
            "user_id",
            "method",
            "path",
            "event_id",
            "event_type",
        ):
            value = getattr(record, field, None)
            if value is not None:
                context_parts.append(f"{field}={value}")

        for key, value in get_custom_log_fields(record).items():
            context_parts.append(f"{key}={value}")

        if context_parts:
            base = f"{base} | {' | '.join(context_parts)}"

        if record.exc_info:
            return f"{base}\n{self.formatException(record.exc_info)}"

        return base


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        log_data: dict[str, Any] = {
            "timestamp": datetime.now(UTC).isoformat(),
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "module": record.module,
            "function": record.funcName,
            "line": record.lineno,
        }

        for field in (
            "request_id",
            "user_id",
            "method",
            "path",
            "event_id",
            "event_type",
        ):
            value = getattr(record, field, None)
            if value is not None:
                log_data[field] = value

        log_data.update(get_custom_log_fields(record))

        if record.exc_info:
            log_data["exception"] = self.formatException(record.exc_info)

        return json.dumps(log_data, ensure_ascii=False, default=str)


def setup_logging(
    level: int | str = "INFO",
    log_format: str = "text",
    *,
    logger_name: str = "fastvia",
) -> logging.Logger:
    logger = logging.getLogger(logger_name)
    logger.setLevel(level)
    logger.handlers.clear()

    handler = logging.StreamHandler(sys.stdout)
    handler.setLevel(level)
    handler.addFilter(ContextFilter())

    if log_format.lower() == "json":
        handler.setFormatter(JsonFormatter())
    else:
        handler.setFormatter(ContextAwareFormatter())

    logger.addHandler(handler)
    logger.propagate = False

    return logger
