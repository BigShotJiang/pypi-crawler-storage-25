from __future__ import annotations

from contextvars import ContextVar, Token
from typing import Any

request_id_ctx: ContextVar[str | None] = ContextVar("request_id", default=None)
path_ctx: ContextVar[str | None] = ContextVar("path", default=None)
method_ctx: ContextVar[str | None] = ContextVar("method", default=None)

event_id_ctx: ContextVar[str | None] = ContextVar("event_id", default=None)
event_type_ctx: ContextVar[str | None] = ContextVar("event_type", default=None)


def set_log_context(
    *,
    request_id: str | None = None,
    path: str | None = None,
    method: str | None = None,
    event_id: str | None = None,
    event_type: str | None = None,
) -> dict[str, Token[Any]]:
    return {
        "request_id": request_id_ctx.set(request_id),
        "path": path_ctx.set(path),
        "method": method_ctx.set(method),
        "event_id": event_id_ctx.set(event_id),
        "event_type": event_type_ctx.set(event_type),
    }


def reset_log_context(tokens: dict[str, Token[Any]]) -> None:
    request_id_ctx.reset(tokens["request_id"])
    path_ctx.reset(tokens["path"])
    method_ctx.reset(tokens["method"])
    event_id_ctx.reset(tokens["event_id"])
    event_type_ctx.reset(tokens["event_type"])


def get_log_context() -> dict[str, str | None]:
    return {
        "request_id": request_id_ctx.get(),
        "path": path_ctx.get(),
        "method": method_ctx.get(),
        "event_id": event_id_ctx.get(),
        "event_type": event_type_ctx.get(),
    }


def log_extra(**values: object) -> dict[str, object]:
    return {key: value for key, value in values.items() if value is not None}
