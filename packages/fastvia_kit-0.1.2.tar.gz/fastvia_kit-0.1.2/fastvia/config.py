from __future__ import annotations

from typing import Literal

from pydantic import Field
from pydantic_settings import BaseSettings, SettingsConfigDict

Environment = Literal["dev", "test", "staging", "prod"]
LogFormat = Literal["plain", "json"]


class FastviaSettings(BaseSettings):
    """
    Base settings for Fastvia-powered FastAPI apps.

    Projects can inherit from this class and add their own settings.
    """

    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        extra="ignore",
        case_sensitive=True,
    )

    APP_NAME: str = "Fastvia App"
    ENV: Environment = "dev"

    API_V1_PREFIX: str = "/api/v1"

    ENABLE_DOCS: bool = True
    FORCE_HTTPS: bool = False

    LOG_LEVEL: str = "INFO"
    LOG_FORMAT: LogFormat = "plain"

    DATABASE_URL: str | None = None

    REDIS_URL: str = "redis://localhost:6379/0"

    RATE_LIMIT_ENABLED: bool = True
    RATE_LIMIT_STORAGE_URI: str | None = None

    CORS_ORIGINS: list[str] = Field(default_factory=list)
    TRUSTED_HOSTS: list[str] = Field(default_factory=list)

    ENABLE_GZIP: bool = True
    GZIP_MINIMUM_SIZE: int = 1000

    @property
    def is_prod(self) -> bool:
        return self.ENV == "prod"

    @property
    def docs_enabled(self) -> bool:
        return self.ENABLE_DOCS and not self.is_prod

    @property
    def rate_limit_storage_uri(self) -> str:
        return self.RATE_LIMIT_STORAGE_URI or self.REDIS_URL
