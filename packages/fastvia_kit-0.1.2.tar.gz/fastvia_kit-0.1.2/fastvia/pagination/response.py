from __future__ import annotations

from typing import Generic, TypeVar

from pydantic import BaseModel, ConfigDict

from fastvia.pagination.meta import PageMeta

T = TypeVar("T")


class PaginatedResponse(BaseModel, Generic[T]):
    items: list[T]
    meta: PageMeta

    model_config = ConfigDict(extra="forbid")
