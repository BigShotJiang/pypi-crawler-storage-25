from __future__ import annotations

from fastapi import Query
from pydantic import BaseModel, ConfigDict, Field, computed_field


class PaginationParams(BaseModel):
    """
    Standard pagination query parameters for list endpoints.
    """

    page: int = Field(
        default=1,
        ge=1,
        description="Page number. Must be greater than or equal to 1.",
    )
    per_page: int = Field(
        default=10,
        ge=1,
        le=100,
        description="Number of items per page. Maximum 100.",
    )

    model_config = ConfigDict(
        extra="forbid",
        json_schema_extra={
            "example": {
                "page": 2,
                "per_page": 20,
            }
        },
    )

    @computed_field
    @property
    def offset(self) -> int:
        return (self.page - 1) * self.per_page


def pagination_params(
    page: int = Query(
        1,
        ge=1,
        description="Page number. Must be greater than or equal to 1.",
    ),
    per_page: int = Query(
        10,
        ge=1,
        le=100,
        description="Number of items per page. Maximum 100.",
    ),
) -> PaginationParams:
    return PaginationParams(page=page, per_page=per_page)
