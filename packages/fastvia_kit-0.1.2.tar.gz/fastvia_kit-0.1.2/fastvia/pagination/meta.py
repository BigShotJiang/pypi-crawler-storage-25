from __future__ import annotations

from pydantic import BaseModel, ConfigDict, Field

from fastvia.pagination.params import PaginationParams


class PageMeta(BaseModel):
    """
    Metadata returned alongside paginated list responses.
    """

    total: int = Field(
        ...,
        ge=0,
        description="Total number of items available after filters are applied.",
    )
    page: int = Field(..., ge=1, description="Current page number.")
    per_page: int = Field(..., ge=1, le=100, description="Number of items per page.")
    pages: int = Field(..., ge=0, description="Total number of pages available.")
    has_next: bool = Field(..., description="Whether a next page exists.")
    has_prev: bool = Field(..., description="Whether a previous page exists.")

    model_config = ConfigDict(
        extra="forbid",
        json_schema_extra={
            "example": {
                "total": 42,
                "page": 2,
                "per_page": 10,
                "pages": 5,
                "has_next": True,
                "has_prev": True,
            }
        },
    )

    @classmethod
    def from_pagination(
        cls,
        *,
        total: int,
        pagination: PaginationParams,
    ) -> PageMeta:
        pages = 0 if total == 0 else (total + pagination.per_page - 1) // pagination.per_page

        return cls(
            total=total,
            page=pagination.page,
            per_page=pagination.per_page,
            pages=pages,
            has_next=pagination.page < pages,
            has_prev=pagination.page > 1 and pages > 0,
        )
