from __future__ import annotations

import json
from typing import Any

from arq.connections import ArqRedis, RedisSettings, create_pool


def job_serializer(data: Any) -> bytes:
    return json.dumps(data).encode("utf-8")


def job_deserializer(data: bytes) -> Any:
    return json.loads(data.decode("utf-8"))


def create_arq_redis_settings(redis_url: str) -> RedisSettings:
    return RedisSettings.from_dsn(redis_url)


async def create_arq_pool(
    redis_url: str,
    *,
    job_serializer_func=job_serializer,
    job_deserializer_func=job_deserializer,
) -> ArqRedis:
    return await create_pool(
        create_arq_redis_settings(redis_url),
        job_serializer=job_serializer_func,
        job_deserializer=job_deserializer_func,
    )
