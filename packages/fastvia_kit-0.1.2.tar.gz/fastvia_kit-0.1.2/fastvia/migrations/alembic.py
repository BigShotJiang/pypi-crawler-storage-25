from __future__ import annotations

from pathlib import Path

from alembic import command
from alembic.config import Config


def create_alembic_config(
    *,
    config_path: str | Path = "alembic.ini",
    database_url: str | None = None,
    script_location: str | None = None,
) -> Config:
    """
    Create an Alembic Config object.

    This keeps migrations explicit:
    - no automatic migration on app startup
    - no hidden database changes
    - app decides when to run upgrade/downgrade
    """
    config = Config(str(config_path))

    if database_url:
        config.set_main_option("sqlalchemy.url", database_url)

    if script_location:
        config.set_main_option("script_location", script_location)

    return config


def upgrade_to_head(config: Config) -> None:
    """
    Run Alembic upgrade head.
    """
    command.upgrade(config, "head")


def downgrade_to_base(config: Config) -> None:
    """
    Run Alembic downgrade base.
    """
    command.downgrade(config, "base")


def revision(
    config: Config,
    *,
    message: str,
    autogenerate: bool = False,
) -> None:
    """
    Create a new Alembic revision.
    """
    command.revision(
        config,
        message=message,
        autogenerate=autogenerate,
    )
