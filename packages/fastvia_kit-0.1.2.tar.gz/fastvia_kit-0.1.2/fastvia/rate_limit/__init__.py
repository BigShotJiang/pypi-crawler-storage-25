from __future__ import annotations

from fastvia.rate_limit.keys import UserIdResolver, ip_key, user_or_ip_key
from fastvia.rate_limit.setup import (
    auth_rate_limit,
    rate_limit_exceeded_handler,
    register_rate_limiting,
)

__all__ = [
    "UserIdResolver",
    "auth_rate_limit",
    "ip_key",
    "rate_limit_exceeded_handler",
    "register_rate_limiting",
    "user_or_ip_key",
]
