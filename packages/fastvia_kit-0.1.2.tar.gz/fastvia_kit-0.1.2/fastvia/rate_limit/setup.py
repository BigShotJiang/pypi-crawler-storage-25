from __future__ import annotations

from collections.abc import Callable

from fastapi import FastAPI, Request
from slowapi import Limiter
from slowapi.errors import RateLimitExceeded
from slowapi.middleware import SlowAPIMiddleware
from starlette.responses import JSONResponse

from fastvia.errors import RateLimitError
from fastvia.errors.handlers import fastvia_error_handler
from fastvia.rate_limit.keys import ip_key


async def rate_limit_exceeded_handler(
    request: Request,
    exc: RateLimitExceeded,
) -> JSONResponse:
    headers: dict[str, str] = {}

    retry_after = getattr(exc, "retry_after", None)
    if retry_after is not None:
        headers["Retry-After"] = str(retry_after)

    error = RateLimitError(
        "Too many requests. Please slow down.",
        details={
            "limit": str(exc.detail),
        },
        headers=headers or None,
    )

    return await fastvia_error_handler(request, error)


def register_rate_limiting(
    app: FastAPI,
    *,
    storage_uri: str,
    key_func: Callable[[Request], str] = ip_key,
    default_limits: list[str] | None = None,
) -> Limiter:
    limiter = Limiter(
        key_func=key_func,
        storage_uri=storage_uri,
        default_limits=default_limits or [],
    )

    app.state.limiter = limiter
    app.add_middleware(SlowAPIMiddleware)
    app.add_exception_handler(RateLimitExceeded, rate_limit_exceeded_handler)

    return limiter


def auth_rate_limit(limiter: Limiter, rule: str) -> Callable[[Request], object]:
    async def dummy(request: Request) -> None:
        return None

    decorated = limiter.limit(rule)(dummy)

    async def rate_limit_dep(request: Request) -> None:
        await decorated(request)

    return rate_limit_dep
