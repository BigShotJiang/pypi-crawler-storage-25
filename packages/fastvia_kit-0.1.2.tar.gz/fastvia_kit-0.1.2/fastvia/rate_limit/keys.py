from __future__ import annotations

from collections.abc import Callable

from fastapi import Request
from slowapi.util import get_remote_address

UserIdResolver = Callable[[Request], str | int | None]


def ip_key(request: Request) -> str:
    return f"ip:{get_remote_address(request)}"


def user_or_ip_key(
    *,
    user_id_resolver: UserIdResolver | None = None,
) -> Callable[[Request], str]:
    def key_func(request: Request) -> str:
        if user_id_resolver is not None:
            user_id = user_id_resolver(request)
            if user_id:
                return f"user:{user_id}"

        user = getattr(request.state, "user", None)
        user_id = getattr(user, "id", None)

        if user_id:
            return f"user:{user_id}"

        return ip_key(request)

    return key_func
