from __future__ import annotations

import time
import uuid

from starlette.types import ASGIApp, Message, Receive, Scope, Send

from fastvia.logging import reset_log_context, set_log_context


class RequestContextMiddleware:
    """
    Adds request context to every HTTP request.

    It stores:
    - request_id in scope["state"]
    - process_time in scope["state"]

    It also exposes:
    - X-Request-ID
    - X-Process-Time

    It connects request_id, path, and method to Fastvia logging context.
    """

    def __init__(
        self,
        app: ASGIApp,
        *,
        request_id_header: str = "x-request-id",
        process_time_header: str = "x-process-time",
    ) -> None:
        self.app = app
        self.request_id_header = request_id_header.lower()
        self.process_time_header = process_time_header.lower()

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        request_id = self._get_request_id(scope)
        method = str(scope.get("method") or "")
        path = str(scope.get("path") or "")

        scope.setdefault("state", {})
        scope["state"]["request_id"] = request_id
        scope["state"]["process_time"] = None

        tokens = set_log_context(
            request_id=request_id,
            method=method,
            path=path,
        )

        started_at = time.perf_counter()

        async def send_wrapper(message: Message) -> None:
            if message["type"] == "http.response.start":
                process_time = time.perf_counter() - started_at
                scope["state"]["process_time"] = process_time

                headers = list(message.get("headers", []))
                headers.append(
                    (
                        self.request_id_header.encode("latin-1"),
                        request_id.encode("latin-1"),
                    )
                )
                headers.append(
                    (
                        self.process_time_header.encode("latin-1"),
                        f"{process_time:.6f}".encode("latin-1"),
                    )
                )

                message["headers"] = headers

            await send(message)

        try:
            await self.app(scope, receive, send_wrapper)
        finally:
            reset_log_context(tokens)

    def _get_request_id(self, scope: Scope) -> str:
        headers = {
            key.decode("latin-1").lower(): value.decode("latin-1")
            for key, value in scope.get("headers", [])
        }

        return headers.get(self.request_id_header) or str(uuid.uuid4())
