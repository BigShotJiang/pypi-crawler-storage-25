from __future__ import annotations

from starlette.types import ASGIApp, Message, Receive, Scope, Send

DEFAULT_CSP = (
    "default-src 'self'; "
    "frame-ancestors 'none'; "
    "base-uri 'self'; "
    "form-action 'self'; "
    "object-src 'none';"
)

DEFAULT_HSTS = "max-age=31536000; includeSubDomains; preload"
DEFAULT_CACHE_CONTROL = "no-store, no-cache, must-revalidate, private"
DEFAULT_PERMISSIONS_POLICY = "camera=(), microphone=(), geolocation=()"


class SecurityHeadersMiddleware:
    """
    Adds common security headers to HTTP responses.

    Default behavior is strict and API-friendly.
    Users can override CSP, HSTS, cache-control, and cross-origin policies
    when their frontend or deployment needs something different.
    """

    def __init__(
        self,
        app: ASGIApp,
        *,
        enable_hsts: bool = False,
        hsts_value: str = DEFAULT_HSTS,
        csp_value: str | None = DEFAULT_CSP,
        cache_control_value: str | None = DEFAULT_CACHE_CONTROL,
        permissions_policy_value: str | None = DEFAULT_PERMISSIONS_POLICY,
        cross_origin_opener_policy: str | None = "same-origin",
        cross_origin_resource_policy: str | None = "same-origin",
    ) -> None:
        self.app = app
        self.enable_hsts = enable_hsts
        self.hsts_value = hsts_value
        self.csp_value = csp_value
        self.cache_control_value = cache_control_value
        self.permissions_policy_value = permissions_policy_value
        self.cross_origin_opener_policy = cross_origin_opener_policy
        self.cross_origin_resource_policy = cross_origin_resource_policy

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        async def send_wrapper(message: Message) -> None:
            if message["type"] == "http.response.start":
                headers = list(message.get("headers", []))

                self._set_default_header(headers, "x-content-type-options", "nosniff")
                self._set_default_header(headers, "x-frame-options", "DENY")
                self._set_default_header(
                    headers,
                    "referrer-policy",
                    "strict-origin-when-cross-origin",
                )

                if self.permissions_policy_value is not None:
                    self._set_default_header(
                        headers,
                        "permissions-policy",
                        self.permissions_policy_value,
                    )

                if self.cache_control_value is not None:
                    self._set_default_header(
                        headers,
                        "cache-control",
                        self.cache_control_value,
                    )

                if self.cross_origin_opener_policy is not None:
                    self._set_default_header(
                        headers,
                        "cross-origin-opener-policy",
                        self.cross_origin_opener_policy,
                    )

                if self.cross_origin_resource_policy is not None:
                    self._set_default_header(
                        headers,
                        "cross-origin-resource-policy",
                        self.cross_origin_resource_policy,
                    )

                if self.enable_hsts:
                    self._set_default_header(
                        headers,
                        "strict-transport-security",
                        self.hsts_value,
                    )

                if self.csp_value is not None:
                    self._set_default_header(
                        headers,
                        "content-security-policy",
                        self.csp_value,
                    )

                message["headers"] = headers

            await send(message)

        await self.app(scope, receive, send_wrapper)

    def _set_default_header(
        self,
        headers: list[tuple[bytes, bytes]],
        name: str,
        value: str,
    ) -> None:
        encoded_name = name.encode("latin-1")

        if any(header_name.lower() == encoded_name for header_name, _ in headers):
            return

        headers.append((encoded_name, value.encode("latin-1")))
