from __future__ import annotations

import json
import logging
import sys
from datetime import UTC, datetime

from fastvia.logging import (
    ContextAwareFormatter,
    ContextFilter,
    JsonFormatter,
    get_log_context,
    log_extra,
    reset_log_context,
    set_log_context,
    setup_logging,
)
from fastvia.logging.setup import get_custom_log_fields


def test_set_and_get_log_context() -> None:
    tokens = set_log_context(
        request_id="req_123",
        path="/ping",
        method="GET",
        event_id="evt_123",
        event_type="test.event",
    )

    try:
        assert get_log_context() == {
            "request_id": "req_123",
            "path": "/ping",
            "method": "GET",
            "event_id": "evt_123",
            "event_type": "test.event",
        }
    finally:
        reset_log_context(tokens)


def test_reset_log_context() -> None:
    tokens = set_log_context(request_id="req_123")

    reset_log_context(tokens)

    assert get_log_context() == {
        "request_id": None,
        "path": None,
        "method": None,
        "event_id": None,
        "event_type": None,
    }


def test_context_filter_adds_context_to_log_record() -> None:
    tokens = set_log_context(
        request_id="req_123",
        path="/items",
        method="POST",
        event_id="evt_123",
        event_type="item.created",
    )

    try:
        record = logging.LogRecord(
            name="test",
            level=logging.INFO,
            pathname=__file__,
            lineno=1,
            msg="hello",
            args=(),
            exc_info=None,
        )

        assert ContextFilter().filter(record) is True
        assert record.request_id == "req_123"
        assert record.path == "/items"
        assert record.method == "POST"
        assert record.event_id == "evt_123"
        assert record.event_type == "item.created"
    finally:
        reset_log_context(tokens)


def test_context_filter_keeps_user_id_from_extra() -> None:
    record = logging.LogRecord(
        name="test",
        level=logging.INFO,
        pathname=__file__,
        lineno=1,
        msg="hello",
        args=(),
        exc_info=None,
    )
    record.user_id = "user_123"

    assert ContextFilter().filter(record) is True
    assert record.user_id == "user_123"


def test_context_aware_formatter_includes_context() -> None:
    record = logging.LogRecord(
        name="test",
        level=logging.INFO,
        pathname=__file__,
        lineno=1,
        msg="hello boss",
        args=(),
        exc_info=None,
    )

    record.request_id = "req_123"
    record.method = "GET"
    record.path = "/ping"
    record.user_id = None
    record.event_id = None
    record.event_type = None

    output = ContextAwareFormatter().format(record)

    assert "hello boss" in output
    assert "request_id=req_123" in output
    assert "method=GET" in output
    assert "path=/ping" in output


def test_context_aware_formatter_includes_custom_extra_fields() -> None:
    record = logging.LogRecord(
        name="test",
        level=logging.INFO,
        pathname=__file__,
        lineno=1,
        msg="payment processed",
        args=(),
        exc_info=None,
    )

    record.request_id = "req_123"
    record.user_id = "user_123"
    record.payment_id = "pay_123"
    record.provider = "stripe"
    record.amount = 500
    record.event_id = None
    record.event_type = None

    output = ContextAwareFormatter().format(record)

    assert "payment processed" in output
    assert "request_id=req_123" in output
    assert "user_id=user_123" in output
    assert "payment_id=pay_123" in output
    assert "provider=stripe" in output
    assert "amount=500" in output


def test_context_aware_formatter_includes_exception() -> None:
    try:
        raise ValueError("broken")
    except ValueError:
        record = logging.LogRecord(
            name="test",
            level=logging.ERROR,
            pathname=__file__,
            lineno=1,
            msg="failed",
            args=(),
            exc_info=sys.exc_info(),
        )

    output = ContextAwareFormatter().format(record)

    assert "failed" in output
    assert "ValueError: broken" in output


def test_json_formatter_outputs_json_with_context() -> None:
    record = logging.LogRecord(
        name="test",
        level=logging.INFO,
        pathname=__file__,
        lineno=1,
        msg="hello json",
        args=(),
        exc_info=None,
    )

    record.request_id = "req_123"
    record.method = "GET"
    record.path = "/ping"
    record.user_id = None
    record.event_id = "evt_123"
    record.event_type = "demo.event"

    output = JsonFormatter().format(record)
    data = json.loads(output)

    assert data["level"] == "INFO"
    assert data["logger"] == "test"
    assert data["message"] == "hello json"
    assert data["request_id"] == "req_123"
    assert data["method"] == "GET"
    assert data["path"] == "/ping"
    assert data["event_id"] == "evt_123"
    assert data["event_type"] == "demo.event"


def test_json_formatter_includes_custom_extra_fields() -> None:
    record = logging.LogRecord(
        name="test",
        level=logging.INFO,
        pathname=__file__,
        lineno=1,
        msg="payment json",
        args=(),
        exc_info=None,
    )

    record.request_id = "req_123"
    record.user_id = "user_123"
    record.payment_id = "pay_123"
    record.provider = "stripe"
    record.amount = 500
    record.event_id = None
    record.event_type = None

    output = JsonFormatter().format(record)
    data = json.loads(output)

    assert data["message"] == "payment json"
    assert data["request_id"] == "req_123"
    assert data["user_id"] == "user_123"
    assert data["payment_id"] == "pay_123"
    assert data["provider"] == "stripe"
    assert data["amount"] == 500


def test_json_formatter_serializes_custom_non_json_values() -> None:
    record = logging.LogRecord(
        name="test",
        level=logging.INFO,
        pathname=__file__,
        lineno=1,
        msg="custom value",
        args=(),
        exc_info=None,
    )

    created_at = datetime(2026, 5, 6, tzinfo=UTC)
    record.created_at = created_at

    output = JsonFormatter().format(record)
    data = json.loads(output)

    assert data["created_at"] == str(created_at)


def test_json_formatter_includes_exception() -> None:
    try:
        raise RuntimeError("json broken")
    except RuntimeError:
        record = logging.LogRecord(
            name="test",
            level=logging.ERROR,
            pathname=__file__,
            lineno=1,
            msg="json failed",
            args=(),
            exc_info=sys.exc_info(),
        )

    output = JsonFormatter().format(record)
    data = json.loads(output)

    assert data["message"] == "json failed"
    assert "RuntimeError: json broken" in data["exception"]


def test_get_custom_log_fields_excludes_standard_and_context_fields() -> None:
    record = logging.LogRecord(
        name="test",
        level=logging.INFO,
        pathname=__file__,
        lineno=1,
        msg="hello",
        args=(),
        exc_info=None,
    )

    record.request_id = "req_123"
    record.method = "GET"
    record.path = "/items"
    record.user_id = "user_123"
    record.event_id = "evt_123"
    record.event_type = "demo.event"
    record.custom_value = "hello"
    record.none_value = None
    record._private_value = "hidden"

    custom_fields = get_custom_log_fields(record)

    assert custom_fields == {
        "custom_value": "hello",
    }


def test_setup_logging_returns_configured_logger() -> None:
    logger = setup_logging(level="INFO", log_format="text", logger_name="fastvia_test")

    assert logger.name == "fastvia_test"
    assert logger.level == logging.INFO
    assert logger.propagate is False
    assert len(logger.handlers) == 1
    assert isinstance(logger.handlers[0].formatter, ContextAwareFormatter)


def test_setup_logging_supports_json_format() -> None:
    logger = setup_logging(level="INFO", log_format="json", logger_name="fastvia_json_test")

    assert isinstance(logger.handlers[0].formatter, JsonFormatter)


def test_log_extra_removes_none_values() -> None:
    extra = log_extra(
        event_id="evt_123",
        event_type=None,
        custom_value="hello",
    )

    assert extra == {
        "event_id": "evt_123",
        "custom_value": "hello",
    }


def test_log_extra_supports_dynamic_custom_fields() -> None:
    extra = log_extra(
        user_id="user_123",
        payment_id="pay_123",
        provider="stripe",
        amount=500,
        ignored=None,
    )

    assert extra == {
        "user_id": "user_123",
        "payment_id": "pay_123",
        "provider": "stripe",
        "amount": 500,
    }
