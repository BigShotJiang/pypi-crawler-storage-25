from __future__ import annotations

import pytest
from redis.asyncio import Redis

from fastvia.redis import close_all_redis, close_redis, get_redis


def test_get_redis_returns_redis_client() -> None:
    client = get_redis("redis://localhost:6379/0")

    assert isinstance(client, Redis)


def test_get_redis_reuses_same_client_for_same_url() -> None:
    first = get_redis("redis://localhost:6379/0")
    second = get_redis("redis://localhost:6379/0")

    assert first is second


def test_get_redis_creates_different_clients_for_different_options() -> None:
    first = get_redis("redis://localhost:6379/0", decode_responses=True)
    second = get_redis("redis://localhost:6379/0", decode_responses=False)

    assert first is not second


@pytest.mark.asyncio
async def test_close_redis_removes_single_client() -> None:
    first = get_redis("redis://localhost:6379/1")

    await close_redis("redis://localhost:6379/1")

    second = get_redis("redis://localhost:6379/1")

    try:
        assert first is not second
    finally:
        await close_redis("redis://localhost:6379/1")


@pytest.mark.asyncio
async def test_close_all_redis_clears_cached_clients() -> None:
    first = get_redis("redis://localhost:6379/2")
    second = get_redis("redis://localhost:6379/3")

    await close_all_redis()

    new_first = get_redis("redis://localhost:6379/2")
    new_second = get_redis("redis://localhost:6379/3")

    try:
        assert first is not new_first
        assert second is not new_second
    finally:
        await close_all_redis()
