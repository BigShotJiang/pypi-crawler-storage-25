from __future__ import annotations

from http import HTTPStatus

from fastapi import FastAPI
from fastapi.testclient import TestClient

from fastvia import bootstrap_fastvia
from fastvia.errors import NotFoundError


def test_bootstrap_fastvia_adds_default_middlewares_and_error_handlers() -> None:
    app = FastAPI()

    bootstrap_fastvia(
        app,
        enable_logging=False,
        cors_origins=[],
        rate_limit_storage_uri="memory://",
        enable_rate_limiting=False,
    )

    @app.get("/ping")
    async def ping() -> dict[str, str]:
        return {"message": "pong"}

    @app.get("/missing")
    async def missing() -> None:
        raise NotFoundError("Missing item.")

    client = TestClient(app)

    ping_response = client.get("/ping")

    assert ping_response.status_code == HTTPStatus.OK
    assert ping_response.headers.get("x-request-id")
    assert ping_response.headers.get("x-process-time")
    assert ping_response.headers["x-content-type-options"] == "nosniff"

    missing_response = client.get("/missing", headers={"x-request-id": "req_bootstrap"})

    assert missing_response.status_code == HTTPStatus.NOT_FOUND
    assert missing_response.json() == {
        "error": "not_found",
        "message": "Missing item.",
        "details": {},
        "request_id": "req_bootstrap",
    }


def test_bootstrap_fastvia_can_disable_defaults() -> None:
    app = FastAPI()

    bootstrap_fastvia(
        app,
        enable_logging=False,
        cors_origins=[],
        rate_limit_storage_uri="memory://",
        enable_rate_limiting=False,
        add_request_context=False,
        add_security_headers=False,
        register_errors=False,
        enable_gzip=False,
    )

    @app.get("/ping")
    async def ping() -> dict[str, str]:
        return {"message": "pong"}

    client = TestClient(app)

    response = client.get("/ping")

    assert response.status_code == HTTPStatus.OK
    assert "x-request-id" not in response.headers
    assert "x-process-time" not in response.headers
    assert "x-content-type-options" not in response.headers


def test_bootstrap_fastvia_adds_cors_when_origins_are_provided() -> None:
    app = FastAPI()

    bootstrap_fastvia(
        app,
        enable_logging=False,
        cors_origins=["https://example.com"],
        rate_limit_storage_uri="memory://",
        enable_rate_limiting=False,
    )

    @app.get("/ping")
    async def ping() -> dict[str, str]:
        return {"message": "pong"}

    client = TestClient(app)

    response = client.options(
        "/ping",
        headers={
            "origin": "https://example.com",
            "access-control-request-method": "GET",
        },
    )

    assert response.status_code == HTTPStatus.OK
    assert response.headers["access-control-allow-origin"] == "https://example.com"


def test_bootstrap_fastvia_registers_rate_limiting_when_enabled() -> None:
    app = FastAPI()

    bootstrap_fastvia(
        app,
        enable_logging=False,
        cors_origins=[],
        rate_limit_storage_uri="memory://",
        enable_rate_limiting=True,
    )

    assert hasattr(app.state, "limiter")
