from __future__ import annotations

from http import HTTPStatus

import pytest
from fastapi import FastAPI, Request
from fastapi.testclient import TestClient
from fastapi_users.authentication import AuthenticationBackend, BearerTransport, JWTStrategy
from jose import jwt

from fastvia.auth import (
    create_bearer_transport,
    create_jwt_auth_backend,
    create_jwt_strategy_getter,
    get_user_id_from_bearer_token,
)

SECRET = "test-secret"
ALGORITHM = "HS256"


def test_create_bearer_transport() -> None:
    transport = create_bearer_transport(token_url="/api/auth/login")

    assert isinstance(transport, BearerTransport)


@pytest.mark.asyncio
async def test_create_jwt_strategy_getter() -> None:
    get_strategy = create_jwt_strategy_getter(
        secret=SECRET,
        lifetime_seconds=3600,
        algorithm=ALGORITHM,
    )

    strategy = await get_strategy()

    assert isinstance(strategy, JWTStrategy)


def test_create_jwt_auth_backend() -> None:
    backend = create_jwt_auth_backend(
        secret=SECRET,
        lifetime_seconds=3600,
        algorithm=ALGORITHM,
        token_url="/api/auth/login",
        name="jwt",
    )

    assert isinstance(backend, AuthenticationBackend)
    assert backend.name == "jwt"


def test_get_user_id_from_bearer_token_returns_subject() -> None:
    app = FastAPI()

    @app.get("/me")
    async def me(request: Request) -> dict[str, str | None]:
        user_id = get_user_id_from_bearer_token(
            request,
            secret=SECRET,
            algorithm=ALGORITHM,
        )
        return {"user_id": user_id}

    token = jwt.encode({"sub": "user_123"}, SECRET, algorithm=ALGORITHM)

    client = TestClient(app)

    response = client.get(
        "/me",
        headers={"authorization": f"Bearer {token}"},
    )

    assert response.status_code == HTTPStatus.OK
    assert response.json() == {"user_id": "user_123"}


def test_get_user_id_from_bearer_token_returns_none_without_token() -> None:
    app = FastAPI()

    @app.get("/me")
    async def me(request: Request) -> dict[str, str | None]:
        user_id = get_user_id_from_bearer_token(
            request,
            secret=SECRET,
            algorithm=ALGORITHM,
        )
        return {"user_id": user_id}

    client = TestClient(app)

    response = client.get("/me")

    assert response.status_code == HTTPStatus.OK
    assert response.json() == {"user_id": None}


def test_get_user_id_from_bearer_token_returns_none_for_invalid_token() -> None:
    app = FastAPI()

    @app.get("/me")
    async def me(request: Request) -> dict[str, str | None]:
        user_id = get_user_id_from_bearer_token(
            request,
            secret=SECRET,
            algorithm=ALGORITHM,
        )
        return {"user_id": user_id}

    client = TestClient(app)

    response = client.get(
        "/me",
        headers={"authorization": "Bearer invalid-token"},
    )

    assert response.status_code == HTTPStatus.OK
    assert response.json() == {"user_id": None}


def test_get_user_id_from_bearer_token_supports_custom_subject_claim() -> None:
    app = FastAPI()

    @app.get("/me")
    async def me(request: Request) -> dict[str, str | None]:
        user_id = get_user_id_from_bearer_token(
            request,
            secret=SECRET,
            algorithm=ALGORITHM,
            subject_claim="user_id",
        )
        return {"user_id": user_id}

    token = jwt.encode({"user_id": "custom_123"}, SECRET, algorithm=ALGORITHM)

    client = TestClient(app)

    response = client.get(
        "/me",
        headers={"authorization": f"Bearer {token}"},
    )

    assert response.status_code == HTTPStatus.OK
    assert response.json() == {"user_id": "custom_123"}
