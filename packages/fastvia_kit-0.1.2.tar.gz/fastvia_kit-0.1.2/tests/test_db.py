from __future__ import annotations

from collections.abc import AsyncGenerator

import pytest
from sqlalchemy.ext.asyncio import AsyncEngine, AsyncSession, async_sessionmaker
from sqlalchemy.sql import text

from fastvia.db import (
    create_async_db_engine,
    create_session_dependency,
    create_session_factory,
)


@pytest.mark.asyncio
async def test_create_async_db_engine_returns_async_engine() -> None:
    engine = create_async_db_engine("sqlite+aiosqlite:///:memory:")

    try:
        assert isinstance(engine, AsyncEngine)
    finally:
        await engine.dispose()


@pytest.mark.asyncio
async def test_create_session_factory_returns_async_sessionmaker() -> None:
    engine = create_async_db_engine("sqlite+aiosqlite:///:memory:")

    try:
        session_factory = create_session_factory(engine)

        assert isinstance(session_factory, async_sessionmaker)

        async with session_factory() as session:
            assert isinstance(session, AsyncSession)
    finally:
        await engine.dispose()


@pytest.mark.asyncio
async def test_create_session_dependency_yields_async_session() -> None:
    engine = create_async_db_engine("sqlite+aiosqlite:///:memory:")

    try:
        session_factory = create_session_factory(engine)
        get_db = create_session_dependency(session_factory)

        session_generator: AsyncGenerator[AsyncSession, None] = get_db()
        session = await anext(session_generator)

        try:
            assert isinstance(session, AsyncSession)
        finally:
            await session_generator.aclose()
    finally:
        await engine.dispose()


@pytest.mark.asyncio
async def test_session_can_execute_query() -> None:
    engine = create_async_db_engine("sqlite+aiosqlite:///:memory:")

    try:
        session_factory = create_session_factory(engine)

        async with session_factory() as session:
            result = await session.execute(text("SELECT 1"))
            assert result.scalar_one() == 1
    finally:
        await engine.dispose()


@pytest.mark.asyncio
async def test_session_factory_options_are_applied() -> None:
    engine = create_async_db_engine("sqlite+aiosqlite:///:memory:")

    try:
        session_factory = create_session_factory(
            engine,
            expire_on_commit=False,
            autoflush=False,
        )

        async with session_factory() as session:
            assert session.autoflush is False

            result = await session.execute(text("SELECT 1"))
            assert result.scalar_one() == 1
    finally:
        await engine.dispose()
