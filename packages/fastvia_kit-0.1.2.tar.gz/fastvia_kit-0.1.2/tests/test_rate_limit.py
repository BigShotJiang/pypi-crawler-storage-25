from __future__ import annotations

from http import HTTPStatus

from fastapi import FastAPI, Request
from fastapi.testclient import TestClient

from fastvia.middleware import RequestContextMiddleware
from fastvia.rate_limit import (
    auth_rate_limit,
    ip_key,
    rate_limit_exceeded_handler,
    register_rate_limiting,
    user_or_ip_key,
)


class FakeRateLimitExceeded:
    detail = "1/minute"
    retry_after = 60


def test_ip_key_uses_client_ip() -> None:
    app = FastAPI()

    @app.get("/key")
    async def key_route(request: Request) -> dict[str, str]:
        return {"key": ip_key(request)}

    client = TestClient(app)

    response = client.get("/key")

    assert response.status_code == HTTPStatus.OK
    assert response.json()["key"].startswith("ip:")


def test_user_or_ip_key_uses_state_user_when_available() -> None:
    app = FastAPI()

    class User:
        id = "user_123"

    @app.middleware("http")
    async def add_user_to_state(request: Request, call_next):
        request.state.user = User()
        return await call_next(request)

    @app.get("/key")
    async def key_route(request: Request) -> dict[str, str]:
        key_func = user_or_ip_key()
        return {"key": key_func(request)}

    client = TestClient(app)

    response = client.get("/key")

    assert response.status_code == HTTPStatus.OK
    assert response.json() == {"key": "user:user_123"}


def test_user_or_ip_key_uses_custom_user_id_resolver() -> None:
    app = FastAPI()

    @app.get("/key")
    async def key_route(request: Request) -> dict[str, str]:
        key_func = user_or_ip_key(user_id_resolver=lambda _: "resolved_user")
        return {"key": key_func(request)}

    client = TestClient(app)

    response = client.get("/key")

    assert response.status_code == HTTPStatus.OK
    assert response.json() == {"key": "user:resolved_user"}


def test_register_rate_limiting_adds_limiter_to_app_state() -> None:
    app = FastAPI()

    limiter = register_rate_limiting(
        app,
        storage_uri="memory://",
        default_limits=[],
    )

    assert app.state.limiter is limiter


def test_rate_limit_handler_returns_fastvia_error_response() -> None:
    app = FastAPI()
    app.add_middleware(RequestContextMiddleware)

    @app.get("/limited")
    async def limited(request: Request):
        return await rate_limit_exceeded_handler(
            request,
            FakeRateLimitExceeded(),  # type: ignore[arg-type]
        )

    client = TestClient(app)

    response = client.get("/limited", headers={"x-request-id": "req_limit"})

    assert response.status_code == HTTPStatus.TOO_MANY_REQUESTS
    assert response.headers["retry-after"] == "60"
    assert response.json() == {
        "error": "rate_limit_exceeded",
        "message": "Too many requests. Please slow down.",
        "details": {"limit": "1/minute"},
        "request_id": "req_limit",
    }


def test_auth_rate_limit_dependency_can_be_created() -> None:
    app = FastAPI()

    limiter = register_rate_limiting(
        app,
        storage_uri="memory://",
        default_limits=[],
    )

    dependency = auth_rate_limit(limiter, "1/minute")

    assert callable(dependency)
