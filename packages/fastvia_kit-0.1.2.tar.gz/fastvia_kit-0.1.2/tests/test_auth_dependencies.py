from __future__ import annotations

from collections.abc import AsyncGenerator
from http import HTTPStatus
from uuid import UUID, uuid4

import pytest
from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient
from fastapi_users.authentication import AuthenticationBackend, BearerTransport, Strategy
from fastapi_users.manager import BaseUserManager, UUIDIDMixin
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession

from fastvia.auth import (
    create_current_user_dependency,
    create_fastapi_users,
    create_user_db_dependency,
    create_user_manager_dependency,
)


class DummyUser(BaseModel):
    id: UUID
    email: str
    is_active: bool = True
    is_superuser: bool = False
    is_verified: bool = True


class DummyUserManager(UUIDIDMixin, BaseUserManager[DummyUser, UUID]):
    reset_password_token_secret = "secret"
    verification_token_secret = "secret"

    def __init__(self, user_db, db_session):
        super().__init__(user_db)
        self.db_session = db_session


class DummyStrategy(Strategy[DummyUser, UUID]):
    async def read_token(self, token, user_manager):
        return None

    async def write_token(self, user):
        return "token"

    async def destroy_token(self, token, user):
        return None


async def get_db() -> AsyncGenerator[AsyncSession, None]:
    yield None


def test_create_user_db_dependency_returns_dependency_callable() -> None:
    get_user_db = create_user_db_dependency(
        get_db=get_db,
        user_model=DummyUser,
    )

    assert callable(get_user_db)


@pytest.mark.asyncio
async def test_user_db_dependency_yields_sqlalchemy_user_database() -> None:
    get_user_db = create_user_db_dependency(
        get_db=get_db,
        user_model=DummyUser,
    )

    generator = get_user_db(None)
    user_db = await anext(generator)

    try:
        assert user_db is not None
    finally:
        await generator.aclose()


def test_create_user_manager_dependency_returns_dependency_callable() -> None:
    get_user_db = create_user_db_dependency(
        get_db=get_db,
        user_model=DummyUser,
    )

    get_user_manager = create_user_manager_dependency(
        manager_class=DummyUserManager,
        get_user_db=get_user_db,
        get_db=get_db,
    )

    assert callable(get_user_manager)


@pytest.mark.asyncio
async def test_user_manager_dependency_yields_manager() -> None:
    get_user_db = create_user_db_dependency(
        get_db=get_db,
        user_model=DummyUser,
    )

    get_user_manager = create_user_manager_dependency(
        manager_class=DummyUserManager,
        get_user_db=get_user_db,
        get_db=get_db,
    )

    class FakeUserDb:
        pass

    generator = get_user_manager(FakeUserDb(), None)
    manager = await anext(generator)

    try:
        assert isinstance(manager, DummyUserManager)
    finally:
        await generator.aclose()


def test_create_fastapi_users_returns_instance() -> None:
    async def get_user_manager():
        yield None

    backend = AuthenticationBackend(
        name="jwt",
        transport=BearerTransport(tokenUrl="/auth/login"),
        get_strategy=lambda: DummyStrategy(),
    )

    fastapi_users = create_fastapi_users(
        get_user_manager=get_user_manager,
        auth_backends=[backend],
    )

    assert fastapi_users is not None


def test_create_current_user_dependency_returns_callable() -> None:
    async def get_user_manager():
        yield None

    backend = AuthenticationBackend(
        name="jwt",
        transport=BearerTransport(tokenUrl="/auth/login"),
        get_strategy=lambda: DummyStrategy(),
    )

    fastapi_users = create_fastapi_users(
        get_user_manager=get_user_manager,
        auth_backends=[backend],
    )

    current_user = create_current_user_dependency(
        fastapi_users,
        active=True,
        verified=True,
    )

    assert callable(current_user)


def test_current_user_dependency_can_be_used_in_route() -> None:
    app = FastAPI()

    expected_user = DummyUser(
        id=uuid4(),
        email="test@example.com",
    )

    async def fake_current_user() -> DummyUser:
        return expected_user

    UserDep = Depends(fake_current_user)

    @app.get("/me")
    async def me(user: DummyUser = UserDep) -> dict[str, str]:
        return {"id": str(user.id), "email": user.email}

    client = TestClient(app)

    response = client.get("/me")

    assert response.status_code == HTTPStatus.OK
    assert response.json() == {
        "id": str(expected_user.id),
        "email": expected_user.email,
    }
