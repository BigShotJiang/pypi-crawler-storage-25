from __future__ import annotations

from arq.connections import RedisSettings

from fastvia.jobs import create_arq_redis_settings, job_deserializer, job_serializer


def test_job_serializer_and_deserializer_round_trip() -> None:
    payload = {
        "event_id": "evt_123",
        "event_type": "demo.event",
        "count": 3,
        "active": True,
    }

    serialized = job_serializer(payload)
    deserialized = job_deserializer(serialized)

    assert isinstance(serialized, bytes)
    assert deserialized == payload


def test_create_arq_redis_settings_from_dsn() -> None:
    settings = create_arq_redis_settings("redis://localhost:6379/2")

    assert isinstance(settings, RedisSettings)
    assert settings.host == "localhost"
    assert settings.port == 6379
    assert settings.database == 2
