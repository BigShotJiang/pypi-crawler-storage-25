from __future__ import annotations

from http import HTTPStatus

from fastapi import FastAPI
from fastapi.testclient import TestClient

from fastvia.logging import get_log_context
from fastvia.middleware import RequestContextMiddleware, SecurityHeadersMiddleware


def create_test_app() -> FastAPI:
    app = FastAPI()

    app.add_middleware(SecurityHeadersMiddleware)
    app.add_middleware(RequestContextMiddleware)

    @app.get("/ping")
    async def ping() -> dict[str, str]:
        return {"message": "pong"}

    return app


def test_request_context_headers_are_added() -> None:
    client = TestClient(create_test_app())

    response = client.get("/ping")

    assert response.status_code == HTTPStatus.OK
    assert response.headers.get("x-request-id")
    assert response.headers.get("x-process-time")


def test_existing_request_id_is_reused() -> None:
    client = TestClient(create_test_app())

    response = client.get("/ping", headers={"x-request-id": "test-request-id"})

    assert response.status_code == HTTPStatus.OK
    assert response.headers["x-request-id"] == "test-request-id"


def test_request_context_is_available_in_logging_context() -> None:
    app = FastAPI()
    app.add_middleware(RequestContextMiddleware)

    @app.get("/context")
    async def context() -> dict[str, str | None]:
        context_data = get_log_context()

        return {
            "request_id": context_data["request_id"],
            "method": context_data["method"],
            "path": context_data["path"],
        }

    client = TestClient(app)

    response = client.get("/context", headers={"x-request-id": "req_test"})

    assert response.status_code == HTTPStatus.OK
    assert response.json() == {
        "request_id": "req_test",
        "method": "GET",
        "path": "/context",
    }


def test_logging_context_is_reset_after_request() -> None:
    app = FastAPI()
    app.add_middleware(RequestContextMiddleware)

    @app.get("/context")
    async def context() -> dict[str, str | None]:
        return get_log_context()

    client = TestClient(app)

    response = client.get("/context", headers={"x-request-id": "req_test"})

    assert response.status_code == HTTPStatus.OK
    assert response.json()["request_id"] == "req_test"

    assert get_log_context() == {
        "request_id": None,
        "path": None,
        "method": None,
        "event_id": None,
        "event_type": None,
    }


def test_security_headers_are_added() -> None:
    client = TestClient(create_test_app())

    response = client.get("/ping")

    assert response.status_code == HTTPStatus.OK
    assert response.headers["x-content-type-options"] == "nosniff"
    assert response.headers["x-frame-options"] == "DENY"
    assert response.headers["referrer-policy"] == "strict-origin-when-cross-origin"
    assert response.headers["permissions-policy"] == "camera=(), microphone=(), geolocation=()"
    assert response.headers["cache-control"] == "no-store, no-cache, must-revalidate, private"
    assert response.headers["cross-origin-opener-policy"] == "same-origin"
    assert response.headers["cross-origin-resource-policy"] == "same-origin"
    assert "content-security-policy" in response.headers


def test_security_headers_do_not_override_existing_headers() -> None:
    app = FastAPI()
    app.add_middleware(SecurityHeadersMiddleware)

    @app.middleware("http")
    async def add_custom_header(request, call_next):
        response = await call_next(request)
        response.headers["X-Frame-Options"] = "SAMEORIGIN"
        return response

    @app.get("/custom")
    async def custom() -> dict[str, str]:
        return {"message": "ok"}

    client = TestClient(app)

    response = client.get("/custom")

    assert response.status_code == HTTPStatus.OK
    assert response.headers["x-frame-options"] == "SAMEORIGIN"


def test_hsts_is_disabled_by_default() -> None:
    client = TestClient(create_test_app())

    response = client.get("/ping")

    assert "strict-transport-security" not in response.headers


def test_hsts_can_be_enabled() -> None:
    app = FastAPI()
    app.add_middleware(SecurityHeadersMiddleware, enable_hsts=True)

    @app.get("/ping")
    async def ping() -> dict[str, str]:
        return {"message": "pong"}

    client = TestClient(app)

    response = client.get("/ping")

    assert response.headers["strict-transport-security"] == (
        "max-age=31536000; includeSubDomains; preload"
    )


def test_csp_can_be_disabled() -> None:
    app = FastAPI()
    app.add_middleware(SecurityHeadersMiddleware, csp_value=None)

    @app.get("/ping")
    async def ping() -> dict[str, str]:
        return {"message": "pong"}

    client = TestClient(app)

    response = client.get("/ping")

    assert "content-security-policy" not in response.headers


def test_csp_can_be_customized() -> None:
    app = FastAPI()
    app.add_middleware(
        SecurityHeadersMiddleware,
        csp_value="default-src 'self'; img-src 'self' data:;",
    )

    @app.get("/ping")
    async def ping() -> dict[str, str]:
        return {"message": "pong"}

    client = TestClient(app)

    response = client.get("/ping")

    assert response.headers["content-security-policy"] == (
        "default-src 'self'; img-src 'self' data:;"
    )


def test_cache_control_can_be_disabled() -> None:
    app = FastAPI()
    app.add_middleware(SecurityHeadersMiddleware, cache_control_value=None)

    @app.get("/ping")
    async def ping() -> dict[str, str]:
        return {"message": "pong"}

    client = TestClient(app)

    response = client.get("/ping")

    assert "cache-control" not in response.headers


def test_permissions_policy_can_be_disabled() -> None:
    app = FastAPI()
    app.add_middleware(SecurityHeadersMiddleware, permissions_policy_value=None)

    @app.get("/ping")
    async def ping() -> dict[str, str]:
        return {"message": "pong"}

    client = TestClient(app)

    response = client.get("/ping")

    assert "permissions-policy" not in response.headers


def test_cross_origin_headers_can_be_disabled() -> None:
    app = FastAPI()
    app.add_middleware(
        SecurityHeadersMiddleware,
        cross_origin_opener_policy=None,
        cross_origin_resource_policy=None,
    )

    @app.get("/ping")
    async def ping() -> dict[str, str]:
        return {"message": "pong"}

    client = TestClient(app)

    response = client.get("/ping")

    assert "cross-origin-opener-policy" not in response.headers
    assert "cross-origin-resource-policy" not in response.headers
