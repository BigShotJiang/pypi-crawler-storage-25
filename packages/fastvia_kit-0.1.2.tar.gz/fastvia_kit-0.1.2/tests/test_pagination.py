from __future__ import annotations

from http import HTTPStatus

from fastapi import Depends, FastAPI
from fastapi.testclient import TestClient
from pydantic import BaseModel

from fastvia.pagination import PageMeta, PaginatedResponse, PaginationParams, pagination_params

PaginationDep = Depends(pagination_params)


class ItemOut(BaseModel):
    id: int
    name: str


def test_pagination_params_defaults() -> None:
    params = PaginationParams()

    assert params.page == 1
    assert params.per_page == 10
    assert params.offset == 0


def test_pagination_params_offset() -> None:
    params = PaginationParams(page=3, per_page=20)

    assert params.offset == 40


def test_page_meta_from_pagination_with_items() -> None:
    pagination = PaginationParams(page=2, per_page=10)

    meta = PageMeta.from_pagination(total=42, pagination=pagination)

    assert meta.total == 42
    assert meta.page == 2
    assert meta.per_page == 10
    assert meta.pages == 5
    assert meta.has_next is True
    assert meta.has_prev is True


def test_page_meta_from_pagination_with_zero_total() -> None:
    pagination = PaginationParams(page=1, per_page=10)

    meta = PageMeta.from_pagination(total=0, pagination=pagination)

    assert meta.total == 0
    assert meta.pages == 0
    assert meta.has_next is False
    assert meta.has_prev is False


def test_paginated_response_shape() -> None:
    pagination = PaginationParams(page=1, per_page=10)
    meta = PageMeta.from_pagination(total=2, pagination=pagination)

    response = PaginatedResponse[ItemOut](
        items=[
            ItemOut(id=1, name="First"),
            ItemOut(id=2, name="Second"),
        ],
        meta=meta,
    )

    assert response.model_dump() == {
        "items": [
            {"id": 1, "name": "First"},
            {"id": 2, "name": "Second"},
        ],
        "meta": {
            "total": 2,
            "page": 1,
            "per_page": 10,
            "pages": 1,
            "has_next": False,
            "has_prev": False,
        },
    }


def test_pagination_dependency() -> None:
    app = FastAPI()

    @app.get("/items")
    async def list_items(
        pagination: PaginationParams = PaginationDep,
    ) -> dict[str, int]:
        return {
            "page": pagination.page,
            "per_page": pagination.per_page,
            "offset": pagination.offset,
        }

    client = TestClient(app)

    response = client.get("/items?page=4&per_page=15")

    assert response.status_code == HTTPStatus.OK
    assert response.json() == {
        "page": 4,
        "per_page": 15,
        "offset": 45,
    }


def test_pagination_dependency_rejects_invalid_values() -> None:
    app = FastAPI()

    @app.get("/items")
    async def list_items(
        pagination: PaginationParams = PaginationDep,
    ) -> dict[str, int]:
        return {
            "page": pagination.page,
            "per_page": pagination.per_page,
            "offset": pagination.offset,
        }

    client = TestClient(app)

    response = client.get("/items?page=0&per_page=101")

    assert response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY
