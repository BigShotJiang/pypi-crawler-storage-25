from __future__ import annotations

from http import HTTPStatus

from fastapi import FastAPI
from fastapi.testclient import TestClient
from pydantic import BaseModel

from fastvia.errors import (
    BadRequestError,
    ConflictError,
    FastviaError,
    ForbiddenError,
    NotFoundError,
    RateLimitError,
    ServiceUnavailableError,
    UnauthorizedError,
    ValidationError,
    register_exception_handlers,
)
from fastvia.middleware import RequestContextMiddleware


class ItemPayload(BaseModel):
    name: str
    quantity: int


def create_test_app() -> FastAPI:
    app = FastAPI()
    app.add_middleware(RequestContextMiddleware)
    register_exception_handlers(app)

    @app.get("/not-found")
    async def not_found() -> None:
        raise NotFoundError("Item not found.")

    @app.get("/custom")
    async def custom_error() -> None:
        raise BadRequestError(
            "Invalid plan selected.",
            code="invalid_plan",
            details={"allowed": ["free", "pro"]},
        )

    @app.get("/headers")
    async def error_with_headers() -> None:
        raise RateLimitError(headers={"Retry-After": "60"})

    @app.post("/items")
    async def create_item(payload: ItemPayload) -> dict[str, object]:
        return payload.model_dump()

    return app


def test_fastvia_error_classes_have_expected_defaults() -> None:
    assert FastviaError().status_code == HTTPStatus.INTERNAL_SERVER_ERROR
    assert BadRequestError().status_code == HTTPStatus.BAD_REQUEST
    assert UnauthorizedError().status_code == HTTPStatus.UNAUTHORIZED
    assert ForbiddenError().status_code == HTTPStatus.FORBIDDEN
    assert NotFoundError().status_code == HTTPStatus.NOT_FOUND
    assert ConflictError().status_code == HTTPStatus.CONFLICT
    assert ValidationError().status_code == HTTPStatus.UNPROCESSABLE_ENTITY
    assert RateLimitError().status_code == HTTPStatus.TOO_MANY_REQUESTS
    assert ServiceUnavailableError().status_code == HTTPStatus.SERVICE_UNAVAILABLE


def test_fastvia_error_handler_returns_clean_response() -> None:
    client = TestClient(create_test_app())

    response = client.get("/not-found", headers={"x-request-id": "req_errors"})

    assert response.status_code == HTTPStatus.NOT_FOUND
    assert response.json() == {
        "error": "not_found",
        "message": "Item not found.",
        "details": {},
        "request_id": "req_errors",
    }


def test_fastvia_error_supports_custom_code_and_details() -> None:
    client = TestClient(create_test_app())

    response = client.get("/custom", headers={"x-request-id": "req_custom"})

    assert response.status_code == HTTPStatus.BAD_REQUEST
    assert response.json() == {
        "error": "invalid_plan",
        "message": "Invalid plan selected.",
        "details": {"allowed": ["free", "pro"]},
        "request_id": "req_custom",
    }


def test_fastvia_error_supports_headers() -> None:
    client = TestClient(create_test_app())

    response = client.get("/headers")

    assert response.status_code == HTTPStatus.TOO_MANY_REQUESTS
    assert response.headers["retry-after"] == "60"


def test_validation_error_handler_returns_clean_response() -> None:
    client = TestClient(create_test_app())

    response = client.post("/items", json={"name": "Book", "quantity": "wrong"})
    body = response.json()

    assert response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY
    assert body["error"] == "validation_error"
    assert body["message"] == "Invalid request data."
    assert body["request_id"]
    assert isinstance(body["details"], list)
