from __future__ import annotations

from pathlib import Path
from unittest.mock import Mock, patch

from alembic.config import Config

from fastvia.migrations import (
    create_alembic_config,
    downgrade_to_base,
    revision,
    upgrade_to_head,
)


def test_create_alembic_config_returns_config() -> None:
    config = create_alembic_config(config_path="alembic.ini")

    assert isinstance(config, Config)


def test_create_alembic_config_sets_database_url() -> None:
    config = create_alembic_config(
        config_path="alembic.ini",
        database_url="postgresql+asyncpg://user:pass@localhost/db",
    )

    assert config.get_main_option("sqlalchemy.url") == (
        "postgresql+asyncpg://user:pass@localhost/db"
    )


def test_create_alembic_config_sets_script_location() -> None:
    config = create_alembic_config(
        config_path=Path("alembic.ini"),
        script_location="migrations",
    )

    assert config.get_main_option("script_location") == "migrations"


def test_upgrade_to_head_calls_alembic_upgrade() -> None:
    config = Mock(spec=Config)

    with patch("fastvia.migrations.alembic.command.upgrade") as upgrade_mock:
        upgrade_to_head(config)

    upgrade_mock.assert_called_once_with(config, "head")


def test_downgrade_to_base_calls_alembic_downgrade() -> None:
    config = Mock(spec=Config)

    with patch("fastvia.migrations.alembic.command.downgrade") as downgrade_mock:
        downgrade_to_base(config)

    downgrade_mock.assert_called_once_with(config, "base")


def test_revision_calls_alembic_revision() -> None:
    config = Mock(spec=Config)

    with patch("fastvia.migrations.alembic.command.revision") as revision_mock:
        revision(
            config,
            message="create users table",
            autogenerate=True,
        )

    revision_mock.assert_called_once_with(
        config,
        message="create users table",
        autogenerate=True,
    )
