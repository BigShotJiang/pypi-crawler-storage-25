# Changelog

## 0.1.2 - 2026-05-10

### Added

- Added dynamic custom logging fields support for values passed through `extra`.
- Added tests for custom logging fields in text and JSON formatters.
- Added database pagination example using async SQLAlchemy and Fastvia pagination helpers.
- Added standalone middleware example.
- Added standalone CORS example.
- Added standalone error handling example.
- Added user-or-IP rate limiting example using JWT bearer token resolution.
- Added Redis example showing cached key/value usage with Fastvia Redis helpers.
- Added ARQ background jobs example using Fastvia job helpers.
- Added JWT auth helper example showing bearer token user ID resolution.
- Added logging example showing request context, event fields, custom extra fields, and exception logging.
- Added Alembic migration script example showing dynamic config usage.
- Added README badges for PyPI version, supported Python versions, license, GitLab pipeline status, and PePy downloads.
- Documented available runnable examples in the README.

### Changed

- Improved logging formatters to include dynamic custom fields passed through `extra`.
- Added safer JSON serialization for custom log fields.
- Removed raw development commands from README and kept Makefile commands as the main workflow.

## 0.1.1 - 2026-05-04

### Added

- Added GitLab CI pipeline for formatting, linting, tests, coverage, build, and package checks.
- Added optional `server` dependency group for installing Uvicorn with Fastvia.

### Changed

- Updated `bootstrap_fastvia` middleware registration order so request context wraps the app flow correctly.
- Refined logging context behavior by keeping request-scoped fields in context and allowing user-specific fields to be passed through `extra`.
- Updated README installation and example instructions for `fastvia-kit[server]`.

## 0.1.0 - 2026-05-03

### Added

- Request context middleware
- Security headers middleware
- Logging context and formatters
- API error handlers
- Pagination helpers
- Redis-backed rate limiting helpers
- Async database helpers
- Redis client helpers
- ARQ helpers
- JWT and FastAPI Users auth helpers
- Alembic migration helpers
- Fastvia bootstrap helper