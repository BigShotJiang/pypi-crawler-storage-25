from __future__ import annotations

from typing import Any

from arq.connections import RedisSettings

from fastvia.jobs import job_deserializer, job_serializer

REDIS_URL = "redis://localhost:6379/0"


async def send_demo_email(ctx: dict[str, Any], email: str, subject: str) -> dict[str, str]:
    print(f"Sending demo email to {email} with subject: {subject}")

    return {
        "email": email,
        "subject": subject,
        "status": "sent",
    }


class WorkerSettings:
    functions = [send_demo_email]
    redis_settings = RedisSettings.from_dsn(REDIS_URL)
    job_serializer = job_serializer
    job_deserializer = job_deserializer
