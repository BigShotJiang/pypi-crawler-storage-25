from __future__ import annotations

from fastapi import FastAPI

from fastvia.middleware import RequestContextMiddleware, SecurityHeadersMiddleware

app = FastAPI(
    title="Fastvia Middleware Example",
    version="1.0.0",
)

app.add_middleware(
    SecurityHeadersMiddleware,
    enable_hsts=False,
    csp_value=None,
)

app.add_middleware(RequestContextMiddleware)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/hello")
async def hello() -> dict[str, str]:
    return {"message": "Hello from Fastvia middleware example"}
