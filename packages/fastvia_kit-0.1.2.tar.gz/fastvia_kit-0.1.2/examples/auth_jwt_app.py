from __future__ import annotations

from fastapi import FastAPI, Request
from jose import jwt

from fastvia.auth import create_jwt_auth_backend, get_user_id_from_bearer_token

SECRET = "demo-secret"
ALGORITHM = "HS256"


app = FastAPI(
    title="Fastvia JWT Auth Helper Example",
    version="1.0.0",
)


auth_backend = create_jwt_auth_backend(
    secret=SECRET,
    lifetime_seconds=3600,
    algorithm=ALGORITHM,
    token_url="/auth/login",
)


@app.get("/auth/backend")
async def auth_backend_info() -> dict[str, str]:
    return {
        "backend_name": auth_backend.name,
        "token_url": "/auth/login",
    }


@app.get("/auth/token")
async def create_demo_token() -> dict[str, str]:
    token = jwt.encode(
        {"sub": "user_123"},
        SECRET,
        algorithm=ALGORITHM,
    )

    return {"access_token": token}


@app.get("/auth/me")
async def read_current_user_id(request: Request) -> dict[str, str | None]:
    user_id = get_user_id_from_bearer_token(
        request,
        secret=SECRET,
        algorithm=ALGORITHM,
    )

    return {"user_id": user_id}
