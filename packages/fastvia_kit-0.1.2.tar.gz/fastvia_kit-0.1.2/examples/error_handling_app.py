from __future__ import annotations

from fastapi import FastAPI

from fastvia.errors import (
    BadRequestError,
    ForbiddenError,
    NotFoundError,
    UnauthorizedError,
    register_exception_handlers,
)
from fastvia.middleware import RequestContextMiddleware

app = FastAPI(
    title="Fastvia Error Handling Example",
    version="1.0.0",
)

app.add_middleware(RequestContextMiddleware)
register_exception_handlers(app)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/errors/bad-request")
async def bad_request() -> None:
    raise BadRequestError(
        "Invalid request data.",
        details={"field": "name"},
    )


@app.get("/errors/unauthorized")
async def unauthorized() -> None:
    raise UnauthorizedError("Authentication required.")


@app.get("/errors/forbidden")
async def forbidden() -> None:
    raise ForbiddenError("You do not have permission to access this resource.")


@app.get("/errors/not-found")
async def not_found() -> None:
    raise NotFoundError("Item not found.")
