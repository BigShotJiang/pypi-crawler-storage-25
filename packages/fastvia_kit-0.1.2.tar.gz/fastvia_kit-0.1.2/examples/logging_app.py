from __future__ import annotations

from fastapi import FastAPI

from fastvia import bootstrap_fastvia
from fastvia.logging import log_extra, setup_logging

app = FastAPI(
    title="Fastvia Logging Example",
    version="1.0.0",
)


bootstrap_fastvia(
    app,
    enable_logging=True,
    log_level="INFO",
    log_format="text",
    logger_name="fastvia_logging_example",
    cors_origins=["http://localhost:3000"],
    rate_limit_storage_uri="memory://",
)


logger = setup_logging(
    level="INFO",
    log_format="json",
    logger_name="app",
)


@app.get("/log/basic")
async def basic_log() -> dict[str, str]:
    logger.info("Basic log message")

    return {"message": "basic log written"}


@app.get("/log/event")
async def event_log() -> dict[str, str]:
    logger.info(
        "Order created",
        extra=log_extra(
            event_id="order_123",
            event_type="order.created",
        ),
    )

    return {"message": "event log written"}


@app.get("/log/custom-extra")
async def custom_extra_log() -> dict[str, str]:
    logger.info(
        "Payment processed",
        extra=log_extra(
            user_id="user_123",
            event_id="payment_123",
            event_type="payment.processed",
            payment_id="pay_123",
            provider="stripe",
            amount=500,
            currency="EUR",
        ),
    )

    return {"message": "custom extra log written"}


@app.get("/log/error")
async def error_log() -> dict[str, str]:
    try:
        raise ValueError("Demo logging error")
    except ValueError:
        logger.exception(
            "Something failed while processing the request",
            extra=log_extra(
                event_id="err_123",
                event_type="demo.error",
                user_id="user_123",
            ),
        )

    return {"message": "error log written"}
