from __future__ import annotations

from fastapi import Depends, FastAPI, Request
from pydantic import BaseModel

from fastvia import bootstrap_fastvia
from fastvia.errors import NotFoundError
from fastvia.pagination import PageMeta, PaginatedResponse, PaginationParams, pagination_params

app = FastAPI(
    title="Fastvia Basic Example",
    version="1.0.0",
)

bootstrap_fastvia(
    app,
    enable_logging=True,
    log_level="INFO",
    log_format="text",
    logger_name="fastvia_example",
    cors_origins=["http://localhost:3000"],
    rate_limit_storage_uri="memory://",
)


PaginationDep = Depends(pagination_params)


class ItemOut(BaseModel):
    id: int
    name: str


ITEMS = [
    ItemOut(id=1, name="First item"),
    ItemOut(id=2, name="Second item"),
    ItemOut(id=3, name="Third item"),
]


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/items", response_model=PaginatedResponse[ItemOut])
async def list_items(
    pagination: PaginationParams = PaginationDep,
) -> PaginatedResponse[ItemOut]:
    start = pagination.offset
    end = start + pagination.per_page

    rows = ITEMS[start:end]

    meta = PageMeta.from_pagination(
        total=len(ITEMS),
        pagination=pagination,
    )

    return PaginatedResponse(
        items=rows,
        meta=meta,
    )


@app.get("/items/{item_id}", response_model=ItemOut)
async def get_item(item_id: int) -> ItemOut:
    for item in ITEMS:
        if item.id == item_id:
            return item

    raise NotFoundError("Item not found.")


@app.get("/limited")
@app.state.limiter.limit("5/minute")
async def limited(request: Request) -> dict[str, str]:
    return {"message": "This endpoint is rate limited."}
