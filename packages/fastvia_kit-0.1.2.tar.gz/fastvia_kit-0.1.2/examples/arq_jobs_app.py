from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager
from typing import Any

from fastapi import FastAPI
from pydantic import BaseModel

from fastvia.jobs import create_arq_pool

REDIS_URL = "redis://localhost:6379/0"


class EmailJobIn(BaseModel):
    email: str
    subject: str


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    app.state.arq_pool = await create_arq_pool(REDIS_URL)

    try:
        yield
    finally:
        await app.state.arq_pool.aclose()


app = FastAPI(
    title="Fastvia ARQ Jobs Example",
    version="1.0.0",
    lifespan=lifespan,
)


@app.post("/jobs/email")
async def enqueue_email_job(payload: EmailJobIn) -> dict[str, Any]:
    job = await app.state.arq_pool.enqueue_job(
        "send_demo_email",
        payload.email,
        payload.subject,
    )

    return {
        "job_id": job.job_id,
        "status": "queued",
    }
