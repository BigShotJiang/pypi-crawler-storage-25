"""
Example Alembic migration script.

Before running this file, your project should already have:

- alembic.ini
- migrations/
- migrations/env.py
- migrations/versions/

Typical setup:

    alembic init migrations
    alembic revision --autogenerate -m "create initial tables"
    python examples/alembic_script.py

Fastvia only helps create the Alembic config dynamically and run commands from Python.
It does not replace Alembic.
"""

from __future__ import annotations

from alembic.config import Config

from fastvia.migrations import create_alembic_config, revision, upgrade_to_head

DATABASE_URL = "sqlite+aiosqlite:///./fastvia_demo.db"


def create_config() -> Config:
    return create_alembic_config(
        config_path="alembic.ini",
        database_url=DATABASE_URL,
        script_location="migrations",
    )


def run_upgrade() -> None:
    config = create_config()
    upgrade_to_head(config)


def create_revision() -> None:
    config = create_config()

    revision(
        config,
        message="create initial tables",
        autogenerate=True,
    )


if __name__ == "__main__":
    run_upgrade()
