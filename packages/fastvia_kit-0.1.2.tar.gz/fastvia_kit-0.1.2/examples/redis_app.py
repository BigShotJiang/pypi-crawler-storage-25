from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import FastAPI

from fastvia.redis import close_all_redis, get_redis

REDIS_URL = "redis://localhost:6379/0"


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    try:
        yield
    finally:
        await close_all_redis()


app = FastAPI(
    title="Fastvia Redis Example",
    version="1.0.0",
    lifespan=lifespan,
)


@app.get("/redis/ping")
async def redis_ping() -> dict[str, str]:
    redis = get_redis(REDIS_URL)
    pong = await redis.ping()

    return {"pong": str(pong)}


@app.post("/redis/cache/{key}")
async def set_cache_value(key: str, value: str) -> dict[str, str]:
    redis = get_redis(REDIS_URL)

    await redis.set(key, value, ex=60)

    return {
        "key": key,
        "value": value,
        "ttl": "60 seconds",
    }


@app.get("/redis/cache/{key}")
async def get_cache_value(key: str) -> dict[str, str | None]:
    redis = get_redis(REDIS_URL)

    value = await redis.get(key)

    return {
        "key": key,
        "value": value,
    }
