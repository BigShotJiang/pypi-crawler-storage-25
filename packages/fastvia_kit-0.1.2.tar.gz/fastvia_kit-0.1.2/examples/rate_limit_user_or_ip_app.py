from __future__ import annotations

from fastapi import FastAPI, Request
from jose import jwt

from fastvia import bootstrap_fastvia
from fastvia.auth import get_user_id_from_bearer_token
from fastvia.rate_limit import user_or_ip_key

SECRET = "demo-secret"
ALGORITHM = "HS256"


def resolve_user_id(request: Request) -> str | None:
    return get_user_id_from_bearer_token(
        request,
        secret=SECRET,
        algorithm=ALGORITHM,
    )


app = FastAPI(
    title="Fastvia User or IP Rate Limit Example",
    version="1.0.0",
)


bootstrap_fastvia(
    app,
    enable_logging=True,
    log_level="INFO",
    log_format="text",
    logger_name="fastvia_rate_limit_example",
    cors_origins=["http://localhost:3000"],
    rate_limit_storage_uri="memory://",
    rate_limit_key_func=user_or_ip_key(
        user_id_resolver=resolve_user_id,
    ),
)


@app.get("/token")
async def create_demo_token() -> dict[str, str]:
    token = jwt.encode(
        {"sub": "user_123"},
        SECRET,
        algorithm=ALGORITHM,
    )

    return {"access_token": token}


@app.get("/limited")
@app.state.limiter.limit("3/minute")
async def limited(request: Request) -> dict[str, str]:
    return {
        "message": "This route is rate limited by user ID if authenticated, otherwise by IP.",
    }


@app.get("/whoami")
async def whoami(request: Request) -> dict[str, str | None]:
    user_id = resolve_user_id(request)

    return {"user_id": user_id}
