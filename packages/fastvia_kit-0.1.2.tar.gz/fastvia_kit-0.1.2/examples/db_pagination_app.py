from __future__ import annotations

from collections.abc import AsyncIterator
from contextlib import asynccontextmanager

from fastapi import Depends, FastAPI
from pydantic import BaseModel
from sqlalchemy import String, func, select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column

from fastvia.db import create_async_db_engine, create_session_dependency, create_session_factory
from fastvia.pagination import PageMeta, PaginatedResponse, PaginationParams, pagination_params

engine = create_async_db_engine("sqlite+aiosqlite:///./fastvia_demo.db")
SessionLocal = create_session_factory(engine)
get_db = create_session_dependency(SessionLocal)

DbDep = Depends(get_db)
PaginationDep = Depends(pagination_params)


class Base(DeclarativeBase):
    pass


class Product(Base):
    __tablename__ = "products"

    id: Mapped[int] = mapped_column(primary_key=True, index=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    price: Mapped[int] = mapped_column(nullable=False)


class ProductOut(BaseModel):
    id: int
    name: str
    price: int

    model_config = {"from_attributes": True}


async def seed_products() -> None:
    async with SessionLocal() as db:
        total = await db.scalar(select(func.count()).select_from(Product))

        if total:
            return

        db.add_all(
            [
                Product(name="Keyboard", price=45),
                Product(name="Mouse", price=25),
                Product(name="Monitor", price=180),
                Product(name="Laptop Stand", price=35),
                Product(name="USB-C Hub", price=50),
                Product(name="Webcam", price=75),
                Product(name="Desk Lamp", price=30),
                Product(name="Notebook", price=12),
            ]
        )
        await db.commit()


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncIterator[None]:
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    await seed_products()

    try:
        yield
    finally:
        await engine.dispose()


app = FastAPI(
    title="Fastvia DB Pagination Example",
    version="1.0.0",
    lifespan=lifespan,
)


@app.get("/products", response_model=PaginatedResponse[ProductOut])
async def list_products(
    pagination: PaginationParams = PaginationDep,
    db: AsyncSession = DbDep,
) -> PaginatedResponse[ProductOut]:
    total = await db.scalar(select(func.count()).select_from(Product)) or 0

    statement = (
        select(Product)
        .order_by(Product.id.desc())
        .offset(pagination.offset)
        .limit(pagination.per_page)
    )

    result = await db.execute(statement)
    products = result.scalars().all()

    return PaginatedResponse(
        items=[ProductOut.model_validate(product) for product in products],
        meta=PageMeta.from_pagination(
            total=total,
            pagination=pagination,
        ),
    )
