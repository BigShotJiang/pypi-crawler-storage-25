# Contributing to Fastvia

Thank you for your interest in contributing to Fastvia.

Fastvia is a FastAPI backend toolkit focused on reusable production-style helpers for middleware, logging, errors, pagination, rate limiting, Redis, ARQ, database setup, auth, and migrations.

## Development Setup

Clone the repository:

```bash
git clone https://gitlab.com/abdulfatahbabakrkhail/fastvia.git
cd fastvia
```

Create and activate a virtual environment:

```bash
python3 -m venv env
source env/bin/activate
```

Install development dependencies:

```bash
make install-dev
```

## Common Commands

Format code:

```bash
make format
```

Run lint checks:

```bash
make lint
```

Run tests:

```bash
make test
```

Run tests with coverage:

```bash
make test-cov
```

Clean build and cache files:

```bash
make clean
```

Build the package:

```bash
make build
```

Check the package:

```bash
make check
```

## Contribution Guidelines

- Keep changes focused and small.
- Add or update tests when changing behavior.
- Keep examples simple and runnable.
- Do not add unnecessary dependencies.
- Do not include secrets, tokens, passwords, private database URLs, or private API keys.
- Keep Fastvia generic. App-specific logic should stay outside the package.
- Prefer clear public APIs over hidden magic.
- Keep migrations explicit. Fastvia should not run database migrations automatically on app startup.

## Examples

If you add or update an example, make sure it is easy to run and clearly shows one idea.

Current examples include:

```text
examples/basic_app.py
examples/middleware_app.py
examples/cors_app.py
examples/error_handling_app.py
examples/db_pagination_app.py
examples/rate_limit_user_or_ip_app.py
examples/redis_app.py
examples/arq_jobs_app.py
examples/arq_worker.py
examples/auth_jwt_app.py
examples/logging_app.py
examples/alembic_script.py
```

When an example needs an external service like Redis, mention it clearly in the README or comments.

## Branch Flow

`main` contains the latest stable release.

`dev` is used for active development.

External contributors should create a fork or a feature branch and open a merge request targeting `dev`.

Maintainers review merge requests and merge them into `dev`. After changes are tested and ready for release, `dev` is merged into `main` and a release tag is created.

Typical flow:

```text
feature branch or fork -> merge request -> dev -> main -> release tag
```

## Commit Style

Use clear commit messages, for example:

```text
feat: support dynamic logging extra fields
docs: add Redis example
fix: correct middleware order
test: add logging formatter tests
chore: prepare 0.1.2 release
```

## Merge Requests

Before opening a merge request, run:

```bash
make format
make lint
make test-cov
make clean
make build
make check
```

The GitLab CI pipeline should pass before merging.

## Release Notes

Update `CHANGELOG.md` when adding user-facing changes, examples, docs, or behavior changes.

Use sections like:

```md
### Added

### Changed

### Fixed
```

## Security

Please do not report security issues in public issues.

If you find a security problem, report it privately by email:

```text
fatahbabakrkhail@gmail.com
```

## License

By contributing to Fastvia, you agree that your contribution will be licensed under the MIT License.