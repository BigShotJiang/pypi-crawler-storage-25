"""Claude (Anthropic) translator backend."""

import logging

from mobile_ai_translator.services.translators.base import BaseTranslator

logger = logging.getLogger("mobile_ai_translator")


class ClaudeTranslator(BaseTranslator):
    name = "Claude (Anthropic)"

    def validate_key(self) -> bool:
        try:
            import anthropic

            client = anthropic.Anthropic(api_key=self.api_key)
            resp = client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=10,
                messages=[{"role": "user", "content": "Reply with: ok"}],
            )
            return bool(resp.content)
        except Exception:
            return False

    def _call_api(self, prompt: str) -> str | None:
        try:
            import anthropic

            client = anthropic.Anthropic(api_key=self.api_key)
            resp = client.messages.create(
                model="claude-sonnet-4-20250514",
                max_tokens=8192,
                messages=[{"role": "user", "content": prompt}],
            )
            return resp.content[0].text
        except Exception as exc:
            logger.error("Claude API error: %s", exc)
            return None
