"""
.env file manager — auto-creates, scaffolds, loads, and writes API keys.

Auto-detects .env location from the project directory (no Django dependency).
"""

import functools
import os
from pathlib import Path

from dotenv import dotenv_values, set_key

from mobile_ai_translator.services.translators import ALL_ENV_KEYS


@functools.lru_cache(maxsize=1)
def _env_path() -> Path:
    """Find the developer's .env file anywhere in the project.

    Walks the entire project tree looking for an existing .env.
    If found, uses it. If not found, defaults to cwd/.env for creation.
    """
    base = Path(os.getcwd())

    # Walk the project to find any existing .env
    for root, dirs, files in os.walk(base):
        # Skip irrelevant directories
        dirs[:] = [d for d in dirs if d not in {
            "venv", ".venv", "env", ".env_dir", "node_modules",
            "__pycache__", ".git", ".tox", "htmlcov", "static",
            "media", "locale", "migrations", "assets",
            "build", ".dart_tool", ".gradle",
        }]
        if ".env" in files:
            return Path(root) / ".env"

    # No .env found anywhere — default to project root
    return base / ".env"


def ensure_env_exists() -> Path:
    """Ensure .env exists. Only scaffold missing API key placeholders.

    - If .env already exists, appends only keys that are completely absent.
    - If .env is new, creates it at project root with all key placeholders.
    - Never duplicates or overwrites existing keys.
    """
    env_file = _env_path()

    if not env_file.exists():
        env_file.parent.mkdir(parents=True, exist_ok=True)
        env_file.touch()

    raw_text = env_file.read_text()
    existing = dotenv_values(str(env_file))

    # Only add keys that are completely absent (not in file at all)
    missing = [
        (key, desc)
        for key, desc in ALL_ENV_KEYS.items()
        if key not in existing and key not in raw_text
    ]

    if missing:
        with open(env_file, "a") as f:
            if not any(k in raw_text for k in ALL_ENV_KEYS):
                f.write("\n# ── Mobile AI Translator API Keys ──\n")
            for key, desc in missing:
                f.write(f"# {desc}\n")
                f.write(f"{key}=\n")

    return env_file


def get_env_status() -> dict[str, str | None]:
    """Return {env_var: value_or_None} for all translation provider keys."""
    env_file = _env_path()
    file_values = dotenv_values(str(env_file)) if env_file.exists() else {}

    status = {}
    for key in ALL_ENV_KEYS:
        val = file_values.get(key, "").strip()
        if not val:
            val = os.environ.get(key, "").strip()
        status[key] = val if val else None
    return status


def load_key(env_var: str) -> str | None:
    """Read a key from .env (or os.environ fallback)."""
    env_file = _env_path()
    if env_file.exists():
        values = dotenv_values(str(env_file))
        val = values.get(env_var, "").strip()
        if val:
            return val
    val = os.environ.get(env_var, "").strip()
    return val if val else None


def save_key(env_var: str, value: str):
    """Write/update a key in the developer's .env file."""
    env_file = _env_path()
    if not env_file.exists():
        env_file.parent.mkdir(parents=True, exist_ok=True)
        env_file.touch()
    set_key(str(env_file), env_var, value)
