"""
CLI entry point for mobile-ai-translator.

Usage:
    mobile-ai-translate                          # Auto-detect + interactive
    mobile-ai-translate --platform flutter       # Explicit platform
    mobile-ai-translate --provider claude        # Explicit provider
    mobile-ai-translate --dry-run                # Preview mode
"""

import argparse
import logging
import sys
import time
from pathlib import Path

from mobile_ai_translator import __version__
from mobile_ai_translator.cli import ui
from mobile_ai_translator.platforms import detect_platform, get_platform_handler
from mobile_ai_translator.services import env_manager
from mobile_ai_translator.services.translators import (
    ALL_ENV_KEYS,
    OPENROUTER_MODELS,
    PROVIDER_ENV_KEYS,
    get_translator,
)

logger = logging.getLogger("mobile_ai_translator")


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="mobile-ai-translate",
        description="AI-powered translation for Flutter, Android & iOS",
    )
    parser.add_argument(
        "--version", action="version", version=f"mobile-ai-translator {__version__}"
    )
    parser.add_argument(
        "--platform",
        choices=["flutter", "android", "ios"],
        help="Mobile platform (auto-detected if omitted)",
    )
    parser.add_argument(
        "--provider",
        choices=["claude", "openai", "openrouter", "gemini", "mistral", "skip"],
        help="AI translation provider",
    )
    parser.add_argument(
        "--model",
        help="Model ID for OpenRouter (e.g. deepseek/deepseek-chat-v3-0324)",
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Preview translations without writing files",
    )
    parser.add_argument(
        "--no-input",
        action="store_true",
        help="Non-interactive mode (CI/CD)",
    )
    parser.add_argument(
        "--batch-size",
        type=int,
        default=10,
        help="Number of strings per AI request (default: 10)",
    )
    parser.add_argument(
        "--debug",
        action="store_true",
        help="Enable verbose debug logging",
    )
    parser.add_argument(
        "--project-dir",
        type=str,
        default=".",
        help="Project root directory (default: current directory)",
    )
    return parser


def main():
    parser = build_parser()
    args = parser.parse_args()

    # ── Logging ──────────────────────────────────────────────────────
    if args.debug:
        logging.basicConfig(level=logging.DEBUG, format="%(name)s %(levelname)s: %(message)s")
    else:
        logging.basicConfig(level=logging.WARNING)

    project_root = Path(args.project_dir).resolve()

    if args.batch_size < 1:
        ui.show_error("--batch-size must be at least 1.")
        sys.exit(1)

    # ── Step 1: Boot sequence ────────────────────────────────────────
    ui.show_boot_sequence()

    # ── Step 2: Detect platform ──────────────────────────────────────
    ui.show_step(1, "PLATFORM DETECTION")

    platform = args.platform or detect_platform(project_root)
    if not platform:
        ui.show_error(
            "Could not auto-detect mobile platform.\n"
            "    Use --platform flutter|android|ios to specify manually."
        )
        sys.exit(1)

    handler = get_platform_handler(platform)

    # ── Step 3: Show API key status ──────────────────────────────────
    env_manager.ensure_env_exists()
    key_status = env_manager.get_env_status()
    ui.show_env_key_status(key_status, ALL_ENV_KEYS)

    # ── Step 4: Scan source strings ──────────────────────────────────
    ui.show_step(2, "SCANNING SOURCE STRINGS")

    source_strings = handler.scan_source(project_root)
    if not source_strings:
        ui.show_error("No source strings found. Check your project structure.")
        sys.exit(1)

    ui.show_success(f"Found {len(source_strings)} source strings")

    # ── Step 5: Detect target languages ──────────────────────────────
    target_languages = handler.detect_target_languages(project_root)
    if not target_languages:
        if args.no_input:
            ui.show_error("No target languages found and --no-input mode is active.")
            sys.exit(1)
        ui.show_warning("No target languages detected. Let's set them up.")
        target_languages = ui.prompt_target_languages()

    # Show project info
    ui.show_platform_detected(
        platform=platform,
        project_path=str(project_root),
        source_locale="en",
        lang_count=len(target_languages),
    )
    ui.show_languages(target_languages)

    # ── Step 6: Find missing translations ────────────────────────────
    ui.show_step(3, "DETECTING MISSING TRANSLATIONS")

    missing = handler.get_missing_translations(project_root, source_strings, target_languages)
    total_missing = sum(len(keys) for keys in missing.values())

    if total_missing == 0:
        ui.show_success("All translations are up to date!")
        ui.show_final_report(
            platform=platform,
            source_strings=len(source_strings),
            missing_count=0,
            translated=0,
            languages=len(target_languages),
            elapsed=0.0,
            provider="N/A",
            success=True,
            project_path=str(project_root),
        )
        return

    ui.show_scan_results(
        source_strings=len(source_strings),
        missing_count=total_missing,
        languages=len(target_languages),
    )

    # ── Step 7: Select provider ──────────────────────────────────────
    ui.show_step(4, "SELECT TRANSLATION ENGINE")

    provider_key = ui.show_model_selection(
        no_input=args.no_input,
        provider=args.provider,
    )

    if provider_key == "skip":
        ui.show_warning("Translation skipped.")
        return

    # OpenRouter model selection
    model_id = ""
    if provider_key == "openrouter":
        model_id = ui.show_openrouter_model_selection(
            OPENROUTER_MODELS,
            no_input=args.no_input,
            model_flag=args.model,
        )

    # ── Step 8: API key verification ─────────────────────────────────
    ui.show_step(5, "API KEY VERIFICATION")

    env_var = PROVIDER_ENV_KEYS[provider_key]
    api_key = env_manager.load_key(env_var)

    if not api_key:
        if args.no_input:
            ui.show_error(f"{env_var} not set. Cannot proceed in --no-input mode.")
            sys.exit(1)
        api_key = ui.prompt_api_key(provider_key, env_var)
        env_manager.save_key(env_var, api_key)

    translator = get_translator(provider_key, api_key=api_key, model_id=model_id)

    ui.show_info(f"Validating {translator.name} API key...")
    if not translator.validate_key():
        ui.show_auth_failure(translator.name)
        sys.exit(1)
    ui.show_success(f"{translator.name} API key verified!")

    # ── Step 9: Dry run check ────────────────────────────────────────
    if args.dry_run:
        ui.show_dry_run_banner()
        all_missing_values = []
        for lang_keys in missing.values():
            for key in lang_keys:
                val = source_strings.get(key, key)
                if val not in all_missing_values:
                    all_missing_values.append(val)
        ui.show_dry_run_messages(all_missing_values, len(target_languages))
        return

    # ── Step 10: Translate ───────────────────────────────────────────
    ui.show_step(6, "TRANSLATING")

    start_time = time.time()

    # Collect unique missing source values
    missing_values_set: dict[str, str] = {}  # source_value -> key
    for lang_keys in missing.values():
        for key in lang_keys:
            val = source_strings.get(key, "")
            if val and val not in missing_values_set:
                missing_values_set[val] = key

    missing_values = list(missing_values_set.keys())

    # Translate in batches
    all_translations: dict[str, dict[str, str]] = {}
    batch_size = args.batch_size

    progress = ui.create_translation_progress()
    with progress:
        task = progress.add_task("Translating...", total=len(missing_values))

        for i in range(0, len(missing_values), batch_size):
            batch = missing_values[i : i + batch_size]
            result = translator.translate_batch(
                batch, target_languages, platform=platform
            )
            if result:
                all_translations.update(result)
            progress.advance(task, len(batch))

    # ── Step 11: Write translations ──────────────────────────────────
    ui.show_step(7, "WRITING TRANSLATIONS")

    stats = handler.write_translations(project_root, all_translations, source_strings)
    ui.show_translation_results(stats)

    elapsed = time.time() - start_time
    total_translated = len(all_translations)

    # ── Step 12: Final report ────────────────────────────────────────
    ui.show_final_report(
        platform=platform,
        source_strings=len(source_strings),
        missing_count=total_missing,
        translated=total_translated,
        languages=len(target_languages),
        elapsed=elapsed,
        provider=translator.name,
        success=total_translated > 0,
        project_path=str(project_root),
    )


if __name__ == "__main__":
    main()
