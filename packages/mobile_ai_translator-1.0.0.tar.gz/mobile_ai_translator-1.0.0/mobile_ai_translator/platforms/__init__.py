"""
Platform detection and registry for mobile projects.

Supports: Flutter (.arb), Android (strings.xml), iOS (.strings / .xcstrings)
"""

from pathlib import Path


def detect_platform(project_root: Path) -> str | None:
    """Auto-detect mobile platform from project structure."""

    # Flutter: pubspec.yaml at root
    if (project_root / "pubspec.yaml").exists():
        return "flutter"

    # Android: app/build.gradle or build.gradle with android plugin
    if (project_root / "app" / "build.gradle").exists():
        return "android"
    if (project_root / "app" / "build.gradle.kts").exists():
        return "android"

    # iOS: .xcodeproj or .xcworkspace at root
    try:
        for item in project_root.iterdir():
            if item.suffix in (".xcodeproj", ".xcworkspace"):
                return "ios"
    except (PermissionError, OSError):
        pass

    return None


def get_platform_handler(platform: str):
    """Return the platform handler module."""
    if platform == "flutter":
        from mobile_ai_translator.platforms import flutter
        return flutter
    elif platform == "android":
        from mobile_ai_translator.platforms import android
        return android
    elif platform == "ios":
        from mobile_ai_translator.platforms import ios
        return ios
    else:
        raise ValueError(f"Unsupported platform: {platform}")
