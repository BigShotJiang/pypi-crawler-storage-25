"""
Flutter ARB parser — reads/writes .arb localization files.

ARB files are JSON with special keys:
  - @@locale: locale identifier
  - @key: metadata for a translation key (description, placeholders)
  - Regular keys: translatable strings
"""

import json
import logging
from pathlib import Path

import yaml

logger = logging.getLogger("mobile_ai_translator")


def get_config(project_root: Path) -> dict:
    """Read l10n.yaml or return defaults."""
    l10n_file = project_root / "l10n.yaml"
    if l10n_file.exists():
        with open(l10n_file) as f:
            config = yaml.safe_load(f) or {}
        return {
            "arb_dir": config.get("arb-dir", "lib/l10n"),
            "template_arb": config.get("template-arb-file", "app_en.arb"),
        }
    return {
        "arb_dir": "lib/l10n",
        "template_arb": "app_en.arb",
    }


def scan_source(project_root: Path) -> dict[str, str]:
    """Read source ARB file and return {key: value} for translatable strings."""
    config = get_config(project_root)
    arb_dir = project_root / config["arb_dir"]
    template_file = arb_dir / config["template_arb"]

    if not template_file.exists():
        logger.error("Template ARB not found: %s", template_file)
        return {}

    with open(template_file, encoding="utf-8") as f:
        data = json.load(f)

    # Extract translatable keys (skip @@locale and @key metadata)
    strings = {}
    for key, value in data.items():
        if key.startswith("@@") or key.startswith("@"):
            continue
        if isinstance(value, str):
            strings[key] = value

    return strings


def detect_target_languages(project_root: Path) -> dict[str, str]:
    """Scan arb-dir for existing app_{lang}.arb files and return {code: name}."""
    config = get_config(project_root)
    arb_dir = project_root / config["arb_dir"]

    if not arb_dir.exists():
        return {}

    # Language name lookup
    from mobile_ai_translator.cli.ui import COMMON_LANGUAGES

    languages = {}
    template_name = config["template_arb"]

    for arb_file in sorted(arb_dir.glob("*.arb")):
        if arb_file.name == template_name:
            continue
        # Extract lang code from filename like app_es.arb
        stem = arb_file.stem  # e.g. "app_es"
        parts = stem.rsplit("_", 1)
        if len(parts) == 2:
            lang_code = parts[1]
            if lang_code != "en":
                languages[lang_code] = COMMON_LANGUAGES.get(lang_code, lang_code.upper())

    return languages


def get_missing_translations(
    project_root: Path, source_strings: dict[str, str], target_languages: dict[str, str]
) -> dict[str, list[str]]:
    """Return {lang_code: [missing_keys]} for each target language."""
    config = get_config(project_root)
    arb_dir = project_root / config["arb_dir"]
    template_name = config["template_arb"]
    prefix = template_name.rsplit("_", 1)[0]  # e.g. "app"

    missing = {}
    for lang_code in target_languages:
        target_file = arb_dir / f"{prefix}_{lang_code}.arb"
        if target_file.exists():
            with open(target_file, encoding="utf-8") as f:
                existing = json.load(f)
            missing_keys = [k for k in source_strings if k not in existing]
        else:
            missing_keys = list(source_strings.keys())
        if missing_keys:
            missing[lang_code] = missing_keys

    return missing


def write_translations(
    project_root: Path,
    translations: dict[str, dict[str, str]],
    source_strings: dict[str, str],
) -> dict[str, int]:
    """Write translations to ARB files. Returns {lang_code: count_written}."""
    config = get_config(project_root)
    arb_dir = project_root / config["arb_dir"]
    template_name = config["template_arb"]
    prefix = template_name.rsplit("_", 1)[0]

    arb_dir.mkdir(parents=True, exist_ok=True)

    # Read source ARB for metadata
    template_file = arb_dir / template_name
    source_data = {}
    if template_file.exists():
        with open(template_file, encoding="utf-8") as f:
            source_data = json.load(f)

    # Reorganize: translations is {source_msg: {lang: translated}}
    # We need: {lang: {key: translated}}
    lang_translations: dict[str, dict[str, str]] = {}
    for key, value in source_strings.items():
        if value in translations:
            for lang_code, translated_text in translations[value].items():
                lang_translations.setdefault(lang_code, {})[key] = translated_text

    stats = {}
    for lang_code, entries in lang_translations.items():
        target_file = arb_dir / f"{prefix}_{lang_code}.arb"

        # Load existing data or start fresh
        if target_file.exists():
            with open(target_file, encoding="utf-8") as f:
                data = json.load(f)
        else:
            data = {"@@locale": lang_code}

        # Add translations
        count = 0
        for key, value in entries.items():
            if key not in data:
                data[key] = value
                # Copy metadata if it exists in source
                meta_key = f"@{key}"
                if meta_key in source_data:
                    data[meta_key] = source_data[meta_key]
                count += 1

        # Write back
        with open(target_file, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write("\n")

        stats[lang_code] = count

    return stats
