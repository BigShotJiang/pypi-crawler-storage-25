"""
iOS .strings / .xcstrings parser — reads/writes localization files.

Supports:
  - Classic .strings files (key-value pairs in *.lproj/ directories)
  - Modern .xcstrings files (Xcode 15+, single JSON file)
"""

import json
import logging
import re
from pathlib import Path

logger = logging.getLogger("mobile_ai_translator")


# ── .strings parser ──────────────────────────────────────────────────

# Regex for "key" = "value"; pairs (handles escaped quotes)
_STRINGS_PATTERN = re.compile(
    r'"((?:[^"\\]|\\.)*)"\s*=\s*"((?:[^"\\]|\\.)*)"\s*;'
)

def _parse_strings_file(path: Path) -> dict[str, str]:
    """Parse a .strings file into {key: value}."""
    if not path.exists():
        return {}

    content = path.read_text(encoding="utf-8")
    return dict(_STRINGS_PATTERN.findall(content))


def _write_strings_file(path: Path, entries: dict[str, str]):
    """Write entries as a .strings file.

    Values from _parse_strings_file already contain escape sequences
    as they appear in the file (e.g. \\", \\n). New values from the AI
    may contain literal quotes that need escaping. We write values as-is
    since the regex captures the raw escaped content, and new AI values
    should not contain unescaped quotes (the prompt instructs to preserve
    escape sequences).
    """
    path.parent.mkdir(parents=True, exist_ok=True)
    lines = []
    for key, value in entries.items():
        lines.append(f'"{key}" = "{value}";')
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")


# ── .xcstrings parser ────────────────────────────────────────────────


def _parse_xcstrings_file(path: Path) -> dict:
    """Parse an .xcstrings JSON file."""
    if not path.exists():
        return {}

    with open(path, encoding="utf-8") as f:
        return json.load(f)


# ── Detect format ────────────────────────────────────────────────────


def _detect_format(project_root: Path) -> tuple[str, Path | None]:
    """Detect iOS localization format: 'xcstrings' or 'strings'.

    Returns (format, path_to_main_file_or_dir).
    """
    # Check for .xcstrings first (modern)
    for xcstrings in project_root.rglob("*.xcstrings"):
        return "xcstrings", xcstrings

    # Check for .lproj directories
    for lproj in project_root.rglob("*.lproj"):
        strings_file = lproj / "Localizable.strings"
        if strings_file.exists():
            return "strings", lproj.parent
        # Check for any .strings file
        for sf in lproj.glob("*.strings"):
            return "strings", lproj.parent

    return "unknown", None


def _find_source_lproj(base_dir: Path) -> Path | None:
    """Find the source language .lproj directory (en.lproj or Base.lproj)."""
    for name in ("en.lproj", "Base.lproj"):
        candidate = base_dir / name
        if candidate.exists():
            return candidate
    return None


def scan_source(project_root: Path) -> dict[str, str]:
    """Read source localization and return {key: value}."""
    fmt, path = _detect_format(project_root)

    if fmt == "xcstrings" and path:
        data = _parse_xcstrings_file(path)
        source_lang = data.get("sourceLanguage", "en")
        strings_data = data.get("strings", {})
        result = {}
        for key, entry in strings_data.items():
            localizations = entry.get("localizations", {})
            if source_lang in localizations:
                unit = localizations[source_lang].get("stringUnit", {})
                value = unit.get("value", "")
                if value:
                    result[key] = value
            else:
                # Key itself may be the English value
                result[key] = key
        return result

    elif fmt == "strings" and path:
        source_lproj = _find_source_lproj(path)
        if not source_lproj:
            logger.error("No en.lproj or Base.lproj found in %s", path)
            return {}

        strings_file = source_lproj / "Localizable.strings"
        return _parse_strings_file(strings_file)

    logger.error("No iOS localization files found in %s", project_root)
    return {}


def detect_target_languages(project_root: Path) -> dict[str, str]:
    """Detect target languages from project structure."""
    fmt, path = _detect_format(project_root)

    from mobile_ai_translator.cli.ui import COMMON_LANGUAGES

    if fmt == "xcstrings" and path:
        data = _parse_xcstrings_file(path)
        source_lang = data.get("sourceLanguage", "en")
        strings_data = data.get("strings", {})

        # Collect all language codes from existing translations
        all_langs = set()
        for entry in strings_data.values():
            localizations = entry.get("localizations", {})
            all_langs.update(localizations.keys())
        all_langs.discard(source_lang)

        return {
            code: COMMON_LANGUAGES.get(code, code.upper())
            for code in sorted(all_langs)
        }

    elif fmt == "strings" and path:
        languages = {}
        for lproj in sorted(path.glob("*.lproj")):
            lang_code = lproj.stem
            if lang_code in ("en", "Base"):
                continue
            languages[lang_code] = COMMON_LANGUAGES.get(lang_code, lang_code.upper())
        return languages

    return {}


def get_missing_translations(
    project_root: Path, source_strings: dict[str, str], target_languages: dict[str, str]
) -> dict[str, list[str]]:
    """Return {lang_code: [missing_keys]} for each target language."""
    fmt, path = _detect_format(project_root)

    missing = {}

    if fmt == "xcstrings" and path:
        data = _parse_xcstrings_file(path)
        strings_data = data.get("strings", {})

        for lang_code in target_languages:
            missing_keys = []
            for key in source_strings:
                entry = strings_data.get(key, {})
                localizations = entry.get("localizations", {})
                if lang_code not in localizations:
                    missing_keys.append(key)
                else:
                    unit = localizations[lang_code].get("stringUnit", {})
                    if not unit.get("value", "").strip():
                        missing_keys.append(key)
            if missing_keys:
                missing[lang_code] = missing_keys

    elif fmt == "strings" and path:
        for lang_code in target_languages:
            target_file = path / f"{lang_code}.lproj" / "Localizable.strings"
            if target_file.exists():
                existing = _parse_strings_file(target_file)
                missing_keys = [k for k in source_strings if k not in existing]
            else:
                missing_keys = list(source_strings.keys())
            if missing_keys:
                missing[lang_code] = missing_keys

    return missing


def write_translations(
    project_root: Path,
    translations: dict[str, dict[str, str]],
    source_strings: dict[str, str],
) -> dict[str, int]:
    """Write translations to iOS localization files. Returns {lang_code: count}."""
    fmt, path = _detect_format(project_root)

    # Reorganize: translations is {source_value: {lang: translated}}
    # We need: {lang: {key: translated_value}}
    lang_translations: dict[str, dict[str, str]] = {}
    for key, source_value in source_strings.items():
        if source_value in translations:
            for lang_code, translated_text in translations[source_value].items():
                lang_translations.setdefault(lang_code, {})[key] = translated_text

    stats = {}

    if fmt == "xcstrings" and path:
        data = _parse_xcstrings_file(path)
        strings_data = data.setdefault("strings", {})

        for lang_code, entries in lang_translations.items():
            count = 0
            for key, value in entries.items():
                if key not in strings_data:
                    strings_data[key] = {"localizations": {}}
                localizations = strings_data[key].setdefault("localizations", {})
                if lang_code not in localizations or not localizations[lang_code].get("stringUnit", {}).get("value"):
                    localizations[lang_code] = {
                        "stringUnit": {
                            "state": "translated",
                            "value": value,
                        }
                    }
                    count += 1
            stats[lang_code] = count

        # Write back
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
            f.write("\n")

    elif fmt == "strings" and path:
        for lang_code, entries in lang_translations.items():
            target_file = path / f"{lang_code}.lproj" / "Localizable.strings"

            # Load existing
            existing = _parse_strings_file(target_file) if target_file.exists() else {}

            count = 0
            for key, value in entries.items():
                if key not in existing:
                    existing[key] = value
                    count += 1

            _write_strings_file(target_file, existing)
            stats[lang_code] = count

    return stats
