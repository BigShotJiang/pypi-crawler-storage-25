"""
Android strings.xml parser — reads/writes XML localization files.

Handles:
  - <string name="...">...</string>
  - <string-array name="..."><item>...</item>...</string-array>
  - <plurals name="..."><item quantity="...">...</item>...</plurals>
  - translatable="false" skipping
"""

import logging
import xml.etree.ElementTree as ET
from pathlib import Path

logger = logging.getLogger("mobile_ai_translator")

# Default Android res path
RES_PATH = "app/src/main/res"


def _get_res_dir(project_root: Path) -> Path:
    """Find the Android res directory."""
    return project_root / RES_PATH


def _get_element_text(element: ET.Element) -> str:
    """Get full text content of an element including tail text of children."""
    return "".join(element.itertext())


def scan_source(project_root: Path) -> dict[str, str]:
    """Read values/strings.xml and return {name: value} for translatable strings."""
    res_dir = _get_res_dir(project_root)
    source_file = res_dir / "values" / "strings.xml"

    if not source_file.exists():
        logger.error("Source strings.xml not found: %s", source_file)
        return {}

    tree = ET.parse(source_file)
    root = tree.getroot()

    strings = {}
    for elem in root:
        if elem.tag == "string":
            if elem.get("translatable") == "false":
                continue
            name = elem.get("name", "")
            text = _get_element_text(elem).strip()
            if name and text:
                strings[name] = text

        elif elem.tag == "string-array":
            name = elem.get("name", "")
            items = [item.text or "" for item in elem.findall("item")]
            if name and items:
                # Encode as JSON array for translation
                strings[f"__array__{name}"] = "|||".join(items)

        elif elem.tag == "plurals":
            name = elem.get("name", "")
            for item in elem.findall("item"):
                quantity = item.get("quantity", "")
                text = item.text or ""
                if quantity and text:
                    strings[f"__plural__{name}__{quantity}"] = text

    return strings


def detect_target_languages(project_root: Path) -> dict[str, str]:
    """Scan res/ for values-{lang}/ directories."""
    res_dir = _get_res_dir(project_root)
    if not res_dir.exists():
        return {}

    from mobile_ai_translator.cli.ui import COMMON_LANGUAGES

    languages = {}
    for d in sorted(res_dir.iterdir()):
        if d.is_dir() and d.name.startswith("values-"):
            lang_code = d.name.split("-", 1)[1]
            if lang_code and lang_code != "en":
                languages[lang_code] = COMMON_LANGUAGES.get(lang_code, lang_code.upper())

    return languages


def get_missing_translations(
    project_root: Path, source_strings: dict[str, str], target_languages: dict[str, str]
) -> dict[str, list[str]]:
    """Return {lang_code: [missing_keys]} for each target language."""
    res_dir = _get_res_dir(project_root)

    # Only consider regular string keys for missing check
    regular_keys = {k for k in source_strings if not k.startswith("__")}

    missing = {}
    for lang_code in target_languages:
        target_file = res_dir / f"values-{lang_code}" / "strings.xml"
        if target_file.exists():
            tree = ET.parse(target_file)
            root = tree.getroot()
            existing = set()
            for elem in root:
                if elem.tag == "string":
                    name = elem.get("name", "")
                    if name:
                        existing.add(name)
                elif elem.tag == "string-array":
                    name = elem.get("name", "")
                    if name:
                        existing.add(name)
                elif elem.tag == "plurals":
                    name = elem.get("name", "")
                    if name:
                        existing.add(name)

            # Check which source keys are missing
            missing_keys = []
            for k in source_strings:
                if k.startswith("__array__"):
                    real_name = k.split("__", 2)[2]
                    if real_name not in existing:
                        missing_keys.append(k)
                elif k.startswith("__plural__"):
                    parts = k.split("__")
                    real_name = parts[2]
                    if real_name not in existing:
                        missing_keys.append(k)
                else:
                    if k not in existing:
                        missing_keys.append(k)
        else:
            missing_keys = list(source_strings.keys())

        if missing_keys:
            missing[lang_code] = missing_keys

    return missing


def write_translations(
    project_root: Path,
    translations: dict[str, dict[str, str]],
    source_strings: dict[str, str],
) -> dict[str, int]:
    """Write translations to values-{lang}/strings.xml. Returns {lang_code: count}."""
    res_dir = _get_res_dir(project_root)

    # Reorganize: translations is {source_value: {lang: translated}}
    # We need: {lang: {key: translated_value}}
    lang_translations: dict[str, dict[str, str]] = {}
    for key, source_value in source_strings.items():
        if source_value in translations:
            for lang_code, translated_text in translations[source_value].items():
                lang_translations.setdefault(lang_code, {})[key] = translated_text

    stats = {}
    for lang_code, entries in lang_translations.items():
        target_dir = res_dir / f"values-{lang_code}"
        target_dir.mkdir(parents=True, exist_ok=True)
        target_file = target_dir / "strings.xml"

        # Load existing or create new
        if target_file.exists():
            tree = ET.parse(target_file)
            root = tree.getroot()
        else:
            root = ET.Element("resources")
            tree = ET.ElementTree(root)

        count = 0
        for key, value in entries.items():
            if key.startswith("__array__"):
                array_name = key.split("__", 2)[2]
                # Check if already exists
                exists = any(
                    e.tag == "string-array" and e.get("name") == array_name
                    for e in root
                )
                if not exists:
                    arr_elem = ET.SubElement(root, "string-array", name=array_name)
                    for item_text in value.split("|||"):
                        item = ET.SubElement(arr_elem, "item")
                        item.text = item_text.strip()
                    count += 1

            elif key.startswith("__plural__"):
                parts = key.split("__")
                plural_name = parts[2]
                quantity = parts[3]
                # Find or create plurals element
                plural_elem = None
                for e in root:
                    if e.tag == "plurals" and e.get("name") == plural_name:
                        plural_elem = e
                        break
                if plural_elem is None:
                    plural_elem = ET.SubElement(root, "plurals", name=plural_name)
                    count += 1
                item = ET.SubElement(plural_elem, "item", quantity=quantity)
                item.text = value

            else:
                # Regular string
                exists = any(
                    e.tag == "string" and e.get("name") == key
                    for e in root
                )
                if not exists:
                    elem = ET.SubElement(root, "string", name=key)
                    elem.text = value
                    count += 1

        # Write with proper XML declaration
        ET.indent(tree, space="    ")
        with open(target_file, "wb") as f:
            tree.write(f, encoding="utf-8", xml_declaration=True)

        stats[lang_code] = count

    return stats
