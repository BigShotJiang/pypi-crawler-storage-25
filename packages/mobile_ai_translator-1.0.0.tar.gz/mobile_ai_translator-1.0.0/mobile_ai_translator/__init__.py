"""
mobile-ai-translator — AI-powered translation for Flutter, Android & iOS.

Setup:
    1. pip install mobile-ai-translator
    2. cd your-mobile-project/
    3. Run: mobile-ai-translate
"""

__version__ = "1.0.0"
__author__ = "Happy Cyber"
__license__ = "MIT"
