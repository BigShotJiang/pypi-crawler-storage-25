**FileSystem:** A file type module for Python

**Usage:** Make a empty .py file, and paste the contents inside FileSystem.py into the empyty file. Now import the functions using from your_file_name import file, folder, path, system

**JOIN OUR DISCORD:** https://discord.gg/B9fGhbPGkP