# Claude Code Configuration - Workweaver

`AGENTS.md` is the single policy source of truth for this repository.

This folder contains Claude Code implementation details only:

- `.claude/settings.json` for hooks, auto-invoke, and local runtime toggles.
- `.claude/agents/` for role-specific agent prompts.
- `.claude/commands/` for slash-command wrappers.
- `.claude/hooks/` for local automation hooks.
- `.claude/memories.md`, `.claude/anti-patterns.md`, `.claude/preferences.md` for pattern capture.

## Conflict Rule

- If any `.claude/*` content conflicts with `AGENTS.md`, `AGENTS.md` wins.
- Keep `.claude/*` thin and tool-specific to avoid duplicated policy and context pollution.
