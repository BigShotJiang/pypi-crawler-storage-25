# Design canonical snapshots

This folder preserves canonical design-source artifacts so the repo can
reproduce design decisions without re-fetching from external URLs.

## design-bundle-2026-05-14-rV6m.tar.gz

Source: `https://api.anthropic.com/v1/design/h/rV6m_jjfrdZ1GHFgiMBwTw`
(claude.ai/design handoff bundle for project "Workweaver Design System").

Two sessions:
- `chats/chat1.md` — initial design session 2026-04-19 (visual system, token rules, calendar shell, chat-first interaction model).
- `chats/chat2.md` — admin-parity follow-up 2026-05-11 (admin shell kit, Zara identity surfaces, wallet UI placement).

Why preserved here:
- Provides reproducible canonical source for design decisions, including
  D015 (plain glass restored).
- The remote URL is session-auth-gated and not reliably fetchable from
  arbitrary contexts. Committing the artifact ensures future agents (and
  reviewers) can audit the canon without re-authenticating.

How to extract:
```
mkdir -p /tmp/ww-design-bundle
gunzip -c .claude/snapshots/design-bundle-2026-05-14-rV6m.tar.gz | \
  tar -x -C /tmp/ww-design-bundle
```

Bundle contents map to repo as follows:
- `project/SKILL.md` → `.workweaver-design/SKILL.md`
- `project/README.md` → `.workweaver-design/README.md`
- `project/HANDOFF.md` → `.workweaver-design/HANDOFF.md`
- `project/README-ADMIN.md` → `.workweaver-design/README-ADMIN.md`
- `project/colors_and_type.css` → `.workweaver-design/colors_and_type.css`
- `project/admin-shell-kit.html` → `.workweaver-design/admin-shell-kit.html`
- `project/preview/*` → `.workweaver-design/preview/*`
- `project/ui_kits/*` → `.workweaver-design/ui_kits/*`
- `project/assets/*` → `.workweaver-design/assets/*`

The repo-side files apply three product overrides per `docs/decisions/D015`:
1. 2 anchors (Mission, Settings) — bundle's 7-rail-item exploration is superseded.
2. Terminology updates: AI workforce / Evidence Ledger / Agent Identity (vs bundle's AI-Ops / Evidence Graph / AI-Ops Identity).
3. Self-hosted fonts (bundle's "Free Google Fonts" line dropped under production CSP).
