# Cursor config (Workweaver)

- **Rules**: `.cursor/rules/` — project rules (no Factory; Claude Code is primary).
- **MCP (local)**: `.cursor/mcp.json` — project MCP servers only; no Factory MCP servers.

## Removing Factory MCP (global + local)

Factory is deprecated. To ensure no Factory MCP servers run:

1. **Global** (Cursor app): Open **Cursor Settings → Tools & Integrations → MCP** (or edit `~/.cursor/mcp.json`). Remove any Factory MCP server entries from **globalFactorySettingsJSON**.
2. **Local (this project)**: This repo uses **localFactorySettingsJSON** via `.cursor/mcp.json` with no Factory servers. If you had Factory only in workspace settings, this file overrides that for the project.
3. Restart Cursor after changing global MCP config.
