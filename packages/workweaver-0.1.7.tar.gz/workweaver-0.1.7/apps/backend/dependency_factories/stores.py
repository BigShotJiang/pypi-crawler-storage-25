from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from apps.backend.services.meeting_session_store import MeetingSessionStore
    from apps.backend.services.mission_node_store import MissionNodeStore
    from apps.backend.services.role_store import RoleStore
    from apps.backend.services.scheduling.store import ScheduleStore
    from apps.backend.services.task_store import TaskStore
    from apps.backend.services.channels.whatsapp.store import WhatsAppMessageStore


@lru_cache(maxsize=1)
def get_task_store() -> TaskStore:
    """Return singleton TaskStore."""
    from apps.backend.services.task_store import get_task_store as _factory

    return _factory()


@lru_cache(maxsize=1)
def get_schedule_store() -> ScheduleStore:
    """Return singleton ScheduleStore."""
    from apps.backend.services.scheduling.store import get_schedule_store as _factory

    return _factory()


@lru_cache(maxsize=1)
def get_mission_node_store() -> MissionNodeStore:
    """Return singleton MissionNodeStore."""
    from apps.backend.services.mission_node_store import get_mission_node_store as _factory

    return _factory()


@lru_cache(maxsize=1)
def get_meeting_session_store() -> MeetingSessionStore:
    """Return singleton MeetingSessionStore."""
    from apps.backend.services.meeting_session_store import (
        get_meeting_session_store as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_role_store() -> RoleStore:
    """Return singleton RoleStore."""
    from apps.backend.services.role_store import get_role_store as _factory

    return _factory()


def get_whatsapp_message_store() -> WhatsAppMessageStore:
    """Return a WhatsAppMessageStore instance."""
    from apps.backend.services.channels.whatsapp.store import (
        get_whatsapp_message_store as _factory,
    )

    return _factory()
