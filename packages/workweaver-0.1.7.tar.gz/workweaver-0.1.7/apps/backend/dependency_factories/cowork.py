from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from apps.backend.services.agent_context_store import AgentContextStore as EmployeeContextStore
    from apps.backend.services.learning import EmployeeLearningLoop
    from apps.backend.services.clarification_protocol import ClarificationProtocol
    from apps.backend.services.customer_context_store import CustomerContextStore
    from apps.backend.services.session.session_continuity import SessionContinuityService
    from apps.backend.services.skills.skill_guidance_store import SkillGuidanceStore


@lru_cache(maxsize=1)
def get_employee_context_store() -> EmployeeContextStore:
    """Return singleton AgentContextStore."""
    from apps.backend.services.agent_context_store import (
        get_agent_context_store as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_customer_context_store() -> CustomerContextStore:
    """Return singleton CustomerContextStore."""
    from apps.backend.services.customer_context_store import (
        get_customer_context_store as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_session_continuity_service() -> SessionContinuityService:
    """Return singleton SessionContinuityService."""
    from apps.backend.services.session.session_continuity import (
        get_session_continuity_service as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_employee_learning_loop() -> EmployeeLearningLoop:
    """Return singleton EmployeeLearningLoop."""
    from apps.backend.services.learning import (
        get_agent_learning_loop as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_skill_guidance_store() -> SkillGuidanceStore:
    """Return singleton SkillGuidanceStore."""
    from apps.backend.services.skills.skill_guidance_store import (
        get_skill_guidance_store as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_clarification_protocol() -> ClarificationProtocol:
    """Return singleton ClarificationProtocol."""
    from apps.backend.services.clarification_protocol import (
        get_clarification_protocol as _factory,
    )

    return _factory()
