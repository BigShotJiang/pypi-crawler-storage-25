from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from apps.backend.services.billing.compensation import CompensationService
    from apps.backend.services.notification_service import NotificationService


def get_compensation_service() -> CompensationService:
    """Return a CompensationService instance."""
    from apps.backend.services.billing.compensation import get_compensation_service as _factory

    return _factory()


@lru_cache(maxsize=1)
def get_notification_service() -> NotificationService:
    """Return singleton NotificationService."""
    from apps.backend.services.notification_service import (
        get_notification_service as _factory,
    )

    return _factory()
