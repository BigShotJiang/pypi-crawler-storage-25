from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from apps.backend.services.agent_instance_manager import AgentInstanceManager


@lru_cache(maxsize=1)
def get_agent_instance_manager() -> AgentInstanceManager:
    """Return singleton AgentInstanceManager wired through the public facade."""
    from apps.backend.services.agent_instance_manager import AgentInstanceManager
    from apps.backend.services.stores.instance_store import InstanceStore
    from apps.backend.dependency_factories.agents import get_agent_profile_store
    from apps.backend.dependency_factories.core import get_event_bus

    return AgentInstanceManager(
        router=None,
        profile_store=get_agent_profile_store(),
        event_bus=get_event_bus(),
        store=InstanceStore(),
    )


@lru_cache(maxsize=1)
def get_connector_executor() -> Any:
    """Return singleton ConnectorExecutor wired to the public broker getter.

    Issue #2747: also injects the ConnectorHealthService so the executor
    populates structured remediation hints (`error_message`,
    `error_category`, `needs_reauth`) on every recorded failure. Without
    this wiring, the new fields would be inert in the live runtime path.
    Falls back gracefully when the health-service factory is unavailable.
    """
    from apps.backend.services.connectors.connector_executor import ConnectorExecutor
    from apps.backend.dependency_factories.connectors import get_connector_policy_broker

    try:
        from apps.backend.services.connector_health_service import (
            get_connector_health_service,
        )

        health_service = get_connector_health_service()
    except Exception:
        health_service = None

    return ConnectorExecutor(
        policy_broker=get_connector_policy_broker(),
        health_service=health_service,
    )
