from __future__ import annotations
from apps.backend.config.table_names import resolve_table

from functools import lru_cache
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from apps.backend.services.degradation_notifier import DegradationNotifier
    from apps.backend.services.event_bus import EventBus
    from apps.backend.services.telemetry_policy import TelemetryPolicy


def get_tenants_table() -> Any:
    """Return shared tenants-table resource through one dependency seam."""
    from apps.backend.services.tenants_table import resolve_tenants_table_name

    return get_dynamodb_table(resolve_tenants_table_name())


def get_orgs_table() -> Any:
    """Return shared orgs-table resource through one dependency seam."""
    from apps.backend.services.orgs_table import resolve_orgs_table_name

    return get_dynamodb_table(resolve_orgs_table_name())


def get_users_table() -> Any:
    """Return shared users-table resource through one dependency seam."""
    table_name = str(resolve_table("users")).strip() or "workweaver-users"
    return get_dynamodb_table(table_name)


def get_dynamodb_table(table_name: str) -> Any:
    """Resolve a DynamoDB table resource using the infrastructure store seam."""
    from apps.backend.services.dynamo_store import get_table

    return get_table(table_name=table_name)


def get_aws_client(service_name: str, *, region_name: str | None = None) -> Any:
    """Resolve an AWS SDK client through a single dependency seam."""
    import boto3

    return boto3.client(service_name, region_name=region_name)


@lru_cache(maxsize=1)
def get_event_bus() -> EventBus:
    """Return singleton EventBus instance."""
    from apps.backend.services.event_bus import get_event_bus as _factory

    return _factory()


@lru_cache(maxsize=1)
def get_telemetry_policy() -> TelemetryPolicy:
    """Return shared TelemetryPolicy singleton."""
    from apps.backend.services.telemetry_policy import get_telemetry_policy as _factory

    return _factory()


@lru_cache(maxsize=1)
def get_degradation_notifier() -> DegradationNotifier:
    """Return shared DegradationNotifier singleton."""
    from apps.backend.services.degradation_notifier import (
        get_degradation_notifier as _factory,
    )

    return _factory()
