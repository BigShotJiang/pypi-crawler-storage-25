from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from apps.backend.services.async_scheduler import AsyncScheduler
    from apps.backend.services.company_graph import CompanyGraph
    from apps.backend.services.metric_direction import MetricRegistry
    from apps.backend.services.online_eval import OnlineEvalService
    from apps.backend.services.regulated_action_rails import RegulatedActionRails
    from apps.backend.services.zara.zara_goal_intake import ZaraGoalIntake


@lru_cache(maxsize=1)
def get_async_scheduler() -> AsyncScheduler:
    """Return the singleton AsyncScheduler for standalone deployments."""
    from apps.backend.services.async_scheduler import AsyncScheduler

    return AsyncScheduler()


@lru_cache(maxsize=1)
def get_company_graph() -> CompanyGraph:
    """Return the singleton CompanyGraph."""
    from apps.backend.services.company_graph import CompanyGraph

    return CompanyGraph()


@lru_cache(maxsize=1)
def get_metric_registry() -> MetricRegistry:
    """Return the shared OnlineEval metric registry.

    Managed profiles persist metric definitions in DynamoDB when
    METRIC_REGISTRY_TABLE_NAME is configured. Local and standalone profiles use
    the in-process registry seeded with the same built-in metric directions.
    """
    from apps.backend.services.metric_direction import (
        DynamoDBMetricRegistryStore,
        create_online_eval_metric_registry,
    )

    from apps.backend.config.table_names import configured_table

    table_name = configured_table("metric_registry")
    if not table_name:
        return create_online_eval_metric_registry()

    from apps.backend.dependency_factories.core import get_dynamodb_table

    return create_online_eval_metric_registry(store=DynamoDBMetricRegistryStore(get_dynamodb_table(table_name)))


@lru_cache(maxsize=1)
def get_online_eval_service() -> OnlineEvalService:
    """Return the singleton OnlineEvalService."""
    from apps.backend.services.online_eval import OnlineEvalService

    return OnlineEvalService(metric_registry=get_metric_registry())


@lru_cache(maxsize=1)
def get_regulated_action_rails() -> RegulatedActionRails:
    """Return the singleton RegulatedActionRails."""
    from apps.backend.services.regulated_action_rails import RegulatedActionRails

    return RegulatedActionRails()


@lru_cache(maxsize=1)
def get_zara_goal_intake() -> ZaraGoalIntake:
    """Return the singleton ZaraGoalIntake."""
    from apps.backend.services.zara.zara_goal_intake import ZaraGoalIntake

    return ZaraGoalIntake()
