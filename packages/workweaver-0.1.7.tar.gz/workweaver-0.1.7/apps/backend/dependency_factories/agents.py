from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from apps.backend.services.agent_activation_service import (
        AgentActivationService as HireEmployeeService,
    )
    from apps.backend.services.agent_profile_store import AgentProfileStore
    from apps.backend.services.approval_gates import ApprovalGates
    from apps.backend.services.lead_scorer import LeadScorer
    from apps.backend.services.unified_skill_registry import UnifiedSkillRegistry


@lru_cache(maxsize=1)
def get_agent_profile_store() -> AgentProfileStore:
    """Return singleton AgentProfileStore."""
    from apps.backend.services.agent_profile_store import (
        get_agent_profile_store as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_unified_skill_registry() -> UnifiedSkillRegistry:
    """Return UnifiedSkillRegistry instance."""
    from apps.backend.services.unified_skill_registry import (
        get_unified_skill_registry as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_hire_employee_service() -> HireEmployeeService:
    """Return singleton AgentActivationService (backward-compat name)."""
    from apps.backend.services.agent_activation_service import (
        get_agent_activation_service as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_approval_gates() -> ApprovalGates:
    """Return singleton ApprovalGates with the default expiration."""
    from apps.backend.services.approval_gates import get_approval_gates as _factory

    return _factory(default_expiration_seconds=3600)


@lru_cache(maxsize=1)
def get_lead_scorer() -> LeadScorer:
    """Return singleton LeadScorer."""
    from apps.backend.services.lead_scorer import get_lead_scorer as _factory

    return _factory()
