"""Grouped FastAPI/backend dependency factories.

`apps.backend.dependencies` remains the public import surface. This package
holds the implementation modules so the facade can stay small and callers do
not need to change.
"""
