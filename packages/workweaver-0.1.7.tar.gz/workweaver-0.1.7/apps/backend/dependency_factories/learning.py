from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from apps.backend.services.scheduling.calendar_service import CalendarService
    from apps.backend.services.learning import LearningLoopService


@lru_cache(maxsize=1)
def get_calendar_service() -> CalendarService:
    """Return singleton CalendarService seam."""
    from apps.backend.services.scheduling.calendar_service import CalendarService

    return CalendarService()


def get_learning_loop_service(
    tenant_id: str,
    memory_service: Any,
    evidence_service: Any,
    task_improvement_service: Any | None = None,
    governance_service: Any | None = None,
    employee_learning_loop: Any | None = None,
) -> LearningLoopService:
    """Construct a tenant-scoped LearningLoopService."""
    from apps.backend.services.learning import build_learning_loop_service

    return build_learning_loop_service(
        tenant_id=tenant_id,
        memory_service=memory_service,
        evidence_service=evidence_service,
        task_improvement_service=task_improvement_service,
        governance_service=governance_service,
        employee_learning_loop=employee_learning_loop,
    )


def get_cross_loop_compounding_service() -> Any:
    """Return a new CrossLoopCompoundingService wired to the shared store.

    Intentionally not cached: callers may override the underlying store in
    tests, and the historical contract was one fresh wrapper per call.
    """
    from apps.backend.services.cross_loop_compounding import CrossLoopCompoundingService
    from apps.backend.services.dynamo_store import _get_table

    return CrossLoopCompoundingService(store=_get_table())


def get_developer_loop_service() -> Any:
    """Return a new DeveloperLoopService with the default learnings directory.

    Intentionally not cached to preserve the previous facade behavior.
    """
    from apps.backend.services.developer_loop import DeveloperLoopService

    return DeveloperLoopService()
