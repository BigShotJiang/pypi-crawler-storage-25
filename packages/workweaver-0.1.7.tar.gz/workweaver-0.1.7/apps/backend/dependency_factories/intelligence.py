from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from apps.backend.services.batch_orchestrator import BatchOrchestrator
    from apps.backend.services.developmental_intelligence import DevelopmentalIntelligenceService
    from apps.backend.services.grok_skill_selector import GrokSkillSelector
    from apps.backend.services.inference_aggregator import IntelligenceAggregator
    from apps.backend.services.inference.intelligence_service import ProactiveIntelligenceEngine
    from apps.backend.services.runtime.provisioning_service import (
        WorkweaverRuntimeProvisioningService,
    )


@lru_cache(maxsize=1)
def get_proactive_intelligence_engine() -> ProactiveIntelligenceEngine:
    """Return singleton ProactiveIntelligenceEngine."""
    from apps.backend.services.inference.intelligence_service import (
        get_proactive_intelligence_engine as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_developmental_intelligence_service() -> DevelopmentalIntelligenceService:
    """Return singleton DevelopmentalIntelligenceService."""
    from apps.backend.services.developmental_intelligence import (
        get_developmental_intelligence_service as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_intelligence_aggregator() -> IntelligenceAggregator:
    """Return singleton IntelligenceAggregator."""
    from apps.backend.services.inference_aggregator import (
        get_intelligence_aggregator as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_batch_orchestrator() -> BatchOrchestrator:
    """Return singleton BatchOrchestrator."""
    from apps.backend.services.batch_orchestrator import (
        get_batch_orchestrator as _factory,
    )

    return _factory()


def get_skill_selector() -> GrokSkillSelector:
    """Return a GrokSkillSelector instance."""
    from apps.backend.services.grok_skill_selector import (
        get_skill_selector as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_workweaver_runtime_provisioning_service() -> WorkweaverRuntimeProvisioningService:
    """Return singleton WorkweaverRuntimeProvisioningService."""
    from apps.backend.services.runtime.provisioning_service import (
        get_workweaver_runtime_provisioning_service as _factory,
    )

    return _factory()
