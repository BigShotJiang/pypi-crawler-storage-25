from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from apps.backend.services.connector_policy_broker import ConnectorPolicyBroker
    from apps.backend.services.connectors.connector_sdk import ConnectorSDK
    from apps.backend.services.connectors.marketplace import IntegrationMarketplace


@lru_cache(maxsize=1)
def get_connector_policy_broker() -> ConnectorPolicyBroker:
    """Return singleton ConnectorPolicyBroker wired to the credential vault."""
    from apps.backend.services.connector_policy_broker import (
        get_connector_policy_broker as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_connector_sdk() -> ConnectorSDK:
    """Return singleton ConnectorSDK."""
    from apps.backend.services.connectors.connector_sdk import (
        get_connector_sdk as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_marketplace() -> IntegrationMarketplace:
    """Return singleton IntegrationMarketplace."""
    from apps.backend.services.connectors.marketplace import get_marketplace as _factory

    return _factory()
