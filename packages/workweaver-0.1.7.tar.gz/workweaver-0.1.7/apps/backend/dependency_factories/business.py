from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from apps.backend.services.audit_logger import AuditLogger
    from apps.backend.services.payment_event_resource_store import PaymentEventResourceStore
    from apps.backend.services.email_threading import EmailThreadingService
    from apps.backend.services.memory.service import MemoryService
    from apps.backend.services.billing import MeteringService
    from apps.backend.services.mission_contracts import MissionContractsService
    from apps.backend.services.thread_service import ThreadService
    from apps.backend.services.usage_tracker import UsageTrackerService

# Re-export canonical factory from evidence_ledger.py (single definition).
from apps.backend.services.evidence_ledger import (  # noqa: F401
    get_evidence_ledger_service,
)


@lru_cache(maxsize=1)
def get_usage_tracker() -> UsageTrackerService:
    """Return singleton UsageTrackerService."""
    from apps.backend.services.usage_tracker import UsageTrackerService

    return UsageTrackerService()


@lru_cache(maxsize=1)
def get_metering_service() -> MeteringService:
    """Return singleton MeteringService."""
    from apps.backend.services.billing import MeteringService

    return MeteringService()


@lru_cache(maxsize=1)
def get_audit_logger() -> AuditLogger:
    """Return singleton AuditLogger."""
    from apps.backend.services.audit_logger import get_audit_logger as _factory

    return _factory()


@lru_cache(maxsize=1)
def get_payment_event_resource_store() -> PaymentEventResourceStore:
    """Return singleton PaymentEventResourceStore."""
    from apps.backend.services.payment_event_resource_store import (
        get_payment_event_resource_store as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_memory_service() -> MemoryService:
    """Return singleton MemoryService."""
    from apps.backend.services.memory.service import get_memory_service as _factory

    return _factory()


@lru_cache(maxsize=1)
def get_mission_contracts_service() -> MissionContractsService:
    """Return singleton MissionContractsService."""
    from apps.backend.services.mission_contracts import (
        get_mission_contracts_service as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_email_threading_service() -> EmailThreadingService:
    """Return singleton EmailThreadingService."""
    from apps.backend.services.email_threading import (
        get_email_threading_service as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_thread_service() -> ThreadService:
    """Return singleton ThreadService."""
    from apps.backend.services.thread_service import get_thread_service as _factory

    return _factory()
