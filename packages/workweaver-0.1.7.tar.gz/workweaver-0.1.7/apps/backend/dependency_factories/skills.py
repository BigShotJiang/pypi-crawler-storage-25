from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from apps.backend.services.repo_skill_catalog import RepoSkillCatalogService


@lru_cache(maxsize=1)
def get_repo_skill_catalog_service() -> RepoSkillCatalogService:
    """Return singleton RepoSkillCatalogService."""
    from apps.backend.services.repo_skill_catalog import RepoSkillCatalogService

    return RepoSkillCatalogService()
