from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from apps.backend.services.billing.stripe_checkout import StripeCheckoutService
    from apps.backend.services.billing.subscription_service import SubscriptionManager
    from apps.backend.services.tenant_provisioning import TenantProvisioningService


@lru_cache(maxsize=1)
def get_tenant_provisioning_service() -> TenantProvisioningService:
    """Return singleton TenantProvisioningService."""
    from apps.backend.services.tenant_provisioning import (
        get_tenant_provisioning_service as _factory,
    )

    return _factory()


def get_subscription_manager() -> SubscriptionManager:
    """Return singleton SubscriptionManager (Stripe-backed)."""
    from apps.backend.services.billing.subscription_service import (
        get_subscription_manager as _factory,
    )

    return _factory()


def get_stripe_checkout_service() -> StripeCheckoutService:
    """Return singleton StripeCheckoutService."""
    from apps.backend.services.billing.stripe_checkout import (
        get_stripe_checkout_service as _factory,
    )

    return _factory()
