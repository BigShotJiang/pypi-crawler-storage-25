from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    pass


@lru_cache(maxsize=1)
def load_auth_identity_contract() -> dict:
    """Return the frozen auth/identity capability contract (parsed JSON object).

    Single JSON source: ``apps/backend/config/auth_identity_contract.json``.
    The landing copy at ``apps/landing/public/agent-knowledge/auth-contract.json`` must match;
    ``tests/unit/test_auth_identity_contract.py`` enforces parity.
    """
    import json
    from pathlib import Path

    _CONFIG_PATH = Path(__file__).resolve().parents[1] / "config" / "auth_identity_contract.json"
    raw = _CONFIG_PATH.read_text(encoding="utf-8")
    return json.loads(raw)
