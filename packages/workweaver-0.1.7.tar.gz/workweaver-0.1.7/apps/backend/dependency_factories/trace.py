from __future__ import annotations

from functools import lru_cache
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from apps.backend.services.capability_manifest import CapabilityManifestService
    from apps.backend.services.checkpoint_service import CheckpointService
    from apps.backend.services.connectors.action_discovery import ActionDiscoveryService
    from apps.backend.services.drift_detection import DriftDetectionService
    from apps.backend.services.domain_factory.provisioner import DomainProvisioner
    from apps.backend.services.domain_factory.zara_integration import DomainProvisioningHandler
    from apps.backend.services.goal_cascade import GoalCascadeService
    from apps.backend.services.human_override import HumanOverrideService
    from apps.backend.services.time_rollup_service import TimeRollupService
    from apps.backend.services.learning.trace_strategy_miner import StrategyMiner
    from apps.backend.services.learning.trace_strategy_retriever import StrategyRetriever
    from apps.backend.services.learning.trace_strategy_store import StrategyStore
    from apps.backend.services.trace_store import InferenceTraceStore


@lru_cache(maxsize=1)
def get_inference_trace_store() -> InferenceTraceStore:
    """Return singleton InferenceTraceStore."""
    from apps.backend.services.trace_store import (
        get_inference_trace_store as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_strategy_store() -> StrategyStore:
    """Return singleton StrategyStore."""
    from apps.backend.services.learning.trace_strategy_store import (
        get_strategy_store as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_strategy_miner() -> StrategyMiner:
    """Return singleton StrategyMiner."""
    from apps.backend.services.learning.trace_strategy_miner import (
        get_strategy_miner as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_strategy_retriever() -> StrategyRetriever:
    """Return singleton StrategyRetriever."""
    from apps.backend.services.learning.trace_strategy_retriever import (
        get_strategy_retriever as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_checkpoint_service() -> CheckpointService:
    """Return singleton CheckpointService."""
    from apps.backend.services.checkpoint_service import (
        get_checkpoint_service as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_drift_detection_service() -> DriftDetectionService:
    """Return singleton DriftDetectionService."""
    from apps.backend.services.drift_detection import (
        get_drift_detection_service as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_human_override_service() -> HumanOverrideService:
    """Return singleton HumanOverrideService."""
    from apps.backend.services.human_override import (
        get_human_override_service as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_goal_cascade_service() -> GoalCascadeService:
    """Return singleton GoalCascadeService."""
    from apps.backend.services.goal_cascade import GoalCascadeService

    return GoalCascadeService()


@lru_cache(maxsize=1)
def get_capability_manifest_service() -> CapabilityManifestService:
    """Return singleton CapabilityManifestService."""
    from apps.backend.services.capability_manifest import (
        get_capability_manifest_service as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_action_discovery_service() -> ActionDiscoveryService:
    """Return singleton ActionDiscoveryService."""
    from apps.backend.services.connectors.action_discovery import (
        ActionDiscoveryService,
    )

    return ActionDiscoveryService()


@lru_cache(maxsize=1)
def get_time_rollup_service() -> TimeRollupService:
    """Return singleton TimeRollupService."""
    from apps.backend.services.time_rollup_service import (
        get_time_rollup_service as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_domain_provisioner() -> DomainProvisioner:
    """Return singleton DomainProvisioner."""
    from apps.backend.services.domain_factory.provisioner import (
        get_domain_provisioner as _factory,
    )

    return _factory()


@lru_cache(maxsize=1)
def get_domain_provisioning_handler() -> DomainProvisioningHandler:
    """Return singleton DomainProvisioningHandler."""
    from apps.backend.services.domain_factory.zara_integration import (
        get_domain_provisioning_handler as _factory,
    )

    return _factory()
