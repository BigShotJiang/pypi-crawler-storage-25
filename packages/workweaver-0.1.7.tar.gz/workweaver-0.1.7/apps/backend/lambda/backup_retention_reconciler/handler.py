"""AWS Backup recovery-point retention reconciler (#798).

Nightly Lambda that prunes recovery points exceeding the declared
retention window. AWS Backup lifecycle rules only control NEW backups
going forward — they do not retroactively prune existing recovery
points when retention is shortened. This Lambda closes that gap by
reconciling actual vault state against declared policy on a schedule.

Safety constraints:

  - DRY_RUN env can disable real deletions (recommended for first deploy).
  - GRACE_WINDOW_HOURS protects recently-created recovery points from
    being pruned mid-creation (default: 6 hours).
  - HARD_CAP_DELETES_PER_RUN refuses to delete more than N RPs in one
    invocation (default: 200) — runaway deletes require human review.
  - Recovery points tagged ``DoNotPrune=true`` are always kept.
  - S3 RPs in compliance-mode object lock are always kept.

Invocation: EventBridge scheduled rule, daily at 04:30 UTC (after the
ECS task def cleanup at 04:00 UTC).

Environment variables:
    ENVIRONMENT             - 'dev' | 'staging' | 'prod'
    AWS_REGION              - AWS region (default: 'us-east-1')
    PRIMARY_VAULT_NAME      - primary backup vault name (required)
    DR_VAULT_NAME           - secondary DR vault name (optional)
    RETENTION_DAYS          - max age in days a non-protected RP may have
                              (default: 30)
    GRACE_WINDOW_HOURS      - skip RPs younger than this (default: 6)
    HARD_CAP_DELETES_PER_RUN - refuse to delete more than this in one run
                               (default: 200)
    DRY_RUN                 - 'true' to skip actual delete calls
"""

from __future__ import annotations

import logging
import os
from datetime import datetime, timedelta, timezone
from typing import Any

import boto3
from botocore.exceptions import BotoCoreError, ClientError

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


# =============================================================================
# Configuration
# =============================================================================

ENVIRONMENT = os.getenv("ENVIRONMENT", "prod")
AWS_REGION = os.getenv("AWS_REGION", "us-east-1")
DR_REGION = os.getenv("DR_REGION", "us-west-2")
PRIMARY_VAULT_NAME = os.getenv("PRIMARY_VAULT_NAME", "").strip()
DR_VAULT_NAME = os.getenv("DR_VAULT_NAME", "").strip()
RETENTION_DAYS = int(os.getenv("RETENTION_DAYS", "30"))
GRACE_WINDOW_HOURS = int(os.getenv("GRACE_WINDOW_HOURS", "6"))
HARD_CAP_DELETES_PER_RUN = int(os.getenv("HARD_CAP_DELETES_PER_RUN", "200"))
DRY_RUN = os.getenv("DRY_RUN", "false").strip().lower() in ("1", "true", "yes")


# =============================================================================
# Internal helpers
# =============================================================================


def _list_all_recovery_points(backup: Any, vault_name: str) -> list[dict[str, Any]]:
    """Return every recovery point in a vault (paginated)."""
    rps: list[dict[str, Any]] = []
    paginator = backup.get_paginator("list_recovery_points_by_backup_vault")
    for page in paginator.paginate(BackupVaultName=vault_name):
        rps.extend(page.get("RecoveryPoints", []))
    return rps


def _get_rp_tags(backup: Any, rp_arn: str) -> dict[str, str]:
    """Fetch resource tags for a recovery point ARN. Returns empty dict on error."""
    try:
        resp = backup.list_tags(ResourceArn=rp_arn)
        return resp.get("Tags", {}) or {}
    except (ClientError, BotoCoreError) as exc:
        logger.warning("list_tags_failed arn=%s error=%s", rp_arn, exc)
        return {}


def _is_protected(rp: dict[str, Any], tags: dict[str, str]) -> tuple[bool, str]:
    """Return (protected, reason). Protected RPs are never pruned."""
    if tags.get("DoNotPrune", "").strip().lower() in ("1", "true", "yes"):
        return True, "tag_do_not_prune"
    # S3 compliance-mode object lock implies hard hold.
    if rp.get("ResourceType") == "S3" and rp.get("ParentRecoveryPointArn") is None:
        # The full S3 lock check requires get-object-lock-configuration on the
        # underlying bucket; we conservatively keep S3 RPs to avoid GDPR/SOX
        # violations. Surface this so the operator knows to revisit.
        return True, "s3_resource_conservative_keep"
    return False, ""


def _within_grace_window(rp: dict[str, Any], now: datetime) -> bool:
    """Return True if the RP is younger than the grace window."""
    created_at = rp.get("CreationDate")
    if created_at is None:
        return True  # Conservative: skip if we can't tell
    if isinstance(created_at, str):
        try:
            created_at = datetime.fromisoformat(created_at)
        except ValueError:
            return True
    if created_at.tzinfo is None:
        created_at = created_at.replace(tzinfo=timezone.utc)
    return (now - created_at) < timedelta(hours=GRACE_WINDOW_HOURS)


def _exceeds_retention(rp: dict[str, Any], now: datetime) -> bool:
    """Return True if the RP is older than RETENTION_DAYS."""
    created_at = rp.get("CreationDate")
    if created_at is None:
        return False
    if isinstance(created_at, str):
        try:
            created_at = datetime.fromisoformat(created_at)
        except ValueError:
            return False
    if created_at.tzinfo is None:
        created_at = created_at.replace(tzinfo=timezone.utc)
    return (now - created_at) > timedelta(days=RETENTION_DAYS)


def _delete_safely(backup: Any, vault_name: str, rp_arn: str) -> bool:
    """Delete a recovery point. Returns True on success, False on AWS error."""
    if DRY_RUN:
        logger.info("dry_run_skip_delete vault=%s arn=%s", vault_name, rp_arn)
        return True
    try:
        backup.delete_recovery_point(BackupVaultName=vault_name, RecoveryPointArn=rp_arn)
        return True
    except (ClientError, BotoCoreError) as exc:
        logger.error("delete_recovery_point_failed vault=%s arn=%s error=%s", vault_name, rp_arn, exc)
        return False


def _reconcile_vault(backup: Any, vault_name: str, now: datetime) -> dict[str, Any]:
    """Reconcile a single vault. Returns a per-vault summary."""
    if not vault_name:
        return {"vault": "", "skipped": "no name configured"}

    try:
        rps = _list_all_recovery_points(backup, vault_name)
    except (ClientError, BotoCoreError) as exc:
        logger.error("list_recovery_points_failed vault=%s error=%s", vault_name, exc)
        return {"vault": vault_name, "error": str(exc)}

    total = len(rps)
    candidates: list[dict[str, Any]] = []
    protected = 0
    in_grace = 0

    for rp in rps:
        if _within_grace_window(rp, now):
            in_grace += 1
            continue
        if not _exceeds_retention(rp, now):
            continue
        tags = _get_rp_tags(backup, rp.get("RecoveryPointArn", ""))
        is_protected, reason = _is_protected(rp, tags)
        if is_protected:
            protected += 1
            logger.info("rp_protected vault=%s arn=%s reason=%s", vault_name, rp.get("RecoveryPointArn"), reason)
            continue
        candidates.append(rp)

    # Hard cap on deletes per run.
    if len(candidates) > HARD_CAP_DELETES_PER_RUN:
        logger.error(
            "hard_cap_exceeded vault=%s would_delete=%d cap=%d",
            vault_name,
            len(candidates),
            HARD_CAP_DELETES_PER_RUN,
        )
        return {
            "vault": vault_name,
            "rp_total": total,
            "would_delete": len(candidates),
            "deleted": 0,
            "protected": protected,
            "in_grace": in_grace,
            "hard_capped": True,
            "cap": HARD_CAP_DELETES_PER_RUN,
        }

    deleted = 0
    failed = 0
    for rp in candidates:
        if _delete_safely(backup, vault_name, rp.get("RecoveryPointArn", "")):
            deleted += 1
        else:
            failed += 1

    return {
        "vault": vault_name,
        "rp_total": total,
        "deleted": deleted,
        "delete_failed": failed,
        "protected": protected,
        "in_grace": in_grace,
        "would_delete": deleted + failed,
        "hard_capped": False,
        "dry_run": DRY_RUN,
    }


# =============================================================================
# Entry point
# =============================================================================


def lambda_handler(event: dict | None, _context: Any) -> dict[str, Any]:
    """EventBridge entry point.

    Returns a per-vault summary. Allows the caller to override DRY_RUN
    via the event payload (``{"dry_run": true}``) for ad-hoc safe runs.

    Per-region boto3 clients: AWS Backup is regional, so the primary
    vault (us-east-1) and DR vault (us-west-2) need separate clients
    pointed at their respective endpoints. A single shared client
    pinned to one region will return AccessDeniedException for any
    vault outside its region (the message is misleading — it's a
    "vault not found in this region" error wearing an IAM disguise).
    """
    global DRY_RUN  # noqa: PLW0603
    if event and isinstance(event, dict) and "dry_run" in event:
        DRY_RUN = bool(event["dry_run"])

    if not PRIMARY_VAULT_NAME:
        raise RuntimeError("PRIMARY_VAULT_NAME env var is required")

    primary_client = boto3.client("backup", region_name=AWS_REGION)
    now = datetime.now(timezone.utc)

    summary: dict[str, Any] = {
        "environment": ENVIRONMENT,
        "retention_days": RETENTION_DAYS,
        "grace_window_hours": GRACE_WINDOW_HOURS,
        "hard_cap_deletes_per_run": HARD_CAP_DELETES_PER_RUN,
        "dry_run": DRY_RUN,
        "vaults": [],
    }

    summary["vaults"].append(_reconcile_vault(primary_client, PRIMARY_VAULT_NAME, now))
    if DR_VAULT_NAME:
        dr_client = boto3.client("backup", region_name=DR_REGION)
        summary["vaults"].append(_reconcile_vault(dr_client, DR_VAULT_NAME, now))

    logger.info("backup_retention_reconciler_complete %s", summary)
    return summary
