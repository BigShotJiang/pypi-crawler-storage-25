"""Integration catalog for supported third-party connectors."""

from __future__ import annotations

import logging
from dataclasses import dataclass, field
from enum import Enum

from apps.backend.services.zoho.product_registry import list_zoho_catalog_products

logger = logging.getLogger(__name__)


class IntegrationCategory(str, Enum):
    CRM = "crm"
    CALENDAR = "calendar"
    EMAIL = "email"
    MESSAGING = "messaging"
    PAYMENTS = "payments"
    STORAGE = "storage"
    COMMUNICATION = "communication"
    SUPPORT = "support"
    ACCOUNTING = "accounting"
    MARKETING = "marketing"
    PRODUCTIVITY = "productivity"
    LEGAL = "legal"
    IDENTITY = "identity"
    CMS = "cms"


class AuthType(str, Enum):
    OAUTH2 = "oauth2"
    API_KEY = "api_key"
    BASIC_AUTH = "basic_auth"
    BEARER_TOKEN = "bearer_token"
    WEBHOOK = "webhook"


@dataclass
class IntegrationDefinition:
    name: str
    category: IntegrationCategory
    auth_type: AuthType
    description: str
    capabilities: list[str]
    config_required: bool = True
    is_available: bool = True
    metadata: dict[str, object] = field(default_factory=dict)


class IntegrationsRegistry:
    """In-memory integration catalog used by APIs and OAuth orchestration."""

    _BASE_INTEGRATIONS: dict[str, IntegrationDefinition] = {
        "Salesforce": IntegrationDefinition(
            name="Salesforce",
            category=IntegrationCategory.CRM,
            auth_type=AuthType.OAUTH2,
            description="Salesforce CRM for enterprise sales workflows.",
            capabilities=["create_contact", "update_contact", "create_opportunity", "list_opportunities"],
        ),
        "HubSpot": IntegrationDefinition(
            name="HubSpot",
            category=IntegrationCategory.CRM,
            auth_type=AuthType.OAUTH2,
            description="CRM platform for sales and marketing workflows.",
            capabilities=["create_contact", "update_contact", "create_deal", "list_deals"],
        ),
        "Google Calendar": IntegrationDefinition(
            name="Google Calendar",
            category=IntegrationCategory.CALENDAR,
            auth_type=AuthType.OAUTH2,
            description="Scheduling, calendar events, and Google Meet meeting creation.",
            capabilities=["create_event", "update_event", "list_events", "create_meeting"],
        ),
        "Twilio WhatsApp": IntegrationDefinition(
            name="Twilio WhatsApp",
            category=IntegrationCategory.MESSAGING,
            auth_type=AuthType.API_KEY,
            description="WhatsApp messaging via Twilio APIs.",
            capabilities=["send_message", "send_media", "get_message_status"],
        ),
        "Stripe": IntegrationDefinition(
            name="Stripe",
            category=IntegrationCategory.PAYMENTS,
            auth_type=AuthType.API_KEY,
            description="Payment capture and customer billing operations.",
            capabilities=["create_payment_intent", "confirm_payment", "refund_charge"],
        ),
        "Google Drive": IntegrationDefinition(
            name="Google Drive",
            category=IntegrationCategory.STORAGE,
            auth_type=AuthType.OAUTH2,
            description="File storage and sharing automation.",
            capabilities=["upload_file", "download_file", "list_files"],
        ),
        # Google Docs/Sheets/Slides shipped #775 (2026-04-08).
        # Google Meet is intentionally NOT a separate entry — it's covered
        # by Google Calendar's create_meeting capability (Meet links are
        # provisioned via calendar.events with conferenceData.createRequest).
        "Google Docs": IntegrationDefinition(
            name="Google Docs",
            category=IntegrationCategory.PRODUCTIVITY,
            auth_type=AuthType.OAUTH2,
            description="Create, edit, and export Google Docs.",
            capabilities=["create_document", "append_text", "replace_text", "get_document", "export_as_pdf"],
        ),
        "Google Sheets": IntegrationDefinition(
            name="Google Sheets",
            category=IntegrationCategory.PRODUCTIVITY,
            auth_type=AuthType.OAUTH2,
            description="Create spreadsheets, read and write ranges, append rows.",
            capabilities=["create_spreadsheet", "read_range", "write_range", "append_row", "batch_update"],
        ),
        "Google Slides": IntegrationDefinition(
            name="Google Slides",
            category=IntegrationCategory.PRODUCTIVITY,
            auth_type=AuthType.OAUTH2,
            description="Create and edit Google Slides presentations.",
            capabilities=["create_presentation", "add_slide", "replace_all_text", "get_presentation", "batch_update"],
        ),
        "Slack": IntegrationDefinition(
            name="Slack",
            category=IntegrationCategory.COMMUNICATION,
            auth_type=AuthType.OAUTH2,
            description="Team messaging and channel notifications.",
            capabilities=["send_message", "create_channel", "list_channels"],
        ),
        "Gmail": IntegrationDefinition(
            name="Gmail",
            category=IntegrationCategory.EMAIL,
            auth_type=AuthType.OAUTH2,
            description="Google email sending and reading via Gmail API.",
            capabilities=["send_email", "read_email"],
        ),
        "Outlook": IntegrationDefinition(
            name="Outlook",
            category=IntegrationCategory.EMAIL,
            auth_type=AuthType.OAUTH2,
            # 2026-04-09 (#821): dropped read_email. The Entra app no longer
            # requests Mail.Read — only Mail.Send. Advertising read_email here
            # would cause skill planners to assume a capability the runtime
            # can't fulfil. If read_email is revived, restore Mail.Read in
            # integration_manager.py and marketplace.py first.
            description="Microsoft email sending via Microsoft Graph.",
            capabilities=["send_email"],
        ),
        "Microsoft Calendar": IntegrationDefinition(
            name="Microsoft Calendar",
            category=IntegrationCategory.CALENDAR,
            auth_type=AuthType.OAUTH2,
            description="Microsoft calendar event management via Microsoft Graph.",
            capabilities=["create_event", "list_events", "check_availability"],
        ),
        "Ghost": IntegrationDefinition(
            name="Ghost",
            category=IntegrationCategory.CMS,
            auth_type=AuthType.API_KEY,
            description="Ghost CMS — publish blog posts, manage pages, members, and newsletters. Works with self-hosted and Ghost(Pro).",
            capabilities=["posts", "pages", "tags", "members", "newsletters", "images", "site"],
            metadata={"documentation_url": "https://docs.ghost.org/admin-api/", "icon": "fas fa-ghost"},
        ),
    }

    def __init__(self) -> None:
        self._integrations: dict[str, IntegrationDefinition] = dict(self._BASE_INTEGRATIONS)
        self._integrations.update(self._build_zoho_integrations())

    @staticmethod
    def _zoho_category(value: str) -> IntegrationCategory:
        return {
            "accounting": IntegrationCategory.ACCOUNTING,
            "calendar": IntegrationCategory.CALENDAR,
            "communication": IntegrationCategory.COMMUNICATION,
            "crm": IntegrationCategory.CRM,
            "email": IntegrationCategory.EMAIL,
            "identity": IntegrationCategory.IDENTITY,
            "legal": IntegrationCategory.LEGAL,
            "marketing": IntegrationCategory.MARKETING,
            "payments": IntegrationCategory.PAYMENTS,
            "productivity": IntegrationCategory.PRODUCTIVITY,
            "storage": IntegrationCategory.STORAGE,
            "support": IntegrationCategory.SUPPORT,
            "cms": IntegrationCategory.CMS,
        }.get(value, IntegrationCategory.COMMUNICATION)

    def _build_zoho_integrations(self) -> dict[str, IntegrationDefinition]:
        return {
            product.display_name: IntegrationDefinition(
                name=product.display_name,
                category=self._zoho_category(product.category),
                auth_type=AuthType(str(product.auth_type)),
                description=product.description,
                capabilities=list(product.catalog_capabilities or product.capabilities),
                metadata=product.to_metadata(),
            )
            for product in list_zoho_catalog_products()
        }

    def list_available(self) -> list[IntegrationDefinition]:
        return [i for i in self._integrations.values() if i.is_available]

    def get_integration(self, name: str) -> IntegrationDefinition | None:
        if not name:
            return None
        return self._integrations.get(name)

    def list_by_category(self, category: IntegrationCategory) -> list[IntegrationDefinition]:
        return [i for i in self.list_available() if i.category == category]

    def list_by_auth_type(self, auth_type: AuthType) -> list[IntegrationDefinition]:
        return [i for i in self.list_available() if i.auth_type == auth_type]

    def search_capabilities(self, capability: str) -> list[IntegrationDefinition]:
        normalized = capability.strip().lower()
        return [i for i in self.list_available() if any(c.lower() == normalized for c in i.capabilities)]

    def validate_integration_config(self, name: str, config: dict[str, str]) -> bool:
        integration = self.get_integration(name)
        if integration is None:
            return False
        if not integration.config_required:
            return True

        required_by_auth = {
            AuthType.OAUTH2: {"client_id", "client_secret"},
            AuthType.API_KEY: {"api_key"},
            AuthType.BASIC_AUTH: {"username", "password"},
            AuthType.BEARER_TOKEN: {"token"},
            AuthType.WEBHOOK: {"webhook_url"},
        }
        required = required_by_auth.get(integration.auth_type, set())
        return all(config.get(k) for k in required)

    def get_integration_summary(self) -> dict[str, int]:
        counts: dict[str, int] = {"total": len(self.list_available())}
        for category in IntegrationCategory:
            counts[category.value] = len(self.list_by_category(category))
        return counts


_registry: IntegrationsRegistry | None = None


def get_integrations_registry() -> IntegrationsRegistry:
    global _registry
    if _registry is None:
        _registry = IntegrationsRegistry()
        logger.info("Initialized integrations catalog")
    return _registry
