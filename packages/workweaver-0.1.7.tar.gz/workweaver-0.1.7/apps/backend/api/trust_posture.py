"""Unified Trust Posture API.

Read-only aggregation endpoint returning the complete security state of
an agent across all 6 trust services: ExecutionGuard, QuotaEnforcement,
CredentialVault, ApprovalService, GovernedSwarmService, InterruptControl.

Routes:
    GET /api/v1/runtime/trust-posture/{agent_id} — Get full trust posture

Legacy requirement reference: TODOS.md — Unified Trust Posture API (P2)
"""

from __future__ import annotations

import logging
from datetime import datetime, UTC
from typing import Any

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/runtime/trust-posture", tags=["trust-posture"])


class TrustPostureResponse(BaseModel):
    """Aggregated trust posture across all 6 security services."""

    agent_id: str
    tenant_id: str

    # Service 1: ExecutionGuard
    automation_level: str = "ask_to_execute"
    behavioral_stops: dict[str, Any] = Field(default_factory=dict)

    # Service 2: QuotaEnforcement
    quota_summary: dict[str, Any] = Field(default_factory=dict)

    # Service 3: CredentialVault (count only, never values)
    credential_ref_count: int = 0

    # Service 4: ApprovalService
    pending_approval_count: int = 0
    pending_approvals: list[dict[str, Any]] = Field(default_factory=list)

    # Service 5: GovernedSwarmService (active leases)
    active_lease_count: int = 0
    active_leases: list[dict[str, Any]] = Field(default_factory=list)
    total_budget_used_usd: float = 0.0
    total_budget_approved_usd: float = 0.0

    # Service 6: InterruptControl
    session_state: str | None = None
    has_active_override: bool = False

    # Metadata
    evaluated_at: str = ""


def _get_behavioral_stops(tenant_id: str) -> dict[str, Any]:
    """Read behavioral stops for tenant (safe fallback on error)."""
    try:
        from apps.backend.services.behavioral_stops_store import _get_stops

        stops = _get_stops(tenant_id)
        return dict(stops) if stops else {}
    except Exception:
        logger.debug("behavioral_stops unavailable for %s", tenant_id)
        return {}


def _get_quota_summary(tenant_id: str) -> dict[str, Any]:
    """Read quota usage summary for tenant (safe fallback on error)."""
    try:
        from apps.backend.services.billing_entitlement_resolver import BillingEntitlementResolver
        from apps.backend.services.usage_tracker import UsageTrackerService

        resolver = BillingEntitlementResolver()
        tracker = UsageTrackerService()
        now = datetime.now(UTC)
        usage = tracker.get_usage_summary(tenant_id, now.year, now.month)
        if not usage:
            return {}
        snapshot = resolver.resolve(tenant_id)
        summary: dict[str, Any] = {}
        for metric_name, current_qty in usage.items():
            status = resolver.metric_status(tenant_id, metric_name, snapshot=snapshot, usage_summary=usage)
            if status:
                summary[metric_name] = {
                    "current": float(current_qty),
                    "limit": float(status.hard_limit) if status.hard_limit else None,
                    "blocked": status.is_blocked,
                }
        return summary
    except Exception:
        logger.debug("quota_summary unavailable for %s", tenant_id)
        return {}


def _get_credential_ref_count(tenant_id: str, agent_id: str) -> int:
    """Count vault references for an agent (never expose values)."""
    try:
        from apps.backend.services.agent_credential_vault import AgentCredentialVault

        vault = AgentCredentialVault()
        refs = vault.list_vault_refs_for_agent(tenant_id=tenant_id, agent_id=agent_id)
        return len(refs) if refs else 0
    except Exception:
        logger.debug("vault refs unavailable for %s/%s", tenant_id, agent_id)
        return 0


def _get_pending_approvals(tenant_id: str) -> tuple[int, list[dict[str, Any]]]:
    """Get pending approval requests for tenant."""
    try:
        from apps.backend.services.approval_service import ApprovalService

        svc = ApprovalService()
        result = svc.list_pending_requests(tenant_id=tenant_id)
        if result and result.success and result.metadata:
            approvals = result.metadata.get("approvals", [])
            items = [
                {
                    "request_id": a.get("request_id", ""),
                    "tool_name": a.get("tool_name", ""),
                    "status": a.get("status", ""),
                }
                for a in approvals
            ]
            return len(items), items
        return 0, []
    except Exception:
        logger.debug("approvals unavailable for %s", tenant_id)
        return 0, []


def _get_active_leases(
    tenant_id: str,
    agent_id: str,
) -> tuple[int, list[dict[str, Any]], float, float]:
    """Get active capability leases for an agent."""
    # Leases are in-memory objects during governed runs, not persisted.
    # Returns empty for now — populated when governed runs are active.
    return 0, [], 0.0, 0.0


def _get_interrupt_state(tenant_id: str) -> tuple[str | None, bool]:
    """Get interrupt state for tenant's latest session."""
    # InterruptStateStore requires a session_id; without active session, defaults.
    return None, False


def _build_trust_posture(
    tenant_id: str,
    agent_id: str,
) -> TrustPostureResponse:
    """Aggregate trust posture from all 6 services.

    All calls are read-only. Failures in any service produce safe
    defaults rather than errors — partial posture is better than no posture.
    """
    stops = _get_behavioral_stops(tenant_id)
    automation_level = stops.pop("automation_level", "ask_to_execute") if stops else "ask_to_execute"
    quota_summary = _get_quota_summary(tenant_id)
    vault_count = _get_credential_ref_count(tenant_id, agent_id)
    approval_count, approvals = _get_pending_approvals(tenant_id)
    lease_count, leases, budget_used, budget_approved = _get_active_leases(tenant_id, agent_id)
    session_state, has_override = _get_interrupt_state(tenant_id)

    return TrustPostureResponse(
        agent_id=agent_id,
        tenant_id=tenant_id,
        automation_level=str(automation_level),
        behavioral_stops=stops,
        quota_summary=quota_summary,
        credential_ref_count=vault_count,
        pending_approval_count=approval_count,
        pending_approvals=approvals,
        active_lease_count=lease_count,
        active_leases=leases,
        total_budget_used_usd=budget_used,
        total_budget_approved_usd=budget_approved,
        session_state=session_state,
        has_active_override=has_override,
        evaluated_at=datetime.now(UTC).isoformat(),
    )


@router.get("/{agent_id}", response_model=TrustPostureResponse)
async def get_trust_posture(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> TrustPostureResponse:
    """Get unified trust posture for an agent.

    Aggregates security state from ExecutionGuard, QuotaEnforcement,
    CredentialVault, ApprovalService, GovernedSwarmService, and
    InterruptControl into a single read-only view.
    """
    return _build_trust_posture(tenant_id=tenant_id, agent_id=agent_id)
