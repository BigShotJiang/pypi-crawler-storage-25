"""KernelSkill REST surface — issue #2788.

Read-only inspection of the §14 ``kernel.*`` skills + on-demand probe
runs. Mutations are forbidden by contract: kernel skills are immutable,
owner=system, and tenants cannot edit, archive, or extend them.

Routes:

* ``GET  /api/v1/kernel/skills`` — list every §14 skill.
* ``GET  /api/v1/kernel/skills/{skill_id}`` — show one skill.
* ``POST /api/v1/kernel/skills/{skill_id}/run`` — probe the skill,
  emitting a read-only Decision Trace via the executor's idempotent
  capture path.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.runtime.kernel_skill_registry import (
    KERNEL_SECTION_14_SKILL_IDS,
    KernelSkillExecutor,
)


__all__ = [
    "KERNEL_SECTION_14_SKILL_IDS",
    "KernelSkillListResponse",
    "KernelSkillRow",
    "KernelSkillRunResponse",
    "get_kernel_skill_executor",
    "list_kernel_skills",
    "reset_kernel_skill_executor_for_testing",
    "router",
    "run_kernel_skill",
    "show_kernel_skill",
]


router = APIRouter(
    prefix="/api/v1/kernel/skills",
    tags=["kernel", "skills"],
)


_executor: KernelSkillExecutor | None = None


def get_kernel_skill_executor() -> KernelSkillExecutor:
    """Return the module-level KernelSkillExecutor singleton."""
    global _executor  # noqa: PLW0603
    if _executor is None:
        _executor = KernelSkillExecutor()
    return _executor


def reset_kernel_skill_executor_for_testing() -> None:
    """Drop the singleton so tests start with a fresh trace cache."""
    global _executor  # noqa: PLW0603
    _executor = None


class KernelSkillRow(BaseModel):
    """A single §14 KernelSkill row."""

    skill_id: str
    name: str
    category: str
    description: str
    immutable: bool = True
    owner: str = "system"
    backed_by: list[str] = Field(default_factory=list)


class KernelSkillListResponse(BaseModel):
    """List of §14 kernel skills."""

    skills: list[KernelSkillRow]
    skill_count: int


class KernelSkillRunResponse(BaseModel):
    """Outcome of a kernel skill probe."""

    tenant_id: str
    skill_id: str
    operation: str
    side_effect_class: str
    idempotency_key: str
    trace_id: str | None
    summary: dict[str, Any] = Field(default_factory=dict)


def _row_from_skill(skill: Any) -> KernelSkillRow:
    return KernelSkillRow(
        skill_id=skill.skill_id,
        name=skill.name,
        category=skill.category.value,
        description=skill.description,
        immutable=skill.immutable,
        owner="system",
        backed_by=list(skill.backed_by),
    )


@router.get("", response_model=KernelSkillListResponse)
def list_kernel_skills(
    tenant_id: str = Depends(get_verified_tenant_id),  # noqa: ARG001 — auth gate
) -> KernelSkillListResponse:
    """List the six §14 KernelSkills."""
    executor = get_kernel_skill_executor()
    skills = [_row_from_skill(skill) for skill in executor.registry.list_section_14()]
    return KernelSkillListResponse(skills=skills, skill_count=len(skills))


@router.get("/{skill_id}", response_model=KernelSkillRow)
def show_kernel_skill(
    skill_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),  # noqa: ARG001 — auth gate
) -> KernelSkillRow:
    """Show one §14 KernelSkill by ID."""
    if skill_id not in KERNEL_SECTION_14_SKILL_IDS:
        raise HTTPException(status_code=404, detail=f"Unknown kernel skill: {skill_id}")
    executor = get_kernel_skill_executor()
    skill = executor.registry.get(skill_id)
    if skill is None:
        raise HTTPException(status_code=404, detail=f"Unknown kernel skill: {skill_id}")
    return _row_from_skill(skill)


@router.post("/{skill_id}/run", response_model=KernelSkillRunResponse)
def run_kernel_skill(
    skill_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> KernelSkillRunResponse:
    """Probe one §14 KernelSkill and emit a read-only Decision Trace."""
    if skill_id not in KERNEL_SECTION_14_SKILL_IDS:
        raise HTTPException(status_code=404, detail=f"Unknown kernel skill: {skill_id}")
    executor = get_kernel_skill_executor()
    try:
        result = executor.run(tenant_id=tenant_id, skill_id=skill_id)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return KernelSkillRunResponse(
        tenant_id=result.tenant_id,
        skill_id=result.skill_id,
        operation=result.operation,
        side_effect_class=result.side_effect_class,
        idempotency_key=result.idempotency_key,
        trace_id=result.trace_id,
        summary=result.summary,
    )
