"""Shared service layer for Public API (M5.1 MCP + M5.2 REST).

Contains the business logic backing both the REST endpoints and MCP tool
dispatch. Each method accepts a tenant_id and operation-specific parameters,
enforces tenant isolation, and delegates to existing backend services.

This module uses in-memory stores for tasks, schedules, approvals, etc.
when DynamoDB is not available (dev/test). In production, these delegate
to the real DynamoDB-backed services.

Reference: docs/CAPABILITIES.md M5.1, M5.2
"""

from __future__ import annotations

import asyncio
import logging
import uuid
from datetime import datetime, UTC
from typing import Any

logger = logging.getLogger(__name__)


class PublicResearchError(RuntimeError):
    """Typed research failure safe to expose through REST and MCP."""

    def __init__(
        self,
        *,
        code: str,
        message: str,
        status_code: int,
        evidence_id: str | None = None,
        retryable: bool = False,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.message = message
        self.status_code = status_code
        self.evidence_id = evidence_id
        self.retryable = retryable

    @classmethod
    def from_research_error(cls, exc: Any) -> "PublicResearchError":
        code = str(getattr(exc, "code", "research_failed") or "research_failed")
        status_code = {
            "operation_not_allowed": 403,
            "quota_exceeded": 429,
            "worker_cancelled": 409,
            "provider_unavailable": 503,
        }.get(code, 503)
        return cls(
            code=code,
            message=str(exc),
            status_code=status_code,
            evidence_id=getattr(exc, "evidence_id", None),
            retryable=code == "provider_unavailable",
        )

    def to_dict(self) -> dict[str, Any]:
        return {
            "code": self.code,
            "message": self.message,
            "evidence_id": self.evidence_id,
            "retryable": self.retryable,
        }


def _swarm_public_status(state: str) -> str:
    return {
        "pending": "admitted",
        "running": "running",
        "completed": "completed",
        "failed": "failed",
        "cancelled": "cancelled",
    }.get(state, state)


def _swarm_execution_payload(execution: Any) -> dict[str, Any]:
    from apps.backend.utils.tenant import strip_tenant_prefix

    status_value = _swarm_public_status(str(getattr(execution, "state", "")))
    current_step = int(getattr(execution, "current_step", 0) or 0)
    total_steps = int(getattr(execution, "total_steps", 0) or 0)
    if status_value == "completed" and total_steps:
        current_step = total_steps
    return {
        "execution_id": getattr(execution, "execution_id", ""),
        "tenant_id": strip_tenant_prefix(str(getattr(execution, "tenant_id", ""))),
        "plan_id": getattr(execution, "plan_id", None),
        "status": status_value,
        "current_step": current_step,
        "total_steps": total_steps,
        "steps": list(getattr(execution, "steps", []) or []),
        "tool_leases": list(getattr(execution, "tool_leases", []) or []),
        "loss_score_actual": getattr(execution, "loss_score_actual", None),
        "loss_score_expected": getattr(execution, "loss_score_expected", None),
        "created_at": getattr(execution, "created_at", None) or getattr(execution, "started_at", None),
        "updated_at": (
            getattr(execution, "updated_at", None)
            or getattr(execution, "completed_at", None)
            or getattr(execution, "started_at", None)
        ),
        "goal": getattr(execution, "goal", None),
        "calendar_group": getattr(execution, "calendar_group", None),
        "cancel_reason": getattr(execution, "cancel_reason", None),
    }


def _as_plain_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return dict(value)
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    raise ValueError("Expected a structured response object")


def _parse_swarm_spawn_budget(raw: Any) -> dict[str, Any]:
    if raw in (None, ""):
        return {}
    if isinstance(raw, dict):
        parsed: dict[str, Any] = {}
        for key, value in raw.items():
            normalized_key = "wall_seconds" if key == "wall" else str(key)
            if normalized_key not in {"tokens", "dollars", "wall_seconds", "steps"}:
                raise ValueError(f"Unsupported budget axis: {key}")
            parsed[normalized_key] = value
        return parsed

    parsed: dict[str, Any] = {}
    seen: set[str] = set()
    for part in str(raw).split(","):
        item = part.strip()
        if not item or "=" not in item:
            raise ValueError("Malformed budget; expected tokens=N,dollars=N,wall=Ns,steps=N")
        key, value = (piece.strip() for piece in item.split("=", 1))
        if key in seen:
            raise ValueError(f"Duplicate budget axis: {key}")
        seen.add(key)
        if key == "tokens":
            parsed[key] = _positive_int(value, "tokens")
        elif key == "dollars":
            parsed[key] = _positive_float(value, "dollars")
        elif key == "wall":
            if not value.endswith("s"):
                raise ValueError("Budget wall axis must use seconds, for example wall=300s")
            parsed["wall_seconds"] = _positive_int(value[:-1], "wall")
        elif key == "steps":
            parsed[key] = _positive_int(value, "steps")
        else:
            raise ValueError(f"Unsupported budget axis: {key}")
    return parsed


def _positive_int(raw: Any, label: str) -> int:
    try:
        value = int(raw)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must be a positive integer") from exc
    if value <= 0:
        raise ValueError(f"{label} must be greater than zero")
    return value


def _positive_float(raw: Any, label: str) -> float:
    try:
        value = float(raw)
    except (TypeError, ValueError) as exc:
        raise ValueError(f"{label} must be a positive number") from exc
    if value <= 0:
        raise ValueError(f"{label} must be greater than zero")
    return value


def _swarm_spawn_auto_approve_tiers(raw: Any) -> set[str]:
    tiers = {item.strip().lower() for item in str(raw or "low,medium").split(",") if item.strip()}
    if not tiers:
        raise ValueError("auto_approve_tier cannot be empty")
    unknown = tiers - {"low", "medium", "high", "critical"}
    if unknown:
        raise ValueError(f"Unsupported auto-approve tier(s): {', '.join(sorted(unknown))}")
    forbidden = tiers & {"high", "critical"}
    if forbidden:
        raise ValueError("High and critical plans require explicit approval and cannot be auto-approved")
    return tiers


def _swarm_spawn_plan_mode(raw: Any) -> str | None:
    text = str(raw or "").strip().lower().replace("-", "_")
    if not text:
        return None
    if text == "emergent":
        return "self_organizing_emergent"
    if text not in {"self_organizing_emergent", "rigid"}:
        raise ValueError("plan_mode must be emergent or rigid")
    return text


def _swarm_plan_sensitivity(plan: dict[str, Any]) -> str:
    tier = str(plan.get("sensitivity") or "").strip().lower()
    if tier not in {"low", "medium", "high", "critical"}:
        raise ValueError("Plan response did not include a recognized sensitivity tier; refusing to auto-execute")
    return tier


def _swarm_plan_gate_flags(plan: dict[str, Any]) -> dict[str, Any]:
    gate_flags = plan.get("gate_flags")
    if not isinstance(gate_flags, dict):
        raise ValueError("Plan response did not include gate flags; refusing to auto-execute")
    return gate_flags


def _enforce_swarm_spawn_plan_budget(plan: dict[str, Any], budget: dict[str, Any]) -> None:
    steps = [item for item in plan.get("steps") or [] if isinstance(item, dict)]
    max_steps = budget.get("steps")
    if max_steps is not None and len(steps) > int(max_steps):
        raise ValueError(f"Plan has {len(steps)} steps, exceeding budget steps={max_steps}")
    wall_seconds = budget.get("wall_seconds")
    if wall_seconds is not None:
        estimated = sum(int(step.get("estimated_duration_seconds") or 0) for step in steps)
        if estimated > int(wall_seconds):
            raise ValueError(f"Plan estimates {estimated}s, exceeding budget wall={wall_seconds}s")


def _ensure_swarm_spawn_can_execute(tier: str, gate_flags: dict[str, Any], allowed_tiers: set[str]) -> None:
    if tier in {"high", "critical"} or bool(gate_flags.get("requires_explicit_approval")):
        raise ValueError(f"Refusing to auto-execute {tier}-tier swarm plan; explicit approval is required")
    if tier not in allowed_tiers:
        raise ValueError(f"Plan sensitivity is {tier}, outside auto-approved tiers: {', '.join(sorted(allowed_tiers))}")


def _entity_schema_json_type(field_type: str) -> str:
    return {
        "string": "string",
        "integer": "integer",
        "number": "number",
        "boolean": "boolean",
        "date": "string",
        "datetime": "string",
        "json": "object",
    }.get(field_type, "string")


async def _wait_for_zara_execution(
    *,
    tenant_id: str,
    execution_id: str,
    poll_interval_seconds: float,
    wait_timeout_seconds: float,
) -> dict[str, Any]:
    if poll_interval_seconds <= 0:
        raise ValueError("poll_interval_seconds must be greater than zero")
    if wait_timeout_seconds <= 0:
        raise ValueError("wait_timeout_seconds must be greater than zero")
    from apps.backend.services.zara.plan_store import get_zara_plan_store

    store = get_zara_plan_store()
    terminal = {"completed", "failed", "cancelled"}
    loop = asyncio.get_running_loop()
    deadline = loop.time() + wait_timeout_seconds
    while True:
        record = store.get_execution(tenant_id, execution_id)
        if not record:
            raise ValueError(f"Execution not found: {execution_id}")
        status = str(record.get("status") or "").strip().lower()
        if status in terminal:
            return record
        if loop.time() >= deadline:
            raise ValueError(f"Timed out waiting for execution {execution_id}; last status was {status or 'unknown'}")
        await asyncio.sleep(poll_interval_seconds)


def _verified_context_role(role: Any | None):
    from apps.backend.models.user import UserRole

    if isinstance(role, UserRole):
        return role
    if str(role or "").strip().lower() in {"admin", "owner"}:
        return UserRole.ADMIN
    return UserRole.AGENT


def _verified_context_actor(actor_id: str | None) -> str:
    actor = str(actor_id or "").strip()
    if not actor:
        raise PermissionError("verified_actor_required")
    return actor


class PublicApiService:
    """Shared service for public API operations.

    All methods are tenant-scoped: they receive tenant_id and only
    operate on that tenant's data.
    """

    def __init__(self) -> None:
        # In-memory stores for dev/test. Production uses DynamoDB via
        # existing services (lazy-imported to avoid import-time boto3 failures).
        self._tasks: dict[str, dict[str, Any]] = {}
        self._schedules: dict[str, dict[str, Any]] = {}

    # ------------------------------------------------------------------
    # Tasks
    # ------------------------------------------------------------------

    async def create_task(
        self,
        *,
        tenant_id: str,
        title: str,
        description: str = "",
        assigned_agent: str | None = None,
        priority: str = "medium",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Create a new task for the tenant."""
        # Public API IDs use URL-safe format (no '#' which is a URL fragment delimiter)
        task_id = f"task_{uuid.uuid4().hex[:12]}"
        now = datetime.now(UTC).isoformat()
        task = {
            "task_id": task_id,
            "tenant_id": tenant_id,
            "title": title,
            "description": description,
            "assigned_agent": assigned_agent,
            "priority": priority,
            "status": "backlog",
            "created_at": now,
            "updated_at": now,
        }
        self._tasks[task_id] = task
        logger.info("Public API: created task %s for tenant %s", task_id, tenant_id)
        return task

    async def get_task_status(
        self,
        *,
        tenant_id: str,
        task_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Get the status of a task. Raises KeyError if not found."""
        task = self._tasks.get(task_id)
        if not task or task.get("tenant_id") != tenant_id:
            raise KeyError(f"Task not found: {task_id}")
        return task

    async def evidence_trace(
        self,
        *,
        tenant_id: str,
        task_id: str | None = None,
        workitem_id: str | None = None,
        goal_id: str | None = None,
        subject_id: str | None = None,
        subject_type: str | None = None,
        limit: int = 50,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Return the hydrated task/goal Decision Trace contract used by MCP."""
        del kwargs
        target_id = subject_id or task_id or workitem_id or goal_id
        from apps.backend.api import evidence as evidence_api

        trace = evidence_api._build_hydrated_decision_trace(
            tenant_id=tenant_id,
            subject_id=target_id,
            subject_type=subject_type or ("goal" if goal_id else None),
            limit=limit,
        )
        return trace.model_dump(mode="json")

    async def ontology_query(
        self,
        *,
        tenant_id: str,
        q: str = "",
        kind: str | None = None,
        limit: int = 50,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Query the tenant ontology graph through the shared public API layer."""
        del kwargs
        from apps.backend.extensions.ontology.primitive_ontology import PrimitiveKind
        from apps.backend.services.ontology_query import query_tenant_ontology_nodes

        try:
            primitive_kind = PrimitiveKind(kind) if kind else None
        except ValueError as exc:
            allowed = ", ".join(item.value for item in PrimitiveKind)
            raise ValueError(f"Unsupported ontology kind: {kind}. Expected one of: {allowed}") from exc
        response = query_tenant_ontology_nodes(tenant_id=tenant_id, q=q, kind=primitive_kind, limit=limit)
        return response.model_dump(mode="json")

    async def entity_schema_create(
        self,
        *,
        tenant_id: str,
        name: str,
        fields: list[dict[str, Any]],
        relationships: list[dict[str, Any]] | None = None,
        dcl: str,
        owner: str,
        created_by: str,
        description: str = "",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Create a draft tenant entity schema."""
        del kwargs
        from apps.backend.models.entity_schema import EntitySchemaDraftRequest
        from apps.backend.services.entity_schema_registry import get_entity_schema_registry

        request = EntitySchemaDraftRequest.model_validate(
            {
                "name": name,
                "fields": fields,
                "relationships": relationships or [],
                "dcl": dcl,
                "owner": owner,
                "created_by": created_by,
                "description": description,
            }
        )
        return get_entity_schema_registry().create_draft(tenant_id, request).model_dump(mode="json")

    async def entity_schema_list(
        self,
        *,
        tenant_id: str,
        status: str | None = None,
        limit: int = 100,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List tenant entity schemas."""
        del kwargs
        from apps.backend.services.entity_schema_registry import get_entity_schema_registry

        schemas = get_entity_schema_registry().list_schemas(tenant_id, status=status, limit=limit)
        return {
            "tenant_id": tenant_id,
            "schemas": [schema.model_dump(mode="json") for schema in schemas],
            "count": len(schemas),
        }

    async def entity_schema_get(
        self,
        *,
        tenant_id: str,
        name: str,
        version: int | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Get one tenant entity schema."""
        del kwargs
        from apps.backend.services.entity_schema_registry import get_entity_schema_registry

        schema = get_entity_schema_registry().get_schema(tenant_id, name, version)
        if schema is None:
            raise KeyError(f"Entity schema not found: {name}")
        return schema.model_dump(mode="json")

    async def entity_schema_activate(
        self,
        *,
        tenant_id: str,
        name: str,
        version: int,
        actor_id: str = "mcp",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Activate a draft tenant entity schema."""
        del kwargs
        from apps.backend.services.entity_schema_registry import get_entity_schema_registry

        return (
            get_entity_schema_registry()
            .activate_schema(
                tenant_id,
                name,
                int(version),
                actor_id=actor_id,
            )
            .model_dump(mode="json")
        )

    async def entity_record_create(
        self,
        *,
        tenant_id: str,
        schema_name: str,
        fields: dict[str, Any] | None = None,
        evidence_ids: list[str] | None = None,
        decision_id: str | None = None,
        evidence_null_reason: str | None = None,
        decision_null_reason: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Create a tenant entity record through the latest active schema."""
        del kwargs
        from apps.backend.services.entity_instance_service import (
            EntityRecordWriteRequest,
            get_entity_instance_service,
        )

        request = EntityRecordWriteRequest(
            fields=dict(fields or {}),
            evidence_ids=list(evidence_ids or []),
            decision_id=decision_id,
            evidence_null_reason=evidence_null_reason,
            decision_null_reason=decision_null_reason,
        )
        return get_entity_instance_service().create_record(tenant_id, schema_name, request).model_dump(mode="json")

    async def entity_record_get(
        self,
        *,
        tenant_id: str,
        schema_name: str,
        record_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Read a tenant entity record through the latest active schema."""
        del kwargs
        from apps.backend.services.entity_instance_service import get_entity_instance_service

        return get_entity_instance_service().get_record(tenant_id, schema_name, record_id).model_dump(mode="json")

    async def entity_record_list(
        self,
        *,
        tenant_id: str,
        schema_name: str,
        limit: int = 100,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List tenant entity records through the latest active schema."""
        del kwargs
        from apps.backend.services.entity_instance_service import get_entity_instance_service

        return get_entity_instance_service().list_records(tenant_id, schema_name, limit=limit).model_dump(mode="json")

    async def entity_record_update(
        self,
        *,
        tenant_id: str,
        schema_name: str,
        record_id: str,
        fields: dict[str, Any] | None = None,
        evidence_ids: list[str] | None = None,
        decision_id: str | None = None,
        evidence_null_reason: str | None = None,
        decision_null_reason: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Update a tenant entity record through the latest active schema."""
        del kwargs
        from apps.backend.services.entity_instance_service import (
            EntityRecordWriteRequest,
            get_entity_instance_service,
        )

        request = EntityRecordWriteRequest(
            fields=dict(fields or {}),
            evidence_ids=list(evidence_ids or []),
            decision_id=decision_id,
            evidence_null_reason=evidence_null_reason,
            decision_null_reason=decision_null_reason,
        )
        return (
            get_entity_instance_service()
            .update_record(tenant_id, schema_name, record_id, request)
            .model_dump(mode="json")
        )

    async def entity_record_schema(
        self,
        *,
        tenant_id: str,
        schema_name: str,
        operation: str = "create",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Describe allowed fields for entity record create/update tools."""
        del kwargs
        from apps.backend.models.entity_schema import EntitySchemaStatus
        from apps.backend.services.entity_schema_registry import get_entity_schema_registry

        schemas = get_entity_schema_registry().list_schemas(
            tenant_id,
            name=schema_name,
            status=EntitySchemaStatus.ACTIVE,
            limit=500,
        )
        if not schemas:
            raise KeyError(f"Active entity schema not found: {schema_name}")
        schema = max(schemas, key=lambda item: item.version)
        partial = str(operation or "create").strip().lower() == "update"
        field_properties: dict[str, dict[str, Any]] = {}
        required: list[str] = []
        for field in schema.fields:
            field_properties[field.name] = {
                "type": _entity_schema_json_type(str(field.type.value if hasattr(field.type, "value") else field.type)),
                "description": field.description or "",
                "dcl": str(field.dcl.value if hasattr(field.dcl, "value") else field.dcl),
                "required": bool(field.required),
            }
            if field.required and not partial:
                required.append(field.name)
        return {
            "tenant_id": tenant_id,
            "schema_name": schema.name,
            "schema_version": schema.version,
            "operation": "update" if partial else "create",
            "fields_schema": {
                "type": "object",
                "properties": field_properties,
                "required": required,
                "additionalProperties": False,
            },
            "relationships": [relationship.model_dump(mode="json") for relationship in schema.relationships],
        }

    async def entity_conflicts(
        self,
        *,
        tenant_id: str,
        schema_name: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List unresolved local/cloud conflicts for tenant entity records."""
        del kwargs
        from apps.backend.services.entity_sync import get_entity_sync_service

        return get_entity_sync_service().list_conflicts(tenant_id, schema_name).model_dump(mode="json")

    async def entity_conflict_resolve(
        self,
        *,
        tenant_id: str,
        conflict_id: str,
        strategy: str,
        actor_id: str = "mcp",
        resolved_fields: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Explicitly resolve one local/cloud conflict for a tenant entity record."""
        del kwargs
        from apps.backend.models.entity_sync import EntityConflictResolveRequest
        from apps.backend.services.entity_sync import get_entity_sync_service

        request = EntityConflictResolveRequest(
            strategy=strategy,
            actor_id=actor_id,
            resolved_fields=resolved_fields,
        )
        return (
            get_entity_sync_service()
            .resolve_conflict(
                tenant_id=tenant_id,
                conflict_id=conflict_id,
                request=request,
            )
            .model_dump(mode="json")
        )

    async def operational_context_show(
        self,
        *,
        tenant_id: str,
        subject_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Return the REST Operational Context subject response contract."""
        del kwargs
        from apps.backend.services.operational_context_read_model import get_operational_context_read_model_service

        response = await get_operational_context_read_model_service().get_subject(
            tenant_id=tenant_id,
            subject_id=subject_id,
        )
        return _as_plain_dict(response)

    async def operational_context_workspace(
        self,
        *,
        tenant_id: str,
        workspace_id: str,
        actor_id: str = "mcp",
        actor_role: str = "admin",
        verified_actor_id: str | None = None,
        verified_actor_role: Any | None = None,
        member_id: str | None = None,
        kind: str | None = None,
        entity: str | None = None,
        since: str | None = None,
        cursor: str | None = None,
        limit: int = 50,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Return permitted Workspace Operational Context for MCP/public callers."""
        del kwargs
        from apps.backend.services.context_permissions import (
            get_context_permission_service,
            same_workspace,
        )

        if not same_workspace(workspace_id, tenant_id):
            raise PermissionError("workspace_mismatch")
        del actor_id, actor_role
        role = _verified_context_role(verified_actor_role)
        actor = _verified_context_actor(verified_actor_id)
        return get_context_permission_service().query_workspace_context(
            workspace_id=tenant_id,
            actor_id=actor,
            actor_role=role,
            member_id=member_id,
            kind=kind,
            entity=entity,
            since=since,
            cursor=cursor,
            limit=limit,
        )

    async def operational_context_share(
        self,
        *,
        tenant_id: str,
        grant_to: str,
        scope: dict[str, Any],
        expires_at: str,
        rights: list[str],
        actor_id: str = "mcp",
        verified_actor_id: str | None = None,
        verified_actor_role: Any | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Create an Operational Context Permission grant for MCP/public callers."""
        del actor_id, kwargs
        from apps.backend.models.user import UserRole

        if _verified_context_role(verified_actor_role) != UserRole.ADMIN:
            raise PermissionError("admin_required")
        actor = _verified_context_actor(verified_actor_id)
        from apps.backend.services.context_permissions import (
            ContextPermissionScope,
            get_context_permission_service,
        )

        grant = get_context_permission_service().create_grant(
            workspace_id=tenant_id,
            grant_to=grant_to,
            scope=ContextPermissionScope.model_validate(scope or {}),
            expires_at=expires_at,
            rights=rights,
            created_by=actor,
        )
        return grant.model_dump(mode="json")

    async def agent_identity_readiness(
        self,
        *,
        tenant_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Return the shared Zara identity readiness contract."""
        del kwargs
        from apps.backend.services.agent_identity_readiness import (
            get_agent_identity_readiness_service,
        )

        return get_agent_identity_readiness_service().readiness(tenant_id=tenant_id)

    async def agent_identity_status(
        self,
        *,
        tenant_id: str,
        agent_id: str = "zara",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Return per-purpose Zara-owned provider identity status."""
        del kwargs
        from apps.backend.api.agent_identity import (
            PurposeIdentityStatus,
            ZaraIdentityStatus,
            _purpose_name_to_agent_purpose,
        )
        from apps.backend.services.agent_identity_readiness import (
            get_agent_identity_readiness_service,
        )
        from apps.backend.services.agent_scope_registry import (
            get_agent_scope_registry,
        )

        readiness_result = get_agent_identity_readiness_service().readiness(
            tenant_id=tenant_id,
            agent_id=agent_id,
        )
        scope_registry = get_agent_scope_registry()

        purpose_statuses: list[PurposeIdentityStatus] = []
        for item in readiness_result.get("purposes", []):
            purpose_name = str(item.get("purpose", ""))
            agent_purpose = _purpose_name_to_agent_purpose(purpose_name)
            forbidden = list(scope_registry.forbidden_for(agent_purpose)) if agent_purpose else []
            purpose_statuses.append(
                PurposeIdentityStatus(
                    purpose=purpose_name,
                    status=str(item.get("status", "missing")),
                    provider=str(item.get("provider", "")),
                    principal_email=item.get("principal_email"),
                    scopes=list(item.get("granted_scopes") or []),
                    forbidden_scopes=forbidden,
                    missing_reason=item.get("missing_reason"),
                )
            )

        status_obj = ZaraIdentityStatus(
            agent_id=agent_id,
            tenant_id=readiness_result.get("tenant_id", tenant_id),
            purposes=purpose_statuses,
        )
        return status_obj.model_dump()

    # ------------------------------------------------------------------
    # Agents
    # ------------------------------------------------------------------

    async def list_agents(
        self,
        *,
        tenant_id: str,
        status_filter: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List agents for the tenant."""
        # Attempt to use real service; fall back to empty list
        agents: list[dict[str, Any]] = []
        try:
            from apps.backend.services.agent_registry import get_agent_registry

            registry = get_agent_registry()
            agents = registry.list_agents(tenant_id=tenant_id) or []
        except Exception:
            logger.debug("Agent registry unavailable, returning empty list")
        return {
            "tenant_id": tenant_id,
            "agents": agents,
            "count": len(agents),
        }

    async def agent_di(
        self,
        *,
        tenant_id: str,
        agent_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Return the aggregate DI score that gates self-organizing planning."""
        del kwargs
        normalized_agent_id = str(agent_id or "").strip()
        if not normalized_agent_id:
            raise ValueError("ww.agent.di requires agent_id")
        from apps.backend.services.developmental_intelligence import get_developmental_intelligence_service

        return (
            get_developmental_intelligence_service()
            .compute(
                agent_id=normalized_agent_id,
                tenant_id=tenant_id,
            )
            .to_dict()
        )

    async def research_search(
        self,
        *,
        tenant_id: str,
        query: str,
        operation: str = "search",
        max_results: int = 5,
        url: str | None = None,
        workitem_id: str | None = None,
        swarm_execution_id: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Run a bounded tenant-scoped research call."""
        del kwargs
        from apps.backend.services.evidence_ledger import get_evidence_ledger_service
        from apps.backend.services.research_capability import (
            ResearchCapabilityError,
            ResearchToolRequest,
            create_research_lease,
            execute_research,
        )

        try:
            request = ResearchToolRequest(
                query=query,
                operation=operation,  # type: ignore[arg-type]
                max_results=max_results,
                url=url,
                workitem_id=workitem_id,
                swarm_execution_id=swarm_execution_id,
            )
        except ValueError as exc:
            raise PublicResearchError(
                code="invalid_request",
                message=str(exc),
                status_code=422,
                retryable=False,
            ) from exc
        lease = create_research_lease(
            tenant_id=tenant_id,
            max_results=request.max_results,
            workitem_id=workitem_id,
            swarm_execution_id=swarm_execution_id,
        )
        try:
            result = await execute_research(
                request,
                lease=lease,
                evidence_service=get_evidence_ledger_service(),
                actor_path="public_api.research_search",
            )
        except ResearchCapabilityError as exc:
            raise PublicResearchError.from_research_error(exc) from exc
        return result.model_dump(mode="json")

    # ─── Issue #3227: admin permissions surfaces ──────────────────────

    async def admin_permissions_list(
        self,
        *,
        tenant_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List admin role assignments + role catalog. Mirrors GET
        /api/v1/admin/permissions. Tenant arg accepted for parity with
        other PublicApiService dispatchers; the underlying surface is
        platform-scoped."""
        del kwargs, tenant_id
        from apps.backend.services.admin.admin_permission import (
            AdminRole,
            get_role_permissions,
        )
        from apps.backend.services.admin.admin_role_store import (
            get_admin_role_store,
        )

        store = get_admin_role_store()
        assignments = []
        for assignment in store.list_roles():
            assignments.append({
                "email": assignment.email,
                "role": assignment.role.value,
                "assigned_by": assignment.assigned_by,
                "assigned_at": assignment.assigned_at,
                "notes": assignment.notes,
                "permissions": sorted(
                    p.value for p in get_role_permissions(assignment.role)
                ),
            })
        roles = {
            role.value: sorted(p.value for p in get_role_permissions(role))
            for role in AdminRole
        }
        return {"assignments": assignments, "roles": roles}

    async def admin_permissions_grant(
        self,
        *,
        tenant_id: str,
        email: str,
        role: str,
        notes: str = "",
        actor_email: str = "system",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Grant an admin role to a user."""
        del kwargs, tenant_id
        from apps.backend.services.admin.admin_permission import (
            AdminRole,
            get_role_permissions,
        )
        from apps.backend.services.admin.admin_role_store import (
            get_admin_role_store,
        )

        try:
            target_role = AdminRole(role)
        except ValueError as exc:
            valid = ", ".join(r.value for r in AdminRole)
            raise ValueError(
                f"Unknown role {role!r}. Valid roles: {valid}"
            ) from exc

        assignment = get_admin_role_store().set_role(
            email,
            target_role,
            assigned_by=actor_email,
            notes=notes,
        )
        return {
            "email": assignment.email,
            "role": assignment.role.value,
            "assigned_by": assignment.assigned_by,
            "assigned_at": assignment.assigned_at,
            "notes": assignment.notes,
            "permissions": sorted(
                p.value for p in get_role_permissions(target_role)
            ),
        }

    async def admin_permissions_revoke(
        self,
        *,
        tenant_id: str,
        email: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Revoke a user's admin role assignment."""
        del kwargs, tenant_id
        from apps.backend.services.admin.admin_role_store import (
            get_admin_role_store,
        )

        revoked = get_admin_role_store().remove_role(email)
        return {"email": email, "revoked": bool(revoked)}

    async def browser_run(
        self,
        *,
        tenant_id: str,
        task: str,
        start_url: str | None = None,
        url: str | None = None,
        mode: str = "deterministic",
        work_item_id: str | None = None,
        timeblock_id: str | None = None,
        allowed_url_patterns: list[str] | None = None,
        public_read_only_default: bool = False,
        side_effecting: bool = False,
        downloads_allowed: bool = False,
        artifact_temp_dir: str | None = None,
        steps: list[dict[str, Any]] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        del kwargs
        from apps.backend.services.browser_policy import BrowserTaskMode
        from apps.backend.services.browser_workbench import (
            BrowserWorkbenchContext,
            BrowserWorkbenchRequest,
            get_browser_workbench_service,
        )

        target_url = str(start_url or url or "").strip()
        if not target_url:
            raise ValueError("browser_run requires start_url")
        request = BrowserWorkbenchRequest(
            task=task,
            start_url=target_url,
            mode=BrowserTaskMode(mode),
            work_item_id=work_item_id,
            timeblock_id=timeblock_id,
            allowed_url_patterns=list(allowed_url_patterns or []),
            public_read_only_default=public_read_only_default,
            side_effecting=side_effecting,
            downloads_allowed=downloads_allowed,
            artifact_temp_dir=artifact_temp_dir,
            steps=steps,
        )
        result = await get_browser_workbench_service().run(
            request,
            context=BrowserWorkbenchContext(tenant_id=tenant_id, workspace_id=tenant_id),
        )
        return result.model_dump(mode="json")

    async def browser_sandbox_evaluate(
        self,
        *,
        tenant_id: str,
        url: str,
        task_mode: str = "deterministic",
        side_effecting: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Evaluate a URL against the browser sandbox policy via the public API.

        Returns an allow/deny verdict without executing any browser action.
        """
        del kwargs
        from apps.backend.api.browser_workbench import _resolve_tenant_policy
        from apps.backend.services.browser_policy import BrowserTaskMode

        import uuid as _uuid

        policy = _resolve_tenant_policy(tenant_id=tenant_id)
        decision = policy.evaluate(
            url,
            task_mode=BrowserTaskMode(task_mode),
            side_effecting=side_effecting,
        )
        trace_id = f"trace_sandbox_eval_{_uuid.uuid4().hex[:12]}"
        return {
            "verdict": decision.verdict.value,
            "url": decision.url,
            "reason": decision.reason,
            "matched_allow_entry": decision.matched_allow_entry,
            "decision_trace_id": trace_id,
        }

    async def browser_sandbox_policy(
        self,
        *,
        tenant_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Read the current browser sandbox policy for the tenant."""
        del kwargs
        from apps.backend.api.browser_workbench import _resolve_tenant_policy

        policy = _resolve_tenant_policy(tenant_id=tenant_id)
        return {
            "allowlist": list(policy.allowlist),
            "read_only_public_web": policy.read_only_public_web,
            "artifact_temp_dir_configured": bool(policy.artifact_temp_dir),
            "workspace_id": policy.workspace_id,
        }

    async def admin_inference_audit_grid(
        self,
        *,
        tenant_id: str,
        purpose: str = "",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Return the per-Purpose x per-provider audit grid for the caller's tenant.

        Read-only audit projection: rows are Purpose enum values, columns are
        enabled providers, cells contain cost_per_m_tokens, latency_p50/p95,
        jurisdiction, call_count. The MCP surface scopes data to the caller's
        ``tenant_id``; platform-wide aggregation remains gated to the founder
        REST/CLI/admin-MCP path. Optional ``purpose`` filter narrows rows.

        Reuses ``apps.backend.api.admin_inference.build_audit_grid`` so REST,
        CLI, and MCP surfaces project the same canonical view.

        Reference: GitHub issue #3215.
        """
        del kwargs
        from apps.backend.api.admin_inference import build_audit_grid
        from apps.backend.services.inference.admin_resolver import AdminInferenceResolver

        resolver = AdminInferenceResolver()
        return build_audit_grid(
            resolver=resolver,
            tenant_id=tenant_id or "",
            purpose=purpose or "",
        )

    # ─── Issue #3224: jurisdiction policy MCP surfaces ──────────────────

    async def admin_jurisdiction_policy_show(
        self,
        *,
        tenant_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Read the current jurisdiction blocklist policy.

        Mirrors GET /api/v1/founder/inference/jurisdiction-policy.
        """
        del kwargs, tenant_id
        from apps.backend.services.inference.admin_store import get_admin_inference_store

        store = get_admin_inference_store()
        blocked = store.get_blocked_providers()
        return {
            "blocked_providers": [
                {
                    "provider_id": pid,
                    "reason": store.get_blocked_provider_reason(pid) or "",
                }
                for pid in sorted(blocked)
            ],
            "default_block_reason": "Provider is blocked by jurisdiction/provenance policy.",
        }

    async def admin_jurisdiction_policy_set(
        self,
        *,
        tenant_id: str,
        providers: dict[str, str],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Replace the jurisdiction blocklist with a new set of blocked providers.

        Mirrors PUT /api/v1/founder/inference/jurisdiction-policy.
        """
        del kwargs, tenant_id
        from apps.backend.services.inference.admin_store import get_admin_inference_store
        from apps.backend.services.inference.admin_resolver import get_cached_resolver

        store = get_admin_inference_store()
        new_set = store.set_blocked_providers(providers)
        get_cached_resolver().invalidate()
        return {
            "blocked_providers": [
                {
                    "provider_id": pid,
                    "reason": store.get_blocked_provider_reason(pid) or providers.get(pid, ""),
                }
                for pid in sorted(new_set)
            ],
            "default_block_reason": "Provider is blocked by jurisdiction/provenance policy.",
        }

    # ─── Issue #3209: embedding policy MCP surfaces ─────────────────────

    async def admin_embedding_policy_show(
        self,
        *,
        tenant_id: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Read the embedding policy.

        Provide ``tenant_id`` to show one tenant's effective policy; omit it (or
        pass an empty string) to list every policy.  Mirrors
        GET /api/v1/founder/embedding/policy[/{tenant_id}].
        """
        del kwargs
        from apps.backend.services.inference.admin_embedding_policy_store import (
            get_admin_embedding_policy_store,
        )
        from apps.backend.workmemory.models.tenant_embedding_policy import (
            SUPPORTED_PROVIDERS,
            TenantEmbeddingPolicy,
        )

        store = get_admin_embedding_policy_store()
        target = (tenant_id or "").strip()
        if target and target != "__platform__":
            policy = store.get_policy(target)
            return {
                "tenant_id": policy.tenant_id,
                "mode": policy.mode,
                "per_purpose_overrides": dict(policy.per_purpose_overrides),
            }
        policies = store.list_policies()
        if not any(p.tenant_id == "__platform__" for p in policies):
            policies = [TenantEmbeddingPolicy(tenant_id="__platform__"), *policies]
        return {
            "policies": [
                {
                    "tenant_id": p.tenant_id,
                    "mode": p.mode,
                    "per_purpose_overrides": dict(p.per_purpose_overrides),
                }
                for p in policies
            ],
            "supported_providers": sorted(SUPPORTED_PROVIDERS),
        }

    async def admin_embedding_policy_set(
        self,
        *,
        tenant_id: str,
        mode: str = "aws_only",
        per_purpose_overrides: dict[str, str] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Upsert the embedding policy for one tenant or the platform default.

        Mirrors PUT /api/v1/founder/embedding/policy/{tenant_id}.
        """
        del kwargs
        from apps.backend.services.inference.admin_embedding_policy_store import (
            get_admin_embedding_policy_store,
        )
        from apps.backend.workmemory.models.tenant_embedding_policy import (
            TenantEmbeddingPolicy,
        )

        store = get_admin_embedding_policy_store()
        target = (tenant_id or "").strip() or "__platform__"
        policy = TenantEmbeddingPolicy(
            tenant_id=target,
            mode=mode,  # type: ignore[arg-type]
            per_purpose_overrides=per_purpose_overrides or {},
        )
        persisted = store.set_policy(policy)
        return {
            "tenant_id": persisted.tenant_id,
            "mode": persisted.mode,
            "per_purpose_overrides": dict(persisted.per_purpose_overrides),
        }

    # ─── Issue #3508: manifest-driven inference MCP family ─────────────
    #
    # The handlers below proxy each ``ww.inference.*`` / ``ww.admin.inference.*``
    # MCP tool through the in-process ASGI app so REST and MCP share the
    # exact same FastAPI handler — no behavior duplication. Each method
    # corresponds to one entry in
    # ``apps/cli/ww/commands/inference_manifest.yaml``; the parity test in
    # ``tests/contracts/test_inference_surface_parity.py`` verifies a
    # 1:1 mapping (CLI op ↔ MCP tool ↔ API endpoint).

    async def _inference_proxy(
        self,
        *,
        tenant_id: str,
        op_name: str,
        parameters: dict[str, Any] | None = None,
    ) -> dict[str, Any]:
        from httpx import AsyncClient, ASGITransport

        from apps.backend.api.inference_mcp_tools import manifest_operations
        from apps.backend.main import app

        ops = {str(op["name"]): op for op in manifest_operations()}
        op = ops.get(op_name)
        if op is None:
            raise ValueError(f"unknown inference manifest op: {op_name}")

        method = str(op.get("http_method") or "GET").upper()
        path_template = str(op.get("path") or "")
        path_substitutions: dict[str, Any] = {}
        query_params: dict[str, Any] = {}
        body: dict[str, Any] = {}
        for param in op.get("params") or []:
            name = str(param["name"])
            location = str(param.get("in") or "query")
            if parameters is None or name not in parameters:
                continue
            value = parameters[name]
            if value in (None, ""):
                continue
            if location == "path":
                path_substitutions[name] = value
            elif location == "query":
                query_params[name] = value
            elif location == "body":
                body[name] = value

        try:
            path = path_template.format(**path_substitutions)
        except KeyError as exc:
            raise ValueError(f"{op_name}: missing path placeholder {exc}") from None

        headers = {"x-tenant-id": tenant_id, "x-user-id": tenant_id}
        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://inference-mcp",
        ) as client:
            if method == "GET":
                resp = await client.get(path, params=query_params, headers=headers)
            elif method == "DELETE":
                resp = await client.delete(path, params=query_params, headers=headers)
            elif method == "POST":
                resp = await client.post(path, json=body or None, params=query_params, headers=headers)
            elif method == "PUT":
                resp = await client.put(path, json=body or None, params=query_params, headers=headers)
            else:
                raise ValueError(f"{op_name}: unsupported HTTP method {method}")
            try:
                payload = resp.json()
            except ValueError:
                payload = {"status": resp.status_code, "text": resp.text}
            if isinstance(payload, list):
                payload = {"items": payload}
            if isinstance(payload, dict):
                payload.setdefault("_status_code", resp.status_code)
            return payload  # type: ignore[return-value]

    # — Tenant scope —

    async def inference_provider_add(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="provider.add",
            parameters=kwargs,
        )

    async def inference_provider_update(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="provider.update",
            parameters=kwargs,
        )

    async def inference_provider_list(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="provider.list",
            parameters=kwargs,
        )

    async def inference_provider_get(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="provider.get",
            parameters=kwargs,
        )

    async def inference_provider_test(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="provider.test",
            parameters=kwargs,
        )

    async def inference_provider_disable(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="provider.disable",
            parameters=kwargs,
        )

    async def inference_provider_enable(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="provider.enable",
            parameters=kwargs,
        )

    async def inference_provider_retire(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="provider.retire",
            parameters=kwargs,
        )

    async def inference_provider_delete(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="provider.delete",
            parameters=kwargs,
        )

    async def inference_provider_rotate_credentials(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="provider.rotate_credentials",
            parameters=kwargs,
        )

    async def inference_provider_profile_add(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="provider.profile.add",
            parameters=kwargs,
        )

    async def inference_provider_profile_update(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="provider.profile.update",
            parameters=kwargs,
        )

    async def inference_provider_profile_delete(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="provider.profile.delete",
            parameters=kwargs,
        )

    async def inference_provider_profile_list(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="provider.profile.list",
            parameters=kwargs,
        )

    async def inference_oauth_start(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="oauth.start",
            parameters=kwargs,
        )

    async def inference_oauth_complete(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="oauth.complete",
            parameters=kwargs,
        )

    async def inference_oauth_refresh(self, **kwargs: Any) -> dict[str, Any]:
        """Issue #3513 — generic refresh dispatch (provider in path)."""
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="oauth.refresh",
            parameters=kwargs,
        )

    async def inference_oauth_status(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="oauth.status",
            parameters=kwargs,
        )

    async def inference_oauth_disconnect(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="oauth.disconnect",
            parameters=kwargs,
        )

    async def inference_model_list(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="model.list",
            parameters=kwargs,
        )

    async def inference_model_discover(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="model.discover",
            parameters=kwargs,
        )

    async def inference_routing_get(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="routing.get",
            parameters=kwargs,
        )

    async def inference_routing_set(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="routing.set",
            parameters=kwargs,
        )

    async def inference_routing_fallback_set(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="routing.fallback_set",
            parameters=kwargs,
        )

    async def inference_routing_fallback_audit_event(self, **kwargs: Any) -> dict[str, Any]:
        # Issue #3512: read recent fallback-chain audit events distinct from
        # primary inference calls. The op flows through the same inference
        # proxy as routing.get/set so transport, auth, and audit semantics
        # stay consistent across the routing op family.
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="routing.fallback_audit_event",
            parameters=kwargs,
        )

    async def inference_routing_tenant_override_get(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="routing.tenant_override_get",
            parameters=kwargs,
        )

    async def inference_routing_tenant_override_set(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="routing.tenant_override_set",
            parameters=kwargs,
        )

    async def inference_status(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="status",
            parameters=kwargs,
        )

    # — Provider plugin management (Issue #3589) ——

    async def inference_plugin_list(self, **kwargs: Any) -> dict[str, Any]:
        from apps.backend.api.provider_management import get_provider_registry
        registry = get_provider_registry()
        payload = registry.list_providers_api_payload()
        return {"providers": payload, "total": len(payload)}

    async def inference_plugin_install(self, **kwargs: Any) -> dict[str, Any]:
        from apps.backend.api.provider_management import get_provider_registry
        from apps.backend.services.inference.provider_profiles.plugin_manifest import (
            PluginManifestError,
            parse_manifest,
        )
        import shutil
        name = str(kwargs.get("name") or "")
        manifest_yaml = str(kwargs.get("manifest_yaml") or "")
        if not name or not manifest_yaml:
            return {"error": "name and manifest_yaml are required"}
        registry = get_provider_registry()
        plugin_dir = registry._plugin_dir / name
        plugin_dir.mkdir(parents=True, exist_ok=True)
        manifest_path = plugin_dir / "manifest.yaml"
        manifest_path.write_text(manifest_yaml, encoding="utf-8")
        try:
            manifest = parse_manifest(manifest_path)
        except PluginManifestError as exc:
            shutil.rmtree(plugin_dir, ignore_errors=True)
            return {"error": f"Invalid manifest: {exc}"}
        registry.discover_plugins()
        return {
            "status": "installed",
            "name": manifest.name,
            "provider_id": manifest.provider_id,
            "default_model": manifest.default_model,
        }

    async def inference_plugin_get(self, **kwargs: Any) -> dict[str, Any]:
        from apps.backend.api.provider_management import get_provider_registry
        name = str(kwargs.get("name") or "")
        registry = get_provider_registry()
        try:
            profile = registry.get(name)
        except KeyError:
            return {"error": f"Provider {name!r} not found"}
        builtin_ids = {p.profile_id for p in registry._builtins}
        source = "builtin" if profile.profile_id in builtin_ids else "plugin"
        return {
            "profile_id": profile.profile_id,
            "provider_id": profile.provider_id,
            "default_model": profile.default_model,
            "provenance": profile.provenance,
            "jurisdiction": profile.jurisdiction,
            "requires_tool_use_probe": profile.requires_tool_use_probe,
            "supported_purposes": [p.value for p in profile.supported_purposes],
            "source": source,
        }

    async def inference_plugin_smoke(self, **kwargs: Any) -> dict[str, Any]:
        from apps.backend.api.provider_management import get_provider_registry
        from apps.backend.services.inference.provider_profiles.plugin_registry import SmokeTestError
        name = str(kwargs.get("name") or "")
        registry = get_provider_registry()
        try:
            result = registry.smoke_test(name)
        except SmokeTestError as exc:
            return {"error": str(exc)}
        return result

    async def inference_plugin_enable(self, **kwargs: Any) -> dict[str, Any]:
        from apps.backend.api.provider_management import get_provider_registry
        name = str(kwargs.get("name") or "")
        registry = get_provider_registry()
        registry.enable_plugin(name)
        return {"status": "enabled", "name": name}

    async def inference_plugin_disable(self, **kwargs: Any) -> dict[str, Any]:
        from apps.backend.api.provider_management import get_provider_registry
        name = str(kwargs.get("name") or "")
        registry = get_provider_registry()
        registry.disable_plugin(name)
        return {"status": "disabled", "name": name}

    # — Admin scope —

    async def admin_inference_defaults_get(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="defaults.get",
            parameters=kwargs,
        )

    async def admin_inference_defaults_set(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="defaults.set",
            parameters=kwargs,
        )

    async def admin_inference_tenant_routing_get(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="tenant-routing.get",
            parameters=kwargs,
        )

    async def admin_inference_tenant_routing_set(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="tenant-routing.set",
            parameters=kwargs,
        )

    async def admin_inference_tenant_routing_clear(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="tenant-routing.clear",
            parameters=kwargs,
        )

    async def admin_inference_blocked_providers_list(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="blocked-providers.list",
            parameters=kwargs,
        )

    async def admin_inference_blocked_providers_set(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="blocked-providers.set",
            parameters=kwargs,
        )

    async def admin_inference_blocked_providers_add(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="blocked-providers.add",
            parameters=kwargs,
        )

    async def admin_inference_blocked_providers_remove(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="blocked-providers.remove",
            parameters=kwargs,
        )

    async def admin_inference_jurisdiction_policy_get(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="jurisdiction-policy.get",
            parameters=kwargs,
        )

    async def admin_inference_jurisdiction_policy_set(self, **kwargs: Any) -> dict[str, Any]:
        return await self._inference_proxy(
            tenant_id=kwargs.pop("tenant_id"),
            op_name="jurisdiction-policy.set",
            parameters=kwargs,
        )

    async def run_agent(
        self,
        *,
        tenant_id: str,
        agent_id: str,
        task: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Trigger an agent execution with a task description."""
        run_id = f"run_{uuid.uuid4().hex[:12]}"
        logger.info(
            "Public API: trigger agent run %s agent=%s tenant=%s",
            run_id,
            agent_id,
            tenant_id,
        )
        return {
            "run_id": run_id,
            "agent_id": agent_id,
            "tenant_id": tenant_id,
            "task": task,
            "status": "queued",
            "created_at": datetime.now(UTC).isoformat(),
        }

    # ------------------------------------------------------------------
    # Schedules
    # ------------------------------------------------------------------

    async def create_schedule(
        self,
        *,
        tenant_id: str,
        agent_id: str,
        title: str,
        schedule_type: str,
        cron_expression: str | None = None,
        description: str = "",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Create a schedule for an agent."""
        schedule_id = f"sched_{uuid.uuid4().hex[:12]}"
        now = datetime.now(UTC).isoformat()
        schedule = {
            "schedule_id": schedule_id,
            "tenant_id": tenant_id,
            "agent_id": agent_id,
            "title": title,
            "description": description,
            "schedule_type": schedule_type,
            "cron_expression": cron_expression,
            "status": "active",
            "created_at": now,
            "updated_at": now,
        }
        self._schedules[schedule_id] = schedule
        logger.info("Public API: created schedule %s for tenant %s", schedule_id, tenant_id)
        return schedule

    async def trigger_schedule(
        self,
        *,
        tenant_id: str,
        schedule_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Fire a triggered schedule immediately."""
        schedule = self._schedules.get(schedule_id)
        if not schedule or schedule.get("tenant_id") != tenant_id:
            raise KeyError(f"Schedule not found: {schedule_id}")
        return {
            "schedule_id": schedule_id,
            "tenant_id": tenant_id,
            "status": "triggered",
            "triggered_at": datetime.now(UTC).isoformat(),
        }

    # ------------------------------------------------------------------
    # Evidence
    # ------------------------------------------------------------------

    async def query_evidence(
        self,
        *,
        tenant_id: str,
        agent_id: str | None = None,
        event_type: str | None = None,
        limit: int = 50,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Query the evidence ledger for a tenant."""
        items: list[dict[str, Any]] = []
        try:
            from apps.backend.services.evidence_ledger import get_evidence_ledger_service

            svc = get_evidence_ledger_service()
            items = svc.query_timeline(tenant_id=tenant_id, limit=limit) or []
        except Exception:
            logger.debug("Evidence ledger service unavailable, returning empty list")
        return {
            "tenant_id": tenant_id,
            "items": items,
            "count": len(items),
        }

    # ------------------------------------------------------------------
    # Approvals
    # ------------------------------------------------------------------

    async def list_approvals(
        self,
        *,
        tenant_id: str,
        limit: int = 20,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List pending approval requests for the tenant."""
        approvals: list[dict[str, Any]] = []
        try:
            from apps.backend.services.approval_service import ApprovalService
            from apps.backend.services.approval_gates import get_approval_gates

            service = ApprovalService(approval_gates=get_approval_gates())
            result = service.list_pending_requests(tenant_id=tenant_id)
            if result.success:
                approvals = result.requests or []
        except Exception:
            logger.debug("Approval service unavailable, returning empty list")
        return {
            "tenant_id": tenant_id,
            "approvals": approvals,
            "count": len(approvals),
        }

    async def approve_action(
        self,
        *,
        tenant_id: str,
        request_id: str,
        actor_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Approve a pending action. Raises KeyError if not found."""
        try:
            from apps.backend.services.approval_service import ApprovalService
            from apps.backend.services.approval_gates import get_approval_gates

            service = ApprovalService(approval_gates=get_approval_gates())
            result = service.approve_request(
                tenant_id=tenant_id,
                request_id=request_id,
                actor_id=actor_id,
            )
            if not result.success:
                raise KeyError(f"Approval not found or action failed: {request_id}")
            return {
                "success": True,
                "request_id": request_id,
                "actor_id": actor_id,
                "action": "approve",
                "tenant_id": tenant_id,
            }
        except KeyError:
            raise
        except Exception as exc:
            logger.warning("Approval action failed: %s", exc)
            raise KeyError(f"Approval not found: {request_id}") from exc

    async def reject_action(
        self,
        *,
        tenant_id: str,
        request_id: str,
        actor_id: str,
        reason: str = "",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Reject a pending action. Raises KeyError if not found."""
        try:
            from apps.backend.services.approval_service import ApprovalService
            from apps.backend.services.approval_gates import get_approval_gates

            service = ApprovalService(approval_gates=get_approval_gates())
            result = service.reject_request(
                tenant_id=tenant_id,
                request_id=request_id,
                actor_id=actor_id,
                reason=reason,
            )
            if not result.success:
                raise KeyError(f"Approval not found or action failed: {request_id}")
            return {
                "success": True,
                "request_id": request_id,
                "actor_id": actor_id,
                "action": "reject",
                "reason": reason,
                "tenant_id": tenant_id,
            }
        except KeyError:
            raise
        except Exception as exc:
            logger.warning("Rejection action failed: %s", exc)
            raise KeyError(f"Approval not found: {request_id}") from exc

    # ------------------------------------------------------------------
    # Connectors
    # ------------------------------------------------------------------

    async def connector_install(
        self,
        *,
        tenant_id: str,
        connector_id: str,
        credentials: dict[str, Any],
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Install a connector for the tenant."""
        try:
            from apps.backend.api.connectors._core import get_shared_connector_service

            svc = get_shared_connector_service()
            result = await svc.install_connector(
                tenant_id=tenant_id,
                connector_id=connector_id,
                credentials=credentials,
            )
            return result  # type: ignore[no-any-return]
        except Exception as exc:
            logger.warning("Connector install failed: %s", exc)
            return {
                "tenant_id": tenant_id,
                "connector_id": connector_id,
                "state": "error",
                "error": str(exc),
            }

    async def connector_import_openapi(
        self,
        *,
        tenant_id: str,
        spec_url: str,
        base_url: str | None = None,
        name: str | None = None,
        description: str = "",
        auth: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Import an OpenAPI/Swagger spec as a tenant connector."""
        try:
            from apps.backend.services.connectors.openapi_factory import get_openapi_tool_factory

            return await get_openapi_tool_factory().import_spec(
                spec_url,
                tenant_id,
                base_url=base_url,
                name=name,
                description=description,
                auth=auth or {"type": "none"},
            )
        except Exception as exc:
            logger.warning("Connector OpenAPI import failed: %s", exc)
            return {
                "tenant_id": tenant_id,
                "spec_url": spec_url,
                "state": "error",
                "error": str(exc),
            }

    async def connector_execute(
        self,
        *,
        tenant_id: str,
        connector_id: str,
        operation: str,
        params: dict[str, Any] | None = None,
        dry_run: bool = False,
        idempotency_key: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Execute an operation on an installed connector."""
        try:
            from apps.backend.api.connectors._core import get_shared_connector_service

            svc = get_shared_connector_service()
            result = await svc.execute_operation(
                tenant_id=tenant_id,
                connector_id=connector_id,
                operation=operation,
                params=params or {},
                dry_run=dry_run,
                idempotency_key=idempotency_key,
            )
            return result  # type: ignore[no-any-return]
        except Exception as exc:
            logger.warning("Connector execute failed: %s", exc)
            return {
                "tenant_id": tenant_id,
                "connector_id": connector_id,
                "operation": operation,
                "error": str(exc),
            }

    async def connector_list(
        self,
        *,
        tenant_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List installed connectors for the tenant."""
        try:
            from apps.backend.api.connectors._core import get_shared_connector_service

            svc = get_shared_connector_service()
            result = await svc.list_installed(tenant_id=tenant_id)
            connectors = result if isinstance(result, list) else result.get("connectors", [])
            return {
                "tenant_id": tenant_id,
                "connectors": connectors,
                "count": len(connectors),
            }
        except Exception as exc:
            logger.warning("Connector list failed: %s", exc)
            return {
                "tenant_id": tenant_id,
                "connectors": [],
                "count": 0,
                "error": str(exc),
            }

    async def connector_health(
        self,
        *,
        tenant_id: str,
        connector_id: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Get per-connector health metrics: circuit breaker, success rate, latency, retry budget.

        When connector_id is provided, returns a single connector's health snapshot.
        When omitted, returns health for all connectors of the tenant.
        """
        try:
            from apps.backend.services.connector_health_service import get_connector_health_service

            svc = get_connector_health_service()

            # Issue #2747 round 11: route through the shared remediation
            # helper so MCP/public-API responses CANNOT contradict the HTTP
            # health route or the dashboard bundle. The helper also picks
            # up probe-derived auth states from the persisted health store.
            from apps.backend.services.connector_remediation import compute_remediation
            from apps.backend.api.connectors._core import _get_health_store

            def _probe_for(cid: str) -> dict[str, str] | None:
                try:
                    stored = _get_health_store().get_snapshot(
                        tenant_id=tenant_id,
                        connector_id=cid,
                    )
                    if stored:
                        return {"state": stored.get("state") or "", "message": stored.get("message") or ""}
                except Exception:  # pragma: no cover
                    return None
                return None

            if connector_id:
                snapshot = svc.get_health(tenant_id, connector_id)
                remediation = compute_remediation(
                    tenant_id=tenant_id,
                    connector_id=connector_id,
                    health_service=svc,
                    probe_response=_probe_for(connector_id),
                )
                return {
                    "connector_id": snapshot.connector_id,
                    "tenant_id": snapshot.tenant_id,
                    "circuit_state": remediation.get("circuit_state") or snapshot.circuit_state,
                    "success_rate_24h": snapshot.success_rate_24h,
                    "p95_latency_ms": snapshot.p95_latency_ms,
                    "p99_latency_ms": snapshot.p99_latency_ms,
                    "total_calls": snapshot.total_calls,
                    "total_successes": snapshot.total_successes,
                    "total_failures": snapshot.total_failures,
                    "retry_budget_remaining": snapshot.retry_budget_remaining,
                    "last_failure_at": snapshot.last_failure_at,
                    "last_success_at": snapshot.last_success_at,
                    "uptime_percentage_24h": snapshot.uptime_percentage_24h,
                    "last_failure_message": remediation.get("last_failure_message"),
                    "last_failure_category": remediation.get("last_failure_category"),
                    "needs_reauth": bool(remediation.get("needs_reauth", False)),
                }

            # Issue #2747 round 12: enumerate connector IDs from BOTH the
            # executor-history service AND the persisted probe store. A
            # connector that only has a stored auth_expired probe (no
            # runtime traffic yet) must still surface in aggregate.
            snapshots = svc.get_all_health(tenant_id)
            executor_ids: set[str] = {s.connector_id for s in snapshots}
            executor_by_id = {s.connector_id: s for s in snapshots}

            store_only_ids: set[str] = set()
            store_probes: dict[str, dict[str, str]] = {}
            try:
                stored_list = _get_health_store().list_snapshots(tenant_id)
                for stored in stored_list:
                    cid = stored.get("connector_id") or ""
                    if not cid:
                        continue
                    store_probes[cid] = {
                        "state": stored.get("state") or "",
                        "message": stored.get("message") or "",
                    }
                    if cid not in executor_ids:
                        store_only_ids.add(cid)
            except Exception:  # pragma: no cover -- never fail the public API on a store miss
                stored_list = []

            connectors = []
            all_ids = list(executor_ids) + list(store_only_ids)
            for cid in all_ids:
                probe = store_probes.get(cid) or _probe_for(cid)
                remediation = compute_remediation(
                    tenant_id=tenant_id,
                    connector_id=cid,
                    health_service=svc,
                    probe_response=probe,
                )
                s = executor_by_id.get(cid)
                connectors.append({
                    "connector_id": cid,
                    "circuit_state": remediation.get("circuit_state")
                        or (s.circuit_state if s else "closed"),
                    "success_rate_24h": s.success_rate_24h if s else 0.0,
                    "p95_latency_ms": s.p95_latency_ms if s else 0.0,
                    "p99_latency_ms": s.p99_latency_ms if s else 0.0,
                    "total_calls": s.total_calls if s else 0,
                    "total_successes": s.total_successes if s else 0,
                    "total_failures": s.total_failures if s else 0,
                    "retry_budget_remaining": s.retry_budget_remaining if s else 0,
                    "last_failure_at": s.last_failure_at if s else None,
                    "last_success_at": s.last_success_at if s else None,
                    "uptime_percentage_24h": s.uptime_percentage_24h if s else 0.0,
                    "last_failure_message": remediation.get("last_failure_message"),
                    "last_failure_category": remediation.get("last_failure_category"),
                    "needs_reauth": bool(remediation.get("needs_reauth", False)),
                })
            return {
                "tenant_id": tenant_id,
                "connectors": connectors,
                "total": len(connectors),
                "open_circuits": sum(1 for c in connectors if c["circuit_state"] == "open"),
                "degraded": sum(1 for c in connectors if c["circuit_state"] == "half_open"),
            }
        except Exception as exc:
            logger.warning("Connector health failed: %s", exc)
            return {
                "tenant_id": tenant_id,
                "connector_id": connector_id,
                "error": str(exc),
            }

    async def connector_status(
        self,
        *,
        tenant_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Return the read-only connector availability map without credentials."""
        try:
            from apps.backend.api.connectors._core import _connector_availability_map

            return {
                "tenant_id": tenant_id,
                **_connector_availability_map(tenant_id),
            }
        except Exception as exc:
            logger.warning("Connector status failed: %s", exc)
            return {
                "tenant_id": tenant_id,
                "items": [],
                "summary": {"total": 0, "functional": 0, "degraded": 0, "unavailable": 0},
                "error": str(exc),
            }

    async def connector_auth(
        self,
        *,
        tenant_id: str,
        provider: str,
        redirect_uri: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Initiate OAuth2 flow for a PM connector (JIRA, Linear, Asana, Trello).

        Issue #3585: returns the authorization URL for the user to redirect to.
        """
        import os
        import secrets

        from apps.backend.services.connectors.pm_connector_oauth_mixin import (
            PMConnectorOAuthMixin,
            PROVIDER_OAUTH_CONFIGS,
        )

        provider = (provider or "").strip().lower()
        if provider not in PROVIDER_OAUTH_CONFIGS:
            return {
                "error": f"Provider '{provider}' does not support OAuth. Supported: {sorted(PROVIDER_OAUTH_CONFIGS.keys())}",
                "supported_providers": sorted(PROVIDER_OAUTH_CONFIGS.keys()),
            }

        if not redirect_uri:
            public_base = (os.environ.get("PUBLIC_BASE_URL") or "https://api.workweaver.ai").rstrip("/")
            redirect_uri = f"{public_base}/api/v1/connectors/{provider}/oauth/callback"

        state = secrets.token_urlsafe(32)
        mixin = PMConnectorOAuthMixin()

        try:
            url = mixin.build_authorization_url(
                provider=provider,
                state=state,
                redirect_uri=redirect_uri,
            )
        except ValueError as exc:
            return {"error": str(exc), "provider": provider}

        return {
            "authorize_url": url,
            "state": state,
            "provider": provider,
        }

    # ------------------------------------------------------------------
    # CLI capability wrappers
    # ------------------------------------------------------------------

    async def mission_list(
        self,
        *,
        tenant_id: str,
        status: str | None = None,
        agent_id: str | None = None,
        limit: int = 25,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List work items (missions) for the tenant."""
        try:
            from apps.backend.services.workitem_service import get_workitem_service

            svc = get_workitem_service()
            result = svc.list_workitems(
                tenant_id=tenant_id,
                status=status,
                agent_id=agent_id,
                limit=limit,
            )
            items = result if isinstance(result, list) else result.get("items", [])
            return {
                "tenant_id": tenant_id,
                "items": items,
                "count": len(items),
            }
        except Exception as exc:
            logger.warning("Mission list failed: %s", exc)
            return {
                "tenant_id": tenant_id,
                "items": [],
                "count": 0,
                "error": str(exc),
            }

    async def plan_list(
        self,
        *,
        tenant_id: str,
        status: str | None = None,
        limit: int = 50,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List Zara objective plans for CLI/MCP parity."""
        from apps.backend.services.zara.plan_store import get_zara_plan_store

        result = get_zara_plan_store().list_plans(tenant_id, status=status, limit=limit)
        plans = list(result.get("plans") or [])
        return {
            "tenant_id": tenant_id,
            "plans": plans,
            "count": len(plans),
            "next_cursor": result.get("next_cursor"),
        }

    async def plan_show(
        self,
        *,
        tenant_id: str,
        plan_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Show one Zara objective plan with revision and execution history."""
        from apps.backend.services.zara.plan_store import get_zara_plan_store

        store = get_zara_plan_store()
        plan = store.get_plan(tenant_id, plan_id)
        if not plan:
            raise KeyError(f"Plan not found: {plan_id}")
        return {
            "tenant_id": tenant_id,
            "plan": plan,
            "revisions": list(plan.get("revisions") or []),
            "executions": store.list_executions_for_plan(tenant_id, plan_id),
        }

    async def plan_steer(
        self,
        *,
        tenant_id: str,
        plan_id: str,
        action: str,
        instruction: str | None = None,
        actor_id: str | None = None,
        actor_source: str | None = None,
        expected_revision: int | None = None,
        idempotency_key: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Apply the shared Zara plan steering contract for MCP parity."""
        del actor_source, kwargs
        from apps.backend.api.zara import apply_plan_control

        result = await apply_plan_control(
            plan_id=plan_id,
            action=action,
            instruction=instruction,
            actor_id=actor_id,
            actor_source="mcp",
            expected_revision=expected_revision,
            idempotency_key=idempotency_key,
            tenant_id=tenant_id,
        )
        return _as_plain_dict(result)

    async def mission_steer(
        self,
        *,
        tenant_id: str,
        mission_id: str,
        action_kind: str,
        idempotency_key: str,
        payload: dict[str, Any] | None = None,
        actor_id: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Steer a running mission via the canonical CardAction dispatch."""
        del kwargs
        from apps.backend.api.mission_steer import authorize_mission_steer
        from apps.backend.models.timeblock_card import CardActionKind
        from apps.backend.services.timeblock_cards.steer_service import (
            create_runtime_steer_service,
        )

        member_id = str(actor_id or "").strip()
        action = CardActionKind(action_kind)
        authorize_mission_steer(
            mission_id=mission_id,
            tenant_id=tenant_id,
            member_id=member_id,
        )
        service = create_runtime_steer_service(tenant_id=tenant_id)
        result = service.steer(
            mission_id=mission_id,
            tenant_id=tenant_id,
            member_id=member_id,
            action_kind=action,
            payload=payload or {},
            idempotency_key=idempotency_key,
        )
        return result

    async def mission_reversal_request(
        self,
        *,
        tenant_id: str,
        mission_id: str,
        requested_by: str = "mcp",
        dry_run: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Request mission-level reversal planning or dispatch."""
        del kwargs
        from apps.backend.services.reversal_orchestrator import get_reversal_orchestrator

        return await get_reversal_orchestrator().request_reversal(
            mission_id,
            requested_by,
            tenant_id=tenant_id,
            dry_run=dry_run,
        )

    async def mission_outcome_review(
        self,
        *,
        tenant_id: str,
        mission_id: str,
        outcome_id: str,
        decision: str,
        actor_id: str,
        timeblock_id: str | None = None,
        correction: str | None = None,
        evidence_ref_ids: list[str] | None = None,
        idempotency_key: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Review a mission outcome through the canonical completion gate."""
        del kwargs
        from apps.backend.services.mission_outcome_review import (
            MissionOutcomeReviewDecision,
            MissionOutcomeReviewRequest,
            get_mission_outcome_review_service,
        )

        result = get_mission_outcome_review_service().review_outcome(
            tenant_id=tenant_id,
            actor_id=actor_id,
            request=MissionOutcomeReviewRequest(
                mission_id=mission_id,
                outcome_id=outcome_id,
                timeblock_id=timeblock_id,
                decision=MissionOutcomeReviewDecision(decision),
                correction=correction,
                evidence_ref_ids=list(evidence_ref_ids or []),
                idempotency_key=idempotency_key,
            ),
        )
        return result.model_dump(mode="json")

    async def mission_admission_show(
        self,
        *,
        tenant_id: str,
        mission_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Return the durable per-Mission worker admission snapshot (issue #3282)."""
        del kwargs
        from apps.backend.services.runtime.mission_worker_admission import (
            get_mission_worker_admission,
        )

        snapshot = await get_mission_worker_admission().snapshot(tenant_id, mission_id)
        return {
            "tenant_id": snapshot.tenant_id,
            "mission_id": snapshot.mission_id,
            "cap": snapshot.cap,
            "active_workers": snapshot.active_workers,
            "workers": [
                {
                    "worker_id": lease.worker_id,
                    "leased_at": lease.leased_at.isoformat(),
                    "lease_expires_at": lease.lease_expires_at.isoformat(),
                }
                for lease in snapshot.workers
            ],
        }

    async def mission_breaker_show_or_reset(
        self,
        *,
        tenant_id: str,
        mission_id: str,
        action: str = "show",
        reason: str = "operator override",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Read or reset the spawn circuit breaker (issue #3283)."""
        del kwargs
        from apps.backend.services.runtime.spawn_circuit_breaker import (
            get_spawn_circuit_breaker,
        )

        breaker = get_spawn_circuit_breaker()
        if action == "reset":
            snap = await breaker.reset(tenant_id, mission_id, reason=reason)
        else:
            snap = await breaker.get_state(tenant_id, mission_id)
        return {
            "tenant_id": snap.tenant_id,
            "mission_id": snap.mission_id,
            "state": snap.state.value,
            "consecutive_failures": snap.consecutive_failures,
            "backoff_seconds": snap.backoff_seconds,
            "opened_at": snap.opened_at.isoformat() if snap.opened_at else None,
            "last_transition_at": snap.last_transition_at.isoformat(),
        }

    async def workitem_create(
        self,
        *,
        tenant_id: str,
        title: str,
        description: str = "",
        source_kind: str = "task",
        priority: str = "medium",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Create a new work item."""
        try:
            from apps.backend.services.workitem_service import get_workitem_service

            svc = get_workitem_service()
            result = svc.create_workitem(
                tenant_id=tenant_id,
                title=title,
                description=description,
                source_kind=source_kind,
                priority=priority,
            )
            return result  # type: ignore[no-any-return]
        except Exception as exc:
            logger.warning("WorkItem create failed: %s", exc)
            item_id = f"wi_{uuid.uuid4().hex[:12]}"
            return {
                "id": item_id,
                "tenant_id": tenant_id,
                "title": title,
                "status": "created",
                "error": str(exc),
            }

    async def memory_store(
        self,
        *,
        tenant_id: str,
        content: str,
        scope: str = "tenant",
        agent_id: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Store a memory item."""
        try:
            from apps.backend.workmemory.memory_graph import get_memory_graph

            graph = get_memory_graph()
            memory_id = f"mem_{uuid.uuid4().hex[:12]}"
            graph.store(
                tenant_id=tenant_id,
                memory_id=memory_id,
                content=content,
                scope=scope,
                agent_id=agent_id,
            )
            return {
                "memory_id": memory_id,
                "tenant_id": tenant_id,
                "scope": scope,
                "stored": True,
            }
        except Exception as exc:
            logger.warning("Memory store failed: %s", exc)
            memory_id = f"mem_{uuid.uuid4().hex[:12]}"
            return {
                "memory_id": memory_id,
                "tenant_id": tenant_id,
                "stored": False,
                "error": str(exc),
            }

    async def config_get(
        self,
        *,
        tenant_id: str,
        key: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Get a tenant configuration value."""
        try:
            from apps.backend.services.tenant_config import get_tenant_config

            config = get_tenant_config(tenant_id)
            value = config.get(key) if isinstance(config, dict) else None
            return {
                "tenant_id": tenant_id,
                "key": key,
                "value": value,
                "found": value is not None,
            }
        except Exception as exc:
            logger.warning("Config get failed: %s", exc)
            return {
                "tenant_id": tenant_id,
                "key": key,
                "value": None,
                "found": False,
                "error": str(exc),
            }

    async def entity_list(
        self,
        *,
        tenant_id: str,
        entity_type: str | None = None,
        limit: int = 50,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List entities for the tenant."""
        try:
            from apps.backend.services.entity_service import get_entity_service

            svc = get_entity_service()
            result = svc.list_entities(
                tenant_id=tenant_id,
                entity_type=entity_type,
                limit=limit,
            )
            entities = result if isinstance(result, list) else result.get("entities", [])
            return {
                "tenant_id": tenant_id,
                "entities": entities,
                "count": len(entities),
            }
        except Exception as exc:
            logger.warning("Entity list failed: %s", exc)
            return {
                "tenant_id": tenant_id,
                "entities": [],
                "count": 0,
                "error": str(exc),
            }

    async def org_audit_log(
        self,
        *,
        tenant_id: str,
        org_id: str = "current",
        since: str | None = "7d",
        until: str | None = None,
        actor: str | None = None,
        event_type: Any = None,
        limit: int = 50,
        cursor: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Query the org-level audit log for the authenticated tenant's org."""
        del kwargs
        from apps.backend.services.org_audit_log import get_org_audit_log_service

        return get_org_audit_log_service().query(
            org_id=org_id or "current",
            caller_tenant_id=tenant_id,
            since=since,
            until=until,
            actor=actor,
            event_types=event_type,
            limit=limit,
            cursor=cursor,
        )

    # ------------------------------------------------------------------
    # Swarm executions
    # ------------------------------------------------------------------

    async def swarm_spawn(
        self,
        *,
        tenant_id: str,
        goal: str,
        agents: int | None = None,
        budget: Any = None,
        is_foreground: bool = False,
        until_done: bool = False,
        auto_approve_tier: str = "low,medium",
        plan_mode: str | None = None,
        poll_interval_seconds: float = 2.0,
        wait_timeout_seconds: float = 900.0,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Plan and start a Zara-backed swarm execution for CLI/MCP parity."""
        del kwargs
        normalized_goal = str(goal or "").strip()
        if not normalized_goal:
            raise ValueError("ww.swarm.spawn requires goal")

        parsed_budget = _parse_swarm_spawn_budget(budget)
        requested_agents = max(1, int(agents or parsed_budget.get("agents") or 1))
        from apps.backend.services.swarm_resource_planner import get_swarm_resource_planner

        capacity_decision = get_swarm_resource_planner().plan(
            tenant_id=tenant_id,
            requested_agents=requested_agents,
            is_foreground=is_foreground,
            budget_usd=parsed_budget.get("dollars"),
        )
        if capacity_decision.decision in {"queue", "simulation_only", "requires_capacity_upgrade", "deny"}:
            return {
                "tenant_id": tenant_id,
                "status": "not_started",
                "capacity": capacity_decision.model_dump(),
            }
        auto_approve_tiers = _swarm_spawn_auto_approve_tiers(auto_approve_tier)
        planner_mode = _swarm_spawn_plan_mode(plan_mode)
        spawn_context = {
            "workspace": "mission",
            "source": "ww.swarm.spawn",
            "swarm_spawn": True,
            "budget": parsed_budget,
            "capacity": capacity_decision.model_dump(),
            "effective_agents": capacity_decision.allowed_agents,
            "auto_approve_tiers": sorted(auto_approve_tiers),
            "until_done": bool(until_done),
        }

        from apps.backend.api.zara import execute_plan, generate_plan
        from apps.backend.api.zara.models import ExecutePlanRequest, PlanRequest

        plan_request = PlanRequest(goal=normalized_goal, context=spawn_context, planner_mode=planner_mode)
        plan = _as_plain_dict(await generate_plan(plan_request, tenant_id=tenant_id))
        tier = _swarm_plan_sensitivity(plan)
        gate_flags = _swarm_plan_gate_flags(plan)
        _enforce_swarm_spawn_plan_budget(plan, parsed_budget)
        _ensure_swarm_spawn_can_execute(tier, gate_flags, auto_approve_tiers)

        plan_id = str(plan.get("plan_id") or "").strip()
        if not plan_id:
            raise ValueError("Plan response did not include plan_id")
        plan_rev = int(plan.get("revision") or plan.get("latest_rev") or 1)
        execution = _as_plain_dict(
            await execute_plan(
                ExecutePlanRequest(
                    plan_id=plan_id,
                    plan_rev=plan_rev,
                    goal=normalized_goal,
                    context=spawn_context,
                    explicit_approval=False,
                ),
                tenant_id=tenant_id,
            )
        )
        execution_id = str(execution.get("execution_id") or "").strip()
        if not execution_id:
            raise ValueError("execute-plan response did not include execution_id")

        final_status: dict[str, Any] | None = None
        if until_done:
            final_status = await _wait_for_zara_execution(
                tenant_id=tenant_id,
                execution_id=execution_id,
                poll_interval_seconds=float(poll_interval_seconds),
                wait_timeout_seconds=float(wait_timeout_seconds),
            )

        payload: dict[str, Any] = {
            "tenant_id": tenant_id,
            "execution_id": execution_id,
            "status": str((final_status or execution).get("status") or ""),
            "plan_id": plan_id,
            "plan_revision": plan_rev,
            "goal": normalized_goal,
            "planner_mode": plan.get("planner_mode"),
            "sensitivity": tier,
            "gate_flags": gate_flags,
            "initial_steps": len([item for item in plan.get("steps") or [] if isinstance(item, dict)]),
            "budget": parsed_budget,
            "auto_approve_tiers": sorted(auto_approve_tiers),
            "capacity": capacity_decision.model_dump(),
            "effective_agents": capacity_decision.allowed_agents,
        }
        if final_status is not None:
            payload["final_status"] = final_status
        return payload

    async def swarm_status(
        self,
        *,
        tenant_id: str,
        execution_id: str | None = None,
        status: str = "active",
        limit: int = 50,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List active swarm executions or show one execution."""
        del kwargs
        from apps.backend.services.swarm_scheduler import get_swarm_scheduler
        from apps.backend.utils.tenant import strip_tenant_prefix

        scheduler = get_swarm_scheduler()
        tenant = strip_tenant_prefix(tenant_id)
        if execution_id:
            execution = scheduler.get_fresh(tenant, execution_id)
            if execution is None:
                return {"found": False, "execution_id": execution_id}
            return {"found": True, "execution": _swarm_execution_payload(execution)}

        normalized = str(status or "active").strip().lower()
        try:
            capped_limit = max(1, min(int(limit), 200))
        except (TypeError, ValueError):
            capped_limit = 50
        state = {
            "admitted": "pending",
            "pending": "pending",
            "running": "running",
            "completed": "completed",
            "failed": "failed",
            "cancelled": "cancelled",
        }.get(normalized)
        if normalized == "queued":
            executions = []
        elif normalized == "active":
            executions = [
                execution
                for execution in scheduler.list_executions(tenant, limit=500)
                if execution.state in {"pending", "running"}
            ][:capped_limit]
        elif state:
            executions = scheduler.list_executions(tenant, state=state, limit=capped_limit)
        else:
            raise ValueError(f"Unsupported swarm status filter: {status}")
        payloads = [_swarm_execution_payload(execution) for execution in executions]
        return {
            "tenant_id": tenant,
            "executions": payloads,
            "count": len(payloads),
            "limit": capped_limit,
            "status": normalized,
        }

    async def swarm_cancel(
        self,
        *,
        tenant_id: str,
        execution_id: str,
        reason: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Cancel a pending or running swarm execution."""
        del kwargs
        from apps.backend.services.swarm_scheduler import get_swarm_scheduler
        from apps.backend.utils.tenant import strip_tenant_prefix

        scheduler = get_swarm_scheduler()
        tenant = strip_tenant_prefix(tenant_id)
        execution = scheduler.get_fresh(tenant, execution_id)
        if execution is None:
            return {"found": False, "execution_id": execution_id}
        if execution.state == "cancelled":
            return {
                "found": True,
                "execution_id": execution_id,
                "status": "cancelled",
                "cancelled": False,
                "reason": reason or execution.cancel_reason,
            }
        if execution.state not in {"pending", "running"}:
            raise ValueError(f"Cannot cancel swarm execution in {execution.state} state")
        cancelled = scheduler.cancel(tenant, execution_id, reason=reason)
        return {
            "found": True,
            "execution_id": execution_id,
            "status": "cancelled" if cancelled else _swarm_public_status(execution.state),
            "cancelled": cancelled,
            "reason": reason,
        }

    async def swarm_constitution_create(
        self,
        *,
        tenant_id: str,
        name: str,
        content: str,
        actor_id: str = "mcp",
        rationale: str | None = None,
        activate: bool = False,
        idempotency_key: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Create a versioned swarm constitution for CLI/MCP parity."""
        del kwargs
        from apps.backend.services.swarm_constitution import get_swarm_constitution_service

        result = get_swarm_constitution_service().create_constitution(
            tenant_id=tenant_id,
            name=name,
            content=content,
            actor_id=actor_id,
            rationale=rationale,
            activate=activate,
            idempotency_key=idempotency_key,
            surface="mcp",
        )
        return result.model_dump(mode="json")

    async def swarm_constitution_list(self, *, tenant_id: str, **kwargs: Any) -> dict[str, Any]:
        """List swarm constitutions for CLI/MCP parity."""
        del kwargs
        from apps.backend.services.swarm_constitution import get_swarm_constitution_service

        constitutions = [
            item.model_dump(mode="json")
            for item in get_swarm_constitution_service().list_constitutions(tenant_id)
        ]
        return {"tenant_id": tenant_id, "constitutions": constitutions, "count": len(constitutions)}

    async def swarm_constitution_get(
        self,
        *,
        tenant_id: str,
        constitution_id: str,
        version: int | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Return one swarm constitution version."""
        del kwargs
        from apps.backend.services.swarm_constitution import get_swarm_constitution_service

        return get_swarm_constitution_service().get_constitution(
            tenant_id,
            constitution_id,
            version=version,
        ).model_dump(mode="json")

    async def swarm_constitution_update(
        self,
        *,
        tenant_id: str,
        constitution_id: str,
        content: str,
        actor_id: str = "mcp",
        name: str | None = None,
        rationale: str | None = None,
        idempotency_key: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Append a new swarm constitution version."""
        del kwargs
        from apps.backend.services.swarm_constitution import get_swarm_constitution_service

        return get_swarm_constitution_service().update_constitution(
            tenant_id=tenant_id,
            constitution_id=constitution_id,
            content=content,
            actor_id=actor_id,
            name=name,
            rationale=rationale,
            idempotency_key=idempotency_key,
            surface="mcp",
        ).model_dump(mode="json")

    async def swarm_constitution_activate(
        self,
        *,
        tenant_id: str,
        constitution_id: str,
        version: int,
        actor_id: str = "mcp",
        rationale: str | None = None,
        idempotency_key: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Activate one swarm constitution version."""
        del kwargs
        from apps.backend.services.swarm_constitution import get_swarm_constitution_service

        return get_swarm_constitution_service().activate_version(
            tenant_id=tenant_id,
            constitution_id=constitution_id,
            version=int(version),
            actor_id=actor_id,
            rationale=rationale,
            idempotency_key=idempotency_key,
            surface="mcp",
        ).model_dump(mode="json")

    async def swarm_constitution_deactivate(
        self,
        *,
        tenant_id: str,
        constitution_id: str,
        actor_id: str = "mcp",
        rationale: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Deactivate the active swarm constitution."""
        del kwargs
        from apps.backend.services.swarm_constitution import get_swarm_constitution_service

        return get_swarm_constitution_service().deactivate(
            tenant_id=tenant_id,
            constitution_id=constitution_id,
            actor_id=actor_id,
            rationale=rationale,
        ).model_dump(mode="json")

    async def swarm_constitution_delete(
        self,
        *,
        tenant_id: str,
        constitution_id: str,
        actor_id: str = "mcp",
        rationale: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Delete one swarm constitution."""
        del kwargs
        from apps.backend.services.swarm_constitution import get_swarm_constitution_service

        return get_swarm_constitution_service().delete_constitution(
            tenant_id=tenant_id,
            constitution_id=constitution_id,
            actor_id=actor_id,
            rationale=rationale,
        ).model_dump(mode="json")

    async def swarm_constitution_active(self, *, tenant_id: str, **kwargs: Any) -> dict[str, Any]:
        """Return the active swarm constitution."""
        del kwargs
        from apps.backend.services.swarm_constitution import get_swarm_constitution_service

        active = get_swarm_constitution_service().get_active_constitution(tenant_id)
        if active is None:
            return {"tenant_id": tenant_id, "constitution": None}
        payload = active.model_dump(mode="json")
        return {"tenant_id": tenant_id, "constitution": payload, **payload}

    async def swarm_record_step_result(
        self,
        *,
        tenant_id: str,
        step_id: str,
        proposed_status: str = "completed",
        evidence_bundle: dict[str, Any] | None = None,
        evidence_ids: list[str] | None = None,
        function_id: str | None = None,
        completed_at: str | None = None,
        actor_chain: list[str] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Submit a terminal-status candidate for a swarm step (#3236).

        Mirrors POST /api/v1/swarm/steps/{step_id}/result. Routes the
        decision through CompletionGate (verifier + success-criteria
        evaluator + evidence isolation + optimistic-lock CAS) and emits
        a swarm.completion_gate.verdict decision trace.
        """
        del kwargs
        from apps.backend.api.swarm_step_result import attempt_step_transition

        normalized_step = str(step_id or "").strip()
        if not normalized_step:
            raise ValueError("ww.swarm.record_step_result requires step_id")
        chain = list(actor_chain) if isinstance(actor_chain, list) else ["mcp"]
        response, http_status = await attempt_step_transition(
            tenant_id=tenant_id,
            step_id=normalized_step,
            proposed_status=str(proposed_status or "completed"),
            evidence_bundle=evidence_bundle if isinstance(evidence_bundle, dict) else None,
            evidence_ids=list(evidence_ids or []),
            function_id=str(function_id or "").strip() or None,
            completed_at=str(completed_at or "").strip() or None,
            actor_chain=chain,
        )
        payload = response.model_dump(mode="json")
        payload["http_status"] = http_status
        return payload

    async def swarm_success_criteria_eval(
        self,
        *,
        tenant_id: str,
        step_id: str,
        criteria: dict[str, Any],
        evidence: dict[str, Any] | None = None,
        actor_chain: list[str] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Evaluate a swarm step success criterion (#3238).

        Mirrors POST /api/v1/swarm/steps/{step_id}/criterion/evaluate. Emits a
        ``swarm.success_criteria.evaluated`` decision trace per invocation so
        MCP, CLI, and REST callers share one auditable verdict path.
        """
        del kwargs
        from apps.backend.services.swarm.success_criteria_evaluator import (
            SuccessCriteriaEvaluator,
        )
        from apps.backend.utils.tenant import strip_tenant_prefix

        tenant = strip_tenant_prefix(tenant_id)
        normalized_step = str(step_id or "").strip()
        if not normalized_step:
            raise ValueError("ww.swarm.success_criteria_eval requires step_id")
        if not isinstance(criteria, dict):
            raise ValueError("ww.swarm.success_criteria_eval requires criteria object")

        chain = list(actor_chain) if isinstance(actor_chain, list) else ["mcp"]
        result = SuccessCriteriaEvaluator.evaluate(
            criteria=criteria,
            evidence=evidence or {},
            tenant_id=tenant,
            step_id=normalized_step,
            actor_chain=chain,
        )
        return {
            "tenant_id": tenant,
            "step_id": normalized_step,
            "passed": result.passed,
            "criteria_type": result.criteria_type,
            "details": list(result.details),
        }

    async def workflow_template_list(self, *, tenant_id: str, **kwargs: Any) -> dict[str, Any]:
        """List backend-owned workflow saga templates for CLI/MCP parity."""
        del kwargs
        from apps.backend.services.workflow.template_saga_operations import (
            get_workflow_template_saga_service,
        )
        from apps.backend.utils.tenant import strip_tenant_prefix

        tenant = strip_tenant_prefix(tenant_id)
        templates = get_workflow_template_saga_service().list_templates(tenant)
        return {"tenant_id": tenant, "count": len(templates), "templates": templates}

    async def workflow_template_show(
        self,
        *,
        tenant_id: str,
        template_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Return one workflow saga template."""
        del kwargs
        from apps.backend.services.workflow.template_saga_operations import (
            get_workflow_template_saga_service,
        )
        from apps.backend.utils.tenant import strip_tenant_prefix

        tenant = strip_tenant_prefix(tenant_id)
        return get_workflow_template_saga_service().show_template(tenant, template_id)

    async def workflow_saga_run(
        self,
        *,
        tenant_id: str,
        template_id: str,
        idempotency_key: str | None = None,
        actor_id: str = "mcp",
        initial_data: dict[str, Any] | None = None,
        fail_step_id: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Run a workflow template as an idempotent saga."""
        del kwargs
        from apps.backend.services.workflow.template_saga_operations import (
            get_workflow_template_saga_service,
        )
        from apps.backend.utils.tenant import strip_tenant_prefix

        tenant = strip_tenant_prefix(tenant_id)
        return get_workflow_template_saga_service().run_template(
            tenant,
            template_id,
            actor_id=actor_id,
            initial_data=initial_data,
            idempotency_key=idempotency_key,
            fail_step_id=fail_step_id,
        )

    async def workflow_saga_status(
        self,
        *,
        tenant_id: str,
        run_id: str,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Return a workflow saga run by tenant-scoped run ID."""
        del kwargs
        from apps.backend.services.workflow.template_saga_operations import (
            get_workflow_template_saga_service,
        )
        from apps.backend.utils.tenant import strip_tenant_prefix

        tenant = strip_tenant_prefix(tenant_id)
        return get_workflow_template_saga_service().get_run(tenant, run_id)

    async def workflow_saga_compensate(
        self,
        *,
        tenant_id: str,
        run_id: str,
        reason: str = "manual_compensation",
        actor_id: str = "mcp",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Compensate a workflow saga run."""
        del kwargs
        from apps.backend.services.workflow.template_saga_operations import (
            get_workflow_template_saga_service,
        )
        from apps.backend.utils.tenant import strip_tenant_prefix

        tenant = strip_tenant_prefix(tenant_id)
        return get_workflow_template_saga_service().compensate_run(
            tenant,
            run_id,
            actor_id=actor_id,
            reason=reason,
        )

    async def pulse_list(
        self,
        *,
        tenant_id: str,
        state: str | None = None,
        kind: str | None = None,
        subject_id: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List universal Pulse projections for CLI/MCP parity."""
        del kwargs
        from apps.backend.services.pulse_service import get_pulse_projection_service
        from apps.backend.utils.tenant import strip_tenant_prefix

        tenant = strip_tenant_prefix(tenant_id)
        pulses = get_pulse_projection_service().list_pulses(
            tenant,
            state=state,
            kind=kind,
            subject_id=subject_id,
        )
        return {"tenant_id": tenant, "count": len(pulses), "pulses": [pulse.model_dump() for pulse in pulses]}

    async def session_intake_queue_status(
        self,
        *,
        tenant_id: str,
        member_id: str | None = None,
        channel: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Read per-member intake queue counters for CLI/MCP parity."""
        del kwargs
        from apps.backend.services.sessions.intake_queue import get_member_intake_queue

        return get_member_intake_queue().stats(
            workspace_id=tenant_id,
            member_id=member_id,
            channel=channel,
        ).to_response()

    # ------------------------------------------------------------------
    # Weekly Upgrade Digest
    # ------------------------------------------------------------------

    async def upgrades_list(self, *, tenant_id: str, **kwargs: Any) -> dict[str, Any]:
        del kwargs
        from apps.backend.services.upgrade_digest import get_upgrade_digest_service

        return get_upgrade_digest_service().build_digest(tenant_id).to_dict()

    async def upgrades_show(self, *, tenant_id: str, proposal_id: str, **kwargs: Any) -> dict[str, Any]:
        del kwargs
        from apps.backend.services.upgrade_digest import get_upgrade_digest_service

        return get_upgrade_digest_service().get_proposal(tenant_id, proposal_id)

    async def upgrades_approve(
        self, *, tenant_id: str, proposal_id: str, actor_id: str = "mcp", **kwargs: Any
    ) -> dict[str, Any]:
        del kwargs
        from apps.backend.services.upgrade_digest import get_upgrade_digest_service

        return get_upgrade_digest_service().approve(tenant_id, proposal_id, actor_id=actor_id)

    async def upgrades_pilot(
        self, *, tenant_id: str, proposal_id: str, actor_id: str = "mcp", **kwargs: Any
    ) -> dict[str, Any]:
        del kwargs
        from apps.backend.services.upgrade_digest import get_upgrade_digest_service

        return get_upgrade_digest_service().pilot(tenant_id, proposal_id, actor_id=actor_id)

    async def upgrades_dismiss(
        self, *, tenant_id: str, proposal_id: str, actor_id: str = "mcp", **kwargs: Any
    ) -> dict[str, Any]:
        del kwargs
        from apps.backend.services.upgrade_digest import get_upgrade_digest_service

        return get_upgrade_digest_service().dismiss(tenant_id, proposal_id, actor_id=actor_id)

    # ------------------------------------------------------------------
    # Precedent Outcome Prediction (Issue #2331)
    # ------------------------------------------------------------------

    async def precedent_predict(
        self,
        *,
        tenant_id: str,
        action_domain: str,
        description: str,
        k_precedents: int = 20,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Predict outcome distribution from historical precedents."""
        del kwargs
        from apps.backend.models.outcome_distribution import ActionSpec
        from apps.backend.services.precedent_outcome_service import PrecedentOutcomeService
        from apps.backend.services.precedent_query import PrecedentQuery
        from apps.backend.utils.tenant import strip_tenant_prefix

        tenant = strip_tenant_prefix(tenant_id)

        action_spec = ActionSpec(
            action_domain=action_domain,
            description=description,
        )

        precedent_query = PrecedentQuery()
        query_result = precedent_query.find_precedents(
            tenant_id=tenant,
            decision_summary=description,
            decision_type="tool_call",
            top_k=k_precedents,
        )

        service = PrecedentOutcomeService()
        prediction = service.predict(
            action_spec=action_spec,
            precedents=query_result.precedents,
        )

        return {"prediction": prediction.model_dump()}

    # ------------------------------------------------------------------
    # Strategy Trace (Issue #2327)
    # ------------------------------------------------------------------

    async def strategy_trace(
        self,
        *,
        tenant_id: str,
        okr_id: str | None = None,
        limit: int = 100,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Return strategic decision traces (OKR + DecisionEvent projection over domain=strategy)."""
        del kwargs
        from apps.backend.api.evidence import get_strategic_trace, list_strategic_traces

        if okr_id:
            trace = get_strategic_trace(tenant_id=tenant_id, okr_id=okr_id, limit=limit)
            return {
                "tenant_id": tenant_id,
                "trace": trace.model_dump(mode="json"),
            }
        traces = list_strategic_traces(tenant_id=tenant_id, limit=limit)
        return {
            "tenant_id": tenant_id,
            "items": [t.model_dump(mode="json") for t in traces],
            "count": len(traces),
        }

    # ------------------------------------------------------------------
    # TimeBlock CRUD (W#2785 PR C) — MCP surface over canonical
    # /api/v1/timeblocks REST API. Calls AgentWorkLedgerService directly
    # so the audit-bearing Decision Trace is emitted by the same
    # canonical seam that PR A's REST routes use.
    # ------------------------------------------------------------------

    async def timeblock_list(
        self,
        *,
        tenant_id: str,
        workspace_id: str | None = None,
        since: str | None = None,
        until: str | None = None,
        owner: str | None = None,
        limit: int = 50,
        cursor: str | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """List TimeBlocks for the tenant. Read-only — no Decision Trace."""
        del kwargs
        from apps.backend.services.timeblock_mcp_dispatch import list_timeblocks_mcp

        return await list_timeblocks_mcp(
            tenant_id=tenant_id,
            workspace_id=workspace_id,
            since=since,
            until=until,
            owner=owner,
            limit=limit,
            cursor=cursor,
        )

    async def timeblock_create(
        self,
        *,
        tenant_id: str,
        workspace_id: str | None = None,
        owner_id: str | None = None,
        start_utc: str | None = None,
        end_utc: str | None = None,
        title: str | None = None,
        intent: str = "",
        force: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Create a TimeBlock. Conflict-checked unless force=true. Emits trace."""
        del kwargs
        from apps.backend.services.timeblock_mcp_dispatch import create_timeblock_mcp

        return await create_timeblock_mcp(
            tenant_id=tenant_id,
            workspace_id=workspace_id,
            owner_id=owner_id,
            start_utc=start_utc,
            end_utc=end_utc,
            title=title,
            intent=intent,
            force=force,
        )

    async def timeblock_show(
        self,
        *,
        tenant_id: str,
        id: str | None = None,  # noqa: A002 — public MCP schema field name
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Read a single TimeBlock by id. Read-only — no Decision Trace."""
        del kwargs
        from apps.backend.services.timeblock_mcp_dispatch import show_timeblock_mcp

        return await show_timeblock_mcp(tenant_id=tenant_id, block_id=id)

    async def timeblock_update(
        self,
        *,
        tenant_id: str,
        id: str | None = None,  # noqa: A002
        title: str | None = None,
        intent: str | None = None,
        start_utc: str | None = None,
        end_utc: str | None = None,
        force: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Patch a TimeBlock. Time edits run conflict detection. Emits trace."""
        del kwargs
        from apps.backend.services.timeblock_mcp_dispatch import update_timeblock_mcp

        return await update_timeblock_mcp(
            tenant_id=tenant_id,
            block_id=id,
            title=title,
            intent=intent,
            start_utc=start_utc,
            end_utc=end_utc,
            force=force,
        )

    async def timeblock_move(
        self,
        *,
        tenant_id: str,
        id: str | None = None,  # noqa: A002
        new_start_utc: str | None = None,
        new_end_utc: str | None = None,
        force: bool = False,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Atomically move a TimeBlock window. Conflict-checked unless force=true."""
        del kwargs
        from apps.backend.services.timeblock_mcp_dispatch import move_timeblock_mcp

        return await move_timeblock_mcp(
            tenant_id=tenant_id,
            block_id=id,
            new_start_utc=new_start_utc,
            new_end_utc=new_end_utc,
            force=force,
        )

    async def timeblock_delete(
        self,
        *,
        tenant_id: str,
        id: str | None = None,  # noqa: A002
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Soft-delete (state→CANCELLED) a TimeBlock. Audit row is preserved."""
        del kwargs
        from apps.backend.services.timeblock_mcp_dispatch import delete_timeblock_mcp

        return await delete_timeblock_mcp(tenant_id=tenant_id, block_id=id)

    async def function_sli_snapshot(
        self,
        *,
        tenant_id: str,
        function_id: str,
        window_hours: int = 24,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Capture zero-burn SLI snapshot for a Work Function via MCP."""
        del kwargs
        from httpx import AsyncClient, ASGITransport

        from apps.backend.main import app

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.get(
                f"/api/v1/work-functions/{function_id}/zero-burn-snapshot",
                params={"window_hours": window_hours},
                headers={"x-tenant-id": tenant_id},
            )
            return resp.json()

    async def function_sli_reap(
        self,
        *,
        tenant_id: str,
        function_id: str,
        idle_threshold_minutes: int = 30,
        dry_run: bool = False,
        actor_id: str = "mcp",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Reap idle resource envelopes for a Work Function via MCP."""
        del kwargs
        from httpx import AsyncClient, ASGITransport

        from apps.backend.main import app

        async with AsyncClient(
            transport=ASGITransport(app=app),
            base_url="http://test",
        ) as client:
            resp = await client.post(
                f"/api/v1/work-functions/{function_id}/reap-idle",
                json={
                    "idle_threshold_minutes": idle_threshold_minutes,
                    "dry_run": dry_run,
                    "actor_id": actor_id,
                },
                headers={"x-tenant-id": tenant_id},
            )
            return resp.json()

    # ------------------------------------------------------------------
    # Chat router MCP surface (Slices 9 + 11).
    # ------------------------------------------------------------------

    async def chat_route(
        self,
        *,
        tenant_id: str,
        message: str = "",
        thread_id: str = "",
        workspace_context: dict[str, Any] | None = None,
        expected_state_hash: str | None = None,
        prior_scope: dict[str, Any] | None = None,
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Classify a chat message via the canonical chat router.

        Wraps ``POST /api/v1/chat/route``. Mirrors the CLI surface so
        agents that drive Workweaver via MCP can ask "what kind of
        conversation is this?" before dispatching their own follow-up
        actions.
        """
        del kwargs
        from apps.backend.services.chat_router.contract import (
            CardLifecycleState,
            ChatScope,
            ChatScopeType,
            ScopeInferredFrom,
            WorkspaceContext,
        )
        from apps.backend.services.chat_router.router_service import (
            RouteRequest,
            get_chat_router_service,
        )

        ctx_payload = workspace_context or {}
        active_states: dict[str, CardLifecycleState] = {}
        for card_id, state in (ctx_payload.get("active_card_states") or {}).items():
            try:
                active_states[card_id] = CardLifecycleState(str(state))
            except ValueError:
                continue
        ctx = WorkspaceContext(
            currently_open_card_id=ctx_payload.get("currently_open_card_id"),
            currently_open_goal_id=ctx_payload.get("currently_open_goal_id"),
            recently_viewed_card_ids=list(
                ctx_payload.get("recently_viewed_card_ids") or []
            ),
            active_card_states=active_states,
        )

        prior_scope_obj: ChatScope | None = None
        if prior_scope and isinstance(prior_scope, dict):
            try:
                prior_scope_obj = ChatScope(
                    type=ChatScopeType(str(prior_scope.get("type", "workspace"))),
                    id=prior_scope.get("id"),
                    name=prior_scope.get("name"),
                    confidence=float(prior_scope.get("confidence", 0.5)),
                    rationale=str(prior_scope.get("rationale") or ""),
                    inferred_from=ScopeInferredFrom.HISTORY_CARRYOVER,
                )
            except Exception:
                prior_scope_obj = None

        service = get_chat_router_service()
        decision = await service.route(
            RouteRequest(
                message=str(message or ""),
                thread_id=str(thread_id or ""),
                tenant_id=tenant_id,
                workspace_context=ctx,
                expected_state_hash=expected_state_hash,
                prior_scope=prior_scope_obj,
            )
        )

        # Mirror the REST envelope shape.
        from apps.backend.api.chat_router_routes import _envelope_from_decision

        envelope = _envelope_from_decision(decision)
        return envelope.model_dump()

    async def chat_rollback(
        self,
        *,
        tenant_id: str,
        decision_id: str = "",
        actor: str = "user",
        **kwargs: Any,
    ) -> dict[str, Any]:
        """Roll back a ``KNOWLEDGE_WORK`` plan via the canonical service.

        Wraps ``POST /api/v1/chat/rollback/{decision_id}``.
        """
        del kwargs
        from apps.backend.services.zara.plan_rollback_service import (
            get_plan_rollback_service,
        )

        result = await get_plan_rollback_service().rollback(
            decision_id=decision_id,
            tenant_id=tenant_id,
            actor=actor,
        )
        return {
            "decision_id": decision_id,
            "status": result.status,
            "rolled_back_card_ids": result.rolled_back_card_ids,
            "rolled_back_count": len(result.rolled_back_card_ids),
            "message": result.message,
        }


_instance: PublicApiService | None = None


def get_public_api_service() -> PublicApiService:
    """Return the singleton PublicApiService instance."""
    global _instance
    if _instance is None:
        _instance = PublicApiService()
    return _instance
