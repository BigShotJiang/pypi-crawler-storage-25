"""Connector Action Discovery API — browse and search available connector actions.

Exposes the ActionDiscoveryService through REST endpoints so tenants can
discover what actions are available across their connected providers, search
by capability, force-refresh the catalog, and view a dashboard summary.

Prefix: /api/v1/connectors/actions
Tags: connector-actions

Architecture:
    Request -> tenant extraction -> ActionDiscoveryService -> Response
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, Query

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.connectors.action_discovery import (
    ActionDiscoveryService,
    ConnectorAction,
    ConnectorActionCatalog,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/connectors", tags=["connector-actions"])

# Side effect classes that represent write operations (non-read-only).
_WRITE_SIDE_EFFECTS: frozenset[str] = frozenset({"create", "update", "delete", "execute"})


def _get_service() -> ActionDiscoveryService:
    from apps.backend.dependencies import get_action_discovery_service

    return get_action_discovery_service()


def _action_to_dict(action: ConnectorAction) -> dict[str, Any]:
    """Serialize a ConnectorAction to a JSON-friendly dict."""
    return {
        "action_id": action.action_id,
        "provider": action.provider,
        "verb": action.verb,
        "resource": action.resource,
        "description": action.description,
        "input_schema": action.input_schema,
        "output_schema": action.output_schema,
        "side_effect_class": action.side_effect_class,
        "reversible": action.reversible,
        "rate_limit": action.rate_limit,
        "requires_approval": action.requires_approval,
    }


def _catalog_to_dict(catalog: ConnectorActionCatalog) -> dict[str, Any]:
    """Serialize a ConnectorActionCatalog to a JSON-friendly dict."""
    return {
        "tenant_id": catalog.tenant_id,
        "last_refreshed": catalog.last_refreshed,
        "providers": {
            provider_id: [_action_to_dict(a) for a in actions] for provider_id, actions in catalog.providers.items()
        },
        "total_actions": sum(len(a) for a in catalog.providers.values()),
    }


def _build_dashboard_view(
    catalog: ConnectorActionCatalog,
    connected_providers: set[str],
) -> dict[str, Any]:
    """Build a dashboard-friendly view of connector state for the Settings UI.

    Args:
        catalog: The tenant's full action catalog.
        connected_providers: Set of provider IDs that the tenant has actively connected.

    Returns:
        Dashboard dict with connected/available lists and aggregate totals.
    """
    connected: list[dict[str, Any]] = []
    available: list[dict[str, Any]] = []
    total_actions = 0
    total_write = 0
    approval_required = 0

    for provider_id, actions in catalog.providers.items():
        read_count = sum(1 for a in actions if a.side_effect_class == "read_only")
        write_count = sum(1 for a in actions if a.side_effect_class in _WRITE_SIDE_EFFECTS)
        approval_count = sum(1 for a in actions if a.requires_approval)

        total_actions += len(actions)
        total_write += write_count
        approval_required += approval_count

        if provider_id in connected_providers:
            connected.append(
                {
                    "provider": provider_id,
                    "status": "active",
                    "read_actions": read_count,
                    "write_actions": write_count,
                    "last_synced": catalog.last_refreshed,
                }
            )
        else:
            available.append(
                {
                    "provider": provider_id,
                    "category": _infer_category(provider_id),
                    "description": f"Connect {provider_id} to discover available actions",
                    "actions_available": len(actions),
                }
            )

    return {
        "connected": connected,
        "available": available,
        "total_actions": total_actions,
        "total_write_actions": total_write,
        "approval_required_count": approval_required,
    }


def _infer_category(provider_id: str) -> str:
    """Infer a connector category from the provider ID.

    Uses simple heuristics; real category data comes from ConnectorManifest.
    """
    crm_providers = {"hubspot", "salesforce", "zoho-crm"}
    productivity_providers = {"google-calendar", "google-drive", "notion", "outlook-calendar", "microsoft-365"}
    communication_providers = {"slack", "gmail", "zoho-mail", "twilio"}
    dev_providers = {"github"}
    payment_providers = {"stripe"}

    if provider_id in crm_providers:
        return "crm"
    if provider_id in productivity_providers:
        return "productivity"
    if provider_id in communication_providers:
        return "communication"
    if provider_id in dev_providers:
        return "development"
    if provider_id in payment_providers:
        return "payments"
    return "other"


@router.get("/dashboard")
async def get_connector_dashboard(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Dashboard-friendly view of all connectors for the Settings UI.

    Returns connected providers with action counts, available providers,
    and aggregate totals including write actions and approval requirements.
    """
    service = _get_service()
    catalog = service.get_catalog(tenant_id)
    if catalog is None:
        catalog = service.refresh_catalog(tenant_id)

    # Determine which providers the tenant has actively connected.
    # For now, treat all providers in the catalog as connected since
    # the catalog is built from PROVIDER_OPERATION_MAP which represents
    # configured integrations. A future enhancement will check
    # connection status per provider.
    connected_providers = set(catalog.providers.keys())

    return _build_dashboard_view(catalog, connected_providers)


@router.get("/actions")
async def get_action_catalog(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Get the full action catalog for the authenticated tenant.

    Returns the cached catalog if available, otherwise triggers a refresh.
    """
    service = _get_service()
    catalog = service.get_catalog(tenant_id)
    if catalog is None:
        catalog = service.refresh_catalog(tenant_id)
    return _catalog_to_dict(catalog)


@router.get("/{provider_id}/actions")
async def get_provider_actions(
    provider_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Get available actions for a specific provider."""
    service = _get_service()
    actions = service.discover_actions(tenant_id, provider_id)
    return {
        "provider_id": provider_id,
        "actions": [_action_to_dict(a) for a in actions],
        "total": len(actions),
    }


@router.post("/{provider_id}/actions/refresh")
async def refresh_provider_actions(
    provider_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Force refresh actions for a specific provider.

    Discovers actions fresh from the operation map and updates the catalog.
    """
    service = _get_service()
    actions = service.discover_actions(tenant_id, provider_id)

    # Update the catalog with refreshed provider actions
    catalog = service.get_catalog(tenant_id)
    if catalog is None:
        catalog = service.refresh_catalog(tenant_id)
    else:
        catalog.providers[provider_id] = actions

    return {
        "provider_id": provider_id,
        "actions": [_action_to_dict(a) for a in actions],
        "total": len(actions),
        "refreshed": True,
    }


@router.get("/actions/search")
async def search_actions_by_capability(
    capability: str = Query(..., description="Capability to search for, e.g. 'create_contact'"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Search for actions matching a capability need.

    Searches across all providers in the tenant's catalog for actions whose
    action_id, verb, or resource matches the capability string.
    """
    service = _get_service()
    # Ensure catalog exists
    if service.get_catalog(tenant_id) is None:
        service.refresh_catalog(tenant_id)

    actions = service.get_actions_by_capability(tenant_id, capability)
    return {
        "capability": capability,
        "matches": [_action_to_dict(a) for a in actions],
        "total": len(actions),
    }
