"""Harness foundation API endpoints (Lane-A H0-01..H0-05)."""

from __future__ import annotations

from dataclasses import asdict
from typing import Any

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.harness_core import get_harness_runtime
from apps.backend.services.harness_rollout_snapshot import (
    resolve_harness_rollout_snapshot_sync,
)

router = APIRouter(prefix="/api/v1/harness", tags=["harness"])


class HarnessMetricsResponse(BaseModel):
    token_count: int
    session_count: int
    tool_load_count: int
    recall_hit_rate: float
    failure_recovery_rate: float
    recall_hits: int
    recall_misses: int
    recovery_successes: int
    recovery_failures: int
    progressive_metadata_count: int
    progressive_body_load_count: int
    capability_resolution_count: int
    runtime_capability_resolution_count: int
    capability_resolution_fallback_count: int
    capability_inventory_cache_hits: int
    capability_inventory_cache_misses: int


class ContextCompactRequest(BaseModel):
    session_id: str = Field(..., min_length=1, max_length=128)
    context: list[dict[str, Any]] = Field(default_factory=list)
    max_turns: int = Field(default=8, ge=2, le=200)
    keep_recent: int = Field(default=4, ge=1, le=50)


class ContextCheckpointResponse(BaseModel):
    checkpoint_id: str
    tenant_id: str
    session_id: str
    summary: str
    created_at: str
    original_turn_count: int
    compacted_turn_count: int


class ContextCompactResponse(BaseModel):
    compacted: bool
    compacted_context: list[dict[str, str]]
    checkpoint: ContextCheckpointResponse | None = None


class PrecheckExecuteRequest(BaseModel):
    trigger: str = Field(..., min_length=1, max_length=128)
    payload: dict[str, Any] = Field(default_factory=dict)
    force_execute: bool = False


class PrecheckExecuteResponse(BaseModel):
    should_execute: bool
    reason: str
    execution_path: list[str]


class HarnessRolloutResponse(BaseModel):
    tenant_id: str
    harness_assertion_enforcement: str
    harness_main_path_policy: str
    harness_capability_graph: str
    harness_progressive_disclosure_prompt: str
    harness_state_mode: str


@router.get(
    "/metrics",
    response_model=HarnessMetricsResponse,
    summary="Get harness observability counters",
)
def get_harness_metrics(
    tenant_id: str = Depends(get_verified_tenant_id),  # noqa: ARG001
) -> HarnessMetricsResponse:
    harness = get_harness_runtime()
    snapshot = harness.metrics_snapshot()
    return HarnessMetricsResponse(**snapshot)


@router.get(
    "/rollout",
    response_model=HarnessRolloutResponse,
    summary="Get tenant-resolved harness rollout controls",
)
def get_harness_rollout(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> HarnessRolloutResponse:
    snapshot = resolve_harness_rollout_snapshot_sync(tenant_id)
    return HarnessRolloutResponse(tenant_id=tenant_id, **snapshot.to_dict())


@router.post(
    "/context/compact",
    response_model=ContextCompactResponse,
    summary="Compact long session context and persist checkpoint",
)
def compact_harness_context(
    body: ContextCompactRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ContextCompactResponse:
    harness = get_harness_runtime()
    result = harness.compact_context(
        tenant_id=tenant_id,
        session_id=body.session_id,
        context=body.context,
        max_turns=body.max_turns,
        keep_recent=body.keep_recent,
    )

    checkpoint = None
    if result.checkpoint is not None:
        checkpoint = ContextCheckpointResponse(**asdict(result.checkpoint))

    return ContextCompactResponse(
        compacted=result.compacted,
        compacted_context=result.compacted_context,
        checkpoint=checkpoint,
    )


@router.post(
    "/precheck/execute",
    response_model=PrecheckExecuteResponse,
    summary="Run Elvis precheck gate before agent execution",
)
def precheck_execute(
    body: PrecheckExecuteRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PrecheckExecuteResponse:
    del tenant_id
    harness = get_harness_runtime()
    decision = harness.evaluate_precheck(
        trigger=body.trigger,
        payload=body.payload,
        force_execute=body.force_execute,
    )
    return PrecheckExecuteResponse(**decision.to_dict())


__all__ = ["router"]
