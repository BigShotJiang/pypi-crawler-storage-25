"""API endpoints for Google Places venue discovery.

Issue #3616.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, status

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.models.place import (
    PlaceDiscoveryRequest,
    PlaceDiscoveryResponse,
)
from apps.backend.services.google_places_service import (
    GooglePlacesError,
    GooglePlacesService,
)

router = APIRouter(prefix="/api/v1/places", tags=["places"])


def _get_service() -> GooglePlacesService:
    """Create a GooglePlacesService from tenant settings.

    In production, the API key is resolved from tenant secrets.
    For now, uses the GOOGLE_MAPS_API_KEY environment variable.
    """
    import os

    api_key = os.environ.get("GOOGLE_MAPS_API_KEY", "")
    return GooglePlacesService(api_key=api_key)


@router.post(
    "/discover",
    response_model=PlaceDiscoveryResponse,
    responses={
        403: {"description": "Google Places API key invalid or missing"},
        429: {"description": "Google Places API rate limit exceeded"},
        502: {"description": "Google Places API unavailable"},
    },
)
async def discover_places(
    request: PlaceDiscoveryRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PlaceDiscoveryResponse:
    """Discover venues near a location using Google Places API."""
    service = _get_service()
    try:
        return await service.discover(tenant_id=tenant_id, request=request)
    except GooglePlacesError as exc:
        if exc.status_code == 403:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=str(exc),
            ) from exc
        if exc.status_code == 429:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail=str(exc),
            ) from exc
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail=str(exc),
        ) from exc
