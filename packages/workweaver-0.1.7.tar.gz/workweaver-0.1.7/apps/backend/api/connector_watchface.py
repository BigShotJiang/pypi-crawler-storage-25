"""Connector-hub watchface adapters (issue #1181).

The connector-hub UI (``apps/dashboard/components/workspace/connector-hub.html``)
was calling five endpoints that 404'd in production:

- ``GET /api/v1/connectors/catalog``           (browse catalog)
- ``POST /api/v1/connectors/install``          (install by body.connector_id)
- ``DELETE /api/v1/connectors/installed/{id}`` (uninstall)
- ``GET /api/v1/connectors/health/{id}``       (probe one connector)
- ``POST /api/v1/connectors/test/{id}/{action}`` (execute a test action)

Backend has similar data but at different paths — ``/catalog/available``,
``/{id}/install``, ``/{id}/uninstall``, ``/{id}/health``, ``/{id}/execute``
(``apps/backend/api/connectors.py``).

This module is the same pattern as ``mission_watchface.py`` and
``meeting_watchface.py``: thin canonical adapters that delegate to
existing handlers + normalize shapes + add the guards the UI assumes.

Structural properties (post GLM + Codex round-1 review):

1. Tenant from auth context only.
2. Catalog filtered to GA providers only (never expose beta / disabled
   entries — GLM finding).
3. Install flow validates connector_id against the catalog before
   handing off to the backend's ``/{provider_id}/install`` (GLM).
4. Uninstall blocks when the connector has active operations; a drain
   period is enforced via health probe (GLM).
5. Health is cached in-process for 30s per-tenant+connector to avoid
   DDoS'ing the provider under auto-refresh (GLM).
6. ``/test`` takes the action in the BODY not the path — Codex security
   finding. Path-based actions invite enumeration; body-based +
   allowlist makes enumeration expensive and auditable.
7. Every write endpoint (install, uninstall, test) emits a structured
   audit log with tenant_id + connector_id + action + result.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException, Path, Response
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.connectors.shared_connector_service import get_shared_connector_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/connectors", tags=["connector-watchface"])
_shared_connector_service = get_shared_connector_service()
_health_cache = _shared_connector_service.health_cache


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class CatalogEntry(BaseModel):
    connector_id: str
    name: str | None = None
    category: str | None = None
    description: str | None = None
    status: str = "generally_available"
    icon_url: str | None = None


class CatalogResponse(BaseModel):
    connectors: list[CatalogEntry] = Field(default_factory=list)
    count: int = 0


class InstallRequest(BaseModel):
    connector_id: str = Field(..., min_length=1, max_length=200)
    credentials: dict[str, Any] | None = None
    config: dict[str, Any] | None = None


class InstallResponse(BaseModel):
    connector_id: str
    status: str = "installed"
    health: str | None = None
    installed_at: str | None = None


class HealthResponse(BaseModel):
    connector_id: str
    status: str = "unknown"
    detail: str | None = None
    last_checked_at: str | None = None
    cached: bool = False


class TestRequest(BaseModel):
    connector_id: str = Field(..., min_length=1, max_length=200)
    action_id: str = Field(..., min_length=1, max_length=100, pattern=r"^[a-z0-9_\-\.]+$")


class TestResponse(BaseModel):
    connector_id: str
    action_id: str
    success: bool
    result: dict[str, Any] | None = None
    error: str | None = None
    evidence_id: str | None = None


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _hash_params(params: Any) -> str:
    """Stable short hash for audit log without logging raw params (PII)."""
    return _shared_connector_service.hash_params(params)


def _verify_connector_installed(tenant_id: str, connector_id: str) -> bool:
    """Return True iff ``connector_id`` is installed for ``tenant_id``."""
    return _shared_connector_service.verify_connector_installed(tenant_id, connector_id)


def _allowed_test_actions(connector_id: str) -> set[str]:
    """Resolve the whitelist of test actions for a connector.

    Always includes the generic ``ping`` action which every connector
    must support via its health probe.
    """
    return _shared_connector_service.allowed_test_actions(connector_id)


# ---------------------------------------------------------------------------
# GET /api/v1/connectors/catalog
# ---------------------------------------------------------------------------


@router.get("/catalog", response_model=CatalogResponse)
async def catalog(
    response: Response,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CatalogResponse:
    """Browsable connector catalog.

    Delegates to ``/catalog/available`` but strips any non-GA rows so
    the UI never shows beta/disabled connectors to a tenant (GLM flag).
    """
    response.headers["Cache-Control"] = "private, max-age=60"

    data = await _shared_connector_service.list_catalog(tenant_id=tenant_id)
    return CatalogResponse(
        connectors=[CatalogEntry(**item) for item in data["connectors"]],
        count=int(data["count"]),
    )


# ---------------------------------------------------------------------------
# POST /api/v1/connectors/install
# ---------------------------------------------------------------------------


@router.post("/install", response_model=InstallResponse, status_code=201)
async def install_by_body(
    response: Response,
    body: InstallRequest = Body(...),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> InstallResponse:
    """Install a connector using ``connector_id`` in the body.

    GLM round-1 finding: validate ``connector_id`` exists in the
    catalog and resolve it to the canonical ``provider_id`` the backend
    handler expects. Returns 404 if the ID isn't in the GA catalog.
    """
    response.headers["Cache-Control"] = "private, no-cache, no-store, must-revalidate"

    data = await _shared_connector_service.install_by_body(
        tenant_id=tenant_id,
        connector_id=body.connector_id,
        body=body,
    )
    return InstallResponse(**data)


# ---------------------------------------------------------------------------
# DELETE /api/v1/connectors/installed/{connector_id}
# ---------------------------------------------------------------------------


@router.delete("/installed/{connector_id}", status_code=204)
async def uninstall_by_id(
    response: Response,
    connector_id: str = Path(..., min_length=1, max_length=200),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> Response:
    """Uninstall a connector, draining active operations first.

    GLM round-1 finding: if the connector has active webhooks or
    running syncs, tearing it down synchronously can orphan resources.
    We probe health first and block uninstall if the connector is
    reporting active-ops. The backend handler still performs the actual
    teardown; this adapter adds the drain guard.
    """
    response.headers["Cache-Control"] = "private, no-cache, no-store, must-revalidate"

    await _shared_connector_service.uninstall_by_id(tenant_id=tenant_id, connector_id=connector_id)
    response.status_code = 204
    return response


# ---------------------------------------------------------------------------
# GET /api/v1/connectors/health/{connector_id}
# ---------------------------------------------------------------------------


async def _probe_health(tenant_id: str, connector_id: str, *, use_cache: bool = True) -> dict[str, Any]:
    """Probe connector health with a per-tenant+connector 30s cache.

    GLM round-1: under auto-refresh (every 5s × N connectors) the
    naïve pass-through would DDoS the provider. The cache coalesces
    bursty probes.
    """
    return await _shared_connector_service.probe_health(
        tenant_id=tenant_id,
        connector_id=connector_id,
        use_cache=use_cache,
    )


@router.get("/health/{connector_id}", response_model=HealthResponse)
async def health_by_id(
    response: Response,
    connector_id: str = Path(..., min_length=1, max_length=200),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> HealthResponse:
    """Probe one connector's health. 30s per-tenant+connector cache."""
    response.headers["Cache-Control"] = "private, max-age=30"

    data = await _probe_health(tenant_id, connector_id, use_cache=True)
    return HealthResponse(
        connector_id=connector_id,
        status=str(data.get("status") or "unknown"),
        detail=data.get("detail"),
        last_checked_at=data.get("last_checked_at") or data.get("checked_at"),
        cached=bool(data.get("cached", False)),
    )


# ---------------------------------------------------------------------------
# POST /api/v1/connectors/test  (body-driven — Codex security fix)
# ---------------------------------------------------------------------------


@router.post("/test", response_model=TestResponse)
async def test_connector_action(
    response: Response,
    body: TestRequest = Body(...),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> TestResponse:
    """Execute an allowlisted test action against an installed connector.

    Codex round-1 security fix: the original UI path was
    ``/test/{connector_id}/{action_id}`` which invites enumeration via
    path traversal. This adapter requires the action in the body and
    rejects anything outside the per-connector allowlist with a generic
    404 (so an attacker can't distinguish "unknown action" from
    "forbidden action").
    """
    response.headers["Cache-Control"] = "private, no-cache, no-store, must-revalidate"

    # Auth: connector must be installed for this tenant.
    if not _verify_connector_installed(tenant_id, body.connector_id):
        # Generic 404 so enumeration is opaque.
        raise HTTPException(status_code=404, detail="connector_not_installed_or_unknown")

    # Auth: action must be on the allowlist for this connector.
    allowed = _allowed_test_actions(body.connector_id)
    if body.action_id not in allowed:
        logger.info(
            "connector_test_action_rejected",
            extra={
                "tenant_id": tenant_id,
                "connector_id": body.connector_id,
                "action_id": body.action_id,
            },
        )
        raise HTTPException(status_code=404, detail="connector_not_installed_or_unknown")

    data = await _shared_connector_service.execute_test_action(
        tenant_id=tenant_id,
        connector_id=body.connector_id,
        action_id=body.action_id,
    )
    return TestResponse(**data)


__all__ = ["router"]
