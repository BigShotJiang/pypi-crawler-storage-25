"""Entity Relationships API (PR-CB5 — Icarus bar).

Endpoints:
    GET /api/v1/entities/{entity_id}/relationships — cross-entity interaction history

Aggregates interactions from WorkItem, Thread, and Evidence stores.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities", tags=["entity-relationships"])

# In-memory interaction store (tenant_id -> entity_id -> list of interactions)
# In production, this aggregates from WorkItem + Thread + Evidence stores via DynamoDB queries.
_interaction_store: dict[str, dict[str, list[dict[str, Any]]]] = {}


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class InteractionRecord(BaseModel):
    interaction_id: str
    interaction_type: str = Field(
        ...,
        description="Type: work_item, thread, meeting, evidence",
    )
    counterparty_entity_id: str | None = None
    summary: str = ""
    timestamp: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


class RelationshipsResponse(BaseModel):
    entity_id: str
    interactions: list[InteractionRecord] = Field(default_factory=list)
    total: int = 0


# ---------------------------------------------------------------------------
# Store access helpers
# ---------------------------------------------------------------------------


def _get_workitem_service() -> Any:
    try:
        from apps.backend.services.execution.workitem_service import get_workitem_service

        return get_workitem_service()
    except Exception:
        return None


def _get_thread_store() -> Any:
    try:
        from apps.backend.services.thread_store import get_thread_store

        return get_thread_store()
    except Exception:
        return None


def _get_evidence_store() -> Any:
    try:
        from apps.backend.services.memory_store import get_evidence_store

        return get_evidence_store()
    except Exception:
        return None


async def _aggregate_interactions(
    tenant_id: str,
    entity_id: str,
    limit: int,
) -> list[InteractionRecord]:
    """Aggregate interactions from multiple stores.

    Queries WorkItem, Thread, and Evidence stores first. Falls back to
    in-memory store only when all service dependencies are unavailable.
    """
    interactions: list[InteractionRecord] = []
    any_store_available = False

    # Attempt WorkItem store aggregation
    workitem_svc = _get_workitem_service()
    if workitem_svc is not None:
        try:
            items = await workitem_svc.list_by_entity(
                tenant_id=tenant_id,
                entity_id=entity_id,
                limit=limit,
            )
            any_store_available = True
            for item in items:
                interactions.append(
                    InteractionRecord(
                        interaction_id=str(getattr(item, "id", "")),
                        interaction_type="work_item",
                        summary=str(getattr(item, "title", "")),
                        timestamp=str(getattr(item, "created_at", "")),
                    )
                )
        except Exception:
            logger.debug("workitem_aggregation_unavailable", exc_info=True)

    # Attempt Thread store aggregation
    thread_store = _get_thread_store()
    if thread_store is not None:
        try:
            threads = await thread_store.list_by_entity(
                tenant_id=tenant_id,
                entity_id=entity_id,
                limit=limit,
            )
            any_store_available = True
            for thread in threads:
                interactions.append(
                    InteractionRecord(
                        interaction_id=str(getattr(thread, "id", "")),
                        interaction_type="thread",
                        summary=str(getattr(thread, "subject", "")),
                        timestamp=str(getattr(thread, "created_at", "")),
                    )
                )
        except Exception:
            logger.debug("thread_aggregation_unavailable", exc_info=True)

    # Attempt Evidence store aggregation
    evidence_store = _get_evidence_store()
    if evidence_store is not None:
        try:
            evidence_items = await evidence_store.list_by_entity(
                tenant_id=tenant_id,
                entity_id=entity_id,
                limit=limit,
            )
            any_store_available = True
            for ev in evidence_items:
                interactions.append(
                    InteractionRecord(
                        interaction_id=str(getattr(ev, "id", "")),
                        interaction_type="evidence",
                        summary=str(getattr(ev, "description", "")),
                        timestamp=str(getattr(ev, "created_at", "")),
                    )
                )
        except Exception:
            logger.debug("evidence_aggregation_unavailable", exc_info=True)

    # In-memory fallback only when no durable store query succeeded
    if not any_store_available:
        tenant_store = _interaction_store.get(tenant_id, {})
        entity_records = tenant_store.get(entity_id, [])
        for rec in entity_records:
            interactions.append(InteractionRecord(**rec))

    # Sort by timestamp descending, limit
    interactions.sort(key=lambda r: r.timestamp, reverse=True)
    return interactions[:limit]


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("/{entity_id}/relationships", response_model=RelationshipsResponse)
async def get_entity_relationships(
    entity_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(50, ge=1, le=500, description="Maximum interactions to return"),
) -> RelationshipsResponse:
    """Return cross-entity interaction history.

    Aggregates interactions (WorkItems, threads, meetings, evidence) involving
    this entity from multiple stores.
    """
    interactions = await _aggregate_interactions(
        tenant_id=tenant_id,
        entity_id=entity_id,
        limit=limit,
    )

    return RelationshipsResponse(
        entity_id=entity_id,
        interactions=interactions,
        total=len(interactions),
    )
