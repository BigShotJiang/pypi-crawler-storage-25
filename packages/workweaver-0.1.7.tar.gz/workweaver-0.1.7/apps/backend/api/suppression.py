"""Suppression management API.

Manual CRUD and import endpoints for tenant-scoped delivery suppression records.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, Field

from apps.backend.models.suppression import (
    SuppressionAuditEvent,
    SuppressionChannel,
    SuppressionRecord,
)

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.suppression_store import SuppressionStore, get_suppression_store

router = APIRouter(prefix="/api/v1/suppression", tags=["suppression"])


def _actor_from_request(request: Request) -> str:
    """Extract actor from verified auth state. No raw header fallback in production."""
    state_user = str(getattr(request.state, "user_id", "") or "").strip()
    if state_user:
        return state_user
    return "system"


class SuppressionUpsertRequest(BaseModel):
    """Manual suppression create/update payload."""

    channel: SuppressionChannel
    identifier: str = Field(..., description="Email or WhatsApp E.164 identifier")
    reason: str = Field(..., description="manual|unsubscribe|bounce|complaint|invalid|legal")
    source: str = Field(default="manual")
    metadata: dict[str, Any] = Field(default_factory=dict)


class SuppressionImportRequest(BaseModel):
    """Bulk suppression import payload."""

    records: list[SuppressionUpsertRequest] = Field(..., min_length=1)
    source: str | None = Field(default="import")


class SuppressionResponse(BaseModel):
    """Suppression record response model."""

    channel: str
    identifier: str
    identifier_normalized: str
    reason: str
    source: str
    actor: str
    metadata: dict[str, Any]
    created_at: str
    updated_at: str

    @classmethod
    def from_record(cls, record: SuppressionRecord) -> SuppressionResponse:
        return cls(
            channel=record.channel.value,
            identifier=record.identifier,
            identifier_normalized=record.identifier_normalized,
            reason=record.reason.value,
            source=record.source,
            actor=record.actor,
            metadata=record.metadata,
            created_at=record.created_at,
            updated_at=record.updated_at,
        )


class SuppressionListResponse(BaseModel):
    """List suppression records response."""

    total: int
    records: list[SuppressionResponse]


class SuppressionImportResponse(BaseModel):
    """Bulk import results response."""

    created: int
    updated: int
    failed: int
    errors: list[dict[str, Any]] = Field(default_factory=list)
    records: list[SuppressionResponse] = Field(default_factory=list)


class SuppressionAuditResponse(BaseModel):
    """Suppression audit response."""

    total: int
    events: list[dict[str, Any]]


@router.get("", response_model=SuppressionListResponse)
def list_suppressions(
    channel: SuppressionChannel | None = Query(default=None),
    limit: int = Query(default=200, ge=1, le=1000),
    tenant_id: str = Depends(get_verified_tenant_id),
    store: SuppressionStore = Depends(get_suppression_store),
) -> SuppressionListResponse:
    records = store.list_records(tenant_id, channel=channel, limit=limit)
    return SuppressionListResponse(
        total=len(records),
        records=[SuppressionResponse.from_record(record) for record in records],
    )


@router.post("", response_model=SuppressionResponse, status_code=status.HTTP_201_CREATED)
def upsert_suppression(
    payload: SuppressionUpsertRequest,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
    store: SuppressionStore = Depends(get_suppression_store),
) -> SuppressionResponse:
    actor = _actor_from_request(request)
    try:
        record, _ = store.upsert(
            tenant_id=tenant_id,
            channel=payload.channel,
            identifier=payload.identifier,
            reason=payload.reason,
            source=payload.source,
            actor=actor,
            metadata=payload.metadata,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid request parameters") from exc

    return SuppressionResponse.from_record(record)


@router.delete("")
def delete_suppression(
    request: Request,
    channel: SuppressionChannel = Query(...),
    identifier: str = Query(...),
    tenant_id: str = Depends(get_verified_tenant_id),
    store: SuppressionStore = Depends(get_suppression_store),
) -> dict[str, Any]:
    actor = _actor_from_request(request)
    removed = store.delete_record(
        tenant_id=tenant_id,
        channel=channel,
        identifier=identifier,
        actor=actor,
        source="manual_delete",
    )
    if not removed:
        raise HTTPException(status_code=404, detail="Suppression record not found")
    return {"deleted": True, "channel": channel.value, "identifier": identifier}


@router.post("/import", response_model=SuppressionImportResponse, status_code=status.HTTP_201_CREATED)
def import_suppressions(
    payload: SuppressionImportRequest,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
    store: SuppressionStore = Depends(get_suppression_store),
) -> SuppressionImportResponse:
    actor = _actor_from_request(request)
    result = store.import_records(
        tenant_id=tenant_id,
        records=[record.model_dump() for record in payload.records],
        actor=actor,
        source=str(payload.source or "import"),
    )
    return SuppressionImportResponse(
        created=result["created"],
        updated=result["updated"],
        failed=result["failed"],
        errors=result["errors"],
        records=[SuppressionResponse.from_record(record) for record in result["records"]],
    )


@router.get("/audit", response_model=SuppressionAuditResponse)
def list_suppression_audit(
    limit: int = Query(default=200, ge=1, le=1000),
    tenant_id: str = Depends(get_verified_tenant_id),
    store: SuppressionStore = Depends(get_suppression_store),
) -> SuppressionAuditResponse:
    events: list[SuppressionAuditEvent] = store.list_audit_events(tenant_id, limit=limit)
    return SuppressionAuditResponse(
        total=len(events),
        events=[
            {
                "action": event.action,
                "channel": event.channel,
                "identifier_normalized": event.identifier_normalized,
                "reason": event.reason,
                "source": event.source,
                "actor": event.actor,
                "metadata": event.metadata,
                "created_at": event.created_at,
            }
            for event in events
        ],
    )
