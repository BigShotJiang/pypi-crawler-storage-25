"""Deployment profile and capability discovery endpoint.

Returns the active deployment profile and which capabilities are available
under it, so the frontend can render cloud-only badges and adjust UX.

ADR-006, issue #1616.
"""

from __future__ import annotations

from fastapi import APIRouter

from apps.backend.providers.base import (
    DeploymentProfile,
    get_deployment_profile,
)

router = APIRouter(prefix="/api/v1", tags=["profile"])

# Cloud-only capabilities. When running under local_native or standalone,
# these are unavailable unless the user has run `ww login`.
_CLOUD_ONLY_CAPABILITIES = {
    "cognito_auth": {DeploymentProfile.managed_saas},
    "ses_email": {DeploymentProfile.managed_saas, DeploymentProfile.self_host_production},
    "bedrock_embeddings": {DeploymentProfile.managed_saas},
    "scheduled_jobs": {DeploymentProfile.managed_saas, DeploymentProfile.self_host_production},
    "cross_device_sync": {
        DeploymentProfile.managed_saas,
        DeploymentProfile.self_host_production,
        DeploymentProfile.standalone,
    },
}


@router.get("/profile")
def get_profile() -> dict:
    profile = get_deployment_profile()
    capabilities = {
        name: profile in allowed_profiles
        for name, allowed_profiles in _CLOUD_ONLY_CAPABILITIES.items()
    }
    return {
        "profile": profile.value,
        "capabilities": capabilities,
    }
