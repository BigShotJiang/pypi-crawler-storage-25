"""Embeddings proxy (#1998).

Edge surfaces (``ww`` CLI) rely on the cloud-managed embedding provider that
the tenant configured globally — typically Bedrock Titan Embeddings or
OpenAI's ``text-embedding-3-small``. Self-hosted deployments bypass this and
talk to their local provider directly; the CLI's mode-awareness layer picks
the right path before issuing the call (see ``apps/cli/ww/config.py``).

This router exposes:

* ``POST /api/v1/embeddings`` — one-call proxy that resolves the tenant's
  configured embedding provider, fetches credentials via the admin resolver,
  and forwards the call. The wire shape mimics the OpenAI Embeddings API so
  the CLI can keep one transport layer.

The proxy refuses to run in self-host mode unless the tenant's admin has
explicitly enabled cloud embedding fallback. This mirrors the privacy posture
self-hosted users expect.
"""

from __future__ import annotations

import hashlib
import logging

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)


router = APIRouter(prefix="/api/v1/embeddings", tags=["embeddings"])


class EmbeddingsRequest(BaseModel):
    """OpenAI-compatible embeddings request."""

    input: list[str] | str = Field(..., description="Text or list of texts to embed")
    model: str = Field("auto", description="Model name; 'auto' uses tenant default")
    encoding_format: str = Field("float", description="float | base64")


class EmbeddingItem(BaseModel):
    object: str = "embedding"
    index: int
    embedding: list[float]


class EmbeddingsResponse(BaseModel):
    object: str = "list"
    data: list[EmbeddingItem]
    model: str
    usage: dict[str, int] = Field(default_factory=dict)
    provider: str = ""


class EmbeddingProvider:
    """Minimal protocol the resolver returns."""

    name: str
    model: str

    def embed(self, texts: list[str]) -> list[list[float]]:  # pragma: no cover - protocol
        raise NotImplementedError


class TenantEmbeddingResolver:
    """Resolve the embedding provider for a tenant from tenant_config.

    For now the resolver returns a deterministic stub embedding (hash-derived)
    when no provider is wired — this keeps the proxy testable end-to-end
    without binding to a specific cloud SDK. Production wiring overrides via
    ``set_embedding_resolver``.
    """

    def resolve(self, tenant_id: str, requested_model: str) -> EmbeddingProvider:
        return _StubEmbeddingProvider(tenant_id=tenant_id, model=requested_model)


class _StubEmbeddingProvider(EmbeddingProvider):
    name = "stub"

    def __init__(self, tenant_id: str, model: str) -> None:
        self.tenant_id = tenant_id
        self.model = model if model != "auto" else "stub-embedding-v1"

    def embed(self, texts: list[str]) -> list[list[float]]:
        out: list[list[float]] = []
        for text in texts:
            digest = hashlib.sha256(
                f"{self.tenant_id}\0{text}".encode("utf-8")
            ).digest()
            seed_int = int.from_bytes(digest[:8], "big") % 10_000
            seed = float(seed_int) / 10_000.0
            out.append([seed, 1.0 - seed, seed * seed])
        return out


_resolver: TenantEmbeddingResolver = TenantEmbeddingResolver()


def set_embedding_resolver(resolver: TenantEmbeddingResolver) -> None:
    """Production wiring hook (called by main.py during startup)."""

    global _resolver
    _resolver = resolver


def get_embedding_resolver() -> TenantEmbeddingResolver:
    return _resolver


@router.post("", response_model=EmbeddingsResponse)
async def embed(
    payload: EmbeddingsRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    resolver: TenantEmbeddingResolver = Depends(get_embedding_resolver),
) -> EmbeddingsResponse:
    texts = [payload.input] if isinstance(payload.input, str) else list(payload.input)
    if not texts:
        raise HTTPException(status_code=422, detail="input must contain at least one string")
    provider = resolver.resolve(tenant_id, payload.model)
    vectors = provider.embed(texts)
    return EmbeddingsResponse(
        data=[
            EmbeddingItem(index=i, embedding=list(v)) for i, v in enumerate(vectors)
        ],
        model=getattr(provider, "model", payload.model),
        usage={"prompt_tokens": sum(len(t) for t in texts), "total_tokens": sum(len(t) for t in texts)},
        provider=getattr(provider, "name", "stub"),
    )
