"""Node, org graph, inbox, and training endpoints for Mission Control."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    resolve_authenticated_impersonator_id,
)
from apps.backend.api import mission_shared
from datetime import UTC

logger = logging.getLogger(__name__)
router = APIRouter()


class CreateNodeRequest(BaseModel):
    node_type: str = Field(..., max_length=50, description="Type of node (org, dept, team, agent, skill)")
    name: str = Field(..., max_length=200, description="Display name of the node")
    description: str = Field("", max_length=5000, description="Optional description")
    parent_node_id: str | None = Field(None, max_length=100, description="Parent node ID for hierarchy")
    config: dict = Field(default_factory=dict, description="Node configuration")
    metadata: dict = Field(default_factory=dict, description="Additional metadata")


class UpdateNodeRequest(BaseModel):
    name: str | None = Field(None, max_length=200, description="Updated name")
    description: str | None = Field(None, max_length=5000, description="Updated description")
    parent_node_id: str | None = Field(
        None,
        max_length=100,
        description="Updated parent node ID (org can only be root; other node types require valid parent)",
    )
    config: dict | None = Field(None, description="Updated configuration")
    metadata: dict | None = Field(None, description="Updated metadata")
    revision: int = Field(..., description="Current revision for optimistic locking")


class UpdateStatusRequest(BaseModel):
    status: str = Field(..., max_length=50, description="New status (idle, active, thinking, blocked, error)")


class TeachRequest(BaseModel):
    context: str = Field(..., max_length=10000, description="Context or situation that triggered the teaching moment")
    lesson: str = Field(..., max_length=10000, description="What the AI should learn or improve")
    execution_id: str | None = Field(None, max_length=100, description="Related execution ID if applicable")
    tenant_id: str = Field(..., max_length=100, description="Tenant ID")
    metadata: dict = Field(default_factory=dict, description="Additional metadata")


class EscalateRequest(BaseModel):
    reason: str = Field(..., max_length=5000, description="Reason for escalation")
    context: str = Field(..., max_length=10000, description="Context of the situation requiring escalation")
    urgency: str = Field("normal", max_length=50, description="Urgency level: low, normal, high, critical")
    execution_id: str | None = Field(None, max_length=100, description="Related execution ID if applicable")
    tenant_id: str = Field(..., max_length=100, description="Tenant ID")
    metadata: dict = Field(default_factory=dict, description="Additional metadata")


class TeachResponse(BaseModel):
    success: bool
    message: str
    teaching_id: str = Field(..., description="ID of the created teaching record")


class EscalateResponse(BaseModel):
    success: bool
    message: str
    escalation_id: str = Field(..., description="ID of the created escalation")
    approval_queue_url: str | None = Field(None, description="URL to view in approval queue")


class NodeResponse(BaseModel):
    node_id: str
    node_type: str
    name: str
    description: str
    status: str
    parent_node_id: str | None
    created_at: str
    updated_at: str
    revision: int
    config: dict = Field(default_factory=dict)
    metadata: dict = Field(default_factory=dict)


class NodeListResponse(BaseModel):
    nodes: list[NodeResponse]
    count: int


class OrgTreeResponse(BaseModel):
    tree: dict
    total_nodes: int


class InboxResponse(BaseModel):
    items: list[dict]
    count: int


class ActivityPulseResponse(BaseModel):
    active_count: int
    thinking_count: int
    idle_count: int
    blocked_count: int
    error_count: int
    total_nodes: int


_NODE_TYPE_TO_MEMORY_SCOPE: dict[str, str] = {
    "org": "org",
    "department": "department",
    "team": "team",
}


def _seed_node_memory(tenant_id: str, node: dict[str, Any]) -> None:
    """Seed memory scope for a newly created org/department/team node.

    Best-effort: failures are logged but never block node creation.
    """
    node_type = str(node.get("node_type", ""))
    scope = _NODE_TYPE_TO_MEMORY_SCOPE.get(node_type)
    if not scope:
        return

    try:
        from apps.backend.services.memory.service import get_memory_service

        memory_service = get_memory_service()
        node_id = str(node.get("node_id", ""))
        name = str(node.get("name", ""))
        description = str(node.get("description", ""))

        memory_service.store_fact(
            tenant_id=tenant_id,
            key=f"{node_type}_name",
            value=name,
            scope=scope,
            source="system",
            agent_id=node_id,
        )

        if description.strip():
            memory_service.store_fact(
                tenant_id=tenant_id,
                key=f"{node_type}_description",
                value=description,
                scope=scope,
                source="system",
                agent_id=node_id,
            )

        config = node.get("config") or {}
        if config:
            memory_service.store_fact(
                tenant_id=tenant_id,
                key=f"{node_type}_config",
                value=str(config),
                scope=scope,
                source="system",
                agent_id=node_id,
            )

        parent_node_id = node.get("parent_node_id")
        if parent_node_id:
            memory_service.store_fact(
                tenant_id=tenant_id,
                key=f"{node_type}_parent",
                value=str(parent_node_id),
                scope=scope,
                source="system",
                agent_id=node_id,
            )

        logger.info(
            "Seeded memory scope=%s for %s node %s (tenant=%s)",
            scope,
            node_type,
            node_id,
            tenant_id,
        )
    except Exception:
        logger.warning(
            "Memory seeding failed for %s node %s (tenant=%s)",
            node_type,
            node.get("node_id", ""),
            tenant_id,
            exc_info=True,
        )


def _node_response_from_item(item: dict[str, Any]) -> NodeResponse:
    return NodeResponse(
        node_id=item["node_id"],
        node_type=item["node_type"],
        name=item["name"],
        description=item.get("description", ""),
        status=item.get("status", "idle"),
        parent_node_id=item.get("parent_node_id"),
        created_at=item["created_at"],
        updated_at=item["updated_at"],
        revision=item["revision"],
        config=item.get("config", {}),
        metadata=item.get("metadata", {}),
    )


@router.get("/nodes", response_model=NodeListResponse)
async def list_nodes(
    tenant_id: str = Depends(get_verified_tenant_id),
    node_type: str | None = Query(None, description="Filter by node type"),
    parent_node_id: str | None = Query(None, description="Filter by parent node"),
    limit: int = Query(200, ge=1, le=500, description="Max nodes to return"),
):
    try:
        store = mission_shared.get_store()
        filtered_nodes = store.list_nodes(tenant_id)
        if node_type:
            filtered_nodes = [node for node in filtered_nodes if node.get("node_type") == node_type]
        if parent_node_id:
            filtered_nodes = [node for node in filtered_nodes if node.get("parent_node_id") == parent_node_id]
        nodes = [_node_response_from_item(node) for node in filtered_nodes[:limit]]
        return NodeListResponse(nodes=nodes, count=len(nodes))
    except Exception as exc:
        logger.error("Failed to list nodes: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to list nodes")


@router.post("/nodes", response_model=NodeResponse, status_code=201)
async def create_node(
    request: CreateNodeRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        store = mission_shared.get_store()
        node = store.create_node(
            tenant_id=tenant_id,
            node_type=request.node_type,
            name=request.name,
            description=request.description,
            parent_node_id=request.parent_node_id,
            config=request.config,
            metadata=request.metadata,
        )
        if node.get("node_type") in {"department", "team", "agent"}:
            try:
                collab = mission_shared.get_collaboration()
                all_nodes = store.list_nodes(tenant_id)
                node_type = str(node.get("node_type", ""))
                node_id = str(node.get("node_id", ""))
                if node_type == "department":
                    await collab.upsert_named_channel(
                        tenant_id=tenant_id,
                        name=f"#dept-{mission_shared.slugify_channel_name(str(node.get('name', '')))}",
                        scope=node_type,
                        agent_ids=mission_shared.collect_department_agent_ids(all_nodes, node_id),
                        topic=f"Department coordination for {node.get('name', '')}",
                    )
                elif node_type == "team":
                    await collab.upsert_named_channel(
                        tenant_id=tenant_id,
                        name=f"#team-{mission_shared.slugify_channel_name(str(node.get('name', '')))}",
                        scope=node_type,
                        agent_ids=mission_shared.collect_team_agent_ids(all_nodes, node_id),
                        topic=f"Team coordination for {node.get('name', '')}",
                    )
                    department_id = str(node.get("parent_node_id", ""))
                    department_node = next(
                        (
                            item
                            for item in all_nodes
                            if item.get("node_type") == "department" and str(item.get("node_id", "")) == department_id
                        ),
                        None,
                    )
                    if department_node:
                        await collab.upsert_named_channel(
                            tenant_id=tenant_id,
                            name=f"#dept-{mission_shared.slugify_channel_name(str(department_node.get('name', '')))}",
                            scope="department",
                            agent_ids=mission_shared.collect_department_agent_ids(all_nodes, department_id),
                            topic=f"Department coordination for {department_node.get('name', '')}",
                        )
                else:
                    team_id = str(node.get("parent_node_id", ""))
                    team_node = next(
                        (
                            item
                            for item in all_nodes
                            if item.get("node_type") == "team" and str(item.get("node_id", "")) == team_id
                        ),
                        None,
                    )
                    if team_node:
                        await collab.upsert_named_channel(
                            tenant_id=tenant_id,
                            name=f"#team-{mission_shared.slugify_channel_name(str(team_node.get('name', '')))}",
                            scope="team",
                            agent_ids=mission_shared.collect_team_agent_ids(all_nodes, team_id),
                            topic=f"Team coordination for {team_node.get('name', '')}",
                        )
                        department_id = str(team_node.get("parent_node_id", ""))
                        department_node = next(
                            (
                                item
                                for item in all_nodes
                                if item.get("node_type") == "department"
                                and str(item.get("node_id", "")) == department_id
                            ),
                            None,
                        )
                        if department_node:
                            await collab.upsert_named_channel(
                                tenant_id=tenant_id,
                                name=f"#dept-{mission_shared.slugify_channel_name(str(department_node.get('name', '')))}",
                                scope="department",
                                agent_ids=mission_shared.collect_department_agent_ids(all_nodes, department_id),
                                topic=f"Department coordination for {department_node.get('name', '')}",
                            )
            except Exception:
                logger.warning(
                    "Mission channel auto-sync failed tenant=%s node=%s",
                    tenant_id,
                    node.get("node_id", ""),
                    exc_info=True,
                )
        # Seed memory scope for org/department/team nodes (best-effort)
        if node.get("node_type") in _NODE_TYPE_TO_MEMORY_SCOPE:
            _seed_node_memory(tenant_id, node)

        return _node_response_from_item(node)
    except ValueError as exc:
        logger.error("Node creation failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to create node: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to create node")


@router.get("/nodes/{node_id}", response_model=NodeResponse)
async def get_node(
    node_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        node = mission_shared.get_store().get_node(tenant_id, node_id)
        if not node:
            raise HTTPException(status_code=404, detail=f"Node {node_id} not found")
        return _node_response_from_item(node)
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Failed to get node: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to get node")


@router.put("/nodes/{node_id}", response_model=NodeResponse)
async def update_node(
    node_id: str,
    request: UpdateNodeRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        updates = {}
        if request.name is not None:
            updates["name"] = request.name
        if request.description is not None:
            updates["description"] = request.description
        if request.parent_node_id is not None:
            updates["parent_node_id"] = request.parent_node_id
        if request.config is not None:
            updates["config"] = request.config
        if request.metadata is not None:
            updates["metadata"] = request.metadata
        node = mission_shared.get_store().update_node(
            tenant_id=tenant_id,
            node_id=node_id,
            expected_revision=request.revision,
            updates=updates,
        )
        if not node:
            raise HTTPException(status_code=404, detail=f"Node {node_id} not found")
        return _node_response_from_item(node)
    except HTTPException:
        raise
    except ValueError as exc:
        logger.error("Node update conflict: %s", exc, exc_info=True)
        raise HTTPException(status_code=409, detail="Conflict")
    except Exception as exc:
        logger.error("Failed to update node: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to update node")


@router.delete("/nodes/{node_id}")
async def delete_node(
    node_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        success = mission_shared.get_store().delete_node(tenant_id, node_id)
        if not success:
            raise HTTPException(status_code=404, detail=f"Node {node_id} not found")
        return {"deleted": True}
    except HTTPException:
        raise
    except ValueError as exc:
        logger.error("Node deletion failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to delete node: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to delete node")


@router.put("/nodes/{node_id}/status", response_model=NodeResponse)
async def update_node_status(
    node_id: str,
    request: UpdateStatusRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        node = mission_shared.get_store().update_status(tenant_id, node_id, request.status)
        if not node:
            raise HTTPException(status_code=404, detail=f"Node {node_id} not found")
        try:
            bus = mission_shared.get_event_bus()
            await bus.publish(
                tenant_id=tenant_id,
                event_type="STATUS_CHANGE",
                data={"node_id": node_id, "status": request.status, "node_type": str(node.get("node_type", ""))},
            )
        except Exception:
            logger.warning(
                "Failed to publish status change event tenant=%s node=%s",
                tenant_id,
                node_id,
                exc_info=True,
            )
        return _node_response_from_item(node)
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Failed to update status: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to update status")


@router.get("/tree", response_model=OrgTreeResponse)
async def get_org_tree(
    tenant_id: str = Depends(get_verified_tenant_id),
):
    def _count_tree_nodes(nodes: list[dict[str, Any]]) -> int:
        total = 0
        stack: list[dict[str, Any]] = [node for node in nodes if isinstance(node, dict)]
        while stack:
            node = stack.pop()
            total += 1
            children = node.get("children", [])
            if isinstance(children, list):
                stack.extend(child for child in children if isinstance(child, dict))
        return total

    try:
        tree = mission_shared.get_store().get_tree(tenant_id)
        if isinstance(tree, dict):
            raw_roots = tree.get("roots", [])
            roots = raw_roots if isinstance(raw_roots, list) else []
            total = int(tree.get("total_nodes", _count_tree_nodes(roots)))
        elif isinstance(tree, list):
            roots = [node for node in tree if isinstance(node, dict)]
            total = _count_tree_nodes(roots)
        else:
            roots = []
            total = 0
        return OrgTreeResponse(tree={"roots": roots}, total_nodes=total)
    except Exception as exc:
        logger.error("Failed to get tree: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to get tree")


@router.get("/inbox", response_model=InboxResponse)
async def get_inbox(
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(20, ge=1, le=200, description="Max items to return"),
):
    try:
        result = mission_shared.get_approval_gates().list_pending_approvals(tenant_id=tenant_id)
        if not result.success:
            return InboxResponse(items=[], count=0)
        approvals = result.metadata.get("approvals", [])[:limit]
        return InboxResponse(items=approvals, count=len(approvals))
    except Exception as exc:
        logger.error("Failed to get inbox: %s", exc)
        return InboxResponse(items=[], count=0)


@router.get("/activity", response_model=ActivityPulseResponse)
async def get_activity_pulse(
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        nodes = mission_shared.get_store().list_nodes(tenant_id)
        status_counts = {"active": 0, "thinking": 0, "idle": 0, "blocked": 0, "error": 0}
        for node in nodes:
            status = node.get("status", "idle")
            if status in status_counts:
                status_counts[status] += 1
        return ActivityPulseResponse(
            active_count=status_counts["active"],
            thinking_count=status_counts["thinking"],
            idle_count=status_counts["idle"],
            blocked_count=status_counts["blocked"],
            error_count=status_counts["error"],
            total_nodes=len(nodes),
        )
    except Exception as exc:
        logger.error("Failed to get activity pulse: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to get activity pulse")


@router.post("/teach", response_model=TeachResponse, status_code=201)
async def teach_ai(payload: TeachRequest, http_request: Request):
    try:
        from datetime import datetime
        import uuid

        from apps.backend.services.audit_logger import AuditAction, get_audit_logger

        teaching_id = f"TEACH#{uuid.uuid4().hex[:12]}"
        get_audit_logger().log(
            action=AuditAction.AI_TEACHING_RECORDED,
            tenant_id=payload.tenant_id,
            user_id="human",
            resource_type="teaching",
            resource_id=teaching_id,
            impersonator_id=resolve_authenticated_impersonator_id(http_request),
            metadata={
                "context": payload.context,
                "lesson": payload.lesson,
                "execution_id": payload.execution_id,
                "timestamp": datetime.now(UTC).isoformat(),
                **payload.metadata,
            },
        )
        return TeachResponse(
            success=True,
            message="Teaching recorded successfully. AI will incorporate this lesson.",
            teaching_id=teaching_id,
        )
    except Exception as exc:
        logger.error("Failed to record teaching: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to record teaching")


@router.post("/escalate", response_model=EscalateResponse, status_code=201)
async def escalate_to_human(payload: EscalateRequest, http_request: Request):
    try:
        from datetime import datetime
        import uuid

        from apps.backend.services.approval_gates import get_approval_gates
        from apps.backend.services.audit_logger import AuditAction, get_audit_logger

        escalation_id = f"ESC#{uuid.uuid4().hex[:12]}"
        get_approval_gates()
        get_audit_logger().log(
            action=AuditAction.AI_ESCALATION_CREATED,
            tenant_id=payload.tenant_id,
            user_id="ai_agent",
            resource_type="escalation",
            resource_id=escalation_id,
            impersonator_id=resolve_authenticated_impersonator_id(http_request),
            metadata={
                "reason": payload.reason,
                "context": payload.context,
                "urgency": payload.urgency,
                "execution_id": payload.execution_id,
                "timestamp": datetime.now(UTC).isoformat(),
                **payload.metadata,
            },
        )
        return EscalateResponse(
            success=True,
            message=f"Escalation created with {payload.urgency} urgency. Human review required.",
            escalation_id=escalation_id,
            approval_queue_url=f"/mission/approvals/{escalation_id}",
        )
    except Exception as exc:
        logger.error("Failed to create escalation: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to create escalation")


__all__ = [
    "CreateNodeRequest",
    "UpdateNodeRequest",
    "UpdateStatusRequest",
    "TeachRequest",
    "EscalateRequest",
    "TeachResponse",
    "EscalateResponse",
    "NodeResponse",
    "NodeListResponse",
    "OrgTreeResponse",
    "InboxResponse",
    "ActivityPulseResponse",
    "list_nodes",
    "create_node",
    "get_node",
    "update_node",
    "delete_node",
    "update_node_status",
    "get_org_tree",
    "get_inbox",
    "get_activity_pulse",
    "teach_ai",
    "escalate_to_human",
]
