"""Read-only session intake queue status API."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_id,
)
from apps.backend.services.sessions.intake_queue import get_member_intake_queue

router = APIRouter(prefix="/api/v1/sessions/intake-queue", tags=["sessions"])


@router.get("")
async def get_intake_queue_status(
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    member_id: str | None = Query(None, description="Optional member or agent ID. Defaults to the caller."),
    channel: str | None = Query(None, description="Optional channel filter: slack, email, teams, or all."),
) -> dict[str, Any]:
    """Return tenant-scoped intake queue counters for one member or the workspace."""
    target_member_id = (member_id or user_id or "").strip() or None
    return get_member_intake_queue().stats(
        workspace_id=tenant_id,
        member_id=target_member_id,
        channel=channel,
    ).to_response()
