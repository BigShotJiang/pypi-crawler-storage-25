"""Shared helpers for Mission Control API modules."""

from __future__ import annotations

import re
from typing import TYPE_CHECKING

from fastapi import Request

if TYPE_CHECKING:
    pass


_CHANNEL_SLUG_RE = re.compile(r"[^a-z0-9]+")


def _mission_api_module():
    from apps.backend.api import mission as mission_api

    return mission_api


def get_store():
    return _mission_api_module()._get_store()


def get_collaboration():
    return _mission_api_module()._get_collaboration()


def get_evidence_ledger():
    return _mission_api_module()._get_evidence_ledger()


def get_platform_bridge():
    return _mission_api_module()._get_platform_bridge()


def get_platform_mapping_store():
    return _mission_api_module()._get_platform_mapping_store()


def get_ambient_monitor():
    return _mission_api_module()._get_ambient_monitor()


def get_event_bus():
    return _mission_api_module()._get_event_bus()


def get_approval_gates():
    return _mission_api_module()._get_approval_gates()


def get_contracts_service():
    return _mission_api_module()._get_contracts_service()


def get_run_state_service():
    return _mission_api_module()._get_run_state_service()


def slugify_channel_name(name: str) -> str:
    raw = str(name or "").strip().lower()
    if not raw:
        return "unnamed"
    slug = _CHANNEL_SLUG_RE.sub("-", raw).strip("-")
    return slug or "unnamed"


def collect_team_agent_ids(nodes: list[dict], team_id: str) -> list[str]:
    return [
        str(node.get("node_id", ""))
        for node in nodes
        if node.get("node_type") == "agent" and node.get("parent_node_id") == team_id
    ]


def collect_department_agent_ids(nodes: list[dict], department_id: str) -> list[str]:
    team_ids = {
        str(node.get("node_id", ""))
        for node in nodes
        if node.get("node_type") == "team" and node.get("parent_node_id") == department_id
    }
    return [
        str(node.get("node_id", ""))
        for node in nodes
        if node.get("node_type") == "agent" and str(node.get("parent_node_id", "")) in team_ids
    ]


def resolve_escalation_resolvers(nodes: list[dict], source_agent_id: str) -> list[str]:
    source = next(
        (node for node in nodes if node.get("node_type") == "agent" and str(node.get("node_id", "")) == source_agent_id),
        None,
    )
    if not source:
        return []

    team_id = str(source.get("parent_node_id", ""))
    team = next((node for node in nodes if str(node.get("node_id", "")) == team_id), None)
    department_id = str(team.get("parent_node_id", "")) if team else ""
    team_lead = None
    for node in nodes:
        if node.get("node_type") != "agent":
            continue
        if str(node.get("parent_node_id", "")) != team_id:
            continue
        if str(node.get("node_id", "")) == source_agent_id:
            continue
        role = str((node.get("config") or {}).get("role", "")).lower()
        metadata = node.get("metadata") or {}
        if metadata.get("is_team_lead") is True or "lead" in role or "manager" in role:
            team_lead = str(node.get("node_id", ""))
            break

    department_coordinator = None
    team_ids = {
        str(node.get("node_id", ""))
        for node in nodes
        if node.get("node_type") == "team" and str(node.get("parent_node_id", "")) == department_id
    }
    for node in nodes:
        if node.get("node_type") != "agent":
            continue
        if str(node.get("parent_node_id", "")) not in team_ids:
            continue
        if str(node.get("node_id", "")) == source_agent_id:
            continue
        role = str((node.get("config") or {}).get("role", "")).lower()
        metadata = node.get("metadata") or {}
        if metadata.get("is_department_coordinator") is True or "coordinator" in role or "director" in role:
            department_coordinator = str(node.get("node_id", ""))
            break

    ordered = [value for value in [team_lead, department_coordinator] if value]
    return list(dict.fromkeys(ordered))


def request_user_id(request: Request) -> str:
    state_user = str(getattr(request.state, "user_id", "") or "").strip()
    if state_user:
        return state_user
    return str(request.headers.get("X-User-Id") or "").strip()


def resolve_human_actor(request: Request, requested_actor: str, *, fallback: str = "human:operator") -> str:
    user_id = request_user_id(request)
    if user_id:
        return f"human:{user_id}"
    actor = str(requested_actor or "").strip()
    return actor or fallback

