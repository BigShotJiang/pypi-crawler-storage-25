
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel

router = APIRouter(prefix="/api/v1/harness/templates", tags=["harness-templates"])

BUILTIN_TEMPLATES = [
    {
        "id": "morning-briefing",
        "name": "Morning Briefing",
        "description": "Daily summary of emails, calendar, and tasks prioritized by urgency",
        "category": "productivity",
        "required_connectors": ["gmail", "google-calendar", "slack"],
        "estimated_minutes": 3,
        "prompt_template": "Review my unread emails, today's calendar events, and pending tasks. Summarize the top priorities and flag anything urgent.",
        "difficulty": "beginner",
    },
    {
        "id": "inbox-triage",
        "name": "Inbox Triage",
        "description": "Categorize and prioritize incoming emails, draft responses for routine ones",
        "category": "productivity",
        "required_connectors": ["gmail"],
        "estimated_minutes": 5,
        "prompt_template": "Triage my inbox: categorize emails as urgent/important/routine/spam. Draft responses for routine inquiries. Flag anything needing my personal attention.",
        "difficulty": "beginner",
    },
    {
        "id": "lead-follow-up",
        "name": "Lead Follow-up",
        "description": "Check CRM for stale leads and draft personalized follow-up messages",
        "category": "sales",
        "required_connectors": ["hubspot", "gmail"],
        "estimated_minutes": 10,
        "prompt_template": "Find leads in CRM with no activity in 7+ days. Draft personalized follow-up emails based on their last interaction and company context.",
        "difficulty": "intermediate",
    },
    {
        "id": "meeting-prep",
        "name": "Meeting Prep",
        "description": "Prepare briefing docs for upcoming meetings with attendee context",
        "category": "productivity",
        "required_connectors": ["google-calendar", "gmail", "notion"],
        "estimated_minutes": 5,
        "prompt_template": "For my next meeting, compile attendee profiles, recent email threads, and relevant documents. Create a one-page briefing.",
        "difficulty": "intermediate",
    },
    {
        "id": "weekly-report",
        "name": "Weekly Report",
        "description": "Generate a weekly status report from completed tasks and communications",
        "category": "reporting",
        "required_connectors": ["gmail", "slack", "notion"],
        "estimated_minutes": 8,
        "prompt_template": "Compile this week's completed tasks, key decisions, blockers, and next week's priorities into a structured weekly report.",
        "difficulty": "beginner",
    },
    {
        "id": "customer-onboarding",
        "name": "Customer Onboarding",
        "description": "Set up new customer accounts with welcome sequence and documentation",
        "category": "support",
        "required_connectors": ["gmail", "hubspot", "notion"],
        "estimated_minutes": 15,
        "prompt_template": "For the new customer, create a CRM record, send the welcome email sequence, set up their documentation space, and schedule the kickoff call.",
        "difficulty": "advanced",
    },
    {
        "id": "social-media-monitor",
        "name": "Social Media Monitor",
        "description": "Monitor brand mentions and competitor activity across social channels",
        "category": "marketing",
        "required_connectors": ["slack"],
        "estimated_minutes": 10,
        "prompt_template": "Monitor social media for brand mentions, competitor news, and industry trends. Summarize findings and flag anything requiring immediate response.",
        "difficulty": "intermediate",
    },
    {
        "id": "competitor-watch",
        "name": "Competitor Watch",
        "description": "Track competitor product changes, pricing updates, and market moves",
        "category": "strategy",
        "required_connectors": ["slack", "notion"],
        "estimated_minutes": 15,
        "prompt_template": "Research competitor websites, recent announcements, and product changes. Update the competitive intelligence document with new findings.",
        "difficulty": "advanced",
    },
]


class HarnessTemplate(BaseModel):
    id: str
    name: str
    description: str
    category: str
    required_connectors: list[str]
    estimated_minutes: int
    prompt_template: str
    difficulty: str


class TemplateListResponse(BaseModel):
    templates: list[HarnessTemplate]
    total: int


@router.get("/", response_model=TemplateListResponse)
def list_templates(
    category: str | None = Query(default=None, description="Filter by category"),
) -> TemplateListResponse:
    templates = BUILTIN_TEMPLATES
    if category is not None:
        templates = [t for t in templates if t["category"] == category]
    return TemplateListResponse(
        templates=[HarnessTemplate(**t) for t in templates],
        total=len(templates),
    )


@router.get("/{template_id}", response_model=HarnessTemplate)
def get_template(template_id: str) -> HarnessTemplate:
    for t in BUILTIN_TEMPLATES:
        if t["id"] == template_id:
            return HarnessTemplate(**t)
    raise HTTPException(status_code=404, detail=f"Template '{template_id}' not found")
