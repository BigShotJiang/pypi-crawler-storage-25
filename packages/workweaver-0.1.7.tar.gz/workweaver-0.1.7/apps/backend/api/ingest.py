"""Unified ingest API — single endpoint for all file/text/URL/clipboard ingestion.

POST /api/v1/ingest          — multipart file upload
POST /api/v1/ingest/text     — raw text content
POST /api/v1/ingest/url      — fetch and ingest from URL
POST /api/v1/ingest/clipboard — clipboard paste content

All paths route through UnifiedFileIngestionService → WorkMemory.
Works in both AWS and local Docker environments.

GitHub issue #1078
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, File, Form, HTTPException, UploadFile
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id as get_tenant_id
from apps.backend.services.unified_file_ingestion import (
    UnifiedFileIngestionService,
    get_unified_ingestion_service,
)
from apps.backend.services.tenant_quota_service import QuotaDecision, TenantQuotaService, get_tenant_quota_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/ingest", tags=["ingest"])


# ── Request/Response Models ────────────────────────────────────────────


class TextIngestRequest(BaseModel):
    content: str = Field(..., min_length=1, max_length=5_000_000)
    category: str | None = None
    source_surface: str = "api"


class UrlIngestRequest(BaseModel):
    url: str = Field(..., min_length=1)
    filename: str | None = None
    category: str | None = None


class ClipboardIngestRequest(BaseModel):
    content: str = Field(..., min_length=1, max_length=5_000_000)
    content_type: str = "text/plain"
    category: str | None = None


class IngestResponse(BaseModel):
    success: bool
    source: str
    sha256: str
    item_ids: list[str] = []
    filename: str | None = None
    content_type: str | None = None
    size_bytes: int = 0
    facts_extracted: int = 0
    chunks_processed: int = 0
    warnings: list[str] = []
    errors: list[str] = []
    resource_ref: str | None = None
    processing_status: str = "complete"


# ── Dependency ─────────────────────────────────────────────────────────


def _get_service() -> UnifiedFileIngestionService:
    return get_unified_ingestion_service()


def _get_quota_service() -> TenantQuotaService:
    return get_tenant_quota_service()


def _raise_quota_error(decision: QuotaDecision) -> None:
    headers = {"Retry-After": str(decision.retry_after_seconds)} if decision.retry_after_seconds else None
    if decision.reason == "upload_bytes_limit_exceeded":
        raise HTTPException(status_code=413, detail=decision.reason, headers=headers)
    if decision.reason in {
        "tenant_storage_limit_exceeded",
        "storage_limit_unavailable",
        "monthly_memory_write_limit_exceeded",
        "quota_unavailable",
        "memory_write_limit_unavailable",
    }:
        raise HTTPException(status_code=429, detail=decision.reason, headers=headers)
    raise HTTPException(status_code=422, detail=decision.reason, headers=headers)


# ── Endpoints ──────────────────────────────────────────────────────────


@router.post("", response_model=IngestResponse)
async def ingest_file_upload(
    file: UploadFile = File(...),
    category: str | None = Form(None),
    source_surface: str = Form("upload"),
    tenant_id: str = Depends(get_tenant_id),
    svc: UnifiedFileIngestionService = Depends(_get_service),
) -> dict[str, Any]:
    """Upload a file for ingestion into WorkMemory."""
    content = await file.read()
    quota = _get_quota_service()
    upload_decision = quota.check_upload(tenant_id=tenant_id, size_bytes=len(content))
    if not upload_decision.allowed:
        _raise_quota_error(upload_decision)
    memory_decision = quota.check_memory_writes(tenant_id=tenant_id, writes_needed=1)
    if not memory_decision.allowed:
        _raise_quota_error(memory_decision)
    result = await svc.ingest_upload(
        tenant_id=tenant_id,
        filename=file.filename or "upload",
        content=content,
        content_type=file.content_type,
        category=category,
        source_surface=source_surface,
    )
    if not result.success:
        raise HTTPException(status_code=422, detail=result.errors)
    return result.to_dict()


@router.post("/text", response_model=IngestResponse)
async def ingest_text(
    request: TextIngestRequest,
    tenant_id: str = Depends(get_tenant_id),
    svc: UnifiedFileIngestionService = Depends(_get_service),
) -> dict[str, Any]:
    """Ingest raw text content into WorkMemory."""
    quota = _get_quota_service()
    memory_decision = quota.check_memory_writes(tenant_id=tenant_id, writes_needed=1)
    if not memory_decision.allowed:
        _raise_quota_error(memory_decision)
    result = await svc.ingest_text(
        tenant_id=tenant_id,
        content=request.content,
        source_surface=request.source_surface,
        category=request.category,
    )
    if not result.success:
        raise HTTPException(status_code=422, detail=result.errors)
    return result.to_dict()


@router.post("/url", response_model=IngestResponse)
async def ingest_from_url(
    request: UrlIngestRequest,
    tenant_id: str = Depends(get_tenant_id),
    svc: UnifiedFileIngestionService = Depends(_get_service),
) -> dict[str, Any]:
    """Fetch content from a URL and ingest into WorkMemory."""
    quota = _get_quota_service()
    memory_decision = quota.check_memory_writes(tenant_id=tenant_id, writes_needed=1)
    if not memory_decision.allowed:
        _raise_quota_error(memory_decision)
    result = await svc.ingest_url(
        tenant_id=tenant_id,
        url=request.url,
        filename=request.filename,
        category=request.category,
    )
    if not result.success:
        raise HTTPException(status_code=422, detail=result.errors)
    return result.to_dict()


@router.post("/clipboard", response_model=IngestResponse)
async def ingest_clipboard(
    request: ClipboardIngestRequest,
    tenant_id: str = Depends(get_tenant_id),
    svc: UnifiedFileIngestionService = Depends(_get_service),
) -> dict[str, Any]:
    """Ingest clipboard paste content into WorkMemory."""
    quota = _get_quota_service()
    memory_decision = quota.check_memory_writes(tenant_id=tenant_id, writes_needed=1)
    if not memory_decision.allowed:
        _raise_quota_error(memory_decision)
    result = await svc.ingest_clipboard(
        tenant_id=tenant_id,
        content=request.content,
        content_type=request.content_type,
        category=request.category,
    )
    if not result.success:
        raise HTTPException(status_code=422, detail=result.errors)
    return result.to_dict()
