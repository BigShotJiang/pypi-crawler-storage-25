"""REST surface for the tenant conflict detector (#3548)."""

from __future__ import annotations

from typing import Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.conflict_detector import (
    ConflictDetectorService,
    ResolutionResult,
    TenantConflict,
    TenantConflictBundle,
    get_conflict_detector_service,
)


router = APIRouter(prefix="/api/v1/tenant/conflicts", tags=["tenant", "conflicts"])


class ResolveRequest(BaseModel):
    action: Literal["accept_suggestion", "reject", "escalate"]


class ResolveResponse(BaseModel):
    result: ResolutionResult


def _detector() -> ConflictDetectorService:
    return get_conflict_detector_service()


@router.get("", response_model=TenantConflictBundle)
def list_tenant_conflicts(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> TenantConflictBundle:
    """Run the conflict matrix for the caller's tenant and return the bundle."""
    return _detector().detect(tenant_id=tenant_id)


@router.get("/{conflict_id}", response_model=TenantConflict)
def show_tenant_conflict(
    conflict_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> TenantConflict:
    bundle = _detector().detect(tenant_id=tenant_id)
    for conflict in bundle.conflicts:
        if conflict.conflict_id == conflict_id:
            return conflict
    raise HTTPException(status_code=404, detail=f"conflict {conflict_id} not found")


@router.post("/{conflict_id}/resolve", response_model=ResolveResponse)
def resolve_tenant_conflict(
    conflict_id: str,
    body: ResolveRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ResolveResponse:
    bundle = _detector().detect(tenant_id=tenant_id)
    for conflict in bundle.conflicts:
        if conflict.conflict_id == conflict_id:
            result = _detector().resolve(conflict=conflict, action=body.action)
            return ResolveResponse(result=result)
    raise HTTPException(status_code=404, detail=f"conflict {conflict_id} not found")


__all__ = ["router", "ResolveRequest", "ResolveResponse"]
