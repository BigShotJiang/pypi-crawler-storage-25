"""Telephony Management API — tenant-owned phone number routing on top of BYO Twilio credentials.

Endpoints:
  GET  /api/v1/telephony/numbers          — List provisioned numbers
  POST /api/v1/telephony/numbers          — Provision a new tenant-owned number (Twilio-backed)
  DELETE /api/v1/telephony/numbers/{sid}   — Release a number
  GET  /api/v1/telephony/numbers/{sid}     — Get number details
  PUT  /api/v1/telephony/numbers/{sid}/routing — Update call routing for a number
  GET  /api/v1/telephony/usage             — Get telephony usage summary

Legacy requirement reference: docs/COMMERCIAL.md Blocker #15
"""

from __future__ import annotations

import logging
import os
import re
from datetime import datetime, UTC
from typing import Any, Literal

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field, field_validator

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

try:
    from apps.backend.services import dynamo_store
except ImportError:  # pragma: no cover — flat-path fallback (Docker)
    from services import dynamo_store  # type: ignore[no-redef]

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/telephony", tags=["telephony"])

# Valid routing targets — enforced at the Pydantic layer.
# RT-6: 7 modes required (was 4). Added ivr, agent_pool, park.
VALID_ROUTING_TARGETS = ("zara", "queue", "voicemail", "forward", "ivr", "agent_pool", "park")

# Twilio SID pattern: two uppercase letters followed by 32 hex chars.
_TWILIO_SID_RE = re.compile(r"^[A-Z]{2}[0-9a-f]{32}$")


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class ProvisionNumberRequest(BaseModel):
    """Request to provision a new phone number."""

    country_code: str = Field("US", description="ISO country code", max_length=2)
    area_code: str | None = Field(None, description="Preferred area code")
    capabilities: list[str] = Field(
        default_factory=lambda: ["voice", "sms"],
        description="Required capabilities: voice, sms, mms",
    )
    label: str = Field("", description="Human-friendly label", max_length=100)
    routing_target: Literal["zara", "queue", "voicemail", "forward", "ivr", "agent_pool", "park"] = Field(
        "zara",
        description="Where inbound calls route: zara | queue | voicemail | forward | ivr | agent_pool | park",
    )
    forward_to: str | None = Field(None, description="Forward-to number if routing_target=forward")

    @field_validator("forward_to")
    @classmethod
    def _validate_forward_to(cls, v: str | None, info: Any) -> str | None:
        routing = info.data.get("routing_target")
        if routing == "forward" and not v:
            raise ValueError("forward_to is required when routing_target is 'forward'")
        if v and not re.match(r"^\+[1-9]\d{1,14}$", v):
            raise ValueError("forward_to must be a valid E.164 phone number")
        return v


class UpdateRoutingRequest(BaseModel):
    """Request to update call routing for a number."""

    routing_target: Literal["zara", "queue", "voicemail", "forward", "ivr", "agent_pool", "park"] = Field(
        ..., description="Where inbound calls route: zara | queue | voicemail | forward | ivr | agent_pool | park"
    )
    forward_to: str | None = Field(None, description="Forward-to number if routing_target=forward")
    greeting_message: str | None = Field(None, description="Custom greeting message")
    business_hours_only: bool = Field(False, description="Only route during business hours")

    @field_validator("forward_to")
    @classmethod
    def _validate_forward_to(cls, v: str | None, info: Any) -> str | None:
        routing = info.data.get("routing_target")
        if routing == "forward" and not v:
            raise ValueError("forward_to is required when routing_target is 'forward'")
        if v and not re.match(r"^\+[1-9]\d{1,14}$", v):
            raise ValueError("forward_to must be a valid E.164 phone number")
        return v


class PhoneNumberResponse(BaseModel):
    """Phone number details."""

    sid: str = Field(..., description="Twilio SID")
    phone_number: str = Field(..., description="E.164 phone number")
    ownership_model: str = Field("tenant_owned", description="Ownership contract for this number")
    friendly_name: str = Field("", description="Display name")
    capabilities: dict[str, bool] = Field(default_factory=dict)
    routing_target: str = Field("zara")
    forward_to: str | None = None
    status: str = Field("active")
    label: str = Field("")
    created_at: str = Field("")


class TelephonyUsageResponse(BaseModel):
    """Telephony usage summary."""

    total_numbers: int = 0
    total_inbound_calls: int = 0
    total_outbound_calls: int = 0
    total_minutes: float = 0.0
    monthly_cost_estimate_usd: float = 0.0


# ---------------------------------------------------------------------------
# Service helpers (delegate to Twilio SDK)
# ---------------------------------------------------------------------------


def _get_twilio_client():
    """Lazy-init Twilio client from environment."""
    account_sid = os.getenv("TWILIO_ACCOUNT_SID", "")
    auth_token = os.getenv("TWILIO_AUTH_TOKEN", "")
    if not account_sid or not auth_token:
        return None
    try:
        from twilio.rest import Client

        return Client(account_sid, auth_token)
    except ImportError:
        logger.warning("twilio package not installed")
        return None


def _validate_twilio_sid(sid: str) -> None:
    """Validate Twilio SID format to prevent injection."""
    if not _TWILIO_SID_RE.match(sid):
        raise HTTPException(status_code=400, detail="Invalid Twilio SID format")


def _tenant_owns_routing(tenant_id: str, routing: dict[str, Any]) -> bool:
    """Return True only when the routing record is explicitly scoped to the tenant."""
    return bool(isinstance(routing, dict) and routing and routing.get("tenant_id") == tenant_id)


# In-memory routing config — acceptable for Phase 1 (single ECS task).
# Durable source of truth is DynamoDB; this dict is a read-through cache.
_routing_config: dict[str, dict[str, Any]] = {}
_ROUTING_SK_PREFIX = "TELEPHONY_ROUTING#"


def _routing_sk(sid: str) -> str:
    return f"{_ROUTING_SK_PREFIX}{sid}"


def _get_routing_config(tenant_id: str, sid: str) -> dict[str, Any]:
    """Get routing config for tenant+sid from DynamoDB with cache fallback."""
    cached = _routing_config.get(sid, {})
    if cached.get("tenant_id") == tenant_id:
        return cached

    try:
        data = dynamo_store.get_item(tenant_id, _routing_sk(sid))
        if isinstance(data, dict) and data:
            _routing_config[sid] = data
            return data
    except Exception:
        logger.warning("Failed to read telephony routing from DynamoDB sid=%s", sid, exc_info=True)

    return cached


def _put_routing_config(tenant_id: str, sid: str, config: dict[str, Any]) -> None:
    """Write routing config to cache and DynamoDB."""
    _routing_config[sid] = dict(config)
    try:
        dynamo_store.put_item(tenant_id, _routing_sk(sid), dict(config))
    except Exception:
        logger.warning("Failed to persist telephony routing sid=%s; using cache fallback", sid, exc_info=True)


def _delete_routing_config(tenant_id: str, sid: str) -> None:
    """Delete routing config from cache and DynamoDB."""
    _routing_config.pop(sid, None)
    try:
        dynamo_store.delete_item(tenant_id, _routing_sk(sid))
    except Exception:
        logger.warning("Failed to delete telephony routing sid=%s from DynamoDB", sid, exc_info=True)


# ---------------------------------------------------------------------------
# Endpoints — all require authenticated tenant
# ---------------------------------------------------------------------------


@router.get("/numbers", response_model=list[PhoneNumberResponse])
async def list_numbers(
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(20, ge=1, le=100),
) -> list[PhoneNumberResponse]:
    """List all provisioned phone numbers for the authenticated tenant."""
    client = _get_twilio_client()
    if not client:
        raise HTTPException(status_code=503, detail="Twilio not configured")

    try:
        numbers = client.incoming_phone_numbers.list(limit=limit)
        result = []
        for num in numbers:
            routing = _get_routing_config(tenant_id, num.sid)
            # Only include numbers explicitly owned by this tenant.
            if not _tenant_owns_routing(tenant_id, routing):
                continue
            result.append(
                PhoneNumberResponse(
                    sid=num.sid,
                    phone_number=num.phone_number,
                    ownership_model="tenant_owned",
                    friendly_name=num.friendly_name or "",
                    capabilities={
                        "voice": getattr(num.capabilities, "voice", False),
                        "sms": getattr(num.capabilities, "sms", False),
                        "mms": getattr(num.capabilities, "mms", False),
                    }
                    if num.capabilities
                    else {},
                    routing_target=routing.get("routing_target", "zara"),
                    forward_to=routing.get("forward_to"),
                    status="active",
                    label=routing.get("label", ""),
                    created_at=str(num.date_created) if num.date_created else "",
                )
            )
        return result
    except Exception as e:
        logger.error("Failed to list phone numbers: %s", e, exc_info=True)
        raise HTTPException(status_code=502, detail="Failed to list numbers")


@router.post("/numbers", response_model=PhoneNumberResponse, status_code=status.HTTP_201_CREATED)
async def provision_number(
    req: ProvisionNumberRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PhoneNumberResponse:
    """Provision a tenant-owned phone number from a BYO Twilio account."""
    client = _get_twilio_client()
    if not client:
        raise HTTPException(status_code=503, detail="Twilio not configured")

    try:
        # Search for available numbers
        search_params: dict[str, Any] = {"limit": 1}
        if req.area_code:
            search_params["area_code"] = req.area_code
        if "voice" in req.capabilities:
            search_params["voice_enabled"] = True
        if "sms" in req.capabilities:
            search_params["sms_enabled"] = True

        available = client.available_phone_numbers(req.country_code).local.list(**search_params)
        if not available:
            raise HTTPException(status_code=404, detail="No numbers available matching criteria")

        # Buy the first available number
        voice_url = os.getenv("TWILIO_VOICE_WEBHOOK_URL", "")
        purchased = client.incoming_phone_numbers.create(
            phone_number=available[0].phone_number,
            voice_url=voice_url or None,
            friendly_name=req.label or f"Workweaver {req.country_code}",
        )

        # Store routing config scoped to tenant (include phone_number for reverse lookup)
        _put_routing_config(
            tenant_id,
            purchased.sid,
            {
                "tenant_id": tenant_id,
                "phone_number": purchased.phone_number,
                "routing_target": req.routing_target,
                "forward_to": req.forward_to,
                "label": req.label,
            },
        )

        # Register in inbound routing cache for tenant resolution
        try:
            from apps.backend.services.channels.twilio.voice_inbound import register_phone_tenant

            register_phone_tenant(
                purchased.phone_number,
                tenant_id,
                req.routing_target,
                forward_to=req.forward_to,
            )
        except ImportError:
            logger.debug("twilio_voice_inbound not available for phone-tenant registration")

        logger.info("Provisioned number: %s (%s) for tenant=%s", purchased.phone_number, purchased.sid, tenant_id)

        return PhoneNumberResponse(
            sid=purchased.sid,
            phone_number=purchased.phone_number,
            ownership_model="tenant_owned",
            friendly_name=purchased.friendly_name or "",
            capabilities={"voice": True, "sms": True},
            routing_target=req.routing_target,
            forward_to=req.forward_to,
            status="active",
            label=req.label,
            created_at=datetime.now(UTC).isoformat(),
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to provision number: %s", e, exc_info=True)
        raise HTTPException(status_code=502, detail="Failed to provision number")


@router.delete("/numbers/{sid}", status_code=status.HTTP_200_OK)
async def release_number(
    sid: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, str]:
    """Release a provisioned phone number."""
    _validate_twilio_sid(sid)
    client = _get_twilio_client()
    if not client:
        raise HTTPException(status_code=503, detail="Twilio not configured")

    # Verify tenant owns this number
    routing = _get_routing_config(tenant_id, sid)
    if not _tenant_owns_routing(tenant_id, routing):
        raise HTTPException(status_code=403, detail="Number does not belong to this organization")

    try:
        # Unregister from inbound routing cache before deleting
        phone_number = routing.get("phone_number") or ""
        if phone_number:
            try:
                from apps.backend.services.channels.twilio.voice_inbound import unregister_phone_tenant

                unregister_phone_tenant(phone_number)
            except ImportError:
                logger.debug("twilio_voice_inbound not available for phone-tenant unregistration")

        client.incoming_phone_numbers(sid).delete()
        _delete_routing_config(tenant_id, sid)
        logger.info("Released number: %s (tenant=%s)", sid, tenant_id)
        return {"status": "released", "sid": sid}
    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to release number %s: %s", sid, e, exc_info=True)
        raise HTTPException(status_code=502, detail="Failed to release number")


@router.get("/numbers/{sid}", response_model=PhoneNumberResponse)
async def get_number(
    sid: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PhoneNumberResponse:
    """Get details of a provisioned phone number."""
    _validate_twilio_sid(sid)
    client = _get_twilio_client()
    if not client:
        raise HTTPException(status_code=503, detail="Twilio not configured")

    # Verify tenant owns this number
    routing = _get_routing_config(tenant_id, sid)
    if routing.get("tenant_id") and routing["tenant_id"] != tenant_id:
        raise HTTPException(status_code=403, detail="Number does not belong to this organization")

    try:
        num = client.incoming_phone_numbers(sid).fetch()
        return PhoneNumberResponse(
            sid=num.sid,
            phone_number=num.phone_number,
            ownership_model="tenant_owned",
            friendly_name=num.friendly_name or "",
            capabilities={
                "voice": getattr(num.capabilities, "voice", False),
                "sms": getattr(num.capabilities, "sms", False),
                "mms": getattr(num.capabilities, "mms", False),
            }
            if num.capabilities
            else {},
            routing_target=routing.get("routing_target", "zara"),
            forward_to=routing.get("forward_to"),
            status="active",
            label=routing.get("label", ""),
            created_at=str(num.date_created) if num.date_created else "",
        )
    except Exception as e:
        logger.error("Failed to get number %s: %s", sid, e, exc_info=True)
        raise HTTPException(status_code=502, detail="Failed to get number details")


@router.put("/numbers/{sid}/routing")
async def update_routing(
    sid: str,
    req: UpdateRoutingRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Update call routing for a phone number."""
    _validate_twilio_sid(sid)

    # Verify tenant owns this number
    routing = _get_routing_config(tenant_id, sid)
    if not _tenant_owns_routing(tenant_id, routing):
        raise HTTPException(status_code=403, detail="Number does not belong to this organization")

    _put_routing_config(
        tenant_id,
        sid,
        {
            **routing,
            "tenant_id": tenant_id,
            "routing_target": req.routing_target,
            "forward_to": req.forward_to,
            "greeting_message": req.greeting_message,
            "business_hours_only": req.business_hours_only,
        },
    )
    # Update inbound routing cache if phone number is known
    phone_number = routing.get("phone_number") or ""
    if phone_number:
        try:
            from apps.backend.services.channels.twilio.voice_inbound import register_phone_tenant

            register_phone_tenant(
                phone_number,
                tenant_id,
                req.routing_target,
                forward_to=req.forward_to,
                greeting_message=req.greeting_message,
                business_hours_only=req.business_hours_only,
            )
        except ImportError:
            logger.debug("twilio_voice_inbound not available for phone-tenant registration")

    logger.info("Updated routing for %s: target=%s (tenant=%s)", sid, req.routing_target, tenant_id)
    return {"status": "updated", "sid": sid, "routing_target": req.routing_target}


@router.get("/usage", response_model=TelephonyUsageResponse)
async def get_telephony_usage(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> TelephonyUsageResponse:
    """Get telephony usage summary for the authenticated tenant."""
    client = _get_twilio_client()
    if not client:
        return TelephonyUsageResponse()

    try:
        numbers = client.incoming_phone_numbers.list(limit=100)
        # Filter to tenant's numbers
        tenant_numbers = [n for n in numbers if _tenant_owns_routing(tenant_id, _get_routing_config(tenant_id, n.sid))]
        return TelephonyUsageResponse(
            total_numbers=len(tenant_numbers),
            total_inbound_calls=0,  # Would query Twilio usage records
            total_outbound_calls=0,
            total_minutes=0.0,
            monthly_cost_estimate_usd=len(tenant_numbers) * 1.15,  # ~$1.15/number/month
        )
    except Exception as e:
        logger.error("Failed to get telephony usage: %s", e, exc_info=True)
        return TelephonyUsageResponse()
