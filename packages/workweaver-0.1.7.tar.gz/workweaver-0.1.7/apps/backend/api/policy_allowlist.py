"""Tenant-scoped policy allowlist read API (#3256)."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    require_admin_user_role,
)
from apps.backend.services.policy.allowlist_adopters import (
    get_platform_allowlist_store,
    seed_tool_defaults,
    seed_url_defaults,
)
from apps.backend.services.policy.platform_allowlist import (
    AllowlistKind,
    AllowlistRegistryUnavailableError,
)

router = APIRouter(prefix="/api/v1/admin/policy/allowlist", tags=["policy-allowlist"])


class AllowlistEntryResponse(BaseModel):
    kind: str
    value_canonical: str
    value_raw: str
    tenant_id: str | None
    scope: str
    immutable: bool
    version: int
    audit_actor: str
    audit_ts: str
    denied: bool
    deny_reason: str | None


class AllowlistListResponse(BaseModel):
    tenant_id: str
    kind: str
    entries: list[AllowlistEntryResponse]
    count: int


def _normalize_kind(kind: str) -> AllowlistKind:
    normalized = kind.strip().upper()
    try:
        return AllowlistKind(normalized)
    except ValueError as exc:
        allowed = ", ".join(item.value for item in AllowlistKind)
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Unsupported allowlist kind {kind!r}; expected one of: {allowed}",
        ) from exc


def policy_allowlist_payload(*, kind: str, tenant_id: str) -> dict[str, object]:
    allowlist_kind = _normalize_kind(kind)
    if allowlist_kind == AllowlistKind.TOOL:
        seed_tool_defaults()
    elif allowlist_kind == AllowlistKind.URL:
        seed_url_defaults()
    store = get_platform_allowlist_store()
    try:
        entries = store.list_entries(allowlist_kind, tenant_id=tenant_id)
    except AllowlistRegistryUnavailableError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Policy allowlist registry is unavailable",
        ) from exc
    rows = [
        {
            "kind": entry.kind.value,
            "value_canonical": entry.value_canonical,
            "value_raw": entry.value_raw,
            "tenant_id": entry.tenant_id,
            "scope": "tenant" if entry.tenant_id else "platform",
            "immutable": entry.immutable,
            "version": entry.version,
            "audit_actor": entry.audit_actor,
            "audit_ts": entry.audit_ts,
            "denied": entry.deny_reason is not None,
            "deny_reason": entry.deny_reason,
        }
        for entry in entries
    ]
    return {
        "tenant_id": tenant_id,
        "kind": allowlist_kind.value,
        "entries": rows,
        "count": len(rows),
    }


@router.get("", response_model=AllowlistListResponse)
def list_policy_allowlist(
    kind: str = Query(..., description="Allowlist kind, e.g. TOOL."),
    tenant_id: str = Depends(get_verified_tenant_id),
    _admin_role: object = Depends(require_admin_user_role),
) -> AllowlistListResponse:
    """List platform and tenant entries for a policy allowlist kind."""
    return AllowlistListResponse.model_validate(
        policy_allowlist_payload(kind=kind, tenant_id=tenant_id)
    )
