"""Experiment Lifecycle API (PR-CB3 — autoresearch bar).

Endpoints (baseline tracking):
    POST /api/v1/experiments/{experiment_id}/baseline  — capture current metric as baseline
    GET  /api/v1/experiments/{experiment_id}/progress   — metric vs baseline
    POST /api/v1/experiments/{experiment_id}/lock        — lock experiment

A/B experiment endpoints:
    POST /api/v1/experiments/create                     — create experiment with variants
    POST /api/v1/experiments/{experiment_id}/start       — start experiment (enable traffic)
    POST /api/v1/experiments/{experiment_id}/record      — record outcome for a variant
    GET  /api/v1/experiments/{experiment_id}/analysis    — statistical analysis
    GET  /api/v1/experiments/list                        — list experiments for tenant
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.experiment_service import get_experiment_service
from apps.backend.services.stores.tenant_scoped import TenantScopedStore

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/experiments", tags=["experiments"])

SK_PREFIX = "EXPERIMENT"


# ---------------------------------------------------------------------------
# Durable experiment store (DynamoDB PK=TENANT#, SK=EXPERIMENT#)
# ---------------------------------------------------------------------------


class ExperimentStore(TenantScopedStore):
    """Tenant-scoped DynamoDB store for experiment records."""

    def get(self, tenant_id: str, experiment_id: str) -> dict[str, Any] | None:
        items = self._query(tenant_id, SK_PREFIX)
        for item in items:
            if item.get("experiment_id") == experiment_id:
                return item
        return None

    def put(self, tenant_id: str, experiment_id: str, record: dict[str, Any]) -> None:
        record["experiment_id"] = experiment_id
        self._persist(tenant_id, SK_PREFIX, experiment_id, record)


_experiment_store: ExperimentStore | None = None


def _get_experiment_store() -> ExperimentStore:
    global _experiment_store  # noqa: PLW0603
    if _experiment_store is None:
        _experiment_store = ExperimentStore()
    return _experiment_store


# ---------------------------------------------------------------------------
# Request / Response models — baseline tracking
# ---------------------------------------------------------------------------


class BaselineRequest(BaseModel):
    metric_name: str = Field(..., min_length=1, max_length=200)
    baseline_value: float


class BaselineResponse(BaseModel):
    experiment_id: str
    metric_name: str
    baseline_value: float
    status: str


class ProgressResponse(BaseModel):
    experiment_id: str
    metric_name: str | None
    baseline_value: float | None
    current_value: float | None
    delta: float | None
    delta_percent: float | None
    status: str


class LockResponse(BaseModel):
    experiment_id: str
    status: str
    locked: bool


# ---------------------------------------------------------------------------
# Request / Response models — A/B experiments
# ---------------------------------------------------------------------------


class VariantSpec(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    config: dict[str, Any] = Field(default_factory=dict)
    traffic_percent: float | None = None


class CreateExperimentRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=200)
    description: str = ""
    variants: list[VariantSpec] = Field(..., min_length=2)
    min_sample_size: int = Field(default=100, ge=1)


class RecordOutcomeRequest(BaseModel):
    variant_id: str = Field(..., min_length=1)
    success: bool
    value: float = 0.0


class VariantResponse(BaseModel):
    variant_id: str
    name: str
    config: dict[str, Any]
    traffic_percent: float
    sample_count: int
    success_count: int
    success_rate: float
    mean_value: float


class ExperimentResponse(BaseModel):
    experiment_id: str
    tenant_id: str
    name: str
    description: str
    state: str
    variants: list[VariantResponse]
    created_at: str
    min_sample_size: int


class AnalysisResponse(BaseModel):
    experiment_id: str
    control: VariantResponse
    treatment: VariantResponse
    improvement_pct: float
    z_score: float
    p_value: float
    significant: bool
    confidence_level: float
    sample_size_sufficient: bool
    recommendation: str


class ExperimentListResponse(BaseModel):
    experiments: list[ExperimentResponse]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _variant_to_response(v: Any) -> VariantResponse:
    return VariantResponse(
        variant_id=v.variant_id,
        name=v.name,
        config=v.config,
        traffic_percent=v.traffic_percent,
        sample_count=v.sample_count,
        success_count=v.success_count,
        success_rate=v.success_rate,
        mean_value=v.mean_value,
    )


def _experiment_to_response(exp: Any) -> ExperimentResponse:
    return ExperimentResponse(
        experiment_id=exp.experiment_id,
        tenant_id=exp.tenant_id,
        name=exp.name,
        description=exp.description,
        state=exp.state,
        variants=[_variant_to_response(v) for v in exp.variants],
        created_at=exp.created_at,
        min_sample_size=exp.min_sample_size,
    )


# ---------------------------------------------------------------------------
# Baseline tracking endpoints (existing)
# ---------------------------------------------------------------------------


@router.post("/{experiment_id}/baseline", response_model=BaselineResponse)
async def capture_baseline(
    experiment_id: str,
    body: BaselineRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> BaselineResponse:
    """Capture current metric as baseline for an experiment."""
    store = _get_experiment_store()
    record = store.get(tenant_id, experiment_id) or {"status": "active"}

    if record.get("status") == "locked":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Experiment {experiment_id} is locked",
        )

    record["metric_name"] = body.metric_name
    record["baseline_value"] = body.baseline_value
    store.put(tenant_id, experiment_id, record)

    logger.info(
        "Baseline captured for experiment %s: %s = %f",
        experiment_id,
        body.metric_name,
        body.baseline_value,
    )

    return BaselineResponse(
        experiment_id=experiment_id,
        metric_name=body.metric_name,
        baseline_value=body.baseline_value,
        status=record["status"],
    )


@router.get("/{experiment_id}/progress", response_model=ProgressResponse)
async def get_progress(
    experiment_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ProgressResponse:
    """Return metric vs baseline for an experiment."""
    store = _get_experiment_store()
    record = store.get(tenant_id, experiment_id)

    if record is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Experiment {experiment_id} not found",
        )

    metric_name = record.get("metric_name")
    baseline_value = record.get("baseline_value")
    current_value = record.get("current_value")

    delta: float | None = None
    delta_percent: float | None = None
    if baseline_value is not None and current_value is not None:
        delta = current_value - baseline_value
        delta_percent = (delta / baseline_value * 100) if baseline_value != 0 else None

    return ProgressResponse(
        experiment_id=experiment_id,
        metric_name=metric_name,
        baseline_value=baseline_value,
        current_value=current_value,
        delta=delta,
        delta_percent=delta_percent,
        status=record.get("status", "active"),
    )


@router.post("/{experiment_id}/lock", response_model=LockResponse)
async def lock_experiment(
    experiment_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> LockResponse:
    """Lock an experiment, preventing further modifications."""
    store = _get_experiment_store()
    record = store.get(tenant_id, experiment_id)

    if record is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Experiment {experiment_id} not found",
        )

    if record.get("status") == "locked":
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Experiment {experiment_id} is already locked",
        )

    record["status"] = "locked"
    store.put(tenant_id, experiment_id, record)
    logger.info("Experiment %s locked", experiment_id)

    return LockResponse(
        experiment_id=experiment_id,
        status="locked",
        locked=True,
    )


# ---------------------------------------------------------------------------
# A/B experiment endpoints
# ---------------------------------------------------------------------------


@router.post("/create", response_model=ExperimentResponse)
async def create_experiment(
    body: CreateExperimentRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ExperimentResponse:
    """Create a new A/B experiment with multiple variants."""
    svc = get_experiment_service()

    variant_dicts: list[dict[str, Any]] = []
    for v in body.variants:
        d: dict[str, Any] = {"name": v.name, "config": v.config}
        if v.traffic_percent is not None:
            d["traffic_percent"] = v.traffic_percent
        variant_dicts.append(d)

    exp = svc.create(
        tenant_id,
        body.name,
        variant_dicts,
        description=body.description,
        min_sample_size=body.min_sample_size,
    )

    logger.info("A/B experiment created: %s (%s)", exp.experiment_id, body.name)
    return _experiment_to_response(exp)


@router.post("/{experiment_id}/start", response_model=ExperimentResponse)
async def start_experiment(
    experiment_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ExperimentResponse:
    """Start an experiment, enabling traffic assignment."""
    svc = get_experiment_service()
    exp = svc.get(experiment_id)

    if exp is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Experiment {experiment_id} not found",
        )
    if exp.tenant_id != tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Experiment belongs to a different tenant",
        )
    if exp.state not in ("draft", "paused"):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Cannot start experiment in state '{exp.state}'",
        )

    exp.state = "running"
    logger.info("A/B experiment started: %s", experiment_id)
    return _experiment_to_response(exp)


@router.post("/{experiment_id}/record")
async def record_outcome(
    experiment_id: str,
    body: RecordOutcomeRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, str]:
    """Record an outcome for a variant in an experiment."""
    svc = get_experiment_service()
    exp = svc.get(experiment_id)

    if exp is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Experiment {experiment_id} not found",
        )
    if exp.tenant_id != tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Experiment belongs to a different tenant",
        )

    svc.record_outcome(experiment_id, body.variant_id, body.success, body.value)
    return {"status": "recorded"}


@router.get("/{experiment_id}/analysis", response_model=AnalysisResponse)
async def analyze_experiment(
    experiment_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> AnalysisResponse:
    """Run statistical analysis on an A/B experiment."""
    svc = get_experiment_service()
    exp = svc.get(experiment_id)

    if exp is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Experiment {experiment_id} not found",
        )
    if exp.tenant_id != tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Experiment belongs to a different tenant",
        )

    result = svc.analyze(experiment_id)
    if result is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Experiment requires at least 2 variants for analysis",
        )

    return AnalysisResponse(
        experiment_id=result.experiment_id,
        control=_variant_to_response(result.control),
        treatment=_variant_to_response(result.treatment),
        improvement_pct=result.improvement_pct,
        z_score=result.z_score,
        p_value=result.p_value,
        significant=result.significant,
        confidence_level=result.confidence_level,
        sample_size_sufficient=result.sample_size_sufficient,
        recommendation=result.recommendation,
    )


@router.get("/list", response_model=ExperimentListResponse)
async def list_experiments(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ExperimentListResponse:
    """List all A/B experiments for the current tenant."""
    svc = get_experiment_service()
    experiments = svc.list_experiments(tenant_id)
    return ExperimentListResponse(
        experiments=[_experiment_to_response(e) for e in experiments],
    )
