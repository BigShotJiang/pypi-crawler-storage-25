"""Connector health API endpoints for per-connector circuit breaker and uptime telemetry.

Issue #2337: tenant-visible health dashboard.

Endpoints:
  GET /api/v1/connectors/health             -- overall health for all connectors
  GET /api/v1/connectors/{connector_id}/health -- per-connector health
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.connector_health_service import ConnectorHealthService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/connectors", tags=["connector-health"])


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class ConnectorHealthResponse(BaseModel):
    """Health snapshot for a single connector.

    Issue #2747 added structured remediation hints (`last_failure_message`,
    `last_failure_category`, `needs_reauth`) so the connector status badge UI
    can route a non-live circuit to the right CTA without parsing free-text
    error strings. Fields are optional/defaulted for backwards compatibility.
    """

    connector_id: str
    circuit_state: str = Field(description="closed | half_open | open")
    success_rate_24h: float = Field(description="Success rate over last 24h (%)")
    p95_latency_ms: float = Field(description="95th percentile latency (ms)")
    p99_latency_ms: float = Field(description="99th percentile latency (ms)")
    total_calls: int = Field(description="Total calls in 24h window")
    total_successes: int = 0
    total_failures: int = 0
    retry_budget_remaining: int = Field(description="Remaining retry tokens")
    last_failure_at: str | None = None
    last_success_at: str | None = None
    uptime_percentage_24h: float = Field(description="Uptime % over last 24h")
    last_failure_message: str | None = Field(
        default=None,
        description="Human-readable last failure message (rendered into UI tooltip)",
    )
    last_failure_category: str | None = Field(
        default=None,
        description="Short failure category tag, e.g. 'auth_expired'",
    )
    needs_reauth: bool = Field(
        default=False,
        description="When true, the UI surfaces a re-auth CTA instead of switch-to-fallback",
    )


class AllConnectorsHealthResponse(BaseModel):
    """Health summary for all connectors of a tenant."""

    connectors: list[ConnectorHealthResponse] = Field(default_factory=list)
    total: int = 0
    open_circuits: int = 0
    degraded: int = 0


def _snapshot_to_response(snapshot: Any) -> ConnectorHealthResponse:
    return ConnectorHealthResponse(
        connector_id=snapshot.connector_id,
        circuit_state=snapshot.circuit_state,
        success_rate_24h=round(snapshot.success_rate_24h, 2),
        p95_latency_ms=round(snapshot.p95_latency_ms, 2),
        p99_latency_ms=round(snapshot.p99_latency_ms, 2),
        total_calls=snapshot.total_calls,
        total_successes=snapshot.total_successes,
        total_failures=snapshot.total_failures,
        retry_budget_remaining=snapshot.retry_budget_remaining,
        last_failure_at=snapshot.last_failure_at,
        last_success_at=snapshot.last_success_at,
        uptime_percentage_24h=round(snapshot.uptime_percentage_24h, 2),
        last_failure_message=getattr(snapshot, "last_failure_message", None),
        last_failure_category=getattr(snapshot, "last_failure_category", None),
        needs_reauth=getattr(snapshot, "needs_reauth", False),
    )


def _get_service() -> ConnectorHealthService:
    from apps.backend.services.connector_health_service import get_connector_health_service

    return get_connector_health_service()


# ---------------------------------------------------------------------------
# GET /api/v1/connectors/health
# ---------------------------------------------------------------------------


@router.get("/health", response_model=AllConnectorsHealthResponse)
async def all_connector_health(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> AllConnectorsHealthResponse:
    """Overall health dashboard for all connectors of the authenticated tenant."""
    svc = _get_service()
    snapshots = svc.get_all_health(tenant_id)
    responses = [_snapshot_to_response(s) for s in snapshots]
    open_circuits = sum(1 for r in responses if r.circuit_state == "open")
    degraded = sum(1 for r in responses if r.circuit_state == "half_open")
    return AllConnectorsHealthResponse(
        connectors=responses,
        total=len(responses),
        open_circuits=open_circuits,
        degraded=degraded,
    )


# ---------------------------------------------------------------------------
# /api/v1/connectors/{connector_id}/health is served by routes_lifecycle.py
# (the canonical `connectors` router) — issue #2747 retired the duplicate
# definition that previously lived here. The canonical route enriches its
# response with the same structured remediation hints surfaced by this
# module's snapshot.
# ---------------------------------------------------------------------------
