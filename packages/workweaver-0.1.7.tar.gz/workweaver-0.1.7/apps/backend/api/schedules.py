"""Schedules API — Agent scheduling endpoints.

Provides CRUD + lifecycle endpoints for Mission Control schedules.
Extended by P2.6 (Scheduled Capabilities) with run-now and capability-aware creation.
"""

from __future__ import annotations

import logging
from datetime import datetime, UTC
from typing import Any

import structlog
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.schemas.error_response import safe_error_detail

router = APIRouter(prefix="/api/v1/mission/schedules", tags=["schedules"])
logger = logging.getLogger(__name__)
structured_logger = structlog.get_logger(__name__)


def _log_schedule_error(
    *,
    error_code: str,
    operation: str,
    tenant_id: str,
    schedule_id: str = "",
) -> None:
    structured_logger.exception(
        "schedule_operation_failed",
        error_code=error_code,
        component="backend.api.schedules",
        route="/api/v1/mission/schedules",
        operation=operation,
        tenant_id=tenant_id,
        schedule_id=schedule_id,
    )


# ---------------------------------------------------------------------------
# Request Models
# ---------------------------------------------------------------------------


class CreateScheduleRequest(BaseModel):
    """Request to create a new schedule."""

    agent_id: str = Field(..., description="Agent/entity ID this schedule belongs to")
    title: str = Field(..., description="Schedule title / display name")
    schedule_type: str = Field(
        ...,
        description="Type of schedule (one_time, recurring, triggered, proactive).",
    )
    description: str = Field("", description="Optional description")
    cron_expression: str | None = Field(None, description="Cron expression for recurring schedules")
    check_interval_minutes: int = Field(5, description="Check interval for proactive schedules")
    next_run_at: str | None = Field(None, description="ISO 8601 timestamp for next scheduled run")
    config: dict[str, Any] = Field(default_factory=dict, description="Schedule-specific configuration")
    # P2.6 fields (optional for backward compatibility)
    capability_id: str | None = Field(None, description="Capability to execute (P2.6)")
    timezone: str | None = Field(None, description="IANA timezone for cron evaluation (P2.6)")
    params: dict[str, Any] | None = Field(None, description="Capability parameters (P2.6)")
    schedule_description: str | None = Field(None, description="NL schedule description to parse (P2.6)")
    routine: dict[str, Any] | None = Field(
        None,
        description="Optional typed routine metadata projected onto schedule.config.routine",
    )


class UpdateScheduleRequest(BaseModel):
    """Request to update an existing schedule."""

    title: str | None = Field(None, description="Updated title")
    description: str | None = Field(None, description="Updated description")
    cron_expression: str | None = Field(None, description="Updated cron expression")
    check_interval_minutes: int | None = Field(None, description="Updated check interval")
    next_run_at: str | None = Field(None, description="Updated next run time")
    config: dict[str, Any] | None = Field(None, description="Updated configuration")
    routine: dict[str, Any] | None = Field(
        None,
        description="Optional typed routine metadata projected onto schedule.config.routine",
    )
    revision: int = Field(..., description="Current revision for optimistic locking")


# ---------------------------------------------------------------------------
# Response Models
# ---------------------------------------------------------------------------


class ScheduleResponse(BaseModel):
    """Response for a single schedule."""

    schedule_id: str
    tenant_id: str
    agent_id: str
    title: str
    description: str
    schedule_type: str
    cron_expression: str | None
    check_interval_minutes: int
    next_run_at: str | None
    status: str
    created_at: str
    updated_at: str
    revision: int
    config: dict[str, Any] = Field(default_factory=dict)


class ScheduleListResponse(BaseModel):
    """Response for list of schedules."""

    schedules: list[ScheduleResponse]
    count: int


class TriggerResponse(BaseModel):
    """Response for triggering or running a schedule."""

    schedule_id: str
    dispatched: bool
    triggered_at: str


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _to_schedule_response(s: dict[str, Any]) -> ScheduleResponse:
    """Convert a raw schedule dict to a ScheduleResponse. DRY helper."""
    return ScheduleResponse(
        schedule_id=s["schedule_id"],
        tenant_id=s["tenant_id"],
        agent_id=s["agent_id"],
        title=s["title"],
        description=s.get("description", ""),
        schedule_type=s["schedule_type"],
        cron_expression=s.get("cron_expression"),
        check_interval_minutes=s.get("check_interval_minutes", 5),
        next_run_at=s.get("next_run_at"),
        status=s.get("status", "active"),
        created_at=s["created_at"],
        updated_at=s["updated_at"],
        revision=s["revision"],
        config=s.get("config", {}),
    )


def _get_store():
    """Lazy import schedule store to avoid circular dependencies."""
    from apps.backend.services.scheduling.store import get_schedule_store

    return get_schedule_store()


def _get_pattern_observer():
    """Lazy import SchedulePatternObserver singleton to avoid circular deps."""
    from apps.backend.services.scheduling.service import _get_pattern_observer as _obs

    return _obs()


def _get_schedule_service():
    """Lazy import ScheduleService (P2.6) to avoid circular dependencies."""
    from apps.backend.services.scheduling.service import get_schedule_service

    return get_schedule_service()


def _get_dispatch_service():
    """Lazy import dispatch service to avoid circular dependencies."""
    from apps.backend.services.agent_dispatch import get_agent_dispatch_service

    return get_agent_dispatch_service()


def _merge_routine_config(
    config: dict[str, Any] | None,
    routine: dict[str, Any] | None,
) -> dict[str, Any]:
    merged = dict(config or {})
    if not routine:
        return merged

    from apps.backend.services.scheduling.routines import RoutineMetadata

    payload: dict[str, Any] = {}
    if isinstance(merged.get("routine"), dict):
        payload.update(merged["routine"])
    payload.update(routine)
    merged["routine"] = RoutineMetadata.model_validate(payload).model_dump(mode="json")
    return merged


# ---------------------------------------------------------------------------
# CRUD Endpoints
# ---------------------------------------------------------------------------


@router.post("/", response_model=ScheduleResponse, status_code=201)
async def create_schedule(
    request: CreateScheduleRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ScheduleResponse:
    """Create a new schedule.

    Supports both legacy (agent_id + config) and P2.6 (capability_id + timezone)
    creation patterns. When capability_id is provided, uses ScheduleService for
    timezone-aware cron computation and NL schedule parsing.
    """
    try:
        # P2.6 path: capability-aware creation with timezone support
        if request.capability_id:
            service = _get_schedule_service()

            # Parse NL schedule description if provided (and no explicit cron)
            cron_expression = request.cron_expression
            if not cron_expression and request.schedule_description:
                parsed = service.parse_nl_schedule(request.schedule_description)
                if parsed:
                    cron_expression = parsed
                else:
                    raise HTTPException(
                        status_code=400,
                        detail=f"Could not parse schedule description: '{request.schedule_description}'",
                    )

            schedule = service.create_schedule(
                tenant_id=tenant_id,
                entity_id=request.agent_id,
                capability_id=request.capability_id,
                display_name=request.title,
                cron_expression=cron_expression,
                timezone=request.timezone or "UTC",
                params=request.params,
                schedule_type=request.schedule_type,
                next_run_at=request.next_run_at,
            )
            if request.routine:
                store = _get_store()
                schedule = store.update_schedule(
                    tenant_id=tenant_id,
                    schedule_id=str(schedule.get("schedule_id") or ""),
                    updates={"config": _merge_routine_config(schedule.get("config"), request.routine)},
                    revision=int(schedule.get("revision") or 1),
                )
        else:
            # Legacy path: direct store creation
            store = _get_store()
            schedule = store.create_schedule(
                tenant_id=tenant_id,
                agent_id=request.agent_id,
                title=request.title,
                schedule_type=request.schedule_type,
                description=request.description,
                cron_expression=request.cron_expression,
                check_interval_minutes=request.check_interval_minutes,
                next_run_at=request.next_run_at,
                config=_merge_routine_config(request.config, request.routine),
            )

        return _to_schedule_response(schedule)

    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception:
        _log_schedule_error(
            error_code="schedule_create_failed",
            operation="create_schedule",
            tenant_id=tenant_id,
        )
        raise HTTPException(status_code=500, detail="Failed to create schedule")


@router.get("/", response_model=ScheduleListResponse)
async def list_schedules(
    tenant_id: str = Depends(get_verified_tenant_id),
    agent_id: str | None = Query(None, description="Filter by agent/entity ID"),
    schedule_type: str | None = Query(None, description="Filter by schedule type"),
    status: str | None = Query(None, description="Filter by status"),
    limit: int = Query(100, ge=1, le=500, description="Max schedules to return"),
) -> ScheduleListResponse:
    """List all schedules with optional filters."""
    try:
        store = _get_store()
        schedules = store.list_schedules(tenant_id, agent_id=agent_id, schedule_type=schedule_type, status=status)[
            :limit
        ]

        responses = [_to_schedule_response(s) for s in schedules]
        return ScheduleListResponse(schedules=responses, count=len(responses))

    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception:
        _log_schedule_error(
            error_code="schedule_list_failed",
            operation="list_schedules",
            tenant_id=tenant_id,
        )
        raise HTTPException(status_code=500, detail="Failed to list schedules")


@router.get("/{schedule_id}", response_model=ScheduleResponse)
async def get_schedule(
    schedule_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ScheduleResponse:
    """Get a single schedule by ID."""
    try:
        store = _get_store()
        schedule = store.get_schedule(tenant_id, schedule_id)
        if not schedule:
            raise HTTPException(status_code=404, detail=f"Schedule {schedule_id} not found")
        return _to_schedule_response(schedule)

    except HTTPException:
        raise
    except Exception:
        _log_schedule_error(
            error_code="schedule_get_failed",
            operation="get_schedule",
            tenant_id=tenant_id,
            schedule_id=schedule_id,
        )
        raise HTTPException(status_code=500, detail="Failed to get schedule")


@router.patch("/{schedule_id}", response_model=ScheduleResponse)
async def update_schedule(
    schedule_id: str,
    request: UpdateScheduleRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ScheduleResponse:
    """Update an existing schedule (partial update)."""
    try:
        store = _get_store()
        current = store.get_schedule(tenant_id, schedule_id)
        if not current:
            raise HTTPException(status_code=404, detail=f"Schedule {schedule_id} not found")

        updates: dict[str, Any] = {}
        if request.title is not None:
            updates["title"] = request.title
        if request.description is not None:
            updates["description"] = request.description
        if request.cron_expression is not None:
            updates["cron_expression"] = request.cron_expression
        if request.check_interval_minutes is not None:
            updates["check_interval_minutes"] = request.check_interval_minutes
        if request.next_run_at is not None:
            updates["next_run_at"] = request.next_run_at
        if request.config is not None:
            updates["config"] = request.config
        if request.routine is not None:
            updates["config"] = _merge_routine_config(
                updates.get("config", current.get("config")),
                request.routine,
            )

        schedule = store.update_schedule(
            tenant_id=tenant_id,
            schedule_id=schedule_id,
            updates=updates,
            revision=request.revision,
        )

        # Notify pattern observer so learning loop tracks reschedule frequency.
        try:
            observer = _get_pattern_observer()
            observer.on_schedule_modified(
                tenant_id=tenant_id,
                schedule_id=schedule_id,
                task_title=str(schedule.get("title", schedule_id)),
                modification_type="rescheduled",
                agent_id=str(schedule.get("agent_id", "")),
                metadata={k: updates[k] for k in ("next_run_at", "cron_expression") if k in updates},
            )
        except Exception:
            logger.warning(
                "schedule_pattern_observer.on_schedule_modified failed for %s",
                schedule_id,
                exc_info=True,
            )

        return _to_schedule_response(schedule)

    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=409, detail=safe_error_detail(e))
    except Exception:
        _log_schedule_error(
            error_code="schedule_update_failed",
            operation="update_schedule",
            tenant_id=tenant_id,
            schedule_id=schedule_id,
        )
        raise HTTPException(status_code=500, detail="Failed to update schedule")


# PUT uses the same logic as PATCH for full replacement
@router.put("/{schedule_id}", response_model=ScheduleResponse)
async def replace_schedule(
    schedule_id: str,
    request: UpdateScheduleRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ScheduleResponse:
    """Replace an existing schedule (full update, same semantics as PATCH)."""
    return await update_schedule(schedule_id, request, tenant_id)


@router.delete("/{schedule_id}")
async def delete_schedule(
    schedule_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, bool]:
    """Delete a schedule."""
    try:
        store = _get_store()
        success = store.delete_schedule(tenant_id, schedule_id)
        return {"deleted": success}

    except ValueError as e:
        raise HTTPException(status_code=404, detail=safe_error_detail(e))
    except Exception:
        _log_schedule_error(
            error_code="schedule_delete_failed",
            operation="delete_schedule",
            tenant_id=tenant_id,
            schedule_id=schedule_id,
        )
        raise HTTPException(status_code=500, detail="Failed to delete schedule")


# ---------------------------------------------------------------------------
# Lifecycle Endpoints
# ---------------------------------------------------------------------------


@router.post("/{schedule_id}/pause", response_model=ScheduleResponse)
async def pause_schedule(
    schedule_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ScheduleResponse:
    """Pause a schedule."""
    try:
        store = _get_store()
        schedule = store.pause_schedule(tenant_id, schedule_id)
        return _to_schedule_response(schedule)

    except ValueError as e:
        raise HTTPException(status_code=404, detail=safe_error_detail(e))
    except Exception:
        _log_schedule_error(
            error_code="schedule_pause_failed",
            operation="pause_schedule",
            tenant_id=tenant_id,
            schedule_id=schedule_id,
        )
        raise HTTPException(status_code=500, detail="Failed to pause schedule")


@router.post("/{schedule_id}/resume", response_model=ScheduleResponse)
async def resume_schedule(
    schedule_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ScheduleResponse:
    """Resume a paused schedule."""
    try:
        store = _get_store()
        schedule = store.resume_schedule(tenant_id, schedule_id)
        return _to_schedule_response(schedule)

    except ValueError as e:
        raise HTTPException(status_code=404, detail=safe_error_detail(e))
    except Exception:
        _log_schedule_error(
            error_code="schedule_resume_failed",
            operation="resume_schedule",
            tenant_id=tenant_id,
            schedule_id=schedule_id,
        )
        raise HTTPException(status_code=500, detail="Failed to resume schedule")


@router.get("/upcoming/list", response_model=ScheduleListResponse)
async def list_upcoming(
    tenant_id: str = Depends(get_verified_tenant_id),
    hours: int = Query(24, ge=1, le=168, description="Number of hours to look ahead"),
    limit: int = Query(100, ge=1, le=500, description="Max schedules to return"),
) -> ScheduleListResponse:
    """List upcoming schedules within specified hours."""
    try:
        store = _get_store()
        schedules = store.list_upcoming(tenant_id, hours=hours)[:limit]
        responses = [_to_schedule_response(s) for s in schedules]
        return ScheduleListResponse(schedules=responses, count=len(responses))

    except Exception:
        _log_schedule_error(
            error_code="schedule_list_upcoming_failed",
            operation="list_upcoming",
            tenant_id=tenant_id,
        )
        raise HTTPException(status_code=500, detail="Failed to list upcoming schedules")


@router.post("/{schedule_id}/trigger", response_model=TriggerResponse)
async def trigger_schedule(
    schedule_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> TriggerResponse:
    """Fire a triggered schedule immediately by enqueuing to SQS.

    Only schedules with schedule_type="triggered" can be fired via this
    endpoint. Use /run-now to execute any schedule type immediately.
    """
    try:
        store = _get_store()
        schedule = store.get_schedule(tenant_id, schedule_id)

        if not schedule:
            raise HTTPException(status_code=404, detail=f"Schedule {schedule_id} not found")

        if schedule.get("schedule_type") != "triggered":
            raise HTTPException(
                status_code=400,
                detail=(
                    f"Schedule {schedule_id} has type '{schedule.get('schedule_type')}'. "
                    "Only 'triggered' schedules can be fired via this endpoint. "
                    "Use /run-now for other schedule types."
                ),
            )

        if schedule.get("status") != "active":
            raise HTTPException(
                status_code=400,
                detail=f"Schedule {schedule_id} is not active (status: {schedule.get('status')})",
            )

        agent_id = schedule.get("agent_id", "")
        triggered_at = datetime.now(UTC).isoformat()

        dispatch = _get_dispatch_service()
        dispatched = dispatch.dispatch_scheduled_run(
            tenant_id=tenant_id,
            agent_id=agent_id,
            schedule_type="triggered",
            session_context={
                "triggered_by": "api",
                "schedule_id": schedule_id,
                "triggered_at": triggered_at,
            },
        )

        # Update last_fired_at (best-effort)
        try:
            store.update_schedule(
                tenant_id=tenant_id,
                schedule_id=schedule_id,
                updates={"last_fired_at": triggered_at},
                revision=schedule.get("revision", 1),
            )
        except Exception as exc:
            logger.warning("Failed to update last_fired_at for schedule %s: %s", schedule_id, exc)

        return TriggerResponse(
            schedule_id=schedule_id,
            dispatched=dispatched,
            triggered_at=triggered_at,
        )

    except HTTPException:
        raise
    except Exception:
        _log_schedule_error(
            error_code="schedule_trigger_failed",
            operation="trigger_schedule",
            tenant_id=tenant_id,
            schedule_id=schedule_id,
        )
        raise HTTPException(status_code=500, detail="Failed to trigger schedule")


# ---------------------------------------------------------------------------
# P2.6: Run-Now — execute any schedule type immediately
# ---------------------------------------------------------------------------


@router.post("/{schedule_id}/run-now", response_model=TriggerResponse)
async def run_now(
    schedule_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> TriggerResponse:
    """Execute any active schedule immediately, regardless of schedule_type.

    Unlike /trigger (which only works for 'triggered' type schedules), /run-now
    can execute any schedule type (recurring, one_time, proactive, triggered).
    The schedule is dispatched to the SQS queue and last_fired_at is updated.

    This does NOT affect the schedule's next_run_at — it is an out-of-band
    execution. The schedule_runner Lambda will still fire at the next scheduled
    time independently.
    """
    try:
        store = _get_store()
        schedule = store.get_schedule(tenant_id, schedule_id)

        if not schedule:
            raise HTTPException(status_code=404, detail=f"Schedule {schedule_id} not found")

        if schedule.get("status") != "active":
            raise HTTPException(
                status_code=400,
                detail=f"Schedule {schedule_id} is not active (status: {schedule.get('status')})",
            )

        agent_id = schedule.get("agent_id", "")
        schedule_type = schedule.get("schedule_type", "")
        triggered_at = datetime.now(UTC).isoformat()

        dispatch = _get_dispatch_service()
        dispatched = dispatch.dispatch_scheduled_run(
            tenant_id=tenant_id,
            agent_id=agent_id,
            schedule_type=schedule_type,
            session_context={
                "triggered_by": "run_now",
                "schedule_id": schedule_id,
                "triggered_at": triggered_at,
            },
        )

        # Update last_fired_at (best-effort)
        try:
            store.update_schedule(
                tenant_id=tenant_id,
                schedule_id=schedule_id,
                updates={"last_fired_at": triggered_at},
                revision=schedule.get("revision", 1),
            )
        except Exception as exc:
            logger.warning("Failed to update last_fired_at for schedule %s: %s", schedule_id, exc)

        return TriggerResponse(
            schedule_id=schedule_id,
            dispatched=dispatched,
            triggered_at=triggered_at,
        )

    except HTTPException:
        raise
    except Exception:
        _log_schedule_error(
            error_code="schedule_run_now_failed",
            operation="run_now",
            tenant_id=tenant_id,
            schedule_id=schedule_id,
        )
        raise HTTPException(status_code=500, detail="Failed to execute schedule")
