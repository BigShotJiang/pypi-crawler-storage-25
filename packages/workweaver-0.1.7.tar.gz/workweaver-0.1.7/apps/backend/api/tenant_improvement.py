"""Tenant improvement API (P4.2) -- weekly improvement report endpoint.

Endpoint:
    GET /api/v1/tenant/improvement-report
        Query params: learning_posture (aggressive|moderate|conservative)
        Returns: WeeklyImprovementReport as JSON

Legacy requirement reference: docs/CAPABILITIES.md P4.2
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, Query

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/tenant", tags=["tenant-improvement"])


def _build_service() -> Any:
    """Build TenantImprovementService with real evidence ledger."""
    from apps.backend.services.evidence_ledger import get_evidence_ledger_service
    from apps.backend.services.tenant_improvement_loop import TenantImprovementService

    return TenantImprovementService(evidence_service=get_evidence_ledger_service())


@router.get("/improvement-report")
def get_improvement_report(
    learning_posture: str = Query(
        "moderate",
        pattern="^(aggressive|moderate|conservative)$",
        description="Tenant learning posture controlling auto-apply behavior",
    ),
    tenant_id: str = Depends(get_verified_tenant_id),
    service: Any = Depends(_build_service),
) -> dict[str, Any]:
    """Return the weekly improvement report for the authenticated tenant.

    The report includes:
    - Total capabilities tracked
    - Average success rate across all capabilities
    - List of underperforming capabilities (below 80% success rate)
    - Learning posture and auto-apply status
    - Human-readable summary
    """
    report = service.generate_weekly_report(
        tenant_id=tenant_id,
        learning_posture=learning_posture,
    )
    return report.to_dict()
