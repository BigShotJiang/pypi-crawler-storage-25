"""Entity Phone API — assign, query, and release phone numbers per entity.

Endpoints:
    POST   /api/v1/entities/{entity_id}/phone      — Assign phone number
    GET    /api/v1/entities/{entity_id}/phone      — Get assigned number
    DELETE /api/v1/entities/{entity_id}/phone      — Release number
    GET    /api/v1/phone/assignments                — List all tenant assignments

PR-F: Multi-level phone entity scoping.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.entity_phone_routing import get_entity_phone_router

logger = logging.getLogger(__name__)

router = APIRouter(tags=["phone"])


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class AssignPhoneRequest(BaseModel):
    """Request body for assigning a phone number to an entity."""

    phone_number: str = Field(
        ...,
        description="E.164 phone number (e.g. +14155551234)",
        pattern=r"^\+[1-9]\d{7,14}$",
    )


class PhoneAssignmentResponse(BaseModel):
    """Response for a phone assignment operation."""

    entity_id: str
    phone_number: str
    tenant_id: str
    message: str


class PhoneGetResponse(BaseModel):
    """Response for querying an entity's phone number."""

    entity_id: str
    phone_number: str | None
    tenant_id: str


class PhoneAssignmentItem(BaseModel):
    """Single entry in the assignments list."""

    entity_id: str
    phone_number: str
    assigned_at: str | None = None


class PhoneAssignmentListResponse(BaseModel):
    """Response for listing all phone assignments in a tenant."""

    tenant_id: str
    assignments: list[PhoneAssignmentItem]
    count: int


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/api/v1/entities/{entity_id}/phone",
    response_model=PhoneAssignmentResponse,
    status_code=status.HTTP_200_OK,
)
async def assign_phone(
    entity_id: str,
    body: AssignPhoneRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PhoneAssignmentResponse:
    """Assign a phone number to an entity.

    Creates a tenant-scoped mapping between the entity and the phone number.
    Rejects duplicates: a phone number can only be assigned to one entity per tenant.
    """
    phone_router = get_entity_phone_router()
    try:
        phone_router.assign_phone(tenant_id, entity_id, body.phone_number)
    except ValueError as exc:
        logger.error("Phone assignment failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid request parameters",
        ) from exc

    logger.info("Assigned phone %s to entity %s tenant %s", body.phone_number, entity_id, tenant_id)
    return PhoneAssignmentResponse(
        entity_id=entity_id,
        phone_number=body.phone_number,
        tenant_id=tenant_id,
        message=f"Phone {body.phone_number} assigned to entity {entity_id}",
    )


@router.get(
    "/api/v1/entities/{entity_id}/phone",
    response_model=PhoneGetResponse,
    status_code=status.HTTP_200_OK,
)
async def get_entity_phone(
    entity_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PhoneGetResponse:
    """Get the phone number assigned to an entity."""
    phone_router = get_entity_phone_router()
    phone_number = phone_router.get_phone(tenant_id, entity_id)
    return PhoneGetResponse(
        entity_id=entity_id,
        phone_number=phone_number,
        tenant_id=tenant_id,
    )


@router.delete(
    "/api/v1/entities/{entity_id}/phone",
    status_code=status.HTTP_200_OK,
    response_model=PhoneAssignmentResponse,
)
async def release_entity_phone(
    entity_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PhoneAssignmentResponse:
    """Release the phone number assigned to an entity."""
    phone_router = get_entity_phone_router()
    phone_router.release_phone(tenant_id, entity_id)
    logger.info("Released phone for entity %s tenant %s", entity_id, tenant_id)
    return PhoneAssignmentResponse(
        entity_id=entity_id,
        phone_number="",
        tenant_id=tenant_id,
        message=f"Phone released for entity {entity_id}",
    )


@router.get(
    "/api/v1/phone/assignments",
    response_model=PhoneAssignmentListResponse,
    status_code=status.HTTP_200_OK,
)
async def list_phone_assignments(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PhoneAssignmentListResponse:
    """List all entity-phone assignments for the tenant."""
    phone_router = get_entity_phone_router()
    assignments = phone_router.list_assignments(tenant_id)
    items = [
        PhoneAssignmentItem(
            entity_id=a.get("entity_id", ""),
            phone_number=a.get("phone_number", ""),
            assigned_at=a.get("assigned_at"),
        )
        for a in assignments
    ]
    return PhoneAssignmentListResponse(
        tenant_id=tenant_id,
        assignments=items,
        count=len(items),
    )
