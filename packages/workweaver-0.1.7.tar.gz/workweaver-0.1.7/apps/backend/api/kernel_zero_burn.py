"""Tenant-wide zero-burn SLI surface (#2879).

Per-Function snapshots already ship at
``GET /api/v1/work-functions/{id}/zero-burn-snapshot`` (#3468). This
module adds the tenant-aggregated read so Zara — and the operator who
asks "what's our zero-burn ratio right now?" — get a single
authoritative answer instead of having to fan out per-Function.

Routes:

* ``GET /api/v1/kernel/zero-burn`` — ratio + status + per-Function rows.

Design notes:

* The route is read-only and emits no Decision Trace; the per-Function
  read at ``/work-functions/{id}/zero-burn-snapshot`` already emits a
  trace. The §14 ``kernel.capacity_check`` skill is the trace-emitting
  surface for the aggregate read (`kernel.capacity_check.run` →
  Decision Trace → minute-bucket idempotency).
* The tenant aggregator walks ``FunctionCapacityEnvelope`` to enumerate
  the workspace's Functions, then asks
  ``ZeroBurnSLIService.tenant_zero_burn_summary`` for the rollup.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.capacity.zero_burn_sli import (
    get_zero_burn_sli_service,
)
from apps.backend.services.zara.zara_awareness_service import (
    list_function_capacity_envelopes,
)

router = APIRouter(prefix="/api/v1/kernel/zero-burn", tags=["kernel", "zero-burn"])


class ZeroBurnFunctionRow(BaseModel):
    work_function_id: str
    is_zero_burn: bool
    active_workers: int = 0
    capacity_leases: int = 0
    queue_consumers: int = 0
    connector_sessions: int = 0
    scheduler_claims: int = 0
    cloud_tasks: int = 0
    function_metering_events: int = 0
    billable_compute_units: str = "0"


class ZeroBurnSummaryResponse(BaseModel):
    """Tenant-wide zero-burn SLI summary."""

    workspace_id: str
    function_count: int = 0
    dormant_count: int = 0
    non_dormant_count: int = 0
    dormant_ratio: float = 0.0
    status: str = "unknown"
    window_hours: int = 24
    functions: list[ZeroBurnFunctionRow] = Field(default_factory=list)


@router.get("", response_model=ZeroBurnSummaryResponse)
def read_zero_burn_summary(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ZeroBurnSummaryResponse:
    """Return the tenant-wide zero-burn SLI summary."""
    envelopes = list_function_capacity_envelopes(tenant_id)
    function_ids = [env.function_id for env in envelopes]
    sli = get_zero_burn_sli_service()
    payload = sli.tenant_zero_burn_summary(
        workspace_id=tenant_id, function_ids=function_ids
    )
    rows = [ZeroBurnFunctionRow(**row) for row in payload.get("functions", [])]
    return ZeroBurnSummaryResponse(
        workspace_id=str(payload.get("workspace_id") or tenant_id),
        function_count=int(payload.get("function_count") or 0),
        dormant_count=int(payload.get("dormant_count") or 0),
        non_dormant_count=int(payload.get("non_dormant_count") or 0),
        dormant_ratio=float(payload.get("dormant_ratio") or 0.0),
        status=str(payload.get("status") or "unknown"),
        window_hours=int(payload.get("window_hours") or 24),
        functions=rows,
    )


__all__ = [
    "router",
    "ZeroBurnSummaryResponse",
    "ZeroBurnFunctionRow",
    "read_zero_burn_summary",
]
