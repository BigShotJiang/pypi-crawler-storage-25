"""REST surface for the healing digest (#3550)."""

from __future__ import annotations

import re
from datetime import UTC, datetime

from fastapi import APIRouter, Depends, HTTPException, Query, status

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.healing_digest import (
    HealingDigest,
    HealingDigestService,
    get_healing_digest_service,
    month_key,
)


router = APIRouter(prefix="/api/v1/tenant/healing", tags=["tenant", "healing"])


_MONTH_RE = re.compile(r"^\d{4}-\d{2}$")


def _service() -> HealingDigestService:
    return get_healing_digest_service()


@router.get("/digest", response_model=HealingDigest)
def get_healing_digest(
    month: str | None = Query(
        default=None,
        description="YYYY-MM. Defaults to the current UTC month.",
    ),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> HealingDigest:
    target_month = month or month_key(datetime.now(UTC))
    if not _MONTH_RE.match(target_month):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"invalid month: {target_month!r}; expected YYYY-MM",
        )
    return _service().digest(tenant_id=tenant_id, month=target_month)


__all__ = ["router"]
