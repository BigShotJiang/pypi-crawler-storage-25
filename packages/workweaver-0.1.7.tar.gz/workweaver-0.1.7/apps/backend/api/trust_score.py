"""Trust Score API endpoint.

M10.5 — GET /api/v1/agents/{agent_id}/trust-score

Returns a per-agent trust score computed from approval history,
task success rate, and evidence quality. Includes a boolean
`relaxed_approval` flag indicating whether the agent has earned
enough trust to skip mandatory approval on low-risk tools.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.trust_score import (
    DEFAULT_TRUST_THRESHOLD,
    TrustScoreResolver,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/agents", tags=["trust-score"])


# ---------------------------------------------------------------------------
# Lazy service accessor (avoid import-time boto3 failures in tests)
# ---------------------------------------------------------------------------


def _get_trust_score_resolver() -> TrustScoreResolver:
    return TrustScoreResolver()


# ---------------------------------------------------------------------------
# Response model
# ---------------------------------------------------------------------------


class TrustScoreResponse(BaseModel):
    """Response for the trust score endpoint."""

    agent_id: str = Field(..., description="Agent identifier")
    approval_ratio: float = Field(..., description="Approved / (approved + rejected)")
    task_success_ratio: float = Field(..., description="Success / (success + failure)")
    evidence_quality_avg: float = Field(..., description="Mean evidence quality score")
    total: float = Field(..., description="Weighted trust score (0.0 to 1.0)")
    relaxed_approval: bool = Field(
        ...,
        description="True if trust score exceeds threshold and approval can be optional",
    )
    threshold: float = Field(..., description="Trust threshold used for relaxation decision")


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------


@router.get("/{agent_id}/trust-score", response_model=TrustScoreResponse)
async def get_agent_trust_score(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    threshold: float = Query(
        DEFAULT_TRUST_THRESHOLD,
        ge=0.0,
        le=1.0,
        description="Trust threshold for approval relaxation",
    ),
) -> TrustScoreResponse:
    """Compute and return the trust score for an agent.

    Aggregates data from:
    - Approval gates: approved vs rejected requests for this agent
    - Decision events: task outcomes and evidence quality

    The ``relaxed_approval`` flag indicates whether the agent qualifies
    for optional (rather than mandatory) approval on low-risk tools.
    """
    try:
        resolution = _get_trust_score_resolver().resolve(
            tenant_id,
            agent_id,
            threshold=threshold,
        )

        return TrustScoreResponse(
            agent_id=agent_id,
            approval_ratio=resolution.score.approval_ratio,
            task_success_ratio=resolution.score.task_success_ratio,
            evidence_quality_avg=resolution.score.evidence_quality_avg,
            total=resolution.score.total,
            relaxed_approval=resolution.relaxed_approval,
            threshold=resolution.threshold,
        )

    except Exception as exc:
        logger.error(
            "Failed to compute trust score for agent %s: %s",
            agent_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to compute trust score",
        ) from exc
