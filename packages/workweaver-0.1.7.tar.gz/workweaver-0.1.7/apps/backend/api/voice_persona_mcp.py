"""Voice Persona MCP tool dispatch -- ww.voice.persona.* tools (#2798)."""
from __future__ import annotations
from typing import Any


def dispatch_voice_persona_tool(
    *,
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
    service: Any,
) -> Any:
    """Dispatch a voice persona MCP tool to the service layer."""
    if tool_name in {"ww.voice.clone.register", "ww.voice.persona.clone.register"}:
        return service.register_clone_ownership(
            tenant_id=tenant_id,
            voice_id=str(parameters.get("voice_id") or ""),
            name=parameters.get("name"),
            provider=str(parameters.get("provider") or "custom"),
            provider_clone_id=str(parameters.get("provider_clone_id") or ""),
            proof_ref=str(parameters.get("proof_ref") or ""),
            description=str(parameters.get("description") or ""),
        )
    if tool_name == "ww.voice.persona.create":
        return service.create_persona(
            tenant_id=tenant_id,
            name=str(parameters.get("name") or ""),
            voice_id=str(parameters.get("voice_id") or "ara"),
            language=str(parameters.get("language") or "en"),
            speaking_rate=float(parameters.get("speaking_rate") or 1.0),
            pitch=float(parameters.get("pitch") or 0.0),
            greeting_script=str(parameters.get("greeting_script") or ""),
            hold_message=str(parameters.get("hold_message") or ""),
            transfer_message=str(parameters.get("transfer_message") or ""),
            pronunciation_dict=parameters.get("pronunciation_dict"),
            from_template=parameters.get("from_template"),
        )
    if tool_name == "ww.voice.persona.list":
        return service.list_personas(tenant_id)
    if tool_name in {"ww.voice.catalog.list", "ww.voice.persona.voices"}:
        return service.list_voice_catalog(tenant_id)
    if tool_name == "ww.voice.persona.get":
        persona_id = str(parameters.get("persona_id") or "")
        result = service.get_persona(tenant_id, persona_id)
        if result is None:
            return {"error": "Persona not found", "persona_id": persona_id}
        return result
    if tool_name == "ww.voice.persona.update":
        persona_id = str(parameters.get("persona_id") or "")
        updates = {k: v for k, v in parameters.items() if k != "persona_id" and v is not None}
        return service.update_persona(tenant_id=tenant_id, persona_id=persona_id, updates=updates)
    if tool_name == "ww.voice.persona.delete":
        persona_id = str(parameters.get("persona_id") or "")
        deleted = service.delete_persona(tenant_id, persona_id)
        return {"deleted": deleted, "persona_id": persona_id}
    if tool_name == "ww.voice.persona.templates":
        return service.list_templates()
    raise ValueError(f"Unknown voice persona tool: {tool_name}")
