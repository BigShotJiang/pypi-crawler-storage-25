"""Admin meeting provider API -- platform-level credential management.

Endpoints (all require founder auth):
  GET    /api/v1/founder/meeting/providers
  POST   /api/v1/founder/meeting/providers/{provider_id}
  GET    /api/v1/founder/meeting/providers/tenants/{tenant_id}
  POST   /api/v1/founder/meeting/providers/tenants/{tenant_id}/{provider_id}
  DELETE /api/v1/founder/meeting/providers/tenants/{tenant_id}/{provider_id}

Credentials are never returned.  Only ``has_credentials: bool`` is exposed.
"""

from __future__ import annotations

import logging
import os
import re
from http import HTTPStatus
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field, field_validator

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.api.founder_admin import require_founder
from apps.backend.services.admin.admin_permission import AdminPermission
from apps.backend.schemas.error_response import safe_error_detail
from apps.backend.services.admin_meeting_provider_store import (
    CANONICAL_MEETING_PROVIDERS,
    AdminMeetingProviderStore,
    AdminMeetingProviderStoreError,
    get_admin_meeting_provider_store,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/founder/meeting", tags=["founder-admin-meeting"])

# Pattern for safe IDs.
_SAFE_ID_RE = re.compile(r"^[a-zA-Z0-9\-_]{1,120}$")

# Provider sources: which env var provides the credential when admin store is empty.
_PROVIDER_ENV_VARS: dict[str, str] = {
    "recall_us_west_2": "RECALL_AI_API_KEY_US_WEST_2",
    "recall_eu_central_1": "RECALL_AI_API_KEY_EU_CENTRAL_1",
    "recall_ap_northeast_1": "RECALL_AI_API_KEY_AP_NORTHEAST_1",
    "deepgram": "DEEPGRAM_API_KEY",
    "sarvam": "SARVAM_API_KEY",
}

_PROVIDER_LABELS: dict[str, str] = {
    "recall_us_west_2": "Recall.ai (US West 2)",
    "recall_eu_central_1": "Recall.ai (EU Central 1)",
    "recall_ap_northeast_1": "Recall.ai (AP Northeast 1)",
    "deepgram": "Deepgram",
    "sarvam": "Sarvam AI",
}


# ============================================================================
# Dependency helpers
# ============================================================================


def _get_store() -> AdminMeetingProviderStore:
    return get_admin_meeting_provider_store()


def _validate_safe_id(v: str, field_name: str) -> str:
    v = v.strip()
    if not v:
        raise ValueError(f"{field_name} must not be empty")
    if not _SAFE_ID_RE.match(v):
        raise ValueError(
            f"{field_name} contains invalid characters or exceeds 120 chars. "
            "Only alphanumeric, dash, and underscore are allowed."
        )
    return v


def _validate_provider_id(provider_id: str) -> str:
    """Validate and return a canonical meeting provider ID."""
    _validate_safe_id(provider_id, "provider_id")
    if provider_id not in CANONICAL_MEETING_PROVIDERS:
        raise HTTPException(
            status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
            detail=(
                f"Unknown meeting provider: {provider_id!r}. "
                f"Valid providers: {sorted(CANONICAL_MEETING_PROVIDERS)}"
            ),
        )
    return provider_id


# ============================================================================
# Request / Response models
# ============================================================================


class UpsertMeetingProviderRequest(BaseModel):
    credentials: dict[str, Any] | None = Field(
        None,
        description=(
            "Credential payload to encrypt and store via vault. "
            "Expected: {api_key: '...'}. Omit to leave existing credentials unchanged."
        ),
    )
    enabled: bool = Field(True, description="Whether this provider is active")

    @field_validator("credentials")
    @classmethod
    def _validate_credentials(cls, v: dict[str, Any] | None) -> dict[str, Any] | None:
        if v is not None and not v.get("api_key"):
            raise ValueError("credentials must contain a non-empty 'api_key' field")
        return v


class MeetingProviderSummary(BaseModel):
    provider_id: str
    label: str
    enabled: bool
    has_credentials: bool
    source: str = Field(description="Where the credential comes from: admin_store | env_var | none")
    updated_at: str = ""


class TenantOverrideSummary(BaseModel):
    provider_id: str
    label: str
    enabled: bool
    has_credentials: bool
    updated_at: str = ""


# ============================================================================
# Helper: determine credential source
# ============================================================================


def _credential_source(provider_id: str, has_vault_ref: bool) -> str:
    """Determine where the effective credential comes from."""
    if has_vault_ref:
        return "admin_store"
    env_var = _PROVIDER_ENV_VARS.get(provider_id, "")
    if env_var:
        value = (os.getenv(env_var) or "").strip()
        placeholder = {"__fill_me__", "changeme", "placeholder", ""}
        if value.lower() not in placeholder:
            return "env_var"
    # Also check flat RECALL_AI_API_KEY for recall providers
    if provider_id.startswith("recall_"):
        flat = (os.getenv("RECALL_AI_API_KEY") or "").strip()
        placeholder = {"__fill_me__", "changeme", "placeholder", ""}
        if flat.lower() not in placeholder:
            return "env_var"
    return "none"


def _has_any_credential(provider_id: str, has_vault_ref: bool) -> bool:
    """Check if any credential is available for this provider."""
    return _credential_source(provider_id, has_vault_ref) != "none"


# ============================================================================
# Endpoints
# ============================================================================


@router.get("/providers", response_model=list[MeetingProviderSummary])
async def list_providers(
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.MEETING_READ)),
    store: AdminMeetingProviderStore = Depends(_get_store),
) -> list[dict[str, Any]]:
    """List all 5 canonical meeting providers with credential status."""
    stored = {p["provider_id"]: p for p in store.list_global_providers()}

    result: list[dict[str, Any]] = []
    for pid in sorted(CANONICAL_MEETING_PROVIDERS):
        row = stored.get(pid)
        has_vault_ref = bool(row and row.get("credential_vault_ref"))
        result.append({
            "provider_id": pid,
            "label": _PROVIDER_LABELS.get(pid, pid),
            "enabled": bool(row and row.get("enabled", False)) if row else False,
            "has_credentials": _has_any_credential(pid, has_vault_ref),
            "source": _credential_source(pid, has_vault_ref),
            "updated_at": row.get("updated_at", "") if row else "",
        })
    return result


@router.post("/providers/{provider_id}", response_model=MeetingProviderSummary)
async def upsert_provider(
    provider_id: str,
    body: UpsertMeetingProviderRequest,
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.MEETING_WRITE)),
    store: AdminMeetingProviderStore = Depends(_get_store),
) -> dict[str, Any]:
    """Create or update credentials for a global meeting provider."""
    provider_id = _validate_provider_id(provider_id)

    try:
        result = store.upsert_global_provider(
            provider_id=provider_id,
            label=_PROVIDER_LABELS.get(provider_id, provider_id),
            credentials=body.credentials,
            enabled=body.enabled,
        )
    except AdminMeetingProviderStoreError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=safe_error_detail(exc),
        )

    has_vault_ref = bool(result.get("credential_vault_ref"))
    logger.info(
        "admin_meeting.upsert_provider provider=%s founder=%s",
        provider_id,
        _founder,
    )
    return {
        "provider_id": result["provider_id"],
        "label": result["label"],
        "enabled": result["enabled"],
        "has_credentials": _has_any_credential(provider_id, has_vault_ref),
        "source": _credential_source(provider_id, has_vault_ref),
        "updated_at": result.get("updated_at", ""),
    }


@router.get("/providers/tenants/{tenant_id}", response_model=list[TenantOverrideSummary])
async def list_tenant_overrides(
    tenant_id: str,
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.MEETING_READ)),
    store: AdminMeetingProviderStore = Depends(_get_store),
) -> list[dict[str, Any]]:
    """List per-tenant meeting provider overrides."""
    try:
        _validate_safe_id(tenant_id, "tenant_id")
    except ValueError as exc:
        raise HTTPException(
            status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
            detail=str(exc),
        )

    overrides = store.list_tenant_overrides(tenant_id)
    return [
        {
            "provider_id": o["provider_id"],
            "label": o["label"],
            "enabled": o["enabled"],
            "has_credentials": bool(o.get("credential_vault_ref")),
            "updated_at": o.get("updated_at", ""),
        }
        for o in overrides
    ]


@router.post(
    "/providers/tenants/{tenant_id}/{provider_id}",
    response_model=TenantOverrideSummary,
)
async def upsert_tenant_override(
    tenant_id: str,
    provider_id: str,
    body: UpsertMeetingProviderRequest,
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.MEETING_WRITE)),
    store: AdminMeetingProviderStore = Depends(_get_store),
) -> dict[str, Any]:
    """Create or update per-tenant meeting provider override."""
    try:
        _validate_safe_id(tenant_id, "tenant_id")
    except ValueError as exc:
        raise HTTPException(
            status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
            detail=str(exc),
        )
    provider_id = _validate_provider_id(provider_id)

    try:
        result = store.upsert_tenant_override(
            tenant_id=tenant_id,
            provider_id=provider_id,
            credentials=body.credentials,
            enabled=body.enabled,
        )
    except AdminMeetingProviderStoreError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=safe_error_detail(exc),
        )

    logger.info(
        "admin_meeting.upsert_tenant_override tenant=%s provider=%s founder=%s",
        tenant_id,
        provider_id,
        _founder,
    )
    return {
        "provider_id": result["provider_id"],
        "label": result["label"],
        "enabled": result["enabled"],
        "has_credentials": bool(result.get("credential_vault_ref")),
        "updated_at": result.get("updated_at", ""),
    }


@router.delete(
    "/providers/tenants/{tenant_id}/{provider_id}",
    status_code=HTTPStatus.NO_CONTENT,
)
async def delete_tenant_override(
    tenant_id: str,
    provider_id: str,
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.MEETING_WRITE)),
    store: AdminMeetingProviderStore = Depends(_get_store),
) -> None:
    """Delete a per-tenant override, reverting to global credentials."""
    try:
        _validate_safe_id(tenant_id, "tenant_id")
    except ValueError as exc:
        raise HTTPException(
            status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
            detail=str(exc),
        )
    provider_id = _validate_provider_id(provider_id)

    deleted = store.delete_tenant_override(tenant_id, provider_id)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No tenant override found for tenant={tenant_id!r} provider={provider_id!r}",
        )
    logger.info(
        "admin_meeting.delete_tenant_override tenant=%s provider=%s founder=%s",
        tenant_id,
        provider_id,
        _founder,
    )
