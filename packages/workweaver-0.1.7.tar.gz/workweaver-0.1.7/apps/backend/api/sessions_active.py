"""Ambient cross-surface session attach API (#2132).

Returns the canonical "active session" for the authenticated tenant+user
tuple, regardless of which surface (CLI, dashboard, voice, Slack) is asking.
The session id attaches to the Intention Kernel (see D007) so all surfaces
share one continuity stream — the laptop dashboard, ``ww`` cold start, and
Slack DM all see the same active session without an explicit
``ww session resume``.

Endpoints
---------
* ``GET  /api/v1/sessions/active``                — current active session
* ``POST /api/v1/sessions/active/attach``         — record an ambient attach
* ``POST /api/v1/sessions/active/opt-out``        — disable ambient attach for
  a specific surface (e.g. headless CI agents)
* ``GET  /api/v1/sessions/active/opt-out``        — list current opt-outs

User identity is always derived from the authenticated session via
``get_verified_user_id``. Callers cannot pass ``user_id`` in the body or query
string and have a different identity accepted — the auth dep wins.
"""

from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_id,
)
from apps.backend.services.sessions.active_session_store import (
    ActiveSessionStore as SignalStore,
    ActiveSessionStoreBackend,
    InMemoryActiveSessionBackend,
    build_active_session_backend,
)


logger = logging.getLogger(__name__)


router = APIRouter(prefix="/api/v1/sessions/active", tags=["sessions-active"])


# ---------------------------------------------------------------------------
# Wire models
# ---------------------------------------------------------------------------


class ActiveSession(BaseModel):
    session_id: str
    tenant_id: str
    user_id: str
    last_surface: str = ""
    last_touched_at: datetime
    pending_intents: int = 0
    kernel_id: str = ""
    summary: str = ""


class AmbientAttachRequest(BaseModel):
    """Body for POST /attach.

    ``user_id`` is intentionally **not** part of this model — the user
    identity is derived from the authenticated session via
    ``get_verified_user_id``. Callers that want to attach for someone else
    must impersonate via the standard admin path; ambient attach itself is
    self-only.
    """

    surface: str = Field(..., description="cli | dashboard | voice | slack | mobile")
    trigger: str = Field("cold_start", description="Attach trigger reason")
    confirm_writes: bool = Field(
        False, description="True after user confirms write continuation"
    )


class OptOutRequest(BaseModel):
    """Body for POST /opt-out. ``user_id`` is derived from auth."""

    surface: str


class OptOutListResponse(BaseModel):
    user_id: str
    surfaces: list[str]


# ---------------------------------------------------------------------------
# Service-style state — backed by a durable Dynamo store in production
# and an in-memory backend for tests and local-native runs.
# ---------------------------------------------------------------------------


class ActiveSessionStore:
    """Tenant+user keyed active session + opt-out tracker.

    The previous version stored everything in a process-local dict, which lost
    state on every container restart and made multi-instance deployments
    inconsistent. This version delegates persistence to an
    :class:`ActiveSessionStoreBackend` (in-memory for tests, DynamoDB for
    production) so attaches survive restarts and rolling deploys.
    """

    def __init__(self, backend: ActiveSessionStoreBackend | None = None) -> None:
        self._backend: ActiveSessionStoreBackend = (
            backend or InMemoryActiveSessionBackend()
        )

    # ------------------------------------------------------------------
    # Session CRUD
    # ------------------------------------------------------------------

    def get(self, tenant_id: str, user_id: str) -> ActiveSession | None:
        payload = self._backend.load_active(tenant_id, user_id)
        if not payload:
            return None
        return ActiveSession(**payload)

    def upsert(self, session: ActiveSession) -> None:
        self._backend.save_active(
            session.tenant_id,
            session.user_id,
            session.model_dump(),
        )

    def attach(
        self,
        *,
        tenant_id: str,
        user_id: str,
        surface: str,
        confirm_writes: bool,
    ) -> ActiveSession | None:
        existing = self.get(tenant_id, user_id)
        if existing is None:
            return None
        updated = ActiveSession(
            session_id=existing.session_id,
            tenant_id=existing.tenant_id,
            user_id=existing.user_id,
            last_surface=surface,
            last_touched_at=datetime.now(timezone.utc),
            pending_intents=existing.pending_intents,
            kernel_id=existing.kernel_id,
            summary=existing.summary,
        )
        self.upsert(updated)
        logger.info(
            "ambient_attach tenant=%s user=%s surface=%s confirm_writes=%s",
            tenant_id,
            user_id,
            surface,
            confirm_writes,
        )
        return updated

    # ------------------------------------------------------------------
    # Opt-out tracking
    # ------------------------------------------------------------------

    def opt_out(self, tenant_id: str, user_id: str, surface: str) -> list[str]:
        bucket = self._backend.load_opt_outs(tenant_id, user_id)
        bucket.add(surface)
        self._backend.save_opt_outs(tenant_id, user_id, bucket)
        return sorted(bucket)

    def opt_in(self, tenant_id: str, user_id: str, surface: str) -> list[str]:
        bucket = self._backend.load_opt_outs(tenant_id, user_id)
        bucket.discard(surface)
        self._backend.save_opt_outs(tenant_id, user_id, bucket)
        return sorted(bucket)

    def is_opted_out(self, tenant_id: str, user_id: str, surface: str) -> bool:
        return surface in self._backend.load_opt_outs(tenant_id, user_id)

    def list_opt_outs(self, tenant_id: str, user_id: str) -> list[str]:
        return sorted(self._backend.load_opt_outs(tenant_id, user_id))


_store: ActiveSessionStore = ActiveSessionStore(build_active_session_backend())

# Signal store for publish_signal (services-layer, separate from session CRUD store).
_signal_store: SignalStore | None = None

# Per-(tenant_id, user_id) adapter registry — avoids duplicate callback registrations.
_adapter_registry: dict[tuple[str, str], Any] = {}


def get_active_session_store() -> ActiveSessionStore:
    return _store


def _get_signal_store() -> SignalStore:
    global _signal_store
    if _signal_store is None:
        _signal_store = SignalStore()
    return _signal_store


def _get_or_create_adapter(tenant_id: str, user_id: str) -> Any:
    """Return the MessagesAmbientAdapter for (tenant_id, user_id), creating if absent."""
    key = (tenant_id, user_id)
    if key not in _adapter_registry:
        from apps.backend.services.ambient_adapters.messages import MessagesAmbientAdapter

        _adapter_registry[key] = MessagesAmbientAdapter(
            tenant_id=tenant_id,
            user_id=user_id,
            session_store=_get_signal_store(),
        )
    return _adapter_registry[key]


def reset_for_tests(
    backend: ActiveSessionStoreBackend | None = None,
) -> ActiveSessionStore:
    """Replace module-level singletons with fresh instances for test isolation."""

    global _store, _signal_store, _adapter_registry
    _store = ActiveSessionStore(backend or InMemoryActiveSessionBackend())
    _signal_store = None
    _adapter_registry = {}
    from apps.backend.services.ambient_adapters.messages import _INBOUND_REGISTRY
    _INBOUND_REGISTRY.clear()
    return _store


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.get("", response_model=ActiveSession | None)
async def get_active(
    surface: str = Query("cli", description="Calling surface"),
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    store: ActiveSessionStore = Depends(get_active_session_store),
) -> ActiveSession | None:
    if store.is_opted_out(tenant_id, user_id, surface):
        return None
    return store.get(tenant_id, user_id)


@router.post("/attach", response_model=ActiveSession | None)
async def attach_active(
    payload: AmbientAttachRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    store: ActiveSessionStore = Depends(get_active_session_store),
) -> ActiveSession | None:
    if store.is_opted_out(tenant_id, user_id, payload.surface):
        raise HTTPException(status_code=403, detail="surface opted out of ambient attach")
    session = store.attach(
        tenant_id=tenant_id,
        user_id=user_id,
        surface=payload.surface,
        confirm_writes=payload.confirm_writes,
    )
    if session is not None:
        try:
            adapter = _get_or_create_adapter(tenant_id, user_id)
            await adapter.attach(session.session_id)
        except Exception:
            logger.warning(
                "ambient_attach: adapter.attach failed tenant=%s user=%s",
                tenant_id,
                user_id,
                exc_info=True,
            )
    return session


@router.post("/opt-out", response_model=OptOutListResponse)
async def opt_out_surface(
    payload: OptOutRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    store: ActiveSessionStore = Depends(get_active_session_store),
) -> OptOutListResponse:
    surfaces = store.opt_out(tenant_id, user_id, payload.surface)
    return OptOutListResponse(user_id=user_id, surfaces=surfaces)


@router.delete("/opt-out", response_model=OptOutListResponse)
async def opt_in_surface(
    surface: str = Query(...),
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    store: ActiveSessionStore = Depends(get_active_session_store),
) -> OptOutListResponse:
    surfaces = store.opt_in(tenant_id, user_id, surface)
    return OptOutListResponse(user_id=user_id, surfaces=surfaces)


@router.get("/opt-out", response_model=OptOutListResponse)
async def list_opt_outs(
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    store: ActiveSessionStore = Depends(get_active_session_store),
) -> OptOutListResponse:
    return OptOutListResponse(user_id=user_id, surfaces=store.list_opt_outs(tenant_id, user_id))


__all__ = [
    "ActiveSession",
    "ActiveSessionStore",
    "AmbientAttachRequest",
    "OptOutListResponse",
    "OptOutRequest",
    "get_active_session_store",
    "reset_for_tests",
    "router",
    "_get_or_create_adapter",
    "_get_signal_store",
]
