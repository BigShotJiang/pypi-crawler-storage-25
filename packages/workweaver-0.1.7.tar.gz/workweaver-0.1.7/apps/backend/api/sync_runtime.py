"""Edge<->Cloud sync runtime API (#1997, #2130).

Exposes:
* ``POST /api/v1/sync/{entity_type}/{entity_id}`` — apply a revision.
  Returns 200 + merged on clean merge, 409 + conflict_id + diff on field
  conflict, 422 on revision gap.
* ``GET  /api/v1/sync/{entity_type}/{entity_id}`` — fetch current snapshot.
* ``GET  /api/v1/sync/conflicts`` — list unresolved conflicts for the tenant
  (powers the ``/admin/sync-conflicts`` UI).
* ``POST /api/v1/sync/conflicts/{conflict_id}/resolve`` — accept a manual
  resolution payload and clear the conflict.

Wire format keeps ``vector_clock`` flat for transport and accepts
``actor_id`` so the engine can advance the clock on the merged side.
"""

from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Response, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.edge_cloud.sync_engine import (
    EntityRevision,
    SyncEngine,
    SyncOutcome,
)
from apps.backend.services.edge_cloud.sync_state_store import build_sync_state_store


router = APIRouter(prefix="/api/v1/sync", tags=["sync"])


# The engine is resolved lazily so that environment-driven configuration
# (e.g. SYNC_STATE_TABLE in managed_saas) is consulted at startup, not at
# import time. Tests override ``get_sync_engine`` via FastAPI's
# ``dependency_overrides`` so they never construct a DynamoDB client.
_engine: SyncEngine | None = None


def _build_engine() -> SyncEngine:
    return SyncEngine(store=build_sync_state_store())


def get_sync_engine() -> SyncEngine:
    """FastAPI dep injection seam.

    Lazily constructs the durable engine on first request so import-time
    side effects stay zero. Tests override this via
    ``app.dependency_overrides[get_sync_engine] = lambda: ...``.
    """

    global _engine
    if _engine is None:
        _engine = _build_engine()
    return _engine


def reset_engine_for_tests() -> None:
    """Drop the cached engine instance (test-only helper)."""

    global _engine
    _engine = None


# ---------------------------------------------------------------------------
# Wire models
# ---------------------------------------------------------------------------


class SyncRequest(BaseModel):
    """Edge -> cloud or cloud -> edge sync write.

    ``revision`` is the caller's *baseline*: the last revision the caller
    observed for this entity (``0`` if the caller has not seen any). The
    server derives the persisted revision (``baseline + 1`` on a clean
    fast-forward; cloud-revision + 1 after a successful field-merge). The
    server never accepts a "next revision" from the caller — that contract
    was historically ambiguous across the API, CLI, and engine layers.
    """

    revision: int = Field(
        ...,
        ge=0,
        description=(
            "Caller's last seen revision (baseline). "
            "Use 0 when the entity has not been seen before. "
            "The server derives the persisted revision."
        ),
    )
    fields: dict[str, Any] = Field(default_factory=dict)
    vector_clock: dict[str, int] = Field(default_factory=dict)
    actor_id: str = Field("", description="Authoring actor for clock advance")


class FieldConflictWire(BaseModel):
    field_name: str
    base_value: Any | None = None
    cloud_value: Any | None = None
    incoming_value: Any | None = None
    strategy: str
    reason: str


class SyncResponse(BaseModel):
    status: str  # "merged" | "conflict" | "rejected"
    revision: int | None = None
    fields: dict[str, Any] | None = None
    vector_clock: dict[str, int] | None = None
    last_writer: str = ""
    conflicts: list[FieldConflictWire] = Field(default_factory=list)
    # Server-assigned conflict id when ``status=='conflict'``. Use this id
    # when calling /api/v1/sync/conflicts/<id>/resolve.
    conflict_id: str = ""
    cloud_revision: int | None = None
    reason: str = ""


class ConflictWire(BaseModel):
    conflict_id: str
    entity_type: str
    entity_id: str
    cloud_revision: int
    incoming_revision: int
    detected_at: datetime
    conflicts: list[FieldConflictWire]


class ConflictResolveRequest(BaseModel):
    """Manual conflict resolution payload.

    The server derives the persisted revision (cloud + 1); callers do not
    supply it. ``actor_id`` advances the vector clock for the resolving
    writer.
    """

    fields: dict[str, Any]
    vector_clock: dict[str, int] = Field(default_factory=dict)
    actor_id: str = ""


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.get("/{entity_type}/{entity_id}", response_model=SyncResponse)
async def get_snapshot(
    entity_type: str,
    entity_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    engine: SyncEngine = Depends(get_sync_engine),
) -> SyncResponse:
    snap = engine.snapshot(tenant_id, entity_type, entity_id)
    if snap is None:
        return SyncResponse(status="missing")
    return SyncResponse(
        status="merged",
        revision=snap.revision,
        fields=dict(snap.fields),
        vector_clock=dict(snap.vector_clock),
        last_writer=snap.last_writer,
    )


@router.post("/{entity_type}/{entity_id}", response_model=SyncResponse)
async def apply_revision(
    entity_type: str,
    entity_id: str,
    payload: SyncRequest,
    response: Response,
    tenant_id: str = Depends(get_verified_tenant_id),
    engine: SyncEngine = Depends(get_sync_engine),
) -> SyncResponse:
    incoming = EntityRevision(
        tenant_id=tenant_id,
        entity_type=entity_type,
        entity_id=entity_id,
        revision=payload.revision,
        fields=dict(payload.fields),
        vector_clock=dict(payload.vector_clock),
        last_writer=payload.actor_id,
        updated_at=datetime.now(timezone.utc),
    )
    outcome = engine.apply(incoming, actor_id=payload.actor_id)
    if outcome.status == "conflict":
        response.status_code = status.HTTP_409_CONFLICT
    elif outcome.status == "rejected":
        response.status_code = status.HTTP_422_UNPROCESSABLE_CONTENT
    return _to_response(outcome)


@router.get("/conflicts", response_model=list[ConflictWire])
async def list_conflicts(
    tenant_id: str = Depends(get_verified_tenant_id),
    engine: SyncEngine = Depends(get_sync_engine),
) -> list[ConflictWire]:
    return [
        ConflictWire(
            conflict_id=c.conflict_id,
            entity_type=c.entity_type,
            entity_id=c.entity_id,
            cloud_revision=c.cloud_revision,
            incoming_revision=c.incoming_revision,
            detected_at=c.detected_at,
            conflicts=[
                FieldConflictWire(
                    field_name=fc.field_name,
                    base_value=fc.base_value,
                    cloud_value=fc.cloud_value,
                    incoming_value=fc.incoming_value,
                    strategy=fc.strategy.value,
                    reason=fc.reason,
                )
                for fc in c.conflicts
            ],
        )
        for c in engine.conflicts(tenant_id)
    ]


@router.post("/conflicts/{conflict_id}/resolve", response_model=SyncResponse)
async def resolve_conflict(
    conflict_id: str,
    payload: ConflictResolveRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    engine: SyncEngine = Depends(get_sync_engine),
) -> SyncResponse:
    pending = [c for c in engine.conflicts(tenant_id) if c.conflict_id == conflict_id]
    if not pending:
        raise HTTPException(status_code=404, detail="conflict not found")
    target = pending[0]
    # Engine derives the persisted revision internally (cloud + 1) so the
    # resolve contract matches the apply contract: callers never set the
    # next revision explicitly.
    resolution = EntityRevision(
        tenant_id=tenant_id,
        entity_type=target.entity_type,
        entity_id=target.entity_id,
        revision=0,
        fields=dict(payload.fields),
        vector_clock=dict(payload.vector_clock),
        last_writer=payload.actor_id,
        updated_at=datetime.now(timezone.utc),
    )
    persisted = engine.resolve_conflict(tenant_id, conflict_id, resolution)
    return SyncResponse(
        status="merged",
        revision=persisted.revision,
        fields=dict(persisted.fields),
        vector_clock=dict(persisted.vector_clock),
        last_writer=persisted.last_writer,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _to_response(outcome: SyncOutcome) -> SyncResponse:
    if outcome.status == "merged" and outcome.merged is not None:
        return SyncResponse(
            status="merged",
            revision=outcome.merged.revision,
            fields=dict(outcome.merged.fields),
            vector_clock=dict(outcome.merged.vector_clock),
            last_writer=outcome.merged.last_writer,
        )
    if outcome.status == "conflict":
        return SyncResponse(
            status="conflict",
            cloud_revision=outcome.cloud_revision.revision if outcome.cloud_revision else None,
            conflicts=[
                FieldConflictWire(
                    field_name=fc.field_name,
                    base_value=fc.base_value,
                    cloud_value=fc.cloud_value,
                    incoming_value=fc.incoming_value,
                    strategy=fc.strategy.value,
                    reason=fc.reason,
                )
                for fc in outcome.conflicts
            ],
            conflict_id=outcome.conflict_id,
            reason=outcome.reason,
        )
    return SyncResponse(
        status="rejected",
        cloud_revision=outcome.cloud_revision.revision if outcome.cloud_revision else None,
        reason=outcome.reason,
    )
