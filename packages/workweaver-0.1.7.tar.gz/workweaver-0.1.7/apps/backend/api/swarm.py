"""Tenant-scoped swarm execution status API."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, ConfigDict, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.loss_function import ExecutionState, LossFunction, LossResultRepository, get_loss_repository
from apps.backend.services.swarm_scheduler import (
    SwarmExecution,
    SwarmScheduler,
    get_swarm_scheduler,
)
from apps.backend.services.swarm_resource_planner import (
    SwarmCapacityDecision,
    get_swarm_resource_planner,
)
from apps.backend.utils.tenant import strip_tenant_prefix

router = APIRouter(prefix="/api/v1/swarm", tags=["swarm"])

_STATUS_TO_STATE = {
    "admitted": "pending",
    "pending": "pending",
    "running": "running",
    "completed": "completed",
    "failed": "failed",
    "cancelled": "cancelled",
}

_STATE_TO_STATUS = {
    "pending": "admitted",
    "running": "running",
    "completed": "completed",
    "failed": "failed",
    "cancelled": "cancelled",
}


class SwarmStepStatus(BaseModel):
    step_id: str
    status: str
    started_at: str | None = None
    completed_at: str | None = None
    evidence_ids: list[str] = Field(default_factory=list)


class SwarmExecutionStatus(BaseModel):
    execution_id: str
    tenant_id: str
    plan_id: str | None = None
    status: str
    current_step: int = 0
    total_steps: int = 0
    steps: list[SwarmStepStatus] = Field(default_factory=list)
    loss_score_actual: float | None = None
    loss_score_expected: float | None = None
    created_at: str | None = None
    updated_at: str | None = None
    goal: str | None = None
    calendar_group: str | None = None
    cancel_reason: str | None = None


class SwarmExecutionListResponse(BaseModel):
    executions: list[SwarmExecutionStatus]
    count: int
    limit: int
    status: str | None = None


class SwarmLossResponse(BaseModel):
    tenant_id: str
    execution_id: str
    revision: int
    scalar: float
    components: dict[str, float]
    weights: dict[str, float]
    key: str
    computed_at: str
    skill_id: str | None = None


class CancelSwarmExecutionRequest(BaseModel):
    reason: str | None = Field(default=None, max_length=500)


class CancelSwarmExecutionResponse(BaseModel):
    execution_id: str
    status: str
    cancelled: bool
    reason: str | None = None


class SwarmResourcePlanRequest(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    requested_agents: int = Field(default=1, ge=1, alias="agents")
    budget_usd: float | None = Field(default=None, ge=0)
    is_foreground: bool = False
    local_capacity: dict[str, Any] | None = None


def _scheduler() -> SwarmScheduler:
    return get_swarm_scheduler()


def _loss_results() -> LossResultRepository:
    return get_loss_repository()


@router.post("/resource-plan", response_model=SwarmCapacityDecision)
async def plan_swarm_resources(
    request: SwarmResourcePlanRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SwarmCapacityDecision:
    """Return the effective swarm shape before dispatch."""

    tenant = strip_tenant_prefix(tenant_id)
    local_capacity = None
    if request.local_capacity:
        from apps.backend.services.swarm_resource_planner import LocalCapacitySnapshot

        local_capacity = LocalCapacitySnapshot.model_validate(request.local_capacity)
    return get_swarm_resource_planner().plan(
        tenant_id=tenant,
        requested_agents=request.requested_agents,
        is_foreground=request.is_foreground,
        budget_usd=request.budget_usd,
        local_capacity=local_capacity,
    )


def _state_for_status(raw_status: str | None) -> str | None:
    if raw_status is None or not raw_status.strip():
        return None
    normalized = raw_status.strip().lower()
    if normalized == "queued":
        return "queued"
    if normalized == "active":
        return "active"
    if normalized not in _STATUS_TO_STATE:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported swarm status filter: {raw_status}",
        )
    return _STATUS_TO_STATE[normalized]


def _public_status(state: str) -> str:
    return _STATE_TO_STATUS.get(state, state)


def _step_status(step: Any) -> SwarmStepStatus:
    if not isinstance(step, dict):
        return SwarmStepStatus(step_id=str(step), status="unknown")
    evidence_ids = step.get("evidence_ids") or []
    if not isinstance(evidence_ids, list):
        evidence_ids = [str(evidence_ids)]
    return SwarmStepStatus(
        step_id=str(step.get("step_id") or ""),
        status=str(step.get("status") or "queued"),
        started_at=step.get("started_at"),
        completed_at=step.get("completed_at"),
        evidence_ids=[str(item) for item in evidence_ids if str(item or "").strip()],
    )


def _execution_status(execution: SwarmExecution) -> SwarmExecutionStatus:
    public_status = _public_status(execution.state)
    current_step = execution.current_step
    if execution.state == "completed" and execution.total_steps:
        current_step = execution.total_steps
    return SwarmExecutionStatus(
        execution_id=execution.execution_id,
        tenant_id=strip_tenant_prefix(execution.tenant_id),
        plan_id=execution.plan_id,
        status=public_status,
        current_step=current_step,
        total_steps=execution.total_steps,
        steps=[_step_status(step) for step in execution.steps],
        loss_score_actual=execution.loss_score_actual,
        loss_score_expected=execution.loss_score_expected,
        created_at=execution.created_at or execution.started_at,
        updated_at=execution.updated_at or execution.completed_at or execution.started_at,
        goal=execution.goal,
        calendar_group=execution.calendar_group,
        cancel_reason=execution.cancel_reason,
    )


@router.get("/executions/{execution_id}", response_model=SwarmExecutionStatus)
async def get_swarm_execution(
    execution_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SwarmExecutionStatus:
    """Return one swarm execution for the authenticated tenant."""
    tenant = strip_tenant_prefix(tenant_id)
    execution = _scheduler().get_fresh(tenant, execution_id)
    if execution is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Swarm execution not found")
    return _execution_status(execution)


@router.get("/executions", response_model=SwarmExecutionListResponse)
async def list_swarm_executions(
    tenant_id_query: str | None = Query(default=None, alias="tenant_id"),
    status_filter: str | None = Query(default=None, alias="status"),
    limit: int = Query(default=50, ge=1, le=200),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SwarmExecutionListResponse:
    """List swarm executions for the authenticated tenant."""
    tenant = strip_tenant_prefix(tenant_id)
    if tenant_id_query and strip_tenant_prefix(tenant_id_query) != tenant:
        return SwarmExecutionListResponse(executions=[], count=0, limit=limit, status=status_filter)

    state = _state_for_status(status_filter)
    if state == "queued":
        return SwarmExecutionListResponse(executions=[], count=0, limit=limit, status=status_filter)
    if state == "active":
        executions = [
            execution
            for execution in _scheduler().list_executions(tenant, limit=500)
            if execution.state in {"pending", "running"}
        ][:limit]
    else:
        executions = _scheduler().list_executions(tenant, state=state, limit=limit)
    statuses = [_execution_status(execution) for execution in executions]
    return SwarmExecutionListResponse(
        executions=statuses,
        count=len(statuses),
        limit=limit,
        status=status_filter,
    )


@router.get("/executions/{execution_id}/loss", response_model=SwarmLossResponse)
async def get_swarm_execution_loss(
    execution_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    repository: LossResultRepository = Depends(_loss_results),
) -> SwarmLossResponse:
    """Return the latest persisted runtime loss for one swarm execution."""
    tenant = strip_tenant_prefix(tenant_id)
    execution = _scheduler().get_fresh(tenant, execution_id)
    if execution is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Swarm execution not found")

    result = repository.latest(tenant, execution_id)
    if result is None:
        state = ExecutionState.from_execution(execution, tenant_id=tenant)
        result = repository.persist(LossFunction.for_tenant(tenant).compute(state), execution_state=state)
        _scheduler().record_loss(tenant, execution_id, result.scalar)
    response_payload = result.to_dict()
    response_payload.setdefault("skill_id", None)
    return SwarmLossResponse(**response_payload)


@router.post("/executions/{execution_id}/cancel", response_model=CancelSwarmExecutionResponse)
async def cancel_swarm_execution(
    execution_id: str,
    request: CancelSwarmExecutionRequest | None = None,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CancelSwarmExecutionResponse:
    """Cancel a pending or running swarm execution."""
    tenant = strip_tenant_prefix(tenant_id)
    scheduler = _scheduler()
    execution = scheduler.get_fresh(tenant, execution_id)
    if execution is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Swarm execution not found")
    if execution.state == "cancelled":
        return CancelSwarmExecutionResponse(
            execution_id=execution_id,
            status="cancelled",
            cancelled=False,
            reason=request.reason if request else None,
        )
    if execution.state not in {"pending", "running"}:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Cannot cancel swarm execution in {execution.state} state",
        )
    reason = request.reason if request else None
    from apps.backend.observability.action_metrics import CANCEL_VISIBLE_MS, observed_async_action

    async with observed_async_action(
        action="cancel.visible",
        surface="runtime",
        budget_id="swarm.cancel_latency",
        metric_name=CANCEL_VISIBLE_MS,
        tenant_id=tenant,
    ):
        cancelled = scheduler.cancel(tenant, execution_id, reason=reason)
    if not cancelled:
        refreshed = scheduler.get_fresh(tenant, execution_id)
        if refreshed is not None and refreshed.state == "cancelled":
            return CancelSwarmExecutionResponse(
                execution_id=execution_id,
                status="cancelled",
                cancelled=False,
                reason=request.reason if request else None,
            )
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Swarm execution changed state")
    return CancelSwarmExecutionResponse(
        execution_id=execution_id,
        status="cancelled",
        cancelled=True,
        reason=reason,
    )
