"""Shared voice context preload helpers for Twilio answer paths.

Re-exports from ``services.channels.twilio.voice_preload`` for backward
compatibility.  New callers should import from the service module directly.
"""

# Re-exported from services for backward compatibility (issue #3785).
from apps.backend.services.channels.twilio.voice_preload import (  # noqa: F401
    build_voice_preload_metadata,
    resolve_voice_preload_timeout_seconds,
)
