"""Compatibility layer for Mission Control API routers and patch targets."""

from __future__ import annotations

from fastapi import APIRouter

from apps.backend.api import (
    mission_collaboration_api,
    mission_collaboration_models,
    mission_org_api,
    mission_runtime_api,
)

router = APIRouter(prefix="/api/v1/mission", tags=["mission"])
missions_router = APIRouter(prefix="/api/v1/missions", tags=["missions"])

router.include_router(mission_org_api.router)
router.include_router(mission_collaboration_api.router)
router.include_router(mission_runtime_api.router)
missions_router.include_router(mission_runtime_api.missions_router)


def _get_store():
    from apps.backend.services.mission_node_store import get_mission_node_store

    return get_mission_node_store()


def _get_collaboration():
    from apps.backend.services.agent_collaboration import get_agent_collaboration

    return get_agent_collaboration()


def _get_evidence_ledger():
    from apps.backend.services.evidence_ledger import get_evidence_ledger_service

    return get_evidence_ledger_service()


def _get_platform_bridge():
    from apps.backend.services.platform_bridge import get_platform_bridge

    return get_platform_bridge()


def _get_platform_mapping_store():
    from apps.backend.services.platform_bridge import get_platform_channel_mapping_store

    return get_platform_channel_mapping_store()


def _get_ambient_monitor():
    from apps.backend.services.ambient_monitor import get_ambient_monitor_service

    return get_ambient_monitor_service()


def _get_event_bus():
    from apps.backend.services.event_bus import get_event_bus

    return get_event_bus()


def _get_approval_gates():
    from apps.backend.services.approval_gates import get_approval_gates

    return get_approval_gates()


def _get_contracts_service():
    from apps.backend.services.mission_contracts import get_mission_contracts_service

    return get_mission_contracts_service()


def _get_run_state_service():
    from apps.backend.services.mission_run.state import get_mission_run_state_service

    return get_mission_run_state_service()


for _module in (mission_org_api, mission_collaboration_models, mission_collaboration_api, mission_runtime_api):
    for _name in getattr(_module, "__all__", ()):
        globals()[_name] = getattr(_module, _name)


__all__ = [
    "router",
    "missions_router",
    "_get_store",
    "_get_collaboration",
    "_get_evidence_ledger",
    "_get_platform_bridge",
    "_get_platform_mapping_store",
    "_get_ambient_monitor",
    "_get_event_bus",
    "_get_approval_gates",
    "_get_contracts_service",
    "_get_run_state_service",
]
for _module in (mission_org_api, mission_collaboration_models, mission_collaboration_api, mission_runtime_api):
    __all__.extend(getattr(_module, "__all__", ()))
