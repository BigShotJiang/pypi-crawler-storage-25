"""Provider management REST endpoints (Issue #3589).

Endpoints:
  GET  /api/v1/providers              -- list all providers (built-in + plugins + tenant overrides)
  POST /api/v1/providers              -- install plugin (upload manifest or managed ZIP)
  GET  /api/v1/providers/{name}       -- provider details
  POST /api/v1/providers/{name}/smoke -- smoke test provider connectivity

All endpoints require admin auth.
"""

from __future__ import annotations

import logging
import shutil
from http import HTTPStatus
from typing import Any

from fastapi import APIRouter, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.services.inference.provider_profiles.plugin_manifest import (
    PluginManifestError,
    parse_manifest,
)
from apps.backend.services.inference.provider_profiles.plugin_registry import (
    ProviderProfileRegistry,
    SmokeTestError,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/providers", tags=["provider-management"])


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class InstallPluginRequest(BaseModel):
    """Request body for installing a plugin from a manifest URL or inline YAML."""

    name: str = Field(..., max_length=64, description="Plugin name (slug)")
    manifest_yaml: str = Field(
        ...,
        description="Raw YAML content of the plugin manifest",
    )


class TenantOverrideRequest(BaseModel):
    """Request body for setting a tenant overlay."""

    tenant_id: str = Field(..., description="Tenant ID")
    provider_id: str = Field(..., description="Provider ID to override")
    default_model: str = Field(..., description="Override default model")


class EnableDisableRequest(BaseModel):
    """Request body for enable/disable."""

    enabled: bool = Field(True, description="Enable or disable the plugin")


# ---------------------------------------------------------------------------
# Singleton registry
# ---------------------------------------------------------------------------

_registry: ProviderProfileRegistry | None = None


def get_provider_registry() -> ProviderProfileRegistry:
    """Return the process-level ProviderProfileRegistry singleton."""
    global _registry  # noqa: PLW0603
    if _registry is None:
        _registry = ProviderProfileRegistry()
    return _registry


def reset_provider_registry() -> None:
    """Reset the singleton (for testing)."""
    global _registry  # noqa: PLW0603
    _registry = None


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("")
def list_providers() -> dict[str, Any]:
    """List all providers (built-in + plugins + tenant overrides)."""
    registry = get_provider_registry()
    providers = registry.list_providers_api_payload()
    return {"providers": providers, "total": len(providers)}


@router.post("", status_code=status.HTTP_201_CREATED)
def install_plugin(request: InstallPluginRequest) -> dict[str, Any]:
    """Install a new plugin from inline YAML manifest.

    The manifest is validated and written to the plugin directory.
    Managed (signed) plugins should be installed via the admin UI upload flow.
    """
    registry = get_provider_registry()

    # Write manifest to plugin directory
    plugin_dir = registry._plugin_dir / request.name
    plugin_dir.mkdir(parents=True, exist_ok=True)
    manifest_path = plugin_dir / "manifest.yaml"
    manifest_path.write_text(request.manifest_yaml, encoding="utf-8")

    # Validate by parsing
    try:
        manifest = parse_manifest(manifest_path)
    except PluginManifestError as exc:
        # Clean up on validation failure
        shutil.rmtree(plugin_dir, ignore_errors=True)
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST,
            detail=f"Invalid manifest: {exc}",
        ) from exc

    # Re-discover to pick up the new plugin
    registry.discover_plugins()

    return {
        "status": "installed",
        "name": manifest.name,
        "provider_id": manifest.provider_id,
        "default_model": manifest.default_model,
    }


@router.get("/{name}")
def get_provider(name: str) -> dict[str, Any]:
    """Get details for a specific provider."""
    registry = get_provider_registry()

    try:
        profile = registry.get(name)
    except KeyError:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND,
            detail=f"Provider {name!r} not found",
        )

    # Determine source
    builtin_ids = {p.profile_id for p in registry._builtins}
    source = "builtin" if profile.profile_id in builtin_ids else "plugin"

    return {
        "profile_id": profile.profile_id,
        "provider_id": profile.provider_id,
        "default_model": profile.default_model,
        "provenance": profile.provenance,
        "jurisdiction": profile.jurisdiction,
        "requires_tool_use_probe": profile.requires_tool_use_probe,
        "supported_purposes": [p.value for p in profile.supported_purposes],
        "source": source,
        "decision_trace": profile.decision_trace_context(
            model_spec=f"{profile.provider_id}/{profile.default_model}"
        ),
    }


@router.post("/{name}/smoke")
def smoke_test_provider(name: str) -> dict[str, Any]:
    """Smoke test provider connectivity."""
    registry = get_provider_registry()

    try:
        result = registry.smoke_test(name)
    except SmokeTestError as exc:
        raise HTTPException(
            status_code=HTTPStatus.BAD_REQUEST,
            detail=str(exc),
        ) from exc

    return result


@router.post("/{name}/enable")
def enable_plugin(name: str) -> dict[str, Any]:
    """Enable a previously disabled plugin."""
    registry = get_provider_registry()
    registry.enable_plugin(name)
    return {"status": "enabled", "name": name}


@router.post("/{name}/disable")
def disable_plugin(name: str) -> dict[str, Any]:
    """Disable a plugin."""
    registry = get_provider_registry()
    registry.disable_plugin(name)
    return {"status": "disabled", "name": name}


@router.post("/{name}/tenant-override")
def set_tenant_override(request: TenantOverrideRequest, name: str) -> dict[str, Any]:
    """Set a tenant-specific override for a provider's default model."""
    registry = get_provider_registry()

    try:
        registry.get(name)
    except KeyError:
        raise HTTPException(
            status_code=HTTPStatus.NOT_FOUND,
            detail=f"Provider {name!r} not found",
        )

    registry.set_tenant_override(
        tenant_id=request.tenant_id,
        provider_id=request.provider_id,
        default_model=request.default_model,
    )

    return {
        "status": "override_set",
        "tenant_id": request.tenant_id,
        "provider_id": request.provider_id,
        "default_model": request.default_model,
    }


__all__ = [
    "get_provider_registry",
    "reset_provider_registry",
    "router",
]
