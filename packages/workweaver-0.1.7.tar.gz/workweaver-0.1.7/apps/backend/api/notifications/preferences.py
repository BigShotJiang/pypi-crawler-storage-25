"""
Notification Preferences API

API endpoints for managing user notification preferences.

Source: docs/PRODUCT.md#P1.7G.1 (lines 14749-14876)
Status: Sprint 7.0I - Implementation
"""

from apps.backend.config.region import AWS_REGION
from fastapi import APIRouter, Depends, HTTPException

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, get_verified_user_id
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from pydantic import BaseModel, Field
from typing import Any
import logging
from datetime import UTC, datetime
import uuid

from apps.backend.services.notification_service import (
    NotificationChannel,
    NotificationType,
    NotificationPriority,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/notifications", tags=["notifications"])


# Request/Response Models


class ChannelPreference(BaseModel):
    """Per-channel notification preference."""

    channel: NotificationChannel
    enabled: bool


class NotificationTypePreference(BaseModel):
    """Per-notification-type preference."""

    notification_type: NotificationType
    enabled: bool
    channels: list[NotificationChannel]


class NotificationPreferences(BaseModel):
    """User notification preferences."""

    tenant_id: str
    user_id: str

    # Channel-level preferences
    email_enabled: bool = True
    sms_enabled: bool = True
    whatsapp_enabled: bool = True
    in_app_enabled: bool = True

    # Notification-type preferences
    call_missed_enabled: bool = True
    call_completed_enabled: bool = False
    call_transcript_ready_enabled: bool = True

    new_lead_enabled: bool = True
    lead_qualified_enabled: bool = True
    lead_followup_reminder_enabled: bool = True

    skill_deployed_enabled: bool = True
    skill_failed_enabled: bool = True
    system_update_enabled: bool = True
    billing_alert_enabled: bool = True

    onboarding_reminder_enabled: bool = True
    trial_expiring_enabled: bool = True

    # Quiet hours (disable non-urgent notifications)
    quiet_hours_enabled: bool = False
    quiet_hours_start: str = "22:00"  # 10 PM
    quiet_hours_end: str = "08:00"  # 8 AM
    quiet_hours_timezone: str = "UTC"


class UpdatePreferenceRequest(BaseModel):
    """Request to update a single preference."""

    preference_key: str = Field(..., description="Key of preference to update")
    value: Any = Field(..., description="New value")


class NotificationListResponse(BaseModel):
    """Response for notification list."""

    notifications: list[dict[str, Any]]
    total: int
    unread_count: int


class MarkReadRequest(BaseModel):
    """Request to mark notification(s) as read."""

    notification_ids: list[str] | None = Field(
        None,
        description="Specific notification IDs to mark as read. If null, marks all as read.",
    )


class UnreadCountResponse(BaseModel):
    """Unread notification count."""

    unread_count: int


class AlertRule(BaseModel):
    """Payload for an alert rule."""

    id: str | None = None
    name: str = Field(..., min_length=1, max_length=100)
    notification_types: list[str] = Field(default_factory=list)
    priority: str = NotificationPriority.NORMAL.value
    channels: list[str] = Field(default_factory=list)
    enabled: bool = True
    conditions: dict[str, Any] = Field(default_factory=dict)
    cooldown_minutes: int = Field(default=0, ge=0, le=43200)


class AlertRulesRequest(BaseModel):
    """Alert rules list payload."""

    rules: list[AlertRule]


class AlertRulesResponse(BaseModel):
    """Response payload for alert-rule API."""

    rules: list[dict[str, Any]]


class NotificationAnalyticsTrendPoint(BaseModel):
    """Time bucket for trend graph."""

    bucket: str
    count: int


class NotificationAnalyticsMetric(BaseModel):
    """Type/priority/channel metric buckets."""

    type: str | None = None
    priority: str | None = None
    channel: str | None = None
    count: int


class NotificationAnalyticsResponse(BaseModel):
    """Analytics payload for notification history."""

    total_alerts: int
    unread_alerts: int
    window_days: int
    by_type: list[NotificationAnalyticsMetric]
    by_priority: list[NotificationAnalyticsMetric]
    by_channel: list[NotificationAnalyticsMetric]
    trend: list[NotificationAnalyticsTrendPoint]


# API Endpoints


@router.get("/preferences", response_model=NotificationPreferences)
async def get_preferences(
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> NotificationPreferences:
    """
    Get notification preferences for user.

    Returns all notification preferences including channel settings,
    notification type settings, and quiet hours configuration.
    """
    try:
        # Import here to avoid circular dependency
        from apps.backend.services.notification_service import get_notification_service

        service = get_notification_service()
        preferences = service._get_user_preferences(tenant_id, user_id)

        if not preferences or not preferences.get("tenant_id"):
            # Return default preferences (handles None, {}, and incomplete records)
            return NotificationPreferences(
                tenant_id=tenant_id,
                user_id=user_id,
            )

        return NotificationPreferences(**preferences)
    except Exception as e:
        logger.error(f"Failed to get preferences: {e}")
        raise HTTPException(status_code=500, detail="Failed to get preferences")


@router.put("/preferences", response_model=NotificationPreferences)
async def update_preferences(
    preferences: NotificationPreferences,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> NotificationPreferences:
    """
    Update notification preferences for user.

    Updates all notification preferences. Only include fields you want to change.
    """
    try:
        # Import here to avoid circular dependency
        import boto3
        from botocore.exceptions import ClientError

        dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION)
        preferences_table = dynamodb.Table("workweaver-notification-preferences")

        # Build update item
        item = preferences.model_dump()
        item["tenant_id"] = tenant_id
        item["user_id"] = user_id
        item["updated_at"] = datetime.now(UTC).replace(tzinfo=None).isoformat()

        # Store in DynamoDB
        preferences_table.put_item(Item=item)

        logger.info(f"Updated preferences for user {user_id} in tenant {tenant_id}")

        return NotificationPreferences(**item)
    except ClientError as e:
        logger.error(f"Failed to update preferences: {e}")
        raise HTTPException(status_code=500, detail="Failed to update preferences")
    except Exception as e:
        logger.error(f"Unexpected error updating preferences: {e}")
        raise HTTPException(status_code=500, detail="Failed to update preferences")


@router.patch("/preferences")
async def patch_preference(
    request: UpdatePreferenceRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> dict[str, Any]:
    """
    Update a single notification preference.

    Use this endpoint to update individual preferences without sending the full object.
    """
    try:
        import boto3
        from botocore.exceptions import ClientError

        dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION)
        preferences_table = dynamodb.Table("workweaver-notification-preferences")

        # Build update expression
        update_expression = (
            f"SET {request.preference_key} = :value, updated_at = :updated_at"
        )
        expression_values = {
            ":value": request.value,
            ":updated_at": datetime.now(UTC).replace(tzinfo=None).isoformat(),
        }

        # Update in DynamoDB
        preferences_table.update_item(
            Key={
                "tenant_id": tenant_id,
                "user_id": user_id,
            },
            UpdateExpression=update_expression,
            ExpressionAttributeValues=expression_values,
        )

        logger.info(
            f"Updated preference {request.preference_key} for user {user_id} to {request.value}"
        )

        return {
            "success": True,
            "preference_key": request.preference_key,
            "value": request.value,
        }
    except ClientError as e:
        logger.error(f"Failed to patch preference: {e}")
        raise HTTPException(status_code=500, detail="Failed to update preference")
    except Exception as e:
        logger.error(f"Unexpected error patching preference: {e}")
        raise HTTPException(status_code=500, detail="Failed to update preference")


@router.get("/notifications", response_model=NotificationListResponse)
async def list_notifications(
    unread_only: bool = False,
    limit: int = 50,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> NotificationListResponse:
    """
    List in-app notifications for user.

    Returns paginated list of notifications with optional filtering.
    """
    try:
        from apps.backend.services.notification_service import get_notification_service

        service = get_notification_service()
        notifications = service.get_user_notifications(
            tenant_id,
            user_id,
            unread_only=unread_only,
            limit=limit,
        )

        return NotificationListResponse(
            notifications=notifications,
            total=len(notifications),
            unread_count=service.get_unread_count(tenant_id, user_id),
        )
    except Exception as e:
        logger.error(f"Failed to list notifications: {e}")
        raise HTTPException(status_code=500, detail="Failed to list notifications")


@router.get("/unread-count", response_model=UnreadCountResponse)
async def get_unread_count(
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> UnreadCountResponse:
    """
    Get unread notification count.

    Intended for header badge updates and overview indicators.
    """
    try:
        from apps.backend.services.notification_service import get_notification_service

        service = get_notification_service()
        return UnreadCountResponse(
            unread_count=service.get_unread_count(tenant_id, user_id)
        )
    except Exception as e:
        logger.error(f"Failed to read unread count: {e}")
        raise HTTPException(status_code=500, detail="Failed to get unread count")


@router.get("/alerts/analytics", response_model=NotificationAnalyticsResponse)
async def get_alerts_analytics(
    window_days: int = 30,
    history_limit: int = 500,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> NotificationAnalyticsResponse:
    """
    Get alert analytics summary and trend for dashboard cards and charts.
    """
    try:
        from apps.backend.services.notification_service import get_notification_service

        service = get_notification_service()
        payload = service.get_notification_analytics(
            tenant_id,
            user_id,
            window_days=max(1, min(365, window_days)),
            history_limit=max(1, min(200, history_limit)),
        )
        return NotificationAnalyticsResponse(**payload)
    except Exception as e:
        logger.error(f"Failed to load alert analytics: {e}")
        raise HTTPException(status_code=500, detail="Failed to load alert analytics")


@router.get("/alerts/rules", response_model=AlertRulesResponse)
async def list_alert_rules(
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> AlertRulesResponse:
    """
    Get configured alert rules for this user.
    """
    try:
        from apps.backend.services.notification_service import get_notification_service

        service = get_notification_service()
        rules = service.get_alert_rules(tenant_id, user_id)
        paged_rules, _total = paginate_items(rules, pagination)
        return AlertRulesResponse(rules=paged_rules)
    except Exception as e:
        logger.error(f"Failed to load alert rules: {e}")
        raise HTTPException(status_code=500, detail="Failed to load alert rules")


@router.put("/alerts/rules", response_model=AlertRulesResponse)
async def put_alert_rules(
    payload: AlertRulesRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> AlertRulesResponse:
    """
    Replace all alert rules for the user.
    """
    try:
        from apps.backend.services.notification_service import get_notification_service

        service = get_notification_service()
        saved = service.save_alert_rules(
            tenant_id, user_id, [rule.model_dump() for rule in payload.rules]
        )
        return AlertRulesResponse(rules=saved)
    except Exception as e:
        logger.error(f"Failed to save alert rules: {e}")
        raise HTTPException(status_code=500, detail="Failed to save alert rules")


@router.post("/alerts/rules", response_model=AlertRulesResponse)
async def create_alert_rule(
    rule: AlertRule,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> AlertRulesResponse:
    """
    Create a new alert rule.
    """
    try:
        from apps.backend.services.notification_service import get_notification_service

        service = get_notification_service()
        existing_rules = service.get_alert_rules(tenant_id, user_id)
        payload = rule.model_dump()
        payload["id"] = payload.get("id") or f"rule-{uuid.uuid4().hex}"
        saved = service.save_alert_rules(tenant_id, user_id, existing_rules + [payload])
        return AlertRulesResponse(rules=saved)
    except Exception as e:
        logger.error(f"Failed to create alert rule: {e}")
        raise HTTPException(status_code=500, detail="Failed to create alert rule")


@router.delete("/alerts/rules/{rule_id}", response_model=AlertRulesResponse)
async def delete_alert_rule(
    rule_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> AlertRulesResponse:
    """
    Delete a single alert rule.
    """
    try:
        from apps.backend.services.notification_service import get_notification_service

        service = get_notification_service()
        removed = service.delete_alert_rule(tenant_id, user_id, rule_id)
        if not removed:
            raise HTTPException(status_code=404, detail="Alert rule not found")
        return AlertRulesResponse(rules=service.get_alert_rules(tenant_id, user_id))
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to delete alert rule: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete alert rule")


@router.post("/notifications/mark-read")
async def mark_notifications_read(
    request: MarkReadRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> dict[str, Any]:
    """
    Mark notification(s) as read.

    If notification_ids is provided, marks only those as read.
    If notification_ids is null/empty, marks all notifications as read.
    """
    try:
        from apps.backend.services.notification_service import get_notification_service

        service = get_notification_service()

        if request.notification_ids:
            # Mark specific notifications as read
            count = 0
            for notification_id in request.notification_ids:
                if service.mark_notification_read(tenant_id, notification_id):
                    count += 1
        else:
            # Mark all as read
            count = service.mark_all_read(tenant_id, user_id)

        return {
            "success": True,
            "marked_read_count": count,
        }
    except Exception as e:
        logger.error(f"Failed to mark notifications as read: {e}")
        raise HTTPException(
            status_code=500, detail="Failed to mark notifications as read"
        )


@router.delete("/notifications/{notification_id}")
async def delete_notification(
    notification_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """
    Delete a notification.

    Permanently removes the notification from the user's inbox.
    """
    try:
        import boto3
        from botocore.exceptions import ClientError

        dynamodb = boto3.resource("dynamodb", region_name=AWS_REGION)
        notifications_table = dynamodb.Table("workweaver-notifications")

        # Delete notification
        notifications_table.delete_item(
            Key={
                "tenant_id": tenant_id,
                "notification_id": notification_id,
            }
        )

        logger.info(f"Deleted notification {notification_id}")

        return {
            "success": True,
            "notification_id": notification_id,
        }
    except ClientError as e:
        logger.error(f"Failed to delete notification: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete notification")
    except Exception as e:
        logger.error(f"Unexpected error deleting notification: {e}")
        raise HTTPException(status_code=500, detail="Failed to delete notification")


# Convenience function to register router
def get_router() -> APIRouter:
    """Get the notification preferences router."""
    return router
