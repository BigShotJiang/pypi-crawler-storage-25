"""
Notifications API module

Contains endpoints for managing notifications and user preferences.
"""

from apps.backend.api.notifications.preferences import router

__all__ = ["router"]
