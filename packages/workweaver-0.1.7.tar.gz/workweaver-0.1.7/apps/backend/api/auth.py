"""Authentication API router aggregation.

This module was split into focused domain modules (Phase 5 tech debt reduction):
- auth_models.py: Pydantic models, enums, response classes
- auth_helpers.py: Shared utilities, config, AWS client singletons
- auth_signup.py: Google OAuth + email signup endpoints
- auth_login.py: Login, tenant/user query, provisioning status endpoints
- auth_management.py: Invitations, password reset, behavioral stops

All symbols that tests or external code previously imported from this module
are re-exported below for backward compatibility.
"""

import asyncio  # noqa: F401 - used by tests via monkeypatch (auth.asyncio)

from fastapi import APIRouter

from apps.backend.api.auth_signup import router as signup_router
from apps.backend.api.auth_login import router as login_router
from apps.backend.api.auth_management import router as management_router

# Aggregated router: sub-routers have NO prefix; this is the single prefix.
router = APIRouter(
    prefix="/api/v1/auth",
    tags=["authentication"],
)
router.include_router(signup_router)
router.include_router(login_router)
router.include_router(management_router)

# ---------------------------------------------------------------------------
# Backward-compatible re-exports
#
# Tests (test_runtime_auth_redirects.py, test_auth_flow.py) import symbols
# from `apps.backend.api.auth` via module attribute access or mock.patch.
# Re-export everything they need so those tests continue to work unchanged.
# ---------------------------------------------------------------------------

# Models & enums
from apps.backend.api.auth_models import (  # noqa: F401, E402
    AuthProvider,
    SignupResponse,
    LoginResponse,
    BehavioralStops,
    AuthMeResponse,
    RuntimeProvisioningStatusResponse,
)

# Helpers & config constants
from apps.backend.api.auth_helpers import (  # noqa: F401, E402
    INTERNAL_SIGNUP_BYPASS_DOMAINS,
    INTERNAL_SIGNUP_SKIP_STRIPE_ENABLED,
    RUNTIME_PROVISIONING_COOKIE_NAME,
    _complete_signup_after_identity_verification,
    _set_runtime_provisioning_cookie,
    _clear_runtime_provisioning_cookie,
    _redact_email,
)

_LAZY_COMPAT_EXPORTS = {
    "boto3": (
        "boto3",
        None,
    ),
    "get_tenant_provisioning_service": (
        "apps.backend.services.tenant_provisioning",
        "get_tenant_provisioning_service",
    ),
    "get_workweaver_runtime_provisioning_service": (
        "apps.backend.services.runtime.provisioning_service",
        "get_workweaver_runtime_provisioning_service",
    ),
    "exchange_code_for_tokens": (
        "apps.backend.services.google_oauth",
        "exchange_code_for_tokens",
    ),
    "validate_google_id_token": (
        "apps.backend.services.google_oauth",
        "validate_google_id_token",
    ),
    "mint_workweaver_runtime_provisioning_cookie": (
        "apps.backend.services.runtime.provisioning_token",
        "mint_workweaver_runtime_provisioning_cookie",
    ),
}


def __getattr__(name: str):
    if name not in _LAZY_COMPAT_EXPORTS:
        raise AttributeError(name)
    module_path, attr = _LAZY_COMPAT_EXPORTS[name]
    module = __import__(module_path, fromlist=[attr] if attr else [])
    value = getattr(module, attr) if attr else module
    globals()[name] = value
    return value
