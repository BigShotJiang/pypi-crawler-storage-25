"""Authentication management endpoints (invitations, password reset, behavioral stops).

Extracted from auth.py (Phase 5 tech debt reduction).
"""

import logging
import os
from datetime import datetime, UTC

from fastapi import APIRouter, Depends, Header, HTTPException, Request, status

from apps.backend.api.rate_limit import limiter
from apps.backend.api.auth_models import (
    AcceptInvitationRequest,
    AuthProvider,
    BehavioralStops,
    PasswordResetRequest,
    RequestPasswordResetRequest,
    ResendInvitationRequest,
    SignupResponse,
    UpdateBehavioralStopsRequest,
)
from apps.backend.api.auth_helpers import (
    _disable_cognito,
    _require_cognito_idp,
    _redact_email,
)
from apps.backend.models.user import UserRole  # noqa: E402  -- used by Depends typing
from apps.backend.services.behavioral_stops_store import (
    _get_stops as _get_canonical_behavioral_stops,
    _save_stops as _save_canonical_behavioral_stops,
)

logger = logging.getLogger(__name__)

router = APIRouter()


def get_tenant_provisioning_service():
    from apps.backend.services.tenant_provisioning import (
        get_tenant_provisioning_service as _service_factory,
    )

    return _service_factory()


def _get_verified_tenant_id_dep(
    request: Request,
    x_tenant_id: str | None = Header(None),
) -> str:
    from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

    return get_verified_tenant_id(request=request, x_tenant_id=x_tenant_id)


def _get_verified_user_role_dep(
    request: Request,
    tenant_id: str = Depends(_get_verified_tenant_id_dep),
) -> "UserRole":
    from apps.backend.api.dependencies.tenant_auth import get_verified_user_role

    return get_verified_user_role(request=request, tenant_id=tenant_id)


# ============================================================================
# Invitation Endpoints (TASK-6.0C.002)
# ============================================================================


@router.post(
    "/accept-invitation",
    response_model=SignupResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Accept invitation and create user",
    description="Accept tenant invitation by validating JWT token and creating user account.",
)
@limiter.limit("5/minute")
async def accept_invitation(request: Request, body: AcceptInvitationRequest) -> SignupResponse:
    """
    Accept invitation and create user account.

    Flow:
    1. Validate JWT token from invitation email
    2. Extract invitation details (tenant_id, email, role)
    3. Create user account with provided password
    4. Mark invitation as accepted
    5. Return success response

    Args:
        request: FastAPI request object
        body: Accept invitation request

    Returns:
        SignupResponse with user details

    Raises:
        HTTPException: 400 if validation fails
        HTTPException: 401 if token is invalid or expired
        HTTPException: 404 if invitation not found
        HTTPException: 500 if server error occurs
    """
    try:
        import jwt
        from apps.backend.providers.identity_provider import IdentityProviderError, get_identity_provider
        from apps.backend.services.user_management import (
            InvitationAlreadyFinalizedError,
            InvitationExpiredError,
            UserAlreadyExistsError,
            UserManagementService,
            UserNotFoundError,
        )

        logger.info("Accept invitation request received")

        # Decode JWT token
        try:
            jwt_secret = os.environ.get("JWT_SECRET", "").strip()
            if not jwt_secret:
                raise RuntimeError("JWT_SECRET environment variable is required and must not be empty")
            payload = jwt.decode(
                body.token,
                jwt_secret,
                algorithms=["HS256"],
            )
        except jwt.ExpiredSignatureError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "error": "token_expired",
                    "message": "Invitation token has expired",
                },
            )
        except jwt.InvalidTokenError:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "error": "invalid_token",
                    "message": "Invalid invitation token",
                },
            )

        invitation_id = str(payload.get("invitation_id") or "").strip()
        tenant_id = str(payload.get("tenant_id") or "").strip()
        email = str(payload.get("email") or "").strip().lower()

        if not all([invitation_id, tenant_id, email]):
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "invalid_token",
                    "message": "Token missing required fields",
                },
            )

        # Get invitation
        user_mgmt = UserManagementService()
        try:
            invitation = user_mgmt.get_invitation(invitation_id)
        except UserNotFoundError as exc:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "error": "invitation_not_found",
                    "message": "Invitation not found",
                },
            ) from exc

        if invitation.tenant_id != tenant_id or invitation.invitee_email.lower() != email:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "invitation_token_mismatch",
                    "message": "Invitation token does not match the invitation record",
                },
            )
        if invitation.status != "pending":
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail={
                    "error": "invitation_already_finalized",
                    "message": f"Invitation is already {invitation.status}",
                    "status": invitation.status,
                },
            )
        if user_mgmt.is_invitation_expired(invitation_id):
            try:
                user_mgmt.accept_invitation(invitation_id)
            except InvitationExpiredError:
                pass
            raise HTTPException(
                status_code=status.HTTP_410_GONE,
                detail={
                    "error": "invitation_expired",
                    "message": "Invitation has expired",
                },
            )

        from apps.backend.services.tenant_provisioning import TenantAlreadyExistsError

        provisioning_service = get_tenant_provisioning_service()

        def _signup_response(user_id: str) -> SignupResponse:
            return SignupResponse(
                tenant_id=tenant_id,
                user_id=user_id,
                email=email,
                status="active",
                role=invitation.role,
                auth_provider=AuthProvider.EMAIL_PASSWORD.value,
                next_step="complete_profile",
                provisioning_mode="existing_tenant",
                stripe_checkout_url=None,
            )

        def _accept_once() -> None:
            try:
                user_mgmt.accept_invitation(invitation_id)
            except InvitationAlreadyFinalizedError:
                latest = user_mgmt.get_invitation(invitation_id)
                if latest.status != "accepted":
                    raise

        def _existing_member_user_id() -> str:
            try:
                existing_tenant = provisioning_service.get_tenant_by_email(email, product="workweaver")
            except Exception:
                logger.warning("Failed invite member recovery lookup for %s", _redact_email(email), exc_info=True)
                return ""
            if not existing_tenant or existing_tenant.get("tenant_id") != tenant_id:
                return ""
            return str(existing_tenant.get("member_user_id") or "").strip()

        existing_member_id = _existing_member_user_id()
        if existing_member_id:
            try:
                user_mgmt.create_user(
                    tenant_id=tenant_id,
                    user_id=existing_member_id,
                    email=email,
                    name=body.name,
                    role=invitation.role,
                )
            except UserAlreadyExistsError:
                pass
            _accept_once()
            logger.info("Recovered accepted invitation %s for existing user=%s", invitation_id, existing_member_id)
            return _signup_response(existing_member_id)

        # GAP-003 (issue #1147, Codex round-2 fix): re-run password policy
        # with the invitee email now known from the JWT payload. The
        # Pydantic-level validator runs without email (body doesn't carry
        # one), so it cannot enforce the email-similarity rule. Running it
        # again here closes the bypass: an attacker crafting a valid
        # invite JWT cannot land a password equal to or derived from the
        # invite email.
        from apps.backend.services.password_policy import (
            PasswordPolicyError,
            validate_password,
        )

        try:
            validate_password(body.password, email=email)
        except PasswordPolicyError as pw_exc:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                detail={
                    "error": "weak_password",
                    "message": str(pw_exc),
                    "failures": pw_exc.failures,
                },
            ) from pw_exc

        identity = get_identity_provider()

        try:
            user_id = identity.create_user(
                email=email,
                password=body.password,
                name=body.name or "",
                attributes={
                    "custom:tenant_id": tenant_id,
                    "custom:role": invitation.role.value,
                },
            )
        except IdentityProviderError as exc:
            raise HTTPException(
                status_code=exc.status_code,
                detail={
                    "error": "identity_user_create_failed",
                    "message": str(exc),
                },
            ) from exc
        except Exception as exc:
            error_code = str(getattr(exc, "response", {}).get("Error", {}).get("Code", "")).strip()
            if error_code in {"UsernameExistsException", "AliasExistsException"}:
                existing_member_id = _existing_member_user_id()
                if existing_member_id:
                    try:
                        user_mgmt.create_user(
                            tenant_id=tenant_id,
                            user_id=existing_member_id,
                            email=email,
                            name=body.name,
                            role=invitation.role,
                        )
                    except UserAlreadyExistsError:
                        pass
                    _accept_once()
                    return _signup_response(existing_member_id)
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail={
                        "error": "user_already_exists",
                        "message": "A user already exists for this invitation email",
                    },
                ) from exc
            if error_code == "InvalidPasswordException":
                raise HTTPException(
                    status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                    detail={
                        "error": "weak_password",
                        "message": "Password rejected by identity provider",
                    },
                ) from exc
            if error_code == "InvalidParameterException":
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail={
                        "error": "invalid_identity_user",
                        "message": "Identity provider rejected the invitation user attributes",
                    },
                ) from exc
            if error_code == "TooManyRequestsException":
                raise HTTPException(
                    status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                    detail={
                        "error": "identity_rate_limited",
                        "message": "Identity provider rate limit exceeded",
                    },
                ) from exc
            raise

        if not user_id:
            raise HTTPException(
                status_code=status.HTTP_502_BAD_GATEWAY,
                detail={
                    "error": "identity_user_create_failed",
                    "message": "Identity provider did not return a user id",
                },
            )

        if not _disable_cognito():
            user_pool_id = os.environ.get("COGNITO_USER_POOL_ID", "").strip()
            if not user_pool_id:
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail={
                        "error": "cognito_user_pool_unavailable",
                        "message": "Cognito user pool is not configured",
                    },
                )
            _require_cognito_idp().admin_confirm_sign_up(UserPoolId=user_pool_id, Username=email)

        try:
            provisioning_service.create_user(
                tenant_id=tenant_id,
                user_id=user_id,
                email=email,
                name=body.name,
                role=invitation.role,
            )
        except TenantAlreadyExistsError as exc:
            recovered_user_id = _existing_member_user_id()
            if not recovered_user_id:
                raise HTTPException(
                    status_code=status.HTTP_409_CONFLICT,
                    detail={
                        "error": "user_already_exists",
                        "message": "A user already exists for this invitation email",
                    },
                ) from exc
            user_id = recovered_user_id

        try:
            user_mgmt.create_user(
                tenant_id=tenant_id,
                user_id=user_id,
                email=email,
                name=body.name,
                role=invitation.role,
            )
        except UserAlreadyExistsError:
            pass

        try:
            _accept_once()
        except (InvitationAlreadyFinalizedError, InvitationExpiredError) as exc:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail={
                    "error": "invitation_already_finalized",
                    "message": str(exc),
                },
            ) from exc

        logger.info(f"Successfully accepted invitation {invitation_id} for user={user_id}")

        return _signup_response(user_id)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error accepting invitation: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "accept_invitation_failed",
                "message": "Failed to accept invitation",
            },
        )


# ============================================================================
# Password Reset Endpoints
# ============================================================================


@router.post(
    "/password-reset/request",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Request password reset",
    description="Send password reset email to user.",
)
@limiter.limit("5/minute")
async def request_password_reset(request: Request, body: RequestPasswordResetRequest) -> dict[str, str]:
    """
    Request password reset email.

    Flow:
    1. Validate email format
    2. Generate password reset token
    3. Send reset email with secure link
    4. Return success (always succeed to prevent email enumeration)

    Args:
        request: FastAPI request object
        body: Password reset request

    Returns:
        Success message

    Raises:
        HTTPException: 400 if validation fails
        HTTPException: 500 if server error occurs
    """
    try:
        from apps.backend.services.invitation_service import get_invitation_service

        logger.info("Password reset request for %s", _redact_email(body.email))

        # Send password reset email
        invitation_service = get_invitation_service()
        invitation_service.send_password_reset_email(body.email)

        logger.info("Password reset email sent to %s", _redact_email(body.email))

        return {"message": "If an account exists with this email, a password reset link has been sent."}

    except Exception as e:
        # Always return success to prevent email enumeration
        logger.warning("Password reset request for %s failed: %s", _redact_email(body.email), e)
        return {"message": "If an account exists with this email, a password reset link has been sent."}


@router.post(
    "/password-reset/confirm",
    status_code=status.HTTP_200_OK,
    summary="Complete password reset",
    description="Reset user password using token from email.",
)
@limiter.limit("10/minute")
async def confirm_password_reset(request: Request, body: PasswordResetRequest) -> dict[str, str]:
    """
    Complete password reset flow.

    Flow:
    1. Validate JWT token from reset email
    2. Reset user password
    3. Return success

    Args:
        request: FastAPI request object
        body: Password reset confirmation

    Returns:
        Success message

    Raises:
        HTTPException: 400 if validation fails
        HTTPException: 401 if token is invalid or expired
        HTTPException: 500 if server error occurs
    """
    try:
        from apps.backend.services.invitation_service import get_invitation_service

        logger.info("Password reset confirmation request")

        # Reset password using token
        invitation_service = get_invitation_service()
        invitation_service.reset_password(body.token, body.new_password)

        logger.info("Password reset successfully")

        return {"message": "Password has been reset successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error confirming password reset: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "password_reset_failed",
                "message": "Failed to reset password",
            },
        )


@router.post(
    "/resend-invitation",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Resend invitation email",
    description="Resend invitation email for expired or pending invitations. Admin-only (#2746).",
)
@limiter.limit("3/minute")
async def resend_invitation(
    request: Request,
    body: ResendInvitationRequest,
    verified_tenant_id: str = Depends(_get_verified_tenant_id_dep),
    requester_role: "UserRole" = Depends(_get_verified_user_role_dep),
) -> dict[str, str]:
    """
    Resend invitation email.

    Flow:
    1. Find existing invitation
    2. If expired, create new invitation
    3. Send invitation email
    4. Return success

    Args:
        request: FastAPI request object
        body: Resend invitation request

    Returns:
        Success message

    Raises:
        HTTPException: 400 if validation fails
        HTTPException: 404 if no invitation exists
        HTTPException: 500 if server error occurs
    """
    try:
        from apps.backend.services.invitation_service import get_invitation_service

        # Issue #2746: tenant_id from the verified auth context overrides
        # the body. The verified id has the TENANT# prefix stripped while
        # the UI sends the prefixed form, so compare on a normalized basis.
        def _strip_tenant_prefix(value: str) -> str:
            v = str(value or "").strip()
            return v[len("TENANT#"):] if v.startswith("TENANT#") else v

        if _strip_tenant_prefix(body.tenant_id) != _strip_tenant_prefix(verified_tenant_id):
            logger.warning(
                "Resend invitation tenant mismatch: body=%s verified=%s",
                body.tenant_id,
                verified_tenant_id,
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={"error": "tenant_mismatch", "message": "Cannot resend across tenants"},
            )

        # Admin role gating: only admins can resend (#2746).
        from apps.backend.services.user_management import UserManagementService
        if not UserManagementService().can_invite_users(requester_role):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={"error": "InsufficientPrivilegesError", "detail": "Only admins can resend invitations"},
            )

        logger.info("Resend invitation request for tenant=%s, email=%s", body.tenant_id, _redact_email(body.email))

        # Resend invitation
        invitation_service = get_invitation_service()
        invitation_service.resend_invitation(body.tenant_id, body.email)

        logger.info("Invitation resent to %s", _redact_email(body.email))

        return {"message": f"Invitation has been sent to {body.email}"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error resending invitation: {e}")
        # BUG FIX: was HTTP_500_INTERNAL_SERVER_SERVICE (typo), corrected to HTTP_500_INTERNAL_SERVER_ERROR
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "resend_invitation_failed",
                "message": "Failed to resend invitation",
            },
        )


# =============================================================================
# Part 9: Safety Controls - Behavioral Stops
# =============================================================================


@router.put(
    "/tenant/{tenant_id}/behavioral-stops",
    response_model=BehavioralStops,
    status_code=status.HTTP_200_OK,
    summary="Update behavioral stops (Part 9.0B)",
    description="Update tenant-level behavioral stop controls (emergency brake).",
)
async def update_behavioral_stops(
    tenant_id: str,
    body: UpdateBehavioralStopsRequest,
    _verified_tenant_id: str = Depends(_get_verified_tenant_id_dep),
) -> BehavioralStops:
    """
    Update behavioral stops for a tenant.

    This implements Part 9.0B - Behavioral Stop Controls:
    - Pause all execution (emergency brake)
    - Pause autonomy only
    - Block specific tools
    - Block operation types
    - Quiet hours
    - Interrupt budget
    """
    if tenant_id != _verified_tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": "tenant_mismatch", "message": "Organization mismatch"},
        )

    # Get existing behavioral stops or create defaults
    current = BehavioralStops(**_get_canonical_behavioral_stops(tenant_id))

    # Update fields
    now = datetime.now(UTC).isoformat()

    if body.paused is not None:
        current.paused = body.paused
        current.paused_at = now if body.paused else None

    if body.pause_reason is not None:
        current.pause_reason = body.pause_reason

    if body.pause_autonomy is not None:
        current.pause_autonomy = body.pause_autonomy
        current.pause_autonomy_at = now if body.pause_autonomy else None

    if body.blocked_tools is not None:
        current.blocked_tools = body.blocked_tools

    if body.blocked_operation_types is not None:
        current.blocked_operation_types = body.blocked_operation_types

    if body.quiet_hours_enabled is not None:
        current.quiet_hours_enabled = body.quiet_hours_enabled
    if body.quiet_hours_start is not None:
        current.quiet_hours_start = body.quiet_hours_start
    if body.quiet_hours_end is not None:
        current.quiet_hours_end = body.quiet_hours_end
    if body.quiet_hours_blocked_types is not None:
        current.quiet_hours_blocked_types = body.quiet_hours_blocked_types

    if body.interrupt_budget_enabled is not None:
        current.interrupt_budget_enabled = body.interrupt_budget_enabled
    if body.max_notifications_per_day is not None:
        current.max_notifications_per_day = body.max_notifications_per_day
    if body.max_messages_per_hour is not None:
        current.max_messages_per_hour = body.max_messages_per_hour
    if body.learning_agility is not None:
        current.learning_agility = body.learning_agility
    if body.adaptation_mode is not None:
        current.adaptation_mode = body.adaptation_mode
    if body.confirmation_mode is not None:
        current.confirmation_mode = body.confirmation_mode
    if body.proactive_learning_enabled is not None:
        current.proactive_learning_enabled = body.proactive_learning_enabled
    if body.signal_horizon is not None:
        current.signal_horizon = body.signal_horizon
    if body.drift_sensitivity is not None:
        current.drift_sensitivity = body.drift_sensitivity

    try:
        _save_canonical_behavioral_stops(tenant_id, current.model_dump(exclude_none=True))
    except Exception as e:
        logger.error(f"Failed to save behavioral stops: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "save_failed",
                "message": "Failed to save behavioral stops",
            },
        )

    # Emit evidence receipt for policy.behavioral_stop_set (Part 9.0B)
    try:
        logger.info(
            f"Evidence: behavioral_stop_set tenant={tenant_id} paused={current.paused} "
            f"pause_autonomy={current.pause_autonomy} blocked_tools={current.blocked_tools}"
        )
    except Exception as evidence_error:
        logger.warning(f"Failed to emit evidence receipt: {evidence_error}")

    return current


@router.get(
    "/tenant/{tenant_id}/behavioral-stops",
    response_model=BehavioralStops,
    status_code=status.HTTP_200_OK,
    summary="Get behavioral stops (Part 9.0B)",
    description="Get tenant-level behavioral stop controls.",
)
async def get_behavioral_stops(
    tenant_id: str,
    _verified_tenant_id: str = Depends(_get_verified_tenant_id_dep),
) -> BehavioralStops:
    """Get behavioral stops for a tenant."""
    if tenant_id != _verified_tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": "tenant_mismatch", "message": "Organization mismatch"},
        )

    return BehavioralStops(**_get_canonical_behavioral_stops(tenant_id))
