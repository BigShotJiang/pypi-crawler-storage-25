"""Weekly Upgrade Digest API."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.schemas.error_response import ErrorResponse
from apps.backend.services.upgrade_digest import UpgradeDigestError, UpgradeDigestService, get_upgrade_digest_service

router = APIRouter(prefix="/api/v1/upgrades", tags=["upgrades"])


class UpgradeActionRequest(BaseModel):
    actor_id: str = Field(default="unknown", description="User or agent approving the upgrade action.")


def _service() -> UpgradeDigestService:
    return get_upgrade_digest_service()


@router.get("", responses={503: {"model": ErrorResponse}})
@router.get("/", include_in_schema=False)
async def list_upgrades(
    service: UpgradeDigestService = Depends(_service),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return the tenant's current Weekly Upgrade Digest."""

    try:
        return service.build_digest(tenant_id).to_dict()
    except UpgradeDigestError as exc:
        raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail=str(exc)) from exc


@router.get("/{proposal_id}", responses={404: {"model": ErrorResponse}})
async def show_upgrade(
    proposal_id: str,
    service: UpgradeDigestService = Depends(_service),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return one L3 upgrade proposal."""

    try:
        return service.get_proposal(tenant_id, proposal_id)
    except UpgradeDigestError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc


@router.post("/{proposal_id}/approve", responses={404: {"model": ErrorResponse}})
async def approve_upgrade(
    proposal_id: str,
    request: UpgradeActionRequest | None = None,
    service: UpgradeDigestService = Depends(_service),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Approve a proposal and move it to applying state."""

    try:
        return service.approve(tenant_id, proposal_id, actor_id=(request or UpgradeActionRequest()).actor_id)
    except UpgradeDigestError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc


@router.post("/{proposal_id}/pilot", responses={404: {"model": ErrorResponse}})
async def pilot_upgrade(
    proposal_id: str,
    request: UpgradeActionRequest | None = None,
    service: UpgradeDigestService = Depends(_service),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Schedule a 1-week, 10% pilot for a proposal."""

    try:
        return service.pilot(tenant_id, proposal_id, actor_id=(request or UpgradeActionRequest()).actor_id)
    except UpgradeDigestError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc


@router.post("/{proposal_id}/dismiss", responses={404: {"model": ErrorResponse}})
async def dismiss_upgrade(
    proposal_id: str,
    request: UpgradeActionRequest | None = None,
    service: UpgradeDigestService = Depends(_service),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Dismiss a proposal for 90 days."""

    try:
        return service.dismiss(tenant_id, proposal_id, actor_id=(request or UpgradeActionRequest()).actor_id)
    except UpgradeDigestError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
