"""Swarm step success-criteria REST surface (#3238).

Exposes the deterministic ``SuccessCriteriaEvaluator`` to humans via REST so
the CLI (`ww mission criterion <step-id>`) and dashboards can evaluate or
inspect swarm step criteria without reaching into the runtime CompletionGate.

Routes
------
- ``GET /api/v1/swarm/steps/{step_id}/criterion``
    Look up the stored success criterion (and last evaluation, if any) for a
    swarm step belonging to the authenticated tenant. Returns ``204`` when no
    matching step is found so CLI consumers can render an empty state.
- ``POST /api/v1/swarm/steps/{step_id}/criterion/evaluate``
    Evaluate a criteria spec against an evidence bundle and emit a
    Decision Trace. Body shape matches the evaluator's keyword arguments
    (``criteria`` plus ``evidence``).
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException, status
from pydantic import BaseModel, ConfigDict, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.swarm.success_criteria_evaluator import (
    EvaluationResult,
    SuccessCriteriaEvaluator,
)
from apps.backend.services.swarm_scheduler import (
    SwarmScheduler,
    get_swarm_scheduler,
)
from apps.backend.utils.tenant import strip_tenant_prefix

router = APIRouter(prefix="/api/v1/swarm", tags=["swarm"])


class CriterionLookupResponse(BaseModel):
    """Stored criterion + last evaluation for a swarm step."""

    model_config = ConfigDict(extra="forbid")

    step_id: str
    execution_id: str | None = None
    tenant_id: str
    criteria: dict[str, Any] | None = None
    last_evaluation: dict[str, Any] | None = None
    found: bool


class CriterionEvaluateRequest(BaseModel):
    """Body for ``POST /criterion/evaluate``.

    ``criteria`` is the criterion spec (``criteria_type`` plus type-specific
    parameters). ``evidence`` is the bundle to evaluate against. Both are
    required so the evaluator can run without leaning on runtime state.
    """

    model_config = ConfigDict(extra="forbid")

    criteria: dict[str, Any] = Field(...)
    evidence: dict[str, Any] = Field(default_factory=dict)
    actor_chain: list[str] = Field(default_factory=list)


class CriterionEvaluateResponse(BaseModel):
    """Surface payload for an evaluator verdict."""

    model_config = ConfigDict(extra="forbid")

    step_id: str
    tenant_id: str
    passed: bool
    criteria_type: str
    details: list[str]


def _scheduler() -> SwarmScheduler:
    return get_swarm_scheduler()


def _find_step(
    scheduler: SwarmScheduler, tenant: str, step_id: str
) -> tuple[str | None, dict[str, Any] | None]:
    """Locate the named step inside any swarm execution for ``tenant``.

    Returns a ``(execution_id, step_payload)`` tuple. Either side is ``None``
    when the step has not been recorded yet — surface callers must render an
    empty state rather than 5xx in that case.
    """
    target = step_id.strip()
    if not target:
        return None, None
    for execution in scheduler.list_executions(tenant, limit=500):
        for step in execution.steps:
            if not isinstance(step, dict):
                continue
            if str(step.get("step_id") or "") == target:
                return execution.execution_id, step
    return None, None


def _result_payload(result: EvaluationResult) -> dict[str, Any]:
    return {
        "passed": result.passed,
        "criteria_type": result.criteria_type,
        "details": list(result.details),
    }


@router.get(
    "/steps/{step_id}/criterion",
    response_model=CriterionLookupResponse,
)
async def get_step_criterion(
    step_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CriterionLookupResponse:
    """Return the stored success criterion (and last verdict, if any)."""
    tenant = strip_tenant_prefix(tenant_id)
    execution_id, step = _find_step(_scheduler(), tenant, step_id)
    if step is None:
        return CriterionLookupResponse(
            step_id=step_id,
            execution_id=None,
            tenant_id=tenant,
            criteria=None,
            last_evaluation=None,
            found=False,
        )
    payload = step.get("payload") if isinstance(step.get("payload"), dict) else {}
    criteria = payload.get("success_criteria") if isinstance(payload, dict) else None
    last_eval = payload.get("success_criteria_result") if isinstance(payload, dict) else None
    return CriterionLookupResponse(
        step_id=step_id,
        execution_id=execution_id,
        tenant_id=tenant,
        criteria=criteria if isinstance(criteria, dict) else None,
        last_evaluation=last_eval if isinstance(last_eval, dict) else None,
        found=True,
    )


@router.post(
    "/steps/{step_id}/criterion/evaluate",
    response_model=CriterionEvaluateResponse,
)
async def evaluate_step_criterion(
    step_id: str,
    request: CriterionEvaluateRequest = Body(...),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CriterionEvaluateResponse:
    """Evaluate ``criteria`` against ``evidence`` and emit a Decision Trace."""
    tenant = strip_tenant_prefix(tenant_id)
    try:
        result = SuccessCriteriaEvaluator.evaluate(
            criteria=request.criteria,
            evidence=request.evidence,
            tenant_id=tenant,
            step_id=step_id,
            actor_chain=list(request.actor_chain),
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)
        ) from exc
    payload = _result_payload(result)
    return CriterionEvaluateResponse(
        step_id=step_id,
        tenant_id=tenant,
        passed=payload["passed"],
        criteria_type=payload["criteria_type"],
        details=payload["details"],
    )
