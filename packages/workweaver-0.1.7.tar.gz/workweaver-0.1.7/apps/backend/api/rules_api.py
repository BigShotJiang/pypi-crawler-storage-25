"""Governance Rules API (DevEx P2.2).

Tenant-facing CRUD + evaluation for governance rules.

Routes:
    GET   /api/v1/rules              -- list rules
    POST  /api/v1/rules              -- create rule
    PUT   /api/v1/rules/{rule_id}    -- update (toggle) rule
    POST  /api/v1/rules/evaluate     -- evaluate rules against action context
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.rule_engine import (
    RuleAction,
    RuleType,
    get_rule_engine,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/rules", tags=["rules"])


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class CreateRuleRequest(BaseModel):
    """Request body for creating a governance rule."""

    display_name: str
    rule_type: RuleType
    condition: dict[str, Any] = Field(default_factory=dict)
    action: RuleAction
    entity_id: str | None = None


class ToggleRuleRequest(BaseModel):
    """Request body for toggling a rule's active state."""

    is_active: bool


class EvaluateRulesRequest(BaseModel):
    """Request body for evaluating rules against an action context."""

    entity_id: str | None = None
    action_context: dict[str, Any]


class RuleResponse(BaseModel):
    """Single rule in API responses."""

    id: str
    tenant_id: str
    entity_id: str | None = None
    display_name: str
    rule_type: str
    condition: dict[str, Any]
    action: str
    is_active: bool
    is_system: bool
    created_at: str


class EvaluationResultResponse(BaseModel):
    """Single evaluation result in API responses."""

    rule_id: str
    rule_name: str
    triggered: bool
    action: str
    reason: str


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("", response_model=list[RuleResponse])
async def list_rules(
    tenant_id: str = Depends(get_verified_tenant_id),
    entity_id: str | None = None,
) -> list[RuleResponse]:
    """List all governance rules for a tenant (includes system rules)."""
    engine = get_rule_engine()
    rules = engine.list_rules(tenant_id, entity_id=entity_id)
    return [
        RuleResponse(
            id=r.id,
            tenant_id=r.tenant_id,
            entity_id=r.entity_id,
            display_name=r.display_name,
            rule_type=r.rule_type.value,
            condition=r.condition,
            action=r.action.value,
            is_active=r.is_active,
            is_system=r.is_system,
            created_at=r.created_at,
        )
        for r in rules
    ]


@router.post("", response_model=RuleResponse, status_code=status.HTTP_201_CREATED)
async def create_rule(
    body: CreateRuleRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> RuleResponse:
    """Create a new tenant governance rule."""
    engine = get_rule_engine()
    rule = engine.create_rule(
        tenant_id,
        {
            "display_name": body.display_name,
            "rule_type": body.rule_type.value,
            "condition": body.condition,
            "action": body.action.value,
            "entity_id": body.entity_id,
        },
    )
    return RuleResponse(
        id=rule.id,
        tenant_id=rule.tenant_id,
        entity_id=rule.entity_id,
        display_name=rule.display_name,
        rule_type=rule.rule_type.value,
        condition=rule.condition,
        action=rule.action.value,
        is_active=rule.is_active,
        is_system=rule.is_system,
        created_at=rule.created_at,
    )


@router.put("/{rule_id}", response_model=dict[str, Any])
async def update_rule(
    rule_id: str,
    body: ToggleRuleRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Toggle a rule's active state. System rules cannot be disabled."""
    engine = get_rule_engine()
    try:
        engine.toggle_rule(tenant_id, rule_id, active=body.is_active)
    except ValueError as exc:
        logger.error("Rule toggle failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid request parameters",
        ) from exc
    return {"rule_id": rule_id, "is_active": body.is_active}


@router.post("/evaluate", response_model=list[EvaluationResultResponse])
async def evaluate_rules(
    body: EvaluateRulesRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[EvaluationResultResponse]:
    """Evaluate all applicable rules against the provided action context."""
    engine = get_rule_engine()
    results = engine.evaluate_rules(
        tenant_id=tenant_id,
        entity_id=body.entity_id,
        action_context=body.action_context,
    )
    return [
        EvaluationResultResponse(
            rule_id=r.rule_id,
            rule_name=r.rule_name,
            triggered=r.triggered,
            action=r.action.value,
            reason=r.reason,
        )
        for r in results
    ]
