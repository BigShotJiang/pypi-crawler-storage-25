"""Standards-based connector registration routes."""

from __future__ import annotations

import inspect
import logging
from typing import Any

from fastapi import Depends, HTTPException, status

from apps.backend.api.connectors_contracts import (
    StandardConnectorDefinitionResponse,
    StandardConnectorRegisterRequest,
)
from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.pagination import (
    PaginationParams,
    build_pagination_dependency,
    paginate_items,
)

from ._core import _get_standard_registry, router

logger = logging.getLogger(__name__)


@router.get("/standards/definitions", response_model=list[StandardConnectorDefinitionResponse])
async def list_standard_connector_definitions(
    tenant_id: str = Depends(get_verified_tenant_id),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> list[dict[str, Any]]:
    """List tenant-defined advanced connectors on the canonical substrate."""
    definitions, _total = paginate_items(_get_standard_registry().list_definitions(tenant_id), pagination)
    return definitions


@router.post(
    "/standards/register", response_model=StandardConnectorDefinitionResponse, status_code=status.HTTP_201_CREATED
)
async def register_standard_connector(
    body: StandardConnectorRegisterRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Register and verify a standards-based connector on the canonical substrate."""
    registry = _get_standard_registry()
    try:
        result = registry.register_definition(
            tenant_id,
            {
                "connector_id": body.connector_id,
                "name": body.name,
                "description": body.description,
                "category": body.category,
                "documentation_url": body.documentation_url,
                "transport": body.transport,
                "auth": body.auth,
                "operations": body.operations,
            },
        )
        if inspect.isawaitable(result):
            result = await result
        return result
    except ValueError as exc:
        logger.warning("register_connector validation error: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid connector registration data",
        ) from exc
