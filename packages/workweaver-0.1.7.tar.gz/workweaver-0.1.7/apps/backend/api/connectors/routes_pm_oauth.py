"""REST endpoints for PM connector OAuth2 flows.

Issue #3585: OAuth2 flows for PM connectors (JIRA, Linear, Asana, Trello).

Routes:
- POST /{provider}/oauth/authorize  -- returns redirect URL
- GET  /{provider}/oauth/callback   -- exchanges code for token + stores in vault

These routes supplement the existing ``routes_oauth_dispatch`` dispatcher.
The dispatch route handles the wizard-facing ``POST /{connector_id}/oauth/start``
contract; these routes provide PM-provider-specific authorize/callback semantics
that the dispatch route can delegate to.
"""

from __future__ import annotations

import logging

from fastapi import Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.connectors.pm_connector_oauth_mixin import (
    PMConnectorOAuthMixin,
    PROVIDER_OAUTH_CONFIGS,
)

from ._core import router

logger = logging.getLogger(__name__)

_SUPPORTED_PROVIDERS = frozenset(PROVIDER_OAUTH_CONFIGS.keys())


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class PMAuthorizeRequest(BaseModel):
    """Request body for PM connector OAuth authorize."""

    redirect_uri: str | None = Field(
        default=None,
        description="Override OAuth callback URI.",
    )


class PMAuthorizeResponse(BaseModel):
    """Response with the authorization redirect URL."""

    authorize_url: str = Field(..., description="Provider authorization URL.")
    state: str = Field(..., description="CSRF state token.")
    provider: str = Field(..., description="Provider key.")


class PMCallbackResponse(BaseModel):
    """Response after successful code exchange."""

    provider: str = Field(..., description="Provider key.")
    token_stored: bool = Field(..., description="Whether token was stored.")
    expires_at: str | None = Field(
        default=None, description="Token expiry ISO timestamp."
    )


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.post(
    "/{provider}/oauth/authorize",
    response_model=PMAuthorizeResponse,
    summary="Start OAuth2 flow for a PM connector",
    description="Returns the provider authorization URL for the tenant to redirect to.",
)
async def pm_oauth_authorize(
    provider: str,
    body: PMAuthorizeRequest | None = None,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PMAuthorizeResponse:
    """Generate OAuth2 authorization URL for the given PM provider."""
    provider = (provider or "").strip().lower()
    if provider not in _SUPPORTED_PROVIDERS:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Provider '{provider}' does not support OAuth. Supported: {sorted(_SUPPORTED_PROVIDERS)}",
        )

    import os
    import secrets

    import apps.backend.api.dependencies.redirect_validation as rv

    redirect_uri = (body.redirect_uri if body else None) or ""
    if not redirect_uri:
        public_base = (os.environ.get("PUBLIC_BASE_URL") or "https://api.workweaver.ai").rstrip("/")
        redirect_uri = f"{public_base}/api/v1/connectors/{provider}/oauth/callback"

    validated_redirect = rv.validate_redirect_url(redirect_uri, tenant_id=tenant_id)

    state = secrets.token_urlsafe(32)
    mixin = PMConnectorOAuthMixin()

    try:
        url = mixin.build_authorization_url(
            provider=provider,
            state=state,
            redirect_uri=validated_redirect,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc

    return PMAuthorizeResponse(
        authorize_url=url,
        state=state,
        provider=provider,
    )


@router.get(
    "/{provider}/oauth/callback",
    response_model=PMCallbackResponse,
    summary="Complete OAuth2 flow for a PM connector",
    description="Exchanges the authorization code for a token and stores it in the vault.",
)
async def pm_oauth_callback(
    provider: str,
    code: str = Query(..., description="Authorization code from provider."),
    state: str = Query(..., description="CSRF state token."),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PMCallbackResponse:
    """Exchange authorization code for access token and store in vault."""
    provider = (provider or "").strip().lower()
    if provider not in _SUPPORTED_PROVIDERS:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Provider '{provider}' does not support OAuth. Supported: {sorted(_SUPPORTED_PROVIDERS)}",
        )

    import os

    public_base = (os.environ.get("PUBLIC_BASE_URL") or "https://api.workweaver.ai").rstrip("/")
    redirect_uri = f"{public_base}/api/v1/connectors/{provider}/oauth/callback"

    mixin = PMConnectorOAuthMixin()

    try:
        record = await mixin.exchange_authorization_code(
            tenant_id=tenant_id,
            provider=provider,
            code=code,
            redirect_uri=redirect_uri,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc

    return PMCallbackResponse(
        provider=provider,
        token_stored=True,
        expires_at=record.expires_at.isoformat() if record.expires_at else None,
    )


__all__ = [
    "PMCallbackResponse",
    "PMAuthorizeRequest",
    "PMAuthorizeResponse",
    "pm_oauth_authorize",
    "pm_oauth_callback",
]
