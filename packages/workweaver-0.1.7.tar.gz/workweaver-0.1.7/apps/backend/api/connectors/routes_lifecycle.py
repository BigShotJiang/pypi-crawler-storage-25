"""Connector lifecycle routes — detail, list, install, uninstall, execute, health."""

from __future__ import annotations

import hashlib
import json
import logging
import uuid
from typing import Any

from fastapi import Depends, HTTPException, Query, status

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.connectors_contracts import (
    ConnectorDetailResponse,
    ConnectorListResponse,
    ExecuteRequest,
    ExecuteResponse,
    HealthResponse,
    InstallRequest,
    InstallResponse,
)
from apps.backend.api.pagination import (
    PaginationParams,
    build_pagination_dependency,
    paginate_items,
)
from apps.backend.services.connector_health_monitor import get_connector_health_monitor
from apps.backend.services.connectors.base import ConnectorConfig
from apps.backend.services.connectors.execution_policy import (
    ConnectorBulkheadSaturated,
    ConnectorExecutionPolicyError,
    ConnectorExecutionTimedOut,
    get_connector_execution_envelope,
)
from apps.backend.services.connectors.connector_sdk import get_connector_sdk
from apps.backend.services.failure_taxonomy import classify_failure

from ._core import (
    _CONNECTOR_CLASSES,
    _catalog_connector_summaries,
    _evidence_url,
    _get_connector_info,
    _get_marketplace,
    _get_standard_registry,
    _get_zoho_connection_manager,
    _load_connector_classes,
    _record_connector_execution,
    _record_connector_mutation,
    _run_connector_health_check,
    _run_zoho_connector_health_check,
    _zoho_connection_for_connector,
    _zoho_credential_owner,
    _zoho_product_for_connector_id,
    router,
)

logger = logging.getLogger(__name__)


def _execute_body_dry_run(body: Any) -> bool:
    return bool(getattr(body, "dry_run", False))


def _execute_body_idempotency_key(body: Any) -> str | None:
    normalized = str(getattr(body, "idempotency_key", None) or "").strip()
    return normalized or None


def _scope_connector_idempotency_key(
    *,
    tenant_id: str,
    connector_id: str,
    operation_id: str,
    idempotency_key: str | None,
    params: dict[str, Any] | None = None,
) -> str | None:
    if not idempotency_key:
        idempotency_key = _request_scoped_connector_idempotency_key(
            connector_id=connector_id,
            operation_id=operation_id,
            params=params or {},
        )
    return ":".join(
        [
            str(tenant_id or "").strip(),
            str(connector_id or "").strip(),
            str(operation_id or "").strip(),
            idempotency_key,
        ]
    )


def _request_scoped_connector_idempotency_key(
    *,
    connector_id: str,
    operation_id: str,
    params: dict[str, Any],
) -> str:
    payload = json.dumps(
        {
            "connector_id": connector_id,
            "operation_id": operation_id,
            "params": params,
        },
        sort_keys=True,
        separators=(",", ":"),
        default=str,
    )
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()[:16]
    return f"request:{digest}:{uuid.uuid4().hex}"


@router.get("/{connector_id}", response_model=ConnectorDetailResponse)
async def get_connector(connector_id: str) -> dict[str, Any]:
    """Get full details for a single connector.

    Includes auth field schema, supported operations with their
    input/output schemas, and metadata.
    """
    try:
        return _get_connector_info(connector_id)
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Connector '{connector_id}' not found.",
        )


@router.get("", response_model=ConnectorListResponse)
async def list_connectors(
    category: str | None = Query(default=None, description="Filter by category"),
    search: str | None = Query(default=None, description="Search query"),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=20, max_limit=100)),
) -> dict[str, Any]:
    """Browse the connector marketplace.

    Supports filtering by category, free-text search, and pagination.
    """
    try:
        connectors = _catalog_connector_summaries()
        if category:
            connectors = [item for item in connectors if str(item.get("category") or "") == category]
        if search:
            needle = search.lower()
            connectors = [
                item
                for item in connectors
                if needle in (f"{item.get('id', '')} {item.get('name', '')} {item.get('description', '')}").lower()
            ]
        page_items, total = paginate_items(connectors, pagination)
        pages = max(1, (total + pagination.limit - 1) // pagination.limit)
        return {
            "items": page_items,
            "total": total,
            "page": (pagination.offset // pagination.limit) + 1,
            "page_size": pagination.limit,
            "pages": pages,
        }
    except ValueError as exc:
        logger.warning("list_connectors validation error: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid connector list parameters",
        )


@router.post("/{connector_id}/install", response_model=InstallResponse, status_code=status.HTTP_201_CREATED)
async def install_connector(
    connector_id: str,
    body: InstallRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Install a connector for the requesting tenant.

    Validates credentials against the connector's auth schema before
    persisting. Re-installing updates credentials.
    """
    mp = _get_marketplace()
    from apps.backend.services.agent_credential_vault import VaultConfigurationError

    zoho_product = _zoho_product_for_connector_id(connector_id)
    if zoho_product is not None:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                f"Connector '{connector_id}' uses Workweaver-owned Zoho OAuth. "
                "Start the canonical auth flow at /api/v1/connectors/zoho/auth/start instead of installing credentials."
            ),
        )

    if connector_id.startswith("custom-tenant-"):
        _get_standard_registry().ensure_registered(tenant_id, connector_id)

    try:
        installation = mp.install_connector(
            tenant_id,
            connector_id,
            body.credentials,
            agent_id=body.agent_id,
        )
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Connector '{connector_id}' not found.",
        )
    except ValueError as exc:
        logger.warning("install_connector validation error connector=%s: %s", connector_id, exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid connector installation data",
        )
    except VaultConfigurationError as exc:
        logger.error("install_connector vault error connector=%s: %s", connector_id, exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Credential vault unavailable",
        ) from exc

    evidence_event_id = _record_connector_mutation(
        tenant_id=tenant_id,
        connector_id=connector_id,
        action="installed",
        credential_owner=installation.credential_agent_id or body.agent_id or "shared",
    )
    logger.info("[%s] Installed connector '%s'", tenant_id, connector_id)
    return {
        **installation.to_dict(),
        "state": "verified",
        "credential_owner": installation.credential_agent_id or body.agent_id or "shared",
        "evidence_event_id": evidence_event_id,
        "evidence_url": _evidence_url(evidence_event_id),
    }


@router.delete("/{connector_id}/uninstall", status_code=status.HTTP_204_NO_CONTENT)
async def uninstall_connector(
    connector_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> None:
    """Uninstall a connector for the requesting tenant.

    Removes the installation record and stored credentials.
    """
    mp = _get_marketplace()
    zoho_product = _zoho_product_for_connector_id(connector_id)

    if zoho_product is not None:
        connection = _get_zoho_connection_manager().disconnect_connection(tenant_id, zoho_product.product_slug)
        if connection is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No canonical Zoho connection found for connector '{connector_id}'.",
            )
        _record_connector_mutation(
            tenant_id=tenant_id,
            connector_id=connector_id,
            action="uninstalled",
            credential_owner=_zoho_credential_owner(connection),
        )
        logger.info("[%s] Disconnected canonical Zoho connector '%s'", tenant_id, connector_id)
        return

    try:
        installation = mp._load_installation(tenant_id, connector_id)
        mp.uninstall_connector(tenant_id, connector_id)
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No installation found for connector '{connector_id}'.",
        )

    _record_connector_mutation(
        tenant_id=tenant_id,
        connector_id=connector_id,
        action="uninstalled",
        credential_owner=installation.credential_agent_id or "shared",
    )
    logger.info("[%s] Uninstalled connector '%s'", tenant_id, connector_id)


@router.post("/{connector_id}/execute", response_model=ExecuteResponse)
async def execute_connector(
    connector_id: str,
    body: ExecuteRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Execute an operation on an installed connector.

    Steps:
    1. Verify the connector is installed for the tenant.
    2. Retrieve stored credentials from the installation record.
    3. Instantiate the connector class (if available) or delegate to SDK executor.
    4. Execute the requested operation.
    5. Return the result.

    Raises 403 if the connector is not installed, 400 for bad operations,
    and 404 if the connector does not exist.
    """
    dry_run = _execute_body_dry_run(body)
    idempotency_key = _execute_body_idempotency_key(body)
    caller_supplied_idempotency_key = idempotency_key is not None
    scoped_idempotency_key = _scope_connector_idempotency_key(
        tenant_id=tenant_id,
        connector_id=connector_id,
        operation_id=body.operation_id,
        idempotency_key=idempotency_key,
        params=body.params,
    )
    connector_idempotency_key = scoped_idempotency_key if caller_supplied_idempotency_key else None
    mp = _get_marketplace()
    sdk = get_connector_sdk()
    from apps.backend.services.agent_credential_vault import VaultConfigurationError

    zoho_product = _zoho_product_for_connector_id(connector_id)
    zoho_connection = _zoho_connection_for_connector(tenant_id, connector_id) if zoho_product is not None else None

    if connector_id.startswith("custom-tenant-"):
        _get_standard_registry().ensure_registered(tenant_id, connector_id)

    # 1. Verify connector exists in registry
    try:
        connector_info = _get_connector_info(connector_id)
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Connector '{connector_id}' not found.",
        )

    installation = None
    if zoho_product is not None:
        if zoho_connection is None or zoho_connection.state != "connected":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Connector '{connector_id}' is not connected for this organization.",
            )
        credentials: dict[str, Any] = {}
        credential_owner = _zoho_credential_owner(zoho_connection)
    else:
        # 2. Verify installed for tenant and get credentials
        try:
            installation = mp._load_installation(tenant_id, connector_id)
        except KeyError:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Connector '{connector_id}' is not installed for this organization. Install it first.",
            )

        try:
            credentials = mp.resolve_credentials(tenant_id, installation)
        except VaultConfigurationError as exc:
            logger.error("execute_connector vault error connector=%s: %s", connector_id, exc, exc_info=True)
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Credential vault unavailable",
            ) from exc
        credential_owner = installation.credential_agent_id or "shared"

    # 3. Validate the operation exists
    supported_ops = [op["id"] for op in connector_info["operations"]]
    if body.operation_id not in supported_ops:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Operation '{body.operation_id}' is not supported by connector "
                f"'{connector_id}'. Supported: {supported_ops}"
            ),
        )

    # 4. Execute via ConnectorBase subclass if available, otherwise SDK executor
    logger.info(
        "[%s] Executing '%s.%s' with %d params",
        tenant_id,
        connector_id,
        body.operation_id,
        len(body.params),
    )

    _load_connector_classes()
    execution_mode = "class" if connector_id in _CONNECTOR_CLASSES else "sdk"
    if zoho_product is not None and execution_mode != "class":
        execution_mode = "unsupported_zoho"

    execution_envelope = get_connector_execution_envelope()
    execution_policy = execution_envelope.build_policy(
        tenant_id=tenant_id,
        connector_id=connector_id,
        operation_id=body.operation_id,
    )

    try:
        if execution_mode == "class":
            operation_params = dict(body.params)
            if body.idempotency_key and "idempotency_key" not in operation_params:
                operation_params["idempotency_key"] = body.idempotency_key
            # Instantiate the typed connector class
            config = ConnectorConfig(
                provider=connector_id,
                tenant_id=tenant_id,
                credentials=credentials,
            )
            connector_instance = _CONNECTOR_CLASSES[connector_id](config)
            result = await execution_envelope.execute(
                lambda: connector_instance.execute_with_preview(
                    body.operation_id,
                    operation_params,
                    dry_run=dry_run,
                    idempotency_key=connector_idempotency_key,
                ),
                policy=execution_policy,
                tenant_id=tenant_id,
                connector_id=connector_id,
                operation_id=body.operation_id,
                idempotency_key=scoped_idempotency_key,
                execution_mode="class",
            )
        elif execution_mode == "unsupported_zoho":
            if dry_run:
                result = {
                    "provider_validation_supported": False,
                    "fallback_policy": "simulate",
                    "compliance_verdict": "requires_review",
                    "preview_payload": {
                        "connector_id": connector_id,
                        "endpoint": f"POST /{body.operation_id}",
                        "body": body.params,
                    },
                    "idempotency_key": body.idempotency_key or "",
                    "preview_summary": f"Would execute {connector_id}.{body.operation_id} (Zoho unsupported-class fallback)",
                    "warnings": ["connector_class_not_available"],
                    "would_execute": True,
                }
            else:
                raise RuntimeError(
                    f"Connector '{connector_id}' is connected but does not expose execution through this route yet."
                )
        else:
            if dry_run:
                raise RuntimeError(
                    f"Connector '{connector_id}' does not expose a non-mutating dry_run preview path."
                )
            # Fall back to SDK executor (registered during seed)
            if body.dry_run:
                result = {
                    "provider_validation_supported": False,
                    "fallback_policy": "simulate",
                    "compliance_verdict": "requires_review",
                    "preview_payload": {
                        "endpoint": f"POST /{body.operation_id}",
                        "body": body.params,
                    },
                    "idempotency_key": body.idempotency_key or "",
                    "preview_summary": f"Would execute {connector_id}.{body.operation_id}",
                    "warnings": [],
                    "would_execute": True,
                }
            else:
                result = await execution_envelope.execute(
                    lambda: sdk.execute_operation(connector_id, body.operation_id, body.params, credentials),
                    policy=execution_policy,
                    tenant_id=tenant_id,
                    connector_id=connector_id,
                    operation_id=body.operation_id,
                    idempotency_key=scoped_idempotency_key,
                    execution_mode="sdk",
                )
    except ConnectorBulkheadSaturated as exc:
        logger.warning("execute_connector bulkhead saturated connector=%s op=%s: %s", connector_id, body.operation_id, exc)
        raise HTTPException(
            status_code=status.HTTP_429_TOO_MANY_REQUESTS,
            detail="Connector provider capacity is temporarily saturated",
        ) from exc
    except ConnectorExecutionPolicyError as exc:
        logger.warning("execute_connector policy error connector=%s op=%s: %s", connector_id, body.operation_id, exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    except ConnectorExecutionTimedOut as exc:
        logger.warning("execute_connector timed out connector=%s op=%s: %s", connector_id, body.operation_id, exc)
        raise HTTPException(
            status_code=status.HTTP_504_GATEWAY_TIMEOUT,
            detail="Connector provider deadline exceeded",
        ) from exc
    except ValueError as exc:
        logger.warning("execute_connector bad operation connector=%s op=%s: %s", connector_id, body.operation_id, exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid operation or parameters",
        )
    except RuntimeError as exc:
        logger.warning("execute_connector not implemented connector=%s op=%s: %s", connector_id, body.operation_id, exc)
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="Operation not implemented",
        )
    except Exception as exc:
        logger.error(
            "[%s] Execution failed for '%s.%s': %s",
            tenant_id,
            connector_id,
            body.operation_id,
            exc,
            exc_info=True,
        )
        evidence_event_id = _record_connector_execution(
            tenant_id=tenant_id,
            connector_id=connector_id,
            operation_id=body.operation_id,
            success=False,
            credential_owner=credential_owner,
            error=str(exc),
            execution_mode="preview" if dry_run else execution_mode,
            dry_run=dry_run,
            idempotency_key=scoped_idempotency_key,
        )

        # Failures also feed learning — knowing what doesn't work is as
        # valuable as knowing what does. Prevents repeated bad patterns.
        try:
            from apps.backend.services.skills.promotion_service import DeterministicPromotionService

            det_svc = DeterministicPromotionService()
            det_svc.record_execution(
                skill_id=f"{connector_id}.{body.operation_id}",
                tenant_id=tenant_id,
                steps=[{"tool": connector_id, "operation": body.operation_id, "params": body.params}],
                success=False,
            )
        except Exception:
            pass

        # Fire-and-forget: feed connector health monitor for escalation tracking
        try:
            failure_category = classify_failure(str(exc), tool_id=connector_id)
            get_connector_health_monitor().record_failure(
                tenant_id=tenant_id,
                connector_id=connector_id,
                failure_category=failure_category.value,
                failure_message=str(exc),
            )
        except Exception:
            pass  # Health monitoring is best-effort, never blocks the response

        return {
            "connector_id": connector_id,
            "operation_id": body.operation_id,
            "success": False,
            "result": {},
            "error": str(exc),
            "evidence_event_id": evidence_event_id,
            "evidence_url": _evidence_url(evidence_event_id),
            "dry_run": dry_run,
            "idempotency_key": idempotency_key,
        }

    logger.info("[%s] Execution succeeded for '%s.%s'", tenant_id, connector_id, body.operation_id)
    evidence_event_id = _record_connector_execution(
        tenant_id=tenant_id,
        connector_id=connector_id,
        operation_id=body.operation_id,
        success=True,
        credential_owner=credential_owner,
        result=result,
        execution_mode="preview" if dry_run else execution_mode,
        dry_run=dry_run,
        idempotency_key=scoped_idempotency_key,
    )

    # Feed the learning loop — ALL tool executions compound into learning,
    # not just Zara-routed ones. Direct API calls, CLI calls, and Zara calls
    # all contribute to pattern recognition and skill crystallization.
    try:
        from apps.backend.services.skills.promotion_service import DeterministicPromotionService

        det_svc = DeterministicPromotionService()
        det_svc.record_execution(
            skill_id=f"{connector_id}.{body.operation_id}",
            tenant_id=tenant_id,
            steps=[{"tool": connector_id, "operation": body.operation_id, "params": body.params}],
            success=True,
        )
    except Exception:
        pass  # Learning is best-effort, never blocks the response

    if not dry_run:
        # Fire-and-forget: record live provider success in health monitor.
        try:
            get_connector_health_monitor().record_success(
                tenant_id=tenant_id,
                connector_id=connector_id,
            )
        except Exception:
            pass  # Health monitoring is best-effort, never blocks the response

    return {
        "connector_id": connector_id,
        "operation_id": body.operation_id,
        "success": True,
        "result": result,
        "dry_run": body.dry_run,
        "idempotency_key": body.idempotency_key,
        "error": None,
        "evidence_event_id": evidence_event_id,
        "evidence_url": _evidence_url(evidence_event_id),
        "dry_run": dry_run,
        "idempotency_key": idempotency_key,
    }


@router.get("/{connector_id}/health", response_model=HealthResponse)
async def connector_health(
    connector_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Health-check a connector for the requesting tenant.

    Instantiates the connector with stored credentials and runs its
    health_check method. Requires the connector to be installed.
    """
    mp = _get_marketplace()
    from apps.backend.services.agent_credential_vault import VaultConfigurationError

    zoho_product = _zoho_product_for_connector_id(connector_id)

    if connector_id.startswith("custom-tenant-"):
        _get_standard_registry().ensure_registered(tenant_id, connector_id)

    # Verify connector exists
    try:
        _get_connector_info(connector_id)
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Connector '{connector_id}' not found.",
        )

    if zoho_product is not None:
        connection = _zoho_connection_for_connector(tenant_id, connector_id)
        if connection is None or connection.state != "connected":
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Connector '{connector_id}' is not connected for this organization.",
            )
        return await _run_zoho_connector_health_check(
            tenant_id=tenant_id,
            connector_id=connector_id,
            connection=connection,
        )

    # Verify installed
    try:
        installation = mp._load_installation(tenant_id, connector_id)
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Connector '{connector_id}' is not installed for this organization.",
        )

    try:
        return await _run_connector_health_check(
            tenant_id=tenant_id,
            connector_id=connector_id,
            installation=installation,
        )
    except VaultConfigurationError as exc:
        logger.error("connector_health vault error connector=%s: %s", connector_id, exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Credential vault unavailable",
        ) from exc
