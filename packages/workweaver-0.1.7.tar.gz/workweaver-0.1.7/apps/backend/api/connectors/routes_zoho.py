"""Zoho connector auth routes (start / complete / list / get)."""

from __future__ import annotations

import logging
import os
import time

from fastapi import Depends, HTTPException, Query, status

from apps.backend.api.connectors_contracts import (
    ZohoAuthCallbackResponse,
    ZohoAuthCompleteRequest,
    ZohoAuthStartRequest,
    ZohoAuthStartResponse,
    ZohoConnectionResponse,
)
from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.dependencies.redirect_validation import validate_redirect_url
from apps.backend.services.zoho.connection_manager import zoho_canonical_product_slug

from ._core import (
    _decode_zoho_connector_state,
    _encode_zoho_connector_state,
    _get_zoho_connection_manager,
    _replace_query_param,
    _zoho_callback_uri,
    _zoho_connection_response,
    _zoho_state_b64,
    router,
)

logger = logging.getLogger(__name__)


@router.post("/zoho/auth/start", response_model=ZohoAuthStartResponse)
async def start_zoho_connector_auth(
    body: ZohoAuthStartRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ZohoAuthStartResponse:
    """Start a Workweaver-owned Zoho connector auth flow."""
    # CVE-2026-32025 (#3184): validate redirect_uri against allowlist.
    zoho_redirect_uri = str(body.redirect_uri or _zoho_callback_uri()).strip()
    validated_redirect = validate_redirect_url(zoho_redirect_uri, tenant_id=tenant_id)

    try:
        canonical_product = zoho_canonical_product_slug(body.product_slug)
        oauth_state = _zoho_state_b64(os.urandom(18))
        state = _encode_zoho_connector_state(
            {
                "tenant_id": tenant_id,
                "product_slug": canonical_product,
                "scope": body.scope,
                "agent_id": body.agent_id,
                "dc": body.dc,
                "redirect_uri": validated_redirect,
                "iat": int(time.time()),
                "oauth_state": oauth_state,
            }
        )
        result = _get_zoho_connection_manager().start_connection(
            tenant_id,
            canonical_product,
            redirect_uri=validated_redirect,
            scope=body.scope,
            agent_id=body.agent_id,
            dc_hint=body.dc,
            requested_scopes=body.scopes,
            oauth_state=oauth_state,
            auth_state=state,
            org_id=body.org_id,
            portal_id=body.portal_id,
            instance_id=body.instance_id,
        )
        # Phase 2 of OAuth Unification (2026-04-06): mint a JWT envelope
        # via the unified mint_oauth_state helper. The unified
        # /oauth/callback dispatcher decodes this envelope to route
        # the callback to _complete_zoho_connector_auth without
        # round-tripping through the static dashboard popup HTML page.
        #
        # The csrf_state field carries the inner Zoho oauth_state token
        # so the existing complete_connection() validation against the
        # connection record continues to work without modification.
        from apps.backend.services.oauth_redirect_state import (
            OAuthRedirectError,
            mint_oauth_state,
        )

        try:
            # Build the frontend connection_key. `canonical_product` is always
            # in the form "zoho-<product>" (e.g. "zoho-books"), so we only
            # need to replace the dash with an underscore — NOT re-prefix
            # with "zoho_". The previous version produced "zoho_zoho_books"
            # (double zoho prefix), a cosmetic defect surfaced in the popup
            # state JWT during real-user testing on 2026-04-06.
            zoho_connection_key = canonical_product.replace("-", "_")
            final_state = mint_oauth_state(
                provider="integration",
                flow="integration_zoho",
                return_to_origin="https://workweaver.ai",
                tenant_id=tenant_id,
                connection_id=result["connection"].connection_id,
                connection_key=zoho_connection_key,
                csrf_state=oauth_state,
                ttl_seconds=15 * 60,  # 15 min — Zoho OAuth flows can be slow
            )
        except (OAuthRedirectError, RuntimeError) as exc:
            # If JWT minting fails (e.g. JWT_SECRET missing in test envs),
            # fall back to the legacy Zoho HMAC state so the existing
            # /api/v1/connectors/zoho/oauth/callback path keeps working.
            logger.warning(f"[{tenant_id}] mint_oauth_state failed for Zoho start; using legacy HMAC state: {exc}")
            final_state = _encode_zoho_connector_state(
                {
                    "tenant_id": tenant_id,
                    "connection_id": result["connection"].connection_id,
                    "product_slug": canonical_product,
                    "scope": body.scope,
                    "agent_id": body.agent_id,
                    "dc": result["connection"].dc,
                    "redirect_uri": validated_redirect,
                    "iat": int(time.time()),
                    "oauth_state": oauth_state,
                }
            )
    except ValueError as exc:
        status_code = (
            status.HTTP_503_SERVICE_UNAVAILABLE if "configured" in str(exc).lower() else status.HTTP_400_BAD_REQUEST
        )
        raise HTTPException(status_code=status_code, detail=str(exc)) from exc

    return ZohoAuthStartResponse(
        authorization_url=_replace_query_param(str(result["authorization_url"]), "state", final_state),
        state=final_state,
        requested_scopes=list(result["requested_scopes"]),
        connection=_zoho_connection_response(result["connection"]),
    )


@router.get("/zoho/connections", response_model=list[ZohoConnectionResponse])
async def list_zoho_connections(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[ZohoConnectionResponse]:
    """List canonical Zoho product connections for the tenant."""
    return [_zoho_connection_response(record) for record in _get_zoho_connection_manager().list_connections(tenant_id)]


@router.get("/zoho/connections/{product_slug}", response_model=ZohoConnectionResponse)
async def get_zoho_connection(
    product_slug: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ZohoConnectionResponse:
    """Get the canonical Zoho connection for a single product."""
    record = _get_zoho_connection_manager().get_connection(tenant_id, product_slug)
    if record is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Zoho connection not found")
    return _zoho_connection_response(record)


async def _complete_zoho_connector_auth(
    *,
    tenant_id: str,
    connection_id: str,
    code: str,
    state: str,
    accounts_server: str | None = None,
    location: str | None = None,
    org_id: str | None = None,
    portal_id: str | None = None,
    instance_id: str | None = None,
) -> ZohoAuthCallbackResponse:
    try:
        record = await _get_zoho_connection_manager().complete_connection(
            tenant_id,
            connection_id=connection_id,
            code=code,
            state=state,
            accounts_server=accounts_server,
            location=location,
            org_id=org_id,
            portal_id=portal_id,
            instance_id=instance_id,
        )
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    except ValueError as exc:
        status_code = (
            status.HTTP_503_SERVICE_UNAVAILABLE
            if "temporarily unavailable" in str(exc).lower()
            else status.HTTP_400_BAD_REQUEST
        )
        raise HTTPException(status_code=status_code, detail=str(exc)) from exc

    return ZohoAuthCallbackResponse(success=True, connection=_zoho_connection_response(record))


@router.post("/zoho/auth/complete", response_model=ZohoAuthCallbackResponse)
async def complete_zoho_connector_auth_via_api(
    body: ZohoAuthCompleteRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ZohoAuthCallbackResponse:
    """Complete Zoho auth with an explicit connection id and callback code."""
    return await _complete_zoho_connector_auth(
        tenant_id=tenant_id,
        connection_id=body.connection_id,
        code=body.code,
        state=body.state,
        accounts_server=None,
        location=None,
        org_id=body.org_id,
        portal_id=body.portal_id,
        instance_id=body.instance_id,
    )


@router.get("/zoho/oauth/callback", response_model=ZohoAuthCallbackResponse)
async def complete_zoho_connector_auth(
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    error_description: str | None = None,
    location: str | None = None,
    accounts_server: str | None = Query(None, alias="accounts-server"),
) -> ZohoAuthCallbackResponse:
    """Complete a Zoho connector OAuth flow and persist the canonical connection."""
    if error:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(error_description or error).strip(),
        )
    if not code:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Missing Zoho authorization code")
    if not state:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Missing Zoho connector state")

    try:
        state_payload = _decode_zoho_connector_state(state)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    connection_id = str(state_payload.get("connection_id") or "").strip()
    record = (
        _get_zoho_connection_manager().find_connection_by_id(state_payload["tenant_id"], connection_id)
        if connection_id
        else None
    )
    if record is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Zoho connection not found")

    return await _complete_zoho_connector_auth(
        tenant_id=state_payload["tenant_id"],
        connection_id=record.connection_id,
        code=code,
        state=str(state_payload.get("oauth_state") or ""),
        accounts_server=accounts_server,
        location=location,
    )
