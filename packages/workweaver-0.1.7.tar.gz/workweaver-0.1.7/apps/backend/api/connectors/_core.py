"""Connector Execution API — shared state, registry, router, and helpers.

Exposes the Integration Marketplace and ConnectorSDK through a REST API so that
tenants can discover connectors, install them with credentials, execute operations,
and verify connector health.

Prefix: /api/v1/connectors
Tags: connectors

Architecture:
    Request -> tenant extraction -> IntegrationMarketplace / ConnectorSDK -> Response

DynamoDB schema (installations):
    PK=TENANT#{tenant_id}  SK=CONNECTOR_INSTALL#{connector_id}

This module holds the shared `router` plus the private helpers used by the
route modules in this package. Route handlers live in dedicated submodules
(`routes_catalog`, `routes_connect_session`, `routes_zoho`, `routes_standards`,
`routes_lifecycle`, `routes_twilio` moved to `services/channels/twilio/routes.py`)
and are imported by `__init__.py` so their decorators attach to `router`.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import json
import logging
import os
import time
from datetime import datetime, UTC
from typing import Any
from urllib.parse import parse_qsl, urlencode, urlparse, urlunparse

from fastapi import APIRouter

from apps.backend.api.connectors_contracts import (
    ConnectionCenterItem,
    ConnectionCenterResponse,
    ZohoConnectionResponse,
)
from apps.backend.config.secrets import get_zoho_client_secret
from apps.backend.integrations.integration_catalog import (
    IntegrationDefinition,
    get_integrations_registry as _get_integrations_registry,
)
from apps.backend.services.connectors.base import (
    ConnectorBase,
    ConnectorConfig,
    ProviderState,
)
from apps.backend.services.connectors.marketplace import IntegrationMarketplace
from apps.backend.services.connectors.shared_connector_service import get_shared_connector_service
from apps.backend.services.connectors.standard_connector_registry import (
    get_standard_connector_registry,
    is_custom_connector_id,
)
from apps.backend.services.evidence_ledger import (
    get_evidence_ledger_service,
    record_connector_execution_evidence,
)
from apps.backend.services.integration_health_store import (
    IntegrationHealthStore,
    IntegrationHealthStoreError,
)
from apps.backend.services.integration_manager import IntegrationManager
from apps.backend.services.zoho.connection_manager import (
    ZohoConnectionManager,
    get_zoho_connection_manager,
)
from apps.backend.services.zoho.connection_store import ZohoConnectionRecord
from apps.backend.services.zoho.product_registry import get_zoho_product, list_zoho_products
from apps.backend.providers.base import get_deployment_profile

logger = logging.getLogger(__name__)

# Preserve the module patch seam used by connector contract tests.
get_integrations_registry = _get_integrations_registry

# ---------------------------------------------------------------------------
# Connector class registry
# ---------------------------------------------------------------------------
# Maps connector IDs that have a concrete ConnectorBase implementation to
# their class. Connectors without a class entry here can still be browsed
# and installed, but execution falls back to the SDK executor (if registered).

_CONNECTOR_CLASSES: dict[str, type[ConnectorBase]] = {}
_CONNECTOR_BOOTSTRAP_ERRORS: dict[str, str] = {}


def _load_connector_classes() -> None:
    """Lazily populate _CONNECTOR_CLASSES from known connector modules."""
    if _CONNECTOR_CLASSES or _CONNECTOR_BOOTSTRAP_ERRORS:
        return

    _CONNECTOR_REGISTRY: list[tuple[str, str, str]] = [
        ("hubspot-crm", "apps.backend.services.connectors.hubspot_connector", "HubSpotConnector"),
        ("salesforce-crm", "apps.backend.services.connectors.salesforce_connector", "SalesforceConnector"),
        ("github", "apps.backend.services.connectors.github_connector", "GitHubConnector"),
        ("jira", "apps.backend.services.connectors.jira_connector", "JIRAConnector"),
        ("linear", "apps.backend.services.connectors.linear_connector", "LinearConnector"),
        ("gmail", "apps.backend.services.connectors.gmail_connector", "GmailConnector"),
        ("slack", "apps.backend.services.connectors.slack_connector", "SlackConnector"),
        ("google-drive", "apps.backend.services.connectors.google_drive_connector", "GoogleDriveConnector"),
        ("notion", "apps.backend.services.connectors.notion_connector", "NotionConnector"),
        ("zoho-crm", "apps.backend.services.zoho.connectors.crm_connector", "ZohoCRMConnector"),
        ("google-workspace", "apps.backend.services.connectors.google_workspace_connector", "GoogleWorkspaceConnector"),
        ("microsoft-365", "apps.backend.services.connectors.microsoft_365_connector", "Microsoft365Connector"),
        # #1155 (2026-04-14): OneDriveConnector removed. Files.ReadWrite was
        # dropped from the Microsoft 365 Entra scopes in #821 (2026-04-09) and
        # never restored (#1155), so the standalone OneDrive connector class shipped
        # in #776 could never authenticate — UI falsely advertised "OneDrive (#1155)
        # connected" while every operation failed. Entire class deleted;
        # legacy tenant rows with provider=onedrive (#821) become soft-invisible via
        # _CONNECTOR_CLASSES.get() lookups.
        ("teams", "apps.backend.services.connectors.teams_connector", "TeamsConnector"),
        ("twilio", "apps.backend.services.channels.twilio.connector", "TwilioConnector"),
        ("whatsapp-business", "apps.backend.services.connectors.whatsapp_business_connector", "WhatsAppBusinessConnector"),
        ("stripe", "apps.backend.services.connectors.stripe_connector", "StripeConnector"),
        ("google-calendar", "apps.backend.services.connectors.google_calendar_connector", "GoogleCalendarConnector"),
        ("google-docs", "apps.backend.services.connectors.google_docs_connector", "GoogleDocsConnector"),
        ("google-sheets", "apps.backend.services.connectors.google_sheets_connector", "GoogleSheetsConnector"),
        ("google-slides", "apps.backend.services.connectors.google_slides_connector", "GoogleSlidesConnector"),
        ("outlook-calendar", "apps.backend.services.connectors.outlook_calendar_connector", "OutlookCalendarConnector"),
        (
            "google-search-console",
            "apps.backend.services.connectors.google_search_console_connector",
            "GoogleSearchConsoleConnector",
        ),
        ("zoho-books", "apps.backend.services.zoho.connectors.books_connector", "ZohoBooksConnector"),
        ("zoho-calendar", "apps.backend.services.zoho.connectors.calendar_connector", "ZohoCalendarConnector"),
        ("zoho-mail", "apps.backend.services.zoho.connectors.mail_connector", "ZohoMailConnector"),
        ("zoho-analytics", "apps.backend.services.zoho.connectors.analytics_connector", "ZohoAnalyticsConnector"),
        # Ghost connector removed — infra deleted in 3c2f8a57, no server exists.
        ("web-search", "apps.backend.services.connectors.web_search_connector", "WebSearchConnector"),
        ("razorpay", "apps.backend.services.connectors.razorpay_connector", "RazorpayConnector"),
        ("zoho-payroll", "apps.backend.services.zoho.connectors.payroll_connector", "ZohoPayrollConnector"),
        ("zoho-inventory", "apps.backend.services.zoho.connectors.inventory_connector", "ZohoInventoryConnector"),
        ("zoho-people", "apps.backend.services.zoho.connectors.people_connector", "ZohoPeopleConnector"),
    ]

    import importlib

    for key, module_path, class_name in _CONNECTOR_REGISTRY:
        try:
            module = importlib.import_module(module_path)
            _CONNECTOR_CLASSES[key] = getattr(module, class_name)
        except ImportError:  # pragma: no cover
            # Fallback: try relative path (legacy layout)
            fallback = module_path.replace("apps.backend.services.", "services.")
            try:
                module = importlib.import_module(fallback)
                _CONNECTOR_CLASSES[key] = getattr(module, class_name)
            except ImportError:
                pass
            except Exception as exc:
                logger.warning("Connector bootstrap failed for %s via legacy path: %s", key, exc, exc_info=True)
                _CONNECTOR_BOOTSTRAP_ERRORS[key] = str(exc) or exc.__class__.__name__
        except Exception as exc:
            logger.warning("Connector bootstrap failed for %s: %s", key, exc, exc_info=True)
            _CONNECTOR_BOOTSTRAP_ERRORS[key] = str(exc) or exc.__class__.__name__


def _connector_bootstrap_failure(connector_id: str) -> str | None:
    try:
        _load_connector_classes()
    except Exception as exc:  # pragma: no cover - defensive fallback
        return str(exc) or exc.__class__.__name__
    return _CONNECTOR_BOOTSTRAP_ERRORS.get(connector_id)


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

router = APIRouter(prefix="/api/v1/connectors", tags=["connectors"])

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_marketplace() -> IntegrationMarketplace:
    """Return the seeded marketplace singleton (seeds builtin connectors on first call)."""
    from apps.backend.services.connectors.marketplace import get_marketplace

    return get_marketplace()


def _get_health_store() -> IntegrationHealthStore:
    return IntegrationHealthStore()


def _get_integration_manager() -> IntegrationManager:
    return IntegrationManager()


def _get_standard_registry():
    return get_standard_connector_registry()


def _get_zoho_connection_manager() -> ZohoConnectionManager:
    return get_zoho_connection_manager()


def _safe_list_zoho_connections(tenant_id: str, *, surface: str) -> list[ZohoConnectionRecord]:
    try:
        return _get_zoho_connection_manager().list_connections(tenant_id)
    except Exception as exc:
        logger.warning("[%s] Unable to load Zoho %s state: %s", tenant_id, surface, exc, exc_info=True)
        return []


def _zoho_callback_uri() -> str:
    """Return the OAuth callback URL Workweaver registers with Zoho.

    Phase 2 of OAuth Unification (2026-04-06) routes Zoho through the
    single canonical /oauth/callback dispatcher. The dispatcher decodes
    the JWT envelope minted in start_zoho_connector_auth (with
    flow=integration_zoho), extracts tenant_id + connection_id + the
    inner Zoho CSRF token, and forwards to _complete_zoho_connector_auth
    internally — then renders the popup-callback HTML response.

    Set OAUTH_DISPATCHER_DISABLED=1 to fall back to the legacy
    /api/v1/connectors/zoho/oauth/callback URL during a rollback. The
    legacy route is still mounted as a backwards-compat shim, so flipping
    the flag is a clean revert.
    """
    public_base = (os.environ.get("PUBLIC_BASE_URL") or "https://api.workweaver.ai").rstrip("/")
    if os.environ.get("OAUTH_DISPATCHER_DISABLED", "").strip().lower() in {"1", "true", "yes"}:
        return f"{public_base}/api/v1/connectors/zoho/oauth/callback"
    return f"{public_base}/oauth/callback"


def _zoho_state_secret() -> str:
    secret = (
        os.environ.get("ZOHO_OAUTH_STATE_SECRET")
        or os.environ.get("WORKWEAVER_VAULT_SECRET")
        or os.environ.get("WORKSPACE_API_KEY_SECRET")
        or (get_zoho_client_secret() or "")
        or ""
    ).strip()
    if not secret:
        raise ValueError("Zoho connector auth state secret not configured")
    return secret


def _zoho_state_b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode("utf-8").rstrip("=")


def _zoho_state_decode(data: str) -> bytes:
    padded = data + "=" * (-len(data) % 4)
    return base64.urlsafe_b64decode(padded.encode("utf-8"))


def _encode_zoho_connector_state(payload: dict[str, Any]) -> str:
    secret = _zoho_state_secret().encode("utf-8")
    encoded = _zoho_state_b64(json.dumps(payload, separators=(",", ":")).encode("utf-8"))
    signature = hmac.new(secret, encoded.encode("utf-8"), hashlib.sha256).digest()
    return f"{encoded}.{_zoho_state_b64(signature)}"


def _decode_zoho_connector_state(token: str) -> dict[str, Any]:
    raw = str(token or "").strip()
    if "." not in raw:
        raise ValueError("Invalid Zoho connector state")
    encoded, signature = raw.split(".", 1)
    expected = _zoho_state_b64(
        hmac.new(_zoho_state_secret().encode("utf-8"), encoded.encode("utf-8"), hashlib.sha256).digest()
    )
    if not hmac.compare_digest(signature, expected):
        raise ValueError("Invalid Zoho connector state signature")
    payload = json.loads(_zoho_state_decode(encoded).decode("utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Invalid Zoho connector state payload")
    issued_at = int(payload.get("iat") or 0)
    if issued_at <= 0 or int(time.time()) - issued_at > 15 * 60:
        raise ValueError("Zoho connector state expired")
    return payload


def _replace_query_param(url: str, key: str, value: str) -> str:
    parsed = urlparse(url)
    params = [(k, v) for k, v in parse_qsl(parsed.query, keep_blank_values=True) if k != key]
    params.append((key, value))
    return urlunparse(parsed._replace(query=urlencode(params)))


def _zoho_connection_response(record: ZohoConnectionRecord) -> ZohoConnectionResponse:
    product = get_zoho_product(record.product_slug)
    return ZohoConnectionResponse(
        connection_id=record.connection_id,
        tenant_id=record.tenant_id,
        display_name=product.display_name,
        product_slug=record.product_slug,
        scope=record.scope,
        agent_id=record.agent_id,
        dc=record.dc,
        accounts_base_url=record.accounts_base_url,
        api_base_url=record.api_base_url,
        state=record.state,
        granted_scopes=list(record.granted_scopes),
        requested_scopes=list(record.requested_scopes),
        credential_owner=record.credential_owner_agent_id,
        org_id=record.org_id,
        portal_id=record.portal_id,
        instance_id=record.instance_id,
        last_error=record.last_error,
        health_metadata=dict(record.health_metadata),
        created_at=record.created_at,
        updated_at=record.updated_at,
    )


def _evidence_url(evidence_id: str | None) -> str | None:
    if not evidence_id:
        return None
    return f"/api/v1/evidence/{evidence_id}"


def _health_alert_states() -> set[str]:
    return {
        ProviderState.ERROR.value,
        ProviderState.MISSING_CREDENTIALS.value,
        ProviderState.AUTH_EXPIRED.value,
        ProviderState.DISABLED.value,
    }


def _build_health_snapshot(
    *,
    tenant_id: str,
    connector_id: str,
    provider: str,
    state: str,
    message: str,
    latency_ms: float,
    evidence_event_id: str | None,
) -> dict[str, Any]:
    return {
        "tenant_id": tenant_id,
        "connector_id": connector_id,
        "provider": provider,
        "state": state,
        "message": message,
        "latency_ms": float(latency_ms or 0.0),
        "alert_open": state not in {"connected", "configured"},
        "last_checked_at": datetime.now(UTC).isoformat(),
        "evidence_event_id": evidence_event_id,
    }


def _clean_connector_key(value: str | None) -> str:
    """Normalise a connector identifier for cross-source comparison.

    Frontend convention is underscore-separated (e.g. "zoho_crm", "google_drive")
    because that matches DOM data-key convention. Backend product registry stores
    connector_id in dash-separated form (e.g. "zoho-crm", "google-drive") because
    that's the canonical product_slug convention. Without normalising between
    the two, _zoho_product_for_connector_id() fails to match Zoho DELETE requests
    from the frontend — the root cause of the "Connection not found" bug caught
    in real-user testing on 2026-04-07.

    Normalise BOTH dashes and spaces to underscores so the comparison is stable
    regardless of which representation the caller used.
    """
    return str(value or "").strip().lower().replace(" ", "_").replace("-", "_")


_INTEGRATION_TO_CONNECTOR_ID: dict[str, str | None] = {
    "HubSpot": "hubspot-crm",
    "Salesforce": "salesforce-crm",
    "Slack": "slack",
    "Google Drive": "google-drive",
    "Google Docs": "google-docs",
    "Google Sheets": "google-sheets",
    "Google Slides": "google-slides",
    "Twilio WhatsApp": "twilio",
    "Stripe": "stripe",
}

_SURFACED_CONNECTOR_SPECS: list[dict[str, Any]] = [
    {
        "key": "gmail",
        "display_name": "Gmail",
        "integration_name": "Gmail",
        "connector_id": None,
        "verified_path": True,
        "surface_rank": 0,
    },
    {
        "key": "google_calendar",
        "display_name": "Google Calendar",
        "integration_name": "Google Calendar",
        "connector_id": None,
        "verified_path": True,
        "surface_rank": 1,
    },
    {
        "key": "slack",
        "display_name": "Slack",
        "integration_name": "Slack",
        "connector_id": "slack",
        "verified_path": True,
        "surface_rank": 2,
    },
    {
        "key": "hubspot",
        "display_name": "HubSpot",
        "integration_name": "HubSpot",
        "connector_id": "hubspot-crm",
        "verified_path": False,
        "surface_rank": 3,
    },
    {
        "key": "whatsapp",
        "display_name": "WhatsApp",
        "integration_name": "Twilio WhatsApp",
        "connector_id": "twilio",
        "verified_path": False,
        "surface_rank": 4,
    },
    {
        "key": "telegram",
        "display_name": "Telegram",
        "description": "Demand-based connector. Enable only when the workflow justifies a real Telegram path.",
        "category": "communication",
        "auth_type": "demand_based",
        "demand_based": True,
        "verified_path": False,
        "surface_rank": 5,
        "icon_url": "https://cdn.workweaver.ai/integrations/telegram.svg",
        "documentation_url": "https://docs.workweaver.ai/integrations/telegram",
    },
    {
        # GitHub connector is fully implemented in
        # apps/backend/services/connectors/github_connector.py with 6 ops
        # (list_repos, create_issue, list_issues, etc.). It was hidden
        # from the surfaced list — now exposed (Codex Q5: cheapest
        # immediate win). 2026-04-08.
        "key": "github",
        "display_name": "GitHub",
        "description": "Code repos, issues, pull requests.",
        "category": "developer",
        "auth_type": "token",
        "integration_name": "GitHub",
        "connector_id": "github",
        "verified_path": True,
        "surface_rank": 6,
    },
    # Google Docs / Sheets / Slides shipped #775 (2026-04-08).
    # All three ride the same Google OAuth client and go through the
    # legacy OAuth path (see _PROVIDERS_VIA_LEGACY_OAUTH above).
    # Google Meet is intentionally NOT a separate spec — it's covered
    # by the existing google_calendar entry via create_meeting().
    {
        "key": "google_docs",
        "display_name": "Google Docs",
        "description": "Create, edit, and export Google Docs.",
        "category": "productivity",
        "auth_type": "oauth2",
        "integration_name": "Google Docs",
        "connector_id": "google-docs",
        "verified_path": True,
        "surface_rank": 7,
    },
    {
        "key": "google_sheets",
        "display_name": "Google Sheets",
        "description": "Create spreadsheets, read and write ranges, append rows.",
        "category": "productivity",
        "auth_type": "oauth2",
        "integration_name": "Google Sheets",
        "connector_id": "google-sheets",
        "verified_path": True,
        "surface_rank": 8,
    },
    {
        "key": "google_slides",
        "display_name": "Google Slides",
        "description": "Build and edit Google Slides presentations.",
        "category": "productivity",
        "auth_type": "oauth2",
        "integration_name": "Google Slides",
        "connector_id": "google-slides",
        "verified_path": True,
        "surface_rank": 9,
    },
    # Microsoft Teams shipped #776 (2026-04-10). Uses the Microsoft Entra
    # OAuth client with OnlineMeetings.ReadWrite. Personal Microsoft
    # accounts (live.com) cannot create Teams meetings.
    # #1155 (2026-04-14): OneDrive (#1155) surface spec removed. The Entra client
    # no longer requests Files.ReadWrite (dropped in #821), so advertising
    # OneDrive (#821) as a verified connector was a UI falsehood — every
    # operation would 401/403 at runtime. Gap-closing decision: delete,
    # not restore the scope (compliance).
    {
        "key": "teams",
        "display_name": "Microsoft Teams",
        "description": "Create meetings, send chat messages. Requires work/school account.",
        "category": "communication",
        "auth_type": "oauth2",
        "integration_name": "Microsoft Teams",
        "connector_id": "teams",
        "verified_path": True,
        "surface_rank": 11,
    },
    # Google Chat shipped #3203 via PlatformAdapter Protocol (no Pub/Sub daemon).
    # Inbound: webhook (X-Goog-Chat-Token verification). Outbound: Chat REST API.
    # Surfaces: REST webhook, CLI (ww connector status), MCP (ww.connector.status),
    # Card v2 renderer, ComplianceGuard preflight, Decision Trace per send/receive.
    {
        "key": "google_chat",
        "display_name": "Google Chat",
        "description": "Send and receive messages in Google Chat spaces via webhook.",
        "category": "communication",
        "auth_type": "service_account",
        "integration_name": "Google Chat",
        "connector_id": "google-chat",
        "verified_path": True,
        "surface_rank": 12,
    },
]

_SURFACED_SPEC_BY_INTEGRATION = {
    str(spec.get("integration_name")): spec for spec in _SURFACED_CONNECTOR_SPECS if spec.get("integration_name")
}

_OMIT_MARKETPLACE_IDS = {
    "google-workspace",
    "microsoft-365",
}


def _health_to_state(snapshot: dict[str, Any] | None) -> str | None:
    if not snapshot:
        return None
    state = str(snapshot.get("state") or "")
    if state in _health_alert_states():
        return "degraded"
    if state in {ProviderState.CONNECTED.value, ProviderState.CONFIGURED.value}:
        return "verified"
    return None


def _connector_status_metadata() -> tuple[list[str], list[str]]:
    try:
        from apps.backend.services.capability_registry import load_capability_registry

        row = load_capability_registry().find("connector.status")
    except Exception:
        return ["connector.status"], ["ww.connector.status"]
    capability_ids = [row.capability_id]
    tool_names = [tool for tool in row.tool_ids if tool]
    if not tool_names and row.mcp_tool:
        tool_names = [row.mcp_tool]
    return capability_ids, tool_names


def _status_setup_command(connector_id: str, auth_type: str, *, installed: bool, status: str) -> str:
    if installed and status == "functional":
        return f"ww connector health {connector_id}"
    if str(auth_type or "").lower() == "oauth2":
        return f"ww connector oauth {connector_id}"
    return f"ww connector install {connector_id}"


def _availability_status_for(
    *,
    connector_id: str,
    display_name: str,
    auth_type: str,
    installed: bool,
    health_snapshot: dict[str, Any] | None,
) -> dict[str, Any]:
    state = str((health_snapshot or {}).get("state") or "")
    message = str((health_snapshot or {}).get("message") or "").strip()
    current_health_snapshot = health_snapshot if installed else None
    if installed and state in _health_alert_states():
        status = "degraded"
        reason = message or f"{display_name} has a blocking health state: {state}."
    elif installed:
        status = "functional"
        reason = "Connector is installed and no blocking health state is recorded."
    else:
        status = "unavailable"
        if str(auth_type or "").lower() == "oauth2":
            reason = "Grant permission to verify the connector."
        else:
            reason = "Install the connector credentials before using connector-backed capabilities."
    return {
        "status": status,
        "reason": reason,
        "setup_command": _status_setup_command(
            connector_id,
            auth_type,
            installed=installed,
            status=status,
        ),
        "last_checked_at": (current_health_snapshot or {}).get("last_checked_at"),
        "evidence_event_id": (current_health_snapshot or {}).get("evidence_event_id"),
        "evidence_url": _evidence_url((current_health_snapshot or {}).get("evidence_event_id")),
    }


def _record_connector_status_trace(
    *,
    tenant_id: str,
    summary: dict[str, int],
    profile: str,
) -> str | None:
    created_at = datetime.now(UTC).isoformat()
    idempotency_seed = json.dumps(
        {
            "tenant_id": tenant_id,
            "operation": "connector.status",
            "profile": profile,
            "summary": dict(summary),
        },
        sort_keys=True,
        separators=(",", ":"),
    )
    idempotency_digest = hashlib.sha256(idempotency_seed.encode()).hexdigest()[:16]
    trace_payload = {
        "item_type": "connector_availability_map",
        "workspace_id": tenant_id,
        "subject_id": "connector.status",
        "actor_chain": ["tenant:connector_status", "tool:ww.connector.status"],
        "operation": "connector.status",
        "side_effect_class": "read_only",
        "policy_verdict": "n_a",
        "evidence_refs": [],
        "outcome": "success",
        "idempotency_key": f"{tenant_id}:connector.status:{idempotency_digest}",
        "created_at": created_at,
        "profile": profile,
        "summary": dict(summary),
    }
    try:
        record = get_evidence_ledger_service().ingest(
            tenant_id=tenant_id,
            event_type="evidence:connector_status_read",
            data=trace_payload,
            actor_path="tenant.connector_status",
            artifact_payload=trace_payload,
        )
    except Exception as exc:
        logger.warning("[%s] Connector status trace unavailable: %s", tenant_id, exc, exc_info=True)
        return None
    return str(record.get("evidence_id") or "")


def _custom_connector_summary_from_definition(definition: dict[str, Any]) -> dict[str, Any] | None:
    connector_id = str(definition.get("connector_id") or definition.get("id") or "").strip()
    if not connector_id or not is_custom_connector_id(connector_id):
        return None
    return {
        "id": connector_id,
        "name": str(definition.get("name") or connector_id),
        "description": str(definition.get("description") or "Tenant-defined connector."),
        "category": str(definition.get("category") or "operations"),
        "auth_type": str(definition.get("auth_type") or "api_key"),
        "icon_url": str(definition.get("icon_url") or ""),
        "documentation_url": str(definition.get("documentation_url") or ""),
        "is_builtin": False,
        "coming_soon": False,
        "operation_count": int(definition.get("operation_count") or 0),
    }


def _tenant_custom_connector_summaries(
    tenant_id: str,
    *,
    installed_by_connector_id: dict[str, dict[str, Any]],
) -> list[dict[str, Any]]:
    custom_by_key: dict[str, dict[str, Any]] = {}
    try:
        registry = _get_standard_registry()
        registry.ensure_registered(tenant_id)
        for definition in registry.list_definitions(tenant_id):
            summary = _custom_connector_summary_from_definition(definition)
            if summary is not None:
                custom_by_key[_clean_connector_key(summary["id"])] = summary
    except Exception as exc:
        logger.warning("[%s] Connector status custom definitions unavailable: %s", tenant_id, exc, exc_info=True)

    for installed in installed_by_connector_id.values():
        connector_id = str(installed.get("id") or installed.get("connector_id") or "").strip()
        if not connector_id or not is_custom_connector_id(connector_id):
            continue
        custom_by_key.setdefault(
            _clean_connector_key(connector_id),
            {
                "id": connector_id,
                "name": str(installed.get("name") or connector_id),
                "description": str(installed.get("description") or "Tenant-defined connector."),
                "category": str(installed.get("category") or "operations"),
                "auth_type": str(installed.get("auth_type") or "api_key"),
                "icon_url": str(installed.get("icon_url") or ""),
                "documentation_url": str(installed.get("documentation_url") or ""),
                "is_builtin": False,
                "coming_soon": False,
                "operation_count": int(installed.get("operation_count") or 0),
            },
        )

    return sorted(
        custom_by_key.values(),
        key=lambda item: str(item.get("name") or item.get("id") or "").lower(),
    )


def _connector_availability_map(tenant_id: str) -> dict[str, Any]:
    capability_ids, tool_names = _connector_status_metadata()
    profile = get_deployment_profile().value
    try:
        health_snapshots = _get_health_store().list_snapshots(tenant_id)
    except Exception as exc:
        logger.warning("[%s] Connector status health snapshots unavailable: %s", tenant_id, exc, exc_info=True)
        health_snapshots = []
    health_by_connector_id = {
        _clean_connector_key(snapshot.get("connector_id")): snapshot
        for snapshot in health_snapshots
        if isinstance(snapshot, dict)
    }

    marketplace = _get_marketplace()
    installed_by_connector_id = {
        _clean_connector_key(item.get("id")): item
        for item in marketplace.get_installed(tenant_id)
        if isinstance(item, dict)
    }
    for connection in _safe_list_zoho_connections(tenant_id, surface="connector-status"):
        if connection.state != "connected":
            continue
        product = get_zoho_product(connection.product_slug)
        if not product.catalog_visible or not product.connector_id:
            continue
        installed_by_connector_id[_clean_connector_key(product.connector_id)] = _zoho_installed_connector_payload(
            connection
        )

    items: list[dict[str, Any]] = []
    seen: set[str] = set()
    connector_summaries = [
        *_catalog_connector_summaries(),
        *_tenant_custom_connector_summaries(
            tenant_id,
            installed_by_connector_id=installed_by_connector_id,
        ),
    ]
    for connector in connector_summaries:
        connector_id = str(connector.get("id") or "").strip()
        if not connector_id:
            continue
        normalized = _clean_connector_key(connector_id)
        if normalized in seen:
            continue
        seen.add(normalized)
        installed = normalized in installed_by_connector_id
        display_name = str(connector.get("name") or connector_id)
        auth_type = str(connector.get("auth_type") or "")
        status_fields = _availability_status_for(
            connector_id=connector_id,
            display_name=display_name,
            auth_type=auth_type,
            installed=installed,
            health_snapshot=health_by_connector_id.get(normalized),
        )
        items.append(
            {
                "connector_id": connector_id,
                "display_name": display_name,
                "capability_ids": list(capability_ids),
                "tool_names": list(tool_names),
                "profile_support": {"self_host": True, "managed": True},
                **status_fields,
            }
        )

    items.sort(key=lambda item: (item["status"] != "functional", item["display_name"].lower()))
    summary = {
        "total": len(items),
        "functional": sum(1 for item in items if item["status"] == "functional"),
        "degraded": sum(1 for item in items if item["status"] == "degraded"),
        "unavailable": sum(1 for item in items if item["status"] == "unavailable"),
    }
    return {
        "items": items,
        "summary": summary,
        "profile": profile,
        "generated_at": datetime.now(UTC).isoformat(),
        "decision_trace_id": _record_connector_status_trace(
            tenant_id=tenant_id,
            summary=summary,
            profile=profile,
        ),
    }


def _integration_metadata(integration: IntegrationDefinition) -> dict[str, Any]:
    return dict(getattr(integration, "metadata", {}) or {})


def _connector_id_for_integration(integration: IntegrationDefinition) -> str | None:
    metadata = _integration_metadata(integration)
    connector_id = str(metadata.get("connector_id") or "").strip()
    if connector_id:
        return connector_id
    return _INTEGRATION_TO_CONNECTOR_ID.get(integration.name)


def _list_zoho_catalog_products() -> list[Any]:
    return [product for product in list_zoho_products() if product.catalog_visible and product.connector_id]


def _zoho_product_for_connector_id(connector_id: str):
    normalized = _clean_connector_key(connector_id)
    if not normalized:
        return None
    for product in _list_zoho_catalog_products():
        if _clean_connector_key(product.connector_id) == normalized:
            return product
    return None


def _zoho_connector_exposes_execution(product: Any) -> bool:
    connector_id = _clean_connector_key(getattr(product, "connector_id", ""))
    if not connector_id:
        return False
    _load_connector_classes()
    # _CONNECTOR_CLASSES keys are canonical dash-form ("zoho-crm"), but
    # _clean_connector_key normalises dashes to underscores so the comparison
    # must be symmetric. Without this, every zoho product falls through to
    # empty operations on /api/v1/connectors/{id}, /popular, and /execute —
    # a user-facing production regression.
    return connector_id in {_clean_connector_key(key) for key in _CONNECTOR_CLASSES}


def _zoho_operation_ids(product: Any) -> list[str]:
    if not _zoho_connector_exposes_execution(product):
        return []
    return [
        str(operation).strip()
        for operation in (product.catalog_capabilities or product.capabilities)
        if str(operation).strip()
    ]


def _zoho_connector_summary(product: Any) -> dict[str, Any]:
    return {
        "id": str(product.connector_id or product.product_slug),
        "name": product.display_name,
        "description": product.description,
        "category": product.category,
        "auth_type": product.auth_type,
        "icon_url": "",
        "documentation_url": "",
        "is_builtin": True,
        "coming_soon": bool(product.coming_soon),
        "operation_count": len(_zoho_operation_ids(product)),
    }


def _zoho_connector_detail(product: Any) -> dict[str, Any]:
    operations = _zoho_operation_ids(product)
    return {
        **_zoho_connector_summary(product),
        "version": "1.0.0",
        "author": "Workweaver",
        "supported_operations": operations,
        "auth_fields": [],
        "operations": [
            {
                "id": operation,
                "name": operation.replace("_", " ").title(),
                "description": f"{product.display_name} {operation.replace('_', ' ')}",
                "input_schema": {"type": "object"},
                "output_schema": {"type": "object"},
            }
            for operation in operations
        ],
    }


def _get_connector_info(connector_id: str) -> dict[str, Any]:
    marketplace = _get_marketplace()
    try:
        return marketplace.get_connector(connector_id)
    except KeyError:
        product = _zoho_product_for_connector_id(connector_id)
        if product is None:
            raise
        return _zoho_connector_detail(product)


def _zoho_connection_for_connector(tenant_id: str, connector_id: str) -> ZohoConnectionRecord | None:
    product = _zoho_product_for_connector_id(connector_id)
    if product is None:
        return None
    return _get_zoho_connection_manager().get_connection(tenant_id, product.product_slug)


def _zoho_credential_owner(connection: ZohoConnectionRecord | None) -> str:
    return str(getattr(connection, "credential_owner_agent_id", "") or "shared")


def _zoho_installed_connector_payload(connection: ZohoConnectionRecord) -> dict[str, Any]:
    product = get_zoho_product(connection.product_slug)
    return {
        **_zoho_connector_summary(product),
        "install_id": connection.connection_id,
        "installed_at": str(connection.created_at or ""),
        "updated_at": str(connection.updated_at or ""),
    }


def _list_marketplace_catalog_items() -> list[dict[str, Any]]:
    marketplace = _get_marketplace()
    items: list[dict[str, Any]] = []
    page = 1
    pages = 1

    while page <= pages:
        payload = marketplace.list_connectors(page=page, page_size=100)
        items.extend(dict(item) for item in (payload.get("items") or []))
        pages = max(int(payload.get("pages") or 1), 1)
        page += 1

    return items


def _catalog_connector_summaries() -> list[dict[str, Any]]:
    combined = {_clean_connector_key(item.get("id")): item for item in _list_marketplace_catalog_items()}
    for product in _list_zoho_catalog_products():
        combined.setdefault(_clean_connector_key(product.connector_id), _zoho_connector_summary(product))
    return sorted(
        combined.values(),
        key=lambda item: (str(item.get("category") or ""), str(item.get("name") or item.get("id") or "").lower()),
    )


def _build_connection_center_item(
    *,
    key: str,
    display_name: str,
    description: str,
    category: str,
    auth_type: str,
    icon_url: str = "",
    documentation_url: str = "",
    connector_id: str | None = None,
    integration_name: str | None = None,
    verified_path: bool = False,
    surfaced: bool = False,
    surface_rank: int = 999,
    demand_based: bool = False,
    coming_soon: bool = False,
    catalog_only: bool = False,
    connected_connection: Any = None,
    pending_connection: Any = None,
    installed_connector: dict[str, Any] | None = None,
    health_snapshot: dict[str, Any] | None = None,
    supported_operations: list[str] | None = None,
) -> ConnectionCenterItem:
    return get_shared_connector_service().build_connection_center_item(
        key=key,
        display_name=display_name,
        description=description,
        category=category,
        auth_type=auth_type,
        icon_url=icon_url,
        documentation_url=documentation_url,
        connector_id=connector_id,
        integration_name=integration_name,
        verified_path=verified_path,
        surfaced=surfaced,
        surface_rank=surface_rank,
        demand_based=demand_based,
        coming_soon=coming_soon,
        catalog_only=catalog_only,
        connected_connection=connected_connection,
        pending_connection=pending_connection,
        installed_connector=installed_connector,
        health_snapshot=health_snapshot,
        supported_operations=supported_operations,
    )


async def _build_connection_center_response(tenant_id: str) -> ConnectionCenterResponse:
    return await get_shared_connector_service().build_connection_center_response(tenant_id)


def _record_health_alert(
    *,
    tenant_id: str,
    connector_id: str,
    provider: str,
    state: str,
    message: str,
    latency_ms: float,
) -> str | None:
    if state not in _health_alert_states():
        return None
    record = get_evidence_ledger_service().ingest(
        tenant_id=tenant_id,
        event_type="evidence:item",
        data={
            "item_type": "connector_health_alert",
            "domain": "integrations",
            "connector_id": connector_id,
            "provider": provider,
            "state": state,
            "message": message,
            "latency_ms": latency_ms,
        },
        actor_path="system.connector_health",
        artifact_payload={
            "connector_id": connector_id,
            "provider": provider,
            "state": state,
            "message": message,
            "latency_ms": latency_ms,
        },
    )
    return str(record["evidence_id"])


def _record_connector_mutation(
    *,
    tenant_id: str,
    connector_id: str,
    action: str,
    credential_owner: str,
) -> str:
    record = get_evidence_ledger_service().ingest(
        tenant_id=tenant_id,
        event_type="evidence:connector_write",
        data={
            "item_type": "connector_installation",
            "connector_id": connector_id,
            "action": action,
            "credential_owner": credential_owner,
        },
        actor_path="tenant.connector_installation",
        artifact_payload={
            "connector_id": connector_id,
            "action": action,
            "credential_owner": credential_owner,
        },
    )
    return str(record["evidence_id"])


def _record_connector_execution(
    *,
    tenant_id: str,
    connector_id: str,
    operation_id: str,
    success: bool,
    credential_owner: str,
    result: Any | None = None,
    error: str | None = None,
    execution_mode: str | None = None,
    dry_run: bool = False,
    idempotency_key: str | None = None,
) -> str | None:
    return record_connector_execution_evidence(
        tenant_id=tenant_id,
        connector_id=connector_id,
        operation_id=operation_id,
        success=success,
        credential_owner=credential_owner,
        result=result,
        error=error,
        execution_mode=execution_mode,
        dry_run=dry_run,
        idempotency_key=idempotency_key,
        evidence_service=get_evidence_ledger_service(),
    )


async def _run_connector_health_check(
    *,
    tenant_id: str,
    connector_id: str,
    installation: Any,
) -> dict[str, Any]:
    bootstrap_failure = _connector_bootstrap_failure(connector_id)
    # Issue #2747 round 21: track whether an actual health_check() ran.
    # Synthetic states (CONFIGURED for SDK-only connectors, ERROR from
    # bootstrap / credential resolution) must NOT be treated as live
    # probes — otherwise they could clear a more-recent breaker failure.
    probe_actually_ran = False
    if bootstrap_failure:
        response = {
            "connector_id": connector_id,
            "provider": connector_id,
            "state": ProviderState.ERROR.value,
            "message": f"Connector bootstrap unavailable: {bootstrap_failure}",
            "latency_ms": 0.0,
        }
    else:
        try:
            credentials = _get_marketplace().resolve_credentials(tenant_id, installation)
        except Exception as exc:
            logger.error(
                "[%s] Credential resolution failed for '%s': %s",
                tenant_id,
                connector_id,
                exc,
                exc_info=True,
            )
            response = {
                "connector_id": connector_id,
                "provider": connector_id,
                "state": ProviderState.ERROR.value,
                "message": f"Connector credentials unavailable: {exc}",
                "latency_ms": 0.0,
            }
        else:
            if connector_id not in _CONNECTOR_CLASSES:
                response = {
                    "connector_id": connector_id,
                    "provider": connector_id,
                    "state": ProviderState.CONFIGURED.value,
                    "message": "Connector is installed but has no health-check implementation.",
                    "latency_ms": 0.0,
                }
            else:
                config = ConnectorConfig(
                    provider=connector_id,
                    tenant_id=tenant_id,
                    credentials=credentials,
                )
                connector_instance = _CONNECTOR_CLASSES[connector_id](config)
                # Issue #2747 round 23: mark the probe as live BEFORE the
                # await so a thrown auth error (401, invalid_grant, etc.)
                # is still treated as authoritative. The intent is "we
                # tried to run a live probe" — whether it succeeds or
                # throws, the result reflects the current credential state.
                probe_actually_ran = True
                try:
                    health = await connector_instance.health_check()
                    response = {
                        "connector_id": connector_id,
                        "provider": health.provider,
                        "state": health.state.value,
                        "message": health.message,
                        "latency_ms": health.latency_ms,
                    }
                except Exception as exc:
                    logger.error(
                        "[%s] Health check failed for '%s': %s",
                        tenant_id,
                        connector_id,
                        exc,
                        exc_info=True,
                    )
                    response = {
                        "connector_id": connector_id,
                        "provider": connector_id,
                        "state": ProviderState.ERROR.value,
                        "message": str(exc),
                        "latency_ms": 0.0,
                    }

    evidence_event_id = _record_health_alert(
        tenant_id=tenant_id,
        connector_id=connector_id,
        provider=response["provider"],
        state=response["state"],
        message=response["message"],
        latency_ms=response["latency_ms"],
    )
    snapshot = _build_health_snapshot(
        tenant_id=tenant_id,
        connector_id=connector_id,
        provider=response["provider"],
        state=response["state"],
        message=response["message"],
        latency_ms=response["latency_ms"],
        evidence_event_id=evidence_event_id,
    )
    try:
        snapshot = _get_health_store().save_snapshot(
            tenant_id=tenant_id,
            connector_id=connector_id,
            provider=response["provider"],
            state=response["state"],
            message=response["message"],
            latency_ms=response["latency_ms"],
            evidence_event_id=evidence_event_id,
        )
    except IntegrationHealthStoreError as exc:
        logger.warning(
            "[%s] Connector health snapshot persistence unavailable for '%s': %s",
            tenant_id,
            connector_id,
            exc,
            exc_info=True,
        )
    # Issue #2747: enrich the canonical health response with structured
    # remediation hints. Round 21: only flag the probe as live when an
    # actual health_check() ran (probe_actually_ran). Synthetic
    # CONFIGURED / ERROR states must NOT clear a more-recent breaker
    # failure.
    remediation = _connector_remediation_fields(
        tenant_id=tenant_id,
        connector_id=connector_id,
        probe_response=response,
        probe_is_live=probe_actually_ran,
    )
    return {
        **response,
        "last_checked_at": snapshot.get("last_checked_at"),
        "alert_open": bool(snapshot.get("alert_open")),
        "evidence_event_id": snapshot.get("evidence_event_id"),
        "evidence_url": _evidence_url(snapshot.get("evidence_event_id")),
        **remediation,
    }


def _connector_remediation_fields(
    *,
    tenant_id: str,
    connector_id: str,
    probe_response: dict[str, Any] | None = None,
    probe_is_live: bool = False,
) -> dict[str, Any]:
    """Thin wrapper over the shared ``compute_remediation`` helper.

    Issue #2747 round 11+21: every consumer (HTTP route, dashboard bundle,
    public/MCP API) goes through ``apps.backend.services.connector_remediation``
    so they cannot drift. The HTTP route only sets ``probe_is_live=True``
    when an actual ``ConnectorBase.health_check()`` ran — synthetic
    CONFIGURED / ERROR responses for connectors without a probe stay
    non-authoritative.
    """
    from apps.backend.services.connector_remediation import (
        compute_remediation,
        resolve_health_service,
    )

    return compute_remediation(
        tenant_id=tenant_id,
        connector_id=connector_id,
        health_service=resolve_health_service(),
        probe_response=probe_response,
        probe_is_live=probe_is_live,
    )


async def _run_zoho_connector_health_check(
    *,
    tenant_id: str,
    connector_id: str,
    connection: ZohoConnectionRecord,
) -> dict[str, Any]:
    bootstrap_failure = _connector_bootstrap_failure(connector_id)
    # Issue #2747 round 21: probe_actually_ran tracks whether a real
    # health_check() executed so non-live synthetic states cannot clear
    # a more-recent breaker failure.
    probe_actually_ran = False

    if bootstrap_failure:
        response = {
            "connector_id": connector_id,
            "provider": connector_id,
            "state": ProviderState.ERROR.value,
            "message": f"Connector bootstrap unavailable: {bootstrap_failure}",
            "latency_ms": 0.0,
        }
    elif connector_id in _CONNECTOR_CLASSES:
        config = ConnectorConfig(
            provider=connector_id,
            tenant_id=tenant_id,
            credentials={},
        )
        connector_instance = _CONNECTOR_CLASSES[connector_id](config)
        # Issue #2747 round 23: mark live before await — same fix as the
        # standard path above.
        probe_actually_ran = True
        try:
            health = await connector_instance.health_check()
            response = {
                "connector_id": connector_id,
                "provider": health.provider,
                "state": health.state.value,
                "message": health.message,
                "latency_ms": health.latency_ms,
            }
        except Exception as exc:
            logger.error(
                "[%s] Health check failed for canonical Zoho connector '%s': %s",
                tenant_id,
                connector_id,
                exc,
                exc_info=True,
            )
            response = {
                "connector_id": connector_id,
                "provider": connector_id,
                "state": ProviderState.ERROR.value,
                "message": str(exc),
                "latency_ms": 0.0,
            }
    else:
        product = get_zoho_product(connection.product_slug)
        response = {
            "connector_id": connector_id,
            "provider": connector_id,
            "state": str((connection.health_metadata or {}).get("state") or ProviderState.CONNECTED.value),
            "message": f"{product.display_name} connected via canonical Zoho auth",
            "latency_ms": 0.0,
        }

    evidence_event_id = _record_health_alert(
        tenant_id=tenant_id,
        connector_id=connector_id,
        provider=response["provider"],
        state=response["state"],
        message=response["message"],
        latency_ms=response["latency_ms"],
    )
    snapshot = _build_health_snapshot(
        tenant_id=tenant_id,
        connector_id=connector_id,
        provider=response["provider"],
        state=response["state"],
        message=response["message"],
        latency_ms=response["latency_ms"],
        evidence_event_id=evidence_event_id,
    )
    try:
        snapshot = _get_health_store().save_snapshot(
            tenant_id=tenant_id,
            connector_id=connector_id,
            provider=response["provider"],
            state=response["state"],
            message=response["message"],
            latency_ms=response["latency_ms"],
            evidence_event_id=evidence_event_id,
        )
    except IntegrationHealthStoreError as exc:
        logger.warning(
            "[%s] Canonical Zoho health snapshot persistence unavailable for '%s': %s",
            tenant_id,
            connector_id,
            exc,
            exc_info=True,
        )
    # Issue #2747: enrich the canonical Zoho health response with the same
    # structured remediation hints used by every other connector path. The
    # probe response is forwarded so a current auth_expired probe forces
    # needs_reauth=True regardless of executor history. Round 21:
    # probe_is_live is True only when an actual health_check() ran.
    remediation = _connector_remediation_fields(
        tenant_id=tenant_id,
        connector_id=connector_id,
        probe_response=response,
        probe_is_live=probe_actually_ran,
    )
    return {
        **response,
        "last_checked_at": snapshot.get("last_checked_at"),
        "alert_open": bool(snapshot.get("alert_open")),
        "evidence_event_id": snapshot.get("evidence_event_id"),
        "evidence_url": _evidence_url(snapshot.get("evidence_event_id")),
        **remediation,
    }
