"""Connector OAuth dispatch route.

Issue #2155 (codex review on PR #2155, derived from #1999):
The onboarding wizard's quick-connect button posts to
``/api/v1/connectors/{connector_id}/oauth/start`` so the UI has a single,
stable contract for every provider. The backend, however, exposes
provider-specific routes:

- Zoho products use ``/api/v1/connectors/zoho/auth/start`` and require a
  ``product_slug`` payload.
- Generic OAuth2 integrations (Slack, HubSpot, Google Docs/Sheets/Slides,
  Microsoft Teams, GitHub, etc.) use ``/api/v1/integrations/oauth/connect``
  and require an ``integration_name`` payload.

This module adds a thin dispatch route that translates the
``connector_id``-shaped UI request into the right backend handler so the
wizard never has to know which provider lives where.

Why a dispatcher and not "fix the UI per connector": codex review explicitly
asked for option (a) because it gives the dashboard a stable contract that
absorbs backend churn (e.g., when a future provider migrates from the legacy
integrations OAuth path to its own service-specific route, only this file
changes — the wizard does not).
"""

from __future__ import annotations

import logging
import os

from fastapi import Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.dependencies.redirect_validation import validate_redirect_url
from apps.backend.services.connectors.base import ProviderNotRegisteredError

from ._core import (
    _INTEGRATION_TO_CONNECTOR_ID,
    _SURFACED_CONNECTOR_SPECS,
    _clean_connector_key,
    _get_integration_manager,
    _zoho_product_for_connector_id,
    router,
)
from .routes_zoho import start_zoho_connector_auth
from apps.backend.api.connectors_contracts import ZohoAuthStartRequest
from apps.backend.integrations.integration_catalog import AuthType, get_integrations_registry

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class ConnectorOAuthStartRequest(BaseModel):
    """Wizard-shaped quick-connect payload.

    The wizard sends an opaque ``return_to`` so we can route the user back
    to the autonomous-track page after the OAuth round-trip completes. We
    do NOT propagate ``return_to`` to the upstream services — those services
    own their own redirect URI registration with the OAuth provider — but we
    accept it here so the wizard contract stays forward-compatible.
    """

    return_to: str | None = Field(
        default=None,
        description="Pathname + query string to return to after OAuth completes.",
    )
    redirect_uri: str | None = Field(
        default=None,
        description="Override OAuth callback URI. Defaults to the canonical Workweaver callback.",
    )


class ConnectorOAuthStartResponse(BaseModel):
    """Unified response shape across Zoho and generic OAuth2 providers."""

    authorize_url: str = Field(..., description="Provider authorization URL.")
    state: str = Field(..., description="CSRF state token.")
    connection_id: str | None = Field(
        default=None,
        description="Connection ID (where the upstream service issues one).",
    )
    provider: str = Field(..., description="Resolved upstream provider key.")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _default_redirect_uri() -> str:
    """Canonical OAuth callback URL the integrations OAuth path expects."""
    public_base = (os.environ.get("PUBLIC_BASE_URL") or "https://api.workweaver.ai").rstrip("/")
    return f"{public_base}/oauth/callback"


def _connector_to_integration_name(connector_id: str) -> str | None:
    """Resolve a UI ``connector_id`` to a registry ``integration_name``.

    Strategy:
    1. Inverse the curated ``_INTEGRATION_TO_CONNECTOR_ID`` mapping.
    2. If a surfaced connector spec carries an ``integration_name``, prefer it.
    3. Fall back to scanning the integrations registry by metadata.connector_id.

    We normalise both sides through ``_clean_connector_key`` so dashes/spaces
    don't mismatch (the same defense ``_zoho_product_for_connector_id`` uses).
    """
    normalized = _clean_connector_key(connector_id)
    if not normalized:
        return None

    # Strategy 1: curated forward map (HubSpot -> hubspot-crm, etc.)
    for integration_name, mapped_connector in _INTEGRATION_TO_CONNECTOR_ID.items():
        if mapped_connector and _clean_connector_key(mapped_connector) == normalized:
            return integration_name

    # Strategy 2: surfaced connector specs (covers Gmail, Google Calendar,
    # Google Docs/Sheets/Slides, Teams, GitHub, etc.).
    for spec in _SURFACED_CONNECTOR_SPECS:
        spec_connector_id = spec.get("connector_id")
        spec_key = spec.get("key")
        spec_integration = spec.get("integration_name")
        if not spec_integration:
            continue
        candidates = {spec_connector_id, spec_key}
        for candidate in candidates:
            if candidate and _clean_connector_key(str(candidate)) == normalized:
                return str(spec_integration)

    # Strategy 3: scan the live integrations registry (catches integrations
    # that surface their connector_id via metadata only).
    registry = get_integrations_registry()
    for integration in registry.list_available():
        metadata_connector = (integration.metadata or {}).get("connector_id")
        if metadata_connector and _clean_connector_key(str(metadata_connector)) == normalized:
            return integration.name
        if _clean_connector_key(integration.name) == normalized:
            return integration.name

    return None


def _is_zoho_connector(connector_id: str) -> bool:
    """Return True when the connector_id maps to a Zoho product registry entry."""
    return _zoho_product_for_connector_id(connector_id) is not None


# ---------------------------------------------------------------------------
# Route
# ---------------------------------------------------------------------------


@router.post(
    "/{connector_id}/oauth/start",
    response_model=ConnectorOAuthStartResponse,
    summary="Start an OAuth flow for any connector (dispatcher)",
    description=(
        "Stable wizard-facing OAuth start route. Dispatches Zoho connectors "
        "to ``/api/v1/connectors/zoho/auth/start`` semantics and other OAuth2 "
        "integrations to ``/api/v1/integrations/oauth/connect``."
    ),
)
async def start_connector_oauth(
    connector_id: str,
    body: ConnectorOAuthStartRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ConnectorOAuthStartResponse:
    """Dispatch the wizard's connector OAuth start to the right backend handler."""
    connector_id_clean = (connector_id or "").strip()
    if not connector_id_clean:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Missing connector_id",
        )

    # CVE-2026-32025 (#3184): validate redirect_uri against allowlist.
    redirect_uri_raw = (body.redirect_uri or "").strip() or _default_redirect_uri()
    validated_redirect = validate_redirect_url(redirect_uri_raw, tenant_id=tenant_id)

    # Branch 1: Zoho products keep their bespoke start handler so the
    # canonical product_slug + JWT envelope flow stays intact.
    if _is_zoho_connector(connector_id_clean):
        product = _zoho_product_for_connector_id(connector_id_clean)
        assert product is not None, "guarded by _is_zoho_connector"
        zoho_request = ZohoAuthStartRequest(
            product_slug=product.product_slug,
            redirect_uri=validated_redirect,
        )
        zoho_response = await start_zoho_connector_auth(
            body=zoho_request,
            tenant_id=tenant_id,
        )
        return ConnectorOAuthStartResponse(
            authorize_url=zoho_response.authorization_url,
            state=zoho_response.state,
            connection_id=zoho_response.connection.connection_id,
            provider="zoho",
        )

    # Branch 2: generic OAuth2 integrations go through IntegrationManager.
    integration_name = _connector_to_integration_name(connector_id_clean)
    if not integration_name:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Connector '{connector_id_clean}' has no OAuth start route.",
        )

    registry = get_integrations_registry()
    integration = registry.get_integration(integration_name)
    if integration is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Integration '{integration_name}' not found.",
        )
    if integration.auth_type != AuthType.OAUTH2:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=(
                f"Integration '{integration_name}' uses {integration.auth_type.value}; "
                "OAuth start is only supported for OAuth2 integrations."
            ),
        )

    redirect_uri = validated_redirect
    manager = _get_integration_manager()
    try:
        result = await manager.initiate_oauth_flow(
            tenant_id=tenant_id,
            integration_name=integration_name,
            redirect_uri=redirect_uri,
        )
    except ValueError as exc:
        # Surface the underlying ValueError as a 400 — this is the same
        # contract the legacy /api/v1/integrations/oauth/connect uses, so
        # the dashboard handles errors identically across both paths.
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    except ProviderNotRegisteredError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=str(exc),
        ) from exc
    except Exception as exc:  # pragma: no cover - defensive
        logger.error(
            "[%s] OAuth dispatch failed for connector %s -> integration %s: %s",
            tenant_id,
            connector_id_clean,
            integration_name,
            exc,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to initiate OAuth flow",
        ) from exc

    return ConnectorOAuthStartResponse(
        authorize_url=str(result.get("authorization_url") or ""),
        state=str(result.get("state") or ""),
        connection_id=str(result.get("connection_id") or "") or None,
        provider=integration_name,
    )


# Convenience: re-export under a public symbol for tests.
__all__ = [
    "ConnectorOAuthStartRequest",
    "ConnectorOAuthStartResponse",
    "start_connector_oauth",
]


def _resolve_integration_name(connector_id: str) -> str | None:
    """Public helper for tests/contracts to verify dispatch resolution."""
    return _connector_to_integration_name(connector_id)
