"""Connector import routes."""

from __future__ import annotations

import logging

from fastapi import Depends, HTTPException, status

from apps.backend.api.connectors_contracts import OpenAPIImportRequest, OpenAPIImportResponse
from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.connectors.openapi_factory import (
    OpenAPIToolFactory,
    get_openapi_tool_factory,
)

from ._core import router

logger = logging.getLogger(__name__)


def _get_openapi_tool_factory() -> OpenAPIToolFactory:
    return get_openapi_tool_factory()


@router.post(
    "/import/openapi",
    response_model=OpenAPIImportResponse,
    status_code=status.HTTP_201_CREATED,
)
async def import_openapi_connector(
    body: OpenAPIImportRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, object]:
    """Import an OpenAPI document as a tenant-scoped connector."""
    try:
        return await _get_openapi_tool_factory().import_spec(
            body.spec_url,
            tenant_id,
            base_url=body.base_url,
            name=body.name,
            description=body.description,
            auth=body.auth,
        )
    except ValueError as exc:
        logger.warning("openapi_connector_import validation error: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
