"""Public facade for the connectors API package.

The original `apps/backend/api/connectors.py` module was split into cohesive
submodules for readability and to clear the STRUCT-MEGA-FILE product-health
gate. This package re-exports the same names the rest of the codebase used
to import from `apps.backend.api.connectors`, so existing import sites,
test patches, and `shared_connector_service._connectors_module()` continue
to work without change.

Module map:
- `_core`                    — shared router, registry, and private helpers
- `routes_catalog`           — catalog / categories / popular / installed / health / connection-center
- `routes_connect_session`   — deprecated /{provider_id}/connect-session
- `routes_zoho`              — Zoho auth routes (start / complete / list / get)
- `routes_standards`         — standards-based connector registration
- `routes_lifecycle`         — connector detail / list / install / uninstall / execute / health
- `routes_oauth_dispatch`    — wizard-facing OAuth start dispatcher
- `routes_pm_oauth`          — PM connector OAuth2 routes (authorize / callback) #3585
- `routes_twilio`            — moved to `services/channels/twilio/routes.py` (Twilio BYO flow and legacy 410 stubs)
"""

from __future__ import annotations

# ---------------------------------------------------------------------------
# Load the shared router and helpers first so decorators in the route modules
# have something to attach to.
# ---------------------------------------------------------------------------
from ._core import (  # noqa: F401 — public/private re-exports
    _CONNECTOR_BOOTSTRAP_ERRORS,
    _CONNECTOR_CLASSES,
    _INTEGRATION_TO_CONNECTOR_ID,
    _OMIT_MARKETPLACE_IDS,
    _SURFACED_CONNECTOR_SPECS,
    _SURFACED_SPEC_BY_INTEGRATION,
    _build_connection_center_item,
    _build_connection_center_response,
    _build_health_snapshot,
    _catalog_connector_summaries,
    _clean_connector_key,
    _connector_bootstrap_failure,
    _connector_availability_map,
    _connector_id_for_integration,
    _decode_zoho_connector_state,
    _encode_zoho_connector_state,
    _evidence_url,
    _get_connector_info,
    _get_health_store,
    _get_integration_manager,
    _get_marketplace,
    _get_standard_registry,
    _get_zoho_connection_manager,
    _health_alert_states,
    _health_to_state,
    _integration_metadata,
    _list_marketplace_catalog_items,
    _list_zoho_catalog_products,
    _load_connector_classes,
    _record_connector_execution,
    _record_connector_mutation,
    _record_health_alert,
    _replace_query_param,
    _run_connector_health_check,
    _run_zoho_connector_health_check,
    _safe_list_zoho_connections,
    _zoho_callback_uri,
    _zoho_connection_for_connector,
    _zoho_connection_response,
    _zoho_connector_detail,
    _zoho_connector_exposes_execution,
    _zoho_connector_summary,
    _zoho_credential_owner,
    _zoho_installed_connector_payload,
    _zoho_operation_ids,
    _zoho_product_for_connector_id,
    _zoho_state_b64,
    _zoho_state_decode,
    _zoho_state_secret,
    get_integrations_registry,
    logger,
    router,
)

# ---------------------------------------------------------------------------
# Import route modules so their @router.* decorators register endpoints.
# Ordering matters for FastAPI path resolution: routes_catalog must precede
# routes_lifecycle because /installed, /health, /connection-center, etc. are
# more specific than the catch-all /{connector_id} in routes_lifecycle.
# routes_connect_session (/{provider_id}/connect-session) is specific-enough
# that ordering is fine. routes_zoho / routes_standards all use dedicated
# path prefixes so their ordering is independent. routes_twilio is now
# imported from services/channels/twilio/routes.py.
# ---------------------------------------------------------------------------
from . import routes_catalog  # noqa: F401, E402
from . import routes_connect_session  # noqa: F401, E402
from . import routes_zoho  # noqa: F401, E402
from . import routes_standards  # noqa: F401, E402
from . import routes_import  # noqa: F401, E402
from . import routes_oauth_dispatch  # noqa: F401, E402
from . import routes_pm_oauth  # noqa: F401, E402 — issue #3585 PM connector OAuth routes
from apps.backend.services.channels.twilio import routes as routes_twilio  # noqa: F401, E402
from . import routes_lifecycle  # noqa: F401, E402

# Re-export routing-layer symbols that other modules or tests import directly.
from .routes_connect_session import (  # noqa: E402, F401
    _CONNECT_SESSION_SUNSET_HTTP_DATE,
    _CONNECT_SESSION_SUNSET_ISO,
    _PROVIDERS_VIA_LEGACY_OAUTH,
    _PROVIDERS_WITH_OAUTH_CREDENTIALS_PROVISIONED,
    _connect_session_successor,
    create_connector_connect_session,
)
from .routes_catalog import (  # noqa: E402, F401
    get_connection_center,
    get_connector_status,
    list_available_connectors,
    list_categories,
    list_connector_health,
    list_installed,
    list_popular,
)
from .routes_lifecycle import (  # noqa: E402, F401
    connector_health,
    execute_connector,
    get_connector,
    install_connector,
    list_connectors,
    uninstall_connector,
)
from .routes_standards import (  # noqa: E402, F401
    list_standard_connector_definitions,
    register_standard_connector,
)
from .routes_import import import_openapi_connector  # noqa: E402, F401
from apps.backend.services.channels.twilio.routes import (  # noqa: E402, F401
    TWILIO_BYO_DOCS_URL,
    TWILIO_BYO_REQUIRED_FIELDS,
    TwilioConnectRequest,
    TwilioConnectResponse,
    TwilioProvisioningStatusResponse,
    _LEGACY_TWILIO_GONE_BODY,
    _TwilioPortRequestLegacy,
    _verify_twilio_credentials,
    connect_twilio_byo,
    port_twilio_number_deprecated,
    provision_twilio_number_deprecated,
    twilio_provisioning_status,
)
from .routes_zoho import (  # noqa: E402, F401
    _complete_zoho_connector_auth,
    complete_zoho_connector_auth,
    complete_zoho_connector_auth_via_api,
    get_zoho_connection,
    list_zoho_connections,
    start_zoho_connector_auth,
)
from .routes_oauth_dispatch import (  # noqa: E402, F401
    ConnectorOAuthStartRequest,
    ConnectorOAuthStartResponse,
    start_connector_oauth,
)
