"""Catalog and discovery routes — available / categories / popular / installed / health / connection-center."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import Depends, Query

from apps.backend.api.connectors_contracts import (
    CatalogAvailableResponse,
    CategoryCount,
    ConnectionCenterResponse,
    ConnectorAvailabilityResponse,
    ConnectorHealthListResponse,
    ConnectorSummary,
    HealthResponse,
    InstalledConnector,
)
from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.pagination import (
    PaginationParams,
    build_pagination_dependency,
    paginate_items,
)
from apps.backend.services.connectors.base import ProviderState
from apps.backend.services.zoho.product_registry import get_zoho_product

from ._core import (
    _build_connection_center_response,
    _catalog_connector_summaries,
    _clean_connector_key,
    _connector_availability_map,
    _get_marketplace,
    _get_standard_registry,
    _list_marketplace_catalog_items,
    _run_connector_health_check,
    _run_zoho_connector_health_check,
    _safe_list_zoho_connections,
    _zoho_connector_exposes_execution,
    _zoho_connector_summary,
    _zoho_installed_connector_payload,
    _zoho_product_for_connector_id,
    router,
)

logger = logging.getLogger(__name__)


@router.get("/catalog/available", response_model=CatalogAvailableResponse)
async def list_available_connectors(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """List ALL available connectors from the built-in marketplace catalog."""
    marketplace_items = _list_marketplace_catalog_items()
    combined: dict[str, dict[str, Any]] = {}
    for item in marketplace_items:
        key = _clean_connector_key(item.get("id"))
        is_available = not (item.get("coming_soon", False) or item.get("state") == "catalog_only")
        combined[key] = {
            **item,
            "source": "platform",
            "installed": False,
            "available": is_available,
        }

    items = sorted(
        combined.values(),
        key=lambda x: (str(x.get("category") or ""), str(x.get("name") or x.get("id") or "").lower()),
    )

    return {
        "items": items,
        "total": len(items),
        "custom_count": len(combined),
        "discovered_count": 0,
    }


@router.get("/categories", response_model=list[CategoryCount])
async def list_categories(
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=25, max_limit=100)),
) -> list[dict[str, Any]]:
    """Get all connector categories with counts.

    Returns each category with the total number of connectors and
    how many are currently available (non-coming-soon).
    """
    counts: dict[str, dict[str, int]] = {}
    for connector in _catalog_connector_summaries():
        category = str(connector.get("category") or "integration")
        counts.setdefault(category, {"total": 0, "available": 0})
        counts[category]["total"] += 1
        # catalog_only providers are not available (same as coming_soon).
        is_available = not (bool(connector.get("coming_soon")) or connector.get("state") == "catalog_only")
        if is_available:
            counts[category]["available"] += 1
    categories = [
        {"category": category, "total": values["total"], "available": values["available"]}
        for category, values in sorted(counts.items())
    ]
    categories, _total = paginate_items(categories, pagination)
    return categories


@router.get("/popular", response_model=list[ConnectorSummary])
async def list_popular(
    limit: int = Query(default=10, ge=1, le=50, description="Max connectors to return"),
) -> list[dict[str, Any]]:
    """Get popular connectors ranked by install count.

    Returns the most-installed connectors, with built-in connectors
    prioritised. Coming-soon connectors are excluded.
    """
    popular = list(_get_marketplace().get_popular(limit=limit))
    seen = {_clean_connector_key(item.get("id")) for item in popular}
    for connector_id in ("zoho-crm", "zoho-calendar", "zoho-mail", "zoho-books", "zoho-desk"):
        product = _zoho_product_for_connector_id(connector_id)
        if (
            product is None
            or product.coming_soon
            or not _zoho_connector_exposes_execution(product)
            or _clean_connector_key(connector_id) in seen
        ):
            continue
        popular.append(_zoho_connector_summary(product))
        seen.add(_clean_connector_key(connector_id))
        if len(popular) >= limit:
            break
    return popular[:limit]


@router.get("/installed", response_model=list[InstalledConnector])
async def list_installed(
    tenant_id: str = Depends(get_verified_tenant_id),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> list[dict[str, Any]]:
    """List all connectors installed for the requesting tenant.

    Credentials are never included in the response.
    """
    mp = _get_marketplace()
    _get_standard_registry().ensure_registered(tenant_id)
    logger.info("[%s] Listing installed connectors", tenant_id)
    installed = [
        item
        for item in mp.get_installed(tenant_id)
        if _zoho_product_for_connector_id(str(item.get("id") or "")) is None
    ]
    installed.extend(
        _zoho_installed_connector_payload(connection)
        for connection in _safe_list_zoho_connections(tenant_id, surface="installed-connectors")
        if connection.state == "connected" and get_zoho_product(connection.product_slug).catalog_visible
    )
    installed.sort(key=lambda item: str(item.get("name") or item.get("id") or "").lower())
    installed, _total = paginate_items(installed, pagination)
    return installed


@router.get("/status", response_model=ConnectorAvailabilityResponse)
async def get_connector_status(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ConnectorAvailabilityResponse:
    """Return the tenant connector availability map across runtime profiles."""
    return ConnectorAvailabilityResponse(**_connector_availability_map(tenant_id))


@router.get("/health", response_model=ConnectorHealthListResponse)
async def list_connector_health(
    tenant_id: str = Depends(get_verified_tenant_id),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> ConnectorHealthListResponse:
    """Run and persist health checks for all installed connectors."""
    mp = _get_marketplace()
    _get_standard_registry().ensure_registered(tenant_id)
    items: list[HealthResponse] = []
    health_targets: list[dict[str, Any]] = [
        {
            "kind": "marketplace",
            "connector_id": str(item.get("id") or ""),
            "sort_name": str(item.get("name") or item.get("id") or "").lower(),
        }
        for item in mp.get_installed(tenant_id)
        if _zoho_product_for_connector_id(str(item.get("id") or "")) is None
    ]
    for connection in _safe_list_zoho_connections(tenant_id, surface="connector-health"):
        product = get_zoho_product(connection.product_slug)
        if connection.state != "connected" or not product.catalog_visible or not product.connector_id:
            continue
        health_targets.append(
            {
                "kind": "zoho",
                "connector_id": product.connector_id,
                "sort_name": product.display_name.lower(),
                "connection": connection,
            }
        )
    health_targets.sort(key=lambda item: (str(item.get("sort_name") or ""), str(item.get("connector_id") or "")))
    page_targets, _total = paginate_items(health_targets, pagination)
    for target in page_targets:
        if target["kind"] == "zoho":
            health = await _run_zoho_connector_health_check(
                tenant_id=tenant_id,
                connector_id=target["connector_id"],
                connection=target["connection"],
            )
            items.append(HealthResponse(**health))
            continue
        try:
            installation = mp._load_installation(tenant_id, target["connector_id"])
        except Exception as exc:
            logger.warning(
                "[%s] Unable to load installed connector '%s' for health: %s",
                tenant_id,
                target["connector_id"],
                exc,
                exc_info=True,
            )
            items.append(
                HealthResponse(
                    connector_id=target["connector_id"],
                    provider=target["connector_id"],
                    state=ProviderState.ERROR.value,
                    message="Installed connector record is unavailable.",
                    latency_ms=0.0,
                    alert_open=True,
                )
            )
            continue
        health = await _run_connector_health_check(
            tenant_id=tenant_id,
            connector_id=target["connector_id"],
            installation=installation,
        )
        items.append(HealthResponse(**health))
    return ConnectorHealthListResponse(items=items, count=len(items))


@router.get("/connection-center", response_model=ConnectionCenterResponse)
async def get_connection_center(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ConnectionCenterResponse:
    """Return the canonical connection-center feed for runtime and onboarding."""
    return await _build_connection_center_response(tenant_id)
