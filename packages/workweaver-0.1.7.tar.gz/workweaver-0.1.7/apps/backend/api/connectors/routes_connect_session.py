"""Deprecated connect-session route (#1154 — Nango retired).

Emits RFC 8594-compliant 410 Gone with structured routing info pointing at
the native connector flow (OAuth / Zoho dedicated / BYOC).
"""

from __future__ import annotations

import logging

from fastapi import Depends, status
from fastapi.responses import JSONResponse

from apps.backend.api.connectors_contracts import ConnectorConnectSessionRequest
from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

from ._core import router

logger = logging.getLogger(__name__)


# Providers served via the legacy /api/v1/integrations/oauth/connect endpoint.
_PROVIDERS_VIA_LEGACY_OAUTH: set[str] = {
    "gmail",
    "google",
    "google-mail",
    "google_mail",
    "google-calendar",
    "google_calendar",
    "google-drive",
    "google_drive",
    "google-workspace",
    "google_workspace",
    # Docs / Sheets / Slides ride the same Google OAuth client_id/secret
    # provisioned for Gmail/Calendar/Drive — they go through the legacy
    # /api/v1/integrations/oauth/connect path.
    "google-docs",
    "google_docs",
    "google-sheets",
    "google_sheets",
    "google-slides",
    "google_slides",
    # Google Meet is not a standalone connector — it's calendar.events with
    # conferenceData.createRequest. We accept the alias here so users who
    # click a "Connect Meet" button get routed through the calendar OAuth.
    "google-meet",
    "google_meet",
}

# Backwards-compat alias used by older code paths and tests.
_PROVIDERS_WITH_OAUTH_CREDENTIALS_PROVISIONED: set[str] = _PROVIDERS_VIA_LEGACY_OAUTH


# RFC 8594 Sunset date for the deprecated connect-session endpoint.
# 2026-10-15 (Thursday) — 6 months from the 2026-04-14 deprecation (#1154).
# HTTP-date format per RFC 7231 §7.1.1.1.
_CONNECT_SESSION_SUNSET_HTTP_DATE = "Thu, 15 Oct 2026 00:00:00 GMT"
_CONNECT_SESSION_SUNSET_ISO = "2026-10-15T00:00:00Z"


def _connect_session_successor(provider_id: str) -> tuple[str | None, str]:
    """Return (replacement_url, auth_method) for the deprecated connect-session provider.

    - Google-family providers: native OAuth at /api/v1/integrations/oauth/connect
    - Zoho family:             dedicated Workweaver-owned auth at /api/v1/connectors/zoho/auth/start
    - Everything else:         BYOC (replacement is None — UI renders "coming soon" / "bring your own")
    """
    normalized = provider_id.strip().lower()
    if normalized in _PROVIDERS_VIA_LEGACY_OAUTH:
        return "/api/v1/integrations/oauth/connect", "oauth"
    if normalized.startswith("zoho"):
        return "/api/v1/connectors/zoho/auth/start", "dedicated"
    return None, "byoc"


@router.post(
    "/{provider_id}/connect-session",
    deprecated=True,
    responses={
        410: {
            "description": (
                "Endpoint permanently retired — Nango removed (#990, #1012, #1154). "
                "Use the native connector flow indicated by the `replacement` field."
            )
        }
    },
)
async def create_connector_connect_session(
    provider_id: str,
    body: ConnectorConnectSessionRequest,  # noqa: ARG001 — kept for backwards-compat schema
    tenant_id: str = Depends(get_verified_tenant_id),
) -> JSONResponse:
    """Deprecated — returns 410 Gone with structured routing info.

    See #1154. The 501 stub is replaced by a RFC 8594-compliant deprecation
    response so the UI can render "coming soon" (BYOC) or redirect to the
    native auth flow (OAuth / Zoho dedicated) based on the `auth_method`
    and `replacement` fields in the body.

    The auth gate (`get_verified_tenant_id`) fires FIRST — unauthenticated
    callers get 401/403 before ever seeing the 410. This is fail-CLOSED.
    """
    replacement, auth_method = _connect_session_successor(provider_id)

    logger.warning(
        "connector_connect_session_deprecated_call",
        extra={
            "tenant_id": tenant_id,
            "provider_id": provider_id,
            "auth_method": auth_method,
            "replacement": replacement,
        },
    )

    headers: dict[str, str] = {
        "Deprecation": "true",
        "Sunset": _CONNECT_SESSION_SUNSET_HTTP_DATE,
        "Cache-Control": "no-store",
    }
    if replacement:
        headers["Link"] = f'<{replacement}>; rel="successor-version"'

    return JSONResponse(
        status_code=status.HTTP_410_GONE,
        content={
            "error": "connector_connect_session_deprecated",
            "detail": (
                "Nango-based session flow has been retired (#990, #1012). "
                "Use the native connector flow indicated by `replacement`, "
                "or bring your own credentials when `auth_method` is `byoc`."
            ),
            "provider": provider_id,
            "replacement": replacement,
            "auth_method": auth_method,
            "sunset_at": _CONNECT_SESSION_SUNSET_ISO,
        },
        headers=headers,
    )
