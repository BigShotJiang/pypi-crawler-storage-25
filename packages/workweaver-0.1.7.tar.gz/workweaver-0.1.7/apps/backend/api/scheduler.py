"""
Adaptive Scheduler API

Reschedule, plan retrieval, pin/unpin, weight management, feedback, and health.
Durable lease status endpoint (#3600).

Source: docs/PRODUCT.md#Part19
"""

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.schemas.error_response import safe_error_detail
from apps.backend.services.scheduling.adaptive import (
    AdaptiveScheduler,
    FeedbackCollector,
    TriggerHandler,
)
from apps.backend.services.scheduler_state_store import SchedulerPersistenceError

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/scheduler", tags=["scheduler"])

_scheduler = AdaptiveScheduler()
_trigger_handler = TriggerHandler(scheduler=_scheduler)
_feedback = FeedbackCollector(scheduler=_scheduler)


def _raise_scheduler_store_error(exc: SchedulerPersistenceError) -> None:
    raise HTTPException(status_code=503, detail="Scheduler storage unavailable") from exc


# --- Request Models ---


class ScheduleRequest(BaseModel):
    items: list[dict[str, Any]] = Field(..., min_length=1, description="Schedulable items")
    target_date: str = Field(..., description="YYYY-MM-DD")
    mode: str = Field("all", pattern="^(agent|human|all)$")
    working_hours: list[int] = Field([9, 17], min_length=2, max_length=2)
    focus_blocks: list[dict[str, str]] = Field(default_factory=list)
    calendar_events: list[dict[str, str]] = Field(default_factory=list)
    max_review_windows: int = Field(4, ge=1, le=12)


class PinRequest(BaseModel):
    item_id: str = Field(..., min_length=1)
    pinned_time: str | None = Field(None, description="ISO datetime or null to unpin")


class WeightsRequest(BaseModel):
    urgency: float = Field(..., ge=0.05, le=0.50)
    deadline_proximity: float = Field(..., ge=0.05, le=0.50)
    importance: float = Field(..., ge=0.05, le=0.50)
    context_affinity: float = Field(..., ge=0.05, le=0.50)
    energy_fit: float = Field(..., ge=0.05, le=0.50)


class FeedbackRequest(BaseModel):
    item_id: str = Field(..., min_length=1)
    estimated_minutes: float = Field(..., gt=0)
    actual_minutes: float = Field(..., gt=0)
    agent_id: str | None = None
    task_type: str = Field("general")
    completed_hour: int | None = Field(None, ge=0, le=23)


class DurationEstimateRequest(BaseModel):
    task_type: str = Field("general")
    base_minutes: float = Field(..., gt=0)


# --- Endpoints ---


@router.post("/schedule")
async def schedule(
    req: ScheduleRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Run a full scheduling pass. Returns plan with slots, overflow, and health."""
    try:
        plan = _scheduler.schedule(
            tenant_id=tenant_id,
            items=req.items,
            target_date=req.target_date,
            mode=req.mode,
            working_hours=(req.working_hours[0], req.working_hours[1]),
            focus_blocks=req.focus_blocks,
            calendar_events=req.calendar_events,
            max_review_windows=req.max_review_windows,
        )
        return plan.to_dict()
    except SchedulerPersistenceError as exc:
        _raise_scheduler_store_error(exc)


@router.get("/plan/{plan_id}")
async def get_plan(
    plan_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Retrieve a previously generated plan."""
    try:
        plan = _scheduler.get_plan(plan_id, tenant_id)
        if not plan:
            raise HTTPException(status_code=404, detail="Plan not found")
        return plan.to_dict()
    except SchedulerPersistenceError as exc:
        _raise_scheduler_store_error(exc)


@router.post("/pin")
async def pin_item(
    req: PinRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Pin or unpin an item to a specific time."""
    try:
        return _scheduler.pin_item(tenant_id, req.item_id, req.pinned_time)
    except SchedulerPersistenceError as exc:
        _raise_scheduler_store_error(exc)


@router.get("/weights")
async def get_weights(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, float]:
    """Get priority weights for the tenant."""
    try:
        return _scheduler.get_weights(tenant_id)
    except SchedulerPersistenceError as exc:
        _raise_scheduler_store_error(exc)


@router.put("/weights")
async def set_weights(
    req: WeightsRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, float]:
    """Set priority weights for the tenant."""
    weights = req.model_dump()
    try:
        return _scheduler.set_weights(tenant_id, weights)
    except SchedulerPersistenceError as exc:
        _raise_scheduler_store_error(exc)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))


@router.post("/feedback")
async def record_feedback(
    req: FeedbackRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Record task completion feedback for learning calibration."""
    try:
        return _feedback.record_completion(
            tenant_id=tenant_id,
            item_id=req.item_id,
            estimated_minutes=req.estimated_minutes,
            actual_minutes=req.actual_minutes,
            agent_id=req.agent_id,
            task_type=req.task_type,
            completed_hour=req.completed_hour,
        )
    except SchedulerPersistenceError as exc:
        _raise_scheduler_store_error(exc)


@router.post("/duration-estimate")
async def get_duration_estimate(
    req: DurationEstimateRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Get calibrated duration estimate based on historical completion data."""
    try:
        calibrated = _feedback.get_duration_estimate(tenant_id, req.task_type, req.base_minutes)
        return {
            "task_type": req.task_type,
            "base_minutes": req.base_minutes,
            "calibrated_minutes": calibrated,
        }
    except SchedulerPersistenceError as exc:
        _raise_scheduler_store_error(exc)


@router.get("/agent-affinity/{agent_id}")
async def get_agent_affinity(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, float]:
    """Get agent's task type affinities (avg minutes per task type)."""
    try:
        return _feedback.get_agent_affinity(tenant_id, agent_id)
    except SchedulerPersistenceError as exc:
        _raise_scheduler_store_error(exc)


@router.get("/health")
async def get_health(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Get scheduler health: completion count, trigger count, current weights."""
    try:
        return {
            "tenant_id": tenant_id,
            "completion_count": _feedback.get_completion_count(tenant_id),
            "trigger_count": _trigger_handler.get_trigger_count(tenant_id),
            "weights": _scheduler.get_weights(tenant_id),
        }
    except SchedulerPersistenceError as exc:
        _raise_scheduler_store_error(exc)


# ── Durable scheduler leases (issue #3600) ────────────────────────────


@router.get("/leases")
async def list_leases(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """List currently active (LEASED) scheduler leases.

    Durable leases backed by PortableStore (DynamoDB/Postgres/SQLite)
    enforce single-leader semantics on multi-pod deployments (issue #3600).
    """
    from apps.backend.services.runtime.task_lease_scheduler import AsyncSchedulerService

    scheduler = AsyncSchedulerService()
    active = scheduler.list_active_leases()
    return {
        "tenant_id": tenant_id,
        "leases": [
            {
                "task_id": t.task_id,
                "workspace_id": t.workspace_id,
                "task_type": t.task_type,
                "leased_by": t.leased_by,
                "leader_id": t.leader_id,
                "lease_expires_at": t.lease_expires_at.isoformat() if t.lease_expires_at else None,
                "state": t.state.value if hasattr(t.state, "value") else str(t.state),
            }
            for t in active
        ],
        "count": len(active),
    }
