"""Mission runtime contract endpoints."""

from __future__ import annotations

import logging
import secrets
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field

from apps.backend.api import mission_shared
from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)
router = APIRouter()
missions_router = APIRouter()


def _get_intelligence_aggregator():
    from apps.backend.services.inference_aggregator import get_intelligence_aggregator

    return get_intelligence_aggregator()


class LedgerEntryResponse(BaseModel):
    entry_id: str
    mission_id: str
    entry_type: str
    summary: str
    actor: str
    timestamp: str
    metadata: dict = Field(default_factory=dict)


class LedgerResponse(BaseModel):
    mission_id: str
    entries: list[LedgerEntryResponse]
    count: int


class CancelMissionRequest(BaseModel):
    reason: str = Field("", max_length=5000, description="Cancellation reason")


class CancelMissionResponse(BaseModel):
    mission_id: str
    status: str
    cancelled_at: str
    cancelled_by: str
    reason: str


class ReplayEntryResponse(BaseModel):
    entry_id: str
    mission_id: str
    entry_type: str
    summary: str
    actor: str
    timestamp: str
    metadata: dict = Field(default_factory=dict)


class ReplayResponse(BaseModel):
    mission_id: str
    transitions: list[ReplayEntryResponse]
    count: int


class EnsureRunRequest(BaseModel):
    metadata: dict[str, Any] = Field(default_factory=dict)
    actor: str = Field("system", min_length=1, max_length=200)


class RunStateResponse(BaseModel):
    run_id: str
    mission_id: str
    status: str
    revision: int
    command_count: int
    last_command: str = ""
    last_actor: str = ""
    created_at: str
    updated_at: str
    paused_at: str | None = None
    cancelled_at: str | None = None
    completed_at: str | None = None
    failed_at: str | None = None
    failure_reason: str | None = None
    root_block_id: str | None = None
    steer_queue: list[dict[str, Any]] = Field(default_factory=list)
    goals: dict[str, dict[str, Any]] = Field(default_factory=dict)
    goal_roots: list[str] = Field(default_factory=list)
    agent_budgets: dict[str, dict[str, float]] = Field(default_factory=dict)
    agent_execution_budgets: dict[str, dict[str, float]] = Field(default_factory=dict)
    task_checkouts: dict[str, dict[str, Any]] = Field(default_factory=dict)
    execution_loop_state: dict[str, Any] = Field(default_factory=dict)
    governance_stop_reason: str | None = None
    governance_stop_evidence_id: str | None = None
    governance_stop_evidence_url: str | None = None
    swarm_mode: str | None = None
    swarm_config: dict[str, Any] = Field(default_factory=dict)
    budget_envelope: dict[str, Any] = Field(default_factory=dict)
    worker_identities: dict[str, dict[str, Any]] = Field(default_factory=dict)
    delegation_warrants: dict[str, dict[str, Any]] = Field(default_factory=dict)
    capability_leases: dict[str, dict[str, Any]] = Field(default_factory=dict)
    lineage_nodes: dict[str, dict[str, Any]] = Field(default_factory=dict)
    lineage_edges: dict[str, dict[str, Any]] = Field(default_factory=dict)
    swarm_activity: list[dict[str, Any]] = Field(default_factory=list)
    swarm_monitor: dict[str, Any] = Field(default_factory=dict)
    simulation_runs: dict[str, dict[str, Any]] = Field(default_factory=dict)
    simulation_artifacts: dict[str, dict[str, Any]] = Field(default_factory=dict)
    worker_time_blocks: dict[str, str] = Field(default_factory=dict)
    composition_plan: dict[str, Any] | None = None


class RunCommandResponse(BaseModel):
    command_id: str
    command_seq: int
    run_id: str
    mission_id: str
    command: str
    actor: str
    payload: dict[str, Any] = Field(default_factory=dict)
    status_before: str = ""
    status_after: str = ""
    recorded_at: str


class RunCommandListResponse(BaseModel):
    run_id: str
    commands: list[RunCommandResponse]
    count: int


class RunControlRequest(BaseModel):
    actor: str = Field("operator", min_length=1, max_length=200)
    reason: str = Field("", max_length=5000)


class ReversalRequest(BaseModel):
    requested_by: str = Field("operator", min_length=1, max_length=200)
    dry_run: bool = Field(False, description="Return the reversal plan without dispatching compensating actions.")


# ---------------------------------------------------------------------------
# Reversal UI confirmation flow (Issue #3280)
# ---------------------------------------------------------------------------


class _ReversalConfirmationStore:
    """In-memory store for reversal confirmation tokens.

    Each token is scoped to a (mission_id, tenant_id) pair and expires
    after a short TTL.  Tokens are single-use: once consumed by the
    execute endpoint they are removed.
    """

    _TOKEN_TTL_SECONDS = 10 * 60  # 10 minutes

    def __init__(self) -> None:
        self._tokens: dict[str, dict[str, Any]] = {}

    def store(self, mission_id: str, tenant_id: str) -> str:
        """Generate and store a confirmation token for the given mission."""
        token = secrets.token_urlsafe(32)
        self._tokens[token] = {
            "mission_id": mission_id,
            "tenant_id": tenant_id,
            "created_at": datetime.now(UTC).isoformat(),
        }
        return token

    def consume(self, token: str, mission_id: str, tenant_id: str) -> bool:
        """Validate and consume a confirmation token.

        Returns True if the token is valid and matches the mission/tenant,
        False otherwise.  The token is removed on successful consumption.
        """
        entry = self._tokens.get(token)
        if entry is None:
            return False
        if entry["mission_id"] != mission_id:
            return False
        if entry["tenant_id"] != tenant_id:
            return False
        # Check TTL
        created = datetime.fromisoformat(entry["created_at"].replace("Z", "+00:00"))
        age = (datetime.now(UTC) - created).total_seconds()
        if age > self._TOKEN_TTL_SECONDS:
            self._tokens.pop(token, None)
            return False
        # Consume (single-use)
        self._tokens.pop(token, None)
        return True


_reversal_confirmation_store = _ReversalConfirmationStore()


class ReversalPreviewActionItem(BaseModel):
    """A single planned compensation action in the preview response."""

    original_evidence_id: str
    connector_id: str
    operation_id: str
    reversal_action: str | None = None
    compensation_taxonomy: str
    dispatchable: bool
    reason: str | None = None
    original_event_at: str | None = None
    reversal_window_seconds: int | None = Field(
        default=None,
        description="Provider reversal window in seconds. Used by the UI to render a per-action countdown that turns red when <30s remain before window expiry.",
    )


class ReversalPreviewRequest(BaseModel):
    requested_by: str = Field("operator", min_length=1, max_length=200)


class ReversalPreviewResponse(BaseModel):
    mission_id: str
    plan: list[ReversalPreviewActionItem]
    confirmation_token: str
    count: int


class ReversalExecuteRequest(BaseModel):
    requested_by: str = Field("operator", min_length=1, max_length=200)
    confirmation_token: str = Field(..., min_length=1, description="Token from preview response")


class ReversalExecuteResponse(BaseModel):
    mission_id: str
    receipt: dict[str, Any]


class SteerRunRequest(BaseModel):
    actor: str = Field("operator", min_length=1, max_length=200)
    directive: str = Field(..., min_length=1, max_length=10000)
    context: dict[str, Any] = Field(default_factory=dict)


class ConfigureRunGovernanceRequest(BaseModel):
    actor: str = Field("operator", min_length=1, max_length=200)
    goals: list[dict[str, Any]] = Field(default_factory=list)
    budgets: dict[str, float] = Field(default_factory=dict)


class TaskCheckoutRequest(BaseModel):
    actor: str = Field("operator", min_length=1, max_length=200)
    task_id: str = Field(..., min_length=1, max_length=200)
    agent_id: str = Field(..., min_length=1, max_length=200)
    goal_id: str = Field(..., min_length=1, max_length=200)
    budget_cost: float = Field(..., gt=0)
    ancestor_goal_id: str | None = Field(None, max_length=200)


class TaskCheckoutResponse(BaseModel):
    checkout_id: str
    task_id: str
    agent_id: str
    goal_id: str
    goal_ancestry: list[str] = Field(default_factory=list)
    budget_cost: float
    checked_out_at: str
    checked_out_by: str
    status: str


class RunCommandMutationResponse(BaseModel):
    run: RunStateResponse
    command: RunCommandResponse


class RunCheckoutMutationResponse(BaseModel):
    run: RunStateResponse
    checkout: TaskCheckoutResponse
    command: RunCommandResponse


class SwarmRuntimeRequest(BaseModel):
    actor: str = Field("operator", min_length=1, max_length=200)
    mode: str = Field(..., pattern="^(solo|assisted|pod|cell|simulation)$")
    base_budget_usd: float = Field(1.0, gt=0)
    estimated_minutes: int = Field(15, ge=1, le=1440)
    requested_workers: int | None = Field(None, ge=1, le=128)
    approval_threshold: str | None = Field(None, pattern="^(per_action|summary|mission|outcome|none)$")
    max_depth: int | None = Field(None, ge=0, le=8)
    max_concurrency: int | None = Field(None, ge=1, le=128)
    wall_clock_budget_seconds: int | None = Field(None, ge=60, le=86400)
    merge_strategy: str | None = Field(
        None,
        pattern="^(first_success|majority|weighted_vote|synthesized_merge|human_review)$",
    )
    side_effect_policy: str | None = Field(None, pattern="^(read_only|governed|approval_required)$")
    metadata: dict[str, Any] = Field(default_factory=dict)


class CompositionPlanRequest(BaseModel):
    actor: str = Field("operator", min_length=1, max_length=200)
    composition_plan: dict[str, Any] = Field(default_factory=dict)


class CompositionReprioritizeRequest(BaseModel):
    actor: str = Field("operator", min_length=1, max_length=200)
    reprioritize: dict[str, Any] = Field(default_factory=dict)


class SwarmRuntimeResponse(BaseModel):
    run: RunStateResponse
    command: RunCommandResponse
    swarm_mode: str
    proof_plane: str
    budget_envelope: dict[str, Any] = Field(default_factory=dict)
    swarm_monitor: dict[str, Any] = Field(default_factory=dict)


class RegisterPrincipalRequest(BaseModel):
    actor: str = Field("operator", min_length=1, max_length=200)
    agent_id: str = Field(..., min_length=1, max_length=200)
    worker_class: str = Field("synthesizer", pattern="^(researcher|validator|tool_runner|synthesizer|reviewer)$")
    metadata: dict[str, Any] = Field(default_factory=dict)


class WorkerDelegationRequest(BaseModel):
    actor: str = Field("operator", min_length=1, max_length=200)
    parent_agent_id: str = Field(..., min_length=1, max_length=200)
    child_agent_id: str = Field(..., min_length=1, max_length=200)
    worker_class: str = Field(..., pattern="^(researcher|validator|tool_runner|synthesizer|reviewer)$")
    budget_usd: float = Field(..., gt=0)
    allowed_tools: list[str] = Field(default_factory=list)
    allowed_operations: list[str] = Field(default_factory=list)
    allowed_memory_scopes: list[str] = Field(default_factory=list)
    max_depth: int | None = Field(None, ge=0, le=8)
    max_concurrency: int | None = Field(None, ge=1, le=128)
    max_wall_clock_seconds: int = Field(900, ge=60, le=86400)
    merge_strategy: str | None = Field(
        None,
        pattern="^(first_success|majority|weighted_vote|synthesized_merge|human_review)$",
    )
    approval_threshold: str | None = Field(None, pattern="^(per_action|summary|mission|outcome|none)$")
    metadata: dict[str, Any] = Field(default_factory=dict)


class WorkerIdentityTransitionRequest(BaseModel):
    actor: str = Field("operator", min_length=1, max_length=200)
    target_state: str = Field(..., pattern="^(active|expired|revoked|suspended)$")
    reason: str = Field("", max_length=5000)


class WorkerActionRequest(BaseModel):
    actor: str = Field("operator", min_length=1, max_length=200)
    tool_id: str = Field(..., min_length=1, max_length=200)
    operation_type: str = Field(..., min_length=1, max_length=200)
    cost_usd: float = Field(..., gt=0)
    memory_scope: str | None = Field(None, max_length=200)
    side_effect: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)
    signature: str | None = Field(None, min_length=1)
    outcome: str = Field("completed", min_length=1, max_length=200)


class SimulationRunRequest(BaseModel):
    actor: str = Field("operator", min_length=1, max_length=200)
    requested_by: str = Field(..., min_length=1, max_length=200)
    scenario: str = Field(..., min_length=1, max_length=10000)
    allowed_tools: list[str] = Field(default_factory=list)
    compare_to_run_id: str | None = Field(None, max_length=200)
    metadata: dict[str, Any] = Field(default_factory=dict)


class PrincipalIdentityResponse(BaseModel):
    run: RunStateResponse
    command: RunCommandResponse
    identity: dict[str, Any] = Field(default_factory=dict)


class WorkerDelegationResponse(BaseModel):
    run: RunStateResponse
    command: RunCommandResponse
    identity: dict[str, Any] = Field(default_factory=dict)
    warrant: dict[str, Any] = Field(default_factory=dict)
    lease: dict[str, Any] = Field(default_factory=dict)


class WorkerIdentityResponse(BaseModel):
    run: RunStateResponse
    command: RunCommandResponse
    identity: dict[str, Any] = Field(default_factory=dict)


class WorkerActionResponse(BaseModel):
    run: RunStateResponse
    command: RunCommandResponse
    action: dict[str, Any] = Field(default_factory=dict)


class SimulationRunResponse(BaseModel):
    run: RunStateResponse
    command: RunCommandResponse
    simulation: dict[str, Any] = Field(default_factory=dict)
    artifact: dict[str, Any] = Field(default_factory=dict)


class SwarmMonitorResponse(BaseModel):
    run_id: str
    mission_id: str
    swarm_monitor: dict[str, Any] = Field(default_factory=dict)


def _run_state_response_from_item(item: dict[str, Any]) -> RunStateResponse:
    return RunStateResponse(
        run_id=str(item.get("run_id", "")),
        mission_id=str(item.get("mission_id", "")),
        status=str(item.get("status", "")),
        revision=int(item.get("revision", 0)),
        command_count=int(item.get("command_count", 0)),
        last_command=str(item.get("last_command", "")),
        last_actor=str(item.get("last_actor", "")),
        created_at=str(item.get("created_at", "")),
        updated_at=str(item.get("updated_at", "")),
        paused_at=item.get("paused_at"),
        cancelled_at=item.get("cancelled_at"),
        completed_at=item.get("completed_at"),
        failed_at=item.get("failed_at"),
        failure_reason=str(item.get("failure_reason") or "") or None,
        root_block_id=str(item.get("root_block_id") or "") or None,
        steer_queue=list(item.get("steer_queue") or []),
        goals=dict(item.get("goals") or {}),
        goal_roots=list(item.get("goal_roots") or []),
        agent_budgets=dict(item.get("agent_budgets") or {}),
        agent_execution_budgets=dict(item.get("agent_execution_budgets") or {}),
        task_checkouts=dict(item.get("task_checkouts") or {}),
        execution_loop_state=dict(item.get("execution_loop_state") or {}),
        governance_stop_reason=str(item.get("governance_stop_reason") or "") or None,
        governance_stop_evidence_id=str(item.get("governance_stop_evidence_id") or "") or None,
        governance_stop_evidence_url=str(item.get("governance_stop_evidence_url") or "") or None,
        swarm_mode=str(item.get("swarm_mode") or "") or None,
        swarm_config=dict(item.get("swarm_config") or {}),
        budget_envelope=dict(item.get("budget_envelope") or {}),
        worker_identities=dict(item.get("worker_identities") or {}),
        delegation_warrants=dict(item.get("delegation_warrants") or {}),
        capability_leases=dict(item.get("capability_leases") or {}),
        lineage_nodes=dict(item.get("lineage_nodes") or {}),
        lineage_edges=dict(item.get("lineage_edges") or {}),
        swarm_activity=list(item.get("swarm_activity") or []),
        swarm_monitor=dict(item.get("swarm_monitor") or {}),
        simulation_runs=dict(item.get("simulation_runs") or {}),
        simulation_artifacts=dict(item.get("simulation_artifacts") or {}),
        worker_time_blocks={str(key): str(value) for key, value in dict(item.get("worker_time_blocks") or {}).items()},
        composition_plan=dict(item.get("composition_plan") or {}) or None,
    )


def _run_command_response_from_item(item: dict[str, Any]) -> RunCommandResponse:
    return RunCommandResponse(
        command_id=str(item.get("command_id", "")),
        command_seq=int(item.get("command_seq", 0)),
        run_id=str(item.get("run_id", "")),
        mission_id=str(item.get("mission_id", "")),
        command=str(item.get("command", "")),
        actor=str(item.get("actor", "")),
        payload=dict(item.get("payload") or {}),
        status_before=str(item.get("status_before", "")),
        status_after=str(item.get("status_after", "")),
        recorded_at=str(item.get("recorded_at", "")),
    )


async def _publish_mission_event(tenant_id: str, event_type: str, payload: dict[str, Any]) -> None:
    try:
        await mission_shared.get_event_bus().publish(tenant_id, event_type, payload)
    except (ConnectionError, OSError, ValueError, RuntimeError):
        logger.warning("mission_event_publish_failed tenant=%s type=%s", tenant_id, event_type, exc_info=True)


def _sync_goals_with_intelligence(tenant_id: str, goals: list[dict[str, Any]]) -> None:
    try:
        _get_intelligence_aggregator().sync_goals(tenant_id, goals)
    except (AttributeError, ValueError, KeyError, RuntimeError):
        logger.warning("mission_goal_sync_failed tenant=%s", tenant_id, exc_info=True)


def _raise_run_error(exc: ValueError) -> None:
    message = str(exc)
    if "not found" in message.lower():
        raise HTTPException(status_code=404, detail=message)
    raise HTTPException(status_code=409, detail=message)


class MissionWorkerLeaseResponse(BaseModel):
    worker_id: str
    leased_at: str
    lease_expires_at: str


class MissionAdmissionResponse(BaseModel):
    """Snapshot of the durable admission gate (issue #3282)."""

    tenant_id: str
    mission_id: str
    cap: int
    active_workers: int
    workers: list[MissionWorkerLeaseResponse] = Field(default_factory=list)


class MissionBreakerResponse(BaseModel):
    """Snapshot of the spawn circuit breaker (issue #3283)."""

    tenant_id: str
    mission_id: str
    state: str
    consecutive_failures: int
    backoff_seconds: int
    opened_at: str | None = None
    last_transition_at: str


class MissionBreakerResetRequest(BaseModel):
    reason: str = Field("operator override", max_length=500)


@missions_router.get(
    "/{mission_id}/breaker", response_model=MissionBreakerResponse
)
async def get_mission_breaker(
    mission_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Return the spawn circuit breaker state for a mission (issue #3283)."""
    from apps.backend.services.runtime.spawn_circuit_breaker import (
        get_spawn_circuit_breaker,
    )

    snap = await get_spawn_circuit_breaker().get_state(tenant_id, mission_id)
    return MissionBreakerResponse(
        tenant_id=snap.tenant_id,
        mission_id=snap.mission_id,
        state=snap.state.value,
        consecutive_failures=snap.consecutive_failures,
        backoff_seconds=snap.backoff_seconds,
        opened_at=snap.opened_at.isoformat() if snap.opened_at else None,
        last_transition_at=snap.last_transition_at.isoformat(),
    )


@missions_router.post(
    "/{mission_id}/breaker/reset", response_model=MissionBreakerResponse
)
async def reset_mission_breaker(
    mission_id: str,
    body: MissionBreakerResetRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Operator manual reset of the spawn circuit breaker (issue #3283)."""
    from apps.backend.services.runtime.spawn_circuit_breaker import (
        get_spawn_circuit_breaker,
    )

    snap = await get_spawn_circuit_breaker().reset(
        tenant_id, mission_id, reason=body.reason
    )
    return MissionBreakerResponse(
        tenant_id=snap.tenant_id,
        mission_id=snap.mission_id,
        state=snap.state.value,
        consecutive_failures=snap.consecutive_failures,
        backoff_seconds=snap.backoff_seconds,
        opened_at=snap.opened_at.isoformat() if snap.opened_at else None,
        last_transition_at=snap.last_transition_at.isoformat(),
    )


@missions_router.get(
    "/{mission_id}/admission", response_model=MissionAdmissionResponse
)
async def get_mission_admission(
    mission_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Return the per-Mission worker admission snapshot.

    Includes the durable cap (`max_workers_per_mission` from TenantConfig),
    the active worker count, and one row per active worker. Surface for
    issue #3282 — used by the CLI (`ww mission admission show`) and MCP tool
    (`ww.mission.admission`) for parity.
    """
    from apps.backend.services.runtime.mission_worker_admission import (
        get_mission_worker_admission,
    )

    snapshot = await get_mission_worker_admission().snapshot(tenant_id, mission_id)
    return MissionAdmissionResponse(
        tenant_id=snapshot.tenant_id,
        mission_id=snapshot.mission_id,
        cap=snapshot.cap,
        active_workers=snapshot.active_workers,
        workers=[
            MissionWorkerLeaseResponse(
                worker_id=lease.worker_id,
                leased_at=lease.leased_at.isoformat(),
                lease_expires_at=lease.lease_expires_at.isoformat(),
            )
            for lease in snapshot.workers
        ],
    )


@missions_router.get("/{mission_id}/ledger", response_model=LedgerResponse)
async def get_mission_ledger(
    mission_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(200, ge=1, le=1000, description="Max entries to return"),
):
    try:
        entries = mission_shared.get_contracts_service().get_ledger(tenant_id, mission_id, limit=limit)
        return LedgerResponse(
            mission_id=mission_id,
            entries=[
                LedgerEntryResponse(
                    entry_id=entry["entry_id"],
                    mission_id=entry["mission_id"],
                    entry_type=entry["entry_type"],
                    summary=entry["summary"],
                    actor=entry["actor"],
                    timestamp=entry["timestamp"],
                    metadata=entry.get("metadata", {}),
                )
                for entry in entries
            ],
            count=len(entries),
        )
    except (ValueError, KeyError):
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to get mission ledger: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to get mission ledger")


@missions_router.post("/{mission_id}/cancel", response_model=CancelMissionResponse)
async def cancel_mission(
    mission_id: str,
    request: CancelMissionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        state = mission_shared.get_contracts_service().cancel_mission(
            tenant_id,
            mission_id,
            reason=request.reason,
            actor=tenant_id,
        )
        return CancelMissionResponse(
            mission_id=state["mission_id"],
            status=state["status"],
            cancelled_at=state["cancelled_at"],
            cancelled_by=state["cancelled_by"],
            reason=state.get("cancellation_reason", ""),
        )
    except ValueError as exc:
        if "not found" in str(exc).lower():
            raise HTTPException(status_code=404, detail="Resource not found")
        raise HTTPException(status_code=409, detail="Conflict. Please refresh and retry.")
    except Exception as exc:
        logger.error("Failed to cancel mission: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to cancel mission")


@missions_router.get("/{mission_id}/replay", response_model=ReplayResponse)
async def get_mission_replay(
    mission_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        transitions = mission_shared.get_contracts_service().get_replay(tenant_id, mission_id)
        return ReplayResponse(
            mission_id=mission_id,
            transitions=[
                ReplayEntryResponse(
                    entry_id=entry["entry_id"],
                    mission_id=entry["mission_id"],
                    entry_type=entry["entry_type"],
                    summary=entry["summary"],
                    actor=entry["actor"],
                    timestamp=entry["timestamp"],
                    metadata=entry.get("metadata", {}),
                )
                for entry in transitions
            ],
            count=len(transitions),
        )
    except (ValueError, KeyError):
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to get mission replay: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to get mission replay")


@missions_router.post("/{mission_id}/reversal:request", response_model=dict[str, Any])
async def request_mission_reversal(
    mission_id: str,
    request: ReversalRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    from apps.backend.services.reversal_orchestrator import get_reversal_orchestrator

    try:
        return await get_reversal_orchestrator().request_reversal(
            mission_id,
            request.requested_by,
            tenant_id=tenant_id,
            dry_run=request.dry_run,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


# ---------------------------------------------------------------------------
# Reversal UI confirmation flow (Issue #3280)
# ---------------------------------------------------------------------------


@missions_router.post("/{mission_id}/reversal/preview", response_model=ReversalPreviewResponse)
async def reversal_preview(
    mission_id: str,
    request: ReversalPreviewRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ReversalPreviewResponse:
    """Preview reversal compensation actions for a mission.

    Returns a list of planned compensation actions with side-effect
    descriptions, plus a confirmation_token required for the execute step.
    This is a dry-run: no compensating actions are dispatched.
    """
    from apps.backend.services.reversal_orchestrator import get_reversal_orchestrator

    try:
        result = await get_reversal_orchestrator().request_reversal(
            mission_id,
            request.requested_by,
            tenant_id=tenant_id,
            dry_run=True,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    plan_data = result.get("plan") or {}
    raw_items = plan_data.get("items") or []
    items = [
        ReversalPreviewActionItem(
            original_evidence_id=item.get("original_evidence_id", ""),
            connector_id=item.get("connector_id", ""),
            operation_id=item.get("operation_id", ""),
            reversal_action=item.get("reversal_action"),
            compensation_taxonomy=item.get("compensation_taxonomy", "manual"),
            dispatchable=item.get("dispatchable", False),
            reason=item.get("reason"),
            original_event_at=item.get("original_event_at"),
            reversal_window_seconds=item.get("reversal_window_seconds"),
        )
        for item in raw_items
    ]

    confirmation_token = _reversal_confirmation_store.store(mission_id, tenant_id)

    # Emit a Decision Trace for the preview action
    await _publish_mission_event(
        tenant_id,
        "decision_trace:reversal.preview",
        {
            "tenant_id": tenant_id,
            "mission_id": mission_id,
            "actor": request.requested_by,
            "operation": "reversal.preview",
            "item_count": len(items),
            "confirmation_token_generated": True,
        },
    )

    return ReversalPreviewResponse(
        mission_id=mission_id,
        plan=items,
        confirmation_token=confirmation_token,
        count=len(items),
    )


@missions_router.post("/{mission_id}/reversal/execute", response_model=ReversalExecuteResponse)
async def reversal_execute(
    mission_id: str,
    request: ReversalExecuteRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ReversalExecuteResponse:
    """Execute a previously previewed reversal.

    Requires a valid confirmation_token from the preview step.
    The token is single-use and scoped to the mission/tenant pair.
    """
    if not _reversal_confirmation_store.consume(
        request.confirmation_token, mission_id, tenant_id,
    ):
        raise HTTPException(
            status_code=409,
            detail="Invalid or expired confirmation token. Please request a new preview.",
        )

    from apps.backend.services.reversal_orchestrator import get_reversal_orchestrator

    try:
        result = await get_reversal_orchestrator().request_reversal(
            mission_id,
            request.requested_by,
            tenant_id=tenant_id,
            dry_run=False,
        )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    receipt = result.get("receipt") or {}

    # Emit a Decision Trace for the execute action
    await _publish_mission_event(
        tenant_id,
        "decision_trace:reversal.execute",
        {
            "tenant_id": tenant_id,
            "mission_id": mission_id,
            "actor": request.requested_by,
            "operation": "reversal.execute",
            "receipt_status": receipt.get("status", "unknown"),
        },
    )

    return ReversalExecuteResponse(
        mission_id=mission_id,
        receipt=receipt,
    )


# ---------------------------------------------------------------------------
# Mission checkpoint create / list / diff (issue #3249)
# ---------------------------------------------------------------------------


class CheckpointCreateRequest(BaseModel):
    timeblock_id: str | None = Field(default=None, description="TimeBlock to associate")
    checkpoint_type: str = Field(default="manual", description="auto|manual|pre_restore")


class CheckpointCreateResponse(BaseModel):
    checkpoint_id: str
    mission_id: str
    checkpoint_type: str
    created_at: str
    status: str = "created"


@missions_router.post(
    "/{mission_id}/checkpoint",
    response_model=CheckpointCreateResponse,
    status_code=201,
)
async def create_mission_checkpoint(
    mission_id: str,
    request: CheckpointCreateRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    from apps.backend.models.mission_checkpoint import MissionCheckpoint, MissionSnapshot
    from apps.backend.services.mission_checkpoint_store import get_mission_checkpoint_store

    snapshot = MissionSnapshot()
    cp = MissionCheckpoint(
        tenant_id=tenant_id,
        mission_id=mission_id,
        timeblock_id=request.timeblock_id or "default",
        checkpoint_type=request.checkpoint_type,
        snapshot=snapshot,
        actor_id="api:checkpoint",
    )
    try:
        store = get_mission_checkpoint_store()
        created = store.create(cp)
        return CheckpointCreateResponse(
            checkpoint_id=created.checkpoint_id,
            mission_id=mission_id,
            checkpoint_type=created.checkpoint_type,
            created_at=str(created.created_at),
        )
    except Exception as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc


class CheckpointListResponse(BaseModel):
    mission_id: str
    checkpoints: list[dict[str, Any]]
    count: int


@missions_router.get(
    "/{mission_id}/checkpoints",
    response_model=CheckpointListResponse,
)
async def list_mission_checkpoints(
    mission_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    from apps.backend.services.mission_checkpoint_store import get_mission_checkpoint_store

    store = get_mission_checkpoint_store()
    checkpoints = store.list_by_mission(tenant_id, mission_id)
    items = [
        {
            "checkpoint_id": cp.checkpoint_id,
            "checkpoint_type": cp.checkpoint_type,
            "created_at": str(cp.created_at),
            "actor_id": cp.actor_id,
        }
        for cp in checkpoints
    ]
    return CheckpointListResponse(
        mission_id=mission_id,
        checkpoints=items,
        count=len(items),
    )


class CheckpointDiffResponse(BaseModel):
    checkpoint_a_id: str
    checkpoint_b_id: str
    has_changes: bool
    added_fields: dict[str, Any]
    removed_fields: dict[str, Any]
    changed_fields: dict[str, Any]


@missions_router.get(
    "/{mission_id}/checkpoint/{checkpoint_a}/diff/{checkpoint_b}",
    response_model=CheckpointDiffResponse,
)
async def diff_mission_checkpoints(
    mission_id: str,
    checkpoint_a: str,
    checkpoint_b: str,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    from apps.backend.services.mission_checkpoint_store import get_mission_checkpoint_store

    store = get_mission_checkpoint_store()
    try:
        diff = store.diff_checkpoints(
            checkpoint_a_id=checkpoint_a,
            checkpoint_b_id=checkpoint_b,
            tenant_id=tenant_id,
        )
        return CheckpointDiffResponse(
            checkpoint_a_id=checkpoint_a,
            checkpoint_b_id=checkpoint_b,
            has_changes=diff["has_changes"],
            added_fields=diff["added_fields"],
            removed_fields=diff["removed_fields"],
            changed_fields=diff["changed_fields"],
        )
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


# ---------------------------------------------------------------------------
# Mission checkpoint restore (issue #3246)
# ---------------------------------------------------------------------------


class CheckpointRestoreRequest(BaseModel):
    idempotency_key: str | None = Field(
        default=None,
        description="Optional idempotency key to prevent duplicate restores",
    )


class CheckpointRestoreResponse(BaseModel):
    checkpoint_id: str
    backup_id: str
    status: str
    snapshot_workitem_count: int = Field(
        default=0,
        description="Number of work items in the restored snapshot",
    )


@missions_router.post(
    "/{mission_id}/checkpoint/{checkpoint_id}/restore",
    response_model=CheckpointRestoreResponse,
)
async def restore_mission_checkpoint(
    mission_id: str,
    checkpoint_id: str,
    request: CheckpointRestoreRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    from apps.backend.services.mission_checkpoint_store import (
        get_mission_checkpoint_store,
    )

    try:
        store = get_mission_checkpoint_store()
        result = store.restore_checkpoint(
            checkpoint_id=checkpoint_id,
            mission_id=mission_id,
            tenant_id=tenant_id,
            idempotency_key=request.idempotency_key,
        )
        return CheckpointRestoreResponse(
            checkpoint_id=result.checkpoint_id,
            backup_id=result.backup_id,
            status=result.status,
            snapshot_workitem_count=len(result.snapshot.workitem_state),
        )
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except RuntimeError as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@missions_router.post("/{mission_id}/runs/{run_id}", response_model=RunStateResponse, status_code=201)
async def ensure_mission_run(
    mission_id: str,
    run_id: str,
    request: EnsureRunRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        state = mission_shared.get_run_state_service().ensure_run(
            tenant_id=tenant_id,
            mission_id=mission_id,
            run_id=run_id,
            actor=request.actor,
            metadata=request.metadata,
        )
        await _publish_mission_event(
            tenant_id,
            "mission.run.created",
            {
                "tenant_id": tenant_id,
                "mission_id": mission_id,
                "run_id": run_id,
                "status": state.get("status"),
                "command_seq": int(state.get("command_count", 0)),
            },
        )
        return _run_state_response_from_item(state)
    except ValueError as exc:
        _raise_run_error(exc)
    except Exception:
        logger.exception("Failed to ensure mission run: mission=%s run=%s", mission_id, run_id)
        raise HTTPException(status_code=500, detail="Failed to ensure mission run")


@missions_router.get("/runs/{run_id}", response_model=RunStateResponse)
async def get_mission_run(
    run_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        state = mission_shared.get_run_state_service().get_run(tenant_id=tenant_id, run_id=run_id)
        if state is None:
            raise HTTPException(status_code=404, detail=f"Run not found: {run_id}")
        return _run_state_response_from_item(state)
    except HTTPException:
        raise
    except Exception:
        logger.exception("Failed to fetch mission run: run=%s", run_id)
        raise HTTPException(status_code=500, detail="Failed to fetch mission run")


@missions_router.get("/runs/{run_id}/commands", response_model=RunCommandListResponse)
async def get_run_commands(
    run_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(200, ge=1, le=2000, description="Max command rows"),
):
    try:
        commands = mission_shared.get_run_state_service().list_commands(tenant_id=tenant_id, run_id=run_id, limit=limit)
        rows = [_run_command_response_from_item(item) for item in commands]
        return RunCommandListResponse(run_id=run_id, commands=rows, count=len(rows))
    except (ValueError, KeyError):
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception:
        logger.exception("Failed to get run command history: run=%s", run_id)
        raise HTTPException(status_code=500, detail="Failed to get run command history")


async def _apply_run_command(
    *,
    tenant_id: str,
    run_id: str,
    command: str,
    actor: str,
    payload: dict[str, Any],
) -> RunCommandMutationResponse:
    state, command_row = mission_shared.get_run_state_service().apply_command(
        tenant_id=tenant_id,
        run_id=run_id,
        command=command,
        actor=actor,
        payload=payload,
    )
    event_payload = {
        "tenant_id": tenant_id,
        "mission_id": str(state.get("mission_id", "")),
        "run_id": run_id,
        "command_id": command_row.get("command_id"),
        "command_seq": int(command_row.get("command_seq", 0)),
        "command": command,
        "actor": actor,
        "status": state.get("status"),
        "payload": payload,
    }
    await _publish_mission_event(tenant_id, "mission.command.issued", event_payload)
    await _publish_mission_event(tenant_id, "mission.run.state_changed", event_payload)
    return RunCommandMutationResponse(
        run=_run_state_response_from_item(state),
        command=_run_command_response_from_item(command_row),
    )


@router.post("/runs/{run_id}/pause", response_model=RunCommandMutationResponse)
@missions_router.post("/runs/{run_id}/pause", response_model=RunCommandMutationResponse, include_in_schema=False)
async def pause_run(
    run_id: str,
    request: RunControlRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        return await _apply_run_command(
            tenant_id=tenant_id,
            run_id=run_id,
            command="pause",
            actor=request.actor,
            payload={"reason": request.reason},
        )
    except ValueError as exc:
        _raise_run_error(exc)
    except Exception:
        logger.exception("Failed to pause run: run=%s", run_id)
        raise HTTPException(status_code=500, detail="Failed to pause run")


@router.post("/runs/{run_id}/resume", response_model=RunCommandMutationResponse)
@missions_router.post("/runs/{run_id}/resume", response_model=RunCommandMutationResponse, include_in_schema=False)
async def resume_run(
    run_id: str,
    request: RunControlRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        return await _apply_run_command(
            tenant_id=tenant_id,
            run_id=run_id,
            command="resume",
            actor=request.actor,
            payload={"reason": request.reason},
        )
    except ValueError as exc:
        _raise_run_error(exc)
    except Exception:
        logger.exception("Failed to resume run: run=%s", run_id)
        raise HTTPException(status_code=500, detail="Failed to resume run")


@router.post("/runs/{run_id}/cancel", response_model=RunCommandMutationResponse)
@missions_router.post("/runs/{run_id}/cancel", response_model=RunCommandMutationResponse, include_in_schema=False)
async def cancel_run(
    run_id: str,
    request: RunControlRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        return await _apply_run_command(
            tenant_id=tenant_id,
            run_id=run_id,
            command="cancel",
            actor=request.actor,
            payload={"reason": request.reason},
        )
    except ValueError as exc:
        _raise_run_error(exc)
    except Exception:
        logger.exception("Failed to cancel run: run=%s", run_id)
        raise HTTPException(status_code=500, detail="Failed to cancel run")


@router.post("/runs/{run_id}/steer", response_model=RunCommandMutationResponse)
@missions_router.post("/runs/{run_id}/steer", response_model=RunCommandMutationResponse, include_in_schema=False)
async def steer_run(
    run_id: str,
    request: SteerRunRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        return await _apply_run_command(
            tenant_id=tenant_id,
            run_id=run_id,
            command="steer",
            actor=request.actor,
            payload={"directive": request.directive, "context": request.context},
        )
    except ValueError as exc:
        _raise_run_error(exc)
    except Exception:
        logger.exception("Failed to steer run: run=%s", run_id)
        raise HTTPException(status_code=500, detail="Failed to steer run")


@router.get("/runs/{run_id}/composition", response_model=dict[str, Any])
@missions_router.get("/runs/{run_id}/composition", response_model=dict[str, Any], include_in_schema=False)
async def get_run_composition_plan(
    run_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        plan = mission_shared.get_run_state_service().get_composition_plan(tenant_id=tenant_id, run_id=run_id)
        return dict(plan or {})
    except ValueError as exc:
        _raise_run_error(exc)
    except Exception:
        logger.exception("Failed to fetch run composition plan: run=%s", run_id)
        raise HTTPException(status_code=500, detail="Failed to fetch run composition plan")


@router.get("/runs/{run_id}/metering/receipts", response_model=list[dict[str, Any]])
@missions_router.get(
    "/runs/{run_id}/metering/receipts",
    response_model=list[dict[str, Any]],
    include_in_schema=False,
)
async def list_run_metering_receipts(
    run_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """List typed execution receipts for a mission run (issue #1314)."""
    try:
        return mission_shared.get_run_state_service().list_execution_receipts(
            tenant_id=tenant_id,
            run_id=run_id,
        )
    except ValueError as exc:
        _raise_run_error(exc)
    except Exception:
        logger.exception("Failed to list metering receipts: run=%s", run_id)
        raise HTTPException(status_code=500, detail="Failed to list metering receipts")


@router.put("/runs/{run_id}/composition", response_model=RunCommandMutationResponse)
@missions_router.put("/runs/{run_id}/composition", response_model=RunCommandMutationResponse, include_in_schema=False)
async def set_run_composition_plan(
    run_id: str,
    request: CompositionPlanRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        state, command_row = mission_shared.get_run_state_service().set_composition_plan(
            tenant_id=tenant_id,
            run_id=run_id,
            actor=request.actor,
            composition_plan=request.composition_plan,
        )
        await _publish_mission_event(
            tenant_id,
            "mission.composition.updated",
            {
                "tenant_id": tenant_id,
                "run_id": run_id,
                "mission_id": str(state.get("mission_id", "")),
                "command_id": command_row.get("command_id"),
                "composition_plan": dict(state.get("composition_plan") or {}),
            },
        )
        return RunCommandMutationResponse(
            run=_run_state_response_from_item(state),
            command=_run_command_response_from_item(command_row),
        )
    except ValueError as exc:
        _raise_run_error(exc)
    except Exception:
        logger.exception("Failed to set run composition plan: run=%s", run_id)
        raise HTTPException(status_code=500, detail="Failed to set run composition plan")


@router.post("/runs/{run_id}/composition/reprioritize", response_model=RunCommandMutationResponse)
@missions_router.post(
    "/runs/{run_id}/composition/reprioritize",
    response_model=RunCommandMutationResponse,
    include_in_schema=False,
)
async def reprioritize_run_composition_plan(
    run_id: str,
    request: CompositionReprioritizeRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        state, command_row = mission_shared.get_run_state_service().reprioritize_composition_plan(
            tenant_id=tenant_id,
            run_id=run_id,
            actor=request.actor,
            reprioritize=request.reprioritize,
        )
        await _publish_mission_event(
            tenant_id,
            "mission.composition.reprioritized",
            {
                "tenant_id": tenant_id,
                "run_id": run_id,
                "mission_id": str(state.get("mission_id", "")),
                "command_id": command_row.get("command_id"),
                "reprioritize": request.reprioritize,
            },
        )
        return RunCommandMutationResponse(
            run=_run_state_response_from_item(state),
            command=_run_command_response_from_item(command_row),
        )
    except ValueError as exc:
        _raise_run_error(exc)
    except Exception:
        logger.exception("Failed to reprioritize run composition plan: run=%s", run_id)
        raise HTTPException(status_code=500, detail="Failed to reprioritize run composition plan")


@router.post("/runs/{run_id}/governance", response_model=RunCommandMutationResponse)
@missions_router.post("/runs/{run_id}/governance", response_model=RunCommandMutationResponse, include_in_schema=False)
async def configure_run_governance(
    run_id: str,
    request: ConfigureRunGovernanceRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        state, command_row = mission_shared.get_run_state_service().configure_governance(
            tenant_id=tenant_id,
            run_id=run_id,
            goals=request.goals,
            budgets=request.budgets,
            actor=request.actor,
        )
        event_payload = {
            "tenant_id": tenant_id,
            "mission_id": str(state.get("mission_id", "")),
            "run_id": run_id,
            "command_id": command_row.get("command_id"),
            "command_seq": int(command_row.get("command_seq", 0)),
            "goals": request.goals,
            "budgets": request.budgets,
        }
        _sync_goals_with_intelligence(tenant_id, request.goals)
        await _publish_mission_event(tenant_id, "mission.governance.updated", event_payload)
        return RunCommandMutationResponse(
            run=_run_state_response_from_item(state),
            command=_run_command_response_from_item(command_row),
        )
    except ValueError as exc:
        _raise_run_error(exc)
    except Exception:
        logger.exception("Failed to configure governance: run=%s", run_id)
        raise HTTPException(status_code=500, detail="Failed to configure run governance")


@router.get("/streams/events")
async def mission_stream_events(
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
    run_id: str | None = Query(None, description="Optional run filter"),
    since: str | None = Query(None, description="Optional replay lower bound"),
    backlog_limit: int = Query(200, ge=1, le=1000, description="Replay rows before live stream"),
    backlog_only: bool = Query(False, description="When true, stream only replay backlog then close"),
):
    from apps.backend.api import events as events_api

    return await events_api.mission_event_stream(
        request=request,
        x_tenant_id=tenant_id,
        run_id=run_id,
        since=since,
        backlog_limit=backlog_limit,
        backlog_only=backlog_only,
    )


@missions_router.post("/runs/{run_id}/checkout", response_model=RunCheckoutMutationResponse)
async def checkout_run_task(
    run_id: str,
    request: TaskCheckoutRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        state, checkout, command_row = mission_shared.get_run_state_service().checkout_task(
            tenant_id=tenant_id,
            run_id=run_id,
            task_id=request.task_id,
            agent_id=request.agent_id,
            goal_id=request.goal_id,
            budget_cost=request.budget_cost,
            actor=request.actor,
            ancestor_goal_id=request.ancestor_goal_id,
        )
        event_payload = {
            "tenant_id": tenant_id,
            "mission_id": str(state.get("mission_id", "")),
            "run_id": run_id,
            "command_id": command_row.get("command_id"),
            "command_seq": int(command_row.get("command_seq", 0)),
            "checkout": checkout,
        }
        await _publish_mission_event(tenant_id, "mission.task.checked_out", event_payload)
        return RunCheckoutMutationResponse(
            run=_run_state_response_from_item(state),
            checkout=TaskCheckoutResponse(**checkout),
            command=_run_command_response_from_item(command_row),
        )
    except ValueError as exc:
        _raise_run_error(exc)
    except Exception:
        logger.exception("Failed to checkout task: run=%s task=%s", run_id, request.task_id)
        raise HTTPException(status_code=500, detail="Failed to checkout task")


@missions_router.post("/runs/{run_id}/swarm", response_model=SwarmRuntimeResponse)
async def configure_swarm_runtime(
    run_id: str,
    request: SwarmRuntimeRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        state, command_row = mission_shared.get_run_state_service().configure_swarm_runtime(
            tenant_id=tenant_id,
            run_id=run_id,
            mode=request.mode,
            actor=request.actor,
            base_budget_usd=request.base_budget_usd,
            estimated_minutes=request.estimated_minutes,
            requested_workers=request.requested_workers,
            approval_threshold=request.approval_threshold,
            max_depth=request.max_depth,
            max_concurrency=request.max_concurrency,
            wall_clock_budget_seconds=request.wall_clock_budget_seconds,
            merge_strategy=request.merge_strategy,
            side_effect_policy=request.side_effect_policy,
            metadata=request.metadata,
        )
        await _publish_mission_event(
            tenant_id,
            "mission.swarm.updated",
            {
                "tenant_id": tenant_id,
                "run_id": run_id,
                "mission_id": str(state.get("mission_id", "")),
                "swarm_mode": str(state.get("swarm_mode", "")),
                "budget_envelope": dict(state.get("budget_envelope") or {}),
                "command_id": command_row.get("command_id"),
            },
        )
        return SwarmRuntimeResponse(
            run=_run_state_response_from_item(state),
            command=_run_command_response_from_item(command_row),
            swarm_mode=str(state.get("swarm_mode", "")),
            proof_plane=str((state.get("budget_envelope") or {}).get("proof_plane") or ""),
            budget_envelope=dict(state.get("budget_envelope") or {}),
            swarm_monitor=dict(state.get("swarm_monitor") or {}),
        )
    except ValueError as exc:
        _raise_run_error(exc)
    except Exception:
        logger.exception("Failed to configure swarm runtime: run=%s", run_id)
        raise HTTPException(status_code=500, detail="Failed to configure swarm runtime")


@missions_router.post("/runs/{run_id}/workers/principal", response_model=PrincipalIdentityResponse)
async def register_principal_worker(
    run_id: str,
    request: RegisterPrincipalRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        state, identity, command_row = mission_shared.get_run_state_service().register_principal_worker(
            tenant_id=tenant_id,
            run_id=run_id,
            agent_id=request.agent_id,
            actor=request.actor,
            worker_class=request.worker_class,
            metadata=request.metadata,
        )
        await _publish_mission_event(
            tenant_id,
            "mission.identity.registered",
            {
                "tenant_id": tenant_id,
                "run_id": run_id,
                "mission_id": str(state.get("mission_id", "")),
                "agent_id": request.agent_id,
                "identity": identity,
                "command_id": command_row.get("command_id"),
            },
        )
        return PrincipalIdentityResponse(
            run=_run_state_response_from_item(state),
            command=_run_command_response_from_item(command_row),
            identity=identity,
        )
    except ValueError as exc:
        _raise_run_error(exc)
    except Exception:
        logger.exception("Failed to register principal worker: run=%s agent=%s", run_id, request.agent_id)
        raise HTTPException(status_code=500, detail="Failed to register principal worker")


@missions_router.post("/runs/{run_id}/workers/delegate", response_model=WorkerDelegationResponse)
async def delegate_worker(
    run_id: str,
    request: WorkerDelegationRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        state, result, command_row = mission_shared.get_run_state_service().delegate_worker(
            tenant_id=tenant_id,
            run_id=run_id,
            parent_agent_id=request.parent_agent_id,
            child_agent_id=request.child_agent_id,
            worker_class=request.worker_class,
            budget_usd=request.budget_usd,
            actor=request.actor,
            allowed_tools=request.allowed_tools,
            allowed_operations=request.allowed_operations,
            allowed_memory_scopes=request.allowed_memory_scopes,
            max_depth=request.max_depth,
            max_concurrency=request.max_concurrency,
            max_wall_clock_seconds=request.max_wall_clock_seconds,
            merge_strategy=request.merge_strategy,
            approval_threshold=request.approval_threshold,
            metadata=request.metadata,
        )
        await _publish_mission_event(
            tenant_id,
            "mission.delegation.issued",
            {
                "tenant_id": tenant_id,
                "run_id": run_id,
                "mission_id": str(state.get("mission_id", "")),
                "identity": result.get("identity"),
                "warrant": result.get("warrant"),
                "lease": result.get("lease"),
                "command_id": command_row.get("command_id"),
            },
        )
        return WorkerDelegationResponse(
            run=_run_state_response_from_item(state),
            command=_run_command_response_from_item(command_row),
            identity=dict(result.get("identity") or {}),
            warrant=dict(result.get("warrant") or {}),
            lease=dict(result.get("lease") or {}),
        )
    except ValueError as exc:
        _raise_run_error(exc)
    except Exception:
        logger.exception("Failed to delegate worker: run=%s child=%s", run_id, request.child_agent_id)
        raise HTTPException(status_code=500, detail="Failed to delegate worker")


@missions_router.post("/runs/{run_id}/workers/{agent_id}/identity", response_model=WorkerIdentityResponse)
async def transition_worker_identity(
    run_id: str,
    agent_id: str,
    request: WorkerIdentityTransitionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        state, identity, command_row = mission_shared.get_run_state_service().transition_worker_identity(
            tenant_id=tenant_id,
            run_id=run_id,
            agent_id=agent_id,
            target_state=request.target_state,
            actor=request.actor,
            reason=request.reason,
        )
        await _publish_mission_event(
            tenant_id,
            "mission.identity.transitioned",
            {
                "tenant_id": tenant_id,
                "run_id": run_id,
                "mission_id": str(state.get("mission_id", "")),
                "agent_id": agent_id,
                "target_state": request.target_state,
                "command_id": command_row.get("command_id"),
            },
        )
        return WorkerIdentityResponse(
            run=_run_state_response_from_item(state),
            command=_run_command_response_from_item(command_row),
            identity=identity,
        )
    except ValueError as exc:
        _raise_run_error(exc)
    except Exception:
        logger.exception("Failed to transition identity: run=%s agent=%s", run_id, agent_id)
        raise HTTPException(status_code=500, detail="Failed to transition identity")


@missions_router.post("/runs/{run_id}/workers/{agent_id}/actions", response_model=WorkerActionResponse)
async def record_worker_action(
    run_id: str,
    agent_id: str,
    request: WorkerActionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        state, action, command_row = mission_shared.get_run_state_service().record_governed_action(
            tenant_id=tenant_id,
            run_id=run_id,
            agent_id=agent_id,
            tool_id=request.tool_id,
            operation_type=request.operation_type,
            cost_usd=request.cost_usd,
            actor=request.actor,
            memory_scope=request.memory_scope,
            side_effect=request.side_effect,
            metadata=request.metadata,
            signature=request.signature,
            outcome=request.outcome,
        )
        await _publish_mission_event(
            tenant_id,
            "mission.worker.action_recorded",
            {
                "tenant_id": tenant_id,
                "run_id": run_id,
                "mission_id": str(state.get("mission_id", "")),
                "agent_id": agent_id,
                "action": action,
                "command_id": command_row.get("command_id"),
            },
        )
        return WorkerActionResponse(
            run=_run_state_response_from_item(state),
            command=_run_command_response_from_item(command_row),
            action=action,
        )
    except ValueError as exc:
        _raise_run_error(exc)
    except Exception:
        logger.exception("Failed to record worker action: run=%s agent=%s", run_id, agent_id)
        raise HTTPException(status_code=500, detail="Failed to record worker action")


@missions_router.post("/runs/{run_id}/simulation", response_model=SimulationRunResponse)
async def start_simulation_run(
    run_id: str,
    request: SimulationRunRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        state, result, command_row = mission_shared.get_run_state_service().start_simulation_run(
            tenant_id=tenant_id,
            run_id=run_id,
            scenario=request.scenario,
            requested_by=request.requested_by,
            actor=request.actor,
            allowed_tools=request.allowed_tools,
            compare_to_run_id=request.compare_to_run_id,
            metadata=request.metadata,
        )
        await _publish_mission_event(
            tenant_id,
            "mission.simulation.started",
            {
                "tenant_id": tenant_id,
                "run_id": run_id,
                "mission_id": str(state.get("mission_id", "")),
                "simulation": result.get("simulation"),
                "artifact": result.get("artifact"),
                "command_id": command_row.get("command_id"),
            },
        )
        return SimulationRunResponse(
            run=_run_state_response_from_item(state),
            command=_run_command_response_from_item(command_row),
            simulation=dict(result.get("simulation") or {}),
            artifact=dict(result.get("artifact") or {}),
        )
    except ValueError as exc:
        _raise_run_error(exc)
    except Exception:
        logger.exception("Failed to start simulation run: run=%s", run_id)
        raise HTTPException(status_code=500, detail="Failed to start simulation run")


@missions_router.get("/runs/{run_id}/swarm-monitor", response_model=SwarmMonitorResponse)
async def get_swarm_monitor(
    run_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        state = mission_shared.get_run_state_service().get_run(tenant_id=tenant_id, run_id=run_id)
        if state is None:
            raise HTTPException(status_code=404, detail=f"Run not found: {run_id}")
        return SwarmMonitorResponse(
            run_id=run_id,
            mission_id=str(state.get("mission_id", "")),
            swarm_monitor=dict(state.get("swarm_monitor") or {}),
        )
    except HTTPException:
        raise
    except Exception:
        logger.exception("Failed to fetch swarm monitor: run=%s", run_id)
        raise HTTPException(status_code=500, detail="Failed to fetch swarm monitor")


__all__ = [
    "LedgerEntryResponse",
    "LedgerResponse",
    "CancelMissionRequest",
    "CancelMissionResponse",
    "ReplayEntryResponse",
    "ReplayResponse",
    "EnsureRunRequest",
    "RunStateResponse",
    "RunCommandResponse",
    "RunCommandListResponse",
    "RunControlRequest",
    "ReversalRequest",
    "ReversalPreviewRequest",
    "ReversalPreviewResponse",
    "ReversalPreviewActionItem",
    "ReversalExecuteRequest",
    "ReversalExecuteResponse",
    "SteerRunRequest",
    "ConfigureRunGovernanceRequest",
    "SwarmRuntimeRequest",
    "CompositionPlanRequest",
    "CompositionReprioritizeRequest",
    "SwarmRuntimeResponse",
    "RegisterPrincipalRequest",
    "WorkerDelegationRequest",
    "WorkerIdentityTransitionRequest",
    "WorkerActionRequest",
    "SimulationRunRequest",
    "PrincipalIdentityResponse",
    "WorkerDelegationResponse",
    "WorkerIdentityResponse",
    "WorkerActionResponse",
    "SimulationRunResponse",
    "SwarmMonitorResponse",
    "TaskCheckoutRequest",
    "TaskCheckoutResponse",
    "RunCommandMutationResponse",
    "RunCheckoutMutationResponse",
    "get_mission_ledger",
    "cancel_mission",
    "get_mission_replay",
    "request_mission_reversal",
    "reversal_preview",
    "reversal_execute",
    "ensure_mission_run",
    "get_mission_run",
    "get_run_commands",
    "pause_run",
    "resume_run",
    "cancel_run",
    "steer_run",
    "get_run_composition_plan",
    "set_run_composition_plan",
    "reprioritize_run_composition_plan",
    "configure_run_governance",
    "mission_stream_events",
    "checkout_run_task",
    "configure_swarm_runtime",
    "register_principal_worker",
    "delegate_worker",
    "transition_worker_identity",
    "record_worker_action",
    "start_simulation_run",
    "get_swarm_monitor",
    "CheckpointCreateRequest",
    "CheckpointCreateResponse",
    "create_mission_checkpoint",
    "CheckpointListResponse",
    "list_mission_checkpoints",
    "CheckpointDiffResponse",
    "diff_mission_checkpoints",
    "CheckpointRestoreRequest",
    "CheckpointRestoreResponse",
    "restore_mission_checkpoint",
    "_reversal_confirmation_store",
]
