"""Canonical WorkItem API."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Response, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

router = APIRouter(prefix="/api/v1/work-items", tags=["work-items"])

UNIFIED_STATUS_PATTERN = "^(active|paused|blocked|in_progress|review|done|archived|cancelled)$"
SOURCE_KIND_PATTERN = "^(goal|task)$"


def _get_goal_store():
    from apps.backend.api.goals import _get_goal_store as _factory

    return _factory()


def _get_task_store():
    from apps.backend.services.task_store import get_task_store

    return get_task_store()


def _get_workitem_service():
    from apps.backend.services.execution.workitem_service import get_workitem_service

    return get_workitem_service()


def _get_intelligence_aggregator():
    from apps.backend.api.goals import _get_intelligence_aggregator as _factory

    return _factory()


def _get_evidence_ledger_service():
    from apps.backend.api.goals import _get_evidence_ledger_service as _factory

    return _factory()


class WorkItemResponse(BaseModel):
    id: str
    tenant_id: str | None = None
    goal_id: str | None = None
    task_id: str | None = None
    source_kind: str
    title: str
    description: str = ""
    success_criteria: str = ""
    assigned_agent: str | None = None
    status: str
    priority: str
    due_date: str | None = None
    recurrence_cron: str | None = None
    revision: int
    tags: list[str] = Field(default_factory=list)
    attachments: list[dict[str, Any]] = Field(default_factory=list)
    created_at: str
    updated_at: str
    parent_item_id: str | None = None
    legacy_status: str
    legacy_endpoint: str
    evidence_refs: list[Any] = Field(default_factory=list)
    evidence_trail: list[Any] = Field(default_factory=list)
    task_history: list[dict[str, Any]] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    # Issue #2747: optional connector snapshot consumed by the runtime
    # TimeBlock connector status badge. Populated from the connector that
    # ran the work item plus the latest /api/v1/connectors/{id}/health
    # snapshot. Shape mirrors the badge's prop schema so the UI does not
    # need to translate.
    connector: dict[str, Any] | None = None


class WorkItemListResponse(BaseModel):
    items: list[WorkItemResponse] = Field(default_factory=list)
    count: int


class WorkItemTimelineEntryResponse(BaseModel):
    id: str = ""
    kind: str = ""
    title: str = ""
    detail: str = ""
    status: str = ""
    timestamp: str = ""
    source: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


class WorkItemConversationResponse(BaseModel):
    status: str = "unlinked"
    thread_id: str = ""
    channel: str = ""
    thread_kind: str = ""
    subject: str = ""
    contact: str = ""
    participants: list[str] = Field(default_factory=list)
    last_message: str = ""
    last_message_at: str = ""
    message_count: int = 0
    outcome: str = ""
    channel_events: list[dict[str, Any]] = Field(default_factory=list)
    messages: list[dict[str, Any]] = Field(default_factory=list)
    links: dict[str, str] = Field(default_factory=dict)


class WorkItemEvidenceResponse(BaseModel):
    attachments: list[dict[str, Any]] = Field(default_factory=list)
    trail: list[Any] = Field(default_factory=list)
    decision_event_ids: list[str] = Field(default_factory=list)
    recording_refs: list[dict[str, Any]] = Field(default_factory=list)
    summary: dict[str, Any] = Field(default_factory=dict)
    links: dict[str, str] = Field(default_factory=dict)


class WorkItemMemoryResponse(BaseModel):
    status: str = "empty"
    query: str = ""
    items: list[dict[str, Any]] = Field(default_factory=list)
    source: str = ""
    captured_at: str = ""
    links: dict[str, str] = Field(default_factory=dict)


class WorkItemDetailBundleResponse(BaseModel):
    overview: WorkItemResponse
    timeline: list[WorkItemTimelineEntryResponse] = Field(default_factory=list)
    conversation: WorkItemConversationResponse = Field(default_factory=WorkItemConversationResponse)
    evidence: WorkItemEvidenceResponse = Field(default_factory=WorkItemEvidenceResponse)
    memory: WorkItemMemoryResponse = Field(default_factory=WorkItemMemoryResponse)


class CreateWorkItemRequest(BaseModel):
    source_kind: str = Field(..., pattern=SOURCE_KIND_PATTERN)
    title: str = Field(..., min_length=1, max_length=200)
    description: str = Field("", max_length=5000)
    success_criteria: str = Field("", max_length=2000)
    assigned_agent: str | None = Field(None, max_length=100)
    status: str | None = Field(None, pattern=UNIFIED_STATUS_PATTERN)
    priority: str = Field("medium", max_length=50)
    due_date: str | None = Field(None)
    recurrence_cron: str | None = Field(None, max_length=200)
    parent_item_id: str | None = Field(None, max_length=200)
    tags: list[str] = Field(default_factory=list)
    attachments: list[dict[str, Any]] = Field(default_factory=list)
    idempotency_key: str | None = Field(None, max_length=200)


class UpdateWorkItemRequest(BaseModel):
    revision: int = Field(..., ge=1)
    title: str | None = Field(None, min_length=1, max_length=200)
    description: str | None = Field(None, max_length=5000)
    success_criteria: str | None = Field(None, max_length=2000)
    assigned_agent: str | None = Field(None, max_length=100)
    status: str | None = Field(None, pattern=UNIFIED_STATUS_PATTERN)
    priority: str | None = Field(None, max_length=50)
    due_date: str | None = Field(None)
    recurrence_cron: str | None = Field(None, max_length=200)
    parent_item_id: str | None = Field(None, max_length=200)
    tags: list[str] | None = None
    attachments: list[dict[str, Any]] | None = None


def _resolve_item(
    *,
    tenant_id: str,
    item_id: str,
    source_kind: str | None,
    workitems: Any,
    goal_store: Any,
    task_store: Any,
) -> dict[str, Any]:
    try:
        item = workitems.get_work_item(
            tenant_id=tenant_id,
            item_id=item_id,
            source_kind=source_kind,
            goal_store=goal_store,
            task_store=task_store,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to load WorkItem") from exc
    if item is None:
        raise HTTPException(status_code=404, detail="WorkItem not found")
    return item


@router.get("", response_model=WorkItemListResponse)
def list_work_items(
    tenant_id: str = Depends(get_verified_tenant_id),
    status: str | None = Query(None, description="Unified WorkItem status filter"),
    agent_id: str | None = Query(None, description="Assigned agent filter"),
    source_kind: str | None = Query(None, pattern=SOURCE_KIND_PATTERN),
    limit: int = Query(50, ge=1, le=500),
    workitems: Any = Depends(_get_workitem_service),
    goal_store: Any = Depends(_get_goal_store),
    task_store: Any = Depends(_get_task_store),
) -> WorkItemListResponse:
    try:
        items, count = workitems.query_work_items(
            tenant_id=tenant_id,
            goal_store=goal_store,
            task_store=task_store,
            status=status,
            agent_id=agent_id,
            source_kind=source_kind,
            limit=limit,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to list WorkItems") from exc
    return WorkItemListResponse(items=items, count=count)


@router.post("", response_model=WorkItemResponse, status_code=status.HTTP_201_CREATED)
async def create_work_item(
    body: CreateWorkItemRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    x_idempotency_key: str | None = Header(default=None, alias="x-idempotency-key"),
    workitems: Any = Depends(_get_workitem_service),
    goal_store: Any = Depends(_get_goal_store),
    task_store: Any = Depends(_get_task_store),
    aggregator: Any = Depends(_get_intelligence_aggregator),
    evidence_ledger: Any = Depends(_get_evidence_ledger_service),
) -> WorkItemResponse:
    idempotency_key = str(x_idempotency_key or body.idempotency_key or "").replace("\x00", "").strip() or None

    try:
        item = await workitems.create_work_item(
            tenant_id=tenant_id,
            payload=body.model_dump(),
            goal_store=goal_store,
            task_store=task_store,
            aggregator=aggregator,
            evidence_ledger=evidence_ledger,
            idempotency_key=idempotency_key,
        )
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=400, detail="Invalid WorkItem data") from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to create WorkItem") from exc
    return WorkItemResponse(**item)


@router.get("/{item_id}/detail-bundle", response_model=WorkItemDetailBundleResponse)
def get_work_item_detail_bundle(
    item_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    source_kind: str | None = Query(None, pattern=SOURCE_KIND_PATTERN),
    workitems: Any = Depends(_get_workitem_service),
    goal_store: Any = Depends(_get_goal_store),
    task_store: Any = Depends(_get_task_store),
) -> WorkItemDetailBundleResponse:
    try:
        bundle = workitems.get_work_item_detail_bundle(
            tenant_id=tenant_id,
            item_id=item_id,
            source_kind=source_kind,
            goal_store=goal_store,
            task_store=task_store,
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to load WorkItem detail bundle") from exc
    if bundle is None:
        raise HTTPException(status_code=404, detail="WorkItem not found")
    return WorkItemDetailBundleResponse(**bundle)


@router.get("/{item_id}", response_model=WorkItemResponse)
def get_work_item(
    item_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    source_kind: str | None = Query(None, pattern=SOURCE_KIND_PATTERN),
    workitems: Any = Depends(_get_workitem_service),
    goal_store: Any = Depends(_get_goal_store),
    task_store: Any = Depends(_get_task_store),
) -> WorkItemResponse:
    item = _resolve_item(
        tenant_id=tenant_id,
        item_id=item_id,
        source_kind=source_kind,
        workitems=workitems,
        goal_store=goal_store,
        task_store=task_store,
    )
    return WorkItemResponse(**item)


@router.patch("/{item_id}", response_model=WorkItemResponse)
def update_work_item(
    item_id: str,
    body: UpdateWorkItemRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    source_kind: str | None = Query(None, pattern=SOURCE_KIND_PATTERN),
    workitems: Any = Depends(_get_workitem_service),
    goal_store: Any = Depends(_get_goal_store),
    task_store: Any = Depends(_get_task_store),
    evidence_ledger: Any = Depends(_get_evidence_ledger_service),
) -> WorkItemResponse:
    try:
        item = workitems.update_work_item(
            tenant_id=tenant_id,
            item_id=item_id,
            payload=body.model_dump(exclude_unset=True),
            fields_set=set(body.model_fields_set),
            source_kind=source_kind,
            goal_store=goal_store,
            task_store=task_store,
            evidence_ledger=evidence_ledger,
        )
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to update WorkItem") from exc
    return WorkItemResponse(**item)


@router.delete("/{item_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_work_item(
    item_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    source_kind: str | None = Query(None, pattern=SOURCE_KIND_PATTERN),
    workitems: Any = Depends(_get_workitem_service),
    goal_store: Any = Depends(_get_goal_store),
    task_store: Any = Depends(_get_task_store),
) -> Response:
    try:
        workitems.delete_work_item(
            tenant_id=tenant_id,
            item_id=item_id,
            source_kind=source_kind,
            goal_store=goal_store,
            task_store=task_store,
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail="WorkItem not found") from exc
    except HTTPException:
        raise
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to delete WorkItem") from exc
    return Response(status_code=status.HTTP_204_NO_CONTENT)
