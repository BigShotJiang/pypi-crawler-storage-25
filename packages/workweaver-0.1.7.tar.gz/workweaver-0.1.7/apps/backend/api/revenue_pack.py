from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, get_verified_user_id
from apps.backend.models.approval_request import ApprovalStatus
from apps.backend.services.approval_gates import ApprovalActionResult
from apps.backend.services.approval_service import ApprovalService
from apps.backend.services.human_judgment_service import HumanJudgmentError, HumanJudgmentService
from apps.backend.services.mission_contracts import MissionStatus


router = APIRouter(prefix="/api/v1/revenue-pack", tags=["revenue-pack"])


def _get_approval_gates():
    from apps.backend.services.approval_gates import get_approval_gates

    return get_approval_gates()


def _get_decision_service():
    from apps.backend.services.context.decision_event_capture import DecisionEventCaptureService

    return DecisionEventCaptureService()


def _get_mission_contracts_service():
    from apps.backend.services.mission_contracts import get_mission_contracts_service

    return get_mission_contracts_service()


def _get_run_state_service():
    from apps.backend.services.mission_run.state import get_mission_run_state_service

    return get_mission_run_state_service()


def _get_human_judgment_service():
    gates = _get_approval_gates()
    return HumanJudgmentService(
        approval_service=ApprovalService(approval_gates=gates),
        approval_gates=gates,
    )


def _raise_human_judgment_http_error(exc: HumanJudgmentError) -> None:
    raise HTTPException(
        status_code=exc.status_code,
        detail={
            "error": exc.code,
            "message": str(exc),
        },
    ) from exc


class RevenuePackMission(BaseModel):
    mission_id: str
    mission_type: str
    subject_id: str = ""
    brief: str
    risk_level: str = "low"
    approval_state: str
    created_at: str
    approval_request_id: str | None = None
    approval_context: dict[str, Any] = Field(default_factory=dict)
    artifacts: list[dict[str, Any]] = Field(default_factory=list)
    outcome: str | None = None


class RevenuePackApprovalRequest(BaseModel):
    action: str = Field(..., pattern="^(approve|reject)$")
    approved_by: str | None = None
    reason: str | None = None


class RevenuePackApprovalResponse(BaseModel):
    success: bool
    mission_id: str
    approval_state: str
    approval_request_id: str


class RevenuePackProofCard(BaseModel):
    card_id: str
    title: str
    summary: str | None = None
    mission_type: str | None = None
    created_at: str
    verified: bool = False
    decision_trace_available: bool = False
    decision_trace_url: str | None = None
    evidence_refs: list[str] = Field(default_factory=list)
    approval_context: dict[str, Any] = Field(default_factory=dict)


def _approval_status_to_state(status_value: str) -> str:
    mapping = {
        ApprovalStatus.PENDING.value: "pending_approval",
        ApprovalStatus.APPROVED.value: "approved",
        ApprovalStatus.REJECTED.value: "rejected",
        ApprovalStatus.EXPIRED.value: "rejected",
    }
    return mapping.get(str(status_value or "").strip().lower(), "pending_approval")


def _mission_status_to_state(status_value: str) -> str:
    normalized = str(status_value or "").strip().lower()
    mapping = {
        MissionStatus.PENDING.value: "draft",
        MissionStatus.ACTIVE.value: "approved",
        MissionStatus.PAUSED.value: "approved",
        MissionStatus.CANCELLED.value: "rejected",
        MissionStatus.COMPLETED.value: "completed",
        MissionStatus.FAILED.value: "rejected",
    }
    return mapping.get(normalized, "draft")


def _humanize_approval(metadata: dict[str, Any], tool_name: str, tool_params: dict[str, Any] | None) -> str:
    for key in ("description", "message", "summary", "title", "detail", "why_review_needed"):
        value = metadata.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()

    params = tool_params or {}
    for key in ("subject", "brief", "content", "preview", "email_subject", "record_id"):
        value = params.get(key)
        if isinstance(value, str) and value.strip():
            return value.strip()

    return str(tool_name or "Approval required").replace(".", " ").replace("_", " ").strip().title()


def _subject_id_from_metadata(metadata: dict[str, Any], tool_params: dict[str, Any] | None) -> str:
    for source in (metadata, tool_params or {}):
        for key in ("subject_id", "record_id", "lead_id", "deal_id", "contact_id", "entity_id"):
            value = source.get(key)
            if value is None:
                continue
            text = str(value).strip()
            if text:
                return text
    return ""


def _project_approval_request(request: dict[str, Any]) -> RevenuePackMission:
    metadata = request.get("metadata") or {}
    tool_name = str(request.get("tool_name") or "approval")
    tool_params = request.get("tool_params") if isinstance(request.get("tool_params"), dict) else {}
    request_id = str(request.get("request_id") or "")
    return RevenuePackMission(
        mission_id=request_id,
        mission_type=tool_name,
        subject_id=_subject_id_from_metadata(metadata, tool_params),
        brief=_humanize_approval(metadata, tool_name, tool_params),
        risk_level=str(metadata.get("risk_level") or metadata.get("severity") or "medium"),
        approval_state=_approval_status_to_state(str(request.get("status") or ApprovalStatus.PENDING.value)),
        created_at=str(request.get("created_at") or ""),
        approval_request_id=request_id,
        approval_context={
            "state": _approval_status_to_state(str(request.get("status") or ApprovalStatus.PENDING.value)),
            "why_review_needed": _humanize_approval(metadata, tool_name, tool_params),
            "risk_level": str(metadata.get("risk_level") or metadata.get("severity") or "medium"),
            "expires_at": str(request.get("expires_at") or metadata.get("expires_at") or ""),
            "tool_name": tool_name,
        },
        artifacts=[],
        outcome=None,
    )


def _project_mission_state(state: dict[str, Any]) -> RevenuePackMission:
    mission_id = str(state.get("mission_id") or "")
    mission_name = str(state.get("name") or "").strip()
    raw_status = str(state.get("status") or MissionStatus.PENDING.value)
    return RevenuePackMission(
        mission_id=mission_id,
        mission_type="mission_runtime",
        subject_id=mission_id,
        brief=mission_name or mission_id or "Mission",
        risk_level="low",
        approval_state=_mission_status_to_state(raw_status),
        created_at=str(state.get("created_at") or state.get("updated_at") or ""),
        approval_request_id=None,
        approval_context={"state": _mission_status_to_state(raw_status)},
        artifacts=[],
        outcome=raw_status,
    )


def _project_decision_card(tenant_id: str, decision: Any) -> RevenuePackProofCard:
    trace_id = str(getattr(decision, "trace_id", "") or "")
    summary = str(getattr(decision, "decision_summary", "") or "").strip()
    rationale = str(getattr(decision, "rationale", "") or "").strip()
    outcome = str(getattr(decision, "outcome", "") or "").strip().lower()
    evidence_refs = [f"{tenant_id}/DECISION#{trace_id}"] if trace_id else []
    return RevenuePackProofCard(
        card_id=trace_id,
        title=summary or trace_id or "Proof card",
        summary=rationale or summary or None,
        mission_type=str(getattr(decision, "decision_type", "") or "").strip() or None,
        created_at=str(getattr(decision, "created_at", "") or ""),
        verified=outcome == "success",
        decision_trace_available=bool(trace_id),
        decision_trace_url=f"/api/v1/evidence/decisions/{trace_id}" if trace_id else None,
        evidence_refs=evidence_refs,
        approval_context={},
    )


def _project_lineage_card(state: dict[str, Any]) -> RevenuePackProofCard | None:
    run_id = str(state.get("run_id") or "").strip()
    if not run_id:
        return None
    budget = dict(state.get("budget_envelope") or {})
    nodes = dict(state.get("lineage_nodes") or {})
    identities = dict(state.get("worker_identities") or {})
    simulations = dict(state.get("simulation_runs") or {})
    swarm_activity = list(state.get("swarm_activity") or [])
    if not nodes and not identities and not simulations and not swarm_activity:
        return None

    swarm_mode = str(state.get("swarm_mode") or budget.get("swarm_mode") or "solo").strip().lower() or "solo"
    proof_plane = str(budget.get("proof_plane") or "production").strip().lower() or "production"
    worker_count = len(
        [
            payload
            for payload in identities.values()
            if isinstance(payload, dict) and str(payload.get("identity_kind") or "") == "child_worker"
        ]
    )
    simulation_count = len(simulations)
    title = f"{swarm_mode.title()} mission run"
    summary = (
        f"{worker_count} governed worker(s) on the {proof_plane} plane."
        if proof_plane == "production"
        else f"{simulation_count or 1} simulation artifact(s) with side effects blocked."
    )
    evidence_refs = list(nodes.keys())[:8]
    return RevenuePackProofCard(
        card_id=run_id,
        title=title,
        summary=summary,
        mission_type=swarm_mode,
        created_at=str(state.get("updated_at") or state.get("created_at") or ""),
        verified=proof_plane == "production" and bool(nodes),
        decision_trace_available=True,
        decision_trace_url=f"/api/v1/evidence/lineage/{run_id}",
        evidence_refs=evidence_refs,
        approval_context={
            "state": str(state.get("status") or ""),
            "swarm_mode": swarm_mode,
            "proof_plane": proof_plane,
            "run_id": run_id,
            "worker_count": worker_count,
            "budget_used_usd": str(budget.get("used_usd") or "0"),
            "budget_approved_usd": str(budget.get("approved_usd") or "0"),
            "export_url": f"/api/v1/evidence/audit-bundle/{run_id}",
        },
    )


def _approval_failure_status(action_result: ApprovalActionResult | None) -> int:
    if action_result == ApprovalActionResult.NOT_FOUND:
        return status.HTTP_404_NOT_FOUND
    if action_result == ApprovalActionResult.UNAUTHORIZED:
        return status.HTTP_403_FORBIDDEN
    if action_result == ApprovalActionResult.SERVICE_UNAVAILABLE:
        return status.HTTP_503_SERVICE_UNAVAILABLE
    return status.HTTP_409_CONFLICT


@router.get("/missions", response_model=list[RevenuePackMission])
async def list_revenue_pack_missions(
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(50, ge=1, le=200),
) -> list[RevenuePackMission]:
    contracts = _get_mission_contracts_service()
    approvals = _get_approval_gates()
    run_state = _get_run_state_service()

    mission_rows: list[RevenuePackMission] = []
    seen: set[str] = set()

    for state in contracts.list_mission_states(tenant_id, limit=limit):
        row = _project_mission_state(state)
        if not row.mission_id or row.mission_id in seen:
            continue
        mission_rows.append(row)
        seen.add(row.mission_id)

    for state in run_state.list_runs(tenant_id=tenant_id, limit=limit):
        run_id = str(state.get("run_id") or "").strip()
        if not run_id or run_id in seen:
            continue
        if not state.get("swarm_activity") and not state.get("worker_identities") and not state.get("task_checkouts"):
            continue
        swarm_mode = str(state.get("swarm_mode") or "solo")
        approval_state = "completed" if str(state.get("status") or "").strip().lower() == "completed" else "approved"
        budget = dict(state.get("budget_envelope") or {})
        swarm_monitor = dict(state.get("swarm_monitor") or {})
        mission_rows.append(
            RevenuePackMission(
                mission_id=run_id,
                mission_type=f"swarm_{swarm_mode}",
                subject_id=str(state.get("mission_id") or ""),
                brief=f"{swarm_mode.title()} run for {str(state.get('mission_id') or run_id)}",
                risk_level="low" if str(budget.get("proof_plane") or "production") == "production" else "medium",
                approval_state=approval_state,
                created_at=str(state.get("updated_at") or state.get("created_at") or ""),
                approval_request_id=None,
                approval_context={
                    "state": approval_state,
                    "swarm_mode": swarm_mode,
                    "proof_plane": str(budget.get("proof_plane") or "production"),
                    "run_id": run_id,
                    "active_worker_count": int(swarm_monitor.get("active_worker_count") or 0),
                    "lease_count": int(swarm_monitor.get("lease_count") or 0),
                    "budget_used_usd": str(swarm_monitor.get("used_budget_usd") or budget.get("used_usd") or "0"),
                    "budget_approved_usd": str(
                        swarm_monitor.get("approved_budget_usd") or budget.get("approved_usd") or "0"
                    ),
                    "export_url": f"/api/v1/evidence/audit-bundle/{run_id}",
                },
                artifacts=[],
                outcome=str(state.get("status") or ""),
            )
        )
        seen.add(run_id)

    approval_result = approvals.list_pending_approvals(tenant_id=tenant_id)
    if not approval_result.success:
        raise HTTPException(status_code=500, detail="Failed to list approval-backed missions")

    approval_requests = approval_result.metadata.get("approvals", [])
    if isinstance(approval_requests, list):
        for request in approval_requests:
            if not isinstance(request, dict):
                continue
            row = _project_approval_request(request)
            if not row.mission_id or row.mission_id in seen:
                continue
            mission_rows.append(row)
            seen.add(row.mission_id)

    mission_rows.sort(key=lambda row: row.created_at or "", reverse=True)
    return mission_rows[:limit]


@router.post(
    "/missions/{mission_id}/approval",
    response_model=RevenuePackApprovalResponse,
    status_code=status.HTTP_200_OK,
)
async def update_revenue_pack_approval(
    mission_id: str,
    request: RevenuePackApprovalRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
) -> RevenuePackApprovalResponse:
    service = _get_human_judgment_service()

    if request.action == "approve":
        try:
            await service.approve_request(
                tenant_id=tenant_id,
                request_id=mission_id,
                actor_id=actor_id,
                reason=request.reason,
                source="revenue_pack",
            )
        except HumanJudgmentError as exc:
            _raise_human_judgment_http_error(exc)
        return RevenuePackApprovalResponse(
            success=True,
            mission_id=mission_id,
            approval_state="approved",
            approval_request_id=mission_id,
        )

    try:
        await service.reject_request(
            tenant_id=tenant_id,
            request_id=mission_id,
            actor_id=actor_id,
            reason=str(request.reason or "No reason provided"),
            source="revenue_pack",
        )
    except HumanJudgmentError as exc:
        _raise_human_judgment_http_error(exc)
    return RevenuePackApprovalResponse(
        success=True,
        mission_id=mission_id,
        approval_state="rejected",
        approval_request_id=mission_id,
    )


@router.get("/proof-cards", response_model=list[RevenuePackProofCard])
async def list_revenue_pack_proof_cards(
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(50, ge=1, le=200),
) -> list[RevenuePackProofCard]:
    decision_service = _get_decision_service()
    run_state = _get_run_state_service()
    cards: list[RevenuePackProofCard] = []
    seen: set[str] = set()

    for state in run_state.list_runs(tenant_id=tenant_id, limit=limit):
        lineage_card = _project_lineage_card(state)
        if lineage_card is None or lineage_card.card_id in seen:
            continue
        cards.append(lineage_card)
        seen.add(lineage_card.card_id)

    decisions = decision_service.list_decisions(tenant_id=tenant_id, limit=limit)
    for decision in decisions:
        card = _project_decision_card(tenant_id, decision)
        if card.card_id in seen:
            continue
        cards.append(card)
        seen.add(card.card_id)
    cards.sort(key=lambda card: card.created_at or "", reverse=True)
    return cards
