"""Canonical Workweaver Runtime API."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, Header, HTTPException, Request, Response, status
from pydantic import BaseModel, Field

from apps.backend.api.auth_runtime_state import (
    retry_runtime_provisioning as auth_retry_runtime_provisioning,
)
from apps.backend.api.auth_runtime_state import runtime_provisioning_status as auth_runtime_provisioning_status
from apps.backend.api.auth_models import RuntimeProvisioningStatusResponse

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/runtime", tags=["runtime"])


class RuntimeVaultPutRequest(BaseModel):
    agent_id: str = Field(..., min_length=1, max_length=128)
    provider: str = Field(..., min_length=1, max_length=128)
    name: str = Field(..., min_length=1, max_length=256)
    payload: dict[str, Any] = Field(default_factory=dict)


class RuntimeVaultPutResponse(BaseModel):
    tenant_id: str
    agent_id: str
    credential_ref: str


class RuntimeVaultResolveRequest(BaseModel):
    agent_id: str = Field(..., min_length=1, max_length=128)
    credential_ref: str = Field(..., min_length=1, max_length=64)


class RuntimeVaultResolveResponse(BaseModel):
    tenant_id: str
    agent_id: str
    credential_ref: str
    payload: dict[str, Any]


@router.get(
    "/provisioning/status",
    response_model=RuntimeProvisioningStatusResponse,
    summary="Get Workweaver Runtime provisioning status",
)
async def runtime_provisioning_status(
    request: Request,
    response: Response,
    x_workweaver_runtime_provisioning_token: str | None = Header(
        default=None,
        alias="X-Workweaver-Runtime-Provisioning-Token",
    ),
) -> RuntimeProvisioningStatusResponse:
    """Canonical runtime status endpoint."""
    result = await auth_runtime_provisioning_status(
        request=request,
        response=response,
        x_workweaver_runtime_provisioning_token=(x_workweaver_runtime_provisioning_token or "").strip() or None,
    )
    if isinstance(result, RuntimeProvisioningStatusResponse):
        return result
    return RuntimeProvisioningStatusResponse(**result.model_dump())


@router.post(
    "/provisioning/retry",
    response_model=RuntimeProvisioningStatusResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Retry Workweaver Runtime provisioning",
)
async def retry_runtime_provisioning(
    request: Request,
    response: Response,
    x_workweaver_runtime_provisioning_token: str | None = Header(
        default=None,
        alias="X-Workweaver-Runtime-Provisioning-Token",
    ),
) -> RuntimeProvisioningStatusResponse:
    """Canonical runtime retry endpoint."""
    result = await auth_retry_runtime_provisioning(
        request=request,
        response=response,
        x_workweaver_runtime_provisioning_token=(x_workweaver_runtime_provisioning_token or "").strip() or None,
    )
    if isinstance(result, RuntimeProvisioningStatusResponse):
        return result
    return RuntimeProvisioningStatusResponse(**result.model_dump())


@router.post("/vault/credentials", response_model=RuntimeVaultPutResponse, status_code=status.HTTP_201_CREATED)
async def put_runtime_credential(
    body: RuntimeVaultPutRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> RuntimeVaultPutResponse:
    from apps.backend.services.agent_credential_vault import (
        VaultConfigurationError,
        get_agent_credential_vault,
    )

    vault = get_agent_credential_vault()
    try:
        ref = vault.put_payload(
            tenant_id=tenant_id,
            agent_id=body.agent_id.strip(),
            provider=body.provider.strip(),
            name=body.name.strip(),
            payload=body.payload,
        )
    except VaultConfigurationError as exc:
        logger.error("Vault configuration error on put: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Service temporarily unavailable",
        ) from exc
    return RuntimeVaultPutResponse(tenant_id=tenant_id, agent_id=body.agent_id.strip(), credential_ref=ref)


@router.post("/vault/credentials/resolve", response_model=RuntimeVaultResolveResponse)
async def resolve_runtime_credential(
    body: RuntimeVaultResolveRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> RuntimeVaultResolveResponse:
    from apps.backend.services.agent_credential_vault import (
        VaultConfigurationError,
        get_agent_credential_vault,
    )

    vault = get_agent_credential_vault()
    try:
        payload = vault.get_payload(
            tenant_id=tenant_id,
            agent_id=body.agent_id.strip(),
            ref_id=body.credential_ref.strip(),
        )
    except KeyError:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="credential_ref_not_found")
    except PermissionError:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="cross_agent_credential_access_denied")
    except VaultConfigurationError as exc:
        logger.error("Vault configuration error on resolve: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Service temporarily unavailable",
        ) from exc
    return RuntimeVaultResolveResponse(
        tenant_id=tenant_id,
        agent_id=body.agent_id.strip(),
        credential_ref=body.credential_ref.strip(),
        payload=payload,
    )


@router.get("/execution-graph/{agent_id}")
async def get_execution_graph(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return runtime execution graph (agent instances + parent/child edges)."""
    from apps.backend.dependencies import get_agent_instance_manager

    mgr = get_agent_instance_manager()
    instances = mgr.list_instances(tenant_id=tenant_id, agent_id=agent_id)

    nodes = []
    edges = []
    for inst in instances:
        nodes.append(
            {
                "instance_id": inst.instance_id,
                "agent_id": inst.agent_id,
                "purpose": inst.purpose,
                "state": inst.state.value if hasattr(inst.state, "value") else str(inst.state),
                "created_at": inst.created_at,
                "last_heartbeat": inst.last_heartbeat,
            }
        )
        if inst.parent_instance_id:
            edges.append(
                {
                    "from": inst.parent_instance_id,
                    "to": inst.instance_id,
                    "type": "spawned",
                }
            )

    return {
        "tenant_id": tenant_id,
        "agent_id": agent_id,
        "nodes": nodes,
        "edges": edges,
        "node_count": len(nodes),
        "edge_count": len(edges),
    }


@router.post("/execution-graph/reload")
async def reload_execution_graph(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Reload execution graph state from persistent store after restart."""
    from apps.backend.dependencies import get_agent_instance_manager

    mgr = get_agent_instance_manager()
    loaded = await mgr.reload_from_store(tenant_id)
    return {"tenant_id": tenant_id, "loaded_instances": loaded}


# ---------------------------------------------------------------------------
# Gateway restart drain — surface parity (issue #3602)
# ---------------------------------------------------------------------------


class DrainStatusResponse(BaseModel):
    """Serialized view of the drain controller state."""

    pod_id: str
    state: str  # ready / draining / drained
    is_ready: bool
    last_report: dict[str, Any] | None = None


@router.get(
    "/drain-status",
    response_model=DrainStatusResponse,
    summary="Get gateway drain status (issue #3602)",
)
async def get_drain_status(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> DrainStatusResponse:
    """Return the current drain state of the runtime gateway pod."""
    from apps.backend.services.runtime.runtime_drain_controller import get_runtime_drain_controller

    ctrl = get_runtime_drain_controller()
    report_data: dict[str, Any] | None = None
    if ctrl.final_report:
        r = ctrl.final_report
        report_data = {
            "sessions_active": r.sessions_active,
            "sessions_suspended": r.sessions_suspended,
            "sessions_abandoned": r.sessions_abandoned,
            "total_ms": r.total_ms,
            "caused_by": r.caused_by,
            "budget_exhausted": r.budget_exhausted,
        }
    return DrainStatusResponse(
        pod_id=ctrl.pod_id,
        state=ctrl.state.value,
        is_ready=ctrl.is_ready_for_traffic(),
        last_report=report_data,
    )


# ---------------------------------------------------------------------------
# Background missions - principal Zara responsiveness (#1206)
# ---------------------------------------------------------------------------


class MissionTicketResponse(BaseModel):
    """Serialized view of a MissionTicket for API responses."""

    ticket_id: str
    tenant_id: str
    session_id: str
    principal_session_id: str
    mission_ref: str
    status: str
    created_at: str
    updated_at: str
    progress_pct: int
    last_summary: str
    failure_reason: str | None = None
    outcome: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class MissionListResponse(BaseModel):
    tenant_id: str
    missions: list[MissionTicketResponse]


class MissionCancelRequest(BaseModel):
    reason: str = Field(default="cancelled", min_length=1, max_length=256)


def _serialize_ticket(ticket: Any) -> MissionTicketResponse:
    return MissionTicketResponse(
        ticket_id=ticket.ticket_id,
        tenant_id=ticket.tenant_id,
        session_id=ticket.session_id,
        principal_session_id=ticket.principal_session_id,
        mission_ref=ticket.mission_ref,
        status=ticket.status,
        created_at=ticket.created_at.isoformat(),
        updated_at=ticket.updated_at.isoformat(),
        progress_pct=ticket.progress_pct,
        last_summary=ticket.last_summary,
        failure_reason=ticket.failure_reason,
        outcome=ticket.outcome,
        metadata=dict(ticket.metadata or {}),
    )


@router.get(
    "/missions",
    response_model=MissionListResponse,
    summary="List active background missions for the principal Zara session",
)
async def list_background_missions(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> MissionListResponse:
    """List running/paused background missions for the tenant.

    The principal Zara session calls this to answer "what's running?"
    without blocking on mission execution (#1206).
    """
    from apps.backend.services.background_mission_tracker import (
        get_background_mission_tracker,
    )

    tracker = get_background_mission_tracker()
    tickets = tracker.list_active_missions(tenant_id)
    return MissionListResponse(
        tenant_id=tenant_id,
        missions=[_serialize_ticket(ticket) for ticket in tickets],
    )


@router.get(
    "/missions/{ticket_id}",
    response_model=MissionTicketResponse,
    summary="Get status of a specific background mission",
)
async def get_background_mission(
    ticket_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> MissionTicketResponse:
    from apps.backend.services.background_mission_tracker import (
        get_background_mission_tracker,
    )

    tracker = get_background_mission_tracker()
    ticket = tracker.get_ticket(ticket_id, tenant_id=tenant_id)
    if ticket is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="mission_ticket_not_found",
        )
    return _serialize_ticket(ticket)


@router.post(
    "/missions/{ticket_id}/cancel",
    response_model=MissionTicketResponse,
    summary="Cancel a running background mission",
)
async def cancel_background_mission(
    ticket_id: str,
    body: MissionCancelRequest | None = None,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> MissionTicketResponse:
    from apps.backend.services.background_mission_tracker import (
        get_background_mission_tracker,
    )

    from apps.backend.services.runtime.runtime_session_gateway import (
        get_runtime_session_gateway,
    )

    tracker = get_background_mission_tracker()
    gateway = get_runtime_session_gateway()
    reason = (body.reason if body is not None else "cancelled").strip() or "cancelled"
    try:
        # #1448: route through cancel_mission_async so the live RuntimeSession
        # actually stops via gateway.fail_session instead of only flipping the
        # ticket status while the background mission keeps consuming budget.
        ticket = await tracker.cancel_mission_async(
            ticket_id,
            tenant_id=tenant_id,
            reason=reason,
            session_gateway=gateway,
        )
    except ValueError as exc:
        message = str(exc)
        if "unknown mission ticket" in message:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail="mission_ticket_not_found",
            ) from exc
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=message,
        ) from exc
    return _serialize_ticket(ticket)


# ---------------------------------------------------------------------------
# Swarm concurrency status — aggregate view (issue #3219)
# ---------------------------------------------------------------------------


class SwarmConcurrencyStatusResponse(BaseModel):
    """Aggregate swarm concurrency status for a tenant."""

    tenant_id: str
    max_concurrent_workers: int = Field(ge=0)
    active_workers: int = Field(ge=0)
    circuit_breaker_state: str  # CLOSED / OPEN / HALF_OPEN
    zombie_reaped_count: int = Field(ge=0)


@router.get(
    "/swarm/concurrency",
    response_model=SwarmConcurrencyStatusResponse,
    summary="Swarm concurrency cap status (issue #3219)",
)
async def get_swarm_concurrency_status(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SwarmConcurrencyStatusResponse:
    """Read-only aggregate of admission cap, breaker state, and zombie count.

    Gathers the current state across all active missions for the tenant by
    inspecting the durable admission index and the spawn circuit breaker.
    """
    from apps.backend.services.runtime.mission_worker_admission import (
        get_mission_worker_admission,
    )

    admission = get_mission_worker_admission()

    # Enumerate all active missions for this tenant.
    active_missions = await admission.list_active_missions()
    tenant_missions = [(t, m) for t, m in active_missions if t == tenant_id]

    total_active = 0
    total_reaped = 0
    breaker_state_label = "CLOSED"

    # Resolve the cap for the tenant (all missions share the same default).
    cap = admission._default_cap
    if admission._cap_provider is not None:
        try:
            cap = int(admission._cap_provider(tenant_id, ""))
        except Exception:
            pass

    for t_id, m_id in tenant_missions:
        snap = await admission.snapshot(t_id, m_id)
        total_active += snap.active_workers

    # Check breaker state across tenant missions — report the most severe.
    if admission._breaker is not None and tenant_missions:
        from apps.backend.services.runtime.spawn_circuit_breaker import (
            BreakerState,
        )

        for t_id, m_id in tenant_missions:
            bsnap = await admission._breaker.get_state(t_id, m_id)
            if bsnap.state is BreakerState.OPEN:
                breaker_state_label = "OPEN"
                break
            if bsnap.state is BreakerState.HALF_OPEN:
                breaker_state_label = "HALF_OPEN"

    # Zombie reaped count: sum of attempt_counts from the reaper singleton
    # for this tenant. The reaper tracks this in memory per process.
    try:
        from apps.backend.services.runtime.zombie_reaper import get_zombie_reaper

        reaper = get_zombie_reaper()
        for key, count in reaper._attempt_counts.items():
            if key[0] == tenant_id:
                total_reaped += count
    except Exception:
        logger.debug("swarm_concurrency_status.reaper_unavailable", exc_info=True)

    return SwarmConcurrencyStatusResponse(
        tenant_id=tenant_id,
        max_concurrent_workers=cap,
        active_workers=total_active,
        circuit_breaker_state=breaker_state_label,
        zombie_reaped_count=total_reaped,
    )


__all__ = ["router"]
