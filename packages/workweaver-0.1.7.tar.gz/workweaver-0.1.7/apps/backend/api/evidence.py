from __future__ import annotations

import logging
from typing import Any
from unittest.mock import Mock

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.params import Body
from botocore.exceptions import BotoCoreError, ClientError

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/evidence", tags=["evidence"])


def _get_service():
    """Lazy import to avoid import-time boto3 failures in tests."""
    from apps.backend.services.evidence_ledger import get_evidence_ledger_service

    return get_evidence_ledger_service()


def _get_dev_intel():
    """Lazy import developmental intelligence service."""
    from apps.backend.services.developmental_intelligence import (
        get_developmental_intelligence_service,
    )

    return get_developmental_intelligence_service()


def _get_decision_service():
    """Lazy import decision capture service for trace retrieval."""
    from apps.backend.services.context.decision_event_capture import DecisionEventCaptureService

    return DecisionEventCaptureService()


def _get_baseline_service():
    from apps.backend.services.macrohard_baseline import get_macrohard_baseline_service

    return get_macrohard_baseline_service()


def _get_run_state_service():
    from apps.backend.services.mission_run.state import get_mission_run_state_service

    return get_mission_run_state_service()


def _get_gate_b_audit_bundle_service():
    from apps.backend.services.gate_b_audit_bundle import get_gate_b_audit_bundle_service

    return get_gate_b_audit_bundle_service()


def _enrich_timeline_with_traits(items: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Add trait_tag (Knowledge/Experience/Skill) to each evidence item."""
    try:
        svc = _get_dev_intel()
        for item in items:
            tag = svc.classify_trait(item)
            item["trait_tag"] = tag.value if tag else None
    except Exception as exc:
        logger.warning(
            "Evidence trait enrichment failed; returning raw timeline items: %s",
            exc,
            exc_info=True,
        )
    return items


def _timeline_unavailable_error(exc: Exception) -> HTTPException:
    logger.warning("Evidence timeline unavailable: %s", exc, exc_info=True)
    return HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail={
            "error": "evidence_timeline_unavailable",
            "detail": "Evidence timeline is temporarily unavailable.",
        },
    )


def _strict_proof_failure_detail(*, run_id: str, bundle: dict[str, Any]) -> dict[str, Any]:
    revenue_proof = bundle.get("revenue_proof") if isinstance(bundle.get("revenue_proof"), dict) else {}
    return {
        "message": "Revenue Proof Loop audit bundle failed strict verification",
        "run_id": run_id,
        "required_booleans": revenue_proof.get("required_booleans", {}),
        "supporting_signals": revenue_proof.get("supporting_signals", {}),
        "blockers": revenue_proof.get("blockers", []),
        "proof_bundle": {
            "run_id": str(bundle.get("run_id") or run_id),
            "tenant_id": str(bundle.get("tenant_id") or ""),
            "workflow": str(bundle.get("workflow") or ""),
            "revenue_proof": revenue_proof,
        },
    }


# Request/Response Models


class EvidenceIngestRequest(BaseModel):
    """Request model for ingesting evidence."""

    event_type: str = Field(..., max_length=100, description="Type of event (e.g., 'user.login', 'skill.executed')")
    data: dict[str, Any] = Field(..., description="Event payload data")
    session_id: str | None = Field(None, max_length=100, description="Session identifier for correlation")
    risk_level: str | None = Field(None, max_length=50, description="Risk level: LOW, MEDIUM, HIGH, CRITICAL")
    scope_type: str | None = Field(None, max_length=50, description="Scope type (e.g., 'tenant', 'user', 'skill')")
    scope_id: str | None = Field(None, max_length=100, description="Scope identifier")
    actor_path: str | None = Field(None, max_length=500, description="Actor path for attribution")
    source_event_id: str | None = Field(None, max_length=100, description="Source event ID for causality")


class EvidenceIngestResponse(BaseModel):
    """Response model for evidence ingestion.

    Matches the Workweaver Runtime plugin's EvidenceLogResponse interface:
    { event_id: string, ingested: boolean }
    """

    event_id: str = Field(..., description="Unique evidence identifier")
    ingested: bool = Field(..., description="Whether the evidence was ingested")


class EvidenceTimelineResponse(BaseModel):
    """Response model for evidence timeline."""

    items: list[dict[str, Any]] = Field(..., description="Evidence entries")
    cursor: str | None = Field(None, description="Cursor for pagination")
    count: int = Field(..., description="Number of items in this response")


class EvidenceRecordResponse(BaseModel):
    """Single evidence record response."""

    item: dict[str, Any] = Field(..., description="Evidence record")


class DecisionTraceItem(BaseModel):
    """Decision trace projection for customer-facing proof UI."""

    trace_id: str
    skill_id: str
    decision_summary: str
    decision_type: str
    outcome: str
    rationale: str | None = None
    alternatives_considered: list[str] = Field(default_factory=list)
    decision_conditions: list[str] = Field(default_factory=list)
    sop_deviation: str | None = None
    quality_score: float
    created_at: str
    entity_ids: list[str] = Field(default_factory=list)
    # #3549: AwarenessSnapshot id for zara.plan.* / zara.steer.* traces.
    awareness_snapshot_id: str | None = None


class AwarenessSnapshotResponse(BaseModel):
    """Response shape for the awareness-snapshot replay endpoint (#3549)."""

    snapshot_id: str
    tenant_id: str
    workspace: str
    captured_at: str
    schema_version: str
    runtime: dict[str, Any] = Field(default_factory=dict)
    capabilities: dict[str, Any] = Field(default_factory=dict)
    proactive: dict[str, Any] = Field(default_factory=dict)
    routines: dict[str, Any] = Field(default_factory=dict)
    capability_readiness: list[dict[str, Any]] = Field(default_factory=list)
    persona_overlay_digest: str | None = None


class DecisionTraceResponse(BaseModel):
    """List response for customer-facing decision traces."""

    items: list[DecisionTraceItem]
    count: int


class HydratedDecisionTraceResponse(BaseModel):
    """Hydrated Decision Trace shared by API, CLI, UI, and MCP."""

    trace_id: str | None = None
    subject_id: str | None = None
    subject_type: str = "workitem"
    items: list[dict[str, Any]] = Field(default_factory=list)
    count: int = 0
    evidence_ids: list[str] = Field(default_factory=list)
    decisions: list[dict[str, Any]] = Field(default_factory=list)
    tool_calls: list[dict[str, Any]] = Field(default_factory=list)
    policy_gates: list[dict[str, Any]] = Field(default_factory=list)
    artifacts: list[dict[str, Any]] = Field(default_factory=list)
    costs: list[dict[str, Any]] = Field(default_factory=list)
    timeblocks: list[dict[str, Any]] = Field(default_factory=list)
    actors: list[str] = Field(default_factory=list)
    outcomes: list[str] = Field(default_factory=list)
    trace_envelope_ids: list[str] = Field(default_factory=list)
    artifact_lineage_refs: list[dict[str, Any]] = Field(default_factory=list)
    provider_audit_refs: list[dict[str, Any]] = Field(default_factory=list)


class LineageProjectionResponse(BaseModel):
    run_id: str
    mission_id: str
    swarm_mode: str
    proof_plane: str
    budget: dict[str, Any] = Field(default_factory=dict)
    summary: dict[str, Any] = Field(default_factory=dict)
    nodes: list[dict[str, Any]] = Field(default_factory=list)
    edges: list[dict[str, Any]] = Field(default_factory=list)
    identities: list[dict[str, Any]] = Field(default_factory=list)
    warrants: list[dict[str, Any]] = Field(default_factory=list)
    leases: list[dict[str, Any]] = Field(default_factory=list)


class AuditBundleResponse(BaseModel):
    bundle: dict[str, Any] = Field(default_factory=dict)


class BaselineReportResponse(BaseModel):
    report_version: int
    generated_at: str
    window: dict[str, Any] = Field(default_factory=dict)
    evidence_coverage: dict[str, Any] = Field(default_factory=dict)
    decision_trace_coverage: dict[str, Any] = Field(default_factory=dict)
    flagship_workflow: dict[str, Any] = Field(default_factory=dict)


class StrategicDecisionTrace(BaseModel):
    """Strategic decision trace projection for a single OKR."""

    okr_id: str
    intent: str = ""
    linked_work_items: list[str] = Field(default_factory=list)
    resource_reallocations: list[dict[str, Any]] = Field(default_factory=list)
    decisions: list[dict[str, Any]] = Field(default_factory=list)
    outcomes: list[str] = Field(default_factory=list)


class StrategicTraceListResponse(BaseModel):
    """List response for strategic decision traces."""

    items: list[StrategicDecisionTrace]
    count: int


def _plain_attr(obj: Any, name: str, default: Any = None) -> Any:
    value = getattr(obj, name, default)
    if isinstance(value, Mock):
        return default
    return value


def _list_attr(obj: Any, name: str) -> list[Any]:
    value = _plain_attr(obj, name, [])
    if isinstance(value, list):
        return value
    if isinstance(value, tuple):
        return list(value)
    if isinstance(value, set):
        return sorted(value)
    return []


def _string_attr(obj: Any, name: str) -> str:
    value = _plain_attr(obj, name, "")
    if value is None or isinstance(value, (dict, list, tuple, set)):
        return ""
    return str(value)


def _float_attr(obj: Any, name: str) -> float:
    try:
        return float(_plain_attr(obj, name, 0.0) or 0.0)
    except (TypeError, ValueError):
        return 0.0


def _dict_payload(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return dict(value)
    if isinstance(value, str) and value.strip():
        import json

        try:
            parsed = json.loads(value)
        except json.JSONDecodeError:
            return {}
        return parsed if isinstance(parsed, dict) else {}
    return {}


def _list_payload(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, list):
        return [dict(item) for item in value if isinstance(item, dict)]
    if isinstance(value, dict):
        return [dict(value)]
    return []


def _unique_strings(values: list[Any]) -> list[str]:
    seen: set[str] = set()
    result: list[str] = []
    for value in values:
        text = str(value or "").strip()
        if text and text not in seen:
            seen.add(text)
            result.append(text)
    return result


def _decision_context(decision: Any) -> dict[str, Any]:
    return _dict_payload(_plain_attr(decision, "context_data", None))


def _decision_trace_item_payload(decision: Any) -> dict[str, Any]:
    return DecisionTraceItem(
        trace_id=_string_attr(decision, "trace_id"),
        skill_id=_string_attr(decision, "skill_id"),
        decision_summary=_string_attr(decision, "decision_summary"),
        decision_type=_string_attr(decision, "decision_type"),
        outcome=_string_attr(decision, "outcome"),
        rationale=_plain_attr(decision, "rationale", None),
        alternatives_considered=[str(item) for item in _list_attr(decision, "alternatives_considered")],
        decision_conditions=[str(item) for item in _list_attr(decision, "decision_conditions")],
        sop_deviation=_plain_attr(decision, "sop_deviation", None),
        quality_score=_float_attr(decision, "quality_score"),
        created_at=_string_attr(decision, "created_at"),
        entity_ids=[str(item) for item in _list_attr(decision, "entity_ids")],
    ).model_dump(mode="json")


def _collect_lineage_list(value: Any) -> list[dict[str, Any]]:
    """Collect lineage refs from ArtifactRef/ProviderAuditRef objects or dicts."""
    if not value:
        return []
    if isinstance(value, list):
        result: list[dict[str, Any]] = []
        for item in value:
            if isinstance(item, dict):
                result.append(item)
            elif hasattr(item, "model_dump"):
                result.append(item.model_dump(mode="json"))
        return result
    return []


def _collect_payload_list(decision: Any, context: dict[str, Any], *names: str) -> list[dict[str, Any]]:
    for name in names:
        direct = _plain_attr(decision, name, None)
        if direct:
            return _list_payload(direct)
        if name in context:
            return _list_payload(context.get(name))
    return []


def _infer_subject_type(subject_id: str | None, explicit: str | None = None) -> str:
    if explicit:
        return explicit
    normalized = str(subject_id or "").strip().lower()
    if normalized.startswith("goal"):
        return "goal"
    if normalized.startswith("task"):
        return "task"
    return "workitem"


def _build_hydrated_decision_trace(
    *,
    tenant_id: str,
    subject_id: str | None,
    subject_type: str | None = None,
    limit: int = 100,
    decision_service: Any | None = None,
) -> HydratedDecisionTraceResponse:
    resolved_subject_type = _infer_subject_type(subject_id, subject_type)
    if not subject_id:
        return HydratedDecisionTraceResponse(subject_type=resolved_subject_type)

    service = decision_service or _get_decision_service()
    decisions = service.list_decisions(tenant_id=tenant_id, limit=max(1, min(int(limit), 1000)))
    matched = []
    for decision in decisions:
        entity_ids = [str(item) for item in _list_attr(decision, "entity_ids")]
        if str(subject_id) in entity_ids:
            matched.append(decision)

    items: list[dict[str, Any]] = []
    evidence_ids: list[Any] = []
    tool_calls: list[dict[str, Any]] = []
    policy_gates: list[dict[str, Any]] = []
    artifacts: list[dict[str, Any]] = []
    costs: list[dict[str, Any]] = []
    timeblocks: list[dict[str, Any]] = []
    actors: list[Any] = []
    outcomes: list[Any] = []
    trace_envelope_ids: list[Any] = []
    artifact_lineage_refs: list[dict[str, Any]] = []
    provider_audit_refs: list[dict[str, Any]] = []

    for decision in matched:
        context = _decision_context(decision)
        payload = _decision_trace_item_payload(decision)
        items.append(payload)

        evidence_ids.extend(_list_attr(decision, "evidence_ids"))
        evidence_ids.extend(context.get("evidence_ids") if isinstance(context.get("evidence_ids"), list) else [])
        evidence_ids.extend(
            [
                _string_attr(decision, "evidence_id"),
                _string_attr(decision, "source_event_id"),
                context.get("evidence_id"),
                context.get("source_event_id"),
            ]
        )
        tool_calls.extend(_collect_payload_list(decision, context, "tool_calls", "tool_call"))
        policy_gates.extend(_collect_payload_list(decision, context, "policy_gates", "policy_decision", "policy_verdict"))
        artifacts.extend(_collect_payload_list(decision, context, "artifacts", "artifact"))
        costs.extend(_collect_payload_list(decision, context, "costs", "cost"))
        timeblocks.extend(_collect_payload_list(decision, context, "timeblocks", "time_blocks", "timeblock"))
        artifact_lineage_refs.extend(
            _collect_lineage_list(_plain_attr(decision, "artifact_lineage_refs", None))
            or _collect_payload_list(decision, context, "artifact_lineage_refs")
        )
        provider_audit_refs.extend(
            _collect_lineage_list(_plain_attr(decision, "provider_audit_refs", None))
            or _collect_payload_list(decision, context, "provider_audit_refs")
        )
        actors.extend(
            [
                _string_attr(decision, "actor"),
                _string_attr(decision, "actor_id"),
                _string_attr(decision, "agent_id"),
                context.get("actor"),
                context.get("actor_id"),
            ]
        )
        outcomes.append(payload.get("outcome"))
        trace_envelope_ids.extend(
            [
                _string_attr(decision, "trace_envelope_id"),
                context.get("trace_envelope_id"),
            ]
        )

    trace_id = str(items[0].get("trace_id") or "") if items else f"trace:{subject_id}"
    return HydratedDecisionTraceResponse(
        trace_id=trace_id,
        subject_id=str(subject_id),
        subject_type=resolved_subject_type,
        items=items,
        count=len(items),
        evidence_ids=_unique_strings(evidence_ids),
        decisions=items,
        tool_calls=tool_calls,
        policy_gates=policy_gates,
        artifacts=artifacts,
        costs=costs,
        timeblocks=timeblocks,
        actors=_unique_strings(actors),
        outcomes=_unique_strings(outcomes),
        trace_envelope_ids=_unique_strings(trace_envelope_ids),
        artifact_lineage_refs=artifact_lineage_refs,
        provider_audit_refs=provider_audit_refs,
    )


def list_strategic_traces(
    tenant_id: str,
    decision_service: Any = None,
    limit: int = 100,
) -> list[StrategicDecisionTrace]:
    """Return strategic DecisionEvents grouped by OKR.

    Scans strategy-domain decisions and projects them into
    StrategicDecisionTrace objects keyed by okr_id found in entity_ids.
    """
    service = decision_service or _get_decision_service()
    decisions = service.list_decisions(tenant_id=tenant_id, limit=limit)

    okr_map: dict[str, StrategicDecisionTrace] = {}

    for decision in decisions:
        domain = getattr(decision, "domain", "operational")
        if domain != "strategy":
            continue

        entity_ids = [str(eid) for eid in _list_attr(decision, "entity_ids")]
        okr_id: str | None = None
        for eid in entity_ids:
            if eid.startswith("okr_"):
                okr_id = eid
                break

        if okr_id is None:
            continue

        if okr_id not in okr_map:
            okr_map[okr_id] = StrategicDecisionTrace(
                okr_id=okr_id,
                intent=_string_attr(decision, "decision_summary"),
                linked_work_items=[eid for eid in entity_ids if eid != okr_id],
                decisions=[],
                outcomes=[],
            )

        trace = okr_map[okr_id]
        trace.decisions.append(_decision_trace_item_payload(decision))
        outcome_val = _string_attr(decision, "outcome")
        if outcome_val:
            trace.outcomes.append(outcome_val)

    return list(okr_map.values())


def get_strategic_trace(
    tenant_id: str,
    okr_id: str,
    decision_service: Any = None,
    limit: int = 100,
) -> StrategicDecisionTrace:
    """Return a single StrategicDecisionTrace for the given OKR."""
    traces = list_strategic_traces(
        tenant_id=tenant_id,
        decision_service=decision_service,
        limit=limit,
    )
    for trace in traces:
        if trace.okr_id == okr_id:
            return trace
    return StrategicDecisionTrace(okr_id=okr_id)


# Endpoints


@router.post(
    "/ingest",
    response_model=EvidenceIngestResponse,
    status_code=status.HTTP_201_CREATED,
)
async def ingest_evidence(
    request: EvidenceIngestRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> EvidenceIngestResponse:
    """
    Ingest a new evidence entry into the Evidence Ledger.

    This endpoint accepts evidence data and stores it with full metadata,
    including tenant isolation, session correlation, and risk classification.
    """
    try:
        service = _get_service()
        result = service.ingest(
            tenant_id=tenant_id,
            event_type=request.event_type,
            data=request.data,
            session_id=request.session_id,
            risk_level=request.risk_level,
            scope_type=request.scope_type,
            scope_id=request.scope_id,
            actor_path=request.actor_path,
            source_event_id=request.source_event_id,
            capture_surface="http",
            service_family="evidence_api",
        )

        return EvidenceIngestResponse(
            event_id=result["evidence_id"],
            ingested=True,
        )
    except Exception as e:
        logger.error(f"Failed to ingest evidence: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to ingest evidence",
        )


@router.get("/timeline", response_model=EvidenceTimelineResponse)
async def get_evidence_timeline(
    tenant_id: str = Depends(get_verified_tenant_id),
    event_type: str | None = Query(None, description="Filter by event type"),
    limit: int = Query(50, ge=1, le=1000, description="Maximum number of items to return"),
    cursor: str | None = Query(None, description="Pagination cursor"),
    entity_id: str | None = Query(None, description="Filter by AI worker entity identifier"),
) -> EvidenceTimelineResponse:
    """
    Get evidence timeline with optional filtering and pagination.

    Returns a chronologically ordered list of evidence entries for a tenant,
    optionally filtered by event type or entity_id.
    """
    try:
        service = _get_service()
        result = service.get_timeline(
            tenant_id=tenant_id,
            event_type=event_type,
            limit=limit,
            cursor=cursor,
            entity_id=entity_id,
        )

        items = _enrich_timeline_with_traits(result.get("items", []))
        return EvidenceTimelineResponse(
            items=items,
            cursor=result.get("cursor"),
            count=len(items),
        )
    except (ClientError, BotoCoreError) as e:
        raise _timeline_unavailable_error(e) from e
    except Exception as e:
        logger.error(f"Failed to get evidence timeline: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get evidence timeline",
        )


@router.get("/decisions", response_model=DecisionTraceResponse)
async def list_decision_traces(
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(25, ge=1, le=200, description="Maximum number of decision traces to return"),
    skill_id: str | None = Query(None, description="Optional skill filter"),
    outcome: str | None = Query(None, description="Optional outcome filter"),
) -> DecisionTraceResponse:
    """List tenant-scoped decision traces for the Proof UI."""
    try:
        service = _get_decision_service()
        decisions = service.list_decisions(
            tenant_id=tenant_id,
            limit=limit,
            skill_id=skill_id,
            outcome=outcome,
        )
        items = [
            DecisionTraceItem(
                trace_id=decision.trace_id,
                skill_id=decision.skill_id,
                decision_summary=decision.decision_summary,
                decision_type=decision.decision_type,
                outcome=decision.outcome,
                rationale=decision.rationale,
                alternatives_considered=list(decision.alternatives_considered),
                decision_conditions=list(decision.decision_conditions),
                sop_deviation=decision.sop_deviation,
                quality_score=decision.quality_score,
                created_at=decision.created_at,
                entity_ids=list(decision.entity_ids),
            )
            for decision in decisions
        ]
        return DecisionTraceResponse(items=items, count=len(items))
    except Exception as e:
        logger.error(f"Failed to list decision traces: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get decision traces",
        )


@router.get("/decisions/{trace_id}", response_model=DecisionTraceItem)
async def get_decision_trace(
    trace_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> DecisionTraceItem:
    """Get a single decision trace by trace id."""
    try:
        service = _get_decision_service()
        decision = service.get_decision(tenant_id=tenant_id, trace_id=trace_id)
        if decision is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Decision trace not found: {trace_id}",
            )
        return DecisionTraceItem(
            trace_id=decision.trace_id,
            skill_id=decision.skill_id,
            decision_summary=decision.decision_summary,
            decision_type=decision.decision_type,
            outcome=decision.outcome,
            rationale=decision.rationale,
            alternatives_considered=list(decision.alternatives_considered),
            decision_conditions=list(decision.decision_conditions),
            sop_deviation=decision.sop_deviation,
            quality_score=decision.quality_score,
            created_at=decision.created_at,
            entity_ids=list(decision.entity_ids),
            awareness_snapshot_id=getattr(decision, "awareness_snapshot_id", None),
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get decision trace: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get decision trace",
        )


@router.get(
    "/{trace_id}/awareness-snapshot",
    response_model=AwarenessSnapshotResponse,
)
async def get_awareness_snapshot_for_trace(
    trace_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> AwarenessSnapshotResponse:
    """Replay the AwarenessSnapshot Zara consulted for ``trace_id`` (#3549).

    Resolves the trace, reads its ``awareness_snapshot_id``, and looks
    the snapshot up in the WorkMemory ``AWARENESS_SNAPSHOT#`` namespace.
    Returns 404 when the trace exists but never carried a snapshot id
    (legacy path) or when the snapshot row has aged out of retention.
    """
    decision_service = _get_decision_service()
    decision = decision_service.get_decision(tenant_id=tenant_id, trace_id=trace_id)
    if decision is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Decision trace not found: {trace_id}",
        )
    snapshot_id = getattr(decision, "awareness_snapshot_id", None)
    if not snapshot_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"Decision trace {trace_id} did not stamp an awareness_snapshot_id "
                "(legacy or non-zara.plan.* operation)."
            ),
        )
    try:
        from apps.backend.providers.portable_store import create_portable_store
        from apps.backend.workmemory.services.awareness_snapshot_store import (
            AwarenessSnapshotStore,
        )

        store = AwarenessSnapshotStore(create_portable_store())
        snapshot = store.get(tenant_id=tenant_id, snapshot_id=snapshot_id)
    except Exception as exc:
        logger.warning(
            "awareness_snapshot lookup failed trace=%s err=%s", trace_id, exc
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="awareness_snapshot store unavailable",
        )
    if snapshot is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=(
                f"Awareness snapshot {snapshot_id} not found for tenant "
                "(may have aged out of retention)."
            ),
        )
    return AwarenessSnapshotResponse(
        snapshot_id=snapshot.snapshot_id,
        tenant_id=snapshot.tenant_id,
        workspace=snapshot.workspace,
        captured_at=snapshot.captured_at.isoformat(),
        schema_version=snapshot.schema_version,
        runtime=snapshot.runtime,
        capabilities=snapshot.capabilities,
        proactive=snapshot.proactive,
        routines=snapshot.routines,
        capability_readiness=snapshot.capability_readiness,
        persona_overlay_digest=snapshot.persona_overlay_digest,
    )


@router.post("/decisions/search")
async def search_decision_traces(
    request_body: dict[str, Any] = Body(default={}),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Search decision traces with structured filters and full-text query.

    Accepts structured filters (domain, tool_name, outcome, skill_id,
    decision_type, min_confidence, time_range_start, time_range_end,
    sop_deviation_present, precedent_id) and optional full-text ``query``
    over rationale, decision_summary, and alternatives_considered.

    Tenant-isolated by default; cross-tenant search returns 403 unless
    admin scope (enforced by get_verified_tenant_id dependency).
    """
    from apps.backend.services.decision_search_service import (
        DecisionSearchFilters,
        get_decision_search_service,
    )

    try:
        filters = DecisionSearchFilters(**{
            k: v for k, v in request_body.items()
            if k in DecisionSearchFilters.model_fields
        })
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail=f"Invalid search filters: {exc}",
        ) from exc

    query = request_body.get("query")
    if query is not None:
        query = str(query).strip() or None

    try:
        service = get_decision_search_service()
        result = service.search(tenant_id=tenant_id, filters=filters, query=query)
        return result.model_dump(mode="json")
    except Exception as e:
        logger.error(f"Failed to search decision traces: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to search decision traces",
        )


@router.get("/strategy/traces", response_model=StrategicTraceListResponse)
async def list_strategic_trace_endpoint(
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(100, ge=1, le=500, description="Maximum decisions to scan"),
) -> StrategicTraceListResponse:
    """List strategic decision traces grouped by OKR."""
    try:
        traces = list_strategic_traces(
            tenant_id=tenant_id,
            limit=limit,
        )
        return StrategicTraceListResponse(items=traces, count=len(traces))
    except Exception as e:
        logger.error(f"Failed to list strategic traces: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get strategic traces",
        )


@router.get("/strategy/traces/{okr_id}", response_model=StrategicDecisionTrace)
async def get_strategic_trace_endpoint(
    okr_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> StrategicDecisionTrace:
    """Get a single strategic decision trace by OKR ID."""
    try:
        trace = get_strategic_trace(
            tenant_id=tenant_id,
            okr_id=okr_id,
        )
        return trace
    except Exception as e:
        logger.error(f"Failed to get strategic trace: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get strategic trace",
        )


@router.get("/lineage/{run_id}", response_model=LineageProjectionResponse)
async def get_lineage_projection(
    run_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> LineageProjectionResponse:
    try:
        projection = _get_run_state_service().export_lineage_projection(tenant_id=tenant_id, run_id=run_id)
        data = projection.model_dump(mode="json")
        return LineageProjectionResponse(
            run_id=str(data.get("run_id") or run_id),
            mission_id=str(data.get("mission_id") or ""),
            swarm_mode=str(data.get("swarm_mode") or ""),
            proof_plane=str(data.get("proof_plane") or ""),
            budget=dict(data.get("budget") or {}),
            summary=dict(data.get("summary") or {}),
            nodes=list(data.get("nodes") or []),
            edges=list(data.get("edges") or []),
            identities=list(data.get("identities") or []),
            warrants=list(data.get("warrants") or []),
            leases=list(data.get("leases") or []),
        )
    except ValueError as exc:
        logger.error("Lineage projection not found: %s", exc, exc_info=True)
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Lineage projection not found")
    except Exception as exc:
        logger.error("Failed to export lineage projection: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to export lineage projection",
        )


@router.get("/lineage/{run_id}/export", response_model=AuditBundleResponse)
async def export_lineage_bundle(
    run_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> AuditBundleResponse:
    try:
        bundle = _get_run_state_service().export_audit_bundle(tenant_id=tenant_id, run_id=run_id)
        return AuditBundleResponse(bundle=bundle)
    except ValueError as exc:
        logger.error("Audit bundle not found for run %s: %s", run_id, exc, exc_info=True)
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Audit bundle not found")
    except Exception as exc:
        logger.error("Failed to export audit bundle: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to export audit bundle",
        )


@router.get("/audit-bundle/{run_id}")
async def get_gate_b_audit_bundle(
    run_id: str,
    strict: bool = Query(False, description="Fail closed when the Revenue Proof Loop artifact is incomplete."),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    try:
        bundle = _get_gate_b_audit_bundle_service().build_bundle(tenant_id=tenant_id, run_id=run_id)
        if strict and not bundle.get("revenue_proof", {}).get("qualifying", False):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail=_strict_proof_failure_detail(run_id=run_id, bundle=bundle),
            )
        return bundle
    except ValueError as exc:
        logger.error("Gate B audit bundle not found for run %s: %s", run_id, exc, exc_info=True)
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Gate B audit bundle not found") from exc
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Failed to assemble Gate B audit bundle for run %s: %s", run_id, exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to assemble Gate B audit bundle",
        ) from exc


@router.get("/session/{session_id}")
async def get_evidence_by_session(
    session_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(50, ge=1, le=1000, description="Maximum number of items to return"),
) -> list[dict[str, Any]]:
    """
    Get all evidence entries for a specific session.

    Returns evidence entries correlated by session ID, useful for debugging
    and tracing user journeys or process flows.
    """
    try:
        service = _get_service()
        result = service.get_by_session(
            tenant_id=tenant_id,
            session_id=session_id,
            limit=limit,
        )

        return result
    except Exception as e:
        logger.error(f"Failed to get evidence by session: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get evidence by session",
        )


@router.get("/export")
async def export_evidence(
    tenant_id: str = Depends(get_verified_tenant_id),
    event_type: str | None = Query(None, description="Filter by event type"),
    limit: int = Query(1000, ge=1, le=10000, description="Maximum number of items to export"),
) -> list[dict[str, Any]]:
    """
    Export evidence data as JSON array.

    Returns a plain JSON array of evidence entries for bulk export,
    useful for compliance reporting and external analysis.
    """
    try:
        service = _get_service()
        result = service.export(
            tenant_id=tenant_id,
            event_type=event_type,
            limit=limit,
        )

        return result
    except Exception as e:
        logger.error(f"Failed to export evidence: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to export evidence",
        )


@router.get("/baseline", response_model=BaselineReportResponse)
async def get_macrohard_baseline(
    tenant_id: str = Depends(get_verified_tenant_id),
    evidence_limit: int = Query(500, ge=1, le=5000, description="Maximum evidence records to inspect"),
    decision_limit: int = Query(500, ge=1, le=5000, description="Maximum decision records to inspect"),
    flagship_workflow: str = Query("timeblock", description="Flagship workflow baseline to summarize"),
) -> BaselineReportResponse:
    """Return the PR-00 baseline truth report for evidence, decisions, and outcome links."""
    try:
        service = _get_baseline_service()
        report = service.build_report(
            tenant_id=tenant_id,
            evidence_limit=evidence_limit,
            decision_limit=decision_limit,
            flagship_workflow=flagship_workflow,
        )
        return BaselineReportResponse(**report)
    except Exception as exc:
        logger.error("Failed to build Macrohard baseline report: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to build baseline report",
        )


@router.get("/{task_id}/trace", response_model=HydratedDecisionTraceResponse)
async def get_task_decision_trace(
    task_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(100, ge=1, le=500, description="Maximum decisions to scan"),
    subject_type: str | None = Query(None, description="Optional subject type, such as workitem, task, or goal"),
) -> HydratedDecisionTraceResponse:
    """Get all decision traces for a specific task.

    Returns the hydrated Decision Trace for a WorkItem, task, or goal,
    including the decision events whose entity_ids contain the subject id.

    M10.4 -- Decision Trace Customer Surface.
    """
    try:
        return _build_hydrated_decision_trace(
            tenant_id=tenant_id,
            subject_id=task_id,
            subject_type=subject_type,
            limit=limit,
        )
    except Exception as e:
        logger.error(f"Failed to get task decision trace: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get task decision trace",
        )


# NOTE: /{evidence_id} is a catch-all path parameter and MUST be the last
# GET route registered on this router. If placed earlier, it shadows literal
# paths like /decisions, /export, /timeline, and /{task_id}/trace.
@router.get("/{evidence_id}", response_model=EvidenceRecordResponse)
async def get_evidence_record(
    evidence_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> EvidenceRecordResponse:
    """Get a single evidence record by ID for the authenticated tenant."""
    try:
        service = _get_service()
        item = service.get_by_id(tenant_id=tenant_id, evidence_id=evidence_id)
        if item is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Evidence not found: {evidence_id}",
            )
        return EvidenceRecordResponse(item=item)
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get evidence record: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get evidence record",
        )
