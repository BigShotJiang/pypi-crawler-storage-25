"""Goal Cascade API — PR-T2.8.

Endpoints:
    POST /api/v1/goals/{goal_id}/cascade   — decompose goal through hierarchy
    GET  /api/v1/goals/{goal_id}/cascade    — get cascade tree with progress
    GET  /api/v1/goals/{goal_id}/alignment  — alignment score for a work item

Wire: GoalCascadeService for decomposition and progress aggregation.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/goals", tags=["goal-cascade"])


# ---------------------------------------------------------------------------
# Lazy accessor
# ---------------------------------------------------------------------------


def _get_cascade_service():
    from apps.backend.dependencies import get_goal_cascade_service

    return get_goal_cascade_service()


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class CascadeLevelResponse(BaseModel):
    """A single node in the cascade tree."""

    level: str
    node_id: str
    node_name: str
    goal_summary: str
    workitem_id: str | None
    progress: float
    children: list[CascadeLevelResponse] = Field(default_factory=list)


# Pydantic v2: model_rebuild resolves forward reference for recursive model
CascadeLevelResponse.model_rebuild()


class CascadeResponse(BaseModel):
    """Full cascade tree response."""

    goal_id: str
    cascade: CascadeLevelResponse


class AlignmentResponse(BaseModel):
    """Alignment score between a goal and work item."""

    goal_id: str
    workitem_id: str
    alignment_score: float
    interpretation: str


# ---------------------------------------------------------------------------
# Internal: mock topology for cascade when MissionNodeStore is unavailable
# ---------------------------------------------------------------------------


def _build_mock_topology(tenant_id: str) -> dict:
    """Build a simple mock topology for development/testing.

    In production, this would be replaced by MissionNodeStore.get_tree().
    """
    return {
        "org": {
            "node_id": f"org-{tenant_id}",
            "name": tenant_id,
            "children": [
                {
                    "node_id": f"dept-default-{tenant_id}",
                    "name": "Default Department",
                    "node_type": "department",
                    "children": [
                        {
                            "node_id": f"team-default-{tenant_id}",
                            "name": "Default Team",
                            "node_type": "team",
                            "children": [
                                {
                                    "node_id": f"agent-default-{tenant_id}",
                                    "name": "Default Agent",
                                    "node_type": "agent",
                                    "children": [],
                                }
                            ],
                        }
                    ],
                }
            ],
        }
    }


def _get_topology(tenant_id: str) -> dict:
    """Get org topology, falling back to mock if DynamoDB is unavailable."""
    try:
        from apps.backend.services.mission_node_store import get_mission_node_store

        store = get_mission_node_store()
        tree = store.get_tree(tenant_id)

        if not tree.get("roots"):
            return _build_mock_topology(tenant_id)

        # Convert MissionNodeStore tree format to cascade topology format
        root = tree["roots"][0]
        return {"org": _convert_node(root)}
    except Exception:
        logger.warning(
            "MissionNodeStore unavailable, using mock topology for tenant %s",
            tenant_id,
            exc_info=True,
        )
        return _build_mock_topology(tenant_id)


def _convert_node(node: dict) -> dict:
    """Convert a MissionNodeStore node to cascade topology format."""
    return {
        "node_id": node.get("node_id", ""),
        "name": node.get("name", ""),
        "node_type": node.get("node_type", "org"),
        "children": [_convert_node(c) for c in node.get("children", [])],
    }


def _get_goal(tenant_id: str, goal_id: str) -> dict | None:
    """Fetch a goal from GoalStore, returning None if unavailable."""
    try:
        from apps.backend.api.goals import GoalStore

        store = GoalStore()
        return store.get(tenant_id, goal_id)
    except Exception:
        logger.warning("GoalStore unavailable for goal %s", goal_id, exc_info=True)
        return None


# ---------------------------------------------------------------------------
# In-memory cascade cache (per-request lifecycle in production;
# kept simple here for MVP)
# ---------------------------------------------------------------------------

_cascade_cache: dict[str, dict] = {}


def _cascade_level_to_response(node) -> CascadeLevelResponse:
    """Convert a CascadeLevel dataclass to response model."""
    return CascadeLevelResponse(
        level=node.level,
        node_id=node.node_id,
        node_name=node.node_name,
        goal_summary=node.goal_summary,
        workitem_id=node.workitem_id,
        progress=node.progress,
        children=[_cascade_level_to_response(c) for c in node.children],
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("/{goal_id}/cascade", response_model=CascadeResponse)
async def decompose_goal(
    goal_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CascadeResponse:
    """Decompose a goal through the org hierarchy."""
    goal = _get_goal(tenant_id, goal_id)
    if goal is None:
        # Allow cascade even without a persisted goal (use goal_id as title)
        goal = {"goal_id": goal_id, "title": goal_id, "description": "", "priority": "medium"}

    topology = _get_topology(tenant_id)
    svc = _get_cascade_service()
    cascade = svc.decompose_from_topology(goal, topology)

    # Cache for subsequent GET
    cache_key = f"{tenant_id}:{goal_id}"
    _cascade_cache[cache_key] = {"goal": goal, "cascade": cascade}

    return CascadeResponse(
        goal_id=goal_id,
        cascade=_cascade_level_to_response(cascade),
    )


@router.get("/{goal_id}/cascade", response_model=CascadeResponse)
async def get_cascade(
    goal_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CascadeResponse:
    """Get the cascade tree for a goal with current progress."""
    cache_key = f"{tenant_id}:{goal_id}"
    cached = _cascade_cache.get(cache_key)

    if cached:
        svc = _get_cascade_service()
        cascade = cached["cascade"]
        # Recompute progress
        svc.compute_cascade_progress(cascade)
        return CascadeResponse(
            goal_id=goal_id,
            cascade=_cascade_level_to_response(cascade),
        )

    # No cached cascade — build fresh
    goal = _get_goal(tenant_id, goal_id)
    if goal is None:
        goal = {"goal_id": goal_id, "title": goal_id, "description": "", "priority": "medium"}

    topology = _get_topology(tenant_id)
    svc = _get_cascade_service()
    cascade = svc.decompose_from_topology(goal, topology)

    return CascadeResponse(
        goal_id=goal_id,
        cascade=_cascade_level_to_response(cascade),
    )


@router.get("/{goal_id}/alignment", response_model=AlignmentResponse)
async def get_alignment(
    goal_id: str,
    workitem_id: str = Query(..., description="Work item ID to check alignment for"),
    workitem_text: str = Query("", description="Work item text (title + description)"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> AlignmentResponse:
    """Compute alignment score between a goal and a work item."""
    goal = _get_goal(tenant_id, goal_id)
    if goal is None:
        goal = {"goal_id": goal_id, "title": goal_id, "description": ""}

    goal_text = f"{goal.get('title', '')} {goal.get('description', '')}"

    svc = _get_cascade_service()
    score = svc.compute_alignment_score(goal_text, workitem_text)

    if score >= 0.7:
        interpretation = "strongly aligned"
    elif score >= 0.4:
        interpretation = "moderately aligned"
    elif score > 0.0:
        interpretation = "weakly aligned"
    else:
        interpretation = "not aligned"

    return AlignmentResponse(
        goal_id=goal_id,
        workitem_id=workitem_id,
        alignment_score=round(score, 4),
        interpretation=interpretation,
    )
