"""Managed server-side workspace terminal API.

This surface executes commands inside Workweaver-managed workspace roots. It is
not a pass-through terminal on the user's local machine.
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from datetime import datetime, timedelta
from apps.backend.utils.time import utc_now as _utc_now
from pathlib import Path
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field

from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.api.workspace._core import (
    CommandOptions,
    CommandResult,
    WorkspaceExecutionActor,
    get_workspace_terminal_actor,
    get_workspace_root,
    resolve_workspace_path,
    run_local_command,
)
from apps.backend.services.workspace_terminal_session_store import (
    get_workspace_terminal_session_store,
)

logger = logging.getLogger(__name__)


router = APIRouter(prefix="/api/v1/workspace/terminal", tags=["workspace", "terminal"])

DEFAULT_SESSION_TTL_SECONDS = 15 * 60
MAX_SESSION_TTL_SECONDS = 24 * 60 * 60
MAX_COMMAND_TIMEOUT_SECONDS = 300


def get_audit_logger():
    from apps.backend.services.audit_logger import get_audit_logger as _get_audit_logger

    return _get_audit_logger()


def _audit_action(name: object):
    if hasattr(name, "name") and hasattr(name, "value"):
        return name
    from apps.backend.services.audit_logger import AuditAction

    try:
        return getattr(AuditAction, str(name))
    except AttributeError:
        return AuditAction(str(name))


def _audit_severity(name: object):
    if hasattr(name, "name") and hasattr(name, "value"):
        return name
    from apps.backend.services.audit_logger import AuditSeverity

    try:
        return getattr(AuditSeverity, str(name))
    except AttributeError:
        return AuditSeverity(str(name))


def __getattr__(name: str):
    if name == "AuditAction":
        from apps.backend.services.audit_logger import AuditAction

        return AuditAction
    if name == "AuditSeverity":
        from apps.backend.services.audit_logger import AuditSeverity

        return AuditSeverity
    raise AttributeError(name)


class TerminalSessionCreateRequest(BaseModel):
    cwd: str = Field(default=".", description="Starting directory under workspace root")
    ttl_seconds: int = Field(
        default=DEFAULT_SESSION_TTL_SECONDS,
        ge=60,
        le=MAX_SESSION_TTL_SECONDS,
        description="Session TTL in seconds",
    )
    run_id: str | None = Field(default=None, description="Optional governed mission run binding")
    agent_id: str | None = Field(default=None, description="Optional governed agent binding")


class TerminalCommandRequest(BaseModel):
    command: str = Field(min_length=1, max_length=12_000)
    cwd: str = Field(default=".", description="Directory under workspace root")
    timeout_seconds: int = Field(
        default=30,
        ge=1,
        le=MAX_COMMAND_TIMEOUT_SECONDS,
        description="Command timeout in seconds",
    )
    environment: dict[str, str] = Field(default_factory=dict)
    budget_cost: float = Field(default=1.0, gt=0, le=100.0)


class TerminalSessionResponse(BaseModel):
    session_id: str
    tenant_id: str
    working_dir: str
    created_at: str
    expires_at: str
    ttl_seconds: int
    workspace_root: str
    command_hint: str
    run_id: str | None = None
    agent_id: str | None = None


class TerminalCommandResponse(BaseModel):
    session_id: str
    tenant_id: str
    command: str
    cwd: str
    exit_code: int | None
    timed_out: bool
    stdout: str
    stderr: str
    duration_ms: int
    run_id: str | None = None
    agent_id: str | None = None
    run_status: str | None = None
    execution_budget_used: float | None = None
    execution_budget_limit: float | None = None
    governance_action: str | None = None
    stop_evidence_id: str | None = None
    stop_evidence_url: str | None = None


class TerminalSessionListResponse(BaseModel):
    tenant_id: str
    sessions: list[TerminalSessionResponse]
    count: int


@dataclass
class TerminalSessionState:
    tenant_id: str
    created_at: datetime
    expires_at: datetime
    working_dir: str
    last_used_at: datetime | None = None
    last_command: str = ""
    last_exit_code: int | None = None
    last_duration_ms: int | None = None
    last_timed_out: bool = False
    run_id: str | None = None
    agent_id: str | None = None
    stop_evidence_id: str | None = None
    stop_evidence_url: str | None = None


def _safe_ttl(ttl_seconds: int) -> int:
    if ttl_seconds < 60:
        return 60
    if ttl_seconds > MAX_SESSION_TTL_SECONDS:
        return MAX_SESSION_TTL_SECONDS
    return ttl_seconds


def _get_run_state_service():
    from apps.backend.services.mission_run.state import get_mission_run_state_service

    return get_mission_run_state_service()


def _require_governed_run(tenant_id: str, run_id: str, agent_id: str) -> dict[str, object]:
    service = _get_run_state_service()
    state = service.get_run(tenant_id=tenant_id, run_id=run_id)
    if state is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Mission run not found")
    if str(state.get("status") or "") != "active":
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Mission run is not active")
    execution_budgets = dict(state.get("agent_execution_budgets") or {})
    if agent_id not in execution_budgets:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"No execution budget configured for agent '{agent_id}'",
        )
    return state


def _serialize_state(session_id: str, state: TerminalSessionState) -> dict[str, object]:
    payload: dict[str, object] = {
        "session_id": session_id,
        "tenant_id": state.tenant_id,
        "created_at": state.created_at.isoformat(),
        "expires_at": state.expires_at.isoformat(),
        "working_dir": state.working_dir,
        "last_command": state.last_command,
        "last_timed_out": state.last_timed_out,
    }
    if state.last_used_at is not None:
        payload["last_used_at"] = state.last_used_at.isoformat()
    if state.last_exit_code is not None:
        payload["last_exit_code"] = state.last_exit_code
    if state.last_duration_ms is not None:
        payload["last_duration_ms"] = state.last_duration_ms
    if state.run_id:
        payload["run_id"] = state.run_id
    if state.agent_id:
        payload["agent_id"] = state.agent_id
    if state.stop_evidence_id:
        payload["stop_evidence_id"] = state.stop_evidence_id
    if state.stop_evidence_url:
        payload["stop_evidence_url"] = state.stop_evidence_url
    return payload


def _parse_datetime(raw: object) -> datetime | None:
    value = str(raw or "").strip()
    if not value:
        return None
    try:
        return datetime.fromisoformat(value)
    except ValueError:
        return None


def _deserialize_state(record: dict[str, object]) -> TerminalSessionState:
    created_at = _parse_datetime(record.get("created_at")) or _utc_now()
    expires_at = _parse_datetime(record.get("expires_at")) or created_at
    last_used_at = _parse_datetime(record.get("last_used_at"))
    return TerminalSessionState(
        tenant_id=str(record.get("tenant_id") or "").strip(),
        created_at=created_at,
        expires_at=expires_at,
        working_dir=str(record.get("working_dir") or "").strip(),
        last_used_at=last_used_at,
        last_command=str(record.get("last_command") or ""),
        last_exit_code=record.get("last_exit_code") if isinstance(record.get("last_exit_code"), int) else None,
        last_duration_ms=record.get("last_duration_ms") if isinstance(record.get("last_duration_ms"), int) else None,
        last_timed_out=bool(record.get("last_timed_out")),
        run_id=str(record.get("run_id") or "") or None,
        agent_id=str(record.get("agent_id") or "") or None,
        stop_evidence_id=str(record.get("stop_evidence_id") or "") or None,
        stop_evidence_url=str(record.get("stop_evidence_url") or "") or None,
    )


async def _persist_session(session_id: str, state: TerminalSessionState) -> None:
    await get_workspace_terminal_session_store().put_session(
        tenant_id=state.tenant_id,
        session_id=session_id,
        data=_serialize_state(session_id, state),
    )


async def _delete_session(tenant_id: str, session_id: str) -> None:
    await get_workspace_terminal_session_store().delete_session(tenant_id, session_id)


async def _load_session(tenant_id: str, session_id: str) -> TerminalSessionState | None:
    record = await get_workspace_terminal_session_store().get_session(tenant_id, session_id)
    if not record:
        return None
    state = _deserialize_state(record)
    if state.tenant_id != tenant_id:
        return None
    return state


async def _list_active_sessions(tenant_id: str, now: datetime) -> list[tuple[str, TerminalSessionState]]:
    records = await get_workspace_terminal_session_store().list_sessions(tenant_id)
    active: list[tuple[str, TerminalSessionState]] = []
    expired: list[str] = []
    for record in records:
        session_id = str(record.get("session_id") or "").strip()
        if not session_id:
            continue
        state = _deserialize_state(record)
        if state.tenant_id != tenant_id:
            continue
        if state.expires_at < now:
            expired.append(session_id)
            continue
        active.append((session_id, state))
    for session_id in expired:
        await _delete_session(tenant_id, session_id)
    return active


def _relative_to_root(root: Path, target: Path) -> str:
    return target.relative_to(root).as_posix()


def _audit_terminal_event(
    actor: WorkspaceExecutionActor,
    action: object,
    resource_type: str,
    resource_id: str,
    metadata: dict[str, object],
    severity: object = "INFO",
) -> None:
    try:
        audit_action = _audit_action(action)
        audit_severity = _audit_severity(severity)
        get_audit_logger().log(
            action=audit_action,
            tenant_id=actor.tenant_id,
            user_id=actor.user_id,
            impersonator_id=actor.impersonator_id,
            resource_type=resource_type,
            resource_id=resource_id,
            severity=audit_severity,
            metadata=metadata,
            ip_address=actor.ip_address,
            user_agent=actor.user_agent,
        )
    except Exception:
        logger.warning(
            "Terminal audit logging failed for tenant=%s user=%s action=%s",
            actor.tenant_id,
            actor.user_id,
            action,
            exc_info=True,
        )


def _format_session(
    session_id: str,
    tenant_id: str,
    state: TerminalSessionState,
    ttl: int,
) -> TerminalSessionResponse:
    return TerminalSessionResponse(
        session_id=session_id,
        tenant_id=tenant_id,
        working_dir=state.working_dir,
        created_at=state.created_at.isoformat(),
        expires_at=state.expires_at.isoformat(),
        ttl_seconds=ttl,
        workspace_root=str(get_workspace_root(tenant_id)),
        command_hint=f"POST /api/v1/workspace/terminal/{session_id}/command",
        run_id=state.run_id,
        agent_id=state.agent_id,
    )


@router.post("", response_model=TerminalSessionResponse, status_code=status.HTTP_201_CREATED)
async def create_terminal_session(
    request: Request,
    body: TerminalSessionCreateRequest,
) -> TerminalSessionResponse:
    actor = get_workspace_terminal_actor(request)
    tenant_id = actor.tenant_id
    workspace_root = get_workspace_root(tenant_id)
    working_dir = resolve_workspace_path(workspace_root, body.cwd)
    if not working_dir.exists() or not working_dir.is_dir():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Working directory not found",
        )
    run_id = str(body.run_id or "").strip() or None
    agent_id = str(body.agent_id or "").strip() or None
    if bool(run_id) != bool(agent_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="run_id and agent_id must be provided together",
        )
    if run_id and agent_id:
        _require_governed_run(tenant_id, run_id, agent_id)

    session_id = uuid4().hex
    ttl = _safe_ttl(body.ttl_seconds)
    now = _utc_now()
    state = TerminalSessionState(
        tenant_id=tenant_id,
        created_at=now,
        expires_at=now + timedelta(seconds=ttl),
        working_dir=str(working_dir),
        run_id=run_id,
        agent_id=agent_id,
    )
    await _persist_session(session_id, state)

    _audit_terminal_event(
        actor=actor,
        action="WORKSPACE_TERMINAL_SESSION_CREATE",
        resource_type="workspace_terminal_session",
        resource_id=session_id,
        metadata={
            "command": "create_session",
            "working_dir": str(working_dir),
            "ttl_seconds": ttl,
            "run_id": run_id,
            "agent_id": agent_id,
        },
    )

    return _format_session(session_id, tenant_id, state, ttl)


@router.get("", response_model=TerminalSessionListResponse)
async def list_terminal_sessions(
    request: Request,
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> TerminalSessionListResponse:
    actor = get_workspace_terminal_actor(request)
    tenant_id = actor.tenant_id
    now = _utc_now()

    sessions = []
    for session_id, state in await _list_active_sessions(tenant_id, now):
        ttl = int((state.expires_at - now).total_seconds())
        if ttl < 0:
            ttl = 0
        sessions.append(_format_session(session_id, tenant_id, state, ttl))
    sessions.sort(key=lambda item: item.created_at)
    sessions, _total = paginate_items(sessions, pagination)

    return TerminalSessionListResponse(
        tenant_id=tenant_id,
        sessions=sessions,
        count=len(sessions),
    )


@router.delete("/{session_id}", status_code=status.HTTP_204_NO_CONTENT)
async def close_terminal_session(request: Request, session_id: str):
    actor = get_workspace_terminal_actor(request)
    tenant_id = actor.tenant_id
    state = await _load_session(tenant_id, session_id)
    if state is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Session not found",
        )
    await _delete_session(tenant_id, session_id)

    _audit_terminal_event(
        actor=actor,
        action="WORKSPACE_TERMINAL_SESSION_CLOSE",
        resource_type="workspace_terminal_session",
        resource_id=session_id,
        metadata={"command": "close_session"},
    )
    # No return statement for 204 No Content response


async def _require_session(tenant_id: str, session_id: str) -> TerminalSessionState:
    now = _utc_now()
    state = await _load_session(tenant_id, session_id)
    if state is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Session not found")
    if state.expires_at < now:
        await _delete_session(tenant_id, session_id)
        raise HTTPException(status_code=status.HTTP_410_GONE, detail="Session expired")
    return state


def _resolve_command_cwd(tenant_root: Path, state: TerminalSessionState, requested: str) -> Path:
    if requested == ".":
        resolved = Path(state.working_dir)
    else:
        resolved = resolve_workspace_path(tenant_root, requested)

    if not resolved.exists():
        raise HTTPException(status_code=404, detail="Working directory not found")
    if not resolved.is_dir():
        raise HTTPException(status_code=400, detail="Working directory is not a directory")
    state.working_dir = str(resolved)
    return resolved


def _command_response(
    session_id: str,
    tenant_id: str,
    cwd: str,
    request: TerminalCommandRequest,
    result: CommandResult,
    run_state: dict[str, object] | None = None,
    execution_record: dict[str, object] | None = None,
) -> TerminalCommandResponse:
    execution_budgets = dict(run_state.get("agent_execution_budgets") or {}) if run_state else {}
    budget_entry = execution_budgets.get(str(execution_record.get("agent_id") or "")) if execution_record else None
    return TerminalCommandResponse(
        session_id=session_id,
        tenant_id=tenant_id,
        command=request.command,
        cwd=cwd,
        exit_code=result.returncode,
        timed_out=result.timed_out,
        stdout=result.stdout,
        stderr=result.stderr,
        duration_ms=result.duration_ms,
        run_id=str(run_state.get("run_id") or "") or None if run_state else None,
        agent_id=str(execution_record.get("agent_id") or "") or None if execution_record else None,
        run_status=str(run_state.get("status") or "") or None if run_state else None,
        execution_budget_used=float(budget_entry.get("used")) if isinstance(budget_entry, dict) else None,
        execution_budget_limit=float(budget_entry.get("limit")) if isinstance(budget_entry, dict) else None,
        governance_action=str(execution_record.get("governance_action") or "") or None if execution_record else None,
        stop_evidence_id=str(execution_record.get("stop_evidence_id") or "") or None if execution_record else None,
        stop_evidence_url=str(execution_record.get("stop_evidence_url") or "") or None if execution_record else None,
    )


@router.post("/{session_id}/command", response_model=TerminalCommandResponse)
async def run_terminal_command(
    request: Request,
    session_id: str,
    body: TerminalCommandRequest,
) -> TerminalCommandResponse:
    actor = get_workspace_terminal_actor(request)
    tenant_id = actor.tenant_id
    state = await _require_session(tenant_id, session_id)
    workspace_root = get_workspace_root(tenant_id)
    cwd_path = _resolve_command_cwd(workspace_root, state, body.cwd)
    if state.run_id and state.agent_id:
        _require_governed_run(tenant_id, state.run_id, state.agent_id)

    result = await run_local_command(
        body.command,
        CommandOptions(
            cwd=cwd_path,
            timeout_seconds=body.timeout_seconds,
            shell=False,
            env=body.environment,
        ),
    )
    _audit_terminal_event(
        actor=actor,
        action="WORKSPACE_TERMINAL_COMMAND",
        resource_type="workspace_terminal_session",
        resource_id=session_id,
        metadata={
            "command": body.command,
            "working_dir": str(cwd_path),
            "timeout_seconds": body.timeout_seconds,
            "exit_code": result.returncode,
            "timed_out": result.timed_out,
        },
        severity="INFO" if result.returncode == 0 and not result.timed_out else "WARNING",
    )
    state.last_used_at = _utc_now()
    state.last_command = body.command
    state.last_exit_code = result.returncode
    state.last_duration_ms = result.duration_ms
    state.last_timed_out = result.timed_out
    run_state: dict[str, object] | None = None
    execution_record: dict[str, object] | None = None
    if state.run_id and state.agent_id:
        run_state, execution_record, _command_row = _get_run_state_service().record_execution_step(
            tenant_id=tenant_id,
            run_id=state.run_id,
            agent_id=state.agent_id,
            operation="workspace_terminal_command",
            fingerprint=f"{cwd_path}:{body.command.strip()}",
            budget_cost=body.budget_cost,
            actor=f"workspace_terminal:{actor.user_id}",
            metadata={
                "session_id": session_id,
                "cwd": str(cwd_path),
                "command": body.command,
                "timeout_seconds": body.timeout_seconds,
                "exit_code": result.returncode,
                "timed_out": result.timed_out,
                "duration_ms": result.duration_ms,
            },
        )
        state.stop_evidence_id = str(execution_record.get("stop_evidence_id") or "") or None
        state.stop_evidence_url = str(execution_record.get("stop_evidence_url") or "") or None
    await _persist_session(session_id, state)
    return _command_response(
        session_id,
        tenant_id,
        str(cwd_path),
        body,
        result,
        run_state=run_state,
        execution_record=execution_record,
    )
