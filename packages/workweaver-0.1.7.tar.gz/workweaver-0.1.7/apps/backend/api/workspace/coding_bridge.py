"""Workspace API for GitHub issue bridge artifacts."""

from __future__ import annotations

from typing import TYPE_CHECKING, Any

from fastapi import APIRouter, HTTPException, Request, status
from pydantic import BaseModel, Field

from apps.backend.api.workspace._core import get_workspace_terminal_actor

if TYPE_CHECKING:
    from apps.backend.services.coding_bridge import CodingBridgeService

router = APIRouter(prefix="/api/v1/workspace/coding-bridge", tags=["workspace", "coding-bridge"])


class CodingBridgeCreateRequest(BaseModel):
    run_id: str = Field(..., min_length=1, max_length=200)
    agent_id: str = Field(..., min_length=1, max_length=200)
    repository: str = Field(..., min_length=3, max_length=200)
    github_credential_ref: str = Field(..., min_length=1, max_length=200)
    title: str = Field(..., min_length=1, max_length=200)
    request_summary: str = Field(..., min_length=1, max_length=4000)
    labels: list[str] = Field(default_factory=list)
    evidence_refs: list[str] = Field(default_factory=list)
    diagnosis: dict[str, Any] | None = None


class CodingBridgeResponse(BaseModel):
    bridge_id: str
    tenant_id: str
    run_id: str
    agent_id: str
    repository: str
    issue_number: int | None = None
    issue_url: str | None = None
    issue_state: str
    related_prs: list[dict[str, Any]] = Field(default_factory=list)
    status: str
    evidence_event_id: str | None = None
    created_at: str
    updated_at: str


def get_coding_bridge_service() -> CodingBridgeService:
    from apps.backend.services.coding_bridge import CodingBridgeService

    return CodingBridgeService()


def get_mission_run_state_service():
    from apps.backend.services.mission_run.state import get_mission_run_state_service as _service_factory

    return _service_factory()


def _require_governed_run(tenant_id: str, run_id: str, agent_id: str) -> None:
    state = get_mission_run_state_service().get_run(tenant_id=tenant_id, run_id=run_id)
    if state is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Mission run not found")
    if str(state.get("status") or "") != "active":
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Mission run is not active")
    execution_budgets = dict(state.get("agent_execution_budgets") or {})
    if agent_id not in execution_budgets:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"No execution budget configured for agent '{agent_id}'",
        )


@router.post("", response_model=CodingBridgeResponse, status_code=status.HTTP_201_CREATED)
async def create_coding_bridge(
    request: Request,
    body: CodingBridgeCreateRequest,
) -> CodingBridgeResponse:
    actor = get_workspace_terminal_actor(request)
    _require_governed_run(actor.tenant_id, body.run_id, body.agent_id)
    service = get_coding_bridge_service()
    try:
        from apps.backend.services.coding_bridge import CodingBridgeCreateInput

        record = await service.create_bridge(
            CodingBridgeCreateInput(
                tenant_id=actor.tenant_id,
                run_id=body.run_id,
                agent_id=body.agent_id,
                repository=body.repository,
                github_credential_ref=body.github_credential_ref,
                title=body.title,
                request_summary=body.request_summary,
                labels=tuple(body.labels),
                evidence_refs=tuple(body.evidence_refs),
                diagnosis=body.diagnosis,
            )
        )
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="GitHub credential not found") from exc
    except PermissionError as exc:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Credential access denied") from exc
    except ValueError as exc:
        logger.error("Invalid coding bridge parameters: %s", exc, exc_info=True)
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid request parameters") from exc
    return CodingBridgeResponse(**record)


@router.get("/{bridge_id}", response_model=CodingBridgeResponse)
async def get_coding_bridge(
    request: Request,
    bridge_id: str,
) -> CodingBridgeResponse:
    actor = get_workspace_terminal_actor(request)
    service = get_coding_bridge_service()
    try:
        record = await service.get_bridge(tenant_id=actor.tenant_id, bridge_id=bridge_id)
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Coding bridge not found") from exc
    except PermissionError as exc:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Credential access denied") from exc
    return CodingBridgeResponse(**record)
