"""Workspace settings APIs for Workweaver Runtime config."""

from __future__ import annotations

import shlex
import re
import socket
import subprocess
import os
from datetime import datetime
from pathlib import Path
import logging

from fastapi import APIRouter, HTTPException, Request, status
from pydantic import BaseModel, Field

from apps.backend.api.workspace._core import (
    CommandOptions,
    WorkspaceExecutionActor,
    get_runtime_settings_path,
    get_tenant_id,
    read_json,
    get_workspace_terminal_actor,
    run_local_command,
    to_audit_entry,
    validate_runtime_settings,
    write_json,
)

logger = logging.getLogger(__name__)


router = APIRouter(prefix="/api/v1/workspace/settings", tags=["workspace", "settings"])
RUNTIME_RESTART_AUDIT_ACTION = "workspace.runtime.restart"


class RuntimeSettingsResponse(BaseModel):
    tenant_id: str
    path: str
    exists: bool
    updated_at: str | None
    settings: dict
    validation_errors: list[str]
    validation_ok: bool


class RuntimeSettingsUpdateRequest(BaseModel):
    settings: dict = Field(default_factory=dict)
    replace: bool = False
    validate_only: bool = False


class RuntimeSettingsRestartRequest(BaseModel):
    reason: str | None = Field(default=None, max_length=1000)
    confirm: bool = False


class RuntimeSettingsRestartResponse(BaseModel):
    tenant_id: str
    requested: bool
    path: str
    executed_command: bool
    command: str | None = None
    output: str | None = None


class DomainVerifyRequest(BaseModel):
    domain: str = Field(..., min_length=1, max_length=253)
    subdomain: str = Field(default="app", min_length=1, max_length=63)
    expected_target: str | None = Field(default=None, max_length=253)
    verification_token: str | None = Field(default=None, max_length=255)


class DomainVerifyResponse(BaseModel):
    tenant_id: str
    status: str
    verified: bool
    domain: str
    subdomain: str
    hostname: str
    expected_target: str | None
    verification_token: str | None
    cname_targets: list[str]
    message: str


def _serialize_metadata(path: Path, exists: bool) -> str | None:
    if not exists:
        return None
    return datetime.fromtimestamp(path.stat().st_mtime).isoformat() + "Z"


def _normalize_dns_name(value: str | None, fallback: str = "") -> str:
    normalized = (value or "").strip().lower()
    if not normalized:
        return fallback
    normalized = normalized.replace("http://", "").replace("https://", "")
    normalized = normalized.strip().strip(".")
    normalized = re.sub(r"\s+", "", normalized)
    return normalized


def _is_dns_label(candidate: str) -> bool:
    if not candidate or len(candidate) > 63:
        return False
    if candidate.startswith("-") or candidate.endswith("-"):
        return False
    return re.fullmatch(r"[a-z0-9-]+", candidate) is not None


def _is_valid_dns_name(candidate: str) -> bool:
    if not candidate or len(candidate) > 253:
        return False
    labels = candidate.split(".")
    if any(not _is_dns_label(label) for label in labels):
        return False
    return True


def _query_cname_records(hostname: str) -> list[str]:
    commands = (
        ["dig", "+short", "CNAME", hostname],
        ["nslookup", "-type=cname", hostname],
    )

    for command in commands:
        try:
            result = subprocess.run(
                command,
                capture_output=True,
                text=True,
                timeout=6,
                check=False,
            )
        except FileNotFoundError:
            continue
        except Exception:
            return []

        output = (result.stdout or "").strip()
        if not output:
            continue

        if command[0] == "dig":
            candidates = [
                line.strip().rstrip(".").lower()
                for line in output.splitlines()
                if line.strip() and line.strip().lower() != hostname.lower()
            ]
        else:
            candidates = []
            for line in output.splitlines():
                lower = line.lower()
                if "canonical name" in lower and "=" in line:
                    _, value = line.split("=", 1)
                    value = value.strip().rstrip(".").lower()
                    if value:
                        candidates.append(value)

        if candidates:
            return candidates

    return []


def _resolve_ips(hostname: str) -> list[str]:
    try:
        infos = socket.getaddrinfo(hostname, None, family=socket.AF_UNSPEC)
    except Exception:
        return []

    ips: list[str] = []
    for info in infos:
        address = info[4][0]
        if address and address not in ips:
            ips.append(address)
    return ips


def _build_domain_verification_target(hostname: str, expected_target: str | None) -> tuple[bool, str, list[str], list[str], list[str]]:
    expected = _normalize_dns_name(expected_target, "")
    cname_records = _query_cname_records(hostname)
    hostname_ips = _resolve_ips(hostname)
    expected_ips = _resolve_ips(expected) if expected else []
    messages: list[str] = []

    if not expected:
        return (
            False,
            "expected_target is required for verification.",
            cname_records,
            hostname_ips,
            expected_ips,
        )

    if any(record == expected for record in cname_records):
        return (
            True,
            "CNAME record matches expected target.",
            cname_records,
            hostname_ips,
            expected_ips,
        )

    if hostname_ips and expected_ips and set(hostname_ips).intersection(expected_ips):
        return (
            True,
            "Hostname resolves to the same IP range as expected target.",
            cname_records,
            hostname_ips,
            expected_ips,
        )

    if cname_records:
        messages.append(f"CNAME mismatch: expected '{expected}' but got '{cname_records[0]}'")
    else:
        messages.append("No CNAME record found for hostname.")

    if expected:
        messages.append(f"Expected target lookup IPs: {', '.join(expected_ips) if expected_ips else 'unresolved'}")
    if hostname_ips:
        messages.append(f"Hostname resolves to: {', '.join(hostname_ips)}")
    return (False, "; ".join(messages), cname_records, hostname_ips, expected_ips)


def _log_runtime_restart_audit(
    actor: WorkspaceExecutionActor,
    action: str,
    resource: str,
    command: str | None = None,
    metadata: dict[str, object] | None = None,
    severity: str = "info",
) -> None:
    try:
        from apps.backend.services.audit_logger import AuditAction, AuditSeverity, get_audit_logger

        get_audit_logger().log(
            action=AuditAction(action),
            tenant_id=actor.tenant_id,
            user_id=actor.user_id,
            impersonator_id=actor.impersonator_id,
            resource_type="runtime_settings",
            resource_id=resource,
            severity=AuditSeverity(severity),
            metadata={
                **(metadata or {}),
                **({"command": command} if command else {}),
                "ip_address": actor.ip_address,
                "user_agent": actor.user_agent,
            },
        )
    except Exception:
        logger.warning(
            "Runtime restart audit logging failed for tenant=%s user=%s",
            actor.tenant_id,
            actor.user_id,
            exc_info=True,
        )


@router.get("/runtime", response_model=RuntimeSettingsResponse)
async def get_runtime_settings(request: Request) -> RuntimeSettingsResponse:
    tenant_id = get_tenant_id(request)
    settings_path = get_runtime_settings_path()
    settings, exists = read_json(settings_path)
    errors = validate_runtime_settings(settings)

    return RuntimeSettingsResponse(
        tenant_id=tenant_id,
        path=str(settings_path),
        exists=exists,
        updated_at=_serialize_metadata(settings_path, exists),
        settings=settings,
        validation_errors=errors,
        validation_ok=(len(errors) == 0),
    )


@router.put("/runtime", response_model=RuntimeSettingsResponse)
async def update_runtime_settings(
    request: Request,
    body: RuntimeSettingsUpdateRequest,
) -> RuntimeSettingsResponse:
    tenant_id = get_tenant_id(request)
    settings_path = get_runtime_settings_path()
    current, exists = read_json(settings_path)

    merged = body.settings if body.replace else {**current, **body.settings}
    validation_errors = validate_runtime_settings(merged)

    if body.validate_only:
        return RuntimeSettingsResponse(
            tenant_id=tenant_id,
            path=str(settings_path),
            exists=exists,
            updated_at=_serialize_metadata(settings_path, exists),
            settings=merged,
            validation_errors=validation_errors,
            validation_ok=(len(validation_errors) == 0),
        )

    if validation_errors:
        return RuntimeSettingsResponse(
            tenant_id=tenant_id,
            path=str(settings_path),
            exists=exists,
            updated_at=_serialize_metadata(settings_path, exists),
            settings=current,
            validation_errors=validation_errors,
            validation_ok=False,
        )

    write_json(settings_path, merged)
    _ = to_audit_entry(
        "workspace_settings_updated",
        tenant_id,
        {
            "path": str(settings_path),
            "replace": body.replace,
        },
        impersonator_id=str(
            getattr(request.state, "authenticated_impersonator_id", "")
            or getattr(request.state, "impersonator_id", "")
            or "",
        ).strip()
        or None,
    )
    return RuntimeSettingsResponse(
        tenant_id=tenant_id,
        path=str(settings_path),
        exists=True,
        updated_at=_serialize_metadata(settings_path, True),
        settings=merged,
        validation_errors=[],
        validation_ok=True,
    )


@router.post("/runtime/restart", response_model=RuntimeSettingsRestartResponse)
async def restart_workspace_runtime(
    request: Request,
    body: RuntimeSettingsRestartRequest,
) -> RuntimeSettingsRestartResponse:
    actor = get_workspace_terminal_actor(request)
    tenant_id = actor.tenant_id
    if not body.confirm:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Restart requires explicit confirmation",
        )

    settings_path = get_runtime_settings_path()
    command = _coalesce_restart_command()
    if not command:
        _log_runtime_restart_audit(
            actor=actor,
            action=RUNTIME_RESTART_AUDIT_ACTION,
            resource=str(settings_path),
            metadata={
                "result": "not_configured",
                "path": str(settings_path),
            },
            severity="warning",
        )
        return RuntimeSettingsRestartResponse(
            tenant_id=tenant_id,
            requested=True,
            path=str(settings_path),
            executed_command=False,
            command=None,
            output="Restart command not configured; restart request recorded only.",
        )

    try:
        parsed_command = shlex.split(command)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Configured restart command is invalid",
        )
    if not parsed_command:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Configured restart command is empty",
        )

    result = await run_local_command(
        parsed_command,
        CommandOptions(
            cwd=settings_path.parent,
            timeout_seconds=60,
            shell=False,
        ),
    )
    output = (result.stdout or "").rstrip()
    if result.stderr:
        if output:
            output = f"{output}\n{result.stderr}"
        else:
            output = result.stderr

    _log_runtime_restart_audit(
        actor=actor,
        action=RUNTIME_RESTART_AUDIT_ACTION,
        resource=str(settings_path),
        command=command,
        metadata={
            "result": "executed" if result.returncode == 0 and not result.timed_out else "failed",
            "path": str(settings_path),
            "return_code": result.returncode,
            "timed_out": result.timed_out,
        },
        severity=(
            "warning"
            if result.returncode not in (None, 0) or result.timed_out
            else "info"
        ),
    )

    return RuntimeSettingsRestartResponse(
        tenant_id=tenant_id,
        requested=True,
        path=str(settings_path),
        executed_command=True,
        command=command,
        output=output.strip(),
    )


@router.post("/domain/verify", response_model=DomainVerifyResponse)
async def verify_domain(
    request: Request,
    body: DomainVerifyRequest,
) -> DomainVerifyResponse:
    tenant_id = get_tenant_id(request)
    domain = _normalize_dns_name(body.domain)
    if not _is_valid_dns_name(domain):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid domain value",
        )

    subdomain = _normalize_dns_name(body.subdomain, "app")
    if not _is_valid_dns_name(subdomain):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid subdomain value",
        )

    expected_target = _normalize_dns_name(body.expected_target, "")
    if expected_target and not _is_valid_dns_name(expected_target):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid expected_target value",
        )

    hostname = f"{subdomain}.{domain}"
    verified, message, cname_targets, _, _ = _build_domain_verification_target(
        hostname=hostname,
        expected_target=expected_target,
    )
    status_value = "verified" if verified else "not_verified"
    if not verified:
        message = message or "Domain verification did not match expected target."

    return DomainVerifyResponse(
        tenant_id=tenant_id,
        status=status_value,
        verified=verified,
        domain=domain,
        subdomain=subdomain,
        hostname=hostname,
        expected_target=expected_target or None,
        verification_token=body.verification_token,
        cname_targets=cname_targets,
        message=message,
    )


def _coalesce_restart_command() -> str:
    return os.environ.get("WORKWEAVER_RUNTIME_RESTART_COMMAND", "").strip()


__all__ = [
    "router",
    "RuntimeSettingsResponse",
    "RuntimeSettingsUpdateRequest",
    "RuntimeSettingsRestartRequest",
    "RuntimeSettingsRestartResponse",
    "DomainVerifyRequest",
    "DomainVerifyResponse",
]
