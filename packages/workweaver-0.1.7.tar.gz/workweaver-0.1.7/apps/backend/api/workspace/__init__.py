"""Workspace API router aggregation."""

from __future__ import annotations

from fastapi import APIRouter

from apps.backend.api.workspace.coding_bridge import router as coding_bridge_router
from apps.backend.api.workspace.coding_runs import router as coding_runs_router
from apps.backend.api.workspace.files import router as files_router
from apps.backend.api.workspace.repos import router as repos_router
from apps.backend.api.workspace.settings import router as settings_router
from apps.backend.api.workspace.terminal import router as terminal_router

router = APIRouter()

router.include_router(coding_bridge_router)
router.include_router(coding_runs_router)
router.include_router(terminal_router)
router.include_router(files_router)
router.include_router(repos_router)
router.include_router(settings_router)

__all__ = ["router"]
