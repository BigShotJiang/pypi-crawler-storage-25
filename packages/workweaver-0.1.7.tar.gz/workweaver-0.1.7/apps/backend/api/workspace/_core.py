"""Shared helpers for workspace API endpoints.

Provides tenant-aware workspace path resolution, command execution helpers,
and JSON file read/write primitives for workspace and Workweaver Runtime settings.
"""

from __future__ import annotations

import asyncio
import json
import logging
import os
import re
import shlex
import tempfile
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

from fastapi import HTTPException, Request, status

from apps.backend.api.dependencies.tenant_auth import resolve_verified_tenant_id
from apps.backend.utils.tenant import strip_tenant_prefix

logger = logging.getLogger(__name__)

TERMINAL_OUTPUT_LIMIT_BYTES = 256 * 1024
WORKSPACE_TERMINAL_ALLOWED_ROLES_ENV = "WORKSPACE_TERMINAL_ALLOWED_ROLES"
# SECURITY (#1927): WORKSPACE_TERMINAL_AUTH_REQUIRED removed — auth is always required.
# No caller may bypass terminal authentication.
WORKSPACE_TERMINAL_ALLOWED_ENV_KEYS = frozenset({"HOME", "LANG", "LC_ALL", "LC_MESSAGES", "TERM", "TZ"})
# Subset of env vars safe to expose to subprocesses (excludes AWS creds, secrets, tokens).
# os.environ.copy() must NEVER be used — it leaks AWS_ACCESS_KEY_ID and secrets.
_SUBPROCESS_SAFE_ENV_KEYS = frozenset(
    {
        "HOME",
        "LANG",
        "LC_ALL",
        "LC_CTYPE",
        "LC_MESSAGES",
        "PATH",
        "SHELL",
        "TERM",
        "TZ",
        "USER",
        "LOGNAME",
        "TMPDIR",
        "TEMP",
        "TMP",
    }
)


def _coalesce_env(*names: str, default: str = "") -> str:
    for name in names:
        value = os.environ.get(name, "").strip()
        if value:
            return value
    return default


def _coalesce_bool_env(*names: str, default: bool = False) -> bool:
    for name in names:
        value = os.environ.get(name, "").strip().lower()
        if not value:
            continue
        return value in {"1", "true", "yes", "on"}
    return default


def _extract_client_ip(request: Request) -> str | None:
    """Extract real client IP from request, considering proxy headers.

    Checks X-Forwarded-For and X-Real-IP headers before falling back to
    request.client.host. This ensures audit logs capture the actual client
    IP rather than the proxy/load balancer IP.

    Args:
        request: FastAPI request object

    Returns:
        Client IP address or None if unavailable
    """
    # Check X-Forwarded-For (can be comma-separated list, first is client)
    x_forwarded_for = request.headers.get("x-forwarded-for")
    if x_forwarded_for:
        # Take the first IP in the chain (original client)
        return x_forwarded_for.split(",")[0].strip()

    # Check X-Real-IP (single IP)
    x_real_ip = request.headers.get("x-real-ip")
    if x_real_ip:
        return x_real_ip.strip()

    # Fall back to direct connection IP
    return request.client.host if request.client else None


def _tenant_id_from_request(request: Request) -> str:
    tenant_id = str(getattr(request.state, "tenant_id", "") or "").strip()
    if tenant_id:
        return tenant_id
    try:
        return resolve_verified_tenant_id(request)
    except HTTPException:
        return ""


def _normalize_tenant_id(value: str) -> str:
    tenant_id = (value or "").strip()
    if not tenant_id:
        return ""
    if tenant_id.startswith("TENANT#"):
        return tenant_id
    return f"TENANT#{tenant_id}"


def _parse_roles(raw: str | None) -> frozenset[str]:
    if not raw:
        return frozenset()
    values = re.split(r"[,\s]+", raw.strip())
    return frozenset(role.lower() for role in values if role and not role.startswith("#") and role.strip())


def _configured_terminal_roles() -> frozenset[str]:
    configured = _coalesce_env(WORKSPACE_TERMINAL_ALLOWED_ROLES_ENV, default="admin")
    roles = _parse_roles(configured)
    if not roles:
        return frozenset({"admin"})
    return roles


@dataclass
class WorkspaceExecutionActor:
    tenant_id: str
    user_id: str
    roles: frozenset[str]
    ip_address: str | None = None
    user_agent: str | None = None
    impersonator_id: str | None = None


def _resolve_roles_from_session(tenant_id: str, user_id: str) -> frozenset[str]:
    """Resolve user roles from the server-side user record, never from request headers.

    Falls back to the configured terminal-roles set when the record lookup
    fails (e.g. DDB unavailable), which is strictly more restrictive than
    trusting a client-supplied role header.
    """
    if not tenant_id or not user_id:
        return frozenset()
    try:
        from apps.backend.api.dependencies.tenant_auth import _resolve_user_record

        record = _resolve_user_record(strip_tenant_prefix(tenant_id), user_id)
        role_value = str(record.get("role", "")).strip().lower()
        if role_value:
            return frozenset({role_value})
    except Exception:
        logger.warning(
            "Failed to resolve user role from session for tenant=%s user=%s; denying by default",
            tenant_id,
            user_id,
        )
    return frozenset()


def get_workspace_terminal_actor(request: Request) -> WorkspaceExecutionActor:
    """Resolve actor identity for workspace terminal/control-style endpoints.

    Security (#1927): Roles are resolved exclusively from the verified session's
    user record. Client-supplied X-User-Role headers are ignored. Anonymous
    callers are rejected with 401.
    """
    tenant_id = _normalize_tenant_id(_tenant_id_from_request(request))
    user_id = str(getattr(request.state, "user_id", "") or "").strip()
    impersonator_id = str(
        getattr(request.state, "authenticated_impersonator_id", "")
        or getattr(request.state, "impersonator_id", "")
        or "",
    ).strip() or None

    # Security (#1927): All callers must be authenticated. No fallback.
    if not tenant_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing organization identity",
        )
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing user identity",
        )

    # Resolve roles from server-side session, never from client headers.
    roles = _resolve_roles_from_session(tenant_id, user_id)
    if not roles:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Missing user role",
        )

    configured_roles = _configured_terminal_roles()
    if configured_roles and not roles.intersection(configured_roles):
        logger.warning(
            "Terminal authorization denied for tenant=%s user=%s roles=%s",
            tenant_id,
            user_id,
            ",".join(sorted(roles)),
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User role is not authorized for terminal actions",
        )

    return WorkspaceExecutionActor(
        tenant_id=tenant_id,
        user_id=user_id,
        roles=roles,
        ip_address=_extract_client_ip(request),
        user_agent=request.headers.get("user-agent"),
        impersonator_id=impersonator_id,
    )


def get_tenant_id(request: Request) -> str:
    """Resolve tenant id from verified auth context.

    Security (#1928): The TENANT#shared fallback is removed. All callers must
    be authenticated. Raises 401 when no verified tenant identity is present.
    """
    tenant_id = _tenant_id_from_request(request)
    if tenant_id:
        return tenant_id
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Authentication required",
    )


def _default_workspace_root() -> str:
    return _coalesce_env(
        "WORKSPACE_ROOT",
        "WORKWEAVER_RUNTIME_WORKSPACE_ROOT",
        default="/workspace",
    )


def _is_local_workspace_env() -> bool:
    return _coalesce_env("ENVIRONMENT", "WORKWEAVER_ENV", default="").lower() in {"dev", "local", "test"}


def _should_scope_tenant() -> bool:
    return _coalesce_env("WORKSPACE_TENANT_SCOPING", default="false").lower() in {
        "1",
        "true",
        "yes",
        "on",
    }


def get_runtime_settings_path() -> Path:
    return Path(
        _coalesce_env(
            "WORKWEAVER_RUNTIME_SETTINGS_PATH",
            "WORKWEAVER_RUNTIME_CONFIG_PATH",
            default="/opt/workweaver-runtime/config/runtime.json",
        )
    ).expanduser()


def get_workspace_root(tenant_id: str) -> Path:
    """Resolve canonical workspace root for the tenant and ensure it exists."""
    configured_root = Path(_default_workspace_root()).expanduser()
    root = configured_root.resolve()
    if _should_scope_tenant():
        safe = re.sub(r"[^A-Za-z0-9_.-]", "_", strip_tenant_prefix(tenant_id)).strip()
        safe = safe or "tenant"
        root = root / safe
    try:
        root.mkdir(parents=True, exist_ok=True)
    except PermissionError:
        if not _is_local_workspace_env():
            raise
        fallback_base = Path(
            _coalesce_env(
                "WORKSPACE_FALLBACK_ROOT",
                default=os.path.join(tempfile.gettempdir(), "workweaver-workspace"),
            )
        ).expanduser()
        fallback_root = fallback_base.resolve()
        if _should_scope_tenant():
            safe = re.sub(r"[^A-Za-z0-9_.-]", "_", strip_tenant_prefix(tenant_id)).strip()
            safe = safe or "tenant"
            fallback_root = fallback_root / safe
        fallback_root.mkdir(parents=True, exist_ok=True)
        logger.warning(
            "Workspace root %s was not writable; falling back to %s for local development",
            configured_root,
            fallback_root,
        )
        return fallback_root
    return root


def _normalize_relative_path(relative_path: str | None) -> str:
    candidate = (relative_path or "").strip()
    if not candidate or candidate == ".":
        return "."
    if "\0" in candidate:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Path contains unsupported NUL byte",
        )
    if candidate.startswith("/") or re.search(r"(^|/)\.\.(/|$)", candidate):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Path traversal is not allowed",
        )
    return candidate


def resolve_workspace_path(tenant_root: Path, relative_path: str | None) -> Path:
    """Resolve and sanitize a tenant workspace relative path."""
    workspace_root = tenant_root.resolve()
    safe_rel = _normalize_relative_path(relative_path)
    target = (workspace_root / safe_rel).resolve()
    workspace_root_str = str(workspace_root)
    target_str = str(target)
    if target_str != workspace_root_str and not target_str.startswith(f"{workspace_root_str}{os.sep}"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Path is outside the workspace root",
        )
    return target


def to_audit_entry(
    event_type: str,
    tenant_id: str,
    payload: dict[str, Any],
    impersonator_id: str | None = None,
) -> dict[str, Any]:
    return {
        "event_type": event_type,
        "tenant_id": tenant_id,
        "timestamp": datetime.now(UTC).replace(tzinfo=None).isoformat() + "Z",
        "payload": payload,
        **({"impersonator_id": impersonator_id} if impersonator_id else {}),
    }


def read_json(path: Path) -> tuple[dict[str, Any], bool]:
    if not path.exists():
        return {}, False

    try:
        with path.open("r", encoding="utf-8") as handle:
            data = json.load(handle)
    except json.JSONDecodeError as exc:
        logger.error("Invalid JSON in %s: %s", path, exc)
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail="Invalid JSON in settings document",
        ) from exc

    if not isinstance(data, dict):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail="Expected JSON object for settings document",
        )
    return data, True


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = dict(payload)
    # M7: Use unpredictable temp filename (mkstemp) in same directory to prevent TOCTOU
    # races on the temp file. Permissions set on temp file before atomic rename so there
    # is never a window where the final path is world-readable.
    fd, temp_str = tempfile.mkstemp(dir=str(path.parent), prefix=".write_", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as handle:
            json.dump(payload, handle, indent=2, sort_keys=True)
        try:
            os.chmod(temp_str, 0o600)
        except PermissionError:
            logger.warning("Unable to set file mode for temp %s — file may be world-readable", temp_str)
        os.replace(temp_str, str(path))
    except Exception:
        try:
            os.unlink(temp_str)
        except OSError:
            pass
        raise


def validate_runtime_settings(payload: dict[str, Any]) -> list[str]:
    issues: list[str] = []
    for key, value in payload.items():
        if not isinstance(key, str):
            issues.append("All top-level keys must be strings")
        if isinstance(key, str) and not key.strip():
            issues.append("Empty top-level keys are not allowed")
        if isinstance(value, bytes):
            issues.append(f"Top-level key '{key}' has unsupported binary value")
    return issues


@dataclass
class CommandResult:
    returncode: int | None
    stdout: str
    stderr: str
    duration_ms: int
    timed_out: bool = False


@dataclass
class CommandOptions:
    cwd: Path
    timeout_seconds: int = 30
    shell: bool = False
    env: dict[str, str] | None = None


def _coerce_command(
    command: str | list[str] | tuple[str, ...],
    shell: bool,  # noqa: ARG001 — shell mode is permanently disabled (CWE-78 prevention)
) -> tuple[list[str], bool]:
    # Security: shell=True (create_subprocess_shell) is permanently disabled to prevent
    # OS command injection (CWE-78). All commands run via create_subprocess_exec only.
    if isinstance(command, str):
        if not command.strip():
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="command cannot be empty",
            )
        try:
            parts = shlex.split(command)
        except ValueError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Invalid command string",
            ) from exc
        return parts, False

    if not command:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="command cannot be empty",
        )
    parts = [str(part) for part in command if str(part).strip()]
    if not parts:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="command cannot be empty",
        )
    return parts, False


def _coerce_command_env(overrides: dict[str, str] | None) -> dict[str, str]:
    # Security: never copy os.environ directly — it contains AWS credentials and secrets.
    # Build a clean environment from a strict allowlist only.
    env: dict[str, str] = {k: v for k, v in os.environ.items() if k in _SUBPROCESS_SAFE_ENV_KEYS}
    # Ensure a safe, controlled PATH — never inherit from environment.
    env["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
    for name, value in (overrides or {}).items():
        key = str(name).strip()
        if not key or key not in WORKSPACE_TERMINAL_ALLOWED_ENV_KEYS:
            continue
        env[key] = str(value)
    return env


async def run_local_command(command: str | list[str] | tuple[str, ...], options: CommandOptions) -> CommandResult:
    """Execute a local command and capture bounded output."""
    cmd, _use_shell = _coerce_command(command, options.shell)
    command_for_log = " ".join(cmd)
    start = datetime.now(UTC).replace(tzinfo=None)

    if not options.cwd.exists():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Working directory not found: {options.cwd}",
        )

    env = _coerce_command_env(options.env)

    process = None
    try:
        # Security: always use create_subprocess_exec (never create_subprocess_shell).
        # Shell execution is permanently disabled to prevent command injection (CWE-78).
        process = await asyncio.create_subprocess_exec(
            *cmd,
            cwd=str(options.cwd),
            env=env,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )

        stdout_raw, stderr_raw = await asyncio.wait_for(
            process.communicate(),
            timeout=max(1, options.timeout_seconds),
        )
        elapsed_ms = int((datetime.now(UTC).replace(tzinfo=None) - start).total_seconds() * 1000)
        stdout = (stdout_raw or b"").decode("utf-8", errors="replace")
        stderr = (stderr_raw or b"").decode("utf-8", errors="replace")
        if len(stdout) > TERMINAL_OUTPUT_LIMIT_BYTES:
            stdout = stdout[:TERMINAL_OUTPUT_LIMIT_BYTES]
        if len(stderr) > TERMINAL_OUTPUT_LIMIT_BYTES:
            stderr = stderr[:TERMINAL_OUTPUT_LIMIT_BYTES]
        return CommandResult(
            returncode=process.returncode,
            stdout=stdout,
            stderr=stderr,
            duration_ms=elapsed_ms,
            timed_out=False,
        )
    except TimeoutError:
        if process is not None:
            process.kill()
            await process.wait()
        elapsed_ms = int((datetime.now(UTC).replace(tzinfo=None) - start).total_seconds() * 1000)
        logger.warning("Command timeout for: %s in %s", command_for_log, options.cwd)
        return CommandResult(
            returncode=None,
            stdout="",
            stderr="Command timed out",
            duration_ms=elapsed_ms,
            timed_out=True,
        )
    except Exception as exc:  # pragma: no cover
        logger.exception("Command execution failed for %s", command_for_log)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to execute command",
        ) from exc
