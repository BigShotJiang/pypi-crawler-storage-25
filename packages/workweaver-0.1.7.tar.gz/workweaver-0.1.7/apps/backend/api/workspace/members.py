"""Canonical Workspace Member Management API.

Provides REST API for managing workspace membership using canonical
terminology (workspace, owner, member) per PRODUCT-CONTEXT.md section 4.

Routes:
  GET    /api/v1/workspaces/{workspace_id}/members           -- list members
  POST   /api/v1/workspaces/{workspace_id}/members/invite    -- invite a member
  GET    /api/v1/workspaces/{workspace_id}/members/invitations -- list invitations
  POST   /api/v1/workspaces/{workspace_id}/members/invitations/{invitation_id}/accept -- accept
  DELETE /api/v1/workspaces/{workspace_id}/members/invitations/{invitation_id} -- cancel
  PATCH  /api/v1/workspaces/{workspace_id}/members/{member_id}/role -- update role
  DELETE /api/v1/workspaces/{workspace_id}/members/{member_id}      -- offboard

Legacy route: /api/v1/tenant/users (retained with deprecation header).
"""

from __future__ import annotations

from datetime import datetime
from typing import Any, NoReturn

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, EmailStr, Field

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_email,
    get_verified_user_id,
    get_verified_user_role,
)
from apps.backend.models.user import UserRole, UserStatus
from apps.backend.schemas.error_response import ErrorResponse
from apps.backend.services.user_management import (
    InsufficientPrivilegesError,
    InvitationExpiredError,
    LastAdminError,
    UserManagementService,
    UserNotFoundError,
)

router = APIRouter(prefix="/api/v1/workspaces", tags=["workspace-members"])

DEPRECATION_HEADER = "X-Deprecated-Api"
DEPRECATION_MESSAGE = "Use /api/v1/workspaces/{workspace_id}/members instead of /api/v1/tenant/users"


# ---------------------------------------------------------------------------
# Request / Response models (canonical terminology)
# ---------------------------------------------------------------------------


class InviteMemberRequest(BaseModel):
    """Request body for inviting a member to a workspace."""

    member_email: EmailStr = Field(..., description="Email of the member to invite")
    role: UserRole = Field(..., description="Role to assign (admin, manager, agent)")


class MemberInvitationResponse(BaseModel):
    """Response model for a workspace member invitation."""

    invitation_id: str
    workspace_id: str = Field(..., description="Workspace the invitation belongs to")
    member_email: str = Field(..., description="Invited member email")
    role: UserRole
    inviter_email: str
    status: str
    created_at: datetime
    expires_at: datetime
    accepted_at: datetime | None = None


class UpdateMemberRoleRequest(BaseModel):
    """Request body for updating a member's role."""

    role: UserRole = Field(..., description="New role to assign")


class MemberResponse(BaseModel):
    """Response model for a workspace member."""

    member_id: str = Field(..., description="Unique member identifier")
    email: str
    role: UserRole
    status: UserStatus
    created_at: datetime
    updated_at: datetime | None = None
    last_login: datetime | None = None


class MemberListResponse(BaseModel):
    """Response model for workspace member list."""

    members: list[dict[str, Any]] = Field(..., description="List of workspace members")
    total: int


# ---------------------------------------------------------------------------
# Dependencies
# ---------------------------------------------------------------------------


def get_user_management_service() -> UserManagementService:
    """Dependency to get user management service."""
    return UserManagementService()


def _send_invitation_email(invitation_id: str) -> None:
    from apps.backend.services.invitation_service import get_invitation_service

    get_invitation_service().send_invitation_email(invitation_id)


def _service_unavailable(action: str, exc: Exception) -> NoReturn:
    """Raise a typed degraded response when user-management storage fails."""
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail={
            "error": "workspace_member_management_unavailable",
            "detail": f"Workspace member management unavailable while trying to {action}",
        },
    ) from exc


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get(
    "/{workspace_id}/members",
    response_model=MemberListResponse,
    responses={
        403: {"model": ErrorResponse, "description": "Insufficient privileges"},
    },
)
async def list_members(
    workspace_id: str,
    role_filter: UserRole | None = None,
    status_filter: UserStatus | None = None,
    limit: int = Query(100, ge=1, le=500, description="Max results"),
    service: UserManagementService = Depends(get_user_management_service),
    tenant_id: str = Depends(get_verified_tenant_id),
    requester_role: UserRole = Depends(get_verified_user_role),
) -> dict[str, Any]:
    """List members of a workspace.

    Only workspace owners and admins can enumerate the member roster.
    """
    if not service.can_invite_users(requester_role):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "InsufficientPrivilegesError",
                "detail": "Only admins can list workspace members",
            },
        )
    try:
        result = service.list_users(
            tenant_id=tenant_id,
            role_filter=role_filter,
            status_filter=status_filter,
            limit=limit,
        )
        # Remap to canonical terminology
        result["members"] = result.pop("users", result.get("members", []))
        return result
    except Exception as exc:
        _service_unavailable("list members", exc)


@router.post(
    "/{workspace_id}/members/invite",
    response_model=MemberInvitationResponse,
    status_code=status.HTTP_201_CREATED,
    responses={
        403: {"model": ErrorResponse, "description": "Insufficient privileges"},
    },
)
async def invite_member(
    workspace_id: str,
    request: InviteMemberRequest,
    service: UserManagementService = Depends(get_user_management_service),
    requester_role: UserRole = Depends(get_verified_user_role),
    tenant_id: str = Depends(get_verified_tenant_id),
    inviter_email: str = Depends(get_verified_user_email),
) -> Any:
    """Invite a new member to the workspace.

    Only admins can create invitations. Role is verified from the
    authoritative user record in DynamoDB, not from client-supplied headers.
    """
    if not service.can_invite_users(requester_role):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "InsufficientPrivilegesError",
                "detail": "Only admins can invite workspace members",
            },
        )

    try:
        invitation = service.create_invitation(
            tenant_id=tenant_id,
            inviter_email=inviter_email,
            invitee_email=request.member_email,
            role=request.role,
        )
    except Exception as exc:
        _service_unavailable("create an invitation", exc)

    # Send acceptance email
    try:
        invitation_id = (
            getattr(invitation, "invitation_id", None)
            or (invitation.get("invitation_id") if isinstance(invitation, dict) else None)
        )
        if invitation_id:
            _send_invitation_email(str(invitation_id))
    except Exception as exc:  # pragma: no cover -- email failure non-fatal
        import logging

        logging.getLogger(__name__).warning(
            "invite_member email-send failed: %s", exc, exc_info=True
        )

    # Remap to canonical terminology
    if isinstance(invitation, dict):
        invitation["workspace_id"] = invitation.pop("tenant_id", tenant_id)
        invitation["member_email"] = invitation.pop("invitee_email", request.member_email)
    return invitation


@router.get(
    "/{workspace_id}/members/invitations",
    response_model=list[MemberInvitationResponse],
    responses={
        403: {"model": ErrorResponse, "description": "Insufficient privileges"},
    },
)
async def list_invitations(
    workspace_id: str,
    invitation_status: str | None = Query(None, alias="status", description="Filter by status"),
    limit: int = Query(100, ge=1, le=500, description="Max invitations to return"),
    service: UserManagementService = Depends(get_user_management_service),
    tenant_id: str = Depends(get_verified_tenant_id),
    requester_role: UserRole = Depends(get_verified_user_role),
) -> list[Any]:
    """List pending invitations for the workspace.

    Admin-only -- invitation rosters are sensitive PII.
    """
    if not service.can_invite_users(requester_role):
        raise HTTPException(
            status_code=403,
            detail={
                "error": "InsufficientPrivilegesError",
                "detail": "Only admins can list workspace invitations",
            },
        )
    try:
        return service.list_invitations(tenant_id, status=invitation_status)[:limit]
    except Exception as exc:
        _service_unavailable("list invitations", exc)


@router.post(
    "/{workspace_id}/members/invitations/{invitation_id}/accept",
    response_model=MemberInvitationResponse,
    responses={
        404: {"model": ErrorResponse, "description": "Invitation not found"},
        400: {"model": ErrorResponse, "description": "Invitation expired"},
    },
)
async def accept_invitation(
    workspace_id: str,
    invitation_id: str,
    service: UserManagementService = Depends(get_user_management_service),
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> Any:
    """Accept a workspace invitation.

    Requires verified auth. The invitation must belong to the caller's workspace.
    """
    try:
        invitation = service.get_invitation(invitation_id)
        inv_tenant = str(getattr(invitation, "tenant_id", "") or "").strip()
        if inv_tenant and inv_tenant != tenant_id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={"error": "UserNotFoundError", "detail": "Invitation not found"},
            )
        return service.accept_invitation(invitation_id)
    except UserNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "UserNotFoundError", "detail": str(e)},
        )
    except InvitationExpiredError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "InvitationExpiredError", "detail": str(e)},
        )
    except Exception as exc:
        _service_unavailable("accept an invitation", exc)


@router.delete(
    "/{workspace_id}/members/invitations/{invitation_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    responses={
        404: {"model": ErrorResponse, "description": "Invitation not found"},
        403: {"model": ErrorResponse, "description": "Insufficient privileges"},
    },
)
async def cancel_invitation(
    workspace_id: str,
    invitation_id: str,
    service: UserManagementService = Depends(get_user_management_service),
    tenant_id: str = Depends(get_verified_tenant_id),
    requester_role: UserRole = Depends(get_verified_user_role),
) -> None:
    """Cancel a workspace invitation.

    Only admins can cancel invitations for their workspace.
    """
    if not service.can_invite_users(requester_role):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "InsufficientPrivilegesError",
                "detail": "Only admins can cancel invitations",
            },
        )
    try:
        invitation = service.get_invitation(invitation_id)
        inv_tenant = str(getattr(invitation, "tenant_id", "") or "").strip()
        if inv_tenant and inv_tenant != tenant_id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={"error": "UserNotFoundError", "detail": "Invitation not found"},
            )
        service.cancel_invitation(invitation_id)
    except UserNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "UserNotFoundError", "detail": str(e)},
        )
    except Exception as exc:
        _service_unavailable("cancel an invitation", exc)


@router.patch(
    "/{workspace_id}/members/{member_id}/role",
    response_model=MemberResponse,
    responses={
        403: {"model": ErrorResponse, "description": "Insufficient privileges"},
        404: {"model": ErrorResponse, "description": "Member not found"},
    },
)
async def update_member_role(
    workspace_id: str,
    member_id: str,
    request: UpdateMemberRoleRequest,
    service: UserManagementService = Depends(get_user_management_service),
    requester_role: UserRole = Depends(get_verified_user_role),
    requester_id: str = Depends(get_verified_user_id),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Update a workspace member's role. Only admins can update roles."""
    try:
        result = service.update_user_role(
            tenant_id=tenant_id,
            user_id=member_id,
            new_role=request.role,
            requester_role=requester_role,
            requester_id=requester_id,
        )
        # Remap to canonical terminology
        result["member_id"] = result.pop("user_id", member_id)
        return result
    except UserNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "UserNotFoundError", "detail": str(e)},
        )
    except InsufficientPrivilegesError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": "InsufficientPrivilegesError", "detail": str(e)},
        )
    except Exception as exc:
        _service_unavailable("update member role", exc)


@router.delete(
    "/{workspace_id}/members/{member_id}",
    response_model=MemberResponse,
    responses={
        403: {"model": ErrorResponse, "description": "Insufficient privileges"},
        404: {"model": ErrorResponse, "description": "Member not found"},
        400: {"model": ErrorResponse, "description": "Cannot offboard last admin"},
    },
)
async def offboard_member(
    workspace_id: str,
    member_id: str,
    service: UserManagementService = Depends(get_user_management_service),
    requester_role: UserRole = Depends(get_verified_user_role),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Offboard a workspace member (soft delete). Only admins can offboard."""
    try:
        result = service.offboard_user(
            tenant_id=tenant_id,
            user_id=member_id,
            requester_role=requester_role,
        )
        # Remap to canonical terminology
        result["member_id"] = result.pop("user_id", member_id)
        return result
    except UserNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "UserNotFoundError", "detail": str(e)},
        )
    except InsufficientPrivilegesError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": "InsufficientPrivilegesError", "detail": str(e)},
        )
    except LastAdminError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "LastAdminError", "detail": str(e)},
        )
    except Exception as exc:
        _service_unavailable("offboard member", exc)


# ---------------------------------------------------------------------------
# External Identity Binding endpoints (issue #3587)
# ---------------------------------------------------------------------------

from apps.backend.services.identity_binding_service import (
    BindingNotFoundError,
    DuplicateBindingError,
    IdentityBindingService,
    ProviderNotSupportedError,
)


class BindExternalIdentityRequest(BaseModel):
    """Request body for binding an external identity to a member."""

    provider: str = Field(..., description="External provider (jira, linear, asana, trello)")
    external_user_id: str = Field(..., description="User ID in the external system")
    external_email: str | None = Field(None, description="Optional email from external system")
    external_name: str | None = Field(None, description="Optional display name from external system")


class ExternalIdentityBindingResponse(BaseModel):
    """Response model for an external identity binding."""

    binding_id: str
    tenant_id: str
    workspace_id: str
    member_id: str
    provider: str
    external_user_id: str
    external_email: str | None = None
    external_name: str | None = None
    created_at: datetime
    created_by: str


class ExternalIdentityBindingListResponse(BaseModel):
    """Response model for listing external identity bindings."""

    bindings: list[ExternalIdentityBindingResponse]
    total: int


def get_identity_binding_service() -> IdentityBindingService:
    """Dependency to get the identity binding service."""
    return IdentityBindingService()


@router.post(
    "/{workspace_id}/members/{member_id}/external-identity",
    response_model=ExternalIdentityBindingResponse,
    status_code=status.HTTP_201_CREATED,
    responses={
        400: {"model": ErrorResponse, "description": "Invalid provider or duplicate binding"},
        403: {"model": ErrorResponse, "description": "Insufficient privileges"},
    },
)
async def bind_external_identity(
    workspace_id: str,
    member_id: str,
    request: BindExternalIdentityRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    requester_role: UserRole = Depends(get_verified_user_role),
    service: IdentityBindingService = Depends(get_identity_binding_service),
) -> Any:
    """Bind an external PM-tool user to a Workweaver Member.

    Admin-only: only workspace admins can create identity bindings.
    """
    if not service_can_invite(requester_role):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "InsufficientPrivilegesError",
                "detail": "Only admins can bind external identities",
            },
        )
    try:
        binding = service.bind_external_identity(
            tenant_id=tenant_id,
            workspace_id=workspace_id,
            member_id=member_id,
            provider=request.provider,
            external_user_id=request.external_user_id,
            external_email=request.external_email,
            external_name=request.external_name,
            created_by=str(tenant_id),
        )
    except ProviderNotSupportedError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "ProviderNotSupportedError", "detail": str(e)},
        )
    except DuplicateBindingError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "DuplicateBindingError", "detail": str(e)},
        )
    except Exception as exc:
        _service_unavailable("bind external identity", exc)

    return {
        "binding_id": binding.binding_id,
        "tenant_id": binding.tenant_id,
        "workspace_id": binding.workspace_id,
        "member_id": binding.member_id,
        "provider": binding.provider,
        "external_user_id": binding.external_user_id,
        "external_email": binding.external_email,
        "external_name": binding.external_name,
        "created_at": binding.created_at,
        "created_by": binding.created_by,
    }


def service_can_invite(role: UserRole) -> bool:
    """Check if the user role can manage members.

    Admins and managers can manage identity bindings.
    """
    return role in (UserRole.ADMIN, UserRole.MANAGER)


@router.get(
    "/{workspace_id}/members/{member_id}/external-identity",
    response_model=ExternalIdentityBindingListResponse,
    responses={
        403: {"model": ErrorResponse, "description": "Insufficient privileges"},
    },
)
async def list_external_identities(
    workspace_id: str,
    member_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    requester_role: UserRole = Depends(get_verified_user_role),
    service: IdentityBindingService = Depends(get_identity_binding_service),
) -> dict[str, Any]:
    """List external identity bindings for a member.

    Admin-only: only workspace admins can list identity bindings.
    """
    if not service_can_invite(requester_role):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "InsufficientPrivilegesError",
                "detail": "Only admins can list external identities",
            },
        )
    try:
        bindings = service.list_bindings_for_member(
            tenant_id=tenant_id,
            member_id=member_id,
        )
        return {
            "bindings": [
                {
                    "binding_id": b.binding_id,
                    "tenant_id": b.tenant_id,
                    "workspace_id": b.workspace_id,
                    "member_id": b.member_id,
                    "provider": b.provider,
                    "external_user_id": b.external_user_id,
                    "external_email": b.external_email,
                    "external_name": b.external_name,
                    "created_at": b.created_at,
                    "created_by": b.created_by,
                }
                for b in bindings
            ],
            "total": len(bindings),
        }
    except Exception as exc:
        _service_unavailable("list external identities", exc)


@router.delete(
    "/{workspace_id}/members/{member_id}/external-identity/{binding_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    responses={
        403: {"model": ErrorResponse, "description": "Insufficient privileges"},
        404: {"model": ErrorResponse, "description": "Binding not found"},
    },
)
async def delete_external_identity(
    workspace_id: str,
    member_id: str,
    binding_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    requester_role: UserRole = Depends(get_verified_user_role),
    service: IdentityBindingService = Depends(get_identity_binding_service),
) -> None:
    """Delete an external identity binding.

    Admin-only: only workspace admins can remove identity bindings.
    """
    if not service_can_invite(requester_role):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "InsufficientPrivilegesError",
                "detail": "Only admins can delete external identities",
            },
        )
    try:
        service.delete_binding(
            tenant_id=tenant_id,
            binding_id=binding_id,
        )
    except BindingNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "BindingNotFoundError", "detail": str(e)},
        )
    except Exception as exc:
        _service_unavailable("delete external identity", exc)
