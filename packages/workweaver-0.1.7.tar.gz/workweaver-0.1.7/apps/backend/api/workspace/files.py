"""Workspace file browser and file edit APIs."""

from __future__ import annotations

import asyncio
import base64
import shutil
from datetime import datetime
from pathlib import Path

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field

from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.api.workspace._core import (
    get_tenant_id,
    get_workspace_root,
    resolve_workspace_path,
)


router = APIRouter(prefix="/api/v1/workspace/files", tags=["workspace", "files"])

MAX_FILE_BYTES = 2 * 1024 * 1024


class WorkspaceEntry(BaseModel):
    path: str
    name: str
    is_directory: bool
    size: int | None = None
    mime_hint: str
    updated_at: str


class FileBrowseResponse(BaseModel):
    tenant_id: str
    workspace_root: str
    path: str
    total: int
    entries: list[WorkspaceEntry]


class FileContentResponse(BaseModel):
    tenant_id: str
    path: str
    content: str
    encoding: str
    size: int


class FileWriteRequest(BaseModel):
    path: str = Field(..., description="Target file path")
    content: str = Field(default="", description="File contents")
    overwrite: bool = False
    create_directories: bool = False


class FileWriteResponse(BaseModel):
    tenant_id: str
    path: str
    size: int
    created: bool
    overwritten: bool


class FileCreateRequest(BaseModel):
    path: str
    is_directory: bool = False
    content: str = ""
    create_directories: bool = True


class FileDeleteResponse(BaseModel):
    tenant_id: str
    deleted: bool
    path: str


class FileMoveRequest(BaseModel):
    source: str
    destination: str
    overwrite: bool = False
    create_directories: bool = True


class FileMoveResponse(BaseModel):
    tenant_id: str
    source: str
    destination: str
    overwritten: bool


class FileCreateResponse(BaseModel):
    tenant_id: str
    path: str
    is_directory: bool
    created: bool
    size: int | None = None


def _safe_name(path: str) -> str:
    if not path or not path.strip():
        raise HTTPException(status_code=400, detail="path is required")
    return path.strip()


def _relative_to_root(root: Path, target: Path) -> str:
    if target == root:
        return "."
    return target.relative_to(root).as_posix()


def _entry(base: Path, path: Path) -> WorkspaceEntry:
    stat = path.stat()
    return WorkspaceEntry(
        path=_relative_to_root(base, path),
        name=path.name,
        is_directory=path.is_dir(),
        size=None if path.is_dir() else stat.st_size,
        mime_hint="directory" if path.is_dir() else "file",
        updated_at=datetime.fromtimestamp(stat.st_mtime).isoformat() + "Z",
    )


def _should_hide_entry(base: Path, target: Path, include_hidden: bool) -> bool:
    if include_hidden:
        return False
    rel = target.relative_to(base).parts
    return any(part.startswith(".") for part in rel)


@router.get("", response_model=FileBrowseResponse)
async def list_workspace_files(
    request: Request,
    path: str = ".",
    include_hidden: bool = False,
    recursive: bool = False,
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=100, max_limit=500)),
) -> FileBrowseResponse:
    tenant_id = get_tenant_id(request)
    workspace_root = get_workspace_root(tenant_id)
    target = resolve_workspace_path(workspace_root, _safe_name(path))

    if not target.exists():
        raise HTTPException(status_code=404, detail="Path not found")

    if target.is_file():
        return FileBrowseResponse(
            tenant_id=tenant_id,
            workspace_root=str(workspace_root),
            path=_relative_to_root(workspace_root, target),
            total=1,
            entries=[_entry(workspace_root, target)],
        )

    entries: list[WorkspaceEntry] = []
    workspace_root_str = str(workspace_root)
    if recursive:
        for item in target.rglob("*"):
            # Security: reject symlinks that escape the workspace root (CWE-59).
            if item.is_symlink() and not str(item.resolve()).startswith(workspace_root_str):
                continue
            if _should_hide_entry(workspace_root, item, include_hidden):
                continue
            try:
                entries.append(_entry(workspace_root, item))
            except OSError:
                continue
    else:
        for item in target.iterdir():
            # Security: reject symlinks that escape the workspace root (CWE-59).
            if item.is_symlink() and not str(item.resolve()).startswith(workspace_root_str):
                continue
            if _should_hide_entry(workspace_root, item, include_hidden):
                continue
            try:
                entries.append(_entry(workspace_root, item))
            except OSError:
                continue

    entries.sort(key=lambda item: (not item.is_directory, item.name.lower()))
    paged_entries, total = paginate_items(entries, pagination)
    return FileBrowseResponse(
        tenant_id=tenant_id,
        workspace_root=str(workspace_root),
        path=_relative_to_root(workspace_root, target),
        total=total,
        entries=paged_entries,
    )


@router.get("/content", response_model=FileContentResponse)
async def get_file_content(
    request: Request,
    path: str,
    max_size: int = Query(default=MAX_FILE_BYTES, ge=1, le=MAX_FILE_BYTES * 4),
) -> FileContentResponse:
    tenant_id = get_tenant_id(request)
    workspace_root = get_workspace_root(tenant_id)
    target = resolve_workspace_path(workspace_root, _safe_name(path))

    if not target.exists() or target.is_dir():
        raise HTTPException(status_code=404, detail="File not found")

    size = target.stat().st_size
    if size > max_size:
        raise HTTPException(status_code=413, detail="File exceeds requested max_size")

    # M8: Run blocking I/O in thread pool with timeout to prevent event-loop stall
    # on large/slow files (e.g. sparse files, NFS mounts).
    try:
        raw = await asyncio.wait_for(
            asyncio.to_thread(target.read_bytes),
            timeout=10.0,
        )
    except TimeoutError:
        raise HTTPException(status_code=504, detail="File read timed out")
    try:
        content = raw.decode("utf-8")
        encoding = "utf-8"
    except UnicodeDecodeError:
        content = base64.b64encode(raw).decode("ascii")
        encoding = "base64"

    return FileContentResponse(
        tenant_id=tenant_id,
        path=_relative_to_root(workspace_root, target),
        content=content,
        encoding=encoding,
        size=size,
    )


@router.put("/content", response_model=FileWriteResponse)
async def write_file_content(
    request: Request,
    body: FileWriteRequest,
) -> FileWriteResponse:
    tenant_id = get_tenant_id(request)
    workspace_root = get_workspace_root(tenant_id)
    target = resolve_workspace_path(workspace_root, _safe_name(body.path))

    if target.exists() and target.is_dir():
        raise HTTPException(status_code=400, detail="Target is a directory")
    if target.exists() and not body.overwrite:
        raise HTTPException(status_code=409, detail="File already exists")

    encoded = body.content.encode("utf-8")
    if len(encoded) > MAX_FILE_BYTES:
        raise HTTPException(
            status_code=413,
            detail="Content exceeds workspace write limit",
        )

    if not target.parent.exists():
        if body.create_directories:
            target.parent.mkdir(parents=True, exist_ok=True)
        else:
            raise HTTPException(status_code=404, detail="Destination directory not found")

    created = not target.exists()
    target.write_text(body.content, encoding="utf-8")
    return FileWriteResponse(
        tenant_id=tenant_id,
        path=_relative_to_root(workspace_root, target),
        size=target.stat().st_size,
        created=created,
        overwritten=not created,
    )


@router.post("", response_model=FileCreateResponse)
async def create_file_or_dir(
    request: Request,
    body: FileCreateRequest,
) -> FileCreateResponse:
    tenant_id = get_tenant_id(request)
    workspace_root = get_workspace_root(tenant_id)
    target = resolve_workspace_path(workspace_root, _safe_name(body.path))

    if target.exists():
        raise HTTPException(status_code=409, detail="Path already exists")

    if not target.parent.exists():
        if body.create_directories:
            target.parent.mkdir(parents=True, exist_ok=True)
        else:
            raise HTTPException(status_code=404, detail="Destination directory not found")

    if body.is_directory:
        target.mkdir(parents=True, exist_ok=True)
        size = None
    else:
        target.write_text(body.content, encoding="utf-8")
        size = target.stat().st_size

    return FileCreateResponse(
        tenant_id=tenant_id,
        path=_relative_to_root(workspace_root, target),
        is_directory=body.is_directory,
        created=True,
        size=size,
    )


@router.delete("", response_model=FileDeleteResponse)
async def delete_file_or_dir(
    request: Request,
    path: str,
    recursive: bool = False,
) -> FileDeleteResponse:
    tenant_id = get_tenant_id(request)
    workspace_root = get_workspace_root(tenant_id)
    target = resolve_workspace_path(workspace_root, _safe_name(path))

    if not target.exists():
        raise HTTPException(status_code=404, detail="Path not found")

    if target.is_dir():
        if any(target.iterdir()) and not recursive:
            raise HTTPException(status_code=409, detail="Directory is not empty")
        if recursive:
            shutil.rmtree(target)
        else:
            target.rmdir()
    else:
        target.unlink()

    return FileDeleteResponse(
        tenant_id=tenant_id,
        deleted=True,
        path=_relative_to_root(workspace_root, target),
    )


@router.post("/move", response_model=FileMoveResponse)
async def move_file_or_dir(
    request: Request,
    body: FileMoveRequest,
) -> FileMoveResponse:
    tenant_id = get_tenant_id(request)
    workspace_root = get_workspace_root(tenant_id)
    source = resolve_workspace_path(workspace_root, _safe_name(body.source))
    destination = resolve_workspace_path(workspace_root, _safe_name(body.destination))

    if not source.exists():
        raise HTTPException(status_code=404, detail="Source not found")
    if source == destination:
        return FileMoveResponse(
            tenant_id=tenant_id,
            source=_relative_to_root(workspace_root, source),
            destination=_relative_to_root(workspace_root, destination),
            overwritten=False,
        )
    if destination.exists() and not body.overwrite:
        raise HTTPException(status_code=409, detail="Destination exists")
    if destination.exists() and destination.is_relative_to(source):
        raise HTTPException(status_code=400, detail="Destination cannot be inside source")

    if not destination.parent.exists():
        if body.create_directories:
            destination.parent.mkdir(parents=True, exist_ok=True)
        else:
            raise HTTPException(status_code=404, detail="Destination directory not found")

    overwritten = destination.exists()
    if overwritten:
        if destination.is_dir():
            shutil.rmtree(destination)
        else:
            destination.unlink()

    source.replace(destination)
    return FileMoveResponse(
        tenant_id=tenant_id,
        source=_relative_to_root(workspace_root, source),
        destination=_relative_to_root(workspace_root, destination),
        overwritten=overwritten,
    )
