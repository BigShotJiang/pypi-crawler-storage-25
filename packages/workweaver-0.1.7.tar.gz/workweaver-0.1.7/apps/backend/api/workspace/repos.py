"""Repository integration endpoints for workspace API."""

from __future__ import annotations

import asyncio
import os
import logging
from collections import defaultdict, deque
from dataclasses import dataclass
from datetime import datetime, UTC
from pathlib import Path
import time
from typing import Literal
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, Field

from apps.backend.api.pagination import PaginationParams, build_pagination_dependency
from apps.backend.api.workspace._core import (
    CommandOptions,
    CommandResult,
    TERMINAL_OUTPUT_LIMIT_BYTES,
    _coerce_command_env,
    get_tenant_id,
    get_workspace_root,
    resolve_workspace_path,
    run_local_command,
)
from apps.backend.services.workspace_repo_job_store import get_workspace_repo_job_store


logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/workspace/repos", tags=["workspace", "repos"])

MAX_REPO_DISCOVERY_DEPTH = 4
MAX_REPO_DISCOVERY_DEPTH_CAP = 10
DEFAULT_REPO_DISCOVERY_PAGE_SIZE = 25
MAX_REPO_DISCOVERY_PAGE_SIZE = 100
REPO_DISCOVERY_QUERY_RATE_LIMIT = 30
REPO_DISCOVERY_QUERY_RATE_WINDOW_SECONDS = 60
REPO_DISCOVERY_WARNING_LIMIT = 25
DEFAULT_REPO_JOB_TIMEOUT_SECONDS = 300
MAX_REPO_JOB_TIMEOUT_SECONDS = 1800

REPO_JOB_TERMINAL_STATUSES = frozenset(
    {"completed", "failed", "timed_out", "cancelled", "interrupted"}
)

_REPO_DISCOVERY_QUERY_WINDOW: dict[str, deque[float]] = defaultdict(deque)
_REPO_DISCOVERY_QUERY_RATE_LOCK = asyncio.Lock()
_ACTIVE_REPO_JOBS: dict[tuple[str, str], ActiveRepoJob] = {}
_ACTIVE_REPO_JOBS_LOCK = asyncio.Lock()
_SKIP_DISCOVERY_DIRS = frozenset(
    {
        ".git",
        ".hg",
        ".svn",
        ".venv",
        "node_modules",
        "__pycache__",
        ".pytest_cache",
        ".cache",
        ".turbo",
        ".next",
        "dist",
        "build",
        ".terraform",
    }
)


class RepoDiscoveryItem(BaseModel):
    path: str
    branch: str | None
    clean: bool
    uncommitted_count: int
    last_commit: str | None


class RepoListResponse(BaseModel):
    tenant_id: str
    total: int
    repos: list[RepoDiscoveryItem]
    page: int
    page_size: int
    has_more: bool
    skipped: int
    warnings: list[str]


class RepoCloneRequest(BaseModel):
    remote_url: str
    path: str | None = None
    branch: str | None = None
    depth: int = Field(default=1, ge=1, le=50)


class RepoCloneResponse(BaseModel):
    tenant_id: str
    path: str
    remote_url: str
    branch: str | None
    created: bool


class RepoStatusResponse(BaseModel):
    tenant_id: str
    path: str
    branch: str
    clean: bool
    uncommitted_files: int
    last_commit: str | None
    remotes: list[str]
    ahead: int | None = None
    behind: int | None = None


class RepoPullRequest(BaseModel):
    path: str
    remote: str = "origin"
    rebase: bool = False


class RepoPullResponse(BaseModel):
    tenant_id: str
    path: str
    remote: str
    rebase: bool
    output: str


class RepoBranchRequest(BaseModel):
    path: str
    action: Literal["list", "current", "create", "switch", "delete"]
    branch: str | None = None
    page: int = 1
    page_size: int = Field(default=50, ge=1, le=200)


class RepoBranchResponse(BaseModel):
    tenant_id: str
    path: str
    action: str
    branch: str | None = None
    branches: list[str] | None = None
    total: int | None = None
    page: int | None = None
    page_size: int | None = None
    has_more: bool | None = None


class RepoJobStatusResponse(BaseModel):
    tenant_id: str
    job_id: str
    operation: str
    status: str
    path: str
    created_at: str
    command: list[str]
    timeout_seconds: int
    started_at: str | None = None
    finished_at: str | None = None
    exit_code: int | None = None
    timed_out: bool = False
    cancel_requested: bool = False
    stdout: str = ""
    stderr: str = ""


class RepoJobListResponse(BaseModel):
    tenant_id: str
    jobs: list[RepoJobStatusResponse]
    count: int


class RepoJobAcceptedResponse(BaseModel):
    tenant_id: str
    job_id: str
    operation: str
    status: str
    path: str
    created_at: str


@dataclass
class ActiveRepoJob:
    task: asyncio.Task[None] | None = None
    process: asyncio.subprocess.Process | None = None


def _safe_path(path: str | None) -> str:
    if not path or not path.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="path is required",
        )
    return path.strip()


def _relative_repo_path(workspace_root: Path, repo_root: Path) -> str:
    return repo_root.relative_to(workspace_root).as_posix()


def _ensure_git_repo(repo_root: Path) -> None:
    git_dir = repo_root / ".git"
    if not git_dir.exists() or not git_dir.is_dir():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Path is not a git repository",
        )


def _safe_int_env(name: str, default: int, minimum: int = 1, maximum: int | None = None) -> int:
    raw = str(os.getenv(name, "")).strip()
    if not raw:
        return default

    try:
        value = int(raw)
    except ValueError:
        logger.warning("Ignoring invalid int env var %s=%r; using %s", name, raw, default)
        return default

    if value < minimum:
        return minimum
    if maximum is not None and value > maximum:
        return maximum
    return value


def _get_discovery_rate_limits() -> tuple[int, int]:
    limit = _safe_int_env("WORKSPACE_REPO_DISCOVERY_QUERY_RATE_LIMIT", REPO_DISCOVERY_QUERY_RATE_LIMIT, minimum=1)
    window = _safe_int_env(
        "WORKSPACE_REPO_DISCOVERY_QUERY_RATE_WINDOW_SECONDS",
        REPO_DISCOVERY_QUERY_RATE_WINDOW_SECONDS,
        minimum=1,
    )
    return limit, window


async def _enforce_discovery_rate_limit(request: Request) -> None:
    tenant_id = get_tenant_id(request)
    client_host = (request.client.host if request.client else "unknown").strip() or "unknown"
    key = f"{tenant_id}:{client_host}"
    limit, window = _get_discovery_rate_limits()
    now = time.monotonic()

    async with _REPO_DISCOVERY_QUERY_RATE_LOCK:
        timestamps = _REPO_DISCOVERY_QUERY_WINDOW[key]
        while timestamps and now - timestamps[0] > window:
            timestamps.popleft()

        if len(timestamps) >= limit:
            retry_after = max(1, int(window - (now - timestamps[0])))
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail="Repository discovery query rate limit exceeded",
                headers={"Retry-After": str(retry_after)},
            )

        timestamps.append(now)


def _iter_repo_roots(workspace_root: Path, max_depth: int):
    queue: deque[tuple[Path, int]] = deque([(workspace_root, 0)])
    while queue:
        current_root, depth = queue.popleft()
        try:
            children = [entry for entry in current_root.iterdir() if entry.is_dir(follow_symlinks=False)]
        except OSError as exc:
            logger.warning("Skipping unreadable directory during repo discovery %s: %s", current_root, exc)
            continue

        for child in sorted(children, key=lambda item: item.name):
            if child.name == ".git":
                yield child.parent
                continue

            if child.name in _SKIP_DISCOVERY_DIRS:
                continue

            if depth < max_depth:
                queue.append((child, depth + 1))


async def _run_repo_command(repo_root: Path, command: list[str], timeout: int = 30) -> CommandResult:
    result = await run_local_command(
        command,
        CommandOptions(cwd=repo_root, timeout_seconds=timeout, shell=False),
    )
    if result.timed_out:
        raise HTTPException(
            status_code=status.HTTP_408_REQUEST_TIMEOUT,
            detail="Repository operation timed out",
        )
    if result.returncode:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail=result.stderr.strip() or f"Repository command failed: {' '.join(command)}",
        )
    return result


async def _format_repo_summary(repo_root: Path, workspace_root: Path) -> RepoDiscoveryItem:
    branch = "unknown"
    uncommitted_count = 0
    last_commit: str | None = None

    status_result = await _run_repo_command(repo_root, ["git", "status", "--short"], timeout=10)
    status_lines = [line for line in status_result.stdout.splitlines() if line.strip()]
    uncommitted_count = len(status_lines)

    branch_result = await _run_repo_command(
        repo_root,
        ["git", "rev-parse", "--abbrev-ref", "HEAD"],
        timeout=10,
    )
    if branch_result.stdout.strip():
        branch = branch_result.stdout.strip()

    commit_result = await _run_repo_command(repo_root, ["git", "log", "-1", "--pretty=%H"], timeout=10)
    if commit_result.stdout.strip():
        last_commit = commit_result.stdout.strip()

    return RepoDiscoveryItem(
        path=_relative_repo_path(workspace_root, repo_root),
        branch=branch,
        clean=(uncommitted_count == 0),
        uncommitted_count=uncommitted_count,
        last_commit=last_commit,
    )


def _repo_job_now() -> str:
    return datetime.now(UTC).isoformat()


def _bounded_output(value: str) -> str:
    if len(value) <= TERMINAL_OUTPUT_LIMIT_BYTES:
        return value
    return value[:TERMINAL_OUTPUT_LIMIT_BYTES]


def _serialize_repo_job(
    *,
    tenant_id: str,
    job_id: str,
    operation: str,
    path: str,
    command: list[str],
    timeout_seconds: int,
    created_at: str,
    status: str = "queued",
    started_at: str | None = None,
    finished_at: str | None = None,
    exit_code: int | None = None,
    timed_out: bool = False,
    cancel_requested: bool = False,
    stdout: str = "",
    stderr: str = "",
) -> dict[str, object]:
    return {
        "tenant_id": tenant_id,
        "job_id": job_id,
        "operation": operation,
        "path": path,
        "command": list(command),
        "timeout_seconds": int(timeout_seconds),
        "created_at": created_at,
        "status": status,
        "started_at": started_at,
        "finished_at": finished_at,
        "exit_code": exit_code,
        "timed_out": bool(timed_out),
        "cancel_requested": bool(cancel_requested),
        "stdout": _bounded_output(stdout),
        "stderr": _bounded_output(stderr),
    }


def _format_job_response(job: dict[str, object]) -> RepoJobStatusResponse:
    return RepoJobStatusResponse(
        tenant_id=str(job.get("tenant_id") or ""),
        job_id=str(job.get("job_id") or ""),
        operation=str(job.get("operation") or ""),
        status=str(job.get("status") or "queued"),
        path=str(job.get("path") or ""),
        created_at=str(job.get("created_at") or ""),
        command=[str(part) for part in list(job.get("command") or [])],
        timeout_seconds=int(job.get("timeout_seconds") or DEFAULT_REPO_JOB_TIMEOUT_SECONDS),
        started_at=str(job.get("started_at") or "") or None,
        finished_at=str(job.get("finished_at") or "") or None,
        exit_code=int(job.get("exit_code")) if isinstance(job.get("exit_code"), int) else None,
        timed_out=bool(job.get("timed_out")),
        cancel_requested=bool(job.get("cancel_requested")),
        stdout=str(job.get("stdout") or ""),
        stderr=str(job.get("stderr") or ""),
    )


async def _persist_repo_job(job: dict[str, object]) -> None:
    await get_workspace_repo_job_store().put_job(
        str(job.get("tenant_id") or ""),
        str(job.get("job_id") or ""),
        dict(job),
    )


async def _load_repo_job(tenant_id: str, job_id: str) -> dict[str, object] | None:
    return await get_workspace_repo_job_store().get_job(tenant_id, job_id)


async def _list_repo_jobs(tenant_id: str) -> list[dict[str, object]]:
    jobs = await get_workspace_repo_job_store().list_jobs(tenant_id)
    return [dict(job) for job in jobs if str(job.get("tenant_id") or "") == tenant_id]


async def _delete_repo_job(tenant_id: str, job_id: str) -> None:
    await get_workspace_repo_job_store().delete_job(tenant_id, job_id)


async def _pop_active_repo_job(tenant_id: str, job_id: str) -> ActiveRepoJob | None:
    async with _ACTIVE_REPO_JOBS_LOCK:
        return _ACTIVE_REPO_JOBS.pop((tenant_id, job_id), None)


async def _get_active_repo_job(tenant_id: str, job_id: str) -> ActiveRepoJob | None:
    async with _ACTIVE_REPO_JOBS_LOCK:
        return _ACTIVE_REPO_JOBS.get((tenant_id, job_id))


async def _reconcile_repo_job(job: dict[str, object]) -> dict[str, object]:
    if str(job.get("status") or "") != "running":
        return job
    tenant_id = str(job.get("tenant_id") or "")
    job_id = str(job.get("job_id") or "")
    active = await _get_active_repo_job(tenant_id, job_id)
    if active is not None and active.task is not None and not active.task.done():
        return job
    job["status"] = "interrupted"
    job["finished_at"] = _repo_job_now()
    stderr = str(job.get("stderr") or "")
    suffix = "Repository job interrupted by runtime restart"
    job["stderr"] = suffix if not stderr else f"{stderr}\n{suffix}"
    await _persist_repo_job(job)
    return job


async def _execute_repo_process(
    command: list[str],
    cwd: Path,
    timeout_seconds: int,
    active_job: ActiveRepoJob,
) -> CommandResult:
    start = datetime.now(UTC)
    process: asyncio.subprocess.Process | None = None
    try:
        process = await asyncio.create_subprocess_exec(
            *command,
            cwd=str(cwd),
            env=_coerce_command_env(None),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        active_job.process = process
        stdout_raw, stderr_raw = await asyncio.wait_for(
            process.communicate(),
            timeout=max(1, timeout_seconds),
        )
        elapsed_ms = int((datetime.now(UTC) - start).total_seconds() * 1000)
        return CommandResult(
            returncode=process.returncode,
            stdout=_bounded_output((stdout_raw or b"").decode("utf-8", errors="replace")),
            stderr=_bounded_output((stderr_raw or b"").decode("utf-8", errors="replace")),
            duration_ms=elapsed_ms,
            timed_out=False,
        )
    except TimeoutError:
        if process is not None and process.returncode is None:
            process.kill()
            await process.wait()
        elapsed_ms = int((datetime.now(UTC) - start).total_seconds() * 1000)
        return CommandResult(
            returncode=None,
            stdout="",
            stderr="Repository job timed out",
            duration_ms=elapsed_ms,
            timed_out=True,
        )
    except asyncio.CancelledError:
        if process is not None and process.returncode is None:
            process.kill()
            await process.wait()
        elapsed_ms = int((datetime.now(UTC) - start).total_seconds() * 1000)
        return CommandResult(
            returncode=None,
            stdout="",
            stderr="Repository job cancelled",
            duration_ms=elapsed_ms,
            timed_out=False,
        )


async def _run_repo_job(
    *,
    tenant_id: str,
    job_id: str,
    operation: str,
    path: str,
    repo_root: Path,
    command: list[str],
    timeout_seconds: int,
) -> None:
    job = await _load_repo_job(tenant_id, job_id)
    if not job:
        return
    job["status"] = "running"
    job["started_at"] = _repo_job_now()
    await _persist_repo_job(job)

    active = await _get_active_repo_job(tenant_id, job_id)
    if active is None:
        return

    result = await _execute_repo_process(command, repo_root, timeout_seconds, active)
    job = (await _load_repo_job(tenant_id, job_id)) or job
    job["finished_at"] = _repo_job_now()
    job["stdout"] = result.stdout
    job["stderr"] = result.stderr
    job["timed_out"] = result.timed_out
    job["exit_code"] = result.returncode
    if bool(job.get("cancel_requested")):
        job["status"] = "cancelled"
    elif result.timed_out:
        job["status"] = "timed_out"
    elif result.returncode == 0:
        job["status"] = "completed"
    elif result.returncode is None and result.stderr == "Repository job cancelled":
        job["status"] = "cancelled"
    else:
        job["status"] = "failed"
    await _persist_repo_job(job)
    await _pop_active_repo_job(tenant_id, job_id)


async def _start_repo_job(
    *,
    tenant_id: str,
    operation: str,
    path: str,
    repo_root: Path,
    command: list[str],
    timeout_seconds: int = DEFAULT_REPO_JOB_TIMEOUT_SECONDS,
) -> dict[str, object]:
    job_id = uuid4().hex
    created_at = _repo_job_now()
    job = _serialize_repo_job(
        tenant_id=tenant_id,
        job_id=job_id,
        operation=operation,
        path=path,
        command=command,
        timeout_seconds=timeout_seconds,
        created_at=created_at,
    )
    await _persist_repo_job(job)
    active = ActiveRepoJob()
    async with _ACTIVE_REPO_JOBS_LOCK:
        _ACTIVE_REPO_JOBS[(tenant_id, job_id)] = active
    task = asyncio.create_task(
        _run_repo_job(
            tenant_id=tenant_id,
            job_id=job_id,
            operation=operation,
            path=path,
            repo_root=repo_root,
            command=command,
            timeout_seconds=timeout_seconds,
        )
    )
    active.task = task
    return job


def _resolve_repo_job_root(
    *,
    workspace_root: Path,
    operation: str,
    relative_path: str,
) -> Path:
    if operation == "clone":
        return workspace_root
    repo_root = resolve_workspace_path(workspace_root, _safe_path(relative_path))
    _ensure_git_repo(repo_root)
    return repo_root


async def _resume_repo_job(
    *,
    tenant_id: str,
    job: dict[str, object],
) -> dict[str, object]:
    status_value = str(job.get("status") or "")
    if status_value not in {"interrupted", "failed", "timed_out", "cancelled"}:
        raise HTTPException(status_code=409, detail="Repository job is not resumable")

    workspace_root = get_workspace_root(tenant_id)
    repo_root = _resolve_repo_job_root(
        workspace_root=workspace_root,
        operation=str(job.get("operation") or ""),
        relative_path=str(job.get("path") or ""),
    )

    job["status"] = "queued"
    job["started_at"] = None
    job["finished_at"] = None
    job["exit_code"] = None
    job["timed_out"] = False
    job["cancel_requested"] = False
    job["stdout"] = ""
    job["stderr"] = ""
    await _persist_repo_job(job)

    active = ActiveRepoJob()
    job_id = str(job.get("job_id") or "")
    command = [str(part) for part in list(job.get("command") or [])]
    timeout_seconds = int(job.get("timeout_seconds") or DEFAULT_REPO_JOB_TIMEOUT_SECONDS)

    async with _ACTIVE_REPO_JOBS_LOCK:
        _ACTIVE_REPO_JOBS[(tenant_id, job_id)] = active

    task = asyncio.create_task(
        _run_repo_job(
            tenant_id=tenant_id,
            job_id=job_id,
            operation=str(job.get("operation") or ""),
            path=str(job.get("path") or ""),
            repo_root=repo_root,
            command=command,
            timeout_seconds=timeout_seconds,
        )
    )
    active.task = task
    return job


async def _require_repo_job(tenant_id: str, job_id: str) -> dict[str, object]:
    job = await _load_repo_job(tenant_id, job_id)
    if not job:
        raise HTTPException(status_code=404, detail="Repository job not found")
    if str(job.get("tenant_id") or "") != tenant_id:
        raise HTTPException(status_code=404, detail="Repository job not found")
    return await _reconcile_repo_job(job)


@router.get("", response_model=RepoListResponse)
async def list_repositories(
    request: Request,
    max_depth: int = Query(default=MAX_REPO_DISCOVERY_DEPTH, ge=1, le=MAX_REPO_DISCOVERY_DEPTH_CAP),
    pagination: PaginationParams = Depends(
        build_pagination_dependency(
            default_limit=DEFAULT_REPO_DISCOVERY_PAGE_SIZE,
            max_limit=MAX_REPO_DISCOVERY_PAGE_SIZE,
        )
    ),
) -> RepoListResponse:
    await _enforce_discovery_rate_limit(request)

    tenant_id = get_tenant_id(request)
    workspace_root = get_workspace_root(tenant_id)

    offset = pagination.offset
    end = offset + pagination.limit
    repos: list[RepoDiscoveryItem] = []
    warnings: list[str] = []
    total = 0
    skipped = 0
    has_more = False

    for idx, repo_root in enumerate(_iter_repo_roots(workspace_root, max_depth), start=1):
        total += 1
        if idx <= offset:
            continue

        if idx <= end:
            try:
                repos.append(await _format_repo_summary(repo_root, workspace_root))
            except HTTPException as exc:
                skipped += 1
                if len(warnings) < REPO_DISCOVERY_WARNING_LIMIT:
                    relative_path = _relative_repo_path(workspace_root, repo_root)
                    warnings.append(f"{relative_path}: {exc.detail}")
            except Exception as exc:
                skipped += 1
                if len(warnings) < REPO_DISCOVERY_WARNING_LIMIT:
                    relative_path = _relative_repo_path(workspace_root, repo_root)
                    warnings.append(f"{relative_path}: {exc}")
                logger.exception("Failed to summarize repository for listing: %s", repo_root)
        else:
            has_more = True

    return RepoListResponse(
        tenant_id=tenant_id,
        total=total,
        repos=repos,
        page=pagination.page,
        page_size=pagination.page_size,
        has_more=has_more,
        skipped=skipped,
        warnings=warnings,
    )


@router.post("/clone", response_model=RepoCloneResponse)
async def clone_repository(
    request: Request,
    body: RepoCloneRequest,
) -> RepoCloneResponse:
    await _enforce_discovery_rate_limit(request)

    tenant_id = get_tenant_id(request)
    workspace_root = get_workspace_root(tenant_id)
    target_name = body.path or os.path.basename(body.remote_url.rstrip("/")).removesuffix(".git")
    if not target_name:
        target_name = "workspace-repo"
    target = resolve_workspace_path(workspace_root, target_name.strip().strip("/\\"))

    if target.exists():
        raise HTTPException(status_code=409, detail="Target directory already exists")

    args = ["git", "clone"]
    if body.depth:
        args.extend(["--depth", str(body.depth)])
    if body.branch:
        args.extend(["--branch", body.branch])
    args.extend([body.remote_url, str(target)])

    await _run_repo_command(workspace_root, args, timeout=180)

    return RepoCloneResponse(
        tenant_id=tenant_id,
        path=target.relative_to(workspace_root).as_posix(),
        remote_url=body.remote_url,
        branch=body.branch,
        created=True,
    )


@router.get("/status", response_model=RepoStatusResponse)
async def get_repo_status(
    request: Request,
    path: str,
) -> RepoStatusResponse:
    await _enforce_discovery_rate_limit(request)

    tenant_id = get_tenant_id(request)
    workspace_root = get_workspace_root(tenant_id)
    repo_root = resolve_workspace_path(workspace_root, _safe_path(path))

    _ensure_git_repo(repo_root)

    branch_out = await _run_repo_command(repo_root, ["git", "rev-parse", "--abbrev-ref", "HEAD"], timeout=10)
    status_out = await _run_repo_command(repo_root, ["git", "status", "--short"], timeout=10)
    commit_out = await _run_repo_command(repo_root, ["git", "log", "-1", "--pretty=%h %s"], timeout=10)
    remote_out = await _run_repo_command(repo_root, ["git", "remote"], timeout=10)

    uncommitted = [line for line in status_out.stdout.splitlines() if line.strip()]
    remotes = [remote.strip() for remote in remote_out.stdout.splitlines() if remote.strip()]

    return RepoStatusResponse(
        tenant_id=tenant_id,
        path=repo_root.relative_to(workspace_root).as_posix(),
        branch=branch_out.stdout.strip() or "unknown",
        clean=(len(uncommitted) == 0),
        uncommitted_files=len(uncommitted),
        last_commit=commit_out.stdout.strip() or None,
        remotes=remotes,
    )


@router.post("/pull", response_model=RepoPullResponse)
async def pull_repo(
    request: Request,
    body: RepoPullRequest,
) -> RepoPullResponse:
    await _enforce_discovery_rate_limit(request)

    tenant_id = get_tenant_id(request)
    workspace_root = get_workspace_root(tenant_id)
    repo_root = resolve_workspace_path(workspace_root, _safe_path(body.path))
    _ensure_git_repo(repo_root)

    args = ["git", "pull", body.remote]
    if body.rebase:
        args.append("--rebase")
    result = await _run_repo_command(repo_root, args, timeout=180)
    output = (result.stdout + "\n" + result.stderr).strip()

    return RepoPullResponse(
        tenant_id=tenant_id,
        path=repo_root.relative_to(workspace_root).as_posix(),
        remote=body.remote,
        rebase=body.rebase,
        output=output,
    )


@router.post("/branch", response_model=RepoBranchResponse)
async def branch_repo(
    request: Request,
    body: RepoBranchRequest,
) -> RepoBranchResponse:
    await _enforce_discovery_rate_limit(request)

    tenant_id = get_tenant_id(request)
    workspace_root = get_workspace_root(tenant_id)
    repo_root = resolve_workspace_path(workspace_root, _safe_path(body.path))
    _ensure_git_repo(repo_root)

    if body.action == "list":
        result = await _run_repo_command(repo_root, ["git", "branch", "--format=%(refname:short)"])
        branches = [line.strip() for line in result.stdout.splitlines() if line.strip()]

        offset = (body.page - 1) * body.page_size
        end = offset + body.page_size
        total = len(branches)
        has_more = end < total
        paged_branches = branches[offset:end]

        return RepoBranchResponse(
            tenant_id=tenant_id,
            path=repo_root.relative_to(workspace_root).as_posix(),
            action="list",
            branches=paged_branches,
            total=total,
            page=body.page,
            page_size=body.page_size,
            has_more=has_more,
        )

    if body.action == "current":
        result = await _run_repo_command(repo_root, ["git", "rev-parse", "--abbrev-ref", "HEAD"])
        return RepoBranchResponse(
            tenant_id=tenant_id,
            path=repo_root.relative_to(workspace_root).as_posix(),
            action="current",
            branch=result.stdout.strip() or None,
        )

    if not body.branch:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="branch is required for this action",
        )

    if body.action == "create":
        await _run_repo_command(repo_root, ["git", "checkout", "-b", body.branch])
        return RepoBranchResponse(
            tenant_id=tenant_id,
            path=repo_root.relative_to(workspace_root).as_posix(),
            action="create",
            branch=body.branch,
        )

    if body.action == "switch":
        await _run_repo_command(repo_root, ["git", "checkout", body.branch])
        return RepoBranchResponse(
            tenant_id=tenant_id,
            path=repo_root.relative_to(workspace_root).as_posix(),
            action="switch",
            branch=body.branch,
        )

    if body.action == "delete":
        await _run_repo_command(repo_root, ["git", "branch", "-D", body.branch])
        return RepoBranchResponse(
            tenant_id=tenant_id,
            path=repo_root.relative_to(workspace_root).as_posix(),
            action="delete",
            branch=body.branch,
        )

    raise HTTPException(status_code=400, detail="Unknown branch action")


@router.post("/jobs/clone", response_model=RepoJobAcceptedResponse, status_code=status.HTTP_202_ACCEPTED)
async def start_clone_job(
    request: Request,
    body: RepoCloneRequest,
) -> RepoJobAcceptedResponse:
    await _enforce_discovery_rate_limit(request)

    tenant_id = get_tenant_id(request)
    workspace_root = get_workspace_root(tenant_id)
    target_name = body.path or os.path.basename(body.remote_url.rstrip("/")).removesuffix(".git")
    if not target_name:
        target_name = "workspace-repo"
    target = resolve_workspace_path(workspace_root, target_name.strip().strip("/\\"))
    if target.exists():
        raise HTTPException(status_code=409, detail="Target directory already exists")

    command = ["git", "clone"]
    if body.depth:
        command.extend(["--depth", str(body.depth)])
    if body.branch:
        command.extend(["--branch", body.branch])
    command.extend([body.remote_url, str(target)])

    job = await _start_repo_job(
        tenant_id=tenant_id,
        operation="clone",
        path=target.relative_to(workspace_root).as_posix(),
        repo_root=workspace_root,
        command=command,
    )
    return RepoJobAcceptedResponse(
        tenant_id=tenant_id,
        job_id=str(job["job_id"]),
        operation="clone",
        status=str(job["status"]),
        path=str(job["path"]),
        created_at=str(job["created_at"]),
    )


@router.post("/jobs/pull", response_model=RepoJobAcceptedResponse, status_code=status.HTTP_202_ACCEPTED)
async def start_pull_job(
    request: Request,
    body: RepoPullRequest,
) -> RepoJobAcceptedResponse:
    await _enforce_discovery_rate_limit(request)

    tenant_id = get_tenant_id(request)
    workspace_root = get_workspace_root(tenant_id)
    repo_root = resolve_workspace_path(workspace_root, _safe_path(body.path))
    _ensure_git_repo(repo_root)

    command = ["git", "pull", body.remote]
    if body.rebase:
        command.append("--rebase")

    job = await _start_repo_job(
        tenant_id=tenant_id,
        operation="pull",
        path=repo_root.relative_to(workspace_root).as_posix(),
        repo_root=repo_root,
        command=command,
    )
    return RepoJobAcceptedResponse(
        tenant_id=tenant_id,
        job_id=str(job["job_id"]),
        operation="pull",
        status=str(job["status"]),
        path=str(job["path"]),
        created_at=str(job["created_at"]),
    )


@router.post("/jobs/branch", response_model=RepoJobAcceptedResponse, status_code=status.HTTP_202_ACCEPTED)
async def start_branch_job(
    request: Request,
    body: RepoBranchRequest,
) -> RepoJobAcceptedResponse:
    await _enforce_discovery_rate_limit(request)

    if body.action not in {"create", "switch", "delete"}:
        raise HTTPException(status_code=400, detail="Asynchronous branch jobs require create, switch, or delete")
    if not body.branch:
        raise HTTPException(status_code=400, detail="branch is required for this action")

    tenant_id = get_tenant_id(request)
    workspace_root = get_workspace_root(tenant_id)
    repo_root = resolve_workspace_path(workspace_root, _safe_path(body.path))
    _ensure_git_repo(repo_root)

    if body.action == "create":
        command = ["git", "checkout", "-b", body.branch]
    elif body.action == "switch":
        command = ["git", "checkout", body.branch]
    else:
        command = ["git", "branch", "-D", body.branch]

    job = await _start_repo_job(
        tenant_id=tenant_id,
        operation=f"branch:{body.action}",
        path=repo_root.relative_to(workspace_root).as_posix(),
        repo_root=repo_root,
        command=command,
    )
    return RepoJobAcceptedResponse(
        tenant_id=tenant_id,
        job_id=str(job["job_id"]),
        operation=str(job["operation"]),
        status=str(job["status"]),
        path=str(job["path"]),
        created_at=str(job["created_at"]),
    )


@router.get("/jobs", response_model=RepoJobListResponse)
async def list_repo_jobs(
    request: Request,
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> RepoJobListResponse:
    tenant_id = get_tenant_id(request)
    jobs = []
    rows = await _list_repo_jobs(tenant_id)
    for job in rows[pagination.offset : pagination.offset + pagination.limit]:
        jobs.append(_format_job_response(await _reconcile_repo_job(job)))
    return RepoJobListResponse(tenant_id=tenant_id, jobs=jobs, count=len(jobs))


@router.get("/jobs/{job_id}", response_model=RepoJobStatusResponse)
async def get_repo_job(
    request: Request,
    job_id: str,
) -> RepoJobStatusResponse:
    tenant_id = get_tenant_id(request)
    job = await _require_repo_job(tenant_id, job_id)
    return _format_job_response(job)


@router.post("/jobs/{job_id}/cancel", response_model=RepoJobStatusResponse)
async def cancel_repo_job(
    request: Request,
    job_id: str,
) -> RepoJobStatusResponse:
    tenant_id = get_tenant_id(request)
    job = await _require_repo_job(tenant_id, job_id)
    if str(job.get("status") or "") in REPO_JOB_TERMINAL_STATUSES:
        return _format_job_response(job)

    job["cancel_requested"] = True
    await _persist_repo_job(job)
    active = await _get_active_repo_job(tenant_id, job_id)
    if active is not None and active.task is not None:
        active.task.cancel()
        await asyncio.sleep(0)
        job = await _require_repo_job(tenant_id, job_id)
        return _format_job_response(job)

    job["status"] = "cancelled"
    job["finished_at"] = _repo_job_now()
    job["stderr"] = _bounded_output(str(job.get("stderr") or "Repository job cancelled"))
    await _persist_repo_job(job)
    return _format_job_response(job)


@router.post("/jobs/{job_id}/resume", response_model=RepoJobStatusResponse)
async def resume_repo_job(
    request: Request,
    job_id: str,
) -> RepoJobStatusResponse:
    tenant_id = get_tenant_id(request)
    job = await _require_repo_job(tenant_id, job_id)
    job = await _resume_repo_job(tenant_id=tenant_id, job=job)
    return _format_job_response(job)


@router.delete("/jobs/{job_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_repo_job(
    request: Request,
    job_id: str,
) -> None:
    tenant_id = get_tenant_id(request)
    job = await _require_repo_job(tenant_id, job_id)
    if str(job.get("status") or "") not in REPO_JOB_TERMINAL_STATUSES:
        raise HTTPException(status_code=409, detail="Repository job is still active")
    await _delete_repo_job(tenant_id, job_id)
