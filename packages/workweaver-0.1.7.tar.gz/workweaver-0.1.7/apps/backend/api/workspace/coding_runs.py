"""Governed coding-run API over tenant-scoped workspace compute."""

from __future__ import annotations

import asyncio
import logging
import os
import re
import shlex
from datetime import datetime, UTC
from pathlib import Path
from typing import Any, Literal
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field

from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.api.workspace._core import (
    TERMINAL_OUTPUT_LIMIT_BYTES,
    WorkspaceExecutionActor,
    get_workspace_root,
    get_workspace_terminal_actor,
    resolve_workspace_path,
)
from apps.backend.services.agent_credential_vault import get_agent_credential_vault
from apps.backend.services.approval_gates import get_approval_gates
from apps.backend.services.behavioral_stops_store import _get_stops as _get_behavioral_stops
from apps.backend.services.evidence_ledger import get_evidence_ledger_service
from apps.backend.services.execution.guard_service import (
    AutomationLevel,
    BehavioralStopConfig,
    PolicyVerdict,
    approval_request_id,
    approval_request_status,
    get_execution_guard,
)
from apps.backend.services.workspace_coding_run_store import (
    get_workspace_coding_run_store,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/workspace/coding-runs", tags=["workspace", "coding-runs"])

MAX_COMMAND_TIMEOUT_SECONDS = 900
SAFE_BASE_ENV_KEYS = frozenset(
    {
        "HOME",
        "LANG",
        "LC_ALL",
        "LC_CTYPE",
        "LC_MESSAGES",
        "PATH",
        "SHELL",
        "TERM",
        "TZ",
        "USER",
        "LOGNAME",
        "TMPDIR",
        "TEMP",
        "TMP",
    }
)
SAFE_CODING_ENV_KEYS = frozenset(
    {
        "GH_TOKEN",
        "GITHUB_TOKEN",
        "GIT_TERMINAL_PROMPT",
    }
)
CODING_DELIVERY_POLICY_TOOL = "workspace.coding.delivery"


def get_mission_run_state_service():
    from apps.backend.services.mission_run.state import get_mission_run_state_service as _service_factory

    return _service_factory()


class CodingRunSource(BaseModel):
    mode: Literal["workspace", "clone", "fork"] = "workspace"
    repo_path: str | None = None
    remote_url: str | None = None
    repository: str | None = None
    target_path: str | None = None


class CodingRunDelivery(BaseModel):
    mode: Literal["none", "push", "pr"] = "none"
    approval_required: bool = True
    remote: str = "origin"
    base_branch: str | None = None
    repo: str | None = None
    head: str | None = None
    title: str | None = None
    body: str | None = None
    comment_body: str | None = None
    status_context: str | None = None
    status_state: Literal["error", "failure", "pending", "success"] | None = None
    status_description: str | None = None
    github_credential_ref: str | None = None


class CodingRunCommand(BaseModel):
    command: str = Field(..., min_length=1, max_length=12_000)
    timeout_seconds: int | None = Field(default=None, ge=1, le=MAX_COMMAND_TIMEOUT_SECONDS)


class CodingRunRequest(BaseModel):
    run_id: str = Field(..., min_length=1, max_length=200)
    agent_id: str = Field(..., min_length=1, max_length=200)
    plan: list[str] = Field(default_factory=list)
    source: CodingRunSource = Field(default_factory=CodingRunSource)
    branch: str | None = Field(default=None, max_length=200)
    edit_commands: list[CodingRunCommand] = Field(default_factory=list)
    test_commands: list[CodingRunCommand] = Field(default_factory=list)
    command_timeout_seconds: int = Field(default=120, ge=1, le=MAX_COMMAND_TIMEOUT_SECONDS)
    delivery: CodingRunDelivery = Field(default_factory=CodingRunDelivery)


class CodingRunResponse(BaseModel):
    coding_run_id: str
    tenant_id: str
    run_id: str
    agent_id: str
    status: str
    source_mode: str
    repo_path: str
    branch: str | None = None
    remote_url: str | None = None
    plan: list[str] = Field(default_factory=list)
    executed_commands: list[dict[str, Any]] = Field(default_factory=list)
    approval_request_id: str | None = None
    approval_status: str | None = None
    delivery_mode: str
    current_commit: str | None = None
    base_commit: str | None = None
    diff_summary: str | None = None
    pr_url: str | None = None
    evidence_event_id: str | None = None
    evidence_url: str | None = None
    execution_budget_used: float | None = None
    execution_budget_limit: float | None = None
    governance_stop_reason: str | None = None
    governance_stop_evidence_id: str | None = None
    governance_stop_evidence_url: str | None = None
    created_at: str
    updated_at: str


class CodingRunListResponse(BaseModel):
    tenant_id: str
    runs: list[CodingRunResponse]
    count: int


def _coding_now() -> str:
    return datetime.now(UTC).isoformat()


def _bounded_output(value: str) -> str:
    if len(value) <= TERMINAL_OUTPUT_LIMIT_BYTES:
        return value
    return value[:TERMINAL_OUTPUT_LIMIT_BYTES]


def _safe_env(extra_env: dict[str, str] | None = None) -> dict[str, str]:
    env: dict[str, str] = {key: value for key, value in os.environ.items() if key in SAFE_BASE_ENV_KEYS}
    env["PATH"] = "/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin"
    for raw_key, raw_value in (extra_env or {}).items():
        key = str(raw_key).strip()
        if not key:
            continue
        if key in SAFE_CODING_ENV_KEYS or key.startswith("GIT_CONFIG_"):
            env[key] = str(raw_value)
    return env


async def _run_coding_command(
    command: str | list[str],
    *,
    cwd: Path,
    timeout_seconds: int,
    env: dict[str, str] | None = None,
) -> dict[str, Any]:
    if not cwd.exists():
        raise HTTPException(status_code=400, detail=f"Working directory not found: {cwd}")

    if isinstance(command, str):
        try:
            parts = shlex.split(command)
        except ValueError as exc:
            raise HTTPException(status_code=400, detail="Invalid command string") from exc
    else:
        parts = [str(part) for part in command if str(part).strip()]

    if not parts:
        raise HTTPException(status_code=400, detail="command cannot be empty")

    started_at = datetime.now(UTC)
    process = await asyncio.create_subprocess_exec(
        *parts,
        cwd=str(cwd),
        env=_safe_env(env),
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout_raw, stderr_raw = await asyncio.wait_for(
            process.communicate(),
            timeout=max(1, int(timeout_seconds)),
        )
        timed_out = False
    except TimeoutError:
        process.kill()
        await process.wait()
        stdout_raw, stderr_raw = b"", b"Command timed out"
        timed_out = True

    duration_ms = int((datetime.now(UTC) - started_at).total_seconds() * 1000)
    return {
        "command": " ".join(parts),
        "exit_code": process.returncode,
        "timed_out": timed_out,
        "stdout": _bounded_output((stdout_raw or b"").decode("utf-8", errors="replace")),
        "stderr": _bounded_output((stderr_raw or b"").decode("utf-8", errors="replace")),
        "duration_ms": duration_ms,
    }


def _require_governed_run(tenant_id: str, run_id: str, agent_id: str) -> dict[str, Any]:
    service = get_mission_run_state_service()
    state = service.get_run(tenant_id=tenant_id, run_id=run_id)
    if state is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Mission run not found")
    if str(state.get("status") or "") != "active":
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Mission run is not active")
    execution_budgets = dict(state.get("agent_execution_budgets") or {})
    if agent_id not in execution_budgets:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"No execution budget configured for agent '{agent_id}'",
        )
    return state


async def _persist_run(tenant_id: str, coding_run_id: str, record: dict[str, Any]) -> None:
    record["updated_at"] = _coding_now()
    await get_workspace_coding_run_store().put_run(tenant_id, coding_run_id, record)


async def _require_run(tenant_id: str, coding_run_id: str) -> dict[str, Any]:
    record = await get_workspace_coding_run_store().get_run(tenant_id, coding_run_id)
    if not record:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Coding run not found")
    if str(record.get("tenant_id") or "") != tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Coding run not found")
    return record


def _ensure_git_repo(repo_root: Path) -> None:
    if not (repo_root / ".git").exists():
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Path is not a git repository")


def _derive_target_name(source: CodingRunSource) -> str:
    if source.target_path:
        return source.target_path.strip()
    if source.mode == "clone" and source.remote_url:
        return os.path.basename(source.remote_url.rstrip("/")).removesuffix(".git") or "workspace-repo"
    if source.mode == "fork" and source.repository:
        return source.repository.split("/", 1)[-1] or "workspace-repo"
    if source.repo_path:
        return source.repo_path.strip()
    return "workspace-repo"


def _github_env(tenant_id: str, agent_id: str, credential_ref: str) -> dict[str, str]:
    try:
        payload = get_agent_credential_vault().get_payload(
            tenant_id=tenant_id,
            agent_id=agent_id,
            ref_id=credential_ref,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="credential_ref_not_found") from exc
    except PermissionError as exc:
        raise HTTPException(status_code=403, detail="cross_agent_credential_access_denied") from exc

    token = str(payload.get("access_token") or payload.get("token") or "").strip()
    if not token:
        raise HTTPException(status_code=409, detail="github_credential_missing_access_token")
    return {
        "GH_TOKEN": token,
        "GITHUB_TOKEN": token,
        "GIT_TERMINAL_PROMPT": "0",
        "GIT_CONFIG_COUNT": "1",
        "GIT_CONFIG_KEY_0": "credential.helper",
        "GIT_CONFIG_VALUE_0": "!gh auth git-credential",
    }


def _github_repo_from_remote(remote_url: str | None) -> str | None:
    value = str(remote_url or "").strip()
    if not value:
        return None
    match = re.search(r"github\.com[:/](?P<repo>[^/]+/[^/.]+)(?:\.git)?$", value)
    if not match:
        return None
    return match.group("repo")


def _command_timeout(spec: CodingRunCommand, default_timeout: int) -> int:
    return int(spec.timeout_seconds or default_timeout)


def _delivery_policy_decision(
    tenant_id: str,
    *,
    record: dict[str, Any],
    run_state: dict[str, Any] | None = None,
):
    delivery = CodingRunDelivery(**dict(record.get("delivery") or {}))
    delivery_inputs = {
        key: value
        for key, value in {
            "delivery_mode": delivery.mode,
            "repo_path": record.get("repo_path"),
            "branch": record.get("branch"),
            "remote_url": record.get("remote_url"),
            "current_commit": record.get("current_commit"),
            "repo": delivery.repo,
            "run_id": record.get("run_id"),
            "agent_id": record.get("agent_id"),
        }.items()
        if value not in (None, "")
    }
    coding_run_id = str(record.get("coding_run_id") or "").strip()
    run_id = str(record.get("run_id") or "").strip()
    agent_id = str(record.get("agent_id") or "").strip()
    governed_context = get_execution_guard().build_governed_action_context(
        tool_id="workspace_coding_delivery",
        operation_type=delivery.mode or "none",
        correlation_id=coding_run_id or run_id,
        entity_ids=[value for value in [agent_id, run_id] if value],
        source_event_ids=[value for value in [run_id, coding_run_id] if value],
        decision_trace_null_reason="execution_guard_capture_pending",
        proof_plane=(run_state or {}).get("proof_plane") or "production",
        side_effect=delivery.mode in {"push", "pr"},
    )
    return get_execution_guard().evaluate(
        tenant_id=tenant_id,
        tool_id="workspace_coding_delivery",
        policy_tool_name=CODING_DELIVERY_POLICY_TOOL,
        operation_type=delivery.mode or "none",
        automation_level=AutomationLevel.AUTO_EXECUTE_SAFE,
        behavioral_stops=BehavioralStopConfig(**_get_behavioral_stops(tenant_id)),
        inputs=delivery_inputs,
        agent_id=agent_id or None,
        entity_id=agent_id or None,
        session_id=coding_run_id or None,
        capture_surface="workspace",
        service_family="coding_runs",
        context_data=delivery_inputs or None,
        governed_context=governed_context or None,
    )


def _record_delivery_policy_stop(record: dict[str, Any], decision: Any) -> None:
    verdict = getattr(decision, "verdict", None)
    receipt = getattr(decision, "evidence_receipt", None)
    reasons = [str(reason) for reason in list(getattr(decision, "reasons", []) or []) if str(reason).strip()]
    trace_id = str((receipt or {}).get("trace_id") or "").strip() if isinstance(receipt, dict) else ""
    decision_id = str((receipt or {}).get("decision_id") or "").strip() if isinstance(receipt, dict) else ""

    record["approval_status"] = verdict.value if isinstance(verdict, PolicyVerdict) else None
    record["governance_stop_reason"] = "; ".join(reasons) or (
        verdict.value if isinstance(verdict, PolicyVerdict) else "delivery_policy_blocked"
    )
    record["governance_stop_evidence_id"] = decision_id or None
    record["governance_stop_evidence_url"] = f"/api/v1/evidence/decisions/{trace_id}" if trace_id else None
    record["status"] = "completed" if verdict == PolicyVerdict.DRAFT else "failed"


def _create_delivery_approval_request(
    *,
    tenant_id: str,
    coding_run_id: str,
    actor: WorkspaceExecutionActor,
    record: dict[str, Any],
    decision_reasons: list[str],
) -> None:
    approval = get_approval_gates().create_approval_request_safe(
        tenant_id=tenant_id,
        session_id=coding_run_id,
        user_id=actor.user_id,
        tool_name="workspace_coding_delivery",
        tool_params={
            "delivery_mode": record.get("delivery_mode"),
            "repo_path": record.get("repo_path"),
            "branch": record.get("branch"),
        },
        metadata={
            "source": "workspace_coding_runs_api",
            "coding_run_id": coding_run_id,
            "run_id": record.get("run_id"),
            "agent_id": record.get("agent_id"),
            "decision_reasons": decision_reasons,
        },
    )
    approval_request = getattr(approval, "approval_request", None)
    request_id = approval_request_id(approval_request)
    if not approval.success or approval_request is None or not request_id:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Approval system unavailable",
        )
    record["approval_request_id"] = request_id
    record["approval_status"] = approval_request_status(approval_request) or "pending"
    record["status"] = "awaiting_approval"


async def _git_output(repo_root: Path, command: list[str], *, env: dict[str, str] | None = None) -> str | None:
    result = await _run_coding_command(command, cwd=repo_root, timeout_seconds=60, env=env)
    if result["timed_out"] or result["exit_code"] not in (0, None):
        return None
    return str(result["stdout"] or "").strip() or None


def _record_budget_snapshot(record: dict[str, Any], run_state: dict[str, Any] | None, agent_id: str) -> None:
    budgets = dict(run_state.get("agent_execution_budgets") or {}) if run_state else {}
    entry = dict(budgets.get(agent_id) or {})
    record["execution_budget_used"] = float(entry.get("used")) if entry else None
    record["execution_budget_limit"] = float(entry.get("limit")) if entry else None
    record["governance_stop_reason"] = str(run_state.get("governance_stop_reason") or "") or None if run_state else None
    record["governance_stop_evidence_id"] = (
        str(run_state.get("governance_stop_evidence_id") or "") or None if run_state else None
    )
    record["governance_stop_evidence_url"] = (
        str(run_state.get("governance_stop_evidence_url") or "") or None if run_state else None
    )


def _append_command(
    record: dict[str, Any],
    *,
    phase: str,
    result: dict[str, Any],
) -> None:
    commands = list(record.get("executed_commands") or [])
    commands.append({"phase": phase, **result})
    record["executed_commands"] = commands


def _record_execution_step(
    *,
    tenant_id: str,
    run_id: str,
    agent_id: str,
    phase: str,
    command_text: str,
    repo_path: str,
) -> dict[str, Any]:
    service = get_mission_run_state_service()
    state, _exec_record, _command = service.record_execution_step(
        tenant_id=tenant_id,
        run_id=run_id,
        agent_id=agent_id,
        operation=f"workspace_coding_{phase}",
        fingerprint=f"{repo_path}:{command_text}",
        budget_cost=1.0,
        actor="workspace_coding_run",
        metadata={"phase": phase, "command": command_text},
    )
    return state


async def _write_coding_run_evidence(record: dict[str, Any]) -> tuple[str, str]:
    payload = {
        "item_type": "coding_run",
        "domain": "workspace_coding",
        "coding_run_id": record["coding_run_id"],
        "tenant_id": record["tenant_id"],
        "run_id": record["run_id"],
        "agent_id": record["agent_id"],
        "status": record["status"],
        "source_mode": record["source_mode"],
        "repo_path": record["repo_path"],
        "remote_url": record.get("remote_url"),
        "branch": record.get("branch"),
        "base_commit": record.get("base_commit"),
        "current_commit": record.get("current_commit"),
        "diff_summary": record.get("diff_summary"),
        "plan": list(record.get("plan") or []),
        "executed_commands": list(record.get("executed_commands") or []),
        "approval_request_id": record.get("approval_request_id"),
        "approval_status": record.get("approval_status"),
        "delivery_mode": record.get("delivery_mode"),
        "pr_url": record.get("pr_url"),
        "execution_budget_used": record.get("execution_budget_used"),
        "execution_budget_limit": record.get("execution_budget_limit"),
        "governance_stop_reason": record.get("governance_stop_reason"),
        "governance_stop_evidence_id": record.get("governance_stop_evidence_id"),
    }
    evidence = get_evidence_ledger_service().ingest(
        tenant_id=str(record["tenant_id"]),
        event_type="evidence:item",
        data=payload,
        actor_path="system.workspace_coding_run",
        artifact_payload=payload,
    )
    evidence_id = str(evidence["evidence_id"])
    return evidence_id, f"/api/v1/evidence/{evidence_id}"


async def _prepare_repo(
    *,
    tenant_id: str,
    agent_id: str,
    actor: WorkspaceExecutionActor,
    source: CodingRunSource,
    delivery: CodingRunDelivery,
    default_timeout: int,
    record: dict[str, Any],
) -> Path:
    workspace_root = get_workspace_root(tenant_id)
    if source.mode == "workspace":
        repo_root = resolve_workspace_path(workspace_root, source.repo_path)
        _ensure_git_repo(repo_root)
        return repo_root

    target_path = _derive_target_name(source)
    repo_root = resolve_workspace_path(workspace_root, target_path)
    if repo_root.exists():
        raise HTTPException(status_code=409, detail="Target repository path already exists")

    env: dict[str, str] | None = None
    if source.mode == "clone":
        if not source.remote_url:
            raise HTTPException(status_code=400, detail="remote_url is required for clone source mode")
        result = await _run_coding_command(
            ["git", "clone", source.remote_url, str(repo_root)],
            cwd=workspace_root,
            timeout_seconds=default_timeout,
        )
        _append_command(record, phase="source", result=result)
        if result["timed_out"] or result["exit_code"] != 0:
            raise HTTPException(status_code=422, detail="Repository clone failed")
        return repo_root

    if source.mode == "fork":
        if not source.repository:
            raise HTTPException(status_code=400, detail="repository is required for fork source mode")
        if not delivery.github_credential_ref:
            raise HTTPException(status_code=400, detail="github_credential_ref is required for fork source mode")
        env = _github_env(tenant_id, agent_id, delivery.github_credential_ref)
        command = [
            "gh",
            "repo",
            "fork",
            source.repository,
            "--clone",
            "--remote",
            "--remote-name",
            "origin",
            "--default-branch-only",
            "--",
            target_path,
        ]
        result = await _run_coding_command(
            command,
            cwd=workspace_root,
            timeout_seconds=default_timeout,
            env=env,
        )
        _append_command(record, phase="source", result=result)
        if result["timed_out"] or result["exit_code"] != 0:
            raise HTTPException(status_code=422, detail="Repository fork failed")
        return repo_root

    raise HTTPException(status_code=400, detail="Unsupported coding run source mode")


async def _finalize_repo_snapshot(
    record: dict[str, Any], repo_root: Path, *, env: dict[str, str] | None = None
) -> None:
    record["branch"] = await _git_output(repo_root, ["git", "rev-parse", "--abbrev-ref", "HEAD"], env=env)
    record["current_commit"] = await _git_output(repo_root, ["git", "rev-parse", "HEAD"], env=env)
    record["diff_summary"] = await _git_output(repo_root, ["git", "diff", "--stat"], env=env)
    record["remote_url"] = await _git_output(repo_root, ["git", "remote", "get-url", "origin"], env=env)


def _default_pr_title(record: dict[str, Any]) -> str:
    branch = str(record.get("branch") or "workspace-update")
    return f"Workweaver coding run: {branch}"


def _default_pr_body(record: dict[str, Any]) -> str:
    plan = list(record.get("plan") or [])
    if not plan:
        return f"Automated coding run {record['coding_run_id']}"
    return "\n".join(f"- {item}" for item in plan)


async def _deliver_run(
    *,
    tenant_id: str,
    actor: WorkspaceExecutionActor,
    record: dict[str, Any],
) -> dict[str, Any]:
    delivery = CodingRunDelivery(**dict(record.get("delivery") or {}))
    repo_root = resolve_workspace_path(get_workspace_root(tenant_id), str(record.get("repo_path") or ""))
    _ensure_git_repo(repo_root)

    env: dict[str, str] | None = None
    if delivery.mode in {"push", "pr"}:
        if not delivery.github_credential_ref:
            raise HTTPException(status_code=409, detail="github_credential_ref is required for delivery")
        env = _github_env(tenant_id, str(record["agent_id"]), delivery.github_credential_ref)

    if delivery.mode == "push":
        push_result = await _run_coding_command(
            ["git", "push", "-u", delivery.remote, str(record.get("branch") or "")],
            cwd=repo_root,
            timeout_seconds=record.get("command_timeout_seconds") or 120,
            env=env,
        )
        _append_command(record, phase="delivery", result=push_result)
        if push_result["timed_out"] or push_result["exit_code"] != 0:
            record["status"] = "failed"
            return record
    elif delivery.mode == "pr":
        push_result = await _run_coding_command(
            ["git", "push", "-u", delivery.remote, str(record.get("branch") or "")],
            cwd=repo_root,
            timeout_seconds=record.get("command_timeout_seconds") or 120,
            env=env,
        )
        _append_command(record, phase="delivery", result=push_result)
        if push_result["timed_out"] or push_result["exit_code"] != 0:
            record["status"] = "failed"
            return record

        repo_name = delivery.repo or _github_repo_from_remote(str(record.get("remote_url") or ""))
        if not repo_name:
            raise HTTPException(status_code=409, detail="Unable to determine GitHub repository for PR delivery")
        pr_command = [
            "gh",
            "pr",
            "create",
            "--repo",
            repo_name,
            "--base",
            delivery.base_branch or "main",
            "--head",
            delivery.head or str(record.get("branch") or ""),
            "--title",
            delivery.title or _default_pr_title(record),
            "--body",
            delivery.body or _default_pr_body(record),
        ]
        pr_result = await _run_coding_command(
            pr_command,
            cwd=repo_root,
            timeout_seconds=record.get("command_timeout_seconds") or 120,
            env=env,
        )
        _append_command(record, phase="delivery", result=pr_result)
        if pr_result["timed_out"] or pr_result["exit_code"] != 0:
            record["status"] = "failed"
            return record
        record["pr_url"] = str(pr_result.get("stdout") or "").strip() or None

        if delivery.comment_body and record["pr_url"]:
            comment_result = await _run_coding_command(
                [
                    "gh",
                    "pr",
                    "comment",
                    str(record["pr_url"]),
                    "--repo",
                    repo_name,
                    "--body",
                    delivery.comment_body,
                ],
                cwd=repo_root,
                timeout_seconds=record.get("command_timeout_seconds") or 120,
                env=env,
            )
            _append_command(record, phase="delivery", result=comment_result)
            if comment_result["timed_out"] or comment_result["exit_code"] != 0:
                record["status"] = "failed"
                return record

    if delivery.status_state:
        repo_name = delivery.repo or _github_repo_from_remote(str(record.get("remote_url") or ""))
        current_commit = str(record.get("current_commit") or "") or await _git_output(
            repo_root,
            ["git", "rev-parse", "HEAD"],
            env=env,
        )
        if not repo_name or not current_commit:
            raise HTTPException(status_code=409, detail="Unable to determine repository or commit for status delivery")
        status_result = await _run_coding_command(
            [
                "gh",
                "api",
                f"repos/{repo_name}/statuses/{current_commit}",
                "--method",
                "POST",
                "--raw-field",
                f"state={delivery.status_state}",
                "--raw-field",
                f"context={delivery.status_context or 'workweaver/coding-run'}",
                "--raw-field",
                f"description={delivery.status_description or 'Coding run completed'}",
            ],
            cwd=repo_root,
            timeout_seconds=record.get("command_timeout_seconds") or 120,
            env=env,
        )
        _append_command(record, phase="delivery", result=status_result)
        if status_result["timed_out"] or status_result["exit_code"] != 0:
            record["status"] = "failed"
            return record

    await _finalize_repo_snapshot(record, repo_root, env=env)
    record["status"] = "completed"
    record["approval_status"] = "approved" if record.get("approval_request_id") else None
    return record


async def _response_from_record(record: dict[str, Any]) -> CodingRunResponse:
    return CodingRunResponse(**record)


@router.post("", response_model=CodingRunResponse, status_code=status.HTTP_201_CREATED)
async def start_coding_run(
    request: Request,
    body: CodingRunRequest,
) -> CodingRunResponse:
    actor = get_workspace_terminal_actor(request)
    tenant_id = actor.tenant_id
    run_state = _require_governed_run(tenant_id, body.run_id, body.agent_id)

    if body.delivery.mode in {"push", "pr"} and not body.delivery.github_credential_ref:
        raise HTTPException(status_code=400, detail="github_credential_ref is required for push or pr delivery")

    coding_run_id = uuid4().hex
    record: dict[str, Any] = {
        "coding_run_id": coding_run_id,
        "tenant_id": tenant_id,
        "run_id": body.run_id,
        "agent_id": body.agent_id,
        "status": "running",
        "source_mode": body.source.mode,
        "repo_path": _derive_target_name(body.source),
        "branch": body.branch,
        "remote_url": body.source.remote_url,
        "plan": list(body.plan or []),
        "executed_commands": [],
        "approval_request_id": None,
        "approval_status": None,
        "delivery_mode": body.delivery.mode,
        "current_commit": None,
        "base_commit": None,
        "diff_summary": None,
        "pr_url": None,
        "evidence_event_id": None,
        "evidence_url": None,
        "execution_budget_used": None,
        "execution_budget_limit": None,
        "governance_stop_reason": None,
        "governance_stop_evidence_id": None,
        "governance_stop_evidence_url": None,
        "created_at": _coding_now(),
        "updated_at": _coding_now(),
        "delivery": body.delivery.model_dump(),
        "command_timeout_seconds": body.command_timeout_seconds,
    }
    _record_budget_snapshot(record, run_state, body.agent_id)
    await _persist_run(tenant_id, coding_run_id, record)

    repo_root = await _prepare_repo(
        tenant_id=tenant_id,
        agent_id=body.agent_id,
        actor=actor,
        source=body.source,
        delivery=body.delivery,
        default_timeout=body.command_timeout_seconds,
        record=record,
    )
    record["repo_path"] = repo_root.relative_to(get_workspace_root(tenant_id)).as_posix()
    await _finalize_repo_snapshot(record, repo_root)
    record["base_commit"] = record.get("current_commit")

    if body.branch:
        branch_result = await _run_coding_command(
            ["git", "checkout", "-B", body.branch],
            cwd=repo_root,
            timeout_seconds=body.command_timeout_seconds,
        )
        _append_command(record, phase="branch", result=branch_result)
        if branch_result["timed_out"] or branch_result["exit_code"] != 0:
            record["status"] = "failed"
            await _finalize_repo_snapshot(record, repo_root)
            evidence_id, evidence_url = await _write_coding_run_evidence(record)
            record["evidence_event_id"] = evidence_id
            record["evidence_url"] = evidence_url
            await _persist_run(tenant_id, coding_run_id, record)
            return await _response_from_record(record)
        run_state = _record_execution_step(
            tenant_id=tenant_id,
            run_id=body.run_id,
            agent_id=body.agent_id,
            phase="branch",
            command_text=branch_result["command"],
            repo_path=record["repo_path"],
        )
        _record_budget_snapshot(record, run_state, body.agent_id)
        if str(run_state.get("status") or "") != "active":
            record["status"] = "paused"
            evidence_id, evidence_url = await _write_coding_run_evidence(record)
            record["evidence_event_id"] = evidence_id
            record["evidence_url"] = evidence_url
            await _persist_run(tenant_id, coding_run_id, record)
            return await _response_from_record(record)

    for phase_name, commands in (("edit", body.edit_commands), ("test", body.test_commands)):
        for command in commands:
            _require_governed_run(tenant_id, body.run_id, body.agent_id)
            result = await _run_coding_command(
                command.command,
                cwd=repo_root,
                timeout_seconds=_command_timeout(command, body.command_timeout_seconds),
            )
            _append_command(record, phase=phase_name, result=result)
            run_state = _record_execution_step(
                tenant_id=tenant_id,
                run_id=body.run_id,
                agent_id=body.agent_id,
                phase=phase_name,
                command_text=result["command"],
                repo_path=record["repo_path"],
            )
            _record_budget_snapshot(record, run_state, body.agent_id)
            if str(run_state.get("status") or "") != "active":
                record["status"] = "paused"
                break
            if result["timed_out"] or result["exit_code"] != 0:
                record["status"] = "failed"
                break
        if record["status"] != "running":
            break

    await _finalize_repo_snapshot(record, repo_root)

    if record["status"] == "running":
        if body.delivery.mode == "none":
            record["status"] = "completed"
        else:
            delivery_run_state = _require_governed_run(tenant_id, body.run_id, body.agent_id)
            delivery_decision = _delivery_policy_decision(
                tenant_id,
                record=record,
                run_state=delivery_run_state,
            )
            if delivery_decision.verdict == PolicyVerdict.REQUIRE_APPROVAL:
                try:
                    _create_delivery_approval_request(
                        tenant_id=tenant_id,
                        coding_run_id=coding_run_id,
                        actor=actor,
                        record=record,
                        decision_reasons=list(delivery_decision.reasons or []),
                    )
                except Exception as exc:
                    logger.warning(
                        "Failed to create delivery approval for coding_run_id=%s",
                        coding_run_id,
                        exc_info=True,
                    )
                    record["status"] = "failed"
                    evidence_id, evidence_url = await _write_coding_run_evidence(record)
                    record["evidence_event_id"] = evidence_id
                    record["evidence_url"] = evidence_url
                    await _persist_run(tenant_id, coding_run_id, record)
                    raise HTTPException(
                        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                        detail="Approval system unavailable",
                    ) from exc
            elif delivery_decision.verdict == PolicyVerdict.ALLOW:
                record = await _deliver_run(tenant_id=tenant_id, actor=actor, record=record)
            else:
                _record_delivery_policy_stop(record, delivery_decision)

    evidence_id, evidence_url = await _write_coding_run_evidence(record)
    record["evidence_event_id"] = evidence_id
    record["evidence_url"] = evidence_url
    await _persist_run(tenant_id, coding_run_id, record)
    return await _response_from_record(record)


@router.post("/{coding_run_id}/deliver", response_model=CodingRunResponse)
async def deliver_coding_run(
    request: Request,
    coding_run_id: str,
) -> CodingRunResponse:
    actor = get_workspace_terminal_actor(request)
    tenant_id = actor.tenant_id
    record = await _require_run(tenant_id, coding_run_id)
    if str(record.get("status") or "") != "awaiting_approval":
        raise HTTPException(status_code=409, detail="Coding run is not awaiting delivery")
    run_state = _require_governed_run(tenant_id, str(record["run_id"]), str(record["agent_id"]))
    delivery_decision = _delivery_policy_decision(
        tenant_id,
        record=record,
        run_state=run_state,
    )
    if (
        delivery_decision.verdict == PolicyVerdict.REQUIRE_APPROVAL
        and not str(record.get("approval_request_id") or "").strip()
    ):
        try:
            _create_delivery_approval_request(
                tenant_id=tenant_id,
                coding_run_id=coding_run_id,
                actor=actor,
                record=record,
                decision_reasons=list(delivery_decision.reasons or []),
            )
        except Exception as exc:
            logger.warning(
                "Failed to create delivery approval during deliver for coding_run_id=%s",
                coding_run_id,
                exc_info=True,
            )
            await _persist_run(tenant_id, coding_run_id, record)
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Approval system unavailable",
            ) from exc
        await _persist_run(tenant_id, coding_run_id, record)
        raise HTTPException(status_code=409, detail="Coding run delivery is not approved")
    if delivery_decision.verdict == PolicyVerdict.DENY:
        _record_delivery_policy_stop(record, delivery_decision)
        await _persist_run(tenant_id, coding_run_id, record)
        raise HTTPException(status_code=403, detail="Coding run delivery blocked by policy")
    if delivery_decision.verdict == PolicyVerdict.DRAFT:
        _record_delivery_policy_stop(record, delivery_decision)
        await _persist_run(tenant_id, coding_run_id, record)
        raise HTTPException(status_code=409, detail="Coding run delivery withheld by policy")

    approval_request_id = str(record.get("approval_request_id") or "").strip()
    if approval_request_id:
        result = get_approval_gates().get_approval_request_safe(tenant_id=tenant_id, request_id=approval_request_id)
        approval_request = result.approval_request
        if not result.success or approval_request is None or not approval_request.is_approved():
            raise HTTPException(status_code=409, detail="Coding run delivery is not approved")
        record["approval_status"] = approval_request.status.value

    record["status"] = "delivering"
    await _persist_run(tenant_id, coding_run_id, record)
    record = await _deliver_run(tenant_id=tenant_id, actor=actor, record=record)
    evidence_id, evidence_url = await _write_coding_run_evidence(record)
    record["evidence_event_id"] = evidence_id
    record["evidence_url"] = evidence_url
    await _persist_run(tenant_id, coding_run_id, record)
    return await _response_from_record(record)


@router.get("/{coding_run_id}", response_model=CodingRunResponse)
async def get_coding_run(
    request: Request,
    coding_run_id: str,
) -> CodingRunResponse:
    actor = get_workspace_terminal_actor(request)
    record = await _require_run(actor.tenant_id, coding_run_id)
    return await _response_from_record(record)


@router.get("", response_model=CodingRunListResponse)
async def list_coding_runs(
    request: Request,
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=100)),
) -> CodingRunListResponse:
    actor = get_workspace_terminal_actor(request)
    rows = await get_workspace_coding_run_store().list_runs(
        actor.tenant_id,
        limit=pagination.offset + pagination.limit,
    )
    rows, _total = paginate_items(rows, pagination)
    runs = [await _response_from_record(row) for row in rows]
    return CodingRunListResponse(tenant_id=actor.tenant_id, runs=runs, count=len(runs))
