"""Agent work ledger API backed by canonical TimeBlocks."""

from __future__ import annotations

import logging
from datetime import UTC, datetime, timedelta
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, get_verified_user_id
from apps.backend.models.time_block import TimeBlock, TimeBlockOrigin, TimeBlockSource, TimeBlockState, TimeBlockType
from apps.backend.services.agent_work_ledger import get_agent_work_ledger_service
from apps.backend.services.scheduling.routines import get_routine_service
from apps.backend.services.scheduling.timeblock_materialization import (
    TimeBlockMaterializationRequest,
    get_timeblock_materialization_service,
)
from apps.backend.services.time_rollup_service import get_time_rollup_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/agent-work", tags=["agent-work"])

# Default workday hours (configurable per tenant via settings in the future)
DEFAULT_WORKDAY_START_HOUR = 8
DEFAULT_WORKDAY_END_HOUR = 20


class TimeBlockListResponse(BaseModel):
    blocks: list[TimeBlock] = Field(default_factory=list)
    count: int


class TimeBlockSummaryResponse(BaseModel):
    summary: dict[str, Any] = Field(default_factory=dict)


from apps.backend.contracts.agent_work_ledger import CalendarDensityInfo  # noqa: F401 -- re-export from contracts


class TimeBlockCalendarResponse(BaseModel):
    timezone: str
    range_start: str
    range_end: str
    summary: dict[str, Any] = Field(default_factory=dict)
    days: list[dict[str, Any]] = Field(default_factory=list)
    # Predicted future blocks — rendered with dashed border + 50% opacity (PR-07)
    predicted_blocks: list[dict[str, Any]] = Field(default_factory=list)
    # Pending human judgment items — rendered as "judgment debt" in calendar (PR-08)
    pending_judgments: list[dict[str, Any]] = Field(default_factory=list)
    # Calendar density metrics for the current view
    density: CalendarDensityInfo | None = None
    # Routine audit findings/recommendations built from the same ledger/schedule substrate.
    routine_audit: dict[str, Any] = Field(default_factory=dict)


class AutoresearchReportResponse(BaseModel):
    report: dict[str, Any] = Field(default_factory=dict)


class TimeSlot(BaseModel):
    """A single calendar-grid render slot.

    Supports 15/30/60-minute rendering granularity. This is a **view
    concern only** — the canonical audit unit is the hour
    (see ``TimeBlock.canonical_hour_bucket``). Per #1208, changing the
    rendered slot width does **not** change the underlying ontology.
    """

    time: str  # "08:00", "08:30", "09:00", etc.
    blocks: list[dict[str, Any]] = Field(default_factory=list)
    empty: bool = True


# Keep backward-compatible alias
HourSlot = TimeSlot


class CalendarGridResponse(BaseModel):
    """Full day grid with all workday slots rendered (empty or populated).

    ``granularity_minutes`` is a pure rendering / view concern. The
    canonical audit unit is always the hour, anchored at UTC — see
    :attr:`TimeBlock.canonical_hour_bucket` and the rollup service
    module docstring.
    """

    date: str
    timezone: str
    workday_start: int
    workday_end: int
    granularity_minutes: int = 30
    slots: list[TimeSlot] = Field(default_factory=list)


class RollupEntryResponse(BaseModel):
    period_start: str
    period_end: str
    total_blocks: int
    phase_distribution: dict[str, int] = Field(default_factory=dict)
    outcome_distribution: dict[str, int] = Field(default_factory=dict)
    block_type_distribution: dict[str, int] = Field(default_factory=dict)
    value_tier_distribution: dict[str, int] = Field(default_factory=dict)
    productivity_score_avg: float | None = None
    judgment_debt: int
    learning_velocity: float
    total_cost: float
    truncated: bool = False


class RollupResponse(BaseModel):
    granularity: str
    start: str
    end: str
    timezone: str = "UTC"
    entries: list[RollupEntryResponse] = Field(default_factory=list)


class CreateHumanBlockRequest(BaseModel):
    """Request body for creating a manual or external TimeBlock."""

    title: str = Field(..., min_length=1, max_length=500, description="Block title/objective")
    description: str = Field("", max_length=5000, description="Block description/plan")
    start_time: str = Field(..., description="Start time (ISO 8601)")
    end_time: str = Field(..., description="End time (ISO 8601)")
    phase: str = Field("execute", description="TimeBlock phase")
    mission_id: str | None = Field(None, description="Optional mission to associate with")
    agent_id: str = Field("human", description="Agent ID for the human block")
    schedule_id: str | None = Field(None, description="Optional schedule/routine link")
    origin: str = Field("user", description="Origin: user | autonomous | system")
    source: str = Field("human", description="Source: human | agent")
    block_type: str = Field("admin", description="Canonical block type")
    evidence_ids: list[str] = Field(default_factory=list, description="Linked evidence IDs")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional canonical metadata")
    upsert: bool = Field(False, description="Use upsert semantics instead of create-only")


class TimeBlockPatchRequest(BaseModel):
    """Partial update for a TimeBlock: reschedule, state change, or annotate."""

    started_at: str | None = Field(None, description="ISO 8601 datetime for rescheduling")
    state: str | None = Field(None, description="New state (planned, active, waiting, ...)")
    notes: str | None = Field(None, description="User annotation/notes")


class BlockFeedbackRequest(BaseModel):
    """Human feedback on a completed time block."""

    useful: bool = Field(..., description="Whether the block output was useful")
    comment: str = Field("", description="Optional feedback comment")


class BlockFeedbackResponse(BaseModel):
    """Response after recording block feedback."""

    block_id: str
    feedback_recorded: bool


class SystemActivityEntry(BaseModel):
    """A single system activity event."""

    block_id: str
    objective: str
    state: str
    phase: str
    started_at: str
    ended_at: str | None
    agent_id: str
    origin: str


class SystemActivityResponse(BaseModel):
    """List of recent system activity events."""

    activities: list[SystemActivityEntry] = Field(default_factory=list)


def _ledger():
    return get_agent_work_ledger_service()


def _materializer():
    return get_timeblock_materialization_service()


def _parse_datetime(value: str | None) -> datetime | None:
    if not value:
        return None
    parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    return parsed if parsed.tzinfo is not None else parsed.replace(tzinfo=UTC)


def _resolve_calendar_range(view: str, anchor: datetime | None) -> tuple[datetime, datetime]:
    """Resolve start/end from view type and anchor date.

    Supports: day, week, month, quarter.
    """
    base = anchor or datetime.now(UTC)
    start_of_day = base.replace(hour=0, minute=0, second=0, microsecond=0)

    if view == "day":
        return start_of_day, start_of_day + timedelta(days=1)

    if view == "week":
        weekday_offset = start_of_day.weekday()
        start_of_week = start_of_day - timedelta(days=weekday_offset)
        return start_of_week, start_of_week + timedelta(days=6, hours=23, minutes=59, seconds=59)

    if view == "month":
        start = start_of_day.replace(day=1)
        if start.month == 12:
            end = start.replace(year=start.year + 1, month=1)
        else:
            end = start.replace(month=start.month + 1)
        return start, end

    if view == "quarter":
        q_start_month = ((start_of_day.month - 1) // 3) * 3 + 1
        start = start_of_day.replace(month=q_start_month, day=1)
        end_month = q_start_month + 3
        if end_month > 12:
            end = start.replace(year=start.year + 1, month=end_month - 12)
        else:
            end = start.replace(month=end_month)
        return start, end

    # Fallback to week for unknown views
    weekday_offset = start_of_day.weekday()
    start_of_week = start_of_day - timedelta(days=weekday_offset)
    return start_of_week, start_of_week + timedelta(days=6, hours=23, minutes=59, seconds=59)


def _list_blocks(
    tenant_id: str,
    *,
    start_at: str | None = None,
    end_at: str | None = None,
    agent_id: str | None = None,
    team_id: str | None = None,
    department_id: str | None = None,
    organization_id: str | None = None,
    mission_id: str | None = None,
    run_id: str | None = None,
    schedule_id: str | None = None,
    state: str | None = None,
    outcome: str | None = None,
    lane: str | None = None,
    phase: str | None = None,
    limit: int = 500,
) -> list[TimeBlock]:
    return _ledger().list_blocks(
        tenant_id,
        start_at=_parse_datetime(start_at),
        end_at=_parse_datetime(end_at),
        agent_id=agent_id,
        team_id=team_id,
        department_id=department_id,
        organization_id=organization_id,
        mission_id=mission_id,
        run_id=run_id,
        schedule_id=schedule_id,
        state=state,
        outcome=outcome,
        lane=lane,
        phase=phase,
        limit=limit,
    )


@router.get("/blocks", response_model=TimeBlockListResponse)
async def list_blocks(
    tenant_id: str = Depends(get_verified_tenant_id),
    start_at: str | None = Query(None, description="Start of time range (ISO 8601)"),
    end_at: str | None = Query(None, description="End of time range (ISO 8601)"),
    agent_id: str | None = Query(None, description="Filter by agent"),
    team_id: str | None = Query(None, description="Filter by team"),
    department_id: str | None = Query(None, description="Filter by department"),
    organization_id: str | None = Query(None, description="Filter by organization"),
    mission_id: str | None = Query(None, description="Filter by mission"),
    run_id: str | None = Query(None, description="Filter by run"),
    schedule_id: str | None = Query(None, description="Filter by schedule/routine"),
    state: str | None = Query(None, description="Filter by block state"),
    outcome: str | None = Query(None, description="Filter by outcome"),
    lane: str | None = Query(None, description="Filter by lane"),
    phase: str | None = Query(None, description="Filter by phase"),
    limit: int = Query(500, ge=1, le=500, description="Maximum number of blocks to return"),
) -> TimeBlockListResponse:
    try:
        blocks = _list_blocks(
            tenant_id,
            start_at=start_at,
            end_at=end_at,
            agent_id=agent_id,
            team_id=team_id,
            department_id=department_id,
            organization_id=organization_id,
            mission_id=mission_id,
            run_id=run_id,
            schedule_id=schedule_id,
            state=state,
            outcome=outcome,
            lane=lane,
            phase=phase,
            limit=limit,
        )
        return TimeBlockListResponse(blocks=blocks, count=len(blocks))
    except ValueError as exc:
        logger.error("Invalid time block list parameters: %s", exc, exc_info=True)
        raise HTTPException(status_code=400, detail="Invalid request parameters") from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to list TimeBlocks") from exc


@router.post("/blocks", response_model=TimeBlock, status_code=201)
async def create_time_block(
    body: CreateHumanBlockRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
) -> TimeBlock:
    """Create a manual or external TimeBlock through the canonical creation seam."""
    try:
        start_dt = _parse_datetime(body.start_time)
        end_dt = _parse_datetime(body.end_time)
        if start_dt is None or end_dt is None:
            raise ValueError("start_time and end_time are required")
        if end_dt < start_dt:
            raise ValueError("end_time must be greater than or equal to start_time")

        now = datetime.now(UTC)
        if start_dt > now:
            state = TimeBlockState.PLANNED
        elif end_dt <= now:
            state = TimeBlockState.COMPLETED
        else:
            state = TimeBlockState.ACTIVE

        duration_budget_minutes = max(int((end_dt - start_dt).total_seconds() // 60), 1)
        metadata = {
            **body.metadata,
            "created_via": "agent_work_api",
            "requested_end_at": end_dt.isoformat(),
            "created_by_user_id": authenticated_user_id,
        }
        return _materializer().materialize(
            TimeBlockMaterializationRequest(
                tenant_id=tenant_id,
                agent_id=body.agent_id or authenticated_user_id or "human",
                mission_id=body.mission_id,
                schedule_id=body.schedule_id,
                objective=body.title,
                plan=body.description,
                actual=body.description if state == TimeBlockState.COMPLETED else "",
                duration_budget_minutes=duration_budget_minutes,
                started_at=start_dt,
                ended_at=end_dt if state == TimeBlockState.COMPLETED else None,
                phase=body.phase,
                state=state,
                outcome="neutral" if state == TimeBlockState.COMPLETED else "unknown",
                origin=TimeBlockOrigin(body.origin),
                source=TimeBlockSource(body.source),
                block_type=TimeBlockType(body.block_type),
                evidence_ids=body.evidence_ids,
                metadata=metadata,
                upsert=body.upsert,
            )
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to create TimeBlock") from exc


@router.get("/blocks/{block_id}", response_model=TimeBlock)
async def get_block(
    block_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> TimeBlock:
    block = _ledger().get_block(tenant_id, block_id)
    if block is None:
        raise HTTPException(status_code=404, detail=f"TimeBlock not found: {block_id}")
    return block


@router.get("/active", response_model=TimeBlockListResponse)
async def list_active_blocks(
    tenant_id: str = Depends(get_verified_tenant_id),
    agent_id: str | None = Query(None, description="Filter by agent"),
    mission_id: str | None = Query(None, description="Filter by mission"),
    run_id: str | None = Query(None, description="Filter by run"),
    limit: int = Query(200, ge=1, le=500, description="Maximum number of blocks to return"),
) -> TimeBlockListResponse:
    try:
        blocks = _ledger().list_active_blocks(
            tenant_id,
            agent_id=agent_id,
            mission_id=mission_id,
            run_id=run_id,
            limit=limit,
        )
        return TimeBlockListResponse(blocks=blocks, count=len(blocks))
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to list active TimeBlocks") from exc


@router.get("/summaries", response_model=TimeBlockSummaryResponse)
async def list_summaries(
    tenant_id: str = Depends(get_verified_tenant_id),
    start_at: str | None = Query(None, description="Start of time range (ISO 8601)"),
    end_at: str | None = Query(None, description="End of time range (ISO 8601)"),
    group_by: str = Query("day", pattern="^(day|week)$", description="Group summaries by day or week"),
    agent_id: str | None = Query(None, description="Filter by agent"),
    team_id: str | None = Query(None, description="Filter by team"),
    department_id: str | None = Query(None, description="Filter by department"),
    organization_id: str | None = Query(None, description="Filter by organization"),
    mission_id: str | None = Query(None, description="Filter by mission"),
    run_id: str | None = Query(None, description="Filter by run"),
    outcome: str | None = Query(None, description="Filter by outcome"),
    lane: str | None = Query(None, description="Filter by lane"),
) -> TimeBlockSummaryResponse:
    try:
        summary = _ledger().list_summaries(
            tenant_id,
            start_at=_parse_datetime(start_at),
            end_at=_parse_datetime(end_at),
            group_by=group_by,
            agent_id=agent_id,
            team_id=team_id,
            department_id=department_id,
            organization_id=organization_id,
            mission_id=mission_id,
            run_id=run_id,
            outcome=outcome,
            lane=lane,
        )
        return TimeBlockSummaryResponse(summary=summary)
    except ValueError as exc:
        logger.error("Invalid time block summary parameters: %s", exc, exc_info=True)
        raise HTTPException(status_code=400, detail="Invalid request parameters") from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to compute TimeBlock summaries") from exc


@router.get("/calendar", response_model=TimeBlockCalendarResponse)
async def calendar_view(
    tenant_id: str = Depends(get_verified_tenant_id),
    view: str = Query("week", pattern="^(day|week|month|quarter)$", description="Calendar view granularity"),
    anchor: str | None = Query(None, description="Anchor date for the view (ISO 8601)"),
    start_at: str | None = Query(None, description="Start of time range (ISO 8601)"),
    end_at: str | None = Query(None, description="End of time range (ISO 8601)"),
    timezone_name: str = Query("UTC", description="IANA timezone name for date grouping"),
    granularity_minutes: int = Query(
        30,
        description="Slot granularity in minutes (15, 30, or 60)",
    ),
    agent_id: str | None = Query(None, description="Filter by agent"),
    team_id: str | None = Query(None, description="Filter by team"),
    department_id: str | None = Query(None, description="Filter by department"),
    organization_id: str | None = Query(None, description="Filter by organization"),
    mission_id: str | None = Query(None, description="Filter by mission"),
    lane: str | None = Query(None, description="Filter by lane"),
    outcome: str | None = Query(None, description="Filter by outcome"),
) -> TimeBlockCalendarResponse:
    if granularity_minutes not in (15, 30, 60):
        raise HTTPException(status_code=400, detail="granularity_minutes must be 15, 30, or 60")
    try:
        start_dt = _parse_datetime(start_at)
        end_dt = _parse_datetime(end_at)
        if start_dt is None or end_dt is None:
            start_dt, end_dt = _resolve_calendar_range(view, _parse_datetime(anchor))
        response = _ledger().list_calendar_blocks(
            tenant_id,
            start_at=start_dt,
            end_at=end_dt,
            timezone_name=timezone_name,
            agent_id=agent_id,
            team_id=team_id,
            department_id=department_id,
            organization_id=organization_id,
            mission_id=mission_id,
            lane=lane,
            outcome=outcome,
        )
        # Augment with predicted blocks (PR-07 — Mission Calendar overlay)
        predicted_blocks: list[dict[str, Any]] = []
        try:
            from apps.backend.services.mission_prediction_service import get_mission_prediction_service

            active_blocks = [
                b
                for day in response.get("days", [])
                for b in day.get("blocks", [])
                if b.get("status")
                in {
                    "researching",
                    "drafting",
                    "awaiting_approval",
                    "pending_approval",
                    "approved",
                    "sent",
                    "meeting_booked",
                    "in_progress",
                }
            ]
            if active_blocks:
                pred_svc = get_mission_prediction_service()
                predicted_blocks = pred_svc.predict_blocks_for_workitems(active_blocks)
        except Exception as exc:
            logger.warning("calendar_view: prediction augmentation failed: %s", exc)

        # Augment with pending judgments (PR-08 — judgment debt display)
        pending_judgments: list[dict[str, Any]] = []
        try:
            from apps.backend.services.approval_gates import get_approval_gates

            gates = get_approval_gates()
            result = gates.list_pending_approvals(tenant_id)
            for req in result.requests or []:
                pending_judgments.append(
                    {
                        "judgment_id": req.request_id,
                        "tool_name": req.tool_name,
                        "summary": f"Approval required: {req.tool_name}",
                        "urgency": "high"
                        if req.expires_at and req.expires_at <= datetime.now(UTC) + timedelta(hours=1)
                        else "normal",
                        "created_at": req.created_at.isoformat() if req.created_at else None,
                        "expires_at": req.expires_at.isoformat() if req.expires_at else None,
                        "workitem_id": (req.metadata or {}).get("workitem_id"),
                        "session_id": req.session_id,
                        "inbox_link": f"#/inbox?judgment={req.request_id}",
                    }
                )
        except Exception as exc:
            logger.warning("calendar_view: judgment debt augmentation failed: %s", exc)

        # Compute calendar density (PR — Calendar Density Management)
        density_info = None
        try:
            from apps.backend.services.scheduling.calendar_density import compute_calendar_density

            workday_hours = float(DEFAULT_WORKDAY_END_HOUR - DEFAULT_WORKDAY_START_HOUR)
            density_info = compute_calendar_density(
                days=response.get("days", []),
                workday_hours=workday_hours,
            )
        except Exception as exc:
            logger.warning("calendar_view: density computation failed: %s", exc)

        routine_audit: dict[str, Any] = {}
        try:
            routine_audit = get_routine_service().build_audit_summary(tenant_id)
        except Exception as exc:
            logger.warning("calendar_view: routine audit augmentation failed: %s", exc)

        return TimeBlockCalendarResponse(
            **response,
            predicted_blocks=predicted_blocks,
            pending_judgments=pending_judgments,
            density=density_info,
            routine_audit=routine_audit,
        )
    except ValueError as exc:
        logger.error("Invalid calendar view parameters: %s", exc, exc_info=True)
        raise HTTPException(status_code=400, detail="Invalid request parameters") from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to load Mission Calendar") from exc


@router.get("/grid", response_model=CalendarGridResponse)
async def calendar_grid(
    tenant_id: str = Depends(get_verified_tenant_id),
    date: str = Query(..., description="Date to render (YYYY-MM-DD or ISO 8601)"),
    timezone_name: str = Query("UTC", description="IANA timezone name"),
    granularity_minutes: int = Query(
        30,
        description="Slot granularity in minutes (15, 30, or 60)",
    ),
    agent_id: str | None = Query(None, description="Filter by agent"),
    mission_id: str | None = Query(None, description="Filter by mission"),
) -> CalendarGridResponse:
    """Render a single-day calendar grid with configurable slot granularity.

    Returns all workday slots (empty or populated) for the given date.
    Default granularity is 30 minutes. Valid values: 15, 30, 60.
    """
    if granularity_minutes not in (15, 30, 60):
        raise HTTPException(status_code=400, detail="granularity_minutes must be 15, 30, or 60")

    try:
        anchor_dt = _parse_datetime(date)
        if anchor_dt is None:
            raise ValueError(f"Cannot parse date: {date}")
        start_dt = anchor_dt.replace(hour=DEFAULT_WORKDAY_START_HOUR, minute=0, second=0, microsecond=0)
        end_dt = anchor_dt.replace(hour=DEFAULT_WORKDAY_END_HOUR, minute=0, second=0, microsecond=0)

        blocks = _list_blocks(
            tenant_id,
            start_at=start_dt.isoformat(),
            end_at=end_dt.isoformat(),
            agent_id=agent_id,
            mission_id=mission_id,
            limit=500,
        )

        # Build time slots for the workday
        slots: list[TimeSlot] = []
        current = start_dt
        while current < end_dt:
            time_str = current.strftime("%H:%M")
            slot_end = current + timedelta(minutes=granularity_minutes)
            slot_blocks = [
                b.model_dump(mode="json") if hasattr(b, "model_dump") else {}
                for b in blocks
                if b.started_at
                and _parse_datetime(
                    b.started_at.isoformat() if isinstance(b.started_at, datetime) else str(b.started_at)
                )
                is not None
                and _parse_datetime(
                    b.started_at.isoformat() if isinstance(b.started_at, datetime) else str(b.started_at)
                )
                < slot_end
                and (
                    b.ended_at is None
                    or _parse_datetime(b.ended_at.isoformat() if isinstance(b.ended_at, datetime) else str(b.ended_at))
                    is None
                    or _parse_datetime(b.ended_at.isoformat() if isinstance(b.ended_at, datetime) else str(b.ended_at))
                    > current
                )
            ]
            slots.append(
                TimeSlot(
                    time=time_str,
                    blocks=slot_blocks,
                    empty=len(slot_blocks) == 0,
                )
            )
            current = slot_end

        return CalendarGridResponse(
            date=anchor_dt.strftime("%Y-%m-%d"),
            timezone=timezone_name,
            workday_start=DEFAULT_WORKDAY_START_HOUR,
            workday_end=DEFAULT_WORKDAY_END_HOUR,
            granularity_minutes=granularity_minutes,
            slots=slots,
        )
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to build calendar grid") from exc


@router.get("/autoresearch/report", response_model=AutoresearchReportResponse)
async def autoresearch_report(
    tenant_id: str = Depends(get_verified_tenant_id),
    start_at: str | None = Query(None, description="Start of time range (ISO 8601)"),
    end_at: str | None = Query(None, description="End of time range (ISO 8601)"),
    lane: str = Query(
        "simulation", pattern="^(simulation|shadow|production)$", description="Execution lane to analyze"
    ),
    mission_id: str | None = Query(None, description="Filter by mission"),
    run_id: str | None = Query(None, description="Filter by run"),
) -> AutoresearchReportResponse:
    try:
        from apps.backend.services.autoresearch.orchestrator import AutoresearchOrchestrator

        blocks = _ledger().list_blocks(
            tenant_id,
            start_at=_parse_datetime(start_at),
            end_at=_parse_datetime(end_at),
            mission_id=mission_id,
            run_id=run_id,
            limit=5000,
        )
        report = await AutoresearchOrchestrator().evaluate(
            tenant_id=tenant_id,
            blocks=blocks,
            lane=lane,
        )
        return AutoresearchReportResponse(report=report.model_dump(mode="json"))
    except ValueError as exc:
        logger.error("Invalid autoresearch report parameters: %s", exc, exc_info=True)
        raise HTTPException(status_code=400, detail="Invalid request parameters") from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to generate autoresearch report") from exc


@router.patch("/blocks/{block_id}", response_model=TimeBlock)
async def patch_time_block(
    block_id: str,
    body: TimeBlockPatchRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> TimeBlock:
    """Update a time block -- reschedule, change state, or annotate."""
    updates = body.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(status_code=400, detail="No fields provided for update")
    try:
        return _ledger().patch_block(tenant_id, block_id, updates)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to patch TimeBlock") from exc


@router.post("/blocks/{block_id}/feedback", response_model=BlockFeedbackResponse)
async def submit_block_feedback(
    block_id: str,
    body: BlockFeedbackRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> BlockFeedbackResponse:
    """Record human feedback on a completed time block.

    This is the gradient signal for the learning loop.
    """
    try:
        result = _ledger().record_feedback(
            tenant_id,
            block_id,
            useful=body.useful,
            comment=body.comment,
        )

        # Forward feedback to the learning loop as a human gradient signal
        try:
            from apps.backend.dependencies import get_learning_loop_service

            loop_svc = get_learning_loop_service(tenant_id=tenant_id)
            await loop_svc.record_human_feedback(
                tenant_id=tenant_id,
                task_id=block_id,
                useful=body.useful,
                comment=body.comment,
            )
        except Exception:
            logger.warning("Failed to forward feedback to learning loop", exc_info=True)

        return BlockFeedbackResponse(**result)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to record feedback") from exc


@router.get("/rollup", response_model=RollupResponse)
async def get_time_rollup(
    granularity: str = Query(
        "daily",
        description=(
            "Rollup granularity. Hourly is the canonical audit unit (#1208); "
            "coarser granularities compose deterministically from hourly buckets. "
            "Values: hourly, daily, weekly, monthly, quarterly, yearly."
        ),
    ),
    start: str = Query(..., description="Start datetime (ISO 8601)"),
    end: str = Query(..., description="End datetime (ISO 8601)"),
    scope_type: str = Query("individual", description="Scope type: individual, team, department, org"),
    timezone_name: str = Query(
        "UTC",
        description=(
            "IANA timezone for weekly/monthly/quarterly/yearly boundary alignment. "
            "Hourly buckets are always UTC — the canonical audit anchor."
        ),
    ),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> RollupResponse:
    """Aggregate time-block rollup at the requested granularity and scope.

    Per #1208 the hour is the canonical audit primitive. A block that
    spans N hours participates in N hourly buckets; coarser rollups
    attribute to a single bucket by the block's
    ``canonical_hour_bucket``.
    """
    try:
        svc = get_time_rollup_service()
        entries = svc.get_rollup(tenant_id, granularity, start, end, timezone_name=timezone_name)
        return RollupResponse(
            granularity=granularity,
            start=start,
            end=end,
            timezone=timezone_name,
            entries=[
                RollupEntryResponse(
                    period_start=e.period_start,
                    period_end=e.period_end,
                    total_blocks=e.total_blocks,
                    phase_distribution=e.phase_distribution,
                    outcome_distribution=e.outcome_distribution,
                    block_type_distribution=e.block_type_distribution,
                    value_tier_distribution=e.value_tier_distribution,
                    productivity_score_avg=(
                        round(e.productivity_score_sum / e.productivity_score_count, 4)
                        if e.productivity_score_count > 0
                        else None
                    ),
                    judgment_debt=e.judgment_debt,
                    learning_velocity=e.learning_velocity,
                    total_cost=float(e.total_cost),
                    truncated=e.truncated,
                )
                for e in entries
            ],
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to compute rollup") from exc


@router.get("/system-activity", response_model=SystemActivityResponse)
async def get_system_activity(
    limit: int = Query(10, ge=1, le=50, description="Max number of system activity events"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SystemActivityResponse:
    """Get recent system activity (memory consolidation, drift detection, etc.) for visible action trails."""
    try:
        activities = _ledger().get_system_activity(tenant_id, limit=limit)
        return SystemActivityResponse(
            activities=[SystemActivityEntry(**a) for a in activities],
        )
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to fetch system activity") from exc
