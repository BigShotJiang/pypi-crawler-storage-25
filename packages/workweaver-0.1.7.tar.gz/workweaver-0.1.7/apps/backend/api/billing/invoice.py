"""
Invoice Generation API for Workweaver Platform.

REST API endpoints for generating monthly Stripe invoices from usage data.
Integrates with InvoiceGeneratorService for automated billing.

Architecture:
- POST /api/v1/billing/invoices/generate - Generate invoice for tenant/period
- POST /api/v1/billing/invoices/generate-all - Generate all tenant invoices
- GET /api/v1/billing/invoices/{tenant_id} - List tenant invoices
- GET /api/v1/billing/invoices/{invoice_id} - Get invoice details

Constitutional Compliance:
- Axiom 1 (Agency): API-first design for agent consumption
- Axiom 2 (Memory): All invoice operations logged to Operational Context
- Axiom 5 (Defined/Undefined): Invoice generation is automated (no human intervention)

Legacy requirement reference: P1.7B.5 - Usage Metering & Billing
"""

import logging
from datetime import datetime, UTC
from typing import Any

from fastapi import APIRouter, HTTPException, Depends, Query, status
from pydantic import BaseModel, Field, field_validator

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

from apps.backend.services.billing.invoice_service import (
    InvoiceGeneratorService,
    InvoiceGenerationError,
)
from apps.backend.services.usage_tracker import UsageTrackerService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/billing/invoices", tags=["invoices"])


# === Request/Response Models ===


class GenerateInvoiceRequest(BaseModel):
    """Request to generate an invoice for a tenant."""

    tenant_id: str = Field(..., description="Tenant ID (TENANT#<ULID>)")
    year: int = Field(..., description="Billing year (e.g., 2026)", ge=2020, le=2100)
    month: int = Field(..., description="Billing month (1-12)", ge=1, le=12)
    force: bool = Field(False, description="Regenerate invoice even if one exists")

    @field_validator("month")
    @classmethod
    def validate_month(cls, v):
        """Ensure month is in valid range."""
        if not 1 <= v <= 12:
            raise ValueError("Month must be between 1 and 12")
        return v

    @field_validator("year")
    @classmethod
    def validate_year(cls, v):
        """Ensure year is reasonable."""
        current_year = datetime.now().year
        if v < 2020 or v > current_year + 1:
            raise ValueError(f"Year must be between 2020 and {current_year + 1}")
        return v


class GenerateAllInvoicesRequest(BaseModel):
    """Request to generate invoices for all tenants."""

    year: int = Field(..., description="Billing year (e.g., 2026)", ge=2020, le=2100)
    month: int = Field(..., description="Billing month (1-12)", ge=1, le=12)
    force: bool = Field(False, description="Regenerate invoices even if they exist")


class InvoiceLineItem(BaseModel):
    """Invoice line item."""

    description: str
    amount_aed: str
    quantity: int = 1


class InvoiceDetails(BaseModel):
    """Invoice details."""

    invoice_id: str
    invoice_status: str
    total_amount_aed: str
    currency: str
    period: str
    tenant_id: str
    invoice_url: str | None = None
    invoice_evidence_id: str | None = None
    invoice_evidence_url: str | None = None
    created_at: int
    line_items: list[InvoiceLineItem] = []


class InvoiceGenerationResponse(BaseModel):
    """Response from invoice generation."""

    status: str
    invoice_id: str | None = None
    invoice_status: str | None = None
    invoice_url: str | None = None
    invoice_evidence_id: str | None = None
    invoice_evidence_url: str | None = None
    total_amount_aed: str | None = None
    currency: str | None = None
    tenant_id: str
    period: str
    created_at: int | None = None
    error: str | None = None


class BulkInvoiceResponse(BaseModel):
    """Response from bulk invoice generation."""

    period: str
    total_tenants: int
    successful: int
    failed: int
    skipped: int
    results: list[InvoiceGenerationResponse]


# === Dependencies ===


def get_invoice_generator() -> InvoiceGeneratorService:
    """Get InvoiceGeneratorService instance."""
    try:
        return InvoiceGeneratorService()
    except Exception as e:
        logger.error(f"Failed to initialize InvoiceGeneratorService: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Invoice service not available",
        )


def get_usage_tracker() -> UsageTrackerService:
    """Get UsageTrackerService instance."""
    return UsageTrackerService()


def _assert_tenant_scope(scoped_tenant_id: str, verified_tenant_id: str) -> None:
    if str(scoped_tenant_id).strip() != str(verified_tenant_id).strip():
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Organization ID mismatch between route payload and authenticated session",
        )


# === Endpoint Handlers ===


@router.post(
    "/generate",
    response_model=InvoiceGenerationResponse,
    status_code=status.HTTP_200_OK,
    summary="Generate invoice for tenant",
    description="Generate a Stripe invoice for a specific tenant's usage in a billing period.",
)
async def generate_invoice(
    request: GenerateInvoiceRequest,
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    invoice_generator: InvoiceGeneratorService = Depends(get_invoice_generator),
) -> InvoiceGenerationResponse:
    """
    Generate a Stripe invoice for a tenant's usage.

    Args:
        request: Invoice generation request
        invoice_generator: Invoice generator service

    Returns:
        Invoice generation result

    Raises:
        HTTPException: If generation fails
    """
    try:
        _assert_tenant_scope(request.tenant_id, verified_tenant_id)
        logger.info(f"Generating invoice for tenant {request.tenant_id} for period {request.year}-{request.month:02d}")

        result = invoice_generator.generate_invoice_for_period(
            tenant_id=request.tenant_id,
            year=request.year,
            month=request.month,
            force=request.force,
        )

        return InvoiceGenerationResponse(**result)

    except InvoiceGenerationError as e:
        logger.error(f"Invoice generation failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invoice generation failed",
        )
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error generating invoice: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate invoice",
        )


@router.post(
    "/generate-all",
    response_model=BulkInvoiceResponse,
    status_code=status.HTTP_200_OK,
    summary="Generate invoices for all tenants",
    description="Generate Stripe invoices for all tenants with usage in a billing period.",
)
async def generate_all_invoices(
    request: GenerateAllInvoicesRequest,
    invoice_generator: InvoiceGeneratorService = Depends(get_invoice_generator),
) -> BulkInvoiceResponse:
    """
    Generate invoices for all tenants with usage.

    Args:
        request: Bulk invoice generation request
        invoice_generator: Invoice generator service

    Returns:
        Bulk invoice generation summary

    Raises:
        HTTPException: If generation fails catastrophically
    """
    try:
        logger.info(f"Generating invoices for all tenants for period {request.year}-{request.month:02d}")

        results = invoice_generator.generate_invoices_for_all_tenants(
            year=request.year,
            month=request.month,
            force=request.force,
        )

        # Count results
        successful = sum(1 for r in results if r["status"] == "success")
        failed = sum(1 for r in results if r["status"] == "error")
        skipped = sum(1 for r in results if r["status"] == "already_invoiced")

        return BulkInvoiceResponse(
            period=f"{request.year}-{request.month:02d}",
            total_tenants=len(results),
            successful=successful,
            failed=failed,
            skipped=skipped,
            results=[InvoiceGenerationResponse(**r) for r in results],
        )

    except Exception as e:
        if isinstance(e, HTTPException):
            raise
        logger.error(f"Unexpected error generating bulk invoices: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate bulk invoices",
        )


@router.get(
    "/{tenant_id}",
    response_model=list[dict[str, Any]],
    status_code=status.HTTP_200_OK,
    summary="List tenant invoices",
    description="List all invoices for a specific tenant.",
)
async def list_tenant_invoices(
    tenant_id: str,
    months: int = Query(12, ge=1, le=24, description="Number of months of history"),
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    usage_tracker: UsageTrackerService = Depends(get_usage_tracker),
) -> list[dict[str, Any]]:
    """
    List all invoices for a tenant.

    Args:
        tenant_id: Tenant ID
        months: Number of months of invoice history (1-24, default 12)
        usage_tracker: Usage tracker service

    Returns:
        List of invoice summaries
    """
    try:
        _assert_tenant_scope(tenant_id, verified_tenant_id)
        # Get usage history (which includes invoice information)
        history = usage_tracker.get_usage_history(tenant_id, months=months)

        # Filter for invoiced periods
        invoices = []
        for period_data in history:
            if period_data.get("invoice_id"):
                period = period_data.get(
                    "period",
                    f"{period_data.get('year')}-{str(period_data.get('month')).zfill(2)}",
                )
                invoices.append(
                    {
                        "invoice_id": period_data["invoice_id"],
                        "period": period,
                        "status": period_data.get("invoice_status", "unknown"),
                        "total_aed": str(period_data.get("total_cost_aed", 0)),
                        "invoice_url": period_data.get("invoice_url"),
                        "invoice_evidence_id": period_data.get("invoice_evidence_id"),
                        "invoice_evidence_url": period_data.get("invoice_evidence_url"),
                        "billed_metrics": period_data.get("billed_metrics", {}),
                        "usage_source_key": period_data.get("usage_source_key"),
                        "invoiced_at": period_data.get("invoiced_at"),
                    }
                )

        return invoices

    except Exception as e:
        if isinstance(e, HTTPException):
            raise
        logger.error(f"Failed to list invoices for tenant {tenant_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list invoices",
        )


@router.get(
    "/health",
    status_code=status.HTTP_200_OK,
    summary="Invoice service health check",
    description="Check if invoice generation service is healthy.",
)
async def health_check() -> dict[str, str]:
    """
    Health check endpoint.

    Returns:
        Health status
    """
    return {
        "status": "healthy",
        "service": "invoice-generator",
        "timestamp": datetime.now(UTC).isoformat(),
    }
