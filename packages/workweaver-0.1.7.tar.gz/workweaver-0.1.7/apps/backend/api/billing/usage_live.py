"""Per-Member live metering + agent pause/resume endpoints (#2728).

Backs the Mission Calendar live-cost-banner shipped in PR #3113.

The frontend banner polls ``GET /api/v1/billing/usage/{tenant_id}/live`` and
shows ``Pause my agents`` / ``Resume`` actions which call this router's
``POST /api/v1/billing/pause-agents`` and ``POST /api/v1/billing/resume-agents``.

Live spend is read from the canonical ``UsageTrackerService.get_member_usage_summary``
read model. ``paused`` reads/writes the ``BehavioralStops`` store (``paused``
field) -- the same surface that ``ExecutionGuard`` consults to deny tool
invocations and that ``tenant_lifecycle_admin._pause_tenant_execution``
already targets.

Design constraints (from issue #2728):
  * Per-member scope: the response only carries the *caller's* breakdown.
    ``member_id`` is derived from the authenticated session, not the URL.
  * ``today`` = start of UTC day; ``month`` = start of UTC month.
  * Pause/resume both emit a Decision Trace via ``_emit_decision_trace``
    (info-log evidence the same way ``api/skills_admin.py`` does for skill
    mutations -- the canonical evidence ledger absorbs the log line).
  * Pause when already paused / resume when already running is idempotent
    and does NOT emit a second trace -- governance noise reduction.
  * Provider-level breakdown sourcing is out-of-scope for this PR; the
    response shape is wired but populated as an empty list until provider
    tags land on inference events. See follow-ups in the PR body.
"""

from __future__ import annotations

import logging
from datetime import datetime, UTC
from decimal import Decimal, InvalidOperation
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_id,
)
from apps.backend.services.behavioral_stops_store import (
    BehavioralStopsStoreError,
    get_behavioral_stops,
    save_behavioral_stops,
)
from apps.backend.services.usage_tracker import (
    UsageAggregationError,
    UsageTrackerService,
)


logger = logging.getLogger(__name__)


router = APIRouter(prefix="/api/v1/billing", tags=["billing", "usage", "live"])


# ---------------------------------------------------------------------------
# Pydantic response models
# ---------------------------------------------------------------------------


class LiveSpendBreakdownEntry(BaseModel):
    """One row of the per-member spend breakdown.

    The frontend banner uses this only for the "View breakdown" link target.
    Provider-level rollup is out-of-scope for #2728; ``provider`` falls back
    to ``"workweaver"`` until inference events carry provider tags.
    """

    provider: str = Field(..., description="Inference / capability provider")
    agent: str = Field(..., description="Agent identifier")
    usd: float = Field(..., ge=0.0, description="USD attributed to this row this month")


class LiveSpendResponse(BaseModel):
    """Live spend snapshot for one member of one tenant.

    Mirrors the contract the frontend already shipped in PR #3113.
    """

    tenant_id: str = Field(..., description="Tenant identifier (no TENANT# prefix)")
    member_id: str = Field(..., description="Authenticated member identifier")
    spend_usd_today: float = Field(
        ..., ge=0.0, description="Member's UTC-day spend in USD"
    )
    spend_usd_month: float = Field(
        ..., ge=0.0, description="Member's UTC-month spend in USD"
    )
    last_updated_at: datetime = Field(
        ..., description="Snapshot freshness timestamp (UTC)"
    )
    breakdown: list[LiveSpendBreakdownEntry] = Field(
        default_factory=list,
        description="Per-(provider, agent) breakdown for this member",
    )
    paused: bool = Field(
        ..., description="True when the tenant has paused all agent execution"
    )


# ---------------------------------------------------------------------------
# Dependencies / helpers
# ---------------------------------------------------------------------------


def get_usage_tracker() -> UsageTrackerService:
    """Lazy-construct the canonical usage tracker."""
    return UsageTrackerService()


def _normalize_tenant(value: str) -> str:
    raw = str(value or "").strip()
    return raw[len("TENANT#") :] if raw.startswith("TENANT#") else raw


def _assert_tenant_scope(path_tenant_id: str, verified_tenant_id: str) -> None:
    """Reject mismatched tenant on the URL path. Returns 404 to avoid leaking
    cross-tenant existence checks via 403 vs 404 timing differences -- the
    frontend treats both 404 and network errors as fall-open silent."""
    if _normalize_tenant(path_tenant_id) != _normalize_tenant(verified_tenant_id):
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Tenant not found",
        )


def _safe_float(raw: Any) -> float:
    """Coerce DDB / Decimal / str cost values to a float without raising."""
    if raw is None:
        return 0.0
    try:
        return float(Decimal(str(raw)))
    except (InvalidOperation, TypeError, ValueError):
        return 0.0


def _emit_decision_trace(
    *,
    tenant_id: str,
    event_type: str,
    member_id: str,
    payload: dict[str, Any],
) -> None:
    """Emit a Decision Trace event for a pause / resume mutation.

    Mirrors ``apps/backend/api/skills_admin._emit_decision_trace`` -- the
    canonical evidence ledger absorbs the structured log line in production.
    Tests assert via ``caplog`` so this stays a thin info-log emit.
    """
    receipt = {
        "type": event_type,
        "tenant_id": tenant_id,
        "member_id": member_id,
        "timestamp": datetime.now(UTC).isoformat(),
        **payload,
    }
    logger.info("Decision trace event: %s", receipt)


def _spend_for_member(
    *,
    summary: dict[str, Any],
    member_id: str,
) -> tuple[float, list[LiveSpendBreakdownEntry]]:
    """Pull the member's row out of a member-usage summary.

    Returns ``(spend_usd, breakdown)``. Empty when the member has no
    recorded spend in the requested period.
    """
    items = summary.get("items") or []
    breakdown: list[LiveSpendBreakdownEntry] = []
    spend_usd = 0.0
    target = str(member_id or "").strip()

    for item in items:
        actor = str(item.get("actor_id") or "").strip()
        if actor != target:
            continue
        spend_usd = _safe_float(item.get("total_cost_usd"))
        # Per-metric cost rows feed the breakdown table. Provider tagging
        # on metering events is rolling out (#2728 follow-up), so until
        # then the provider falls back to "workweaver" and the metric
        # type stands in as the agent surface.
        metrics = item.get("metrics") or {}
        if isinstance(metrics, dict):
            for metric_type, metric_data in metrics.items():
                cost = _safe_float((metric_data or {}).get("total_cost_usd"))
                if cost <= 0:
                    continue
                breakdown.append(
                    LiveSpendBreakdownEntry(
                        provider="workweaver",
                        agent=str(metric_type),
                        usd=round(cost, 6),
                    )
                )
        break

    breakdown.sort(key=lambda row: row.usd, reverse=True)
    return spend_usd, breakdown


def _build_live_response(
    *,
    tenant_id: str,
    member_id: str,
    usage_tracker: UsageTrackerService,
    paused: bool,
) -> LiveSpendResponse:
    """Assemble the LiveSpendResponse from the canonical aggregator."""
    now = datetime.now(UTC)
    today = now.date()

    # Month-to-date: use the canonical member rollup that already reads
    # the same partition usage events get written to.
    try:
        month_summary = usage_tracker.get_member_usage_summary(
            tenant_id, now.year, now.month, limit=200
        )
    except UsageAggregationError as exc:
        logger.warning(
            "live_spend.month_aggregation_failed tenant=%s err=%s",
            tenant_id,
            exc,
        )
        month_summary = {"items": []}
    except Exception as exc:  # noqa: BLE001 -- fall-open
        logger.warning(
            "live_spend.month_aggregation_unexpected tenant=%s err=%s",
            tenant_id,
            type(exc).__name__,
        )
        month_summary = {"items": []}

    spend_month, breakdown = _spend_for_member(
        summary=month_summary, member_id=member_id
    )

    # Day rollup: re-use the same monthly partition but constrain to
    # today's events. ``get_member_usage_summary`` does not currently
    # expose a date filter, so we approximate today's spend by walking
    # the same items and filtering on the ``timestamp`` field that
    # ``UsageTrackerService.record_usage`` writes onto each row.
    spend_today = _today_spend_from_summary(
        summary=month_summary,
        member_id=member_id,
        today=today,
        usage_tracker=usage_tracker,
        tenant_id=tenant_id,
    )

    return LiveSpendResponse(
        tenant_id=_normalize_tenant(tenant_id),
        member_id=member_id,
        spend_usd_today=round(spend_today, 6),
        spend_usd_month=round(spend_month, 6),
        last_updated_at=now,
        breakdown=breakdown,
        paused=paused,
    )


def _today_spend_from_summary(
    *,
    summary: dict[str, Any],
    member_id: str,
    today: Any,
    usage_tracker: UsageTrackerService,
    tenant_id: str,
) -> float:
    """Best-effort UTC-day rollup for one member.

    ``get_member_usage_summary`` already aggregates the month. To split
    today's slice without scanning a second time we re-query the raw
    partition and filter on the per-row ``timestamp`` field. If that
    fails (unlikely; same store), fall back to the monthly figure
    (over-counts but keeps the banner usable rather than dark).
    """
    target = str(member_id or "").strip()
    try:
        # Reach into the same store the tracker uses. ``_store`` is the
        # PortableStore in tests; in prod the tracker uses DynamoDB
        # directly via ``self.table``. Fall through to month spend in
        # the prod path so we never raise.
        store = getattr(usage_tracker, "_store", None)
        if store is None:
            return _spend_for_member(summary=summary, member_id=member_id)[0]
        pk = usage_tracker._usage_partition_key(  # type: ignore[attr-defined]
            tenant_id, today.year, f"{today.month:02d}"
        )
        raw_items = store.query(pk, sk_prefix="METRIC#", limit=500)
    except Exception:  # noqa: BLE001
        return _spend_for_member(summary=summary, member_id=member_id)[0]

    spend = 0.0
    for raw in raw_items:
        item = raw.get("data", raw) if isinstance(raw, dict) else raw
        if not isinstance(item, dict):
            continue
        actor = str(item.get("actor_id") or "").strip()
        if actor != target:
            metadata = item.get("metadata") if isinstance(item.get("metadata"), dict) else {}
            for key in ("actor_id", "member_user_id", "member_id", "user_id"):
                candidate = str(metadata.get(key) or "").strip()
                if candidate:
                    actor = candidate
                    break
            if actor != target:
                continue
        ts_raw = str(item.get("timestamp") or "").strip()
        if not ts_raw:
            continue
        try:
            ts = datetime.fromisoformat(ts_raw.replace("Z", "+00:00"))
        except ValueError:
            continue
        if ts.astimezone(UTC).date() != today:
            continue
        # Cost lives either on the row itself or in the embedded metadata.
        cost = _safe_float(item.get("cost_usd") or item.get("total_cost_usd"))
        if cost == 0.0:
            metadata = item.get("metadata") if isinstance(item.get("metadata"), dict) else {}
            cost = _safe_float(metadata.get("cost_usd"))
        spend += cost
    return spend


# ---------------------------------------------------------------------------
# GET /api/v1/billing/usage/{tenant_id}/live
# ---------------------------------------------------------------------------


@router.get(
    "/usage/{tenant_id}/live",
    response_model=LiveSpendResponse,
    summary="Get live per-Member spend snapshot",
    description=(
        "Returns the authenticated member's UTC-day and UTC-month spend, "
        "the per-(provider, agent) breakdown, and the tenant's pause state. "
        "Backs the Mission Calendar live-cost-banner (#3113)."
    ),
)
async def get_live_spend(
    tenant_id: str,
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    member_id: str = Depends(get_verified_user_id),
    usage_tracker: UsageTrackerService = Depends(get_usage_tracker),
) -> LiveSpendResponse:
    _assert_tenant_scope(tenant_id, verified_tenant_id)
    stops = get_behavioral_stops(verified_tenant_id)
    paused = bool(stops.get("paused"))
    return _build_live_response(
        tenant_id=verified_tenant_id,
        member_id=member_id,
        usage_tracker=usage_tracker,
        paused=paused,
    )


# ---------------------------------------------------------------------------
# POST /api/v1/billing/pause-agents
# ---------------------------------------------------------------------------


@router.post(
    "/pause-agents",
    response_model=LiveSpendResponse,
    summary="Pause all agent execution for the caller's tenant",
    description=(
        "Flips the BehavioralStops ``paused`` flag to true. Idempotent: "
        "calling twice does NOT emit a second Decision Trace. The response "
        "is the same shape as GET /usage/{tenant_id}/live so the frontend "
        "can swap state without a second round-trip."
    ),
)
async def pause_agents(
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    member_id: str = Depends(get_verified_user_id),
    usage_tracker: UsageTrackerService = Depends(get_usage_tracker),
) -> LiveSpendResponse:
    return _toggle_pause(
        tenant_id=verified_tenant_id,
        member_id=member_id,
        usage_tracker=usage_tracker,
        target_paused=True,
        event_type="billing.agents.paused",
    )


# ---------------------------------------------------------------------------
# POST /api/v1/billing/resume-agents
# ---------------------------------------------------------------------------


@router.post(
    "/resume-agents",
    response_model=LiveSpendResponse,
    summary="Resume agent execution for the caller's tenant",
    description=(
        "Flips the BehavioralStops ``paused`` flag back to false. Only "
        "clears the marker when the current pause originated from this "
        "endpoint -- pauses set by the tenant-suspend cascade or by an "
        "explicit emergency brake are left alone (footgun avoidance, "
        "matches ``tenant_lifecycle_admin._clear_tenant_execution_pause``)."
    ),
)
async def resume_agents(
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    member_id: str = Depends(get_verified_user_id),
    usage_tracker: UsageTrackerService = Depends(get_usage_tracker),
) -> LiveSpendResponse:
    return _toggle_pause(
        tenant_id=verified_tenant_id,
        member_id=member_id,
        usage_tracker=usage_tracker,
        target_paused=False,
        event_type="billing.agents.resumed",
    )


# ---------------------------------------------------------------------------
# Internal toggle helper
# ---------------------------------------------------------------------------


_PAUSE_REASON_TAG = "member_pause_my_agents"


def _toggle_pause(
    *,
    tenant_id: str,
    member_id: str,
    usage_tracker: UsageTrackerService,
    target_paused: bool,
    event_type: str,
) -> LiveSpendResponse:
    """Persist the pause flip and return the live snapshot.

    Idempotency: when the flag already matches the desired state, the
    persistence layer is *not* touched and no Decision Trace is emitted.
    The response still reflects the canonical state so the frontend can
    settle without a separate GET round-trip.

    Resume safety: only clears the marker when the existing
    ``pause_reason`` is the one this endpoint set (or empty). Pauses set
    by the suspend cascade (``tenant_suspended:*``) or the emergency
    brake (``emergency_brake:*``) are preserved -- the right surfaces to
    resume those live elsewhere.
    """
    stops = dict(get_behavioral_stops(tenant_id))
    current = bool(stops.get("paused"))
    pause_reason = str(stops.get("pause_reason") or "").strip()

    if current == target_paused:
        return _build_live_response(
            tenant_id=tenant_id,
            member_id=member_id,
            usage_tracker=usage_tracker,
            paused=current,
        )

    if not target_paused and pause_reason and pause_reason != _PAUSE_REASON_TAG:
        # Resume request, but the pause was set by a different surface
        # (tenant suspend / emergency brake). Don't clobber it -- return
        # the live state as-is. The frontend treats the still-paused
        # banner as the source of truth.
        logger.info(
            "live_spend.resume_skipped_foreign_pause tenant=%s reason=%s",
            tenant_id,
            pause_reason,
        )
        return _build_live_response(
            tenant_id=tenant_id,
            member_id=member_id,
            usage_tracker=usage_tracker,
            paused=current,
        )

    now = datetime.now(UTC)
    if target_paused:
        stops.update(
            {
                "paused": True,
                "paused_at": now.isoformat(),
                "paused_by": member_id,
                "pause_reason": _PAUSE_REASON_TAG,
            }
        )
    else:
        stops.update(
            {
                "paused": False,
                "paused_at": None,
                "paused_by": None,
                "pause_reason": None,
            }
        )

    try:
        save_behavioral_stops(tenant_id, stops)
    except BehavioralStopsStoreError as exc:
        logger.error(
            "live_spend.persist_failed tenant=%s err=%s",
            tenant_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Could not persist pause state. Please retry.",
        ) from exc

    _emit_decision_trace(
        tenant_id=tenant_id,
        event_type=event_type,
        member_id=member_id,
        payload={"paused": target_paused, "pause_reason": _PAUSE_REASON_TAG},
    )

    return _build_live_response(
        tenant_id=tenant_id,
        member_id=member_id,
        usage_tracker=usage_tracker,
        paused=target_paused,
    )


__all__ = [
    "LiveSpendBreakdownEntry",
    "LiveSpendResponse",
    "router",
    "get_usage_tracker",
]
