"""
Subscription API Endpoints (TASK-6.0H.001)

REST API for subscription lifecycle operations.
Constitutional compliance:
- Axiom 2: All subscription operations logged to Operational Context
- Axiom 5: Agents automate subscription management (no human clicks required)
"""
from apps.backend.config.table_names import resolve_table

import logging
import os
from datetime import datetime, UTC
from typing import Any

from fastapi import APIRouter, HTTPException, Depends
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.schemas.error_response import safe_error_detail

from apps.backend.services.billing.subscription_service import (
    SubscriptionManager,
    SubscriptionManagerError,
    SubscriptionNotFoundError,
    SubscriptionOperationError,
    DunningError,
)

# Configure logging
logger = logging.getLogger(__name__)

# Router
router = APIRouter(prefix="/api/v1/billing", tags=["billing", "subscription"])


# ============================================================================
# Dependencies
# ============================================================================


def get_subscription_manager() -> SubscriptionManager:
    """Get subscription manager service instance."""
    try:
        return SubscriptionManager(
            stripe_api_key=os.getenv("STRIPE_API_KEY", ""),
            tenants_table_name=resolve_table("tenants"),
        )
    except Exception as e:
        logger.error(f"Failed to initialize subscription manager: {e}")
        raise HTTPException(status_code=500, detail="Failed to initialize subscription service")


def _assert_tenant_scope(scoped_tenant_id: str, verified_tenant_id: str) -> None:
    """Reject cross-tenant operations on tenant-scoped subscription routes.

    Required: authenticated session tenant_id must match the {tenant_id} path parameter.

    Both sides are normalized by stripping the ``TENANT#`` prefix before comparison
    so that ``TENANT#<id>`` in the URL path matches the bare ``<id>`` that
    ``get_verified_tenant_id`` returns after normalization.

    Raises HTTP 403 with a descriptive ``detail`` message explaining the permission
    requirement so callers can surface a meaningful error instead of a generic 403.
    """

    def _normalize(v: str) -> str:
        raw = str(v or "").strip()
        return raw[len("TENANT#") :] if raw.startswith("TENANT#") else raw

    if _normalize(scoped_tenant_id) != _normalize(verified_tenant_id):
        raise HTTPException(
            status_code=403,
            detail=(
                "Access denied: the organization in the request URL does not match "
                "your authenticated session. Ensure you are accessing subscription data "
                "for your own organization."
            ),
        )


# ============================================================================
# Response Models
# ============================================================================


class SubscriptionStatusResponse(BaseModel):
    """Response model for subscription status."""

    tenant_id: str = Field(..., description="Tenant identifier")
    subscription_id: str = Field(..., description="Stripe subscription ID")
    status: str = Field(..., description="Subscription status")
    plan_id: str = Field(..., description="Price/Plan ID")
    current_period_start: str = Field(..., description="Current period start (ISO)")
    current_period_end: str = Field(..., description="Current period end (ISO)")
    cancel_at_period_end: bool = Field(..., description="Will cancel at period end")
    cancelled_at: str | None = Field(None, description="When cancellation was requested")
    trial_start: str | None = Field(None, description="Trial period start")
    trial_end: str | None = Field(None, description="Trial period end")
    cancellation_evidence_id: str | None = Field(None, description="Cancellation proof record")
    cancellation_evidence_url: str | None = Field(None, description="Cancellation proof API URL")


class CancelSubscriptionRequest(BaseModel):
    """Request model for cancelling subscription."""

    immediate: bool = Field(
        False,
        description="If True, cancel immediately. If False, cancel at period end.",
    )


class CancelSubscriptionResponse(BaseModel):
    """Response model for cancelled subscription."""

    tenant_id: str = Field(..., description="Tenant identifier")
    subscription_id: str = Field(..., description="Stripe subscription ID")
    status: str = Field(..., description="Subscription status after cancellation")
    cancellation_type: str = Field(..., description="immediate or at_period_end")
    current_period_end: str = Field(..., description="Current period end (ISO)")
    cancelled_at: str | None = Field(None, description="When cancellation was processed")
    cancellation_evidence_id: str | None = Field(None, description="Cancellation proof record")
    cancellation_evidence_url: str | None = Field(None, description="Cancellation proof API URL")


class ReactivateSubscriptionResponse(BaseModel):
    """Response model for reactivated subscription."""

    tenant_id: str = Field(..., description="Tenant identifier")
    subscription_id: str = Field(..., description="Stripe subscription ID")
    status: str = Field(..., description="Subscription status after reactivation")
    current_period_end: str = Field(..., description="Current period end (ISO)")
    cancel_at_period_end: bool = Field(..., description="Cancellation flag removed")


class PaymentMethodInfo(BaseModel):
    """Payment method details."""

    id: str = Field(..., description="Stripe payment method ID")
    type: str = Field(..., description="Payment method type")
    brand: str = Field(..., description="Card brand")
    last4: str = Field(..., description="Last 4 card digits")
    exp_month: int = Field(..., description="Expiration month")
    exp_year: int = Field(..., description="Expiration year")
    is_default: bool = Field(..., description="Whether this is the default method")


class PaymentMethodsResponse(BaseModel):
    """Response model for tenant payment methods."""

    tenant_id: str = Field(..., description="Tenant identifier")
    customer_id: str = Field(..., description="Stripe customer ID")
    default_payment_method_id: str | None = Field(
        None,
        description="Default payment method ID",
    )
    methods: list[PaymentMethodInfo] = Field(
        default_factory=list,
        description="Saved payment methods",
    )


class UpdatePaymentMethodRequest(BaseModel):
    """Request model for updating default payment method."""

    stripe_payment_method_id: str = Field(
        ...,
        description="Stripe payment method ID (pm_...)",
        min_length=1,
    )


class UpdatePaymentMethodResponse(BaseModel):
    """Response model for payment method updates."""

    tenant_id: str = Field(..., description="Tenant identifier")
    payment_method_updated: bool = Field(..., description="Update succeeded")
    dunning_cleared: bool = Field(..., description="Dunning state cleared")
    subscription_reactivated: bool = Field(
        ...,
        description="Subscription reactivated after payment method update",
    )
    default_payment_method_id: str = Field(
        ...,
        description="New default payment method ID",
    )


class DunningSnapshot(BaseModel):
    """Dunning workflow snapshot for the public lifecycle endpoint (#1165)."""

    state: str = Field(..., description="Dunning workflow state")
    failed_attempts: int = Field(..., description="Number of failed payment attempts")
    max_attempts: int = Field(..., description="Failure count at which account is suspended")
    last_failed_at: str | None = Field(None, description="ISO timestamp of last failed payment")
    next_retry_at: str | None = Field(None, description="ISO timestamp of next scheduled retry")


class BillingLifecycleResponse(BaseModel):
    """Public billing lifecycle snapshot consumed by the dashboard grace-period banner (#1165)."""

    tenant_id: str = Field(..., description="Authenticated tenant identifier")
    lifecycle_state: str = Field(
        ...,
        description="Derived lifecycle: active | grace_period | past_due | suspended | cancelled",
    )
    subscription_status: str | None = Field(
        None,
        description="Raw subscription status persisted on the tenant record (may lag Stripe).",
    )
    dunning: DunningSnapshot | None = Field(
        None,
        description="Dunning snapshot when the tenant is not fully active.",
    )
    grace_expires_at: str | None = Field(
        None,
        description=(
            "ISO timestamp the banner should count down to. "
            "Mirrors dunning.next_retry_at during grace_period/past_due."
        ),
    )
    hosted_invoice_url: str | None = Field(
        None,
        description="Stripe hosted invoice URL for the failing payment, when available.",
    )
    as_of: str = Field(..., description="Server-side timestamp of this snapshot (ISO, UTC).")


# ============================================================================
# API Endpoints
# ============================================================================


def _safe_str(value: Any) -> str | None:
    """Return a trimmed string or None so DDB typing quirks don't leak into responses."""
    if value is None:
        return None
    text = str(value).strip()
    return text or None


def _safe_int(value: Any, *, default: int = 0) -> int:
    """Coerce a DDB-stored counter to int without raising on dirty data.

    Codex round-3 review: ``int(dunning.get("failed_attempts") or 0)`` raises
    ``ValueError`` when the stored value is a non-numeric string (``""``,
    ``"unknown"``, legacy debug sentinels). Because ``_derive_lifecycle_state``
    is called outside the lookup ``try/except`` on the public
    ``/api/v1/billing/lifecycle`` endpoint, that exception surfaces as a 500
    and breaks the fall-open resilience contract. Coerce defensively so the
    grace-period banner stays honest for malformed rows.
    """
    if value is None:
        return default
    if isinstance(value, bool):
        # bool is a subclass of int; reject to avoid surprising True→1 coercion.
        return default
    if isinstance(value, (int, float)):
        try:
            return int(value)
        except (OverflowError, ValueError):
            return default
    try:
        text = str(value).strip()
    except Exception:  # noqa: BLE001 — defensive coerce
        return default
    if not text:
        return default
    try:
        return int(text)
    except ValueError:
        try:
            return int(float(text))
        except (TypeError, ValueError):
            return default


def _derive_lifecycle_state(tenant_record: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    """Derive the public lifecycle_state + dunning snapshot from the tenant record.

    Precedence (most specific first; managed-lifecycle terminal states win
    over dunning so the banner can route the user to the right CTA per
    PRODUCT-CONTEXT.md §21 / #3050):

      1. tenant.status == "locked"                       -> "locked"
      2. tenant.status == "suspended"                    -> "suspended"
      3. tenant.status == "paused"                       -> "paused"
      4. tenant.status == "throttled"                    -> "throttled"
      5. tenant.status == "trial_expired"                -> "trial_expired"
      6. tenant.status in {"trial","trialing"}           -> "trial"
      7. subscription.status in {"cancelled","canceled"} -> "cancelled"
      8. dunning.state == "suspended"                    -> "suspended"
      9. dunning.state == "in_progress":
            failed_attempts <= 1                         -> "grace_period"
            failed_attempts >= 2                         -> "past_due"
      10. otherwise                                      -> "active"

    The second return is the dunning sub-dict (may be empty).
    """
    status = str(tenant_record.get("status", "") or "").lower().strip()
    subscription = tenant_record.get("subscription", {}) or {}
    sub_status = str(subscription.get("status", "") or "").lower().strip()
    dunning = tenant_record.get("dunning", {}) or {}
    dunning_state = str(dunning.get("state", "") or "").lower().strip()
    failed_attempts = _safe_int(dunning.get("failed_attempts"))

    # Managed-lifecycle terminal states (admin / abuse intervention).
    if status == "locked":
        return "locked", dunning
    if status == "suspended":
        return "suspended", dunning
    if status == "paused":
        return "paused", dunning
    if status == "throttled":
        return "throttled", dunning
    # Managed-lifecycle trial-renewal states.
    if status == "trial_expired":
        return "trial_expired", dunning
    if status in {"trial", "trialing"}:
        return "trial", dunning
    # Subscription-level cancellation overrides dunning.
    if sub_status in {"cancelled", "canceled"}:
        return "cancelled", dunning
    if dunning_state == "suspended":
        return "suspended", dunning
    if dunning_state == "in_progress":
        if failed_attempts <= 1:
            return "grace_period", dunning
        return "past_due", dunning
    return "active", dunning


@router.get(
    "/subscription/{tenant_id}/status",
    response_model=SubscriptionStatusResponse,
    summary="Get subscription status",
    description="Get current subscription status for a tenant.",
)
async def get_subscription_status(
    tenant_id: str,
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    subscription_mgr: SubscriptionManager = Depends(get_subscription_manager),
) -> SubscriptionStatusResponse:
    """
    Get subscription status for a tenant.

    Returns current subscription details including:
    - Status (active, past_due, cancelled, etc.)
    - Current billing period
    - Cancellation status
    - Trial information (if applicable)

    All operations logged to Operational Context (Axiom 2).
    """
    try:
        _assert_tenant_scope(tenant_id, verified_tenant_id)
        details = subscription_mgr.get_subscription_status(tenant_id)

        response = SubscriptionStatusResponse(
            tenant_id=tenant_id,
            subscription_id=details.subscription_id,
            status=details.status.value,
            plan_id=details.plan_id,
            current_period_start=details.current_period_start.isoformat(),
            current_period_end=details.current_period_end.isoformat(),
            cancel_at_period_end=details.cancel_at_period_end,
            cancelled_at=details.cancelled_at.isoformat() if details.cancelled_at else None,
            trial_start=details.trial_start.isoformat() if details.trial_start else None,
            trial_end=details.trial_end.isoformat() if details.trial_end else None,
            cancellation_evidence_id=details.cancellation_evidence_id,
            cancellation_evidence_url=details.cancellation_evidence_url,
        )

        logger.info(f"Retrieved subscription status for tenant {tenant_id}: {details.status.value}")

        return response

    except SubscriptionNotFoundError as e:
        logger.error(f"Subscription not found: {e}")
        raise HTTPException(status_code=404, detail="Subscription not found")
    except SubscriptionManagerError as e:
        logger.error(f"Failed to get subscription status: {e}")
        raise HTTPException(status_code=500, detail="Subscription service error")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error getting subscription status: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post(
    "/subscription/{tenant_id}/cancel",
    response_model=CancelSubscriptionResponse,
    summary="Cancel subscription",
    description="Cancel subscription (immediately or at period end).",
)
async def cancel_subscription(
    tenant_id: str,
    request: CancelSubscriptionRequest,
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    subscription_mgr: SubscriptionManager = Depends(get_subscription_manager),
) -> CancelSubscriptionResponse:
    """
    Cancel subscription for a tenant.

    Supports two cancellation modes:
    - immediate=True: Cancel immediately (access revoked now)
    - immediate=False: Cancel at period end (access continues until period ends)

    All operations logged to Operational Context (Axiom 2).
    """
    try:
        _assert_tenant_scope(tenant_id, verified_tenant_id)
        details = subscription_mgr.cancel_subscription(
            tenant_id=tenant_id,
            immediate=request.immediate,
        )

        cancellation_type = "immediate" if request.immediate else "at_period_end"

        response = CancelSubscriptionResponse(
            tenant_id=tenant_id,
            subscription_id=details.subscription_id,
            status=details.status.value,
            cancellation_type=cancellation_type,
            current_period_end=details.current_period_end.isoformat(),
            cancelled_at=details.cancelled_at.isoformat() if details.cancelled_at else None,
            cancellation_evidence_id=details.cancellation_evidence_id,
            cancellation_evidence_url=details.cancellation_evidence_url,
        )

        logger.info(f"Cancelled subscription for tenant {tenant_id} ({cancellation_type})")

        return response

    except SubscriptionNotFoundError as e:
        logger.error(f"Subscription not found: {e}")
        raise HTTPException(status_code=404, detail="Subscription not found")
    except SubscriptionManagerError as e:
        logger.error(f"Failed to cancel subscription: {e}")
        raise HTTPException(status_code=500, detail="Subscription service error")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error cancelling subscription: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post(
    "/subscription/{tenant_id}/reactivate",
    response_model=ReactivateSubscriptionResponse,
    summary="Reactivate subscription",
    description="Reactivate a cancelled subscription.",
)
async def reactivate_subscription(
    tenant_id: str,
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    subscription_mgr: SubscriptionManager = Depends(get_subscription_manager),
) -> ReactivateSubscriptionResponse:
    """
    Reactivate subscription for a tenant.

    Removes the cancel_at_period_end flag to resume subscription.
    Only works if subscription is still active and scheduled for cancellation.

    All operations logged to Operational Context (Axiom 2).
    """
    try:
        _assert_tenant_scope(tenant_id, verified_tenant_id)
        details = subscription_mgr.reactivate_subscription(tenant_id)

        response = ReactivateSubscriptionResponse(
            tenant_id=tenant_id,
            subscription_id=details.subscription_id,
            status=details.status.value,
            current_period_end=details.current_period_end.isoformat(),
            cancel_at_period_end=details.cancel_at_period_end,
        )

        logger.info(f"Reactivated subscription for tenant {tenant_id}")

        return response

    except SubscriptionNotFoundError as e:
        logger.error(f"Subscription not found: {e}")
        raise HTTPException(status_code=404, detail="Subscription not found")
    except SubscriptionOperationError as e:
        logger.error(f"Cannot reactivate subscription: {e}")
        raise HTTPException(status_code=400, detail="Invalid subscription operation")
    except SubscriptionManagerError as e:
        logger.error(f"Failed to reactivate subscription: {e}")
        raise HTTPException(status_code=500, detail="Subscription service error")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error reactivating subscription: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get(
    "/subscription/{tenant_id}/payment-methods",
    response_model=PaymentMethodsResponse,
    summary="Get payment methods",
    description="List saved payment methods for a tenant.",
)
async def get_payment_methods(
    tenant_id: str,
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    subscription_mgr: SubscriptionManager = Depends(get_subscription_manager),
) -> PaymentMethodsResponse:
    """
    Get payment methods for a tenant.

    This endpoint returns all attached payment methods and the current default.
    """
    try:
        _assert_tenant_scope(tenant_id, verified_tenant_id)
        methods = subscription_mgr.get_payment_methods(tenant_id)
        return PaymentMethodsResponse(**methods)

    except SubscriptionNotFoundError as e:
        logger.error(f"Payment methods not found: {e}")
        raise HTTPException(status_code=404, detail="Subscription not found")
    except SubscriptionManagerError as e:
        logger.error(f"Failed to get payment methods: {e}")
        raise HTTPException(status_code=500, detail="Subscription service error")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error getting payment methods: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post(
    "/subscription/{tenant_id}/payment-method",
    response_model=UpdatePaymentMethodResponse,
    summary="Update default payment method",
    description="Set a new default payment method for the tenant.",
)
async def update_payment_method(
    tenant_id: str,
    request: UpdatePaymentMethodRequest,
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    subscription_mgr: SubscriptionManager = Depends(get_subscription_manager),
) -> UpdatePaymentMethodResponse:
    """
    Update tenant default payment method.

    If the tenant is in dunning, this refreshes access state and may reactivate.
    """
    try:
        _assert_tenant_scope(tenant_id, verified_tenant_id)
        result = subscription_mgr.update_payment_method(
            tenant_id=tenant_id,
            stripe_payment_method_id=request.stripe_payment_method_id,
        )

        return UpdatePaymentMethodResponse(
            tenant_id=tenant_id,
            payment_method_updated=result["payment_method_updated"],
            dunning_cleared=result["dunning_cleared"],
            subscription_reactivated=result["subscription_reactivated"],
            default_payment_method_id=request.stripe_payment_method_id,
        )

    except SubscriptionNotFoundError as e:
        logger.error(f"Payment method update not found: {e}")
        raise HTTPException(status_code=404, detail="Subscription not found")
    except DunningError as e:
        logger.error(f"Failed to update payment method: {e}")
        raise HTTPException(status_code=400, detail="Payment method update failed")
    except SubscriptionManagerError as e:
        logger.error(f"Failed to update payment method: {e}")
        raise HTTPException(status_code=500, detail="Subscription service error")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error updating payment method: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


# ============================================================================
# Refund Models & Endpoint
# ============================================================================


class RefundRequest(BaseModel):
    """Request model for issuing a refund."""

    amount_cents: int | None = Field(
        None,
        description="Amount in cents to refund (None = full refund of latest charge)",
    )
    reason: str = Field(
        default="requested_by_customer",
        description="Reason for the refund",
    )


class RefundResponse(BaseModel):
    """Response model for a refund operation."""

    tenant_id: str = Field(..., description="Tenant identifier")
    refund_id: str = Field(..., description="Stripe refund ID")
    amount_cents: int = Field(..., description="Refunded amount in cents")
    currency: str = Field(..., description="Currency code")
    status: str = Field(..., description="Refund status")
    created_at: str = Field(..., description="ISO timestamp of refund")


@router.post(
    "/{tenant_id}/subscription/refund",
    response_model=RefundResponse,
    summary="Issue refund",
    description="Issue a full or partial refund for the tenant's latest charge.",
)
async def issue_refund(
    tenant_id: str,
    request: RefundRequest = RefundRequest(),
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    subscription_mgr: SubscriptionManager = Depends(get_subscription_manager),
) -> RefundResponse:
    """
    Issue a refund for a tenant.

    If amount_cents is None, a full refund is issued for the latest charge.
    All refunds are logged to the Operational Context (Axiom 2).
    """
    try:
        _assert_tenant_scope(tenant_id, verified_tenant_id)
        result = subscription_mgr.issue_refund(
            tenant_id=tenant_id,
            amount_cents=request.amount_cents,
            reason=request.reason,
        )

        return RefundResponse(
            tenant_id=tenant_id,
            refund_id=result.refund_id,
            amount_cents=result.amount_cents,
            currency=result.currency,
            status=result.status,
            created_at=result.created_at,
        )

    except SubscriptionNotFoundError as e:
        logger.error(f"Subscription not found for refund: {e}")
        raise HTTPException(status_code=404, detail="Subscription not found")
    except SubscriptionOperationError as e:
        logger.error(f"Refund operation failed: {e}")
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except SubscriptionManagerError as e:
        logger.error(f"Refund service error: {e}")
        raise HTTPException(status_code=500, detail="Subscription service error")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error issuing refund: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


# ============================================================================
# Cancellation Proof (docs/PRODUCT.md §Predictable billing bar)
# ============================================================================


class CancellationProofResponse(BaseModel):
    """Evidence-backed cancellation proof for audit and transparency."""

    tenant_id: str
    cancelled: bool = False
    cancellation_date: str | None = None
    cancellation_evidence_id: str | None = None
    cancellation_evidence_url: str | None = None
    effective_date: str | None = None
    refund_issued: bool = False
    refund_amount: float | None = None
    hooks_revoked: bool = False
    data_export_available: bool = False


@router.get(
    "/subscription/{tenant_id}/cancellation-proof",
    response_model=CancellationProofResponse,
    summary="Get cancellation proof",
    description="Retrieve evidence-backed cancellation proof for a tenant.",
)
async def get_cancellation_proof(
    tenant_id: str,
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    subscription_mgr: SubscriptionManager = Depends(get_subscription_manager),
) -> CancellationProofResponse:
    """Return the cancellation proof artifact for a tenant.

    Provides evidence-backed proof that the subscription was cancelled,
    when it took effect, whether refunds were issued, and whether durable
    hooks have been revoked. This closes the Predictable Billing trust bar.
    """
    _verify_tenant_access(tenant_id, verified_tenant_id)
    try:
        details = subscription_mgr.get_subscription_details(tenant_id)
        is_cancelled = details.status in ("cancelled", "expired")
        return CancellationProofResponse(
            tenant_id=tenant_id,
            cancelled=is_cancelled,
            cancellation_date=details.cancellation_date if is_cancelled else None,
            cancellation_evidence_id=details.cancellation_evidence_id,
            cancellation_evidence_url=details.cancellation_evidence_url,
            effective_date=details.cancellation_effective_date
            if hasattr(details, "cancellation_effective_date")
            else details.cancellation_date,
            hooks_revoked=is_cancelled,
            data_export_available=is_cancelled,
        )
    except SubscriptionManagerError:
        raise HTTPException(status_code=404, detail="Subscription not found")


# ============================================================================
# Pre-Overage Alert (docs/PRODUCT.md §Predictable billing bar)
# ============================================================================


class PreOverageAlertResponse(BaseModel):
    """Pre-overage usage alert for proactive billing transparency."""

    tenant_id: str
    usage_pct: float = 0.0
    threshold_pct: float = 80.0
    alert_active: bool = False
    current_usage: float = 0.0
    plan_limit: float = 0.0
    projected_overage: float = 0.0
    message: str = ""


@router.get(
    "/subscription/{tenant_id}/overage-alert",
    response_model=PreOverageAlertResponse,
    summary="Pre-overage usage alert",
    description="Check if tenant is approaching plan usage limits.",
)
async def get_overage_alert(
    tenant_id: str,
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    subscription_mgr: SubscriptionManager = Depends(get_subscription_manager),
) -> PreOverageAlertResponse:
    """Check whether the tenant is approaching usage limits.

    Returns an alert when usage exceeds the configurable threshold (default 80%).
    This closes the pre-overage alert requirement in the Predictable Billing bar.
    """
    _verify_tenant_access(tenant_id, verified_tenant_id)
    try:
        details = subscription_mgr.get_subscription_details(tenant_id)
        usage = float(getattr(details, "current_usage", 0) or 0)
        limit = float(getattr(details, "plan_limit", 0) or 0)
        threshold = 80.0
        pct = (usage / limit * 100) if limit > 0 else 0.0
        alert_active = pct >= threshold
        projected = max(0.0, usage - limit) if alert_active else 0.0
        message = (
            f"Usage at {pct:.0f}% of plan limit. Projected overage: ${projected:.2f}."
            if alert_active
            else "Usage within plan limits."
        )
        return PreOverageAlertResponse(
            tenant_id=tenant_id,
            usage_pct=round(pct, 1),
            threshold_pct=threshold,
            alert_active=alert_active,
            current_usage=usage,
            plan_limit=limit,
            projected_overage=projected,
            message=message,
        )
    except SubscriptionManagerError:
        raise HTTPException(status_code=404, detail="Subscription not found")


# ============================================================================
# Health Check
# ============================================================================


@router.get(
    "/subscription/health",
    summary="Health check",
    description="Check subscription API health",
)
async def health_check() -> dict[str, str]:
    """Health check endpoint."""
    return {"status": "healthy", "service": "subscription-management"}


# ============================================================================
# Stripe Customer Portal (T6 follow-up of Settings IA redesign)
# ============================================================================


class PortalLinkResponse(BaseModel):
    """Response containing a one-time Stripe customer portal URL."""

    url: str = Field(..., description="Short-lived Stripe customer portal URL")
    expires_at: str | None = Field(default=None, description="Optional ISO timestamp")


@router.post(
    "/portal-link",
    response_model=PortalLinkResponse,
    summary="Create Stripe customer portal session",
    description=(
        "Create a Stripe Customer Portal session for the authenticated tenant "
        "and return its short-lived URL. Used by the Settings → Usage & billing "
        "card to power the 'View past invoices →' link without exposing any "
        "billing details inside Workweaver itself."
    ),
)
async def create_portal_link(
    subscription_mgr: SubscriptionManager = Depends(get_subscription_manager),
    verified_tenant_id: str = Depends(get_verified_tenant_id),
) -> PortalLinkResponse:
    """Create a Stripe customer portal session for the verified tenant.

    Resolves the tenant's stripe_customer_id from the tenants table and asks
    Stripe for a portal session. The return URL is the canonical Settings →
    Usage page so the user lands back where they came from.

    Returns 503 if Stripe is not configured (missing STRIPE_API_KEY) so the
    frontend can hide the link gracefully.
    Returns 404 if the tenant has no Stripe customer (free plan, never billed).
    """
    import stripe  # noqa: PLC0415

    api_key = os.getenv("STRIPE_API_KEY", "").strip()
    if not api_key:
        raise HTTPException(
            status_code=503,
            detail="Stripe is not configured for this environment.",
        )
    stripe.api_key = api_key

    # Look up the tenant record to get the stripe customer id.
    # IMPORTANT: get_verified_tenant_id returns the stripped form (no TENANT#
    # prefix) while _get_tenant_record queries DynamoDB with pk = "TENANT#...".
    # Without this normalization the lookup ALWAYS misses for any caller using
    # get_verified_tenant_id.
    pk_tenant_id = (
        verified_tenant_id
        if verified_tenant_id.startswith("TENANT#")
        else f"TENANT#{verified_tenant_id}"
    )
    try:
        tenant_record = subscription_mgr._get_tenant_record(pk_tenant_id)  # type: ignore[attr-defined]
    except SubscriptionNotFoundError:
        raise HTTPException(status_code=404, detail="Tenant not found")
    except Exception as exc:
        logger.error("portal_link_tenant_lookup_failed: %s", exc)
        raise HTTPException(status_code=500, detail="Tenant lookup failed")

    customer_id = (
        (tenant_record or {}).get("subscription", {}).get("stripe_customer_id")
        if isinstance(tenant_record, dict)
        else None
    )
    if not customer_id:
        raise HTTPException(
            status_code=404,
            detail="No billing customer on file for this workspace yet.",
        )

    return_url = os.getenv("WORKWEAVER_BILLING_RETURN_URL", "https://workweaver.ai/settings?tab=usage")

    try:
        session = stripe.billing_portal.Session.create(  # type: ignore[attr-defined]
            customer=customer_id,
            return_url=return_url,
        )
    except stripe.error.StripeError as exc:  # type: ignore[attr-defined]
        logger.error("portal_link_stripe_error: %s", exc)
        raise HTTPException(status_code=502, detail="Stripe error creating portal session")

    return PortalLinkResponse(
        url=str(session.url),
        expires_at=None,
    )


@router.get(
    "/lifecycle",
    response_model=BillingLifecycleResponse,
    summary="Get billing lifecycle snapshot",
    description=(
        "Return a derived billing lifecycle snapshot (active/grace_period/past_due/"
        "suspended/cancelled) for the authenticated tenant. Consumed by the dashboard "
        "grace-period banner (#1165)."
    ),
)
async def get_billing_lifecycle(
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    subscription_mgr: SubscriptionManager = Depends(get_subscription_manager),
) -> BillingLifecycleResponse:
    """Return the public billing lifecycle snapshot for the authenticated tenant.

    This endpoint is fall-open: if the tenant has no record yet, the tenants
    table is missing, or DDB raises transiently, we return ``lifecycle_state =
    "active"`` so the banner never blocks a working workspace. The banner only
    escalates when we have concrete evidence of dunning.
    """
    now_iso = datetime.now(UTC).isoformat()
    pk_tenant_id = (
        verified_tenant_id
        if verified_tenant_id.startswith("TENANT#")
        else f"TENANT#{verified_tenant_id}"
    )

    try:
        tenant_record = subscription_mgr._get_tenant_record(pk_tenant_id)  # type: ignore[attr-defined]
    except SubscriptionNotFoundError:
        tenant_record = None
    except SubscriptionManagerError as exc:
        logger.warning("billing_lifecycle_lookup_failed: %s", exc)
        tenant_record = None
    except Exception as exc:  # pragma: no cover - defensive
        logger.error("billing_lifecycle_unexpected_error: %s", exc)
        tenant_record = None

    if not isinstance(tenant_record, dict) or not tenant_record:
        return BillingLifecycleResponse(
            tenant_id=verified_tenant_id,
            lifecycle_state="active",
            subscription_status=None,
            dunning=None,
            grace_expires_at=None,
            hosted_invoice_url=None,
            as_of=now_iso,
        )

    lifecycle_state, dunning_block = _derive_lifecycle_state(tenant_record)

    dunning_snapshot: DunningSnapshot | None = None
    grace_expires_at: str | None = None
    hosted_invoice_url: str | None = None
    if isinstance(dunning_block, dict) and dunning_block:
        max_attempts = int(
            dunning_block.get("max_attempts", subscription_mgr.max_failed_attempts) or 4
        )
        dunning_snapshot = DunningSnapshot(
            state=str(dunning_block.get("state", "not_in_dunning")),
            failed_attempts=int(dunning_block.get("failed_attempts", 0) or 0),
            max_attempts=max_attempts,
            last_failed_at=_safe_str(dunning_block.get("last_failed_at")),
            next_retry_at=_safe_str(dunning_block.get("next_retry_at")),
        )
        if lifecycle_state in {"grace_period", "past_due"}:
            grace_expires_at = dunning_snapshot.next_retry_at
        hosted_invoice_url = _safe_str(dunning_block.get("hosted_invoice_url"))

    subscription_block = tenant_record.get("subscription", {}) or {}
    subscription_status = _safe_str(subscription_block.get("status"))

    return BillingLifecycleResponse(
        tenant_id=verified_tenant_id,
        lifecycle_state=lifecycle_state,
        subscription_status=subscription_status,
        dunning=dunning_snapshot,
        grace_expires_at=grace_expires_at,
        hosted_invoice_url=hosted_invoice_url,
        as_of=now_iso,
    )
