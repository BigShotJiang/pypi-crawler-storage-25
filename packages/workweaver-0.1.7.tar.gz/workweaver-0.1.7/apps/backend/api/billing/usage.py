"""
Usage API Endpoints (TASK-6.0F.001)

REST API for tracking and querying tenant usage metrics.
Constitutional compliance:
- Axiom 2: All usage events logged to Operational Context
- Axiom 5: Agents automate usage tracking (no human clicks required)
"""

import logging
import csv
from io import StringIO
from decimal import Decimal
from typing import Any
from datetime import datetime, UTC

from fastapi import APIRouter, HTTPException, Depends, Query, Path, Request, Response, status
from pydantic import BaseModel, Field, field_validator

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.billing.catalog import BillingCatalogService, canonicalize_workweaver_plan
from apps.backend.services.billing.entitlements import BillingEntitlementResolver
from apps.backend.services.billing.read_models import BillingReadModelService

from apps.backend.services.usage_tracker import (
    UsageTrackerService,
    UsageMetricType,
    TIER_LIMITS,
    UsageTrackerError,
    UsageAggregationError,
    BatchUsageTrackerError,
)

# Configure logging
logger = logging.getLogger(__name__)

# Router
router = APIRouter(prefix="/api/v1/billing", tags=["billing", "usage"])
_SUPPORTED_TIER_QUERY_VALUES = frozenset({"trial", "paid", "professional", "launchpad", "growth", "enterprise"})


# ============================================================================
# Dependencies
# ============================================================================


def get_usage_tracker() -> UsageTrackerService:
    """Get usage tracker service instance."""
    return UsageTrackerService()


def get_billing_read_models() -> BillingReadModelService:
    return BillingReadModelService()


def get_billing_entitlements() -> BillingEntitlementResolver:
    return BillingEntitlementResolver()


def _assert_tenant_scope(scoped_tenant_id: str, verified_tenant_id: str) -> None:
    """Reject cross-tenant operations on tenant-scoped billing routes.

    Required: authenticated session tenant must match the tenant_id in the URL path.

    Both sides are normalized by stripping the ``TENANT#`` prefix before comparison
    so that ``TENANT#<id>`` in the URL path matches the bare ``<id>`` that
    ``get_verified_tenant_id`` returns after normalization.

    Raises HTTP 403 with a descriptive ``detail`` message explaining the permission
    requirement so callers can surface a meaningful error instead of a generic 403.
    """

    def _normalize(v: str) -> str:
        raw = str(v or "").strip()
        return raw[len("TENANT#") :] if raw.startswith("TENANT#") else raw

    if _normalize(scoped_tenant_id) != _normalize(verified_tenant_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                "Access denied: the organization in the request URL does not match "
                "your authenticated session. Ensure you are accessing billing data "
                "for your own organization."
            ),
        )


def _resolve_tier_override(tier: str | None) -> tuple[str | None, str | None]:
    if tier is None:
        return None, None
    requested = str(tier).strip().lower()
    if requested not in _SUPPORTED_TIER_QUERY_VALUES:
        raise HTTPException(status_code=400, detail="Unsupported tier")
    return requested, canonicalize_workweaver_plan(requested)


def _resolve_usage_limits_surface(
    *,
    tenant_id: str,
    tier: str | None,
    entitlements: BillingEntitlementResolver,
) -> tuple[str, dict[str, Any], dict[str, Any]]:
    requested_tier, canonical_tier = _resolve_tier_override(tier)
    if canonical_tier is None:
        snapshot = entitlements.resolve(tenant_id)
        hard_limits = dict(snapshot.hard_limits)
        included_quantities = dict(snapshot.included_quantities)
        return snapshot.plan_tier, hard_limits, included_quantities

    if requested_tier in TIER_LIMITS:
        legacy_limits = TIER_LIMITS[requested_tier]
        hard_limits = {metric.value: quantity for metric, quantity in legacy_limits.items()}
        return requested_tier, hard_limits, {}

    catalog = BillingCatalogService()
    hard_limits = catalog.resolve_hard_limits(tenant_id, canonical_tier)
    included_quantities = catalog.resolve_included_quantities(canonical_tier)
    return requested_tier or canonical_tier, hard_limits, included_quantities


# ============================================================================
# Request/Response Models
# ============================================================================


class RecordUsageRequest(BaseModel):
    """Request model for recording a usage event."""

    tenant_id: str = Field(
        ...,
        description="Tenant identifier",
        min_length=1,
        max_length=128,
        pattern=r"^TENANT#[A-Za-z0-9_-]+$",
    )
    metric_type: UsageMetricType = Field(..., description="Type of usage metric being recorded")
    quantity: Decimal = Field(..., gt=0, description="Amount of usage (must be positive)")
    unit: str = Field(..., description="Unit of measurement (e.g., 'minutes', 'messages')")
    metadata: dict[str, Any] | None = Field(None, description="Additional event metadata")
    actor_id: str | None = Field(
        None,
        description="Member or system actor attributed to this usage. "
        "When omitted the authenticated user from the session context is used; "
        "if no session user is available the event is attributed to 'tenant_registrar'.",
        min_length=1,
        max_length=256,
    )
    idempotency_key: str | None = Field(
        None,
        description="Optional deduplication key for safe retries",
        min_length=3,
        max_length=128,
    )
    timestamp: str | None = Field(
        None,
        description="Event timestamp in ISO format (defaults to now)",
    )

    @field_validator("timestamp")
    @classmethod
    def validate_timestamp(cls, v):
        """Validate and parse timestamp if provided."""
        if v is None:
            return None
        try:
            datetime.fromisoformat(v.replace("Z", "+00:00"))
            return v
        except ValueError:
            raise ValueError("timestamp must be a valid ISO 8601 datetime")


class UsageEventResponse(BaseModel):
    """Response model for a recorded usage event."""

    PK: str = Field(..., description="Partition key (tenant + billing period)")
    SK: str = Field(..., description="Sort key (metric + event ID)")
    tenant_id: str = Field(..., description="Tenant identifier")
    metric_type: str = Field(..., description="Type of metric")
    quantity: Decimal = Field(..., description="Amount of usage")
    unit: str = Field(..., description="Unit of measurement")
    timestamp: str = Field(..., description="Event timestamp")
    metadata: dict[str, Any] = Field(default_factory=dict, description="Event metadata")
    actor_id: str = Field(default="tenant_registrar", description="Member or system actor attributed to this usage")
    attribution_source: str = Field(default="backfill", description="event or backfill")


class MetricSummary(BaseModel):
    """Summary for a single metric type."""

    total_quantity: Decimal = Field(..., description="Total quantity for this metric")
    unit: str = Field(..., description="Unit of measurement")
    event_count: int = Field(..., description="Number of events recorded")


class UsageSummaryResponse(BaseModel):
    """Response model for usage summary."""

    tenant_id: str = Field(..., description="Tenant identifier")
    year: int = Field(..., description="Billing period year")
    month: str = Field(..., description="Billing period month (zero-padded)")
    period_start: str = Field(..., description="Period start timestamp")
    period_end: str = Field(..., description="Period end timestamp")
    metrics: dict[str, MetricSummary] = Field(default_factory=dict, description="Usage by metric type")


class UsageHistoryResponse(BaseModel):
    """Response model for usage history."""

    tenant_id: str = Field(..., description="Tenant identifier")
    history: list[UsageSummaryResponse] = Field(..., description="List of monthly usage summaries")


class BatchRecordUsageRequest(BaseModel):
    """Request model for batch recording usage events."""

    events: list[RecordUsageRequest] = Field(..., min_length=1, max_length=100, description="List of usage events")


class BatchRecordUsageResponse(BaseModel):
    """Response model for batch recording usage events."""

    recorded: int = Field(..., description="Number of events successfully recorded")
    failed: int = Field(..., description="Number of events that failed")
    events: list[UsageEventResponse] = Field(..., description="List of recorded events")


class MetricLimitStatus(BaseModel):
    """Usage and limit status for a metric."""

    limit: Decimal = Field(..., description="Tier limit for the metric")
    used: Decimal = Field(..., description="Current period usage")
    remaining: Decimal = Field(..., description="Remaining allowance")
    percent_used: Decimal = Field(..., description="Percent of limit consumed")


class UsageLimitsResponse(BaseModel):
    """Response model for usage limits."""

    tenant_id: str = Field(..., description="Tenant identifier")
    tier: str = Field(..., description="Billing tier")
    year: int = Field(..., description="Billing period year")
    month: str = Field(..., description="Billing period month (zero-padded)")
    limits: dict[str, MetricLimitStatus] = Field(..., description="Per-metric limit and consumption")


class UsageAlertResponseItem(BaseModel):
    """Budget alert entry for one metric threshold."""

    threshold_pct: int = Field(..., description="Threshold percentage")
    metric: str = Field(..., description="Metric identifier")
    current_usage: Decimal = Field(..., description="Current usage for the metric")
    limit: Decimal = Field(..., description="Tier limit for the metric")
    breached: bool = Field(..., description="Whether threshold is breached")
    soft_block: bool = Field(False, description="Whether a soft block should apply")


class UsageAlertsResponse(BaseModel):
    """Response model for usage alerts."""

    tenant_id: str = Field(..., description="Tenant identifier")
    tier: str = Field(..., description="Billing tier")
    year: int = Field(..., description="Billing period year")
    month: str = Field(..., description="Billing period month (zero-padded)")
    alerts: list[UsageAlertResponseItem] = Field(..., description="Threshold alerts for the billing period")


class TenantBillingMetricBreakdown(BaseModel):
    raw_quantity: str
    included_quantity: str
    overage_quantity: str
    amount_usd: str
    cogs_usd: str
    label: str
    quantity_hours: str | None = None


class TenantBillingAdjustmentSummary(BaseModel):
    adjustment_id: str
    kind: str
    amount_usd: str
    reason: str
    created_at: str
    created_by: str
    metric_name: str | None = None
    note: str | None = None
    evidence_url: str | None = None
    status: str


class TenantBillingReconciliationSummary(BaseModel):
    provider: str
    status: str
    variance_count: int
    reconciled_at: str | None = None


class TenantBillingWorkspaceResponse(BaseModel):
    tenant_id: str
    plan_tier: str
    currency: str
    year: int
    month: int
    plan_fee_usd: str
    projected_usage_usd: str
    adjustment_total_usd: str
    projected_cogs_usd: str
    projected_bill_usd: str
    projected_margin_usd: str
    included_quantities: dict[str, str]
    invoice_totals: dict[str, Decimal]
    metric_breakdown: dict[str, TenantBillingMetricBreakdown]
    adjustments: list[TenantBillingAdjustmentSummary] = Field(default_factory=list)
    reconciliation: list[TenantBillingReconciliationSummary] = Field(default_factory=list)


def _resolve_period(
    year: int | None,
    month: int | None,
) -> tuple[int, int]:
    """Resolve explicit year/month or default to current UTC period."""
    now = datetime.now(UTC)
    return (year or now.year, month or now.month)


def _build_metric_usage(summary: dict[str, Any]) -> dict[UsageMetricType, Decimal]:
    """Map summary metrics to UsageMetricType for tier checks."""
    metric_usage: dict[UsageMetricType, Decimal] = {}
    metrics = summary.get("metrics", {})
    for metric_type in UsageMetricType:
        metric_data = metrics.get(metric_type.value, {})
        try:
            metric_usage[metric_type] = Decimal(str(metric_data.get("total_quantity", 0)))
        except (TypeError, ValueError):
            metric_usage[metric_type] = Decimal("0")
    return metric_usage


def _build_usage_csv(summary: dict[str, Any]) -> str:
    """Serialize usage summary to CSV."""
    buffer = StringIO()
    writer = csv.writer(buffer)
    writer.writerow(["tenant_id", "year", "month", "metric_type", "total_quantity", "unit", "event_count"])

    for metric_type, data in sorted(summary.get("metrics", {}).items()):
        writer.writerow(
            [
                summary.get("tenant_id", ""),
                summary.get("year", ""),
                summary.get("month", ""),
                metric_type,
                data.get("total_quantity", 0),
                data.get("unit", ""),
                data.get("event_count", 0),
            ]
        )

    invoice_totals = summary.get("invoice_totals")
    if isinstance(invoice_totals, dict):
        writer.writerow([])
        writer.writerow(["invoice_total", "value"])
        for key, value in sorted(invoice_totals.items()):
            writer.writerow([key, value])

    return buffer.getvalue()


# ============================================================================
# Actor resolution helpers
# ============================================================================


def _resolve_actor_id(request: Request, explicit_actor_id: str | None = None) -> str | None:
    """Resolve the actor_id for a metering event.

    Priority:
    1. ``user_id`` from the authenticated session context (request.state).
       Authenticated identity always wins to prevent billing attribution spoofing.
    2. Explicit ``actor_id`` provided by the caller — only used when no
       authenticated user is present (e.g. service-to-service calls).
    3. ``None`` (falls through to ``tenant_registrar`` in the service layer).

    Returns:
        The resolved actor identifier, or ``None`` when no attribution source
        is available (service layer will apply the ``tenant_registrar`` fallback).
    """
    auth_user_id = str(getattr(request.state, "user_id", "") or "").strip()
    if auth_user_id:
        return auth_user_id
    if explicit_actor_id:
        return explicit_actor_id
    return None


# ============================================================================
# API Endpoints
# ============================================================================


@router.post(
    "/usage/record",
    response_model=UsageEventResponse,
    status_code=201,
    summary="Record a usage event",
    description="Record a single usage event for a tenant. Automatically logs to Operational Context for audit trail.",
)
async def record_usage(
    body: RecordUsageRequest,
    http_request: Request,
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    usage_tracker: UsageTrackerService = Depends(get_usage_tracker),
) -> UsageEventResponse:
    """
    Record a usage event for a tenant.

    This endpoint is called by platform services to track usage:
    - Voice services: track call minutes
    - WhatsApp service: track messages sent/received
    - Email service: track emails sent/received
    - Skill executor: track skill executions

    All events are logged to Operational Context for audit trail (Axiom 2).
    """
    try:
        _assert_tenant_scope(body.tenant_id, verified_tenant_id)
        # Parse timestamp if provided
        timestamp = None
        if body.timestamp:
            timestamp = datetime.fromisoformat(body.timestamp.replace("Z", "+00:00"))

        # Resolve actor_id: auth context > explicit field > metadata > service fallback
        metadata = dict(body.metadata or {})
        explicit_actor = body.actor_id or metadata.get("actor_id")
        resolved_actor = _resolve_actor_id(http_request, explicit_actor)
        if resolved_actor:
            metadata["actor_id"] = resolved_actor

        # Record usage event
        event = usage_tracker.record_usage(
            tenant_id=body.tenant_id,
            metric_type=body.metric_type,
            quantity=body.quantity,
            unit=body.unit,
            metadata=metadata if metadata else None,
            timestamp=timestamp,
            idempotency_key=body.idempotency_key,
        )

        logger.info(
            f"Recorded usage: tenant={body.tenant_id} metric={body.metric_type.value} quantity={body.quantity}"
        )

        return UsageEventResponse(**event)

    except UsageTrackerError as e:
        logger.error(f"Failed to record usage: {e}")
        raise HTTPException(status_code=500, detail="Failed to record usage")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error recording usage: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.post(
    "/usage/record/batch",
    response_model=BatchRecordUsageResponse,
    status_code=201,
    summary="Record multiple usage events",
    description="Record multiple usage events in a single batch request. Continues on individual failures.",
)
async def batch_record_usage(
    body: BatchRecordUsageRequest,
    http_request: Request,
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    usage_tracker: UsageTrackerService = Depends(get_usage_tracker),
) -> BatchRecordUsageResponse:
    """
    Record multiple usage events in a single batch.

    Useful for bulk imports or catching up on missed events.
    Individual event failures don't stop the batch.
    """
    try:
        # Convert to list of dicts
        events = []
        for event_req in body.events:
            _assert_tenant_scope(event_req.tenant_id, verified_tenant_id)
            metadata = dict(event_req.metadata or {})
            explicit_actor = event_req.actor_id or metadata.get("actor_id")
            resolved_actor = _resolve_actor_id(http_request, explicit_actor)
            if resolved_actor:
                metadata["actor_id"] = resolved_actor
            event = {
                "tenant_id": event_req.tenant_id,
                "metric_type": event_req.metric_type,
                "quantity": event_req.quantity,
                "unit": event_req.unit,
                "metadata": metadata if metadata else None,
                "idempotency_key": event_req.idempotency_key,
            }
            if event_req.timestamp:
                event["timestamp"] = datetime.fromisoformat(event_req.timestamp.replace("Z", "+00:00"))
            events.append(event)

        # Batch record. Any failed event returns a typed 503 so callers can retry.
        recorded_events = usage_tracker.batch_record_usage(events)

        logger.info(f"Batch recorded {len(recorded_events)}/{len(events)} usage events")

        return BatchRecordUsageResponse(
            recorded=len(recorded_events),
            failed=len(events) - len(recorded_events),
            events=[UsageEventResponse(**e) for e in recorded_events],
        )

    except BatchUsageTrackerError as e:
        logger.error(
            "Batch usage recording failed: recorded=%d failed=%d",
            len(getattr(e, "recorded_events", [])),
            len(getattr(e, "failed_events", [])),
        )
        raise HTTPException(
            status_code=503,
            detail={
                "error": "metering_batch_failed",
                "recorded": len(getattr(e, "recorded_events", [])),
                "failed": len(getattr(e, "failed_events", [])),
                "failed_events": getattr(e, "failed_events", []),
            },
        ) from e
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error in batch recording: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get(
    "/usage/{tenant_id}/summary/{year}/{month}",
    response_model=UsageSummaryResponse,
    summary="Get usage summary for billing period",
    description="Get aggregated usage summary for a specific billing period (month).",
)
async def get_usage_summary(
    tenant_id: str,
    year: int = Path(..., ge=2024, le=2099, description="Billing period year"),
    month: int = Path(..., ge=1, le=12, description="Billing period month (1-12)"),
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    usage_tracker: UsageTrackerService = Depends(get_usage_tracker),
) -> UsageSummaryResponse:
    """
    Get usage summary for a specific billing period.

    Returns aggregated usage by metric type for the specified month.
    Used by billing system to calculate invoices.
    """
    try:
        _assert_tenant_scope(tenant_id, verified_tenant_id)
        summary = usage_tracker.get_usage_summary(tenant_id, year, month)

        # Convert metrics to MetricSummary models
        metrics = {}
        for metric_type, data in summary.get("metrics", {}).items():
            metrics[metric_type] = MetricSummary(**data)

        response = UsageSummaryResponse(
            tenant_id=summary["tenant_id"],
            year=summary["year"],
            month=summary["month"],
            period_start=summary["period_start"],
            period_end=summary["period_end"],
            metrics=metrics,
        )

        logger.info(f"Retrieved usage summary: tenant={tenant_id} period={year}-{month:02d} metrics={len(metrics)}")

        return response

    except UsageAggregationError as e:
        logger.error(f"Failed to get usage summary: {e}")
        raise HTTPException(status_code=500, detail="Failed to get usage summary")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error getting usage summary: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get(
    "/usage/{tenant_id}/current",
    response_model=UsageSummaryResponse,
    summary="Get current month usage",
    description="Get usage summary for the current billing period.",
)
async def get_current_month_usage(
    tenant_id: str,
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    usage_tracker: UsageTrackerService = Depends(get_usage_tracker),
) -> UsageSummaryResponse:
    """
    Get usage summary for the current billing period.

    Convenience endpoint for dashboard display.
    """
    try:
        _assert_tenant_scope(tenant_id, verified_tenant_id)
        summary = usage_tracker.get_current_month_usage(tenant_id)

        # Convert metrics to MetricSummary models
        metrics = {}
        for metric_type, data in summary.get("metrics", {}).items():
            metrics[metric_type] = MetricSummary(**data)

        return UsageSummaryResponse(
            tenant_id=summary["tenant_id"],
            year=summary["year"],
            month=summary["month"],
            period_start=summary["period_start"],
            period_end=summary["period_end"],
            metrics=metrics,
        )

    except UsageAggregationError as e:
        logger.error(f"Failed to get current month usage: {e}")
        raise HTTPException(status_code=500, detail="Failed to get current usage")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error getting current month usage: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get(
    "/workspace/{tenant_id}/current",
    response_model=TenantBillingWorkspaceResponse,
    summary="Get tenant billing workspace snapshot",
    description="Return current projected bill, included usage, and per-meter billing breakdown.",
)
# Required: authenticated session tenant_id must match the {tenant_id} path parameter.
# The TENANT# prefix in the URL path is stripped before comparison.
# HTTP 403 is returned with a descriptive detail message when scopes do not match.
async def get_tenant_billing_workspace(
    tenant_id: str,
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    read_models: BillingReadModelService = Depends(get_billing_read_models),
) -> TenantBillingWorkspaceResponse:
    _assert_tenant_scope(tenant_id, verified_tenant_id)
    snapshot = read_models.tenant_month_snapshot(tenant_id)
    return TenantBillingWorkspaceResponse(
        tenant_id=snapshot.tenant_id,
        plan_tier=snapshot.plan_tier,
        currency=snapshot.currency,
        year=snapshot.year,
        month=snapshot.month,
        plan_fee_usd=str(snapshot.plan_fee_usd),
        projected_usage_usd=str(snapshot.projected_usage_usd),
        adjustment_total_usd=str(snapshot.adjustment_total_usd),
        projected_cogs_usd=str(snapshot.projected_cogs_usd),
        projected_bill_usd=str(snapshot.projected_bill_usd),
        projected_margin_usd=str(snapshot.projected_margin_usd),
        included_quantities=snapshot.included_quantities,
        invoice_totals=snapshot.invoice_totals,
        metric_breakdown={
            key: TenantBillingMetricBreakdown(**value) for key, value in snapshot.metric_breakdown.items()
        },
        adjustments=[TenantBillingAdjustmentSummary(**value) for value in snapshot.adjustments],
        reconciliation=[TenantBillingReconciliationSummary(**value) for value in snapshot.reconciliation],
    )


@router.get(
    "/usage/{tenant_id}/history",
    response_model=UsageHistoryResponse,
    summary="Get usage history",
    description="Get usage history across multiple billing periods.",
)
async def get_usage_history(
    tenant_id: str,
    months: int = Query(12, ge=1, le=24, description="Number of months to retrieve"),
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    usage_tracker: UsageTrackerService = Depends(get_usage_tracker),
) -> UsageHistoryResponse:
    """
    Get usage history for a tenant.

    Returns monthly usage summaries for the specified number of months.
    Used for analytics and trend visualization.
    """
    try:
        _assert_tenant_scope(tenant_id, verified_tenant_id)
        history = usage_tracker.get_usage_history(tenant_id, months)

        # Convert to response models
        summaries = []
        for summary in history:
            metrics = {}
            for metric_type, data in summary.get("metrics", {}).items():
                metrics[metric_type] = MetricSummary(**data)

            summaries.append(
                UsageSummaryResponse(
                    tenant_id=summary["tenant_id"],
                    year=summary["year"],
                    month=summary["month"],
                    period_start=summary["period_start"],
                    period_end=summary["period_end"],
                    metrics=metrics,
                )
            )

        logger.info(f"Retrieved usage history: tenant={tenant_id} periods={len(summaries)}")

        return UsageHistoryResponse(tenant_id=tenant_id, history=summaries)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error getting usage history: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get(
    "/usage/{tenant_id}/limits",
    response_model=UsageLimitsResponse,
    summary="Get tier limits and usage",
    description="Get billing-tier limits and current usage for each metric.",
)
async def get_usage_limits(
    tenant_id: str,
    tier: str | None = Query(
        None, description="Deprecated. Tenant plan is resolved from canonical billing entitlements."
    ),
    year: int | None = Query(None, ge=2024, le=2099, description="Billing period year"),
    month: int | None = Query(None, ge=1, le=12, description="Billing period month (1-12)"),
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    usage_tracker: UsageTrackerService = Depends(get_usage_tracker),
    entitlements: BillingEntitlementResolver = Depends(get_billing_entitlements),
) -> UsageLimitsResponse:
    """Get per-metric limits and consumption for a tenant tier."""
    _assert_tenant_scope(tenant_id, verified_tenant_id)
    resolved_tier, hard_limits, included_quantities = _resolve_usage_limits_surface(
        tenant_id=tenant_id,
        tier=tier,
        entitlements=entitlements,
    )
    tier_limits = dict(hard_limits)
    for metric_name, included in included_quantities.items():
        tier_limits.setdefault(metric_name, included)

    resolved_year, resolved_month = _resolve_period(year, month)

    try:
        summary = usage_tracker.get_usage_summary(tenant_id, resolved_year, resolved_month)
        metric_usage = _build_metric_usage(summary)

        limits: dict[str, MetricLimitStatus] = {}
        for metric_name, metric_limit in tier_limits.items():
            try:
                metric_key = metric_name.value  # type: ignore[union-attr]
            except AttributeError:
                metric_key = str(metric_name)
            metric_enum = next((m for m in UsageMetricType if m.value == metric_key), None)
            used = (
                metric_usage.get(metric_enum, Decimal("0"))
                if metric_enum is not None
                else Decimal(str((summary.get("metric_totals") or {}).get(metric_key, 0)))
            )
            limit_value = Decimal(str(metric_limit))
            remaining = max(limit_value - used, Decimal("0"))
            percent_used = ((used / limit_value) * 100).quantize(Decimal("0.01")) if limit_value else Decimal("0")
            limits[metric_key] = MetricLimitStatus(
                limit=limit_value,
                used=used,
                remaining=remaining,
                percent_used=percent_used,
            )

        return UsageLimitsResponse(
            tenant_id=tenant_id,
            tier=resolved_tier,
            year=resolved_year,
            month=f"{resolved_month:02d}",
            limits=limits,
        )

    except UsageAggregationError as e:
        logger.error(f"Failed to get usage limits: {e}")
        raise HTTPException(status_code=500, detail="Failed to get usage limits")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error getting usage limits: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get(
    "/usage/{tenant_id}/alerts",
    response_model=UsageAlertsResponse,
    summary="Get usage alerts",
    description="Get budget threshold alerts for a tenant based on current usage and tier.",
)
# Required: authenticated session tenant_id must match the {tenant_id} path parameter.
# The TENANT# prefix in the URL path is stripped before comparison.
# HTTP 403 is returned with a descriptive detail message when scopes do not match.
async def get_usage_alerts(
    tenant_id: str,
    tier: str | None = Query(
        None, description="Deprecated. Tenant plan is resolved from canonical billing entitlements."
    ),
    year: int | None = Query(None, ge=2024, le=2099, description="Billing period year"),
    month: int | None = Query(None, ge=1, le=12, description="Billing period month (1-12)"),
    breached_only: bool = Query(False, description="Return only breached thresholds"),
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    usage_tracker: UsageTrackerService = Depends(get_usage_tracker),
    entitlements: BillingEntitlementResolver = Depends(get_billing_entitlements),
) -> UsageAlertsResponse:
    """Get threshold alerts for billing usage."""
    _assert_tenant_scope(tenant_id, verified_tenant_id)
    resolved_tier, hard_limits, included_quantities = _resolve_usage_limits_surface(
        tenant_id=tenant_id,
        tier=tier,
        entitlements=entitlements,
    )
    tier_limits = dict(hard_limits)
    for metric_name, included in included_quantities.items():
        tier_limits.setdefault(metric_name, included)

    resolved_year, resolved_month = _resolve_period(year, month)

    try:
        summary = usage_tracker.get_usage_summary(tenant_id, resolved_year, resolved_month)
        metric_usage = _build_metric_usage(summary)
        alerts = []
        for metric_name, metric_limit in tier_limits.items():
            metric_key = metric_name.value if hasattr(metric_name, "value") else str(metric_name)
            metric_enum = next((m for m in UsageMetricType if m.value == metric_key), None)
            used = (
                metric_usage.get(metric_enum, Decimal("0"))
                if metric_enum is not None
                else Decimal(str((summary.get("metric_totals") or {}).get(metric_key, 0)))
            )
            for threshold in (80, 95, 100):
                threshold_value = Decimal(str(metric_limit)) * Decimal(threshold) / Decimal("100")
                breached = used >= threshold_value
                alerts.append(
                    type(
                        "Alert",
                        (),
                        {
                            "threshold_pct": threshold,
                            "metric": metric_key,
                            "current_usage": used,
                            "limit": Decimal(str(metric_limit)),
                            "breached": breached,
                            "soft_block": breached and threshold == 100 and metric_key in hard_limits,
                        },
                    )()
                )

        if breached_only:
            alerts = [alert for alert in alerts if alert.breached]

        response_alerts = [
            UsageAlertResponseItem(
                threshold_pct=alert.threshold_pct,
                metric=alert.metric,
                current_usage=Decimal(str(alert.current_usage)),
                limit=Decimal(str(alert.limit)),
                breached=alert.breached,
                soft_block=alert.soft_block,
            )
            for alert in alerts
        ]

        return UsageAlertsResponse(
            tenant_id=tenant_id,
            tier=resolved_tier,
            year=resolved_year,
            month=f"{resolved_month:02d}",
            alerts=response_alerts,
        )
    except UsageAggregationError as e:
        logger.error(f"Failed to get usage alerts: {e}")
        raise HTTPException(status_code=500, detail="Failed to get usage alerts")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error getting usage alerts: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get(
    "/usage/{tenant_id}/export",
    summary="Export usage data",
    description="Export billing usage for a period as JSON or CSV.",
)
async def export_usage_get(
    tenant_id: str,
    format: str = Query("json", pattern="^(json|csv)$", description="Export format: json or csv"),
    year: int | None = Query(None, ge=2024, le=2099, description="Billing period year"),
    month: int | None = Query(None, ge=1, le=12, description="Billing period month (1-12)"),
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    usage_tracker: UsageTrackerService = Depends(get_usage_tracker),
) -> Any:
    """Export usage summary in JSON or CSV format."""
    _assert_tenant_scope(tenant_id, verified_tenant_id)
    return _export_usage_summary(
        tenant_id=tenant_id,
        format=format,
        year=year,
        month=month,
        usage_tracker=usage_tracker,
    )


@router.post(
    "/usage/{tenant_id}/export",
    summary="Export usage data",
    description="Export billing usage for a period as JSON or CSV.",
)
async def export_usage_post(
    tenant_id: str,
    format: str = Query("json", pattern="^(json|csv)$", description="Export format: json or csv"),
    year: int | None = Query(None, ge=2024, le=2099, description="Billing period year"),
    month: int | None = Query(None, ge=1, le=12, description="Billing period month (1-12)"),
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    usage_tracker: UsageTrackerService = Depends(get_usage_tracker),
) -> Any:
    """POST variant for export endpoint."""
    _assert_tenant_scope(tenant_id, verified_tenant_id)
    return _export_usage_summary(
        tenant_id=tenant_id,
        format=format,
        year=year,
        month=month,
        usage_tracker=usage_tracker,
    )


@router.get(
    "/usage/{tenant_id}/provider-breakdown",
    summary="Get provider cost breakdown",
    description="Return provider-level cost/usage rollup for the current billing period.",
)
async def get_provider_breakdown(
    tenant_id: str,
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    usage_tracker: UsageTrackerService = Depends(get_usage_tracker),
) -> dict[str, Any]:
    _assert_tenant_scope(tenant_id, verified_tenant_id)
    now = datetime.now(UTC)
    try:
        summary = usage_tracker.get_usage_summary(tenant_id, now.year, now.month)
    except Exception:
        summary = {"metrics": {}}

    providers: dict[str, dict[str, float]] = {}
    for metric_name, metric_data in (summary.get("metrics", {}) or {}).items():
        quantity = float((metric_data or {}).get("total_quantity", 0) or 0)
        if quantity <= 0:
            continue
        # Until provider tags are available on all usage events, keep a deterministic fallback bucket.
        providers.setdefault("platform", {"cost": 0.0, "quantity": 0.0})
        providers["platform"]["quantity"] += quantity

    return {"tenant_id": tenant_id, "providers": providers}


@router.get(
    "/usage/{tenant_id}/agent-breakdown",
    summary="Get agent usage breakdown",
    description="Return agent-level usage/cost rollup for the current billing period.",
)
async def get_agent_breakdown(
    tenant_id: str,
    verified_tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    _assert_tenant_scope(tenant_id, verified_tenant_id)
    # Agent-level metering dimensions are being rolled out; keep a stable response contract.
    return {"tenant_id": tenant_id, "agents": []}


def _export_usage_summary(
    tenant_id: str,
    format: str,
    year: int | None,
    month: int | None,
    usage_tracker: UsageTrackerService,
) -> Any:
    """Internal usage export implementation."""
    resolved_year, resolved_month = _resolve_period(year, month)

    try:
        summary = usage_tracker.get_usage_summary(tenant_id, resolved_year, resolved_month)

        if format == "csv":
            csv_content = _build_usage_csv(summary)
            filename = f"usage-{tenant_id}-{resolved_year}-{resolved_month:02d}.csv"
            return Response(
                content=csv_content,
                media_type="text/csv",
                headers={"Content-Disposition": f'attachment; filename="{filename}"'},
            )

        return summary

    except UsageAggregationError as e:
        logger.error(f"Failed to export usage summary: {e}")
        raise HTTPException(status_code=500, detail="Failed to export usage summary")
    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Unexpected error exporting usage summary: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


# ============================================================================
# Health Check
# ============================================================================


@router.get("/usage/health", summary="Health check", description="Check API health")
async def health_check() -> dict[str, str]:
    """Health check endpoint."""
    return {"status": "healthy", "service": "usage-tracking"}
