"""
Checkout Verification Endpoint

Verifies a Stripe Checkout session after payment redirect.
Called by checkout-success.html to confirm payment and display details.

Constitutional compliance:
- Axiom 5: Automated payment verification (Defined Work)
- Axiom 2: Payment events already captured by stripe_webhooks.py
"""

import logging
import os

import stripe
from fastapi import APIRouter, Header, HTTPException, Query, Request, status
from pydantic import BaseModel, Field

from apps.backend.api.auth_helpers import RUNTIME_PROVISIONING_COOKIE_NAMES
from apps.backend.services.runtime.provisioning_token import (
    RuntimeProvisioningTokenError,
    verify_workweaver_runtime_provisioning_token,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/billing", tags=["billing", "checkout"])


class CheckoutVerifyResponse(BaseModel):
    """Response for checkout session verification."""

    status: str = Field(..., description="Payment status (paid, unpaid, no_payment_required)")
    amount: int = Field(..., description="Total amount in cents")
    currency: str = Field(..., description="Currency code (e.g. usd)")
    interval: str | None = Field(None, description="Billing interval (month, year)")
    tenant_id: str | None = Field(None, description="Tenant ID from session metadata")
    email: str | None = Field(None, description="Customer email")


def _clean_token_value(value: str | None) -> str:
    return value.strip() if isinstance(value, str) else ""


@router.get(
    "/checkout/verify",
    response_model=CheckoutVerifyResponse,
    summary="Verify checkout session",
    description="Verify a Stripe Checkout session after payment redirect.",
)
async def verify_checkout_session(
    request: Request,
    session_id: str = Query(..., description="Stripe Checkout session ID"),
    x_workweaver_runtime_provisioning_token: str | None = Header(
        default=None,
        alias="X-Workweaver-Runtime-Provisioning-Token",
    ),
) -> CheckoutVerifyResponse:
    """
    Verify a Stripe Checkout session by session_id.

    Called by checkout-success.html after Stripe redirects back.
    Retrieves session from Stripe API, confirms payment status,
    and returns display data for the success page.
    """
    token = _clean_token_value(x_workweaver_runtime_provisioning_token)
    if not token:
        for cookie_name in RUNTIME_PROVISIONING_COOKIE_NAMES:
            token = (request.cookies.get(cookie_name) or "").strip()
            if token:
                break

    if not token:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": "unauthorized", "message": "Authentication required"},
        )

    try:
        claims = verify_workweaver_runtime_provisioning_token(token)
    except RuntimeProvisioningTokenError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": "unauthorized", "message": "Invalid or expired authentication token"},
        )

    api_key = os.getenv("STRIPE_API_KEY")
    if not api_key:
        logger.error("STRIPE_API_KEY not configured")
        raise HTTPException(status_code=500, detail="Stripe not configured")

    try:
        stripe.api_key = api_key
        session = stripe.checkout.Session.retrieve(
            session_id,
            expand=["subscription"],
        )
    except stripe.error.InvalidRequestError:
        raise HTTPException(status_code=404, detail="Checkout session not found")
    except stripe.error.StripeError as e:
        logger.error("Stripe API error verifying session %s: %s", session_id, e)
        raise HTTPException(status_code=502, detail="Failed to verify with Stripe")

    payment_status = session.get("payment_status", "unpaid")
    amount_total = session.get("amount_total", 0)
    currency = session.get("currency", "usd")
    metadata = session.get("metadata", {})
    tenant_id = metadata.get("tenant_id")
    if tenant_id and tenant_id != claims.tenant_id:
        logger.warning(
            "Checkout verify tenant mismatch: claims_tenant=%s session_tenant=%s session_id=%s",
            claims.tenant_id,
            tenant_id,
            session_id,
        )
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Forbidden")

    customer_details = session.get("customer_details") or {}
    email = customer_details.get("email") or metadata.get("customer_email")

    # Extract billing interval from subscription
    interval = None
    subscription = session.get("subscription")
    if subscription and isinstance(subscription, dict):
        items_data = subscription.get("items", {}).get("data", [])
        if items_data:
            price = items_data[0].get("price", {})
            recurring = price.get("recurring", {})
            interval = recurring.get("interval")

    logger.info(
        "Checkout verify: session=%s status=%s amount=%s tenant=%s",
        session_id,
        payment_status,
        amount_total,
        tenant_id,
    )

    return CheckoutVerifyResponse(
        status=payment_status,
        amount=amount_total,
        currency=currency,
        interval=interval,
        tenant_id=tenant_id,
        email=email,
    )
