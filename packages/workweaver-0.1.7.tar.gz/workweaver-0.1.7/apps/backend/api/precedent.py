"""Precedent Prediction API endpoint (Issue #2331).

Endpoint:
  POST /api/v1/precedent/predict -- predict outcome distribution from precedents

This endpoint is intentionally outside the /simulation/ namespace to keep
concerns separated: simulation deals with goal-based sandbox execution,
while precedent prediction deals with statistical outcome distributions
from historical decision events.

Reference: GitHub Issue #2331 -- precedent-outcome distribution prediction layer.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, status

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.models.outcome_distribution import (
    PredictRequest,
    PredictResponse,
)
from apps.backend.services.precedent_outcome_service import PrecedentOutcomeService
from apps.backend.services.precedent_query import PrecedentQuery

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/precedent", tags=["precedent"])


@router.post("/predict", response_model=PredictResponse)
async def predict_outcome(
    body: PredictRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PredictResponse:
    """Predict outcome distribution for a proposed action based on precedents.

    Given an action specification (domain + description), this endpoint queries
    past decision_event precedents for the tenant and computes an outcome
    distribution over success_rate, expected_cost, expected_latency_ms, and
    risk_indicators.

    Confidence bands:
    - < 3 precedents: "insufficient" (no distribution returned)
    - 3-9 precedents: "low"
    - >= 10 precedents: derived from sample variance

    Action-domain filtering excludes cross-domain precedents to prevent
    meaningless averaging across different action types.
    """
    action_spec = body.action_spec

    try:
        # Query precedents using the existing PrecedentQuery service.
        precedent_query = PrecedentQuery()
        query_result = precedent_query.find_precedents(
            tenant_id=tenant_id,
            decision_summary=action_spec.description,
            decision_type="tool_call",
            top_k=body.k_precedents,
        )
    except Exception as exc:
        logger.error(
            "precedent_predict_query_failed tenant=%s error=%s",
            tenant_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Precedent query failed: {exc}",
        ) from exc

    # Compute outcome distribution from matched precedents.
    service = PrecedentOutcomeService()
    prediction = service.predict(
        action_spec=action_spec,
        precedents=query_result.precedents,
    )

    logger.info(
        "precedent_predict tenant=%s domain=%s n=%d confidence=%s",
        tenant_id,
        action_spec.action_domain,
        prediction.sample_n,
        prediction.confidence,
    )

    return PredictResponse(prediction=prediction)
