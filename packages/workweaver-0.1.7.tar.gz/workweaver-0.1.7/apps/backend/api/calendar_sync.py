"""
Calendar Sync API

Bidirectional calendar sync and My Day merged view.

Source: docs/PRODUCT.md#Part17.4.1
"""

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.scheduling.calendar_service import (
    CalendarService,
    CalendarSyncPersistenceError,
    ReviewWindowPersistenceError,
)
from apps.backend.services.scheduling.calendar_sync_engine import get_calendar_sync_engine

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/mission/calendar", tags=["calendar-sync"])

_calendar_service = CalendarService()


def _raise_calendar_store_error(exc: CalendarSyncPersistenceError) -> None:
    raise HTTPException(status_code=503, detail="Calendar storage unavailable") from exc


def _raise_review_window_store_error(exc: ReviewWindowPersistenceError) -> None:
    raise HTTPException(status_code=503, detail="Review window storage unavailable") from exc


class ConnectProviderRequest(BaseModel):
    provider: str = Field(..., max_length=50, description="google | microsoft | zoho")
    credentials: dict[str, str] = Field(
        default_factory=dict,
        description="Provider-specific credentials",
    )


class AddEventRequest(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    start_time: str = Field(..., max_length=50, description="ISO datetime")
    end_time: str = Field(..., max_length=50, description="ISO datetime")
    event_type: str = Field(
        "human",
        max_length=50,
        description="human | ai_schedule | review_window | focus_time",
    )
    description: str = Field("", max_length=5000)
    attendees: list[str] = Field(default_factory=list)


class FocusBlockRequest(BaseModel):
    start_time: str = Field(..., description="HH:MM format")
    end_time: str = Field(..., description="HH:MM format")
    date: str | None = Field(None, description="YYYY-MM-DD, null for recurring")
    recurring: bool = Field(False)
    label: str = Field("Focus Time", max_length=200)


class ScheduleReviewRequest(BaseModel):
    attention_items: list[dict[str, Any]] = Field(..., description="Items needing review")
    target_date: str | None = Field(None, description="YYYY-MM-DD")


class WorkingHoursRequest(BaseModel):
    start: str = Field("09:00", description="HH:MM")
    end: str = Field("17:00", description="HH:MM")


class BidirectionalSyncRequest(BaseModel):
    provider: str = Field(
        ...,
        max_length=50,
        pattern="^(google|microsoft|zoho)$",
        description="Calendar provider to sync: google | microsoft | zoho",
    )


@router.post("/sync")
async def trigger_bidirectional_sync(
    body: BidirectionalSyncRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Trigger bidirectional calendar sync for a provider.

    Pulls events from external calendar, pushes AI-scheduled events out,
    and merges results into the internal calendar.
    """
    engine = get_calendar_sync_engine()
    try:
        state = await engine.sync(tenant_id, body.provider)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    return {
        "tenant_id": state.tenant_id,
        "provider": state.provider,
        "last_sync_at": state.last_sync_at,
        "events_synced": state.events_synced,
        "errors": state.errors,
    }


@router.get("/connections")
async def list_connections(
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(50, ge=1, le=200, description="Max connections to return"),
) -> list[dict[str, Any]]:
    """List all calendar provider connections."""
    try:
        return _calendar_service.list_connections(tenant_id)[:limit]
    except CalendarSyncPersistenceError as exc:
        _raise_calendar_store_error(exc)


@router.post("/connections")
async def connect_provider(
    req: ConnectProviderRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Connect a calendar provider."""
    try:
        return _calendar_service.connect_provider(tenant_id, req.provider, req.credentials)
    except CalendarSyncPersistenceError as exc:
        _raise_calendar_store_error(exc)
    except ValueError as exc:
        logger.warning("connect_provider validation error: %s", exc)
        raise HTTPException(status_code=400, detail="Invalid provider connection data") from exc


@router.delete("/connections/{connection_id}")
async def disconnect_provider(
    connection_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, str]:
    """Disconnect a calendar provider."""
    try:
        deleted = _calendar_service.disconnect_provider(tenant_id, connection_id)
    except CalendarSyncPersistenceError as exc:
        _raise_calendar_store_error(exc)
    if not deleted:
        raise HTTPException(status_code=404, detail="Connection not found")
    return {"status": "disconnected", "connection_id": connection_id}


@router.post("/sync/{connection_id}")
async def sync_calendar(
    connection_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Trigger a sync for a calendar provider."""
    try:
        result = _calendar_service.sync_events(tenant_id, connection_id)
        if result.get("manual_required") or result.get("degraded"):
            logger.warning(
                "Calendar sync degraded for connection %s tenant %s: fallback_used=%s mode=%s",
                connection_id,
                tenant_id,
                result.get("fallback_used"),
                result.get("fallback_mode"),
            )
        return result
    except CalendarSyncPersistenceError as exc:
        _raise_calendar_store_error(exc)
    except ValueError as exc:
        logger.warning("sync_calendar not found: %s", exc)
        raise HTTPException(status_code=404, detail="Calendar connection not found") from exc


@router.get("/my-day")
async def get_my_day(
    date: str | None = Query(None, description="YYYY-MM-DD"),
    view: str = Query("merged", pattern="^(merged|human|ai|review)$"),
    range_name: str = Query("today", alias="range", pattern="^(today|week|month|agenda)$"),
    scope: str = Query("personal", pattern="^(personal|team|org)$"),
    limit: int = Query(100, ge=1, le=500),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Get merged calendar view for a bounded calendar range."""
    try:
        return _calendar_service.get_calendar_view(
            tenant_id=tenant_id,
            date=date,
            view=view,
            range_name=range_name,
            scope=scope,
            limit=limit,
        )
    except CalendarSyncPersistenceError as exc:
        _raise_calendar_store_error(exc)


@router.post("/events")
async def add_event(
    req: AddEventRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Add a calendar event."""
    try:
        return _calendar_service.add_event(
            tenant_id=tenant_id,
            title=req.title,
            start_time=req.start_time,
            end_time=req.end_time,
            event_type=req.event_type,
            description=req.description,
            attendees=req.attendees,
        )
    except CalendarSyncPersistenceError as exc:
        _raise_calendar_store_error(exc)


@router.get("/focus")
async def get_focus_blocks(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[dict[str, Any]]:
    """Get all focus time blocks."""
    try:
        return _calendar_service.get_focus_blocks(tenant_id)
    except CalendarSyncPersistenceError as exc:
        _raise_calendar_store_error(exc)


@router.post("/focus")
async def set_focus_block(
    req: FocusBlockRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Set a focus time block."""
    try:
        return _calendar_service.set_focus_block(
            tenant_id=tenant_id,
            start_time=req.start_time,
            end_time=req.end_time,
            date=req.date,
            recurring=req.recurring,
            label=req.label,
        )
    except CalendarSyncPersistenceError as exc:
        _raise_calendar_store_error(exc)


@router.get("/review-windows")
async def get_review_windows(
    date: str | None = Query(None),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[dict[str, Any]]:
    """Get scheduled review windows."""
    try:
        return _calendar_service.get_windows(tenant_id, date)
    except ReviewWindowPersistenceError as exc:
        _raise_review_window_store_error(exc)


@router.post("/review-windows/schedule")
async def schedule_review_windows(
    req: ScheduleReviewRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[dict[str, Any]]:
    """Auto-schedule review windows from attention items."""
    try:
        return _calendar_service.schedule_review_windows(
            tenant_id,
            req.attention_items,
            req.target_date,
        )
    except ReviewWindowPersistenceError as exc:
        _raise_review_window_store_error(exc)


@router.post("/review-windows/{window_id}/complete")
async def complete_review_window(
    window_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Mark a review window as completed."""
    try:
        window = _calendar_service.complete_review_window(tenant_id, window_id)
    except ReviewWindowPersistenceError as exc:
        _raise_review_window_store_error(exc)
    if not window:
        raise HTTPException(status_code=404, detail="Review window not found")
    return window


@router.get("/working-hours")
async def get_working_hours(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, str]:
    """Get working hours configuration."""
    try:
        return _calendar_service.get_working_hours(tenant_id)
    except ReviewWindowPersistenceError as exc:
        _raise_review_window_store_error(exc)


@router.put("/working-hours")
async def set_working_hours(
    req: WorkingHoursRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, str]:
    """Set working hours for review window scheduling."""
    try:
        _calendar_service.set_working_hours(req.start, req.end, tenant_id)
        return _calendar_service.get_working_hours(tenant_id)
    except ReviewWindowPersistenceError as exc:
        _raise_review_window_store_error(exc)
