"""Compounding Trajectory API (issue #2325).

GET /api/v1/compounding/trajectory
GET /api/v1/compounding/stall
"""

from __future__ import annotations

import logging
from datetime import datetime, UTC

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/compounding", tags=["compounding-trajectory"])


def _get_scorecard_service():
    from apps.backend.services.compounding_scorecard import get_scorecard_service
    return get_scorecard_service()


class TrajectoryPointResponse(BaseModel):
    bucket: int = Field(..., description="Ordinal bucket index")
    mean: float = Field(..., description="Mean quality_score")
    stderr: float = Field(..., description="Standard error")
    sample_n: int = Field(..., description="Sample count")
    confidence_band: str = Field(..., description="Confidence level")


class TrajectoryResponse(BaseModel):
    skill_id: str
    window_days: int
    generated_at: str
    points: list[TrajectoryPointResponse]
    sparkline: str


class StallEvidenceResponse(BaseModel):
    skill_id: str
    compound_count_increase: int
    quality_delta: float
    recent_mean: float
    baseline_mean: float
    window_days: int
    config: dict[str, int | float]


class StallResponse(BaseModel):
    skill_id: str
    stalled: bool
    stall_evidence: StallEvidenceResponse | None = None
    window_days: int


@router.get("/trajectory", response_model=TrajectoryResponse)
async def get_skill_trajectory(
    skill_id: str = Query(..., description="Skill ID to query"),
    window_days: int = Query(30, description="Lookback window in days", ge=1, le=365),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> TrajectoryResponse:
    try:
        svc = _get_scorecard_service()
        points = await svc.get_skill_trajectory(tenant_id=tenant_id, skill_id=skill_id, window_days=window_days)
        from apps.backend.services.compounding_scorecard import CompoundingTrajectoryPoint
        sparkline = CompoundingTrajectoryPoint.render_sparkline(points)
        return TrajectoryResponse(
            skill_id=skill_id, window_days=window_days,
            generated_at=datetime.now(UTC).replace(microsecond=0).isoformat(),
            points=[TrajectoryPointResponse(bucket=p.bucket, mean=p.mean, stderr=p.stderr, sample_n=p.sample_n, confidence_band=p.confidence_band) for p in points],
            sparkline=sparkline,
        )
    except Exception as exc:
        logger.error("Trajectory computation failed for skill %s: %s", skill_id, exc, exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to compute trajectory") from exc


@router.get("/stall", response_model=StallResponse)
async def detect_skill_stall(
    skill_id: str = Query(..., description="Skill ID to check"),
    window_days: int = Query(30, description="Lookback window in days", ge=1, le=365),
    stall_window_days: int = Query(7, description="Stall window in days", ge=1, le=365),
    min_compound_count: int = Query(10, description="Min compound count (K)", ge=1),
    max_quality_delta: float = Query(0.02, description="Max quality delta (epsilon)", ge=0.0, le=1.0),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> StallResponse:
    from apps.backend.services.compounding_scorecard import CompoundingStallConfig
    try:
        svc = _get_scorecard_service()
        config = CompoundingStallConfig(min_compound_count=min_compound_count, max_quality_delta=max_quality_delta, window_days=stall_window_days)
        result = await svc.detect_stall(tenant_id=tenant_id, skill_id=skill_id, window_days=window_days, config=config)
        evidence = None
        if result.get("stall_evidence"):
            se = result["stall_evidence"]
            evidence = StallEvidenceResponse(skill_id=se["skill_id"], compound_count_increase=se["compound_count_increase"], quality_delta=se["quality_delta"], recent_mean=se["recent_mean"], baseline_mean=se["baseline_mean"], window_days=se["window_days"], config=se["config"])
        return StallResponse(skill_id=skill_id, stalled=result["stalled"], stall_evidence=evidence, window_days=window_days)
    except Exception as exc:
        logger.error("Stall detection failed for skill %s: %s", skill_id, exc, exc_info=True)
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to detect stall") from exc
