"""Good Morning Brief API — GET /api/v1/brief/morning."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/brief", tags=["morning-brief"])


def _get_brief_service():
    """Lazy import to avoid import-time boto3 failures in tests."""
    from apps.backend.services.morning_brief import get_morning_brief_service

    return get_morning_brief_service()


@router.get(
    "/morning",
    summary="Good Morning Brief",
    description=(
        "Aggregate overnight evidence across entities into proof cards. "
        "Cards are sorted so entities needing approval surface first."
    ),
)
async def get_morning_brief(
    hours_back: int = Query(
        12,
        ge=1,
        le=72,
        description="How many hours of evidence history to include (default 12).",
    ),
    limit_per_entity: int = Query(
        10,
        ge=1,
        le=50,
        description="Maximum evidence entries per entity card.",
    ),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return the morning brief for the authenticated tenant."""
    try:
        svc = _get_brief_service()
        return await svc.generate_brief(
            tenant_id=tenant_id,
            hours_back=hours_back,
            limit_per_entity=limit_per_entity,
        )
    except Exception as exc:
        logger.error("Failed to generate morning brief: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to generate morning brief",
        ) from exc
