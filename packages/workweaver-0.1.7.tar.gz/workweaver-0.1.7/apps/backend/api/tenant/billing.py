from __future__ import annotations

from decimal import Decimal
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.billing.usage import get_usage_tracker
from apps.backend.services.usage_tracker import UsageAggregationError, UsageTrackerService


router = APIRouter(prefix="/api/v1/tenant/billing", tags=["tenant-billing"])


class MemberBillingMetric(BaseModel):
    total_quantity: float = Field(..., description="Total usage quantity for this metric")
    unit: str = Field(..., description="Usage unit")
    event_count: int = Field(..., description="Number of usage events")
    total_cost_usd: str = Field(..., description="Attributed cost in USD")


class MemberBillingSpend(BaseModel):
    actor_id: str = Field(..., description="Member or system actor; legacy backfill uses tenant_registrar")
    attribution_source: str = Field(..., description="event or backfill")
    total_quantity: float = Field(..., description="Total usage quantity across metrics")
    total_cost_usd: str = Field(..., description="Attributed cost in USD")
    event_count: int = Field(..., description="Number of usage events")
    metrics: dict[str, MemberBillingMetric] = Field(default_factory=dict)


class InferencePricingBreakdown(BaseModel):
    pricing_source: str = Field(..., description="Rate-card source used for the projected cost")
    pricing_provider: str = Field(..., description="Provider recorded in the pricing projection")
    pricing_model: str = Field(..., description="Model recorded in the pricing projection")
    pricing_known: bool = Field(..., description="Whether the rate came from a known pricing row")
    event_count: int = Field(..., description="Number of inference audit rows in this bucket")
    total_tokens: int = Field(..., description="Total inference tokens in this bucket")
    total_cogs_usd: str = Field(..., description="Projected COGS for this bucket")


class MemberBillingResponse(BaseModel):
    tenant_id: str
    year: int
    month: str
    period_start: str
    items: list[MemberBillingSpend]
    inference_pricing_breakdown: list[InferencePricingBreakdown] = Field(default_factory=list)
    total: int
    limit: int
    offset: int
    next_offset: int | None = None


def _normalize_tenant_id(value: str) -> str:
    raw = str(value or "").strip()
    return raw if raw.startswith("TENANT#") else f"TENANT#{raw}"


def _coerce_decimal(value: Any) -> Decimal:
    try:
        return Decimal(str(value or 0))
    except (ArithmeticError, TypeError, ValueError):
        return Decimal("0")


def _summarize_inference_pricing(records: list[dict[str, Any]]) -> list[dict[str, Any]]:
    grouped: dict[tuple[str, str, str, bool], dict[str, Any]] = {}
    for record in records:
        if not isinstance(record, dict):
            continue
        pricing_source = str(record.get("pricing_source") or "unknown pricing source").strip() or "unknown pricing source"
        pricing_provider = str(record.get("pricing_provider") or "unknown provider").strip() or "unknown provider"
        pricing_model = str(
            record.get("pricing_model")
            or record.get("requested_model_spec")
            or record.get("model_id")
            or "unknown model"
        ).strip() or "unknown model"
        pricing_known = bool(record.get("pricing_known"))
        key = (pricing_source, pricing_provider, pricing_model, pricing_known)
        bucket = grouped.setdefault(
            key,
            {
                "pricing_source": pricing_source,
                "pricing_provider": pricing_provider,
                "pricing_model": pricing_model,
                "pricing_known": pricing_known,
                "event_count": 0,
                "total_tokens": 0,
                "total_cogs_usd": Decimal("0"),
            },
        )
        bucket["event_count"] += 1
        bucket["total_tokens"] += int(
            record.get("total_tokens")
            or (
                int(record.get("prompt_tokens") or 0)
                + int(record.get("completion_tokens") or 0)
            )
        )
        bucket["total_cogs_usd"] += _coerce_decimal(record.get("total_cogs_usd"))

    rows = list(grouped.values())
    rows.sort(
        key=lambda row: (
            row["total_cogs_usd"],
            row["event_count"],
            row["pricing_source"],
            row["pricing_provider"],
            row["pricing_model"],
        ),
        reverse=True,
    )
    for row in rows:
        row["total_cogs_usd"] = str(row["total_cogs_usd"])
    return rows


def _member_response(payload: dict[str, Any]) -> MemberBillingResponse:
    return MemberBillingResponse(
        tenant_id=str(payload["tenant_id"]),
        year=int(payload["year"]),
        month=str(payload["month"]),
        period_start=str(payload["period_start"]),
        items=[MemberBillingSpend(**item) for item in payload.get("items", [])],
        inference_pricing_breakdown=[
            InferencePricingBreakdown(**item) for item in payload.get("inference_pricing_breakdown", [])
        ],
        total=int(payload["total"]),
        limit=int(payload["limit"]),
        offset=int(payload["offset"]),
        next_offset=payload.get("next_offset"),
    )


@router.get(
    "/by-member",
    response_model=MemberBillingResponse,
    summary="Get per-member billing attribution",
    description="Return read-only per-member usage and cost attribution for one billing period.",
)
async def get_billing_by_member(
    year: int = Query(..., ge=2024, le=2099, description="Billing period year"),
    month: int = Query(..., ge=1, le=12, description="Billing period month"),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    usage_tracker: UsageTrackerService = Depends(get_usage_tracker),
) -> MemberBillingResponse:
    tenant_id = _normalize_tenant_id(verified_tenant_id)
    try:
        payload = usage_tracker.get_member_usage_summary(
            tenant_id,
            year,
            month,
            limit=limit,
            offset=offset,
        )
        payload["inference_pricing_breakdown"] = _summarize_inference_pricing(
            usage_tracker.list_inference_audit_records(tenant_id, year, month)
        )
        return _member_response(payload)
    except UsageAggregationError as exc:
        raise HTTPException(status_code=500, detail="Failed to get per-member billing") from exc
