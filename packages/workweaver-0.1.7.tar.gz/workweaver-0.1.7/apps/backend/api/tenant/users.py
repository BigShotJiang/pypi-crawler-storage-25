"""Tenant User Management API endpoints.

Provides REST API for:
- User invitation
- Role updates
- User offboarding
- User listing

Reference: WORKPLAN.md TASK-6.0C.001
Legacy requirement reference: P1.7B.2 — Tenant Admin & User Management
Constitution: Axiom 1 (Agents First), Axiom 2 (Context & Memory)
"""

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, EmailStr, Field
from typing import Any
from datetime import datetime

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_email,
    get_verified_user_id,
    get_verified_user_role,
)
from apps.backend.schemas.error_response import ErrorResponse
from apps.backend.services.user_management import (
    UserManagementService,
    Invitation,
    UserNotFoundError,
    InsufficientPrivilegesError,
    LastAdminError,
    InvitationExpiredError,
)
from apps.backend.models.user import UserRole, UserStatus


# ============================================================================
# Router
# ============================================================================


router = APIRouter(prefix="/api/v1/tenant/users", tags=["user-management"])


def _service_unavailable(action: str, exc: Exception) -> None:
    """Raise a typed degraded response when user-management storage fails."""
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail={
            "error": "user_management_unavailable",
            "detail": f"User management unavailable while trying to {action}",
        },
    ) from exc


# ============================================================================
# Request/Response Models
# ============================================================================


class CreateInvitationRequest(BaseModel):
    """Request model for creating user invitation."""

    invitee_email: EmailStr = Field(..., description="Email of user to invite")
    role: UserRole = Field(..., description="Role to assign to invited user")


class InvitationResponse(BaseModel):
    """Response model for invitation."""

    invitation_id: str
    tenant_id: str
    invitee_email: str
    role: UserRole
    inviter_email: str
    status: str
    created_at: datetime
    expires_at: datetime
    accepted_at: datetime | None = None


class UpdateUserRoleRequest(BaseModel):
    """Request model for updating user role."""

    role: UserRole = Field(..., description="New role to assign")


class UserResponse(BaseModel):
    """Response model for user."""

    user_id: str
    email: str
    role: UserRole
    status: UserStatus
    created_at: datetime
    updated_at: datetime | None = None
    last_login: datetime | None = None


class UserListResponse(BaseModel):
    """Response model for user list."""

    users: list[dict[str, Any]]
    total: int



# ============================================================================
# Dependencies
# ============================================================================


def get_user_management_service() -> UserManagementService:
    """Dependency to get user management service."""
    return UserManagementService()


def _send_invitation_email(invitation_id: str) -> None:
    from apps.backend.services.invitation_service import get_invitation_service

    get_invitation_service().send_invitation_email(invitation_id)


# ============================================================================
# API Endpoints
# ============================================================================


@router.post(
    "/invitations",
    response_model=InvitationResponse,
    status_code=status.HTTP_201_CREATED,
    responses={
        403: {"model": ErrorResponse, "description": "Insufficient privileges"},
    },
)
async def create_invitation(
    request: CreateInvitationRequest,
    service: UserManagementService = Depends(get_user_management_service),
    requester_role: UserRole = Depends(get_verified_user_role),
    tenant_id: str = Depends(get_verified_tenant_id),
    inviter_email: str = Depends(get_verified_user_email),
) -> Invitation:
    """Create user invitation.

    Only admins can create invitations. Role is verified from the
    authoritative user record in DynamoDB, not from client-supplied headers.
    """
    if not service.can_invite_users(requester_role):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "InsufficientPrivilegesError",
                "detail": "Only admins can invite users",
            },
        )

    try:
        invitation = service.create_invitation(
            tenant_id=tenant_id,
            inviter_email=inviter_email,
            invitee_email=request.invitee_email,
            role=request.role,
        )
    except Exception as exc:
        _service_unavailable("create an invitation", exc)

    # Issue #2746: send the token-backed acceptance email so the invitee
    # actually receives the link. UserManagementService.create_invitation
    # only creates the row; InvitationService owns the email + acceptance
    # URL generation. Failures here don't roll back the invitation row —
    # the UI gets the ID and the admin can use Resend to retry.
    try:

        invitation_id = (
            getattr(invitation, "invitation_id", None)
            or (invitation.get("invitation_id") if isinstance(invitation, dict) else None)
        )
        if invitation_id:
            _send_invitation_email(str(invitation_id))
    except Exception as exc:  # pragma: no cover -- email failure non-fatal
        import logging

        logging.getLogger(__name__).warning(
            "create_invitation email-send failed: %s", exc, exc_info=True
        )

    return invitation


@router.get(
    "/invitations/{invitation_id}",
    response_model=InvitationResponse,
    responses={
        404: {"model": ErrorResponse, "description": "Invitation not found"},
    },
)
async def get_invitation(
    invitation_id: str,
    service: UserManagementService = Depends(get_user_management_service),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> Invitation:
    """Get invitation by ID.

    Security (#1929): Requires verified tenant auth. Only returns invitations
    belonging to the caller's tenant.
    """
    try:
        invitation = service.get_invitation(invitation_id)
    except UserNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "UserNotFoundError", "detail": str(e)},
        )
    except Exception as exc:
        _service_unavailable("load an invitation", exc)

    # Tenant ownership check (#1929)
    inv_tenant = str(getattr(invitation, "tenant_id", "") or "").strip()
    if inv_tenant and inv_tenant != tenant_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "UserNotFoundError", "detail": "Invitation not found"},
        )
    return invitation


@router.get("/invitations", response_model=list[InvitationResponse])
async def list_invitations(
    status: str | None = None,
    limit: int = Query(100, ge=1, le=500, description="Max invitations to return"),
    service: UserManagementService = Depends(get_user_management_service),
    tenant_id: str = Depends(get_verified_tenant_id),
    requester_role: UserRole = Depends(get_verified_user_role),
) -> list[Invitation]:
    """List all invitations for tenant.

    Issue #2746: admin-only — invitation rosters are sensitive PII. Non-admin
    callers (manager/agent) get 403 here so the Members management UI can
    fail closed instead of leaking the roster to read-only users.
    """
    if not service.can_invite_users(requester_role):
        # Use the literal 403 to avoid shadowing the `status: str | None`
        # query parameter that filters invitations by status string.
        raise HTTPException(
            status_code=403,
            detail={
                "error": "InsufficientPrivilegesError",
                "detail": "Only admins can list invitations",
            },
        )
    try:
        return service.list_invitations(tenant_id, status=status)[:limit]
    except Exception as exc:
        _service_unavailable("list invitations", exc)


@router.post(
    "/invitations/{invitation_id}/accept",
    response_model=InvitationResponse,
    responses={
        404: {"model": ErrorResponse, "description": "Invitation not found"},
        400: {"model": ErrorResponse, "description": "Invitation expired"},
    },
)
async def accept_invitation(
    invitation_id: str,
    service: UserManagementService = Depends(get_user_management_service),
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
) -> Invitation:
    """Accept invitation.

    Security (#1929): Requires verified auth. The invitation must belong to
    the caller's tenant.
    """
    try:
        # Verify the invitation belongs to the caller's tenant before accepting.
        invitation = service.get_invitation(invitation_id)
        inv_tenant = str(getattr(invitation, "tenant_id", "") or "").strip()
        if inv_tenant and inv_tenant != tenant_id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={"error": "UserNotFoundError", "detail": "Invitation not found"},
            )
        return service.accept_invitation(invitation_id)
    except UserNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "UserNotFoundError", "detail": str(e)},
        )
    except InvitationExpiredError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "InvitationExpiredError", "detail": str(e)},
        )
    except Exception as exc:
        _service_unavailable("accept an invitation", exc)


@router.delete(
    "/invitations/{invitation_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    responses={
        404: {"model": ErrorResponse, "description": "Invitation not found"},
    },
)
async def cancel_invitation(
    invitation_id: str,
    service: UserManagementService = Depends(get_user_management_service),
    tenant_id: str = Depends(get_verified_tenant_id),
    requester_role: UserRole = Depends(get_verified_user_role),
) -> None:
    """Cancel invitation.

    Security (#1929): Requires verified admin auth. Only admins can cancel
    invitations for their own tenant.
    """
    if not service.can_invite_users(requester_role):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "InsufficientPrivilegesError",
                "detail": "Only admins can cancel invitations",
            },
        )
    try:
        # Verify the invitation belongs to the caller's tenant before canceling.
        invitation = service.get_invitation(invitation_id)
        inv_tenant = str(getattr(invitation, "tenant_id", "") or "").strip()
        if inv_tenant and inv_tenant != tenant_id:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={"error": "UserNotFoundError", "detail": "Invitation not found"},
            )
        service.cancel_invitation(invitation_id)
    except UserNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "UserNotFoundError", "detail": str(e)},
        )
    except Exception as exc:
        _service_unavailable("cancel an invitation", exc)


@router.patch(
    "/{user_id}/role",
    response_model=UserResponse,
    responses={
        403: {"model": ErrorResponse, "description": "Insufficient privileges"},
        404: {"model": ErrorResponse, "description": "User not found"},
    },
)
async def update_user_role(
    user_id: str,
    request: UpdateUserRoleRequest,
    service: UserManagementService = Depends(get_user_management_service),
    requester_role: UserRole = Depends(get_verified_user_role),
    requester_id: str = Depends(get_verified_user_id),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Update user role. Only admins can update roles."""
    try:
        return service.update_user_role(
            tenant_id=tenant_id,
            user_id=user_id,
            new_role=request.role,
            requester_role=requester_role,
            requester_id=requester_id,
        )
    except UserNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "UserNotFoundError", "detail": str(e)},
        )
    except InsufficientPrivilegesError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": "InsufficientPrivilegesError", "detail": str(e)},
        )
    except Exception as exc:
        _service_unavailable("update a user role", exc)


@router.delete(
    "/{user_id}",
    response_model=UserResponse,
    responses={
        403: {"model": ErrorResponse, "description": "Insufficient privileges"},
        404: {"model": ErrorResponse, "description": "User not found"},
        400: {"model": ErrorResponse, "description": "Cannot offboard last admin"},
    },
)
async def offboard_user(
    user_id: str,
    service: UserManagementService = Depends(get_user_management_service),
    requester_role: UserRole = Depends(get_verified_user_role),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Offboard user (soft delete). Only admins can offboard users."""
    try:
        return service.offboard_user(
            tenant_id=tenant_id,
            user_id=user_id,
            requester_role=requester_role,
        )
    except UserNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "UserNotFoundError", "detail": str(e)},
        )
    except InsufficientPrivilegesError as e:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": "InsufficientPrivilegesError", "detail": str(e)},
        )
    except LastAdminError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "LastAdminError", "detail": str(e)},
        )
    except Exception as exc:
        _service_unavailable("offboard a user", exc)


@router.get("", response_model=UserListResponse)
async def list_users(
    role_filter: UserRole | None = None,
    status_filter: UserStatus | None = None,
    limit: int = Query(100, ge=1, le=500, description="Max results"),
    service: UserManagementService = Depends(get_user_management_service),
    tenant_id: str = Depends(get_verified_tenant_id),
    requester_role: UserRole = Depends(get_verified_user_role),
) -> dict[str, Any]:
    """List users for tenant.

    Issue #2746: admin-only — the member roster reveals coworker emails
    and roles. Non-admin callers receive 403; the Members management UI
    treats that as a read-only state and hides management actions.
    """
    if not service.can_invite_users(requester_role):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "InsufficientPrivilegesError",
                "detail": "Only admins can list users",
            },
        )
    try:
        return service.list_users(
            tenant_id=tenant_id,
            role_filter=role_filter,
            status_filter=status_filter,
            limit=limit,
        )
    except Exception as exc:
        _service_unavailable("list users", exc)


@router.get(
    "/{user_id}",
    response_model=UserResponse,
    responses={
        404: {"model": ErrorResponse, "description": "User not found"},
    },
)
async def get_user(
    user_id: str,
    service: UserManagementService = Depends(get_user_management_service),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Get user by ID."""
    try:
        return service.get_user(tenant_id, user_id)
    except UserNotFoundError as e:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "UserNotFoundError", "detail": str(e)},
        )
    except Exception as exc:
        _service_unavailable("load a user", exc)
