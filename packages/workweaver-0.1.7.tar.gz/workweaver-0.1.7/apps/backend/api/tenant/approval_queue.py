"""Mission Control approval queue API.

Provides endpoints used by the Mission Control dashboard for human approvals:
- List pending approval requests for a tenant.
- Get pending approval count (for nav badge — M8.2).
- Get approval history with status filter (M8.3).
- Approve/reject approval requests (M8.5: with optional modified_params).

Reference: docs/PRODUCT.md § Mission Control UX.
"""

from __future__ import annotations

import re
from datetime import datetime, UTC
from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, get_verified_user_id
from apps.backend.models.approval_request import ApprovalStatus
from apps.backend.services.approval_gates import get_approval_gates
from apps.backend.services.approval_service import ApprovalService
from apps.backend.services.human_judgment_service import HumanJudgmentError, HumanJudgmentService


router = APIRouter(prefix="/api/v1/tenant", tags=["approval-queue"])


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class ApprovalQueueItem(BaseModel):
    """Single pending approval queue row."""

    request_id: str = Field(..., description="Approval request ID")
    description: str = Field(..., description="Human-readable request description")
    requested_by: str = Field(..., description="User that requested approval")
    timestamp: str = Field(..., description="Request creation timestamp (ISO)")
    tool_name: str | None = Field(default=None, description="Tool requiring approval")


class ApprovalQueueResponse(BaseModel):
    """Response for pending approval queue."""

    tenant_id: str
    approvals: list[ApprovalQueueItem]
    count: int


class PendingCountResponse(BaseModel):
    """Response for pending approval count (M8.2 — nav badge)."""

    tenant_id: str
    count: int


class ApprovalHistoryItem(BaseModel):
    """Single approval history row (M8.3)."""

    request_id: str = Field(..., description="Approval request ID")
    tool_name: str = Field(..., description="Tool name")
    status: str = Field(..., description="Approval status")
    requested_by: str = Field(..., description="User who requested")
    approved_by: str | None = Field(default=None, description="User who approved")
    rejected_by: str | None = Field(default=None, description="User who rejected")
    rejection_reason: str | None = Field(default=None, description="Rejection reason")
    created_at: str = Field(..., description="Created timestamp (ISO)")
    updated_at: str = Field(..., description="Last updated timestamp (ISO)")
    description: str = Field(..., description="Human-readable description")


class ApprovalHistoryResponse(BaseModel):
    """Response for approval audit history (M8.3)."""

    tenant_id: str
    approvals: list[ApprovalHistoryItem]
    count: int


class ApprovalActionRequest(BaseModel):
    """Approve action request (M8.5: includes optional modified_params)."""

    actor_id: str | None = Field(default=None, description="Deprecated. Actor is resolved from auth.")
    modified_params: dict[str, Any] | None = Field(
        default=None,
        description="Optional edited parameters for inline action edit (M8.5)",
    )


class RejectApprovalRequest(BaseModel):
    """Reject action request."""

    actor_id: str | None = Field(default=None, description="Deprecated. Actor is resolved from auth.")
    reason: str | None = Field(
        default="No reason provided",
        description="Reason for rejection",
        max_length=512,
    )


class ApprovalActionResponse(BaseModel):
    """Response for approve/reject actions."""

    success: bool = Field(..., description="Whether action succeeded")
    message: str = Field(..., description="Action result message")
    request_id: str = Field(..., description="Approval request ID")
    actor_id: str = Field(..., description="User ID who took action")
    action: str = Field(..., description="approve or reject")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _normalize_tenant_id(raw: str) -> str:
    """Return tenant id in TENANT#... format."""
    value = (raw or "").strip()
    if not value:
        return ""
    if value.startswith("TENANT#"):
        return value
    return f"TENANT#{value}"


def _validate_tenant(tenant_id: str, x_tenant_id: str) -> str:
    """Validate and normalize tenant, raising HTTP errors on mismatch."""
    normalized_tenant = _normalize_tenant_id(tenant_id)
    normalized_header = _normalize_tenant_id(x_tenant_id)
    if not normalized_tenant:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_tenant_id",
                "message": "tenant_id is required and must not be empty",
            },
        )

    if normalized_tenant != normalized_header:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "tenant_mismatch",
                "message": "X-Tenant-ID does not match requested tenant_id",
            },
        )

    if not re.match(r"^TENANT#[A-Za-z0-9_-]+$", normalized_tenant):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_tenant_format",
                "message": "Tenant ID must be TENANT#<id> with alphanumeric characters",
            },
        )
    return normalized_tenant


def _humanize_request(item: dict[str, Any]) -> str:
    """Build a readable description from tool metadata."""
    metadata = item.get("metadata") or {}
    for key in ("description", "message", "summary", "notes", "title", "detail"):
        candidate = metadata.get(key)
        if isinstance(candidate, str) and candidate.strip():
            return candidate.strip()

    tool_name = str(item.get("tool_name") or "Unknown action")
    params = item.get("tool_params")
    if isinstance(params, dict) and params:
        parts: list[str] = []
        for key, value in list(params.items())[:3]:
            parts.append(f"{key}={value}")
        if parts:
            return f"{tool_name} ({', '.join(parts)})"
        return tool_name
    return tool_name


def _map_action_error(action: str, result_code: str, message: str) -> None:
    """Raise a mapped HTTP exception for approval action failures."""
    status_code_map = {
        "NOT_FOUND": status.HTTP_404_NOT_FOUND,
        "INVALID_STATUS": status.HTTP_409_CONFLICT,
        "EXPIRED": status.HTTP_410_GONE,
        "UNAUTHORIZED": status.HTTP_403_FORBIDDEN,
        "SERVICE_UNAVAILABLE": status.HTTP_503_SERVICE_UNAVAILABLE,
    }
    http_code = status_code_map.get(result_code, status.HTTP_400_BAD_REQUEST)

    raise HTTPException(
        status_code=http_code,
        detail={
            "error": result_code.lower(),
            "message": message or f"Failed to {action} approval request",
        },
    )


def _raise_queue_unavailable(action: str, exc: Exception) -> None:
    """Raise a typed degraded response when queue storage or service calls fail."""
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail={
            "error": "approval_queue_unavailable",
            "message": f"Approval queue unavailable while trying to {action}",
        },
    ) from exc


def _get_human_judgment_service() -> HumanJudgmentService:
    gates = get_approval_gates()
    return HumanJudgmentService(
        approval_service=ApprovalService(approval_gates=gates),
        approval_gates=gates,
    )


def _raise_human_judgment_error(exc: HumanJudgmentError) -> None:
    raise HTTPException(
        status_code=exc.status_code,
        detail={
            "error": exc.code,
            "message": str(exc),
        },
    ) from exc


def _safe_timestamp(value: Any) -> str:
    """Convert value to ISO timestamp string."""
    if isinstance(value, str):
        return value
    if isinstance(value, datetime):
        return value.isoformat()
    return datetime.now(UTC).isoformat()


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get(
    "/{tenant_id}/approval-queue",
    response_model=ApprovalQueueResponse,
    status_code=status.HTTP_200_OK,
    summary="List pending approval queue for tenant",
    description="Returns pending approval requests for Mission Control queue.",
)
async def get_approval_queue(
    tenant_id: str,
    x_tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(20, ge=1, le=200),
) -> ApprovalQueueResponse:
    normalized_tenant = _validate_tenant(tenant_id, x_tenant_id)

    try:
        service = ApprovalService(approval_gates=get_approval_gates())
        list_result = service.list_pending_requests(tenant_id=normalized_tenant)
    except Exception as exc:
        _raise_queue_unavailable("load the approval queue", exc)
    if not list_result.success:
        _raise_queue_unavailable("load the approval queue", RuntimeError(list_result.message or "failed"))

    raw_approvals = list_result.metadata.get("approvals", [])
    if not isinstance(raw_approvals, list):
        raw_approvals = []
    total_count = len([approval for approval in raw_approvals if isinstance(approval, dict)])

    items: list[ApprovalQueueItem] = []
    for index, approval in enumerate(raw_approvals):
        if not isinstance(approval, dict):
            continue

        if index >= limit:
            break

        items.append(
            ApprovalQueueItem(
                request_id=str(approval.get("request_id", "")),
                description=_humanize_request(approval),
                requested_by=str(approval.get("user_id") or "Unknown"),
                timestamp=_safe_timestamp(approval.get("created_at")),
                tool_name=str(approval.get("tool_name") or "Unknown"),
            )
        )

    return ApprovalQueueResponse(
        tenant_id=normalized_tenant,
        approvals=items,
        count=total_count,
    )


@router.get(
    "/{tenant_id}/approval-queue/pending-count",
    response_model=PendingCountResponse,
    status_code=status.HTTP_200_OK,
    summary="Get pending approval count for nav badge (M8.2)",
)
async def get_pending_count(
    tenant_id: str,
    x_tenant_id: str = Depends(get_verified_tenant_id),
) -> PendingCountResponse:
    """Return the number of pending approvals for the tenant.

    This lightweight endpoint feeds the dashboard nav badge via SSE polling.
    """
    normalized_tenant = _validate_tenant(tenant_id, x_tenant_id)

    try:
        gates = get_approval_gates()
        list_result = gates.list_pending_approvals(tenant_id=normalized_tenant)
    except Exception as exc:
        _raise_queue_unavailable("read pending approval count", exc)

    if not list_result.success:
        _raise_queue_unavailable("read pending approval count", RuntimeError(list_result.message or "failed"))
    count = int(list_result.metadata.get("count", 0) or 0)

    return PendingCountResponse(
        tenant_id=normalized_tenant,
        count=count,
    )


@router.get(
    "/{tenant_id}/approval-queue/history",
    response_model=ApprovalHistoryResponse,
    status_code=status.HTTP_200_OK,
    summary="Get approval audit history (M8.3)",
)
async def get_approval_history(
    tenant_id: str,
    x_tenant_id: str = Depends(get_verified_tenant_id),
    approval_status: str | None = Query(
        None,
        alias="status",
        description="Filter by status: pending, approved, rejected, expired",
    ),
    limit: int = Query(100, ge=1, le=500),
) -> ApprovalHistoryResponse:
    """Return all approval records with optional status filter.

    Unlike the pending queue, this endpoint returns approved, rejected,
    and expired records for audit purposes.
    """
    normalized_tenant = _validate_tenant(tenant_id, x_tenant_id)

    # Resolve optional status filter
    status_filter = None
    if approval_status:
        try:
            status_filter = ApprovalStatus(approval_status.lower())
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "invalid_status",
                    "message": f"Invalid status '{approval_status}'. Must be one of: pending, approved, rejected, expired",
                },
            )

    try:
        gates = get_approval_gates()
        all_approvals = gates.list_all_approvals(
            tenant_id=normalized_tenant,
            status_filter=status_filter,
        )
    except Exception as exc:
        _raise_queue_unavailable("load approval history", exc)

    total_count = len(all_approvals)
    items: list[ApprovalHistoryItem] = []
    for approval in all_approvals[:limit]:
        items.append(
            ApprovalHistoryItem(
                request_id=approval.request_id,
                tool_name=approval.tool_name,
                status=approval.status.value,
                requested_by=approval.user_id,
                approved_by=approval.approved_by,
                rejected_by=approval.rejected_by,
                rejection_reason=approval.rejection_reason,
                created_at=_safe_timestamp(approval.created_at),
                updated_at=_safe_timestamp(approval.updated_at),
                description=_humanize_request(approval.to_dict()),
            )
        )

    return ApprovalHistoryResponse(
        tenant_id=normalized_tenant,
        approvals=items,
        count=total_count,
    )


@router.post(
    "/{tenant_id}/approval-queue/{request_id}/approve",
    response_model=ApprovalActionResponse,
    status_code=status.HTTP_200_OK,
    summary="Approve a pending approval request",
)
async def approve_request(
    tenant_id: str,
    request_id: str,
    request: ApprovalActionRequest = Body(...),
    x_tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
) -> ApprovalActionResponse:
    normalized_tenant = _validate_tenant(tenant_id, x_tenant_id)

    try:
        await _get_human_judgment_service().approve_request(
            tenant_id=normalized_tenant,
            request_id=request_id,
            actor_id=actor_id,
            reason=None,
            modified_params=request.modified_params,
            source="approval_queue",
        )
    except HumanJudgmentError as exc:
        _raise_human_judgment_error(exc)
    except Exception as exc:
        _raise_queue_unavailable("approve the request", exc)

    return ApprovalActionResponse(
        success=True,
        message="approved",
        request_id=request_id,
        actor_id=actor_id,
        action="approve",
    )


@router.post(
    "/{tenant_id}/approval-queue/{request_id}/reject",
    response_model=ApprovalActionResponse,
    status_code=status.HTTP_200_OK,
    summary="Reject a pending approval request",
)
async def reject_request(
    tenant_id: str,
    request_id: str,
    request: RejectApprovalRequest = Body(...),
    x_tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
) -> ApprovalActionResponse:
    normalized_tenant = _validate_tenant(tenant_id, x_tenant_id)

    try:
        await _get_human_judgment_service().reject_request(
            tenant_id=normalized_tenant,
            request_id=request_id,
            actor_id=actor_id,
            reason=request.reason or "No reason provided",
            source="approval_queue",
        )
    except HumanJudgmentError as exc:
        _raise_human_judgment_error(exc)
    except Exception as exc:
        _raise_queue_unavailable("reject the request", exc)

    return ApprovalActionResponse(
        success=True,
        message="rejected",
        request_id=request_id,
        actor_id=actor_id,
        action="reject",
    )
