"""Tenant management API endpoints."""
