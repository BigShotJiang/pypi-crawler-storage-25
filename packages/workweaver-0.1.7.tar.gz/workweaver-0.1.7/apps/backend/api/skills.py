"""Skills CRUD API for Workweaver Skills-First AI Platform.

This module provides REST API endpoints for managing skills including:
- List skills
- Get skill details
- Create/update/delete skills
- Test skills
- Enable/disable skills

Reference: docs/PRODUCT.md P1.1.5 — Skill CRUD API (lines 2993-3049)
"""

from apps.backend.config.table_names import resolve_table

import json
import logging
import time
import uuid
from dataclasses import asdict, fields
from typing import Any, Literal

from fastapi import APIRouter, Depends, File, HTTPException, Path, Query, Request, UploadFile, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_role,
    require_admin_user_role,
)
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.models.user import UserRole
from apps.backend.models.user_context import UserContext
from apps.backend.models.skill_registry import CompiledSkillMetadata, SkillRegistry
from apps.backend.models.skill_source import SkillSourceImportRequest, SkillSourceImportResponse
from apps.backend.services.skills.skill_query import SkillQueryService
from apps.backend.services.skills.skill_registrar import CompiledSkill, SkillRegistrar
from apps.backend.services.skills.skill_source_importer import (
    SkillSourceImportError,
    run_skill_source_import,
)
from apps.backend.services.unified_skill_registry import UnifiedSkillRegistry
from apps.backend.services.executable_skill_platform import (
    SkillInstallSource,
    SkillPackageValidationError,
    SkillRuntimeError,
    get_executable_skill_platform,
)
from apps.backend.services.upload_validation import (
    UploadValidationError,
    validate_skill_archive_upload,
)
from apps.backend.services.skillify import SkillifyService
from apps.backend.schemas.skill import Skill
from apps.backend.middleware.tenant_isolation import resolve_request_tenant_id as get_tenant_id
from apps.backend.middleware.tenant_isolation import resolve_request_user_id as get_user_id

# Configure logging
logger = logging.getLogger(__name__)

SkillStatus = Literal["active", "deprecated", "draft"]
VisibilityScope = Literal["tenant", "team", "global", "private"]


def _new_skill_instance_id() -> str:
    """Generate a robust skill instance id compatible across ULID package variants."""
    try:
        import ulid

        return str(ulid.new())
    except Exception:
        millis = int(time.time() * 1000)
        return f"{millis:012x}{uuid.uuid4().hex[:14]}".upper()[:26]


def _resolved_executable_skill_tenant_id(request: Request, verified_tenant_id: str) -> str:
    """Return the verified tenant for executable-skill package operations.

    Router-level requests receive this value from JWT-backed auth. Direct unit
    tests that call handlers without FastAPI dependency resolution still fall
    back to the request tenant shim.
    """
    if isinstance(verified_tenant_id, str) and verified_tenant_id:
        return verified_tenant_id
    return get_tenant_id(request)


def get_user_context(request: Request) -> UserContext | None:
    """Resolve the caller context when user identity is available.

    Some older local tests and tenant-scoped admin paths exercise the Skills API
    with only a tenant header. Production-authenticated requests still carry a
    verified user id, and owner-scoped authorization is enforced whenever a
    user-owned skill is involved.
    """
    tenant_id = get_tenant_id(request)
    try:
        user_id = get_user_id(request)
    except HTTPException:
        return None
    role = get_verified_user_role(request=request, tenant_id=tenant_id)
    return UserContext(tenant_id=tenant_id, user_id=user_id, role=role)


def _skill_visibility_scope(registry: SkillRegistry) -> str:
    try:
        metadata = json.loads(getattr(registry, "skill_metadata", "") or "{}")
    except Exception:
        metadata = {}
    return str(metadata.get("visibility_scope") or "tenant")


def _can_access_skill(registry: SkillRegistry, user_context: UserContext | None) -> bool:
    owner_user_id = getattr(registry, "owner_user_id", None)
    visibility_scope = _skill_visibility_scope(registry)
    if user_context is None:
        return owner_user_id is None or visibility_scope in {"tenant", "global"}
    return user_context.can_access_skill(owner_user_id, visibility_scope)


def _assert_can_access_skill(registry: SkillRegistry, user_context: UserContext | None) -> None:
    if not _can_access_skill(registry, user_context):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have access to this skill.",
        )


def _assert_can_modify_skill(registry: SkillRegistry, user_context: UserContext | None) -> None:
    owner_user_id = getattr(registry, "owner_user_id", None)
    if user_context is None:
        if owner_user_id is None:
            return
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="User identity is required to modify a user-owned skill.",
        )
    if not user_context.can_modify_skill(owner_user_id):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="You do not have permission to modify this skill.",
        )


# ============================================================================
# Pydantic Models for API
# ============================================================================


class SkillCreateRequest(BaseModel):
    """Request model for creating a new skill.

    Attributes:
        skill_id: Unique skill identifier
        display_name: Human-readable name
        description: Skill description
        vertical: Business vertical
        role_category: Role category
        triggers: List of trigger types
        prompt: LLM instruction prompt
        input_schema_ref: Reference to input JSON schema
        output_schema_ref: Reference to output JSON schema
        version: Semantic version
        status: Skill lifecycle status
        visibility_scope: Visibility scope
        tags: List of tags
        localization: Localization configuration (optional)
    """

    skill_id: str = Field(..., description="Unique skill identifier")
    display_name: str = Field(..., description="Human-readable skill name")
    description: str = Field(..., description="Skill description")
    vertical: str = Field(..., description="Business vertical")
    role_category: str = Field(..., description="Role category")
    triggers: list[str] = Field(..., description="List of trigger types")
    prompt: str = Field(..., description="LLM instruction prompt")
    input_schema_ref: str = Field(..., description="Reference to input JSON schema")
    output_schema_ref: str = Field(..., description="Reference to output JSON schema")
    version: str = Field(default="1.0.0", description="Semantic version")
    status: SkillStatus = Field(default="active", description="Skill lifecycle status")
    visibility_scope: VisibilityScope = Field(default="tenant", description="Visibility scope")
    tags: list[str] = Field(default_factory=list, description="List of tags")
    localization: dict[str, Any] | None = Field(default=None, description="Localization configuration")


class SkillUpdateRequest(BaseModel):
    """Request model for updating an existing skill.

    All fields are optional; only provided fields will be updated.
    """

    display_name: str | None = Field(default=None, description="Human-readable name")
    description: str | None = Field(default=None, description="Skill description")
    prompt: str | None = Field(default=None, description="LLM instruction prompt")
    status: SkillStatus | None = Field(default=None, description="Skill lifecycle status")
    tags: list[str] | None = Field(default=None, description="List of tags")
    localization: dict[str, Any] | None = Field(default=None, description="Localization configuration")


class SkillRetireRequest(BaseModel):
    """Request model for retiring or superseding a skill."""

    reason: str = Field(..., min_length=1, description="Why the skill is being retired")
    superseded_by_skill_id: str | None = Field(default=None, description="Optional replacement skill identifier")


class SkillTestRequest(BaseModel):
    """Request model for testing a skill.

    Attributes:
        test_scenario: Test scenario description
        input_data: Input data for skill execution
        expected_output: Expected output (optional)
    """

    test_scenario: str = Field(..., description="Test scenario description")
    input_data: dict[str, Any] = Field(..., description="Input data for skill execution")
    expected_output: dict[str, Any] | None = Field(default=None, description="Expected output")


class SkillTestResponse(BaseModel):
    """Response model for skill test results.

    Attributes:
        success: Whether the test passed
        output: Actual output from skill
        error: Error message if test failed
        duration_ms: Test duration in milliseconds
    """

    success: bool
    output: dict[str, Any] | None = None
    error: str | None = None
    duration_ms: float


class SkillEnableDisableRequest(BaseModel):
    """Request model for enabling/disabling a skill.

    Attributes:
        enabled: Whether to enable or disable the skill
    """

    enabled: bool = Field(..., description="Whether to enable or disable the skill")


class SkillEvolutionRequest(BaseModel):
    """Request model for creating a durable skill-evolution proposal."""

    failure_patterns: list[str] = Field(..., min_length=1, description="Observed recurring failure patterns")


class SkillEvolutionValidationRequest(BaseModel):
    """Request model for submitting shadow metrics for a queued evolution."""

    candidate_metrics: dict[str, Any] = Field(
        ...,
        description="Shadow execution metrics snapshot for regression validation",
    )


class SkillEvolutionRejectRequest(BaseModel):
    """Request model for rejecting a durable skill-evolution proposal."""

    reason: str = Field(default="rejected_by_reviewer", min_length=1, description="Reviewer rejection reason")


class SkillProposalRespondRequest(BaseModel):
    """Natural-language reviewer response for a Skillify proposal."""

    response: str = Field(..., min_length=1, description="Free-text response to the proposal")


class SkillProposalRespondResponse(BaseModel):
    """Classified response outcome for a Skillify proposal."""

    proposal_id: str
    action: Literal["keep_existing", "extend", "new", "skip"]
    response_text: str
    status: str
    message: str


class SkillEvolutionResponse(BaseModel):
    """API representation of a durable skill-evolution proposal."""

    improvement_id: str
    skill_id: str
    tenant_id: str
    failure_patterns: list[str]
    proposed_changes: str
    status: str
    created_at: str
    applied_at: str | None = None
    rejected_at: str | None = None
    rolled_back_at: str | None = None
    rejection_reason: str | None = None
    baseline_version: str | None = None
    candidate_version: str | None = None
    validation_status: str | None = None
    validation_summary: str | None = None
    validation_reason: str | None = None
    baseline_metrics: dict[str, Any] | None = None
    candidate_metrics: dict[str, Any] | None = None


class SkillListItem(BaseModel):
    """Simplified skill model for list responses.

    Attributes:
        skill_id: Skill identifier
        skill_instance_id: Instance ULID
        display_name: Human-readable name
        description: Skill description
        vertical: Business vertical
        status: Skill lifecycle status
        version: Semantic version
        created_at: Creation timestamp
        updated_at: Last update timestamp
    """

    skill_id: str
    skill_instance_id: str
    display_name: str
    description: str
    vertical: str
    status: SkillStatus
    lifecycle_state: str = "active"
    capability_class: str | None = None
    tool_profile: str | None = None
    risk_class: str | None = None
    cost_tier: str | None = None
    quality_score: float | None = None
    freshness_score: float | None = None
    success_rate: float | None = None
    superseded_by_skill_id: str | None = None
    retired_reason: str | None = None
    version: str
    created_at: str
    updated_at: str


class SkillResponse(BaseModel):
    """Full skill model for get responses.

    Attributes:
        skill_id: Skill identifier
        skill_instance_id: Instance ULID
        display_name: Human-readable name
        description: Skill description
        vertical: Business vertical
        role_category: Role category
        triggers: List of trigger types
        prompt: LLM instruction prompt
        input_schema_ref: Reference to input JSON schema
        output_schema_ref: Reference to output JSON schema
        version: Semantic version
        status: Skill lifecycle status
        visibility_scope: Visibility scope
        tags: List of tags
        localization: Localization configuration
        created_at: Creation timestamp
        updated_at: Last update timestamp
    """

    skill_id: str
    skill_instance_id: str
    display_name: str
    description: str
    vertical: str
    role_category: str
    triggers: list[str]
    prompt: str
    input_schema_ref: str
    output_schema_ref: str
    version: str
    status: SkillStatus
    lifecycle_state: str = "active"
    visibility_scope: VisibilityScope
    tags: list[str]
    localization: dict[str, Any] | None
    capability_class: str | None = None
    tool_profile: str | None = None
    risk_class: str | None = None
    cost_tier: str | None = None
    quality_score: float | None = None
    freshness_score: float | None = None
    success_rate: float | None = None
    last_validated_at: str | None = None
    source_memory_item_ids: list[str] = Field(default_factory=list)
    source_pattern_ids: list[str] = Field(default_factory=list)
    source_artifact_ids: list[str] = Field(default_factory=list)
    superseded_by_skill_id: str | None = None
    retired_at: str | None = None
    retired_reason: str | None = None
    created_at: str
    updated_at: str


class SkillPackageImportRequest(BaseModel):
    """Import request for GitHub-hosted skill package."""

    github_url: str = Field(..., min_length=1, description="GitHub repository URL")
    ref: str = Field(default="main", min_length=1, description="Branch or ref")
    subpath: str | None = Field(
        default=None,
        description="Optional package subpath within the repository",
    )


class SkillRunRequest(BaseModel):
    """Runtime request for executing an installed skill package."""

    input_data: dict[str, Any] = Field(..., description="Input payload")
    idempotency_key: str | None = Field(
        default=None,
        description="Optional idempotency key for dedupe",
    )


class SkillChainRequest(BaseModel):
    """Request model for chain validation."""

    skill_ids: list[str] = Field(
        ...,
        min_length=2,
        description="Ordered list of skill IDs",
    )


class SkillChainRunRequest(SkillChainRequest):
    """Request model for chain execution."""

    input_data: dict[str, Any] = Field(..., description="Initial chain input payload")
    idempotency_prefix: str | None = Field(
        default=None,
        description="Optional chain-level idempotency key prefix",
    )


# ============================================================================
# API Router
# ============================================================================

router = APIRouter(
    prefix="/api/v1/skills",
    tags=["Skills"],
)


def _skill_registry_to_list_item(registry: SkillRegistry) -> SkillListItem:
    """Convert SkillRegistry to SkillListItem.

    Args:
        registry: SkillRegistry instance

    Returns:
        SkillListItem instance
    """
    # Parse skill_metadata JSON string
    metadata = json.loads(registry.skill_metadata)

    return SkillListItem(
        skill_id=registry.skill_id,
        skill_instance_id=registry.skill_instance_id,
        display_name=metadata.get("display_name", ""),
        description=metadata.get("description", ""),
        vertical=registry.vertical,
        status=registry.status,
        lifecycle_state=metadata.get("lifecycle_state", "active"),
        capability_class=metadata.get("capability_class"),
        tool_profile=metadata.get("tool_profile"),
        risk_class=metadata.get("risk_class"),
        cost_tier=metadata.get("cost_tier"),
        quality_score=metadata.get("quality_score"),
        freshness_score=metadata.get("freshness_score"),
        success_rate=metadata.get("success_rate"),
        superseded_by_skill_id=metadata.get("superseded_by_skill_id"),
        retired_reason=metadata.get("retired_reason"),
        version=metadata.get("version", "1.0.0"),
        created_at=registry.created_at,
        updated_at=registry.updated_at,
    )


def _skill_registry_to_response(registry: SkillRegistry) -> SkillResponse:
    """Convert SkillRegistry to SkillResponse.

    Args:
        registry: SkillRegistry instance

    Returns:
        SkillResponse instance
    """
    # Parse skill_metadata JSON string
    metadata = json.loads(registry.skill_metadata)

    return SkillResponse(
        skill_id=registry.skill_id,
        skill_instance_id=registry.skill_instance_id,
        display_name=metadata.get("display_name", ""),
        description=metadata.get("description", ""),
        vertical=registry.vertical,
        role_category=metadata.get("role_category", ""),
        triggers=metadata.get("triggers", []),
        prompt=metadata.get("prompt", ""),
        input_schema_ref=metadata.get("input_schema_ref", ""),
        output_schema_ref=metadata.get("output_schema_ref", ""),
        version=metadata.get("version", "1.0.0"),
        status=registry.status,
        lifecycle_state=metadata.get("lifecycle_state", "active"),
        visibility_scope=metadata.get("visibility_scope", "tenant"),
        tags=metadata.get("tags", []),
        localization=metadata.get("localization"),
        capability_class=metadata.get("capability_class"),
        tool_profile=metadata.get("tool_profile"),
        risk_class=metadata.get("risk_class"),
        cost_tier=metadata.get("cost_tier"),
        quality_score=metadata.get("quality_score"),
        freshness_score=metadata.get("freshness_score"),
        success_rate=metadata.get("success_rate"),
        last_validated_at=metadata.get("last_validated_at"),
        source_memory_item_ids=list(metadata.get("source_memory_item_ids") or []),
        source_pattern_ids=list(metadata.get("source_pattern_ids") or []),
        source_artifact_ids=list(metadata.get("source_artifact_ids") or []),
        superseded_by_skill_id=metadata.get("superseded_by_skill_id"),
        retired_at=metadata.get("retired_at"),
        retired_reason=metadata.get("retired_reason"),
        created_at=registry.created_at,
        updated_at=registry.updated_at,
    )


def _find_skill_registry_by_skill_id(
    query_service: SkillQueryService,
    tenant_id: str,
    skill_id: str,
) -> SkillRegistry | None:
    """Find a single skill registry entry by skill_id."""
    list_tenant_skills = getattr(query_service, "list_tenant_skills", None)
    if callable(list_tenant_skills):
        skills = list_tenant_skills(tenant_id=tenant_id, include_metadata=True)
        try:
            iterator = iter(skills)
        except TypeError:
            iterator = None
        if iterator is not None:
            for skill in iterator:
                if skill.skill_id == skill_id:
                    return skill

    get_skill = getattr(query_service, "get_skill", None)
    if callable(get_skill):
        result = get_skill(tenant_id, skill_id)
        if isinstance(result, SkillRegistry) or result is None:
            return result
        return result
    return None


def _merge_registry_metadata(
    registry: SkillRegistry,
    *,
    metadata_updates: dict[str, Any] | None = None,
    status_override: str | None = None,
) -> CompiledSkillMetadata:
    """Preserve governed metadata while applying partial updates."""
    metadata_payload = asdict(registry.get_metadata())
    updates = dict(metadata_updates or {})
    allowed_fields = {field.name for field in fields(CompiledSkillMetadata)}
    unknown_fields = sorted(set(updates) - allowed_fields)
    if unknown_fields:
        raise ValueError(f"Unknown skill metadata fields: {', '.join(unknown_fields)}")
    metadata_payload.update(updates)
    if status_override is not None:
        metadata_payload["status"] = status_override
    if status_override == "active":
        metadata_payload["lifecycle_state"] = "active"
        metadata_payload["superseded_by_skill_id"] = None
        metadata_payload["retired_at"] = None
        metadata_payload["retired_reason"] = None
    return CompiledSkillMetadata(**metadata_payload)


def _get_skill_evolution_service(tenant_id: str):
    """Construct the durable skill evolution service for a tenant."""
    import boto3
    from apps.backend.config.region import AWS_REGION
    from apps.backend.services.skills import SkillEvolutionService

    table = boto3.resource("dynamodb", region_name=AWS_REGION).Table(resolve_table("tenants"))
    return SkillEvolutionService(
        tenant_id=tenant_id,
        dynamo_store=table,
        skill_query_service=SkillQueryService(),
        skill_registrar=SkillRegistrar(),
    )


def _get_skillify_service(tenant_id: str) -> SkillifyService:
    """Construct Skillify service with process-local proposal state for dev/API."""
    return SkillifyService()


def _serialize_skill_evolution(record: Any) -> SkillEvolutionResponse:
    """Normalize service responses into the API contract."""
    if hasattr(record, "__dict__"):
        payload = dict(record.__dict__)
    else:
        payload = dict(record)
    return SkillEvolutionResponse(**payload)


# ============================================================================
# API Endpoints
# ============================================================================


@router.get(
    "",
    response_model=list[SkillListItem],
    status_code=status.HTTP_200_OK,
    summary="List available skills",
    description="List all skills for the authenticated tenant",
)
async def list_skills(
    request: Request,
    status_filter: str | None = Query(default=None, description="Filter by skill status (active, deprecated, draft)"),
    vertical_filter: str | None = Query(default=None, description="Filter by business vertical"),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=200, max_limit=500)),
) -> list[SkillListItem]:
    """List all skills for the authenticated tenant.

    Args:
        request: FastAPI request object
        status_filter: Optional filter by skill status
        vertical_filter: Optional filter by vertical
        pagination: Shared bounded pagination parameters

    Returns:
        List of SkillListItem objects

    Raises:
        HTTPException: If tenant_id header is missing (via middleware)
    """
    tenant_id = get_tenant_id(request)
    user_context = get_user_context(request)

    try:
        query_service = SkillQueryService()

        # List all skills for tenant
        results = query_service.list_tenant_skills(tenant_id)
        results = [r for r in results if _can_access_skill(r, user_context)]

        # Apply filters if provided
        if status_filter:
            results = [r for r in results if r.status == status_filter]
        if vertical_filter:
            results = [r for r in results if r.vertical == vertical_filter]

        # Convert to list items and apply bound
        paged_results, _total = paginate_items(results, pagination)
        skill_list = [_skill_registry_to_list_item(r) for r in paged_results]

        return skill_list

    except Exception as e:
        logger.error(f"Failed to list skills: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list skills",
        )


@router.post(
    "/proposals/{proposal_id}/respond",
    response_model=SkillProposalRespondResponse,
    status_code=status.HTTP_200_OK,
    summary="Respond to a Skillify proposal",
)
async def respond_to_skill_proposal(
    request: Request,
    body: SkillProposalRespondRequest,
    proposal_id: str = Path(..., description="Skillify proposal identifier"),
) -> SkillProposalRespondResponse:
    """Classify and store a natural-language dedup/new/skip response."""
    tenant_id = get_tenant_id(request)
    service = _get_skillify_service(tenant_id)
    try:
        response = service.respond_to_proposal(
            tenant_id=tenant_id,
            proposal_id=proposal_id,
            response_text=body.response,
        )
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    payload = response.to_dict() if hasattr(response, "to_dict") else vars(response)
    return SkillProposalRespondResponse(**payload)



@router.post(
    "/import",
    response_model=SkillSourceImportResponse,
    status_code=status.HTTP_200_OK,
    summary="Import governed SkillSource",
    description="Run SkillSource alignment/import policy for the authenticated workspace.",
)
async def import_skill_source(
    request: Request,
    body: SkillSourceImportRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    _admin: UserRole = Depends(require_admin_user_role),
) -> SkillSourceImportResponse:
    """Run governed SkillSource import through the canonical importer."""
    tenant_id = _resolved_executable_skill_tenant_id(request, tenant_id)
    if body.workspace_id != tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="workspace_id must match authenticated tenant_id",
        )
    try:
        return run_skill_source_import(body)
    except SkillSourceImportError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

@router.get(
    "/{skill_id}",
    response_model=SkillResponse,
    status_code=status.HTTP_200_OK,
    summary="Get skill definition",
    description="Get skill definition by skill_id",
)
async def get_skill(request: Request, skill_id: str = Path(..., description="Skill identifier")) -> SkillResponse:
    """Get skill definition by skill_id.

    Args:
        request: FastAPI request object
        skill_id: Skill identifier

    Returns:
        SkillResponse object

    Raises:
        HTTPException: If skill not found or tenant_id header is missing
    """
    tenant_id = get_tenant_id(request)
    user_context = get_user_context(request)

    try:
        query_service = SkillQueryService()

        result = _find_skill_registry_by_skill_id(
            query_service=query_service,
            tenant_id=tenant_id,
            skill_id=skill_id,
        )

        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Skill not found: {skill_id}",
            )
        _assert_can_access_skill(result, user_context)

        return _skill_registry_to_response(result)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get skill {skill_id}: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get skill",
        )


@router.post(
    "",
    response_model=SkillResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create new skill",
    description="Create a new skill (tenant override)",
)
async def create_skill(request: Request, skill_request: SkillCreateRequest) -> SkillResponse:
    """Create a new skill.

    Args:
        request: FastAPI request object
        skill_request: Skill creation request

    Returns:
        Created SkillResponse object

    Raises:
        HTTPException: If tenant_id header is missing or creation fails
    """
    tenant_id = get_tenant_id(request)
    user_context = get_user_context(request)

    try:
        registrar = SkillRegistrar()

        # Create Skill object from request
        skill = Skill(
            skill_id=skill_request.skill_id,
            display_name=skill_request.display_name,
            description=skill_request.description,
            vertical=skill_request.vertical,
            role_category=skill_request.role_category,
            triggers=skill_request.triggers,
            prompt=skill_request.prompt,
            input_schema_ref=skill_request.input_schema_ref,
            output_schema_ref=skill_request.output_schema_ref,
            version=skill_request.version,
            status=skill_request.status,
            visibility_scope=skill_request.visibility_scope,
            tags=skill_request.tags,
            localization=skill_request.localization,
        )

        compiled_skill = CompiledSkill(
            skill_id=skill.skill_id,
            skill_instance_id=_new_skill_instance_id(),
            display_name=skill.display_name,
            description=skill.description,
            vertical=skill.vertical,
            role_category=skill.role_category,
            triggers=skill.triggers,
            input_schema_ref=skill.input_schema_ref,
            output_schema_ref=skill.output_schema_ref,
            prompt=skill.prompt,
            version=skill.version,
            status=skill.status,
            tags=skill.tags,
            localization=skill.localization,
            visibility_scope=skill.visibility_scope,
        )

        # Register compiled skill in DynamoDB
        result = registrar.register_skill(
            compiled_skill=compiled_skill,
            tenant_id=tenant_id,
            owner_user_id=user_context.user_id if user_context else None,
        )
        # Backward compatibility:
        # - canonical path returns RegistrationResult(success, skill_registry, error)
        # - older call sites/mocks may still return SkillRegistry directly
        if hasattr(result, "success"):
            if not result.success or result.skill_registry is None:
                message = result.error or "Unknown registration failure"
                raise RuntimeError(f"Skill registration failed: {message}")
            skill_registry = result.skill_registry
        else:
            skill_registry = result
            if skill_registry is None:
                raise RuntimeError("Skill registration failed: missing registry record")

        return _skill_registry_to_response(skill_registry)

    except Exception as e:
        logger.error(f"Failed to create skill: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create skill",
        )


@router.patch(
    "/{skill_id}",
    response_model=SkillResponse,
    status_code=status.HTTP_200_OK,
    summary="Update skill",
    description="Update an existing skill",
)
async def update_skill(
    request: Request,
    skill_id: str = Path(..., description="Skill identifier"),
    skill_request: SkillUpdateRequest = ...,
) -> SkillResponse:
    """Update an existing skill.

    Args:
        request: FastAPI request object
        skill_id: Skill identifier
        skill_request: Skill update request

    Returns:
        Updated SkillResponse object

    Raises:
        HTTPException: If skill not found or update fails
    """
    tenant_id = get_tenant_id(request)
    user_context = get_user_context(request)

    try:
        query_service = SkillQueryService()
        registry_service = UnifiedSkillRegistry(dynamodb_table=query_service.table)

        # Get existing skill
        result = _find_skill_registry_by_skill_id(
            query_service=query_service,
            tenant_id=tenant_id,
            skill_id=skill_id,
        )

        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Skill not found: {skill_id}",
            )
        _assert_can_modify_skill(result, user_context)

        metadata_updates: dict[str, Any] = {}
        if skill_request.display_name is not None:
            metadata_updates["display_name"] = skill_request.display_name
        if skill_request.description is not None:
            metadata_updates["description"] = skill_request.description
        if skill_request.prompt is not None:
            metadata_updates["prompt"] = skill_request.prompt
        if skill_request.tags is not None:
            metadata_updates["tags"] = skill_request.tags
        if skill_request.localization is not None:
            metadata_updates["localization"] = skill_request.localization

        updated_metadata = _merge_registry_metadata(
            result,
            metadata_updates=metadata_updates,
            status_override=skill_request.status,
        )
        registry_service.update_skill(
            tenant_id=tenant_id,
            skill_instance_id=result.skill_instance_id,
            metadata=updated_metadata,
        )

        refreshed = _find_skill_registry_by_skill_id(
            query_service=query_service,
            tenant_id=tenant_id,
            skill_id=skill_id,
        )
        if not refreshed:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to reload skill after update: {skill_id}",
            )

        return _skill_registry_to_response(refreshed)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to update skill {skill_id}: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to update skill",
        )


@router.delete(
    "/{skill_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete skill",
    description="Delete a skill",
)
async def delete_skill(request: Request, skill_id: str = Path(..., description="Skill identifier")):
    """Delete a skill.

    Args:
        request: FastAPI request object
        skill_id: Skill identifier

    Raises:
        HTTPException: If skill not found or deletion fails
    """
    tenant_id = get_tenant_id(request)
    user_context = get_user_context(request)

    try:
        query_service = SkillQueryService()

        # Verify skill exists
        result = _find_skill_registry_by_skill_id(
            query_service=query_service,
            tenant_id=tenant_id,
            skill_id=skill_id,
        )

        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Skill not found: {skill_id}",
            )
        _assert_can_modify_skill(result, user_context)

        UnifiedSkillRegistry(dynamodb_table=query_service.table).delete_skill(
            tenant_id=tenant_id,
            skill_instance_id=result.skill_instance_id,
        )

        logger.info(f"Skill {skill_id} deleted for tenant {tenant_id}")

        return None

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to delete skill {skill_id}: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to delete skill",
        )


@router.post(
    "/{skill_id}/retire",
    response_model=SkillResponse,
    status_code=status.HTTP_200_OK,
    summary="Retire or supersede skill",
    description="Mark a skill retired or superseded without deleting lineage",
)
async def retire_skill(
    request: Request,
    body: SkillRetireRequest,
    skill_id: str = Path(..., description="Skill identifier"),
) -> SkillResponse:
    """Retire a skill while preserving governed lineage and provenance."""
    tenant_id = get_tenant_id(request)

    try:
        query_service = SkillQueryService()
        registry_entry = _find_skill_registry_by_skill_id(
            query_service=query_service,
            tenant_id=tenant_id,
            skill_id=skill_id,
        )
        if not registry_entry:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Skill not found: {skill_id}",
            )

        registry_service = UnifiedSkillRegistry(dynamodb_table=query_service.table)
        registry_service.retire_skill(
            tenant_id=tenant_id,
            skill_instance_id=registry_entry.skill_instance_id,
            reason=body.reason,
            superseded_by_skill_id=body.superseded_by_skill_id,
        )

        refreshed = _find_skill_registry_by_skill_id(
            query_service=query_service,
            tenant_id=tenant_id,
            skill_id=skill_id,
        )
        if not refreshed:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=f"Failed to reload skill after retirement: {skill_id}",
            )

        return _skill_registry_to_response(refreshed)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to retire skill {skill_id}: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retire skill",
        )


@router.post(
    "/{skill_id}/test",
    response_model=SkillTestResponse,
    status_code=status.HTTP_200_OK,
    summary="Test skill with scenarios",
    description="Test a skill with test scenarios",
)
async def test_skill(
    request: Request,
    skill_id: str = Path(..., description="Skill identifier"),
    test_request: SkillTestRequest = ...,
) -> SkillTestResponse:
    """Test a skill with test scenarios.

    Args:
        request: FastAPI request object
        skill_id: Skill identifier
        test_request: Skill test request

    Returns:
        SkillTestResponse with test results

    Raises:
        HTTPException: If skill not found or test fails
    """
    tenant_id = get_tenant_id(request)

    try:
        query_service = SkillQueryService()

        # Verify skill exists
        result = _find_skill_registry_by_skill_id(
            query_service=query_service,
            tenant_id=tenant_id,
            skill_id=skill_id,
        )

        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Skill not found: {skill_id}",
            )

        # Skill test engine not yet wired — return honest result
        return SkillTestResponse(
            success=False,
            output=None,
            error="Skill testing engine not yet available",
            duration_ms=0.0,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to test skill {skill_id}: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to test skill",
        )


@router.patch(
    "/tenants/{tenant_id}/skills/{skill_id}",
    status_code=status.HTTP_200_OK,
    summary="Enable/disable skill",
    description="Toggle skill enable/disable status",
)
async def enable_disable_skill(
    request: Request,
    tenant_id: str = Path(..., description="Tenant identifier (without TENANT# prefix)"),
    skill_id: str = Path(..., description="Skill identifier"),
    enable_request: SkillEnableDisableRequest = ...,
) -> dict[str, str]:
    """Enable or disable a skill.

    Args:
        tenant_id: Tenant identifier (from URL path, without TENANT# prefix)
        skill_id: Skill identifier
        enable_request: Enable/disable request

    Returns:
        Dictionary with status message

    Raises:
        HTTPException: If skill not found or update fails
    """
    path_tenant_id = f"TENANT#{tenant_id}"
    authenticated_tenant_id = get_tenant_id(request)
    if authenticated_tenant_id != path_tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Forbidden: organization mismatch.",
        )

    try:
        query_service = SkillQueryService()
        registry_service = UnifiedSkillRegistry(dynamodb_table=query_service.table)

        # Verify skill exists
        result = _find_skill_registry_by_skill_id(
            query_service=query_service,
            tenant_id=path_tenant_id,
            skill_id=skill_id,
        )

        if not result:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Skill not found: {skill_id}",
            )

        new_status = "active" if enable_request.enabled else "deprecated"
        updated_metadata = _merge_registry_metadata(
            result,
            status_override=new_status,
        )
        registry_service.update_skill(
            tenant_id=path_tenant_id,
            skill_instance_id=result.skill_instance_id,
            metadata=updated_metadata,
        )

        logger.info(f"Skill {skill_id} status persisted to {new_status}")

        return {"status": new_status, "message": f"Skill {skill_id} {new_status}"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to enable/disable skill {skill_id}: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to enable/disable skill",
        )


@router.get(
    "/evolution/queue",
    response_model=list[SkillEvolutionResponse],
    status_code=status.HTTP_200_OK,
    summary="List durable skill evolution queue",
)
async def list_skill_evolution_queue(
    request: Request,
    status_filter: str | None = Query(default=None, description="Optional proposal status filter"),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> list[SkillEvolutionResponse]:
    """List durable prompt/version evolution proposals across all skills."""
    tenant_id = get_tenant_id(request)
    service = _get_skill_evolution_service(tenant_id)
    records = service.list_improvements(status=status_filter)
    serialized = [_serialize_skill_evolution(record) for record in records]
    paged_records, _total = paginate_items(serialized, pagination)
    return paged_records


@router.get(
    "/{skill_id}/evolution",
    response_model=list[SkillEvolutionResponse],
    status_code=status.HTTP_200_OK,
    summary="List durable skill evolution proposals",
)
async def list_skill_evolution(
    request: Request,
    skill_id: str = Path(..., description="Skill identifier"),
    status_filter: str | None = Query(default=None, description="Optional proposal status filter"),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> list[SkillEvolutionResponse]:
    """List durable prompt/version evolution proposals for a skill."""
    tenant_id = get_tenant_id(request)
    service = _get_skill_evolution_service(tenant_id)
    records = service.list_improvements(status=status_filter, skill_id=skill_id)
    serialized = [_serialize_skill_evolution(record) for record in records]
    paged_records, _total = paginate_items(serialized, pagination)
    return paged_records


@router.post(
    "/{skill_id}/evolution/propose",
    response_model=SkillEvolutionResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create durable skill evolution proposal",
)
async def propose_skill_evolution(
    request: Request,
    body: SkillEvolutionRequest,
    skill_id: str = Path(..., description="Skill identifier"),
) -> SkillEvolutionResponse:
    """Create a durable reviewed improvement proposal for a skill."""
    tenant_id = get_tenant_id(request)
    service = _get_skill_evolution_service(tenant_id)
    proposal = service.propose_improvement(skill_id=skill_id, failure_patterns=body.failure_patterns)
    return _serialize_skill_evolution(proposal)


@router.post(
    "/{skill_id}/evolution/{improvement_id}/validate",
    response_model=SkillEvolutionResponse,
    status_code=status.HTTP_200_OK,
    summary="Validate queued skill evolution proposal with shadow metrics",
)
async def validate_skill_evolution(
    request: Request,
    body: SkillEvolutionValidationRequest,
    skill_id: str = Path(..., description="Skill identifier"),
    improvement_id: str = Path(..., description="Improvement identifier"),
) -> SkillEvolutionResponse:
    """Run regression gates for a queued prompt/version mutation."""
    tenant_id = get_tenant_id(request)
    service = _get_skill_evolution_service(tenant_id)
    validated = await service.validate_improvement(
        skill_id=skill_id,
        improvement_id=improvement_id,
        candidate_metrics=body.candidate_metrics,
    )
    if not validated:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Improvement not found or not validatable: {improvement_id}",
        )
    return _serialize_skill_evolution(validated)


@router.post(
    "/{skill_id}/evolution/{improvement_id}/apply",
    response_model=SkillEvolutionResponse,
    status_code=status.HTTP_200_OK,
    summary="Apply durable skill evolution proposal",
)
async def apply_skill_evolution(
    request: Request,
    skill_id: str = Path(..., description="Skill identifier"),
    improvement_id: str = Path(..., description="Improvement identifier"),
) -> SkillEvolutionResponse:
    """Apply a reviewed prompt/version mutation for a skill."""
    tenant_id = get_tenant_id(request)
    service = _get_skill_evolution_service(tenant_id)
    applied = service.apply_improvement(skill_id=skill_id, improvement_id=improvement_id)
    if not applied:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Improvement not found or not applicable: {improvement_id}",
        )
    record = next(
        (item for item in service.list_improvements(skill_id=skill_id) if item.get("improvement_id") == improvement_id),
        None,
    )
    if not record:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to reload improvement after apply: {improvement_id}",
        )
    return _serialize_skill_evolution(record)


@router.post(
    "/{skill_id}/evolution/{improvement_id}/reject",
    response_model=SkillEvolutionResponse,
    status_code=status.HTTP_200_OK,
    summary="Reject durable skill evolution proposal",
)
async def reject_skill_evolution(
    request: Request,
    body: SkillEvolutionRejectRequest,
    skill_id: str = Path(..., description="Skill identifier"),
    improvement_id: str = Path(..., description="Improvement identifier"),
) -> SkillEvolutionResponse:
    """Reject a durable skill evolution proposal."""
    tenant_id = get_tenant_id(request)
    service = _get_skill_evolution_service(tenant_id)
    rejected = service.reject_improvement(
        skill_id=skill_id,
        improvement_id=improvement_id,
        reason=body.reason,
    )
    if not rejected:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Improvement not found or not rejectable: {improvement_id}",
        )
    record = next(
        (item for item in service.list_improvements(skill_id=skill_id) if item.get("improvement_id") == improvement_id),
        None,
    )
    if not record:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to reload improvement after reject: {improvement_id}",
        )
    return _serialize_skill_evolution(record)


@router.post(
    "/{skill_id}/evolution/{improvement_id}/rollback",
    response_model=SkillEvolutionResponse,
    status_code=status.HTTP_200_OK,
    summary="Rollback durable skill evolution proposal",
)
async def rollback_skill_evolution(
    request: Request,
    skill_id: str = Path(..., description="Skill identifier"),
    improvement_id: str = Path(..., description="Improvement identifier"),
) -> SkillEvolutionResponse:
    """Rollback an applied prompt/version mutation for a skill."""
    tenant_id = get_tenant_id(request)
    service = _get_skill_evolution_service(tenant_id)
    rolled_back = service.rollback_improvement(skill_id=skill_id, improvement_id=improvement_id)
    if not rolled_back:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Improvement not found or not rollbackable: {improvement_id}",
        )
    record = next(
        (item for item in service.list_improvements(skill_id=skill_id) if item.get("improvement_id") == improvement_id),
        None,
    )
    if not record:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to reload improvement after rollback: {improvement_id}",
        )
    return _serialize_skill_evolution(record)


# ---------------------------------------------------------------------------
# Skillify Drift Detection endpoints (#2333)
# ---------------------------------------------------------------------------


class DriftReportResponse(BaseModel):
    """API representation of a drift report."""

    skill_id: str
    tenant_id: str
    promotion_baseline: float
    rolling_7d: float
    drop_pct: float
    sample_n: int
    recommended_action: str
    risk_tier: str = "LOW"
    staleness: str | None = None


class DemoteRequest(BaseModel):
    """Request model for drift-initiated demotion."""

    reason: str = Field(default="drift_detected", min_length=1, description="Demotion reason")


class DemoteResponse(BaseModel):
    """API representation of a demotion proposal outcome."""

    skill_id: str
    tenant_id: str
    status: str
    rollback_initiated: bool = False


@router.get(
    "/{skill_id}/drift",
    response_model=DriftReportResponse,
    status_code=status.HTTP_200_OK,
    summary="Get drift status for a skill",
)
async def get_skill_drift(
    request: Request,
    skill_id: str = Path(..., description="Skill identifier"),
) -> DriftReportResponse:
    """Evaluate a promoted skill for quality_score drift over the past 7 days."""
    tenant_id = get_tenant_id(request)
    drift_svc = _get_drift_service(tenant_id)
    report = drift_svc.evaluate_drift(tenant_id, skill_id)
    return DriftReportResponse(**report.to_dict())


@router.post(
    "/{skill_id}/demote",
    response_model=DemoteResponse,
    status_code=status.HTTP_200_OK,
    summary="Propose or execute demotion for a drifting skill",
)
async def demote_skill(
    request: Request,
    skill_id: str = Path(..., description="Skill identifier"),
    body: DemoteRequest | None = None,
) -> DemoteResponse:
    """Propose demotion for a skill with detected drift.

    LOW/MED risk tiers auto-apply. HIGH/EXEC require validator pool quorum.
    """
    tenant_id = get_tenant_id(request)
    drift_svc = _get_drift_service(tenant_id)
    report = drift_svc.evaluate_drift(tenant_id, skill_id)
    proposal = await drift_svc.propose_demotion(
        tenant_id=tenant_id,
        skill_id=skill_id,
        drift_report=report,
        validator_pool=None,
    )
    return DemoteResponse(
        skill_id=proposal.skill_id,
        tenant_id=proposal.tenant_id,
        status=proposal.status,
        rollback_initiated=proposal.rollback_initiated,
    )


def _get_drift_service(tenant_id: str) -> Any:
    """Lazily construct a SkillifyDriftService for the given tenant."""
    from apps.backend.services.skills.drift_detector import SkillifyDriftService
    from apps.backend.services.skills.promotion.rollback import RollbackService

    # Use in-memory stores by default; production wiring replaces these
    # with DynamoDB-backed implementations via dependency injection.
    metrics_store = _InMemoryMetricsStore()
    baseline_store = _InMemoryBaselineStore()
    rollback_service = RollbackService()

    return SkillifyDriftService(
        metrics_store=metrics_store,
        baseline_store=baseline_store,
        rollback_service=rollback_service,
    )


class _InMemoryMetricsStore:
    """Placeholder metrics store for API endpoint bootstrapping.

    Production deployments replace this with the compounding telemetry
    substrate (Issue compounding-telemetry).
    """

    def get_rolling_samples(self, tenant_id: str, skill_id: str, window_days: int = 7) -> list[dict[str, Any]]:
        return []


class _InMemoryBaselineStore:
    """Placeholder baseline store for API endpoint bootstrapping."""

    def get_baseline(self, tenant_id: str, skill_id: str) -> dict[str, Any] | None:
        return None


@router.post(
    "/upload",
    status_code=status.HTTP_201_CREATED,
    summary="Upload executable skill package",
    description="Install a zip-packaged executable skill for the authenticated tenant",
)
@router.post(
    "/packages/upload",
    status_code=status.HTTP_201_CREATED,
    summary="Upload executable skill package",
    description="Install a zip-packaged executable skill for the authenticated tenant",
    include_in_schema=False,
)
async def upload_skill_package(
    request: Request,
    archive: UploadFile = File(...),
    tenant_id: str = Depends(get_verified_tenant_id),
    _admin: UserRole = Depends(require_admin_user_role),
) -> dict[str, Any]:
    """Install an executable skill package from uploaded zip archive."""
    tenant_id = _resolved_executable_skill_tenant_id(request, tenant_id)
    try:
        payload = await archive.read()
        validate_skill_archive_upload(
            filename=archive.filename,
            content=payload,
            declared_content_type=getattr(archive, "content_type", None),
        )
        package = get_executable_skill_platform().install_from_zip_bytes(
            tenant_id=tenant_id,
            archive_bytes=payload,
            source=SkillInstallSource.UPLOAD,
            source_ref=archive.filename or "upload.zip",
        )
        return {
            "installed": True,
            "package": package.to_dict(),
        }
    except SkillPackageValidationError as exc:
        logger.warning("upload_skill_package validation error: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Skill package validation failed",
        ) from exc
    except UploadValidationError as exc:
        logger.warning("upload_skill_package upload validation error: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Upload validation failed",
        ) from exc


@router.post(
    "/import/github",
    status_code=status.HTTP_201_CREATED,
    summary="Import executable skill package from GitHub",
)
@router.post(
    "/packages/import",
    status_code=status.HTTP_201_CREATED,
    summary="Import executable skill package from GitHub",
    include_in_schema=False,
)
async def import_skill_package(
    request: Request,
    body: SkillPackageImportRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    _admin: UserRole = Depends(require_admin_user_role),
) -> dict[str, Any]:
    """Import and install a skill package from a GitHub repository."""
    tenant_id = _resolved_executable_skill_tenant_id(request, tenant_id)
    try:
        package = get_executable_skill_platform().import_from_github(
            tenant_id=tenant_id,
            github_url=body.github_url,
            ref=body.ref,
            subpath=body.subpath,
        )
        return {
            "installed": True,
            "package": package.to_dict(),
        }
    except SkillPackageValidationError as exc:
        logger.warning("import_skill_package validation error: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Skill package validation failed",
        ) from exc


@router.post(
    "/{skill_id}/runs",
    status_code=status.HTTP_200_OK,
    summary="Run installed executable skill",
)
@router.post(
    "/{skill_id}/run",
    status_code=status.HTTP_200_OK,
    summary="Run installed executable skill",
    include_in_schema=False,
)
async def run_skill_package(
    request: Request,
    skill_id: str,
    body: SkillRunRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    _admin: UserRole = Depends(require_admin_user_role),
) -> dict[str, Any]:
    """Run an installed skill package with runtime policy controls."""
    tenant_id = _resolved_executable_skill_tenant_id(request, tenant_id)
    try:
        run_record = await get_executable_skill_platform().run_skill(
            tenant_id=tenant_id,
            skill_id=skill_id,
            payload=body.input_data,
            idempotency_key=body.idempotency_key,
        )
        return run_record.to_dict()
    except SkillRuntimeError as exc:
        logger.warning("run_skill_package runtime error skill=%s: %s", skill_id, exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Skill execution failed",
        ) from exc


@router.get(
    "/runs/{run_id}",
    status_code=status.HTTP_200_OK,
    summary="Get executable skill run status",
    include_in_schema=False,
)
async def get_skill_run_status(
    request: Request,
    run_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    _admin: UserRole = Depends(require_admin_user_role),
) -> dict[str, Any]:
    """Return run status for a previously executed skill run."""
    tenant_id = _resolved_executable_skill_tenant_id(request, tenant_id)
    run_record = get_executable_skill_platform().get_run_status(tenant_id, run_id)
    if run_record is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Run not found: {run_id}",
        )
    return run_record.to_dict()


@router.get(
    "/{skill_id}/runs/{run_id}",
    status_code=status.HTTP_200_OK,
    summary="Get executable skill run status",
)
async def get_skill_run_status_for_skill(
    request: Request,
    skill_id: str,
    run_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    _admin: UserRole = Depends(require_admin_user_role),
) -> dict[str, Any]:
    """Return run status for a previously executed skill run under a skill scope."""
    tenant_id = _resolved_executable_skill_tenant_id(request, tenant_id)
    run_record = get_executable_skill_platform().get_run_status(tenant_id, run_id)
    if run_record is None or run_record.skill_id != skill_id:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Run not found for skill: {skill_id}/{run_id}",
        )
    return run_record.to_dict()


@router.post(
    "/chains/validate",
    status_code=status.HTTP_200_OK,
    summary="Validate typed chain contracts",
)
async def validate_skill_chain_contracts(
    request: Request,
    body: SkillChainRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    _admin: UserRole = Depends(require_admin_user_role),
) -> dict[str, Any]:
    """Validate output-input contract compatibility across an ordered skill chain."""
    tenant_id = _resolved_executable_skill_tenant_id(request, tenant_id)
    is_valid, errors = get_executable_skill_platform().validate_chain_contracts(
        tenant_id=tenant_id,
        skill_ids=body.skill_ids,
    )
    return {
        "valid": is_valid,
        "errors": errors,
        "skill_ids": body.skill_ids,
    }


@router.post(
    "/chains/run",
    status_code=status.HTTP_200_OK,
    summary="Run chain of executable skills",
)
async def run_skill_chain(
    request: Request,
    body: SkillChainRunRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    _admin: UserRole = Depends(require_admin_user_role),
) -> dict[str, Any]:
    """Run a chain of installed skills after validating chain contracts."""
    tenant_id = _resolved_executable_skill_tenant_id(request, tenant_id)
    try:
        result = await get_executable_skill_platform().run_chain(
            tenant_id=tenant_id,
            skill_ids=body.skill_ids,
            payload=body.input_data,
            idempotency_prefix=body.idempotency_prefix,
        )
        return result
    except SkillRuntimeError as exc:
        logger.warning("run_chain runtime error: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Skill chain execution failed",
        ) from exc
