"""Connector locality kernel surface (#2880).

Routes:

* ``GET /api/v1/kernel/connector-locality`` — full matrix summary
  (entry counts, per-side-effect-class counts, cloud-required class
  list).
* ``GET /api/v1/kernel/connector-locality/{connector}/{operation}`` —
  per-operation explanation: decision (LOCAL_ELIGIBLE /
  CLOUD_REQUIRED / POLICY_REQUIRED / UNSUPPORTED_LOCAL), reason,
  policy modes considered.

The matrix itself is global; tenant-scoped policy modes can still
narrow the decision via the ``policy_modes`` query parameter on the
explanation route.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.connectors.locality_matrix import (
    DEFAULT_LOCALITY_MATRIX,
    ConnectorLocalityMatrix,
)


router = APIRouter(
    prefix="/api/v1/kernel/connector-locality",
    tags=["kernel", "connector-locality"],
)


class ConnectorLocalityEntryRow(BaseModel):
    connector_name: str
    operation: str
    side_effect_class: str
    allowed_localities: list[str]
    fallback: str
    policy_reason: str
    is_local_eligible: bool


class ConnectorLocalitySummaryResponse(BaseModel):
    """Full matrix projection used by the awareness digest."""

    entry_count: int = 0
    local_eligible_count: int = 0
    cloud_required_count: int = 0
    cloud_required_classes: list[str] = Field(default_factory=list)
    by_side_effect_class: dict[str, int] = Field(default_factory=dict)
    entries: list[ConnectorLocalityEntryRow] = Field(default_factory=list)


class ConnectorLocalityExplanationResponse(BaseModel):
    """Per-operation locality explanation."""

    connector_name: str
    operation: str
    decision: str
    side_effect_class: str
    reason: str
    allowed_localities: list[str]
    fallback: str
    policy_modes: list[str]


def _matrix() -> ConnectorLocalityMatrix:
    return DEFAULT_LOCALITY_MATRIX


@router.get("", response_model=ConnectorLocalitySummaryResponse)
def list_connector_locality(
    tenant_id: str = Depends(get_verified_tenant_id),  # noqa: ARG001 — auth gate
) -> ConnectorLocalitySummaryResponse:
    """Return the full connector locality matrix summary."""
    payload = _matrix().tenant_locality_summary()
    rows = [ConnectorLocalityEntryRow(**row) for row in payload.get("entries", [])]
    return ConnectorLocalitySummaryResponse(
        entry_count=int(payload.get("entry_count") or 0),
        local_eligible_count=int(payload.get("local_eligible_count") or 0),
        cloud_required_count=int(payload.get("cloud_required_count") or 0),
        cloud_required_classes=list(payload.get("cloud_required_classes") or []),
        by_side_effect_class=dict(payload.get("by_side_effect_class") or {}),
        entries=rows,
    )


@router.get(
    "/{connector_name}/{operation}",
    response_model=ConnectorLocalityExplanationResponse,
)
def explain_connector_locality(
    connector_name: str,
    operation: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    policy_modes: list[str] = Query(default_factory=list),
) -> ConnectorLocalityExplanationResponse:
    """Return the locality decision + reason for one connector/op pair."""
    explanation = _matrix().explain(
        connector_name,
        operation,
        policy_modes=list(policy_modes),
        tenant_id=tenant_id,
    )
    return ConnectorLocalityExplanationResponse(
        connector_name=explanation.connector_name,
        operation=explanation.operation,
        decision=explanation.decision.value,
        side_effect_class=explanation.side_effect_class.value,
        reason=explanation.reason,
        allowed_localities=[loc.value for loc in explanation.allowed_localities],
        fallback=explanation.fallback,
        policy_modes=list(explanation.policy_modes),
    )


__all__ = [
    "router",
    "ConnectorLocalityEntryRow",
    "ConnectorLocalitySummaryResponse",
    "ConnectorLocalityExplanationResponse",
    "list_connector_locality",
    "explain_connector_locality",
]
