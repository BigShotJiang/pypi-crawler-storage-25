"""Meta-Observer API -- cross-subsystem improvement coordination.

Endpoints:
    GET  /api/v1/meta/observations              -- recent observations
    GET  /api/v1/meta/proposals                  -- threshold proposals and states
    POST /api/v1/meta/proposals/{id}/shadow      -- move proposal to shadow
    POST /api/v1/meta/proposals/{id}/resolve     -- promote or reject after shadow
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Path, Query, status
from pydantic import BaseModel

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/meta", tags=["meta-observer"])


# ---------------------------------------------------------------------------
# Request/response models
# ---------------------------------------------------------------------------


class ShadowRequest(BaseModel):
    """Request body for entering shadow state."""

    shadow_days: int = 7


class ResolveRequest(BaseModel):
    """Request body for promoting or rejecting a proposal."""

    regression_detected: bool


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_service() -> Any:
    from apps.backend.services.meta_observer import get_meta_observer

    return get_meta_observer()


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("/observations")
def list_observations(
    source: str | None = Query(None, description="Filter by ObservationSource value"),
    limit: int = Query(20, ge=1, le=100, description="Max observations to return"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[dict[str, Any]]:
    """Return recent observations from improvement subsystems."""
    svc = _get_service()

    from apps.backend.services.meta_observer import ObservationSource

    filtered_source = None
    if source is not None:
        try:
            filtered_source = ObservationSource(source)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid source: {source}. Valid: {[s.value for s in ObservationSource]}",
            )

    observations = svc.get_observations(source=filtered_source, limit=limit)
    return [
        {
            "source": obs.source.value,
            "signal": obs.signal,
            "evidence": obs.evidence,
            "timestamp": obs.timestamp,
            "severity": obs.severity,
        }
        for obs in observations
    ]


@router.get("/proposals")
def list_proposals(
    state: str | None = Query(None, description="Filter by ProposalState value"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[dict[str, Any]]:
    """Return threshold proposals and their lifecycle states."""
    svc = _get_service()

    from apps.backend.services.meta_observer import ProposalState

    filtered_state = None
    if state is not None:
        try:
            filtered_state = ProposalState(state)
        except ValueError:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Invalid state: {state}. Valid: {[s.value for s in ProposalState]}",
            )

    proposals = svc.get_proposals(state=filtered_state)
    return [
        {
            "proposal_id": p.proposal_id,
            "proposal_type": p.proposal_type.value,
            "target_service": p.target_service.value,
            "target_parameter": p.target_parameter,
            "current_value": p.current_value,
            "proposed_value": p.proposed_value,
            "rationale": p.rationale,
            "anti_overfit_check": p.anti_overfit_check,
            "state": p.state.value,
            "proposed_at": p.proposed_at,
            "shadow_until": p.shadow_until,
            "evidence": p.evidence,
        }
        for p in proposals
    ]


@router.post("/proposals/{proposal_id}/shadow")
def enter_shadow(
    proposal_id: str = Path(..., description="Proposal ID to move into shadow"),
    body: ShadowRequest = ShadowRequest(),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Move a proposal into SHADOW state for monitoring."""
    svc = _get_service()
    success = svc.enter_shadow(proposal_id, shadow_days=body.shadow_days)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Proposal {proposal_id} not found or not in PROPOSED state",
        )
    return {"proposal_id": proposal_id, "state": "shadow", "shadow_days": body.shadow_days}


@router.post("/proposals/{proposal_id}/resolve")
def resolve_proposal(
    proposal_id: str = Path(..., description="Proposal ID to resolve"),
    body: ResolveRequest = ...,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Promote or reject a proposal after its shadow period."""
    svc = _get_service()

    from apps.backend.services.meta_observer import ProposalState

    result_state = svc.promote_or_reject(proposal_id, regression_detected=body.regression_detected)
    if result_state == ProposalState.EXPIRED:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Proposal {proposal_id} not found or not in SHADOW state",
        )
    return {
        "proposal_id": proposal_id,
        "state": result_state.value,
        "regression_detected": body.regression_detected,
    }
