"""Quick Actions API — list and execute quick actions from the Mission surface.

Routes:
    GET  /api/v1/quick-actions                       — List available actions
    POST /api/v1/quick-actions/{action_id}/execute   — Execute a specific action
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, ConfigDict, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.quick_actions import (
    QuickActionDef,
    QuickActionRegistry,
    create_default_registry,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/quick-actions", tags=["quick-actions"])


def _get_feature_flag_service():
    from apps.backend.services.feature_flags import get_feature_flags

    return get_feature_flags()


# ---------------------------------------------------------------------------
# Gate B actions (registered but gated — not yet shipped)
# ---------------------------------------------------------------------------

GATE_B_ACTIONS: list[QuickActionDef] = [
    QuickActionDef(
        action_id="followup",
        label="Follow Up",
        description="Automated follow-up on stale conversations",
        required_feature_flags=["gate_b_followup"],
        handler_name="followup_handler",
        is_shipped=False,
    ),
    QuickActionDef(
        action_id="crm_sync",
        label="CRM Sync",
        description="Sync latest interactions to CRM records",
        required_feature_flags=["gate_b_crm_sync"],
        handler_name="crm_sync_handler",
        is_shipped=False,
    ),
    QuickActionDef(
        action_id="call_prep",
        label="Call Prep",
        description="Prepare briefing notes before a scheduled call",
        required_feature_flags=["gate_b_call_prep"],
        handler_name="call_prep_handler",
        is_shipped=False,
    ),
    QuickActionDef(
        action_id="meeting_followup",
        label="Meeting Follow-up",
        description="Auto-generate and send meeting follow-up actions",
        required_feature_flags=["gate_b_meeting_followup"],
        handler_name="meeting_followup_handler",
        is_shipped=False,
    ),
]


# ---------------------------------------------------------------------------
# Registry singleton
# ---------------------------------------------------------------------------


_registry: QuickActionRegistry | None = None


def _get_registry() -> QuickActionRegistry:
    """Get or create the singleton quick action registry."""
    global _registry  # noqa: PLW0603
    if _registry is None:
        _registry = create_default_registry()
        for action in GATE_B_ACTIONS:
            _registry.register(action)
    return _registry


# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------


class QuickActionResponse(BaseModel):
    """Single quick action in the list response."""

    action_id: str
    label: str
    description: str
    is_shipped: bool
    required_feature_flags: list[str] = Field(default_factory=list)


class QuickActionListResponse(BaseModel):
    """Response for listing available quick actions."""

    actions: list[QuickActionResponse]
    total: int


class QuickActionExecuteRequest(BaseModel):
    """Request body for executing a quick action."""

    model_config = ConfigDict(extra="forbid")
    params: dict[str, Any] | None = None


class QuickActionExecuteResponse(BaseModel):
    """Response after executing a quick action."""

    action_id: str
    status: str
    output: dict[str, Any] | None = None
    error: str | None = None


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("", response_model=QuickActionListResponse)
async def list_quick_actions(
    shipped_only: bool = Query(False, description="Only return shipped (Gate A) actions"),
    tenant_id: str = Depends(get_verified_tenant_id),
    registry: QuickActionRegistry = Depends(_get_registry),
) -> QuickActionListResponse:
    """List all registered quick actions, optionally filtered to shipped-only."""
    actions = registry.list_actions(shipped_only=shipped_only)
    return QuickActionListResponse(
        actions=[
            QuickActionResponse(
                action_id=a.action_id,
                label=a.label,
                description=a.description,
                is_shipped=a.is_shipped,
                required_feature_flags=a.required_feature_flags,
            )
            for a in actions
        ],
        total=len(actions),
    )


@router.post("/{action_id}/execute", response_model=QuickActionExecuteResponse)
async def execute_quick_action(
    action_id: str,
    body: QuickActionExecuteRequest = QuickActionExecuteRequest(),
    tenant_id: str = Depends(get_verified_tenant_id),
    registry: QuickActionRegistry = Depends(_get_registry),
    feature_flags=Depends(_get_feature_flag_service),
) -> QuickActionExecuteResponse:
    """Execute a specific quick action after gate checks.

    Returns:
        Execution result with status, output, and optional error.
    """
    action_def = registry.get(action_id)
    if action_def is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Quick action not found: {action_id}",
        )

    resolved_flags = await feature_flags.list_flags(tenant_id=tenant_id)
    enabled_flags = frozenset(
        flag_name for flag_name, flag_value in resolved_flags.items() if flag_name and bool(flag_value)
    )

    result = registry.execute(
        action_id=action_id,
        tenant_id=tenant_id,
        params=body.params,
        enabled_flags=enabled_flags,
        tenant_capabilities=None,
    )

    return QuickActionExecuteResponse(
        action_id=result.action_id,
        status=result.status.value,
        output=result.output,
        error=result.error,
    )
