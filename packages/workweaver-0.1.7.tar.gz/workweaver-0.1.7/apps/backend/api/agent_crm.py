"""Agent CRM API endpoint — multi-provider (Zoho, Salesforce, HubSpot).

Provides POST /api/v1/crm/query for Workweaver Runtime plugin CRM tool.
Response matches plugin TypeScript interface:
  {records: CrmRecord[], total_count: number, operation: string}

CrmRecord = {id, type, properties, created_at, updated_at}

Provider selection priority:
  1. Explicit ``provider`` field in request (if set)
  2. ``CRM_DEFAULT_PROVIDER`` env var
  3. Auto-detect: try Zoho → Salesforce → HubSpot based on configured secrets
"""

from __future__ import annotations

import logging
import os
from datetime import datetime, UTC
from typing import Any, Literal

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.evidence_ledger import get_evidence_ledger_service
from apps.backend.services.integration_health_store import IntegrationHealthStore
from apps.backend.services.zoho.connection_manager import get_zoho_connection_manager
from apps.backend.services.zoho.crm import get_zoho_crm_service
from apps.backend.services.salesforce_crm_service import get_salesforce_crm_service
from apps.backend.services.hubspot_crm_service import get_hubspot_crm_service
from apps.backend.services.billing import MeteringService
from apps.backend.services.usage_tracker import UsageMetricType

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/crm", tags=["agent-crm"])


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class CrmQueryRequest(BaseModel):
    """Request model matching Workweaver Runtime plugin CrmQueryRequest."""

    operation: Literal["search", "get", "update", "list"] = Field(..., description="CRM operation to perform")
    entity_type: str = Field(..., description="Entity type (e.g. contact, deal)")
    provider: str | None = Field(
        None,
        description="CRM provider: zoho | salesforce | hubspot. Auto-detected if omitted.",
    )
    query: str | None = Field(None, description="Search query string")
    entity_id: str | None = Field(None, description="Entity ID for get/update")
    fields: list[str] | None = Field(None, description="Fields to return")
    filters: dict[str, Any] | None = Field(None, description="Query filters")
    updates: dict[str, Any] | None = Field(None, description="Fields to update")
    limit: int | None = Field(None, ge=1, le=1000, description="Max records to return")


class CrmRecord(BaseModel):
    """Single CRM record matching Workweaver Runtime plugin CrmRecord interface."""

    id: str = Field(..., description="Record identifier")
    type: str = Field(..., description="Entity type")
    properties: dict[str, Any] = Field(..., description="Record properties")
    created_at: str = Field(..., description="ISO8601 creation timestamp")
    updated_at: str = Field(..., description="ISO8601 last update timestamp")


class CrmQueryResponse(BaseModel):
    """Response model matching Workweaver Runtime plugin CrmQueryResponse.

    Exactly: {records: CrmRecord[], total_count: number, operation: string}
    """

    records: list[CrmRecord] = Field(..., description="Matching records")
    total_count: int = Field(..., description="Total matching records")
    operation: str = Field(..., description="Operation that was performed")
    evidence_event_id: str | None = Field(None, description="Durable evidence record for verified CRM mutations")
    evidence_url: str | None = Field(None, description="Evidence API URL for verified CRM mutations")


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------


def _zoho_crm_connected(tenant_id: str) -> bool:
    try:
        connection = get_zoho_connection_manager().get_connection(tenant_id, "zoho-crm")
    except Exception:
        return False
    return bool(connection and connection.state == "connected")


def _provider_unconfigured_detail(provider: str, required: list[str]) -> dict[str, Any]:
    return {
        "error": "provider_unconfigured",
        "provider": provider,
        "state": "missing_credentials",
        "required_secrets": required,
        "next_action": "Add provider credentials to environment or Secrets Manager",
    }


def _normalize_timestamp(raw: Any, fallback: str) -> str:
    if isinstance(raw, str) and raw.strip():
        return raw
    return fallback


def _evidence_url(evidence_id: str | None) -> str | None:
    if not evidence_id:
        return None
    return f"/api/v1/evidence/{evidence_id}"


def _get_health_store() -> IntegrationHealthStore:
    return IntegrationHealthStore()


def _extract_data_rows(response: Any) -> list[dict[str, Any]]:
    if not isinstance(response, dict):
        return []
    rows = response.get("data")
    if not isinstance(rows, list):
        return []
    return [row for row in rows if isinstance(row, dict)]


def _build_search_criteria(filters: dict[str, Any] | None) -> str | None:
    if not isinstance(filters, dict):
        return None

    clauses: list[str] = []
    for field, raw_value in filters.items():
        field_name = str(field or "").strip()
        if not field_name or raw_value is None:
            continue
        value = str(raw_value).strip()
        if not value:
            continue
        clauses.append(f"({field_name}:equals:{value})")

    if not clauses:
        return None
    return "and".join(clauses)


def _to_crm_record(
    lead: dict[str, Any],
    entity_type: str,
    fields: list[str] | None,
) -> CrmRecord:
    now = datetime.now(UTC).isoformat()
    lead_id = str(lead.get("id") or "").strip()

    if fields:
        properties = {field: lead[field] for field in fields if field in lead}
    else:
        properties = dict(lead)

    created_at = _normalize_timestamp(
        lead.get("Created_Time") or lead.get("created_time"),
        now,
    )
    updated_at = _normalize_timestamp(
        lead.get("Modified_Time") or lead.get("modified_time") or lead.get("updated_time"),
        created_at,
    )

    return CrmRecord(
        id=lead_id,
        type=entity_type,
        properties=properties,
        created_at=created_at,
        updated_at=updated_at,
    )


def _raw_record_properties(raw: dict[str, Any] | None) -> dict[str, Any]:
    if not isinstance(raw, dict):
        return {}
    props = raw.get("properties")
    if isinstance(props, dict):
        return props
    return raw


def _value_matches(expected: Any, actual: Any) -> bool:
    if actual == expected:
        return True
    return str(actual).strip() == str(expected).strip()


def _provider_connector_id(provider: str) -> str:
    return {
        "zoho": "zoho-crm",
        "salesforce": "salesforce-crm",
        "hubspot": "hubspot-crm",
    }.get(provider, provider)


def _prepare_mutation_context(
    *,
    provider: str,
    request: CrmQueryRequest,
    before: dict[str, Any] | None,
    after: dict[str, Any] | None,
) -> dict[str, Any]:
    updates = dict(request.updates or {})
    after_props = _raw_record_properties(after)
    verification_failures = [
        {
            "field": field,
            "expected": value,
            "actual": after_props.get(field),
        }
        for field, value in updates.items()
        if field not in after_props or not _value_matches(value, after_props.get(field))
    ]
    return {
        "provider": provider,
        "entity_type": request.entity_type,
        "entity_id": request.entity_id,
        "updates": updates,
        "before": before or {},
        "after": after or {},
        "verified": bool(after) and not verification_failures,
        "verification_failures": verification_failures,
    }


def _record_crm_mutation_evidence(
    *,
    tenant_id: str,
    mutation_context: dict[str, Any],
) -> tuple[str, str]:
    verified = bool(mutation_context.get("verified"))
    payload = {
        "item_type": "crm_mutation",
        "domain": "crm",
        **mutation_context,
    }
    record = get_evidence_ledger_service().ingest(
        tenant_id=tenant_id,
        event_type="evidence:item",
        data=payload,
        actor_path="system.crm_api",
        artifact_payload=payload,
    )
    evidence_id = str(record["evidence_id"])
    if not verified:
        _get_health_store().save_snapshot(
            tenant_id=tenant_id,
            connector_id=_provider_connector_id(str(mutation_context.get("provider") or "")),
            provider=str(mutation_context.get("provider") or ""),
            state="error",
            message="crm_read_back_verification_failed",
            latency_ms=0.0,
            evidence_event_id=evidence_id,
        )
    return evidence_id, _evidence_url(evidence_id) or ""


def _resolve_provider(request_provider: str | None, tenant_id: str | None = None) -> str:
    """Determine which CRM provider to use."""
    if request_provider:
        return request_provider.lower().strip()
    default = (os.getenv("CRM_DEFAULT_PROVIDER") or "").lower().strip()
    if default in {"zoho", "salesforce", "hubspot"}:
        return default
    if tenant_id and _zoho_crm_connected(tenant_id):
        return "zoho"
    if not tenant_id and (
        (os.getenv("ZOHO_CREDENTIALS_SECRET_NAME") or "").strip()
        or (os.getenv("ZOHO_CREDENTIALS_SECRET") or "").strip()
    ):
        return "zoho"
    if (os.getenv("SALESFORCE_CREDENTIALS_SECRET_NAME") or "").strip():
        return "salesforce"
    if (os.getenv("HUBSPOT_CREDENTIALS_SECRET_NAME") or "").strip():
        return "hubspot"
    return "zoho"


async def _get_crm_service(provider: str, tenant_id: str):
    """Resolve and return (provider_tag, service) for the given provider."""
    if provider == "zoho":
        if not _zoho_crm_connected(tenant_id):
            raise HTTPException(
                status_code=503, detail=_provider_unconfigured_detail("zoho_crm", ["canonical Zoho CRM connection"])
            )
        try:
            return (
                "zoho",
                await get_zoho_crm_service(
                    tenant_id=tenant_id,
                    cache_ttl_seconds=int(os.getenv("ZOHO_CREDENTIALS_CACHE_TTL", "900")),
                ),
            )
        except ValueError as exc:
            raise HTTPException(
                status_code=503, detail=_provider_unconfigured_detail("zoho_crm", ["canonical Zoho CRM connection"])
            ) from exc
    elif provider == "salesforce":
        if get_salesforce_crm_service is None:
            raise HTTPException(
                status_code=503, detail=_provider_unconfigured_detail("salesforce", ["salesforce_crm_service module"])
            )
        try:
            return ("salesforce", await get_salesforce_crm_service())
        except (ValueError, Exception) as exc:
            raise HTTPException(
                status_code=503,
                detail=_provider_unconfigured_detail("salesforce", ["SALESFORCE_CREDENTIALS_SECRET_NAME"]),
            ) from exc
    elif provider == "hubspot":
        if get_hubspot_crm_service is None:
            raise HTTPException(
                status_code=503, detail=_provider_unconfigured_detail("hubspot", ["hubspot_crm_service module"])
            )
        try:
            return ("hubspot", await get_hubspot_crm_service())
        except (ValueError, Exception) as exc:
            raise HTTPException(
                status_code=503, detail=_provider_unconfigured_detail("hubspot", ["HUBSPOT_CREDENTIALS_SECRET_NAME"])
            ) from exc
    else:
        raise HTTPException(status_code=400, detail=f"Unsupported CRM provider: {provider}")


async def _execute_zoho(
    service: Any,
    request: CrmQueryRequest,
    mutation_context: dict[str, Any] | None = None,
) -> list[CrmRecord]:
    """Execute CRM operation via Zoho service."""
    records: list[CrmRecord] = []
    if request.operation == "get":
        if request.entity_id:
            lead = await service.get_lead(request.entity_id, fields=request.fields)
            if lead and str(lead.get("id") or "").strip():
                records = [_to_crm_record(lead, request.entity_type, request.fields)]
    elif request.operation == "update":
        if request.entity_id:
            before = await service.get_lead(request.entity_id)
            result = await service.update_lead(request.entity_id, request.updates or {})
            if isinstance(result, dict) and not result.get("success", True):
                raise HTTPException(status_code=502, detail="provider_error")
            lead = await service.get_lead(request.entity_id)
            if mutation_context is not None:
                mutation_context.update(
                    _prepare_mutation_context(
                        provider="zoho",
                        request=request,
                        before=before,
                        after=lead,
                    )
                )
                if not mutation_context.get("verified"):
                    raise HTTPException(status_code=502, detail="crm_read_back_verification_failed")
            if not lead:
                lead = {"id": request.entity_id, **(request.updates or {})}
            if str(lead.get("id") or "").strip():
                records = [_to_crm_record(lead, request.entity_type, request.fields)]
    elif request.operation in {"search", "list"}:
        criteria = _build_search_criteria(request.filters)
        query_params: dict[str, Any] = {}
        if request.limit:
            query_params["per_page"] = request.limit
        if criteria:
            query_params["criteria"] = criteria
        if request.operation == "search":
            word = (request.query or "").strip()
            if word:
                query_params["word"] = word
            if query_params.get("word") or query_params.get("criteria"):
                response = await service._make_api_request(method="GET", path="/Leads/search", query=query_params)
                rows = _extract_data_rows(response)
                records = [
                    _to_crm_record(row, request.entity_type, request.fields)
                    for row in rows
                    if str(row.get("id") or "").strip()
                ]
        else:
            path = "/Leads/search" if query_params.get("criteria") else "/Leads"
            response = await service._make_api_request(method="GET", path=path, query=query_params or None)
            rows = _extract_data_rows(response)
            records = [
                _to_crm_record(row, request.entity_type, request.fields)
                for row in rows
                if str(row.get("id") or "").strip()
            ]
    return records


def _connector_record_to_crm(raw: dict[str, Any], entity_type: str, fields: list[str] | None) -> CrmRecord:
    """Convert a connector-style record (Salesforce/HubSpot) to CrmRecord."""
    now = datetime.now(UTC).isoformat()
    record_id = str(raw.get("id") or raw.get("Id") or "").strip()
    props = raw.get("properties", raw)
    if fields:
        props = {f: props[f] for f in fields if f in props}
    else:
        props = dict(props)
    created = _normalize_timestamp(raw.get("createdAt") or raw.get("CreatedDate") or raw.get("Created_Time"), now)
    updated = _normalize_timestamp(
        raw.get("updatedAt") or raw.get("LastModifiedDate") or raw.get("Modified_Time"), created
    )
    return CrmRecord(id=record_id, type=entity_type, properties=props, created_at=created, updated_at=updated)


async def _execute_connector(
    service: Any,
    request: CrmQueryRequest,
    mutation_context: dict[str, Any] | None = None,
) -> list[CrmRecord]:
    """Execute CRM operation via a connector-based service (Salesforce/HubSpot)."""
    records: list[CrmRecord] = []
    object_type = request.entity_type or "contacts"
    if request.operation == "get":
        if request.entity_id:
            rec = await service.get_record(request.entity_id, object_type=object_type)
            if rec and str(rec.get("id") or rec.get("Id") or "").strip():
                records = [_connector_record_to_crm(rec, request.entity_type, request.fields)]
    elif request.operation == "update":
        if request.entity_id:
            before = await service.get_record(request.entity_id, object_type=object_type)
            await service.update_record(request.entity_id, request.updates or {}, object_type=object_type)
            rec = await service.get_record(request.entity_id, object_type=object_type)
            if mutation_context is not None:
                mutation_context.update(
                    _prepare_mutation_context(
                        provider=str(mutation_context.get("provider") or ""),
                        request=request,
                        before=before,
                        after=rec,
                    )
                )
                if not mutation_context.get("verified"):
                    raise HTTPException(status_code=502, detail="crm_read_back_verification_failed")
            if not rec:
                rec = {"id": request.entity_id, **(request.updates or {})}
            if str(rec.get("id") or rec.get("Id") or "").strip():
                records = [_connector_record_to_crm(rec, request.entity_type, request.fields)]
    elif request.operation == "search":
        word = (request.query or "").strip()
        if word:
            results = await service.search(word, object_type=object_type, limit=request.limit or 10)
            records = [
                _connector_record_to_crm(r, request.entity_type, request.fields)
                for r in results
                if str(r.get("id") or r.get("Id") or "").strip()
            ]
    elif request.operation == "list":
        results = await service.list_records(object_type=object_type, limit=request.limit or 10)
        records = [
            _connector_record_to_crm(r, request.entity_type, request.fields)
            for r in results
            if str(r.get("id") or r.get("Id") or "").strip()
        ]
    return records


@router.post("/query", response_model=CrmQueryResponse)
async def query_crm(
    request: CrmQueryRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CrmQueryResponse:
    """Query CRM data on behalf of an AI agent.

    Supports Zoho, Salesforce, and HubSpot. Provider auto-detected or set explicitly.
    """
    provider_name = _resolve_provider(request.provider, tenant_id)
    logger.info(
        "Agent CRM query: tenant=%s op=%s entity=%s provider=%s",
        tenant_id,
        request.operation,
        request.entity_type,
        provider_name,
    )
    provider_tag, service = await _get_crm_service(provider_name, tenant_id)
    mutation_context: dict[str, Any] | None = None
    evidence_event_id: str | None = None
    evidence_url: str | None = None
    if request.operation == "update":
        mutation_context = {
            "provider": provider_tag,
            "entity_type": request.entity_type,
            "entity_id": request.entity_id,
            "updates": dict(request.updates or {}),
        }
    try:
        if provider_tag == "zoho":
            records = await _execute_zoho(service, request, mutation_context=mutation_context)
        else:
            records = await _execute_connector(service, request, mutation_context=mutation_context)
        if mutation_context is not None:
            evidence_event_id, evidence_url = _record_crm_mutation_evidence(
                tenant_id=tenant_id,
                mutation_context=mutation_context,
            )
        try:
            await MeteringService().meter(
                tenant_id=tenant_id,
                metric=UsageMetricType.CRM_OPERATIONS,
                quantity=1,
                unit="operations",
                idempotency_key=(
                    f"agent_crm:{tenant_id}:{provider_tag}:{request.operation}:"
                    f"{request.entity_type}:{request.entity_id or request.query or 'list'}"
                ),
                metadata={"operation": request.operation, "entity_type": request.entity_type, "provider": provider_tag},
            )
        except Exception:
            logger.warning("CRM metering failed for tenant=%s (fail_open)", tenant_id, exc_info=True)
        return CrmQueryResponse(
            records=records,
            total_count=len(records),
            operation=request.operation,
            evidence_event_id=evidence_event_id,
            evidence_url=evidence_url,
        )
    except HTTPException as exc:
        if mutation_context is not None and exc.detail == "crm_read_back_verification_failed":
            try:
                _record_crm_mutation_evidence(
                    tenant_id=tenant_id,
                    mutation_context=mutation_context,
                )
            except Exception:
                logger.error("Failed to persist CRM verification failure evidence", exc_info=True)
        raise
    except Exception as exc:
        logger.error("Agent CRM provider error (%s): %s", provider_tag, exc, exc_info=True)
        raise HTTPException(status_code=502, detail="provider_error") from exc
    finally:
        if service and hasattr(service, "close"):
            await service.close()
