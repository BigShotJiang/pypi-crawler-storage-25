"""Admin diagnostics endpoint (Track 8.2).

Returns non-PII metadata: service versions, health status, recent error
counts, and process uptime. Gated by tenant auth.
"""

from __future__ import annotations

import logging
import time
from datetime import datetime, UTC

from apps.backend.config.region import AWS_REGION
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, require_admin_user_role
from apps.backend.services.admin.admin_permission import AdminPermission
from apps.backend.services.degradation_notifier import get_degradation_notifier
from apps.backend.services.self_diagnosis import SelfDiagnosisService
from apps.backend.services.telemetry_policy import get_telemetry_policy
from apps.backend.voice_services.latency_tracker import (
    get_global_tracker,
    get_sip_handshake_latency_summary_by_edge,
)

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/admin",
    tags=["admin"],
    dependencies=[
        Depends(require_admin_user_role),
        Depends(require_admin_permission_dep(AdminPermission.DIAGNOSTICS_READ)),
    ],
)

# Process start time — set once at import
_PROCESS_START = time.monotonic()

# API version — matches main.py FastAPI version
_API_VERSION = "1.0.0"

# Lazy reference to the global error tracker (set by main.py at startup)
_error_tracker = None
_acknowledged_degradation_events: set[str] = set()
_self_diagnosis_service = SelfDiagnosisService()


class TelemetryPolicyUpdateRequest(BaseModel):
    """Admin telemetry policy update request."""

    mode: str = Field(..., description="metadata_only | content_enabled")
    region: str = Field(default=AWS_REGION, description="Data residency region")


class DegradationEventRequest(BaseModel):
    """Create degradation event request."""

    event_type: str = Field(..., description="provider_down | quota_hit | timeout | service_degraded")
    details: dict = Field(default_factory=dict, description="Event details")


class SelfDiagnosisFailureInput(BaseModel):
    """Failure signal captured by assertions for one corrective-loop iteration."""

    name: str = Field(..., description="Assertion name")
    severity: str = Field(default="unknown", description="Assertion severity")
    message: str = Field(default="", description="Assertion failure message")


class SelfDiagnosisTraceInput(BaseModel):
    """Bounded corrective-loop trace input for diagnosis."""

    iteration: int = Field(default=0, ge=0)
    task_description: str = Field(default="")
    execution_status: str = Field(default="unknown")
    execution_mode: str = Field(default="unknown")
    assertion_passed: bool = Field(default=False)
    failures: list[SelfDiagnosisFailureInput] = Field(default_factory=list)


class SelfDiagnosisRequest(BaseModel):
    """Self-diagnosis request payload."""

    task_description: str = Field(..., min_length=1, description="Original task description")
    task_category: str | None = Field(default=None, description="Optional task category")
    final_assertion_passed: bool = Field(default=False)
    traces: list[SelfDiagnosisTraceInput] = Field(default_factory=list, description="Corrective-loop traces")


def set_error_tracker(tracker: object) -> None:
    """Called by main.py to inject the global ErrorTracker instance."""
    global _error_tracker
    _error_tracker = tracker


@router.get("/diagnostics")
async def get_diagnostics(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict:
    """Return operational diagnostics — metadata only, NO PII.

    Requires tenant authentication (admin-only in production).
    """
    uptime = time.monotonic() - _PROCESS_START

    error_snapshot = {"total": 0, "by_path": {}, "last_error_time": None}
    if _error_tracker is not None:
        error_snapshot = _error_tracker.snapshot()

    return {
        "service_versions": {
            "api": _API_VERSION,
            "python": _python_version(),
        },
        "health": {
            "status": "healthy",
            "checks": {
                "api": "ok",
            },
        },
        "error_counts": error_snapshot,
        "uptime_seconds": round(uptime, 2),
        "timestamp": datetime.now(UTC).isoformat(),
    }


@router.get("/degradation-events")
async def get_degradation_events(
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = 10,
) -> dict:
    """Return recent degradation notifications for tenant."""
    notifier = get_degradation_notifier()
    notifications = notifier.get_recent(tenant_id=tenant_id, limit=max(1, min(limit, 100)))
    for event in notifications:
        event_key = f"{event.get('tenant_id')}::{event.get('event_type')}::{event.get('timestamp')}"
        event["acknowledged"] = event_key in _acknowledged_degradation_events
    return {"tenant_id": tenant_id, "events": notifications, "count": len(notifications)}


@router.post("/self-diagnosis")
async def create_self_diagnosis(
    request: SelfDiagnosisRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict:
    """Build a bounded, reproducible self-diagnosis artifact for failed or high-risk runs."""
    diagnosis = _self_diagnosis_service.analyze(
        task_description=request.task_description,
        task_category=request.task_category,
        final_assertion_passed=request.final_assertion_passed,
        traces=[trace.model_dump() for trace in request.traces],
    )
    return {
        "tenant_id": tenant_id,
        "diagnosis": diagnosis.as_dict(),
    }


@router.post("/degradation-events")
async def create_degradation_event(
    request: DegradationEventRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict:
    """Record degradation notification (operator/manual hook)."""
    notifier = get_degradation_notifier()
    event = notifier.notify(
        event_type=request.event_type,
        details=request.details,
        tenant_id=tenant_id,
    )
    return {"success": True, "event": event}


@router.post("/degradation-events/acknowledge")
async def acknowledge_degradation_event(
    timestamp: str,
    event_type: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict:
    """Acknowledge a degradation event by tenant/event/timestamp key."""
    key = f"{tenant_id}::{event_type}::{timestamp}"
    _acknowledged_degradation_events.add(key)
    return {"success": True, "acknowledged_key": key}


@router.get("/telemetry/policy")
async def get_tenant_telemetry_policy(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict:
    """Return tenant telemetry mode + residency + audit metadata."""
    policy = get_telemetry_policy()
    return {
        "tenant_id": tenant_id,
        "mode": policy.get_mode(tenant_id),
        "region": policy.get_data_residency(tenant_id),
        "audit": policy.get_audit_metadata(tenant_id),
    }


@router.get("/observability/summary")
async def get_observability_summary(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict:
    """Return non-PII admin observability counters and voice latency groups."""
    voice_sip_latency_by_edge = await get_sip_handshake_latency_summary_by_edge(
        tenant_id=tenant_id,
        global_tracker=get_global_tracker(),
    )
    return {
        "tenant_id": tenant_id,
        "error_rate_1h": 0.0,
        "error_rate_24h": 0.0,
        "p99_memory_recall": 0,
        "p99_connector_call": 0,
        "p99_dag_execute": 0,
        "voice_sip_latency_by_edge": voice_sip_latency_by_edge,
        "timestamp": datetime.now(UTC).isoformat(),
    }


@router.put("/telemetry/policy")
async def update_tenant_telemetry_policy(
    request: TelemetryPolicyUpdateRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict:
    """Update tenant telemetry mode + residency."""
    policy = get_telemetry_policy()
    try:
        policy.set_mode(tenant_id, request.mode)
    except ValueError as exc:
        logger.error("Invalid telemetry policy mode: %s", exc, exc_info=True)
        raise HTTPException(status_code=400, detail="Invalid request parameters") from exc
    policy.set_data_residency(tenant_id, request.region)
    return {
        "success": True,
        "tenant_id": tenant_id,
        "mode": policy.get_mode(tenant_id),
        "region": policy.get_data_residency(tenant_id),
    }


def _python_version() -> str:
    """Return Python runtime version string."""
    import sys

    return f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"
