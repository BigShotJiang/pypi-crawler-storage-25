"""Role Proposals API — self-assembling role proposals endpoints.

Endpoints:
    GET  /api/v1/roles/proposals          — list current proposals for tenant
    POST /api/v1/roles/proposals/approve  — approve a proposal, creating the role

Role assembly contract.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/roles/proposals", tags=["role-proposals"])


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class ProposalResponse(BaseModel):
    """Response schema for a single role proposal."""

    proposed_role_id: str
    display_name: str
    capabilities: list[str]
    justification: str
    task_count: int
    confidence: float
    proposed_at: str
    status: str


class ProposalListResponse(BaseModel):
    """Response schema for a list of proposals."""

    proposals: list[ProposalResponse]
    count: int


class ApproveProposalRequest(BaseModel):
    """Request body to approve a proposal."""

    proposal: dict[str, Any] = Field(..., description="Proposal dict returned by GET /proposals")


class RoleResponse(BaseModel):
    """Minimal role response after approval."""

    role_id: str
    tenant_id: str
    display_name: str
    capabilities: list[str]
    created_by: str
    created_at: str


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_assembler():
    """Build RoleAssembler with production dependencies (lazy import)."""
    from apps.backend.services.evidence_ledger import get_evidence_ledger_service
    from apps.backend.services.role_assembler import RoleAssembler
    from apps.backend.services.role_store import get_role_store

    return RoleAssembler(
        role_store=get_role_store(),
        evidence_svc=get_evidence_ledger_service(),
    )


def _to_proposal_response(p: dict[str, Any]) -> ProposalResponse:
    return ProposalResponse(
        proposed_role_id=p["proposed_role_id"],
        display_name=p["display_name"],
        capabilities=p.get("capabilities", []),
        justification=p.get("justification", ""),
        task_count=p.get("task_count", 0),
        confidence=p.get("confidence", 0.0),
        proposed_at=p.get("proposed_at", ""),
        status=p.get("status", "pending_approval"),
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("/", response_model=ProposalListResponse)
async def list_proposals(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ProposalListResponse:
    """Analyze task patterns and return pending role proposals for the tenant."""
    try:
        assembler = _get_assembler()
        proposals = assembler.analyze_and_propose(tenant_id)
        return ProposalListResponse(
            proposals=[_to_proposal_response(p) for p in proposals],
            count=len(proposals),
        )
    except HTTPException:
        raise
    except Exception:
        logger.exception("Unexpected error listing proposals for tenant %s", tenant_id)
        raise HTTPException(status_code=500, detail="Failed to list role proposals")


@router.post("/approve", response_model=RoleResponse, status_code=201)
async def approve_proposal(
    request: ApproveProposalRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> RoleResponse:
    """Approve a role proposal — creates the role immediately."""
    try:
        assembler = _get_assembler()
        role = assembler.approve_proposal(tenant_id, request.proposal)
        return RoleResponse(
            role_id=role["role_id"],
            tenant_id=role["tenant_id"],
            display_name=role["display_name"],
            capabilities=role.get("capabilities", []),
            created_by=role.get("created_by", "role_assembler"),
            created_at=role.get("created_at", ""),
        )
    except ValueError as exc:
        logger.error("Role proposal approval failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except HTTPException:
        raise
    except Exception:
        logger.exception("Unexpected error approving proposal for tenant %s", tenant_id)
        raise HTTPException(status_code=500, detail="Failed to approve role proposal")
