"""apps/backend/api/contestability.py — Decision Trace contest + replay endpoints.

Closes file/accept/reject portion of #2729. Replay endpoint (#2819) ships
after #2711 (deterministic context re-load) merged.

Contract:
- POST /api/v1/context/{decision_id}/contest   — file a counter-alternative
- POST /api/v1/contests/{contest_id}/accept    — Owner accepts
- POST /api/v1/contests/{contest_id}/reject    — Owner rejects
- GET  /api/v1/context/{decision_id}/contests  — list contests for a decision
- POST /api/v1/context/{decision_id}/replay    — replay decision trace (#2819)

Authentication is delegated to the same FastAPI dependency the rest of the
backend uses. Tests can override `get_contestation_service`,
`get_replay_service` and the auth dependency to keep them hermetic.
"""
from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, get_verified_user_id
from apps.backend.services.context_graph.contestability import (
    ContestationService,
    ContestNotFoundError,
    ContestStateError,
    InMemoryContestStore,
)
from apps.backend.services.decision_trace_replay import (
    CapturedDecisionStore,
    DecisionNotFoundError as ReplayDecisionNotFoundError,
    DecisionTraceReplayService,
    EvidenceLedgerTraceEmitter,
    OperationalContextReplayContextLoader,
    TenantMismatchError,
)

router = APIRouter(prefix="/api/v1", tags=["contestability"])

_DEFAULT_SERVICE: ContestationService | None = None
_DEFAULT_REPLAY_SERVICE: DecisionTraceReplayService | None = None


def get_contestation_service() -> ContestationService:
    """Module-level singleton; replace in tests via `app.dependency_overrides`."""
    global _DEFAULT_SERVICE
    if _DEFAULT_SERVICE is None:
        _DEFAULT_SERVICE = ContestationService(store=InMemoryContestStore())
    return _DEFAULT_SERVICE


def get_replay_service() -> DecisionTraceReplayService:
    """Module-level singleton for replay; override in tests."""
    global _DEFAULT_REPLAY_SERVICE
    if _DEFAULT_REPLAY_SERVICE is None:
        _DEFAULT_REPLAY_SERVICE = DecisionTraceReplayService(
            context_loader=OperationalContextReplayContextLoader(),
            decision_store=CapturedDecisionStore(),
            trace_emitter=EvidenceLedgerTraceEmitter(),
        )
    return _DEFAULT_REPLAY_SERVICE


# --- request / response models ---------------------------------------------


class FileContestRequest(BaseModel):
    counter_alternative: str = Field(..., min_length=1, max_length=2000)
    rationale: str = Field(..., min_length=1, max_length=5000)
    evidence_refs: list[str] = Field(default_factory=list, max_length=50)
    member_id: str | None = Field(default=None, max_length=200)


class AcceptContestRequest(BaseModel):
    accepted_by: str | None = Field(default=None, max_length=200)
    rationale: str = Field("", max_length=5000)


class RejectContestRequest(BaseModel):
    rejected_by: str | None = Field(default=None, max_length=200)
    rationale: str = Field("", max_length=5000)


class ContestEventResponse(BaseModel):
    id: str
    kind: str
    decision_id: str
    payload: dict[str, Any]
    created_at: float


# --- routes ----------------------------------------------------------------


@router.post(
    "/context/{decision_id}/contest",
    response_model=ContestEventResponse,
    status_code=status.HTTP_201_CREATED,
)
def file_contest(
    decision_id: str,
    body: FileContestRequest,
    tenant_id: str = Depends(get_verified_tenant_id),  # noqa: ARG001
    user_id: str = Depends(get_verified_user_id),
    service: ContestationService = Depends(get_contestation_service),
) -> ContestEventResponse:
    contest = service.file_contest(
        decision_id=decision_id,
        member_id=user_id,
        counter_alternative=body.counter_alternative,
        rationale=body.rationale,
        evidence_refs=body.evidence_refs,
    )
    return ContestEventResponse(
        id=contest.id,
        kind=contest.kind,
        decision_id=contest.decision_id,
        payload=contest.payload,
        created_at=contest.created_at,
    )


@router.post(
    "/contests/{contest_id}/accept",
    response_model=ContestEventResponse,
    status_code=status.HTTP_200_OK,
)
def accept_contest(
    contest_id: str,
    body: AcceptContestRequest,
    tenant_id: str = Depends(get_verified_tenant_id),  # noqa: ARG001
    user_id: str = Depends(get_verified_user_id),
    service: ContestationService = Depends(get_contestation_service),
) -> ContestEventResponse:
    try:
        amended = service.accept_contest(
            contest_id=contest_id,
            accepted_by=user_id,
            rationale=body.rationale,
        )
    except ContestNotFoundError:
        raise HTTPException(status_code=404, detail="contest not found")
    except ContestStateError as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    return ContestEventResponse(
        id=amended.id,
        kind=amended.kind,
        decision_id=amended.decision_id,
        payload=amended.payload,
        created_at=amended.created_at,
    )


@router.post(
    "/contests/{contest_id}/reject",
    response_model=ContestEventResponse,
    status_code=status.HTTP_200_OK,
)
def reject_contest(
    contest_id: str,
    body: RejectContestRequest,
    tenant_id: str = Depends(get_verified_tenant_id),  # noqa: ARG001
    user_id: str = Depends(get_verified_user_id),
    service: ContestationService = Depends(get_contestation_service),
) -> ContestEventResponse:
    try:
        rejected = service.reject_contest(
            contest_id=contest_id,
            rejected_by=user_id,
            rationale=body.rationale,
        )
    except ContestNotFoundError:
        raise HTTPException(status_code=404, detail="contest not found")
    except ContestStateError as exc:
        raise HTTPException(status_code=409, detail=str(exc))
    return ContestEventResponse(
        id=rejected.id,
        kind=rejected.kind,
        decision_id=rejected.decision_id,
        payload=rejected.payload,
        created_at=rejected.created_at,
    )


@router.get(
    "/context/{decision_id}/contests",
    response_model=list[ContestEventResponse],
)
def list_contests(
    decision_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),  # noqa: ARG001
    service: ContestationService = Depends(get_contestation_service),
) -> list[ContestEventResponse]:
    contests = service.list_contests_for_decision(decision_id)
    return [
        ContestEventResponse(
            id=c.id,
            kind=c.kind,
            decision_id=c.decision_id,
            payload=c.payload,
            created_at=c.created_at,
        )
        for c in contests
    ]


# --- replay request / response models (#2819) ------------------------------


class ReplayRequest(BaseModel):
    seed: int | None = Field(default=None, ge=0)


class ReplayResponse(BaseModel):
    original_decision_id: str
    new_trace_id: str
    replayed_at: float
    verdict_match: bool
    context_snapshot: dict[str, Any] = Field(default_factory=dict)


# --- replay route (#2819) ---------------------------------------------------


@router.post(
    "/context/{decision_id:path}/replay",
    response_model=ReplayResponse,
    status_code=status.HTTP_200_OK,
)
async def replay_decision(
    decision_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    body: ReplayRequest | None = Body(default=None),  # noqa: ARG001
    service: DecisionTraceReplayService = Depends(get_replay_service),
) -> ReplayResponse:
    try:
        result = await service.replay(
            decision_id=decision_id,
            tenant_id=tenant_id,
        )
    except ReplayDecisionNotFoundError:
        raise HTTPException(status_code=404, detail="decision not found")
    except TenantMismatchError as exc:
        raise HTTPException(status_code=400, detail=str(exc))
    return ReplayResponse(
        original_decision_id=result.original_decision_id,
        new_trace_id=result.new_trace_id,
        replayed_at=result.replayed_at,
        verdict_match=result.verdict_match,
        context_snapshot=result.context_snapshot,
    )
