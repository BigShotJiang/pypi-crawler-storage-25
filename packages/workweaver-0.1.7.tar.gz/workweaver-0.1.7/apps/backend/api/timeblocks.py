"""``/api/v1/timeblocks`` — REST CRUD over the canonical TimeBlock ledger.

Backend half of W#2785 (TimeBlockCard primitive set), PR A.

This module is the canonical REST entry point for the TimeBlock primitive.
Higher-level views (Mission Calendar listing in
:mod:`apps.backend.api.mission_timeblocks`) sit on top of the same
:class:`AgentWorkLedgerService`; this surface gives REST + CLI + MCP a
single sharp CRUD shape.

Design contracts (PRODUCT-CONTEXT.md §12):

- **UTC at rest, always.** ``start_utc`` / ``end_utc`` round-trip through
  the canonical model in UTC. Display tz is the workstation's problem.
- **Atomic move.** ``POST /{id}/move`` rewrites ``started_at`` /
  ``ended_at`` after a conflict check; the call is one transition (not
  delete+create) so the audit trail and ``block_id`` stay stable.
- **Conflict detection.** Create + move reject 409 if the proposed window
  overlaps an existing live block for the same owner. Caller can opt out
  with ``?force=true`` (records ``forced_overlap=True`` in metadata).
- **Soft delete.** ``DELETE`` flips state → ``CANCELLED`` and stamps
  ``ended_at`` — the row stays for audit. Hard delete is intentionally
  not exposed.
- **Decision Trace.** Every state-changing call goes through
  :class:`AgentWorkLedgerService` which already emits evidence rows on
  create/update/transition. The route handler layer never bypasses the
  ledger.
- **RBAC.** Owner (``UserRole.ADMIN``) writes; any tenant role reads.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime, timedelta
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, ConfigDict, Field, field_validator

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_role,
)
from apps.backend.models.time_block import (
    TERMINAL_BLOCK_STATES,
    TimeBlock,
    TimeBlockOutcome,
    TimeBlockState,
)
from apps.backend.models.user import UserRole

logger = logging.getLogger(__name__)

MAX_TIMEBLOCK_REQUEST_READ = 500


router = APIRouter(prefix="/api/v1/timeblocks", tags=["timeblocks"])


# ---------------------------------------------------------------------------
# Indirection seams (overridable in tests)
# ---------------------------------------------------------------------------


def _get_ledger() -> Any:
    """Return the canonical TimeBlock ledger service.

    Indirection seam — tests monkeypatch this to inject an in-memory fake.
    Keeps the route module decoupled from the dynamo / disk store factory.
    """
    from apps.backend.services.agent_work_ledger import (
        get_agent_work_ledger_service,
    )

    return get_agent_work_ledger_service()


# ---------------------------------------------------------------------------
# Pydantic surface models
# ---------------------------------------------------------------------------


def _coerce_utc(value: datetime) -> datetime:
    """Promote naive datetimes to UTC; normalise everything else to UTC."""

    if value.tzinfo is None:
        return value.replace(tzinfo=UTC)
    return value.astimezone(UTC)


class TimeBlockCreateRequest(BaseModel):
    """Body for ``POST /api/v1/timeblocks``."""

    model_config = ConfigDict(extra="forbid")

    workspace_id: str = Field(
        ...,
        min_length=1,
        description="Workspace id. Currently unused by the ledger but "
        "captured in metadata so the surface is stable as we layer "
        "workspace-scoped queries on top.",
    )
    start_utc: datetime = Field(
        ...,
        description="UTC start instant. Naive datetimes are interpreted as UTC.",
    )
    end_utc: datetime = Field(
        ...,
        description="UTC end instant. Must be >= start_utc.",
    )
    title: str = Field(
        ..., min_length=1, max_length=500, description="Short objective."
    )
    intent: str = Field(
        default="",
        max_length=2000,
        description="Plan / intent free text. Optional.",
    )
    owner_id: str = Field(
        ...,
        min_length=1,
        description="Member id of the block owner. Maps to ``agent_id`` on the canonical model.",
    )

    @field_validator("start_utc", "end_utc")
    @classmethod
    def _utc(cls, v: datetime) -> datetime:
        return _coerce_utc(v)


class TimeBlockUpdateRequest(BaseModel):
    """Body for ``PATCH /api/v1/timeblocks/{id}`` — partial update."""

    model_config = ConfigDict(extra="forbid")

    title: str | None = Field(default=None, min_length=1, max_length=500)
    intent: str | None = Field(default=None, max_length=2000)
    start_utc: datetime | None = None
    end_utc: datetime | None = None

    @field_validator("start_utc", "end_utc")
    @classmethod
    def _utc(cls, v: datetime | None) -> datetime | None:
        return None if v is None else _coerce_utc(v)


class TimeBlockMoveRequest(BaseModel):
    """Body for ``POST /api/v1/timeblocks/{id}/move``."""

    model_config = ConfigDict(extra="forbid")

    new_start_utc: datetime
    new_end_utc: datetime

    @field_validator("new_start_utc", "new_end_utc")
    @classmethod
    def _utc(cls, v: datetime) -> datetime:
        return _coerce_utc(v)


class TimeBlockEnvelope(BaseModel):
    """Wire shape returned by every CRUD endpoint."""

    id: str
    workspace_id: str | None
    owner_id: str
    title: str
    intent: str
    start_utc: str
    end_utc: str
    state: str
    outcome: str
    canonical_hour_bucket: str
    deleted: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)


class TimeBlockListResponse(BaseModel):
    """Paginated list payload."""

    items: list[TimeBlockEnvelope]
    next_cursor: str | None = Field(
        default=None,
        description="Opaque cursor for the next page. ``None`` when no more rows.",
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _enum_value(value: Any) -> str:
    """Return the string ``.value`` of a str-Enum, else ``str(value)``.

    ``TimeBlock`` is configured with ``use_enum_values=True``, so values
    parsed via ``model_validate`` come back as plain strings. Fields set
    on a freshly-constructed model still carry the enum object — Python
    3.11+ ``str()`` on a str-mixin enum returns the qualified name, NOT
    the value. Always go through this helper so the wire shape is
    deterministic regardless of construction path.
    """

    return value.value if hasattr(value, "value") else str(value)


def _envelope(block: TimeBlock) -> TimeBlockEnvelope:
    """Project a :class:`TimeBlock` onto the public REST envelope."""

    metadata = dict(block.metadata or {})
    workspace_id = metadata.get("workspace_id")
    end_dt = block.ended_at or (
        block.started_at + timedelta(minutes=block.duration_budget_minutes)
    )
    state_value = _enum_value(block.state)
    return TimeBlockEnvelope(
        id=block.block_id,
        workspace_id=str(workspace_id) if workspace_id else None,
        owner_id=block.agent_id,
        title=block.objective,
        intent=block.plan,
        start_utc=block.started_at.astimezone(UTC).isoformat(),
        end_utc=end_dt.astimezone(UTC).isoformat(),
        state=state_value,
        outcome=_enum_value(block.outcome),
        canonical_hour_bucket=block.canonical_hour_bucket.isoformat(),
        deleted=state_value == TimeBlockState.CANCELLED.value,
        metadata=metadata,
    )


def _ensure_writer(role: UserRole) -> None:
    """RBAC: only ADMIN (Owner) and OWNER role may mutate."""

    # ``UserRole`` enum exposes ADMIN as the canonical owner role on the
    # workspace. Any non-admin caller is treated as read-only.
    if role != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="timeblock writes require Owner (ADMIN) role",
        )


def _validate_window(start: datetime, end: datetime) -> None:
    if end <= start:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail="end_utc must be strictly after start_utc",
        )


def _duration_minutes(start: datetime, end: datetime) -> int:
    """Compute the integer-minute duration; clamp to the model bounds."""

    minutes = max(1, round((end - start).total_seconds() / 60))
    # The model clamps duration_budget_minutes to <= 24*60. Fail fast
    # rather than letting Pydantic raise a 500 wrapped as 422.
    if minutes > 24 * 60:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail="timeblock window must not exceed 24 hours",
        )
    return minutes


def _check_conflict(
    ledger: Any,
    *,
    tenant_id: str,
    owner_id: str,
    start: datetime,
    end: datetime,
    exclude_block_id: str | None,
    force: bool,
) -> None:
    """Reject 409 if ``[start, end)`` overlaps a live block for ``owner_id``.

    Cancelled/Failed/Completed blocks (terminal) are never considered for
    conflict — they are historical rows. ``exclude_block_id`` lets the
    move endpoint skip the row it is moving.
    """

    if force:
        return
    if hasattr(ledger, "list_live_blocks_for_agent"):
        existing = ledger.list_live_blocks_for_agent(
            tenant_id,
            owner_id,
            limit=MAX_TIMEBLOCK_REQUEST_READ,
        )
    else:
        existing = ledger.list_blocks(
            tenant_id,
            agent_id=owner_id,
            limit=MAX_TIMEBLOCK_REQUEST_READ,
        )
    terminal_values = {state.value for state in TERMINAL_BLOCK_STATES}
    for other in existing:
        if other.block_id == exclude_block_id:
            continue
        if _enum_value(other.state) in terminal_values:
            continue
        other_start = other.started_at.astimezone(UTC)
        other_end = (
            other.ended_at
            or (other.started_at + timedelta(minutes=other.duration_budget_minutes))
        ).astimezone(UTC)
        # Half-open intervals: [start, end) overlaps [other_start, other_end)
        # iff start < other_end and other_start < end.
        if start < other_end and other_start < end:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail={
                    "error": "timeblock_conflict",
                    "conflict_block_id": other.block_id,
                    "conflict_window": {
                        "start_utc": other_start.isoformat(),
                        "end_utc": other_end.isoformat(),
                    },
                },
            )


def _filter_workspace(blocks: list[TimeBlock], workspace_id: str | None) -> list[TimeBlock]:
    if workspace_id is None:
        return blocks
    return [
        block
        for block in blocks
        if str((block.metadata or {}).get("workspace_id") or "") == workspace_id
    ]


def _decode_cursor(cursor: str | None) -> int:
    if not cursor:
        return 0
    try:
        offset = int(cursor)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"invalid cursor: {cursor!r}",
        ) from exc
    if offset < 0:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="cursor must be non-negative",
        )
    return offset


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.get("", response_model=TimeBlockListResponse)
async def list_timeblocks(
    tenant_id: str = Depends(get_verified_tenant_id),
    _user_role: UserRole = Depends(get_verified_user_role),
    workspace_id: str | None = Query(default=None),
    since: datetime | None = Query(default=None, description="UTC lower bound."),
    until: datetime | None = Query(default=None, description="UTC upper bound."),
    owner: str | None = Query(default=None, description="Filter by ``owner_id``."),
    cursor: str | None = Query(default=None),
    limit: int = Query(default=50, ge=1, le=500),
) -> TimeBlockListResponse:
    """List TimeBlocks for the tenant.

    Read access is open to any authenticated tenant member; mutation
    enforcement lives on the write endpoints.
    """

    ledger = _get_ledger()
    since_utc = _coerce_utc(since) if since else None
    until_utc = _coerce_utc(until) if until else None
    offset = _decode_cursor(cursor)
    read_limit = min(MAX_TIMEBLOCK_REQUEST_READ, offset + limit + 1)
    blocks: list[TimeBlock] = ledger.list_blocks(
        tenant_id,
        start_at=since_utc,
        end_at=until_utc,
        agent_id=owner,
        limit=read_limit,
    )
    blocks = _filter_workspace(blocks, workspace_id)

    page = blocks[offset : offset + limit]
    next_cursor = (
        str(offset + limit) if offset + limit < len(blocks) else None
    )
    return TimeBlockListResponse(
        items=[_envelope(b) for b in page],
        next_cursor=next_cursor,
    )


@router.post(
    "",
    response_model=TimeBlockEnvelope,
    status_code=status.HTTP_201_CREATED,
)
async def create_timeblock(
    body: TimeBlockCreateRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_role: UserRole = Depends(get_verified_user_role),
    force: bool = Query(default=False, description="Skip conflict detection."),
) -> TimeBlockEnvelope:
    """Create a TimeBlock. Returns 409 on owner-window conflict unless force=true."""

    _ensure_writer(user_role)
    _validate_window(body.start_utc, body.end_utc)
    duration = _duration_minutes(body.start_utc, body.end_utc)

    ledger = _get_ledger()
    _check_conflict(
        ledger,
        tenant_id=tenant_id,
        owner_id=body.owner_id,
        start=body.start_utc,
        end=body.end_utc,
        exclude_block_id=None,
        force=force,
    )

    metadata: dict[str, Any] = {"workspace_id": body.workspace_id}
    if force:
        metadata["forced_overlap"] = True

    block = TimeBlock(
        tenant_id=tenant_id,
        agent_id=body.owner_id,
        objective=body.title,
        plan=body.intent,
        started_at=body.start_utc,
        duration_budget_minutes=duration,
        metadata=metadata,
    )
    persisted = ledger.create_block(block)
    return _envelope(persisted)


@router.get("/{block_id}", response_model=TimeBlockEnvelope)
async def get_timeblock(
    block_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    _user_role: UserRole = Depends(get_verified_user_role),
) -> TimeBlockEnvelope:
    """Read a single TimeBlock by id."""

    ledger = _get_ledger()
    block = ledger.get_block(tenant_id, block_id)
    if block is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"timeblock not found: {block_id}",
        )
    return _envelope(block)


@router.patch("/{block_id}", response_model=TimeBlockEnvelope)
async def update_timeblock(
    block_id: str,
    body: TimeBlockUpdateRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_role: UserRole = Depends(get_verified_user_role),
    force: bool = Query(default=False, description="Skip conflict detection on time changes."),
) -> TimeBlockEnvelope:
    """Partial update. Time edits run conflict detection."""

    _ensure_writer(user_role)
    ledger = _get_ledger()
    current = ledger.get_block(tenant_id, block_id)
    if current is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"timeblock not found: {block_id}",
        )
    if _enum_value(current.state) in {state.value for state in TERMINAL_BLOCK_STATES}:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="cannot patch a terminal timeblock",
        )

    changes: dict[str, Any] = {}
    if body.title is not None:
        changes["objective"] = body.title
    if body.intent is not None:
        changes["plan"] = body.intent

    new_start = body.start_utc or current.started_at.astimezone(UTC)
    new_end = body.end_utc or (
        current.started_at + timedelta(minutes=current.duration_budget_minutes)
    ).astimezone(UTC)

    time_changed = body.start_utc is not None or body.end_utc is not None
    if time_changed:
        _validate_window(new_start, new_end)
        _check_conflict(
            ledger,
            tenant_id=tenant_id,
            owner_id=current.agent_id,
            start=new_start,
            end=new_end,
            exclude_block_id=block_id,
            force=force,
        )
        changes["started_at"] = new_start
        changes["duration_budget_minutes"] = _duration_minutes(new_start, new_end)

    if not changes:
        # No-op patch — return the current envelope.
        return _envelope(current)

    updated = ledger.update_block(tenant_id, block_id, **changes)
    return _envelope(updated)


@router.delete("/{block_id}", response_model=TimeBlockEnvelope)
async def delete_timeblock(
    block_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_role: UserRole = Depends(get_verified_user_role),
) -> TimeBlockEnvelope:
    """Soft delete: state → CANCELLED, stamps ``ended_at``. Audit row preserved."""

    _ensure_writer(user_role)
    ledger = _get_ledger()
    current = ledger.get_block(tenant_id, block_id)
    if current is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"timeblock not found: {block_id}",
        )
    if _enum_value(current.state) == TimeBlockState.CANCELLED.value:
        return _envelope(current)
    if _enum_value(current.state) in {state.value for state in TERMINAL_BLOCK_STATES}:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"cannot cancel a {_enum_value(current.state)} timeblock",
        )

    cancelled = ledger.transition_block(
        tenant_id,
        block_id,
        state=TimeBlockState.CANCELLED,
        outcome=TimeBlockOutcome.ABORTED,
        actual="cancelled via REST",
    )
    return _envelope(cancelled)


@router.post("/{block_id}/move", response_model=TimeBlockEnvelope)
async def move_timeblock(
    block_id: str,
    body: TimeBlockMoveRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_role: UserRole = Depends(get_verified_user_role),
    force: bool = Query(default=False, description="Skip conflict detection."),
) -> TimeBlockEnvelope:
    """Atomic move — rewrites the window in one ledger transition.

    Conflict-checks the new window against other live blocks owned by the
    same agent and rejects 409 unless ``?force=true``.
    """

    _ensure_writer(user_role)
    _validate_window(body.new_start_utc, body.new_end_utc)
    duration = _duration_minutes(body.new_start_utc, body.new_end_utc)

    ledger = _get_ledger()
    current = ledger.get_block(tenant_id, block_id)
    if current is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"timeblock not found: {block_id}",
        )
    if _enum_value(current.state) in {state.value for state in TERMINAL_BLOCK_STATES}:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"cannot move a {_enum_value(current.state)} timeblock",
        )

    _check_conflict(
        ledger,
        tenant_id=tenant_id,
        owner_id=current.agent_id,
        start=body.new_start_utc,
        end=body.new_end_utc,
        exclude_block_id=block_id,
        force=force,
    )

    metadata = dict(current.metadata or {})
    if force:
        metadata["forced_overlap"] = True
    moved = ledger.update_block(
        tenant_id,
        block_id,
        started_at=body.new_start_utc,
        duration_budget_minutes=duration,
        metadata=metadata,
    )
    return _envelope(moved)
