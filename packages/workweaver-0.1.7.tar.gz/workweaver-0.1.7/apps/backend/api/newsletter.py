"""Newsletter campaign API (F-CT-002).

Exposes newsletter campaign lifecycle through REST endpoints:
- POST /api/v1/newsletters/campaigns — create campaign
- GET /api/v1/newsletters/campaigns/{id} — get campaign status
- POST /api/v1/newsletters/campaigns/{id}/send — trigger send
- POST /api/v1/newsletters/campaigns/{id}/schedule — schedule send

Prefix: /api/v1/newsletters
Tags: newsletters
"""

from __future__ import annotations

import logging
from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.newsletter_service import (
    NewsletterService,
    NewsletterServiceError,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/newsletters", tags=["newsletters"])

# ---------------------------------------------------------------------------
# Singleton service (lazily initialized)
# ---------------------------------------------------------------------------

_service: NewsletterService | None = None


def _get_service() -> NewsletterService:
    global _service  # noqa: PLW0603
    if _service is None:
        _service = NewsletterService()
    return _service


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class CreateCampaignRequest(BaseModel):
    """Create a new newsletter campaign."""

    subject: str = Field(..., min_length=1, max_length=500)
    html_body: str = Field(..., min_length=1)
    recipients: list[str] = Field(..., min_length=1)


class CreateCampaignResponse(BaseModel):
    campaign_id: str
    tenant_id: str
    subject: str
    status: str


class ScheduleCampaignRequest(BaseModel):
    """Schedule a campaign for future delivery."""

    send_at: datetime


class CampaignStatusResponse(BaseModel):
    campaign_id: str
    tenant_id: str
    subject: str
    status: str
    created_at: str
    sent_at: str | None = None
    scheduled_at: str | None = None
    total_recipients: int = 0
    sent_count: int = 0
    failed_count: int = 0
    suppressed_count: int = 0


class SendCampaignResponse(BaseModel):
    campaign_id: str
    status: str
    sent_count: int = 0
    failed_count: int = 0


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/campaigns",
    response_model=CreateCampaignResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_campaign(
    body: CreateCampaignRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CreateCampaignResponse:
    """Create a new newsletter campaign in draft status."""
    svc = _get_service()
    try:
        campaign = await svc.create_campaign(
            tenant_id=tenant_id,
            subject=body.subject,
            html_body=body.html_body,
            recipients=body.recipients,
        )
    except ValueError as exc:
        logger.error("Newsletter campaign creation failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid request parameters",
        ) from exc

    return CreateCampaignResponse(
        campaign_id=campaign.campaign_id,
        tenant_id=campaign.tenant_id,
        subject=campaign.subject,
        status=campaign.status,
    )


@router.get(
    "/campaigns/{campaign_id}",
    response_model=CampaignStatusResponse,
)
async def get_campaign_status(
    campaign_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CampaignStatusResponse:
    """Get campaign status and delivery statistics."""
    svc = _get_service()
    result = await svc.get_campaign_status(campaign_id, tenant_id=tenant_id)
    if result is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Campaign not found: {campaign_id}",
        )
    return CampaignStatusResponse(**result)


@router.post(
    "/campaigns/{campaign_id}/send",
    response_model=SendCampaignResponse,
)
async def send_campaign(
    campaign_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SendCampaignResponse:
    """Trigger campaign send (idempotent)."""
    svc = _get_service()
    try:
        campaign = await svc.send_campaign(campaign_id, tenant_id=tenant_id)
    except NewsletterServiceError as exc:
        logger.error("Newsletter send failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Resource not found",
        ) from exc

    return SendCampaignResponse(
        campaign_id=campaign.campaign_id,
        status=campaign.status,
        sent_count=campaign.delivery_stats.get("sent_count", 0),
        failed_count=campaign.delivery_stats.get("failed_count", 0),
    )


@router.post(
    "/campaigns/{campaign_id}/schedule",
    response_model=CampaignStatusResponse,
)
async def schedule_campaign(
    campaign_id: str,
    body: ScheduleCampaignRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CampaignStatusResponse:
    """Schedule a campaign for future delivery."""
    svc = _get_service()
    try:
        _campaign = await svc.schedule_campaign(campaign_id, send_at=body.send_at, tenant_id=tenant_id)
    except NewsletterServiceError as exc:
        logger.error("Newsletter schedule failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Resource not found",
        ) from exc

    result = await svc.get_campaign_status(campaign_id, tenant_id=tenant_id)
    if result is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Campaign scheduled but status unavailable",
        )
    return CampaignStatusResponse(**result)
