"""Workflows API — P2.7 Capability Composition.

CRUD and execution endpoints for user-defined capability workflows.

Prefix: /api/v1/workflows
Tags: workflows

Endpoints:
- GET  /api/v1/workflows            — list workflows for entity
- POST /api/v1/workflows            — create workflow
- POST /api/v1/workflows/{id}/execute — trigger manual execution
- DELETE /api/v1/workflows/{id}     — delete workflow
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException, Path, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.models.workflow import (
    WorkflowCreate,
    WorkflowExecutionResponse,
    WorkflowListResponse,
    WorkflowResponse,
)
from apps.backend.services.workflow_service import (
    WorkflowNotFoundError,
    get_workflow_service,
)
from apps.backend.services.workflow.template_saga_operations import (
    WorkflowTemplateSagaNotFoundError,
    get_workflow_template_saga_service,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/workflows", tags=["workflows"])


# ---------------------------------------------------------------------------
# Request models
# ---------------------------------------------------------------------------


class WorkflowCreateRequest(WorkflowCreate):
    """Request body for workflow creation (adds entity_id)."""

    entity_id: str = Field(..., description="Entity (agent) the workflow belongs to")


class WorkflowExecuteRequest(BaseModel):
    """Optional seed data when manually triggering a workflow."""

    initial_data: dict[str, Any] = Field(
        default_factory=dict,
        description="Seed data available to the first workflow step.",
    )
    context: dict[str, Any] = Field(
        default_factory=dict,
        description="Optional execution metadata propagated to skill dispatch.",
    )


class WorkflowTemplateRunRequest(BaseModel):
    """Run request for a reference WorkflowTemplate saga."""

    initial_data: dict[str, Any] = Field(default_factory=dict)
    idempotency_key: str | None = Field(default=None)
    fail_step_id: str | None = Field(
        default=None,
        description="Test-only deterministic failure injection for saga compensation coverage.",
    )


class WorkflowSagaCompensateRequest(BaseModel):
    """Manual compensation request for a WorkflowTemplate saga run."""

    reason: str | None = Field(default=None)
    idempotency_key: str | None = Field(default=None)


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get(
    "/templates",
    status_code=status.HTTP_200_OK,
    summary="List reference workflow templates",
)
async def list_workflow_templates(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """List WorkflowTemplate saga references visible to this tenant."""
    templates = get_workflow_template_saga_service().list_templates(tenant_id)
    return {"templates": templates, "count": len(templates)}


@router.get(
    "/templates/{template_id}",
    status_code=status.HTTP_200_OK,
    summary="Show a reference workflow template",
)
async def show_workflow_template(
    template_id: str = Path(..., description="WorkflowTemplate ID to inspect"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Show a single WorkflowTemplate saga reference."""
    try:
        return get_workflow_template_saga_service().show_template(tenant_id, template_id)
    except WorkflowTemplateSagaNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resource not found") from exc


@router.post(
    "/{template_id}/run",
    status_code=status.HTTP_200_OK,
    summary="Run a reference workflow template saga",
)
async def run_workflow_template(
    template_id: str = Path(..., description="WorkflowTemplate ID to run"),
    body: WorkflowTemplateRunRequest | None = Body(default=None),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Run a WorkflowTemplate saga with retry-safe idempotency."""
    body = body or WorkflowTemplateRunRequest()
    try:
        return get_workflow_template_saga_service().run_template(
            tenant_id,
            template_id,
            initial_data=body.initial_data,
            idempotency_key=body.idempotency_key,
            fail_step_id=body.fail_step_id,
        )
    except WorkflowTemplateSagaNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resource not found") from exc


@router.get(
    "/runs/{run_id}",
    status_code=status.HTTP_200_OK,
    summary="Show workflow saga run status",
)
async def get_workflow_saga_run(
    run_id: str = Path(..., description="Workflow saga run ID"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return tenant-scoped WorkflowTemplate saga run status."""
    try:
        return get_workflow_template_saga_service().get_run(tenant_id, run_id)
    except WorkflowTemplateSagaNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resource not found") from exc


@router.post(
    "/runs/{run_id}/compensate",
    status_code=status.HTTP_200_OK,
    summary="Compensate workflow saga run",
)
async def compensate_workflow_saga_run(
    run_id: str = Path(..., description="Workflow saga run ID"),
    body: WorkflowSagaCompensateRequest | None = Body(default=None),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Manually run compensation for a tenant-scoped saga run."""
    body = body or WorkflowSagaCompensateRequest()
    try:
        return get_workflow_template_saga_service().compensate_run(
            tenant_id,
            run_id,
            reason=body.reason,
            idempotency_key=body.idempotency_key,
        )
    except WorkflowTemplateSagaNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Resource not found") from exc


@router.get(
    "",
    response_model=WorkflowListResponse,
    status_code=status.HTTP_200_OK,
    summary="List workflows for an entity",
)
async def list_workflows(
    entity_id: str = Query(..., description="Entity ID to filter by"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> WorkflowListResponse:
    """List all workflows belonging to the specified entity."""
    svc = get_workflow_service()
    workflows = svc.list_workflows(tenant_id, entity_id)
    items = [WorkflowResponse(**w) for w in workflows]
    return WorkflowListResponse(workflows=items, count=len(items))


@router.post(
    "",
    response_model=WorkflowResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a new workflow",
)
async def create_workflow(
    body: WorkflowCreateRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> WorkflowResponse:
    """Create a new capability composition workflow."""
    svc = get_workflow_service()
    record = svc.create_workflow(tenant_id, body.entity_id, body)
    return WorkflowResponse(**record)


@router.post(
    "/{workflow_id}/execute",
    response_model=WorkflowExecutionResponse,
    status_code=status.HTTP_200_OK,
    summary="Execute a workflow",
)
async def execute_workflow(
    workflow_id: str = Path(..., description="Workflow ID to execute"),
    body: WorkflowExecuteRequest | None = Body(default=None),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> WorkflowExecutionResponse:
    """Trigger manual execution of a workflow."""
    svc = get_workflow_service()
    body = body or WorkflowExecuteRequest()
    try:
        result = await svc.execute_workflow(
            tenant_id,
            workflow_id,
            initial_data=body.initial_data,
            execution_context=body.context,
        )
    except WorkflowNotFoundError as exc:
        logger.error("Workflow not found: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Resource not found",
        ) from exc
    return WorkflowExecutionResponse(**result)


@router.delete(
    "/{workflow_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a workflow",
)
async def delete_workflow(
    workflow_id: str = Path(..., description="Workflow ID to delete"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> None:
    """Delete a workflow definition."""
    svc = get_workflow_service()
    try:
        svc.delete_workflow(tenant_id, workflow_id)
    except WorkflowNotFoundError as exc:
        logger.error("Workflow not found: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Resource not found",
        ) from exc
