"""Visitor analytics beacon — ingests events from landing page tracking.js.

Unauthenticated endpoint (visitors aren't tenants). Rate-limited by IP.
Events are stored in DynamoDB for funnel analysis and Zoho Analytics sync.
"""

from __future__ import annotations
from apps.backend.config.table_names import resolve_table

import logging
import time
from typing import Any

from fastapi import APIRouter, Request, Response, status
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/beacon", tags=["beacon"])

_TABLE_NAME = resolve_table("tenants")

# Simple in-memory rate limiter (per-IP, 60 events/min)
_RATE_WINDOW = 60.0
_RATE_LIMIT = 60
_rate_buckets: dict[str, list[float]] = {}


def _check_rate(ip: str) -> bool:
    now = time.monotonic()
    bucket = _rate_buckets.get(ip, [])
    bucket = [t for t in bucket if now - t < _RATE_WINDOW]
    if len(bucket) >= _RATE_LIMIT:
        return False
    bucket.append(now)
    _rate_buckets[ip] = bucket
    return True


class VisitorEvent(BaseModel):
    event: str = Field(..., max_length=64, description="Event name (page_view, click, scroll, etc.)")
    page: str = Field("", max_length=512)
    data: dict[str, Any] = Field(default_factory=dict)


class BeaconRequest(BaseModel):
    session_id: str = Field("", max_length=128)
    events: list[VisitorEvent] = Field(default_factory=list, max_length=100)
    utm: dict[str, str] = Field(default_factory=dict)
    referrer: str = Field("", max_length=1024)
    device: dict[str, Any] = Field(default_factory=dict)


@router.post("", status_code=status.HTTP_204_NO_CONTENT)
async def ingest_beacon(body: BeaconRequest, request: Request) -> Response:
    """Ingest visitor tracking events from landing page.

    Unauthenticated — any visitor can send events. Rate-limited by IP.
    """
    ip = request.client.host if request.client else "unknown"
    if not _check_rate(ip):
        return Response(status_code=status.HTTP_429_TOO_MANY_REQUESTS)

    if not body.events:
        return Response(status_code=status.HTTP_204_NO_CONTENT)

    # Store in DynamoDB for analytics pipeline
    try:
        from apps.backend.providers.portable_store import create_portable_store

        store = create_portable_store(_TABLE_NAME)
        import uuid
        from datetime import datetime, UTC

        batch_id = str(uuid.uuid4())[:8]
        ts = datetime.now(UTC).isoformat()

        for i, event in enumerate(body.events[:100]):
            store.put_item(
                pk="VISITOR_EVENTS",
                sk=f"EVENT#{ts}#{batch_id}#{i:03d}",
                data={
                    "Type": "VisitorEvent",
                    "SessionId": body.session_id[:128],
                    "Event": event.event[:64],
                    "Page": event.page[:512],
                    "Data": event.data,
                    "UTM": body.utm,
                    "Referrer": body.referrer[:1024],
                    "Device": body.device,
                    "IP": ip,
                    "Timestamp": ts,
                },
            )
    except Exception:
        logger.exception("Failed to store visitor beacon events")
        # Don't fail the request — beacon is best-effort

    return Response(status_code=status.HTTP_204_NO_CONTENT)
