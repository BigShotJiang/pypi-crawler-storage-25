"""Capability Management API endpoints (P2.1).

Exposes tenant-facing capability listing, toggling, and role template
application. Internal skill wiring is never exposed through these endpoints.

Endpoints:
  GET  /api/v1/capabilities                       -- list capabilities for an entity
  GET  /api/v1/capabilities/readiness              -- capability readiness probe states
  GET  /api/v1/capabilities/{id}/state             -- canonical rollout state (#3543)
  POST /api/v1/capabilities/{id}/toggle            -- enable/disable a capability
  GET  /api/v1/capabilities/templates              -- list role templates
  POST /api/v1/capabilities/templates/{role_name}/apply -- apply a template

Legacy requirement reference: docs/CAPABILITIES.md P2.1
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_id,
    require_admin_user_role,
)
from apps.backend.models.user import UserRole
from apps.backend.services.admin.admin_permission import (
    AdminPermission,
    AdminPermissionCheck,
    AdminRole,
    check_permission,
)
from apps.backend.services.capability_service import (
    CapabilityNotFoundError,
    get_capability_service,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/capabilities", tags=["capabilities"])


def _require_capability_write(
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    admin_role: UserRole = Depends(require_admin_user_role),
) -> AdminPermissionCheck:
    del admin_role
    result = check_permission(
        role=AdminRole.TENANT_ADMIN,
        permission=AdminPermission.CAPABILITIES_WRITE,
        actor_id=user_id,
        target_tenant_ids=(tenant_id,),
        actor_tenant_id=tenant_id,
    )
    if not result.allowed:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=result.reason or "Permission denied",
        )
    return result


_CAPABILITY_WRITE_DEPENDENCIES = [
    Depends(require_admin_user_role),
    Depends(_require_capability_write),
]


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class ToggleCapabilityBody(BaseModel):
    """Request body for toggling a capability."""

    entity_id: str = Field(..., min_length=1, description="AI entity ID")
    enabled: bool = Field(..., description="True to enable, False to disable")


class ApplyTemplateBody(BaseModel):
    """Request body for applying a role template."""

    entity_id: str = Field(..., min_length=1, description="AI entity ID")


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("")
async def list_capabilities(
    entity_id: str = Query(..., min_length=1, description="AI entity ID"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[dict[str, Any]]:
    """List all available capabilities with per-entity enabled/disabled state.

    Returns capability metadata suitable for tenant-facing UI.
    Internal skill IDs are never included.
    """
    svc = get_capability_service()
    caps = svc.list_capabilities(tenant_id=tenant_id, entity_id=entity_id)
    return [c.to_tenant_dict() for c in caps]


@router.get("/readiness")
async def get_capability_readiness(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return capability readiness states from the agent_awareness namespace.

    Lists all probed capabilities with their current readiness level,
    last probe timestamp, and degraded-since metadata when applicable.
    """
    from apps.backend.workmemory.agent_awareness_store import AgentAwarenessStore
    from apps.backend.providers.portable_store import create_portable_store
    from apps.backend.services.zara.zara_awareness_service import (
        translate_readiness_to_view,
    )

    store = AgentAwarenessStore(store=create_portable_store())
    capabilities = store.get_awareness(tenant_id)
    annotated = []
    for row in capabilities:
        row = dict(row)
        readiness = row.get("readiness")
        row["awareness_view"] = (
            translate_readiness_to_view(readiness) if readiness else "not_yet_available"
        )
        annotated.append(row)
    return {
        "tenant_id": tenant_id,
        "capabilities": annotated,
        "total": len(annotated),
    }


@router.get("/{capability_id}/state")
async def get_capability_state(
    capability_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return the canonical rollout state for a capability (#3543).

    Combines the registry-declared state (loaded from capabilities.registry.yaml)
    with the per-tenant probe outcome stored in the agent_awareness namespace,
    so callers see both the global declaration and the tenant-local view.
    """
    from apps.backend.providers.portable_store import create_portable_store
    from apps.backend.services.capability_registry import load_capability_registry
    from apps.backend.services.capability_state_machine import CapabilityStateMachine
    from apps.backend.services.zara.zara_awareness_service import (
        translate_capability_state_to_view,
    )
    from apps.backend.workmemory.agent_awareness_store import (
        AgentAwarenessStore,
        Readiness,
    )

    registry = load_capability_registry()
    try:
        row = registry.find(capability_id)
    except KeyError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"detail": "capability_not_in_registry", "capability_id": capability_id},
        )

    declared_state = row.state
    declared_view = translate_capability_state_to_view(declared_state)

    store = AgentAwarenessStore(store=create_portable_store())
    tenant_row = store.get_capability(tenant_id, capability_id) or {}
    tenant_readiness_value = tenant_row.get("readiness")
    if tenant_readiness_value:
        try:
            tenant_state = CapabilityStateMachine.from_readiness(
                Readiness(tenant_readiness_value)
            )
        except ValueError:
            tenant_state = declared_state
    else:
        tenant_state = declared_state
    tenant_view = translate_capability_state_to_view(tenant_state)

    return {
        "capability_id": capability_id,
        "tenant_id": tenant_id,
        "declared_state": declared_state.value,
        "declared_view": declared_view,
        "tenant_state": tenant_state.value,
        "tenant_view": tenant_view,
        "last_probe_at": tenant_row.get("last_probe_at"),
        "last_probe_outcome": tenant_row.get("last_probe_outcome"),
    }


@router.get("/{capability_id}/probe-history")
async def get_capability_probe_history(
    capability_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return the most recent probe outcome for ``(tenant, capability_id)``.

    Surface for the round-5 audit (#2340 reopen): exposes the
    ``agent_awareness`` row written by ``CapabilityProbeRunner`` so an
    operator can answer "when was capability X last probed and what was
    the outcome?" without reaching for storage. Tenant isolation is
    enforced by the auth dependency — every read is keyed by
    ``tenant_id`` and never crosses tenants.
    """
    from apps.backend.jobs.capability_readiness_probe import (
        get_probe_history_for_tenant,
    )
    from apps.backend.providers.portable_store import create_portable_store
    from apps.backend.workmemory.agent_awareness_store import AgentAwarenessStore

    store = AgentAwarenessStore(store=create_portable_store())
    return get_probe_history_for_tenant(
        tenant_id=tenant_id,
        capability_id=capability_id,
        store=store,
    )


@router.post("/{capability_id}/toggle", dependencies=_CAPABILITY_WRITE_DEPENDENCIES)
async def toggle_capability(
    capability_id: str,
    body: ToggleCapabilityBody,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Enable or disable a single capability for an entity."""
    svc = get_capability_service()
    try:
        return svc.toggle_capability(
            tenant_id=tenant_id,
            entity_id=body.entity_id,
            capability_id=capability_id,
            enabled=body.enabled,
        )
    except CapabilityNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Capability not found: {capability_id}",
        )


@router.get("/templates")
async def list_templates(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """List all available role templates with their capability sets."""
    svc = get_capability_service()
    return svc.list_role_templates()


@router.get("/limitations")
async def get_limitations(
    provider: str = Query(..., min_length=1, description="Connector provider ID (e.g. hubspot, salesforce)"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[dict[str, Any]]:
    """Query limitations for a specific connected provider.

    Returns known limitations including rate limits, auth scope restrictions,
    data access gaps, and feature gaps.
    """
    from apps.backend.dependencies import get_capability_manifest_service

    manifest_svc = get_capability_manifest_service()
    limitations = manifest_svc.get_connector_limitations(tenant_id, provider=provider)
    return [
        {
            "provider": lim.provider,
            "limitation_type": lim.limitation_type,
            "description": lim.description,
            "workaround": lim.workaround,
        }
        for lim in limitations
    ]


@router.post("/templates/{role_name}/apply", dependencies=_CAPABILITY_WRITE_DEPENDENCIES)
async def apply_template(
    role_name: str,
    body: ApplyTemplateBody,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Apply a role template to an entity, bulk-enabling its capabilities."""
    svc = get_capability_service()
    try:
        return svc.apply_role_template(
            tenant_id=tenant_id,
            entity_id=body.entity_id,
            role_name=role_name,
        )
    except ValueError as exc:
        logger.error("Capability registration failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid request parameters",
        )
