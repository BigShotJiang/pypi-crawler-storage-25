"""Admin cost summary API — issues #788 + #795 read-only foundation.

Provides a single endpoint that the founder admin portal can call to render
the live cost picture without spawning multiple requests:

  GET /api/v1/founder/cost/summary

Returns:
- Active cost tier (currently always "solo_dogfood" — flipping it requires
  Terraform apply, which is the follow-up #788 mutation work)
- Real AWS usage cost over the last 7 days, filtered to RECORD_TYPE=Usage
  (the trick that catches credit-masked spend — see commit 3c2f8a57's story)
- Real cost forecast for the next 30 days
- Per-service breakdown (top 10) for the last 7 days
- Backend ECS state (running tasks, deployments)
- Secrets Manager total + monthly cost
- Quick links to the next-action items the operator should know about

The endpoint is wired with `Depends(require_founder)` so only platform
founders can call it. CostExplorer queries are cached in-process for one
hour (CostExplorer charges $0.01 per call, so caching matters).
"""

from __future__ import annotations

import logging
import os
import time
from datetime import date, timedelta
from typing import Any

import boto3
from botocore.exceptions import ClientError
from fastapi import APIRouter, Depends, HTTPException, status

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.services.admin.admin_permission import (
    AdminPermission,
    AdminPermissionCheck,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/founder/cost", tags=["founder-admin-cost"])

_CACHE_TTL_SECONDS = 3600
_cache: dict[str, tuple[float, dict[str, Any]]] = {}

DEFAULT_REGION = os.getenv("AWS_REGION", "us-east-1")


def _cached(key: str) -> dict[str, Any] | None:
    entry = _cache.get(key)
    if not entry:
        return None
    timestamp, value = entry
    if time.time() - timestamp > _CACHE_TTL_SECONDS:
        return None
    return value


def _put_cache(key: str, value: dict[str, Any]) -> None:
    _cache[key] = (time.time(), value)


def _ce_get_usage(days: int = 7, projection_days: int = 3) -> dict[str, Any]:
    """Real cost over the past N days, filtered to RECORD_TYPE=Usage.

    This is the credit-aware view: AWS Backup vault, ECS Fargate, RDS, etc.
    show their real cost even when AWS credits are absorbing 100% of it.

    Uses DAILY granularity so we can compute TWO projections from a single
    Cost Explorer call (CE charges $0.01 per call — caching + single-query
    matters):

    - ``projected_monthly_usd`` — 7-day extrapolation (stable, slow to react)
    - ``recent_projected_monthly_usd`` — last 3 days only (reactive; reflects
      post-fix run rate after a cost-tier change, which the 7d average hides
      because it straddles the transition). See #827 for the 2026-04-09
      finding: the 7d window on 2026-04-09 mixed 5 pre-rationalization days
      with 1 post-fix day, inflating the projection 3×.
    """
    cache_key = f"ce_usage_{days}_{projection_days}"
    cached = _cached(cache_key)
    if cached:
        return cached

    end = date.today()
    start = end - timedelta(days=days)
    ce = boto3.client("ce", region_name="us-east-1")
    try:
        resp = ce.get_cost_and_usage(
            TimePeriod={"Start": start.isoformat(), "End": end.isoformat()},
            Granularity="DAILY",
            Metrics=["UnblendedCost"],
            Filter={
                "Dimensions": {
                    "Key": "RECORD_TYPE",
                    "Values": ["Usage"],
                },
            },
            GroupBy=[{"Type": "DIMENSION", "Key": "SERVICE"}],
        )
    except ClientError as exc:
        logger.warning("ce.get_cost_and_usage failed: %s", exc)
        return {
            "window_days": days,
            "total_usage_usd": None,
            "by_service": [],
            "error": str(exc),
        }

    # Aggregate full window (totals + by-service) AND the trailing projection
    # window in one pass so we stay at exactly one CE API call per cache miss.
    per_day = resp.get("ResultsByTime", [])
    full_groups: dict[str, float] = {}
    recent_total = 0.0
    # ResultsByTime is returned chronologically; the last projection_days
    # entries are the trailing window we project from.
    cutoff_index = max(0, len(per_day) - projection_days)
    recent_days_seen = 0
    for idx, result in enumerate(per_day):
        day_total = 0.0
        for group in result.get("Groups", []):
            svc = (group.get("Keys") or [""])[0]
            amount = float(group.get("Metrics", {}).get("UnblendedCost", {}).get("Amount", "0"))
            full_groups[svc] = full_groups.get(svc, 0.0) + amount
            day_total += amount
        if idx >= cutoff_index:
            recent_total += day_total
            recent_days_seen += 1

    full_total = sum(full_groups.values())
    by_service: list[dict[str, Any]] = sorted(
        ({"service": svc, "usd": round(amt, 2)} for svc, amt in full_groups.items() if abs(amt) > 0.005),
        key=lambda r: -float(r["usd"]),
    )[:10]

    payload = {
        "window_days": days,
        "projection_window_days": recent_days_seen,
        "total_usage_usd": round(full_total, 2),
        "projected_monthly_usd": round(full_total * 30 / max(1, days), 2),
        "recent_projected_monthly_usd": round(recent_total * 30 / max(1, recent_days_seen), 2)
        if recent_days_seen > 0
        else None,
        "by_service": by_service,
    }
    _put_cache(cache_key, payload)
    return payload


def _ce_get_forecast(days: int = 30) -> dict[str, Any]:
    cache_key = f"ce_forecast_{days}"
    cached = _cached(cache_key)
    if cached:
        return cached

    start = date.today() + timedelta(days=1)
    end = start + timedelta(days=days)
    ce = boto3.client("ce", region_name="us-east-1")
    try:
        resp = ce.get_cost_forecast(
            TimePeriod={"Start": start.isoformat(), "End": end.isoformat()},
            Metric="UNBLENDED_COST",
            Granularity="MONTHLY",
        )
    except ClientError as exc:
        logger.warning("ce.get_cost_forecast failed: %s", exc)
        return {"days": days, "forecast_usd": None, "error": str(exc)}

    total = float(resp.get("Total", {}).get("Amount", "0"))
    payload = {"days": days, "forecast_usd": round(total, 2)}
    _put_cache(cache_key, payload)
    return payload


def _ecs_state() -> dict[str, Any]:
    cache_key = "ecs_state"
    cached = _cached(cache_key)
    if cached:
        return cached

    try:
        ecs = boto3.client("ecs", region_name=DEFAULT_REGION)
        cluster = "workweaver-ecs-cluster-prod"
        services_resp = ecs.list_services(cluster=cluster, maxResults=100)
        svc_arns = services_resp.get("serviceArns", [])
        services = []
        for chunk_start in range(0, len(svc_arns), 10):
            chunk = svc_arns[chunk_start : chunk_start + 10]
            desc = ecs.describe_services(cluster=cluster, services=chunk)
            for svc in desc.get("services", []):
                services.append(
                    {
                        "name": svc.get("serviceName"),
                        "desired": svc.get("desiredCount"),
                        "running": svc.get("runningCount"),
                        "deployment_state": (svc.get("deployments") or [{}])[0].get("rolloutState"),
                    }
                )
    except ClientError as exc:
        logger.warning("ecs state lookup failed: %s", exc)
        return {"error": str(exc), "services": []}

    payload = {"cluster": cluster, "services": services}
    _put_cache(cache_key, payload)
    return payload


def _secrets_manager_state() -> dict[str, Any]:
    cache_key = "secrets_state"
    cached = _cached(cache_key)
    if cached:
        return cached

    try:
        sm = boto3.client("secretsmanager", region_name=DEFAULT_REGION)
        all_secrets: list[str] = []
        next_token: str | None = None
        while True:
            kwargs: dict[str, Any] = {"MaxResults": 100}
            if next_token:
                kwargs["NextToken"] = next_token
            resp = sm.list_secrets(**kwargs)
            all_secrets.extend(s["Name"] for s in resp.get("SecretList", []))
            next_token = resp.get("NextToken")
            if not next_token:
                break
    except ClientError as exc:
        logger.warning("secrets manager list failed: %s", exc)
        return {"error": str(exc), "count": None}

    count = len(all_secrets)
    payload = {
        "count": count,
        "monthly_cost_usd": round(count * 0.40, 2),
    }
    _put_cache(cache_key, payload)
    return payload


def _cost_tier_summary() -> dict[str, Any]:
    """Read the cost_tier from terraform.auto.tfvars (best effort).

    Mutating the tier requires running `terraform apply`, which is the
    #788 follow-up. This endpoint is read-only.
    """
    tfvars_path = "/app/infra/terraform/dev/terraform.auto.tfvars"
    tier = "unknown"
    try:
        with open(tfvars_path, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if line.startswith("cost_tier"):
                    parts = line.split("=", 1)
                    if len(parts) == 2:
                        tier = parts[1].strip().strip('"').strip("'") or "unknown"
                        break
    except (OSError, IOError):
        # Backend container doesn't ship the .tfvars file by default; that's fine.
        # Default to solo_dogfood since that's what was applied 2026-04-08.
        tier = "solo_dogfood"

    if tier == "solo_dogfood":
        capability_summary = {
            "tier": "solo_dogfood",
            "backend_replicas": 1,
            "learning_replicas": 1,
            "pgvector_multi_az": False,
            "rds_backup_days": 1,
            "backup_daily_days": 7,
            "backup_monthly_enabled": False,
            "cross_region_dr": False,
            "blog_enabled": False,
            # Re-grounded 2026-04-09 per #827 audit: the aspirational "$50/mo"
            # target didn't survive contact with public IPv4 charges
            # ($0.005/hour per in-use IP, ~$25/mo on 7 workweaver IPs),
            # baseline Fargate pricing ($54/mo for 4 task-minimum), and
            # RDS + Secrets + ALB floors. $85/mo is the memory-backed
            # engineered estimate ($70-100 range midpoint).
            "estimated_monthly_usd": 85,
        }
    elif tier == "production":
        capability_summary = {
            "tier": "production",
            "backend_replicas": 2,
            "learning_replicas": 2,
            "pgvector_multi_az": True,
            "rds_backup_days": 35,
            "backup_daily_days": 35,
            "backup_monthly_enabled": True,
            "cross_region_dr": True,
            "blog_enabled": False,
            "estimated_monthly_usd": 240,
        }
    else:
        capability_summary = {"tier": tier, "estimated_monthly_usd": None}

    return capability_summary


@router.get("/summary")
async def get_cost_summary(_perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.BILLING_READ))) -> dict[str, Any]:
    """Single read-only call that returns the live cost picture.

    Wired into the founder admin portal at admin.workweaver.ai/admin/cost/.
    """
    try:
        return {
            "cost_tier": _cost_tier_summary(),
            "usage": _ce_get_usage(days=7),
            "forecast": _ce_get_forecast(days=30),
            "ecs": _ecs_state(),
            "secrets_manager": _secrets_manager_state(),
            "notes": [
                "AWS usage shown is filtered by RECORD_TYPE=Usage. The console default "
                "view shows $0 when credits absorb spend — this view exposes real burn.",
                "Flipping cost_tier from solo_dogfood → production is currently a Terraform "
                "apply, not an in-portal toggle. See #788 for the toggle wiring.",
            ],
        }
    except Exception as exc:  # pragma: no cover - boto3 surface
        logger.exception("admin_cost_summary_failed")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Cost summary failed: {exc}",
        ) from exc
