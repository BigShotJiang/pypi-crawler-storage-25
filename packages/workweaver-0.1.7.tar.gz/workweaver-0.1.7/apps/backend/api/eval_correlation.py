"""Per-skill eval-correlation read API (issue #2050).

Surfaces the latest persisted Matthews Correlation Coefficient (MCC) report
for a skill via ``GET /api/v1/skills/{skill_id}/eval-correlation`` so the L3
admin UI can render the eval-vs-outcome correlation panel without recomputing
the matrix on every page load.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.config.table_names import resolve_table
from apps.backend.providers.portable_store import create_portable_store
from apps.backend.schemas.error_response import ErrorResponse
from apps.backend.services.eval_correlation_service import (
    EvalCorrelationService,
    SkillCorrelationReport,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/skills", tags=["skills"])


class EvalCorrelationResponse(BaseModel):
    """API representation of a per-skill MCC report."""

    schema_version: int
    skill_id: str
    tenant_id: str
    week_id: str
    window_start: str
    window_end: str
    n_executions: int
    observed_eval_count: int
    missing_eval_count: int
    missing_eval_rate: float
    eval_pass_rate: float
    real_success_rate: float
    confusion_matrix: dict[str, int] = Field(default_factory=dict)
    mcc: float | None
    flagged: bool
    flag_reasons: list[str] = Field(default_factory=list)
    threshold: float
    missing_eval_rate_threshold: float
    min_samples: int
    success_threshold: float
    sample_execution_ids: list[str] = Field(default_factory=list)
    created_at: str

    @classmethod
    def from_report(cls, report: SkillCorrelationReport) -> "EvalCorrelationResponse":
        return cls(
            schema_version=report.schema_version,
            skill_id=report.skill_id,
            tenant_id=report.tenant_id,
            week_id=report.week_id,
            window_start=report.window_start,
            window_end=report.window_end,
            n_executions=report.n_executions,
            observed_eval_count=report.observed_eval_count,
            missing_eval_count=report.missing_eval_count,
            missing_eval_rate=report.missing_eval_rate,
            eval_pass_rate=report.eval_pass_rate,
            real_success_rate=report.real_success_rate,
            confusion_matrix=dict(report.confusion_matrix),
            mcc=report.mcc,
            flagged=report.flagged,
            flag_reasons=list(report.flag_reasons),
            threshold=report.threshold,
            missing_eval_rate_threshold=report.missing_eval_rate_threshold,
            min_samples=report.min_samples,
            success_threshold=report.success_threshold,
            sample_execution_ids=list(report.sample_execution_ids),
            created_at=report.created_at,
        )


_service_override: EvalCorrelationService | None = None


def configure_eval_correlation_service(service: EvalCorrelationService | None) -> None:
    """Override the API-resolved service for tests."""

    global _service_override
    _service_override = service


def _get_service() -> EvalCorrelationService:
    if _service_override is not None:
        return _service_override
    report_store = create_portable_store(resolve_table("skill_eval_correlation"))
    source_store = create_portable_store(resolve_table("tenants"))
    return EvalCorrelationService(report_store=report_store, source_store=source_store)


@router.get(
    "/{skill_id}/eval-correlation",
    response_model=EvalCorrelationResponse,
    responses={404: {"model": ErrorResponse}},
)
async def get_eval_correlation(
    skill_id: str,
    week_id: str | None = Query(default=None, description="ISO YYYY-Www week id; omit for the latest report"),
    service: EvalCorrelationService = Depends(_get_service),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> EvalCorrelationResponse:
    """Return the most recent MCC report for one skill, or 404 if none exists."""

    report = service.get_report(tenant_id=tenant_id, skill_id=skill_id, week_id=week_id)
    if report is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No eval-correlation report for skill {skill_id}",
        )
    return EvalCorrelationResponse.from_report(report)


@router.get(
    "/eval-correlation/flagged",
    responses={503: {"model": ErrorResponse}},
)
async def list_flagged_eval_correlations(
    week_id: str | None = Query(default=None, description="ISO YYYY-Www week id to filter by"),
    limit: int = Query(default=50, ge=1, le=500),
    service: EvalCorrelationService = Depends(_get_service),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return reports flagged below the configured MCC threshold."""

    flagged = service.list_flagged(tenant_id=tenant_id, week_id=week_id, limit=limit)
    return {
        "tenant_id": tenant_id,
        "week_id": week_id,
        "count": len(flagged),
        "reports": [EvalCorrelationResponse.from_report(report).model_dump(mode="json") for report in flagged],
    }
