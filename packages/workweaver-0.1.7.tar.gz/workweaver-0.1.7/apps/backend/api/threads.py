"""Canonical thread read API."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Path, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.thread_service import ThreadService, get_thread_service

router = APIRouter(prefix="/api/v1/threads", tags=["threads"])


class ThreadMessageResponse(BaseModel):
    message_id: str = ""
    channel: str = "email"
    direction: str = "inbound"
    event_type: str = ""
    participant: str = ""
    subject: str = ""
    body: str = ""
    preview: str = ""
    created_at: str = ""
    thread_id: str = ""
    status: str = ""


class ThreadResponse(BaseModel):
    thread_id: str
    channel: str = "email"
    thread_kind: str = "email"
    status: str = ""
    subject: str = ""
    contact: str = ""
    participants: list[str] = Field(default_factory=list)
    last_message: str = ""
    last_message_at: str = ""
    message_count: int = 0
    unread: bool = False
    unread_count: int = 0
    channel_events: list[dict[str, Any]] = Field(default_factory=list)
    message_ids: list[str] = Field(default_factory=list)
    messages: list[ThreadMessageResponse] = Field(default_factory=list)
    entity_id: str = ""
    workitem_id: str = ""
    mission_ref: str = ""
    sequence_id: str = ""
    provider_message_id: str = ""
    outcome: str = ""
    created_at: str = ""
    updated_at: str = ""


class ThreadListResponse(BaseModel):
    items: list[ThreadResponse] = Field(default_factory=list)
    count: int = 0


def _get_service() -> ThreadService:
    return get_thread_service()


@router.get("/{thread_id}", response_model=ThreadResponse)
async def get_thread_endpoint(
    thread_id: str = Path(..., min_length=1),
    tenant_id: str = Depends(get_verified_tenant_id),
    service: ThreadService = Depends(_get_service),
) -> ThreadResponse:
    thread = service.get_thread(tenant_id=tenant_id, thread_id=thread_id)
    if thread is None:
        raise HTTPException(status_code=404, detail=f"Thread not found: {thread_id}")
    return ThreadResponse(**thread)


@router.get("", response_model=ThreadListResponse)
async def list_threads_endpoint(
    tenant_id: str = Depends(get_verified_tenant_id),
    thread_type: str | None = Query(None, alias="type"),
    status: str | None = Query(None),
    entity_id: str | None = Query(None),
    limit: int = Query(50, ge=1, le=200),
    service: ThreadService = Depends(_get_service),
) -> ThreadListResponse:
    fetch_limit = 200 if any((thread_type, status, entity_id)) else limit
    threads = service.list_threads(tenant_id=tenant_id, limit=fetch_limit)
    items: list[ThreadResponse] = []
    for thread in threads:
        if thread_type and thread.get("thread_kind") != thread_type and thread.get("channel") != thread_type:
            continue
        if status and str(thread.get("status") or "").strip().lower() != status.strip().lower():
            continue
        if entity_id and str(thread.get("entity_id") or "").strip() != str(entity_id).strip():
            continue
        items.append(ThreadResponse(**thread))
        if len(items) >= limit:
            break
    return ThreadListResponse(items=items, count=len(items))
