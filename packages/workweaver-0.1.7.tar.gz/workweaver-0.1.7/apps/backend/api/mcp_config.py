"""MCP client configuration snippets for external agent hosts."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id


router = APIRouter(prefix="/api/v1/mcp", tags=["mcp-config"])


class CursorMcpConfigResponse(BaseModel):
    path: str = ".cursor/mcp.json"
    scope: str = "acp.cursor"
    mcp_json: dict[str, Any] = Field(..., description="Cursor .cursor/mcp.json payload.")


@router.get("/cursor-config", response_model=CursorMcpConfigResponse)
async def get_cursor_mcp_config(
    api_base_url: str = Query(default="https://api.workweaver.ai"),
    server_name: str = Query(default="workweaver"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CursorMcpConfigResponse:
    """Return a tenant-scoped `.cursor/mcp.json` snippet for Workweaver MCP."""

    base_url = api_base_url.rstrip("/")
    name = _safe_server_name(server_name)
    return CursorMcpConfigResponse(
        mcp_json={
            "mcpServers": {
                name: {
                    "url": f"{base_url}/mcp/http/v1/messages",
                    "headers": {
                        "Authorization": "Bearer ${WORKWEAVER_API_KEY}",
                        "x-tenant-id": tenant_id,
                        "x-workmemory-no-train": "true",
                        "x-workmemory-training-allowed": "false",
                    },
                }
            }
        }
    )


def _safe_server_name(value: str) -> str:
    cleaned = "".join(ch for ch in str(value or "workweaver").strip() if ch.isalnum() or ch in {"-", "_"})
    return cleaned or "workweaver"
