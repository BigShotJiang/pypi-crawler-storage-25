"""Canonical judgment-debt feed API."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, get_verified_user_id
from apps.backend.services.judgment_feed_service import (
    JudgmentFeedService,
    get_judgment_feed_service,
)

router = APIRouter(prefix="/api/v1/judgments", tags=["judgments"])


class JudgmentFeedCounts(BaseModel):
    total: int = 0
    approvals: int = 0
    entity: int = 0
    proactive: int = 0
    learning: int = 0
    budget: int = 0
    deadline: int = 0


class JudgmentFeedItem(BaseModel):
    id: str
    source: str
    kind: str
    title: str
    detail: str
    status: str
    timestamp: str = ""
    href: str = ""
    badges: list[str] = Field(default_factory=list)
    actions: list[dict[str, Any]] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)
    policy_proposal: dict[str, Any] | None = None


class JudgmentFeedResponse(BaseModel):
    tenant_id: str
    summary: str
    counts: JudgmentFeedCounts
    items: list[JudgmentFeedItem] = Field(default_factory=list)
    unavailable_sources: list[str] = Field(default_factory=list)


class JudgmentActionRequest(BaseModel):
    source: str = Field(..., min_length=1)
    item_id: str = Field(..., min_length=1)
    action: str = Field(..., min_length=1)
    reason: str | None = None
    action_id: str | None = None
    payload: dict[str, Any] = Field(default_factory=dict)


class JudgmentActionResponse(BaseModel):
    success: bool = True
    source: str
    item_id: str
    action: str
    message: str
    result: dict[str, Any] = Field(default_factory=dict)
    summary: str = ""
    remaining_counts: JudgmentFeedCounts = Field(default_factory=JudgmentFeedCounts)


def _get_service() -> JudgmentFeedService:
    return get_judgment_feed_service()


@router.get("/feed", response_model=JudgmentFeedResponse)
async def get_judgment_feed(
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(12, ge=1, le=50),
    service: JudgmentFeedService = Depends(_get_service),
) -> JudgmentFeedResponse:
    payload = await service.build_feed(tenant_id, limit=limit)
    return JudgmentFeedResponse(**payload)


@router.post("/actions", response_model=JudgmentActionResponse, status_code=status.HTTP_200_OK)
async def perform_judgment_action(
    request: JudgmentActionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
    service: JudgmentFeedService = Depends(_get_service),
) -> JudgmentActionResponse:
    try:
        payload = await service.perform_action(
            tenant_id=tenant_id,
            source=request.source,
            item_id=request.item_id,
            action=request.action,
            actor_id=actor_id,
            reason=request.reason,
            action_id=request.action_id,
            payload=request.payload,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Judgment action service temporarily unavailable",
        ) from exc

    return JudgmentActionResponse(**payload)
