"""Edge-Cloud session handoff API routes.

Provides REST endpoints for the edge<->cloud seamless handoff primitive (#1605).
Edge clients (ww CLI) claim cloud sessions, checkpoint state, and resume
from any surface (edge, cloud dashboard, MCP).

The router translates between the shared ``SessionResponse`` wire format
(used by the CLI) and the internal ``HandoffRecord`` / ``SyncPayload``
domain models from the service layer.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.edge_cloud.edge_cloud_handoff import (
    EdgeCloudHandoff,
    HandoffDirection as SvcDirection,
    HandoffRecord,
    HandoffStatus as SvcStatus,
    InMemoryEdgeCloudStore,
)
from apps.shared.edge_cloud_models import (
    CheckpointSessionRequest,
    ClaimSessionRequest,
    HandoffDirection,
    HandoffStatus,
    SessionResponse,
    SyncSessionRequest,
)

router = APIRouter(prefix="/api/v1/edge-cloud", tags=["edge-cloud"])

# Use InMemoryEdgeCloudStore as default (production will wire DynamoDB via DI)
handoff_service = EdgeCloudHandoff(store=InMemoryEdgeCloudStore())


# ---------------------------------------------------------------------------
# Mapping helpers
# ---------------------------------------------------------------------------

_DIRECTION_MAP = {
    HandoffDirection.LOCAL_TO_CLOUD: SvcDirection.LOCAL_TO_CLOUD,
    HandoffDirection.CLOUD_TO_LOCAL: SvcDirection.CLOUD_TO_LOCAL,
    HandoffDirection.BIDIRECTIONAL: SvcDirection.BIDIRECTIONAL,
}

_SVC_DIRECTION_MAP = {v: k for k, v in _DIRECTION_MAP.items()}

_STATUS_MAP = {
    SvcStatus.PENDING: HandoffStatus.PENDING,
    SvcStatus.IN_PROGRESS: HandoffStatus.IN_PROGRESS,
    SvcStatus.COMPLETED: HandoffStatus.COMPLETED,
    SvcStatus.FAILED: HandoffStatus.FAILED,
    SvcStatus.ROLLED_BACK: HandoffStatus.ROLLED_BACK,
}


def _record_to_response(record: HandoffRecord) -> SessionResponse:
    """Map an internal HandoffRecord to the shared SessionResponse wire format."""

    return SessionResponse(
        session_id=record.handoff_id,
        tenant_id=record.tenant_id,
        status=_STATUS_MAP.get(record.status, HandoffStatus.PENDING),
        direction=_SVC_DIRECTION_MAP.get(
            record.payload.direction, HandoffDirection.BIDIRECTIONAL
        ),
        surface=record.payload.source,
        created_at=record.started_at,
        completed_at=record.completed_at,
        handoff_id=record.handoff_id,
        error_message=record.error_message,
    )


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.post("/sessions/claim", response_model=SessionResponse)
async def claim_session(
    req: ClaimSessionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SessionResponse:
    """Claim a cloud session from an edge or MCP surface."""
    record = handoff_service.initiate(
        tenant_id=tenant_id,
        direction=SvcDirection.CLOUD_TO_LOCAL,
        source=req.surface,
        target="edge",
        data_keys=["session_state"],
    )
    return _record_to_response(record)


@router.post("/sessions/checkpoint", response_model=SessionResponse)
async def checkpoint_session(
    req: CheckpointSessionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SessionResponse:
    """Checkpoint edge state back to cloud."""
    record = handoff_service.initiate(
        tenant_id=tenant_id,
        direction=SvcDirection.LOCAL_TO_CLOUD,
        source=req.surface,
        target="cloud",
        data_keys=list(req.payload_data.keys()) if req.payload_data else ["session_state"],
    )
    return _record_to_response(record)


@router.post("/sessions/sync", response_model=SessionResponse)
async def sync_session(
    req: SyncSessionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SessionResponse:
    """Bidirectional sync between edge and cloud."""
    record = handoff_service.initiate(
        tenant_id=tenant_id,
        direction=_DIRECTION_MAP.get(req.direction, SvcDirection.BIDIRECTIONAL),
        source="edge",
        target="cloud",
        data_keys=["session_state"],
    )
    return _record_to_response(record)


@router.get("/sessions/{session_id}", response_model=SessionResponse | None)
async def get_session_status(
    session_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SessionResponse | None:
    """Get the status of a handoff session."""
    record = handoff_service.get_status(session_id)
    if record is None:
        return None
    if record.tenant_id != tenant_id:
        return None
    return _record_to_response(record)


@router.get("/sessions", response_model=list[SessionResponse])
async def list_sessions(
    tenant_id: str = Depends(get_verified_tenant_id),
    status: HandoffStatus | None = Query(None, description="Filter by status"),
) -> list[SessionResponse]:
    """List all handoff sessions for a tenant."""
    records = handoff_service.list_handoffs(tenant_id)
    responses = [_record_to_response(r) for r in records]
    if status:
        responses = [r for r in responses if r.status == status]
    return responses


@router.post("/sessions/{session_id}/fail", response_model=SessionResponse)
async def fail_session(
    session_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    reason: str = Query("unknown"),
) -> SessionResponse:
    """Mark a handoff session as failed."""
    record = handoff_service.get_status(session_id)
    if not record or record.tenant_id != tenant_id:
        raise HTTPException(status_code=404, detail="Session not found")
    failed = handoff_service.fail(record.handoff_id, reason)
    return _record_to_response(failed)


@router.post("/sessions/{session_id}/rollback", response_model=SessionResponse)
async def rollback_session(
    session_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SessionResponse:
    """Roll back a handoff session."""
    record = handoff_service.get_status(session_id)
    if not record or record.tenant_id != tenant_id:
        raise HTTPException(status_code=404, detail="Session not found")
    rolled_back = handoff_service.rollback(record.handoff_id)
    return _record_to_response(rolled_back)
