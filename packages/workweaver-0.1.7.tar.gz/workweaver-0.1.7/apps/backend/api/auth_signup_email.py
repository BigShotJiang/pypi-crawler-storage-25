"""Email signup and verification routes."""

from __future__ import annotations

import os
import secrets
from datetime import datetime, timedelta, UTC

import ulid
from fastapi import APIRouter, HTTPException, Request, status

from apps.backend.api.auth_models import (
    AuthProvider,
    EmailPasswordSignupRequest,
    EmailVerificationRequest,
    EmailVerificationResendRequest,
    SignupResponse,
)
from apps.backend.api.auth_helpers import build_signup_consent, get_signup_terms_version
from apps.backend.api.auth_signup_shared import get_auth_signup_facade, logger
from apps.backend.api.rate_limit import limiter  # noqa: E402

router = APIRouter()


@router.post(
    "/signup/email",
    response_model=SignupResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Initiate email/password signup",
    description="Sign up with AWS Cognito and send verification email. Returns 202 Accepted.",
)
@limiter.limit("5/minute")
async def signup_with_email(request: Request, body: EmailPasswordSignupRequest) -> SignupResponse:
    """Initiate email/password signup flow using AWS Cognito."""
    if not body.accepted_terms or not body.accepted_privacy:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail={
                "error": "terms_not_accepted",
                "message": "You must accept the Terms of Service and Privacy Policy to sign up.",
            },
        )
    facade = get_auth_signup_facade()
    signup_consent = build_signup_consent(body.accepted_terms, body.accepted_privacy)
    try:
        logger.info("Email signup request for %s", facade._redact_email(body.email))
        normalized_email = body.email.lower()
        selected_region_code, selected_region_label = facade._resolve_signup_region(
            email=normalized_email,
            preferred_region=body.preferred_region,
        )
        has_invite = bool(
            (body.invite_token and body.invite_token.strip())
            or (body.sub_tenant_invite_token and body.sub_tenant_invite_token.strip())
        )
        if not facade._domain_allowed_for_provisioning(normalized_email, has_valid_invite=has_invite):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=facade._domain_not_allowed_detail(),
            )

        if facade._disable_cognito():
            logger.info(
                "Skipping Cognito + verification for signup with email=%s",
                facade._redact_email(normalized_email),
            )
            owner_user_id = f"email_{ulid.new()}"
            signup_response = await facade._complete_signup_after_identity_verification(
                owner_user_id=owner_user_id,
                email=normalized_email,
                auth_provider=AuthProvider.EMAIL_PASSWORD,
                owner_name=body.name,
                preferred_region=body.preferred_region,
                product="workweaver",
                invite_token=body.invite_token or None,
                sub_tenant_invite_token=body.sub_tenant_invite_token or None,
                consent=signup_consent,
            )
            logger.info(
                "Signup completed without Cognito for %s, tenant_id=%s",
                facade._redact_email(body.email),
                signup_response.tenant_id,
            )
            return signup_response

        cognito_idp = facade._require_cognito_idp()
        verifications_table = facade._require_verifications_table()

        user_pool_id = os.environ.get("COGNITO_USER_POOL_ID")
        client_id = os.environ.get("COGNITO_CLIENT_ID")
        if not user_pool_id or not client_id:
            logger.error("Cognito configuration missing")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "error": "configuration_error",
                    "message": "Authentication service not properly configured",
                },
            )

        verification_code = f"{secrets.randbelow(900000) + 100000}"
        expires_at = datetime.now(UTC) + timedelta(hours=24)
        ttl_seconds = int((expires_at - datetime.now(UTC)).total_seconds())

        verification_item_data: dict = {
            "pk": f"VERIFICATION#{normalized_email}",
            "sk": f"CODE#{verification_code}",
            "email": normalized_email,
            "name": body.name or "",
            "password_hash": "REDACTED",
            "auth_provider": AuthProvider.EMAIL_PASSWORD.value,
            "preferred_region_code": selected_region_code,
            "preferred_region_label": selected_region_label,
            "product": "workweaver",
            "created_at": datetime.now(UTC).isoformat(),
            "expires_at": expires_at.isoformat(),
            "ttl": ttl_seconds,
            # GDPR consent tracking
            "accepted_terms": signup_consent.accepted_terms,
            "accepted_privacy": signup_consent.accepted_privacy,
            "consent_at": signup_consent.consent_at,
            "terms_version": signup_consent.terms_version,
        }
        if body.invite_token:
            verification_item_data["invite_token"] = body.invite_token
        if body.sub_tenant_invite_token:
            verification_item_data["sub_tenant_invite_token"] = body.sub_tenant_invite_token
        verifications_table.put_item(Item=verification_item_data)

        try:
            from apps.backend.providers.identity_provider import get_identity_provider

            _identity = get_identity_provider()
            user_sub = _identity.create_user(
                email=normalized_email,
                password=body.password,
                name=body.name or "",
            )
            logger.info(
                "Signup initiated for %s, UserSub=%s",
                facade._redact_email(body.email),
                user_sub,
            )
        except cognito_idp.exceptions.UsernameExistsException:
            logger.warning("Cognito user already exists for %s", facade._redact_email(body.email))
            try:
                user_status = cognito_idp.admin_get_user(UserPoolId=user_pool_id, Username=normalized_email)
                user_status_val = user_status.get("UserStatus", "")
                if user_status_val == "CONFIRMED":
                    raise HTTPException(
                        status_code=status.HTTP_409_CONFLICT,
                        detail={
                            "error": "user_exists",
                            "message": "An account with this email already exists. Please sign in.",
                            "email": body.email,
                        },
                    )

                cognito_idp.resend_confirmation_code(ClientId=client_id, Username=normalized_email)
                logger.info("Resent confirmation code to %s", facade._redact_email(body.email))
                return SignupResponse(
                    tenant_id=f"pending_{ulid.new()}",
                    user_id=f"pending_{ulid.new()}",
                    status="pending_verification",
                    email=normalized_email,
                    role="pending",
                    auth_provider=AuthProvider.EMAIL_PASSWORD.value,
                    next_step="verify_email",
                    stripe_checkout_url=None,
                    selected_region_code=selected_region_code,
                    selected_region_label=selected_region_label,
                )
            except HTTPException:
                raise
            except Exception as exc:
                logger.error("Error checking existing user: %s", exc)
                raise HTTPException(
                    status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                    detail={
                        "error": "signup_failed",
                        "message": "Failed to complete signup. Please try again.",
                    },
                ) from exc
        except cognito_idp.exceptions.InvalidPasswordException as exc:
            logger.warning("Invalid password for %s: %s", facade._redact_email(body.email), exc)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "invalid_password",
                    "message": str(exc),
                },
            ) from exc
        except cognito_idp.exceptions.InvalidParameterException as exc:
            logger.warning("Invalid parameter for %s: %s", facade._redact_email(body.email), exc)
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "invalid_parameter",
                    "message": str(exc),
                },
            ) from exc

        logger.info("Email signup initiated for %s", facade._redact_email(body.email))
        return SignupResponse(
            tenant_id=f"pending_{ulid.new()}",
            user_id=f"pending_{ulid.new()}",
            status="pending_verification",
            email=normalized_email,
            role="pending",
            auth_provider=AuthProvider.EMAIL_PASSWORD.value,
            next_step="verify_email",
            stripe_checkout_url=None,
            selected_region_code=selected_region_code,
            selected_region_label=selected_region_label,
        )

    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Error in email signup for %s: %s", facade._redact_email(body.email), exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "signup_failed",
                "message": "Failed to initiate signup. Please try again.",
            },
        ) from exc


@router.post(
    "/signup/email/resend",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Resend signup verification email",
    description="Resend Cognito verification code for email/password signup without requiring password payload.",
)
@limiter.limit("3/minute")
async def resend_signup_email_verification(request: Request, body: EmailVerificationResendRequest) -> dict:
    """Resend verification code for pending email/password signup."""
    facade = get_auth_signup_facade()
    normalized_email = body.email.lower()
    selected_region_code, selected_region_label = facade._resolve_signup_region(
        email=normalized_email,
        preferred_region=None,
    )

    if facade._disable_cognito():
        logger.info(
            "Verification resend simulated in DISABLE_COGNITO mode for %s", facade._redact_email(normalized_email)
        )
        return {
            "status": "pending_verification",
            "email": normalized_email,
            "next_step": "verify_email",
            "selected_region_code": selected_region_code,
            "selected_region_label": selected_region_label,
        }

    cognito_idp = facade._require_cognito_idp()
    client_id = os.environ.get("COGNITO_CLIENT_ID")
    if not client_id:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "configuration_error",
                "message": "Authentication service not properly configured",
            },
        )

    try:
        cognito_idp.resend_confirmation_code(ClientId=client_id, Username=normalized_email)
        logger.info("Resent confirmation code to %s", facade._redact_email(normalized_email))
    except Exception as exc:
        error_name = exc.__class__.__name__
        if error_name in {"LimitExceededException", "TooManyRequestsException"}:
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail={
                    "error": "resend_rate_limited",
                    "message": "Too many resend attempts. Please wait before trying again.",
                },
            ) from exc
        if error_name == "UserNotFoundException":
            logger.info("Resend requested for non-existing user: %s", facade._redact_email(normalized_email))
        else:
            logger.error("Failed to resend confirmation code for %s: %s", facade._redact_email(normalized_email), exc)
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "error": "resend_failed",
                    "message": "Failed to resend verification code.",
                },
            ) from exc

    return {
        "status": "pending_verification",
        "email": normalized_email,
        "next_step": "verify_email",
        "selected_region_code": selected_region_code,
        "selected_region_label": selected_region_label,
    }


@router.post(
    "/signup/email/verify",
    response_model=SignupResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Verify email and complete signup",
    description="Verify email via Cognito code and create tenant. Redirects to Stripe Checkout.",
)
@limiter.limit("10/minute")
async def verify_email_and_complete_signup(request: Request, body: EmailVerificationRequest) -> SignupResponse:
    """Verify email code and complete tenant creation."""
    facade = get_auth_signup_facade()
    try:
        cognito_idp = facade._require_cognito_idp()
        verifications_table = facade._require_verifications_table()
        logger.info("Email verification request for %s", facade._redact_email(body.email))
        normalized_email = body.email.lower()

        response = verifications_table.query(
            KeyConditionExpression="pk = :pk",
            ExpressionAttributeValues={":pk": f"VERIFICATION#{normalized_email}"},
            Limit=1,
        )
        if not response.get("Items"):
            logger.warning("No pending verification found for %s", facade._redact_email(body.email))
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "error": "verification_not_found",
                    "message": "No pending signup found for this email. Please sign up first.",
                },
            )

        verification_item = response["Items"][0]
        expires_at_str = verification_item.get("expires_at")
        if expires_at_str:
            expires_at = datetime.fromisoformat(expires_at_str)
            if datetime.now(UTC) > expires_at:
                logger.warning("Verification expired for %s", facade._redact_email(body.email))
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail={
                        "error": "verification_expired",
                        "message": "Verification code has expired. Please sign up again.",
                    },
                )

        is_test_email = facade._allow_test_email_bypass() and facade._is_test_email_bypass_address(normalized_email)
        user_pool_id = os.environ.get("COGNITO_USER_POOL_ID")
        if not user_pool_id and not is_test_email:
            logger.error("Cognito configuration missing")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "error": "configuration_error",
                    "message": "Authentication service not properly configured",
                },
            )

        if not is_test_email:
            try:
                from apps.backend.providers.identity_provider import get_identity_provider

                _identity = get_identity_provider()
                _identity.confirm_user(
                    email=normalized_email,
                    confirmation_code=body.verification_code,
                )
                logger.info("User confirmed: %s", facade._redact_email(body.email))
            except cognito_idp.exceptions.CodeMismatchException:
                logger.warning("Invalid verification code for %s", facade._redact_email(body.email))
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail={
                        "error": "invalid_code",
                        "message": "Invalid verification code. Please check and try again.",
                    },
                )
            except cognito_idp.exceptions.ExpiredCodeException:
                logger.warning("Expired verification code for %s", facade._redact_email(body.email))
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail={
                        "error": "code_expired",
                        "message": "Verification code has expired. Please request a new one.",
                    },
                )
            except cognito_idp.exceptions.UserNotFoundException:
                logger.warning("User not found in Cognito: %s", facade._redact_email(body.email))
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail={
                        "error": "user_not_found",
                        "message": "User not found. Please sign up first.",
                    },
                )
            except cognito_idp.exceptions.NotAuthorizedException:
                logger.warning("User already confirmed: %s", facade._redact_email(body.email))
                logger.info(
                    "User %s already confirmed, proceeding with tenant creation", facade._redact_email(body.email)
                )

        stored_invite_token = verification_item.get("invite_token") or None
        stored_sub_tenant_invite_token = verification_item.get("sub_tenant_invite_token") or None
        has_invite = bool(stored_invite_token or stored_sub_tenant_invite_token)

        if (
            not facade._domain_allowed_for_provisioning(normalized_email, has_valid_invite=has_invite)
            and not is_test_email
        ):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=facade._domain_not_allowed_detail(),
            )

        user_name = verification_item.get("name", "")
        product = (verification_item.get("product") or "").strip() or "workweaver"
        preferred_region = (
            body.preferred_region
            or verification_item.get("preferred_region_code")
            or verification_item.get("preferred_region_label")
        )

        owner_user_id = None
        if not is_test_email:
            try:
                user_status = cognito_idp.admin_get_user(UserPoolId=user_pool_id, Username=normalized_email)
                attrs = user_status.get("UserAttributes", [])
                for attribute in attrs:
                    if attribute.get("Name") == "sub":
                        owner_user_id = attribute.get("Value")
                        break
            except cognito_idp.exceptions.UserNotFoundException:
                logger.error(
                    "User not found in Cognito during verification: %s", facade._redact_email(normalized_email)
                )
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail={
                        "error": "verification_failed",
                        "message": "User verification failed. Please contact support.",
                    },
                )
            except Exception as exc:
                logger.error("Unexpected error during identity verification: %s", exc)
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail={
                        "error": "identity_service_unavailable",
                        "message": "Identity verification temporarily unavailable. Please try again.",
                    },
                ) from exc
        if not owner_user_id:
            owner_user_id = f"email_{ulid.new()}"

        signup_response = await facade._complete_signup_after_identity_verification(
            owner_user_id=owner_user_id,
            email=normalized_email,
            auth_provider=AuthProvider.EMAIL_PASSWORD,
            owner_name=user_name,
            preferred_region=preferred_region,
            product=product,
            invite_token=stored_invite_token,
            sub_tenant_invite_token=stored_sub_tenant_invite_token,
            consent=build_signup_consent(
                bool(verification_item.get("accepted_terms")),
                bool(verification_item.get("accepted_privacy")),
                consent_at=str(verification_item.get("consent_at") or ""),
                terms_version=str(verification_item.get("terms_version") or get_signup_terms_version()),
            ),
        )

        try:
            verifications_table.delete_item(
                Key={
                    "pk": f"VERIFICATION#{normalized_email}",
                    "sk": verification_item["sk"],
                }
            )
        except Exception as cleanup_error:
            logger.warning("Failed to cleanup verification record: %s", cleanup_error)

        logger.info(
            "Created tenant %s via email signup for %s, status=%s, mode=%s",
            signup_response.tenant_id,
            facade._redact_email(body.email),
            signup_response.status,
            signup_response.provisioning_mode,
        )
        return signup_response

    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Error in email verification for %s: %s", facade._redact_email(body.email), exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "verification_failed",
                "message": "Failed to verify email. Please try again.",
            },
        ) from exc
