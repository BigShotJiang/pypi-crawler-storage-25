"""Voice calls, recordings, memory, and connection-pool endpoints.

Extracted from main.py to keep the monolith manageable.
Router uses NO prefix -- all paths are kept verbatim so existing clients
see zero change.
"""

from __future__ import annotations

import base64
import hashlib
import logging
import os
import time
from datetime import datetime, UTC
from typing import Any

from botocore.exceptions import BotoCoreError, ClientError
from apps.backend.config.region import AWS_REGION
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse, RedirectResponse

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    resolve_verified_tenant_id,
)
from apps.backend.services.memory.adapters.import_service import MarkdownDocument, MemoryImportService
from apps.backend.services.memory.runtime import WorkMemoryRuntime, get_runtime

logger = logging.getLogger(__name__)

router = APIRouter(tags=["voice-calls"])

_RECORDING_INTENT_ALIASES = {
    "evidence": "evidence_only",
    "evidence_only": "evidence_only",
    "searchable": "searchable_recall",
    "searchable_recall": "searchable_recall",
    "learning": "searchable_recall",
    "memory": "searchable_recall",
}

_VOICE_RECORDING_UNAVAILABLE_ERRORS = (BotoCoreError, ClientError, FileNotFoundError, OSError)


# ---------------------------------------------------------------------------
# Lazy service accessors (avoid import-time boto3 / heavy init in tests)
# ---------------------------------------------------------------------------

_recording_service = None


def _get_workmemory_client() -> WorkMemoryRuntime:
    return get_runtime()


def _get_plugin_memory_service():  # noqa: ANN202
    """Lazy-load the canonical MemoryService for plugin-contract endpoints.

    All memory persistence (recall, store, capture) delegates to this single
    authority.  Tests can monkeypatch this accessor to inject stubs.
    """
    from apps.backend.services.memory.service import get_memory_service

    return get_memory_service()


def _get_recording_service():  # noqa: ANN202
    """Return the singleton RecordingService, creating on first call."""
    global _recording_service
    if _recording_service is None:
        from apps.backend.voice_services.recording_service import RecordingService

        bucket_name = os.environ.get("EVIDENCE_LAKE_BUCKET")
        logger.info("Initializing RecordingService (voice_calls router) bucket=%s", bucket_name)
        _recording_service = RecordingService(bucket_name=bucket_name)
    return _recording_service


def _get_zara_connection_pool():  # noqa: ANN202
    """Lazy-load the Zara connection pool singleton."""
    from apps.backend.voice_services.zara_connection_pool import get_zara_connection_pool

    return get_zara_connection_pool()


# ---------------------------------------------------------------------------
# Tenant resolution helpers
# ---------------------------------------------------------------------------


def _resolve_voice_tenant_id(request: Request) -> str:
    """Resolve tenant from verified auth context only.

    Security (#1934): The insecure voice tenant fallback env var is deleted.
    Voice tenant resolution fails closed — no env-based fallback.
    """
    return resolve_verified_tenant_id(request)


def _resolve_authenticated_tenant_id(request: Request) -> str:
    """Resolve tenant from authenticated request context only."""
    return resolve_verified_tenant_id(request)


# ---------------------------------------------------------------------------
# Scalar coercion helpers
# ---------------------------------------------------------------------------


def _as_string(value: object, fallback: str = "") -> str:
    if isinstance(value, str):
        value = value.strip()
        return value if value else fallback
    if value is None:
        return fallback
    if isinstance(value, bool):
        return "true" if value else "false"
    if isinstance(value, (int, float)):
        return str(value)
    return fallback


def _as_int(
    value: object,
    fallback: int,
    minimum: int | None = None,
    maximum: int | None = None,
) -> int:
    try:
        candidate = int(value)  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return fallback
    if minimum is not None and candidate < minimum:
        return fallback
    if maximum is not None and candidate > maximum:
        return fallback
    return candidate


# ---------------------------------------------------------------------------
# Memory recall helpers (validation only; persistence moved to MemoryService)
# ---------------------------------------------------------------------------


def _validate_startup_mode(raw_mode: str) -> str:
    startup_mode = raw_mode.strip().lower() or "topic"
    if startup_mode not in {"topic", "temporal", "graph"}:
        raise HTTPException(status_code=400, detail="startup_mode must be one of: topic, temporal, graph")
    return startup_mode


def _resolve_recording_intent(raw_intent: object, searchable_recall: object | None = None) -> str:
    if searchable_recall is not None:
        if not isinstance(searchable_recall, bool):
            raise HTTPException(
                status_code=400,
                detail="searchable_recall must be a boolean when provided",
            )
        requested_intent = "searchable_recall" if searchable_recall else "evidence_only"
        intent = _as_string(raw_intent, "").lower().replace("-", "_")
        if intent:
            normalized = _RECORDING_INTENT_ALIASES.get(intent)
            if normalized is None:
                raise HTTPException(
                    status_code=400,
                    detail="recording_intent must be one of: evidence_only, searchable_recall",
                )
            if normalized != requested_intent:
                raise HTTPException(
                    status_code=400,
                    detail=(
                        "searchable_recall and recording_intent disagree; provide only one explicit source "
                        "(or matching values)."
                    ),
                )
        return requested_intent

    intent = _as_string(raw_intent, "evidence_only").lower().replace("-", "_")
    normalized = _RECORDING_INTENT_ALIASES.get(intent)
    if normalized:
        return normalized
    raise HTTPException(
        status_code=400,
        detail="recording_intent must be one of: evidence_only, searchable_recall",
    )


def _resolve_recording_intent_source(raw_intent: object, searchable_recall: object | None = None) -> str:
    if searchable_recall is not None:
        return "searchable_recall"
    if raw_intent is not None:
        return "recording_intent"
    return "default"


def _build_recording_memory_text(*, summary: str, transcript: str) -> str:
    parts: list[str] = []
    normalized_summary = _as_string(summary)
    normalized_transcript = _as_string(transcript)
    if normalized_summary:
        parts.append(f"Summary: {normalized_summary}")
    if normalized_transcript:
        parts.append(f"Transcript:\n{normalized_transcript}")
    return "\n\n".join(parts).strip()


# ---------------------------------------------------------------------------
# Playback / payload helpers
# ---------------------------------------------------------------------------


def _playback_url_from_ref(call_id: str, playback_ref: Any | None) -> str:
    if not playback_ref:
        return ""
    kind = str(getattr(playback_ref, "kind", "") or "")
    value = str(getattr(playback_ref, "value", "") or "")
    if not value:
        return ""
    if kind == "url":
        return value
    return f"/api/v1/voice/calls/{call_id}/playback"


def _voice_call_payload(call: Any, playback_url: str) -> dict[str, Any]:
    metadata = call.metadata.to_dict()
    transcript = str(call.transcript or metadata.get("transcript", "") or "")
    summary = str(call.summary or metadata.get("summary", "") or "")
    transcript_hash = hashlib.sha256(transcript.encode("utf-8")).hexdigest() if transcript else ""
    return {
        "call_id": call.call_id,
        "timestamp": call.timestamp.isoformat(),
        "duration_ms": int(metadata.get("duration_ms", 0)),
        "quality_score": int(metadata.get("quality_score", 0)),
        "latency_metrics": metadata.get("latency_metrics", {}),
        "test_scenario": metadata.get("test_scenario", ""),
        "format": metadata.get("format", ""),
        "participants": metadata.get("participants", []),
        "summary": summary,
        "transcript": transcript,
        "transcript_hash": transcript_hash,
        "recording_ref": getattr(call.storage_ref, "ref", ""),
        "playback_url": playback_url,
    }


def _recording_memory_payload(result: Any, *, source_type: str) -> dict[str, Any]:
    item_ids = result.get("item_ids") if isinstance(result, dict) else None
    if not isinstance(item_ids, list):
        single_item_id = result.get("item_id") if isinstance(result, dict) else None
        item_ids = [str(single_item_id)] if single_item_id else []
    success = bool(result.get("success", True)) if isinstance(result, dict) else True
    if not item_ids and isinstance(result, dict):
        success = bool(result.get("success", False))
    return {
        "processing_status": str(result.get("status") or result.get("processing_status") or "complete"),
        "success": success,
        "item_ids": [str(item) for item in item_ids],
        "facts_extracted": len(item_ids),
        "chunks_processed": len(item_ids),
        "warnings": [str(item) for item in (result.get("warnings") or [])],
        "omissions": [str(item) for item in (result.get("omissions") or [])],
        "errors": [str(item) for item in (result.get("errors") or [])],
        "resource_ref": result.get("resource_ref"),
        "source_type": source_type,
    }


def _voice_recording_store_unavailable(action: str, exc: Exception) -> HTTPException:
    logger.warning("Voice recording storage unavailable while %s: %s", action, exc, exc_info=True)
    return HTTPException(
        status_code=503,
        detail={
            "error": "voice_recording_store_unavailable",
            "detail": "Voice recording storage is temporarily unavailable.",
            "action": action,
        },
    )


# ============================================================================
# Voice Call Endpoints
# ============================================================================


@router.get("/api/v1/voice/calls")
async def list_voice_calls(request: Request, limit: int = 50) -> dict[str, Any]:
    """Part 6 contract: list recorded calls for the current tenant."""
    try:
        service = _get_recording_service()
        tenant_id = _resolve_voice_tenant_id(request)
        calls = await service.list_calls(tenant_id=tenant_id, limit=limit)
        result = []
        for call in calls:
            playback_ref = await service.get_playback_ref_for_call(call=call)
            result.append(
                _voice_call_payload(
                    call=call,
                    playback_url=_playback_url_from_ref(call.call_id, playback_ref),
                )
            )

        return {
            "calls": result,
            "count": len(result),
            "runtime_mode": (request.headers.get("X-WW-Voice-Runtime-Mode") or "managed_relay"),
            "recording_store": (
                request.headers.get("X-WW-Recording-Store") or os.getenv("VOICE_RECORDING_STORE", "s3")
            ),
        }
    except HTTPException:
        raise
    except _VOICE_RECORDING_UNAVAILABLE_ERRORS as e:
        raise _voice_recording_store_unavailable("listing voice calls", e) from e
    except Exception as e:
        logger.error("Failed to list voice calls: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to list voice calls")


@router.get("/api/v1/voice/calls/{call_id}")
async def get_voice_call(call_id: str, request: Request) -> dict[str, Any]:
    """Part 6 contract: get call metadata, transcript, summary, and playback ref."""
    try:
        service = _get_recording_service()
        tenant_id = _resolve_voice_tenant_id(request)
        call = await service.get_call(tenant_id=tenant_id, call_id=call_id)
        if not call:
            raise HTTPException(status_code=404, detail=f"Call not found: {call_id}")
        playback_ref = await service.get_playback_ref_for_call(call=call)
        return _voice_call_payload(
            call=call,
            playback_url=_playback_url_from_ref(call.call_id, playback_ref),
        )
    except HTTPException:
        raise
    except _VOICE_RECORDING_UNAVAILABLE_ERRORS as e:
        raise _voice_recording_store_unavailable(f"getting voice call {call_id}", e) from e
    except Exception as e:
        logger.error("Failed to get voice call: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to get voice call")


@router.get("/api/v1/voice/calls/{call_id}/playback")
async def get_voice_call_playback(call_id: str, request: Request):  # noqa: ANN201
    """Part 6 contract: stream local playback or redirect to signed URL."""
    try:
        service = _get_recording_service()
        tenant_id = _resolve_voice_tenant_id(request)
        playback_ref = await service.get_playback_ref(
            tenant_id=tenant_id,
            call_id=call_id,
        )
        if not playback_ref:
            raise HTTPException(status_code=404, detail=f"Playback not found: {call_id}")

        kind = str(getattr(playback_ref, "kind", "") or "")
        value = str(getattr(playback_ref, "value", "") or "")
        if kind == "url":
            return RedirectResponse(url=value, status_code=307)

        if not value or not os.path.exists(value):
            raise HTTPException(status_code=404, detail=f"Playback file not found: {call_id}")

        suffix = os.path.splitext(value)[1].lower()
        media_type = (
            "audio/wav"
            if suffix == ".wav"
            else "audio/webm"
            if suffix == ".webm"
            else "audio/mp4"
            if suffix in {".m4a", ".mp4"}
            else "audio/mpeg"
            if suffix in {".mp3", ".mpeg"}
            else "audio/ogg"
            if suffix == ".ogg"
            else "audio/flac"
            if suffix == ".flac"
            else "application/octet-stream"
        )
        return FileResponse(
            path=value,
            media_type=media_type,
            filename=os.path.basename(value),
        )
    except HTTPException:
        raise
    except _VOICE_RECORDING_UNAVAILABLE_ERRORS as e:
        raise _voice_recording_store_unavailable(f"loading playback for {call_id}", e) from e
    except Exception as e:
        logger.error("Failed to get playback: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to get playback")


# ============================================================================
# Legacy Recording Endpoints
# ============================================================================


@router.get("/api/recordings/list")
async def list_recordings(
    request: Request,
    limit: int = 50,
    min_quality: int | None = None,
) -> dict[str, Any]:
    """Legacy compatibility list endpoint used by existing landing/widget clients."""
    try:
        service = _get_recording_service()
        tenant_id = _resolve_voice_tenant_id(request)
        calls = await service.list_calls(tenant_id=tenant_id, limit=limit)
        result = []
        for call in calls:
            metadata = call.metadata.to_dict()
            quality_score = int(metadata.get("quality_score", 0))
            if min_quality is not None and quality_score < min_quality:
                continue
            if int(metadata.get("duration_ms", 0)) <= 0:
                continue
            playback_ref = await service.get_playback_ref_for_call(call=call)
            result.append(
                {
                    "callId": call.call_id,
                    "timestamp": call.timestamp.isoformat(),
                    "duration": int(metadata.get("duration_ms", 0)),
                    "qualityScore": quality_score,
                    "latencyMetrics": metadata.get("latency_metrics", {}),
                    "testScenario": metadata.get("test_scenario", ""),
                    "format": metadata.get("format", ""),
                    "url": _playback_url_from_ref(call.call_id, playback_ref),
                    "s3_key": getattr(call.storage_ref, "ref", ""),
                    "size_bytes": int(getattr(call.storage_ref, "size_bytes", 0) or 0),
                    "participants": metadata.get("participants", []),
                }
            )
        logger.info("Listed %d recordings", len(result))
        return {"recordings": result, "count": len(result)}
    except HTTPException:
        raise
    except _VOICE_RECORDING_UNAVAILABLE_ERRORS as e:
        raise _voice_recording_store_unavailable("listing recordings", e) from e
    except Exception as e:
        logger.error("Failed to list recordings: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to list recordings")


@router.get("/api/recordings/{call_id}")
async def get_recording(call_id: str, request: Request, format: str = "pcm") -> dict[str, Any]:
    """Legacy compatibility detail endpoint."""
    try:
        service = _get_recording_service()
        tenant_id = _resolve_voice_tenant_id(request)
        call = await service.get_call(tenant_id=tenant_id, call_id=call_id)
        if not call:
            raise HTTPException(status_code=404, detail=f"Recording not found: {call_id}")
        if str(call.metadata.format or "").strip() != format:
            raise HTTPException(status_code=404, detail=f"Recording not found for format: {format}")
        playback_ref = await service.get_playback_ref_for_call(call=call)
        return {
            "call_id": call_id,
            "metadata": call.metadata.to_dict(),
            "playback_url": _playback_url_from_ref(call.call_id, playback_ref),
        }
    except HTTPException:
        raise
    except _VOICE_RECORDING_UNAVAILABLE_ERRORS as e:
        raise _voice_recording_store_unavailable(f"loading recording {call_id}", e) from e
    except Exception as e:
        logger.error("Failed to get recording: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to get recording")


@router.delete("/api/recordings/delete")
async def delete_recording(request: Request, callId: str) -> dict[str, bool]:
    """Delete a recording by callId (testing-only)."""
    try:
        service = _get_recording_service()
        tenant_id = _resolve_voice_tenant_id(request)
        deleted = await service.delete_call(tenant_id=tenant_id, call_id=callId)
        return {"success": deleted}
    except HTTPException:
        raise
    except _VOICE_RECORDING_UNAVAILABLE_ERRORS as e:
        raise _voice_recording_store_unavailable(f"deleting recording {callId}", e) from e
    except Exception as e:
        logger.error("Failed to delete recording: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to delete recording")


# ============================================================================
# Memory Endpoints
# ============================================================================


@router.post("/api/v1/memory/recall")
async def recall_memory_facts(request: Request) -> dict[str, Any]:
    """Recall memory facts with startup modes and token-budget enforcement.

    Delegates to MemoryService.plugin_recall -- the single memory authority.
    """
    payload = await request.json()
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Invalid request body")

    query = _as_string(payload.get("query"))
    tenant_id = _resolve_authenticated_tenant_id(request)
    raw_limit = _as_int(payload.get("limit"), 5)
    limit = max(1, min(12, raw_limit))
    fact_type = _as_string(payload.get("fact_type"), "conversation_memory")
    startup_mode = _validate_startup_mode(_as_string(payload.get("startup_mode"), "topic"))
    raw_budget = _as_int(payload.get("token_budget"), 4000)
    token_budget = max(256, min(16000, raw_budget))

    svc = _get_plugin_memory_service()
    return await svc.plugin_recall(
        tenant_id=tenant_id,
        query=query,
        limit=limit,
        fact_type=fact_type,
        startup_mode=startup_mode,
        token_budget=token_budget,
    )


@router.post("/api/v1/memory/capture")
async def capture_memory_facts(request: Request) -> dict[str, Any]:
    """Store extracted conversation memories via WorkMemory ingestion.

    Delegates to MemoryService.plugin_capture -- the single memory authority.
    """
    payload = await request.json()
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Invalid request body")

    tenant_id = _resolve_authenticated_tenant_id(request)
    raw_facts = payload.get("facts")
    if not isinstance(raw_facts, list):
        raise HTTPException(status_code=400, detail="Expected facts array")

    svc = _get_plugin_memory_service()
    return await svc.plugin_capture(tenant_id=tenant_id, facts=raw_facts)


@router.post("/api/v1/memory/store")
async def store_memory_fact(request: Request) -> dict[str, Any]:
    """Store a single memory fact via the Workweaver Runtime plugin contract.

    Delegates to MemoryService.plugin_store -- the single memory authority.

    Plugin sends MemoryStoreRequest:
    { fact_type, key, value, scope?, confidence?, source?, metadata? }

    Returns MemoryStoreResponse:
    { stored: boolean, fact_id?: string }
    """
    payload = await request.json()
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Invalid request body")

    key = _as_string(payload.get("key"))
    value = _as_string(payload.get("value"))
    if not key:
        raise HTTPException(status_code=400, detail="'key' field is required")
    if not value:
        raise HTTPException(status_code=400, detail="'value' field is required")

    fact_type = _as_string(payload.get("fact_type"), "fact")
    scope = _as_string(payload.get("scope"), "tenant")
    confidence = payload.get("confidence")
    source = _as_string(payload.get("source"), "plugin")
    metadata = payload.get("metadata") if isinstance(payload.get("metadata"), dict) else {}

    tenant_id = _resolve_authenticated_tenant_id(request)

    svc = _get_plugin_memory_service()
    result = await svc.plugin_store(
        tenant_id=tenant_id,
        key=key,
        value=value,
        fact_type=fact_type,
        scope=scope,
        confidence=confidence,
        source=source,
        metadata=metadata,
    )

    if not result["stored"] and not result.get("workmemory_written") and not result.get("legacy_written"):
        raise HTTPException(status_code=503, detail="Memory service unavailable")

    return result


@router.post("/api/v1/workmemory/import/markdown")
@router.post("/api/v1/memory/import/markdown", include_in_schema=False)
async def import_memory_markdown(request: Request) -> dict[str, Any]:
    """Import markdown memory entries (memories/anti-patterns/preferences)."""
    payload = await request.json()
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Invalid request body")

    tenant_id = _resolve_authenticated_tenant_id(request)
    documents: list[MarkdownDocument] = []

    markdown = payload.get("markdown")
    if isinstance(markdown, str) and markdown.strip():
        documents.append(MarkdownDocument(content=markdown, source=_as_string(payload.get("source"), "inline")))

    raw_documents = payload.get("documents")
    if isinstance(raw_documents, list):
        for item in raw_documents:
            if not isinstance(item, dict):
                continue
            content = _as_string(item.get("content"))
            if not content:
                continue
            source = _as_string(item.get("source"), _as_string(item.get("path"), "inline"))
            documents.append(MarkdownDocument(content=content, source=source))

    if not documents:
        raise HTTPException(status_code=400, detail="Provide markdown text or documents[]")

    importer = MemoryImportService(workmemory_client=_get_workmemory_client())
    summary = await importer.import_markdown_documents(tenant_id=tenant_id, documents=documents)
    return {
        **summary.to_dict(),
        "tenant_id": tenant_id,
        "migration_mode": "workmemory",
    }


@router.post("/api/v1/workmemory/import/obsidian")
@router.post("/api/v1/memory/import/obsidian", include_in_schema=False)
async def import_memory_obsidian(request: Request) -> dict[str, Any]:
    """Import Obsidian vault markdown notes through WorkMemory ingestion."""
    payload = await request.json()
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Invalid request body")

    tenant_id = _resolve_authenticated_tenant_id(request)
    vault_path = _as_string(payload.get("vault_path"))
    if not vault_path:
        raise HTTPException(status_code=400, detail="'vault_path' is required")

    importer = MemoryImportService(workmemory_client=_get_workmemory_client())
    summary = await importer.import_obsidian_vault(tenant_id=tenant_id, vault_path=vault_path)
    return {
        **summary.to_dict(),
        "tenant_id": tenant_id,
        "vault_path": vault_path,
        "migration_mode": "workmemory",
    }


@router.post("/api/v1/workmemory/import/markdown-dir")
@router.post("/api/v1/memory/import/markdown-dir", include_in_schema=False)
async def import_memory_markdown_directory(request: Request) -> dict[str, Any]:
    """Import all markdown files from a directory through WorkMemory ingestion."""
    payload = await request.json()
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Invalid request body")

    tenant_id = _resolve_authenticated_tenant_id(request)
    directory_path = _as_string(payload.get("directory_path"))
    if not directory_path:
        raise HTTPException(status_code=400, detail="'directory_path' is required")
    recursive = bool(payload.get("recursive", True))

    importer = MemoryImportService(workmemory_client=_get_workmemory_client())
    summary = await importer.import_markdown_directory(
        tenant_id=tenant_id,
        directory_path=directory_path,
        recursive=recursive,
    )
    return {
        **summary.to_dict(),
        "tenant_id": tenant_id,
        "directory_path": directory_path,
        "recursive": recursive,
        "migration_mode": "workmemory",
    }


@router.post("/api/v1/workmemory/import/sessions")
@router.post("/api/v1/memory/import/sessions", include_in_schema=False)
async def import_memory_sessions(request: Request) -> dict[str, Any]:
    """Import sessions into WorkMemory ingestion pipeline."""
    payload = await request.json()
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="Invalid request body")

    tenant_id = _resolve_authenticated_tenant_id(request)
    sessions = payload.get("sessions")
    if not isinstance(sessions, list):
        raise HTTPException(status_code=400, detail="'sessions' must be an array")

    importer = MemoryImportService(workmemory_client=_get_workmemory_client())
    summary = await importer.import_sessions(tenant_id=tenant_id, sessions=sessions)
    return {
        **summary.to_dict(),
        "tenant_id": tenant_id,
        "migration_mode": "workmemory",
    }


# ============================================================================
# xAI Token Endpoint
# ============================================================================


@router.post("/get-token")
async def get_xai_token(request: Request) -> dict[str, str]:
    """Get xAI ephemeral token for Zara Voice AI.

    Requires X-Tenant-Id header.

    This endpoint fetches an ephemeral token from xAI's client_secrets API,
    which provides scoped access for client-side authentication.

    Reference: https://docs.x.ai/docs/guides/voice/agent
    """
    tenant_id = _resolve_authenticated_tenant_id(request)

    try:
        # Get xAI API key from Secrets Manager
        secret_arn = os.environ.get("GROK_SECRET_ARN")
        if not secret_arn:
            raise HTTPException(status_code=500, detail="GROK_SECRET_ARN not configured")

        import boto3

        session = boto3.Session()
        client = session.client(
            "secretsmanager",
            region_name=AWS_REGION,
        )
        response = client.get_secret_value(SecretId=secret_arn)
        api_key = response.get("SecretString")

        if not api_key:
            raise HTTPException(status_code=500, detail="xAI API key not found in Secrets Manager")

        # Set XAI_API_KEY environment variable (for other services that might need it)
        os.environ["XAI_API_KEY"] = api_key

        # Import get_ephemeral_token function
        from voice_services import get_ephemeral_token  # type: ignore[import-untyped]

        # Fetch ephemeral token from xAI
        token_response = await get_ephemeral_token(api_key=api_key, expires_after_seconds=300)

        logger.info(
            "Generated xAI ephemeral token for tenant=%s, expires_at: %s",
            tenant_id,
            token_response["expires_at"],
        )

        return {
            "client_secret": token_response["value"],
            "expires_at": datetime.fromtimestamp(token_response["expires_at"], tz=UTC).isoformat(),
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to generate xAI token: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to generate token")


# ============================================================================
# Recording Upload Endpoints
# ============================================================================


async def _upload_recording_impl(request: Request) -> dict[str, Any]:
    """Upload audio recording to S3 Evidence Lake."""
    try:
        body = await request.json()
        tenant_id = _resolve_voice_tenant_id(request)
        audio_base64 = body.get("audio_base64")
        call_id = body.get("call_id", f"grok-{int(time.time())}")
        test_type = body.get("test_type", "grok")
        duration_ms = body.get("duration_ms", 0)
        latency_metrics = body.get("latency_metrics", {})
        fmt = body.get("format") or body.get("fmt")
        transcript = _as_string(body.get("transcript"))
        summary = _as_string(body.get("summary"))
        recording_intent_raw = body.get("recording_intent") or body.get("artifact_intent")
        searchable_recall = body.get("searchable_recall")
        recording_intent = _resolve_recording_intent(
            recording_intent_raw,
            searchable_recall,
        )

        if not audio_base64:
            raise HTTPException(status_code=400, detail="audio_base64 is required")

        audio_bytes = base64.b64decode(audio_base64)

        recording_service = _get_recording_service()

        from apps.backend.voice_services.recording_service import (
            RecordingMetadata,
            LatencyMetadata,
        )

        recording_format = str(fmt or "webm")
        metadata = RecordingMetadata(
            call_id=call_id,
            timestamp=datetime.now(UTC).isoformat(),
            duration_ms=int(duration_ms),
            latency_metrics=LatencyMetadata(
                twilio_edge_ms=latency_metrics.get("twilio_edge_ms", 0),
                websocket_ms=latency_metrics.get("websocket_ms", 0),
                xai_processing_ms=latency_metrics.get("xai_processing_ms", 0),
                response_path_ms=latency_metrics.get("response_path_ms", 0),
                first_voice_ms=latency_metrics.get("first_voice_ms", 0),
                avg_latency_ms=latency_metrics.get("avg_latency_ms", 0),
                total_ms=latency_metrics.get("total_ms", int(duration_ms)),
            ),
            quality_score=0,
            test_scenario=f"voice-test-{test_type}",
            format=recording_format,
            participants=[],
            transcript=transcript,
            summary=summary,
            recording_intent=recording_intent,
        )

        s3_key = await recording_service.store_recording(
            call_id=call_id,
            audio_data=audio_bytes,
            format=metadata.format,
            metadata=metadata,
            tenant_id=tenant_id,
        )

        logger.info("Recording uploaded: %s -> %s", call_id, s3_key)
        response_payload: dict[str, Any] = {
            "s3_key": s3_key,
            "call_id": call_id,
            "timestamp": metadata.timestamp,
            "recording_intent": recording_intent,
            "recording_intent_source": _resolve_recording_intent_source(recording_intent_raw, searchable_recall),
            "artifact_classification": recording_intent,
            "workmemory_written": False,
        }
        if recording_intent == "evidence_only":
            return response_payload

        memory_text = _build_recording_memory_text(summary=summary, transcript=transcript)
        if not memory_text:
            return JSONResponse(
                status_code=422,
                content={
                    **response_payload,
                    "workmemory": {
                        "processing_status": "rejected",
                        "success": False,
                        "item_ids": [],
                        "facts_extracted": 0,
                        "chunks_processed": 0,
                        "warnings": [],
                        "omissions": [],
                        "errors": [
                            "Searchable recording uploads require a transcript or summary so WorkMemory can store searchable text."
                        ],
                        "resource_ref": None,
                        "source_type": "voice_recording_searchable",
                    },
                },
            )

        try:
            ingest_result = await _get_workmemory_client().ingest_text(
                tenant_id=tenant_id,
                content=memory_text,
                source_type="voice_recording_searchable",
                category="voice_recordings",
                metadata={
                    "call_id": call_id,
                    "recording_ref": s3_key,
                    "recording_format": metadata.format,
                    "duration_ms": int(duration_ms),
                    "recording_intent": recording_intent,
                },
                content_type="text/markdown",
            )
        except Exception:
            logger.exception("Recording searchable dual-write failed call_id=%s tenant=%s", call_id, tenant_id)
            return JSONResponse(
                status_code=502,
                content={
                    **response_payload,
                    "workmemory": {
                        "processing_status": "rejected",
                        "success": False,
                        "errors": ["Failed to write searchable recall copy to WorkMemory."],
                    },
                },
            )

        memory_payload = _recording_memory_payload(ingest_result, source_type="voice_recording_searchable")
        response_payload.update(
            {
                "workmemory_written": bool(memory_payload["success"]),
                "workmemory": memory_payload,
            }
        )
        if not bool(memory_payload["success"]):
            return JSONResponse(
                status_code=int(ingest_result.get("status_code") or 422),
                content=response_payload,
            )
        return response_payload

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to upload recording: %s", e, exc_info=True)
        raise HTTPException(status_code=500, detail="Upload failed")


@router.post("/recordings/upload")
async def upload_recording(request: Request) -> dict[str, Any]:
    return await _upload_recording_impl(request)


@router.post("/api/recordings/upload")
async def upload_recording_api(request: Request) -> dict[str, Any]:
    return await _upload_recording_impl(request)


# ============================================================================
# Connection Pool Endpoints
# ============================================================================


@router.get("/api/connections/health")
async def connections_health(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Health check endpoint for xAI connection pool.

    Security (#1930): Requires verified tenant auth. Response scoped to
    the caller's tenant only.

    Returns:
        Connection pool health metrics: counts by status, retry stats, etc.
    """
    pool = _get_zara_connection_pool()
    health = await pool.get_pool_health()

    return {
        "status": "healthy" if health["healthy_connections"] > 0 else "degraded",
        "timestamp": datetime.now(UTC).isoformat(),
        "pool": health,
    }


@router.get("/api/connections/{session_id}")
async def connection_status(
    session_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> Any:
    """Get status and info for a specific connection.

    Security (#1930): Requires verified tenant auth. Returns 404 (not 403)
    when the session belongs to another tenant, to prevent enumeration.

    Args:
        session_id: Connection session identifier

    Returns:
        Connection status and info, or 404 if not found
    """
    pool = _get_zara_connection_pool()
    info = await pool.get_connection_info(session_id)

    if not info:
        raise HTTPException(status_code=404, detail=f"Connection {session_id} not found")

    # Tenant scoping: return 404 (not 403) to prevent session enumeration.
    session_tenant = str(info.get("tenant_id") or "").strip()
    if session_tenant and tenant_id != session_tenant:
        raise HTTPException(status_code=404, detail=f"Connection {session_id} not found")

    return info
