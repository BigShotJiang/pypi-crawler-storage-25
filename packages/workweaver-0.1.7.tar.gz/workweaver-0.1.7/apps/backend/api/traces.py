"""Inference Traces API — query structured execution traces (PR-T3.1).

Endpoints:
  GET /api/v1/traces?category={cat}&limit=50  — list traces for tenant
  GET /api/v1/traces/{trace_id}               — get a single trace

All endpoints are tenant-scoped via the standard auth dependency.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/traces", tags=["traces"])


def _get_store():
    """Lazy import to avoid import-time boto3 failures in tests."""
    from apps.backend.dependencies import get_inference_trace_store

    return get_inference_trace_store()


@router.get("")
async def list_traces(
    tenant_id: str = Depends(get_verified_tenant_id),
    category: str | None = Query(default=None, description="Filter by task category"),
    limit: int = Query(default=50, ge=1, le=200, description="Max results"),
) -> dict[str, Any]:
    """List inference traces for the authenticated tenant.

    Returns traces sorted newest-first, optionally filtered by task category.
    """
    try:
        store = _get_store()
        traces = await store.list_traces(tenant_id, category=category, limit=limit)
        return {"traces": traces, "count": len(traces)}
    except Exception:
        logger.exception("Failed to list traces for tenant %s", tenant_id)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve traces",
        )


@router.get("/{trace_id}")
async def get_trace(
    trace_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Get a single inference trace by ID."""
    try:
        store = _get_store()
        trace = await store.get_trace(tenant_id, trace_id)
    except Exception:
        logger.exception("Failed to get trace %s for tenant %s", trace_id, tenant_id)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve trace",
        )

    if trace is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Trace {trace_id} not found",
        )
    return trace
