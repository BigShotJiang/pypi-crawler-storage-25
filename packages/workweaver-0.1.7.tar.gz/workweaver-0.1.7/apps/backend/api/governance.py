"""Governance API — evolution rate limits, simulation safety, and human override controls.

Endpoints:
  GET  /api/v1/governance/policy-authority      — Public policy authority map
  GET  /api/v1/governance/budget-gate            — Budget gate fail-closed status (#3603)
  GET  /api/v1/governance/evolution/state        — Current evolution rate limit state
  PUT  /api/v1/governance/evolution/limits        — Update evolution rate limits
  GET  /api/v1/governance/simulation/limits       — Current simulation limits
  POST /api/v1/governance/override/pause          — Stop Workweaver into read-only mode
  POST /api/v1/governance/override/resume         — Resume automation
  POST /api/v1/governance/override/pause-learning — Pause learning
  GET  /api/v1/governance/override/state          — Get override state
  POST /api/v1/governance/heartbeat               — Record human heartbeat

PR-T7.3 (Simulation Sandbox Safety) + PR-T7.4 (Evolution Rate Limiting) + PR-T7.5 (Human Override).
"""

from __future__ import annotations

from datetime import UTC, datetime

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_id,
    require_admin_user_role,
)
from apps.backend.models.user import UserRole
from apps.backend.services.admin.admin_permission import (
    AdminPermission,
    AdminPermissionCheck,
    AdminRole,
    check_permission,
)
from apps.backend.services.evolution_rate_limiter import (
    EVOLUTION_CATEGORIES,
    get_evolution_rate_limiter,
)
from apps.backend.services.simulation.safety import (
    get_simulation_safety_guard,
)

router = APIRouter(prefix="/api/v1/governance", tags=["governance"])


def _require_governance_write(
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    admin_role: UserRole = Depends(require_admin_user_role),
) -> AdminPermissionCheck:
    del admin_role
    result = check_permission(
        role=AdminRole.TENANT_ADMIN,
        permission=AdminPermission.GOVERNANCE_WRITE,
        actor_id=user_id,
        target_tenant_ids=(tenant_id,),
        actor_tenant_id=tenant_id,
    )
    if not result.allowed:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=result.reason or "Permission denied",
        )
    return result


_GOVERNANCE_WRITE_DEPENDENCIES = [
    Depends(require_admin_user_role),
    Depends(_require_governance_write),
]


# ── Response / Request Models ───────────────────────────────────────────


class EvolutionCategoryState(BaseModel):
    """State of one evolution rate limit category."""

    category: str
    current_count: int
    max_count: int
    allowed: bool
    resets_at: str


class EvolutionStateResponse(BaseModel):
    """Full evolution rate limit state for a tenant."""

    tenant_id: str
    categories: list[EvolutionCategoryState]
    effective_limits: dict[str, int]


class EvolutionLimitsUpdate(BaseModel):
    """Request body for updating evolution limits.

    All fields are optional; only provided fields are applied.
    Behavioral stops (learning_agility, adaptation_mode) are the primary
    mechanism for limit adjustment, but this endpoint allows admin override.
    """

    learning_agility: str | None = Field(
        None,
        description="'conservative', 'moderate', or 'aggressive'",
    )
    adaptation_mode: str | None = Field(
        None,
        description="'locked', 'recommend_reversible', or 'auto_execute'",
    )


class SimulationLimitsResponse(BaseModel):
    """Current simulation limits for a tenant."""

    tenant_id: str
    max_cost_per_run: float
    max_runs_per_day: int
    max_concurrent_runs: int


class PolicyAuthorityEntryResponse(BaseModel):
    sub_question: str
    authority: str
    service: str
    boundary: str
    evidence_required: bool


class PolicyAuthorityResponse(BaseModel):
    tenant_id: str
    authority: str
    final_verdicts: list[str]
    sub_questions: list[PolicyAuthorityEntryResponse]
    envelope_model: dict[str, object]


class PaymentPolicyPreflightRequest(BaseModel):
    action: str = Field("payment.manage", description="Payment action being preflighted.")
    actor_id: str = Field("zara", description="Actor requesting payment authority.")
    provider: str = Field("stripe", description="Payment provider name.")
    amount: float | None = Field(None, description="Requested payment amount.")
    currency: str | None = Field(None, description="Requested payment currency.")
    mandate_id: str | None = Field(None, description="Verified payment mandate identifier.")
    mandate_valid: bool | None = Field(None, description="Whether the mandate was verified by the caller.")
    mandate_error: str | None = Field(None, description="Mandate verification failure code, when known.")


class PaymentPolicyPreflightResponse(BaseModel):
    tenant_id: str
    actor_id: str
    action: str
    final_verdict: str
    sub_verdicts: list[dict[str, object]]


# ── Endpoints ───────────────────────────────────────────────────────────


@router.get("/policy-authority", response_model=PolicyAuthorityResponse)
def get_policy_authority(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PolicyAuthorityResponse:
    """Return the public authority map behind PolicyDecisionEnvelope."""
    from apps.backend.services.policy_authority import policy_authority_map_payload

    payload = policy_authority_map_payload()
    return PolicyAuthorityResponse(tenant_id=tenant_id, **payload)


@router.post("/payment-preflight", response_model=PaymentPolicyPreflightResponse)
def payment_policy_preflight(
    body: PaymentPolicyPreflightRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PaymentPolicyPreflightResponse:
    """Return the governed payment action preflight envelope without provider calls."""
    from apps.backend.services.payment_policy_store import load_tenant_payment_policy
    from apps.backend.services.policy_authority import build_payment_policy_preflight

    envelope = build_payment_policy_preflight(
        tenant_id=tenant_id,
        actor={"actor_id": body.actor_id},
        inputs={
            "action": body.action,
            "provider": body.provider,
            "amount": body.amount,
            "currency": body.currency,
            "mandate_id": body.mandate_id,
            "mandate_valid": body.mandate_valid,
            "mandate_error": body.mandate_error,
            "tenant_payment_policy": load_tenant_payment_policy(tenant_id),
        },
    )
    return PaymentPolicyPreflightResponse(**envelope.to_public_dict())


@router.get("/evolution/state", response_model=EvolutionStateResponse)
def get_evolution_state(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> EvolutionStateResponse:
    """Return current evolution rate limit state for the authenticated tenant."""
    limiter = get_evolution_rate_limiter()
    effective = limiter.get_limits(tenant_id)

    categories: list[EvolutionCategoryState] = []
    for cat in EVOLUTION_CATEGORIES:
        result = limiter.check_rate_limit(tenant_id, cat)
        categories.append(
            EvolutionCategoryState(
                category=cat,
                current_count=result.current_count,
                max_count=result.max_count,
                allowed=result.allowed,
                resets_at=result.resets_at,
            )
        )

    return EvolutionStateResponse(
        tenant_id=tenant_id,
        categories=categories,
        effective_limits=effective,
    )


@router.put(
    "/evolution/limits",
    response_model=EvolutionStateResponse,
    dependencies=_GOVERNANCE_WRITE_DEPENDENCIES,
)
def update_evolution_limits(
    body: EvolutionLimitsUpdate,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> EvolutionStateResponse:
    """Update tenant evolution limits via behavioral stops.

    This endpoint adjusts limits by modifying the behavioral stops that
    the EvolutionRateLimiter reads. Direct numeric overrides are not
    supported — use learning_agility and adaptation_mode instead.
    """
    if body.learning_agility is not None:
        valid = {"conservative", "moderate", "aggressive"}
        if body.learning_agility not in valid:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                detail=f"learning_agility must be one of {sorted(valid)}",
            )

    if body.adaptation_mode is not None:
        valid_modes = {"locked", "recommend_reversible", "auto_execute"}
        if body.adaptation_mode not in valid_modes:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
                detail=f"adaptation_mode must be one of {sorted(valid_modes)}",
            )

    updates: dict[str, str] = {}
    if body.learning_agility is not None:
        updates["learning_agility"] = body.learning_agility
    if body.adaptation_mode is not None:
        updates["adaptation_mode"] = body.adaptation_mode

    # Persist via the canonical behavioral stops store that EvolutionRateLimiter reads.
    try:
        if updates:
            stops = _load_behavioral_stops(tenant_id)
            stops.update(updates)
            _save_behavioral_stops(tenant_id, stops)
    except ImportError:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail="Behavioral stops store not available",
        )

    # Return updated state
    return get_evolution_state(tenant_id=tenant_id)


@router.get("/simulation/limits", response_model=SimulationLimitsResponse)
def get_simulation_limits_endpoint(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SimulationLimitsResponse:
    """Return current simulation limits for the authenticated tenant."""
    guard = get_simulation_safety_guard()
    limits = guard.get_simulation_limits(tenant_id)

    return SimulationLimitsResponse(
        tenant_id=tenant_id,
        max_cost_per_run=limits.max_cost_per_run,
        max_runs_per_day=limits.max_runs_per_day,
        max_concurrent_runs=limits.max_concurrent_runs,
    )


# ── Human Override Models ──────────────────────────────────────────────


class OverrideStateResponse(BaseModel):
    """Current human override state for a tenant."""

    tenant_id: str
    automation_active: bool
    automation_paused: bool
    read_only_mode: bool
    status: str
    learning_paused: bool
    max_authority_level: int
    blocked_tools: list[str]
    last_heartbeat: str | None
    heartbeat_stale: bool


class HeartbeatResponse(BaseModel):
    """Heartbeat recording confirmation."""

    tenant_id: str
    recorded: bool
    last_heartbeat: str | None
    stale: bool


# ── Human Override Endpoints ───────────────────────────────────────────


def _get_override_service() -> "HumanOverrideService":
    from apps.backend.dependencies import get_human_override_service

    return get_human_override_service()


def _load_behavioral_stops(tenant_id: str) -> dict[str, object]:
    from apps.backend.services.behavioral_stops_store import get_behavioral_stops

    return get_behavioral_stops(tenant_id)


def _save_behavioral_stops(tenant_id: str, stops: dict[str, object]) -> None:
    from apps.backend.services.behavioral_stops_store import save_behavioral_stops

    save_behavioral_stops(tenant_id, stops)


def _build_override_state_response(tenant_id: str) -> OverrideStateResponse:
    svc = _get_override_service()
    state = svc.get_override_state(tenant_id)
    stops = _load_behavioral_stops(tenant_id)
    execution_paused = bool(stops.get("paused"))
    read_only_mode = bool(stops.get("pause_autonomy")) and not execution_paused
    status = "paused" if execution_paused else "read_only" if read_only_mode else "running"
    blocked_tools = [str(tool) for tool in list(stops.get("blocked_tools") or [])]

    return OverrideStateResponse(
        tenant_id=tenant_id,
        automation_active=status == "running",
        automation_paused=status != "running",
        read_only_mode=read_only_mode,
        status=status,
        learning_paused=state.learning_paused,
        max_authority_level=state.max_authority_level,
        blocked_tools=blocked_tools,
        last_heartbeat=state.last_heartbeat,
        heartbeat_stale=state.heartbeat_stale,
    )


@router.post(
    "/override/pause",
    response_model=OverrideStateResponse,
    dependencies=_GOVERNANCE_WRITE_DEPENDENCIES,
)
@router.post(
    "/override/pause-all",
    response_model=OverrideStateResponse,
    include_in_schema=False,
    dependencies=_GOVERNANCE_WRITE_DEPENDENCIES,
)
def pause_all_automation(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> OverrideStateResponse:
    """Shift Workweaver into read-only mode for the authenticated tenant."""
    stops = _load_behavioral_stops(tenant_id)
    stops["pause_autonomy"] = True
    stops["pause_autonomy_at"] = datetime.now(UTC).isoformat()
    _save_behavioral_stops(tenant_id, stops)
    return _build_override_state_response(tenant_id)


@router.post(
    "/override/resume",
    response_model=OverrideStateResponse,
    dependencies=_GOVERNANCE_WRITE_DEPENDENCIES,
)
def resume_automation(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> OverrideStateResponse:
    """Resume autonomous Workweaver execution for the authenticated tenant."""
    stops = _load_behavioral_stops(tenant_id)
    stops["pause_autonomy"] = False
    stops["pause_autonomy_at"] = None
    _save_behavioral_stops(tenant_id, stops)
    return _build_override_state_response(tenant_id)


@router.post(
    "/override/pause-learning",
    response_model=OverrideStateResponse,
    dependencies=_GOVERNANCE_WRITE_DEPENDENCIES,
)
def pause_learning(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> OverrideStateResponse:
    """Pause learning for the authenticated tenant."""
    svc = _get_override_service()
    svc.pause_learning(tenant_id)
    return _build_override_state_response(tenant_id)


@router.get("/override/state", response_model=OverrideStateResponse)
def get_override_state(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> OverrideStateResponse:
    """Return current human override state for the authenticated tenant."""
    return _build_override_state_response(tenant_id)


@router.post("/heartbeat", response_model=HeartbeatResponse)
def record_heartbeat(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> HeartbeatResponse:
    """Record a human presence heartbeat for the authenticated tenant."""
    svc = _get_override_service()
    svc.record_heartbeat(tenant_id)
    hb = svc.check_heartbeat(tenant_id)
    return HeartbeatResponse(
        tenant_id=tenant_id,
        recorded=True,
        last_heartbeat=hb.last_heartbeat,
        stale=hb.stale,
    )


# ── Idempotency gate status (issue #3604) ───────────────────────────


class IdempotencyGateStatusResponse(BaseModel):
    tenant_id: str
    fail_closed: bool
    risk_tier: str
    mode: str
    degraded: bool


@router.get("/idempotency-gate", response_model=IdempotencyGateStatusResponse)
def get_idempotency_gate_status(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> IdempotencyGateStatusResponse:
    """Return the idempotency gate fail-closed status for the tenant (issue #3604)."""
    from apps.backend.services.idempotency import RiskAwareIdempotencyStore

    store = RiskAwareIdempotencyStore()
    health = store.health_check()
    return IdempotencyGateStatusResponse(
        tenant_id=tenant_id,
        fail_closed=health.get("fail_closed", True),
        risk_tier=health.get("risk_tier", "HIGH_RISK"),
        mode=health.get("mode", "durable"),
        degraded=health.get("degraded", False),
    )


# ── Budget Gate (fail-closed, #3603) ────────────────────────────────────


class BudgetGateStatusResponse(BaseModel):
    """Current budget gate status for the authenticated tenant."""

    tenant_id: str
    fail_closed: bool = Field(description="True when the gate denies on metering degradation")
    degraded_axes: list[str] = Field(default_factory=list, description="Axes currently degraded")
    verdict: str = Field(description="Current gate verdict: GO / REJECT")


@router.get("/budget-gate", response_model=BudgetGateStatusResponse)
def get_budget_gate_status(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> BudgetGateStatusResponse:
    """Return the current budget gate fail-closed status for the authenticated tenant.

    The budget gate is fail-closed: when metering is degraded (timeout, error),
    requests are denied rather than silently allowed (issue #3603).
    """
    from apps.backend.services.billing.budget_gate_default import DefaultBudgetGate

    gate = DefaultBudgetGate()
    snapshot, degraded_axes = gate._snapshot(tenant_id)
    verdict = "REJECT" if degraded_axes else "GO"
    return BudgetGateStatusResponse(
        tenant_id=tenant_id,
        fail_closed=True,
        degraded_axes=degraded_axes,
        verdict=verdict,
    )


# ── Memory canonicalization status (issue #3605) ─────────────────────


class MemoryCanonicalizationStatusResponse(BaseModel):
    tenant_id: str
    canonical_backend: str
    default_max_results: int


@router.get("/memory-canonicalization", response_model=MemoryCanonicalizationStatusResponse)
def get_memory_canonicalization_status(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> MemoryCanonicalizationStatusResponse:
    """Return the memory canonicalization + bounded recall status (issue #3605)."""
    from apps.backend.providers.portable_store import InMemoryStore
    from apps.backend.workmemory.services.memory_canonicalization import (
        MemoryCanonicalizationService,
    )

    svc = MemoryCanonicalizationService(store=InMemoryStore())
    backend = svc.get_canonical_backend(tenant_id)
    return MemoryCanonicalizationStatusResponse(
        tenant_id=tenant_id,
        canonical_backend=backend,
        default_max_results=50,
    )
