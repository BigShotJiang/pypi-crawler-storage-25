"""ChannelMessage render REST endpoint (#3261).

POST /api/v1/channels/render — accepts a ChannelMessage + target enum,
returns the rendered platform-specific payload.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from fastapi import Depends

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/channels", tags=["channels-render"])


class RenderBlockPayload(BaseModel):
    block_type: str = Field(..., max_length=50)
    text: str | None = Field(default=None, max_length=3000)
    actions: list[dict[str, str]] | None = None
    image_url: str | None = None
    alt_text: str | None = None
    confidence_level: str | None = Field(default=None, max_length=20)
    slack_elements: list[dict[str, Any]] | None = None
    slack_text_type: str | None = Field(default=None, max_length=20)


class RenderMessagePayload(BaseModel):
    blocks: list[RenderBlockPayload] = Field(default_factory=list)
    fallback_text: str = Field(default="", max_length=5000)
    decision_trace_id: str | None = None
    confidence_level: str | None = Field(default=None, max_length=20)


class RenderRequest(BaseModel):
    target: str = Field(..., description="Render target: slack, adaptive_card, markdown, email_html, plain_text")
    message: RenderMessagePayload


class RenderResponse(BaseModel):
    target: str
    payload: Any
    decision_trace_id: str | None = None


@router.post("/render", response_model=RenderResponse)
async def render_channel_message(
    request: RenderRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> RenderResponse:
    """Render a ChannelMessage to a specific platform format."""
    from apps.backend.services.channels.channel_message import (
        ChannelBlock,
        ChannelMessage,
        ChannelMessageRenderer,
        ChannelTarget,
    )

    try:
        target = ChannelTarget(request.target)
    except ValueError:
        valid = ", ".join(t.value for t in ChannelTarget)
        raise HTTPException(
            status_code=422,
            detail=f"Invalid target '{request.target}'. Valid: {valid}",
        ) from None

    blocks = [
        ChannelBlock(
            block_type=b.block_type,
            text=b.text,
            actions=b.actions,
            image_url=b.image_url,
            alt_text=b.alt_text,
            confidence_level=b.confidence_level,
            slack_elements=b.slack_elements,
            slack_text_type=b.slack_text_type,
        )
        for b in request.message.blocks
    ]

    msg = ChannelMessage(
        blocks=blocks,
        fallback_text=request.message.fallback_text,
        decision_trace_id=request.message.decision_trace_id,
        confidence_level=request.message.confidence_level,
    )

    renderer = ChannelMessageRenderer()
    result = renderer.render(msg, target=target)

    return RenderResponse(
        target=result.target,
        payload=result.payload,
        decision_trace_id=result.decision_trace_id,
    )


__all__ = ["router"]
