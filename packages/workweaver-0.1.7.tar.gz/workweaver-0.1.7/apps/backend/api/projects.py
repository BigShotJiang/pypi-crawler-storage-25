"""
Projects API

Natural language project generation and management.

Source: docs/PRODUCT.md#Part18.3
"""

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.project_generator import ProjectGenerator

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/mission/projects", tags=["projects"])

_project_gen = ProjectGenerator()


class GenerateProjectRequest(BaseModel):
    description: str = Field(..., min_length=10, max_length=5000, description="Natural language project description")
    deadline: str | None = Field(None, max_length=50, description="Target deadline (YYYY-MM-DD)")
    team_size: int | None = Field(None, ge=1, le=10, description="Max agents to assign")


class ConfirmProjectRequest(BaseModel):
    plan_id: str = Field(..., max_length=100, description="Plan ID from /generate response")


@router.post("/generate")
async def generate_project(
    req: GenerateProjectRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Generate a project plan from natural language description."""
    plan = _project_gen.generate_plan(
        tenant_id=tenant_id,
        description=req.description,
        deadline=req.deadline,
        team_size=req.team_size,
    )
    return plan


@router.get("/{plan_id}")
async def get_project_plan(
    plan_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Get a generated project plan."""
    plan = _project_gen.get_plan(plan_id, tenant_id)
    if not plan:
        raise HTTPException(status_code=404, detail=f"Plan {plan_id} not found")
    return plan


@router.post("/confirm")
async def confirm_project(
    req: ConfirmProjectRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Confirm a generated plan for execution."""
    plan = _project_gen.confirm_plan(tenant_id, req.plan_id)
    if not plan:
        raise HTTPException(status_code=404, detail=f"Plan {req.plan_id} not found")
    return plan
