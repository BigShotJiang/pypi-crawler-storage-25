"""
Shared rate limiter for all API endpoints.

Import this module in route files to apply per-endpoint limits:
    from api.rate_limit import limiter

    @router.post("/login")
    @limiter.limit("5/minute")
    async def login(request: Request, ...): ...

Rate limiting is disabled when DISABLE_RATE_LIMIT=1 (for test environments).
Limits are per IP address by default.

The ``default_limits`` apply to EVERY route via ``SlowAPIMiddleware`` (auto_check).
Routes decorated with ``@limiter.limit(...)`` get stricter per-endpoint limits
*in addition to* the default.  ``application_limits`` are hard ceilings that
always apply on top of everything else.
"""

from __future__ import annotations

import os

from slowapi import Limiter
from slowapi.util import get_remote_address

_enabled = os.environ.get("DISABLE_RATE_LIMIT", "").strip().lower() not in ("1", "true", "yes")

limiter = Limiter(
    key_func=get_remote_address,
    # Per-route default: 120 req/min (~2 req/sec).  Sensitive endpoints
    # override this with stricter @limiter.limit decorators.
    default_limits=["120/minute"],
    # Hard ceiling per IP across all endpoints (burst + sustained):
    application_limits=["600/minute"],
    enabled=_enabled,
)
