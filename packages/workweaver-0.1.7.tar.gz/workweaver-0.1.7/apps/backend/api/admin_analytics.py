"""Admin analytics API -- issues #1089 + #1158.

Provides platform-level usage analytics for the admin dashboard:

  GET /api/v1/admin/analytics/usage

Returns:
- DAU, WAU, MAU: real values computed from the ``TENANTS_ALL_INDEX`` DDB
  fan-out partition. Falls open to ``data_source="unavailable"`` if the
  table env var is missing or DDB raises — the admin UI must honor
  ``data_source`` to distinguish "no activity" from "source down".
- Session counts over 7d and 30d windows (placeholder zeros until the
  metering SQS fan-out includes session markers).
- Tool call counts over 7d (placeholder zeros until metering is wired).
- Top 10 connectors by usage (empty placeholder until per-connector
  metering is live).
- Rolling window breakdowns for 7d, 30d, 90d (active_tenants is real;
  sessions/tool_calls follow metering wiring).

Auth: requires admin role via ``require_admin_user_role`` dependency.
"""

from __future__ import annotations

import logging
from datetime import datetime, UTC
from typing import Any

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import require_admin_user_role
from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.services.admin.admin_permission import AdminPermission

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/admin/analytics",
    tags=["admin-analytics"],
    dependencies=[
        Depends(require_admin_user_role),
        Depends(require_admin_permission_dep(AdminPermission.ANALYTICS_READ)),
    ],
)


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class ConnectorUsage(BaseModel):
    """Usage entry for a single connector."""

    connector_id: str = Field(..., description="Connector identifier")
    name: str = Field(..., description="Human-readable connector name")
    usage_count: int = Field(..., ge=0, description="Total usage count in the window")


class RollingWindowMetrics(BaseModel):
    """Metrics for a single rolling window period."""

    active_tenants: int = Field(..., ge=0, description="Distinct active tenants")
    sessions: int = Field(..., ge=0, description="Total sessions")
    tool_calls: int = Field(..., ge=0, description="Total tool calls")


class AdminAnalyticsResponse(BaseModel):
    """Response shape for the admin analytics usage endpoint."""

    dau: int = Field(..., ge=0, description="Daily active unique tenants")
    wau: int = Field(..., ge=0, description="Weekly active unique tenants")
    mau: int = Field(..., ge=0, description="Monthly active unique tenants")
    session_count_7d: int = Field(..., ge=0, description="Total sessions in last 7 days")
    session_count_30d: int = Field(..., ge=0, description="Total sessions in last 30 days")
    tool_call_count_7d: int = Field(..., ge=0, description="Total tool calls in last 7 days")
    top_connectors: list[ConnectorUsage] = Field(
        default_factory=list,
        description="Top 10 connectors by usage (empty when no data)",
    )
    rolling_windows: dict[str, RollingWindowMetrics] = Field(
        ...,
        description="Metrics broken down by rolling window (7d, 30d, 90d)",
    )
    generated_at: str = Field(
        default="",
        description="ISO-8601 timestamp of when the response was generated",
    )
    data_source: str = Field(
        default="unavailable",
        description=(
            "Where the numbers came from. One of: "
            "'tenants_index' — tenants DDB fan-out query returned the full "
            "dataset (real and complete); "
            "'tenants_index_partial' — DDB pagination was truncated at the "
            "page-budget cap; numbers are a lower bound, UI should render a "
            "'partial data' affordance; "
            "'unavailable' — DDB unreachable and we fell back to zeros. "
            "Issue #1158 — callers must distinguish 'no activity' from 'data "
            "source down'. Codex round-3 #1377 review added the partial state."
        ),
    )
    data_source_error: str | None = Field(
        default=None,
        description=(
            "When data_source='unavailable' or 'tenants_index_partial', a "
            "short operator-friendly reason (e.g. 'ddb_scan_failed: "
            "AccessDenied', 'scan_truncated_at_25_pages'). Never PII."
        ),
    )


# ---------------------------------------------------------------------------
# Data helpers — Issue #1158: compute DAU/WAU/MAU from the tenants DDB table
# by scanning ``last_active_at`` / ``last_login_at`` timestamps. Falls back
# to zeros with ``data_source="unavailable"`` when DDB is unreachable so
# the admin UI can render an honest "source unavailable" state.
# ---------------------------------------------------------------------------

_ROLLING_PERIODS = ("7d", "30d", "90d")

# Keys we look at to decide whether a tenant was "active" in a window.
# Kept broad on purpose — any of these timestamps advancing counts as
# activity, which is what DAU/WAU/MAU semantics actually want.
_TENANT_ACTIVITY_TIMESTAMP_KEYS = (
    "last_active_at",
    "last_login_at",
    "last_user_action_at",
    "updated_at",
)


def _parse_iso(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        text = str(value)
        # Accept trailing Z.
        if text.endswith("Z"):
            text = text[:-1] + "+00:00"
        parsed = datetime.fromisoformat(text)
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=UTC)
        return parsed
    except (ValueError, TypeError):
        return None


def _latest_activity_at(row: dict[str, Any]) -> datetime | None:
    """Return the most-recent activity timestamp across known tenant fields."""
    newest: datetime | None = None
    for key in _TENANT_ACTIVITY_TIMESTAMP_KEYS:
        parsed = _parse_iso(row.get(key))
        if parsed is not None and (newest is None or parsed > newest):
            newest = parsed
    return newest


_TENANT_ACTIVITY_PROJECTION = (
    "tenant_pk, sk, created_at, updated_at, #status, "
    "last_active_at, last_login_at, last_user_action_at"
)
_TENANT_ACTIVITY_PAGE_LIMIT = 200
_TENANT_ACTIVITY_MAX_PAGES = 25  # 5,000 tenants/page*pages hard-cap


def _scan_tenant_activity() -> tuple[list[datetime], str, str | None]:
    """Return (activity_timestamps, source, error) for DAU/WAU/MAU aggregation.

    Issue #1158: queries the ``TENANTS_ALL_INDEX_PK`` fan-out partition on the
    tenants table (written at tenant creation/update) and projects only the
    small set of timestamp attributes in ``_TENANT_ACTIVITY_TIMESTAMP_KEYS``.
    This avoids a full table scan and keeps the admin analytics endpoint
    bounded regardless of tenant count.

    Fall-open behavior:
      - ``("unavailable", "tenants_table_env_not_set")`` when env var missing
        (admin UI should render "source unavailable", not zero activity)
      - ``("unavailable", "ddb_query_failed: <ExceptionType>")`` on DDB error
      - ``("tenants_index", None)`` on success (even if zero tenants)
      - ``("tenants_index_partial", "scan_truncated_at_N_pages")`` when the
        scan hit ``_TENANT_ACTIVITY_MAX_PAGES`` but DDB still had more rows —
        the returned activity is a prefix, not the whole population. Codex
        round-3 review: without this, DAU/WAU/MAU silently undercount past
        ``PAGE_LIMIT*MAX_PAGES`` tenants while ``data_source="tenants_index"``
        falsely claims full fidelity. Callers must treat partial as
        "trust the source, but the number is a lower bound."

    PII safety:
      - Only non-PII timestamp attributes are projected; the fan-out record
        does NOT contain user/owner PII beyond the status enum.
    """
    try:
        import os  # noqa: PLC0415

        tenants_table = os.getenv("TENANTS_TABLE", "").strip()
        if not tenants_table:
            return [], "unavailable", "tenants_table_env_not_set"

        # Lazy imports so admin_analytics stays importable in minimal test
        # environments (no boto3 / no portable store registry).
        from apps.backend.dependency_factories.core import get_tenants_table  # noqa: PLC0415
        from apps.backend.services.tenant_provisioning import TENANTS_ALL_INDEX_PK  # noqa: PLC0415

        table = get_tenants_table()
        if table is None:
            return [], "unavailable", "tenants_table_factory_returned_none"

        activity: list[datetime] = []
        last_evaluated_key = None
        pages = 0
        while pages < _TENANT_ACTIVITY_MAX_PAGES:
            kwargs: dict[str, Any] = {
                "KeyConditionExpression": "pk = :pk",
                "ExpressionAttributeValues": {":pk": TENANTS_ALL_INDEX_PK},
                "ExpressionAttributeNames": {"#status": "status"},
                "ProjectionExpression": _TENANT_ACTIVITY_PROJECTION,
                "Limit": _TENANT_ACTIVITY_PAGE_LIMIT,
            }
            if last_evaluated_key:
                kwargs["ExclusiveStartKey"] = last_evaluated_key
            response = table.query(**kwargs)
            items = response.get("Items", []) if isinstance(response, dict) else []
            for item in items:
                if not isinstance(item, dict):
                    continue
                parsed = _latest_activity_at(item)
                if parsed is not None:
                    activity.append(parsed)
            last_evaluated_key = (
                response.get("LastEvaluatedKey") if isinstance(response, dict) else None
            )
            pages += 1
            if not last_evaluated_key:
                break
        if last_evaluated_key:
            # Ran out of page budget while DDB still had rows — the admin
            # dashboard must surface "partial" rather than trust a silently
            # undercounted number as the whole dataset.
            logger.warning(
                "admin_analytics_tenant_scan_truncated pages=%d limit=%d",
                pages,
                _TENANT_ACTIVITY_MAX_PAGES,
            )
            return (
                activity,
                "tenants_index_partial",
                f"scan_truncated_at_{pages}_pages",
            )
        return activity, "tenants_index", None
    except Exception as exc:  # noqa: BLE001 — structural fall-open
        logger.warning("admin_analytics_tenant_scan_failed: %s", exc)
        return [], "unavailable", f"ddb_query_failed: {type(exc).__name__}"


def _count_in_window(activity: list[datetime], *, days: int, now: datetime) -> int:
    from datetime import timedelta  # local import — narrow scope

    cutoff = now - timedelta(days=days)
    return sum(1 for ts in activity if ts >= cutoff)


def _estimate_active_tenants(
    activity: list[datetime] | None = None, now: datetime | None = None
) -> dict[str, int]:
    """Compute DAU/WAU/MAU from tenant activity timestamps.

    When ``activity`` is None we scan the tenants table. Callers in tests
    may pass a pre-computed list to avoid the scan.
    """
    if now is None:
        now = datetime.now(UTC)
    if activity is None:
        activity, _, _ = _scan_tenant_activity()
    return {
        "dau": _count_in_window(activity, days=1, now=now),
        "wau": _count_in_window(activity, days=7, now=now),
        "mau": _count_in_window(activity, days=30, now=now),
    }


def _estimate_session_counts() -> dict[str, int]:
    """Return session counts for 7d and 30d windows.

    Placeholder: returns zeros.
    """
    return {"session_count_7d": 0, "session_count_30d": 0}


def _estimate_tool_call_count() -> int:
    """Return tool call count for the last 7 days.

    Placeholder: returns zero.
    """
    return 0


def _get_top_connectors(*, limit: int = 10) -> list[dict[str, Any]]:
    """Return top connectors by usage.

    Placeholder: returns an empty list until connector usage tracking
    is wired into the metering pipeline.
    """
    return []


def _build_rolling_windows() -> dict[str, dict[str, int]]:
    """Build metrics for each rolling window period.

    Placeholder: returns zeros for all periods.
    """
    return {period: {"active_tenants": 0, "sessions": 0, "tool_calls": 0} for period in _ROLLING_PERIODS}


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------


@router.get("/usage", response_model=AdminAnalyticsResponse)
async def get_admin_analytics_usage() -> AdminAnalyticsResponse:
    """Return platform-level usage analytics for the admin dashboard.

    Issue #1158: DAU/WAU/MAU are computed from the tenants DDB table
    (fall-open to 0 on DDB failure with ``data_source='unavailable'`` so
    the admin UI can render honest "source unavailable" copy instead of
    implying zero activity). Session counts, tool-call counts, and
    connector usage remain placeholder until metering tables are wired
    through the same scan pattern in a follow-up slice.
    """
    now = datetime.now(UTC)
    activity, data_source, data_source_error = _scan_tenant_activity()
    tenants = _estimate_active_tenants(activity=activity, now=now)
    sessions = _estimate_session_counts()

    # rolling_windows: only active_tenants is real today.
    rolling = {}
    for period in _ROLLING_PERIODS:
        days = int(period.rstrip("d"))
        rolling[period] = RollingWindowMetrics(
            active_tenants=_count_in_window(activity, days=days, now=now),
            sessions=0,
            tool_calls=0,
        )

    return AdminAnalyticsResponse(
        dau=tenants["dau"],
        wau=tenants["wau"],
        mau=tenants["mau"],
        session_count_7d=sessions["session_count_7d"],
        session_count_30d=sessions["session_count_30d"],
        tool_call_count_7d=_estimate_tool_call_count(),
        top_connectors=_get_top_connectors(limit=10),
        rolling_windows=rolling,
        generated_at=now.isoformat(),
        data_source=data_source,
        data_source_error=data_source_error,
    )
