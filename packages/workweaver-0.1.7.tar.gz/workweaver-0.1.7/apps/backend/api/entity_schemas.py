"""Versioned tenant entity schema registry API."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, get_verified_user_id
from apps.backend.models.entity_schema import EntitySchema, EntitySchemaDraftRequest, EntitySchemaStatus
from apps.backend.services.entity_schema_registry import (
    EntitySchemaNotFoundError,
    EntitySchemaValidationError,
    get_entity_schema_registry,
)

router = APIRouter(prefix="/api/v1/entity-schemas", tags=["entity-schemas"])


@router.post("", response_model=EntitySchema, status_code=status.HTTP_201_CREATED)
async def create_entity_schema_draft(
    request: EntitySchemaDraftRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> EntitySchema:
    return get_entity_schema_registry().create_draft(tenant_id, request)


@router.get("", response_model=list[EntitySchema])
async def list_entity_schemas(
    status_filter: EntitySchemaStatus | None = Query(None, alias="status"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[EntitySchema]:
    return get_entity_schema_registry().list_schemas(tenant_id, status=status_filter)


@router.get("/{name}", response_model=EntitySchema)
async def get_entity_schema(
    name: str,
    version: int | None = Query(None, ge=1),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> EntitySchema:
    schema = get_entity_schema_registry().get_schema(tenant_id, name, version)
    if schema is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Entity schema not found: {name}")
    return schema


@router.post("/{name}/versions/{version}/activate", response_model=EntitySchema)
async def activate_entity_schema(
    name: str,
    version: int,
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
) -> EntitySchema:
    try:
        return get_entity_schema_registry().activate_schema(tenant_id, name, version, actor_id=actor_id)
    except EntitySchemaNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    except EntitySchemaValidationError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_CONTENT, detail=str(exc)) from exc

