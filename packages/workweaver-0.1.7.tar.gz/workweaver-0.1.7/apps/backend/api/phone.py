"""
Phone Management API

Provides REST endpoints for tenant-owned phone management primitives:
- POST /api/phone/port - Create a tenant-owned port request
- GET /api/phone/port/{port_id} - Get port request status
- GET /api/phone/port - List all port requests
- GET /api/phone/inventory - List tenant phone inventory
- DELETE /api/phone/inventory/{phone_id} - Release a phone number

Twilio operations use the tenant's BYO connector credentials (see
POST /api/v1/connectors/twilio/connect), not platform-managed Twilio env vars (#1317).

All operations are tenant-scoped and logged to the Evidence Ledger.
"""

import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field, field_validator

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.pagination import (
    PaginationParams,
    build_pagination_dependency,
    paginate_items,
    resolve_pagination,
)
from apps.backend.services.phone_porting import (
    PhonePortingService,
    PortStatus,
    PortingReason,
    PortAddress,
)
from apps.backend.services.phone_provisioning import (
    PhoneProvisioningService,
)
from apps.backend.services.evidence_ledger import get_evidence_ledger_service
from apps.backend.services.tenant_twilio_byo import (
    TenantTwilioBYOError,
    resolve_twilio_rest_client_for_tenant,
    twilio_byo_error_payload,
)

try:
    from apps.backend.services import dynamo_store
except ImportError:  # pragma: no cover - flat-path fallback (Docker)
    from services import dynamo_store  # type: ignore[no-redef]

logger = logging.getLogger(__name__)

_ROUTING_SK_PREFIX = "TELEPHONY_ROUTING#"


def _twilio_client_for_tenant(tenant_id: str):
    try:
        return resolve_twilio_rest_client_for_tenant(tenant_id)
    except TenantTwilioBYOError as exc:
        raise HTTPException(
            status_code=status.HTTP_412_PRECONDITION_FAILED,
            detail=twilio_byo_error_payload(exc),
        ) from exc


def _require_tenant_id(request: Request) -> str:
    tenant_id = str(getattr(request.state, "tenant_id", "") or "").strip()
    if not tenant_id:
        raise HTTPException(status_code=401, detail="Missing organization context")
    return tenant_id


def _routing_sk(phone_sid: str) -> str:
    return f"{_ROUTING_SK_PREFIX}{phone_sid}"


def _tenant_owns_phone_sid(tenant_id: str, phone_sid: str) -> bool:
    try:
        routing = dynamo_store.get_item(tenant_id, _routing_sk(phone_sid))
    except Exception:
        logger.warning("Failed to resolve telephony routing ownership sid=%s", phone_sid, exc_info=True)
        return False

    return bool(isinstance(routing, dict) and routing and routing.get("tenant_id") == tenant_id)


def _record_phone_evidence(
    *,
    tenant_id: str,
    event_type: str,
    data: dict[str, object],
) -> None:
    """Write a phone-management fact to the canonical evidence ledger."""
    try:
        get_evidence_ledger_service().ingest(
            tenant_id=tenant_id,
            event_type="evidence:item",
            data={
                "item_type": event_type,
                "domain": "telephony",
                **data,
            },
            actor_path="tenant.phone_management",
            service_family="telephony",
            capture_surface="phone_api",
        )
    except Exception as exc:  # pragma: no cover - best-effort audit log
        logger.warning("Failed to log phone evidence: %s", exc, exc_info=True)


# ============================================================================
# Request/Response Models
# ============================================================================


class PortAddressModel(BaseModel):
    """Address model for porting requests."""

    street: str = Field(..., description="Street address")
    city: str = Field(..., description="City name")
    region: str = Field(..., description="State/Province")
    postal_code: str = Field(..., description="Postal/ZIP code")
    iso_country: str = Field(..., description="ISO 3166-1 alpha-2 country code")

    @field_validator("iso_country")
    @classmethod
    def validate_iso_country(cls, v):
        if not v or len(v) != 2 or not v.isalpha() or not v.isupper():
            raise ValueError("iso_country must be ISO 3166-1 alpha-2 code (e.g., 'US', 'AE')")
        return v


class CreatePortRequest(BaseModel):
    """Request to create a phone number porting request."""

    phone_number: str = Field(
        ...,
        description="E.164 phone number to port (e.g., '+14155551234')",
    )

    number_type: str = Field(
        default="business",
        description="Type of number: 'business' or 'personal'",
    )

    wireless: bool = Field(
        default=False,
        description="Whether this is a wireless/mobile number",
    )

    # Business information
    company_name: str | None = Field(
        default=None,
        description="Company name (required for business numbers)",
    )

    company_title: str | None = Field(
        default=None,
        description="Signatory's title in company (for business numbers)",
    )

    # Personal information
    first_name: str | None = Field(
        default=None,
        description="First name (required for personal numbers)",
    )

    last_name: str | None = Field(
        default=None,
        description="Last name (required for personal numbers)",
    )

    title: str | None = Field(
        default=None,
        description="Title (for personal numbers)",
    )

    # Contact information
    email: str = Field(
        ...,
        description="Contact email address",
    )

    contact_phone_number: str | None = Field(
        default=None,
        description="Contact phone number",
    )

    # Carrier information
    carrier_name: str | None = Field(
        default=None,
        description="Current carrier name",
    )

    account_number: str | None = Field(
        default=None,
        description="Account number with current carrier",
    )

    pin: str | None = Field(
        default=None,
        description="PIN/passcode with current carrier",
    )

    taxpayer_id: str | None = Field(
        default=None,
        description="Tax ID / SSN (last 4 digits)",
    )

    # Addresses
    billing_address: PortAddressModel | None = Field(
        default=None,
        description="Billing address for the number",
    )

    service_address: PortAddressModel | None = Field(
        default=None,
        description="Service address for the number",
    )

    # Porting details
    porting_reason: str = Field(
        default="business",
        description="Reason for porting: 'personal', 'business', 'resale', 'other'",
    )

    # Signed document URLs (optional, if pre-signed)
    loa_url: str | None = Field(
        default=None,
        description="URL to signed LOA document",
    )

    signature_url: str | None = Field(
        default=None,
        description="URL to signature image",
    )

    @field_validator("phone_number")
    @classmethod
    def validate_phone_number(cls, v):
        if not PhoneProvisioningService.validate_phone_number(v):
            raise ValueError("phone_number must be in E.164 format (e.g., '+14155551234')")
        return v

    @field_validator("number_type")
    @classmethod
    def validate_number_type(cls, v):
        if v not in ("business", "personal"):
            raise ValueError("number_type must be 'business' or 'personal'")
        return v

    @field_validator("porting_reason")
    @classmethod
    def validate_porting_reason(cls, v):
        valid_reasons = {"personal", "business", "resale", "other"}
        if v not in valid_reasons:
            raise ValueError(f"porting_reason must be one of {valid_reasons}")
        return v


class PhoneNumberInventoryItem(BaseModel):
    """Phone number in tenant inventory."""

    phone_number: str
    sid: str
    friendly_name: str
    date_created: str
    capabilities: dict
    status: str  # "in-use" or "released"


# ============================================================================
# API Router
# ============================================================================

router = APIRouter(
    prefix="/api/phone",
    tags=["phone-management"],
    dependencies=[Depends(get_verified_tenant_id)],
)


@router.post("/port", response_model=dict)
async def create_port_request(request: Request, body: CreatePortRequest):
    """
    Create a phone number porting request.

    Initiates the process of porting an existing phone number to the tenant's Twilio account.
    Returns a port request ID and a Letter of Authorization (LOA) document.

    The LOA document must be signed and submitted to complete the porting process.

    Used by agents to port numbers without UI interaction.

    Evidence Ledger: Logs port request creation event (Constitution Axiom 2).
    """
    try:
        tenant_id = _require_tenant_id(request)

        twilio_client = _twilio_client_for_tenant(tenant_id)
        porting_service = PhonePortingService(twilio_client)

        # Convert models to service types
        billing_address = None
        if body.billing_address:
            billing_address = PortAddress(
                street=body.billing_address.street,
                city=body.billing_address.city,
                region=body.billing_address.region,
                postal_code=body.billing_address.postal_code,
                iso_country=body.billing_address.iso_country,
            )

        service_address = None
        if body.service_address:
            service_address = PortAddress(
                street=body.service_address.street,
                city=body.service_address.city,
                region=body.service_address.region,
                postal_code=body.service_address.postal_code,
                iso_country=body.service_address.iso_country,
            )

        # Map porting reason string to enum
        reason_map = {
            "personal": PortingReason.PERSONAL,
            "business": PortingReason.BUSINESS,
            "resale": PortingReason.RESALE,
            "other": PortingReason.OTHER,
        }
        porting_reason = reason_map.get(body.porting_reason, PortingReason.BUSINESS)

        # Create port request
        result = await porting_service.create_port_request(
            phone_number=body.phone_number,
            number_type=body.number_type,
            wireless=body.wireless,
            company_name=body.company_name,
            company_title=body.company_title,
            first_name=body.first_name,
            last_name=body.last_name,
            title=body.title,
            email=body.email,
            contact_phone=body.contact_phone_number,
            carrier_name=body.carrier_name,
            account_number=body.account_number,
            pin=body.pin,
            taxpayer_id=body.taxpayer_id,
            billing_address=billing_address,
            service_address=service_address,
            porting_reason=porting_reason,
            loa_url=body.loa_url,
            signature_url=body.signature_url,
        )

        if not result.success:
            raise HTTPException(status_code=400, detail=result.message)

        _record_phone_evidence(
            tenant_id=tenant_id,
            event_type="phone_port_request_created",
            data={
                "phone_number": body.phone_number,
                "port_request_id": result.port_request_id,
                "number_type": body.number_type,
                "ownership_model": "tenant_owned",
                "contract_mode": "byo_assisted",
            },
        )

        return {
            "port_request_id": result.port_request_id,
            "message": result.message,
            "ownership_model": "tenant_owned",
            "contract_mode": "byo_assisted",
            "loa_document": {
                "content": result.loa_document.content if result.loa_document else None,
                "filename": result.loa_document.filename if result.loa_document else None,
                "content_type": result.loa_document.content_type if result.loa_document else None,
            },
            "status": "pending",
            "next_steps": [
                "1. Download and sign the LOA document",
                "2. Upload signed LOA via PUT /api/phone/port/{port_id}/loa",
                "3. Wait for port request to be approved (2-4 weeks)",
                "4. Do not cancel service with current provider until port completes",
            ],
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to create port request: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to create port request")


@router.get("/port/{port_id}", response_model=Optional[dict])
async def get_port_status(request: Request, port_id: str):
    """
    Get the status of a porting request.

    Returns current status, dates, and completion estimate for a port request.
    Returns null if the port request ID is not found.

    Used by agents to check porting status without UI interaction.
    """
    try:
        tenant_id = _require_tenant_id(request)
        twilio_client = _twilio_client_for_tenant(tenant_id)
        porting_service = PhonePortingService(twilio_client)

        result = await porting_service.check_port_status(port_id)

        if result is None:
            return None

        return {
            "port_request_id": result.port_request_id,
            "phone_number": result.phone_number,
            "status": result.status.value,
            "date_created": result.date_created,
            "date_completed": result.date_completed,
            "estimated_completion_date": result.estimated_completion_date,
            "loa_required": result.loa_required,
            "carrier_name": result.carrier_name,
            "ownership_model": "tenant_owned",
        }

    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as e:
        logger.error(f"Failed to get port status: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to get port status")


@router.get("/port", response_model=list[dict])
async def list_port_requests(
    request: Request,
    status: str | None = None,
    limit: int = 50,
):
    """
    List all porting requests.

    Returns a list of port requests with their current status.
    Can filter by status and limit results.

    Used by agents to list port requests without UI interaction.
    """
    try:
        tenant_id = _require_tenant_id(request)

        if limit < 1 or limit > 100:
            raise HTTPException(status_code=400, detail="limit must be between 1 and 100")

        twilio_client = _twilio_client_for_tenant(tenant_id)
        porting_service = PhonePortingService(twilio_client)

        # Map status string to enum if provided
        status_filter = None
        if status:
            status_map = {
                "pending": PortStatus.PENDING,
                "in-review": PortStatus.IN_REVIEW,
                "approved": PortStatus.APPROVED,
                "rejected": PortStatus.REJECTED,
                "completed": PortStatus.COMPLETED,
                "failed": PortStatus.FAILED,
                "cancelled": PortStatus.CANCELLED,
            }
            status_filter = status_map.get(status)
            if status_filter is None:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid status: {status}. Must be one of {list(status_map.keys())}",
                )

        results = await porting_service.list_port_requests(status=status_filter, limit=limit)

        return [
            {
                "port_request_id": r.port_request_id,
                "phone_number": r.phone_number,
                "status": r.status.value,
                "date_created": r.date_created,
                "date_completed": r.date_completed,
                "estimated_completion_date": r.estimated_completion_date,
                "loa_required": r.loa_required,
                "ownership_model": "tenant_owned",
            }
            for r in results
        ]

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to list port requests: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to list port requests")


@router.get("/inventory", response_model=list[dict])
async def list_phone_inventory(
    request: Request,
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
):
    """
    List tenant phone inventory.

    Returns all phone numbers owned by the tenant account.
    Includes purchased numbers and ported numbers.

    Used by agents to list phone inventory without UI interaction.

    Evidence Ledger: Queries phone inventory state (Constitution Axiom 2).
    """
    try:
        pagination = resolve_pagination(pagination, default_limit=50)
        tenant_id = _require_tenant_id(request)

        twilio_client = _twilio_client_for_tenant(tenant_id)

        # List all incoming phone numbers
        incoming_numbers = twilio_client.incoming_phone_numbers.list(limit=100)

        results = []
        for number in incoming_numbers:
            capabilities = {
                "voice": bool(getattr(number, "capabilities", {}).get("voice", False)),
                "sms": bool(getattr(number, "capabilities", {}).get("sms", False)),
                "mms": bool(getattr(number, "capabilities", {}).get("mms", False)),
                "fax": bool(getattr(number, "capabilities", {}).get("fax", False)),
            }

            sid = getattr(number, "sid", "")
            if not sid or not _tenant_owns_phone_sid(tenant_id, sid):
                continue

            results.append(
                {
                    "phone_number": str(getattr(number, "phone_number", "")),
                    "sid": sid,
                    "friendly_name": getattr(number, "friendly_name", ""),
                    "date_created": getattr(number, "date_created", ""),
                    "capabilities": capabilities,
                    "status": "in-use",
                    "ownership_model": "tenant_owned",
                }
            )

        paged_results, _total = paginate_items(results, pagination)
        logger.info("Listed %s phone numbers for tenant %s", len(paged_results), tenant_id)
        return paged_results

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to list phone inventory: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to list phone inventory")


@router.delete("/inventory/{phone_sid}", response_model=dict)
async def release_phone_number(request: Request, phone_sid: str):
    """
    Release a phone number from tenant inventory.

    Permanently releases the phone number from the Twilio account.
    This action cannot be undone.

    Used by agents to release phone numbers without UI interaction.

    Evidence Ledger: Logs phone number release event (Constitution Axiom 2).
    """
    try:
        tenant_id = _require_tenant_id(request)

        if not phone_sid or not phone_sid.startswith("PN"):
            raise HTTPException(
                status_code=400,
                detail="phone_sid must be a Twilio phone number SID (starts with PN)",
            )

        if not _tenant_owns_phone_sid(tenant_id, phone_sid):
            raise HTTPException(status_code=403, detail="Phone number does not belong to this organization")

        twilio_client = _twilio_client_for_tenant(tenant_id)

        # Fetch the number to get phone number for logging
        try:
            number = twilio_client.incoming_phone_numbers(phone_sid).fetch()
            phone_number = getattr(number, "phone_number", "")
        except Exception:
            phone_number = "unknown"

        # Release the number
        twilio_client.incoming_phone_numbers(phone_sid).delete()

        _record_phone_evidence(
            tenant_id=tenant_id,
            event_type="phone_number_released",
            data={
                "phone_sid": phone_sid,
                "phone_number": phone_number,
                "ownership_model": "tenant_owned",
            },
        )

        logger.info(f"Released phone number {phone_number} ({phone_sid}) for tenant {tenant_id}")

        return {
            "phone_sid": phone_sid,
            "phone_number": phone_number,
            "message": "Phone number released successfully",
            "status": "released",
            "ownership_model": "tenant_owned",
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to release phone number: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to release phone number")
