"""WorkspacePersonaOverlay REST router (#3542).

Routes
------
- ``GET /api/v1/workspace/persona`` → current overlay or 404 with
  ``{"detail": "persona_overlay_not_set"}``.
- ``PUT /api/v1/workspace/persona`` → accept overlay body; 422 on validation
  failure with ``{"detail": "persona_overlay_validation_failed", "violating_keys": [...]}``.
- ``DELETE /api/v1/workspace/persona`` → reset (idempotent — no 404 if unset).

The overlay is the *safe* SOUL.md analog. Kernel envelope, governance, evals,
and floor schema are NOT settable through this surface.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_id,
)
from apps.backend.models.workspace_persona_overlay import (
    PersonaOverlayValidationError,
    WorkspacePersonaOverlay,
)
from apps.backend.services.persona_overlay_service import (
    get_persona_overlay_service,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/workspace/persona", tags=["workspace", "persona"])


@router.get("", summary="Get the current workspace persona overlay")
async def get_workspace_persona(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    service = get_persona_overlay_service()
    overlay = service.get(tenant_id=tenant_id)
    if overlay is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="persona_overlay_not_set",
        )
    return overlay.model_dump(mode="json")


@router.put("", summary="Set or replace the workspace persona overlay")
async def put_workspace_persona(
    overlay: WorkspacePersonaOverlay,
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
) -> dict[str, Any]:
    service = get_persona_overlay_service()
    try:
        # Pydantic already enforced the allowlist at body parse — but we
        # re-run the validator on dump to defend against any future model
        # widening that admits a forbidden path.
        result = service.set_from_payload(
            tenant_id=tenant_id,
            payload=overlay.model_dump(mode="json"),
            actor_id=actor_id,
        )
    except PersonaOverlayValidationError as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail={
                "error": "persona_overlay_validation_failed",
                "message": str(exc),
                "violating_keys": exc.violating_keys,
            },
        )
    return result.model_dump(mode="json")


@router.delete("", summary="Reset the workspace persona overlay")
async def delete_workspace_persona(
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
) -> dict[str, Any]:
    service = get_persona_overlay_service()
    service.reset(tenant_id=tenant_id, actor_id=actor_id)
    return {"status": "ok", "operation": "workspace.persona.reset"}


__all__ = ["router"]
