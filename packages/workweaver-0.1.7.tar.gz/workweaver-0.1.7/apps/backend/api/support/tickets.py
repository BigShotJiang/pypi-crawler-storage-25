"""
Support Tickets API (TASK-6.0G.001)

REST API for customer support ticket management.
Constitutional compliance:
- Axiom 2: All ticket actions logged to Operational Context
- Axiom 5: Automated ticket routing and tracking
"""

import asyncio
import logging

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field

from apps.backend.api.pagination import PaginationParams, build_pagination_dependency
from apps.backend.models.support_ticket import (
    MessageCreate,
    SupportTicket,
    TicketCategory,
    TicketCreate,
    TicketPriority,
    TicketStatus,
    TicketUpdate,
)
from apps.backend.services.ticket_service import TicketService
from apps.backend.services.zoho.ticket_sync_service import TicketSyncService
from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.founder_admin import require_founder
# Configure logging
logger = logging.getLogger(__name__)

# Router
router = APIRouter(prefix="/api/v1/support", tags=["support"])


# ============================================================================
# Dependencies
# ============================================================================


def get_ticket_service() -> TicketService:
    """Get ticket service instance."""
    return TicketService()


def get_sync_service() -> TicketSyncService:
    """Get ticket sync service instance."""
    return TicketSyncService()


# ============================================================================
# Request/Response Models
# ============================================================================


class CreateTicketRequest(BaseModel):
    """Request to create a new ticket."""

    # Deprecated identity fields retained for payload compatibility.
    # Write paths derive tenant/user from verified auth context.
    tenant_id: str | None = Field(
        None,
        description="Deprecated: ignored. Tenant is derived from authentication.",
    )
    user_id: str | None = Field(
        None,
        description="Deprecated: ignored. User is derived from authentication.",
    )
    subject: str = Field(
        ..., min_length=1, max_length=200, description="Ticket subject"
    )
    description: str = Field(
        ..., min_length=1, max_length=5000, description="Ticket description"
    )
    priority: TicketPriority = Field(
        TicketPriority.MEDIUM, description="Ticket priority"
    )
    category: TicketCategory = Field(
        TicketCategory.OTHER, description="Ticket category"
    )


class UpdateTicketRequest(BaseModel):
    """Request to update a ticket."""

    status: TicketStatus | None = Field(None, description="New ticket status")
    priority: TicketPriority | None = Field(None, description="New ticket priority")
    assigned_to: str | None = Field(None, description="Agent ID to assign ticket to")


class AddMessageRequest(BaseModel):
    """Request to add a message to a ticket."""

    # Deprecated sender fields retained for payload compatibility.
    sender_id: str | None = Field(
        None,
        description="Deprecated: ignored. Sender ID is derived from authentication.",
    )
    sender_type: str | None = Field(
        None,
        description="Deprecated: ignored for customer path. Sender type is server-derived.",
    )
    content: str = Field(
        ..., min_length=1, max_length=5000, description="Message content"
    )
    is_internal: bool = Field(
        False, description="True for internal agent notes (not visible to customer)"
    )


class TicketResponse(BaseModel):
    """Response with ticket details."""

    ticket: SupportTicket
    message: str = "Ticket retrieved successfully"


class TicketListResponseModel(BaseModel):
    """Response with ticket list."""

    tickets: list[SupportTicket]
    total: int
    page: int
    page_size: int
    message: str = "Tickets retrieved successfully"


class MessageResponse(BaseModel):
    """Response after adding a message."""

    message_id: str
    ticket_id: str
    message: str = "Message added successfully"


class TicketDetailResponse(BaseModel):
    """Response with full ticket details and messages."""

    ticket: SupportTicket
    messages: list
    message: str = "Ticket detail retrieved successfully"


class HealthResponse(BaseModel):
    """Health check response."""

    status: str
    service: str
    message: str


# ============================================================================
# API Endpoints
# ============================================================================


def _get_request_user_id(request: Request) -> str:
    """Return authenticated user id from request state or raise 401."""
    user_id = str(getattr(request.state, "user_id", "") or "").strip()
    if not user_id:
        raise HTTPException(status_code=401, detail="Authenticated user required")
    return user_id


def _require_ticket_tenant_match(ticket: SupportTicket, tenant_id: str) -> None:
    """Block cross-tenant reads/writes for ticket routes."""
    if ticket.tenant_id != tenant_id:
        # Return 404 to avoid revealing ticket existence across tenants.
        raise HTTPException(status_code=404, detail=f"Ticket {ticket.ticket_id} not found")


@router.post("/tickets", response_model=TicketResponse, status_code=201)
async def create_ticket(
    request_ctx: Request,
    request: CreateTicketRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    ticket_service: TicketService = Depends(get_ticket_service),
) -> TicketResponse:
    """
    Create a new support ticket.

    Args:
        request: Ticket creation request
        ticket_service: Ticket service instance

    Returns:
        Created ticket

    Raises:
        HTTPException: If ticket creation fails
    """
    try:
        user_id = _get_request_user_id(request_ctx)
        ticket_req = TicketCreate(
            subject=request.subject,
            description=request.description,
            priority=request.priority,
            category=request.category,
        )

        ticket = ticket_service.create_ticket(
            tenant_id=tenant_id,
            user_id=user_id,
            request=ticket_req,
        )

        logger.info(
            f"Created ticket {ticket.ticket_id} for tenant {tenant_id}",
            extra={
                "tenant_id": tenant_id,
                "user_id": user_id,
                "ticket_id": ticket.ticket_id,
                "subject": request.subject,
                "category": request.category.value,
                "priority": request.priority.value,
            },
        )

        # Outbound sync to Zoho Desk (fire-and-forget, best-effort)
        sync_svc = get_sync_service()
        asyncio.create_task(
            _outbound_create_sync(sync_svc, ticket_service, ticket, sync_svc)
        )

        return TicketResponse(
            ticket=ticket,
            message="Ticket created successfully",
        )

    except Exception as e:
        logger.error(f"Failed to create ticket: {e}")
        raise HTTPException(status_code=500, detail="Failed to create ticket")


@router.get("/tickets/{ticket_id}", response_model=TicketResponse)
async def get_ticket(
    request_ctx: Request,
    ticket_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    ticket_service: TicketService = Depends(get_ticket_service),
) -> TicketResponse:
    """
    Get a ticket by ID.

    Args:
        ticket_id: Ticket ID
        ticket_service: Ticket service instance

    Returns:
        Ticket details

    Raises:
        HTTPException: If ticket not found
    """
    ticket = ticket_service.get_ticket(ticket_id)

    if not ticket:
        raise HTTPException(status_code=404, detail=f"Ticket {ticket_id} not found")
    _require_ticket_tenant_match(ticket, tenant_id)

    return TicketResponse(
        ticket=ticket,
        message="Ticket retrieved successfully",
    )


@router.get("/tickets", response_model=TicketListResponseModel)
async def list_tickets(
    tenant_id: str = Depends(get_verified_tenant_id),
    status: TicketStatus | None = Query(None, description="Filter by status"),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=100)),
    ticket_service: TicketService = Depends(get_ticket_service),
) -> TicketListResponseModel:
    """
    List tickets for a tenant.

    Args:
        tenant_id: Tenant ID
        status: Optional status filter
        pagination: Shared bounded pagination parameters
        ticket_service: Ticket service instance

    Returns:
        Paginated list of tickets
    """
    response = ticket_service.list_tickets(
        tenant_id=tenant_id,
        status=status,
        page=pagination.page,
        page_size=pagination.page_size,
    )

    return TicketListResponseModel(
        tickets=response.tickets,
        total=response.total,
        page=response.page,
        page_size=response.page_size,
        message="Tickets retrieved successfully",
    )


@router.patch("/tickets/{ticket_id}", response_model=TicketResponse)
async def update_ticket(
    request_ctx: Request,
    ticket_id: str,
    request: UpdateTicketRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    ticket_service: TicketService = Depends(get_ticket_service),
) -> TicketResponse:
    """
    Update ticket status/priority/assignment.

    Args:
        ticket_id: Ticket ID
        request: Update request
        ticket_service: Ticket service instance

    Returns:
        Updated ticket

    Raises:
        HTTPException: If ticket not found or update fails
    """
    try:
        agent_id = _get_request_user_id(request_ctx)
        existing = ticket_service.get_ticket(ticket_id)
        if not existing:
            raise HTTPException(status_code=404, detail=f"Ticket {ticket_id} not found")
        _require_ticket_tenant_match(existing, tenant_id)

        ticket_req = TicketUpdate(
            status=request.status,
            priority=request.priority,
            assigned_to=request.assigned_to,
        )

        ticket = ticket_service.update_ticket(
            ticket_id=ticket_id,
            request=ticket_req,
            agent_id=agent_id,
        )

        if not ticket:
            raise HTTPException(status_code=404, detail=f"Ticket {ticket_id} not found")

        logger.info(
            f"Updated ticket {ticket_id}",
            extra={
                "ticket_id": ticket_id,
                "status": request.status.value if request.status else None,
                "priority": request.priority.value if request.priority else None,
                "assigned_to": request.assigned_to,
            },
        )

        # Outbound sync to Zoho Desk (fire-and-forget, best-effort)
        if request.status and ticket.zoho_ticket_id:
            sync_svc = get_sync_service()
            asyncio.create_task(
                _outbound_update_sync(sync_svc, ticket)
            )

        return TicketResponse(
            ticket=ticket,
            message="Ticket updated successfully",
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to update ticket {ticket_id}: {e}")
        raise HTTPException(
            status_code=500, detail="Failed to update ticket"
        )


@router.post(
    "/tickets/{ticket_id}/messages", response_model=MessageResponse, status_code=201
)
async def add_message(
    request_ctx: Request,
    ticket_id: str,
    msg_body: AddMessageRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    ticket_service: TicketService = Depends(get_ticket_service),
) -> MessageResponse:
    """Add a message to a ticket."""
    try:
        sender_id = _get_request_user_id(request_ctx)
        sender_type = "customer"
        existing = ticket_service.get_ticket(ticket_id)
        if not existing:
            raise HTTPException(status_code=404, detail=f"Ticket {ticket_id} not found")
        _require_ticket_tenant_match(existing, tenant_id)

        message_req = MessageCreate(
            content=msg_body.content,
            is_internal=msg_body.is_internal,
        )

        message = ticket_service.add_message(
            ticket_id=ticket_id,
            sender_id=sender_id,
            sender_type=sender_type,
            request=message_req,
        )

        if not message:
            raise HTTPException(status_code=404, detail=f"Ticket {ticket_id} not found")

        logger.info(
            f"Added message to ticket {ticket_id}",
            extra={
                "ticket_id": ticket_id,
                "message_id": message.message_id,
                "sender_id": sender_id,
                "sender_type": sender_type,
            },
        )

        # Outbound sync: mirror customer message to Zoho Desk
        if sender_type == "customer" and existing.zoho_ticket_id:
            sync_svc = get_sync_service()
            asyncio.create_task(
                _outbound_comment_sync(sync_svc, existing, msg_body.content)
            )

        return MessageResponse(
            message_id=message.message_id,
            ticket_id=ticket_id,
            message="Message added successfully",
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to add message to ticket {ticket_id}: {e}")
        raise HTTPException(status_code=500, detail="Failed to add message")


@router.get("/tickets/{ticket_id}/detail", response_model=TicketDetailResponse)
async def get_ticket_detail(
    request_ctx: Request,
    ticket_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    ticket_service: TicketService = Depends(get_ticket_service),
) -> TicketDetailResponse:
    """
    Get full ticket details with message history.

    Args:
        ticket_id: Ticket ID
        ticket_service: Ticket service instance

    Returns:
        Full ticket details with messages

    Raises:
        HTTPException: If ticket not found
    """
    detail = ticket_service.get_ticket_detail(ticket_id)

    if not detail:
        raise HTTPException(status_code=404, detail=f"Ticket {ticket_id} not found")
    _require_ticket_tenant_match(detail.ticket, tenant_id)

    return TicketDetailResponse(
        ticket=detail.ticket,
        messages=detail.messages,
        message="Ticket detail retrieved successfully",
    )


@router.get("/health", response_model=HealthResponse)
async def health_check() -> HealthResponse:
    """
    Health check endpoint for support tickets API.

    Returns:
        Health status
    """
    return HealthResponse(
        status="healthy",
        service="support-tickets",
        message="Support tickets API is operational",
    )


# ============================================================================
# Admin: cross-tenant ticket listing (Issue #2350)
# ============================================================================


@router.get("/admin/tickets")
async def admin_list_tickets(
    status: TicketStatus | None = Query(None, description="Filter by status"),
    tenant_id: str | None = Query(None, description="Filter by tenant"),
    category: TicketCategory | None = Query(None, description="Filter by category"),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
    ticket_service: TicketService = Depends(get_ticket_service),
    _founder: str = Depends(require_founder),
) -> dict:
    """List support tickets across all tenants (admin/Desk Inbox).

    Requires founder auth. Returns tickets with tenant_id for triage.
    """
    filters: dict = {}
    if status:
        filters["status"] = status
    if tenant_id:
        filters["tenant_id"] = tenant_id
    if category:
        filters["category"] = category

    response = ticket_service.list_tickets(
        tenant_id=tenant_id or "",
        status=status,
        limit=pagination.limit,
        offset=pagination.offset,
    )
    return {
        "tickets": response.tickets if hasattr(response, "tickets") else [],
        "total": response.total if hasattr(response, "total") else 0,
        "filters": filters,
    }

# ============================================================================
# Outbound sync helpers (fire-and-forget)
# ============================================================================


async def _outbound_create_sync(
    sync_svc: TicketSyncService,
    ticket_service: TicketService,
    ticket: SupportTicket,
    _sync_svc_param: TicketSyncService,
) -> None:
    """Mirror a newly created ticket to Zoho Desk and store the sync state."""
    from datetime import UTC, datetime as dt

    try:
        zoho_id = await sync_svc.sync_create(ticket)
        if zoho_id:
            ticket_service.update_zoho_sync_state(
                ticket_id=ticket.ticket_id,
                zoho_ticket_id=zoho_id,
                last_synced_at=dt.now(UTC).replace(tzinfo=None),
            )
    except Exception:
        logger.warning(
            "Outbound create sync failed for ticket %s",
            ticket.ticket_id,
            exc_info=True,
        )


async def _outbound_update_sync(
    sync_svc: TicketSyncService,
    ticket: SupportTicket,
) -> None:
    """Propagate a ticket update to Zoho Desk."""
    from datetime import UTC, datetime as dt
    from apps.backend.services.ticket_service import TicketService as _TS

    try:
        success = await sync_svc.sync_update(
            ticket,
            zoho_ticket_id=ticket.zoho_ticket_id or "",
        )
        if success:
            _TS().update_zoho_sync_state(
                ticket_id=ticket.ticket_id,
                last_synced_at=dt.now(UTC).replace(tzinfo=None),
            )
    except Exception:
        logger.warning(
            "Outbound update sync failed for ticket %s",
            ticket.ticket_id,
            exc_info=True,
        )


async def _outbound_comment_sync(
    sync_svc: TicketSyncService,
    ticket: SupportTicket,
    content: str,
) -> None:
    """Mirror a customer comment to Zoho Desk."""
    try:
        await sync_svc.sync_comment(
            tenant_id=ticket.tenant_id,
            zoho_ticket_id=ticket.zoho_ticket_id or "",
            content=content,
            is_public=True,
        )
    except Exception:
        logger.warning(
            "Outbound comment sync failed for ticket %s",
            ticket.ticket_id,
            exc_info=True,
        )
