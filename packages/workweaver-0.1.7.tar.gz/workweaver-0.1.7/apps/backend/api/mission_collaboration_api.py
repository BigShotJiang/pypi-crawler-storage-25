"""Collaboration endpoints for Mission Control."""

from __future__ import annotations

import asyncio
import logging

from fastapi import APIRouter, Depends, HTTPException, Query, Request

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.api.mission_collaboration_models import (
    AddReactionRequest,
    AdvanceEscalationChainsRequest,
    AdvanceEscalationChainsResponse,
    AgentStatusBoardResponse,
    AgentStatusItemResponse,
    ChannelListResponse,
    ChannelMembershipRequest,
    ChannelMessageResponse,
    ChannelMessagesResponse,
    ChannelResponse,
    CompleteCrossTeamHandoffRequest,
    CreateChannelRequest,
    CrossTeamHandoffResponse,
    EscalationChainResponse,
    EscalationDecisionResponse,
    EscalationListResponse,
    IngestPlatformEventRequest,
    MarkReadRequest,
    PlatformMappingListResponse,
    PlatformMappingResponse,
    ResolveEscalationRequest,
    RunHealthMonitorResponse,
    SendChannelMessageRequest,
    StartCrossTeamHandoffRequest,
    StartEscalationChainRequest,
    UnreadCountResponse,
    UpsertPlatformMappingRequest,
)
from apps.backend.api import mission_shared

logger = logging.getLogger(__name__)
router = APIRouter()


def _channel_response_from_item(item: dict, unread_count: int | None = None) -> ChannelResponse:
    return ChannelResponse(
        channel_id=str(item.get("channel_id", "")),
        name=str(item.get("name", "")),
        scope=str(item.get("scope", "org")),
        topic=str(item.get("topic", "")),
        member_agent_ids=list(item.get("member_agent_ids") or []),
        created_at=str(item.get("created_at", "")),
        updated_at=str(item.get("updated_at", item.get("created_at", ""))),
        unread_count=unread_count,
    )


def _channel_message_response_from_item(item: dict) -> ChannelMessageResponse:
    return ChannelMessageResponse(
        channel_id=str(item.get("channel_id", "")),
        message_id=str(item.get("message_id", "")),
        from_agent=str(item.get("from_agent", "")),
        to_agent=item.get("to_agent"),
        content=str(item.get("content", "")),
        message_type=str(item.get("message_type", "broadcast")),
        timestamp=str(item.get("timestamp", "")),
        mentions=list(item.get("mentions") or []),
        reactions=list(item.get("reactions") or []),
    )


def _platform_mapping_response_from_item(item: dict) -> PlatformMappingResponse:
    return PlatformMappingResponse(
        channel_id=str(item.get("channel_id", "")),
        platform=str(item.get("platform", "")),
        external_channel_id=str(item.get("external_channel_id", "")),
        mention_map=dict(item.get("mention_map") or {}),
        enabled=bool(item.get("enabled", False)),
        created_at=str(item.get("created_at", "")),
        updated_at=str(item.get("updated_at", item.get("created_at", ""))),
    )


@router.get("/collaboration/channels", response_model=ChannelListResponse)
async def list_collaboration_channels(
    tenant_id: str = Depends(get_verified_tenant_id),
    scope: str | None = Query(None, description="Filter by channel scope"),
    agent_id: str | None = Query(None, description="If set, include unread count for this agent"),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
):
    try:
        collab = mission_shared.get_collaboration()
        channels = await collab.ensure_default_channels(tenant_id)
        if scope:
            scope_value = str(scope).strip().lower()
            channels = [channel for channel in channels if str(channel.get("scope", "")).lower() == scope_value]
        channels, _total = paginate_items(channels, pagination)
        rows: list[ChannelResponse] = []
        for channel in channels:
            unread_count = None
            if agent_id:
                unread_count = await collab.get_unread_count(
                    tenant_id=tenant_id,
                    channel_id=str(channel.get("channel_id", "")),
                    agent_id=agent_id,
                )
            rows.append(_channel_response_from_item(channel, unread_count=unread_count))
        return ChannelListResponse(channels=rows, count=len(rows))
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to list collaboration channels: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to list channels")


@router.post("/collaboration/channels", response_model=ChannelResponse, status_code=201)
async def create_collaboration_channel(
    request: CreateChannelRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        channel = await mission_shared.get_collaboration().create_channel(
            tenant_id=tenant_id,
            name=request.name,
            scope=request.scope,
            agent_ids=request.member_agent_ids,
            topic=request.topic,
        )
        return _channel_response_from_item(channel)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to create collaboration channel: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to create channel")


@router.post("/collaboration/channels/{channel_id}/join", response_model=ChannelResponse)
async def join_collaboration_channel(
    channel_id: str,
    request: ChannelMembershipRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        channel = await mission_shared.get_collaboration().join_channel(
            tenant_id=tenant_id,
            channel_id=channel_id,
            agent_id=request.agent_id,
        )
        return _channel_response_from_item(channel)
    except KeyError:
        raise HTTPException(status_code=404, detail="Resource not found")
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to join collaboration channel: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to join channel")


@router.post("/collaboration/channels/{channel_id}/leave", response_model=ChannelResponse)
async def leave_collaboration_channel(
    channel_id: str,
    request: ChannelMembershipRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        channel = await mission_shared.get_collaboration().leave_channel(
            tenant_id=tenant_id,
            channel_id=channel_id,
            agent_id=request.agent_id,
        )
        return _channel_response_from_item(channel)
    except KeyError:
        raise HTTPException(status_code=404, detail="Resource not found")
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to leave collaboration channel: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to leave channel")


@router.get("/collaboration/channels/{channel_id}/messages", response_model=ChannelMessagesResponse)
async def list_collaboration_channel_messages(
    channel_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    agent_id: str = Query(..., min_length=1),
    since: float | None = Query(None, ge=0),
    limit: int = Query(50, ge=1, le=200),
):
    try:
        messages = await mission_shared.get_collaboration().get_channel_messages(
            tenant_id=tenant_id,
            channel_id=channel_id,
            viewer_agent=agent_id,
            since=since,
            limit=limit,
        )
        rows = [_channel_message_response_from_item(message) for message in messages]
        return ChannelMessagesResponse(channel_id=channel_id, messages=rows, count=len(rows))
    except KeyError:
        raise HTTPException(status_code=404, detail="Resource not found")
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except PermissionError:
        raise HTTPException(status_code=403, detail="Access denied")
    except Exception as exc:
        logger.error("Failed to list channel messages: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to list channel messages")


@router.post("/collaboration/channels/{channel_id}/messages", response_model=ChannelMessageResponse, status_code=201)
async def send_collaboration_channel_message(
    http_request: Request,
    channel_id: str,
    request: SendChannelMessageRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        message = await mission_shared.get_collaboration().send_to_channel(
            tenant_id=tenant_id,
            channel_id=channel_id,
            from_agent=mission_shared.resolve_human_actor(http_request, request.from_agent),
            content=request.content,
            message_type=request.message_type,
            to_agent=request.to_agent,
        )
        message["reactions"] = []
        return _channel_message_response_from_item(message)
    except PermissionError:
        raise HTTPException(status_code=403, detail="Access denied")
    except KeyError:
        raise HTTPException(status_code=404, detail="Resource not found")
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to send channel message: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to send channel message")


@router.post("/collaboration/channels/{channel_id}/reactions")
async def add_collaboration_reaction(
    channel_id: str,
    request: AddReactionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        reaction = await mission_shared.get_collaboration().add_reaction(
            tenant_id=tenant_id,
            channel_id=channel_id,
            message_id=request.message_id,
            agent_id=request.agent_id,
            emoji=request.emoji,
        )
        return {"success": True, "reaction": reaction}
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except PermissionError:
        raise HTTPException(status_code=403, detail="Access denied")
    except Exception as exc:
        logger.error("Failed to add reaction: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to add reaction")


@router.post("/collaboration/channels/{channel_id}/read")
async def mark_collaboration_channel_read(
    channel_id: str,
    request: MarkReadRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        receipt = await mission_shared.get_collaboration().mark_read(
            tenant_id=tenant_id,
            channel_id=channel_id,
            agent_id=request.agent_id,
            timestamp=request.timestamp,
        )
        return {"success": True, "receipt": receipt}
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except PermissionError:
        raise HTTPException(status_code=403, detail="Access denied")
    except Exception as exc:
        logger.error("Failed to mark channel read: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to mark channel read")


@router.get("/collaboration/channels/{channel_id}/unread", response_model=UnreadCountResponse)
async def get_collaboration_channel_unread_count(
    channel_id: str,
    agent_id: str = Query(..., min_length=1),
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        unread_count = await mission_shared.get_collaboration().get_unread_count(
            tenant_id=tenant_id,
            channel_id=channel_id,
            agent_id=agent_id,
        )
        return UnreadCountResponse(channel_id=channel_id, agent_id=agent_id, unread_count=unread_count)
    except PermissionError:
        raise HTTPException(status_code=403, detail="Access denied")
    except Exception as exc:
        logger.error("Failed to get unread count: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to get unread count")


@router.get("/collaboration/escalations", response_model=EscalationListResponse)
async def list_collaboration_escalations(
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(50, ge=1, le=200),
    agent_id: str = Query(..., min_length=1),
):
    try:
        escalations = await mission_shared.get_collaboration().list_pending_escalations(
            tenant_id=tenant_id,
            viewer_agent=agent_id,
            limit=limit,
        )
        rows = [_channel_message_response_from_item(item) for item in escalations]
        return EscalationListResponse(escalations=rows, count=len(rows))
    except PermissionError:
        raise HTTPException(status_code=403, detail="Access denied")
    except Exception as exc:
        logger.error("Failed to list escalations: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to list escalations")


@router.post("/collaboration/escalations/{message_id}/resolve", response_model=EscalationDecisionResponse)
async def resolve_collaboration_escalation(
    http_request: Request,
    message_id: str,
    request: ResolveEscalationRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        collab = mission_shared.get_collaboration()
        actor = mission_shared.resolve_human_actor(http_request, request.decided_by)
        resolution = await collab.resolve_escalation(
            tenant_id=tenant_id,
            message_id=message_id,
            decided_by=actor,
            decision=request.decision,
            reasoning=request.reasoning,
        )
        evidence_id = str(resolution.get("evidence_id", "")).strip()
        if not evidence_id:
            evidence_service = mission_shared.get_evidence_ledger()
            evidence_payload = {
                "decision_domain": "mission.escalation",
                "decision": str(resolution.get("decision", "")),
                "reasoning": str(request.reasoning or ""),
                "decided_by": str(resolution.get("decided_by", actor)),
                "message_id": message_id,
                "channel_id": str(resolution.get("channel_id", "")),
                "requesting_agent": str(resolution.get("requesting_agent", "")),
                "decision_message_id": str(resolution.get("decision_message_id", "")),
                "escalation_content": str(resolution.get("escalation_content", "")),
            }

            def _ingest_evidence() -> dict:
                return evidence_service.ingest(
                    tenant_id=tenant_id,
                    event_type="evidence:decision",
                    data=evidence_payload,
                    session_id=f"mission-escalation:{message_id}",
                    actor_path=str(resolution.get("decided_by", actor)),
                    source_event_id=message_id,
                )

            evidence_record = await asyncio.get_event_loop().run_in_executor(None, _ingest_evidence)
            evidence_id = str(evidence_record.get("evidence_id", "")).strip()
            if evidence_id:
                resolution = await collab.attach_escalation_evidence(
                    tenant_id=tenant_id,
                    message_id=message_id,
                    evidence_id=evidence_id,
                )
        return EscalationDecisionResponse(
            success=True,
            message_id=message_id,
            decision=str(resolution.get("decision", "")),
            decided_by=str(resolution.get("decided_by", "")),
            resolved_at=str(resolution.get("resolved_at", "")),
            decision_message_id=str(resolution.get("decision_message_id", "")) or None,
            evidence_id=str(resolution.get("evidence_id", evidence_id)) or None,
        )
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except PermissionError:
        raise HTTPException(status_code=403, detail="Access denied")
    except Exception as exc:
        logger.error("Failed to resolve escalation: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to resolve escalation")


@router.get("/collaboration/platforms/{platform}/mappings", response_model=PlatformMappingListResponse)
async def list_collaboration_platform_mappings(
    platform: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    channel_id: str | None = Query(None),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
):
    try:
        items = await mission_shared.get_platform_mapping_store().list_mappings(
            tenant_id=tenant_id,
            channel_id=channel_id,
            platform=platform,
        )
        rows = [_platform_mapping_response_from_item(item) for item in items]
        rows, _total = paginate_items(rows, pagination)
        return PlatformMappingListResponse(mappings=rows, count=len(rows))
    except (ValueError, KeyError):
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to list collaboration platform mappings: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to list platform mappings")


@router.put("/collaboration/platforms/{platform}/mappings/{channel_id}", response_model=PlatformMappingResponse)
async def upsert_collaboration_platform_mapping(
    platform: str,
    channel_id: str,
    request: UpsertPlatformMappingRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        item = await mission_shared.get_platform_mapping_store().upsert_mapping(
            tenant_id=tenant_id,
            channel_id=channel_id,
            platform=platform,
            external_channel_id=request.external_channel_id,
            mention_map=request.mention_map,
            enabled=request.enabled,
        )
        return _platform_mapping_response_from_item(item)
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to upsert platform mapping: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to upsert platform mapping")


@router.delete("/collaboration/platforms/{platform}/mappings/{channel_id}")
async def delete_collaboration_platform_mapping(
    platform: str,
    channel_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        await mission_shared.get_platform_mapping_store().delete_mapping(
            tenant_id=tenant_id,
            channel_id=channel_id,
            platform=platform,
        )
        return {"success": True}
    except (ValueError, KeyError):
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to delete platform mapping: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to delete platform mapping")


@router.post("/collaboration/platforms/{platform}/ingest")
async def ingest_collaboration_platform_event(
    platform: str,
    request: IngestPlatformEventRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        bridge = mission_shared.get_platform_bridge()
        normalized_platform = str(platform or "").strip().lower()
        if not bridge.has_adapter(normalized_platform):
            raise HTTPException(status_code=400, detail=f"Platform adapter not configured: {normalized_platform}")
        mappings = await mission_shared.get_platform_mapping_store().list_mappings(
            tenant_id=tenant_id,
            platform=normalized_platform,
            enabled_only=True,
        )
        if not mappings:
            raise HTTPException(status_code=404, detail="No active platform mappings for organization")

        from apps.backend.services.platform_bridge import ChannelMapping

        collab = mission_shared.get_collaboration()
        for item in mappings:
            mapping = ChannelMapping(
                tenant_id=tenant_id,
                channel_id=str(item.get("channel_id", "")),
                platform=normalized_platform,
                external_channel_id=str(item.get("external_channel_id", "")),
                mention_map=dict(item.get("mention_map") or {}),
            )
            posted = await bridge.ingest_external_to_channel(
                platform=normalized_platform,
                mapping=mapping,
                raw_event=request.raw_event,
                collaboration_service=collab,
            )
            if posted:
                return {
                    "success": True,
                    "channel_id": mapping.channel_id,
                    "message_id": str(posted.get("message_id", "")),
                }
        raise HTTPException(status_code=404, detail="No matching mapping for inbound event")
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Failed to ingest collaboration platform event: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to ingest platform event")


@router.get("/collaboration/agent-status", response_model=AgentStatusBoardResponse)
async def get_collaboration_agent_status_board(
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        nodes = mission_shared.get_store().list_nodes(tenant_id)
        rows = [
            AgentStatusItemResponse(
                agent_id=str(agent.get("node_id", "")),
                name=str(agent.get("name", "")),
                role=str((agent.get("config") or {}).get("role", "AI Employee")),
                status=str(agent.get("status", "idle")),
                parent_node_id=agent.get("parent_node_id"),
            )
            for agent in nodes
            if agent.get("node_type") == "agent"
        ]
        rows.sort(key=lambda row: row.name.lower())
        return AgentStatusBoardResponse(agents=rows, count=len(rows))
    except (ValueError, KeyError):
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to get collaboration agent status board: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to get status board")


@router.post("/collaboration/ambient/health/run", response_model=RunHealthMonitorResponse)
async def run_collaboration_health_monitor(
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        result = await mission_shared.get_ambient_monitor().run_health_monitor(tenant_id)
        return RunHealthMonitorResponse(
            tenant_id=str(result.get("tenant_id", tenant_id)),
            findings=list(result.get("findings", [])),
            message_ids=[str(value) for value in result.get("message_ids", [])],
            channel_id=str(result.get("channel_id", "")),
        )
    except (ValueError, KeyError):
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to run ambient health monitor: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to run health monitor")


@router.post("/collaboration/handoffs", response_model=CrossTeamHandoffResponse, status_code=201)
async def start_cross_team_handoff(
    http_request: Request,
    request: StartCrossTeamHandoffRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        actor = mission_shared.resolve_human_actor(http_request, request.from_agent)
        tracker = await mission_shared.get_collaboration().create_cross_team_handoff(
            tenant_id=tenant_id,
            from_agent=actor,
            target_channel_id=request.target_channel_id,
            content=request.content,
            origin_channel_id=request.origin_channel_id,
        )
        return CrossTeamHandoffResponse(
            handoff_id=str(tracker.get("handoff_id", "")),
            status=str(tracker.get("status", "pending")),
            origin_agent=str(tracker.get("origin_agent", actor)),
            target_channel_id=str(tracker.get("target_channel_id", request.target_channel_id)),
            request_message_id=str(tracker.get("request_message_id", "")),
            relay_message_id=tracker.get("relay_message_id"),
            evidence_id=tracker.get("evidence_id"),
        )
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except PermissionError:
        raise HTTPException(status_code=403, detail="Access denied")
    except KeyError:
        raise HTTPException(status_code=404, detail="Resource not found")
    except Exception as exc:
        logger.error("Failed to create cross-team handoff: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to create handoff")


@router.post("/collaboration/handoffs/{handoff_id}/complete", response_model=CrossTeamHandoffResponse)
async def complete_cross_team_handoff(
    http_request: Request,
    handoff_id: str,
    request: CompleteCrossTeamHandoffRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        collab = mission_shared.get_collaboration()
        actor = mission_shared.resolve_human_actor(http_request, request.from_agent)
        tracker = await collab.complete_cross_team_handoff(
            tenant_id=tenant_id,
            handoff_id=handoff_id,
            from_agent=actor,
            result=request.result,
        )
        evidence_payload = {
            "handoff_id": handoff_id,
            "origin_agent": str(tracker.get("origin_agent", "")),
            "completed_by": str(tracker.get("completed_by", actor)),
            "result": str(tracker.get("result", request.result)),
            "relay_message_id": str(tracker.get("relay_message_id", "")),
        }
        evidence = mission_shared.get_evidence_ledger()

        def _ingest_handoff_evidence() -> dict:
            return evidence.ingest(
                tenant_id=tenant_id,
                event_type="evidence:handoff",
                data=evidence_payload,
                session_id=f"mission-handoff:{handoff_id}",
                actor_path=str(tracker.get("completed_by", actor)),
                source_event_id=handoff_id,
            )

        evidence_record = await asyncio.get_event_loop().run_in_executor(None, _ingest_handoff_evidence)
        evidence_id = str(evidence_record.get("evidence_id", "")).strip()
        if evidence_id:
            tracker = await collab.attach_handoff_evidence(
                tenant_id=tenant_id,
                handoff_id=handoff_id,
                evidence_id=evidence_id,
            )
        return CrossTeamHandoffResponse(
            handoff_id=str(tracker.get("handoff_id", handoff_id)),
            status=str(tracker.get("status", "completed")),
            origin_agent=str(tracker.get("origin_agent", "")),
            target_channel_id=str(tracker.get("target_channel_id", "")),
            request_message_id=str(tracker.get("request_message_id", "")),
            relay_message_id=tracker.get("relay_message_id"),
            evidence_id=tracker.get("evidence_id"),
        )
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except PermissionError:
        raise HTTPException(status_code=403, detail="Access denied")
    except KeyError:
        raise HTTPException(status_code=404, detail="Resource not found")
    except Exception as exc:
        logger.error("Failed to complete cross-team handoff: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to complete handoff")


@router.post("/collaboration/escalation-chains", response_model=EscalationChainResponse, status_code=201)
async def start_escalation_chain(
    request: StartEscalationChainRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        nodes = mission_shared.get_store().list_nodes(tenant_id)
        chain = await mission_shared.get_collaboration().create_escalation_chain(
            tenant_id=tenant_id,
            source_agent=request.source_agent,
            reason=request.reason,
            resolvers=mission_shared.resolve_escalation_resolvers(nodes, request.source_agent),
            timeout_seconds=request.timeout_seconds,
        )
        return EscalationChainResponse(
            chain_id=str(chain.get("chain_id", "")),
            status=str(chain.get("status", "")),
            source_agent=str(chain.get("source_agent", request.source_agent)),
            resolver_chain=list(chain.get("resolver_chain") or []),
            current_level=int(chain.get("current_level", -1)),
            no_resolver=bool(chain.get("no_resolver", False)),
            next_escalation_at=str(chain.get("next_escalation_at", "")) or None,
        )
    except ValueError:
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to start escalation chain: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to start escalation chain")


@router.post("/collaboration/escalation-chains/advance", response_model=AdvanceEscalationChainsResponse)
async def advance_escalation_chains(
    request: AdvanceEscalationChainsRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    try:
        advanced = await mission_shared.get_collaboration().advance_escalation_chains(
            tenant_id=tenant_id,
            now_timestamp=request.now_timestamp,
        )
        rows = [
            EscalationChainResponse(
                chain_id=str(item.get("chain_id", "")),
                status=str(item.get("status", "")),
                source_agent=str(item.get("source_agent", "")),
                resolver_chain=list(item.get("resolver_chain") or []),
                current_level=int(item.get("current_level", -1)),
                no_resolver=bool(item.get("no_resolver", False)),
                next_escalation_at=str(item.get("next_escalation_at", "")) or None,
            )
            for item in advanced
        ]
        return AdvanceEscalationChainsResponse(advanced=rows, count=len(rows))
    except (ValueError, KeyError):
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.error("Failed to advance escalation chains: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to advance escalation chains")


__all__ = [
    "list_collaboration_channels",
    "create_collaboration_channel",
    "join_collaboration_channel",
    "leave_collaboration_channel",
    "list_collaboration_channel_messages",
    "send_collaboration_channel_message",
    "add_collaboration_reaction",
    "mark_collaboration_channel_read",
    "get_collaboration_channel_unread_count",
    "list_collaboration_escalations",
    "resolve_collaboration_escalation",
    "list_collaboration_platform_mappings",
    "upsert_collaboration_platform_mapping",
    "delete_collaboration_platform_mapping",
    "ingest_collaboration_platform_event",
    "get_collaboration_agent_status_board",
    "run_collaboration_health_monitor",
    "start_cross_team_handoff",
    "complete_cross_team_handoff",
    "start_escalation_chain",
    "advance_escalation_chains",
]
