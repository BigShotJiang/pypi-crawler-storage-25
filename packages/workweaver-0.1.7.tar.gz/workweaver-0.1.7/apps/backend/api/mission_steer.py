"""POST /api/v1/mission/{mission_id}/steer -- chat-steering entry point.

Canonical REST surface for dispatching :class:`CardActionKind` actions
against a mission. Tenant-scoped, idempotent, Decision-Trace-bearing.

Surface parity: REST (this file) + CLI (ww mission steer) + MCP (swarm.steer).
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_id,
)
from apps.backend.models.timeblock_card import CardActionKind
from apps.backend.utils.tenant import strip_tenant_prefix

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/mission", tags=["mission"])

_AUTHORITY_SCALAR_FIELDS = (
    "owner_member_id",
    "actor_member_id",
    "created_by_member_id",
    "member_id",
    "assignee_member_id",
    "assigned_member_id",
)
_AUTHORITY_LIST_FIELDS = (
    "authorized_member_ids",
    "allowed_member_ids",
    "member_ids",
    "participant_member_ids",
    "collaborator_member_ids",
    "owners",
)
_GENERIC_FORBIDDEN = "Steer not permitted."


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class SteerRequest(BaseModel):
    """Payload for a mission steer action."""

    action_kind: CardActionKind
    payload: dict[str, Any] = Field(default_factory=dict)
    idempotency_key: str = Field(
        ...,
        min_length=1,
        description="Client-generated dedup key. Same key within 5 min returns original result.",
    )


class SteerResponse(BaseModel):
    """Response after a successful steer dispatch."""

    action_id: str
    kind: str
    timestamp: str


# ---------------------------------------------------------------------------
# Dependency helpers
# ---------------------------------------------------------------------------


def _get_mission_contracts_service() -> Any:
    from apps.backend.services.mission_contracts import get_mission_contracts_service

    return get_mission_contracts_service()


def _get_agent_work_ledger_service() -> Any:
    from apps.backend.services.agent_work_ledger import get_agent_work_ledger_service

    return get_agent_work_ledger_service(enable_evidence=False)


def _get_store(request: Request) -> Any:
    store = getattr(request.app.state, "portable_store", None)
    if store is None:
        from apps.backend.services.timeblock_cards.steer_service import (
            create_runtime_steer_store,
        )

        store = create_runtime_steer_store()
        request.app.state.portable_store = store
    return store


def _get_card_action_service(*, store: Any | None = None, tenant_id: str = "") -> Any:
    """Indirection seam -- overridable in tests via monkeypatch."""
    from apps.backend.services.timeblock_cards.steer_service import (
        create_runtime_steer_service,
    )

    return create_runtime_steer_service(tenant_id=tenant_id, store=store)


def _normalize_tenant_id(value: str) -> str:
    return strip_tenant_prefix(str(value or "").strip())


def _member_values_from(value: Any) -> set[str]:
    if value is None:
        return set()
    if isinstance(value, str):
        text = value.strip()
        return {text} if text else set()
    if isinstance(value, dict):
        members: set[str] = set()
        for field in (*_AUTHORITY_SCALAR_FIELDS, *_AUTHORITY_LIST_FIELDS):
            members.update(_member_values_from(value.get(field)))
        return members
    if isinstance(value, (list, tuple, set)):
        members = set()
        for item in value:
            members.update(_member_values_from(item))
        return members
    return {str(value).strip()} if str(value).strip() else set()


def _mission_authorized_members(mission_state: dict[str, Any]) -> set[str]:
    members = _member_values_from(mission_state)
    for nested_key in ("metadata", "approval_context", "context", "ownership"):
        nested = mission_state.get(nested_key)
        if isinstance(nested, dict):
            members.update(_member_values_from(nested))
    return members


def _block_authorizes_member(block: Any, member_id: str) -> bool:
    member = str(member_id or "").strip()
    if not member:
        return False
    if str(getattr(block, "agent_id", "") or "").strip() == member:
        return True
    metadata = getattr(block, "metadata", {}) or {}
    if isinstance(metadata, dict) and member in _member_values_from(metadata):
        return True
    for field in ("owner_member_id", "actor_member_id", "member_id", "assigned_member_id"):
        if str(getattr(block, field, "") or "").strip() == member:
            return True
    return False


def _member_has_timeblock_authority(
    *,
    tenant_id: str,
    mission_id: str,
    member_id: str,
) -> bool:
    ledger = _get_agent_work_ledger_service()
    try:
        blocks = ledger.list_blocks(tenant_id, mission_id=mission_id, limit=50)
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "mission_steer.timeblock_authority_lookup_failed mission=%s error=%s",
            mission_id,
            type(exc).__name__,
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Mission authorization unavailable.",
        ) from exc
    return any(_block_authorizes_member(block, member_id) for block in blocks)


def authorize_mission_steer(mission_id: str, tenant_id: str, member_id: str) -> None:
    """Fail closed unless the verified caller can steer this mission."""
    mission = mission_id.strip()
    if not mission:
        raise HTTPException(status_code=400, detail="Missing mission_id.")

    verified_tenant = _normalize_tenant_id(tenant_id)
    verified_member = str(member_id or "").strip()
    if not verified_tenant or not verified_member:
        raise HTTPException(status_code=401, detail="Missing tenant or member identity.")

    contracts = _get_mission_contracts_service()
    try:
        if hasattr(contracts, "get_mission_state"):
            mission_state = contracts.get_mission_state(verified_tenant, mission)
        else:
            mission_state = contracts._get_mission_state(verified_tenant, mission)
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "mission_steer.mission_authority_lookup_failed mission=%s error=%s",
            mission,
            type(exc).__name__,
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Mission authorization unavailable.",
        ) from exc

    if mission_state is None:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=_GENERIC_FORBIDDEN)

    explicit_members = _mission_authorized_members(mission_state)
    if explicit_members:
        if verified_member in explicit_members:
            return
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=_GENERIC_FORBIDDEN)

    if _member_has_timeblock_authority(
        tenant_id=verified_tenant,
        mission_id=mission,
        member_id=verified_member,
    ):
        return

    raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=_GENERIC_FORBIDDEN)


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------


@router.post(
    "/{mission_id}/steer",
    response_model=SteerResponse,
    responses={
        403: {"description": "Cross-tenant or unauthorized steer attempt."},
        422: {"description": "Invalid CardActionKind or payload."},
    },
)
async def steer_mission(
    mission_id: str,
    body: SteerRequest,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
    member_id: str = Depends(get_verified_user_id),
) -> SteerResponse:
    """Dispatch a steer action against a mission.

    Tenant-scoped, idempotent. The ``idempotency_key`` ensures that
    re-submissions within the dedup window return the original result.
    """
    mission_id = mission_id.strip()
    tenant_id = _normalize_tenant_id(tenant_id)
    member_id = member_id.strip()

    authorize_mission_steer(mission_id, tenant_id, member_id)

    service = _get_card_action_service(store=_get_store(request), tenant_id=tenant_id)

    try:
        result = service.steer(
            mission_id=mission_id,
            tenant_id=tenant_id,
            member_id=member_id,
            action_kind=body.action_kind,
            payload=body.payload,
            idempotency_key=body.idempotency_key,
        )
    except Exception as exc:  # noqa: BLE001
        from apps.backend.services.timeblock_cards.card_action_service import (
            DecisionTraceCaptureError,
        )
        from apps.backend.services.timeblock_cards.steer_service import (
            SteerIdempotencyPendingError,
        )

        if isinstance(exc, SteerIdempotencyPendingError):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Steer request is still being processed; retry with the same idempotency key.",
            ) from exc
        if isinstance(exc, DecisionTraceCaptureError):
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail="Decision Trace capture unavailable.",
            ) from exc
        raise

    return SteerResponse(
        action_id=result["action_id"],
        kind=result["kind"],
        timestamp=result["timestamp"],
    )
