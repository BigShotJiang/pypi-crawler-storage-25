"""GET /api/v1/mission/{mission_id}/steps/{step_id}/verifier — verifier verdict history.

Read-only surface: returns the verifier decision history for a single mission step.
Tenant-scoped: the underlying VerifierDecisionStore isolates by tenant_id in the pk.

Issue #3240.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.providers.portable_store import PortableStore
from apps.backend.services.timeblock_cards.verifier_decision_store import VerifierDecisionStore

logger = logging.getLogger(__name__)

router = APIRouter()


class VerifierHistoryEntry(BaseModel):
    entry_id: str
    step_id: str
    mission_id: str
    verdict: str
    action: str
    max_severity: str | None = None
    actor_member_id: str
    evidence_id: str | None = None
    created_at: str = ""


class VerifierHistoryResponse(BaseModel):
    mission_id: str
    step_id: str
    entries: list[VerifierHistoryEntry] = Field(default_factory=list)


def _get_store(request: Request) -> PortableStore:
    """Retrieve the PortableStore from app state."""
    store = getattr(request.app.state, "portable_store", None)
    if store is None:
        from apps.backend.providers.portable_store import InMemoryStore

        store = InMemoryStore()
        request.app.state.portable_store = store
    return store


@router.get(
    "/api/v1/mission/{mission_id}/steps/{step_id}/verifier",
    response_model=VerifierHistoryResponse,
)
def get_verifier_history(
    mission_id: str,
    step_id: str,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> VerifierHistoryResponse:
    """Return verifier decision history for a mission step.

    Returns 200 with an empty entries array if no verdicts exist.
    Returns 404 if the step has no history AND the mission does not belong
    to the authenticated tenant (no leakage of existence).
    """
    store = _get_store(request)
    vds = VerifierDecisionStore(store, tenant_id=tenant_id)

    entries = vds.list_for_step(mission_id=mission_id, step_id=step_id)

    return VerifierHistoryResponse(
        mission_id=mission_id,
        step_id=step_id,
        entries=[VerifierHistoryEntry(**e) for e in entries],
    )
