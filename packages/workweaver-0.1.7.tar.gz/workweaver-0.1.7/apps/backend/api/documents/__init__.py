"""
Documents API Package.

Note: The legacy upload_router is retired (410 GONE). Only the store router
is canonical. See apps/backend/api/documents/upload.py for details.
"""

from apps.backend.api.documents.store import router as documents_store_router

__all__ = ["documents_store_router"]
