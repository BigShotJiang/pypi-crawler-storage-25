"""
Documents API

CRUD for Memory Docs tab (5th tab in /mission/memory surface).

Source: docs/PRODUCT.md#Part17.5
"""

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.pagination import PaginationParams, build_pagination_dependency
from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.schemas.error_response import safe_error_detail
from apps.backend.services.document_store import DocumentStore, DocumentStorePersistenceError

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/mission/documents", tags=["documents"])

# Singleton over durable tenant-scoped document storage
_doc_store = DocumentStore()


def _raise_document_store_error(exc: DocumentStorePersistenceError) -> None:
    raise HTTPException(
        status_code=503,
        detail={
            "error": "document_storage_unavailable",
            "detail": "Document storage is temporarily unavailable.",
            "reason": str(exc) or "document_store_unavailable",
        },
    ) from exc


class CreateDocumentRequest(BaseModel):
    title: str = Field(..., min_length=1, max_length=500)
    content_md: str = Field("", description="Markdown content")
    doc_type: str = Field("custom", description="report | analysis | playbook | meeting-notes | custom")
    visibility: str = Field("team", description="private | team | org")
    created_by: str = Field("human", description="Agent ID or 'human'")
    linked_tasks: list[str] = Field(default_factory=list)
    linked_evidence: list[str] = Field(default_factory=list)


class UpdateDocumentRequest(BaseModel):
    title: str | None = Field(None, min_length=1, max_length=500)
    content_md: str | None = None
    doc_type: str | None = None
    visibility: str | None = None
    linked_tasks: list[str] | None = None
    linked_evidence: list[str] | None = None


class DocumentResponse(BaseModel):
    doc_id: str
    tenant_id: str
    title: str
    doc_type: str
    content_md: str
    linked_tasks: list[str]
    linked_evidence: list[str]
    visibility: str
    created_by: str
    created_at: str
    updated_at: str


@router.get("/list", response_model=list[DocumentResponse], include_in_schema=False)
@router.get("", response_model=list[DocumentResponse])
async def list_documents(
    doc_type: str | None = Query(None),
    visibility: str | None = Query(None),
    created_by: str | None = Query(None),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[dict[str, Any]]:
    """List documents with optional filters."""
    try:
        return _doc_store.list_docs(
            tenant_id,
            doc_type,
            visibility,
            created_by,
            pagination.limit,
            pagination.offset,
        )
    except DocumentStorePersistenceError as exc:
        _raise_document_store_error(exc)


@router.post("", response_model=DocumentResponse, status_code=201)
async def create_document(
    req: CreateDocumentRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Create a new document."""
    try:
        return _doc_store.create(
            tenant_id=tenant_id,
            title=req.title,
            content_md=req.content_md,
            doc_type=req.doc_type,
            visibility=req.visibility,
            created_by=req.created_by,
            linked_tasks=req.linked_tasks,
            linked_evidence=req.linked_evidence,
        )
    except DocumentStorePersistenceError as exc:
        _raise_document_store_error(exc)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))


@router.get("/search")
async def search_documents(
    q: str = Query(..., min_length=1),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=20, max_limit=100)),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[dict[str, Any]]:
    """Search documents by title and content."""
    try:
        return _doc_store.search(tenant_id, q, pagination.limit)
    except DocumentStorePersistenceError as exc:
        _raise_document_store_error(exc)


@router.get("/{doc_id}", response_model=DocumentResponse)
async def get_document(
    doc_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Get a single document."""
    try:
        doc = _doc_store.get(tenant_id, doc_id)
    except DocumentStorePersistenceError as exc:
        _raise_document_store_error(exc)
    if not doc:
        raise HTTPException(status_code=404, detail=f"Document {doc_id} not found")
    return doc


@router.patch("/{doc_id}", response_model=DocumentResponse)
async def update_document(
    doc_id: str,
    req: UpdateDocumentRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Update a document."""
    updates = req.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")
    try:
        doc = _doc_store.update(tenant_id, doc_id, updates)
    except DocumentStorePersistenceError as exc:
        _raise_document_store_error(exc)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    if not doc:
        raise HTTPException(status_code=404, detail=f"Document {doc_id} not found")
    return doc


@router.delete("/{doc_id}")
async def delete_document(
    doc_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, str]:
    """Delete a document."""
    try:
        deleted = _doc_store.delete(tenant_id, doc_id)
    except DocumentStorePersistenceError as exc:
        _raise_document_store_error(exc)
    if not deleted:
        raise HTTPException(status_code=404, detail=f"Document {doc_id} not found")
    return {"status": "deleted", "doc_id": doc_id}
