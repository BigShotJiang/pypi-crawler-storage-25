"""Retired legacy document-upload router.

This module is intentionally kept importable so older package imports do not
break, but the former `/api/v1/documents/upload` flow is no longer mounted.

Canonical paths now are:
- `/api/v1/memory/import` for generic WorkMemory-backed file ingestion
- `/api/v1/mission/documents` for durable document records in the dashboard
"""

from fastapi import APIRouter, HTTPException, status

router = APIRouter(prefix="/api/v1/documents", tags=["documents"])


@router.post("/upload", include_in_schema=False)
async def retired_documents_upload() -> None:
    """Fail closed if this retired router is mounted by mistake."""
    raise HTTPException(
        status_code=status.HTTP_410_GONE,
        detail=(
            "Legacy /api/v1/documents/upload is retired. "
            "Use /api/v1/memory/import for file ingest or /api/v1/mission/documents for document records."
        ),
    )
