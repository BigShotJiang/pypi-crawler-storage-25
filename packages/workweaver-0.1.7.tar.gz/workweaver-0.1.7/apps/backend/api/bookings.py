"""
Bookings API

Booking page management (authenticated) + public availability/booking endpoints.

Source: docs/PRODUCT.md#Part18.1
"""

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.scheduling.calendar_service import CalendarService
from apps.backend.services.booking_service import BookingPersistenceError, BookingService

logger = logging.getLogger(__name__)

router = APIRouter(tags=["bookings"])

_calendar_service = CalendarService()
_booking_svc = BookingService(calendar_svc=_calendar_service)


# --- Models ---


class CreatePageRequest(BaseModel):
    title: str = Field(..., min_length=1, max_length=200)
    slug: str = Field(..., min_length=1, max_length=100, pattern="^[a-z0-9-]+$")
    duration_minutes: int = Field(30, ge=15, le=120)
    buffer_minutes: int = Field(15, ge=0, le=60)
    daily_limit: int = Field(8, ge=1, le=20)
    working_hours_start: str = Field("09:00")
    working_hours_end: str = Field("17:00")
    description: str = Field("")


class UpdatePageRequest(BaseModel):
    title: str | None = Field(None, min_length=1, max_length=200)
    slug: str | None = Field(None, min_length=1, max_length=100)
    duration_minutes: int | None = Field(None, ge=15, le=120)
    buffer_minutes: int | None = Field(None, ge=0, le=60)
    daily_limit: int | None = Field(None, ge=1, le=20)
    working_hours_start: str | None = None
    working_hours_end: str | None = None
    description: str | None = None
    active: bool | None = None


class BookSlotRequest(BaseModel):
    date: str = Field(..., description="YYYY-MM-DD")
    start_time: str = Field(..., description="HH:MM")
    end_time: str = Field(..., description="HH:MM")
    guest_name: str = Field(..., min_length=1)
    guest_email: str = Field(..., min_length=3)
    notes: str = Field("")
    thread_id: str | None = Field(default=None)
    entity_id: str | None = Field(default=None)
    workitem_id: str | None = Field(default=None)
# --- Authenticated Endpoints (manage booking pages) ---


@router.get("/api/v1/mission/bookings/pages")
async def list_pages(
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(100, ge=1, le=500, description="Max pages to return"),
) -> list[dict[str, Any]]:
    """List all booking pages."""
    try:
        return _booking_svc.list_pages(tenant_id)[:limit]
    except BookingPersistenceError as exc:
        logger.error("Booking persistence error: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Service temporarily unavailable") from exc


@router.post("/api/v1/mission/bookings/pages", status_code=201)
async def create_page(
    req: CreatePageRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Create a new booking page."""
    try:
        return _booking_svc.create_page(
            tenant_id=tenant_id,
            title=req.title,
            slug=req.slug,
            duration_minutes=req.duration_minutes,
            buffer_minutes=req.buffer_minutes,
            daily_limit=req.daily_limit,
            working_hours_start=req.working_hours_start,
            working_hours_end=req.working_hours_end,
            description=req.description,
        )
    except BookingPersistenceError as exc:
        logger.error("Booking persistence error: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Service temporarily unavailable") from exc


@router.patch("/api/v1/mission/bookings/pages/{page_id}")
async def update_page(
    page_id: str,
    req: UpdatePageRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Update a booking page."""
    updates = req.model_dump(exclude_none=True)
    if not updates:
        raise HTTPException(status_code=400, detail="No fields to update")
    try:
        page = _booking_svc.update_page(tenant_id, page_id, updates)
        if not page:
            raise HTTPException(status_code=404, detail="Booking page not found")
        return page
    except BookingPersistenceError as exc:
        logger.error("Booking persistence error: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Service temporarily unavailable") from exc


@router.delete("/api/v1/mission/bookings/pages/{page_id}")
async def delete_page(
    page_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, str]:
    """Delete a booking page."""
    try:
        if not _booking_svc.delete_page(tenant_id, page_id):
            raise HTTPException(status_code=404, detail="Booking page not found")
        return {"status": "deleted", "page_id": page_id}
    except BookingPersistenceError as exc:
        logger.error("Booking persistence error: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Service temporarily unavailable") from exc


@router.get("/api/v1/mission/bookings/upcoming")
async def list_upcoming_bookings(
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(100, ge=1, le=500, description="Max bookings to return"),
) -> list[dict[str, Any]]:
    """List upcoming bookings."""
    try:
        return _booking_svc.list_bookings(tenant_id, upcoming_only=True)[:limit]
    except BookingPersistenceError as exc:
        logger.error("Booking persistence error: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Service temporarily unavailable") from exc


# --- Public Endpoints (no auth required) ---


@router.get("/api/v1/bookings/{org_slug}/{page_slug}/availability")
async def get_availability(
    org_slug: str,
    page_slug: str,
    date: str = Query(..., description="YYYY-MM-DD"),
) -> dict[str, Any]:
    """Get available slots for a booking page (public)."""
    try:
        page = _booking_svc.get_page_by_slug(org_slug, page_slug)
        if not page:
            raise HTTPException(status_code=404, detail="Booking page not found")
        slots = _booking_svc.get_availability(page["page_id"], date)
        return {
            "page_title": page["title"],
            "date": date,
            "duration_minutes": page["duration_minutes"],
            "slots": slots,
        }
    except BookingPersistenceError as exc:
        logger.error("Booking persistence error: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Service temporarily unavailable") from exc


@router.post("/api/v1/bookings/{org_slug}/{page_slug}/book")
async def book_slot(
    org_slug: str,
    page_slug: str,
    req: BookSlotRequest,
) -> dict[str, Any]:
    """Book an available slot (public)."""
    try:
        page = _booking_svc.get_page_by_slug(org_slug, page_slug)
        if not page:
            raise HTTPException(status_code=404, detail="Booking page not found")
        booking = _booking_svc.create_booking(
            page_id=page["page_id"],
            date=req.date,
            start_time=req.start_time,
            end_time=req.end_time,
            guest_name=req.guest_name,
            guest_email=req.guest_email,
            notes=req.notes,
            thread_id=req.thread_id,
            entity_id=req.entity_id,
            workitem_id=req.workitem_id,
        )
        return booking
    except ValueError as exc:
        logger.error("Invalid booking request: %s", exc, exc_info=True)
        raise HTTPException(status_code=400, detail="Invalid request parameters") from exc
    except BookingPersistenceError as exc:
        logger.error("Booking persistence error: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Service temporarily unavailable") from exc
