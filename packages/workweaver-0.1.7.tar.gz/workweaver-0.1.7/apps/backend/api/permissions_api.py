"""Canonical Permissions API endpoints.

Provides REST API for managing workspace permissions using canonical
terminology (permission, workspace, owner, member) per PRODUCT-CONTEXT.md
section 4.

Routes:
  GET  /api/v1/permissions                           -- list permissions for an entity
  GET  /api/v1/permissions/readiness                  -- permission readiness probe states
  POST /api/v1/permissions/{permission_id}/toggle     -- enable/disable a permission
  GET  /api/v1/permissions/templates                  -- list role templates
  POST /api/v1/permissions/templates/{role_name}/apply -- apply a template
  GET  /api/v1/permissions/limitations                -- query provider limitations
  GET  /api/v1/permissions/{permission_id}/setup-status -- setup status
  POST /api/v1/permissions/{permission_id}/setup      -- submit setup answers
  DELETE /api/v1/permissions/{permission_id}/setup    -- disconnect/reset setup

Legacy route: /api/v1/capabilities (retained with deprecation header).
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Path, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_id,
    require_admin_user_role,
)
from apps.backend.models.user import UserRole
from apps.backend.services.admin.admin_permission import (
    AdminPermission,
    AdminPermissionCheck,
    AdminRole,
    check_permission,
)
from apps.backend.services.capability_service import (
    CapabilityNotFoundError,
    get_capability_service,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/permissions", tags=["permissions"])

DEPRECATION_HEADER = "X-Deprecated-Api"
DEPRECATION_MESSAGE = "Use /api/v1/permissions instead of /api/v1/capabilities"


def _require_permission_write(
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    admin_role: UserRole = Depends(require_admin_user_role),
) -> AdminPermissionCheck:
    del admin_role
    result = check_permission(
        role=AdminRole.TENANT_ADMIN,
        permission=AdminPermission.CAPABILITIES_WRITE,
        actor_id=user_id,
        target_tenant_ids=(tenant_id,),
        actor_tenant_id=tenant_id,
    )
    if not result.allowed:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=result.reason or "Permission denied",
        )
    return result


_PERMISSION_WRITE_DEPENDENCIES = [
    Depends(require_admin_user_role),
    Depends(_require_permission_write),
]


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class TogglePermissionBody(BaseModel):
    """Request body for toggling a permission."""

    entity_id: str = Field(..., min_length=1, description="AI entity ID")
    enabled: bool = Field(..., description="True to enable, False to disable")


class ApplyTemplateBody(BaseModel):
    """Request body for applying a role template."""

    entity_id: str = Field(..., min_length=1, description="AI entity ID")


class SetupQuestionResponse(BaseModel):
    """A single setup question."""

    id: str
    label: str
    type: str
    options: list[str] | None = None


class SetupStatusResponse(BaseModel):
    """Response for setup status check."""

    permission_id: str = Field(..., description="Permission identifier")
    status: str
    required_integrations: list[str] = Field(default_factory=list)
    questions: list[SetupQuestionResponse] = Field(default_factory=list)
    config: dict[str, Any] = Field(default_factory=dict)


class SetupSubmitRequest(BaseModel):
    """Request body for submitting setup answers."""

    entity_id: str = Field(..., description="Entity (agent) to configure")
    answers: dict[str, Any] = Field(..., description="Setup answers keyed by question ID")


class SetupSubmitResponse(BaseModel):
    """Response after setup submission."""

    permission_id: str = Field(..., description="Permission identifier")
    status: str
    config: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("")
async def list_permissions(
    entity_id: str = Query(..., min_length=1, description="AI entity ID"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[dict[str, Any]]:
    """List all available permissions with per-entity enabled/disabled state.

    Returns permission metadata suitable for workspace-facing UI.
    Internal skill IDs are never included.
    """
    svc = get_capability_service()
    caps = svc.list_capabilities(tenant_id=tenant_id, entity_id=entity_id)
    return [c.to_tenant_dict() for c in caps]


@router.get("/readiness")
async def get_permission_readiness(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return permission readiness states from the agent_awareness namespace.

    Lists all probed permissions with their current readiness level,
    last probe timestamp, and degraded-since metadata when applicable.
    """
    from apps.backend.workmemory.agent_awareness_store import AgentAwarenessStore
    from apps.backend.providers.portable_store import create_portable_store

    store = AgentAwarenessStore(store=create_portable_store())
    capabilities = store.get_awareness(tenant_id)
    return {
        "workspace_id": tenant_id,
        "permissions": capabilities,
        "total": len(capabilities),
    }


@router.post("/{permission_id}/toggle", dependencies=_PERMISSION_WRITE_DEPENDENCIES)
async def toggle_permission(
    permission_id: str,
    body: TogglePermissionBody,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Enable or disable a single permission for an entity."""
    svc = get_capability_service()
    try:
        return svc.toggle_capability(
            tenant_id=tenant_id,
            entity_id=body.entity_id,
            capability_id=permission_id,
            enabled=body.enabled,
        )
    except CapabilityNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Permission not found: {permission_id}",
        )


@router.get("/templates")
async def list_templates(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """List all available role templates with their permission sets."""
    svc = get_capability_service()
    return svc.list_role_templates()


@router.get("/limitations")
async def get_limitations(
    provider: str = Query(..., min_length=1, description="Connector provider ID (e.g. hubspot, salesforce)"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[dict[str, Any]]:
    """Query limitations for a specific connected provider.

    Returns known limitations including rate limits, auth scope restrictions,
    data access gaps, and feature gaps.
    """
    from apps.backend.dependencies import get_capability_manifest_service

    manifest_svc = get_capability_manifest_service()
    limitations = manifest_svc.get_connector_limits(tenant_id, provider=provider)
    return [
        {
            "provider": lim.provider,
            "limitation_type": lim.limitation_type,
            "description": lim.description,
            "workaround": lim.workaround,
        }
        for lim in limitations
    ]


@router.post("/templates/{role_name}/apply", dependencies=_PERMISSION_WRITE_DEPENDENCIES)
async def apply_template(
    role_name: str,
    body: ApplyTemplateBody,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Apply a role template to an entity, bulk-enabling its permissions."""
    svc = get_capability_service()
    try:
        return svc.apply_role_template(
            tenant_id=tenant_id,
            entity_id=body.entity_id,
            role_name=role_name,
        )
    except ValueError as exc:
        logger.error("Permission template application failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid request parameters",
        )


@router.get(
    "/{permission_id}/setup-status",
    response_model=SetupStatusResponse,
    status_code=status.HTTP_200_OK,
    summary="Get permission setup status",
)
async def get_setup_status(
    permission_id: str = Path(..., description="Permission identifier"),
    entity_id: str = Query(..., description="Entity (agent) identifier"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SetupStatusResponse:
    """Check whether a permission is configured for the entity.

    Returns required integrations and setup questions if not yet configured.
    """
    from apps.backend.services.capability_setup_service import get_capability_setup_service

    svc = get_capability_setup_service()
    result = svc.get_setup_status(tenant_id, entity_id, permission_id)

    status_str = result["status"]
    if hasattr(status_str, "value"):
        status_str = status_str.value

    questions = [SetupQuestionResponse(**q) for q in result.get("questions", [])]

    return SetupStatusResponse(
        permission_id=result["capability_id"],
        status=status_str,
        required_integrations=result.get("required_integrations", []),
        questions=questions,
        config=result.get("config", {}),
    )


@router.post(
    "/{permission_id}/setup",
    response_model=SetupSubmitResponse,
    status_code=status.HTTP_200_OK,
    summary="Submit permission setup",
    dependencies=_PERMISSION_WRITE_DEPENDENCIES,
)
async def submit_setup(
    permission_id: str = Path(..., description="Permission identifier"),
    body: SetupSubmitRequest = ...,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SetupSubmitResponse:
    """Submit setup answers for a permission.

    Stores the configuration in entity-scoped DynamoDB settings.
    """
    from apps.backend.services.capability_setup_service import get_capability_setup_service

    svc = get_capability_setup_service()
    result = svc.submit_setup(tenant_id, body.entity_id, permission_id, body.answers)

    status_str = result["status"]
    if hasattr(status_str, "value"):
        status_str = status_str.value

    return SetupSubmitResponse(
        permission_id=result["capability_id"],
        status=status_str,
        config=result.get("config", {}),
    )


@router.delete(
    "/{permission_id}/setup",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Disconnect / reset permission setup",
    response_model=None,
    dependencies=_PERMISSION_WRITE_DEPENDENCIES,
)
async def reset_setup(
    permission_id: str = Path(..., description="Permission identifier"),
    entity_id: str = Query(..., description="Entity (agent) identifier"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> None:
    """Remove a permission setup configuration for an entity.

    Reverts the permission to not-started state, effectively disconnecting
    the service from this entity. Credential vault entries are not touched.
    """
    from apps.backend.services.capability_setup_service import get_capability_setup_service

    svc = get_capability_setup_service()
    svc.reset_setup(tenant_id, entity_id, permission_id)
