"""Tasks API (Part 17) - Task and pipeline management endpoints."""

import logging
from typing import Literal

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Response
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.api.work_items import WorkItemResponse
from apps.backend.services.tenant_quota_service import QuotaDecision, TenantQuotaService, get_tenant_quota_service
from apps.backend.services.task_store import TaskStoreUnavailable

router = APIRouter(prefix="/api/v1/mission/tasks", tags=["tasks"])

TaskStatus = Literal["recurring", "backlog", "in_progress", "review", "done", "blocked"]
TASK_STATUS_DESCRIPTION = "Initial status (recurring|backlog|in_progress|review|done|blocked)"
TASK_PRIORITY_DESCRIPTION = "Priority level (urgent|high|medium|low)"


# Request Models
class TaskAttachment(BaseModel):
    """Structured task attachment metadata."""

    filename: str = Field(..., min_length=1, max_length=500)
    content_type: str = Field(..., min_length=1, max_length=200)
    size_bytes: int = Field(..., ge=0)
    detected_content_type: str = Field(..., min_length=1, max_length=50)
    processing_status: str = Field(..., min_length=1, max_length=32)
    source_type: str = Field("task_attachment", min_length=1, max_length=100)
    item_ids: list[str] = Field(default_factory=list)
    warnings: list[str] = Field(default_factory=list)
    omissions: list[str] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)
    resource_ref: str | None = Field(None, max_length=100)


class CreateTaskRequest(BaseModel):
    """Request to create a new task."""

    title: str = Field(..., max_length=200, description="Task title")
    description: str = Field("", max_length=5000, description="Task description")
    assigned_agent: str | None = Field(None, max_length=100, description="Agent ID to assign task to")
    status: TaskStatus = Field("backlog", description=TASK_STATUS_DESCRIPTION)
    priority: str = Field("medium", max_length=50, description=TASK_PRIORITY_DESCRIPTION)
    schedule: str | None = Field(None, max_length=200, description="Cron-like schedule for recurring tasks")
    due_date: str | None = Field(None, description="Due date in ISO format")
    tags: list[str] = Field(default_factory=list, description="Tags for categorization")
    attachments: list[TaskAttachment] = Field(default_factory=list, description="WorkMemory-backed task attachments")


class UpdateTaskRequest(BaseModel):
    """Request to update an existing task."""

    title: str | None = Field(None, max_length=200, description="Updated title")
    description: str | None = Field(None, max_length=5000, description="Updated description")
    assigned_agent: str | None = Field(None, max_length=100, description="Updated agent assignment")
    status: TaskStatus | None = Field(None, description="Updated status")
    priority: str | None = Field(None, max_length=50, description="Updated priority")
    schedule: str | None = Field(None, max_length=200, description="Updated schedule")
    due_date: str | None = Field(None, description="Updated due date")
    tags: list[str] | None = Field(None, description="Updated tags")
    attachments: list[TaskAttachment] | None = Field(None, description="Updated attachment list")
    revision: int = Field(..., description="Current revision for optimistic locking")


class MoveTaskRequest(BaseModel):
    """Request to move task to new status."""

    status: TaskStatus = Field(..., description="New status")
    revision: int = Field(..., description="Current revision for optimistic locking")


class CreatePipelineRequest(BaseModel):
    """Request to create a new pipeline."""

    name: str = Field(..., max_length=200, description="Pipeline name")
    columns: list[str] = Field(..., description="List of column/status names")


class UpdatePipelineRequest(BaseModel):
    """Request to update a pipeline."""

    name: str | None = Field(None, max_length=200, description="Updated name")
    columns: list[str] | None = Field(None, description="Updated columns")
    revision: int = Field(..., description="Current revision for optimistic locking")


# Response Models
class TaskResponse(BaseModel):
    """Response for a single task."""

    task_id: str
    title: str
    description: str
    assigned_agent: str | None
    status: TaskStatus
    priority: str
    schedule: str | None
    due_date: str | None
    tags: list[str]
    attachments: list[TaskAttachment]
    created_at: str
    updated_at: str
    revision: int


class TaskListResponse(BaseModel):
    """Response for list of tasks."""

    tasks: list[TaskResponse]
    count: int


class PipelineResponse(BaseModel):
    """Response for a single pipeline."""

    pipeline_id: str
    name: str
    columns: list[str]
    created_at: str
    updated_at: str
    revision: int


class PipelineListResponse(BaseModel):
    """Response for list of pipelines."""

    pipelines: list[PipelineResponse]
    count: int


# Lazy import helpers
def _get_store():
    """Lazy import task store to avoid circular dependencies."""
    from apps.backend.services.task_store import get_task_store

    return get_task_store()


def _get_batch_orchestrator():
    """Lazy import batch orchestrator to avoid circular dependencies."""
    from apps.backend.services.batch_orchestrator import get_batch_orchestrator

    return get_batch_orchestrator()


def _get_workitem_service():
    from apps.backend.services.execution.workitem_service import get_workitem_service

    return get_workitem_service()


def _get_quota_service() -> TenantQuotaService:
    return get_tenant_quota_service()


def _raise_quota_error(decision: QuotaDecision) -> None:
    if decision.reason == "upload_bytes_limit_exceeded":
        raise HTTPException(status_code=413, detail=decision.reason)
    if decision.reason == "task_attachment_limit_exceeded":
        raise HTTPException(status_code=422, detail=decision.reason)
    if decision.reason in {"quota_unavailable", "storage_limit_unavailable", "tenant_storage_limit_exceeded"}:
        raise HTTPException(status_code=429, detail=decision.reason)
    raise HTTPException(status_code=422, detail=decision.reason)


def _attachment_size_bytes(attachments: list[TaskAttachment]) -> int:
    return sum(max(0, int(attachment.size_bytes or 0)) for attachment in attachments)


def _check_task_attachment_quota(
    quota: TenantQuotaService,
    *,
    tenant_id: str,
    attachments: list[TaskAttachment],
) -> None:
    if not attachments:
        return

    attachment_decision = quota.check_task_attachment_count(
        tenant_id=tenant_id,
        attachment_count=len(attachments),
    )
    if not attachment_decision.allowed:
        _raise_quota_error(attachment_decision)

    total_attachment_bytes = _attachment_size_bytes(attachments)
    if total_attachment_bytes > 0:
        storage_decision = quota.check_upload(tenant_id=tenant_id, size_bytes=total_attachment_bytes)
        if not storage_decision.allowed:
            _raise_quota_error(storage_decision)


def _task_store_unavailable_error() -> HTTPException:
    return HTTPException(status_code=503, detail="task_store_unavailable")


@router.post("/", response_model=TaskResponse, status_code=201)
async def create_task(
    request: CreateTaskRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    x_idempotency_key: str | None = Header(default=None, alias="x-idempotency-key"),
    workitems=Depends(_get_workitem_service),
):
    """Create a new task."""
    try:
        store = _get_store()
        idempotency_key = str(x_idempotency_key or "").replace("\x00", "").strip() or None
        quota = _get_quota_service()
        _check_task_attachment_quota(
            quota,
            tenant_id=tenant_id,
            attachments=request.attachments,
        )

        item = await workitems.create_work_item(
            tenant_id=tenant_id,
            payload={
                "source_kind": "task",
                "title": request.title,
                "description": request.description,
                "assigned_agent": request.assigned_agent,
                "status": workitems.unified_status_from_task(request.status),
                "priority": request.priority,
                "recurrence_cron": request.schedule,
                "due_date": request.due_date,
                "tags": request.tags,
                "attachments": [attachment.model_dump() for attachment in request.attachments],
            },
            goal_store=None,
            task_store=store,
            idempotency_key=idempotency_key,
        )
        return TaskResponse(**workitems.legacy_task_payload(item))

    except ValueError as e:
        logger.warning("create_task validation error: %s", e)
        raise HTTPException(status_code=400, detail="Invalid task data")
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to create task")


@router.get("/", response_model=TaskListResponse)
async def list_tasks(
    tenant_id: str = Depends(get_verified_tenant_id),
    status: TaskStatus | None = Query(None, description=TASK_STATUS_DESCRIPTION),
    agent_id: str | None = Query(None, description="Filter by assigned agent"),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
):
    """List tasks with optional filters."""
    try:
        store = _get_store()

        tasks = store.list_tasks(
            tenant_id=tenant_id,
            status=status,
            agent_id=agent_id,
            limit=pagination.offset + pagination.limit,
        )

        paged_tasks, _total = paginate_items(tasks, pagination)
        task_responses = [
            TaskResponse(
                task_id=t["task_id"],
                title=t["title"],
                description=t.get("description", ""),
                assigned_agent=t.get("assigned_agent"),
                status=t["status"],
                priority=t["priority"],
                schedule=t.get("schedule"),
                due_date=t.get("due_date"),
                tags=t.get("tags", []),
                attachments=t.get("attachments", []),
                created_at=t["created_at"],
                updated_at=t["updated_at"],
                revision=t["revision"],
            )
            for t in paged_tasks
        ]

        return TaskListResponse(tasks=task_responses, count=len(task_responses))

    except TaskStoreUnavailable as exc:
        logger.error("Task store unavailable while listing tasks: %s", exc)
        raise _task_store_unavailable_error() from exc
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to list tasks")


@router.get("/{task_id}", response_model=WorkItemResponse)
async def get_task(
    task_id: str,
    response: Response,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Get a single task by ID."""
    try:
        store = _get_store()
        from apps.backend.api.goals import _get_goal_store
        from apps.backend.services.execution.workitem_service import get_workitem_service

        try:
            goal_store = _get_goal_store()
        except Exception:
            goal_store = None

        task = get_workitem_service().get_work_item(
            tenant_id=tenant_id,
            item_id=task_id,
            source_kind="task",
            goal_store=goal_store,
            task_store=store,
        )

        if not task:
            raise HTTPException(status_code=404, detail=f"Task {task_id} not found")

        response.headers["X-Deprecated"] = f"use /api/v1/work-items/{task_id}"
        return WorkItemResponse(**task)

    except TaskStoreUnavailable as exc:
        logger.error("Task store unavailable while reading task %s: %s", task_id, exc)
        raise _task_store_unavailable_error() from exc
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to get task")


@router.patch("/{task_id}", response_model=TaskResponse)
async def update_task(
    task_id: str,
    request: UpdateTaskRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    workitems=Depends(_get_workitem_service),
):
    """Update an existing task."""
    try:
        store = _get_store()
        quota = _get_quota_service()

        payload = {"revision": request.revision}
        fields_set: set[str] = set()
        if request.title is not None:
            payload["title"] = request.title
            fields_set.add("title")
        if request.description is not None:
            payload["description"] = request.description
            fields_set.add("description")
        if request.assigned_agent is not None:
            payload["assigned_agent"] = request.assigned_agent
            fields_set.add("assigned_agent")
        if request.status is not None:
            payload["status"] = workitems.unified_status_from_task(request.status)
            fields_set.add("status")
        if request.priority is not None:
            payload["priority"] = request.priority
            fields_set.add("priority")
        if request.schedule is not None:
            payload["recurrence_cron"] = request.schedule
            fields_set.add("recurrence_cron")
        if request.due_date is not None:
            payload["due_date"] = request.due_date
            fields_set.add("due_date")
        if request.tags is not None:
            payload["tags"] = request.tags
            fields_set.add("tags")
        if request.attachments is not None:
            _check_task_attachment_quota(
                quota,
                tenant_id=tenant_id,
                attachments=request.attachments,
            )
            payload["attachments"] = [attachment.model_dump() for attachment in request.attachments]
            fields_set.add("attachments")

        item = workitems.update_work_item(
            tenant_id=tenant_id,
            item_id=task_id,
            payload=payload,
            fields_set=fields_set,
            source_kind="task",
            goal_store=None,
            task_store=store,
        )
        return TaskResponse(**workitems.legacy_task_payload(item))

    except ValueError as e:
        logger.warning("update_task validation error: %s", e)
        # Check if it's a revision mismatch
        if "Revision mismatch" in str(e):
            raise HTTPException(status_code=409, detail="Task revision conflict")
        raise HTTPException(status_code=400, detail="Invalid task data")
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to update task")


@router.delete("/{task_id}", status_code=204)
async def delete_task(
    task_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    workitems=Depends(_get_workitem_service),
):
    """Delete a task."""
    try:
        store = _get_store()
        workitems.delete_work_item(
            tenant_id=tenant_id,
            item_id=task_id,
            source_kind="task",
            goal_store=None,
            task_store=store,
        )
        return None

    except ValueError as e:
        logger.warning("delete_task not found: %s", e)
        raise HTTPException(status_code=404, detail="Task not found")
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to delete task")


@router.post("/{task_id}/run")
async def run_task(
    task_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Queue a task for execution via BatchOrchestrator."""
    try:
        store = _get_store()
        task = store.get_task(tenant_id, task_id)

        if not task:
            raise HTTPException(status_code=404, detail=f"Task {task_id} not found")

        # Delegate to BatchOrchestrator for real execution
        orchestrator = _get_batch_orchestrator()
        job = await orchestrator.submit_job(
            tenant_id=tenant_id,
            name=task["title"],
            actions=[
                {
                    "action_type": "skill_execute",
                    "skill_id": "task_execute",
                    "name": task["title"],
                    "input_data": {
                        "task_id": task_id,
                        "description": task.get("description", ""),
                        "assigned_agent": task.get("assigned_agent"),
                        "priority": task.get("priority", "medium"),
                        "tags": task.get("tags", []),
                        "attachments": task.get("attachments", []),
                    },
                }
            ],
            source="task_run",
            submitted_by=task.get("assigned_agent"),
        )

        # Update task status to in_progress — must stay synchronized with queue state
        try:
            store.update_task(
                tenant_id=tenant_id,
                task_id=task_id,
                updates={"status": "in_progress"},
                revision=task["revision"],
            )
        except Exception as exc:
            logger.error(
                "Task status update failed after job queued: task_id=%s job_id=%s error=%s",
                task_id,
                job.job_id,
                exc,
            )
            raise HTTPException(
                status_code=500,
                detail=f"Job queued (job_id={job.job_id}) but task status update failed — state desynchronized",
            )

        return {
            "task_id": task_id,
            "job_id": job.job_id,
            "status": job.status.value,
            "message": "Task queued for execution",
        }

    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to run task")


@router.get("/pipelines/", response_model=PipelineListResponse)
async def list_pipelines(
    tenant_id: str = Depends(get_verified_tenant_id),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=100, max_limit=500)),
):
    """List all pipelines."""
    try:
        store = _get_store()
        pipelines, _total = paginate_items(store.list_pipelines(tenant_id), pagination)

        # Convert to response models
        pipeline_responses = [
            PipelineResponse(
                pipeline_id=p["pipeline_id"],
                name=p["name"],
                columns=p["columns"],
                created_at=p["created_at"],
                updated_at=p["updated_at"],
                revision=p["revision"],
            )
            for p in pipelines
        ]

        return PipelineListResponse(pipelines=pipeline_responses, count=len(pipeline_responses))

    except Exception:
        raise HTTPException(status_code=500, detail="Failed to list pipelines")


@router.post("/pipelines/", response_model=PipelineResponse, status_code=201)
async def create_pipeline(
    request: CreatePipelineRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Create a new pipeline."""
    try:
        store = _get_store()

        pipeline = store.create_pipeline(
            tenant_id=tenant_id,
            name=request.name,
            columns=request.columns,
        )

        return PipelineResponse(
            pipeline_id=pipeline["pipeline_id"],
            name=pipeline["name"],
            columns=pipeline["columns"],
            created_at=pipeline["created_at"],
            updated_at=pipeline["updated_at"],
            revision=pipeline["revision"],
        )

    except Exception:
        raise HTTPException(status_code=500, detail="Failed to create pipeline")


@router.patch("/pipelines/{pipeline_id}", response_model=PipelineResponse)
async def update_pipeline(
    pipeline_id: str,
    request: UpdatePipelineRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Update an existing pipeline."""
    try:
        store = _get_store()

        # Build updates dict from non-None fields
        updates = {}
        if request.name is not None:
            updates["name"] = request.name
        if request.columns is not None:
            updates["columns"] = request.columns

        pipeline = store.update_pipeline(
            tenant_id=tenant_id,
            pipeline_id=pipeline_id,
            updates=updates,
            revision=request.revision,
        )

        return PipelineResponse(
            pipeline_id=pipeline["pipeline_id"],
            name=pipeline["name"],
            columns=pipeline["columns"],
            created_at=pipeline["created_at"],
            updated_at=pipeline["updated_at"],
            revision=pipeline["revision"],
        )

    except ValueError as e:
        logger.warning("update_pipeline validation error: %s", e)
        # Check if it's a revision mismatch
        if "Revision mismatch" in str(e):
            raise HTTPException(status_code=409, detail="Pipeline revision conflict")
        raise HTTPException(status_code=400, detail="Invalid pipeline data")
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to update pipeline")


@router.delete("/pipelines/{pipeline_id}", status_code=204)
async def delete_pipeline(
    pipeline_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Delete a pipeline."""
    try:
        store = _get_store()
        store.delete_pipeline(tenant_id, pipeline_id)
        return None

    except ValueError as e:
        logger.warning("delete_pipeline not found: %s", e)
        raise HTTPException(status_code=404, detail="Pipeline not found")
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to delete pipeline")
