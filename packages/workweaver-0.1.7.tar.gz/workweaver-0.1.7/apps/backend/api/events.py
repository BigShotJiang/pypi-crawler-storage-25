"""SSE Events API for Mission Control Part 17 — Real-time updates.

Provides Server-Sent Events streaming for tenant-scoped real-time updates.
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Any

from fastapi import APIRouter, Depends, Header, HTTPException, Query, Request, WebSocket, WebSocketDisconnect, status

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    resolve_verified_websocket_tenant_id,
)
from apps.backend.services.event_bus import EventBusReplayError
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field

from apps.backend.schemas.error_response import safe_error_detail

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/events", tags=["events"])


def _get_bus():
    """Lazy import event bus."""
    from apps.backend.services.event_bus import get_event_bus

    return get_event_bus()


class PublishEventRequest(BaseModel):
    """Request to publish an event."""

    event_type: str = Field(..., description="Event type (e.g., task.created)")
    data: dict = Field(default_factory=dict, description="Event payload")


class PublishEventResponse(BaseModel):
    """Response after publishing an event."""

    published: bool
    subscribers: int
    durable_write_ok: bool
    runtime_status: str = Field(..., description="Overall provider preflight status")
    preflight: dict[str, Any] = Field(default_factory=dict, description="Typed provider readiness summary")


class ReplayEvent(BaseModel):
    """Single replayed event."""

    event_id: str = Field(..., description="Stable event identifier")
    type: str = Field(..., description="Event type")
    data: dict = Field(default_factory=dict, description="Event payload")
    timestamp: str = Field(..., description="Event timestamp")


class ReplayEventResponse(BaseModel):
    """Replay response payload."""

    tenant_id: str
    events: list[ReplayEvent]
    count: int
    limit: int
    runtime_status: str = Field(..., description="Overall provider preflight status")
    preflight: dict[str, Any] = Field(default_factory=dict, description="Typed provider readiness summary")


def _get_runtime_truth() -> dict[str, Any]:
    """Return a serializable snapshot of provider preflight truth."""
    from apps.backend.services.preflight import summarize_preflight

    summary = summarize_preflight()
    return {
        "runtime_status": summary.status.value,
        "preflight": {
            "status": summary.status.value,
            "ready": summary.ready,
            "degraded": summary.degraded,
            "unavailable": summary.unavailable,
            "checks": [
                {
                    "name": check.name,
                    "status": check.status.value,
                    "reason": check.reason,
                }
                for check in summary.checks
            ],
        },
    }


def _format_sse_event(event: dict[str, Any]) -> str:
    """Format an event dict as an SSE message with id and data fields.

    Output format per the SSE spec (https://html.spec.whatwg.org/multipage/server-sent-events.html):
        id: <event_id>
        event: <event_type>
        data: <json_payload>
        <blank line>

    The id: field enables browser-native Last-Event-ID reconnection.
    The event: field enables typed addEventListener dispatch on the client.
    The data: JSON always includes type so onmessage handlers can also read it.
    """
    event_id = str(event.get("event_id", ""))
    event_type = str(event.get("type", ""))
    lines: list[str] = []
    if event_id:
        lines.append(f"id: {event_id}")
    if event_type:
        lines.append(f"event: {event_type}")
    lines.append(f"data: {json.dumps(event)}")
    lines.append("")
    lines.append("")
    return "\n".join(lines)


def _is_mission_event(event: dict[str, Any]) -> bool:
    return str(event.get("type", "")).startswith("mission.")


def _matches_run_filter(event: dict[str, Any], run_id: str | None) -> bool:
    if not run_id:
        return True
    payload = event.get("data")
    if not isinstance(payload, dict):
        return False
    return str(payload.get("run_id", "")) == str(run_id)


@router.get("/stream")
async def event_stream(
    request: Request,
    x_tenant_id: str = Depends(get_verified_tenant_id),
    last_event_id: str | None = Header(default=None, alias="Last-Event-ID"),
):
    """SSE endpoint. Client connects and receives tenant-scoped events.

    Supports ``Last-Event-ID`` header for reconnection replay (#3601).
    When provided, the server replays durable events after the given ID
    before streaming live events.

    Sends heartbeat every 30 seconds to keep connection alive.
    Auto-cleans up on client disconnect.
    """
    bus = _get_bus()
    replayed: list[dict[str, Any]] = []

    # Replay from Last-Event-ID if provided (#3601)
    if last_event_id:
        try:
            # Find the timestamp of the event with the given ID
            all_recent = await bus.replay(x_tenant_id, limit=1000)
            found_timestamp: str | None = None
            for evt in all_recent:
                if str(evt.get("event_id", "")) == last_event_id:
                    found_timestamp = str(evt.get("timestamp", ""))
                    break
            if found_timestamp:
                # Replay events after the found timestamp
                replayed = [e for e in all_recent if str(e.get("timestamp", "")) > found_timestamp]
        except EventBusReplayError:
            logger.warning("SSE replay unavailable for tenant %s", x_tenant_id, exc_info=True)

    queue = await bus.subscribe(x_tenant_id)

    async def generate():
        try:
            # Emit replayed events first
            for event in replayed:
                yield _format_sse_event(event)
            while True:
                if await request.is_disconnected():
                    break
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=30.0)
                    yield _format_sse_event(event)
                except TimeoutError:
                    yield ": heartbeat\n\n"
        except asyncio.CancelledError:
            logger.debug("Event SSE stream cancelled for tenant=%s", x_tenant_id, exc_info=True)
        finally:
            bus.unsubscribe(x_tenant_id, queue)

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.get("/mission/stream")
async def mission_event_stream(
    request: Request,
    x_tenant_id: str = Depends(get_verified_tenant_id),
    run_id: str | None = Query(None, description="Optional run filter"),
    since: str | None = Query(None, description="Optional replay lower bound"),
    backlog_limit: int = Query(200, ge=1, le=1000, description="Replay rows before live stream"),
    backlog_only: bool = Query(False, description="When true, stream only replay backlog then close"),
):
    """SSE stream scoped to mission command-plane and intervention events."""
    bus = _get_bus()
    replayed: list[dict[str, Any]] = []
    if since:
        try:
            replayed = await bus.replay(
                x_tenant_id,
                since_timestamp=since,
                limit=backlog_limit,
            )
        except EventBusReplayError as exc:
            logger.warning("Mission SSE replay unavailable for tenant %s", x_tenant_id, exc_info=True)
            raise HTTPException(status_code=503, detail="event_replay_unavailable") from exc
    queue = await bus.subscribe(x_tenant_id)

    async def generate():
        try:
            for event in replayed:
                if not _is_mission_event(event):
                    continue
                if not _matches_run_filter(event, run_id):
                    continue
                yield _format_sse_event(event)
            if backlog_only:
                return

            while True:
                if await request.is_disconnected():
                    break
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=30.0)
                    if not _is_mission_event(event):
                        continue
                    if not _matches_run_filter(event, run_id):
                        continue
                    yield _format_sse_event(event)
                except TimeoutError:
                    yield ": heartbeat\n\n"
        except asyncio.CancelledError:
            logger.debug(
                "Mission SSE stream cancelled for tenant=%s run_id=%s",
                x_tenant_id,
                run_id,
                exc_info=True,
            )
        finally:
            bus.unsubscribe(x_tenant_id, queue)

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.websocket("/mission/ws")
async def mission_event_websocket(websocket: WebSocket) -> None:
    """WebSocket stream for mission command-plane and intervention events."""
    try:
        tenant_id = resolve_verified_websocket_tenant_id(websocket)
    except HTTPException as exc:
        close_code = 4403 if exc.status_code == status.HTTP_403_FORBIDDEN else 4401
        await websocket.close(code=close_code, reason=str(exc.detail))
        return

    run_id = (websocket.query_params.get("run_id") or "").strip() or None
    since = (websocket.query_params.get("since") or "").strip() or None
    try:
        backlog_limit = int((websocket.query_params.get("backlog_limit") or "200").strip())
    except Exception:
        backlog_limit = 200
    backlog_limit = min(max(backlog_limit, 1), 1000)
    bus = _get_bus()
    replayed: list[dict[str, Any]] = []
    if since:
        try:
            replayed = await bus.replay(
                tenant_id,
                since_timestamp=since,
                limit=backlog_limit,
            )
        except EventBusReplayError:
            logger.warning("Mission websocket replay unavailable for tenant=%s", tenant_id, exc_info=True)
            await websocket.close(code=1013, reason="event_replay_unavailable")
            return
    queue = await bus.subscribe(tenant_id)
    await websocket.accept()

    try:
        for event in replayed:
            if not _is_mission_event(event):
                continue
            if not _matches_run_filter(event, run_id):
                continue
            await websocket.send_json(event)

        while True:
            try:
                event = await asyncio.wait_for(queue.get(), timeout=30.0)
            except TimeoutError:
                await websocket.send_json({"type": "heartbeat", "timestamp": "now"})
                continue
            if not _is_mission_event(event):
                continue
            if not _matches_run_filter(event, run_id):
                continue
            await websocket.send_json(event)
    except WebSocketDisconnect:
        logger.debug("Mission websocket disconnected for tenant=%s run_id=%s", tenant_id, run_id, exc_info=True)
    except Exception:
        logger.exception("Mission websocket stream failed for tenant=%s", tenant_id)
    finally:
        bus.unsubscribe(tenant_id, queue)


@router.post("/publish", response_model=PublishEventResponse)
async def publish_event(
    request: PublishEventRequest,
    x_tenant_id: str = Depends(get_verified_tenant_id),
):
    """Publish an event to all subscribers for a tenant.

    Internal endpoint used by other services to broadcast events.
    """
    try:
        bus = _get_bus()
        outcome = await bus.publish_with_status(x_tenant_id, request.event_type, request.data)
        runtime_truth = _get_runtime_truth()
        return PublishEventResponse(
            published=True,
            subscribers=outcome.subscribers,
            durable_write_ok=outcome.durable_write_ok,
            runtime_status=runtime_truth["runtime_status"],
            preflight=runtime_truth["preflight"],
        )
    except ValueError as e:
        raise HTTPException(status_code=422, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=503, detail="event_publish_unavailable")


@router.get("/subscribers")
async def get_subscriber_count(
    x_tenant_id: str = Depends(get_verified_tenant_id),
):
    """Get number of active SSE subscribers for tenant."""
    bus = _get_bus()
    count = bus.subscriber_count(x_tenant_id)
    runtime_truth = _get_runtime_truth()
    return {
        "tenant_id": x_tenant_id,
        "subscribers": count,
        "runtime_status": runtime_truth["runtime_status"],
        "preflight": runtime_truth["preflight"],
    }


def _is_calendar_event(event: dict[str, Any]) -> bool:
    """Check if an event is a timeblock calendar event."""
    return str(event.get("type", "")).startswith("timeblock.")


@router.get("/calendar/stream")
async def calendar_event_stream(
    request: Request,
    x_tenant_id: str = Depends(get_verified_tenant_id),
):
    """SSE endpoint for real-time TimeBlock calendar updates.

    Emits events: timeblock.created, timeblock.updated, timeblock.completed.
    Sends heartbeat every 30 seconds to keep connection alive.
    """
    bus = _get_bus()
    queue: asyncio.Queue[dict[str, Any]] = await bus.subscribe(x_tenant_id)

    async def generate():
        try:
            while True:
                if await request.is_disconnected():
                    break
                try:
                    event = await asyncio.wait_for(queue.get(), timeout=30.0)
                    if not _is_calendar_event(event):
                        continue
                    yield _format_sse_event(event)
                except TimeoutError:
                    yield ": heartbeat\n\n"
        except asyncio.CancelledError:
            logger.debug("Calendar SSE stream cancelled for tenant=%s", x_tenant_id, exc_info=True)
        finally:
            bus.unsubscribe(x_tenant_id, queue)

    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@router.get("/replay", response_model=ReplayEventResponse)
async def replay_events(
    x_tenant_id: str = Depends(get_verified_tenant_id),
    since: str | None = Query(None, description="Optional ISO timestamp lower bound"),
    event_type: str | None = Query(None, description="Optional event-type filter"),
    limit: int = Query(200, ge=1, le=1000, description="Max replay events"),
):
    """Replay durable events ordered by timestamp for the current tenant."""
    try:
        bus = _get_bus()
        events = await bus.replay(
            x_tenant_id,
            since_timestamp=since,
            event_type=event_type,
            limit=limit,
        )
        rows = [ReplayEvent(**event) for event in events]
        runtime_truth = _get_runtime_truth()
        return ReplayEventResponse(
            tenant_id=x_tenant_id,
            events=rows,
            count=len(rows),
            limit=limit,
            runtime_status=runtime_truth["runtime_status"],
            preflight=runtime_truth["preflight"],
        )
    except EventBusReplayError as exc:
        logger.warning("Failed to replay events for tenant %s", x_tenant_id, exc_info=True)
        raise HTTPException(status_code=503, detail="event_replay_unavailable") from exc
