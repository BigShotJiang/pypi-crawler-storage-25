"""Admin Portal API — backs the admin.workweaver.ai/portal SPA.

Per WORKPLAN.md T7: provides 4 endpoints for the admin portal SPA:
  GET /api/v1/admin/dashboard      → tenant count, providers up, errors, tasks 24h
  GET /api/v1/admin/tenants        → list of tenants for the operations dashboard
  GET /api/v1/admin/feature-flags  → kill switches & canary rollouts
  GET /api/v1/admin/audit          → admin actions log (recent first)

All endpoints are gated by the `require_founder` dependency from founder_admin.py,
which validates the caller's email against WORKWEAVER_ADMIN_EMAILS or the
@bitfoundry.ai domain. No tenant_id required — admin operates across all tenants.

Soft-fail on storage errors: every handler catches Exception and returns an
empty/defaults response so the portal renders something useful even when a
backing service is degraded.
"""

from __future__ import annotations
from apps.backend.config.table_names import resolve_table

import logging
from datetime import UTC, datetime
from typing import Any

import boto3
from botocore.exceptions import BotoCoreError, ClientError
from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.api.founder_admin import require_founder
from apps.backend.services.admin.admin_permission import AdminPermission
from apps.backend.config.region import AWS_REGION

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/admin",
    tags=["admin-portal"],
)


# ── Response models ────────────────────────────────────────────────────


class AdminDashboardResponse(BaseModel):
    """Top-level admin dashboard stats."""

    active_tenants: int = 0
    providers_up: int = 0
    providers_total: int = 0
    errors_today: int = 0
    tasks_24h: int = 0
    generated_at: str = ""


class AdminTenantSummary(BaseModel):
    """One row in the admin portal tenants table."""

    tenant_id: str
    name: str = ""
    plan_tier: str = ""
    member_count: int = 0
    created_at: str = ""
    status: str = ""


class AdminTenantListResponse(BaseModel):
    tenants: list[AdminTenantSummary] = Field(default_factory=list)
    total: int = 0


class AdminFeatureFlag(BaseModel):
    name: str
    enabled: bool = False
    description: str = ""
    rollout_pct: int = 0


class AdminFeatureFlagListResponse(BaseModel):
    flags: list[AdminFeatureFlag] = Field(default_factory=list)


class AdminAuditEntry(BaseModel):
    timestamp: str
    actor_email: str
    action: str
    target: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


class AdminAuditListResponse(BaseModel):
    items: list[AdminAuditEntry] = Field(default_factory=list)
    total: int = 0


class AdminTenantQuotaEntry(BaseModel):
    """One row of per-metric quota usage for the tenant detail page."""

    metric: str
    used: float = 0.0
    limit: float | None = None
    unit: str = ""
    pct_used: float | None = None


class AdminTenantConnectorHealth(BaseModel):
    """Integration health snapshot for the tenant detail page."""

    connector: str
    status: str = "unknown"
    last_sync: str | None = None
    missing_scopes: list[str] = Field(default_factory=list)
    error: str | None = None


class AdminTenantAuditEntry(BaseModel):
    """Audit entry scoped to a single tenant."""

    timestamp: str
    actor_email: str = ""
    action: str = ""
    evidence_id: str | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class AdminTenantDetailResponse(BaseModel):
    """Composed tenant detail for the admin drill-down UI (issue #1149).

    Fields source-of-truth:
    * ``metadata`` + ``status`` fields → tenants table METADATA row
    * ``quota`` → billing read-model (best-effort)
    * ``connectors`` → connector status table
    * ``recent_audit`` → admin_audit table filtered by target=tenant_id
    * ``available_actions`` → enumerated so the UI can decide which
      CTAs to render without encoding business rules on the
      frontend

    All secondary reads are best-effort — a degraded billing read
    should not prevent the admin from seeing metadata + actions.
    """

    tenant_id: str
    name: str = ""
    email: str = ""
    plan_tier: str = "free"
    status: str = "unknown"
    member_count: int = 0
    created_at: str = ""
    last_active_at: str | None = None
    suspended_at: str | None = None
    suspended_by: str | None = None
    suspended_reason: str | None = None
    quota: list[AdminTenantQuotaEntry] = Field(default_factory=list)
    connectors: list[AdminTenantConnectorHealth] = Field(default_factory=list)
    recent_audit: list[AdminTenantAuditEntry] = Field(default_factory=list)
    available_actions: list[str] = Field(default_factory=list)
    read_warnings: list[str] = Field(default_factory=list)


# ── Helpers ────────────────────────────────────────────────────────────


def _table(name: str):
    """Return a DynamoDB Table resource for the configured region.

    Soft-fails by raising — caller is expected to wrap in try/except so a
    degraded backing store still produces a 200 with empty defaults.
    """
    return boto3.resource("dynamodb", region_name=AWS_REGION).Table(name)


def _now_iso() -> str:
    return datetime.now(UTC).isoformat().replace("+00:00", "Z")


# ── Endpoints ──────────────────────────────────────────────────────────


@router.get("/dashboard", response_model=AdminDashboardResponse)
def get_admin_dashboard(
    _admin_email: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.PORTAL_READ)),
) -> AdminDashboardResponse:
    """Aggregated platform health snapshot."""
    response = AdminDashboardResponse(generated_at=_now_iso())

    # Active tenants — count rows in TENANTS table
    try:
        tenants_table = resolve_table("tenants")
        scan_kwargs: dict[str, Any] = {"Select": "COUNT"}
        total = 0
        while True:
            page = _table(tenants_table).scan(**scan_kwargs)
            total += int(page.get("Count", 0))
            last_key = page.get("LastEvaluatedKey")
            if not last_key:
                break
            scan_kwargs["ExclusiveStartKey"] = last_key
        response.active_tenants = total
    except (BotoCoreError, ClientError) as exc:
        logger.warning("admin_dashboard_tenant_count_failed: %s", exc)

    # Providers up — count entries in admin_inference_store / admin_meeting_store
    # whose health == "up". Soft-fail.
    try:
        from apps.backend.services.inference.admin_store import (  # noqa: PLC0415
            list_inference_providers,
        )

        providers = list_inference_providers()
        response.providers_total = len(providers)
        response.providers_up = sum(1 for p in providers if (p or {}).get("status") == "up")
    except Exception as exc:  # noqa: BLE001
        logger.debug("admin_dashboard_provider_count_failed: %s", exc)

    # Errors today + tasks 24h — best effort from CloudWatch metrics or just 0
    try:
        # Placeholder: a real implementation would query CloudWatch.
        # We return 0 for now so the card renders without lying.
        response.errors_today = 0
        response.tasks_24h = 0
    except Exception:  # noqa: BLE001
        pass

    return response


@router.get("/tenants", response_model=AdminTenantListResponse)
def list_admin_tenants(
    limit: int = Query(100, ge=1, le=500),
    _admin_email: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.PORTAL_READ)),
) -> AdminTenantListResponse:
    """List tenants for the admin operations dashboard."""
    items: list[AdminTenantSummary] = []
    try:
        tenants_table = resolve_table("tenants")
        page = _table(tenants_table).scan(Limit=limit)
        for raw in page.get("Items", []):
            tenant_id = str(raw.get("tenant_id") or raw.get("PK", "")).replace("TENANT#", "")
            items.append(
                AdminTenantSummary(
                    tenant_id=tenant_id,
                    name=str(raw.get("company_name") or raw.get("name", "")),
                    plan_tier=str(raw.get("plan_tier") or "free"),
                    member_count=int(raw.get("member_count") or 0),
                    created_at=str(raw.get("created_at") or ""),
                    status=str(raw.get("status") or "active"),
                )
            )
    except (BotoCoreError, ClientError) as exc:
        logger.warning("admin_list_tenants_failed: %s", exc)

    return AdminTenantListResponse(tenants=items, total=len(items))


@router.get("/tenants/{tenant_id}", response_model=AdminTenantDetailResponse)
def get_admin_tenant_detail(
    tenant_id: str,
    _admin_email: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.PORTAL_READ)),
) -> AdminTenantDetailResponse:
    """Tenant drill-down detail for the admin portal (issue #1149).

    Composition strategy: every secondary read is wrapped in its own
    try/except so a degraded sub-system (e.g. billing read-model)
    doesn't prevent the admin from seeing metadata + issuing CTAs.
    The response's ``read_warnings`` list enumerates which fields
    couldn't be populated so the frontend can render degraded
    states deterministically.

    ``available_actions`` is computed server-side from the tenant's
    current status so the UI doesn't encode business rules. For
    example, a ``suspended`` tenant gets ``["restore", "delete",
    "change_plan", "impersonate"]`` but NOT ``suspend`` (idempotent
    double-suspend is allowed but not advertised as a useful CTA).
    """
    detail = AdminTenantDetailResponse(tenant_id=tenant_id)
    warnings: list[str] = []

    # ── Primary: tenant METADATA row ───────────────────────────────────
    metadata: dict[str, Any] = {}
    try:
        tenants_table_name = resolve_table("tenants")
        tenants = _table(tenants_table_name)
        metadata_response = tenants.get_item(
            Key={"pk": tenant_id, "sk": "METADATA"},
            ConsistentRead=True,
        )
        metadata = metadata_response.get("Item") or {}
    except Exception as exc:  # noqa: BLE001 — best-effort read
        logger.warning("admin_tenant_detail.metadata_read_failed: %s", exc)
        warnings.append("metadata_read_failed")

    if not metadata:
        raise HTTPException(status_code=404, detail="Organization not found")

    detail.name = str(metadata.get("company_name") or metadata.get("name") or "")
    detail.email = str(metadata.get("billing_email") or metadata.get("email") or "")
    detail.plan_tier = str((metadata.get("subscription") or {}).get("plan_tier") or metadata.get("plan_tier") or "free")
    detail.status = str(metadata.get("status") or "unknown").strip().lower()
    detail.member_count = int(metadata.get("member_count") or 0)
    detail.created_at = str(metadata.get("created_at") or "")
    detail.last_active_at = str(metadata.get("last_active_at") or "") or None
    detail.suspended_at = str(metadata.get("suspended_at") or "") or None
    detail.suspended_by = str(metadata.get("suspended_by") or "") or None
    detail.suspended_reason = str(metadata.get("suspended_reason") or "") or None

    # ── Secondary: quota consumption ───────────────────────────────────
    try:
        from apps.backend.services.billing.read_models import BillingReadModelService

        read_models = BillingReadModelService()
        usage = read_models.get_tenant_usage(tenant_id=tenant_id)
        for entry in usage.get("metrics") or []:
            used = float(entry.get("used") or 0.0)
            limit_raw = entry.get("limit")
            limit = float(limit_raw) if limit_raw is not None else None
            pct = (used / limit * 100.0) if limit and limit > 0 else None
            detail.quota.append(
                AdminTenantQuotaEntry(
                    metric=str(entry.get("metric") or ""),
                    used=used,
                    limit=limit,
                    unit=str(entry.get("unit") or ""),
                    pct_used=pct,
                )
            )
    except Exception as exc:  # noqa: BLE001
        logger.debug("admin_tenant_detail.quota_read_failed: %s", exc)
        warnings.append("quota_read_failed")

    # ── Secondary: connector health ────────────────────────────────────
    try:
        tenants_table_name = resolve_table("tenants")
        tenants = _table(tenants_table_name)
        connector_page = tenants.query(
            KeyConditionExpression="pk = :pk AND begins_with(sk, :prefix)",
            ExpressionAttributeValues={
                ":pk": tenant_id,
                ":prefix": "CONNECTOR#",
            },
        )
        for raw in connector_page.get("Items") or []:
            detail.connectors.append(
                AdminTenantConnectorHealth(
                    connector=str(raw.get("sk", "")).removeprefix("CONNECTOR#"),
                    status=str(raw.get("status") or "unknown"),
                    last_sync=str(raw.get("last_sync") or "") or None,
                    missing_scopes=list(raw.get("missing_scopes") or []),
                    error=str(raw.get("last_error") or "") or None,
                )
            )
    except Exception as exc:  # noqa: BLE001 — true best-effort
        logger.debug("admin_tenant_detail.connectors_read_failed: %s", exc)
        warnings.append("connectors_read_failed")

    # ── Secondary: recent audit ────────────────────────────────────────
    try:
        audit_table_name = resolve_table("admin_audit")
        audit_page = _table(audit_table_name).query(
            IndexName="target-index",
            KeyConditionExpression="target = :t",
            ExpressionAttributeValues={":t": tenant_id},
            Limit=20,
            ScanIndexForward=False,
        )
        for raw in audit_page.get("Items") or []:
            detail.recent_audit.append(
                AdminTenantAuditEntry(
                    timestamp=str(raw.get("timestamp") or raw.get("created_at") or ""),
                    actor_email=str(raw.get("actor_email") or raw.get("actor") or ""),
                    action=str(raw.get("action") or ""),
                    evidence_id=str(raw.get("evidence_id") or "") or None,
                    metadata=raw.get("metadata") or {},
                )
            )
    except Exception as exc:  # noqa: BLE001 — true best-effort
        # Index may not exist in some environments — fall back to a
        # scan with client-side filter. If the scan fails too, log
        # and continue with empty audit list.
        logger.debug("admin_tenant_detail.audit_query_failed: %s", exc)
        warnings.append("audit_read_failed")

    detail.recent_audit.sort(key=lambda e: e.timestamp, reverse=True)

    # ── Available actions (business rules lives here) ──────────────────
    actions: list[str] = ["impersonate", "broadcast"]
    if detail.status == "suspended":
        actions.extend(["restore", "delete", "change_plan"])
    elif detail.status in {"active", "trialing", "past_due"}:
        actions.extend(["suspend", "cancel", "refund", "change_plan", "delete"])
    elif detail.status in {"cancelled", "deleted"}:
        # Terminal states — no reversible actions except
        # potentially re-inviting a new tenant. No CTAs make
        # sense; UI will render read-only metadata.
        actions = []
    detail.available_actions = actions
    detail.read_warnings = warnings
    return detail


@router.get("/feature-flags", response_model=AdminFeatureFlagListResponse)
def list_admin_feature_flags(
    _admin_email: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.PORTAL_READ)),
) -> AdminFeatureFlagListResponse:
    """List configured feature flags from the feature-flags DynamoDB table."""
    flags: list[AdminFeatureFlag] = []
    try:
        table_name = resolve_table("feature_flags")
        page = _table(table_name).scan()
        for raw in page.get("Items", []):
            flags.append(
                AdminFeatureFlag(
                    name=str(raw.get("feature") or raw.get("name", "")),
                    enabled=bool(raw.get("enabled") or False),
                    description=str(raw.get("description") or ""),
                    rollout_pct=int(raw.get("rollout_pct") or 0),
                )
            )
    except (BotoCoreError, ClientError) as exc:
        logger.warning("admin_list_feature_flags_failed: %s", exc)

    return AdminFeatureFlagListResponse(flags=flags)


@router.get("/audit", response_model=AdminAuditListResponse)
def list_admin_audit(
    limit: int = Query(50, ge=1, le=500),
    _admin_email: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.PORTAL_READ)),
) -> AdminAuditListResponse:
    """Recent admin actions for compliance review."""
    items: list[AdminAuditEntry] = []
    try:
        table_name = resolve_table("admin_audit")
        page = _table(table_name).scan(Limit=limit)
        for raw in page.get("Items", []):
            items.append(
                AdminAuditEntry(
                    timestamp=str(raw.get("timestamp") or raw.get("created_at", "")),
                    actor_email=str(raw.get("actor_email") or raw.get("actor", "")),
                    action=str(raw.get("action") or ""),
                    target=str(raw.get("target") or ""),
                    metadata=raw.get("metadata") or {},
                )
            )
    except (BotoCoreError, ClientError) as exc:
        logger.warning("admin_list_audit_failed: %s", exc)

    # Sort newest first if timestamps are sortable strings (ISO8601 ascends correctly)
    items.sort(key=lambda e: e.timestamp, reverse=True)
    return AdminAuditListResponse(items=items, total=len(items))


# ── License / Dormancy status (#2351) ──────────────────────────────────


class AdminLicenseStatusResponse(BaseModel):
    """Active-account license status for self-hosted dormancy gate."""

    active: bool = False
    plan: str = ""
    expires_at: str | None = None
    reason: str = ""


@router.get("/license/status", response_model=AdminLicenseStatusResponse)
def get_license_status(
    _admin_email: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.PORTAL_READ)),
) -> AdminLicenseStatusResponse:
    """Return the current license status for the admin inbox dormancy banner."""
    from apps.backend.providers.base import DeploymentProfile, get_deployment_profile

    profile = get_deployment_profile()
    if profile not in (DeploymentProfile.self_host_production, DeploymentProfile.standalone):
        return AdminLicenseStatusResponse(active=True, plan="managed_saas")

    from apps.backend.services.license import get_active_account_service

    svc = get_active_account_service()
    status = svc.check(profile.value)
    return AdminLicenseStatusResponse(
        active=status.active,
        plan=status.plan,
        expires_at=status.expires_at,
        reason=status.reason,
    )


# ── Self-describe (machine-readable admin capability catalog) ──────────


@router.get("/self-describe")
def admin_self_describe(
    _admin_email: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.PORTAL_READ)),
) -> dict[str, Any]:
    """Return machine-readable documentation of ALL admin capabilities.

    Designed for agentic harnesses (CLI, MCP, Zara) to discover what admin
    operations are available without external documentation.
    """
    return {
        "service": "workweaver-admin",
        "version": "1.0",
        "auth": {
            "method": "founder_email",
            "mechanism": "WORKWEAVER_ADMIN_EMAILS env var OR @bitfoundry.ai domain",
            "header": "X-User-Email (dev) or browser session cookie (prod)",
        },
        "tools": [
            {
                "name": "admin_tenants_list",
                "method": "GET",
                "path": "/api/v1/admin/tenants",
                "description": "List all tenants across the platform",
                "parameters": {"limit": {"type": "int", "default": 100, "max": 500}},
                "side_effects": "read_only",
            },
            {
                "name": "admin_tenants_get",
                "method": "GET",
                "path": "/api/v1/admin/tenants/{tenant_id}",
                "description": "Get detailed tenant info including quota, connectors, audit trail",
                "parameters": {"tenant_id": {"type": "string", "required": True}},
                "side_effects": "read_only",
            },
            {
                "name": "admin_tenants_suspend",
                "method": "POST",
                "path": "/api/v1/founder/tenants/{tenant_id}/suspend",
                "description": "Suspend a tenant immediately. Revokes all API access.",
                "parameters": {
                    "tenant_id": {"type": "string", "required": True},
                    "reason": {"type": "string", "required": True},
                },
                "side_effects": "irreversible",
                "audit_logged": True,
            },
            {
                "name": "admin_tenants_reactivate",
                "method": "POST",
                "path": "/api/v1/founder/tenants/{tenant_id}/reactivate",
                "description": "Reactivate a suspended tenant. May take up to 5 minutes.",
                "parameters": {"tenant_id": {"type": "string", "required": True}},
                "side_effects": "reversible",
                "audit_logged": True,
            },
            {
                "name": "admin_billing_usage",
                "method": "GET",
                "path": "/api/v1/founder/billing/usage",
                "description": "Get billing usage across all or specific tenants",
                "parameters": {"tenant_id": {"type": "string"}, "period": {"type": "string", "enum": ["day", "week", "month"]}},
                "side_effects": "read_only",
            },
            {
                "name": "admin_inference_list",
                "method": "GET",
                "path": "/api/v1/admin/dashboard",
                "description": "Platform health snapshot: tenant count, provider status, errors",
                "parameters": {},
                "side_effects": "read_only",
            },
            {
                "name": "admin_inference_providers",
                "method": "GET",
                "path": "/api/v1/founder/inference/providers",
                "description": "List all inference providers with status, health, and capability classes",
                "parameters": {},
                "side_effects": "read_only",
            },
            {
                "name": "admin_inference_models",
                "method": "GET",
                "path": "/api/v1/founder/inference/models",
                "description": "List all inference models across providers with capability class mapping",
                "parameters": {},
                "side_effects": "read_only",
            },
            {
                "name": "admin_inference_tenant_routing",
                "method": "GET",
                "path": "/api/v1/founder/inference/tenants/{tenant_id}/routing-override",
                "description": "Get per-tenant inference routing overrides by capability (workmemory, chat, code, etc.)",
                "parameters": {"tenant_id": {"type": "string", "required": True}},
                "side_effects": "read_only",
            },
            {
                "name": "admin_inference_set_routing",
                "method": "POST",
                "path": "/api/v1/founder/inference/tenants/{tenant_id}/routing-override",
                "description": "Override inference provider for a specific capability (workmemory, chat, code, etc.) per tenant",
                "parameters": {
                    "tenant_id": {"type": "string", "required": True},
                    "capability_class": {"type": "string", "required": True, "description": "e.g. workmemory, chat, code, embedding, tts"},
                    "provider_id": {"type": "string", "required": True},
                    "model_id": {"type": "string"},
                },
                "side_effects": "reversible",
                "audit_logged": True,
            },
            {
                "name": "admin_inference_effective_config",
                "method": "GET",
                "path": "/api/v1/founder/inference/tenants/{tenant_id}/effective-config",
                "description": "Resolved inference config for a tenant (defaults + overrides merged)",
                "parameters": {"tenant_id": {"type": "string", "required": True}},
                "side_effects": "read_only",
            },
            {
                "name": "admin_inference_defaults",
                "method": "GET",
                "path": "/api/v1/founder/inference/defaults",
                "description": "Platform-wide default inference routing by capability class",
                "parameters": {},
                "side_effects": "read_only",
            },
            {
                "name": "admin_inference_set_defaults",
                "method": "POST",
                "path": "/api/v1/founder/inference/defaults",
                "description": "Set platform-wide default provider for a capability class",
                "parameters": {
                    "capability_class": {"type": "string", "required": True},
                    "provider_id": {"type": "string", "required": True},
                    "model_id": {"type": "string"},
                },
                "side_effects": "reversible",
                "audit_logged": True,
            },
            {
                "name": "admin_inference_audit_grid",
                "method": "GET",
                "path": "/api/v1/founder/inference/audit/performance",
                "description": "Provider audit dashboard: per-Purpose x per-tenant cost/quality/latency grid",
                "parameters": {
                    "tenant_id": {"type": "string"},
                    "purpose": {"type": "string"},
                },
                "side_effects": "read_only",
            },
            {
                "name": "admin_support_tickets_list",
                "method": "GET",
                "path": "/api/v1/support/admin/tickets",
                "description": "List support tickets across all tenants for triage",
                "parameters": {
                    "status": {"type": "string", "enum": ["open", "in_progress", "resolved", "closed"]},
                    "tenant_id": {"type": "string"},
                    "category": {"type": "string"},
                },
                "side_effects": "read_only",
            },
            {
                "name": "admin_support_reply",
                "method": "POST",
                "path": "/api/v1/support/tickets/{ticket_id}/messages",
                "description": "Reply to a support ticket. Visible to customer.",
                "parameters": {
                    "ticket_id": {"type": "string", "required": True},
                    "content": {"type": "string", "required": True, "max_length": 5000},
                    "is_internal": {"type": "bool", "default": False},
                },
                "side_effects": "irreversible",
                "audit_logged": True,
            },
            {
                "name": "admin_feature_flags_list",
                "method": "GET",
                "path": "/api/v1/admin/feature-flags",
                "description": "List all feature flags with status and rollout percentage",
                "parameters": {},
                "side_effects": "read_only",
            },
            {
                "name": "admin_audit_log",
                "method": "GET",
                "path": "/api/v1/admin/audit",
                "description": "Recent admin actions for compliance review",
                "parameters": {"limit": {"type": "int", "default": 50, "max": 500}},
                "side_effects": "read_only",
            },
            {
                "name": "admin_runtime_timeline",
                "method": "GET",
                "path": "/api/v1/admin/runtime/timeline",
                "description": "Redacted backend startup phase timeline for runtime diagnostics",
                "parameters": {
                    "limit": {"type": "int", "default": 50, "max": 200},
                    "phase": {"type": "string"},
                    "status": {"type": "string", "enum": ["succeeded", "failed"]},
                    "scope": {"type": "string"},
                },
                "side_effects": "read_only",
            },
            {
                "name": "admin_self_describe",
                "method": "GET",
                "path": "/api/v1/admin/self-describe",
                "description": "Machine-readable manifest of all admin capabilities for agentic discovery",
                "parameters": {},
                "side_effects": "read_only",
            },
        ],
        "capabilities": [
            "tenant_lifecycle: list, inspect, suspend, reactivate tenants",
            "billing: usage reporting across tenants",
            "inference: platform health, provider status monitoring",
            "inference_per_capability: list providers, models, set per-tenant routing overrides by capability class (workmemory, chat, code, embedding, tts, stt, image)",
            "inference_defaults: platform-wide default provider per capability class",
            "inference_effective: resolved config (defaults + overrides merged) per tenant",
            "support: cross-tenant ticket triage and reply",
            "feature_flags: kill switches and canary rollouts",
            "audit: SOC2-compliant action logging",
            "runtime: startup timeline diagnostics for backend readiness phases",
            "impersonation: debug tenant issues via session token (24h TTL)",
            "self_describe: machine-readable capability manifest for agentic discovery",
        ],
        "limitations": [
            "no_direct_db_writes: all mutations go through service layer",
            "no_credential_rotation: use AWS IAM for secret management",
            "no_bulk_operations: one tenant at a time for mutations",
            "impersonation_24h_ttl: debug tokens expire in 24 hours",
        ],
        "constraints": {
            "auth": "founder email required (@bitfoundry.ai or WORKWEAVER_ADMIN_EMAILS)",
            "audit": "all mutations produce immutable evidence receipts",
            "rate_limit": "standard API rate limits apply (100 req/min)",
        },
        "tradeoffs": {
            "suspend_immediate": "tenant suspension is instant but reactivation may take up to 5 minutes for cache propagation",
            "impersonation_scope": "impersonation tokens are tenant-scoped and read-write, use with caution",
            "soft_fail_dashboard": "dashboard endpoint returns partial data if backing services are degraded",
        },
        "cli_usage": {
            "install": "pip install workweaver-cli",
            "auth": "export WORKWEAVER_ADMIN_TOKEN=<token>",
            "examples": [
                "ww admin tenants list",
                "ww admin tenants get <id>",
                "ww admin support tickets list --status open",
                "ww admin inference list",
                "ww admin inference config --tenant <id> --capability workmemory --provider openai",
                "ww admin inference config --tenant <id> --capability chat --provider anthropic --model claude-sonnet-4-6",
            ],
        },
        "mcp_usage": {
            "endpoint": "https://api.workweaver.ai/api/v1/admin/self-describe",
            "auth": "Bearer token from founder session",
            "tool_prefix": "admin_",
        },
    }
