"""Human-AI Collaboration API endpoints (M9.5, M9.6).

M9.5 — Human Takeover / Hand-Back UX:
  POST /api/v1/mission/tasks/{task_id}/takeover — suspend session, create HUMAN_OVERRIDE TimeBlock
  POST /api/v1/mission/tasks/{task_id}/handback — resume session with handback notes

M9.6 — Multi-Channel Session Continuity:
  GET /api/v1/mission/tasks/{task_id}/channel-timeline — return channel transition history

Multi-tenant invariant: All operations are tenant-scoped via X-Tenant-ID header.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Body, Depends, HTTPException, Path, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/mission/tasks", tags=["human-ai-collaboration"])


# ---------------------------------------------------------------------------
# Lazy gateway accessor
# ---------------------------------------------------------------------------


def _get_session_gateway():
    from apps.backend.services.runtime.runtime_session_gateway import get_runtime_session_gateway

    return get_runtime_session_gateway()


def _get_task_store():
    from apps.backend.services.task_store import get_task_store

    return get_task_store()


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class TakeoverRequest(BaseModel):
    """Request to take over a task from the AI."""

    user_id: str = Field(..., min_length=1, description="ID of the user taking over")
    session_id: str = Field(..., min_length=1, description="Runtime session ID to take over")
    reason: str | None = Field(None, description="Reason for taking over")


class TakeoverResponse(BaseModel):
    """Response after taking over a task."""

    success: bool
    task_id: str
    session_id: str
    state: str
    takeover_user_id: str
    message: str


class HandbackRequest(BaseModel):
    """Request to hand a task back to the AI."""

    session_id: str = Field(..., min_length=1, description="Runtime session ID to hand back")
    notes: str = Field("", description="Notes about what was done during human takeover")


class HandbackResponse(BaseModel):
    """Response after handing a task back to the AI."""

    success: bool
    task_id: str
    session_id: str
    state: str
    handback_notes: str | None
    message: str


class ChannelTransitionEntry(BaseModel):
    """A single channel transition in the timeline."""

    channel: str
    event: str
    timestamp: str
    user_id: str | None = None


class ChannelTimelineResponse(BaseModel):
    """Response for channel timeline."""

    task_id: str
    session_id: str
    timeline: list[ChannelTransitionEntry]


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/{task_id}/takeover",
    response_model=TakeoverResponse,
    status_code=status.HTTP_200_OK,
)
async def takeover_task(
    task_id: str = Path(..., description="Task ID to take over"),
    request: TakeoverRequest = Body(...),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> TakeoverResponse:
    """Human takes over an in-progress task from the AI (M9.5).

    Suspends the runtime session and creates a HUMAN_OVERRIDE TimeBlock.
    The task moves to "Human In Progress" state.
    """
    gateway = _get_session_gateway()
    try:
        session = await gateway.takeover_session(
            tenant_id=tenant_id,
            session_id=request.session_id,
            user_id=request.user_id,
        )
    except ValueError as exc:
        logger.error("Collaboration session not found: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Resource not found",
        )

    return TakeoverResponse(
        success=True,
        task_id=task_id,
        session_id=session.session_id,
        state=session.state,
        takeover_user_id=request.user_id,
        message=f"Task {task_id} taken over by {request.user_id}",
    )


@router.post(
    "/{task_id}/handback",
    response_model=HandbackResponse,
    status_code=status.HTTP_200_OK,
)
async def handback_task(
    task_id: str = Path(..., description="Task ID to hand back to AI"),
    request: HandbackRequest = Body(...),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> HandbackResponse:
    """Human hands a task back to the AI after manual intervention (M9.5).

    Resumes the runtime session from the dashboard channel and injects
    handback notes so the AI can continue with context.
    """
    gateway = _get_session_gateway()
    try:
        session = await gateway.handback_session(
            tenant_id=tenant_id,
            session_id=request.session_id,
            notes=request.notes,
        )
    except ValueError as exc:
        logger.error("Collaboration session not found: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Resource not found",
        )

    return HandbackResponse(
        success=True,
        task_id=task_id,
        session_id=session.session_id,
        state=session.state,
        handback_notes=session.handback_notes,
        message=f"Task {task_id} handed back to AI",
    )


@router.get(
    "/{task_id}/channel-timeline",
    response_model=ChannelTimelineResponse,
    status_code=status.HTTP_200_OK,
)
async def get_channel_timeline(
    task_id: str = Path(..., description="Task ID"),
    session_id: str = "",
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ChannelTimelineResponse:
    """Get the cross-channel transition timeline for a task session (M9.6).

    Returns an ordered list of channel transitions with timestamps,
    showing the complete journey: "Started on Slack -> Continued on Dashboard -> ..."
    """
    if not session_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="session_id query parameter is required",
        )

    gateway = _get_session_gateway()
    try:
        timeline = await gateway.get_channel_timeline(
            tenant_id=tenant_id,
            session_id=session_id,
        )
    except ValueError as exc:
        logger.error("Collaboration session not found: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Resource not found",
        )

    entries = [
        ChannelTransitionEntry(
            channel=str(entry.get("channel", "")),
            event=str(entry.get("event", "")),
            timestamp=str(entry.get("timestamp", "")),
            user_id=entry.get("user_id"),
        )
        for entry in timeline
    ]

    return ChannelTimelineResponse(
        task_id=task_id,
        session_id=session_id,
        timeline=entries,
    )
