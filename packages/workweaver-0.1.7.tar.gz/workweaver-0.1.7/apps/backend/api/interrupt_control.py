"""
Interrupt Control API endpoints (TASK-3.8.006).

This module implements API endpoints for human interrupt control following legacy P1.3.6:
- POST /api/v1/sessions/{id}/pause - Set status=paused
- POST /api/v1/sessions/{id}/resume - Set status=active
- POST /api/v1/traces/{id}/cancel - Set status=cancelled, run compensation
- POST /api/v1/traces/{id}/approve - Clear approval gate

Multi-tenant invariant: All operations are tenant-scoped via X-Tenant-ID header.
Cross-tenant operations are rejected at the API layer.
"""

import logging
from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException, Path, Request, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, get_verified_user_id
from apps.backend.schemas.error_response import ErrorResponse
from apps.backend.services.approval_gates import get_approval_gates
from apps.backend.services.approval_service import ApprovalService
from apps.backend.services.billing.compensation import (
    execute_compensation_for_trace,
)
from apps.backend.services.human_judgment_service import HumanJudgmentError, HumanJudgmentService
from apps.backend.services.interrupt_state_store import (
    get_interrupt_state_store,
)

logger = logging.getLogger(__name__)

# Router
router = APIRouter(
    prefix="/api/v1",
    tags=["interrupt-control"],
)


def _extract_interrupt_tenant_header(request: Request) -> str:
    """Return the raw legacy tenant header used by interrupt-control routes."""
    return str(
        request.headers.get("x-tenant-id")
        or request.headers.get("X-Tenant-Id")
        or request.headers.get("X-Tenant-ID")
        or ""
    ).strip()


def _resolve_interrupt_tenant_id(request: Request, tenant_id: str) -> str:
    """Accept normalized auth tenant IDs while preserving legacy header validation."""
    raw_header = _extract_interrupt_tenant_header(request)
    if not raw_header.startswith("TENANT#"):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "invalid_tenant_format", "detail": "Organization ID must start with TENANT#"},
        )

    normalized_header = raw_header[len("TENANT#") :]
    normalized_tenant = tenant_id[len("TENANT#") :] if tenant_id.startswith("TENANT#") else tenant_id
    if normalized_tenant and normalized_header != normalized_tenant:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": "tenant_mismatch", "detail": "Interrupt request tenant does not match auth context"},
        )

    return raw_header


def _get_human_judgment_service() -> HumanJudgmentService:
    gates = get_approval_gates()
    return HumanJudgmentService(
        approval_service=ApprovalService(approval_gates=gates),
        approval_gates=gates,
        interrupt_state_store=get_interrupt_state_store(),
        compensation_runner=execute_compensation_for_trace,
    )


def _raise_judgment_http_error(exc: HumanJudgmentError) -> None:
    raise HTTPException(
        status_code=exc.status_code,
        detail={
            "error": exc.code,
            "detail": str(exc),
        },
    ) from exc


# =============================================================================
# Request/Response Models
# =============================================================================


class PauseSessionRequest(BaseModel):
    """Request to pause a session."""

    reason: str | None = Field(
        None,
        description="Reason for pausing the session",
        json_schema_extra={"example": "Human intervention required"},
    )
    set_by_user_id: str | None = Field(
        default=None,
        description="Deprecated. Actor is resolved from authenticated context.",
        json_schema_extra={"example": "user_123"},
    )
    scope: str = Field(
        default="trace",
        description="Scope of pause (trace or session)",
        pattern="^(trace|session)$",
    )


class PauseSessionResponse(BaseModel):
    """Response to pause session request."""

    success: bool
    message: str
    session_id: str
    previous_state: str
    current_state: str
    paused_by: str
    paused_at: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class ResumeSessionRequest(BaseModel):
    """Request to resume a paused session."""

    reason: str | None = Field(
        None,
        description="Reason for resuming the session",
        json_schema_extra={"example": "Issue resolved, continuing execution"},
    )
    set_by_user_id: str | None = Field(
        default=None,
        description="Deprecated. Actor is resolved from authenticated context.",
        json_schema_extra={"example": "user_123"},
    )


class ResumeSessionResponse(BaseModel):
    """Response to resume session request."""

    success: bool
    message: str
    session_id: str
    previous_state: str
    current_state: str
    resumed_by: str
    resumed_at: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class CancelTraceRequest(BaseModel):
    """Request to cancel a trace."""

    reason: str | None = Field(
        None,
        description="Reason for cancellation",
        json_schema_extra={"example": "Customer requested to stop"},
    )
    set_by_user_id: str | None = Field(
        default=None,
        description="Deprecated. Actor is resolved from authenticated context.",
        json_schema_extra={"example": "user_123"},
    )
    executed_actions: list[dict[str, Any]] = Field(
        default_factory=list,
        description="List of executed actions for compensation",
    )
    run_compensation: bool = Field(
        default=True,
        description="Whether to run compensation on reversible actions",
    )


class CancelTraceResponse(BaseModel):
    """Response to cancel trace request."""

    success: bool
    message: str
    trace_id: str
    previous_state: str
    current_state: str
    cancelled_by: str
    cancelled_at: str
    compensation_summary: dict[str, Any] | None = None
    metadata: dict[str, Any] = Field(default_factory=dict)


class ApproveTraceRequest(BaseModel):
    """Request to approve a trace action."""

    approval_request_id: str = Field(
        ...,
        description="ID of the approval request to approve",
        json_schema_extra={"example": "apr_123"},
    )
    approved_by: str | None = Field(
        default=None,
        description="Deprecated. Actor is resolved from authenticated context.",
        json_schema_extra={"example": "user_123"},
    )
    reason: str | None = Field(
        None,
        description="Reason for approval",
        json_schema_extra={"example": "Verified with customer, proceed"},
    )


class ApproveTraceResponse(BaseModel):
    """Response to approve trace request."""

    success: bool
    message: str
    approval_request_id: str
    previous_status: str
    current_status: str
    approved_by: str
    approved_at: str
    metadata: dict[str, Any] = Field(default_factory=dict)



# =============================================================================
# API Endpoints
# =============================================================================


@router.post(
    "/sessions/{session_id}/pause",
    response_model=PauseSessionResponse,
    status_code=status.HTTP_200_OK,
    responses={
        400: {"model": ErrorResponse, "description": "Invalid request"},
        403: {"model": ErrorResponse, "description": "Cross-tenant access rejected"},
        404: {"model": ErrorResponse, "description": "Session not found"},
        409: {"model": ErrorResponse, "description": "Session already paused"},
    },
)
async def pause_session(
    request_context: Request,
    session_id: str = Path(..., description="Session ID to pause"),
    request: PauseSessionRequest = Body(...),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
) -> PauseSessionResponse:
    """Pause a session (legacy P1.3.6).

    Halts execution before the next tool call. Session state transitions:
    - ACTIVE → PAUSED

    Args:
        session_id: Session ID to pause
        request: Pause request with reason and user ID
        tenant_id: Verified tenant ID from authentication context

    Returns:
        PauseSessionResponse with updated state

    Raises:
        HTTPException: 400 if invalid state transition
        HTTPException: 403 if cross-tenant access
        HTTPException: 404 if session not found
        HTTPException: 409 if already paused
    """
    logger.info("Pause request for session %s by user %s", session_id, actor_id)

    canonical_tenant_id = _resolve_interrupt_tenant_id(request_context, tenant_id)
    try:
        result = _get_human_judgment_service().pause_session(
            tenant_id=canonical_tenant_id,
            session_id=session_id,
            actor_id=actor_id,
            reason=request.reason,
            scope=request.scope,
            source="interrupt_control",
        )
    except HumanJudgmentError as exc:
        _raise_judgment_http_error(exc)

    return PauseSessionResponse(
        success=True,
        message=f"Session {session_id} paused successfully",
        session_id=session_id,
        previous_state=result["previous_state"],
        current_state=result["current_state"],
        paused_by=actor_id,
        paused_at=result["acted_at"],
        metadata={
            "reason": request.reason,
            "scope": request.scope,
        },
    )


@router.post(
    "/sessions/{session_id}/resume",
    response_model=ResumeSessionResponse,
    status_code=status.HTTP_200_OK,
    responses={
        400: {"model": ErrorResponse, "description": "Invalid request"},
        403: {"model": ErrorResponse, "description": "Cross-tenant access rejected"},
        404: {"model": ErrorResponse, "description": "Session not found"},
        409: {"model": ErrorResponse, "description": "Session not paused"},
    },
)
async def resume_session(
    request_context: Request,
    session_id: str = Path(..., description="Session ID to resume"),
    request: ResumeSessionRequest = Body(...),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
) -> ResumeSessionResponse:
    """Resume a paused session (legacy P1.3.6).

    Resumes execution of a paused session. Session state transitions:
    - PAUSED → ACTIVE

    Args:
        session_id: Session ID to resume
        request: Resume request with reason and user ID
        tenant_id: Verified tenant ID from authentication context

    Returns:
        ResumeSessionResponse with updated state

    Raises:
        HTTPException: 400 if invalid state transition
        HTTPException: 403 if cross-tenant access
        HTTPException: 404 if session not found
        HTTPException: 409 if not paused
    """
    logger.info("Resume request for session %s by user %s", session_id, actor_id)

    canonical_tenant_id = _resolve_interrupt_tenant_id(request_context, tenant_id)
    try:
        result = _get_human_judgment_service().resume_session(
            tenant_id=canonical_tenant_id,
            session_id=session_id,
            actor_id=actor_id,
            reason=request.reason,
            source="interrupt_control",
        )
    except HumanJudgmentError as exc:
        _raise_judgment_http_error(exc)

    return ResumeSessionResponse(
        success=True,
        message=f"Session {session_id} resumed successfully",
        session_id=session_id,
        previous_state=result["previous_state"],
        current_state=result["current_state"],
        resumed_by=actor_id,
        resumed_at=result["acted_at"],
        metadata={
            "reason": request.reason,
        },
    )


@router.post(
    "/traces/{trace_id}/cancel",
    response_model=CancelTraceResponse,
    status_code=status.HTTP_200_OK,
    responses={
        400: {"model": ErrorResponse, "description": "Invalid request"},
        403: {"model": ErrorResponse, "description": "Cross-tenant access rejected"},
        404: {"model": ErrorResponse, "description": "Trace not found"},
    },
)
async def cancel_trace(
    request_context: Request,
    trace_id: str = Path(..., description="Trace ID to cancel"),
    request: CancelTraceRequest = Body(...),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
) -> CancelTraceResponse:
    """Cancel a trace and run compensation (legacy P1.3.6).

    Stops future steps in the trace and runs compensation for reversible actions.
    Session state transitions:
    - ACTIVE → CANCELLED (terminal)

    Compensation:
    - Reversible actions (calendar.*, crm.update_lead): Undo
    - Irreversible actions (whatsapp.send, email.send): Log

    Args:
        trace_id: Trace ID to cancel
        request: Cancel request with reason, user ID, and executed actions
        tenant_id: Verified tenant ID from authentication context

    Returns:
        CancelTraceResponse with compensation summary

    Raises:
        HTTPException: 400 if invalid state transition
        HTTPException: 403 if cross-tenant access
        HTTPException: 404 if trace not found
    """
    logger.info(
        "Cancel request for trace %s by user %s, run_compensation=%s",
        trace_id,
        actor_id,
        request.run_compensation,
    )

    canonical_tenant_id = _resolve_interrupt_tenant_id(request_context, tenant_id)
    try:
        result = await _get_human_judgment_service().cancel_trace(
            tenant_id=canonical_tenant_id,
            trace_id=trace_id,
            actor_id=actor_id,
            reason=request.reason,
            executed_actions=request.executed_actions,
            run_compensation=request.run_compensation,
            source="interrupt_control",
        )
    except HumanJudgmentError as exc:
        _raise_judgment_http_error(exc)

    return CancelTraceResponse(
        success=True,
        message=f"Trace {trace_id} cancelled successfully",
        trace_id=trace_id,
        previous_state=result["previous_state"],
        current_state=result["current_state"],
        cancelled_by=actor_id,
        cancelled_at=result["acted_at"],
        compensation_summary=result["compensation_summary"],
        metadata={
            "reason": request.reason,
            "run_compensation": request.run_compensation,
            "executed_actions_count": len(request.executed_actions),
        },
    )


@router.post(
    "/traces/{trace_id}/approve",
    response_model=ApproveTraceResponse,
    status_code=status.HTTP_200_OK,
    responses={
        400: {"model": ErrorResponse, "description": "Invalid request"},
        403: {"model": ErrorResponse, "description": "Cross-tenant access rejected"},
        404: {"model": ErrorResponse, "description": "Approval request not found"},
        409: {"model": ErrorResponse, "description": "Approval already processed"},
    },
)
async def approve_trace(
    request_context: Request,
    trace_id: str = Path(..., description="Trace ID bound to the approval request"),
    request: ApproveTraceRequest = Body(...),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
) -> ApproveTraceResponse:
    """Approve a trace action (legacy P1.3.6).

    Clears the approval gate for an irreversible action. Approval status transitions:
    - PENDING → APPROVED

    Args:
        trace_id: Trace ID (for routing only, approval_id is used)
        request: Approve request with approval ID, user ID, and reason
        tenant_id: Verified tenant ID from authentication context

    Returns:
        ApproveTraceResponse with updated status

    Raises:
        HTTPException: 400 if invalid status transition
        HTTPException: 403 if cross-tenant access
        HTTPException: 404 if approval request not found
        HTTPException: 409 if already processed
    """
    logger.info("Approve request for approval %s by user %s", request.approval_request_id, actor_id)

    canonical_tenant_id = _resolve_interrupt_tenant_id(request_context, tenant_id)
    try:
        result = await _get_human_judgment_service().approve_request(
            tenant_id=canonical_tenant_id,
            request_id=request.approval_request_id,
            actor_id=actor_id,
            reason=request.reason,
            expected_trace_id=trace_id,
            source="interrupt_control",
        )
    except HumanJudgmentError as exc:
        _raise_judgment_http_error(exc)

    return ApproveTraceResponse(
        success=True,
        message=f"Approval request {request.approval_request_id} approved successfully",
        approval_request_id=request.approval_request_id,
        previous_status=result["previous_status"],
        current_status=result["current_status"],
        approved_by=actor_id,
        approved_at=result["acted_at"],
        metadata={
            "reason": request.reason,
            "tool_name": result["tool_name"],
        },
    )


# =============================================================================
# Convenience Functions
# =============================================================================


def get_interrupt_control_router() -> APIRouter:
    """Get interrupt control router.

    Returns:
        APIRouter with interrupt control endpoints
    """
    return router
