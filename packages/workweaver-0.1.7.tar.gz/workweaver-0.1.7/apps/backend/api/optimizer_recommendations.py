"""Optimizer recommendations API.

Surfaces the Pareto-reconciled L3 recommendations and the underlying frontier
so dashboards (Swarm dashboard, Weekly Upgrade Digest preview) can render the
single recommended template per goal class plus the tradeoff explanation.
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.schemas.error_response import ErrorResponse
from apps.backend.services.optimizers.pareto_reconciler import (
    LOSS_AXES,
    LOSS_AXIS_TO_METRIC,
    ParetoReconciler,
    RECONCILED_PROPOSAL_TYPE,
)

router = APIRouter(prefix="/api/v1/optimizer", tags=["optimizer"])


def _service() -> ParetoReconciler:
    return ParetoReconciler()


@router.get("/recommendations", responses={503: {"model": ErrorResponse}})
async def list_recommendations(
    service: ParetoReconciler = Depends(_service),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return all reconciled recommendations for the tenant."""

    records = service.list_recommendations(tenant_id)
    return {
        "tenant_id": tenant_id,
        "count": len(records),
        "axes": list(LOSS_AXES),
        "axis_metrics": dict(LOSS_AXIS_TO_METRIC),
        "proposal_type": RECONCILED_PROPOSAL_TYPE,
        "recommendations": [_card(record) for record in records],
    }


@router.get("/recommendations/{goal_class}", responses={404: {"model": ErrorResponse}})
async def show_recommendation(
    goal_class: str,
    service: ParetoReconciler = Depends(_service),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return the recommendation for one goal class plus its Pareto frontier."""

    records = service.list_recommendations(tenant_id, goal_class=goal_class)
    if not records:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No reconciled recommendation for goal_class={goal_class}",
        )
    record = records[0]
    return {
        "tenant_id": tenant_id,
        "goal_class": goal_class,
        "axes": list(LOSS_AXES),
        "axis_metrics": dict(LOSS_AXIS_TO_METRIC),
        "recommendation": _card(record),
        "pareto_frontier": _frontier(record),
        "dominated": _dominated(record),
    }


def _card(record: dict[str, Any]) -> dict[str, Any]:
    target_raw = record.get("target")
    target: dict[str, Any] = target_raw if isinstance(target_raw, dict) else {}
    metrics_raw = record.get("metrics")
    metrics: dict[str, Any] = metrics_raw if isinstance(metrics_raw, dict) else {}
    return {
        "proposal_id": record.get("proposal_id"),
        "goal_class": str(target.get("goal_class") or ""),
        "plan_template_id": str(target.get("plan_template_id") or ""),
        "title": record.get("title"),
        "rationale": record.get("rationale"),
        "metrics": metrics,
        "status": record.get("status"),
        "created_at": record.get("created_at"),
        "updated_at": record.get("updated_at"),
    }


def _frontier(record: dict[str, Any]) -> list[dict[str, Any]]:
    metrics_raw = record.get("metrics")
    metrics: dict[str, Any] = metrics_raw if isinstance(metrics_raw, dict) else {}
    items = metrics.get("frontier") or []
    return [item for item in items if isinstance(item, dict)]


def _dominated(record: dict[str, Any]) -> list[dict[str, Any]]:
    metrics_raw = record.get("metrics")
    metrics: dict[str, Any] = metrics_raw if isinstance(metrics_raw, dict) else {}
    items = metrics.get("dominated") or []
    return [item for item in items if isinstance(item, dict)]
