"""Collaboration thread and teammate invite APIs for runtime proof/work surfaces."""

from __future__ import annotations

from datetime import datetime, UTC
from typing import Any
from urllib.parse import quote

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, EmailStr, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.models.user import UserRole

router = APIRouter(prefix="/api/v1/collaboration", tags=["collaboration"])

COMMENT_EVENT = "run:collaboration_comment"
WATCHER_EVENT = "run:collaboration_watcher_added"
SHARE_EVENT = "run:collaboration_share_link"
INVITE_EVENT = "run:collaboration_invite_created"
THREAD_EVENTS = {COMMENT_EVENT, WATCHER_EVENT, SHARE_EVENT, INVITE_EVENT}


def _get_evidence_service():
    from apps.backend.services.evidence_ledger import get_evidence_ledger_service

    return get_evidence_ledger_service()


def _get_user_management_service():
    from apps.backend.services.user_management import UserManagementService

    return UserManagementService()


def _safe_iso(value: Any) -> str:
    if isinstance(value, str) and value.strip():
        return value
    return datetime.now(UTC).isoformat()


def _coerce_role(value: str) -> UserRole:
    normalized = str(value or "").strip().lower()
    if normalized == UserRole.ADMIN.value:
        return UserRole.ADMIN
    if normalized == UserRole.MANAGER.value:
        return UserRole.MANAGER
    return UserRole.AGENT


class CollaborationCommentItem(BaseModel):
    evidence_id: str
    body: str
    created_at: str
    author_id: str | None = None
    author_email: str | None = None
    author_label: str | None = None


class CollaborationWatcherItem(BaseModel):
    evidence_id: str
    watcher_email: str
    watcher_label: str
    added_at: str
    added_by: str | None = None


class CollaborationShareItem(BaseModel):
    evidence_id: str
    url: str
    label: str
    channel: str
    created_at: str
    created_by: str | None = None


class CollaborationInviteItem(BaseModel):
    evidence_id: str
    invitation_id: str
    invitee_email: str
    role: str
    invite_url: str
    created_at: str
    created_by: str | None = None


class CollaborationThreadResponse(BaseModel):
    scope_type: str
    scope_id: str
    comments: list[CollaborationCommentItem] = Field(default_factory=list)
    watchers: list[CollaborationWatcherItem] = Field(default_factory=list)
    shares: list[CollaborationShareItem] = Field(default_factory=list)
    invites: list[CollaborationInviteItem] = Field(default_factory=list)


class CollaborationCommentRequest(BaseModel):
    scope_type: str = Field(..., min_length=2, max_length=80)
    scope_id: str = Field(..., min_length=2, max_length=200)
    body: str = Field(..., min_length=1, max_length=2000)
    author_label: str | None = Field(default=None, max_length=120)


class CollaborationWatcherRequest(BaseModel):
    scope_type: str = Field(..., min_length=2, max_length=80)
    scope_id: str = Field(..., min_length=2, max_length=200)
    watcher_email: EmailStr
    watcher_label: str | None = Field(default=None, max_length=160)


class CollaborationShareRequest(BaseModel):
    scope_type: str = Field(..., min_length=2, max_length=80)
    scope_id: str = Field(..., min_length=2, max_length=200)
    url: str = Field(..., min_length=5, max_length=1200)
    label: str = Field(..., min_length=1, max_length=200)
    channel: str = Field(default="browser", min_length=2, max_length=40)


class CollaborationInviteRequest(BaseModel):
    scope_type: str = Field(..., min_length=2, max_length=80)
    scope_id: str = Field(..., min_length=2, max_length=200)
    invitee_email: EmailStr
    role: str = Field(default=UserRole.AGENT.value, min_length=2, max_length=40)
    invite_url: str | None = Field(default=None, max_length=1200)
    note: str | None = Field(default=None, max_length=500)


class CollaborationActionResponse(BaseModel):
    ok: bool = True
    evidence_id: str


class CollaborationInviteResponse(CollaborationActionResponse):
    invitation_id: str
    invitee_email: str
    role: str
    invite_url: str


def _actor_identity(request: Request) -> dict[str, str]:
    """Extract actor identity from verified auth state, not raw client headers."""
    user_id = str(getattr(request.state, "user_id", "") or "").strip()
    email = str(getattr(request.state, "user_email", "") or "").strip().lower()
    # Name is not security-critical (audit label only); fall back to header
    name = str(request.headers.get("x-user-name") or "").strip()
    return {
        "user_id": user_id,
        "email": email,
        "name": name,
    }


def _build_invite_url(invitation_id: str) -> str:
    return f"/runtime/?surface=organizations&invitation_id={quote(invitation_id, safe='')}"


def _thread_payload(items: list[dict[str, Any]]) -> CollaborationThreadResponse:
    comments: list[CollaborationCommentItem] = []
    shares: list[CollaborationShareItem] = []
    invites: list[CollaborationInviteItem] = []
    watcher_map: dict[str, CollaborationWatcherItem] = {}
    scope_type = ""
    scope_id = ""

    for item in items:
        # Scope values are stable within a thread query; capture the first populated pair.
        if not scope_type:
            scope_type = str(item.get("scope_type") or "").strip()
        if not scope_id:
            scope_id = str(item.get("scope_id") or "").strip()

        event_type = str(item.get("event_type") or "").strip()
        evidence_id = str(item.get("evidence_id") or "").strip()
        created_at = _safe_iso(item.get("event_at") or item.get("created_at"))

        if event_type == COMMENT_EVENT:
            body = str(item.get("body") or "").strip()
            if body:
                comments.append(
                    CollaborationCommentItem(
                        evidence_id=evidence_id,
                        body=body,
                        created_at=created_at,
                        author_id=str(item.get("author_id") or "").strip() or None,
                        author_email=str(item.get("author_email") or "").strip() or None,
                        author_label=str(item.get("author_label") or "").strip() or None,
                    )
                )
            continue

        if event_type == WATCHER_EVENT:
            watcher_email = str(item.get("watcher_email") or "").strip().lower()
            if watcher_email:
                watcher_map[watcher_email] = CollaborationWatcherItem(
                    evidence_id=evidence_id,
                    watcher_email=watcher_email,
                    watcher_label=str(item.get("watcher_label") or watcher_email).strip() or watcher_email,
                    added_at=created_at,
                    added_by=str(item.get("added_by") or "").strip() or None,
                )
            continue

        if event_type == SHARE_EVENT:
            share_url = str(item.get("share_url") or item.get("url") or "").strip()
            if share_url:
                shares.append(
                    CollaborationShareItem(
                        evidence_id=evidence_id,
                        url=share_url,
                        label=str(item.get("share_label") or item.get("label") or "Shared link").strip()
                        or "Shared link",
                        channel=str(item.get("share_channel") or item.get("channel") or "browser").strip() or "browser",
                        created_at=created_at,
                        created_by=str(item.get("created_by") or "").strip() or None,
                    )
                )
            continue

        if event_type == INVITE_EVENT:
            invitation_id = str(item.get("invitation_id") or "").strip()
            invitee_email = str(item.get("invitee_email") or "").strip().lower()
            if invitation_id and invitee_email:
                invites.append(
                    CollaborationInviteItem(
                        evidence_id=evidence_id,
                        invitation_id=invitation_id,
                        invitee_email=invitee_email,
                        role=str(item.get("role") or UserRole.AGENT.value).strip() or UserRole.AGENT.value,
                        invite_url=str(item.get("invite_url") or _build_invite_url(invitation_id)).strip(),
                        created_at=created_at,
                        created_by=str(item.get("created_by") or "").strip() or None,
                    )
                )

    comments.sort(key=lambda item: item.created_at)
    shares.sort(key=lambda item: item.created_at, reverse=True)
    invites.sort(key=lambda item: item.created_at, reverse=True)
    watchers = sorted(watcher_map.values(), key=lambda item: item.watcher_label.lower())

    return CollaborationThreadResponse(
        scope_type=scope_type,
        scope_id=scope_id,
        comments=comments,
        watchers=watchers,
        shares=shares,
        invites=invites,
    )


@router.get("/thread", response_model=CollaborationThreadResponse)
async def get_collaboration_thread(
    scope_type: str = Query(..., min_length=2, max_length=80),
    scope_id: str = Query(..., min_length=2, max_length=200),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CollaborationThreadResponse:
    service = _get_evidence_service()
    items = service.query_by_scope(
        tenant_id=tenant_id,
        scope_type=scope_type,
        scope_id=scope_id,
        limit=200,
    )
    thread_items = [item for item in items if str(item.get("event_type") or "").strip() in THREAD_EVENTS]
    response = _thread_payload(thread_items)
    if not response.scope_type:
        response.scope_type = scope_type
    if not response.scope_id:
        response.scope_id = scope_id
    return response


@router.post("/comments", response_model=CollaborationActionResponse, status_code=status.HTTP_201_CREATED)
async def create_comment(
    request: CollaborationCommentRequest,
    actor: dict[str, str] = Depends(_actor_identity),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CollaborationActionResponse:
    body = request.body.strip()
    if not body:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Comment body is required")

    evidence = _get_evidence_service().ingest(
        tenant_id=tenant_id,
        event_type=COMMENT_EVENT,
        scope_type=request.scope_type,
        scope_id=request.scope_id,
        data={
            "body": body,
            "author_id": actor["user_id"] or None,
            "author_email": actor["email"] or None,
            "author_label": (
                request.author_label or actor["name"] or actor["email"] or actor["user_id"] or "Teammate"
            ).strip(),
        },
        artifact_payload={
            "body": body,
            "scope_type": request.scope_type,
            "scope_id": request.scope_id,
        },
    )
    return CollaborationActionResponse(evidence_id=str(evidence.get("evidence_id") or ""))


@router.post("/watchers", response_model=CollaborationActionResponse, status_code=status.HTTP_201_CREATED)
async def add_watcher(
    request: CollaborationWatcherRequest,
    actor: dict[str, str] = Depends(_actor_identity),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CollaborationActionResponse:
    watcher_email = str(request.watcher_email).strip().lower()
    evidence = _get_evidence_service().ingest(
        tenant_id=tenant_id,
        event_type=WATCHER_EVENT,
        scope_type=request.scope_type,
        scope_id=request.scope_id,
        data={
            "watcher_email": watcher_email,
            "watcher_label": (request.watcher_label or watcher_email).strip() or watcher_email,
            "added_by": actor["email"] or actor["user_id"] or None,
        },
        artifact_payload={
            "watcher_email": watcher_email,
            "scope_type": request.scope_type,
            "scope_id": request.scope_id,
        },
    )
    return CollaborationActionResponse(evidence_id=str(evidence.get("evidence_id") or ""))


@router.post("/share-link", response_model=CollaborationActionResponse, status_code=status.HTTP_201_CREATED)
async def record_share_link(
    request: CollaborationShareRequest,
    actor: dict[str, str] = Depends(_actor_identity),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CollaborationActionResponse:
    evidence = _get_evidence_service().ingest(
        tenant_id=tenant_id,
        event_type=SHARE_EVENT,
        scope_type=request.scope_type,
        scope_id=request.scope_id,
        data={
            "share_url": request.url.strip(),
            "share_label": request.label.strip(),
            "share_channel": request.channel.strip().lower(),
            "created_by": actor["email"] or actor["user_id"] or None,
        },
        artifact_payload={
            "url": request.url.strip(),
            "scope_type": request.scope_type,
            "scope_id": request.scope_id,
        },
    )
    return CollaborationActionResponse(evidence_id=str(evidence.get("evidence_id") or ""))


@router.post("/invites", response_model=CollaborationInviteResponse, status_code=status.HTTP_201_CREATED)
async def create_teammate_invite(
    request: CollaborationInviteRequest,
    actor: dict[str, str] = Depends(_actor_identity),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CollaborationInviteResponse:
    service = _get_user_management_service()
    invitation = service.create_invitation(
        tenant_id=tenant_id,
        inviter_email=actor["email"] or "workspace@workweaver.ai",
        invitee_email=str(request.invitee_email).strip().lower(),
        role=_coerce_role(request.role),
    )
    invite_url = str(request.invite_url or _build_invite_url(invitation.invitation_id)).strip()
    evidence = _get_evidence_service().ingest(
        tenant_id=tenant_id,
        event_type=INVITE_EVENT,
        scope_type=request.scope_type,
        scope_id=request.scope_id,
        data={
            "invitation_id": invitation.invitation_id,
            "invitee_email": invitation.invitee_email,
            "role": invitation.role.value,
            "invite_url": invite_url,
            "created_by": actor["email"] or actor["user_id"] or None,
            "note": str(request.note or "").strip() or None,
        },
        artifact_payload={
            "invitation_id": invitation.invitation_id,
            "invitee_email": invitation.invitee_email,
            "scope_type": request.scope_type,
            "scope_id": request.scope_id,
        },
    )
    return CollaborationInviteResponse(
        evidence_id=str(evidence.get("evidence_id") or ""),
        invitation_id=invitation.invitation_id,
        invitee_email=invitation.invitee_email,
        role=invitation.role.value,
        invite_url=invite_url,
    )
