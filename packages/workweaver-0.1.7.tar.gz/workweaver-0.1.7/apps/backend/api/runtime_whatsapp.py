"""
Workweaver Runtime WhatsApp API Endpoints

Bridges WhatsApp conversations to tenant-specific Workweaver Runtime AI instances.

Endpoints:
- POST /api/v1/runtime/whatsapp/process   — Process WhatsApp message through Workweaver Runtime
- GET  /api/v1/runtime/whatsapp/sessions  — List active WhatsApp-Runtime sessions
- GET  /api/v1/runtime/whatsapp/health    — Check Workweaver Runtime WhatsApp bridge health
- POST /api/v1/runtime/whatsapp/configure — Configure Workweaver Runtime WhatsApp for tenant
"""

from __future__ import annotations
from apps.backend.config.table_names import resolve_table

import logging
from apps.backend.config.region import AWS_REGION
from typing import Any

import boto3
from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, Field

from apps.backend.services.channels.whatsapp.runtime_bridge import WorkweaverWhatsAppBridge

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    resolve_verified_tenant_id,
)
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
logger = logging.getLogger(__name__)

router = APIRouter()


# ---------------------------------------------------------------------------
# Request / Response Models
# ---------------------------------------------------------------------------


class ProcessMessageRequest(BaseModel):
    """Process an inbound WhatsApp message through Workweaver Runtime."""

    conversation_id: str = Field(
        ...,
        description="WhatsApp conversation thread ID",
        examples=["CONV#001"],
    )
    message_text: str = Field(
        ...,
        description="WhatsApp message content",
        examples=["Hello, I need help with my order"],
    )
    from_number: str = Field(
        ...,
        description="Customer phone number in E.164 format",
        examples=["+1234567890"],
    )
    media_url: str | None = Field(
        default=None,
        description="Optional URL of media attachment",
    )
    metadata: dict[str, Any] | None = Field(
        default=None,
        description="Additional context metadata",
    )


class ProcessMessageResponse(BaseModel):
    """Response from processing a WhatsApp message through Workweaver Runtime."""

    status: str = Field(description="Processing status (ok, error, no_endpoint, unavailable)")
    reply: dict[str, Any] | None = Field(
        default=None,
        description="Reply message details",
    )
    error: str | None = Field(
        default=None,
        description="Error detail if status is error",
    )


class SessionInfo(BaseModel):
    """Active WhatsApp-Workweaver Runtime conversation session."""

    conversation_id: str
    created_at: str
    last_activity: str
    message_count: int
    active: bool


class SessionsResponse(BaseModel):
    """List of active sessions for a tenant."""

    tenant_id: str
    sessions: list[SessionInfo]
    total: int


class HealthResponse(BaseModel):
    """Health status of the Workweaver Runtime WhatsApp bridge."""

    status: str
    service: str
    tenant_health: dict[str, Any] | None = None


class ConfigureRequest(BaseModel):
    """Configure Workweaver Runtime WhatsApp integration for a tenant."""

    endpoint: str = Field(
        ...,
        description="Workweaver Runtime gateway endpoint URL",
        examples=["https://runtime.tenant-abc.example.com"],
    )
    gateway_token: str = Field(
        ...,
        description="Authentication token for Workweaver Runtime gateway",
    )


class ConfigureResponse(BaseModel):
    """Result of configuring Workweaver Runtime WhatsApp integration."""

    success: bool
    tenant_id: str
    message: str


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/process",
    response_model=ProcessMessageResponse,
    summary="Process WhatsApp message through Workweaver Runtime",
    description=(
        "Forward an inbound WhatsApp message to the tenant's dedicated "
        "Workweaver Runtime AI instance and return the AI-generated reply."
    ),
)
async def process_whatsapp_message(
    request: ProcessMessageRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ProcessMessageResponse:
    """
    Process an inbound WhatsApp message through Workweaver Runtime.

    Routes the message to the tenant's dedicated Workweaver Runtime instance,
    waits for the AI-generated reply, and returns it.
    """
    try:
        async with WorkweaverWhatsAppBridge(tenant_id) as bridge:
            result = await bridge.forward_message(
                conversation_id=request.conversation_id,
                message_text=request.message_text,
                from_number=request.from_number,
                media_url=request.media_url,
                metadata=request.metadata,
            )

        return ProcessMessageResponse(
            status=result.get("status", "ok"),
            reply=result.get("reply"),
            error=result.get("error"),
        )

    except Exception as exc:
        logger.error(
            "Unexpected error processing WhatsApp message for %s: %s",
            tenant_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to process WhatsApp message through Workweaver Runtime",
        )


@router.get(
    "/sessions",
    response_model=SessionsResponse,
    summary="List active WhatsApp-Workweaver Runtime sessions",
    description=(
        "Return all active conversation sessions between WhatsApp and the tenant's Workweaver Runtime instance."
    ),
)
async def list_sessions(
    tenant_id: str = Depends(get_verified_tenant_id),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> SessionsResponse:
    """List active WhatsApp-Workweaver Runtime sessions for a tenant."""
    try:
        async with WorkweaverWhatsAppBridge(tenant_id) as bridge:
            raw_sessions = await bridge.list_active_sessions()

        sessions, _total = paginate_items([SessionInfo(**s) for s in raw_sessions], pagination)
        return SessionsResponse(
            tenant_id=tenant_id,
            sessions=sessions,
            total=len(sessions),
        )

    except Exception as exc:
        logger.error(
            "Error listing sessions for %s: %s",
            tenant_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list sessions",
        )


def _get_tenant_id_for_health(
    request: Request,
    include_tenant_health: bool = Query(
        default=False,
        description="Set true to include authenticated tenant instance health",
    ),
) -> str | None:
    """Resolve tenant_id for authenticated tenant health checks only."""
    if not include_tenant_health:
        return None

    return resolve_verified_tenant_id(request)


@router.get(
    "/health",
    response_model=HealthResponse,
    summary="Check Workweaver Runtime WhatsApp bridge health",
    description=(
        "Returns overall bridge health. Set include_tenant_health=true to "
        "also check the authenticated tenant's Workweaver Runtime instance."
    ),
)
async def bridge_health(
    tenant_id: str | None = Depends(_get_tenant_id_for_health),
) -> HealthResponse:
    """Health check for the Workweaver Runtime WhatsApp bridge."""
    if tenant_id:
        try:
            async with WorkweaverWhatsAppBridge(tenant_id) as bridge:
                tenant_health = await bridge.check_instance_health()
        except Exception as exc:
            logger.warning("Health check failed for %s: %s", tenant_id, exc)
            tenant_health = {"healthy": False, "reason": str(exc)}

        return HealthResponse(
            status="healthy",
            service="runtime-whatsapp-bridge",
            tenant_health=tenant_health,
        )

    return HealthResponse(
        status="healthy",
        service="runtime-whatsapp-bridge",
    )


@router.post(
    "/configure",
    response_model=ConfigureResponse,
    summary="Configure Workweaver Runtime WhatsApp integration for tenant",
    description=(
        "Store the tenant's Workweaver Runtime gateway endpoint and authentication token "
        "in DynamoDB so WhatsApp messages can be routed to their AI instance."
    ),
)
async def configure_tenant(
    request: ConfigureRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ConfigureResponse:
    """
    Persist Workweaver Runtime configuration for a tenant.

    Writes the endpoint URL and gateway token to DynamoDB under the
    RUNTIME#CONFIG sort key for fast lookup during message processing.
    """
    try:
        dynamodb = boto3.resource(
            "dynamodb",
            region_name=AWS_REGION,
        )
        table = dynamodb.Table(resolve_table("tenants"))

        table.put_item(
            Item={
                "pk": tenant_id,
                "sk": "RUNTIME#CONFIG",
                "endpoint": request.endpoint,
                "gateway_token": request.gateway_token,
                "service": "runtime-whatsapp",
            }
        )

        logger.info(
            "Workweaver Runtime WhatsApp configured for tenant %s endpoint=%s",
            tenant_id,
            request.endpoint,
        )

        return ConfigureResponse(
            success=True,
            tenant_id=tenant_id,
            message=f"Workweaver Runtime WhatsApp integration configured for {tenant_id}",
        )

    except Exception as exc:
        logger.error(
            "Failed to configure Workweaver Runtime WhatsApp for %s: %s",
            tenant_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to configure Workweaver Runtime WhatsApp integration",
        )
