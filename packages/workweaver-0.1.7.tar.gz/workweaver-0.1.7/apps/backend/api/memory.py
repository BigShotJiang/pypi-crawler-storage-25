"""Memory API for Workweaver's Memory system (Part 7).

Built on top of the Evidence Ledger service for hierarchical context resolution,
hybrid search, and policy-aware memory management.

Part 17 extensions: 4-tab memory model (journal, facts, patterns, rules).
"""

import logging
from typing import Any

from botocore.exceptions import BotoCoreError, ClientError
from fastapi import APIRouter, Depends, File, HTTPException, Query, Request, UploadFile, status
from fastapi.responses import JSONResponse
from pydantic import BaseModel, Field, field_validator

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, get_verified_user_id
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.services.sourced_recall import (
    apply_memory_review_overlay,
    build_memory_provenance_links,
    coerce_time_offset_seconds,
    coerce_memory_mapping,
)
from apps.backend.services.upload_validation import (
    MEMORY_UPLOAD_MAX_SIZE_BYTES,
    UploadValidationError,
    build_memory_upload_rejection,
    get_memory_upload_capabilities,
    validate_memory_upload,
)
from apps.backend.schemas.error_response import safe_error_detail
from apps.backend.services.billing import MeteringService
from apps.backend.services.usage_tracker import UsageMetricType
from apps.backend.utils.tenant import normalize_tenant_id

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/memory", tags=["memory"])
_MEMORY_BACKEND_EXCEPTIONS = (BotoCoreError, ClientError, ConnectionError, TimeoutError, OSError)


def _get_memory_service():
    """Lazy import for MemoryService -- the single memory authority.

    Part 17 routes (journal, facts, patterns, rules, search, decision-trees,
    improvements) and all plugin-contract memory operations delegate here.
    """
    from apps.backend.services.memory.service import get_memory_service

    return get_memory_service()


def _get_approval_service():
    """Lazy import for canonical approval + learning improvement operations."""
    from apps.backend.services.approval_service import ApprovalService

    return ApprovalService(memory_service=_get_memory_service())


def _get_decision_tree_service():
    """Lazy import for decision-tree extraction and consolidation."""
    from apps.backend.services.decision_tree_service import DecisionTreeService

    return DecisionTreeService(memory_service=_get_memory_service())


def _get_attachment_ingestion_service():
    """Lazy import for canonical file ingestion via unified service."""
    from apps.backend.services.unified_file_ingestion import get_unified_ingestion_service

    return get_unified_ingestion_service()


def _get_workmemory_client():
    """Lazy import for direct WorkMemory item lookups."""
    from apps.backend.services.memory.runtime import get_runtime

    return get_runtime()


def _get_version_history_service():
    """Lazy import for mutable review history attached to memory items."""
    from apps.backend.workmemory.api.routes.version_history import get_version_history_service

    return get_version_history_service()


async def _meter(
    *,
    tenant_id: str,
    metric: UsageMetricType,
    quantity: float,
    unit: str,
    idempotency_key: str,
    metadata: dict,
) -> None:
    """Record metering event through canonical gateway (best-effort)."""
    try:
        await MeteringService().meter(
            tenant_id=tenant_id,
            metric=metric,
            quantity=quantity,
            unit=unit,
            idempotency_key=idempotency_key,
            metadata=metadata,
        )
    except Exception:
        logger.warning(
            "Memory metering failed tenant=%s metric=%s",
            tenant_id,
            metric.value,
            exc_info=True,
        )


def _raise_memory_service_unavailable(*, operation: str, tenant_id: str, exc: Exception) -> None:
    logger.warning(
        "memory.%s unavailable tenant=%s: %s",
        operation,
        tenant_id,
        exc,
        exc_info=True,
    )
    raise HTTPException(status_code=503, detail="Memory service unavailable") from exc


def _memory_provenance_links(item_id: str, *, item: dict[str, Any], metadata: dict[str, Any]) -> dict[str, str]:
    meeting_id = str(metadata.get("meeting_id") or item.get("meeting_id") or "").strip() or None
    time_offset_sec = coerce_time_offset_seconds(
        metadata.get("time_offset_sec"),
        metadata.get("offset_sec"),
    )
    return build_memory_provenance_links(
        item_id,
        meeting_id=meeting_id,
        time_offset_sec=time_offset_sec,
    )


def _canonical_memory_history_tenant_id(tenant_id: str) -> str:
    return normalize_tenant_id(str(tenant_id or "").strip())


# Request Models


class RememberRequest(BaseModel):
    """Request to record a new memory."""

    memory_type: str = Field(..., max_length=50, description="fact|preference|episode|tool_capability")
    scope_type: str = Field(..., max_length=50, description="agent|team|department|org|work_function|...")
    scope_id: str = Field(..., max_length=100, description="Scope identifier")
    content: dict = Field(..., description="Memory content")
    importance: int = Field(5, ge=1, le=10, description="Importance score (1-10)")
    reliability: float = Field(0.8, ge=0.0, le=1.0, description="Reliability score (0.0-1.0)")
    ttl_days: int | None = Field(None, description="Time-to-live in days")
    source_event_id: str | None = Field(None, max_length=100, description="Source event ID for provenance")
    allow_scope_promotion: bool = Field(
        default=False,
        description="Must be true to write non-agent scopes",
    )
    function_id: str | None = Field(
        default=None,
        max_length=100,
        description=(
            "Optional Work Function id (#3032). When set, the persisted "
            "record carries function_id as a top-level attribute so the "
            "query-side post-filter (function_id parameter on /api/v1/memory/query) "
            "can match against it. Independent of scope_type/scope_id."
        ),
    )


class ForgetRequest(BaseModel):
    """Request to mark a memory as expired."""

    evidence_id: str = Field(..., max_length=100, description="Evidence ID to forget")


class MemoryQueryRequest(BaseModel):
    """Request to query memories."""

    scope_type: str = Field(
        ...,
        max_length=50,
        description="agent|team|department|org|work_function|...",
    )
    scope_id: str = Field(..., max_length=100, description="Scope identifier")
    memory_types: list[str] | None = Field(None, description="Filter by memory types")
    limit: int = Field(20, ge=1, le=100, description="Maximum results to return")
    function_id: str | None = Field(
        default=None,
        max_length=100,
        description=(
            "Optional Work Function id. When set, results from the primary "
            "scope_type/scope_id partition are post-filtered to items whose "
            "function_id matches OR is unset (the latter remain shared/unscoped "
            "per the filter_items_by_tier contract). This is a *secondary* "
            "filter axis — scope_type/scope_id remains the primary partition. "
            "Function-as-primary-scope (scope_type='work_function') is also "
            "supported but exercises a different path (scope-keyed query, no "
            "post-filter)."
        ),
    )


class PromoteRequest(BaseModel):
    """Request to promote memory to broader scope."""

    evidence_id: str = Field(..., max_length=100, description="Evidence ID to promote")
    new_state: str = Field("active", max_length=50, description="New state after promotion")


# Response Models


class MemoryResponse(BaseModel):
    """Response after recording a memory."""

    evidence_id: str
    memory_type: str
    scope_type: str
    scope_id: str
    state: str
    importance: int
    reliability: float


class MemoryQueryResponse(BaseModel):
    """Response for memory query."""

    items: list[dict]
    count: int


class ContextResolveResponse(BaseModel):
    """Response for hierarchical context resolution."""

    merged_items: list[dict]
    provenance: list[dict]
    scope_chain: list[str]


class MemoryProfileResponse(BaseModel):
    """Response for memory profile."""

    scope_type: str
    scope_id: str
    total_memories: int
    by_type: dict[str, int]
    recent: list[dict]


class HistoricalMemoryItemResponse(BaseModel):
    """Durable historical memory detail returned by citation links."""

    item_id: str
    fact: str
    category: str
    created_at: str | None = None
    source_type: str
    metadata: dict = Field(default_factory=dict)
    provenance: dict = Field(default_factory=dict)
    temporal: dict = Field(default_factory=dict)
    relationship: dict = Field(default_factory=dict)
    source_confidence: float | None = None
    review_state: str = "active"
    superseded_by: str | None = None
    source_event_id: str | None = None
    resource_ref: str | None = None
    memory_scope: str | None = None
    source_link: str
    runtime_href: str
    version_history_link: str
    challenge_link: str
    inspect_link: str


class ChallengeHistoricalMemoryRequest(BaseModel):
    """Challenge a cited memory item and persist a review receipt."""

    reason: str = Field(..., min_length=1, description="Why the cited memory should be reviewed")
    reviewer_id: str | None = Field(default=None, description="Optional explicit reviewer id")

    @field_validator("reason")
    @classmethod
    def validate_reason(cls, value: str) -> str:
        normalized = value.strip()
        if not normalized:
            raise ValueError("Challenge reason cannot be blank")
        return normalized


class ChallengeHistoricalMemoryResponse(BaseModel):
    """Response after challenging a cited memory item."""

    item_id: str
    review_state: str
    challenge_version_id: str
    reason: str
    source_link: str
    version_history_link: str
    challenge_link: str


class AttachmentImportResponse(BaseModel):
    """Response after importing a file into WorkMemory."""

    filename: str
    content_type: str
    size_bytes: int
    detected_content_type: str
    processing_status: str
    success: bool
    item_ids: list[str] = Field(default_factory=list)
    facts_extracted: int = 0
    chunks_processed: int = 0
    warnings: list[str] = Field(default_factory=list)
    omissions: list[str] = Field(default_factory=list)
    errors: list[str] = Field(default_factory=list)
    resource_ref: str | None = None
    source_type: str = "file"


class AttachmentUploadCapabilitiesResponse(BaseModel):
    """Server-owned upload contract consumed by generic dashboard uploaders."""

    import_endpoint: str
    max_size_bytes: int
    accept: str
    accepted_extensions: list[str] = Field(default_factory=list)
    accepted_content_types: list[str] = Field(default_factory=list)


class CreateLearningProposalRequest(BaseModel):
    """Request to turn a learned pattern into governed skill guidance."""

    skill_id: str = Field(..., min_length=1, description="Skill to evolve")
    proposed_tip: str | None = Field(None, description="Optional reviewer-authored guidance tip")
    rationale: str | None = Field(None, description="Why this change should exist")
    candidate_metrics: dict | None = Field(None, description="Optional shadow metrics snapshot")


class RejectLearningProposalRequest(BaseModel):
    """Reject a learning proposal with reviewer reason."""

    reason: str = Field("rejected_by_reviewer", min_length=1, description="Reason for rejection")


class ConsolidateDecisionTreesRequest(BaseModel):
    """Request to merge recurring decision trees into stronger reusable trees."""

    skill_id: str | None = Field(default=None, description="Optional skill filter")
    decision_type: str | None = Field(default=None, description="Optional decision type filter")
    min_occurrences: int = Field(default=2, ge=2, le=50, description="Minimum recurring observations required")


# Endpoints


@router.post("/remember", response_model=MemoryResponse)
async def remember(
    request: RememberRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Record a new memory.

    Args:
        request: Memory to record
        tenant_id: Tenant identifier

    Returns:
        MemoryResponse with evidence_id and metadata

    Raises:
        HTTPException: If memory recording fails
    """
    try:
        service = _get_memory_service()
        result = service.remember(
            tenant_id=tenant_id,
            memory_type=request.memory_type,
            scope_type=request.scope_type,
            scope_id=request.scope_id,
            content=request.content,
            importance=request.importance,
            reliability=request.reliability,
            ttl_days=request.ttl_days,
            source_event_id=request.source_event_id,
            allow_scope_promotion=request.allow_scope_promotion,
            function_id=request.function_id,
        )

        await _meter(
            tenant_id=tenant_id,
            metric=UsageMetricType.MEMORY_WRITES,
            quantity=1,
            unit="writes",
            idempotency_key=f"memory:remember:{tenant_id}:{result['evidence_id']}",
            metadata={"memory_type": result["memory_type"], "scope_type": request.scope_type},
        )

        return MemoryResponse(
            evidence_id=result["evidence_id"],
            memory_type=result["memory_type"],
            scope_type=result["scope_type"],
            scope_id=result["scope_id"],
            state=result["state"],
            importance=result["importance"],
            reliability=result["reliability"],
        )

    except PermissionError as e:
        logger.warning("memory.remember permission denied tenant=%s: %s", tenant_id, e)
        raise HTTPException(status_code=403, detail=str(e))
    except ValueError as e:
        logger.warning("memory.remember validation error tenant=%s: %s", tenant_id, e)
        raise HTTPException(status_code=400, detail="Invalid memory data")
    except _MEMORY_BACKEND_EXCEPTIONS as exc:
        _raise_memory_service_unavailable(operation="remember", tenant_id=tenant_id, exc=exc)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception(
            "memory.remember_failed tenant=%s scope=%s:%s",
            tenant_id,
            request.scope_type,
            request.scope_id,
        )
        raise HTTPException(status_code=500, detail="Failed to record memory") from exc


@router.post("/forget")
async def forget(request: ForgetRequest, tenant_id: str = Depends(get_verified_tenant_id)):
    """Mark a memory as expired.

    Args:
        request: Evidence ID to forget
        tenant_id: Tenant identifier

    Returns:
        Success confirmation

    Raises:
        HTTPException: If forget operation fails
    """
    try:
        service = _get_memory_service()

        service.forget(tenant_id=tenant_id, evidence_id=request.evidence_id)

        await _meter(
            tenant_id=tenant_id,
            metric=UsageMetricType.MEMORY_WRITES,
            quantity=1,
            unit="deletes",
            idempotency_key=f"memory:forget:{tenant_id}:{request.evidence_id}",
            metadata={"operation": "forget", "evidence_id": request.evidence_id},
        )

        return {
            "status": "success",
            "evidence_id": request.evidence_id,
            "state": "expired",
        }

    except ValueError as e:
        logger.warning("memory.forget not found tenant=%s: %s", tenant_id, e)
        raise HTTPException(status_code=404, detail="Memory not found")
    except _MEMORY_BACKEND_EXCEPTIONS as exc:
        _raise_memory_service_unavailable(operation="forget", tenant_id=tenant_id, exc=exc)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception("memory.forget_failed tenant=%s evidence_id=%s", tenant_id, request.evidence_id)
        raise HTTPException(status_code=500, detail="Failed to forget memory") from exc


@router.post(
    "/import",
    response_model=AttachmentImportResponse,
    status_code=status.HTTP_201_CREATED,
)
async def import_memory_attachment(
    file: UploadFile = File(...),
    source_type: str = "memory_upload",
    category: str | None = None,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Import a file into WorkMemory through the canonical attachment ingest path."""
    content = await file.read()
    if len(content) > MEMORY_UPLOAD_MAX_SIZE_BYTES:
        payload = build_memory_upload_rejection(
            filename=file.filename,
            declared_content_type=getattr(file, "content_type", None),
            size_bytes=len(content),
            source_type=source_type,
            error=f"File too large: {len(content)} bytes (max {MEMORY_UPLOAD_MAX_SIZE_BYTES})",
        )
        return JSONResponse(status_code=413, content=AttachmentImportResponse(**payload).model_dump())
    try:
        validated_upload = validate_memory_upload(
            filename=file.filename,
            content=content,
            declared_content_type=getattr(file, "content_type", None),
        )
    except UploadValidationError as exc:
        payload = build_memory_upload_rejection(
            filename=file.filename,
            declared_content_type=getattr(file, "content_type", None),
            size_bytes=len(content),
            source_type=source_type,
            error=str(exc),
        )
        return JSONResponse(status_code=422, content=AttachmentImportResponse(**payload).model_dump())

    service = _get_attachment_ingestion_service()
    try:
        result = await service.ingest_upload(
            tenant_id=tenant_id,
            filename=file.filename or "attachment",
            content=content,
            content_type=validated_upload.content_type,
            source_surface=source_type,
            category=category,
        )
    except (ValueError, KeyError, RuntimeError, BotoCoreError, ClientError) as exc:
        logger.exception("memory.import_failed tenant=%s file=%s: %s", tenant_id, file.filename, exc)
        raise HTTPException(status_code=500, detail="Failed to import attachment")

    payload = AttachmentImportResponse(**result.to_dict())
    if result.status_code >= 400:
        return JSONResponse(status_code=result.status_code, content=payload.model_dump())
    return payload


@router.get("/upload-capabilities", response_model=AttachmentUploadCapabilitiesResponse)
async def get_attachment_upload_capabilities() -> AttachmentUploadCapabilitiesResponse:
    """Return the canonical upload contract for memory/task file importers."""
    contract = get_memory_upload_capabilities()
    return AttachmentUploadCapabilitiesResponse(
        import_endpoint=contract.import_endpoint,
        max_size_bytes=contract.max_size_bytes,
        accept=contract.accept,
        accepted_extensions=list(contract.accepted_extensions),
        accepted_content_types=list(contract.accepted_content_types),
    )


@router.post("/query", response_model=MemoryQueryResponse)
async def query(request: MemoryQueryRequest, tenant_id: str = Depends(get_verified_tenant_id)):
    """Query memories with hybrid search and policy filter.

    Args:
        request: Query parameters
        tenant_id: Tenant identifier

    Returns:
        MemoryQueryResponse with matching items

    Raises:
        HTTPException: If query fails
    """
    try:
        service = _get_memory_service()

        items = service.query_by_scope(
            tenant_id=tenant_id,
            scope_type=request.scope_type,
            scope_id=request.scope_id,
            limit=request.limit,
            function_id=request.function_id,
        )

        # Filter by memory_types if provided
        if request.memory_types:
            items = [item for item in items if item.get("memory_type") in request.memory_types]

        await _meter(
            tenant_id=tenant_id,
            metric=UsageMetricType.MEMORY_READS,
            quantity=len(items),
            unit="reads",
            idempotency_key=f"memory:query:{tenant_id}:{request.scope_type}:{request.scope_id}:{len(items)}",
            metadata={"scope_type": request.scope_type, "results_count": len(items)},
        )

        return MemoryQueryResponse(items=items, count=len(items))

    except ValueError as e:
        logger.warning("memory.query validation error tenant=%s: %s", tenant_id, e)
        raise HTTPException(status_code=400, detail="Invalid query parameters")
    except _MEMORY_BACKEND_EXCEPTIONS as exc:
        _raise_memory_service_unavailable(operation="query", tenant_id=tenant_id, exc=exc)
    except HTTPException:
        raise
    except Exception as exc:
        logger.exception(
            "memory.query_failed tenant=%s scope=%s:%s",
            tenant_id,
            request.scope_type,
            request.scope_id,
        )
        raise HTTPException(status_code=500, detail="Failed to query memories") from exc


@router.get("/resolve", response_model=ContextResolveResponse)
async def resolve(
    tenant_id: str = Depends(get_verified_tenant_id),
    scope_type: str = Query(..., description="agent|team|department|org"),
    scope_id: str = Query(..., description="Scope identifier"),
    include_inherited: bool = Query(False, description="Include parent scope memories"),
):
    """Hierarchical context resolution.

    Resolves memories across scope hierarchy with provenance tracking.

    Args:
        tenant_id: Tenant identifier
        scope_type: Scope type (agent, team, department, org)
        scope_id: Scope identifier
        include_inherited: Whether to include parent scope memories

    Returns:
        ContextResolveResponse with merged items and provenance

    Raises:
        HTTPException: If resolution fails
    """
    try:
        service = _get_memory_service()

        result = service.resolve_context(
            tenant_id=tenant_id,
            scope_type=scope_type,
            scope_id=scope_id,
            include_inherited=include_inherited,
        )

        result_dict = result if isinstance(result, dict) else {}
        merged_items = result_dict.get("merged_items", [])
        if not isinstance(merged_items, list):
            merged_items = []

        await _meter(
            tenant_id=tenant_id,
            metric=UsageMetricType.MEMORY_READS,
            quantity=len(merged_items),
            unit="reads",
            idempotency_key=f"memory:resolve:{tenant_id}:{scope_type}:{scope_id}:{include_inherited}",
            metadata={"scope_type": scope_type, "include_inherited": include_inherited},
        )

        contexts = result_dict.get("contexts", {})
        if isinstance(contexts, dict) and contexts:
            scope_chain = list(contexts.keys())
            provenance = [
                {"scope": scope_key, "item_count": len(scope_items)} for scope_key, scope_items in contexts.items()
            ]
        else:
            raw_scope_chain = result_dict.get("scope_chain", [])
            scope_chain = [
                str(scope).strip()
                for scope in (raw_scope_chain if isinstance(raw_scope_chain, list) else [])
                if str(scope).strip()
            ]
            raw_provenance = result_dict.get("provenance", [])
            provenance = raw_provenance if isinstance(raw_provenance, list) else []

        return ContextResolveResponse(
            merged_items=merged_items,
            provenance=provenance,
            scope_chain=scope_chain,
        )

    except ValueError as e:
        logger.warning("memory.resolve validation error tenant=%s: %s", tenant_id, e)
        raise HTTPException(status_code=400, detail="Invalid resolution parameters")
    except _MEMORY_BACKEND_EXCEPTIONS as exc:
        _raise_memory_service_unavailable(operation="resolve", tenant_id=tenant_id, exc=exc)
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to resolve context") from exc


@router.get("/profile/{scope_type}/{scope_id}", response_model=MemoryProfileResponse)
async def get_profile(scope_type: str, scope_id: str, tenant_id: str = Depends(get_verified_tenant_id)):
    """Get memory profile for a scope.

    Aggregates memory statistics and recent items.

    Args:
        scope_type: Scope type (agent, team, department, org)
        scope_id: Scope identifier
        tenant_id: Tenant identifier

    Returns:
        MemoryProfileResponse with aggregated statistics

    Raises:
        HTTPException: If profile retrieval fails
    """
    try:
        service = _get_memory_service()
        profile = service.get_memory_profile(
            tenant_id=tenant_id,
            scope_type=scope_type,
            scope_id=scope_id,
            limit=100,
        )

        await _meter(
            tenant_id=tenant_id,
            metric=UsageMetricType.MEMORY_READS,
            quantity=1,
            unit="profile_fetch",
            idempotency_key=f"memory:profile:{tenant_id}:{scope_type}:{scope_id}",
            metadata={"scope_type": scope_type, "total_memories": profile["total_memories"]},
        )

        return MemoryProfileResponse(**profile)

    except ValueError as e:
        logger.warning("memory.get_profile validation error tenant=%s: %s", tenant_id, e)
        raise HTTPException(status_code=400, detail="Invalid profile parameters")
    except _MEMORY_BACKEND_EXCEPTIONS as exc:
        _raise_memory_service_unavailable(operation="get_profile", tenant_id=tenant_id, exc=exc)
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to get memory profile") from exc


@router.post("/promote")
async def promote(request: PromoteRequest, tenant_id: str = Depends(get_verified_tenant_id)):
    """Promote memory to broader scope.

    Updates the state of a memory to promote it to a broader scope.

    Args:
        request: Evidence ID and new state
        tenant_id: Tenant identifier

    Returns:
        Success confirmation

    Raises:
        HTTPException: If promotion fails
    """
    try:
        service = _get_memory_service()

        service.update_state(
            tenant_id=tenant_id,
            evidence_id=request.evidence_id,
            new_state=request.new_state,
        )

        return {
            "status": "success",
            "evidence_id": request.evidence_id,
            "new_state": request.new_state,
        }

    except ValueError as e:
        logger.warning("memory.promote not found tenant=%s: %s", tenant_id, e)
        raise HTTPException(status_code=404, detail="Memory not found")
    except _MEMORY_BACKEND_EXCEPTIONS as exc:
        _raise_memory_service_unavailable(operation="promote", tenant_id=tenant_id, exc=exc)
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Failed to promote memory") from exc


# ============================================================================
# Part 17: Mission Control Memory Extensions (4-tab model)
# ============================================================================

# === JOURNAL ===


@router.get("/journal")
async def get_journal(
    tenant_id: str = Depends(get_verified_tenant_id),
    agent_id: str | None = Query(None, description="Filter by agent ID"),
    date: str | None = Query(None, description="Filter by date (ISO format)"),
    limit: int = Query(50, ge=1, le=1000, description="Maximum results"),
):
    """Get journal entries (evidence timeline formatted for display).

    Args:
        tenant_id: Tenant identifier
        agent_id: Optional agent filter
        date: Optional date filter (YYYY-MM-DD)
        limit: Maximum entries to return

    Returns:
        List of journal entries with timestamp, agent, summary
    """
    try:
        service = _get_memory_service()
        entries = service.get_journal(tenant_id=tenant_id, agent_id=agent_id, date=date, limit=limit)
        return {"items": entries, "entries": entries, "count": len(entries)}

    except (ValueError, KeyError) as e:
        logger.warning("memory.get_journal validation error tenant=%s: %s", tenant_id, e)
        raise HTTPException(status_code=400, detail="Invalid journal parameters")
    except _MEMORY_BACKEND_EXCEPTIONS as exc:
        _raise_memory_service_unavailable(operation="get_journal", tenant_id=tenant_id, exc=exc)
    except Exception as exc:
        logger.exception("memory.get_journal failed tenant=%s", tenant_id)
        raise HTTPException(status_code=500, detail="Failed to get journal") from exc


@router.get("/journal/summary")
async def get_journal_summary(
    tenant_id: str = Depends(get_verified_tenant_id),
    date: str = Query(..., description="Date (ISO format)"),
):
    """Get summary statistics for a day's journal.

    Args:
        tenant_id: Tenant identifier
        date: Date to summarize (YYYY-MM-DD)

    Returns:
        Summary with total entries, by_agent counts, highlights
    """
    try:
        service = _get_memory_service()
        summary = service.get_journal_summary(tenant_id=tenant_id, date=date)
        return summary

    except (ValueError, KeyError) as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except _MEMORY_BACKEND_EXCEPTIONS as exc:
        _raise_memory_service_unavailable(operation="get_journal_summary", tenant_id=tenant_id, exc=exc)
    except Exception as exc:
        logger.exception("memory.get_journal_summary failed tenant=%s", tenant_id)
        raise HTTPException(status_code=500, detail="Failed to get journal summary") from exc


# === FACTS ===


class StoreFactRequest(BaseModel):
    """Request to store a long-term fact."""

    key: str = Field(..., description="Fact key")
    value: str = Field(..., description="Fact value")
    scope: str = Field("org", description="Scope: agent|team|department|org")
    source: str = Field("user", description="Source: user|agent|system")
    agent_id: str | None = Field(None, description="Agent ID if scope=agent")


class UpdateFactRequest(BaseModel):
    """Request to update an existing long-term fact."""

    key: str | None = Field(None, description="Fact key (accepted for compatibility)")
    value: str = Field(..., description="Updated fact value")
    scope: str | None = Field(None, description="Fact scope (accepted for compatibility)")


@router.get("/facts")
async def get_facts(
    tenant_id: str = Depends(get_verified_tenant_id),
    scope: str | None = Query(None, description="Filter by scope"),
    agent_id: str | None = Query(None, description="Filter by agent ID"),
):
    """List all facts for a tenant.

    Args:
        tenant_id: Tenant identifier
        scope: Optional scope filter
        agent_id: Optional agent filter

    Returns:
        List of facts
    """
    try:
        service = _get_memory_service()
        facts = service.get_facts(tenant_id=tenant_id, scope=scope, agent_id=agent_id)
        return {"items": facts, "facts": facts, "count": len(facts)}

    except (ValueError, KeyError) as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except _MEMORY_BACKEND_EXCEPTIONS as exc:
        _raise_memory_service_unavailable(operation="get_facts", tenant_id=tenant_id, exc=exc)
    except Exception as exc:
        logger.exception("memory.get_facts failed tenant=%s", tenant_id)
        raise HTTPException(status_code=500, detail="Failed to get facts") from exc


@router.get("/history/{item_id}", response_model=HistoricalMemoryItemResponse)
async def get_historical_memory_item(
    item_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> HistoricalMemoryItemResponse:
    """Return one historical memory item for citation follow-through."""
    history_tenant_id = _canonical_memory_history_tenant_id(tenant_id)
    try:
        item = await _get_workmemory_client().get_memory_item(
            tenant_id=history_tenant_id,
            item_id=item_id,
            limit=500,
        )
    except _MEMORY_BACKEND_EXCEPTIONS as exc:
        _raise_memory_service_unavailable(operation="get_historical_memory_item", tenant_id=tenant_id, exc=exc)
    except Exception as exc:
        logger.exception("memory.get_historical_memory_item failed tenant=%s item_id=%s", tenant_id, item_id)
        raise HTTPException(status_code=500, detail="Failed to get historical memory item") from exc
    if not item:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="memory_item_not_found")

    fact = str(item.get("fact") or item.get("content") or item.get("text") or item.get("value") or "").strip()
    resolved_item_id = str(item.get("item_id") or item_id)
    metadata = coerce_memory_mapping(item.get("metadata"))
    provenance = coerce_memory_mapping(item.get("provenance"))
    temporal = coerce_memory_mapping(item.get("temporal"))
    relationship = coerce_memory_mapping(item.get("relationship"))
    metadata, review_state = apply_memory_review_overlay(
        tenant_id=history_tenant_id,
        item_id=resolved_item_id,
        metadata=metadata,
        log_failures=True,
    )
    links = _memory_provenance_links(resolved_item_id, item=item, metadata=metadata)
    return HistoricalMemoryItemResponse(
        item_id=resolved_item_id,
        fact=fact,
        category=str(item.get("category") or "general"),
        created_at=item.get("created_at"),
        source_type=str(item.get("source_type") or "memory"),
        metadata=metadata,
        provenance=provenance,
        temporal=temporal,
        relationship=relationship,
        source_confidence=provenance.get("source_confidence"),
        review_state=review_state,
        superseded_by=str(temporal.get("superseded_by") or metadata.get("superseded_by") or "").strip() or None,
        source_event_id=str(metadata.get("source_event_id") or "").strip() or None,
        resource_ref=str(metadata.get("resource_ref") or item.get("resource_ref") or "").strip() or None,
        memory_scope=str(metadata.get("memory_scope") or item.get("memory_scope") or "").strip() or None,
        source_link=links["source_link"],
        runtime_href=links["runtime_href"],
        version_history_link=links["version_history_link"],
        challenge_link=links["challenge_link"],
        inspect_link=links["inspect_link"],
    )


@router.post("/history/{item_id}/challenge", response_model=ChallengeHistoricalMemoryResponse)
async def challenge_historical_memory_item(
    item_id: str,
    body: ChallengeHistoricalMemoryRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
) -> ChallengeHistoricalMemoryResponse:
    """Persist a review receipt when a cited memory item is challenged."""
    history_tenant_id = _canonical_memory_history_tenant_id(tenant_id)
    try:
        item = await _get_workmemory_client().get_memory_item(
            tenant_id=history_tenant_id,
            item_id=item_id,
            limit=500,
        )
    except _MEMORY_BACKEND_EXCEPTIONS as exc:
        _raise_memory_service_unavailable(
            operation="challenge_historical_memory_item",
            tenant_id=tenant_id,
            exc=exc,
        )
    except Exception as exc:
        logger.exception("memory.challenge_historical_memory_item failed tenant=%s item_id=%s", tenant_id, item_id)
        raise HTTPException(status_code=500, detail="Failed to challenge historical memory item") from exc
    if not item:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="memory_item_not_found")

    from apps.backend.workmemory.services.version_history import Operation

    normalized_actor_id = str(authenticated_user_id or "").strip()
    if normalized_actor_id and "#" not in normalized_actor_id:
        normalized_actor_id = f"USER#{normalized_actor_id}"

    requested_reviewer_id = str(body.reviewer_id or "").strip()
    if requested_reviewer_id:
        if "#" not in requested_reviewer_id:
            requested_reviewer_id = f"USER#{requested_reviewer_id}"
        if requested_reviewer_id != normalized_actor_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Reviewer ID mismatch between request body and authenticated identity",
            )

    normalized_reason = body.reason
    version_history = _get_version_history_service()
    prior_challenges = version_history.get_history(
        tenant_id=history_tenant_id,
        item_id=str(item.get("item_id") or item_id),
        operation=Operation.CHALLENGED,
        actor_id=normalized_actor_id,
    )
    existing = next(
        (
            version
            for version in reversed(prior_challenges)
            if str(version.metadata.get("reason") or "").strip() == normalized_reason
        ),
        None,
    )
    version = existing or version_history.record_mutation(
        item={
            "item_id": str(item.get("item_id") or item_id),
            "tenant_id": history_tenant_id,
            "fact": str(item.get("fact") or item.get("content") or item.get("text") or item.get("value") or "").strip(),
        },
        operation=Operation.CHALLENGED,
        actor_id=normalized_actor_id,
        metadata={
            "reason": normalized_reason,
            "review_state": "challenged",
        },
    )
    metadata = coerce_memory_mapping(item.get("metadata"))
    links = _memory_provenance_links(str(item.get("item_id") or item_id), item=item, metadata=metadata)
    return ChallengeHistoricalMemoryResponse(
        item_id=str(item.get("item_id") or item_id),
        review_state="challenged",
        challenge_version_id=version.version_id,
        reason=normalized_reason,
        source_link=links["source_link"],
        version_history_link=links["version_history_link"],
        challenge_link=links["challenge_link"],
    )


@router.post("/facts", status_code=201)
async def store_fact(request: StoreFactRequest, tenant_id: str = Depends(get_verified_tenant_id)):
    """Store a new fact.

    Args:
        request: Fact data
        tenant_id: Tenant identifier

    Returns:
        Created fact
    """
    try:
        service = _get_memory_service()
        fact = service.store_fact(
            tenant_id=tenant_id,
            key=request.key,
            value=request.value,
            scope=request.scope,
            source=request.source,
            agent_id=request.agent_id,
        )
        return fact

    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except _MEMORY_BACKEND_EXCEPTIONS as exc:
        _raise_memory_service_unavailable(operation="store_fact", tenant_id=tenant_id, exc=exc)
    except Exception as exc:
        logger.exception("memory.store_fact failed tenant=%s", tenant_id)
        raise HTTPException(status_code=500, detail="Failed to store fact") from exc


@router.patch("/facts/{fact_id}")
async def update_fact(
    fact_id: str,
    request: UpdateFactRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Update a fact's value.

    Args:
        fact_id: Fact identifier
        request: Updated fact payload
        tenant_id: Tenant identifier

    Returns:
        Updated fact
    """
    try:
        service = _get_memory_service()
        fact = service.update_fact(tenant_id=tenant_id, fact_id=fact_id, value=request.value)
        return fact

    except ValueError as e:
        raise HTTPException(status_code=404, detail=safe_error_detail(e))
    except _MEMORY_BACKEND_EXCEPTIONS as exc:
        _raise_memory_service_unavailable(operation="update_fact", tenant_id=tenant_id, exc=exc)
    except Exception as exc:
        logger.exception("memory.update_fact failed tenant=%s fact_id=%s", tenant_id, fact_id)
        raise HTTPException(status_code=500, detail="Failed to update fact") from exc


@router.delete("/facts/{fact_id}")
async def delete_fact(fact_id: str, tenant_id: str = Depends(get_verified_tenant_id)):
    """Delete a fact.

    Args:
        fact_id: Fact identifier
        tenant_id: Tenant identifier

    Returns:
        Success confirmation
    """
    try:
        service = _get_memory_service()
        service.delete_fact(tenant_id=tenant_id, fact_id=fact_id)
        return {"status": "success", "fact_id": fact_id}

    except ValueError as e:
        raise HTTPException(status_code=404, detail=safe_error_detail(e))
    except _MEMORY_BACKEND_EXCEPTIONS as exc:
        _raise_memory_service_unavailable(operation="delete_fact", tenant_id=tenant_id, exc=exc)
    except Exception as exc:
        logger.exception("memory.delete_fact failed tenant=%s fact_id=%s", tenant_id, fact_id)
        raise HTTPException(status_code=500, detail="Failed to delete fact") from exc


# === PATTERNS ===


@router.get("/patterns")
async def get_patterns(
    tenant_id: str = Depends(get_verified_tenant_id),
    min_confidence: float = Query(0.0, ge=0.0, le=1.0, description="Minimum confidence"),
):
    """List learned patterns.

    Args:
        tenant_id: Tenant identifier
        min_confidence: Minimum confidence score (0.0-1.0)

    Returns:
        List of patterns
    """
    try:
        service = _get_memory_service()
        patterns = service.get_patterns(tenant_id=tenant_id, min_confidence=min_confidence)
        return {"items": patterns, "patterns": patterns, "count": len(patterns)}

    except (ValueError, KeyError) as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except _MEMORY_BACKEND_EXCEPTIONS as exc:
        _raise_memory_service_unavailable(operation="get_patterns", tenant_id=tenant_id, exc=exc)
    except Exception as exc:
        logger.exception("memory.get_patterns failed tenant=%s", tenant_id)
        raise HTTPException(status_code=500, detail="Failed to get patterns") from exc


@router.post("/patterns/{pattern_id}/confirm")
async def confirm_pattern(pattern_id: str, tenant_id: str = Depends(get_verified_tenant_id)):
    """Confirm a pattern (user validates it).

    Args:
        pattern_id: Pattern identifier
        tenant_id: Tenant identifier

    Returns:
        Updated pattern
    """
    try:
        service = _get_memory_service()
        pattern = service.confirm_pattern(tenant_id=tenant_id, pattern_id=pattern_id)
        return pattern

    except ValueError as e:
        raise HTTPException(status_code=404, detail=safe_error_detail(e))
    except _MEMORY_BACKEND_EXCEPTIONS as exc:
        _raise_memory_service_unavailable(operation="confirm_pattern", tenant_id=tenant_id, exc=exc)
    except Exception as exc:
        logger.exception("memory.confirm_pattern failed tenant=%s pattern_id=%s", tenant_id, pattern_id)
        raise HTTPException(status_code=500, detail="Failed to confirm pattern") from exc


@router.post("/patterns/{pattern_id}/dismiss")
async def dismiss_pattern(pattern_id: str, tenant_id: str = Depends(get_verified_tenant_id)):
    """Dismiss a pattern (marks as invalid).

    Args:
        pattern_id: Pattern identifier
        tenant_id: Tenant identifier

    Returns:
        Updated pattern
    """
    try:
        service = _get_memory_service()
        pattern = service.dismiss_pattern(tenant_id=tenant_id, pattern_id=pattern_id)
        return pattern

    except ValueError as e:
        raise HTTPException(status_code=404, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to dismiss pattern")


@router.post("/patterns/{pattern_id}/propose-guidance", status_code=201)
async def propose_pattern_guidance(
    pattern_id: str,
    request: CreateLearningProposalRequest,
    http_request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Create a durable learning proposal from a stored pattern."""
    try:
        service = _get_approval_service()
        reviewer = str(getattr(http_request.state, "user_id", "") or "human_review")
        result = await service.request_learning_proposal(
            tenant_id=tenant_id,
            pattern_id=pattern_id,
            skill_id=request.skill_id,
            proposed_tip=request.proposed_tip,
            rationale=request.rationale,
            requested_by=reviewer,
            candidate_metrics=request.candidate_metrics,
        )
        proposal = dict(result.get("proposal") or {})
        approval = result.get("approval")
        approval_request = getattr(approval, "approval_request", None) if approval is not None else None
        request_id = str(getattr(approval_request, "request_id", "") or "").strip()
        if request_id:
            proposal["approval_request_id"] = request_id
        return proposal
    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to create learning proposal")


@router.get("/improvements")
async def list_learning_improvements(
    tenant_id: str = Depends(get_verified_tenant_id),
    status: str | None = Query(None, description="Optional status filter"),
    skill_id: str | None = Query(None, description="Optional skill filter"),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
):
    """List governed learning proposals."""
    try:
        service = _get_approval_service()
        items = service.list_learning_improvements(tenant_id=tenant_id, status=status, skill_id=skill_id)
        paged_items, _total = paginate_items(items, pagination)
        return {"items": paged_items, "count": len(paged_items)}
    except (ValueError, KeyError) as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to list learning proposals")


@router.post("/improvements/{improvement_id}/apply")
async def apply_learning_improvement(
    improvement_id: str,
    http_request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Apply a reviewed learning proposal into live skill guidance."""
    try:
        service = _get_approval_service()
        reviewer = str(getattr(http_request.state, "user_id", "") or "human_review")
        return await service.apply_learning_improvement(
            tenant_id=tenant_id,
            improvement_id=improvement_id,
            approved_by=reviewer,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to apply learning proposal")


@router.post("/improvements/{improvement_id}/reject")
async def reject_learning_improvement(
    improvement_id: str,
    request: RejectLearningProposalRequest,
    http_request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Reject a learning proposal and keep it out of runtime guidance."""
    try:
        service = _get_approval_service()
        reviewer = str(getattr(http_request.state, "user_id", "") or "human_review")
        return await service.reject_learning_improvement(
            tenant_id=tenant_id,
            improvement_id=improvement_id,
            rejected_by=reviewer,
            reason=request.reason,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to reject learning proposal")


@router.post("/improvements/{improvement_id}/rollback")
async def rollback_learning_improvement(
    improvement_id: str,
    http_request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Rollback a previously applied learning proposal."""
    try:
        service = _get_approval_service()
        reviewer = str(getattr(http_request.state, "user_id", "") or "human_review")
        return service.rollback_learning_improvement(
            tenant_id=tenant_id,
            improvement_id=improvement_id,
            rolled_back_by=reviewer,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to rollback learning proposal")


@router.get("/decision-trees")
async def get_decision_trees(
    tenant_id: str = Depends(get_verified_tenant_id),
    skill_id: str | None = Query(None, description="Optional skill filter"),
    decision_type: str | None = Query(None, description="Optional decision type filter"),
):
    """List persisted decision trees extracted from decision events."""
    try:
        service = _get_memory_service()
        items = service.get_decision_trees(
            tenant_id=tenant_id,
            skill_id=skill_id,
            decision_type=decision_type,
        )
        return {"items": items, "count": len(items)}
    except (ValueError, KeyError) as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to list decision trees")


@router.post("/decision-trees/consolidate")
async def consolidate_decision_trees(
    request: ConsolidateDecisionTreesRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Merge recurring decision trees into stronger reusable trees."""
    try:
        service = _get_decision_tree_service()
        items = service.consolidate_tenant_trees(
            tenant_id=tenant_id,
            skill_id=request.skill_id,
            decision_type=request.decision_type,
            min_occurrences=request.min_occurrences,
        )
        return {"items": items, "count": len(items)}
    except (ValueError, KeyError) as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to consolidate decision trees")


# === RULES ===


class CreateRuleRequest(BaseModel):
    """Request to create a behavioral rule."""

    rule_text: str = Field(..., description="Natural language rule")
    scope: str = Field("org", description="Scope: agent|team|department|org")


@router.get("/rules")
async def get_rules(
    tenant_id: str = Depends(get_verified_tenant_id),
    scope: str | None = Query(None, description="Filter by scope"),
):
    """List all rules.

    Args:
        tenant_id: Tenant identifier
        scope: Optional scope filter

    Returns:
        List of rules
    """
    try:
        service = _get_memory_service()
        rules = service.get_rules(tenant_id=tenant_id, scope=scope)
        return {"items": rules, "rules": rules, "count": len(rules)}

    except (ValueError, KeyError) as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to get rules")


@router.post("/rules", status_code=201)
async def create_rule(request: CreateRuleRequest, tenant_id: str = Depends(get_verified_tenant_id)):
    """Create a new rule.

    Args:
        request: Rule data
        tenant_id: Tenant identifier

    Returns:
        Created rule
    """
    try:
        service = _get_memory_service()
        rule = service.create_rule(tenant_id=tenant_id, rule_text=request.rule_text, scope=request.scope)
        return rule

    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to create rule")


@router.patch("/rules/{rule_id}")
async def update_rule(
    rule_id: str,
    rule_text: str = Query(..., description="New rule text"),
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Update a rule's text.

    Args:
        rule_id: Rule identifier
        rule_text: New rule text
        tenant_id: Tenant identifier

    Returns:
        Updated rule
    """
    try:
        service = _get_memory_service()
        rule = service.update_rule(tenant_id=tenant_id, rule_id=rule_id, rule_text=rule_text)
        return rule

    except ValueError as e:
        raise HTTPException(status_code=404, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to update rule")


@router.delete("/rules/{rule_id}")
async def delete_rule(rule_id: str, tenant_id: str = Depends(get_verified_tenant_id)):
    """Delete a rule.

    Args:
        rule_id: Rule identifier
        tenant_id: Tenant identifier

    Returns:
        Success confirmation
    """
    try:
        service = _get_memory_service()
        service.delete_rule(tenant_id=tenant_id, rule_id=rule_id)
        return {"status": "success", "rule_id": rule_id}

    except ValueError as e:
        raise HTTPException(status_code=404, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to delete rule")


# === SEARCH ===


class MemorySearchRequest(BaseModel):
    """Request to search memory."""

    query: str = Field(..., description="Search query")
    memory_type: str | None = Field(None, description="Filter: journal|facts|patterns|rules")
    agent_id: str | None = Field(None, description="Filter by agent ID")
    limit: int = Field(20, ge=1, le=100, description="Maximum results")


@router.post("/search")
async def search_memory(request: MemorySearchRequest, tenant_id: str = Depends(get_verified_tenant_id)):
    """Search across all memory types.

    Args:
        request: Search parameters
        tenant_id: Tenant identifier

    Returns:
        Search results
    """
    try:
        service = _get_memory_service()
        results = service.search(
            tenant_id=tenant_id,
            query=request.query,
            memory_type=request.memory_type,
            agent_id=request.agent_id,
            limit=request.limit,
        )

        await _meter(
            tenant_id=tenant_id,
            metric=UsageMetricType.MEMORY_READS,
            quantity=len(results),
            unit="search_results",
            idempotency_key=f"memory:search:{tenant_id}:{request.query[:60]}:{request.memory_type or 'all'}",
            metadata={"query": request.query[:100], "memory_type_filter": request.memory_type},
        )

        return {"items": results, "count": len(results)}

    except (ValueError, KeyError) as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except _MEMORY_BACKEND_EXCEPTIONS as exc:
        _raise_memory_service_unavailable(operation="search_memory", tenant_id=tenant_id, exc=exc)
    except Exception as exc:
        logger.exception("memory.search failed tenant=%s", tenant_id)
        raise HTTPException(status_code=500, detail="Failed to search memory") from exc


# ─── Knowledge graph (T2 follow-up of Settings IA redesign) ──────────────


@router.get("/graph")
async def get_memory_graph(
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(80, ge=1, le=500, description="Max facts to include"),
):
    """Return a small knowledge graph synthesized from the tenant's facts.

    Schema (designed to feed any common force-graph renderer):
      {
        "nodes": [
          { "id": "scope:user", "label": "User scope", "type": "scope", "size": 12 },
          { "id": "fact:abc",  "label": "Likes coffee in the morning", "type": "fact", "size": 4 }
        ],
        "edges": [
          { "source": "fact:abc", "target": "scope:user", "type": "in-scope" }
        ],
        "stats": { "total_facts": 42, "scopes": 5 }
      }

    Each fact is a node, each scope is a node, edges connect facts to their scope.
    Soft-fails to an empty graph if the memory service is unavailable.
    """
    try:
        service = _get_memory_service()
        facts = service.get_facts(tenant_id=tenant_id, limit=limit)
    except Exception as exc:  # noqa: BLE001
        logger.warning("memory.graph fetch failed tenant=%s: %s", tenant_id, exc)
        return {"nodes": [], "edges": [], "stats": {"total_facts": 0, "scopes": 0}}

    if not facts:
        return {"nodes": [], "edges": [], "stats": {"total_facts": 0, "scopes": 0}}

    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    scope_to_id: dict[str, str] = {}
    scope_counts: dict[str, int] = {}

    for raw in facts:
        if not isinstance(raw, dict):
            continue
        fact_id = str(raw.get("fact_id") or raw.get("sk") or raw.get("id") or "")
        statement = str(raw.get("statement") or raw.get("value") or raw.get("text") or "Untitled fact")
        scope = str(raw.get("scope") or "general")

        # Truncate long statements for the label
        label = statement[:80] + "…" if len(statement) > 80 else statement

        if not fact_id:
            continue

        nodes.append(
            {
                "id": f"fact:{fact_id}",
                "label": label,
                "type": "fact",
                "size": 4,
                "metadata": {
                    "scope": scope,
                    "agent_id": raw.get("agent_id"),
                    "created_at": raw.get("created_at") or raw.get("timestamp"),
                },
            }
        )

        if scope not in scope_to_id:
            scope_to_id[scope] = f"scope:{scope}"
            scope_counts[scope] = 0
        scope_counts[scope] += 1

        edges.append(
            {
                "source": f"fact:{fact_id}",
                "target": scope_to_id[scope],
                "type": "in-scope",
            }
        )

    # Add scope nodes — size scales with fact count for visual weight
    for scope, scope_id in scope_to_id.items():
        nodes.append(
            {
                "id": scope_id,
                "label": f"{scope.capitalize()} scope",
                "type": "scope",
                "size": min(20, 8 + scope_counts[scope]),
                "metadata": {"fact_count": scope_counts[scope]},
            }
        )

    return {
        "nodes": nodes,
        "edges": edges,
        "stats": {
            "total_facts": len(facts),
            "scopes": len(scope_to_id),
        },
    }
