"""Work Functions REST API surface (#2975)."""

from __future__ import annotations

import logging
from decimal import Decimal
from typing import Annotated, Any, Literal, Protocol

from fastapi import APIRouter, Body, Depends, HTTPException, status
from pydantic import BaseModel, ConfigDict, Field

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    require_admin_user_role,
)
from apps.backend.config.table_names import resolve_table
from apps.backend.models.user import UserRole
from apps.backend.providers.portable_store import create_portable_store
from apps.backend.services.capacity.downgrade import FunctionDowngradeImpact, TenantDowngradePreview
from apps.backend.services.capacity.function_envelope import FunctionCapacityEnvelope
from apps.backend.services.capacity.function_lifecycle import (
    FunctionDeletionCertificate,
    FunctionLifecycleError,
    FunctionLifecycleState,
    FunctionLifecycleTransition,
)
from apps.backend.services.capacity.gdpr_tombstone import (
    EvidenceExpiry,
    GdprDeletionResult,
    GdprTombstone,
)
from apps.backend.services.capacity.worm_quota import (
    QuotaCheckResult,
    RetentionClass,
    StorageUsage,
    WorkFunctionStoragePolicy,
    WorkFunctionWormQuotaService,
    WormQuotaExceededError,
)
from apps.backend.services.capacity.work_function_registry import (
    WorkFunctionCapacitySpec,
    WorkFunctionConflictError,
    WorkFunctionCreateSpec,
    WorkFunctionDowngradePreviewSpec,
    WorkFunctionNotFoundError,
    WorkFunctionRecord,
    WorkFunctionRegistryService,
    WorkFunctionUpdateSpec,
    get_work_function_registry_service,
)
from apps.backend.services.policy_authority import (
    PolicyDecisionEnvelope,
    build_policy_decision_envelope,
)


logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/work-functions", tags=["work-functions"])

WorkFunctionStateValue = Literal["dormant", "active", "archived", "deleted"]
WorkFunctionCreateStateValue = Literal["dormant", "active"]
WorkFunctionDrainPolicyValue = Literal["drain_in_flight", "cancel_in_flight", "reject_if_running"]
WorkFunctionLocalityValue = Literal["prefer_local", "prefer_cloud", "local_only", "cloud_only"]


class WorkFunctionCapacityRequest(BaseModel):
    """Capacity envelope fields accepted on create/update."""

    model_config = ConfigDict(extra="forbid")

    max_concurrent: int = Field(default=5, ge=0)
    budget_usd: float = Field(default=100.0, ge=0)
    foreground_reservations: int = Field(default=0, ge=0)
    always_on_quota: int = Field(default=0, ge=0)
    zero_burn_target_usd: Decimal = Field(default=Decimal("0"), ge=0)
    provider_specific_limits: dict[str, object] = Field(default_factory=dict)


class WorkFunctionCreateRequest(BaseModel):
    """Payload for POST /api/v1/work-functions."""

    name: str | None = Field(default=None, min_length=1, max_length=120)
    preset_id: str | None = Field(default=None, min_length=1, max_length=80)
    purpose: str = Field(default="", max_length=500)
    connector_scopes: list[str] = Field(default_factory=list)
    resource_policy_id: str | None = Field(default=None, max_length=120)
    coordination_protocol: str = Field(default="auto", max_length=40)
    locality_preference: WorkFunctionLocalityValue = "prefer_local"
    autonomy_level: int = Field(default=2, ge=0, le=5)
    initial_state: WorkFunctionCreateStateValue = "active"
    capacity: WorkFunctionCapacityRequest = Field(default_factory=WorkFunctionCapacityRequest)
    actor_id: str = Field(default="zara", min_length=1, max_length=120)


class WorkFunctionUpdateRequest(BaseModel):
    """Payload for PATCH /api/v1/work-functions/{id}."""

    locality_preference: WorkFunctionLocalityValue | None = None
    autonomy_level: int | None = Field(default=None, ge=0, le=5)
    capacity: WorkFunctionCapacityRequest | None = None
    reason: str = Field(default="Updated Work Function", min_length=1, max_length=500)
    actor_id: str = Field(default="zara", min_length=1, max_length=120)


class WorkFunctionArchiveRequest(BaseModel):
    """Payload for Work Function archive."""

    reason: str = Field(..., min_length=1, max_length=500)
    drain_policy: WorkFunctionDrainPolicyValue = "drain_in_flight"
    actor_id: str = Field(default="zara", min_length=1, max_length=120)


class WorkFunctionReactivateRequest(BaseModel):
    """Payload for Work Function reactivation."""

    reason: str = Field(default="Reactivated from archive", min_length=1, max_length=500)
    actor_id: str = Field(default="zara", min_length=1, max_length=120)


class WorkFunctionDeleteRequest(BaseModel):
    """Payload for Work Function GDPR tombstone deletion."""

    reason: str = Field(..., min_length=1, max_length=500)
    evidence_retention_days: int = Field(default=365, ge=1, le=2555)
    actor_id: str = Field(default="zara", min_length=1, max_length=120)


class WorkFunctionDowngradePreviewRequest(BaseModel):
    """Payload for Work Function tier downgrade preview."""

    from_tier: str = Field(..., min_length=1, max_length=80)
    to_tier: str = Field(..., min_length=1, max_length=80)
    tier_limits: dict[str, int] = Field(default_factory=dict)
    active_connectors: list[str] = Field(default_factory=list)
    tier_connectors: list[str] = Field(default_factory=list)
    actor_id: str = Field(default="zara", min_length=1, max_length=120)


class WorkFunctionQuotaPolicyRequest(BaseModel):
    """Payload for Work Function WORM quota policy updates."""

    storage_quota_gb: Decimal | None = Field(default=None, ge=0)
    workmemory_index_quota_mb: Decimal | None = Field(default=None, ge=0)
    artifact_retention_class: Literal["hot", "warm", "cold", "archive"] | None = None
    cold_tier_after_days: int | None = Field(default=None, ge=0)
    reason: str = Field(default="Updated Work Function WORM quota policy", min_length=1, max_length=500)
    actor_id: str = Field(default="zara", min_length=1, max_length=120)


class WorkFunctionCapacityResponse(BaseModel):
    """Public capacity envelope projection."""

    provider_context: str
    always_on_quota: int
    zero_burn_target_usd: str
    max_concurrent: int
    budget_usd: float
    foreground_reservations: int
    active_workers: int
    degraded: bool
    degrade_reason: str | None
    provider_specific_limits: dict[str, object]


class WorkFunctionResponse(BaseModel):
    """Public Work Function projection."""

    function_id: str
    tenant_id: str
    name: str
    preset_id: str | None
    purpose: str
    connector_scopes: list[str]
    resource_policy_id: str | None
    coordination_protocol: str
    locality_preference: str
    autonomy_level: int
    state: WorkFunctionStateValue
    created_at: str
    updated_at: str
    archived_at: str | None
    deleted_at: str | None
    capacity: WorkFunctionCapacityResponse


class WorkFunctionTransitionResponse(BaseModel):
    """Public lifecycle transition projection."""

    function_id: str
    tenant_id: str
    from_state: WorkFunctionStateValue
    to_state: WorkFunctionStateValue
    reason: str
    actor_id: str
    timestamp: str
    decision_trace_id: str | None


class WorkFunctionDeletionCertificateResponse(BaseModel):
    """Public lifecycle deletion certificate projection."""

    function_id: str
    tenant_id: str
    deleted_at: str
    reason: str
    memory_tombstoned: bool
    skills_preserved: bool
    evidence_retained_until: str | None
    decision_trace_id: str | None


class WorkFunctionTombstoneResponse(BaseModel):
    """Public tombstone projection."""

    function_id: str
    tenant_id: str
    item_id: str
    item_type: str
    tombstoned_at: str
    reason: str
    redacted_fields: list[str]
    snapshot_preserved: bool
    evidence_retained_until: str | None


class WorkFunctionEvidenceExpiryResponse(BaseModel):
    """Public WORM evidence expiry projection."""

    function_id: str
    tenant_id: str
    evidence_id: str
    original_key: str
    expiry_date: str
    retention_days: int
    tombstone_id: str | None


class WorkFunctionDeletionResponsePayload(BaseModel):
    """Public GDPR deletion result projection."""

    function_id: str
    tenant_id: str
    memory_items_tombstoned: int
    skills_preserved: int
    evidence_items_expired: int
    evidence_retained_until: str | None
    tombstones: list[WorkFunctionTombstoneResponse]
    evidence_expiries: list[WorkFunctionEvidenceExpiryResponse]


class WorkFunctionDowngradeImpactResponse(BaseModel):
    """Public downgrade impact projection."""

    function_id: str
    current_max_concurrent: int
    new_max_concurrent: int
    current_active_workers: int
    action: str
    drain_required: bool
    connector_revocations: list[str]
    worm_quota_reduction_bytes: int


class WorkFunctionDowngradePreviewResponsePayload(BaseModel):
    """Public tenant downgrade preview projection."""

    tenant_id: str
    from_tier: str
    to_tier: str
    functions_affected: list[WorkFunctionDowngradeImpactResponse]
    functions_requiring_drain: int
    connectors_to_revoke: list[str]
    total_capacity_reduction: int
    estimated_drain_time_minutes: int
    reversible_until: str | None
    has_breaking_changes: bool
    summary: str


class WorkFunctionQuotaPolicyResponse(BaseModel):
    """Public Work Function WORM quota policy projection."""

    work_function_id: str
    storage_quota_gb: str | None
    workmemory_index_quota_mb: str | None
    artifact_retention_class: Literal["hot", "warm", "cold", "archive"]
    cold_tier_after_days: int | None


class WorkFunctionQuotaUsageResponse(BaseModel):
    """Public Work Function WORM quota usage projection."""

    work_function_id: str
    workspace_id: str
    storage_used_gb: str
    workmemory_index_used_mb: str
    artifact_count: int
    worm_evidence_count: int


class WorkFunctionQuotaDecisionResponse(BaseModel):
    """Public Work Function WORM quota decision projection."""

    work_function_id: str
    within_quota: bool
    storage_used_gb: str
    storage_quota_gb: str | None
    action: Literal["block", "request_approval", "compact_and_allow", "cold_tier"]
    reason: str


class WorkFunctionQuotaEnvelopeResponse(BaseModel):
    """Quota read/update envelope shared by REST, CLI, and MCP."""

    quota: WorkFunctionQuotaDecisionResponse
    usage: WorkFunctionQuotaUsageResponse
    headroom_gb: str | None
    policy_snapshot: WorkFunctionQuotaPolicyResponse | None
    policy: PolicyDecisionEnvelope
    decision_trace_id: str


class WorkFunctionPresetResponse(BaseModel):
    """Public Work Function preset projection."""

    key: str
    function_name: str
    agent_count: int
    tools: list[str]
    dormant: bool


class WorkFunctionDecisionTraceContext(BaseModel):
    """Replay-safe context emitted with Work Function API Decision Traces."""

    model_config = ConfigDict(frozen=True)

    reason: str
    drain_policy: str | None = None
    from_tier: str | None = None
    to_tier: str | None = None


class WorkFunctionCreateResponse(BaseModel):
    function: WorkFunctionResponse
    policy: PolicyDecisionEnvelope
    decision_trace_id: str


class WorkFunctionListResponse(BaseModel):
    functions: list[WorkFunctionResponse]
    count: int
    policy: PolicyDecisionEnvelope
    decision_trace_id: str


class WorkFunctionShowResponse(BaseModel):
    function: WorkFunctionResponse
    policy: PolicyDecisionEnvelope
    decision_trace_id: str


class WorkFunctionUpdateResponse(BaseModel):
    function: WorkFunctionResponse
    policy: PolicyDecisionEnvelope
    decision_trace_id: str


class WorkFunctionTransitionEnvelopeResponse(BaseModel):
    function: WorkFunctionResponse
    transition: WorkFunctionTransitionResponse
    policy: PolicyDecisionEnvelope
    decision_trace_id: str


class WorkFunctionDeleteResponse(BaseModel):
    function: WorkFunctionResponse
    transition: WorkFunctionTransitionResponse
    certificate: WorkFunctionDeletionCertificateResponse
    deletion: WorkFunctionDeletionResponsePayload
    policy: PolicyDecisionEnvelope
    decision_trace_id: str


class WorkFunctionDowngradePreviewResponse(BaseModel):
    preview: WorkFunctionDowngradePreviewResponsePayload
    policy: PolicyDecisionEnvelope
    decision_trace_id: str


class WorkFunctionPresetListResponse(BaseModel):
    presets: list[WorkFunctionPresetResponse]
    count: int
    policy: PolicyDecisionEnvelope
    decision_trace_id: str


class WorkFunctionDecisionTraceEmitter(Protocol):
    def __call__(
        self,
        *,
        tenant_id: str,
        function_id: str | None,
        action: str,
        outcome: str,
        policy_id: str | None,
        context: WorkFunctionDecisionTraceContext,
    ) -> str: ...


def get_work_function_service() -> WorkFunctionRegistryService:
    """Dependency hook for the Work Function registry service."""
    return get_work_function_registry_service()


_quota_service: WorkFunctionWormQuotaService | None = None


def get_work_function_quota_service() -> WorkFunctionWormQuotaService:
    """Dependency hook for the Work Function WORM quota service."""
    global _quota_service
    if _quota_service is None:
        _quota_service = WorkFunctionWormQuotaService(
            store=create_portable_store(resolve_table("work_functions"))
        )
    return _quota_service


def get_decision_trace_emitter() -> WorkFunctionDecisionTraceEmitter:
    """Dependency hook for Work Function Decision Trace emission."""
    return _capture_decision_trace


@router.get("/presets", response_model=WorkFunctionPresetListResponse)
async def list_work_function_presets(
    tenant_id: Annotated[str, Depends(get_verified_tenant_id)],
    service: Annotated[WorkFunctionRegistryService, Depends(get_work_function_service)],
    emit_decision_trace: Annotated[
        WorkFunctionDecisionTraceEmitter,
        Depends(get_decision_trace_emitter),
    ],
) -> WorkFunctionPresetListResponse:
    """List canonical dormant Work Function presets."""
    policy = _build_policy(tenant_id, "zara", "work_function.presets")
    trace_id = emit_decision_trace(
        tenant_id=tenant_id,
        function_id=None,
        action="work_function.presets",
        outcome="allowed",
        policy_id=_policy_id(policy),
        context=WorkFunctionDecisionTraceContext(reason="preset discovery"),
    )
    presets = [_preset_response(item) for item in service.list_presets()]
    return WorkFunctionPresetListResponse(
        presets=presets,
        count=len(presets),
        policy=policy,
        decision_trace_id=trace_id,
    )


@router.post("", response_model=WorkFunctionCreateResponse, status_code=status.HTTP_201_CREATED)
async def create_work_function(
    request: WorkFunctionCreateRequest,
    tenant_id: Annotated[str, Depends(get_verified_tenant_id)],
    admin_role: Annotated[UserRole, Depends(require_admin_user_role)],
    service: Annotated[WorkFunctionRegistryService, Depends(get_work_function_service)],
    emit_decision_trace: Annotated[
        WorkFunctionDecisionTraceEmitter,
        Depends(get_decision_trace_emitter),
    ],
) -> WorkFunctionCreateResponse:
    """Create a Work Function from a preset or custom request."""
    _assert_admin_role(admin_role)
    policy = _build_policy(tenant_id, request.actor_id, "work_function.create")
    try:
        record = service.create(tenant_id, _create_spec(request))
    except WorkFunctionConflictError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail=str(exc)) from exc
    trace_id = emit_decision_trace(
        tenant_id=tenant_id,
        function_id=record.function_id,
        action="work_function.create",
        outcome="allowed",
        policy_id=_policy_id(policy),
        context=WorkFunctionDecisionTraceContext(reason="created Work Function"),
    )
    return WorkFunctionCreateResponse(
        function=_function_response(service, record),
        policy=policy,
        decision_trace_id=trace_id,
    )


@router.get("", response_model=WorkFunctionListResponse)
async def list_work_functions(
    tenant_id: Annotated[str, Depends(get_verified_tenant_id)],
    service: Annotated[WorkFunctionRegistryService, Depends(get_work_function_service)],
    emit_decision_trace: Annotated[
        WorkFunctionDecisionTraceEmitter,
        Depends(get_decision_trace_emitter),
    ],
) -> WorkFunctionListResponse:
    """List tenant-scoped Work Functions."""
    policy = _build_policy(tenant_id, "zara", "work_function.list")
    records = service.list(tenant_id)
    trace_id = emit_decision_trace(
        tenant_id=tenant_id,
        function_id=None,
        action="work_function.list",
        outcome="allowed",
        policy_id=_policy_id(policy),
        context=WorkFunctionDecisionTraceContext(reason="listed Work Functions"),
    )
    return WorkFunctionListResponse(
        functions=[_function_response(service, record) for record in records],
        count=len(records),
        policy=policy,
        decision_trace_id=trace_id,
    )


@router.get("/{function_id}/quota", response_model=WorkFunctionQuotaEnvelopeResponse)
async def get_work_function_quota(
    function_id: str,
    tenant_id: Annotated[str, Depends(get_verified_tenant_id)],
    service: Annotated[WorkFunctionRegistryService, Depends(get_work_function_service)],
    quota_service: Annotated[WorkFunctionWormQuotaService, Depends(get_work_function_quota_service)],
    emit_decision_trace: Annotated[
        WorkFunctionDecisionTraceEmitter,
        Depends(get_decision_trace_emitter),
    ],
) -> WorkFunctionQuotaEnvelopeResponse:
    """Read a tenant-scoped Work Function WORM quota."""
    try:
        service.get(tenant_id, function_id)
    except WorkFunctionNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="function not found") from exc
    policy = _build_policy(tenant_id, "zara", "work_function.quota.check")
    trace_id = emit_decision_trace(
        tenant_id=tenant_id,
        function_id=function_id,
        action="work_function.quota.check",
        outcome="allowed",
        policy_id=_policy_id(policy),
        context=WorkFunctionDecisionTraceContext(reason="read Work Function WORM quota"),
    )
    return _quota_envelope(quota_service, tenant_id, function_id, policy, trace_id)


@router.post("/{function_id}/quota/policy", response_model=WorkFunctionQuotaEnvelopeResponse)
async def set_work_function_quota_policy(
    function_id: str,
    request: WorkFunctionQuotaPolicyRequest,
    tenant_id: Annotated[str, Depends(get_verified_tenant_id)],
    admin_role: Annotated[UserRole, Depends(require_admin_user_role)],
    service: Annotated[WorkFunctionRegistryService, Depends(get_work_function_service)],
    quota_service: Annotated[WorkFunctionWormQuotaService, Depends(get_work_function_quota_service)],
    emit_decision_trace: Annotated[
        WorkFunctionDecisionTraceEmitter,
        Depends(get_decision_trace_emitter),
    ],
) -> WorkFunctionQuotaEnvelopeResponse:
    """Set a tenant-scoped Work Function WORM quota policy."""
    _assert_admin_role(admin_role)
    try:
        service.get(tenant_id, function_id)
        current_policy = quota_service.get_policy(function_id, tenant_id=tenant_id)
        quota_service.set_policy(
            _quota_policy(function_id, request, current_policy),
            tenant_id=tenant_id,
        )
    except WorkFunctionNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="function not found") from exc
    except WormQuotaExceededError as exc:
        policy = _build_policy(tenant_id, request.actor_id, "work_function.quota.policy.denied")
        trace_id = emit_decision_trace(
            tenant_id=tenant_id,
            function_id=function_id,
            action="work_function.quota.policy.denied",
            outcome="denied",
            policy_id=_policy_id(policy),
            context=WorkFunctionDecisionTraceContext(reason=request.reason),
        )
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=_quota_exceeded_detail(exc, trace_id),
        ) from exc
    policy = _build_policy(tenant_id, request.actor_id, "work_function.quota.policy.changed")
    trace_id = emit_decision_trace(
        tenant_id=tenant_id,
        function_id=function_id,
        action="work_function.quota.policy.changed",
        outcome="allowed",
        policy_id=_policy_id(policy),
        context=WorkFunctionDecisionTraceContext(reason=request.reason),
    )
    return _quota_envelope(quota_service, tenant_id, function_id, policy, trace_id)


def _quota_exceeded_detail(exc: WormQuotaExceededError, trace_id: str) -> dict[str, str | None]:
    detail: dict[str, str | None] = {
        "code": "worm_storage_quota_exceeded",
        "message": str(exc),
        "function_id": exc.function_id,
        "action": exc.action.value,
        "decision_trace_id": trace_id,
    }
    if exc.current_storage_gb is not None or exc.requested_quota_gb is not None:
        detail["current_storage_gb"] = _decimal_text(exc.current_storage_gb)
        detail["requested_quota_gb"] = _decimal_text(exc.requested_quota_gb)
    if exc.current_workmemory_index_mb is not None or exc.requested_workmemory_index_quota_mb is not None:
        detail["current_workmemory_index_mb"] = _decimal_text(exc.current_workmemory_index_mb)
        detail["requested_workmemory_index_quota_mb"] = _decimal_text(
            exc.requested_workmemory_index_quota_mb
        )
    return detail


@router.get("/{function_id}", response_model=WorkFunctionShowResponse)
async def show_work_function(
    function_id: str,
    tenant_id: Annotated[str, Depends(get_verified_tenant_id)],
    service: Annotated[WorkFunctionRegistryService, Depends(get_work_function_service)],
    emit_decision_trace: Annotated[
        WorkFunctionDecisionTraceEmitter,
        Depends(get_decision_trace_emitter),
    ],
) -> WorkFunctionShowResponse:
    """Read one tenant-scoped Work Function."""
    policy = _build_policy(tenant_id, "zara", "work_function.show")
    try:
        record = service.get(tenant_id, function_id)
    except WorkFunctionNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="function not found") from exc
    trace_id = emit_decision_trace(
        tenant_id=tenant_id,
        function_id=function_id,
        action="work_function.show",
        outcome="allowed",
        policy_id=_policy_id(policy),
        context=WorkFunctionDecisionTraceContext(reason="read Work Function"),
    )
    return WorkFunctionShowResponse(
        function=_function_response(service, record),
        policy=policy,
        decision_trace_id=trace_id,
    )


@router.patch("/{function_id}", response_model=WorkFunctionUpdateResponse)
async def update_work_function(
    function_id: str,
    request: WorkFunctionUpdateRequest,
    tenant_id: Annotated[str, Depends(get_verified_tenant_id)],
    admin_role: Annotated[UserRole, Depends(require_admin_user_role)],
    service: Annotated[WorkFunctionRegistryService, Depends(get_work_function_service)],
    emit_decision_trace: Annotated[
        WorkFunctionDecisionTraceEmitter,
        Depends(get_decision_trace_emitter),
    ],
) -> WorkFunctionUpdateResponse:
    """Update Work Function locality, autonomy, or capacity."""
    _assert_admin_role(admin_role)
    policy = _build_policy(tenant_id, request.actor_id, "work_function.update")
    try:
        active_workers = (
            service.get_capacity(tenant_id, function_id).active_workers
            if request.capacity is not None
            else 0
        )
        record = service.update(tenant_id, function_id, _update_spec(request, active_workers=active_workers))
    except WorkFunctionNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="function not found") from exc
    trace_id = emit_decision_trace(
        tenant_id=tenant_id,
        function_id=function_id,
        action="work_function.update",
        outcome="allowed",
        policy_id=_policy_id(policy),
        context=WorkFunctionDecisionTraceContext(reason=request.reason),
    )
    return WorkFunctionUpdateResponse(
        function=_function_response(service, record),
        policy=policy,
        decision_trace_id=trace_id,
    )


@router.post("/{function_id}/archive", response_model=WorkFunctionTransitionEnvelopeResponse)
async def archive_work_function(
    function_id: str,
    request: WorkFunctionArchiveRequest,
    tenant_id: Annotated[str, Depends(get_verified_tenant_id)],
    admin_role: Annotated[UserRole, Depends(require_admin_user_role)],
    service: Annotated[WorkFunctionRegistryService, Depends(get_work_function_service)],
    emit_decision_trace: Annotated[
        WorkFunctionDecisionTraceEmitter,
        Depends(get_decision_trace_emitter),
    ],
) -> WorkFunctionTransitionEnvelopeResponse:
    """Archive an active Work Function after applying the drain policy."""
    _assert_admin_role(admin_role)
    policy = _build_policy(tenant_id, request.actor_id, "work_function.archive")
    try:
        record, transition = service.archive(
            tenant_id,
            function_id,
            reason=request.reason,
            actor_id=request.actor_id,
            drain_policy=request.drain_policy,
        )
    except WorkFunctionNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="function not found") from exc
    except WorkFunctionConflictError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    except FunctionLifecycleError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    trace_id = emit_decision_trace(
        tenant_id=tenant_id,
        function_id=function_id,
        action="work_function.archive",
        outcome="allowed",
        policy_id=_policy_id(policy),
        context=WorkFunctionDecisionTraceContext(
            reason=request.reason,
            drain_policy=request.drain_policy,
        ),
    )
    return WorkFunctionTransitionEnvelopeResponse(
        function=_function_response(service, record),
        transition=_transition_response(transition, trace_id),
        policy=policy,
        decision_trace_id=trace_id,
    )


@router.post("/{function_id}/reactivate", response_model=WorkFunctionTransitionEnvelopeResponse)
async def reactivate_work_function(
    function_id: str,
    request: WorkFunctionReactivateRequest,
    tenant_id: Annotated[str, Depends(get_verified_tenant_id)],
    admin_role: Annotated[UserRole, Depends(require_admin_user_role)],
    service: Annotated[WorkFunctionRegistryService, Depends(get_work_function_service)],
    emit_decision_trace: Annotated[
        WorkFunctionDecisionTraceEmitter,
        Depends(get_decision_trace_emitter),
    ],
) -> WorkFunctionTransitionEnvelopeResponse:
    """Reactivate an archived Work Function."""
    _assert_admin_role(admin_role)
    policy = _build_policy(tenant_id, request.actor_id, "work_function.reactivate")
    try:
        record, transition = service.reactivate(
            tenant_id,
            function_id,
            reason=request.reason,
            actor_id=request.actor_id,
        )
    except WorkFunctionNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="function not found") from exc
    except FunctionLifecycleError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    trace_id = emit_decision_trace(
        tenant_id=tenant_id,
        function_id=function_id,
        action="work_function.reactivate",
        outcome="allowed",
        policy_id=_policy_id(policy),
        context=WorkFunctionDecisionTraceContext(reason=request.reason),
    )
    return WorkFunctionTransitionEnvelopeResponse(
        function=_function_response(service, record),
        transition=_transition_response(transition, trace_id),
        policy=policy,
        decision_trace_id=trace_id,
    )


@router.delete("/{function_id}", response_model=WorkFunctionDeleteResponse)
async def delete_work_function(
    function_id: str,
    request: Annotated[WorkFunctionDeleteRequest, Body()],
    tenant_id: Annotated[str, Depends(get_verified_tenant_id)],
    admin_role: Annotated[UserRole, Depends(require_admin_user_role)],
    service: Annotated[WorkFunctionRegistryService, Depends(get_work_function_service)],
    emit_decision_trace: Annotated[
        WorkFunctionDecisionTraceEmitter,
        Depends(get_decision_trace_emitter),
    ],
) -> WorkFunctionDeleteResponse:
    """Tombstone a Work Function and return GDPR deletion proof."""
    _assert_admin_role(admin_role)
    policy = _build_policy(tenant_id, request.actor_id, "work_function.delete")
    try:
        record, transition, certificate, deletion = service.delete(
            tenant_id,
            function_id,
            reason=request.reason,
            actor_id=request.actor_id,
            evidence_retention_days=request.evidence_retention_days,
        )
    except WorkFunctionNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="function not found") from exc
    except FunctionLifecycleError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc)) from exc
    trace_id = emit_decision_trace(
        tenant_id=tenant_id,
        function_id=function_id,
        action="work_function.delete",
        outcome="allowed",
        policy_id=_policy_id(policy),
        context=WorkFunctionDecisionTraceContext(reason=request.reason),
    )
    return WorkFunctionDeleteResponse(
        function=_function_response(service, record),
        transition=_transition_response(transition, trace_id),
        certificate=_certificate_response(certificate, trace_id),
        deletion=_deletion_response(deletion),
        policy=policy,
        decision_trace_id=trace_id,
    )


@router.post("/{function_id}/downgrade-preview", response_model=WorkFunctionDowngradePreviewResponse)
async def preview_work_function_downgrade(
    function_id: str,
    request: WorkFunctionDowngradePreviewRequest,
    tenant_id: Annotated[str, Depends(get_verified_tenant_id)],
    service: Annotated[WorkFunctionRegistryService, Depends(get_work_function_service)],
    emit_decision_trace: Annotated[
        WorkFunctionDecisionTraceEmitter,
        Depends(get_decision_trace_emitter),
    ],
) -> WorkFunctionDowngradePreviewResponse:
    """Preview Function impact before applying a tier downgrade."""
    policy = _build_policy(tenant_id, request.actor_id, "work_function.downgrade_preview")
    try:
        preview = service.downgrade_preview(
            tenant_id,
            function_id,
            WorkFunctionDowngradePreviewSpec(
                from_tier=request.from_tier,
                to_tier=request.to_tier,
                tier_limits=request.tier_limits,
                active_connectors=request.active_connectors,
                tier_connectors=request.tier_connectors,
            ),
        )
    except WorkFunctionNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="function not found") from exc
    trace_id = emit_decision_trace(
        tenant_id=tenant_id,
        function_id=function_id,
        action="work_function.downgrade_preview",
        outcome="blocked" if preview.has_breaking_changes else "allowed",
        policy_id=_policy_id(policy),
        context=WorkFunctionDecisionTraceContext(
            reason=preview.summary,
            from_tier=request.from_tier,
            to_tier=request.to_tier,
        ),
    )
    return WorkFunctionDowngradePreviewResponse(
        preview=_downgrade_preview_response(preview),
        policy=policy,
        decision_trace_id=trace_id,
    )


def _create_spec(request: WorkFunctionCreateRequest) -> WorkFunctionCreateSpec:
    return WorkFunctionCreateSpec(
        name=request.name,
        preset_id=request.preset_id,
        purpose=request.purpose,
        connector_scopes=request.connector_scopes,
        resource_policy_id=request.resource_policy_id,
        coordination_protocol=request.coordination_protocol,
        locality_preference=request.locality_preference,
        autonomy_level=request.autonomy_level,
        initial_state=FunctionLifecycleState(request.initial_state),
        capacity=_capacity_spec(request.capacity),
    )


def _assert_admin_role(admin_role: Any) -> None:
    if admin_role != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin role required",
        )


def _update_spec(request: WorkFunctionUpdateRequest, *, active_workers: int = 0) -> WorkFunctionUpdateSpec:
    return WorkFunctionUpdateSpec(
        locality_preference=request.locality_preference,
        autonomy_level=request.autonomy_level,
        capacity=_capacity_spec(request.capacity, active_workers=active_workers) if request.capacity is not None else None,
        reason=request.reason,
    )


def _capacity_spec(request: WorkFunctionCapacityRequest, *, active_workers: int = 0) -> WorkFunctionCapacitySpec:
    return WorkFunctionCapacitySpec(
        max_concurrent=request.max_concurrent,
        budget_usd=request.budget_usd,
        foreground_reservations=request.foreground_reservations,
        always_on_quota=request.always_on_quota,
        active_workers=active_workers,
        zero_burn_target_usd=request.zero_burn_target_usd,
        provider_specific_limits=request.provider_specific_limits,
    )


def _quota_policy(
    function_id: str,
    request: WorkFunctionQuotaPolicyRequest,
    current: WorkFunctionStoragePolicy | None,
) -> WorkFunctionStoragePolicy:
    retention_class = _quota_request_value(request, "artifact_retention_class", current)
    cold_tier_after_days = _quota_request_value(request, "cold_tier_after_days", current)
    return WorkFunctionStoragePolicy(
        work_function_id=function_id,
        storage_quota_gb=_quota_request_value(request, "storage_quota_gb", current),
        workmemory_index_quota_mb=_quota_request_value(request, "workmemory_index_quota_mb", current),
        artifact_retention_class=RetentionClass(retention_class or RetentionClass.HOT.value),
        cold_tier_after_days=cold_tier_after_days,
    )


def _quota_request_value(
    request: WorkFunctionQuotaPolicyRequest,
    field_name: str,
    current: WorkFunctionStoragePolicy | None,
) -> Any:
    if field_name in request.model_fields_set:
        return getattr(request, field_name)
    if current is None:
        return getattr(request, field_name)
    return getattr(current, field_name)


def _quota_envelope(
    quota_service: WorkFunctionWormQuotaService,
    tenant_id: str,
    function_id: str,
    policy: PolicyDecisionEnvelope,
    trace_id: str,
) -> WorkFunctionQuotaEnvelopeResponse:
    usage = quota_service.get_usage(function_id, tenant_id=tenant_id) or StorageUsage(
        work_function_id=function_id,
        workspace_id=tenant_id,
    )
    policy_snapshot = quota_service.get_policy(function_id, tenant_id=tenant_id)
    quota = quota_service.check_quota(function_id, tenant_id=tenant_id)
    return WorkFunctionQuotaEnvelopeResponse(
        quota=_quota_decision_response(quota),
        usage=_quota_usage_response(usage, tenant_id),
        headroom_gb=_quota_headroom(quota),
        policy_snapshot=_quota_policy_response(policy_snapshot),
        policy=policy,
        decision_trace_id=trace_id,
    )


def _quota_decision_response(result: QuotaCheckResult) -> WorkFunctionQuotaDecisionResponse:
    return WorkFunctionQuotaDecisionResponse(
        work_function_id=result.work_function_id,
        within_quota=result.within_quota,
        storage_used_gb=_decimal_text(result.storage_used_gb),
        storage_quota_gb=_decimal_text(result.storage_quota_gb),
        action=result.action.value,  # type: ignore[arg-type]
        reason=result.reason,
    )


def _quota_usage_response(usage: StorageUsage, tenant_id: str) -> WorkFunctionQuotaUsageResponse:
    return WorkFunctionQuotaUsageResponse(
        work_function_id=usage.work_function_id,
        workspace_id=usage.workspace_id or tenant_id,
        storage_used_gb=_decimal_text(usage.storage_used_gb),
        workmemory_index_used_mb=_decimal_text(usage.workmemory_index_used_mb),
        artifact_count=usage.artifact_count,
        worm_evidence_count=usage.worm_evidence_count,
    )


def _quota_policy_response(policy: WorkFunctionStoragePolicy | None) -> WorkFunctionQuotaPolicyResponse | None:
    if policy is None:
        return None
    return WorkFunctionQuotaPolicyResponse(
        work_function_id=policy.work_function_id,
        storage_quota_gb=_decimal_text(policy.storage_quota_gb),
        workmemory_index_quota_mb=_decimal_text(policy.workmemory_index_quota_mb),
        artifact_retention_class=policy.artifact_retention_class.value,  # type: ignore[arg-type]
        cold_tier_after_days=policy.cold_tier_after_days,
    )


def _quota_headroom(result: QuotaCheckResult) -> str | None:
    if result.storage_quota_gb is None:
        return None
    remaining = max(Decimal("0"), result.storage_quota_gb - result.storage_used_gb)
    return _decimal_text(remaining)


def _decimal_text(value: Decimal | None) -> str | None:
    if value is None:
        return None
    return format(value.normalize(), "f")


def _function_response(
    service: WorkFunctionRegistryService,
    record: WorkFunctionRecord,
) -> WorkFunctionResponse:
    capacity = service.get_capacity(record.tenant_id, record.function_id)
    return WorkFunctionResponse(
        function_id=record.function_id,
        tenant_id=record.tenant_id,
        name=record.name,
        preset_id=record.preset_id,
        purpose=record.purpose,
        connector_scopes=record.connector_scopes,
        resource_policy_id=record.resource_policy_id,
        coordination_protocol=record.coordination_protocol,
        locality_preference=record.locality_preference,
        autonomy_level=record.autonomy_level,
        state=record.state.value,  # type: ignore[arg-type]
        created_at=record.created_at,
        updated_at=record.updated_at,
        archived_at=record.archived_at,
        deleted_at=record.deleted_at,
        capacity=_capacity_response(capacity),
    )


def _capacity_response(envelope: FunctionCapacityEnvelope) -> WorkFunctionCapacityResponse:
    return WorkFunctionCapacityResponse(
        provider_context=envelope.provider_context,
        always_on_quota=envelope.always_on_quota,
        zero_burn_target_usd=str(envelope.zero_burn_target_usd),
        max_concurrent=envelope.max_concurrent,
        budget_usd=envelope.budget_usd,
        foreground_reservations=envelope.foreground_reservations,
        active_workers=envelope.active_workers,
        degraded=envelope.degraded,
        degrade_reason=envelope.degrade_reason,
        provider_specific_limits=dict(envelope.provider_specific_limits),
    )


def _transition_response(
    transition: FunctionLifecycleTransition,
    trace_id: str,
) -> WorkFunctionTransitionResponse:
    return WorkFunctionTransitionResponse(
        function_id=transition.function_id,
        tenant_id=transition.tenant_id,
        from_state=transition.from_state.value,  # type: ignore[arg-type]
        to_state=transition.to_state.value,  # type: ignore[arg-type]
        reason=transition.reason,
        actor_id=transition.actor_id,
        timestamp=transition.timestamp,
        decision_trace_id=trace_id,
    )


def _certificate_response(
    certificate: FunctionDeletionCertificate,
    trace_id: str,
) -> WorkFunctionDeletionCertificateResponse:
    return WorkFunctionDeletionCertificateResponse(
        function_id=certificate.function_id,
        tenant_id=certificate.tenant_id,
        deleted_at=certificate.deleted_at,
        reason=certificate.reason,
        memory_tombstoned=certificate.memory_tombstoned,
        skills_preserved=certificate.skills_preserved,
        evidence_retained_until=certificate.evidence_retained_until,
        decision_trace_id=trace_id,
    )


def _deletion_response(result: GdprDeletionResult) -> WorkFunctionDeletionResponsePayload:
    return WorkFunctionDeletionResponsePayload(
        function_id=result.function_id,
        tenant_id=result.tenant_id,
        memory_items_tombstoned=result.memory_items_tombstoned,
        skills_preserved=result.skills_preserved,
        evidence_items_expired=result.evidence_items_expired,
        evidence_retained_until=result.evidence_retained_until,
        tombstones=[_tombstone_response(item) for item in result.tombstones],
        evidence_expiries=[_evidence_expiry_response(item) for item in result.evidence_expiries],
    )


def _tombstone_response(tombstone: GdprTombstone) -> WorkFunctionTombstoneResponse:
    return WorkFunctionTombstoneResponse(**tombstone.model_dump(mode="json"))


def _evidence_expiry_response(expiry: EvidenceExpiry) -> WorkFunctionEvidenceExpiryResponse:
    return WorkFunctionEvidenceExpiryResponse(**expiry.model_dump(mode="json"))


def _downgrade_preview_response(
    preview: TenantDowngradePreview,
) -> WorkFunctionDowngradePreviewResponsePayload:
    return WorkFunctionDowngradePreviewResponsePayload(
        tenant_id=preview.tenant_id,
        from_tier=preview.from_tier,
        to_tier=preview.to_tier,
        functions_affected=[_downgrade_impact_response(item) for item in preview.functions_affected],
        functions_requiring_drain=preview.functions_requiring_drain,
        connectors_to_revoke=preview.connectors_to_revoke,
        total_capacity_reduction=preview.total_capacity_reduction,
        estimated_drain_time_minutes=preview.estimated_drain_time_minutes,
        reversible_until=preview.reversible_until,
        has_breaking_changes=preview.has_breaking_changes,
        summary=preview.summary,
    )


def _downgrade_impact_response(
    impact: FunctionDowngradeImpact,
) -> WorkFunctionDowngradeImpactResponse:
    return WorkFunctionDowngradeImpactResponse(
        function_id=impact.function_id,
        current_max_concurrent=impact.current_max_concurrent,
        new_max_concurrent=impact.new_max_concurrent,
        current_active_workers=impact.current_active_workers,
        action=impact.action,
        drain_required=impact.drain_required,
        connector_revocations=impact.connector_revocations,
        worm_quota_reduction_bytes=impact.worm_quota_reduction_bytes,
    )


def _preset_response(item: dict[str, object]) -> WorkFunctionPresetResponse:
    return WorkFunctionPresetResponse(
        key=str(item["key"]),
        function_name=str(item["function_name"]),
        agent_count=int(item["agent_count"]),
        tools=[str(tool) for tool in item.get("tools", [])],
        dormant=bool(item["dormant"]),
    )


def _build_policy(
    tenant_id: str,
    actor_id: str,
    action: str,
) -> PolicyDecisionEnvelope:
    return build_policy_decision_envelope(
        "work_function",
        tenant_id=tenant_id,
        actor={"actor_id": actor_id},
        inputs={
            "action": action,
            "risk_tier": "governed_work_function",
            "budget_verdict": "ALLOW",
            "budget_reason": "Work Function lifecycle mutation uses existing tenant capacity policy.",
            "side_effect_proof_reason": "Decision Trace emitted by Work Function REST surface",
        },
    )


def _policy_id(policy: PolicyDecisionEnvelope) -> str:
    return f"{policy.tenant_id}:{policy.action}:{policy.final_verdict}"


def _capture_decision_trace(
    tenant_id: str,
    function_id: str | None,
    action: str,
    outcome: str,
    policy_id: str | None,
    context: WorkFunctionDecisionTraceContext,
) -> str:
    try:
        from apps.backend.services.context.decision_event_capture import capture_decision

        result = capture_decision(
            tenant_id=tenant_id,
            skill_id=function_id or "work_functions",
            decision_summary=f"{action}: {context.reason}",
            decision_type=action,
            outcome=outcome,
            policy_id=policy_id,
            capture_surface="api",
            service_family="work_functions",
            context_data={
                "function_id": function_id,
                "reason": context.reason,
                "drain_policy": context.drain_policy,
                "from_tier": context.from_tier,
                "to_tier": context.to_tier,
            },
        )
        if result.success and result.trace_id:
            return result.trace_id
        logger.warning("work_functions.decision_trace_failed action=%s error=%s", action, result.error)
    except Exception:
        logger.warning("work_functions.decision_trace_exception action=%s", action, exc_info=True)
    return f"uncaptured:{action}"


# ---------------------------------------------------------------------------
# Zero-burn SLI + reap-idle endpoints (#3245)
# ---------------------------------------------------------------------------


class ZeroBurnSnapshotResponse(BaseModel):
    """Response for GET /work-functions/{id}/zero-burn-snapshot."""

    workspace_id: str
    work_function_id: str
    window_started_at: str
    window_ended_at: str
    capacity_leases: int = 0
    active_workers: int = 0
    queue_consumers: int = 0
    connector_sessions: int = 0
    scheduler_claims: int = 0
    cloud_tasks: int = 0
    function_metering_events: int = 0
    billable_compute_units: str = "0"
    is_zero_burn: bool
    decision_trace_id: str | None = None


class ReapIdleRequest(BaseModel):
    """Request for POST /work-functions/{id}/reap-idle."""

    idle_threshold_minutes: int = Field(default=30, ge=1, le=1440)
    dry_run: bool = Field(default=False)
    actor_id: str = Field(default="zara", min_length=1, max_length=120)


class ReapIdleResponse(BaseModel):
    """Response for POST /work-functions/{id}/reap-idle."""

    work_function_id: str
    dry_run: bool
    reaped_envelope_ids: list[str]
    reaped_count: int
    decision_trace_id: str | None = None


@router.get(
    "/{function_id}/zero-burn-snapshot",
    response_model=ZeroBurnSnapshotResponse,
    summary="Zero-burn SLI snapshot for a Work Function",
)
async def get_zero_burn_snapshot(
    function_id: str,
    tenant_id: Annotated[str, Depends(get_verified_tenant_id)],
    service: Annotated[WorkFunctionRegistryService, Depends(get_work_function_service)],
    emit_decision_trace: Annotated[
        WorkFunctionDecisionTraceEmitter,
        Depends(get_decision_trace_emitter),
    ],
    window_hours: int = 24,
) -> ZeroBurnSnapshotResponse:
    """Return the current zero-burn SLI snapshot for a Work Function."""
    try:
        service.get(tenant_id, function_id)
    except WorkFunctionNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="function not found") from exc

    from apps.backend.services.capacity.zero_burn_sli import ZeroBurnSLIService

    sli = ZeroBurnSLIService()
    snap = sli.snapshot(tenant_id, function_id, window_hours=window_hours)

    trace_id = emit_decision_trace(
        tenant_id=tenant_id,
        function_id=function_id,
        action="function.sli.snapshot.viewed",
        outcome="allowed",
        policy_id=None,
        context=WorkFunctionDecisionTraceContext(reason="zero-burn SLI snapshot"),
    )

    return ZeroBurnSnapshotResponse(
        workspace_id=snap.workspace_id,
        work_function_id=snap.work_function_id,
        window_started_at=snap.window_started_at.isoformat(),
        window_ended_at=snap.window_ended_at.isoformat(),
        capacity_leases=snap.capacity_leases,
        active_workers=snap.active_workers,
        queue_consumers=snap.queue_consumers,
        connector_sessions=snap.connector_sessions,
        scheduler_claims=snap.scheduler_claims,
        cloud_tasks=snap.cloud_tasks,
        function_metering_events=snap.function_metering_events,
        billable_compute_units=str(snap.billable_compute_units),
        is_zero_burn=snap.is_zero_burn,
        decision_trace_id=trace_id,
    )


@router.post(
    "/{function_id}/reap-idle",
    response_model=ReapIdleResponse,
    summary="Reap idle resource envelopes for a Work Function",
)
async def reap_idle_envelopes(
    function_id: str,
    request: ReapIdleRequest,
    tenant_id: Annotated[str, Depends(get_verified_tenant_id)],
    service: Annotated[WorkFunctionRegistryService, Depends(get_work_function_service)],
    emit_decision_trace: Annotated[
        WorkFunctionDecisionTraceEmitter,
        Depends(get_decision_trace_emitter),
    ],
) -> ReapIdleResponse:
    """Terminate idle resource envelopes for a Work Function (zero-burn guarantee)."""
    try:
        service.get(tenant_id, function_id)
    except WorkFunctionNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="function not found") from exc

    from apps.backend.services.capacity.zero_burn_envelope import ZeroBurnEnvelopeService

    envelope_svc = ZeroBurnEnvelopeService()
    if request.dry_run:
        idle = envelope_svc.get_idle_envelopes()
        reaped_ids = [e.envelope_id for e in idle if e.function_id == function_id and e.tenant_id == tenant_id]
    else:
        reaped_ids = envelope_svc.reap_idle()

    trace_id = emit_decision_trace(
        tenant_id=tenant_id,
        function_id=function_id,
        action="function.sli.reap.executed",
        outcome="allowed" if not request.dry_run else "dry_run",
        policy_id=None,
        context=WorkFunctionDecisionTraceContext(reason="reap idle envelopes"),
    )

    return ReapIdleResponse(
        work_function_id=function_id,
        dry_run=request.dry_run,
        reaped_envelope_ids=reaped_ids,
        reaped_count=len(reaped_ids),
        decision_trace_id=trace_id,
    )

