"""Admin embedding migration + orchestrator + policy endpoints (#2692, #3209, #3210).

Provides platform-level controls for embedding model selection and migration:

  GET    /api/v1/founder/embedding/status                — get all tenants' embedding status
  POST   /api/v1/founder/embedding/migrate               — start migration for tenant
  GET    /api/v1/founder/embedding/migration-status       — get migration status
  POST   /api/v1/founder/embedding/rollback              — rollback migration

  # #3210 — resumable orchestrator surfaces:
  POST   /api/v1/founder/embedding/migration/{tenant_id}              — start (idempotent on migration_id)
  GET    /api/v1/founder/embedding/migration/{tenant_id}/status        — list persisted migrations
  GET    /api/v1/founder/embedding/migration/{tenant_id}/{migration_id} — show one migration

  # #3209 — per-Purpose × per-tenant policy grid:
  GET    /api/v1/founder/embedding/policy                — list policies (platform + per-tenant)
  GET    /api/v1/founder/embedding/policy/{tenant_id}    — show one policy
  PUT    /api/v1/founder/embedding/policy/{tenant_id}    — set policy (per-Purpose overrides)
  DELETE /api/v1/founder/embedding/policy/{tenant_id}    — drop tenant override (revert to platform default)

All endpoints require founder auth and the corresponding admin permission.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field, field_validator

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.api.founder_admin import require_founder
from apps.backend.services.admin.admin_permission import AdminPermission
from apps.backend.services.inference.admin_embedding_policy_store import (
    AdminEmbeddingPolicyStore,
    get_admin_embedding_policy_store,
)
from apps.backend.workmemory.models.tenant_embedding_policy import (
    SUPPORTED_PROVIDERS,
    TenantEmbeddingPolicy,
)
from apps.backend.workmemory.services.embedding_migration import (
    EmbeddingMigrationService,
    EmbeddingSchemaVersion,
)
from apps.backend.workmemory.services.embedding_migration_orchestrator import (
    EmbeddingMigrationOrchestrator,
    MigrationState,
    get_embedding_migration_orchestrator,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/founder/embedding", tags=["founder-admin-embedding"])


class MigrationRequest(BaseModel):
    """Request to start embedding migration for a tenant."""

    tenant_id: str = Field(..., description="Tenant ID to migrate")
    target_mode: str = Field(..., description="Target mode: aws_only, google_enabled, dual_provider")
    target_model: str = Field(..., description="Target model ID")


class RollbackRequest(BaseModel):
    """Request to rollback embedding migration."""

    tenant_id: str = Field(..., description="Tenant ID to rollback")


def _get_migration_service() -> EmbeddingMigrationService:
    return EmbeddingMigrationService()


@router.get("/status")
async def get_embedding_status(
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.EMBEDDING_READ)),
) -> dict[str, Any]:
    """Return embedding status for all tenants.

    Returns current embedding model, mode, and item count for each tenant.
    """
    # Placeholder: return all tenants with their embedding policy
    # In production, this would scan the tenants table
    return {
        "tenants": [
            {
                "id": "tenant-000000000000000000000000",
                "mode": "aws_only",
                "provider": "bedrock",
                "model": "amazon.titan-embed-text-v2:0",
                "dimensions": 1024,
                "item_count": 0,
            }
        ],
        "total_tenants": 1,
    }


@router.post("/migrate")
async def start_migration(
    request: MigrationRequest,
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.EMBEDDING_READ)),
) -> dict[str, Any]:
    """Start embedding migration for a tenant.

    Validates the target mode and model, then initiates the migration
    through the dual-write lifecycle.
    """
    service = _get_migration_service()

    # Validate target mode
    valid_modes = ["aws_only", "google_enabled", "dual_provider"]
    if request.target_mode not in valid_modes:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid target_mode. Must be one of: {', '.join(valid_modes)}",
        )

    # Build schema version objects for the migration service
    old_version = EmbeddingSchemaVersion(
        model_id="amazon.titan-embed-text-v2:0",
        dimension=1024,
    )
    new_version = EmbeddingSchemaVersion(
        model_id=request.target_model,
        dimension=1024,  # default; caller should specify exact dims
    )

    try:
        result_state = service.start_migration(
            old_version=old_version,
            new_version=new_version,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    except Exception as exc:
        logger.error("Failed to start migration: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to start migration: {exc}",
        ) from exc

    return {
        "status": "started",
        "tenant_id": request.tenant_id,
        "state": result_state.value,
        "target_mode": request.target_mode,
        "target_model": request.target_model,
    }


@router.get("/migration-status")
async def get_migration_status(
    tenant_id: str,
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.EMBEDDING_READ)),
) -> dict[str, Any]:
    """Return migration status for a tenant."""
    service = _get_migration_service()

    try:
        status = service.get_migration_status(tenant_id)
        return {
            "tenant_id": tenant_id,
            "state": status.state.value if hasattr(status, 'state') else 'unknown',
            "progress": getattr(status, 'progress', 0),
            "failed_count": getattr(status, 'failed_count', 0),
        }
    except Exception as exc:
        logger.error("Failed to get migration status: %s", exc)
        return {
            "tenant_id": tenant_id,
            "state": "unknown",
            "error": str(exc),
        }


@router.post("/rollback")
async def rollback_migration(
    request: RollbackRequest,
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.EMBEDDING_READ)),
) -> dict[str, Any]:
    """Rollback an ongoing or completed migration."""
    service = _get_migration_service()

    try:
        service.rollback_migration(request.tenant_id)
        return {
            "status": "rolled_back",
            "tenant_id": request.tenant_id,
        }
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=str(exc),
        ) from exc
    except Exception as exc:
        logger.error("Failed to rollback migration: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Failed to rollback: {exc}",
        ) from exc


# ──────────────────────────────────────────────────────────────────────────
# #3210 — Resumable embedding migration orchestrator
# ──────────────────────────────────────────────────────────────────────────


class StartMigrationRequest(BaseModel):
    from_model: str = Field(..., min_length=1, description="Current embedding model id")
    to_model: str = Field(..., min_length=1, description="Target embedding model id")
    migration_id: str | None = Field(
        default=None,
        description=(
            "Optional client-supplied migration id. Useful for resuming after a "
            "kill -9: pass the same value and the orchestrator returns the "
            "persisted state without restarting."
        ),
    )


class MigrationStateResponse(BaseModel):
    tenant_id: str
    migration_id: str
    from_model: str
    to_model: str
    phase: str
    cursor: str | None
    items_processed: int
    items_failed: int
    evaluated_recall_at_10: float | None
    alias_swapped_at: str | None
    started_at: str
    updated_at: str
    last_error: str | None


class MigrationStateListResponse(BaseModel):
    tenant_id: str
    migrations: list[MigrationStateResponse]


def _get_migration_orchestrator() -> EmbeddingMigrationOrchestrator:
    return get_embedding_migration_orchestrator()


def _migration_state_to_response(state: MigrationState) -> dict[str, Any]:
    return {
        "tenant_id": state.tenant_id,
        "migration_id": state.migration_id,
        "from_model": state.from_model,
        "to_model": state.to_model,
        "phase": state.phase.value,
        "cursor": state.cursor,
        "items_processed": state.items_processed,
        "items_failed": state.items_failed,
        "evaluated_recall_at_10": state.evaluated_recall_at_10,
        "alias_swapped_at": state.alias_swapped_at,
        "started_at": state.started_at,
        "updated_at": state.updated_at,
        "last_error": state.last_error,
    }


@router.post("/migration/{tenant_id}", response_model=MigrationStateResponse)
async def start_or_resume_migration(
    tenant_id: str,
    body: StartMigrationRequest,
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.EMBEDDING_WRITE)),
    orchestrator: EmbeddingMigrationOrchestrator = Depends(_get_migration_orchestrator),
) -> dict[str, Any]:
    """Start a migration (or resume an in-flight one).

    Idempotent on ``migration_id``: re-posting the same id returns the
    persisted state, which is how a CLI/operator recovers after a ``kill -9``
    interrupted the orchestrator process.
    """

    target = (tenant_id or "").strip()
    if not target:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="tenant_id is required.",
        )
    state = orchestrator.start_or_resume(
        tenant_id=target,
        from_model=body.from_model,
        to_model=body.to_model,
        migration_id=body.migration_id,
    )
    return _migration_state_to_response(state)


@router.get(
    "/migration/{tenant_id}/status",
    response_model=MigrationStateListResponse,
)
async def list_migration_states(
    tenant_id: str,
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.EMBEDDING_READ)),
    orchestrator: EmbeddingMigrationOrchestrator = Depends(_get_migration_orchestrator),
) -> dict[str, Any]:
    """List every migration we have persisted state for under ``tenant_id``."""

    target = (tenant_id or "").strip()
    if not target:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="tenant_id is required.",
        )
    states = orchestrator.list_states(target)
    return {
        "tenant_id": target,
        "migrations": [_migration_state_to_response(s) for s in states],
    }


@router.get(
    "/migration/{tenant_id}/{migration_id}",
    response_model=MigrationStateResponse,
)
async def get_migration_state(
    tenant_id: str,
    migration_id: str,
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.EMBEDDING_READ)),
    orchestrator: EmbeddingMigrationOrchestrator = Depends(_get_migration_orchestrator),
) -> dict[str, Any]:
    """Read one migration's persisted state by id."""

    target = (tenant_id or "").strip()
    if not target or not migration_id.strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="tenant_id and migration_id are required.",
        )
    state = orchestrator.get_state(target, migration_id.strip())
    if state is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Migration {migration_id!r} not found for tenant {target!r}.",
        )
    return _migration_state_to_response(state)


# ──────────────────────────────────────────────────────────────────────────
# #3209 — Per-Purpose × per-tenant embedding policy grid
# ──────────────────────────────────────────────────────────────────────────


PLATFORM_TENANT_TOKEN = "__platform__"


class EmbeddingPolicyResponse(BaseModel):
    tenant_id: str = Field(..., description="Tenant id; '__platform__' for the global default.")
    mode: str = Field(..., description="aws_only | google_enabled | dual_provider")
    per_purpose_overrides: dict[str, str] = Field(default_factory=dict)


class EmbeddingPolicyListResponse(BaseModel):
    policies: list[EmbeddingPolicyResponse]
    supported_providers: list[str] = Field(default_factory=lambda: sorted(SUPPORTED_PROVIDERS))


class SetEmbeddingPolicyRequest(BaseModel):
    mode: str = Field(default="aws_only", description="aws_only | google_enabled | dual_provider")
    per_purpose_overrides: dict[str, str] = Field(default_factory=dict)

    @field_validator("mode")
    @classmethod
    def _validate_mode(cls, value: str) -> str:
        normalized = (value or "").strip().lower()
        if normalized not in {"aws_only", "google_enabled", "dual_provider"}:
            raise ValueError("mode must be aws_only | google_enabled | dual_provider")
        return normalized

    @field_validator("per_purpose_overrides")
    @classmethod
    def _validate_overrides(cls, value: dict[str, str]) -> dict[str, str]:
        out: dict[str, str] = {}
        for purpose_id, provider in (value or {}).items():
            purpose_key = str(purpose_id).strip().lower()
            provider_key = str(provider).strip().lower()
            if not purpose_key or not provider_key:
                raise ValueError("per_purpose_overrides keys and values must be non-empty")
            if provider_key not in SUPPORTED_PROVIDERS:
                raise ValueError(
                    f"unsupported embedding provider {provider_key!r}; allowed: {sorted(SUPPORTED_PROVIDERS)}"
                )
            out[purpose_key] = provider_key
        return out


def _get_embedding_policy_store() -> AdminEmbeddingPolicyStore:
    return get_admin_embedding_policy_store()


def _policy_to_response(policy: TenantEmbeddingPolicy) -> EmbeddingPolicyResponse:
    return EmbeddingPolicyResponse(
        tenant_id=policy.tenant_id,
        mode=policy.mode,
        per_purpose_overrides=dict(policy.per_purpose_overrides),
    )


def _emit_embedding_policy_decision(
    *,
    actor: str,
    target_tenant: str,
    decision_type: str,
    outcome: str,
    summary: str,
    context: dict[str, Any],
) -> None:
    """Emit a Decision Trace record for an embedding policy operation.

    Failure to emit must not break the API call (audit retry happens out of
    band), so we swallow exceptions and log them.  Mirrors the pattern used by
    ``apps/backend/services/inference/admin_resolver.py``.
    """
    try:
        from apps.backend.services.context.decision_event_capture import capture_decision  # noqa: PLC0415

        capture_decision(
            tenant_id=target_tenant or PLATFORM_TENANT_TOKEN,
            skill_id="inference.admin_embedding_policy",
            decision_summary=summary,
            decision_type=decision_type,
            outcome=outcome,
            capture_surface="admin_embedding_policy",
            service_family="inference",
            context_data={"actor": actor, **context},
        )
    except Exception:  # noqa: BLE001 — never fail the API on trace failure
        logger.warning(
            "embedding_policy_decision_trace_failed actor=%s target=%s type=%s",
            actor,
            target_tenant,
            decision_type,
            exc_info=True,
        )


@router.get("/policy", response_model=EmbeddingPolicyListResponse)
async def list_embedding_policies(
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.EMBEDDING_READ)),
    store: AdminEmbeddingPolicyStore = Depends(_get_embedding_policy_store),
) -> dict[str, Any]:
    """List all embedding policies (platform default + per-tenant overrides)."""
    policies = store.list_policies()
    if not any(p.tenant_id == PLATFORM_TENANT_TOKEN for p in policies):
        policies = [TenantEmbeddingPolicy(tenant_id=PLATFORM_TENANT_TOKEN), *policies]
    return {
        "policies": [_policy_to_response(p) for p in policies],
        "supported_providers": sorted(SUPPORTED_PROVIDERS),
    }


@router.get("/policy/{tenant_id}", response_model=EmbeddingPolicyResponse)
async def get_embedding_policy(
    tenant_id: str,
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.EMBEDDING_READ)),
    store: AdminEmbeddingPolicyStore = Depends(_get_embedding_policy_store),
) -> dict[str, Any]:
    """Show one tenant's effective policy (with platform-default fallback)."""
    target = (tenant_id or "").strip() or PLATFORM_TENANT_TOKEN
    policy = store.get_policy(None if target == PLATFORM_TENANT_TOKEN else target)
    return _policy_to_response(policy).model_dump()


@router.put("/policy/{tenant_id}", response_model=EmbeddingPolicyResponse)
async def set_embedding_policy(
    tenant_id: str,
    body: SetEmbeddingPolicyRequest,
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.EMBEDDING_WRITE)),
    store: AdminEmbeddingPolicyStore = Depends(_get_embedding_policy_store),
) -> dict[str, Any]:
    """Upsert an embedding policy for ``tenant_id`` (or '__platform__')."""
    target = (tenant_id or "").strip() or PLATFORM_TENANT_TOKEN
    previous = store.get_policy(None if target == PLATFORM_TENANT_TOKEN else target)
    new_policy = TenantEmbeddingPolicy(
        tenant_id=target,
        mode=body.mode,  # type: ignore[arg-type]
        per_purpose_overrides=body.per_purpose_overrides,
    )
    persisted = store.set_policy(new_policy)
    actor_id = getattr(_perm, "actor_id", None) or "founder"
    _emit_embedding_policy_decision(
        actor=str(actor_id),
        target_tenant=target,
        decision_type="embedding_policy_changed",
        outcome="allowed",
        summary=(
            f"embedding_policy_changed tenant={target} from_mode={previous.mode} "
            f"to_mode={persisted.mode} overrides_changed="
            f"{sorted(persisted.per_purpose_overrides.items())}"
        ),
        context={
            "from_mode": previous.mode,
            "to_mode": persisted.mode,
            "from_overrides": previous.per_purpose_overrides,
            "to_overrides": persisted.per_purpose_overrides,
            "migration_strategy": "shadow_write_dual_index_then_alias_swap",
        },
    )
    return _policy_to_response(persisted).model_dump()


@router.delete("/policy/{tenant_id}", response_model=EmbeddingPolicyResponse)
async def delete_embedding_policy(
    tenant_id: str,
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.EMBEDDING_WRITE)),
    store: AdminEmbeddingPolicyStore = Depends(_get_embedding_policy_store),
) -> dict[str, Any]:
    """Drop a per-tenant override; the tenant reverts to the platform default."""
    target = (tenant_id or "").strip()
    if not target or target == PLATFORM_TENANT_TOKEN:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot delete the platform-default embedding policy; PUT a new one instead.",
        )
    previous = store.get_policy(target)
    try:
        store.delete_policy(target)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    after = store.get_policy(target)
    actor_id = getattr(_perm, "actor_id", None) or "founder"
    _emit_embedding_policy_decision(
        actor=str(actor_id),
        target_tenant=target,
        decision_type="embedding_policy_changed",
        outcome="allowed",
        summary=f"embedding_policy_reverted_to_platform_default tenant={target}",
        context={
            "from_mode": previous.mode,
            "to_mode": after.mode,
            "from_overrides": previous.per_purpose_overrides,
            "to_overrides": after.per_purpose_overrides,
            "migration_strategy": "revert_to_platform_default",
        },
    )
    return _policy_to_response(after).model_dump()
