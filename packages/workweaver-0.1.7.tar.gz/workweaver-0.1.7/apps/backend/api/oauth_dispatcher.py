"""Unified OAuth callback dispatcher.

Single canonical callback URL for ALL OAuth flows. The provider's
authorization server redirects to ``https://api.workweaver.ai/oauth/callback``
regardless of which flow initiated the OAuth. The dispatcher decodes the
``state`` parameter (JWT-signed) to determine which internal handler to
invoke, then forwards the request to the appropriate existing handler.

WHY: OAuth 2.0 requires every redirect_uri to be exactly whitelisted in
the provider's developer console. Having multiple callback URL patterns
(login, integration, zoho-specific) forced every new provider to figure
out which URL pattern to use AND register each separately.

This dispatcher fixes that structurally:

  - One canonical URL: https://api.workweaver.ai/oauth/callback
  - Each provider's console only needs to whitelist this single URL ONCE,
    forever.
  - Adding a new provider = update code only, no console changes.
  - Refactoring internal routes = invisible to providers.

ROUTING RULES:

  Login OAuth (identity/session):
    - state.flow == "login_google"    -> auth_signup_google.google_oauth_callback
    - state.flow == "login_microsoft" -> auth_signup_enterprise.microsoft_oauth_callback
    - state.flow == "login_oidc"      -> auth_signup_enterprise.oidc_oauth_callback
    - state.flow == "login_zoho"      -> auth_signup_enterprise.zoho_oauth_callback
    - state.flow unset (legacy v2 token) -> fall back to provider-based routing

  Connector OAuth (BYOC — Bring Your Own Credentials):
    - state.flow == "integration_legacy" -> IntegrationManager.complete_oauth_flow
    - state.flow == "integration_zoho"   -> connectors.complete_zoho_connector_auth

SECURITY:

  - The state token is JWT-signed with JWT_SECRET. Tampering invalidates
    the signature and the dispatcher rejects the request.
  - The flow value is validated against VALID_FLOWS in oauth_redirect_state.py
    so unknown values fall through to safe error handling.
  - The dispatcher does NOT exchange the OAuth code itself — it forwards
    to the existing provider-specific handlers which already have the
    audited logic for code exchange, token storage, and session creation.
"""

from __future__ import annotations

import json
import logging
from html import escape

from fastapi import APIRouter, Request, Response
from fastapi.responses import HTMLResponse, RedirectResponse

from apps.backend.services.oauth_redirect_state import (
    OAuthRedirectError,
    parse_oauth_state,
)

logger = logging.getLogger(__name__)


# Origins that the popup-callback HTML response is allowed to postMessage
# to. The opener (the dashboard) lives on one of these origins; everything
# else is rejected by the parent listener and is silently dropped.
_POPUP_TARGET_ORIGINS = (
    "https://workweaver.ai",
    "https://www.workweaver.ai",
    "https://admin.workweaver.ai",
    "https://infra.workweaver.ai",
    "https://www.infra.workweaver.ai",
    "http://localhost:3000",
    "http://localhost:3001",
)


def _render_popup_callback_response(
    *,
    success: bool,
    state_token: str,
    integration_key: str | None,
    connection_id: str | None,
    return_to_origin: str | None,
    error: str | None = None,
    error_description: str | None = None,
) -> HTMLResponse:
    """Render an HTML response that postMessages the result to window.opener
    and auto-closes the popup.

    Used by the unified dispatcher for popup-based OAuth flows
    (integration_legacy and integration_zoho). The dispatcher renders this
    on api.workweaver.ai/oauth/callback after server-side completing the
    OAuth code exchange. The opener (the dashboard at workweaver.ai) has
    a postMessage listener at integrations.html that recognises
    `already_completed: true` and skips the second-leg API call that the
    legacy /integrations/oauth-callback.html static page used to do.

    Cross-origin postMessage works because the script enumerates ALL the
    Workweaver target origins and posts to each. The browser silently
    drops the messages that don't match the actual opener origin.
    """
    payload: dict[str, object] = {
        "type": "workweaver-oauth-callback",
        # `already_completed` is the new flag — when true, the parent
        # listener should skip its own /api/v1/integrations/oauth/callback
        # call because the dispatcher has already done the exchange.
        "already_completed": True,
        "success": success,
        "state": state_token,
        "key": integration_key,
        "connection_id": connection_id,
    }
    if error:
        payload["error"] = error
    if error_description:
        payload["error_description"] = error_description

    payload_json = json.dumps(payload)
    target_origins_json = json.dumps(list(_POPUP_TARGET_ORIGINS))
    return_url = None
    if return_to_origin:
        return_url = f"{return_to_origin.rstrip('/')}/settings?tab=integrations"
    return_url_json = json.dumps(return_url)
    action_href = escape(return_url or "#", quote=True)

    title = "Workweaver — Connection complete" if success else "Workweaver — Connection failed"
    body_text = (
        "Connection complete. Returning to Connected tools…"
        if success
        else "Couldn't finish the connection. Returning to Connected tools…"
    )
    helper_text = (
        "If this tab stays open, we'll send you back automatically."
        if success
        else "If this tab stays open, return to Connected tools and try again."
    )
    action_label = "Return to Connected tools"
    spinner_color = "#22c55e" if success else "#ef4444"

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>{escape(title)}</title>
<style>
  body {{
    margin: 0;
    padding: 60px 24px;
    font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
    background: #0b0b0c;
    color: #e5e7eb;
    text-align: center;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
  }}
  .spinner {{
    width: 36px;
    height: 36px;
    border: 3px solid rgba(255,255,255,0.18);
    border-top-color: {spinner_color};
    border-radius: 50%;
    animation: spin 1s linear infinite;
    margin-bottom: 24px;
  }}
  @keyframes spin {{
    to {{ transform: rotate(360deg); }}
  }}
  p {{
    font-size: 14px;
    margin: 0;
    opacity: 0.85;
  }}
  .helper {{
    margin-top: 12px;
    max-width: 360px;
    line-height: 1.5;
  }}
  .action {{
    margin-top: 24px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 40px;
    padding: 0 18px;
    border-radius: 999px;
    background: #f8fafc;
    color: #111827;
    font-size: 14px;
    font-weight: 600;
    text-decoration: none;
  }}
</style>
</head>
<body>
  <div class="spinner" role="status" aria-label="Finishing"></div>
  <p>{escape(body_text)}</p>
  <p class="helper">{escape(helper_text)}</p>
  <a class="action" href="{action_href}">{escape(action_label)}</a>
  <script>
    (function() {{
      var payload = {payload_json};
      var targetOrigins = {target_origins_json};
      var returnUrl = {return_url_json};
      var hasOpener = false;
      try {{
        hasOpener = !!(window.opener && !window.opener.closed);
      }} catch (_) {{
        hasOpener = false;
      }}
      try {{
        if (hasOpener) {{
          for (var i = 0; i < targetOrigins.length; i++) {{
            try {{
              window.opener.postMessage(payload, targetOrigins[i]);
            }} catch (_) {{ /* ignore individual targetOrigin errors */ }}
          }}
        }}
      }} catch (err) {{
        console.error('[oauth-dispatcher] postMessage failed', err);
      }}
      setTimeout(function() {{
        if (hasOpener) {{
          try {{ window.close(); }} catch (_) {{}}
        }}
      }}, 300);
      if (returnUrl) {{
        setTimeout(function() {{
          window.location.replace(returnUrl);
        }}, hasOpener ? 1200 : 900);
      }}
    }})();
  </script>
</body>
</html>
"""
    return HTMLResponse(content=html, status_code=200)


# No prefix — this router mounts at the root so the URL is exactly
# https://api.workweaver.ai/oauth/callback (not /api/v1/oauth/callback).
router = APIRouter(tags=["oauth-dispatcher"])


@router.get("/oauth/callback")
async def unified_oauth_callback(
    request: Request,
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    error_description: str | None = None,
):
    """Single canonical OAuth callback for ALL providers + flows.

    Decodes the ``state`` parameter to determine the flow type, then
    forwards to the existing per-flow handler. Backwards compatible with
    legacy state tokens that pre-date the ``flow`` field — falls back to
    provider-based routing in that case.
    """
    # Errors from the provider (e.g. user cancelled) are forwarded to
    # the legacy login handler which knows how to render the redirect
    # back to the dashboard with the right error UX. We pick the
    # google handler as the default error sink because it has the most
    # complete error handling — it logs the error, looks up return_to
    # from state if state is parseable, and renders the right redirect.
    if error and not state:
        from apps.backend.api.auth_signup_google import google_oauth_callback

        return await google_oauth_callback(
            request=request,
            http_response=Response(),
            code=code,
            state=state,
            error=error,
            error_description=error_description,
        )

    if not state:
        logger.warning("oauth_dispatcher: missing state parameter")
        return RedirectResponse(
            url="https://workweaver.ai/login/?error=missing_state",
            status_code=302,
        )

    # Zara calendar identity OAuth uses a simple colon-delimited state
    # (``zara_calendar:<tenant>:<ulid>``) rather than the JWT envelope
    # other flows use. Detect and route before attempting JWT parse so
    # ``parse_oauth_state`` doesn't raise on the shorter shape.
    if state.startswith("zara_calendar:"):
        return await _handle_zara_calendar_complete(
            state_token=state,
            code=code,
            error=error,
            error_description=error_description,
        )

    try:
        parsed = parse_oauth_state(token=state)
    except OAuthRedirectError as exc:
        logger.warning("oauth_dispatcher: invalid state token: %s", exc)
        return RedirectResponse(
            url=f"https://workweaver.ai/login/?error=invalid_state&detail={exc}",
            status_code=302,
        )

    # Resolve the flow. If the state token has an explicit flow field,
    # use it. Otherwise fall back to provider-based routing for backwards
    # compatibility with v1/v2 tokens minted before the flow field existed.
    flow = parsed.flow or _legacy_flow_for_provider(parsed.provider)

    logger.info(
        "oauth_dispatcher: routing flow=%s provider=%s return_to=%s",
        flow,
        parsed.provider,
        parsed.return_to_origin,
    )

    if flow == "login_google":
        from apps.backend.api.auth_signup_google import google_oauth_callback

        return await google_oauth_callback(
            request=request,
            http_response=Response(),
            code=code,
            state=state,
            error=error,
            error_description=error_description,
        )

    if flow == "login_microsoft":
        from apps.backend.api.auth_signup_enterprise import (
            microsoft_oauth_callback,
        )

        return await microsoft_oauth_callback(
            request=request,
            http_response=Response(),
            code=code,
            state=state,
            error=error,
            error_description=error_description,
        )

    if flow == "login_oidc":
        from apps.backend.api.auth_signup_enterprise import oidc_oauth_callback

        return await oidc_oauth_callback(
            request=request,
            http_response=Response(),
            code=code,
            state=state,
            error=error,
            error_description=error_description,
        )

    if flow == "login_zoho":
        from apps.backend.api.auth_signup_enterprise import zoho_oauth_callback

        return await zoho_oauth_callback(
            request=request,
            http_response=Response(),
            code=code,
            state=state,
            error=error,
            error_description=error_description,
        )

    # Phase 2 — integration flows. The dispatcher completes the OAuth
    # exchange server-side and returns an HTML response with embedded
    # postMessage script that notifies the dashboard popup opener.
    if flow == "integration_legacy":
        return await _handle_integration_legacy(
            parsed=parsed,
            state_token=state,
            code=code,
            error=error,
            error_description=error_description,
        )

    if flow == "integration_zoho":
        return await _handle_integration_zoho(
            parsed=parsed,
            state_token=state,
            code=code,
            error=error,
            error_description=error_description,
            request=request,
        )

    logger.warning("oauth_dispatcher: unrecognised flow=%s", flow)
    return RedirectResponse(
        url=f"https://workweaver.ai/login/?error=unknown_flow&detail={flow}",
        status_code=302,
    )


async def _handle_integration_legacy(
    *,
    parsed,
    state_token: str,
    code: str | None,
    error: str | None,
    error_description: str | None,
) -> HTMLResponse:
    """Complete a generic integration OAuth flow (the popup-based path).

    Decodes the JWT envelope's tenant_id/connection_id/csrf_state, calls
    IntegrationManager.complete_oauth_flow internally, then renders the
    HTML postMessage response. The opener (the dashboard) gets
    `already_completed: true` and refreshes the connectors page.
    """
    integration_key = parsed.connection_key
    connection_id = parsed.connection_id
    tenant_id = parsed.tenant_id
    csrf_state = parsed.csrf_state

    if not (tenant_id and connection_id and csrf_state):
        logger.warning(
            "oauth_dispatcher: integration_legacy missing required fields: tenant=%s connection=%s csrf=%s",
            bool(tenant_id),
            bool(connection_id),
            bool(csrf_state),
        )
        return _render_popup_callback_response(
            success=False,
            state_token=state_token,
            integration_key=integration_key,
            connection_id=connection_id,
            return_to_origin=parsed.return_to_origin,
            error="invalid_state",
            error_description="State token is missing required fields",
        )

    if error:
        logger.info("oauth_dispatcher: integration_legacy provider error: %s", error)
        return _render_popup_callback_response(
            success=False,
            state_token=state_token,
            integration_key=integration_key,
            connection_id=connection_id,
            return_to_origin=parsed.return_to_origin,
            error=error,
            error_description=error_description,
        )

    if not code:
        return _render_popup_callback_response(
            success=False,
            state_token=state_token,
            integration_key=integration_key,
            connection_id=connection_id,
            return_to_origin=parsed.return_to_origin,
            error="missing_code",
            error_description="Provider redirect did not include an authorization code",
        )

    try:
        from apps.backend.services.integration_manager import IntegrationManager

        manager = IntegrationManager()
        await manager.complete_oauth_flow(
            tenant_id=tenant_id,
            connection_id=connection_id,
            code=code,
            # complete_oauth_flow validates `state` against the stored
            # connection record. We stored `csrf_state` (the inner ULID
            # or other token) in the connection record at initiate time,
            # so we forward it here.
            state=csrf_state,
        )
    except Exception as exc:  # noqa: BLE001 — surface any error to the popup
        logger.exception(
            "oauth_dispatcher: integration_legacy completion failed for connection_id=%s",
            connection_id,
        )
        return _render_popup_callback_response(
            success=False,
            state_token=state_token,
            integration_key=integration_key,
            connection_id=connection_id,
            return_to_origin=parsed.return_to_origin,
            error="completion_failed",
            error_description=str(exc),
        )

    return _render_popup_callback_response(
        success=True,
        state_token=state_token,
        integration_key=integration_key,
        connection_id=connection_id,
        return_to_origin=parsed.return_to_origin,
    )


async def _handle_integration_zoho(
    *,
    parsed,
    state_token: str,
    code: str | None,
    error: str | None,
    error_description: str | None,
    request: Request,
) -> HTMLResponse:
    """Complete a Zoho integration OAuth flow.

    Zoho has its own backend flow at /api/v1/connectors/zoho/oauth/callback
    today. The dispatcher decodes the JWT, then forwards to the existing
    handler internally, then renders the popup-callback HTML response.
    """
    integration_key = parsed.connection_key or "zoho"
    connection_id = parsed.connection_id
    tenant_id = parsed.tenant_id

    if not (tenant_id and connection_id):
        return _render_popup_callback_response(
            success=False,
            state_token=state_token,
            integration_key=integration_key,
            connection_id=connection_id,
            return_to_origin=parsed.return_to_origin,
            error="invalid_state",
            error_description="State token is missing required fields",
        )

    if error:
        return _render_popup_callback_response(
            success=False,
            state_token=state_token,
            integration_key=integration_key,
            connection_id=connection_id,
            return_to_origin=parsed.return_to_origin,
            error=error,
            error_description=error_description,
        )

    if not code:
        return _render_popup_callback_response(
            success=False,
            state_token=state_token,
            integration_key=integration_key,
            connection_id=connection_id,
            return_to_origin=parsed.return_to_origin,
            error="missing_code",
        )

    # Forward to the existing Zoho completion path. Pull accounts-server
    # and location from the request query string since they are part of
    # Zoho's standard callback contract.
    accounts_server = request.query_params.get("accounts-server")
    location = request.query_params.get("location")

    try:
        from apps.backend.api.connectors import _complete_zoho_connector_auth

        await _complete_zoho_connector_auth(
            tenant_id=tenant_id,
            connection_id=connection_id,
            code=code,
            state=parsed.csrf_state or "",
            accounts_server=accounts_server,
            location=location,
        )
    except Exception as exc:  # noqa: BLE001
        logger.exception(
            "oauth_dispatcher: integration_zoho completion failed for connection_id=%s",
            connection_id,
        )
        return _render_popup_callback_response(
            success=False,
            state_token=state_token,
            integration_key=integration_key,
            connection_id=connection_id,
            return_to_origin=parsed.return_to_origin,
            error="completion_failed",
            error_description=str(exc),
        )

    return _render_popup_callback_response(
        success=True,
        state_token=state_token,
        integration_key=integration_key,
        connection_id=connection_id,
        return_to_origin=parsed.return_to_origin,
    )


def _legacy_flow_for_provider(provider: str) -> str:
    """Map a legacy state token's provider to a flow value.

    Used when a state token was minted before the ``flow`` field existed.
    Login flows are the only flows that minted unified JWT state pre-Phase-1,
    so we always assume login_<provider>.
    """
    return f"login_{provider}"


async def _handle_zara_calendar_complete(
    *,
    state_token: str,
    code: str | None,
    error: str | None,
    error_description: str | None,
) -> Response:
    """Complete a Zara calendar OAuth flow.

    State shape: ``zara_calendar:<tenant_id>:<ulid>``. The dispatcher
    forwards to
    :meth:`ZaraIdentityWriteService.complete_calendar_connect` which
    exchanges the code, persists the refresh token, and flips the
    lifecycle row from ``connecting`` to ``connected``.
    """
    if error:
        logger.warning(
            "oauth_dispatcher: zara_calendar provider error=%s description=%s",
            error,
            error_description,
        )
        return RedirectResponse(
            url=(
                "https://workweaver.ai/admin/identity?error=calendar_oauth_failed"
                f"&detail={error}"
            ),
            status_code=302,
        )
    if not code:
        return RedirectResponse(
            url="https://workweaver.ai/admin/identity?error=missing_code",
            status_code=302,
        )

    try:
        from apps.backend.services.zara.identity_write_service import (
            InvalidOAuthStateError,
            get_zara_identity_write_service,
        )

        service = get_zara_identity_write_service()
        await service.complete_calendar_connect(state=state_token, code=code)
    except InvalidOAuthStateError as exc:
        logger.warning("oauth_dispatcher: zara_calendar invalid state: %s", exc)
        return RedirectResponse(
            url="https://workweaver.ai/admin/identity?error=invalid_state",
            status_code=302,
        )
    except Exception as exc:  # noqa: BLE001
        logger.exception("oauth_dispatcher: zara_calendar completion failed")
        return RedirectResponse(
            url=f"https://workweaver.ai/admin/identity?error=callback_failed&detail={exc}",
            status_code=302,
        )

    return RedirectResponse(
        url="https://workweaver.ai/admin/identity?calendar_connected=1",
        status_code=302,
    )
