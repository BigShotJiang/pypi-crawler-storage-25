"""Supervisor API (PKG-11) — Quality monitoring, conflict detection, intervention.

Endpoints:
    GET    /api/v1/supervisor/status                    — aggregated supervisor status
    POST   /api/v1/supervisor/check                     — run all supervisor checks
    GET    /api/v1/supervisor/quality/{agent_id}        — quality check for specific agent
    GET    /api/v1/supervisor/quality                    — quality check for all agents
    GET    /api/v1/supervisor/conflicts                  — detect goal conflicts
    GET    /api/v1/supervisor/contention                 — detect resource contention
    GET    /api/v1/supervisor/deadlines                  — check approaching deadlines
    POST   /api/v1/supervisor/intervene/{session_id}    — pause executor session
    POST   /api/v1/supervisor/periodic-review            — run autonomous periodic review (SUP-8)
    POST   /api/v1/supervisor/proposals                  — submit learning proposal
    GET    /api/v1/supervisor/proposals                  — list pending proposals
    POST   /api/v1/supervisor/proposals/{id}/approve    — approve learning proposal
    POST   /api/v1/supervisor/proposals/{id}/reject     — reject learning proposal
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/supervisor", tags=["supervisor"])


# ---------------------------------------------------------------------------
# Request/Response Models
# ---------------------------------------------------------------------------


class InterventionRequest(BaseModel):
    """Request to intervene in an executor session."""

    reason: str = Field(
        default="supervisor_intervention",
        max_length=500,
        description="Reason for intervention",
    )
    initiated_by: str = Field(
        default="supervisor",
        max_length=100,
        description="Who initiated the intervention",
    )


class LearningProposalRequest(BaseModel):
    """Request to submit a learning proposal for supervisor review."""

    proposal_id: str = Field(..., min_length=1, max_length=200, description="Unique proposal ID")
    agent_id: str = Field(..., min_length=1, max_length=100, description="Agent submitting the proposal")
    skill_id: str = Field(..., min_length=1, max_length=200, description="Skill being modified")
    rationale: str = Field(..., min_length=1, max_length=2000, description="Rationale for the change")
    proposed_change: dict[str, Any] = Field(
        default_factory=dict,
        description="Proposed changes to the skill",
    )
    metadata: dict[str, Any] | None = Field(
        default=None,
        description="Additional metadata",
    )


class ProposalActionRequest(BaseModel):
    """Request for approve/reject actions on a proposal."""

    acted_by: str = Field(
        default="supervisor",
        max_length=100,
        description="Who is approving/rejecting",
    )
    reason: str = Field(
        default="",
        max_length=2000,
        description="Reason for the decision (used on reject)",
    )


# ---------------------------------------------------------------------------
# Dependency
# ---------------------------------------------------------------------------


def _get_supervisor_service():  # type: ignore[return]
    from apps.backend.services.runtime.supervisor_service import get_supervisor_service

    return get_supervisor_service()


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("/status")
def get_supervisor_status(
    tenant_id: str = Depends(get_verified_tenant_id),
    svc: Any = Depends(_get_supervisor_service),
) -> dict[str, Any]:
    """Get aggregated supervisor status including alerts, conflicts, and proposals."""
    return svc.get_supervisor_status(tenant_id)


@router.post("/check")
def run_full_check(
    tenant_id: str = Depends(get_verified_tenant_id),
    svc: Any = Depends(_get_supervisor_service),
) -> dict[str, Any]:
    """Run all supervisor checks: quality, conflicts, contention, deadlines."""
    return svc.run_full_check(tenant_id)


@router.get("/quality/{agent_id}")
def check_agent_quality(
    agent_id: str,
    threshold: float | None = Query(None, ge=0.0, le=1.0, description="Quality threshold"),
    window_size: int | None = Query(None, ge=1, le=1000, description="Sliding window size"),
    tenant_id: str = Depends(get_verified_tenant_id),
    svc: Any = Depends(_get_supervisor_service),
) -> dict[str, Any]:
    """Check quality for a specific agent via sliding window over evidence."""
    return svc.check_agent_quality(
        tenant_id,
        agent_id,
        threshold=threshold,
        window_size=window_size,
    )


@router.get("/quality")
def check_all_agents_quality(
    tenant_id: str = Depends(get_verified_tenant_id),
    svc: Any = Depends(_get_supervisor_service),
) -> dict[str, Any]:
    """Check quality across all observed agents for the tenant."""
    results = svc.check_all_agents_quality(tenant_id)
    return {"agents": results, "count": len(results)}


@router.get("/conflicts")
def detect_goal_conflicts(
    tenant_id: str = Depends(get_verified_tenant_id),
    svc: Any = Depends(_get_supervisor_service),
) -> dict[str, Any]:
    """Detect resource/time conflicts between active goals."""
    conflicts = svc.detect_goal_conflicts(tenant_id)
    return {"conflicts": conflicts, "count": len(conflicts)}


@router.get("/contention")
def detect_resource_contention(
    time_window_minutes: int = Query(5, ge=1, le=60, description="Time window in minutes"),
    tenant_id: str = Depends(get_verified_tenant_id),
    svc: Any = Depends(_get_supervisor_service),
) -> dict[str, Any]:
    """Detect concurrent resource operations by different agents."""
    contentions = svc.detect_resource_contention(tenant_id, time_window_minutes=time_window_minutes)
    return {"contentions": contentions, "count": len(contentions)}


@router.get("/deadlines")
def check_deadlines(
    alert_hours: float = Query(48.0, ge=1.0, le=720.0, description="Hours before deadline to alert"),
    tenant_id: str = Depends(get_verified_tenant_id),
    svc: Any = Depends(_get_supervisor_service),
) -> dict[str, Any]:
    """Check for goals approaching deadline with no progress."""
    alerts = svc.check_goal_deadlines(tenant_id, alert_hours=alert_hours)
    return {"deadline_alerts": alerts, "count": len(alerts)}


@router.post("/intervene/{session_id}")
def intervene_session(
    session_id: str,
    body: InterventionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    svc: Any = Depends(_get_supervisor_service),
) -> dict[str, Any]:
    """Set pause flag on an executor session.

    Immediately pauses the session via interrupt state store. The agent's
    execution loop should check interrupt state and halt gracefully.
    """
    result = svc.intervene(
        tenant_id,
        session_id,
        reason=body.reason,
        initiated_by=body.initiated_by,
    )
    if not result.get("success"):
        raise HTTPException(
            status_code=503,
            detail=result.get("error", "Intervention failed"),
        )
    return result


@router.post("/periodic-review")
async def run_periodic_review(
    tenant_id: str = Depends(get_verified_tenant_id),
    svc: Any = Depends(_get_supervisor_service),
) -> dict[str, Any]:
    """Run a complete periodic supervisor review autonomously.

    SUP-8: Designed to be called by EventBridge (hourly) via Lambda, or by
    Mission Control manually. Runs quality checks, conflict detection,
    contention detection, deadline watch, and pending proposal review.

    Emits supervisor.periodic_review.completed via EventBus for SSE push.
    """
    return await svc.run_periodic_review(tenant_id)


@router.post("/proposals")
def submit_learning_proposal(
    body: LearningProposalRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    svc: Any = Depends(_get_supervisor_service),
) -> dict[str, Any]:
    """Submit a learning proposal for supervisor review."""
    return svc.submit_learning_proposal(
        tenant_id,
        proposal_id=body.proposal_id,
        agent_id=body.agent_id,
        skill_id=body.skill_id,
        rationale=body.rationale,
        proposed_change=body.proposed_change,
        metadata=body.metadata,
    )


@router.get("/proposals")
def list_pending_proposals(
    tenant_id: str = Depends(get_verified_tenant_id),
    svc: Any = Depends(_get_supervisor_service),
) -> dict[str, Any]:
    """List learning proposals pending supervisor review."""
    proposals = svc.list_pending_proposals(tenant_id)
    return {"proposals": proposals, "count": len(proposals)}


@router.post("/proposals/{proposal_id}/approve")
def approve_proposal(
    proposal_id: str,
    body: ProposalActionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    svc: Any = Depends(_get_supervisor_service),
) -> dict[str, Any]:
    """Approve a pending learning proposal."""
    result = svc.approve_learning_proposal(
        tenant_id,
        proposal_id,
        approved_by=body.acted_by,
    )
    if result is None:
        raise HTTPException(status_code=404, detail="Proposal not found or not pending")
    return result


@router.post("/proposals/{proposal_id}/reject")
def reject_proposal(
    proposal_id: str,
    body: ProposalActionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    svc: Any = Depends(_get_supervisor_service),
) -> dict[str, Any]:
    """Reject a pending learning proposal."""
    result = svc.reject_learning_proposal(
        tenant_id,
        proposal_id,
        rejected_by=body.acted_by,
        reason=body.reason,
    )
    if result is None:
        raise HTTPException(status_code=404, detail="Proposal not found or not pending")
    return result
