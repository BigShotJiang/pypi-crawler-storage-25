"""Outreach opt-in API for the Workweaver compliance surface (#3188).

Endpoints
---------

- ``POST /api/v1/compliance/outreach-opt-in`` — set opt-in for a channel
- ``GET  /api/v1/compliance/outreach-opt-in`` — list opt-in states

RBAC
----

Per #3188 the write surface is admin-scoped; reads are open to any
authenticated member of the tenant.

Decision-trace shape
--------------------

The underlying :mod:`apps.backend.services.compliance.outreach_opt_in` store
emits a structured ``outreach_opt_in_event`` log row on every write.
"""
from __future__ import annotations

import logging
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_id,
    require_admin_user_role,
)
from apps.backend.providers.portable_store import InMemoryStore
from apps.backend.services.compliance.outreach_opt_in import OutreachOptInStore

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/compliance", tags=["compliance"])


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class OutreachOptInRequest(BaseModel):
    """Body for ``POST /api/v1/compliance/outreach-opt-in``."""

    channel: str = Field(..., description="Channel to opt in (whatsapp|sms|email|voice|slack_dm|teams_dm)")
    confirm: bool = Field(..., description="Explicit confirmation of opt-in")


class OutreachOptInResponse(BaseModel):
    """API-facing opt-in record shape."""

    id: str
    tenant_id: str
    channel: str
    opted_in: bool
    consent_attested_at: float
    attested_by: str


class OutreachOptInListResponse(BaseModel):
    """List of opt-in records."""

    opt_ins: list[OutreachOptInResponse]


# ---------------------------------------------------------------------------
# Valid channels
# ---------------------------------------------------------------------------

_VALID_CHANNELS = {"whatsapp", "sms", "email", "voice", "slack_dm", "teams_dm"}


# ---------------------------------------------------------------------------
# DI helpers
# ---------------------------------------------------------------------------

_default_store: OutreachOptInStore | None = None


def _get_store() -> OutreachOptInStore:
    global _default_store
    if _default_store is None:
        _default_store = OutreachOptInStore(store=InMemoryStore())
    return _default_store


def set_default_store(store: OutreachOptInStore | None) -> None:
    """Replace the singleton store (for testing)."""
    global _default_store
    _default_store = store


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/outreach-opt-in",
    response_model=OutreachOptInResponse,
    status_code=status.HTTP_201_CREATED,
)
async def set_outreach_opt_in(
    body: OutreachOptInRequest,
    request: Request,  # noqa: ARG001
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
    _admin: Annotated[object, Depends(require_admin_user_role)] = None,
    store: OutreachOptInStore = Depends(_get_store),
) -> OutreachOptInResponse:
    """Set opt-in for a channel. Admin-only. Requires explicit confirmation."""
    channel = body.channel.lower().strip()
    if channel not in _VALID_CHANNELS:
        raise HTTPException(
            status_code=422,
            detail={
                "error": "invalid_channel",
                "message": f"channel must be one of {', '.join(sorted(_VALID_CHANNELS))}",
            },
        )
    if not body.confirm:
        raise HTTPException(
            status_code=422,
            detail={
                "error": "confirmation_required",
                "message": "confirm must be true to opt in",
            },
        )
    record = store.set_opt_in(
        tenant_id=tenant_id,
        channel=channel,
        opted_in=True,
        attested_by=actor_id,
    )
    return OutreachOptInResponse(**record)


@router.get(
    "/outreach-opt-in",
    response_model=OutreachOptInListResponse,
)
async def list_outreach_opt_ins(
    tenant_id: str = Depends(get_verified_tenant_id),
    store: OutreachOptInStore = Depends(_get_store),
) -> OutreachOptInListResponse:
    """List opt-in states for the tenant. Any authenticated member."""
    records = store.list_opt_ins(tenant_id=tenant_id)
    return OutreachOptInListResponse(
        opt_ins=[OutreachOptInResponse(**r) for r in records],
    )


__all__ = [
    "OutreachOptInRequest",
    "OutreachOptInListResponse",
    "OutreachOptInResponse",
    "router",
    "set_default_store",
]
