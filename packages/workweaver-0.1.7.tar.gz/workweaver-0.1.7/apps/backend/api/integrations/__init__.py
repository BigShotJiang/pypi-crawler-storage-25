"""Integrations API package.

This package contains API endpoints for managing third-party integrations:
- catalog: available integrations + capability summaries
- oauth: OAuth connect/disconnect endpoints
"""

from fastapi import APIRouter

from apps.backend.api.integrations.catalog import router as catalog_router
from apps.backend.api.integrations.oauth import router as oauth_router

router = APIRouter()
router.include_router(catalog_router)
router.include_router(oauth_router)

__all__ = ["router"]
