"""Integrations API endpoints.

This module provides API endpoints for querying available third-party
integrations and their configuration requirements.

Legacy requirement reference: P1.4.3 — Integrations (Available)
"""

import logging
import urllib.parse

from fastapi import APIRouter, Depends, HTTPException, Request, status

from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.integrations.integration_catalog import IntegrationCategory, AuthType, get_integrations_registry

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/integrations", tags=["integrations"])


@router.get("", response_model=dict[str, list[dict]])
async def list_all_integrations(
    request: Request,
    category: str | None = None,
    auth_type: str | None = None,
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
):
    """List all available integrations.

    Args:
        request: FastAPI Request object
        category: Optional category filter (crm, calendar, messaging, etc.)
        auth_type: Optional auth type filter (oauth2, api_key, etc.)

    Returns:
        Dictionary with list of available integrations

    Example:
        GET /api/v1/integrations?category=crm
        GET /api/v1/integrations?auth_type=oauth2
    """
    tenant_id = getattr(request.state, "tenant_id", "unknown")

    try:
        registry = get_integrations_registry()

        # Apply filters
        if category:
            try:
                category_enum = IntegrationCategory(category)
                integrations = registry.list_by_category(category_enum)
            except ValueError:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Invalid category: {category}")
        elif auth_type:
            try:
                auth_enum = AuthType(auth_type)
                integrations = registry.list_by_auth_type(auth_enum)
            except ValueError:
                raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=f"Invalid auth_type: {auth_type}")
        else:
            integrations = registry.list_available()

        rows = [
            {
                "name": integration.name,
                "category": integration.category.value,
                "auth_type": integration.auth_type.value,
                "description": integration.description,
                "capabilities": integration.capabilities,
                "config_required": integration.config_required,
            }
            for integration in integrations
        ]
        paged_rows, _total = paginate_items(rows, pagination)
        return {"integrations": paged_rows}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[{tenant_id}] Failed to list integrations: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to retrieve integrations list"
        )


@router.get("/summary", response_model=dict)
async def get_integrations_summary(request: Request):
    """Get summary of available integrations by category.

    Args:
        request: FastAPI Request object

    Returns:
        Dictionary with counts per category and total

    Example:
        GET /api/v1/integrations/summary
    """
    tenant_id = getattr(request.state, "tenant_id", "unknown")

    try:
        registry = get_integrations_registry()
        summary = registry.get_integration_summary()

        logger.info(f"[{tenant_id}] Retrieved integrations summary: {summary}")
        return summary

    except Exception as e:
        logger.error(f"[{tenant_id}] Failed to get integrations summary: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to retrieve integrations summary"
        )


@router.get("/{integration_name}", response_model=dict)
async def get_integration_details(request: Request, integration_name: str):
    """Get details for a specific integration.

    Args:
        request: FastAPI Request object
        integration_name: Name of the integration (e.g., "HubSpot", "Google Calendar")

    Returns:
        Integration details including capabilities and config requirements

    Example:
        GET /api/v1/integrations/HubSpot
    """
    tenant_id = getattr(request.state, "tenant_id", "unknown")

    try:
        # URL decode and normalize the name
        normalized_name = urllib.parse.unquote(integration_name)

        registry = get_integrations_registry()
        integration = registry.get_integration(normalized_name)

        if not integration:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND, detail=f"Integration '{integration_name}' not found"
            )

        return {
            "name": integration.name,
            "category": integration.category.value,
            "auth_type": integration.auth_type.value,
            "description": integration.description,
            "capabilities": integration.capabilities,
            "config_required": integration.config_required,
            "is_available": integration.is_available,
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[{tenant_id}] Failed to get integration details: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to retrieve integration details"
        )


@router.post("/validate", response_model=dict)
async def validate_integration_config(request: Request, body: dict):
    """Validate integration configuration.

    Args:
        request: FastAPI Request object
        body: Dictionary with 'name' and 'config' keys

    Returns:
        Validation result with is_valid flag

    Example:
        POST /api/v1/integrations/validate
        {
            "name": "HubSpot",
            "config": {
                "client_id": "xxx",
                "client_secret": "xxx"
            }
        }
    """
    tenant_id = getattr(request.state, "tenant_id", "unknown")

    try:
        name = body.get("name")
        config = body.get("config", {})

        if not name:
            raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Missing 'name' field in request body")

        if not config:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, detail="Missing 'config' field in request body"
            )

        registry = get_integrations_registry()
        is_valid = registry.validate_integration_config(name, config)

        logger.info(f"[{tenant_id}] Validated config for {name}: {'valid' if is_valid else 'invalid'}")

        return {
            "name": name,
            "is_valid": is_valid,
            "message": ("Configuration is valid" if is_valid else "Configuration is invalid or incomplete"),
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[{tenant_id}] Failed to validate integration config: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to validate integration configuration"
        )


@router.get("/capabilities/{capability}", response_model=dict)
async def search_by_capability(request: Request, capability: str):
    """Search for integrations that support a specific capability.

    Args:
        request: FastAPI Request object
        capability: Capability to search for (e.g., "create_lead", "send_message")

    Returns:
        List of integrations that support the capability

    Example:
        GET /api/v1/integrations/capabilities/create_lead
    """
    tenant_id = getattr(request.state, "tenant_id", "unknown")

    try:
        # URL decode the capability
        normalized_capability = urllib.parse.unquote(capability)

        registry = get_integrations_registry()
        integrations = registry.search_capabilities(normalized_capability)

        logger.info(f"[{tenant_id}] Found {len(integrations)} integrations supporting '{normalized_capability}'")

        return {
            "capability": normalized_capability,
            "integrations": [
                {
                    "name": integration.name,
                    "category": integration.category.value,
                    "description": integration.description,
                }
                for integration in integrations
            ],
        }

    except Exception as e:
        logger.error(f"[{tenant_id}] Failed to search by capability: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to search integrations by capability"
        )
