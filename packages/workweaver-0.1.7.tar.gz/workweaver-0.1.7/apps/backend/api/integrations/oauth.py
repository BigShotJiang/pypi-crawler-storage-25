"""Integration OAuth API endpoints.

This module provides API endpoints for connecting and disconnecting
third-party integrations via OAuth flows.

Legacy requirement reference: P1.7B.4 — Tool Connection & Disconnection
"""

import logging
import urllib.parse

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.dependencies.redirect_validation import validate_redirect_url
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.schemas.error_response import safe_error_detail
from apps.backend.services.integration_manager import (
    ConnectionState,
    IntegrationConnection,
    IntegrationManager,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/integrations/oauth", tags=["integrations", "oauth"])


# Request/Response Models
class OAuthInitiateRequest(BaseModel):
    """Request to initiate OAuth flow."""

    integration_name: str = Field(..., description="Name of the integration (e.g., 'HubSpot', 'Google Calendar')")
    redirect_uri: str = Field(
        ...,
        description="OAuth callback URI (e.g., 'https://app.workweaver.ai/oauth/callback')",
    )


class OAuthInitiateResponse(BaseModel):
    """Response from OAuth initiate."""

    authorization_url: str = Field(..., description="URL to redirect user to for OAuth approval")
    state: str = Field(..., description="OAuth state parameter for CSRF protection")
    connection_id: str = Field(..., description="Connection ID for tracking")


class OAuthCallbackRequest(BaseModel):
    """Request from OAuth callback."""

    connection_id: str = Field(..., description="Connection ID from initiate_oauth_flow")
    code: str = Field(..., description="OAuth authorization code from callback")
    state: str = Field(..., description="OAuth state parameter from callback")
    agent_id: str | None = Field(
        default=None,
        description="Agent identity that owns this connection (defaults to shared)",
    )


class OAuthConnectionResponse(BaseModel):
    """Response with connection details."""

    connection_id: str
    tenant_id: str
    integration_name: str
    state: str
    auth_type: str
    connected_at: str | None = None
    last_verified: str | None = None
    evidence_event_id: str | None = None
    evidence_url: str | None = None

    @classmethod
    def from_connection(cls, connection: IntegrationConnection) -> "OAuthConnectionResponse":
        """Create from IntegrationConnection."""
        evidence_event_id = connection.evidence_event_id or None
        return cls(
            connection_id=connection.connection_id,
            tenant_id=connection.tenant_id,
            integration_name=connection.integration_name,
            state=connection.state.value,
            auth_type=connection.auth_type.value,
            connected_at=connection.connected_at.isoformat() if connection.connected_at else None,
            last_verified=connection.last_verified.isoformat() if connection.last_verified else None,
            evidence_event_id=evidence_event_id,
            evidence_url=f"/api/v1/evidence/{evidence_event_id}" if evidence_event_id else None,
        )


class ConnectionListResponse(BaseModel):
    """Response with list of connections."""

    connections: list[OAuthConnectionResponse]
    total: int


class DisconnectResponse(BaseModel):
    """Response from disconnect request."""

    connection_id: str
    state: str
    disconnected_at: str


# Dependency Injection
def get_integration_manager() -> IntegrationManager:
    """Get IntegrationManager instance."""
    return IntegrationManager()


def _integration_manager_dep() -> IntegrationManager:
    """
    Dependency wrapper for IntegrationManager.

    Why: FastAPI captures dependency callables at route-definition time. Tests in this
    repo patch `get_integration_manager` at runtime, so routes must depend on a wrapper
    that looks up the global name each call.
    """

    return get_integration_manager()


@router.post("/connect", response_model=OAuthInitiateResponse, status_code=status.HTTP_200_OK)
async def initiate_oauth_flow(
    body: OAuthInitiateRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    manager: IntegrationManager = Depends(_integration_manager_dep),
):
    """Initiate OAuth flow for an integration.

    This endpoint generates an OAuth authorization URL and state parameter.
    Redirect the user to the returned authorization_url to begin the OAuth flow.

    Args:
        request: FastAPI Request object
        body: OAuth initiate request
        manager: IntegrationManager service

    Returns:
        OAuthInitiateResponse with authorization_url, state, and connection_id

    Raises:
        HTTPException 400: Invalid integration name or auth type
        HTTPException 500: Failed to initiate OAuth flow

    Example:
        POST /api/v1/integrations/oauth/connect
        {
            "integration_name": "HubSpot",
            "redirect_uri": "https://app.workweaver.ai/oauth/callback"
        }

        Response:
        {
            "authorization_url": "https://app.hubspot.com/oauth/authorize?...",
            "state": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
            "connection_id": "01ARZ3NDEKTSV4RRFFQ69G5FAV"
        }
    """
    # CVE-2026-32025 (#3184): validate redirect_uri against allowlist.
    validated_redirect = validate_redirect_url(body.redirect_uri, tenant_id=tenant_id)

    try:
        result = await manager.initiate_oauth_flow(
            tenant_id=tenant_id,
            integration_name=body.integration_name,
            redirect_uri=validated_redirect,
        )

        logger.info(
            f"[{tenant_id}] Initiated OAuth flow for {body.integration_name}: connection_id={result['connection_id']}"
        )

        return OAuthInitiateResponse(**result)

    except ValueError as e:
        logger.warning(f"[{tenant_id}] Invalid OAuth initiate request: {e}")
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid OAuth initiate request")
    except Exception as e:
        logger.error(f"[{tenant_id}] Failed to initiate OAuth flow: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to initiate OAuth flow",
        )


@router.post("/callback", response_model=OAuthConnectionResponse, status_code=status.HTTP_200_OK)
async def complete_oauth_flow(
    body: OAuthCallbackRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    manager: IntegrationManager = Depends(_integration_manager_dep),
):
    """Complete OAuth flow by exchanging authorization code for tokens.

    This endpoint is called by the OAuth callback handler after the user
    approves the OAuth request on the integration's side.

    Args:
        request: FastAPI Request object
        body: OAuth callback request with code and state
        manager: IntegrationManager service

    Returns:
        OAuthConnectionResponse with connection details

    Raises:
        HTTPException 400: Invalid state or connection not found
        HTTPException 500: Failed to complete OAuth flow

    Example:
        POST /api/v1/integrations/oauth/callback
        {
            "connection_id": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
            "code": "abc123xyz",
            "state": "01ARZ3NDEKTSV4RRFFQ69G5FAV"
        }

        Response:
        {
            "connection_id": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
            "tenant_id": "tenant_abc",
            "integration_name": "HubSpot",
            "state": "connected",
            "auth_type": "oauth2",
            "connected_at": "2026-02-03T00:00:00Z",
            "last_verified": "2026-02-03T00:00:00Z"
        }
    """
    from apps.backend.services.agent_credential_vault import VaultConfigurationError

    try:
        connection = await manager.complete_oauth_flow(
            tenant_id=tenant_id,
            connection_id=body.connection_id,
            code=body.code,
            state=body.state,
            agent_id=body.agent_id,
        )

        logger.info(
            f"[{tenant_id}] Completed OAuth flow for {connection.integration_name}: connection_id={body.connection_id}"
        )

        return OAuthConnectionResponse.from_connection(connection)

    except ValueError as e:
        logger.warning(f"[{tenant_id}] Invalid OAuth callback request: {e}")
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="Invalid OAuth callback request")
    except VaultConfigurationError as e:
        logger.error(f"[{tenant_id}] Secure storage unavailable during OAuth callback: {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=safe_error_detail(e),
        )
    except Exception as e:
        logger.error(f"[{tenant_id}] Failed to complete OAuth flow: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to complete OAuth flow",
        )


@router.get("", response_model=ConnectionListResponse, status_code=status.HTTP_200_OK)
async def list_connections(
    state: str | None = None,
    tenant_id: str = Depends(get_verified_tenant_id),
    manager: IntegrationManager = Depends(_integration_manager_dep),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
):
    """List all integration connections for the tenant.

    Args:
        request: FastAPI Request object
        state: Optional state filter (e.g., "connected", "pending", "disconnected", "error")
        manager: IntegrationManager service

    Returns:
        ConnectionListResponse with list of connections

    Raises:
        HTTPException 500: Failed to list connections

    Example:
        GET /api/v1/integrations/oauth?state=connected

        Response:
        {
            "connections": [
                {
                    "connection_id": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
                    "tenant_id": "tenant_abc",
                    "integration_name": "HubSpot",
                    "state": "connected",
                    "auth_type": "oauth2",
                    "connected_at": "2026-02-03T00:00:00Z",
                    "last_verified": "2026-02-03T00:00:00Z"
                }
            ],
            "total": 1
        }
    """
    try:
        # Parse state filter if provided
        state_filter = None
        if state:
            try:
                state_filter = ConnectionState(state)
            except ValueError:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Invalid state: {state}. Must be one of: pending, connected, disconnected, error",
                )

        connections = await manager.list_connections(tenant_id=tenant_id, state=state_filter)

        logger.info(f"[{tenant_id}] Listed {len(connections)} integration connections (state filter: {state})")

        bounded, total = paginate_items(connections, pagination)

        return ConnectionListResponse(
            connections=[OAuthConnectionResponse.from_connection(c) for c in bounded],
            total=total,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[{tenant_id}] Failed to list connections: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list connections",
        )


@router.get(
    "/{connection_id}",
    response_model=OAuthConnectionResponse,
    status_code=status.HTTP_200_OK,
)
async def get_connection(
    connection_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    manager: IntegrationManager = Depends(_integration_manager_dep),
):
    """Get details of a specific integration connection.

    Args:
        request: FastAPI Request object
        connection_id: Connection ID
        manager: IntegrationManager service

    Returns:
        OAuthConnectionResponse with connection details

    Raises:
        HTTPException 404: Connection not found
        HTTPException 500: Failed to get connection

    Example:
        GET /api/v1/integrations/oauth/01ARZ3NDEKTSV4RRFFQ69G5FAV

        Response:
        {
            "connection_id": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
            "tenant_id": "tenant_abc",
            "integration_name": "HubSpot",
            "state": "connected",
            "auth_type": "oauth2",
            "connected_at": "2026-02-03T00:00:00Z",
            "last_verified": "2026-02-03T00:00:00Z"
        }
    """
    try:
        connection = await manager.get_connection(tenant_id=tenant_id, connection_id=connection_id)

        logger.info(
            f"[{tenant_id}] Retrieved connection {connection_id}: "
            f"{connection.integration_name} ({connection.state.value})"
        )

        return OAuthConnectionResponse.from_connection(connection)

    except ValueError:
        logger.warning(f"[{tenant_id}] Connection not found: {connection_id}")
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Connection not found")
    except Exception as e:
        logger.error(f"[{tenant_id}] Failed to get connection: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get connection",
        )


@router.delete(
    "/{connection_id}",
    response_model=DisconnectResponse,
    status_code=status.HTTP_200_OK,
)
async def disconnect_integration(
    connection_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    manager: IntegrationManager = Depends(_integration_manager_dep),
):
    """Disconnect an integration connection.

    Marks the connection as DISCONNECTED but keeps the record for audit purposes.

    Args:
        request: FastAPI Request object
        connection_id: Connection ID to disconnect
        manager: IntegrationManager service

    Returns:
        DisconnectResponse with connection_id, state, and disconnected_at timestamp

    Raises:
        HTTPException 404: Connection not found
        HTTPException 400: Connection already disconnected
        HTTPException 500: Failed to disconnect integration

    Example:
        DELETE /api/v1/integrations/oauth/01ARZ3NDEKTSV4RRFFQ69G5FAV

        Response:
        {
            "connection_id": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
            "state": "disconnected",
            "disconnected_at": "2026-02-03T00:00:00Z"
        }
    """
    try:
        connection = await manager.disconnect_integration(tenant_id=tenant_id, connection_id=connection_id)

        logger.info(f"[{tenant_id}] Disconnected {connection.integration_name}: connection_id={connection_id}")

        return DisconnectResponse(
            connection_id=connection.connection_id,
            state=connection.state.value,
            disconnected_at=connection.disconnected_at.isoformat() if connection.disconnected_at else "",
        )

    except ValueError as e:
        logger.warning(f"[{tenant_id}] Invalid disconnect request: {e}")
        is_already_disconnected = "already disconnected" in str(e).lower()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST if is_already_disconnected else status.HTTP_404_NOT_FOUND,
            detail="Connection already disconnected" if is_already_disconnected else "Connection not found",
        )
    except Exception as e:
        logger.error(f"[{tenant_id}] Failed to disconnect integration: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to disconnect integration",
        )


@router.get(
    "/by-integration/{integration_name}",
    response_model=OAuthConnectionResponse,
    status_code=status.HTTP_200_OK,
)
async def get_connection_by_integration(
    integration_name: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    manager: IntegrationManager = Depends(_integration_manager_dep),
):
    """Get the active connection for a specific integration.

    Args:
        request: FastAPI Request object
        integration_name: Name of the integration
        manager: IntegrationManager service

    Returns:
        OAuthConnectionResponse with connection details

    Raises:
        HTTPException 404: No active connection found
        HTTPException 500: Failed to get connection

    Example:
        GET /api/v1/integrations/oauth/by-integration/HubSpot

        Response:
        {
            "connection_id": "01ARZ3NDEKTSV4RRFFQ69G5FAV",
            "tenant_id": "tenant_abc",
            "integration_name": "HubSpot",
            "state": "connected",
            "auth_type": "oauth2",
            "connected_at": "2026-02-03T00:00:00Z",
            "last_verified": "2026-02-03T00:00:00Z"
        }
    """
    try:
        # URL decode integration name
        normalized_name = urllib.parse.unquote(integration_name)

        connection = await manager.get_connection_by_integration(tenant_id=tenant_id, integration_name=normalized_name)

        if not connection:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"No active connection found for '{normalized_name}'",
            )

        logger.info(
            f"[{tenant_id}] Retrieved connection for {normalized_name}: connection_id={connection.connection_id}"
        )

        return OAuthConnectionResponse.from_connection(connection)

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"[{tenant_id}] Failed to get connection by integration: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get connection",
        )
