"""Per-agent identity provisioning, key rotation, and readiness API.

Provides:
- POST /api/v1/employees/{agent_id}/identity/provision — provision agent identity
- POST /api/v1/employees/{agent_id}/identity/rotate — rotate agent keys
- GET /api/v1/agent-identity/readiness — read Zara identity readiness

F-AU-006: Per-Agent Identity — each agent gets a unique Ed25519
signing identity for evidence provenance and action authorization.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.agent_identity_readiness import (
    get_agent_identity_readiness_service,
)
from apps.backend.services.agent_scope_registry import (
    get_agent_scope_registry,
)

logger = logging.getLogger(__name__)

router = APIRouter(tags=["identity"])


class ProvisionIdentityResponse(BaseModel):
    """Response after provisioning an agent identity."""

    identity_id: str
    agent_id: str
    public_key: str
    status: str
    created_at: str


class RotateKeysRequest(BaseModel):
    """Request to rotate agent keys."""

    identity_id: str = Field(..., description="Current identity ID to expire")


class RotateKeysResponse(BaseModel):
    """Response after rotating agent keys."""

    identity_id: str
    agent_id: str
    public_key: str
    status: str
    created_at: str
    previous_identity_id: str


class IdentityReadinessPurpose(BaseModel):
    purpose: str
    provider: str
    status: str
    principal_email: str | None = None
    missing_reason: str | None = None
    required_scopes: list[str] = Field(default_factory=list)
    granted_scopes: list[str] = Field(default_factory=list)


class IdentityReadinessResponse(BaseModel):
    tenant_id: str
    purposes: list[IdentityReadinessPurpose] = Field(default_factory=list)


class PurposeIdentityStatus(BaseModel):
    """Per-purpose identity status for a Zara-owned provider identity."""

    purpose: str
    status: str
    provider: str
    principal_email: str | None = None
    scopes: list[str] = Field(default_factory=list)
    forbidden_scopes: list[str] = Field(default_factory=list)
    missing_reason: str | None = None


class ZaraIdentityStatus(BaseModel):
    """Full identity status for an agent across all purpose surfaces."""

    agent_id: str
    tenant_id: str
    purposes: list[PurposeIdentityStatus] = Field(default_factory=list)


def _get_identity_governance() -> Any:
    from apps.backend.services.agent_identity_governance import (
        get_agent_identity_governance,
    )

    return get_agent_identity_governance()


@router.get(
    "/api/v1/agents/{agent_id}/identity",
    response_model=ZaraIdentityStatus,
)
async def get_agent_identity_status(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ZaraIdentityStatus:
    """Return per-purpose identity readiness and provider status for an agent.

    Each purpose surface (email, calendar, meeting, voice, payment) reports
    whether a Zara-owned provider identity is ready, missing provider auth,
    revoked, or unsupported. Includes granted scopes and forbidden scopes.
    """
    readiness_result = get_agent_identity_readiness_service().readiness(
        tenant_id=tenant_id,
        agent_id=agent_id,
    )
    scope_registry = get_agent_scope_registry()

    purpose_statuses: list[PurposeIdentityStatus] = []
    for item in readiness_result.get("purposes", []):
        purpose_name = str(item.get("purpose", ""))
        provider = str(item.get("provider", ""))
        status = str(item.get("status", "missing"))
        principal_email = item.get("principal_email")
        missing_reason = item.get("missing_reason")

        # Map the readiness purpose name back to AgentPurpose for scope lookup
        agent_purpose = _purpose_name_to_agent_purpose(purpose_name)
        granted_scopes = list(item.get("granted_scopes") or [])
        if agent_purpose:
            forbidden = list(scope_registry.forbidden_for(agent_purpose))
        else:
            forbidden = []

        purpose_statuses.append(
            PurposeIdentityStatus(
                purpose=purpose_name,
                status=status,
                provider=provider,
                principal_email=principal_email,
                scopes=granted_scopes,
                forbidden_scopes=forbidden,
                missing_reason=missing_reason,
            )
        )

    return ZaraIdentityStatus(
        agent_id=agent_id,
        tenant_id=readiness_result.get("tenant_id", tenant_id),
        purposes=purpose_statuses,
    )


def _purpose_name_to_agent_purpose(purpose_name: str) -> Any:
    """Map identity readiness purpose name to AgentPurpose enum."""
    from apps.backend.services.agent_scope_registry import AgentPurpose

    mapping = {
        "email": AgentPurpose.EMAIL_SEND,
        "calendar": AgentPurpose.CALENDAR_WRITE,
        "meeting": AgentPurpose.MEETING_JOIN,
        "voice": AgentPurpose.VOICE_CALL,
        "payment": AgentPurpose.PAYMENT_MANAGE,
    }
    return mapping.get(purpose_name)


@router.post(
    "/api/v1/employees/{agent_id}/identity/provision",
    response_model=ProvisionIdentityResponse,
    status_code=201,
)
async def provision_agent_identity(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ProvisionIdentityResponse:
    """Provision a dedicated cryptographic identity for an agent.

    Creates an Ed25519 keypair, stores the private key in the vault,
    and returns the public key and identity metadata.
    """
    try:
        governance = _get_identity_governance()
        result = governance.provision_agent_identity(
            tenant_id=tenant_id,
            agent_id=agent_id,
            actor="api",
        )

        return ProvisionIdentityResponse(
            identity_id=result["identity_id"],
            agent_id=result["agent_id"],
            public_key=result["public_key"],
            status=result["status"],
            created_at=result["created_at"],
        )
    except ValueError as exc:
        logger.error("Identity provision validation error: %s", exc, exc_info=True)
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.exception(
            "Failed to provision identity: tenant=%s agent=%s error=%s",
            tenant_id,
            agent_id,
            exc,
        )
        raise HTTPException(status_code=500, detail="Failed to provision agent identity")


@router.post(
    "/api/v1/employees/{agent_id}/identity/rotate",
    response_model=RotateKeysResponse,
    status_code=200,
)
async def rotate_agent_keys(
    agent_id: str,
    request: RotateKeysRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> RotateKeysResponse:
    """Rotate an agent's cryptographic keys.

    Expires the current identity and provisions a new one.
    """
    try:
        governance = _get_identity_governance()
        result = governance.rotate_keys(
            tenant_id=tenant_id,
            agent_id=agent_id,
            identity_id=request.identity_id,
            actor="api",
        )

        return RotateKeysResponse(
            identity_id=result["identity_id"],
            agent_id=result["agent_id"],
            public_key=result["public_key"],
            status=result["status"],
            created_at=result["created_at"],
            previous_identity_id=request.identity_id,
        )
    except ValueError as exc:
        logger.error("Key rotation validation error: %s", exc, exc_info=True)
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except Exception as exc:
        logger.exception(
            "Failed to rotate keys: tenant=%s agent=%s error=%s",
            tenant_id,
            agent_id,
            exc,
        )
        raise HTTPException(status_code=500, detail="Failed to rotate agent keys")


@router.get(
    "/api/v1/agent-identity/readiness",
    response_model=IdentityReadinessResponse,
)
async def read_agent_identity_readiness(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> IdentityReadinessResponse:
    """Return read-only readiness for Zara-owned provider identities."""
    result = get_agent_identity_readiness_service().readiness(tenant_id=tenant_id)
    return IdentityReadinessResponse.model_validate(result)
