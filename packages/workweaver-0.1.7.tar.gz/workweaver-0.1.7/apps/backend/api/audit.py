"""Audit export API surface."""

from __future__ import annotations

from typing import Annotated, Any, Literal

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.founder_admin import require_founder
from apps.backend.services.change_events import ChangeEventIntegrityError, ChangeEventService, get_change_event_service

router = APIRouter(prefix="/api/v1/audit", tags=["audit"])


@router.get("/change-events", response_model=None)
async def export_change_events(
    from_ts: Annotated[str | None, Query(alias="from", description="Inclusive ISO-8601 lower bound")] = None,
    to_ts: Annotated[str | None, Query(alias="to", description="Inclusive ISO-8601 upper bound")] = None,
    format: Annotated[Literal["csv", "json"], Query(description="Export format")] = "json",
    tenant_id: str = Depends(get_verified_tenant_id),
    _admin_email: str = Depends(require_founder),
    service: ChangeEventService = Depends(get_change_event_service),
) -> Any:
    """Return a signed SOC2 change-event export for the authenticated tenant."""

    try:
        exported = service.export_changes(tenant_id=tenant_id, from_ts=from_ts, to_ts=to_ts, format=format)
    except ChangeEventIntegrityError as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={"error": "change_event_integrity_failed", "detail": str(exc)},
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "invalid_change_event_export_query", "detail": str(exc)},
        ) from exc

    if format == "csv":
        return Response(
            content=str(exported),
            media_type="text/csv",
            headers={"Content-Disposition": 'attachment; filename="workweaver-change-events.csv"'},
        )
    return exported if isinstance(exported, dict) else {"export": exported}
