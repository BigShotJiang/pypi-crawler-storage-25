"""
Meeting Ingest API

Webhook endpoints for third-party meeting notetakers and meeting list.

Source: docs/PRODUCT.md#Part18.2
"""

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.action_item_extractor import ActionItemExtractor
from apps.backend.services.meeting_ingest import MeetingIngestService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/mission/meetings", tags=["meetings"])

_meeting_svc = MeetingIngestService()
_extractor = ActionItemExtractor()


class MeetingIngestRequest(BaseModel):
    provider: str = Field(..., description="otter | fireflies | recall | manual")
    payload: dict[str, Any] = Field(..., description="Provider-specific payload")


class ExtractActionsRequest(BaseModel):
    transcript: str = Field(..., min_length=10, description="Meeting transcript")
    summary: str = Field("", description="Meeting summary")
    attendees: list[str] = Field(default_factory=list)


@router.post("/ingest")
async def ingest_meeting(
    req: MeetingIngestRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Ingest meeting data from a provider."""
    try:
        return _meeting_svc.ingest(tenant_id, req.provider, req.payload)
    except ValueError as exc:
        logger.error("Meeting ingest validation error: %s", exc, exc_info=True)
        raise HTTPException(status_code=400, detail="Invalid request parameters") from exc


@router.post("/webhook/{provider}")
async def meeting_webhook(
    provider: str,
    payload: dict[str, Any],
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Webhook endpoint for meeting notetaker providers."""
    try:
        return _meeting_svc.ingest(tenant_id, provider, payload)
    except ValueError as exc:
        logger.error("Meeting ingest validation error: %s", exc, exc_info=True)
        raise HTTPException(status_code=400, detail="Invalid request parameters") from exc


@router.post("/extract-actions")
async def extract_action_items(
    req: ExtractActionsRequest,
) -> list[dict[str, Any]]:
    """Extract action items from a transcript."""
    return _extractor.extract(req.transcript, req.summary, req.attendees)


@router.get("")
async def list_meetings(
    limit: int = Query(50, ge=1, le=200),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[dict[str, Any]]:
    """List ingested meetings."""
    return _meeting_svc.list_meetings(tenant_id, limit)


@router.get("/{meeting_id}")
async def get_meeting(
    meeting_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Get a specific meeting."""
    meeting = _meeting_svc.get_meeting(tenant_id, meeting_id)
    if not meeting:
        raise HTTPException(status_code=404, detail=f"Meeting {meeting_id} not found")
    return meeting
