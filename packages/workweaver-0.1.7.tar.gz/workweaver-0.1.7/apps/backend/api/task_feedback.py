"""Task Feedback API (M9.3) — Task Feedback / Rating System.

Endpoint:
    POST /api/v1/mission/tasks/{task_id}/feedback — { rating: 1-5, comment: "..." }

Wire: LearningLoopService — ratings < 3 trigger pattern review,
      ratings >= 4 reinforce current patterns.
      Feedback stored in evidence ledger as learning signal.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/mission/tasks", tags=["task-feedback"])

# Rating threshold: below this triggers pattern review
_LOW_RATING_THRESHOLD = 3
# Rating threshold: at or above this reinforces patterns
_HIGH_RATING_THRESHOLD = 4


# ---------------------------------------------------------------------------
# Request model
# ---------------------------------------------------------------------------


class FeedbackRequest(BaseModel):
    rating: int = Field(..., ge=1, le=5, description="Quality rating 1-5")
    comment: str | None = Field(None, max_length=2000, description="Optional feedback text")


# ---------------------------------------------------------------------------
# Dependencies
# ---------------------------------------------------------------------------


def _get_task_store():  # type: ignore[return]
    from apps.backend.services.task_store import get_task_store

    return get_task_store()


def _get_learning_loop():  # type: ignore[return]
    from apps.backend.services.learning import LearningLoopService

    return LearningLoopService.__new__(LearningLoopService)


def _get_evidence_service():  # type: ignore[return]
    from apps.backend.services.evidence_ledger import get_evidence_ledger_service

    return get_evidence_ledger_service()


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------


@router.post("/{task_id}/feedback")
def submit_task_feedback(
    task_id: str,
    body: FeedbackRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    task_store: Any = Depends(_get_task_store),
    learning_loop: Any = Depends(_get_learning_loop),
    evidence_service: Any = Depends(_get_evidence_service),
) -> dict[str, Any]:
    """Submit quality feedback for a completed task.

    - Rating 1-2: triggers pattern review via learning loop
    - Rating 3: neutral, recorded only
    - Rating 4-5: reinforces current patterns
    - All feedback stored in evidence ledger as learning signal
    """
    # Verify task exists
    task = task_store.get_task(tenant_id, task_id)
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")

    # Store feedback in evidence ledger
    try:
        evidence_service.ingest(
            tenant_id=tenant_id,
            event_type="task_feedback",
            data={
                "task_id": task_id,
                "rating": body.rating,
                "comment": body.comment or "",
                "task_title": task.get("title", ""),
                "task_status": task.get("status", ""),
            },
        )
    except Exception as exc:
        logger.warning("Failed to ingest feedback evidence for %s: %s", task_id, exc)

    # Trigger learning loop actions based on rating
    if body.rating < _LOW_RATING_THRESHOLD:
        try:
            learning_loop.flag_pattern_for_review(
                tenant_id=tenant_id,
                task_id=task_id,
                reason=f"Low rating ({body.rating}/5): {body.comment or 'no comment'}",
            )
        except Exception as exc:
            logger.warning("Pattern review flag failed for %s: %s", task_id, exc)
    elif body.rating >= _HIGH_RATING_THRESHOLD:
        try:
            learning_loop.reinforce_patterns(
                tenant_id=tenant_id,
                task_id=task_id,
                signal=f"High rating ({body.rating}/5): {body.comment or 'no comment'}",
            )
        except Exception as exc:
            logger.warning("Pattern reinforcement failed for %s: %s", task_id, exc)

    return {
        "task_id": task_id,
        "rating": body.rating,
        "comment": body.comment,
        "status": "recorded",
    }
