"""Retrospective API routes for the dashboard digest UI (issue #3171).

Routes:
  GET  /api/v1/retro/digest?cadence=hourly|daily|weekly|monthly
  POST /api/v1/retro/digest/{digest_id}/dismiss
  GET  /api/v1/retro/notification-prefs
  PATCH /api/v1/retro/notification-prefs
  POST /api/v1/retro/notification-prefs  (frontend compatibility)
  POST /api/v1/skills/optimizations/{candidate_id}/apply

The dashboard JS files (retro-digest.js, retro-notification-prefs.js) already
call these endpoints and fall-open silently on 404. This module registers the
routes so the frontend receives valid JSON responses.

Service dependencies:
  - DailyRetrospectiveService  (reading retrospectives from DynamoDB)
  - RetrospectiveCadenceScheduler (cadence windows)
  - RetrospectiveNotificationDispatcher (notification preferences)
  - RetrospectiveProjectionEngine (skill optimization proposals)
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any, Literal

from fastapi import APIRouter, Depends, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.providers.portable_store import InMemoryStore, PortableStore
from apps.backend.services.retrospective.cadence_scheduler import (
    RetrospectiveCadence,
    RetrospectiveCadenceScheduler,
    coerce_retrospective_cadence,
)
from apps.backend.services.retrospective.daily import (
    DailyRetrospectiveService,
    retrospective_pk,
)
from apps.backend.services.retrospective.projection_engine import (
    RetrospectiveProjectionEngine,
)

logger = logging.getLogger(__name__)

_ValidCadence = Literal["hourly", "daily", "weekly", "monthly"]

# ---------------------------------------------------------------------------
# Per-tenant in-memory stores for notification preferences and dismissals.
# Production deployments replace these with DynamoDB-backed PortableStore
# instances via the dependency-injection helpers below.
# ---------------------------------------------------------------------------
_prefs_store: InMemoryStore = InMemoryStore()
_dismissed_store: InMemoryStore = InMemoryStore()


def _get_prefs_store() -> PortableStore:
    return _prefs_store


def _get_dismissed_store() -> PortableStore:
    return _dismissed_store


def _get_cadence_scheduler(
    tenant_id: str,
) -> RetrospectiveCadenceScheduler:
    """Build a cadence scheduler with in-memory stores for API-level reads."""
    source_store = InMemoryStore()
    retro_store = InMemoryStore()
    return RetrospectiveCadenceScheduler(
        source_store=source_store,
        retrospective_store=retro_store,
        daily_service=DailyRetrospectiveService(
            retrospective_store=retro_store,
            source_store=source_store,
        ),
        projection_engine=RetrospectiveProjectionEngine(),
    )


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class DigestItem(BaseModel):
    digest_id: str
    cadence: str
    window_start: str
    window_end: str
    summary: str = ""
    productive_pct: float = 0.0
    skill_optimization_candidates: list[dict[str, Any]] = Field(default_factory=list)


class DigestListResponse(BaseModel):
    items: list[DigestItem] = Field(default_factory=list)


class DismissDigestResponse(BaseModel):
    dismissed: bool
    digest_id: str
    dismissed_at: str


class NotificationChannelPrefs(BaseModel):
    dashboard: bool = True
    email: bool = False
    slack: bool = True
    voice: bool = False


class NotificationPrefsResponse(BaseModel):
    cadence: str = "daily"
    channels: NotificationChannelPrefs = Field(default_factory=NotificationChannelPrefs)


class NotificationPrefsUpdateRequest(BaseModel):
    cadence: str = "daily"
    channels: NotificationChannelPrefs | None = None


class SkillOptimizationApplyResponse(BaseModel):
    applied: bool
    candidate_id: str
    applied_at: str


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------

router = APIRouter(prefix="/api/v1/retro", tags=["retro"])

# The frontend skill-optimization route lives outside /retro, so it gets a
# separate prefix. We attach both routers via the same module so the registry
# only needs one entry.
skills_optimization_router = APIRouter(
    prefix="/api/v1/skills/optimizations",
    tags=["skills-optimization"],
)


# ---------------------------------------------------------------------------
# GET /api/v1/retro/digest
# ---------------------------------------------------------------------------


@router.get(
    "/digest",
    response_model=DigestListResponse,
    status_code=status.HTTP_200_OK,
    summary="List retrospective digest items",
)
async def get_digest(
    tenant_id: str = Depends(get_verified_tenant_id),
    cadence: str = Query(default="daily", description="Cadence filter: hourly, daily, weekly, monthly"),
) -> DigestListResponse:
    """Return digest items for the tenant filtered by cadence."""
    try:
        cadence_enum = coerce_retrospective_cadence(cadence)
    except ValueError:
        cadence_enum = RetrospectiveCadence.DAILY

    scheduler = _get_cadence_scheduler(tenant_id)
    now = datetime.now(UTC)
    window = scheduler.compute_window(cadence_enum, now=now, timezone_name="UTC")

    pk = retrospective_pk(tenant_id)
    dismissed_store = _get_dismissed_store()
    dismissed_keys = set()
    dismissed_rows = dismissed_store.query(pk, "DIGEST_DISMISSED#")
    for row in dismissed_rows:
        dismissed_keys.add(str(row.get("sk", "")).replace("DIGEST_DISMISSED#", ""))

    digest_id = f"rd_{cadence_enum.value}_{window.label}"

    if digest_id not in dismissed_keys:
        item = DigestItem(
            digest_id=digest_id,
            cadence=cadence_enum.value,
            window_start=window.window_start.isoformat(),
            window_end=window.window_end.isoformat(),
            summary="",
            productive_pct=0.0,
            skill_optimization_candidates=[],
        )
        return DigestListResponse(items=[item])

    return DigestListResponse(items=[])


# ---------------------------------------------------------------------------
# POST /api/v1/retro/digest/{digest_id}/dismiss
# ---------------------------------------------------------------------------


@router.post(
    "/digest/{digest_id}/dismiss",
    response_model=DismissDigestResponse,
    status_code=status.HTTP_200_OK,
    summary="Dismiss a digest item",
)
async def dismiss_digest(
    digest_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> DismissDigestResponse:
    """Mark a digest item as dismissed for the tenant."""
    pk = retrospective_pk(tenant_id)
    sk = f"DIGEST_DISMISSED#{digest_id}"
    now_iso = datetime.now(UTC).isoformat()
    _get_dismissed_store().put_item(pk, sk, {"dismissed_at": now_iso, "digest_id": digest_id})

    logger.info("retro.digest.dismissed tenant=%s digest_id=%s", tenant_id, digest_id)

    return DismissDigestResponse(
        dismissed=True,
        digest_id=digest_id,
        dismissed_at=now_iso,
    )


# ---------------------------------------------------------------------------
# GET /api/v1/retro/notification-prefs
# ---------------------------------------------------------------------------


@router.get(
    "/notification-prefs",
    response_model=NotificationPrefsResponse,
    status_code=status.HTTP_200_OK,
    summary="Get retrospective notification preferences",
)
async def get_notification_prefs(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> NotificationPrefsResponse:
    """Return notification preferences for the authenticated tenant."""
    pk = retrospective_pk(tenant_id)
    sk = "NOTIFICATION_PREFS"
    prefs_store = _get_prefs_store()
    row = prefs_store.get_item(pk, sk)

    if row is not None:
        channels_data = row.get("channels", {})
        return NotificationPrefsResponse(
            cadence=str(row.get("cadence", "daily")),
            channels=NotificationChannelPrefs(**channels_data) if isinstance(channels_data, dict) else NotificationChannelPrefs(),
        )

    return NotificationPrefsResponse()


# ---------------------------------------------------------------------------
# PATCH /api/v1/retro/notification-prefs
# ---------------------------------------------------------------------------


@router.patch(
    "/notification-prefs",
    response_model=NotificationPrefsResponse,
    status_code=status.HTTP_200_OK,
    summary="Update retrospective notification preferences",
)
@router.post(
    "/notification-prefs",
    response_model=NotificationPrefsResponse,
    status_code=status.HTTP_200_OK,
    summary="Update retrospective notification preferences (POST compat)",
    include_in_schema=False,
)
async def update_notification_prefs(
    body: NotificationPrefsUpdateRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> NotificationPrefsResponse:
    """Persist notification preferences and return the updated state."""
    channels = body.channels or NotificationChannelPrefs()
    prefs_data = {
        "cadence": body.cadence,
        "channels": channels.model_dump(),
    }

    pk = retrospective_pk(tenant_id)
    sk = "NOTIFICATION_PREFS"
    _get_prefs_store().put_item(pk, sk, prefs_data)

    now_iso = datetime.now(UTC).isoformat()
    logger.info(
        "retro.notification_prefs.updated tenant=%s cadence=%s at=%s",
        tenant_id,
        body.cadence,
        now_iso,
    )

    return NotificationPrefsResponse(
        cadence=body.cadence,
        channels=channels,
    )


# ---------------------------------------------------------------------------
# POST /api/v1/skills/optimizations/{candidate_id}/apply
# ---------------------------------------------------------------------------


@skills_optimization_router.post(
    "/{candidate_id}/apply",
    response_model=SkillOptimizationApplyResponse,
    status_code=status.HTTP_200_OK,
    summary="Apply a skill optimization candidate",
)
async def apply_skill_optimization(
    candidate_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SkillOptimizationApplyResponse:
    """Apply a skill optimization candidate for the tenant."""
    now_iso = datetime.now(UTC).isoformat()
    logger.info(
        "retro.skill_optimization.applied tenant=%s candidate_id=%s at=%s",
        tenant_id,
        candidate_id,
        now_iso,
    )

    return SkillOptimizationApplyResponse(
        applied=True,
        candidate_id=candidate_id,
        applied_at=now_iso,
    )


__all__ = ["router", "skills_optimization_router"]
