"""Universal Pulse API."""

from __future__ import annotations

from typing import Literal

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.models.pulse import PulseProjection
from apps.backend.services.pulse_service import get_pulse_projection_service
from apps.backend.utils.tenant import strip_tenant_prefix

router = APIRouter(prefix="/api/v1/pulse", tags=["pulse"])


class PulseListResponse(BaseModel):
    tenant_id: str
    pulses: list[PulseProjection]
    count: int


@router.get("", response_model=PulseListResponse)
async def list_pulse(
    state: Literal["alive", "idle", "executing", "waiting", "blocked", "degraded", "orphaned"] | None = Query(None),
    kind: Literal["agent", "swarm", "schedule", "job"] | None = Query(None),
    subject_id: str | None = Query(None),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PulseListResponse:
    tenant = strip_tenant_prefix(tenant_id)
    pulses = get_pulse_projection_service().list_pulses(
        tenant,
        state=state,
        kind=kind,
        subject_id=subject_id,
    )
    return PulseListResponse(tenant_id=tenant, pulses=pulses, count=len(pulses))
