"""Meeting participation runtime API.

Implements fail-closed provider behavior for meeting participation:
- If provider credentials are missing, return typed `provider_unconfigured`.
- If credentials exist, attempt real provider operations (Recall.ai).

This endpoint family is distinct from meeting_ingest (which handles post-meeting
ingestion from third-party notetakers).
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
from datetime import datetime, UTC
from decimal import Decimal
from enum import Enum
from typing import Any, cast

import httpx
import ulid
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items, paginate_limit
from apps.backend.services.agent_identity_assertion import (
    AgentIdentityAssertionError,
    get_agent_identity_assertion_service,
)
from apps.backend.services.agent_identity_readiness import IdentityMode
from apps.backend.services.agent_identity_provisioning import (
    AgentOAuthPrincipal,
    AgentOAuthPrincipalUnavailableError,
    get_agent_oauth_principal_provisioning_service,
)
from apps.backend.services.agent_principal_service import (
    AgentPrincipal,
    adapt_legacy_oauth_principal,
)
from apps.backend.services.meeting.interfaces import (
    MeetingJoinBlockedError,
    MeetingParticipationContract,
)
from apps.backend.services.meeting.recall_adapter import RecallAIMeetingAdapter
from apps.backend.services.region_router import get_recall_config, resolve_recall_api_key
from apps.backend.services.meeting_session_store import (
    MeetingSessionStoreError,
    get_meeting_session_store,
)
from apps.backend.services.consent_manager import get_consent_manager
from apps.backend.services.billing import MeteringService
from apps.backend.services.meeting.error_contracts import meeting_store_unavailable_http_exception
from apps.backend.services.meeting.shared_meeting_service import get_shared_meeting_service
from apps.backend.services.sourced_recall import get_sourced_recall_service
from apps.backend.services.tenant_provisioning import get_tenant_provisioning_service
from apps.backend.services.usage_tracker import UsageMetricType

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/meetings", tags=["meetings-runtime"])


class ProviderState(str, Enum):
    CONFIGURED = "configured"
    MISSING_CREDENTIALS = "missing_credentials"
    DISABLED = "disabled"
    DEGRADED = "degraded"


class MeetingParticipationMode(str, Enum):
    JOIN_ONLY = "join_only"
    SPEAK_VIA_OUTPUT_MEDIA = "speak_via_output_media"
    SIGNED_IN_PARTICIPANT = "signed_in_participant"


class JoinMeetingRequest(BaseModel):
    meeting_url: str = Field(..., description="Join URL for external meeting")
    bot_name: str = Field(
        default="Zara (AI Employee, Workweaver)",
        description="Displayed bot participant name",
    )
    output_media_url: str | None = Field(
        default=None,
        description="Optional webpage URL to stream as bot output media/camera",
    )
    participation_mode: MeetingParticipationMode = Field(
        default=MeetingParticipationMode.JOIN_ONLY,
        description=(
            "Canonical participation contract. join_only means a listener-only bot join. "
            "speak_via_output_media enables the output-media path. signed_in_participant "
            "is explicitly unsupported and rejected until a signed-in meeting bridge exists."
        ),
    )
    consent: MeetingJoinConsentRequest | None = Field(
        default=None,
        description="Explicit consent confirmation required before configured meeting joins.",
    )
    booking_context: dict[str, Any] | None = Field(
        default=None,
        description="Optional booking page or slot context to preserve through webhook/post-meeting flows.",
    )
    lead_context: dict[str, Any] | None = Field(
        default=None,
        description="Optional lead/contact context to preserve through webhook/post-meeting flows.",
    )
    attendees: list[str] = Field(
        default_factory=list,
        description="Known meeting attendees or lead emails for post-meeting follow-up.",
    )
    expected_duration_minutes: int | None = Field(
        default=None,
        description="Optional hint for how long the meeting is expected to run; used to pre-size the memory bridge.",
    )


class MeetingJoinConsentRequest(BaseModel):
    confirmed: bool = Field(
        ...,
        description="Caller confirms all participants were notified and consented before join.",
    )
    consented_by: str | None = Field(
        default=None,
        description="Identifier for the human/operator who captured consent.",
    )
    consent_method: str = Field(
        default="host_pre_authorization",
        description="Consent capture method.",
    )
    announcement_text: str | None = Field(
        default=None,
        description="Disclosure text shown or spoken before join.",
    )
    announcement_language: str | None = Field(
        default="en",
        description="Language for the disclosure text.",
    )
    participants_notified: list[str] = Field(
        default_factory=list,
        description="Participants who were notified before the assistant joined.",
    )
    recording_enabled: bool = Field(
        default=True,
        description="Whether recording/transcription is enabled for this meeting join.",
    )


class JoinMeetingResponse(BaseModel):
    session_id: str
    provider: str
    state: str
    participation_mode: str = Field(default=MeetingParticipationMode.JOIN_ONLY.value)
    identity_mode: IdentityMode = Field(default=IdentityMode.ZARA_OWNED)
    identity_reason: str | None = None
    action_identity: str = Field(
        default="zara_owned",
        description="Action-time identity mode (zara_owned|delegated_human|draft_only|denied)",
    )
    action_identity_reason: str | None = Field(
        None,
        description="Human-readable reason for the action_identity value",
    )
    bot_id: str | None = None
    bot_identity: dict[str, Any] | None = None
    created_at: str
    consent_id: str | None = None
    runtime_session: dict[str, Any] | None = None


class MeetingStatusResponse(BaseModel):
    session_id: str
    tenant_id: str
    provider: str
    state: str
    participation_mode: str = Field(default=MeetingParticipationMode.JOIN_ONLY.value)
    identity_mode: IdentityMode = Field(default=IdentityMode.ZARA_OWNED)
    identity_reason: str | None = None
    action_identity: str = Field(
        default="zara_owned",
        description="Action-time identity mode (zara_owned|delegated_human|draft_only|denied)",
    )
    action_identity_reason: str | None = Field(
        None,
        description="Human-readable reason for the action_identity value",
    )
    bot_id: str | None = None
    bot_identity: dict[str, Any] | None = None
    meeting_url: str
    bot_name: str
    created_at: str
    updated_at: str
    error: str | None = None
    consent_id: str | None = None
    runtime_session: dict[str, Any] | None = None


class PreMeetingBriefRequest(BaseModel):
    title: str = Field(..., description="Upcoming meeting title")
    participants: list[str] = Field(default_factory=list, description="Participant names or emails")
    scheduled_for: str | None = Field(default=None, description="ISO8601 or display datetime")
    agenda: str | None = Field(default=None, description="Optional agenda or objective")


class PreMeetingBriefResponse(BaseModel):
    title: str
    scheduled_for: str | None = None
    participants: list[str] = Field(default_factory=list)
    agenda: str | None = None
    brief: str
    citations: list[dict[str, Any]] = Field(default_factory=list)
    generated_at: str
    query: str


_PROVIDER_ERRORS: dict[str, str] = {}
_PLACEHOLDER_CREDENTIAL_VALUES = {"__fill_me__", "__replace_me__", "changeme", "placeholder"}

_DONE_EVENTS = frozenset({"bot.done", "bot.leave", "done", "meeting_ended", "bot_left", "call_ended", "session_stopped"})
_ACTIVE_EVENTS = frozenset({"meeting_started", "bot_joined", "call_joined"})
_MEETING_CONSENT_CONSENT_TYPE = "meeting_join_recording"
_MEETING_CONSENT_CHANNEL = "voice_api"
_MEETING_CONSENT_DEFAULT_METHOD = "host_pre_authorization"
_MEETING_CONSENT_POLICY_ERRORS = [
    "consent_required",
    "participants_notified_required",
    "consent_store_unavailable",
    "blocked_tenant",
]
_SUPPLEMENTAL_MEETING_PROVIDERS: dict[str, list[str]] = {
    "grok_voice": ["XAI_API_KEY"],
    "sarvam_transcript": ["SARVAM_API_KEY"],
    "deepgram_transcript": ["DEEPGRAM_API_KEY"],
    "zoom_oauth": ["ZOOM_OAUTH_CLIENT_ID", "ZOOM_OAUTH_CLIENT_SECRET"],
    "microsoft_graph": ["MICROSOFT_CLIENT_ID", "MICROSOFT_CLIENT_SECRET", "AZURE_TENANT_ID"],
    "zoho_meeting": ["ZOHO_CLIENT_ID", "ZOHO_CLIENT_SECRET"],
}


def __getattr__(name: str) -> Any:
    if name == "_RECALL_OBSERVE_MANIFEST":
        return _recall_observe_manifest()
    if name in {
        "AgentIdentityAssertionRequiredError",
        "AgentPurposeMismatchError",
        "ConsentArtifact",
        "MeetingRuntimeSession",
        "MeetingRuntimeSessionError",
        "ProviderCapabilityManifest",
    }:
        from apps.backend.services.meeting import meeting_runtime_session

        return getattr(meeting_runtime_session, name)
    if name in {"MeetingMemoryBridge", "deregister_bridge", "get_bridge", "register_bridge"}:
        from apps.backend.voice_services import meeting_memory_bridge

        return getattr(meeting_memory_bridge, name)
    raise AttributeError(name)


def _recall_observe_manifest() -> Any:
    from apps.backend.services.meeting.meeting_runtime_session import ProviderCapabilityManifest

    return ProviderCapabilityManifest(
        provider_id="recall_ai",
        supported_contracts=(MeetingParticipationContract.OBSERVE_JOIN,),
        bidirectional_audio=False,
        live_transcription=True,
        webhook_events=True,
    )


def _provider_summary_payload(
    *,
    state: ProviderState,
    missing_credentials: list[str] | None = None,
    last_error: str | None = None,
) -> dict[str, Any]:
    return {
        "state": state.value,
        "missing_credentials": list(missing_credentials or []),
        "last_error": last_error,
    }


def _disabled_meeting_provider_status_summary() -> dict[str, Any]:
    result: dict[str, Any] = {
        "recall_ai": _provider_summary_payload(state=ProviderState.DISABLED),
    }
    for provider in _SUPPLEMENTAL_MEETING_PROVIDERS:
        result[provider] = _provider_summary_payload(state=ProviderState.DISABLED)
    return result


# Frozen capture-mode preference order (docs/PRODUCT.md §Granola bar).
# Prefer least intrusive compliant capture edge: local/browser first when
# available, consented bot join when needed, upload fallback always.
CAPTURE_MODE_PREFERENCE_ORDER: tuple[str, ...] = (
    "browser_capture",  # Least intrusive — local capture, no bot join
    "direct_upload",  # Always available — user uploads after meeting
    "pre_meeting_brief",  # Always available — cited recall before meeting
)


def get_meeting_fallback_capture_contract() -> dict[str, Any]:
    """Return the canonical blocked-join fallback capture contract."""
    options = [
        {
            "mode": "browser_capture",
            "label": "Local browser capture",
            "description": "Meeting-local browser capture is not configured in the current product build.",
            "available": False,
            "endpoint": None,
            "href": None,
            "reason_code": "meeting_browser_capture_not_available",
        },
        {
            "mode": "direct_upload",
            "label": "Direct upload",
            "description": "Upload notes, a transcript, or a recording into durable memory after the meeting.",
            "available": True,
            "endpoint": "/api/v1/memory/import",
            "href": "/runtime/?surface=memory",
            "reason_code": None,
        },
        {
            "mode": "pre_meeting_brief",
            "label": "Pre-meeting brief",
            "description": "Pull cited historical recall before the meeting when automated join is blocked.",
            "available": True,
            "endpoint": "/api/v1/meetings/pre-meeting-brief",
            "href": "/settings?tab=meetings",
            "reason_code": None,
        },
    ]
    recommended_order = [item["mode"] for item in options if item.get("available")]
    return {
        "capture_ready": bool(recommended_order),
        "recommended_order": recommended_order,
        "supporting_surface": "/settings?tab=meetings",
        "options": options,
    }


def _to_float(value: Any) -> float:
    try:
        if value is None:
            return 0.0
        return float(value)
    except (TypeError, ValueError):
        return 0.0


def _extract_seconds(data: dict[str, Any], keys: tuple[str, ...]) -> float:
    for key in keys:
        seconds = _to_float(data.get(key))
        if seconds > 0:
            return seconds
    return 0.0


def _extract_direction(data: dict[str, Any]) -> str:
    raw = (
        str(data.get("direction") or data.get("call_direction") or data.get("meeting_direction") or "").strip().lower()
    )
    if raw in {"inbound", "outbound"}:
        return raw
    return ""


def _build_metering_idempotency_key(
    provider: str,
    metric_type: UsageMetricType,
    event_type: str,
    payload: dict[str, Any],
    *,
    bot_id: str = "",
    tenant_id: str = "",
    session_id: str = "",
) -> str | None:
    if (
        session_id
        and tenant_id
        and metric_type
        in {
            UsageMetricType.MEETING_MINUTES,
            UsageMetricType.MEETING_MINUTES_INBOUND,
            UsageMetricType.MEETING_MINUTES_OUTBOUND,
        }
    ):
        return f"meeting:{tenant_id}:{session_id}:{metric_type.value}"

    event_id = payload.get("event_id") or payload.get("id") or payload.get("webhook_id")
    if not event_id:
        data = payload.get("data")
        if isinstance(data, dict):
            event_id = data.get("event_id") or data.get("id")
    if event_id:
        return f"{provider}:{event_type}:{event_id}:{metric_type.value}"
    # Deterministic fallback for providers that omit event IDs.
    # Uses stable payload serialization + bot scope to dedupe retries safely.
    stable_payload = json.dumps(payload, sort_keys=True, separators=(",", ":"), default=str)
    digest = hashlib.sha256(stable_payload.encode("utf-8")).hexdigest()[:24]
    bot_scope = str(bot_id or "unknown").strip() or "unknown"
    return f"{provider}:{event_type}:{bot_scope}:{digest}:{metric_type.value}"


async def _record_provider_event_metering(
    tenant_id: str,
    provider: str,
    event_type: str,
    payload: dict[str, Any],
) -> bool:
    """Record provider event meters. Returns True if MEETING_MINUTES was metered."""
    data = payload.get("data") if isinstance(payload.get("data"), dict) else payload
    if not isinstance(data, dict):
        data = {}

    metric_events: list[tuple[UsageMetricType, float, str]] = []
    normalized_event = (event_type or "").strip().lower()

    # Meeting duration meters (Recall lifecycle completion events)
    if normalized_event in _DONE_EVENTS:
        duration_seconds = _extract_seconds(
            data,
            (
                "duration_seconds",
                "meeting_duration_seconds",
                "audio_duration_seconds",
                "call_duration_seconds",
            ),
        )
        duration_minutes = duration_seconds / 60 if duration_seconds > 0 else 0.0
        if duration_minutes > 0:
            metric_events.append((UsageMetricType.RECALL_AI_BOT_MINUTES, duration_minutes, "minutes"))
            direction = _extract_direction(data)
            if direction == "inbound":
                metric_events.append((UsageMetricType.MEETING_MINUTES_INBOUND, duration_minutes, "minutes"))
            elif direction == "outbound":
                metric_events.append((UsageMetricType.MEETING_MINUTES_OUTBOUND, duration_minutes, "minutes"))
            else:
                metric_events.append((UsageMetricType.MEETING_MINUTES, duration_minutes, "minutes"))

    # Transcript provider callback meters (transcript_* events)
    if "transcript" in normalized_event:
        transcript_seconds = _extract_seconds(
            data,
            (
                "transcript_seconds",
                "transcript_duration_seconds",
                "audio_seconds",
                "duration_seconds",
            ),
        )
        transcript_provider = (
            str(data.get("transcript_provider") or data.get("provider") or data.get("engine") or "").strip().lower()
        )

        if transcript_seconds > 0:
            if "sarvam" in transcript_provider:
                metric_events.append((UsageMetricType.TRANSCRIPT_SARVAM_SECONDS, transcript_seconds, "seconds"))
            elif "deepgram" in transcript_provider:
                metric_events.append((UsageMetricType.TRANSCRIPT_DEEPGRAM_SECONDS, transcript_seconds, "seconds"))
            else:
                metric_events.append((UsageMetricType.TRANSCRIPT_MINUTES, transcript_seconds / 60, "minutes"))

    if not metric_events:
        return False

    metering = MeteringService()
    bot_id = str(data.get("bot_id") or data.get("id") or "").strip()
    session_id = ""
    if bot_id:
        try:
            session_id = str(get_meeting_session_store().session_id_for_bot(provider, bot_id) or "").strip()
        except Exception:
            session_id = ""
    meeting_minutes_metered = False
    _MEETING_MINUTE_METRICS = {
        UsageMetricType.MEETING_MINUTES,
        UsageMetricType.MEETING_MINUTES_INBOUND,
        UsageMetricType.MEETING_MINUTES_OUTBOUND,
    }
    for metric_type, quantity, unit in metric_events:
        if quantity <= 0:
            continue
        idempotency_key = _build_metering_idempotency_key(
            provider,
            metric_type,
            event_type,
            payload,
            bot_id=bot_id,
            tenant_id=tenant_id,
            session_id=session_id,
        )
        metered = await metering.meter(
            tenant_id=tenant_id,
            metric=metric_type,
            quantity=quantity,
            unit=unit,
            idempotency_key=idempotency_key,
            metadata={
                "provider": provider,
                "event_type": normalized_event,
                "bot_id": bot_id,
                "session_id": session_id,
                "transcript_provider": str(data.get("transcript_provider") or "").strip().lower(),
            },
        )
        if metered and metric_type in _MEETING_MINUTE_METRICS:
            meeting_minutes_metered = True
        if not metered:
            logger.warning(
                "Provider event metering dropped after retries: tenant=%s provider=%s metric=%s event=%s",
                tenant_id,
                provider,
                metric_type.value,
                normalized_event,
            )
    return meeting_minutes_metered


async def apply_provider_event(provider: str, bot_id: str, event_type: str, payload: dict[str, Any]) -> str | None:
    """Apply provider event to durable meeting session store."""
    if not isinstance(payload, dict):
        payload = {}
    if not (provider or "").strip() or not (bot_id or "").strip():
        return None

    store = get_meeting_session_store()
    session_id = store.apply_provider_event(
        provider=provider,
        bot_id=bot_id,
        event_type=event_type,
    )
    if not session_id:
        return session_id
    session = None

    # L7.8: Record bot_joined_at when bot transitions to in_call/joining.
    # This timestamp is used by stop_meeting to compute accurate duration
    # instead of the earlier created_at (when bot was merely requested).
    normalized_event = str(event_type or "").strip().lower()
    if normalized_event in {"bot.status_change", "status_change"}:
        data = payload.get("data") if isinstance(payload.get("data"), dict) else payload
        status_info = data.get("status") if isinstance(data, dict) else None
        status_code = ""
        if isinstance(status_info, dict):
            status_code = str(status_info.get("code") or "").strip().lower()
        elif isinstance(status_info, str):
            status_code = status_info.strip().lower()
        if status_code in {"in_call", "joining", "in_waiting_room"}:
            try:
                store.update_session(session_id, bot_joined_at=datetime.now(UTC).isoformat())
            except Exception:
                logger.warning(
                    "Failed to record bot_joined_at on session=%s",
                    session_id,
                    exc_info=True,
                )

    try:
        session = store.get_session(session_id)
        runtime_session_snapshot = _runtime_session_snapshot_for_provider_event(
            (session or {}).get("runtime_session"),
            provider=provider,
            event_type=event_type,
            session_state=str((session or {}).get("state") or ""),
            payload=payload,
        )
        if runtime_session_snapshot is not None:
            updated_session = store.update_session(session_id, runtime_session=runtime_session_snapshot)
            if isinstance(updated_session, dict):
                session = {**(session or {}), **updated_session}
        tenant_id = str((session or {}).get("tenant_id") or "").strip()
        if tenant_id:
            meeting_metered = await _record_provider_event_metering(
                tenant_id=tenant_id,
                provider=provider,
                event_type=event_type,
                payload=payload,
            )
            # Flag session so stop_meeting knows the webhook already metered
            # meeting duration and should skip its wall-clock estimate.
            if meeting_metered:
                try:
                    store.update_session(session_id, metered_by_webhook=True)
                except Exception:
                    logger.warning(
                        "Failed to stamp metered_by_webhook on session=%s",
                        session_id,
                        exc_info=True,
                    )
    except Exception:
        logger.warning(
            "Provider event metering failed for provider=%s bot_id=%s event=%s",
            provider,
            bot_id,
            event_type,
            exc_info=True,
        )
    return session_id


def _meeting_store_unavailable_error() -> HTTPException:
    return meeting_store_unavailable_http_exception()


def _tenant_matches(session_tenant_id: str, actor_tenant_id: str) -> bool:
    if session_tenant_id == actor_tenant_id:
        return True
    normalized_actor = actor_tenant_id if actor_tenant_id.startswith("TENANT#") else f"TENANT#{actor_tenant_id}"
    return session_tenant_id == normalized_actor


def _provider_disabled(provider: str) -> bool:
    key = f"{provider.upper()}_DISABLED"
    return os.getenv(key, "").strip().lower() in {"1", "true", "yes"}


def _credential_value(name: str) -> str:
    return (os.getenv(name) or "").strip()


def _credential_is_missing(value: str) -> bool:
    normalized = (value or "").strip().lower()
    if not normalized:
        return True
    if normalized in _PLACEHOLDER_CREDENTIAL_VALUES:
        return True
    return normalized.startswith("__fill_me__")


def _missing_credentials(required_secrets: list[str]) -> list[str]:
    return [name for name in required_secrets if _credential_is_missing(_credential_value(name))]


def _meeting_runtime_enabled() -> bool:
    """Feature flag gate for meeting runtime endpoints."""
    raw = os.getenv("MEETING_RUNTIME_ENABLED", "true").strip().lower()
    return raw not in {"0", "false", "no"}


def _build_meeting_provider_status_summary(tenant_id: str) -> dict[str, Any]:
    """Build the canonical meeting-provider readiness snapshot."""
    if not _meeting_runtime_enabled():
        return _disabled_meeting_provider_status_summary()

    # Recall.ai uses regional keys resolved via region_router — not a flat env var
    recall_configured = _recall_provider_configured(tenant_id)
    recall_state = (
        ProviderState.CONFIGURED
        if recall_configured
        else ProviderState.DISABLED
        if _provider_disabled("recall_ai")
        else ProviderState.MISSING_CREDENTIALS
    )
    if _PROVIDER_ERRORS.get("recall_ai") and recall_configured:
        recall_state = ProviderState.DEGRADED

    result: dict[str, Any] = {
        "recall_ai": _provider_summary_payload(
            state=recall_state,
            missing_credentials=[] if recall_configured else ["RECALL_AI_API_KEY_*"],
            last_error=_PROVIDER_ERRORS.get("recall_ai"),
        ),
    }

    for provider, required in _SUPPLEMENTAL_MEETING_PROVIDERS.items():
        state, missing = _provider_state(provider, required)
        result[provider] = _provider_summary_payload(
            state=state,
            missing_credentials=missing,
            last_error=_PROVIDER_ERRORS.get(provider),
        )
    return result


def _meeting_provider_status_summary(tenant_id: str) -> dict[str, Any]:
    """Return the runtime-gated meeting-provider readiness snapshot."""
    _ensure_meeting_runtime_enabled()
    return _build_meeting_provider_status_summary(tenant_id)


def _ensure_meeting_runtime_enabled() -> None:
    if not _meeting_runtime_enabled():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "feature_disabled",
                "feature": "meeting_runtime",
                "next_action": "Set MEETING_RUNTIME_ENABLED=true to enable meeting runtime",
            },
        )


def _provider_state(provider: str, required_secrets: list[str]) -> tuple[ProviderState, list[str]]:
    if _provider_disabled(provider):
        return ProviderState.DISABLED, []

    missing = _missing_credentials(required_secrets)
    if missing:
        return ProviderState.MISSING_CREDENTIALS, missing

    if _PROVIDER_ERRORS.get(provider):
        return ProviderState.DEGRADED, []

    return ProviderState.CONFIGURED, []


def _recall_provider_configured(tenant_id: str) -> bool:
    """Check if Recall.ai credentials are resolvable for the tenant's region."""
    if _provider_disabled("recall_ai"):
        return False
    config = get_recall_config(tenant_id)
    api_key = resolve_recall_api_key(config["region"])
    return api_key is not None


def _get_recall_adapter(tenant_id: str) -> RecallAIMeetingAdapter:
    """Build a RecallAIMeetingAdapter for the tenant's region.

    Raises ValueError if the API key cannot be resolved (which callers
    convert to an HTTPException).
    """
    config = get_recall_config(tenant_id)
    return RecallAIMeetingAdapter(region=config["region"], tenant_id=tenant_id or None)


def _require_meeting_agent_principal(tenant_id: str) -> AgentOAuthPrincipal:
    try:
        return get_agent_oauth_principal_provisioning_service().ensure_meeting_principal(
            tenant_id=tenant_id,
            actor="meetings.join",
        )
    except AgentOAuthPrincipalUnavailableError as exc:
        raise _agent_identity_unavailable_error(str(exc)) from exc
    except ValueError as exc:
        raise _agent_identity_unavailable_error(str(exc)) from exc
    except Exception as exc:
        logger.error("Meeting agent principal unavailable for tenant=%s: %s", tenant_id, exc)
        raise _agent_identity_unavailable_error("Zara's dedicated meeting identity could not be loaded.") from exc


def _agent_identity_unavailable_error(message: str) -> HTTPException:
    reason = message or "Zara's dedicated meeting identity is unavailable."
    return HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail={
            "error": "agent_identity_unavailable",
            "message": reason,
            "identity_mode": IdentityMode.DENIED.value,
            "identity_reason": reason,
            "next_action": "Provision the tenant-scoped Zara agent identity before retrying the meeting join.",
        },
    )


def _agent_identity_signing_error(message: str) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail={
            "error": "agent_identity_signing_failed",
            "message": message or "Zara's meeting identity assertion could not be signed.",
            "next_action": "Retry after the tenant-scoped Zara signing identity is available.",
        },
    )


def _meeting_runtime_start_error(exc: Exception) -> HTTPException:
    from apps.backend.services.meeting.meeting_runtime_session import (
        AgentIdentityAssertionRequiredError,
        AgentPurposeMismatchError,
        MeetingRuntimeSessionError,
    )

    if isinstance(exc, AgentPurposeMismatchError):
        return HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "error": "agent_identity_purpose_mismatch",
                "message": str(exc) or "Zara's meeting identity is not scoped for meeting joins.",
                "next_action": "Reprovision the tenant-scoped Zara meeting identity before retrying.",
            },
        )
    if isinstance(exc, AgentIdentityAssertionRequiredError):
        return HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "agent_identity_assertion_required",
                "message": str(exc) or "Zara's meeting identity assertion is missing or invalid.",
                "next_action": "Retry after the tenant-scoped Zara meeting identity assertion is available.",
            },
        )
    if isinstance(exc, MeetingRuntimeSessionError):
        return HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "error": "meeting_runtime_session_start_failed",
                "message": str(exc) or "Zara's meeting runtime session could not start.",
                "next_action": "Fix the meeting runtime session contract error before retrying.",
            },
        )
    return HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail={
            "error": "meeting_runtime_session_unavailable",
            "message": "Zara's meeting runtime session could not start.",
            "next_action": "Retry after the meeting runtime service is available.",
        },
    )


def _provider_unconfigured_error(provider: str, required: list[str]) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail={
            "error": "provider_unconfigured",
            "provider": provider,
            "state": ProviderState.MISSING_CREDENTIALS.value,
            "required_secrets": required,
            "next_action": "Add provider credentials to environment or Secrets Manager",
        },
    )


def _blocked_tenant_error(status_value: str) -> HTTPException:
    normalized = str(status_value or "").strip().lower() or "unknown"
    next_action = {
        "pending_payment": "complete_billing",
        "suspended": "resolve_billing",
        "cancelled": "reactivate_subscription",
        "destroyed": "contact_support",
    }.get(normalized, "contact_support")
    return HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail={
            "error": "blocked_tenant",
            "tenant_status": normalized,
            "message": "Meeting joins are blocked for the current tenant status.",
            "next_action": next_action,
            "fallback_behavior": "deny_join_without_recording_or_transcription",
        },
    )


def _provider_error_message(exc: Exception) -> tuple[int | None, str]:
    if isinstance(exc, httpx.HTTPStatusError):
        response = exc.response
        detail_message = ""
        if response is not None:
            try:
                payload = response.json()
            except ValueError:
                payload = None
            if isinstance(payload, dict):
                detail_message = str(
                    payload.get("detail") or payload.get("message") or payload.get("error") or payload
                ).strip()
            if not detail_message:
                detail_message = (response.text or "").strip()
            return response.status_code, detail_message or str(exc)
    return None, str(exc)


def _provider_blocked_error(blocked: MeetingJoinBlockedError) -> HTTPException:
    normalized_message = str(blocked.message or "").strip() or "Meeting join is blocked by the provider."
    return HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail={
            "error": "provider_blocked",
            "provider": blocked.provider,
            "provider_status": blocked.status_code,
            "reason_code": blocked.reason_code,
            "message": normalized_message,
            "next_action": "open_meeting_capture_fallback",
            "fallback_behavior": "route_to_direct_upload_or_pre_meeting_brief",
            "fallback_capture": get_meeting_fallback_capture_contract(),
        },
    )


def _assert_meeting_join_allowed(tenant_id: str) -> None:
    tenant = get_tenant_provisioning_service().get_tenant(tenant_id)
    if tenant is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "tenant_not_found", "message": "Organization not found"},
        )

    status_value = str(tenant.get("status") or "").strip().lower()
    if status_value in {"pending_payment", "suspended", "cancelled", "destroyed"}:
        raise _blocked_tenant_error(status_value)


def _resolve_meeting_participation_mode(request: JoinMeetingRequest) -> MeetingParticipationMode:
    """Resolve the canonical meeting participation mode and fail on unsupported modes."""
    mode = request.participation_mode
    has_output_media = bool(str(request.output_media_url or "").strip())

    if mode == MeetingParticipationMode.SIGNED_IN_PARTICIPANT:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "signed_in_meeting_unsupported",
                "message": (
                    "Signed-in meeting participation is not available yet. "
                    "Use join_only or speak_via_output_media."
                ),
                "requested_mode": mode.value,
                "supported_modes": [
                    MeetingParticipationMode.JOIN_ONLY.value,
                    MeetingParticipationMode.SPEAK_VIA_OUTPUT_MEDIA.value,
                ],
            },
        )

    if mode == MeetingParticipationMode.SPEAK_VIA_OUTPUT_MEDIA and not has_output_media:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "output_media_url_required",
                "message": "speak_via_output_media requires output_media_url.",
                "requested_mode": mode.value,
            },
        )

    if has_output_media:
        return MeetingParticipationMode.SPEAK_VIA_OUTPUT_MEDIA
    return MeetingParticipationMode.JOIN_ONLY


def _capture_join_consent(
    *,
    tenant_id: str,
    session_id: str,
    request: JoinMeetingRequest,
    participation_mode: MeetingParticipationMode,
    agent_principal: AgentOAuthPrincipal,
) -> str:
    consent = request.consent
    bot_identity = agent_principal.to_bot_identity()
    if consent is None or not consent.confirmed:
        raise HTTPException(
            status_code=status.HTTP_428_PRECONDITION_REQUIRED,
            detail={
                "error": "consent_required",
                "message": "Explicit participant consent is required before meeting join.",
                "next_action": "Capture host consent and participant notification before retrying.",
                "approval_notice": agent_principal.approval_notice(),
                "bot_identity": bot_identity,
            },
        )
    if consent.recording_enabled and not consent.participants_notified:
        raise HTTPException(
            status_code=status.HTTP_428_PRECONDITION_REQUIRED,
            detail={
                "error": "participants_notified_required",
                "message": "Recording-enabled meeting joins require participant notification evidence.",
                "next_action": "Provide participants_notified before retrying.",
                "approval_notice": agent_principal.approval_notice(),
                "bot_identity": bot_identity,
            },
        )

    try:
        artifact = get_consent_manager().capture_consent(
            tenant_id=tenant_id,
            consent_type="meeting_join_recording",
            channel="voice_api",
            session_id=session_id,
            consented_by=(consent.consented_by or "").strip() or "host",
            consent_method=consent.consent_method,
            announcement_text=consent.announcement_text or agent_principal.approval_notice(),
            announcement_language=consent.announcement_language,
            participants_notified=consent.participants_notified,
            recording_enabled=consent.recording_enabled,
            metadata={
                "meeting_url": request.meeting_url,
                "bot_name": request.bot_name,
                "participation_mode": participation_mode.value,
                "bot_identity": bot_identity,
                "identity_provenance": bot_identity["provenance"],
            },
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Failed to capture meeting consent for tenant=%s session=%s: %s", tenant_id, session_id, exc)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "consent_store_unavailable",
                "message": "Consent could not be persisted. Meeting join denied.",
            },
        ) from exc

    return str(artifact.consent_id)


def _build_join_consent_artifact(
    *,
    consent_id: str,
    request: JoinMeetingRequest,
    agent_principal: AgentOAuthPrincipal,
) -> Any:
    from apps.backend.services.meeting.meeting_runtime_session import ConsentArtifact

    consent = request.consent
    consented_by = (str(consent.consented_by or "").strip() if consent else "") or "host"
    return ConsentArtifact(
        consent_id=consent_id,
        consent_type=_MEETING_CONSENT_CONSENT_TYPE,
        confirmed=bool(consent and consent.confirmed),
        consented_by=consented_by,
        participants_notified=tuple(consent.participants_notified if consent else ()),
    )


def _dynamodb_safe_runtime_snapshot(value: Any) -> Any:
    if isinstance(value, float):
        return Decimal(str(value))
    if isinstance(value, dict):
        return {str(key): _dynamodb_safe_runtime_snapshot(item) for key, item in value.items()}
    if isinstance(value, (list, tuple)):
        return [_dynamodb_safe_runtime_snapshot(item) for item in value]
    return value


def _meeting_runtime_session_store_snapshot(runtime_session: MeetingRuntimeSession) -> dict[str, Any]:
    return cast(dict[str, Any], _dynamodb_safe_runtime_snapshot(runtime_session.to_dict()))


def _stopped_runtime_session_snapshot(runtime_session: Any, *, reason: str) -> dict[str, Any] | None:
    if not isinstance(runtime_session, dict):
        return None
    snapshot = dict(runtime_session)
    snapshot["lifecycle_state"] = "ended"
    snapshot["stop_reason"] = reason
    return cast(dict[str, Any], _dynamodb_safe_runtime_snapshot(snapshot))


def _runtime_session_snapshot_for_provider_event(
    runtime_session: Any,
    *,
    provider: str,
    event_type: str,
    session_state: str = "",
    payload: dict[str, Any],
) -> dict[str, Any] | None:
    if not isinstance(runtime_session, dict):
        return None
    normalized_event = str(event_type or "").strip().lower()
    if not normalized_event:
        return None
    snapshot = dict(runtime_session)
    if normalized_event in _DONE_EVENTS:
        snapshot["lifecycle_state"] = "ended"
        snapshot["stop_reason"] = f"provider_event:{normalized_event}"
    elif normalized_event in _ACTIVE_EVENTS:
        current_lifecycle_state = str(snapshot.get("lifecycle_state") or "").strip().lower()
        current_session_state = str(session_state or "").strip().lower()
        if current_session_state not in {"stopped", "ended"} and current_lifecycle_state not in {
            "ended",
            "stopped",
        }:
            snapshot["lifecycle_state"] = "active"
    else:
        return None
    data = payload.get("data") if isinstance(payload.get("data"), dict) else payload
    event_id = payload.get("event_id") or payload.get("id") or payload.get("webhook_id")
    if not event_id and isinstance(data, dict):
        event_id = data.get("event_id") or data.get("id")
    snapshot["webhook_trust_state"] = {
        "provider": provider,
        "event_type": normalized_event,
        "event_id": str(event_id or "").strip() or None,
        "trusted": True,
        "updated_at": datetime.now(UTC).isoformat(),
    }
    return cast(dict[str, Any], _dynamodb_safe_runtime_snapshot(snapshot))


def _sign_meeting_identity_assertion(
    *,
    tenant_id: str,
    meeting_url: str,
    agent_principal: AgentOAuthPrincipal | AgentPrincipal,
) -> tuple[AgentPrincipal, Any, Any]:
    principal = adapt_legacy_oauth_principal(agent_principal)
    assertion_service = get_agent_identity_assertion_service()
    try:
        assertion = assertion_service.sign(
            principal=principal,
            meeting_url=meeting_url,
        )
    except AgentIdentityAssertionError as exc:
        logger.warning("Meeting identity assertion signing rejected for tenant=%s: %s", tenant_id, exc)
        raise _agent_identity_signing_error(str(exc)) from exc
    except Exception as exc:
        logger.error("Meeting identity assertion signing failed for tenant=%s: %s", tenant_id, exc)
        raise _agent_identity_signing_error("Zara's meeting identity assertion could not be signed.") from exc
    return principal, assertion, assertion_service


async def _build_and_start_meeting_runtime_session(
    *,
    tenant_id: str,
    session_id: str,
    request: JoinMeetingRequest,
    consent_id: str,
    participation_mode: MeetingParticipationMode,
    agent_principal: AgentOAuthPrincipal,
) -> MeetingRuntimeSession:
    from apps.backend.services.meeting.meeting_runtime_session import MeetingRuntimeSession
    from apps.backend.voice_services.meeting_memory_bridge import MeetingMemoryBridge, register_bridge

    principal, assertion, assertion_service = _sign_meeting_identity_assertion(
        tenant_id=tenant_id,
        meeting_url=request.meeting_url,
        agent_principal=agent_principal,
    )
    session = MeetingRuntimeSession(
        session_id=session_id,
        tenant_id=tenant_id,
        meeting_url=request.meeting_url,
        provider_manifest=_recall_observe_manifest(),
        mode=MeetingParticipationContract.OBSERVE_JOIN,
        consent=_build_join_consent_artifact(
            consent_id=consent_id,
            request=request,
            agent_principal=agent_principal,
        ),
        url_validation_result={"source": "meetings.join", "validated": True},
        live_tool_policy={
            "participation_mode": participation_mode.value,
            "active_speaking_claimed": False,
        },
        agent_principal=principal,
        identity_assertion=assertion,
        identity_assertion_service=assertion_service,
    )
    await session.start()

    # Wire MeetingMemoryBridge for long-session transcript paging
    bridge = MeetingMemoryBridge(
        tenant_id=tenant_id,
        meeting_session_id=session_id,
        context_window_size=int(os.environ.get("ZARA_CONTEXT_WINDOW_SIZE", "128000")),
    )
    try:
        await bridge.start(
            expected_duration_minutes=getattr(request, "expected_duration_minutes", None)
        )
        register_bridge(session_id, bridge)
    except Exception:
        logger.warning(
            "MeetingMemoryBridge failed to start for session=%s — proceeding without memory bridge",
            session_id,
            exc_info=True,
        )

    return session


def _serialize_meeting_consent_artifact(artifact: Any) -> dict[str, Any]:
    if hasattr(artifact, "model_dump"):
        raw = dict(artifact.model_dump(mode="json"))
    elif isinstance(artifact, dict):
        raw = dict(artifact)
    else:
        raw = {}
    participants_notified = list(raw.get("participants_notified") or [])
    return {
        "consent_id": str(raw.get("consent_id") or ""),
        "consent_type": str(raw.get("consent_type") or ""),
        "channel": str(raw.get("channel") or ""),
        "session_id": raw.get("session_id"),
        "consented_by": raw.get("consented_by"),
        "consented_at": str(raw.get("consented_at") or ""),
        "consent_method": raw.get("consent_method"),
        "announcement_language": raw.get("announcement_language"),
        "participants_notified": participants_notified,
        "participants_notified_count": len(participants_notified),
        "recording_enabled": bool(raw.get("recording_enabled", False)),
        "revoked_at": raw.get("revoked_at"),
        "revoked_by": raw.get("revoked_by"),
        "revocation_reason": raw.get("revocation_reason"),
        "metadata": dict(raw.get("metadata") or {}),
        "schema_version": raw.get("schema_version"),
    }


def get_meeting_consent_policy_summary(tenant_id: str, *, limit: int = 5) -> dict[str, Any]:
    """Return the fail-closed meeting consent policy plus recent artifact visibility."""
    policy = {
        "explicit_consent_required": True,
        "participant_notification_required_for_recording": True,
        "recording_enabled_default": True,
        "fail_closed": True,
        "consent_type": _MEETING_CONSENT_CONSENT_TYPE,
        "consent_channel": _MEETING_CONSENT_CHANNEL,
        "default_consent_method": _MEETING_CONSENT_DEFAULT_METHOD,
        "policy_errors": list(_MEETING_CONSENT_POLICY_ERRORS),
    }
    recent_consents: list[dict[str, Any]] = []
    recent_consents_available = True
    recent_consents_error: str | None = None

    try:
        consent_manager = get_consent_manager()
        artifacts = consent_manager.list_consents_by_type(
            tenant_id=tenant_id,
            consent_type=_MEETING_CONSENT_CONSENT_TYPE,
            limit=max(1, min(int(limit), 10)),
        )
        recent_consents = [_serialize_meeting_consent_artifact(artifact) for artifact in artifacts]
    except Exception as exc:
        recent_consents_available = False
        recent_consents_error = str(exc)
        logger.warning("Meeting consent summary unavailable for tenant=%s: %s", tenant_id, exc, exc_info=True)

    return {
        "tenant_id": tenant_id,
        "policy": policy,
        "recent_consents": recent_consents,
        "recent_consents_available": recent_consents_available,
        "recent_consents_error": recent_consents_error,
        "providers": _build_meeting_provider_status_summary(tenant_id),
        "fallback_capture": get_meeting_fallback_capture_contract(),
    }


async def _recall_create_bot(
    request: JoinMeetingRequest,
    tenant_id: str = "",
    *,
    agent_principal: AgentOAuthPrincipal | AgentPrincipal,
    runtime_session: MeetingRuntimeSession | None = None,
) -> str:
    """Create a Recall.ai bot via the RecallAIMeetingAdapter.

    Args:
        request: Meeting join request with URL and bot configuration.
        tenant_id: Tenant ID for region routing. Falls back to default (us-west-2).
    """
    try:
        adapter = _get_recall_adapter(tenant_id)
    except ValueError:
        raise _provider_unconfigured_error("recall_ai", ["RECALL_AI_API_KEY_*"])

    # Pre-flight: adapter must declare a join-capable contract.
    # POST_MEETING adapters (transcript retrieval only) must never be used for live join.
    _JOIN_CAPABLE_CONTRACTS = {
        MeetingParticipationContract.OBSERVE_JOIN,
        MeetingParticipationContract.AUTHENTICATED_JOIN,
        MeetingParticipationContract.ACTIVE_SPEAKING,
    }
    if adapter.participation_contract not in _JOIN_CAPABLE_CONTRACTS:
        raise MeetingJoinBlockedError(
            provider=getattr(adapter, "_provider_name", "recall_ai"),
            status_code=None,
            reason_code="provider_blocked",
            message=(
                f"Provider contract '{adapter.participation_contract.value}' does not support "
                "active meeting join. A join-capable contract (observe_join, authenticated_join, "
                "or active_speaking) is required."
            ),
        )

    if runtime_session is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "meeting_runtime_session_required",
                "message": "Recall bot dispatch requires a started MeetingRuntimeSession.",
            },
        )
    runtime_session.verify_identity_assertion()
    bot_identity = agent_principal.to_bot_identity()
    new_principal = runtime_session.agent_principal
    assertion = runtime_session.identity_assertion
    if new_principal is None or assertion is None:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "meeting_runtime_session_identity_missing",
                "message": "MeetingRuntimeSession is missing its signed agent identity assertion.",
            },
        )
    runtime_snapshot = runtime_session.to_dict()
    extra_config: dict[str, Any] = {
        "bot_name": request.bot_name,
        "metadata": {
            "workweaver_bot_identity": json.dumps(bot_identity, sort_keys=True, separators=(",", ":"), default=str),
            "worker_identity_public_key": str(agent_principal.worker_identity.public_key),
            "tenant_id": str(tenant_id),
            "agent_principal_email": str(agent_principal.email),
            "identity_assertion": assertion.to_b64(),
            "meeting_runtime_session_id": runtime_session.session_id,
            "meeting_runtime_lifecycle_state": runtime_session.lifecycle_state.value,
            "meeting_runtime_contract": runtime_session.mode.value,
            "meeting_runtime_provider": runtime_session.provider_manifest.provider_id,
        },
    }
    extra_config["runtime_session"] = runtime_snapshot
    if request.output_media_url:
        extra_config["output_media"] = {
            "camera": {
                "kind": "webpage",
                "config": {"url": request.output_media_url},
            }
        }

    try:
        bot_id = await adapter.join_with_identity(
            meeting_url=request.meeting_url,
            agent_principal=new_principal,
            identity_assertion=assertion,
            extra_config=extra_config,
        )
    except MeetingJoinBlockedError:
        raise
    except Exception as exc:
        _provider_status, provider_message = _provider_error_message(exc)
        detail = f"Recall create bot failed: {provider_message}"
        _PROVIDER_ERRORS["recall_ai"] = detail
        logger.error(detail)
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail={"error": "provider_error", "provider": "recall_ai", "message": detail},
        ) from exc

    _PROVIDER_ERRORS.pop("recall_ai", None)
    if not bot_id:
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail={"error": "provider_error", "provider": "recall_ai", "message": "Missing bot id in response"},
        )
    return bot_id


async def _recall_leave_bot(bot_id: str, tenant_id: str = "") -> None:
    """Leave a Recall.ai meeting via the RecallAIMeetingAdapter."""
    try:
        adapter = _get_recall_adapter(tenant_id)
    except ValueError:
        raise _provider_unconfigured_error("recall_ai", ["RECALL_AI_API_KEY_*"])

    try:
        await adapter.leave(bot_id)
    except Exception as exc:
        detail = f"Recall leave bot failed: {exc}"
        _PROVIDER_ERRORS["recall_ai"] = detail
        logger.error(detail)
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail={"error": "provider_error", "provider": "recall_ai", "message": detail},
        ) from exc

    _PROVIDER_ERRORS.pop("recall_ai", None)


@router.get("/providers/status")
async def get_provider_status(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Get capability state for configured meeting runtime providers."""
    return _meeting_provider_status_summary(tenant_id)


def _persist_blocked_join_session(
    *,
    tenant_id: str,
    session_id: str,
    consent_id: str,
    request: JoinMeetingRequest,
    participation_mode: MeetingParticipationMode,
    bot_identity: dict[str, Any],
    blocked: MeetingJoinBlockedError,
    runtime_session: MeetingRuntimeSession | None = None,
) -> dict[str, Any]:
    now = datetime.now(UTC).isoformat()
    record = {
        "session_id": session_id,
        "tenant_id": tenant_id,
        "provider": blocked.provider,
        "state": "fallback_capture_pending",
        "meeting_url": request.meeting_url,
        "bot_name": request.bot_name,
        "bot_identity": bot_identity,
        "participation_mode": participation_mode.value,
        "identity_mode": IdentityMode.ZARA_OWNED.value,
        "identity_reason": "Meeting join uses Zara's tenant-scoped meeting identity and signed assertion.",
        "created_at": now,
        "updated_at": now,
        "consent_id": consent_id,
        "attendees": request.attendees,
        "reason_code": blocked.reason_code,
        "provider_status": blocked.status_code,
        "provider_message": blocked.message,
        "fallback_capture": get_meeting_fallback_capture_contract(),
    }
    if runtime_session is not None:
        record["runtime_session"] = _meeting_runtime_session_store_snapshot(runtime_session)
    if request.booking_context:
        record["booking_context"] = request.booking_context
    if request.lead_context:
        record["lead_context"] = request.lead_context
    try:
        return get_meeting_session_store().create_session(record)
    except MeetingSessionStoreError as exc:
        logger.error("Meeting store unavailable while persisting blocked join: %s", exc)
        raise _meeting_store_unavailable_error() from exc


@router.post("/join", response_model=JoinMeetingResponse)
async def join_meeting(
    request: JoinMeetingRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> JoinMeetingResponse:
    """Join an external meeting using Recall.ai provider."""
    _ensure_meeting_runtime_enabled()
    _assert_meeting_join_allowed(tenant_id)
    participation_mode = _resolve_meeting_participation_mode(request)
    if _provider_disabled("recall_ai"):
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "provider_disabled",
                "provider": "recall_ai",
                "state": ProviderState.DISABLED.value,
                "next_action": "Enable provider by clearing RECALL_AI_DISABLED",
            },
        )
    if not _recall_provider_configured(tenant_id):
        raise _provider_unconfigured_error("recall_ai", ["RECALL_AI_API_KEY_*"])

    agent_principal = _require_meeting_agent_principal(tenant_id)
    bot_identity = agent_principal.to_bot_identity()
    session_id = f"mtg_{ulid.new().str.lower()}"
    consent_id = _capture_join_consent(
        tenant_id=tenant_id,
        session_id=session_id,
        request=request,
        participation_mode=participation_mode,
        agent_principal=agent_principal,
    )
    try:
        runtime_session = await _build_and_start_meeting_runtime_session(
            tenant_id=tenant_id,
            session_id=session_id,
            request=request,
            consent_id=consent_id,
            participation_mode=participation_mode,
            agent_principal=agent_principal,
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.warning(
            "Meeting runtime session failed to start for tenant=%s session=%s: %s",
            tenant_id,
            session_id,
            exc,
            exc_info=True,
        )
        raise _meeting_runtime_start_error(exc) from exc
    try:
        bot_id = await _recall_create_bot(
            request,
            tenant_id=tenant_id,
            agent_principal=agent_principal,
            runtime_session=runtime_session,
        )
    except MeetingJoinBlockedError as blocked:
        blocked_record = _persist_blocked_join_session(
            tenant_id=tenant_id,
            session_id=session_id,
            consent_id=consent_id,
            request=request,
            participation_mode=participation_mode,
            bot_identity=bot_identity,
            blocked=blocked,
            runtime_session=runtime_session,
        )
        blocked_error = _provider_blocked_error(blocked)
        blocked_detail = cast(dict[str, Any], blocked_error.detail)
        blocked_detail["session_id"] = blocked_record["session_id"]
        blocked_detail["state"] = blocked_record["state"]
        raise blocked_error from blocked
    now = datetime.now(UTC).isoformat()
    runtime_session_response = runtime_session.to_dict()
    runtime_session_response["provider_session_id"] = bot_id
    record = {
        "session_id": session_id,
        "tenant_id": tenant_id,
        "provider": "recall_ai",
        "state": "active",
        "bot_id": bot_id,
        "meeting_url": request.meeting_url,
        "bot_name": request.bot_name,
        "bot_identity": bot_identity,
        "participation_mode": participation_mode.value,
        "created_at": now,
        "updated_at": now,
        "consent_id": consent_id,
        "attendees": request.attendees,
        "runtime_session": cast(dict[str, Any], _dynamodb_safe_runtime_snapshot(runtime_session_response)),
    }
    if request.booking_context:
        record["booking_context"] = request.booking_context
    if request.lead_context:
        record["lead_context"] = request.lead_context
    try:
        store = get_meeting_session_store()
        stored_record = store.create_session(record)
    except MeetingSessionStoreError as exc:
        logger.error("Meeting store unavailable while creating session: %s", exc)
        raise _meeting_store_unavailable_error() from exc

    # NOTE: zero-quantity join meter removed (L7.7) — it created useless records.
    # Duration is metered at stop or via Recall webhook (whichever fires first).

    return JoinMeetingResponse(
        session_id=session_id,
        provider=stored_record["provider"],
        state=stored_record["state"],
        participation_mode=stored_record.get("participation_mode", MeetingParticipationMode.JOIN_ONLY.value),
        identity_mode=IdentityMode.ZARA_OWNED,
        identity_reason=stored_record.get("identity_reason"),
        bot_id=stored_record.get("bot_id"),
        bot_identity=stored_record.get("bot_identity"),
        created_at=stored_record["created_at"],
        consent_id=stored_record.get("consent_id"),
        runtime_session=runtime_session_response,
    )


@router.post("/pre-meeting-brief", response_model=PreMeetingBriefResponse)
async def build_pre_meeting_brief(
    request: PreMeetingBriefRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PreMeetingBriefResponse:
    """Build a sourced brief for an upcoming meeting over historical memory."""
    brief = await get_sourced_recall_service().build_pre_meeting_brief(
        tenant_id=tenant_id,
        title=request.title,
        participants=request.participants,
        scheduled_for=request.scheduled_for,
        agenda=request.agenda,
        limit=5,
    )
    return PreMeetingBriefResponse(**brief)


@router.get("/{session_id}/status", response_model=MeetingStatusResponse)
async def get_meeting_status(
    session_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> MeetingStatusResponse:
    """Get current status of a meeting session."""
    _ensure_meeting_runtime_enabled()
    try:
        store = get_meeting_session_store()
        session = store.get_session(session_id)
    except MeetingSessionStoreError as exc:
        logger.error("Meeting store unavailable while reading session: %s", exc)
        raise _meeting_store_unavailable_error() from exc

    if not session or not _tenant_matches(str(session.get("tenant_id") or ""), tenant_id):
        raise HTTPException(status_code=404, detail="meeting_session_not_found")
    return MeetingStatusResponse(**session)


@router.post("/{session_id}/stop", response_model=MeetingStatusResponse)
async def stop_meeting(
    session_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> MeetingStatusResponse:
    """Stop a running meeting session."""
    _ensure_meeting_runtime_enabled()
    try:
        store = get_meeting_session_store()
        session = store.get_session(session_id)
    except MeetingSessionStoreError as exc:
        logger.error("Meeting store unavailable while reading session for stop: %s", exc)
        raise _meeting_store_unavailable_error() from exc

    if not session or not _tenant_matches(str(session.get("tenant_id") or ""), tenant_id):
        raise HTTPException(status_code=404, detail="meeting_session_not_found")

    bot_id = str(session.get("bot_id") or "").strip()
    if bot_id:
        await _recall_leave_bot(bot_id, tenant_id=tenant_id)

    try:
        updates: dict[str, Any] = {"state": "stopped"}
        runtime_session_snapshot = _stopped_runtime_session_snapshot(
            session.get("runtime_session"),
            reason="manual_stop",
        )
        if runtime_session_snapshot is not None:
            updates["runtime_session"] = runtime_session_snapshot
        updated = store.update_session(session_id, **updates)
    except MeetingSessionStoreError as exc:
        logger.error("Meeting store unavailable while updating stopped state: %s", exc)
        raise _meeting_store_unavailable_error() from exc
    if not updated:
        raise HTTPException(status_code=404, detail="meeting_session_not_found")

    # Meter wall-clock meeting duration, but only if the Recall webhook has
    # not already recorded actual provider-reported duration.  Both paths use
    # the same idempotency key pattern so DynamoDB deduplicates, but skipping
    # the stop estimate when the webhook already fired avoids a misleading
    # wall-clock record that would overcount.  (L7.7 fix)
    try:
        webhook_already_metered = bool(session.get("metered_by_webhook"))
        if not webhook_already_metered:
            duration_minutes = 1  # Default minimum
            # L7.8: Prefer bot_joined_at (actual join time from Recall webhook)
            # over created_at (when the bot was merely requested).
            start_iso = str(session.get("bot_joined_at") or "").strip()
            if not start_iso:
                start_iso = str(session.get("created_at") or "").strip()
            if start_iso:
                start_dt = datetime.fromisoformat(start_iso.replace("Z", "+00:00"))
                elapsed = (datetime.now(UTC) - start_dt).total_seconds()
                duration_minutes = max(1, round(elapsed / 60))
            metered = await MeteringService().meter(
                tenant_id=tenant_id,
                metric=UsageMetricType.MEETING_MINUTES,
                quantity=duration_minutes,
                unit="minutes",
                idempotency_key=f"meeting:{tenant_id}:{session_id}:{UsageMetricType.MEETING_MINUTES.value}",
                metadata={"provider": "recall_ai", "action": "stop", "bot_id": bot_id},
            )
            if not metered:
                logger.warning("Meeting stop metering dropped after retries for tenant=%s", tenant_id)
        else:
            logger.info(
                "Meeting stop metering skipped — webhook already recorded duration for tenant=%s session=%s",
                tenant_id,
                session_id,
            )
    except Exception:
        logger.warning("Meeting stop metering failed for tenant=%s", tenant_id, exc_info=True)

    # End the memory bridge and emit evidence:meeting_session_concluded
    from apps.backend.voice_services.meeting_memory_bridge import deregister_bridge, get_bridge

    bridge = get_bridge(session_id)
    if bridge is not None:
        try:
            await bridge.end()
        except Exception:
            logger.warning(
                "MeetingMemoryBridge.end() failed for session=%s",
                session_id,
                exc_info=True,
            )
        finally:
            deregister_bridge(session_id)

    return MeetingStatusResponse(**updated)


@router.get("/active")
async def list_active_meetings(
    tenant_id: str = Depends(get_verified_tenant_id),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> dict[str, Any]:
    """List active sessions for tenant."""
    _ensure_meeting_runtime_enabled()
    try:
        store = get_meeting_session_store()
        sessions = store.list_sessions(
            tenant_id=tenant_id,
            state="active",
            limit=paginate_limit(200, pagination),
        )
    except MeetingSessionStoreError as exc:
        logger.error("Meeting store unavailable while listing active sessions: %s", exc)
        raise _meeting_store_unavailable_error() from exc
    paged_sessions, _total = paginate_items(sessions, pagination)
    return {"tenant_id": tenant_id, "sessions": paged_sessions, "count": len(paged_sessions)}


@router.get("/history")
async def list_meeting_history(
    tenant_id: str = Depends(get_verified_tenant_id),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> dict[str, Any]:
    """List recent meeting sessions for tenant."""
    _ensure_meeting_runtime_enabled()
    try:
        store = get_meeting_session_store()
        sessions = store.list_sessions(
            tenant_id=tenant_id,
            limit=paginate_limit(200, pagination),
        )
    except MeetingSessionStoreError as exc:
        logger.error("Meeting store unavailable while listing history: %s", exc)
        raise _meeting_store_unavailable_error() from exc
    paged_sessions, _total = paginate_items(sessions, pagination)
    return {"tenant_id": tenant_id, "sessions": paged_sessions, "count": len(paged_sessions)}


@router.get("/{session_id}/transcript")
async def get_session_transcript(
    session_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return transcript state for a meeting session.

    Issue #1159: callers must distinguish "no transcript engine configured"
    from real transcript content. Response always carries ``real_transcript``
    (bool) and ``status``; when no provider is configured, a concrete
    ``missing_provider_env`` list tells operators which secret to set.
    Nothing is ever surfaced as a placeholder disguised as real content.
    """
    _ensure_meeting_runtime_enabled()
    return await get_shared_meeting_service().get_transcript_state(
        tenant_id=tenant_id,
        session_id=session_id,
    )
