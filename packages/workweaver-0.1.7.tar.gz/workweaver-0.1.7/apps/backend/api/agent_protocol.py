"""Agent Protocol REST API -- Scoped External Communication.

Prefix: /api/v1/agents/protocol
Auth: API key via Bearer ww_sk_* token or X-Tenant-Id (dev mode).

CRITICAL: External parties interact ONLY through scoped agents.
The legacy /query endpoint is preserved for backward-compatible internal use.

New endpoints:
- POST /scopes -- create a scoped communication context
- POST /sessions -- start a bidirectional communication session
- POST /sessions/{session_id}/exchange -- send/receive a message
- POST /sessions/{session_id}/complete -- complete a session
- POST /delegate -- AI agent delegates communication to a scoped agent
"""

from __future__ import annotations

import logging
from dataclasses import asdict
from typing import Any

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.plugin_auth import get_plugin_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/agents/protocol", tags=["agent-protocol"])


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


# -- Legacy models (backward compatible) -----------------------------------

class AgentQueryRequest(BaseModel):
    """Request body for querying an agent (legacy)."""

    agent_id: str = Field("zara", max_length=100, description="Target agent ID")
    question: str = Field(..., min_length=1, max_length=5000, description="Question text")
    caller_id: str = Field("external", max_length=100, description="Caller identity")
    context: dict[str, Any] | None = Field(None, description="Optional query context")


class AgentQueryResponse(BaseModel):
    """Structured response from an agent query."""

    message_id: str
    agent_id: str
    answer: str
    sources: list[dict[str, Any]] = Field(default_factory=list)
    confidence: float = 0.0
    suggested_followups: list[str] = Field(default_factory=list)


class MessageListResponse(BaseModel):
    """Response for listing recent agent messages."""

    tenant_id: str
    messages: list[dict[str, Any]] = Field(default_factory=list)
    count: int = 0


# -- Scoped communication models ------------------------------------------

class CreateScopeRequest(BaseModel):
    """Request body for creating a communication scope."""

    agent_id: str = Field(..., max_length=100, description="Agent designated for communication")
    allowed_topics: list[str] = Field(..., min_length=1, description="Topics this agent can discuss")
    allowed_data_sources: list[str] | None = Field(None, description="Data sources (crm, calendar, etc.)")
    allowed_tools: list[str] | None = Field(None, description="Tools the agent can use")
    blocked_topics: list[str] | None = Field(None, description="Explicitly blocked topics")
    context_documents: list[str] | None = Field(None, description="Pre-loaded context documents")
    max_iterations: int = Field(50, ge=1, le=500, description="Max back-and-forth exchanges")
    expires_at: str | None = Field(None, description="ISO 8601 expiry timestamp")
    created_by: str = Field("user", max_length=100, description="Who created this scope")


class ScopeResponse(BaseModel):
    """Response after creating a communication scope."""

    scope_id: str
    agent_id: str
    tenant_id: str
    allowed_topics: list[str]
    allowed_data_sources: list[str] | None = None
    blocked_topics: list[str] = Field(default_factory=list)
    max_iterations: int = 50
    created_by: str = "user"


class StartSessionRequest(BaseModel):
    """Request body for starting a communication session."""

    scope_id: str = Field(..., description="Scope ID to bind this session to")
    external_party_id: str = Field(..., max_length=200, description="External party identity")


class SessionResponse(BaseModel):
    """Response for session operations."""

    session_id: str
    scope_id: str
    state: str
    external_party_id: str
    iterations: int = 0
    calendar_block_id: str | None = None


class ExchangeRequest(BaseModel):
    """Request body for a message exchange."""

    message: str = Field(..., min_length=1, max_length=10000, description="Message content")
    sender: str = Field("external", max_length=100, description="Who is sending")


class SessionCompleteResponse(BaseModel):
    """Response after completing a session."""

    state: str
    summary: str
    action_items: list[str] = Field(default_factory=list)
    iterations: int = 0


class DelegateRequest(BaseModel):
    """Request body for delegating a communication task."""

    delegator_agent_id: str = Field(..., max_length=100, description="Agent delegating the task")
    target_agent_id: str = Field(..., max_length=100, description="Agent to handle communication")
    task_description: str = Field(..., max_length=2000, description="What to communicate")
    external_party: str = Field(..., max_length=200, description="External party identity")
    scope_config: dict[str, Any] = Field(..., description="Scope configuration")


# ---------------------------------------------------------------------------
# Service accessor (lazy import)
# ---------------------------------------------------------------------------


def _get_service():  # noqa: ANN201
    from apps.backend.services.agent_protocol import get_agent_protocol_service

    return get_agent_protocol_service()


# ---------------------------------------------------------------------------
# Legacy endpoints (backward compatible)
# ---------------------------------------------------------------------------


@router.post(
    "/query",
    response_model=AgentQueryResponse,
    summary="Query a Workweaver agent (legacy, internal use)",
)
async def query_agent(
    body: AgentQueryRequest,
    tenant_id: str = Depends(get_plugin_tenant_id),
) -> AgentQueryResponse:
    """Query a Workweaver agent -- legacy internal endpoint.

    For external communication, use the scoped communication endpoints.
    """
    service = _get_service()
    response = await service.query_agent(
        tenant_id=tenant_id,
        agent_id=body.agent_id,
        question=body.question,
        caller_id=body.caller_id,
        context=body.context,
    )
    return AgentQueryResponse(
        message_id=response.message_id,
        agent_id=response.agent_id,
        answer=response.answer,
        sources=response.sources,
        confidence=response.confidence,
        suggested_followups=response.suggested_followups,
    )


@router.get(
    "/messages",
    response_model=MessageListResponse,
    summary="List recent agent-to-agent messages",
)
async def list_messages(
    tenant_id: str = Depends(get_plugin_tenant_id),
    limit: int = Query(20, ge=1, le=200, description="Max results"),
) -> MessageListResponse:
    """List recent agent-to-agent messages for the authenticated tenant."""
    service = _get_service()
    messages = service.get_message_log(tenant_id=tenant_id, limit=limit)
    return MessageListResponse(
        tenant_id=tenant_id,
        messages=[asdict(m) for m in messages],
        count=len(messages),
    )


# ---------------------------------------------------------------------------
# Scoped communication endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/scopes",
    response_model=ScopeResponse,
    summary="Create a scoped communication context for an agent",
)
async def create_scope(
    body: CreateScopeRequest,
    tenant_id: str = Depends(get_plugin_tenant_id),
) -> ScopeResponse:
    """Create a scoped communication context.

    Defines what topics, data sources, and tools an agent can access
    when communicating with external parties.
    """
    service = _get_service()
    scope = service.create_communication_scope(
        tenant_id=tenant_id,
        agent_id=body.agent_id,
        allowed_topics=body.allowed_topics,
        allowed_data_sources=body.allowed_data_sources,
        allowed_tools=body.allowed_tools,
        blocked_topics=body.blocked_topics,
        context_documents=body.context_documents,
        max_iterations=body.max_iterations,
        expires_at=body.expires_at,
        created_by=body.created_by,
    )
    return ScopeResponse(
        scope_id=scope.scope_id,
        agent_id=scope.agent_id,
        tenant_id=scope.tenant_id,
        allowed_topics=scope.allowed_topics,
        allowed_data_sources=scope.allowed_data_sources,
        blocked_topics=scope.blocked_topics,
        max_iterations=scope.max_iterations,
        created_by=scope.created_by,
    )


@router.post(
    "/sessions",
    response_model=SessionResponse,
    summary="Start a bidirectional communication session",
)
async def start_session(
    body: StartSessionRequest,
    tenant_id: str = Depends(get_plugin_tenant_id),
) -> SessionResponse:
    """Start a bidirectional communication session within a scope.

    Creates a TimeBlock in mission calendar.
    """
    service = _get_service()
    session = service.start_session(
        scope_id=body.scope_id,
        external_party_id=body.external_party_id,
    )
    return SessionResponse(
        session_id=session.session_id,
        scope_id=session.scope.scope_id,
        state=session.state,
        external_party_id=session.external_party_id,
        iterations=session.iterations,
        calendar_block_id=session.calendar_block_id,
    )


@router.post(
    "/sessions/{session_id}/exchange",
    response_model=AgentQueryResponse,
    summary="Send/receive a message in a communication session",
)
async def exchange_message(
    session_id: str,
    body: ExchangeRequest,
    tenant_id: str = Depends(get_plugin_tenant_id),
) -> AgentQueryResponse:
    """Send a message in a communication session and get a response.

    The agent responds within scope boundaries. Blocked topics are rejected.
    """
    service = _get_service()
    response = await service.exchange(
        session_id=session_id,
        message=body.message,
        sender=body.sender,
    )
    return AgentQueryResponse(
        message_id=response.message_id,
        agent_id=response.agent_id,
        answer=response.answer,
        sources=response.sources,
        confidence=response.confidence,
        suggested_followups=response.suggested_followups,
    )


@router.post(
    "/sessions/{session_id}/complete",
    response_model=SessionCompleteResponse,
    summary="Complete a session with auto-summary",
)
async def complete_session(
    session_id: str,
    tenant_id: str = Depends(get_plugin_tenant_id),
) -> SessionCompleteResponse:
    """Complete a communication session.

    Auto-generates summary and action items. Updates the TimeBlock.
    """
    service = _get_service()
    result = service.complete_session(session_id)
    return SessionCompleteResponse(
        state=result["state"],
        summary=result["summary"],
        action_items=result["action_items"],
        iterations=result.get("iterations", 0),
    )


@router.post(
    "/delegate",
    response_model=SessionResponse,
    summary="AI agent delegates a communication task to a scoped agent",
)
async def delegate_communication(
    body: DelegateRequest,
    tenant_id: str = Depends(get_plugin_tenant_id),
) -> SessionResponse:
    """AI CEO or any agent delegates a communication task.

    Creates a scoped agent, starts a session, and appears in calendar.
    """
    service = _get_service()
    session = await service.delegate_communication(
        tenant_id=tenant_id,
        delegator_agent_id=body.delegator_agent_id,
        target_agent_id=body.target_agent_id,
        task_description=body.task_description,
        external_party=body.external_party,
        scope_config=body.scope_config,
    )
    return SessionResponse(
        session_id=session.session_id,
        scope_id=session.scope.scope_id,
        state=session.state,
        external_party_id=session.external_party_id,
        iterations=session.iterations,
        calendar_block_id=session.calendar_block_id,
    )
