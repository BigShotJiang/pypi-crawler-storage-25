"""Entity Autonomy API — per-entity autonomy slider.

Endpoint:
    PATCH /api/v1/entities/{entity_id}/autonomy  — set autonomy level 1-5

Autonomy levels:
    1 = Full Oversight   — approve every action
    2 = Read Auto        — read-only auto-approved
    3 = Low Risk Auto    — read, create_draft, research auto-approved
    4 = Medium Risk Auto — + send_email, update_crm auto-approved
    5 = Full Autopilot   — all actions auto-approved

Changes take effect at the next task boundary (next check_before_tool_call).

Entity autonomy contract: per-entity approval rules.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.autonomy_store import AUTONOMY_LEVELS, get_autonomy_store

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities", tags=["autonomy"])


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class AutonomyUpdateRequest(BaseModel):
    """Request body for updating an entity's autonomy level."""

    level: int = Field(..., ge=1, le=5, description="Autonomy level 1-5")


class AutonomyLevelDetail(BaseModel):
    """Detail block for a single autonomy level."""

    level: int
    name: str
    description: str


class AutonomyUpdateResponse(BaseModel):
    """Response after updating an entity's autonomy level."""

    entity_id: str
    tenant_id: str
    level: int
    level_name: str
    level_description: str
    message: str


class AutonomyGetResponse(BaseModel):
    """Response for reading an entity's current autonomy level."""

    entity_id: str
    tenant_id: str
    level: int
    level_name: str
    level_description: str
    is_default: bool


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.patch(
    "/{entity_id}/autonomy",
    response_model=AutonomyUpdateResponse,
    status_code=status.HTTP_200_OK,
)
async def update_entity_autonomy(
    entity_id: str,
    body: AutonomyUpdateRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> AutonomyUpdateResponse:
    """Set the autonomy level for a specific entity.

    Validates level 1-5 and persists to DynamoDB. Takes effect at the next
    task boundary (next InterruptEnforcer.check_before_tool_call invocation).
    """
    store = get_autonomy_store()
    try:
        store.set_entity_autonomy(tenant_id, entity_id, body.level)
    except ValueError as exc:
        logger.error("Invalid autonomy level: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid request parameters",
        ) from exc

    level_config = AUTONOMY_LEVELS[body.level]
    logger.info(
        "Updated autonomy for entity %s tenant %s to level %d (%s)",
        entity_id,
        tenant_id,
        body.level,
        level_config["name"],
    )
    return AutonomyUpdateResponse(
        entity_id=entity_id,
        tenant_id=tenant_id,
        level=body.level,
        level_name=level_config["name"],
        level_description=level_config["description"],
        message=(
            f"Autonomy level updated to {body.level} ({level_config['name']}). Takes effect at the next task boundary."
        ),
    )


@router.get(
    "/{entity_id}/autonomy",
    response_model=AutonomyGetResponse,
    status_code=status.HTTP_200_OK,
)
async def get_entity_autonomy(
    entity_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> AutonomyGetResponse:
    """Get the current autonomy level for a specific entity."""
    from apps.backend.services.autonomy_store import DEFAULT_AUTONOMY_LEVEL

    store = get_autonomy_store()
    stored_level = store.get_entity_autonomy(tenant_id, entity_id)
    is_default = stored_level is None
    level = stored_level if stored_level is not None else DEFAULT_AUTONOMY_LEVEL

    level_config = AUTONOMY_LEVELS[level]
    return AutonomyGetResponse(
        entity_id=entity_id,
        tenant_id=tenant_id,
        level=level,
        level_name=level_config["name"],
        level_description=level_config["description"],
        is_default=is_default,
    )


@router.get(
    "/autonomy/levels",
    response_model=list[AutonomyLevelDetail],
    status_code=status.HTTP_200_OK,
)
async def list_autonomy_levels(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[AutonomyLevelDetail]:
    """Return all 5 autonomy level definitions."""
    return [
        AutonomyLevelDetail(
            level=lvl,
            name=config["name"],
            description=config["description"],
        )
        for lvl, config in AUTONOMY_LEVELS.items()
    ]
