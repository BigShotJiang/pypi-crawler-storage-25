"""Proactive Intelligence API — pending suggestions and approval workflow.

Routes:
    GET  /api/v1/proactive/pending                   — List pending suggestions
    POST /api/v1/proactive/approve/{suggestion_id}   — Approve and act on a suggestion
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/proactive", tags=["proactive"])


# ---------------------------------------------------------------------------
# Dependency
# ---------------------------------------------------------------------------


def _get_engine():  # type: ignore[return]
    from apps.backend.services.inference.intelligence_service import get_proactive_intelligence_engine

    return get_proactive_intelligence_engine()


# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------


class SuggestionActionResponse(BaseModel):
    """A concrete action within a suggestion."""

    action_id: str
    label: str
    action_type: str
    payload: dict[str, Any] = Field(default_factory=dict)
    auto_executable: bool = False


class SuggestionResponse(BaseModel):
    """A single proactive suggestion."""

    suggestion_id: str
    signal_type: str
    title: str
    description: str
    urgency: float
    impact: float
    composite_score: float
    actions: list[SuggestionActionResponse] = Field(default_factory=list)
    created_at: str
    status: str
    tenant_id: str


class PendingSuggestionsResponse(BaseModel):
    """Response listing pending proactive suggestions."""

    suggestions: list[SuggestionResponse]
    total: int


class ApproveRequest(BaseModel):
    """Request body for approving a suggestion."""

    action_id: str | None = Field(
        None,
        description="Specific action to execute. If omitted, the first action is used.",
    )


class ApproveResponse(BaseModel):
    """Response after approving and acting on a suggestion."""

    suggestion: dict[str, Any]
    action: dict[str, Any]
    executed: bool
    result: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("/pending", response_model=PendingSuggestionsResponse)
async def list_pending_suggestions(
    tenant_id: str = Depends(get_verified_tenant_id),
    engine: Any = Depends(_get_engine),
) -> PendingSuggestionsResponse:
    """List all pending proactive suggestions for the current tenant.

    Sorted by composite score (urgency * 0.6 + impact * 0.4) descending.
    """
    try:
        pending = await engine.get_pending_suggestions(tenant_id)
    except Exception as exc:
        logger.error("Failed to fetch pending suggestions for %s: %s", tenant_id, exc)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Proactive intelligence service temporarily unavailable",
        ) from exc

    return PendingSuggestionsResponse(
        suggestions=[
            SuggestionResponse(
                suggestion_id=s.suggestion_id,
                signal_type=s.signal_type.value,
                title=s.title,
                description=s.description,
                urgency=s.urgency,
                impact=s.impact,
                composite_score=s.composite_score,
                actions=[
                    SuggestionActionResponse(
                        action_id=a.action_id,
                        label=a.label,
                        action_type=a.action_type,
                        payload=a.payload,
                        auto_executable=a.auto_executable,
                    )
                    for a in s.actions
                ],
                created_at=s.created_at,
                status=s.status.value,
                tenant_id=s.tenant_id,
            )
            for s in pending
        ],
        total=len(pending),
    )


@router.post("/approve/{suggestion_id}", response_model=ApproveResponse)
async def approve_suggestion(
    suggestion_id: str,
    body: ApproveRequest = ApproveRequest(),
    tenant_id: str = Depends(get_verified_tenant_id),
    engine: Any = Depends(_get_engine),
) -> ApproveResponse:
    """Approve a pending suggestion and execute its action.

    If action_id is omitted, the first action in the suggestion is used.
    Auto-executable actions are executed immediately; non-auto actions return
    the payload for the frontend to orchestrate.
    """
    try:
        result = await engine.act_on_suggestion(
            tenant_id=tenant_id,
            suggestion_id=suggestion_id,
            action_id=body.action_id,
        )
    except ValueError as exc:
        logger.error("Proactive suggestion not found: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Resource not found",
        ) from exc
    except Exception as exc:
        logger.error(
            "Failed to approve suggestion %s for %s: %s",
            suggestion_id,
            tenant_id,
            exc,
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Proactive intelligence service temporarily unavailable",
        ) from exc

    return ApproveResponse(
        suggestion=result["suggestion"],
        action=result["action"],
        executed=result["executed"],
        result=result.get("result", {}),
    )
