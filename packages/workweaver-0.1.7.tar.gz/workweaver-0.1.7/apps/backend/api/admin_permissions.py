"""Admin permissions REST API — list / grant / revoke per-user admin roles.

Issue #3227 round-3: surface parity for the AdminPermission canonical model.
Adds the ``/api/v1/admin/permissions`` endpoints so the role assignments
backed by ``AdminRoleStore`` are reachable from CLI, MCP, and the admin UI.

Permission semantics:

- GET /api/v1/admin/permissions          → list all role assignments + role catalog
                                           (requires GOVERNANCE_READ).
- POST /api/v1/admin/permissions         → grant a role to a user (PLATFORM_ADMIN
                                           only — cross-tenant write).
- DELETE /api/v1/admin/permissions/{email}
                                         → revoke a user's admin role assignment
                                           (PLATFORM_ADMIN only).

Every mutation emits a ``policy.admin_permission.mutation`` Decision Trace
event with ``admin_actor``, ``admin_role``, ``target_user``, ``mutation_class``
fields per the round-3 audit acceptance criteria.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr, Field

from apps.backend.api.dependencies.admin_permissions import (
    require_admin_permission_dep,
)
from apps.backend.api.founder_admin import require_founder
from apps.backend.services.admin.admin_permission import (
    AdminPermission,
    AdminPermissionCheck,
    AdminRole,
    get_role_permissions,
)
from apps.backend.services.admin.admin_role_store import (
    AdminRoleAssignment,
    get_admin_role_store,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/admin/permissions", tags=["admin-permissions"])


# ---------------------------------------------------------------------------
# Schemas
# ---------------------------------------------------------------------------


class _RoleAssignmentResponse(BaseModel):
    email: str = Field(..., description="Email of the user assigned this role.")
    role: str = Field(..., description="Assigned admin role.")
    assigned_by: str = Field(..., description="Actor who set the assignment.")
    assigned_at: str = Field(..., description="ISO-8601 assignment timestamp.")
    notes: str = Field("", description="Optional notes on the assignment.")
    permissions: list[str] = Field(
        default_factory=list,
        description="The set of AdminPermission values granted by this role.",
    )


class _PermissionsListResponse(BaseModel):
    assignments: list[_RoleAssignmentResponse]
    roles: dict[str, list[str]] = Field(
        default_factory=dict,
        description="Role -> list of granted permissions (read-only catalog).",
    )


class _GrantBody(BaseModel):
    email: EmailStr = Field(..., description="Email of the user to grant a role to.")
    role: str = Field(..., description="AdminRole value (e.g. 'tenant_admin').")
    notes: str = Field("", description="Optional reason / context for audit.")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _emit_admin_permission_trace(
    *,
    actor_id: str,
    target_user: str,
    mutation_class: str,
    role: AdminRole | None,
    outcome: str,
    rationale: str,
) -> None:
    """Best-effort Decision Trace emission for permission mutations."""
    try:
        from apps.backend.services.context.decision_event_capture import (
            capture_decision,
        )

        capture_decision(
            tenant_id="platform",
            skill_id="policy.admin_permission",
            decision_summary=(
                f"Admin permission {mutation_class} for user {target_user!r}"
                + (f" -> role {role.value!r}" if role is not None else "")
            ),
            decision_type="policy.admin_permission.mutation",
            outcome=outcome,
            rationale=rationale,
            capture_surface="admin_permissions",
            service_family="policy",
            context_data={
                "admin_actor": actor_id,
                "admin_role": role.value if role is not None else None,
                "target_user": target_user,
                "mutation_class": mutation_class,
            },
        )
    except Exception:
        logger.debug(
            "admin_permission decision trace emit failed actor=%s target=%s class=%s",
            actor_id,
            target_user,
            mutation_class,
            exc_info=True,
        )


def _assignment_to_response(assignment: AdminRoleAssignment) -> _RoleAssignmentResponse:
    perms = sorted(p.value for p in get_role_permissions(assignment.role))
    return _RoleAssignmentResponse(
        email=assignment.email,
        role=assignment.role.value,
        assigned_by=assignment.assigned_by,
        assigned_at=assignment.assigned_at,
        notes=assignment.notes,
        permissions=perms,
    )


def _role_catalog() -> dict[str, list[str]]:
    return {
        role.value: sorted(p.value for p in get_role_permissions(role))
        for role in AdminRole
    }


def _parse_role(value: str) -> AdminRole:
    try:
        return AdminRole(value)
    except ValueError as exc:
        valid = ", ".join(r.value for r in AdminRole)
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Unknown role {value!r}. Valid roles: {valid}",
        ) from exc


# ---------------------------------------------------------------------------
# Routes
# ---------------------------------------------------------------------------


@router.get("", response_model=_PermissionsListResponse)
async def list_permissions(
    _admin: str = Depends(require_founder),
    perm: AdminPermissionCheck = Depends(
        require_admin_permission_dep(AdminPermission.GOVERNANCE_READ)
    ),
) -> dict[str, Any]:
    """List all admin role assignments and the role -> permission catalog."""
    store = get_admin_role_store()
    assignments = [
        _assignment_to_response(a) for a in store.list_roles()
    ]
    return {
        "assignments": [a.model_dump() for a in assignments],
        "roles": _role_catalog(),
    }


@router.post("", response_model=_RoleAssignmentResponse, status_code=status.HTTP_200_OK)
async def grant_permission(
    body: _GrantBody,
    actor_email: str = Depends(require_founder),
    _perm: AdminPermissionCheck = Depends(
        require_admin_permission_dep(AdminPermission.GOVERNANCE_WRITE)
    ),
) -> dict[str, Any]:
    """Grant an admin role to a user (PLATFORM_ADMIN-gated mutation)."""
    role = _parse_role(body.role)
    store = get_admin_role_store()
    assignment = store.set_role(
        body.email,
        role,
        assigned_by=actor_email,
        notes=body.notes,
    )
    _emit_admin_permission_trace(
        actor_id=actor_email,
        target_user=body.email,
        mutation_class="grant",
        role=role,
        outcome="granted",
        rationale="Admin role granted via /api/v1/admin/permissions",
    )
    return _assignment_to_response(assignment).model_dump()


@router.delete("/{email}", status_code=status.HTTP_200_OK)
async def revoke_permission(
    email: str,
    actor_email: str = Depends(require_founder),
    _perm: AdminPermissionCheck = Depends(
        require_admin_permission_dep(AdminPermission.GOVERNANCE_WRITE)
    ),
) -> dict[str, Any]:
    """Revoke a user's admin role assignment (PLATFORM_ADMIN-gated mutation)."""
    store = get_admin_role_store()
    removed = store.remove_role(email)
    _emit_admin_permission_trace(
        actor_id=actor_email,
        target_user=email,
        mutation_class="revoke",
        role=None,
        outcome="revoked" if removed else "no_op",
        rationale=(
            "Admin role revoked via /api/v1/admin/permissions"
            if removed
            else "No assignment existed; revoke was a no-op"
        ),
    )
    return {"email": email, "revoked": removed}
