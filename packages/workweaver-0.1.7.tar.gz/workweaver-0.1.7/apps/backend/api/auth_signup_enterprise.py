"""Microsoft, Zoho, and unified OAuth config routes."""

from __future__ import annotations

import concurrent.futures
import os

from fastapi import APIRouter, HTTPException, Query, Request, Response, status
from fastapi.responses import RedirectResponse

from apps.backend.api.auth_models import AuthProvider, OAuthProviderConfig, UnifiedOAuthConfigResponse
from apps.backend.api.rate_limit import limiter
from apps.backend.api.auth_signup_shared import (
    ExistingAccountDifferentProviderError,
    OAuthSignupRequiredError,
    PUBLIC_WEB_ORIGIN_FALLBACK,
    _build_cli_oauth_error_response,
    _build_post_signup_redirect,
    _emit_oauth_callback_event,
    _lookup_existing_tenant_for_identity,
    _normalize_product_key,
    _oauth_error_redirect_url,
    _oauth_login_start_failure_redirect,
    _provider_callback_uri,
    _resolve_oauth_login_start,
    _resolve_oauth_signin_response,
    _safe_return_to_origin,
    get_auth_signup_facade,
    logger,
)
from apps.backend.services.oauth_redirect_state import (
    OAuthRedirectError,
    mint_oauth_state,
    normalize_return_to_origin,
    parse_oauth_state,
)
from apps.backend.providers.oidc_provider import OIDCIdentityProvider, OIDCProviderConfig
from apps.backend.providers.secret_provider import get_secret_from_env
router = APIRouter()

# Maximum time the unified OAuth config endpoint will wait for an OIDC issuer
# discovery probe before defaulting ``device_code_enabled`` to False. The flag
# is non-critical (only used to render an extra CLI hint), so the auth page
# must not block on a slow upstream. Cold-start regression: see
# tests/unit/test_auth_signup_enterprise.py::test_oidc_discovery_slow_call_bounded_by_short_timeout
_OIDC_DISCOVERY_PROBE_TIMEOUT_SECONDS = 1.0


def _self_host_cognito_disabled() -> bool:
    self_host = os.environ.get("WORKWEAVER_SELF_HOST", "").strip().lower() in {"1", "true", "yes"}
    explicit_self_host = os.environ.get("WORKWEAVER_DEPLOYMENT_PROFILE", "").strip().lower() == "self_host_production"
    cognito_disabled = os.environ.get("DISABLE_COGNITO", "").strip().lower() in {"1", "true", "yes"}
    return (self_host or explicit_self_host) and cognito_disabled


def _oauth_secret_values_from_env() -> dict[str, str | None]:
    return {
        "google_client_id": get_secret_from_env("google/client_id"),
        "google_client_secret": get_secret_from_env("google/client_secret"),
        "microsoft_client_id": get_secret_from_env("microsoft/client_id"),
        "microsoft_client_secret": get_secret_from_env("microsoft/client_secret"),
        "zoho_client_id": get_secret_from_env("zoho/client_id"),
        "zoho_client_secret": get_secret_from_env("zoho/client_secret"),
    }


def _probe_oidc_device_code_supported(oidc_config: "OIDCProviderConfig") -> bool:
    """Return whether the configured OIDC issuer advertises device-code login.

    Short-circuits after ``_OIDC_DISCOVERY_PROBE_TIMEOUT_SECONDS`` so a cold
    lambda or slow issuer cannot stall ``/oauth/config``. On timeout or any
    exception, returns False — Google/Microsoft/Zoho buttons still load.
    """

    def _run() -> bool:
        return OIDCIdentityProvider(config=oidc_config).device_authorization_supported()

    # Use a non-blocking executor: the context manager would wait for the
    # worker thread on ``__exit__``, defeating the timeout. The dangling
    # thread becomes a daemon and dies with the process — acceptable because
    # the underlying httpx call has its own 10s socket timeout.
    executor = concurrent.futures.ThreadPoolExecutor(max_workers=1)
    future = executor.submit(_run)
    try:
        result = future.result(timeout=_OIDC_DISCOVERY_PROBE_TIMEOUT_SECONDS)
    except concurrent.futures.TimeoutError:
        logger.warning(
            "OIDC discovery probe timed out after %.1fs; "
            "device_code_enabled defaulting to False",
            _OIDC_DISCOVERY_PROBE_TIMEOUT_SECONDS,
        )
        result = False
    except Exception:
        logger.warning("OIDC discovery failed while loading auth config", exc_info=True)
        result = False
    finally:
        # ``wait=False`` lets the in-flight worker finish in the background
        # bounded by httpx's own socket timeout, while the request returns now.
        executor.shutdown(wait=False)
    return result


def _get_oidc_provider() -> OIDCIdentityProvider:
    config = OIDCProviderConfig.from_env()
    if config is None:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "oidc_signup_disabled",
                "detail": "OIDC sign-in is not configured.",
            },
        )
    return OIDCIdentityProvider(config=config)


@router.get(
    "/microsoft/login",
    summary="Start Microsoft OAuth redirect flow",
    description="Redirects user to Microsoft consent screen for sign-in.",
)
@limiter.limit("10/minute")
async def microsoft_oauth_login(
    request: Request,
    return_to: str,
    preferred_region: str | None = None,
    product: str | None = None,
    invite_token: str | None = None,
    sub_tenant_invite_token: str | None = Query(default=None, alias="sub_tenant_invite"),
    client: str | None = None,
    client_state: str | None = None,
    code_challenge: str | None = None,
    code_challenge_method: str | None = None,
):
    """Redirect user to Microsoft OAuth consent screen."""
    facade = get_auth_signup_facade()
    if not facade.MICROSOFT_SIGNUP_ENABLED:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "microsoft_signup_disabled",
                "detail": "Microsoft signup is currently disabled.",
            },
        )

    origin, normalized_client = _resolve_oauth_login_start(
        provider="microsoft",
        return_to=return_to,
        client=client,
        client_state=client_state,
        normalize_return_to=normalize_return_to_origin,
        detail_key="detail",
    )

    try:
        redirect_uri = _provider_callback_uri("microsoft")
        state = mint_oauth_state(
            provider="microsoft",
            flow="login_microsoft",
            return_to_origin=origin,
            preferred_region=preferred_region,
            product=_normalize_product_key(product),
            invite_token=invite_token,
            sub_tenant_invite_token=sub_tenant_invite_token,
            client=normalized_client,
            client_state=client_state,
            code_challenge=code_challenge,
            code_challenge_method=code_challenge_method,
            ttl_seconds=10 * 60,
        )
        url = facade.get_microsoft_auth_url(redirect_uri=redirect_uri, state=state)
        return RedirectResponse(url=url, status_code=status.HTTP_302_FOUND)
    except Exception as exc:
        return _oauth_login_start_failure_redirect(
            provider="microsoft",
            origin=origin,
            reason=str(exc),
            client=normalized_client,
            client_state=client_state,
        )


@router.get(
    "/oidc/login",
    summary="Start self-host OIDC redirect flow",
    description="Redirects the user to the configured self-host OIDC provider for sign-in.",
)
@limiter.limit("10/minute")
async def oidc_oauth_login(
    request: Request,
    return_to: str,
    preferred_region: str | None = None,
    product: str | None = None,
    invite_token: str | None = None,
    sub_tenant_invite_token: str | None = Query(default=None, alias="sub_tenant_invite"),
    client: str | None = None,
    client_state: str | None = None,
    code_challenge: str | None = None,
    code_challenge_method: str | None = None,
):
    """Redirect user to the configured OIDC provider."""
    oidc_provider = _get_oidc_provider()
    origin, normalized_client = _resolve_oauth_login_start(
        provider="oidc",
        return_to=return_to,
        client=client,
        client_state=client_state,
        normalize_return_to=normalize_return_to_origin,
        detail_key="detail",
    )

    try:
        redirect_uri = _provider_callback_uri("oidc")
        state = mint_oauth_state(
            provider="oidc",
            flow="login_oidc",
            return_to_origin=origin,
            preferred_region=preferred_region,
            product=_normalize_product_key(product),
            invite_token=invite_token,
            sub_tenant_invite_token=sub_tenant_invite_token,
            client=normalized_client,
            client_state=client_state,
            code_challenge=code_challenge,
            code_challenge_method=code_challenge_method,
            ttl_seconds=10 * 60,
        )
        url = oidc_provider.build_authorization_url(redirect_uri=redirect_uri, state=state)
        return RedirectResponse(url=url, status_code=status.HTTP_302_FOUND)
    except Exception as exc:
        return _oauth_login_start_failure_redirect(
            provider="oidc",
            origin=origin,
            reason=str(exc),
            client=normalized_client,
            client_state=client_state,
        )


@router.get(
    "/microsoft/callback",
    summary="Microsoft OAuth redirect callback",
    description="Completes Microsoft sign-in and sends the user back to Workweaver.",
)
@limiter.limit("10/minute")
async def microsoft_oauth_callback(
    request: Request,
    http_response: Response,
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    error_description: str | None = None,
):
    facade = get_auth_signup_facade()
    if not facade.MICROSOFT_SIGNUP_ENABLED:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "microsoft_signup_disabled",
                "detail": "Microsoft signup is currently disabled.",
            },
        )

    return_to_origin = PUBLIC_WEB_ORIGIN_FALLBACK
    preferred_region: str | None = None
    product = "workweaver"
    invite_token: str | None = None
    sub_tenant_invite_token: str | None = None
    client = "web"
    client_state: str | None = None
    code_challenge: str | None = None
    code_challenge_method: str | None = None
    try:
        if state:
            parsed = parse_oauth_state(token=state, expected_provider="microsoft")
            return_to_origin = parsed.return_to_origin
            preferred_region = parsed.preferred_region
            product = _normalize_product_key(parsed.product)
            invite_token = parsed.invite_token
            sub_tenant_invite_token = parsed.sub_tenant_invite_token
            client = parsed.client
            client_state = parsed.client_state
            code_challenge = parsed.code_challenge
            code_challenge_method = parsed.code_challenge_method
    except OAuthRedirectError as exc:
        logger.warning("Microsoft OAuth state parse failed: %s", exc)
        return_to_origin = PUBLIC_WEB_ORIGIN_FALLBACK

    return_to_origin = _safe_return_to_origin(return_to_origin)

    if error:
        message = (error_description or error or "Microsoft sign-in failed").strip()
        if client == "cli":
            return _build_cli_oauth_error_response(
                provider="microsoft",
                client_state=client_state,
                outcome="provider_error",
                error_code=message,
                message=f"Microsoft sign-in returned an error: {message}.",
                reason=message,
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="microsoft",
            error_code=message,
            client=client,
            client_state=client_state,
        )
        _emit_oauth_callback_event(
            provider="microsoft",
            outcome="provider_error",
            redirect_to=dest,
            reason=message,
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)

    if not code:
        if client == "cli":
            return _build_cli_oauth_error_response(
                provider="microsoft",
                client_state=client_state,
                outcome="missing_code",
                error_code="missing_code",
                message="Microsoft sign-in did not return an authorization code.",
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="microsoft",
            error_code="missing_code",
            client=client,
            client_state=client_state,
        )
        _emit_oauth_callback_event(
            provider="microsoft",
            outcome="missing_code",
            redirect_to=dest,
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)

    # In-flight safe: echo the actual request path so the dispatcher
    # rollout doesn't break flows that started on the legacy URL.
    from apps.backend.api.auth_signup_shared import _callback_uri_from_request

    redirect_uri = _callback_uri_from_request(request, "microsoft")
    try:
        result = await facade.validate_microsoft_signin(code=code, redirect_uri=redirect_uri)
        token_email = result["email"]
        token_user_id = f"microsoft:{result['microsoft_user_id']}"

        has_invite = bool(
            (invite_token and invite_token.strip())
            or (sub_tenant_invite_token and sub_tenant_invite_token.strip())
        )
        existing_tenant = _lookup_existing_tenant_for_identity(
            owner_user_id=token_user_id,
            email=token_email,
            product=product,
        )
        if not existing_tenant and client != "cli" and not facade._domain_allowed_for_provisioning(
            token_email,
            has_valid_invite=has_invite,
        ):
            dest = _oauth_error_redirect_url(
                origin=return_to_origin,
                provider="microsoft",
                error_code="early_access_only_join_waitlist",
                client=client,
                client_state=client_state,
            )
            _emit_oauth_callback_event(
                provider="microsoft",
                outcome="domain_denied",
                redirect_to=dest,
                email=token_email,
            )
            return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)

        response = await _resolve_oauth_signin_response(
            provider=AuthProvider.MICROSOFT,
            owner_user_id=token_user_id,
            email=token_email,
            owner_name=result.get("name"),
            preferred_region=preferred_region,
            product=product,
            invite_token=invite_token,
            sub_tenant_invite_token=sub_tenant_invite_token,
            allow_signup=client != "cli",
        )
        return _build_post_signup_redirect(
            provider="microsoft",
            response=response,
            return_to_origin=return_to_origin,
            client=client,
            client_state=client_state,
            code_challenge=code_challenge,
            code_challenge_method=code_challenge_method,
        )
    except OAuthSignupRequiredError as exc:
        if client == "cli":
            return _build_cli_oauth_error_response(
                provider="microsoft",
                client_state=client_state,
                outcome="signup_required",
                error_code="signup_required",
                message="This Microsoft account does not have an existing Workweaver tenant yet.",
                reason=str(exc),
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="microsoft",
            error_code="signup_required",
            client=client,
            client_state=client_state,
        )
        _emit_oauth_callback_event(
            provider="microsoft",
            outcome="signup_required",
            redirect_to=dest,
            reason=str(exc),
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)
    except ExistingAccountDifferentProviderError as exc:
        logger.info(
            "Microsoft OAuth rejected — existing account under different provider: "
            "existing=%s attempted=%s",
            exc.existing_provider,
            exc.attempted_provider,
        )
        if client == "cli":
            return _build_cli_oauth_error_response(
                provider="microsoft",
                client_state=client_state,
                outcome="existing_account_different_provider",
                error_code="existing_account_different_provider",
                message=(
                    f"An account with this email already exists using "
                    f"{exc.existing_provider} sign-in. Sign in with that method, "
                    f"then link Microsoft from Settings → Account."
                ),
                reason=str(exc),
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="microsoft",
            error_code="existing_account_different_provider",
            client=client,
            client_state=client_state,
        )
        _emit_oauth_callback_event(
            provider="microsoft",
            outcome="existing_account_different_provider",
            redirect_to=dest,
            reason=str(exc),
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)
    except Exception as exc:
        if client == "cli":
            logger.warning("Microsoft OAuth redirect callback failed: %s", exc)
            return _build_cli_oauth_error_response(
                provider="microsoft",
                client_state=client_state,
                outcome="callback_failed",
                error_code="oauth_callback_failed",
                message="Microsoft sign-in could not be completed.",
                reason=str(exc),
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="microsoft",
            error_code="oauth_callback_failed",
            client=client,
            client_state=client_state,
        )
        logger.warning("Microsoft OAuth redirect callback failed: %s", exc)
        _emit_oauth_callback_event(
            provider="microsoft",
            outcome="callback_failed",
            redirect_to=dest,
            reason=str(exc),
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)


@router.get(
    "/zoho/login",
    summary="Start Zoho OAuth redirect flow",
    description="Redirects user to Zoho consent screen for sign-in.",
)
@limiter.limit("10/minute")
async def zoho_oauth_login(
    request: Request,
    return_to: str,
    preferred_region: str | None = None,
    product: str | None = None,
    invite_token: str | None = None,
    sub_tenant_invite_token: str | None = Query(default=None, alias="sub_tenant_invite"),
    client: str | None = None,
    client_state: str | None = None,
    code_challenge: str | None = None,
    code_challenge_method: str | None = None,
):
    """Redirect user to Zoho OAuth consent screen."""
    facade = get_auth_signup_facade()
    if not facade.ZOHO_SIGNUP_ENABLED:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "zoho_signup_disabled",
                "detail": "Zoho signup is currently disabled.",
            },
        )

    origin, normalized_client = _resolve_oauth_login_start(
        provider="zoho",
        return_to=return_to,
        client=client,
        client_state=client_state,
        normalize_return_to=normalize_return_to_origin,
        detail_key="detail",
    )

    try:
        redirect_uri = _provider_callback_uri("zoho")
        state = mint_oauth_state(
            provider="zoho",
            flow="login_zoho",
            return_to_origin=origin,
            preferred_region=preferred_region,
            product=_normalize_product_key(product),
            invite_token=invite_token,
            sub_tenant_invite_token=sub_tenant_invite_token,
            client=normalized_client,
            client_state=client_state,
            code_challenge=code_challenge,
            code_challenge_method=code_challenge_method,
            ttl_seconds=10 * 60,
        )
        url = facade.get_zoho_auth_url(redirect_uri=redirect_uri, state=state)
        return RedirectResponse(url=url, status_code=status.HTTP_302_FOUND)
    except Exception as exc:
        return _oauth_login_start_failure_redirect(
            provider="zoho",
            origin=origin,
            reason=str(exc),
            client=normalized_client,
            client_state=client_state,
        )


@router.get(
    "/oidc/callback",
    summary="Self-host OIDC redirect callback",
    description="Completes self-host OIDC sign-in and sends the user back to Workweaver.",
)
@limiter.limit("10/minute")
async def oidc_oauth_callback(
    request: Request,
    http_response: Response,
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    error_description: str | None = None,
):
    del http_response
    return_to_origin = PUBLIC_WEB_ORIGIN_FALLBACK
    preferred_region: str | None = None
    product = "workweaver"
    invite_token: str | None = None
    sub_tenant_invite_token: str | None = None
    client = "web"
    client_state: str | None = None
    code_challenge: str | None = None
    code_challenge_method: str | None = None

    try:
        if state:
            parsed = parse_oauth_state(token=state, expected_provider="oidc")
            return_to_origin = parsed.return_to_origin
            preferred_region = parsed.preferred_region
            product = _normalize_product_key(parsed.product)
            invite_token = parsed.invite_token
            sub_tenant_invite_token = parsed.sub_tenant_invite_token
            client = parsed.client
            client_state = parsed.client_state
            code_challenge = parsed.code_challenge
            code_challenge_method = parsed.code_challenge_method
    except OAuthRedirectError as exc:
        logger.warning("OIDC OAuth state parse failed: %s", exc)
        return_to_origin = PUBLIC_WEB_ORIGIN_FALLBACK

    return_to_origin = _safe_return_to_origin(return_to_origin)

    if error:
        message = (error_description or error or "OIDC sign-in failed").strip()
        if client == "cli":
            return _build_cli_oauth_error_response(
                provider="oidc",
                client_state=client_state,
                outcome="provider_error",
                error_code=message,
                message=f"OIDC sign-in returned an error: {message}.",
                reason=message,
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="oidc",
            error_code=message,
            client=client,
            client_state=client_state,
        )
        _emit_oauth_callback_event(
            provider="oidc",
            outcome="provider_error",
            redirect_to=dest,
            reason=message,
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)

    if not code:
        if client == "cli":
            return _build_cli_oauth_error_response(
                provider="oidc",
                client_state=client_state,
                outcome="missing_code",
                error_code="missing_code",
                message="OIDC sign-in did not return an authorization code.",
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="oidc",
            error_code="missing_code",
            client=client,
            client_state=client_state,
        )
        _emit_oauth_callback_event(
            provider="oidc",
            outcome="missing_code",
            redirect_to=dest,
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)

    from apps.backend.api.auth_signup_shared import _callback_uri_from_request

    redirect_uri = _callback_uri_from_request(request, "oidc")
    oidc_provider = _get_oidc_provider()
    try:
        token_response = oidc_provider.exchange_authorization_code(code=code, redirect_uri=redirect_uri)
        envelope = oidc_provider.resolve_from_token_response(token_response)
        token_email = str(envelope.email or "").strip().lower()
        raw_user_id = str(envelope.user_id or "").strip()
        token_user_id = f"oidc:{raw_user_id}" if raw_user_id else ""
        owner_name = str(envelope.identity_claims.get("name") or "").strip() or None

        if not token_email or not token_user_id:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "invalid_oidc_token",
                    "detail": "OIDC token did not include the required identity claims.",
                },
            )

        response = await _resolve_oauth_signin_response(
            provider=AuthProvider.OIDC,
            owner_user_id=token_user_id,
            email=token_email,
            owner_name=owner_name,
            preferred_region=preferred_region,
            product=product,
            invite_token=invite_token,
            sub_tenant_invite_token=sub_tenant_invite_token,
            allow_signup=client != "cli",
        )
        return _build_post_signup_redirect(
            provider="oidc",
            response=response,
            return_to_origin=return_to_origin,
            client=client,
            client_state=client_state,
            code_challenge=code_challenge,
            code_challenge_method=code_challenge_method,
        )
    except OAuthSignupRequiredError:
        if client == "cli":
            return _build_cli_oauth_error_response(
                provider="oidc",
                client_state=client_state,
                outcome="signup_required",
                error_code="signup_required",
                message="This OIDC account does not have an existing Workweaver tenant yet.",
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="oidc",
            error_code="signup_required",
            client=client,
            client_state=client_state,
        )
        _emit_oauth_callback_event(
            provider="oidc",
            outcome="signup_required",
            redirect_to=dest,
            reason="signup_required",
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)
    except ExistingAccountDifferentProviderError as exc:
        if client == "cli":
            return _build_cli_oauth_error_response(
                provider="oidc",
                client_state=client_state,
                outcome="provider_mismatch",
                error_code="existing_account_different_provider",
                message=(
                    f"An account already exists for {exc.email}. "
                    f"Sign in with {exc.existing_provider} or link OIDC from Settings first."
                ),
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="oidc",
            error_code="existing_account_different_provider",
            client=client,
            client_state=client_state,
        )
        _emit_oauth_callback_event(
            provider="oidc",
            outcome="provider_mismatch",
            redirect_to=dest,
            email=exc.email,
            reason=exc.existing_provider,
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)
    except HTTPException:
        raise
    except Exception as exc:
        if client == "cli":
            return _build_cli_oauth_error_response(
                provider="oidc",
                client_state=client_state,
                outcome="callback_failed",
                error_code="callback_failed",
                message="OIDC sign-in could not be completed.",
                reason=str(exc),
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="oidc",
            error_code="callback_failed",
            client=client,
            client_state=client_state,
        )
        _emit_oauth_callback_event(
            provider="oidc",
            outcome="callback_failed",
            redirect_to=dest,
            reason=str(exc),
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)


@router.get(
    "/zoho/callback",
    summary="Zoho OAuth redirect callback",
    description="Completes Zoho sign-in and sends the user back to Workweaver.",
)
@limiter.limit("10/minute")
async def zoho_oauth_callback(
    request: Request,
    http_response: Response,
    code: str | None = None,
    state: str | None = None,
    error: str | None = None,
    error_description: str | None = None,
    location: str | None = None,
    accounts_server: str | None = Query(None, alias="accounts-server"),
):
    facade = get_auth_signup_facade()
    if not facade.ZOHO_SIGNUP_ENABLED:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "zoho_signup_disabled",
                "detail": "Zoho signup is currently disabled.",
            },
        )

    return_to_origin = PUBLIC_WEB_ORIGIN_FALLBACK
    preferred_region: str | None = None
    product = "workweaver"
    invite_token: str | None = None
    sub_tenant_invite_token: str | None = None
    client = "web"
    client_state: str | None = None
    code_challenge: str | None = None
    code_challenge_method: str | None = None
    try:
        if state:
            parsed = parse_oauth_state(token=state, expected_provider="zoho")
            return_to_origin = parsed.return_to_origin
            preferred_region = parsed.preferred_region
            product = _normalize_product_key(parsed.product)
            invite_token = parsed.invite_token
            sub_tenant_invite_token = parsed.sub_tenant_invite_token
            client = parsed.client
            client_state = parsed.client_state
            code_challenge = parsed.code_challenge
            code_challenge_method = parsed.code_challenge_method
    except OAuthRedirectError as exc:
        logger.warning("Zoho OAuth state parse failed: %s", exc)
        return_to_origin = PUBLIC_WEB_ORIGIN_FALLBACK

    return_to_origin = _safe_return_to_origin(return_to_origin)

    if error:
        message = (error_description or error or "Zoho sign-in failed").strip()
        if client == "cli":
            return _build_cli_oauth_error_response(
                provider="zoho",
                client_state=client_state,
                outcome="provider_error",
                error_code=message,
                message=f"Zoho sign-in returned an error: {message}.",
                reason=message,
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="zoho",
            error_code=message,
            client=client,
            client_state=client_state,
        )
        _emit_oauth_callback_event(
            provider="zoho",
            outcome="provider_error",
            redirect_to=dest,
            reason=message,
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)

    if not code:
        if client == "cli":
            return _build_cli_oauth_error_response(
                provider="zoho",
                client_state=client_state,
                outcome="missing_code",
                error_code="missing_code",
                message="Zoho sign-in did not return an authorization code.",
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="zoho",
            error_code="missing_code",
            client=client,
            client_state=client_state,
        )
        _emit_oauth_callback_event(
            provider="zoho",
            outcome="missing_code",
            redirect_to=dest,
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)

    # In-flight safe: echo the actual request path so the dispatcher
    # rollout doesn't break flows that started on the legacy URL.
    from apps.backend.api.auth_signup_shared import _callback_uri_from_request

    redirect_uri = _callback_uri_from_request(request, "zoho")
    try:
        result = await facade.validate_zoho_signin(
            code=code,
            redirect_uri=redirect_uri,
            accounts_server=accounts_server,
            location=location,
        )
        token_email = result["email"]
        token_user_id = f"zoho:{result['zoho_user_id']}"

        has_invite = bool(
            (invite_token and invite_token.strip())
            or (sub_tenant_invite_token and sub_tenant_invite_token.strip())
        )
        existing_tenant = _lookup_existing_tenant_for_identity(
            owner_user_id=token_user_id,
            email=token_email,
            product=product,
        )
        if not existing_tenant and client != "cli" and not facade._domain_allowed_for_provisioning(
            token_email,
            has_valid_invite=has_invite,
        ):
            dest = _oauth_error_redirect_url(
                origin=return_to_origin,
                provider="zoho",
                error_code="early_access_only_join_waitlist",
                client=client,
                client_state=client_state,
            )
            _emit_oauth_callback_event(
                provider="zoho",
                outcome="domain_denied",
                redirect_to=dest,
                email=token_email,
            )
            return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)

        response = await _resolve_oauth_signin_response(
            provider=AuthProvider.ZOHO,
            owner_user_id=token_user_id,
            email=token_email,
            owner_name=result.get("name"),
            preferred_region=preferred_region,
            product=product,
            invite_token=invite_token,
            sub_tenant_invite_token=sub_tenant_invite_token,
            allow_signup=client != "cli",
        )
        return _build_post_signup_redirect(
            provider="zoho",
            response=response,
            return_to_origin=return_to_origin,
            client=client,
            client_state=client_state,
            code_challenge=code_challenge,
            code_challenge_method=code_challenge_method,
        )
    except OAuthSignupRequiredError as exc:
        if client == "cli":
            return _build_cli_oauth_error_response(
                provider="zoho",
                client_state=client_state,
                outcome="signup_required",
                error_code="signup_required",
                message="This Zoho account does not have an existing Workweaver tenant yet.",
                reason=str(exc),
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="zoho",
            error_code="signup_required",
            client=client,
            client_state=client_state,
        )
        _emit_oauth_callback_event(
            provider="zoho",
            outcome="signup_required",
            redirect_to=dest,
            reason=str(exc),
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)
    except ExistingAccountDifferentProviderError as exc:
        logger.info(
            "Zoho OAuth rejected — existing account under different provider: "
            "existing=%s attempted=%s",
            exc.existing_provider,
            exc.attempted_provider,
        )
        if client == "cli":
            return _build_cli_oauth_error_response(
                provider="zoho",
                client_state=client_state,
                outcome="existing_account_different_provider",
                error_code="existing_account_different_provider",
                message=(
                    f"An account with this email already exists using "
                    f"{exc.existing_provider} sign-in. Sign in with that method, "
                    f"then link Zoho from Settings → Account."
                ),
                reason=str(exc),
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="zoho",
            error_code="existing_account_different_provider",
            client=client,
            client_state=client_state,
        )
        _emit_oauth_callback_event(
            provider="zoho",
            outcome="existing_account_different_provider",
            redirect_to=dest,
            reason=str(exc),
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)
    except Exception as exc:
        if client == "cli":
            logger.warning("Zoho OAuth redirect callback failed: %s", exc)
            return _build_cli_oauth_error_response(
                provider="zoho",
                client_state=client_state,
                outcome="callback_failed",
                error_code="oauth_callback_failed",
                message="Zoho sign-in could not be completed.",
                reason=str(exc),
            )
        dest = _oauth_error_redirect_url(
            origin=return_to_origin,
            provider="zoho",
            error_code="oauth_callback_failed",
            client=client,
            client_state=client_state,
        )
        logger.warning("Zoho OAuth redirect callback failed: %s", exc)
        _emit_oauth_callback_event(
            provider="zoho",
            outcome="callback_failed",
            redirect_to=dest,
            reason=str(exc),
        )
        return RedirectResponse(url=dest, status_code=status.HTTP_302_FOUND)


@router.get(
    "/oauth/config",
    response_model=UnifiedOAuthConfigResponse,
    summary="Get unified OAuth config for all providers",
    description="Returns OAuth configuration for Google, Microsoft, and Zoho for the frontend.",
)
async def unified_oauth_config() -> UnifiedOAuthConfigResponse:
    """Return unified OAuth config used by the auth frontend."""
    facade = get_auth_signup_facade()
    if _self_host_cognito_disabled():
        oauth_values = _oauth_secret_values_from_env()
        google_client_id = oauth_values["google_client_id"]
        google_client_secret = oauth_values["google_client_secret"]
        microsoft_client_id = oauth_values["microsoft_client_id"]
        microsoft_client_secret = oauth_values["microsoft_client_secret"]
        zoho_client_id = oauth_values["zoho_client_id"]
        zoho_client_secret = oauth_values["zoho_client_secret"]
    else:
        google_client_id = facade.get_google_client_id()
        google_client_secret = facade.get_google_client_secret()
        microsoft_client_id = facade.get_microsoft_client_id()
        microsoft_client_secret = facade.get_microsoft_client_secret()
        zoho_client_id = facade.get_zoho_client_id()
        zoho_client_secret = facade.get_zoho_client_secret()
    oidc_config = OIDCProviderConfig.from_env()
    allowed_domain = sorted(facade.ALLOWED_PROVISIONING_DOMAINS)[0] if facade.ALLOWED_PROVISIONING_DOMAINS else None
    oidc_device_code_enabled = False
    if oidc_config is not None:
        # Short-circuit the discovery probe so a cold start / slow issuer
        # cannot stall the auth page. Falls back to False on timeout / error.
        oidc_device_code_enabled = _probe_oidc_device_code_supported(oidc_config)

    return UnifiedOAuthConfigResponse(
        google=OAuthProviderConfig(
            enabled=facade.GOOGLE_SIGNUP_ENABLED and bool(google_client_id and google_client_secret),
            client_id=google_client_id,
            display_name="Google",
        ),
        microsoft=OAuthProviderConfig(
            enabled=facade.MICROSOFT_SIGNUP_ENABLED and bool(microsoft_client_id and microsoft_client_secret),
            client_id=microsoft_client_id,
            display_name="Microsoft",
        ),
        oidc=OAuthProviderConfig(
            enabled=oidc_config is not None,
            client_id=(oidc_config.client_id if oidc_config is not None else None),
            display_name=(oidc_config.provider_label if oidc_config is not None else "SSO"),
            device_code_enabled=oidc_device_code_enabled,
        ),
        zoho=OAuthProviderConfig(
            enabled=facade.ZOHO_SIGNUP_ENABLED and bool(zoho_client_id and zoho_client_secret),
            client_id=zoho_client_id,
            display_name="Zoho",
        ),
        allowed_domain=allowed_domain,
        internal_bypass_domains=sorted(facade.INTERNAL_SIGNUP_BYPASS_DOMAINS),
        monthly_price_usd=facade.SIGNUP_MONTHLY_PRICE_USD,
        region_options=facade._signup_region_options(),
    )
