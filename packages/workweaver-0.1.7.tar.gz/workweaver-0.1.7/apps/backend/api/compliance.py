"""DNC management API for the Workweaver compliance surface (#2795 PR A).

Endpoints
---------

- ``POST   /api/v1/compliance/dnc``        — add (or upsert) a DNC entry
- ``GET    /api/v1/compliance/dnc``        — list entries (filter + paginate)
- ``DELETE /api/v1/compliance/dnc/{id}``   — soft-delete an entry

RBAC
----

Per #2795 the write surface is admin-scoped (owner/admin in product terms,
``UserRole.ADMIN`` in the canonical enum); reads are open to any authenticated
member of the tenant. Phone numbers are normalised to E.164 on every write.

Decision-trace shape
--------------------

The underlying :mod:`apps.backend.services.compliance.dnc` store emits a
structured ``dnc_decision_trace`` log row on every write — that is the audit
chain a downstream block surfaces ("why was this blocked?") via the
``entry_id`` returned to the API caller.
"""

from __future__ import annotations

import logging
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_id,
    require_admin_user_role,
)
from apps.backend.services.compliance import (
    DncChannel,
    DncSource,
    DncStore,
    InvalidPhoneError,
    get_default_dnc_store,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/compliance", tags=["compliance"])


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class DncCreateRequest(BaseModel):
    """Body for ``POST /api/v1/compliance/dnc``."""

    phone: str = Field(..., min_length=4, max_length=32)
    channel: str = Field(..., description="voice | sms | whatsapp | email | all")
    reason: str = Field(..., min_length=1, max_length=500)
    source: str = Field(
        default="manual",
        description="manual | opt-out | regulatory",
    )


class DncEntryResponse(BaseModel):
    """API-facing DNC entry shape."""

    id: str
    tenant_id: str
    phone_e164: str
    channel: str
    reason: str
    source: str
    added_at: str
    removed_at: str | None
    actor_id: str


class DncListResponse(BaseModel):
    """Paginated list response."""

    entries: list[DncEntryResponse]
    page: int
    limit: int


# ---------------------------------------------------------------------------
# DI helpers
# ---------------------------------------------------------------------------


def _get_store() -> DncStore:
    return get_default_dnc_store()


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("/dnc", response_model=DncEntryResponse, status_code=status.HTTP_201_CREATED)
async def add_dnc_entry(
    body: DncCreateRequest,
    request: Request,  # noqa: ARG001 (kept for future request-state access)
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
    _admin: Annotated[object, Depends(require_admin_user_role)] = None,
    store: DncStore = Depends(_get_store),
) -> DncEntryResponse:
    """Add (or upsert) a DNC entry. Admin-only."""
    try:
        channel_enum = DncChannel(body.channel.lower().strip())
    except ValueError as exc:
        raise HTTPException(
            status_code=422,
            detail={
                "error": "invalid_channel",
                "message": "channel must be one of voice|sms|whatsapp|email|all",
            },
        ) from exc

    try:
        source_enum = DncSource(body.source.lower().strip())
    except ValueError as exc:
        raise HTTPException(
            status_code=422,
            detail={
                "error": "invalid_source",
                "message": "source must be one of manual|opt-out|regulatory",
            },
        ) from exc

    try:
        entry = store.add(
            tenant_id=tenant_id,
            phone=body.phone,
            channel=channel_enum,
            reason=body.reason,
            source=source_enum,
            actor_id=actor_id,
        )
    except InvalidPhoneError as exc:
        raise HTTPException(
            status_code=422,
            detail={"error": "invalid_phone", "message": str(exc)},
        ) from exc

    return DncEntryResponse(**entry.to_dict())


@router.get("/dnc", response_model=DncListResponse)
async def list_dnc_entries(
    tenant_id: str = Depends(get_verified_tenant_id),
    phone: Annotated[str | None, Query(description="Filter by E.164 phone")] = None,
    channel: Annotated[str | None, Query(description="Filter by channel")] = None,
    page: Annotated[int, Query(ge=1, le=1000)] = 1,
    limit: Annotated[int, Query(ge=1, le=200)] = 50,
    store: DncStore = Depends(_get_store),
) -> DncListResponse:
    """List active DNC entries for the tenant. Any authenticated member."""
    channel_enum: DncChannel | None = None
    if channel:
        try:
            channel_enum = DncChannel(channel.lower().strip())
        except ValueError as exc:
            raise HTTPException(
                status_code=422,
                detail={
                    "error": "invalid_channel",
                    "message": "channel must be one of voice|sms|whatsapp|email|all",
                },
            ) from exc

    entries = store.list_active(
        tenant_id=tenant_id,
        phone=phone,
        channel=channel_enum,
        page=page,
        limit=limit,
    )
    return DncListResponse(
        entries=[DncEntryResponse(**e.to_dict()) for e in entries],
        page=page,
        limit=limit,
    )


@router.delete("/dnc/{entry_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_dnc_entry(
    entry_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
    _admin: Annotated[object, Depends(require_admin_user_role)] = None,
    store: DncStore = Depends(_get_store),
) -> None:
    """Soft-delete a DNC entry. Admin-only."""
    ok = store.remove(tenant_id=tenant_id, entry_id=entry_id, actor_id=actor_id)
    if not ok:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "error": "dnc_entry_not_found",
                "message": "no active DNC entry with that id for this tenant",
            },
        )
    return None


__all__ = [
    "DncCreateRequest",
    "DncEntryResponse",
    "DncListResponse",
    "router",
]
