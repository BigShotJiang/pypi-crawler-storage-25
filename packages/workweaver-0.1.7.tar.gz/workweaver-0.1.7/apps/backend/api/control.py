"""Control Dashboard API for Workweaver Skills-First AI Platform.

This module provides REST API endpoints for real-time skill control and transparency:
- List active skills with status
- Pause/resume skills
- View execution logs with drill-down
- Explainability (why decisions were made)
- Real-time WebSocket updates

Reference: docs/PRODUCT.md P1.7A.6 — User Control & Transparency
"""

import json
import logging
from datetime import UTC, datetime
from typing import Any, Literal


from fastapi import (
    APIRouter,
    Depends,
    HTTPException,
    Path,
    Query,
    Request,
    WebSocket,
    WebSocketDisconnect,
    status,
)
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import (
    resolve_authenticated_impersonator_id,
    resolve_verified_websocket_tenant_id,
)
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.middleware.tenant_isolation import resolve_request_tenant_id as get_tenant_id
from apps.backend.services.skills.skill_query import SkillQueryService

# Configure logging
logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/api/v1", tags=["control"])

# ============================================================================
# Pydantic Models for API
# ============================================================================


class ActiveSkillResponse(BaseModel):
    """Response model for active skill."""

    id: str = Field(..., description="Skill ID")
    name: str = Field(..., description="Skill display name")
    status: Literal["active", "paused"] = Field(..., description="Status: active or paused")
    last_run: str = Field(..., description="ISO timestamp of last execution")
    success_rate: float = Field(..., description="Success rate percentage")
    completed_today: int = Field(..., description="Number of completions today")
    avg_duration_ms: int = Field(..., description="Average execution duration")
    active_executions: int = Field(default=0, description="Current active executions")


class ExecutionLogResponse(BaseModel):
    """Response model for execution log entry."""

    request_id: str = Field(..., description="Unique request ID")
    timestamp: str = Field(..., description="ISO timestamp")
    skill_name: str = Field(..., description="Skill name")
    trigger: str | None = Field(None, description="Trigger type")
    status: str = Field(..., description="Execution status")
    duration_ms: int = Field(..., description="Execution duration")
    reasoning: str | None = Field(None, description="AI reasoning")
    confidence: float | None = Field(None, description="Confidence score")


class ExecutionDetailResponse(BaseModel):
    """Response model for execution details."""

    request_id: str = Field(..., description="Unique request ID")
    timestamp: str = Field(..., description="ISO timestamp")
    skill_name: str = Field(..., description="Skill name")
    skill_id: str = Field(..., description="Skill ID")
    trigger: str | None = Field(None, description="Trigger type")
    status: str = Field(..., description="Execution status")
    duration_ms: int = Field(..., description="Execution duration")
    reasoning: str | None = Field(None, description="AI reasoning")
    confidence: float | None = Field(None, description="Confidence score")
    error: str | None = Field(None, description="Error message")
    steps: list[dict[str, Any]] = Field(default_factory=list, description="Execution steps")


# ============================================================================
# In-Memory State for Real-Time Updates
# ============================================================================

# Tenant-scoped WebSocket connections: tenant_id -> list of active WebSockets
tenant_connections: dict[str, list[WebSocket]] = {}

# Skill execution state (in-memory for demo, should be persisted)
skill_execution_state: dict[str, dict[str, Any]] = {}


# ============================================================================
# API Endpoints
# ============================================================================


@router.get("/skills/active", response_model=dict[str, list[ActiveSkillResponse]])
async def list_active_skills(
    request: Request,
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> dict[str, list[ActiveSkillResponse]]:
    """List all active skills with their current status.

    Returns:
        Dictionary with skills list containing:
        - Skill ID, name, status (active/paused)
        - Last run time, success rate
        - Completed today, average duration
        - Active executions count

    Reference: legacy P1.7A.6 — Active Skills View
    """
    try:
        tenant_id = get_tenant_id(request)

        # Query active skills
        skill_query = SkillQueryService()
        skills = await skill_query.list_skills(
            tenant_id=tenant_id,
            status="active",
            limit=max(1, pagination.offset + pagination.limit),
        )

        # Enrich with execution stats
        active_skills = []
        for skill in skills:
            skill_id = skill.skill_id

            # Get execution stats from state or compute
            state = skill_execution_state.get(skill_id, {})
            active_skills.append(
                ActiveSkillResponse(
                    id=skill_id,
                    name=skill.display_name,
                    status=state.get("control_status", "active"),
                    last_run=state.get("last_run", datetime.now(UTC).replace(tzinfo=None).isoformat()),
                    success_rate=state.get("success_rate", 95.0),
                    completed_today=state.get("completed_today", 0),
                    avg_duration_ms=state.get("avg_duration_ms", 1200),
                    active_executions=state.get("active_executions", 0),
                )
            )

        paged_skills, _total = paginate_items(active_skills, pagination)
        return {"skills": paged_skills}

    except Exception as e:
        logger.error(f"Failed to list active skills: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to load active skills",
        )


@router.post("/skills/{skill_id}/pause")
async def pause_skill(
    skill_id: str = Path(..., description="Skill ID to pause"), request: Request = None
) -> dict[str, str]:
    """Pause a skill to stop new executions.

    Args:
        skill_id: Skill ID to pause
        request: FastAPI request

    Returns:
        Success message

    Reference: legacy P1.7A.6 — Intervention Points
    """
    try:
        tenant_id = get_tenant_id(request)

        # Verify skill exists and belongs to tenant
        skill_query = SkillQueryService()
        skill = await skill_query.get_skill(tenant_id=tenant_id, skill_id=skill_id)

        if not skill:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Skill {skill_id} not found",
            )

        # Update control status
        if skill_id not in skill_execution_state:
            skill_execution_state[skill_id] = {}

        skill_execution_state[skill_id]["control_status"] = "paused"
        skill_execution_state[skill_id]["paused_at"] = datetime.now(UTC).replace(tzinfo=None).isoformat()
        skill_execution_state[skill_id]["paused_by"] = tenant_id

        # Notify WebSocket subscribers for this tenant only
        await broadcast_update(
            tenant_id,
            {
                "type": "skill_status_changed",
                "skill_id": skill_id,
                "status": "paused",
                "timestamp": datetime.now(UTC).replace(tzinfo=None).isoformat(),
            },
        )

        logger.info(f"Skill {skill_id} paused by tenant {tenant_id}")

        return {"message": f"Skill {skill_id} paused successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to pause skill {skill_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to pause skill",
        )


@router.post("/skills/{skill_id}/resume")
async def resume_skill(
    skill_id: str = Path(..., description="Skill ID to resume"), request: Request = None
) -> dict[str, str]:
    """Resume a paused skill.

    Args:
        skill_id: Skill ID to resume
        request: FastAPI request

    Returns:
        Success message

    Reference: legacy P1.7A.6 — Intervention Points
    """
    try:
        tenant_id = get_tenant_id(request)

        # Verify skill exists and belongs to tenant
        skill_query = SkillQueryService()
        skill = await skill_query.get_skill(tenant_id=tenant_id, skill_id=skill_id)

        if not skill:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Skill {skill_id} not found",
            )

        # Update control status
        if skill_id not in skill_execution_state:
            skill_execution_state[skill_id] = {}

        skill_execution_state[skill_id]["control_status"] = "active"
        skill_execution_state[skill_id]["resumed_at"] = datetime.now(UTC).replace(tzinfo=None).isoformat()
        skill_execution_state[skill_id]["resumed_by"] = tenant_id

        # Notify WebSocket subscribers for this tenant only
        await broadcast_update(
            tenant_id,
            {
                "type": "skill_status_changed",
                "skill_id": skill_id,
                "status": "active",
                "timestamp": datetime.now(UTC).replace(tzinfo=None).isoformat(),
            },
        )

        logger.info(f"Skill {skill_id} resumed by tenant {tenant_id}")

        return {"message": f"Skill {skill_id} resumed successfully"}

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to resume skill {skill_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to resume skill",
        )


@router.get("/audit/execution-log", response_model=dict[str, list[ExecutionLogResponse]])
async def get_execution_log(
    limit: int = Query(50, ge=1, le=100, description="Maximum number of entries"),
    skill_id: str | None = Query(None, description="Filter by skill ID"),
    request: Request = None,
) -> dict[str, list[ExecutionLogResponse]]:
    """Get skill execution log with filtering.

    Args:
        limit: Maximum number of entries to return
        skill_id: Optional skill ID filter
        request: FastAPI request

    Returns:
        Dictionary with executions list

    Reference: legacy P1.7A.6 — Skill Execution Log
    """
    try:
        tenant_id = get_tenant_id(request)

        # Query execution log from DynamoDB audit_trail table
        import boto3

        dynamodb = boto3.resource("dynamodb")
        audit_table = dynamodb.Table("audit_trail")

        from boto3.dynamodb.conditions import Key  # noqa: PLC0415

        # Build query
        if skill_id:
            # Query specific skill
            response = audit_table.query(
                KeyConditionExpression=Key("pk").eq(f"AUDIT#{tenant_id}#{skill_id}"),
                Limit=limit,
                ScanIndexForward=False,  # Most recent first
            )
        else:
            # Query tenant_id-index GSI to retrieve all executions for this tenant.
            response = audit_table.query(
                IndexName="tenant_id-index",
                KeyConditionExpression=Key("tenant_id").eq(tenant_id),
                Limit=limit,
                ScanIndexForward=False,
            )

        # Transform to execution log format
        executions = []
        for item in response.get("Items", []):
            # Extract skill name from skill_id
            executions.append(
                ExecutionLogResponse(
                    request_id=item.get("request_id", ""),
                    timestamp=item.get("timestamp", ""),
                    skill_name=item.get("skill_id", ""),
                    trigger=item.get("trigger", "Manual"),
                    status=item.get("status", "unknown"),
                    duration_ms=item.get("duration_ms", 0),
                    reasoning=item.get("reasoning"),
                    confidence=item.get("confidence"),
                )
            )

        return {"executions": executions}

    except Exception as e:
        logger.error(f"Failed to load execution log: {e}")
        return {"executions": [], "warning": "Execution data temporarily unavailable"}


@router.get("/audit/execution/{request_id}", response_model=ExecutionDetailResponse)
async def get_execution_details(
    request_id: str = Path(..., description="Request ID"), request: Request = None
) -> ExecutionDetailResponse:
    """Get detailed execution information with reasoning.

    Args:
        request_id: Unique request ID
        request: FastAPI request

    Returns:
        Detailed execution information

    Reference: legacy P1.7A.6 — Explainability
    """
    try:
        tenant_id = get_tenant_id(request)

        # Query from DynamoDB
        import boto3

        dynamodb = boto3.resource("dynamodb")
        audit_table = dynamodb.Table("audit_trail")

        from boto3.dynamodb.conditions import Key  # noqa: PLC0415

        # Query tenant_id-index GSI, then filter to the specific request_id.
        _gsi_resp = audit_table.query(
            IndexName="tenant_id-index",
            KeyConditionExpression=Key("tenant_id").eq(tenant_id),
            Limit=200,
        )
        response = {"Items": [item for item in _gsi_resp.get("Items", []) if item.get("request_id") == request_id]}

        items = response.get("Items", [])
        if not items:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Execution {request_id} not found",
            )

        item = items[0]

        # Extract audit trail steps
        audit_trail = item.get("audit_trail", [])
        steps = []
        for entry in audit_trail:
            if entry.get("type") == "step":
                steps.append(
                    {
                        "name": entry.get("step", "unknown"),
                        "status": entry.get("status", "unknown"),
                        "layer": entry.get("layer", "unknown"),
                        "duration_ms": entry.get("duration_ms", 0),
                        "error": entry.get("error"),
                    }
                )

        return ExecutionDetailResponse(
            request_id=item.get("request_id", ""),
            timestamp=item.get("timestamp", ""),
            skill_name=item.get("skill_id", ""),
            skill_id=item.get("skill_id", ""),
            trigger=item.get("trigger", "Manual"),
            status=item.get("status", "unknown"),
            duration_ms=item.get("duration_ms", 0),
            reasoning=item.get("reasoning"),
            confidence=item.get("confidence"),
            error=item.get("error"),
            steps=steps,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to load execution details: {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Execution data temporarily unavailable",
        )


@router.post("/audit/execution/{request_id}/replay")
async def replay_execution(
    request_id: str = Path(..., description="Request ID to replay"),
    request: Request = None,
) -> dict[str, str]:
    """Replay an execution with the same inputs.

    Args:
        request_id: Request ID to replay
        request: FastAPI request

    Returns:
        Success message with new request ID

    Reference: legacy P1.7A.6 — Intervention Points
    """
    try:
        tenant_id = get_tenant_id(request)

        # 1. Load original execution from audit trail
        import boto3
        import uuid

        dynamodb = boto3.resource("dynamodb")
        audit_table = dynamodb.Table("audit_trail")

        from boto3.dynamodb.conditions import Key  # noqa: PLC0415

        # Query for the original execution via tenant_id-index GSI, filter by request_id
        _gsi_resp = audit_table.query(
            IndexName="tenant_id-index",
            KeyConditionExpression=Key("tenant_id").eq(tenant_id),
            Limit=200,
        )
        items = [item for item in _gsi_resp.get("Items", []) if item.get("request_id") == request_id]
        if not items:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Execution {request_id} not found",
            )

        original_execution = items[0]

        # 2. Generate new request ID for replay
        new_request_id = f"replay_{str(uuid.uuid4())}"

        # 3. Re-submit execution through workflow executor if available
        # For now, log the replay to audit trail
        from apps.backend.services.audit_logger import AuditLogger, AuditAction, AuditSeverity

        audit_logger = AuditLogger()
        await audit_logger.log(
            action=AuditAction.SKILL_EXECUTED,
            severity=AuditSeverity.INFO,
            tenant_id=tenant_id,
            user_id=original_execution.get("user_id"),
            resource_type="skill_execution",
            resource_id=new_request_id,
            impersonator_id=resolve_authenticated_impersonator_id(request),
            action_metadata={
                "replayed_from": request_id,
                "original_skill_id": original_execution.get("skill_id"),
                "original_timestamp": original_execution.get("timestamp"),
                "replay_timestamp": datetime.now(UTC).replace(tzinfo=None).isoformat(),
                "original_input": original_execution.get("input_data"),
            },
        )

        logger.info(f"Replaying execution {request_id} for tenant {tenant_id} as {new_request_id}")

        # 4. If workflow executor is available, re-execute the skill
        # This would require importing and calling the workflow executor
        # For now, we log the replay event and return the new request ID
        from apps.backend.services.event_bus import get_event_bus

        event_bus = get_event_bus()
        await event_bus.publish(
            tenant_id=tenant_id,
            event_type="activity.new",
            data={
                "activity_type": "skill_replay",
                "request_id": new_request_id,
                "replayed_from": request_id,
                "skill_id": original_execution.get("skill_id"),
            },
        )

        return {
            "message": "Execution replay initiated",
            "new_request_id": new_request_id,
            "original_request_id": request_id,
            "status": "queued",
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to replay execution {request_id}: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to replay execution",
        )


# ============================================================================
# WebSocket Endpoint for Real-Time Updates
# ============================================================================


@router.websocket("/realtime/control")
async def websocket_control_updates(websocket: WebSocket):
    """WebSocket endpoint for real-time control dashboard updates.

    Requires authenticated tenant identity via resolve_verified_websocket_tenant_id.
    Connections are tracked per-tenant; broadcasts are scoped to the same tenant.

    Broadcasts:
    - Skill status changes (pause/resume)
    - Execution started/completed
    - Active execution count changes

    Reference: legacy P1.7A.6 — Real-time Monitoring
    """
    # Authenticate before accepting the connection (reject-then-close pattern).
    try:
        tenant_id = resolve_verified_websocket_tenant_id(websocket)
    except HTTPException as exc:
        close_code = 4403 if exc.status_code == status.HTTP_403_FORBIDDEN else 4401
        await websocket.close(code=close_code, reason=str(exc.detail))
        return

    await websocket.accept()

    # Track in tenant-scoped pool
    tenant_connections.setdefault(tenant_id, []).append(websocket)

    try:
        while True:
            # Keep connection alive and handle incoming messages
            data = await websocket.receive_text()

            # Handle client messages (ping/pong, subscribe, etc.)
            try:
                message = json.loads(data)
                if message.get("type") == "ping":
                    await websocket.send_text(json.dumps({"type": "pong"}))
            except json.JSONDecodeError:
                logger.warning("Invalid JSON from WebSocket client: %s", data)

    except WebSocketDisconnect:
        _remove_connection(tenant_id, websocket)
        logger.info("WebSocket client disconnected for tenant=%s", tenant_id)
    except Exception as e:
        logger.error("WebSocket error: %s", e)
        _remove_connection(tenant_id, websocket)


def _remove_connection(tenant_id: str, websocket: WebSocket) -> None:
    """Remove a websocket from the tenant-scoped pool and clean up empty entries."""
    conns = tenant_connections.get(tenant_id)
    if conns is None:
        return
    if websocket in conns:
        conns.remove(websocket)
    if not conns:
        tenant_connections.pop(tenant_id, None)


async def broadcast_update(tenant_id: str, update: dict[str, Any]):
    """Broadcast update to all WebSocket clients belonging to a specific tenant.

    Args:
        tenant_id: Tenant whose connections should receive the update
        update: Update dictionary to broadcast
    """
    conns = tenant_connections.get(tenant_id)
    if not conns:
        return

    message = json.dumps(update)

    for connection in conns:
        try:
            await connection.send_text(message)
        except Exception as e:
            logger.error(f"Failed to send WebSocket message: {e}")
