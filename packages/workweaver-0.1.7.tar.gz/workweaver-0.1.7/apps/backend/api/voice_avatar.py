"""Voice avatar rendering endpoint for Recall.ai Output Media.

Recall.ai Output Media renders an HTML page as the bot's camera feed
in the meeting. This endpoint serves a lightweight animated avatar
with lip-sync placeholders for Zara.
"""

from __future__ import annotations

from fastapi import APIRouter, Query
from fastapi.responses import HTMLResponse

router = APIRouter(prefix="/api/v1/voice", tags=["voice-avatar"])

_AVATAR_HTML_TEMPLATE = """\
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>Zara - Meeting Assistant</title>
<style>
  * {{ margin: 0; padding: 0; box-sizing: border-box; }}
  body {{
    display: flex;
    align-items: center;
    justify-content: center;
    height: 100vh;
    background: linear-gradient(135deg, #1a1a2e 0%, #16213e 50%, #0f3460 100%);
    font-family: -apple-system, BlinkMacSystemFont, sans-serif;
    color: #fff;
    overflow: hidden;
  }}
  .avatar-container {{
    text-align: center;
    position: relative;
  }}
  .avatar-ring {{
    width: 120px;
    height: 120px;
    border-radius: 50%;
    border: 3px solid rgba(255,255,255,0.2);
    display: flex;
    align-items: center;
    justify-content: center;
    margin: 0 auto 16px;
    position: relative;
  }}
  .avatar-ring.speaking {{
    border-color: #4fc3f7;
    box-shadow: 0 0 20px rgba(79,195,247,0.4);
    animation: pulse 1.5s ease-in-out infinite;
  }}
  .avatar-icon {{
    font-size: 48px;
  }}
  .name {{
    font-size: 16px;
    font-weight: 600;
    letter-spacing: 0.5px;
  }}
  .role {{
    font-size: 12px;
    opacity: 0.7;
    margin-top: 4px;
  }}
  .tenant-id {{
    display: none;
  }}
  @keyframes pulse {{
    0%, 100% {{ transform: scale(1); border-color: #4fc3f7; }}
    50% {{ transform: scale(1.05); border-color: #81d4fa; }}
  }}
</style>
</head>
<body>
<div class="avatar-container">
  <div class="avatar-ring" id="avatar-ring">
    <span class="avatar-icon">&#x1F916;</span>
  </div>
  <div class="name">Zara</div>
  <div class="role">AI Meeting Assistant</div>
  <div class="tenant-id" data-tenant="{tenant_id}">{tenant_id}</div>
</div>
<script>
  // Lip-sync: toggle speaking class via postMessage from bridge
  window.addEventListener('message', function(e) {{
    var ring = document.getElementById('avatar-ring');
    if (e.data === 'speaking') ring.classList.add('speaking');
    else if (e.data === 'silent') ring.classList.remove('speaking');
  }});
</script>
</body>
</html>"""


async def render_avatar(tenant_id: str = Query(..., description="Tenant identifier")) -> HTMLResponse:
    """Render avatar HTML page for Recall.ai Output Media.

    Returns a lightweight HTML page with an animated avatar that
    Recall.ai renders as the bot's camera feed in the meeting.
    """
    html = _AVATAR_HTML_TEMPLATE.format(tenant_id=tenant_id)
    return HTMLResponse(content=html, status_code=200)


# Register the endpoint on the router
router.add_api_route("/avatar", render_avatar, methods=["GET"])
