"""Org audit-log API surface."""

from __future__ import annotations

from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Query, status

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.schemas.error_response import ErrorResponse
from apps.backend.services.capability_lease import CapabilityLeaseDenied
from apps.backend.services.org_audit_log import (
    ORG_AUDIT_EVENT_TYPES,
    OrgAuditForbidden,
    OrgAuditLogService,
    get_org_audit_log_service,
)

router = APIRouter(prefix="/api/v1/org", tags=["org-audit-log"])


@router.get(
    "/{org_id}/audit-log",
    responses={
        400: {"model": ErrorResponse, "description": "Invalid audit-log query"},
        403: {"model": ErrorResponse, "description": "Caller cannot read this org audit log"},
    },
)
async def get_org_audit_log(
    org_id: str,
    since: Annotated[str | None, Query(description="ISO timestamp or relative duration, for example 7d")] = None,
    until: Annotated[str | None, Query(description="ISO timestamp upper bound")] = None,
    actor: Annotated[str | None, Query(description="Actor user id filter")] = None,
    event_type: Annotated[
        list[str] | None,
        Query(description=f"Event type filter. Supported: {', '.join(ORG_AUDIT_EVENT_TYPES)}"),
    ] = None,
    cursor: Annotated[str | None, Query(description="Pagination cursor from the previous response")] = None,
    limit: Annotated[int, Query(ge=1, le=200, description="Maximum events to return")] = 50,
    service: OrgAuditLogService = Depends(get_org_audit_log_service),
    caller_tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return a paginated, tamper-evident org audit log."""

    try:
        return service.query(
            org_id=org_id,
            caller_tenant_id=caller_tenant_id,
            since=since,
            until=until,
            actor=actor,
            event_types=event_type,
            cursor=cursor,
            limit=limit,
        )
    # ``CapabilityLeaseDenied`` is the structural cousin of ``OrgAuditForbidden``:
    # the underlying lease service raises it when the caller's tenant has no
    # org mapping (``tenant_org_unknown``) or when cross-org access is denied.
    # The audit-log endpoint must surface either as 403 — never 500 — so the
    # frontend can distinguish "not your data" from "service broken". This
    # mirrors the mapping already in ``apps/backend/api/org/capacity.py``.
    except (OrgAuditForbidden, CapabilityLeaseDenied) as exc:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": "org_audit_log_forbidden", "detail": str(exc)},
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "invalid_org_audit_log_query", "detail": str(exc)},
        ) from exc
