"""Org management API for Path A sub-tenancy."""

from __future__ import annotations

from dataclasses import asdict

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr, Field

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_email,
    get_verified_user_id,
)
from apps.backend.schemas.error_response import ErrorResponse
from apps.backend.services.org_provisioning import (
    OrgForbiddenError,
    OrgInactiveError,
    OrgInvitationEmailError,
    OrgNotFoundError,
    OrgProvisioningError,
    OrgProvisioningService,
    OrgSubTenantLimitExceededError,
    SubTenantInviteResult,
    get_org_provisioning_service,
)

router = APIRouter(prefix="/api/v1/org", tags=["org-management"])


class InviteSubTenantRequest(BaseModel):
    """Request body for inviting a coworker as an org sub-tenant."""

    invitee_email: EmailStr = Field(..., description="Coworker email address")
    invitee_name: str | None = Field(default=None, max_length=200, description="Optional coworker display name")


class InviteSubTenantResponse(BaseModel):
    """Response returned after a sub-tenant invitation is created."""

    invitation_id: str
    org_id: str
    tenant_id: str
    invitee_email: str
    inviter_email: str
    signup_url: str
    audit_event_id: str
    status: str
    created_at: str
    expires_at: str

    @classmethod
    def from_result(cls, result: SubTenantInviteResult) -> "InviteSubTenantResponse":
        return cls(**asdict(result))


def _service_unavailable(exc: Exception) -> None:
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail={
            "error": "org_provisioning_unavailable",
            "detail": "Org invitation flow is unavailable",
        },
    ) from exc


@router.post(
    "/{org_id}/invite-sub-tenant",
    response_model=InviteSubTenantResponse,
    status_code=status.HTTP_201_CREATED,
    responses={
        403: {"model": ErrorResponse, "description": "Only owner tenants can invite sub-tenants"},
        404: {"model": ErrorResponse, "description": "Org not found"},
        409: {"model": ErrorResponse, "description": "Org cannot accept another sub-tenant"},
        503: {"model": ErrorResponse, "description": "Org provisioning unavailable"},
    },
)
async def invite_sub_tenant(
    org_id: str,
    request: InviteSubTenantRequest,
    service: OrgProvisioningService = Depends(get_org_provisioning_service),
    caller_tenant_id: str = Depends(get_verified_tenant_id),
    inviter_user_id: str = Depends(get_verified_user_id),
    inviter_email: str = Depends(get_verified_user_email),
) -> InviteSubTenantResponse:
    """Invite a coworker into a full-capability sub-tenant under the same org."""
    try:
        result = service.invite_sub_tenant(
            org_id=org_id,
            caller_tenant_id=caller_tenant_id,
            inviter_user_id=inviter_user_id,
            inviter_email=inviter_email,
            invitee_email=str(request.invitee_email),
            invitee_name=request.invitee_name,
        )
    except OrgForbiddenError as exc:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "org_owner_required",
                "detail": str(exc),
            },
        ) from exc
    except OrgNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "error": "org_not_found",
                "detail": str(exc),
            },
        ) from exc
    except (OrgInactiveError, OrgSubTenantLimitExceededError) as exc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={
                "error": "org_sub_tenant_unavailable",
                "detail": str(exc),
            },
        ) from exc
    except OrgInvitationEmailError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "org_invitation_email_failed",
                "detail": str(exc),
            },
        ) from exc
    except OrgProvisioningError as exc:
        _service_unavailable(exc)

    return InviteSubTenantResponse.from_result(result)
