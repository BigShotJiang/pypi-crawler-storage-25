"""Org capacity API surface."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.schemas.error_response import ErrorResponse
from apps.backend.services.capability_lease import CapabilityLeaseDenied, get_permission_service
from apps.backend.services.org_capacity_index import OrgCapacityIndex, get_org_capacity_index
from apps.backend.services.org_audit_log import OrgAuditForbidden

router = APIRouter(prefix="/api/v1/org", tags=["org-capacity"])


def _resolve_org_id(*, requested_org_id: str, caller_tenant_id: str) -> str:
    lease_service = get_permission_service()
    caller_org = lease_service.tenant_org_id(caller_tenant_id)
    normalized = str(requested_org_id or "").strip()
    if normalized in {"", "current", "self"}:
        return caller_org
    if normalized != caller_org:
        raise OrgAuditForbidden("org_capacity_cross_org_denied")
    return normalized


@router.get(
    "/{org_id}/capacity",
    responses={
        403: {"model": ErrorResponse, "description": "Caller cannot read this org capacity index"},
        503: {"model": ErrorResponse, "description": "Capacity index unavailable"},
    },
)
async def get_org_capacity(
    org_id: str,
    index: OrgCapacityIndex = Depends(get_org_capacity_index),
    caller_tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return same-org tenant capacity rows and org rollup."""

    try:
        resolved_org_id = _resolve_org_id(requested_org_id=org_id, caller_tenant_id=caller_tenant_id)
        return index.snapshot(resolved_org_id).to_dict()
    except (OrgAuditForbidden, CapabilityLeaseDenied) as exc:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": "org_capacity_forbidden", "detail": str(exc)},
        ) from exc
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={"error": "org_capacity_unavailable", "detail": str(exc)},
        ) from exc
