"""Tenant-scoped Swarm Constitution REST API."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, get_verified_user_id
from apps.backend.services.swarm_constitution import (
    SwarmConstitution,
    SwarmConstitutionRejected,
    SwarmConstitutionService,
    get_swarm_constitution_service,
)

router = APIRouter(prefix="/api/v1/swarm/constitution", tags=["swarm"])


class SwarmConstitutionCreateRequest(BaseModel):
    name: str = Field(..., min_length=1)
    content: str = Field(..., min_length=1)
    rationale: str | None = None
    activate: bool = False
    idempotency_key: str | None = None


class SwarmConstitutionUpdateRequest(BaseModel):
    name: str | None = None
    content: str = Field(..., min_length=1)
    rationale: str | None = None
    idempotency_key: str | None = None


class SwarmConstitutionActionRequest(BaseModel):
    rationale: str | None = None
    idempotency_key: str | None = None


class SwarmConstitutionListResponse(BaseModel):
    constitutions: list[SwarmConstitution]
    count: int


def get_swarm_constitution_service_dependency() -> SwarmConstitutionService:
    return get_swarm_constitution_service()


def _not_found(exc: KeyError) -> HTTPException:
    return HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))


def _rejected(exc: SwarmConstitutionRejected) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
        detail={"error": "swarm_constitution_rejected", "message": str(exc)},
    )


@router.post("", response_model=SwarmConstitution, status_code=status.HTTP_201_CREATED)
async def create_swarm_constitution(
    request: SwarmConstitutionCreateRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    service: SwarmConstitutionService = Depends(get_swarm_constitution_service_dependency),
) -> Any:
    try:
        return service.create_constitution(
            tenant_id=tenant_id,
            name=request.name,
            content=request.content,
            actor_id=user_id,
            rationale=request.rationale,
            activate=request.activate,
            idempotency_key=request.idempotency_key,
            surface="rest",
        )
    except SwarmConstitutionRejected as exc:
        raise _rejected(exc) from exc


@router.get("", response_model=SwarmConstitutionListResponse)
async def list_swarm_constitutions(
    tenant_id: str = Depends(get_verified_tenant_id),
    service: SwarmConstitutionService = Depends(get_swarm_constitution_service_dependency),
) -> SwarmConstitutionListResponse:
    items = service.list_constitutions(tenant_id)
    return SwarmConstitutionListResponse(constitutions=items, count=len(items))


@router.get("/active", response_model=SwarmConstitution | None)
async def get_active_swarm_constitution(
    tenant_id: str = Depends(get_verified_tenant_id),
    service: SwarmConstitutionService = Depends(get_swarm_constitution_service_dependency),
) -> SwarmConstitution | None:
    return service.get_active_constitution(tenant_id)


@router.get("/{constitution_id}", response_model=SwarmConstitution)
async def get_swarm_constitution(
    constitution_id: str,
    version: int | None = Query(default=None, ge=1),
    tenant_id: str = Depends(get_verified_tenant_id),
    service: SwarmConstitutionService = Depends(get_swarm_constitution_service_dependency),
) -> SwarmConstitution:
    try:
        return service.get_constitution(tenant_id, constitution_id, version=version)
    except KeyError as exc:
        raise _not_found(exc) from exc


@router.patch("/{constitution_id}", response_model=SwarmConstitution)
async def update_swarm_constitution(
    constitution_id: str,
    request: SwarmConstitutionUpdateRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    service: SwarmConstitutionService = Depends(get_swarm_constitution_service_dependency),
) -> SwarmConstitution:
    try:
        return service.update_constitution(
            tenant_id=tenant_id,
            constitution_id=constitution_id,
            name=request.name,
            content=request.content,
            actor_id=user_id,
            rationale=request.rationale,
            idempotency_key=request.idempotency_key,
            surface="rest",
        )
    except SwarmConstitutionRejected as exc:
        raise _rejected(exc) from exc
    except KeyError as exc:
        raise _not_found(exc) from exc


@router.post("/{constitution_id}/versions/{version}/activate", response_model=SwarmConstitution)
async def activate_swarm_constitution_version(
    constitution_id: str,
    version: int,
    request: SwarmConstitutionActionRequest | None = None,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    service: SwarmConstitutionService = Depends(get_swarm_constitution_service_dependency),
) -> SwarmConstitution:
    body = request or SwarmConstitutionActionRequest()
    try:
        return service.activate_version(
            tenant_id=tenant_id,
            constitution_id=constitution_id,
            version=version,
            actor_id=user_id,
            rationale=body.rationale,
            idempotency_key=body.idempotency_key,
            surface="rest",
        )
    except KeyError as exc:
        raise _not_found(exc) from exc


@router.post("/{constitution_id}/deactivate", response_model=SwarmConstitution)
async def deactivate_swarm_constitution(
    constitution_id: str,
    request: SwarmConstitutionActionRequest | None = None,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    service: SwarmConstitutionService = Depends(get_swarm_constitution_service_dependency),
) -> SwarmConstitution:
    body = request or SwarmConstitutionActionRequest()
    try:
        return service.deactivate(
            tenant_id=tenant_id,
            constitution_id=constitution_id,
            actor_id=user_id,
            rationale=body.rationale,
        )
    except KeyError as exc:
        raise _not_found(exc) from exc


@router.delete("/{constitution_id}", response_model=SwarmConstitution)
async def delete_swarm_constitution(
    constitution_id: str,
    request: SwarmConstitutionActionRequest | None = None,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    service: SwarmConstitutionService = Depends(get_swarm_constitution_service_dependency),
) -> SwarmConstitution:
    body = request or SwarmConstitutionActionRequest()
    try:
        return service.delete_constitution(
            tenant_id=tenant_id,
            constitution_id=constitution_id,
            actor_id=user_id,
            rationale=body.rationale,
        )
    except KeyError as exc:
        raise _not_found(exc) from exc
