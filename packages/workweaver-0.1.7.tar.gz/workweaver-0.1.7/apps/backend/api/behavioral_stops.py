"""Behavioral Stop Controls API (Part 9.0B).

CRUD for tenant-level behavioral stops and emergency controls.
Every mutation emits an evidence receipt.
State persisted to DynamoDB (workweaver-tenants-{env}) — survives ECS restarts.

Routes:
    GET  /api/v1/behavioral-stops          — Get current stops for tenant
    PUT  /api/v1/behavioral-stops          — Update stops
    POST /api/v1/behavioral-stops/pause    — Emergency pause all execution
    POST /api/v1/behavioral-stops/resume   — Resume execution

Emergency Brake Routes (F-CP-006):
    POST /api/v1/emergency/halt            — Emergency halt all AI execution
    POST /api/v1/emergency/resume          — Resume after emergency halt
"""

from __future__ import annotations

import logging
from datetime import datetime, UTC
from typing import Any, Literal

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, ConfigDict, Field

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_id,
    require_admin_user_role,
    resolve_authenticated_impersonator_id,
)
from apps.backend.models.user import UserRole
import apps.backend.services.behavioral_stops_store as behavioral_stops_store
from apps.backend.services.behavioral_stops_store import (
    BehavioralStopsStoreError,
    _emit_evidence_receipt,
    _get_stops,
    _save_stops,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/behavioral-stops", tags=["behavioral-stops"])
_table = None


class BehavioralStopsRequest(BaseModel):
    """Request body for updating behavioral stops."""

    model_config = {"extra": "forbid"}

    model_config = ConfigDict(extra="forbid")

    pause_autonomy: bool | None = None
    blocked_tools: list[str] | None = None
    blocked_operation_types: list[str] | None = None

    quiet_hours_enabled: bool | None = None
    quiet_hours_start: str | None = None  # "HH:MM"
    quiet_hours_end: str | None = None  # "HH:MM"
    quiet_hours_blocked_types: list[str] | None = None

    interrupt_budget_enabled: bool | None = None
    max_notifications_per_day: int | None = None
    max_messages_per_hour: int | None = None

    learning_agility: Literal["conservative", "moderate", "aggressive"] | None = None
    adaptation_mode: Literal["manual_review", "recommend_reversible", "auto_reversible"] | None = None
    confirmation_mode: Literal["strict", "balanced", "light"] | None = None
    proactive_learning_enabled: bool | None = None
    signal_horizon: Literal["ephemeral", "seasonal", "durable"] | None = None
    drift_sensitivity: Literal["high", "medium", "low"] | None = None
    no_train: bool | None = None


class BehavioralStopsResponse(BaseModel):
    """Response body for behavioral stops."""

    paused: bool = False
    paused_at: str | None = None
    paused_by: str | None = None
    pause_reason: str | None = None
    pause_autonomy: bool = False
    pause_autonomy_at: str | None = None

    blocked_tools: list[str] = Field(default_factory=list)
    blocked_operation_types: list[str] = Field(default_factory=list)

    quiet_hours_enabled: bool = False
    quiet_hours_start: str | None = None
    quiet_hours_end: str | None = None
    quiet_hours_blocked_types: list[str] = Field(default_factory=list)

    interrupt_budget_enabled: bool = False
    max_notifications_per_day: int = 3
    max_messages_per_hour: int = 5

    learning_agility: Literal["conservative", "moderate", "aggressive"] = "moderate"
    adaptation_mode: Literal["manual_review", "recommend_reversible", "auto_reversible"] = "recommend_reversible"
    confirmation_mode: Literal["strict", "balanced", "light"] = "balanced"
    proactive_learning_enabled: bool = True
    signal_horizon: Literal["ephemeral", "seasonal", "durable"] = "seasonal"
    drift_sensitivity: Literal["high", "medium", "low"] = "medium"
    no_train: bool = True

    evidence_receipt: dict[str, Any] | None = None


class PauseRequest(BaseModel):
    """Request body for emergency pause."""

    model_config = ConfigDict(extra="forbid")

    reason: str = "manual_pause"


def _sync_legacy_table_override() -> None:
    """Honor legacy route-level table monkeypatches used by constitution tests."""
    if _table is not None:
        behavioral_stops_store._table = _table


@router.get("", response_model=BehavioralStopsResponse)
async def get_behavioral_stops(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> BehavioralStopsResponse:
    """Get current behavioral stops for a tenant."""
    _sync_legacy_table_override()
    stops = _get_stops(tenant_id)
    return BehavioralStopsResponse(**stops)


@router.put("", response_model=BehavioralStopsResponse)
async def update_behavioral_stops(
    request: Request,
    body: BehavioralStopsRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
    _admin: UserRole = Depends(require_admin_user_role),
) -> BehavioralStopsResponse:
    """Update behavioral stops for a tenant."""
    _sync_legacy_table_override()
    stops = _get_stops(tenant_id)
    before = dict(stops)

    # Apply updates (only set fields that were provided)
    update_fields = body.model_dump(exclude_unset=True)
    for key, value in update_fields.items():
        if key in stops:
            stops[key] = value
    if body.pause_autonomy is not None:
        stops["pause_autonomy_at"] = datetime.now(UTC).isoformat() if body.pause_autonomy else None

    try:
        _save_stops(tenant_id, stops)
    except BehavioralStopsStoreError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="behavioral_stops_storage_unavailable",
        ) from exc

    receipt = _emit_evidence_receipt(
        tenant_id=tenant_id,
        action="behavioral_stops_updated",
        before=before,
        after=dict(stops),
        actor=authenticated_user_id,
        impersonator_id=resolve_authenticated_impersonator_id(request),
    )

    return BehavioralStopsResponse(**stops, evidence_receipt=receipt)


@router.post("/pause", response_model=BehavioralStopsResponse)
async def emergency_pause(
    request: Request,
    body: PauseRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
    _admin: UserRole = Depends(require_admin_user_role),
) -> BehavioralStopsResponse:
    """Emergency pause all execution for a tenant."""
    _sync_legacy_table_override()
    stops = _get_stops(tenant_id)
    before = dict(stops)

    stops["paused"] = True
    stops["paused_at"] = datetime.now(UTC).isoformat()
    stops["paused_by"] = authenticated_user_id
    stops["pause_reason"] = body.reason

    try:
        _save_stops(tenant_id, stops)
    except BehavioralStopsStoreError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="behavioral_stops_storage_unavailable",
        ) from exc

    receipt = _emit_evidence_receipt(
        tenant_id=tenant_id,
        action="emergency_pause",
        before=before,
        after=dict(stops),
        actor=authenticated_user_id,
        impersonator_id=resolve_authenticated_impersonator_id(request),
    )

    logger.warning(
        "EMERGENCY PAUSE: tenant=%s reason=%s by=%s",
        tenant_id,
        body.reason,
        authenticated_user_id,
    )

    return BehavioralStopsResponse(**stops, evidence_receipt=receipt)


@router.post("/resume", response_model=BehavioralStopsResponse)
async def resume_execution(
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
    _admin: UserRole = Depends(require_admin_user_role),
) -> BehavioralStopsResponse:
    """Resume execution after emergency pause."""
    _sync_legacy_table_override()
    stops = _get_stops(tenant_id)
    before = dict(stops)

    stops["paused"] = False
    stops["paused_at"] = None
    stops["paused_by"] = None
    stops["pause_reason"] = None

    try:
        _save_stops(tenant_id, stops)
    except BehavioralStopsStoreError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="behavioral_stops_storage_unavailable",
        ) from exc

    receipt = _emit_evidence_receipt(
        tenant_id=tenant_id,
        action="execution_resumed",
        before=before,
        after=dict(stops),
        actor=authenticated_user_id,
        impersonator_id=resolve_authenticated_impersonator_id(request),
    )

    logger.info("Execution resumed: tenant=%s by=%s", tenant_id, authenticated_user_id)

    return BehavioralStopsResponse(**stops, evidence_receipt=receipt)


# ---------------------------------------------------------------------------
# Emergency Brake Router (F-CP-006)
# Separate router on /api/v1/emergency for the UI emergency brake button.
# Delegates to the same behavioral_stops_store so state is consistent.
# ---------------------------------------------------------------------------

emergency_router = APIRouter(prefix="/api/v1/emergency", tags=["emergency-brake"])


class EmergencyHaltRequest(BaseModel):
    """Request body for emergency halt."""

    model_config = ConfigDict(extra="forbid")

    reason: str = "emergency_brake_ui"


class EmergencyHaltResponse(BaseModel):
    """Response confirming the emergency halt or resume."""

    paused: bool
    paused_at: str | None = None
    paused_by: str | None = None
    pause_reason: str | None = None
    evidence_receipt: dict[str, Any] | None = None


@emergency_router.post("/halt", response_model=EmergencyHaltResponse)
async def emergency_halt(
    request: Request,
    body: EmergencyHaltRequest = EmergencyHaltRequest(),
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
    _admin: UserRole = Depends(require_admin_user_role),
) -> EmergencyHaltResponse:
    """Emergency halt all AI execution for a tenant (UI emergency brake).

    Sets paused=true in the behavioral stops store, logs the halt event,
    and returns confirmation with an evidence receipt.
    """
    _sync_legacy_table_override()
    stops = _get_stops(tenant_id)
    before = dict(stops)

    stops["paused"] = True
    stops["paused_at"] = datetime.now(UTC).isoformat()
    stops["paused_by"] = authenticated_user_id
    stops["pause_reason"] = body.reason

    try:
        _save_stops(tenant_id, stops)
    except BehavioralStopsStoreError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="behavioral_stops_storage_unavailable",
        ) from exc

    receipt = _emit_evidence_receipt(
        tenant_id=tenant_id,
        action="emergency_halt",
        before=before,
        after=dict(stops),
        actor=authenticated_user_id,
        impersonator_id=resolve_authenticated_impersonator_id(request),
    )

    logger.warning(
        "EMERGENCY HALT: tenant=%s reason=%s by=%s",
        tenant_id,
        body.reason,
        authenticated_user_id,
    )

    return EmergencyHaltResponse(
        paused=True,
        paused_at=stops["paused_at"],
        paused_by=stops["paused_by"],
        pause_reason=stops["pause_reason"],
        evidence_receipt=receipt,
    )


@emergency_router.post("/resume", response_model=EmergencyHaltResponse)
async def emergency_resume(
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
    _admin: UserRole = Depends(require_admin_user_role),
) -> EmergencyHaltResponse:
    """Resume AI execution after an emergency halt.

    Clears paused state in the behavioral stops store and returns confirmation.
    """
    _sync_legacy_table_override()
    stops = _get_stops(tenant_id)
    before = dict(stops)

    stops["paused"] = False
    stops["paused_at"] = None
    stops["paused_by"] = None
    stops["pause_reason"] = None

    try:
        _save_stops(tenant_id, stops)
    except BehavioralStopsStoreError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="behavioral_stops_storage_unavailable",
        ) from exc

    receipt = _emit_evidence_receipt(
        tenant_id=tenant_id,
        action="emergency_resume",
        before=before,
        after=dict(stops),
        actor=authenticated_user_id,
        impersonator_id=resolve_authenticated_impersonator_id(request),
    )

    logger.info("EMERGENCY RESUME: tenant=%s by=%s", tenant_id, authenticated_user_id)

    return EmergencyHaltResponse(
        paused=False,
        paused_at=None,
        paused_by=None,
        pause_reason=None,
        evidence_receipt=receipt,
    )
