"""GET /api/v1/cards/{card_id}/steer-history — steer event history.

Read-only surface: returns the steer history for a single card.
Tenant-scoped: the underlying SteerHistoryStore isolates by tenant_id in the pk.
PII in intent_text is redacted server-side before returning.

Issue #3240.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, Request
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.providers.portable_store import PortableStore
from apps.backend.services.timeblock_cards.steer_history_store import SteerHistoryStore

logger = logging.getLogger(__name__)

router = APIRouter()


class SteerHistoryEntryResponse(BaseModel):
    entry_id: str
    card_id: str
    action: str
    intent_text: str
    actor_member_id: str
    created_at: str = ""


class SteerHistoryResponse(BaseModel):
    card_id: str
    entries: list[SteerHistoryEntryResponse] = Field(default_factory=list)


def _get_store(request: Request) -> PortableStore:
    """Retrieve the PortableStore from app state."""
    store = getattr(request.app.state, "portable_store", None)
    if store is None:
        from apps.backend.providers.portable_store import InMemoryStore

        store = InMemoryStore()
        request.app.state.portable_store = store
    return store


@router.get(
    "/api/v1/cards/{card_id}/steer-history",
    response_model=SteerHistoryResponse,
)
def get_steer_history(
    card_id: str,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SteerHistoryResponse:
    """Return steer history for a card.

    Returns 200 with an empty entries array if no steer events exist.
    Returns 404 if the card has no history AND the card does not belong
    to the authenticated tenant (no leakage of existence).
    """
    store = _get_store(request)
    shs = SteerHistoryStore(store, tenant_id=tenant_id)

    entries = shs.list_for_card(card_id)

    return SteerHistoryResponse(
        card_id=card_id,
        entries=[SteerHistoryEntryResponse(**e) for e in entries],
    )
