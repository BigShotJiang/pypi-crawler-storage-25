"""Admin runtime diagnostics API."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.api.dependencies.tenant_auth import require_admin_user_role
from apps.backend.services.admin.admin_permission import AdminPermission
from apps.backend.services.runtime.startup_timeline import startup_timeline

router = APIRouter(
    prefix="/api/v1/admin/runtime",
    tags=["admin", "runtime"],
    dependencies=[
        Depends(require_admin_user_role),
        Depends(require_admin_permission_dep(AdminPermission.DIAGNOSTICS_READ)),
    ],
)


class StartupTimelineResponse(BaseModel):
    """Startup timeline response."""

    pod_id: str = Field(..., description="Current process or pod identifier.")
    limit: int
    phases: list[dict[str, Any]]


@router.get("/timeline", response_model=StartupTimelineResponse)
def get_runtime_startup_timeline(
    limit: int = Query(default=50, ge=1, le=200),
    phase: str | None = Query(default=None),
    status: str | None = Query(default=None),
    scope: str | None = Query(default=None),
) -> dict[str, Any]:
    """Return redacted runtime startup phase history for the current process."""
    phases = startup_timeline.snapshot(
        limit=limit,
        phase=phase,
        status=status,
        scope=scope,
    )
    pod_id = phases[-1]["pod_id"] if phases else "local-process"
    return {"pod_id": pod_id, "limit": limit, "phases": phases}
