"""Team Management API for Mission Control Part 17 — Team surface.

Provides endpoints for creating, managing, and organizing AI agents.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger(__name__)

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.schemas.error_response import safe_error_detail
from apps.backend.services.sessions.intake_queue import get_member_intake_queue

router = APIRouter(prefix="/api/v1/mission/team", tags=["team"])


# Request Models
class CreateAgentRequest(BaseModel):
    """Request to create a new AI agent."""

    name: str = Field(..., max_length=200, description="Agent name")
    role: str = Field(..., max_length=200, description="Agent role/title")
    job_description: str = Field(..., max_length=5000, description="What this agent does")
    parent_node_id: str | None = Field(None, max_length=100, description="Parent team node ID")
    skills: list[str] = Field(default_factory=list, description="Skill IDs")
    tools: list[dict[str, Any]] = Field(default_factory=list, description="Tool connections")
    rules: list[str] = Field(default_factory=list, description="Agent rules")
    success_criteria: list[str] = Field(default_factory=list, description="Success metrics")
    personality: dict[str, str] | None = Field(None, description="Personality settings (tone, proactivity, verbosity)")
    avatar_url: str | None = Field(None, description="Avatar image URL")
    identity_mode: str = Field("shared", description="Identity mode (shared|dedicated)")
    identity_config: dict[str, Any] | None = Field(None, description="Optional identity provisioning config")


class UpdateAgentRequest(BaseModel):
    """Request to update an agent profile."""

    name: str | None = Field(None, max_length=200, description="Updated name")
    role: str | None = Field(None, max_length=200, description="Updated role")
    job_description: str | None = Field(None, max_length=5000, description="Updated job description")
    skills: list[str] | None = Field(None, description="Updated skill IDs")
    tools: list[dict[str, Any]] | None = Field(None, description="Updated tool connections")
    rules: list[str] | None = Field(None, description="Updated rules")
    success_criteria: list[str] | None = Field(None, description="Updated success criteria")
    personality: dict[str, str] | None = Field(None, description="Updated personality")
    avatar_url: str | None = Field(None, max_length=2000, description="Updated avatar URL")
    identity_mode: str | None = Field(None, description="Updated identity mode (shared|dedicated)")
    identity_config: dict[str, Any] | None = Field(None, description="Optional identity provisioning config")


class UpdatePositionRequest(BaseModel):
    """Request to move agent to new position in org chart."""

    new_parent_id: str = Field(..., max_length=100, description="New parent team node ID")


class AssignSkillsRequest(BaseModel):
    """Request to assign skills to an agent."""

    skill_ids: list[str] = Field(..., description="Skill IDs to assign")


class AssignToolsRequest(BaseModel):
    """Request to assign tool connections to an agent."""

    tool_connections: list[dict[str, Any]] = Field(..., description="Tool connections to assign")


class CreateAgentFromNLRequest(BaseModel):
    """Request to create an agent from natural-language intent."""

    prompt: str = Field(..., min_length=10, max_length=10000)
    parent_node_id: str | None = Field(None, max_length=100, description="Optional existing team node")
    identity_mode: str = Field("shared", description="Identity mode (shared|dedicated)")


class AutoProvisionRequest(BaseModel):
    """Request to auto-create a team from a natural language description."""

    description: str = Field(..., min_length=10, max_length=5000, description="Natural language team description")
    connected_tools: list[str] = Field(default_factory=list, description="Tools already connected to the tenant")


class TeamSwarmRequest(BaseModel):
    """Request to run a structurally defined team as a self-organizing swarm."""

    coordination_protocol: str = Field("auto", description="Coordination protocol (auto|sequential|parallel|pipeline)")
    budget_usd: float = Field(50.0, gt=0, le=500, description="Budget for swarm execution in USD")
    max_depth: int = Field(2, ge=0, le=8, description="Maximum delegation depth")


class AutoProvisionResponse(BaseModel):
    """Response for auto-provisioned Work Function."""

    function_name: str | None = None
    agents: list[dict[str, Any]] = Field(default_factory=list)
    blueprint: dict[str, Any] = Field(default_factory=dict)


class TeamSwarmResponse(BaseModel):
    """Response for running a team as a swarm."""

    team_node_id: str
    envelope: dict[str, Any] = Field(default_factory=dict)
    agent_ids: list[str] = Field(default_factory=list)
    recommendation: dict[str, Any] | None = None


# Response Models
class AgentProfileResponse(BaseModel):
    """Response for agent profile."""

    agent_id: str
    name: str
    role: str
    job_description: str
    status: str
    identity_mode: str = "shared"
    identity_status: str = "ready"
    identity: dict[str, Any] = Field(default_factory=dict)
    skills: list[str] = Field(default_factory=list)
    tools: list[dict[str, Any]] = Field(default_factory=list)
    rules: list[str] = Field(default_factory=list)
    success_criteria: list[str] = Field(default_factory=list)
    personality: dict[str, str] | None = Field(default_factory=dict)
    avatar_url: str = ""
    stats: dict[str, Any] | None = Field(default_factory=dict)
    intake_queue: dict[str, Any] = Field(default_factory=dict)
    parent_node_id: str | None = None
    created_at: str = ""
    updated_at: str = ""
    revision: int = 1
    metatype: str | None = Field(None, description="H3.0 metatype string (computed, read-only)")
    developmental_profile: dict[str, Any] | None = Field(None, description="Full developmental profile (Part 21)")


class AgentListResponse(BaseModel):
    """Response for list of agents."""

    agents: list[AgentProfileResponse]
    count: int


class StatsResponse(BaseModel):
    """Response for agent performance stats."""

    tasks_completed: int = 0
    time_saved_hours: float = 0.0
    last_active_at: str | None = None


class OrgChartResponse(BaseModel):
    """Response for org chart."""

    tenant_id: str
    roots: list[dict[str, Any]]
    total_nodes: int


class NLCreateAgentResponse(BaseModel):
    """Response for NL agent creation into org graph."""

    agent: AgentProfileResponse
    org_node_id: str = ""
    department_node_id: str = ""
    team_node_id: str = ""
    created_nodes: list[dict[str, Any]] = Field(default_factory=list)


# Lazy import helpers
def _get_store():
    """Lazy import agent profile store to avoid circular dependencies."""
    from apps.backend.services.agent_profile_store import get_agent_profile_store

    return get_agent_profile_store()


def _get_dev_intel():
    """Lazy import developmental intelligence service."""
    from apps.backend.services.developmental_intelligence import (
        get_developmental_intelligence_service,
    )

    return get_developmental_intelligence_service()


def _get_identity_provisioner():
    from apps.backend.services.identity_provisioner import get_identity_provisioner

    return get_identity_provisioner()


def _get_identity_governance():
    from apps.backend.services.agent_identity_governance import get_agent_identity_governance

    return get_agent_identity_governance()


def _get_nl_creator(store):
    from apps.backend.services.nl_agent_creator import NaturalLanguageAgentCreator as NaturalLanguageEmployeeCreator

    return NaturalLanguageEmployeeCreator(
        node_store=store._nodes,  # noqa: SLF001 - store exposes node-store-backed behavior
        profile_store=store,
        identity_governance=_get_identity_governance(),
    )


def _get_auto_team_provisioner():
    from apps.backend.services.work_function_preset import get_work_function_preset_resolver

    return get_work_function_preset_resolver()


def _get_topology_swarm_bridge():
    from apps.backend.services.topology_swarm_bridge import get_topology_swarm_bridge

    return get_topology_swarm_bridge()


def _enrich_with_metatype(agent: dict[str, Any], tenant_id: str) -> dict[str, Any]:
    """Enrich agent profile dict with computed metatype (best-effort)."""
    try:
        svc = _get_dev_intel()
        ctx = svc.get_developmental_context(tenant_id, agent["agent_id"], entity_type="agent")
        agent["metatype"] = ctx.metatype_string
        agent["developmental_profile"] = ctx.to_dict()
    except Exception:
        # Non-blocking: metatype is enrichment, not critical
        agent.setdefault("metatype", None)
        agent.setdefault("developmental_profile", None)
    return agent


def _enrich_with_intake_queue(agent: dict[str, Any], tenant_id: str) -> dict[str, Any]:
    agent_id = str(agent.get("agent_id") or "").strip()
    if not agent_id:
        agent["intake_queue"] = {}
        return agent
    try:
        agent["intake_queue"] = get_member_intake_queue().stats(
            workspace_id=tenant_id,
            member_id=agent_id,
        ).to_response()
    except Exception:
        logger.exception("Failed to read intake queue stats for tenant=%s agent=%s", tenant_id, agent_id)
        agent["intake_queue"] = {}
    return agent


@router.post("/agents", response_model=AgentProfileResponse, status_code=201)
async def create_agent(
    request: CreateAgentRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    store=Depends(_get_store),
):
    """Create a new AI agent."""
    try:
        governance = _get_identity_governance()
        identity_mode = governance.normalize_mode(request.identity_mode, default="shared")
        agent = store.create_agent(
            tenant_id=tenant_id,
            name=request.name,
            role=request.role,
            job_description=request.job_description,
            parent_node_id=request.parent_node_id,
            skills=request.skills,
            tools=request.tools,
            rules=request.rules,
            success_criteria=request.success_criteria,
            personality=request.personality,
            avatar_url=request.avatar_url,
            identity_mode=identity_mode,
        )

        identity_cfg = request.identity_config or governance.default_identity_config(name=request.name)
        try:
            identity_service = _get_identity_provisioner()
            if identity_mode == "dedicated":
                identity_result = await identity_service.provision_full_identity(
                    agent_id=agent["agent_id"],
                    tenant_id=tenant_id,
                    config=identity_cfg,
                )
            else:
                identity_result = await identity_service.provision_shared_identity(
                    agent_id=agent["agent_id"],
                    tenant_id=tenant_id,
                    config=identity_cfg,
                )
        except Exception as exc:
            identity_result = {
                "identity_mode": identity_mode,
                "status": "failed",
                "error": str(exc),
            }

        agent = store.set_identity_state(
            tenant_id=tenant_id,
            agent_id=agent["agent_id"],
            identity_mode=str(identity_result.get("identity_mode", identity_mode)),
            identity_status=str(identity_result.get("status", "unknown")),
            identity=dict(identity_result),
        )

        return AgentProfileResponse(**agent)

    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to create agent")


@router.get("/agents", response_model=AgentListResponse)
async def list_agents(
    tenant_id: str = Depends(get_verified_tenant_id),
    store=Depends(_get_store),
    status: str | None = Query(None, description="Optional agent status filter"),
    limit: int = Query(100, ge=1, le=500, description="Max agents to return"),
):
    """List all AI agents for a tenant."""
    try:
        agents = store.list_agents(tenant_id)
        if status:
            normalized = status.strip().lower()
            agents = [agent for agent in agents if str(agent.get("status", "")).strip().lower() == normalized]
        agents = agents[:limit]

        enriched = [_enrich_with_intake_queue(dict(a), tenant_id) for a in agents]

        return AgentListResponse(agents=[AgentProfileResponse(**a) for a in enriched], count=len(enriched))

    except Exception as exc:
        logger.exception("Failed to list agents for tenant=%s: %s", tenant_id, exc)
        raise HTTPException(status_code=500, detail="Failed to list agents")


@router.get("/agents/{agent_id}", response_model=AgentProfileResponse)
async def get_agent(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    store=Depends(_get_store),
):
    """Get agent profile by ID, enriched with developmental intelligence."""
    try:
        agent = store.get_agent(tenant_id, agent_id)

        if not agent:
            raise HTTPException(status_code=404, detail=f"Agent {agent_id} not found")

        agent = _enrich_with_metatype(agent, tenant_id)
        return AgentProfileResponse(**agent)

    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to get agent")


@router.patch("/agents/{agent_id}", response_model=AgentProfileResponse)
async def update_agent(
    agent_id: str,
    request: UpdateAgentRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    store=Depends(_get_store),
):
    """Update agent profile."""
    try:
        # Build updates dict from non-None fields
        updates = {}
        if request.name is not None:
            updates["name"] = request.name
        if request.role is not None:
            updates["role"] = request.role
        if request.job_description is not None:
            updates["job_description"] = request.job_description
        if request.skills is not None:
            updates["skills"] = request.skills
        if request.tools is not None:
            updates["tools"] = request.tools
        if request.rules is not None:
            updates["rules"] = request.rules
        if request.success_criteria is not None:
            updates["success_criteria"] = request.success_criteria
        if request.personality is not None:
            updates["personality"] = request.personality
        if request.avatar_url is not None:
            updates["avatar_url"] = request.avatar_url
        if request.identity_mode is not None:
            updates["identity_mode"] = request.identity_mode

        agent = store.update_agent(tenant_id, agent_id, updates)

        if request.identity_mode is not None:
            governance = _get_identity_governance()
            target_mode = governance.normalize_mode(request.identity_mode)
            if target_mode == "dedicated":
                identity_cfg = request.identity_config or governance.default_identity_config(name=agent["name"])
                try:
                    identity_service = _get_identity_provisioner()
                    identity_result = await identity_service.elevate_to_dedicated(
                        agent_id=agent_id,
                        tenant_id=tenant_id,
                        config=identity_cfg,
                    )
                except Exception as exc:
                    identity_result = {"identity_mode": "dedicated", "status": "failed", "error": str(exc)}
                agent = store.set_identity_state(
                    tenant_id=tenant_id,
                    agent_id=agent_id,
                    identity_mode="dedicated",
                    identity_status=str(identity_result.get("status", "unknown")),
                    identity=dict(identity_result),
                )

        return AgentProfileResponse(**agent)

    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to update agent")


@router.delete("/agents/{agent_id}")
async def delete_agent(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    store=Depends(_get_store),
):
    """Delete (deactivate) an AI agent."""
    try:
        success = store.delete_agent(tenant_id, agent_id)

        if not success:
            raise HTTPException(status_code=404, detail=f"Agent {agent_id} not found")

        return {"deleted": True}

    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to delete agent")


@router.post("/agents/{agent_id}/pause", response_model=AgentProfileResponse)
async def pause_agent(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    store=Depends(_get_store),
):
    """Pause an AI agent."""
    try:
        agent = store.pause_agent(tenant_id, agent_id)
        return AgentProfileResponse(**agent)

    except Exception:
        raise HTTPException(status_code=500, detail="Failed to pause agent")


@router.post("/agents/{agent_id}/resume", response_model=AgentProfileResponse)
async def resume_agent(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    store=Depends(_get_store),
):
    """Resume a paused AI agent."""
    try:
        agent = store.resume_agent(tenant_id, agent_id)
        return AgentProfileResponse(**agent)

    except Exception:
        raise HTTPException(status_code=500, detail="Failed to resume agent")


@router.get("/org-chart", response_model=OrgChartResponse)
async def get_org_chart(
    tenant_id: str = Depends(get_verified_tenant_id),
    store=Depends(_get_store),
):
    """Get organization chart structure."""
    try:
        tree = store.get_org_chart(tenant_id)

        return OrgChartResponse(
            tenant_id=tree.get("tenant_id", tenant_id),
            roots=tree.get("roots", []),
            total_nodes=tree.get("total_nodes", 0),
        )

    except Exception:
        raise HTTPException(status_code=500, detail="Failed to get org chart")


@router.patch("/agents/{agent_id}/position", response_model=AgentProfileResponse)
async def update_org_position(
    agent_id: str,
    request: UpdatePositionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    store=Depends(_get_store),
):
    """Move agent to new position in org chart."""
    try:
        agent = store.update_org_position(tenant_id, agent_id, request.new_parent_id)
        return AgentProfileResponse(**agent)

    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to update org position")


@router.get("/agents/{agent_id}/stats", response_model=StatsResponse)
async def get_agent_stats(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    store=Depends(_get_store),
):
    """Get performance statistics for an agent."""
    try:
        stats = store.get_agent_stats(tenant_id, agent_id)

        return StatsResponse(
            tasks_completed=stats.get("tasks_completed", 0),
            time_saved_hours=stats.get("time_saved_hours", 0.0),
            last_active_at=stats.get("last_active_at"),
        )

    except ValueError as e:
        raise HTTPException(status_code=404, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to get stats")


@router.get("/agents/{agent_id}/development")
async def get_agent_development(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    store=Depends(_get_store),
):
    """Get developmental intelligence profile for an agent (PR-T2.10).

    Returns DI profile with per-quadrant scores, overall level,
    and autonomy recommendation based on Constitution Axiom 2.
    """
    try:
        agent = store.get_agent(tenant_id, agent_id)
        if not agent:
            raise HTTPException(status_code=404, detail=f"Agent {agent_id} not found")

        svc = _get_dev_intel()
        profile = svc.compute_profile(tenant_id, agent_id)
        recommendation = svc.get_autonomy_recommendation(profile)

        return {
            "agent_id": agent_id,
            "profile": profile.to_dict(),
            "autonomy_recommendation": recommendation,
        }

    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to compute developmental profile")


@router.get("/agents/{agent_id}/di")
async def get_agent_di(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    store=Depends(_get_store),
):
    """Get the aggregate DI score that gates self-organizing planning."""
    try:
        agent = store.get_agent(tenant_id, agent_id)
        if not agent:
            raise HTTPException(status_code=404, detail=f"Agent {agent_id} not found")

        score = _get_dev_intel().compute(agent_id=agent_id, tenant_id=tenant_id)
        return score.to_dict()
    except HTTPException:
        raise
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to compute DI score")


@router.put("/agents/{agent_id}/skills", response_model=AgentProfileResponse)
async def assign_skills(
    agent_id: str,
    request: AssignSkillsRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    store=Depends(_get_store),
):
    """Assign skills to an agent."""
    try:
        agent = store.assign_skills(tenant_id, agent_id, request.skill_ids)
        return AgentProfileResponse(**agent)

    except ValueError as e:
        raise HTTPException(status_code=404, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to assign skills")


@router.put("/agents/{agent_id}/tools", response_model=AgentProfileResponse)
async def assign_tools(
    agent_id: str,
    request: AssignToolsRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    store=Depends(_get_store),
):
    """Assign tool connections to an agent."""
    try:
        agent = store.assign_tools(tenant_id, agent_id, request.tool_connections)
        return AgentProfileResponse(**agent)

    except ValueError as e:
        raise HTTPException(status_code=404, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to assign tools")


@router.post("/agents/nl-create", response_model=NLCreateAgentResponse, status_code=201)
async def create_agent_from_nl(
    request: CreateAgentFromNLRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    store=Depends(_get_store),
):
    """Create AI agent from natural language and place into structured org graph."""
    try:
        creator = _get_nl_creator(store)
        result = creator.create_agent(
            tenant_id=tenant_id,
            prompt=request.prompt,
            identity_mode=request.identity_mode,
            parent_node_id=request.parent_node_id,
        )
        agent = result["agent"]

        governance = _get_identity_governance()
        identity_mode = governance.normalize_mode(agent.get("identity_mode"))
        identity_cfg = governance.default_identity_config(name=agent["name"])
        try:
            identity_service = _get_identity_provisioner()
            if identity_mode == "dedicated":
                identity_result = await identity_service.provision_full_identity(
                    agent_id=agent["agent_id"],
                    tenant_id=tenant_id,
                    config=identity_cfg,
                )
            else:
                identity_result = await identity_service.provision_shared_identity(
                    agent_id=agent["agent_id"],
                    tenant_id=tenant_id,
                    config=identity_cfg,
                )
        except Exception as exc:
            identity_result = {
                "identity_mode": identity_mode,
                "status": "failed",
                "error": str(exc),
            }
        agent = store.set_identity_state(
            tenant_id=tenant_id,
            agent_id=agent["agent_id"],
            identity_mode=str(identity_result.get("identity_mode", identity_mode)),
            identity_status=str(identity_result.get("status", "unknown")),
            identity=dict(identity_result),
        )

        return NLCreateAgentResponse(
            agent=AgentProfileResponse(**agent),
            org_node_id=str(result.get("org_node_id", "")),
            department_node_id=str(result.get("department_node_id", "")),
            team_node_id=str(result.get("team_node_id", "")),
            created_nodes=list(result.get("created_nodes") or []),
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to create NL agent")


@router.post("/auto-provision", response_model=AutoProvisionResponse, status_code=201)
async def auto_provision_team(
    body: AutoProvisionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Auto-create a Work Function from a natural language description.

    Generates a Function blueprint from the description, then provisions
    agents using the NL agent creator.
    """
    try:
        provisioner = _get_auto_team_provisioner()
        blueprint = provisioner.generate_blueprint(
            body.description, connected_tools=body.connected_tools
        )
        result = await provisioner.provision(tenant_id, blueprint)

        return AutoProvisionResponse(
            function_name=result.get("function_name"),
            agents=result.get("agents", []),
            blueprint={
                "function_name": blueprint.function_name,
                "agents_planned": len(blueprint.agents),
                "tools_required": blueprint.tools_required,
                "rationale": blueprint.rationale,
            },
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to auto-provision team")


@router.post("/teams/{team_id}/run-as-swarm", response_model=TeamSwarmResponse)
async def run_team_as_swarm(
    team_id: str,
    body: TeamSwarmRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Run a structurally defined team as a self-organizing swarm.

    Creates a ConstraintEnvelope scoped to the team's agents,
    enabling self-organization within the team's structural boundaries.
    """
    try:
        bridge = _get_topology_swarm_bridge()
        agent_ids = bridge.get_team_agents(tenant_id, team_id)

        from apps.backend.services.topology_swarm_bridge import TeamSwarmConfig

        config = TeamSwarmConfig(
            team_node_id=team_id,
            tenant_id=tenant_id,
            agent_ids=agent_ids,
            coordination_protocol=body.coordination_protocol,
            budget_usd=body.budget_usd,
            max_depth=body.max_depth,
        )
        envelope = bridge.build_team_envelope(config)
        recommendation = bridge.recommend_restructuring(tenant_id, team_id, {})

        return TeamSwarmResponse(
            team_node_id=team_id,
            envelope={
                "max_agents": envelope.max_agents,
                "max_depth": envelope.max_depth,
                "budget_usd": envelope.budget_usd,
                "memory_scope": envelope.memory_scope,
                "coordination_protocol": envelope.coordination_protocol,
                "allow_self_organization": envelope.allow_self_organization,
            },
            agent_ids=agent_ids,
            recommendation=recommendation,
        )
    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception:
        raise HTTPException(status_code=500, detail="Failed to run team as swarm")
