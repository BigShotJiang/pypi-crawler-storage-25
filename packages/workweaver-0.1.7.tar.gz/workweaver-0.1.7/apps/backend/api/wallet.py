"""Wallet policy + transactions REST surface.

Endpoints are tenant-scoped. As of issue #3625 the wallet surface supports
multiple wallets per Zara — every read/write keyed by ``wallet_id``:

- GET  /api/v1/wallet/policies                       list all wallets.
- GET  /api/v1/wallet/policy/{wallet_id}             single wallet policy.
- PUT  /api/v1/wallet/policy/{wallet_id}             upsert a wallet policy.
- GET  /api/v1/wallet/policy                         alias → default wallet.
- PUT  /api/v1/wallet/policy                         alias → default wallet.
- GET  /api/v1/wallet/transactions                   list pending / signed transactions.
- POST /api/v1/wallet/transactions/{id}/sign         attempt to sign — preflight gated.

The bare ``/wallet/policy`` (no path id) and the legacy un-scoped transaction
routes resolve to ``wallet_id="default"`` and carry a
``Deprecation: true`` response header so admin clients can migrate at their
own pace.

Reads route through :class:`WalletPolicyService`. Writes emit Decision Trace
entries via DecisionEventCaptureService. The sign endpoint runs the canonical
payment-preflight envelope before any state change.
"""

from __future__ import annotations

import re
from decimal import Decimal, InvalidOperation
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Path, Query, Response, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_email,
    require_admin_user_role,
)
from apps.backend.models.crypto_wallet_policy import (
    CryptoWalletPolicy,
    WalletAddressAllowlistEntry,
)
from apps.backend.services.admin.admin_permission import AdminPermission
from apps.backend.services.wallet.wallet_policy_service import (
    DEFAULT_WALLET_ID,
    WalletDecisionTraceError,
    WalletPolicyDenied,
    WalletPolicyNotFoundError,
    WalletPolicyService,
    WalletTransactionNotFoundError,
    get_wallet_policy_service,
)

router = APIRouter(prefix="/api/v1/wallet", tags=["wallet"])

# Wallet identifiers must round-trip through SK keys + URL paths without
# ambiguity. Limit to alphanumerics, dash, underscore, dot, colon.
_WALLET_ID_RE = re.compile(r"^[A-Za-z0-9._:-]{1,64}$")


def _validate_wallet_id(wallet_id: str) -> str:
    candidate = (wallet_id or "").strip()
    if not _WALLET_ID_RE.match(candidate):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_wallet_id",
                "wallet_id": wallet_id,
            },
        )
    return candidate


def _get_decision_capture() -> Any:
    from apps.backend.services.context.decision_event_capture import (
        DecisionEventCaptureService,
    )

    return DecisionEventCaptureService()


def _capture_failed(result: Any) -> bool:
    return bool(result is not None and getattr(result, "success", True) is False)


def _trace_unavailable(*, wallet_id: str) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail={
            "error": "wallet_decision_trace_unavailable",
            "wallet_id": wallet_id,
            "retryable": True,
        },
    )


# ---------------------------------------------------------------------------
# Pydantic payloads
# ---------------------------------------------------------------------------


class WalletAllowlistEntryPayload(BaseModel):
    chain_family: str = Field(..., min_length=1, max_length=64)
    network_id: str = Field(..., min_length=1, max_length=64)
    address: str = Field(..., min_length=1, max_length=128)


class WalletPolicyPayload(BaseModel):
    daily_cap_usd: str = Field("0", description="Daily cap as a decimal string.")
    approval_threshold_usd: str = Field("0", description="Multi-approver threshold (decimal).")
    max_slippage_bps: int = Field(300, ge=0, le=10000)
    allowlisted_addresses: list[WalletAllowlistEntryPayload] = Field(default_factory=list)
    mev_protection_required: bool = True
    mev_threshold_usd: str = Field("1000")
    allowed_chain_families: list[str] = Field(default_factory=list)
    compliance_screening_enabled: bool = True
    enabled: bool = False


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("/policies")
async def list_wallet_policies(
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.WALLET_READ)),
    tenant_id: str = Depends(get_verified_tenant_id),
    service: WalletPolicyService = Depends(get_wallet_policy_service),
) -> dict[str, Any]:
    """Return every wallet policy row owned by the caller's tenant.

    Each entry is a serialized :class:`CryptoWalletPolicy` payload carrying
    its ``wallet_id``. An empty list means no wallets have been
    provisioned — the identity aggregator surfaces that as the wallet
    capability being un-provisioned (see issue #3625).
    """

    del admin_role
    wallets = service.list_policies(tenant_id)
    return {
        "tenant_id": tenant_id,
        "wallets": wallets,
        "count": len(wallets),
    }


@router.get("/policy/{wallet_id}")
async def get_wallet_policy_by_id(
    wallet_id: str = Path(..., min_length=1, max_length=64),
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.WALLET_READ)),
    tenant_id: str = Depends(get_verified_tenant_id),
    service: WalletPolicyService = Depends(get_wallet_policy_service),
) -> dict[str, Any]:
    """Return the specific wallet's policy row."""

    del admin_role
    wid = _validate_wallet_id(wallet_id)
    try:
        policy = service.get_policy_row(tenant_id, wallet_id=wid)
    except WalletPolicyNotFoundError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={"error": "wallet_policy_not_found", "wallet_id": wid},
        ) from exc
    payload = policy.to_dict()
    payload["wallet_id"] = wid
    return payload


@router.put("/policy/{wallet_id}")
async def put_wallet_policy_by_id(
    body: WalletPolicyPayload,
    wallet_id: str = Path(..., min_length=1, max_length=64),
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.WALLET_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_email: str = Depends(get_verified_user_email),
    service: WalletPolicyService = Depends(get_wallet_policy_service),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    """Upsert a wallet policy keyed by ``wallet_id``."""

    del admin_role
    wid = _validate_wallet_id(wallet_id)
    policy = _payload_to_policy(body, tenant_id=tenant_id)
    try:
        capture_result = decision_capture.capture_decision(
            tenant_id=tenant_id,
            skill_id="wallet.policy.set",
            decision_summary=(
                f"Allowed wallet policy update wallet_id={wid} enabled={body.enabled}"
            ),
            decision_type="wallet_policy_update",
            outcome="allowed",
            entity_ids=[tenant_id, wid],
            rationale=f"Policy update by {actor_email or 'admin'}",
            context_data={
                "wallet_id": wid,
                "enabled": body.enabled,
                "daily_cap_usd": body.daily_cap_usd,
                "compliance_screening_enabled": body.compliance_screening_enabled,
            },
            capture_surface="rest",
            service_family="wallet_policy",
        )
    except Exception as exc:  # noqa: BLE001
        raise _trace_unavailable(wallet_id=wid) from exc
    if _capture_failed(capture_result):
        raise _trace_unavailable(wallet_id=wid)

    saved = service.set_policy(
        tenant_id, policy, actor=actor_email or "admin", wallet_id=wid
    )

    payload = saved.to_dict()
    payload["wallet_id"] = wid
    return payload


@router.get("/policy")
async def get_wallet_policy(
    response: Response,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.WALLET_READ)),
    tenant_id: str = Depends(get_verified_tenant_id),
    service: WalletPolicyService = Depends(get_wallet_policy_service),
) -> dict[str, Any]:
    """Deprecated alias — resolves to the ``default`` wallet (issue #3625)."""

    del admin_role
    response.headers["Deprecation"] = "true"
    response.headers["Link"] = (
        f'</api/v1/wallet/policy/{DEFAULT_WALLET_ID}>; rel="successor-version"'
    )
    policy = service.get_policy(tenant_id, wallet_id=DEFAULT_WALLET_ID)
    payload = policy.to_dict()
    payload["wallet_id"] = DEFAULT_WALLET_ID
    return payload


@router.put("/policy")
async def put_wallet_policy(
    body: WalletPolicyPayload,
    response: Response,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.WALLET_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_email: str = Depends(get_verified_user_email),
    service: WalletPolicyService = Depends(get_wallet_policy_service),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    """Deprecated alias — writes the ``default`` wallet (issue #3625)."""

    del admin_role
    response.headers["Deprecation"] = "true"
    response.headers["Link"] = (
        f'</api/v1/wallet/policy/{DEFAULT_WALLET_ID}>; rel="successor-version"'
    )
    policy = _payload_to_policy(body, tenant_id=tenant_id)
    try:
        capture_result = decision_capture.capture_decision(
            tenant_id=tenant_id,
            skill_id="wallet.policy.set",
            decision_summary=(
                f"Allowed wallet policy update wallet_id={DEFAULT_WALLET_ID} enabled={body.enabled}"
            ),
            decision_type="wallet_policy_update",
            outcome="allowed",
            entity_ids=[tenant_id, DEFAULT_WALLET_ID],
            rationale=f"Policy update by {actor_email or 'admin'}",
            context_data={
                "wallet_id": DEFAULT_WALLET_ID,
                "enabled": body.enabled,
                "daily_cap_usd": body.daily_cap_usd,
                "compliance_screening_enabled": body.compliance_screening_enabled,
                "deprecation_alias": True,
            },
            capture_surface="rest",
            service_family="wallet_policy",
        )
    except Exception as exc:  # noqa: BLE001
        raise _trace_unavailable(wallet_id=DEFAULT_WALLET_ID) from exc
    if _capture_failed(capture_result):
        raise _trace_unavailable(wallet_id=DEFAULT_WALLET_ID)

    saved = service.set_policy(
        tenant_id, policy, actor=actor_email or "admin", wallet_id=DEFAULT_WALLET_ID
    )

    payload = saved.to_dict()
    payload["wallet_id"] = DEFAULT_WALLET_ID
    return payload


@router.get("/transactions")
async def list_wallet_transactions(
    cursor: Annotated[str | None, Query(description="Pagination cursor.")] = None,
    tx_status: Annotated[
        str | None,
        Query(alias="status", description="Filter by status: pending|signed|denied|failed"),
    ] = None,
    wallet_id: Annotated[
        str | None,
        Query(description="Filter by wallet_id; omit to scan all wallets."),
    ] = None,
    limit: Annotated[int, Query(ge=1, le=500)] = 50,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.WALLET_READ)),
    tenant_id: str = Depends(get_verified_tenant_id),
    service: WalletPolicyService = Depends(get_wallet_policy_service),
) -> dict[str, Any]:
    """List wallet transactions for the caller's tenant."""

    del admin_role
    resolved_wid = _validate_wallet_id(wallet_id) if wallet_id else None
    return service.list_transactions(
        tenant_id,
        wallet_id=resolved_wid,
        status_filter=tx_status,
        cursor=cursor,
        limit=limit,
    )


@router.post("/transactions/{tx_id}/sign")
async def sign_wallet_transaction(
    tx_id: str,
    wallet_id: Annotated[
        str | None,
        Query(description="Optional wallet scope for the sign call."),
    ] = None,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.WALLET_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_email: str = Depends(get_verified_user_email),
    service: WalletPolicyService = Depends(get_wallet_policy_service),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    """Sign a pending wallet transaction (preflight-gated)."""

    del admin_role
    resolved_wid = _validate_wallet_id(wallet_id) if wallet_id else None
    try:
        result = service.sign_transaction(
            tenant_id,
            tx_id,
            actor=actor_email or "admin",
            wallet_id=resolved_wid,
            decision_capture=decision_capture,
        )
    except WalletTransactionNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    except WalletDecisionTraceError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "wallet_decision_trace_unavailable",
                "tx_id": tx_id,
                "retryable": True,
            },
        ) from exc
    except WalletPolicyDenied as exc:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": "wallet_policy_denied", "envelope": exc.envelope},
        ) from exc

    return result


def _parse_decimal_field(value: str, *, field: str) -> Decimal:
    """Convert a string payload field to ``Decimal`` with structured 400 on failure.

    Codex review #3621 F13 — ``Decimal(...)`` raises ``InvalidOperation`` on
    malformed strings, which bubbled out as a 500. Callers expect 400 with
    field-level detail so the admin UI can surface the validation error
    inline.
    """

    raw = value if value is not None else ""
    try:
        return Decimal(raw)
    except (InvalidOperation, ValueError) as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error_code": "invalid_decimal",
                "field": field,
                "value": str(raw),
            },
        ) from exc


def _payload_to_policy(payload: WalletPolicyPayload, *, tenant_id: str) -> CryptoWalletPolicy:
    """Convert the validated Pydantic payload into the domain dataclass."""

    from apps.backend.models.chain_tx_evidence import ChainFamily

    def _resolve_chain(value: str) -> ChainFamily | None:
        try:
            return ChainFamily(str(value))
        except Exception:  # noqa: BLE001
            return None

    allowlisted: list[WalletAddressAllowlistEntry] = []
    for entry in payload.allowlisted_addresses or []:
        family = _resolve_chain(entry.chain_family)
        if family is None:
            continue
        allowlisted.append(
            WalletAddressAllowlistEntry(
                chain_family=family,
                network_id=entry.network_id,
                address=entry.address,
            )
        )
    allowed_chains = [
        family for family in (_resolve_chain(v) for v in payload.allowed_chain_families)
        if family is not None
    ]
    return CryptoWalletPolicy(
        tenant_id=tenant_id,
        daily_cap_usd=_parse_decimal_field(payload.daily_cap_usd, field="daily_cap_usd"),
        approval_threshold_usd=_parse_decimal_field(
            payload.approval_threshold_usd, field="approval_threshold_usd"
        ),
        max_slippage_bps=payload.max_slippage_bps,
        allowlisted_addresses=allowlisted,
        time_windows=[],
        mev_protection_required=payload.mev_protection_required,
        mev_threshold_usd=_parse_decimal_field(
            payload.mev_threshold_usd, field="mev_threshold_usd"
        ),
        allowed_chain_families=allowed_chains,
        compliance_screening_enabled=payload.compliance_screening_enabled,
        enabled=payload.enabled,
    )
