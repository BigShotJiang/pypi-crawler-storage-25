"""Canonical platform-admin / founder allowlist helpers."""

from __future__ import annotations

import os

from apps.backend.config.environment import is_development, is_test

_DEFAULT_PLATFORM_ADMIN_EMAILS = frozenset(
    {
        "santhanakrishnan@bitfoundry.ai",
        "aditya.koushik@bitfoundry.ai",
    }
)


def _allow_baked_platform_admins() -> bool:
    explicit = str(os.getenv("WORKWEAVER_ALLOW_DEFAULT_PLATFORM_ADMINS") or "").strip().lower()
    if explicit in {"1", "true", "yes", "on"}:
        return True
    if str(os.getenv("DISABLE_COGNITO") or "").strip() == "1":
        return True
    return is_development() or is_test()


def platform_admin_emails() -> frozenset[str]:
    """Return the canonical lowercase platform-admin email allowlist.

    ``WORKWEAVER_ADMIN_EMAILS`` is the operator-configurable source of truth.
    The baked-in fallback exists only for explicitly local/test-style execution.
    """

    admin_emails_raw = os.getenv("WORKWEAVER_ADMIN_EMAILS", "")
    admin_emails = {
        email.strip().lower()
        for email in admin_emails_raw.split(",")
        if email.strip()
    }
    if admin_emails:
        return frozenset(admin_emails)
    if _allow_baked_platform_admins():
        return _DEFAULT_PLATFORM_ADMIN_EMAILS
    return frozenset()


def is_platform_admin_email(email: str | None) -> bool:
    normalized = str(email or "").strip().lower()
    if not normalized:
        return False
    if normalized in platform_admin_emails():
        return True
    return normalized.endswith("@bitfoundry.ai")
