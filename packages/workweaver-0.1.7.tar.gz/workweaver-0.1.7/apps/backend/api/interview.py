"""Interview API -- conversational AI interview endpoints.

Handles prospect interviews powered by Bedrock/Grok, returning
Zara's responses and managing session state.

Legacy requirement reference: Sprint 3D -- Interview API Endpoints
"""

import hashlib
import hmac
import logging
import os

from fastapi import APIRouter, BackgroundTasks, HTTPException, Query, status

from apps.backend.schemas.interview import (
    InterviewMessageRequest,
    InterviewMessageResponse,
    InterviewReportAcceptedResponse,
    InterviewReportRequest,
    InterviewSessionResponse,
    RecommendationPayload,
    TaskSprintMessageRequest,
    TaskSprintMessageResponse,
)
from apps.backend.services.interview_session_service import (
    InterviewSessionService,
)
from apps.backend.services.interview_report_service import InterviewReportService
from apps.backend.services.interview_report_service import build_recommendation_payload
from apps.backend.services.lead_magnet_email_service import LeadMagnetEmailService
from apps.backend.services.nonvoice_reasoning_client import NonVoiceReasoningClient
logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/interview", tags=["interview"])

# Singleton service -- lazily initialised on first request.
_service: InterviewSessionService | None = None


# ---------------------------------------------------------------------------
# Session token -- HMAC-based access token for session-scoped endpoints.
# ---------------------------------------------------------------------------

def _session_token_secret() -> str:
    """Return the secret used to sign session access tokens.

    Falls back to a dev-only constant so tests remain deterministic.
    """
    return os.environ.get(
        "INTERVIEW_SESSION_TOKEN_SECRET",
        "workweaver-interview-dev-secret",
    )


def generate_session_token(session_id: str) -> str:
    """Generate a session-scoped access token for interview session recovery.

    The token is an HMAC-SHA256 of the session_id using a server-side secret.
    The client must pass this token back when accessing session-scoped endpoints
    (GET /{session_id}, POST /{session_id}/report).
    """
    return hmac.new(
        _session_token_secret().encode("utf-8"),
        session_id.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()


def _verify_session_token(session_id: str, token: str) -> bool:
    """Verify that the provided token matches the expected HMAC for session_id."""
    expected = generate_session_token(session_id)
    return hmac.compare_digest(expected, token)


def _recommendation_payload_for_complete_session(
    extracted_data: dict | None,
) -> RecommendationPayload | None:
    if extracted_data is None:
        return None
    return build_recommendation_payload(extracted_data)


def _build_task_executor():
    """Build the same improvement-aware executor used by Zara task paths.

    Interview/task-sprint sessions are public and do not have an authenticated
    tenant yet, so they run under a dedicated configurable interview tenant.
    """
    try:
        from apps.backend.services.zara.factory import build_zara_task_executor
        from apps.backend.utils.tenant import normalize_tenant_id

        interview_tenant_id = normalize_tenant_id(
            os.getenv("INTERVIEW_EXECUTOR_TENANT_ID", "interview-public")
        )
        return build_zara_task_executor(
            tenant_id=interview_tenant_id,
            llm_client=_build_reasoning_client(),
        )
    except Exception as exc:
        logger.warning("Unable to initialize interview task executor: %s", exc)
        return None


def _build_reasoning_client() -> NonVoiceReasoningClient:
    return NonVoiceReasoningClient(
        tenant_id=os.getenv("INTERVIEW_EXECUTOR_TENANT_ID", "interview-public"),
        on_fallback=lambda from_provider, to_provider, exc: logger.warning(
            "Interview reasoning fallback: %s -> %s (%s)",
            from_provider,
            to_provider,
            exc,
        ),
    )


def _get_service() -> InterviewSessionService:
    """Get or create the interview session service singleton."""
    global _service
    if _service is None:
        llm_client = _build_reasoning_client()
        _service = InterviewSessionService(
            llm_client=llm_client,
            task_executor=_build_task_executor(),
        )
    return _service


@router.post(
    "/message",
    response_model=InterviewMessageResponse,
    status_code=status.HTTP_200_OK,
)
async def send_message(req: InterviewMessageRequest) -> InterviewMessageResponse:
    """Send a message to Zara and get her response.

    If session_id is omitted, a new interview session is created.
    """
    service = _get_service()

    try:
        result = await service.process_message(
            session_id=req.session_id,
            user_message=req.message,
            enrichment=req.enrichment,
            is_voice=req.is_voice,
        )
    except RuntimeError as e:
        logger.error("Interview LLM error: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Zara is temporarily unavailable. Please try again.",
        )

    return InterviewMessageResponse(
        session_id=result.session_id,
        zara_message=result.zara_message,
        stage=result.stage.value if hasattr(result.stage, "value") else str(result.stage),
        exchange_count=result.exchange_count,
        is_complete=result.is_complete,
        extracted_data=result.extracted_data,
        recommendation_payload=_recommendation_payload_for_complete_session(result.extracted_data)
        if result.is_complete
        else None,
        session_token=generate_session_token(result.session_id),
    )


@router.get(
    "/{session_id}",
    response_model=InterviewSessionResponse,
    status_code=status.HTTP_200_OK,
)
async def get_session(
    session_id: str,
    session_token: str = Query(..., description="HMAC session access token"),
) -> InterviewSessionResponse:
    """Retrieve interview session state for recovery or display.

    Requires a valid session_token obtained from the /message response.
    """
    if not _verify_session_token(session_id, session_token):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing session token.",
        )

    service = _get_service()
    session = await service.get_session(session_id)

    if session is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Interview session not found.",
        )

    return InterviewSessionResponse(
        session_id=session.session_id,
        stage=session.stage.value if hasattr(session.stage, "value") else str(session.stage),
        exchange_count=session.exchange_count,
        is_complete=session.is_complete,
        history=session.history,
        extracted_data=session.extracted_data if session.is_complete else None,
        recommendation_payload=_recommendation_payload_for_complete_session(session.extracted_data)
        if session.is_complete
        else None,
    )


@router.post(
    "/{session_id}/report",
    response_model=InterviewReportAcceptedResponse,
    status_code=status.HTTP_202_ACCEPTED,
)
async def trigger_report(
    session_id: str,
    req: InterviewReportRequest,
    background_tasks: BackgroundTasks,
    session_token: str = Query(..., description="HMAC session access token"),
) -> InterviewReportAcceptedResponse:
    """Trigger report generation for a completed interview.

    Requires a valid session_token obtained from the /message response.
    Runs report pipeline in background: extract, narrative, email, CRM.
    """
    if not _verify_session_token(session_id, session_token):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid or missing session token.",
        )

    service = _get_service()
    session = await service.get_session(session_id)

    if session is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Interview session not found.",
        )

    if not session.is_complete:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Interview is not yet complete. Continue the conversation first.",
        )

    # Override email if provided
    if req.email_override:
        session.extracted_data["email"] = req.email_override

    # Build report service with real dependencies
    llm_client = _build_reasoning_client()
    try:
        email_service = LeadMagnetEmailService()
    except Exception:
        email_service = None
    report_service = InterviewReportService(
        llm_client=llm_client,
        email_service=email_service,
    )

    async def _run_report() -> None:
        try:
            await report_service.generate_report(session)
        except Exception as e:
            logger.error("Background report generation failed for %s: %s", session_id, e)

    background_tasks.add_task(_run_report)

    return InterviewReportAcceptedResponse(
        status="accepted",
        message="Report generation started. You'll receive it by email shortly.",
        session_id=session_id,
        recommendation_payload=_recommendation_payload_for_complete_session(session.extracted_data),
    )


# ---------- Task Sprint endpoints ----------


@router.post(
    "/sprint/message",
    response_model=TaskSprintMessageResponse,
    status_code=status.HTTP_200_OK,
)
async def send_sprint_message(req: TaskSprintMessageRequest) -> TaskSprintMessageResponse:
    """Send a message in task sprint mode.

    Task sprints are short, focused execution bursts (max 5 exchanges).
    If session_id is omitted, a new sprint session is created.
    """
    service = _get_service()

    try:
        result = await service.process_sprint_message(
            session_id=req.session_id,
            user_message=req.message,
            task_context=req.task_context,
            enrichment=req.enrichment,
        )
    except RuntimeError as e:
        logger.error("Sprint LLM error: %s", e)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Zara is temporarily unavailable. Please try again.",
        )

    return TaskSprintMessageResponse(
        session_id=result.session_id,
        zara_message=result.zara_message,
        stage=result.stage.value if hasattr(result.stage, "value") else str(result.stage),
        exchange_count=result.exchange_count,
        is_complete=result.is_complete,
        task_output=result.task_output,
        session_token=generate_session_token(result.session_id),
    )
