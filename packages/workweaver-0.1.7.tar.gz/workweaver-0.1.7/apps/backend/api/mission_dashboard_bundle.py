"""Bundled dashboard read model for the Mission runtime surface."""

from __future__ import annotations

import asyncio
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request, Response, status
from pydantic import BaseModel, Field

from apps.backend.api import mission_shared
from apps.backend.api.activity_stream import (
    ActivityItem,
    _action_description,
    _humanize_action,
    _safe_timestamp,
)
from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, get_verified_user_id
from apps.backend.api.settings import ProfileSettings, SettingsStorageError, _get_settings
from apps.backend.api.work_items import (
    WorkItemResponse,
    _get_goal_store,
    _get_task_store,
    _get_workitem_service,
)

router = APIRouter(prefix="/api/v1/mission", tags=["mission"])

_DASHBOARD_CACHE_CONTROL = "private, max-age=10"


class DashboardKpis(BaseModel):
    active: int = 0
    awaiting: int = 0
    shipped_today: int = 0
    pipeline_goal_pct: int = 0
    zara_runs: int = 0
    pending_ttl_human: str = "—"
    inbox_attention: int = 0
    entropy_escalation_active: bool = False
    behavioral_entropy_threshold: float | None = 2.5
    behavioral_entropy_last_max: float | None = None
    behavioral_entropy_last_agent: str | None = None
    entropy_escalation_expires_at: str | None = None
    entropy_remediation_url: str = "#/mission?dock=harness"


class DashboardWorkItems(BaseModel):
    goals: list[WorkItemResponse] = Field(default_factory=list)
    tasks: list[WorkItemResponse] = Field(default_factory=list)
    goal_count: int = 0
    task_count: int = 0
    blocked_count: int = 0
    review_count: int = 0


class DashboardUserProfile(BaseModel):
    id: str
    tenant_id: str
    name: str = ""
    email: str = ""
    # Issue #2746: tenant role is needed by the runtime to gate the
    # Members management UI. UserRole values: 'admin' | 'manager' | 'agent'.
    # Defaults to '' when the source store doesn't carry one (legacy users).
    role: str = ""


class DashboardAuth(BaseModel):
    authenticated: bool
    expires_at: str | None = None


class DashboardBundleResponse(BaseModel):
    kpis: DashboardKpis
    work_items: DashboardWorkItems
    activity_recent: list[ActivityItem] = Field(default_factory=list)
    compounding: dict[str, Any] | None = None
    user_profile: DashboardUserProfile
    auth: DashboardAuth


def _get_mission_store() -> Any:
    return mission_shared.get_store()


def _get_audit_log() -> Any:
    from apps.backend.services.audit_logger import get_audit_logger

    return get_audit_logger()


def _get_connector_health_service() -> Any | None:
    from apps.backend.services.connector_health_service import get_connector_health_service

    return get_connector_health_service()


def _get_connector_probe_response(*, tenant_id: str, connector_id: str) -> dict[str, Any] | None:
    from apps.backend.api.connectors._core import _get_health_store

    stored = _get_health_store().get_snapshot(
        tenant_id=tenant_id,
        connector_id=connector_id,
    )
    if not stored:
        return None
    return {
        "state": stored.get("state") or "",
        "message": stored.get("message") or "",
    }


def _get_runtime_alert_config(tenant_id: str) -> dict[str, Any]:
    from apps.backend.services.tenant_config import get_tenant_config

    config = get_tenant_config(tenant_id)
    return config if isinstance(config, dict) else {}


def _load_profile_settings(tenant_id: str, user_id: str) -> ProfileSettings:
    defaults = ProfileSettings(tenant_id=tenant_id, user_id=user_id).model_dump()
    settings = _get_settings(tenant_id, f"profile#{user_id}", defaults)
    settings["user_id"] = user_id
    return ProfileSettings(**settings)


def _build_user_profile(profile: ProfileSettings, *, tenant_id: str, user_id: str) -> DashboardUserProfile:
    name = str(profile.full_name or "").strip()
    email = str(profile.email or "").strip().lower()
    if not name and email and "@" in email:
        name = email.split("@", 1)[0].replace(".", " ").replace("_", " ").title()
    # Issue #2746: surface tenant role for UI gating (Members management).
    role = _resolve_user_role(tenant_id=tenant_id, user_id=user_id)
    return DashboardUserProfile(
        id=user_id,
        tenant_id=tenant_id,
        name=name,
        email=email,
        role=role,
    )


def _resolve_user_role(*, tenant_id: str, user_id: str) -> str:
    """Best-effort: read the user's tenant role from the user store.

    Returns ''. when the role can't be resolved — consumers must fail closed
    (default to non-admin gating) when role is empty.
    """
    try:
        from apps.backend.services.user_management import UserManagementService

        svc = UserManagementService()
        user = svc.get_user(tenant_id, user_id)
        if user is None:
            return ""
        role_value = getattr(user, "role", None)
        if role_value is None and isinstance(user, dict):
            role_value = user.get("role")
        if hasattr(role_value, "value"):
            role_value = role_value.value
        return str(role_value or "").strip().lower()
    except Exception:  # pragma: no cover -- never fail bundle on role miss
        return ""


def _connector_snapshot_for_item(
    item: dict[str, Any],
    *,
    tenant_id: str,
    health_service: Any | None,
) -> dict[str, Any] | None:
    """Build the connector snapshot dict consumed by the runtime status badge.

    Issue #2747. Reads ``metadata.connector`` (preferred) or
    ``metadata.connector_id`` from the work-item projection. When a
    health_service is available, augments the snapshot with the live
    circuit-breaker health for ``(tenant_id, connector_id)`` so the badge
    can render live / degraded / failed and the right remediation CTA
    without a second round-trip.
    """
    metadata = item.get("metadata") or {}
    if not isinstance(metadata, dict):
        return None

    declared = metadata.get("connector")
    if isinstance(declared, dict) and declared.get("connector_id"):
        snapshot: dict[str, Any] = dict(declared)
    else:
        # Issue #2747 round 14: only opt in to the connector badge when the
        # work-item explicitly declares `metadata.connector_id`. The
        # earlier `metadata.provider` fallback was unsafe — TimeBlock
        # emission hooks use `provider` for non-connector domains too
        # (email send providers, meeting providers like `recall`), and
        # treating those as connector IDs polluted aggregate health and
        # surfaced phantom badges.
        connector_id = metadata.get("connector_id")
        if not connector_id:
            return None
        snapshot = {
            "connector_id": str(connector_id),
            "label": metadata.get("connector_label") or str(connector_id),
            "icon": metadata.get("connector_icon"),
        }

    # Issue #2747 round 11: route through the shared remediation helper so
    # the bundle, public/MCP API, and HTTP health route emit the SAME
    # structured fields. Probe-derived auth states surface here too via the
    # persisted integration health store snapshot.
    from apps.backend.services.connector_remediation import compute_remediation

    probe_response: dict[str, Any] | None = None
    if health_service is not None:
        try:
            probe_response = _get_connector_probe_response(
                tenant_id=tenant_id,
                connector_id=snapshot["connector_id"],
            )
        except Exception:  # pragma: no cover -- never fail bundle on store miss
            probe_response = None

    remediation = compute_remediation(
        tenant_id=tenant_id,
        connector_id=snapshot["connector_id"],
        health_service=health_service,
        probe_response=probe_response,
    )

    snapshot["health"] = {
        "circuit_state": remediation.get("circuit_state") or "closed",
        "success_rate_24h": 0.0,
        "last_failure_at": None,
    }
    if health_service is not None:
        try:
            health = health_service.get_health(tenant_id, snapshot["connector_id"])
            snapshot["health"].update({
                "success_rate_24h": getattr(health, "success_rate_24h", 0.0),
                "last_failure_at": getattr(health, "last_failure_at", None),
            })
        except Exception:  # pragma: no cover
            pass

    # Issue #2747 round 16: remediation-owned fields are AUTHORITATIVE.
    # `metadata.connector` may carry stale values (e.g. needs_reauth=True
    # from before the user re-authed); we must not preserve them. Clear
    # stale fields when the current remediation says they're not active.
    last_message = remediation.get("last_failure_message")
    last_category = remediation.get("last_failure_category")
    needs_reauth = bool(remediation.get("needs_reauth", False))

    if last_message:
        snapshot["lastError"] = last_message
    else:
        snapshot.pop("lastError", None)

    if last_category:
        snapshot["failure_category"] = last_category
    else:
        snapshot.pop("failure_category", None)

    if needs_reauth:
        snapshot["needs_reauth"] = True
    else:
        snapshot.pop("needs_reauth", None)

    return snapshot


def _attach_connector(
    item: dict[str, Any],
    *,
    tenant_id: str,
    health_service: Any | None,
) -> dict[str, Any]:
    """Return ``item`` with a ``connector`` field if the projection declared one."""
    snapshot = _connector_snapshot_for_item(item, tenant_id=tenant_id, health_service=health_service)
    if snapshot is None:
        return item
    enriched = dict(item)
    enriched["connector"] = snapshot
    return enriched


def _build_work_items_and_kpis(
    workitems: Any,
    *,
    tenant_id: str,
    goal_store: Any,
    task_store: Any,
    health_service: Any | None = None,
) -> tuple[DashboardWorkItems, DashboardKpis]:
    def query_projection(*, limit: int, source_kind: str | None = None, status: str | None = None) -> tuple[list[dict[str, Any]], int]:
        items, count = workitems.query_work_items(
            tenant_id=tenant_id,
            goal_store=goal_store,
            task_store=task_store,
            source_kind=source_kind,
            status=status,
            limit=limit,
        )
        return list(items or []), int(count or 0)

    def count_goals(*, status: str | None = None, updated_date_prefix: str | None = None) -> int:
        goals_for_count = goal_store.list_goals(tenant_id) if goal_store is not None else []
        count = 0
        for goal in goals_for_count:
            projected = workitems._project_goal(goal, tenant_id=tenant_id)
            if status and str(projected.get("status") or "").strip().lower() != status:
                continue
            if updated_date_prefix and not str(projected.get("updated_at") or "").startswith(updated_date_prefix):
                continue
            count += 1
        return count

    def count_tasks(*, status: str | None = None, updated_date_prefix: str | None = None) -> int:
        if task_store is not None and hasattr(task_store, "count_tasks"):
            return int(
                task_store.count_tasks(
                    tenant_id=tenant_id,
                    status=status,
                    updated_date_prefix=updated_date_prefix,
                )
                or 0
            )
        _items, count = query_projection(source_kind="task", status=status, limit=25)
        if updated_date_prefix:
            return sum(1 for item in _items if str(item.get("updated_at") or "").startswith(updated_date_prefix))
        return count

    def count_all(*, status: str | None = None, updated_date_prefix: str | None = None) -> int:
        return count_goals(status=status, updated_date_prefix=updated_date_prefix) + count_tasks(
            status=status,
            updated_date_prefix=updated_date_prefix,
        )

    def recent_task_projection(limit: int) -> list[dict[str, Any]]:
        if task_store is not None and hasattr(task_store, "list_recent_tasks"):
            return [
                workitems._project_task(task, tenant_id=tenant_id)
                for task in task_store.list_recent_tasks(tenant_id=tenant_id, limit=limit)
            ]
        tasks_for_projection, _count = query_projection(source_kind="task", limit=25)
        return tasks_for_projection[:limit]

    goals, _visible_goal_count = query_projection(source_kind="goal", limit=3)
    tasks = recent_task_projection(5)
    goal_count = count_goals()
    task_count = count_tasks()
    blocked_count = count_all(status="blocked")
    review_count = count_all(status="review")
    active_count = count_all(status="active")
    in_progress_count = count_all(status="in_progress")
    today = datetime.now(UTC).date().isoformat()
    shipped_today = count_all(status="done", updated_date_prefix=today)
    done_goal_count = count_goals(status="done")
    active = active_count + in_progress_count
    pipeline_goal_pct = round((done_goal_count / goal_count) * 100) if goal_count else 0
    return (
        DashboardWorkItems(
            goals=[
                WorkItemResponse(**_attach_connector(item, tenant_id=tenant_id, health_service=health_service))
                for item in goals[:3]
            ],
            tasks=[
                WorkItemResponse(**_attach_connector(item, tenant_id=tenant_id, health_service=health_service))
                for item in tasks[:5]
            ],
            goal_count=goal_count,
            task_count=task_count,
            blocked_count=blocked_count,
            review_count=review_count,
        ),
        DashboardKpis(
            active=active,
            awaiting=review_count,
            shipped_today=shipped_today,
            pipeline_goal_pct=pipeline_goal_pct,
        ),
    )


def _build_compounding_summary(tenant_id: str) -> dict[str, Any]:
    from apps.backend.services.morning_brief import MorningBriefService

    return MorningBriefService(evidence_svc=None, include_historical_recall=False)._build_compounding_summary(tenant_id)


def _metadata_list(metadata: dict[str, Any], *keys: str) -> list[dict[str, Any] | str]:
    for key in keys:
        value = metadata.get(key)
        if isinstance(value, list):
            return value
        if isinstance(value, (dict, str)):
            return [value]
    return []


def _build_activity_recent(audit_log: Any, *, tenant_id: str, limit: int = 20) -> list[ActivityItem]:
    entries = audit_log.query_by_tenant(tenant_id=tenant_id, limit=limit)
    items: list[ActivityItem] = []
    for entry in entries:
        metadata = entry.action_metadata if isinstance(getattr(entry, "action_metadata", None), dict) else {}
        action_raw = getattr(entry, "action", "")
        action = str(action_raw.value) if hasattr(action_raw, "value") else str(action_raw or "")
        resource_type = str(getattr(entry, "resource_type", "") or "") or None
        resource_id = str(getattr(entry, "resource_id", "") or "") or None
        items.append(
            ActivityItem(
                timestamp=_safe_timestamp(getattr(entry, "timestamp", "")),
                actor=str(getattr(entry, "user_id", "") or "system").strip() or "system",
                action_type=_humanize_action(action),
                description=_action_description(action, metadata, resource_type, resource_id),
                activity_id=str(getattr(entry, "event_id", "") or "") or None,
                resource_type=resource_type,
                resource_id=resource_id,
                source_jumps=_metadata_list(metadata, "source_jumps", "memory_jumps", "memory_links", "sources"),
                citations=_metadata_list(metadata, "citations"),
                historical_recall=metadata.get("historical_recall")
                if isinstance(metadata.get("historical_recall"), dict)
                else None,
            )
        )
    return items


def _attach_runtime_alerts(kpis: DashboardKpis, tenant_id: str) -> DashboardKpis:
    try:
        config = _get_runtime_alert_config(tenant_id)
    except Exception:
        config = {}

    kpis.entropy_escalation_active = bool(config.get("entropy_escalation_active"))
    threshold = config.get("behavioral_entropy_threshold", 2.5)
    try:
        kpis.behavioral_entropy_threshold = float(threshold) if threshold is not None else None
    except (TypeError, ValueError):
        kpis.behavioral_entropy_threshold = None
    last_max = config.get("behavioral_entropy_last_max")
    try:
        kpis.behavioral_entropy_last_max = float(last_max) if last_max is not None else None
    except (TypeError, ValueError):
        kpis.behavioral_entropy_last_max = None
    last_agent = str(config.get("behavioral_entropy_last_agent") or "").strip()
    kpis.behavioral_entropy_last_agent = last_agent or None
    expires_at = str(config.get("entropy_escalation_expires_at") or "").strip()
    kpis.entropy_escalation_expires_at = expires_at or None
    return kpis


def _auth_expiry_from_request(request: Request) -> str | None:
    """Return a local signed-session expiry without re-running provider auth."""
    from apps.backend.api.auth_helpers import BROWSER_SESSION_COOKIE_NAMES
    from apps.backend.services.session.browser_session import BrowserSessionTokenError, verify_browser_session_token

    cookies = getattr(request, "cookies", {}) or {}
    for cookie_name in BROWSER_SESSION_COOKIE_NAMES:
        token = str(cookies.get(cookie_name) or "").strip()
        if not token:
            continue
        try:
            claims = verify_browser_session_token(token)
        except BrowserSessionTokenError:
            return None
        return datetime.fromtimestamp(claims.exp, tz=UTC).isoformat()
    return None


@router.get(
    "/dashboard-bundle",
    response_model=DashboardBundleResponse,
    status_code=status.HTTP_200_OK,
)
async def get_dashboard_bundle(
    request: Request,
    response: Response,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    workitems: Any = Depends(_get_workitem_service),
    goal_store: Any = Depends(_get_goal_store),
    task_store: Any = Depends(_get_task_store),
    mission_store: Any = Depends(_get_mission_store),
    audit_log: Any = Depends(_get_audit_log),
) -> DashboardBundleResponse:
    response.headers["Cache-Control"] = _DASHBOARD_CACHE_CONTROL

    # Issue #2747: lazily resolve the connector health service so the bundle
    # work-items can carry a live `connector` snapshot when the underlying
    # work-item declares a connector_id in its metadata. Health-service
    # failures are non-fatal — if resolution fails the bundle still ships,
    # the badge just renders without live status.
    try:
        health_service = _get_connector_health_service()
    except Exception:
        health_service = None

    work_items_task = asyncio.to_thread(
        _build_work_items_and_kpis,
        workitems,
        tenant_id=tenant_id,
        goal_store=goal_store,
        task_store=task_store,
        health_service=health_service,
    )
    profile_task = asyncio.to_thread(_load_profile_settings, tenant_id, user_id)
    activity_recent_task = asyncio.to_thread(_build_activity_recent, audit_log, tenant_id=tenant_id, limit=20)
    compounding_task = asyncio.to_thread(_build_compounding_summary, tenant_id)
    activity_pulse_task = asyncio.to_thread(mission_store.list_nodes, tenant_id)

    try:
        (work_item_bundle, kpis), profile, activity_recent, compounding, mission_nodes = await asyncio.gather(
            work_items_task,
            profile_task,
            activity_recent_task,
            compounding_task,
            activity_pulse_task,
        )
    except SettingsStorageError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="settings_storage_unavailable",
        ) from exc
    except Exception as exc:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Failed to load dashboard bundle") from exc

    active_node_count = 0
    thinking_node_count = 0
    for node in mission_nodes:
        status_value = str((node or {}).get("status") or "").strip().lower()
        if status_value in {"active", "thinking"}:
            active_node_count += 1
        if status_value == "thinking":
            thinking_node_count += 1
    kpis.active = active_node_count
    kpis.zara_runs = thinking_node_count
    _attach_runtime_alerts(kpis, tenant_id)

    return DashboardBundleResponse(
        kpis=kpis,
        work_items=work_item_bundle,
        activity_recent=activity_recent,
        compounding=compounding,
        user_profile=_build_user_profile(profile, tenant_id=tenant_id, user_id=user_id),
        auth=DashboardAuth(authenticated=True, expires_at=_auth_expiry_from_request(request)),
    )
