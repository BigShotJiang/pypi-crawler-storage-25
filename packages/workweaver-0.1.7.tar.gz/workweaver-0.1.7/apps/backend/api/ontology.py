"""Tenant ontology query API."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.public_api_service import get_public_api_service
from apps.backend.extensions.ontology.primitive_ontology import PrimitiveKind

router = APIRouter(prefix="/api/v1/ontology", tags=["ontology"])


class OntologyQueryApiResponse(BaseModel):
    tenant_id: str
    matches: list[dict[str, Any]] = Field(default_factory=list)
    consulted_sources: list[str] = Field(default_factory=list)


@router.get("/query", response_model=OntologyQueryApiResponse)
async def query_ontology(
    q: str = Query("", description="Search text"),
    kind: PrimitiveKind | None = Query(None, description="Optional ontology node kind"),
    limit: int = Query(50, ge=1, le=100),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> OntologyQueryApiResponse:
    result = await get_public_api_service().ontology_query(
        tenant_id=tenant_id,
        q=q,
        kind=kind.value if kind else None,
        limit=limit,
    )
    return OntologyQueryApiResponse.model_validate(result)
