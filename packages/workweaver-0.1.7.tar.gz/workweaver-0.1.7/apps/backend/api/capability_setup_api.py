"""Capability Setup API — P2.8 Progressive Setup for New Capabilities.

Endpoints for checking and configuring capability setup requirements.

Prefix: /api/v1/capabilities
Tags: capability-setup

Endpoints:
- GET    /api/v1/capabilities/{id}/setup-status — returns setup state
- POST   /api/v1/capabilities/{id}/setup        — submit setup answers
- DELETE /api/v1/capabilities/{id}/setup        — disconnect / reset setup
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, Path, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.capabilities_api import _CAPABILITY_WRITE_DEPENDENCIES
from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.capability_setup_service import get_capability_setup_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/capabilities", tags=["capability-setup"])


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class SetupQuestionResponse(BaseModel):
    """A single setup question."""

    id: str
    label: str
    type: str
    options: list[str] | None = None


class SetupStatusResponse(BaseModel):
    """Response for setup status check."""

    capability_id: str
    status: str
    required_integrations: list[str] = Field(default_factory=list)
    questions: list[SetupQuestionResponse] = Field(default_factory=list)
    config: dict[str, Any] = Field(default_factory=dict)


class SetupSubmitRequest(BaseModel):
    """Request body for submitting setup answers."""

    entity_id: str = Field(..., description="Entity (agent) to configure")
    answers: dict[str, Any] = Field(..., description="Setup answers keyed by question ID")


class SetupSubmitResponse(BaseModel):
    """Response after setup submission."""

    capability_id: str
    status: str
    config: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get(
    "/{capability_id}/setup-status",
    response_model=SetupStatusResponse,
    status_code=status.HTTP_200_OK,
    summary="Get capability setup status",
)
async def get_setup_status(
    capability_id: str = Path(..., description="Capability identifier"),
    entity_id: str = Query(..., description="Entity (agent) identifier"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SetupStatusResponse:
    """Check whether a capability is configured for the entity.

    Returns required integrations and setup questions if not yet configured.
    """
    svc = get_capability_setup_service()
    result = svc.get_setup_status(tenant_id, entity_id, capability_id)

    # Convert SetupStatus enum to string for response
    status_str = result["status"]
    if hasattr(status_str, "value"):
        status_str = status_str.value

    questions = [SetupQuestionResponse(**q) for q in result.get("questions", [])]

    return SetupStatusResponse(
        capability_id=result["capability_id"],
        status=status_str,
        required_integrations=result.get("required_integrations", []),
        questions=questions,
        config=result.get("config", {}),
    )


@router.post(
    "/{capability_id}/setup",
    response_model=SetupSubmitResponse,
    status_code=status.HTTP_200_OK,
    summary="Submit capability setup",
    dependencies=_CAPABILITY_WRITE_DEPENDENCIES,
)
async def submit_setup(
    capability_id: str = Path(..., description="Capability identifier"),
    body: SetupSubmitRequest = ...,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SetupSubmitResponse:
    """Submit setup answers for a capability.

    Stores the configuration in entity-scoped DynamoDB settings.
    """
    svc = get_capability_setup_service()
    result = svc.submit_setup(tenant_id, body.entity_id, capability_id, body.answers)

    status_str = result["status"]
    if hasattr(status_str, "value"):
        status_str = status_str.value

    return SetupSubmitResponse(
        capability_id=result["capability_id"],
        status=status_str,
        config=result.get("config", {}),
    )


@router.delete(
    "/{capability_id}/setup",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Disconnect / reset capability setup",
    response_model=None,
    dependencies=_CAPABILITY_WRITE_DEPENDENCIES,
)
async def reset_setup(
    capability_id: str = Path(..., description="Capability identifier"),
    entity_id: str = Query(..., description="Entity (agent) identifier"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> None:
    """Remove a capability setup configuration for an entity.

    Reverts the capability to not-started state, effectively disconnecting
    the service from this entity. Credential vault entries are not touched
    here — vault cleanup is a separate concern if needed.
    """
    svc = get_capability_setup_service()
    svc.reset_setup(tenant_id, entity_id, capability_id)
