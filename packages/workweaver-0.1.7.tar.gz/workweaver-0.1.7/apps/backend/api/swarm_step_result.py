"""Swarm step terminal-transition REST surface (#3236).

Exposes :class:`CompletionGate` to humans + agents via REST so the CLI
(``ww swarm step-result <step-id>``) and MCP tool
(``ww.swarm.record_step_result``) share one verifier-as-gate path.

Routes
------
- ``POST /api/v1/swarm/steps/{step_id}/result``
    Submit a terminal-status candidate for a swarm step. The gate runs
    the verifier (and the success-criteria evaluator when an evidence
    bundle carries one), checks evidence isolation, writes the result
    via optimistic-lock CAS, and returns the verdict.

Status codes
------------
- ``200`` -- verifier approved AND CAS committed
- ``409`` -- CAS conflict after idempotent replay (caller must refresh)
- ``422`` -- evidence isolation violation (cross-tenant or
  cross-function evidence bundle)
- ``403`` -- verifier denied / degraded paused
- ``404`` -- step not found for the authenticated tenant
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Body, Depends, HTTPException, status
from pydantic import BaseModel, ConfigDict, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.swarm.completion_gate import (
    EvidenceIsolationError,
    GateVerdict,
)
from apps.backend.services.swarm_scheduler import (
    SwarmExecution,
    SwarmScheduler,
    get_swarm_scheduler,
)
from apps.backend.utils.tenant import strip_tenant_prefix

router = APIRouter(prefix="/api/v1/swarm", tags=["swarm"])


class StepResultRequest(BaseModel):
    """Body for ``POST /steps/{step_id}/result``.

    All fields except ``proposed_status`` are optional. ``evidence_bundle``
    must include a ``tenant_id`` matching the authenticated tenant; the
    gate raises an isolation violation otherwise. The optional
    ``function_id`` constrains the bundle to a function id; cross-function
    bundles are rejected.
    """

    model_config = ConfigDict(extra="forbid")

    proposed_status: str = Field(
        default="completed",
        description="Terminal status candidate. Values not in the canonical "
        "terminal set bypass the gate.",
    )
    evidence_bundle: dict[str, Any] | None = Field(
        default=None,
        description="Caller-supplied evidence dict. Wrapped in an "
        "UntrustedContextEnvelope before reaching the verifier.",
    )
    evidence_ids: list[str] = Field(
        default_factory=list,
        description="Evidence Ledger refs attached to the step on commit.",
    )
    function_id: str | None = Field(
        default=None,
        description="Optional function id for cross-function isolation.",
    )
    completed_at: str | None = Field(
        default=None,
        description="ISO-8601 completion timestamp (defaults to now).",
    )
    actor_chain: list[str] = Field(
        default_factory=list,
        description="Caller chain captured in the Decision Trace.",
    )


class StepResultResponse(BaseModel):
    """Surface payload describing a CompletionGate verdict.

    This payload is shared by the REST router (200), the CLI handler,
    and the MCP tool. The 409/422/403 responses use the same shape so
    surface clients can render a uniform inspector regardless of
    outcome.
    """

    model_config = ConfigDict(extra="forbid")

    step_id: str
    tenant_id: str
    execution_id: str | None
    can_commit: bool
    verifier_action: str
    commit_status: str
    committed_version: int | None = None
    cas_attempts: int = 0
    verifier_max_severity: str | None = None
    verifier_model: str | None = None
    verifier_latency_ms: int | None = None
    verifier_tokens: int | None = None
    evidence_id: str | None = None
    evidence_bundle_id: str | None = None
    isolation_error: str | None = None


def _scheduler() -> SwarmScheduler:
    return get_swarm_scheduler()


def _find_step(
    scheduler: SwarmScheduler, tenant: str, step_id: str
) -> tuple[SwarmExecution, dict[str, Any]] | None:
    """Resolve the step inside any swarm execution for ``tenant``."""
    target = step_id.strip()
    if not target:
        return None
    for execution in scheduler.list_executions(tenant, limit=500):
        for step in execution.steps:
            if not isinstance(step, dict):
                continue
            if str(step.get("step_id") or "") == target:
                return execution, step
    return None


def verdict_to_response(
    *,
    verdict: GateVerdict,
    tenant_id: str,
    execution_id: str | None,
) -> StepResultResponse:
    return StepResultResponse(
        step_id=verdict.step_id,
        tenant_id=tenant_id,
        execution_id=execution_id,
        can_commit=verdict.can_commit,
        verifier_action=verdict.verifier_action,
        commit_status=verdict.commit_status,
        committed_version=verdict.committed_version,
        cas_attempts=verdict.cas_attempts,
        verifier_max_severity=verdict.verifier_max_severity,
        verifier_model=verdict.verifier_model,
        verifier_latency_ms=verdict.verifier_latency_ms,
        verifier_tokens=verdict.verifier_tokens,
        evidence_id=verdict.evidence_id,
        evidence_bundle_id=verdict.evidence_bundle_id,
        isolation_error=verdict.isolation_error,
    )


def _http_status_for(verdict: GateVerdict) -> int:
    if verdict.commit_status == "isolation_violation":
        return status.HTTP_422_UNPROCESSABLE_ENTITY
    if verdict.commit_status == "conflict":
        return status.HTTP_409_CONFLICT
    if verdict.commit_status in {"committed", "committed_replay"}:
        return status.HTTP_200_OK
    if verdict.commit_status in {"degraded_pause", "denied"}:
        return status.HTTP_403_FORBIDDEN
    return status.HTTP_200_OK


async def attempt_step_transition(
    *,
    tenant_id: str,
    step_id: str,
    proposed_status: str,
    evidence_bundle: dict[str, Any] | None,
    evidence_ids: list[str],
    function_id: str | None,
    completed_at: str | None,
    actor_chain: list[str],
) -> tuple[StepResultResponse, int]:
    """Shared core for REST + MCP step-result transitions."""
    tenant = strip_tenant_prefix(tenant_id)
    located = _find_step(_scheduler(), tenant, step_id)
    if located is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Step not found: {step_id}",
        )
    execution, _step = located

    # Drive the gate directly (rather than via record_step_result) so we
    # surface the verdict object faithfully -- the scheduler returns a
    # boolean today, which is right for queue-driven callers but loses
    # information needed for HTTP status mapping.
    from apps.backend.services.swarm.completion_gate import (
        get_default_completion_gate,
    )

    scheduler = _scheduler()
    gate = scheduler._completion_gate or get_default_completion_gate()

    commit_fn = scheduler._commit_step_result_factory(  # type: ignore[attr-defined]
        tenant_id=tenant,
        execution=execution,
        step_id=step_id,
        proposed_status=proposed_status,
        evidence_ids=evidence_ids,
        payload={
            "actor_chain": list(actor_chain),
        },
        completed_at=completed_at,
    )
    refresh_fn = scheduler._version_refresh_factory(  # type: ignore[attr-defined]
        tenant_id=tenant,
        execution_id=execution.execution_id,
    )
    try:
        verdict = await gate.attempt_terminal_transition(
            step_id=step_id,
            proposed_status=proposed_status,
            tenant_id=tenant,
            function_id=function_id or execution.execution_id,
            evidence_bundle=evidence_bundle,
            expected_version=execution.version,
            actor_chain=list(actor_chain or []),
            commit_fn=commit_fn,
            version_refresh_fn=refresh_fn,
        )
    except EvidenceIsolationError as exc:
        isolation_verdict = GateVerdict(
            step_id=step_id,
            can_commit=False,
            verifier_action="isolation_violation",
            verifier_max_severity=None,
            evidence_id=None,
            isolation_error=str(exc),
            commit_status="isolation_violation",
        )
        return (
            verdict_to_response(
                verdict=isolation_verdict,
                tenant_id=tenant,
                execution_id=execution.execution_id,
            ),
            status.HTTP_422_UNPROCESSABLE_ENTITY,
        )
    response = verdict_to_response(
        verdict=verdict,
        tenant_id=tenant,
        execution_id=execution.execution_id,
    )
    return response, _http_status_for(verdict)


@router.post(
    "/steps/{step_id}/result",
    response_model=StepResultResponse,
    responses={
        200: {"description": "Verifier approved and CAS committed."},
        403: {"description": "Verifier denied or degraded-paused the transition."},
        404: {"description": "Step not found for the authenticated tenant."},
        409: {"description": "Optimistic-lock conflict after idempotent replay."},
        422: {"description": "Evidence isolation violation (tenant/function mismatch)."},
    },
)
async def post_step_result(
    step_id: str,
    request: StepResultRequest = Body(...),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> Any:
    """Submit a terminal-status candidate for a swarm step.

    The verifier-as-gate runs first; the CAS write only lands when the
    verifier approves AND the optimistic-lock version matches.
    """
    response, http_status = await attempt_step_transition(
        tenant_id=tenant_id,
        step_id=step_id,
        proposed_status=request.proposed_status,
        evidence_bundle=request.evidence_bundle,
        evidence_ids=list(request.evidence_ids),
        function_id=request.function_id,
        completed_at=request.completed_at,
        actor_chain=list(request.actor_chain) or ["api"],
    )
    if http_status == status.HTTP_200_OK:
        return response
    # FastAPI's default response_model serialisation requires the body
    # to be returned as the response_model type for 2xx; for non-2xx
    # we wrap the same payload in an HTTPException-style envelope so
    # the client can still parse the verdict. JSONResponse keeps the
    # same shape as response_model.
    from fastapi.responses import JSONResponse

    return JSONResponse(status_code=http_status, content=response.model_dump(mode="json"))
