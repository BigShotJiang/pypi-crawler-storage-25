"""Authentication Pydantic models, enums, and response classes.

Extracted from auth.py (Phase 5 tech debt reduction).
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Literal

from pydantic import AliasChoices, BaseModel, EmailStr, Field, field_validator, model_validator

from apps.backend.schemas.error_response import ErrorResponse  # noqa: F401 — re-exported for API use
from apps.backend.services.password_policy import MAX_LENGTH as _PW_MAX_LENGTH
from apps.backend.services.password_policy import MIN_LENGTH as _PW_MIN_LENGTH
from apps.backend.services.password_policy import PasswordPolicyError, validate_password


# ============================================================================
# Enums
# ============================================================================


class AuthProvider(str, Enum):
    """Supported authentication providers."""

    GOOGLE = "google"
    MICROSOFT = "microsoft"
    OIDC = "oidc"
    ZOHO = "zoho"
    EMAIL_PASSWORD = "email_password"


# ============================================================================
# Request Models
# ============================================================================


class GoogleOAuthRequest(BaseModel):
    """Request model for Google OAuth authentication.

    Attributes:
        id_token: Google OAuth ID token
        access_token: Google OAuth access token
        email: User's email from Google
        name: User's full name from Google
        google_user_id: Google user ID
        accepted_terms: User accepted Terms of Service
        accepted_privacy: User accepted Privacy Policy
    """

    # Google Identity Services has two common browser flows:
    # - ID token (JWT) via google.accounts.id.* (returns credential)
    # - Access token via google.accounts.oauth2.initTokenClient() (returns ya29...)
    #
    # We accept either so the frontend can evolve without breaking signup.
    id_token: str | None = Field(None, description="Google OAuth ID token (JWT)")
    access_token: str | None = Field(None, description="Google OAuth access token")
    # These are optional because we can derive them from the validated token.
    # Keeping them optional also lets the frontend use the simpler Google ID token flow.
    email: EmailStr | None = Field(None, description="User's email (optional; derived from token)")
    name: str | None = Field(None, description="User's full name (optional)")
    google_user_id: str | None = Field(None, description="Google user ID (optional; derived from token)", min_length=1)
    preferred_region: str | None = Field(None, description="Preferred region label/code for tenant provisioning")
    invite_token: str | None = Field(None, description="Invite token from alpha access invite link (UUID4)")
    sub_tenant_invite_token: str | None = Field(
        None,
        validation_alias=AliasChoices("sub_tenant_invite_token", "sub_tenant_invite"),
        description="Invite token for claiming an org-bounded sub-tenant workspace",
    )
    accepted_terms: bool = Field(description="User accepted Terms of Service and Privacy Policy")
    accepted_privacy: bool = Field(description="User accepted Privacy Policy")

    @field_validator("email")
    @classmethod
    def validate_email(cls, v: str) -> str:
        """Validate and normalize email."""
        if v is None:
            return v
        if not v.strip():
            raise ValueError("email cannot be empty")
        return v.strip().lower()

    @model_validator(mode="after")
    def validate_google_tokens(self) -> "GoogleOAuthRequest":
        if not (self.id_token and self.id_token.strip()) and not (self.access_token and self.access_token.strip()):
            raise ValueError("Either id_token or access_token must be provided")
        return self


class GoogleOAuthCodeRequest(BaseModel):
    """Request model for Google OAuth code exchange (GIS code client).

    Attributes:
        code: One-time authorization code from Google Identity Services.
        preferred_region: Optional region selection for provisioning.
        accepted_terms: User accepted Terms of Service.
        accepted_privacy: User accepted Privacy Policy.
    """

    code: str = Field(..., description="Google OAuth authorization code", min_length=1)
    preferred_region: str | None = Field(None, description="Preferred region label/code for tenant provisioning")
    invite_token: str | None = Field(None, description="Invite token from alpha access invite link (UUID4)")
    sub_tenant_invite_token: str | None = Field(
        None,
        validation_alias=AliasChoices("sub_tenant_invite_token", "sub_tenant_invite"),
        description="Invite token for claiming an org-bounded sub-tenant workspace",
    )
    accepted_terms: bool = Field(description="User accepted Terms of Service and Privacy Policy")
    accepted_privacy: bool = Field(description="User accepted Privacy Policy")


class EmailPasswordSignupRequest(BaseModel):
    """Request model for email/password signup.

    Attributes:
        email: User's email address
        password: User's password (will be hashed)
        name: User's full name (optional)
        accepted_terms: User accepted Terms of Service
        accepted_privacy: User accepted Privacy Policy
    """

    email: EmailStr = Field(..., description="User's email address")
    password: str = Field(
        ...,
        description=(
            f"User's password (min {_PW_MIN_LENGTH} chars, must include upper, "
            "lower, digit, and symbol; must not be a common password or "
            "equal to your email)"
        ),
        min_length=_PW_MIN_LENGTH,
        max_length=_PW_MAX_LENGTH,
    )
    name: str | None = Field(None, description="User's full name", max_length=255)
    preferred_region: str | None = Field(
        None, description="Preferred region label/code for tenant provisioning", max_length=50
    )
    invite_token: str | None = Field(None, description="Invite token from alpha access invite link (UUID4)")
    sub_tenant_invite_token: str | None = Field(
        None,
        validation_alias=AliasChoices("sub_tenant_invite_token", "sub_tenant_invite"),
        description="Invite token for claiming an org-bounded sub-tenant workspace",
    )
    accepted_terms: bool = Field(description="User accepted Terms of Service and Privacy Policy")
    accepted_privacy: bool = Field(description="User accepted Privacy Policy")

    @model_validator(mode="after")
    def _enforce_password_policy(self) -> "EmailPasswordSignupRequest":
        """Structural password-policy gate (GAP-003, issue #1147).

        Checked after field binding so ``validate_password`` can compare
        password against email and reject equality/substring reuse that
        the per-field min-length check cannot catch.
        """
        try:
            validate_password(self.password, email=self.email)
        except PasswordPolicyError as exc:
            raise ValueError(str(exc)) from exc
        return self


class EmailVerificationRequest(BaseModel):
    """Request model for email verification.

    Attributes:
        email: User's email address
        verification_code: 6-digit verification code
    """

    email: EmailStr = Field(..., description="User's email address")
    verification_code: str = Field(..., description="6-digit verification code", pattern=r"^\d{6}$")
    preferred_region: str | None = Field(
        None,
        description="Preferred region label/code (overrides initial signup selection)",
        max_length=50,
    )


class EmailVerificationResendRequest(BaseModel):
    """Request model for resending email verification code."""

    email: EmailStr = Field(..., description="User's email address")


class LoginRequest(BaseModel):
    """Request model for email/password login.

    Attributes:
        email: User's email address
        password: User's password
    """

    email: EmailStr = Field(..., description="User's email address")
    password: str = Field(..., description="User's password", min_length=1, max_length=128)


class LoginChallengeRequest(BaseModel):
    """Request model for completing an MFA login challenge."""

    challenge_token: str = Field(..., description="Short-lived signed challenge token", min_length=1, max_length=4096)
    code: str = Field(..., description="6-digit TOTP code", pattern=r"^\d{6}$")


class CLIAuthExchangeRequest(BaseModel):
    """Request model for exchanging a short-lived CLI OAuth code for a bearer token."""

    code: str = Field(..., description="Short-lived signed CLI auth code", min_length=1, max_length=4096)
    code_verifier: str = Field(..., description="PKCE verifier generated by the ww CLI", min_length=32, max_length=256)


class CLIAuthStartRequest(BaseModel):
    """Request model for starting a browser-based CLI login."""

    provider: Literal["google", "microsoft", "oidc", "zoho"] | None = Field(
        None,
        description="Optional provider shortcut. When omitted, the browser shows the unified Workweaver login page.",
    )
    return_to: str | None = Field(
        None,
        description="Trusted Workweaver browser origin to show completion after provider auth",
        max_length=2048,
    )
    code_challenge: str = Field(
        ..., description="PKCE code challenge generated by the ww CLI", min_length=32, max_length=512
    )
    code_challenge_method: Literal["S256"] = Field(
        "S256",
        description="PKCE challenge method supported by the ww CLI",
    )


class CLIAuthStartResponse(BaseModel):
    """Response model for starting a CLI browser login."""

    provider: Literal["google", "microsoft", "oidc", "zoho"] | None = Field(
        None,
        description="Optional provider shortcut attached to the login URL",
    )
    login_url: str = Field(..., description="Provider login URL to open in the browser", min_length=1, max_length=4096)
    poll_token: str = Field(
        ..., description="Hidden CLI poll token used to finish browser login", min_length=16, max_length=512
    )
    expires_in: int = Field(..., description="Seconds before the pending CLI login expires", ge=30, le=3600)


class CLIAuthCompleteRequest(BaseModel):
    """Request model for completing a CLI browser login from an authenticated web session."""

    client_state: str = Field(
        ..., description="CLI login attempt id from /api/v1/auth/cli/start", min_length=8, max_length=512
    )
    code_challenge: str = Field(
        ..., description="PKCE code challenge generated by the ww CLI", min_length=32, max_length=512
    )
    code_challenge_method: Literal["S256"] = Field(
        "S256",
        description="PKCE challenge method supported by the ww CLI",
    )
    provider: Literal["email_password", "google", "microsoft", "oidc", "zoho"] | None = Field(
        None,
        description="Authentication method that completed the browser sign-in.",
    )


class CLIAuthCompleteResponse(BaseModel):
    """Response model for completing a CLI browser login from the browser."""

    status: Literal["complete"] = Field(default="complete", description="Signals that the CLI exchange code is ready")
    provider: Literal["email_password", "google", "microsoft", "oidc", "zoho"] = Field(
        ...,
        description="Authentication method attached to the completed CLI login",
    )
    tenant_id: str = Field(..., description="Authenticated tenant id")
    user_id: str = Field(..., description="Authenticated user id")
    email: str = Field(..., description="Authenticated email")
    expires_in: int = Field(..., description="Seconds before the CLI exchange code expires", ge=30, le=3600)


class CLIPendingLoginRequest(BaseModel):
    """Request model for polling an in-progress CLI browser login."""

    poll_token: str = Field(
        ..., description="Hidden CLI poll token generated by the backend", min_length=16, max_length=512
    )


class CLIPendingLoginResponse(BaseModel):
    """Response model for the CLI browser-login bridge."""

    status: Literal["pending", "complete", "error"] = Field(..., description="Current browser login state")
    provider: str | None = Field(None, description="OAuth provider attached to the login attempt")
    code: str | None = Field(None, description="Short-lived signed CLI auth code when status=complete")
    error: str | None = Field(None, description="Provider or bridge error when status=error")
    poll_after_seconds: int = Field(1, description="Suggested poll delay before checking again", ge=1, le=30)


class CLIDeviceAuthStartRequest(BaseModel):
    """Request model for starting a device-code CLI login."""

    provider: Literal["oidc"] = Field(
        default="oidc",
        description="Self-host OIDC device-code login provider.",
    )


class CLIDeviceAuthStartResponse(BaseModel):
    """Response model for starting a device-code CLI login."""

    provider: Literal["oidc"] = Field(default="oidc")
    device_code: str = Field(..., description="Opaque device authorization code from the identity provider")
    user_code: str = Field(..., description="Short user-facing verification code")
    verification_uri: str = Field(..., description="Verification URL the user should open")
    verification_uri_complete: str | None = Field(
        None,
        description="Optional verification URL that already includes the user code",
    )
    expires_in: int = Field(..., description="Seconds before the device code expires", ge=30, le=3600)
    poll_after_seconds: int = Field(..., description="Suggested initial poll interval", ge=1, le=60)


class CLIDeviceAuthPollRequest(BaseModel):
    """Request model for polling a device-code CLI login."""

    provider: Literal["oidc"] = Field(default="oidc")
    device_code: str = Field(..., description="Opaque device authorization code from the identity provider")


class CLIDeviceAuthPollResponse(BaseModel):
    """Response model for a device-code CLI login poll."""

    status: Literal["pending", "complete", "error"] = Field(..., description="Current device-code login state")
    provider: Literal["oidc"] = Field(default="oidc")
    login: LoginResponse | None = Field(None, description="Completed Workweaver CLI session payload when ready")
    error: str | None = Field(None, description="Device authorization error when status=error")
    poll_after_seconds: int = Field(1, description="Suggested poll delay before checking again", ge=1, le=60)


class AcceptInvitationRequest(BaseModel):
    """Request model for accepting an invitation."""

    token: str = Field(..., description="JWT token from invitation email", max_length=2048)
    password: str = Field(
        ...,
        description=(
            f"User's password (min {_PW_MIN_LENGTH} chars, must include upper, "
            "lower, digit, and symbol; must not be a common password or "
            "equal to your email)"
        ),
        min_length=_PW_MIN_LENGTH,
        max_length=_PW_MAX_LENGTH,
    )
    name: str | None = Field(None, description="User's full name", max_length=255)

    @field_validator("password")
    @classmethod
    def _enforce_password_policy(cls, value: str) -> str:
        """Structural password-policy gate (GAP-003, issue #1147).

        Invitation-acceptance shares the same password policy as reset
        and signup so rollout can never downgrade credentials via the
        back door of an invitation accept.
        """
        try:
            validate_password(value)
        except PasswordPolicyError as exc:
            raise ValueError(str(exc)) from exc
        return value


class RequestPasswordResetRequest(BaseModel):
    """Request model for password reset."""

    email: EmailStr = Field(..., description="User's email address")


class PasswordResetRequest(BaseModel):
    """Request model for completing password reset."""

    token: str = Field(..., description="JWT token from password reset email")
    new_password: str = Field(
        ...,
        description=(
            f"New password (min {_PW_MIN_LENGTH} chars, must include upper, "
            "lower, digit, and symbol; must not be a common password or "
            "equal to your email)"
        ),
        min_length=_PW_MIN_LENGTH,
        max_length=_PW_MAX_LENGTH,
    )

    @field_validator("new_password")
    @classmethod
    def _enforce_password_policy(cls, value: str) -> str:
        """Structural password-policy gate (GAP-003, issue #1147).

        Rejects passwords that fail centralized complexity rules so a
        200 OK on ``POST /password-reset/confirm`` is real evidence of a
        strong password, not a silent downgrade to the previous min-8
        behavior.
        """
        try:
            validate_password(value)
        except PasswordPolicyError as exc:
            raise ValueError(str(exc)) from exc
        return value


class ResendInvitationRequest(BaseModel):
    """Request model for resending invitation."""

    tenant_id: str = Field(..., description="Tenant ID")
    email: EmailStr = Field(..., description="Email to resend invitation to")


class UpdateBehavioralStopsRequest(BaseModel):
    """Request to update behavioral stops (Part 9.0B)."""

    paused: bool | None = None
    pause_reason: str | None = None

    pause_autonomy: bool | None = None

    blocked_tools: list[str] | None = None
    blocked_operation_types: list[str] | None = None

    quiet_hours_enabled: bool | None = None
    quiet_hours_start: str | None = None
    quiet_hours_end: str | None = None
    quiet_hours_blocked_types: list[str] | None = None

    interrupt_budget_enabled: bool | None = None
    max_notifications_per_day: int | None = None
    max_messages_per_hour: int | None = None

    learning_agility: Literal["conservative", "moderate", "aggressive"] | None = None
    adaptation_mode: Literal["manual_review", "recommend_reversible", "auto_reversible"] | None = None
    confirmation_mode: Literal["strict", "balanced", "light"] | None = None
    proactive_learning_enabled: bool | None = None
    signal_horizon: Literal["ephemeral", "seasonal", "durable"] | None = None
    drift_sensitivity: Literal["high", "medium", "low"] | None = None


# ============================================================================
# Response Models
# ============================================================================


class LoginResponse(BaseModel):
    """Response model for successful login.

    Attributes:
        access_token: JWT access token
        refresh_token: JWT refresh token
        token_type: Type of token (Bearer)
        expires_in: Token expiration time in seconds
        tenant_id: User's tenant ID
        user_id: User's ID
        email: User's email
        role: User's role
    """

    access_token: str = Field(..., description="JWT access token")
    refresh_token: str | None = Field(None, description="JWT refresh token")
    token_type: str = Field(default="Bearer", description="Token type")
    expires_in: int = Field(..., description="Token expiration in seconds")
    tenant_id: str = Field(..., description="User's tenant ID")
    user_id: str = Field(..., description="User's ID")
    email: str = Field(..., description="User's email")
    role: str = Field(..., description="User's role")
    auth_provider: str | None = Field(None, description="Authentication method used for this session")
    auth_source: Literal["browser-pair", "device-code", "password"] | None = Field(
        None,
        description="Surface that created this session.",
    )


class LoginChallengeResponse(BaseModel):
    """Response model for MFA challenge continuation."""

    status: Literal["challenge_required"] = Field(
        default="challenge_required",
        description="Signals that additional MFA work is required before login completes",
    )
    challenge_name: Literal["MFA_SETUP", "SOFTWARE_TOKEN_MFA"] = Field(
        ...,
        description="Identity-provider challenge name",
    )
    challenge_token: str = Field(..., description="Short-lived signed challenge continuation token")
    email: str = Field(..., description="User email for the challenged login")
    expires_in: int = Field(..., description="Challenge token expiration in seconds")
    message: str = Field(..., description="Human-readable next step")
    secret_code: str | None = Field(
        None,
        description="Base32 TOTP secret for MFA setup flows. Present only for MFA_SETUP.",
    )
    otpauth_uri: str | None = Field(
        None,
        description="otpauth:// URI for authenticator apps. Present only for MFA_SETUP.",
    )


class SignupResponse(BaseModel):
    """Response model for successful signup.

    Attributes:
        tenant_id: Unique tenant identifier
        user_id: Unique user identifier
        status: Tenant status (should be PENDING_PAYMENT)
        email: User's email
        role: User's role (should be ADMIN)
        auth_provider: Authentication provider used
        next_step: Next action required (stripe_checkout/runtime_ready)
        stripe_checkout_url: URL for Stripe checkout
    """

    tenant_id: str = Field(..., description="Unique tenant identifier")
    user_id: str = Field(..., description="Unique user identifier")
    status: str = Field(..., description="Tenant status")
    email: str = Field(..., description="User's email")
    role: str = Field(..., description="User's role")
    auth_provider: str = Field(..., description="Authentication provider")
    next_step: str = Field(..., description="Next action required")
    provisioning_mode: str = Field(
        default="stripe_checkout",
        description="Provisioning route used (stripe_checkout/org_workspace_bootstrap/internal_bypass)",
    )
    stripe_checkout_url: str | None = Field(None, description="Stripe checkout URL")
    runtime_instance_id: str | None = Field(None, description="Provisioned Workweaver Runtime instance ID")
    runtime_public_ip: str | None = Field(None, description="Provisioned Workweaver Runtime public IP")
    runtime_endpoint: str | None = Field(None, description="Tenant Workweaver Runtime endpoint URL")
    runtime_launch_url: str | None = Field(
        None,
        description="Deprecated compatibility field. Launch URLs are no longer returned to clients.",
    )
    runtime_status: str | None = Field(None, description="Workweaver Runtime provisioning status")
    runtime_provisioning_token: str | None = Field(
        None,
        description="Short-lived token for runtime provisioning status polling.",
    )
    runtime_step: str | None = Field(None, description="Runtime provisioning step")
    selected_region_code: str | None = Field(None, description="Chosen AWS region code for tenant provisioning")
    selected_region_label: str | None = Field(None, description="Chosen region label shown to the user")


class SignupRegionOption(BaseModel):
    """Region option shown in signup UX."""

    label: str = Field(..., description="Human-readable region label")
    code: str = Field(..., description="AWS region code")


class SignupRegionsResponse(BaseModel):
    """Available region options for signup."""

    options: list[SignupRegionOption] = Field(..., description="Selectable region options")
    default_external_region_code: str = Field(..., description="Default region code for non-internal users")
    default_external_region_label: str = Field(..., description="Default region label for non-internal users")
    internal_region_code: str = Field(..., description="Fixed region code for internal users")
    internal_region_label: str = Field(..., description="Fixed region label for internal users")


class GoogleAuthConfigResponse(BaseModel):
    """Response model for public Google OAuth frontend configuration."""

    enabled: bool = Field(..., description="Whether Google signup is enabled")
    client_id: str | None = Field(None, description="Google OAuth client ID")
    allowed_domain: str | None = Field(None, description="Allowed email domain for provisioning")
    internal_bypass_domains: list[str] | None = Field(
        None, description="Domains that bypass Stripe and auto-provision Workweaver Runtime"
    )
    monthly_price_usd: int = Field(..., description="Monthly Stripe price in USD for non-internal users")
    region_options: list[SignupRegionOption] = Field(
        default_factory=list,
        description="Human-readable regions selectable during signup",
    )


class OAuthProviderConfig(BaseModel):
    """Config for a single OAuth provider."""

    enabled: bool = Field(..., description="Whether this provider is enabled")
    client_id: str | None = Field(None, description="OAuth client ID (only for client-side flows like Google)")
    display_name: str | None = Field(None, description="Human-readable provider label for the auth UI")
    device_code_enabled: bool = Field(
        default=False,
        description="Whether device-code login is available for this provider.",
    )


class UnifiedOAuthConfigResponse(BaseModel):
    """Response model for unified OAuth configuration (all providers)."""

    google: OAuthProviderConfig
    microsoft: OAuthProviderConfig
    oidc: OAuthProviderConfig
    zoho: OAuthProviderConfig
    allowed_domain: str | None = Field(None, description="Allowed email domain for provisioning")
    internal_bypass_domains: list[str] | None = Field(
        None, description="Domains that bypass Stripe and auto-provision Workweaver Runtime"
    )
    monthly_price_usd: int = Field(..., description="Monthly Stripe price in USD for non-internal users")
    region_options: list[SignupRegionOption] = Field(
        default_factory=list,
        description="Human-readable regions selectable during signup",
    )


class RuntimeProvisioningStatusResponse(BaseModel):
    """Provisioning status surface for the HQ provisioning page (Part 2)."""

    runtime: dict[str, Any] = Field(default_factory=dict)
    runtime_status: str | None = None
    runtime_endpoint: str | None = None
    runtime_launch_url: str | None = Field(
        default=None,
        description="Deprecated compatibility field. Launch URLs are no longer returned to clients.",
    )
    runtime_step: str | None = None
    bootstrap_step: str | None = None  # e.g. "gateway_init", "skill_catalog", "health_check"
    next_action: str | None = None
    next_check_seconds: int = 5
    execute_blockers: list[str] = Field(default_factory=list)  # reasons execution is blocked

    @model_validator(mode="after")
    def _mirror_runtime_payload(self) -> "RuntimeProvisioningStatusResponse":
        if not self.runtime_step and self.bootstrap_step:
            self.runtime_step = self.bootstrap_step

        if not self.bootstrap_step and self.runtime_step:
            self.bootstrap_step = self.runtime_step
        if not self.next_action:
            runtime_next_action = None
            if isinstance(self.runtime, dict):
                runtime_next_action = str(self.runtime.get("next_action") or "").strip() or None
            if runtime_next_action:
                self.next_action = runtime_next_action
            else:
                normalized_status = str(self.runtime_status or "").strip().lower()
                if normalized_status == "ready":
                    self.next_action = "ready"
                elif normalized_status in {"failed", "error"}:
                    self.next_action = "retry"
                elif normalized_status == "disabled":
                    self.next_action = "disabled"
                else:
                    self.next_action = "poll"
        return self


class BehavioralStops(BaseModel):
    """Tenant-level behavioral stop controls (Part 9.0B)."""

    paused: bool = False
    paused_at: str | None = None
    paused_by: str | None = None
    pause_reason: str | None = None

    pause_autonomy: bool = False
    pause_autonomy_at: str | None = None

    blocked_tools: list[str] = []
    blocked_operation_types: list[str] = []

    quiet_hours_enabled: bool = False
    quiet_hours_start: str | None = None  # "20:00"
    quiet_hours_end: str | None = None  # "08:00"
    quiet_hours_blocked_types: list[str] = []

    interrupt_budget_enabled: bool = False
    max_notifications_per_day: int = 3
    max_messages_per_hour: int = 5

    learning_agility: Literal["conservative", "moderate", "aggressive"] = "moderate"
    adaptation_mode: Literal["manual_review", "recommend_reversible", "auto_reversible"] = "recommend_reversible"
    confirmation_mode: Literal["strict", "balanced", "light"] = "balanced"
    proactive_learning_enabled: bool = True
    signal_horizon: Literal["ephemeral", "seasonal", "durable"] = "seasonal"
    drift_sensitivity: Literal["high", "medium", "low"] = "medium"


class AuthMeResponse(BaseModel):
    """Auth state for marketing/app route gating."""

    authenticated: bool = False
    tenant_id: str | None = None
    # Tenant URL slug — DNS-safe label used by the tenant-scoped path
    # pattern ``workweaver.ai/<tenant_slug>/`` (#2757). The runtime
    # consumes this to validate the URL prefix against the authenticated
    # tenant; mismatch raises a "switch workspace" prompt rather than a
    # silent cross-tenant view. Populated by
    # ``apps.backend.utils.tenant.derive_tenant_slug`` (deterministic from
    # ``tenant_id``); never the raw email.
    tenant_slug: str | None = None
    user_id: str | None = None
    email: str | None = None
    # Display name for the authenticated user. Resolved from the tenant
    # record's owner_name (signup-time SSO name) when available, with
    # fallback to the email local-part. Used by Settings → Profile to
    # pre-populate the name field on first load.
    user_name: str | None = None
    # T7 of Settings IA redesign — admin portal gate.
    # True when the authenticated user's email is on the admin allowlist
    # (env var WORKWEAVER_ADMIN_EMAILS, comma-separated). Read by the
    # admin.workweaver.ai/portal SPA.
    is_admin: bool = False
    tenant_state: str | None = None
    next_action: str = "signup"
    runtime_status: str | None = None
    workweaver_runtime_status: str | None = None
    onboarding_status: str | None = None
    onboarding_current_step: str | None = None
    onboarding_required: bool = False
    onboarding_completed: bool = False

    # Tenant lifecycle status (trial, active, stopped, etc.)
    tenant_status: str | None = None
    # ISO timestamp when trial expires (only set for trial tenants)
    trial_expires_at: str | None = None

    # Part 9: Safety Controls
    preflight_status: str = "green"  # red, yellow, green
    execution_posture: str = "no_execute"  # no_execute, execute
    behavioral_stops: BehavioralStops | None = None

    @model_validator(mode="after")
    def _mirror_runtime_status(self) -> "AuthMeResponse":
        if not self.workweaver_runtime_status and self.runtime_status:
            self.workweaver_runtime_status = self.runtime_status
        if not self.runtime_status and self.workweaver_runtime_status:
            self.runtime_status = self.workweaver_runtime_status
        return self
