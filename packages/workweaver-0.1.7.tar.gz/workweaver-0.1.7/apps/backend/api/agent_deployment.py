"""Agent Deployment and Quick Agent APIs for Mission Control.

Two-step activation flow:
1. POST /generate-profile — LLM generates profile from NL description
2. POST /confirm — User confirms (possibly edited) profile, agent is created

Quick Agent flow:
1. POST /quick-agent/plan — build a runnable plan with connector/risk preview
2. POST /quick-agent/run — execute the first run or return an explicit blocked reason
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta, UTC
from decimal import Decimal
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field
import ulid

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.schemas.error_response import safe_error_detail

ACTIVATE_PREFIX = "/api/v1/mission/activate"
HIRE_PREFIX = "/api/v1/mission/hire"

router = APIRouter(tags=["agent-deployment"])
logger = logging.getLogger(__name__)

CANONICAL_WORK_QUICK_AGENT_HREF = "/runtime/?surface=work&tab=actions"
CANONICAL_RUNTIME_INTEGRATIONS_HREF = "/runtime/?surface=integrations"
CANONICAL_TASKS_HREF = "/runtime/?surface=tasks-board"
CANONICAL_PROOF_HREF = "/runtime/?surface=proof&tab=trail"

CONNECTOR_REQUIREMENT_MAP = {
    "calendar": {
        "integration_name": "Google Calendar",
        "aliases": {"google calendar", "google-workspace", "google workspace"},
        "state_when_unconnected": "needs_auth",
        "reason": "Needed to coordinate calendars, meetings, and time-based work.",
    },
    "gmail": {
        "integration_name": "Gmail",
        "aliases": {"gmail", "google-workspace", "google workspace", "email"},
        "state_when_unconnected": "needs_auth",
        "reason": "Needed for outbound email and inbox-follow-up tasks.",
    },
    "slack": {
        "integration_name": "Slack",
        "aliases": {"slack"},
        "state_when_unconnected": "needs_auth",
        "reason": "Needed for channel notifications, approvals, and team follow-through.",
    },
    "crm": {
        "integration_name": "HubSpot",
        "aliases": {"hubspot", "hubspot crm", "salesforce", "zoho crm", "crm"},
        "state_when_unconnected": "available",
        "reason": "CRM-backed tasks are available in the wider catalog, but not in the verified Wave 1 Quick Agent lane.",
    },
}


def _apply_legacy_hire_headers(request: Request, response: Response) -> None:
    path = str(getattr(request.url, "path", "") or "")
    if not path.startswith(HIRE_PREFIX):
        return
    response.headers["Deprecation"] = "true"
    response.headers["Link"] = f'<{path.replace(HIRE_PREFIX, ACTIVATE_PREFIX, 1)}>; rel="successor-version"'


def _get_service():
    from apps.backend.services.agent_activation_service import get_agent_activation_service

    return get_agent_activation_service()


def _get_task_store():
    from apps.backend.services.task_store import get_task_store

    return get_task_store()


def _get_schedule_store():
    from apps.backend.services.scheduling.store import get_schedule_store

    return get_schedule_store()


def _get_evidence_ledger_service():
    from apps.backend.services.evidence_ledger import get_evidence_ledger_service

    return get_evidence_ledger_service()


def _get_integration_manager():
    from apps.backend.services.integration_manager import IntegrationManager

    return IntegrationManager()


def _get_connectors_marketplace():
    from apps.backend.services.connectors.marketplace import get_connectors_marketplace

    return get_connectors_marketplace()


def _get_run_state_service():
    from apps.backend.services.mission_run.state import get_mission_run_state_service

    return get_mission_run_state_service()


def _get_governed_swarm_service():
    from apps.backend.services.governed_swarm_service import get_governed_swarm_service

    return get_governed_swarm_service()


def _get_identity_governance():
    from apps.backend.services.agent_identity_governance import get_agent_identity_governance

    return get_agent_identity_governance()


def _get_swarm_scheduler():
    from apps.backend.services.swarm_scheduler import get_swarm_scheduler

    return get_swarm_scheduler()


def _get_block_planner():
    from apps.backend.services.planning.block_planner import BlockPlanner

    return BlockPlanner()


def _get_autoresearch_orchestrator():
    from apps.backend.services.autoresearch.orchestrator import AutoresearchOrchestrator

    return AutoresearchOrchestrator()


def _get_work_ledger():
    from apps.backend.services.agent_work_ledger import get_agent_work_ledger_service

    return get_agent_work_ledger_service()


def _get_memory_service():
    from apps.backend.services.memory.service import get_memory_service as _get

    return _get()


async def _recall_relevant_memory(tenant_id: str, objective: str) -> dict[str, Any]:
    """Recall facts and patterns relevant to the planning objective.

    Non-blocking: if the memory service raises, returns empty defaults so
    that the plan endpoint is never gated on memory availability.
    """
    try:
        memory = _get_memory_service()
        facts = memory.get_facts(tenant_id, scope="org", limit=20)
        all_patterns = memory.get_patterns(tenant_id)
        # Slice to top 10 patterns (already sorted by confidence desc in the service)
        patterns = all_patterns[:10]
        return {
            "recalled_facts": facts,
            "recalled_patterns": patterns,
            "memory_facts_count": len(facts),
        }
    except Exception as exc:
        logger.warning(
            "Memory recall failed for tenant=%s (non-blocking): %s",
            tenant_id,
            exc,
        )
        return {
            "recalled_facts": [],
            "recalled_patterns": [],
            "memory_facts_count": 0,
        }


async def _rollback_quick_agent_activation(
    *,
    service: Any | None,
    tenant_id: str,
    agent_id: str | None,
    task_id: str | None,
    schedule_id: str | None,
) -> None:
    # Undo side effects in reverse creation order so later resources do not
    # outlive their parents during a partial quick-agent activation failure.
    if schedule_id:
        try:
            _get_schedule_store().delete_schedule(tenant_id, schedule_id)
        except Exception as exc:
            logger.warning("Quick agent rollback failed to delete schedule %s: %s", schedule_id, exc)

    if task_id:
        try:
            from apps.backend.services.execution.workitem_service import get_workitem_service

            get_workitem_service().delete_work_item(
                tenant_id=tenant_id,
                item_id=task_id,
                goal_store=None,
                task_store=_get_task_store(),
                source_kind="task",
            )
        except Exception as exc:
            logger.warning("Quick agent rollback failed to delete work item %s: %s", task_id, exc)

    if agent_id and service is not None and hasattr(service, "rollback_activation"):
        try:
            await service.rollback_activation(tenant_id=tenant_id, agent_id=agent_id)
        except Exception as exc:
            logger.warning("Quick agent rollback failed to remove agent %s: %s", agent_id, exc)


def _fail_quick_agent_execution(
    *,
    tenant_id: str,
    swarm_scheduler: Any | None,
    swarm_execution: Any | None,
) -> None:
    try:
        if swarm_scheduler is not None and swarm_execution is not None:
            swarm_scheduler.fail(tenant_id, swarm_execution.execution_id)
    except Exception as exc:
        logger.warning("Quick agent rollback failed to mark scheduler execution as failed: %s", exc)


def _fail_quick_agent_run_state(
    *,
    tenant_id: str,
    run_state_service: Any | None,
    run_id: str | None,
    reason: str,
) -> None:
    try:
        if run_state_service is not None and run_id:
            run_state_service.apply_command(
                tenant_id=tenant_id,
                run_id=run_id,
                command="fail",
                actor="quick_agent",
                payload={"reason": reason},
            )
    except Exception as exc:
        logger.warning("Quick agent rollback failed to mark run %s as failed: %s", run_id, exc)


async def _compensate_failed_quick_agent_execution(
    *,
    service: Any | None,
    tenant_id: str,
    agent_id: str | None,
    task_id: str | None,
    schedule_id: str | None,
    swarm_scheduler: Any | None,
    swarm_execution: Any | None,
    run_state_service: Any | None,
    run_id: str | None,
    run_failure_reason: str = "quick_agent_setup_failed",
) -> None:
    await _rollback_quick_agent_activation(
        service=service,
        tenant_id=tenant_id,
        agent_id=agent_id,
        task_id=task_id,
        schedule_id=schedule_id,
    )
    _fail_quick_agent_execution(
        tenant_id=tenant_id,
        swarm_scheduler=swarm_scheduler,
        swarm_execution=swarm_execution,
    )
    _fail_quick_agent_run_state(
        tenant_id=tenant_id,
        run_state_service=run_state_service,
        run_id=run_id,
        reason=run_failure_reason,
    )


def _format_memory_insights(memory_context: dict[str, Any]) -> list[str]:
    """Format recalled facts and patterns as human-readable insight strings.

    Capped at 5 entries to keep the first_run_preview concise.
    """
    insights: list[str] = []
    max_insights = 5

    for fact in memory_context.get("recalled_facts") or []:
        if len(insights) >= max_insights:
            break
        key = str(fact.get("key") or "")
        value = str(fact.get("value") or "")
        if key and value:
            insights.append(f"{key}: {value}")

    for pattern in memory_context.get("recalled_patterns") or []:
        if len(insights) >= max_insights:
            break
        text = str(pattern.get("pattern") or "")
        if text:
            insights.append(text)

    return insights


def _entropy_plan_warning(tenant_id: str) -> str | None:
    """Return the Quick Agent plan warning while entropy escalation is active."""
    try:
        from apps.backend.services.tenant_config import get_tenant_config

        config = get_tenant_config(tenant_id)
    except Exception:
        return None
    if not bool(config.get("entropy_escalation_active")):
        return None
    threshold = config.get("behavioral_entropy_threshold", 2.5)
    expires_at = config.get("entropy_escalation_expires_at") or "the next review window"
    return (
        "Behavioral entropy is above the tenant threshold "
        f"({threshold} nats). Auto-approval is paused until {expires_at}; "
        "review approvals before starting live work."
    )


def _combine_generation_warnings(*warnings: str | None) -> str | None:
    """Join generation warnings without empty fragments."""
    parts = [str(w).strip() for w in warnings if str(w or "").strip()]
    return " ".join(parts) if parts else None


class GenerateProfileRequest(BaseModel):
    job_description: str = Field(..., min_length=10, description="Plain English job description")


class GenerateProfileResponse(BaseModel):
    name: str
    role: str
    job_description: str
    skills: list[str] = []
    tools: list[dict] = []
    rules: list[str] = []
    schedule: dict | None = None
    success_criteria: list[str] = []
    source_description: str = ""
    generation_mode: str = "moonshot"
    generation_warning: str | None = None


class ConnectorRequirementResponse(BaseModel):
    key: str
    integration_name: str
    required: bool = True
    state: str = "available"
    reason: str = ""
    verified_path: bool = True
    connect_href: str = CANONICAL_RUNTIME_INTEGRATIONS_HREF


class QuickAgentPlanRequest(BaseModel):
    objective: str = Field(..., min_length=10, description="Natural-language outcome to achieve")
    swarm_mode: str = Field("auto", pattern="^(auto|solo|assisted|pod|cell|simulation)$")
    coordination_protocol: str = Field("auto", pattern="^(auto|sequential|parallel|pipeline)$")
    max_workers: int | None = Field(None, ge=1, le=64)
    max_depth: int | None = Field(None, ge=0, le=8)
    max_concurrency: int | None = Field(None, ge=1, le=64)
    merge_strategy: str | None = Field(
        None,
        pattern="^(first_success|majority|weighted_vote|synthesized_merge|human_review)$",
    )
    approval_threshold: str | None = Field(None, pattern="^(per_action|summary|mission|outcome|none)$")
    simulation_scenario: str | None = Field(None, max_length=10000)


class QuickAgentPlanResponse(BaseModel):
    objective: str
    name: str
    role: str
    job_description: str
    skills: list[str] = []
    tools: list[dict] = []
    rules: list[str] = []
    schedule: dict | None = None
    success_criteria: list[str] = []
    source_description: str = ""
    generation_mode: str = "moonshot"
    generation_warning: str | None = None
    risk_level: str = "low"
    first_run_preview: list[str] = []
    connector_requirements: list[ConnectorRequirementResponse] = []
    missing_connectors: list[str] = []
    can_run: bool = False
    run_href: str = CANONICAL_WORK_QUICK_AGENT_HREF
    integrations_href: str = CANONICAL_RUNTIME_INTEGRATIONS_HREF
    swarm_mode: str = "assisted"
    swarm_mode_source: str = "automatic"
    proof_plane: str = "production"
    merge_strategy: str = "synthesized_merge"
    approval_threshold: str = "summary"
    budget_estimate_usd: str = "0.00"
    budget_preview: str = ""
    swarm_defaults: dict[str, Any] = Field(default_factory=dict)
    block_plan: list[dict[str, Any]] = Field(default_factory=list)
    planner_summary: str = ""
    autoresearch: dict[str, Any] = Field(default_factory=dict)
    memory_facts_used: int = 0
    recalled_insights: list[str] = Field(default_factory=list)


class ConfirmActivationRequest(BaseModel):
    name: str = Field(..., description="Agent name (user may have edited)")
    role: str = Field("AI Agent", description="Agent role")
    job_description: str = Field("", description="Job description")
    skills: list[str] = Field(default_factory=list)
    tools: list[dict] = Field(default_factory=list)
    rules: list[str] = Field(default_factory=list)
    schedule: dict | None = Field(None)
    success_criteria: list[str] = Field(default_factory=list)
    personality: dict | None = Field(None)
    source_description: str = Field("", description="Original NL description")
    parent_node_id: str | None = Field(
        None,
        description="Optional target team node ID for initial placement",
    )
    identity_mode: str = Field(
        default="shared",
        description="Identity mode (shared|dedicated)",
    )
    identity_config: dict[str, Any] | None = Field(
        default=None,
        description="Optional dedicated identity provisioning config",
    )


class ActivatedAgentResponse(BaseModel):
    agent_id: str
    name: str
    role: str
    job_description: str
    status: str
    identity_mode: str = "shared"
    identity_status: str = "unknown"
    identity: dict[str, Any] | None = None
    skills: list[str] = []
    tools: list[dict] = []
    rules: list[str] = []
    schedule: dict | None = None
    success_criteria: list[str] = []
    created_at: str


# Backward-compatible alias
HiredAgentResponse = ActivatedAgentResponse


class ElevateIdentityRequest(BaseModel):
    identity_config: dict[str, Any] = Field(default_factory=dict)


class ElevateIdentityResponse(BaseModel):
    agent_id: str
    identity_mode: str
    identity_status: str
    identity: dict[str, Any]


class QuickAgentRunRequest(ConfirmActivationRequest):
    connector_requirements: list[ConnectorRequirementResponse] = Field(default_factory=list)
    activate_schedule: bool = Field(
        default=True,
        description="Create the suggested schedule when the plan recommends a recurring cadence.",
    )
    swarm_mode: str = Field("auto", pattern="^(auto|solo|assisted|pod|cell|simulation)$")
    coordination_protocol: str = Field("auto", pattern="^(auto|sequential|parallel|pipeline)$")
    max_workers: int | None = Field(None, ge=1, le=64)
    max_depth: int | None = Field(None, ge=0, le=8)
    max_concurrency: int | None = Field(None, ge=1, le=64)
    merge_strategy: str | None = Field(
        None,
        pattern="^(first_success|majority|weighted_vote|synthesized_merge|human_review)$",
    )
    approval_threshold: str | None = Field(None, pattern="^(per_action|summary|mission|outcome|none)$")
    simulation_scenario: str | None = Field(None, max_length=10000)


class QuickAgentRunResponse(BaseModel):
    status: str
    blocked_reason: str | None = None
    risk_level: str = "low"
    agent_id: str | None = None
    agent_name: str | None = None
    task_id: str | None = None
    task_title: str | None = None
    schedule_id: str | None = None
    evidence_id: str | None = None
    evidence_url: str | None = None
    work_url: str = CANONICAL_TASKS_HREF
    proof_url: str = CANONICAL_PROOF_HREF
    integrations_url: str = CANONICAL_RUNTIME_INTEGRATIONS_HREF
    connector_requirements: list[ConnectorRequirementResponse] = []
    missing_connectors: list[str] = []
    summary: str = ""
    run_id: str | None = None
    swarm_mode: str = "assisted"
    swarm_mode_source: str = "automatic"
    proof_plane: str = "production"
    budget_estimate_usd: str = "0.00"
    budget_preview: str = ""
    swarm_monitor: dict[str, Any] = Field(default_factory=dict)
    lineage_url: str | None = None
    export_url: str | None = None
    block_plan: list[dict[str, Any]] = Field(default_factory=list)
    planner_summary: str = ""
    simulation_recommended: bool = False
    # M6.6: Cold Start Scaling UX fields
    scaling_in_progress: bool = False
    retry_after_ms: int = 0


def _normalize_schedule(schedule: dict[str, Any] | None) -> dict[str, Any] | None:
    if not isinstance(schedule, dict):
        return None
    schedule_type = str(schedule.get("type") or "").strip().lower() or "one_time"
    cron_expression = str(
        schedule.get("cron_expression") or schedule.get("cron") or "",
    ).strip()
    description = str(schedule.get("description") or "").strip()
    normalized = {
        "type": schedule_type,
        "description": description,
    }
    if cron_expression:
        normalized["cron_expression"] = cron_expression
    return normalized


def _normalize_tool_provider(tool: Any) -> str:
    if isinstance(tool, str):
        return tool.strip().lower()
    if isinstance(tool, dict):
        return str(tool.get("provider") or tool.get("name") or "").strip().lower()
    return ""


def _connector_key_for_tool(tool: Any) -> str | None:
    provider = _normalize_tool_provider(tool)
    if not provider or provider in {"workweaver", "documents", "sheets", "notion", "support"}:
        return None
    if provider in {"calendar", "google calendar", "google_calendar"}:
        return "calendar"
    if provider in {"email", "mail", "gmail", "gmail_api"}:
        return "gmail"
    if provider == "slack":
        return "slack"
    if provider in {"crm", "hubspot", "hubspot crm", "salesforce", "zoho crm", "zoho_crm"}:
        return "crm"
    return None


def _estimate_risk_level(objective: str, tools: list[dict[str, Any]]) -> str:
    normalized = f"{objective} {' '.join(_normalize_tool_provider(tool) for tool in tools)}".lower()
    if any(term in normalized for term in ("refund", "payment", "invoice", "delete", "terminate", "legal")):
        return "high"
    if any(term in normalized for term in ("email", "slack", "calendar", "crm", "lead", "customer")):
        return "medium"
    return "low"


def _build_first_run_preview(
    *,
    objective: str,
    profile: dict[str, Any],
    schedule: dict[str, Any] | None,
    risk_level: str,
) -> list[str]:
    role = str(profile.get("role") or "AI Employee").strip()
    name = str(profile.get("name") or "Agent").strip()
    preview = [
        f"Activate {name} as {role} using the existing activation and team primitives.",
        f"Create a tracked first task for: {objective.strip()}",
        f"Run with a {risk_level} risk posture and proof-backed status updates.",
    ]
    if schedule and schedule.get("type") == "recurring":
        preview.append(f"Attach the suggested recurring schedule: {schedule.get('description') or 'Recurring run'}")
    return preview


def _normalize_swarm_mode(mode: str | None, *, allow_auto: bool = False) -> str:
    default_value = "auto" if allow_auto else "assisted"
    value = str(mode or default_value).strip().lower() or default_value
    allowed = {"solo", "assisted", "pod", "cell", "simulation"}
    if allow_auto:
        allowed.add("auto")
    if value not in allowed:
        raise ValueError(f"swarm_mode must be one of: {', '.join(sorted(allowed))}")
    return value


def _base_budget_for_risk(risk_level: str) -> float:
    normalized = str(risk_level or "").strip().lower()
    if normalized == "high":
        return 3.0
    if normalized == "medium":
        return 2.0
    return 1.0


def _budget_preview(envelope: dict[str, Any]) -> str:
    return (
        f"{str(envelope.get('swarm_mode') or '').title()} mode "
        f"· up to {int(envelope.get('max_workers') or 0)} worker(s) "
        f"· budget ${str(envelope.get('approved_usd') or '0')} "
        f"· approval {str(envelope.get('approval_threshold') or '')} "
        f"· plane {str(envelope.get('proof_plane') or '')}"
    )


async def _resolve_connector_requirements(
    *,
    tenant_id: str,
    tools: list[dict[str, Any]],
) -> list[ConnectorRequirementResponse]:
    manager = _get_integration_manager()
    marketplace = _get_connectors_marketplace()

    connected_integrations = set()
    try:
        connections = await manager.list_connections(tenant_id=tenant_id)
        for connection in connections:
            if str(connection.state.value) == "connected":
                connected_integrations.add(str(connection.integration_name or "").strip().lower())
    except Exception as exc:  # pragma: no cover - best effort signal enrichment
        logger.warning("Unable to read OAuth connections for quick agent plan: tenant=%s error=%s", tenant_id, exc)

    try:
        installed = marketplace.get_installed(tenant_id)
        for item in installed:
            connected_integrations.add(str(item.get("id") or "").strip().lower())
            connected_integrations.add(str(item.get("name") or "").strip().lower())
    except Exception as exc:  # pragma: no cover - best effort signal enrichment
        logger.warning("Unable to read connector installs for quick agent plan: tenant=%s error=%s", tenant_id, exc)

    requirements: list[ConnectorRequirementResponse] = []
    seen_keys: set[str] = set()
    for tool in tools:
        connector_key = _connector_key_for_tool(tool)
        if not connector_key or connector_key in seen_keys:
            continue
        seen_keys.add(connector_key)
        metadata = CONNECTOR_REQUIREMENT_MAP[connector_key]
        integration_name = str(metadata["integration_name"])
        aliases = {integration_name.lower(), *metadata["aliases"]}
        verified = any(alias in connected_integrations for alias in aliases)
        state = "verified" if verified else str(metadata["state_when_unconnected"])
        verified_path = connector_key in {"calendar", "gmail", "slack"}
        requirements.append(
            ConnectorRequirementResponse(
                key=connector_key,
                integration_name=integration_name,
                required=True,
                state=state,
                reason=str(metadata["reason"]),
                verified_path=verified_path,
            )
        )

    return requirements


def _missing_connector_names(requirements: list[ConnectorRequirementResponse]) -> list[str]:
    return [
        requirement.integration_name
        for requirement in requirements
        if requirement.required and requirement.state != "verified"
    ]


def _record_quick_agent_evidence(
    *,
    tenant_id: str,
    event_type: str,
    objective: str,
    data: dict[str, Any],
) -> str:
    evidence = _get_evidence_ledger_service().ingest(
        tenant_id=tenant_id,
        event_type=event_type,
        scope_type="quick_agent",
        scope_id="quick-agent",
        data={
            "objective": objective,
            **data,
        },
        artifact_payload={
            "objective": objective,
            "recorded_at": datetime.now(UTC).isoformat(),
            **data,
        },
    )
    return str(evidence.get("evidence_id") or "")


def _compress_autoresearch_report(report: Any) -> dict[str, Any]:
    if report is None:
        return {}
    payload = report.model_dump(mode="json") if hasattr(report, "model_dump") else dict(report)
    payload["findings"] = list(payload.get("findings") or [])[:3]
    payload["recommendations"] = list(payload.get("recommendations") or [])[:3]
    return payload


def _seed_block_plan(
    *,
    tenant_id: str,
    root_block_id: str,
    mission_id: str,
    run_id: str,
    agent_id: str,
    swarm_mode: str,
    execution_lane: str,
    blocks: list[dict[str, Any]],
) -> None:
    ledger = _get_work_ledger()
    cursor = datetime.now(UTC)
    for block in blocks:
        budget_minutes = int(block.get("duration_budget_minutes") or 15)
        created = ledger.create_block(
            {
                "tenant_id": tenant_id,
                "mission_id": mission_id,
                "run_id": run_id,
                "agent_id": agent_id,
                "parent_block_id": root_block_id,
                "execution_lane": execution_lane,
                "swarm_mode": swarm_mode,
                "phase": str(block.get("phase") or "execute"),
                "state": "planned",
                "outcome": "unknown",
                "objective": str(block.get("objective") or ""),
                "plan": str(block.get("plan") or ""),
                "duration_budget_minutes": budget_minutes,
                "started_at": cursor.isoformat(),
                "expected_artifacts": list(block.get("expected_artifacts") or []),
                "origin": "user",
                "metadata": {
                    "planned": True,
                    "rationale": str(block.get("rationale") or ""),
                },
            },
            emit_evidence=False,
        )
        ledger.link_child_block(tenant_id, root_block_id, created.block_id)
        cursor += timedelta(minutes=budget_minutes)


@router.post(f"{ACTIVATE_PREFIX}/generate-profile", response_model=GenerateProfileResponse)
@router.post(f"{HIRE_PREFIX}/generate-profile", response_model=GenerateProfileResponse, include_in_schema=False)
async def generate_profile(
    request: GenerateProfileRequest,
    http_request: Request,
    response: Response,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Step 1: Generate AI agent profile from natural language description."""
    try:
        _apply_legacy_hire_headers(http_request, response)
        service = _get_service()
        profile = await service.generate_profile(tenant_id, request.job_description)
        return GenerateProfileResponse(**{k: v for k, v in profile.items() if k != "tenant_id"})
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception as exc:
        logger.exception("Failed to generate activation profile: tenant=%s error=%s", tenant_id, exc)
        raise HTTPException(status_code=500, detail="Failed to generate profile")


@router.post(f"{ACTIVATE_PREFIX}/quick-agent/plan", response_model=QuickAgentPlanResponse)
@router.post(f"{HIRE_PREFIX}/quick-agent/plan", response_model=QuickAgentPlanResponse, include_in_schema=False)
async def quick_agent_plan(
    request: QuickAgentPlanRequest,
    http_request: Request,
    response: Response,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Plan the first Quick Agent run using the existing activation primitives."""
    try:
        _apply_legacy_hire_headers(http_request, response)
        service = _get_service()
        profile = await service.generate_profile(tenant_id, request.objective)
        schedule = _normalize_schedule(profile.get("schedule"))
        connector_requirements = await _resolve_connector_requirements(
            tenant_id=tenant_id,
            tools=list(profile.get("tools") or []),
        )
        risk_level = _estimate_risk_level(request.objective, list(profile.get("tools") or []))
        requested_swarm_mode = _normalize_swarm_mode(request.swarm_mode, allow_auto=True)
        history = _get_work_ledger().list_blocks(tenant_id, limit=500)
        autoresearch_report = await _get_autoresearch_orchestrator().evaluate(
            tenant_id=tenant_id,
            blocks=history,
            lane="simulation",
        )
        memory_context = await _recall_relevant_memory(tenant_id, request.objective)
        planner = _get_block_planner().plan_goal(
            request.objective,
            risk_level=risk_level,
            requested_swarm_mode=requested_swarm_mode,
            execution_lane="simulation" if requested_swarm_mode == "simulation" else "production",
            autoresearch_report=autoresearch_report.model_dump(mode="json"),
        )
        swarm_mode = planner.recommended_swarm_mode
        budget_envelope = (
            _get_governed_swarm_service()
            .build_budget_envelope(
                run_id=f"plan-{ulid.new().str}",
                mission_id="quick-agent-plan",
                mode=swarm_mode,
                base_budget_usd=_base_budget_for_risk(risk_level),
                requested_workers=request.max_workers,
                max_depth=request.max_depth,
                max_concurrency=request.max_concurrency,
                merge_strategy=request.merge_strategy,
                approval_threshold=request.approval_threshold,
            )
            .model_dump(mode="json")
        )
        missing_connectors = _missing_connector_names(connector_requirements)
        entropy_warning = _entropy_plan_warning(tenant_id)
        response = QuickAgentPlanResponse(
            objective=request.objective,
            name=str(profile.get("name") or ""),
            role=str(profile.get("role") or ""),
            job_description=str(profile.get("job_description") or ""),
            skills=list(profile.get("skills") or []),
            tools=list(profile.get("tools") or []),
            rules=list(profile.get("rules") or []),
            schedule=schedule,
            success_criteria=list(profile.get("success_criteria") or []),
            source_description=str(profile.get("source_description") or ""),
            generation_mode=str(profile.get("generation_mode") or "moonshot"),
            generation_warning=_combine_generation_warnings(profile.get("generation_warning"), entropy_warning),
            risk_level=risk_level,
            first_run_preview=[
                *_build_first_run_preview(
                    objective=request.objective,
                    profile=profile,
                    schedule=schedule,
                    risk_level=risk_level,
                ),
                f"Autoplanner chose {swarm_mode} mode across {len(planner.blocks)} bounded block(s).",
                *(
                    [f"Recalled {memory_context['memory_facts_count']} memory fact(s) to refine the plan."]
                    if memory_context.get("memory_facts_count")
                    else []
                ),
            ],
            connector_requirements=connector_requirements,
            missing_connectors=missing_connectors,
            can_run=swarm_mode == "simulation" or not missing_connectors,
            swarm_mode=swarm_mode,
            swarm_mode_source=planner.swarm_mode_source,
            proof_plane=str(budget_envelope.get("proof_plane") or "production"),
            merge_strategy=str(budget_envelope.get("merge_strategy") or "synthesized_merge"),
            approval_threshold=str(budget_envelope.get("approval_threshold") or "summary"),
            budget_estimate_usd=str(budget_envelope.get("approved_usd") or "0.00"),
            budget_preview=_budget_preview(budget_envelope),
            swarm_defaults=budget_envelope,
            block_plan=[block.model_dump(mode="json") for block in planner.blocks],
            planner_summary=planner.planner_summary,
            autoresearch=_compress_autoresearch_report(autoresearch_report),
            memory_facts_used=memory_context.get("memory_facts_count", 0),
            recalled_insights=_format_memory_insights(memory_context),
        )
        return response
    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception as exc:
        logger.exception("Failed to plan quick agent: tenant=%s error=%s", tenant_id, exc)
        raise HTTPException(status_code=500, detail="Failed to plan quick agent")


@router.post(f"{ACTIVATE_PREFIX}/confirm", response_model=HiredAgentResponse, status_code=201)
@router.post(f"{HIRE_PREFIX}/confirm", response_model=HiredAgentResponse, status_code=201, include_in_schema=False)
async def confirm_hire(
    request: ConfirmActivationRequest,
    http_request: Request,
    response: Response,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Step 2: Confirm activation — creates the AI agent."""
    try:
        _apply_legacy_hire_headers(http_request, response)
        service = _get_service()
        agent = await service.activate(tenant_id, request.model_dump())

        # Provision cryptographic identity for the new agent (best-effort).
        # Failure here should not block the activation itself.
        agent_id = agent.get("agent_id") or agent.get("id")
        if agent_id:
            try:
                identity_gov = _get_identity_governance()
                identity_gov.provision_agent_identity(
                    tenant_id=tenant_id,
                    agent_id=str(agent_id),
                    actor="activate_flow",
                )
            except Exception as id_exc:
                logger.warning(
                    "Identity provisioning failed for agent %s (non-blocking): %s",
                    agent_id,
                    id_exc,
                )

        return HiredAgentResponse(**agent)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception as exc:
        logger.exception("Failed to activate agent: tenant=%s error=%s", tenant_id, exc)
        raise HTTPException(status_code=500, detail="Failed to activate agent")


@router.post(f"{ACTIVATE_PREFIX}/quick-agent/run", response_model=QuickAgentRunResponse, status_code=201)
@router.post(
    f"{HIRE_PREFIX}/quick-agent/run", response_model=QuickAgentRunResponse, status_code=201, include_in_schema=False
)
async def quick_agent_run(
    request: QuickAgentRunRequest,
    http_request: Request,
    response: Response,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Execute the first Quick Agent run or return an explicit blocked reason."""
    service: Any | None = None
    activated_agent_id: str | None = None
    created_task_id: str | None = None
    created_schedule_id: str | None = None
    run_state_service: Any | None = None
    created_run_id: str | None = None
    swarm_scheduler: Any | None = None
    swarm_execution: Any | None = None
    try:
        _apply_legacy_hire_headers(http_request, response)
        schedule = _normalize_schedule(request.schedule)
        connector_requirements = await _resolve_connector_requirements(
            tenant_id=tenant_id,
            tools=request.tools,
        )
        missing_connectors = _missing_connector_names(connector_requirements)
        risk_level = _estimate_risk_level(request.source_description or request.job_description, request.tools)
        requested_swarm_mode = _normalize_swarm_mode(request.swarm_mode, allow_auto=True)
        history = _get_work_ledger().list_blocks(tenant_id, limit=500)
        autoresearch_report = await _get_autoresearch_orchestrator().evaluate(
            tenant_id=tenant_id,
            blocks=history,
            lane="simulation" if requested_swarm_mode == "simulation" else "shadow",
        )
        governed_swarm = _get_governed_swarm_service()
        identity_governance = _get_identity_governance()
        objective = str(request.source_description or request.job_description or request.role).strip()
        planner = _get_block_planner().plan_goal(
            objective,
            risk_level=risk_level,
            requested_swarm_mode=requested_swarm_mode,
            execution_lane="simulation" if requested_swarm_mode == "simulation" else "production",
            autoresearch_report=autoresearch_report.model_dump(mode="json"),
        )
        swarm_mode = planner.recommended_swarm_mode
        budget_envelope = governed_swarm.build_budget_envelope(
            run_id=f"run-preview-{ulid.new().str}",
            mission_id="quick-agent-run",
            mode=swarm_mode,
            base_budget_usd=_base_budget_for_risk(risk_level),
            requested_workers=request.max_workers,
            max_depth=request.max_depth,
            max_concurrency=request.max_concurrency,
            merge_strategy=request.merge_strategy,
            approval_threshold=request.approval_threshold,
        ).model_dump(mode="json")
        proof_plane = str(budget_envelope.get("proof_plane") or "production")
        budget_preview = _budget_preview(budget_envelope)

        # --- Simulation gate + scheduler: build ConstraintEnvelope once ---
        from apps.backend.models.governed_swarm import ConstraintEnvelope as _CE

        _constraint_envelope = _CE(
            budget_usd=float(str(budget_envelope.get("approved_usd") or "0")),
            max_agents=int(budget_envelope.get("max_workers") or 1),
            coordination_protocol=request.coordination_protocol,
        )

        # --- Simulation gate: consult should_simulate before execution ---
        simulation_recommended = False
        if swarm_mode != "simulation":
            simulation_recommended = governed_swarm.should_simulate(_constraint_envelope, objective, tenant_id)
            if simulation_recommended:
                logger.warning(
                    "simulation.recommended tenant_id=%s objective=%.100s budget=%.2f",
                    tenant_id,
                    objective,
                    _constraint_envelope.budget_usd,
                )

        # --- SwarmScheduler: track this execution ---
        swarm_scheduler = _get_swarm_scheduler()
        swarm_execution = swarm_scheduler.schedule(tenant_id, objective, _constraint_envelope)
        if swarm_execution is not None:
            swarm_scheduler.start(tenant_id, swarm_execution.execution_id)

        if missing_connectors and swarm_mode != "simulation":
            blocked_reason = (
                "Connect " + ", ".join(missing_connectors) + " before the first Quick Agent run can execute."
            )
            evidence_id = _record_quick_agent_evidence(
                tenant_id=tenant_id,
                event_type="evidence:item",
                objective=objective,
                data={
                    "status": "blocked",
                    "blocked_reason": blocked_reason,
                    "missing_connectors": missing_connectors,
                    "risk_level": risk_level,
                    "swarm_mode": swarm_mode,
                    "proof_plane": proof_plane,
                },
            )
            # Cancel the scheduler tracking since we're blocked
            if swarm_execution is not None:
                swarm_scheduler.cancel(tenant_id, swarm_execution.execution_id)
            return QuickAgentRunResponse(
                status="blocked",
                blocked_reason=blocked_reason,
                risk_level=risk_level,
                connector_requirements=connector_requirements,
                missing_connectors=missing_connectors,
                evidence_id=evidence_id,
                evidence_url=f"/evidence/?evidence_id={evidence_id}",
                summary="Quick Agent is blocked until the required connectors are verified.",
                swarm_mode=swarm_mode,
                swarm_mode_source=planner.swarm_mode_source,
                proof_plane=proof_plane,
                budget_estimate_usd=str(budget_envelope.get("approved_usd") or "0.00"),
                budget_preview=budget_preview,
                block_plan=[block.model_dump(mode="json") for block in planner.blocks],
                planner_summary=planner.planner_summary,
                simulation_recommended=simulation_recommended,
            )

        service = _get_service()
        is_simulation = swarm_mode == "simulation"
        if is_simulation:
            agent = {
                "agent_id": f"simulation-{ulid.new().str}",
                "name": request.name,
                "role": request.role,
            }
        else:
            agent = await service.activate(
                tenant_id,
                {
                    **request.model_dump(
                        exclude={
                            "connector_requirements",
                            "activate_schedule",
                            "swarm_mode",
                            "max_workers",
                            "max_depth",
                            "max_concurrency",
                            "merge_strategy",
                            "approval_threshold",
                            "simulation_scenario",
                        }
                    ),
                    "schedule": schedule,
                },
            )
            activated_agent_id = str(agent.get("agent_id") or "").strip() or None

        task = None
        if not is_simulation:
            task_title = f"Quick Agent: {objective[:72]}".strip()
            if len(task_title) > 90:
                task_title = task_title[:87].rstrip() + "..."
            task_description = "\n".join(
                line
                for line in [
                    f"Objective: {objective}",
                    f"Agent: {agent['name']} ({agent['role']})",
                    f"Job: {request.job_description}",
                    "Expected proof: explicit output, evidence record, and next-step summary.",
                ]
                if line.strip()
            )
            try:
                from apps.backend.services.execution.workitem_service import get_workitem_service
            except ImportError as exc:
                logger.exception("Quick agent canonical WorkItem import failed: tenant=%s", tenant_id)
                raise HTTPException(status_code=503, detail="canonical_workitem_service_unavailable") from exc

            try:
                _wi_result = await get_workitem_service().create_work_item(
                    tenant_id=tenant_id,
                    payload={
                        "source_kind": "task",
                        "title": task_title,
                        "description": task_description,
                        "assigned_agent": agent["agent_id"],
                        "status": "paused",
                        "priority": "medium" if risk_level == "low" else "high",
                        "tags": ["quick-agent", "phase-ux", f"swarm:{swarm_mode}"],
                    },
                    goal_store=None,
                    task_store=_get_task_store(),
                )
            except HTTPException:
                raise
            except Exception as exc:
                botocore_errors: tuple[type[BaseException], ...] = ()
                try:
                    from botocore.exceptions import BotoCoreError, ClientError

                    botocore_errors = (BotoCoreError, ClientError)
                except Exception:  # pragma: no cover - optional dependency branch
                    botocore_errors = ()
                if botocore_errors and isinstance(exc, botocore_errors):
                    logger.warning("Quick agent canonical WorkItem store unavailable: tenant=%s err=%s", tenant_id, exc)
                    raise HTTPException(status_code=503, detail="canonical_workitem_store_unavailable") from exc
                raise
            task = {"task_id": _wi_result.get("task_id") or _wi_result.get("id", ""), "title": task_title}
            created_task_id = str(task.get("task_id") or "").strip() or None

        schedule_id: str | None = None
        if not is_simulation and request.activate_schedule and schedule and schedule.get("type") == "recurring":
            created_schedule = _get_schedule_store().create_schedule(
                tenant_id=tenant_id,
                agent_id=agent["agent_id"],
                title=f"{agent['name']} schedule",
                schedule_type="recurring",
                description=str(schedule.get("description") or objective),
                cron_expression=str(schedule.get("cron_expression") or ""),
                config={
                    "source": "quick_agent",
                    "objective": objective,
                    "task_id": task["task_id"] if task else "",
                    "swarm_mode": swarm_mode,
                },
            )
            schedule_id = str(created_schedule.get("schedule_id") or "")
            created_schedule_id = schedule_id or None

        run_state_service = _get_run_state_service()
        run_id = ulid.new().str
        created_run_id = run_id
        mission_id = str(task["task_id"] if task else f"simulation-{ulid.new().str}")
        state = run_state_service.ensure_run(
            tenant_id=tenant_id,
            mission_id=mission_id,
            run_id=run_id,
            actor="quick_agent",
            metadata={
                "source": "quick_agent",
                "objective": objective,
                "risk_level": risk_level,
                "swarm_mode": swarm_mode,
                "proof_plane": proof_plane,
                "planner_summary": planner.planner_summary,
                "block_plan": [block.model_dump(mode="json") for block in planner.blocks],
                "principal_agent_id": agent["agent_id"],
            },
        )
        run_state_service.configure_swarm_runtime(
            tenant_id=tenant_id,
            run_id=run_id,
            mode=swarm_mode,
            actor="quick_agent",
            base_budget_usd=_base_budget_for_risk(risk_level),
            estimated_minutes=15,
            requested_workers=request.max_workers,
            approval_threshold=request.approval_threshold,
            max_depth=request.max_depth,
            max_concurrency=request.max_concurrency,
            merge_strategy=request.merge_strategy,
            metadata={"objective": objective},
        )
        run_state_service.register_principal_worker(
            tenant_id=tenant_id,
            run_id=run_id,
            agent_id=agent["agent_id"],
            actor="quick_agent",
            worker_class="synthesizer",
            metadata={"agent_name": agent["name"], "role": agent["role"]},
        )
        root_block_id = str(state.get("root_block_id") or "")
        if root_block_id:
            _seed_block_plan(
                tenant_id=tenant_id,
                root_block_id=root_block_id,
                mission_id=mission_id,
                run_id=run_id,
                agent_id=agent["agent_id"],
                swarm_mode=swarm_mode,
                execution_lane="simulation" if is_simulation else "production",
                blocks=[block.model_dump(mode="json") for block in planner.blocks],
            )

        if is_simulation:
            run_state_service.start_simulation_run(
                tenant_id=tenant_id,
                run_id=run_id,
                scenario=str(request.simulation_scenario or objective),
                requested_by=agent["agent_id"],
                actor="quick_agent",
                allowed_tools=[str(tool.get("provider") or "") for tool in request.tools if isinstance(tool, dict)],
                metadata={"objective": objective},
            )
        else:
            if swarm_mode != "solo":
                from apps.backend.models.governed_swarm import WorkerIdentity

                tool_providers = [
                    str(tool.get("provider") or "").strip().lower()
                    for tool in request.tools
                    if isinstance(tool, dict) and str(tool.get("provider") or "").strip()
                ] or ["workweaver"]
                worker_specs = [
                    ("researcher", "search", tool_providers[0]),
                    ("validator", "review", "quality_gate"),
                    ("tool_runner", "query", tool_providers[0]),
                    ("synthesizer", "draft", "mission_brief"),
                    ("reviewer", "review", "proof_review"),
                ]
                approved_worker_limit = int(budget_envelope.get("max_workers") or len(worker_specs))
                requested_worker_count = int(request.max_workers or approved_worker_limit)
                worker_count = max(1, min(requested_worker_count, approved_worker_limit, len(worker_specs)))
                budget_slice = max(
                    0.1,
                    float(str(budget_envelope.get("approved_usd") or "1.00")) / float(max(worker_count + 1, 2)),
                )
                for index, (worker_class, operation_type, tool_id) in enumerate(worker_specs[:worker_count], start=1):
                    child_agent_id = f"{agent['agent_id']}-{worker_class}-{index}"
                    _state, delegation, _command = run_state_service.delegate_worker(
                        tenant_id=tenant_id,
                        run_id=run_id,
                        parent_agent_id=agent["agent_id"],
                        child_agent_id=child_agent_id,
                        worker_class=worker_class,
                        budget_usd=budget_slice,
                        actor="quick_agent",
                        allowed_tools=[tool_id],
                        allowed_operations=[operation_type],
                        allowed_memory_scopes=["mission:brief", "mission:context"],
                        metadata={"objective": objective, "risk_level": risk_level},
                    )
                    child_identity = WorkerIdentity.model_validate(delegation["identity"])
                    action_payload = {
                        "run_id": run_id,
                        "agent_id": child_agent_id,
                        "tool_id": tool_id,
                        "operation_type": operation_type,
                        "cost_usd": str(round(budget_slice / 2, 2)),
                        "proof_plane": proof_plane,
                        "memory_scope": "mission:brief",
                    }
                    signature = identity_governance.sign_payload(
                        tenant_id=tenant_id,
                        identity=child_identity,
                        payload=action_payload,
                        actor="quick_agent",
                    )
                    run_state_service.record_governed_action(
                        tenant_id=tenant_id,
                        run_id=run_id,
                        agent_id=child_agent_id,
                        tool_id=tool_id,
                        operation_type=operation_type,
                        cost_usd=round(budget_slice / 2, 2),
                        actor="quick_agent",
                        memory_scope="mission:brief",
                        side_effect=False,
                        metadata={"objective": objective, "worker_class": worker_class},
                        signature=signature,
                        outcome=f"{worker_class} contribution recorded",
                    )

        evidence_id = _record_quick_agent_evidence(
            tenant_id=tenant_id,
            event_type="evidence:item",
            objective=objective,
            data={
                "status": "simulated" if is_simulation else "completed",
                "risk_level": risk_level,
                "agent_id": agent["agent_id"],
                "task_id": task["task_id"] if task else None,
                "schedule_id": schedule_id,
                "run_id": run_id,
                "swarm_mode": swarm_mode,
                "proof_plane": proof_plane,
            },
        )
        run_state_service.apply_command(
            tenant_id=tenant_id,
            run_id=run_id,
            command="complete",
            actor="quick_agent",
            payload={
                "reason": "quick_agent_run_finished",
                "actual": (
                    "Simulation recorded with side effects blocked."
                    if is_simulation
                    else "Tracked task, delegated helper work, and proof were recorded."
                ),
                "outcome": "neutral" if is_simulation else "advanced",
                "learnings": planner.planner_summary,
            },
        )
        final_run_state = run_state_service.get_run(tenant_id=tenant_id, run_id=run_id) or {}

        # --- SwarmScheduler: mark execution completed ---
        if swarm_execution is not None:
            _exec_cost = Decimal(str(budget_envelope.get("used_usd") or "0"))
            swarm_scheduler.complete(tenant_id, swarm_execution.execution_id, cost_usd=_exec_cost)

        return QuickAgentRunResponse(
            status="simulated" if is_simulation else "completed",
            risk_level=risk_level,
            agent_id=agent["agent_id"],
            agent_name=agent["name"],
            task_id=task["task_id"] if task else None,
            task_title=task["title"] if task else None,
            schedule_id=schedule_id,
            evidence_id=evidence_id,
            evidence_url=f"/evidence/?evidence_id={evidence_id}",
            connector_requirements=connector_requirements,
            missing_connectors=[] if not is_simulation else missing_connectors,
            summary=(
                "Quick Agent created a simulation-only governed run with side effects blocked."
                if is_simulation
                else "Quick Agent created the first tracked task, bounded helpers, and lineage-backed proof."
            ),
            run_id=run_id,
            swarm_mode=swarm_mode,
            swarm_mode_source=planner.swarm_mode_source,
            proof_plane=proof_plane,
            budget_estimate_usd=str(budget_envelope.get("approved_usd") or "0.00"),
            budget_preview=budget_preview,
            swarm_monitor=dict(final_run_state.get("swarm_monitor") or {}),
            lineage_url=f"/api/v1/evidence/lineage/{run_id}",
            export_url=f"/api/v1/evidence/audit-bundle/{run_id}",
            block_plan=[block.model_dump(mode="json") for block in planner.blocks],
            planner_summary=planner.planner_summary,
            simulation_recommended=simulation_recommended,
        )
    except HTTPException:
        await _compensate_failed_quick_agent_execution(
            service=service,
            tenant_id=tenant_id,
            agent_id=activated_agent_id,
            task_id=created_task_id,
            schedule_id=created_schedule_id,
            swarm_scheduler=swarm_scheduler,
            swarm_execution=swarm_execution,
            run_state_service=run_state_service,
            run_id=created_run_id,
        )
        raise
    except ValueError as e:
        await _compensate_failed_quick_agent_execution(
            service=service,
            tenant_id=tenant_id,
            agent_id=activated_agent_id,
            task_id=created_task_id,
            schedule_id=created_schedule_id,
            swarm_scheduler=swarm_scheduler,
            swarm_execution=swarm_execution,
            run_state_service=run_state_service,
            run_id=created_run_id,
        )
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except Exception as exc:
        await _compensate_failed_quick_agent_execution(
            service=service,
            tenant_id=tenant_id,
            agent_id=activated_agent_id,
            task_id=created_task_id,
            schedule_id=created_schedule_id,
            swarm_scheduler=swarm_scheduler,
            swarm_execution=swarm_execution,
            run_state_service=run_state_service,
            run_id=created_run_id,
        )
        logger.exception("Failed to execute quick agent: tenant=%s error=%s", tenant_id, exc)
        raise HTTPException(status_code=500, detail="Failed to execute quick agent")


@router.post(
    f"{ACTIVATE_PREFIX}/{{agent_id}}/identity/elevate",
    response_model=ElevateIdentityResponse,
    status_code=200,
)
@router.post(
    f"{HIRE_PREFIX}/{{agent_id}}/identity/elevate",
    response_model=ElevateIdentityResponse,
    status_code=200,
    include_in_schema=False,
)
async def elevate_identity(
    agent_id: str,
    request: ElevateIdentityRequest,
    http_request: Request,
    response: Response,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """Elevate an agent from shared to dedicated identity mode."""
    try:
        _apply_legacy_hire_headers(http_request, response)
        service = _get_service()
        result = await service.elevate_identity(
            tenant_id=tenant_id,
            agent_id=agent_id,
            config=request.identity_config,
        )
        return ElevateIdentityResponse(**result)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=safe_error_detail(e))
    except Exception as exc:
        logger.exception(
            "Failed to elevate identity: tenant=%s agent=%s error=%s",
            tenant_id,
            agent_id,
            exc,
        )
        raise HTTPException(status_code=500, detail="Failed to elevate identity")
