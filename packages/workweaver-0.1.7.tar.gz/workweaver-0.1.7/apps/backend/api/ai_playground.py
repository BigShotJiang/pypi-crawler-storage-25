"""AI Playground APIs for prompt testing, A/B experiments, and response analytics."""

from __future__ import annotations

import json
import logging
import os
import random
import re
import threading
import time
from collections import defaultdict
from apps.backend.utils.time import utc_now_iso_z
from datetime import datetime, timedelta, UTC
from statistics import mean
from typing import Any, cast

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field

from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.api.workspace._core import get_tenant_id
from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id as _get_verified_tenant_id
from apps.backend.services.grok_client import GrokClient
from apps.backend.services.billing import MeteringService
from apps.backend.services.usage_tracker import UsageMetricType
from apps.backend.services.inference.service import (
    DEFAULT_GROK_MODEL_SPEC,
    PLAYGROUND_MODEL_GROK_FAST,
    PLAYGROUND_MODEL_GROK_NON_REASONING,
    PLAYGROUND_MODEL_GROK_2,
    PLAYGROUND_MODEL_GPT41_MINI,
    PLAYGROUND_MODEL_CLAUDE37_SONNET,
    PLAYGROUND_MODEL_GEMINI25_FLASH,
)


logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/ai-playground", tags=["AI Playground"])


MAX_STORED_RUNS = int(os.getenv("AI_PLAYGROUND_MAX_STORED_RUNS", "200"))
_RUNS_LOCK = threading.Lock()
_RUN_HISTORY: list[dict[str, Any]] = []


class ModelInfo(BaseModel):
    """Model metadata returned to the playground UI."""

    id: str
    provider: str = "grok"
    name: str
    description: str
    max_tokens: int = 1024
    pricing_input_per_1m_tokens: float
    pricing_output_per_1m_tokens: float
    benchmark_latency_ms: int
    benchmark_quality_score: float
    benchmark_safety_score: float = 97.0
    benchmark_relevance_score: float = 92.0
    context_window_tokens: int = 8192
    tags: list[str] = Field(default_factory=list)


class PromptTestRequest(BaseModel):
    """Payload for a single prompt test run."""

    tenant_id: str | None = Field(default=None, max_length=128)
    model_id: str = Field(..., min_length=2, max_length=256)
    model_provider: str = Field(default="grok", max_length=64)
    system_prompt: str = Field(default="", max_length=24000)
    user_prompt: str = Field(..., min_length=1, max_length=12000)
    input_context: str = Field(default="", max_length=12000)
    run_name: str | None = Field(default=None, max_length=160)
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    top_p: float = Field(default=1.0, ge=0.0, le=1.0)
    max_tokens: int = Field(default=768, ge=32, le=8192)


class AbTestRequest(BaseModel):
    """Payload for A/B style prompt comparisons."""

    tenant_id: str | None = Field(default=None, max_length=128)
    model_id_a: str | None = Field(default=None, max_length=256)
    model_provider_a: str = Field(default="grok", max_length=64)
    system_prompt_a: str = Field(default="", max_length=24000)

    model_id_b: str | None = Field(default=None, max_length=256)
    model_provider_b: str = Field(default="grok", max_length=64)
    system_prompt_b: str = Field(default="", max_length=24000)

    user_prompt: str = Field(..., min_length=1, max_length=12000)
    input_context: str = Field(default="", max_length=12000)
    judge_criterion: str = Field(
        default="Choose the variant with stronger clarity, specificity, and actionability.",
        max_length=500,
    )
    temperature: float = Field(default=0.7, ge=0.0, le=2.0)
    max_tokens: int = Field(default=768, ge=32, le=8192)
    run_name: str | None = Field(default=None, max_length=160)

    model_id: str | None = Field(default=None, max_length=256, description="Fallback model for both variants")
    model_provider: str = Field(default="grok", max_length=64)


class AbVariantResult(BaseModel):
    """Single variant result in an A/B comparison."""

    label: str
    system_prompt: str
    model_id: str
    model_provider: str
    latency_ms: int
    quality_score: float
    safety_score: float
    relevance_score: float
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    response: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class PromptRunResult(BaseModel):
    """Single prompt run result."""

    run_id: str
    kind: str
    tenant_id: str
    created_at: str
    status: str
    model_id: str
    model_provider: str
    latency_ms: int
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    quality_score: float
    safety_score: float
    relevance_score: float
    run_name: str
    response: str
    status_message: str
    metadata: dict[str, Any] = Field(default_factory=dict)


class AbRunResult(BaseModel):
    """A/B test result container."""

    run_id: str
    kind: str
    tenant_id: str
    created_at: str
    status: str
    run_name: str
    judge_criterion: str
    winner: str
    confidence: float
    delta: float
    latency_ms: int
    status_message: str
    variants: list[AbVariantResult]
    winner_score: float
    runner_up_score: float
    metadata: dict[str, Any] = Field(default_factory=dict)


class RunsResponse(BaseModel):
    """Response model for run history endpoint."""

    tenant_id: str
    count: int
    limit: int
    runs: list[dict[str, Any]]


class ModelBreakdownItem(BaseModel):
    model_id: str
    model_provider: str
    runs: int
    avg_quality: float
    avg_latency_ms: float


class AnalyticsResponse(BaseModel):
    """Response model for playground analytics endpoint."""

    tenant_id: str
    window_days: int
    total_runs: int
    prompt_runs: int
    ab_runs: int
    success_rate: float
    avg_latency_ms: float
    avg_quality: float
    model_breakdown: list[ModelBreakdownItem]
    recent_runs: list[dict[str, Any]]


class ModelRecommendationItem(BaseModel):
    """Single model recommendation entry."""

    provider: str
    model_id: str
    name: str
    score: float
    rationale: str
    estimated_cost_per_1m: float
    estimated_latency_ms: float
    estimated_quality_score: float
    estimated_safety_score: float
    observed_runs: int
    normalized_quality: float
    normalized_latency: float
    normalized_cost: float
    normalized_safety: float


class ModelRecommendationResponse(BaseModel):
    """Response model for model recommendation endpoint."""

    tenant_id: str
    objective: str
    recommendations: list[ModelRecommendationItem]
    metadata: dict[str, Any]



def _coalesce_str(value: str | None, fallback: str = "") -> str:
    return (value or "").strip() or fallback


def _estimate_token_count(value: str) -> int:
    if not value:
        return 0
    # Conservative rough estimator; avoids external tokenizer dependency.
    return max(1, len(re.findall(r"\b\w+\b", value)))


def _safe_int(value: Any) -> int:
    try:
        return max(0, int(value))
    except (TypeError, ValueError):
        return 0


def _estimate_usage(
    *,
    system_prompt: str,
    user_prompt: str,
    input_context: str,
    output_text: str,
) -> dict[str, int]:
    prompt_tokens = _estimate_token_count(f"{system_prompt} {user_prompt} {input_context}")
    completion_tokens = _estimate_token_count(output_text)
    total_tokens = max(1, prompt_tokens + completion_tokens)
    return {
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": total_tokens,
    }


def _extract_provider_usage(usage: Any) -> dict[str, int] | None:
    if not isinstance(usage, dict):
        return None
    prompt_tokens = _safe_int(usage.get("prompt_tokens"))
    completion_tokens = _safe_int(usage.get("completion_tokens"))
    total_tokens = _safe_int(usage.get("total_tokens", prompt_tokens + completion_tokens))
    if prompt_tokens <= 0 and completion_tokens <= 0 and total_tokens <= 0:
        return None
    total_tokens = max(total_tokens, prompt_tokens + completion_tokens)
    return {
        "prompt_tokens": prompt_tokens,
        "completion_tokens": completion_tokens,
        "total_tokens": total_tokens,
    }


def _is_risky_phrase(text: str) -> bool:
    risky = {
        "ignore",
        "jailbreak",
        "bypass",
        "override",
        "password",
        "root access",
    }
    haystack = (text or "").lower()
    return any(token in haystack for token in risky)


def _score_output(response_text: str, user_prompt: str, system_prompt: str, input_context: str) -> dict[str, float]:
    clean_output = _coalesce_str(response_text, "")
    prompt_words = set(
        word
        for word in re.findall(r"[a-zA-Z0-9]+", f"{system_prompt} {user_prompt} {input_context}".lower())
        if len(word) > 2
    )
    response_words = set(word for word in re.findall(r"[a-zA-Z0-9]+", clean_output.lower()) if len(word) > 2)

    overlap_ratio = 0.0
    if prompt_words:
        overlap_ratio = len(prompt_words.intersection(response_words)) / len(prompt_words)

    quality = overlap_ratio * 55.0
    length = max(len(clean_output), 1)
    readability = 1.0 if 120 <= length <= 1800 else max(0.1, min(1.0, 1800 / length))
    safety = 0.12 if _is_risky_phrase(clean_output) else 1.0
    relevance_score = min(100.0, quality + (readability * 45.0))
    quality_score = min(100.0, quality + (readability * 35.0) + (safety * 10.0))

    return {
        "quality_score": round(float(quality_score), 2),
        "relevance_score": round(float(relevance_score), 2),
        "safety_score": round(float(safety * 100.0), 2),
    }


def _normalize_identifier(label: str | None) -> str:
    return re.sub(r"[^a-zA-Z0-9._-]", "-", _coalesce_str(label, "workweaver").lower())[:64]


def _default_models() -> list[ModelInfo]:
    return [
        ModelInfo(
            id=PLAYGROUND_MODEL_GROK_FAST,
            provider="grok",
            name="Grok 4.1 Fast",
            description="Balanced speed and quality for everyday prompts.",
            max_tokens=8192,
            pricing_input_per_1m_tokens=6.5,
            pricing_output_per_1m_tokens=13.0,
            benchmark_latency_ms=780,
            benchmark_quality_score=88.5,
            benchmark_safety_score=98.0,
            benchmark_relevance_score=90.0,
            context_window_tokens=131072,
            tags=["balanced", "general"],
        ),
        ModelInfo(
            id=PLAYGROUND_MODEL_GROK_NON_REASONING,
            provider="grok",
            name="Grok 4.1 Fast Non-Reasoning",
            description="Cost-efficient mode with concise responses.",
            max_tokens=2048,
            pricing_input_per_1m_tokens=2.5,
            pricing_output_per_1m_tokens=5.0,
            benchmark_latency_ms=620,
            benchmark_quality_score=83.5,
            benchmark_safety_score=96.5,
            benchmark_relevance_score=86.8,
            context_window_tokens=81920,
            tags=["cost", "automation"],
        ),
        ModelInfo(
            id=PLAYGROUND_MODEL_GROK_2,
            provider="grok",
            name="Grok 2",
            description="Compact experimentation model for quick iterations.",
            max_tokens=1024,
            pricing_input_per_1m_tokens=1.2,
            pricing_output_per_1m_tokens=2.4,
            benchmark_latency_ms=410,
            benchmark_quality_score=75.0,
            benchmark_safety_score=95.0,
            benchmark_relevance_score=78.0,
            context_window_tokens=16384,
            tags=["fast", "prototype"],
        ),
        ModelInfo(
            id=PLAYGROUND_MODEL_GPT41_MINI,
            provider="bedrock",
            name="GPT-4.1 Mini",
            description="Efficient generalist model with strong reasoning at low latency.",
            max_tokens=16384,
            pricing_input_per_1m_tokens=0.3,
            pricing_output_per_1m_tokens=0.6,
            benchmark_latency_ms=520,
            benchmark_quality_score=86.0,
            benchmark_safety_score=97.0,
            benchmark_relevance_score=84.5,
            context_window_tokens=128000,
            tags=["reasoning", "low-cost"],
        ),
        ModelInfo(
            id=PLAYGROUND_MODEL_CLAUDE37_SONNET,
            provider="anthropic",
            name="Claude 3.7 Sonnet",
            description="Strong coding and analysis capabilities with thoughtful long-form output.",
            max_tokens=200000,
            pricing_input_per_1m_tokens=3.0,
            pricing_output_per_1m_tokens=15.0,
            benchmark_latency_ms=690,
            benchmark_quality_score=92.0,
            benchmark_safety_score=99.0,
            benchmark_relevance_score=93.5,
            context_window_tokens=200000,
            tags=["analysis", "long-context"],
        ),
        ModelInfo(
            id=PLAYGROUND_MODEL_GEMINI25_FLASH,
            provider="google",
            name="Gemini 2.5 Flash",
            description="Multimodal-first model for quick content drafts and summaries.",
            max_tokens=8192,
            pricing_input_per_1m_tokens=0.6,
            pricing_output_per_1m_tokens=1.6,
            benchmark_latency_ms=560,
            benchmark_quality_score=84.0,
            benchmark_safety_score=96.0,
            benchmark_relevance_score=82.0,
            context_window_tokens=1000000,
            tags=["multimodal", "fast"],
        ),
    ]


def _safe_float(value: Any, fallback: float = 0.0) -> float:
    try:
        return float(value)
    except (TypeError, ValueError):
        return fallback


def _normalize_score(value: float, min_value: float, max_value: float, lower_is_better: bool = False) -> float:
    if max_value <= min_value:
        return 0.5
    if lower_is_better:
        normalized = (max_value - value) / (max_value - min_value)
    else:
        normalized = (value - min_value) / (max_value - min_value)
    return max(0.0, min(1.0, normalized))


def _build_model_observation_stats(tenant_id: str) -> dict[str, dict[str, float]]:
    runs = _list_runs(tenant_id)
    by_model: dict[str, dict[str, float]] = defaultdict(
        lambda: {
            "runs": 0,
            "avg_quality": 0.0,
            "avg_latency_ms": 0.0,
            "avg_safety_score": 0.0,
            "quality_total": 0.0,
            "latency_total": 0.0,
            "safety_total": 0.0,
        }
    )

    def record_observation(model_provider: str | None, model_id: str | None, metric: dict[str, Any]) -> None:
        provider = _coalesce_str(model_provider, "grok")
        model = _coalesce_str(model_id, DEFAULT_GROK_MODEL_SPEC)
        key = f"{provider}::{model}"
        bucket = by_model[key]
        bucket["runs"] += 1
        bucket["quality_total"] += _safe_float(metric.get("quality_score", 0.0))
        bucket["latency_total"] += _safe_float(metric.get("latency_ms", 0.0))
        bucket["safety_total"] += _safe_float(metric.get("safety_score", 0.0))

    for run in runs:
        if run.get("kind") == "ab":
            for variant in cast(list[dict[str, Any]], run.get("variants", [])):
                record_observation(
                    variant.get("model_provider"),
                    variant.get("model_id"),
                    {
                        "quality_score": variant.get("quality_score"),
                        "latency_ms": variant.get("latency_ms"),
                        "safety_score": variant.get("safety_score"),
                    },
                )
            continue

        record_observation(
            run.get("model_provider"),
            run.get("model_id"),
            {
                "quality_score": run.get("quality_score"),
                "latency_ms": run.get("latency_ms"),
                "safety_score": run.get("safety_score"),
            },
        )

    for item in by_model.values():
        if not item["runs"]:
            continue
        runs_count = item["runs"]
        item["avg_quality"] = item["quality_total"] / runs_count
        item["avg_latency_ms"] = item["latency_total"] / runs_count
        item["avg_safety_score"] = item["safety_total"] / runs_count
        item["quality_total"] = 0.0
        item["latency_total"] = 0.0
        item["safety_total"] = 0.0

    return by_model


def _build_recommendations(
    tenant_id: str,
    *,
    objective: str,
    provider_filter: str | None,
    limit: int,
) -> list[dict[str, Any]]:
    catalog = _default_models()
    if provider_filter:
        catalog = [model for model in catalog if model.provider == provider_filter]
        if not catalog:
            return []

    observed = _build_model_observation_stats(tenant_id)
    scores = {
        "quality": [],
        "cost": [],
        "latency": [],
        "balanced": [],
        "safety": [],
    }

    model_quality_values: list[float] = []
    model_latency_values: list[float] = []
    model_cost_values: list[float] = []
    model_safety_values: list[float] = []
    for model in catalog:
        key = f"{model.provider}::{model.id}"
        observed_entry = observed.get(key, {})
        quality = float(observed_entry.get("avg_quality", 0.0)) or model.benchmark_quality_score
        latency = float(observed_entry.get("avg_latency_ms", 0.0)) or model.benchmark_latency_ms
        safety = float(observed_entry.get("avg_safety_score", 0.0)) or model.benchmark_safety_score
        cost = float(model.pricing_input_per_1m_tokens) + float(model.pricing_output_per_1m_tokens)
        model_quality_values.append(quality)
        model_latency_values.append(latency)
        model_cost_values.append(cost)
        model_safety_values.append(safety)

    if not catalog:
        return []

    quality_range = (min(model_quality_values), max(model_quality_values))
    latency_range = (min(model_latency_values), max(model_latency_values))
    safety_range = (min(model_safety_values), max(model_safety_values))
    cost_range = (min(model_cost_values), max(model_cost_values))

    weights_by_objective = {
        "quality": {"quality": 0.55, "latency": 0.15, "cost": 0.15, "safety": 0.15},
        "cost": {"quality": 0.25, "latency": 0.25, "cost": 0.45, "safety": 0.05},
        "latency": {"quality": 0.2, "latency": 0.6, "cost": 0.1, "safety": 0.1},
        "balanced": {"quality": 0.35, "latency": 0.25, "cost": 0.25, "safety": 0.15},
        "safety": {"quality": 0.25, "latency": 0.2, "cost": 0.1, "safety": 0.45},
    }
    objective_key = objective if objective in weights_by_objective else "balanced"
    weights = weights_by_objective[objective_key]

    for model in catalog:
        key = f"{model.provider}::{model.id}"
        observed_entry = observed.get(key, {})
        observed_runs = int(observed_entry.get("runs", 0))
        quality = float(observed_entry.get("avg_quality", 0.0)) or model.benchmark_quality_score
        latency = float(observed_entry.get("avg_latency_ms", 0.0)) or model.benchmark_latency_ms
        safety = float(observed_entry.get("avg_safety_score", 0.0)) or model.benchmark_safety_score
        cost = float(model.pricing_input_per_1m_tokens) + float(model.pricing_output_per_1m_tokens)

        if observed_runs:
            blend = min(1.0, observed_runs / 12.0)
            quality = (model.benchmark_quality_score * (1.0 - blend)) + (quality * blend)
            safety = (model.benchmark_safety_score * (1.0 - blend)) + (safety * blend)
            latency = (model.benchmark_latency_ms * (1.0 - blend)) + (latency * blend)

        normalized = {
            "quality": _normalize_score(quality, quality_range[0], quality_range[1], lower_is_better=False),
            "latency": _normalize_score(latency, latency_range[0], latency_range[1], lower_is_better=True),
            "cost": _normalize_score(cost, cost_range[0], cost_range[1], lower_is_better=True),
            "safety": _normalize_score(safety, safety_range[0], safety_range[1], lower_is_better=False),
        }
        total_score = (
            normalized["quality"] * weights["quality"]
            + normalized["latency"] * weights["latency"]
            + normalized["cost"] * weights["cost"]
            + normalized["safety"] * weights["safety"]
        ) * 100

        rationale = "Great overall match."
        if objective_key == "quality":
            rationale = "Prioritizes output quality with fallback on reliability."
        elif objective_key == "latency":
            rationale = "Prioritizes speed and low response time."
        elif objective_key == "cost":
            rationale = "Optimized for low-cost usage while preserving quality."
        elif objective_key == "safety":
            rationale = "Prioritizes safer, policy-conservative responses."
        elif objective_key == "balanced":
            rationale = "Balanced blend of quality, speed, safety, and cost."

        if observed_runs:
            rationale = f"{rationale} Based on {observed_runs} recent production runs."

        scores[objective_key].append(
            {
                "provider": model.provider,
                "model_id": model.id,
                "name": model.name,
                "score": round(total_score, 2),
                "rationale": rationale,
                "estimated_cost_per_1m": round(
                    float(model.pricing_input_per_1m_tokens + model.pricing_output_per_1m_tokens), 4
                ),
                "estimated_latency_ms": round(float(latency), 1),
                "estimated_quality_score": round(float(quality), 1),
                "estimated_safety_score": round(float(safety), 1),
                "observed_runs": observed_runs,
                "normalized_quality": round(normalized["quality"], 2),
                "normalized_latency": round(normalized["latency"], 2),
                "normalized_cost": round(normalized["cost"], 2),
                "normalized_safety": round(normalized["safety"], 2),
            }
        )

    ranking = scores.get(objective_key, [])[:]
    ranking.sort(key=lambda item: item["score"], reverse=True)
    return ranking[:limit]


def _synthesize_response(user_prompt: str, system_prompt: str, input_context: str) -> str:
    base = _coalesce_str(system_prompt)
    context = _coalesce_str(input_context)
    if context:
        context_line = f"Context: {context}"
    else:
        context_line = ""

    return (
        f"[{base[:80]}]\n"
        f"User asks: {user_prompt.strip()}\n"
        f"{context_line}\n\n"
        f"Quick response: I recommend addressing this with a concise plan, highlighting assumptions,"
        " risks, and suggested next action steps."
    )


def _persist_run(run: dict[str, Any]) -> None:
    with _RUNS_LOCK:
        _RUN_HISTORY.insert(0, run)
        del _RUN_HISTORY[MAX_STORED_RUNS:]


def _list_runs(tenant_id: str) -> list[dict[str, Any]]:
    with _RUNS_LOCK:
        return [run for run in _RUN_HISTORY if run.get("tenant_id") == tenant_id]


async def _execute_model_call(
    *,
    model_id: str,
    model_provider: str,
    system_prompt: str,
    user_prompt: str,
    input_context: str,
    temperature: float,
    top_p: float,
    max_tokens: int,
) -> tuple[str, int, dict[str, int], dict[str, Any]]:
    provider = (model_provider or "grok").lower()
    start = time.perf_counter()
    model_error: str | None = None

    if provider == "grok":
        try:
            grok_client = GrokClient()
            combined_prompt = _coalesce_str(user_prompt)
            if input_context:
                combined_prompt = f"Context: {input_context}\n\n{combined_prompt}"

            payload = [
                {"role": "system", "content": _coalesce_str(system_prompt, "You are a helpful AI assistant.")},
                {"role": "user", "content": combined_prompt},
            ]

            reply = await grok_client.chat_completion(
                model=model_id,
                messages=payload,
                temperature=temperature,
                max_tokens=max_tokens,
                top_p=top_p,
            )
            content = _coalesce_str(reply.get("content"), "")
            latency_ms = int((time.perf_counter() - start) * 1000)
            if not content:
                raise RuntimeError("Model returned an empty response")

            provider_usage = _extract_provider_usage(reply.get("usage"))
            if provider_usage:
                return (
                    content,
                    latency_ms,
                    provider_usage,
                    {
                        "model_call_status": "success",
                        "token_usage_source": "provider",
                        "token_usage_estimated": False,
                        "token_usage_reason": "provider_usage",
                    },
                )

            estimated_usage = _estimate_usage(
                system_prompt=system_prompt,
                user_prompt=user_prompt,
                input_context=input_context,
                output_text=content,
            )
            return (
                content,
                latency_ms,
                estimated_usage,
                {
                    "model_call_status": "success",
                    "token_usage_source": "estimated",
                    "token_usage_estimated": True,
                    "token_usage_reason": "missing_provider_usage",
                },
            )
        except Exception as error:
            # Fall back to deterministic output when API is unavailable.
            logger.warning("Grok model call failed, using fallback response: %s", error)
            model_error = str(error)

    mock = _synthesize_response(user_prompt, system_prompt, input_context)
    latency_ms = max(20, int((time.perf_counter() - start) * 1000))
    usage = _estimate_usage(
        system_prompt=system_prompt,
        user_prompt=user_prompt,
        input_context=input_context,
        output_text=mock,
    )
    metadata: dict[str, Any] = {
        "model_call_status": "fallback" if model_error else "simulated",
        "token_usage_source": "estimated",
        "token_usage_estimated": True,
        "token_usage_reason": "model_call_failed" if model_error else "provider_not_integrated",
    }
    if model_error:
        metadata["model_call_error"] = model_error
    return mock, latency_ms, usage, metadata


async def _meter_llm_usage(
    *,
    tenant_id: str,
    model_id: str,
    model_provider: str,
    run_id: str,
    prompt_tokens: int,
    completion_tokens: int,
    usage_metadata: dict[str, Any],
    variant_label: str | None = None,
) -> dict[str, bool]:
    shared_metadata: dict[str, Any] = {
        "source": "ai_playground",
        "run_id": run_id,
        "model_id": model_id,
        "model_provider": model_provider,
        "token_usage_source": usage_metadata.get("token_usage_source", "estimated"),
        "token_usage_reason": usage_metadata.get("token_usage_reason", "unknown"),
        "model_call_status": usage_metadata.get("model_call_status", "unknown"),
    }
    if variant_label:
        shared_metadata["variant"] = variant_label

    metering = MeteringService()
    input_metered = await metering.meter(
        tenant_id=tenant_id,
        metric=UsageMetricType.LLM_INFERENCE_TOKENS_IN,
        quantity=float(max(0, prompt_tokens)),
        unit="tokens",
        metadata={**shared_metadata, "meter": "llm_inference_tokens_in"},
        fail_open=True,
    )
    output_metered = await metering.meter(
        tenant_id=tenant_id,
        metric=UsageMetricType.LLM_INFERENCE_TOKENS_OUT,
        quantity=float(max(0, completion_tokens)),
        unit="tokens",
        metadata={**shared_metadata, "meter": "llm_inference_tokens_out"},
        fail_open=True,
    )
    return {
        "input_metered": input_metered,
        "output_metered": output_metered,
    }


def _get_run_scoreboard() -> list[ModelBreakdownItem]:
    return [
        ModelBreakdownItem(
            model_id=DEFAULT_GROK_MODEL_SPEC,
            model_provider="grok",
            runs=0,
            avg_quality=0.0,
            avg_latency_ms=0.0,
        )
    ]


def _build_run_record(
    *,
    tenant_id: str,
    run_id: str,
    status: str,
    kind: str,
    model_id: str,
    model_provider: str,
    payload: dict[str, Any],
    response: str,
    latency_ms: int,
    prompt_tokens: int,
    completion_tokens: int,
    total_tokens: int,
    run_name: str,
    metadata: dict[str, Any] | None = None,
) -> dict[str, Any]:
    score = _score_output(
        response,
        user_prompt=payload.get("user_prompt", ""),
        system_prompt=payload.get("system_prompt", ""),
        input_context=payload.get("input_context", ""),
    )

    return {
        "run_id": run_id,
        "kind": kind,
        "tenant_id": tenant_id,
        "created_at": utc_now_iso_z(),
        "status": status,
        "model_id": model_id,
        "model_provider": model_provider,
        "run_name": run_name,
        "latency_ms": latency_ms,
        "prompt_tokens": int(prompt_tokens),
        "completion_tokens": int(completion_tokens),
        "total_tokens": int(total_tokens),
        "quality_score": score["quality_score"],
        "safety_score": score["safety_score"],
        "relevance_score": score["relevance_score"],
        "response": response,
        "status_message": "Completed",
        "metadata": metadata or {},
    }


@router.get("/models")
async def list_models(
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=20, max_limit=100)),
) -> dict[str, Any]:
    """List available model endpoints and defaults for playground testing."""
    models = [item.model_dump() for item in _default_models()]
    paged_models, _total = paginate_items(models, pagination)
    return {
        "models": paged_models,
        "default_model_id": models[0]["id"],
    }


@router.get("/models/recommendations")
async def recommend_models(
    request: Request,
    objective: str = Query(default="balanced"),
    provider: str | None = Query(default=None),
    limit: int = Query(default=3, ge=1, le=20),
) -> ModelRecommendationResponse:
    """Return ranked model recommendations for a given usage objective."""
    normalized_objective = (
        objective if objective in {"quality", "cost", "latency", "balanced", "safety"} else "balanced"
    )
    tenant_id = get_tenant_id(request)
    recommendations = _build_recommendations(
        tenant_id=tenant_id,
        objective=normalized_objective,
        provider_filter=provider.strip().lower() if provider else None,
        limit=limit,
    )
    return ModelRecommendationResponse(
        tenant_id=tenant_id,
        objective=normalized_objective,
        recommendations=[ModelRecommendationItem(**payload) for payload in recommendations],
        metadata={
            "provider_filter": provider,
            "count": len(recommendations),
            "requested_limit": limit,
        },
    )


@router.post("/prompt-tests")
async def run_prompt_test(
    request: Request,
    body: PromptTestRequest,
    verified_tenant_id: str = Depends(_get_verified_tenant_id),
) -> PromptRunResult:
    """Run a single prompt test across a selected model."""
    # Issue #1937: use verified tenant auth; ignore body.tenant_id
    tenant_id = verified_tenant_id
    model_id = _coalesce_str(body.model_id, DEFAULT_GROK_MODEL_SPEC)
    model_provider = _coalesce_str(body.model_provider, "grok")

    try:
        response_text, latency_ms, usage, usage_metadata = await _execute_model_call(
            model_id=model_id,
            model_provider=model_provider,
            system_prompt=body.system_prompt,
            user_prompt=body.user_prompt,
            input_context=body.input_context,
            temperature=body.temperature,
            top_p=body.top_p,
            max_tokens=body.max_tokens,
        )
        run_id = f"pr_{int(time.time() * 1000)}_{random.randint(0, 9999):04d}"
        run_name = _coalesce_str(body.run_name, f"Prompt test · {model_id}")
        metering_result = await _meter_llm_usage(
            tenant_id=tenant_id,
            model_id=model_id,
            model_provider=model_provider,
            run_id=run_id,
            prompt_tokens=usage.get("prompt_tokens", 0),
            completion_tokens=usage.get("completion_tokens", 0),
            usage_metadata=usage_metadata,
        )
        run_metadata = {
            **usage_metadata,
            "metering": metering_result,
        }
        run = _build_run_record(
            tenant_id=tenant_id,
            run_id=run_id,
            status="ok",
            kind="prompt",
            model_id=model_id,
            model_provider=model_provider,
            payload={
                "system_prompt": body.system_prompt,
                "user_prompt": body.user_prompt,
                "input_context": body.input_context,
            },
            response=response_text,
            latency_ms=latency_ms,
            prompt_tokens=usage.get("prompt_tokens", 0),
            completion_tokens=usage.get("completion_tokens", 0),
            total_tokens=usage.get("total_tokens", 0),
            run_name=run_name,
            metadata=run_metadata,
        )
        _persist_run(run)
        return PromptRunResult(
            run_id=run["run_id"],
            kind=run["kind"],
            tenant_id=run["tenant_id"],
            created_at=run["created_at"],
            status=run["status"],
            model_id=run["model_id"],
            model_provider=run["model_provider"],
            latency_ms=run["latency_ms"],
            prompt_tokens=run["prompt_tokens"],
            completion_tokens=run["completion_tokens"],
            total_tokens=run["total_tokens"],
            quality_score=run["quality_score"],
            safety_score=run["safety_score"],
            relevance_score=run["relevance_score"],
            run_name=run["run_name"],
            response=run["response"],
            status_message=run["status_message"],
            metadata=run.get("metadata", {}),
        )
    except Exception as error:
        error_message = f"Failed to execute prompt test: {error}"
        logger.exception("Prompt test failed")
        raise HTTPException(status_code=500, detail=error_message)


@router.post("/ab-tests")
async def run_ab_test(
    request: Request,
    body: AbTestRequest,
    verified_tenant_id: str = Depends(_get_verified_tenant_id),
) -> AbRunResult:
    """Run a paired A/B prompt test and compare outputs."""
    # Issue #1937: use verified tenant auth; ignore body.tenant_id
    tenant_id = verified_tenant_id
    fallback_model = _coalesce_str(body.model_id, DEFAULT_GROK_MODEL_SPEC)
    fallback_provider = _coalesce_str(body.model_provider, "grok")

    model_a = _coalesce_str(body.model_id_a, fallback_model)
    model_b = _coalesce_str(body.model_id_b, fallback_model)
    provider_a = _coalesce_str(body.model_provider_a, fallback_provider)
    provider_b = _coalesce_str(body.model_provider_b, fallback_provider)

    try:
        int(time.perf_counter() * 1000)

        resp_a, latency_a, usage_a, metadata_a = await _execute_model_call(
            model_id=model_a,
            model_provider=provider_a,
            system_prompt=body.system_prompt_a,
            user_prompt=body.user_prompt,
            input_context=body.input_context,
            temperature=body.temperature,
            top_p=1.0,
            max_tokens=body.max_tokens,
        )

        resp_b, latency_b, usage_b, metadata_b = await _execute_model_call(
            model_id=model_b,
            model_provider=provider_b,
            system_prompt=body.system_prompt_b,
            user_prompt=body.user_prompt,
            input_context=body.input_context,
            temperature=body.temperature,
            top_p=1.0,
            max_tokens=body.max_tokens,
        )

        score_a = _score_output(
            resp_a,
            user_prompt=body.user_prompt,
            system_prompt=body.system_prompt_a,
            input_context=body.input_context,
        )
        score_b = _score_output(
            resp_b,
            user_prompt=body.user_prompt,
            system_prompt=body.system_prompt_b,
            input_context=body.input_context,
        )

        a_quality = score_a["quality_score"]
        b_quality = score_b["quality_score"]
        if abs(a_quality - b_quality) <= 0.25:
            winner = "tie"
            winner_score = max(a_quality, b_quality)
            runner_up_score = min(a_quality, b_quality)
        elif a_quality > b_quality:
            winner = "A"
            winner_score = a_quality
            runner_up_score = b_quality
        else:
            winner = "B"
            winner_score = b_quality
            runner_up_score = a_quality

        delta = round(abs(a_quality - b_quality), 2)
        confidence = max(0.5, min(100.0, 50.0 + delta))

        total_latency = latency_a + latency_b
        run_id = f"ab_{int(time.time() * 1000)}_{random.randint(0, 9999):04d}"
        run_name = _coalesce_str(body.run_name, f"A/B run · {model_a} vs {model_b}")
        metering_a = await _meter_llm_usage(
            tenant_id=tenant_id,
            model_id=model_a,
            model_provider=provider_a,
            run_id=run_id,
            prompt_tokens=usage_a.get("prompt_tokens", 0),
            completion_tokens=usage_a.get("completion_tokens", 0),
            usage_metadata=metadata_a,
            variant_label="A",
        )
        metering_b = await _meter_llm_usage(
            tenant_id=tenant_id,
            model_id=model_b,
            model_provider=provider_b,
            run_id=run_id,
            prompt_tokens=usage_b.get("prompt_tokens", 0),
            completion_tokens=usage_b.get("completion_tokens", 0),
            usage_metadata=metadata_b,
            variant_label="B",
        )
        variant_a_metadata = {**metadata_a, "metering": metering_a}
        variant_b_metadata = {**metadata_b, "metering": metering_b}
        variants = [
            AbVariantResult(
                label="A",
                system_prompt=_coalesce_str(body.system_prompt_a, "(default)"),
                model_id=model_a,
                model_provider=provider_a,
                latency_ms=latency_a,
                quality_score=a_quality,
                safety_score=score_a["safety_score"],
                relevance_score=score_a["relevance_score"],
                prompt_tokens=usage_a.get("prompt_tokens", 0),
                completion_tokens=usage_a.get("completion_tokens", 0),
                total_tokens=usage_a.get("total_tokens", 0),
                response=resp_a,
                metadata=variant_a_metadata,
            ),
            AbVariantResult(
                label="B",
                system_prompt=_coalesce_str(body.system_prompt_b, "(default)"),
                model_id=model_b,
                model_provider=provider_b,
                latency_ms=latency_b,
                quality_score=b_quality,
                safety_score=score_b["safety_score"],
                relevance_score=score_b["relevance_score"],
                prompt_tokens=usage_b.get("prompt_tokens", 0),
                completion_tokens=usage_b.get("completion_tokens", 0),
                total_tokens=usage_b.get("total_tokens", 0),
                response=resp_b,
                metadata=variant_b_metadata,
            ),
        ]

        run = {
            "run_id": run_id,
            "kind": "ab",
            "tenant_id": tenant_id,
            "created_at": utc_now_iso_z(),
            "status": "ok",
            "status_message": "Completed",
            "run_name": run_name,
            "judge_criterion": body.judge_criterion,
            "winner": winner,
            "confidence": confidence,
            "delta": delta,
            "latency_ms": total_latency,
            "quality_score": winner_score,
            "runner_up_score": runner_up_score,
            "relevance_score": max(score_a["relevance_score"], score_b["relevance_score"]),
            "safety_score": max(score_a["safety_score"], score_b["safety_score"]),
            "winner_score": winner_score,
            "runner_up_score": runner_up_score,
            "variants": [json.loads(variant.model_dump_json()) for variant in variants],
            "variant_labels": ["A", "B"],
            "duration_ms": total_latency,
            "provider_a": provider_a,
            "provider_b": provider_b,
            "model_a": model_a,
            "model_b": model_b,
            "metadata": {
                "variants": {
                    "A": variant_a_metadata,
                    "B": variant_b_metadata,
                }
            },
        }
        _persist_run(run)

        return AbRunResult(
            run_id=run["run_id"],
            kind=run["kind"],
            tenant_id=run["tenant_id"],
            created_at=run["created_at"],
            status=run["status"],
            run_name=run_name,
            judge_criterion=body.judge_criterion,
            winner=winner,
            confidence=confidence,
            delta=delta,
            latency_ms=total_latency,
            status_message=run["status_message"],
            winner_score=winner_score,
            runner_up_score=runner_up_score,
            variants=variants,
            metadata=run.get("metadata", {}),
        )
    except Exception:
        logger.exception("A/B test failed")
        raise HTTPException(status_code=500, detail="Failed to run A/B test")


@router.get("/runs")
async def get_runs(
    request: Request,
    limit: int = Query(default=50, ge=1, le=200),
) -> RunsResponse:
    """Return recent test runs for the tenant."""
    tenant_id = get_tenant_id(request)
    runs = _list_runs(tenant_id)
    limit_runs = runs[:limit]
    return RunsResponse(
        tenant_id=tenant_id,
        count=len(runs),
        limit=limit,
        runs=limit_runs,
    )


@router.get("/analytics")
async def get_analytics(
    request: Request,
    days: int = Query(default=14, ge=1, le=365),
) -> AnalyticsResponse:
    """Return summarized analytics for AI playground experiments."""
    tenant_id = get_tenant_id(request)
    runs = _list_runs(tenant_id)

    cutoff = datetime.now(UTC) - timedelta(days=days)
    window_runs = []
    for run in runs:
        try:
            created_raw = run.get("created_at", "")
            created = datetime.fromisoformat(created_raw.replace("Z", "+00:00"))
            if created >= cutoff:
                window_runs.append(run)
        except (ValueError, TypeError):
            window_runs.append(run)

    prompt_runs = [run for run in window_runs if run.get("kind") == "prompt"]
    ab_runs = [run for run in window_runs if run.get("kind") == "ab"]

    success_count = sum(1 for run in window_runs if run.get("status") == "ok")
    total = max(len(window_runs), 1)

    avg_latency = mean([float(run.get("latency_ms", 0) or 0) for run in window_runs]) if window_runs else 0.0
    avg_quality = mean([float(run.get("quality_score", 0) or 0) for run in window_runs]) if window_runs else 0.0

    grouped: dict[str, list[dict[str, Any]]] = {}
    for run in window_runs:
        key = f"{run.get('model_provider', 'unknown')}::{run.get('model_id', 'unknown')}"
        grouped.setdefault(key, []).append(run)

    model_breakdown: list[ModelBreakdownItem] = []
    for key, bucket in grouped.items():
        provider, model_id = key.split("::", 1)
        model_breakdown.append(
            ModelBreakdownItem(
                model_id=model_id,
                model_provider=provider,
                runs=len(bucket),
                avg_latency_ms=round(mean(float(item.get("latency_ms", 0) or 0) for item in bucket)),
                avg_quality=round(mean(float(item.get("quality_score", 0) or 0) for item in bucket)),
            )
        )

    model_breakdown.sort(key=lambda entry: entry.runs, reverse=True)

    return AnalyticsResponse(
        tenant_id=tenant_id,
        window_days=days,
        total_runs=len(window_runs),
        prompt_runs=len(prompt_runs),
        ab_runs=len(ab_runs),
        success_rate=round((success_count / total) * 100.0, 2),
        avg_latency_ms=round(avg_latency, 1),
        avg_quality=round(avg_quality, 1),
        model_breakdown=model_breakdown,
        recent_runs=window_runs[: min(6, len(window_runs))],
    )
