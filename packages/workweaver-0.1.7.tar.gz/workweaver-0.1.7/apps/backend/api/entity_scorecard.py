"""Learning Scorecard API.

GET /api/v1/entities/{entity_id}/scorecard

Returns per-entity week-over-week metrics computed from the evidence ledger.
Auth: same as all tenant-scoped routes (get_verified_tenant_id).
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities", tags=["entity-scorecard"])


# ---------------------------------------------------------------------------
# Lazy accessor — keeps import-time boto3 calls out of test collection
# ---------------------------------------------------------------------------


def _get_scorecard_service():
    from apps.backend.services.compounding_scorecard import get_scorecard_service

    return get_scorecard_service()


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class PeriodMetrics(BaseModel):
    """Aggregated evidence metrics for a single 7-day window."""

    tasks_completed: int = Field(..., description="Events with event_type ending in ':complete'")
    total_evidence_entries: int = Field(..., description="Total evidence entries in the period")
    avg_duration_ms: int = Field(..., description="Mean duration across completed tasks (0 when none)")
    days_active: int = Field(..., description="Distinct calendar days with at least one entry")


class WeekOverWeekDeltas(BaseModel):
    """Percentage changes between this week and last week."""

    tasks_completed_pct: float = Field(..., description="Week-over-week change in tasks_completed (%)")
    evidence_entries_pct: float = Field(..., description="Week-over-week change in total evidence entries (%)")


class ScorecardResponse(BaseModel):
    """Full scorecard response for a single entity."""

    entity_id: str
    generated_at: str = Field(..., description="ISO-8601 UTC timestamp")
    this_week: PeriodMetrics
    last_week: PeriodMetrics
    deltas: WeekOverWeekDeltas
    has_sufficient_data: bool = Field(
        ...,
        description="True when tasks_completed >= 5 in this_week (reliable trend signal)",
    )
    days_of_data: int = Field(..., description="Days of data available (capped at 7)")


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------


@router.get("/{entity_id}/scorecard", response_model=ScorecardResponse)
async def get_entity_scorecard(
    entity_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ScorecardResponse:
    """Return the learning scorecard for a single AI worker entity.

    The scorecard aggregates evidence entries from the last 14 days into two
    7-day windows (this_week / last_week) and computes:

    - tasks_completed — evidence entries whose event_type ends in ':complete'
    - total_evidence_entries — raw entry count
    - avg_duration_ms — mean duration_ms across completed tasks
    - days_active — distinct days with at least one entry

    Week-over-week deltas are expressed as percentages. `has_sufficient_data`
    is True when the entity has completed >= 5 tasks this week, signalling
    that the trend is statistically meaningful.
    """
    try:
        svc = _get_scorecard_service()
        result = await svc.get_scorecard(tenant_id=tenant_id, entity_id=entity_id)
        return ScorecardResponse(**result)
    except Exception as exc:
        logger.error(
            "Scorecard computation failed for entity %s: %s",
            entity_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to compute scorecard",
        ) from exc
