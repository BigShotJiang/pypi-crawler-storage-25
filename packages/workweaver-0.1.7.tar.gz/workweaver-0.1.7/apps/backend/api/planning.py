"""Collaborative Planning API — objective → decomposition → approval → TimeBlocks.

Endpoints:
  POST /api/v1/planning/propose   — Propose a plan from an objective
  POST /api/v1/planning/approve   — Approve a proposed plan, materialize TimeBlocks
"""

from __future__ import annotations

import asyncio
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, get_verified_user_id
from apps.backend.services.planning.collaborative import (
    PlanProposal,
    get_collaborative_planner,
)

router = APIRouter(prefix="/api/v1/planning", tags=["planning"])


# ── Request/Response Models ──────────────────────────────────────────────


class ProposeRequest(BaseModel):
    objective: str = Field(..., min_length=10, max_length=2000)


class PlanCandidateResponse(BaseModel):
    title: str
    description: str
    success_criteria: str
    target_scope: str
    candidate_owner_node_id: str | None = None
    candidate_owner_name: str | None = None
    owner_rationale: str = ""
    priority: str = "medium"
    estimated_duration_minutes: int = 60
    risks: list[str] = Field(default_factory=list)
    constraints: list[str] = Field(default_factory=list)
    execution_lane: str = "production"


class PlanProposalResponse(BaseModel):
    plan_id: str
    tenant_id: str
    objective: str
    inferred_scope: str
    decomposition_level: str
    candidates: list[PlanCandidateResponse] = Field(default_factory=list)
    success_criteria: str = ""
    constraints: list[str] = Field(default_factory=list)
    risks: list[str] = Field(default_factory=list)
    status: str = "proposed"
    created_at: str = ""


class ApproveRequest(BaseModel):
    plan_id: str = Field(..., min_length=1)
    objective: str = Field(..., min_length=10)
    overrides: dict[str, Any] = Field(default_factory=dict)


class TimeBlockSpec(BaseModel):
    objective: str
    plan: str
    phase: str
    execution_lane: str
    duration_budget_minutes: int
    agent_id: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


class ApproveResponse(BaseModel):
    plan_id: str
    status: str = "materialized"
    timeblocks: list[TimeBlockSpec] = Field(default_factory=list)
    total_blocks: int = 0


# ── Helpers ──────────────────────────────────────────────────────────────


def _proposal_to_response(p: PlanProposal) -> PlanProposalResponse:
    return PlanProposalResponse(
        plan_id=p.plan_id,
        tenant_id=p.tenant_id,
        objective=p.objective,
        inferred_scope=p.inferred_scope,
        decomposition_level=p.decomposition_level,
        candidates=[
            PlanCandidateResponse(
                title=c.title,
                description=c.description,
                success_criteria=c.success_criteria,
                target_scope=c.target_scope,
                candidate_owner_node_id=c.candidate_owner_node_id,
                candidate_owner_name=c.candidate_owner_name,
                owner_rationale=c.owner_rationale,
                priority=c.priority,
                estimated_duration_minutes=c.estimated_duration_minutes,
                risks=c.risks,
                constraints=c.constraints,
                execution_lane=c.execution_lane,
            )
            for c in p.candidates
        ],
        success_criteria=p.success_criteria,
        constraints=p.constraints,
        risks=p.risks,
        status=p.status,
        created_at=p.created_at,
    )


# ── In-memory plan cache (single process, short-lived) ──────────────────

_plan_cache: dict[str, PlanProposal] = {}


# ── Endpoints ────────────────────────────────────────────────────────────


@router.post("/propose", response_model=PlanProposalResponse)
async def propose_plan(
    request: ProposeRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PlanProposalResponse:
    """Propose a plan from an objective. System infers scope and decomposes."""
    planner = get_collaborative_planner()
    proposal = await asyncio.to_thread(planner.propose_plan, tenant_id, request.objective)
    _plan_cache[proposal.plan_id] = proposal
    return _proposal_to_response(proposal)


@router.post("/approve", response_model=ApproveResponse)
async def approve_plan(
    request: ApproveRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
) -> ApproveResponse:
    """Approve a proposed plan and materialize into TimeBlock specs."""
    proposal = _plan_cache.get(request.plan_id)
    if proposal is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Plan not found. Plans expire after session ends.",
        )
    if proposal.tenant_id != tenant_id:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Tenant mismatch")

    planner = get_collaborative_planner()
    blocks = await asyncio.to_thread(
        planner.approve_plan,
        proposal,
        approved_by=actor_id,
        overrides=request.overrides,
    )
    # Clean up cache
    _plan_cache.pop(request.plan_id, None)

    return ApproveResponse(
        plan_id=request.plan_id,
        status="materialized",
        timeblocks=[TimeBlockSpec(**b) for b in blocks],
        total_blocks=len(blocks),
    )
