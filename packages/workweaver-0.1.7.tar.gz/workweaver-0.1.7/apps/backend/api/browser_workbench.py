"""Browser Workbench REST surface (#3052 child, #3271 sandbox endpoints)."""

from __future__ import annotations


from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.browser_policy import (
    BrowserSandboxDecision,
    BrowserSandboxPolicy,
    BrowserTaskMode,
)
from apps.backend.services.browser_workbench import (
    BrowserWorkbenchContext,
    BrowserWorkbenchRequest,
    BrowserWorkbenchResult,
    get_browser_workbench_service,
)


router = APIRouter(prefix="/api/v1/browser", tags=["browser-workbench"])


# ---------------------------------------------------------------------------
# Sandbox evaluation request/response models (#3271)
# ---------------------------------------------------------------------------


class SandboxEvaluateRequest(BaseModel):
    """Request body for sandbox policy evaluation."""

    url: str = Field(..., min_length=1, description="URL to evaluate against the sandbox policy.")
    task_mode: BrowserTaskMode = Field(
        default=BrowserTaskMode.DETERMINISTIC,
        description="Browser task mode: deterministic or agentic.",
    )
    side_effecting: bool = Field(
        default=False,
        description="Whether the action has side effects (forms, downloads, uploads).",
    )


class SandboxEvaluateResponse(BaseModel):
    """Response from sandbox policy evaluation."""

    verdict: str = Field(description="Policy verdict: allow or deny.")
    url: str = Field(description="The URL that was evaluated.")
    reason: str = Field(default="", description="Human-readable reason for the verdict.")
    matched_allow_entry: str | None = Field(
        default=None,
        description="The allowlist entry that matched, if any.",
    )
    decision_trace_id: str = Field(
        default="",
        description="Decision Trace identifier for audit.",
    )


class SandboxPolicyResponse(BaseModel):
    """Current sandbox policy configuration for the tenant."""

    allowlist: list[str] = Field(default_factory=list, description="Allowed URL origins.")
    read_only_public_web: bool = Field(
        default=False,
        description="Whether read-only public-web mode is enabled.",
    )
    artifact_temp_dir_configured: bool = Field(
        default=False,
        description="Whether artifact temp dir is configured for downloads.",
    )
    workspace_id: str = Field(default="", description="Workspace ID this policy applies to.")


# ---------------------------------------------------------------------------
# Task execution endpoint (existing, #3052)
# ---------------------------------------------------------------------------


@router.post("/tasks", response_model=BrowserWorkbenchResult)
async def run_browser_task(
    request: BrowserWorkbenchRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> BrowserWorkbenchResult:
    service = get_browser_workbench_service()
    return await service.run(
        request,
        context=BrowserWorkbenchContext(
            tenant_id=tenant_id,
            workspace_id=tenant_id,
        ),
    )


# ---------------------------------------------------------------------------
# Sandbox evaluation endpoints (#3271)
# ---------------------------------------------------------------------------


@router.post("/sandbox/evaluate", response_model=SandboxEvaluateResponse)
async def evaluate_sandbox_url(
    body: SandboxEvaluateRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SandboxEvaluateResponse:
    """Evaluate a URL against the tenant's browser sandbox policy.

    Returns an allow/deny verdict with reason, without executing any
    browser action. Useful for pre-flight checks in UI, CLI, and MCP.
    """
    import uuid


    policy = _resolve_tenant_policy(tenant_id=tenant_id)
    decision = policy.evaluate(
        body.url,
        task_mode=body.task_mode,
        side_effecting=body.side_effecting,
    )

    trace_id = f"trace_sandbox_eval_{uuid.uuid4().hex[:12]}"

    # Emit Decision Trace for the evaluation (best-effort).
    _emit_sandbox_trace(
        tenant_id=tenant_id,
        url=body.url,
        decision=decision,
        side_effecting=body.side_effecting,
        trace_id=trace_id,
    )

    return SandboxEvaluateResponse(
        verdict=decision.verdict.value,
        url=decision.url,
        reason=decision.reason,
        matched_allow_entry=decision.matched_allow_entry,
        decision_trace_id=trace_id,
    )


@router.get("/sandbox/policy", response_model=SandboxPolicyResponse)
async def get_sandbox_policy(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SandboxPolicyResponse:
    """Get the current browser sandbox policy configuration for the tenant."""
    policy = _resolve_tenant_policy(tenant_id=tenant_id)
    return SandboxPolicyResponse(
        allowlist=list(policy.allowlist),
        read_only_public_web=policy.read_only_public_web,
        artifact_temp_dir_configured=bool(policy.artifact_temp_dir),
        workspace_id=policy.workspace_id,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _resolve_tenant_policy(*, tenant_id: str) -> BrowserSandboxPolicy:
    """Resolve the BrowserSandboxPolicy for a tenant.

    In the current implementation the policy is constructed from the
    tenant defaults. Future work will persist per-tenant allowlists
    in DynamoDB and load them here.
    """
    return BrowserSandboxPolicy(workspace_id=tenant_id)


def _emit_sandbox_trace(
    *,
    tenant_id: str,
    url: str,
    decision: BrowserSandboxDecision,
    side_effecting: bool,
    trace_id: str,
) -> None:
    """Best-effort Decision Trace emission for sandbox evaluations."""
    try:
        from apps.backend.services.context.decision_event_capture import capture_decision

        capture_decision(
            tenant_id=tenant_id,
            skill_id="browser.sandbox",
            decision_summary=f"browser.sandbox.evaluated: {decision.verdict.value} {url}",
            decision_type="browser.sandbox.evaluated",
            outcome=decision.verdict.value,
            capture_surface="rest",
            service_family="browser",
            context_data={
                "url": url,
                "reason": decision.reason,
                "matched_allow_entry": decision.matched_allow_entry,
                "side_effecting": side_effecting,
                "trace_id": trace_id,
            },
        )
    except Exception:
        pass  # Best-effort: never block the evaluation for a trace failure.
