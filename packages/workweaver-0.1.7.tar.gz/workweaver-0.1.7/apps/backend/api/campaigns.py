"""Campaign API endpoints -- CRUD, execution control, and progress tracking
for bulk calling campaigns."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.bulk_campaign_dialer import (
    BulkCampaignDialer,
    get_bulk_campaign_dialer,
)
from apps.backend.services.voice_guardrails import BUSINESS_VOICE_MAX_CONCURRENT_CALLS

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/campaigns", tags=["campaigns"])


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class ContactInput(BaseModel):
    id: str = ""
    phone: str = ""
    phone_number: str = ""
    name: str = ""
    company: str = ""
    context: str = ""


class CreateCampaignRequest(BaseModel):
    name: str = Field(..., max_length=200)
    objective: str = Field(..., max_length=2000)
    contacts: list[dict[str, Any]] = Field(..., min_length=1)
    max_concurrent: int = Field(
        default=20,
        ge=1,
        le=BUSINESS_VOICE_MAX_CONCURRENT_CALLS,
    )


class CampaignResponse(BaseModel):
    campaign_id: str
    tenant_id: str
    name: str
    objective: str
    status: str
    contact_count: int
    max_concurrent: int
    created_at: str
    started_at: str | None = None
    completed_at: str | None = None


class ProgressResponse(BaseModel):
    campaign_id: str
    status: str
    progress: dict[str, Any]


# ---------------------------------------------------------------------------
# Dependency
# ---------------------------------------------------------------------------


def _get_dialer() -> BulkCampaignDialer:
    return get_bulk_campaign_dialer()


def _normalize_tenant_id(value: str | None) -> str:
    raw = (value or "").strip()
    if not raw:
        raise HTTPException(status_code=401, detail="Authentication required")
    return raw if raw.startswith("TENANT#") else f"TENANT#{raw}"


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("/create", response_model=CampaignResponse, status_code=status.HTTP_201_CREATED)
async def create_campaign(
    body: CreateCampaignRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    dialer: BulkCampaignDialer = Depends(_get_dialer),
) -> CampaignResponse:
    """Create a new bulk calling campaign."""
    tid = _normalize_tenant_id(tenant_id)
    campaign = dialer.create_campaign(
        tenant_id=tid,
        name=body.name,
        objective=body.objective,
        contacts=body.contacts,
        max_concurrent=body.max_concurrent,
    )
    return CampaignResponse(
        campaign_id=campaign.campaign_id,
        tenant_id=campaign.tenant_id,
        name=campaign.name,
        objective=campaign.objective,
        status=campaign.status.value,
        contact_count=len(campaign.contacts),
        max_concurrent=campaign.max_concurrent,
        created_at=campaign.created_at,
    )


@router.post("/{campaign_id}/start")
async def start_campaign(
    campaign_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    dialer: BulkCampaignDialer = Depends(_get_dialer),
) -> dict[str, Any]:
    """Start executing a campaign."""
    campaign = dialer.get_campaign(campaign_id)
    if not campaign:
        raise HTTPException(status_code=404, detail="Campaign not found")
    ok = await dialer.start_campaign(campaign_id)
    if not ok:
        raise HTTPException(status_code=409, detail="Campaign cannot be started")
    return {"campaign_id": campaign_id, "status": "running"}


@router.post("/{campaign_id}/pause")
async def pause_campaign(
    campaign_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    dialer: BulkCampaignDialer = Depends(_get_dialer),
) -> dict[str, Any]:
    """Pause a running campaign."""
    campaign = dialer.get_campaign(campaign_id)
    if not campaign:
        raise HTTPException(status_code=404, detail="Campaign not found")
    ok = dialer.pause_campaign(campaign_id)
    if not ok:
        raise HTTPException(status_code=409, detail="Campaign cannot be paused")
    return {"campaign_id": campaign_id, "status": "paused"}


@router.get("/{campaign_id}/progress", response_model=ProgressResponse)
async def campaign_progress(
    campaign_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    dialer: BulkCampaignDialer = Depends(_get_dialer),
) -> ProgressResponse:
    """Get campaign progress."""
    campaign = dialer.get_campaign(campaign_id)
    if not campaign:
        raise HTTPException(status_code=404, detail="Campaign not found")
    return ProgressResponse(
        campaign_id=campaign_id,
        status=campaign.status.value,
        progress=campaign.progress,
    )


@router.get("/list")
async def list_campaigns(
    tenant_id: str = Depends(get_verified_tenant_id),
    dialer: BulkCampaignDialer = Depends(_get_dialer),
) -> dict[str, Any]:
    """List all campaigns for the authenticated tenant."""
    tid = _normalize_tenant_id(tenant_id)
    campaigns = dialer.list_campaigns(tid)
    return {
        "campaigns": [
            {
                "campaign_id": c.campaign_id,
                "name": c.name,
                "status": c.status.value,
                "contact_count": len(c.contacts),
                "progress": c.progress,
                "created_at": c.created_at,
            }
            for c in campaigns
        ],
        "count": len(campaigns),
    }
