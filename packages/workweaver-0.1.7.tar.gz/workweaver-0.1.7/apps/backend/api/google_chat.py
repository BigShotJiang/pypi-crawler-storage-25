"""Google Chat webhook handler for the Workweaver Runtime Harness.

Provides:
- POST /api/v1/webhooks/google-chat -- receive Google Chat events
    (message events with space/sender metadata)

Verifies webhook token from X-Goog-Chat-Token header.
Routes events through the channel router.

Issue #3203: Google Chat connector via PlatformAdapter Protocol (no Pub/Sub daemon).
"""

from __future__ import annotations

import logging
import os
from typing import Any

from fastapi import APIRouter, HTTPException, Request
from fastapi.responses import JSONResponse

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/webhooks/google-chat", tags=["webhooks", "google-chat"])

_WEBHOOK_TOKEN_ENV = "GOOGLE_CHAT_WEBHOOK_TOKEN"


def _verify_webhook_token(request: Request) -> None:
    """Verify the Google Chat webhook token.

    Google Chat sends a verification token in the X-Goog-Chat-Token header
    for bot-initiated webhooks. Raises HTTPException 401 if missing or
    invalid.
    """
    expected = os.getenv(_WEBHOOK_TOKEN_ENV, "").strip()
    if not expected:
        raise HTTPException(status_code=401, detail="GOOGLE_CHAT_WEBHOOK_TOKEN not configured")

    provided = str(request.headers.get("X-Goog-Chat-Token", "")).strip()
    if provided != expected:
        raise HTTPException(status_code=401, detail="Invalid Google Chat webhook token")


async def _route_to_channel_router(
    *,
    event: dict[str, Any],
) -> dict[str, Any]:
    """Route a Google Chat event to the channel router for processing."""
    try:
        from apps.backend.services.channels.channel_router import get_channel_router, summarize_delivery_result
    except ImportError:
        logger.debug("ChannelRouter not available -- Google Chat event not routed")
        return {
            "status": "manual_required",
            "delivery_status": "failed",
            "channel": "google_chat",
        }

    message = event.get("message", {}) or {}
    sender = message.get("sender", {}) or {}
    space = event.get("space", {}) or {}
    text = str(message.get("text", ""))
    sender_name = str(sender.get("name", "unknown"))
    space_name = str(space.get("name", ""))

    contact_id = sender_name
    tenant_id = f"TENANT#google_chat#{space_name}"

    router_instance = get_channel_router()

    try:
        delivery = await router_instance.route_message(
            tenant_id=tenant_id,
            contact_id=contact_id,
            message=text,
            channel_origin="google_chat",
        )
        return summarize_delivery_result(delivery)
    except Exception as exc:
        logger.warning("Google Chat routing failed (non-fatal): %s", exc)
        return {
            "status": "manual_required",
            "delivery_status": "failed",
            "channel": "google_chat",
            "error": str(exc),
        }


@router.post("")
async def handle_google_chat_webhook(request: Request) -> JSONResponse:
    """Handle Google Chat webhook callbacks.

    Supports:
    - MESSAGE: processes message events from Google Chat spaces
    - Other event types: acknowledges and logs
    """
    _verify_webhook_token(request)

    try:
        payload: dict[str, Any] = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    event_type = str(payload.get("type", "")).strip()
    event = payload.get("event", {}) or {}

    if event_type == "MESSAGE":
        message = event.get("message", {}) or {}
        sender = message.get("sender", {}) or {}
        text = str(message.get("text", ""))
        space = event.get("space", {}) or {}

        logger.info(
            "google_chat.webhook.message space=%s sender=%s text_len=%d",
            space.get("name", ""),
            sender.get("name", ""),
            len(text),
        )

        outcome = await _route_to_channel_router(event=event)

        return JSONResponse(
            content={"status": "ok", "delivery": outcome},
            status_code=200,
        )

    logger.info("google_chat.webhook.ignored_type type=%s", event_type)
    return JSONResponse(content={"status": "ignored"}, status_code=200)
