"""
Account Lifecycle API Endpoints — GDPR-compliant deletion and data export.

REST API for:
- DELETE /api/v1/account/{tenant_id} — full account cascade deletion
- DELETE /api/v1/account/{tenant_id}/user/{user_id} — single user deletion
- GET /api/v1/account/{tenant_id}/data-export — GDPR Art. 20 data portability

Constitutional compliance:
- Axiom 2: All deletions produce immutable evidence receipts
- Axiom 5: Automated lifecycle operations (no human intervention required)
"""
from apps.backend.config.table_names import resolve_table

import json
import logging
import os
import zipfile
from io import BytesIO
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import Response
from pydantic import BaseModel, Field

from apps.backend.services.account_lifecycle import (
    AccountLifecycleService,
    AccountLifecycleError,
    TenantNotFoundError,
)
from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/account", tags=["account-lifecycle"])


# ============================================================================
# Dependencies
# ============================================================================


def get_account_lifecycle_service() -> AccountLifecycleService:
    """Get account lifecycle service instance."""
    try:
        return AccountLifecycleService(
            tenants_table=resolve_table("tenants"),
            stripe_api_key=os.getenv("STRIPE_API_KEY", ""),
        )
    except Exception as e:
        logger.error(f"Failed to initialize account lifecycle service: {e}")
        raise HTTPException(
            status_code=500,
            detail="Failed to initialize account lifecycle service",
        )


# ============================================================================
# Request / Response Models
# ============================================================================


class DeleteAccountRequest(BaseModel):
    """Request body for account deletion."""

    reason: str = Field(
        default="user_requested",
        description="Reason for deletion (e.g. gdpr_request, admin_action)",
    )


class DeleteSelfRequest(BaseModel):
    """Request body for authenticated self-service deletion."""

    confirm_email: str = Field(
        default="",
        description="Email confirmation entered by the user in settings UI.",
    )
    reason: str = Field(
        default="user_requested",
        description="Reason for deletion",
    )


class DeletionCertificateResponse(BaseModel):
    """Response model for deletion operations."""

    tenant_id: str = Field(..., description="Deleted tenant ID")
    deleted_at: str = Field(..., description="ISO timestamp of deletion")
    reason: str = Field(..., description="Reason for deletion")
    evidence_receipt_id: str = Field(..., description="UUID evidence receipt")
    cascade_steps: list[str] = Field(
        default_factory=list,
        description="Completed cascade steps",
    )
    evidence_event_id: str | None = Field(
        default=None,
        description="Evidence Ledger record for the deletion proof",
    )
    evidence_url: str | None = Field(
        default=None,
        description="Evidence API URL for the deletion proof",
    )


class DataExportResponse(BaseModel):
    """Response model for GDPR data export."""

    tenant_id: str = Field(..., description="Tenant ID")
    exported_at: str = Field(..., description="ISO timestamp of export")
    profile: dict[str, Any] = Field(default_factory=dict)
    billing: dict[str, Any] = Field(default_factory=dict)
    users: list[dict[str, Any]] = Field(default_factory=list)
    tasks: list[dict[str, Any]] = Field(default_factory=list)
    memories: list[dict[str, Any]] = Field(default_factory=list)
    other: list[dict[str, Any]] = Field(default_factory=list)


# ============================================================================
# API Endpoints
# ============================================================================


def _serialize_export(
    export_payload: dict[str, Any],
    export_format: str,
) -> tuple[bytes, str, str]:
    """Render an export payload to bytes + media-type + file extension."""
    if export_format == "jsonl":
        lines: list[str] = []
        for section in ("profile", "billing"):
            lines.append(json.dumps({"section": section, "data": export_payload.get(section, {})}, ensure_ascii=False))
        for section in ("users", "tasks", "memories", "other"):
            for item in export_payload.get(section, []):
                lines.append(json.dumps({"section": section, "data": item}, ensure_ascii=False))
        content = ("\n".join(lines) + ("\n" if lines else "")).encode("utf-8")
        return content, "application/x-ndjson", "jsonl"

    if export_format == "zip":
        payload = json.dumps(export_payload, ensure_ascii=False, indent=2).encode("utf-8")
        buf = BytesIO()
        with zipfile.ZipFile(buf, mode="w", compression=zipfile.ZIP_DEFLATED) as zf:
            zf.writestr("workweaver-export.json", payload)
        return buf.getvalue(), "application/zip", "zip"

    payload = json.dumps(export_payload, ensure_ascii=False, indent=2).encode("utf-8")
    return payload, "application/json", "json"


def _validate_confirm_email(
    *,
    service: AccountLifecycleService,
    tenant_id: str,
    confirm_email: str,
) -> None:
    """Best-effort confirm-email validation against tenant metadata."""
    expected = confirm_email.strip().lower()
    if not expected:
        return
    try:
        tenant = service._get_tenant_record(tenant_id)  # type: ignore[attr-defined]
        known = {
            str(tenant.get("email") or "").strip().lower(),
            str(tenant.get("billing_email") or "").strip().lower(),
        }
        known.discard("")
        if known and expected not in known:
            raise HTTPException(status_code=400, detail="Email confirmation does not match account email")
    except TenantNotFoundError:
        raise HTTPException(status_code=404, detail="Organization not found")


@router.delete(
    "/me",
    response_model=DeletionCertificateResponse,
    summary="Delete authenticated account/user",
    description="Deletes authenticated user if user context exists, otherwise deletes tenant account.",
)
async def delete_my_account(
    request: Request,
    body: DeleteSelfRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    service: AccountLifecycleService = Depends(get_account_lifecycle_service),
) -> DeletionCertificateResponse:
    """Self-service deletion endpoint used by settings UI."""
    _validate_confirm_email(
        service=service,
        tenant_id=tenant_id,
        confirm_email=body.confirm_email,
    )
    user_id = str(getattr(request.state, "user_id", "") or "").strip()
    try:
        if user_id:
            cert = service.delete_user(tenant_id=tenant_id, user_id=user_id)
        else:
            cert = service.delete_account(tenant_id=tenant_id, reason=body.reason)
        return DeletionCertificateResponse(
            tenant_id=cert.tenant_id,
            deleted_at=cert.deleted_at,
            reason=cert.reason,
            evidence_receipt_id=cert.evidence_receipt_id,
            cascade_steps=cert.cascade_steps,
            evidence_event_id=cert.evidence_event_id,
            evidence_url=cert.evidence_url,
        )
    except TenantNotFoundError:
        raise HTTPException(status_code=404, detail="Organization not found")
    except AccountLifecycleError as e:
        logger.error(f"Self-service deletion failed: {e}")
        raise HTTPException(status_code=500, detail="Account deletion failed")


@router.get(
    "/me/data-export",
    summary="Authenticated data export",
    description="Export authenticated account data in json/jsonl/zip format.",
)
async def export_my_data(
    export_format: str = Query(
        default="json",
        alias="format",
        pattern="^(json|jsonl|zip)$",
        description="Export format",
    ),
    tenant_id: str = Depends(get_verified_tenant_id),
    service: AccountLifecycleService = Depends(get_account_lifecycle_service),
) -> Response:
    """Self-service export endpoint used by settings UI."""
    try:
        data = service.export_user_data(tenant_id=tenant_id)
        payload, media_type, ext = _serialize_export(data, export_format)
        filename = f"workweaver-export-{tenant_id}.{ext}"
        return Response(
            content=payload,
            media_type=media_type,
            headers={"Content-Disposition": f'attachment; filename="{filename}"'},
        )
    except TenantNotFoundError:
        raise HTTPException(status_code=404, detail="Organization not found")
    except AccountLifecycleError as e:
        logger.error(f"Self-service export failed: {e}")
        raise HTTPException(status_code=500, detail="Data export failed")


@router.delete(
    "/{tenant_id}",
    response_model=DeletionCertificateResponse,
    summary="Delete entire tenant account",
    description="Cascade delete: Stripe, WorkMemory, S3, DynamoDB. Produces evidence receipt.",
)
async def delete_account(
    tenant_id: str,
    request: DeleteAccountRequest = DeleteAccountRequest(),
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    service: AccountLifecycleService = Depends(get_account_lifecycle_service),
) -> DeletionCertificateResponse:
    """Delete entire tenant account with full cascade.

    Requires authenticated caller whose verified tenant matches the path tenant_id.
    """
    if verified_tenant_id != tenant_id:
        raise HTTPException(
            status_code=403,
            detail="Cannot delete a different organization's account",
        )
    try:
        cert = service.delete_account(
            tenant_id=tenant_id,
            reason=request.reason,
        )
        return DeletionCertificateResponse(
            tenant_id=cert.tenant_id,
            deleted_at=cert.deleted_at,
            reason=cert.reason,
            evidence_receipt_id=cert.evidence_receipt_id,
            cascade_steps=cert.cascade_steps,
            evidence_event_id=cert.evidence_event_id,
            evidence_url=cert.evidence_url,
        )
    except TenantNotFoundError:
        raise HTTPException(status_code=404, detail="Organization not found")
    except AccountLifecycleError as e:
        logger.error(f"Account deletion failed: {e}")
        raise HTTPException(status_code=500, detail="Account deletion failed")
    except Exception as e:
        logger.error(f"Unexpected error deleting account: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.delete(
    "/{tenant_id}/user/{user_id}",
    response_model=DeletionCertificateResponse,
    summary="Delete single user within tenant",
    description="Remove user record and associated data. Produces evidence receipt.",
)
async def delete_user(
    tenant_id: str,
    user_id: str,
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    service: AccountLifecycleService = Depends(get_account_lifecycle_service),
) -> DeletionCertificateResponse:
    """Delete a single user within a tenant.

    Requires authenticated caller whose verified tenant matches the path tenant_id.
    """
    if verified_tenant_id != tenant_id:
        raise HTTPException(
            status_code=403,
            detail="Cannot delete a user in a different organization",
        )
    try:
        cert = service.delete_user(
            tenant_id=tenant_id,
            user_id=user_id,
        )
        return DeletionCertificateResponse(
            tenant_id=cert.tenant_id,
            deleted_at=cert.deleted_at,
            reason=cert.reason,
            evidence_receipt_id=cert.evidence_receipt_id,
            cascade_steps=cert.cascade_steps,
            evidence_event_id=cert.evidence_event_id,
            evidence_url=cert.evidence_url,
        )
    except TenantNotFoundError:
        raise HTTPException(status_code=404, detail="Organization not found")
    except AccountLifecycleError as e:
        logger.error(f"User deletion failed: {e}")
        raise HTTPException(status_code=500, detail="User deletion failed")
    except Exception as e:
        logger.error(f"Unexpected error deleting user: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")


@router.get(
    "/{tenant_id}/data-export",
    response_model=DataExportResponse,
    summary="GDPR data export",
    description="Export all user data for GDPR Art. 20 data portability.",
)
async def export_user_data(
    tenant_id: str,
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    service: AccountLifecycleService = Depends(get_account_lifecycle_service),
) -> DataExportResponse:
    """Export all user data for GDPR compliance.

    Requires authenticated caller whose verified tenant matches the path tenant_id.
    """
    if verified_tenant_id != tenant_id:
        raise HTTPException(
            status_code=403,
            detail="Cannot export data for a different organization",
        )
    try:
        data = service.export_user_data(tenant_id=tenant_id)
        return DataExportResponse(**data)
    except TenantNotFoundError:
        raise HTTPException(status_code=404, detail="Organization not found")
    except AccountLifecycleError as e:
        logger.error(f"Data export failed: {e}")
        raise HTTPException(status_code=500, detail="Data export failed")
    except Exception as e:
        logger.error(f"Unexpected error exporting data: {e}")
        raise HTTPException(status_code=500, detail="Internal server error")
