"""Coordination API -- productized org-worker coordination endpoints (#1862)."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.coordination_orchestrator import (
    CoordinationOrchestrator,
    CoordinationSession,
)

logger = logging.getLogger(__name__)
router = APIRouter()

_orchestrators: dict[str, CoordinationOrchestrator] = {}


def _get_orchestrator(tenant_id: str) -> CoordinationOrchestrator:
    if tenant_id not in _orchestrators:
        _orchestrators[tenant_id] = CoordinationOrchestrator(tenant_id=tenant_id)
    return _orchestrators[tenant_id]


def _session_to_response(session: CoordinationSession) -> dict[str, Any]:
    return {
        "session_id": session.session_id, "tenant_id": session.tenant_id,
        "objective": session.objective, "phase": session.phase.value,
        "task_id": session.task_id, "selected_worker_id": session.selected_worker_id,
        "handoff_id": session.handoff_id, "evidence_ids": session.evidence_ids,
        "constraints": session.constraints,
        "created_at": session.created_at.isoformat() if session.created_at else None,
        "completed_at": session.completed_at.isoformat() if session.completed_at else None,
    }


@router.post("/coordination/sessions", status_code=201)
async def start_coordination(objective: str, constraints: dict[str, Any] | None = None, session_id: str | None = None, tenant_id: str = Depends(get_verified_tenant_id)) -> dict[str, Any]:
    return _session_to_response(_get_orchestrator(tenant_id).start(objective=objective, constraints=constraints, session_id=session_id))


@router.get("/coordination/sessions")
async def list_coordination_sessions(tenant_id: str = Depends(get_verified_tenant_id)) -> list[dict[str, Any]]:
    return [_session_to_response(s) for s in _get_orchestrator(tenant_id).list_sessions()]


@router.get("/coordination/sessions/{session_id}")
async def get_coordination_session(session_id: str, tenant_id: str = Depends(get_verified_tenant_id)) -> dict[str, Any]:
    status = _get_orchestrator(tenant_id).monitor(session_id)
    if status is None:
        raise HTTPException(status_code=404, detail="Coordination session not found")
    return status


@router.post("/coordination/sessions/{session_id}/discover")
async def discover_workers(session_id: str, capability: str | None = None, tenant_id: str = Depends(get_verified_tenant_id)) -> list[dict[str, Any]]:
    return [{"agent_id": c.agent_id, "capabilities": c.capabilities, "capacity": c.capacity, "current_tasks": c.current_tasks} for c in _get_orchestrator(tenant_id).discover(session_id, capability=capability)]


@router.post("/coordination/sessions/{session_id}/dispatch")
async def dispatch_worker(session_id: str, worker_id: str, subtask: str, from_agent: str = "coordinator", tenant_id: str = Depends(get_verified_tenant_id)) -> dict[str, Any]:
    orch = _get_orchestrator(tenant_id)
    if not orch.select_and_dispatch(session_id, worker_id, subtask, from_agent=from_agent):
        raise HTTPException(status_code=400, detail="Dispatch failed")
    return _session_to_response(orch.get_session(session_id))


@router.post("/coordination/sessions/{session_id}/context-share")
async def request_context_share(session_id: str, requesting_agent: str, target_agent: str, reason: str, tenant_id: str = Depends(get_verified_tenant_id)) -> dict[str, Any]:
    result = _get_orchestrator(tenant_id).request_context_share(session_id, requesting_agent=requesting_agent, target_agent=target_agent, reason=reason)
    return {"granted": result.granted, "access_level": result.access_level.value, "reason": result.reason}


@router.post("/coordination/sessions/{session_id}/context-share/approve")
async def approve_context_share(session_id: str, requesting_agent: str, target_agent: str, tenant_id: str = Depends(get_verified_tenant_id)) -> dict[str, Any]:
    if not _get_orchestrator(tenant_id).approve_context_share(session_id, requesting_agent=requesting_agent, target_agent=target_agent):
        raise HTTPException(status_code=400, detail="Approval failed")
    return {"approved": True}


@router.post("/coordination/sessions/{session_id}/evidence")
async def record_evidence(session_id: str, evidence_id: str, agent_id: str, description: str, tenant_id: str = Depends(get_verified_tenant_id)) -> dict[str, Any]:
    if not _get_orchestrator(tenant_id).record_evidence(session_id, evidence_id=evidence_id, agent_id=agent_id, description=description):
        raise HTTPException(status_code=400, detail="Evidence recording failed")
    return {"recorded": True, "evidence_id": evidence_id}


@router.post("/coordination/sessions/{session_id}/complete")
async def complete_with_retrospective(session_id: str, tenant_id: str = Depends(get_verified_tenant_id)) -> dict[str, Any]:
    report = _get_orchestrator(tenant_id).complete_with_retrospective(session_id)
    if report is None:
        raise HTTPException(status_code=404, detail="Coordination session not found")
    return {"session_id": report.session_id, "task_id": report.task_id, "objective": report.objective, "participants": report.participants, "total_traces": report.total_traces, "evidence_count": report.evidence_count, "audit_events": report.audit_events, "duration_summary": report.duration_summary, "lessons": report.lessons, "delegate_count": report.delegate_count, "context_shares": report.context_shares}


@router.post("/coordination/workers")
async def register_worker(agent_id: str, capabilities: list[str], capacity: float = 1.0, current_tasks: int = 0, tenant_id: str = Depends(get_verified_tenant_id)) -> dict[str, Any]:
    _get_orchestrator(tenant_id).register_worker(agent_id, capabilities=capabilities, capacity=capacity, current_tasks=current_tasks)
    return {"registered": True, "agent_id": agent_id}


__all__ = ["router"]
