"""Analytics funnel observability for tenant conversion tracking.

Tracks: signup -> verify -> configure -> deploy -> active
Provides: GET /api/v1/analytics/funnel for conversion rates per stage.

Source: Phase 9.2 -- Analytics Funnel Observability
"""

import logging

from fastapi import APIRouter, Depends, HTTPException, Path, status
from pydantic import BaseModel, Field

from apps.backend.middleware.tenant_isolation import get_tenant_id
from apps.backend.services.funnel_analytics import (
    FunnelAnalyticsService,
    FunnelStage,
)

logger = logging.getLogger(__name__)

# ============================================================================
# Router
# ============================================================================

router = APIRouter(
    prefix="/api/v1/analytics/funnel",
    tags=["analytics-funnel"],
)

# Singleton service instance
_funnel_svc = FunnelAnalyticsService()


# ============================================================================
# Pydantic Models
# ============================================================================


class StageCount(BaseModel):
    """Stage count in the funnel."""

    stage: str
    count: int


class BottleneckInfo(BaseModel):
    """Bottleneck identification."""

    stage: str | None = None
    drop_count: int = 0


class FunnelMetricsResponse(BaseModel):
    """Full funnel metrics response."""

    stages: list[StageCount]
    conversion_rates: dict[str, float]
    bottleneck: BottleneckInfo
    total_tenants: int


class TenantStageResponse(BaseModel):
    """Tenant's current funnel stage."""

    tenant_id: str
    stage: str | None = None


class RecordTransitionRequest(BaseModel):
    """Request to record a stage transition."""

    stage: str = Field(
        ...,
        description="Funnel stage: SIGNED_UP, VERIFIED, CONFIGURED, DEPLOYED, ACTIVE",
    )


# ============================================================================
# Dependencies
# ============================================================================


def get_funnel_service() -> FunnelAnalyticsService:
    """Get FunnelAnalyticsService singleton."""
    return _funnel_svc


# ============================================================================
# Endpoints
# ============================================================================


@router.get(
    "",
    response_model=FunnelMetricsResponse,
    summary="Get funnel conversion metrics",
    description="Return conversion rates per stage with bottleneck identification",
)
async def get_funnel_metrics(
    tenant_id: str = Depends(get_tenant_id),
    svc: FunnelAnalyticsService = Depends(get_funnel_service),
) -> FunnelMetricsResponse:
    """Return funnel-wide conversion metrics.

    Includes stage counts, conversion rates between adjacent stages,
    and bottleneck identification.
    """
    try:
        metrics = svc.get_funnel_metrics()
        return FunnelMetricsResponse(
            stages=[StageCount(**s) for s in metrics["stages"]],
            conversion_rates=metrics["conversion_rates"],
            bottleneck=BottleneckInfo(**metrics["bottleneck"]),
            total_tenants=metrics["total_tenants"],
        )
    except Exception as e:
        logger.error("Failed to get funnel metrics: %s", e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to compute funnel metrics",
        )


@router.get(
    "/{tenant_id}",
    response_model=TenantStageResponse,
    summary="Get tenant funnel stage",
    description="Return the current funnel stage for a specific tenant",
)
async def get_tenant_funnel_stage(
    tenant_id: str = Path(..., description="Tenant ID to look up"),
    _caller_tenant: str = Depends(get_tenant_id),
    svc: FunnelAnalyticsService = Depends(get_funnel_service),
) -> TenantStageResponse:
    """Return a specific tenant's current funnel stage."""
    if _caller_tenant != f"TENANT#{tenant_id}" and _caller_tenant != tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot access another organization's funnel stage",
        )
    try:
        stage = svc.get_tenant_stage(tenant_id)
        return TenantStageResponse(tenant_id=tenant_id, stage=stage)
    except Exception as e:
        logger.error("Failed to get tenant stage for %s: %s", tenant_id, e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get organization stage",
        )


@router.post(
    "/{target_tenant_id}/transition",
    response_model=TenantStageResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Record stage transition",
    description="Record a tenant reaching a new funnel stage",
)
async def record_transition(
    request: RecordTransitionRequest,
    target_tenant_id: str = Path(..., description="Tenant to record transition for"),
    _caller_tenant: str = Depends(get_tenant_id),
    svc: FunnelAnalyticsService = Depends(get_funnel_service),
) -> TenantStageResponse:
    """Record a tenant reaching a new funnel stage."""
    if _caller_tenant != f"TENANT#{target_tenant_id}" and _caller_tenant != target_tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot modify another organization's funnel stage",
        )
    try:
        stage = FunnelStage(request.stage)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid stage: {request.stage}. Must be one of: {[s.value for s in FunnelStage]}",
        )

    try:
        svc.record_stage_transition(target_tenant_id, stage)
        current_stage = svc.get_tenant_stage(target_tenant_id)
        return TenantStageResponse(tenant_id=target_tenant_id, stage=current_stage)
    except Exception as e:
        logger.error("Failed to record transition for %s: %s", target_tenant_id, e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to record stage transition",
        )
