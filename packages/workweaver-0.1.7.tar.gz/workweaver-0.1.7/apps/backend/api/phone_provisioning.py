"""
Phone Provisioning API

Provides REST endpoints for agent-native phone number provisioning against
tenant-owned Twilio accounts (BYO): credentials come from the connector install
(POST /api/v1/connectors/twilio/connect), not Workweaver-managed carrier APIs.

- POST /api/provisioning/search - Search for available numbers
- POST /api/provisioning/purchase - Purchase a phone number
- POST /api/provisioning/verify - Verify a caller ID
- GET /api/provisioning/verify/{phone_number} - Get verification status
- GET /api/provisioning/bundles - List regulatory bundles
- POST /api/provisioning/bundles/attach - Attach regulatory bundle

These endpoints are designed for autonomous agent usage, not UI workflows.
They do not imply Workweaver-managed carrier provisioning (#1317).
"""

import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field, field_validator

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.services.phone_provisioning import (
    PhoneProvisioningService,
    PhoneNumberType,
)
from apps.backend.services.tenant_twilio_byo import (
    TenantTwilioBYOError,
    resolve_twilio_rest_client_for_tenant,
    twilio_byo_error_payload,
)

logger = logging.getLogger(__name__)


def _twilio_client_for_tenant(tenant_id: str):
    try:
        return resolve_twilio_rest_client_for_tenant(tenant_id)
    except TenantTwilioBYOError as exc:
        raise HTTPException(
            status_code=status.HTTP_412_PRECONDITION_FAILED,
            detail=twilio_byo_error_payload(exc),
        ) from exc


# ============================================================================
# Request/Response Models
# ============================================================================


class SearchNumbersRequest(BaseModel):
    """Request to search for available phone numbers."""

    iso_country: str = Field(
        default="US",
        description="ISO 3166-1 alpha-2 country code",
        min_length=2,
        max_length=2,
    )

    area_code: str | None = Field(
        default=None,
        description="Area code to filter (US only, e.g., '415')",
        max_length=3,
    )

    region: str | None = Field(
        default=None,
        description="State/province to filter (e.g., 'CA')",
        max_length=100,
    )

    locality: str | None = Field(
        default=None,
        description="City name to filter (e.g., 'San Francisco')",
        max_length=200,
    )

    number_type: str = Field(
        default="local",
        description="Type of number: local, mobile, toll_free, national",
    )

    limit: int = Field(
        default=10,
        description="Maximum results to return (1-100)",
        ge=1,
        le=100,
    )

    @field_validator("number_type")
    @classmethod
    def validate_number_type(cls, v):
        valid_types = {"local", "mobile", "toll_free", "national"}
        if v not in valid_types:
            raise ValueError(f"Invalid number_type: {v}. Must be one of {valid_types}")
        return v

    @field_validator("iso_country")
    @classmethod
    def validate_iso_country(cls, v):
        if not v or len(v) != 2 or not v.isalpha() or not v.isupper():
            raise ValueError("iso_country must be ISO 3166-1 alpha-2 code (e.g., 'US', 'AE')")
        return v


class PurchaseNumberRequest(BaseModel):
    """Request to purchase a phone number."""

    phone_number: str = Field(
        ...,
        description="E.164 phone number to purchase (e.g., '+14155551234')",
    )

    friendly_name: str | None = Field(
        default=None,
        description="Optional friendly name for the number",
        max_length=200,
    )

    sms_url: str | None = Field(
        default=None,
        description="Optional SMS webhook URL",
    )

    voice_url: str | None = Field(
        default=None,
        description="Optional voice webhook URL",
    )

    @field_validator("sms_url", "voice_url")
    @classmethod
    def validate_webhook_url(cls, v: str | None) -> str | None:
        if v is None:
            return v
        from urllib.parse import urlparse

        parsed = urlparse(v)
        if parsed.scheme not in ("https",):
            raise ValueError("Webhook URL must use HTTPS")
        # "0.0.0.0" is in a DENY list (SSRF guard), not a bind target.
        forbidden_hosts = ("localhost", "127.0.0.1", "0.0.0.0", "169.254.169.254")  # nosec B104  # noqa: S104
        if not parsed.hostname or parsed.hostname in forbidden_hosts:
            raise ValueError("Webhook URL must not point to internal addresses")
        return v

    voice_method: str = Field(
        default="POST",
        description="HTTP method for voice webhook",
    )

    @field_validator("phone_number")
    @classmethod
    def validate_phone_number(cls, v):
        from apps.backend.services.phone_provisioning import PhoneProvisioningService

        if not PhoneProvisioningService.validate_phone_number(v):
            raise ValueError("phone_number must be in E.164 format (e.g., '+14155551234')")
        return v


class VerifyCallerIdRequest(BaseModel):
    """Request to verify an outgoing caller ID."""

    phone_number: str = Field(
        ...,
        description="E.164 phone number to verify (e.g., '+14155551234')",
    )

    friendly_name: str | None = Field(
        default=None,
        description="Optional friendly name for the caller ID",
        max_length=200,
    )

    call_delay: int = Field(
        default=0,
        description="Delay before verification call (seconds)",
        ge=0,
        le=300,
    )

    @field_validator("phone_number")
    @classmethod
    def validate_phone_number(cls, v):
        from apps.backend.services.phone_provisioning import PhoneProvisioningService

        if not PhoneProvisioningService.validate_phone_number(v):
            raise ValueError("phone_number must be in E.164 format (e.g., '+14155551234')")
        return v


class AttachBundleRequest(BaseModel):
    """Request to attach regulatory bundle to phone number."""

    phone_number_sid: str = Field(
        ...,
        description="Twilio phone number SID (PN...)",
    )

    bundle_sid: str = Field(
        ...,
        description="Regulatory bundle SID (RN...)",
    )

    @field_validator("phone_number_sid")
    @classmethod
    def validate_phone_number_sid(cls, v):
        if not v or not v.startswith("PN"):
            raise ValueError("phone_number_sid must be a Twilio phone number SID (starts with PN)")
        return v

    @field_validator("bundle_sid")
    @classmethod
    def validate_bundle_sid(cls, v):
        if not v or not v.startswith("RN"):
            raise ValueError("bundle_sid must be a Twilio regulatory bundle SID (starts with RN)")
        return v


# ============================================================================
# API Router
# ============================================================================

router = APIRouter(
    prefix="/api/provisioning",
    tags=["phone-provisioning"],
    dependencies=[Depends(get_verified_tenant_id)],
)


@router.post("/search", response_model=list[dict])
async def search_numbers(
    request: Request,
    body: SearchNumbersRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """
    Search for available phone numbers.

    Returns a list of available numbers matching the search criteria.
    Results include phone number, region, capabilities, and beta status.

    Used by agents to find numbers to purchase without UI interaction.
    """
    try:
        twilio_client = _twilio_client_for_tenant(tenant_id)

        # Map number_type string to enum
        number_type_map = {
            "local": PhoneNumberType.LOCAL,
            "mobile": PhoneNumberType.MOBILE,
            "toll_free": PhoneNumberType.TOLL_FREE,
            "national": PhoneNumberType.NATIONAL,
        }
        number_type = number_type_map.get(body.number_type, PhoneNumberType.LOCAL)

        provisioning_service = PhoneProvisioningService(twilio_client)

        results = await provisioning_service.search_number(
            iso_country=body.iso_country,
            area_code=body.area_code,
            region=body.region,
            locality=body.locality,
            number_type=number_type,
            limit=body.limit,
        )

        # Convert to dict for JSON response
        return [
            {
                "phone_number": result.phone_number,
                "friendly_name": result.friendly_name,
                "region": result.region,
                "locality": result.locality,
                "rate_center": result.rate_center,
                "lata": result.lata,
                "iso_country": result.iso_country,
                "capabilities": result.capabilities,
                "number_type": result.number_type.value,
                "beta": result.beta,
                "ownership_model": result.ownership_model,
            }
            for result in results
        ]

    except ValueError as e:
        logger.warning("search_numbers validation error: %s", e)
        raise HTTPException(status_code=400, detail="Invalid search parameters")
    except Exception as e:
        logger.error(f"Failed to search numbers: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to search for phone numbers")


@router.post("/purchase", response_model=dict)
async def purchase_number(
    request: Request,
    body: PurchaseNumberRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """
    Purchase a phone number.

    Purchases the specified phone number and returns details.
    The number becomes available in the account immediately.

    Used by agents to provision numbers without UI interaction.
    """
    try:
        twilio_client = _twilio_client_for_tenant(tenant_id)
        provisioning_service = PhoneProvisioningService(twilio_client)

        result = await provisioning_service.purchase_number(
            phone_number=body.phone_number,
            friendly_name=body.friendly_name,
            sms_url=body.sms_url,
            voice_url=body.voice_url,
            voice_method=body.voice_method,
        )

        return {
            "phone_number": result.phone_number,
            "sid": result.sid,
            "account_sid": result.account_sid,
            "friendly_name": result.friendly_name,
            "date_created": result.date_created,
            "capabilities": result.capabilities,
            "status": result.status,
            "ownership_model": result.ownership_model,
            "message": "Phone number purchased successfully",
        }

    except ValueError as e:
        logger.warning("purchase_number validation error: %s", e)
        raise HTTPException(status_code=400, detail="Invalid purchase request")
    except Exception as e:
        logger.error(f"Failed to purchase number: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to purchase phone number")


@router.post("/verify", response_model=dict)
async def verify_caller_id(
    request: Request,
    body: VerifyCallerIdRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """
    Verify an outgoing caller ID.

    Initiates a verification call to the phone number.
    The user must enter a verification code via DTMF tones.
    Status can be checked via GET /api/provisioning/verify/{phone_number}.

    Used by agents to verify caller IDs without UI interaction.
    """
    try:
        twilio_client = _twilio_client_for_tenant(tenant_id)
        provisioning_service = PhoneProvisioningService(twilio_client)

        result = await provisioning_service.verify_caller_id(
            phone_number=body.phone_number,
            friendly_name=body.friendly_name,
            call_delay=body.call_delay,
        )

        return {
            "phone_number": result.phone_number,
            "sid": result.sid,
            "account_sid": result.account_sid,
            "friendly_name": result.friendly_name,
            "date_created": result.date_created,
            "date_verified": result.date_verified,
            "status": "pending",
            "ownership_model": result.ownership_model,
            "message": "Verification call initiated. Enter verification code when prompted.",
        }

    except ValueError as e:
        logger.warning("verify_caller_id validation error: %s", e)
        raise HTTPException(status_code=400, detail="Invalid verification request")
    except Exception as e:
        logger.error(f"Failed to verify caller ID: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to verify caller ID")


@router.get("/verify/{phone_number:path}", response_model=Optional[dict])
async def get_verification_status(
    request: Request,
    phone_number: str,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """
    Get verification status for a caller ID.

    Returns verification status if the phone number was verified or is pending.
    Returns null if no verification record exists.

    Used by agents to poll verification status without UI interaction.
    """
    try:
        # Validate phone number format
        from apps.backend.services.phone_provisioning import PhoneProvisioningService

        if not PhoneProvisioningService.validate_phone_number(phone_number):
            raise HTTPException(
                status_code=400,
                detail="Phone number must be in E.164 format (e.g., '+14155551234')",
            )

        twilio_client = _twilio_client_for_tenant(tenant_id)
        provisioning_service = PhoneProvisioningService(twilio_client)

        result = await provisioning_service.get_verification_status(phone_number)

        if result is None:
            return None

        return {
            "phone_number": result.phone_number,
            "sid": result.sid,
            "account_sid": result.account_sid,
            "friendly_name": result.friendly_name,
            "date_created": result.date_created,
            "date_verified": result.date_verified,
            "status": "verified" if result.date_verified else "pending",
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get verification status: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to get verification status")


@router.get("/bundles", response_model=list[dict])
async def list_regulatory_bundles(
    request: Request,
    iso_country: str = "US",
    phone_number_type: str = "local",
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """
    List regulatory bundles for a country.

    Regulatory bundles are required for compliance in certain countries (e.g., UAE).
    Returns a list of available bundles with their status.

    Used by agents to find regulatory bundles without UI interaction.
    """
    try:
        twilio_client = _twilio_client_for_tenant(tenant_id)
        provisioning_service = PhoneProvisioningService(twilio_client)

        results = await provisioning_service.list_regulatory_bundles(
            iso_country=iso_country,
            phone_number_type=phone_number_type,
        )

        bundles = [
            {
                "sid": result.sid,
                "account_sid": result.account_sid,
                "friendly_name": result.friendly_name,
                "status": result.status.value,
                "date_created": result.date_created,
                "valid_until": result.valid_until,
                "phone_numbers": result.phone_numbers,
                "iso_country": result.iso_country,
                "ownership_model": result.ownership_model,
            }
            for result in results
        ]
        paged_bundles, _total = paginate_items(bundles, pagination)
        return paged_bundles

    except ValueError as e:
        logger.warning("list_regulatory_bundles validation error: %s", e)
        raise HTTPException(status_code=400, detail="Invalid bundle list parameters")
    except Exception as e:
        logger.error(f"Failed to list regulatory bundles: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to list regulatory bundles")


@router.post("/bundles/attach", response_model=dict)
async def attach_regulatory_bundle(
    request: Request,
    body: AttachBundleRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
):
    """
    Attach a regulatory bundle to a phone number.

    Required for compliance in certain countries (e.g., UAE geographic numbers).
    The bundle must exist and the phone number must be owned by the account.

    Used by agents to attach regulatory bundles without UI interaction.
    """
    try:
        twilio_client = _twilio_client_for_tenant(tenant_id)
        provisioning_service = PhoneProvisioningService(twilio_client)

        result = await provisioning_service.attach_regulatory_bundle(
            phone_number_sid=body.phone_number_sid,
            bundle_sid=body.bundle_sid,
        )

        if result.success:
            return {
                "success": True,
                "phone_number_sid": result.phone_number_sid,
                "bundle_sid": result.bundle_sid,
                "message": result.message,
                "ownership_model": result.ownership_model,
            }
        else:
            return {
                "success": False,
                "phone_number_sid": result.phone_number_sid,
                "bundle_sid": result.bundle_sid,
                "message": result.message,
                "error_code": result.error_code,
                "ownership_model": result.ownership_model,
            }

    except ValueError as e:
        logger.warning("attach_regulatory_bundle validation error: %s", e)
        raise HTTPException(status_code=400, detail="Invalid bundle attachment request")
    except Exception as e:
        logger.error(f"Failed to attach regulatory bundle: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to attach regulatory bundle")
