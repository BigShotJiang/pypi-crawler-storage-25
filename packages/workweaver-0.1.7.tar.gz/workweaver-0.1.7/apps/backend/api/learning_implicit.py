"""Learning Implicit Acceptance API -- UI POST signal + read-only inspector (#2326)."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/learning/implicit", tags=["learning-implicit"])


class ImplicitSignalRequest(BaseModel):
    trace_id: str = Field(..., min_length=26, max_length=26)
    surface: str = Field(..., pattern=r"^(ui|cli|mcp|email)$")
    client_id: str = Field(..., min_length=1)
    consent_token: str = Field(..., min_length=1)
    dwell_ms: int | None = Field(default=None, ge=0)


class ImplicitSignalResponse(BaseModel):
    accepted: bool
    rate_limited: bool = False
    consent_disabled: bool = False


class ImplicitSignalListItem(BaseModel):
    trace_id: str
    surface: str
    observed_at: str
    dwell_ms: int | None
    weight: float
    client_id: str


class ImplicitSignalListResponse(BaseModel):
    items: list[ImplicitSignalListItem]
    count: int


def _get_collector() -> Any:
    from apps.backend.services.learning.implicit_acceptance_collector import ImplicitAcceptanceCollector
    return ImplicitAcceptanceCollector()


@router.post("/ui", response_model=ImplicitSignalResponse)
async def record_ui_signal(body: ImplicitSignalRequest,
                           tenant_id: str = Depends(get_verified_tenant_id)) -> ImplicitSignalResponse:
    collector = _get_collector()
    result = collector.record_signal(
        tenant_id=tenant_id, trace_id=body.trace_id, surface=body.surface,
        client_id=body.client_id, consent_token=body.consent_token, dwell_ms=body.dwell_ms,
    )
    return ImplicitSignalResponse(accepted=result.accepted, rate_limited=result.rate_limited,
                                  consent_disabled=result.consent_disabled)


@router.get("", response_model=ImplicitSignalListResponse)
async def list_signals(limit: int = Query(50, ge=1, le=200),
                       tenant_id: str = Depends(get_verified_tenant_id)) -> ImplicitSignalListResponse:
    collector = _get_collector()
    stored = collector.list_signals(tenant_id=tenant_id, limit=limit)
    items = [ImplicitSignalListItem(
        trace_id=s.trace_id, surface=s.signal.surface, observed_at=s.signal.observed_at,
        dwell_ms=s.signal.dwell_ms, weight=s.signal.weight, client_id=s.signal.client_id,
    ) for s in stored]
    return ImplicitSignalListResponse(items=items, count=len(items))
