"""OKR API — PR-T2.7.

Endpoints:
    POST /api/v1/okr/generate          — auto-generate OKRs from a goal
    GET  /api/v1/okr                    — list OKRs for tenant
    GET  /api/v1/okr/{okr_id}           — get OKR with progress
    PUT  /api/v1/okr/{okr_id}/progress  — update key result progress
    POST /api/v1/okr/{okr_id}/trade-off — run trade-off analysis

Wire: AutonomousOKRService for OKR lifecycle management.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/okr", tags=["okr"])


# ---------------------------------------------------------------------------
# Lazy accessor — keeps import-time boto3 calls out of test collection
# ---------------------------------------------------------------------------


def _get_okr_service(tenant_id: str):
    from apps.backend.services.autonomous_okr import AutonomousOKRService

    svc = AutonomousOKRService(tenant_id=tenant_id)
    return svc


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class GenerateOKRRequest(BaseModel):
    """Request to auto-generate an OKR."""

    goal_id: str | None = Field(None, description="Existing goal ID to derive OKR from")
    objective: str | None = Field(None, description="Objective text (if no goal_id)")


class KeyResultResponse(BaseModel):
    """Key result in an OKR response."""

    kr_id: str
    description: str
    target_value: float
    current_value: float
    unit: str
    assigned_to: str | None
    status: str


class OKRResponse(BaseModel):
    """OKR response with key results and progress."""

    okr_id: str
    tenant_id: str
    objective: str
    key_results: list[KeyResultResponse]
    status: str
    progress_pct: float
    source_goal_id: str | None
    created_at: str


class UpdateProgressRequest(BaseModel):
    """Request to update a key result's progress."""

    kr_id: str = Field(..., description="Key result ID to update")
    current_value: float = Field(..., ge=0, description="New current value")


class TradeoffRequest(BaseModel):
    """Request for trade-off analysis."""

    okr_ids: list[str] = Field(..., min_length=2, description="OKR IDs to analyze")


class TradeoffResponse(BaseModel):
    """Trade-off analysis result."""

    conflicting_okrs: list[str]
    conflict_type: str
    severity: str
    recommendation: str


class DashboardResponse(BaseModel):
    """OKR dashboard summary."""

    total_okrs: int
    overall_progress: float
    by_status: dict[str, int]


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _okr_to_response(okr) -> OKRResponse:
    """Convert an OKR dataclass to response model."""
    return OKRResponse(
        okr_id=okr.okr_id,
        tenant_id=okr.tenant_id,
        objective=okr.objective,
        key_results=[
            KeyResultResponse(
                kr_id=kr.kr_id,
                description=kr.description,
                target_value=kr.target_value,
                current_value=kr.current_value,
                unit=kr.unit,
                assigned_to=kr.assigned_to,
                status=kr.status,
            )
            for kr in okr.key_results
        ],
        status=okr.status.value if hasattr(okr.status, "value") else okr.status,
        progress_pct=okr.progress_pct,
        source_goal_id=okr.source_goal_id,
        created_at=okr.created_at,
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("/generate", response_model=OKRResponse)
async def generate_okr(
    body: GenerateOKRRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> OKRResponse:
    """Auto-generate an OKR from a goal or objective text."""
    svc = _get_okr_service(tenant_id)

    if body.goal_id:
        try:
            okr = svc.create_okr_from_goal(tenant_id, body.goal_id)
        except ValueError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
    elif body.objective:
        # Generate suggested key results for free-text objective
        key_results = svc.suggest_key_results(tenant_id, body.objective)
        import uuid

        from apps.backend.services.autonomous_okr import OKR

        okr_id = f"okr_{uuid.uuid4().hex[:12]}"
        okr = OKR(
            okr_id=okr_id,
            tenant_id=tenant_id,
            objective=body.objective,
            key_results=key_results,
            source_goal_id=None,
        )
        svc._okrs[okr_id] = okr
        svc._persist_okr(tenant_id, okr)
    else:
        raise HTTPException(
            status_code=400,
            detail="Either goal_id or objective must be provided",
        )

    return _okr_to_response(okr)


@router.get("", response_model=DashboardResponse)
async def list_okrs(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> DashboardResponse:
    """List OKRs for tenant as a dashboard summary."""
    svc = _get_okr_service(tenant_id)
    dashboard = svc.get_okr_dashboard(tenant_id)
    return DashboardResponse(**dashboard.model_dump())


@router.get("/{okr_id}", response_model=OKRResponse)
async def get_okr(
    okr_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> OKRResponse:
    """Get a single OKR with current progress."""
    svc = _get_okr_service(tenant_id)
    okr = svc._okrs.get(okr_id)
    if okr is None:
        raise HTTPException(status_code=404, detail=f"OKR {okr_id} not found")

    svc.track_progress(tenant_id, okr_id)
    return _okr_to_response(okr)


@router.put("/{okr_id}/progress", response_model=OKRResponse)
async def update_progress(
    okr_id: str,
    body: UpdateProgressRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> OKRResponse:
    """Update a key result's progress and recalculate OKR progress."""
    svc = _get_okr_service(tenant_id)
    okr = svc._okrs.get(okr_id)
    if okr is None:
        raise HTTPException(status_code=404, detail=f"OKR {okr_id} not found")

    # Find and update the key result
    kr_found = False
    for kr in okr.key_results:
        if kr.kr_id == body.kr_id:
            kr.current_value = body.current_value
            kr_found = True
            break

    if not kr_found:
        raise HTTPException(
            status_code=404,
            detail=f"Key result {body.kr_id} not found in OKR {okr_id}",
        )

    svc.track_progress(tenant_id, okr_id)
    svc._persist_okr(tenant_id, okr)
    return _okr_to_response(okr)


@router.post("/{okr_id}/trade-off", response_model=list[TradeoffResponse])
async def analyze_tradeoffs(
    okr_id: str,
    body: TradeoffRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[TradeoffResponse]:
    """Run trade-off analysis between OKRs."""
    svc = _get_okr_service(tenant_id)

    # Ensure the path OKR is included in analysis
    all_ids = list(set([okr_id] + body.okr_ids))

    tradeoffs = svc.analyze_tradeoffs(tenant_id, all_ids)
    return [
        TradeoffResponse(
            conflicting_okrs=t.conflicting_okrs,
            conflict_type=t.conflict_type,
            severity=t.severity,
            recommendation=t.recommendation,
        )
        for t in tradeoffs
    ]
