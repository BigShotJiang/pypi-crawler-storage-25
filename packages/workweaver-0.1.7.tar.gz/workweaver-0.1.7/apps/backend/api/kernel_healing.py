"""Kernel HEAL ladder REST surface -- issue #3545.

Read-only inspection of recent self-healing recovery incidents,
classified by ``RemediationPosture`` (auto_reversible /
approval_reversible / escalate_irreversible).

Tenant-scoped: every recovery attempt is read from the caller's tenant
mission_run state via :class:`MissionRunStateService`. The supervisor
stamps ``remediation_posture`` + ``heal_class`` into every attempt's
``extra`` metadata at write-time, so this endpoint just projects the
posture-classified view.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends, Query

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.mission_run.state import get_mission_run_state_service

# Re-exported from services for backward compatibility (issue #3785).
from apps.backend.services.healing_actions import (  # noqa: F401
    HealingActionRow,
    HealingActionsResponse,
    collect_recent_healing_actions,
)

router = APIRouter(
    prefix="/api/v1/kernel/healing",
    tags=["kernel", "healing"],
)


@router.get("/recent", response_model=HealingActionsResponse)
def get_recent_healing_actions(
    window_hours: int = Query(default=24, ge=1, le=24 * 30),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> HealingActionsResponse:
    """List recent self-healing actions classified by RemediationPosture (#3545)."""
    service = get_mission_run_state_service()
    return collect_recent_healing_actions(
        tenant_id=tenant_id,
        window_hours=window_hours,
        service=service,
    )
