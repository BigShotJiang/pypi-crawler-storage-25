"""Entities API — RFC D011, Slice 1 (read-only).

Read-only FastAPI router for the Dynamic Entity Registry.

Prefix: /api/v1/entities
Tags: entities

Endpoints in this router:
  GET /api/v1/entities               — list registered schemas for tenant
  GET /api/v1/entities/{entity_name} — describe a single schema

No POST / PUT / DELETE on /api/v1/entities in slice 1.
Schema-aware entity record CRUD lives in apps.backend.api.entity_instances.

Issue: #2179
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, status

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.dynamic_entity_registry import (
    EntityDescriptor,
    get_entity_registry,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/entities", tags=["entities"])


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class EntityListResponse(object):
    """Thin wrapper; FastAPI serialises EntityDescriptor list directly."""


# ---------------------------------------------------------------------------
# GET /api/v1/entities
# ---------------------------------------------------------------------------


@router.get(
    "",
    response_model=list[EntityDescriptor],
    status_code=status.HTTP_200_OK,
    summary="List registered entity schemas",
    description=(
        "Returns all entity schemas registered for the authenticated tenant. "
        "This legacy descriptor router remains read-only; entity record CRUD uses /records routes."
    ),
)
async def list_entities(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[EntityDescriptor]:
    """List all registered entity schemas for the tenant."""
    registry = get_entity_registry()
    entities = registry.list_entities(tenant_id)
    logger.info("entity_list tenant=%s count=%d", tenant_id, len(entities))
    return entities


# ---------------------------------------------------------------------------
# GET /api/v1/entities/{entity_name}
# ---------------------------------------------------------------------------


@router.get(
    "/{entity_name}",
    response_model=EntityDescriptor,
    status_code=status.HTTP_200_OK,
    summary="Describe a registered entity schema",
    description=(
        "Returns the entity schema descriptor for *entity_name* within the "
        "authenticated tenant. Returns 404 if the entity is not registered."
    ),
)
async def describe_entity(
    entity_name: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> EntityDescriptor:
    """Return the descriptor for a single entity schema."""
    registry = get_entity_registry()
    descriptor = registry.describe_entity(tenant_id, entity_name)
    if descriptor is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Entity '{entity_name}' is not registered for this tenant.",
        )
    logger.info("entity_describe tenant=%s entity=%s", tenant_id, entity_name)
    return descriptor
