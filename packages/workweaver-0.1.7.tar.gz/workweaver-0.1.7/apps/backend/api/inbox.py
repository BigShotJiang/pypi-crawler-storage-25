"""
Unified Inbox API

Multi-channel conversations: WhatsApp, email, voice.
Single thread view per contact across channels.

Reference: docs/audit/remediation-plan L4.2
"""

import asyncio
import logging
import os
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from pydantic import BaseModel, Field

from apps.backend.api.pagination import PaginationParams, build_pagination_dependency
from apps.backend.services.thread_service import get_thread_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/inbox", tags=["inbox"])


def _get_thread_service():
    return get_thread_service()


# ==================== Request/Response Models ====================


class SendMessageRequest(BaseModel):
    """Request to send a message in a conversation."""

    body: str = Field(..., min_length=1, max_length=1000, description="Message body text")
    media_url: str | None = Field(None, description="Optional media attachment URL")
    channel: str = Field(default="whatsapp", description="Channel to send on")


class ConversationResponse(BaseModel):
    """Response containing list of conversations."""

    conversations: list[dict[str, Any]]
    total_count: int
    channels: list[str] = Field(default_factory=lambda: ["whatsapp", "email", "voice"])


class ConversationMessagesResponse(BaseModel):
    """Response containing messages in a conversation."""

    messages: list[dict[str, Any]]
    conversation_id: str
    total_count: int
    channel: str = "whatsapp"


class MessageSentResponse(BaseModel):
    """Response after sending a message."""

    sid: str
    status: str
    to: str
    body: str
    conversation_id: str

    replacement: str | None = None  # #1157: UI hint to reach connector send path
    message: str | None = None  # #1157: human-readable reason for not_supported states

class MarkReadResponse(BaseModel):
    """Response after marking conversation as read."""

    success: bool
    conversation_id: str


class UnreadCountResponse(BaseModel):
    """Response with unread message count."""

    unread_count: int
    by_channel: dict[str, int] = Field(default_factory=dict)


def _conversation_summary(thread: dict[str, Any]) -> dict[str, Any]:
    return {
        "conversation_id": thread.get("thread_id", ""),
        "thread_id": thread.get("thread_id", ""),
        "contact": thread.get("contact", ""),
        "subject": thread.get("subject", ""),
        "last_message": thread.get("last_message", ""),
        "last_message_at": thread.get("last_message_at", ""),
        "message_count": thread.get("message_count", 0),
        "channel": thread.get("channel", "email"),
        "unread": thread.get("unread", False),
        "duration_seconds": thread.get("duration_seconds", 0),
        "recording_url": thread.get("recording_url", ""),
    }


# ==================== API Endpoints ====================


@router.get("", response_model=ConversationResponse)
async def list_conversations_endpoint(
    request: Request,
    channel: str = Query(default="all", pattern="^(all|whatsapp|email|voice)$"),
    limit: int | None = None,
    offset: int = 0,
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> dict[str, Any]:
    """List all conversations for the tenant, optionally filtered by channel."""
    tenant_id = getattr(request.state, "tenant_id", None)
    if not tenant_id:
        raise HTTPException(status_code=401, detail="Authentication required")
    resolved_limit = limit if limit is not None else pagination.limit
    resolved_offset = offset if limit is not None else pagination.offset
    return list_conversations(
        tenant_id=tenant_id,
        channel=channel,
        limit=resolved_limit,
        offset=resolved_offset,
    )


@router.get("/conversations", response_model=ConversationResponse)
async def list_conversations_alias_endpoint(
    request: Request,
    channel: str = Query(default="all", pattern="^(all|whatsapp|email|voice)$"),
    limit: int | None = None,
    offset: int = 0,
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> dict[str, Any]:
    """Alias kept for CLI/dashboard route parity."""
    return await list_conversations_endpoint(
        request=request,
        channel=channel,
        limit=limit,
        offset=offset,
        pagination=pagination,
    )


def list_conversations(
    tenant_id: str,
    channel: str = "all",
    limit: int = 50,
    offset: int = 0,
) -> dict[str, Any]:
    """List conversations across channels.

    Args:
        tenant_id: Tenant identifier
        channel: Channel filter — "all", "whatsapp", "email", or "voice"
        limit: Max conversations to return
        offset: Offset into sorted result set

    Returns:
        Dictionary with conversations list, total_count, and active channels
    """
    all_conversations: list[dict[str, Any]] = []
    active_channels: list[str] = []

    fetch_limit = limit + offset + 10  # Over-fetch for merge + pagination

    try:
        threads = _get_thread_service().list_threads(tenant_id=tenant_id, limit=fetch_limit)
    except Exception as exc:
        logger.warning("Failed to fetch canonical threads: %s", exc)
        threads = []

    for thread in threads:
        thread_channel = str(thread.get("channel") or "").strip() or "email"
        if channel != "all" and thread_channel != channel:
            continue
        all_conversations.append(_conversation_summary(thread))
        if thread_channel not in active_channels:
            active_channels.append(thread_channel)

    # Sort by last_message_at descending
    all_conversations.sort(
        key=lambda c: c.get("last_message_at", c.get("created_at", "")),
        reverse=True,
    )

    paged = all_conversations[offset : offset + limit]
    return {
        "conversations": paged,
        "total_count": len(all_conversations),
        "channels": active_channels or ["whatsapp", "email", "voice"],
    }


@router.get("/{conversation_id}/messages", response_model=ConversationMessagesResponse)
async def get_conversation_messages_endpoint(
    request: Request,
    conversation_id: str,
    limit: int = 100,
) -> dict[str, Any]:
    """Get all messages in a conversation (supports whatsapp:, email:, voice: prefixes)."""
    tenant_id = getattr(request.state, "tenant_id", None)
    if not tenant_id:
        raise HTTPException(status_code=401, detail="Authentication required")
    return get_conversation_messages(tenant_id=tenant_id, conversation_id=conversation_id, limit=limit)


def get_conversation_messages(
    tenant_id: str,
    conversation_id: str,
    limit: int = 100,
) -> dict[str, Any]:
    """Get messages for any canonical or legacy thread identifier."""
    try:
        thread_messages = _get_thread_service().list_thread_messages(
            tenant_id=tenant_id,
            identifier=conversation_id,
            limit=limit,
        )

        message_dicts = [
            {
                "sid": item.get("message_id", ""),
                "body": item.get("body", item.get("preview", "")),
                "direction": item.get("direction", "inbound"),
                "status": item.get("status", "delivered"),
                "created_at": item.get("created_at", ""),
                "conversation_id": thread_messages.get("thread_id", ""),
                "channel": item.get("channel", thread_messages.get("channel", "email")),
                "subject": item.get("subject", ""),
                "participant": item.get("participant", ""),
            }
            for item in list(thread_messages.get("messages") or [])
        ]

        return {
            "messages": message_dicts,
            "conversation_id": thread_messages.get("thread_id", conversation_id),
            "total_count": len(message_dicts),
            "channel": thread_messages.get("channel", "email"),
        }

    except Exception as e:
        logger.error("Error getting messages for conversation %s: %s", conversation_id, e)
        raise HTTPException(status_code=500, detail="Failed to get conversation messages")


@router.post("/{conversation_id}/messages", response_model=MessageSentResponse)
async def send_message_endpoint(
    request: Request,
    conversation_id: str,
    message: SendMessageRequest,
) -> dict[str, Any]:
    """Send a message to a conversation."""
    tenant_id = getattr(request.state, "tenant_id", None)
    if not tenant_id:
        raise HTTPException(status_code=401, detail="Authentication required")
    return await _send_message_async(
        tenant_id=tenant_id,
        conversation_id=conversation_id,
        body=message.body,
        media_url=message.media_url,
        channel=message.channel,
    )


def send_message(
    tenant_id: str,
    conversation_id: str,
    body: str,
    media_url: str | None = None,
    channel: str = "whatsapp",
) -> dict[str, Any]:
    """Sync compatibility wrapper for the async message send path."""
    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(
            _send_message_async(
                tenant_id=tenant_id,
                conversation_id=conversation_id,
                body=body,
                media_url=media_url,
                channel=channel,
            )
        )

    raise RuntimeError("send_message() cannot be called from an async context; await _send_message_async() instead")


async def _send_message_async(
    tenant_id: str,
    conversation_id: str,
    body: str,
    media_url: str | None = None,
    channel: str = "whatsapp",
) -> dict[str, Any]:
    """Send a message to a conversation.

    Routes to the appropriate channel based on the channel param or
    canonical thread identity when possible.
    """
    thread = _get_thread_service().resolve_thread(tenant_id=tenant_id, identifier=conversation_id)
    if thread is not None:
        conversation_id = str(thread.get("thread_id") or conversation_id)
        if channel == "whatsapp":
            channel = str(thread.get("channel") or channel)

    if channel == "email":
        # Issue #1157: native email-send from the inbox surface is not wired
        # yet. Route email sends through the Gmail / Outlook connector SDK
        # instead of the legacy inbox path. Until that wiring lands, return
        # a structured "not_supported" response (HTTP 200 + body.status) so
        # the UI hides the CTA cleanly — never a silent-success or a cryptic
        # 500. Callers must use the connector send path
        # (POST /v1/connectors/<provider>/operations/send_message).
        logger.warning(
            "inbox_email_send_not_supported",
            extra={
                "tenant_id": tenant_id,
                "conversation_id": conversation_id,
                "replacement": "/v1/connectors/{gmail|outlook}/operations/send_message",
            },
        )
        return {
            "sid": "",
            "status": "not_supported",
            "to": conversation_id,
            "body": body,
            "conversation_id": conversation_id,
            "replacement": "/v1/connectors/{gmail|outlook}/operations/send_message",
            "message": (
                "Inbox email-send is routed through the native connector SDK "
                "(gmail / outlook). Use the connector send path instead."
            ),
        }

    if channel == "voice":
        logger.info("Voice reply not applicable for conversation %s", conversation_id)
        return {
            "sid": "",
            "status": "not_applicable",
            "to": conversation_id,
            "body": body,
            "conversation_id": conversation_id,
        }

    # Default: WhatsApp (backward compatible)
    try:
        customer_number = ""
        if thread is not None:
            customer_number = str(thread.get("contact") or "").replace("whatsapp:", "").strip()
        if not customer_number:
            raise HTTPException(
                status_code=400,
                detail=f"Unknown canonical thread: {conversation_id}",
            )
        to_number = f"whatsapp:{customer_number}"

        from apps.backend.services.channels.whatsapp.service import get_whatsapp_service

        service = get_whatsapp_service()
        from_number = os.environ.get("TWILIO_WHATSAPP_NUMBER", "")
        # send_message is async but we're in a sync helper — callers use the
        # async endpoint which awaits the send_message_endpoint.  Keep the
        # result dict construction safe for both sync and async paths.
        result = await service.send_message(
            to_number=to_number,
            from_number=f"whatsapp:{from_number}" if from_number else "",
            content=body,
            media_url=media_url,
            tenant_id=tenant_id,
        )
        if not getattr(result, "success", False):
            error_code = getattr(result, "error_code", None) or "WHATSAPP_SEND_FAILED"
            error_message = getattr(result, "error_message", None) or "WhatsApp send failed"
            status_code = 403 if error_code == "OUTBOUND_COMPLIANCE_BLOCKED" else 502
            logger.warning(
                "inbox_whatsapp_send_failed",
                extra={
                    "tenant_id": tenant_id,
                    "conversation_id": conversation_id,
                    "error_code": error_code,
                },
            )
            raise HTTPException(
                status_code=status_code,
                detail={
                    "error": error_code,
                    "message": error_message,
                    "conversation_id": conversation_id,
                },
            )
        message_sid = getattr(result, "message_sid", "") or ""
        account_sid = getattr(result, "account_sid", "") or os.environ.get("TWILIO_ACCOUNT_SID", "")
        message_status = getattr(result, "status", "queued") or "queued"
        source_ref = str(thread.get("source_ref") or "").strip() if thread is not None else ""
        if source_ref and message_sid and account_sid:
            try:
                from apps.backend.services.channels.whatsapp.handler import WhatsAppHandler

                await WhatsAppHandler(tenant_id).store_outbound_message(
                    message_sid=message_sid,
                    account_sid=account_sid,
                    from_number=f"whatsapp:{from_number}" if from_number else "",
                    to_number=to_number,
                    body=body,
                    media_url=media_url,
                    conversation_id=source_ref,
                )
            except Exception:
                logger.error(
                    "WhatsApp send succeeded but outbound persistence failed tenant=%s thread=%s sid=%s",
                    tenant_id,
                    conversation_id,
                    message_sid,
                    exc_info=True,
                )

        return {
            "sid": message_sid,
            "status": message_status,
            "to": to_number,
            "body": body,
            "conversation_id": conversation_id,
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error sending message to conversation %s: %s", conversation_id, e)
        raise HTTPException(status_code=500, detail="Failed to send message")


@router.post("/{conversation_id}/read", response_model=MarkReadResponse)
async def mark_conversation_read_endpoint(
    request: Request,
    conversation_id: str,
) -> dict[str, Any]:
    """Mark all messages in a conversation as read."""
    tenant_id = getattr(request.state, "tenant_id", None)
    if not tenant_id:
        raise HTTPException(status_code=401, detail="Authentication required")
    return mark_conversation_read(tenant_id=tenant_id, conversation_id=conversation_id)


def mark_conversation_read(
    tenant_id: str,
    conversation_id: str,
) -> dict[str, Any]:
    """Mark all messages in a conversation as read.

    Voice conversations are considered always-read.
    """
    try:
        result = _get_thread_service().mark_thread_read(conversation_id, tenant_id=tenant_id)
        success = bool(result.get("success", True))

        if not success:
            raise HTTPException(
                status_code=404,
                detail=f"Conversation not found: {conversation_id}",
            )

        return {"success": True, "conversation_id": conversation_id}

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error marking conversation %s as read: %s", conversation_id, e)
        raise HTTPException(status_code=500, detail="Failed to mark conversation as read")


@router.get("/unread-count", response_model=UnreadCountResponse)
async def get_unread_count_endpoint(
    request: Request,
) -> dict[str, Any]:
    """Get count of unread messages for the tenant, broken down by channel."""
    tenant_id = getattr(request.state, "tenant_id", None)
    if not tenant_id:
        raise HTTPException(status_code=401, detail="Authentication required")
    return get_unread_count(tenant_id=tenant_id)


def get_unread_count(
    tenant_id: str,
) -> dict[str, Any]:
    """Get total unread count aggregated across channels with per-channel breakdown."""
    by_channel: dict[str, int] = {"whatsapp": 0, "email": 0, "voice": 0}
    try:
        threads = _get_thread_service().list_threads(tenant_id=tenant_id, limit=200)
        for thread in threads:
            channel = str(thread.get("channel") or "").strip() or "email"
            if channel not in by_channel:
                by_channel[channel] = 0
            if thread.get("unread", False):
                by_channel[channel] += 1
    except Exception as exc:
        logger.warning("Failed to get unread counts from canonical threads: %s", exc)

    total = sum(by_channel.values())
    return {
        "unread_count": total,
        "by_channel": by_channel,
    }
