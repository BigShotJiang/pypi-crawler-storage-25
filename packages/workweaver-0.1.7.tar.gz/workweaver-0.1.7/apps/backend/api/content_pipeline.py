"""Content orchestration API (newsletter, CRM sync, health).

Ghost endpoints (POST /content/drafts/ghost, POST /content/events/ghost) were
removed 2026-04-08 (issue #800 / N1 phase 2). Ghost RDS/EFS/ECS were destroyed
in the cost rationalization sprint and the markdown blog system at apps/blog/
replaces them. Newsletter dispatch from markdown post HTML is wired by #790.
"""

from __future__ import annotations

import json
import logging
from typing import Any

from fastapi import APIRouter, Depends, Header, HTTPException, Request, status
from pydantic import BaseModel, Field

from apps.backend.api.rate_limit import limiter
from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.webhooks._shared import compare_webhook_secret, resolve_configured_value

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1", tags=["content-pipeline"])


# GhostDraftRequest, GhostDraftResponse, GhostEventResponse removed 2026-04-08
# (issue #800 / N1 phase 2). Ghost stack was destroyed in the cost
# rationalization sprint.


class NewsletterCampaignRequest(BaseModel):
    campaign_id: str | None = None
    title: str = Field(..., min_length=1)
    subject: str | None = None
    content_post_id: str | None = None
    content_html: str | None = None
    content_text: str | None = None
    audience_segment: str = "all"
    metadata: dict[str, Any] = Field(default_factory=dict)


# #790: newsletter dispatch from a markdown post rendered into S3
class BlogNewsletterDispatchRequest(BaseModel):
    """Request body for POST /api/v1/blog/{slug}/dispatch-newsletter."""

    preview_to: str | None = Field(
        default=None,
        description=(
            "If set, SES sends a single preview email to this address (bypasses "
            "the subscriber list). Use before broadcast to verify rendering."
        ),
    )
    confirm_broadcast: bool = Field(
        default=False,
        description=(
            "If true, broadcast to all active subscribers. Must be explicit — "
            "preview_to and confirm_broadcast are mutually exclusive."
        ),
    )
    s3_bucket: str | None = Field(
        default=None,
        description="Override the default blog bucket (defaults to WORKWEAVER_BLOG_BUCKET env)",
    )


class BlogNewsletterDispatchResponse(BaseModel):
    tenant_id: str
    campaign_id: str
    title: str
    source: str
    post_slug: str
    preview_sent: bool = False
    broadcast_sent: bool = False
    preview_recipient: str | None = None
    preview_error: str | None = None
    status: str | None = None
    metrics: dict[str, Any] | None = None
    errors: list[dict[str, Any]] | None = None


# #791: subscribe form — public endpoints
class BlogSubscribeRequest(BaseModel):
    email: str = Field(..., max_length=320)
    source: str = Field(default="landing", max_length=80)
    # Honeypot: the form includes a hidden "website" field. Real users leave
    # it empty; naive scrapers fill it. Populated honeypot = drop silently.
    website: str | None = Field(default=None, max_length=320)


class BlogSubscribeResponse(BaseModel):
    tenant_id: str
    status: str
    email_hash: str | None = None
    confirmation_sent: bool | None = None
    reason: str | None = None


class BlogConfirmResponse(BaseModel):
    tenant_id: str
    status: str
    email_hash: str | None = None
    crm_sync: dict[str, Any] | None = None


class NewsletterCampaignResponse(BaseModel):
    tenant_id: str
    campaign_id: str
    title: str
    subject: str
    status: str
    updated_at: str


class NewsletterSendRequest(BaseModel):
    dry_run: bool = False


class NewsletterSendResponse(BaseModel):
    tenant_id: str
    campaign_id: str
    status: str
    metrics: dict[str, Any]
    errors: list[dict[str, Any]] = Field(default_factory=list)


class SubscriberSyncRecord(BaseModel):
    email: str
    consent_email: bool = False
    source: str = "manual"
    tags: list[str] = Field(default_factory=list)
    status: str = "active"
    metadata: dict[str, Any] = Field(default_factory=dict)


class SubscriberSyncRequest(BaseModel):
    subscribers: list[SubscriberSyncRecord] = Field(..., min_length=1)


class SubscriberSyncResponse(BaseModel):
    tenant_id: str
    created: int
    updated: int
    failed: int
    errors: list[dict[str, Any]] = Field(default_factory=list)


class NewsletterFeedbackResponse(BaseModel):
    tenant_id: str
    event_id: str
    notification_type: str
    duplicate: bool
    updated: int
    updates: list[dict[str, Any]] = Field(default_factory=list)


class CRMSyncRequest(BaseModel):
    event_id: str | None = None
    email: str
    company: str | None = None
    name: str | None = None
    lifecycle_stage: str = "subscriber"
    source: str = "content_pipeline"
    engagement: dict[str, Any] = Field(default_factory=dict)
    metadata: dict[str, Any] = Field(default_factory=dict)
    idempotency_key: str | None = None


class CRMSyncResponse(BaseModel):
    tenant_id: str
    duplicate: bool
    idempotency_key: str
    event_id: str | None = None
    status: str
    provider_result: dict[str, Any] = Field(default_factory=dict)


class PipelineHealthResponse(BaseModel):
    tenant_id: str
    status: str
    counts: dict[str, int]
    pipeline: dict[str, Any]


def _get_service():
    from apps.backend.services.content.service import get_content_orchestrator_service

    return get_content_orchestrator_service()


def _detail_from_exc(exc: Exception) -> str:
    text = str(exc).strip()
    return text or exc.__class__.__name__


def _resolve_content_webhook_tenant(request: Request) -> str:
    tenant_id = resolve_configured_value(
        request,
        state_attr="content_webhook_tenant_id",
        env_names=("CONTENT_WEBHOOK_TENANT_ID", "CONTENT_PIPELINE_DEFAULT_TENANT_ID"),
    )
    if tenant_id:
        return tenant_id
    raise HTTPException(status_code=status.HTTP_503_SERVICE_UNAVAILABLE, detail="Content webhook tenant not configured")


def _resolve_content_webhook_token(request: Request) -> str:
    return resolve_configured_value(
        request,
        state_attr="content_webhook_token",
        env_names=("CONTENT_WEBHOOK_TOKEN",),
    )


# Ghost endpoints retired 2026-04-08 (issue #800 / N1 phase 2). Both routes
# return HTTP 410 Gone for any caller still pointing at them, so we get a
# loud-but-graceful failure mode rather than a 500 from a missing handler.


@router.post("/content/drafts/ghost", status_code=status.HTTP_410_GONE, deprecated=True)
async def _ghost_draft_gone() -> None:
    raise HTTPException(
        status_code=status.HTTP_410_GONE,
        detail=(
            "Ghost draft endpoint retired 2026-04-08 (issue #800). "
            "The markdown blog system at apps/blog/ replaces it. "
            "See docs/PRODUCT.md for the new workflow."
        ),
    )


@router.post("/content/events/ghost", status_code=status.HTTP_410_GONE, deprecated=True)
async def _ghost_webhook_gone() -> None:
    raise HTTPException(
        status_code=status.HTTP_410_GONE,
        detail=(
            "Ghost webhook endpoint retired 2026-04-08 (issue #800). "
            "Ghost RDS/EFS/ECS were destroyed in the cost rationalization sprint."
        ),
    )


@router.post(
    "/newsletter/campaigns",
    response_model=NewsletterCampaignResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_newsletter_campaign(
    payload: NewsletterCampaignRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> NewsletterCampaignResponse:
    service = _get_service()
    try:
        result = await service.create_newsletter_campaign(
            tenant_id=tenant_id,
            campaign_id=payload.campaign_id,
            title=payload.title,
            subject=payload.subject,
            content_post_id=payload.content_post_id,
            content_html=payload.content_html,
            content_text=payload.content_text,
            audience_segment=payload.audience_segment,
            metadata=payload.metadata,
        )
        return NewsletterCampaignResponse(**result)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=_detail_from_exc(exc)) from exc
    except Exception:
        logger.exception("content_pipeline.create_newsletter_campaign_failed")
        raise HTTPException(status_code=500, detail="Failed to create newsletter campaign")


@router.post(
    "/newsletter/campaigns/{campaign_id}/send",
    response_model=NewsletterSendResponse,
)
async def send_newsletter_campaign(
    campaign_id: str,
    payload: NewsletterSendRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> NewsletterSendResponse:
    service = _get_service()
    try:
        result = await service.send_newsletter_campaign(
            tenant_id=tenant_id,
            campaign_id=campaign_id,
            dry_run=payload.dry_run,
        )
        return NewsletterSendResponse(**result)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=_detail_from_exc(exc)) from exc
    except Exception:
        logger.exception("content_pipeline.send_newsletter_campaign_failed")
        raise HTTPException(status_code=500, detail="Failed to send newsletter campaign")


@router.post(
    "/blog/{slug}/dispatch-newsletter",
    response_model=BlogNewsletterDispatchResponse,
)
async def dispatch_blog_newsletter(
    slug: str,
    payload: BlogNewsletterDispatchRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> BlogNewsletterDispatchResponse:
    """#790: dispatch a newsletter from a markdown post rendered into S3.

    Three modes (mutually exclusive):
      - preview: sends a single email to payload.preview_to (pre-flight check)
      - broadcast: sends to all active subscribers (requires confirm_broadcast=true)
      - dry_run: neither preview_to nor confirm_broadcast set — just prepares
        the campaign row without sending anything

    The CLI wrapper (scripts/blog/send-newsletter.sh) defaults to preview mode
    and requires a second run with --confirm to broadcast.
    """
    # Validate mutual exclusivity at the API boundary so the CLI can rely on
    # a clean error shape.
    if payload.preview_to and payload.confirm_broadcast:
        raise HTTPException(
            status_code=400,
            detail="preview_to and confirm_broadcast are mutually exclusive — pick one.",
        )

    service = _get_service()
    try:
        result = await service.dispatch_newsletter_from_markdown_post(
            tenant_id=tenant_id,
            post_slug=slug,
            s3_bucket=payload.s3_bucket,
            preview_to=payload.preview_to,
            confirm_broadcast=payload.confirm_broadcast,
        )
        return BlogNewsletterDispatchResponse(**result)
    except ValueError as exc:
        # Differentiates "post not in S3" (404) from bad input (400).
        message = str(exc).lower()
        if "not found" in message:
            raise HTTPException(status_code=404, detail=_detail_from_exc(exc)) from exc
        raise HTTPException(status_code=400, detail=_detail_from_exc(exc)) from exc
    except Exception:
        logger.exception("content_pipeline.dispatch_blog_newsletter_failed")
        raise HTTPException(status_code=500, detail="Failed to dispatch blog newsletter")


# ----------------------------------------------------------------------------
# #791: subscribe form flow (public endpoints, no tenant auth)
# ----------------------------------------------------------------------------
# These routes are called from the public landing page. Tenant defaults to
# the content_pipeline default tenant (TENANT#public). Rate limited.


@router.post(
    "/blog/subscribe",
    response_model=BlogSubscribeResponse,
    status_code=status.HTTP_200_OK,
)
@limiter.limit("5/minute")
async def blog_subscribe(
    request: Request,
    payload: BlogSubscribeRequest,
) -> BlogSubscribeResponse:
    """#791: public form submission — starts the double-opt-in flow.

    Always returns 200 regardless of the underlying status so scrapers can't
    enumerate valid/invalid emails or detect the honeypot trap.
    """
    service = _get_service()
    tenant_id = getattr(getattr(request.app, "state", None), "content_webhook_tenant_id", None) or "TENANT#public"
    try:
        result = await service.add_subscriber(
            tenant_id=tenant_id,
            email=payload.email,
            source=payload.source,
            honeypot=payload.website,
        )
        return BlogSubscribeResponse(**result)
    except ValueError as exc:
        # Return 200 with status=invalid so form submits don't leak valid/invalid
        # email enumeration. The detail is logged server-side.
        logger.info("blog_subscribe_rejected: %s", exc)
        return BlogSubscribeResponse(
            tenant_id=tenant_id,
            status="invalid",
            reason=str(exc)[:200],
        )
    except Exception:
        logger.exception("content_pipeline.blog_subscribe_failed")
        raise HTTPException(status_code=500, detail="Failed to process subscribe request")


@router.get(
    "/blog/confirm",
    response_model=BlogConfirmResponse,
)
async def blog_confirm(
    request: Request,
    token: str,
) -> BlogConfirmResponse:
    """#791: user clicks the confirmation link from the SES email.

    Returns JSON — the landing static page at /blog/subscribed/ can parse
    the URL ?token= param, call this endpoint via fetch, then render the
    confirmation screen. This separates the GET-link side effect from the
    page rendering.
    """
    service = _get_service()
    tenant_id = getattr(getattr(request.app, "state", None), "content_webhook_tenant_id", None) or "TENANT#public"
    try:
        result = await service.confirm_subscriber(tenant_id=tenant_id, token=token)
        return BlogConfirmResponse(**result)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=_detail_from_exc(exc)) from exc
    except Exception:
        logger.exception("content_pipeline.blog_confirm_failed")
        raise HTTPException(status_code=500, detail="Failed to confirm subscription")


@router.post(
    "/newsletter/subscribers/sync",
    response_model=SubscriberSyncResponse,
)
async def sync_subscribers(
    payload: SubscriberSyncRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SubscriberSyncResponse:
    service = _get_service()
    try:
        result = await service.sync_subscribers(
            tenant_id=tenant_id,
            subscribers=[row.model_dump() for row in payload.subscribers],
        )
        return SubscriberSyncResponse(**result)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=_detail_from_exc(exc)) from exc
    except Exception:
        logger.exception("content_pipeline.sync_subscribers_failed")
        raise HTTPException(status_code=500, detail="Failed to sync subscribers")


@router.post(
    "/newsletter/events/ses",
    response_model=NewsletterFeedbackResponse,
)
@limiter.limit("30/minute")
async def ingest_newsletter_feedback(
    request: Request,
    x_webhook_token: str | None = Header(default=None, alias="x-webhook-token"),
    x_idempotency_key: str | None = Header(default=None, alias="x-idempotency-key"),
) -> NewsletterFeedbackResponse:
    service = _get_service()
    try:
        expected_token = _resolve_content_webhook_token(request)
        if not expected_token:
            raise HTTPException(status_code=503, detail="Content webhook token not configured")
        if not compare_webhook_secret(x_webhook_token, expected_token):
            raise HTTPException(status_code=401, detail="Invalid webhook token")

        tenant_id = _resolve_content_webhook_tenant(request)

        raw_body = await request.body()
        envelope = json.loads(raw_body.decode("utf-8")) if raw_body else {}
        if not isinstance(envelope, dict):
            raise HTTPException(status_code=400, detail="Invalid JSON payload")

        payload_data: dict[str, Any] = envelope
        if str(envelope.get("Type") or "").strip() == "SubscriptionConfirmation":
            return NewsletterFeedbackResponse(
                tenant_id=tenant_id,
                event_id="sns-subscription-confirmation",
                notification_type="subscription_confirmation",
                duplicate=False,
                updated=0,
                updates=[],
            )
        if isinstance(envelope.get("Message"), str) and envelope["Message"].strip():
            try:
                nested = json.loads(envelope["Message"])
                if isinstance(nested, dict):
                    payload_data = nested
            except json.JSONDecodeError:
                payload_data = envelope

        idempotency_key_raw = str(
            x_idempotency_key
            or payload_data.get("idempotency_key")
            or payload_data.get("event_id")
            or envelope.get("MessageId")
            or ""
        ).strip()
        idempotency_key = idempotency_key_raw or None

        result = await service.ingest_newsletter_feedback(
            tenant_id=tenant_id,
            payload=payload_data,
            idempotency_key=idempotency_key,
        )
        return NewsletterFeedbackResponse(**result)
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=_detail_from_exc(exc)) from exc
    except Exception:
        logger.exception("content_pipeline.ingest_newsletter_feedback_failed")
        raise HTTPException(status_code=500, detail="Failed to ingest newsletter feedback")


@router.post(
    "/content/sync/crm",
    response_model=CRMSyncResponse,
)
async def sync_content_to_crm(
    payload: CRMSyncRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CRMSyncResponse:
    service = _get_service()
    body = payload.model_dump()
    body["event_id"] = body.get("event_id") or None

    try:
        result = await service.sync_content_to_crm(
            tenant_id=tenant_id,
            payload=body,
            idempotency_key=payload.idempotency_key,
        )
        return CRMSyncResponse(**result)
    except RuntimeError as exc:
        raise HTTPException(status_code=502, detail=_detail_from_exc(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=_detail_from_exc(exc)) from exc
    except Exception:
        logger.exception("content_pipeline.sync_content_to_crm_failed")
        raise HTTPException(status_code=500, detail="Failed to sync content to CRM")


@router.get(
    "/content/pipeline/health",
    response_model=PipelineHealthResponse,
)
async def get_pipeline_health(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PipelineHealthResponse:
    service = _get_service()
    try:
        result = await service.pipeline_health(tenant_id=tenant_id)
        return PipelineHealthResponse(**result)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=_detail_from_exc(exc)) from exc
    except Exception:
        logger.exception("content_pipeline.pipeline_health_failed")
        raise HTTPException(status_code=500, detail="Failed to load content pipeline health")
