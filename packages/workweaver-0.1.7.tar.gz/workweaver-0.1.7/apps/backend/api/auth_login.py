"""Authentication login and tenant/user query endpoints.

Extracted from auth.py (Phase 5 tech debt reduction).
"""

import base64
import json
import logging
import os
from datetime import UTC, datetime
from typing import Any
from urllib.parse import quote, urlencode

import jwt
import ulid
from fastapi import APIRouter, HTTPException, Request, Response, status
from fastapi.responses import JSONResponse

from apps.backend.api.auth_runtime_state import (
    _browser_session_claims_from_cookie,
    _resolve_authenticated_request_identity,
    router as auth_runtime_state_router,
)
from apps.backend.api.auth_models import (
    CLIAuthCompleteRequest,
    CLIAuthCompleteResponse,
    CLIDeviceAuthPollRequest,
    CLIDeviceAuthPollResponse,
    CLIDeviceAuthStartRequest,
    CLIDeviceAuthStartResponse,
    CLIAuthExchangeRequest,
    CLIAuthStartRequest,
    CLIAuthStartResponse,
    CLIPendingLoginRequest,
    CLIPendingLoginResponse,
    LoginChallengeRequest,
    LoginChallengeResponse,
    LoginRequest,
    LoginResponse,
)
from apps.backend.api.auth_signup_shared import (
    CLI_AUTH_CODE_TTL_SECONDS,
    PUBLIC_WEB_ORIGIN_FALLBACK,
    _resolve_oauth_login_start,
    get_auth_signup_facade,
)
from apps.backend.api.auth_helpers import (
    BROWSER_SESSION_COOKIE_NAMES as _BROWSER_SESSION_COOKIE_NAMES,
    _disable_cognito,
    _redact_email,
    _require_cognito_idp,
    _set_browser_session_cookie,
    _set_runtime_provisioning_cookie,
)
from apps.backend.services.session.browser_session import (
    BrowserSessionClaims,
    BrowserSessionTokenError,
    mint_cli_auth_code,
    mint_cli_session_token,
    verify_cli_auth_code,
    verify_pkce_code_verifier,
)
from apps.backend.services.cli_login_bridge import (
    InvalidCLILoginPollToken,
    create_cli_login_attempt,
    get_cli_login_attempt,
    publish_cli_login_result,
    read_cli_login_result,
)
from apps.backend.config.secrets import get_secret
from apps.backend.providers.identity_provider import IdentityProviderError, get_identity_provider
from apps.backend.providers.oidc_provider import OIDCIdentityProvider, OIDCProviderConfig

BROWSER_SESSION_COOKIE_NAMES = _BROWSER_SESSION_COOKIE_NAMES

from apps.backend.api.rate_limit import limiter
from apps.backend.services.auth_identity_contract import load_auth_identity_contract

logger = logging.getLogger(__name__)

router = APIRouter()
router.include_router(auth_runtime_state_router)
_LOGIN_CHALLENGE_ALIASES = {"SOFTWARE_TOKEN_SETUP": "MFA_SETUP"}
_SUPPORTED_LOGIN_CHALLENGES = {"MFA_SETUP", "SOFTWARE_TOKEN_MFA"}
_UNSUPPORTED_LOGIN_CHALLENGES = {"SMS_MFA"}
_AUTH_CHALLENGE_TTL_SECONDS = 10 * 60
_CLI_OAUTH_SESSION_TTL_SECONDS = 30 * 24 * 60 * 60
_CLI_LOGIN_START_TTL_SECONDS = 10 * 60


def get_tenant_provisioning_service():
    from apps.backend.services.tenant_provisioning import (
        get_tenant_provisioning_service as _service_factory,
    )

    return _service_factory()


@router.get("/contract")
async def get_auth_identity_contract() -> JSONResponse:
    """Frozen auth/identity capability contract (issue #1322)."""
    return JSONResponse(content=load_auth_identity_contract())


def _decode_unverified_jwt_claims(token: str) -> dict[str, Any]:
    """Best-effort JWT payload decode without signature verification."""
    raw = str(token or "").strip()
    if not raw or "." not in raw:
        return {}

    parts = raw.split(".")
    if len(parts) < 2:
        return {}

    payload = parts[1]
    padded = payload + "=" * (-len(payload) % 4)
    try:
        decoded = base64.urlsafe_b64decode(padded.encode("utf-8")).decode("utf-8")
        data = json.loads(decoded)
    except Exception:
        return {}

    return data if isinstance(data, dict) else {}


def _provider_login_enabled(provider: str) -> bool:
    facade = get_auth_signup_facade()
    provider_key = str(provider or "").strip().lower()
    if provider_key == "google":
        return bool(getattr(facade, "GOOGLE_SIGNUP_ENABLED", False))
    if provider_key == "microsoft":
        return bool(getattr(facade, "MICROSOFT_SIGNUP_ENABLED", False))
    if provider_key == "oidc":
        return OIDCProviderConfig.from_env() is not None
    if provider_key == "zoho":
        return bool(getattr(facade, "ZOHO_SIGNUP_ENABLED", False))
    return False


def _build_cli_browser_login_url(
    *,
    return_to_origin: str,
    client_state: str,
    code_challenge: str,
    code_challenge_method: str,
    provider: str | None = None,
) -> str:
    params: dict[str, str] = {
        "client": "cli",
        "client_state": client_state,
        "code_challenge": code_challenge,
        "code_challenge_method": code_challenge_method,
        # Force browsers and intermediaries to fetch the current auth shell for
        # each short-lived CLI exchange instead of reusing an old /login view.
        "ww_cli_login": client_state,
    }
    if provider:
        params["provider"] = provider
    return f"{return_to_origin.rstrip('/')}/login?{urlencode(params)}"


def _resolve_identity_from_auth_tokens(
    *,
    id_token: str,
    access_token: str,
    fallback_email: str,
) -> tuple[str, str]:
    """Resolve user identity from Cognito-issued JWT claims without an extra network hop."""
    normalized_fallback_email = str(fallback_email or "").strip().lower()
    for token in (id_token, access_token):
        claims = _decode_unverified_jwt_claims(token)
        if not claims:
            continue
        user_id = str(
            claims.get("sub") or claims.get("cognito:username") or claims.get("username") or "",
        ).strip()
        email = str(claims.get("email") or normalized_fallback_email).strip().lower()
        if user_id or email:
            return user_id, email
    return "", normalized_fallback_email


def _resolve_oidc_linked_tenant_record_id(*, tenant_id: str, user_id: str) -> str:
    """Resolve only subject-linked tenants for OIDC CLI login.

    Device-code login must never recover a tenant purely by email because that
    would recreate a side-channel account-linking path outside the first-party
    signup/login surfaces.
    """
    normalized_user_id = str(user_id or "").strip()
    if not normalized_user_id:
        return ""

    provisioning_service = get_tenant_provisioning_service()
    tenant = provisioning_service.get_tenant_by_owner(normalized_user_id, product="workweaver")
    if not tenant:
        tenant = provisioning_service.get_tenant_by_owner(normalized_user_id, product=None)
    resolved = str((tenant or {}).get("tenant_id") or "").strip()
    if resolved:
        return resolved if resolved.startswith("TENANT#") else f"TENANT#{resolved}"

    normalized_tenant_id = str(tenant_id or "").strip()
    if not normalized_tenant_id:
        return ""
    candidate_tenant_id = (
        normalized_tenant_id if normalized_tenant_id.startswith("TENANT#") else f"TENANT#{normalized_tenant_id}"
    )
    linked_user = provisioning_service.get_user(candidate_tenant_id, normalized_user_id)
    return candidate_tenant_id if linked_user is not None else ""


def _normalize_cli_auth_provider(provider: str | None) -> str:
    normalized = str(provider or "").strip().lower()
    if normalized in {"email", "password"}:
        return "email_password"
    if normalized in {"email_password", "google", "microsoft", "oidc", "zoho"}:
        return normalized
    return "email_password"


def _canonical_login_challenge_name(challenge_name: str) -> str:
    normalized = str(challenge_name or "").strip()
    if not normalized:
        return ""
    return _LOGIN_CHALLENGE_ALIASES.get(normalized, normalized)


def _auth_challenge_secret() -> str:
    candidates = [
        os.getenv("JWT_SECRET", "").strip(),
        (get_secret("jwt/secret") or "").strip(),
        (get_secret("jwt/secret", "prod") or "").strip(),
    ]
    for candidate in candidates:
        if candidate:
            return candidate
    raise HTTPException(
        status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
        detail={
            "error": "auth_challenge_unavailable",
            "message": "Authentication challenge service is not available. Please try again.",
        },
    )


def _mint_auth_challenge_token(*, email: str, challenge_name: str, session: str, ttl_seconds: int) -> str:
    canonical_challenge = _canonical_login_challenge_name(challenge_name)
    payload = {
        "purpose": "auth_challenge",
        "email": str(email or "").strip().lower(),
        "challenge_name": canonical_challenge,
        "session": str(session or "").strip(),
        "exp": int(datetime.now(UTC).timestamp()) + int(ttl_seconds),
    }
    encoded = jwt.encode(payload, _auth_challenge_secret(), algorithm="HS256")
    return encoded.decode("utf-8") if isinstance(encoded, bytes) else str(encoded)


def _verify_auth_challenge_token(token: str) -> dict[str, str]:
    try:
        payload = jwt.decode(str(token or "").strip(), _auth_challenge_secret(), algorithms=["HS256"])
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "error": "invalid_auth_challenge",
                "message": "Authentication challenge expired or is invalid. Please sign in again.",
            },
        ) from exc

    if not isinstance(payload, dict):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "error": "invalid_auth_challenge",
                "message": "Authentication challenge expired or is invalid. Please sign in again.",
            },
        )

    challenge_name = _canonical_login_challenge_name(payload.get("challenge_name") or "")
    email = str(payload.get("email") or "").strip().lower()
    session = str(payload.get("session") or "").strip()
    if challenge_name not in _SUPPORTED_LOGIN_CHALLENGES or not email or not session:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "error": "invalid_auth_challenge",
                "message": "Authentication challenge expired or is invalid. Please sign in again.",
            },
        )
    return {"challenge_name": challenge_name, "email": email, "session": session}


def _build_totp_setup_uri(*, email: str, secret_code: str) -> str:
    account_name = quote(str(email or "").strip().lower(), safe="")
    issuer = quote("Workweaver", safe="")
    secret = quote(str(secret_code or "").strip().upper(), safe="")
    return f"otpauth://totp/{issuer}:{account_name}?secret={secret}&issuer={issuer}"


def _build_login_challenge_response(
    *,
    email: str,
    challenge_name: str,
    session: str,
    secret_code: str = "",
) -> JSONResponse:
    normalized_email = str(email or "").strip().lower()
    normalized_challenge = _canonical_login_challenge_name(challenge_name)
    normalized_session = str(session or "").strip()
    if normalized_challenge not in _SUPPORTED_LOGIN_CHALLENGES or not normalized_email or not normalized_session:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "auth_challenge_unavailable",
                "message": "Authentication challenge service is not available. Please try again.",
            },
        )

    payload = LoginChallengeResponse(
        challenge_name=normalized_challenge,  # type: ignore[arg-type]
        challenge_token=_mint_auth_challenge_token(
            email=normalized_email,
            challenge_name=normalized_challenge,
            session=normalized_session,
            ttl_seconds=_AUTH_CHALLENGE_TTL_SECONDS,
        ),
        email=normalized_email,
        expires_in=_AUTH_CHALLENGE_TTL_SECONDS,
        message=(
            "Set up an authenticator app to finish signing in."
            if normalized_challenge == "MFA_SETUP"
            else "Enter the 6-digit code from your authenticator app."
        ),
        secret_code=str(secret_code or "").strip().upper() or None,
        otpauth_uri=(
            _build_totp_setup_uri(email=normalized_email, secret_code=secret_code)
            if normalized_challenge == "MFA_SETUP" and str(secret_code or "").strip()
            else None
        ),
    )
    return JSONResponse(status_code=status.HTTP_202_ACCEPTED, content=payload.model_dump(exclude_none=True))


def _handle_login_auth_response(
    *,
    auth_response: dict[str, Any],
    cognito_idp: Any,
    normalized_email: str,
) -> JSONResponse:
    challenge_name = _canonical_login_challenge_name(auth_response.get("ChallengeName") or "")
    if not challenge_name:
        return _build_login_success_response(
            authentication_result=auth_response.get("AuthenticationResult", {}),
            fallback_email=normalized_email,
        )

    if challenge_name in _UNSUPPORTED_LOGIN_CHALLENGES:
        logger.warning(
            "Unsupported Cognito auth challenge %s for %s",
            challenge_name,
            _redact_email(normalized_email),
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "error": "auth_challenge_unsupported",
                "message": "SMS/mobile OTP is not supported. Use an authenticator app TOTP challenge instead.",
                "challenge_name": challenge_name,
            },
        )

    if challenge_name == "MFA_SETUP":
        challenge_session = str(auth_response.get("Session") or "").strip()
        if not challenge_session:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail={
                    "error": "auth_challenge_required",
                    "message": "Additional authentication challenge required for this account.",
                    "challenge_name": challenge_name,
                },
            )
        associate_response = cognito_idp.associate_software_token(Session=challenge_session)
        secret_code = str(associate_response.get("SecretCode") or "").strip().upper()
        next_session = str(associate_response.get("Session") or challenge_session).strip()
        if not secret_code or not next_session:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail={
                    "error": "auth_challenge_unavailable",
                    "message": "Unable to initialize authenticator setup. Please try again.",
                },
            )
        return _build_login_challenge_response(
            email=normalized_email,
            challenge_name=challenge_name,
            session=next_session,
            secret_code=secret_code,
        )

    if challenge_name in _SUPPORTED_LOGIN_CHALLENGES:
        challenge_session = str(auth_response.get("Session") or "").strip()
        if not challenge_session:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail={
                    "error": "auth_challenge_unavailable",
                    "message": "Unable to continue authentication challenge. Please try again.",
                },
            )
        return _build_login_challenge_response(
            email=normalized_email,
            challenge_name=challenge_name,
            session=challenge_session,
        )

    logger.warning(
        "Unsupported Cognito auth challenge %s for %s",
        challenge_name,
        _redact_email(normalized_email),
    )
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail={
            "error": "auth_challenge_required",
            "message": "Additional authentication challenge required for this account.",
            "challenge_name": challenge_name,
        },
    )


def _require_oidc_provider() -> OIDCIdentityProvider:
    provider = get_identity_provider()
    if not isinstance(provider, OIDCIdentityProvider):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": "oidc_signup_disabled",
                "message": "OIDC device-code login is not configured in this environment.",
            },
        )
    return provider


def _build_cli_session_login_payload(
    *,
    tenant_id: str,
    user_id: str,
    email: str,
    role: str,
    expires_in: int = _CLI_OAUTH_SESSION_TTL_SECONDS,
    provider: str,
    auth_source: str,
    linked_browser_session_iat: int = 0,
) -> LoginResponse:
    ttl_seconds = max(int(expires_in), 60)
    access_token = mint_cli_session_token(
        tenant_id=tenant_id,
        user_id=user_id,
        email=email,
        provider=provider,
        auth_source=auth_source,
        linked_browser_session_iat=linked_browser_session_iat,
        ttl_seconds=ttl_seconds,
    )
    return LoginResponse(
        access_token=access_token,
        refresh_token=None,
        token_type="Bearer",
        expires_in=ttl_seconds,
        tenant_id=tenant_id,
        user_id=user_id,
        email=email,
        role=role or "ADMIN",
        auth_provider=provider,
        auth_source=auth_source,  # type: ignore[arg-type]
    )


def _require_browser_pair_session(request: Request) -> BrowserSessionClaims:
    claims = _browser_session_claims_from_cookie(request)
    if claims:
        return claims
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail={
            "error": "browser_session_required",
            "message": "Open `ww auth login` and finish sign-in in the same browser session.",
        },
    )


def _build_login_success_response(*, authentication_result: dict[str, Any], fallback_email: str) -> JSONResponse:
    access_token = authentication_result.get("AccessToken", "")
    id_token = authentication_result.get("IdToken", "")
    refresh_token = authentication_result.get("RefreshToken", "")
    expires_in = authentication_result.get("ExpiresIn", 3600)

    if not access_token:
        logger.error(
            "Cognito login response missing access token for %s",
            _redact_email(fallback_email),
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "auth_session_initialization_failed",
                "message": "Authentication session could not be established. Please try again.",
            },
        )

    provisioning_service = get_tenant_provisioning_service()
    sub, resolved_email = _resolve_identity_from_auth_tokens(
        id_token=id_token,
        access_token=access_token,
        fallback_email=fallback_email,
    )
    if not sub:
        logger.warning(
            "Unable to resolve Cognito user identity from auth tokens for %s",
            _redact_email(fallback_email),
        )

    product = "workweaver"
    tenant = provisioning_service.get_tenant_by_owner(sub, product=product) if sub else None
    if not tenant and sub:
        tenant = provisioning_service.get_tenant_by_owner(sub, product=None)

    if not tenant:
        tenant = _resolve_login_tenant_by_email(
            provisioning_service=provisioning_service,
            email=fallback_email,
        )

    if not tenant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "error": "tenant_not_found",
                "message": "No tenant found for this account. Please sign up first.",
            },
        )

    # Founder-suspend gate (issue #1146, Codex round-2): refuse login
    # before issuing any session credentials for a suspended tenant.
    _reject_if_tenant_suspended(tenant)

    user = provisioning_service.get_user(tenant["tenant_id"], sub) if sub else None
    if not user:
        fallback_user_id = str(tenant.get("owner_user_id") or "").strip()
        resolved_user_id = sub or fallback_user_id
        if resolved_user_id:
            if not sub and fallback_user_id:
                logger.info(
                    "Recovered login user_id from tenant owner_user_id for tenant=%s",
                    tenant["tenant_id"],
                )
            user = {"user_id": resolved_user_id, "tenant_id": tenant["tenant_id"]}
        else:
            user = {"user_id": "", "tenant_id": tenant["tenant_id"]}

    logger.info("Login successful for %s, tenant=%s", _redact_email(fallback_email), tenant["tenant_id"])

    login_data = LoginResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="Bearer",
        expires_in=expires_in,
        tenant_id=tenant["tenant_id"],
        user_id=str(user.get("user_id") or sub or tenant.get("owner_user_id") or "").strip(),
        email=resolved_email or fallback_email.lower(),
        role=user.get("role", "ADMIN"),
        auth_provider="email_password",
    )

    if not login_data.user_id:
        logger.error(
            "Authenticated login missing resolved user_id for tenant=%s email=%s",
            tenant["tenant_id"],
            _redact_email(fallback_email),
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "auth_session_initialization_failed",
                "message": "Authentication session could not be established. Please try again.",
            },
        )

    response = JSONResponse(content=login_data.model_dump())
    try:
        _set_browser_session_cookie(
            response,
            tenant_id=tenant["tenant_id"],
            user_id=login_data.user_id,
            email=login_data.email,
            ttl_seconds=login_data.expires_in,
        )
        _set_runtime_provisioning_cookie(response, tenant_id=tenant["tenant_id"])
        logger.info("Set browser session and provisioning cookies for tenant: %s", tenant["tenant_id"])
    except Exception as exc:
        logger.error("Failed to set auth cookies: %s", exc)

    return response


def _resolve_login_tenant_by_email(
    *,
    provisioning_service: Any,
    email: str,
    product: str | None = "workweaver",
) -> dict[str, Any] | None:
    normalized_email = str(email or "").strip().lower()
    if not normalized_email:
        return None

    try:
        tenant = provisioning_service.get_tenant_by_email(normalized_email, product=product)
        if tenant or product is None:
            return tenant

        tenant = provisioning_service.get_tenant_by_email(normalized_email, product=None)
        if tenant:
            logger.info("Recovered tenant by email fallback: %s", tenant.get("tenant_id"))
        return tenant
    except Exception as exc:
        logger.warning("Login tenant lookup failed for %s: %s", _redact_email(normalized_email), exc)
        return None


def _read_consistent_tenant_metadata(tenant_id: str) -> dict[str, Any]:
    """Consistent-read the METADATA row by primary key.

    Codex round-3 BLOCK: the previous login gate consulted the
    ``status`` field on the projection returned by
    ``get_tenant_by_email`` / ``get_tenant_by_owner``. Those helpers
    query the ``GSI_TENANTS_BY_EMAIL`` / ``GSI_TENANTS_BY_OWNER``
    secondary indexes, which are eventually consistent. A
    freshly-committed founder suspend could miss the login gate
    during GSI replication lag — and the projection does not even
    include ``suspended_by`` / ``suspended_reason``, so those
    fields were always absent from the tenant dict in practice.

    Returns ``{}`` on failure — callers treat empty as "cannot
    verify" and fall back to the projection (which at least has
    ``status`` from the GSI).
    """
    normalized_tenant_id = str(tenant_id or "").strip()
    if not normalized_tenant_id:
        return {}
    try:
        from apps.backend.dependency_factories.core import get_tenants_table

        table = get_tenants_table()
        resp = table.get_item(
            Key={"pk": normalized_tenant_id, "sk": "METADATA"},
            ConsistentRead=True,
        )
        return resp.get("Item") or {}
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "tenant_metadata_read_failed tenant=%s error=%s",
            normalized_tenant_id,
            type(exc).__name__,
        )
        return {}


def _reject_if_tenant_suspended(tenant: dict[str, Any] | None) -> None:
    """Refuse login when the tenant is in ``suspended`` status.

    Round-2 BLOCK: added for issue #1146 (prevent immediate re-login
    after founder suspend).

    Round-3 BLOCK fix: the GSI projection passed in may be stale
    (TOCTOU window between suspend write and GSI replication). We
    now re-read the METADATA row by primary key with
    ``ConsistentRead=True`` whenever a ``tenant_id`` is available.
    The fresh METADATA row is authoritative.

    ``tenant`` may be either:
    - a full METADATA row (already consistent — from the local-dev
      path that reads tenants directly), OR
    - a GSI projection from ``get_tenant_by_email`` /
      ``get_tenant_by_owner`` (needs a consistent re-read).
    """
    if not isinstance(tenant, dict):
        return

    tenant_id = str(tenant.get("tenant_id") or tenant.get("pk") or "").strip()
    sort_key = str(tenant.get("sk") or tenant.get("SK") or "").strip().upper()
    is_metadata_row = sort_key == "METADATA"
    authoritative: dict[str, Any] = tenant
    if tenant_id and not is_metadata_row:
        fresh = _read_consistent_tenant_metadata(tenant_id)
        if fresh:
            authoritative = fresh

    status_raw = str(authoritative.get("status") or "").strip().lower()
    if status_raw != "suspended":
        return
    suspended_by = str(authoritative.get("suspended_by") or "").strip()
    suspended_reason = str(authoritative.get("suspended_reason") or "").strip()
    # Codex round-4 PII fix: keep founder email out of the rendered
    # log message body. Hash it and pass via structured ``extra`` so
    # downstream log processors can redact or query by hash without
    # ever displaying the cleartext email.
    _sus_by_hash = ""
    if suspended_by:
        import hashlib as _hashlib

        _sus_by_hash = _hashlib.sha256(suspended_by.encode("utf-8")).hexdigest()[:12]
    logger.warning(
        "login_blocked_tenant_suspended",
        extra={
            "tenant_id": tenant_id or authoritative.get("tenant_id"),
            "suspended_by_hash": _sus_by_hash or "unknown",
        },
    )
    # 403 signals a policy rejection (the credentials may be valid,
    # but the tenant is frozen). 401 would be ambiguous — clients
    # would retry the password.
    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail={
            "error": "tenant_suspended",
            "message": (
                "This organization is currently suspended. Please contact Workweaver support to restore access."
            ),
            # Only expose non-PII details — ``suspended_by`` is a
            # founder email we shouldn't leak to the logged-out user.
            "suspended_reason": suspended_reason or None,
        },
    )


# ============================================================================
# Login Endpoint
# ============================================================================


@router.post(
    "/login",
    response_model=LoginResponse | LoginChallengeResponse,
    status_code=status.HTTP_200_OK,
    summary="Login with email/password",
    description="Authenticate user via the configured identity provider and return bearer tokens.",
)
@limiter.limit("10/minute")
async def login_with_email_password(
    request: Request, response: Response, body: LoginRequest
) -> LoginResponse | LoginChallengeResponse:
    """
    Login user using email and password via the configured identity provider.

    Flow:
    1. Authenticate with the active managed identity adapter
    2. Get user's tenant information
    3. Return bearer tokens and user/tenant details

    Args:
        request: FastAPI request object
        body: Login credentials

    Returns:
        LoginResponse with JWT tokens and user/tenant details

    Raises:
        HTTPException: 401 if authentication fails
        HTTPException: 404 if user not found
        HTTPException: 500 if server error occurs
    """
    try:
        logger.info("Login request for %s", _redact_email(body.email))
        normalized_email = body.email.lower()

        product = "workweaver"
        provisioning_service = get_tenant_provisioning_service()

        # When Cognito is disabled (local Docker dev), look up tenant by email directly.
        if _disable_cognito():
            logger.info("Cognito disabled - login bypass for %s", _redact_email(normalized_email))
            tenant = _resolve_login_tenant_by_email(
                provisioning_service=provisioning_service,
                email=normalized_email,
                product=product,
            )
            if not tenant:
                raise HTTPException(
                    status_code=status.HTTP_404_NOT_FOUND,
                    detail={
                        "error": "tenant_not_found",
                        "message": "No tenant found. Please sign up first.",
                    },
                )

            # Founder-suspend gate (issue #1146): refuse login for
            # a suspended tenant even in local-dev mode, so the UAT
            # suite exercises the same enforcement path as prod.
            _reject_if_tenant_suspended(tenant)

            login_data = LoginResponse(
                access_token=f"local-dev-{ulid.new()}",
                refresh_token=f"local-dev-refresh-{ulid.new()}",
                token_type="Bearer",
                expires_in=3600,
                tenant_id=tenant["tenant_id"],
                user_id=tenant.get("member_user_id") or tenant.get("owner_user_id", ""),
                email=normalized_email,
                role=tenant.get("role", "ADMIN"),
                auth_provider="email_password",
            )
            response = JSONResponse(content=login_data.model_dump())
            try:
                _set_browser_session_cookie(
                    response,
                    tenant_id=tenant["tenant_id"],
                    user_id=login_data.user_id,
                    email=normalized_email,
                    ttl_seconds=login_data.expires_in,
                )
                _set_runtime_provisioning_cookie(response, tenant_id=tenant["tenant_id"])
            except Exception as e:
                logger.warning(f"Cookie set failed (expected in local dev): {e}")
            return response

        cognito_idp = _require_cognito_idp()

        # Get Cognito configuration
        user_pool_id = os.environ.get("COGNITO_USER_POOL_ID")
        client_id = os.environ.get("COGNITO_CLIENT_ID")

        if not user_pool_id or not client_id:
            logger.error("Cognito configuration missing")
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "error": "configuration_error",
                    "message": "Authentication service not properly configured",
                },
            )

        # Authenticate with Cognito
        try:
            auth_response = cognito_idp.initiate_auth(
                ClientId=client_id,
                AuthFlow="USER_PASSWORD_AUTH",
                AuthParameters={
                    "USERNAME": body.email.lower(),
                    "PASSWORD": body.password,
                },
            )

            logger.info("Cognito authentication successful for %s", _redact_email(body.email))

        except cognito_idp.exceptions.NotAuthorizedException:
            logger.warning("Invalid credentials for %s", _redact_email(body.email))
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "error": "invalid_credentials",
                    "message": "Invalid email or password",
                },
            )
        except cognito_idp.exceptions.UserNotFoundException:
            logger.warning("User not found: %s", _redact_email(body.email))
            # Return identical error to prevent account enumeration
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "error": "invalid_credentials",
                    "message": "Invalid email or password",
                },
            )
        except cognito_idp.exceptions.UserNotConfirmedException:
            logger.warning("User not confirmed: %s", _redact_email(body.email))
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "error": "user_not_confirmed",
                    "message": "Please verify your email before logging in.",
                },
            )

        return _handle_login_auth_response(
            auth_response=auth_response,
            cognito_idp=cognito_idp,
            normalized_email=normalized_email,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Error in login for %s: %s", _redact_email(body.email), e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "login_failed",
                "message": "Failed to complete login. Please try again.",
            },
        )


@router.post(
    "/login/challenge",
    response_model=LoginResponse | LoginChallengeResponse,
    status_code=status.HTTP_200_OK,
    summary="Complete an MFA login challenge",
    description="Finish identity-provider MFA setup or TOTP verification and return bearer tokens.",
)
@limiter.limit("20/minute")
async def complete_login_challenge(
    request: Request,
    response: Response,
    body: LoginChallengeRequest,
) -> LoginResponse | LoginChallengeResponse:
    try:
        del request, response
        claims = _verify_auth_challenge_token(body.challenge_token)
        challenge_name = claims["challenge_name"]
        email = claims["email"]
        session_token = claims["session"]

        cognito_idp = _require_cognito_idp()
        client_id = os.environ.get("COGNITO_CLIENT_ID")
        if not client_id:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail={
                    "error": "configuration_error",
                    "message": "Authentication service not properly configured",
                },
            )

        if challenge_name == "MFA_SETUP":
            verify_response = cognito_idp.verify_software_token(
                Session=session_token,
                UserCode=body.code,
                FriendlyDeviceName="Workweaver authenticator",
            )
            next_session = str(verify_response.get("Session") or "").strip()
            if not next_session:
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail={
                        "error": "auth_challenge_unavailable",
                        "message": "Unable to complete authenticator setup. Please try again.",
                    },
                )
            auth_response = cognito_idp.respond_to_auth_challenge(
                ClientId=client_id,
                ChallengeName="MFA_SETUP",
                Session=next_session,
                ChallengeResponses={"USERNAME": email},
            )
        elif challenge_name == "SOFTWARE_TOKEN_MFA":
            auth_response = cognito_idp.respond_to_auth_challenge(
                ClientId=client_id,
                ChallengeName="SOFTWARE_TOKEN_MFA",
                Session=session_token,
                ChallengeResponses={
                    "USERNAME": email,
                    "SOFTWARE_TOKEN_MFA_CODE": body.code,
                },
            )
        else:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "error": "invalid_auth_challenge",
                    "message": "Authentication challenge expired or is invalid. Please sign in again.",
                },
            )

        return _handle_login_auth_response(
            auth_response=auth_response,
            cognito_idp=cognito_idp,
            normalized_email=email,
        )
    except HTTPException:
        raise
    except Exception as exc:
        exc_name = type(exc).__name__
        if exc_name in {"CodeMismatchException", "EnableSoftwareTokenMFAException"}:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "error": "invalid_mfa_code",
                    "message": "Invalid verification code. Please try again.",
                },
            ) from exc
        if exc_name in {"ExpiredCodeException", "NotAuthorizedException"}:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail={
                    "error": "auth_challenge_required",
                    "message": "Authentication challenge expired. Please sign in again.",
                },
            ) from exc
        logger.error("Error completing login challenge for %s: %s", _redact_email("unknown"), exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "auth_challenge_failed",
                "message": "Failed to complete authentication challenge. Please try again.",
            },
        ) from exc


@router.post(
    "/cli/start",
    response_model=CLIAuthStartResponse,
    status_code=status.HTTP_200_OK,
    summary="Start a browser-based ww CLI login",
    description="Create a short-lived CLI login attempt, then return the browser login URL and hidden poll token.",
)
@limiter.limit("20/minute")
async def start_cli_login(request: Request, body: CLIAuthStartRequest) -> CLIAuthStartResponse:
    del request
    provider = str(body.provider or "").strip().lower() or None
    if provider and not _provider_login_enabled(provider):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "error": f"{provider}_signup_disabled",
                "message": f"{provider.capitalize()} signup is currently disabled.",
            },
        )

    try:
        attempt = create_cli_login_attempt(
            provider=provider,
            code_challenge=body.code_challenge,
            code_challenge_method=body.code_challenge_method,
            ttl_seconds=_CLI_LOGIN_START_TTL_SECONDS,
        )
    except RuntimeError as exc:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "cli_login_unavailable",
                "message": str(exc),
            },
        ) from exc
    return_to_origin, _ = _resolve_oauth_login_start(
        provider=provider,
        return_to=body.return_to or PUBLIC_WEB_ORIGIN_FALLBACK,
        client="cli",
        client_state=attempt.attempt_id,
    )
    login_url = _build_cli_browser_login_url(
        return_to_origin=return_to_origin,
        client_state=attempt.attempt_id,
        code_challenge=attempt.code_challenge,
        code_challenge_method=attempt.code_challenge_method,
        provider=provider,
    )
    return CLIAuthStartResponse(
        provider=provider,
        login_url=login_url,
        poll_token=attempt.poll_token,
        expires_in=attempt.expires_in,
    )


@router.post(
    "/cli/complete",
    response_model=CLIAuthCompleteResponse,
    status_code=status.HTTP_200_OK,
    summary="Complete a CLI browser login from an authenticated web session",
    description="Publish the short-lived CLI auth exchange code after the unified Workweaver auth page finishes sign-in.",
)
@limiter.limit("30/minute")
async def complete_cli_login_from_browser(request: Request, body: CLIAuthCompleteRequest) -> CLIAuthCompleteResponse:
    logger.info("CLI auth complete request: client_state=%s...", str(body.client_state or "")[:12])
    attempt = get_cli_login_attempt(body.client_state)
    if not attempt:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_client_state",
                "message": "CLI login attempt is missing or expired. Run `ww auth login` again.",
            },
        )
    if attempt.code_challenge != str(body.code_challenge or "").strip():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_code_challenge",
                "message": "CLI login attempt does not match this browser session. Run `ww auth login` again.",
            },
        )
    if attempt.code_challenge_method != str(body.code_challenge_method or "").strip().upper():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_code_challenge_method",
                "message": "CLI login attempt does not match this browser session. Run `ww auth login` again.",
            },
        )

    browser_claims = _require_browser_pair_session(request)
    tenant_id = browser_claims.tenant_id
    user_id = browser_claims.user_id
    email = browser_claims.email
    provisioning_service = get_tenant_provisioning_service()
    user_profile = provisioning_service.get_user(tenant_id, user_id) or {}
    provider = _normalize_cli_auth_provider(body.provider or user_profile.get("auth_provider") or attempt.provider)
    if attempt.provider and attempt.provider != provider:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "invalid_provider",
                "message": "This CLI login was started with a different provider. Run `ww auth login` again.",
            },
        )

    exchange_code = mint_cli_auth_code(
        tenant_id=tenant_id,
        user_id=user_id,
        email=email,
        provider=provider,
        code_challenge=attempt.code_challenge,
        code_challenge_method=attempt.code_challenge_method,
        auth_source="browser-pair",
        linked_browser_session_iat=browser_claims.iat,
        ttl_seconds=CLI_AUTH_CODE_TTL_SECONDS,
    )
    logger.info("CLI auth complete publishing result: client_state=%s tenant=%s",
                attempt.attempt_id[:12], tenant_id)
    published = publish_cli_login_result(
        client_state=attempt.attempt_id,
        provider=provider,
        code=exchange_code,
        ttl_seconds=CLI_AUTH_CODE_TTL_SECONDS,
    )
    if not published:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "cli_login_publish_failed",
                "message": "Failed to publish login result. Please try again.",
            },
        )
    logger.info("CLI auth complete published: client_state=%s provider=%s",
                attempt.attempt_id[:12], provider)
    return CLIAuthCompleteResponse(
        status="complete",
        provider=provider,
        tenant_id=tenant_id,
        user_id=user_id,
        email=email,
        expires_in=CLI_AUTH_CODE_TTL_SECONDS,
    )


@router.post(
    "/cli/pending",
    response_model=CLIPendingLoginResponse,
    status_code=status.HTTP_200_OK,
    summary="Poll an in-progress CLI browser login",
    description="Return pending, complete, or error for a browser OAuth login started by the ww CLI.",
)
@limiter.limit("120/minute")
async def poll_cli_login_result(request: Request, body: CLIPendingLoginRequest) -> CLIPendingLoginResponse:
    del request
    logger.info("CLI auth poll: poll_token=%s...", str(body.poll_token or "")[:12])
    try:
        result = read_cli_login_result(body.poll_token)
    except InvalidCLILoginPollToken as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "error": "invalid_cli_poll_token",
                "message": str(exc),
            },
        ) from exc
    return CLIPendingLoginResponse(
        status=result.status,
        provider=result.provider,
        code=result.code,
        error=result.error,
        poll_after_seconds=result.poll_after_seconds,
    )


@router.post(
    "/cli/device/start",
    response_model=CLIDeviceAuthStartResponse,
    status_code=status.HTTP_200_OK,
    summary="Start a self-host OIDC device-code login",
    description="Begin device-code login for self-host OIDC environments.",
)
@limiter.limit("20/minute")
async def start_cli_device_login(request: Request, body: CLIDeviceAuthStartRequest) -> CLIDeviceAuthStartResponse:
    del request, body
    provider = _require_oidc_provider()
    try:
        session = provider.start_device_authorization()
    except IdentityProviderError as exc:
        raise HTTPException(
            status_code=exc.status_code,
            detail={
                "error": "oidc_device_login_unavailable",
                "message": str(exc),
            },
        ) from exc

    return CLIDeviceAuthStartResponse(
        provider="oidc",
        device_code=session.device_code,
        user_code=session.user_code,
        verification_uri=session.verification_uri,
        verification_uri_complete=session.verification_uri_complete or None,
        expires_in=session.expires_in,
        poll_after_seconds=session.interval,
    )


@router.post(
    "/cli/device/poll",
    response_model=CLIDeviceAuthPollResponse,
    status_code=status.HTTP_200_OK,
    summary="Poll a self-host OIDC device-code login",
    description="Poll the configured self-host OIDC provider until device-code login completes.",
)
@limiter.limit("120/minute")
async def poll_cli_device_login(request: Request, body: CLIDeviceAuthPollRequest) -> CLIDeviceAuthPollResponse:
    del request
    provider = _require_oidc_provider()
    try:
        poll_result = provider.poll_device_authorization(device_code=body.device_code)
    except IdentityProviderError as exc:
        raise HTTPException(
            status_code=exc.status_code,
            detail={
                "error": "oidc_device_login_unavailable",
                "message": str(exc),
            },
        ) from exc

    if poll_result.status != "complete":
        return CLIDeviceAuthPollResponse(
            status=("error" if poll_result.status == "error" else "pending"),
            provider="oidc",
            error=poll_result.error,
            poll_after_seconds=poll_result.poll_after_seconds,
        )

    try:
        envelope = provider.resolve_from_token_response(
            {
                "access_token": poll_result.access_token,
                "id_token": poll_result.id_token,
            }
        )
    except IdentityProviderError as exc:
        return CLIDeviceAuthPollResponse(
            status="error",
            provider="oidc",
            error=str(exc),
            poll_after_seconds=poll_result.poll_after_seconds,
        )

    raw_user_id = str(envelope.user_id or "").strip()
    user_id = f"oidc:{raw_user_id}" if raw_user_id else ""
    tenant_id = _resolve_oidc_linked_tenant_record_id(
        tenant_id=str(envelope.tenant_id or "").strip(),
        user_id=user_id,
    )
    email = str(envelope.email or "").strip().lower()
    if not tenant_id or not user_id or not email:
        return CLIDeviceAuthPollResponse(
            status="error",
            provider="oidc",
            error="Authenticated OIDC account is not linked to a Workweaver tenant.",
            poll_after_seconds=poll_result.poll_after_seconds,
        )

    provisioning_service = get_tenant_provisioning_service()
    tenant = provisioning_service.get_tenant(tenant_id)
    if not tenant:
        return CLIDeviceAuthPollResponse(
            status="error",
            provider="oidc",
            error="No tenant found for this OIDC account. Create the tenant in the browser first, then retry.",
            poll_after_seconds=poll_result.poll_after_seconds,
        )

    user = provisioning_service.get_user(tenant_id, user_id) or {}
    login = _build_cli_session_login_payload(
        tenant_id=tenant_id,
        user_id=user_id,
        email=email,
        role=str(user.get("role") or tenant.get("role") or "ADMIN"),
        provider="oidc",
        auth_source="device-code",
    )
    return CLIDeviceAuthPollResponse(
        status="complete",
        provider="oidc",
        login=login,
        poll_after_seconds=poll_result.poll_after_seconds,
    )


@router.post(
    "/cli/exchange",
    response_model=LoginResponse,
    status_code=status.HTTP_200_OK,
    summary="Exchange a CLI OAuth code for a bearer token",
    description="Verify a short-lived CLI OAuth exchange code and mint a bearer session token for the ww CLI.",
)
@limiter.limit("20/minute")
async def exchange_cli_auth_code(request: Request, body: CLIAuthExchangeRequest) -> LoginResponse:
    del request
    try:
        claims = verify_cli_auth_code(body.code)
    except BrowserSessionTokenError as exc:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "error": "invalid_cli_auth_code",
                "message": "CLI authentication code expired or is invalid. Please sign in again.",
            },
        ) from exc
    if not verify_pkce_code_verifier(
        body.code_verifier,
        expected_code_challenge=claims.code_challenge,
        code_challenge_method=claims.code_challenge_method,
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={
                "error": "invalid_cli_auth_code",
                "message": "CLI authentication code expired or is invalid. Please sign in again.",
            },
        )

    provisioning_service = get_tenant_provisioning_service()
    tenant = provisioning_service.get_tenant(claims.tenant_id)
    if not tenant:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail={
                "error": "tenant_not_found",
                "message": "No tenant found for this account. Please sign in again.",
            },
        )

    user = provisioning_service.get_user(claims.tenant_id, claims.user_id) or {}
    return _build_cli_session_login_payload(
        tenant_id=claims.tenant_id,
        user_id=claims.user_id,
        email=claims.email,
        role=str(user.get("role") or tenant.get("role") or "ADMIN"),
        provider=claims.provider,
        auth_source=claims.auth_source or "browser-pair",
        linked_browser_session_iat=claims.linked_browser_session_iat,
    )


# ============================================================================
# Tenant / User Query Endpoints
# ============================================================================


@router.get(
    "/tenant/{tenant_id}",
    response_model=dict[str, Any],
    status_code=status.HTTP_200_OK,
    summary="Get tenant details",
    description="Retrieve tenant information by ID.",
)
async def get_tenant(request: Request, tenant_id: str) -> dict[str, Any]:
    """
    Get tenant details by ID.

    Args:
        tenant_id: Tenant ID

    Returns:
        Tenant details

    Raises:
        HTTPException: 404 if tenant not found
        HTTPException: 500 if server error occurs
    """
    try:
        session_tenant_id, _session_user_id = _resolve_authenticated_request_identity(request)
        if session_tenant_id != tenant_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "error": "forbidden",
                    "message": "You are not authorized to access this tenant.",
                },
            )

        logger.info(f"Get tenant request for tenant_id={tenant_id}")

        provisioning_service = get_tenant_provisioning_service()
        tenant = provisioning_service.get_tenant(tenant_id)

        if not tenant:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "error": "tenant_not_found",
                    "message": f"Tenant {tenant_id} not found",
                },
            )

        # Read endpoints stay side-effect free. Runtime reconciliation is owned by the
        # provisioning controller and explicit retry commands.

        return tenant

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting tenant {tenant_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "get_tenant_failed",
                "message": "Failed to retrieve tenant details",
            },
        )


@router.get(
    "/tenant/{tenant_id}/user/{user_id}",
    response_model=dict[str, Any],
    status_code=status.HTTP_200_OK,
    summary="Get user details",
    description="Retrieve user information by tenant and user ID.",
)
async def get_user(request: Request, tenant_id: str, user_id: str) -> dict[str, Any]:
    """
    Get user details by tenant and user ID.

    Args:
        tenant_id: Tenant ID
        user_id: User ID

    Returns:
        User details

    Raises:
        HTTPException: 404 if user not found
        HTTPException: 500 if server error occurs
    """
    try:
        session_tenant_id, session_user_id = _resolve_authenticated_request_identity(request)
        if session_tenant_id != tenant_id or session_user_id != user_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "error": "forbidden",
                    "message": "You are not authorized to access this user.",
                },
            )

        logger.info(f"Get user request for tenant_id={tenant_id}, user_id={user_id}")

        provisioning_service = get_tenant_provisioning_service()
        user = provisioning_service.get_user(tenant_id, user_id)

        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail={
                    "error": "user_not_found",
                    "message": f"User {user_id} not found in tenant {tenant_id}",
                },
            )

        return user

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Error getting user {user_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "get_user_failed",
                "message": "Failed to retrieve user details",
            },
        )


# ── Admin token exchange (dogfood bridge) ────────────────────────────────


@router.post("/admin-token-exchange")
async def admin_token_exchange(
    request: Request,
) -> JSONResponse:
    """Exchange an admin impersonation token for a browser session cookie.

    Called by the runtime when opened via admin.workweaver.ai dogfood bridge
    with ?admin_token=X. Verifies the token, sets the session cookie, and
    returns the auth state for the impersonated tenant.
    """
    from pydantic import BaseModel

    class AdminTokenBody(BaseModel):
        token: str

    try:
        body = await request.json()
        token = str(body.get("token", "")).strip()
    except Exception:
        return JSONResponse({"ok": False, "error": "invalid_body"}, status_code=400)

    if not token:
        return JSONResponse({"ok": False, "error": "missing_token"}, status_code=400)

    from apps.backend.services.session.browser_session import (
        BrowserSessionTokenError,
        verify_browser_session_token,
    )
    from apps.backend.api.auth_helpers import BROWSER_SESSION_COOKIE_NAMES

    try:
        claims = verify_browser_session_token(token)
    except BrowserSessionTokenError:
        return JSONResponse({"ok": False, "error": "invalid_token"}, status_code=401)

    if not claims.email:
        return JSONResponse({"ok": False, "error": "no_email_in_token"}, status_code=401)

    cookie_name = BROWSER_SESSION_COOKIE_NAMES[0] if BROWSER_SESSION_COOKIE_NAMES else "__Secure-ww-browser-session"
    resp = JSONResponse({"ok": True, "email": claims.email})
    resp.set_cookie(
        key=cookie_name,
        value=token,
        httponly=True,
        secure=True,
        samesite="none",
        max_age=86400,  # 24 hours matching impersonation TTL
        path="/",
        domain=".workweaver.ai",
    )

    logger.info(
        "admin_token_exchange: set session cookie for %s",
        claims.email,
        extra={"email": claims.email, "impersonator_id": claims.impersonator_id},
    )

    return resp
