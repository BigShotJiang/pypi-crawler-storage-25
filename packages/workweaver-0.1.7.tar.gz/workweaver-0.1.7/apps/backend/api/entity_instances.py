"""Tenant entity record CRUD API backed by active entity schemas."""

from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query, status

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.entity_instance_service import (
    EntityRecordEnvelope,
    EntityRecordListEnvelope,
    EntityRecordNotFoundError,
    EntityRecordValidationError,
    EntityRecordWriteRequest,
    get_entity_instance_service,
)
from apps.backend.models.entity_sync import EntityConflict, EntityConflictResolveRequest, EntitySyncConflictList
from apps.backend.services.entity_sync import get_entity_sync_service

router = APIRouter(prefix="/api/v1/entities/{schema_name}/records", tags=["entity-records"])
sync_router = APIRouter(prefix="/api/v1/entities/records", tags=["entity-records"])


@router.post("", response_model=EntityRecordEnvelope, status_code=status.HTTP_201_CREATED)
async def create_entity_record(
    schema_name: str,
    request: EntityRecordWriteRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> EntityRecordEnvelope:
    try:
        return get_entity_instance_service().create_record(tenant_id, schema_name, request)
    except EntityRecordValidationError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_CONTENT, detail=str(exc)) from exc


@router.get("", response_model=EntityRecordListEnvelope)
async def list_entity_records(
    schema_name: str,
    limit: int = Query(100, ge=1, le=500),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> EntityRecordListEnvelope:
    try:
        return get_entity_instance_service().list_records(tenant_id, schema_name, limit=limit)
    except EntityRecordValidationError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_CONTENT, detail=str(exc)) from exc


@router.get("/sync-conflicts", response_model=EntitySyncConflictList)
async def list_entity_sync_conflicts(
    schema_name: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> EntitySyncConflictList:
    return get_entity_sync_service().list_conflicts(tenant_id, schema_name)


@sync_router.get("/sync-conflicts", response_model=EntitySyncConflictList)
async def list_all_entity_sync_conflicts(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> EntitySyncConflictList:
    return get_entity_sync_service().list_conflicts(tenant_id)


@sync_router.post("/sync-conflicts/{conflict_id}/resolve", response_model=EntityConflict)
async def resolve_entity_sync_conflict(
    conflict_id: str,
    request: EntityConflictResolveRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> EntityConflict:
    try:
        return get_entity_sync_service().resolve_conflict(
            tenant_id=tenant_id,
            conflict_id=conflict_id,
            request=request,
        )
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc


@router.get("/{record_id}", response_model=EntityRecordEnvelope)
async def get_entity_record(
    schema_name: str,
    record_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> EntityRecordEnvelope:
    try:
        return get_entity_instance_service().get_record(tenant_id, schema_name, record_id)
    except EntityRecordNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    except EntityRecordValidationError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_CONTENT, detail=str(exc)) from exc


@router.patch("/{record_id}", response_model=EntityRecordEnvelope)
async def update_entity_record(
    schema_name: str,
    record_id: str,
    request: EntityRecordWriteRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> EntityRecordEnvelope:
    try:
        return get_entity_instance_service().update_record(tenant_id, schema_name, record_id, request)
    except EntityRecordNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    except EntityRecordValidationError as exc:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_CONTENT, detail=str(exc)) from exc
