"""Domain Pack API endpoints (PR-T5.1, PR-T5.2, PR-T5.3).

Exposes domain pack listing, readiness checks, provisioning, active
domain queries, Zara domain detection, and workflow compilation.

Endpoints:
  GET  /api/v1/domains/packs                        -- list available domain packs
  GET  /api/v1/domains/packs/{domain_id}/readiness   -- check readiness for tenant
  POST /api/v1/domains/provision                     -- provision a domain pack
  GET  /api/v1/domains/active                        -- list tenant's active domains
  POST /api/v1/domains/detect                        -- detect domain from user input
  POST /api/v1/domains/propose                       -- get provisioning proposal
  GET  /api/v1/workflows/compiled                    -- list auto-compiled skills
  POST /api/v1/workflows/compile/{workflow_id}       -- force-compile a workflow
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.dependencies import (
    get_domain_provisioner,
    get_domain_provisioning_handler,
)
from apps.backend.services.domain_factory.registry import get_pack, list_packs
from apps.backend.services.domain_factory.workflow_compiler import get_workflow_compiler

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/domains", tags=["domains"])
workflows_router = APIRouter(prefix="/api/v1/workflows", tags=["workflows"])


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class ProvisionRequest(BaseModel):
    """Request body for provisioning a domain pack."""

    domain_id: str = Field(..., min_length=1, description="Domain pack ID to provision")


class PackSummary(BaseModel):
    """Summary of a domain pack for listing."""

    domain_id: str
    name: str
    description: str
    required_connector_count: int
    skill_count: int
    role_count: int


class ReadinessResponse(BaseModel):
    """Readiness check result."""

    domain_id: str
    ready: bool
    connectors: list[dict[str, Any]]
    missing_required: list[str]
    missing_optional: list[str]


class ProvisionResponse(BaseModel):
    """Provisioning result."""

    domain_id: str
    tenant_id: str
    roles_created: list[str]
    skills_registered: list[str]
    readiness: dict[str, Any] | None
    provisioned_at: str


class ActiveDomainsResponse(BaseModel):
    """List of active domain IDs for a tenant."""

    tenant_id: str
    active_domains: list[str]


class DetectRequest(BaseModel):
    """Request body for domain detection from user input."""

    user_input: str = Field(..., min_length=1, description="Natural language input to analyze")


class DetectResponse(BaseModel):
    """Domain detection result."""

    detected_domain_id: str | None
    user_input: str


class ProposeRequest(BaseModel):
    """Request body for provisioning proposal."""

    domain_id: str = Field(..., min_length=1, description="Domain pack ID to propose")


class ProposalResponse(BaseModel):
    """Provisioning proposal with readiness assessment."""

    domain_id: str
    domain_name: str
    readiness_score: float
    missing_connectors: list[dict[str, Any]]
    roles_to_create: list[str]
    skills_available: int
    workflows_available: int
    requires_approval: bool


class CompiledSkillResponse(BaseModel):
    """Auto-compiled skill from a proven workflow."""

    skill_id: str
    name: str
    description: str
    source_workflow_id: str
    steps: list[dict[str, Any]]
    input_schema: dict[str, Any]
    output_schema: dict[str, Any]
    success_rate: float
    compiled_at: str


# ---------------------------------------------------------------------------
# Domain Pack Endpoints (PR-T5.1)
# ---------------------------------------------------------------------------


@router.get("/packs", response_model=list[PackSummary])
async def list_domain_packs() -> list[PackSummary]:
    """List all available domain packs."""
    packs = list_packs()
    return [
        PackSummary(
            domain_id=p.domain_id,
            name=p.name,
            description=p.description,
            required_connector_count=len(p.required_connectors),
            skill_count=len(p.skills),
            role_count=len(p.role_templates),
        )
        for p in packs
    ]


@router.get("/packs/{domain_id}/readiness", response_model=ReadinessResponse)
async def check_domain_readiness(
    domain_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ReadinessResponse:
    """Check if a tenant is ready to provision a domain pack."""
    pack = get_pack(domain_id)
    if pack is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Domain pack not found: {domain_id}",
        )

    provisioner = get_domain_provisioner()
    report = provisioner.check_readiness(tenant_id, pack)

    return ReadinessResponse(
        domain_id=report.domain_id,
        ready=report.ready,
        connectors=[c.to_dict() for c in report.connectors],
        missing_required=report.missing_required,
        missing_optional=report.missing_optional,
    )


@router.post("/provision", response_model=ProvisionResponse, status_code=status.HTTP_201_CREATED)
async def provision_domain(
    body: ProvisionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ProvisionResponse:
    """Provision a domain pack for the authenticated tenant."""
    pack = get_pack(body.domain_id)
    if pack is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Domain pack not found: {body.domain_id}",
        )

    provisioner = get_domain_provisioner()
    result = provisioner.provision(tenant_id, pack)

    return ProvisionResponse(
        domain_id=result.domain_id,
        tenant_id=result.tenant_id,
        roles_created=result.roles_created,
        skills_registered=result.skills_registered,
        readiness=result.readiness.to_dict() if result.readiness else None,
        provisioned_at=result.provisioned_at,
    )


@router.get("/active", response_model=ActiveDomainsResponse)
async def list_active_domains(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ActiveDomainsResponse:
    """List all active domains for the authenticated tenant."""
    provisioner = get_domain_provisioner()
    active = provisioner.list_active_domains(tenant_id)

    return ActiveDomainsResponse(
        tenant_id=tenant_id,
        active_domains=active,
    )


# ---------------------------------------------------------------------------
# Zara Domain Detection Endpoints (PR-T5.2)
# ---------------------------------------------------------------------------


@router.post("/detect", response_model=DetectResponse)
async def detect_domain(body: DetectRequest) -> DetectResponse:
    """Detect which domain a user input is requesting."""
    handler = get_domain_provisioning_handler()
    detected = handler.detect_domain_request(body.user_input)

    return DetectResponse(
        detected_domain_id=detected,
        user_input=body.user_input,
    )


@router.post("/propose", response_model=ProposalResponse)
async def propose_provisioning(
    body: ProposeRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ProposalResponse:
    """Get a provisioning proposal with readiness assessment."""
    handler = get_domain_provisioning_handler()

    try:
        proposal = handler.propose_provisioning(tenant_id, body.domain_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc

    return ProposalResponse(
        domain_id=proposal.domain_id,
        domain_name=proposal.domain_name,
        readiness_score=proposal.readiness_score,
        missing_connectors=proposal.missing_connectors,
        roles_to_create=proposal.roles_to_create,
        skills_available=proposal.skills_available,
        workflows_available=proposal.workflows_available,
        requires_approval=proposal.requires_approval,
    )


# ---------------------------------------------------------------------------
# Workflow Compilation Endpoints (PR-T5.3)
# ---------------------------------------------------------------------------


@workflows_router.get("/compiled", response_model=list[CompiledSkillResponse])
async def list_compiled_skills(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[CompiledSkillResponse]:
    """List all auto-compiled skills for the authenticated tenant."""
    compiler = get_workflow_compiler()
    skills = compiler.get_compiled_skills(tenant_id)

    return [
        CompiledSkillResponse(
            skill_id=s.skill_id,
            name=s.name,
            description=s.description,
            source_workflow_id=s.source_workflow_id,
            steps=s.steps,
            input_schema=s.input_schema,
            output_schema=s.output_schema,
            success_rate=s.success_rate,
            compiled_at=s.compiled_at,
        )
        for s in skills
    ]


@workflows_router.post("/compile/{workflow_id}", response_model=CompiledSkillResponse)
async def compile_workflow(
    workflow_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CompiledSkillResponse:
    """Force-compile a workflow into a reusable skill."""
    compiler = get_workflow_compiler()

    try:
        skill = compiler.compile_to_skill(tenant_id, workflow_id)
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=str(exc),
        ) from exc

    return CompiledSkillResponse(
        skill_id=skill.skill_id,
        name=skill.name,
        description=skill.description,
        source_workflow_id=skill.source_workflow_id,
        steps=skill.steps,
        input_schema=skill.input_schema,
        output_schema=skill.output_schema,
        success_rate=skill.success_rate,
        compiled_at=skill.compiled_at,
    )
