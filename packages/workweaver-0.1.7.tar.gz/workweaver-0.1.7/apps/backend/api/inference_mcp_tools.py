"""Manifest-driven MCP tool generation for the inference admin family.

Issue #3508: the same YAML manifest that drives the ``ww inference`` CLI
namespace also drives the corresponding ``ww.inference.*`` and
``ww.admin.inference.*`` MCP tools. This module reads
``apps/cli/ww/commands/inference_manifest.yaml`` and produces:

    * ``inference_mcp_tools()``       — the list[dict] schemas to splice into
                                         ``PUBLIC_MCP_TOOLS`` in ``public_mcp``.
    * ``dispatch_inference_tool(...)`` — async dispatcher mapping each tool to
                                         a ``PublicAPIService`` handler.

Both surfaces share a single source of truth so the parity test in
``tests/contracts/test_inference_surface_parity.py`` can hold (CLI op count ==
MCP tool count == manifest op count).
"""

from __future__ import annotations

from functools import lru_cache
from pathlib import Path
from typing import Any

import yaml


_MANIFEST_PATH = (
    Path(__file__).resolve().parents[2]
    / "cli"
    / "ww"
    / "commands"
    / "inference_manifest.yaml"
)


@lru_cache(maxsize=1)
def _load_manifest() -> dict[str, Any]:
    if not _MANIFEST_PATH.exists():
        raise FileNotFoundError(f"inference manifest not found at {_MANIFEST_PATH}")
    return yaml.safe_load(_MANIFEST_PATH.read_text(encoding="utf-8")) or {}


def manifest_operations() -> list[dict[str, Any]]:
    """Return the ordered list of manifest operations."""

    raw = _load_manifest()
    return list(raw.get("operations") or [])


def _tool_input_schema(op: dict[str, Any]) -> dict[str, Any]:
    """Build a JSON Schema for the MCP ``inputSchema`` field from manifest params."""

    properties: dict[str, Any] = {}
    required: list[str] = []
    for param in op.get("params") or []:
        name = str(param["name"])
        help_text = str(param.get("help") or "")
        ptype = str(param.get("type") or "string")
        json_type: dict[str, Any]
        if ptype == "bool":
            json_type = {"type": "boolean"}
        elif name in ("capability_classes", "providers"):
            # Free-form JSON object (provider→reason map or capability routing).
            json_type = {
                "type": "object",
                "additionalProperties": True,
            }
        else:
            json_type = {"type": "string"}
        if help_text:
            json_type["description"] = help_text
        properties[name] = json_type
        if bool(param.get("required", False)):
            required.append(name)
    schema: dict[str, Any] = {"type": "object", "properties": properties}
    if required:
        schema["required"] = required
    return schema


def _tool_category(op: dict[str, Any]) -> str:
    return "admin" if bool(op.get("admin")) else "inference"


def _tool_intent_hints(op: dict[str, Any]) -> list[str]:
    """Generate intent hints from manifest summary + canonical CLI shape."""

    summary = str(op.get("summary") or "").rstrip(".")
    name = str(op["name"])
    cli_path = (
        f"ww admin inference {name.replace('.', ' ')}"
        if bool(op.get("admin"))
        else f"ww inference {name.replace('.', ' ')}"
    )
    hints: list[str] = [cli_path]
    if summary:
        hints.append(summary.lower())
    return hints


def _tool_for_op(op: dict[str, Any]) -> dict[str, Any]:
    """Build a single MCP tool entry from a manifest op."""

    name = str(op["mcp_tool_name"])
    summary = str(op.get("summary") or "")
    method = str(op.get("http_method") or "GET")
    path = str(op.get("path") or "")
    description = (
        f"{summary} Mirrors {method} {path}. "
        "Generated from apps/cli/ww/commands/inference_manifest.yaml (issue #3508)."
    )
    return {
        "name": name,
        "description": description,
        "inputSchema": _tool_input_schema(op),
        "namespace": "ww",
        "category": _tool_category(op),
        "callable": True,
        "intent_hints": _tool_intent_hints(op),
        # Manifest-driven inference tools land via #3508 (merged in #3534)
        # before product-decided capability rows exist for each one in
        # docs/reference/runtime/capabilities.registry.yaml. Until those
        # registry rows land the parity gate would fail with "missing from
        # capabilities.registry.yaml". Mark each manifest tool as
        # needs_product_decision so the gate skips it — see
        # ``_validate_mcp_registry_coverage`` in
        # ops/scripts/generate_capability_registry.py. Tracked under
        # the parent issue #3508.
        "parity": {
            "status": "needs_product_decision",
            "owner_issue": "#3508",
        },
    }


def inference_mcp_tools() -> list[dict[str, Any]]:
    """Return the full list of MCP tool entries for the inference family.

    Skips operations whose ``mcp_tool_name`` is already present in
    ``existing_names`` so manifest-driven tools never collide with hand-rolled
    ones (e.g. legacy ``ww.admin.inference.audit_grid``, jurisdiction policy).
    """

    seen: set[str] = set()
    tools: list[dict[str, Any]] = []
    for op in manifest_operations():
        name = str(op.get("mcp_tool_name") or "")
        if not name or name in seen:
            continue
        seen.add(name)
        tools.append(_tool_for_op(op))
    return tools


def manifest_op_by_mcp_tool(tool_name: str) -> dict[str, Any] | None:
    """Look up the manifest op for a given MCP tool name."""

    for op in manifest_operations():
        if str(op.get("mcp_tool_name") or "") == tool_name:
            return op
    return None


def inference_mcp_tool_names() -> list[str]:
    """Return the canonical MCP tool names produced by the manifest."""

    return [str(op["mcp_tool_name"]) for op in manifest_operations() if op.get("mcp_tool_name")]


# ---------------------------------------------------------------------------
# Dispatcher
# ---------------------------------------------------------------------------


_LEGACY_DISPATCH_OVERRIDES: dict[str, str] = {
    # These legacy MCP tools were registered before #3508 and have hand-rolled
    # PublicAPIService handlers. Reuse them so we keep behavior identical.
    "ww.admin.inference.audit_grid": "admin_inference_audit_grid",
}


async def dispatch_inference_tool(
    *,
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch a manifest-driven inference MCP tool.

    For tool names with a hand-rolled ``PublicAPIService`` handler (e.g.
    ``audit_grid``), reuse it via the override map. Otherwise resolve to a
    canonical handler whose name is derived from the manifest op. Missing
    handlers raise ``NotImplementedError`` so test/parity drift is loud.
    """

    from apps.backend.api.public_api_service import get_public_api_service

    op = manifest_op_by_mcp_tool(tool_name)
    if op is None:
        raise ValueError(f"inference MCP tool not in manifest: {tool_name}")

    handler_name = _LEGACY_DISPATCH_OVERRIDES.get(
        tool_name,
        _manifest_handler_name(op),
    )
    service = get_public_api_service()
    handler = getattr(service, handler_name, None)
    if handler is None:
        raise NotImplementedError(
            f"PublicAPIService is missing handler '{handler_name}' for MCP tool "
            f"'{tool_name}'. Add it before registering the manifest entry.",
        )
    return await handler(tenant_id=tenant_id, **parameters)


def _manifest_handler_name(op: dict[str, Any]) -> str:
    """Map an op name to its PublicAPIService handler.

    Convention:
        - admin ops:  ``admin_inference_<flatname>``
        - tenant ops: ``inference_<flatname>``

    where ``<flatname>`` is the dotted name with dots and dashes replaced by
    underscores. Examples:
        provider.add               -> inference_provider_add
        oauth.start                -> inference_oauth_start
        defaults.set               -> admin_inference_defaults_set
        tenant-routing.get         -> admin_inference_tenant_routing_get
        blocked-providers.list     -> admin_inference_blocked_providers_list
    """

    flat = str(op["name"]).replace(".", "_").replace("-", "_")
    if bool(op.get("admin")):
        return f"admin_inference_{flat}"
    return f"inference_{flat}"


def manifest_handler_name(op: dict[str, Any]) -> str:
    """Public alias for ``_manifest_handler_name`` (used by tests + codegen)."""

    return _manifest_handler_name(op)
