"""Autonomy Compiler API — policy lifecycle, metrics, and control.

Endpoints:
  GET  /api/v1/autonomy/metrics              — Autonomy metrics for tenant
  GET  /api/v1/autonomy/policies             — List compiled policies
  GET  /api/v1/autonomy/policies/{id}        — Get single policy
  POST /api/v1/autonomy/policies/{id}/activate  — User confirms activation
  POST /api/v1/autonomy/policies/{id}/pause     — Pause a policy
  POST /api/v1/autonomy/policies/{id}/resume    — Resume a paused policy
  POST /api/v1/autonomy/compile              — Trigger compilation now
  POST /api/v1/autonomy/regret              — Record a regret event
  GET  /api/v1/autonomy/pattern-proposals   — Pending PROPOSED policies for
                                               Inbox approve-this-pattern CTA
                                               (Contract 11)
"""

from __future__ import annotations

import asyncio
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, get_verified_user_id
from apps.backend.models.compiled_policy import BlastRadius, PolicyLifecycle
from apps.backend.services.autonomy_compiler import (
    advance_policy_lifecycle,
    get_autonomy_compiler,
)
from apps.backend.services.autonomy_policy_store import get_policy_store

router = APIRouter(prefix="/api/v1/autonomy", tags=["autonomy"])


# ── Response Models ──────────────────────────────────────────────────────


class PolicyResponse(BaseModel):
    policy_id: str
    scope: str
    description: str
    blast_radius: str
    lifecycle: str
    pattern_tool: str
    pattern_conditions: dict[str, Any] = Field(default_factory=dict)
    created_from_judgment_ids: list[str] = Field(default_factory=list)
    created_at: str = ""
    review_date: str | None = None
    kill_metric: str | None = None
    kill_metric_threshold: float | None = None
    rollback_path: str = "pause"
    canary_percentage: int = 0
    auto_executed_count: int = 0
    regret_count: int = 0
    regret_rate: float = 0.0
    shadow_would_have_count: int = 0
    shadow_user_agreed_count: int = 0


class MetricsResponse(BaseModel):
    judgment_count: int = 0
    judgment_count_delta: int = 0
    regret_rate: float = 0.0
    reversal_rate: float = 0.0
    trust_rollback_count: int = 0
    active_policies: int = 0
    shadow_policies: int = 0
    canary_policies: int = 0
    compiled_this_week: int = 0
    inbox_reduction_pct: float = 0.0


class PoliciesListResponse(BaseModel):
    tenant_id: str
    policies: list[PolicyResponse] = Field(default_factory=list)
    total: int = 0


class CompileResponse(BaseModel):
    new_policies: list[PolicyResponse] = Field(default_factory=list)
    total_new: int = 0


class RegretRequest(BaseModel):
    policy_id: str = Field(..., min_length=1)


class RegretResponse(BaseModel):
    success: bool = True
    policy_id: str
    message: str = ""


# ── Helpers ──────────────────────────────────────────────────────────────


def _policy_to_response(p: Any) -> PolicyResponse:
    return PolicyResponse(
        policy_id=p.policy_id,
        scope=p.scope,
        description=p.description,
        blast_radius=p.blast_radius.value if hasattr(p.blast_radius, "value") else str(p.blast_radius),
        lifecycle=p.lifecycle.value if hasattr(p.lifecycle, "value") else str(p.lifecycle),
        pattern_tool=p.pattern_tool,
        pattern_conditions=p.pattern_conditions,
        created_from_judgment_ids=p.created_from_judgment_ids,
        created_at=p.created_at,
        review_date=p.review_date,
        kill_metric=p.kill_metric,
        kill_metric_threshold=p.kill_metric_threshold,
        rollback_path=p.rollback_path,
        canary_percentage=p.canary_percentage,
        auto_executed_count=p.auto_executed_count,
        regret_count=p.regret_count,
        regret_rate=p.regret_rate,
        shadow_would_have_count=p.shadow_would_have_count,
        shadow_user_agreed_count=p.shadow_user_agreed_count,
    )


# ── Endpoints ────────────────────────────────────────────────────────────


@router.get("/metrics", response_model=MetricsResponse)
async def get_metrics(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> MetricsResponse:
    compiler = get_autonomy_compiler()
    metrics = await asyncio.to_thread(compiler.compute_metrics, tenant_id)
    return MetricsResponse(
        judgment_count=metrics.judgment_count,
        judgment_count_delta=metrics.judgment_count_delta,
        regret_rate=metrics.regret_rate,
        reversal_rate=metrics.reversal_rate,
        trust_rollback_count=metrics.trust_rollback_count,
        active_policies=metrics.active_policies,
        shadow_policies=metrics.shadow_policies,
        canary_policies=metrics.canary_policies,
        compiled_this_week=metrics.compiled_this_week,
        inbox_reduction_pct=metrics.inbox_reduction_pct,
    )


@router.get("/policies", response_model=PoliciesListResponse)
async def list_policies(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PoliciesListResponse:
    store = get_policy_store()
    policies = await asyncio.to_thread(store.list_policies, tenant_id)
    return PoliciesListResponse(
        tenant_id=tenant_id,
        policies=[_policy_to_response(p) for p in policies],
        total=len(policies),
    )


@router.get("/policies/{policy_id}", response_model=PolicyResponse)
async def get_policy(
    policy_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PolicyResponse:
    store = get_policy_store()
    policy = await asyncio.to_thread(store.get_policy, tenant_id, policy_id)
    if policy is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Policy not found")
    return _policy_to_response(policy)


@router.post("/policies/{policy_id}/activate", response_model=PolicyResponse)
async def activate_policy(
    policy_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
) -> PolicyResponse:
    """User explicitly activates a policy (required for HIGH blast radius)."""
    store = get_policy_store()
    policy = await asyncio.to_thread(store.get_policy, tenant_id, policy_id)
    if policy is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Policy not found")

    new_state = advance_policy_lifecycle(policy, force_live=True)
    if new_state is None:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Policy in {policy.lifecycle.value} state cannot be activated right now",
        )
    await asyncio.to_thread(store.put_policy, policy)
    return _policy_to_response(policy)


@router.post("/policies/{policy_id}/pause", response_model=PolicyResponse)
async def pause_policy(
    policy_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
) -> PolicyResponse:
    """Pause a policy. Reverts to manual approval for matching actions."""
    store = get_policy_store()
    policy = await asyncio.to_thread(store.get_policy, tenant_id, policy_id)
    if policy is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Policy not found")
    if not policy.can_transition_to(PolicyLifecycle.PAUSED):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Cannot pause policy in {policy.lifecycle.value} state",
        )
    policy.transition_to(PolicyLifecycle.PAUSED)
    await asyncio.to_thread(store.put_policy, policy)
    return _policy_to_response(policy)


@router.post("/policies/{policy_id}/resume", response_model=PolicyResponse)
async def resume_policy(
    policy_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
) -> PolicyResponse:
    """Resume a paused policy. LOW goes to LIVE, MEDIUM/HIGH go to SHADOW."""
    store = get_policy_store()
    policy = await asyncio.to_thread(store.get_policy, tenant_id, policy_id)
    if policy is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Policy not found")
    if policy.lifecycle != PolicyLifecycle.PAUSED:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Policy is not paused",
        )
    # LOW blast radius skips shadow on resume (spec: "Activate immediately")
    if policy.blast_radius == BlastRadius.LOW:
        policy.transition_to(PolicyLifecycle.LIVE)
    else:
        policy.transition_to(PolicyLifecycle.SHADOW)
    await asyncio.to_thread(store.put_policy, policy)
    return _policy_to_response(policy)


@router.post("/compile", response_model=CompileResponse)
async def compile_policies(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CompileResponse:
    """Trigger policy compilation for the tenant."""
    compiler = get_autonomy_compiler()
    new_policies = await asyncio.to_thread(compiler.compile_policies, tenant_id)
    return CompileResponse(
        new_policies=[_policy_to_response(p) for p in new_policies],
        total_new=len(new_policies),
    )


@router.post("/regret", response_model=RegretResponse)
async def record_regret(
    request: RegretRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
) -> RegretResponse:
    """Record that a user reversed an auto-executed action."""
    compiler = get_autonomy_compiler()
    await asyncio.to_thread(compiler.record_regret, tenant_id, request.policy_id)
    return RegretResponse(
        policy_id=request.policy_id,
        message="Regret recorded. Policy metrics updated.",
    )


class PatternProposalItem(BaseModel):
    """A single pending pattern proposal shown in the Inbox approve-this-pattern CTA."""

    pattern_id: str
    description: str
    scope: str
    blast_radius: str
    expires_days: int = 30
    undo_path: str = "pause"


class PatternProposalsResponse(BaseModel):
    """Response for GET /api/v1/autonomy/pattern-proposals.

    Returns PROPOSED-lifecycle policies that the Inbox JS uses to surface
    the 'Approve this pattern' CTA (Contract 11 — Transparent Autonomy UX).
    An empty list means no pending proposals; the CTA stays hidden.
    """

    proposals: list[PatternProposalItem] = Field(default_factory=list)
    total: int = 0


@router.get("/pattern-proposals", response_model=PatternProposalsResponse)
async def list_pattern_proposals(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PatternProposalsResponse:
    """Return pending pattern proposals for the Inbox 'Approve this pattern' CTA.

    Returns only PROPOSED-lifecycle policies — those detected by the autonomy
    compiler but not yet shadow/canary/live.  The Inbox JS polls this on load;
    when proposals are present it shows the approve-this-pattern panel so the
    user can promote a pattern to policy in one click.
    """
    store = get_policy_store()
    all_policies = await asyncio.to_thread(store.list_policies, tenant_id)
    proposed = [p for p in all_policies if p.lifecycle == PolicyLifecycle.PROPOSED]

    _BLAST_EXPIRY_DAYS = {"low": 30, "medium": 14, "high": 7}

    items: list[PatternProposalItem] = []
    for p in proposed:
        blast = p.blast_radius.value if hasattr(p.blast_radius, "value") else str(p.blast_radius)
        items.append(
            PatternProposalItem(
                pattern_id=p.policy_id,
                description=p.description,
                scope=p.scope,
                blast_radius=blast,
                expires_days=_BLAST_EXPIRY_DAYS.get(blast.lower(), 30),
                undo_path="pause",
            )
        )

    return PatternProposalsResponse(proposals=items, total=len(items))
