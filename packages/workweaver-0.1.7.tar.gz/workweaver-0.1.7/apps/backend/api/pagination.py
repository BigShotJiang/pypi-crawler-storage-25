"""Shared bounded pagination helpers for collection endpoints."""

from __future__ import annotations

from apps.backend.contracts.pagination import (  # noqa: F401 -- re-export from contracts
    PaginationParams,
    build_pagination_dependency,
    paginate_items,
    paginate_limit,
    resolve_pagination,
)
