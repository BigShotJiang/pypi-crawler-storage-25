"""Roles API — role template CRUD endpoints.

Endpoints:
    POST   /api/v1/roles               — create role
    GET    /api/v1/roles               — list roles for tenant
    GET    /api/v1/roles/{role_id}     — get single role
    PATCH  /api/v1/roles/{role_id}     — update role
    DELETE /api/v1/roles/{role_id}     — delete role (non-system only)

Key schema: PK=TENANT#{tenant_id}, SK=ROLE#{role_id}
Auth: Depends on get_verified_tenant_id (identity provider in prod, X-Tenant-Id in dev).
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/roles", tags=["roles"])


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class GovernanceConfig(BaseModel):
    """Governance configuration embedded in a role."""

    default_autonomy: int = Field(2, ge=1, le=5, description="Autonomy level 1-5")
    approval_required: list[str] = Field(default_factory=list, description="Actions requiring approval")
    budget_daily_usd: float = Field(0.0, ge=0.0, description="Daily budget cap in USD")


class CreateRoleRequest(BaseModel):
    """Request body for creating a new role template."""

    display_name: str = Field(..., min_length=1, max_length=200, description="Role display name")
    capabilities: list[str] = Field(default_factory=list, description="Capability slugs")
    personality: dict[str, Any] = Field(default_factory=dict, description="Personality config")
    governance: GovernanceConfig = Field(default_factory=GovernanceConfig, description="Governance defaults")
    channels: list[str] = Field(default_factory=list, description="Channel slugs")
    created_by: str = Field("user", max_length=200, description="Creator identifier")


class UpdateRoleRequest(BaseModel):
    """Request body for a partial role update (PATCH semantics)."""

    display_name: str | None = Field(None, min_length=1, max_length=200)
    capabilities: list[str] | None = None
    personality: dict[str, Any] | None = None
    governance: GovernanceConfig | None = None
    channels: list[str] | None = None


class RoleResponse(BaseModel):
    """Response schema for a single role."""

    role_id: str
    tenant_id: str
    display_name: str
    capabilities: list[str]
    personality: dict[str, Any]
    governance: dict[str, Any]
    channels: list[str]
    is_system: bool
    created_by: str
    created_at: str
    updated_at: str


class RoleListResponse(BaseModel):
    """Response schema for a list of roles."""

    roles: list[RoleResponse]
    count: int


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_store():
    """Lazy import to avoid circular dependencies."""
    from apps.backend.services.role_store import get_role_store

    return get_role_store()


def _to_response(item: dict[str, Any]) -> RoleResponse:
    return RoleResponse(
        role_id=item["role_id"],
        tenant_id=item["tenant_id"],
        display_name=item["display_name"],
        capabilities=item.get("capabilities", []),
        personality=item.get("personality", {}),
        governance=item.get("governance", {}),
        channels=item.get("channels", []),
        is_system=item.get("is_system", False),
        created_by=item.get("created_by", "system"),
        created_at=item.get("created_at", ""),
        updated_at=item.get("updated_at", ""),
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("/", response_model=RoleResponse, status_code=201)
async def create_role(
    request: CreateRoleRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> RoleResponse:
    """Create a new role template for the authenticated tenant."""
    try:
        store = _get_store()
        role = store.create_role(
            tenant_id=tenant_id,
            display_name=request.display_name,
            capabilities=request.capabilities,
            personality=request.personality,
            governance=request.governance.model_dump(),
            channels=request.channels,
            is_system=False,
            created_by=request.created_by,
        )
        return _to_response(role)
    except ValueError as exc:
        logger.error("Role creation failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=400, detail="Invalid request parameters")
    except HTTPException:
        raise
    except Exception:
        logger.exception("Unexpected error creating role for tenant %s", tenant_id)
        raise HTTPException(status_code=500, detail="Failed to create role")


@router.get("/", response_model=RoleListResponse)
async def list_roles(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> RoleListResponse:
    """List all role templates for the authenticated tenant."""
    try:
        store = _get_store()
        roles = store.list_roles(tenant_id)
        return RoleListResponse(
            roles=[_to_response(r) for r in roles],
            count=len(roles),
        )
    except HTTPException:
        raise
    except Exception:
        logger.exception("Unexpected error listing roles for tenant %s", tenant_id)
        raise HTTPException(status_code=500, detail="Failed to list roles")


@router.get("/{role_id}", response_model=RoleResponse)
async def get_role(
    role_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> RoleResponse:
    """Retrieve a single role template by ID."""
    try:
        store = _get_store()
        role = store.get_role(tenant_id, role_id)
        if role is None:
            raise HTTPException(status_code=404, detail=f"Role not found: {role_id}")
        return _to_response(role)
    except HTTPException:
        raise
    except Exception:
        logger.exception("Unexpected error fetching role %s for tenant %s", role_id, tenant_id)
        raise HTTPException(status_code=500, detail="Failed to get role")


@router.patch("/{role_id}", response_model=RoleResponse)
async def update_role(
    role_id: str,
    request: UpdateRoleRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> RoleResponse:
    """Partially update a role template (PATCH semantics)."""
    try:
        store = _get_store()
        updates: dict[str, Any] = {}
        if request.display_name is not None:
            updates["display_name"] = request.display_name
        if request.capabilities is not None:
            updates["capabilities"] = request.capabilities
        if request.personality is not None:
            updates["personality"] = request.personality
        if request.governance is not None:
            updates["governance"] = request.governance.model_dump()
        if request.channels is not None:
            updates["channels"] = request.channels

        if not updates:
            raise HTTPException(status_code=400, detail="No updatable fields provided")

        role = store.update_role(tenant_id, role_id, updates)
        return _to_response(role)
    except ValueError as exc:
        logger.error("Role update not found: %s", exc, exc_info=True)
        raise HTTPException(status_code=404, detail="Resource not found")
    except HTTPException:
        raise
    except Exception:
        logger.exception("Unexpected error updating role %s for tenant %s", role_id, tenant_id)
        raise HTTPException(status_code=500, detail="Failed to update role")


@router.delete("/{role_id}", status_code=204)
async def delete_role(
    role_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> None:
    """Delete a non-system role template."""
    try:
        store = _get_store()
        store.delete_role(tenant_id, role_id)
    except ValueError as exc:
        error_msg = str(exc)
        if "system role" in error_msg:
            raise HTTPException(status_code=403, detail=error_msg)
        raise HTTPException(status_code=404, detail=error_msg)
    except HTTPException:
        raise
    except Exception:
        logger.exception("Unexpected error deleting role %s for tenant %s", role_id, tenant_id)
        raise HTTPException(status_code=500, detail="Failed to delete role")
