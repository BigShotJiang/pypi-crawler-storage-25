"""Agent Instances API — spawn, destroy, list, and manage agent instances.

Provides REST endpoints for multi-session agent instance lifecycle.

Legacy requirement reference: P1.R35 — Multi-Session Agent Architecture
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/agents", tags=["agent-instances"])


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class SpawnInstanceRequest(BaseModel):
    """Request to spawn a new agent instance."""

    purpose: str = Field(..., max_length=500, description="What this instance will do")
    context_override: dict[str, Any] | None = Field(None, description="Context snapshot")
    parent_instance_id: str | None = Field(None, description="Parent instance for sub-agents")


class InstanceResponse(BaseModel):
    """Response for a single agent instance."""

    instance_id: str
    agent_id: str
    tenant_id: str
    session_id: str
    session_key: str
    purpose: str
    state: str
    context_snapshot: dict[str, Any] = {}
    created_at: str = ""
    last_heartbeat: str = ""
    parent_instance_id: str | None = None


class InstanceListResponse(BaseModel):
    """Response for listing instances."""

    instances: list[InstanceResponse]
    count: int


class InstanceStatsResponse(BaseModel):
    """Response for instance statistics."""

    tenant_id: str
    agent_id: str | None = None
    total_instances: int
    active: int
    idle: int
    orphaned: int
    destroyed: int


class HealResponse(BaseModel):
    """Response from self-heal operation."""

    detected: int
    destroyed: int


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_manager():  # type: ignore[no-untyped-def]
    """Get the AgentInstanceManager singleton (lazy import to avoid circular deps)."""
    from apps.backend.dependencies import get_agent_instance_manager

    return get_agent_instance_manager()


def _instance_to_response(inst: Any) -> InstanceResponse:
    """Convert AgentInstance to response model."""
    return InstanceResponse(
        instance_id=inst.instance_id,
        agent_id=inst.agent_id,
        tenant_id=inst.tenant_id,
        session_id=inst.session_id,
        session_key=inst.session_key,
        purpose=inst.purpose,
        state=inst.state.value if hasattr(inst.state, "value") else str(inst.state),
        context_snapshot=inst.context_snapshot,
        created_at=inst.created_at,
        last_heartbeat=inst.last_heartbeat,
        parent_instance_id=inst.parent_instance_id,
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


class AgentSummaryResponse(BaseModel):
    """Summary listing of all agents for the tenant."""

    agents: list[dict[str, Any]]
    count: int


@router.get("", response_model=AgentSummaryResponse)
async def list_agents(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> AgentSummaryResponse:
    """List all agent instances for the tenant."""
    mgr = _get_manager()
    try:
        instances = await mgr.list_instances(tenant_id=tenant_id)
    except Exception:
        instances = []
    seen_agents: dict[str, dict[str, Any]] = {}
    for inst in instances:
        aid = inst.agent_id
        if aid not in seen_agents:
            seen_agents[aid] = {
                "agent_id": aid,
                "active_instances": 0,
                "state": inst.state.value if hasattr(inst.state, "value") else str(inst.state),
            }
        seen_agents[aid]["active_instances"] += 1
    return AgentSummaryResponse(
        agents=list(seen_agents.values()),
        count=len(seen_agents),
    )


@router.post("/{agent_id}/instances", status_code=201, response_model=InstanceResponse)
async def spawn_instance(
    agent_id: str,
    body: SpawnInstanceRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> InstanceResponse:
    """Spawn a new agent instance."""
    mgr = _get_manager()
    try:
        inst = await mgr.spawn_instance(
            tenant_id=tenant_id,
            agent_id=agent_id,
            purpose=body.purpose,
            context_override=body.context_override,
            parent_instance_id=body.parent_instance_id,
        )
    except RuntimeError as exc:
        logger.error("Agent instance spawn rate limited: %s", exc, exc_info=True)
        raise HTTPException(status_code=429, detail="Too many requests") from exc

    return _instance_to_response(inst)


@router.get("/{agent_id}/instances", response_model=InstanceListResponse)
async def list_instances(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> InstanceListResponse:
    """List active instances for an agent."""
    mgr = _get_manager()
    instances = mgr.list_instances(tenant_id, agent_id=agent_id)
    paged_instances, _total = paginate_items(instances, pagination)
    return InstanceListResponse(
        instances=[_instance_to_response(i) for i in paged_instances],
        count=len(paged_instances),
    )


@router.get("/{agent_id}/instances/{instance_id}", response_model=InstanceResponse)
async def get_instance(
    agent_id: str,
    instance_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> InstanceResponse:
    """Get a specific agent instance."""
    mgr = _get_manager()
    inst = mgr.get_instance(tenant_id, instance_id)
    if not inst or inst.agent_id != agent_id:
        raise HTTPException(status_code=404, detail="Instance not found")
    return _instance_to_response(inst)


@router.delete("/{agent_id}/instances/{instance_id}", status_code=200)
async def destroy_instance(
    agent_id: str,
    instance_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Destroy an agent instance and free its session."""
    mgr = _get_manager()
    result = await mgr.destroy_instance(tenant_id, instance_id)
    if not result:
        raise HTTPException(status_code=404, detail="Instance not found")
    return {"status": "destroyed", "instance_id": instance_id}


@router.post("/{agent_id}/instances/{instance_id}/heartbeat", status_code=200)
async def heartbeat_instance(
    agent_id: str,
    instance_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Update heartbeat for a running instance."""
    mgr = _get_manager()
    result = await mgr.heartbeat(tenant_id, instance_id)
    if not result:
        raise HTTPException(status_code=404, detail="Instance not found or destroyed")
    return {"status": "ok", "instance_id": instance_id}


@router.get("/{agent_id}/instances-stats", response_model=InstanceStatsResponse)
async def get_instance_stats(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> InstanceStatsResponse:
    """Get instance statistics for an agent."""
    mgr = _get_manager()
    stats = mgr.get_stats(tenant_id, agent_id=agent_id)
    return InstanceStatsResponse(**stats)


@router.post("/{agent_id}/instances/{instance_id}/children", status_code=201, response_model=InstanceResponse)
async def spawn_child_instance(
    agent_id: str,
    instance_id: str,
    body: SpawnInstanceRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> InstanceResponse:
    """Spawn a child sub-agent instance."""
    mgr = _get_manager()
    try:
        inst = await mgr.spawn_child_instance(
            parent_instance_id=instance_id,
            purpose=body.purpose,
            context_override=body.context_override,
        )
    except ValueError as exc:
        logger.error("Agent child instance not found: %s", exc, exc_info=True)
        raise HTTPException(status_code=404, detail="Resource not found") from exc
    except RuntimeError as exc:
        logger.error("Agent child instance spawn rate limited: %s", exc, exc_info=True)
        raise HTTPException(status_code=429, detail="Too many requests") from exc

    return _instance_to_response(inst)


@router.post("/heal", status_code=200, response_model=HealResponse)
async def heal_orphans(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> HealResponse:
    """Run self-heal: detect and destroy orphaned instances."""
    mgr = _get_manager()
    result = await mgr.heal_orphans(tenant_id)
    return HealResponse(**result)
