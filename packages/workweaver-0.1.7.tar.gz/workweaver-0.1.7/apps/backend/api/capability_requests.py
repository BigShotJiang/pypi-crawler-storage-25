"""CBAC Capability Request API endpoints.

Provides endpoints for the dynamic capability request/grant flow:
- POST /api/v1/cbac/capability-requests — create a request
- GET /api/v1/cbac/capability-requests — list requests (filterable by status/agent)
- GET /api/v1/cbac/capability-requests/{request_id} — get single request
- POST /api/v1/cbac/capability-requests/{request_id}/approve — approve
- POST /api/v1/cbac/capability-requests/{request_id}/reject — reject

CBAC-2: Dynamic capability request/grant flow
CBAC-4: Capability escalation with justification (justification + goal_evidence fields)
CBAC-5: Evidence ledger integration on approve/reject
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.models.capability_request import (
    CapabilityRequestCreate,
    CapabilityRequestListResponse,
    CapabilityRequestResponse,
)
from apps.backend.services.capability_request_service import (
    get_capability_request_service,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/cbac", tags=["cbac-capability-requests"])


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class RejectBody(BaseModel):
    """Request body for rejecting a capability request."""

    rejected_by: str = Field(..., description="User rejecting the request")
    reason: str = Field(..., min_length=1, description="Reason for rejection")


class ApproveBody(BaseModel):
    """Request body for approving a capability request."""

    approved_by: str = Field(..., description="User approving the request")


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post(
    "/capability-requests",
    response_model=CapabilityRequestResponse,
    status_code=status.HTTP_201_CREATED,
)
async def create_capability_request(
    body: CapabilityRequestCreate,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CapabilityRequestResponse:
    """Create a new capability request.

    An agent requests a capability (tool) it does not currently hold,
    providing justification and optional goal evidence for supervisor review.
    """
    svc = get_capability_request_service()
    record = svc.create_request(
        tenant_id=tenant_id,
        agent_id=body.agent_id,
        tool_name=body.tool_name,
        justification=body.justification,
        goal_evidence=body.goal_evidence,
    )
    return CapabilityRequestResponse(**record)


@router.get(
    "/capability-requests",
    response_model=CapabilityRequestListResponse,
)
async def list_capability_requests(
    tenant_id: str = Depends(get_verified_tenant_id),
    request_status: str | None = Query(
        None, alias="status", description="Filter by status (pending, approved, rejected)"
    ),
    agent_id: str | None = Query(None, description="Filter by agent ID"),
) -> CapabilityRequestListResponse:
    """List capability requests for the tenant.

    Supports filtering by status and agent_id. Supervisor review endpoint
    shows justification and goal evidence for each request.
    """
    svc = get_capability_request_service()
    records = svc.list_requests(
        tenant_id=tenant_id,
        status=request_status,
        agent_id=agent_id,
    )
    items = [CapabilityRequestResponse(**r) for r in records]
    return CapabilityRequestListResponse(requests=items, count=len(items))


@router.get(
    "/capability-requests/{request_id}",
    response_model=CapabilityRequestResponse,
)
async def get_capability_request(
    request_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CapabilityRequestResponse:
    """Get a single capability request by ID.

    Returns full details including justification and goal evidence
    for supervisor review.
    """
    svc = get_capability_request_service()
    record = svc.get_request(tenant_id, request_id)
    if record is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Capability request not found: {request_id}",
        )
    return CapabilityRequestResponse(**record)


@router.post(
    "/capability-requests/{request_id}/approve",
    response_model=CapabilityRequestResponse,
)
async def approve_capability_request(
    request_id: str,
    body: ApproveBody,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CapabilityRequestResponse:
    """Approve a capability request and grant the tool to the agent.

    On approval:
    1. The capability is granted to the agent via AgentProfileStore
    2. An evidence trail is logged to the evidence ledger (CBAC-5)
    """
    svc = get_capability_request_service()
    try:
        record = svc.approve_request(
            tenant_id=tenant_id,
            request_id=request_id,
            approved_by=body.approved_by,
        )
    except ValueError as exc:
        logger.error("Capability request operation failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid request parameters",
        ) from exc
    return CapabilityRequestResponse(**record)


@router.post(
    "/capability-requests/{request_id}/reject",
    response_model=CapabilityRequestResponse,
)
async def reject_capability_request(
    request_id: str,
    body: RejectBody,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CapabilityRequestResponse:
    """Reject a capability request.

    On rejection:
    1. The request status is set to rejected with reason
    2. An evidence trail is logged to the evidence ledger (CBAC-5)
    """
    svc = get_capability_request_service()
    try:
        record = svc.reject_request(
            tenant_id=tenant_id,
            request_id=request_id,
            rejected_by=body.rejected_by,
            reason=body.reason,
        )
    except ValueError as exc:
        logger.error("Capability request operation failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid request parameters",
        ) from exc
    return CapabilityRequestResponse(**record)
