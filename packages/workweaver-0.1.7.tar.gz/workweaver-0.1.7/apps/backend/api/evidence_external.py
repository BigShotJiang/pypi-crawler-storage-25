"""Evidence-as-a-Service -- external evidence ingestion endpoints.

External agents (outside Workweaver) can POST evidence via:
- REST API: POST /api/v1/evidence/external/ingest
- OpenTelemetry OTLP: POST /api/v1/evidence/external/otlp

Both paths authenticate via X-API-Key header (ww_sk_* token),
resolve tenant from the existing tenant API key infrastructure,
and write to EvidenceLedgerService with full entity_id attribution.
"""
from __future__ import annotations

import logging
from datetime import datetime, UTC
from typing import Any

from fastapi import APIRouter, HTTPException, Request, status
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/evidence/external", tags=["evidence-external"])


# ============================================================================
# Request / Response Models
# ============================================================================


class ExternalEvidenceRequest(BaseModel):
    """Schema for external evidence ingestion via REST."""

    action_type: str = Field(
        ...,
        max_length=200,
        description="Type of action (e.g., 'email_sent', 'meeting_scheduled')",
    )
    actor_id: str = Field(
        ...,
        max_length=200,
        description="ID of the actor/agent that performed the action",
    )
    entity_id: str | None = Field(
        None,
        max_length=200,
        description="Entity ID if action is attributed to a specific AI worker entity",
    )
    input_summary: str | None = Field(
        None,
        max_length=2000,
        description="Summary of inputs to the action",
    )
    output_summary: str | None = Field(
        None,
        max_length=2000,
        description="Summary of action outputs/results",
    )
    decision_rationale: str | None = Field(
        None,
        max_length=2000,
        description="Why this action was taken",
    )
    timestamp: str | None = Field(
        None,
        description="ISO 8601 timestamp (defaults to now if omitted)",
    )
    metadata: dict[str, Any] = Field(
        default_factory=dict,
        description="Additional metadata key-value pairs",
    )


class OTelSpanRequest(BaseModel):
    """Schema for OpenTelemetry OTLP span ingestion.

    Accepts the standard OTLP/JSON resource_spans format.
    Workweaver-specific span attributes are prefixed with 'ww.':
      ww.action_type, ww.actor_id, ww.entity_id,
      ww.input_summary, ww.output_summary, ww.decision_rationale,
      ww.tool_called, ww.outcome
    """

    resource_spans: list[Any] = Field(
        ...,
        description="OTLP resource spans array (standard OTLP/JSON format)",
    )


class EvidenceIngestResponse(BaseModel):
    """Response for evidence ingestion."""

    evidence_id: str = Field(..., description="Unique evidence identifier assigned by Workweaver")
    status: str = Field("accepted", description="Ingestion status")
    ingested_at: str = Field(..., description="ISO 8601 timestamp of ingestion")


# ============================================================================
# Auth helper
# ============================================================================


def _resolve_tenant(request: Request) -> str:
    """Resolve tenant_id from X-API-Key header.

    Validates the API key against the tenant API key infrastructure
    (DynamoDB APIKEY#<sha256> lookup via plugin_auth).

    In dev mode (DISABLE_COGNITO=1): falls back to X-Tenant-Id header.

    Raises:
        HTTPException 401 if no valid key or tenant cannot be resolved.
    """
    from apps.backend.api.dependencies.plugin_auth import (
        _disable_cognito,
        _lookup_api_key,
    )

    # Support both X-API-Key (EaaS convention) and Authorization: Bearer (plugin convention)
    raw_key = (request.headers.get("x-api-key") or "").strip()
    if not raw_key:
        auth_header = (request.headers.get("authorization") or "").strip()
        if auth_header.lower().startswith("bearer "):
            raw_key = auth_header.split(" ", 1)[1].strip()

    if raw_key and raw_key.startswith("ww_sk_"):
        tenant_id = _lookup_api_key(raw_key)
        if tenant_id:
            return tenant_id
        if not _disable_cognito():
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid API key",
            )
        # Dev mode: fall through to X-Tenant-Id

    if _disable_cognito():
        x_tenant_id = (request.headers.get("x-tenant-id") or "").strip()
        if x_tenant_id:
            return x_tenant_id
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="X-Tenant-Id header required (dev mode) or provide X-API-Key: ww_sk_*",
        )

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="X-API-Key header with ww_sk_* token required",
    )


# ============================================================================
# Lazy service accessor
# ============================================================================


def _get_service():
    """Lazy import to avoid import-time boto3 failures in tests."""
    from apps.backend.services.evidence_ledger import get_evidence_ledger_service

    return get_evidence_ledger_service()


# ============================================================================
# Endpoints
# ============================================================================


@router.post(
    "/ingest",
    response_model=EvidenceIngestResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Ingest evidence from external agents (REST)",
    description=(
        "External agents POST evidence about actions they performed. "
        "Authenticated via X-API-Key: ww_sk_* header. "
        "Writes to the Workweaver Evidence Ledger with full entity attribution."
    ),
)
async def ingest_external_evidence(
    body: ExternalEvidenceRequest,
    request: Request,
) -> EvidenceIngestResponse:
    """Ingest evidence from an external agent via REST API."""
    tenant_id = _resolve_tenant(request)

    try:
        evidence_svc = _get_service()
        timestamp = body.timestamp or datetime.now(UTC).isoformat()

        result = await evidence_svc.async_ingest(
            tenant_id=tenant_id,
            event_type=f"external:{body.action_type}",
            data={
                "actor_id": body.actor_id,
                "input_summary": body.input_summary,
                "output_summary": body.output_summary,
                "decision_rationale": body.decision_rationale,
                "metadata": body.metadata,
                "source": "eaas_rest",
                "external_timestamp": timestamp,
            },
            actor_path=body.actor_id,
            entity_id=body.entity_id,
        )

        return EvidenceIngestResponse(
            evidence_id=result["evidence_id"],
            status="accepted",
            ingested_at=datetime.now(UTC).isoformat(),
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("EaaS REST ingest failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to ingest evidence",
        )


@router.post(
    "/otlp",
    response_model=EvidenceIngestResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Ingest OpenTelemetry OTLP spans as evidence",
    description=(
        "External agents send standard OTLP/JSON resource_spans. "
        "Workweaver extracts ww.* span attributes for evidence attribution. "
        "Authenticated via X-API-Key: ww_sk_* header."
    ),
)
async def ingest_otlp_spans(
    body: OTelSpanRequest,
    request: Request,
) -> EvidenceIngestResponse:
    """Ingest OpenTelemetry OTLP spans as evidence entries."""
    tenant_id = _resolve_tenant(request)

    try:
        evidence_svc = _get_service()
        ingested_count = 0
        last_evidence_id = "none"

        for resource_span in body.resource_spans:
            scope_spans = resource_span.get("scope_spans") or resource_span.get("scopeSpans") or []
            for scope_span in scope_spans:
                for span in scope_span.get("spans") or []:
                    attrs = _extract_otlp_attributes(span.get("attributes") or [])

                    # Map ww.* attributes to EvidenceLedgerService fields
                    action_type = attrs.get("ww.action_type") or span.get("name") or "unknown"
                    actor_id = str(attrs.get("ww.actor_id") or "otlp-agent")
                    entity_id_val = attrs.get("ww.entity_id")
                    entity_id = str(entity_id_val) if entity_id_val else None

                    result = await evidence_svc.async_ingest(
                        tenant_id=tenant_id,
                        event_type=f"external:{action_type}",
                        data={
                            "actor_id": actor_id,
                            "input_summary": attrs.get("ww.input_summary"),
                            "output_summary": attrs.get("ww.output_summary"),
                            "decision_rationale": attrs.get("ww.decision_rationale"),
                            "tool_called": attrs.get("ww.tool_called"),
                            "outcome": attrs.get("ww.outcome"),
                            "span_id": span.get("spanId"),
                            "trace_id": span.get("traceId"),
                            "source": "eaas_otlp",
                        },
                        actor_path=actor_id,
                        entity_id=entity_id,
                    )

                    last_evidence_id = result["evidence_id"]
                    ingested_count += 1

        return EvidenceIngestResponse(
            evidence_id=last_evidence_id,
            status=f"accepted ({ingested_count} spans)",
            ingested_at=datetime.now(UTC).isoformat(),
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("EaaS OTLP ingest failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to ingest OTLP spans",
        )


# ============================================================================
# Helpers
# ============================================================================


def _extract_otlp_attributes(attributes: list[dict[str, Any]]) -> dict[str, Any]:
    """Extract a flat key->value dict from OTLP attribute array.

    OTLP attribute values are typed unions:
      {"key": "ww.actor_id", "value": {"stringValue": "agent-1"}}

    Returns a plain str->Any dict for easy consumption.
    """
    result: dict[str, Any] = {}
    for attr in attributes:
        key = attr.get("key") or ""
        value_obj = attr.get("value") or {}
        # Prefer the most common types; fall back to raw repr
        extracted: Any = (
            value_obj.get("stringValue")
            or value_obj.get("intValue")
            or value_obj.get("doubleValue")
            or value_obj.get("boolValue")
        )
        if extracted is None and value_obj:
            extracted = str(value_obj)
        result[key] = extracted
    return result
