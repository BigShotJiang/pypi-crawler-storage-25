"""Internal Agent Directory API — service-level peer discovery endpoint.

Used by AI agents at runtime to discover teammates without holding a
human JWT. Protected by a static internal token (X-Internal-Token header)
validated against the INTERNAL_API_TOKEN env var.

Endpoints:
  GET /internal/agents/{tenant_id}/{agent_id}/peers
  GET /internal/agents/{tenant_id}/find?name=...
  GET /internal/agents/{tenant_id}/find?skill=...
"""

from __future__ import annotations

import logging
import os
from typing import Any

from fastapi import APIRouter, Header, HTTPException

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/internal/agents", tags=["internal-agents"])

_INTERNAL_TOKEN = os.environ.get("INTERNAL_API_TOKEN", "")


def _check_internal_token(x_internal_token: str = Header(default="")) -> None:
    """Validate internal service token.

    Raises 403 if token is absent or does not match INTERNAL_API_TOKEN.
    When INTERNAL_API_TOKEN is not set (dev/test), always allow through.
    """
    if not _INTERNAL_TOKEN:
        logger.warning("INTERNAL_API_TOKEN not configured — rejecting request")
        raise HTTPException(status_code=403, detail="Internal API token not configured")
    if x_internal_token != _INTERNAL_TOKEN:
        raise HTTPException(status_code=403, detail="Invalid internal token")


@router.get("/{tenant_id}/{agent_id}/peers")
async def get_peers(
    tenant_id: str,
    agent_id: str,
    include_self: bool = False,
    entity_id: str | None = None,
    x_internal_token: str = Header(default=""),
) -> dict[str, Any]:
    """Return all agents in the same team as the requesting agent.

    This is the primary endpoint called from within agent execution context
    to enable peer-aware collaboration and delegation.

    Args:
        entity_id: RT-7: Optional entity scope filter. When provided, only
            peers belonging to the same entity (company/department/project)
            are returned. Enables Zara scoped entity behavior.

    Returns:
        {
          "agent_id": "...",
          "peers": [{"agent_id", "name", "role", "skills", "status"}, ...]
        }
    """
    _check_internal_token(x_internal_token)

    from apps.backend.services.agent_directory import get_agent_directory

    directory = get_agent_directory()
    peers = directory.get_peers(
        tenant_id,
        agent_id,
        include_self=include_self,
        entity_id=entity_id,
    )

    return {
        "agent_id": agent_id,
        "tenant_id": tenant_id,
        "peers": peers,
        "count": len(peers),
    }


@router.get("/{tenant_id}/find")
async def find_agent(
    tenant_id: str,
    name: str | None = None,
    skill: str | None = None,
    x_internal_token: str = Header(default=""),
) -> dict[str, Any]:
    """Find agents by name (fuzzy) or by required skill.

    At least one of name or skill must be provided.

    Returns:
        {"results": [{"agent_id", "name", "role", "skills", "status"}, ...]}
    """
    _check_internal_token(x_internal_token)

    if not name and not skill:
        raise HTTPException(status_code=400, detail="Provide at least one of: name, skill")

    from apps.backend.services.agent_directory import get_agent_directory

    directory = get_agent_directory()

    if name:
        match = directory.find_by_name(tenant_id, name)
        results = [match] if match else []
    else:
        assert skill is not None
        results = directory.find_by_skill(tenant_id, skill)

    return {"results": results, "count": len(results)}
