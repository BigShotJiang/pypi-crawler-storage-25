"""Omnibox API — parse and route user commands from the Runtime Shell omnibox.

Routes:
    POST /api/v1/omnibox/parse — Parse raw text into a structured command and route.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.omnibox_command_grammar import (
    CommandGrammarError,
    parse_command,
    route_command,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/omnibox", tags=["omnibox"])


class OmniboxParseRequest(BaseModel):
    """Request body for omnibox parsing."""

    raw_input: str = Field(..., min_length=1, max_length=500, description="Raw text typed into the omnibox")


class OmniboxParsedResponse(BaseModel):
    """Structured response after parsing and routing an omnibox command."""

    verb: str
    target: str
    sub_target: str | None = None
    is_fallback: bool = False
    metadata: dict[str, Any] = Field(default_factory=dict)
    handler: str
    params: dict[str, Any] = Field(default_factory=dict)
    keyboard_shortcut_hint: str = Field(
        default="Cmd+K / Ctrl+K to focus omnibox",
        description="Keyboard shortcut hint for the frontend",
    )


@router.post("/parse", response_model=OmniboxParsedResponse)
async def parse_omnibox(
    body: OmniboxParseRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> OmniboxParsedResponse:
    """Parse raw omnibox input into a structured command with routing info.

    The six-verb grammar (go, open, start, ask, review, configure) is used to
    interpret the input. Unrecognized text falls through to ``ask`` (Zara query).

    Returns:
        Parsed command with handler name and parameters for the frontend to dispatch.
    """
    try:
        command = parse_command(body.raw_input)
    except CommandGrammarError as exc:
        logger.error("Omnibox command parse error: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail="Validation error",
        ) from exc

    route = route_command(command)

    return OmniboxParsedResponse(
        verb=command.verb.value,
        target=command.target,
        sub_target=command.sub_target,
        is_fallback=command.is_fallback,
        metadata=command.metadata,
        handler=route.handler,
        params=route.params,
    )
