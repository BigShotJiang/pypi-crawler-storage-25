"""
Invite Token System — Alpha Launch Access Control.

Implements a 3-level access model for Workweaver alpha:
  Level 0 — Founders (@bitfoundry.ai): existing domain bypass
  Level 1 — Invited Beta: invite token system (this module)
  Level 2 — Waitlist: existing waitlist system

Legacy requirement reference: Section 0.5 Alpha Launch Specification

Endpoints:
  POST /api/v1/founder/invites      — Generate invite (admin only)
  GET  /api/v1/founder/invites      — List all invites (admin only)
  GET  /api/v1/invites/{token}      — Validate token (public)
  POST /api/v1/invites/{token}/consume — Mark used (internal, called during signup)
"""
from apps.backend.config.table_names import resolve_table

import logging
import os
import re
from apps.backend.config.region import AWS_REGION
import uuid
from datetime import datetime, timedelta, UTC
from typing import Literal

import boto3
from botocore.exceptions import ClientError
from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, EmailStr, Field

from apps.backend.api.founder_admin import require_founder
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.config.pricing import STRIPE_COUPONS

logger = logging.getLogger(__name__)

router = APIRouter()

INVITE_ITEM_PK_PREFIX = "INVITE#"
INVITE_METADATA_SK = "METADATA"
INVITE_ACCESS_CODE_RE = re.compile(r"^[A-Z0-9][A-Z0-9-]{2,31}$")

# Fan-out index: all-invites listing without table scan.
# pk=_INVITE_ALL_INDEX_PK, sk="INVITE#{token}" → enables list_invites via query.
_INVITE_ALL_INDEX_PK = "ALL_INVITES_INDEX"


# ============================================================================
# DynamoDB Table
# ============================================================================


def _get_invites_table():
    """Get DynamoDB table for invite tokens (same table as tenants for simplicity)."""
    region = AWS_REGION
    table_name = resolve_table("invites")
    try:
        profile = (os.environ.get("AWS_PROFILE") or os.environ.get("AWS_DEFAULT_PROFILE") or "").strip()
        if profile:
            try:
                session = boto3.Session(profile_name=profile, region_name=region)
            except Exception:
                session = boto3.Session(region_name=region)
        else:
            session = boto3.Session(region_name=region)
        dynamodb = session.resource("dynamodb", region_name=region)
        return dynamodb.Table(table_name)
    except Exception:
        logger.exception("Failed to initialize invites DynamoDB table")
        raise


# ============================================================================
# Request / Response Models
# ============================================================================


class CreateInviteRequest(BaseModel):
    """Request to generate a new invite token."""

    invited_email: EmailStr | None = Field(
        None,
        description="Pre-assign to a specific email. None = open invite (any email).",
    )
    product: Literal["workweaver", "workmemory", "both"] = Field(
        "workweaver",
        description="Which product the invite grants access to.",
    )
    workweaver_tier: Literal["launchpad", "growth", "enterprise"] | None = Field(
        None,
        description="Workweaver tier to provision. Required if product includes workweaver.",
    )
    workmemory_tier: Literal["starter", "pro", "team", "enterprise"] | None = Field(
        None,
        description="WorkMemory standalone tier. Required if product includes workmemory.",
    )
    discount_pct: int = Field(
        100,
        ge=0,
        le=100,
        description="Discount percentage (0=full price, 100=free, skip Stripe).",
    )
    max_uses: int = Field(
        1,
        ge=1,
        le=100,
        description="How many times this token can be used (1 for personal invites).",
    )
    expires_days: int = Field(
        30,
        ge=1,
        le=365,
        description="Token validity in days from creation.",
    )
    notes: str | None = Field(
        None,
        max_length=500,
        description="Admin context: e.g. 'Rahul - potential enterprise customer'.",
    )
    access_code: str | None = Field(
        None,
        min_length=3,
        max_length=32,
        description="Optional founder-issued human-readable access code such as WORK95.",
    )
    stripe_coupon_id: str | None = Field(
        None,
        max_length=128,
        description="Optional explicit Stripe coupon id for non-free discounted checkout.",
    )


class InviteTokenRecord(BaseModel):
    """Full invite token record (admin view)."""

    token: str
    access_code: str | None = None
    invited_by: str
    invited_email: str | None = None
    product: str
    workweaver_tier: str | None = None
    workmemory_tier: str | None = None
    discount_pct: int
    stripe_coupon_id: str | None = None
    max_uses: int
    uses_so_far: int
    expires_at: str
    status: str
    notes: str | None = None
    created_at: str
    invite_url: str


class InviteValidationResponse(BaseModel):
    """Public invite validation response (no admin data leaked)."""

    token: str
    valid: bool
    access_code: str | None = None
    product: str | None = None
    workweaver_tier: str | None = None
    workmemory_tier: str | None = None
    discount_pct: int | None = None
    invited_email: str | None = None
    expires_at: str | None = None
    error: str | None = None


class InviteListResponse(BaseModel):
    """Admin invite list response."""

    invites: list[InviteTokenRecord]
    total: int


# ============================================================================
# Invite Service
# ============================================================================


def _build_invite_url(token: str) -> str:
    base = os.getenv("FRONTEND_BASE_URL", "https://workweaver.ai").rstrip("/")
    return f"{base}/auth/?invite={token}"


def _normalize_invite_identifier(token: str) -> str:
    raw = str(token or "").strip()
    if not raw:
        return ""
    try:
        return str(uuid.UUID(raw))
    except ValueError:
        return raw.upper()


def _is_valid_invite_identifier(token: str) -> bool:
    normalized = _normalize_invite_identifier(token)
    if not normalized:
        return False
    try:
        uuid.UUID(normalized)
        return True
    except ValueError:
        return bool(INVITE_ACCESS_CODE_RE.fullmatch(normalized))


def _resolve_discount_coupon_id(
    *,
    discount_pct: int,
    access_code: str | None,
    explicit_coupon_id: str | None,
) -> str | None:
    if explicit_coupon_id:
        return explicit_coupon_id.strip() or None
    if discount_pct <= 0 or discount_pct >= 100:
        return None

    normalized_code = _normalize_invite_identifier(access_code or "")
    if normalized_code:
        env_key = f"STRIPE_COUPON_{normalized_code.replace('-', '_')}"
        env_coupon = (os.getenv(env_key) or "").strip()
        if env_coupon:
            return env_coupon

    if discount_pct == 95:
        return STRIPE_COUPONS.get("alpha_tester")
    if discount_pct == 50:
        return STRIPE_COUPONS.get("beta_tester")
    return None


def _to_invite_record(item: dict) -> InviteTokenRecord:
    token = item.get("token", "")
    return InviteTokenRecord(
        token=token,
        access_code=item.get("access_code"),
        invited_by=item.get("invited_by", ""),
        invited_email=item.get("invited_email"),
        product=item.get("product", "workweaver"),
        workweaver_tier=item.get("workweaver_tier"),
        workmemory_tier=item.get("workmemory_tier"),
        discount_pct=int(item.get("discount_pct", 100)),
        stripe_coupon_id=item.get("stripe_coupon_id"),
        max_uses=int(item.get("max_uses", 1)),
        uses_so_far=int(item.get("uses_so_far", 0)),
        expires_at=item.get("expires_at", ""),
        status=item.get("invite_status", "active"),
        notes=item.get("notes"),
        created_at=item.get("created_at", ""),
        invite_url=_build_invite_url(token),
    )


def create_invite(req: CreateInviteRequest, invited_by: str) -> InviteTokenRecord:
    """Create and persist a new invite token."""
    token = _normalize_invite_identifier(req.access_code or "") or str(uuid.uuid4())
    if req.access_code and not _is_valid_invite_identifier(token):
        raise ValueError("invalid_access_code")

    workweaver_tier = req.workweaver_tier or ("launchpad" if req.product in {"workweaver", "both"} else None)
    workmemory_tier = req.workmemory_tier or ("starter" if req.product in {"workmemory", "both"} else None)

    now = datetime.now(UTC)
    expires_at = now + timedelta(days=req.expires_days)
    stripe_coupon_id = _resolve_discount_coupon_id(
        discount_pct=req.discount_pct,
        access_code=token if req.access_code else None,
        explicit_coupon_id=req.stripe_coupon_id,
    )

    item: dict = {
        "pk": f"{INVITE_ITEM_PK_PREFIX}{token}",
        "sk": INVITE_METADATA_SK,
        "token": token,
        "invited_by": invited_by,
        "product": req.product,
        "discount_pct": req.discount_pct,
        "max_uses": req.max_uses,
        "uses_so_far": 0,
        "expires_at": expires_at.isoformat(),
        "invite_status": "active",
        "created_at": now.isoformat(),
    }

    if req.access_code:
        item["access_code"] = token
    if req.invited_email:
        item["invited_email"] = req.invited_email.lower()
    if workweaver_tier:
        item["workweaver_tier"] = workweaver_tier
    if workmemory_tier:
        item["workmemory_tier"] = workmemory_tier
    if req.notes:
        item["notes"] = req.notes
    if stripe_coupon_id:
        item["stripe_coupon_id"] = stripe_coupon_id

    table = _get_invites_table()
    try:
        table.put_item(
            Item=item,
            ConditionExpression="attribute_not_exists(pk) AND attribute_not_exists(sk)",
        )
    except ClientError as exc:
        if exc.response.get("Error", {}).get("Code") == "ConditionalCheckFailedException":
            raise ValueError("invite_identifier_already_exists") from exc
        raise

    # Fan-out index record: enables list_invites() to use query instead of scan.
    # Best-effort — if this fails the invite still works; it just won't appear in admin lists.
    try:
        table.put_item(
            Item={
                "pk": _INVITE_ALL_INDEX_PK,
                "sk": f"INVITE#{token}",
                "token": token,
                "created_at": now.isoformat(),
            }
        )
    except Exception:
        logger.warning("Failed to write invite all-index entry for token=%s", token[:8] + "...", exc_info=True)

    logger.info(
        "Invite created: token=%s product=%s tier=%s discount=%d%% invited_by=%s",
        token[:8] + "...",
        req.product,
        workweaver_tier or workmemory_tier or "none",
        req.discount_pct,
        invited_by,
    )

    return _to_invite_record(item)


def get_invite(token: str) -> dict | None:
    """Fetch raw invite record by token. Returns None if not found."""
    token = _normalize_invite_identifier(token)
    table = _get_invites_table()
    resp = table.get_item(Key={"pk": f"{INVITE_ITEM_PK_PREFIX}{token}", "sk": INVITE_METADATA_SK})
    return resp.get("Item")


def validate_invite(token: str) -> InviteValidationResponse:
    """Validate a token and return public-safe response."""
    item = get_invite(token)
    if not item:
        return InviteValidationResponse(token=token, valid=False, error="invite_not_found")

    invite_status = item.get("invite_status", "active")
    if invite_status == "expired":
        return InviteValidationResponse(token=token, valid=False, error="invite_expired")
    if invite_status == "consumed":
        uses_so_far = int(item.get("uses_so_far", 0))
        max_uses = int(item.get("max_uses", 1))
        if uses_so_far >= max_uses:
            return InviteValidationResponse(token=token, valid=False, error="invite_consumed")

    expires_at_str = item.get("expires_at", "")
    if expires_at_str:
        try:
            expires_at_dt = datetime.fromisoformat(expires_at_str)
            if expires_at_dt < datetime.now(UTC):
                # Lazily mark expired in DynamoDB
                try:
                    _update_invite_status(token, "expired")
                except Exception:
                    logger.warning(
                        "Failed to mark invite as expired", extra={"token": token[:8] + "..."}, exc_info=True
                    )
                return InviteValidationResponse(token=token, valid=False, error="invite_expired")
        except ValueError:
            pass

    return InviteValidationResponse(
        token=token,
        valid=True,
        access_code=item.get("access_code"),
        product=item.get("product"),
        workweaver_tier=item.get("workweaver_tier"),
        workmemory_tier=item.get("workmemory_tier"),
        discount_pct=int(item.get("discount_pct", 100)),
        invited_email=item.get("invited_email"),
        expires_at=expires_at_str or None,
    )


def consume_invite(token: str, used_by_email: str) -> bool:
    """
    Atomically increment uses_so_far. Mark consumed when uses >= max_uses.

    Returns True on success, False if already consumed or expired.
    """
    token = _normalize_invite_identifier(token)
    item = get_invite(token)
    if not item:
        return False

    max_uses = int(item.get("max_uses", 1))
    uses_so_far = int(item.get("uses_so_far", 0))

    if uses_so_far >= max_uses:
        return False

    new_uses = uses_so_far + 1
    new_status = "consumed" if new_uses >= max_uses else "active"

    table = _get_invites_table()
    try:
        table.update_item(
            Key={"pk": f"{INVITE_ITEM_PK_PREFIX}{token}", "sk": INVITE_METADATA_SK},
            UpdateExpression="SET uses_so_far = :u, invite_status = :s, last_used_by = :e, last_used_at = :t",
            ConditionExpression="uses_so_far = :prev",
            ExpressionAttributeValues={
                ":u": new_uses,
                ":s": new_status,
                ":e": used_by_email,
                ":t": datetime.now(UTC).isoformat(),
                ":prev": uses_so_far,
            },
        )
        logger.info(
            "Invite consumed: token=%s uses=%d/%d email=%s", token[:8] + "...", new_uses, max_uses, used_by_email
        )
        return True
    except ClientError as e:
        if e.response["Error"]["Code"] == "ConditionalCheckFailedException":
            # Concurrent consumption — re-validate
            logger.warning("Concurrent invite consumption for token=%s", token[:8] + "...")
            return False
        raise


def _update_invite_status(token: str, new_status: str) -> None:
    token = _normalize_invite_identifier(token)
    table = _get_invites_table()
    table.update_item(
        Key={"pk": f"{INVITE_ITEM_PK_PREFIX}{token}", "sk": INVITE_METADATA_SK},
        UpdateExpression="SET invite_status = :s",
        ExpressionAttributeValues={":s": new_status},
    )


def list_invites() -> list[dict]:
    """List all invite records (admin only — called only by founder endpoints).

    Uses the ALL_INVITES_INDEX fan-out partition written by create_invite to avoid
    a full-table scan. Each index entry is resolved to the authoritative primary record.
    """
    from boto3.dynamodb.conditions import Key

    table = _get_invites_table()
    index_items: list[dict] = []
    kwargs: dict = {"KeyConditionExpression": Key("pk").eq(_INVITE_ALL_INDEX_PK)}
    while True:
        resp = table.query(**kwargs)
        index_items.extend(resp.get("Items", []))
        last_key = resp.get("LastEvaluatedKey")
        if not last_key:
            break
        kwargs["ExclusiveStartKey"] = last_key

    results: list[dict] = []
    for idx in index_items:
        token_val = str(idx.get("sk") or "").removeprefix("INVITE#")
        if not token_val:
            continue
        item = get_invite(token_val)
        if item:
            results.append(item)
    return results


# ============================================================================
# API Endpoints
# ============================================================================


@router.post(
    "/api/v1/founder/invites",
    response_model=InviteTokenRecord,
    status_code=status.HTTP_201_CREATED,
    summary="Generate invite token (admin only)",
    tags=["founder-admin"],
)
async def create_invite_endpoint(
    body: CreateInviteRequest,
    founder_email: str = Depends(require_founder),
) -> InviteTokenRecord:
    """Generate a new invite token. Requires founder authentication."""
    try:
        return create_invite(body, invited_by=founder_email)
    except Exception as e:
        logger.exception("Failed to create invite: %s", e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={"error": "invite_creation_failed", "message": str(e)},
        )


@router.get(
    "/api/v1/founder/invites",
    response_model=InviteListResponse,
    summary="List all invite tokens (admin only)",
    tags=["founder-admin"],
)
async def list_invites_endpoint(
    founder_email: str = Depends(require_founder),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> InviteListResponse:
    """List all invite tokens with status. Requires founder authentication."""
    items = list_invites()
    records = [_to_invite_record(item) for item in items]
    records.sort(key=lambda r: r.created_at, reverse=True)
    paged_records, total = paginate_items(records, pagination)
    return InviteListResponse(invites=paged_records, total=total)


@router.get(
    "/api/v1/invites/{token}",
    response_model=InviteValidationResponse,
    summary="Validate invite token (public)",
    tags=["invites"],
)
async def validate_invite_endpoint(token: str) -> InviteValidationResponse:
    """
    Public endpoint to validate an invite token.

    Returns product/tier/discount info. Never returns admin data (invited_by, notes).
    Frontend calls this when user enters/arrives with an invite token.
    """
    if not _is_valid_invite_identifier(token):
        return InviteValidationResponse(token=token, valid=False, error="invalid_token_format")

    return validate_invite(_normalize_invite_identifier(token))


@router.post(
    "/api/v1/invites/{token}/consume",
    status_code=status.HTTP_200_OK,
    summary="Mark invite token as used (internal)",
    tags=["invites"],
)
async def consume_invite_endpoint(
    token: str,
    request: Request,
) -> dict:
    """
    Mark an invite token as used. Called internally during signup after successful provisioning.

    This endpoint is callable without auth (signup has its own auth). The token is already
    validated during signup — this is a best-effort post-provisioning step.
    Rate-limited in production by the middleware; token UUID format provides sufficient
    entropy to prevent enumeration.
    """
    # Extract used_by from request body or query param
    body_data: dict = {}
    try:
        body_data = await request.json()
    except Exception:
        logger.debug("Request body parse failed", exc_info=True)
    used_by_email = body_data.get("email", "unknown")

    normalized_token = _normalize_invite_identifier(token)
    if not _is_valid_invite_identifier(normalized_token):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "invalid_token_format"},
        )

    success = consume_invite(normalized_token, used_by_email=used_by_email)
    if not success:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail={"error": "invite_already_consumed_or_expired"},
        )
    return {"status": "consumed"}
