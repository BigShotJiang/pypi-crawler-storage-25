"""UAT simulation router (issue #1151).

Why this exists
---------------
End-to-end UAT of inbound flows (email reply, calendar booking,
provider webhooks, virtual-clock backdating) previously required
real 48-hour waits. The ``cold-outreach-gate-b-reply-to-meeting``
scenario was literally unrunnable in CI. This module provides a
controlled simulation surface that generates the same internal
events as real inbound webhooks, tagged with ``uat_mode=True`` so
evidence records are auditable afterwards.

Safety design
-------------
The simulation router is **hard-gated** by three independent
checks, evaluated per-request (never cached):

1. ``WORKWEAVER_UAT_MODE`` env must equal ``1``, ``true``, or ``yes``.
2. ``WORKWEAVER_ENV`` must NOT be a production-like value (``prod``,
   ``production``) UNLESS ``WORKWEAVER_UAT_PROD_OVERRIDE`` also
   equals ``1``. The override exists for the single legitimate use
   case of running prod smoke tests against a disposable tenant
   immediately after a deploy; otherwise the router refuses even
   if UAT_MODE is true.
3. Each request carries an ``X-UAT-Signed-Token`` header whose
   JWT is signed with ``UAT_SIGNING_SECRET`` and exp < 15 min.
   Without a valid signature, every simulation endpoint returns
   403. This prevents an accidental flag flip from exposing the
   surface publicly.

All simulation endpoints are no-ops when the gate refuses — the
response is ``404 Not Found`` (not 403) so the existence of the
surface doesn't leak externally when the flag is off. A 403 is
only returned when UAT_MODE is ON but the signed token is
missing or invalid, so the UAT test harness knows to fix its
signing config.

Supported simulations
---------------------
* ``POST /api/v1/uat/simulate/email-reply`` — emits the same
  evidence event as an inbound IMAP/SES webhook.
* ``POST /api/v1/uat/simulate/meeting-booked`` — emits the same
  evidence event as a calendar provider booking webhook.
* ``POST /api/v1/uat/simulate/crm-stage`` — emits the same
  evidence event as a CRM stage-change webhook.
* ``POST /api/v1/uat/oauth/mint-test-token`` — returns a
  provider-like access token that the rest of the code can use
  without a real IdP round-trip.
* ``X-UAT-Virtual-Clock: <ISO>`` header backdates evidence
  events for retention/SLA testing.

All responses include ``uat_mode: true`` + the virtual clock (if
provided) so evidence rows are distinguishable from real traffic.
"""

from __future__ import annotations
from apps.backend.config.table_names import resolve_table

import logging
import os
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Request, status
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/uat", tags=["uat-simulation"])


# ---------------------------------------------------------------------------
# Gate helpers
# ---------------------------------------------------------------------------


def _uat_mode_enabled() -> bool:
    raw = os.environ.get("WORKWEAVER_UAT_MODE", "").strip().lower()
    return raw in {"1", "true", "yes"}


def _looks_like_production() -> bool:
    env = os.environ.get("WORKWEAVER_ENV", "").strip().lower()
    if env in {"prod", "production"}:
        return True
    # Tenants-table naming is another safety hint — "prod" suffix
    # usually means the real AWS account.
    tenants_table = resolve_table("tenants").strip().lower()
    return "prod" in tenants_table


def _prod_override() -> bool:
    raw = os.environ.get("WORKWEAVER_UAT_PROD_OVERRIDE", "").strip().lower()
    return raw in {"1", "true", "yes"}


def _signing_secret() -> str:
    return os.environ.get("UAT_SIGNING_SECRET", "").strip()


def _verify_uat_token(request: Request) -> dict[str, Any]:
    """Verify the ``X-UAT-Signed-Token`` JWT. Returns decoded claims.

    JWT is HS256-signed with ``UAT_SIGNING_SECRET`` and must include
    ``exp`` < 15 minutes from now. The claims ``tenant_id`` and
    ``actor`` are propagated into evidence records.
    """
    token = request.headers.get("X-UAT-Signed-Token", "").strip()
    if not token:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="UAT signed token required (X-UAT-Signed-Token header).",
        )

    secret = _signing_secret()
    if not secret:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                "UAT_SIGNING_SECRET is not configured on this environment. "
                "Refusing to run simulation endpoints with an unsigned token."
            ),
        )

    try:
        import jwt

        claims = jwt.decode(token, secret, algorithms=["HS256"])
    except Exception as exc:  # noqa: BLE001
        logger.warning("uat_token_verify_failed error=%s", type(exc).__name__)
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid UAT signed token.",
        ) from exc

    if not isinstance(claims, dict):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="UAT token claims are not a dict.",
        )
    return claims


def require_uat_mode(request: Request) -> dict[str, Any]:
    """Three-layer gate: UAT_MODE → prod-refusal → signed token.

    Returns the verified JWT claims so handlers can access
    ``tenant_id`` / ``actor`` without re-parsing.

    The ``404`` for UAT-off is deliberate: it makes the surface
    invisible to external callers so a misconfigured prod instance
    doesn't reveal the existence of simulation routes.
    """
    if not _uat_mode_enabled():
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Not Found",
        )

    if _looks_like_production() and not _prod_override():
        logger.critical(
            "uat_endpoint_refused_production url=%s",
            request.url.path,
        )
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Not Found",
        )

    return _verify_uat_token(request)


def _parse_virtual_clock(request: Request) -> datetime:
    """Extract the X-UAT-Virtual-Clock header, if present.

    Defaults to real-now when unset or invalid (virtual clock is
    opt-in per test).
    """
    raw = request.headers.get("X-UAT-Virtual-Clock", "").strip()
    if not raw:
        return datetime.now(UTC)
    try:
        parsed = datetime.fromisoformat(raw.replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=UTC)
        return parsed
    except ValueError:
        logger.warning("uat_virtual_clock_invalid value=%s", raw)
        return datetime.now(UTC)


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class EmailReplySimulationRequest(BaseModel):
    tenant_id: str = Field(..., min_length=1)
    prospect_email: str = Field(..., min_length=3)
    subject: str = Field(default="", max_length=512)
    body: str = Field(..., min_length=1, max_length=16_384)
    thread_id: str | None = None


class MeetingBookingSimulationRequest(BaseModel):
    tenant_id: str = Field(..., min_length=1)
    entity_id: str = Field(..., min_length=1, description="The prospect/account the meeting is for")
    attendee_email: str = Field(..., min_length=3)
    scheduled_at: str = Field(..., description="ISO 8601 timestamp of the booked meeting")
    provider: str = Field(default="calendly")


class CrmStageSimulationRequest(BaseModel):
    tenant_id: str = Field(..., min_length=1)
    entity_id: str = Field(..., min_length=1)
    from_stage: str = Field(..., min_length=1)
    to_stage: str = Field(..., min_length=1)
    provider: str = Field(default="zoho_crm")


class OAuthMintRequest(BaseModel):
    tenant_id: str = Field(..., min_length=1)
    provider: str = Field(..., min_length=1, description="e.g. google, microsoft, slack")
    scopes: list[str] = Field(default_factory=list)


class SimulationResponse(BaseModel):
    uat_mode: bool = True
    event_type: str
    evidence_id: str | None = None
    virtual_clock_at: str
    detail: dict[str, Any] = Field(default_factory=dict)


class OAuthMintResponse(BaseModel):
    uat_mode: bool = True
    provider: str
    access_token: str
    refresh_token: str
    expires_in: int = 3600
    scope: str
    virtual_clock_at: str


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _emit_uat_evidence(
    *,
    event_type: str,
    tenant_id: str,
    claims: dict[str, Any],
    virtual_clock_at: datetime,
    data: dict[str, Any],
) -> str | None:
    """Emit an evidence record tagged ``uat_mode=True`` so UAT
    events are distinguishable from real traffic in audit queries."""
    try:
        from apps.backend.services.evidence_ledger import get_evidence_ledger_service

        service = get_evidence_ledger_service()
        record = service.ingest(
            tenant_id=tenant_id,
            event_type=event_type,
            data={
                **data,
                "uat_mode": True,
                "uat_actor": str(claims.get("actor") or "unknown"),
                "virtual_clock_at": virtual_clock_at.isoformat(),
            },
            actor_path="uat_simulation",
        )
        return str(record.get("evidence_id") or "") or None
    except Exception:  # noqa: BLE001
        logger.warning(
            "uat_evidence_emit_failed event_type=%s tenant=%s",
            event_type,
            tenant_id,
            exc_info=True,
        )
        return None


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("/simulate/email-reply", response_model=SimulationResponse)
def simulate_email_reply(
    request: Request,
    body: EmailReplySimulationRequest,
    claims: dict[str, Any] = Depends(require_uat_mode),
) -> SimulationResponse:
    virtual_clock = _parse_virtual_clock(request)
    event_id = _emit_uat_evidence(
        event_type="evidence:inbound_email_reply",
        tenant_id=body.tenant_id,
        claims=claims,
        virtual_clock_at=virtual_clock,
        data={
            "prospect_email": body.prospect_email,
            "subject": body.subject,
            "body": body.body,
            "thread_id": body.thread_id,
            "direction": "inbound",
        },
    )
    return SimulationResponse(
        event_type="inbound_email_reply",
        evidence_id=event_id,
        virtual_clock_at=virtual_clock.isoformat(),
        detail={
            "prospect_email": body.prospect_email,
            "thread_id": body.thread_id,
        },
    )


@router.post("/simulate/meeting-booked", response_model=SimulationResponse)
def simulate_meeting_booked(
    request: Request,
    body: MeetingBookingSimulationRequest,
    claims: dict[str, Any] = Depends(require_uat_mode),
) -> SimulationResponse:
    virtual_clock = _parse_virtual_clock(request)
    event_id = _emit_uat_evidence(
        event_type="evidence:meeting_booked",
        tenant_id=body.tenant_id,
        claims=claims,
        virtual_clock_at=virtual_clock,
        data={
            "entity_id": body.entity_id,
            "attendee_email": body.attendee_email,
            "scheduled_at": body.scheduled_at,
            "provider": body.provider,
        },
    )
    return SimulationResponse(
        event_type="meeting_booked",
        evidence_id=event_id,
        virtual_clock_at=virtual_clock.isoformat(),
        detail={"entity_id": body.entity_id, "provider": body.provider},
    )


@router.post("/simulate/crm-stage", response_model=SimulationResponse)
def simulate_crm_stage(
    request: Request,
    body: CrmStageSimulationRequest,
    claims: dict[str, Any] = Depends(require_uat_mode),
) -> SimulationResponse:
    virtual_clock = _parse_virtual_clock(request)
    event_id = _emit_uat_evidence(
        event_type="evidence:crm_stage_change",
        tenant_id=body.tenant_id,
        claims=claims,
        virtual_clock_at=virtual_clock,
        data={
            "entity_id": body.entity_id,
            "from_stage": body.from_stage,
            "to_stage": body.to_stage,
            "provider": body.provider,
        },
    )
    return SimulationResponse(
        event_type="crm_stage_change",
        evidence_id=event_id,
        virtual_clock_at=virtual_clock.isoformat(),
        detail={
            "entity_id": body.entity_id,
            "from_stage": body.from_stage,
            "to_stage": body.to_stage,
        },
    )


@router.post("/oauth/mint-test-token", response_model=OAuthMintResponse)
def mint_test_oauth_token(
    request: Request,
    body: OAuthMintRequest,
    claims: dict[str, Any] = Depends(require_uat_mode),
) -> OAuthMintResponse:
    """Mint a provider-looking access token for UAT without hitting
    the real IdP. Token is an opaque random string — downstream
    code that wants to make a real API call with it must have a
    UAT-mode branch that recognizes tokens starting with ``uat-``
    and short-circuits to fixture responses."""
    import secrets

    virtual_clock = _parse_virtual_clock(request)
    access_token = f"uat-{body.provider}-{secrets.token_urlsafe(24)}"
    refresh_token = f"uat-refresh-{secrets.token_urlsafe(24)}"
    scope = " ".join(body.scopes)

    _emit_uat_evidence(
        event_type="evidence:oauth_test_token_minted",
        tenant_id=body.tenant_id,
        claims=claims,
        virtual_clock_at=virtual_clock,
        data={
            "provider": body.provider,
            "scopes": body.scopes,
            # Never log the access token itself — only the prefix
            # so ops can correlate without leaking secret material.
            "token_prefix": access_token[:16] + "...",
        },
    )
    return OAuthMintResponse(
        provider=body.provider,
        access_token=access_token,
        refresh_token=refresh_token,
        scope=scope,
        virtual_clock_at=virtual_clock.isoformat(),
    )


__all__ = [
    "router",
    "require_uat_mode",
]
