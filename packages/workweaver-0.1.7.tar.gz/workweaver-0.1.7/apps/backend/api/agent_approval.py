"""Agent Approval API endpoint.

Provides POST /api/v1/approval/request for Workweaver Runtime plugin approval tool.
Response matches plugin TypeScript interface:
  {request_id: string, status: string, approver?: string, message?: string}
"""

from __future__ import annotations

import logging
from typing import Any, Literal
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.approval_service import ApprovalService
from apps.backend.services.approval_gates import get_approval_gates
from apps.backend.services.execution.guard_service import (
    AutomationLevel,
    PolicyVerdict,
    approval_request_id,
    approval_request_status,
    get_execution_guard,
)
from apps.backend.services.policy_tools import canonical_policy_tool_name, policy_tool_requires_identity
from apps.backend.services.tool_permission_service import ToolPermissionService
logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/approval", tags=["agent-approval"])
_tool_permission_service: ToolPermissionService | None = None


def _get_tool_permission_service() -> ToolPermissionService:
    global _tool_permission_service
    if _tool_permission_service is None:
        _tool_permission_service = ToolPermissionService()
    return _tool_permission_service


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class ApprovalRequestBody(BaseModel):
    """Request model matching Workweaver Runtime plugin ApprovalRequest."""

    action: str = Field(..., description="Action requiring approval")
    reason: str = Field(..., description="Why approval is needed")
    risk_level: Literal["low", "medium", "high", "critical"] | None = Field(
        None, description="Risk level of the action"
    )
    details: dict[str, Any] | None = Field(None, description="Additional context")
    timeout_seconds: int | None = Field(None, ge=1, description="Approval timeout")


class ApprovalResponse(BaseModel):
    """Response model matching Workweaver Runtime plugin ApprovalResponse.

    Exactly: {request_id: string, status: string, approver?: string, message?: string}
    """

    request_id: str = Field(..., description="Unique approval request identifier")
    status: str = Field(..., description="Approval status: pending | approved | rejected")
    approver: str | None = Field(None, description="Who approved (if auto-approved)")
    message: str | None = Field(None, description="Human-readable message")


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------


@router.post("/request", response_model=ApprovalResponse)
async def create_approval_request(
    request: ApprovalRequestBody,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ApprovalResponse:
    """Create an approval request on behalf of an AI agent.

    Low risk actions are auto-approved. All others are pending.
    Real approval workflow integration uses ApprovalGates service.
    """
    logger.info(
        "Agent approval request: tenant=%s action=%s risk=%s",
        tenant_id,
        request.action,
        request.risk_level,
    )

    # Optional runtime permission pre-check when agent context is provided.
    agent_id = None
    if isinstance(request.details, dict):
        agent_id = request.details.get("agent_id")
    if isinstance(agent_id, str) and agent_id.strip():
        permission = _get_tool_permission_service().check_permission(
            tenant_id=tenant_id,
            agent_id=agent_id.strip(),
            tool_name=request.action,
        )
        if not permission.allowed:
            return ApprovalResponse(
                request_id="rejected-by-policy",
                status="rejected",
                approver="policy",
                message=permission.reason,
            )
        if permission.requires_approval:
            request.risk_level = request.risk_level or "high"

    details = request.details or {}
    guard_agent_id = str(details.get("agent_id") or "").strip() or None
    guard_entity_id = str(details.get("entity_id") or details.get("agent_id") or "").strip() or None
    guard = get_execution_guard()
    operation_type = guard.infer_operation_type(
        request.action,
        _lower_text(details.get("operation_type")),
        details,
    )
    policy_tool_name = canonical_policy_tool_name(request.action, operation_type)
    guard_session_id = _approval_session_id(details, policy_tool_name)
    missing_execution_identity = policy_tool_requires_identity(policy_tool_name, operation_type) and not guard_entity_id
    decision_context = {
        key: value
        for key, value in {
            "trace_id": details.get("trace_id"),
            "risk_level": request.risk_level,
            "timeout_seconds": request.timeout_seconds,
            "source": details.get("source") or "agent_approval_api",
            "policy_tool_name": policy_tool_name,
            "missing_execution_identity": missing_execution_identity,
        }.items()
        if value is not None
    }
    decision = guard.evaluate(
        tenant_id=tenant_id,
        tool_id=request.action,
        operation_type=operation_type,
        automation_level=AutomationLevel.AUTO_EXECUTE_SAFE,
        inputs=details,
        agent_id=guard_agent_id,
        entity_id=guard_entity_id,
        session_id=guard_session_id,
        policy_tool_name=policy_tool_name,
        capture_surface="approval_api",
        service_family="agent_approval",
        context_data=decision_context or None,
    )

    if decision.verdict == PolicyVerdict.DENY:
        return ApprovalResponse(
            request_id="rejected-by-policy",
            status="rejected",
            approver="policy",
            message=f"Policy denied action: {', '.join(decision.reasons)}",
        )

    if (
        request.risk_level == "low"
        and decision.verdict != PolicyVerdict.REQUIRE_APPROVAL
        and not missing_execution_identity
    ):
        return ApprovalResponse(
            request_id="approved-by-policy",
            status="approved",
            approver="system",
            message=f"Auto-approved low-risk action: {request.action}",
        )

    try:
        approval = ApprovalService(approval_gates=get_approval_gates()).request_tool_approval(
            tenant_id=tenant_id,
            session_id=guard_session_id,
            user_id=str(details.get("agent_id") or details.get("user_id") or "agent:runtime").strip(),
            tool_name=policy_tool_name,
            tool_params=details,
            metadata={
                "source": "agent_approval_api",
                "reason": request.reason,
                "risk_level": request.risk_level,
                "decision_reasons": decision.reasons,
                "timeout_seconds": request.timeout_seconds,
                "policy_tool_name": policy_tool_name,
                "missing_execution_identity": missing_execution_identity,
            },
        )
    except Exception as exc:
        logger.warning("Approval request creation failed for action=%s", request.action, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Approval system unavailable",
        ) from exc
    approval_request = approval.approval_request
    request_id = approval_request_id(approval_request)
    if not approval.success or approval_request is None or not request_id:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Approval system unavailable",
        )

    return ApprovalResponse(
        request_id=request_id,
        status=approval_request_status(approval_request) or "pending",
        message=f"Approval required for action: {request.action}",
    )


def _lower_text(value: Any) -> str:
    return str(value or "").strip().lower()


def _approval_session_id(details: dict[str, Any], policy_tool_name: str) -> str:
    for key in ("session_id", "run_id", "trace_id"):
        value = str(details.get(key) or "").strip()
        if value:
            return value
    return f"approval-request:{policy_tool_name}:{uuid4().hex}"
