"""Tenant-scoped Operational Context API."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.context.decision_event_capture import (
    DecisionEventCaptureService,
)
from apps.backend.services.operational_context_list import (
    CursorDecodeError,
    OperationalContextListResponse,
    OperationalContextListService,
)
from apps.backend.services.operational_context_read_model import (
    OperationalContextReadModelService,
    OperationalContextSubjectResponse,
    get_operational_context_read_model_service,
)

router = APIRouter(prefix="/api/v1/operational-context", tags=["operational-context"])


def _get_operational_context_read_model_service() -> OperationalContextReadModelService:
    return get_operational_context_read_model_service()


def _get_decision_event_capture_service() -> DecisionEventCaptureService:
    """Dependency seam for the underlying decision-event store.

    The list endpoint constructs ``OperationalContextListService`` per request
    so tests can swap the capture service via FastAPI's ``dependency_overrides``
    without hitting cloud backends.
    """
    return DecisionEventCaptureService()


def _build_list_service(
    capture_service: DecisionEventCaptureService = Depends(
        _get_decision_event_capture_service
    ),
) -> OperationalContextListService:
    return OperationalContextListService(capture_service=capture_service)


@router.get("", response_model=OperationalContextListResponse)
async def list_operational_context(
    actor: str | None = Query(None, description="Filter by originating actor (skill_id)"),
    kind: str | None = Query(
        None, description="Filter by entry kind (decision_type)"
    ),
    since: str | None = Query(
        None, description="ISO 8601 timestamp; entries strictly older are dropped"
    ),
    filter_query: str | None = Query(
        None,
        alias="filter",
        description="Free-text token match against summary/rationale/alternatives",
    ),
    cursor: str | None = Query(
        None, description="Opaque cursor returned by previous page"
    ),
    limit: int = Query(50, ge=1, le=200, description="Page size, max 200"),
    tenant_id: str = Depends(get_verified_tenant_id),
    list_service: OperationalContextListService = Depends(_build_list_service),
) -> OperationalContextListResponse:
    """Cursor-paginated Operational Context list (#2739 backend)."""
    try:
        return list_service.list(
            tenant_id=tenant_id,
            actor=actor,
            kind=kind,
            since=since,
            filter_query=filter_query,
            limit=limit,
            cursor=cursor,
        )
    except CursorDecodeError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"invalid cursor: {exc}",
        ) from exc


@router.get("/{subject_id}", response_model=OperationalContextSubjectResponse)
async def show_operational_context(
    subject_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    service: OperationalContextReadModelService = Depends(_get_operational_context_read_model_service),
) -> Any:
    return await service.get_subject(tenant_id=tenant_id, subject_id=subject_id)
