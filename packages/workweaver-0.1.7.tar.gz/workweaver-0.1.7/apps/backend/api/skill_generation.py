"""Skill Generation API for Workweaver Auto-Skill Generation.

This module provides REST API endpoints for auto-generating skills from:
- Interview responses
- Document processing
- Pattern learning

Includes endpoints for:
- Generating skill drafts
- Listing pending drafts
- Approving/rejecting/editing drafts
- Getting draft details

Reference: docs/PRODUCT.md P1.7E.1 — Auto-Skill Generation
"""

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Path, Query, status
from pydantic import BaseModel, Field

from apps.backend.middleware.tenant_isolation import get_tenant_id, get_user_id
from apps.backend.services.skills.skill_generator import (
    InterviewSkillGenerationRequest,
    DocumentSkillGenerationRequest,
    SkillGenerator,
    SkillGeneratorError,
    SkillDraft,
)

logger = logging.getLogger(__name__)

# ============================================================================
# Router
# ============================================================================

router = APIRouter(
    prefix="/api/v1/skills/generation",
    tags=["skill-generation"],
)

# ============================================================================
# Pydantic Models for API
# ============================================================================


class GenerateFromInterviewRequest(BaseModel):
    """Request to generate skills from interview."""

    interview_id: str = Field(
        ...,
        max_length=100,
        description="Interview ID to generate skills from",
    )
    interview_data: dict[str, Any] = Field(
        ...,
        description="Interview data including all completed steps",
    )


class GenerateFromDocumentRequest(BaseModel):
    """Request to generate skills from document."""

    document_id: str = Field(
        ...,
        max_length=100,
        description="Document ID to generate skills from",
    )
    document_data: dict[str, Any] = Field(
        ...,
        description="Document data including extracted facts",
    )


class ApproveDraftRequest(BaseModel):
    """Request to approve a skill draft."""

    reviewer_id: str = Field(
        ...,
        max_length=100,
        description="User ID approving the draft",
    )


class RejectDraftRequest(BaseModel):
    """Request to reject a skill draft."""

    reviewer_id: str = Field(
        ...,
        max_length=100,
        description="User ID rejecting the draft",
    )
    reason: str = Field(
        ...,
        min_length=10,
        max_length=1000,
        description="Rejection reason",
    )


class EditDraftRequest(BaseModel):
    """Request to edit a skill draft."""

    editor_id: str = Field(
        ...,
        max_length=100,
        description="User ID editing the draft",
    )
    edited_definition: dict[str, Any] = Field(
        ...,
        description="Edited skill definition",
    )


class DraftResponse(BaseModel):
    """Response model for skill draft."""

    draft_id: str
    tenant_id: str
    user_id: str
    generation_type: str
    source_id: str | None
    display_name: str
    description: str
    parsed_definition: dict[str, Any]
    approval_status: str
    rejection_reason: str | None
    edited_definition: dict[str, Any] | None
    created_at: str
    reviewed_at: str | None
    reviewed_by: str | None
    suggested_confidence: float
    reasoning: str | None
    required_tools: list[str]

    @classmethod
    def from_draft(cls, draft: SkillDraft) -> "DraftResponse":
        """Create response from SkillDraft."""
        return cls(
            draft_id=draft.draft_id,
            tenant_id=draft.tenant_id,
            user_id=draft.user_id,
            generation_type=draft.generation_type.value,
            source_id=draft.source_id,
            display_name=draft.display_name,
            description=draft.description,
            parsed_definition=draft.parsed_definition,
            approval_status=draft.approval_status.value,
            rejection_reason=draft.rejection_reason,
            edited_definition=draft.edited_definition,
            created_at=draft.created_at.isoformat(),
            reviewed_at=draft.reviewed_at.isoformat() if draft.reviewed_at else None,
            reviewed_by=draft.reviewed_by,
            suggested_confidence=draft.suggested_confidence,
            reasoning=draft.reasoning,
            required_tools=draft.required_tools,
        )


class GenerationResponse(BaseModel):
    """Response model for skill generation."""

    success: bool
    drafts_generated: int
    draft_ids: list[str]
    errors: list[str]

    @classmethod
    def from_result(cls, result) -> "GenerationResponse":
        """Create response from SkillGenerationResult."""
        return cls(
            success=result.success,
            drafts_generated=result.drafts_generated,
            draft_ids=result.draft_ids,
            errors=result.errors,
        )


# ============================================================================
# Dependencies
# ============================================================================


def get_skill_generator() -> SkillGenerator:
    """Get SkillGenerator instance."""
    return SkillGenerator()


# ============================================================================
# API Endpoints
# ============================================================================


@router.post(
    "/interview",
    response_model=GenerationResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Generate skills from interview",
    description="Automatically generate skill drafts from completed interview data",
)
async def generate_from_interview(
    request: GenerateFromInterviewRequest,
    tenant_id: str = Depends(get_tenant_id),
    user_id: str = Depends(get_user_id),
    generator: SkillGenerator = Depends(get_skill_generator),
) -> GenerationResponse:
    """
    Generate skill drafts from interview responses.

    Analyzes interview data including business understanding, connected tools,
    and workflow preferences to suggest relevant automation skills.

    Args:
        request: Generation request with interview_id and interview_data
        tenant_id: Tenant ID from middleware
        user_id: User ID from middleware
        generator: SkillGenerator instance

    Returns:
        GenerationResponse with list of generated draft IDs

    Raises:
        HTTPException: If generation fails
    """
    try:
        logger.info(f"Generating skills from interview {request.interview_id} for tenant {tenant_id}")

        # Create internal request
        internal_request = InterviewSkillGenerationRequest(
            tenant_id=tenant_id,
            user_id=user_id,
            interview_id=request.interview_id,
        )

        # Generate skills
        result = await generator.generate_from_interview(
            request=internal_request,
            interview_data=request.interview_data,
        )

        return GenerationResponse.from_result(result)

    except Exception as e:
        logger.error(f"Failed to generate skills from interview: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Skill generation failed",
        )


@router.post(
    "/document",
    response_model=GenerationResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Generate skills from document",
    description="Automatically generate skill drafts from processed document data",
)
async def generate_from_document(
    request: GenerateFromDocumentRequest,
    tenant_id: str = Depends(get_tenant_id),
    user_id: str = Depends(get_user_id),
    generator: SkillGenerator = Depends(get_skill_generator),
) -> GenerationResponse:
    """
    Generate skill drafts from document processing.

    Analyzes document text and extracted facts to identify operational
    patterns and suggest automation skills.

    Args:
        request: Generation request with document_id and document_data
        tenant_id: Tenant ID from middleware
        user_id: User ID from middleware
        generator: SkillGenerator instance

    Returns:
        GenerationResponse with list of generated draft IDs

    Raises:
        HTTPException: If generation fails
    """
    try:
        logger.info(f"Generating skills from document {request.document_id} for tenant {tenant_id}")

        # Create internal request
        internal_request = DocumentSkillGenerationRequest(
            tenant_id=tenant_id,
            user_id=user_id,
            document_id=request.document_id,
        )

        # Generate skills
        result = await generator.generate_from_document(
            request=internal_request,
            document_data=request.document_data,
        )

        return GenerationResponse.from_result(result)

    except Exception as e:
        logger.error(f"Failed to generate skills from document: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Skill generation failed",
        )


@router.get(
    "/drafts/pending",
    response_model=list[DraftResponse],
    summary="List pending skill drafts",
    description="Get all pending skill drafts for the current tenant",
)
async def list_pending_drafts(
    tenant_id: str = Depends(get_tenant_id),
    generator: SkillGenerator = Depends(get_skill_generator),
    limit: int = Query(100, ge=1, le=500, description="Max drafts to return"),
) -> list[DraftResponse]:
    """
    List all pending skill drafts for review.

    Args:
        tenant_id: Tenant ID from middleware
        generator: SkillGenerator instance
        limit: Max drafts to return

    Returns:
        List of pending DraftResponse objects

    Raises:
        HTTPException: If listing fails
    """
    try:
        logger.info(f"Listing pending drafts for tenant {tenant_id}")

        drafts = await generator.list_pending_drafts(tenant_id)

        return [DraftResponse.from_draft(d) for d in drafts[:limit]]

    except Exception as e:
        logger.error(f"Failed to list pending drafts: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to list drafts",
        )


@router.get(
    "/drafts/{draft_id}",
    response_model=DraftResponse,
    summary="Get skill draft details",
    description="Get details of a specific skill draft",
)
async def get_draft(
    draft_id: str = Path(..., description="Draft ID"),
    tenant_id: str = Depends(get_tenant_id),
    generator: SkillGenerator = Depends(get_skill_generator),
) -> DraftResponse:
    """
    Get details of a specific skill draft.

    Args:
        draft_id: Draft ID
        tenant_id: Tenant ID from middleware
        generator: SkillGenerator instance

    Returns:
        DraftResponse with draft details

    Raises:
        HTTPException: If draft not found
    """
    try:
        logger.info(f"Getting draft {draft_id} for tenant {tenant_id}")

        # Get draft using internal method
        draft = await generator._get_draft(draft_id, tenant_id)

        return DraftResponse.from_draft(draft)

    except SkillGeneratorError as e:
        logger.error(f"Draft not found: {e}")
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Draft not found",
        )
    except Exception as e:
        logger.error(f"Failed to get draft: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to get draft",
        )


@router.post(
    "/drafts/{draft_id}/approve",
    response_model=DraftResponse,
    summary="Approve skill draft",
    description="Approve a skill draft for registration in the skill system",
)
async def approve_draft(
    draft_id: str = Path(..., description="Draft ID"),
    request: ApproveDraftRequest = ...,
    tenant_id: str = Depends(get_tenant_id),
    generator: SkillGenerator = Depends(get_skill_generator),
) -> DraftResponse:
    """
    Approve a skill draft.

    Marks the draft as approved. Approved skills should be registered
    in the skill system for execution.

    Args:
        draft_id: Draft ID to approve
        request: Approve request with reviewer_id
        tenant_id: Tenant ID from middleware
        generator: SkillGenerator instance

    Returns:
        Updated DraftResponse

    Raises:
        HTTPException: If approval fails
    """
    try:
        logger.info(f"Approving draft {draft_id} by {request.reviewer_id}")

        draft = await generator.approve_draft(
            draft_id=draft_id,
            tenant_id=tenant_id,
            reviewer_id=request.reviewer_id,
        )

        return DraftResponse.from_draft(draft)

    except SkillGeneratorError as e:
        logger.error(f"Approval failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Draft approval failed",
        )
    except Exception as e:
        logger.error(f"Failed to approve draft: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Approval failed",
        )


@router.post(
    "/drafts/{draft_id}/reject",
    response_model=DraftResponse,
    summary="Reject skill draft",
    description="Reject a skill draft with a reason",
)
async def reject_draft(
    draft_id: str = Path(..., description="Draft ID"),
    request: RejectDraftRequest = ...,
    tenant_id: str = Depends(get_tenant_id),
    generator: SkillGenerator = Depends(get_skill_generator),
) -> DraftResponse:
    """
    Reject a skill draft.

    Marks the draft as rejected with a reason.

    Args:
        draft_id: Draft ID to reject
        request: Reject request with reviewer_id and reason
        tenant_id: Tenant ID from middleware
        generator: SkillGenerator instance

    Returns:
        Updated DraftResponse

    Raises:
        HTTPException: If rejection fails
    """
    try:
        logger.info(f"Rejecting draft {draft_id} by {request.reviewer_id}")

        draft = await generator.reject_draft(
            draft_id=draft_id,
            tenant_id=tenant_id,
            reviewer_id=request.reviewer_id,
            reason=request.reason,
        )

        return DraftResponse.from_draft(draft)

    except SkillGeneratorError as e:
        logger.error(f"Rejection failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Draft rejection failed",
        )
    except Exception as e:
        logger.error(f"Failed to reject draft: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Rejection failed",
        )


@router.post(
    "/drafts/{draft_id}/edit",
    response_model=DraftResponse,
    summary="Edit skill draft",
    description="Edit a skill draft before approval",
)
async def edit_draft(
    draft_id: str = Path(..., description="Draft ID"),
    request: EditDraftRequest = ...,
    tenant_id: str = Depends(get_tenant_id),
    generator: SkillGenerator = Depends(get_skill_generator),
) -> DraftResponse:
    """
    Edit a skill draft.

    Allows editing the skill definition before approval.

    Args:
        draft_id: Draft ID to edit
        request: Edit request with editor_id and edited_definition
        tenant_id: Tenant ID from middleware
        generator: SkillGenerator instance

    Returns:
        Updated DraftResponse

    Raises:
        HTTPException: If edit fails
    """
    try:
        logger.info(f"Editing draft {draft_id} by {request.editor_id}")

        draft = await generator.edit_draft(
            draft_id=draft_id,
            tenant_id=tenant_id,
            editor_id=request.editor_id,
            edited_definition=request.edited_definition,
        )

        return DraftResponse.from_draft(draft)

    except SkillGeneratorError as e:
        logger.error(f"Edit failed: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Draft edit failed",
        )
    except Exception as e:
        logger.error(f"Failed to edit draft: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Edit failed",
        )
