"""Admin-scoped REST router package.

Each module under this package exposes a FastAPI ``router`` mounted under
``/api/v1/admin/...`` and gated by the tenant_admin role plus an explicit
``AdminPermission`` scope.
"""
