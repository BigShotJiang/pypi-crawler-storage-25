"""Admin-scoped tenant member management.

Mirrors the canonical workspace-members surface but lives under the
``/api/v1/admin`` namespace so the admin UI has a stable URL that does not
encode a workspace path parameter. Reads + writes are scoped to the
caller's tenant via :func:`get_verified_tenant_id`.

Routes:

- GET  /api/v1/admin/members           list tenant members (cursor-paginated).
- POST /api/v1/admin/members/invite    invite a new member.

The list endpoint returns the same payload shape as the canonical
``/api/v1/workspaces/{wid}/members`` so existing UI components can switch URL
strings without re-mapping fields. The invite endpoint emits a
DecisionEventCaptureService trace on success.
"""

from __future__ import annotations

import logging
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, EmailStr, Field

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_email,
    require_admin_user_role,
)
from apps.backend.models.user import UserRole
from apps.backend.services.admin.admin_permission import AdminPermission
from apps.backend.services.user_management import (
    UserManagementError,
    UserManagementService,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/admin/members", tags=["admin-members"])

# Roster scan cap — fetched from the store once, then offset-sliced in-process
# so cursors reliably reach the back of the roster. `UserManagementService.list_users`
# does not (yet) accept a cursor argument, so the admin endpoint takes the
# pragmatic path: pull a generous bound and paginate locally. A tenant
# exceeding this cap is a hard signal to extend the service with native
# cursor support; admins see a warning log when it happens.
_ROSTER_SCAN_CAP = 5000


def _get_user_management_service() -> UserManagementService:
    return UserManagementService()


def _get_decision_capture() -> Any:
    from apps.backend.services.context.decision_event_capture import (
        DecisionEventCaptureService,
    )

    return DecisionEventCaptureService()


class InviteMemberRequest(BaseModel):
    member_email: EmailStr = Field(..., description="Email of the member to invite.")
    role: UserRole = Field(UserRole.AGENT, description="Role for the invited member.")


@router.get("")
async def list_admin_members(
    cursor: Annotated[str | None, Query(description="Cursor returned by the previous page.")] = None,
    limit: Annotated[int, Query(ge=1, le=500, description="Max members per page.")] = 100,
    role_filter: Annotated[UserRole | None, Query(alias="role")] = None,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.MEMBERS_READ)),
    tenant_id: str = Depends(get_verified_tenant_id),
    service: UserManagementService = Depends(_get_user_management_service),
) -> dict[str, Any]:
    """Return the tenant member roster (paginated, cursor-based)."""

    del admin_role
    try:
        # Pull up to the scan cap so cursor offsets are computed against the
        # full tenant roster, not a single page. Codex review #3621 P1 flagged
        # the previous shape (service-level limit + in-process slicing) as a
        # pagination dead-end past the first page.
        result = service.list_users(
            tenant_id=tenant_id,
            role_filter=role_filter,
            limit=_ROSTER_SCAN_CAP,
        )
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "admin_members.list_failed tenant=%s error=%s",
            tenant_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Tenant member roster unavailable.",
        ) from exc

    members = result.pop("users", result.get("members", []))
    if len(members) >= _ROSTER_SCAN_CAP:
        logger.warning(
            "admin_members.scan_cap_hit tenant=%s cap=%d — extend UserManagementService with native cursor support.",
            tenant_id,
            _ROSTER_SCAN_CAP,
        )
    try:
        offset = max(0, int(cursor)) if cursor else 0
    except ValueError:
        offset = 0
    page = members[offset : offset + limit]
    next_cursor = str(offset + limit) if offset + limit < len(members) else None
    return {
        "tenant_id": tenant_id,
        "members": page,
        "count": len(page),
        "total_count": len(members),
        "next_cursor": next_cursor,
    }


@router.post("/invite", status_code=status.HTTP_201_CREATED)
async def invite_admin_member(
    body: InviteMemberRequest,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.MEMBERS_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    inviter_email: str = Depends(get_verified_user_email),
    service: UserManagementService = Depends(_get_user_management_service),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    """Create a member invitation and emit a decision trace."""

    del admin_role
    try:
        invitation = service.create_invitation(
            tenant_id=tenant_id,
            inviter_email=inviter_email or "admin@workweaver.ai",
            invitee_email=str(body.member_email),
            role=body.role,
        )
    except UserManagementError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "admin_members.invite_failed tenant=%s error=%s",
            tenant_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Member invitation service unavailable.",
        ) from exc

    payload = invitation.to_store_item() if hasattr(invitation, "to_store_item") else dict(invitation)
    invitation_id = (
        getattr(invitation, "invitation_id", None)
        or (invitation.get("invitation_id") if isinstance(invitation, dict) else None)
    )

    try:
        decision_capture.capture_decision(
            tenant_id=tenant_id,
            skill_id="admin.member.invite",
            decision_summary=f"Invited {body.member_email} as {body.role.value}",
            decision_type="member_invitation",
            outcome="created",
            entity_ids=[str(invitation_id) if invitation_id else "unknown"],
            rationale=f"Invitation issued by {inviter_email or 'admin'}",
            context_data={
                "invitation_id": invitation_id,
                "invitee_email": str(body.member_email),
                "role": body.role.value,
            },
            capture_surface="rest",
            service_family="admin_members",
        )
    except Exception:  # noqa: BLE001
        logger.warning(
            "admin_members.invite_decision_trace_failed tenant=%s",
            tenant_id,
            exc_info=True,
        )

    return {**payload, "tenant_id": tenant_id}
