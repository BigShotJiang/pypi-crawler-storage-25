"""Admin-scoped audit log endpoints.

Mirrors apps.backend.api.org.audit_log but scopes to the caller's own tenant
and lives under ``/api/v1/admin/audit``. Returns paginated JSON for the
admin UI, and a flat CSV export for download.

The admin variant treats the caller's tenant as the org scope (admin is
tenant-scoped). Cross-tenant audit reads are not supported here — those go
through the platform_admin path on the org router.
"""

from __future__ import annotations

import csv
import io
import logging
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import StreamingResponse

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    require_admin_user_role,
)
from apps.backend.schemas.error_response import ErrorResponse
from apps.backend.services.admin.admin_permission import AdminPermission
from apps.backend.services.org_audit_log import (
    ORG_AUDIT_EVENT_TYPES,
    OrgAuditForbidden,
    OrgAuditLogService,
    get_org_audit_log_service,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/admin/audit", tags=["admin-audit"])


def _resolve_admin_org_id(service: OrgAuditLogService, caller_tenant_id: str) -> str:
    """Resolve the admin's tenant to its org scope.

    Admin endpoints always operate within the caller's own org. We call
    ``resolve_org_id`` with the canonical ``"current"`` token so the
    service maps the caller tenant to its org via the lease service.
    """
    try:
        return service.resolve_org_id(
            requested_org_id="current",
            caller_tenant_id=caller_tenant_id,
        )
    except OrgAuditForbidden as exc:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": "admin_audit_forbidden", "detail": str(exc)},
        ) from exc


@router.get(
    "",
    responses={
        400: {"model": ErrorResponse, "description": "Invalid audit-log query"},
        403: {"model": ErrorResponse, "description": "Caller cannot read this admin audit log"},
    },
)
async def get_admin_audit_log(
    since: Annotated[
        str | None,
        Query(description="ISO timestamp or relative duration, for example 7d"),
    ] = None,
    until: Annotated[str | None, Query(description="ISO timestamp upper bound")] = None,
    actor: Annotated[str | None, Query(description="Actor user id filter")] = None,
    event_type: Annotated[
        list[str] | None,
        Query(description=f"Event type filter. Supported: {', '.join(ORG_AUDIT_EVENT_TYPES)}"),
    ] = None,
    cursor: Annotated[
        str | None,
        Query(description="Pagination cursor from the previous response"),
    ] = None,
    limit: Annotated[int, Query(ge=1, le=200, description="Maximum events to return")] = 50,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.AUDIT_READ)),
    actor_tenant_id: str = Depends(get_verified_tenant_id),
    service: OrgAuditLogService = Depends(get_org_audit_log_service),
) -> dict[str, Any]:
    """Return a paginated, tamper-evident admin audit log for the caller's tenant."""

    del admin_role
    org_id = _resolve_admin_org_id(service, actor_tenant_id)
    try:
        return service.query(
            org_id=org_id,
            caller_tenant_id=actor_tenant_id,
            since=since,
            until=until,
            actor=actor,
            event_types=event_type,
            cursor=cursor,
            limit=limit,
        )
    except OrgAuditForbidden as exc:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": "admin_audit_forbidden", "detail": str(exc)},
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "invalid_admin_audit_log_query", "detail": str(exc)},
        ) from exc


@router.get(
    ".csv",
    responses={
        400: {"model": ErrorResponse, "description": "Invalid audit-log query"},
        403: {"model": ErrorResponse, "description": "Caller cannot read this admin audit log"},
    },
)
async def export_admin_audit_log_csv(
    since: Annotated[
        str | None,
        Query(description="ISO timestamp or relative duration, for example 7d"),
    ] = None,
    until: Annotated[str | None, Query(description="ISO timestamp upper bound")] = None,
    actor: Annotated[str | None, Query(description="Actor user id filter")] = None,
    event_type: Annotated[
        list[str] | None,
        Query(description="Event type filter (see JSON endpoint)"),
    ] = None,
    limit: Annotated[
        int,
        Query(ge=1, le=1000, description="Maximum events to export"),
    ] = 200,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.AUDIT_READ)),
    actor_tenant_id: str = Depends(get_verified_tenant_id),
    service: OrgAuditLogService = Depends(get_org_audit_log_service),
) -> StreamingResponse:
    """Stream the audit log as CSV with a fixed header."""

    del admin_role
    org_id = _resolve_admin_org_id(service, actor_tenant_id)
    try:
        result = service.query(
            org_id=org_id,
            caller_tenant_id=actor_tenant_id,
            since=since,
            until=until,
            actor=actor,
            event_types=event_type,
            cursor=None,
            limit=limit,
        )
    except OrgAuditForbidden as exc:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={"error": "admin_audit_forbidden", "detail": str(exc)},
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "invalid_admin_audit_log_query", "detail": str(exc)},
        ) from exc

    buffer = io.StringIO()
    writer = csv.writer(buffer)
    writer.writerow(["event_id", "timestamp", "actor", "event_type", "object_id", "details"])

    for event in result.get("events", []) or []:
        writer.writerow(
            [
                str(event.get("event_id") or ""),
                str(event.get("occurred_at") or event.get("at") or ""),
                str(event.get("actor") or event.get("actor_user_id") or ""),
                str(event.get("event_type") or ""),
                str(event.get("resource_id") or event.get("lease_id") or ""),
                str(event.get("reason") or event.get("outcome") or ""),
            ]
        )

    payload = buffer.getvalue().encode("utf-8")
    headers = {
        "Content-Disposition": f'attachment; filename="admin-audit-{org_id}.csv"',
    }
    return StreamingResponse(
        iter([payload]),
        media_type="text/csv",
        headers=headers,
    )
