"""Admin-scoped tenant signup audit endpoint.

Issue #3623 — surfaces every tenant id + owner_email + signup_time + status so
a founder can confirm the signup-allowlist policy is being honored end-to-end.
Pairs with ``ops/scripts/check_signup_allowlist.py`` and the
``.github/workflows/signup-allowlist-audit.yml`` workflow, which together form
the belt-and-suspenders enforcement strategy:

1. API enforcement (``auth_helpers._domain_allowed_for_provisioning``) — refuses
   tenant creation pre-side-effect.
2. Daily CI audit (this endpoint + the script) — catches drift if the policy
   regresses or an exception lands in an unrelated PR.

The endpoint reads the fan-out ``TENANTS_ALL_INDEX`` partition written by
``tenant_provisioning.create_tenant``; it never scans the table.
"""

from __future__ import annotations

import logging
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, ConfigDict, Field

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.api.founder_admin import require_founder
from apps.backend.services.admin.admin_permission import AdminPermission
from apps.backend.services.tenant_provisioning import (
    TENANTS_ALL_INDEX_PK,
    TenantStatus,
    get_tenant_provisioning_service,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/admin/tenants", tags=["admin-tenants-audit"])

# Tenants fan-out scan cap. Matches the bounded-listing pattern used by
# ``apps.backend.api.founder_admin.list_tenants`` (which iterates the same
# partition without an outer cap). The audit endpoint terminates early as soon
# as the requested page worth of tenants has been gathered, so the cap below
# is only relevant for very large environments paging through every row.
_AUDIT_SCAN_CAP = 5000

# Suspended-like statuses that the default audit pass omits. Founders can flip
# ``include_suspended=true`` to see them; the CI gate always requests them so a
# silently-suspended off-allowlist tenant cannot hide.
_SUSPENDED_STATUSES = frozenset(
    {
        TenantStatus.SUSPENDED.value,
        TenantStatus.CANCELLED.value,
        TenantStatus.DESTROYED.value,
    }
)


class TenantAuditEntry(BaseModel):
    """A single row in the signup-audit projection."""

    model_config = ConfigDict(populate_by_name=True)

    tenant_id: str = Field(..., description="Tenant primary key (TENANT#<ULID>)")
    owner_email: str = Field(..., description="Lowercased owner email at signup")
    signup_time: str = Field(..., description="ISO-8601 timestamp from tenant.created_at")
    status: str = Field(..., description="Tenant lifecycle status")
    subscription_status: str | None = Field(
        default=None,
        description="Subscription status mirrored on the fan-out row",
    )
    product: str | None = Field(default=None, description="Product scope ('workweaver', 'workmemory'), if scoped")
    is_sub_tenant: bool = Field(default=False, description="True for org sub-tenant rows")


class TenantAuditResponse(BaseModel):
    """Paginated audit projection."""

    model_config = ConfigDict(populate_by_name=True)

    tenants: list[TenantAuditEntry] = Field(default_factory=list)
    count: int = Field(..., description="Rows returned in this page")
    total_scanned: int = Field(..., description="Rows inspected across pagination so far")
    next_cursor: str | None = Field(
        default=None,
        description="Cursor to pass back as ?cursor=… on the next page (None when exhausted)",
    )
    include_suspended: bool = Field(
        ...,
        description="Echoes the request flag for caller debuggability",
    )


def _normalize_audit_row(item: dict[str, Any]) -> TenantAuditEntry:
    raw_pk = str(item.get("tenant_pk") or item.get("sk") or "").strip()
    return TenantAuditEntry(
        tenant_id=raw_pk,
        owner_email=str(item.get("email") or "").strip().lower(),
        signup_time=str(item.get("created_at") or ""),
        status=str(item.get("status") or "").strip().lower(),
        subscription_status=(str(item.get("subscription_status")).strip().lower() or None)
        if item.get("subscription_status") is not None
        else None,
        product=(str(item.get("product") or "").strip() or None),
        is_sub_tenant=bool(item.get("is_sub_tenant")),
    )


def _provisioning_service_dependency():
    """Indirection so tests can override the provisioning service."""
    return get_tenant_provisioning_service()


@router.get(
    "/audit",
    response_model=TenantAuditResponse,
    summary="Audit tenant signups",
    description=(
        "Founder-only projection of every tenant's id + owner email + signup time + status. "
        "Pairs with the daily ``signup-allowlist-audit`` GitHub Action which fails the build "
        "if any owner_email is outside ``INTERNAL_SIGNUP_BYPASS_DOMAINS``."
    ),
)
async def audit_tenants(
    include_suspended: Annotated[
        bool,
        Query(description="Include suspended/cancelled/destroyed tenants in the projection."),
    ] = False,
    cursor: Annotated[
        str | None,
        Query(description="Encoded ``LastEvaluatedKey`` from the previous response."),
    ] = None,
    limit: Annotated[int, Query(ge=1, le=500, description="Max rows per page.")] = 100,
    _founder_email: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.TENANT_READ)),
    provisioning_service: Any = Depends(_provisioning_service_dependency),
) -> TenantAuditResponse:
    """Page through the ``TENANTS_ALL_INDEX`` partition and project the audit fields."""

    del _founder_email, _perm
    table = getattr(provisioning_service, "table", None)
    if table is None:
        logger.error("admin_tenants_audit.table_unavailable")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Tenants table is not available in this environment.",
        )

    exclusive_start_key: dict[str, Any] | None = None
    if cursor:
        # Cursor encodes ``sk`` (tenant_pk). The partition key is always
        # ``TENANTS_ALL_INDEX`` so we only need to forward ``sk``.
        exclusive_start_key = {"pk": TENANTS_ALL_INDEX_PK, "sk": cursor.strip()}

    tenants: list[TenantAuditEntry] = []
    scanned = 0
    last_evaluated_key: dict[str, Any] | None = None
    try:
        while len(tenants) < limit and scanned < _AUDIT_SCAN_CAP:
            query_kwargs: dict[str, Any] = {
                "KeyConditionExpression": "pk = :pk",
                "ExpressionAttributeValues": {":pk": TENANTS_ALL_INDEX_PK},
                "Limit": min(200, limit - len(tenants)),
            }
            if exclusive_start_key is not None:
                query_kwargs["ExclusiveStartKey"] = exclusive_start_key
            response = table.query(**query_kwargs)
            page_items = response.get("Items", []) or []
            for raw_item in page_items:
                scanned += 1
                if not isinstance(raw_item, dict):
                    continue
                row = _normalize_audit_row(raw_item)
                if not include_suspended and row.status in _SUSPENDED_STATUSES:
                    continue
                tenants.append(row)
                if len(tenants) >= limit:
                    break
            last_evaluated_key = response.get("LastEvaluatedKey")
            if not last_evaluated_key:
                break
            exclusive_start_key = last_evaluated_key
    except Exception as exc:  # noqa: BLE001
        logger.error("admin_tenants_audit.query_failed error=%s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Tenant audit projection is temporarily unavailable.",
        ) from exc

    next_cursor: str | None = None
    if last_evaluated_key and isinstance(last_evaluated_key.get("sk"), str):
        next_cursor = last_evaluated_key["sk"]

    return TenantAuditResponse(
        tenants=tenants,
        count=len(tenants),
        total_scanned=scanned,
        next_cursor=next_cursor,
        include_suspended=include_suspended,
    )
