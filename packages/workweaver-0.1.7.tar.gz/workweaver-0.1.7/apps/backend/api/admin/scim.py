"""SCIM provisioning configuration endpoints.

Tenant admins manage their SCIM endpoint (typically a SaaS identity provider
like Okta or Azure AD) through this surface. The config is stored alongside
other tenant settings and consumed by the canonical SCIM ingest worker
(out of scope for this PR — this commit lands only the config surface).
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field, HttpUrl

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_email,
    require_admin_user_role,
)
from apps.backend.services.admin.admin_permission import AdminPermission
from apps.backend.services.admin.scim_config_store import (
    ScimConfigStore,
    get_scim_config_store,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/admin/scim", tags=["admin-scim"])


def _get_decision_capture() -> Any:
    from apps.backend.services.context.decision_event_capture import (
        DecisionEventCaptureService,
    )

    return DecisionEventCaptureService()


class ScimConfigPayload(BaseModel):
    endpoint: HttpUrl = Field(..., description="SCIM v2 base URL provided by the identity provider.")
    token_ref: str = Field(
        ...,
        min_length=4,
        max_length=512,
        description="Reference to the SCIM bearer token (e.g. secret manager key).",
    )
    sync_enabled: bool = Field(False, description="Set true to activate the SCIM sync worker.")


@router.get("/config")
async def get_scim_config(
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.SCIM_READ)),
    tenant_id: str = Depends(get_verified_tenant_id),
    store: ScimConfigStore = Depends(get_scim_config_store),
) -> dict[str, Any]:
    """Return the SCIM config row for the caller's tenant."""

    del admin_role
    config = store.get(tenant_id)
    return config.to_public_dict()


@router.put("/config")
async def put_scim_config(
    body: ScimConfigPayload,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.SCIM_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_email: str = Depends(get_verified_user_email),
    store: ScimConfigStore = Depends(get_scim_config_store),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    """Write the SCIM config and emit a decision trace."""

    del admin_role
    updated = store.put(
        tenant_id,
        endpoint=str(body.endpoint),
        token_ref=body.token_ref,
        sync_enabled=body.sync_enabled,
        updated_by=actor_email or "admin",
    )

    try:
        decision_capture.capture_decision(
            tenant_id=tenant_id,
            skill_id="admin.scim.config",
            decision_summary=f"Updated SCIM config (sync_enabled={body.sync_enabled})",
            decision_type="scim_config_update",
            outcome="written",
            entity_ids=[tenant_id],
            rationale=f"SCIM config rewritten by {actor_email or 'admin'}",
            context_data={
                "endpoint": str(body.endpoint),
                "sync_enabled": body.sync_enabled,
            },
            capture_surface="rest",
            service_family="admin_scim",
        )
    except Exception:  # noqa: BLE001
        logger.warning(
            "admin_scim.put_decision_trace_failed tenant=%s",
            tenant_id,
            exc_info=True,
        )

    return updated.to_public_dict()
