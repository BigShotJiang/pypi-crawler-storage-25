"""ChannelRoutingRule REST surface (#2999).

Cross-channel routing rules: declare how an inbound channel routes to an
outbound channel for a workspace, with optional intent + entity-scope
filters and approval gating. The substrate lives at
``apps.backend.services.channels.channel_routing_rule``.

Per PRODUCT-CONTEXT.md §13: every cross-channel write emits its own
Decision Trace tying back to the source thread; rules are the
governance hook for that emission.
"""
from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id


logger = logging.getLogger(__name__)


router = APIRouter(prefix="/api/v1/channel/routing-rules", tags=["channel-routing"])


# ---------------------------------------------------------------------------
# Service resolution
# ---------------------------------------------------------------------------


def _get_service() -> Any:
    """Resolve the ChannelRoutingService — in-memory by default."""
    try:
        from apps.backend.services.channels.channel_routing_rule import (
            get_channel_routing_service,
        )

        return get_channel_routing_service()
    except ImportError:
        from apps.backend.services.channels.channel_routing_rule import (
            ChannelRoutingService,
        )

        return ChannelRoutingService()


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class RoutingRuleCreateRequest(BaseModel):
    """Payload for POST /api/v1/channel/routing-rules."""

    source_channel: str = Field(..., max_length=50)
    target_channel: str = Field(..., max_length=50)
    priority: str = Field(
        default="ALLOWED",
        max_length=20,
        description="PREFERRED | ALLOWED | BLOCKED",
    )
    condition: str | None = Field(default=None, max_length=200)
    intent_type: str | None = Field(default=None, max_length=100)
    entity_scope: str | None = Field(default=None, max_length=100)
    redaction_level: str = Field(default="none", max_length=20)
    decision_trace_reason: str | None = Field(default=None, max_length=500)
    approval_state: str = Field(default="approved", max_length=20)


class RoutingRuleResponse(BaseModel):
    rule_id: str
    workspace_id: str
    source_channel: str
    target_channel: str
    priority: str
    condition: str | None
    intent_type: str | None
    entity_scope: str | None
    redaction_level: str
    decision_trace_reason: str | None
    approval_state: str
    created_at: str


class RoutingRuleListResponse(BaseModel):
    rules: list[RoutingRuleResponse]
    count: int


class RoutingMatchTestRequest(BaseModel):
    source_channel: str = Field(..., max_length=50)
    intent_type: str | None = Field(default=None, max_length=100)
    entity_scope: str | None = Field(default=None, max_length=100)


class RoutingMatchTestResponse(BaseModel):
    target_channel: str
    rule_id: str
    reason: str
    fallback: bool


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _serialize_rule(rule: Any) -> RoutingRuleResponse:
    return RoutingRuleResponse(
        rule_id=rule.rule_id,
        workspace_id=rule.workspace_id,
        source_channel=getattr(rule.source_channel, "value", str(rule.source_channel)),
        target_channel=getattr(rule.target_channel, "value", str(rule.target_channel)),
        priority=getattr(rule.priority, "name", str(rule.priority)),
        condition=rule.condition,
        intent_type=rule.intent_type,
        entity_scope=rule.entity_scope,
        redaction_level=getattr(rule.redaction_level, "value", str(rule.redaction_level)),
        decision_trace_reason=rule.decision_trace_reason,
        approval_state=getattr(rule.approval_state, "value", str(rule.approval_state)),
        created_at=rule.created_at.isoformat(),
    )


def _coerce_channel(value: str) -> Any:
    from apps.backend.services.channels.channel_routing_rule import Channel

    try:
        return Channel(value)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=f"invalid channel: {value}") from exc


def _coerce_priority(value: str) -> Any:
    from apps.backend.services.channels.channel_routing_rule import RoutingPriority

    try:
        return RoutingPriority[value.upper()]
    except KeyError as exc:
        raise HTTPException(status_code=400, detail=f"invalid priority: {value}") from exc


def _coerce_redaction(value: str) -> Any:
    from apps.backend.services.channels.channel_routing_rule import RedactionLevel

    try:
        return RedactionLevel(value)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=f"invalid redaction_level: {value}") from exc


def _coerce_approval(value: str) -> Any:
    from apps.backend.services.channels.channel_routing_rule import ApprovalState

    try:
        return ApprovalState(value)
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=f"invalid approval_state: {value}") from exc


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("", response_model=RoutingRuleListResponse)
async def list_rules(tenant_id: str = Depends(get_verified_tenant_id)) -> RoutingRuleListResponse:
    """List all routing rules for the tenant."""
    service = _get_service()
    rules = service.get_rules(workspace_id=tenant_id)
    return RoutingRuleListResponse(
        rules=[_serialize_rule(r) for r in rules],
        count=len(rules),
    )


@router.post("", response_model=RoutingRuleResponse, status_code=201)
async def create_rule(
    request: RoutingRuleCreateRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> RoutingRuleResponse:
    """Create a new routing rule."""
    from apps.backend.services.channels.channel_routing_rule import ChannelRoutingRule

    service = _get_service()
    rule = ChannelRoutingRule(
        rule_id=f"rule_{uuid4().hex[:12]}",
        workspace_id=tenant_id,
        source_channel=_coerce_channel(request.source_channel),
        target_channel=_coerce_channel(request.target_channel),
        priority=_coerce_priority(request.priority),
        condition=request.condition,
        intent_type=request.intent_type,
        entity_scope=request.entity_scope,
        redaction_level=_coerce_redaction(request.redaction_level),
        decision_trace_reason=request.decision_trace_reason,
        approval_state=_coerce_approval(request.approval_state),
        created_at=datetime.now(UTC),
    )
    service.add_rule(rule)
    logger.info(
        "channel_routing_rule.create tenant=%s rule_id=%s",
        tenant_id,
        rule.rule_id,
    )
    return _serialize_rule(rule)


@router.get("/{rule_id}", response_model=RoutingRuleResponse)
async def show_rule(
    rule_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> RoutingRuleResponse:
    """Retrieve a single rule by id."""
    service = _get_service()
    rules = service.get_rules(workspace_id=tenant_id)
    match = next((r for r in rules if r.rule_id == rule_id), None)
    if match is None:
        raise HTTPException(status_code=404, detail="rule not found")
    return _serialize_rule(match)


@router.delete("/{rule_id}", status_code=204)
async def delete_rule(
    rule_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> None:
    """Delete a rule by id. Idempotent — missing rules return 204."""
    service = _get_service()
    rules = service.get_rules(workspace_id=tenant_id)
    if not any(r.rule_id == rule_id for r in rules):
        # Idempotent — still return success.
        logger.info("channel_routing_rule.delete tenant=%s rule_id=%s missing", tenant_id, rule_id)
        return
    service.remove_rule(rule_id)
    logger.info("channel_routing_rule.delete tenant=%s rule_id=%s", tenant_id, rule_id)


@router.post("/match-test", response_model=RoutingMatchTestResponse)
async def match_test(
    request: RoutingMatchTestRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> RoutingMatchTestResponse:
    """Evaluate routing rules without committing a write — debug surface."""
    service = _get_service()
    decision = service.route(
        workspace_id=tenant_id,
        source_channel=_coerce_channel(request.source_channel),
        intent_type=request.intent_type,
        entity_scope=request.entity_scope,
    )
    return RoutingMatchTestResponse(
        target_channel=getattr(decision.target_channel, "value", str(decision.target_channel)),
        rule_id=decision.rule_id,
        reason=decision.reason,
        fallback=decision.fallback,
    )


__all__ = ["router"]
