"""Meeting-panel watchface adapters (issue #1180).

The meeting-panel UI (``apps/dashboard/components/workspace/meeting-panel.html``)
was calling seven endpoints that 404'd in production:

- ``GET /api/v1/meetings?upcoming=true``
- ``GET /api/v1/meetings?past=true``
- ``GET /api/v1/meetings/{id}/bot-status``
- ``PUT /api/v1/meetings/{id}/bot-status``
- ``GET /api/v1/meetings/{id}/prep-brief``
- ``POST /api/v1/meetings/{id}/ask-zara``
- ``GET /api/v1/meetings/{id}/action-items``

Backend data lives at ``/api/v1/meetings/{active,history,{session_id}/status,
pre-meeting-brief,{session_id}/transcript}`` (``apps/backend/api/meetings.py``),
but the shapes and paths don't match the frontend's user-mental-model URLs.
This module is the same structural fix pattern as ``mission_watchface.py``:
thin canonical adapters that delegate to existing services with the
response shape the watchface actually renders.

Structural properties (mirroring mission_watchface.py):

1. Tenant from auth context only (never query/body).
2. Hard-cap pagination server-side.
3. Enum-validated query params.
4. Empty-state returns valid 200 — watchface tile renders empty state,
   never 500.
5. Service-throw graceful degradation with structured warning logs.
6. Write actions (``PUT /bot-status``, ``POST /ask-zara``) emit audit
   events.
7. Cache headers differentiated by liveness:
   - Upcoming list / prep brief: ``private, max-age=30``
   - Past list: ``private, max-age=60`` (less volatile)
   - bot-status, ask-zara, action-items: ``no-cache`` (live state)
"""

from __future__ import annotations

import logging
from typing import Any, Literal

from fastapi import APIRouter, Body, Depends, Query, Response
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.meeting.shared_meeting_service import get_shared_meeting_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/meetings", tags=["meeting-watchface"])

# Hard caps per GLM + Codex round-1 pattern.
_UPCOMING_DEFAULT_LIMIT = 20
_UPCOMING_MAX_LIMIT = 100
_PAST_DEFAULT_LIMIT = 20
_PAST_MAX_LIMIT = 100

# Short cache for listings. Watchface refreshes often; 30s avoids the
# "why is my new meeting not showing up" frustration while still
# coalescing burst loads.
_LIST_CACHE_SECONDS = 30


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class MeetingSummary(BaseModel):
    id: str
    title: str | None = None
    start_time: str | None = None
    attendees: list[str] | str | None = None
    zara_status: Literal["confirmed", "invited", "declined", "not_invited", "joined", "left"] = "not_invited"


class MeetingsListResponse(BaseModel):
    meetings: list[MeetingSummary] = Field(default_factory=list)
    count: int = 0


class BotStatusResponse(BaseModel):
    meeting_id: str
    status: Literal["not_invited", "invited", "confirmed", "declined", "joined", "left"] = "not_invited"
    bot_id: str | None = None
    joined_at: str | None = None
    left_at: str | None = None


class BotStatusUpdateRequest(BaseModel):
    status: Literal["invite", "accept", "decline", "cancel"] = Field(..., description="Requested transition")


class PrepBriefResponse(BaseModel):
    meeting_id: str
    title: str | None = None
    summary: str = ""
    participants: list[str] = Field(default_factory=list)
    scheduled_for: str | None = None
    sources: list[dict[str, Any]] = Field(default_factory=list)
    generated_at: str


class AskZaraRequest(BaseModel):
    question: str = Field(..., min_length=1, max_length=2000)


class AskZaraResponse(BaseModel):
    meeting_id: str
    status: Literal["queued", "answered", "unavailable"] = "queued"
    answer: str | None = None
    trace_id: str | None = None


class ActionItem(BaseModel):
    id: str
    title: str
    assignee: str | None = None
    due_at: str | None = None
    done: bool = False


class ActionItemsResponse(BaseModel):
    meeting_id: str
    runtime_session: dict[str, Any] | None = None
    action_items: list[ActionItem] = Field(default_factory=list)
    count: int = 0
    source: Literal["transcript", "manual", "unavailable"] = "unavailable"
    transcript_status: str | None = None
    message: str | None = None


# ---------------------------------------------------------------------------
# GET /api/v1/meetings?upcoming=true | ?past=true
# ---------------------------------------------------------------------------


@router.get("", response_model=MeetingsListResponse)
async def list_meetings(
    response: Response,
    tenant_id: str = Depends(get_verified_tenant_id),
    upcoming: bool = Query(False, description="Return only meetings starting in the future"),
    past: bool = Query(False, description="Return only meetings already finished"),
    limit: int = Query(_UPCOMING_DEFAULT_LIMIT, ge=1, le=_UPCOMING_MAX_LIMIT),
) -> MeetingsListResponse:
    """List meetings for the tenant, optionally filtered by time."""
    response.headers["Cache-Control"] = f"private, max-age={_LIST_CACHE_SECONDS}"
    payload = await get_shared_meeting_service().list_meetings(
        tenant_id=tenant_id,
        upcoming=upcoming,
        past=past,
        limit=limit,
    )
    return MeetingsListResponse(**payload)


# ---------------------------------------------------------------------------
# GET / PUT /api/v1/meetings/{id}/bot-status
# ---------------------------------------------------------------------------


@router.get("/{session_id}/bot-status", response_model=BotStatusResponse)
async def get_bot_status(
    response: Response,
    session_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> BotStatusResponse:
    """Current Zara bot invitation state for a meeting."""
    response.headers["Cache-Control"] = "private, no-cache, no-store, must-revalidate"
    payload = await get_shared_meeting_service().get_bot_status(
        tenant_id=tenant_id,
        session_id=session_id,
        absent_returns_not_invited=True,
        degrade_store_errors=True,
    )
    return BotStatusResponse(**payload)


@router.put("/{session_id}/bot-status", response_model=BotStatusResponse)
async def update_bot_status(
    response: Response,
    session_id: str,
    body: BotStatusUpdateRequest = Body(...),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> BotStatusResponse:
    """Mutate the Zara bot invitation state.

    Valid transitions are a small state machine:
    - ``not_invited`` → ``invited`` (via ``status=invite``)
    - ``invited`` → ``confirmed`` (via ``status=accept``)
    - ``invited`` → ``declined`` (via ``status=decline``)
    - ``any`` → ``cancelled`` (via ``status=cancel``)

    Audit event emitted on every state change. Returns the current
    canonical state after the mutation.
    """
    response.headers["Cache-Control"] = "private, no-cache, no-store, must-revalidate"
    payload = await get_shared_meeting_service().transition_bot_status(
        tenant_id=tenant_id,
        session_id=session_id,
        transition=body.status,
        degrade_store_errors=True,
    )
    return BotStatusResponse(**payload)


# ---------------------------------------------------------------------------
# GET /api/v1/meetings/{id}/prep-brief
# ---------------------------------------------------------------------------


@router.get("/{session_id}/prep-brief", response_model=PrepBriefResponse)
async def get_prep_brief(
    response: Response,
    session_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PrepBriefResponse:
    """AI-generated pre-meeting brief.

    Delegates to the sourced-recall service's ``build_pre_meeting_brief``
    handler used by the existing ``POST /pre-meeting-brief`` endpoint.
    Builds the request from session metadata so the frontend can hit a
    simple GET rather than re-posting the meeting fields it already has.
    """
    response.headers["Cache-Control"] = f"private, max-age={_LIST_CACHE_SECONDS}"
    payload = await get_shared_meeting_service().build_prep_brief(
        tenant_id=tenant_id,
        session_id=session_id,
        degrade_store_errors=True,
    )
    return PrepBriefResponse(**payload)


# ---------------------------------------------------------------------------
# POST /api/v1/meetings/{id}/ask-zara
# ---------------------------------------------------------------------------


@router.post("/{session_id}/ask-zara", response_model=AskZaraResponse, status_code=202)
async def ask_zara(
    response: Response,
    session_id: str,
    body: AskZaraRequest = Body(...),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> AskZaraResponse:
    """Ask Zara a question during a live meeting.

    Returns 202 + ``status="queued"`` so the frontend can poll or
    subscribe to an SSE stream rather than blocking on Zara latency.
    If the Zara voice/chat service is not available, degrades to
    ``status="unavailable"`` with a clear message.

    Audit logs every question for compliance (no PII in logs — just
    tenant_id, session_id, question length).
    """
    response.headers["Cache-Control"] = "private, no-cache, no-store, must-revalidate"
    payload = await get_shared_meeting_service().enqueue_zara_question(
        tenant_id=tenant_id,
        session_id=session_id,
        question=body.question,
        degrade_store_errors=True,
    )
    return AskZaraResponse(**payload)


# ---------------------------------------------------------------------------
# GET /api/v1/meetings/{id}/action-items
# ---------------------------------------------------------------------------


@router.get("/{session_id}/action-items", response_model=ActionItemsResponse)
async def list_action_items(
    response: Response,
    session_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ActionItemsResponse:
    """Extracted action items for a completed meeting.

    Returns 200 with empty list for meetings without a transcript
    (kinder to watchface UI than 404). Source is ``"unavailable"``
    when the transcript engine is not configured so the UI can render
    an explicit "Awaiting transcript" state rather than "0 action items."
    """
    response.headers["Cache-Control"] = "private, no-cache, no-store, must-revalidate"
    payload = await get_shared_meeting_service().list_action_items(
        tenant_id=tenant_id,
        session_id=session_id,
        degrade_store_errors=True,
    )
    return ActionItemsResponse(**payload)


__all__ = ["router"]
