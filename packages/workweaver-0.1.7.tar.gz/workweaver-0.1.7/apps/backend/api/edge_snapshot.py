"""Edge snapshot REST API (#3546).

Exposes:
* ``GET /api/v1/edge/snapshot/key``  — Ed25519 public key for snapshot
  signature verification.
* ``GET /api/v1/edge/snapshot``      — signed snapshot blob containing
  CapabilityRegistry rows, AgentAwarenessStore rows, Decision Traces,
  and OTel events.

Both endpoints are tenant-scoped and require authentication.
"""

from __future__ import annotations

import base64

from fastapi import APIRouter, Depends

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.edge_cloud.snapshot_publisher import EdgeSnapshotPublisher


router = APIRouter(prefix="/api/v1/edge/snapshot", tags=["edge-snapshot"])

_publisher: EdgeSnapshotPublisher | None = None


def get_publisher() -> EdgeSnapshotPublisher:
    global _publisher
    if _publisher is None:
        _publisher = EdgeSnapshotPublisher()
    return _publisher


def reset_publisher_for_tests() -> None:
    global _publisher
    _publisher = None


@router.get("/key")
async def get_public_key(
    tenant_id: str = Depends(get_verified_tenant_id),
    publisher: EdgeSnapshotPublisher = Depends(get_publisher),
) -> dict[str, str]:
    key_bytes = publisher.public_key_bytes()
    return {
        "public_key": base64.b64encode(key_bytes).decode(),
        "algorithm": "ed25519",
    }


@router.get("")
async def get_snapshot(
    tenant_id: str = Depends(get_verified_tenant_id),
    publisher: EdgeSnapshotPublisher = Depends(get_publisher),
) -> dict[str, str]:
    from apps.backend.services.capability_registry.registry import (
        load_capability_registry,
    )

    registry = load_capability_registry()
    capabilities = [
        {
            "capability_id": row.capability_id,
            "contract_id": row.contract_id,
            "family": row.family,
            "action": row.action,
            "description": row.description,
            "state": row.state.value,
        }
        for row in registry.rows
        if not row.sunsetted
    ]

    blob, sig = publisher.publish(
        capabilities=capabilities,
        awareness_rows=[],
        traces=[],
        otel_events=[],
    )

    return {
        "blob": base64.b64encode(blob).decode(),
        "signature": base64.b64encode(sig).decode(),
        "algorithm": "ed25519",
    }
