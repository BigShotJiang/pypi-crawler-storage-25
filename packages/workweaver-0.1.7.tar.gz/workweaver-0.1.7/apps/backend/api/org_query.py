"""Org Query API -- cross-tool natural language answers for your organization.

Routes:
    POST /api/v1/org/query  -- Execute an org-level query across all connected sources.
    POST /api/v1/org/detect -- Detect whether a question is an org-level query.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.org_query_service import get_org_query_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/org", tags=["org-query"])


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class OrgQueryRequest(BaseModel):
    """Request body for org-level query."""

    question: str = Field(
        ...,
        min_length=1,
        max_length=2000,
        description="Natural language question about your organization",
    )


class OrgQueryResponse(BaseModel):
    """Response from org-level query."""

    answer: str = Field(..., description="Synthesized answer")
    sources: list[dict[str, Any]] = Field(default_factory=list, description="Data sources consulted")
    suggested_followups: list[str] = Field(default_factory=list, description="Suggested follow-up questions")
    query_plan: list[str] = Field(default_factory=list, description="Which tools were queried")


class OrgDetectRequest(BaseModel):
    """Request body for org query detection."""

    question: str = Field(
        ...,
        min_length=1,
        max_length=2000,
        description="Question to classify",
    )


class OrgDetectResponse(BaseModel):
    """Response from org query detection."""

    is_org_query: bool = Field(..., description="Whether the question is an org-level query")


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("/query", response_model=OrgQueryResponse)
async def query_org(
    body: OrgQueryRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> OrgQueryResponse:
    """Query your organization -- ChatGPT for your business.

    Fans out the question to all connected data sources (CRM, calendar,
    memory, evidence ledger, work items) and synthesizes a unified answer.
    """
    svc = get_org_query_service()
    try:
        result = await svc.query(tenant_id, body.question)
    except Exception as exc:
        logger.error("Org query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Org query temporarily unavailable.")

    return OrgQueryResponse(
        answer=result.answer,
        sources=result.sources,
        suggested_followups=result.suggested_followups,
        query_plan=result.query_plan,
    )


@router.post("/detect", response_model=OrgDetectResponse)
async def detect_org_query(
    body: OrgDetectRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> OrgDetectResponse:
    """Detect whether a question is an org-level query.

    Useful for the omnibox and Zara to decide whether to route to
    the org query service vs the regular task executor.
    """
    svc = get_org_query_service()
    return OrgDetectResponse(is_org_query=svc.is_org_query(body.question))
