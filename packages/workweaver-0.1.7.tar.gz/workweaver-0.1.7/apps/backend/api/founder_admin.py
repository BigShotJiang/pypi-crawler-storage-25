"""
Founder Admin API — Super-admin panel for Workweaver founders.

Provides platform-level management capabilities restricted to platform-admin
emails. All destructive actions produce immutable evidence receipts.
"""
from apps.backend.config.table_names import resolve_table

import logging
import os
import time
import uuid  # noqa: F401 — used in broadcast_notification endpoint
from datetime import datetime, UTC
from decimal import Decimal
from typing import Any

import boto3  # noqa: F401 — used in system_health endpoint
from fastapi import APIRouter, Depends, Header, HTTPException, Request, status
from pydantic import BaseModel, Field

from apps.backend.api import mission_shared
from apps.backend.api.auth_helpers import BROWSER_SESSION_COOKIE_NAMES
from apps.backend.api.platform_admin_identity import is_platform_admin_email
from apps.backend.services.account_lifecycle import (
    AccountLifecycleService,
    AccountLifecycleError,
    TenantNotFoundError,
)
from apps.backend.services.session.browser_session import (
    BrowserSessionTokenError,
    mint_browser_session_token,
    verify_browser_session_token,
)
from apps.backend.services.billing.adjustments import BillingAdjustmentService
from apps.backend.services.billing.ingress import BillingIngressService
from apps.backend.services.billing.reconciliation import (
    BillingProviderImportService,
    BillingReconciliationService,
)
from apps.backend.services.billing.read_models import BillingReadModelService
from apps.backend.services.billing.subscription_service import (
    SubscriptionManager,
    SubscriptionManagerError,
    SubscriptionNotFoundError,
    SubscriptionOperationError,
)
from apps.backend.dependency_factories.business import get_audit_logger
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.schemas.error_response import safe_error_detail
from apps.backend.services.audit_logger import AuditAction, AuditSeverity
from apps.backend.services.tenant_lifecycle_admin import (
    TenantLifecycleAdminService,
)
from apps.backend.services.tenant_provisioning import TENANTS_ALL_INDEX_PK

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/founder", tags=["founder-admin"])

# ============================================================================
# Auth Dependency
# ============================================================================


def _disable_cognito() -> bool:
    """Check if Cognito auth is disabled (dev/test mode).

    Safety: forcibly ignores DISABLE_COGNITO in production environments and ECS.
    """
    val = os.environ.get("DISABLE_COGNITO", "").strip().lower() in {"1", "true", "yes"}
    if not val:
        return False
    from apps.backend.config.environment import get_environment, is_production_like

    env = get_environment()
    if is_production_like():
        logger.critical(
            "SECURITY: DISABLE_COGNITO is set in %s environment. "
            "This is a critical security misconfiguration. Ignoring the flag.",
            env,
        )
        return False
    if os.environ.get("ECS_CONTAINER_METADATA_URI"):
        logger.critical(
            "SECURITY: DISABLE_COGNITO is set in an ECS environment. "
            "This is a critical security misconfiguration. Ignoring the flag."
        )
        return False
    return True


def require_founder(
    request: Request,
    authorization: str | None = Header(None),
) -> str:
    """
    Dependency that verifies the caller is a Workweaver founder.

    In production: extracts email from JWT claims on request.state.
    In dev mode (DISABLE_COGNITO): extracts from X-User-Email header.

    Returns:
        Verified founder email.

    Raises:
        HTTPException 401 if no auth info available.
        HTTPException 403 if email is not on the platform-admin allowlist.
    """
    email: str | None = None

    if _disable_cognito():
        # Dev mode: trust header
        email = request.headers.get("x-user-email")
    else:
        for cookie_name in BROWSER_SESSION_COOKIE_NAMES:
            token = (request.cookies.get(cookie_name) or "").strip()
            if not token:
                continue
            try:
                email = verify_browser_session_token(token).email
            except BrowserSessionTokenError:
                logger.warning("Invalid browser session cookie presented to founder admin")
                email = None
            if email:
                break
        if not email:
            # Production fallback: extract from JWT claims stored in request.state
            email = getattr(request.state, "user_email", None)

    if not email:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
        )

    if not is_platform_admin_email(email):
        logger.warning(f"Founder access denied for email: {email}")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Founder access required",
        )

    return email


# ============================================================================
# Service Dependencies
# ============================================================================


def get_account_lifecycle_service() -> AccountLifecycleService:
    """Get account lifecycle service instance."""
    return AccountLifecycleService(
        tenants_table=resolve_table("tenants"),
        stripe_api_key=os.getenv("STRIPE_API_KEY", ""),
    )


def get_subscription_manager() -> SubscriptionManager:
    """Get subscription manager instance."""
    return SubscriptionManager(
        stripe_api_key=os.getenv("STRIPE_API_KEY", ""),
        tenants_table_name=resolve_table("tenants"),
    )


def get_billing_read_models() -> BillingReadModelService:
    """Get billing read-model service instance."""
    return BillingReadModelService()


def get_billing_adjustments() -> BillingAdjustmentService:
    return BillingAdjustmentService()


def get_billing_provider_imports() -> BillingProviderImportService:
    return BillingProviderImportService()


def get_billing_reconciliation() -> BillingReconciliationService:
    return BillingReconciliationService()


def get_billing_ingress() -> BillingIngressService:
    return BillingIngressService()


def get_tenant_lifecycle_admin(
    lifecycle: AccountLifecycleService = Depends(get_account_lifecycle_service),
) -> "TenantLifecycleAdminService":
    """Tenant lifecycle admin service (issue #1146).

    Wiring notes (council adversarial review 2026-04-14):

    * ``tenants_table`` is the metadata table — the service reads
      ``METADATA``/``USER#``/``AGENT#`` rows from here.
    * ``session_store`` MUST write to the **users** table so the
      per-user ``sessions_invalidated_at`` markers land where the
      auth middleware reads them (``tenant_auth.py:88`` reads from
      ``os.environ.get('USERS_TABLE', 'workweaver-prod-users')``).
      An earlier draft routed the store through the tenants table;
      GLM caught that the invalidation cascade would be a silent
      no-op because the read path goes elsewhere.
    * We build the users-table handle inline rather than via the
      ``user_management._create_default_store`` helper because that
      helper returns a ``PortableStore`` with its own schema —
      different shape from what ``DynamoDbSessionInvalidationStore``
      expects. The ``boto3.Table`` primitive is the right seam.
    """
    import os as _os

    import boto3 as _boto3

    from apps.backend.services.session.session_invalidation import (
        DynamoDbSessionInvalidationStore,
    )
    from apps.backend.services.tenant_lifecycle_admin import TenantLifecycleAdminService

    users_table_name = _resolve_table("users")
    users_table = _boto3.resource(
        "dynamodb",
        region_name=_os.getenv("AWS_REGION", "us-east-1"),
    ).Table(users_table_name)
    session_store = DynamoDbSessionInvalidationStore(users_table)

    return TenantLifecycleAdminService(
        tenants_table=lifecycle._tenants_table,
        session_store=session_store,
    )


# ============================================================================
# Request / Response Models
# ============================================================================


class TenantSummary(BaseModel):
    """Summary view of a tenant."""

    tenant_id: str = Field(..., description="Tenant ID")
    name: str = Field(default="", description="Tenant name")
    email: str = Field(default="", description="Primary email")
    status: str = Field(default="unknown", description="Account status")
    subscription_status: str = Field(default="none", description="Subscription status")
    user_count: int = Field(default=0, description="Number of users")
    created_at: str = Field(default="", description="ISO creation timestamp")


class TenantListResponse(BaseModel):
    """Response for listing all tenants."""

    tenants: list[TenantSummary] = Field(default_factory=list)
    total: int = Field(default=0, description="Total tenant count")


class TenantDetailResponse(BaseModel):
    """Full tenant detail."""

    tenant_id: str
    name: str = ""
    email: str = ""
    status: str = "unknown"
    subscription: dict[str, Any] = Field(default_factory=dict)
    users: list[dict[str, Any]] = Field(default_factory=list)
    created_at: str = ""
    metadata: dict[str, Any] = Field(default_factory=dict)


class AdminRefundRequest(BaseModel):
    """Request for admin-initiated refund."""

    amount_cents: int | None = Field(
        None,
        description="Amount in cents (None = full refund)",
    )
    reason: str = Field(
        default="admin_initiated",
        description="Reason for refund",
    )


class AdminRefundResponse(BaseModel):
    """Response for admin refund."""

    tenant_id: str
    refund_id: str
    amount_cents: int
    currency: str
    status: str


class AdminCancelResponse(BaseModel):
    """Response for admin subscription cancellation."""

    tenant_id: str
    subscription_id: str
    status: str
    cancellation_type: str


class AdminDeleteResponse(BaseModel):
    """Response for admin account deletion."""

    tenant_id: str
    deleted_at: str
    evidence_receipt_id: str
    cascade_steps: list[str] = Field(default_factory=list)


class AdminSuspendRequest(BaseModel):
    """Request body for ``PUT /tenants/{tenant_id}/suspend``.

    ``reason`` is required and ends up in the immutable evidence
    record. Keep it short but specific — "credential compromise",
    "abusive behavior on 2026-04-14", etc.
    """

    reason: str = Field(..., min_length=3, max_length=512)


class AdminPauseRequest(BaseModel):
    """Request body for ``PUT /tenants/{tenant_id}/pause`` (issue #3050).

    Pause is the softer managed-lifecycle cousin of suspend: it expresses
    "temporarily blocked, no accusation" — non-payment dunning, scheduled
    maintenance, customer-requested hold. The cascade (sessions
    invalidated + agents marked + ExecutionGuard pause armed) matches
    suspend so behaviour is consistent, but the public lifecycle banner
    routes to the right CTA per PRODUCT-CONTEXT.md §21.
    """

    reason: str = Field(..., min_length=3, max_length=512)


class AdminThrottleRequest(BaseModel):
    """Request body for ``PUT /tenants/{tenant_id}/throttle`` (issue #3050).

    Throttle is the SOFTEST managed-lifecycle action — it does not
    freeze the tenant. ``qps_cap`` is the per-tenant plans/minute
    ceiling enforced at the planner gate by ``AgenticRateLimiter``.

    Validation: ``1 ≤ qps_cap ≤ DEFAULT_PER_MEMBER_PER_MINUTE``. The
    upper bound matches the platform default — asking for a higher
    cap is meaningless because the limiter already permits more, so
    the founder must instead RESTORE to clear the throttle.
    """

    reason: str = Field(..., min_length=3, max_length=512)
    qps_cap: int = Field(
        ...,
        gt=0,
        le=10,  # DEFAULT_PER_MEMBER_PER_MINUTE — see agentic_limiter.py
        description=(
            "Per-tenant plans/minute cap enforced by AgenticRateLimiter. "
            "Must be in [1, DEFAULT_PER_MEMBER_PER_MINUTE]. Asking for a "
            "cap above the platform default is rejected — restore the "
            "tenant instead of throttling above the default."
        ),
    )


class AdminRestoreRequest(BaseModel):
    """Request body for ``PUT /tenants/{tenant_id}/restore``."""

    reason: str = Field(..., min_length=3, max_length=512)


class AdminSuspendResponse(BaseModel):
    """Response from the suspend admin endpoint (issue #1146).

    ``idempotent`` is True if the tenant was already suspended (the
    call did not change state but did emit an audit event so the
    admin action stays visible).

    ``users_invalidated`` / ``users_failed`` / ``agents_paused`` /
    ``agents_failed`` give the caller the cascade's visibility — a
    partial failure does NOT block the status transition (the
    lifecycle admin service commits the state flip first, then does
    the cascade), but the numbers tell the operator whether any
    follow-up is needed.
    """

    tenant_id: str
    previous_status: str
    new_status: str
    changed_by: str
    changed_at: str
    reason: str
    idempotent: bool = False
    users_invalidated: int = 0
    users_failed: int = 0
    agents_paused: int = 0
    agents_failed: int = 0
    evidence_id: str | None = None
    warnings: list[str] = Field(default_factory=list)


class AdminPauseResponse(BaseModel):
    """Response from the pause admin endpoint (issue #3050).

    Mirrors ``AdminSuspendResponse`` because the cascade shape is
    identical (sessions invalidated, agents marked, ExecutionGuard
    pause armed). The only difference is the resulting ``status`` is
    ``paused`` not ``suspended``, which routes the public lifecycle
    banner to the right CTA per PRODUCT-CONTEXT.md §21.
    """

    tenant_id: str
    previous_status: str
    new_status: str
    changed_by: str
    changed_at: str
    reason: str
    idempotent: bool = False
    users_invalidated: int = 0
    users_failed: int = 0
    agents_paused: int = 0
    agents_failed: int = 0
    evidence_id: str | None = None
    warnings: list[str] = Field(default_factory=list)


class AdminThrottleResponse(BaseModel):
    """Response from the throttle admin endpoint (issue #3050).

    ``qps_cap`` echoes back the configured per-tenant plans/minute
    ceiling so the operator can confirm the value the limiter will
    enforce. Throttle does NOT cascade — sessions stay valid and
    agents keep running, the only effect is the rate cap. ``warnings``
    lists any best-effort failures (e.g. evidence emit) that did not
    block the transition.
    """

    tenant_id: str
    previous_status: str
    new_status: str
    changed_by: str
    changed_at: str
    reason: str
    qps_cap: int
    idempotent: bool = False
    evidence_id: str | None = None
    warnings: list[str] = Field(default_factory=list)


class AdminRestoreResponse(BaseModel):
    """Response from the restore admin endpoint (issue #1146).

    Restore deliberately does NOT auto-unpause agents — founders must
    resume each agent explicitly after reviewing the suspension
    window. That is by design and is documented in
    ``tenant_lifecycle_admin.py``.
    """

    tenant_id: str
    previous_status: str
    new_status: str
    changed_by: str
    changed_at: str
    reason: str
    idempotent: bool = False
    evidence_id: str | None = None
    warnings: list[str] = Field(default_factory=list)


class MetricsOverviewResponse(BaseModel):
    """Platform metrics overview."""

    total_tenants: int = Field(default=0)
    active_tenants: int = Field(default=0)
    total_agents: int = Field(default=0)
    mrr_cents: int = Field(default=0, description="Monthly recurring revenue in cents")
    churn_rate: float = Field(default=0.0, description="Churn rate as decimal (0.05 = 5%)")


class FounderBillingTenantSummary(BaseModel):
    tenant_id: str
    plan_tier: str
    projected_bill_usd: str
    projected_usage_usd: str
    adjustment_total_usd: str
    projected_cogs_usd: str
    reconciliation_status: str


class FounderBillingOverviewResponse(BaseModel):
    tenant_count: int
    projected_plan_fees_usd: str
    projected_usage_usd: str
    projected_adjustments_usd: str
    projected_bill_usd: str
    projected_cogs_usd: str
    projected_margin_usd: str
    reconciled_tenant_count: int = 0
    tenants_with_variance: int = 0
    provider_variance_count: int = 0
    top_tenants: list[FounderBillingTenantSummary] = Field(default_factory=list)


class ProviderUsageImportRow(BaseModel):
    tenant_id: str
    metric: str
    quantity: Decimal = Field(..., ge=0)
    cost_usd: Decimal = Field(Decimal("0"), ge=0)
    reference_id: str | None = None
    provider_session_id: str | None = None


class ProviderUsageImportRequest(BaseModel):
    provider: str = Field(..., min_length=2, max_length=64)
    year: int = Field(..., ge=2024, le=2099)
    month: int = Field(..., ge=1, le=12)
    rows: list[ProviderUsageImportRow] = Field(default_factory=list, min_length=1)
    source: str = Field(default="manual_csv")


class ProviderUsageImportResponse(BaseModel):
    provider: str
    period: str
    tenant_count: int
    row_count: int
    imported_at: str


class ReconciliationDeltaResponse(BaseModel):
    metric: str
    internal_quantity: str
    provider_quantity: str
    quantity_variance: str
    internal_cogs_usd: str
    provider_cost_usd: str
    cost_variance_usd: str
    within_tolerance: bool


class BillingReconciliationResponse(BaseModel):
    tenant_id: str
    provider: str
    period: str
    status: str
    variance_count: int
    reconciled_at: str | None = None
    deltas: list[ReconciliationDeltaResponse] = Field(default_factory=list)


class BillingAdjustmentCreateRequest(BaseModel):
    year: int = Field(..., ge=2024, le=2099)
    month: int = Field(..., ge=1, le=12)
    kind: str = Field(..., pattern="^(credit|debit)$")
    amount_usd: float = Field(..., gt=0)
    reason: str = Field(..., min_length=3, max_length=256)
    metric_name: str | None = None
    note: str | None = None
    evidence_url: str | None = None


class BillingAdjustmentResponse(BaseModel):
    adjustment_id: str
    tenant_id: str
    period: str
    kind: str
    amount_usd: str
    reason: str
    created_at: str
    created_by: str
    metric_name: str | None = None
    note: str | None = None
    evidence_url: str | None = None
    status: str


class DlqReplayRequest(BaseModel):
    tenant_id: str = Field(..., description="Tenant ID to replay DLQ items for")
    limit: int = Field(default=100, ge=1, le=500, description="Max items to replay")


class DlqReplayResponse(BaseModel):
    tenant_id: str
    replayed_count: int
    items: list[dict[str, Any]] = Field(default_factory=list)


# M4.4 — New request/response models for missing admin endpoints


class ChangePlanRequest(BaseModel):
    """Request to change a tenant's plan tier."""

    plan_tier: str = Field(
        ...,
        description="New plan tier (e.g. launchpad, growth, enterprise)",
        min_length=1,
        max_length=64,
    )
    reason: str = Field(
        default="founder_override",
        description="Reason for plan change",
        max_length=256,
    )


class ChangePlanResponse(BaseModel):
    """Response after plan tier change."""

    tenant_id: str
    previous_tier: str
    new_tier: str
    changed_by: str
    changed_at: str


class TrialActivateRequest(BaseModel):
    """Request to activate or extend a trial."""

    days: int = Field(
        default=14,
        ge=1,
        le=365,
        description="Trial duration in days",
    )
    reason: str = Field(
        default="founder_override",
        description="Reason for trial activation/extension",
        max_length=256,
    )


class TrialActivateResponse(BaseModel):
    """Response after trial activation or extension."""

    tenant_id: str
    trial_end: str
    days: int
    activated_by: str


class ImpersonateResponse(BaseModel):
    """Response containing a tenant-scoped session token for debugging."""

    tenant_id: str
    token: str
    expires_at: str
    impersonated_by: str


class GlobalAgentSummary(BaseModel):
    """Summary of a single agent across all tenants."""

    tenant_id: str = Field(default="")
    agent_id: str = Field(default="")
    agent_name: str = Field(default="")
    status: str = Field(default="unknown")
    skill_count: int = Field(default=0)


class GlobalAgentsResponse(BaseModel):
    """Response listing all agents across all tenants."""

    agents: list[GlobalAgentSummary] = Field(default_factory=list)
    total: int = Field(default=0)


class ComponentHealth(BaseModel):
    """Health status of a single infrastructure component."""

    name: str
    status: str = Field(default="unknown", description="healthy | degraded | down | unknown")
    latency_ms: float | None = None
    detail: str = Field(default="")


class SystemHealthResponse(BaseModel):
    """Aggregate system health across all infrastructure components."""

    overall: str = Field(default="healthy", description="healthy | degraded | down")
    checked_at: str = Field(default="")
    components: list[ComponentHealth] = Field(default_factory=list)


class BroadcastRequest(BaseModel):
    """Request to send a notification to all or selected tenants."""

    message: str = Field(
        ...,
        min_length=1,
        max_length=2000,
        description="Notification message",
    )
    title: str = Field(
        default="System Notification",
        max_length=200,
        description="Notification title",
    )
    tenant_ids: list[str] | None = Field(
        None,
        description="Target tenant IDs (None = all tenants)",
    )
    severity: str = Field(
        default="info",
        description="info | warning | critical",
    )


class BroadcastResponse(BaseModel):
    """Response after broadcasting a notification."""

    broadcast_id: str
    sent_to: int
    title: str
    severity: str
    sent_at: str
    sent_by: str


# ============================================================================
# Endpoints
# ============================================================================


@router.get(
    "/tenants",
    response_model=TenantListResponse,
    summary="List all tenants",
    description="List all tenants with status and subscription info. Founder access only.",
)
async def list_tenants(
    founder_email: str = Depends(require_founder),
    lifecycle: AccountLifecycleService = Depends(get_account_lifecycle_service),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> TenantListResponse:
    """List all tenants for admin overview."""
    try:
        # Query TENANTS_ALL_INDEX partition (fan-out written at tenant creation).
        index_items: list[dict[str, Any]] = []
        start_key = None
        while True:
            kwargs: dict[str, Any] = {
                "KeyConditionExpression": "pk = :pk",
                "ExpressionAttributeValues": {":pk": TENANTS_ALL_INDEX_PK},
                "Limit": 200,
            }
            if start_key:
                kwargs["ExclusiveStartKey"] = start_key
            resp = lifecycle._tenants_table.query(**kwargs)
            index_items.extend(resp.get("Items", []))
            start_key = resp.get("LastEvaluatedKey")
            if not start_key:
                break

        tenants = []
        for item in index_items:
            tenants.append(
                TenantSummary(
                    tenant_id=item.get("tenant_pk", item.get("sk", "")),
                    name=item.get("name", ""),
                    email=item.get("email", ""),
                    status=item.get("status", "unknown"),
                    subscription_status=item.get("subscription_status", "none"),
                    user_count=item.get("user_count", 0),
                    created_at=item.get("created_at", ""),
                )
            )

        paged_tenants, total = paginate_items(tenants, pagination)
        return TenantListResponse(tenants=paged_tenants, total=total)

    except Exception as e:
        logger.error(f"Failed to list tenants: {e}")
        raise HTTPException(status_code=500, detail="Failed to list organizations")


@router.get(
    "/tenants/{tenant_id}",
    response_model=TenantDetailResponse,
    summary="Get tenant detail",
    description="Get full tenant detail including users. Founder access only.",
)
async def get_tenant_detail(
    tenant_id: str,
    founder_email: str = Depends(require_founder),
    lifecycle: AccountLifecycleService = Depends(get_account_lifecycle_service),
) -> TenantDetailResponse:
    """Get full tenant detail."""
    try:
        # Query all records for this tenant
        response = lifecycle._tenants_table.query(
            KeyConditionExpression="pk = :pk",
            ExpressionAttributeValues={":pk": tenant_id},
        )
        items = response.get("Items", [])

        metadata: dict[str, Any] = {}
        users: list[dict[str, Any]] = []
        for item in items:
            sk = item.get("sk", "")
            if sk == "METADATA":
                metadata = item
            elif sk.startswith("USER#"):
                users.append({k: v for k, v in item.items() if k != "pk"})

        if not metadata:
            raise HTTPException(status_code=404, detail="Organization not found")

        return TenantDetailResponse(
            tenant_id=tenant_id,
            name=metadata.get("name", metadata.get("company_name", "")),
            email=metadata.get("email", metadata.get("billing_email", "")),
            status=metadata.get("status", "unknown"),
            subscription=metadata.get("subscription", {}),
            users=users,
            created_at=metadata.get("created_at", ""),
            metadata={k: v for k, v in metadata.items() if k not in ("pk", "sk", "subscription")},
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to get tenant detail: {e}")
        raise HTTPException(status_code=500, detail="Failed to get organization detail")


@router.post(
    "/tenants/{tenant_id}/cancel",
    response_model=AdminCancelResponse,
    summary="Admin cancel subscription",
    description="Cancel a tenant's subscription. Founder access only.",
)
async def admin_cancel_subscription(
    tenant_id: str,
    founder_email: str = Depends(require_founder),
    sub_mgr: SubscriptionManager = Depends(get_subscription_manager),
) -> AdminCancelResponse:
    """Admin cancel a tenant's subscription (immediate)."""
    try:
        details = sub_mgr.cancel_subscription(tenant_id=tenant_id, immediate=True)
        return AdminCancelResponse(
            tenant_id=tenant_id,
            subscription_id=details.subscription_id,
            status=details.status.value,
            cancellation_type="immediate",
        )
    except SubscriptionNotFoundError:
        raise HTTPException(status_code=404, detail="Subscription not found")
    except SubscriptionManagerError as e:
        logger.error(f"Admin cancel failed: {e}")
        raise HTTPException(status_code=500, detail="Subscription cancel failed")


@router.post(
    "/tenants/{tenant_id}/refund",
    response_model=AdminRefundResponse,
    summary="Admin issue refund",
    description="Issue a refund for a tenant. Founder access only.",
)
async def admin_refund(
    tenant_id: str,
    request: AdminRefundRequest = AdminRefundRequest(),
    founder_email: str = Depends(require_founder),
    sub_mgr: SubscriptionManager = Depends(get_subscription_manager),
) -> AdminRefundResponse:
    """Admin issue a refund."""
    try:
        result = sub_mgr.issue_refund(
            tenant_id=tenant_id,
            amount_cents=request.amount_cents,
            reason=request.reason,
        )
        return AdminRefundResponse(
            tenant_id=tenant_id,
            refund_id=result.refund_id,
            amount_cents=result.amount_cents,
            currency=result.currency,
            status=result.status,
        )
    except SubscriptionNotFoundError:
        raise HTTPException(status_code=404, detail="Subscription not found")
    except SubscriptionOperationError as e:
        logger.error(f"Admin refund failed: {e}")
        raise HTTPException(status_code=400, detail=safe_error_detail(e))
    except SubscriptionManagerError as e:
        logger.error(f"Admin refund service error: {e}")
        raise HTTPException(status_code=500, detail="Refund failed")


@router.delete(
    "/tenants/{tenant_id}",
    response_model=AdminDeleteResponse,
    summary="Admin delete tenant",
    description="Full cascade deletion of a tenant. Founder access only.",
)
async def admin_delete_tenant(
    tenant_id: str,
    founder_email: str = Depends(require_founder),
    lifecycle: AccountLifecycleService = Depends(get_account_lifecycle_service),
) -> AdminDeleteResponse:
    """Admin delete a tenant with full cascade."""
    try:
        cert = lifecycle.delete_account(
            tenant_id=tenant_id,
            reason=f"admin_deletion_by_{founder_email}",
        )
        return AdminDeleteResponse(
            tenant_id=cert.tenant_id,
            deleted_at=cert.deleted_at,
            evidence_receipt_id=cert.evidence_receipt_id,
            cascade_steps=cert.cascade_steps,
        )
    except TenantNotFoundError:
        raise HTTPException(status_code=404, detail="Organization not found")
    except AccountLifecycleError as e:
        logger.error(f"Admin delete failed: {e}")
        raise HTTPException(status_code=500, detail="Account deletion failed")


# ============================================================================
# Tenant Lifecycle (Suspend / Pause / Throttle / Restore) — issues #1146, #3050
# ============================================================================


def _hash_actor(email: str) -> str:
    """Short stable hash for the actor field on tenant-side SSE payloads.

    The tenant subscribers see the lifecycle event but should not learn
    a founder's email verbatim. The hash is short, deterministic, and
    only consumed by the banner UI for "by admin <abc123>" display.
    """
    import hashlib

    return hashlib.sha256((email or "").strip().lower().encode("utf-8")).hexdigest()[:12]


async def _publish_lifecycle_event(
    *,
    tenant_id: str,
    event_type: str,
    actor_email: str,
    reason: str,
    previous_status: str,
    new_status: str,
    changed_at: str,
    idempotent: bool,
    extra: dict[str, Any] | None = None,
) -> None:
    """Fire-and-forget publish of a managed-lifecycle event to the
    affected tenant's own SSE stream (#3050).

    Failures are swallowed — the lifecycle transition has already
    committed via the service, so a transient EventBus failure must
    not surface as a 500 to the founder. The endpoint behaviour is
    "best-effort SSE notification".
    """
    try:
        from apps.backend.services.event_bus import get_event_bus

        bus = get_event_bus()
    except Exception:  # noqa: BLE001
        logger.debug("Lifecycle SSE bus unavailable; skipping push for tenant=%s", tenant_id)
        return
    payload: dict[str, Any] = {
        "type": event_type,
        "actor": _hash_actor(actor_email),
        "reason": reason,
        "previous_status": previous_status,
        "new_status": new_status,
        "ts": changed_at,
        "idempotent": idempotent,
    }
    if extra:
        payload.update(extra)
    try:
        await bus.publish(tenant_id, event_type, payload)
    except Exception as exc:  # noqa: BLE001
        logger.debug(
            "Lifecycle SSE push failed for tenant=%s event=%s: %s",
            tenant_id,
            event_type,
            exc,
        )


@router.put(
    "/tenants/{tenant_id}/suspend",
    response_model=AdminSuspendResponse,
    summary="Admin suspend tenant",
    description=(
        "Freeze a tenant: flip ``tenant_status='suspended'``, invalidate "
        "every user's browser session, and mark all agent rows "
        "paused-by-suspend. Founder access only. Idempotent on repeat "
        "calls."
    ),
)
async def admin_suspend_tenant(
    tenant_id: str,
    request: AdminSuspendRequest,
    founder_email: str = Depends(require_founder),
    service: TenantLifecycleAdminService = Depends(get_tenant_lifecycle_admin),
) -> AdminSuspendResponse:
    """Suspend a tenant — see ``tenant_lifecycle_admin.py`` for semantics."""
    from apps.backend.services.tenant_lifecycle_admin import (
        InvalidStateTransitionError,
        TenantLifecycleAdminError,
    )
    from apps.backend.services.tenant_lifecycle_admin import (
        TenantNotFoundError as LifecycleTenantNotFoundError,
    )

    try:
        result = service.suspend(
            tenant_id=tenant_id,
            actor_email=founder_email,
            reason=request.reason,
        )
        return AdminSuspendResponse(
            tenant_id=result.tenant_id,
            previous_status=result.previous_status,
            new_status=result.new_status,
            changed_by=result.changed_by,
            changed_at=result.changed_at,
            reason=result.reason,
            idempotent=result.idempotent,
            users_invalidated=result.users_invalidated,
            users_failed=result.users_failed,
            agents_paused=result.agents_paused,
            agents_failed=result.agents_failed,
            evidence_id=result.evidence_id,
            warnings=result.warnings,
        )
    except LifecycleTenantNotFoundError:
        raise HTTPException(status_code=404, detail="Organization not found")
    except InvalidStateTransitionError as exc:
        logger.warning(
            "admin_suspend rejected: tenant=%s current=%s requested=%s",
            exc.tenant_id,
            exc.current_status,
            exc.requested,
        )
        raise HTTPException(
            status_code=409,
            detail=f"Cannot suspend tenant in state {exc.current_status!r}",
        )
    except TenantLifecycleAdminError as exc:
        logger.error("admin_suspend failed: %s", exc)
        raise HTTPException(status_code=500, detail="Suspend failed")
    except ValueError as exc:
        # Raised by the service for empty/invalid arguments.
        raise HTTPException(status_code=400, detail=safe_error_detail(exc))


@router.put(
    "/tenants/{tenant_id}/pause",
    response_model=AdminPauseResponse,
    summary="Admin pause tenant (managed lifecycle)",
    description=(
        "Pause a tenant: flip ``tenant_status='paused'``, invalidate "
        "every user's browser session, mark all agents paused-by-pause, "
        "and arm the ExecutionGuard tenant-pause so subsequent tool "
        "invocations DENY. Pause is the softer managed-lifecycle cousin "
        "of suspend (issue #3050) — same cascade, different banner. "
        "Pause on a ``suspended`` tenant is a 409 because suspend is "
        "more severe and must not be silently downgraded; restore "
        "first, then pause if that's the intent. Founder access only. "
        "Idempotent on repeat calls."
    ),
)
async def admin_pause_tenant(
    tenant_id: str,
    request: AdminPauseRequest,
    founder_email: str = Depends(require_founder),
    service: TenantLifecycleAdminService = Depends(get_tenant_lifecycle_admin),
) -> AdminPauseResponse:
    """Pause a tenant — see ``tenant_lifecycle_admin.py`` for semantics."""
    from apps.backend.services.tenant_lifecycle_admin import (
        InvalidStateTransitionError,
        TenantLifecycleAdminError,
    )
    from apps.backend.services.tenant_lifecycle_admin import (
        TenantNotFoundError as LifecycleTenantNotFoundError,
    )

    try:
        result = service.pause(
            tenant_id=tenant_id,
            actor_email=founder_email,
            reason=request.reason,
        )
        # Best-effort SSE push to the affected tenant's own stream so
        # subscribed admins/owners see the lifecycle banner update
        # without polling. Cross-tenant fanout is intentionally NOT
        # used (only the tenant gets news about itself).
        await _publish_lifecycle_event(
            tenant_id=result.tenant_id,
            event_type="tenant.lifecycle.paused",
            actor_email=founder_email,
            reason=result.reason,
            previous_status=result.previous_status,
            new_status=result.new_status,
            changed_at=result.changed_at,
            idempotent=result.idempotent,
        )
        return AdminPauseResponse(
            tenant_id=result.tenant_id,
            previous_status=result.previous_status,
            new_status=result.new_status,
            changed_by=result.changed_by,
            changed_at=result.changed_at,
            reason=result.reason,
            idempotent=result.idempotent,
            users_invalidated=result.users_invalidated,
            users_failed=result.users_failed,
            agents_paused=result.agents_paused,
            agents_failed=result.agents_failed,
            evidence_id=result.evidence_id,
            warnings=result.warnings,
        )
    except LifecycleTenantNotFoundError:
        raise HTTPException(status_code=404, detail="Organization not found")
    except InvalidStateTransitionError as exc:
        logger.warning(
            "admin_pause rejected: tenant=%s current=%s requested=%s",
            exc.tenant_id,
            exc.current_status,
            exc.requested,
        )
        raise HTTPException(
            status_code=409,
            detail=f"Cannot pause tenant in state {exc.current_status!r}",
        )
    except TenantLifecycleAdminError as exc:
        logger.error("admin_pause failed: %s", exc)
        raise HTTPException(status_code=500, detail="Pause failed")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=safe_error_detail(exc))


@router.put(
    "/tenants/{tenant_id}/throttle",
    response_model=AdminThrottleResponse,
    summary="Admin throttle tenant (managed lifecycle)",
    description=(
        "Throttle a tenant: flip ``tenant_status='throttled'`` and write "
        "a per-tenant ``qps_cap`` to METADATA. Unlike suspend/pause, "
        "throttle does NOT freeze the tenant — sessions stay valid and "
        "agents keep running. The only effect is the planner gate "
        "(``AgenticRateLimiter``) enforcing the new cap on top of its "
        "default per-member rate. Idempotent on (status=throttled, "
        "qps_cap=requested). Throttle on a ``suspended`` tenant is a "
        "409 — restore first if that's the intent. Founder access only."
    ),
)
async def admin_throttle_tenant(
    tenant_id: str,
    request: AdminThrottleRequest,
    founder_email: str = Depends(require_founder),
    service: TenantLifecycleAdminService = Depends(get_tenant_lifecycle_admin),
) -> AdminThrottleResponse:
    """Throttle a tenant — see ``tenant_lifecycle_admin.py`` for semantics."""
    from apps.backend.services.tenant_lifecycle_admin import (
        InvalidStateTransitionError,
        TenantLifecycleAdminError,
    )
    from apps.backend.services.tenant_lifecycle_admin import (
        TenantNotFoundError as LifecycleTenantNotFoundError,
    )

    try:
        result = service.throttle(
            tenant_id=tenant_id,
            actor_email=founder_email,
            reason=request.reason,
            qps_cap=request.qps_cap,
        )
        # Best-effort SSE push to the affected tenant's own stream.
        await _publish_lifecycle_event(
            tenant_id=result.tenant_id,
            event_type="tenant.lifecycle.throttled",
            actor_email=founder_email,
            reason=result.reason,
            previous_status=result.previous_status,
            new_status=result.new_status,
            changed_at=result.changed_at,
            idempotent=result.idempotent,
            extra={"qps_cap": result.qps_cap},
        )
        # Defensive: result.qps_cap should always be set on a throttle
        # result, but coerce so the response always carries a valid int.
        return AdminThrottleResponse(
            tenant_id=result.tenant_id,
            previous_status=result.previous_status,
            new_status=result.new_status,
            changed_by=result.changed_by,
            changed_at=result.changed_at,
            reason=result.reason,
            qps_cap=int(result.qps_cap if result.qps_cap is not None else request.qps_cap),
            idempotent=result.idempotent,
            evidence_id=result.evidence_id,
            warnings=result.warnings,
        )
    except LifecycleTenantNotFoundError:
        raise HTTPException(status_code=404, detail="Organization not found")
    except InvalidStateTransitionError as exc:
        logger.warning(
            "admin_throttle rejected: tenant=%s current=%s requested=%s",
            exc.tenant_id,
            exc.current_status,
            exc.requested,
        )
        raise HTTPException(
            status_code=409,
            detail=f"Cannot throttle tenant in state {exc.current_status!r}",
        )
    except TenantLifecycleAdminError as exc:
        logger.error("admin_throttle failed: %s", exc)
        raise HTTPException(status_code=500, detail="Throttle failed")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=safe_error_detail(exc))


@router.put(
    "/tenants/{tenant_id}/restore",
    response_model=AdminRestoreResponse,
    summary="Admin restore tenant",
    description=(
        "Clear ANY managed-lifecycle hold on a tenant — suspend, "
        "pause, or throttle (#3050 PR C). Flips ``tenant_status="
        "'active'``, REMOVEs every sentinel field (suspended_*, "
        "paused_*, throttled_*) and clears ``qps_cap`` so the rate "
        "limiter goes back to the platform default. Agents are NOT "
        "auto-unpaused — founders must review each agent and resume "
        "explicitly. Founder access only. Idempotent on repeat calls."
    ),
)
async def admin_restore_tenant(
    tenant_id: str,
    request: AdminRestoreRequest,
    founder_email: str = Depends(require_founder),
    service: TenantLifecycleAdminService = Depends(get_tenant_lifecycle_admin),
) -> AdminRestoreResponse:
    """Restore a tenant — see ``tenant_lifecycle_admin.py`` for semantics."""
    from apps.backend.services.tenant_lifecycle_admin import (
        InvalidStateTransitionError,
        TenantLifecycleAdminError,
    )
    from apps.backend.services.tenant_lifecycle_admin import (
        TenantNotFoundError as LifecycleTenantNotFoundError,
    )

    try:
        result = service.restore(
            tenant_id=tenant_id,
            actor_email=founder_email,
            reason=request.reason,
        )
        # Best-effort SSE push of ``tenant.lifecycle.restored`` to the
        # affected tenant's own stream so the lifecycle banner clears
        # without polling. ``previous_status`` is included so admins
        # know which managed-lifecycle hold was cleared.
        await _publish_lifecycle_event(
            tenant_id=result.tenant_id,
            event_type="tenant.lifecycle.restored",
            actor_email=founder_email,
            reason=result.reason,
            previous_status=result.previous_status,
            new_status=result.new_status,
            changed_at=result.changed_at,
            idempotent=result.idempotent,
        )
        return AdminRestoreResponse(
            tenant_id=result.tenant_id,
            previous_status=result.previous_status,
            new_status=result.new_status,
            changed_by=result.changed_by,
            changed_at=result.changed_at,
            reason=result.reason,
            idempotent=result.idempotent,
            evidence_id=result.evidence_id,
            warnings=result.warnings,
        )
    except LifecycleTenantNotFoundError:
        raise HTTPException(status_code=404, detail="Organization not found")
    except InvalidStateTransitionError as exc:
        logger.warning(
            "admin_restore rejected: tenant=%s current=%s requested=%s",
            exc.tenant_id,
            exc.current_status,
            exc.requested,
        )
        raise HTTPException(
            status_code=409,
            detail=f"Cannot restore tenant in state {exc.current_status!r}",
        )
    except TenantLifecycleAdminError as exc:
        logger.error("admin_restore failed: %s", exc)
        raise HTTPException(status_code=500, detail="Restore failed")
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=safe_error_detail(exc))


@router.get(
    "/metrics/overview",
    response_model=MetricsOverviewResponse,
    summary="Platform metrics overview",
    description="Get platform-level metrics: MRR, tenants, agents, churn. Founder access only.",
)
async def metrics_overview(
    founder_email: str = Depends(require_founder),
    lifecycle: AccountLifecycleService = Depends(get_account_lifecycle_service),
) -> MetricsOverviewResponse:
    """Get platform metrics overview."""
    try:
        # Query TENANTS_ALL_INDEX partition instead of scanning all METADATA rows.
        items: list[dict[str, Any]] = []
        start_key = None
        while True:
            kwargs: dict[str, Any] = {
                "KeyConditionExpression": "pk = :pk",
                "ExpressionAttributeValues": {":pk": TENANTS_ALL_INDEX_PK},
                "Limit": 500,
            }
            if start_key:
                kwargs["ExclusiveStartKey"] = start_key
            resp = lifecycle._tenants_table.query(**kwargs)
            items.extend(resp.get("Items", []))
            start_key = resp.get("LastEvaluatedKey")
            if not start_key:
                break

        total_tenants = len(items)
        active_tenants = 0
        total_agents = 0
        mrr_cents = 0
        cancelled_count = 0

        for item in items:
            sub_status = item.get("subscription_status", "")
            tenant_status = item.get("status", "")

            if sub_status in ("active", "trialing") and tenant_status != "deleted":
                active_tenants += 1
            if sub_status in ("canceled", "cancelled"):
                cancelled_count += 1

            total_agents += int(item.get("agent_count", 0))
            mrr_cents += int(item.get("mrr_cents", 0))

        churn_rate = (cancelled_count / total_tenants) if total_tenants > 0 else 0.0

        return MetricsOverviewResponse(
            total_tenants=total_tenants,
            active_tenants=active_tenants,
            total_agents=total_agents,
            mrr_cents=mrr_cents,
            churn_rate=round(churn_rate, 4),
        )

    except Exception as e:
        logger.error(f"Failed to compute metrics: {e}")
        raise HTTPException(status_code=500, detail="Failed to compute metrics")


@router.get(
    "/billing/overview",
    response_model=FounderBillingOverviewResponse,
    summary="Founder billing overview",
    description="Live founder-grade billing overview with projected bill, COGS, margin, and top tenants.",
)
async def founder_billing_overview(
    founder_email: str = Depends(require_founder),
    read_models: BillingReadModelService = Depends(get_billing_read_models),
) -> FounderBillingOverviewResponse:
    _ = founder_email
    try:
        overview = read_models.founder_overview()
        return FounderBillingOverviewResponse(
            tenant_count=int(overview.get("tenant_count", 0)),
            projected_plan_fees_usd=str(overview.get("projected_plan_fees_usd", "0.00")),
            projected_usage_usd=str(overview.get("projected_usage_usd", "0.00")),
            projected_adjustments_usd=str(overview.get("projected_adjustments_usd", "0.00")),
            projected_bill_usd=str(overview.get("projected_bill_usd", "0.00")),
            projected_cogs_usd=str(overview.get("projected_cogs_usd", "0.00")),
            projected_margin_usd=str(overview.get("projected_margin_usd", "0.00")),
            reconciled_tenant_count=int(overview.get("reconciled_tenant_count", 0)),
            tenants_with_variance=int(overview.get("tenants_with_variance", 0)),
            provider_variance_count=int(overview.get("provider_variance_count", 0)),
            top_tenants=[FounderBillingTenantSummary(**tenant) for tenant in overview.get("top_tenants", [])],
        )
    except Exception as e:
        logger.error("Failed to compute founder billing overview: %s", e)
        raise HTTPException(status_code=500, detail="Failed to compute founder billing overview")


@router.post(
    "/billing/provider-usage/import",
    response_model=ProviderUsageImportResponse,
    summary="Import provider billing usage",
    description="Founder-only manual provider usage import used for reconciliation.",
)
async def import_provider_usage(
    request: ProviderUsageImportRequest,
    founder_email: str = Depends(require_founder),
    imports: BillingProviderImportService = Depends(get_billing_provider_imports),
) -> ProviderUsageImportResponse:
    _ = founder_email
    try:
        result = imports.import_usage_rows(
            provider=request.provider,
            year=request.year,
            month=request.month,
            rows=[row.model_dump() for row in request.rows],
            imported_by=founder_email,
            source=request.source,
        )
        return ProviderUsageImportResponse(**result)
    except Exception as e:
        logger.error("Failed to import provider usage: %s", e)
        raise HTTPException(status_code=500, detail="Failed to import provider usage")


@router.post(
    "/billing/reconciliation/run",
    response_model=list[BillingReconciliationResponse],
    summary="Run billing reconciliation",
    description="Founder-only provider-aware reconciliation for one billing period.",
)
async def run_billing_reconciliation(
    year: int,
    month: int,
    provider: str | None = None,
    founder_email: str = Depends(require_founder),
    reconciliation: BillingReconciliationService = Depends(get_billing_reconciliation),
) -> list[BillingReconciliationResponse]:
    _ = founder_email
    try:
        results = reconciliation.reconcile_period(year=year, month=month, provider=provider)
        return [
            BillingReconciliationResponse(
                tenant_id=str(item.get("tenant_id") or ""),
                provider=str(item.get("provider") or ""),
                period=str(item.get("period") or ""),
                status=str(item.get("status") or "missing"),
                variance_count=int(item.get("variance_count") or 0),
                reconciled_at=str(item.get("reconciled_at") or "") or None,
                deltas=[
                    ReconciliationDeltaResponse(
                        metric=str(delta.get("metric") or ""),
                        internal_quantity=str(delta.get("internal_quantity") or "0"),
                        provider_quantity=str(delta.get("provider_quantity") or "0"),
                        quantity_variance=str(delta.get("quantity_variance") or "0"),
                        internal_cogs_usd=str(delta.get("internal_cogs_usd") or "0"),
                        provider_cost_usd=str(delta.get("provider_cost_usd") or "0"),
                        cost_variance_usd=str(delta.get("cost_variance_usd") or "0"),
                        within_tolerance=bool(delta.get("within_tolerance")),
                    )
                    for delta in item.get("deltas", [])
                ],
            )
            for item in results
        ]
    except Exception as e:
        logger.error("Failed to run billing reconciliation: %s", e)
        raise HTTPException(status_code=500, detail="Failed to run billing reconciliation")


@router.get(
    "/billing/reconciliation",
    response_model=list[BillingReconciliationResponse],
    summary="List billing reconciliation results",
    description="Founder-only provider reconciliation results for a billing period.",
)
async def list_billing_reconciliation(
    year: int,
    month: int,
    provider: str | None = None,
    founder_email: str = Depends(require_founder),
    reconciliation: BillingReconciliationService = Depends(get_billing_reconciliation),
) -> list[BillingReconciliationResponse]:
    _ = founder_email
    try:
        results = reconciliation.list_results(year=year, month=month, provider=provider)
        return [
            BillingReconciliationResponse(
                tenant_id=str(item.get("tenant_id") or ""),
                provider=str(item.get("provider") or ""),
                period=str(item.get("period") or ""),
                status=str(item.get("status") or "missing"),
                variance_count=int(item.get("variance_count") or 0),
                reconciled_at=str(item.get("reconciled_at") or "") or None,
                deltas=[
                    ReconciliationDeltaResponse(
                        metric=str(delta.get("metric") or ""),
                        internal_quantity=str(delta.get("internal_quantity") or "0"),
                        provider_quantity=str(delta.get("provider_quantity") or "0"),
                        quantity_variance=str(delta.get("quantity_variance") or "0"),
                        internal_cogs_usd=str(delta.get("internal_cogs_usd") or "0"),
                        provider_cost_usd=str(delta.get("provider_cost_usd") or "0"),
                        cost_variance_usd=str(delta.get("cost_variance_usd") or "0"),
                        within_tolerance=bool(delta.get("within_tolerance")),
                    )
                    for delta in item.get("deltas", [])
                ],
            )
            for item in results
        ]
    except Exception as e:
        logger.error("Failed to list billing reconciliation: %s", e)
        raise HTTPException(status_code=500, detail="Failed to list billing reconciliation")


@router.post(
    "/tenants/{tenant_id}/billing/adjustments",
    response_model=BillingAdjustmentResponse,
    summary="Create billing adjustment",
    description="Founder-only explicit credit or debit adjustment for a tenant billing period.",
)
async def create_billing_adjustment(
    tenant_id: str,
    request: BillingAdjustmentCreateRequest,
    founder_email: str = Depends(require_founder),
    adjustments: BillingAdjustmentService = Depends(get_billing_adjustments),
) -> BillingAdjustmentResponse:
    try:
        record = adjustments.create_adjustment(
            tenant_id=tenant_id,
            year=request.year,
            month=request.month,
            kind=request.kind,
            amount_usd=request.amount_usd,
            reason=request.reason,
            created_by=founder_email,
            metric_name=request.metric_name,
            note=request.note,
            evidence_url=request.evidence_url,
        )
        return BillingAdjustmentResponse(
            adjustment_id=record.adjustment_id,
            tenant_id=record.tenant_id,
            period=record.period,
            kind=record.kind,
            amount_usd=str(record.amount_usd),
            reason=record.reason,
            created_at=record.created_at,
            created_by=record.created_by,
            metric_name=record.metric_name,
            note=record.note,
            evidence_url=record.evidence_url,
            status=record.status,
        )
    except Exception as e:
        logger.error("Failed to create billing adjustment: %s", e)
        raise HTTPException(status_code=500, detail="Failed to create billing adjustment")


@router.get(
    "/tenants/{tenant_id}/billing/adjustments",
    response_model=list[BillingAdjustmentResponse],
    summary="List billing adjustments",
    description="Founder-only list of explicit billing adjustments for a tenant billing period.",
)
async def list_billing_adjustments(
    tenant_id: str,
    year: int,
    month: int,
    founder_email: str = Depends(require_founder),
    adjustments: BillingAdjustmentService = Depends(get_billing_adjustments),
) -> list[BillingAdjustmentResponse]:
    _ = founder_email
    try:
        records = adjustments.list_adjustments(tenant_id, year=year, month=month)
        return [
            BillingAdjustmentResponse(
                adjustment_id=record.adjustment_id,
                tenant_id=record.tenant_id,
                period=record.period,
                kind=record.kind,
                amount_usd=str(record.amount_usd),
                reason=record.reason,
                created_at=record.created_at,
                created_by=record.created_by,
                metric_name=record.metric_name,
                note=record.note,
                evidence_url=record.evidence_url,
                status=record.status,
            )
            for record in records
        ]
    except Exception as e:
        logger.error("Failed to list billing adjustments: %s", e)
        raise HTTPException(status_code=500, detail="Failed to list billing adjustments")


@router.post(
    "/billing/dlq/replay",
    response_model=DlqReplayResponse,
    summary="Replay dead-lettered billing usage events",
    description="Founder-only manual replay of failed usage metering events from the DLQ.",
)
async def replay_billing_dlq(
    request: DlqReplayRequest,
    founder_email: str = Depends(require_founder),
    ingress: BillingIngressService = Depends(get_billing_ingress),
) -> DlqReplayResponse:
    """Replay dead-lettered metering events for a tenant."""
    _ = founder_email
    try:
        replayed = ingress.replay_failed_usage(request.tenant_id, limit=request.limit)
        return DlqReplayResponse(
            tenant_id=request.tenant_id,
            replayed_count=len(replayed),
            items=replayed,
        )
    except Exception as e:
        logger.error("Failed to replay billing DLQ for tenant=%s: %s", request.tenant_id, e)
        raise HTTPException(status_code=500, detail="Failed to replay billing DLQ")


@router.get(
    "/tenants/{tenant_id}/runs/{run_id}/metering/receipts",
    response_model=list[dict[str, Any]],
    summary="List execution receipts for a tenant mission run",
    description="Founder-only read of canonical execution receipts (issue #1314).",
)
async def founder_list_metering_receipts(
    tenant_id: str,
    run_id: str,
    founder_email: str = Depends(require_founder),
) -> list[dict[str, Any]]:
    _ = founder_email
    try:
        return mission_shared.get_run_state_service().list_execution_receipts(
            tenant_id=tenant_id,
            run_id=run_id,
        )
    except ValueError as exc:
        detail = str(exc)
        if "not found" in detail.lower():
            raise HTTPException(status_code=404, detail=detail) from exc
        raise HTTPException(status_code=400, detail=detail) from exc
    except Exception as exc:
        logger.exception("Founder metering receipts failed tenant=%s run=%s", tenant_id, run_id)
        raise HTTPException(status_code=500, detail="Failed to list metering receipts") from exc


# ============================================================================
# M4.4 — Missing Admin Endpoints
# ============================================================================


@router.put(
    "/tenants/{tenant_id}/plan",
    response_model=ChangePlanResponse,
    summary="Change tenant plan tier",
    description="Founder-only override to change a tenant's plan tier.",
)
async def change_tenant_plan(
    tenant_id: str,
    request: ChangePlanRequest,
    founder_email: str = Depends(require_founder),
    lifecycle: AccountLifecycleService = Depends(get_account_lifecycle_service),
) -> ChangePlanResponse:
    """Change a tenant's plan tier (founder override)."""
    try:
        # Fetch current tenant metadata
        response = lifecycle._tenants_table.query(
            KeyConditionExpression="pk = :pk AND sk = :sk",
            ExpressionAttributeValues={":pk": tenant_id, ":sk": "METADATA"},
        )
        items = response.get("Items", [])
        if not items:
            raise HTTPException(status_code=404, detail="Organization not found")

        metadata = items[0]
        previous_tier = metadata.get("subscription", {}).get("plan_tier", "none")
        now = datetime.now(UTC).isoformat()

        # Update subscription.plan_tier in DynamoDB
        lifecycle._tenants_table.update_item(
            Key={"pk": tenant_id, "sk": "METADATA"},
            UpdateExpression="SET subscription.plan_tier = :tier, subscription.plan_changed_at = :ts, subscription.plan_changed_by = :by, subscription.plan_change_reason = :reason",
            ExpressionAttributeValues={
                ":tier": request.plan_tier,
                ":ts": now,
                ":by": founder_email,
                ":reason": request.reason,
            },
        )

        logger.info(
            "Plan changed for tenant=%s from=%s to=%s by=%s reason=%s",
            tenant_id,
            previous_tier,
            request.plan_tier,
            founder_email,
            request.reason,
        )

        return ChangePlanResponse(
            tenant_id=tenant_id,
            previous_tier=previous_tier,
            new_tier=request.plan_tier,
            changed_by=founder_email,
            changed_at=now,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to change plan for tenant=%s: %s", tenant_id, e)
        raise HTTPException(status_code=500, detail="Failed to change plan")


@router.post(
    "/tenants/{tenant_id}/trial",
    response_model=TrialActivateResponse,
    summary="Activate or extend trial",
    description="Founder-only trial activation or extension for a tenant.",
)
async def activate_trial(
    tenant_id: str,
    request: TrialActivateRequest,
    founder_email: str = Depends(require_founder),
    lifecycle: AccountLifecycleService = Depends(get_account_lifecycle_service),
) -> TrialActivateResponse:
    """Activate or extend a trial for a tenant."""
    try:
        # Verify tenant exists
        response = lifecycle._tenants_table.query(
            KeyConditionExpression="pk = :pk AND sk = :sk",
            ExpressionAttributeValues={":pk": tenant_id, ":sk": "METADATA"},
        )
        items = response.get("Items", [])
        if not items:
            raise HTTPException(status_code=404, detail="Organization not found")

        now_ts = int(time.time())
        trial_end_ts = now_ts + (request.days * 86400)
        trial_end_iso = datetime.fromtimestamp(trial_end_ts, tz=UTC).isoformat()

        lifecycle._tenants_table.update_item(
            Key={"pk": tenant_id, "sk": "METADATA"},
            UpdateExpression="SET subscription.#st = :status, subscription.trial_end = :end, subscription.trial_activated_by = :by, subscription.trial_reason = :reason",
            ExpressionAttributeNames={"#st": "status"},
            ExpressionAttributeValues={
                ":status": "trialing",
                ":end": trial_end_iso,
                ":by": founder_email,
                ":reason": request.reason,
            },
        )

        logger.info(
            "Trial activated for tenant=%s days=%d by=%s reason=%s",
            tenant_id,
            request.days,
            founder_email,
            request.reason,
        )

        return TrialActivateResponse(
            tenant_id=tenant_id,
            trial_end=trial_end_iso,
            days=request.days,
            activated_by=founder_email,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to activate trial for tenant=%s: %s", tenant_id, e)
        raise HTTPException(status_code=500, detail="Failed to activate trial")


@router.post(
    "/tenants/{tenant_id}/impersonate",
    response_model=ImpersonateResponse,
    summary="Impersonate tenant",
    description="Return a tenant-scoped session token for debugging (24h TTL, audit-logged). Founder access only.",
)
async def impersonate_tenant(
    tenant_id: str,
    request: Request,
    founder_email: str = Depends(require_founder),
    lifecycle: AccountLifecycleService = Depends(get_account_lifecycle_service),
) -> ImpersonateResponse:
    """Generate a tenant-scoped session token for founder impersonation."""
    try:
        # Verify tenant exists
        response = lifecycle._tenants_table.query(
            KeyConditionExpression="pk = :pk AND sk = :sk",
            ExpressionAttributeValues={":pk": tenant_id, ":sk": "METADATA"},
        )
        items = response.get("Items", [])
        if not items:
            raise HTTPException(status_code=404, detail="Organization not found")

        metadata = items[0]
        tenant_email = metadata.get("email", metadata.get("billing_email", ""))

        # Mint a 24-hour session token scoped to the target tenant
        ttl_24h = 24 * 60 * 60
        token = mint_browser_session_token(
            tenant_id=tenant_id,
            user_id=f"founder-impersonate:{founder_email}",
            email=tenant_email or founder_email,
            impersonator_id=founder_email,
            ttl_seconds=ttl_24h,
        )

        expires_at = datetime.fromtimestamp(int(time.time()) + ttl_24h, tz=UTC).isoformat()

        get_audit_logger().log(
            action=AuditAction.ADMIN_IMPERSONATION_STARTED,
            tenant_id=tenant_id,
            user_id=founder_email,
            impersonator_id=founder_email,
            resource_type="tenant",
            resource_id=tenant_id,
            severity=AuditSeverity.WARNING,
            metadata={
                "effective_user_id": f"founder-impersonate:{founder_email}",
                "effective_email": tenant_email or founder_email,
                "expires_at": expires_at,
                "ttl_seconds": ttl_24h,
            },
            ip_address=request.client.host if request.client else None,
            user_agent=request.headers.get("user-agent"),
        )
        logger.warning(
            "AUDIT: Founder impersonation tenant=%s by=%s expires=%s",
            tenant_id,
            founder_email,
            expires_at,
        )

        return ImpersonateResponse(
            tenant_id=tenant_id,
            token=token,
            expires_at=expires_at,
            impersonated_by=founder_email,
        )

    except HTTPException:
        raise
    except BrowserSessionTokenError as e:
        logger.error("Failed to mint impersonation token: %s", e)
        raise HTTPException(status_code=500, detail="Failed to create impersonation token")
    except Exception as e:
        logger.error("Failed to impersonate tenant=%s: %s", tenant_id, e)
        raise HTTPException(status_code=500, detail="Failed to impersonate organization")


@router.get(
    "/agents/global",
    response_model=GlobalAgentsResponse,
    summary="List all agents globally",
    description="List all agents across all tenants. Founder access only.",
)
async def list_global_agents(
    founder_email: str = Depends(require_founder),
    lifecycle: AccountLifecycleService = Depends(get_account_lifecycle_service),
) -> GlobalAgentsResponse:
    """List all agents across all tenants."""
    _ = founder_email
    try:
        # Discover tenants via TENANTS_ALL_INDEX, then query each tenant's agents.
        tenant_pks: list[str] = []
        start_key = None
        while True:
            kwargs: dict[str, Any] = {
                "KeyConditionExpression": "pk = :pk",
                "ExpressionAttributeValues": {":pk": TENANTS_ALL_INDEX_PK},
                "ProjectionExpression": "tenant_pk",
                "Limit": 500,
            }
            if start_key:
                kwargs["ExclusiveStartKey"] = start_key
            resp = lifecycle._tenants_table.query(**kwargs)
            for idx in resp.get("Items", []):
                tpk = str(idx.get("tenant_pk") or idx.get("sk") or "")
                if tpk:
                    tenant_pks.append(tpk)
            start_key = resp.get("LastEvaluatedKey")
            if not start_key:
                break

        agents: list[GlobalAgentSummary] = []
        for tpk in tenant_pks:
            agent_resp = lifecycle._tenants_table.query(
                KeyConditionExpression="pk = :pk AND begins_with(sk, :prefix)",
                ExpressionAttributeValues={":pk": tpk, ":prefix": "AGENT#"},
                Limit=200,
            )
            for item in agent_resp.get("Items", []):
                agents.append(
                    GlobalAgentSummary(
                        tenant_id=tpk,
                        agent_id=item.get("sk", "").removeprefix("AGENT#"),
                        agent_name=item.get("name", item.get("agent_name", "")),
                        status=item.get("status", "unknown"),
                        skill_count=int(item.get("skill_count", 0)),
                    )
                )

        return GlobalAgentsResponse(agents=agents, total=len(agents))

    except Exception as e:
        logger.error("Failed to list global agents: %s", e)
        raise HTTPException(status_code=500, detail="Failed to list global agents")


@router.get(
    "/health",
    response_model=SystemHealthResponse,
    summary="Aggregate system health",
    description="Aggregate system health check across infrastructure components. Founder access only.",
)
async def system_health(
    founder_email: str = Depends(require_founder),
) -> SystemHealthResponse:
    """Return aggregate system health status."""
    _ = founder_email
    components: list[ComponentHealth] = []

    # Check DynamoDB (tenants table)
    try:
        ddb = boto3.resource("dynamodb", region_name=os.getenv("AWS_REGION", "us-east-1"))
        table_name = resolve_table("tenants")
        table = ddb.Table(table_name)
        t0 = time.monotonic()
        table.table_status  # noqa: B018 — force table describe
        latency = (time.monotonic() - t0) * 1000
        components.append(
            ComponentHealth(
                name="dynamodb",
                status="healthy",
                latency_ms=round(latency, 1),
                detail=f"Table {table_name} is {table.table_status}",
            )
        )
    except Exception as e:
        components.append(
            ComponentHealth(
                name="dynamodb",
                status="degraded",
                detail=safe_error_detail(e),
            )
        )

    # Check S3 (evidence bucket)
    try:
        s3 = boto3.client("s3", region_name=os.getenv("AWS_REGION", "us-east-1"))
        bucket = os.getenv("EVIDENCE_BUCKET", "ww-evidence-prod-us-east-1")
        t0 = time.monotonic()
        s3.head_bucket(Bucket=bucket)
        latency = (time.monotonic() - t0) * 1000
        components.append(
            ComponentHealth(
                name="s3",
                status="healthy",
                latency_ms=round(latency, 1),
                detail=f"Bucket {bucket} accessible",
            )
        )
    except Exception as e:
        components.append(
            ComponentHealth(
                name="s3",
                status="degraded",
                detail=safe_error_detail(e),
            )
        )

    # Determine overall status
    statuses = [c.status for c in components]
    if all(s == "healthy" for s in statuses):
        overall = "healthy"
    elif any(s == "down" for s in statuses):
        overall = "down"
    else:
        overall = "degraded"

    return SystemHealthResponse(
        overall=overall,
        checked_at=datetime.now(UTC).isoformat(),
        components=components,
    )


@router.post(
    "/broadcast",
    response_model=BroadcastResponse,
    summary="Broadcast notification",
    description="Send a notification to all or selected tenants. Founder access only.",
)
async def broadcast_notification(
    request: BroadcastRequest,
    founder_email: str = Depends(require_founder),
    lifecycle: AccountLifecycleService = Depends(get_account_lifecycle_service),
) -> BroadcastResponse:
    """Send a notification to all or selected tenants."""
    try:
        if request.tenant_ids:
            target_ids = request.tenant_ids
        else:
            # Discover all tenants via fan-out index instead of table scan.
            target_ids = []
            _start_key = None
            while True:
                _kwargs: dict[str, Any] = {
                    "KeyConditionExpression": "pk = :pk",
                    "ExpressionAttributeValues": {":pk": TENANTS_ALL_INDEX_PK},
                    "ProjectionExpression": "tenant_pk",
                    "Limit": 500,
                }
                if _start_key:
                    _kwargs["ExclusiveStartKey"] = _start_key
                _resp = lifecycle._tenants_table.query(**_kwargs)
                for _item in _resp.get("Items", []):
                    _tpk = str(_item.get("tenant_pk") or _item.get("sk") or "")
                    if _tpk:
                        target_ids.append(_tpk)
                _start_key = _resp.get("LastEvaluatedKey")
                if not _start_key:
                    break

        broadcast_id = str(uuid.uuid4())
        now = datetime.now(UTC).isoformat()

        # Store broadcast record per target tenant
        for tid in target_ids:
            try:
                lifecycle._tenants_table.put_item(
                    Item={
                        "pk": tid,
                        "sk": f"NOTIFICATION#{broadcast_id}",
                        "title": request.title,
                        "message": request.message,
                        "severity": request.severity,
                        "sent_by": founder_email,
                        "sent_at": now,
                        "read": False,
                    }
                )
            except Exception as inner_e:
                logger.warning("Failed to deliver broadcast to tenant=%s: %s", tid, inner_e)

        logger.info(
            "Broadcast sent id=%s to=%d tenants by=%s severity=%s",
            broadcast_id,
            len(target_ids),
            founder_email,
            request.severity,
        )

        return BroadcastResponse(
            broadcast_id=broadcast_id,
            sent_to=len(target_ids),
            title=request.title,
            severity=request.severity,
            sent_at=now,
            sent_by=founder_email,
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error("Failed to send broadcast: %s", e)
        raise HTTPException(status_code=500, detail="Failed to send broadcast")
