"""Investigation Consent API endpoints.

Endpoints:
    POST /api/v1/consent/investigation         -- grant consent
    DELETE /api/v1/consent/investigation/{id}   -- revoke consent
    GET /api/v1/consent/investigation/{id}      -- check consent
    GET /api/v1/consent/investigation           -- list consents

Reference: issue #2342
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.models.investigation_consent import (
    InvestigationConsentEnvelope,
)
from apps.backend.providers.portable_store import create_portable_store
from apps.backend.providers.object_store import get_evidence_store
from apps.backend.services.investigation_consent_service import InvestigationConsentService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/consent/investigation", tags=["investigation-consent"])


def _service() -> InvestigationConsentService:
    """Create a service instance with live dependencies."""
    from apps.backend.config.table_names import resolve_table

    table_name = resolve_table("tenants", env_var="CONSENT_TABLE", default_short_name="consent")
    store = create_portable_store(table_name)
    evidence_store = get_evidence_store()
    return InvestigationConsentService(store=store, evidence_store=evidence_store)


# ---------------------------------------------------------------------------
# Request / Response schemas
# ---------------------------------------------------------------------------


class GrantConsentBody(BaseModel):
    """Request body for granting investigation consent."""

    investigation_id: str = Field(..., min_length=1, description="Investigation identifier")
    granted_by: str = Field(..., min_length=1, description="User who grants consent")
    scope: list[str] = Field(..., min_length=1, description="Allowed scopes")
    duration_hours: int = Field(..., gt=0, description="Duration in hours")
    metadata: dict[str, Any] | None = Field(default=None, description="Additional context")


class RevokeConsentBody(BaseModel):
    """Request body for revoking investigation consent."""

    reason: str = Field(..., min_length=1, description="Revocation reason")


class ConsentResponse(BaseModel):
    """Response for a single consent envelope."""

    consent_id: str
    tenant_id: str
    investigation_id: str
    granted_by: str
    scope: list[str]
    granted_at: str
    expires_at: str
    duration_hours: int
    audit_trail_ref: str | None = None
    revoked_at: str | None = None
    revocation_reason: str | None = None
    is_valid: bool
    metadata: dict[str, Any] = {}


def _envelope_to_response(envelope: InvestigationConsentEnvelope) -> ConsentResponse:
    return ConsentResponse(
        consent_id=envelope.consent_id,
        tenant_id=envelope.tenant_id,
        investigation_id=envelope.investigation_id,
        granted_by=envelope.granted_by,
        scope=envelope.scope,
        granted_at=envelope.granted_at,
        expires_at=envelope.expires_at,
        duration_hours=envelope.duration_hours,
        audit_trail_ref=envelope.audit_trail_ref,
        revoked_at=envelope.revoked_at,
        revocation_reason=envelope.revocation_reason,
        is_valid=not envelope.is_revoked() and not envelope.is_expired(),
        metadata=envelope.metadata,
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("", response_model=ConsentResponse, status_code=201)
async def grant_investigation_consent(
    body: GrantConsentBody,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ConsentResponse:
    """Grant investigation consent."""
    try:
        envelope = _service().grant_consent(
            tenant_id=tenant_id,
            investigation_id=body.investigation_id,
            granted_by=body.granted_by,
            scope=body.scope,
            duration_hours=body.duration_hours,
            metadata=body.metadata,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    return _envelope_to_response(envelope)


@router.delete("/{consent_id}", response_model=ConsentResponse)
async def revoke_investigation_consent(
    consent_id: str,
    body: RevokeConsentBody,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ConsentResponse:
    """Revoke investigation consent."""
    try:
        envelope = _service().revoke_consent(
            tenant_id=tenant_id,
            consent_id=consent_id,
            reason=body.reason,
        )
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    return _envelope_to_response(envelope)


@router.get("/{consent_id}", response_model=ConsentResponse)
async def check_investigation_consent(
    consent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ConsentResponse:
    """Check a specific investigation consent by ID."""
    svc = _service()
    pk = f"TENANT#{tenant_id}" if not tenant_id.startswith("TENANT#") else tenant_id
    sk = f"INVESTIGATION_CONSENT#{consent_id}"
    item = svc._store.get_item(pk, sk)
    if item is None:
        raise HTTPException(status_code=404, detail="Consent not found")
    envelope = InvestigationConsentEnvelope.from_dynamodb_item(item)
    return _envelope_to_response(envelope)


@router.get("", response_model=list[ConsentResponse])
async def list_investigation_consents(
    investigation_id: str | None = Query(default=None, description="Filter by investigation"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[ConsentResponse]:
    """List investigation consents for a tenant."""
    envelopes = _service().list_consents(
        tenant_id=tenant_id,
        investigation_id=investigation_id,
    )
    return [_envelope_to_response(e) for e in envelopes]
