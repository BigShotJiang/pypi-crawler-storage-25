"""Canonical intelligence API surface.

Endpoints:
    GET  /api/v1/intelligence/briefing        — daily briefing
    GET  /api/v1/intelligence/anomalies        — detected anomalies
    POST /api/v1/intelligence/check-alignment  — goal alignment check
    POST /api/v1/intelligence/score-proposal   — proposal scoring
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/intelligence", tags=["intelligence"])


# ---------------------------------------------------------------------------
# Dependency
# ---------------------------------------------------------------------------


def _get_intelligence_aggregator():  # type: ignore[return]
    from apps.backend.services.inference_aggregator import get_intelligence_aggregator

    return get_intelligence_aggregator()


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class CheckAlignmentRequest(BaseModel):
    agent_id: str = Field("default", description="Target agent identifier")
    goal_description: str = Field(..., min_length=1, description="Natural-language goal statement")
    evidence_items: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Evidence items for developmental context (empty falls back to stored data)",
    )


class CheckAlignmentResponse(BaseModel):
    alignment_score: float = Field(..., ge=0.0, le=1.0, description="Alignment score 0-1")
    agent_id: str
    goal_description: str


class ScoreProposalRequest(BaseModel):
    skill_id: str = Field(..., min_length=1, description="Skill identifier for the proposal")
    agent_id: str = Field("default", description="Agent context for scoring")


class ScoreProposalResponse(BaseModel):
    proposal_score: float = Field(..., ge=0.0, le=1.0, description="Proposal value score 0-1")
    skill_id: str
    agent_id: str


class AnomalyItem(BaseModel):
    description: str
    severity: str = "warning"


class AnomaliesResponse(BaseModel):
    agent_id: str
    anomalies: list[AnomalyItem]
    count: int


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("/briefing")
async def get_briefing(
    agent_id: str = Query("default", description="Agent to get briefing for"),
    tenant_id: str = Depends(get_verified_tenant_id),
    aggregator: Any = Depends(_get_intelligence_aggregator),
) -> dict[str, Any]:
    """Return the daily intelligence briefing for the current tenant.

    Aggregates developmental context, proactive signals, pending suggestions,
    growth areas, and anomalies via IntelligenceAggregator.get_daily_briefing().
    """
    try:
        briefing = await aggregator.get_daily_briefing(tenant_id, agent_id)
    except Exception as exc:
        logger.error("Intelligence briefing failed for %s: %s", tenant_id, exc)
        raise HTTPException(status_code=503, detail="Intelligence briefing service temporarily unavailable")

    briefing["tenant_id"] = tenant_id
    return briefing


@router.get("/anomalies")
async def get_anomalies(
    agent_id: str = Query("default", description="Agent to check for anomalies"),
    tenant_id: str = Depends(get_verified_tenant_id),
    aggregator: Any = Depends(_get_intelligence_aggregator),
) -> dict[str, Any]:
    """Detect developmental regressions, stuck phases, and imbalances.

    Returns a list of human-readable anomaly descriptions with severity indicators.
    """
    try:
        anomaly_strings = aggregator.detect_anomalies(tenant_id, agent_id)
    except Exception as exc:
        logger.error("Anomaly detection failed for %s: %s", tenant_id, exc)
        raise HTTPException(status_code=503, detail="Anomaly detection service temporarily unavailable")

    anomalies = []
    for desc in anomaly_strings:
        severity = "critical" if "Regression" in desc else ("warning" if "Stuck" in desc else "info")
        anomalies.append({"description": desc, "severity": severity})

    return {
        "agent_id": agent_id,
        "anomalies": anomalies,
        "count": len(anomalies),
    }


@router.post("/check-alignment")
async def check_alignment(
    request: CheckAlignmentRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    aggregator: Any = Depends(_get_intelligence_aggregator),
) -> dict[str, Any]:
    """Score how well a goal aligns with the agent's developmental context.

    Returns alignment score in [0.0, 1.0]. Higher scores mean better alignment
    with growth-hungry quadrants.
    """
    from apps.backend.services.inference_aggregator import GoalAlignmentUnavailableError

    try:
        score = aggregator.check_goal_alignment(
            tenant_id,
            request.agent_id,
            request.goal_description,
            request.evidence_items,
        )
    except GoalAlignmentUnavailableError:
        raise HTTPException(status_code=503, detail="Goal alignment service temporarily unavailable")
    except Exception as exc:
        logger.error("Goal alignment check failed for %s: %s", tenant_id, exc)
        raise HTTPException(status_code=503, detail="Goal alignment service temporarily unavailable")

    return {
        "alignment_score": score,
        "agent_id": request.agent_id,
        "goal_description": request.goal_description,
    }


@router.post("/score-proposal")
async def score_proposal(
    request: ScoreProposalRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    aggregator: Any = Depends(_get_intelligence_aggregator),
) -> dict[str, Any]:
    """Score a learning proposal using developmental context.

    Skills targeting quadrants with low scores (more room to grow) receive
    higher proposal value scores.
    """
    try:
        score = aggregator.score_proposal(
            tenant_id,
            {"skill_id": request.skill_id, "agent_id": request.agent_id},
        )
    except Exception as exc:
        logger.error("Proposal scoring failed for %s: %s", tenant_id, exc)
        raise HTTPException(status_code=503, detail="Proposal scoring service temporarily unavailable")

    return {
        "proposal_score": score,
        "skill_id": request.skill_id,
        "agent_id": request.agent_id,
    }
