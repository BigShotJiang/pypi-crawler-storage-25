"""Learning Signal DLQ API -- list, inspect, and replay dead-lettered signals."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.models.learning_signal_dlq import (
    LearningSignalDLQListResponse,
    LearningSignalDLQResponse,
    ReplayResponse,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/learning/dlq", tags=["learning-dlq"])


def _get_queue():
    from apps.backend.services.learning.learning_signal_queue import LearningSignalQueue
    return LearningSignalQueue()


def _envelope_to_response(envelope: Any) -> LearningSignalDLQResponse:
    return LearningSignalDLQResponse(
        id=envelope.id, tenant_id=envelope.tenant_id, work_item_id=envelope.work_item_id,
        attempt_id=envelope.attempt_id, idempotency_key=envelope.idempotency_key,
        attempts=envelope.attempts, dead_lettered=envelope.dead_lettered,
        last_error=envelope.last_error, next_retry_at=envelope.next_retry_at,
        created_at=envelope.created_at, updated_at=envelope.updated_at,
    )


@router.get("", response_model=LearningSignalDLQListResponse)
async def list_dlq(
    limit: int = Query(50, ge=1, le=200),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> LearningSignalDLQListResponse:
    queue = _get_queue()
    envelopes = queue.list_dlq(tenant_id, limit=limit)
    return LearningSignalDLQListResponse(items=[_envelope_to_response(e) for e in envelopes], count=len(envelopes))


@router.get("/{envelope_id}", response_model=LearningSignalDLQResponse)
async def inspect_dlq(envelope_id: str, tenant_id: str = Depends(get_verified_tenant_id)) -> LearningSignalDLQResponse:
    queue = _get_queue()
    envelope = queue.inspect(envelope_id, tenant_id)
    if envelope is None:
        raise HTTPException(status_code=404, detail="DLQ entry not found")
    return _envelope_to_response(envelope)


@router.post("/{envelope_id}/replay", response_model=ReplayResponse)
async def replay_dlq(envelope_id: str, tenant_id: str = Depends(get_verified_tenant_id)) -> ReplayResponse:
    queue = _get_queue()
    envelope = queue.replay(envelope_id, tenant_id)
    if envelope is None:
        raise HTTPException(status_code=404, detail="DLQ entry not found")
    return ReplayResponse(replayed=True, id=envelope.id, message="DLQ entry queued for replay")
