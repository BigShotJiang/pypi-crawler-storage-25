"""HTTP error-mapping for cold-outreach pre-send blocks (issue #1153 layer 1).

Codex round-1 review of #1153: ``PreSendBlockedError`` semantics weren't
surfaced at the API layer. This module gives every HTTP route that drives
cold-outreach a single helper that maps a blocked send to the right
status code + headers + structured detail body.

Mapping (per the spec capture-surface vocabulary):

- ``suppressed_before_send``       → 412 Precondition Failed
- ``rate_limit_hit``               → 429 Too Many Requests + ``Retry-After``
- ``deliverability_not_configured`` → 412 Precondition Failed
- ``consent_missing``              → 403 Forbidden
- (anything else)                  → 412 Precondition Failed (default)

The detail body always carries:

- ``error``                — short machine code (== capture_surface)
- ``step``                 — the chain step that blocked
- ``reason``               — human-readable reason from the check
- ``evidence_event_id``    — pointer into the evidence ledger
- ``retry_after_seconds``  — when present (rate_limit case)

Routes use this as::

    try:
        guard.run(ctx)
    except PreSendBlockedError as exc:
        raise map_pre_send_block(exc)
"""

from __future__ import annotations

from fastapi import HTTPException, status

from apps.backend.services.channels.pre_send_guard import PreSendBlockedError


_STATUS_BY_CAPTURE_SURFACE: dict[str, int] = {
    "suppressed_before_send": status.HTTP_412_PRECONDITION_FAILED,
    "rate_limit_hit": status.HTTP_429_TOO_MANY_REQUESTS,
    "deliverability_not_configured": status.HTTP_412_PRECONDITION_FAILED,
    "deliverability_unverified": status.HTTP_412_PRECONDITION_FAILED,
    "consent_missing": status.HTTP_403_FORBIDDEN,
    "consent_unverified": status.HTTP_403_FORBIDDEN,
}


def map_pre_send_block(exc: PreSendBlockedError) -> HTTPException:
    """Convert a ``PreSendBlockedError`` to a FastAPI ``HTTPException``.

    Returns the exception (caller raises it). Includes ``Retry-After``
    header for rate-limit blocks per RFC 7231 §7.1.3.
    """
    capture = exc.check.capture_surface
    code = _STATUS_BY_CAPTURE_SURFACE.get(capture, status.HTTP_412_PRECONDITION_FAILED)

    detail: dict[str, object] = {
        "error": capture,
        "step": exc.check.name,
        "reason": exc.check.reason,
        "evidence_event_id": exc.evidence_event_id,
    }
    if exc.check.retry_after_seconds is not None:
        detail["retry_after_seconds"] = exc.check.retry_after_seconds

    headers: dict[str, str] = {}
    if code == status.HTTP_429_TOO_MANY_REQUESTS and exc.check.retry_after_seconds:
        headers["Retry-After"] = str(int(exc.check.retry_after_seconds))

    return HTTPException(status_code=code, detail=detail, headers=headers or None)


__all__ = ["map_pre_send_block"]
