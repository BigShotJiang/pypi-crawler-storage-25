"""
Push Notification API

Web Push subscription management for Mission Control PWA.
Endpoints for subscribing, unsubscribing, and sending test notifications.

Source: docs/PRODUCT.md#Part18.5

Issue #1160: subscriptions + preferences persist in the canonical
``push_subscription_store`` (DDB-backed under managed SaaS, portable
under self-host). The module-level ``_subscriptions`` / ``_preferences``
dicts remain as degraded-mode cache only — any DDB outage preserves
service availability but the store is authoritative for reads on
process restart.
"""

import logging
import os
from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.services.push_subscription_store import get_push_subscription_store

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/mission/push", tags=["push-notifications"])


# --- Models ---

class PushSubscription(BaseModel):
    """Web Push subscription from browser."""
    endpoint: str = Field(..., description="Push service endpoint URL")
    keys: dict[str, str] = Field(..., description="p256dh and auth keys")


class SubscribeRequest(BaseModel):
    """Subscribe to push notifications."""
    subscription: PushSubscription
    device_name: str | None = Field(None, description="Human-readable device name")


class SubscribeResponse(BaseModel):
    subscription_id: str
    device_name: str | None
    subscribed_at: str


class PushPreferences(BaseModel):
    """Push notification preferences."""
    needs_attention: bool = Field(True, description="Notify when items need human attention")
    task_completed: bool = Field(True, description="Notify when AI completes a task")
    emergency_alerts: bool = Field(True, description="Always notify for emergency stops")
    daily_briefing: bool = Field(True, description="Morning briefing push")
    quiet_hours_start: str | None = Field(None, description="HH:MM format, e.g. 22:00")
    quiet_hours_end: str | None = Field(None, description="HH:MM format, e.g. 08:00")


# --- Storage ---
#
# Issue #1160: authoritative state is the portable push-subscription store
# below; the module-level dicts are retained ONLY as degraded-mode cache
# when the underlying DDB/portable store is briefly unreachable. All
# readers should go through the store façade (``get_push_subscription_store``)
# so process restarts preserve subscriptions.

# In-memory caches — canonical dicts live in services.push_cache (issue #3785).
from apps.backend.services.push_cache import preferences as _preferences  # noqa: F401
from apps.backend.services.push_cache import subscriptions as _subscriptions  # noqa: F401


# --- VAPID Key ---

def get_vapid_public_key() -> str:
    """Return VAPID public key for client-side subscription."""
    return os.getenv("VAPID_PUBLIC_KEY", "")


# --- Endpoints ---

@router.get("/vapid-key")
async def vapid_key() -> dict[str, str]:
    """Return the VAPID public key for the browser to subscribe."""
    key = get_vapid_public_key()
    if not key:
        raise HTTPException(status_code=503, detail="VAPID keys not configured")
    return {"public_key": key}


@router.post("/subscribe", response_model=SubscribeResponse)
async def subscribe(
    req: SubscribeRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SubscribeResponse:
    """Register a push subscription for the current device."""
    sub_id = f"push_{uuid4().hex[:12]}"
    now = datetime.now(UTC).replace(tzinfo=None).isoformat() + "Z"
    record = {
        "subscription_id": sub_id,
        "tenant_id": tenant_id,
        "subscription": req.subscription.model_dump(),
        "device_name": req.device_name,
        "subscribed_at": now,
    }
    # Write through to the durable store (Issue #1160). Cache update + store
    # put are both handled inside put_subscription.
    get_push_subscription_store().put_subscription(record)
    # Legacy cache mirror — keep so any remaining direct-dict readers still
    # see the fresh record. To be removed once callers migrate to the store.
    _subscriptions[sub_id] = record
    logger.info("Push subscription created: %s for tenant %s", sub_id, tenant_id)
    return SubscribeResponse(
        subscription_id=sub_id,
        device_name=req.device_name,
        subscribed_at=now,
    )


@router.delete("/subscribe/{subscription_id}")
async def unsubscribe(
    subscription_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, str]:
    """Remove a push subscription."""
    store = get_push_subscription_store()
    # Council BLOCK #1234: ownership check must be authoritative, not
    # cache-only. Passing tenant_id lets the store do a DDB point-read
    # which works on cold cache AND after a worker restart.
    existing = store.get_subscription(subscription_id, tenant_id=tenant_id)
    if existing is None:
        # Either the row does not exist or it belongs to another tenant
        # (store.get_subscription filters by tenant). Return 404 in both
        # cases to avoid leaking existence across tenant boundaries.
        return {"status": "not_found", "subscription_id": subscription_id}
    deleted = store.delete_subscription(
        tenant_id=tenant_id, subscription_id=subscription_id
    )
    if not deleted:
        # Store write failed → the DDB row might still be live. Surface
        # a 503 so clients retry instead of treating this as a successful
        # unsubscribe.
        raise HTTPException(
            status_code=503,
            detail={
                "error": "push_subscription_revoke_failed",
                "subscription_id": subscription_id,
                "retry": True,
            },
        )
    if subscription_id in _subscriptions and _subscriptions[subscription_id].get("tenant_id") == tenant_id:
        del _subscriptions[subscription_id]
    logger.info("Push subscription removed: %s for tenant %s", subscription_id, tenant_id)
    return {"status": "unsubscribed", "subscription_id": subscription_id}


@router.get("/preferences", response_model=PushPreferences)
async def get_preferences(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PushPreferences:
    """Get push notification preferences."""
    stored = get_push_subscription_store().get_preferences(tenant_id)
    if stored is not None:
        # Drop the pk/sk/tenant_id fields that leak store internals.
        return PushPreferences(
            **{k: v for k, v in stored.items() if k in PushPreferences.model_fields}
        )
    return _preferences.get(tenant_id, PushPreferences())


@router.put("/preferences", response_model=PushPreferences)
async def update_preferences(
    prefs: PushPreferences,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PushPreferences:
    """Update push notification preferences."""
    record = {"tenant_id": tenant_id, **prefs.model_dump()}
    get_push_subscription_store().put_preferences(tenant_id, record)
    _preferences[tenant_id] = prefs
    logger.info("Push preferences updated for tenant %s", tenant_id)
    return prefs


@router.get("/subscriptions")
async def list_subscriptions(
    tenant_id: str = Depends(get_verified_tenant_id),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> list[dict[str, Any]]:
    """List all active push subscriptions for the tenant."""
    store_rows = get_push_subscription_store().list_for_tenant(tenant_id)
    subscriptions = [
        {
            "subscription_id": s["subscription_id"],
            "device_name": s.get("device_name"),
            "subscribed_at": s["subscribed_at"],
        }
        for s in store_rows
        if s.get("subscription_id")
    ]
    paged_subscriptions, _total = paginate_items(subscriptions, pagination)
    return paged_subscriptions
