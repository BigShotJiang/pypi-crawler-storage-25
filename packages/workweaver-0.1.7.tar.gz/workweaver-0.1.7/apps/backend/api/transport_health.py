"""Transport health REST API routes.

#3216: Exposes transport health telemetry via REST endpoints for CLI
`ww doctor diagnostics` and founder admin inspection.

Endpoints:
  GET /api/v1/transport-health/summary  - aggregate provider health
  GET /api/v1/transport-health/deep     - full event history + diagnostics
"""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends

from apps.backend.api.founder_admin import require_founder
from apps.backend.services.transport_health_telemetry import (
    get_transport_health_telemetry,
)

router = APIRouter(
    prefix="/api/v1/transport-health",
    tags=["transport-health"],
)


@router.get("/summary")
async def get_transport_health_summary(
    _founder: str = Depends(require_founder),
) -> dict[str, Any]:
    """Return aggregate transport health summary.

    Returns per-provider latest state, total event count, and per-provider
    event counts. Used by ``ww diagnostics`` for quick status checks.
    """
    telemetry = get_transport_health_telemetry()
    return telemetry.get_summary()


@router.get("/deep")
async def get_transport_health_deep(
    _founder: str = Depends(require_founder),
) -> dict[str, Any]:
    """Return deep transport health diagnostics.

    Includes full summary plus the last 100 events with provider, state,
    cause, session_id, latency_ms, and timestamp. Used by
    ``ww diagnostics --deep`` for detailed inspection.
    """
    telemetry = get_transport_health_telemetry()
    return telemetry.get_deep_diagnostics()
