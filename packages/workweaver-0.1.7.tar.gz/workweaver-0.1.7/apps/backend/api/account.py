"""Account service-entitlement API (#3050 child).

GET /api/v1/account/status returns the typed AccountServiceEntitlement payload
that closes the loop between the dashboard banner (#3088) and the
``_derive_lifecycle_state`` derivation in the billing module (#3111).

This module is intentionally a thin façade. It owns:

* Pulling the authenticated tenant from ``get_verified_tenant_id``.
* Looking up the tenant record via the existing
  ``SubscriptionManager._get_tenant_record`` (same fall-open semantics as
  ``GET /api/v1/billing/lifecycle``).
* Mapping the derived ``lifecycle_state`` string onto the
  ``AccountLifecycleState`` enum.
* Resolving the deployment profile (env-driven, falls back to
  ``local_native``) so the response can express whether Stripe / managed-cloud
  capacity are gates for this workspace.

It does NOT modify ``_derive_lifecycle_state`` (already shipped) or the
dashboard banner (already shipped). Admin pause/throttle/restore endpoints,
owner email templates, and the Resource Policy decision-class UI are tracked
as out-of-scope follow-ups on the parent #3050.
"""

from __future__ import annotations

import logging
import os
from datetime import datetime
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel

from apps.backend.api.billing.subscription import (
    _derive_lifecycle_state,
    get_subscription_manager,
)
from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.config.table_names import resolve_table  # noqa: F401 — kept for parity
from apps.backend.models.account_service_entitlement import (
    AccountLifecycleState,
    AccountServiceEntitlement,
    DeploymentProfileLiteral,
)
from apps.backend.services.billing.subscription_service import (
    SubscriptionManager,
    SubscriptionManagerError,
    SubscriptionNotFoundError,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/account", tags=["account-status"])


# ---------------------------------------------------------------------------
# Mapping helpers
# ---------------------------------------------------------------------------


# String values returned by ``_derive_lifecycle_state`` mapped onto the
# canonical enum surfaced to the frontend. Documented in the PR body.
#
# Notes (#3050):
#   * ``cancelled``       -> ``SUSPENDED``  (admin route, not renew)
#   * ``grace_period``    -> ``PAST_DUE``   (collapse to a single banner state)
#   * ``past_due``        -> ``PAST_DUE``
#   * ``trial`` / ``trial_expired`` / ``paused`` / ``throttled`` /
#     ``suspended`` / ``locked`` map one-to-one.
_LIFECYCLE_STATE_MAP: dict[str, AccountLifecycleState] = {
    "active": AccountLifecycleState.ACTIVE,
    "trial": AccountLifecycleState.TRIAL,
    "trial_expired": AccountLifecycleState.TRIAL_EXPIRED,
    "grace_period": AccountLifecycleState.PAST_DUE,
    "past_due": AccountLifecycleState.PAST_DUE,
    "paused": AccountLifecycleState.PAUSED,
    "throttled": AccountLifecycleState.THROTTLED,
    "suspended": AccountLifecycleState.SUSPENDED,
    "locked": AccountLifecycleState.LOCKED,
    "cancelled": AccountLifecycleState.SUSPENDED,
}

# Deployment profiles where managed-cloud capacity is entitled to execute and
# Stripe is the canonical billing gate.  Self-host / standalone keep Stripe
# dormant in their first-value path (#3051 smoke).
_MANAGED_PROFILE: DeploymentProfileLiteral = "managed_saas"

_SUPPORTED_PROFILES: tuple[DeploymentProfileLiteral, ...] = (
    "managed_saas",
    "self_host_production",
    "standalone",
    "local_native",
)


def _resolve_deployment_profile() -> DeploymentProfileLiteral:
    """Resolve the deployment profile from env, fall back to local_native.

    We intentionally do NOT call into ``providers.base.get_deployment_profile``
    here — the entitlement endpoint must avoid the cached process-wide profile
    detection so tests / multi-region rollouts can drive the response purely
    from ``WORKWEAVER_DEPLOYMENT_PROFILE``. Anything unknown collapses to
    ``local_native`` (the conservative, Stripe-dormant choice).
    """
    raw = os.environ.get("WORKWEAVER_DEPLOYMENT_PROFILE", "").strip().lower()
    if raw in _SUPPORTED_PROFILES:
        return raw  # type: ignore[return-value]
    return "local_native"


def _map_lifecycle_state(derived: str) -> AccountLifecycleState:
    """Map the derived lifecycle string onto the public enum.

    Unknown values (registry drift, future states not yet enumerated) collapse
    to ``ACTIVE`` so the banner stays out of the way — the same fall-open
    posture as ``GET /api/v1/billing/lifecycle``.
    """
    return _LIFECYCLE_STATE_MAP.get(str(derived or "").strip().lower(), AccountLifecycleState.ACTIVE)


def _renewal_required_at(
    state: AccountLifecycleState,
    tenant_record: dict[str, Any],
) -> datetime | None:
    """Return the renewal deadline only for states that need it.

    Only ``TRIAL``, ``TRIAL_EXPIRED``, and ``PAST_DUE`` populate this field
    (matches the banner's CTA ladder). Resolution order, first hit wins:

      1. ``tenant.trial_ends_at``        (trial / trial_expired)
      2. ``tenant.subscription.trial_end`` (legacy mirror)
      3. ``tenant.dunning.next_retry_at``  (past_due)
      4. ``tenant.renewal_required_at``    (admin override)
    """
    if state not in {
        AccountLifecycleState.TRIAL,
        AccountLifecycleState.TRIAL_EXPIRED,
        AccountLifecycleState.PAST_DUE,
    }:
        return None

    candidates: list[Any] = []
    if state in {AccountLifecycleState.TRIAL, AccountLifecycleState.TRIAL_EXPIRED}:
        candidates.append(tenant_record.get("trial_ends_at"))
        sub = tenant_record.get("subscription") or {}
        if isinstance(sub, dict):
            candidates.append(sub.get("trial_end"))
    if state == AccountLifecycleState.PAST_DUE:
        dunning = tenant_record.get("dunning") or {}
        if isinstance(dunning, dict):
            candidates.append(dunning.get("next_retry_at"))
    candidates.append(tenant_record.get("renewal_required_at"))

    for raw in candidates:
        parsed = _coerce_datetime(raw)
        if parsed is not None:
            return parsed
    return None


def _coerce_datetime(raw: Any) -> datetime | None:
    """Best-effort ISO/datetime coercion. Returns ``None`` on failure."""
    if raw is None:
        return None
    if isinstance(raw, datetime):
        return raw
    text = str(raw).strip()
    if not text:
        return None
    # Accept the trailing ``Z`` zulu form Stripe emits.
    text = text.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(text)
    except ValueError:
        return None


def _throttle_reason(
    state: AccountLifecycleState, tenant_record: dict[str, Any]
) -> str | None:
    """Return a throttle reason only when state == throttled and one is set."""
    if state != AccountLifecycleState.THROTTLED:
        return None
    raw = tenant_record.get("throttle_reason")
    if raw is None:
        return None
    text = str(raw).strip()
    return text or None


def _evidence_id(tenant_record: dict[str, Any]) -> str | None:
    """Pull the most recent lifecycle-transition evidence id, if any."""
    raw = (
        tenant_record.get("lifecycle_evidence_id")
        or tenant_record.get("last_lifecycle_evidence_id")
        or None
    )
    if raw is None:
        return None
    text = str(raw).strip()
    return text or None


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------


class _DegradedEntitlementError(BaseModel):
    """Internal type — never returned. Documents the fall-open contract."""


@router.get(
    "/status",
    response_model=AccountServiceEntitlement,
    summary="Get account service entitlement",
    description=(
        "Return the AccountServiceEntitlement for the authenticated workspace. "
        "Per PRODUCT-CONTEXT.md §21, capabilities_visible is always 'all' — "
        "managed lifecycle gates *entitlement*, not *feature presence*."
    ),
)
async def get_account_status(
    verified_tenant_id: str = Depends(get_verified_tenant_id),
    subscription_mgr: SubscriptionManager = Depends(get_subscription_manager),
) -> AccountServiceEntitlement:
    """Return the typed service-entitlement snapshot for the verified tenant.

    Fall-open semantics mirror ``GET /api/v1/billing/lifecycle``: if the tenant
    record is missing, the tenants table is unreachable, or DDB raises
    transiently, we return ``state=ACTIVE`` so the banner never blocks a
    working workspace. Concrete lifecycle escalation only happens when we have
    evidence in the tenant record.
    """
    deployment_profile = _resolve_deployment_profile()
    pk_tenant_id = (
        verified_tenant_id
        if verified_tenant_id.startswith("TENANT#")
        else f"TENANT#{verified_tenant_id}"
    )

    tenant_record: dict[str, Any] | None
    try:
        record = subscription_mgr._get_tenant_record(pk_tenant_id)  # type: ignore[attr-defined]
        tenant_record = record if isinstance(record, dict) else None
    except SubscriptionNotFoundError:
        tenant_record = None
    except SubscriptionManagerError as exc:
        logger.warning("account_status_lookup_failed: %s", exc)
        tenant_record = None
    except HTTPException:
        raise
    except Exception as exc:  # pragma: no cover — defensive fall-open
        logger.error("account_status_unexpected_error: %s", exc)
        tenant_record = None

    if not tenant_record:
        return AccountServiceEntitlement(
            workspace_id=verified_tenant_id,
            deployment_profile=deployment_profile,
            state=AccountLifecycleState.ACTIVE,
            capabilities_visible="all",
            managed_cloud_capacity_enabled=(deployment_profile == _MANAGED_PROFILE),
            stripe_required=(deployment_profile == _MANAGED_PROFILE),
            renewal_required_at=None,
            throttle_reason=None,
            evidence_id=None,
        )

    derived_state, _ = _derive_lifecycle_state(tenant_record)
    state = _map_lifecycle_state(derived_state)

    return AccountServiceEntitlement(
        workspace_id=verified_tenant_id,
        deployment_profile=deployment_profile,
        state=state,
        capabilities_visible="all",
        managed_cloud_capacity_enabled=(deployment_profile == _MANAGED_PROFILE),
        stripe_required=(deployment_profile == _MANAGED_PROFILE),
        renewal_required_at=_renewal_required_at(state, tenant_record),
        throttle_reason=_throttle_reason(state, tenant_record),
        evidence_id=_evidence_id(tenant_record),
    )
