"""
Stripe Webhook Handlers (TASK-6.0B.003)

Handles Stripe webhook events for payment confirmation and tenant provisioning.
Constitutional compliance:
- Axiom 2: Stores payment events in Operational Context (Architecture B)
- Axiom 5: Agents execute Defined Work (tenant activation)
"""
from apps.backend.config.table_names import resolve_table

import asyncio
from datetime import UTC, datetime
from decimal import Decimal, ROUND_HALF_UP
import json
import logging
import os
from typing import Any

import stripe
from fastapi import APIRouter, Request, HTTPException, Header
from pydantic import BaseModel, Field

from apps.backend.config.environment import get_environment
from apps.backend.services.tenant_provisioning import get_tenant_provisioning_service
from apps.backend.services.payment_event_resource_store import get_payment_event_resource_store
from apps.backend.services.evidence_ledger import get_evidence_ledger_service
from apps.backend.services.billing.stripe_webhook_outbox import get_stripe_webhook_outbox_service
from apps.backend.services.billing.subscription_service import SubscriptionManager
from apps.backend.config.secrets import get_stripe_secret_key, get_stripe_webhook_secret
from apps.backend.config.pricing import WORKMEMORY_PLANS, WORKWEAVER_PLANS
from apps.backend.services.runtime.provisioning_service import (
    RuntimeProvisioningError,
    get_workweaver_runtime_provisioning_service,
)
from apps.backend.utils.time import utc_now_iso

# Configure logging
logger = logging.getLogger(__name__)


def _bool_env(name: str, default: bool = False) -> bool:
    return os.getenv(name, str(default)).strip().lower() in {"1", "true", "yes", "on"}


RUNTIME_AUTO_PROVISION_AFTER_PAYMENT = _bool_env("RUNTIME_AUTO_PROVISION_AFTER_PAYMENT", True)

# Router
router = APIRouter()


# ============================================================================
# Models
# ============================================================================


class WebhookEvent(BaseModel):
    """Stripe webhook event model."""

    id: str = Field(..., description="Event ID")
    type: str = Field(..., description="Event type")
    data: dict[str, Any] = Field(..., description="Event data")
    created: int = Field(..., description="Event creation timestamp")
    livemode: bool = Field(False, description="Whether this is a live event")


class TenantProvisioningResult(BaseModel):
    """Result of tenant provisioning from webhook."""

    tenant_id: str = Field(..., description="Tenant ID")
    status: str = Field(..., description="Provisioning status")
    message: str | None = Field(None, description="Status message")


def _evidence_url(evidence_id: str | None) -> str | None:
    if not evidence_id:
        return None
    return f"/api/v1/evidence/{evidence_id}"


def _expected_checkout_amount_usd(metadata: dict[str, Any]) -> Decimal | None:
    product = str(metadata.get("signup_product") or "").strip().lower()
    tier = str(metadata.get("signup_tier") or "").strip().lower()
    billing = str(metadata.get("signup_billing") or "monthly").strip().lower()
    if billing != "monthly" or not product or not tier:
        return None

    if product == "workweaver":
        plan = WORKWEAVER_PLANS.get(tier)
    elif product == "workmemory":
        plan = WORKMEMORY_PLANS.get(tier)
    else:
        plan = None

    if not plan:
        return None

    base_amount = plan.get("monthly_usd")
    if base_amount is None:
        return None

    discount_pct = Decimal(str(metadata.get("invite_discount_pct", "0")))
    multiplier = (Decimal("100") - discount_pct) / Decimal("100")
    expected = (Decimal(str(base_amount)) * multiplier).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
    return expected


def _resolve_stripe_secret_key() -> str:
    configured = os.getenv("STRIPE_API_KEY", "").strip()
    if configured:
        return configured
    return (get_stripe_secret_key(get_environment()) or "").strip()


def _resolve_stripe_webhook_secret() -> str:
    configured = os.getenv("STRIPE_WEBHOOK_SECRET", "").strip()
    if configured:
        return configured
    return (get_stripe_webhook_secret(get_environment()) or "").strip()


def _resolve_tenant_id_from_subscription(
    manager: SubscriptionManager,
    subscription: dict[str, Any],
) -> str:
    metadata = subscription.get("metadata", {}) if isinstance(subscription, dict) else {}
    tenant_id = str(metadata.get("tenant_id") or "").strip()
    if tenant_id:
        return tenant_id
    subscription_id = str(subscription.get("id") or "").strip()
    if not subscription_id:
        return "unknown"
    # Resolve via STRIPE_SUB fan-out index (written at activation) — no table scan.
    idx_resp = manager.tenants_table.get_item(
        Key={"pk": f"STRIPE_SUB#{subscription_id}", "sk": "TENANT_REF"},
    )
    idx_item = idx_resp.get("Item")
    if not idx_item:
        return "unknown"
    tenant_pk = str(idx_item.get("tenant_pk") or "")
    if not tenant_pk.startswith("TENANT#"):
        return "unknown"
    return tenant_pk


def _update_subscription_snapshot(
    manager: SubscriptionManager,
    *,
    tenant_id: str,
    subscription: dict[str, Any],
    tenant_status: str,
    evidence_event_id: str | None = None,
    evidence_event_url: str | None = None,
) -> None:
    if not tenant_id or tenant_id == "unknown":
        return
    record = manager.tenants_table.get_item(Key={"pk": tenant_id, "sk": "METADATA"}).get("Item") or {}
    snapshot = dict(record.get("subscription") or {})
    snapshot["stripe_subscription_id"] = str(subscription.get("id") or snapshot.get("stripe_subscription_id") or "")
    snapshot["status"] = str(subscription.get("status") or snapshot.get("status") or "").strip().lower()
    snapshot["cancel_at_period_end"] = bool(subscription.get("cancel_at_period_end", False))
    if subscription.get("current_period_end") is not None:
        snapshot["current_period_end"] = subscription.get("current_period_end")
    if subscription.get("current_period_start") is not None:
        snapshot["current_period_start"] = subscription.get("current_period_start")
    if evidence_event_id:
        snapshot["last_billing_evidence_id"] = evidence_event_id
    if evidence_event_url:
        snapshot["last_billing_evidence_url"] = evidence_event_url
    # Founder-suspend protection (issue #1146, council round-1 finding
    # CRITICAL-1): if a founder has manually suspended the tenant,
    # Stripe must NOT be allowed to overwrite ``status`` back to any
    # billing-driven value (e.g. ``active`` on a paid invoice). We
    # detect the founder-suspend state via the ``suspended_by``
    # sentinel written by ``tenant_lifecycle_admin.suspend``.
    #
    # When founder-suspended we still want to keep the subscription
    # snapshot up-to-date (billing data is still useful for the
    # admin UI), we just hold the top-level ``status`` at
    # ``suspended`` until a founder explicitly restores.
    suspended_by = str(record.get("suspended_by") or "").strip()
    current_status = str(record.get("status") or "").strip().lower()
    founder_frozen = bool(suspended_by) and current_status == "suspended"

    if founder_frozen:
        # Update the subscription sub-document and updated_at only;
        # leave ``status`` as ``suspended``.
        manager.tenants_table.update_item(
            Key={"pk": tenant_id, "sk": "METADATA"},
            UpdateExpression="SET subscription = :subscription, updated_at = :updated_at",
            ExpressionAttributeValues={
                ":subscription": snapshot,
                ":updated_at": utc_now_iso(),
            },
        )
        # Codex round-4 PII fix: do not interpolate the founder
        # email into the rendered message body. Hash it for
        # correlation and pass via structured ``extra`` so log
        # viewers never show cleartext.
        import hashlib as _hashlib

        _sus_by_hash = _hashlib.sha256(suspended_by.encode("utf-8")).hexdigest()[:12]
        logger.info(
            "stripe_webhook_suppressed_status_change",
            extra={
                "tenant_id": tenant_id,
                "status": current_status,
                "suspended_by_hash": _sus_by_hash,
            },
        )
        return

    try:
        manager.tenants_table.update_item(
            Key={"pk": tenant_id, "sk": "METADATA"},
            UpdateExpression="SET subscription = :subscription, #tenant_status = :tenant_status, updated_at = :updated_at",
            # CAS: don't flip ``status`` if a founder-suspend landed
            # between our get_item above and this update_item. Belt +
            # suspenders — the read-check handles the common case, the
            # CAS handles the race.
            ConditionExpression=(
                "attribute_not_exists(suspended_by) "
                "OR suspended_by = :no_sentinel "
                "OR #tenant_status <> :suspended_literal"
            ),
            ExpressionAttributeNames={
                "#tenant_status": "status",
            },
            ExpressionAttributeValues={
                ":subscription": snapshot,
                ":tenant_status": tenant_status,
                ":updated_at": utc_now_iso(),
                ":no_sentinel": "",
                ":suspended_literal": "suspended",
            },
        )
    except Exception as exc:  # noqa: BLE001 — ConditionalCheckFailedException
        if "ConditionalCheckFailed" not in type(exc).__name__:
            raise
        # Founder suspend raced our write. Fall back to subscription-only
        # update — we still record the billing data, just not the status.
        logger.info(
            "stripe_webhook_status_race_lost: tenant=%s requested_status=%s reason=founder_suspend_committed",
            tenant_id,
            tenant_status,
        )
        manager.tenants_table.update_item(
            Key={"pk": tenant_id, "sk": "METADATA"},
            UpdateExpression="SET subscription = :subscription, updated_at = :updated_at",
            ExpressionAttributeValues={
                ":subscription": snapshot,
                ":updated_at": utc_now_iso(),
            },
        )


def _write_billing_webhook_evidence(
    *,
    tenant_id: str,
    item_type: str,
    event: WebhookEvent,
    payload: dict[str, Any],
) -> str:
    record = get_evidence_ledger_service().ingest(
        tenant_id=tenant_id,
        event_type="evidence:item",
        data={
            "item_type": item_type,
            "domain": "billing",
            "stripe_event_id": event.id,
            "stripe_event_type": event.type,
            "livemode": event.livemode,
            **payload,
        },
        actor_path="system.stripe_webhook",
        artifact_payload={
            "event_id": event.id,
            "event_type": event.type,
            "payload": payload,
        },
    )
    return str(record["evidence_id"])


# ============================================================================
# Webhook Handler
# ============================================================================


async def handle_checkout_session_completed(
    event: WebhookEvent,
) -> TenantProvisioningResult:
    """
    Handle checkout.session.completed event.

    This event is sent when a customer completes the Stripe Checkout flow.
    We use this to confirm payment and provision tenant resources.

    Args:
        event: Stripe webhook event

    Returns:
        TenantProvisioningResult with tenant provisioning status
    """
    try:
        session = event.data.get("object", {})
        session_id = session.get("id")
        customer_email = session.get("customer_details", {}).get("email")
        payment_status = session.get("payment_status")
        metadata = session.get("metadata", {})
        tenant_id = metadata.get("tenant_id")
        amount_total = session.get("amount_total", 0) / 100  # Convert from cents

        logger.info(
            f"Processing checkout.session.completed: session_id={session_id}, "
            f"tenant_id={tenant_id}, payment_status={payment_status}, "
            f"amount=${amount_total}"
        )

        # Verify payment status
        if payment_status != "paid":
            logger.warning(f"Payment not successful for session {session_id}: {payment_status}")
            return TenantProvisioningResult(
                tenant_id=tenant_id or "unknown",
                status="failed",
                message=f"Payment status: {payment_status}",
            )

        if not tenant_id:
            logger.error(f"No tenant_id in metadata for session {session_id}")
            return TenantProvisioningResult(
                tenant_id="unknown",
                status="failed",
                message="No tenant_id in session metadata",
            )

        # Verify expected checkout amount (warn-only for flexibility across plans/trials)
        expected_amount = _expected_checkout_amount_usd(metadata)
        if expected_amount is not None and Decimal(str(amount_total)) != expected_amount:
            logger.warning(
                f"Payment amount mismatch for session {session_id}: expected ${expected_amount}, got ${amount_total}"
            )

        # Get Stripe customer and subscription IDs
        stripe_customer_id = session.get("customer")
        stripe_subscription_id = session.get("subscription")

        # TASK-6.0B.003: Activate tenant after payment
        tenant_service = get_tenant_provisioning_service()
        try:
            updated_tenant = tenant_service.activate_tenant_after_payment(
                tenant_id=tenant_id,
                stripe_customer_id=stripe_customer_id,
                stripe_subscription_id=stripe_subscription_id,
            )
            logger.info(f"Activated tenant {tenant_id} with Stripe customer {stripe_customer_id}")
        except Exception as e:
            logger.error(f"Failed to activate tenant {tenant_id}: {e}")
            return TenantProvisioningResult(
                tenant_id=tenant_id,
                status="error",
                message=f"Failed to activate tenant: {str(e)}",
            )

        runtime_suffix = ""
        if RUNTIME_AUTO_PROVISION_AFTER_PAYMENT:
            product = (
                updated_tenant.get("product") or (updated_tenant.get("provenance") or {}).get("product") or ""
            ).strip()
            if product and product != "workweaver":
                logger.info(
                    "Skipping runtime provisioning for %s: tenant product=%s",
                    tenant_id,
                    product,
                )
                runtime_suffix = "; runtime provisioning skipped (non-Workweaver product)"
            else:
                owner_user_id = updated_tenant.get("owner_user_id")
                owner_email = (updated_tenant.get("email") or customer_email or "").strip().lower()
                preferred_region = updated_tenant.get("preferred_region_code")

                if owner_user_id and owner_email:
                    try:
                        runtime_provisioning_service = get_workweaver_runtime_provisioning_service()
                        runtime_provisioning_result = await asyncio.to_thread(
                            runtime_provisioning_service.reconcile_provisioning,
                            tenant_id=tenant_id,
                            owner_email=owner_email,
                            owner_user_id=owner_user_id,
                            region=preferred_region,
                        )

                        if runtime_provisioning_result.status in {"ready", "provisioning"}:
                            runtime_suffix = f"; runtime {runtime_provisioning_result.status}"
                        elif runtime_provisioning_result.status == "disabled":
                            runtime_suffix = "; runtime provisioning disabled"
                        else:
                            logger.error(
                                "Runtime provisioning returned non-success status for %s: %s",
                                tenant_id,
                                runtime_provisioning_result.status,
                            )
                            return TenantProvisioningResult(
                                tenant_id=tenant_id,
                                status="partial_success",
                                message=(
                                    "Payment confirmed and tenant activated, but Workweaver Runtime "
                                    f"provisioning failed: {runtime_provisioning_result.message or runtime_provisioning_result.status}"
                                ),
                            )
                    except RuntimeProvisioningError as e:
                        logger.error(
                            "Runtime provisioning failed for paid tenant %s: %s",
                            tenant_id,
                            e,
                        )
                        return TenantProvisioningResult(
                            tenant_id=tenant_id,
                            status="partial_success",
                            message=(
                                "Payment confirmed and tenant activated, but Workweaver Runtime "
                                f"provisioning failed: {e}"
                            ),
                        )
                else:
                    logger.warning(
                        "Skipping runtime provisioning for %s due to missing owner metadata",
                        tenant_id,
                    )
                    runtime_suffix = "; runtime provisioning skipped (missing owner metadata)"
        else:
            runtime_suffix = "; runtime provisioning disabled"

        # Constitution Axiom 2: Store payment event in Operational Context
        try:
            context_service = get_payment_event_resource_store()
            context_service.store_payment_event(
                event_id=event.id,
                event_type=event.type,
                tenant_id=tenant_id,
                customer_email=customer_email,
                payment_status=payment_status,
                amount_total=amount_total,
                currency=session.get("currency", "usd"),
                session_id=session_id,
                stripe_customer_id=stripe_customer_id,
                stripe_subscription_id=stripe_subscription_id,
                livemode=event.livemode,
            )
            logger.info(f"Stored payment event in Operational Context for tenant {tenant_id}")
        except Exception as e:
            logger.error(f"Failed to store payment event in Operational Context: {e}")
            # Non-fatal: continue even if Operational Context storage fails

        # Consume invite token if present (paid invite flow — Blocker #10)
        invite_token = metadata.get("invite_token", "")
        if invite_token:
            try:
                from apps.backend.api.invites import consume_invite

                consumed = consume_invite(invite_token, used_by_email=customer_email or "")
                if consumed:
                    logger.info("Consumed invite token %s for tenant %s", invite_token[:8], tenant_id)
                else:
                    logger.warning(
                        "Invite token %s could not be consumed (already used or not found)", invite_token[:8]
                    )
            except Exception as e:
                logger.warning("Failed to consume invite token after payment: %s", e)

        return TenantProvisioningResult(
            tenant_id=tenant_id,
            status="success",
            message=f"Payment confirmed and tenant activated: ${amount_total}{runtime_suffix}",
        )

    except Exception as e:
        logger.error(f"Error processing checkout.session.completed: {e}")
        return TenantProvisioningResult(
            tenant_id=tenant_id if "tenant_id" in locals() else "unknown",
            status="error",
            message=str(e),
        )


async def handle_invoice_paid(event: WebhookEvent) -> TenantProvisioningResult:
    """
    Handle invoice.paid event.

    This event is sent when an invoice payment succeeds.
    For subscriptions, this confirms recurring billing payments.

    Args:
        event: Stripe webhook event

    Returns:
        TenantProvisioningResult with tenant provisioning status
    """
    try:
        invoice = event.data.get("object", {})
        invoice_id = invoice.get("id")
        customer_email = invoice.get("customer_email")
        amount_paid = invoice.get("amount_paid", 0) / 100  # Convert from cents
        metadata = invoice.get("metadata", {})
        tenant_id = metadata.get("tenant_id")

        logger.info(
            f"Processing invoice.paid: invoice_id={invoice_id}, tenant_id={tenant_id}, amount_paid=${amount_paid}"
        )

        if not tenant_id:
            logger.warning(f"No tenant_id in metadata for invoice {invoice_id}")
            return TenantProvisioningResult(
                tenant_id="unknown",
                status="skipped",
                message="No tenant_id in invoice metadata",
            )

        # Log payment confirmation
        logger.info(
            f"Invoice payment confirmed for tenant={tenant_id}: "
            f"invoice={invoice_id}, amount=${amount_paid}, "
            f"email={customer_email}"
        )

        evidence_id = _write_billing_webhook_evidence(
            tenant_id=tenant_id,
            item_type="invoice_paid",
            event=event,
            payload={
                "invoice_id": invoice_id,
                "customer_email": customer_email,
                "amount_paid": amount_paid,
                "currency": invoice.get("currency", "usd"),
                "invoice_url": invoice.get("hosted_invoice_url"),
            },
        )

        return TenantProvisioningResult(
            tenant_id=tenant_id,
            status="success",
            message=f"Invoice paid: ${amount_paid} ({evidence_id})",
        )

    except Exception as e:
        logger.error(f"Error processing invoice.paid: {e}")
        return TenantProvisioningResult(
            tenant_id=tenant_id if "tenant_id" in locals() else "unknown",
            status="error",
            message=str(e),
        )


async def handle_payment_intent_succeeded(
    event: WebhookEvent,
) -> TenantProvisioningResult:
    """
    Handle payment_intent.succeeded event.

    This event is sent when a payment intent succeeds.
    This is the final confirmation of payment success.

    Args:
        event: Stripe webhook event

    Returns:
        TenantProvisioningResult with tenant provisioning status
    """
    try:
        payment_intent = event.data.get("object", {})
        intent_id = payment_intent.get("id")
        amount = payment_intent.get("amount", 0) / 100  # Convert from cents
        metadata = payment_intent.get("metadata", {})
        tenant_id = metadata.get("tenant_id")

        logger.info(
            f"Processing payment_intent.succeeded: intent_id={intent_id}, tenant_id={tenant_id}, amount=${amount}"
        )

        if not tenant_id:
            logger.warning(f"No tenant_id in metadata for payment intent {intent_id}")
            return TenantProvisioningResult(
                tenant_id="unknown",
                status="skipped",
                message="No tenant_id in payment intent metadata",
            )

        # Log payment confirmation
        logger.info(f"Payment intent succeeded for tenant={tenant_id}: intent={intent_id}, amount=${amount}")

        evidence_id = _write_billing_webhook_evidence(
            tenant_id=tenant_id,
            item_type="payment_intent_succeeded",
            event=event,
            payload={
                "payment_intent_id": intent_id,
                "amount": amount,
                "currency": payment_intent.get("currency", "usd"),
            },
        )

        return TenantProvisioningResult(
            tenant_id=tenant_id,
            status="success",
            message=f"Payment succeeded: ${amount} ({evidence_id})",
        )

    except Exception as e:
        logger.error(f"Error processing payment_intent.succeeded: {e}")
        return TenantProvisioningResult(
            tenant_id=tenant_id if "tenant_id" in locals() else "unknown",
            status="error",
            message=str(e),
        )


def _get_subscription_manager() -> SubscriptionManager:
    return SubscriptionManager(
        stripe_api_key=_resolve_stripe_secret_key(),
        tenants_table_name=resolve_table("tenants"),
    )


async def handle_invoice_payment_failed(event: WebhookEvent) -> TenantProvisioningResult:
    """Handle invoice.payment_failed and trigger dunning workflow."""
    try:
        invoice = event.data.get("object", {})
        metadata = invoice.get("metadata", {}) if isinstance(invoice, dict) else {}
        tenant_id = metadata.get("tenant_id", "unknown")
        manager = _get_subscription_manager()
        await asyncio.to_thread(manager.handle_payment_failed_webhook, event.model_dump())
        return TenantProvisioningResult(
            tenant_id=tenant_id,
            status="success",
            message="Payment failure processed and dunning workflow updated",
        )
    except Exception as e:
        logger.error("Error processing invoice.payment_failed: %s", e)
        return TenantProvisioningResult(
            tenant_id=tenant_id if "tenant_id" in locals() else "unknown",
            status="error",
            message=str(e),
        )


async def handle_subscription_updated(event: WebhookEvent) -> TenantProvisioningResult:
    """Handle customer.subscription.updated events with tenant state synchronization.

    Grace-period aware (#1879): when Stripe reports ``past_due`` the tenant
    enters a 7-day grace period rather than being immediately suspended.
    Only ``canceled``/``unpaid`` trigger immediate suspension.
    """
    subscription = event.data.get("object", {}) if isinstance(event.data, dict) else {}
    manager = _get_subscription_manager()
    tenant_id = _resolve_tenant_id_from_subscription(manager, subscription)
    sub_status = str(subscription.get("status") or "").strip().lower()

    # Grace-period mapping (#1879): past_due enters grace, not immediate suspend.
    _IMMEDIATE_SUSPEND_STATES = {"canceled", "unpaid"}
    if sub_status in {"active", "trialing"}:
        tenant_status = "active"
    elif sub_status == "past_due":
        tenant_status = "active"  # Keep tenant active during grace
        # Enter grace period on the subscription manager
        try:
            hosted_url = subscription.get("hosted_invoice_url", "")
            await asyncio.to_thread(
                manager.enter_grace_period,
                tenant_id=tenant_id,
                reason="subscription_past_due",
                hosted_invoice_url=hosted_url,
            )
        except Exception as exc:
            logger.warning(
                "Grace period entry failed for %s, continuing with snapshot update: %s",
                tenant_id,
                exc,
            )
    elif sub_status in _IMMEDIATE_SUSPEND_STATES:
        tenant_status = "suspended"
    else:
        # Unknown/unexpected Stripe status -- keep current state, log warning
        tenant_status = "active"
        logger.warning(
            "Unexpected Stripe subscription status=%s for tenant=%s; not suspending",
            sub_status,
            tenant_id,
        )

    evidence_id = _write_billing_webhook_evidence(
        tenant_id=tenant_id,
        item_type="subscription_updated",
        event=event,
        payload={
            "subscription_id": subscription.get("id"),
            "status": sub_status,
            "cancel_at_period_end": bool(subscription.get("cancel_at_period_end", False)),
            "current_period_end": subscription.get("current_period_end"),
            "current_period_start": subscription.get("current_period_start"),
        },
    )
    _update_subscription_snapshot(
        manager,
        tenant_id=tenant_id,
        subscription=subscription,
        tenant_status=tenant_status,
        evidence_event_id=evidence_id,
        evidence_event_url=_evidence_url(evidence_id),
    )
    logger.info(
        "Processed customer.subscription.updated: tenant_id=%s subscription_id=%s status=%s",
        tenant_id,
        subscription.get("id"),
        sub_status,
    )
    return TenantProvisioningResult(
        tenant_id=tenant_id,
        status="success",
        message="Subscription update event received and synced",
    )


async def handle_subscription_deleted(event: WebhookEvent) -> TenantProvisioningResult:
    """Handle customer.subscription.deleted events with tenant access revocation."""
    subscription = event.data.get("object", {}) if isinstance(event.data, dict) else {}
    manager = _get_subscription_manager()
    tenant_id = _resolve_tenant_id_from_subscription(manager, subscription)
    subscription = dict(subscription)
    subscription["status"] = "canceled"
    subscription["cancel_at_period_end"] = False
    evidence_id = _write_billing_webhook_evidence(
        tenant_id=tenant_id,
        item_type="subscription_deleted",
        event=event,
        payload={
            "subscription_id": subscription.get("id"),
            "status": subscription.get("status"),
            "cancel_at_period_end": False,
            "current_period_end": subscription.get("current_period_end"),
        },
    )
    _update_subscription_snapshot(
        manager,
        tenant_id=tenant_id,
        subscription=subscription,
        tenant_status="suspended",
        evidence_event_id=evidence_id,
        evidence_event_url=_evidence_url(evidence_id),
    )
    logger.info(
        "Processed customer.subscription.deleted: tenant_id=%s subscription_id=%s",
        tenant_id,
        subscription.get("id"),
    )
    return TenantProvisioningResult(
        tenant_id=tenant_id,
        status="success",
        message="Subscription deletion event received and access revoked",
    )


async def handle_charge_refunded(event: WebhookEvent) -> TenantProvisioningResult:
    """Handle charge.refunded — partial or full refund of a charge.

    Closes #2731. Emits a billing-evidence Decision Trace event so the refund
    is auditable in the Context Graph. Skips cleanly when tenant_id is absent
    (mirrors invoice.paid policy).
    """
    try:
        charge = event.data.get("object", {})
        charge_id = charge.get("id")
        amount = charge.get("amount", 0) / 100
        amount_refunded = charge.get("amount_refunded", 0) / 100
        currency = charge.get("currency", "usd")
        metadata = charge.get("metadata", {})
        tenant_id = metadata.get("tenant_id")
        refunds = charge.get("refunds", {}).get("data", [])
        last_refund = refunds[-1] if refunds else {}

        logger.info(
            "Processing charge.refunded: charge=%s tenant=%s amount=%.2f refunded=%.2f",
            charge_id,
            tenant_id,
            amount,
            amount_refunded,
        )

        if not tenant_id:
            logger.warning("No tenant_id in metadata for charge %s", charge_id)
            return TenantProvisioningResult(
                tenant_id="unknown",
                status="skipped",
                message="No tenant_id in charge metadata",
            )

        evidence_id = _write_billing_webhook_evidence(
            tenant_id=tenant_id,
            item_type="charge_refunded",
            event=event,
            payload={
                "charge_id": charge_id,
                "amount": amount,
                "amount_refunded": amount_refunded,
                "currency": currency,
                "refund_id": last_refund.get("id"),
                "refund_reason": last_refund.get("reason"),
                "receipt_url": charge.get("receipt_url"),
            },
        )

        return TenantProvisioningResult(
            tenant_id=tenant_id,
            status="success",
            message=f"Charge refund recorded: ${amount_refunded:.2f} {currency.upper()} ({evidence_id})",
        )

    except Exception as e:  # noqa: BLE001
        logger.error("Error processing charge.refunded: %s", e)
        return TenantProvisioningResult(
            tenant_id=tenant_id if "tenant_id" in locals() else "unknown",
            status="error",
            message=str(e),
        )


async def handle_invoice_voided(event: WebhookEvent) -> TenantProvisioningResult:
    """Handle invoice.voided — invoice voided before payment.

    Closes #2731. Emits a billing-evidence Decision Trace event so the void is
    auditable. No tenant provisioning side effects.
    """
    try:
        invoice = event.data.get("object", {})
        invoice_id = invoice.get("id")
        amount_due = invoice.get("amount_due", 0) / 100
        currency = invoice.get("currency", "usd")
        metadata = invoice.get("metadata", {})
        tenant_id = metadata.get("tenant_id")

        logger.info(
            "Processing invoice.voided: invoice=%s tenant=%s amount_due=%.2f",
            invoice_id,
            tenant_id,
            amount_due,
        )

        if not tenant_id:
            logger.warning("No tenant_id in metadata for invoice %s", invoice_id)
            return TenantProvisioningResult(
                tenant_id="unknown",
                status="skipped",
                message="No tenant_id in invoice metadata",
            )

        evidence_id = _write_billing_webhook_evidence(
            tenant_id=tenant_id,
            item_type="invoice_voided",
            event=event,
            payload={
                "invoice_id": invoice_id,
                "amount_due": amount_due,
                "currency": currency,
                "customer_email": invoice.get("customer_email"),
                "status": invoice.get("status", "void"),
            },
        )

        return TenantProvisioningResult(
            tenant_id=tenant_id,
            status="success",
            message=f"Invoice voided: ${amount_due:.2f} {currency.upper()} ({evidence_id})",
        )

    except Exception as e:  # noqa: BLE001
        logger.error("Error processing invoice.voided: %s", e)
        return TenantProvisioningResult(
            tenant_id=tenant_id if "tenant_id" in locals() else "unknown",
            status="error",
            message=str(e),
        )


# Webhook event type handlers map
WEBHOOK_HANDLERS = {
    "checkout.session.completed": handle_checkout_session_completed,
    "invoice.paid": handle_invoice_paid,
    "invoice.payment_failed": handle_invoice_payment_failed,
    "invoice.voided": handle_invoice_voided,
    "payment_intent.succeeded": handle_payment_intent_succeeded,
    "charge.refunded": handle_charge_refunded,
    "customer.subscription.updated": handle_subscription_updated,
    "customer.subscription.deleted": handle_subscription_deleted,
}


async def process_webhook_event(event: WebhookEvent) -> TenantProvisioningResult:
    """
    Process a Stripe webhook event.

    Routes the event to the appropriate handler based on event type.

    Args:
        event: Stripe webhook event

    Returns:
        TenantProvisioningResult with processing status
    """
    event_type = event.type

    # Get handler for this event type
    handler = WEBHOOK_HANDLERS.get(event_type)

    if not handler:
        logger.info(f"No handler for event type: {event_type}")
        return TenantProvisioningResult(
            tenant_id="unknown",
            status="skipped",
            message=f"Unhandled event type: {event_type}",
        )

    # Process event with handler
    return await handler(event)


# ============================================================================
# API Endpoints
# ============================================================================


def verify_stripe_webhook_signature(payload: bytes, signature_header: str, webhook_secret: str) -> bool:
    """
    Verify Stripe webhook signature.

    Args:
        payload: Raw request payload
        signature_header: Stripe-Signature header value
        webhook_secret: Stripe webhook secret

    Returns:
        True if signature is valid, False otherwise
    """
    try:
        stripe.WebhookSignature.verify_header(payload, signature_header, webhook_secret)
        return True
    except Exception:
        logger.warning("Invalid Stripe webhook signature")
        return False


@router.post("/webhooks/stripe")
async def stripe_webhook(
    request: Request,
    stripe_signature: str = Header(None, alias="stripe-signature"),
):
    """
    Handle Stripe webhook events.

    This endpoint receives webhook events from Stripe for payment confirmation.
    It verifies the webhook signature and processes events asynchronously.

    Events handled:
    - checkout.session.completed: Customer completed checkout
    - invoice.paid: Invoice payment succeeded
    - payment_intent.succeeded: Payment intent succeeded

    Args:
        request: FastAPI request
        background_tasks: FastAPI background tasks
        stripe_signature: Stripe-Signature header for verification

    Returns:
        200 OK if webhook is processed successfully
        400 Bad Request if signature is invalid
        500 Internal Server Error if the webhook secret is unavailable
        503 Service Unavailable if durable outbox capture fails

    Raises:
        HTTPException: If webhook signature is invalid
    """
    # Get webhook secret from environment
    webhook_secret = _resolve_stripe_webhook_secret()

    if not webhook_secret:
        logger.error("STRIPE_WEBHOOK_SECRET not configured")
        raise HTTPException(status_code=500, detail="Webhook secret not configured")

    # Read request payload
    payload = await request.body()

    # Verify webhook signature
    if not verify_stripe_webhook_signature(payload, stripe_signature, webhook_secret):
        raise HTTPException(status_code=400, detail="Invalid webhook signature")

    # Parse event
    try:
        event_dict = request.state._raw_json if hasattr(request.state, "_raw_json") else None
        if not event_dict:
            event_dict = json.loads(payload)

        event = WebhookEvent(**event_dict)

        logger.info(f"Received Stripe webhook: {event.type} (id={event.id})")

        accepted = await asyncio.to_thread(lambda: get_stripe_webhook_outbox_service().enqueue_event(event_dict))
        logger.info(
            "stripe_webhook_outbox_write_succeeded event_id=%s duplicate=%s state=%s",
            event.id,
            accepted.duplicate,
            accepted.state,
        )

        if accepted.duplicate:
            logger.info("Duplicate Stripe webhook ignored: %s", event.id)
            return {
                "status": "duplicate",
                "event_id": event.id,
                "outbox_state": accepted.state,
            }

        logger.info(
            "Stripe webhook accepted into outbox: event=%s id=%s",
            event.type,
            event.id,
        )
        return {"status": "accepted", "event_id": event.id, "outbox_state": accepted.state}

    except HTTPException:
        raise
    except (json.JSONDecodeError, ValueError) as e:
        logger.warning("Invalid Stripe webhook payload: %s", e)
        raise HTTPException(status_code=400, detail="Invalid webhook payload") from e
    except Exception as e:
        event_id = ""
        if isinstance(locals().get("event_dict"), dict):
            event_id = str(locals()["event_dict"].get("id") or "")
        logger.error("stripe_webhook_outbox_write_failed event_id=%s error=%s", event_id, e)
        raise HTTPException(
            status_code=503,
            detail="Error queueing webhook",
            headers={"Retry-After": "5"},
        )


@router.get("/webhooks/stripe/health")
async def webhook_health():
    """Health check endpoint for webhooks."""
    return {
        "status": "healthy",
        "service": "stripe-webhooks",
        "timestamp": datetime.now(UTC).isoformat(),
    }
