"""
Analytics API

Dashboard metrics for Mission Control.

Source: docs/PRODUCT.md#Part18.4
"""

import logging
from typing import Any

from fastapi import APIRouter, Depends, Query

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.analytics_service import AnalyticsService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/mission/analytics", tags=["analytics"])

_analytics_svc: AnalyticsService | None = None


def _get_analytics_service() -> AnalyticsService:
    global _analytics_svc
    if _analytics_svc is None:
        from apps.backend.services.task_store import get_task_store

        _analytics_svc = AnalyticsService(task_store=get_task_store())
    return _analytics_svc


@router.get("")
async def get_analytics(
    period: str = Query("week", pattern="^(week|month|quarter)$"),
    pipeline: str = Query("all"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return aggregated analytics for the dashboard."""
    return _get_analytics_service().get_analytics(tenant_id, period, pipeline)
