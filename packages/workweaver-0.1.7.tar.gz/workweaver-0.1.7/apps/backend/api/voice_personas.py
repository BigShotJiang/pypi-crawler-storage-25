"""Voice Persona API endpoints -- CRUD for workspace voice personas (#2798).

Clone-voice endpoints added in #3239.
"""
from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/personas", tags=["personas", "voice"])


class CreatePersonaRequest(BaseModel):
    name: str
    voice_id: str = "ara"
    language: str = "en"
    speaking_rate: float = 1.0
    pitch: float = 0.0
    greeting_script: str = ""
    hold_message: str = ""
    transfer_message: str = ""
    pronunciation_dict: dict[str, str] = Field(default_factory=dict)
    from_template: str | None = None


class UpdatePersonaRequest(BaseModel):
    name: str | None = None
    voice_id: str | None = None
    language: str | None = None
    speaking_rate: float | None = None
    pitch: float | None = None
    greeting_script: str | None = None
    hold_message: str | None = None
    transfer_message: str | None = None
    pronunciation_dict: dict[str, str] | None = None
    disabled: bool | None = None


class RegisterCloneRequest(BaseModel):
    voice_id: str
    name: str | None = None
    provider: str = "custom"
    provider_clone_id: str = ""
    proof_ref: str = ""
    description: str = ""


def _get_service(request: Request) -> Any:
    service = getattr(request.app.state, "voice_persona_service", None)
    if service is not None:
        return service
    from apps.backend.services.voice_persona_store import get_voice_persona_service
    return get_voice_persona_service()


@router.post("", status_code=status.HTTP_201_CREATED)
async def create_persona(
    body: CreatePersonaRequest,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    service = _get_service(request)
    try:
        return service.create_persona(
            tenant_id=tenant_id, name=body.name, voice_id=body.voice_id, language=body.language,
            speaking_rate=body.speaking_rate, pitch=body.pitch, greeting_script=body.greeting_script,
            hold_message=body.hold_message, transfer_message=body.transfer_message,
            pronunciation_dict=body.pronunciation_dict, from_template=body.from_template,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc


@router.post("/clones", status_code=status.HTTP_201_CREATED)
async def register_clone(
    body: RegisterCloneRequest,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    service = _get_service(request)
    try:
        return service.register_clone_ownership(
            tenant_id=tenant_id,
            voice_id=body.voice_id,
            name=body.name,
            provider=body.provider,
            provider_clone_id=body.provider_clone_id,
            proof_ref=body.proof_ref,
            description=body.description,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc


@router.get("")
async def list_personas(
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[dict[str, Any]]:
    return _get_service(request).list_personas(tenant_id)


@router.get("/templates")
async def list_templates(
    request: Request,
    _tenant_id: str = Depends(get_verified_tenant_id),
) -> list[dict[str, Any]]:
    return _get_service(request).list_templates()


@router.get("/voices")
async def list_voice_catalog(
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[dict[str, Any]]:
    return _get_service(request).list_voice_catalog(tenant_id)


@router.get("/{persona_id}")
async def get_persona(
    persona_id: str,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    result = _get_service(request).get_persona(tenant_id, persona_id)
    if result is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Persona not found")
    return result


@router.patch("/{persona_id}")
async def update_persona(
    persona_id: str,
    body: UpdatePersonaRequest,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    updates = {k: v for k, v in body.model_dump().items() if v is not None}
    try:
        return _get_service(request).update_persona(tenant_id=tenant_id, persona_id=persona_id, updates=updates)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc


@router.delete("/{persona_id}")
async def delete_persona(
    persona_id: str,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    try:
        deleted = _get_service(request).delete_persona(tenant_id, persona_id)
        if not deleted:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Persona not found")
        return {"deleted": True, "persona_id": persona_id}
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc


# ---------------------------------------------------------------------------
# Clone-voice endpoints (#3239)
# ---------------------------------------------------------------------------


def _get_clone_client(request: Request) -> Any:
    client = getattr(request.app.state, "xai_voice_clone_client", None)
    if client is not None:
        return client
    from apps.backend.extensions.voice_services.xai_voice_clone import XAIVoiceCloneClient
    return XAIVoiceCloneClient()


def _require_owner(caller_role: str) -> None:
    if caller_role != "owner":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only workspace owners can manage voice clones",
        )


@router.post("/{persona_id}/clone-voice", status_code=status.HTTP_201_CREATED)
async def clone_voice_create(
    persona_id: str,
    request: Request,
    audio: UploadFile = File(...),
    consent_record_id: str = Form(...),
    caller_role: str = Form("owner"),
    geo_country: str = Form("US"),
    geo_region: str = Form(""),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    _require_owner(caller_role)
    service = _get_service(request)
    persona = service.get_persona(tenant_id, persona_id)
    if persona is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Persona not found")

    audio_data = await audio.read()
    # Estimate duration: bytes / (24000 Hz * 1 ch * 2 bytes/sample)
    audio_duration_s = len(audio_data) / (24000 * 2)

    client = _get_clone_client(request)
    try:
        result = await client.create_voice(
            tenant_id=tenant_id,
            persona_id=persona_id,
            audio_data=audio_data,
            content_type=audio.content_type or "audio/wav",
            audio_duration_s=audio_duration_s,
            consent_record_id=consent_record_id,
            geo_country=geo_country,
            geo_region=geo_region,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    updated = service.update_persona(
        tenant_id=tenant_id,
        persona_id=persona_id,
        updates={
            "voice_origin": "cloned",
            "xai_clone_voice_id": result["xai_voice_id"],
            "clone_status": result.get("status", "pending"),
            "clone_consent_at": request.state._state.get("timestamp", "") if hasattr(request.state, "_state") else "",
            "clone_sample_s3_key": result.get("sample_key", ""),
        },
    )
    return updated


@router.get("/{persona_id}/clone-voice/status")
async def clone_voice_status(
    persona_id: str,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    service = _get_service(request)
    persona = service.get_persona(tenant_id, persona_id)
    if persona is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Persona not found")

    clone_voice_id = persona.get("xai_clone_voice_id")
    if not clone_voice_id:
        return {"clone_status": "none", "voice_origin": persona.get("voice_origin", "built_in")}

    client = _get_clone_client(request)
    try:
        xai_status = await client.get_voice(voice_id=clone_voice_id)
    except Exception:
        return {
            "clone_status": persona.get("clone_status", "unknown"),
            "xai_clone_voice_id": clone_voice_id,
            "voice_origin": persona.get("voice_origin", "built_in"),
        }

    return {
        "clone_status": xai_status.get("status", persona.get("clone_status")),
        "xai_clone_voice_id": clone_voice_id,
        "voice_origin": persona.get("voice_origin", "built_in"),
        "xai_response": xai_status,
    }


@router.post("/{persona_id}/clone-voice/test")
async def clone_voice_test(
    persona_id: str,
    body: dict[str, str],
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> Any:
    service = _get_service(request)
    persona = service.get_persona(tenant_id, persona_id)
    if persona is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Persona not found")

    clone_voice_id = persona.get("xai_clone_voice_id")
    if not clone_voice_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Persona does not have a cloned voice",
        )

    text = body.get("text", "")
    if not text:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="text is required")

    from apps.backend.extensions.voice_services.grok_voice import GrokVoiceSynthesizer
    synthesizer = getattr(request.app.state, "grok_voice_synthesizer", None) or GrokVoiceSynthesizer()
    try:
        audio_bytes = await synthesizer.synthesize(
            text=text, voice_id=clone_voice_id, tenant_id=tenant_id,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc

    from fastapi.responses import Response
    return Response(content=audio_bytes, media_type="audio/mp3")


@router.delete("/{persona_id}/clone-voice", status_code=status.HTTP_204_NO_CONTENT)
async def clone_voice_delete(
    persona_id: str,
    request: Request,
    caller_role: str = "owner",
    tenant_id: str = Depends(get_verified_tenant_id),
) -> None:
    _require_owner(caller_role)
    service = _get_service(request)
    persona = service.get_persona(tenant_id, persona_id)
    if persona is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Persona not found")

    clone_voice_id = persona.get("xai_clone_voice_id")
    if not clone_voice_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Persona does not have a cloned voice",
        )

    client = _get_clone_client(request)
    await client.delete_voice(voice_id=clone_voice_id, tenant_id=tenant_id, persona_id=persona_id)

    service.update_persona(
        tenant_id=tenant_id,
        persona_id=persona_id,
        updates={
            "clone_status": "deleted",
            "clone_sample_s3_key": None,
        },
    )
