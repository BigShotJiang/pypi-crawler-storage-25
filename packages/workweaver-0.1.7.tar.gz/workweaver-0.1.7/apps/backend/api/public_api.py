"""Public REST API surface (M5.2) -- tenant-facing API endpoints.

Prefix: /api/v1/public/
Auth: API key via Bearer ww_sk_* token or X-Tenant-Id (dev mode).
Rate-limited per tenant.

Mirrors the MCP tools from M5.1 as REST endpoints.

Reference: docs/CAPABILITIES.md M5.2
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.plugin_auth import get_plugin_tenant_id
from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.public_api_service import PublicResearchError
from apps.backend.services.research_capability import ResearchToolRequest, ResearchToolResult

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/public", tags=["public-api"])
cli_router = APIRouter(prefix="/api/v1/research", tags=["research"])


# ============================================================================
# Request / Response Models
# ============================================================================


class CreateTaskRequest(BaseModel):
    """Request to create a task via public API."""

    title: str = Field(..., min_length=1, max_length=200, description="Task title")
    description: str = Field("", max_length=5000, description="Task description")
    assigned_agent: str | None = Field(None, max_length=100, description="Agent ID to assign")
    priority: str = Field("medium", description="Priority: urgent|high|medium|low")


class TaskResponse(BaseModel):
    """Response for a single task."""

    task_id: str
    tenant_id: str
    title: str
    description: str = ""
    assigned_agent: str | None = None
    priority: str = "medium"
    status: str = "backlog"
    created_at: str = ""
    updated_at: str = ""


class AgentListResponse(BaseModel):
    """Response for listing agents."""

    tenant_id: str
    agents: list[dict[str, Any]] = Field(default_factory=list)
    count: int = 0


class RunAgentRequest(BaseModel):
    """Request to trigger an agent run."""

    task: str = Field(..., min_length=1, max_length=5000, description="Task description")


class RunAgentResponse(BaseModel):
    """Response for triggering an agent run."""

    run_id: str
    agent_id: str
    tenant_id: str
    task: str
    status: str = "queued"
    created_at: str = ""


class CreateScheduleRequest(BaseModel):
    """Request to create a schedule."""

    agent_id: str = Field(..., min_length=1, max_length=100, description="Agent ID")
    title: str = Field(..., min_length=1, max_length=200, description="Schedule title")
    schedule_type: str = Field(..., description="Type: one_time|recurring|triggered")
    cron_expression: str | None = Field(None, description="Cron expression for recurring")
    description: str = Field("", max_length=2000, description="Description")


class ScheduleResponse(BaseModel):
    """Response for a schedule."""

    schedule_id: str
    tenant_id: str
    agent_id: str
    title: str
    description: str = ""
    schedule_type: str
    cron_expression: str | None = None
    status: str = "active"
    created_at: str = ""
    updated_at: str = ""


class TriggerScheduleResponse(BaseModel):
    """Response for triggering a schedule."""

    schedule_id: str
    tenant_id: str
    status: str = "triggered"
    triggered_at: str = ""


class EvidenceQueryResponse(BaseModel):
    """Response for querying evidence."""

    tenant_id: str
    items: list[dict[str, Any]] = Field(default_factory=list)
    count: int = 0


class ResearchResponse(ResearchToolResult):
    """Response for a tenant-scoped research call."""


class ApprovalListResponse(BaseModel):
    """Response for listing approvals."""

    tenant_id: str
    approvals: list[dict[str, Any]] = Field(default_factory=list)
    count: int = 0


class ApproveRequest(BaseModel):
    """Request to approve a pending action."""

    actor_id: str = Field(..., min_length=1, max_length=100, description="User ID approving")


async def _research_search_response(*, body: ResearchToolRequest, tenant_id: str) -> ResearchResponse:
    service = _get_service()
    try:
        result = await service.research_search(
            tenant_id=tenant_id,
            query=body.query,
            operation=body.operation,
            max_results=body.max_results,
            url=body.url,
            workitem_id=body.workitem_id,
            swarm_execution_id=body.swarm_execution_id,
        )
    except PublicResearchError as exc:
        raise HTTPException(status_code=exc.status_code, detail=exc.to_dict()) from exc
    return ResearchResponse(**result)


class RejectRequest(BaseModel):
    """Request to reject a pending action."""

    actor_id: str = Field(..., min_length=1, max_length=100, description="User ID rejecting")
    reason: str = Field("", max_length=512, description="Rejection reason")


class ApprovalActionResponse(BaseModel):
    """Response for approve/reject actions."""

    success: bool
    request_id: str
    actor_id: str
    action: str
    tenant_id: str


# ============================================================================
# Service accessor (lazy import to avoid import-time failures)
# ============================================================================


def _get_service():
    from apps.backend.api.public_api_service import get_public_api_service

    return get_public_api_service()


# ============================================================================
# Endpoints
# ============================================================================


# --- Agents ---


@router.get(
    "/agents",
    response_model=AgentListResponse,
    summary="List tenant's agents",
)
async def list_agents(
    tenant_id: str = Depends(get_plugin_tenant_id),
    status_filter: str | None = Query(None, description="Filter by agent status"),
) -> AgentListResponse:
    """List all agents belonging to the authenticated tenant."""
    service = _get_service()
    result = await service.list_agents(tenant_id=tenant_id, status_filter=status_filter)
    return AgentListResponse(**result)


# --- Research ---


@router.post(
    "/research/search",
    response_model=ResearchResponse,
    summary="Run bounded web research",
)
async def research_search(
    body: ResearchToolRequest,
    tenant_id: str = Depends(get_plugin_tenant_id),
) -> ResearchResponse:
    """Execute the same web research contract used by CLI and MCP."""
    return await _research_search_response(body=body, tenant_id=tenant_id)


@cli_router.post(
    "/search",
    response_model=ResearchResponse,
    summary="Run bounded web research",
)
async def cli_research_search(
    body: ResearchToolRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ResearchResponse:
    """Execute web research for first-party CLI/browser access tokens."""
    return await _research_search_response(body=body, tenant_id=tenant_id)


@router.post(
    "/agents/{agent_id}/run",
    response_model=RunAgentResponse,
    status_code=status.HTTP_202_ACCEPTED,
    summary="Trigger agent execution",
)
async def run_agent(
    agent_id: str,
    body: RunAgentRequest,
    tenant_id: str = Depends(get_plugin_tenant_id),
) -> RunAgentResponse:
    """Trigger an agent to execute a task."""
    service = _get_service()
    result = await service.run_agent(
        tenant_id=tenant_id,
        agent_id=agent_id,
        task=body.task,
    )
    return RunAgentResponse(**result)


# --- Tasks ---


@router.post(
    "/tasks",
    response_model=TaskResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a task",
)
async def create_task(
    body: CreateTaskRequest,
    tenant_id: str = Depends(get_plugin_tenant_id),
) -> TaskResponse:
    """Create a new task for the tenant."""
    service = _get_service()
    result = await service.create_task(
        tenant_id=tenant_id,
        title=body.title,
        description=body.description,
        assigned_agent=body.assigned_agent,
        priority=body.priority,
    )
    return TaskResponse(**result)


@router.get(
    "/tasks/{task_id}",
    response_model=TaskResponse,
    summary="Get task status",
)
async def get_task_status(
    task_id: str,
    tenant_id: str = Depends(get_plugin_tenant_id),
) -> TaskResponse:
    """Get the status and details of a specific task."""
    service = _get_service()
    try:
        result = await service.get_task_status(tenant_id=tenant_id, task_id=task_id)
    except KeyError:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Task not found")
    return TaskResponse(**result)


# --- Schedules ---


@router.post(
    "/schedules",
    response_model=ScheduleResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a schedule",
)
async def create_schedule(
    body: CreateScheduleRequest,
    tenant_id: str = Depends(get_plugin_tenant_id),
) -> ScheduleResponse:
    """Create a recurring or triggered schedule for an agent."""
    service = _get_service()
    result = await service.create_schedule(
        tenant_id=tenant_id,
        agent_id=body.agent_id,
        title=body.title,
        schedule_type=body.schedule_type,
        cron_expression=body.cron_expression,
        description=body.description,
    )
    return ScheduleResponse(**result)


@router.post(
    "/schedules/{schedule_id}/trigger",
    response_model=TriggerScheduleResponse,
    summary="Trigger a schedule",
)
async def trigger_schedule(
    schedule_id: str,
    tenant_id: str = Depends(get_plugin_tenant_id),
) -> TriggerScheduleResponse:
    """Fire a triggered schedule immediately."""
    service = _get_service()
    try:
        result = await service.trigger_schedule(tenant_id=tenant_id, schedule_id=schedule_id)
    except KeyError:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Schedule not found")
    return TriggerScheduleResponse(**result)


# --- Evidence ---


@router.get(
    "/evidence",
    response_model=EvidenceQueryResponse,
    summary="Query evidence ledger",
)
async def query_evidence(
    tenant_id: str = Depends(get_plugin_tenant_id),
    agent_id: str | None = Query(None, description="Filter by agent"),
    event_type: str | None = Query(None, description="Filter by event type"),
    limit: int = Query(50, ge=1, le=500, description="Max results"),
) -> EvidenceQueryResponse:
    """Query the evidence ledger for the authenticated tenant."""
    service = _get_service()
    result = await service.query_evidence(
        tenant_id=tenant_id,
        agent_id=agent_id,
        event_type=event_type,
        limit=limit,
    )
    return EvidenceQueryResponse(**result)


# --- Approvals ---


@router.get(
    "/approvals",
    response_model=ApprovalListResponse,
    summary="List pending approvals",
)
async def list_approvals(
    tenant_id: str = Depends(get_plugin_tenant_id),
    limit: int = Query(20, ge=1, le=200, description="Max results"),
) -> ApprovalListResponse:
    """List pending approval requests for the authenticated tenant."""
    service = _get_service()
    result = await service.list_approvals(tenant_id=tenant_id, limit=limit)
    return ApprovalListResponse(**result)


@router.post(
    "/approvals/{request_id}/approve",
    response_model=ApprovalActionResponse,
    summary="Approve a pending action",
)
async def approve_action(
    request_id: str,
    body: ApproveRequest,
    tenant_id: str = Depends(get_plugin_tenant_id),
) -> ApprovalActionResponse:
    """Approve a pending approval request."""
    service = _get_service()
    try:
        result = await service.approve_action(
            tenant_id=tenant_id,
            request_id=request_id,
            actor_id=body.actor_id,
        )
    except KeyError:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Approval request not found")
    return ApprovalActionResponse(**result)


@router.post(
    "/approvals/{request_id}/reject",
    response_model=ApprovalActionResponse,
    summary="Reject a pending action",
)
async def reject_action(
    request_id: str,
    body: RejectRequest,
    tenant_id: str = Depends(get_plugin_tenant_id),
) -> ApprovalActionResponse:
    """Reject a pending approval request."""
    service = _get_service()
    try:
        result = await service.reject_action(
            tenant_id=tenant_id,
            request_id=request_id,
            actor_id=body.actor_id,
            reason=body.reason,
        )
    except KeyError:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Approval request not found")
    return ApprovalActionResponse(**result)
