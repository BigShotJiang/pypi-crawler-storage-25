"""Governance anchor paths — read-only listing surface (issue #3547).

Endpoint::

    GET /api/v1/governance/anchor-paths

Returns the canonical inventory of file paths protected by the L4
governance anchor.  Sub-L4 promotions whose diff touches any of these
paths are refused at promotion preflight by
:meth:`apps.backend.services.improvement_policy_registry.ImprovementPolicyRegistry.preflight`,
and any human PR that touches one of them must carry the ``governance``
label (enforced by ``scripts/ci/governance_anchor_gate.py``).

The endpoint is read-only and tenant-scoped.
"""

from __future__ import annotations

from fastapi import APIRouter, Depends
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.governance_anchor_paths import list_anchor_paths

router = APIRouter(prefix="/api/v1/governance", tags=["governance"])


class GovernanceAnchorPathsResponse(BaseModel):
    """Canonical anchor inventory."""

    tenant_id: str = Field(..., description="Authenticated tenant identifier.")
    paths: list[str] = Field(
        ...,
        description="Exact-match anchor paths (repo-relative, POSIX).",
    )
    globs: list[str] = Field(
        ...,
        description="Glob anchors (matched with fnmatch).",
    )


@router.get("/anchor-paths", response_model=GovernanceAnchorPathsResponse)
def get_governance_anchor_paths(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> GovernanceAnchorPathsResponse:
    """Return the L4 anchor-path inventory for the authenticated tenant."""
    inventory = list_anchor_paths()
    return GovernanceAnchorPathsResponse(
        tenant_id=tenant_id,
        paths=list(inventory["paths"]),
        globs=list(inventory["globs"]),
    )
