"""Simulation Sandbox API endpoints (PR-T4.1).

Endpoints:
  POST /api/v1/simulation/run          -- execute simulation for a goal/workitem
  GET  /api/v1/simulation/{run_id}     -- get simulation results
  POST /api/v1/simulation/{run_id}/promote -- promote to SHADOW execution

Legacy requirement reference: Constitution Invariant 11 — simulation sandbox runtime
"""

from __future__ import annotations

import logging
from typing import Any

import ulid
from datetime import UTC, datetime

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.simulation.action_planner import plan_simulation_actions
from apps.backend.services.simulation.sandbox import SimulationSandbox
from apps.backend.services.simulation.world_state import (
    SimulationArtifact,
    capture_world_state,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/simulation", tags=["simulation"])

# In-memory store for simulation runs (tenant_id -> run_id -> result)
_simulation_runs: dict[str, dict[str, dict[str, Any]]] = {}

# In-memory history index (tenant_id -> list of run records)
_simulation_history: dict[str, list[SimulationRunRecord]] = {}


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class SimulationRunRequest(BaseModel):
    """Request body for running a simulation."""

    goal: str = Field(..., min_length=1, description="Goal or scenario to simulate")
    workitem_id: str | None = Field(None, description="Optional work item ID to simulate against")
    max_steps: int = Field(default=50, ge=1, le=100, description="Max simulation steps")
    budget_limit: int = Field(default=100, ge=1, le=1000, description="Max action budget")


class SimulationRunResponse(BaseModel):
    """Response from a simulation run."""

    run_id: str
    tenant_id: str
    goal: str
    status: str
    artifacts: list[dict[str, Any]]
    shadow_writes: list[dict[str, Any]]
    world_state_snapshot: dict[str, Any]
    budget_used: int
    budget_limit: int


class SimulationRunRecord(BaseModel):
    """Metadata record for a simulation run, stored in DynamoDB.

    DynamoDB schema: PK=TENANT#{tenant_id}, SK=SIM_RUN#{run_id}
    """

    run_id: str
    tenant_id: str
    goal: str
    status: str
    artifact_count: int = 0
    budget_used: int = 0
    budget_limit: int = 100
    created_at: str = ""


class SimulationHistoryResponse(BaseModel):
    """Response for listing past simulation runs."""

    runs: list[SimulationRunRecord] = Field(default_factory=list)
    count: int = 0


class PromoteRequest(BaseModel):
    """Request body for promoting a simulation to SHADOW execution."""

    confirm: bool = Field(..., description="Must be true to confirm promotion")


class PromoteResponse(BaseModel):
    """Response from promoting a simulation."""

    run_id: str
    promoted: bool
    promotion_target: str = "SHADOW"


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("/run", response_model=SimulationRunResponse)
async def run_simulation(
    body: SimulationRunRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SimulationRunResponse:
    """Execute a simulation for a goal or workitem.

    Creates a sandbox, captures world state, executes simulated actions,
    and returns the results without any real side effects.
    """
    run_id = f"SIM_{ulid.new().str}"

    # Capture world state
    snapshot = capture_world_state(tenant_id)

    # Create sandbox and execute
    sandbox = SimulationSandbox(
        tenant_id=tenant_id,
        budget_limit=body.budget_limit,
    )

    # Simulate a sequence of actions based on the goal
    artifacts: list[SimulationArtifact] = []
    steps_executed = 0

    # Simple simulation: try common action patterns
    action_sequence = plan_simulation_actions(body.goal, body.workitem_id)

    for tool_id, operation, inputs in action_sequence:
        if steps_executed >= body.max_steps:
            break

        result = sandbox.execute_action(
            tool_id=tool_id,
            operation=operation,
            inputs=inputs,
        )

        if result.budget_exceeded:
            break

        artifacts.append(
            SimulationArtifact(
                action=f"{tool_id}:{operation}",
                predicted_outcome=result.predicted_outcome,
                confidence=0.8 if result.intercepted else 1.0,
                assumptions=["Sandbox simulation — no real execution"],
            )
        )
        steps_executed += 1

    # Store results
    run_data: dict[str, Any] = {
        "run_id": run_id,
        "tenant_id": tenant_id,
        "goal": body.goal,
        "status": "complete",
        "artifacts": [a.to_dict() for a in artifacts],
        "shadow_writes": sandbox.get_shadow_writes(),
        "world_state_snapshot": snapshot.to_dict(),
        "budget_used": sandbox.budget_used,
        "budget_limit": body.budget_limit,
    }
    _simulation_runs.setdefault(tenant_id, {})[run_id] = run_data

    # Persist run record for history queries
    _simulation_history.setdefault(tenant_id, []).append(
        SimulationRunRecord(
            run_id=run_id,
            tenant_id=tenant_id,
            goal=body.goal,
            status="complete",
            artifact_count=len(artifacts),
            budget_used=sandbox.budget_used,
            budget_limit=body.budget_limit,
            created_at=datetime.now(UTC).isoformat(),
        )
    )

    logger.info(
        "Simulation %s complete: %d artifacts, %d shadow writes",
        run_id,
        len(artifacts),
        len(sandbox.get_shadow_writes()),
    )

    return SimulationRunResponse(**run_data)


@router.get("/history", response_model=SimulationHistoryResponse)
async def simulation_history(
    tenant_id: str = Depends(get_verified_tenant_id),
    limit: int = Query(50, ge=1, le=500, description="Maximum number of runs to return"),
) -> SimulationHistoryResponse:
    """List past simulation runs for a tenant.

    Returns run metadata ordered by most recent first.
    Uses TenantScopedStore pattern: PK=TENANT#{tenant_id}, SK=SIM_RUN#{run_id}.
    """
    runs = _simulation_history.get(tenant_id, [])
    # Return most recent first, limited
    sorted_runs = sorted(runs, key=lambda r: r.created_at, reverse=True)[:limit]
    return SimulationHistoryResponse(runs=sorted_runs, count=len(sorted_runs))


@router.get("/{run_id}", response_model=SimulationRunResponse)
async def get_simulation(
    run_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SimulationRunResponse:
    """Get results of a previous simulation run."""
    tenant_runs = _simulation_runs.get(tenant_id, {})
    run_data = tenant_runs.get(run_id)
    if run_data is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Simulation run {run_id} not found",
        )
    return SimulationRunResponse(**run_data)


@router.post("/{run_id}/promote", response_model=PromoteResponse)
async def promote_simulation(
    run_id: str,
    body: PromoteRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PromoteResponse:
    """Promote a simulation to SHADOW execution.

    SHADOW execution means the actions will be logged alongside
    production but not replace production decisions.
    """
    tenant_runs = _simulation_runs.get(tenant_id, {})
    run_data = tenant_runs.get(run_id)
    if run_data is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Simulation run {run_id} not found",
        )

    if not body.confirm:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Promotion requires confirm=true",
        )

    run_data["status"] = "promoted_to_shadow"
    logger.info("Simulation %s promoted to SHADOW execution", run_id)

    return PromoteResponse(
        run_id=run_id,
        promoted=True,
        promotion_target="SHADOW",
    )


# ---------------------------------------------------------------------------
# Simulation Interaction (PR-CB4 — MiroFish bar)
# ---------------------------------------------------------------------------


class InjectRequest(BaseModel):
    """Request body for injecting modifications into a simulation."""

    scenario: str = Field(..., min_length=1, description="Description of the injected scenario")
    modifications: dict[str, Any] = Field(
        ...,
        description="Key-value modifications to world state",
    )


class InjectResponse(BaseModel):
    """Response from a simulation injection."""

    run_id: str
    scenario: str
    status: str
    artifacts: list[dict[str, Any]]
    modifications_applied: dict[str, Any]
    budget_used: int
    budget_limit: int


@router.post("/{run_id}/inject", response_model=InjectResponse)
async def inject_simulation(
    run_id: str,
    body: InjectRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> InjectResponse:
    """Modify world state mid-simulation and re-run with modified parameters.

    Allows interactive "what-if" scenario exploration by injecting changes
    into an existing simulation run.
    """
    tenant_runs = _simulation_runs.get(tenant_id, {})
    run_data = tenant_runs.get(run_id)
    if run_data is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Simulation run {run_id} not found",
        )

    # Re-run simulation with modified parameters
    original_goal = run_data.get("goal", "")
    modified_goal = f"{original_goal} [injected: {body.scenario}]"

    sandbox = SimulationSandbox(
        tenant_id=tenant_id,
        budget_limit=run_data.get("budget_limit", 100),
    )

    # Apply modifications as additional simulation context
    action_sequence = plan_simulation_actions(modified_goal, None)
    artifacts: list[SimulationArtifact] = []

    for tool_id, operation, inputs in action_sequence:
        # Merge modifications into inputs
        merged_inputs = {**inputs, **body.modifications}
        result = sandbox.execute_action(
            tool_id=tool_id,
            operation=operation,
            inputs=merged_inputs,
        )
        if result.budget_exceeded:
            break

        artifacts.append(
            SimulationArtifact(
                action=f"{tool_id}:{operation}",
                predicted_outcome=result.predicted_outcome,
                confidence=0.7,  # Lower confidence for injected scenarios
                assumptions=[f"Injected scenario: {body.scenario}"],
            )
        )

    # Update stored run with injection results
    run_data["status"] = "injected"
    run_data["last_injection"] = {
        "scenario": body.scenario,
        "modifications": body.modifications,
    }

    logger.info(
        "Simulation %s injected with scenario: %s (%d artifacts)",
        run_id,
        body.scenario,
        len(artifacts),
    )

    return InjectResponse(
        run_id=run_id,
        scenario=body.scenario,
        status="injected",
        artifacts=[a.to_dict() for a in artifacts],
        modifications_applied=body.modifications,
        budget_used=sandbox.budget_used,
        budget_limit=run_data.get("budget_limit", 100),
    )

