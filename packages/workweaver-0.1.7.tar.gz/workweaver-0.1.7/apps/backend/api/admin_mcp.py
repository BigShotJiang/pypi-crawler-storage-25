"""Admin MCP endpoint — founder-authenticated tool discovery and invocation.

Separate from the workspace-scoped public MCP to avoid tool pollution.
Only founder-authenticated callers see admin tools.

Progressive disclosure: returns lightweight index by default, full schemas on demand.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.api.founder_admin import require_founder
from apps.backend.services.admin.admin_permission import AdminPermission
from apps.backend.mcp.admin_tools import (
    get_admin_tool_by_name,
    get_admin_tool_categories,
    register_admin_mcp_tools,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/admin/mcp", tags=["admin-mcp"])


@router.get("/tools")
def list_admin_mcp_tools(
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.MCP_READ)),
    category: str | None = Query(None, description="Filter by category"),
    full: bool = Query(False, description="Include full inputSchema"),
) -> dict[str, Any]:
    """List admin MCP tools with optional category filter.

    By default returns a lightweight index (name, description, category, namespace)
    suitable for progressive disclosure. Set full=true for complete schemas.
    """
    if category:
        cats = get_admin_tool_categories()
        tools = cats.get(category, [])
    else:
        tools = register_admin_mcp_tools()

    if full:
        return {"tools": tools, "total": len(tools)}

    # Lightweight index for progressive disclosure
    index = []
    for tool in tools:
        index.append({
            "name": tool["name"],
            "description": tool.get("description", ""),
            "category": tool.get("category", ""),
            "namespace": tool.get("namespace", "admin"),
        })
    return {"tools": index, "total": len(index)}


@router.get("/tools/{tool_name}")
def get_admin_mcp_tool(
    tool_name: str,
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.MCP_READ)),
) -> dict[str, Any]:
    """Get full schema for a specific admin MCP tool."""
    tool = get_admin_tool_by_name(tool_name)
    if not tool:
        raise HTTPException(status_code=404, detail=f"Admin tool '{tool_name}' not found")
    return tool


@router.get("/categories")
def list_admin_mcp_categories(
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.MCP_READ)),
) -> dict[str, Any]:
    """List admin MCP tool categories with counts for progressive disclosure."""
    cats = get_admin_tool_categories()
    return {
        "categories": [
            {"name": name, "tools": len(tools), "tool_names": [t["name"] for t in tools]}
            for name, tools in cats.items()
        ],
        "total_categories": len(cats),
    }


@router.get("/search")
def search_admin_mcp_tools(
    q: str = Query(..., description="Search query"),
    _founder: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.MCP_READ)),
    limit: int = Query(5, ge=1, le=20),
) -> dict[str, Any]:
    """Search admin MCP tools by keyword."""
    import re

    tokens = set(re.findall(r"[a-z0-9]+", q.lower()))
    all_tools = register_admin_mcp_tools()

    scored: list[tuple[int, dict[str, Any]]] = []
    for tool in all_tools:
        text = f"{tool['name']} {tool.get('description', '')} {tool.get('category', '')}".lower()
        text_tokens = set(re.findall(r"[a-z0-9]+", text))
        overlap = len(tokens & text_tokens)
        score = overlap * 10
        compact_q = q.lower().replace(" ", "_")
        if compact_q in tool["name"].lower():
            score += 50
        if any(t in tool["name"].lower() for t in tokens):
            score += 15
        if score:
            scored.append((score, tool))

    scored.sort(key=lambda x: -x[0])
    results = [t for _, t in scored[:limit]]
    return {"results": results, "total": len(results), "query": q}
