"""Meeting provider webhooks.

Receives provider lifecycle events and updates meeting runtime state.
Triggers agentic post-meeting intelligence on meeting completion events.

Recall.ai verification uses workspace-level HMAC-SHA256 signatures.
Each regional account (us-west-2, eu-central-1, ap-northeast-1) has its own
verification secret. The handler tries all configured secrets since the
inbound request does not identify its source region before signature check.

Replay safety:
- Production environments reject webhooks when no verification secret is set.
- Timestamps outside a 5-minute freshness window are rejected.
- Duplicate webhook events (same ``webhook-id``) are acknowledged but not
  re-processed, preventing double metering finalization or post-meeting dispatch.
"""

from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import json
import logging
import os
import time
from typing import Any

from fastapi import APIRouter, Header, HTTPException, Request

from apps.backend.api.meetings import _DONE_EVENTS as _MEETING_DONE_EVENTS
from apps.backend.api.meetings import apply_provider_event
from apps.backend.config.environment import is_production_like
from apps.backend.services.meeting.error_contracts import meeting_store_unavailable_http_exception
from apps.backend.services.meeting_session_store import (
    MeetingSessionStoreError,
    get_meeting_session_store,
)
from apps.backend.services.meeting.post_meeting_agent import PostMeetingAgent
from apps.backend.services.webhooks.fast_ack import get_webhook_fast_ack_ingress

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/webhooks/meetings", tags=["meeting-webhooks"])

# Event types that indicate meeting completion. Keep webhook dispatch and
# runtime lifecycle classification on the same terminal-event contract.
_DONE_EVENTS = _MEETING_DONE_EVENTS

# Recall.ai regional accounts -- each has its own verification secret
_RECALL_REGIONS = ("us_west_2", "eu_central_1", "ap_northeast_1")

# Maximum allowable clock skew in seconds for webhook timestamp freshness.
_WEBHOOK_FRESHNESS_SECONDS = 300  # 5 minutes


def _context_dict(*candidates: Any) -> dict[str, Any]:
    merged: dict[str, Any] = {}
    for candidate in candidates:
        if isinstance(candidate, dict):
            merged.update(candidate)
    return merged


def _get_verification_secrets() -> list[str]:
    """Collect all configured Recall.ai verification secrets.

    Checks per-region env vars first (production ECS), then falls back
    to a single RECALL_VERIFICATION_SECRET (local dev).
    """
    secrets: list[str] = []
    for region in _RECALL_REGIONS:
        val = os.getenv(f"RECALL_VERIFICATION_SECRET_{region.upper()}", "").strip()
        if val:
            secrets.append(val)
    # Single-secret fallback for local dev
    single = os.getenv("RECALL_VERIFICATION_SECRET", "").strip()
    if single and single not in secrets:
        secrets.append(single)
    return secrets


def _check_timestamp_freshness(webhook_timestamp: str | None) -> None:
    """Reject timestamps outside the freshness window.

    The timestamp is a Unix epoch in seconds. Both stale (too old) and
    skewed-future (too far ahead) timestamps are rejected to mitigate
    replay attacks.
    """
    if not webhook_timestamp:
        return
    try:
        ts = int(webhook_timestamp)
    except (ValueError, TypeError):
        return  # Let HMAC verification handle missing/invalid headers
    now = int(time.time())
    if abs(now - ts) > _WEBHOOK_FRESHNESS_SECONDS:
        raise HTTPException(status_code=401, detail="stale_webhook_timestamp")


def _verify_recall_hmac(
    webhook_id: str | None,
    webhook_timestamp: str | None,
    webhook_signature: str | None,
    raw_body: bytes,
) -> None:
    """Verify Recall.ai request using HMAC-SHA256 workspace verification.

    Recall sends three headers: webhook-id, webhook-timestamp, webhook-signature.
    Signed message = "{webhook-id}.{webhook-timestamp}.{raw_body}".
    Signature format = "v1,<base64_hmac_sha256>".

    Tries all configured regional secrets; passes if any one matches.

    Environment-dependent behaviour:
    - **Production/staging**: Rejects webhooks when no verification secrets
      are configured (``401 no_verification_secret_configured``).
    - **Dev/local/test**: Skips verification when no secrets are configured
      so local development works without setting up secrets.
    """
    secrets = _get_verification_secrets()
    if not secrets:
        if is_production_like():
            raise HTTPException(
                status_code=401,
                detail="no_verification_secret_configured",
            )
        return

    if not webhook_id or not webhook_timestamp or not webhook_signature:
        raise HTTPException(status_code=401, detail="missing_verification_headers")

    # Timestamp freshness check -- must happen after header presence check.
    _check_timestamp_freshness(webhook_timestamp)

    # Extract v1 signatures (Recall may send multiple versions)
    v1_sigs = [part[3:] for part in webhook_signature.split(" ") if part.startswith("v1,")]
    if not v1_sigs:
        raise HTTPException(status_code=401, detail="invalid_signature_format")

    msg = f"{webhook_id}.{webhook_timestamp}.{raw_body.decode('utf-8')}"
    msg_bytes = msg.encode("utf-8")

    for secret in secrets:
        key_material = secret
        # Strip whsec_ prefix if present (Svix standard)
        if key_material.startswith("whsec_"):
            key_material = key_material[6:]
        try:
            key_bytes = base64.b64decode(key_material)
        except Exception:
            key_bytes = key_material.encode("utf-8")

        expected = base64.b64encode(hmac.new(key_bytes, msg_bytes, hashlib.sha256).digest()).decode("utf-8")

        if any(hmac.compare_digest(expected, sig) for sig in v1_sigs):
            return  # Valid -- at least one regional secret matched

    raise HTTPException(status_code=401, detail="invalid_webhook_signature")


def _is_duplicate_webhook(webhook_id: str | None) -> bool:
    """Check if a webhook event has already been processed.

    Uses the session store's in-process idempotency set. Returns True
    for previously seen ``webhook_id`` values and records new ones.
    """
    if not webhook_id:
        return False
    store = get_meeting_session_store()
    if store.is_duplicate_event(webhook_id):
        return True
    store.record_event_id(webhook_id)
    return False


@router.post("/recall")
async def recall_webhook(
    request: Request,
    webhook_id: str | None = Header(None),
    webhook_timestamp: str | None = Header(None),
    webhook_signature: str | None = Header(None),
) -> dict[str, Any]:
    """Handle Recall.ai webhook payload.

    Signature verification and replay safety checks happen on the raw body
    before JSON parsing. Duplicate events are acknowledged without re-running
    side effects.
    """
    raw_body = await request.body()
    _verify_recall_hmac(webhook_id, webhook_timestamp, webhook_signature, raw_body)

    # Deduplicate before any state mutation or side-effect dispatch.
    if _is_duplicate_webhook(webhook_id):
        logger.info("Duplicate webhook acknowledged: webhook_id=%s", webhook_id)
        return {"ok": True, "duplicate": True, "webhook_id": webhook_id}

    try:
        payload = json.loads(raw_body)
    except (json.JSONDecodeError, ValueError) as exc:
        raise HTTPException(status_code=400, detail="invalid_payload") from exc
    if not isinstance(payload, dict):
        raise HTTPException(status_code=400, detail="invalid_payload")

    event_type = str(payload.get("event") or payload.get("type") or "").strip()
    data = payload.get("data") if isinstance(payload.get("data"), dict) else payload
    bot_id = str((data or {}).get("bot_id") or (data or {}).get("id") or "").strip()

    try:
        session_id = await apply_provider_event(
            provider="recall_ai",
            bot_id=bot_id,
            event_type=event_type,
            payload=payload,
        )
    except MeetingSessionStoreError as exc:
        logger.error("Meeting webhook rejected due to unavailable meeting store: %s", exc)
        raise meeting_store_unavailable_http_exception() from exc
    logger.info(
        "Processed recall webhook event=%s bot_id=%s session_id=%s",
        event_type,
        bot_id,
        session_id,
    )

    # Trigger agentic post-meeting intelligence on completion events
    normalized_event = event_type.strip().lower()
    if normalized_event in _DONE_EVENTS and session_id:
        _dispatch_post_meeting_agent(
            session_id=session_id,
            payload=payload,
        )

    return {"ok": True, "session_id": session_id, "event_type": event_type}


def _dispatch_post_meeting_agent(
    session_id: str,
    payload: dict[str, Any],
) -> None:
    """Dispatch post-meeting intelligence as a background task.

    Retrieves tenant_id from the session store and launches the agent.
    Does not block the webhook response.
    """
    try:
        store = get_meeting_session_store()
        session = store.get_session(session_id)
    except Exception as exc:
        logger.warning(
            "Cannot dispatch post-meeting agent for session %s: store error: %s",
            session_id,
            exc,
        )
        return

    if not session:
        logger.warning("Cannot dispatch post-meeting agent: session %s not found", session_id)
        return

    tenant_id = str(session.get("tenant_id", "")).strip()
    if not tenant_id:
        logger.warning(
            "Cannot dispatch post-meeting agent: no tenant_id for session %s",
            session_id,
        )
        return

    # Extract transcript from payload if available (provider-specific)
    data = payload.get("data") if isinstance(payload.get("data"), dict) else payload
    transcript = str((data or {}).get("transcript", ""))
    meeting_title = str(
        (data or {}).get("meeting_title") or (data or {}).get("title") or session.get("bot_name", "Meeting")
    )
    booking_context = _context_dict(session.get("booking_context"), (data or {}).get("booking_context"), payload.get("booking_context"))
    lead_context = _context_dict(session.get("lead_context"), (data or {}).get("lead_context"), payload.get("lead_context"))
    attendees = (data or {}).get("attendees") or session.get("attendees") or []

    agent = PostMeetingAgent(tenant_id=tenant_id)
    ingress = get_webhook_fast_ack_ingress()
    ingress_result = ingress.enqueue_verified(
        provider="recall_ai",
        event_id=f"post_meeting:{session_id}",
        tenant_id=tenant_id,
        payload={
            "session_id": session_id,
            "title": meeting_title,
            "tenant_id": tenant_id,
        },
    )
    if ingress_result.duplicate:
        logger.info(
            "Post-meeting agent dispatch duplicate acknowledged for session %s",
            session_id,
        )
        return

    async def _run_agent() -> None:
        try:
            result = await agent.execute(
                transcript=transcript,
                metadata={
                    "session_id": session_id,
                    "title": meeting_title,
                    "tenant_id": tenant_id,
                    "attendees": attendees if isinstance(attendees, list) else [],
                    "booking_context": booking_context,
                    "lead_context": lead_context,
                },
                session_id=session_id,
            )
            logger.info(
                "Post-meeting agent completed for session %s: status=%s",
                session_id,
                result.get("status", "unknown"),
            )
        except Exception as exc:
            ingress.release_dedupe(
                provider="recall_ai",
                event_id=f"post_meeting:{session_id}",
                tenant_id=tenant_id,
                payload={
                    "session_id": session_id,
                    "title": meeting_title,
                    "tenant_id": tenant_id,
                },
            )
            logger.error(
                "Post-meeting agent failed for session %s: %s",
                session_id,
                exc,
                exc_info=True,
            )

    try:
        loop = asyncio.get_running_loop()
        loop.create_task(_run_agent())
    except RuntimeError:
        ingress.release_dedupe(
            provider="recall_ai",
            event_id=f"post_meeting:{session_id}",
            tenant_id=tenant_id,
            payload={
                "session_id": session_id,
                "title": meeting_title,
                "tenant_id": tenant_id,
            },
        )
        logger.warning(
            "No running event loop; post-meeting agent for session %s skipped",
            session_id,
        )
