"""Founder admin: Secrets Manager audit + orphan deletion (#794).

Encodes the manual 2026-04-08 audit workflow as a persistent endpoint.
Lists every secret in AWS Secrets Manager, classifies each as wired
(referenced by an ECS task definition or Lambda function), orphan
(no references found), or unclear (couldn't determine status), and
exposes a guarded delete endpoint behind a 15-second human confirmation
gate.

Wired into the founder admin portal at admin.workweaver.ai/admin/secrets/.

Key endpoints:
    GET    /api/v1/founder/secrets/audit            — list + classify
    DELETE /api/v1/founder/secrets/{secret_name}    — guarded delete

Both endpoints require ``Depends(require_founder)`` so only platform
admins (verified by Cognito group + email allowlist) can call them.

Deletion requires THREE independent confirmations:
    1. URL-encoded secret name in path
    2. ``X-Confirm-Delete`` header value matches the path's secret name
    3. ``X-Confirm-Wait-Elapsed: true`` header — set by the frontend
       after the 15-second countdown. The backend treats this as a
       proof-of-human-pause but does NOT enforce wall-clock timing
       (can't from a stateless API). The frontend gates the button.

Never deletes a wired secret even if the operator forces it — the
audit re-runs server-side immediately before deletion, and a wired
classification raises 409.
"""

from __future__ import annotations

import logging
import os
from typing import Any

import boto3
from botocore.exceptions import BotoCoreError, ClientError
from fastapi import APIRouter, Depends, Header, HTTPException, status

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.services.admin.admin_permission import (
    AdminPermission,
    AdminPermissionCheck,
)
from apps.backend.config.secrets import get_secret_cache_stats, invalidate_secret_cache

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/founder/secrets", tags=["founder-admin-secrets"])

DEFAULT_REGION = os.getenv("AWS_REGION", "us-east-1")
SECRET_MONTHLY_COST_USD = 0.40

# Secrets matching these prefixes are NEVER returned as deletable, even
# if the wiring scan finds no references. Defense in depth against the
# "scan misses a deeply-nested env injection" failure mode.
_NEVER_DELETE_PREFIXES = (
    "workweaver/jwt/",
    "workweaver/cognito/",
    "workweaver/db/",
    "workweaver/postgres/",
    "rds/",
    "/aws/",
)


def _list_all_secrets(sm: Any) -> list[dict[str, Any]]:
    """Return every secret in the account (paginated)."""
    secrets: list[dict[str, Any]] = []
    next_token: str | None = None
    while True:
        kwargs: dict[str, Any] = {"MaxResults": 100}
        if next_token:
            kwargs["NextToken"] = next_token
        resp = sm.list_secrets(**kwargs)
        secrets.extend(resp.get("SecretList", []))
        next_token = resp.get("NextToken")
        if not next_token:
            break
    return secrets


def _list_ecs_secret_arns(ecs: Any) -> set[str]:
    """Return the set of secret ARNs referenced by any ACTIVE task definition."""
    arns: set[str] = set()
    paginator = ecs.get_paginator("list_task_definition_families")
    for page in paginator.paginate(status="ACTIVE"):
        for family in page.get("families", []):
            try:
                td_paginator = ecs.get_paginator("list_task_definitions")
                for td_page in td_paginator.paginate(familyPrefix=family, status="ACTIVE", sort="DESC"):
                    td_arns = td_page.get("taskDefinitionArns", [])
                    if not td_arns:
                        continue
                    # Only inspect the latest revision per family — older
                    # revisions are deregistered nightly by #797 and may
                    # carry stale secret references.
                    latest = td_arns[0]
                    desc = ecs.describe_task_definition(taskDefinition=latest)
                    container_defs = desc.get("taskDefinition", {}).get("containerDefinitions", [])
                    for cd in container_defs:
                        for s in cd.get("secrets", []) or []:
                            value_from = s.get("valueFrom") or ""
                            if value_from:
                                arns.add(value_from.split(":")[-1] if ":" not in value_from else value_from)
                                arns.add(value_from)  # full ARN form too
                    break  # only latest revision
            except (ClientError, BotoCoreError) as exc:
                logger.warning("ecs_describe_failed family=%s error=%s", family, exc)
    return arns


def _list_lambda_secret_refs(lambda_client: Any) -> set[str]:
    """Return secret names/ARNs referenced by any Workweaver Lambda env vars.

    Walks every Lambda in the account; for each, scans environment.Variables
    for values that look like Secrets Manager ARNs or names beginning with
    ``workweaver/``. Best-effort heuristic.
    """
    refs: set[str] = set()
    paginator = lambda_client.get_paginator("list_functions")
    for page in paginator.paginate():
        for fn in page.get("Functions", []):
            env_vars = (fn.get("Environment") or {}).get("Variables", {}) or {}
            for value in env_vars.values():
                if not isinstance(value, str):
                    continue
                if "secretsmanager" in value.lower() or value.startswith("workweaver/"):
                    refs.add(value)
                    # Also add the bare secret name (ARN tail)
                    if ":secret:" in value:
                        refs.add(value.split(":secret:")[-1])
    return refs


def _classify_secret(
    secret: dict[str, Any],
    ecs_arns: set[str],
    lambda_refs: set[str],
) -> tuple[str, list[str]]:
    """Return (status, wired_by_list).

    status ∈ {wired, orphan, never_delete}
    """
    arn = secret.get("ARN") or ""
    name = secret.get("Name") or ""

    if any(name.startswith(p) for p in _NEVER_DELETE_PREFIXES):
        return "never_delete", ["protected_prefix"]

    wired_by: list[str] = []
    if arn in ecs_arns or name in ecs_arns:
        wired_by.append("ecs:task_definition")
    if arn in lambda_refs or name in lambda_refs:
        wired_by.append("lambda:env_var")
    # Substring search as a fallback for partial matches (e.g. ARN vs name)
    for ref in ecs_arns | lambda_refs:
        if name and name in ref:
            wired_by.append(f"substring_match:{ref[:50]}")
            break

    if wired_by:
        return "wired", wired_by
    return "orphan", []


def _audit_secrets() -> dict[str, Any]:
    """Run the audit. Returns the classification dict."""
    sm = boto3.client("secretsmanager", region_name=DEFAULT_REGION)
    ecs = boto3.client("ecs", region_name=DEFAULT_REGION)
    lambda_client = boto3.client("lambda", region_name=DEFAULT_REGION)

    secrets = _list_all_secrets(sm)
    ecs_arns = _list_ecs_secret_arns(ecs)
    lambda_refs = _list_lambda_secret_refs(lambda_client)

    wired: list[dict[str, Any]] = []
    orphans: list[dict[str, Any]] = []
    never_delete: list[dict[str, Any]] = []

    for s in secrets:
        status_label, wired_by = _classify_secret(s, ecs_arns, lambda_refs)
        entry = {
            "name": s.get("Name"),
            "arn": s.get("ARN"),
            "last_changed_date": str(s.get("LastChangedDate", "")),
            "wired_by": wired_by,
        }
        if status_label == "wired":
            wired.append(entry)
        elif status_label == "never_delete":
            never_delete.append(entry)
        else:
            orphans.append(entry)

    total = len(secrets)
    return {
        "total_secrets": total,
        "total_monthly_cost_usd": round(total * SECRET_MONTHLY_COST_USD, 2),
        "by_status": {
            "wired": wired,
            "orphan": orphans,
            "never_delete": never_delete,
        },
        "wired_count": len(wired),
        "orphan_count": len(orphans),
        "never_delete_count": len(never_delete),
        "potential_savings_monthly_usd": round(len(orphans) * SECRET_MONTHLY_COST_USD, 2),
    }


@router.get("/audit")
async def get_secrets_audit(
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.SECRETS_READ)),
) -> dict[str, Any]:
    """Audit Secrets Manager — classify wired vs orphan vs protected."""
    try:
        return _audit_secrets()
    except (ClientError, BotoCoreError) as exc:
        logger.exception("admin_secrets_audit_failed")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Secrets audit failed: {exc}",
        ) from exc


@router.post("/invalidate")
async def invalidate_secrets_cache(
    secret_name: str | None = None,
    environment: str | None = None,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.SECRETS_WRITE)),
) -> dict[str, Any]:
    """Invalidate this process's secret cache after rotation."""
    result = invalidate_secret_cache(secret_name=secret_name, environment=environment)
    return {
        **result,
        "cache": get_secret_cache_stats(),
    }


@router.delete("/{secret_name:path}")
async def delete_secret(
    secret_name: str,
    x_confirm_delete: str = Header(default="", alias="X-Confirm-Delete"),
    x_confirm_wait_elapsed: str = Header(default="", alias="X-Confirm-Wait-Elapsed"),
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.SECRETS_WRITE)),
) -> dict[str, Any]:
    """Permanently delete a Secrets Manager secret.

    Three required confirmations:
      1. ``secret_name`` in path
      2. ``X-Confirm-Delete`` header value matches the path
      3. ``X-Confirm-Wait-Elapsed: true`` set by the frontend after 15s

    Re-runs the audit before deletion and refuses if the secret is
    classified as ``wired`` or ``never_delete``.
    """
    if x_confirm_delete != secret_name:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="X-Confirm-Delete header must equal the path secret name",
        )
    if x_confirm_wait_elapsed.strip().lower() != "true":
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="X-Confirm-Wait-Elapsed: true header is required (15s frontend countdown)",
        )

    # Re-run audit + check status. Refuses to delete wired/protected secrets.
    audit = _audit_secrets()
    by_status = audit.get("by_status", {})
    wired_names = {e["name"] for e in by_status.get("wired", [])}
    protected_names = {e["name"] for e in by_status.get("never_delete", [])}

    if secret_name in wired_names:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Refusing to delete: '{secret_name}' is currently wired into a Workweaver service",
        )
    if secret_name in protected_names:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Refusing to delete: '{secret_name}' matches a protected prefix",
        )

    sm = boto3.client("secretsmanager", region_name=DEFAULT_REGION)
    try:
        sm.delete_secret(SecretId=secret_name, ForceDeleteWithoutRecovery=True)
    except (ClientError, BotoCoreError) as exc:
        logger.exception("admin_secret_delete_failed name=%s", secret_name)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Delete failed: {exc}",
        ) from exc

    logger.info("admin_secret_deleted name=%s by=founder", secret_name)
    return {"deleted": secret_name, "status": "permanently_deleted"}
