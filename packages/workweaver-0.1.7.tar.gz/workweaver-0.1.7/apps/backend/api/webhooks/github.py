"""GitHub webhook handler for code ingest (PR-6.1).

Receives webhook notifications from GitHub when code events occur
(push, pull_request, issues, pull_request_review, repository) and
ingests them into the evidence ledger.

Security:
- HMAC-SHA256 signature validation via GITHUB_WEBHOOK_SECRET env var.
- Requests fail closed if the secret is missing or invalid.
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import os
from typing import Any

from fastapi import APIRouter, HTTPException, Request

from apps.backend.api.rate_limit import limiter
from apps.backend.api.webhooks._shared import compare_webhook_secret
from apps.backend.services.evidence_ledger import get_evidence_ledger_service
from apps.backend.services.github_ingest import GitHubIngestService
from apps.backend.services.idempotency import IdempotencyStore

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/webhooks/github", tags=["webhooks"])
_delivery_store: IdempotencyStore | None = None


def _get_webhook_secret() -> str:
    """Get the HMAC secret for GitHub webhook signature validation."""
    return (os.getenv("GITHUB_WEBHOOK_SECRET") or "").strip()


def _validate_webhook_signature(
    body: bytes,
    signature: str | None,
    secret: str,
) -> bool:
    """Validate HMAC-SHA256 signature of the webhook request body.

    Args:
        body: Raw request body bytes.
        signature: X-Hub-Signature-256 header value (format: sha256=<hex>).
        secret: HMAC secret key.

    Returns:
        True if signature is valid.
    """
    if not signature:
        return False
    if not signature.startswith("sha256="):
        return False
    expected = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return compare_webhook_secret(signature, expected)


def _get_default_tenant() -> str:
    """Get the default tenant for GitHub webhooks."""
    return (os.getenv("GITHUB_WEBHOOK_DEFAULT_TENANT") or "").strip()


def _resolve_tenant(request: Request) -> str:
    """Resolve tenant ID from trusted server configuration.

    Priority:
    1. GITHUB_WEBHOOK_DEFAULT_TENANT env var

    Raises:
        HTTPException: If tenant cannot be resolved.
    """
    default_tenant = _get_default_tenant()
    if default_tenant:
        return default_tenant

    raise HTTPException(status_code=400, detail="Missing tenant ID")


def _get_github_ingest_service() -> GitHubIngestService:
    """Get the GitHub ingest service singleton."""
    from apps.backend.services.github_ingest import get_github_ingest_service

    return get_github_ingest_service()


def _get_delivery_store() -> IdempotencyStore:
    global _delivery_store  # noqa: PLW0603
    if _delivery_store is None:
        _delivery_store = IdempotencyStore()
    return _delivery_store


def _resolve_delivery_id(request: Request, raw_body: bytes) -> str:
    delivery_id = str(request.headers.get("X-GitHub-Delivery") or "").strip()
    if delivery_id:
        return delivery_id
    return hashlib.sha256(raw_body).hexdigest()


@router.post("")
@limiter.limit("30/minute")
async def handle_github_webhook(request: Request) -> dict[str, Any]:
    """Handle GitHub webhook events.

    Validates HMAC signature (if configured), extracts event type from
    X-GitHub-Event header, and routes to the GitHubIngestService.

    Returns:
        Acknowledgment with count of ingested entities and event type.
    """
    # --- Signature validation ---
    webhook_secret = _get_webhook_secret()
    if not webhook_secret:
        raise HTTPException(status_code=503, detail="GITHUB_WEBHOOK_SECRET not configured")
    raw_body = await request.body()

    signature = request.headers.get("X-Hub-Signature-256")
    if not _validate_webhook_signature(raw_body, signature, webhook_secret):
        logger.warning("GitHub webhook signature validation failed")
        raise HTTPException(status_code=401, detail="Invalid webhook signature")

    # --- Event type validation ---
    event_type = request.headers.get("X-GitHub-Event")
    if not event_type:
        raise HTTPException(status_code=400, detail="Missing X-GitHub-Event header")

    # --- Tenant resolution ---
    tenant_id = _resolve_tenant(request)
    delivery_id = _resolve_delivery_id(request, raw_body)
    dedupe_key = f"github_webhook:{tenant_id}:{delivery_id}"

    duplicate = _get_delivery_store().check(dedupe_key)
    if duplicate.is_duplicate:
        cached_result = duplicate.cached_result or {}
        logger.info(
            "GitHub webhook deduplicated: event_type=%s tenant=%s delivery_id=%s",
            event_type,
            tenant_id,
            delivery_id,
        )
        return {
            "accepted": int(cached_result.get("accepted", 0)),
            "event_type": str(cached_result.get("event_type") or event_type),
            "duplicate": True,
        }

    # --- Parse payload ---
    try:
        payload: dict[str, Any] = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    logger.info(
        "GitHub webhook received: event_type=%s tenant=%s",
        event_type,
        tenant_id,
    )

    # --- Route to ingest service ---
    ingest_service = _get_github_ingest_service()
    entities = ingest_service.route_event(tenant_id, event_type, payload)

    # --- Write each entity to evidence ledger ---
    evidence_service = get_evidence_ledger_service()
    for entity in entities:
        try:
            evidence_service.ingest(
                tenant_id=entity.tenant_id,
                event_type=entity.entity_type,
                data=entity.fields,
                capture_surface="github_webhook",
                service_family="code",
                source_event_id=entity.entity_id,
            )
        except Exception:
            logger.exception(
                "Failed to ingest entity %s into evidence ledger",
                entity.entity_id,
            )

    logger.info(
        "GitHub webhook processed: event_type=%s accepted=%d",
        event_type,
        len(entities),
    )

    _get_delivery_store().store(
        dedupe_key,
        {
            "accepted": len(entities),
            "event_type": event_type,
        },
    )

    return {
        "accepted": len(entities),
        "event_type": event_type,
    }
