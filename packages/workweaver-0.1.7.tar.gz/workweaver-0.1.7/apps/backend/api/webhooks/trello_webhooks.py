"""Trello webhook handler for card assignment events.

Receives webhook notifications from Trello (updateCard, addMemberToCard)
and routes card assignments to Zara intake for processing.

Security:
- HMAC-SHA256 signature validation of content + callbackURL.
- Requests fail closed if the secret is missing or invalid.
- Trello sends HEAD requests for webhook confirmation (returns 200).
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import os
from typing import Any

from fastapi import APIRouter, HTTPException, Request

from apps.backend.api.rate_limit import limiter
from apps.backend.api.webhooks._shared import compare_webhook_secret
from apps.backend.services.connectors.base import ConnectorConfig
from apps.backend.services.connectors.markup_converter import convert_to_markdown
from apps.backend.services.connectors.trello_connector import (
    TrelloConnector,
    detect_comment_event as trello_detect_comment,
)
from apps.backend.services.idempotency import IdempotencyStore

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/webhooks/trello", tags=["webhooks"])
_delivery_store: IdempotencyStore | None = None


def _get_webhook_secret() -> str:
    """Get the HMAC secret for Trello webhook signature validation."""
    return (os.getenv("TRELLO_WEBHOOK_SECRET") or "").strip()


def _get_callback_url() -> str:
    """Get the configured callback URL for Trello webhooks."""
    return (os.getenv("TRELLO_WEBHOOK_CALLBACK_URL") or "").strip()


def _get_api_key() -> str:
    """Get the Trello API key."""
    return (os.getenv("TRELLO_API_KEY") or "").strip()


def _get_api_token() -> str:
    """Get the Trello API token."""
    return (os.getenv("TRELLO_API_TOKEN") or "").strip()


def _get_default_tenant() -> str:
    """Get the default tenant for Trello webhooks."""
    return (os.getenv("TRELLO_WEBHOOK_DEFAULT_TENANT") or "").strip()


def _get_delivery_store() -> IdempotencyStore:
    global _delivery_store  # noqa: PLW0603
    if _delivery_store is None:
        _delivery_store = IdempotencyStore()
    return _delivery_store


def _make_connector(
    *,
    tenant_id: str,
    webhook_secret: str,
    callback_url: str,
) -> TrelloConnector:
    """Build a TrelloConnector with the given credentials."""
    config = ConnectorConfig(
        provider="trello",
        tenant_id=tenant_id,
        credentials={
            "api_key": _get_api_key(),
            "api_token": _get_api_token(),
            "webhook_secret": webhook_secret,
            "callback_url": callback_url,
        },
    )
    return TrelloConnector(config)


@router.head("")
@limiter.limit("30/minute")
async def handle_trello_webhook_head(request: Request) -> None:
    """Handle Trello HEAD request for webhook confirmation.

    Trello sends a HEAD request to verify the webhook endpoint is reachable.
    We return 200 to confirm.
    """
    return None


@router.post("")
@limiter.limit("30/minute")
async def handle_trello_webhook(request: Request) -> dict[str, Any]:
    """Handle Trello webhook POST events.

    Validates HMAC signature (if configured), parses the payload, and
    routes card assignment events to Zara intake.

    Returns:
        Acknowledgment with routing status.
    """
    raw_body = await request.body()

    # --- Signature validation ---
    webhook_secret = _get_webhook_secret()
    callback_url = _get_callback_url()
    tenant_id = _get_default_tenant()

    if webhook_secret:
        connector = _make_connector(
            tenant_id=tenant_id,
            webhook_secret=webhook_secret,
            callback_url=callback_url,
        )
        # Cache raw body for sync verification
        connector._get_raw_body = lambda req: raw_body  # noqa: PLW0603

        presented = request.headers.get("X-Trello-Webhook")

        message = raw_body + callback_url.encode("utf-8")
        expected = hmac.new(
            webhook_secret.encode("utf-8"),
            message,
            hashlib.sha256,
        ).hexdigest()

        if not compare_webhook_secret(presented, expected):
            logger.warning("Trello webhook signature validation failed")
            raise HTTPException(status_code=401, detail="Invalid webhook signature")

    # --- Parse payload ---
    try:
        payload: dict[str, Any] = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    # --- Deduplication ---
    action_id = ""
    action = payload.get("action") or {}
    action_id = str(action.get("id") or "")
    dedupe_key = f"trello_webhook:{tenant_id}:{action_id}"

    if action_id:
        store = _get_delivery_store()
        duplicate = store.check(dedupe_key)
        if duplicate.is_duplicate:
            cached_result = duplicate.cached_result or {}
            logger.info(
                "Trello webhook deduplicated: action_id=%s tenant=%s",
                action_id,
                tenant_id,
            )
            return {
                "routed": bool(cached_result.get("routed")),
                "action_id": action_id,
                "duplicate": True,
            }

    # --- Route assignment events to Zara ---
    if not tenant_id:
        logger.warning("Trello webhook received without tenant context")
        return {"routed": False, "reason": "no_tenant"}

    connector = _make_connector(
        tenant_id=tenant_id,
        webhook_secret=webhook_secret,
        callback_url=callback_url,
    )
    result = await connector.route_assignment_to_zara(payload, tenant_id=tenant_id)

    # --- Check for comment events (Issue #3586) ---
    if not result.get("routed"):
        comment = trello_detect_comment(payload)
        if comment is not None:
            comment_text = convert_to_markdown(
                comment.comment_body, comment.comment_body_format,
            )
            try:
                from apps.backend.services.zara.zara_intake_service import (
                    get_zara_intake_service,
                )

                intake = get_zara_intake_service()
                await intake.handle_inbound_pm_comment(
                    workspace_id=tenant_id,
                    source_provider=comment.source_provider,
                    external_id=comment.external_id,
                    comment_text=comment_text,
                    author_email=comment.author_email,
                    author_name=comment.author_name,
                    parent_issue_key=comment.parent_issue_key,
                )
            except Exception:
                logger.exception(
                    "Trello comment routing failed: tenant=%s card=%s",
                    tenant_id,
                    comment.parent_issue_key,
                )

            comment_result = {
                "routed": False,
                "comment_routed": True,
                "card_id": comment.parent_issue_key,
                "comment_id": comment.external_id,
            }
            if action_id:
                _get_delivery_store().store(dedupe_key, comment_result)

            return comment_result

    # --- Store for dedup ---
    if action_id:
        _get_delivery_store().store(dedupe_key, result)

    logger.info(
        "Trello webhook processed: action_id=%s routed=%s",
        action_id,
        result.get("routed"),
    )

    return result
