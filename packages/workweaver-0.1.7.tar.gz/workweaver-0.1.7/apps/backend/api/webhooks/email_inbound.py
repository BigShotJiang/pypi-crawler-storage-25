"""Inbound email webhook for Zara workspace aliases."""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import JSONResponse

from apps.backend.services.email.inbound_pipeline import (
    InboundEmailPipelineError,
    ParsedInboundEmail,
    extract_ses_payload,
    normalize_inbound_payload,
    passed_security_verdicts,
)
from apps.backend.services.zara.email_intake_service import (
    InboundEmail,
    InboundEmailAttachment,
    IntakeOutcome,
    ZaraEmailIntakeService,
    get_zara_email_intake_service,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/webhooks/email", tags=["webhooks", "email"])


def get_email_intake_service() -> ZaraEmailIntakeService:
    """FastAPI dependency wrapper, overridable in tests."""
    return get_zara_email_intake_service()


@router.post("/inbound")
async def handle_email_inbound(
    request: Request,
    intake: ZaraEmailIntakeService = Depends(get_email_intake_service),
) -> JSONResponse:
    """Handle SES inbound notifications and Gmail push sandbox envelopes."""
    try:
        envelope = await request.json()
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"invalid JSON: {exc}") from exc

    if not isinstance(envelope, dict):
        raise HTTPException(status_code=400, detail="payload must be a JSON object")

    sns_type = str(envelope.get("Type") or "").strip()
    if sns_type == "SubscriptionConfirmation":
        logger.info(
            "email_inbound_subscription_confirmation message_id=%s",
            envelope.get("MessageId"),
        )
        return JSONResponse(content={"ok": True, "status": "subscription_confirmation"})

    ses_payload = extract_ses_payload(envelope)
    if ses_payload is not None and not passed_security_verdicts(ses_payload):
        logger.warning(
            "email_inbound_dropped_failing_verdicts message_id=%s",
            ses_payload.get("mail", {}).get("messageId"),
        )
        return JSONResponse(content={"ok": True, "status": "dropped_failing_verdicts"})

    try:
        parsed, deferred_status = normalize_inbound_payload(envelope)
    except InboundEmailPipelineError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    if deferred_status:
        logger.info("email_inbound_provider_deferred status=%s", deferred_status)
        return JSONResponse(content={"ok": True, "status": deferred_status})
    if parsed is None:
        raise HTTPException(status_code=400, detail="payload did not contain an email message")

    inbound = _to_zara_inbound(parsed)
    try:
        result = await intake.handle_inbound_email(inbound)
    except Exception as exc:
        logger.exception(
            "email_inbound_intake_unhandled_error message_id=%s", inbound.message_id
        )
        raise HTTPException(status_code=500, detail="email intake failed") from exc

    if result.status == IntakeOutcome.REJECTED_INVALID_ADDRESS:
        raise HTTPException(
            status_code=400,
            detail=result.detail or "invalid recipient address",
        )

    return JSONResponse(content=result.to_response())


def _to_zara_inbound(parsed: ParsedInboundEmail) -> InboundEmail:
    return InboundEmail(
        sender=parsed.sender,
        to=parsed.to,
        subject=parsed.subject,
        body_text=parsed.body_text,
        message_id=parsed.message_id,
        in_reply_to=parsed.in_reply_to,
        references=parsed.references,
        cc=parsed.cc,
        attachments=tuple(
            InboundEmailAttachment(
                filename=attachment.filename,
                content_type=attachment.content_type,
                size_bytes=attachment.size_bytes,
                text=attachment.text,
                content_sha256=attachment.content_sha256,
            )
            for attachment in parsed.attachments
        ),
    )


__all__ = ["get_email_intake_service", "router"]
