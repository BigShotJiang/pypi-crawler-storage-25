"""Inbound SMS webhook handler — Twilio -> Workweaver.

Receives inbound SMS messages from Twilio and routes them
into the unified conversation system.

Launch Plan L4.5: SMS as first-class conversational channel.
"""

from __future__ import annotations

import logging
from datetime import datetime, UTC
from typing import Any

from fastapi import APIRouter, Form, Request
from fastapi.responses import Response

from apps.backend.api.sms import _canonical_sms_source_ref, _resolve_tenant_from_account_sid
from apps.backend.services.channels.channel_router import summarize_delivery_result

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/webhooks/sms", tags=["webhooks", "sms"])


def _get_thread_service():
    from apps.backend.services.thread_service import get_thread_service

    return get_thread_service()


@router.post("/inbound")
async def handle_sms_inbound(
    request: Request,
    From: str = Form(default=""),
    To: str = Form(default=""),
    Body: str = Form(default=""),
    MessageSid: str = Form(default=""),
    AccountSid: str = Form(default=""),
    NumMedia: str = Form(default="0"),
    MediaUrl0: str = Form(default=""),
    MediaContentType0: str = Form(default=""),
) -> Response:
    """Handle inbound SMS from Twilio.

    Twilio sends POST with form data for each inbound SMS.
    The message is stored in DynamoDB and optionally routed to
    the channel router for cross-channel dispatch.

    Returns an empty TwiML response (no auto-reply).
    """
    from_number = str(From).strip()
    to_number = str(To).strip()
    body = str(Body).strip()
    message_sid = str(MessageSid).strip()

    if not from_number or not body:
        logger.warning(
            "SMS inbound missing from/body: from=%s sid=%s",
            from_number,
            message_sid,
        )
        return Response(content="<Response></Response>", media_type="application/xml")

    logger.info(
        "SMS inbound received: from=%s to=%s sid=%s body_length=%d",
        from_number,
        to_number,
        message_sid,
        len(body),
    )
    tenant_id = _resolve_tenant_from_account_sid(str(AccountSid).strip())

    # Store the inbound message
    try:
        _store_inbound_sms(
            tenant_id=tenant_id,
            from_number=from_number,
            to_number=to_number,
            body=body,
            message_sid=message_sid,
            num_media=int(NumMedia or "0"),
            media_url=str(MediaUrl0).strip() or None,
            media_type=str(MediaContentType0).strip() or None,
        )
    except Exception as exc:
        logger.error("Failed to store inbound SMS: %s", exc, exc_info=True)

    # Route to channel router if available
    route_result = await _route_inbound_sms(
        tenant_id=tenant_id,
        from_number=from_number,
        body=body,
        message_sid=message_sid,
    )
    if route_result is not None and route_result.get("manual_required"):
        logger.warning(
            "SMS channel routing degraded: status=%s channel=%s error=%s",
            route_result.get("status"),
            route_result.get("channel"),
            route_result.get("error"),
        )

    # Persist inbound SMS interaction to WorkMemory (fire-and-forget)
    try:
        _persist_sms_channel_interaction(
            tenant_id=tenant_id,
            contact_id=from_number,
            direction="inbound",
            summary=body[:200] or "[empty]",
            message_sid=message_sid,
        )
    except Exception as exc:
        logger.warning("SMS WorkMemory persistence failed (non-fatal): %s", exc)

    # Slice 14: project the SMS onto the Mission Calendar as an
    # ``external_message`` card. Idempotent — re-ingest of the same SID
    # returns the existing card without creating a duplicate.
    try:
        _project_sms_to_calendar(
            tenant_id=tenant_id,
            from_number=from_number,
            body=body,
            message_sid=message_sid,
        )
    except Exception as exc:
        logger.warning(
            "external_message card projection failed (non-fatal): %s", exc
        )

    # Return empty TwiML response
    return Response(content="<Response></Response>", media_type="application/xml")


def _project_sms_to_calendar(
    *,
    tenant_id: str,
    from_number: str,
    body: str,
    message_sid: str,
) -> None:
    """Emit an ``external_message`` Mission Calendar card for the SMS.

    Lazy-imports the projector so the webhook still works in deployment
    profiles where the inbox services package isn't loaded.
    """
    from apps.backend.services.inbox.external_message_card_projector import (
        get_external_message_card_projector,
    )

    projector = get_external_message_card_projector()
    projector.project_message(
        tenant_id=tenant_id,
        channel="sms",
        external_message_id=message_sid or f"sms:{from_number}:{datetime.now(UTC).isoformat()}",
        from_contact=from_number,
        body=body,
        arrived_at=datetime.now(UTC),
    )


def _store_inbound_sms(
    *,
    tenant_id: str,
    from_number: str,
    to_number: str,
    body: str,
    message_sid: str,
    num_media: int = 0,
    media_url: str | None = None,
    media_type: str | None = None,
) -> dict[str, Any] | None:
    """Store inbound SMS on the canonical thread model."""
    metadata: dict[str, Any] = {"num_media": num_media}
    if media_url:
        metadata["media_url"] = media_url
    if media_type:
        metadata["media_type"] = media_type
    return _get_thread_service().record_channel_message(
        tenant_id=tenant_id,
        channel="sms",
        source_ref=_canonical_sms_source_ref(from_number, to_number),
        message_id=message_sid,
        direction="inbound",
        participant=from_number,
        body=body,
        unread=True,
        event_type="inbound_received",
        thread_kind="sms",
        participants=[from_number, to_number],
        status="received",
        metadata=metadata,
    )


def _persist_sms_channel_interaction(
    *,
    tenant_id: str,
    contact_id: str,
    direction: str,
    summary: str,
    message_sid: str,
) -> None:
    """Persist an SMS channel interaction to WorkMemory (fire-and-forget).

    Runs the async WorkMemory call in a background thread to avoid blocking
    the synchronous SMS webhook pipeline.
    """
    import asyncio
    import threading

    def _run() -> None:
        try:
            from apps.backend.services.memory.runtime import get_runtime

            async def _store() -> None:
                client = get_runtime()
                content = f"SMS {direction} from {contact_id}: {summary}"
                await client.remember(
                    content=content,
                    tenant_id=tenant_id,
                    category="channel_interaction",
                    metadata={
                        "contact_id": contact_id,
                        "channel_type": "sms",
                        "direction": direction,
                        "message_sid": message_sid,
                        "timestamp": datetime.now(UTC).isoformat(),
                    },
                    source_type="channel",
                )

            loop = asyncio.new_event_loop()
            try:
                loop.run_until_complete(_store())
            finally:
                loop.close()
        except Exception:
            logger.warning(
                "Failed to persist SMS channel interaction to WorkMemory tenant=%s sid=%s (non-blocking)",
                tenant_id,
                message_sid,
                exc_info=True,
            )

    thread = threading.Thread(target=_run, daemon=True)
    thread.start()


async def _route_inbound_sms(*, tenant_id: str, from_number: str, body: str, message_sid: str) -> dict[str, Any]:
    """Route SMS to channel router for cross-channel handling.

    Dispatches the inbound SMS through the ChannelRouter so it can be
    responded to on the sender's preferred channel (or echoed back on SMS).
    Returns an explicit routing outcome so callers can distinguish a
    delivered message from a manual-required fallback.
    """
    try:
        from apps.backend.services.channels.channel_router import get_channel_router
    except ImportError:
        logger.debug("ChannelRouter not available — SMS stored but not routed")
        return {
            "status": "manual_required",
            "delivery_status": "failed",
            "manual_required": True,
            "degraded": True,
            "channel": "sms",
            "error": "channel_router_unavailable",
        }

    router = get_channel_router()
    contact_id = from_number

    try:
        delivery = await router.route_message(
            tenant_id=tenant_id,
            contact_id=contact_id,
            message=body,
            channel_origin="sms",
        )
        outcome = summarize_delivery_result(delivery)
        if outcome["manual_required"]:
            logger.warning(
                "Routed inbound SMS from %s but manual follow-up is required (sid=%s)",
                from_number,
                message_sid,
            )
        else:
            logger.info(
                "Routed inbound SMS from %s via channel router (sid=%s)",
                from_number,
                message_sid,
            )
        return outcome
    except Exception as exc:
        logger.warning("SMS channel routing dispatch failed (non-fatal): %s", exc)
        return {
            "status": "manual_required",
            "delivery_status": "failed",
            "manual_required": True,
            "degraded": True,
            "channel": "sms",
            "error": str(exc),
        }
