"""Linear webhook handler for assignment routing and comment sync to Zara intake.

Receives webhook notifications from Linear when issue events occur and
routes assignment events and inbound comments to the Zara intake service.

Security:
- HMAC-SHA256 signature validation via LINEAR_WEBHOOK_SECRET env var.
- Linear sends raw hex digest in X-Linear-Signature header (no prefix).
- Requests fail closed if the secret is missing or invalid.

Issue #2781.
"""

from __future__ import annotations

import hashlib
import logging
import os
from typing import Any

from fastapi import APIRouter, HTTPException, Request

from apps.backend.api.rate_limit import limiter
from apps.backend.services.connectors.markup_converter import convert_to_markdown
from apps.backend.services.idempotency import IdempotencyStore

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/webhooks/linear", tags=["webhooks"])
_delivery_store: IdempotencyStore | None = None


def _get_webhook_secret() -> str:
    """Get the HMAC secret for Linear webhook signature validation."""
    return (os.getenv("LINEAR_WEBHOOK_SECRET") or "").strip()


def _get_default_tenant() -> str:
    """Get the default tenant for Linear webhooks."""
    return (os.getenv("LINEAR_WEBHOOK_DEFAULT_TENANT") or "").strip()


def _get_delivery_store() -> IdempotencyStore:
    global _delivery_store  # noqa: PLW0603
    if _delivery_store is None:
        _delivery_store = IdempotencyStore()
    return _delivery_store


def _get_linear_connector(tenant_id: str) -> Any:
    """Instantiate a LinearConnector for the given tenant."""
    from apps.backend.services.connectors.linear_connector import LinearConnector

    try:
        from apps.backend.services.zara.zara_intake_service import (
            get_zara_intake_service,
        )

        zara_intake = get_zara_intake_service()
    except Exception:
        zara_intake = None
        logger.warning("linear_webhook.zara_intake_unavailable tenant=%s", tenant_id)

    return LinearConnector(
        webhook_secret=_get_webhook_secret(),
        tenant_id=tenant_id,
        zara_intake=zara_intake,
    )


def _resolve_delivery_id(request: Request, raw_body: bytes) -> str:
    """Resolve a unique delivery ID for deduplication."""
    for header_name in ("X-Linear-Delivery-Id", "X-Request-Id"):
        delivery_id = str(request.headers.get(header_name) or "").strip()
        if delivery_id:
            return delivery_id
    return hashlib.sha256(raw_body).hexdigest()


@router.post("")
@limiter.limit("30/minute")
async def handle_linear_webhook(request: Request) -> dict[str, Any]:
    """Handle Linear webhook events.

    Validates HMAC signature, routes assignment events to Zara intake,
    and returns acknowledgment.

    Returns:
        Acknowledgment with accepted status.
    """
    # --- Signature validation ---
    webhook_secret = _get_webhook_secret()
    if not webhook_secret:
        raise HTTPException(
            status_code=503,
            detail="LINEAR_WEBHOOK_SECRET not configured",
        )

    raw_body = await request.body()

    from apps.backend.services.connectors.linear_connector import LinearConnector

    connector_for_verify = LinearConnector(webhook_secret=webhook_secret)
    signature = request.headers.get("X-Linear-Signature")
    if not connector_for_verify.verify_webhook_signature(raw_body, signature):
        logger.warning("Linear webhook signature validation failed")
        raise HTTPException(status_code=401, detail="Invalid webhook signature")

    # --- Tenant resolution ---
    tenant_id = _get_default_tenant()
    if not tenant_id:
        raise HTTPException(status_code=400, detail="Missing tenant ID")

    delivery_id = _resolve_delivery_id(request, raw_body)
    dedupe_key = f"linear_webhook:{tenant_id}:{delivery_id}"

    # --- Deduplication ---
    duplicate = _get_delivery_store().check(dedupe_key)
    if duplicate.is_duplicate:
        cached_result = duplicate.cached_result or {}
        logger.info(
            "Linear webhook deduplicated: tenant=%s delivery_id=%s",
            tenant_id,
            delivery_id,
        )
        return {
            "accepted": bool(cached_result.get("accepted", False)),
            "duplicate": True,
        }

    # --- Parse payload ---
    try:
        payload: dict[str, Any] = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    logger.info(
        "Linear webhook received: action=%s type=%s tenant=%s",
        payload.get("action"),
        payload.get("type"),
        tenant_id,
    )

    # --- Route to connector ---
    linear_connector = _get_linear_connector(tenant_id)
    result = await linear_connector.route_assignment_to_zara(payload)

    # --- Check for comment events (Issue #3586) ---
    if not result.get("routed"):
        from apps.backend.services.connectors.linear_connector import LinearConnector

        comment = LinearConnector.detect_comment_event(payload)
        if comment is not None:
            comment_text = convert_to_markdown(
                comment.comment_body, comment.comment_body_format,
            )
            try:
                from apps.backend.services.zara.zara_intake_service import (
                    get_zara_intake_service,
                )

                intake = get_zara_intake_service()
                await intake.handle_inbound_pm_comment(
                    workspace_id=tenant_id,
                    source_provider=comment.source_provider,
                    external_id=comment.external_id,
                    comment_text=comment_text,
                    author_email=comment.author_email,
                    author_name=comment.author_name,
                    parent_issue_key=comment.parent_issue_key,
                )
            except Exception:
                logger.exception(
                    "Linear comment routing failed: tenant=%s issue=%s",
                    tenant_id,
                    comment.parent_issue_key,
                )

            _get_delivery_store().store(
                dedupe_key,
                {"accepted": True, "comment_routed": True},
            )
            return {
                "accepted": True,
                "comment_routed": True,
                "issue_id": comment.parent_issue_key,
                "comment_id": comment.external_id,
            }

    _get_delivery_store().store(
        dedupe_key,
        {"accepted": result.get("routed", False)},
    )

    return {
        "accepted": result.get("routed", False),
        "issue_id": result.get("issue_id"),
    }
