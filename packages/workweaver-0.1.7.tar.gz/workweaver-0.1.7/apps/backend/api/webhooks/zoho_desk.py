"""Zoho Desk webhook handler for bidirectional ticket sync and learning (P2.5).

Receives webhook notifications from Zoho Desk when tickets are
created, updated, or closed, and syncs changes back to the
Workweaver DynamoDB ticket system.

P2.5 Learning Loop: When a ticket status transitions to 'resolved' or 'closed',
extracts the resolution as a gotcha and stores it in WorkMemory for future
capability execution context enrichment.

Security:
- HMAC-SHA256 signature validation via ZOHO_DESK_WEBHOOK_SECRET env var.
- If secret is not configured, rejects requests before parsing or sync side effects.
- If secret IS configured but signature is missing/invalid, rejects with 401.
"""

from __future__ import annotations

import asyncio
import logging
import os
from typing import Any

from fastapi import APIRouter, HTTPException, Request

from apps.backend.models.support_ticket import (
    TicketPriority,
    TicketStatus,
    TicketUpdate,
)
from apps.backend.services.payment_event_resource_store import PaymentEventResourceStore
from apps.backend.services.desk_learning_loop import validate_desk_webhook_signature
from apps.backend.services.ticket_service import TicketService
from apps.backend.services.zoho.desk_adapter import parse_zoho_webhook
from apps.backend.services.zoho.webhook_service import get_zoho_webhook_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/webhooks/zoho-desk", tags=["webhooks"])


def _get_webhook_secret() -> str:
    """Get the HMAC secret for Zoho Desk webhook signature validation."""
    return (os.getenv("ZOHO_DESK_WEBHOOK_SECRET") or "").strip()


def _log_reconciliation_skip(
    *,
    reason: str,
    parsed: dict[str, Any],
    tenant_id: str | None,
) -> None:
    """Persist webhook skip outcomes for deterministic reconciliation."""
    resolved_tenant_id = str(tenant_id or parsed.get("tenant_id") or "TENANT#unknown").strip()
    if not resolved_tenant_id:
        resolved_tenant_id = "TENANT#unknown"

    try:
        PaymentEventResourceStore().store_atomic_fact(
            tenant_id=resolved_tenant_id,
            fact_type="support_webhook_reconciliation",
            fact_data={
                "reason": reason,
                "connector": "zoho_desk",
                "zoho_ticket_id": parsed.get("zoho_ticket_id"),
                "workweaver_ticket_id": parsed.get("workweaver_ticket_id"),
                "tenant_id": resolved_tenant_id,
                "status": parsed.get("status"),
                "priority": parsed.get("priority"),
            },
        )
    except Exception:
        logger.warning(
            "Failed to persist support webhook reconciliation marker",
            extra={"reason": reason, "tenant_id": resolved_tenant_id},
            exc_info=True,
        )


async def _try_close_orphaned_zoho_ticket(parsed: dict[str, Any]) -> None:
    """Attempt to close an orphaned Zoho Desk ticket when the WW ticket was deleted."""
    tenant_id = str(parsed.get("tenant_id") or "").strip()
    zoho_ticket_id = parsed.get("zoho_ticket_id", "")
    if not zoho_ticket_id or not tenant_id:
        return

    try:
        closed = await get_zoho_webhook_service().close_orphaned_desk_ticket(
            tenant_id=tenant_id,
            zoho_ticket_id=str(zoho_ticket_id),
        )
        if closed:
            logger.info(
                "Closed orphaned Zoho Desk ticket %s after WW deletion",
                zoho_ticket_id,
            )
    except Exception:
        logger.warning(
            "Failed to close orphaned Zoho Desk ticket %s",
            zoho_ticket_id,
            exc_info=True,
        )


@router.post("/ticket-update")
async def handle_ticket_update(request: Request) -> dict[str, Any]:
    """Handle Zoho Desk ticket update webhook.

    Zoho Desk sends webhooks when tickets are created, updated, or closed.
    This endpoint syncs those changes back to the Workweaver DynamoDB ticket system.

    Security: Validates HMAC-SHA256 signature when ZOHO_DESK_WEBHOOK_SECRET is set.

    Returns:
        Acknowledgment response.
    """
    # --- Signature validation (Weakness #3) ---
    webhook_secret = _get_webhook_secret()
    raw_body = await request.body()
    if not webhook_secret:
        logger.error("Zoho Desk webhook secret not configured; rejecting unsigned webhook")
        raise HTTPException(status_code=503, detail="Zoho Desk webhook secret not configured")

    signature = request.headers.get("X-Zoho-Webhook-Signature")
    if not validate_desk_webhook_signature(raw_body, signature, webhook_secret):
        logger.warning("Zoho Desk webhook signature validation failed")
        raise HTTPException(status_code=401, detail="Invalid webhook signature")

    try:
        payload: dict[str, Any] = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    logger.info("Received Zoho Desk webhook: %s", payload.get("eventType", "unknown"))

    parsed = parse_zoho_webhook(payload)
    tenant_id = str(parsed.get("tenant_id") or "").strip()
    delivery_receipt: dict[str, Any] | None = None

    if tenant_id:
        await get_zoho_webhook_service().ensure_connection_metadata(
            tenant_id=tenant_id,
            product_slug="zoho-desk",
            org_id=str(parsed.get("org_id") or "").strip() or None,
            portal_id=str(parsed.get("portal_id") or "").strip() or None,
            instance_id=str(parsed.get("instance_id") or "").strip() or None,
        )
        delivery_receipt = await get_zoho_webhook_service().ingest_inbound_delivery(
            tenant_id=tenant_id,
            product_slug="zoho-desk",
            entity_type="ticket",
            raw_payload=payload,
            parsed_payload=parsed,
            external_id=str(parsed.get("zoho_ticket_id") or "").strip() or None,
            occurred_at=str(parsed.get("updated_at") or "").strip() or None,
            actor_path="system.zoho_desk_webhook",
        )
        if delivery_receipt and delivery_receipt.get("deduplicated"):
            return {
                "status": "ok",
                "synced_ticket": parsed.get("workweaver_ticket_id", ""),
                "deduplicated": True,
                "event_id": delivery_receipt.get("event_id", ""),
                "evidence_id": delivery_receipt.get("evidence_id", ""),
            }

    if not parsed.get("workweaver_ticket_id"):
        logger.warning("Zoho webhook missing workweaver_ticket_id, skipping sync")
        _log_reconciliation_skip(reason="no_workweaver_ticket_id", parsed=parsed, tenant_id=parsed.get("tenant_id"))
        return {
            "status": "skipped",
            "reason": "no workweaver_ticket_id",
            "event_id": (delivery_receipt or {}).get("event_id", ""),
            "evidence_id": (delivery_receipt or {}).get("evidence_id", ""),
        }

    ticket_service = TicketService()
    ticket_id = str(parsed["workweaver_ticket_id"])
    existing = ticket_service.get_ticket(ticket_id)
    if not existing:
        logger.warning("Zoho webhook references unknown ticket id=%s", ticket_id)
        await _try_close_orphaned_zoho_ticket(parsed)
        _log_reconciliation_skip(reason="unknown_ticket", parsed=parsed, tenant_id=parsed.get("tenant_id"))
        return {
            "status": "skipped",
            "reason": "unknown_ticket",
            "event_id": (delivery_receipt or {}).get("event_id", ""),
            "evidence_id": (delivery_receipt or {}).get("evidence_id", ""),
        }

    parsed_tenant = str(parsed.get("tenant_id") or "").strip()
    if parsed_tenant and existing.tenant_id != parsed_tenant:
        logger.warning(
            "Zoho webhook tenant mismatch for ticket id=%s expected=%s actual=%s",
            ticket_id,
            existing.tenant_id,
            parsed_tenant,
        )
        _log_reconciliation_skip(reason="tenant_mismatch", parsed=parsed, tenant_id=existing.tenant_id)
        return {
            "status": "skipped",
            "reason": "tenant_mismatch",
            "event_id": (delivery_receipt or {}).get("event_id", ""),
            "evidence_id": (delivery_receipt or {}).get("evidence_id", ""),
        }

    status_value = str(parsed.get("status") or "").strip().lower()
    priority_value = str(parsed.get("priority") or "").strip().lower()

    update = TicketUpdate(
        status=TicketStatus(status_value) if status_value in {s.value for s in TicketStatus} else None,
        priority=TicketPriority(priority_value) if priority_value in {p.value for p in TicketPriority} else None,
    )
    ticket_service.update_ticket(
        ticket_id=ticket_id,
        request=update,
        agent_id="zoho_desk_webhook",
    )

    logger.info(
        "Synced Zoho ticket %s -> WW ticket %s (status: %s)",
        parsed["zoho_ticket_id"],
        parsed["workweaver_ticket_id"],
        parsed["status"],
    )

    # --- P2.5: Learning loop - extract gotcha from ticket resolution ---
    if status_value in ("resolved", "closed"):
        asyncio.create_task(_process_resolution_learning(parsed=parsed, tenant_id=existing.tenant_id))

    return {
        "status": "ok",
        "synced_ticket": parsed["workweaver_ticket_id"],
        "deduplicated": False,
        "event_id": (delivery_receipt or {}).get("event_id", ""),
        "evidence_id": (delivery_receipt or {}).get("evidence_id", ""),
    }


async def _process_resolution_learning(
    parsed: dict[str, Any],
    tenant_id: str,
) -> None:
    """Extract gotcha from Zoho Desk ticket resolution (P2.5 learning loop).

    Runs as fire-and-forget background task - failures are logged but
    never block the webhook response.
    """
    try:
        from apps.backend.services.desk_learning_loop import DeskLearningLoop
        from apps.backend.services.gotcha_service import GotchaService
        from apps.backend.services.memory.runtime import get_runtime

        wm = get_runtime()
        gotcha_svc = GotchaService(workmemory_client=wm)

        # Extract custom fields for capability/entity context
        ticket_data = parsed
        capability_id = str(ticket_data.get("capability_id") or "unknown")
        entity_id = str(ticket_data.get("entity_id") or "unknown")
        resolution_text = str(ticket_data.get("description") or "")
        zoho_ticket_id = str(ticket_data.get("zoho_ticket_id") or "")

        # The desk adapter is not needed for resolution processing
        # (we already have the parsed data from the webhook)
        loop = DeskLearningLoop(desk_adapter=None, gotcha_service=gotcha_svc)
        await loop.process_resolution(
            capability_id=capability_id,
            entity_id=entity_id,
            tenant_id=tenant_id,
            resolution_text=resolution_text,
            zoho_ticket_id=zoho_ticket_id,
        )
    except Exception as exc:
        logger.warning(
            "P2.5 resolution learning failed (non-blocking): %s",
            exc,
            exc_info=True,
        )
