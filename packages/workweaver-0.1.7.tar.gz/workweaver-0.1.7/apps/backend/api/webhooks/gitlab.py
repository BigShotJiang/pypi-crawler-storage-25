"""GitLab webhook handler for code ingest (PR-6.3).

Receives webhook notifications from GitLab when code events occur
(Push Hook, Merge Request Hook, Issue Hook, Note Hook, Repository Hook)
and ingests them into the evidence ledger.

Security:
- Token validation via X-Gitlab-Token header against GITLAB_WEBHOOK_SECRET env var.
- Requests fail closed if the secret is missing or invalid.
"""

from __future__ import annotations

import hashlib
import logging
import os
from typing import Any

from fastapi import APIRouter, HTTPException, Request

from apps.backend.api.rate_limit import limiter
from apps.backend.api.webhooks._shared import compare_webhook_secret
from apps.backend.services.evidence_ledger import get_evidence_ledger_service
from apps.backend.services.gitlab_ingest import GitLabIngestService
from apps.backend.services.idempotency import IdempotencyStore

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/webhooks/gitlab", tags=["webhooks"])
_delivery_store: IdempotencyStore | None = None


def _get_webhook_secret() -> str:
    """Get the token secret for GitLab webhook validation."""
    return (os.getenv("GITLAB_WEBHOOK_SECRET") or "").strip()


def _validate_webhook_token(
    token: str | None,
    secret: str,
) -> bool:
    """Validate GitLab webhook token.

    Args:
        token: X-Gitlab-Token header value.
        secret: Expected secret token.

    Returns:
        True if token is valid.
    """
    return compare_webhook_secret(token, secret)


def _get_default_tenant() -> str:
    """Get the default tenant for GitLab webhooks."""
    return (os.getenv("GITLAB_WEBHOOK_DEFAULT_TENANT") or "").strip()


def _resolve_tenant(request: Request) -> str:
    """Resolve tenant ID from trusted server configuration.

    Priority:
    1. GITLAB_WEBHOOK_DEFAULT_TENANT env var

    Raises:
        HTTPException: If tenant cannot be resolved.
    """
    default_tenant = _get_default_tenant()
    if default_tenant:
        return default_tenant

    raise HTTPException(status_code=400, detail="Missing tenant ID")


def _get_gitlab_ingest_service() -> GitLabIngestService:
    """Get the GitLab ingest service singleton."""
    from apps.backend.services.gitlab_ingest import get_gitlab_ingest_service

    return get_gitlab_ingest_service()


def _get_delivery_store() -> IdempotencyStore:
    global _delivery_store  # noqa: PLW0603
    if _delivery_store is None:
        _delivery_store = IdempotencyStore()
    return _delivery_store


def _resolve_delivery_id(request: Request, raw_body: bytes) -> str:
    for header_name in ("X-Gitlab-Event-UUID", "X-Gitlab-Delivery", "X-Request-Id"):
        delivery_id = str(request.headers.get(header_name) or "").strip()
        if delivery_id:
            return delivery_id
    return hashlib.sha256(raw_body).hexdigest()


@router.post("")
@limiter.limit("30/minute")
async def handle_gitlab_webhook(request: Request) -> dict[str, Any]:
    """Handle GitLab webhook events.

    Validates token (if configured), extracts event type from
    X-Gitlab-Event header, and routes to the GitLabIngestService.

    Returns:
        Acknowledgment with count of ingested entities and event type.
    """
    # --- Token validation ---
    webhook_secret = _get_webhook_secret()
    if not webhook_secret:
        raise HTTPException(status_code=503, detail="GITLAB_WEBHOOK_SECRET not configured")

    token = request.headers.get("X-Gitlab-Token")
    if not _validate_webhook_token(token, webhook_secret):
        logger.warning("GitLab webhook token validation failed")
        raise HTTPException(status_code=401, detail="Invalid webhook token")

    # --- Event type validation ---
    event_type = request.headers.get("X-Gitlab-Event")
    if not event_type:
        raise HTTPException(status_code=400, detail="Missing X-Gitlab-Event header")

    # --- Tenant resolution ---
    tenant_id = _resolve_tenant(request)
    raw_body = await request.body()
    delivery_id = _resolve_delivery_id(request, raw_body)
    dedupe_key = f"gitlab_webhook:{tenant_id}:{delivery_id}"

    duplicate = _get_delivery_store().check(dedupe_key)
    if duplicate.is_duplicate:
        cached_result = duplicate.cached_result or {}
        logger.info(
            "GitLab webhook deduplicated: event_type=%s tenant=%s delivery_id=%s",
            event_type,
            tenant_id,
            delivery_id,
        )
        return {
            "accepted": int(cached_result.get("accepted", 0)),
            "event_type": str(cached_result.get("event_type") or event_type),
            "duplicate": True,
        }

    # --- Parse payload ---
    try:
        payload: dict[str, Any] = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    logger.info(
        "GitLab webhook received: event_type=%s tenant=%s",
        event_type,
        tenant_id,
    )

    # --- Route to ingest service ---
    ingest_service = _get_gitlab_ingest_service()
    entities = ingest_service.route_event(tenant_id, event_type, payload)

    # --- Write each entity to evidence ledger ---
    evidence_service = get_evidence_ledger_service()
    for entity in entities:
        try:
            evidence_service.ingest(
                tenant_id=entity.tenant_id,
                event_type=entity.entity_type,
                data=entity.fields,
                capture_surface="gitlab_webhook",
                service_family="code",
                source_event_id=entity.entity_id,
            )
        except Exception:
            logger.exception(
                "Failed to ingest entity %s into evidence ledger",
                entity.entity_id,
            )

    logger.info(
        "GitLab webhook processed: event_type=%s accepted=%d",
        event_type,
        len(entities),
    )

    _get_delivery_store().store(
        dedupe_key,
        {
            "accepted": len(entities),
            "event_type": event_type,
        },
    )

    return {
        "accepted": len(entities),
        "event_type": event_type,
    }
