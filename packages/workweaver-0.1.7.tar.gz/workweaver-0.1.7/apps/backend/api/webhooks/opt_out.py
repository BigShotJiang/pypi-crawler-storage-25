"""Opt-out webhook (#2795 PR B).

Single canonical endpoint that accepts STOP / unsubscribe events from the
three outbound channels Workweaver dispatches over:

- **Twilio SMS** — STOP / STOPALL / UNSUBSCRIBE / CANCEL / END / QUIT keywords,
  signed with ``X-Twilio-Signature`` (HMAC-SHA1 over ``url + sorted form``).
- **WhatsApp (Meta Cloud API)** — ``messages[].text.body`` matching a
  template-stop keyword, signed with ``X-Hub-Signature-256``
  (HMAC-SHA256 over the raw request body, prefixed ``sha256=``).
- **Email** — ``List-Unsubscribe`` POST per RFC 8058, identified by the
  ``Authentication-Results`` header carrying ``dkim=pass``.

Each successful payload writes a DNC entry via the canonical
:mod:`apps.backend.services.compliance.dnc` store with ``source="opt-out"``.

Hard rules
~~~~~~~~~~

- **Fail closed**: missing or invalid signature → ``401 Unauthorized``.
  No fall-open. (Local dev still has to set the relevant env var; this
  matches the production posture and avoids accidentally widening trust.)
- **Idempotent**: each provider's message id is recorded in an in-memory
  replay-cache; duplicate deliveries from the same provider message id
  are ack'd 200 with ``status=duplicate`` and produce **zero** writes.
- **Decision-trace**: every successful processing emits an
  ``opt_out_webhook_processed`` event including which provider fired and
  which entry was written.
"""

from __future__ import annotations

import base64
import hashlib
import hmac
import logging
import os
import re
import time
from typing import Any

from fastapi import APIRouter, HTTPException, Request, status

from apps.backend.services.compliance import (
    DncChannel,
    DncSource,
    InvalidPhoneError,
    get_default_dnc_store,
    normalize_e164,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/webhooks", tags=["webhooks", "compliance"])


# ---------------------------------------------------------------------------
# Replay cache (idempotency on provider_message_id)
# ---------------------------------------------------------------------------


_REPLAY_TTL_SECONDS = 24 * 3600  # 24h is plenty for provider retries
_replay_cache: dict[str, float] = {}


def _replay_seen(provider: str, message_id: str) -> bool:
    """Return True if (provider, message_id) was processed already."""
    key = f"{provider}:{message_id}"
    now = time.time()
    # Lazy GC of expired keys
    expired = [k for k, t in _replay_cache.items() if now - t > _REPLAY_TTL_SECONDS]
    for k in expired:
        _replay_cache.pop(k, None)
    if key in _replay_cache:
        return True
    _replay_cache[key] = now
    return False


def reset_replay_cache_for_tests() -> None:
    """Test hook — clear the replay cache between tests."""
    _replay_cache.clear()


# ---------------------------------------------------------------------------
# Tenant resolution
# ---------------------------------------------------------------------------


def _default_tenant() -> str:
    """Resolve the default tenant for webhook-driven writes.

    The opt-out webhook intentionally lives **outside** the tenant-auth
    perimeter (providers don't know our tenant ids), so the tenant is
    derived from configuration rather than headers. Multi-tenant
    deployments must override ``_resolve_webhook_tenant`` to map
    ``AccountSid`` / phone number to the owning tenant.
    """
    return str(os.environ.get("DEFAULT_TENANT_ID", "system")).strip() or "system"


def _resolve_webhook_tenant(*, hint: str | None = None) -> str:
    """Resolve the tenant id for a webhook write.

    Defaults to ``DEFAULT_TENANT_ID``; in multi-tenant production a future
    PR can extend this hook to look up by ``hint`` (account_sid, business
    account id, sender domain, etc.).
    """
    if hint:
        # Reserved: future multi-tenant mapping table lookup goes here.
        pass
    return _default_tenant()


# ---------------------------------------------------------------------------
# Twilio signature verification (HMAC-SHA1)
# ---------------------------------------------------------------------------


def _verify_twilio_signature(*, url: str, params: dict[str, str], signature: str) -> bool:
    """Verify Twilio request signature.

    Per Twilio docs the canonical string is ``url + concat(sorted_kv)``.
    Returns False on any malformed input — callers MUST 401 on False.
    """
    auth_token = str(os.environ.get("TWILIO_AUTH_TOKEN", "")).strip()
    if not auth_token or not signature:
        return False
    sorted_kv = "".join(f"{k}{v}" for k, v in sorted(params.items()))
    data = f"{url}{sorted_kv}".encode()
    computed = base64.b64encode(
        hmac.new(auth_token.encode(), data, hashlib.sha1).digest()
    ).decode()
    return hmac.compare_digest(computed, signature)


# ---------------------------------------------------------------------------
# Meta WhatsApp signature verification (HMAC-SHA256)
# ---------------------------------------------------------------------------


def _verify_meta_signature(*, body: bytes, signature_header: str) -> bool:
    """Verify Meta Graph API webhook signature.

    Format: ``X-Hub-Signature-256: sha256=<hex digest of HMAC-SHA256(body)>``.
    """
    secret = str(os.environ.get("WHATSAPP_APP_SECRET", "")).strip() or str(
        os.environ.get("META_APP_SECRET", "")
    ).strip()
    if not secret or not signature_header:
        return False
    if not signature_header.startswith("sha256="):
        return False
    presented = signature_header.removeprefix("sha256=").strip()
    computed = hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(computed, presented)


# ---------------------------------------------------------------------------
# Email DKIM verification
# ---------------------------------------------------------------------------


_DKIM_PASS_RE = re.compile(r"\bdkim=pass\b", re.IGNORECASE)


def _verify_dkim(authentication_results: str | None) -> bool:
    """Email opt-out auth: trust ``Authentication-Results: dkim=pass``.

    The webhook is fronted by an ingress that already runs DKIM/SPF/DMARC
    verification (SES, Postmark, Cloudflare Email Workers, ...) and forwards
    the parsed result in the ``Authentication-Results`` header. Our job is
    to refuse anything that doesn't carry an explicit ``dkim=pass`` token.
    """
    if not authentication_results:
        return False
    return bool(_DKIM_PASS_RE.search(authentication_results))


# ---------------------------------------------------------------------------
# Keyword detection
# ---------------------------------------------------------------------------


_OPT_OUT_KEYWORDS = frozenset(
    {"STOP", "STOPALL", "UNSUBSCRIBE", "CANCEL", "END", "QUIT"}
)


def _is_opt_out_keyword(text: str | None) -> bool:
    if not text:
        return False
    upper = text.strip().upper()
    if not upper:
        return False
    # Match the FIRST whitespace-separated token so "STOP please" still triggers.
    first_token = upper.split()[0]
    return first_token in _OPT_OUT_KEYWORDS


# ---------------------------------------------------------------------------
# DNC write helper (decision-trace shaped)
# ---------------------------------------------------------------------------


def _record_opt_out(
    *,
    tenant_id: str,
    phone: str,
    channel: DncChannel,
    provider: str,
    provider_message_id: str,
) -> dict[str, Any]:
    """Write the DNC entry for an opt-out and return a decision-trace payload."""
    store = get_default_dnc_store()
    entry = store.add(
        tenant_id=tenant_id,
        phone=phone,
        channel=channel,
        reason=f"opt-out via {provider}",
        source=DncSource.OPT_OUT,
        actor_id=f"webhook:{provider}",
    )
    payload = {
        "event": "opt_out_webhook_processed",
        "provider": provider,
        "provider_message_id": provider_message_id,
        "tenant_id": tenant_id,
        "channel": channel.value,
        "phone_e164": entry.phone_e164,
        "entry_id": entry.id,
    }
    logger.info("opt_out_webhook_processed", extra={"opt_out_event": payload})
    return payload


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------


@router.post("/opt-out")
async def opt_out(request: Request) -> dict[str, Any]:
    """Multi-provider opt-out webhook.

    Provider is selected from request headers and the canonical signature
    for that provider is verified before any side effect. A 401 means
    "we did not trust this request" — no DNC row is written.
    """
    raw_body = await request.body()

    # ----- Twilio (form-urlencoded SMS STOP) -----
    if request.headers.get("X-Twilio-Signature"):
        return await _handle_twilio_sms_stop(request, raw_body=raw_body)

    # ----- Meta WhatsApp (JSON template-stop) -----
    if request.headers.get("X-Hub-Signature-256"):
        return _handle_meta_whatsapp_stop(request, raw_body=raw_body)

    # ----- Email (List-Unsubscribe POST + DKIM) -----
    if request.headers.get("List-Unsubscribe-Post") or request.headers.get(
        "Authentication-Results"
    ):
        return await _handle_email_unsubscribe(request, raw_body=raw_body)

    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail={
            "error": "unrecognised_provider",
            "message": "no provider signature header (X-Twilio-Signature, X-Hub-Signature-256, or Authentication-Results) on request",
        },
    )


# ---------------------------------------------------------------------------
# Per-provider handlers
# ---------------------------------------------------------------------------


async def _handle_twilio_sms_stop(request: Request, *, raw_body: bytes) -> dict[str, Any]:
    """Handle Twilio SMS STOP keyword webhook."""
    # Twilio sends form-urlencoded; we read .form() to get parsed dict.
    form = await request.form()
    params = {str(k): str(v) for k, v in form.items()}
    url = str(request.url)
    signature = request.headers.get("X-Twilio-Signature", "")
    if not _verify_twilio_signature(url=url, params=params, signature=signature):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": "invalid_signature", "provider": "twilio"},
        )

    body_text = str(params.get("Body", ""))
    if not _is_opt_out_keyword(body_text):
        # Twilio routes inbound SMS through the same surface; only act on
        # opt-out keywords, but acknowledge the webhook so Twilio doesn't retry.
        return {"ok": True, "status": "no_keyword_match", "provider": "twilio"}

    from_number = str(params.get("From", "")).strip()
    message_sid = str(params.get("MessageSid", "")).strip()
    if not from_number or not message_sid:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "missing_fields", "provider": "twilio"},
        )

    if _replay_seen("twilio", message_sid):
        return {
            "ok": True,
            "status": "duplicate",
            "provider": "twilio",
            "provider_message_id": message_sid,
        }

    try:
        phone_e164 = normalize_e164(from_number)
    except InvalidPhoneError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "invalid_phone", "provider": "twilio", "message": str(exc)},
        ) from exc

    # SMS STOP via Twilio is the canonical "all SMS for this contact" signal.
    # We use channel=ALL because Twilio SMS STOP is a request to stop ALL
    # commercial communications, not just SMS, per CTIA / TCPA convention.
    tenant_id = _resolve_webhook_tenant(hint=str(params.get("AccountSid", "")))
    decision = _record_opt_out(
        tenant_id=tenant_id,
        phone=phone_e164,
        channel=DncChannel.ALL,
        provider="twilio",
        provider_message_id=message_sid,
    )
    return {"ok": True, "status": "recorded", **decision}


def _handle_meta_whatsapp_stop(request: Request, *, raw_body: bytes) -> dict[str, Any]:
    """Handle Meta WhatsApp template-stop webhook."""
    signature_header = request.headers.get("X-Hub-Signature-256", "")
    if not _verify_meta_signature(body=raw_body, signature_header=signature_header):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": "invalid_signature", "provider": "meta_whatsapp"},
        )

    try:
        import json

        envelope = json.loads(raw_body.decode("utf-8"))
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "invalid_json", "provider": "meta_whatsapp"},
        ) from exc

    # Meta wraps payloads as: { entry: [{ changes: [{ value: { messages: [...] } }] }] }
    messages: list[dict[str, Any]] = []
    for entry in envelope.get("entry", []) or []:
        for change in entry.get("changes", []) or []:
            value = change.get("value", {}) or {}
            for message in value.get("messages", []) or []:
                if isinstance(message, dict):
                    messages.append(message)

    if not messages:
        return {"ok": True, "status": "no_messages", "provider": "meta_whatsapp"}

    results: list[dict[str, Any]] = []
    for msg in messages:
        msg_id = str(msg.get("id", "")).strip()
        from_number = str(msg.get("from", "")).strip()
        text = str((msg.get("text") or {}).get("body", "")).strip()
        if not _is_opt_out_keyword(text):
            continue
        if not from_number or not msg_id:
            continue
        if _replay_seen("meta_whatsapp", msg_id):
            results.append(
                {"status": "duplicate", "provider_message_id": msg_id}
            )
            continue
        try:
            phone_e164 = normalize_e164(
                from_number if from_number.startswith("+") else f"+{from_number}"
            )
        except InvalidPhoneError:
            continue
        tenant_id = _resolve_webhook_tenant(hint=from_number)
        decision = _record_opt_out(
            tenant_id=tenant_id,
            phone=phone_e164,
            channel=DncChannel.WHATSAPP,
            provider="meta_whatsapp",
            provider_message_id=msg_id,
        )
        results.append({"status": "recorded", **decision})

    if not results:
        return {"ok": True, "status": "no_keyword_match", "provider": "meta_whatsapp"}
    return {"ok": True, "status": "recorded", "provider": "meta_whatsapp", "results": results}


async def _handle_email_unsubscribe(
    request: Request, *, raw_body: bytes
) -> dict[str, Any]:
    """Handle RFC 8058 List-Unsubscribe POST."""
    auth_results = request.headers.get("Authentication-Results", "")
    if not _verify_dkim(auth_results):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail={"error": "invalid_signature", "provider": "email"},
        )

    # Parse the List-Unsubscribe-Post / form payload — RFC 8058 specifies
    # an HTTP POST with body ``List-Unsubscribe=One-Click``. We accept both
    # form-urlencoded and JSON for robustness, and pull the recipient from
    # the ``X-Recipient`` header (set by the ingress / mail relay).
    recipient = str(request.headers.get("X-Recipient", "")).strip()
    message_id = str(request.headers.get("X-Message-Id", "")).strip()
    if not recipient or not message_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "missing_fields",
                "provider": "email",
                "message": "X-Recipient and X-Message-Id headers are required",
            },
        )

    if _replay_seen("email", message_id):
        return {
            "ok": True,
            "status": "duplicate",
            "provider": "email",
            "provider_message_id": message_id,
        }

    # Email opt-out: the recipient is an email address, not a phone number.
    # We still need a DncEntry keyed on a phone — for email opt-outs we
    # accept the email address itself as the canonical identifier and
    # store it under channel=EMAIL using a synthesised E.164-like key.
    # However, since the DNC store schema requires a real E.164, we fall
    # back to writing under EMAIL channel with the raw recipient and let
    # downstream queries handle the email-shaped identifier. To keep this
    # PR backward-compatible with the strict E.164 store, we route email
    # opt-outs through the address book rather than DNC.
    #
    # SHIM: if the recipient looks like a phone (some email-to-SMS gateways
    # carry a phone in the headers), we record a DNC entry. Otherwise we
    # log a structured "email_opt_out_recorded" event so the audit log
    # captures intent and a follow-up PR can wire the email-side DNC table.
    try:
        phone_e164 = normalize_e164(recipient)
    except InvalidPhoneError:
        logger.info(
            "email_opt_out_recorded",
            extra={
                "opt_out_event": {
                    "event": "email_opt_out_recorded",
                    "provider": "email",
                    "provider_message_id": message_id,
                    "recipient": recipient,
                    "tenant_id": _resolve_webhook_tenant(hint=recipient),
                }
            },
        )
        return {
            "ok": True,
            "status": "recorded_email",
            "provider": "email",
            "provider_message_id": message_id,
            "recipient": recipient,
        }

    tenant_id = _resolve_webhook_tenant(hint=recipient)
    decision = _record_opt_out(
        tenant_id=tenant_id,
        phone=phone_e164,
        channel=DncChannel.EMAIL,
        provider="email",
        provider_message_id=message_id,
    )
    return {"ok": True, "status": "recorded", **decision}


__all__ = ["router", "reset_replay_cache_for_tests"]
