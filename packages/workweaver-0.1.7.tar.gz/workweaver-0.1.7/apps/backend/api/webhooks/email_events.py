"""Email delivery events webhook (bounce/complaint/open/click ingestion).

Extends base delivery guard processing (L6.2) with:
- open/click event type support
- CadenceService signal routing for open/click (engagement tracking)
- SendTimeOptimizer updates for email_opened/link_clicked learning signals
"""

from __future__ import annotations

import logging
from datetime import datetime, UTC
from typing import Any, Literal

from fastapi import APIRouter, Header, HTTPException, Request, status
from pydantic import BaseModel, Field

from apps.backend.api.rate_limit import limiter
from apps.backend.api.webhooks._shared import compare_webhook_secret, tenant_scoped_secret
from apps.backend.services.delivery_guard import get_delivery_guard

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/webhooks/email", tags=["webhooks"])

_ALLOWED_EVENT_TYPES = {"send", "sent", "accepted", "delivered", "bounce", "complaint", "open", "click"}

# Events routed as cadence engagement signals (not suppression triggers)
_ENGAGEMENT_EVENT_TYPES = {"open", "click"}


class EmailDeliveryEvent(BaseModel):
    """Single normalized email delivery event."""

    tenant_id: str = Field(default="", description="Tenant identifier")
    recipient: str = Field(..., description="Recipient email")
    event_type: Literal["send", "sent", "accepted", "delivered", "bounce", "complaint", "open", "click"]
    sender: str | None = Field(default=None, description="Sender identity/domain")
    provider: str | None = Field(default=None, description="Delivery provider")
    provider_message_id: str | None = Field(default=None, description="Provider message id")
    # message_id is a convenience alias accepted from external webhook payloads
    message_id: str | None = Field(default=None, description="Message id (alias for provider_message_id)")
    reason: str | None = Field(default=None, description="Provider-specific reason")
    timestamp: str | None = Field(default=None, description="Event timestamp (ISO-8601)")
    # Engagement tracking fields for open/click events
    campaign_id: str | None = Field(default=None, description="Cadence campaign id for signal routing")
    lead_id: str | None = Field(default=None, description="Lead id for cadence signal routing")
    click_url: str | None = Field(default=None, description="URL clicked (for click events)")
    metadata: dict[str, Any] = Field(default_factory=dict)


class EmailDeliveryEventsRequest(BaseModel):
    """Batch ingestion request for email delivery events."""

    events: list[EmailDeliveryEvent] = Field(default_factory=list)


class EmailDeliveryEventsResponse(BaseModel):
    """Ingestion summary response."""

    accepted: int
    dropped: int


def _extract_event_hour(event: EmailDeliveryEvent) -> tuple[int, int]:
    """Extract UTC hour and day-of-week from event timestamp or current time."""
    ts_str = event.timestamp
    if ts_str:
        try:
            # Parse ISO-8601; handle Z suffix
            ts_str = ts_str.replace("Z", "+00:00")
            dt = datetime.fromisoformat(ts_str)
            if dt.tzinfo is None:
                dt = dt.replace(tzinfo=UTC)
            return dt.hour, dt.weekday()
        except (ValueError, TypeError):
            pass
    now = datetime.now(UTC)
    return now.hour, now.weekday()


def _get_tenant_webhook_secret(tenant_id: str) -> str | None:
    """Get tenant-scoped webhook secret from env pattern TENANT_EMAIL_WEBHOOK_SECRET_{tenant_id}."""
    return tenant_scoped_secret(tenant_id, "TENANT_EMAIL_WEBHOOK_SECRET_")


def _validate_webhook_token_with_tenant(
    x_webhook_token: str | None,
    tenant_id: str,
) -> None:
    """Validate webhook token with tenant-scoped secrets only."""
    provided_token = str(x_webhook_token or "").strip()
    if not provided_token:
        logger.warning("webhook_auth_failed: missing token tenant=%s", tenant_id)
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized webhook token")

    tenant_secret = _get_tenant_webhook_secret(tenant_id)
    if not tenant_secret:
        logger.error("webhook_auth_failed: missing_tenant_secret tenant=%s", tenant_id)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Tenant email webhook secret not configured",
        )

    if compare_webhook_secret(provided_token, tenant_secret):
        logger.info("webhook_auth_success: tenant_scoped tenant=%s", tenant_id)
        return

    logger.warning("webhook_auth_failed: invalid_token tenant=%s", tenant_id)
    raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Unauthorized webhook token")


@router.post("/events", response_model=EmailDeliveryEventsResponse)
@limiter.limit("30/minute")
async def ingest_email_events(
    request: Request,
    body: EmailDeliveryEventsRequest,
    x_webhook_token: str | None = Header(default=None, alias="x-webhook-token"),
) -> EmailDeliveryEventsResponse:
    """Ingest delivery events and update delivery controls.

    This endpoint is provider-agnostic; SES SNS payload normalization can happen upstream.

    L6.2: open/click events are routed to CadenceService as engagement signals
    and to SendTimeOptimizer for per-prospect send-time learning.
    """
    if not body.events:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="events must not be empty")

    tenant_ids = {str(event.tenant_id or "").strip() for event in body.events}
    if "" in tenant_ids or len(tenant_ids) != 1:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail="All email events must share one tenant")

    first_tenant = next(iter(tenant_ids))
    _validate_webhook_token_with_tenant(x_webhook_token, first_tenant)

    guard = get_delivery_guard()
    accepted = 0
    dropped = 0

    for event in body.events:
        event_type = str(event.event_type or "").strip().lower()
        if event_type not in _ALLOWED_EVENT_TYPES:
            dropped += 1
            continue

        resolved_message_id = event.provider_message_id or event.message_id or ""

        try:
            # All events feed delivery guard for health/pacing telemetry.
            # open/click don't affect bounce/complaint counters but still record send cadence.
            guard.record_outcome(
                tenant_id=event.tenant_id,
                channel="email",
                sender=event.sender,
                recipient=event.recipient,
                outcome=event_type,
                source="/api/v1/webhooks/email/events",
                actor="email_events_webhook",
                metadata={
                    "provider": event.provider or "",
                    "provider_message_id": resolved_message_id,
                    "reason": event.reason or "",
                    **(event.metadata or {}),
                },
            )

            # L6.2: Route open/click to CadenceService signal + SendTimeOptimizer
            if event_type in _ENGAGEMENT_EVENT_TYPES and event.tenant_id and event.campaign_id and event.lead_id:
                await _handle_engagement_event(event, event_type)

            accepted += 1
        except Exception:
            logger.warning("Failed to process email delivery event", exc_info=True)
            dropped += 1

    return EmailDeliveryEventsResponse(accepted=accepted, dropped=dropped)


async def _handle_engagement_event(event: EmailDeliveryEvent, event_type: str) -> None:
    """Route open/click engagement events to CadenceService and SendTimeOptimizer.

    L6.2: feeds engagement signals into cadence branching and send-time learning.
    """
    tenant_id = event.tenant_id
    campaign_id = event.campaign_id
    lead_id = event.lead_id

    # Feed CadenceService as a signal (non-suppression — open/click signals
    # allow cadence branches to route on engagement rather than just reply/bounce)
    try:
        from apps.backend.services.scheduling.cadence_service import CadenceService

        svc = CadenceService()
        cadence_signal = "email_opened" if event_type == "open" else "link_clicked"
        # record_engagement_signal is a lightweight signal that doesn't suppress
        await svc.record_engagement_signal(
            tenant_id=tenant_id,
            campaign_id=campaign_id,
            lead_id=lead_id,
            signal_type=cadence_signal,
            metadata={
                "event_type": event_type,
                "click_url": event.click_url or "",
                "recipient": event.recipient,
            },
        )
    except Exception:
        logger.warning(
            "Failed to route %s signal to CadenceService for campaign=%s lead=%s",
            event_type,
            campaign_id,
            lead_id,
            exc_info=True,
        )

    # Feed SendTimeOptimizer for per-prospect engagement window learning
    try:
        from apps.backend.services.send_time_optimizer import get_send_time_optimizer

        hour_utc, day_of_week = _extract_event_hour(event)
        optimizer = get_send_time_optimizer()
        optimizer.record_engagement(
            tenant_id=tenant_id,
            contact_id=lead_id,
            event_type=event_type,
            hour_utc=hour_utc,
            day_of_week=day_of_week,
        )
    except Exception:
        logger.warning(
            "Failed to record send-time engagement for %s/%s",
            tenant_id,
            lead_id,
            exc_info=True,
        )
