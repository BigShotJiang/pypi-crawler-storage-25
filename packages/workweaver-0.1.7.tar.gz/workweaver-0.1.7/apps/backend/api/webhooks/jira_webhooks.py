"""JIRA webhook handler for assignment-to-Zara routing.

Issue #2780: JIRA assignment webhook to Zara intake.

Receives webhook notifications from JIRA when issue events occur and
routes assignment events to Zara intake for processing.

Security:
- HMAC-SHA256 signature validation via JIRA_WEBHOOK_SECRET env var.
- Requests fail closed if the secret is missing or invalid.
"""

from __future__ import annotations

import hashlib
import logging
import os
from typing import Any

from fastapi import APIRouter, HTTPException, Request

from apps.backend.api.rate_limit import limiter
from apps.backend.api.webhooks._shared import compare_webhook_secret
from apps.backend.services.connectors.jira_connector import (
    detect_assignment_event,
    detect_comment_event,
)
from apps.backend.services.connectors.markup_converter import convert_to_markdown
from apps.backend.services.idempotency import IdempotencyStore

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/webhooks/jira", tags=["webhooks"])
_delivery_store: IdempotencyStore | None = None


def _get_webhook_secret() -> str:
    """Get the HMAC secret for JIRA webhook signature validation."""
    return (os.getenv("JIRA_WEBHOOK_SECRET") or "").strip()


def _get_default_tenant() -> str:
    """Get the default tenant for JIRA webhooks."""
    return (os.getenv("JIRA_WEBHOOK_DEFAULT_TENANT") or "").strip()


def _resolve_tenant(request: Request) -> str:
    """Resolve tenant ID from trusted server configuration.

    Priority:
    1. JIRA_WEBHOOK_DEFAULT_TENANT env var

    Raises:
        HTTPException: If tenant cannot be resolved.
    """
    default_tenant = _get_default_tenant()
    if default_tenant:
        return default_tenant

    raise HTTPException(status_code=400, detail="Missing tenant ID")


def _get_delivery_store() -> IdempotencyStore:
    global _delivery_store  # noqa: PLW0603
    if _delivery_store is None:
        _delivery_store = IdempotencyStore()
    return _delivery_store


def _resolve_delivery_id(request: Request, raw_body: bytes) -> str:
    for header_name in ("X-Request-Id", "X-JIRA-Webhook-ID"):
        delivery_id = str(request.headers.get(header_name) or "").strip()
        if delivery_id:
            return delivery_id
    return hashlib.sha256(raw_body).hexdigest()


def _validate_webhook_signature(
    body: bytes,
    signature: str | None,
    secret: str,
) -> bool:
    """Validate HMAC-SHA256 signature of the webhook request body.

    Args:
        body: Raw request body bytes.
        signature: X-Hub-Signature-256 header value (format: sha256=<hex>).
        secret: HMAC secret key.

    Returns:
        True if signature is valid.
    """
    if not signature:
        return False
    if not signature.startswith("sha256="):
        return False

    import hmac as hmac_mod

    expected = "sha256=" + hmac_mod.new(
        secret.encode(), body, hashlib.sha256
    ).hexdigest()
    return compare_webhook_secret(signature, expected)


@router.post("")
@limiter.limit("30/minute")
async def handle_jira_webhook(request: Request) -> dict[str, Any]:
    """Handle JIRA webhook events.

    Validates HMAC signature, extracts event type from webhookEvent field,
    and routes assignment events to Zara intake.

    Returns:
        Acknowledgment with routing status and event type.
    """
    # --- Signature validation ---
    webhook_secret = _get_webhook_secret()
    if not webhook_secret:
        raise HTTPException(status_code=503, detail="JIRA_WEBHOOK_SECRET not configured")

    raw_body = await request.body()

    signature = request.headers.get("X-Hub-Signature-256")
    if not _validate_webhook_signature(raw_body, signature, webhook_secret):
        logger.warning("JIRA webhook signature validation failed")
        raise HTTPException(status_code=401, detail="Invalid webhook signature")

    # --- Tenant resolution ---
    tenant_id = _resolve_tenant(request)
    delivery_id = _resolve_delivery_id(request, raw_body)
    dedupe_key = f"jira_webhook:{tenant_id}:{delivery_id}"

    duplicate = _get_delivery_store().check(dedupe_key)
    if duplicate.is_duplicate:
        cached_result = duplicate.cached_result or {}
        logger.info(
            "JIRA webhook deduplicated: tenant=%s delivery_id=%s",
            tenant_id,
            delivery_id,
        )
        return {
            "status": str(cached_result.get("status", "duplicate")),
            "event_type": str(cached_result.get("event_type") or ""),
            "duplicate": True,
        }

    # --- Parse payload ---
    try:
        payload: dict[str, Any] = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    event_type = str(payload.get("webhookEvent", ""))

    logger.info(
        "JIRA webhook received: event_type=%s tenant=%s",
        event_type,
        tenant_id,
    )

    # --- Route assignment events to Zara ---
    assignment = detect_assignment_event(payload)
    if assignment is None:
        # --- Check for comment events (Issue #3586) ---
        comment = detect_comment_event(payload)
        if comment is not None:
            comment_text = convert_to_markdown(
                comment.comment_body, comment.comment_body_format,
            )
            try:
                from apps.backend.services.zara.zara_intake_service import (
                    get_zara_intake_service,
                )

                intake = get_zara_intake_service()
                await intake.handle_inbound_pm_comment(
                    workspace_id=tenant_id,
                    source_provider=comment.source_provider,
                    external_id=comment.external_id,
                    comment_text=comment_text,
                    author_email=comment.author_email,
                    author_name=comment.author_name,
                    parent_issue_key=comment.parent_issue_key,
                )
            except Exception:
                logger.exception(
                    "JIRA comment routing failed: tenant=%s issue=%s",
                    tenant_id,
                    comment.parent_issue_key,
                )
                raise HTTPException(status_code=500, detail="Comment routing failed")

            _get_delivery_store().store(
                dedupe_key,
                {"status": "comment_routed", "event_type": event_type},
            )
            return {
                "status": "comment_routed",
                "event_type": event_type,
                "issue_key": comment.parent_issue_key,
                "comment_id": comment.external_id,
            }

        _get_delivery_store().store(
            dedupe_key,
            {"status": "ignored", "event_type": event_type},
        )
        return {
            "status": "ignored",
            "event_type": event_type,
        }

    # Route to Zara intake via JIRAConnector
    from apps.backend.services.connectors.base import ConnectorConfig
    from apps.backend.services.connectors.jira_connector import JIRAConnector

    connector = JIRAConnector(
        ConnectorConfig(
            provider="jira",
            tenant_id=tenant_id,
            credentials={"webhook_secret": webhook_secret},
            base_url="",
        ),
    )

    try:
        result = await connector.route_assignment_to_zara(payload)
    except Exception:
        logger.exception(
            "JIRA assignment routing failed: tenant=%s issue=%s",
            tenant_id,
            assignment.issue_key,
        )
        raise HTTPException(status_code=500, detail="Routing failed")

    _get_delivery_store().store(
        dedupe_key,
        {"status": result.get("status", "routed"), "event_type": event_type},
    )

    return {
        "status": result.get("status", "routed"),
        "event_type": event_type,
        "issue_key": assignment.issue_key,
    }
