"""Canonical webhook ingress for external orchestration.

SECURITY: Tokens are validated against tenant-scoped secrets only.
Unsupported sources and unauthenticated requests fail closed.
"""

from __future__ import annotations

import datetime
import hashlib
import json
import logging
from typing import Any

from fastapi import APIRouter, Header, HTTPException, Request, status
from pydantic import BaseModel, ConfigDict, Field, field_validator

from apps.backend.api.rate_limit import limiter
from apps.backend.api.webhooks._shared import compare_webhook_secret, tenant_scoped_secret
from apps.backend.services.external_entity_sync import get_external_entity_sync_service

router = APIRouter(prefix="/api/v1/webhooks", tags=["webhooks"])
logger = logging.getLogger(__name__)

_ALLOWED_SOURCES = frozenset({"slack", "teams", "cliq", "zoho-cliq", "zoho", "generic"})
_MAX_WEBHOOK_PAYLOAD_BYTES = 64 * 1024
_MAX_WEBHOOK_PAYLOAD_KEYS = 128


def _validate_payload_shape(payload: dict[str, Any]) -> dict[str, Any]:
    if len(payload) > _MAX_WEBHOOK_PAYLOAD_KEYS:
        raise ValueError("payload contains too many top-level keys")
    try:
        encoded = json.dumps(payload, separators=(",", ":"), default=str).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise ValueError("payload must be JSON-serializable") from exc
    if len(encoded) > _MAX_WEBHOOK_PAYLOAD_BYTES:
        raise ValueError("payload exceeds maximum size")
    return payload


def _validate_occurred_at_value(value: str | None) -> str | None:
    normalized = str(value or "").strip()
    if not normalized:
        return None
    try:
        datetime.datetime.fromisoformat(normalized.replace("Z", "+00:00"))
    except ValueError as exc:
        raise ValueError("occurred_at must be ISO-8601") from exc
    return normalized


class _WebhookIngestBase(BaseModel):
    model_config = ConfigDict(extra="forbid")

    tenant_id: str = Field(..., min_length=1, max_length=128, description="Tenant identifier")
    entity_type: str = Field(..., min_length=1, max_length=128, description="Canonical entity type")
    payload: dict[str, Any] = Field(default_factory=dict, description="Normalized provider payload")
    idempotency_key: str = Field(..., min_length=1, max_length=256, description="Provider delivery dedupe key")
    external_id: str | None = Field(default=None, max_length=256, description="Stable external record identifier")
    occurred_at: str | None = Field(default=None, max_length=64, description="Provider event timestamp")

    @field_validator("payload")
    @classmethod
    def validate_payload(cls, value: dict[str, Any]) -> dict[str, Any]:
        return _validate_payload_shape(value)

    @field_validator("occurred_at")
    @classmethod
    def validate_occurred_at(cls, value: str | None) -> str | None:
        return _validate_occurred_at_value(value)


class CanonicalWebhookIngestRequest(_WebhookIngestBase):
    source: str = Field(..., min_length=1, max_length=64, description="External source or connector id")


class SourceWebhookIngestRequest(_WebhookIngestBase):
    pass


class CanonicalWebhookIngestResponse(BaseModel):
    event_id: str
    entity_id: str
    deduplicated: bool


def _get_tenant_webhook_secret(tenant_id: str) -> str | None:
    """Get tenant-scoped webhook secret from env pattern TENANT_WEBHOOK_SECRET_{tenant_id}."""
    return tenant_scoped_secret(tenant_id, "TENANT_WEBHOOK_SECRET_")


def _validate_source(source: str) -> str:
    normalized_source = str(source or "").strip().lower()
    if normalized_source not in _ALLOWED_SOURCES:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unsupported webhook source: {source}",
        )
    return normalized_source


def _validate_webhook_token_with_tenant(
    x_webhook_token: str | None,
    tenant_id: str,
    request_id: str,
    source_ip: str,
) -> None:
    """Validate webhook token with tenant-scoped secrets only."""
    provided_token = str(x_webhook_token or "").strip()
    if not provided_token:
        logger.warning(
            "webhook_auth_failed: missing token tenant=%s request_id=%s source_ip=%s",
            tenant_id,
            request_id,
            source_ip,
        )
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Unauthorized webhook token",
        )

    tenant_secret = _get_tenant_webhook_secret(tenant_id)
    if not tenant_secret:
        logger.error(
            "webhook_auth_failed: missing_tenant_secret tenant=%s request_id=%s source_ip=%s",
            tenant_id,
            request_id,
            source_ip,
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Tenant webhook secret not configured",
        )

    if compare_webhook_secret(provided_token, tenant_secret):
        logger.info(
            "webhook_auth_success: tenant_scoped tenant=%s request_id=%s",
            tenant_id,
            request_id,
        )
        return

    logger.warning(
        "webhook_auth_failed: invalid_token tenant=%s request_id=%s source_ip=%s",
        tenant_id,
        request_id,
        source_ip,
    )
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Unauthorized webhook token",
    )


@router.post("/ingest", response_model=CanonicalWebhookIngestResponse)
@limiter.limit("30/minute")
async def ingest_webhook(
    request: Request,
    body: CanonicalWebhookIngestRequest,
    x_webhook_token: str | None = Header(default=None, alias="x-webhook-token"),
) -> CanonicalWebhookIngestResponse:
    request_id = (
        f"wh-{datetime.datetime.now(datetime.UTC).strftime('%Y%m%d%H%M%S')}-"
        f"{hashlib.sha256(body.idempotency_key.encode()).hexdigest()[:8]}"
    )
    source_ip = request.client.host if request.client else "unknown"

    body_source = _validate_source(body.source)
    _validate_webhook_token_with_tenant(x_webhook_token, body.tenant_id, request_id, source_ip)

    receipt = await get_external_entity_sync_service().ingest_webhook(
        body.tenant_id,
        source=body_source,
        entity_type=body.entity_type,
        payload=body.payload,
        idempotency_key=body.idempotency_key,
        external_id=body.external_id,
        occurred_at=body.occurred_at,
    )
    return CanonicalWebhookIngestResponse(
        event_id=str(receipt.get("event_id", "")),
        entity_id=str(receipt.get("entity_id", "")),
        deduplicated=bool(receipt.get("deduplicated", False)),
    )


@router.post("/{source}", response_model=CanonicalWebhookIngestResponse)
@limiter.limit("30/minute")
async def ingest_source_webhook(
    source: str,
    request: Request,
    body: SourceWebhookIngestRequest,
    x_webhook_token: str | None = Header(default=None, alias="x-webhook-token"),
) -> CanonicalWebhookIngestResponse:
    request_id = (
        f"wh-{datetime.datetime.now(datetime.UTC).strftime('%Y%m%d%H%M%S')}-"
        f"{hashlib.sha256(body.idempotency_key.encode()).hexdigest()[:8]}"
    )
    source_ip = request.client.host if request.client else "unknown"

    source_name = _validate_source(source)
    _validate_webhook_token_with_tenant(x_webhook_token, body.tenant_id, request_id, source_ip)

    receipt = await get_external_entity_sync_service().ingest_webhook(
        body.tenant_id,
        source=source_name,
        entity_type=body.entity_type,
        payload=body.payload,
        idempotency_key=body.idempotency_key,
        external_id=body.external_id,
        occurred_at=body.occurred_at,
    )
    return CanonicalWebhookIngestResponse(
        event_id=str(receipt.get("event_id", "")),
        entity_id=str(receipt.get("entity_id", "")),
        deduplicated=bool(receipt.get("deduplicated", False)),
    )
