"""Asana webhook handler: challenge handshake, assignment routing, comment sync.

Receives webhook notifications from Asana for task events and routes
assignment changes to Zara intake.

Security:
- HMAC-SHA256 signature validation via ASANA_WEBHOOK_SECRET env var.
- Handshake challenge echo via X-Hook-Secret header.
- Idempotent delivery via IdempotencyStore.
"""

from __future__ import annotations

import hashlib
import logging
import os
from typing import Any

from fastapi import APIRouter, HTTPException, Request

from apps.backend.api.rate_limit import limiter
from apps.backend.services.connectors.asana_connector import (
    AsanaConnector,
    detect_comment_event as asana_detect_comment,
)
from apps.backend.services.connectors.base import ConnectorConfig
from apps.backend.services.connectors.markup_converter import convert_to_markdown
from apps.backend.services.idempotency import IdempotencyStore

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/webhooks/asana", tags=["webhooks"])
_delivery_store: IdempotencyStore | None = None


def _get_webhook_secret() -> str:
    """Get the HMAC secret for Asana webhook signature validation."""
    return (os.getenv("ASANA_WEBHOOK_SECRET") or "").strip()


def _get_asana_access_token() -> str:
    """Get the Asana access token for API calls."""
    return (os.getenv("ASANA_ACCESS_TOKEN") or "").strip()


def _get_default_tenant() -> str:
    """Get the default tenant for Asana webhooks."""
    return (os.getenv("ASANA_WEBHOOK_DEFAULT_TENANT") or "").strip()


def _get_delivery_store() -> IdempotencyStore:
    global _delivery_store  # noqa: PLW0603
    if _delivery_store is None:
        _delivery_store = IdempotencyStore()
    return _delivery_store


def _build_connector(tenant_id: str) -> AsanaConnector:
    """Build an AsanaConnector for the given tenant."""
    return AsanaConnector(
        ConnectorConfig(
            provider="asana",
            tenant_id=tenant_id,
            credentials={
                "access_token": _get_asana_access_token(),
                "webhook_secret": _get_webhook_secret(),
            },
        )
    )


def _resolve_delivery_id(request: Request, raw_body: bytes) -> str:
    """Resolve a unique delivery ID for idempotency."""
    # Asana includes X-Hook-UID but fall back to body hash
    hook_uid = str(request.headers.get("X-Hook-UID") or "").strip()
    if hook_uid:
        return hook_uid
    return hashlib.sha256(raw_body).hexdigest()


@router.post("")
@limiter.limit("30/minute")
async def handle_asana_webhook(request: Request) -> dict[str, Any]:
    """Handle Asana webhook events.

    Two modes:
    1. Handshake challenge: first request has X-Hook-Secret header,
       respond with {"X-Hook-Secret": <value>}.
    2. Event delivery: HMAC-SHA256 validated, events parsed, assignments
       routed to Zara intake.

    Returns:
        Handshake response or event acknowledgment.
    """
    raw_body = await request.body()

    # --- Handshake challenge ---
    hook_secret = (request.headers.get("X-Hook-Secret") or "").strip()
    if hook_secret:
        # Store the secret for future signature validation
        logger.info("Asana webhook handshake received")
        return {"X-Hook-Secret": hook_secret}

    # --- Signature validation ---
    webhook_secret = _get_webhook_secret()
    if not webhook_secret:
        raise HTTPException(
            status_code=503,
            detail="ASANA_WEBHOOK_SECRET not configured",
        )

    signature = (request.headers.get("X-Hook-Signature") or "").strip()
    if not signature:
        raise HTTPException(
            status_code=401,
            detail="Missing X-Hook-Signature header",
        )

    tenant_id = _get_default_tenant()
    if not tenant_id:
        raise HTTPException(
            status_code=400,
            detail="Missing tenant ID (ASANA_WEBHOOK_DEFAULT_TENANT)",
        )

    connector = _build_connector(tenant_id)
    if not connector.verify_webhook_sync(raw_body, signature):
        logger.warning("Asana webhook signature validation failed")
        raise HTTPException(status_code=401, detail="Invalid webhook signature")

    # --- Idempotency check ---
    delivery_id = _resolve_delivery_id(request, raw_body)
    dedupe_key = f"asana_webhook:{tenant_id}:{delivery_id}"

    store = _get_delivery_store()
    duplicate = store.check(dedupe_key)
    if duplicate.is_duplicate:
        cached_result = duplicate.cached_result or {}
        logger.info(
            "Asana webhook deduplicated: tenant=%s delivery_id=%s",
            tenant_id,
            delivery_id,
        )
        return {
            "accepted": int(cached_result.get("accepted", 0)),
            "duplicate": True,
        }

    # --- Parse payload ---
    try:
        payload: dict[str, Any] = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    logger.info(
        "Asana webhook received: events=%d tenant=%s",
        len(payload.get("events", [])),
        tenant_id,
    )

    # --- Route assignment events to Zara ---
    result = await connector.route_assignment_to_zara(payload)

    accepted = 1 if result.get("status") == "routed" else 0

    # --- Check for comment events (Issue #3586) ---
    if accepted == 0:
        comment = asana_detect_comment(payload)
        if comment is not None:
            comment_text = convert_to_markdown(
                comment.comment_body, comment.comment_body_format,
            )
            try:
                from apps.backend.services.zara.zara_intake_service import (
                    get_zara_intake_service,
                )

                intake = get_zara_intake_service()
                await intake.handle_inbound_pm_comment(
                    workspace_id=tenant_id,
                    source_provider=comment.source_provider,
                    external_id=comment.external_id,
                    comment_text=comment_text,
                    author_email=comment.author_email,
                    author_name=comment.author_name,
                    parent_issue_key=comment.parent_issue_key,
                )
                accepted = 1
            except Exception:
                logger.exception(
                    "Asana comment routing failed: tenant=%s task=%s",
                    tenant_id,
                    comment.parent_issue_key,
                )

            store.store(
                dedupe_key,
                {
                    "accepted": accepted,
                    "status": "comment_routed",
                    "comment_id": comment.external_id,
                },
            )
            return {
                "accepted": accepted,
                "status": "comment_routed",
                "comment_id": comment.external_id,
            }

    store.store(
        dedupe_key,
        {
            "accepted": accepted,
            "status": result.get("status", "unknown"),
        },
    )

    return {
        "accepted": accepted,
        "status": result.get("status", "unknown"),
    }
