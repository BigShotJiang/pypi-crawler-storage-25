"""Shared helpers for webhook boundary hardening."""

from __future__ import annotations

import hmac
import os
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fastapi import Request


def normalize_text(value: object) -> str:
    return str(value or "").strip()


def compare_webhook_secret(presented: str | None, expected: str | None) -> bool:
    candidate = normalize_text(presented)
    secret = normalize_text(expected)
    if not candidate or not secret:
        return False
    return hmac.compare_digest(candidate, secret)


def tenant_scoped_secret(tenant_id: str, prefix: str) -> str:
    normalized_tenant = normalize_text(tenant_id).upper().replace("-", "_")
    if not normalized_tenant:
        return ""
    return normalize_text(os.getenv(f"{prefix}{normalized_tenant}"))


def resolve_configured_value(
    request: Request | None,
    *,
    state_attr: str,
    env_names: tuple[str, ...],
) -> str:
    if request is not None:
        app = getattr(request, "app", None)
        state = getattr(app, "state", None)
        if state is not None:
            candidate = normalize_text(getattr(state, state_attr, ""))
            if candidate:
                return candidate

    for env_name in env_names:
        candidate = normalize_text(os.getenv(env_name))
        if candidate:
            return candidate

    return ""
