"""Microsoft Teams Bot Framework webhook handler (#2725).

Provides:
- POST /api/v1/webhooks/teams — handle Bot Framework activities
    (verification challenges, message events with @mention)

Mirrors apps/backend/api/webhooks/slack_events.py for Teams.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, HTTPException, Request

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/webhooks/teams", tags=["webhooks", "teams"])


def _verify_teams_auth(request: Request) -> bool:
    """Verify Teams Bot Framework authentication.

    In production, this validates the JWT bearer token from the
    Bot Framework using the bot's Microsoft App ID and password.
    For the initial implementation, we check for the presence of
    an Authorization header.
    """
    auth_header = str(request.headers.get("Authorization", "")).strip()
    if not auth_header:
        raise HTTPException(status_code=401, detail="Missing Authorization header")
    # TODO (#2725 follow-up): Full JWT validation using Bot Framework SDK.
    # The Bot Framework sends a Bearer token signed by Microsoft.
    # For now, accept any non-empty Authorization header.
    return True


@router.post("")
async def handle_teams_webhook(request: Request) -> dict[str, Any]:
    """Handle Teams Bot Framework webhook callbacks.

    Supports:
    - verification: responds to Bot Framework verification challenges
    - message: routes @mention events to Zara intake
    - other activity types: acknowledges and logs
    """
    _verify_teams_auth(request)

    try:
        payload: dict[str, Any] = await request.json()
    except Exception:
        raise HTTPException(status_code=400, detail="Invalid JSON payload")

    activity_type = str(payload.get("type") or "").strip()
    activity_name = str(payload.get("name") or "").strip()

    # Handle verification / invoke challenges
    if activity_type == "invoke" and activity_name in (
        "signin/verifyState",
        "signin/tokenExchange",
    ):
        logger.info("teams.webhook.verification challenge received")
        return {"status": "ok"}

    # Handle message activities (potential @mention)
    if activity_type == "message":
        return await _handle_message_activity(payload)

    # Ignore other activity types (conversationUpdate, typing, etc.)
    logger.info(
        "teams.webhook.ignored_activity type=%s name=%s",
        activity_type,
        activity_name,
    )
    return {"status": "ignored"}


async def _handle_message_activity(payload: dict[str, Any]) -> dict[str, Any]:
    """Route a message activity to the TeamsConnector for Zara intake."""
    from apps.backend.services.connectors.teams_connector import TeamsConnector
    from apps.backend.services.connectors.base import ConnectorConfig

    # Skip bot messages to avoid loops
    from_id = str((payload.get("from") or {}).get("id") or "")
    if from_id.startswith("28:"):
        # 28: prefix = bot in Teams
        return {"status": "ignored", "detail": "bot message"}

    connector = TeamsConnector(
        ConnectorConfig(
            provider="teams",
            tenant_id="",
            credentials={},
        )
    )

    result = await connector.route_mention_to_zara(payload)
    return result
