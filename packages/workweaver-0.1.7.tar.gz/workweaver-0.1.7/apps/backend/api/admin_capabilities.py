"""Canonical admin capability registry — single source of truth.

Every admin capability must be registered here. The UI, CLI, MCP, and
self-describe endpoint all derive from this registry. A parity test
validates that all surfaces stay in sync.

Adding a new capability:
  1. Add an entry to ADMIN_CAPABILITIES below
  2. Implement the endpoint in founder_admin.py or admin_portal.py
  3. Add the CLI subcommand in apps/cli/ww/commands/admin.py
  4. Add the MCP tool in apps/backend/mcp/admin_tools.py
  5. Add to self-describe in admin_portal.py admin_self_describe()
  6. Add to provider_operations.py workweaver-admin map
  7. Run test_admin_parity.py to verify drift is caught
"""

from __future__ import annotations

from typing import Any


class AdminCapability:
    """One admin capability exposed across UI, CLI, MCP."""

    __slots__ = (
        "name",
        "category",
        "method",
        "path",
        "description",
        "side_effects",
        "parameters",
        "cli_command",
        "mcp_tool",
        "ui_card",
        "audit_logged",
    )

    def __init__(
        self,
        *,
        name: str,
        category: str,
        method: str,
        path: str,
        description: str,
        side_effects: str = "read_only",
        parameters: dict[str, Any] | None = None,
        cli_command: str = "",
        mcp_tool: str = "",
        ui_card: str = "",
        audit_logged: bool = False,
    ) -> None:
        self.name = name
        self.category = category
        self.method = method
        self.path = path
        self.description = description
        self.side_effects = side_effects
        self.parameters = parameters or {}
        self.cli_command = cli_command
        self.mcp_tool = mcp_tool
        self.ui_card = ui_card
        self.audit_logged = audit_logged


ADMIN_CAPABILITIES: list[AdminCapability] = [
    # ── Tenant management ────────────────────────────────────────────────
    AdminCapability(
        name="tenants_list",
        category="tenants",
        method="GET",
        path="/api/v1/admin/tenants",
        description="List all tenants across the platform",
        cli_command="ww admin tenants list",
        mcp_tool="admin_tenants_list",
        ui_card="admin-tenants",
    ),
    AdminCapability(
        name="tenants_get",
        category="tenants",
        method="GET",
        path="/api/v1/admin/tenants/{tenant_id}",
        description="Get detailed tenant info including quota, connectors, audit trail",
        parameters={"tenant_id": {"type": "string", "required": True}},
        cli_command="ww admin tenants get",
        mcp_tool="admin_tenants_get",
        ui_card="admin-tenants",
    ),
    AdminCapability(
        name="tenants_suspend",
        category="tenants",
        method="POST",
        path="/api/v1/founder/tenants/{tenant_id}/suspend",
        description="Suspend a tenant immediately. Revokes all API access.",
        side_effects="irreversible",
        parameters={"tenant_id": {"type": "string", "required": True}, "reason": {"type": "string", "required": True}},
        cli_command="ww admin tenants suspend",
        mcp_tool="admin_tenants_suspend",
        ui_card="admin-tenants",
        audit_logged=True,
    ),
    AdminCapability(
        name="tenants_reactivate",
        category="tenants",
        method="POST",
        path="/api/v1/founder/tenants/{tenant_id}/reactivate",
        description="Reactivate a suspended tenant",
        side_effects="reversible",
        parameters={"tenant_id": {"type": "string", "required": True}},
        cli_command="ww admin tenants reactivate",
        mcp_tool="admin_tenants_reactivate",
        ui_card="admin-tenants",
        audit_logged=True,
    ),
    # ── Billing ──────────────────────────────────────────────────────────
    AdminCapability(
        name="billing_usage",
        category="billing",
        method="GET",
        path="/api/v1/founder/billing/usage",
        description="Get billing usage across all or specific tenants",
        parameters={"tenant_id": {"type": "string"}, "period": {"type": "string", "enum": ["day", "week", "month"]}},
        cli_command="ww admin billing usage",
        mcp_tool="admin_billing_usage",
        ui_card="admin-billing",
    ),
    # ── Inference ────────────────────────────────────────────────────────
    AdminCapability(
        name="inference_dashboard",
        category="inference",
        method="GET",
        path="/api/v1/admin/dashboard",
        description="Platform health snapshot: tenant count, provider status, errors",
        cli_command="ww admin inference list",
        mcp_tool="admin_inference_list",
        ui_card="admin-inference",
    ),
    AdminCapability(
        name="inference_providers",
        category="inference",
        method="GET",
        path="/api/v1/founder/inference/providers",
        description="List all inference providers with status and capability classes",
        cli_command="ww admin inference list",
        mcp_tool="admin_inference_list",
        ui_card="admin-inference",
    ),
    AdminCapability(
        name="inference_models",
        category="inference",
        method="GET",
        path="/api/v1/founder/inference/models",
        description="List all inference models with capability class mapping",
        cli_command="ww admin inference list",
        mcp_tool="admin_inference_list",
        ui_card="admin-inference",
    ),
    AdminCapability(
        name="inference_tenant_routing",
        category="inference",
        method="GET",
        path="/api/v1/founder/inference/tenants/{tenant_id}/routing-override",
        description="Get per-tenant inference routing overrides by capability",
        parameters={"tenant_id": {"type": "string", "required": True}},
        cli_command="ww admin inference config",
        mcp_tool="admin_inference_config",
        ui_card="admin-inference",
    ),
    AdminCapability(
        name="inference_set_routing",
        category="inference",
        method="POST",
        path="/api/v1/founder/inference/tenants/{tenant_id}/routing-override",
        description="Override inference provider for a capability per tenant",
        side_effects="reversible",
        parameters={
            "tenant_id": {"type": "string", "required": True},
            "capability_class": {"type": "string", "required": True},
            "provider_id": {"type": "string", "required": True},
            "model_id": {"type": "string"},
        },
        cli_command="ww admin inference config",
        mcp_tool="admin_inference_config",
        ui_card="admin-inference",
        audit_logged=True,
    ),
    AdminCapability(
        name="inference_effective_config",
        category="inference",
        method="GET",
        path="/api/v1/founder/inference/tenants/{tenant_id}/effective-config",
        description="Resolved inference config (defaults + overrides merged)",
        parameters={"tenant_id": {"type": "string", "required": True}},
        cli_command="ww admin inference config",
        mcp_tool="admin_inference_config",
        ui_card="admin-inference",
    ),
    AdminCapability(
        name="inference_defaults",
        category="inference",
        method="GET",
        path="/api/v1/founder/inference/defaults",
        description="Platform-wide default inference routing by capability class",
        cli_command="ww admin inference list",
        mcp_tool="admin_inference_list",
        ui_card="admin-inference",
    ),
    AdminCapability(
        name="inference_set_defaults",
        category="inference",
        method="POST",
        path="/api/v1/founder/inference/defaults",
        description="Set platform-wide default provider for a capability class",
        side_effects="reversible",
        parameters={
            "capability_class": {"type": "string", "required": True},
            "provider_id": {"type": "string", "required": True},
            "model_id": {"type": "string"},
        },
        cli_command="ww admin inference config",
        mcp_tool="admin_inference_config",
        ui_card="admin-inference",
        audit_logged=True,
    ),
    AdminCapability(
        name="inference_audit",
        category="inference",
        method="GET",
        path="/api/v1/founder/inference/audit/performance",
        description="Provider audit dashboard: per-Purpose x per-tenant cost/quality/latency grid",
        parameters={
            "tenant_id": {"type": "string"},
            "purpose": {"type": "string"},
        },
        cli_command="ww admin inference audit",
        mcp_tool="admin_inference_audit_grid",
        ui_card="admin-inference-audit",
    ),
    # ── Support ──────────────────────────────────────────────────────────
    AdminCapability(
        name="support_tickets_list",
        category="support",
        method="GET",
        path="/api/v1/support/admin/tickets",
        description="List support tickets across all tenants for triage",
        parameters={
            "status": {"type": "string", "enum": ["open", "in_progress", "resolved", "closed"]},
            "tenant_id": {"type": "string"},
            "category": {"type": "string"},
        },
        cli_command="ww admin support tickets list",
        mcp_tool="admin_support_tickets",
        ui_card="admin-support",
    ),
    AdminCapability(
        name="support_reply",
        category="support",
        method="POST",
        path="/api/v1/support/tickets/{ticket_id}/messages",
        description="Reply to a support ticket (visible to customer)",
        side_effects="irreversible",
        parameters={
            "ticket_id": {"type": "string", "required": True},
            "content": {"type": "string", "required": True},
            "is_internal": {"type": "bool", "default": False},
        },
        cli_command="ww admin support tickets reply",
        mcp_tool="admin_support_reply",
        ui_card="admin-support",
        audit_logged=True,
    ),
    # ── Feature flags ────────────────────────────────────────────────────
    AdminCapability(
        name="feature_flags_list",
        category="feature_flags",
        method="GET",
        path="/api/v1/admin/feature-flags",
        description="List all feature flags with status and rollout percentage",
        cli_command="ww admin feature-flags list",
        mcp_tool="admin_feature_flags_list",
        ui_card="admin-feature-flags",
    ),
    AdminCapability(
        name="feature_flags_set",
        category="feature_flags",
        method="POST",
        path="/api/v1/admin/feature-flags",
        description="Set a feature flag",
        side_effects="reversible",
        parameters={"flag": {"type": "string", "required": True}, "enabled": {"type": "bool", "required": True}},
        cli_command="ww admin feature-flags set",
        mcp_tool="admin_feature_flags_set",
        ui_card="admin-feature-flags",
        audit_logged=True,
    ),
    # ── Audit ────────────────────────────────────────────────────────────
    AdminCapability(
        name="audit_log",
        category="audit",
        method="GET",
        path="/api/v1/admin/audit",
        description="Recent admin actions for compliance review",
        parameters={"limit": {"type": "int", "default": 50, "max": 500}},
        cli_command="ww admin audit",
        mcp_tool="admin_audit_log",
        ui_card="admin-audit",
    ),
    AdminCapability(
        name="runtime_timeline",
        category="runtime",
        method="GET",
        path="/api/v1/admin/runtime/timeline",
        description="Redacted backend startup phase history for runtime diagnostics",
        parameters={
            "limit": {"type": "int", "default": 50, "max": 200},
            "phase": {"type": "string"},
            "status": {"type": "string", "enum": ["succeeded", "failed"]},
            "scope": {"type": "string"},
        },
        cli_command="ww runtime status --timeline",
        mcp_tool="admin_runtime_timeline",
        ui_card="admin-runtime",
    ),
    # ── Self-describe ────────────────────────────────────────────────────
    AdminCapability(
        name="self_describe",
        category="self_describe",
        method="GET",
        path="/api/v1/admin/self-describe",
        description="Machine-readable manifest of all admin capabilities",
        cli_command="ww admin self-describe",
        mcp_tool="admin_self_describe",
        ui_card="admin-meta",
    ),
]


def get_capabilities_by_category() -> dict[str, list[AdminCapability]]:
    """Return capabilities grouped by category."""
    cats: dict[str, list[AdminCapability]] = {}
    for cap in ADMIN_CAPABILITIES:
        cats.setdefault(cap.category, []).append(cap)
    return cats


def get_mutation_capabilities() -> list[AdminCapability]:
    """Return only capabilities with side effects (mutations)."""
    return [c for c in ADMIN_CAPABILITIES if c.side_effects != "read_only"]


def get_read_only_capabilities() -> list[AdminCapability]:
    """Return only read-only capabilities."""
    return [c for c in ADMIN_CAPABILITIES if c.side_effects == "read_only"]
