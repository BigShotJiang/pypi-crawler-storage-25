"""Validator Pool API -- pool management, stats, and calibration.

Endpoints:
  GET  /api/v1/validator-pool/list          -- List validators for a tenant
  GET  /api/v1/validator-pool/stats         -- Aggregate pool statistics
  GET  /api/v1/validator-pool/calibrate/:id -- Compute calibration for a validator

Read-only: assignment is server-side only (via ValidatorPoolService.assign).

Reference: GitHub issue #2328
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/validator-pool", tags=["validator-pool"])


# ---------------------------------------------------------------------------
# Response models
# ---------------------------------------------------------------------------


class ValidatorProfileResponse(BaseModel):
    """Validator profile summary."""

    user_id: str
    tenant_id: str
    domains: list[str] = Field(default_factory=list)
    calibration_score: float = 0.0
    brier_score: float = 0.0
    n_with_ground_truth: int = 0
    active: bool = True


class ValidatorListResponse(BaseModel):
    """List of validators for a tenant."""

    tenant_id: str
    validators: list[ValidatorProfileResponse]
    count: int


class PoolStatsResponse(BaseModel):
    """Aggregate pool statistics."""

    tenant_id: str
    total: int
    active: int
    inactive: int


class CalibrationResponse(BaseModel):
    """Calibration computation result."""

    validator_id: str
    brier_score: float
    n_with_ground_truth: int
    calibration_score: float


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _get_pool_service() -> Any:
    """Get or create the ValidatorPoolService singleton."""
    from apps.backend.services.validator_pool_service import ValidatorPoolService

    # Use module-level singleton pattern consistent with other services
    if not hasattr(_get_pool_service, "_instance"):
        _get_pool_service._instance = ValidatorPoolService()  # type: ignore[attr-defined]
    return _get_pool_service._instance  # type: ignore[attr-defined]


def _profile_to_response(profile: Any) -> ValidatorProfileResponse:
    return ValidatorProfileResponse(
        user_id=profile.user_id,
        tenant_id=profile.tenant_id,
        domains=profile.domains,
        calibration_score=profile.calibration_score,
        brier_score=profile.brier_score,
        n_with_ground_truth=profile.n_with_ground_truth,
        active=profile.active,
    )


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("/list", response_model=ValidatorListResponse)
async def list_validators(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ValidatorListResponse:
    """List all validators for the authenticated tenant."""
    pool = _get_pool_service()
    validators = pool.list_validators(tenant_id)
    return ValidatorListResponse(
        tenant_id=tenant_id,
        validators=[_profile_to_response(v) for v in validators],
        count=len(validators),
    )


@router.get("/stats", response_model=PoolStatsResponse)
async def pool_stats(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PoolStatsResponse:
    """Return aggregate pool statistics for the authenticated tenant."""
    pool = _get_pool_service()
    stats = pool.pool_stats(tenant_id)
    return PoolStatsResponse(
        tenant_id=tenant_id,
        total=stats["total"],
        active=stats["active"],
        inactive=stats["inactive"],
    )


@router.get("/calibrate/{validator_id}", response_model=CalibrationResponse)
async def calibrate_validator(
    validator_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CalibrationResponse:
    """Compute and return calibration (Brier score) for a specific validator."""
    pool = _get_pool_service()
    result = pool.compute_calibration(tenant_id, validator_id)
    if result is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No calibration data for validator {validator_id}",
        )
    return CalibrationResponse(
        validator_id=result.validator_id,
        brier_score=result.brier_score,
        n_with_ground_truth=result.n_with_ground_truth,
        calibration_score=result.calibration_score,
    )
