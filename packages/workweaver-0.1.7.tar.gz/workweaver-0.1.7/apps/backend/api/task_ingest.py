"""
Task Ingest API

Endpoints for capturing tasks from email, voice, Slack, and webhooks.

Source: docs/PRODUCT.md#Part18.6
"""

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, ConfigDict, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.schemas.error_response import safe_error_detail
from apps.backend.services.task_ingest import TaskIngestService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/mission/tasks/ingest", tags=["task-ingest"])

_ingest_svc = TaskIngestService()


class IngestRequest(BaseModel):
    source: str = Field(..., description="email | voice | slack | webhook | manual")
    payload: dict[str, Any] = Field(..., description="Source-specific payload")


class EmailIngestRequest(BaseModel):
    subject: str = Field("", description="Email subject line")
    sender: str = Field("", description="Sender email address", alias="from")
    body: str = Field("", description="Email body content")
    message_id: str = Field("", description="Email message ID")

    model_config = ConfigDict(populate_by_name=True)


class VoiceIngestRequest(BaseModel):
    transcript: str = Field(..., description="Voice transcript text")
    call_id: str = Field("", description="Voice call ID")
    duration_seconds: int = Field(0, description="Call duration in seconds")


@router.post("")
async def ingest_task(
    req: IngestRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Ingest a task from any source."""
    try:
        return _ingest_svc.ingest(tenant_id, req.source, req.payload)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=safe_error_detail(e))


@router.post("/email")
async def ingest_from_email(
    req: EmailIngestRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Ingest a task from an email."""
    payload = {
        "subject": req.subject,
        "sender": req.sender,
        "body": req.body,
        "message_id": req.message_id,
    }
    return _ingest_svc.ingest(tenant_id, "email", payload)


@router.post("/voice")
async def ingest_from_voice(
    req: VoiceIngestRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Ingest a task from voice transcript."""
    payload = {
        "transcript": req.transcript,
        "call_id": req.call_id,
        "duration_seconds": req.duration_seconds,
    }
    return _ingest_svc.ingest(tenant_id, "voice", payload)


@router.get("")
async def list_ingested_tasks(
    source: str | None = Query(None),
    limit: int = Query(50, ge=1, le=200),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[dict[str, Any]]:
    """List ingested tasks."""
    return _ingest_svc.list_ingested(tenant_id, source, limit)


@router.get("/{task_id}")
async def get_ingested_task(
    task_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Get a specific ingested task."""
    task = _ingest_svc.get_ingested(tenant_id, task_id)
    if not task:
        raise HTTPException(status_code=404, detail=f"Ingested task {task_id} not found")
    return task
