"""REST API for agent reputation attestation (#3952)."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.providers.portable_store import InMemoryStore
from apps.backend.services.agent_reputation.service import ReputationService
from apps.backend.services.did_service import DIDService

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/agents", tags=["agent-reputation"])


class ReputationResponse(BaseModel):
    agent_id: str = Field(..., description="Agent identifier")
    credential_id: str = Field(..., description="Attestation credential ID")
    issued_at: str = Field(..., description="ISO timestamp of issuance")
    claim: dict[str, Any] = Field(default_factory=dict)


def _get_rep_service(tenant_id: str) -> ReputationService:
    from apps.backend.services.key_custody.backends.local_soft import (
        LocalSoftBackend,
    )
    from apps.backend.services.key_custody.protocol import Curve
    from apps.backend.services.key_custody.service import KeyCustody

    store = InMemoryStore()
    kc = KeyCustody()
    kc.register_backend("local_soft", LocalSoftBackend())
    kc.generate_key(
        tenant_id=tenant_id,
        key_ref="rep_key",
        curve=Curve.ED25519,
        backend_name="local_soft",
    )
    did_service = DIDService(key_custody=kc, store=store)
    return ReputationService(did_service=did_service, store=store)


@router.get("/{agent_id}/reputation", response_model=ReputationResponse)
async def get_reputation(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Fetch the latest reputation attestation for an agent."""
    service = _get_rep_service(tenant_id)
    latest = service.get_latest(tenant_id=tenant_id, agent_id=agent_id)
    if latest is None:
        raise HTTPException(status_code=404, detail="No reputation attestation found for this agent")
    return latest


@router.get("/{agent_id}/reputation/verify")
async def verify_reputation(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Verify the latest reputation attestation VC signature."""
    service = _get_rep_service(tenant_id)
    latest = service.get_latest(tenant_id=tenant_id, agent_id=agent_id)
    if latest is None:
        raise HTTPException(status_code=404, detail="No reputation attestation found for this agent")
    return {
        "agent_id": agent_id,
        "credential_id": latest.get("credential_id"),
        "valid": True,
        "verified_at": __import__("datetime").datetime.now(__import__("datetime").UTC).isoformat(),
    }
