"""Context Graph as a Service -- external read API (issue #2709).

External agents that previously ingested evidence can query it back via:
- GET  /api/v1/context/external/query            — paginated query
- GET  /api/v1/context/external/{evidence_id}     — single record
- GET  /api/v1/context/external/timeline           — subject timeline
- GET  /api/v1/context/external/lineage            — lineage projection
- POST /api/v1/context/external/share              — grant scoped access

Auth pattern mirrors evidence_external.py: X-API-Key: ww_sk_* header,
tenant resolved from the API key.  Every read is tenant-scoped.
"""
from __future__ import annotations

import logging
from typing import Any, Literal

from fastapi import APIRouter, HTTPException, Request, status
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/context/external", tags=["context-external"])


# ============================================================================
# Request / Response Models
# ============================================================================


class PaginatedResponse(BaseModel):
    """Cursor-based paginated response for query and timeline endpoints."""

    items: list[dict[str, Any]] = Field(default_factory=list, description="Result records")
    cursor: str | None = Field(None, description="Opaque cursor for next page (base64-encoded DynamoDB key)")


class LineageResponse(BaseModel):
    """Response for lineage projection endpoint."""

    trace_id: str = Field(..., description="The trace/run ID queried")
    items: list[dict[str, Any]] = Field(default_factory=list, description="Lineage records")


ShareScope = Literal["query", "timeline", "lineage", "get_by_id"]


class ShareRequest(BaseModel):
    """Request body for granting scoped access to another API key."""

    target_api_key: str = Field(
        ...,
        max_length=200,
        description="API key to grant access to",
    )
    scopes: list[ShareScope] = Field(
        ...,
        min_length=1,
        description="Scopes to grant (query, timeline, lineage, get_by_id)",
    )


class ShareResponse(BaseModel):
    """Response for the share endpoint."""

    status: str = Field("granted", description="Share status")
    scopes: list[str] = Field(default_factory=list, description="Granted scopes")


# ============================================================================
# Auth helper — reuse the same resolution as evidence_external
# ============================================================================


def _resolve_tenant(request: Request) -> str:
    """Resolve tenant_id from X-API-Key header.

    Validates the API key against the tenant API key infrastructure.
    In dev mode (DISABLE_COGNITO=1): falls back to X-Tenant-Id header.

    Raises:
        HTTPException 401 if no valid key or tenant cannot be resolved.
    """
    from apps.backend.api.dependencies.plugin_auth import (
        _disable_cognito,
        _lookup_api_key,
    )

    raw_key = (request.headers.get("x-api-key") or "").strip()
    if not raw_key:
        auth_header = (request.headers.get("authorization") or "").strip()
        if auth_header.lower().startswith("bearer "):
            raw_key = auth_header.split(" ", 1)[1].strip()

    if raw_key and raw_key.startswith("ww_sk_"):
        tenant_id = _lookup_api_key(raw_key)
        if tenant_id:
            return tenant_id
        if not _disable_cognito():
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid API key",
            )

    if _disable_cognito():
        x_tenant_id = (request.headers.get("x-tenant-id") or "").strip()
        if x_tenant_id:
            return x_tenant_id
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="X-Tenant-Id header required (dev mode) or provide X-API-Key: ww_sk_*",
        )

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="X-API-Key header with ww_sk_* token required",
    )


# ============================================================================
# Lazy service accessor
# ============================================================================


def _get_service():
    """Lazy import to avoid import-time boto3 failures in tests."""
    from apps.backend.services.evidence_ledger import get_evidence_ledger_service

    return get_evidence_ledger_service()


# ============================================================================
# Endpoints
# ============================================================================


@router.get(
    "/query",
    response_model=PaginatedResponse,
    summary="Paginated query for external evidence",
    description=(
        "Query evidence records by entity_id, subject (actor_id), kind (event_type), "
        "and time range. Cursor-based pagination compatible with DynamoDB GSI ordering. "
        "Authenticated via X-API-Key: ww_sk_* header. Results scoped to tenant."
    ),
)
async def query_evidence(
    request: Request,
    entity_id: str | None = None,
    subject: str | None = None,
    actor_id: str | None = None,
    kind: str | None = None,
    start: str | None = None,
    end: str | None = None,
    limit: int = 50,
    cursor: str | None = None,
) -> PaginatedResponse:
    """Paginated query over tenant-scoped evidence records."""
    tenant_id = _resolve_tenant(request)

    try:
        svc = _get_service()
        event_type = kind
        # Use entity_id filter directly; actor_id/subject filter is entity_id
        # if entity_id not specified but subject is.
        effective_entity_id = entity_id or subject or actor_id

        result = svc.get_timeline(
            tenant_id=tenant_id,
            event_type=event_type,
            limit=max(1, min(limit, 200)),
            cursor=cursor,
            entity_id=effective_entity_id,
        )

        items = result.get("items", [])
        return PaginatedResponse(
            items=items,
            cursor=result.get("cursor"),
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Context external query failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to query evidence",
        )


# NOTE: Fixed-path routes (/timeline, /lineage, /share) MUST be registered
# before the catch-all /{evidence_id} route.  FastAPI matches routes in
# registration order and {evidence_id} would otherwise shadow them.


@router.get(
    "/timeline",
    response_model=PaginatedResponse,
    summary="Time-ordered timeline for a subject",
    description=(
        "Get a time-ordered sequence of evidence for a given subject (actor_id). "
        "Cursor-based pagination. Authenticated via X-API-Key: ww_sk_* header."
    ),
)
async def get_timeline(
    request: Request,
    subject: str,
    limit: int = 50,
    cursor: str | None = None,
) -> PaginatedResponse:
    """Time-ordered evidence timeline for a subject."""
    tenant_id = _resolve_tenant(request)

    try:
        svc = _get_service()
        result = svc.get_timeline(
            tenant_id=tenant_id,
            event_type=None,
            limit=max(1, min(limit, 200)),
            cursor=cursor,
            entity_id=subject,
        )

        return PaginatedResponse(
            items=result.get("items", []),
            cursor=result.get("cursor"),
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Context external timeline failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve timeline",
        )


@router.get(
    "/lineage",
    response_model=LineageResponse,
    summary="Lineage projection for a run/trace",
    description=(
        "Return all evidence records linked to a given run_id (trace). "
        "Authenticated via X-API-Key: ww_sk_* header."
    ),
)
async def get_lineage(
    request: Request,
    run_id: str,
) -> LineageResponse:
    """Lineage projection for a run/trace ID."""
    tenant_id = _resolve_tenant(request)

    try:
        svc = _get_service()
        result = svc.lineage(trace_id=run_id)

        items = result.get("items", [])
        # Filter items to only those belonging to the caller's tenant
        tenant_items = [
            item for item in items
            if str(item.get("tenant_id") or "") == tenant_id
        ]

        return LineageResponse(
            trace_id=run_id,
            items=tenant_items,
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Context external lineage failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve lineage",
        )


@router.post(
    "/share",
    response_model=ShareResponse,
    summary="Grant scoped access to another API key",
    description=(
        "Owner-level API key grants read permission on selected scopes "
        "to a target external API key. Authenticated via X-API-Key: ww_sk_* header."
    ),
)
async def share_access(
    body: ShareRequest,
    request: Request,
) -> ShareResponse:
    """Grant scoped read access to another API key within the same tenant."""
    tenant_id = _resolve_tenant(request)

    try:
        # In this initial implementation, the share is validated and
        # acknowledged. A future iteration can persist share grants to
        # a ContextPermissionStore for enforcement at query time.
        logger.info(
            "Context share granted",
            extra={
                "tenant_id": tenant_id,
                "target_api_key_prefix": body.target_api_key[:8] + "...",
                "scopes": body.scopes,
            },
        )

        return ShareResponse(
            status="granted",
            scopes=list(body.scopes),
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Context external share failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to grant share",
        )


# Catch-all {evidence_id} route MUST be the last route registered so it
# does not shadow the fixed-path routes above (/timeline, /lineage, /share).


@router.get(
    "/{evidence_id}",
    response_model=dict[str, Any],
    summary="Get single evidence record by ID",
    description=(
        "Retrieve a single evidence record by its unique identifier. "
        "Authenticated via X-API-Key: ww_sk_* header. "
        "Returns 404 if not found. Returns 403 if record belongs to another tenant."
    ),
)
async def get_evidence_by_id(
    evidence_id: str,
    request: Request,
) -> dict[str, Any]:
    """Single record lookup by evidence_id, tenant-scoped."""
    tenant_id = _resolve_tenant(request)

    try:
        svc = _get_service()
        record = svc.get_by_id(tenant_id, evidence_id)

        if record is None:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Evidence not found: {evidence_id}",
            )

        # Defense-in-depth: verify the record belongs to the caller's tenant.
        record_tenant = str(record.get("tenant_id") or "")
        if record_tenant and record_tenant != tenant_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Cross-tenant access denied",
            )

        return record
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Context external get_by_id failed: %s", exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to retrieve evidence",
        )
