"""Trace Learning API — strategy mining and retrieval (PR-T3.2 + PR-T3.3).

Endpoints:
    POST /api/v1/trace-learning/mine      — trigger mining for a task category
    GET  /api/v1/trace-learning/strategies — get strategies for a category
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/trace-learning", tags=["trace-learning"])


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class MineRequest(BaseModel):
    task_category: str = Field(..., min_length=1, max_length=200)
    sample_size: int = Field(20, ge=1, le=100)


class StrategyResponse(BaseModel):
    strategy_id: str
    tenant_id: str
    scope: str
    user_id: str | None
    task_category: str
    guidance: str
    confidence: float
    validation_count: int
    last_used: str | None
    source_trace_ids: list[str]
    created_at: str
    updated_at: str


class MineResponse(BaseModel):
    strategies_created: int
    strategies: list[StrategyResponse]


# ---------------------------------------------------------------------------
# Dependencies (lazy imports to avoid circular imports at module load)
# ---------------------------------------------------------------------------


def _get_miner():  # type: ignore[return]
    from apps.backend.dependencies import get_strategy_miner

    return get_strategy_miner()


def _get_strategy_store():  # type: ignore[return]
    try:
        from apps.backend.dependencies import get_strategy_store

        return get_strategy_store()
    except Exception as exc:
        logger.warning("trace_learning: strategy store unavailable: %s", exc)
        return None


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.post("/mine", response_model=MineResponse)
async def mine_strategies(
    body: MineRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    miner: object = Depends(_get_miner),
) -> MineResponse:
    """Trigger offline mining for a task category."""
    try:
        strategies = await miner.mine_strategies(  # type: ignore[union-attr]
            tenant_id=tenant_id,
            task_category=body.task_category,
            sample_size=body.sample_size,
        )
    except Exception:
        logger.exception("mining_failed")
        raise HTTPException(status_code=500, detail="Strategy mining failed")

    return MineResponse(
        strategies_created=len(strategies),
        strategies=[
            StrategyResponse(
                strategy_id=s.strategy_id,
                tenant_id=s.tenant_id,
                scope=s.scope,
                user_id=s.user_id,
                task_category=s.task_category,
                guidance=s.guidance,
                confidence=s.confidence,
                validation_count=s.validation_count,
                last_used=s.last_used,
                source_trace_ids=s.source_trace_ids,
                created_at=s.created_at,
                updated_at=s.updated_at,
            )
            for s in strategies
        ],
    )


@router.get("/strategies", response_model=list[StrategyResponse])
async def get_strategies(
    category: str = Query(..., min_length=1, description="Task category to filter by"),
    scope: str = Query("deployment", description="Scope: deployment or user"),
    limit: int = Query(5, ge=1, le=50),
    tenant_id: str = Depends(get_verified_tenant_id),
    store: object = Depends(_get_strategy_store),
) -> list[StrategyResponse]:
    """Retrieve strategies for a task category."""
    try:
        strategies = await store.get_strategies(  # type: ignore[union-attr]
            tenant_id=tenant_id,
            task_category=category,
            scope=scope,
            limit=limit,
        )
    except Exception:
        logger.exception("strategy_retrieval_failed")
        raise HTTPException(status_code=500, detail="Strategy retrieval failed")

    return [
        StrategyResponse(
            strategy_id=s.strategy_id,
            tenant_id=s.tenant_id,
            scope=s.scope,
            user_id=s.user_id,
            task_category=s.task_category,
            guidance=s.guidance,
            confidence=s.confidence,
            validation_count=s.validation_count,
            last_used=s.last_used,
            source_trace_ids=s.source_trace_ids,
            created_at=s.created_at,
            updated_at=s.updated_at,
        )
        for s in strategies
    ]


# ---------------------------------------------------------------------------
# Editable Improvements (PR-CB2 — Hyperagents bar)
# ---------------------------------------------------------------------------


class UpdateStrategyRequest(BaseModel):
    guidance: str = Field(..., min_length=1, max_length=5000)


class DeleteStrategyResponse(BaseModel):
    strategy_id: str
    deleted: bool


@router.put("/strategies/{strategy_id}", response_model=StrategyResponse)
async def update_strategy(
    strategy_id: str,
    body: UpdateStrategyRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    store: object = Depends(_get_strategy_store),
) -> StrategyResponse:
    """Edit strategy guidance text."""
    try:
        strategy = await store.get_strategy(  # type: ignore[union-attr]
            tenant_id=tenant_id,
            strategy_id=strategy_id,
        )
    except Exception:
        strategy = None

    if strategy is None:
        raise HTTPException(
            status_code=404,
            detail=f"Strategy {strategy_id} not found",
        )

    try:
        strategy.guidance = body.guidance
        await store.put_strategy(tenant_id=tenant_id, strategy=strategy)  # type: ignore[union-attr]
    except Exception:
        logger.exception("strategy_update_failed")
        raise HTTPException(status_code=500, detail="Strategy update failed")

    return StrategyResponse(
        strategy_id=strategy.strategy_id,
        tenant_id=strategy.tenant_id,
        scope=strategy.scope,
        user_id=strategy.user_id,
        task_category=strategy.task_category,
        guidance=strategy.guidance,
        confidence=strategy.confidence,
        validation_count=strategy.validation_count,
        last_used=strategy.last_used,
        source_trace_ids=strategy.source_trace_ids,
        created_at=strategy.created_at,
        updated_at=strategy.updated_at,
    )


@router.delete("/strategies/{strategy_id}", response_model=DeleteStrategyResponse)
async def delete_strategy(
    strategy_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    store: object = Depends(_get_strategy_store),
) -> DeleteStrategyResponse:
    """Discard a strategy."""
    try:
        strategy = await store.get_strategy(  # type: ignore[union-attr]
            tenant_id=tenant_id,
            strategy_id=strategy_id,
        )
    except Exception:
        strategy = None

    if strategy is None:
        raise HTTPException(
            status_code=404,
            detail=f"Strategy {strategy_id} not found",
        )

    try:
        await store.delete_strategy(  # type: ignore[union-attr]
            tenant_id=tenant_id,
            strategy_id=strategy_id,
        )
    except Exception:
        logger.exception("strategy_delete_failed")
        raise HTTPException(status_code=500, detail="Strategy deletion failed")

    return DeleteStrategyResponse(strategy_id=strategy_id, deleted=True)


# ---------------------------------------------------------------------------
# Dashboard (PR-T3.5)
# ---------------------------------------------------------------------------


class TraceLearningDashboardResponse(BaseModel):
    strategies_learned_this_week: int = 0
    strategy_hit_rate: float = 0.0
    top_strategies: list[StrategyResponse] = Field(default_factory=list)
    trace_coverage_percent: float = 0.0
    total_traces: int = 0
    total_strategies: int = 0


def _get_trace_store():  # type: ignore[return]
    try:
        from apps.backend.services.trace_store import get_inference_trace_store

        return get_inference_trace_store()
    except Exception as exc:
        logger.warning("trace_learning: trace store unavailable: %s", exc)
        return None


def _safe_confidence(value: object) -> float:
    """Coerce a Strategy.confidence value to a float, defaulting None / non-numeric to 0.0.

    Codex round-1 root-cause: ``sorted(..., key=lambda s: s.confidence)``
    raised ``TypeError`` when any strategy's ``confidence`` was None or a
    non-numeric string, returning 500 even though the handler had a
    try/except around every other step. Centralising the coercion here
    means *every* code path (sort, response_model serialization, hit-rate
    math) is null-safe.
    """
    try:
        if value is None:
            return 0.0
        return float(value)  # handles int, float, numeric str
    except (TypeError, ValueError):
        return 0.0


def _safe_validation_count(value: object) -> int:
    """Coerce validation_count to an int, defaulting to 0."""
    try:
        if value is None:
            return 0
        return int(value)
    except (TypeError, ValueError):
        return 0


def _safe_source_trace_ids(value: object) -> list[str]:
    """Coerce source_trace_ids to a list of strings, never None.

    Codex + Gemini both flagged this: a ``None`` here breaks both the
    ``set.update()`` aggregation and Pydantic response validation.
    """
    if value is None:
        return []
    if isinstance(value, (list, tuple, set)):
        return [str(x) for x in value if x is not None]
    return []


@router.get("/dashboard", response_model=TraceLearningDashboardResponse)
async def trace_learning_dashboard(
    tenant_id: str = Depends(get_verified_tenant_id),
    store: object = Depends(_get_strategy_store),
    trace_store: object = Depends(_get_trace_store),
) -> TraceLearningDashboardResponse:
    """Aggregated trace-learning dashboard metrics for a tenant.

    Closes #1174. The pre-fix handler swallowed every ``Exception`` with
    bare ``try/except: pass`` blocks but still 500'd downstream because:

    1. ``sorted(strategies, key=lambda s: s.confidence)`` raised
       ``TypeError`` when any ``confidence`` was ``None`` or a non-numeric
       string. The handler had no outer catch, so this bubbled to a 500.
    2. ``set.update(s.source_trace_ids)`` raised ``TypeError`` when the
       attribute was ``None``.
    3. Pydantic ``response_model`` validation could 500 if a Strategy
       had ``None`` in a non-Optional field (``confidence: float``).

    The fix replaces every silent-fail with explicit, *typed* defensive
    coercion (``_safe_confidence``, ``_safe_source_trace_ids``,
    ``_safe_validation_count``) so empty/partial data degrades to zeros
    rather than 500, and structured warning logs surface the underlying
    cause so the next regression is debuggable instead of mysterious.
    """
    from datetime import UTC, datetime, timedelta

    # --- Guard: return empty dashboard if stores are unavailable ---
    if store is None or trace_store is None:
        logger.warning("trace_dashboard: store unavailable, returning empty dashboard")
        return TraceLearningDashboardResponse(
            strategies_learned_this_week=0,
            strategy_hit_rate=0.0,
            top_strategies=[],
            trace_coverage_percent=0.0,
            total_strategies=0,
            total_traces=0,
        )

    # --- Fetch strategies (graceful degradation, but loud about it) ---
    all_strategies = []
    try:
        all_strategies = (
            await store.get_strategies(  # type: ignore[union-attr]
                tenant_id=tenant_id,
                task_category="",  # empty category matches none; we use prefix query below
                scope="deployment",
                limit=1000,
            )
            or []
        )
    except Exception as exc:  # noqa: BLE001 — log root cause then degrade
        logger.warning(
            "trace_dashboard_get_strategies_failed",
            extra={"tenant_id": tenant_id, "error": type(exc).__name__},
        )

    # Fallback: query all strategies via prefix scan if category filter returned empty.
    if not all_strategies:
        try:
            from apps.backend.services.learning.trace_strategy_store import (
                SK_PREFIX,
                Strategy,
            )

            raw_items = await store._query_prefix(  # type: ignore[union-attr]
                tenant_id,
                SK_PREFIX,
                limit=1000,
            )
            all_strategies = [Strategy.from_dict(item) for item in (raw_items or [])]
        except Exception as exc:  # noqa: BLE001
            logger.warning(
                "trace_dashboard_prefix_query_failed",
                extra={"tenant_id": tenant_id, "error": type(exc).__name__},
            )

    total_strategies = len(all_strategies)

    # --- Strategies learned this week ---
    now = datetime.now(UTC)
    week_ago_iso = (now - timedelta(days=7)).isoformat()
    strategies_this_week = [s for s in all_strategies if (getattr(s, "created_at", "") or "") >= week_ago_iso]

    # --- Hit rate ---
    validated = [s for s in all_strategies if _safe_validation_count(getattr(s, "validation_count", 0)) > 1]
    hit_rate = (len(validated) / total_strategies) if total_strategies > 0 else 0.0

    # --- Top strategies (defensive sort — fixes the 500) ---
    sorted_strategies = sorted(
        all_strategies,
        key=lambda s: _safe_confidence(getattr(s, "confidence", 0.0)),
        reverse=True,
    )[:5]

    # --- Trace coverage ---
    total_traces = 0
    try:
        from apps.backend.services.trace_store import SK_PREFIX as TRACE_SK_PREFIX

        trace_items = await trace_store._query_prefix(  # type: ignore[union-attr]
            tenant_id,
            TRACE_SK_PREFIX,
            limit=1000,
        )
        total_traces = len(trace_items or [])
    except Exception as exc:  # noqa: BLE001
        logger.warning(
            "trace_dashboard_trace_count_failed",
            extra={"tenant_id": tenant_id, "error": type(exc).__name__},
        )

    # --- Coverage: fraction of traces that contributed to at least one strategy ---
    all_source_trace_ids: set[str] = set()
    for s in all_strategies:
        all_source_trace_ids.update(_safe_source_trace_ids(getattr(s, "source_trace_ids", None)))
    trace_coverage = (len(all_source_trace_ids) / total_traces) if total_traces > 0 else 0.0

    # --- Project to response model with defensive coercion ---
    top_strategies_response = [
        StrategyResponse(
            strategy_id=str(getattr(s, "strategy_id", "") or ""),
            tenant_id=str(getattr(s, "tenant_id", "") or tenant_id),
            scope=str(getattr(s, "scope", "") or ""),
            user_id=getattr(s, "user_id", None),
            task_category=str(getattr(s, "task_category", "") or ""),
            guidance=str(getattr(s, "guidance", "") or ""),
            confidence=_safe_confidence(getattr(s, "confidence", 0.0)),
            validation_count=_safe_validation_count(getattr(s, "validation_count", 0)),
            last_used=getattr(s, "last_used", None),
            source_trace_ids=_safe_source_trace_ids(getattr(s, "source_trace_ids", None)),
            created_at=str(getattr(s, "created_at", "") or ""),
            updated_at=str(getattr(s, "updated_at", "") or ""),
        )
        for s in sorted_strategies
    ]

    return TraceLearningDashboardResponse(
        strategies_learned_this_week=len(strategies_this_week),
        strategy_hit_rate=round(hit_rate, 4),
        top_strategies=top_strategies_response,
        trace_coverage_percent=round(trace_coverage * 100, 2),
        total_traces=total_traces,
        total_strategies=total_strategies,
    )
