"""Registry assembly, search, index, and public query functions.

Extracted from the original monolithic public_mcp.py (#3928).
"""

from __future__ import annotations

import re
from copy import deepcopy
from typing import Any

from apps.backend.api.public_mcp._constants import (
    _TOOL_SEARCH_NAME,
)
from apps.backend.api.public_mcp._schemas_legacy import (
    _LEGACY_PUBLIC_MCP_TOOLS,
)
from apps.backend.api.public_mcp._schemas_native import (
    _NATIVE_PUBLIC_MCP_TOOLS,
    _WORKFLOW_PUBLIC_MCP_TOOLS,
    _PERSONA_PUBLIC_MCP_TOOLS,
    _canonicalize_live_public_tools,
    _inference_manifest_tools,
    _legacy_to_canonical_map,
    _sanitize_public_mcp_text,
    _tool_search_tool_schema,
    _parity_catalog_tools,
    _tool_category,
    _compact_capability_metadata,
    _index_capability_metadata,
)
from apps.backend.mcp.agent_card_tools import AGENT_CARD_TOOLS
from apps.backend.mcp.calendar_tools import CALENDAR_MCP_TOOLS
from apps.backend.mcp.places_tools import PLACES_MCP_TOOLS

_LEGACY_PUBLIC_MCP_TOOLS = _sanitize_public_mcp_text(_LEGACY_PUBLIC_MCP_TOOLS)
_NATIVE_PUBLIC_MCP_TOOLS = _sanitize_public_mcp_text(_NATIVE_PUBLIC_MCP_TOOLS)
_WORKFLOW_PUBLIC_MCP_TOOLS = _sanitize_public_mcp_text(_WORKFLOW_PUBLIC_MCP_TOOLS)
_PERSONA_PUBLIC_MCP_TOOLS = _sanitize_public_mcp_text(_PERSONA_PUBLIC_MCP_TOOLS)

PUBLIC_MCP_TOOLS: list[dict[str, Any]] = _sanitize_public_mcp_text([
    *_canonicalize_live_public_tools(),
    *_NATIVE_PUBLIC_MCP_TOOLS,
    *_inference_manifest_tools(),
    *CALENDAR_MCP_TOOLS,
    *PLACES_MCP_TOOLS,
    *AGENT_CARD_TOOLS,
    *_WORKFLOW_PUBLIC_MCP_TOOLS,
    *_PERSONA_PUBLIC_MCP_TOOLS,
    _tool_search_tool_schema(),
])
_PUBLIC_MCP_CATALOG_TOOLS: list[dict[str, Any]] = []
_catalog_seen: set[str] = set()
for _tool in [*PUBLIC_MCP_TOOLS, *_parity_catalog_tools()]:
    _name = str(_tool.get("name") or "")
    if not _name or _name in _catalog_seen:
        continue
    if live_tool := next((tool for tool in PUBLIC_MCP_TOOLS if tool.get("name") == _name), None):
        _PUBLIC_MCP_CATALOG_TOOLS.append(live_tool)
    else:
        _PUBLIC_MCP_CATALOG_TOOLS.append(_sanitize_public_mcp_text(_tool))
    _catalog_seen.add(_name)
_LEGACY_TO_CANONICAL = _legacy_to_canonical_map()
_CANONICAL_TO_LEGACY: dict[str, str] = {}
for _legacy_name, _canonical_name in _LEGACY_TO_CANONICAL.items():
    _CANONICAL_TO_LEGACY.setdefault(_canonical_name, _legacy_name)
_PUBLIC_TOOL_BY_NAME: dict[str, dict[str, Any]] = {}
for _tool in PUBLIC_MCP_TOOLS:
    _PUBLIC_TOOL_BY_NAME[str(_tool["name"])] = _tool
    for _alias in _tool.get("aliases") or []:
        _PUBLIC_TOOL_BY_NAME[str(_alias)] = _tool
_PUBLIC_CATALOG_TOOL_BY_NAME = {str(_tool["name"]): _tool for _tool in _PUBLIC_MCP_CATALOG_TOOLS}


def canonical_public_mcp_tool_name(tool_name: str) -> str | None:
    """Return the canonical ``ww.*`` name for a public MCP tool or alias."""

    if tool_name == _TOOL_SEARCH_NAME:
        return tool_name
    if tool_name in _LEGACY_TO_CANONICAL:
        return _LEGACY_TO_CANONICAL[tool_name]
    if tool_name in _PUBLIC_TOOL_BY_NAME:
        return str(_PUBLIC_TOOL_BY_NAME[tool_name]["name"])
    return None


def is_public_mcp_tool(tool_name: str) -> bool:
    return canonical_public_mcp_tool_name(tool_name) is not None


def _legacy_dispatch_name(tool_name: str) -> str:
    canonical = canonical_public_mcp_tool_name(tool_name)
    if canonical is None:
        return tool_name
    return _CANONICAL_TO_LEGACY.get(canonical, tool_name)


def get_public_mcp_tool_schema(tool_name: str) -> dict[str, Any]:
    """Return the canonical tool schema for a public MCP tool or compatibility alias."""

    canonical = canonical_public_mcp_tool_name(tool_name)
    if canonical is None and tool_name not in _PUBLIC_CATALOG_TOOL_BY_NAME:
        raise KeyError(tool_name)
    return deepcopy(_PUBLIC_TOOL_BY_NAME.get(canonical or "") or _PUBLIC_CATALOG_TOOL_BY_NAME[tool_name])


def get_public_mcp_tool_index() -> list[dict[str, Any]]:
    """Return progressive-disclosure index rows without full JSON schemas.

    The catalog is intentionally compact: default ``ww`` namespace and callable
    tools are implied so tool growth does not force agents to download repeated
    metadata before asking for the one schema they need.
    """

    rows: list[dict[str, Any]] = []
    for tool in _PUBLIC_MCP_CATALOG_TOOLS:
        description = str(tool.get("description", ""))
        row = {
            "name": tool["name"],
            "description": description if len(description) <= 120 else f"{description[:117]}...",
            "category": tool.get("category", _tool_category(str(tool["name"]))),
        }
        if (namespace := tool.get("namespace", "ww")) != "ww":
            row["namespace"] = namespace
        if not bool(tool.get("callable", True)):
            row["callable"] = False
        if capability := _index_capability_metadata(tool):
            row["capability"] = capability
        rows.append(row)
    return rows


_SEARCH_TOKEN_RE = re.compile(r"[a-z0-9]+")


def _search_text(tool: dict[str, Any]) -> str:
    schema = tool.get("inputSchema") if isinstance(tool.get("inputSchema"), dict) else {}
    properties = schema.get("properties") if isinstance(schema, dict) else {}
    prop_bits: list[str] = []
    if isinstance(properties, dict):
        for prop_name, prop_schema in properties.items():
            prop_bits.append(str(prop_name))
            if isinstance(prop_schema, dict):
                prop_bits.append(str(prop_schema.get("description") or ""))
                enum_values = prop_schema.get("enum") or []
                for ev in enum_values:
                    prop_bits.append(str(ev))
    aliases = " ".join(str(alias) for alias in tool.get("aliases") or [])
    return " ".join(
        [
            str(tool.get("name") or ""),
            aliases,
            str(tool.get("description") or ""),
            str(tool.get("category") or ""),
            " ".join(prop_bits),
        ]
    ).lower()


def _tokens(value: str) -> set[str]:
    return set(_SEARCH_TOKEN_RE.findall(value.lower()))


def search_public_mcp_tools(intent: str, *, limit: int = 5) -> list[dict[str, Any]]:
    """Rank public MCP tools by deterministic lexical match against an intent."""

    query = str(intent or "").strip()
    if not query:
        return []
    query_tokens = _tokens(query)
    scored: list[tuple[int, dict[str, Any]]] = []
    for tool in _PUBLIC_MCP_CATALOG_TOOLS:
        name = str(tool.get("name") or "")
        text = _search_text(tool)
        text_tokens = _tokens(text)
        overlap = len(query_tokens & text_tokens)
        score = overlap * 10
        compact_query = query.lower().replace(" ", ".")
        if compact_query and compact_query in name:
            score += 50
        if any(token in name for token in query_tokens):
            score += 15
        if score:
            scored.append((score, tool))

    ranked = sorted(scored, key=lambda item: (-item[0], str(item[1].get("name") or "")))[: max(1, limit)]
    return [
        {
            "tool_id": tool["name"],
            "name": tool["name"],
            "description": tool.get("description", ""),
            "category": tool.get("category", _tool_category(str(tool["name"]))),
            "score": score,
            "aliases": list(tool.get("aliases") or []),
            "capability": _compact_capability_metadata(tool),
        }
        for score, tool in ranked
    ]
