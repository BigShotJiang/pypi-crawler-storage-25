"""Native ww.* MCP tool schema definitions and schema-building helpers.

Extracted from the original monolithic public_mcp.py (#3928).
"""

from __future__ import annotations

import json
import re
from copy import deepcopy
from typing import Any


from apps.backend.api.public_mcp._constants import (
    _PARITY_JSON_PATH,
    _TOOL_SEARCH_NAME,
    logger,
)
from apps.backend.api.public_mcp._schemas_legacy import (
    _LEGACY_PUBLIC_MCP_TOOLS,
)

_NATIVE_PUBLIC_MCP_TOOLS: list[dict[str, Any]] = [
    {
        "name": "ww.browser.run",
        "description": "Run a Browser Workbench task through the tenant sandbox policy.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task": {"type": "string", "description": "Task for the browser workbench to perform."},
                "start_url": {"type": "string", "description": "Start URL for the browser task."},
                "url": {"type": "string", "description": "Alias for start_url."},
                "mode": {
                    "type": "string",
                    "enum": ["deterministic", "agentic"],
                    "default": "deterministic",
                    "description": "Browser execution mode.",
                },
                "work_item_id": {"type": "string", "description": "Optional WorkItem ID for trace attribution."},
                "timeblock_id": {"type": "string", "description": "Optional TimeBlock ID for trace attribution."},
                "allowed_url_patterns": {
                    "type": "array",
                    "items": {"type": "string"},
                    "default": [],
                    "description": "Allowed URL origins for this run.",
                },
                "public_read_only_default": {
                    "type": "boolean",
                    "default": False,
                    "description": "Allow deterministic read-only public web navigation.",
                },
                "side_effecting": {
                    "type": "boolean",
                    "default": False,
                    "description": "Whether the requested task has side effects.",
                },
                "downloads_allowed": {
                    "type": "boolean",
                    "default": False,
                    "description": "Whether downloads are requested and policy must allow an artifact temp dir.",
                },
                "artifact_temp_dir": {
                    "type": "string",
                    "description": "Temporary artifact directory for governed downloads.",
                },
                "steps": {
                    "type": "array",
                    "items": {"type": "object"},
                    "description": "Optional deterministic step list for CLI-style execution.",
                },
            },
            "required": ["task"],
            "anyOf": [{"required": ["start_url"]}, {"required": ["url"]}],
        },
    },
    {
        "name": "ww.browser.sandbox_evaluate",
        "description": (
            "Evaluate a URL against the browser sandbox policy. Returns an allow/deny "
            "verdict with reason, without executing any browser action. Use for pre-flight "
            "checks before running browser tasks."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "URL to evaluate against the sandbox policy.",
                },
                "task_mode": {
                    "type": "string",
                    "enum": ["deterministic", "agentic"],
                    "default": "deterministic",
                    "description": "Browser task mode for evaluation.",
                },
                "side_effecting": {
                    "type": "boolean",
                    "default": False,
                    "description": "Whether the action has side effects (forms, downloads, uploads).",
                },
            },
            "required": ["url"],
        },
    },
    {
        "name": "ww.browser.sandbox_policy",
        "description": (
            "Read the current browser sandbox policy configuration for the workspace. "
            "Returns the allowlist, read-only public-web flag, and artifact temp dir status."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "ww.session.intake_queue.status",
        "description": "Read per-member session intake queue counters for Slack, email, and Teams-originated work.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "member_id": {
                    "type": "string",
                    "description": "Optional member or agent ID. Omit to read the caller-scoped queue.",
                },
                "channel": {
                    "type": "string",
                    "enum": ["all", "slack", "email", "teams"],
                    "default": "all",
                    "description": "Optional intake channel filter.",
                },
            },
        },
        "namespace": "ww",
        "category": "sessions",
        "side_effect": False,
    },
    {
        "name": "ww.skill.import",
        "description": "Import or dry-run a governed SkillSource package into the authenticated workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "Workspace ID; must match the authenticated workspace.",
                },
                "origin": {
                    "type": "string",
                    "description": "SkillSource origin URL or local package path.",
                },
                "origin_kind": {
                    "type": "string",
                    "enum": ["github", "local", "registry", "mcp-server"],
                    "description": "Kind of SkillSource origin being imported.",
                },
                "dry_run": {
                    "type": "boolean",
                    "description": "Validate and preview the import without installing it.",
                    "default": True,
                },
                "customize": {
                    "type": "boolean",
                    "description": "Apply a customization overlay before import.",
                    "default": False,
                },
                "reject_on_warning": {
                    "type": "boolean",
                    "description": "Reject the import if warnings are produced.",
                    "default": False,
                },
                "customization_overlay": {
                    "type": "object",
                    "description": "Optional SkillCustomizationOverlay payload.",
                    "properties": {
                        "notes": {"type": "string"},
                        "field_overrides": {"type": "object"},
                        "removed_paths": {"type": "array", "items": {"type": "string"}},
                    },
                },
            },
            "required": ["workspace_id", "origin", "origin_kind"],
        },
        "namespace": "ww",
        "category": "skills",
        "callable": True,
        "intent_hints": [
            "skill source import",
            "import skill",
            "dry run skill import",
            "skill package install",
        ],
    },
    {
        "name": "ww.skill.curator.run",
        "description": "Run the proposal-only Skill Curator for the authenticated workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "Workspace ID; must match the authenticated workspace.",
                },
                "weights": {
                    "type": "object",
                    "description": "Optional scoring weights for the curator run.",
                    "properties": {
                        "usage": {"type": "number"},
                        "pass_rate": {"type": "number"},
                        "recency": {"type": "number"},
                        "consolidation": {"type": "number"},
                        "richness": {"type": "number"},
                    },
                },
            },
            "required": ["workspace_id"],
        },
        "namespace": "ww",
        "category": "skills",
        "callable": True,
        "intent_hints": [
            "skill curator run",
            "run skill audit",
            "skill hygiene proposals",
        ],
    },
    {
        "name": "ww.skill.curator.latest",
        "description": "Read the latest Skill Curator run summary for the authenticated workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "Workspace ID; must match the authenticated workspace.",
                },
            },
            "required": ["workspace_id"],
        },
        "namespace": "ww",
        "category": "skills",
        "callable": True,
        "intent_hints": [
            "skill curator latest",
            "latest skill curator run",
            "read skill hygiene run",
        ],
    },
    {
        "name": "ww.skill.curator.list",
        "description": "List Skill Curator proposals for the authenticated workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "Workspace ID; must match the authenticated workspace.",
                },
                "status": {
                    "type": "string",
                    "enum": ["pending", "accepted", "rejected", "deferred"],
                    "description": "Optional proposal status filter.",
                },
            },
            "required": ["workspace_id"],
        },
        "namespace": "ww",
        "category": "skills",
        "callable": True,
        "intent_hints": [
            "skill curator list",
            "list skill curator proposals",
            "skill hygiene proposal queue",
        ],
    },
    {
        "name": "ww.skill.curator.respond",
        "description": "Record an accept, reject, or defer decision for a Skill Curator proposal.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "Workspace ID; must match the authenticated workspace.",
                },
                "proposal_id": {
                    "type": "string",
                    "description": "Skill Curator proposal ID.",
                },
                "decision": {
                    "type": "string",
                    "enum": ["accept", "reject", "defer"],
                    "description": "Decision to record.",
                },
                "reason": {
                    "type": "string",
                    "description": "Decision rationale.",
                    "default": "",
                },
                "actor_id": {
                    "type": "string",
                    "description": "Member or agent actor recording the decision; MCP writes use validated side_effect_proof.actor_id.",
                },
            },
            "required": ["workspace_id", "proposal_id", "decision"],
        },
        "namespace": "ww",
        "category": "skills",
        "callable": True,
        "intent_hints": [
            "skill curator respond",
            "accept skill curator proposal",
            "reject skill curator proposal",
            "defer skill hygiene proposal",
        ],
    },
    {
        "name": "ww.identity.readiness",
        "description": "Return read-only Zara-owned provider identity readiness for the workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
        "namespace": "ww",
        "category": "identity",
        "callable": True,
        "intent_hints": [
            "identity readiness",
            "zara identity readiness",
            "agent identity readiness",
        ],
    },
    {
        "name": "ww.agent.identity",
        "description": "Return per-purpose Zara-owned provider identity status (email, calendar, meeting, voice, payment).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {
                    "type": "string",
                    "description": "Agent ID (default: zara)",
                    "default": "zara",
                },
            },
        },
        "namespace": "ww",
        "category": "identity",
        "callable": True,
        "intent_hints": [
            "agent identity",
            "zara identity",
            "identity status",
            "provider identity",
        ],
    },
    {
        "name": "ww.inbox.list",
        "description": "List pending inbox judgment items.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Max pending items", "default": 20},
            },
        },
        "namespace": "ww",
        "category": "inbox",
        "callable": True,
        "intent_hints": ["inbox list", "pending approvals", "judgment feed"],
    },
    {
        "name": "ww.inbox.approve",
        "description": "Approve a pending inbox judgment item.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "request_id": {"type": "string", "description": "Approval or judgment request ID"},
                "actor_id": {"type": "string", "description": "User ID approving"},
            },
            "required": ["request_id", "actor_id"],
        },
        "namespace": "ww",
        "category": "inbox",
        "callable": True,
        "intent_hints": ["approve pending approval", "approve judgment", "inbox approve"],
    },
    {
        "name": "ww.inbox.reject",
        "description": "Reject a pending inbox judgment item.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "request_id": {"type": "string", "description": "Approval or judgment request ID"},
                "actor_id": {"type": "string", "description": "User ID rejecting"},
                "reason": {"type": "string", "description": "Rejection reason", "default": ""},
            },
            "required": ["request_id", "actor_id"],
        },
        "namespace": "ww",
        "category": "inbox",
        "callable": True,
        "intent_hints": ["reject pending approval", "reject judgment", "inbox reject"],
    },
    {
        "name": "ww.inbox.conversations",
        "description": "List inbox conversations across channels.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "channel": {"type": "string", "description": "Optional channel filter"},
                "limit": {"type": "integer", "description": "Max conversations", "default": 50},
                "offset": {"type": "integer", "description": "Pagination offset", "default": 0},
            },
        },
        "namespace": "ww",
        "category": "inbox",
        "callable": True,
        "intent_hints": ["inbox conversations", "email conversations", "conversation inbox"],
    },
    # ── Wallet tool family (#2366) ──────────────────────────────────────
    {
        "name": "ww.wallet.readiness",
        "description": "Check crypto wallet readiness for the workspace.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["wallet readiness", "crypto readiness", "wallet ready"],
    },
    {
        "name": "ww.wallet.policy",
        "description": "Return the workspace crypto wallet policy (caps, allowlists, slippage, MEV).",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["wallet policy", "crypto policy", "wallet limits"],
    },
    {
        "name": "ww.wallet.address",
        "description": "Derive a wallet address for a given chain family and network.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "chain": {"type": "string", "description": "Chain family (evm, solana, cosmos, bitcoin)"},
                "network": {"type": "string", "description": "Network ID", "default": "mainnet"},
                "index": {"type": "integer", "description": "Derivation index", "default": 0},
            },
            "required": ["chain"],
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["wallet address", "derive address", "crypto address"],
    },
    {
        "name": "ww.wallet.balance",
        "description": "Query wallet balance for a chain and network.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "chain": {"type": "string", "description": "Chain family"},
                "network": {"type": "string", "description": "Network ID", "default": "mainnet"},
                "token": {"type": "string", "description": "Token contract address (optional)"},
            },
            "required": ["chain"],
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["wallet balance", "crypto balance", "token balance"],
    },
    {
        "name": "ww.wallet.sign",
        "description": "Sign a transaction payload using the configured KeyCustody backend.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "chain": {"type": "string", "description": "Chain family"},
                "payload": {"type": "string", "description": "Transaction payload JSON"},
            },
            "required": ["chain", "payload"],
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["wallet sign", "sign transaction", "crypto sign"],
    },
    {
        "name": "ww.wallet.broadcast",
        "description": "Broadcast a signed transaction to the network.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "chain": {"type": "string", "description": "Chain family"},
                "network": {"type": "string", "description": "Network ID", "default": "mainnet"},
                "signed_tx": {"type": "string", "description": "Signed transaction JSON"},
            },
            "required": ["chain", "signed_tx"],
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["wallet broadcast", "broadcast transaction", "send transaction"],
    },
    {
        "name": "ww.wallet.tx_list",
        "description": "List recent wallet transactions.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "chain": {"type": "string", "description": "Chain family"},
                "network": {"type": "string", "description": "Network ID", "default": "mainnet"},
                "limit": {"type": "integer", "description": "Max results", "default": 20},
            },
            "required": ["chain"],
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["wallet transactions", "tx history", "crypto transactions"],
    },
    {
        "name": "ww.wallet.tx_get",
        "description": "Get details of a specific transaction by hash.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tx_hash": {"type": "string", "description": "Transaction hash"},
                "chain": {"type": "string", "description": "Chain family"},
            },
            "required": ["tx_hash", "chain"],
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["wallet tx", "transaction details", "tx status"],
    },
    {
        "name": "ww.wallet.custody_status",
        "description": "Return the custody backend status for the workspace.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": ["custody status", "key custody", "wallet backend"],
    },
    # ── Multi-wallet parity (#3625 / slice 8e) ──────────────────────────
    {
        "name": "ww.wallet.policies.list",
        "description": "List every wallet policy row owned by the caller's tenant (issue #3625).",
        "inputSchema": {
            "type": "object",
            "properties": {},
            "additionalProperties": False,
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": [
            "wallet policies",
            "list wallets",
            "multi-wallet inventory",
        ],
    },
    {
        "name": "ww.wallet.policy.get",
        "description": "Read a per-wallet policy by wallet_id (issue #3625).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "wallet_id": {
                    "type": "string",
                    "description": "Wallet identifier (1..64 chars, [A-Za-z0-9._:-]).",
                    "minLength": 1,
                    "maxLength": 64,
                },
            },
            "required": ["wallet_id"],
            "additionalProperties": False,
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": [
            "wallet policy get",
            "read wallet policy",
            "per-wallet policy",
        ],
    },
    {
        "name": "ww.wallet.policy.set",
        "description": "Upsert a per-wallet policy (issue #3625). Write surface; emits Decision Trace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "wallet_id": {
                    "type": "string",
                    "description": "Wallet identifier (1..64 chars, [A-Za-z0-9._:-]).",
                    "minLength": 1,
                    "maxLength": 64,
                },
                "daily_cap_usd": {
                    "type": "string",
                    "description": "Daily cap as a decimal string.",
                    "default": "0",
                },
                "approval_threshold_usd": {
                    "type": "string",
                    "description": "Multi-approver threshold (decimal string).",
                    "default": "0",
                },
                "max_slippage_bps": {
                    "type": "integer",
                    "description": "Slippage cap in basis points (0..10000).",
                    "minimum": 0,
                    "maximum": 10000,
                    "default": 300,
                },
                "allowlisted_addresses": {
                    "type": "array",
                    "description": "Per-chain allowlist entries.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "chain_family": {"type": "string"},
                            "network_id": {"type": "string"},
                            "address": {"type": "string"},
                        },
                        "required": ["chain_family", "network_id", "address"],
                        "additionalProperties": False,
                    },
                    "default": [],
                },
                "mev_protection_required": {
                    "type": "boolean",
                    "description": "Toggle MEV protection requirement.",
                    "default": True,
                },
                "mev_threshold_usd": {
                    "type": "string",
                    "description": "MEV protection threshold (decimal string).",
                    "default": "1000",
                },
                "allowed_chain_families": {
                    "type": "array",
                    "description": "Chain families this wallet is allowed to operate on.",
                    "items": {"type": "string"},
                    "default": [],
                },
                "compliance_screening_enabled": {
                    "type": "boolean",
                    "description": "Toggle compliance screening.",
                    "default": True,
                },
                "enabled": {
                    "type": "boolean",
                    "description": "Master toggle for the wallet policy.",
                    "default": False,
                },
                "actor_email": {
                    "type": "string",
                    "description": "Caller email captured in the wallet_policy_update Decision Trace.",
                },
            },
            "required": ["wallet_id"],
            "additionalProperties": False,
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": [
            "wallet policy set",
            "update wallet policy",
            "configure wallet",
        ],
    },
    {
        "name": "ww.wallet.transactions.list",
        "description": "List wallet transactions for the tenant (issue #3625).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "wallet_id": {
                    "type": "string",
                    "description": "Restrict to one wallet_id; omit to scan every wallet.",
                    "minLength": 1,
                    "maxLength": 64,
                },
                "status": {
                    "type": "string",
                    "enum": ["pending", "signed", "denied", "failed"],
                    "description": "Filter by transaction status.",
                },
                "cursor": {
                    "type": "string",
                    "description": "Opaque pagination cursor returned by a previous call.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max rows per page (1..500).",
                    "minimum": 1,
                    "maximum": 500,
                    "default": 50,
                },
            },
            "required": [],
            "additionalProperties": False,
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": [
            "wallet transactions",
            "tx inbox",
            "pending transactions",
        ],
    },
    {
        "name": "ww.wallet.transactions.sign",
        "description": "Preflight-gated sign of a pending wallet transaction (issue #3625).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tx_id": {
                    "type": "string",
                    "description": "Transaction id from transactions.list.",
                    "minLength": 1,
                },
                "wallet_id": {
                    "type": "string",
                    "description": "Optional wallet scope for the sign call.",
                    "minLength": 1,
                    "maxLength": 64,
                },
                "actor_email": {
                    "type": "string",
                    "description": "Caller email captured in the Decision Trace.",
                },
            },
            "required": ["tx_id"],
            "additionalProperties": False,
        },
        "namespace": "ww",
        "category": "wallet",
        "callable": True,
        "intent_hints": [
            "wallet sign transaction",
            "sign pending tx",
            "approve wallet payment",
        ],
    },
    # ── Cross-tenant Zara coordination (#3625 / family J) ──────────────
    {
        "name": "ww.zara.coordinate.send",
        "description": "Dispatch a directive to one other Zara in the caller's org.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "target_tenant_id": {
                    "type": "string",
                    "description": "Same-org tenant id to coordinate with.",
                    "minLength": 1,
                    "maxLength": 128,
                },
                "directive": {
                    "type": "string",
                    "description": "Directive payload (1..4096 chars).",
                    "minLength": 1,
                    "maxLength": 4096,
                },
                "intent_class": {
                    "type": "string",
                    "description": "Intent label propagated to the receiving Zara.",
                    "default": "KNOWLEDGE_WORK",
                    "minLength": 1,
                    "maxLength": 64,
                },
                "actor_email": {
                    "type": "string",
                    "description": "Caller email captured in the coordination trace.",
                },
            },
            "required": ["target_tenant_id", "directive"],
            "additionalProperties": False,
        },
        "namespace": "ww",
        "category": "zara",
        "callable": True,
        "intent_hints": [
            "zara coordinate",
            "delegate to zara",
            "cross-tenant directive",
        ],
    },
    {
        "name": "ww.zara.coordinate.show",
        "description": "Return merged status + lease view for one coordination.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "coordination_id": {
                    "type": "string",
                    "description": "Coordination id from a previous coordinate / broadcast call.",
                    "minLength": 1,
                },
            },
            "required": ["coordination_id"],
            "additionalProperties": False,
        },
        "namespace": "ww",
        "category": "zara",
        "callable": True,
        "intent_hints": [
            "zara coordination status",
            "coordination show",
            "directive status",
        ],
    },
    {
        "name": "ww.zara.coordinate.broadcast",
        "description": "Broadcast a directive to every sub-tenant Zara in the caller's org.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "directive": {
                    "type": "string",
                    "description": "Directive payload (1..4096 chars).",
                    "minLength": 1,
                    "maxLength": 4096,
                },
                "intent_class": {
                    "type": "string",
                    "description": "Intent label propagated to receiving Zaras.",
                    "default": "KNOWLEDGE_WORK",
                    "minLength": 1,
                    "maxLength": 64,
                },
                "target_emails": {
                    "type": "array",
                    "description": "Narrow the broadcast to specific sub-tenant owner emails.",
                    "items": {"type": "string"},
                    "maxItems": 128,
                },
                "actor_email": {
                    "type": "string",
                    "description": "Caller email captured in the coordination trace.",
                },
            },
            "required": ["directive"],
            "additionalProperties": False,
        },
        "namespace": "ww",
        "category": "zara",
        "callable": True,
        "intent_hints": [
            "zara coordination broadcast",
            "fan-out directive",
            "broadcast to sub-tenants",
        ],
    },
    # ── Support tool (#2348) ───────────────────────────────────────────
    {
        "name": "ww.support.file_bug",
        "description": "File a support bug report ticket via MCP.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "summary": {"type": "string", "description": "Bug summary / subject"},
                "category": {"type": "string", "description": "Bug category (e.g. email, calendar, payment)", "default": "general"},
                "evidence_refs": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional evidence envelope IDs to attach",
                    "default": [],
                },
                "attach_decision_trace": {"type": "boolean", "description": "Attach decision trace context", "default": True},
            },
            "required": ["summary"],
        },
        "namespace": "ww",
        "category": "support",
        "callable": True,
        "intent_hints": ["file bug", "report bug", "support ticket", "bug report"],
    },
    # ── Support consent tool (#2342) ───────────────────────────────────
    {
        "name": "ww.support.consent",
        "description": "List or approve investigation consent envelopes for a workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "enum": ["list", "approve", "revoke", "check"],
                    "description": "Action to perform on investigation consent.",
                    "default": "list",
                },
                "tenant_id": {"type": "string", "description": "Workspace ID"},
                "investigation_id": {"type": "string", "description": "Filter by investigation ID (list action)"},
                "consent_id": {"type": "string", "description": "Consent envelope ID (approve/revoke/check action)"},
                "granted_by": {"type": "string", "description": "User granting consent (approve action)"},
                "scope": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Consent scopes: data_access, ticket_filing, agent_communication (approve action)",
                    "default": ["data_access"],
                },
                "duration_hours": {
                    "type": "integer",
                    "description": "Consent duration in hours (approve action)",
                    "default": 24,
                },
                "reason": {"type": "string", "description": "Revocation reason (revoke action)"},
            },
            "required": ["action", "tenant_id"],
        },
        "namespace": "ww",
        "category": "support",
        "callable": True,
        "intent_hints": [
            "investigation consent",
            "list consent",
            "approve consent",
            "revoke consent",
            "check consent",
            "support consent",
        ],
    },
    # ── Deployment profile tools (#2394) ──────────────────────────────
    {
        "name": "ww.profile.get",
        "description": "Return the current deployment profile configuration.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww",
        "category": "profile",
        "callable": True,
        "intent_hints": ["profile", "deployment profile", "personal profile", "current profile"],
    },
    {
        "name": "ww.profile.set",
        "description": "Set the deployment profile for this workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "profile": {
                    "type": "string",
                    "description": "Profile name (solo_dogfood, self_host_production, managed_saas, local_native, personal_os)",
                    "enum": ["solo_dogfood", "self_host_production", "managed_saas", "local_native", "personal_os"],
                },
            },
            "required": ["profile"],
        },
        "namespace": "ww",
        "category": "profile",
        "callable": True,
        "intent_hints": ["set profile", "change profile", "switch profile"],
    },
    {
        "name": "ww.profile.list",
        "description": "List all available deployment profiles.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww",
        "category": "profile",
        "callable": True,
        "intent_hints": ["list profiles", "available profiles", "deployment options"],
    },
    # ── Zara identity purposes (#2231) ────────────────────────────────
    {
        "name": "ww.identity.purposes",
        "description": "List Zara-owned provider identity purposes with readiness status.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Agent ID (default: zara)", "default": "zara"},
            },
        },
        "namespace": "ww",
        "category": "identity",
        "callable": True,
        "intent_hints": ["identity purposes", "zara purposes", "provider identity", "agent purposes"],
    },
    {
        "name": "ww.identity.purpose_status",
        "description": "Get the provider identity status for a specific agent purpose.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Agent ID (default: zara)", "default": "zara"},
                "purpose": {
                    "type": "string",
                    "description": "Purpose to check (email_send, calendar_read, calendar_write, meeting_join, payment_initiate, payment_approve, voice_call, crypto_wallet)",
                },
            },
            "required": ["purpose"],
        },
        "namespace": "ww",
        "category": "identity",
        "callable": True,
        "intent_hints": ["purpose status", "identity readiness", "provider auth"],
    },
    # ── Connector tools ───────────────────────────────────────────────────
    {
        "name": "ww.connector.import.openapi",
        "description": "Import an OpenAPI or Swagger document as a tenant-scoped connector.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "spec_url": {"type": "string", "description": "OpenAPI or Swagger spec URL."},
                "base_url": {"type": "string", "description": "Optional API base URL override."},
                "name": {"type": "string", "description": "Optional connector display name."},
                "description": {"type": "string", "description": "Optional connector description."},
                "auth": {
                    "type": "object",
                    "description": "Optional connector auth configuration.",
                    "default": {},
                },
            },
            "required": ["spec_url"],
        },
        "namespace": "ww",
        "category": "connector",
        "callable": True,
        "intent_hints": [
            "import openapi connector",
            "openapi tool factory",
            "swagger connector import",
        ],
    },
    {
        "name": "ww.connector.health",
        "description": "Get per-connector health metrics: circuit breaker state, success rate, latency percentiles, retry budget.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "connector_id": {
                    "type": "string",
                    "description": "Connector ID to check. Omit to return health for all connectors.",
                },
            },
        },
        "namespace": "ww",
        "category": "connector",
        "callable": True,
        "intent_hints": [
            "connector health",
            "circuit breaker",
            "connector uptime",
            "connector status",
            "connector metrics",
        ],
    },
    {
        "name": "ww.connector.status",
        "description": "Return the tenant connector availability map with setup commands and Decision Trace evidence.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
        "namespace": "ww",
        "category": "connector",
        "callable": True,
        "intent_hints": [
            "connector availability",
            "connectors status",
            "connector setup",
            "available connectors",
        ],
    },
    # Issue #3585: PM connector OAuth auth tool.
    {
        "name": "ww.connector.auth",
        "description": "Initiate OAuth2 authorization for a PM connector (JIRA, Linear, Asana, Trello). Returns the authorization URL to redirect the user to.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "provider": {
                    "type": "string",
                    "description": "PM provider key: jira, linear, asana, or trello.",
                },
                "redirect_uri": {
                    "type": "string",
                    "description": "Override OAuth callback URI. Defaults to the canonical Workweaver callback.",
                },
            },
            "required": ["provider"],
        },
        "namespace": "ww",
        "category": "connector",
        "callable": True,
        "intent_hints": [
            "authorize connector",
            "connector oauth",
            "connector auth",
            "pm connector auth",
        ],
    },
    # -- Voice persona tools (#2798) --
    {
        "name": "ww.voice.persona.create",
        "description": "Create a new voice persona for the workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Persona display name"},
                "voice_id": {"type": "string", "description": "TTS voice identifier", "default": "ara"},
                "language": {"type": "string", "description": "Language code", "default": "en"},
                "speaking_rate": {"type": "number", "description": "TTS speed multiplier", "default": 1.0},
                "pitch": {"type": "number", "description": "TTS pitch adjustment", "default": 0.0},
                "from_template": {"type": "string", "description": "Template ID to seed from"},
            },
            "required": ["name"],
        },
        "namespace": "ww", "category": "voice", "callable": True,
        "intent_hints": ["create voice persona", "new voice persona"],
    },
    {
        "name": "ww.voice.persona.clone.register",
        "description": "Register provider-backed ownership for a custom voice clone before using it in a persona.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "voice_id": {"type": "string", "description": "Custom voice clone identifier"},
                "name": {"type": "string", "description": "Clone display name"},
                "provider": {"type": "string", "description": "Clone provider", "default": "custom"},
                "provider_clone_id": {
                    "type": "string",
                    "description": "Provider clone identifier",
                    "minLength": 1,
                    "pattern": "\\S",
                },
                "proof_ref": {
                    "type": "string",
                    "description": "Ownership proof or evidence reference",
                    "minLength": 1,
                    "pattern": "\\S",
                },
                "description": {"type": "string", "description": "Clone description"},
            },
            "required": ["voice_id"],
            "anyOf": [
                {"required": ["provider_clone_id"]},
                {"required": ["proof_ref"]},
            ],
        },
        "namespace": "ww", "category": "voice", "callable": True,
        "intent_hints": ["register voice clone", "custom voice ownership", "voice clone proof"],
    },
    {
        "name": "ww.voice.persona.list",
        "description": "List all voice personas for the workspace.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww", "category": "voice", "callable": True,
        "intent_hints": ["list personas", "voice personas"],
    },
    {
        "name": "ww.voice.catalog.list",
        "description": "List built-in and tenant-owned cloned voices available to the workspace.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww", "category": "voice", "callable": True,
        "intent_hints": ["list voices", "voice catalog", "available voices"],
    },
    {
        "name": "ww.voice.persona.get",
        "description": "Get a specific voice persona by ID.",
        "inputSchema": {
            "type": "object",
            "properties": {"persona_id": {"type": "string", "description": "Persona ID"}},
            "required": ["persona_id"],
        },
        "namespace": "ww", "category": "voice", "callable": True,
    },
    {
        "name": "ww.voice.persona.update",
        "description": "Update fields on an existing voice persona.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "persona_id": {"type": "string", "description": "Persona ID"},
                "name": {"type": "string"}, "voice_id": {"type": "string"},
                "language": {"type": "string"}, "speaking_rate": {"type": "number"},
                "pitch": {"type": "number"}, "greeting_script": {"type": "string"},
                "hold_message": {"type": "string"}, "transfer_message": {"type": "string"},
            },
            "required": ["persona_id"],
        },
        "namespace": "ww", "category": "voice", "callable": True,
    },
    {
        "name": "ww.voice.persona.delete",
        "description": "Soft-delete a voice persona (sets disabled=true).",
        "inputSchema": {
            "type": "object",
            "properties": {"persona_id": {"type": "string", "description": "Persona ID"}},
            "required": ["persona_id"],
        },
        "namespace": "ww", "category": "voice", "callable": True,
    },
    {
        "name": "ww.voice.persona.templates",
        "description": "List available voice persona templates.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww", "category": "voice", "callable": True,
    },
    # ------------------------------------------------------------------
    # TimeBlock CRUD primitive (W#2785 PR C) — MCP surface over the
    # canonical /api/v1/timeblocks REST API. UTC at rest; soft-delete
    # via state→CANCELLED transition; move is an atomic ledger update.
    # ------------------------------------------------------------------
    {
        "name": "ww.timeblock.list",
        "description": (
            "List TimeBlocks for the workspace. Supports filtering by workspace, "
            "owner, and UTC time window. Read-only — paginated projection over "
            "the canonical AgentWorkLedger. Mirrors GET /api/v1/timeblocks."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "Filter by workspace id (matches metadata.workspace_id).",
                },
                "since": {
                    "type": "string",
                    "description": "UTC lower bound (ISO 8601). Naive timestamps are interpreted as UTC.",
                },
                "until": {
                    "type": "string",
                    "description": "UTC upper bound (ISO 8601). Naive timestamps are interpreted as UTC.",
                },
                "owner": {
                    "type": "string",
                    "description": "Filter by TimeBlock owner_id (the canonical agent_id on the ledger row).",
                },
                "limit": {
                    "type": "integer",
                    "description": "Max items per page (default 50, max 500).",
                    "default": 50,
                    "minimum": 1,
                    "maximum": 500,
                },
                "cursor": {
                    "type": "string",
                    "description": "Opaque pagination cursor returned by the previous list call.",
                },
            },
        },
        "namespace": "ww",
        "category": "timeblock",
        "callable": True,
        "intent_hints": ["list timeblocks", "show today's timeblocks", "agenda"],
    },
    {
        "name": "ww.timeblock.create",
        "description": (
            "Create a TimeBlock for an owner with a UTC start/end window and short "
            "title. Rejects on owner-window conflict unless force=true. The state "
            "change emits an audit-bearing Decision Trace via AgentWorkLedger. "
            "Mirrors POST /api/v1/timeblocks."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {
                    "type": "string",
                    "description": "Workspace id (captured in metadata).",
                },
                "owner_id": {
                    "type": "string",
                    "description": "Owner member id (maps to canonical agent_id).",
                },
                "start_utc": {
                    "type": "string",
                    "description": "UTC start instant (ISO 8601).",
                },
                "end_utc": {
                    "type": "string",
                    "description": "UTC end instant (ISO 8601). Must be strictly after start_utc.",
                },
                "title": {
                    "type": "string",
                    "description": "Short objective for the block.",
                },
                "intent": {
                    "type": "string",
                    "description": "Optional plan / intent free text.",
                    "default": "",
                },
                "force": {
                    "type": "boolean",
                    "description": "Skip owner-window conflict detection. Records forced_overlap=true in metadata.",
                    "default": False,
                },
            },
            "required": ["workspace_id", "owner_id", "start_utc", "end_utc", "title"],
        },
        "namespace": "ww",
        "category": "timeblock",
        "callable": True,
        "intent_hints": ["create timeblock", "schedule a block", "block out time"],
    },
    {
        "name": "ww.timeblock.show",
        "description": (
            "Read a single TimeBlock by id. Returns the full envelope including "
            "owner, window, title, intent, state, outcome, canonical hour bucket, "
            "and metadata. Mirrors GET /api/v1/timeblocks/{id}."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {
                    "type": "string",
                    "description": "TimeBlock id.",
                },
            },
            "required": ["id"],
        },
        "namespace": "ww",
        "category": "timeblock",
        "callable": True,
        "intent_hints": ["show timeblock", "view timeblock"],
    },
    {
        "name": "ww.timeblock.update",
        "description": (
            "Patch one TimeBlock — title, intent, or window. Time edits run owner "
            "conflict detection and reject on overlap unless force=true. Emits a "
            "Decision Trace via AgentWorkLedger. Mirrors PATCH /api/v1/timeblocks/{id}."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {"type": "string", "description": "TimeBlock id."},
                "title": {
                    "type": "string",
                    "description": "Updated title (optional).",
                },
                "intent": {
                    "type": "string",
                    "description": "Updated plan / intent (optional).",
                },
                "start_utc": {
                    "type": "string",
                    "description": "Updated UTC start (ISO 8601). Triggers conflict detection.",
                },
                "end_utc": {
                    "type": "string",
                    "description": "Updated UTC end (ISO 8601). Triggers conflict detection.",
                },
                "force": {
                    "type": "boolean",
                    "description": "Skip owner-window conflict detection on time edits.",
                    "default": False,
                },
            },
            "required": ["id"],
        },
        "namespace": "ww",
        "category": "timeblock",
        "callable": True,
        "intent_hints": ["update timeblock", "rename timeblock", "edit intent"],
    },
    {
        "name": "ww.timeblock.move",
        "description": (
            "Atomically move one TimeBlock to a new UTC window. The block_id and "
            "audit lineage stay stable (single ledger transition, not delete + "
            "create). Conflict-checked unless force=true. Mirrors "
            "POST /api/v1/timeblocks/{id}/move."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {"type": "string", "description": "TimeBlock id."},
                "new_start_utc": {
                    "type": "string",
                    "description": "New UTC start instant (ISO 8601).",
                },
                "new_end_utc": {
                    "type": "string",
                    "description": "New UTC end instant (ISO 8601). Must be strictly after new_start_utc.",
                },
                "force": {
                    "type": "boolean",
                    "description": "Skip owner-window conflict detection.",
                    "default": False,
                },
            },
            "required": ["id", "new_start_utc", "new_end_utc"],
        },
        "namespace": "ww",
        "category": "timeblock",
        "callable": True,
        "intent_hints": ["move timeblock", "reschedule timeblock"],
    },
    {
        "name": "ww.timeblock.delete",
        "description": (
            "Soft-delete one TimeBlock — flips state to CANCELLED and stamps "
            "ended_at. The audit row stays for traceability; hard-delete is not "
            "exposed. Mirrors DELETE /api/v1/timeblocks/{id}."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "id": {"type": "string", "description": "TimeBlock id."},
            },
            "required": ["id"],
        },
        "namespace": "ww",
        "category": "timeblock",
        "callable": True,
        "intent_hints": ["cancel timeblock", "delete timeblock"],
    },
    # ------------------------------------------------------------------
    # Chat router (Slices 9 + 11) — MCP twin of POST /api/v1/chat/route
    # + POST /api/v1/chat/rollback/{decision_id}.
    # ------------------------------------------------------------------
    {
        "name": "ww.chat.route",
        "description": (
            "Classify a chat message and return the ChatRouterDecision envelope. "
            "Composes safety guardrail + multi-intent splitter + rule-based "
            "classifier + LLM augmentation (xAI Grok when configured) + scope "
            "resolver. Latency budget: 600 ms p95 / 2.5 s ceiling. Mirrors "
            "POST /api/v1/chat/route."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "message": {
                    "type": "string",
                    "description": "Raw user message text. Safety-checked before any LLM call.",
                },
                "thread_id": {
                    "type": "string",
                    "description": "Conversation thread identifier (durable across messages).",
                },
                "workspace_context": {
                    "type": "object",
                    "description": (
                        "Snapshot of what the user is looking at right now. "
                        "Fields: currently_open_card_id, currently_open_goal_id, "
                        "recently_viewed_card_ids, active_card_states "
                        "(card_id -> 'gated'/'running'/'pending_review'/'done'/'archived'/'failed')."
                    ),
                },
                "expected_state_hash": {
                    "type": "string",
                    "description": (
                        "For EXECUTE_NOW: hash of the target card's state at "
                        "classification time. The executor rejects + re-routes if "
                        "the card mutated since."
                    ),
                },
                "prior_scope": {
                    "type": "object",
                    "description": (
                        "Optional scope carryover hint for short / pronominal turns."
                    ),
                },
            },
            "required": ["message", "thread_id"],
        },
        "namespace": "ww",
        "category": "chat",
        "callable": True,
        "intent_hints": [
            "classify chat",
            "chat route",
            "route message",
            "what intent",
        ],
    },
    {
        "name": "ww.chat.rollback",
        "description": (
            "Reverse all card placements created by a KNOWLEDGE_WORK plan within "
            "the 5-minute undo window. Fails-closed with status='expired' after "
            "the window. Mirrors POST /api/v1/chat/rollback/{decision_id}."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "decision_id": {
                    "type": "string",
                    "description": "Decision id from the original ChatRouterDecision.",
                },
                "actor": {
                    "type": "string",
                    "description": "Who initiated the rollback. Recorded in the decision trace.",
                    "default": "user",
                },
            },
            "required": ["decision_id"],
        },
        "namespace": "ww",
        "category": "chat",
        "callable": True,
        "intent_hints": ["rollback plan", "undo chat plan", "chat undo"],
    },
    {
        "name": "ww.admin.inference.audit_grid",
        "description": (
            "Read-only per-Purpose x per-tenant inference audit grid. "
            "Rows are Purpose enum values (e.g. workmemory.query_expansion, "
            "runtime.planner). Columns are enabled providers from the platform "
            "catalog. Cells contain cost_per_m_tokens, latency_p50_ms, "
            "latency_p95_ms, jurisdiction, call_count, total_cost_usd, "
            "total_tokens. Optional tenant_id and purpose filters narrow the "
            "view. The MCP path scopes audit data to the caller's tenant; "
            "platform-wide aggregation remains gated to the founder REST/CLI "
            "path. Mirrors GET /api/v1/founder/inference/audit-grid. "
            "Issue #3215."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {
                    "type": "string",
                    "description": (
                        "Optional tenant ID to scope cost/latency data. "
                        "Omit to use the caller's tenant scope."
                    ),
                },
                "purpose": {
                    "type": "string",
                    "description": (
                        "Optional Purpose enum value (e.g. 'runtime.planner'). "
                        "When set, only that row is returned."
                    ),
                },
            },
        },
        "namespace": "ww",
        "category": "admin",
        "callable": True,
        "intent_hints": [
            "inference audit grid",
            "per purpose per tenant audit",
            "provider audit dashboard",
            "ww admin inference audit-grid",
        ],
    },
    # Issue #3224: jurisdiction policy MCP surfaces.
    {
        "name": "ww.admin.jurisdiction.policy_show",
        "description": (
            "Read the current jurisdiction/provenance blocklist policy. "
            "Returns the list of blocked providers with reasons. Mirrors "
            "GET /api/v1/founder/inference/jurisdiction-policy."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
        "namespace": "ww",
        "category": "admin",
        "callable": True,
        "intent_hints": [
            "show jurisdiction policy",
            "blocked providers list",
            "inference jurisdiction",
        ],
    },
    {
        "name": "ww.admin.jurisdiction.policy_set",
        "description": (
            "Replace the jurisdiction/provenance blocklist with a new set of "
            "blocked providers. Each entry maps provider_id to block reason. "
            "Mirrors PUT /api/v1/founder/inference/jurisdiction-policy."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "providers": {
                    "type": "object",
                    "description": (
                        "Dict mapping provider_id to block reason. "
                        "Empty dict clears all blocks."
                    ),
                    "additionalProperties": {"type": "string"},
                },
            },
            "required": ["providers"],
        },
        "namespace": "ww",
        "category": "admin",
        "callable": True,
        "intent_hints": [
            "set jurisdiction policy",
            "block inference provider",
            "update jurisdiction blocklist",
        ],
    },
    # Issue #3209: per-Purpose × per-tenant embedding policy MCP surfaces.
    {
        "name": "ww.admin.embedding.policy_show",
        "description": (
            "Read the embedding policy. Provide tenant_id to show one tenant; "
            "omit it to list every policy (platform default + tenant overrides). "
            "Mirrors GET /api/v1/founder/embedding/policy[/{tenant_id}]."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {
                    "type": "string",
                    "description": (
                        "Tenant id; '__platform__' for the global default. "
                        "Omit to list every policy."
                    ),
                },
            },
        },
        "namespace": "ww",
        "category": "admin",
        "callable": True,
        "intent_hints": [
            "show embedding policy",
            "embedding model selection",
            "per purpose embedding overrides",
        ],
    },
    {
        "name": "ww.admin.embedding.policy_set",
        "description": (
            "Upsert the embedding policy for one tenant or the platform default "
            "('__platform__'). Mode chooses the routing baseline; "
            "per_purpose_overrides selectively pin a specific Purpose to a "
            "specific provider. Mirrors PUT /api/v1/founder/embedding/policy/{tenant_id}."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "tenant_id": {
                    "type": "string",
                    "description": "Tenant id; '__platform__' for the global default.",
                },
                "mode": {
                    "type": "string",
                    "enum": ["aws_only", "google_enabled", "dual_provider"],
                    "description": "Mode-based default routing.",
                },
                "per_purpose_overrides": {
                    "type": "object",
                    "description": (
                        "Optional per-Purpose provider overrides. Keys are Purpose "
                        "values (e.g. 'workmemory.embedding.text'); values are one "
                        "of bedrock-titan, bedrock-nova-multimodal, bedrock-cohere-v3, "
                        "gemini-embedding."
                    ),
                    "additionalProperties": {"type": "string"},
                },
            },
            "required": ["tenant_id"],
        },
        "namespace": "ww",
        "category": "admin",
        "callable": True,
        "intent_hints": [
            "set embedding policy",
            "select embedding model",
            "embedding per purpose override",
        ],
    },
    # Issue #3227: admin permissions list/grant/revoke surfaces.
    {
        "name": "ww.admin.permissions.list",
        "description": (
            "List admin role assignments (per-user → AdminRole) and the canonical "
            "role → permission catalog. Mirrors GET /api/v1/admin/permissions. "
            "Requires GOVERNANCE_READ permission."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
        "namespace": "ww",
        "category": "admin",
        "callable": True,
        "intent_hints": [
            "list admin permissions",
            "show admin roles",
            "who has admin access",
        ],
    },
    {
        "name": "ww.admin.permissions.grant",
        "description": (
            "Grant an AdminRole to a user. Cross-tenant write — requires "
            "platform_admin (GOVERNANCE_WRITE). Mirrors "
            "POST /api/v1/admin/permissions."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "email": {
                    "type": "string",
                    "description": "Email of the user to grant a role to.",
                },
                "role": {
                    "type": "string",
                    "enum": [
                        "platform_admin",
                        "tenant_admin",
                        "support_observer",
                        "billing_observer",
                        "compliance_admin",
                    ],
                    "description": "AdminRole to assign.",
                },
                "notes": {
                    "type": "string",
                    "description": "Optional audit notes for the assignment.",
                    "default": "",
                },
            },
            "required": ["email", "role"],
        },
        "namespace": "ww",
        "category": "admin",
        "callable": True,
        "intent_hints": [
            "grant admin role",
            "add admin",
            "promote user to admin",
        ],
    },
    {
        "name": "ww.admin.permissions.revoke",
        "description": (
            "Revoke a user's admin role assignment. Cross-tenant write — requires "
            "platform_admin (GOVERNANCE_WRITE). Mirrors "
            "DELETE /api/v1/admin/permissions/{email}."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "email": {
                    "type": "string",
                    "description": "Email of the user whose role is being revoked.",
                },
            },
            "required": ["email"],
        },
        "namespace": "ww",
        "category": "admin",
        "callable": True,
        "intent_hints": ["revoke admin role", "remove admin", "demote admin"],
    },
    # Issue #3236: CompletionGate MCP surface — mirrors the REST
    # POST /api/v1/swarm/steps/{step_id}/result route. Every invocation
    # emits a swarm.completion_gate.verdict decision trace and meters
    # verifier_judgment_tokens against the tenant.
    {
        "name": "ww.swarm.record_step_result",
        "description": (
            "Submit a terminal-status candidate for a swarm step. Routes "
            "through CompletionGate (verifier + success-criteria evaluator "
            "+ evidence isolation + optimistic-lock CAS). Returns the "
            "verifier verdict and commit outcome (committed / "
            "committed_replay / denied / conflict / isolation_violation)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "step_id": {
                    "type": "string",
                    "description": "Swarm step id to transition.",
                },
                "proposed_status": {
                    "type": "string",
                    "description": (
                        "Terminal status candidate. Non-terminal values "
                        "bypass the gate."
                    ),
                    "default": "completed",
                },
                "evidence_bundle": {
                    "type": "object",
                    "description": (
                        "Evidence dict wrapped in an "
                        "UntrustedContextEnvelope before reaching the "
                        "verifier. Must include matching tenant_id "
                        "(and function_id when supplied at the surface)."
                    ),
                    "default": {},
                },
                "evidence_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Evidence Ledger refs attached on commit.",
                    "default": [],
                },
                "function_id": {
                    "type": "string",
                    "description": "Optional function id for cross-function isolation.",
                    "default": "",
                },
                "completed_at": {
                    "type": "string",
                    "description": "ISO-8601 completion timestamp.",
                    "default": "",
                },
                "actor_chain": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Caller chain captured in the decision trace.",
                    "default": [],
                },
            },
            "required": ["step_id"],
        },
        "namespace": "ww",
        "category": "swarm",
        "callable": True,
        "intent_hints": [
            "record swarm step result",
            "submit step completion",
            "verifier-as-gate",
            "completion gate",
        ],
    },
    # Issue #3238: success-criteria evaluator MCP surface — mirrors the REST
    # POST /api/v1/swarm/steps/{step_id}/criterion/evaluate route. Every
    # invocation emits a swarm.success_criteria.evaluated decision trace.
    {
        "name": "ww.swarm.success_criteria_eval",
        "description": (
            "Evaluate a swarm step success criterion against an evidence "
            "bundle. Returns passed / criteria_type / details and emits a "
            "swarm.success_criteria.evaluated decision trace."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {
                "step_id": {
                    "type": "string",
                    "description": "Swarm step id the criterion belongs to.",
                },
                "criteria": {
                    "type": "object",
                    "description": (
                        "Criterion specification. Must include criteria_type "
                        "(tool_result, file_exists, api_response, threshold, "
                        "all_of, any_of) plus type-specific fields."
                    ),
                },
                "evidence": {
                    "type": "object",
                    "description": "Evidence bundle to evaluate against.",
                    "default": {},
                },
                "actor_chain": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Caller chain captured in the decision trace.",
                    "default": [],
                },
            },
            "required": ["step_id", "criteria"],
        },
        "namespace": "ww",
        "category": "swarm",
        "callable": True,
        "intent_hints": [
            "evaluate success criterion",
            "swarm criterion check",
            "completion gate criterion",
        ],
    },
]


def _load_public_mcp_compatibility() -> list[dict[str, Any]]:
    try:
        registry = json.loads(_PARITY_JSON_PATH.read_text(encoding="utf-8"))
    except Exception:
        logger.warning("public_mcp.compatibility_registry_unavailable", exc_info=True)
        return []
    table = registry.get("public_mcp_compatibility", [])
    return [row for row in table if isinstance(row, dict)]


def _derive_canonical_name(legacy_name: str) -> str:
    if legacy_name.startswith("workweaver."):
        return f"ww.{legacy_name[len('workweaver.') :]}"
    return legacy_name


def _legacy_to_canonical_map() -> dict[str, str]:
    mapping: dict[str, str] = {}
    for row in _load_public_mcp_compatibility():
        legacy = row.get("legacy_tool")
        if not isinstance(legacy, str):
            continue
        canonical = row.get("canonical_tool")
        mapping[legacy] = (
            canonical if isinstance(canonical, str) and canonical.startswith("ww.") else _derive_canonical_name(legacy)
        )
    for tool in _LEGACY_PUBLIC_MCP_TOOLS:
        legacy = str(tool.get("name") or "")
        if legacy and legacy not in mapping:
            mapping[legacy] = _derive_canonical_name(legacy)
    return mapping


def _tool_category(tool_name: str) -> str:
    parts = tool_name.split(".")
    return parts[1] if len(parts) >= 3 else "tools"


def _slug(value: Any) -> str:
    raw = str(value or "").strip().lower()
    slug = re.sub(r"[^a-z0-9]+", "_", raw).strip("_")
    return slug or "unknown"


def _load_parity_registry() -> dict[str, Any]:
    try:
        return json.loads(_PARITY_JSON_PATH.read_text(encoding="utf-8"))
    except Exception:
        logger.warning("public_mcp.parity_registry_unavailable", exc_info=True)
        return {}


def _load_capability_registry_index() -> tuple[dict[str, Any], dict[tuple[str, str], Any]]:
    try:
        from apps.backend.services.capability_registry import load_capability_registry

        registry = load_capability_registry()
    except Exception:
        logger.warning("public_mcp.capability_registry_unavailable", exc_info=True)
        return {}, {}
    return registry.by_mcp_tool(), registry.by_family_action()


_CAPABILITY_BY_MCP_TOOL, _CAPABILITY_BY_FAMILY_ACTION = _load_capability_registry_index()


def _capability_metadata(
    *, tool_name: str | None = None, family: str | None = None, action: str | None = None
) -> dict[str, Any]:
    row = None
    if tool_name and (not family or not action):
        parts = str(tool_name).split(".")
        if len(parts) >= 3 and parts[0] == "ww":
            family = family or parts[1]
            action = action or ".".join(parts[2:])
    if family and action:
        row = _CAPABILITY_BY_FAMILY_ACTION.get((family, action))
    if row is None and tool_name:
        row = _CAPABILITY_BY_MCP_TOOL.get(tool_name)
    if row is None:
        return {}
    return {
        "capability_id": row.capability_id,
        "contract_id": row.contract_id,
        "owner": row.owner,
        "limitations": list(row.limitations),
        "deployment_profiles": list(row.deployment_profiles),
        "docs": list(row.docs),
        "tests": list(row.tests),
        "missing_surfaces": dict(row.missing_surfaces),
    }


def _compact_capability_metadata(tool: dict[str, Any]) -> dict[str, Any]:
    capability = tool.get("capability")
    if not isinstance(capability, dict):
        return {}
    return {key: capability[key] for key in ("capability_id", "contract_id", "owner") if key in capability}


def _index_capability_metadata(tool: dict[str, Any]) -> dict[str, Any]:
    metadata = _compact_capability_metadata(tool)
    if not metadata:
        return {}
    if metadata.get("owner") == "runtime-parity" and not metadata.get("limitations"):
        return {}
    metadata = {"capability_id": metadata["capability_id"]} if "capability_id" in metadata else {}
    return metadata


def _canonical_name_from_parity_row(family: str, subcommand: dict[str, Any]) -> str:
    declared = subcommand.get("mcp")
    if isinstance(declared, str) and declared.startswith("ww."):
        return declared
    return f"ww.{_slug(family)}.{_slug(subcommand.get('name'))}"


def _parity_catalog_tools() -> list[dict[str, Any]]:
    registry = _load_parity_registry()
    catalog: dict[str, dict[str, Any]] = {}
    for family_entry in registry.get("families", []):
        if not isinstance(family_entry, dict):
            continue
        family = str(family_entry.get("family") or "").strip()
        if not family:
            continue
        family_description = str(family_entry.get("description") or "").strip()
        for subcommand in family_entry.get("subcommands", []):
            if not isinstance(subcommand, dict):
                continue
            name = str(subcommand.get("name") or "").strip()
            if not name:
                continue
            canonical_tool_name = _canonical_name_from_parity_row(family, subcommand)
            tool_name = canonical_tool_name
            if tool_name in catalog:
                row_specific_name = f"ww.{_slug(family)}.{_slug(name)}"
                if row_specific_name != tool_name and row_specific_name not in catalog:
                    tool_name = row_specific_name
                else:
                    continue
            catalog.setdefault(
                tool_name,
                {
                    "name": tool_name,
                    "description": family_description or f"{family} {name}",
                    "inputSchema": {
                        "type": "object",
                        "properties": {
                            "parameters": {
                                "type": "object",
                                "description": "Command parameters for this parity surface.",
                                "default": {},
                            }
                        },
                    },
                    "namespace": "ww",
                    "category": family,
                    "callable": False,
                    "intent_hints": [f"{family} {name}", f"ww {family} {name}", canonical_tool_name],
                    "parity": {
                        "family": family,
                        "subcommand": name,
                        "canonical_mcp_tool": canonical_tool_name,
                        "backend": subcommand.get("backend"),
                        "ui": subcommand.get("ui"),
                    },
                    "capability": _capability_metadata(
                        tool_name=canonical_tool_name,
                        family=family,
                        action=name,
                    ),
                },
            )
    return [catalog[name] for name in sorted(catalog)]


def _canonicalize_live_public_tools() -> list[dict[str, Any]]:
    compatibility = {row.get("legacy_tool"): row for row in _load_public_mcp_compatibility()}
    legacy_to_canonical = _legacy_to_canonical_map()
    by_name: dict[str, dict[str, Any]] = {}

    for legacy_tool in _LEGACY_PUBLIC_MCP_TOOLS:
        legacy_name = str(legacy_tool.get("name") or "")
        canonical_name = legacy_to_canonical.get(legacy_name, _derive_canonical_name(legacy_name))
        tool = deepcopy(legacy_tool)
        tool["name"] = canonical_name
        if canonical_name == "ww.evidence.trace":
            tool["description"] = "Return the hydrated Decision Trace for a WorkItem, task, goal, or subject."
            tool["inputSchema"] = {
                "type": "object",
                "properties": {
                    "workitem_id": {"type": "string", "description": "WorkItem ID to trace"},
                    "task_id": {"type": "string", "description": "Task ID to trace"},
                    "goal_id": {"type": "string", "description": "Goal ID to trace"},
                    "subject_id": {"type": "string", "description": "Generic subject ID to trace"},
                    "subject_type": {"type": "string", "description": "Subject type for generic subject IDs"},
                    "limit": {"type": "integer", "description": "Max decisions to scan", "default": 50},
                },
            }
        aliases = list(dict.fromkeys([*(tool.get("aliases") or []), legacy_name]))
        tool["aliases"] = aliases
        tool["legacyAliases"] = aliases
        tool["namespace"] = "ww"
        tool["category"] = _tool_category(canonical_name)
        tool["callable"] = True
        tool["intent_hints"] = [
            canonical_name.replace(".", " "),
            str(tool.get("description") or ""),
            *aliases,
        ]
        if row := compatibility.get(legacy_name):
            family = row.get("parity_family")
            action = row.get("parity_subcommand")
            tool["parity"] = {
                "family": family,
                "subcommand": action,
                "status": row.get("status"),
                "owner_issue": row.get("owner_issue"),
            }
            tool["capability"] = _capability_metadata(
                tool_name=canonical_name,
                family=family if isinstance(family, str) else None,
                action=action if isinstance(action, str) else None,
            )
        else:
            tool["capability"] = _capability_metadata(tool_name=canonical_name)

        existing = by_name.get(canonical_name)
        if existing is None:
            by_name[canonical_name] = tool
            continue

        existing_aliases = list(existing.get("aliases") or [])
        existing_aliases.extend(alias for alias in aliases if alias not in existing_aliases)
        existing["aliases"] = existing_aliases
        existing["legacyAliases"] = existing_aliases

        # If two legacy aliases converge on one canonical name, keep the richer schema.
        existing_schema_size = len(json.dumps(existing.get("inputSchema") or {}, sort_keys=True))
        candidate_schema_size = len(json.dumps(tool.get("inputSchema") or {}, sort_keys=True))
        if candidate_schema_size > existing_schema_size:
            tool["aliases"] = existing_aliases
            tool["legacyAliases"] = existing_aliases
            by_name[canonical_name] = tool

    return [by_name[name] for name in sorted(by_name)]


def _tool_search_tool_schema() -> dict[str, Any]:
    return {
        "name": _TOOL_SEARCH_NAME,
        "description": "Search the Workweaver MCP tool catalog by natural-language intent.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "intent": {"type": "string", "description": "Natural-language action or goal to resolve"},
                "limit": {"type": "integer", "description": "Maximum matches to return", "default": 5},
            },
            "required": ["intent"],
        },
        "namespace": "ww",
        "category": "tools",
        "callable": True,
    }


_WORKFLOW_PUBLIC_MCP_TOOLS: list[dict[str, Any]] = [
    {
        "name": "ww.workflow.template.list",
        "description": "List backend-owned workflow saga templates.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww",
        "category": "workflow",
        "callable": True,
        "intent_hints": ["workflow templates", "list saga templates"],
    },
    {
        "name": "ww.workflow.template.show",
        "description": "Show one backend-owned workflow saga template.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "template_id": {"type": "string", "description": "Workflow template ID."},
            },
            "required": ["template_id"],
        },
        "namespace": "ww",
        "category": "workflow",
        "callable": True,
        "intent_hints": ["show workflow template", "inspect saga template"],
    },
    {
        "name": "ww.workflow.saga.run",
        "description": "Run a workflow template as an idempotent workspace-scoped saga.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "template_id": {"type": "string", "description": "Workflow template ID."},
                "idempotency_key": {"type": "string", "description": "Retry key for exactly-once saga start."},
                "actor_id": {"type": "string", "description": "Actor starting the saga.", "default": "mcp"},
                "initial_data": {"type": "object", "description": "Initial saga input payload."},
                "fail_step_id": {"type": "string", "description": "Test-only failure injection step ID."},
            },
            "required": ["template_id"],
        },
        "namespace": "ww",
        "category": "workflow",
        "callable": True,
        "intent_hints": ["run workflow saga", "start workflow template"],
    },
    {
        "name": "ww.workflow.saga.status",
        "description": "Return a workflow saga run status and Decision Trace events.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "run_id": {"type": "string", "description": "Workflow saga run ID."},
            },
            "required": ["run_id"],
        },
        "namespace": "ww",
        "category": "workflow",
        "callable": True,
        "intent_hints": ["workflow saga status", "saga decision trace"],
    },
    {
        "name": "ww.workflow.saga.compensate",
        "description": "Compensate a workflow saga run and record the transition trace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "run_id": {"type": "string", "description": "Workflow saga run ID."},
                "reason": {"type": "string", "description": "Compensation reason.", "default": "manual_compensation"},
                "actor_id": {"type": "string", "description": "Actor compensating the saga.", "default": "mcp"},
            },
            "required": ["run_id"],
        },
        "namespace": "ww",
        "category": "workflow",
        "callable": True,
        "intent_hints": ["compensate workflow saga", "rollback workflow run"],
    },
]


def _inference_manifest_tools() -> list[dict[str, Any]]:
    """Manifest-driven inference family tools (#3508).

    Returns the ``ww.inference.*`` and ``ww.admin.inference.*`` tool schemas
    generated from ``apps/cli/ww/commands/inference_manifest.yaml``. Tools
    whose names already exist in ``_NATIVE_PUBLIC_MCP_TOOLS`` (e.g. the
    legacy ``ww.admin.inference.audit_grid``) are skipped so the live tool
    definition wins.
    """

    from apps.backend.api.inference_mcp_tools import inference_mcp_tools

    existing = {str(t.get("name") or "") for t in _NATIVE_PUBLIC_MCP_TOOLS}
    return [t for t in inference_mcp_tools() if t["name"] not in existing]


def _workspace_public_description(text: str) -> str:
    """Rewrite internal tenancy vocabulary in public MCP descriptions."""
    replacements = (
        ("ww.tenant.conflicts.list", "the conflict list tool"),
        ("tenant_config", "workspace config"),
        ("target_tenant_id", "target_workspace_id"),
        ("source_tenant_id", "source_workspace_id"),
        ("tenant_override", "workspace_override"),
        ("tenant_id", "workspace_id"),
        ("TenantProviderProfile", "WorkspaceProviderProfile"),
        ("sub-tenant", "child workspace"),
        ("Sub-tenant", "Child workspace"),
        ("cross-tenant", "cross-workspace"),
        ("Cross-tenant", "Cross-workspace"),
        ("multi-tenant", "multi-workspace"),
        ("Multi-tenant", "Multi-workspace"),
        ("tenant-owned", "workspace-owned"),
        ("Tenant-owned", "Workspace-owned"),
        ("tenant_billing", "workspace billing"),
    )
    cleaned = text
    for old, new in replacements:
        cleaned = cleaned.replace(old, new)
    cleaned = re.sub(r"\bTenant\b", "Workspace", cleaned)
    cleaned = re.sub(r"\btenant\b", "workspace", cleaned)
    cleaned = re.sub(r"\bTenants\b", "Workspaces", cleaned)
    cleaned = re.sub(r"\btenants\b", "workspaces", cleaned)
    return cleaned


def _sanitize_public_mcp_text(value: Any, *, sanitize_strings: bool = False) -> Any:
    """Return a copy with customer-visible MCP text using Workspace language."""
    if isinstance(value, list):
        return [_sanitize_public_mcp_text(item, sanitize_strings=sanitize_strings) for item in value]
    if isinstance(value, dict):
        sanitized: dict[str, Any] = {}
        for key, item in value.items():
            if key in {"description", "intent_hints"}:
                sanitized[key] = _sanitize_public_mcp_text(item, sanitize_strings=True)
            else:
                sanitized[key] = _sanitize_public_mcp_text(item)
        return sanitized
    if isinstance(value, str):
        return _workspace_public_description(value) if sanitize_strings else value
    return value


# Issue #3542: WorkspacePersonaOverlay (safe SOUL.md analog).
# Read+write operations on the tenant's persona overlay. Mutations emit an
# identity-class Decision Trace via the service layer; reads do not.
_PERSONA_PUBLIC_MCP_TOOLS: list[dict[str, Any]] = [
    {
        "name": "ww.workspace.persona.show",
        "description": "Read the workspace persona overlay (identity/presence/vocabulary/routing_biases/language). Kernel envelope is unaffected.",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww",
        "category": "workspace",
        "callable": True,
        "intent_hints": [
            "show persona",
            "workspace persona",
            "get persona overlay",
        ],
    },
    {
        "name": "ww.workspace.persona.set",
        "description": "Set or replace the workspace persona overlay. Validator refuses kernel/policy/governance/floor keys.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema_version": {"type": "string", "enum": ["v1"]},
                "identity": {
                    "type": "object",
                    "properties": {
                        "name": {"type": "string"},
                        "voice_id": {"type": "string"},
                        "voice_tone": {
                            "type": "string",
                            "enum": ["warm", "neutral", "crisp", "formal"],
                        },
                    },
                    "required": ["name"],
                },
                "presence": {
                    "type": "object",
                    "properties": {
                        "default_channel": {
                            "type": "string",
                            "enum": [
                                "voice",
                                "email",
                                "slack",
                                "whatsapp",
                                "sms",
                                "dashboard",
                            ],
                        },
                        "work_hours": {"type": "object"},
                        "timezone": {"type": "string"},
                    },
                },
                "vocabulary": {
                    "type": "object",
                    "properties": {
                        "brand_terms": {"type": "array", "items": {"type": "string"}},
                        "forbidden_terms": {
                            "type": "array",
                            "items": {"type": "string"},
                        },
                    },
                },
                "routing_biases": {
                    "type": "object",
                    "properties": {
                        "prefer_channel_outside_hours": {"type": "string"},
                        "summary_length_preference": {
                            "type": "string",
                            "enum": ["terse", "standard", "detailed"],
                        },
                    },
                },
                "language": {
                    "type": "object",
                    "properties": {
                        "primary": {"type": "string"},
                        "fallback_locale": {"type": "string"},
                    },
                },
            },
            "required": ["identity"],
        },
        "namespace": "ww",
        "category": "workspace",
        "callable": True,
        "intent_hints": [
            "set persona",
            "workspace persona overlay",
            "brand zara",
        ],
    },
    {
        "name": "ww.workspace.persona.reset",
        "description": "Reset the workspace persona overlay to defaults (delete the row).",
        "inputSchema": {"type": "object", "properties": {}},
        "namespace": "ww",
        "category": "workspace",
        "callable": True,
        "intent_hints": [
            "reset persona",
            "delete persona overlay",
            "restore default persona",
        ],
    },
]
