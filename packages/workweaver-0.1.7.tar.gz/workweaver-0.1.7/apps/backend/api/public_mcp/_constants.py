"""Module-level constants for public MCP tools.

Extracted from the original monolithic public_mcp.py (#3928).
"""

from __future__ import annotations

import logging
from pathlib import Path

logger = logging.getLogger(__name__)


_PLAN_STEER_MCP_TOOLS = frozenset({"ww.plan.steer", "workweaver.plan.steer"})
_GUARDED_PUBLIC_MCP_TOOLS = frozenset({
    "ww.connector.execute", "workweaver.connector.execute",
    "ww.connector.import.openapi",
    "ww.skill.import",
    "ww.wallet.sign", "ww.wallet.broadcast", "ww.wallet.address",
    # Multi-wallet write surfaces (issue #3625 / slice 8e parity)
    "ww.wallet.policy.set",
    "ww.wallet.transactions.sign",
    # Cross-tenant Zara coordination (issue #3625 / family J)
    "ww.zara.coordinate.send",
    "ww.zara.coordinate.broadcast",
    *_PLAN_STEER_MCP_TOOLS,
    "ww.mission.steer", "workweaver.mission.steer",
    "ww.mission.outcome_review",
    "ww.mission.reversal.request",
    "ww.skill.curator.run",
    "ww.skill.curator.latest",
    "ww.skill.curator.list",
    "ww.skill.curator.respond",
})
_SAFE_OPERATION_PREFIXES = ("read", "list", "get", "search", "query", "describe")
_HIGH_RISK_OPERATION_PREFIXES = (
    "create",
    "delete",
    "destroy",
    "execute",
    "patch",
    "publish",
    "post",
    "purge",
    "remove",
    "run",
    "send",
    "terminate",
    "trigger",
    "update",
    "upsert",
    "write",
)
_SAFE_CONNECTOR_HTTP_METHODS = frozenset({"GET", "HEAD", "OPTIONS"})
_TOOL_SEARCH_NAME = "ww.tools.search"
_CONNECTOR_EXECUTE_TOOL_NAMES = frozenset({"ww.connector.execute", "workweaver.connector.execute"})
_PARITY_JSON_PATH = Path(__file__).resolve().parents[4] / "apps" / "cli" / "parity.json"
