"""Skill Curator MCP tool dispatch (#3928).

Extracted from _dispatch.py. Contains curator-specific constants,
helpers, and the dispatch function for ww.skill.curator.* tools.
"""

from __future__ import annotations

from typing import Any

_SKILL_CURATOR_STATUSES = frozenset({"pending", "accepted", "rejected", "deferred"})
_SKILL_CURATOR_DECISIONS = frozenset({"accept", "reject", "defer"})
_SYNTHETIC_SKILL_CURATOR_DECISION_ACTORS = frozenset(
    {"mcp", "agent", "agent:mcp", "zara", "system"}
)
_SKILL_CURATOR_WEIGHT_FIELDS = frozenset(
    {"usage", "pass_rate", "recency", "consolidation", "richness"}
)


def _get_skill_curator_service():  # noqa: ANN201
    from apps.backend.services.skills.skill_hygiene_service import SkillHygieneService

    return SkillHygieneService()


def _pkg():
    """Return the public_mcp package module for monkeypatch-compatible lookups."""
    import apps.backend.api.public_mcp as _m

    return _m


def _skill_curator_workspace_error(
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, str] | None:
    workspace_id = str(parameters.get("workspace_id") or tenant_id).strip()
    if workspace_id != tenant_id:
        return {
            "status": "error",
            "error": "workspace_id must match authenticated tenant_id",
        }
    return None


def _skill_curator_plain_dict(value: Any) -> dict[str, Any]:
    if isinstance(value, dict):
        return dict(value)
    if hasattr(value, "to_dict"):
        return value.to_dict()
    if hasattr(value, "model_dump"):
        return value.model_dump(mode="json")
    return dict(value)


def _skill_curator_run_payload(run: Any) -> dict[str, Any]:
    payload = _skill_curator_plain_dict(run)
    proposals = [
        _skill_curator_plain_dict(proposal)
        for proposal in payload.get("proposals", [])
    ]
    payload["proposals"] = proposals
    payload["proposal_count"] = int(payload.get("proposal_count") or len(proposals))
    return payload


def _skill_curator_proposal_payload(proposal: Any) -> dict[str, Any]:
    return _skill_curator_plain_dict(proposal)


def _valid_skill_curator_decision_actor(actor_id: str) -> bool:
    normalized = actor_id.strip().lower()
    return bool(actor_id.strip()) and normalized not in _SYNTHETIC_SKILL_CURATOR_DECISION_ACTORS


def _skill_curator_decision_actor_from_proof(
    side_effect_proof: dict[str, Any] | None,
) -> tuple[str | None, dict[str, Any] | None]:
    actor_id = str((side_effect_proof or {}).get("actor_id") or "").strip()
    if not _valid_skill_curator_decision_actor(actor_id):
        return None, {
            "status": "proof_required",
            "error": "Skill Curator decisions require side_effect_proof.actor_id for an accountable member or agent actor",
        }
    return actor_id, None


def _skill_curator_weights(parameters: dict[str, Any]) -> Any:
    raw = parameters.get("weights")
    if raw in (None, ""):
        return None
    if not isinstance(raw, dict):
        raise ValueError("weights must be an object")
    unknown = set(raw) - _SKILL_CURATOR_WEIGHT_FIELDS
    if unknown:
        raise ValueError(f"unsupported weight field(s): {', '.join(sorted(unknown))}")
    from apps.backend.services.skills.skill_hygiene_service import SkillCuratorWeights

    return SkillCuratorWeights(
        **{
            key: float(value)
            for key, value in raw.items()
            if key in _SKILL_CURATOR_WEIGHT_FIELDS and value is not None
        }
    )


def _dispatch_skill_curator_tool(
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    if workspace_error := _skill_curator_workspace_error(tenant_id, parameters):
        return workspace_error
    service = _pkg()._get_skill_curator_service()

    if tool_name == "ww.skill.curator.run":
        try:
            weights = _skill_curator_weights(parameters)
        except ValueError as exc:
            return {"status": "error", "error": str(exc)}
        run = service.run_curator(tenant_id, weights=weights)
        return _skill_curator_run_payload(run)

    if tool_name == "ww.skill.curator.latest":
        run = service.latest_curator_run(tenant_id)
        if run is None:
            return {"status": "not_found", "error": "No Skill Curator run found"}
        return _skill_curator_run_payload(run)

    if tool_name == "ww.skill.curator.list":
        status_filter = parameters.get("status")
        status_value = str(status_filter).strip() if status_filter not in (None, "") else None
        if status_value is not None and status_value not in _SKILL_CURATOR_STATUSES:
            return {
                "status": "error",
                "error": "status must be one of pending, accepted, rejected, deferred",
            }
        proposals = service.list_curator_proposals(tenant_id, status=status_value)
        serialized = [_skill_curator_proposal_payload(proposal) for proposal in proposals]
        return {"proposals": serialized, "count": len(serialized)}

    if tool_name == "ww.skill.curator.respond":
        proposal_id = str(parameters.get("proposal_id") or "").strip()
        if not proposal_id:
            return {"status": "error", "error": "proposal_id is required"}
        decision = str(parameters.get("decision") or "").strip()
        if decision not in _SKILL_CURATOR_DECISIONS:
            return {"status": "error", "error": "decision must be one of accept, reject, defer"}
        actor_id = str(parameters.get("actor_id") or "").strip()
        if not _valid_skill_curator_decision_actor(actor_id):
            return {
                "status": "error",
                "error": "actor_id is required for an accountable member or agent actor",
            }
        try:
            proposal = service.decide_curator_proposal(
                tenant_id,
                proposal_id,
                decision=decision,
                actor_id=actor_id,
                reason=str(parameters.get("reason") or ""),
            )
        except KeyError as exc:
            return {"status": "error", "error": str(exc)}
        return _skill_curator_proposal_payload(proposal)

    raise ValueError(f"Unknown Skill Curator MCP tool: {tool_name}")
