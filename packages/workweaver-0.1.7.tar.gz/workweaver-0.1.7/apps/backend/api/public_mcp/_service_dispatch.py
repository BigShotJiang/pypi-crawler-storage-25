"""Service-delegating MCP dispatch functions (#3928).

Extracted from _dispatch.py. Contains dispatch functions that delegate to
backend services: agent protocol, learning DLQ, wallet, Zara coordination,
support bug/consent, profile, identity, decision search, agent card,
capability state, voice persona, workspace persona.
"""

from __future__ import annotations

import os
from typing import Any


def get_agent_protocol_service():  # noqa: ANN201
    """Lazy-load agent protocol service for MCP dispatch."""
    from apps.backend.services.agent_protocol import (
        get_agent_protocol_service as _get,
    )

    return _get()


async def _dispatch_agent_protocol_tool(
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Handle agent protocol MCP tools."""
    from dataclasses import asdict

    svc = get_agent_protocol_service()

    if tool_name == "workweaver.org.query":
        resp = await svc.query_agent(
            tenant_id=tenant_id,
            agent_id="org",
            question=parameters["question"],
        )
        return asdict(resp)

    if tool_name == "workweaver.agent.query":
        resp = await svc.query_agent(
            tenant_id=tenant_id,
            agent_id=parameters["agent_id"],
            question=parameters["question"],
        )
        return asdict(resp)

    raise ValueError(f"Unknown agent protocol tool: {tool_name}")


# ---------------------------------------------------------------------------
# Learning DLQ MCP tools (#2324)
# ---------------------------------------------------------------------------

_LEARNING_DLQ_MCP_TOOLS: list[dict[str, Any]] = [
    {
        "name": "ww.learning.dlq.list",
        "description": "List dead-lettered learning signals for the workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {"limit": {"type": "integer", "description": "Maximum entries to return.", "default": 50}},
        },
    },
    {
        "name": "ww.learning.dlq.inspect",
        "description": "Inspect a single dead-lettered learning signal.",
        "inputSchema": {
            "type": "object",
            "properties": {"envelope_id": {"type": "string", "description": "DLQ envelope ID to inspect."}},
            "required": ["envelope_id"],
        },
    },
    {
        "name": "ww.learning.dlq.replay",
        "description": "Replay a dead-lettered learning signal for retry.",
        "inputSchema": {
            "type": "object",
            "properties": {"envelope_id": {"type": "string", "description": "DLQ envelope ID to replay."}},
            "required": ["envelope_id"],
        },
    },
]


async def _dispatch_learning_dlq_tool(
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch learning DLQ MCP tools."""
    from apps.backend.services.learning.learning_signal_queue import LearningSignalQueue

    queue = LearningSignalQueue()

    if tool_name == "ww.learning.dlq.list":
        limit = int(parameters.get("limit") or 50)
        envelopes = queue.list_dlq(tenant_id, limit=limit)
        items = [
            {
                "id": e.id,
                "work_item_id": e.work_item_id,
                "attempts": e.attempts,
                "dead_lettered": e.dead_lettered,
                "last_error": e.last_error,
                "created_at": e.created_at,
            }
            for e in envelopes
        ]
        return {"items": items, "count": len(items)}

    if tool_name == "ww.learning.dlq.inspect":
        envelope_id = str(parameters.get("envelope_id") or "")
        if not envelope_id:
            return {"status": "error", "error": "envelope_id is required"}
        envelope = queue.inspect(envelope_id, tenant_id)
        if envelope is None:
            return {"status": "error", "error": "DLQ entry not found"}
        return envelope.model_dump(mode="json")

    if tool_name == "ww.learning.dlq.replay":
        envelope_id = str(parameters.get("envelope_id") or "")
        if not envelope_id:
            return {"status": "error", "error": "envelope_id is required"}
        envelope = queue.replay(envelope_id, tenant_id)
        if envelope is None:
            return {"status": "error", "error": "DLQ entry not found"}
        return {"replayed": True, "id": envelope.id, "message": "DLQ entry queued for replay"}

    return {"status": "error", "error": f"Unknown learning DLQ tool: {tool_name}"}


async def _dispatch_wallet_tool(
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch wallet.* MCP tools via wallet_tools module (#2366)."""
    from apps.backend.mcp.wallet_tools import dispatch_wallet_tool

    return await dispatch_wallet_tool(tool_name, tenant_id, parameters)


async def _dispatch_zara_coordination_tool(
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch ww.zara.coordinate.* MCP tools (#3625 / family J)."""
    from apps.backend.mcp.zara_coordination_tools import (
        dispatch_zara_coordination_tool,
    )

    return await dispatch_zara_coordination_tool(tool_name, tenant_id, parameters)


async def _dispatch_support_file_bug(
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch support.file_bug via BugReportProvider (#2348)."""
    summary = str(parameters.get("summary") or "").strip()
    if not summary:
        return {"status": "error", "error": "summary is required"}

    from apps.backend.providers.bug_report_provider import get_bug_report_provider
    from apps.backend.services.zara.actions.file_support_ticket import FileSupportTicketAction

    provider = get_bug_report_provider()
    action = FileSupportTicketAction(bug_report_provider=provider)
    category = str(parameters.get("category") or "other").strip()
    evidence_refs = parameters.get("evidence_refs") or []

    result = await action.execute(
        tenant_id=tenant_id,
        user_id="mcp",
        category=category,
        summary=summary,
        severity="medium",
        session_context={"evidence": [str(e) for e in evidence_refs]},
    )

    if not result.get("ticket_created"):
        return {"status": "error", "error": result.get("error", "ticket creation failed")}

    ticket_id = result["provider_ticket_id"]
    return {
        "ticket_id": ticket_id,
        "ticket_url": f"/api/v1/support/tickets/{ticket_id}",
        "consent_required": False,
        "status": "open",
    }


async def _dispatch_support_consent(
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch support.consent (#2342)."""
    action = str(parameters.get("action") or "list").strip()
    investigation_id = parameters.get("investigation_id")

    from apps.backend.providers.portable_store import get_portable_store
    from apps.backend.providers.object_store import get_evidence_store
    from apps.backend.services.investigation_consent_service import InvestigationConsentService

    store = get_portable_store()
    evidence_store = get_evidence_store()
    svc = InvestigationConsentService(store=store, evidence_store=evidence_store)

    if action == "list":
        results = svc.list_consents(
            tenant_id=tenant_id,
            investigation_id=investigation_id,
        )
        return {
            "action": "list",
            "tenant_id": tenant_id,
            "consents": [
                {
                    "consent_id": c.consent_id,
                    "investigation_id": c.investigation_id,
                    "granted_by": c.granted_by,
                    "scope": c.scope,
                    "granted_at": c.granted_at,
                    "expires_at": c.expires_at,
                    "revoked_at": c.revoked_at,
                    "audit_trail_ref": c.audit_trail_ref,
                }
                for c in results
            ],
            "count": len(results),
        }

    if action == "approve":
        granted_by = str(parameters.get("granted_by") or "").strip()
        if not granted_by:
            return {"status": "error", "error": "granted_by is required for approve action"}
        scope = parameters.get("scope") or ["data_access"]
        duration_hours = int(parameters.get("duration_hours") or 24)
        if not investigation_id:
            return {"status": "error", "error": "investigation_id is required for approve action"}
        envelope = svc.grant_consent(
            tenant_id=tenant_id,
            investigation_id=investigation_id,
            granted_by=granted_by,
            scope=scope,
            duration_hours=duration_hours,
        )
        return {
            "action": "approve",
            "consent_id": envelope.consent_id,
            "investigation_id": envelope.investigation_id,
            "granted_by": envelope.granted_by,
            "scope": envelope.scope,
            "granted_at": envelope.granted_at,
            "expires_at": envelope.expires_at,
            "audit_trail_ref": envelope.audit_trail_ref,
            "status": "granted",
        }

    if action == "revoke":
        consent_id = str(parameters.get("consent_id") or "").strip()
        reason = str(parameters.get("reason") or "").strip()
        if not consent_id:
            return {"status": "error", "error": "consent_id is required for revoke action"}
        if not reason:
            return {"status": "error", "error": "reason is required for revoke action"}
        envelope = svc.revoke_consent(
            tenant_id=tenant_id,
            consent_id=consent_id,
            reason=reason,
        )
        return {
            "action": "revoke",
            "consent_id": envelope.consent_id,
            "revoked_at": envelope.revoked_at,
            "revocation_reason": envelope.revocation_reason,
            "status": "revoked",
        }

    if action == "check":
        consent_id = str(parameters.get("consent_id") or "").strip()
        if not consent_id:
            return {"status": "error", "error": "consent_id is required for check action"}
        valid = svc.check_consent(
            tenant_id=tenant_id,
            consent_id=consent_id,
        )
        return {
            "action": "check",
            "consent_id": consent_id,
            "valid": valid,
        }

    return {"status": "error", "error": f"Unknown action: {action}"}


async def _dispatch_profile_get(tenant_id: str) -> dict[str, Any]:
    """Dispatch profile.get (#2394)."""
    from apps.backend.services.deployment_profiles import get_deployment_profile_config

    profile = os.environ.get("WORKWEAVER_PROFILE", "solo_dogfood")
    cfg = get_deployment_profile_config(profile)
    result = cfg.to_dict()
    result["tenant_id"] = tenant_id
    return result


async def _dispatch_profile_set(tenant_id: str, parameters: dict[str, Any]) -> dict[str, Any]:
    """Dispatch profile.set (#2394)."""
    from apps.backend.services.deployment_profiles import get_deployment_profile_config

    profile = str(parameters.get("profile") or "").strip()
    if not profile:
        return {"status": "error", "error": "profile is required"}
    cfg = get_deployment_profile_config(profile)
    return {"tenant_id": tenant_id, "profile": cfg.profile.value, "updated": True}


async def _dispatch_profile_list() -> dict[str, Any]:
    """Dispatch profile.list (#2394)."""
    from apps.backend.services.deployment_profiles import list_deployment_profiles

    return {"profiles": list_deployment_profiles()}


async def _dispatch_identity_purposes(tenant_id: str, parameters: dict[str, Any]) -> dict[str, Any]:
    """Dispatch identity.purposes (#2231)."""
    agent_id = str(parameters.get("agent_id") or "zara").strip()
    purposes = [
        "email_send", "calendar_read", "calendar_write", "meeting_join",
        "payment_initiate", "payment_approve", "voice_call", "crypto_wallet",
    ]
    return {
        "agent_id": agent_id,
        "tenant_id": tenant_id,
        "purposes": {p: {"ready": False, "provider": None, "state": "missing"} for p in purposes},
    }


async def _dispatch_identity_purpose_status(tenant_id: str, parameters: dict[str, Any]) -> dict[str, Any]:
    """Dispatch identity.purpose_status (#2231)."""
    agent_id = str(parameters.get("agent_id") or "zara").strip()
    purpose = str(parameters.get("purpose") or "").strip()
    if not purpose:
        return {"status": "error", "error": "purpose is required"}
    return {
        "agent_id": agent_id,
        "tenant_id": tenant_id,
        "purpose": purpose,
        "ready": False,
        "provider": None,
        "state": "missing",
        "scopes": [],
    }


def _dispatch_decision_search(
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch decision.search (#2489)."""
    from apps.backend.services.decision_search_service import (
        DecisionSearchFilters,
        get_decision_search_service,
    )

    filters = DecisionSearchFilters(
        domain=parameters.get("domain"),
        tool_name=parameters.get("tool_name"),
        outcome=parameters.get("outcome"),
        skill_id=parameters.get("skill_id"),
        decision_type=parameters.get("decision_type"),
        min_confidence=parameters.get("min_confidence"),
        time_range_start=parameters.get("time_range_start"),
        time_range_end=parameters.get("time_range_end"),
        sop_deviation_present=parameters.get("sop_deviation_present"),
        precedent_id=parameters.get("precedent_id"),
        limit=int(parameters.get("limit") or 50),
        cursor=parameters.get("cursor"),
    )
    query = str(parameters.get("query") or "").strip() or None
    service = get_decision_search_service()
    result = service.search(tenant_id=tenant_id, filters=filters, query=query)
    return result.model_dump(mode="json")


async def _dispatch_agent_card_show(tenant_id: str) -> dict[str, Any]:
    """Dispatch agent_card_show — return the live Agent Card (#3947)."""
    from apps.backend.api.agent_mesh import (
        _emit_agent_card_trace,
        _meter_agent_card_access,
        build_agent_card,
    )

    card = build_agent_card()
    await _emit_agent_card_trace(tenant_id, "show")
    await _meter_agent_card_access(tenant_id, "show")
    return card


async def _dispatch_agent_card_verify(tenant_id: str, parameters: dict[str, Any]) -> dict[str, Any]:
    """Dispatch agent_card_verify — verify Ed25519 signature (#3947)."""
    import base64
    import json

    from apps.backend.api.agent_mesh import (
        _emit_agent_card_trace,
        _meter_agent_card_access,
    )

    card_json = parameters.get("card_json")
    if card_json:
        try:
            card_data = json.loads(card_json)
        except (json.JSONDecodeError, TypeError):
            return {"valid": False, "error": "Invalid JSON in card_json parameter"}
    else:
        from apps.backend.api.agent_mesh import build_agent_card

        card_data = build_agent_card()

    card = card_data.get("card", card_data)
    sig_block = card_data.get("signature", {})
    sig_value = sig_block.get("value", "")
    public_key_b64 = card.get("public_key", "")

    if not sig_value or not public_key_b64:
        return {"valid": False, "error": "Missing signature or public_key in card"}

    try:
        from apps.backend.api.agent_mesh import _canonical_json

        canonical = _canonical_json(card)
        sig_bytes = base64.urlsafe_b64decode(sig_value + "==")
        pk_bytes = base64.urlsafe_b64decode(public_key_b64 + "==")

        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

        pk = Ed25519PublicKey.from_public_bytes(pk_bytes)
        pk.verify(sig_bytes, canonical)
        fingerprint = base64.urlsafe_b64encode(pk_bytes).rstrip(b"=").decode("ascii")[:16]

        await _emit_agent_card_trace(tenant_id, "verify")
        await _meter_agent_card_access(tenant_id, "verify")

        return {"valid": True, "fingerprint": f"ed25519:{fingerprint}..."}
    except Exception as exc:
        return {"valid": False, "error": str(exc)}


def _dispatch_capability_state_show(
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch ww.capability.state.show (#3543)."""
    capability_id = str(parameters.get("capability_id") or "").strip()
    if not capability_id:
        raise ValueError("capability_id is required")
    from apps.backend.providers.portable_store import create_portable_store
    from apps.backend.services.capability_registry import load_capability_registry
    from apps.backend.services.capability_state_machine import (
        CapabilityStateMachine,
    )
    from apps.backend.services.zara.zara_awareness_service import (
        translate_capability_state_to_view,
    )
    from apps.backend.workmemory.agent_awareness_store import (
        AgentAwarenessStore,
        Readiness,
    )

    registry = load_capability_registry()
    try:
        row = registry.find(capability_id)
    except KeyError:
        return {
            "capability_id": capability_id,
            "error": "capability_not_in_registry",
        }
    declared_state = row.state
    store = AgentAwarenessStore(store=create_portable_store())
    tenant_row = store.get_capability(tenant_id, capability_id) or {}
    tenant_readiness_value = tenant_row.get("readiness")
    if tenant_readiness_value:
        try:
            tenant_state = CapabilityStateMachine.from_readiness(
                Readiness(tenant_readiness_value)
            )
        except ValueError:
            tenant_state = declared_state
    else:
        tenant_state = declared_state
    return {
        "capability_id": capability_id,
        "tenant_id": tenant_id,
        "declared_state": declared_state.value,
        "declared_view": translate_capability_state_to_view(declared_state),
        "tenant_state": tenant_state.value,
        "tenant_view": translate_capability_state_to_view(tenant_state),
        "last_probe_at": tenant_row.get("last_probe_at"),
        "last_probe_outcome": tenant_row.get("last_probe_outcome"),
    }


def _dispatch_capability_state_list(parameters: dict[str, Any]) -> dict[str, Any]:
    """Dispatch ww.capability.state.list (#3543)."""
    from apps.backend.services.capability_registry import load_capability_registry
    from apps.backend.services.zara.zara_awareness_service import (
        translate_capability_state_to_view,
    )

    state_filter = parameters.get("state")
    registry = load_capability_registry()
    rows = []
    for row in registry.rows:
        if state_filter and row.state.value != state_filter:
            continue
        rows.append(
            {
                "capability_id": row.capability_id,
                "state": row.state.value,
                "view": translate_capability_state_to_view(row.state),
            }
        )
    return {"rows": rows, "total": len(rows)}


def _dispatch_voice_persona_tool(
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch voice persona MCP tools (#2798)."""
    from apps.backend.api.voice_persona_mcp import dispatch_voice_persona_tool
    from apps.backend.services.voice_persona_store import get_voice_persona_service

    service = get_voice_persona_service()
    result = dispatch_voice_persona_tool(
        tool_name=tool_name, tenant_id=tenant_id, parameters=parameters, service=service,
    )
    if isinstance(result, dict):
        return result
    if isinstance(result, list):
        if tool_name == "ww.voice.catalog.list":
            return {"voices": result}
        return {"personas": result}
    return {"result": result}


def _dispatch_workspace_persona_tool(
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
) -> dict[str, Any]:
    """Dispatch the WorkspacePersonaOverlay MCP tools (#3542)."""
    from apps.backend.models.workspace_persona_overlay import (
        PersonaOverlayValidationError,
    )
    from apps.backend.services.persona_overlay_service import (
        get_persona_overlay_service,
    )

    service = get_persona_overlay_service()
    actor_id = str(parameters.get("actor_id") or "mcp").strip() or "mcp"

    if tool_name == "ww.workspace.persona.show":
        overlay = service.get(tenant_id=tenant_id)
        if overlay is None:
            return {"set": False, "overlay": None}
        return {"set": True, "overlay": overlay.model_dump(mode="json")}

    if tool_name == "ww.workspace.persona.set":
        raw = parameters.get("overlay") if isinstance(parameters.get("overlay"), dict) else None
        if raw is None:
            raw = {k: v for k, v in parameters.items() if k != "actor_id"}
        try:
            overlay = service.set_from_payload(
                tenant_id=tenant_id,
                payload=raw,
                actor_id=actor_id,
            )
        except PersonaOverlayValidationError as exc:
            return {
                "status": "error",
                "error": "persona_overlay_validation_failed",
                "message": str(exc),
                "violating_keys": exc.violating_keys,
            }
        return {"set": True, "overlay": overlay.model_dump(mode="json")}

    if tool_name == "ww.workspace.persona.reset":
        service.reset(tenant_id=tenant_id, actor_id=actor_id)
        return {"status": "ok", "operation": "workspace.persona.reset"}

    raise ValueError(f"Unknown workspace persona MCP tool: {tool_name}")
