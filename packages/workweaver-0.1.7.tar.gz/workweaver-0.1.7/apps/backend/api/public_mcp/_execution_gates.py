"""Execution gate logic for public MCP connector operations (#3928).

Extracted from _dispatch.py. Contains operation type classification,
gate evaluation, side-effect proof validation, and policy decision helpers.
"""

from __future__ import annotations

import logging
from typing import Any

from apps.backend.api.public_mcp._constants import (
    _PLAN_STEER_MCP_TOOLS,
    _GUARDED_PUBLIC_MCP_TOOLS,
    _SAFE_OPERATION_PREFIXES,
    _HIGH_RISK_OPERATION_PREFIXES,
    _SAFE_CONNECTOR_HTTP_METHODS,
    _CONNECTOR_EXECUTE_TOOL_NAMES,
)

logger = logging.getLogger(__name__)


def _pkg():
    """Return the public_mcp package module for monkeypatch-compatible lookups."""
    import apps.backend.api.public_mcp as _m
    return _m


def _get_execution_guard():  # noqa: ANN201
    """Lazy-load the canonical execution safety gate."""
    from apps.backend.services.execution.guard_service import get_execution_guard

    return get_execution_guard()


def _normalize_connector_operation(operation: Any) -> str:
    """Collapse provider-specific operation names into guard-friendly verbs."""
    op = str(operation or "execute").strip().lower().replace("-", "_")
    op_parts = {part for part in op.split("_") if part}
    for prefix in _HIGH_RISK_OPERATION_PREFIXES:
        if op == prefix or op.startswith(f"{prefix}_") or prefix in op_parts:
            return prefix
    for prefix in _SAFE_OPERATION_PREFIXES:
        if op == prefix or op.startswith(f"{prefix}_"):
            return prefix
    return op or "execute"


def _mcp_operation_type(tool_name: str, parameters: dict[str, Any]) -> str:
    if tool_name in _PLAN_STEER_MCP_TOOLS:
        return str(parameters.get("action") or "control").strip().lower() or "control"
    if tool_name == "ww.connector.import.openapi":
        return "import"
    if tool_name == "ww.skill.import":
        return "read" if bool(parameters.get("dry_run", True)) else "create"
    if tool_name in {"ww.skill.curator.latest", "ww.skill.curator.list"}:
        return "read"
    if tool_name == "ww.skill.curator.run":
        return "execute"
    if tool_name == "ww.skill.curator.respond":
        return "update"
    if tool_name == "ww.mission.reversal.request":
        return "read" if bool(parameters.get("dry_run", False)) else "create"
    if tool_name == "ww.connector.execute" and bool(parameters.get("dry_run", False)):
        if _connector_has_public_dry_run_preview(parameters):
            return "read"
    return _normalize_connector_operation(parameters.get("operation"))


def _guarded_mcp_operation_requires_gate(tool_name: str, operation_type: str) -> bool:
    if tool_name in _PLAN_STEER_MCP_TOOLS:
        return operation_type == "approve"
    if tool_name in {"ww.connector.execute", "workweaver.connector.execute"} and operation_type == "read":
        return False
    if tool_name == "ww.skill.import" and operation_type == "read":
        return False
    if tool_name in {"ww.skill.curator.latest", "ww.skill.curator.list"} and operation_type == "read":
        return False
    if tool_name == "ww.mission.reversal.request" and operation_type == "read":
        return False
    if tool_name in _CONNECTOR_EXECUTE_TOOL_NAMES and operation_type == "read":
        return False
    return tool_name in _GUARDED_PUBLIC_MCP_TOOLS


def _validate_mcp_plan_approve_actor(parameters: dict[str, Any]) -> None:
    action = str(parameters.get("action") or "").strip().lower()
    if action != "approve":
        return
    from fastapi import HTTPException

    actor_id = str(parameters.get("actor_id") or "").strip()
    if not actor_id or actor_id.lower() in {"mcp", "agent", "zara", "system"}:
        raise HTTPException(status_code=403, detail="MCP plan approval requires a member actor_id")
    expected_revision = parameters.get("expected_revision")
    if expected_revision is None:
        raise HTTPException(status_code=422, detail="MCP plan approval requires expected_revision")
    try:
        reviewed_revision = int(expected_revision)
    except (TypeError, ValueError):
        raise HTTPException(status_code=422, detail="MCP plan approval requires integer expected_revision") from None
    if reviewed_revision < 1:
        raise HTTPException(status_code=422, detail="MCP plan approval requires positive expected_revision")
    parameters["expected_revision"] = reviewed_revision
    if not str(parameters.get("idempotency_key") or "").strip():
        raise HTTPException(status_code=422, detail="MCP plan approval requires idempotency_key")


def _policy_decision_to_dict(decision: Any) -> dict[str, Any]:
    verdict = getattr(decision, "verdict", None)
    return {
        "verdict": getattr(verdict, "value", verdict),
        "reasons": list(getattr(decision, "reasons", []) or []),
        "requires_approval_from": getattr(decision, "requires_approval_from", None),
        "evidence_receipt": getattr(decision, "evidence_receipt", None),
    }


def _policy_envelope_to_legacy_decision(envelope: Any, decision: Any | None = None) -> dict[str, Any]:
    legacy = _policy_decision_to_dict(decision) if decision is not None else {}
    final = str(getattr(envelope, "final_verdict", "") or "").lower()
    legacy.setdefault("verdict", "require_approval" if final == "require_approval" else final)
    legacy.setdefault("reasons", [getattr(item, "reason", "") for item in getattr(envelope, "sub_verdicts", [])])
    legacy["envelope"] = envelope.to_public_dict() if hasattr(envelope, "to_public_dict") else envelope
    return legacy


def _policy_block_response(
    *,
    tenant_id: str,
    tool_name: str,
    operation_type: str,
    status: str,
    error: str,
    policy_decision: dict[str, Any] | None = None,
) -> dict[str, Any]:
    response = {
        "tenant_id": tenant_id,
        "tool_name": tool_name,
        "operation_type": operation_type,
        "status": status,
        "error": error,
    }
    if policy_decision is not None:
        response["policy_decision"] = policy_decision
    return response


def _connector_operation_http_method(*, tenant_id: str, parameters: dict[str, Any]) -> str | None:
    connector_id = str(parameters.get("connector_id") or "").strip()
    operation_id = str(parameters.get("operation") or "").strip()
    if not connector_id or not operation_id:
        return None

    try:
        from apps.backend.services.connectors.standard_connector_registry import (
            get_standard_connector_registry,
            is_custom_connector_id,
        )

        if not is_custom_connector_id(connector_id):
            return None
        item = get_standard_connector_registry().get_definition(tenant_id, connector_id)
    except Exception:
        return None

    definition = item.get("Definition") if isinstance(item, dict) else None
    if not isinstance(definition, dict):
        return None
    for operation in definition.get("operations") or []:
        if isinstance(operation, dict) and operation.get("id") == operation_id:
            return str(operation.get("method") or "").strip().upper() or None
    return None


def _connector_has_public_dry_run_preview(parameters: dict[str, Any]) -> bool:
    connector_id = str(parameters.get("connector_id") or "").strip()
    if not connector_id:
        return False
    try:
        from apps.backend.api.connectors._core import _CONNECTOR_CLASSES, _load_connector_classes
        from apps.backend.services.connectors.base import ConnectorBase

        _load_connector_classes()
        connector_cls = _CONNECTOR_CLASSES.get(connector_id)
        if connector_cls is None:
            return False
        return connector_cls._dry_run_preview is not ConnectorBase._dry_run_preview
    except Exception:
        return False


def _operation_requires_side_effect_proof(
    tool_name: str,
    operation_type: str,
    *,
    http_method: str | None = None,
    dry_run_preview_supported: bool = False,
) -> bool:
    if tool_name in _CONNECTOR_EXECUTE_TOOL_NAMES and dry_run_preview_supported:
        return False
    if not _guarded_mcp_operation_requires_gate(tool_name, operation_type):
        return False
    if http_method:
        return http_method.upper() not in _SAFE_CONNECTOR_HTTP_METHODS
    return True


def _strip_side_effect_proof(parameters: dict[str, Any]) -> dict[str, Any]:
    cleaned = dict(parameters)
    cleaned.pop("side_effect_proof", None)
    cleaned.pop("verified_actor_id", None)
    cleaned.pop("verified_actor_role", None)
    nested_params = cleaned.get("params")
    if isinstance(nested_params, dict):
        cleaned["params"] = {
            key: value
            for key, value in nested_params.items()
            if key not in {"side_effect_proof", "verified_actor_id", "verified_actor_role"}
        }
    return cleaned


def _validate_public_mcp_side_effect_proof(
    *,
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
    policy_decision: dict[str, Any] | None,
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    operation_type = _mcp_operation_type(tool_name, parameters)
    http_method = None if tool_name in _PLAN_STEER_MCP_TOOLS else _pkg()._connector_operation_http_method(
        tenant_id=tenant_id,
        parameters=parameters,
    )
    dry_run_preview_supported = (
        tool_name in _CONNECTOR_EXECUTE_TOOL_NAMES
        and bool(parameters.get("dry_run", False))
        and _connector_has_public_dry_run_preview(parameters)
    )
    if not _operation_requires_side_effect_proof(
        tool_name,
        operation_type,
        http_method=http_method,
        dry_run_preview_supported=dry_run_preview_supported,
    ):
        return None, None

    from apps.backend.services.side_effect_proof import (
        SideEffectProofError,
        side_effect_proof_summary,
        validate_side_effect_proof_bundle,
    )

    proof_payload = parameters.get("side_effect_proof")
    if not isinstance(proof_payload, dict):
        nested_params = parameters.get("params")
        if isinstance(nested_params, dict):
            proof_payload = nested_params.get("side_effect_proof")
    evidence_receipt = (policy_decision or {}).get("evidence_receipt")
    expected_policy_verdict_id = None
    if isinstance(evidence_receipt, dict):
        expected_policy_verdict_id = str(evidence_receipt.get("policy_verdict_id") or "").strip() or None
    if expected_policy_verdict_id is None:
        return None, _policy_block_response(
            tenant_id=tenant_id,
            tool_name=tool_name,
            operation_type=operation_type,
            status="proof_required",
            error="Connector side effect blocked until execution guard emits a policy_verdict_id",
            policy_decision=policy_decision,
        )
    try:
        bundle = validate_side_effect_proof_bundle(
            proof_payload,
            tenant_id=tenant_id,
            expected_policy_verdict_id=expected_policy_verdict_id,
            require_decision=True,
            require_timeblock=True,
            require_trace_envelope=True,
        )
    except SideEffectProofError as exc:
        return None, _policy_block_response(
            tenant_id=tenant_id,
            tool_name=tool_name,
            operation_type=operation_type,
            status="proof_required",
            error=f"Connector side effect blocked until proof bundle is complete: {exc}",
            policy_decision=policy_decision,
        )
    return side_effect_proof_summary(bundle), None


def _evaluate_public_mcp_execution_gate(
    *,
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
) -> tuple[dict[str, Any] | None, dict[str, Any] | None]:
    """Evaluate the canonical gate for public MCP tools with external effects.

    Returns ``(policy_decision, block_response)``. ``block_response`` is
    non-None when the downstream handler must not run.
    """
    operation_type = _mcp_operation_type(tool_name, parameters)
    if (
        tool_name in _CONNECTOR_EXECUTE_TOOL_NAMES
        and bool(parameters.get("dry_run", False))
        and _connector_has_public_dry_run_preview(parameters)
    ):
        return None, None
    if not _guarded_mcp_operation_requires_gate(tool_name, operation_type):
        return None, None

    from apps.backend.services.execution.guard_service import AutomationLevel
    from apps.backend.services.policy_authority import build_policy_decision_envelope, execution_guard_sub_verdict
    try:
        decision = _pkg()._get_execution_guard().evaluate(
            tenant_id=tenant_id,
            tool_id=tool_name,
            operation_type=operation_type,
            automation_level=AutomationLevel.ASK_TO_EXECUTE,
            inputs=parameters,
            agent_id=str(parameters.get("agent_id") or "agent:mcp").strip(),
            entity_id=str(parameters.get("agent_id") or parameters.get("connector_id") or "").strip() or None,
            session_id=str(parameters.get("session_id") or parameters.get("trace_id") or "").strip() or None,
            policy_tool_name=tool_name,
            capture_surface="mcp_public",
            service_family="public_mcp",
            context_data={
                "connector_id": parameters.get("connector_id"),
                "requested_operation": parameters.get("operation"),
                "trace_id": parameters.get("trace_id"),
            },
        )
    except Exception as exc:
        logger.warning("public_mcp.execution_guard_unavailable", exc_info=True)
        return None, _policy_block_response(
            tenant_id=tenant_id,
            tool_name=tool_name,
            operation_type=operation_type,
            status="policy_denied",
            error=f"Execution safety gate unavailable: {exc}",
        )

    actor_id = str(parameters.get("agent_id") or "agent:mcp").strip()
    guard_sub_verdict = execution_guard_sub_verdict(decision)
    envelope = build_policy_decision_envelope(
        "connector",
        tenant_id=tenant_id,
        actor={"actor_id": actor_id},
        inputs={
            "action": f"{tool_name}:{operation_type}",
            "execution_verdict": guard_sub_verdict.verdict,
            "execution_reason": guard_sub_verdict.reason,
            "execution_evidence_id": guard_sub_verdict.evidence_id,
            "execution_metadata": guard_sub_verdict.metadata,
            "family_policy_reason": "public MCP connector policy preflight completed",
            "family_policy_metadata": {
                "connector_id": parameters.get("connector_id"),
                "requested_operation": parameters.get("operation"),
            },
        },
    )
    policy_decision = _policy_envelope_to_legacy_decision(envelope, decision)
    if envelope.final_verdict == "ALLOW":
        return policy_decision, None
    if envelope.final_verdict == "REQUIRE_APPROVAL":
        return policy_decision, _policy_block_response(
            tenant_id=tenant_id,
            tool_name=tool_name,
            operation_type=operation_type,
            status="approval_required",
            error="Execution requires approval before connector side effects may run",
            policy_decision=policy_decision,
        )
    if envelope.final_verdict == "DRAFT":
        return policy_decision, _policy_block_response(
            tenant_id=tenant_id,
            tool_name=tool_name,
            operation_type=operation_type,
            status="draft_only",
            error="Execution posture allows only a draft; connector side effects were not run",
            policy_decision=policy_decision,
        )
    return policy_decision, _policy_block_response(
        tenant_id=tenant_id,
        tool_name=tool_name,
        operation_type=operation_type,
        status="policy_denied",
        error="Execution denied by canonical safety gate",
        policy_decision=policy_decision,
    )
