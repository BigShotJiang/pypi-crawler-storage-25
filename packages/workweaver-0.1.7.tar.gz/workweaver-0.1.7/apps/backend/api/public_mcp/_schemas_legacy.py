"""Legacy workweaver.* MCP tool schema definitions.

Extracted from the original monolithic public_mcp.py (#3928).
"""

from __future__ import annotations

from typing import Any

from apps.backend.services.research_capability import research_tool_input_schema

# =====================================================================# MCP Tool Schema Definitions
# =====================================================================
_LEGACY_PUBLIC_MCP_TOOLS: list[dict[str, Any]] = [
    {
        "name": "workweaver.task.create",
        "description": "Create a task for an agent.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Task title"},
                "description": {"type": "string", "description": "Task description", "default": ""},
                "assigned_agent": {"type": "string", "description": "Agent ID to assign task to"},
                "priority": {
                    "type": "string",
                    "description": "Priority level",
                    "enum": ["urgent", "high", "medium", "low"],
                    "default": "medium",
                },
            },
            "required": ["title"],
        },
    },
    {
        "name": "workweaver.task.status",
        "description": "Check the status of a task.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "task_id": {"type": "string", "description": "Task ID to check"},
            },
            "required": ["task_id"],
        },
    },
    {
        "name": "workweaver.agent.list",
        "description": "List the workspace's agents.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "status_filter": {"type": "string", "description": "Filter by agent status"},
            },
        },
    },
    {
        "name": "workweaver.agent.run",
        "description": "Trigger agent execution with a task description.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Agent ID to run"},
                "task": {"type": "string", "description": "Task description for the agent"},
            },
            "required": ["agent_id", "task"],
        },
    },
    {
        "name": "workweaver.schedule.create",
        "description": "Create a recurring or triggered schedule for an agent.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Agent ID"},
                "title": {"type": "string", "description": "Schedule title"},
                "schedule_type": {
                    "type": "string",
                    "description": "Schedule type",
                    "enum": ["one_time", "recurring", "triggered"],
                },
                "cron_expression": {"type": "string", "description": "Cron expression for recurring"},
                "description": {"type": "string", "description": "Schedule description", "default": ""},
            },
            "required": ["agent_id", "title", "schedule_type"],
        },
    },
    {
        "name": "workweaver.schedule.trigger",
        "description": "Fire a triggered schedule immediately.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schedule_id": {"type": "string", "description": "Schedule ID to trigger"},
            },
            "required": ["schedule_id"],
        },
    },
    {
        "name": "workweaver.evidence.query",
        "description": "Query the evidence ledger for a workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Filter by agent ID"},
                "event_type": {"type": "string", "description": "Filter by event type"},
                "limit": {"type": "integer", "description": "Max results", "default": 50},
            },
        },
    },
    {
        "name": "workweaver.approval.list",
        "description": "List pending approval requests for the workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "limit": {"type": "integer", "description": "Max results", "default": 20},
            },
        },
    },
    {
        "name": "workweaver.approval.approve",
        "description": "Approve a pending action.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "request_id": {"type": "string", "description": "Approval request ID"},
                "actor_id": {"type": "string", "description": "User ID approving"},
            },
            "required": ["request_id", "actor_id"],
        },
    },
    {
        "name": "workweaver.approval.reject",
        "description": "Reject a pending action.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "request_id": {"type": "string", "description": "Approval request ID"},
                "actor_id": {"type": "string", "description": "User ID rejecting"},
                "reason": {"type": "string", "description": "Rejection reason", "default": ""},
            },
            "required": ["request_id", "actor_id"],
        },
    },
    {
        "name": "ww.operational_context.show",
        "description": "Show the Operational Context read model for one subject.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "subject_id": {"type": "string", "description": "Subject ID to query"},
            },
            "required": ["subject_id"],
        },
    },
    {
        "name": "ww.operational_context.workspace",
        "description": "Show Workspace Operational Context across permitted Member scopes.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "workspace_id": {"type": "string", "description": "Workspace ID to query"},
                "member_id": {"type": "string", "description": "Optional Member scope"},
                "kind": {"type": "string", "description": "Optional event kind filter"},
                "entity": {"type": "string", "description": "Optional entity filter"},
                "since": {"type": "string", "description": "Optional ISO timestamp lower bound"},
                "cursor": {"type": "string", "description": "Pagination cursor"},
                "limit": {"type": "integer", "description": "Max records", "default": 50},
            },
            "required": ["workspace_id"],
        },
    },
    {
        "name": "ww.operational_context.share",
        "description": "Grant a scoped Operational Context Permission.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "grant_to": {"type": "string", "description": "Member ID or external API key receiving the grant"},
                "scope": {"type": "object", "description": "Permission scope"},
                "expires_at": {"type": "string", "description": "Grant expiry as ISO timestamp"},
                "rights": {
                    "type": "array",
                    "items": {"type": "string", "enum": ["read", "write"]},
                    "default": ["read"],
                },
            },
            "required": ["grant_to", "scope", "expires_at", "rights"],
        },
    },
    # -- Agent Protocol tools -----------------------------------------------
    {
        "name": "workweaver.org.query",
        "description": "Query org-level questions via the default Workweaver agent.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "question": {"type": "string", "description": "Natural language question to ask"},
            },
            "required": ["question"],
        },
    },
    {
        "name": "workweaver.org.audit_log",
        "description": "Query the org-level audit log for lease, dispatch, and org-scope evidence events.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "org_id": {"type": "string", "description": "Org ID to query, or current", "default": "current"},
                "since": {
                    "type": "string",
                    "description": "ISO timestamp or relative duration such as 7d",
                    "default": "7d",
                },
                "until": {"type": "string", "description": "Optional ISO timestamp upper bound"},
                "actor": {"type": "string", "description": "Optional actor user ID filter"},
                "event_type": {
                    "type": "array",
                    "description": "Optional event type filters",
                    "items": {"type": "string"},
                    "default": [],
                },
                "limit": {"type": "integer", "description": "Max audit events", "default": 50},
                "cursor": {"type": "string", "description": "Pagination cursor from the previous response"},
            },
        },
    },
    {
        "name": "workweaver.agent.query",
        "description": "Query a specific Workweaver agent by ID.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Target agent ID"},
                "question": {"type": "string", "description": "Natural language question to ask"},
            },
            "required": ["agent_id", "question"],
        },
    },
    # -- Connector tools ----------------------------------------------------
    {
        "name": "workweaver.connector.install",
        "description": "Install a connector for the workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "connector_id": {
                    "type": "string",
                    "description": "Connector ID (e.g. ghost, zoho-crm, slack)",
                },
                "credentials": {
                    "type": "object",
                    "description": "Connector credentials as key-value pairs",
                    "default": {},
                },
            },
            "required": ["connector_id", "credentials"],
        },
    },
    {
        "name": "workweaver.connector.execute",
        "description": "Execute an operation on an installed connector.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "connector_id": {"type": "string", "description": "Connector ID"},
                "operation": {"type": "string", "description": "Operation to execute"},
                "params": {
                    "type": "object",
                    "description": "Operation parameters",
                    "default": {},
                },
                "dry_run": {
                    "type": "boolean",
                    "description": "Return a side-effect preview without provider execution.",
                    "default": False,
                },
                "idempotency_key": {
                    "type": "string",
                    "description": "Stable caller key reused from preview to live execution.",
                },
            },
            "required": ["connector_id", "operation"],
        },
    },
    {
        "name": "workweaver.connector.list",
        "description": "List installed connectors for the workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "ww.research.search",
        "description": "Run bounded workspace-scoped web research through the shared research lease contract.",
        "inputSchema": research_tool_input_schema(),
    },
    # -- CLI capability wrappers --------------------------------------------
    {
        "name": "workweaver.mission.list",
        "description": "List work items (missions) with optional filters.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "status": {"type": "string", "description": "Filter by WorkItem status"},
                "agent_id": {"type": "string", "description": "Filter by assigned agent ID"},
                "limit": {"type": "integer", "description": "Max results", "default": 25},
            },
        },
    },
    {
        "name": "workweaver.plan.list",
        "description": "List Zara objective plans and execution history.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "description": "Filter by plan status",
                    "enum": ["active", "approved", "blocked", "archived", "completed", "cancelled", "failed"],
                },
                "limit": {"type": "integer", "description": "Max results", "default": 50},
            },
        },
    },
    {
        "name": "workweaver.plan.show",
        "description": "Show a Zara objective plan, revisions, and executions.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "plan_id": {"type": "string", "description": "Plan ID to inspect"},
            },
            "required": ["plan_id"],
        },
    },
    {
        "name": "workweaver.plan.steer",
        "description": "Approve, revise, block, or archive a Zara objective plan.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "plan_id": {"type": "string", "description": "Plan ID to control"},
                "action": {
                    "type": "string",
                    "description": "Plan control action",
                    "enum": ["approve", "steer", "block", "archive"],
                },
                "instruction": {
                    "type": "string",
                    "description": "Natural-language steering or block/archive context",
                    "default": "",
                },
                "actor_id": {
                    "type": "string",
                    "description": "Human member ID; required when action=approve.",
                },
                "expected_revision": {
                    "type": "integer",
                    "description": "Plan revision the caller reviewed before acting.",
                },
                "idempotency_key": {
                    "type": "string",
                    "description": "Stable retry key for this plan-control action.",
                },
            },
            "required": ["plan_id", "action"],
            "allOf": [
                {
                    "if": {"properties": {"action": {"const": "approve"}}, "required": ["action"]},
                    "then": {"required": ["actor_id", "expected_revision", "idempotency_key"]},
                }
            ],
        },
    },
    {
        "name": "ww.plan.list",
        "description": "List Zara objective plans and execution history.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "status": {
                    "type": "string",
                    "description": "Filter by plan status",
                    "enum": ["active", "approved", "blocked", "archived", "completed", "cancelled", "failed"],
                },
                "limit": {"type": "integer", "description": "Max results", "default": 50},
            },
        },
    },
    {
        "name": "ww.plan.show",
        "description": "Show a Zara objective plan, revisions, and executions.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "plan_id": {"type": "string", "description": "Plan ID to inspect"},
            },
            "required": ["plan_id"],
        },
    },
    {
        "name": "ww.plan.steer",
        "description": "Approve, revise, block, or archive a Zara objective plan.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "plan_id": {"type": "string", "description": "Plan ID to control"},
                "action": {
                    "type": "string",
                    "description": "Plan control action",
                    "enum": ["approve", "steer", "block", "archive"],
                },
                "instruction": {
                    "type": "string",
                    "description": "Natural-language steering or block/archive context",
                    "default": "",
                },
                "actor_id": {
                    "type": "string",
                    "description": "Human member ID; required when action=approve.",
                },
                "expected_revision": {
                    "type": "integer",
                    "description": "Plan revision the caller reviewed before acting.",
                },
                "idempotency_key": {
                    "type": "string",
                    "description": "Stable retry key for this plan-control action.",
                },
            },
            "required": ["plan_id", "action"],
            "allOf": [
                {
                    "if": {"properties": {"action": {"const": "approve"}}, "required": ["action"]},
                    "then": {"required": ["actor_id", "expected_revision", "idempotency_key"]},
                }
            ],
        },
    },
    {
        "name": "ww.mission.steer",
        "description": "Steer a running mission with a typed action after verified mission ownership (cancel, modify, escalate, etc.).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mission_id": {
                    "type": "string",
                    "description": "Mission ID to steer.",
                },
                "action_kind": {
                    "type": "string",
                    "description": "Typed action kind",
                    "enum": [
                        "cancel", "modify", "escalate", "reschedule",
                        "reassign", "block", "archive", "extend_skill",
                        "new_variant", "redirect_channel",
                    ],
                },
                "payload": {
                    "type": "object",
                    "description": "Action-specific metadata.",
                    "default": {},
                },
                "idempotency_key": {
                    "type": "string",
                    "description": "Client-generated dedup key.",
                },
                "actor_id": {
                    "type": "string",
                    "description": "Verified Member ID of the actor.",
                },
            },
            "required": ["mission_id", "action_kind", "idempotency_key", "actor_id"],
        },
    },
    {
        "name": "ww.mission.outcome_review",
        "description": "Accept, reject, or correct a reported mission outcome before final TimeBlock completion and Skillify promotion.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mission_id": {"type": "string", "description": "Mission whose reported outcome is being reviewed."},
                "outcome_id": {"type": "string", "description": "Reported outcome or evidence identifier under review."},
                "timeblock_id": {"type": "string", "description": "Optional Mission Calendar TimeBlock to finalize after accept/correct."},
                "decision": {
                    "type": "string",
                    "enum": ["accept", "reject", "correct"],
                    "description": "Review decision. Only accept/correct finalize completion.",
                },
                "correction": {"type": "string", "description": "Required when decision=correct."},
                "evidence_ref_ids": {
                    "type": "array",
                    "items": {"type": "string"},
                    "default": [],
                    "description": "Evidence references supporting the review.",
                },
                "idempotency_key": {"type": "string", "description": "Stable retry key for this review."},
                "actor_id": {"type": "string", "description": "Verified Member ID of the reviewer."},
            },
            "required": ["mission_id", "outcome_id", "decision", "actor_id"],
        },
    },
    {
        "name": "ww.mission.admission",
        "description": "Read the durable per-Mission worker admission gate snapshot (cap, active workers, lease expiries) — issue #3282.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mission_id": {
                    "type": "string",
                    "description": "Mission ID to inspect.",
                },
            },
            "required": ["mission_id"],
        },
    },
    {
        "name": "ww.mission.breaker",
        "description": "Read or reset the per-Mission spawn circuit breaker — issue #3283. Default action is show; pass action=reset with optional reason for operator manual reset.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mission_id": {
                    "type": "string",
                    "description": "Mission ID to inspect or reset.",
                },
                "action": {
                    "type": "string",
                    "enum": ["show", "reset"],
                    "default": "show",
                },
                "reason": {
                    "type": "string",
                    "description": "Reason recorded with the reset Decision Trace.",
                    "default": "operator override",
                },
            },
            "required": ["mission_id"],
        },
    },
    {
        "name": "ww.mission.reversal.request",
        "description": "Preview or dispatch mission-level compensating actions from Evidence Ledger side-effect records.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "mission_id": {
                    "type": "string",
                    "description": "Mission ID whose side effects should be reversed.",
                },
                "requested_by": {
                    "type": "string",
                    "description": "Principal requesting the reversal.",
                    "default": "mcp",
                },
                "dry_run": {
                    "type": "boolean",
                    "description": "Return the reversal plan without dispatching compensating actions.",
                    "default": False,
                },
            },
            "required": ["mission_id"],
        },
    },
    {
        "name": "ww.strategy.trace",
        "description": "List strategic decision traces (OKR + DecisionEvent projection over domain=strategy).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "okr_id": {"type": "string", "description": "Optional OKR ID to filter to a single strategic trace"},
                "limit": {"type": "integer", "description": "Max decisions to scan", "default": 100},
            },
        },
    },
    {
        "name": "workweaver.workitem.create",
        "description": "Create a new work item.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "title": {"type": "string", "description": "Work item title"},
                "description": {"type": "string", "description": "Work item description", "default": ""},
                "source_kind": {
                    "type": "string",
                    "description": "Source kind",
                    "enum": ["goal", "task"],
                    "default": "task",
                },
                "priority": {
                    "type": "string",
                    "description": "Priority",
                    "enum": ["urgent", "high", "medium", "low"],
                    "default": "medium",
                },
            },
            "required": ["title"],
        },
    },
    {
        "name": "workweaver.memory.store",
        "description": "Store a memory item for the workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "content": {"type": "string", "description": "Memory content to store"},
                "scope": {
                    "type": "string",
                    "description": "Memory scope",
                    "enum": ["tenant", "agent", "session"],
                    "default": "tenant",
                },
                "agent_id": {"type": "string", "description": "Agent ID (required when scope=agent)"},
            },
            "required": ["content"],
        },
    },
    {
        "name": "workweaver.config.get",
        "description": "Get workspace configuration value.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "key": {"type": "string", "description": "Configuration key to retrieve"},
            },
            "required": ["key"],
        },
    },
    {
        "name": "workweaver.entity.list",
        "description": "List entities for the workspace.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "entity_type": {"type": "string", "description": "Filter by entity type"},
                "limit": {"type": "integer", "description": "Max results", "default": 50},
            },
        },
    },
    {
        "name": "ww.ontology.query",
        "description": "Query workspace ontology nodes for entity schemas, skills, capabilities, policies, and workflows.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "q": {"type": "string", "description": "Search text", "default": ""},
                "kind": {
                    "type": "string",
                    "description": "Optional ontology node kind",
                    "enum": ["entity_schema", "entity_instance", "skill", "capability", "policy", "workflow"],
                },
                "limit": {"type": "integer", "description": "Max results", "default": 50},
            },
        },
    },
    {
        "name": "ww.policy.authority",
        "description": "Inspect the PolicyDecisionEnvelope authority map and final verdict contract.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "ww.governance.anchor.list",
        "description": (
            "List file paths protected by the L4 governance anchor — "
            "kernel skill registry, policy authority map, floor schema, CI gates. "
            "Sub-L4 promotions touching these paths are denied at preflight (#3547)."
        ),
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "ww.policy.allowlist.list",
        "description": "List platform and tenant policy allowlist entries for a kind.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "kind": {
                    "type": "string",
                    "description": "Allowlist kind to list.",
                    "enum": ["TOOL"],
                    "default": "TOOL",
                },
            },
        },
    },
    {
        "name": "ww.kernel.healing.recent",
        "description": "List recent self-healing recovery actions classified by RemediationPosture (auto_reversible / approval_reversible / escalate_irreversible). #3545.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "window_hours": {
                    "type": "integer",
                    "description": "Lookback window in hours (1-720).",
                    "default": 24,
                    "minimum": 1,
                    "maximum": 720,
                },
            },
        },
    },
    {
        "name": "ww.kernel.skill.list",
        "description": "List the six §14 KernelSkills (kernel.process_inventory, kernel.skill_audit, kernel.memory_consolidation, kernel.capacity_check, kernel.connector_health, kernel.routing_audit). Read-only; immutable, owner=system. #2788.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "ww.kernel.skill.show",
        "description": "Show one §14 KernelSkill row by ID. Read-only. #2788.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "skill_id": {
                    "type": "string",
                    "description": "Kernel skill ID, e.g. kernel.connector_health.",
                },
            },
            "required": ["skill_id"],
        },
    },
    {
        "name": "ww.kernel.skill.run",
        "description": "Probe one §14 KernelSkill and emit a read-only Decision Trace classified as kernel.* with idempotent minute-bucket dedup. #2788.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "skill_id": {
                    "type": "string",
                    "description": "Kernel skill ID, e.g. kernel.connector_health.",
                },
            },
            "required": ["skill_id"],
        },
    },
    {
        "name": "ww.kernel.connector_locality",
        "description": "Connector locality matrix summary (entry count + per-side-effect-class counts + cloud-required class list) or per-operation explanation when connector_name + operation are provided. PAYMENT / IDENTITY / GOVERNANCE classes are never local-eligible. #2880.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "connector_name": {
                    "type": "string",
                    "description": "Optional connector id (e.g. stripe). Omit to list the matrix.",
                },
                "operation": {
                    "type": "string",
                    "description": "Optional operation id (e.g. charge_customer). Required when connector_name is given.",
                },
                "policy_modes": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Optional policy modes that may shift the decision to POLICY_REQUIRED.",
                },
            },
        },
    },
    {
        "name": "ww.kernel.zero_burn",
        "description": "Tenant-wide zero-burn SLI summary: dormant/total Functions, ratio, and status (clean / drifting / burning / unknown). Read-only. #2879.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "ww.kernel.probe.history",
        "description": "Most recent capability probe outcome for (tenant, capability_id). Read-only; reads the agent_awareness namespace populated by the multi-tenant capability readiness probe. #2340.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "capability_id": {
                    "type": "string",
                    "description": "Capability id, e.g. kernel.connector_health.",
                },
            },
            "required": ["capability_id"],
        },
    },
    {
        "name": "ww.evidence.trace.awareness",
        "description": "Replay the AwarenessSnapshot Zara consulted at plan time for a Decision Trace id. Returns 404 when the trace is legacy (no awareness_snapshot_id stamped) or the snapshot has aged out of retention. #3549.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "trace_id": {
                    "type": "string",
                    "description": "Decision Trace id (returned by ww.evidence.trace).",
                },
            },
            "required": ["trace_id"],
        },
    },
    {
        "name": "ww.healing.digest",
        "description": "Read the monthly healing digest — top auto-heal patterns + escalations + Skillify candidates + posture counts. Read-only. #3550.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "month": {
                    "type": "string",
                    "description": "YYYY-MM. Defaults to the current UTC month.",
                },
            },
        },
    },
    {
        "name": "ww.tenant.conflicts.list",
        "description": "Run the tenant_config × persona × governance × resource_policy conflict matrix and return the detected drift bundle. Read-only. #3548.",
        "inputSchema": {
            "type": "object",
            "properties": {},
        },
    },
    {
        "name": "ww.tenant.conflicts.show",
        "description": "Show one detected tenant conflict by id. Read-only. #3548.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "conflict_id": {
                    "type": "string",
                    "description": "Conflict id (returned by ww.tenant.conflicts.list).",
                },
            },
            "required": ["conflict_id"],
        },
    },
    {
        "name": "ww.tenant.conflicts.resolve",
        "description": "Record a resolution decision (accept_suggestion / reject / escalate) for a detected tenant conflict. AUTO_REVERSIBLE actions apply silently; everything else routes to operator approval. #3548.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "conflict_id": {
                    "type": "string",
                    "description": "Conflict id (returned by ww.tenant.conflicts.list).",
                },
                "action": {
                    "type": "string",
                    "enum": ["accept_suggestion", "reject", "escalate"],
                    "default": "accept_suggestion",
                },
            },
            "required": ["conflict_id"],
        },
    },
    {
        "name": "ww.payment.preflight",
        "description": "Return the deny-by-default PolicyDecisionEnvelope for a payment action without provider calls.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "action": {"type": "string", "default": "payment.manage"},
                "actor_id": {"type": "string", "default": "zara"},
                "provider": {"type": "string", "default": "stripe"},
                "amount": {"type": "number"},
                "currency": {"type": "string"},
                "mandate_id": {"type": "string"},
                "mandate_valid": {"type": "boolean"},
                "mandate_error": {"type": "string"},
            },
        },
    },
    {
        "name": "ww.entity_schema.create",
        "description": "Create a draft entity schema.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "fields": {"type": "array", "items": {"type": "object"}},
                "relationships": {"type": "array", "items": {"type": "object"}, "default": []},
                "dcl": {"type": "string", "enum": ["DCL-0", "DCL-1", "DCL-2", "DCL-3", "DCL-4"]},
                "owner": {"type": "string"},
                "created_by": {"type": "string"},
                "description": {"type": "string", "default": ""},
            },
            "required": ["name", "fields", "dcl", "owner", "created_by"],
        },
    },
    {
        "name": "ww.entity_schema.list",
        "description": "List entity schemas.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "status": {"type": "string", "enum": ["draft", "active", "retired"]},
                "limit": {"type": "integer", "default": 100},
            },
        },
    },
    {
        "name": "ww.entity_schema.get",
        "description": "Get an entity schema.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "version": {"type": "integer"},
            },
            "required": ["name"],
        },
    },
    {
        "name": "ww.entity_schema.activate",
        "description": "Activate a draft entity schema.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "version": {"type": "integer"},
                "actor_id": {"type": "string", "default": "mcp"},
            },
            "required": ["name", "version"],
        },
    },
    {
        "name": "ww.entity.record.create",
        "description": "Create a record for an active workspace entity schema.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema_name": {"type": "string", "description": "Active entity schema name."},
                "fields": {"type": "object", "description": "Record fields validated against the active schema."},
                "evidence_ids": {"type": "array", "items": {"type": "string"}, "default": []},
                "decision_id": {"type": "string"},
                "evidence_null_reason": {"type": "string"},
                "decision_null_reason": {"type": "string"},
            },
            "required": ["schema_name", "fields"],
        },
    },
    {
        "name": "ww.entity.record.get",
        "description": "Read a record for an active workspace entity schema.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema_name": {"type": "string", "description": "Active entity schema name."},
                "record_id": {"type": "string", "description": "Record id."},
            },
            "required": ["schema_name", "record_id"],
        },
    },
    {
        "name": "ww.entity.record.list",
        "description": "List records for an active workspace entity schema.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema_name": {"type": "string", "description": "Active entity schema name."},
                "limit": {"type": "integer", "description": "Max results", "default": 100},
            },
            "required": ["schema_name"],
        },
    },
    {
        "name": "ww.entity.record.update",
        "description": "Update a record for an active workspace entity schema.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema_name": {"type": "string", "description": "Active entity schema name."},
                "record_id": {"type": "string", "description": "Record id."},
                "fields": {"type": "object", "description": "Fields to update, validated against the active schema."},
                "evidence_ids": {"type": "array", "items": {"type": "string"}, "default": []},
                "decision_id": {"type": "string"},
                "evidence_null_reason": {"type": "string"},
                "decision_null_reason": {"type": "string"},
            },
            "required": ["schema_name", "record_id", "fields"],
        },
    },
    {
        "name": "ww.entity.record.schema",
        "description": "Describe allowed fields for entity record create/update tools.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema_name": {"type": "string", "description": "Active entity schema name."},
                "operation": {"type": "string", "enum": ["create", "update"], "default": "create"},
            },
            "required": ["schema_name"],
        },
    },
    {
        "name": "ww.entity.conflicts",
        "description": "List unresolved local/cloud sync conflicts for workspace entity records.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "schema_name": {"type": "string", "description": "Optional active entity schema name."},
            },
        },
    },
    {
        "name": "ww.entity.conflict.resolve",
        "description": "Explicitly resolve one local/cloud sync conflict for a workspace entity record.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "conflict_id": {"type": "string"},
                "strategy": {
                    "type": "string",
                    "enum": ["keep_local", "keep_cloud", "custom"],
                    "description": "Resolution strategy recorded for audit.",
                },
                "actor_id": {"type": "string", "default": "mcp"},
                "resolved_fields": {
                    "type": "object",
                    "description": "Required by callers when strategy is custom.",
                },
            },
            "required": ["conflict_id", "strategy"],
        },
    },
    {
        "name": "ww.swarm.status",
        "description": "List active swarm executions or show one execution.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "execution_id": {"type": "string", "description": "Optional execution ID to inspect"},
                "status": {
                    "type": "string",
                    "description": "Optional list filter",
                    "enum": ["active", "admitted", "running", "completed", "failed", "cancelled"],
                    "default": "active",
                },
                "limit": {"type": "integer", "description": "Max list results", "default": 50},
            },
        },
    },
    {
        "name": "ww.swarm.spawn",
        "description": "Plan and start a swarm execution from a free-text goal plus budget envelope.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "goal": {"type": "string", "description": "Free-text goal for the swarm to execute."},
                "budget": {
                    "type": "string",
                    "description": "Budget axes as tokens=N,dollars=N,wall=Ns,steps=N.",
                },
                "until_done": {
                    "type": "boolean",
                    "description": "Poll the execution until it reaches completed, failed, or cancelled.",
                    "default": False,
                },
                "auto_approve_tier": {
                    "type": "string",
                    "description": "Comma-separated tiers allowed to auto-execute. Only low and medium are accepted.",
                    "default": "low,medium",
                },
                "plan_mode": {
                    "type": "string",
                    "description": "Planner mode override.",
                    "enum": ["emergent", "self_organizing_emergent", "rigid"],
                },
                "agents": {
                    "type": "integer",
                    "description": "Requested worker count for capacity preflight.",
                    "minimum": 1,
                    "default": 1,
                },
                "is_foreground": {
                    "type": "boolean",
                    "description": "Evaluate spawn as a foreground Zara task.",
                    "default": False,
                },
            },
            "required": ["goal"],
        },
    },
    {
        "name": "ww.swarm.search_tools",
        "description": "Search CapabilityRegistry for tools a running swarm agent may request at decision time.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {"type": "string", "description": "Natural-language tool need."},
                "modality": {"type": "string", "description": "Optional capability family or action filter."},
                "agent_id": {"type": "string", "description": "Running swarm agent requesting discovery."},
                "limit": {
                    "type": "integer",
                    "description": "Maximum descriptors to return.",
                    "minimum": 1,
                    "maximum": 50,
                    "default": 10,
                },
            },
            "required": ["query", "agent_id"],
        },
    },
    {
        "name": "ww.swarm.activate_tool",
        "description": "Activate a discovered tool for a running swarm agent after Permission and Decision Trace gates.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "tool_name": {"type": "string", "description": "Canonical MCP tool name to activate."},
                "agent_id": {"type": "string", "description": "Running swarm agent requesting activation."},
                "search_query": {"type": "string", "description": "Discovery query that produced the tool."},
                "ttl_seconds": {
                    "type": "integer",
                    "description": "Activation lease TTL.",
                    "minimum": 1,
                    "maximum": 3600,
                    "default": 300,
                },
                "actor_chain": {
                    "type": "array",
                    "items": {"type": "string"},
                    "description": "Actor chain recorded in the Decision Trace.",
                },
                "idempotency_key": {"type": "string", "description": "Stable activation idempotency key."},
            },
            "required": ["tool_name", "agent_id", "idempotency_key"],
        },
    },
    {
        "name": "ww.swarm.cancel",
        "description": "Cancel a pending or running swarm execution.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "execution_id": {"type": "string", "description": "Execution ID to cancel"},
                "reason": {"type": "string", "description": "Cancellation reason for audit evidence"},
            },
            "required": ["execution_id"],
        },
    },
    {
        "name": "ww.swarm.constitution.create",
        "description": "Create a versioned shared constitution for swarm execution.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "name": {"type": "string"},
                "content": {"type": "string"},
                "actor_id": {"type": "string", "default": "mcp"},
                "rationale": {"type": "string"},
                "activate": {"type": "boolean", "default": False},
                "idempotency_key": {"type": "string"},
            },
            "required": ["name", "content"],
        },
    },
    {
        "name": "ww.swarm.constitution.list",
        "description": "List swarm constitutions in the authenticated tenant.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "ww.swarm.constitution.get",
        "description": "Return one swarm constitution version.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "constitution_id": {"type": "string"},
                "version": {"type": "integer", "minimum": 1},
            },
            "required": ["constitution_id"],
        },
    },
    {
        "name": "ww.swarm.constitution.update",
        "description": "Append a new swarm constitution version.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "constitution_id": {"type": "string"},
                "content": {"type": "string"},
                "name": {"type": "string"},
                "actor_id": {"type": "string", "default": "mcp"},
                "rationale": {"type": "string"},
                "idempotency_key": {"type": "string"},
            },
            "required": ["constitution_id", "content"],
        },
    },
    {
        "name": "ww.swarm.constitution.activate",
        "description": "Activate one swarm constitution version for dispatch injection.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "constitution_id": {"type": "string"},
                "version": {"type": "integer", "minimum": 1},
                "actor_id": {"type": "string", "default": "mcp"},
                "rationale": {"type": "string"},
                "idempotency_key": {"type": "string"},
            },
            "required": ["constitution_id", "version"],
        },
    },
    {
        "name": "ww.swarm.constitution.delete",
        "description": "Delete one swarm constitution from active dispatch.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "constitution_id": {"type": "string"},
                "actor_id": {"type": "string", "default": "mcp"},
                "rationale": {"type": "string"},
            },
            "required": ["constitution_id"],
        },
    },
    {
        "name": "ww.swarm.constitution.deactivate",
        "description": "Deactivate the active swarm constitution.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "constitution_id": {"type": "string"},
                "actor_id": {"type": "string", "default": "mcp"},
                "rationale": {"type": "string"},
            },
            "required": ["constitution_id"],
        },
    },
    {
        "name": "ww.swarm.constitution.active",
        "description": "Return the active swarm constitution and dispatch projection.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "ww.function.sli.snapshot",
        "description": "Capture zero-burn SLI snapshot for a Work Function. Returns resource counters and zero-burn compliance.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "function_id": {"type": "string", "description": "Work Function ID."},
                "window_hours": {
                    "type": "integer",
                    "description": "Observation window in hours (default: 24).",
                    "default": 24,
                },
            },
            "required": ["function_id"],
        },
    },
    {
        "name": "ww.function.sli.reap",
        "description": "Reap idle resource envelopes for a Work Function. Terminates idle envelopes to guarantee zero-burn.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "function_id": {"type": "string", "description": "Work Function ID."},
                "idle_threshold_minutes": {
                    "type": "integer",
                    "description": "Idle threshold in minutes (default: 30).",
                    "default": 30,
                },
                "dry_run": {
                    "type": "boolean",
                    "description": "Preview reap without executing (default: false).",
                    "default": False,
                },
                "actor_id": {
                    "type": "string",
                    "description": "Acting principal ID.",
                    "default": "mcp",
                },
            },
            "required": ["function_id"],
        },
    },
    {
        "name": "ww.pulse.list",
        "description": "List workspace Pulse liveness projections by state, kind, or subject.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "state": {
                    "type": "string",
                    "enum": ["alive", "idle", "executing", "waiting", "blocked", "degraded", "orphaned"],
                },
                "kind": {
                    "type": "string",
                    "enum": ["agent", "swarm", "schedule", "job"],
                },
                "subject_id": {"type": "string"},
            },
        },
    },
    {
        "name": "ww.upgrades.list",
        "description": "List current Weekly Upgrade Digest proposals.",
        "inputSchema": {"type": "object", "properties": {}},
    },
    {
        "name": "ww.upgrades.approve",
        "description": "Approve an upgrade proposal.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "proposal_id": {"type": "string", "description": "Upgrade proposal ID."},
                "actor_id": {"type": "string", "description": "Approving actor ID.", "default": "mcp"},
            },
            "required": ["proposal_id"],
        },
    },
    {
        "name": "ww.upgrades.pilot",
        "description": "Schedule a 1-week, 10% pilot for an upgrade proposal.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "proposal_id": {"type": "string", "description": "Upgrade proposal ID."},
                "actor_id": {"type": "string", "description": "Approving actor ID.", "default": "mcp"},
            },
            "required": ["proposal_id"],
        },
    },
    {
        "name": "ww.upgrades.dismiss",
        "description": "Dismiss an upgrade proposal for 90 days.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "proposal_id": {"type": "string", "description": "Upgrade proposal ID."},
                "actor_id": {"type": "string", "description": "Dismissing actor ID.", "default": "mcp"},
            },
            "required": ["proposal_id"],
        },
    },
    {
        "name": "ww.agent.di",
        "description": "Return an agent's Developmental Intelligence score and self-organization gate.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "agent_id": {"type": "string", "description": "Agent ID to score."},
            },
            "required": ["agent_id"],
        },
    },
    {
        "name": "ww.compound.trajectory",
        "description": "Return per-skill quality_score trajectory for the compounding loop.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "skill_id": {"type": "string", "description": "Skill ID to query."},
                "window_days": {"type": "integer", "description": "Lookback window in days.", "default": 30},
            },
            "required": ["skill_id"],
        },
    },
    {
        "name": "ww.precedent.predict",
        "description": "Predict outcome distribution for a proposed action based on historical decision precedents.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "action_domain": {
                    "type": "string",
                    "description": "Action domain (e.g. email_send, calendar_book, payment_charge).",
                },
                "description": {
                    "type": "string",
                    "description": "Description of the proposed action.",
                },
                "k_precedents": {
                    "type": "integer",
                    "description": "Maximum number of precedents to consider (default: 20).",
                    "default": 20,
                },
            },
            "required": ["action_domain", "description"],
        },
    },
    {
        "name": "ww.decision.search",
        "description": "Search decision traces with structured filters and full-text query over rationale, summary, and alternatives.",
        "inputSchema": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Full-text search over rationale, decision_summary, and alternatives_considered.",
                },
                "domain": {
                    "type": "string",
                    "description": "Filter by domain (operational, customer, strategy).",
                    "enum": ["operational", "customer", "strategy"],
                },
                "tool_name": {
                    "type": "string",
                    "description": "Filter by tool/skill name.",
                },
                "outcome": {
                    "type": "string",
                    "description": "Filter by decision outcome.",
                },
                "skill_id": {
                    "type": "string",
                    "description": "Filter by skill ID.",
                },
                "decision_type": {
                    "type": "string",
                    "description": "Filter by decision type.",
                },
                "min_confidence": {
                    "type": "number",
                    "description": "Minimum quality_score threshold (0.0 to 1.0).",
                    "minimum": 0.0,
                    "maximum": 1.0,
                },
                "time_range_start": {
                    "type": "string",
                    "description": "ISO 8601 start of time range.",
                },
                "time_range_end": {
                    "type": "string",
                    "description": "ISO 8601 end of time range.",
                },
                "sop_deviation_present": {
                    "type": "boolean",
                    "description": "Filter for decisions with SOP deviations.",
                },
                "precedent_id": {
                    "type": "string",
                    "description": "Filter by precedent ID in precedent_ids_used.",
                },
                "limit": {
                    "type": "integer",
                    "description": "Maximum results (default: 50).",
                    "default": 50,
                },
                "cursor": {
                    "type": "string",
                    "description": "Pagination cursor from previous response.",
                },
            },
        },
    },
]
