"""Tool dispatch map and dispatch_mcp_tool.

Extracted from the original monolithic public_mcp.py (#3928).
Execution gate logic moved to _execution_gates.py.
"""

from __future__ import annotations

import logging
from typing import Any

from apps.backend.api.public_mcp._constants import (
    _PLAN_STEER_MCP_TOOLS,
    _TOOL_SEARCH_NAME,
)
from apps.backend.api.public_mcp._execution_gates import (
    _evaluate_public_mcp_execution_gate,  # noqa: F401 — used via _pkg()
    _guarded_mcp_operation_requires_gate,
    _mcp_operation_type,
    _strip_side_effect_proof,
    _validate_mcp_plan_approve_actor,
    _validate_public_mcp_side_effect_proof,  # noqa: F401 — used via _pkg()
)
from apps.backend.api.public_mcp._catalog import (
    _PUBLIC_MCP_CATALOG_TOOLS,
    canonical_public_mcp_tool_name,
    search_public_mcp_tools,
    _legacy_dispatch_name,
)

logger = logging.getLogger(__name__)


from apps.backend.api.public_mcp._skill_curator_dispatch import (
    _dispatch_skill_curator_tool,  # noqa: F401 — used via _pkg()
    _skill_curator_decision_actor_from_proof,
)
from apps.backend.api.public_mcp._service_dispatch import (  # noqa: F401
    get_agent_protocol_service,
    _dispatch_agent_protocol_tool,
    _LEARNING_DLQ_MCP_TOOLS,
    _dispatch_learning_dlq_tool,
    _dispatch_wallet_tool,
    _dispatch_zara_coordination_tool,
    _dispatch_support_file_bug,
    _dispatch_support_consent,
    _dispatch_profile_get,
    _dispatch_profile_set,
    _dispatch_profile_list,
    _dispatch_identity_purposes,
    _dispatch_identity_purpose_status,
    _dispatch_decision_search,
    _dispatch_agent_card_show,
    _dispatch_agent_card_verify,
    _dispatch_capability_state_show,
    _dispatch_capability_state_list,
    _dispatch_voice_persona_tool,
    _dispatch_workspace_persona_tool,
)

# Register Learning DLQ tools in the public catalog.
for _tool in _LEARNING_DLQ_MCP_TOOLS:
    _PUBLIC_MCP_CATALOG_TOOLS.append(_tool)


def _pkg():
    """Return the public_mcp package module for monkeypatch-compatible lookups."""
    import apps.backend.api.public_mcp as _m
    return _m


def _dispatch_inbox_conversations(tenant_id: str, parameters: dict[str, Any]) -> dict[str, Any]:
    from apps.backend.api.inbox import list_conversations

    result = list_conversations(
        tenant_id=tenant_id,
        channel=str(parameters.get("channel") or "").strip() or None,
        limit=int(parameters.get("limit") or 50),
        offset=int(parameters.get("offset") or 0),
    )
    return {"tenant_id": tenant_id, **result}


def _get_swarm_tool_discovery_service() -> Any:
    from apps.backend.services.swarm.tool_discovery import SwarmToolDiscoveryService
    from apps.backend.services.unified_capability_gate import get_unified_capability_gate

    return SwarmToolDiscoveryService(permission_gate=get_unified_capability_gate())


def _plain_swarm_tool_value(value: Any) -> Any:
    if hasattr(value, "to_dict"):
        return value.to_dict()
    if isinstance(value, list):
        return [_plain_swarm_tool_value(item) for item in value]
    if isinstance(value, dict):
        return value
    return value


def _dispatch_swarm_tool_search(tenant_id: str, parameters: dict[str, Any]) -> dict[str, Any]:
    service = _pkg()._get_swarm_tool_discovery_service()
    tools = service.search_tools(
        tenant_id=tenant_id,
        agent_id=str(parameters.get("agent_id") or "").strip(),
        query=str(parameters.get("query") or "").strip(),
        modality=str(parameters.get("modality") or "").strip() or None,
        limit=int(parameters.get("limit") or 10),
    )
    rows = _plain_swarm_tool_value(tools)
    return {"tenant_id": tenant_id, "tools": rows, "count": len(rows)}


def _dispatch_swarm_tool_activation(tenant_id: str, parameters: dict[str, Any]) -> dict[str, Any]:
    service = _pkg()._get_swarm_tool_discovery_service()
    idempotency_key = str(parameters.get("idempotency_key") or "").strip()
    if not idempotency_key:
        return {
            "tool_name": str(parameters.get("tool_name") or "").strip(),
            "activated": False,
            "policy_verdict": "DENY",
            "reason": "idempotency_key is required",
            "decision_trace_id": None,
            "permission_lease": None,
        }
    result = service.activate_tool(
        tenant_id=tenant_id,
        agent_id=str(parameters.get("agent_id") or "").strip(),
        tool_name=str(parameters.get("tool_name") or "").strip(),
        search_query=str(parameters.get("search_query") or "").strip() or None,
        ttl_seconds=int(parameters.get("ttl_seconds") or 300),
        actor_chain=[str(item) for item in parameters.get("actor_chain") or []] or None,
        idempotency_key=idempotency_key,
    )
    return _plain_swarm_tool_value(result)


def _dispatch_skill_import(tenant_id: str, parameters: dict[str, Any]) -> dict[str, Any]:
    from apps.backend.models.skill_source import SkillSourceImportRequest
    from apps.backend.services.skills.skill_source_importer import SkillSourceImportError, run_skill_source_import

    request = SkillSourceImportRequest(
        workspace_id=str(parameters.get("workspace_id") or tenant_id),
        origin=parameters.get("origin"),
        origin_kind=parameters.get("origin_kind"),
        dry_run=parameters.get("dry_run", True),
        customize=parameters.get("customize", False),
        reject_on_warning=parameters.get("reject_on_warning", False),
        customization_overlay=parameters.get("customization_overlay"),
    )
    if request.workspace_id != tenant_id:
        return {
            "accepted": False,
            "dry_run": request.dry_run,
            "skill_source": None,
            "decision_trace_id": None,
            "rejection_reason": "workspace_id must match authenticated tenant_id",
        }
    try:
        return run_skill_source_import(request).model_dump(mode="json")
    except SkillSourceImportError as exc:
        return {
            "accepted": False,
            "dry_run": request.dry_run,
            "skill_source": None,
            "decision_trace_id": None,
            "rejection_reason": str(exc),
        }


# =====================================================================# MCP Tool Dispatch
# =====================================================================
# Map tool name -> handler function name in _PublicApiService
_TOOL_DISPATCH: dict[str, str] = {
    "workweaver.task.create": "create_task",
    "workweaver.task.status": "get_task_status",
    "workweaver.agent.list": "list_agents",
    "workweaver.agent.run": "run_agent",
    "ww.session.intake_queue.status": "session_intake_queue_status",
    "workweaver.schedule.create": "create_schedule",
    "workweaver.schedule.trigger": "trigger_schedule",
    "workweaver.evidence.query": "query_evidence",
    "ww.evidence.trace": "evidence_trace",
    "workweaver.approval.list": "list_approvals",
    "workweaver.approval.approve": "approve_action",
    "workweaver.approval.reject": "reject_action",
    "ww.inbox.list": "list_approvals",
    "ww.inbox.approve": "approve_action",
    "ww.inbox.reject": "reject_action",
    # Connector tools
    "workweaver.connector.install": "connector_install",
    "ww.connector.import.openapi": "connector_import_openapi",
    "workweaver.connector.execute": "connector_execute",
    "workweaver.connector.list": "connector_list",
    "ww.connector.health": "connector_health",
    "ww.connector.status": "connector_status",
    "ww.connector.auth": "connector_auth",
    "ww.research.search": "research_search",
    "ww.browser.run": "browser_run",
    "ww.browser.sandbox_evaluate": "browser_sandbox_evaluate",
    "ww.browser.sandbox_policy": "browser_sandbox_policy",
    # Issue #3227: admin permissions surfaces.
    "ww.admin.permissions.list": "admin_permissions_list",
    "ww.admin.permissions.grant": "admin_permissions_grant",
    "ww.admin.permissions.revoke": "admin_permissions_revoke",
    "ww.operational_context.show": "operational_context_show",
    "ww.operational_context.workspace": "operational_context_workspace",
    "ww.operational_context.share": "operational_context_share",
    # CLI capability wrappers
    "workweaver.mission.list": "mission_list",
    "workweaver.plan.list": "plan_list",
    "workweaver.plan.show": "plan_show",
    "workweaver.plan.steer": "plan_steer",
    "workweaver.mission.steer": "mission_steer",
    "ww.plan.list": "plan_list",
    "ww.plan.show": "plan_show",
    "ww.plan.steer": "plan_steer",
    "ww.mission.steer": "mission_steer",
    "ww.mission.outcome_review": "mission_outcome_review",
    "ww.mission.admission": "mission_admission_show",
    "ww.mission.breaker": "mission_breaker_show_or_reset",
    "ww.mission.reversal.request": "mission_reversal_request",
    "ww.strategy.trace": "strategy_trace",
    "workweaver.workitem.create": "workitem_create",
    "workweaver.memory.store": "memory_store",
    "workweaver.config.get": "config_get",
    "workweaver.entity.list": "entity_list",
    "ww.ontology.query": "ontology_query",
    "ww.entity_schema.create": "entity_schema_create",
    "ww.entity_schema.list": "entity_schema_list",
    "ww.entity_schema.get": "entity_schema_get",
    "ww.entity_schema.activate": "entity_schema_activate",
    "ww.entity.record.create": "entity_record_create",
    "ww.entity.record.get": "entity_record_get",
    "ww.entity.record.list": "entity_record_list",
    "ww.entity.record.update": "entity_record_update",
    "ww.entity.record.schema": "entity_record_schema",
    "ww.identity.readiness": "agent_identity_readiness",
    "ww.agent.identity": "agent_identity_status",
    "ww.identity.purposes": "agent_identity_purposes",
    "ww.identity.purpose_status": "agent_identity_purpose_status",
    "ww.entity.conflicts": "entity_conflicts",
    "ww.entity.conflict.resolve": "entity_conflict_resolve",
    "ww.swarm.status": "swarm_status",
    "ww.swarm.spawn": "swarm_spawn",
    "ww.swarm.cancel": "swarm_cancel",
    "ww.swarm.record_step_result": "swarm_record_step_result",
    "ww.swarm.success_criteria_eval": "swarm_success_criteria_eval",
    "ww.swarm.constitution.create": "swarm_constitution_create",
    "ww.swarm.constitution.list": "swarm_constitution_list",
    "ww.swarm.constitution.get": "swarm_constitution_get",
    "ww.swarm.constitution.update": "swarm_constitution_update",
    "ww.swarm.constitution.activate": "swarm_constitution_activate",
    "ww.swarm.constitution.deactivate": "swarm_constitution_deactivate",
    "ww.swarm.constitution.delete": "swarm_constitution_delete",
    "ww.swarm.constitution.active": "swarm_constitution_active",
    "ww.workflow.template.list": "workflow_template_list",
    "ww.workflow.template.show": "workflow_template_show",
    "ww.workflow.saga.run": "workflow_saga_run",
    "ww.workflow.saga.status": "workflow_saga_status",
    "ww.workflow.saga.compensate": "workflow_saga_compensate",
    "ww.pulse.list": "pulse_list",
    "ww.upgrades.list": "upgrades_list",
    "ww.upgrades.approve": "upgrades_approve",
    "ww.upgrades.pilot": "upgrades_pilot",
    "ww.upgrades.dismiss": "upgrades_dismiss",
    "ww.agent.di": "agent_di",
    "ww.compound.trajectory": "compound_trajectory",
    "ww.precedent.predict": "precedent_predict",
    "ww.decision.search": "decision_search",
    "workweaver.org.audit_log": "org_audit_log",
    # Support (#2348)
    "ww.support.file_bug": "support_file_bug",
    # Support consent (#2342)
    "ww.support.consent": "support_consent",
    # Wallet (#2366) — read-only tools dispatched via _TOOL_DISPATCH;
    # write tools (sign, broadcast) dispatched directly in dispatch_mcp_tool
    "ww.wallet.readiness": "wallet_readiness",
    "ww.wallet.policy": "wallet_policy",
    "ww.wallet.address": "wallet_address",
    "ww.wallet.balance": "wallet_balance",
    "ww.wallet.tx_list": "wallet_tx_list",
    "ww.wallet.tx_get": "wallet_tx_get",
    "ww.wallet.custody_status": "wallet_custody_status",
    # Wallet write tools — kept in _TOOL_DISPATCH for legacy name resolution
    "ww.wallet.sign": "wallet_sign",
    "ww.wallet.broadcast": "wallet_broadcast",
    # Multi-wallet parity (#3625 / slice 8e). The startswith("ww.wallet.")
    # branch in dispatch_mcp_tool routes the actual handlers via
    # apps.backend.mcp.wallet_tools; entries here exist so legacy callers can
    # resolve canonical names through canonical_public_mcp_tool_name.
    "ww.wallet.policies.list": "wallet_policies_list",
    "ww.wallet.policy.get": "wallet_policy_get",
    "ww.wallet.policy.set": "wallet_policy_set",
    "ww.wallet.transactions.list": "wallet_transactions_list",
    "ww.wallet.transactions.sign": "wallet_transactions_sign",
    # Cross-tenant Zara coordination (#3625 / family J). Routed via the
    # startswith("ww.zara.coordinate.") branch in dispatch_mcp_tool.
    "ww.zara.coordinate.send": "zara_coordinate_send",
    "ww.zara.coordinate.show": "zara_coordinate_show",
    "ww.zara.coordinate.broadcast": "zara_coordinate_broadcast",
    # Profile (#2394)
    "ww.profile.get": "profile_get",
    "ww.profile.set": "profile_set",
    "ww.profile.list": "profile_list",
    # Voice persona (#2798)
    "ww.voice.persona.create": "voice_persona_create",
    "ww.voice.persona.clone.register": "voice_persona_clone_register",
    "ww.voice.persona.list": "voice_persona_list",
    "ww.voice.catalog.list": "voice_catalog_list",
    "ww.voice.persona.get": "voice_persona_get",
    "ww.voice.persona.update": "voice_persona_update",
    "ww.voice.persona.delete": "voice_persona_delete",
    "ww.voice.persona.templates": "voice_persona_templates",
    # TimeBlock CRUD primitive (#2785 PR C)
    "ww.timeblock.list": "timeblock_list",
    "ww.timeblock.create": "timeblock_create",
    "ww.timeblock.show": "timeblock_show",
    "ww.timeblock.update": "timeblock_update",
    "ww.timeblock.move": "timeblock_move",
    "ww.timeblock.delete": "timeblock_delete",
    # Inference audit grid (#3215) — read-only per-Purpose x per-tenant projection
    "ww.admin.inference.audit_grid": "admin_inference_audit_grid",
    # Jurisdiction policy (#3224) — MCP mirrors for founder REST endpoints
    "ww.admin.jurisdiction.policy_show": "admin_jurisdiction_policy_show",
    "ww.admin.jurisdiction.policy_set": "admin_jurisdiction_policy_set",
    # Embedding policy (#3209) — per-Purpose × per-tenant grid
    "ww.admin.embedding.policy_show": "admin_embedding_policy_show",
    "ww.admin.embedding.policy_set": "admin_embedding_policy_set",
    # Agent Protocol tools are dispatched separately (not via _PublicApiService)
    "workweaver.org.query": "_agent_protocol:org_query",
    "workweaver.agent.query": "_agent_protocol:agent_query",
    # Function SLI + reap (#3245)
    "ww.function.sli.snapshot": "function_sli_snapshot",
    "ww.function.sli.reap": "function_sli_reap",
    # Chat router (Slices 9 + 11)
    "ww.chat.route": "chat_route",
    "ww.chat.rollback": "chat_rollback",
}




async def dispatch_mcp_tool(
    *,
    tool_name: str,
    tenant_id: str,
    parameters: dict[str, Any],
    verified_actor_id: str | None = None,
    verified_actor_role: Any | None = None,
) -> dict[str, Any]:
    """Dispatch an MCP tool invocation to the shared public API service.

    Args:
        tool_name: Fully qualified MCP tool name (e.g. 'ww.workitem.create').
        tenant_id: Authenticated tenant ID.
        parameters: Tool parameters from MCP client.

    Returns:
        Tool execution result as dict.

    Raises:
        ValueError: If tool_name is not recognized.
    """
    if isinstance(verified_actor_id, str):
        verified_actor_id = verified_actor_id.strip() or None
    if isinstance(verified_actor_role, str):
        verified_actor_role = verified_actor_role.strip() or None

    canonical_tool_name = canonical_public_mcp_tool_name(tool_name)
    if canonical_tool_name == _TOOL_SEARCH_NAME:
        return {
            "matches": search_public_mcp_tools(
                str(parameters.get("intent") or parameters.get("query") or ""),
                limit=int(parameters.get("limit") or 5),
            )
        }
    if canonical_tool_name == "ww.policy.authority":
        from apps.backend.services.policy_authority import policy_authority_map_payload

        return {"tenant_id": tenant_id, **policy_authority_map_payload()}
    if canonical_tool_name == "ww.governance.anchor.list":
        # Issue #3547: read-only listing of L4 anchor inventory.
        from apps.backend.services.governance_anchor_paths import list_anchor_paths

        inventory = list_anchor_paths()
        return {
            "tenant_id": tenant_id,
            "paths": list(inventory["paths"]),
            "globs": list(inventory["globs"]),
        }
    if canonical_tool_name == "ww.policy.allowlist.list":
        from apps.backend.api.policy_allowlist import policy_allowlist_payload

        return policy_allowlist_payload(
            kind=str(parameters.get("kind") or "TOOL"),
            tenant_id=tenant_id,
        )
    if canonical_tool_name == "ww.kernel.healing.recent":
        from apps.backend.api.kernel_healing import collect_recent_healing_actions
        from apps.backend.services.mission_run.state import get_mission_run_state_service

        window_hours = parameters.get("window_hours", 24)
        try:
            window_hours_int = int(window_hours)
        except (TypeError, ValueError):
            window_hours_int = 24
        response = collect_recent_healing_actions(
            tenant_id=tenant_id,
            window_hours=window_hours_int,
            service=get_mission_run_state_service(),
        )
        return response.model_dump(mode="json")
    if canonical_tool_name == "ww.member.bind_external":
        from apps.backend.services.identity_binding_service import IdentityBindingService

        service = IdentityBindingService()
        workspace_id = str(parameters.get("workspace_id", ""))
        member_id = str(parameters.get("member_id", ""))
        provider = str(parameters.get("provider", ""))
        external_user_id = str(parameters.get("external_user_id", ""))
        external_email = parameters.get("external_email")
        external_name = parameters.get("external_name")
        binding = service.bind_external_identity(
            tenant_id=tenant_id,
            workspace_id=workspace_id,
            member_id=member_id,
            provider=provider,
            external_user_id=external_user_id,
            external_email=external_email,
            external_name=external_name,
            created_by=f"mcp:{tenant_id}",
        )
        return binding.to_record()
    if canonical_tool_name == "ww.member.list_external_identities":
        from apps.backend.services.identity_binding_service import IdentityBindingService

        service = IdentityBindingService()
        member_id = str(parameters.get("member_id", ""))
        bindings = service.list_bindings_for_member(
            tenant_id=tenant_id,
            member_id=member_id,
        )
        return {
            "bindings": [b.to_record() for b in bindings],
            "total": len(bindings),
        }
    if canonical_tool_name in (
        "ww.kernel.skill.list",
        "ww.kernel.skill.show",
        "ww.kernel.skill.run",
    ):
        from apps.backend.api.kernel_skills import (
            KERNEL_SECTION_14_SKILL_IDS,
            get_kernel_skill_executor,
        )

        executor = get_kernel_skill_executor()
        if canonical_tool_name == "ww.kernel.skill.list":
            return {
                "skills": [
                    {
                        "skill_id": skill.skill_id,
                        "name": skill.name,
                        "category": skill.category.value,
                        "description": skill.description,
                        "owner": "system",
                        "immutable": skill.immutable,
                        "backed_by": list(skill.backed_by),
                    }
                    for skill in executor.registry.list_section_14()
                ],
            }
        skill_id = str(parameters.get("skill_id") or "").strip()
        if skill_id not in KERNEL_SECTION_14_SKILL_IDS:
            return {"error": f"Unknown kernel skill: {skill_id}"}
        if canonical_tool_name == "ww.kernel.skill.show":
            skill = executor.registry.get(skill_id)
            if skill is None:
                return {"error": f"Unknown kernel skill: {skill_id}"}
            return {
                "skill_id": skill.skill_id,
                "name": skill.name,
                "category": skill.category.value,
                "description": skill.description,
                "owner": "system",
                "immutable": skill.immutable,
                "backed_by": list(skill.backed_by),
            }
        # ww.kernel.skill.run
        result = executor.run(tenant_id=tenant_id, skill_id=skill_id)
        return {
            "tenant_id": result.tenant_id,
            "skill_id": result.skill_id,
            "operation": result.operation,
            "side_effect_class": result.side_effect_class,
            "idempotency_key": result.idempotency_key,
            "trace_id": result.trace_id,
            "summary": result.summary,
        }
    if canonical_tool_name == "ww.kernel.connector_locality":
        from apps.backend.services.connectors.locality_matrix import (
            DEFAULT_LOCALITY_MATRIX,
        )

        connector_name = str(parameters.get("connector_name") or "").strip()
        operation = str(parameters.get("operation") or "").strip()
        policy_modes = list(parameters.get("policy_modes") or [])
        if connector_name and operation:
            explanation = DEFAULT_LOCALITY_MATRIX.explain(
                connector_name,
                operation,
                policy_modes=policy_modes,
                tenant_id=tenant_id,
            )
            return {
                "connector_name": explanation.connector_name,
                "operation": explanation.operation,
                "decision": explanation.decision.value,
                "side_effect_class": explanation.side_effect_class.value,
                "reason": explanation.reason,
                "allowed_localities": [loc.value for loc in explanation.allowed_localities],
                "fallback": explanation.fallback,
                "policy_modes": list(explanation.policy_modes),
            }
        if connector_name and not operation:
            return {"error": "operation is required when connector_name is provided"}
        return DEFAULT_LOCALITY_MATRIX.tenant_locality_summary()
    if canonical_tool_name == "ww.kernel.zero_burn":
        from apps.backend.services.capacity.zero_burn_sli import (
            get_zero_burn_sli_service,
        )
        from apps.backend.services.zara.zara_awareness_service import (
            list_function_capacity_envelopes,
        )

        envelopes = list_function_capacity_envelopes(tenant_id)
        function_ids = [env.function_id for env in envelopes]
        sli = get_zero_burn_sli_service()
        return sli.tenant_zero_burn_summary(
            workspace_id=tenant_id, function_ids=function_ids
        )
    if canonical_tool_name == "ww.kernel.probe.history":
        from apps.backend.jobs.capability_readiness_probe import (
            get_probe_history_for_tenant,
        )
        from apps.backend.providers.portable_store import create_portable_store
        from apps.backend.workmemory.agent_awareness_store import AgentAwarenessStore

        capability_id = str(parameters.get("capability_id") or "").strip()
        if not capability_id:
            return {"error": "capability_id is required"}
        store = AgentAwarenessStore(store=create_portable_store())
        return get_probe_history_for_tenant(
            tenant_id=tenant_id,
            capability_id=capability_id,
            store=store,
        )
    if canonical_tool_name == "ww.evidence.trace.awareness":
        from apps.backend.providers.portable_store import create_portable_store
        from apps.backend.services.context.decision_event_capture import (
            DecisionEventCaptureService,
        )
        from apps.backend.workmemory.services.awareness_snapshot_store import (
            AwarenessSnapshotStore,
        )

        trace_id_param = str(parameters.get("trace_id") or "").strip()
        if not trace_id_param:
            return {"error": "trace_id is required"}
        try:
            decision = DecisionEventCaptureService().get_decision(
                tenant_id=tenant_id, trace_id=trace_id_param
            )
        except Exception:
            decision = None
        if decision is None:
            return {"error": f"trace {trace_id_param} not found"}
        snapshot_id = getattr(decision, "awareness_snapshot_id", None)
        if not snapshot_id:
            return {
                "error": (
                    f"trace {trace_id_param} did not stamp awareness_snapshot_id "
                    "(legacy or non-zara.plan.* operation)"
                ),
            }
        store = AwarenessSnapshotStore(create_portable_store())
        snapshot = store.get(tenant_id=tenant_id, snapshot_id=snapshot_id)
        if snapshot is None:
            return {"error": f"snapshot {snapshot_id} not found"}
        return snapshot.to_storage_record()
    if canonical_tool_name == "ww.healing.digest":
        from apps.backend.services.healing_digest import (
            get_healing_digest_service,
        )

        month = str(parameters.get("month") or "").strip() or None
        digest = get_healing_digest_service().digest(
            tenant_id=tenant_id, month=month
        )
        return digest.model_dump(mode="json")
    if canonical_tool_name == "ww.tenant.conflicts.list":
        from apps.backend.services.conflict_detector import (
            get_conflict_detector_service,
        )

        bundle = get_conflict_detector_service().detect(tenant_id=tenant_id)
        return bundle.model_dump(mode="json")
    if canonical_tool_name == "ww.tenant.conflicts.show":
        from apps.backend.services.conflict_detector import (
            get_conflict_detector_service,
        )

        conflict_id = str(parameters.get("conflict_id") or "").strip()
        if not conflict_id:
            return {"error": "conflict_id is required"}
        bundle = get_conflict_detector_service().detect(tenant_id=tenant_id)
        for conflict in bundle.conflicts:
            if conflict.conflict_id == conflict_id:
                return conflict.model_dump(mode="json")
        return {"error": f"conflict {conflict_id} not found"}
    if canonical_tool_name == "ww.tenant.conflicts.resolve":
        from apps.backend.services.conflict_detector import (
            get_conflict_detector_service,
        )

        conflict_id = str(parameters.get("conflict_id") or "").strip()
        if not conflict_id:
            return {"error": "conflict_id is required"}
        action = str(parameters.get("action") or "accept_suggestion")
        if action not in {"accept_suggestion", "reject", "escalate"}:
            return {"error": f"unsupported action: {action}"}
        detector = get_conflict_detector_service()
        bundle = detector.detect(tenant_id=tenant_id)
        for conflict in bundle.conflicts:
            if conflict.conflict_id == conflict_id:
                result = detector.resolve(conflict=conflict, action=action)  # type: ignore[arg-type]
                return result.model_dump(mode="json")
        return {"error": f"conflict {conflict_id} not found"}
    if canonical_tool_name == "ww.payment.preflight":
        from apps.backend.services.payment_policy_store import load_tenant_payment_policy
        from apps.backend.services.policy_authority import build_payment_policy_preflight

        envelope = build_payment_policy_preflight(
            tenant_id=tenant_id,
            actor={"actor_id": str(parameters.get("actor_id") or "zara").strip()},
            inputs={
                "action": parameters.get("action") or "payment.manage",
                "provider": parameters.get("provider") or "stripe",
                "amount": parameters.get("amount"),
                "currency": parameters.get("currency"),
                "mandate_id": parameters.get("mandate_id"),
                "mandate_valid": parameters.get("mandate_valid"),
                "mandate_error": parameters.get("mandate_error"),
                "tenant_payment_policy": load_tenant_payment_policy(tenant_id),
            },
        )
        return envelope.to_public_dict()
    if canonical_tool_name == "ww.inbox.conversations":
        return _dispatch_inbox_conversations(tenant_id, parameters)
    # Wallet (#2366) + multi-wallet parity (#3625 / slice 8e)
    if canonical_tool_name and canonical_tool_name.startswith("ww.wallet."):
        return await _dispatch_wallet_tool(canonical_tool_name, tenant_id, parameters)
    # Cross-tenant Zara coordination (#3625 / family J)
    if canonical_tool_name and canonical_tool_name.startswith("ww.zara.coordinate."):
        return await _dispatch_zara_coordination_tool(
            canonical_tool_name, tenant_id, parameters
        )
    # Support (#2348)
    if canonical_tool_name == "ww.support.file_bug":
        return await _dispatch_support_file_bug(tenant_id, parameters)
    # Support consent (#2342)
    if canonical_tool_name == "ww.support.consent":
        return await _dispatch_support_consent(tenant_id, parameters)
    # Profile (#2394)
    if canonical_tool_name == "ww.profile.get":
        return await _dispatch_profile_get(tenant_id)
    if canonical_tool_name == "ww.profile.set":
        return await _dispatch_profile_set(tenant_id, parameters)
    if canonical_tool_name == "ww.profile.list":
        return await _dispatch_profile_list()
    # Identity purposes (#2231)
    if canonical_tool_name == "ww.identity.purposes":
        return await _dispatch_identity_purposes(tenant_id, parameters)
    if canonical_tool_name == "ww.identity.purpose_status":
        return await _dispatch_identity_purpose_status(tenant_id, parameters)
    # Decision search (#2489)
    if canonical_tool_name == "ww.decision.search":
        return _dispatch_decision_search(tenant_id, parameters)
    # Agent Card surface parity (#3947)
    if canonical_tool_name in ("agent_card_show", "ww.agent_card.show"):
        return await _dispatch_agent_card_show(tenant_id)
    if canonical_tool_name in ("agent_card_verify", "ww.agent_card.verify"):
        return await _dispatch_agent_card_verify(tenant_id, parameters)
    # Voice persona (#2798)
    if canonical_tool_name and (
        canonical_tool_name.startswith("ww.voice.persona.")
        or canonical_tool_name == "ww.voice.catalog.list"
    ):
        return _dispatch_voice_persona_tool(canonical_tool_name, tenant_id, parameters)
    # Workspace persona overlay (#3542) — safe SOUL.md analog. Dispatched
    # directly because it has its own service + validator; the kernel envelope
    # contract test (tests/contracts/test_kernel_envelope_first.py) asserts
    # that overlays never reach into governance/policy/floor surfaces.
    if canonical_tool_name and canonical_tool_name.startswith("ww.workspace.persona."):
        return _dispatch_workspace_persona_tool(
            canonical_tool_name, tenant_id, parameters
        )
    # Calendar writer (#2716)
    if canonical_tool_name and canonical_tool_name.startswith("ww.calendar."):
        return await dispatch_calendar_tool(
            tool_name=canonical_tool_name,
            tenant_id=tenant_id,
            parameters=parameters,
        )
    # Places venue discovery (#3616)
    if canonical_tool_name and canonical_tool_name.startswith("ww.places."):
        return await dispatch_places_tool(
            tool_name=canonical_tool_name,
            tenant_id=tenant_id,
            parameters=parameters,
        )
    if canonical_tool_name == "ww.swarm.search_tools":
        return _dispatch_swarm_tool_search(tenant_id, parameters)
    if canonical_tool_name == "ww.swarm.activate_tool":
        return _dispatch_swarm_tool_activation(tenant_id, parameters)

    # Issue #3508: manifest-driven inference family. Dispatched before the
    # legacy ``_TOOL_DISPATCH`` map so the manifest is the single source of
    # truth for ``ww.inference.*`` and most ``ww.admin.inference.*`` tools.
    # The hand-rolled ``ww.admin.inference.audit_grid`` and its dispatch
    # mapping below remain — ``inference_mcp_tools.dispatch_inference_tool``
    # delegates to the same handler via its override map.
    if canonical_tool_name and (
        canonical_tool_name.startswith("ww.inference.")
        or canonical_tool_name.startswith("ww.admin.inference.")
    ):
        from apps.backend.api.inference_mcp_tools import (
            dispatch_inference_tool,
            inference_mcp_tool_names,
        )

        if canonical_tool_name in set(inference_mcp_tool_names()):
            return await dispatch_inference_tool(
                tool_name=canonical_tool_name,
                tenant_id=tenant_id,
                parameters=parameters,
            )

    dispatch_tool_name = (
        canonical_tool_name
        if tool_name == canonical_tool_name == "ww.evidence.trace"
        else _legacy_dispatch_name(tool_name)
    )

    # Learning DLQ tools -- dispatched directly (#2324)
    if canonical_tool_name and canonical_tool_name.startswith("ww.learning.dlq."):
        return await _dispatch_learning_dlq_tool(canonical_tool_name, tenant_id, parameters)

    if canonical_tool_name and canonical_tool_name.startswith("ww.skill.curator."):
        operation_type = _mcp_operation_type(canonical_tool_name, parameters)
        side_effect_proof: dict[str, Any] | None = None
        dispatch_parameters = parameters
        if _guarded_mcp_operation_requires_gate(canonical_tool_name, operation_type):
            policy_decision, block_response = _pkg()._evaluate_public_mcp_execution_gate(
                tool_name=canonical_tool_name,
                tenant_id=tenant_id,
                parameters=parameters,
            )
            if block_response is not None:
                return block_response
            side_effect_proof, proof_block_response = _pkg()._validate_public_mcp_side_effect_proof(
                tool_name=canonical_tool_name,
                tenant_id=tenant_id,
                parameters=parameters,
                policy_decision=policy_decision,
            )
            if proof_block_response is not None:
                return proof_block_response
            dispatch_parameters = _strip_side_effect_proof(parameters)
            if canonical_tool_name == "ww.skill.curator.respond":
                actor_id, actor_block_response = _skill_curator_decision_actor_from_proof(side_effect_proof)
                if actor_block_response is not None:
                    return actor_block_response
                dispatch_parameters = {**dispatch_parameters, "actor_id": actor_id}
        result = _pkg()._dispatch_skill_curator_tool(canonical_tool_name, tenant_id, dispatch_parameters)
        if (
            side_effect_proof is not None
            and isinstance(result, dict)
            and result.get("status") != "error"
        ):
            result["side_effect_proof"] = side_effect_proof
        return result

    if canonical_tool_name == "ww.skill.import":
        policy_decision, block_response = _pkg()._evaluate_public_mcp_execution_gate(
            tool_name=canonical_tool_name,
            tenant_id=tenant_id,
            parameters=parameters,
        )
        if block_response is not None:
            return block_response
        side_effect_proof, proof_block_response = _pkg()._validate_public_mcp_side_effect_proof(
            tool_name=canonical_tool_name,
            tenant_id=tenant_id,
            parameters=parameters,
            policy_decision=policy_decision,
        )
        if proof_block_response is not None:
            return proof_block_response
        result = _dispatch_skill_import(tenant_id, _strip_side_effect_proof(parameters))
        if side_effect_proof is not None:
            result["side_effect_proof"] = side_effect_proof
        return result
    # Capability rollout state (#3543)
    if canonical_tool_name == "ww.capability.state.show":
        return _dispatch_capability_state_show(tenant_id, parameters)
    if canonical_tool_name == "ww.capability.state.list":
        return _dispatch_capability_state_list(parameters)
    handler_name = _TOOL_DISPATCH.get(dispatch_tool_name)
    if not handler_name:
        raise ValueError(f"Unknown MCP tool: {tool_name}")

    # Agent protocol tools are dispatched via a dedicated path
    if handler_name.startswith("_agent_protocol:"):
        return await _dispatch_agent_protocol_tool(dispatch_tool_name, tenant_id, parameters)

    if canonical_tool_name in _PLAN_STEER_MCP_TOOLS:
        _validate_mcp_plan_approve_actor(parameters)

    policy_decision, block_response = _pkg()._evaluate_public_mcp_execution_gate(
        tool_name=canonical_tool_name or tool_name,
        tenant_id=tenant_id,
        parameters=parameters,
    )
    if block_response is not None:
        return block_response

    side_effect_proof, proof_block_response = _pkg()._validate_public_mcp_side_effect_proof(
        tool_name=canonical_tool_name or tool_name,
        tenant_id=tenant_id,
        parameters=parameters,
        policy_decision=policy_decision,
    )
    if proof_block_response is not None:
        return proof_block_response

    from apps.backend.api.public_api_service import PublicResearchError, get_public_api_service

    dispatch_parameters = _strip_side_effect_proof(parameters)
    if verified_actor_id:
        dispatch_parameters["verified_actor_id"] = verified_actor_id
    if verified_actor_role is not None:
        dispatch_parameters["verified_actor_role"] = verified_actor_role
    service = get_public_api_service()
    handler = getattr(service, handler_name)
    try:
        result = await handler(tenant_id=tenant_id, **dispatch_parameters)
    except PublicResearchError as exc:
        return {
            "status": "error",
            "tool_name": canonical_tool_name or tool_name,
            "error": exc.to_dict(),
        }
    except TypeError as exc:
        if handler_name != "research_search":
            raise
        return {
            "status": "error",
            "tool_name": canonical_tool_name or tool_name,
            "error": {
                "code": "invalid_request",
                "message": str(exc),
                "evidence_id": None,
                "retryable": False,
            },
        }
    if policy_decision is not None and isinstance(result, dict):
        result.setdefault("policy_decision", policy_decision)
    if side_effect_proof is not None and isinstance(result, dict):
        result["side_effect_proof"] = side_effect_proof
    return result
