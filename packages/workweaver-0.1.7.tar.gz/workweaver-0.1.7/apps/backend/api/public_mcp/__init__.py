"""Public MCP tool definitions and dispatch for workspace-facing MCP server (M5.1).

Defines the MCP tool schemas exposed to workspaces and dispatches tool
invocations to the shared public API service layer.

Reference: docs/CAPABILITIES.md M5.1

Refactored from a single 5,913-line file into focused submodules (#3928):
- _constants -- Module-level constant sets (guarded tools, safe ops, etc.)
- _schemas_legacy -- Legacy workweaver.* tool schema definitions
- _schemas_native -- Native ww.* tool schema definitions
- _catalog -- Registry assembly, search, index, and public query functions
- _dispatch -- Tool dispatch map, execution gates, and dispatch_mcp_tool
- _execution_gates -- Execution gate logic extracted from _dispatch (#3928)
"""

from __future__ import annotations

# Re-export all public symbols for backward compatibility.
from apps.backend.api.public_mcp._constants import (  # noqa: F401
    _PLAN_STEER_MCP_TOOLS,
    _GUARDED_PUBLIC_MCP_TOOLS,
    _SAFE_OPERATION_PREFIXES,
    _HIGH_RISK_OPERATION_PREFIXES,
    _SAFE_CONNECTOR_HTTP_METHODS,
    _TOOL_SEARCH_NAME,
    _CONNECTOR_EXECUTE_TOOL_NAMES,
    _PARITY_JSON_PATH,
)

from apps.backend.api.public_mcp._schemas_legacy import (  # noqa: F401
    _LEGACY_PUBLIC_MCP_TOOLS,
)

from apps.backend.api.public_mcp._schemas_native import (  # noqa: F401
    _NATIVE_PUBLIC_MCP_TOOLS,
    _WORKFLOW_PUBLIC_MCP_TOOLS,
    _PERSONA_PUBLIC_MCP_TOOLS,
)

from apps.backend.api.public_mcp._catalog import (  # noqa: F401
    PUBLIC_MCP_TOOLS,
    _PUBLIC_MCP_CATALOG_TOOLS,
    _LEGACY_TO_CANONICAL,
    _CANONICAL_TO_LEGACY,
    _PUBLIC_TOOL_BY_NAME,
    _PUBLIC_CATALOG_TOOL_BY_NAME,
    canonical_public_mcp_tool_name,
    is_public_mcp_tool,
    get_public_mcp_tool_schema,
    get_public_mcp_tool_index,
    search_public_mcp_tools,
)

from apps.backend.api.public_mcp._dispatch import (  # noqa: F401
    _TOOL_DISPATCH,
    dispatch_mcp_tool,
    # Re-exported for test monkeypatching compatibility
    _get_swarm_tool_discovery_service,
)
from apps.backend.api.public_mcp._service_dispatch import (  # noqa: F401
    _LEARNING_DLQ_MCP_TOOLS,
    # AgentCard dispatch (#3947)
    _dispatch_agent_card_show,
    _dispatch_agent_card_verify,
)

from apps.backend.api.public_mcp._skill_curator_dispatch import (  # noqa: F401
    _SKILL_CURATOR_STATUSES,
    _SKILL_CURATOR_DECISIONS,
    _SYNTHETIC_SKILL_CURATOR_DECISION_ACTORS,
    _SKILL_CURATOR_WEIGHT_FIELDS,
    _dispatch_skill_curator_tool,
    _get_skill_curator_service,
)

from apps.backend.api.public_mcp._execution_gates import (  # noqa: F401
    _evaluate_public_mcp_execution_gate,
    _validate_public_mcp_side_effect_proof,
    _get_execution_guard,
    _connector_operation_http_method,
)
