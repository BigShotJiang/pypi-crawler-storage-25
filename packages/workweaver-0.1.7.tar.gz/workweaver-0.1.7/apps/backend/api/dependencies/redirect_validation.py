"""Redirect/handoff target allowlist validation (CVE-2026-32025).

Issue #3184: redirect and handoff endpoints accepted arbitrary target
URLs, enabling open-redirect attacks.  This module provides:

1. ``validate_redirect_host`` — validates that the host portion of a
   redirect target is on the PlatformAllowlist URL kind *or* is a
   Workweaver-owned domain.

2. ``validate_redirect_url`` — convenience wrapper that parses a full
   URL and validates its host.

Both functions raise ``HTTPException(400)`` on denial.
"""

from __future__ import annotations

import logging
from urllib.parse import urlparse

from fastapi import HTTPException, status

logger = logging.getLogger(__name__)


def _is_workweaver_host(host: str) -> bool:
    """Return True if the host is a Workweaver-owned domain."""
    normalized = (host or "").strip().lower().rstrip(".")
    return (
        normalized == "workweaver.ai"
        or normalized.endswith(".workweaver.ai")
    )


def _is_localhost(host: str) -> bool:
    """Return True if the host is localhost or loopback."""
    normalized = (host or "").strip().lower()
    return (
        normalized == "localhost"
        or normalized.startswith("127.")
        or normalized == "[::1]"
        or normalized == "::1"
    )


def validate_redirect_host(
    host: str,
    *,
    tenant_id: str | None = None,
    allow_localhost: bool = False,
) -> str:
    """Validate that a redirect target host is on the allowlist.

    The host is considered allowed when ANY of these are true:

    1. It is a Workweaver-owned domain (workweaver.ai or *.workweaver.ai).
    2. It is in the PlatformAllowlist URL kind (via ``url_is_allowed``).
    3. It is localhost/loopback and ``allow_localhost`` is True (dev mode).

    Returns the normalized (lowercased, stripped) host on success.
    Raises ``HTTPException(400)`` on denial.
    """
    normalized = (host or "").strip().lower().rstrip(".")
    if not normalized:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Redirect target host is required",
        )

    # Workweaver-owned domains are always allowed.
    if _is_workweaver_host(normalized):
        _record_redirect_allow(
            normalized,
            tenant_id=tenant_id,
            actor_chain=["workweaver_domain"],
        )
        return normalized

    # Localhost is allowed only in dev mode.
    if allow_localhost and _is_localhost(normalized):
        _record_redirect_allow(
            normalized,
            tenant_id=tenant_id,
            actor_chain=["localhost_dev_mode"],
        )
        return normalized

    # Check the PlatformAllowlist URL kind.
    try:
        from apps.backend.services.policy.allowlist_adopters import url_is_allowed

        if url_is_allowed(normalized, tenant_id=tenant_id):
            # url_is_allowed already emits the allow trace
            return normalized
    except Exception:
        logger.warning(
            "redirect_validation.allowlist_check_failed host=%s tenant=%s",
            normalized,
            tenant_id,
            exc_info=True,
        )

    logger.warning(
        "redirect_denied host=%s tenant=%s",
        normalized,
        tenant_id,
    )
    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail=f"Redirect target host '{normalized}' is not allowed",
    )


def _record_redirect_allow(
    host: str,
    *,
    tenant_id: str | None,
    actor_chain: list[str],
) -> None:
    """Emit a decision trace when a redirect target is ALLOWED.

    Called for Workweaver-owned domains and localhost-dev-mode paths.
    The ``url_is_allowed`` path emits its own trace via ``_record_url_allow``
    in allowlist_adopters.py, so this function covers the cases where the
    allowlist is bypassed (trusted first-party domains).
    """
    tenant = tenant_id or "platform"
    metadata: dict = {
        "redirect_target": host,
        "policy_verdict": "allowed",
        "actor_chain": actor_chain,
        "tenant_id": tenant_id,
    }
    try:
        from apps.backend.services.context.decision_event_capture import capture_decision

        capture_decision(
            tenant_id=tenant,
            skill_id="policy.redirect.allowlist",
            decision_summary=f"Allowed redirect target {host}",
            decision_type="policy.redirect.allow",
            outcome="allowed",
            rationale=f"Host matched trusted category: {', '.join(actor_chain)}",
            capture_surface="policy.redirect",
            service_family="policy",
            context_data=metadata,
        )
    except Exception:
        logger.warning(
            "redirect_validation.allow_trace_failed tenant=%s host=%s",
            tenant_id,
            host,
            exc_info=True,
        )


def validate_redirect_url(
    url: str,
    *,
    tenant_id: str | None = None,
    allow_localhost: bool = False,
) -> str:
    """Validate that a full redirect URL's host is on the allowlist.

    Parses the URL, extracts the host, and delegates to
    ``validate_redirect_host``.

    Returns the original URL on success.
    Raises ``HTTPException(400)`` on denial or if the URL is malformed.
    """
    stripped = (url or "").strip()
    if not stripped:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Redirect URL is required",
        )

    try:
        parsed = urlparse(stripped)
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Malformed redirect URL",
        )

    host = (parsed.hostname or "").strip()
    if not host:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Redirect URL has no host",
        )

    # Only allow http/https schemes.
    if parsed.scheme and parsed.scheme not in {"http", "https"}:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Redirect URL scheme '{parsed.scheme}' is not allowed",
        )

    validate_redirect_host(host, tenant_id=tenant_id, allow_localhost=allow_localhost)
    return stripped
