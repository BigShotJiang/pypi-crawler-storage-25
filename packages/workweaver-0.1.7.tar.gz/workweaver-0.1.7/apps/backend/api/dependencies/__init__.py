"""FastAPI dependency injection utilities."""

_EXPORTS = {
    "get_verified_tenant_id": (".tenant_auth", "get_verified_tenant_id"),
    "get_plugin_tenant_id": (".plugin_auth", "get_plugin_tenant_id"),
    "require_admin_permission": (".admin_permissions", "require_admin_permission"),
    "require_admin_permission_dep": (".admin_permissions", "require_admin_permission_dep"),
    "require_role": (".scope_validation", "require_role"),
    "validate_websocket_scope": (".scope_validation", "validate_websocket_scope"),
    "role_satisfies": (".scope_validation", "role_satisfies"),
    "validate_redirect_host": (".redirect_validation", "validate_redirect_host"),
    "validate_redirect_url": (".redirect_validation", "validate_redirect_url"),
}


def __getattr__(name: str):
    if name not in _EXPORTS:
        raise AttributeError(name)
    module_path, attr = _EXPORTS[name]
    from importlib import import_module

    module = import_module(module_path, __name__)
    value = getattr(module, attr)
    globals()[name] = value
    return value

__all__ = [
    "get_verified_tenant_id",
    "get_plugin_tenant_id",
    "require_admin_permission",
    "require_admin_permission_dep",
    "require_role",
    "validate_websocket_scope",
    "role_satisfies",
    "validate_redirect_host",
    "validate_redirect_url",
]
