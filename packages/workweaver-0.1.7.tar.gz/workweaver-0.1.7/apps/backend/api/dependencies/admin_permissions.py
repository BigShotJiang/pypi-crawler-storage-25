"""FastAPI dependency for granular admin permission checks.

#3227: Bridges ``require_founder`` (authentication) with
``AdminPermission`` (authorization). Every admin endpoint declares
its required permission via ``Depends(require_admin_permission(...))``
instead of raw ``Depends(require_founder)``.

Backward compatibility:
  - All founder-authenticated users are mapped to PLATFORM_ADMIN.
  - Existing admin functionality is unchanged because PLATFORM_ADMIN
    has every permission.
  - Future: role can be stored per-user in DynamoDB and resolved here.
"""

from __future__ import annotations

import logging
from typing import Annotated

from fastapi import Depends, HTTPException, status

from apps.backend.api.founder_admin import require_founder
from apps.backend.services.admin.admin_permission import (
    AdminPermission,
    AdminPermissionCheck,
    AdminRole,
    check_permission,
)

logger = logging.getLogger(__name__)


async def require_admin_permission(
    permission: AdminPermission,
    founder_email: Annotated[str, Depends(require_founder)],
) -> AdminPermissionCheck:
    """FastAPI dependency that checks an admin permission after authentication.

    Flow:
      1. ``require_founder`` authenticates the user (401/403 on failure).
      2. Resolve the user's ``AdminRole``.
         Currently hardcoded: founders = PLATFORM_ADMIN.
         Future: look up role from a per-user DynamoDB record.
      3. ``check_permission`` evaluates the role-permission matrix.
      4. Returns ``AdminPermissionCheck`` on success, raises 403 on denial.

    Usage::

        @router.get("/providers")
        async def list_providers(
            _perm: AdminPermissionCheck = Depends(
                require_admin_permission_dep(AdminPermission.INFERENCE_READ)
            ),
        ) -> ...:
    """
    # Map authenticated founder to role.
    # Hardcoded for now: all founders are platform_admin.
    # When per-user roles are stored in DynamoDB, resolve here.
    role = AdminRole.PLATFORM_ADMIN

    result = check_permission(
        role=role,
        permission=permission,
        actor_id=founder_email,
    )

    if not result.allowed:
        logger.warning(
            "admin_permission_denied actor=%s role=%s permission=%s reason=%s",
            founder_email,
            role.value,
            permission.value,
            result.reason,
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=result.reason or "Permission denied",
        )

    return result


def require_admin_permission_dep(permission: AdminPermission) -> type:
    """Return a FastAPI-dependency-compatible callable for a given permission.

    FastAPI ``Depends()`` requires a callable. This factory returns one that
    carries the specific ``AdminPermission`` as a closure, so you can write::

        @router.get(...)
        async def handler(
            _perm: AdminPermissionCheck = Depends(
                require_admin_permission_dep(AdminPermission.INFERENCE_READ)
            ),
        ):

    instead of the less-readable lambda form.
    """

    async def _dependency(
        founder_email: str = Depends(require_founder),
    ) -> AdminPermissionCheck:
        return await require_admin_permission(permission, founder_email)

    # Preserve a readable name for FastAPI's dependency display.
    _dependency.__name__ = f"require_admin_permission({permission.value})"
    _dependency.__qualname__ = f"require_admin_permission({permission.value})"
    return _dependency  # type: ignore[return-value]
