"""Plugin authentication dependency for FastAPI routes.

Validates Bearer ww_sk_* API keys from the Workweaver Runtime plugin.
In production: looks up the hashed key in DynamoDB (O(1) get_item).
In local identity-disabled dev mode: falls back to X-Tenant-Id header.
"""
from apps.backend.config.table_names import resolve_table

import hashlib
import logging
import os
from apps.backend.config.region import AWS_REGION
from datetime import datetime, UTC

from fastapi import HTTPException, Request, status

logger = logging.getLogger(__name__)

# Table name from env, default to dev table
_TENANTS_TABLE = resolve_table("tenants")


def _disable_cognito() -> bool:
    """Check if managed auth is disabled (dev/test mode).

    Safety: forcibly ignores DISABLE_COGNITO in production environments and ECS.
    """
    val = os.environ.get("DISABLE_COGNITO", "").strip().lower() in {"1", "true", "yes"}
    if not val:
        return False
    from apps.backend.config.environment import get_environment, is_production_like

    env = get_environment()
    if is_production_like():
        logger.critical(
            "SECURITY: DISABLE_COGNITO is set in %s environment. "
            "This is a critical security misconfiguration. Ignoring the flag.",
            env,
        )
        return False
    if os.environ.get("ECS_CONTAINER_METADATA_URI"):
        logger.critical(
            "SECURITY: DISABLE_COGNITO is set in an ECS environment. "
            "This is a critical security misconfiguration. Ignoring the flag."
        )
        return False
    return True


def _hash_api_key(raw_key: str) -> str:
    """SHA-256 hash of the raw API key for DynamoDB lookup."""
    return hashlib.sha256(raw_key.encode()).hexdigest()


def _lookup_api_key_record(raw_key: str) -> dict[str, str] | None:
    """Look up an API key in DynamoDB and return its trusted binding if valid.

    Uses the APIKEY#<sha256_hash> / META record for O(1) lookup.
    Returns None if the key is not found.
    """
    try:
        import boto3

        key_hash = _hash_api_key(raw_key)
        table_name = resolve_table("tenants")
        dynamodb = boto3.resource(
            "dynamodb",
            region_name=AWS_REGION,
        )
        table = dynamodb.Table(table_name)

        response = table.get_item(
            Key={"PK": f"APIKEY#{key_hash}", "SK": "META"},
            ProjectionExpression="tenant_id,user_id,key_id",
        )

        item = response.get("Item")
        if not item:
            return None

        tenant_id = item.get("tenant_id")
        if not tenant_id:
            return None

        # Best-effort: update last_used timestamp (non-blocking)
        try:
            table.update_item(
                Key={"PK": f"APIKEY#{key_hash}", "SK": "META"},
                UpdateExpression="SET last_used = :ts",
                ExpressionAttributeValues={":ts": datetime.now(UTC).isoformat()},
            )
        except Exception:
            logger.debug("Plugin API key last_used update failed for key_hash=%s", key_hash, exc_info=True)

        return {
            "tenant_id": str(tenant_id),
            "user_id": str(item.get("user_id") or ""),
            "key_id": str(item.get("key_id") or ""),
        }
    except Exception as err:
        logger.error("DynamoDB API key lookup failed: %s", err)
        return None


def _lookup_api_key(raw_key: str) -> str | None:
    """Look up an API key in DynamoDB and return the tenant_id if valid."""
    record = _lookup_api_key_record(raw_key)
    return record["tenant_id"] if record else None


_ORIGINAL_LOOKUP_API_KEY = _lookup_api_key


def get_plugin_tenant_id(request: Request) -> str:
    """Extract and verify tenant_id from plugin API key.

    Checks for Authorization: Bearer ww_sk_* header.
    In production: validates against DynamoDB.
    In dev mode: falls back to X-Tenant-Id header.

    Returns:
        Verified tenant_id string.

    Raises:
        HTTPException 401 if no valid API key or tenant_id.
    """
    # Try Bearer token first (works in both prod and dev)
    auth_header = (request.headers.get("authorization") or "").strip()
    if auth_header.lower().startswith("bearer "):
        token = auth_header.split(" ", 1)[1].strip()
        if token.startswith("ww_sk_"):
            record = None
            if _lookup_api_key is _ORIGINAL_LOOKUP_API_KEY:
                record = _lookup_api_key_record(token)
            else:
                tenant_id = _lookup_api_key(token)
                if tenant_id:
                    record = {"tenant_id": tenant_id, "user_id": "", "key_id": ""}
            if record:
                tenant_id = record["tenant_id"]
                user_id = record.get("user_id") or ""
                if user_id:
                    request.state.authenticated_user_id = user_id
                    request.state.user_id = user_id
                if record.get("key_id"):
                    request.state.api_key_id = record["key_id"]
                request.state.plugin_api_key_record = dict(record)
                request.state.authenticated_tenant_id = tenant_id
                return tenant_id
            # Key exists but not found in DynamoDB
            if not _disable_cognito():
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid API key",
                )
            # In dev mode, fall through to X-Tenant-Id
        else:
            # Not a ww_sk_ token
            if not _disable_cognito():
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Invalid API key format. Expected: Bearer ww_sk_*",
                )

    # Dev mode fallback: trust X-Tenant-Id header
    if _disable_cognito():
        x_tenant_id = (request.headers.get("x-tenant-id") or "").strip()
        if x_tenant_id:
            return x_tenant_id
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="X-Tenant-Id header required (dev mode)",
        )

    # Production: no valid Bearer token found
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Authorization header with Bearer ww_sk_* token required",
    )
