"""Server-side scope validation dependency for WS/REST endpoints (CVE-2026-22172).

Issue #3183: endpoints accepted requests without validating the caller's
role/scope.  This module provides:

1. ``require_role`` — a FastAPI ``Depends`` factory that validates the
   authenticated user's role against a minimum-required role.

2. ``validate_websocket_scope`` — a callable that performs the same check
   for WebSocket handshakes (where FastAPI ``Depends`` is not available
   during the accept phase).

Role hierarchy (ascending privilege):
  AGENT < MANAGER < ADMIN

A ``require_role(UserRole.MANAGER)`` call admits MANAGER and ADMIN but
denies AGENT with 403.
"""

from __future__ import annotations

import logging

from fastapi import Depends, HTTPException, WebSocket, status

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_user_role,
)
from apps.backend.models.user import UserRole

logger = logging.getLogger(__name__)

# Ordered from least to most privileged.
_ROLE_HIERARCHY: dict[UserRole, int] = {
    UserRole.AGENT: 0,
    UserRole.MANAGER: 1,
    UserRole.ADMIN: 2,
}


def role_satisfies(have: UserRole, required: UserRole) -> bool:
    """Return True when ``have`` meets or exceeds ``required``."""
    return _ROLE_HIERARCHY.get(have, -1) >= _ROLE_HIERARCHY.get(required, -1)


def require_role(minimum_role: UserRole):
    """FastAPI dependency factory that validates caller scope.

    Usage::

        @router.get("/api/v1/managers-only")
        async def handler(
            _role: UserRole = Depends(require_role(UserRole.MANAGER)),
        ):
            ...

    Returns the resolved ``UserRole`` on success; raises 403 on denial.
    """

    async def _dependency(
        user_role: UserRole = Depends(get_verified_user_role),
    ) -> UserRole:
        if not role_satisfies(user_role, minimum_role):
            logger.warning(
                "scope_denied required=%s actual=%s",
                minimum_role.value,
                user_role.value,
            )
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"{minimum_role.value} role required",
            )
        return user_role

    _dependency.__name__ = f"require_role({minimum_role.value})"
    _dependency.__qualname__ = f"require_role({minimum_role.value})"
    return _dependency


async def validate_websocket_scope(
    websocket: WebSocket,
    *,
    minimum_role: UserRole,
) -> UserRole:
    """Validate that the WebSocket caller meets the required role.

    Intended to be called *after* authentication succeeds (i.e., after
    ``resolve_verified_websocket_tenant_id``) and before
    ``websocket.accept()`` or any privileged message handling.

    Raises ``HTTPException(403)`` on denial; the caller should close the
    WebSocket with a 4403 close code.
    """
    # Reuse the same user-role resolution path as REST.
    # WebSocket queries carry tenant_id + access_token; the user record
    # is looked up from DynamoDB just like the HTTP path.
    from apps.backend.api.dependencies.tenant_auth import (
        _disable_cognito,
        _extract_authorizer_claims_from_scope,
        _resolve_context_from_access_token_value,
        _resolve_user_record,
        _canonical_resolved_tenant_id,
    )
    from apps.backend.providers.identity_provider import get_identity_provider, IdentityProviderError
    from apps.backend.utils.tenant import strip_tenant_prefix

    # Resolve tenant_id first (re-authenticate).
    query_tenant = str(websocket.query_params.get("tenant_id") or "").strip()
    header_tenant = str(
        websocket.headers.get("x-tenant-id")
        or websocket.headers.get("X-Tenant-Id")
        or "",
    ).strip()
    provided_tenant = strip_tenant_prefix(query_tenant or header_tenant) if (query_tenant or header_tenant) else ""

    if _disable_cognito():
        tenant_id = provided_tenant
        user_id = str(websocket.headers.get("x-user-id") or "").strip()
    else:
        claims = _extract_authorizer_claims_from_scope(
            websocket.scope if isinstance(websocket.scope, dict) else None,
        )
        if claims:
            try:
                envelope = get_identity_provider().resolve_from_claims(claims)
            except IdentityProviderError as exc:
                raise HTTPException(status_code=exc.status_code, detail=str(exc)) from exc
            tenant_id = _canonical_resolved_tenant_id(
                tenant_id=str(envelope.tenant_id or "").strip(),
                user_id=str(envelope.user_id or "").strip(),
                email=str(envelope.email or "").strip().lower(),
            )
            user_id = str(envelope.user_id or "").strip()
        else:
            access_token = str(websocket.query_params.get("access_token") or "").strip()
            if not access_token:
                from apps.backend.api.dependencies.tenant_auth import _extract_bearer_token_from_headers
                access_token = _extract_bearer_token_from_headers(websocket.headers)
            if not access_token:
                raise HTTPException(
                    status_code=status.HTTP_401_UNAUTHORIZED,
                    detail="Authentication required",
                )
            tenant_id, user_id = _resolve_context_from_access_token_value(access_token)

    if not tenant_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
        )

    if not user_id:
        user_id = str(websocket.headers.get("x-user-id") or "").strip()

    if not user_id:
        # Cannot determine identity, deny by default.
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cannot resolve user identity for scope check",
        )

    # Resolve the user record.
    record = _resolve_user_record(tenant_id, user_id)
    role_value = str(record.get("role", "")).strip().lower()
    try:
        user_role = UserRole(role_value) if role_value else UserRole.AGENT
    except ValueError:
        user_role = UserRole.AGENT

    if not role_satisfies(user_role, minimum_role):
        logger.warning(
            "ws_scope_denied tenant=%s user=%s required=%s actual=%s",
            tenant_id,
            user_id,
            minimum_role.value,
            user_role.value,
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"{minimum_role.value} role required",
        )

    return user_role
