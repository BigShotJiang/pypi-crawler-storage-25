"""Outbound SMS API and delivery status webhook.

Provides:
- POST /api/v1/sms/send — send an outbound SMS via Twilio
- POST /api/v1/webhooks/sms/status — delivery status callback from Twilio
- GET /api/v1/sms/conversations/{conversation_id} — retrieve SMS thread

Launch Plan L4.5: SMS as first-class conversational channel.
"""

from __future__ import annotations

import hashlib
import hmac
import logging
import os
import time
from collections import defaultdict
from typing import Any

from fastapi import APIRouter, Depends, Form, HTTPException, Request
from fastapi.responses import Response
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.compliance_guard import Channel
from apps.backend.services.channels.outbound_preflight import run_outbound_preflight

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/sms", tags=["sms"])

# Opt-out keywords (Twilio STOP compliance)
OPT_OUT_KEYWORDS = frozenset({"STOP", "STOPALL", "UNSUBSCRIBE", "CANCEL", "END", "QUIT"})

# Rate limit: max messages per contact per hour
MAX_MESSAGES_PER_CONTACT_PER_HOUR = 10

# In-memory rate limit tracker (keyed by tenant_id:to_number)
# In production, this would use Redis or DynamoDB TTL items.
_rate_limit_tracker: dict[str, list[float]] = defaultdict(list)

# In-memory opt-out set (keyed by tenant_id:phone_number)
# In production, this would be persisted in DynamoDB.
_opt_out_set: set[str] = set()


class SendSmsRequest(BaseModel):
    """Request body for sending an outbound SMS."""

    to_number: str = Field(..., min_length=10, description="E.164 destination phone number")
    body: str = Field(..., min_length=1, max_length=1600, description="SMS body text")


class SendSmsResponse(BaseModel):
    """Response after sending an outbound SMS."""

    success: bool
    message_sid: str | None = None
    conversation_id: str | None = None
    error: str | None = None


class SmsMessage(BaseModel):
    """A single SMS message in a conversation thread."""

    message_sid: str
    direction: str
    from_number: str
    to_number: str
    body: str
    status: str
    created_at: str


class SmsConversationResponse(BaseModel):
    """SMS conversation thread."""

    conversation_id: str
    messages: list[SmsMessage] = []
    total: int = 0


def _check_opt_out(tenant_id: str, phone_number: str) -> bool:
    """Check if a phone number has opted out for a tenant."""
    return f"{tenant_id}:{phone_number}" in _opt_out_set


def _register_opt_out(tenant_id: str, phone_number: str) -> None:
    """Register an opt-out for a phone number."""
    _opt_out_set.add(f"{tenant_id}:{phone_number}")


def _check_rate_limit(tenant_id: str, to_number: str) -> bool:
    """Check if sending to this contact exceeds the rate limit.

    Returns True if the send should be BLOCKED (rate exceeded).
    """
    key = f"{tenant_id}:{to_number}"
    now = time.time()
    hour_ago = now - 3600

    # Prune old entries
    _rate_limit_tracker[key] = [t for t in _rate_limit_tracker[key] if t > hour_ago]

    if len(_rate_limit_tracker[key]) >= MAX_MESSAGES_PER_CONTACT_PER_HOUR:
        return True

    _rate_limit_tracker[key].append(now)
    return False


def _get_twilio_client() -> Any:
    """Get Twilio REST client. Raises RuntimeError if not configured."""
    try:
        from twilio.rest import Client  # type: ignore[import-untyped]
    except ImportError as exc:
        raise RuntimeError("Twilio SDK not installed") from exc

    account_sid = os.getenv("TWILIO_ACCOUNT_SID", "").strip()
    auth_token = os.getenv("TWILIO_AUTH_TOKEN", "").strip()
    if not account_sid or not auth_token:
        raise RuntimeError("TWILIO_ACCOUNT_SID and TWILIO_AUTH_TOKEN must be set")

    return Client(account_sid, auth_token)


def _get_twilio_from_number() -> str:
    """Get the Twilio sender phone number."""
    number = os.getenv("TWILIO_PHONE_NUMBER", "").strip()
    if not number:
        raise RuntimeError("TWILIO_PHONE_NUMBER must be set")
    return number


def _get_thread_service():
    from apps.backend.services.thread_service import get_thread_service

    return get_thread_service()


def _canonical_sms_source_ref(number_a: str, number_b: str) -> str:
    normalized_numbers = sorted([str(number_a or "").strip(), str(number_b or "").strip()])
    if len(normalized_numbers) != 2 or not normalized_numbers[0] or not normalized_numbers[1]:
        return ""
    return f"sms:{normalized_numbers[0]}_{normalized_numbers[1]}"


def _parse_sms_source_ref(source_ref: str) -> tuple[str, str]:
    normalized = str(source_ref or "").strip()
    if not normalized.startswith("sms:"):
        return "", ""
    numbers = normalized.removeprefix("sms:")
    if "_" not in numbers:
        return "", ""
    left, right = numbers.split("_", 1)
    return left, right


def _derive_sms_message_numbers(
    *,
    source_ref: str,
    direction: str,
    participant: str,
) -> tuple[str, str]:
    left, right = _parse_sms_source_ref(source_ref)
    normalized_direction = str(direction or "").strip().lower() or "unknown"
    normalized_participant = str(participant or "").strip()
    other_number = ""
    if normalized_participant == left:
        other_number = right
    elif normalized_participant == right:
        other_number = left
    elif right:
        other_number = right
    elif left:
        other_number = left
    if normalized_direction == "outbound":
        return other_number, normalized_participant or right
    return normalized_participant or left, other_number or right


def _canonical_thread_to_sms_messages(thread: dict[str, Any]) -> list[dict[str, Any]]:
    source_ref = str(thread.get("source_ref") or "").strip()
    raw_messages = list(thread.get("messages") or [])
    normalized_messages: list[dict[str, Any]] = []
    for message in raw_messages:
        if not isinstance(message, dict):
            continue
        message_sid = str(message.get("message_id") or "").strip()
        if not message_sid:
            continue
        direction = str(message.get("direction") or "unknown").strip().lower() or "unknown"
        from_number, to_number = _derive_sms_message_numbers(
            source_ref=source_ref,
            direction=direction,
            participant=str(message.get("participant") or "").strip(),
        )
        normalized_messages.append(
            {
                "message_sid": message_sid,
                "direction": direction,
                "from_number": from_number,
                "to_number": to_number,
                "body": str(message.get("body") or ""),
                "status": str(message.get("status") or ("received" if direction == "inbound" else "queued")),
                "created_at": str(message.get("created_at") or ""),
            }
        )
    normalized_messages.sort(key=lambda item: item.get("created_at", ""))
    return normalized_messages


def _verify_twilio_signature(
    *,
    auth_token: str,
    url: str,
    params: dict[str, str],
    signature: str,
) -> bool:
    """Verify Twilio request signature using HMAC-SHA1.

    Returns True if the request is authentic.
    """
    if not auth_token or not signature:
        return False

    try:
        from twilio.request_validator import RequestValidator  # type: ignore[import-untyped]

        validator = RequestValidator(auth_token)
        return validator.validate(url, params, signature)
    except ImportError:
        # Fallback: manual HMAC-SHA1 verification
        sorted_params = "".join(f"{k}{v}" for k, v in sorted(params.items()))
        data = f"{url}{sorted_params}"
        import base64

        computed = base64.b64encode(
            hmac.new(
                auth_token.encode("utf-8"),
                data.encode("utf-8"),
                hashlib.sha1,
            ).digest()
        ).decode("utf-8")
        return hmac.compare_digest(computed, signature)


def _resolve_tenant_from_account_sid(account_sid: str) -> str:
    """Resolve tenant_id from Twilio AccountSid.

    In a multi-tenant deployment, this would look up the mapping in DynamoDB.
    Falls back to DEFAULT_TENANT_ID for single-tenant deployments.
    """
    # Single-tenant shortcut: if there's only one Twilio account,
    # use the configured default tenant
    configured_sid = os.getenv("TWILIO_ACCOUNT_SID", "").strip()
    if account_sid and configured_sid and account_sid == configured_sid:
        return os.getenv("DEFAULT_TENANT_ID", "system")

    # Multi-tenant: would query DynamoDB mapping table here
    # For now, fall back to default with a warning
    if account_sid:
        logger.warning(
            "No tenant mapping for AccountSid=%s, using DEFAULT_TENANT_ID",
            account_sid,
        )
    return os.getenv("DEFAULT_TENANT_ID", "system")


def _store_outbound_sms(
    *,
    tenant_id: str,
    from_number: str,
    to_number: str,
    body: str,
    message_sid: str,
    status: str = "queued",
) -> dict[str, Any] | None:
    """Store outbound SMS on the canonical thread model."""
    source_ref = _canonical_sms_source_ref(from_number, to_number)
    return _get_thread_service().record_channel_message(
        tenant_id=tenant_id,
        channel="sms",
        source_ref=source_ref,
        message_id=message_sid,
        direction="outbound",
        participant=to_number,
        body=body,
        unread=False,
        event_type="outbound_sent",
        thread_kind="sms",
        participants=[from_number, to_number],
        status=status,
    )


def _update_sms_status(
    *,
    tenant_id: str,
    message_sid: str,
    status: str,
    from_number: str,
    to_number: str,
) -> dict[str, Any] | None:
    """Update SMS delivery status on the canonical thread model."""
    thread_service = _get_thread_service()
    existing_thread = thread_service.find_thread_by_message_id(
        tenant_id=tenant_id,
        message_id=message_sid,
    )
    source_ref = str((existing_thread or {}).get("source_ref") or "").strip()
    if not source_ref:
        source_ref = _canonical_sms_source_ref(from_number, to_number)
    if not source_ref:
        logger.warning(
            "Skipping SMS status update without canonical thread identity tenant=%s sid=%s status=%s",
            tenant_id,
            message_sid,
            status,
        )
        return None
    participant = str(to_number or "").strip()
    if not participant and isinstance(existing_thread, dict):
        for message in list(existing_thread.get("messages") or []):
            if str(message.get("message_id") or "").strip() != message_sid:
                continue
            participant = str(message.get("participant") or "").strip()
            if participant:
                break
    participants: list[str] = []
    if isinstance(existing_thread, dict):
        participants = [str(value or "").strip() for value in list(existing_thread.get("participants") or []) if str(value or "").strip()]
    if not participants and from_number and to_number:
        participants = [from_number, to_number]
    return thread_service.record_channel_message(
        tenant_id=tenant_id,
        channel="sms",
        source_ref=source_ref,
        message_id=message_sid,
        direction="outbound",
        participant=participant,
        unread=False,
        event_type=f"sms_{status}",
        thread_kind="sms",
        participants=participants or None,
        status=status,
        metadata={"delivery_status": status},
    )


def _get_conversation_messages(tenant_id: str, conversation_id: str) -> list[dict[str, Any]]:
    """Retrieve SMS messages from the canonical thread model."""
    thread = _get_thread_service().resolve_thread(tenant_id=tenant_id, identifier=conversation_id)
    if not isinstance(thread, dict):
        return []
    return _canonical_thread_to_sms_messages(thread)


@router.post("/send", response_model=SendSmsResponse)
async def send_sms(
    request: SendSmsRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SendSmsResponse:
    """Send an outbound SMS via Twilio.

    Validates opt-out status and rate limits before sending.
    Stores the message in DynamoDB with direction=outbound.
    """
    to_number = request.to_number.strip()
    body = request.body.strip()

    # ComplianceGuard DNC gate (#2795). Tenant-scoped block list applies to
    # the canonical compliance.dnc store; check before legacy opt-out + rate
    # limit so the user-visible error names the canonical reason.
    try:
        from apps.backend.services.compliance import is_blocked as _dnc_is_blocked

        if _dnc_is_blocked(tenant_id, to_number, "sms"):
            return SendSmsResponse(
                success=False,
                error=f"Contact {to_number} is on the DNC list (sms)",
            )
    except Exception:
        # Never let the DNC gate crash the send path — log and fall through
        # to existing opt-out / rate-limit guards.
        logger.warning("dnc.gate_unavailable", exc_info=True)

    # Check opt-out
    if _check_opt_out(tenant_id, to_number):
        return SendSmsResponse(
            success=False,
            error=f"Contact {to_number} has opted out of SMS",
        )

    # Check rate limit
    if _check_rate_limit(tenant_id, to_number):
        return SendSmsResponse(
            success=False,
            error=f"Rate limit exceeded: max {MAX_MESSAGES_PER_CONTACT_PER_HOUR} messages per contact per hour",
        )

    try:
        import asyncio

        loop = asyncio.get_running_loop()
        client = _get_twilio_client()
        from_number = _get_twilio_from_number()

        try:
            await run_outbound_preflight(
                tenant_id=tenant_id,
                channel=Channel.SMS,
                recipient=to_number,
                sender_identity=from_number,
                message_type="text",
                message_body=body,
                side_effect_class="WRITE_EXTERNAL",
                operation="sms.api.send",
            )
        except Exception as exc:
            if str(exc).startswith("outbound_compliance_blocked:"):
                return SendSmsResponse(success=False, error=str(exc))
            raise

        # Offload blocking Twilio SDK call to thread pool
        message = await loop.run_in_executor(
            None,
            lambda: client.messages.create(
                body=body,
                from_=from_number,
                to=to_number,
                status_callback=os.getenv("SMS_STATUS_CALLBACK_URL", "") or None,
            ),
        )

        message_sid = message.sid
        thread = await loop.run_in_executor(
            None,
            lambda: _store_outbound_sms(
                tenant_id=tenant_id,
                from_number=from_number,
                to_number=to_number,
                body=body,
                message_sid=message_sid,
                status="queued",
            ),
        )
        conversation_id = str((thread or {}).get("thread_id") or _canonical_sms_source_ref(from_number, to_number))

        logger.info(
            "SMS sent: tenant=%s to=%s sid=%s",
            tenant_id,
            to_number,
            message_sid,
        )

        return SendSmsResponse(
            success=True,
            message_sid=message_sid,
            conversation_id=conversation_id,
        )

    except RuntimeError as exc:
        logger.error("SMS send failed (config): %s", exc)
        return SendSmsResponse(success=False, error=str(exc))
    except Exception as exc:
        logger.exception("SMS send failed: %s", exc)
        return SendSmsResponse(success=False, error=f"Failed to send SMS: {exc}")


@router.post("/status", status_code=204)
async def handle_sms_status(
    request: Request,
    MessageSid: str = Form(default=""),
    MessageStatus: str = Form(default=""),
    To: str = Form(default=""),
    From: str = Form(default=""),
    AccountSid: str = Form(default=""),
) -> Response:
    """Handle SMS delivery status callback from Twilio.

    Twilio sends POST with form data when message status changes
    (queued -> sent -> delivered / failed / undelivered).
    Validates Twilio request signature when auth token is configured.
    """
    # Verify Twilio signature
    auth_token = os.getenv("TWILIO_AUTH_TOKEN", "").strip()
    if auth_token:
        twilio_signature = request.headers.get("X-Twilio-Signature", "")
        # Build form params dict for signature verification
        form_data = await request.form()
        params = {str(k): str(v) for k, v in form_data.items()}
        url = str(request.url)

        if not _verify_twilio_signature(
            auth_token=auth_token,
            url=url,
            params=params,
            signature=twilio_signature,
        ):
            raise HTTPException(status_code=401, detail="Invalid Twilio signature")

    message_sid = str(MessageSid).strip()
    msg_status = str(MessageStatus).strip()

    if not message_sid or not msg_status:
        return Response(status_code=204)

    logger.info(
        "SMS status callback: sid=%s status=%s to=%s",
        message_sid,
        msg_status,
        str(To).strip(),
    )

    # Resolve tenant from the Twilio AccountSid
    tenant_id = _resolve_tenant_from_account_sid(str(AccountSid).strip())

    try:
        import asyncio

        loop = asyncio.get_running_loop()
        await loop.run_in_executor(
            None,
            lambda: _update_sms_status(
                tenant_id=tenant_id,
                message_sid=message_sid,
                status=msg_status,
                from_number=str(From).strip(),
                to_number=str(To).strip(),
            ),
        )
    except Exception as exc:
        logger.warning("Failed to update SMS status: %s", exc)

    return Response(status_code=204)


@router.get("/conversations/{conversation_id}", response_model=SmsConversationResponse)
async def get_sms_conversation(
    conversation_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SmsConversationResponse:
    """Retrieve an SMS conversation thread.

    Returns all messages (inbound + outbound) for the given conversation_id,
    sorted chronologically.
    """
    import asyncio

    loop = asyncio.get_running_loop()
    messages_raw = await loop.run_in_executor(
        None,
        _get_conversation_messages,
        tenant_id,
        conversation_id,
    )

    messages = [
        SmsMessage(
            message_sid=m.get("message_sid", ""),
            direction=m.get("direction", "unknown"),
            from_number=m.get("from_number", ""),
            to_number=m.get("to_number", ""),
            body=m.get("body", ""),
            status=m.get("status", "unknown"),
            created_at=m.get("created_at", ""),
        )
        for m in messages_raw
    ]

    normalized_conversation_id = conversation_id
    thread = _get_thread_service().resolve_thread(tenant_id=tenant_id, identifier=conversation_id)
    if isinstance(thread, dict) and thread.get("thread_id"):
        normalized_conversation_id = str(thread.get("thread_id") or conversation_id)

    return SmsConversationResponse(conversation_id=normalized_conversation_id, messages=messages, total=len(messages))
