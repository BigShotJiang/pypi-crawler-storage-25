"""Agent Calendar API endpoint.

Provides POST /api/v1/calendar/check for Workweaver Runtime plugin calendar tool.
Response matches plugin TypeScript interface, with reliability metadata:
  {slots: CalendarSlot[], timezone: string, availability_status: string}

CalendarSlot = {start: string, end: string, available: boolean, title?: string, availability_status?: string}

Track 6: When a tenant has an active Google/Microsoft calendar connection,
real busy periods are fetched via calendar_api and used to mark slots unavailable.
No connection remains an open calendar assumption; provider failure returns
unknown slots and never silently becomes all-available.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta

from fastapi import APIRouter, Body, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.billing import MeteringService
from apps.backend.services.calendar.calendar_writer import (
    CalendarAttendee,
    CalendarEventRequest,
    CalendarPermissionError,
    CalendarProviderError,
    CalendarTimeRange,
    get_calendar_writer,
)
from apps.backend.services.usage_tracker import UsageMetricType
from apps.backend.utils.time import parse_iso

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/calendar", tags=["agent-calendar"])

# 30-minute slot duration
_SLOT_DURATION = timedelta(minutes=30)


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class CalendarCheckRequest(BaseModel):
    """Request model matching Workweaver Runtime plugin CalendarCheckRequest."""

    start_time: str = Field(..., description="Start time in ISO8601 format")
    end_time: str = Field(..., description="End time in ISO8601 format")
    calendar_ids: list[str] | None = Field(None, description="Calendar IDs to check")
    attendees: list[str] | None = Field(None, description="Attendee emails to check")


class CalendarSlot(BaseModel):
    """Single calendar slot matching Workweaver Runtime plugin CalendarSlot interface."""

    start: str = Field(..., description="Slot start time (ISO8601)")
    end: str = Field(..., description="Slot end time (ISO8601)")
    available: bool = Field(..., description="Whether the slot is available")
    title: str | None = Field(None, description="Event title (if unavailable)")
    availability_status: str = Field("available", description="available, busy, or unknown")


class CalendarCheckResponse(BaseModel):
    """Response model matching Workweaver Runtime plugin CalendarCheckResponse.

    Base contract: {slots: CalendarSlot[], timezone: string}
    Reliability metadata distinguishes provider failure from confirmed availability.
    """

    slots: list[CalendarSlot] = Field(..., description="Time slots with availability")
    timezone: str = Field(..., description="Timezone of the slots")
    availability_status: str = Field("available", description="available, busy, or unknown")
    degraded: bool = Field(False, description="True when provider availability could not be confirmed")
    degradation_reason: str | None = Field(None, description="Machine-readable degradation reason")


class CalendarEventWriteRequest(BaseModel):
    provider: str = Field(..., description="Calendar provider: google, outlook, or zoho")
    actor_id: str = Field("zara", description="Actor requesting the write")
    on_behalf_of: str = Field("zara", description="Calendar principal receiving the write")
    title: str = Field(..., description="Event title")
    description: str = Field("", description="Event description")
    time_range: CalendarTimeRange
    attendees: list[CalendarAttendee] = Field(default_factory=list)
    location: str | None = None
    calendar_id: str | None = None
    idempotency_key: str | None = None


class CalendarRespondRequest(BaseModel):
    provider: str
    actor_id: str = "zara"
    on_behalf_of: str = "zara"
    response: str = Field(..., pattern="^(accepted|tentative|declined)$")
    idempotency_key: str | None = None


class CalendarCancelRequest(BaseModel):
    provider: str = "google"
    actor_id: str = "zara"
    on_behalf_of: str = "zara"
    calendar_id: str | None = None
    reason: str | None = None
    idempotency_key: str | None = None


class CalendarFindOptimalTimeRequest(BaseModel):
    provider: str
    actor_id: str = "zara"
    attendees: list[CalendarAttendee] = Field(default_factory=list)
    duration_minutes: int = Field(..., gt=0)
    search_start: datetime
    search_end: datetime


# ---------------------------------------------------------------------------
# Real calendar busy-period retrieval (Track 6)
# ---------------------------------------------------------------------------


async def get_tenant_calendar_busy_periods(tenant_id: str, start_iso: str, end_iso: str) -> list[dict] | None:
    """Fetch real busy periods for a tenant from connected calendar providers."""
    from apps.backend.services.agent_calendar_service import (
        get_tenant_calendar_busy_periods as shared_get_tenant_calendar_busy_periods,
    )

    return await shared_get_tenant_calendar_busy_periods(tenant_id, start_iso, end_iso)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _slot_overlaps_busy(slot_start: datetime, slot_end: datetime, busy_periods: list[dict]) -> bool:
    """Check if a slot overlaps any busy period.

    A slot is busy if it overlaps with any busy period, i.e.:
    slot_start < busy_end AND slot_end > busy_start
    """
    for busy in busy_periods:
        busy_start = parse_iso(busy["start"])
        busy_end = parse_iso(busy["end"])
        if slot_start < busy_end and slot_end > busy_start:
            return True
    return False


def _generate_slots(
    start_iso: str,
    end_iso: str,
    busy_periods: list[dict] | None = None,
    *,
    availability_status: str = "available",
) -> list[CalendarSlot]:
    """Split a time range into 30-minute slots with availability.

    When busy_periods is provided, slots overlapping busy periods are marked
    as unavailable with title="Busy". When provider state is unknown, every
    slot fails closed as unavailable.
    """
    start = parse_iso(start_iso)
    end = parse_iso(end_iso)

    slots: list[CalendarSlot] = []
    current = start
    while current + _SLOT_DURATION <= end:
        slot_end = current + _SLOT_DURATION

        if availability_status == "unknown":
            slots.append(
                CalendarSlot(
                    start=current.strftime("%Y-%m-%dT%H:%M:%SZ"),
                    end=slot_end.strftime("%Y-%m-%dT%H:%M:%SZ"),
                    available=False,
                    title="Availability unknown",
                    availability_status="unknown",
                )
            )
            current = slot_end
            continue

        is_busy = busy_periods is not None and _slot_overlaps_busy(current, slot_end, busy_periods)
        slot_status = "busy" if is_busy else "available"

        slots.append(
            CalendarSlot(
                start=current.strftime("%Y-%m-%dT%H:%M:%SZ"),
                end=slot_end.strftime("%Y-%m-%dT%H:%M:%SZ"),
                available=not is_busy,
                title="Busy" if is_busy else None,
                availability_status=slot_status,
            )
        )
        current = slot_end

    return slots


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------


@router.post("/check", response_model=CalendarCheckResponse)
async def check_calendar(
    request: CalendarCheckRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CalendarCheckResponse:
    """Check calendar availability on behalf of an AI agent.

    Uses real calendar API when a Google/Microsoft connection exists.
    Returns unknown/degraded availability on provider failure so callers cannot
    book from unverified free/busy data as if it were confirmed availability.
    """
    logger.info(
        "Agent calendar check: tenant=%s start=%s end=%s",
        tenant_id,
        request.start_time,
        request.end_time,
    )

    # Attempt to fetch real busy periods (Track 6)
    busy_periods: list[dict] | None = None
    availability_status = "available"
    degraded = False
    degradation_reason: str | None = None
    try:
        busy_periods = await get_tenant_calendar_busy_periods(tenant_id, request.start_time, request.end_time)
    except Exception:
        logger.warning(
            "Calendar API failed for tenant=%s, returning unknown availability",
            tenant_id,
            exc_info=True,
        )
        availability_status = "unknown"
        degraded = True
        degradation_reason = "calendar_provider_unavailable"

    slots = _generate_slots(request.start_time, request.end_time, busy_periods, availability_status=availability_status)
    if availability_status != "unknown" and any(not slot.available for slot in slots):
        availability_status = "busy"

    try:
        await MeteringService().meter(
            tenant_id=tenant_id,
            metric=UsageMetricType.CALENDAR_OPERATIONS,
            quantity=1,
            unit="operations",
            idempotency_key=f"agent_calendar:{tenant_id}:{request.start_time}:{request.end_time}",
            metadata={
                "slots_generated": len(slots),
                "has_real_busy_data": busy_periods is not None,
                "availability_status": availability_status,
                "degraded": degraded,
                "degradation_reason": degradation_reason,
            },
        )
    except Exception:
        logger.warning("Calendar metering failed for tenant=%s", tenant_id, exc_info=True)

    return CalendarCheckResponse(
        slots=slots,
        timezone="UTC",
        availability_status=availability_status,
        degraded=degraded,
        degradation_reason=degradation_reason,
    )


def _raise_calendar_error(exc: Exception) -> None:
    if isinstance(exc, CalendarPermissionError):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(exc)) from exc
    if isinstance(exc, CalendarProviderError):
        http_status = exc.status_code if 400 <= exc.status_code < 500 else status.HTTP_502_BAD_GATEWAY
        raise HTTPException(status_code=http_status, detail=exc.to_public_error()) from exc
    raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc


@router.post("/events")
async def create_calendar_event(
    request: CalendarEventWriteRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, object]:
    writer = get_calendar_writer()
    try:
        result = await writer.create_event(
            CalendarEventRequest(workspace_id=tenant_id, **request.model_dump())
        )
    except Exception as exc:
        _raise_calendar_error(exc)
    return result.model_dump(mode="json")


@router.patch("/events/{event_id}")
async def update_calendar_event(
    event_id: str,
    request: CalendarEventWriteRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, object]:
    writer = get_calendar_writer()
    try:
        result = await writer.update_event(
            CalendarEventRequest(workspace_id=tenant_id, **request.model_dump()),
            event_id=event_id,
        )
    except Exception as exc:
        _raise_calendar_error(exc)
    return result.model_dump(mode="json")


@router.post("/events/{event_id}/respond")
async def respond_to_calendar_invite(
    event_id: str,
    request: CalendarRespondRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, object]:
    writer = get_calendar_writer()
    try:
        result = await writer.respond_to_invite(
            workspace_id=tenant_id,
            provider=request.provider,
            actor_id=request.actor_id,
            on_behalf_of=request.on_behalf_of,
            event_id=event_id,
            response=request.response,
            idempotency_key=request.idempotency_key,
        )
    except Exception as exc:
        _raise_calendar_error(exc)
    return result.model_dump(mode="json")


@router.delete("/events/{event_id}")
async def cancel_calendar_event(
    event_id: str,
    request: CalendarCancelRequest = Body(...),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, object]:
    writer = get_calendar_writer()
    try:
        result = await writer.cancel_event(
            workspace_id=tenant_id,
            provider=request.provider,
            actor_id=request.actor_id,
            on_behalf_of=request.on_behalf_of,
            event_id=event_id,
            calendar_id=request.calendar_id,
            reason=request.reason,
            idempotency_key=request.idempotency_key,
        )
    except Exception as exc:
        _raise_calendar_error(exc)
    return result.model_dump(mode="json")


@router.post("/optimal-time")
async def find_calendar_optimal_time(
    request: CalendarFindOptimalTimeRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, object]:
    writer = get_calendar_writer()
    try:
        result = await writer.find_optimal_time(
            workspace_id=tenant_id,
            provider=request.provider,
            actor_id=request.actor_id,
            attendees=request.attendees,
            duration_minutes=request.duration_minutes,
            search_start=request.search_start,
            search_end=request.search_end,
        )
    except Exception as exc:
        _raise_calendar_error(exc)
    return result.model_dump(mode="json")
