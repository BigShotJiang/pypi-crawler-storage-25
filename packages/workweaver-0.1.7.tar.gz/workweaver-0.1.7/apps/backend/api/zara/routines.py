"""Routine-chat intent helpers for the Zara /chat endpoint."""

from __future__ import annotations

from typing import Any

from apps.backend.services.canonical_context import as_dict

from apps.backend.api.zara.validation import _token_set


def _detect_routine_action(message: str, schedule_service: Any) -> str | None:
    lowered = message.lower()
    if any(phrase in lowered for phrase in ("keep current approach", "leave it as is", "stop nudging", "don't change")):
        return "keep_current_approach"
    if any(word in lowered for word in ("restore", "revert", "undo", "reverse")):
        return "restore"
    if any(word in lowered for word in ("resume", "unpause", "restart")):
        return "resume"
    if any(word in lowered for word in ("pause", "hold", "snooze", "stop")):
        return "pause"
    if any(word in lowered for word in ("cancel", "delete", "remove")):
        return "cancel"
    parsed = schedule_service.parse_nl_schedule(message)
    if parsed and any(word in lowered for word in ("change", "update", "move", "set", "reschedule", "every", "daily", "weekly")):
        return "update_cadence"
    return None


def _is_routine_query(message: str) -> bool:
    lowered = message.lower()
    if "routine" not in lowered and "schedule" not in lowered:
        return False
    return any(
        phrase in lowered
        for phrase in (
            "what routines",
            "which routines",
            "show routines",
            "show schedules",
            "active routines",
            "failing routines",
            "degraded routines",
            "what is running",
        )
    )


def _resolve_routine_target(message: str, routines: list[Any]) -> Any | None:
    lowered = message.lower()
    if not routines:
        return None
    if len(routines) == 1:
        return routines[0]

    scored: list[tuple[int, Any]] = []
    for routine in routines:
        score = 0
        if routine.schedule_id and routine.schedule_id.lower() in lowered:
            score += 20
        display_name = str(routine.display_name or "").strip().lower()
        if display_name and display_name in lowered:
            score += 12
        group_label = str(routine.group_label or "").strip().lower()
        if group_label and group_label in lowered:
            score += 4
        target_ref = str(routine.target_ref or "").strip().lower()
        if target_ref and target_ref in lowered:
            score += 6
        overlap = len(_token_set(display_name).intersection(_token_set(lowered)))
        score += overlap
        if score > 0:
            scored.append((score, routine))

    if not scored:
        recommendations = [
            routine
            for routine in routines
            if isinstance(routine.optimization, dict) and routine.optimization.get("recommended_action")
        ]
        if len(recommendations) == 1:
            return recommendations[0]
        return None

    scored.sort(key=lambda item: item[0], reverse=True)
    if len(scored) > 1 and scored[0][0] == scored[1][0]:
        return None
    return scored[0][1]


def _has_explicit_routine_intent(message: str, routines: list[Any]) -> bool:
    lowered = message.lower()
    if any(keyword in lowered for keyword in ("routine", "routines", "schedule", "schedules", "cadence", "recurring")):
        return True

    for routine in routines:
        schedule_id = str(getattr(routine, "schedule_id", "") or "").strip().lower()
        if schedule_id and schedule_id in lowered:
            return True
        display_name = str(getattr(routine, "display_name", "") or "").strip().lower()
        if display_name and display_name in lowered:
            return True
        target_ref = str(getattr(routine, "target_ref", "") or "").strip().lower()
        if target_ref and target_ref in lowered:
            return True
    return False


def _render_routine_summary(audit: dict[str, Any], routines: list[Any]) -> str:
    summary = as_dict(audit.get("summary"))
    findings = list(audit.get("findings") or [])
    recommendations = list(audit.get("recommendations") or [])
    parts = [
        (
            f"{int(summary.get('total_routines') or len(routines))} routines total, "
            f"{int(summary.get('degraded') or 0)} degraded, "
            f"{int(summary.get('failing') or 0)} failing."
        )
    ]
    if findings:
        parts.append(
            "Attention: "
            + "; ".join(
                f"{item.get('display_name')} ({item.get('health_status')})"
                for item in findings[:3]
                if item.get("display_name")
            )
        )
    if recommendations:
        first = recommendations[0]
        recommended = as_dict(first.get("recommended_action"))
        if first.get("display_name") and recommended.get("action"):
            parts.append(
                f"Top recommendation: {first['display_name']} -> {recommended['action']}."
            )
    return " ".join(parts)
