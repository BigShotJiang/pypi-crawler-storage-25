"""Input validation, normalization, and identity helpers for the Zara API."""

from __future__ import annotations

import re
from typing import Any
from urllib.parse import urlparse

from fastapi import HTTPException
from ulid import monotonic as ulid_monotonic

_CONVERSATION_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9:_-]{2,127}$")
_AGENT_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9:_-]{1,127}$")
_WORKSPACE_RE = re.compile(r"^[a-z0-9][a-z0-9_-]{0,63}$")
_TRACE_ID_RE = re.compile(r"^[0-9A-HJKMNP-TV-Z]{26}$")


def _conversation_id(value: str | None) -> str:
    if value:
        candidate = str(value).strip()
        if not _CONVERSATION_ID_RE.fullmatch(candidate):
            raise HTTPException(
                status_code=422,
                detail="conversation_id must be 3-128 chars of letters, numbers, colon, underscore, or hyphen",
            )
        return candidate
    return f"conv_{ulid_monotonic.new().str.lower()}"


def _normalize_workspace(value: str | None) -> str:
    workspace = str(value or "").strip().lower()
    if not workspace or not _WORKSPACE_RE.fullmatch(workspace):
        return "home"
    return workspace


def _normalize_trace_ids(values: Any) -> list[str]:
    normalized: list[str] = []
    seen: set[str] = set()
    for value in list(values or []):
        trace_id = str(value or "").strip()
        if not trace_id or trace_id in seen:
            continue
        seen.add(trace_id)
        normalized.append(trace_id)
    return normalized


def _resolve_authenticated_user_id(candidate: Any, fallback: str | None) -> str:
    if isinstance(candidate, str) and candidate.strip():
        return candidate.strip()
    return str(fallback or "").strip()


def _sanitize_prompt_page_url(value: str | None) -> str:
    raw_value = str(value or "").strip()
    if not raw_value:
        return ""
    if raw_value.startswith("/"):
        return raw_value.split("?", 1)[0].split("#", 1)[0][:200]

    parsed = urlparse(raw_value)
    if parsed.scheme not in {"http", "https"}:
        return ""
    hostname = str(parsed.hostname or "").strip().lower()
    if not hostname or (
        hostname not in {"localhost", "127.0.0.1", "workweaver.ai", "www.workweaver.ai"}
        and not hostname.endswith(".workweaver.ai")
    ):
        return ""
    return (parsed.path or "/").split("?", 1)[0].split("#", 1)[0][:200]


def _validate_agent_id(agent_id: str | None) -> str | None:
    normalized = str(agent_id or "").strip()
    if not normalized:
        return None
    if not _AGENT_ID_RE.fullmatch(normalized):
        raise HTTPException(status_code=422, detail="Invalid agent_id format")
    return normalized


def _assert_visible_agent(tenant_id: str, agent_id: str | None) -> str | None:
    normalized_agent_id = _validate_agent_id(agent_id)
    if not normalized_agent_id:
        return None

    from apps.backend.services.agent_profile_store import get_agent_profile_store

    if get_agent_profile_store().get_agent(tenant_id, normalized_agent_id) is None:
        raise HTTPException(status_code=404, detail="Agent not found")
    return normalized_agent_id


def _token_set(value: str | None) -> set[str]:
    return {token for token in re.split(r"[^a-z0-9]+", str(value or "").lower()) if token}
