"""Chat-path helpers and route handlers for the Zara API.

These symbols are re-imported in ``__init__.py`` so that existing tests
patching ``apps.backend.api.zara.<symbol>`` continue to work unchanged.
"""

from __future__ import annotations

import logging
import re
import sys
from datetime import UTC, datetime
from typing import Any

from fastapi import HTTPException

from apps.backend.services.canonical_context import as_dict
from apps.backend.services.zara.exceptions import AwarenessUnavailableError
from apps.backend.services.zara.factory import (
    get_workspace_suggestion_labels,
    get_workspace_suggestions,
)
from apps.backend.services.zara.service import TaskContext, TaskExecutionResult

from apps.backend.api.zara.models import (
    ChatResponse,
    ChatRequest,
    CrossEntityQueryResponse,
    CrossEntityQueryRequest,
    DispatchTaskRequest,
    DispatchTaskResponse,
    ExplainRequest,
    ExplainResponse,
    RecallRequest,
    RecallResponse,
    SuggestionRequest,
    SuggestionResponse,
    SupportTicketRequest,
    SupportTicketResponse,
    ZaraActRequest,
    ZaraApproveRequest,
    ZaraApproveResponse,
    ZaraAskRequest,
)
from apps.backend.api.zara.routines import (
    _detect_routine_action as _detect_routine_action_impl,
    _has_explicit_routine_intent,
    _is_routine_query,
    _render_routine_summary,
    _resolve_routine_target,
)
from apps.backend.api.zara.validation import (
    _assert_visible_agent,
    _conversation_id,
    _normalize_workspace,
    _resolve_authenticated_user_id,
    _sanitize_prompt_page_url,
    _TRACE_ID_RE,
)
from apps.backend.api.zara.explain import (
    _build_explain_decision,
    _build_scope_boundaries,
    _decision_workitem_title,
    _expected_workitem_decision_ids,
    _explain_context_summary,
    _explain_coverage_summary,
    _explain_evidence_summary,
    _explain_summary,
    _matched_explain_decisions,
    _workitem_explain_context,
)

logger = logging.getLogger(__name__)


def _pkg():
    """Return the canonical package module for stub dispatch."""
    return sys.modules["apps.backend.api.zara"]


# ---------------------------------------------------------------------------
# Service-lookup stubs — delegate to the package-level definitions so that
# test patches applied to ``apps.backend.api.zara.<stub_name>`` are visible.
# ---------------------------------------------------------------------------

def _get_agent_dispatch_service():
    return _pkg()._get_agent_dispatch_service()


def _get_awareness_snapshot_store():
    return _pkg()._get_awareness_snapshot_store()


def _get_chat_executor(tenant_id: str, agent_id: str | None = None):
    return _pkg()._get_chat_executor(tenant_id, agent_id)


def _get_decision_service():
    return _pkg()._get_decision_service()


def _get_routine_service():
    return _pkg()._get_routine_service()


def _get_schedule_service():
    return _pkg()._get_schedule_service()


def _get_workitem_service():
    return _pkg()._get_workitem_service()


def _get_workitem_goal_store():
    return _pkg()._get_workitem_goal_store()


def _get_workitem_task_store():
    return _pkg()._get_workitem_task_store()


def get_zara_awareness_service():
    """Delegate to package-level binding for test-patch compatibility."""
    return _pkg().get_zara_awareness_service()


def get_zara_control_plane_service():
    """Delegate to package-level binding for test-patch compatibility."""
    return _pkg().get_zara_control_plane_service()


def get_zara_topic_thread_service():
    """Delegate to package-level binding for test-patch compatibility."""
    return _pkg().get_zara_topic_thread_service()


def get_sourced_recall_service():
    """Delegate to package-level binding for test-patch compatibility."""
    return _pkg().get_sourced_recall_service()


def build_budgeted_awareness_prompt_fragment(snapshot):
    """Delegate to package-level binding for test-patch compatibility."""
    return _pkg().build_budgeted_awareness_prompt_fragment(snapshot)


# ---------------------------------------------------------------------------
# Chat-path helpers
# ---------------------------------------------------------------------------


async def _check_planning_readiness(
    *,
    goal: str,
    awareness_snapshot_id: str | None,
    tenant_id: str,
    conversation_id: str = "",
) -> ChatResponse | None:
    """Run AwarenessPlanner.compose_plan as a readiness gate before execution.

    Returns a ``ChatResponse`` with the refusal reason if the planner
    refuses, or ``None`` if planning succeeds (or is skipped).
    Best-effort: failures are logged and silently skipped so the chat
    turn proceeds to normal execution.
    """
    if not awareness_snapshot_id:
        return None
    try:
        from apps.backend.services.execution.awareness_planner import (
            AwarenessPlanner,
            build_action_graph_from_registry,
        )
        from apps.backend.services.execution.plan_results import PlanRefused
        from apps.backend.services.zara.factory import CanonicalZaraLLMClient

        llm_client = CanonicalZaraLLMClient(tenant_id=tenant_id)

        async def _planner_llm(system_prompt: str, user_prompt: str) -> str:
            result = await llm_client.chat_completion(
                model="zara.planning",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
                temperature=0.3,
                max_tokens=512,
            )
            return result["choices"][0]["message"]["content"]

        action_graph = build_action_graph_from_registry()
        snapshot_store = _get_awareness_snapshot_store()
        planner = AwarenessPlanner(
            llm_fn=_planner_llm,
            action_graph=action_graph,
            awareness_snapshot_store=snapshot_store,
        )
        plan = await planner.compose_plan(
            goal,
            awareness_snapshot_id=awareness_snapshot_id,
            tenant_id=tenant_id,
        )
        if isinstance(plan, PlanRefused):
            logger.warning(
                "AwarenessPlanner refused plan for tenant=%s goal=%.80s: %s",
                tenant_id,
                goal,
                plan.reason,
            )
            return ChatResponse(
                message=(
                    f"I'm unable to complete that request right now because some "
                    f"required capabilities aren't fully available: {plan.reason}. "
                    f"Please try again in a few minutes or contact support."
                ),
                conversation_id=conversation_id,
                suggestions=[],
                requires_action=False,
                action_type=None,
                historical_recall=None,
                metadata={
                    "plan_refused": True,
                    "refusal_reason": plan.reason,
                    "blocking_capabilities": [
                        {"capability_id": cid, "state": cs.value}
                        for cid, cs in plan.blocking_capabilities
                    ],
                    "awareness_snapshot_id": awareness_snapshot_id,
                },
            )
    except Exception as exc:
        logger.warning(
            "AwarenessPlanner readiness check failed (best-effort skip): %s",
            exc,
            exc_info=True,
        )
    return None


def _build_recall_response_payload(
    result: dict[str, Any] | None,
    *,
    default_query: str,
    recall_service: Any,
) -> RecallResponse | None:
    if result is None:
        return None

    citations = list(result.get("citations") or [])
    return RecallResponse(
        query=str(result.get("query") or default_query),
        reason_code=str(result.get("reason_code") or "no_match"),
        retrieval_path=str(result.get("retrieval_path") or "unknown"),
        count=int(result.get("count") or len(citations)),
        citations=citations,
        sources=recall_service.render_sources(citations),
    )


def _topic_metadata_payload(binding: Any | None) -> dict[str, Any] | None:
    if binding is None:
        return None
    return {
        "thread_id": str(getattr(binding, "thread_id", "") or ""),
        "topic_key": str(getattr(binding, "topic_key", "") or ""),
        "topic_label": str(getattr(binding, "topic_label", "") or ""),
        "workmemory_session_id": str(getattr(binding, "workmemory_session_id", "") or ""),
        "continuity_match_count": len(list(getattr(binding, "continuity_segments", ()) or ())),
    }


_IDENTITY_CHAT_QUESTIONS = frozenset(
    {
        "who are you",
        "what are you",
        "who is zara",
        "what is zara",
        "what can you do",
        "what can you do for me",
        "what do you know about yourself",
        "is that all you know about yourself",
    }
)


def _is_identity_chat_question(message: str) -> bool:
    normalized = re.sub(r"\s+", " ", str(message or "").strip().lower())
    normalized = normalized.strip(" ?!.")
    if normalized in _IDENTITY_CHAT_QUESTIONS:
        return True
    identity_markers = (
        "who are you",
        "what are you",
        "who is zara",
        "what is zara",
        "what can you do",
        "about yourself",
        "introspect yourself",
        "intelligence provider",
        "inference provider",
        "model provider",
    )
    return any(marker in normalized for marker in identity_markers)


def _maybe_handle_identity_chat(
    *,
    workspace: str,
    message: str,
    conversation_id: str,
    voice_mode: bool,
) -> ChatResponse | None:
    if not _is_identity_chat_question(message):
        return None
    return ChatResponse(
        message=(
            "I'm Zara, Workweaver's AI operator for this tenant. I can answer questions, "
            "inspect workspace context, recall WorkMemory, and turn an instruction into "
            "governed work with approvals, tool calls, and Decision Trace proof. My "
            "inference route is tenant-configured by Workweaver admin policy; user-facing "
            "surfaces deliberately call it the tenant route instead of exposing a raw model id. "
            "When that route is degraded, I should still report my identity, capabilities, "
            "and next diagnostic commands instead of sending you to a generic home page."
        ),
        conversation_id=conversation_id,
        suggestions=get_workspace_suggestion_labels(workspace),
        requires_action=False,
        action_type=None,
        metadata={
            "identity_query": True,
            "workspace": workspace,
            "voice_mode": voice_mode,
        },
    )


def _detect_routine_action(message: str) -> str | None:
    """Wrap the routines helper so it resolves ``_get_schedule_service`` from
    this module's globals (preserving ``patch.object(zara, "_get_schedule_service")``).
    """
    return _detect_routine_action_impl(message, _get_schedule_service())


def _maybe_handle_routine_chat(
    *,
    tenant_id: str,
    authenticated_user_id: str,
    workspace: str,
    message: str,
    conversation_id: str,
) -> ChatResponse | None:
    action = _detect_routine_action(message)
    routine_query = _is_routine_query(message)
    routine_service = _get_routine_service()
    routines = routine_service.list_routines(tenant_id)
    audit = routine_service.build_audit_summary(tenant_id)

    if action is None and not routine_query:
        return None

    if action is not None and not _has_explicit_routine_intent(message, routines):
        return None

    if not routines:
        return ChatResponse(
            message="There are no active routines to inspect yet.",
            conversation_id=conversation_id,
            suggestions=get_workspace_suggestion_labels(workspace),
            requires_action=False,
            action_type=None,
            metadata={"routine_query": True, "routine_audit": audit},
        )

    if action is None:
        return ChatResponse(
            message=_render_routine_summary(audit, routines),
            conversation_id=conversation_id,
            suggestions=get_workspace_suggestion_labels(workspace),
            requires_action=False,
            action_type=None,
            metadata={"routine_query": True, "routine_audit": audit},
        )

    target = _resolve_routine_target(message, routines)
    if target is None:
        return ChatResponse(
            message="I found multiple routines. Name the routine you want to change, like 'pause Morning Brief' or 'resume Weekly Review'.",
            conversation_id=conversation_id,
            suggestions=get_workspace_suggestion_labels(workspace),
            requires_action=True,
            action_type="routine_clarification",
            metadata={"routine_query": True, "routine_audit": audit},
        )

    cron_expression = None
    if action == "update_cadence":
        cron_expression = _get_schedule_service().parse_nl_schedule(message)
        if not cron_expression:
            return ChatResponse(
                message="I understood that as a cadence change, but I couldn't parse the new schedule. Try phrasing it like 'every weekday at 9am' or 'daily at 6pm'.",
                conversation_id=conversation_id,
                suggestions=get_workspace_suggestion_labels(workspace),
                requires_action=True,
                action_type="routine_cadence_clarification",
                metadata={"routine_query": True, "routine_id": target.routine_id},
            )

    try:
        result = routine_service.mutate(
            tenant_id=tenant_id,
            schedule_id=target.routine_id,
            action=action,
            actor_id=authenticated_user_id,
            note=f"Zara chat: {message}",
            recommendation_signature=(
                as_dict(target.optimization).get("recommended_action", {}).get("signature")
                if action == "keep_current_approach"
                else None
            ),
            cron_expression=cron_expression,
        )
    except ValueError as exc:
        detail = str(exc)
        lowered = detail.lower()
        if "revision mismatch" in lowered:
            return ChatResponse(
                message="That routine changed just now. Refresh the schedule state and try again.",
                conversation_id=conversation_id,
                suggestions=get_workspace_suggestion_labels(workspace),
                requires_action=True,
                action_type="routine_conflict",
                metadata={"routine_query": True, "routine_id": target.routine_id, "error": detail},
            )
        if "not found" in lowered:
            return ChatResponse(
                message="I couldn't find that routine anymore. Refresh the schedule state and try again.",
                conversation_id=conversation_id,
                suggestions=get_workspace_suggestion_labels(workspace),
                requires_action=True,
                action_type="routine_not_found",
                metadata={"routine_query": True, "routine_id": target.routine_id, "error": detail},
            )
        raise
    routine_name = result.routine.display_name if result.routine is not None else target.display_name
    return ChatResponse(
        message=f"{result.message} {routine_name} is now {result.routine.status if result.routine is not None else 'updated'}.",
        conversation_id=conversation_id,
        suggestions=get_workspace_suggestion_labels(workspace),
        requires_action=False,
        action_type=None,
        metadata={
            "routine_query": True,
            "routine_action": action,
            "routine_id": target.routine_id,
            "routine_result": result.model_dump(mode="json"),
        },
    )


def _build_task_context(
    request: ChatRequest,
    *,
    conversation_id: str,
    awareness_snapshot: dict[str, Any] | None = None,
    awareness_snapshot_id: str | None = None,
    topic_binding: Any | None = None,
) -> TaskContext:
    workspace = _normalize_workspace(request.context.workspace)
    skill_id = f"{workspace}_{'voice_chat' if request.voice_mode else 'dashboard_chat'}"
    metadata: dict[str, Any] = {
        "workspace": workspace,
        "skill_id": skill_id,
        "page_url": _sanitize_prompt_page_url(request.context.page_url),
        "conversation_id": conversation_id,
        "voice_mode": request.voice_mode,
    }
    topic_payload = _topic_metadata_payload(topic_binding)
    if topic_payload is not None:
        metadata["thread_id"] = topic_payload["thread_id"]
        metadata["topic_thread_id"] = topic_payload["thread_id"]
        metadata["topic_key"] = topic_payload["topic_key"]
        metadata["topic_label"] = topic_payload["topic_label"]
        metadata["workmemory_session_id"] = topic_payload["workmemory_session_id"]
        continuity_prompt = str(getattr(topic_binding, "continuity_prompt", "") or "").strip()
        if continuity_prompt:
            metadata["topic_continuity"] = continuity_prompt
    if awareness_snapshot:
        metadata["awareness_context"] = build_budgeted_awareness_prompt_fragment(awareness_snapshot).text
    if awareness_snapshot_id:
        metadata["awareness_snapshot_id"] = awareness_snapshot_id
    return TaskContext(
        category=f"workspace_{workspace}",
        sub_task="voice_chat" if request.voice_mode else "dashboard_chat",
        capability_class=request.context.capability_class,
        metadata=metadata,
    )


def _derive_action(message: str) -> tuple[bool, str | None]:
    lowered = message.lower()
    if "inbox" in lowered:
        return True, "navigate_inbox"
    if "skill" in lowered and any(keyword in lowered for keyword in ("create", "new", "build")):
        return True, "create_skill"
    return False, None


def _render_chat_message(result: TaskExecutionResult) -> str:
    proof = result.proof_of_work or {}
    completed = str(proof.get("completed") or "").strip()
    if completed:
        return completed
    response_text = str(result.response_text or "").strip()
    if response_text:
        return response_text
    if result.degradation_reasons:
        return str(result.degradation_reasons[0].get("message") or "Zara could not complete this request.")
    return "Zara could not complete this request."


def _chat_metadata(
    request: ChatRequest,
    result: TaskExecutionResult,
    awareness_snapshot: dict[str, Any] | None = None,
    awareness_snapshot_id: str | None = None,
    control_plane: dict[str, Any] | None = None,
) -> dict[str, Any]:
    metadata = {
        "workspace": request.context.workspace,
        "voice_mode": request.voice_mode,
        "timestamp": datetime.now(UTC).isoformat(),
        "execution_mode": result.execution_mode,
        "status": result.status,
        "degraded": result.degraded,
        "trace_id": result.trace_id,
        "degradation_reasons": result.degradation_reasons,
    }
    if control_plane:
        metadata["control_plane"] = dict(control_plane)
    if awareness_snapshot:
        metadata["awareness"] = {
            "runtime_status": awareness_snapshot.get("runtime", {}).get("status"),
            "fallback_mode": awareness_snapshot.get("runtime", {}).get("fallback_mode"),
            "connected_integrations": awareness_snapshot.get("runtime", {}).get("connected_integrations", []),
            "capability_mode": awareness_snapshot.get("capabilities", {}).get("mode"),
            "known_limitations": awareness_snapshot.get("known_limitations", []),
        }
    if awareness_snapshot_id:
        metadata["awareness_snapshot_id"] = awareness_snapshot_id
    return metadata


def _stamp_awareness_on_trace(
    *,
    decision_service: Any,
    tenant_id: str,
    trace_id: str,
    awareness_snapshot_id: str | None,
    workspace: str,
) -> None:
    """Stamp awareness_snapshot_id on the Decision Trace for a chat turn.

    Fire-and-forget: capture failure is logged but never blocks the chat
    turn. The trace_id from the executor is the join key between the chat
    turn and the awareness snapshot that Zara saw.
    """
    skill_id = f"{workspace}_dashboard_chat"
    try:
        decision_service.capture_decision(
            tenant_id=tenant_id,
            skill_id=skill_id,
            decision_summary="Zara chat turn with awareness snapshot",
            decision_type="tool_call",
            outcome="success",
            trace_id=trace_id,
            awareness_snapshot_id=awareness_snapshot_id,
            capture_surface="zara_chat_handler",
            service_family="zara",
        )
    except Exception as exc:
        logger.warning(
            "Zara awareness snapshot trace stamp failed tenant=%s trace=%s: %s",
            tenant_id,
            trace_id,
            exc,
            exc_info=True,
        )


# ---------------------------------------------------------------------------
# Route handlers
# ---------------------------------------------------------------------------


async def get_awareness(
    workspace: str = "home",
    agent_id: str | None = None,
    tenant_id: str = "",
) -> Any:
    """Return Zara's current read-only control-plane awareness snapshot."""
    from apps.backend.api.zara.models import AwarenessResponse
    from apps.backend.api.zara.validation import _normalize_workspace as _nw, _assert_visible_agent as _ava

    workspace = _nw(workspace)
    agent_id = _ava(tenant_id, agent_id)
    awareness = await get_zara_awareness_service().describe(
        tenant_id=tenant_id,
        workspace=workspace,
        agent_id=agent_id,
    )
    return AwarenessResponse(**awareness)


async def chat(
    request: ChatRequest,
    tenant_id: str = "",
    authenticated_user_id: str = "",
) -> ChatResponse:
    """Send message to Zara using the canonical executor-of-record.

    Authenticated tenant context is required for this protected route.
    """
    agent_id = _assert_visible_agent(tenant_id, request.context.agent_id)
    workspace = _normalize_workspace(request.context.workspace)
    conversation_id = _conversation_id(request.conversation_id)
    resolved_user_id = _resolve_authenticated_user_id(authenticated_user_id, request.context.user_id)
    if request.context.user_id and resolved_user_id and request.context.user_id != resolved_user_id:
        raise HTTPException(
            status_code=403,
            detail="User ID mismatch between request body and authenticated identity",
        )
    identity_response = _maybe_handle_identity_chat(
        workspace=workspace,
        message=request.message,
        conversation_id=conversation_id,
        voice_mode=request.voice_mode,
    )
    if identity_response is not None:
        return identity_response
    executor = _get_chat_executor(tenant_id, agent_id=agent_id)
    control_plane_service = get_zara_control_plane_service()
    topic_thread_service = get_zara_topic_thread_service()
    principal_session = None
    topic_binding = None
    control_plane_metadata: dict[str, Any] = {"availability": "available", "active_background_missions": 0}
    try:
        principal_session = await control_plane_service.ensure_principal_session(
            tenant_id=tenant_id,
            conversation_id=conversation_id,
            workspace=workspace,
            user_id=resolved_user_id,
            agent_id=agent_id,
        )
    except Exception as exc:
        logger.warning(
            "Zara principal-session persistence unavailable for tenant=%s conversation=%s: %s",
            tenant_id,
            conversation_id,
            exc,
            exc_info=True,
        )
        control_plane_metadata = {
            "availability": "degraded",
            "principal_session_unavailable": True,
            "active_background_missions": 0,
        }
    else:
        control_plane_metadata = {
            **control_plane_metadata,
            "principal_session_id": principal_session.session_id,
        }

    logger.info(
        "Zara chat request tenant=%s workspace=%s message_length=%d voice_mode=%s",
        tenant_id,
        workspace,
        len(request.message),
        request.voice_mode,
    )

    # Org query intercept: if the message is an org-level question, route to
    # the org query service for cross-tool NL answers instead of the executor.
    try:
        from apps.backend.services.org_query_service import get_org_query_service

        org_svc = get_org_query_service()
        if org_svc.is_org_query(request.message):
            org_result = await org_svc.query(tenant_id, request.message)
            return ChatResponse(
                message=org_result.answer,
                conversation_id=conversation_id,
                suggestions=org_result.suggested_followups or get_workspace_suggestion_labels(workspace),
                requires_action=False,
                action_type=None,
                historical_recall=None,
                metadata={"org_query": True, "query_plan": org_result.query_plan},
            )
    except Exception as exc:
        logger.debug("Org query intercept skipped: %s", exc)

    try:
        routine_response = _maybe_handle_routine_chat(
            tenant_id=tenant_id,
            authenticated_user_id=resolved_user_id,
            workspace=workspace,
            message=request.message,
            conversation_id=conversation_id,
        )
        if routine_response is not None:
            return routine_response
    except Exception as exc:
        logger.debug("Routine chat intercept skipped: %s", exc, exc_info=True)

    awareness_snapshot: dict[str, Any] | None = None
    awareness_snapshot_id: str | None = None
    try:
        awareness_snapshot = await get_zara_awareness_service().describe(
            tenant_id=tenant_id,
            workspace=workspace,
            agent_id=agent_id,
        )
    except AwarenessUnavailableError as exc:
        logger.warning(
            "Zara awareness snapshot unavailable for tenant=%s: %s",
            tenant_id,
            exc,
            exc_info=True,
        )
        awareness_snapshot = None
    except Exception as exc:
        logger.warning("Zara awareness snapshot unavailable for tenant=%s: %s", tenant_id, exc, exc_info=True)

    # Persist the awareness snapshot so Decision Trace replay can reconstruct it.
    if awareness_snapshot is not None:
        try:
            from apps.backend.services.zara.awareness_snapshot import snapshot_from_describe_payload

            snap = snapshot_from_describe_payload(
                awareness_snapshot,
                tenant_id=tenant_id,
                workspace=workspace,
            )
            snapshot_store = _get_awareness_snapshot_store()
            snapshot_store.put(snap)
            awareness_snapshot_id = snap.snapshot_id
        except Exception as exc:
            logger.warning(
                "Zara awareness snapshot persistence failed tenant=%s: %s",
                tenant_id,
                exc,
                exc_info=True,
            )
            # Snapshot write failure is recorded but does not block the chat turn.

    try:
        topic_binding = await topic_thread_service.ensure_binding(
            tenant_id=tenant_id,
            conversation_id=conversation_id,
            workspace=workspace,
            user_id=resolved_user_id,
            agent_id=agent_id,
            principal_session_id=str(getattr(principal_session, "session_id", "") or "") or None,
            topic_id=request.context.topic_id,
            topic_label=request.context.topic_label,
            capability_class=request.context.capability_class,
            recall_query=request.message,
        )
    except Exception as exc:
        logger.warning(
            "Zara topic-thread binding unavailable tenant=%s conversation=%s: %s",
            tenant_id,
            conversation_id,
            exc,
            exc_info=True,
        )
        control_plane_metadata["topic_thread_unavailable"] = True

    async def _hydrate_active_background_truth(metadata: dict[str, Any]) -> dict[str, Any]:
        if principal_session is None:
            return metadata
        try:
            active_background_runs = await control_plane_service.active_background_runs(
                tenant_id,
                principal_session.session_id,
            )
        except Exception as exc:
            logger.warning(
                "Zara background-run discovery unavailable for tenant=%s conversation=%s: %s",
                tenant_id,
                conversation_id,
                exc,
                exc_info=True,
            )
            return {
                **metadata,
                "availability": "degraded",
                "principal_session_id": principal_session.session_id,
                "background_run_discovery_unavailable": True,
                "active_background_missions": 0,
            }

        hydrated_metadata = {
            **metadata,
            "principal_session_id": principal_session.session_id,
            "active_background_missions": len(active_background_runs),
        }
        if active_background_runs:
            hydrated_metadata["active_run_id"] = active_background_runs[0]["run_id"]
        else:
            hydrated_metadata.pop("active_run_id", None)
        return hydrated_metadata

    control_response = None
    if principal_session is not None:
        try:
            control_response = await control_plane_service.handle_chat_message(
                tenant_id=tenant_id,
                principal_session=principal_session,
                conversation_id=conversation_id,
                workspace=workspace,
                user_id=resolved_user_id,
                agent_id=agent_id,
                message=request.message,
            )
        except Exception as exc:
            logger.warning(
                "Zara control-plane handling unavailable for tenant=%s conversation=%s: %s",
                tenant_id,
                conversation_id,
                exc,
                exc_info=True,
            )
            control_plane_metadata = {
                **control_plane_metadata,
                "availability": "degraded",
                "principal_session_id": principal_session.session_id,
                "control_plane_handling_unavailable": True,
                "active_background_missions": 0,
            }
        else:
            control_plane_metadata = {
                **control_plane_metadata,
                "principal_session_id": principal_session.session_id,
            }
    if control_response is not None:
        control_plane_metadata = await _hydrate_active_background_truth(control_plane_metadata)
        control_response_metadata = dict(control_response.get("metadata") or {})
        metadata = {
            # Canonical request/system fields must win over adapter-provided metadata.
            **control_response_metadata,
            "workspace": request.context.workspace,
            "voice_mode": request.voice_mode,
            "timestamp": datetime.now(UTC).isoformat(),
            "control_plane": {
                **dict(control_plane_metadata),
                **dict(control_response_metadata.get("control_plane") or {}),
            },
        }
        if awareness_snapshot:
            metadata["awareness"] = {
                "runtime_status": awareness_snapshot.get("runtime", {}).get("status"),
                "fallback_mode": awareness_snapshot.get("runtime", {}).get("fallback_mode"),
                "connected_integrations": awareness_snapshot.get("runtime", {}).get("connected_integrations", []),
                "capability_mode": awareness_snapshot.get("capabilities", {}).get("mode"),
                "known_limitations": awareness_snapshot.get("known_limitations", []),
            }
        topic_payload = _topic_metadata_payload(topic_binding)
        if topic_payload is not None:
            metadata["topic_thread"] = topic_payload
            try:
                await topic_thread_service.record_turn(
                    tenant_id=tenant_id,
                    binding=topic_binding,
                    workspace=workspace,
                    user_message=request.message,
                    assistant_message=str(control_response.get("message") or "").strip(),
                )
            except Exception as exc:
                logger.warning(
                    "Zara topic-thread control response persistence failed tenant=%s conversation=%s: %s",
                    tenant_id,
                    conversation_id,
                    exc,
                    exc_info=True,
                )
        return ChatResponse(
            message=str(control_response.get("message") or "").strip(),
            conversation_id=conversation_id,
            suggestions=get_workspace_suggestion_labels(workspace),
            requires_action=False,
            action_type=None,
            historical_recall=None,
            metadata=metadata,
        )

    if principal_session is not None:
        control_plane_metadata = await _hydrate_active_background_truth(control_plane_metadata)

    # AwarenessPlanner readiness gate (#3784) — refuse if degraded capabilities
    # are required for the user's goal.
    plan_refused_response = await _check_planning_readiness(
        goal=request.message,
        awareness_snapshot_id=awareness_snapshot_id,
        tenant_id=tenant_id,
        conversation_id=conversation_id,
    )
    if plan_refused_response is not None:
        return plan_refused_response

    try:
        result = await executor.execute_task(
            task_description=request.message,
            task_context=_build_task_context(
                request,
                conversation_id=conversation_id,
                awareness_snapshot=awareness_snapshot,
                awareness_snapshot_id=awareness_snapshot_id,
                topic_binding=topic_binding,
            ),
            session_id=conversation_id,
            user_id=resolved_user_id,
        )
    except Exception as exc:
        logger.error("Canonical Zara executor failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Zara is temporarily unavailable. Please try again.")

    if result.status == "failed":
        rendered_message = _render_chat_message(result)
        metadata = _chat_metadata(
            request,
            result,
            awareness_snapshot=awareness_snapshot,
            awareness_snapshot_id=awareness_snapshot_id,
            control_plane=control_plane_metadata,
        )
        metadata["executor_failed"] = True
        return ChatResponse(
            message=rendered_message,
            conversation_id=conversation_id,
            suggestions=get_workspace_suggestion_labels(workspace),
            requires_action=True,
            action_type="zara_executor_recovery",
            historical_recall=None,
            metadata=metadata,
        )

    # Stamp awareness_snapshot_id on the Decision Trace so the replay endpoint
    # can reconstruct the awareness state Zara saw at this turn (#3783).
    _stamp_awareness_on_trace(
        decision_service=_get_decision_service(),
        tenant_id=tenant_id,
        trace_id=result.trace_id.removeprefix("TRACE#") if result.trace_id else "",
        awareness_snapshot_id=awareness_snapshot_id,
        workspace=workspace,
    )

    rendered_message = _render_chat_message(result)
    metadata = _chat_metadata(
        request,
        result,
        awareness_snapshot=awareness_snapshot,
        awareness_snapshot_id=awareness_snapshot_id,
        control_plane=control_plane_metadata,
    )
    topic_payload = _topic_metadata_payload(topic_binding)
    if topic_payload is not None:
        metadata["topic_thread"] = topic_payload
    recall_service = get_sourced_recall_service()
    sourced_recall = None
    should_cite = recall_service.should_cite(request.message)
    if should_cite:
        try:
            sourced_recall = await recall_service.recall_with_envelopes(
                tenant_id=tenant_id,
                query=request.message,
                limit=3,
            )
        except Exception as exc:
            logger.warning("Historical recall citation lookup failed: %s", exc, exc_info=True)
    historical_recall = _build_recall_response_payload(
        sourced_recall,
        default_query=request.message,
        recall_service=recall_service,
    )
    citations = list(historical_recall.citations) if historical_recall is not None else []
    if historical_recall and historical_recall.citations:
        rendered_message = f"{rendered_message}\n\nSources:\n{historical_recall.sources}"
        metadata["historical_recall"] = historical_recall.model_dump()
    if topic_binding is not None:
        try:
            await topic_thread_service.record_turn(
                tenant_id=tenant_id,
                binding=topic_binding,
                workspace=workspace,
                user_message=request.message,
                assistant_message=rendered_message,
                citations=citations,
            )
        except Exception as exc:
            logger.warning(
                "Zara topic-thread persistence failed tenant=%s conversation=%s: %s",
                tenant_id,
                conversation_id,
                exc,
                exc_info=True,
            )
    requires_action, action_type = _derive_action(request.message)
    return ChatResponse(
        message=rendered_message,
        conversation_id=conversation_id,
        suggestions=get_workspace_suggestion_labels(workspace),
        requires_action=requires_action,
        action_type=action_type,
        historical_recall=historical_recall,
        metadata=metadata,
    )


async def get_suggestions(
    request: SuggestionRequest,
    tenant_id: str = "",
) -> SuggestionResponse:
    """Get workspace-specific suggestions."""
    try:
        workspace = _normalize_workspace(request.context.workspace)
        suggestions = get_workspace_suggestions(workspace)
        logger.info("Retrieved %d suggestions for tenant=%s workspace=%s", len(suggestions), tenant_id, workspace)
        return SuggestionResponse(suggestions=suggestions)
    except Exception as exc:
        logger.error("Error getting Zara suggestions: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to get suggestions")


async def recall(
    request: RecallRequest,
    tenant_id: str = "",
    authenticated_user_id: str = "",
) -> RecallResponse:
    """Return cited historical recall from the canonical memory path."""
    recall_service = get_sourced_recall_service()
    try:
        result = await recall_service.recall_with_envelopes(
            tenant_id=tenant_id,
            query=request.query,
            limit=request.limit,
        )
    except Exception as exc:
        logger.error(
            "Zara cited recall failed tenant=%s user=%s: %s",
            tenant_id,
            authenticated_user_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(status_code=503, detail="Zara is temporarily unavailable.")

    return _build_recall_response_payload(
        result,
        default_query=request.query,
        recall_service=recall_service,
    ) or RecallResponse(
        query=request.query,
        reason_code="no_match",
        retrieval_path="unknown",
        count=0,
        citations=[],
        sources="",
    )


async def explain(
    request: ExplainRequest,
    tenant_id: str = "",
) -> ExplainResponse:
    """Return canonical decision-trace explainability for a WorkItem."""
    workitem_service = _get_workitem_service()
    goal_store = _get_workitem_goal_store()
    task_store = _get_workitem_task_store()

    try:
        item = workitem_service.get_work_item(
            tenant_id=tenant_id,
            item_id=request.workitem_id,
            goal_store=goal_store,
            task_store=task_store,
        )
    except Exception as exc:
        logger.error("Failed to load WorkItem for Zara explain tenant=%s: %s", tenant_id, exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to load WorkItem")
    if item is None:
        raise HTTPException(status_code=404, detail="WorkItem not found")

    try:
        evidence_bundle = workitem_service.get_work_item_detail_bundle(
            tenant_id=tenant_id,
            item_id=request.workitem_id,
            goal_store=goal_store,
            task_store=task_store,
        ) or {"overview": item}
    except Exception as exc:
        logger.error(
            "Failed to load WorkItem detail bundle for Zara explain tenant=%s workitem=%s: %s",
            tenant_id,
            request.workitem_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(status_code=500, detail="Failed to load WorkItem detail bundle")

    workitem_title = _decision_workitem_title(evidence_bundle) or str(item.get("title") or request.workitem_id).strip()
    expected_trace_ids = _expected_workitem_decision_ids(evidence_bundle)
    explain_context = _workitem_explain_context(item, evidence_bundle)

    decision_service = _get_decision_service()
    decision_lookup_limit = min(max(request.max_decisions * 25, 200), 500)
    tenant_decisions = list(
        decision_service.list_decisions(
            tenant_id=tenant_id,
            limit=decision_lookup_limit,
        )
    )
    indexed_decisions = {
        str(getattr(decision, "trace_id", "")).strip(): decision
        for decision in tenant_decisions
        if str(getattr(decision, "trace_id", "")).strip()
    }

    for trace_id in expected_trace_ids:
        if trace_id in indexed_decisions or not _TRACE_ID_RE.fullmatch(trace_id):
            continue
        decision = decision_service.get_decision(tenant_id=tenant_id, trace_id=trace_id)
        if decision is None:
            continue
        indexed_decisions[trace_id] = decision
        tenant_decisions.append(decision)

    matched_decisions, contextual_match_count = _matched_explain_decisions(
        tenant_decisions,
        expected_trace_ids=expected_trace_ids,
        explain_context=explain_context,
    )
    found_trace_ids = {
        str(getattr(decision, "trace_id", "")).strip()
        for decision in matched_decisions
        if str(getattr(decision, "trace_id", "")).strip()
    }
    missing_decision_ids = [trace_id for trace_id in expected_trace_ids if trace_id not in found_trace_ids]
    selected_decisions = matched_decisions[: request.max_decisions]

    return ExplainResponse(
        workitem_id=request.workitem_id,
        workitem_title=workitem_title,
        summary=_explain_summary(
            workitem_title=workitem_title,
            decision_count=len(selected_decisions),
            missing_decision_ids=missing_decision_ids,
        ),
        decision_count=len(selected_decisions),
        explainable=bool(selected_decisions),
        decisions=[
            _build_explain_decision(decision, include_trace_urls=request.include_trace_urls)
            for decision in selected_decisions
        ],
        missing_decision_ids=missing_decision_ids,
        context=_explain_context_summary(explain_context),
        evidence=_explain_evidence_summary(
            evidence_bundle,
            expected_trace_ids=expected_trace_ids,
            selected_decisions=selected_decisions,
        ),
        coverage=_explain_coverage_summary(
            expected_trace_ids=expected_trace_ids,
            missing_decision_ids=missing_decision_ids,
            contextual_match_count=contextual_match_count,
            matched_decisions=matched_decisions,
            selected_decisions=selected_decisions,
        ),
        scope_boundaries=_build_scope_boundaries(explain_context, workitem_title),
        metadata={
            "expected_decision_count": len(expected_trace_ids),
            "matched_context_decision_count": contextual_match_count,
            "decision_lookup_limit": decision_lookup_limit,
            "thread_id": str(explain_context.get("thread_id") or ""),
            "mission_refs": list(explain_context.get("mission_refs") or []),
            "workitem_ids": list(explain_context.get("workitem_ids") or []),
            "truncated_decision_count": max(len(matched_decisions) - len(selected_decisions), 0),
        },
    )


async def cross_entity_query(
    request: CrossEntityQueryRequest,
    tenant_id: str = "",
) -> CrossEntityQueryResponse:
    """Ask Zara what entities have been doing."""
    try:
        result = await get_zara_awareness_service().cross_entity_query(
            tenant_id=tenant_id,
            query=request.query,
        )
    except Exception as exc:
        logger.error("Zara cross-entity query failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Zara is temporarily unavailable.")
    return CrossEntityQueryResponse(**result)


async def dispatch_to_entity(
    request: DispatchTaskRequest,
    tenant_id: str = "",
) -> DispatchTaskResponse:
    """Route a task to the entity whose capabilities match the task type."""
    task_payload: dict[str, Any] = {
        "type": request.type,
        "description": request.description or "",
        "metadata": request.metadata,
    }
    try:
        result = await get_zara_awareness_service().dispatch_to_entity(
            tenant_id=tenant_id,
            task=task_payload,
        )
    except Exception as exc:
        logger.error("Zara dispatch failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Zara is temporarily unavailable.")
    return DispatchTaskResponse(**result)


async def create_support_ticket(
    request: SupportTicketRequest,
    tenant_id: str = "",
) -> SupportTicketResponse:
    """Auto-create a support ticket via Zara for troubleshooting."""
    issue = {"summary": request.summary, "steps": request.steps}
    try:
        result = await get_zara_awareness_service().create_support_ticket(
            tenant_id=tenant_id,
            issue=issue,
        )
    except Exception as exc:
        logger.error("Zara support ticket creation failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Zara is temporarily unavailable.")
    return SupportTicketResponse(**result)


async def health_check() -> dict[str, str]:
    """Health check for Zara chat service."""
    return {
        "status": "healthy",
        "service": "zara-chat",
        "timestamp": datetime.now(UTC).isoformat(),
    }


# ── Zara Verb Routes (Phase 1 — Shell Parity) ─────────────────────────────────
# Spec: "Zara can ask, act, explain, simulate, and approve."
# These thin wrappers collapse into the canonical /chat + judgment feed paths
# so that callers can declare intent explicitly without new surface areas.


async def zara_ask(
    request: ZaraAskRequest,
    tenant_id: str = "",
    authenticated_user_id: str = "",
) -> ChatResponse:
    """Explicit ask intent — delegates to /chat with intent=ask in metadata."""
    chat_request = ChatRequest(
        message=request.message,
        context=request.context,
        conversation_id=request.conversation_id,
        voice_mode=False,
    )
    response = await chat(chat_request, tenant_id=tenant_id, authenticated_user_id=authenticated_user_id)
    response.metadata["zara_intent"] = "ask"
    return response


async def zara_act(
    request: ZaraActRequest,
    tenant_id: str = "",
) -> DispatchTaskResponse:
    """Explicit act intent — delegates to /dispatch with intent=act in metadata."""
    dispatch_request = DispatchTaskRequest(
        type=request.type,
        description=request.description,
        metadata={**request.metadata, "zara_intent": "act"},
    )
    return await dispatch_to_entity(dispatch_request, tenant_id=tenant_id)


async def zara_approve(
    request: ZaraApproveRequest,
    tenant_id: str = "",
    authenticated_user_id: str = "",
) -> ZaraApproveResponse:
    """Approve a pending Inbox judgment via Zara."""
    from apps.backend.services.approval_gates import get_approval_gates
    from apps.backend.services.approval_service import ApprovalService
    from apps.backend.services.human_judgment_service import HumanJudgmentService

    def _build_judgment_svc() -> HumanJudgmentService:
        gates = get_approval_gates()
        return HumanJudgmentService(
            approval_service=ApprovalService(approval_gates=gates),
            approval_gates=gates,
        )

    # For approve_pattern actions the caller may supply only pattern_id (no request_id).
    # Fall back to pattern_id as the effective request identifier.
    effective_request_id = request.request_id or request.pattern_id or ""

    try:
        svc = _build_judgment_svc()
        await svc.approve_request(
            tenant_id=tenant_id,
            request_id=effective_request_id,
            actor_id=authenticated_user_id,
            reason=request.reason,
            modified_params=request.modified_params,
            source="zara_approve_verb",
        )
    except Exception as exc:
        logger.error(
            "Zara /approve failed for tenant=%s request_id=%s: %s",
            tenant_id,
            effective_request_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(status_code=503, detail="Approval could not be processed.")

    return ZaraApproveResponse(
        success=True,
        message="approved",
        request_id=effective_request_id,
        action=request.action,
    )
