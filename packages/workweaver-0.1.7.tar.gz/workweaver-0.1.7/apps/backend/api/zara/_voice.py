"""Voice session route handler for the Zara API.

Symbols are re-imported in ``__init__.py`` for backward compatibility.
"""

from __future__ import annotations

import logging
import os
from datetime import timedelta
from typing import Any

from fastapi import HTTPException

from apps.backend.api.zara.validation import _assert_visible_agent
from apps.backend.api.zara.models import VoiceSessionRequest, VoiceSessionResponse

logger = logging.getLogger(__name__)


async def create_voice_session_token(
    request: VoiceSessionRequest,
    tenant_id: str = "",
    authenticated_user_id: str = "",
) -> VoiceSessionResponse:
    """Create a voice session token for authenticated Zara voice access."""
    agent_id = _assert_visible_agent(tenant_id, request.agent_id)
    resolved_user_id = str(request.user_id or authenticated_user_id or "").strip()
    if str(request.user_id or "").strip() and request.user_id != authenticated_user_id:
        raise HTTPException(
            status_code=403,
            detail="User ID mismatch between request body and authenticated identity",
        )
    if not resolved_user_id:
        raise HTTPException(status_code=401, detail="Authentication required")

    try:
        livekit_url = os.getenv("LIVEKIT_URL", "wss://workweaver.livekit.cloud")
        livekit_api_key = os.getenv("LIVEKIT_API_KEY", "")
        livekit_api_secret = os.getenv("LIVEKIT_API_SECRET", "")

        if not livekit_api_key or not livekit_api_secret:
            raise HTTPException(
                status_code=503,
                detail="Voice service not configured (LIVEKIT_API_KEY/SECRET missing)",
            )

        import json as _json
        import time as _time

        room_name = f"zara-{tenant_id}-{resolved_user_id}-{int(_time.time())}"
        ttl = 3600

        from livekit.api import AccessToken, VideoGrants

        metadata_dict_voice: dict[str, Any] = {
            "tenant_id": tenant_id,
            "session_type": request.session_type,
        }
        # ZARA-5: Propagate agent_id into voice session metadata
        if agent_id:
            metadata_dict_voice["agent_id"] = agent_id
        metadata = _json.dumps(metadata_dict_voice)

        token = (
            AccessToken(livekit_api_key, livekit_api_secret)
            .with_identity(resolved_user_id)
            .with_grants(VideoGrants(room_join=True, room=room_name))
            .with_metadata(metadata)
            .with_ttl(timedelta(seconds=ttl))
        )

        logger.info("Voice session token created room=%s tenant=%s user=%s", room_name, tenant_id, resolved_user_id)
        return VoiceSessionResponse(
            session_token=token.to_jwt(),
            livekit_url=livekit_url,
            room_name=room_name,
            expires_in=ttl,
        )
    except HTTPException:
        raise
    except Exception as exc:
        logger.error("Failed to create Zara voice session token: %s", exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to create voice session")
