"""Canonical Zara API.

This surface is a thin adapter over ZaraTaskExecutor plus a read-only awareness
contract. Workspace-specific guidance still exists for UI suggestions, but task
execution truth lives in the executor rather than a separate Grok or
pattern-matching route.

The module is split into cohesive sub-modules (``models``, ``validation``,
``explain``, ``routines``) and per-flow internal modules (``_chat``, ``_plan``,
``_voice``, ``_meeting``, ``_shared``). This package root keeps the route
registrations plus the service-lookup stubs that tests patch
(``_get_chat_executor``, ``_get_routine_service``, etc.) at their canonical
import path ``apps.backend.api.zara``.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, Header, Query, Request, status
from fastapi.responses import StreamingResponse

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_id,
    require_admin_user_role,
)
from apps.backend.services.agent_dispatch import AgentDispatchService, get_agent_dispatch_service
from apps.backend.services.sourced_recall import get_sourced_recall_service  # noqa: F401
from apps.backend.services.zara.exceptions import AwarenessUnavailableError  # noqa: F401
from apps.backend.services.zara.factory import build_zara_task_executor  # noqa: F401
from apps.backend.services.zara.zara_awareness_service import (  # noqa: F401
    build_budgeted_awareness_prompt_fragment,
    get_zara_awareness_service,
)
from apps.backend.services.zara.zara_control_plane import get_zara_control_plane_service  # noqa: F401
from apps.backend.services.zara.zara_topic_threads import get_zara_topic_thread_service  # noqa: F401
from apps.backend.services.zara.context_loader import (  # noqa: F401
    PriorContextBundle,
    get_zara_prior_context_loader,
)
from apps.backend.services.zara.plan_store import (  # noqa: F401
    build_step_diff,
    default_loss_function,
    get_zara_plan_store,
)
from apps.backend.services.zara.execution_event_bus import (  # noqa: F401
    build_execution_event,
    format_sse,
    get_execution_event_bus,
)

# Sub-module imports used for route registration.
from apps.backend.api.zara import _chat as _chat_mod
from apps.backend.api.zara import _voice as _voice_mod
from apps.backend.api.zara import _plan as _plan_mod
from apps.backend.api.zara import _meeting as _meeting_mod

from apps.backend.api.zara.goal_intake import router as goal_intake_router

# Model re-exports — tests import these from the package root.
from apps.backend.api.zara.models import (  # noqa: F401
    AwarenessCapabilities,
    AwarenessCapabilityItem,
    AwarenessControlPlane,
    AwarenessProactive,
    AwarenessResponse,
    AwarenessRoutineItem,
    AwarenessRoutines,
    AwarenessRuntime,
    ZaraMeetingSpeakRequest,
    ZaraMeetingSpeakResponse,
    ChatContext,
    ChatMessage,
    ChatRequest,
    ChatResponse,
    CrossEntityQueryRequest,
    CrossEntityQueryResponse,
    DispatchTaskRequest,
    DispatchTaskResponse,
    ExecutePlanRequest,
    ExecutePlanResponse,
    ExecutionCancelResponse,
    ExecutionStatusResponse,
    ExecutionSteerRequest,
    ExecutionSteerResponse,
    ExplainContextSummary,
    ExplainCoverageSummary,
    ExplainDecision,
    ExplainEvidenceSummary,
    ExplainRequest,
    ExplainResponse,
    PlanConnectorInput,
    PlanDetailResponse,
    PlanListItemResponse,
    PlanListResponse,
    PlanMitigationRequest,
    PlanRequest,
    PlanResponse,
    PlanReviseRequest,
    PlanSteerRequest,
    PlanSteerResponse,
    PlanRevisionResponse,
    PlanSkillInput,
    PlanStepResponse,
    RecallRequest,
    RecallResponse,
    SkillCandidateResponse,
    SkillReuseSummary,
    StepResultResponse,
    SuggestionRequest,
    SuggestionResponse,
    SupportTicketRequest,
    SupportTicketResponse,
    VoiceSessionRequest,
    VoiceSessionResponse,
    ZaraActRequest,
    ZaraApproveRequest,
    ZaraApproveResponse,
    ZaraAskRequest,
)

# Validation re-exports — tests patch these at the package path.
from apps.backend.api.zara.validation import (  # noqa: F401
    _AGENT_ID_RE,
    _CONVERSATION_ID_RE,
    _TRACE_ID_RE,
    _WORKSPACE_RE,
    _assert_visible_agent,
    _conversation_id,
    _normalize_trace_ids,
    _normalize_workspace,
    _resolve_authenticated_user_id,
    _sanitize_prompt_page_url,
    _token_set,
    _validate_agent_id,
)

# Factory re-exports — tests import these from the package root.
from apps.backend.services.zara.factory import (  # noqa: F401
    get_workspace_suggestion_labels,
    get_workspace_suggestions,
)

# Goal intake — re-export IntakeCompiler for test patching.
from apps.backend.services.zara.zara_goal_intake import GoalMode, IntakeCompiler  # noqa: F401

# Chat helpers re-exported for test patching at apps.backend.api.zara.<symbol>.
from apps.backend.api.zara._chat import (  # noqa: F401
    _check_planning_readiness,
    _build_recall_response_payload,
    _topic_metadata_payload,
    _maybe_handle_identity_chat,
    _detect_routine_action,
    _maybe_handle_routine_chat,
    _build_task_context,
    _derive_action,
    _render_chat_message,
    _chat_metadata,
    _stamp_awareness_on_trace,
)

# Meeting re-export for test patching.
from apps.backend.api.zara._meeting import (  # noqa: F401
    _get_active_speak_executor,
)

# Plan helpers that tests import.
from apps.backend.api.zara._plan import (  # noqa: F401
    apply_plan_control,
    _run_plan_execution,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/zara", tags=["zara"])

# Mount the goal-intake sub-router. The sub-router's prefix ("/goal") is
# relative so the final URL becomes ``POST /api/v1/zara/goal/intake`` (#1064).
router.include_router(goal_intake_router)

# ---------------------------------------------------------------------------
# Service-lookup stubs — tests patch these via ``patch("apps.backend.api.zara.X")``
# so they must remain importable attributes on this module.
# These are defined HERE (not in _shared.py) so that tests patching
# apps.backend.api.zara._get_routine_service etc. affect the symbols that
# the sub-module functions reference at call time.
# ---------------------------------------------------------------------------

_EXECUTOR_CACHE: dict[str, Any] = {}


def _get_workitem_service():
    from apps.backend.services.execution.workitem_service import get_workitem_service
    return get_workitem_service()


def _get_workitem_goal_store():
    from apps.backend.api.goals import _get_goal_store as _factory
    return _factory()


def _get_workitem_task_store():
    from apps.backend.services.task_store import get_task_store
    return get_task_store()


def _get_decision_service():
    from apps.backend.services.context.decision_event_capture import DecisionEventCaptureService
    return DecisionEventCaptureService()


def _get_chat_executor(tenant_id: str, agent_id: str | None = None):
    cache_key = f"{tenant_id}:{agent_id or ''}"
    if cache_key not in _EXECUTOR_CACHE:
        _EXECUTOR_CACHE[cache_key] = build_zara_task_executor(
            tenant_id=tenant_id,
            agent_id=agent_id,
        )
    return _EXECUTOR_CACHE[cache_key]


def _get_routine_service():
    from apps.backend.services.scheduling.routines import get_routine_service
    return get_routine_service()


def _get_schedule_service():
    from apps.backend.services.scheduling.service import get_schedule_service
    return get_schedule_service()


def _get_agent_dispatch_service() -> AgentDispatchService:
    """Stub for tests to patch: ``apps.backend.api.zara._get_agent_dispatch_service``."""
    return get_agent_dispatch_service()


_awareness_snapshot_store: Any | None = None


def _get_awareness_snapshot_store():
    """Module-level singleton so the same store is used for put and get."""
    global _awareness_snapshot_store
    if _awareness_snapshot_store is None:
        from apps.backend.providers.portable_store import create_portable_store
        from apps.backend.workmemory.services.awareness_snapshot_store import AwarenessSnapshotStore
        _awareness_snapshot_store = AwarenessSnapshotStore(
            create_portable_store("zara-awareness-snapshots"),
        )
    return _awareness_snapshot_store


# ---------------------------------------------------------------------------
# Route registrations — thin wrappers that inject FastAPI dependencies and
# delegate to the flow-specific handler functions in the sub-modules.
# ---------------------------------------------------------------------------


@router.get("/awareness", response_model=AwarenessResponse)
async def get_awareness(
    workspace: str = Query("home", description="Current workspace"),
    agent_id: str | None = Query(None, description="AI-func-Ops agent ID for agent-specific posture"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> AwarenessResponse:
    return await _chat_mod.get_awareness(
        workspace=workspace, agent_id=agent_id, tenant_id=tenant_id,
    )


@router.post("/chat", response_model=ChatResponse)
async def chat(
    request: ChatRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
) -> ChatResponse:
    return await _chat_mod.chat(
        request=request, tenant_id=tenant_id, authenticated_user_id=authenticated_user_id,
    )


@router.post("/suggestions", response_model=SuggestionResponse)
async def get_suggestions(
    request: SuggestionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SuggestionResponse:
    return await _chat_mod.get_suggestions(request=request, tenant_id=tenant_id)


@router.post("/recall", response_model=RecallResponse)
async def recall(
    request: RecallRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
) -> RecallResponse:
    return await _chat_mod.recall(
        request=request, tenant_id=tenant_id, authenticated_user_id=authenticated_user_id,
    )


@router.post("/explain", response_model=ExplainResponse)
async def explain(
    request: ExplainRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ExplainResponse:
    return await _chat_mod.explain(request=request, tenant_id=tenant_id)


@router.post("/voice/session-token", response_model=VoiceSessionResponse)
async def create_voice_session_token(
    request: VoiceSessionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
) -> VoiceSessionResponse:
    return await _voice_mod.create_voice_session_token(
        request=request, tenant_id=tenant_id, authenticated_user_id=authenticated_user_id,
    )


@router.get("/health")
async def health_check() -> dict[str, str]:
    return await _chat_mod.health_check()


@router.post("/query", response_model=CrossEntityQueryResponse)
async def cross_entity_query(
    request: CrossEntityQueryRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CrossEntityQueryResponse:
    return await _chat_mod.cross_entity_query(request=request, tenant_id=tenant_id)


@router.post("/dispatch", response_model=DispatchTaskResponse)
async def dispatch_to_entity(
    request: DispatchTaskRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> DispatchTaskResponse:
    return await _chat_mod.dispatch_to_entity(request=request, tenant_id=tenant_id)


@router.post("/support-ticket", response_model=SupportTicketResponse)
async def create_support_ticket(
    request: SupportTicketRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SupportTicketResponse:
    return await _chat_mod.create_support_ticket(request=request, tenant_id=tenant_id)


@router.post("/ask", response_model=ChatResponse)
async def zara_ask(
    request: ZaraAskRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
) -> ChatResponse:
    return await _chat_mod.zara_ask(
        request=request, tenant_id=tenant_id, authenticated_user_id=authenticated_user_id,
    )


@router.post("/act", response_model=DispatchTaskResponse)
async def zara_act(
    request: ZaraActRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> DispatchTaskResponse:
    return await _chat_mod.zara_act(request=request, tenant_id=tenant_id)


@router.post("/approve", response_model=ZaraApproveResponse)
async def zara_approve(
    request: ZaraApproveRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
) -> ZaraApproveResponse:
    return await _chat_mod.zara_approve(
        request=request, tenant_id=tenant_id, authenticated_user_id=authenticated_user_id,
    )


# ---------------------------------------------------------------------------
# Plan routes
# ---------------------------------------------------------------------------


@router.post("/plan", response_model=PlanResponse)
async def generate_plan(
    request: PlanRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PlanResponse:
    return await _plan_mod.generate_plan(request=request, tenant_id=tenant_id)


@router.post("/plan/{plan_id}/revise", response_model=PlanResponse)
async def revise_plan(
    plan_id: str,
    request: PlanReviseRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PlanResponse:
    return await _plan_mod.revise_plan(plan_id=plan_id, request=request, tenant_id=tenant_id)


@router.post("/plans/{plan_id}/steer", response_model=PlanSteerResponse)
async def steer_plan(
    plan_id: str,
    request: PlanSteerRequest,
    http_request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
) -> PlanSteerResponse:
    return await _plan_mod.steer_plan(
        plan_id=plan_id,
        request=request,
        http_request=http_request,
        tenant_id=tenant_id,
        authenticated_user_id=authenticated_user_id,
    )


@router.post("/plan/{plan_id}/mitigations/{mitigation_id}", response_model=PlanResponse)
async def decide_plan_mitigation(
    plan_id: str,
    mitigation_id: str,
    request: PlanMitigationRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PlanResponse:
    return await _plan_mod.decide_plan_mitigation(
        plan_id=plan_id, mitigation_id=mitigation_id, request=request, tenant_id=tenant_id,
    )


@router.get("/plans", response_model=PlanListResponse)
async def list_plans(
    status_filter: str | None = Query(default=None, alias="status"),
    limit: int = Query(default=50, ge=1, le=100),
    cursor: str | None = Query(default=None),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PlanListResponse:
    return await _plan_mod.list_plans(
        status_filter=status_filter, limit=limit, cursor=cursor, tenant_id=tenant_id,
    )


@router.get("/plans/{plan_id}", response_model=PlanDetailResponse)
async def get_plan_detail(
    plan_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PlanDetailResponse:
    return await _plan_mod.get_plan_detail(plan_id=plan_id, tenant_id=tenant_id)


@router.post("/execute-plan", response_model=ExecutePlanResponse, status_code=status.HTTP_202_ACCEPTED)
async def execute_plan(
    request: ExecutePlanRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ExecutePlanResponse:
    return await _plan_mod.execute_plan(request=request, tenant_id=tenant_id)


@router.get("/executions/{execution_id}", response_model=ExecutionStatusResponse)
async def get_execution_status(
    execution_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ExecutionStatusResponse:
    return await _plan_mod.get_execution_status(execution_id=execution_id, tenant_id=tenant_id)


@router.get("/executions/{execution_id}/stream")
async def stream_execution(
    execution_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    last_event_id: str | None = Header(default=None, alias="Last-Event-ID"),
) -> StreamingResponse:
    return await _plan_mod.stream_execution(
        execution_id=execution_id, tenant_id=tenant_id, last_event_id=last_event_id,
    )


@router.post("/executions/{execution_id}/cancel", response_model=ExecutionCancelResponse)
async def cancel_execution(
    execution_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ExecutionCancelResponse:
    return await _plan_mod.cancel_execution(execution_id=execution_id, tenant_id=tenant_id)


@router.post("/executions/{execution_id}/steer", response_model=ExecutionSteerResponse)
async def steer_execution(
    execution_id: str,
    request: ExecutionSteerRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ExecutionSteerResponse:
    return await _plan_mod.steer_execution(execution_id=execution_id, request=request, tenant_id=tenant_id)


# ---------------------------------------------------------------------------
# Active Speak (Route C) — Recall.ai live SDK integration (#2717)
# ---------------------------------------------------------------------------


@router.post(
    "/meetings/{meeting_id}/speak",
    response_model=ZaraMeetingSpeakResponse,
    status_code=status.HTTP_200_OK,
)
async def zara_meeting_speak(
    meeting_id: str,
    request: ZaraMeetingSpeakRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
    _admin_role: Any = Depends(require_admin_user_role),
) -> ZaraMeetingSpeakResponse:
    return await _meeting_mod.zara_meeting_speak(
        meeting_id=meeting_id,
        request=request,
        tenant_id=tenant_id,
        authenticated_user_id=authenticated_user_id,
        _admin_role=_admin_role,
    )


__all__ = [
    "router",
    # models
    "AwarenessCapabilities",
    "AwarenessCapabilityItem",
    "AwarenessControlPlane",
    "AwarenessProactive",
    "AwarenessResponse",
    "AwarenessRoutineItem",
    "AwarenessRoutines",
    "AwarenessRuntime",
    "ChatContext",
    "ChatMessage",
    "ChatRequest",
    "ChatResponse",
    "CrossEntityQueryRequest",
    "CrossEntityQueryResponse",
    "DispatchTaskRequest",
    "DispatchTaskResponse",
    "ExecutePlanRequest",
    "ExecutePlanResponse",
    "ExecutionCancelResponse",
    "ExecutionStatusResponse",
    "ExecutionSteerRequest",
    "ExecutionSteerResponse",
    "ExplainContextSummary",
    "ExplainCoverageSummary",
    "ExplainDecision",
    "ExplainEvidenceSummary",
    "ExplainRequest",
    "ExplainResponse",
    "PlanConnectorInput",
    "PlanDetailResponse",
    "PlanListItemResponse",
    "PlanListResponse",
    "PlanRequest",
    "PlanResponse",
    "PlanReviseRequest",
    "PlanRevisionResponse",
    "PlanSkillInput",
    "PlanStepResponse",
    "RecallRequest",
    "RecallResponse",
    "SkillCandidateResponse",
    "StepResultResponse",
    "SuggestionRequest",
    "SuggestionResponse",
    "SupportTicketRequest",
    "SupportTicketResponse",
    "VoiceSessionRequest",
    "VoiceSessionResponse",
    "ZaraActRequest",
    "ZaraApproveRequest",
    "ZaraApproveResponse",
    "ZaraAskRequest",
    "ZaraMeetingSpeakRequest",
    "ZaraMeetingSpeakResponse",
]
