"""Per-capability provision / rotate / revoke endpoints for Zara identities.

Twelve endpoints in total — three lifecycle actions across four capability
surfaces — all under ``/api/v1/zara/identity/{capability}``. Every response
matches the canonical envelope:

    {"capability", "status", "provisioned_at", "evidence_id", "detail"}

so the admin UI can render lifecycle events uniformly. Each call emits a
DecisionEventCaptureService trace and is gated by
:attr:`AdminPermission.IDENTITY_WRITE`.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, EmailStr, Field

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_email,
    require_admin_user_role,
)
from apps.backend.services.admin.admin_permission import AdminPermission
from apps.backend.services.zara.identity_write_service import (
    SUPPORTED_CAPABILITIES,
    DkimDnsProvisioningError,
    TwilioPhoneProvisioningError,
    WalletPolicyUpdateError,
    ZaraIdentityWriteService,
    get_zara_identity_write_service,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/zara/identity", tags=["zara-identity-write"])


def _get_decision_capture() -> Any:
    from apps.backend.services.context.decision_event_capture import (
        DecisionEventCaptureService,
    )

    return DecisionEventCaptureService()


# ---------------------------------------------------------------------------
# Pydantic payloads
# ---------------------------------------------------------------------------


class EmailProvisionPayload(BaseModel):
    alias_local_part: str = Field(..., min_length=1, max_length=64)
    domain: EmailStr | str = Field(..., min_length=4, max_length=128)


class CalendarProvisionPayload(BaseModel):
    provider: str = Field("google", min_length=1, max_length=32)
    scopes: list[str] | None = Field(
        None,
        description=(
            "Optional OAuth scopes override. Defaults to the provider's "
            "canonical calendar scopes (see SUPPORTED_CALENDAR_PROVIDERS)."
        ),
    )


class PhoneProvisionPayload(BaseModel):
    """Phone-provision payload.

    Issue #3625: per-tenant Twilio credentials. ``twilio_account_sid`` is
    the public account id; ``twilio_auth_token_secret_ref`` is a reference
    into the tenant-owned secrets manager (e.g. AWS SSM parameter path,
    Vault path, env var name). **Raw tokens are rejected** — the secret
    ref is a path, not the secret material itself.
    """

    twilio_account_sid: str = Field(..., min_length=2, max_length=64)
    twilio_auth_token_secret_ref: str = Field(..., min_length=1, max_length=256)
    area_code: str | None = Field(None, min_length=2, max_length=8)


class WalletProvisionPayload(BaseModel):
    enabled: bool = Field(True, description="Set false to skip flipping the wallet policy.")


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _emit_trace(
    *,
    decision_capture: Any,
    tenant_id: str,
    capability: str,
    action: str,
    actor: str,
    evidence_id: str,
    detail: dict[str, Any],
) -> None:
    try:
        decision_capture.capture_decision(
            tenant_id=tenant_id,
            skill_id=f"zara.identity.{capability}.{action}",
            decision_summary=f"{action.capitalize()} {capability} identity",
            decision_type=f"zara_identity_{action}",
            outcome=action,
            entity_ids=[capability],
            rationale=f"Admin {actor} requested {action} on {capability}",
            context_data={
                "capability": capability,
                "action": action,
                "evidence_id": evidence_id,
                **detail,
            },
            capture_surface="rest",
            service_family="zara_identity",
        )
    except Exception:  # noqa: BLE001
        logger.warning(
            "zara_identity_write.trace_failed tenant=%s capability=%s action=%s",
            tenant_id,
            capability,
            action,
            exc_info=True,
        )


def _resolve_actor(actor_email: str | None) -> str:
    return actor_email or "admin@workweaver.ai"


# ---------------------------------------------------------------------------
# Email
# ---------------------------------------------------------------------------


@router.post("/email/provision")
async def provision_email(
    body: EmailProvisionPayload,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.IDENTITY_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_email: str = Depends(get_verified_user_email),
    service: ZaraIdentityWriteService = Depends(get_zara_identity_write_service),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    del admin_role
    actor = _resolve_actor(actor_email)
    try:
        result = service.provision_email(
            tenant_id=tenant_id,
            alias_local_part=body.alias_local_part,
            domain=str(body.domain),
            actor=actor,
        )
    except DkimDnsProvisioningError as exc:
        logger.warning(
            "zara_identity_write.email_provision_failed tenant=%s",
            tenant_id,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail={
                "error_code": "dns_provisioning_failed",
                "message": exc.message,
            },
        ) from exc
    _emit_trace(
        decision_capture=decision_capture,
        tenant_id=tenant_id,
        capability="email",
        action="provision",
        actor=actor,
        evidence_id=result.evidence_id,
        detail=result.detail,
    )
    return result.to_dict()


@router.post("/email/rotate")
async def rotate_email(
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.IDENTITY_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_email: str = Depends(get_verified_user_email),
    service: ZaraIdentityWriteService = Depends(get_zara_identity_write_service),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    del admin_role
    actor = _resolve_actor(actor_email)
    result = service.rotate_email(tenant_id=tenant_id, actor=actor)
    _emit_trace(
        decision_capture=decision_capture,
        tenant_id=tenant_id,
        capability="email",
        action="rotate",
        actor=actor,
        evidence_id=result.evidence_id,
        detail=result.detail,
    )
    return result.to_dict()


@router.post("/email/revoke")
async def revoke_email(
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.IDENTITY_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_email: str = Depends(get_verified_user_email),
    service: ZaraIdentityWriteService = Depends(get_zara_identity_write_service),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    del admin_role
    actor = _resolve_actor(actor_email)
    result = service.revoke_email(tenant_id=tenant_id, actor=actor)
    _emit_trace(
        decision_capture=decision_capture,
        tenant_id=tenant_id,
        capability="email",
        action="revoke",
        actor=actor,
        evidence_id=result.evidence_id,
        detail=result.detail,
    )
    return result.to_dict()


# ---------------------------------------------------------------------------
# Calendar
# ---------------------------------------------------------------------------


@router.post("/calendar/provision")
async def provision_calendar(
    body: CalendarProvisionPayload,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.IDENTITY_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_email: str = Depends(get_verified_user_email),
    service: ZaraIdentityWriteService = Depends(get_zara_identity_write_service),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    del admin_role
    actor = _resolve_actor(actor_email)
    try:
        result = service.provision_calendar(
            tenant_id=tenant_id,
            provider=body.provider,
            actor=actor,
            scopes=body.scopes,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "invalid_calendar_provider", "message": str(exc)},
        ) from exc
    _emit_trace(
        decision_capture=decision_capture,
        tenant_id=tenant_id,
        capability="calendar",
        action="provision",
        actor=actor,
        evidence_id=result.evidence_id,
        detail=result.detail,
    )
    return result.to_dict()


@router.post("/calendar/rotate")
async def rotate_calendar(
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.IDENTITY_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_email: str = Depends(get_verified_user_email),
    service: ZaraIdentityWriteService = Depends(get_zara_identity_write_service),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    del admin_role
    actor = _resolve_actor(actor_email)
    result = service.rotate_calendar(tenant_id=tenant_id, actor=actor)
    _emit_trace(
        decision_capture=decision_capture,
        tenant_id=tenant_id,
        capability="calendar",
        action="rotate",
        actor=actor,
        evidence_id=result.evidence_id,
        detail=result.detail,
    )
    return result.to_dict()


@router.post("/calendar/revoke")
async def revoke_calendar(
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.IDENTITY_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_email: str = Depends(get_verified_user_email),
    service: ZaraIdentityWriteService = Depends(get_zara_identity_write_service),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    del admin_role
    actor = _resolve_actor(actor_email)
    result = service.revoke_calendar(tenant_id=tenant_id, actor=actor)
    _emit_trace(
        decision_capture=decision_capture,
        tenant_id=tenant_id,
        capability="calendar",
        action="revoke",
        actor=actor,
        evidence_id=result.evidence_id,
        detail=result.detail,
    )
    return result.to_dict()


# ---------------------------------------------------------------------------
# Phone
# ---------------------------------------------------------------------------


def _reject_raw_twilio_token(value: str) -> None:
    """Raw Twilio auth tokens are 32-char hex strings — never accept them.

    The phone-provision contract is "send a *reference* into the tenant's
    secrets manager, not the token itself" (issue #3625). We belt-and-brace
    the API boundary by rejecting anything that looks like a raw token.
    """

    cleaned = (value or "").strip()
    if len(cleaned) == 32 and all(ch in "0123456789abcdefABCDEF" for ch in cleaned):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={
                "error": "raw_twilio_token_not_allowed",
                "message": (
                    "twilio_auth_token_secret_ref must reference a secret "
                    "in the tenant's secrets manager, not the raw token."
                ),
            },
        )


@router.post("/phone/provision")
async def provision_phone(
    body: PhoneProvisionPayload,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.IDENTITY_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_email: str = Depends(get_verified_user_email),
    service: ZaraIdentityWriteService = Depends(get_zara_identity_write_service),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    del admin_role
    actor = _resolve_actor(actor_email)
    _reject_raw_twilio_token(body.twilio_auth_token_secret_ref)
    try:
        result = service.provision_phone(
            tenant_id=tenant_id,
            twilio_account_sid=body.twilio_account_sid,
            twilio_auth_token_secret_ref=body.twilio_auth_token_secret_ref,
            area_code=body.area_code,
            actor=actor,
        )
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"error": "invalid_twilio_credentials", "message": str(exc)},
        ) from exc
    except TwilioPhoneProvisioningError as exc:
        logger.warning(
            "zara_identity_write.phone_provision_failed tenant=%s code=%s",
            tenant_id,
            exc.twilio_code,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_502_BAD_GATEWAY,
            detail={
                "error_code": "twilio_api_error",
                "message": exc.message,
                "twilio_code": exc.twilio_code,
                "twilio_status": exc.twilio_status,
            },
        ) from exc
    _emit_trace(
        decision_capture=decision_capture,
        tenant_id=tenant_id,
        capability="phone",
        action="provision",
        actor=actor,
        evidence_id=result.evidence_id,
        detail=result.detail,
    )
    return result.to_dict()


@router.get("/phone/credentials-config")
async def get_phone_credentials_config(
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.IDENTITY_READ)),
    tenant_id: str = Depends(get_verified_tenant_id),
    service: ZaraIdentityWriteService = Depends(get_zara_identity_write_service),
) -> dict[str, Any]:
    """Return the public summary of the tenant's Twilio credentials.

    Issue #3625: contains the SID + secret reference (a *path* into the
    secrets manager) but **never** the raw token. Admin UIs use this to
    confirm the tenant has wired their own Twilio account before
    surfacing phone-provision controls.
    """

    del admin_role
    return service.get_phone_credentials_config(tenant_id=tenant_id)


@router.post("/phone/rotate")
async def rotate_phone(
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.IDENTITY_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_email: str = Depends(get_verified_user_email),
    service: ZaraIdentityWriteService = Depends(get_zara_identity_write_service),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    del admin_role
    actor = _resolve_actor(actor_email)
    result = service.rotate_phone(tenant_id=tenant_id, actor=actor)
    _emit_trace(
        decision_capture=decision_capture,
        tenant_id=tenant_id,
        capability="phone",
        action="rotate",
        actor=actor,
        evidence_id=result.evidence_id,
        detail=result.detail,
    )
    return result.to_dict()


@router.post("/phone/revoke")
async def revoke_phone(
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.IDENTITY_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_email: str = Depends(get_verified_user_email),
    service: ZaraIdentityWriteService = Depends(get_zara_identity_write_service),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    del admin_role
    actor = _resolve_actor(actor_email)
    result = service.revoke_phone(tenant_id=tenant_id, actor=actor)
    _emit_trace(
        decision_capture=decision_capture,
        tenant_id=tenant_id,
        capability="phone",
        action="revoke",
        actor=actor,
        evidence_id=result.evidence_id,
        detail=result.detail,
    )
    return result.to_dict()


# ---------------------------------------------------------------------------
# Wallet
# ---------------------------------------------------------------------------


@router.post("/wallet/provision")
async def provision_wallet(
    body: WalletProvisionPayload,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.IDENTITY_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_email: str = Depends(get_verified_user_email),
    service: ZaraIdentityWriteService = Depends(get_zara_identity_write_service),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    """Provision the wallet capability.

    Codex review #3621 F11 — wallet policy persistence failures surface
    as 503 instead of being swallowed.

    Codex review #3621 F12 — ``body.enabled`` is now honored. Sending
    ``{"enabled": false}`` records the capability lifecycle row for audit
    purposes without flipping the wallet policy enabled flag.
    """

    del admin_role
    actor = _resolve_actor(actor_email)
    try:
        result = service.provision_wallet(
            tenant_id=tenant_id, actor=actor, enabled=body.enabled
        )
    except WalletPolicyUpdateError as exc:
        logger.warning(
            "zara_identity_write.wallet_provision_failed tenant=%s",
            tenant_id,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error_code": "wallet_policy_update_failed",
                "message": str(exc),
            },
        ) from exc
    _emit_trace(
        decision_capture=decision_capture,
        tenant_id=tenant_id,
        capability="wallet",
        action="provision",
        actor=actor,
        evidence_id=result.evidence_id,
        detail=result.detail,
    )
    return result.to_dict()


@router.post("/wallet/rotate")
async def rotate_wallet(
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.IDENTITY_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_email: str = Depends(get_verified_user_email),
    service: ZaraIdentityWriteService = Depends(get_zara_identity_write_service),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    del admin_role
    actor = _resolve_actor(actor_email)
    result = service.rotate_wallet(tenant_id=tenant_id, actor=actor)
    _emit_trace(
        decision_capture=decision_capture,
        tenant_id=tenant_id,
        capability="wallet",
        action="rotate",
        actor=actor,
        evidence_id=result.evidence_id,
        detail=result.detail,
    )
    return result.to_dict()


@router.post("/wallet/revoke")
async def revoke_wallet(
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.IDENTITY_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_email: str = Depends(get_verified_user_email),
    service: ZaraIdentityWriteService = Depends(get_zara_identity_write_service),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    del admin_role
    actor = _resolve_actor(actor_email)
    result = service.revoke_wallet(tenant_id=tenant_id, actor=actor)
    _emit_trace(
        decision_capture=decision_capture,
        tenant_id=tenant_id,
        capability="wallet",
        action="revoke",
        actor=actor,
        evidence_id=result.evidence_id,
        detail=result.detail,
    )
    return result.to_dict()


@router.get("/capabilities")
async def list_supported_capabilities(
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.IDENTITY_READ)),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return the canonical list of capabilities the write surface supports."""

    del admin_role
    if tenant_id is None:  # pragma: no cover — get_verified_tenant_id never returns None
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Authentication required"
        )
    return {"capabilities": list(SUPPORTED_CAPABILITIES)}
