"""Explainability helpers for the Zara /explain endpoint."""

from __future__ import annotations

from typing import Any

from apps.backend.services.canonical_context import (
    as_dict,
    extract_canonical_context,
    first_non_empty,
    json_loads,
    merge_unique_texts,
)

from apps.backend.api.zara.models import (
    ExplainContextSummary,
    ExplainCoverageSummary,
    ExplainDecision,
    ExplainEvidenceSummary,
)
from apps.backend.api.zara.validation import _normalize_trace_ids


def _decision_governed_by(decision: Any, context_data: dict[str, Any]) -> list[str]:
    """Return the governance identifiers that gated a decision.

    Combines (in priority order) the decision's direct ``policy_id``, any
    exception grant reference, policy ids carried through the governed-mutation
    context, and guard names surfaced by the runtime.  De-duplicated while
    preserving first-seen order so Explain consumers can cite the exact rails
    that applied without reshaping the payload.
    """
    governed: list[str] = []
    seen: set[str] = set()

    def _push(value: Any) -> None:
        text = str(value or "").strip()
        if not text or text in seen:
            return
        seen.add(text)
        governed.append(text)

    _push(getattr(decision, "policy_id", None))

    exception_granted = getattr(decision, "exception_granted", None)
    if isinstance(exception_granted, dict):
        _push(exception_granted.get("exception_id"))
        _push(exception_granted.get("policy_id"))
    elif isinstance(exception_granted, str) and exception_granted.strip():
        _push(f"exception:{exception_granted.strip()}")

    governed_mutation = context_data.get("governed_mutation") if isinstance(context_data, dict) else None
    if isinstance(governed_mutation, dict):
        _push(governed_mutation.get("policy_id"))
        for guard in list(governed_mutation.get("guards") or []):
            _push(guard)
        for policy in list(governed_mutation.get("policies_applied") or []):
            _push(policy)

    guards = context_data.get("guards") if isinstance(context_data, dict) else None
    if isinstance(guards, list):
        for guard in guards:
            _push(guard)

    return governed


def _decision_correlation_id(context_data: dict[str, Any]) -> str | None:
    if not isinstance(context_data, dict):
        return None
    correlation = context_data.get("correlation_id")
    if correlation:
        text = str(correlation).strip()
        if text:
            return text
    governed_mutation = context_data.get("governed_mutation")
    if isinstance(governed_mutation, dict):
        candidate = governed_mutation.get("correlation_id") or governed_mutation.get("run_id")
        if candidate:
            text = str(candidate).strip()
            if text:
                return text
    return None


def _build_explain_decision(decision: Any, *, include_trace_urls: bool) -> ExplainDecision:
    alternatives = list(decision.alternatives_considered or [])
    conditions = list(decision.decision_conditions or [])
    trace_url = None
    trace_id = str(getattr(decision, "trace_id", "")).strip()
    if include_trace_urls and trace_id:
        trace_url = f"/api/v1/evidence/decisions/{trace_id}"
    context_data = _decision_context_data(decision)
    return ExplainDecision(
        trace_id=trace_id,
        skill_id=str(getattr(decision, "skill_id", "")).strip(),
        decision_summary=str(getattr(decision, "decision_summary", "")).strip(),
        decision_type=str(getattr(decision, "decision_type", "")).strip(),
        outcome=str(getattr(decision, "outcome", "")).strip(),
        rationale=getattr(decision, "rationale", None),
        alternatives_considered=alternatives,
        decision_conditions=conditions,
        sop_deviation=getattr(decision, "sop_deviation", None),
        quality_score=float(getattr(decision, "quality_score", 0.0) or 0.0),
        created_at=str(getattr(decision, "created_at", "")),
        entity_ids=list(getattr(decision, "entity_ids") or []),
        trace_url=trace_url,
        correlation_id=_decision_correlation_id(context_data),
        governed_by=_decision_governed_by(decision, context_data),
    )


def _build_scope_boundaries(
    explain_context: dict[str, list[str] | str], workitem_title: str
) -> list[str]:
    """Render human-readable scope boundaries for Explain consumers.

    Produces a compact list like ``["workitem: work-123", "thread: thread-7",
    "mission: goal-123", "entities: 2"]`` so UAT ("why did X happen?") can cite
    the exact blast radius without the caller recomputing it from ``context``.
    """
    lines: list[str] = []
    title = str(workitem_title or "").strip()
    if title:
        lines.append(f"workitem_title: {title}")
    workitem_ids = [str(v) for v in (explain_context.get("workitem_ids") or []) if str(v).strip()]
    if workitem_ids:
        lines.append(f"workitem_ids: {', '.join(workitem_ids)}")
    thread_ids = [str(v) for v in (explain_context.get("thread_ids") or []) if str(v).strip()]
    primary_thread = str(explain_context.get("thread_id") or "").strip()
    if primary_thread and primary_thread not in thread_ids:
        thread_ids = [primary_thread, *thread_ids]
    if thread_ids:
        lines.append(f"thread_ids: {', '.join(thread_ids)}")
    mission_refs = [str(v) for v in (explain_context.get("mission_refs") or []) if str(v).strip()]
    if mission_refs:
        lines.append(f"mission_refs: {', '.join(mission_refs)}")
    entity_ids = [str(v) for v in (explain_context.get("entity_ids") or []) if str(v).strip()]
    if entity_ids:
        lines.append(f"entity_ids: {', '.join(entity_ids)}")
    return lines


def _decision_workitem_title(evidence_bundle: dict[str, Any] | None) -> str:
    overview = evidence_bundle.get("overview") if isinstance(evidence_bundle, dict) else None
    if isinstance(overview, dict):
        title = str(overview.get("title") or "").strip()
        if title:
            return title
    return ""


def _decision_context_data(decision: Any) -> dict[str, Any]:
    if hasattr(decision, "get_context_data"):
        try:
            payload = decision.get_context_data()
        except Exception:
            payload = None
        if isinstance(payload, dict):
            return dict(payload)
    raw_context = getattr(decision, "context_data", None)
    if isinstance(raw_context, dict):
        return dict(raw_context)
    return json_loads(raw_context)


def _workitem_explain_context(
    item: dict[str, Any], evidence_bundle: dict[str, Any] | None
) -> dict[str, list[str] | str]:
    bundle = as_dict(evidence_bundle)
    overview = as_dict(bundle.get("overview")) or as_dict(item)
    conversation = as_dict(bundle.get("conversation"))
    item_context = extract_canonical_context(overview, nested_context_keys=("metadata",), include_metadata=True)
    conversation_context = extract_canonical_context(
        conversation, nested_context_keys=("metadata",), include_metadata=True
    )
    source_kind = str(overview.get("source_kind") or "").strip().lower()
    workitem_id_sources: list[list[Any]] = [
        [overview.get("id")],
        [item_context.get("workitem_id")],
        [conversation_context.get("workitem_id")],
    ]
    if source_kind == "goal":
        workitem_id_sources.extend(
            [
                [overview.get("goal_id")],
                [item_context.get("goal_id")],
            ]
        )
    elif source_kind == "task":
        workitem_id_sources.extend(
            [
                [overview.get("task_id")],
                [item_context.get("task_id")],
            ]
        )
    workitem_ids = merge_unique_texts(*workitem_id_sources)
    mission_refs = merge_unique_texts(
        [item_context.get("mission_ref")],
        [conversation_context.get("mission_ref")],
        [overview.get("goal_id")],
        [overview.get("parent_item_id")],
        [overview.get("id")] if str(overview.get("source_kind") or "").strip().lower() == "goal" else [],
    )
    thread_ids = merge_unique_texts(
        [conversation.get("thread_id")],
        [item_context.get("thread_id")],
        [conversation_context.get("thread_id")],
    )
    entity_ids = merge_unique_texts(
        [item_context.get("entity_id")],
        [conversation_context.get("entity_id")],
    )

    return {
        "thread_id": first_non_empty(conversation.get("thread_id"), item_context.get("thread_id")),
        "workitem_ids": workitem_ids,
        "mission_refs": mission_refs,
        "thread_ids": thread_ids,
        "entity_ids": entity_ids,
    }


def _expected_workitem_decision_ids(evidence_bundle: dict[str, Any] | None) -> list[str]:
    evidence = as_dict(as_dict(evidence_bundle).get("evidence"))
    return _normalize_trace_ids(evidence.get("decision_event_ids"))


def _decision_trace_ids(decisions: list[Any]) -> list[str]:
    trace_ids: list[str] = []
    seen: set[str] = set()
    for decision in list(decisions or []):
        trace_id = str(getattr(decision, "trace_id", "") or "").strip()
        if not trace_id or trace_id in seen:
            continue
        seen.add(trace_id)
        trace_ids.append(trace_id)
    return trace_ids


def _explain_context_summary(explain_context: dict[str, Any]) -> ExplainContextSummary:
    return ExplainContextSummary(
        thread_id=str(explain_context.get("thread_id") or ""),
        workitem_ids=merge_unique_texts(explain_context.get("workitem_ids")),
        mission_refs=merge_unique_texts(explain_context.get("mission_refs")),
        entity_ids=merge_unique_texts(explain_context.get("entity_ids")),
    )


def _explain_evidence_summary(
    evidence_bundle: dict[str, Any] | None,
    *,
    expected_trace_ids: list[str],
    selected_decisions: list[Any],
) -> ExplainEvidenceSummary:
    evidence = as_dict(as_dict(evidence_bundle).get("evidence"))
    summary = as_dict(evidence.get("summary"))
    returned_trace_ids = _decision_trace_ids(selected_decisions)
    source_event_ids = merge_unique_texts(
        evidence.get("source_event_ids"),
        [as_dict(entry).get("source_event_id") for entry in list(evidence.get("trail") or []) if isinstance(entry, dict)],
        *[
            _decision_context_data(decision).get("source_event_ids")
            for decision in selected_decisions
        ],
        *[
            as_dict(_decision_context_data(decision).get("governed_mutation")).get("source_event_ids")
            for decision in selected_decisions
        ],
    )
    recording_refs = [entry for entry in list(evidence.get("recording_refs") or []) if isinstance(entry, dict)]
    return ExplainEvidenceSummary(
        decision_event_ids=merge_unique_texts(expected_trace_ids, returned_trace_ids),
        source_event_ids=source_event_ids,
        attachment_count=int(summary.get("attachment_count") or 0),
        evidence_count=int(summary.get("evidence_count") or 0),
        recording_refs=recording_refs,
    )


def _explain_coverage_summary(
    *,
    expected_trace_ids: list[str],
    missing_decision_ids: list[str],
    contextual_match_count: int,
    matched_decisions: list[Any],
    selected_decisions: list[Any],
) -> ExplainCoverageSummary:
    evidence_trace_ids = merge_unique_texts(expected_trace_ids, _decision_trace_ids(selected_decisions))
    governed_mutation_count = 0
    for decision in selected_decisions:
        context_data = _decision_context_data(decision)
        governed_mutation = as_dict(context_data.get("governed_mutation"))
        if governed_mutation or first_non_empty(context_data.get("correlation_id")):
            governed_mutation_count += 1
    return ExplainCoverageSummary(
        expected_decision_count=len(expected_trace_ids),
        evidence_decision_event_count=len(evidence_trace_ids),
        matched_context_decision_count=contextual_match_count,
        truncated_decision_count=max(len(matched_decisions) - len(selected_decisions), 0),
        missing_decision_ids=list(missing_decision_ids),
        governed_mutation_count=governed_mutation_count,
    )


def _decision_match_score(
    decision: Any,
    *,
    expected_trace_ids: set[str],
    workitem_ids: set[str],
    mission_refs: set[str],
    thread_ids: set[str],
    entity_ids: set[str],
) -> int:
    trace_id = str(getattr(decision, "trace_id", "") or "").strip()
    if trace_id in expected_trace_ids:
        return 100

    context = extract_canonical_context(
        _decision_context_data(decision),
        nested_context_keys=("metadata",),
        include_metadata=True,
    )
    score = 0
    if any(
        candidate and candidate in workitem_ids
        for candidate in (context.get("workitem_id"), context.get("goal_id"), context.get("task_id"))
    ):
        score += 4
    if context.get("thread_id") and context.get("thread_id") in thread_ids:
        score += 3
    if context.get("mission_ref") and context.get("mission_ref") in mission_refs:
        score += 2
    decision_entity_ids = {
        str(value or "").strip()
        for value in list(getattr(decision, "entity_ids", []) or [])
        if str(value or "").strip()
    }
    if (context.get("entity_id") and context.get("entity_id") in entity_ids) or decision_entity_ids.intersection(
        entity_ids
    ):
        score += 1
    return score


def _matched_explain_decisions(
    decisions: list[Any],
    *,
    expected_trace_ids: list[str],
    explain_context: dict[str, list[str] | str],
) -> tuple[list[Any], int]:
    expected_trace_id_set = set(expected_trace_ids)
    workitem_ids = set(list(explain_context.get("workitem_ids") or []))
    mission_refs = set(list(explain_context.get("mission_refs") or []))
    thread_ids = set(list(explain_context.get("thread_ids") or []))
    entity_ids = set(list(explain_context.get("entity_ids") or []))

    exact_matches: list[tuple[int, Any]] = []
    contextual_matches: list[tuple[int, int, Any]] = []
    contextual_count = 0
    seen_trace_ids: set[str] = set()

    for index, decision in enumerate(list(decisions or [])):
        trace_id = str(getattr(decision, "trace_id", "") or "").strip()
        if not trace_id or trace_id in seen_trace_ids:
            continue
        score = _decision_match_score(
            decision,
            expected_trace_ids=expected_trace_id_set,
            workitem_ids=workitem_ids,
            mission_refs=mission_refs,
            thread_ids=thread_ids,
            entity_ids=entity_ids,
        )
        if score <= 0:
            continue
        seen_trace_ids.add(trace_id)
        if trace_id in expected_trace_id_set:
            exact_matches.append((index, decision))
            continue
        contextual_count += 1
        contextual_matches.append((-score, index, decision))

    exact_matches.sort(key=lambda entry: entry[0])
    contextual_matches.sort()
    ordered = [decision for _index, decision in exact_matches]
    ordered.extend(decision for _score, _index, decision in contextual_matches)
    return ordered, contextual_count


def _explain_summary(*, workitem_title: str, decision_count: int, missing_decision_ids: list[str]) -> str:
    if decision_count <= 0:
        if missing_decision_ids:
            return (
                f"No decision traces could be loaded for {workitem_title}, "
                f"and {len(missing_decision_ids)} expected trace(s) are missing from the canonical store."
            )
        return f"No linked decision traces were found for {workitem_title}."
    if missing_decision_ids:
        return (
            f"Found {decision_count} decision trace(s) for {workitem_title}; "
            f"{len(missing_decision_ids)} expected trace(s) are still missing from the canonical decision store."
        )
    return f"Found {decision_count} decision trace(s) for {workitem_title}."
