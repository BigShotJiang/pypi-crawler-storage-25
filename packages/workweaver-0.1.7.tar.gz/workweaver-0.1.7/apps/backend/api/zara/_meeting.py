"""Meeting Active Speak route handler for the Zara API.

Symbols are re-imported in ``__init__.py`` for backward compatibility.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import HTTPException, status

from apps.backend.api.zara.models import (
    ZaraMeetingSpeakRequest,
    ZaraMeetingSpeakResponse,
)

logger = logging.getLogger(__name__)


def _get_active_speak_executor():
    """Service-lookup stub. Tests patch this to inject a fake executor.

    Production wiring is intentionally minimal: we lazy-import the executor
    factory so the heavy adapter dependencies don't load on cold start of
    callers that never touch the speak surface.
    """
    from apps.backend.services.meeting.active_speak_executor_factory import (
        get_active_speak_executor,
    )

    return get_active_speak_executor()


async def zara_meeting_speak(
    meeting_id: str,
    request: ZaraMeetingSpeakRequest,
    tenant_id: str = "",
    authenticated_user_id: str = "",
    _admin_role: Any = None,
) -> ZaraMeetingSpeakResponse:
    """Issue an Active Speak (Route C) action through Recall.ai (#2717)."""
    from apps.backend.services.meeting.active_speak_executor import (
        ActiveSpeakConsentRequiredError,
        ActiveSpeakFeatureDisabledError,
        ActiveSpeakProviderError,
    )

    workspace_id = tenant_id

    executor = _get_active_speak_executor()
    try:
        attempt = await executor.speak(
            tenant_id=tenant_id,
            workspace_id=workspace_id,
            meeting_id=meeting_id,
            text=request.text,
            voice_persona_id=request.voice_persona_id,
            trigger_reason=request.trigger_reason,
            actor_member_id=authenticated_user_id,
        )
    except ActiveSpeakFeatureDisabledError as exc:
        logger.info(
            "zara.meeting_speak.feature_disabled tenant=%s meeting=%s "
            "user=%s",
            tenant_id,
            meeting_id,
            authenticated_user_id,
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "feature_disabled": True,
                "reason": "recall_speak_disabled",
                "message": str(exc),
            },
        ) from exc
    except ActiveSpeakConsentRequiredError as exc:
        logger.info(
            "zara.meeting_speak.consent_gate tenant=%s meeting=%s "
            "user=%s reason=%s",
            tenant_id,
            meeting_id,
            authenticated_user_id,
            exc.reason,
        )
        raise HTTPException(
            status_code=status.HTTP_412_PRECONDITION_FAILED,
            detail={
                "consent_required": True,
                "reason": exc.reason,
                "message": str(exc),
            },
        ) from exc
    except ActiveSpeakProviderError as exc:
        logger.warning(
            "zara.meeting_speak.provider_error tenant=%s meeting=%s "
            "reason=%s status=%s",
            tenant_id,
            meeting_id,
            exc.reason,
            exc.http_status,
        )
        raise HTTPException(
            status_code=exc.http_status,
            detail={
                "provider_error": True,
                "reason": exc.reason,
                "message": str(exc),
            },
        ) from exc
    except ValueError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail={"reason": "invalid_request", "message": str(exc)},
        ) from exc

    return ZaraMeetingSpeakResponse(
        recall_call_id=attempt.recall_call_id,
        status=attempt.status,
        consent_id=attempt.consent_id,
        decision_trace_id=attempt.decision_trace_id,
        meeting_id=attempt.meeting_id,
        workspace_id=attempt.workspace_id,
    )
