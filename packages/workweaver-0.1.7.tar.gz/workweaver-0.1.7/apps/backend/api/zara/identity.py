"""Zara identity aggregator REST surface.

Exposes ``GET /api/v1/zara/identity`` so the admin UI can render the
identity panel (email, calendar, phone, wallet, memory) with one round-trip
instead of five. The endpoint delegates to ZaraIdentityAggregator which
keeps a short-TTL cache to make the polling cheap.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    require_admin_user_role,
)
from apps.backend.services.admin.admin_permission import AdminPermission
from apps.backend.services.zara.identity_aggregator import (
    ZaraIdentityAggregator,
    get_zara_identity_aggregator,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/zara/identity", tags=["zara-identity"])


@router.get("")
async def get_zara_identity(
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.IDENTITY_READ)),
    tenant_id: str = Depends(get_verified_tenant_id),
    aggregator: ZaraIdentityAggregator = Depends(get_zara_identity_aggregator),
) -> dict[str, Any]:
    """Return the aggregated identity snapshot for the caller's tenant."""

    del admin_role
    return aggregator.snapshot(tenant_id=tenant_id).as_dict()
