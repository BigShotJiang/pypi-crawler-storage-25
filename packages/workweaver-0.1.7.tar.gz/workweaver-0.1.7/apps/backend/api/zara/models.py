"""Pydantic request/response models for the Zara API."""

from __future__ import annotations

from datetime import UTC, datetime
from typing import Any, Literal

from pydantic import BaseModel, Field


class ChatContext(BaseModel):
    """Context information for chat request."""

    workspace: str = Field(description="Current workspace (home, inbox, skills, etc.)")
    tenant_id: str | None = Field(None, description="Tenant ID for multi-tenancy")
    user_id: str | None = Field(None, description="User ID")
    page_url: str | None = Field(None, description="Current page URL")
    agent_id: str | None = Field(None, description="AI agent ID for per-agent context")
    capability_class: str | None = Field(
        None,
        description="Optional explicit capability class when the caller already knows the workload contract",
    )
    topic_id: str | None = Field(None, description="Optional caller-controlled topic identity")
    topic_label: str | None = Field(None, description="Optional user-visible topic label")


class ChatMessage(BaseModel):
    """Single message in conversation."""

    role: str = Field(description="Message role (user, assistant, system)")
    content: str = Field(description="Message content")
    timestamp: datetime | None = Field(default_factory=lambda: datetime.now(UTC))


class ChatRequest(BaseModel):
    """Request to send message to Zara."""

    message: str = Field(..., description="User message", min_length=1, max_length=5000)
    context: ChatContext = Field(..., description="Conversation context")
    conversation_id: str | None = Field(None, description="Conversation ID for history")
    voice_mode: bool = Field(False, description="Whether voice mode is active")


class ChatResponse(BaseModel):
    """Response from Zara."""

    message: str = Field(..., description="Assistant response")
    conversation_id: str = Field(..., description="Conversation ID")
    suggestions: list[str] | None = Field(None, description="Suggested follow-up actions")
    requires_action: bool = Field(False, description="Whether user action is required")
    action_type: str | None = Field(None, description="Type of action required")
    historical_recall: "RecallResponse | None" = Field(
        default=None,
        description="Typed cited historical recall for UI-grade source rendering.",
    )
    metadata: dict[str, Any] = Field(default_factory=dict, description="Additional metadata")


class SuggestionRequest(BaseModel):
    """Request to get suggestions for current workspace."""

    context: ChatContext = Field(..., description="Conversation context")


class SuggestionResponse(BaseModel):
    """Workspace-specific suggestions."""

    suggestions: list[dict[str, str]] = Field(..., description="List of suggestions with label and query")


class RecallRequest(BaseModel):
    """Request to recall cited historical context from Zara."""

    query: str = Field(..., description="Historical query to recall", min_length=1, max_length=5000)
    limit: int = Field(3, description="Maximum number of cited memories to return", ge=1, le=10)


class RecallResponse(BaseModel):
    """Response from Zara cited recall."""

    query: str
    reason_code: str
    retrieval_path: str
    count: int
    citations: list[dict[str, Any]] = Field(default_factory=list)
    sources: str = ""


class ExplainRequest(BaseModel):
    """Request to explain decisions for a work item."""

    workitem_id: str = Field(..., description="WorkItem ID", min_length=1, max_length=200)
    max_decisions: int = Field(10, description="Maximum number of decision traces to include", ge=1, le=50)
    include_trace_urls: bool = Field(True, description="Whether to include canonical decision trace URLs")


class ExplainDecision(BaseModel):
    """Decision event returned in explain output."""

    trace_id: str
    skill_id: str
    decision_summary: str
    decision_type: str
    outcome: str
    rationale: str | None = None
    alternatives_considered: list[str] = Field(default_factory=list)
    decision_conditions: list[str] = Field(default_factory=list)
    sop_deviation: str | None = None
    quality_score: float = 0.0
    created_at: str
    entity_ids: list[str] = Field(default_factory=list)
    trace_url: str | None = None
    correlation_id: str | None = Field(
        None,
        description="Correlation id tying this decision to the governed mutation run.",
    )
    governed_by: list[str] = Field(
        default_factory=list,
        description=(
            "Governance identifiers (policy ids, exception references, guard names) "
            "that gated this decision. Populated from the decision's policy_id, "
            "exception_granted and governed_mutation context so Explain consumers "
            "can cite the exact rails that applied."
        ),
    )


class ExplainContextSummary(BaseModel):
    """Canonical WorkItem decision boundaries."""

    thread_id: str = ""
    workitem_ids: list[str] = Field(default_factory=list)
    mission_refs: list[str] = Field(default_factory=list)
    entity_ids: list[str] = Field(default_factory=list)


class ExplainEvidenceSummary(BaseModel):
    """Structured evidence references for explain consumers."""

    decision_event_ids: list[str] = Field(default_factory=list)
    source_event_ids: list[str] = Field(default_factory=list)
    attachment_count: int = 0
    evidence_count: int = 0
    recording_refs: list[dict[str, Any]] = Field(default_factory=list)


class ExplainCoverageSummary(BaseModel):
    """Coverage details for explain consumers."""

    expected_decision_count: int = 0
    evidence_decision_event_count: int = 0
    matched_context_decision_count: int = 0
    truncated_decision_count: int = 0
    missing_decision_ids: list[str] = Field(default_factory=list)
    governed_mutation_count: int = 0


class ExplainResponse(BaseModel):
    """Explainability response for a WorkItem.

    Provides a structured contract with three first-class surfaces that UAT
    flows ("why did X happen?") depend on:

    * ``decisions`` — the decision trace (``decision_trace_id`` + rationale)
    * ``evidence`` — source events, attachments, recording refs
    * ``scope_boundaries`` — human-readable in-scope / out-of-scope guardrails
      derived from the canonical context (thread, workitem, mission, entity)
    """

    workitem_id: str
    workitem_title: str
    summary: str
    decision_count: int
    explainable: bool
    decisions: list[ExplainDecision] = Field(default_factory=list)
    missing_decision_ids: list[str] = Field(default_factory=list)
    context: ExplainContextSummary = Field(default_factory=ExplainContextSummary)
    evidence: ExplainEvidenceSummary = Field(default_factory=ExplainEvidenceSummary)
    coverage: ExplainCoverageSummary = Field(default_factory=ExplainCoverageSummary)
    scope_boundaries: list[str] = Field(
        default_factory=list,
        description=(
            "Human-readable scope boundaries describing what was in scope for "
            "this explain (thread, workitem, mission, entity) so consumers can "
            "surface the governed blast radius without recomputing from context."
        ),
    )
    metadata: dict[str, Any] = Field(default_factory=dict)


ChatResponse.model_rebuild()


class VoiceSessionRequest(BaseModel):
    """Request to create a voice session token for authenticated users."""

    user_id: str | None = Field(None, description="User ID; defaults to authenticated user")
    session_type: str = Field("dashboard", description="Session type: dashboard | phone")
    agent_id: str | None = Field(None, description="AI agent ID for this voice session")


class VoiceSessionResponse(BaseModel):
    """Response containing a voice session token."""

    session_token: str = Field(..., description="Signed session token for Zara voice")
    livekit_url: str = Field(..., description="LiveKit server URL to connect to")
    room_name: str = Field(..., description="Room name to join")
    expires_in: int = Field(..., description="Token TTL in seconds")


class AwarenessControlPlane(BaseModel):
    """Zara control-plane framing for the awareness snapshot."""

    identity: str
    role: str
    decision_mode: str
    voice_interface: str
    execution_posture: str
    foreground_responsive: bool = True
    active_background_missions: int = 0
    open_recovery_incidents: int = 0


class AwarenessRuntime(BaseModel):
    """Runtime posture visible to Zara."""

    healthy: bool
    status: str
    connected_integrations: list[str]
    degraded_reasons: list[str]
    fallback_mode: str | None = None
    execution_modes: list[str]


class AwarenessCapabilityItem(BaseModel):
    """Tenant-facing capability item for awareness responses."""

    id: str
    display_name: str
    description: str
    category: str
    icon: str
    required_integrations: list[str]
    governance_defaults: dict[str, Any]
    is_enabled: bool


class AwarenessCapabilities(BaseModel):
    """Capability posture for Zara awareness."""

    entity_id: str | None
    role_label: str | None
    enabled: list[AwarenessCapabilityItem]
    disabled: list[AwarenessCapabilityItem]
    available_role_templates: list[str]
    mode: str


class AwarenessProactive(BaseModel):
    """Proactive-intelligence posture for Zara awareness."""

    available: bool
    mode: str
    pending_suggestions: int | None = None
    last_run_at: str | None = None
    last_signals_scanned: int | None = None
    last_suggestions_generated: int | None = None
    last_run_source: str | None = None


class AwarenessRoutineItem(BaseModel):
    routine_id: str
    display_name: str
    health_status: str
    next_run_at: str | None = None
    recommended_action: dict[str, Any] | None = None


class AwarenessRoutines(BaseModel):
    total: int
    healthy: int
    degraded: int
    failing: int
    paused: int
    cancelled: int
    top_attention: list[AwarenessRoutineItem] = Field(default_factory=list)


class AwarenessResponse(BaseModel):
    """Read-only Zara awareness snapshot."""

    tenant_id: str
    workspace: str
    agent_id: str | None = None
    control_plane: AwarenessControlPlane
    runtime: AwarenessRuntime
    capabilities: AwarenessCapabilities
    proactive: AwarenessProactive
    routines: AwarenessRoutines
    known_limitations: list[str]


# ---------------------------------------------------------------------------
# PR-16: Zara Awareness Rationalization - orchestration endpoint payloads
# ---------------------------------------------------------------------------


class CrossEntityQueryRequest(BaseModel):
    """Ask Zara about what one or more entities have done."""

    query: str = Field(
        ...,
        description="Natural-language query, e.g. 'What did AI-Sales-Ops do today?'",
        min_length=1,
        max_length=2000,
    )


class CrossEntityQueryResponse(BaseModel):
    """Result of a cross-entity query."""

    response_type: str = Field(..., description="'entity_summary' or 'org_summary'")
    entity_id: str | None = Field(None, description="Resolved entity ID, if query targeted a single entity")
    evidence_count: int
    summary: str
    evidence: list[dict[str, Any]] = Field(default_factory=list, description="Up to 10 most recent evidence entries")


class DispatchTaskRequest(BaseModel):
    """Ask Zara to route a task to the appropriate entity."""

    type: str = Field(
        ...,
        description="Task type / capability slug, e.g. 'email_outreach'",
        min_length=1,
        max_length=200,
    )
    description: str | None = Field(None, description="Human-readable task description")
    metadata: dict[str, Any] = Field(default_factory=dict)


class DispatchTaskResponse(BaseModel):
    """Result of a task dispatch attempt."""

    dispatched: bool
    target_role_id: str | None = None
    target_display_name: str | None = None
    reason: str | None = Field(None, description="Set when dispatched=False")


class SupportTicketRequest(BaseModel):
    """Create a support ticket via Zara."""

    summary: str = Field(..., description="Short description of the issue", min_length=1, max_length=500)
    steps: list[str] = Field(default_factory=list, description="Steps to reproduce")


class SupportTicketResponse(BaseModel):
    """Created support ticket."""

    ticket_created: bool
    ticket_id: str
    tenant_id: str
    created_at: str
    summary: str
    steps_to_reproduce: list[str]


# ---------------------------------------------------------------------------
# Zara Verb Routes (Phase 1 — Shell Parity) payloads
# ---------------------------------------------------------------------------


class ZaraAskRequest(BaseModel):
    """Thin /ask wrapper — conversational query with explicit ask intent."""

    message: str = Field(..., description="Question for Zara", min_length=1, max_length=5000)
    context: ChatContext = Field(..., description="Conversation context")
    conversation_id: str | None = Field(None, description="Conversation ID for history")


class ZaraActRequest(BaseModel):
    """Thin /act wrapper — dispatch an action with explicit act intent."""

    type: str = Field(..., description="Action/task type identifier")
    description: str = Field("", description="Human-readable description of the action")
    metadata: dict[str, Any] = Field(default_factory=dict)


class ZaraApproveRequest(BaseModel):
    """Approve a pending Inbox judgment or approve-this-pattern proposal via Zara."""

    request_id: str = Field(
        "", description="Approval request ID from the Inbox queue (omit when action=approve_pattern)"
    )
    action: str = Field("approve", description="'approve' or 'approve_pattern'")
    pattern_id: str | None = Field(
        None, description="Pattern ID when action=approve_pattern; used as request_id if request_id is empty"
    )
    modified_params: dict[str, Any] | None = Field(None)
    reason: str | None = Field(None)


class ZaraApproveResponse(BaseModel):
    success: bool
    message: str
    request_id: str
    action: str


# ---------------------------------------------------------------------------
# Plan generation + execution payloads (Issue #1092)
# ---------------------------------------------------------------------------


# Re-exported from contracts for backward compatibility (issue #3785).
from apps.backend.contracts.zara import (  # noqa: F401 — re-exports
    PlanConnectorInput,
    PlanRequest,
    PlanSkillInput,
)


class SkillCandidateResponse(BaseModel):
    """Candidate skill/connector for an emergent plan step."""

    skill_id: str
    name: str = ""
    capability: str = ""
    fit_score: float = 1.0
    health_score: float | None = None
    queue_depth: int | None = None
    recent_success_rate: float | None = None
    reasons: list[str] = Field(default_factory=list)
    metadata: dict[str, Any] = Field(default_factory=dict)


class PlanStepResponse(BaseModel):
    """Single step in the generated plan."""

    id: str
    name: str
    connector_or_skill: str
    action: str
    inputs: dict[str, Any] = Field(default_factory=dict)
    depends_on: list[str] = Field(default_factory=list)
    success_criteria: str = ""
    estimated_duration_seconds: int = 60
    step_candidates: list[SkillCandidateResponse] = Field(default_factory=list)
    preconditions: list[str] = Field(default_factory=list)


class LossFunctionResponse(BaseModel):
    """Expected plan loss function metadata for user-visible plan cards."""

    weights: dict[str, float] = Field(default_factory=dict)
    expected: float = 0.85
    confidence_band: list[float] = Field(default_factory=lambda: [0.72, 0.92])


class PlanRevisionResponse(BaseModel):
    """Audit row for a plan revision."""

    rev: int
    prev_rev: int | None = None
    instruction: str
    diff: list[dict[str, Any]] = Field(default_factory=list)
    created_at: str


class SkillReuseSummary(BaseModel):
    """Skill-reuse signal surfaced from IntakeCompiler ontology trace."""

    matched_skills: list[dict[str, Any]] = Field(
        default_factory=list,
        description="Skills matched by the ontology trace for this goal.",
    )
    matched_entity_schemas: list[str] = Field(
        default_factory=list,
        description="Entity schema ontology node IDs matched by the ontology trace.",
    )
    matched_entity_records: list[str] = Field(
        default_factory=list,
        description="Entity record ontology node IDs matched by the ontology trace.",
    )
    ontology_consulted: bool = Field(
        True,
        description="Whether the ontology was consulted during intake compilation.",
    )
    decision: str = Field(
        "new",
        description="Reuse decision: 'reuse' | 'extend' | 'new'.",
    )


class PlanResponse(BaseModel):
    """Generated DAG plan response."""

    plan_id: str
    goal: str
    summary: str = ""
    planner_mode: str = "self_organizing_emergent"
    steps: list[PlanStepResponse] = Field(default_factory=list)
    loss_function: LossFunctionResponse = Field(default_factory=LossFunctionResponse)
    revision: int = 1
    status: str = "active"
    diff: list[dict[str, Any]] = Field(default_factory=list)
    sensitivity: str = "low"
    gate_flags: dict[str, bool] = Field(default_factory=dict)
    inverter: dict[str, Any] = Field(default_factory=dict)
    swarm_planner: dict[str, Any] = Field(default_factory=dict)
    prior_context_refs: list[str] = Field(
        default_factory=list,
        description="Evidence, memory, skill, and precedent refs consulted before plan generation.",
    )
    alternatives_considered: list[str] = Field(
        default_factory=list,
        description="Plan-shape alternatives derived from prior outcomes and matching skills.",
    )
    effort_policy: dict[str, Any] = Field(
        default_factory=dict,
        description=(
            "Audit record of how planning depth was determined. "
            "Contains pass_budget, projected_execution_cost_usd, "
            "eval_thoroughness, and applied_overrides."
        ),
    )
    created_at: str | None = None
    updated_at: str | None = None
    skill_reuse_summary: SkillReuseSummary = Field(
        default_factory=SkillReuseSummary,
        description="Skill-reuse signal from IntakeCompiler ontology trace.",
    )


class PlanReviseRequest(BaseModel):
    """Request to revise a persisted plan with natural-language steering."""

    instruction: str = Field(
        ..., description="Natural-language plan steering instruction", min_length=1, max_length=5000
    )


class PlanSteerRequest(BaseModel):
    """Request from a channel steering button on a persisted plan."""

    action: Literal["approve", "steer", "block", "archive"] = Field(
        ..., description="Plan steering action selected by the user"
    )
    instruction: str | None = Field(
        None,
        description="Natural-language instruction for steer/block/archive context",
        max_length=5000,
    )
    actor_id: str | None = Field(
        None,
        description="Trusted bridge actor. HTTP routes resolve actor from authentication and ignore caller-supplied values.",
        max_length=200,
    )
    actor_source: Literal["api", "cli", "mcp", "slack"] | None = Field(
        None,
        description="Trusted bridge surface. HTTP routes infer this from the authenticated request.",
    )
    expected_revision: int | None = Field(
        None,
        description="Plan revision visible when the control was rendered; stale controls are rejected.",
        ge=1,
    )
    idempotency_key: str | None = Field(
        None,
        description="Stable key for retry-safe plan controls.",
        max_length=300,
    )


class PlanSteerResponse(BaseModel):
    """Result of a plan steering action."""

    plan_id: str
    status: str
    revision: int
    decision_trace_id: str
    diff: list[dict[str, Any]] = Field(default_factory=list)
    execution_id: str | None = None
    message: str = ""


class ExecutePlanRequest(BaseModel):
    """Request to execute a previously generated plan."""

    plan_id: str = Field(..., description="Plan ID from plan generation")
    plan_rev: int | None = Field(None, description="Plan revision to execute")
    goal: str | None = Field(None, description="Original goal")
    steps: list[PlanStepResponse] = Field(default_factory=list, description="Plan steps to execute")
    context: dict[str, Any] = Field(default_factory=dict, description="Execution context")
    explicit_approval: bool = Field(False, description="True when a human explicitly approved this run")


class PlanMitigationRequest(BaseModel):
    """Decision on one inverter mitigation surfaced in the plan card."""

    decision: str = Field(..., pattern="^(accepted|dismissed|request_revision)$")


class StepResultResponse(BaseModel):
    """Execution result for a single step."""

    step_id: str
    status: str
    output: dict[str, Any] | None = None
    error: str | None = None


class ExecutePlanResponse(BaseModel):
    """Result of executing a plan."""

    execution_id: str
    status: str
    step_results: dict[str, StepResultResponse] = Field(default_factory=dict)


class ExecutionEventResponse(BaseModel):
    """Stored execution event."""

    event_id: str
    type: str
    execution_id: str
    plan_id: str | None = None
    step_id: str | None = None
    message: str = ""
    payload: dict[str, Any] = Field(default_factory=dict)
    created_at: str


class ExecutionStatusResponse(BaseModel):
    """Current execution status plus persisted timeline."""

    execution_id: str
    plan_id: str
    plan_rev: int = 1
    status: str
    events: list[ExecutionEventResponse] = Field(default_factory=list)
    steers: list[dict[str, Any]] = Field(default_factory=list)
    created_at: str | None = None
    updated_at: str | None = None
    completed_at: str | None = None


class ExecutionCancelResponse(BaseModel):
    """Cancel acknowledgement for an execution."""

    execution_id: str
    status: str


class ExecutionSteerRequest(BaseModel):
    """Request to steer a running execution."""

    instruction: str = Field(..., min_length=1, max_length=5000)


class ExecutionSteerResponse(BaseModel):
    """Steer acknowledgement for a running execution."""

    execution_id: str
    status: str
    instruction: str


class PlanListItemResponse(BaseModel):
    """Compact list row for plan history surfaces."""

    plan_id: str
    goal: str
    status: str
    latest_rev: int = 1
    latest_execution_id: str | None = None
    created_at: str | None = None
    completed_at: str | None = None
    loss_score: float | None = None


class PlanListResponse(BaseModel):
    """Paginated plan list response."""

    plans: list[PlanListItemResponse] = Field(default_factory=list)
    next_cursor: str | None = None


class PlanDetailResponse(BaseModel):
    """Full plan history response."""

    plan: PlanResponse
    revisions: list[PlanRevisionResponse] = Field(default_factory=list)
    executions: list[ExecutionStatusResponse] = Field(default_factory=list)


# ---------------------------------------------------------------------------
# Active Speak (Route C) — Recall.ai live SDK integration (#2717)
# ---------------------------------------------------------------------------


class ZaraMeetingSpeakRequest(BaseModel):
    """Request body for ``POST /api/v1/zara/meetings/{meeting_id}/speak``.

    The endpoint is gated by the ``recall_speak_enabled`` feature flag and
    by an ``ActiveSpeakConsent`` grant for the meeting. Both gates are
    explicit: when off, the API returns 503 (flag) or 412 (consent)
    with a stable reason code.
    """

    text: str = Field(
        ...,
        min_length=1,
        max_length=4000,
        description="Utterance Zara will speak into the meeting.",
    )
    voice_persona_id: str | None = Field(
        default=None,
        description=(
            "Optional configured voice id; null falls back to the bot's "
            "default Recall voice persona."
        ),
    )
    trigger_reason: str = Field(
        ...,
        min_length=1,
        max_length=64,
        description=(
            "What caused this speak attempt. Stable vocabulary recommended: "
            "address_zara | wake_word | schedule | operator_request."
        ),
    )


class ZaraMeetingSpeakResponse(BaseModel):
    """Response body for a successful Active Speak attempt."""

    recall_call_id: str = Field(
        ..., description="Identifier returned by Recall.ai for the speak call."
    )
    status: Literal["sent", "failed"] = Field(
        default="sent", description="Terminal status of the speak attempt."
    )
    consent_id: str = Field(
        ..., description="ActiveSpeakConsent id that authorized this attempt."
    )
    decision_trace_id: str = Field(
        ..., description="Audit trace id recorded for this attempt."
    )
    meeting_id: str = Field(..., description="Meeting the speak was sent into.")
    workspace_id: str = Field(..., description="Workspace owning the meeting.")
