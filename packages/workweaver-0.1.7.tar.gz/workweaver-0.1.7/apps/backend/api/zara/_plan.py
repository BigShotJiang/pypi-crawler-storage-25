"""Plan generation, execution, and steering route handlers for the Zara API.

Symbols are re-imported in ``__init__.py`` for backward compatibility.
"""

from __future__ import annotations

import asyncio
import logging
import sys
from typing import Any

import ulid
from fastapi import HTTPException, Request

from apps.backend.api.zara.models import (
    ExecutePlanRequest,
    ExecutePlanResponse,
    ExecutionCancelResponse,
    ExecutionStatusResponse,
    ExecutionSteerRequest,
    ExecutionSteerResponse,
    PlanDetailResponse,
    PlanListItemResponse,
    PlanListResponse,
    PlanMitigationRequest,
    PlanRequest,
    PlanResponse,
    PlanRevisionResponse,
    PlanSteerRequest,
    PlanSteerResponse,
    PlanStepResponse,
    SkillCandidateResponse,
    SkillReuseSummary,
)
from apps.backend.services.zara.execution_event_bus import (
    build_execution_event,
    format_sse,
)
from apps.backend.services.zara.plan_store import (
    build_step_diff,
    default_loss_function,
)
from apps.backend.services.zara.context_loader import PriorContextBundle
from apps.backend.services.zara.zara_goal_intake import GoalMode, IntakeCompiler
from fastapi.responses import StreamingResponse

logger = logging.getLogger(__name__)


def _pkg():
    """Return the canonical package module for stub dispatch."""
    return sys.modules["apps.backend.api.zara"]


def _get_agent_dispatch_service():
    return _pkg()._get_agent_dispatch_service()


def build_zara_task_executor(tenant_id: str, **kwargs: Any):
    """Delegate to package-level binding for test-patch compatibility."""
    return _pkg().build_zara_task_executor(tenant_id=tenant_id, **kwargs)


def get_zara_plan_store():
    """Delegate to package-level binding for test-patch compatibility."""
    return _pkg().get_zara_plan_store()


def get_execution_event_bus(*args: Any, **kwargs: Any):
    """Delegate to package-level binding for test-patch compatibility."""
    return _pkg().get_execution_event_bus(*args, **kwargs)


def get_zara_prior_context_loader():
    """Delegate to package-level binding for test-patch compatibility."""
    return _pkg().get_zara_prior_context_loader()


def _model_to_dict(value: Any) -> dict[str, Any]:
    if hasattr(value, "model_dump"):
        return value.model_dump()
    return dict(value or {})


def _plan_steps_to_dicts(steps: list[Any]) -> list[dict[str, Any]]:
    return [_model_to_dict(step) for step in steps]


def _plan_step_id(step: dict[str, Any], index: int) -> str:
    return str(step.get("id") or step.get("step_id") or f"step_{index + 1}")


def _latest_step_for_id(
    *,
    tenant_id: str,
    plan_id: str,
    step_id: str,
    fallback: dict[str, Any],
) -> dict[str, Any]:
    record = get_zara_plan_store().get_plan(tenant_id, plan_id) if plan_id else None
    for idx, candidate in enumerate(_plan_steps_to_dicts((record or {}).get("steps") or [])):
        if _plan_step_id(candidate, idx) == step_id:
            return candidate
    return fallback


def _started_execution_step_ids(record: dict[str, Any]) -> set[str]:
    started: set[str] = set()
    for event in record.get("events") or []:
        event_type = str(event.get("type") or "")
        step_id = str(event.get("step_id") or "")
        if step_id and event_type.startswith("step."):
            started.add(step_id)
    return started


async def _revise_plan_record(
    *,
    tenant_id: str,
    plan_id: str,
    instruction: str,
    locked_step_ids: set[str] | None = None,
) -> tuple[dict[str, Any], list[dict[str, Any]]]:
    store = get_zara_plan_store()
    current = store.get_plan(tenant_id, plan_id)
    if not current:
        raise KeyError(f"plan not found: {plan_id}")
    svc = build_zara_task_executor(tenant_id=tenant_id)
    revised = await svc.revise_plan(current, instruction)
    previous_steps = _plan_steps_to_dicts(current.get("steps") or [])
    revised_steps = _plan_steps_to_dicts(revised.get("steps") or [])
    locked = locked_step_ids or set()
    if locked:
        previous_by_id = {_plan_step_id(step, idx): step for idx, step in enumerate(previous_steps)}
        revised_steps = [
            previous_by_id.get(_plan_step_id(step, idx), step) if _plan_step_id(step, idx) in locked else step
            for idx, step in enumerate(revised_steps)
        ]
    diff = build_step_diff(previous_steps, revised_steps)
    record = store.save_revision(
        tenant_id=tenant_id,
        plan_id=plan_id,
        steps=revised_steps,
        instruction=instruction,
        diff=diff,
        summary=str(revised.get("summary") or current.get("summary") or ""),
    )
    return record, diff


def _plan_response_from_record(record: dict[str, Any], *, diff: list[dict[str, Any]] | None = None) -> PlanResponse:
    raw_srs = record.get("skill_reuse_summary") or {}
    if isinstance(raw_srs, dict):
        skill_reuse_summary = SkillReuseSummary(
            matched_skills=list(raw_srs.get("matched_skills") or []),
            matched_entity_schemas=list(raw_srs.get("matched_entity_schemas") or []),
            matched_entity_records=list(raw_srs.get("matched_entity_records") or []),
            ontology_consulted=bool(raw_srs.get("ontology_consulted", True)),
            decision=str(raw_srs.get("decision") or "new"),
        )
    else:
        skill_reuse_summary = SkillReuseSummary()
    return PlanResponse(
        plan_id=str(record.get("plan_id") or ""),
        goal=str(record.get("goal") or ""),
        summary=str(record.get("summary") or ""),
        planner_mode=str(record.get("planner_mode") or "self_organizing_emergent"),
        steps=record.get("steps") or [],
        loss_function=record.get("loss_function") or default_loss_function(),
        revision=int(record.get("latest_rev") or record.get("revision") or 1),
        status=str(record.get("status") or "active"),
        diff=list(diff or []),
        sensitivity=str(record.get("sensitivity") or "low"),
        gate_flags=dict(record.get("gate_flags") or {}),
        inverter=dict(record.get("inverter") or {}),
        swarm_planner=dict(record.get("swarm_planner") or {}),
        prior_context_refs=list(record.get("prior_context_refs") or []),
        alternatives_considered=list(record.get("alternatives_considered") or []),
        effort_policy=dict(record.get("effort_policy") or {}),
        created_at=record.get("created_at"),
        updated_at=record.get("updated_at"),
        skill_reuse_summary=skill_reuse_summary,
    )


def _execution_response_from_record(record: dict[str, Any]) -> ExecutionStatusResponse:
    return ExecutionStatusResponse(
        execution_id=str(record.get("execution_id") or ""),
        plan_id=str(record.get("plan_id") or ""),
        plan_rev=int(record.get("plan_rev") or 1),
        status=str(record.get("status") or "unknown"),
        events=record.get("events") or [],
        steers=record.get("steers") or [],
        created_at=record.get("created_at"),
        updated_at=record.get("updated_at"),
        completed_at=record.get("completed_at"),
    )


def _plan_list_item(record: dict[str, Any]) -> PlanListItemResponse:
    return PlanListItemResponse(
        plan_id=str(record.get("plan_id") or ""),
        goal=str(record.get("goal") or ""),
        status=str(record.get("status") or "active"),
        latest_rev=int(record.get("latest_rev") or 1),
        latest_execution_id=record.get("latest_execution_id"),
        created_at=record.get("created_at"),
        completed_at=record.get("completed_at"),
        loss_score=record.get("loss_score"),
    )


def _record_execution_event(
    *,
    tenant_id: str,
    event: dict[str, Any],
) -> None:
    execution_id = str(event.get("execution_id") or "")
    if not execution_id:
        return
    store = get_zara_plan_store()
    store.append_execution_event(tenant_id=tenant_id, execution_id=execution_id, event=event)
    try:
        get_execution_event_bus().publish(event)
    except Exception:
        logger.warning("Zara execution SSE publish failed after durable append", exc_info=True)


def _log_background_execution_failure(task: asyncio.Task[Any]) -> None:
    try:
        exc = task.exception()
    except asyncio.CancelledError:
        return
    if exc is not None:
        logger.error(
            "Zara plan execution background task failed",
            exc_info=(type(exc), exc, exc.__traceback__),
        )


async def _reply_to_slack_execution_origin(
    *,
    tenant_id: str,
    execution_id: str,
    plan_id: str,
    status: str,
    context: dict[str, Any],
    error: str | None = None,
) -> None:
    slack_workspace_id = str(context.get("slack_workspace_id") or "").strip()
    channel = str(context.get("slack_channel") or "").strip()
    thread_ts = str(context.get("slack_thread_ts") or "").strip()
    decision_trace_id = str(context.get("decision_trace_id") or "").strip()
    if not (slack_workspace_id and channel and thread_ts):
        return
    try:
        from apps.backend.services.zara.zara_intake_service import SlackConnectorThread

        suffix = f" Error: {error}" if error else " Skillify will review this run for reusable skill candidates."
        trace = (
            f" Decision Trace: /api/v1/evidence/decisions/{decision_trace_id}"
            if decision_trace_id
            else ""
        )
        await SlackConnectorThread().reply(
            workspace_id=tenant_id,
            slack_workspace_id=slack_workspace_id,
            channel=channel,
            thread_ts=thread_ts,
            text=(
                f"Zara execution `{execution_id}` for plan `{plan_id}` finished with status `{status}`."
                f"{suffix}{trace}"
            ),
        )
    except Exception:
        logger.warning("zara.execution.slack_origin_reply_failed execution_id=%s", execution_id, exc_info=True)


async def _run_plan_execution(
    *,
    tenant_id: str,
    execution_id: str,
    plan: dict[str, Any],
    context: dict[str, Any],
) -> None:
    from apps.backend.services.dag_executor import DAGExecution, DAGExecutor, DAGStep

    store = get_zara_plan_store()
    bus = get_execution_event_bus()
    bus.register_execution(execution_id)
    plan_id = str(plan.get("plan_id") or "")
    store.update_execution_status(tenant_id=tenant_id, execution_id=execution_id, status="running")
    _record_execution_event(
        tenant_id=tenant_id,
        event=build_execution_event(
            "execution.started",
            execution_id=execution_id,
            plan_id=plan_id,
            message="Execution started",
        ),
    )

    plan_revision = int(plan.get("latest_rev") or plan.get("revision") or 1)

    def _make_step_executor(step: dict[str, Any], step_id: str) -> Any:
        async def _exec(_ctx: dict[str, Any]) -> dict[str, Any]:
            if bus.is_cancelled(execution_id):
                raise RuntimeError("execution cancelled")
            effective_step = _latest_step_for_id(
                tenant_id=tenant_id,
                plan_id=plan_id,
                step_id=step_id,
                fallback=step,
            )
            _record_execution_event(
                tenant_id=tenant_id,
                event=build_execution_event(
                    "step.started",
                    execution_id=execution_id,
                    plan_id=plan_id,
                    step_id=step_id,
                    message=str(effective_step.get("name") or step_id),
                    payload={"step": effective_step},
                ),
            )
            try:
                task_description = (
                    f"Execute {effective_step.get('action') or effective_step.get('name') or step_id}"
                    f" using {effective_step.get('connector_or_skill') or 'Zara'}"
                )
                if effective_step.get("inputs"):
                    task_description += f" with inputs: {effective_step.get('inputs')}"

                # Idempotency key: (tenant_id, plan_id, plan_revision, attempt_id)
                attempt_id = f"{step_id}#rev{plan_revision}"
                dispatch_svc = _get_agent_dispatch_service()
                target_agent_id = (
                    str(effective_step.get("target_agent_id") or effective_step.get("connector_or_skill") or "zara")
                )
                dispatched = dispatch_svc.dispatch_swarm_task(
                    tenant_id=tenant_id,
                    target_agent_id=target_agent_id,
                    swarm_id=execution_id,
                    task=task_description,
                    execution_id=execution_id,
                    step_id=step_id,
                    dependencies=list(effective_step.get("depends_on") or []),
                    skill_id=str(effective_step.get("connector_or_skill") or "") or None,
                    inputs=dict(effective_step.get("inputs") or {}),
                    dispatch_kind="step",
                    attempt=1,
                )

                try:
                    from apps.backend.services.evidence_ledger import get_evidence_ledger_service

                    get_evidence_ledger_service().ingest(
                        tenant_id=tenant_id,
                        event_type="evidence:plan_dispatched_to_swarm",
                        data={
                            "execution_id": execution_id,
                            "plan_id": plan_id,
                            "plan_revision": plan_revision,
                            "step_id": step_id,
                            "attempt_id": attempt_id,
                            "target_agent_id": target_agent_id,
                            "dispatched": dispatched,
                        },
                        actor_path="zara.execute_plan._dispatch_step",
                    )
                except Exception:
                    logger.warning("zara.execute_plan.dispatch_evidence_failed step=%s", step_id, exc_info=True)

                if not dispatched:
                    raise RuntimeError(
                        f"AgentDispatchService refused step {step_id} dispatch"
                        f" (dispatched=False; check queue availability)"
                    )

                _record_execution_event(
                    tenant_id=tenant_id,
                    event=build_execution_event(
                        "step.completed",
                        execution_id=execution_id,
                        plan_id=plan_id,
                        step_id=step_id,
                        message="Step dispatched to swarm",
                        payload={"dispatched": dispatched, "attempt_id": attempt_id},
                    ),
                )
                return {"status": "dispatched", "output": {"attempt_id": attempt_id}}

            except RuntimeError as exc:
                if str(exc) != "execution cancelled":
                    raise
                _record_execution_event(
                    tenant_id=tenant_id,
                    event=build_execution_event(
                        "step.cancelled",
                        execution_id=execution_id,
                        plan_id=plan_id,
                        step_id=step_id,
                        message="Step cancelled",
                    ),
                )
                raise
            except Exception as exc:
                _record_execution_event(
                    tenant_id=tenant_id,
                    event=build_execution_event(
                        "step.failed",
                        execution_id=execution_id,
                        plan_id=plan_id,
                        step_id=step_id,
                        message=str(exc),
                    ),
                )
                raise

        return _exec

    steps = _plan_steps_to_dicts(plan.get("steps") or [])
    dag_steps = []
    for idx, step in enumerate(steps):
        step_id = _plan_step_id(step, idx)
        dag_steps.append(
            DAGStep(
                id=step_id,
                name=str(step.get("name") or step_id),
                execute_fn=_make_step_executor(step, step_id),
                depends_on=list(step.get("depends_on") or []),
                timeout_seconds=max(int(step.get("estimated_duration_seconds") or 60), 30),
            )
        )
    try:
        result = await DAGExecutor().execute(
            DAGExecution(id=execution_id, steps=dag_steps, context={"tenant_id": tenant_id, **context}),
            interrupt_token=bus.get_interrupt_token(execution_id),
        )
        cancelled = bus.is_cancelled(execution_id) or result.status == "interrupted"
        final_status = "cancelled" if cancelled else result.status
        event_type = (
            "execution.cancelled"
            if cancelled
            else ("execution.completed" if result.status == "completed" else "execution.failed")
        )
        store.update_execution_status(tenant_id=tenant_id, execution_id=execution_id, status=final_status)
        store.update_plan_status(
            tenant_id=tenant_id,
            plan_id=plan_id,
            status="cancelled" if cancelled else ("completed" if result.status == "completed" else "failed"),
            latest_execution_id=execution_id,
            loss_score=0.0 if result.status == "completed" else None,
        )
        _record_execution_event(
            tenant_id=tenant_id,
            event=build_execution_event(
                event_type,
                execution_id=execution_id,
                plan_id=plan_id,
                message=f"Execution {final_status}",
                payload={
                    "status": result.status,
                    "step_results": {
                        step_id: {
                            "status": step_result.status.value
                            if hasattr(step_result.status, "value")
                            else str(step_result.status),
                            "output": step_result.output,
                            "error": step_result.error,
                        }
                        for step_id, step_result in result.results.items()
                    },
                },
            ),
        )
        await _reply_to_slack_execution_origin(
            tenant_id=tenant_id,
            execution_id=execution_id,
            plan_id=plan_id,
            status=final_status,
            context=context,
        )
    except Exception as exc:
        logger.error("Zara plan execution failed: %s", exc, exc_info=True)
        store.update_execution_status(tenant_id=tenant_id, execution_id=execution_id, status="failed")
        if plan_id:
            store.update_plan_status(
                tenant_id=tenant_id,
                plan_id=plan_id,
                status="failed",
                latest_execution_id=execution_id,
            )
        _record_execution_event(
            tenant_id=tenant_id,
            event=build_execution_event(
                "execution.failed",
                execution_id=execution_id,
                plan_id=plan_id,
                message=str(exc),
            ),
        )
        await _reply_to_slack_execution_origin(
            tenant_id=tenant_id,
            execution_id=execution_id,
            plan_id=plan_id,
            status="failed",
            context=context,
            error=str(exc),
        )


async def generate_plan(
    request: PlanRequest,
    tenant_id: str = "",
) -> PlanResponse:
    """Generate a DAG execution plan from a business goal."""
    from services.planning.engine import (
        ConnectorSpec,
        GeneratedPlan,
        PlanGenerationEngine,
        PlanStepSpec,
        SkillSpec,
    )
    from apps.backend.services.planning.effort_policy import PlanEffortPolicy
    from apps.backend.services.planning.sensitivity_classifier import SensitivityClassifier
    from apps.backend.services.planning.planner_mode import resolve_planner_mode
    from apps.backend.services.tenant_config import get_tenant_config
    from apps.backend.services.zara.inverter_agent import InverterAgent
    from apps.backend.services.zara.role_agent_runtime import invoke_role_llm
    from apps.backend.services.zara.swarm_planner_agent import SwarmPlannerAgent
    connectors = [
        ConnectorSpec(
            id=c.id,
            name=c.name,
            actions=c.actions,
            description=c.description,
        )
        for c in request.connectors
    ]
    skills = [
        SkillSpec(
            id=s.id,
            name=s.name,
            description=s.description,
            inputs=s.inputs,
            outputs=s.outputs,
        )
        for s in request.skills
    ]

    svc_for_roles = build_zara_task_executor(tenant_id=tenant_id)

    async def _llm_fn(system_prompt: str, user_prompt: str) -> str:
        try:
            return await invoke_role_llm(
                svc_for_roles.llm_client,
                model="zara-role-default",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt},
                ],
            )
        except Exception as exc:
            logger.error("Plan generation LLM call failed: %s", exc, exc_info=True)
            raise HTTPException(status_code=503, detail="Plan generation failed") from exc

    engine = PlanGenerationEngine(llm_fn=_llm_fn)
    plan_ctx = dict(request.context)
    plan_ctx["tenant_id"] = tenant_id
    agent_id = str(
        plan_ctx.get("agent_id")
        or plan_ctx.get("actor_id")
        or plan_ctx.get("zara_agent_id")
        or plan_ctx.get("assignee_id")
        or ""
    ).strip()
    try:
        planner_mode = resolve_planner_mode(tenant_id, request.planner_mode, agent_id=agent_id or None)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    plan_ctx["planner_mode"] = planner_mode.value
    prior_context_bundle = PriorContextBundle.empty()
    try:
        prior_context_bundle = await get_zara_prior_context_loader().load(
            workspace_id=tenant_id,
            mission_topic=request.goal,
            selected_skill_ids=[skill.id for skill in skills],
        )
        plan_ctx["prior_context"] = prior_context_bundle.to_planner_context()
        plan_ctx["prior_context_refs"] = list(prior_context_bundle.prior_context_refs)
    except Exception:
        logger.warning(
            "generate_plan: prior context loading failed tenant=%s goal=%r",
            tenant_id,
            request.goal[:80],
            exc_info=True,
        )

    try:
        from apps.backend.services.skillify import SkillifyService

        skillify_guidance = SkillifyService().planning_guidance_for_goal(tenant_id, request.goal)
        if skillify_guidance["positive"] or skillify_guidance["negative"]:
            plan_ctx["skillify_guidance"] = skillify_guidance
    except Exception:
        logger.warning(
            "generate_plan: skillify guidance loading failed tenant=%s goal=%r",
            tenant_id,
            request.goal[:80],
            exc_info=True,
        )

    _intake_data: dict[str, Any] = {}
    _skill_reuse_summary = SkillReuseSummary()

    raw_intake = request.intake_result
    intake_skipped = bool(plan_ctx.get("intake_skipped"))
    _compiled_intake_result: Any | None = None

    if raw_intake is not None:
        _intake_data = raw_intake
        logger.debug("generate_plan: using caller-supplied intake_result for goal=%r", request.goal[:80])
    elif not request.skills and not intake_skipped:
        try:
            compiled = IntakeCompiler(tenant_id=tenant_id).compile(request.goal)
            _compiled_intake_result = compiled
            _intake_data = {
                "mode": compiled.mode.value,
                "eval_plan": compiled.eval_plan,
                "matched_skills": compiled.matched_skills,
                "matched_entity_schemas": compiled.matched_entity_schemas,
                "matched_entity_records": compiled.matched_entity_records,
                "ontology_consulted": compiled.ontology_consulted,
                "guardrails": compiled.guardrails,
                "approval_gates": compiled.approval_gates,
                "failure_modes": compiled.failure_modes,
                "not_do": compiled.not_do,
                "skillify_decision": compiled.skillify_decision.value,
            }
            matched = compiled.matched_skills
            logger.info(
                "generate_plan: implicit IntakeCompiler compiled goal=%r "
                "mode=%s matched_skills=%d ontology_consulted=%s",
                request.goal[:80],
                compiled.mode.value,
                len(matched),
                compiled.ontology_consulted,
            )
            try:
                from apps.backend.services.zara.execution_event_bus import (
                    get_execution_event_bus,
                )
                bus = get_execution_event_bus(tenant_id=tenant_id)
                bus.emit({
                    "event_type": "evidence:plan_intake_compiled",
                    "tenant_id": tenant_id,
                    "goal": request.goal[:200],
                    "mode": compiled.mode.value,
                    "matched_skill_ids": [s.get("id", s.get("name", "")) for s in matched],
                    "loss_function_applicable": compiled.mode == GoalMode.GRADIENT,
                    "ontology_consulted": compiled.ontology_consulted,
                })
            except Exception:
                logger.debug("generate_plan: decision trace emit failed (non-fatal)", exc_info=True)

            if matched and not skills:
                skills = [
                    SkillSpec(
                        id=str(m.get("id") or m.get("name") or f"skill_{i}"),
                        name=str(m.get("name") or m.get("id") or f"skill_{i}"),
                        description=str(m.get("description") or ""),
                        inputs=list(m.get("inputs") or []),
                        outputs=list(m.get("outputs") or []),
                    )
                    for i, m in enumerate(matched)
                ]
                logger.debug(
                    "generate_plan: injected %d matched skill(s) from ontology into planning context",
                    len(skills),
                )
        except Exception:
            logger.warning(
                "generate_plan: IntakeCompiler.compile() failed (non-fatal, proceeding without intake)",
                exc_info=True,
            )

    if _intake_data:
        matched_skills_raw = list(_intake_data.get("matched_skills") or [])
        matched_entity_schemas_raw = list(_intake_data.get("matched_entity_schemas") or [])
        matched_entity_records_raw = list(_intake_data.get("matched_entity_records") or [])
        ontology_consulted = bool(_intake_data.get("ontology_consulted", True))
        if matched_skills_raw or matched_entity_schemas_raw or matched_entity_records_raw:
            decision = "reuse"
        elif ontology_consulted:
            decision = "new"
        else:
            decision = "new"
        _skill_reuse_summary = SkillReuseSummary(
            matched_skills=matched_skills_raw,
            matched_entity_schemas=matched_entity_schemas_raw,
            matched_entity_records=matched_entity_records_raw,
            ontology_consulted=ontology_consulted,
            decision=decision,
        )

    eval_plan = _intake_data.get("eval_plan") or {}
    intake_mode = _intake_data.get("mode") or ""
    _plan_loss_function: dict[str, Any] | None = None
    if intake_mode == GoalMode.GRADIENT.value and eval_plan.get("method") == "loss_function_with_delta_j":
        _plan_loss_function = {
            "weights": {"task": 0.45, "time": 0.25, "human": 0.05, "risk": 0.15, "cost": 0.10},
            "expected": 0.88,
            "confidence_band": [0.75, 0.94],
            "method": "loss_function_with_delta_j",
            "eval_frequency": eval_plan.get("evaluation_frequency", "weekly"),
        }
    elif intake_mode == GoalMode.HABIT.value:
        _plan_loss_function = {
            "weights": {"task": 0.60, "time": 0.30, "human": 0.05, "risk": 0.05, "cost": 0.00},
            "expected": 0.80,
            "confidence_band": [0.65, 0.90],
            "method": "milestone_rubric",
            "eval_frequency": eval_plan.get("evaluation_frequency", "daily_check_in"),
        }

    _skills_for_planner = [
        {"id": s.id, "name": s.name, "description": s.description, "inputs": s.inputs, "outputs": s.outputs}
        for s in skills
    ]

    _intake_result = _compiled_intake_result or object()
    _effort_decision = PlanEffortPolicy.evaluate(
        _intake_result,
        sensitivity_tier="low",
    )
    plan_ctx["plan_pass_budget"] = _effort_decision.planning_pass_budget
    plan_ctx["plan_eval_thoroughness"] = _effort_decision.eval_thoroughness

    try:
        planner_decision = await SwarmPlannerAgent(
            tenant_id=tenant_id,
            llm_client=svc_for_roles.llm_client,
            evidence_service=svc_for_roles.evidence_service,
        ).decide(
            goal=request.goal,
            connectors=[_model_to_dict(c) for c in request.connectors],
            skills=_skills_for_planner,
            context=plan_ctx,
        )
        if planner_decision.output.decision == "single":
            selected_tool = (
                str(skills[0].id)
                if skills
                else (str(request.connectors[0].id) if request.connectors else "zara")
            )
            plan = GeneratedPlan(
                plan_id=str(ulid.new()),
                goal=request.goal,
                summary=planner_decision.output.reasoning,
                planner_mode=planner_mode,
                steps=[
                    PlanStepSpec(
                        id="step_1",
                        name="Execute objective",
                        connector_or_skill=selected_tool,
                        action=request.goal,
                        inputs={},
                        depends_on=[],
                        success_criteria="Objective completed with evidence.",
                        estimated_duration_seconds=60,
                    )
                ],
            )
        else:
            plan = await engine.generate_plan(
                goal=request.goal,
                available_connectors=connectors,
                available_skills=skills,
                context=plan_ctx,
                mode=planner_mode,
            )
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    response = PlanResponse(
        plan_id=plan.plan_id,
        goal=plan.goal,
        summary=plan.summary,
        planner_mode=plan.planner_mode.value,
        steps=[
            PlanStepResponse(
                id=s.id,
                name=s.name,
                connector_or_skill=s.connector_or_skill,
                action=s.action,
                inputs=s.inputs,
                depends_on=s.depends_on,
                success_criteria=s.success_criteria,
                estimated_duration_seconds=s.estimated_duration_seconds,
                preconditions=list(getattr(s, "preconditions", []) or []),
                step_candidates=[
                    SkillCandidateResponse(
                        skill_id=c.skill_id,
                        name=c.name,
                        capability=c.capability,
                        fit_score=c.fit_score,
                        health_score=c.health_score,
                        queue_depth=c.queue_depth,
                        recent_success_rate=c.recent_success_rate,
                        reasons=c.reasons,
                        metadata=c.metadata,
                    )
                    for c in s.step_candidates
                ],
            )
            for s in plan.steps
        ],
        loss_function=_plan_loss_function if _plan_loss_function is not None else default_loss_function(),
        revision=1,
        status="active",
        skill_reuse_summary=_skill_reuse_summary,
        prior_context_refs=list(prior_context_bundle.prior_context_refs),
        alternatives_considered=list(prior_context_bundle.alternatives_considered),
    )
    plan_steps = _plan_steps_to_dicts(response.steps)
    tenant_config = get_tenant_config(tenant_id)
    sensitivity = SensitivityClassifier().classify_plan(
        goal=response.goal,
        steps=plan_steps,
        tenant_config=tenant_config,
    )
    inverter_payload: dict[str, Any] = {}
    if sensitivity.gate_flags.get("inverter"):
        analysis = await InverterAgent(
            tenant_id=tenant_id,
            llm_client=svc_for_roles.llm_client,
            evidence_service=svc_for_roles.evidence_service,
        ).analyze(
            plan={
                "plan_id": response.plan_id,
                "goal": response.goal,
                "summary": response.summary,
                "steps": plan_steps,
                "sensitivity": sensitivity.to_dict(),
            },
            tenant_context=tenant_config,
            recent_failures=[],
        )
        inverter_payload = analysis.to_plan_payload()

    effort_decision = PlanEffortPolicy.evaluate(
        _intake_result,
        sensitivity_tier=sensitivity.tier,
    )
    effort_policy_dict = effort_decision.to_dict()

    record = get_zara_plan_store().create_plan(
        tenant_id=tenant_id,
        plan_id=response.plan_id,
        goal=response.goal,
        summary=response.summary,
        steps=plan_steps,
        context=plan_ctx,
        loss_function=_model_to_dict(response.loss_function),
        planner_mode=response.planner_mode,
        sensitivity=sensitivity.tier,
        gate_flags=sensitivity.gate_flags,
        inverter=inverter_payload,
        swarm_planner={
            "decision": planner_decision.output.model_dump(mode="json"),
            "source": planner_decision.source,
            "evidence_id": planner_decision.evidence_id,
        },
        skill_reuse_summary=response.skill_reuse_summary.model_dump(mode="json"),
        prior_context_refs=list(prior_context_bundle.prior_context_refs),
        alternatives_considered=list(prior_context_bundle.alternatives_considered),
        effort_policy=effort_policy_dict,
    )
    return _plan_response_from_record(record)


async def revise_plan(
    plan_id: str,
    request: Any,
    tenant_id: str = "",
) -> PlanResponse:
    """Revise a plan by instruction."""
    try:
        record, diff = await _revise_plan_record(
            tenant_id=tenant_id,
            plan_id=plan_id,
            instruction=request.instruction,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Plan not found") from exc
    return _plan_response_from_record(record, diff=diff)


def _plan_steer_trace_id() -> str:
    return f"plan-steer-{ulid.new().str.lower()}"


def _normalize_plan_control_actor(
    *,
    action: str,
    actor_id: str | None,
    actor_source: str | None,
) -> tuple[str, str]:
    source = str(actor_source or "api").strip().lower()
    if source not in {"api", "cli", "mcp", "slack"}:
        raise HTTPException(status_code=422, detail="Unsupported plan control actor source")
    actor = str(actor_id or "").strip()
    if action == "approve":
        if not actor:
            raise HTTPException(status_code=403, detail="Plan approval requires a human actor")
        if source == "mcp" and actor.lower() in {"mcp", "agent", "zara", "system"}:
            raise HTTPException(status_code=403, detail="MCP plan approval requires a member actor_id")
    return actor, source


def _plan_control_source_from_request(request: Request) -> str:
    user_agent = str(request.headers.get("user-agent") or "").strip().lower()
    return "cli" if user_agent.startswith("ww-cli/") else "api"


def _plan_control_idempotency_key(
    *,
    action: str,
    actor_id: str,
    actor_source: str,
    raw_key: str | None,
) -> str | None:
    normalized = str(raw_key or "").strip()
    if not normalized:
        return None
    return f"{action}:{normalized}"


def _plan_approval_revision_idempotency_key(expected_revision: int | None) -> str | None:
    if expected_revision is None:
        return None
    return f"approve:revision:{int(expected_revision)}"


def _require_plan_approve_retry_contract(
    *,
    action: str,
    expected_revision: int | None,
    idempotency_key: str | None,
) -> None:
    if action != "approve":
        return
    if expected_revision is None:
        raise HTTPException(status_code=422, detail="Approve action requires expected_revision")
    if int(expected_revision) < 1:
        raise HTTPException(status_code=422, detail="Approve action requires positive expected_revision")
    if not str(idempotency_key or "").strip():
        raise HTTPException(status_code=422, detail="Approve action requires idempotency_key")


def _idempotent_plan_control_response(current: dict[str, Any], entry: dict[str, Any] | None) -> PlanSteerResponse | None:
    if not isinstance(entry, dict):
        return None
    response = entry.get("response")
    if isinstance(response, dict):
        return PlanSteerResponse(**response)
    return PlanSteerResponse(
        plan_id=str(current.get("plan_id") or ""),
        status=str(current.get("status") or "active"),
        revision=int(current.get("latest_rev") or 1),
        decision_trace_id=str(entry.get("decision_trace_id") or _plan_steer_trace_id()),
        diff=[],
        execution_id=None,
        message="Plan control is already processing.",
    )


def _reserve_plan_control_idempotency(
    *,
    store: Any,
    tenant_id: str,
    plan_id: str,
    key: str | None,
    entry: dict[str, Any],
) -> tuple[bool, dict[str, Any] | None]:
    if not key:
        return True, None
    reserved = store.create_plan_control_idempotency(
        tenant_id=tenant_id,
        plan_id=plan_id,
        key=key,
        entry=entry,
    )
    if reserved:
        return True, None
    return False, store.get_plan_control_idempotency(
        tenant_id=tenant_id,
        plan_id=plan_id,
        key=key,
    )


def _complete_plan_control_idempotency(
    *,
    store: Any,
    tenant_id: str,
    plan_id: str,
    key: str | None,
    fields: dict[str, Any],
) -> None:
    if not key:
        return
    store.update_plan_control_idempotency(
        tenant_id=tenant_id,
        plan_id=plan_id,
        key=key,
        fields=fields,
    )


def _emit_plan_steer_trace(
    *,
    tenant_id: str,
    plan_id: str,
    trace_id: str,
    action: str,
    instruction: str,
    status: str,
    actor_id: str,
    actor_source: str,
    execution_id: str | None = None,
) -> None:
    try:
        from apps.backend.services.evidence_ledger import get_evidence_ledger_service

        get_evidence_ledger_service().ingest(
            tenant_id=tenant_id,
            event_type="evidence:zara_plan_steered",
            data={
                "plan_id": plan_id,
                "action": action,
                "instruction": instruction,
                "status": status,
                "actor_id": actor_id,
                "actor_source": actor_source,
                "execution_id": execution_id,
            },
            decision_trace_id=trace_id,
            actor_path="api.zara.steer_plan",
        )
    except Exception:
        logger.warning("zara.plan_steer_trace_failed plan_id=%s action=%s", plan_id, action, exc_info=True)


async def apply_plan_control(
    *,
    plan_id: str,
    action: str,
    instruction: str | None,
    actor_id: str | None,
    actor_source: str | None,
    tenant_id: str,
    expected_revision: int | None = None,
    idempotency_key: str | None = None,
    execution_context: dict[str, Any] | None = None,
) -> PlanSteerResponse:
    store = get_zara_plan_store()
    current = store.get_plan(tenant_id, plan_id)
    if not current:
        raise HTTPException(status_code=404, detail="Plan not found")

    action = str(action or "").strip()
    instruction = str(instruction or "").strip()
    if action not in {"approve", "steer", "block", "archive"}:
        raise HTTPException(status_code=422, detail="Unsupported plan control action")
    if action == "steer" and not instruction:
        raise HTTPException(status_code=422, detail="Steer action requires instruction")
    _require_plan_approve_retry_contract(
        action=action,
        expected_revision=expected_revision,
        idempotency_key=idempotency_key,
    )
    actor_id, actor_source = _normalize_plan_control_actor(
        action=action,
        actor_id=actor_id,
        actor_source=actor_source,
    )
    idempotency_key = _plan_control_idempotency_key(
        action=action,
        actor_id=actor_id,
        actor_source=actor_source,
        raw_key=idempotency_key,
    )
    duplicate_response = _idempotent_plan_control_response(
        current,
        store.get_plan_control_idempotency(tenant_id=tenant_id, plan_id=plan_id, key=idempotency_key)
        if idempotency_key
        else None,
    )
    if duplicate_response is not None:
        return duplicate_response
    approval_revision_key = _plan_approval_revision_idempotency_key(expected_revision) if action == "approve" else None
    duplicate_response = _idempotent_plan_control_response(
        current,
        store.get_plan_control_idempotency(tenant_id=tenant_id, plan_id=plan_id, key=approval_revision_key)
        if approval_revision_key
        else None,
    )
    if duplicate_response is not None:
        return duplicate_response
    if expected_revision is not None and int(current.get("latest_rev") or 1) != expected_revision:
        raise HTTPException(status_code=409, detail="Plan control is stale")
    trace_id = _plan_steer_trace_id()
    diff: list[dict[str, Any]] = []
    execution_id: str | None = None
    if approval_revision_key:
        reserved, existing_entry = _reserve_plan_control_idempotency(
            store=store,
            tenant_id=tenant_id,
            plan_id=plan_id,
            key=approval_revision_key,
            entry={
                "state": "processing",
                "action": action,
                "actor_id": actor_id,
                "actor_source": actor_source,
                "expected_revision": expected_revision,
                "decision_trace_id": trace_id,
            },
        )
        if not reserved:
            duplicate_response = _idempotent_plan_control_response(current, existing_entry)
            if duplicate_response is not None:
                return duplicate_response
    reserved, existing_entry = _reserve_plan_control_idempotency(
        store=store,
        tenant_id=tenant_id,
        plan_id=plan_id,
        key=idempotency_key,
        entry={
            "state": "processing",
            "action": action,
            "actor_id": actor_id,
            "actor_source": actor_source,
            "expected_revision": expected_revision,
            "decision_trace_id": trace_id,
        },
    )
    if not reserved:
        duplicate_response = _idempotent_plan_control_response(current, existing_entry)
        if duplicate_response is not None:
            return duplicate_response
        return PlanSteerResponse(
            plan_id=str(current.get("plan_id") or plan_id),
            status=str(current.get("status") or "active"),
            revision=int(current.get("latest_rev") or 1),
            decision_trace_id=str((existing_entry or {}).get("decision_trace_id") or _plan_steer_trace_id()),
            diff=[],
            execution_id=None,
            message="Plan control is already processing.",
        )

    if action == "steer":
        record, diff = await _revise_plan_record(
            tenant_id=tenant_id,
            plan_id=plan_id,
            instruction=instruction,
        )
        record = store.update_plan_fields(
            tenant_id=tenant_id,
            plan_id=plan_id,
            fields={
                "last_control_actor_id": actor_id,
                "last_control_actor_source": actor_source,
            },
        )
        message = "Plan updated from channel steering."
    elif action in {"block", "archive"}:
        status_value = "blocked" if action == "block" else "archived"
        diff = [
            {
                "type": "status_changed",
                "before": current.get("status") or "active",
                "after": status_value,
                "instruction": instruction,
                "actor_id": actor_id,
                "actor_source": actor_source,
            }
        ]
        record = store.save_revision(
            tenant_id=tenant_id,
            plan_id=plan_id,
            steps=_plan_steps_to_dicts(current.get("steps") or []),
            instruction=instruction or action,
            diff=diff,
            summary=str(current.get("summary") or ""),
            extra_fields={
                "status": status_value,
                "last_control_actor_id": actor_id,
                "last_control_actor_source": actor_source,
            },
        )
        message = "Plan blocked." if action == "block" else "Plan archived."
    else:
        record = store.save_revision(
            tenant_id=tenant_id,
            plan_id=plan_id,
            steps=_plan_steps_to_dicts(current.get("steps") or []),
            instruction=instruction or "approved",
            diff=[
                {
                    "type": "status_changed",
                    "before": current.get("status") or "active",
                    "after": "approved",
                    "instruction": instruction,
                    "actor_id": actor_id,
                    "actor_source": actor_source,
                }
            ],
            summary=str(current.get("summary") or ""),
            extra_fields={
                "status": "approved",
                "approved_by": actor_id,
                "approved_via": actor_source,
                "last_control_actor_id": actor_id,
                "last_control_actor_source": actor_source,
            },
        )
        execution = await execute_plan(
            ExecutePlanRequest(
                plan_id=plan_id,
                plan_rev=int(record.get("latest_rev") or 1),
                context={
                    "source": "zara_plan_steer",
                    "decision_trace_id": trace_id,
                    "approved_by": actor_id,
                    "approved_via": actor_source,
                    **dict(execution_context or {}),
                },
                explicit_approval=True,
            ),
            tenant_id=tenant_id,
        )
        execution_id = execution.execution_id
        diff = list(record.get("revisions", [])[-1].get("diff") or [])
        message = "Plan approved and handed to governed execution."

    _emit_plan_steer_trace(
        tenant_id=tenant_id,
        plan_id=plan_id,
        trace_id=trace_id,
        action=action,
        instruction=instruction,
        status=str(record.get("status") or "active"),
        actor_id=actor_id,
        actor_source=actor_source,
        execution_id=execution_id,
    )
    response = PlanSteerResponse(
        plan_id=plan_id,
        status=str(record.get("status") or "active"),
        revision=int(record.get("latest_rev") or record.get("revision") or 1),
        decision_trace_id=trace_id,
        diff=diff,
        execution_id=execution_id,
        message=message,
    )
    _complete_plan_control_idempotency(
        store=store,
        tenant_id=tenant_id,
        plan_id=plan_id,
        key=idempotency_key,
        fields={
            "state": "completed",
            "action": action,
            "actor_id": actor_id,
            "actor_source": actor_source,
            "expected_revision": expected_revision,
            "decision_trace_id": trace_id,
            "response": response.model_dump(mode="json"),
        },
    )
    _complete_plan_control_idempotency(
        store=store,
        tenant_id=tenant_id,
        plan_id=plan_id,
        key=approval_revision_key,
        fields={
            "state": "completed",
            "action": action,
            "actor_id": actor_id,
            "actor_source": actor_source,
            "expected_revision": expected_revision,
            "decision_trace_id": trace_id,
            "response": response.model_dump(mode="json"),
        },
    )
    return response


async def steer_plan(
    plan_id: str,
    request: PlanSteerRequest,
    http_request: Request,
    tenant_id: str = "",
    authenticated_user_id: str = "",
) -> PlanSteerResponse:
    return await apply_plan_control(
        plan_id=plan_id,
        action=request.action,
        instruction=request.instruction,
        actor_id=authenticated_user_id,
        actor_source=_plan_control_source_from_request(http_request),
        tenant_id=tenant_id,
        expected_revision=request.expected_revision,
        idempotency_key=request.idempotency_key,
    )


async def decide_plan_mitigation(
    plan_id: str,
    mitigation_id: str,
    request: PlanMitigationRequest,
    tenant_id: str = "",
) -> PlanResponse:
    from apps.backend.services.zara.inverter_agent import apply_mitigation_decision

    store = get_zara_plan_store()
    current = store.get_plan(tenant_id, plan_id)
    if not current:
        raise HTTPException(status_code=404, detail="Plan not found")
    try:
        updated, selected = apply_mitigation_decision(
            current,
            mitigation_id=mitigation_id,
            decision=request.decision,
        )
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Mitigation not found") from exc
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc

    previous_steps = _plan_steps_to_dicts(current.get("steps") or [])
    updated_steps = _plan_steps_to_dicts(updated.get("steps") or [])
    diff = build_step_diff(previous_steps, updated_steps)
    record = store.save_revision(
        tenant_id=tenant_id,
        plan_id=plan_id,
        steps=updated_steps,
        instruction=f"mitigation {mitigation_id} {request.decision}",
        diff=diff,
        summary=str(current.get("summary") or ""),
        extra_fields={"inverter": updated.get("inverter") or {}},
    )
    if request.decision == "request_revision":
        mitigation = str(selected.get("mitigation") or selected.get("description") or mitigation_id)
        record, diff = await _revise_plan_record(
            tenant_id=tenant_id,
            plan_id=plan_id,
            instruction=f"Address mitigation {mitigation_id}: {mitigation}",
        )
    return _plan_response_from_record(record, diff=diff)


async def list_plans(
    status_filter: str | None = None,
    limit: int = 50,
    cursor: str | None = None,
    tenant_id: str = "",
) -> PlanListResponse:
    if status_filter and status_filter not in {"active", "approved", "blocked", "archived", "completed", "cancelled", "failed"}:
        raise HTTPException(status_code=422, detail="Unsupported plan status")
    result = get_zara_plan_store().list_plans(tenant_id, status=status_filter, limit=limit, cursor=cursor)
    return PlanListResponse(
        plans=[_plan_list_item(plan) for plan in result["plans"]],
        next_cursor=result.get("next_cursor"),
    )


async def get_plan_detail(
    plan_id: str,
    tenant_id: str = "",
) -> PlanDetailResponse:
    store = get_zara_plan_store()
    record = store.get_plan(tenant_id, plan_id)
    if not record:
        raise HTTPException(status_code=404, detail="Plan not found")
    executions = store.list_executions_for_plan(tenant_id, plan_id)
    return PlanDetailResponse(
        plan=_plan_response_from_record(record),
        revisions=[PlanRevisionResponse(**item) for item in list(record.get("revisions") or [])],
        executions=[_execution_response_from_record(item) for item in executions if item],
    )


async def execute_plan(
    request: ExecutePlanRequest,
    tenant_id: str = "",
) -> ExecutePlanResponse:
    """Start execution for a persisted plan and stream progress separately."""
    store = get_zara_plan_store()
    stored_plan = store.get_plan(tenant_id, request.plan_id)
    if not stored_plan and not request.steps:
        raise HTTPException(status_code=404, detail="Plan not found")
    if stored_plan:
        plan = dict(stored_plan)
    else:
        plan = {
            "plan_id": request.plan_id,
            "goal": request.goal or "",
            "summary": "",
            "steps": _plan_steps_to_dicts(request.steps),
            "latest_rev": request.plan_rev or 1,
            "loss_function": default_loss_function(),
            "sensitivity": "low",
            "gate_flags": {},
            "inverter": {},
            "swarm_planner": {},
            "status": "active",
        }
        store.create_plan(
            tenant_id=tenant_id,
            plan_id=request.plan_id,
            goal=request.goal or request.plan_id,
            summary="",
            steps=_plan_steps_to_dicts(request.steps),
            context=request.context,
            loss_function=default_loss_function(),
        )

    if request.plan_rev and int(plan.get("latest_rev") or 1) != request.plan_rev:
        raise HTTPException(status_code=409, detail="Plan revision is stale")
    gate_flags = plan.get("gate_flags") if isinstance(plan.get("gate_flags"), dict) else {}
    if gate_flags.get("requires_explicit_approval") and not request.explicit_approval:
        raise HTTPException(status_code=409, detail="This plan requires explicit approval before execution")

    execution_id = f"exec_{ulid.new().str}"
    store.create_execution(
        tenant_id=tenant_id,
        execution_id=execution_id,
        plan_id=request.plan_id,
        plan_rev=int(plan.get("latest_rev") or request.plan_rev or 1),
        context=request.context,
    )
    task = asyncio.create_task(
        _run_plan_execution(
            tenant_id=tenant_id,
            execution_id=execution_id,
            plan=plan,
            context=request.context,
        )
    )
    if hasattr(task, "add_done_callback"):
        task.add_done_callback(_log_background_execution_failure)
    return ExecutePlanResponse(
        execution_id=execution_id,
        status="accepted",
        step_results={},
    )


async def get_execution_status(
    execution_id: str,
    tenant_id: str = "",
) -> ExecutionStatusResponse:
    record = get_zara_plan_store().get_execution(tenant_id, execution_id)
    if not record:
        raise HTTPException(status_code=404, detail="Execution not found")
    return _execution_response_from_record(record)


async def stream_execution(
    execution_id: str,
    tenant_id: str = "",
    last_event_id: str | None = None,
) -> StreamingResponse:
    record = get_zara_plan_store().get_execution(tenant_id, execution_id)
    if not record:
        raise HTTPException(status_code=404, detail="Execution not found")
    bus = get_execution_event_bus()
    persisted = list(record.get("events") or [])
    if not bus.history(execution_id):
        for event in persisted:
            bus.publish(event)

    async def _events() -> Any:
        count = 0
        async for event in bus.subscribe(execution_id, last_event_id=last_event_id):
            count += 1
            yield format_sse(event)
        if count == 0:
            yield ": stream closed\n\n"

    return StreamingResponse(
        _events(),
        media_type="text/event-stream",
        headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"},
    )


async def cancel_execution(
    execution_id: str,
    tenant_id: str = "",
) -> ExecutionCancelResponse:
    store = get_zara_plan_store()
    execution = store.get_execution(tenant_id, execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")
    get_execution_event_bus().cancel(execution_id)
    record = store.mark_cancel_requested(tenant_id=tenant_id, execution_id=execution_id)
    started_step_ids = _started_execution_step_ids(execution)
    plan = store.get_plan(tenant_id, str(record.get("plan_id") or "")) or {}
    for idx, step in enumerate(_plan_steps_to_dicts(plan.get("steps") or [])):
        step_id = _plan_step_id(step, idx)
        if step_id in started_step_ids:
            continue
        _record_execution_event(
            tenant_id=tenant_id,
            event=build_execution_event(
                "step.cancelled",
                execution_id=execution_id,
                plan_id=str(record.get("plan_id") or ""),
                step_id=step_id,
                message="Step cancelled before start",
            ),
        )
    _record_execution_event(
        tenant_id=tenant_id,
        event=build_execution_event(
            "execution.cancel_requested",
            execution_id=execution_id,
            plan_id=str(record.get("plan_id") or ""),
            message="Cancel requested",
        ),
    )
    return ExecutionCancelResponse(execution_id=execution_id, status="cancelling")


async def steer_execution(
    execution_id: str,
    request: ExecutionSteerRequest,
    tenant_id: str = "",
) -> ExecutionSteerResponse:
    store = get_zara_plan_store()
    execution = store.get_execution(tenant_id, execution_id)
    if not execution:
        raise HTTPException(status_code=404, detail="Execution not found")
    revision_payload: dict[str, Any] = {}
    plan_id = str(execution.get("plan_id") or "")
    if plan_id:
        try:
            revised, diff = await _revise_plan_record(
                tenant_id=tenant_id,
                plan_id=plan_id,
                instruction=request.instruction,
                locked_step_ids=_started_execution_step_ids(execution),
            )
            revision_payload = {
                "plan_rev": revised.get("latest_rev"),
                "diff": diff,
                "steps": revised.get("steps") or [],
            }
        except KeyError:
            revision_payload = {}
    try:
        record = store.append_steer(tenant_id=tenant_id, execution_id=execution_id, instruction=request.instruction)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail="Execution not found") from exc
    _record_execution_event(
        tenant_id=tenant_id,
        event=build_execution_event(
            "execution.steered",
            execution_id=execution_id,
            plan_id=str(record.get("plan_id") or ""),
            message="Execution steering received",
            payload={"instruction": request.instruction, **revision_payload},
        ),
    )
    return ExecutionSteerResponse(
        execution_id=execution_id,
        status=str(record.get("status") or "running"),
        instruction=request.instruction,
    )
