"""Cross-tenant Zara coordination REST surface (issue #3625 / family J).

Three endpoints, all gated by per-tenant ADMIN role + the
``AdminPermission.ZARA_COORDINATE_WRITE`` scope:

- ``POST /api/v1/zara/coordinate`` — dispatch a directive to one other Zara
  in the caller's org. Status 202 + a ``CoordinationReceipt`` envelope.
- ``GET /api/v1/zara/coordinate/{coordination_id}`` — read merged status +
  lease view for the given coordination.
- ``POST /api/v1/zara/coordinate/broadcast`` — broadcast a directive to
  every sub-tenant Zara in the caller's org (optionally narrowed by
  ``target_emails``). Status 202 + a list of receipts.

All cross-org calls are refused at the lease layer via
:meth:`PermissionService._assert_same_org`. The receiving Zara's existing
preflight, policy, and consent layers are preserved — the directive flows
through them via the standard work-dispatch path, not around them.
"""

from __future__ import annotations

import logging
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_email,
    require_admin_user_role,
)
from apps.backend.services.admin.admin_permission import AdminPermission
from apps.backend.services.zara.coordination_service import (
    CoordinationError,
    CoordinationReceipt,
    DEFAULT_PAIR_DAILY_CAP,
    RateLimitedError,
    ZaraCoordinationService,
)
from apps.backend.services.zara.coordination_store import (
    CoordinationStore,
    get_default_coordination_store,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/zara/coordinate", tags=["zara-coordination"])

# Module-level permission dependency callables. Captured once so FastAPI
# dependency_overrides in tests can replace the exact closures used in the
# route signatures below. Codex review #3633 F3: route-level permission
# enforcement turns the PERMISSION_REGISTRY entries into binding contracts.
_require_zara_coordinate_write = require_admin_permission_dep(
    AdminPermission.ZARA_COORDINATE_WRITE
)
_require_zara_coordinate_read = require_admin_permission_dep(
    AdminPermission.ZARA_COORDINATE_READ
)

# Re-export the default cap so tests can seed the rate-limit counter without
# hardcoding the number on both sides.
__all__ = [
    "router",
    "DEFAULT_PAIR_DAILY_CAP",
    "_require_zara_coordinate_read",
    "_require_zara_coordinate_write",
]


# ---------------------------------------------------------------------------
# Dependency hooks — overridable in tests via FastAPI's dependency_overrides.
# ---------------------------------------------------------------------------


def _get_permission_service() -> Any:
    """Return the canonical capability-lease permission service."""

    from apps.backend.services.capability_lease import get_permission_service

    return get_permission_service()


def _get_coordination_store() -> CoordinationStore:
    """Return the canonical coordination store.

    Production wires the PortableStore-backed
    :class:`DurableCoordinationStore` so coordination records and per-pair
    rate-limit counters survive process restarts (the in-memory store
    that previously shipped here reset on every redeploy and made the
    audit trail and rate-limit cap meaningless across workers). Tests
    inject :class:`InMemoryCoordinationStore` via FastAPI
    ``dependency_overrides``.
    """

    global _COORDINATION_STORE_SINGLETON
    if _COORDINATION_STORE_SINGLETON is None:
        _COORDINATION_STORE_SINGLETON = get_default_coordination_store()
    return _COORDINATION_STORE_SINGLETON


def _get_dispatch_service() -> Any:
    """Return the agent dispatch service."""

    from apps.backend.services.agent_dispatch import AgentDispatchService

    return AgentDispatchService()


def _get_decision_capture() -> Any:
    """Return the decision event capture service."""

    from apps.backend.services.context.decision_event_capture import (
        DecisionEventCaptureService,
    )

    return DecisionEventCaptureService()


def _get_org_query() -> Any:
    """Return an adapter exposing ``query_org_tenants(org_id)``."""

    from apps.backend.services.org_provisioning import get_org_provisioning_service

    service = get_org_provisioning_service()
    return _OrgQueryAdapter(service)


def _get_policy_provider() -> Any:
    """Return an adapter exposing ``get_policy(target_tenant_id)``."""

    return _TenantConfigPolicyProvider()


# ---------------------------------------------------------------------------
# Adapters bridging the service to existing seams.
# ---------------------------------------------------------------------------


class _OrgQueryAdapter:
    """Thin facade exposing :meth:`list_org_tenants` to the service.

    Uses the public ``list_org_tenants`` accessor on
    :class:`OrgProvisioningService` so the coordination service never
    depends on internal method names. ``list_org_tenants`` is the same
    GSI_TENANTS_BY_ORG read used by sub-tenant counting.
    """

    def __init__(self, provisioning_service: Any) -> None:
        self._service = provisioning_service

    def query_org_tenants(self, org_id: str) -> list[dict[str, Any]]:
        return self._service.list_org_tenants(org_id)


class _TenantConfigPolicyProvider:
    """Resolve ``zara.coordinate.policy`` from the tenant config helper."""

    def get_policy(self, tenant_id: str) -> str:
        from apps.backend.services.tenant_config import get_tenant_config

        config = get_tenant_config(tenant_id) or {}
        zara = config.get("zara") if isinstance(config, dict) else None
        coordinate = (zara or {}).get("coordinate") if isinstance(zara, dict) else None
        policy = (coordinate or {}).get("policy") if isinstance(coordinate, dict) else None
        return str(policy or "auto_accept").strip().lower()


_COORDINATION_STORE_SINGLETON: CoordinationStore | None = None


# ---------------------------------------------------------------------------
# Wire-format payloads
# ---------------------------------------------------------------------------


class CoordinateRequest(BaseModel):
    target_tenant_id: str = Field(..., min_length=1, max_length=128)
    directive: str = Field(..., min_length=1, max_length=4096)
    intent_class: str = Field("KNOWLEDGE_WORK", min_length=1, max_length=64)


class BroadcastRequest(BaseModel):
    directive: str = Field(..., min_length=1, max_length=4096)
    intent_class: str = Field("KNOWLEDGE_WORK", min_length=1, max_length=64)
    target_emails: list[str] | None = Field(default=None, max_length=128)


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


def _build_service(
    permission_service: Any,
    coordination_store: CoordinationStore,
    dispatch_service: Any,
    decision_capture: Any,
    org_query: Any,
    policy_provider: Any,
) -> ZaraCoordinationService:
    """Assemble a coordination service from the resolved adapters.

    Factored out so handlers stay small and so tests can replace any single
    adapter via FastAPI ``dependency_overrides``.
    """

    return ZaraCoordinationService(
        permission_service=permission_service,
        org_query=org_query,
        dispatch_service=dispatch_service,
        decision_capture=decision_capture,
        policy_provider=policy_provider,
        coordination_store=coordination_store,
    )


def _raise_coord_error(exc: CoordinationError) -> None:
    """Translate a coordination error into FastAPI's HTTPException shape."""

    detail: dict[str, Any] = {"error_code": exc.error_code, "message": exc.message}
    headers: dict[str, str] | None = None
    if isinstance(exc, RateLimitedError):
        headers = {"Retry-After": str(exc.retry_after)}
    raise HTTPException(status_code=exc.status_code, detail=detail, headers=headers)


@router.post("", status_code=status.HTTP_202_ACCEPTED)
async def coordinate(
    body: CoordinateRequest,
    admin_role: Annotated[Any, Depends(require_admin_user_role)] = None,
    _perm: Annotated[Any, Depends(_require_zara_coordinate_write)] = None,
    tenant_id: Annotated[str, Depends(get_verified_tenant_id)] = "",
    user_email: Annotated[str, Depends(get_verified_user_email)] = "",
    permission_service: Annotated[Any, Depends(_get_permission_service)] = None,
    coordination_store: Annotated[Any, Depends(_get_coordination_store)] = None,
    dispatch_service: Annotated[Any, Depends(_get_dispatch_service)] = None,
    decision_capture: Annotated[Any, Depends(_get_decision_capture)] = None,
    org_query: Annotated[Any, Depends(_get_org_query)] = None,
    policy_provider: Annotated[Any, Depends(_get_policy_provider)] = None,
) -> dict[str, Any]:
    """Coordinate a directive into one other Zara in the caller's org."""

    del admin_role, _perm

    service = _build_service(
        permission_service,
        coordination_store,
        dispatch_service,
        decision_capture,
        org_query,
        policy_provider,
    )

    try:
        receipt: CoordinationReceipt = service.coordinate(
            source_tenant_id=tenant_id,
            target_tenant_id=body.target_tenant_id,
            directive=body.directive,
            intent_class=body.intent_class,
            actor_email=user_email or "",
        )
    except CoordinationError as exc:
        _raise_coord_error(exc)
    return receipt.to_dict()


@router.get("/{coordination_id}")
async def get_coordination_status(
    coordination_id: str,
    admin_role: Annotated[Any, Depends(require_admin_user_role)] = None,
    _perm: Annotated[Any, Depends(_require_zara_coordinate_read)] = None,
    tenant_id: Annotated[str, Depends(get_verified_tenant_id)] = "",
    permission_service: Annotated[Any, Depends(_get_permission_service)] = None,
    coordination_store: Annotated[Any, Depends(_get_coordination_store)] = None,
    dispatch_service: Annotated[Any, Depends(_get_dispatch_service)] = None,
    decision_capture: Annotated[Any, Depends(_get_decision_capture)] = None,
    org_query: Annotated[Any, Depends(_get_org_query)] = None,
    policy_provider: Annotated[Any, Depends(_get_policy_provider)] = None,
) -> dict[str, Any]:
    """Return merged status + lease view for one coordination."""

    del admin_role, _perm

    service = _build_service(
        permission_service,
        coordination_store,
        dispatch_service,
        decision_capture,
        org_query,
        policy_provider,
    )

    try:
        return service.get_status(
            coordination_id=coordination_id, caller_tenant_id=tenant_id
        )
    except CoordinationError as exc:
        _raise_coord_error(exc)
        return {}  # unreachable; satisfies type checker


@router.post("/broadcast", status_code=status.HTTP_202_ACCEPTED)
async def broadcast(
    body: BroadcastRequest,
    admin_role: Annotated[Any, Depends(require_admin_user_role)] = None,
    _perm: Annotated[Any, Depends(_require_zara_coordinate_write)] = None,
    tenant_id: Annotated[str, Depends(get_verified_tenant_id)] = "",
    user_email: Annotated[str, Depends(get_verified_user_email)] = "",
    permission_service: Annotated[Any, Depends(_get_permission_service)] = None,
    coordination_store: Annotated[Any, Depends(_get_coordination_store)] = None,
    dispatch_service: Annotated[Any, Depends(_get_dispatch_service)] = None,
    decision_capture: Annotated[Any, Depends(_get_decision_capture)] = None,
    org_query: Annotated[Any, Depends(_get_org_query)] = None,
    policy_provider: Annotated[Any, Depends(_get_policy_provider)] = None,
) -> dict[str, Any]:
    """Broadcast a directive to every sub-tenant Zara in the caller's org."""

    del admin_role, _perm

    service = _build_service(
        permission_service,
        coordination_store,
        dispatch_service,
        decision_capture,
        org_query,
        policy_provider,
    )

    try:
        receipts = service.broadcast(
            source_tenant_id=tenant_id,
            directive=body.directive,
            intent_class=body.intent_class,
            actor_email=user_email or "",
            target_emails=body.target_emails,
        )
    except CoordinationError as exc:
        _raise_coord_error(exc)
        receipts = []  # unreachable
    return {
        "count": len(receipts),
        "receipts": [r.to_dict() for r in receipts],
    }
