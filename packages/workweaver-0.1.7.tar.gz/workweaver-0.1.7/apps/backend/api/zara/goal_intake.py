"""Zara goal-intake API surface.

Issue: #1064

Exposes ``POST /api/v1/zara/goal/intake`` — the thin HTTP wrapper around
:class:`apps.backend.services.goal_intake_interviewer.GoalIntakeInterviewer`.

The sub-router uses a relative prefix (``/goal``) and is mounted inside the
parent Zara router (``/api/v1/zara``) via ``include_router`` so the final URL
is ``POST /api/v1/zara/goal/intake``.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.goal_intake_interviewer import (
    GoalIntakeInterviewer,
    GoalIntakeResult,
    LossFunction,
    get_goal_intake_interviewer,
)

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class GoalIntakeRequest(BaseModel):
    """Request body for goal intake classification."""

    goal_text: str = Field(
        ...,
        description="Raw user-supplied goal statement.",
        min_length=1,
        max_length=2000,
    )


class LossFunctionResponse(BaseModel):
    """JSON shape of a :class:`LossFunction`."""

    primary_metric: str
    target_value: float
    unit: str
    counter_metrics: list[str] = Field(default_factory=list)
    time_horizon_days: int


class GoalIntakeResponse(BaseModel):
    """JSON shape of a :class:`GoalIntakeResult`."""

    goal_text: str
    mode: str
    team_structure: str
    loss_function: LossFunctionResponse | None
    blast_radius: str
    interview_questions: list[str]
    confidence: float


# ---------------------------------------------------------------------------
# Router
# ---------------------------------------------------------------------------


router = APIRouter(prefix="/goal", tags=["zara", "goal-intake"])


def _interviewer_factory() -> GoalIntakeInterviewer:
    """Tests patch this to inject a stub interviewer."""
    return get_goal_intake_interviewer()


def _serialise_loss(loss: LossFunction | None) -> LossFunctionResponse | None:
    if loss is None:
        return None
    return LossFunctionResponse(
        primary_metric=loss.primary_metric,
        target_value=loss.target_value,
        unit=loss.unit,
        counter_metrics=list(loss.counter_metrics),
        time_horizon_days=loss.time_horizon_days,
    )


def _serialise_result(result: GoalIntakeResult) -> GoalIntakeResponse:
    return GoalIntakeResponse(
        goal_text=result.goal_text,
        mode=result.mode.value,
        team_structure=result.team_structure.value,
        loss_function=_serialise_loss(result.loss_function),
        blast_radius=result.blast_radius,
        interview_questions=list(result.interview_questions),
        confidence=result.confidence,
    )


@router.post("/intake", response_model=GoalIntakeResponse)
async def goal_intake(
    request: GoalIntakeRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> GoalIntakeResponse:
    """Classify a user-supplied goal statement.

    Returns the structured intake contract (mode, team, loss function,
    follow-up questions) that Zara uses to drive the rest of the goal-cascade
    conversation.
    """
    interviewer = _interviewer_factory()
    try:
        result = interviewer.intake(request.goal_text)
    except ValueError as exc:
        raise HTTPException(status_code=422, detail=str(exc)) from exc
    except Exception as exc:  # pragma: no cover - defensive
        logger.error(
            "Goal intake classification failed tenant=%s: %s",
            tenant_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(status_code=503, detail="Goal intake temporarily unavailable") from exc

    return _serialise_result(result)


__all__ = [
    "router",
    "GoalIntakeRequest",
    "GoalIntakeResponse",
    "LossFunctionResponse",
]
