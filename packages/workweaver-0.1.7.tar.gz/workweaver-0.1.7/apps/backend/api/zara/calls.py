"""Zara-scoped voice call surface.

Thin adapter on top of the existing voice call store and human-transfer queue
that exposes the canonical Zara URLs the admin UI consumes:

- ``GET /api/v1/zara/calls``                   list scoped to caller tenant.
- ``GET /api/v1/zara/calls/{call_id}``         transcript + recording playback.
- ``POST /api/v1/zara/calls/{call_id}/transfer`` enqueue a human transfer.

All endpoints are gated by tenant_admin role plus an explicit
``AdminPermission.CALLS_READ`` / ``CALLS_WRITE`` scope. The transfer endpoint
emits a Decision Trace via DecisionEventCaptureService.
"""

from __future__ import annotations

import logging
from typing import Annotated, Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    require_admin_user_role,
)
from apps.backend.services.admin.admin_permission import AdminPermission
from apps.backend.services.voice.human_transfer_queue import (
    HumanTransferQueue,
    get_human_transfer_queue,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/zara/calls", tags=["zara-calls"])


# ---------------------------------------------------------------------------
# Service accessors (override in tests via FastAPI dependency overrides)
# ---------------------------------------------------------------------------


def _get_call_store() -> Any:
    """Return the canonical call store (DynamoDB in prod, in-memory in tests).

    Indirected so unit tests can swap a fake without monkeypatching the voice
    services module.
    """

    from apps.backend.voice_services.call_control_service import (
        DynamoDBCallStore,
        InMemoryCallStore,
    )
    from apps.backend.config.test_runtime import unit_test_runtime_flag_enabled

    if unit_test_runtime_flag_enabled("WORKWEAVER_UNIT_TEST_DYNAMO_MEMORY"):
        return InMemoryCallStore()
    return DynamoDBCallStore()


def _get_transfer_queue() -> HumanTransferQueue:
    return get_human_transfer_queue()


def _get_decision_capture() -> Any:
    """Return the DecisionEventCaptureService for emitting transfer traces."""

    from apps.backend.services.context.decision_event_capture import (
        DecisionEventCaptureService,
    )

    return DecisionEventCaptureService()


# ---------------------------------------------------------------------------
# Wire-format payloads
# ---------------------------------------------------------------------------


def _call_summary(call: Any) -> dict[str, Any]:
    """Render a ManagedCall as the public Zara payload."""

    return {
        "call_id": str(getattr(call, "call_id", "") or ""),
        "tenant_id": str(getattr(call, "tenant_id", "") or ""),
        "to_number": str(getattr(call, "to_number", "") or ""),
        "from_number": str(getattr(call, "from_number", "") or ""),
        "mode": getattr(getattr(call, "mode", None), "value", str(getattr(call, "mode", "") or "")),
        "state": getattr(getattr(call, "state", None), "value", str(getattr(call, "state", "") or "")),
        "provider": str(getattr(call, "provider", "") or ""),
        "started_at": str(getattr(call, "started_at", "") or ""),
        "updated_at": str(getattr(call, "updated_at", "") or ""),
        "quality_score": getattr(call, "quality_score", None),
        "recording_ref": str(getattr(call, "recording_ref", "") or ""),
        "transcript_ref": str(getattr(call, "transcript_ref", "") or ""),
    }


def _call_detail(call: Any) -> dict[str, Any]:
    """Render a ManagedCall with transcript + recording fields."""

    base = _call_summary(call)
    base.update(
        {
            "participants": list(getattr(call, "participants", []) or []),
            "transcript_segments": list(getattr(call, "transcript_segments", []) or []),
            "session_chain": list(getattr(call, "session_chain", []) or []),
            "mode_history": list(getattr(call, "mode_history", []) or []),
            "metadata": dict(getattr(call, "metadata", {}) or {}),
            "playback_url": f"/api/v1/voice/calls/{base['call_id']}/playback" if base["call_id"] else "",
        }
    )
    return base


class TransferRequest(BaseModel):
    """Payload for a human-transfer enqueue request."""

    queue: str = Field("default", min_length=1, max_length=64, description="Target queue name.")
    reason: str | None = Field(
        None,
        max_length=256,
        description="Free-text rationale for the transfer (audited).",
    )
    priority: int = Field(5, ge=1, le=9, description="Lower number = higher priority.")
    transfer_mode: str = Field(
        "warm",
        pattern=r"^(warm|cold|callback)$",
        description="warm | cold | callback",
    )
    required_skills: list[str] = Field(default_factory=list, max_length=16)


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("")
async def list_zara_calls(
    cursor: Annotated[str | None, Query(description="Opaque pagination cursor.")] = None,
    call_status: Annotated[
        str | None,
        Query(alias="status", description="Filter by call state, for example 'ENDED'."),
    ] = None,
    since: Annotated[str | None, Query(description="ISO timestamp lower bound (started_at).")] = None,
    limit: Annotated[int, Query(ge=1, le=200, description="Max items per page.")] = 50,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.CALLS_READ)),
    tenant_id: str = Depends(get_verified_tenant_id),
    call_store=Depends(_get_call_store),
) -> dict[str, Any]:
    """Return a paginated list of calls owned by the caller's tenant."""

    del admin_role
    try:
        calls = call_store.list_calls(tenant_id)
    except Exception as exc:  # noqa: BLE001 — surface as 503 so the UI can retry.
        logger.error("zara_calls.list_failed tenant=%s error=%s", tenant_id, exc, exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Call store unavailable.",
        ) from exc

    rows = [_call_summary(call) for call in calls or []]
    if call_status:
        rows = [row for row in rows if row["state"].lower() == call_status.lower()]
    if since:
        rows = [row for row in rows if row["started_at"] >= since]

    # Sort newest first by started_at, then apply cursor-based pagination.
    rows.sort(key=lambda row: row["started_at"], reverse=True)

    try:
        offset = max(0, int(cursor)) if cursor else 0
    except ValueError:
        offset = 0
    page = rows[offset : offset + limit]
    next_cursor = str(offset + limit) if offset + limit < len(rows) else None
    return {
        "tenant_id": tenant_id,
        "calls": page,
        "count": len(page),
        "total_count": len(rows),
        "next_cursor": next_cursor,
    }


@router.get("/{call_id}")
async def get_zara_call(
    call_id: str,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.CALLS_READ)),
    tenant_id: str = Depends(get_verified_tenant_id),
    call_store=Depends(_get_call_store),
) -> dict[str, Any]:
    """Return one call's full transcript + recording reference."""

    del admin_role
    try:
        call = call_store.get_call(call_id)
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "zara_calls.get_failed tenant=%s call=%s error=%s",
            tenant_id,
            call_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Call store unavailable.",
        ) from exc

    if call is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Call {call_id} not found")
    if str(getattr(call, "tenant_id", "")) != tenant_id:
        # Return 404 (not 403) to avoid leaking call existence across tenants.
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Call {call_id} not found")
    return _call_detail(call)


@router.post("/{call_id}/transfer")
async def transfer_zara_call(
    call_id: str,
    body: TransferRequest,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.CALLS_WRITE)),
    tenant_id: str = Depends(get_verified_tenant_id),
    call_store=Depends(_get_call_store),
    transfer_queue: HumanTransferQueue = Depends(_get_transfer_queue),
    decision_capture=Depends(_get_decision_capture),
) -> dict[str, Any]:
    """Enqueue a human transfer for the given call and emit a decision trace."""

    del admin_role
    try:
        call = call_store.get_call(call_id)
    except Exception as exc:  # noqa: BLE001
        logger.error(
            "zara_calls.transfer_lookup_failed tenant=%s call=%s error=%s",
            tenant_id,
            call_id,
            exc,
            exc_info=True,
        )
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail="Call store unavailable.",
        ) from exc

    if call is None or str(getattr(call, "tenant_id", "")) != tenant_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Call {call_id} not found")

    entry = transfer_queue.enqueue(
        tenant_id=tenant_id,
        call_id=call_id,
        reason=body.reason or "human_requested",
        priority=body.priority,
        required_skills=list(body.required_skills),
        transfer_mode=body.transfer_mode,
        transfer_context={"queue": body.queue},
    )

    # Best-effort decision trace — never fail the transfer on capture failure.
    try:
        decision_capture.capture_decision(
            tenant_id=tenant_id,
            skill_id="voice.transfer",
            decision_summary=f"Transferred call {call_id} to queue {body.queue}",
            decision_type="voice_transfer",
            outcome="enqueued",
            entity_ids=[call_id],
            rationale=body.reason,
            context_data={
                "call_id": call_id,
                "queue": body.queue,
                "transfer_mode": body.transfer_mode,
                "priority": body.priority,
                "entry_id": entry.entry_id,
            },
            capture_surface="rest",
            service_family="voice",
        )
    except Exception:  # noqa: BLE001
        logger.warning(
            "zara_calls.transfer_decision_trace_failed tenant=%s call=%s",
            tenant_id,
            call_id,
            exc_info=True,
        )

    return {
        "entry_id": entry.entry_id,
        "call_id": call_id,
        "queue": body.queue,
        "transfer_mode": entry.transfer_mode,
        "priority": entry.priority,
        "status": entry.status,
        "estimated_wait_seconds": transfer_queue.estimate_wait_time(tenant_id),
    }
