"""ChannelMessage REST surface -- list and send messages per channel (#3261).

Provides ``GET`` and ``POST`` endpoints at
``/api/v1/channels/{channel_id}/messages`` for listing and sending
``ChannelMessage``-renderer payloads. Every send emits a Decision Trace
for audit.

Tenant isolation: all queries are scoped to the authenticated tenant.
Allowlist enforcement: sends are gated by the platform channel allowlist.
"""
from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any
from uuid import uuid4

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id


logger = logging.getLogger(__name__)


router = APIRouter(
    prefix="/api/v1/channels/{channel_id}/messages",
    tags=["channels-messages"],
)


# ---------------------------------------------------------------------------
# Message store (in-memory default, swappable for DynamoDB)
# ---------------------------------------------------------------------------

_MESSAGE_STORE: dict[str, list[dict[str, Any]]] | None = None


def _get_message_store() -> dict[str, list[dict[str, Any]]]:
    """Return the message store -- defaults to an in-memory dict."""
    global _MESSAGE_STORE
    if _MESSAGE_STORE is None:
        _MESSAGE_STORE = {}
    return _MESSAGE_STORE


def _is_channel_allowed(channel: str, *, tenant_id: str | None = None) -> bool:
    """Check the channel allowlist. Defaults to delegating to the policy module."""
    try:
        from apps.backend.services.policy.allowlist_adopters import channel_is_allowed

        return channel_is_allowed(channel, tenant_id=tenant_id)
    except Exception:
        # If the policy module is unavailable, deny by default.
        return False


# ---------------------------------------------------------------------------
# Request / response models
# ---------------------------------------------------------------------------


class ChannelBlockPayload(BaseModel):
    """A single block in a channel message payload."""

    block_type: str = Field(..., max_length=50)
    text: str | None = Field(default=None, max_length=3000)
    actions: list[dict[str, str]] | None = None
    image_url: str | None = None
    alt_text: str | None = None
    confidence_level: str | None = Field(default=None, max_length=20)
    slack_elements: list[dict[str, Any]] | None = None
    slack_text_type: str | None = Field(default=None, max_length=20)


class SendMessageRequest(BaseModel):
    """Payload for POST /api/v1/channels/{channel_id}/messages."""

    blocks: list[ChannelBlockPayload] = Field(default_factory=list)
    fallback_text: str = Field(default="", max_length=5000)
    confidence_level: str | None = Field(default=None, max_length=20)


class MessageResponse(BaseModel):
    message_id: str
    channel_id: str
    tenant_id: str
    blocks: list[dict[str, Any]]
    fallback_text: str
    confidence_level: str | None
    decision_trace_id: str
    created_at: str


class MessageListResponse(BaseModel):
    messages: list[MessageResponse]
    count: int


class SendMessageResponse(BaseModel):
    message_id: str
    channel_id: str
    tenant_id: str
    sent: bool
    decision_trace_id: str
    created_at: str


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _store_key(tenant_id: str, channel_id: str) -> str:
    return f"{tenant_id}:{channel_id}"


def _emit_decision_trace(
    *,
    tenant_id: str,
    channel_id: str,
    message_id: str,
    operation: str,
) -> str:
    """Emit a Decision Trace for a channel message operation.

    Returns the trace id. In production this would write to the evidence
    store; for now it generates a deterministic trace id.
    """
    trace_id = f"dt_chmsg_{uuid4().hex[:16]}"
    logger.info(
        "channels_messages.decision_trace tenant=%s channel=%s message_id=%s operation=%s trace_id=%s",
        tenant_id,
        channel_id,
        message_id,
        operation,
        trace_id,
    )
    return trace_id


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("", response_model=MessageListResponse)
async def list_messages(
    channel_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> MessageListResponse:
    """List all messages for a channel, scoped to the authenticated tenant."""
    store = _get_message_store()
    key = _store_key(tenant_id, channel_id)
    entries = store.get(key, [])
    messages = [
        MessageResponse(
            message_id=e["message_id"],
            channel_id=e["channel_id"],
            tenant_id=e["tenant_id"],
            blocks=e["blocks"],
            fallback_text=e["fallback_text"],
            confidence_level=e.get("confidence_level"),
            decision_trace_id=e.get("decision_trace_id", ""),
            created_at=e["created_at"],
        )
        for e in entries
    ]
    return MessageListResponse(messages=messages, count=len(messages))


@router.post("", response_model=SendMessageResponse, status_code=201)
async def send_message(
    channel_id: str,
    request: SendMessageRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SendMessageResponse:
    """Send a message to a channel.

    Allowlist enforcement: the channel must be permitted on the platform
    before the message is accepted.
    """
    # Allowlist gate.
    if not _is_channel_allowed(channel_id, tenant_id=tenant_id):
        raise HTTPException(
            status_code=403,
            detail=f"Channel '{channel_id}' denied by platform allowlist",
        )

    message_id = f"chmsg_{uuid4().hex[:12]}"
    created_at = datetime.now(UTC).isoformat()

    # Emit Decision Trace.
    trace_id = _emit_decision_trace(
        tenant_id=tenant_id,
        channel_id=channel_id,
        message_id=message_id,
        operation="channels.messages.send",
    )

    # Serialize blocks to plain dicts for storage.
    blocks_data = [b.model_dump(exclude_none=True) for b in request.blocks]

    # Persist to store.
    store = _get_message_store()
    key = _store_key(tenant_id, channel_id)
    entry = {
        "message_id": message_id,
        "channel_id": channel_id,
        "tenant_id": tenant_id,
        "blocks": blocks_data,
        "fallback_text": request.fallback_text,
        "confidence_level": request.confidence_level,
        "decision_trace_id": trace_id,
        "created_at": created_at,
    }
    if key not in store:
        store[key] = []
    store[key].append(entry)

    logger.info(
        "channels_messages.send tenant=%s channel=%s message_id=%s trace_id=%s",
        tenant_id,
        channel_id,
        message_id,
        trace_id,
    )

    return SendMessageResponse(
        message_id=message_id,
        channel_id=channel_id,
        tenant_id=tenant_id,
        sent=True,
        decision_trace_id=trace_id,
        created_at=created_at,
    )


__all__ = ["router"]
