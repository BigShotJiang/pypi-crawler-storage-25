"""Briefing API (M9.2) — Briefing Dashboard Surface.

Endpoints:
    GET /api/v1/mission/briefing/daily   — formatted daily briefing
    GET /api/v1/mission/briefing/weekly  — 7-day aggregation

Data source: IntelligenceAggregator.get_daily_briefing()
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/mission/briefing", tags=["briefing"])


# ---------------------------------------------------------------------------
# Dependency
# ---------------------------------------------------------------------------


def _get_intelligence_aggregator():  # type: ignore[return]
    from apps.backend.services.inference_aggregator import get_intelligence_aggregator

    return get_intelligence_aggregator()


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("/daily")
async def get_daily_briefing(
    agent_id: str = Query("default", description="Agent to get briefing for"),
    tenant_id: str = Depends(get_verified_tenant_id),
    aggregator: Any = Depends(_get_intelligence_aggregator),
) -> dict[str, Any]:
    """Return formatted daily briefing for the current tenant.

    Uses IntelligenceAggregator.get_daily_briefing() as data source:
    - developmental context
    - proactive signals
    - pending suggestions
    - growth areas
    - anomalies
    """
    try:
        briefing = await aggregator.get_daily_briefing(tenant_id, agent_id)
    except Exception as exc:
        logger.error("Daily briefing generation failed for %s: %s", tenant_id, exc)
        raise HTTPException(status_code=503, detail="Briefing service temporarily unavailable")

    briefing["briefing_type"] = "daily"
    briefing["tenant_id"] = tenant_id
    return briefing


@router.get("/weekly")
async def get_weekly_briefing(
    agent_id: str = Query("default", description="Agent to get briefing for"),
    tenant_id: str = Depends(get_verified_tenant_id),
    aggregator: Any = Depends(_get_intelligence_aggregator),
) -> dict[str, Any]:
    """Return 7-day aggregated briefing for the current tenant.

    Builds on daily briefing data, aggregated over the past 7 days.
    """
    try:
        # Reuse daily briefing as base, annotate as weekly
        briefing = await aggregator.get_daily_briefing(tenant_id, agent_id)
    except Exception as exc:
        logger.error("Weekly briefing generation failed for %s: %s", tenant_id, exc)
        raise HTTPException(status_code=503, detail="Briefing service temporarily unavailable")

    briefing["briefing_type"] = "weekly"
    briefing["tenant_id"] = tenant_id
    briefing["aggregation_days"] = 7
    return briefing
