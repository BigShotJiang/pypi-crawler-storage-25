"""Authentication shared helpers, config constants, and AWS client singletons.

Extracted from auth.py (Phase 5 tech debt reduction).
"""
from __future__ import annotations

from apps.backend.config.table_names import resolve_table

import asyncio
import logging
import os
from apps.backend.config.environment import get_environment, is_production_like
from apps.backend.config.region import AWS_REGION
from datetime import datetime, UTC
from typing import Any
from fastapi import HTTPException, Response, status

from apps.backend.services.session.browser_session import mint_browser_session_token
from apps.backend.config.pricing import STRIPE_COUPONS, WORKWEAVER_PLANS

from apps.backend.api.auth_models import (
    AuthProvider,
    SignupRegionOption,
    SignupResponse,
)

logger = logging.getLogger(__name__)
# ============================================================================
# AWS Client Singletons
# ============================================================================

# NOTE: This module is imported by the FastAPI app during startup.
# Do not create boto3 clients/resources at import time: local Docker often runs without
# an AWS profile configured (e.g. when using `op run` env injection), and failing here
# prevents *all* endpoints (including /api/zara/ws) from starting.

_cognito_idp = None
_verifications_table = None

SIGNUP_TERMS_VERSION = "1.0"
_PLACEHOLDER_SIGNUP_TERMS_VERSIONS = {
    "",
    "1.0",
    "changeme",
    "placeholder",
    "__fill_me__",
    "example",
}


def spawn_background_task(coro: Any, *, task_name: str, tenant_id: str | None = None) -> None:
    from apps.backend.observability.async_tasks import spawn_background_task as _spawn_background_task

    _spawn_background_task(coro, task_name=task_name, tenant_id=tenant_id)


def _aws_region() -> str:
    return AWS_REGION


def _new_boto3_session():
    import boto3
    from botocore.exceptions import ProfileNotFound

    profile = (os.environ.get("AWS_PROFILE") or os.environ.get("AWS_DEFAULT_PROFILE") or "").strip()
    if profile:
        try:
            return boto3.Session(profile_name=profile, region_name=_aws_region())
        except ProfileNotFound:
            return boto3.Session(region_name=_aws_region())
    return boto3.Session(region_name=_aws_region())


def _is_prod_like_env() -> bool:
    return is_production_like()


def get_signup_terms_version() -> str:
    configured = str(os.environ.get("SIGNUP_TERMS_VERSION", SIGNUP_TERMS_VERSION) or "").strip()
    normalized = configured.lower()
    if configured and normalized not in _PLACEHOLDER_SIGNUP_TERMS_VERSIONS:
        return configured
    if _is_prod_like_env():
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "terms_version_unavailable",
                "message": "Signup terms version is not configured for this environment.",
            },
        )
    return SIGNUP_TERMS_VERSION


def _disable_cognito() -> bool:
    val = os.environ.get("DISABLE_COGNITO", "").strip().lower() in {"1", "true", "yes"}
    if val and os.environ.get("ECS_CONTAINER_METADATA_URI"):
        logger.critical(
            "SECURITY: DISABLE_COGNITO is set in an ECS environment. "
            "This is a critical security misconfiguration. Ignoring the flag."
        )
        return False
    return val


def _disable_dynamo_verifications() -> bool:
    val = os.environ.get("DISABLE_DYNAMO_VERIFICATIONS", "").strip().lower() in {
        "1",
        "true",
        "yes",
    }
    if val and os.environ.get("ECS_CONTAINER_METADATA_URI"):
        logger.critical(
            "SECURITY: DISABLE_DYNAMO_VERIFICATIONS is set in an ECS environment. "
            "This is a critical security misconfiguration. Ignoring the flag."
        )
        return False
    return val


def _allow_test_email_bypass() -> bool:
    val = os.environ.get("ALLOW_TEST_EMAIL_BYPASS", "").strip().lower() in {
        "1",
        "true",
        "yes",
    }
    env = get_environment()
    if val and os.environ.get("ECS_CONTAINER_METADATA_URI"):
        logger.critical(
            "SECURITY: ALLOW_TEST_EMAIL_BYPASS is set in an ECS environment. "
            "This is a critical security misconfiguration. Ignoring the flag."
        )
        return False
    if val and env not in {"dev", "test", "local"}:
        logger.critical(
            "SECURITY: ALLOW_TEST_EMAIL_BYPASS is set outside a local/dev environment (%s). Ignoring the flag.",
            env,
        )
        return False
    return val


def _is_test_email_bypass_address(email: str) -> bool:
    """Restrict local bypass addresses to reserved .test domains only."""
    normalized = email.strip().lower()
    if "@" not in normalized:
        return False
    _, domain = normalized.rsplit("@", 1)
    return bool(domain) and domain.endswith(".test")


def build_signup_consent(
    accepted_terms: bool,
    accepted_privacy: bool,
    *,
    consent_at: str | None = None,
    terms_version: str | None = None,
) -> SignupConsent:
    from apps.backend.services.tenant_provisioning import SignupConsent

    resolved_terms_version = str(terms_version or get_signup_terms_version()).strip()
    if not resolved_terms_version:
        resolved_terms_version = get_signup_terms_version()
    return SignupConsent(
        accepted_terms=accepted_terms,
        accepted_privacy=accepted_privacy,
        consent_at=consent_at or datetime.now(UTC).isoformat(),
        terms_version=resolved_terms_version,
    )


def get_cognito_idp():
    global _cognito_idp
    if _disable_cognito():
        return None
    if _cognito_idp is not None:
        return _cognito_idp
    try:
        # If AWS_PROFILE is set but missing in the container, boto3 will raise ProfileNotFound.
        # Fall back to env credentials (AWS_ACCESS_KEY_ID/AWS_SECRET_ACCESS_KEY) if present.
        session = _new_boto3_session()
        _cognito_idp = session.client("cognito-idp", region_name=_aws_region())
    except Exception:
        logger.exception("Failed to initialize Cognito client")
        _cognito_idp = None
    return _cognito_idp


def get_verifications_table():
    global _verifications_table
    if _disable_dynamo_verifications():
        return None
    if _verifications_table is not None:
        return _verifications_table
    try:
        session = _new_boto3_session()
        dynamodb = session.resource("dynamodb", region_name=_aws_region())
        _verifications_table = dynamodb.Table(resolve_table("verifications"))
    except Exception:
        logger.exception("Failed to initialize DynamoDB verifications table")
        _verifications_table = None
    return _verifications_table


def _redact_email(email: str) -> str:
    """Return a redacted email safe for warning/error logs (L2: no PII in log output)."""
    try:
        local, domain = str(email).split("@", 1)
        return f"{local[:3]}***@{domain}"
    except (ValueError, AttributeError):
        return "***"


def _admin_role_value() -> str:
    from apps.backend.services.tenant_provisioning import UserRole

    return UserRole.ADMIN.value


def get_tenant_provisioning_service():
    from apps.backend.services.tenant_provisioning import (
        get_tenant_provisioning_service as _service_factory,
    )

    return _service_factory()


def get_workweaver_runtime_provisioning_service():
    from apps.backend.services.runtime.provisioning_service import (
        get_workweaver_runtime_provisioning_service as _service_factory,
    )

    return _service_factory()


# ============================================================================
# Configuration
# ============================================================================

USERS_TABLE = resolve_table("users")
TENANTS_TABLE = resolve_table("tenants")
# Region imported from config.region
GOOGLE_SIGNUP_ENABLED = os.environ.get("GOOGLE_SIGNUP_ENABLED", "true").lower() == "true"


def _require_cognito_idp():
    c = get_cognito_idp()
    if c is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "cognito_unavailable",
                "message": "Authentication backend is not available in this environment.",
            },
        )
    return c


def _require_verifications_table():
    t = get_verifications_table()
    if t is None:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "verifications_unavailable",
                "message": "Verification storage is not available in this environment.",
            },
        )
    return t


def _parse_domain_csv(value: str) -> set[str]:
    return {item.strip().lower() for item in value.split(",") if item.strip()}


ALLOWED_PROVISIONING_DOMAINS = _parse_domain_csv(
    os.environ.get(
        "ALLOWED_PROVISIONING_DOMAINS",
        os.environ.get(
            "ALLOWED_PROVISIONING_DOMAIN",
            os.environ.get("INTERNAL_SIGNUP_BYPASS_DOMAINS", "bitfoundry.ai"),
        ),
    )
)
INTERNAL_SIGNUP_BYPASS_DOMAINS = _parse_domain_csv(os.environ.get("INTERNAL_SIGNUP_BYPASS_DOMAINS", "bitfoundry.ai"))
INTERNAL_SIGNUP_SKIP_STRIPE_ENABLED = os.environ.get("INTERNAL_SIGNUP_SKIP_STRIPE_ENABLED", "true").lower() == "true"
INTERNAL_SIGNUP_REGION = os.environ.get("INTERNAL_SIGNUP_REGION", "us-east-1").strip()
DEFAULT_EXTERNAL_SIGNUP_REGION = os.environ.get("DEFAULT_EXTERNAL_SIGNUP_REGION", "us-east-1").strip()
SIGNUP_MONTHLY_PRICE_USD = int(WORKWEAVER_PLANS["launchpad"]["monthly_usd"])
WAITLIST_URL = (
    os.environ.get("WAITLIST_URL", "https://workweaver.ai/waitlist").strip() or "https://workweaver.ai/waitlist"
)


def _parse_region_options(value: str) -> dict[str, str]:
    options: dict[str, str] = {}
    for raw_item in value.split(","):
        item = raw_item.strip()
        if not item:
            continue
        if "|" in item:
            label, code = item.split("|", 1)
        elif ":" in item:
            label, code = item.split(":", 1)
        else:
            code = item
            label = item
        label = label.strip()
        code = code.strip()
        if not label or not code:
            continue
        options[label] = code
    return options


SIGNUP_REGION_OPTIONS = _parse_region_options(
    os.environ.get(
        "SIGNUP_REGION_OPTIONS",
        "US East region|us-east-1,Europe (Frankfurt) region|eu-central-1,Asia Pacific (Singapore) region|ap-southeast-1",
    )
)


def _region_label_for_code(region_code: str) -> str:
    for label, code in SIGNUP_REGION_OPTIONS.items():
        if code == region_code:
            return label
    return region_code


def _resolve_requested_region(preferred_region: str | None) -> str:
    if not preferred_region:
        return DEFAULT_EXTERNAL_SIGNUP_REGION

    normalized = preferred_region.strip().lower()
    if not normalized:
        return DEFAULT_EXTERNAL_SIGNUP_REGION

    for label, code in SIGNUP_REGION_OPTIONS.items():
        if normalized == label.lower() or normalized == code.lower():
            return code

    allowed_regions = ", ".join(SIGNUP_REGION_OPTIONS.keys())
    raise HTTPException(
        status_code=status.HTTP_400_BAD_REQUEST,
        detail={
            "error": "invalid_region",
            "message": f"Unsupported region selection. Choose one of: {allowed_regions}",
            "provided_region": preferred_region,
        },
    )


# ============================================================================
# Provisioning Cookie
# ============================================================================

# Provisioning status polling must not leak tenant identifiers or tokens via URL parameters.
# We store a short-lived token in an HttpOnly cookie scoped to the API domain.
RUNTIME_PROVISIONING_COOKIE_NAME_SECURE = "__Secure-ww-runtime-provisioning"
RUNTIME_PROVISIONING_COOKIE_NAME_LOCAL = "ww-runtime-provisioning"
RUNTIME_PROVISIONING_COOKIE_NAME = RUNTIME_PROVISIONING_COOKIE_NAME_SECURE
RUNTIME_PROVISIONING_COOKIE_NAMES = (
    RUNTIME_PROVISIONING_COOKIE_NAME_SECURE,
    RUNTIME_PROVISIONING_COOKIE_NAME_LOCAL,
)
BROWSER_SESSION_COOKIE_NAME_SECURE = "__Secure-ww-browser-session"
BROWSER_SESSION_COOKIE_NAME_LOCAL = "ww-browser-session"
BROWSER_SESSION_COOKIE_NAME = BROWSER_SESSION_COOKIE_NAME_SECURE
BROWSER_SESSION_COOKIE_NAMES = (
    BROWSER_SESSION_COOKIE_NAME_SECURE,
    BROWSER_SESSION_COOKIE_NAME_LOCAL,
)


def _provisioning_cookie_write_name() -> str:
    return RUNTIME_PROVISIONING_COOKIE_NAME_LOCAL if _disable_cognito() else RUNTIME_PROVISIONING_COOKIE_NAME_SECURE


def _browser_session_cookie_write_name() -> str:
    return BROWSER_SESSION_COOKIE_NAME_LOCAL if _disable_cognito() else BROWSER_SESSION_COOKIE_NAME_SECURE


def _set_browser_session_cookie(
    resp: Response,
    *,
    tenant_id: str,
    user_id: str,
    email: str,
    ttl_seconds: int = 12 * 60 * 60,
) -> None:
    token = mint_browser_session_token(
        tenant_id=tenant_id,
        user_id=user_id,
        email=email,
        ttl_seconds=ttl_seconds,
    )
    cookie_name = _browser_session_cookie_write_name()
    max_age = max(int(ttl_seconds), 60)
    if _disable_cognito():
        resp.set_cookie(
            key=cookie_name,
            value=token,
            httponly=True,
            secure=False,
            samesite="lax",
            max_age=max_age,
            path="/",
        )
        return

    resp.set_cookie(
        key=cookie_name,
        value=token,
        httponly=True,
        secure=True,
        samesite="none",
        max_age=max_age,
        path="/",
        domain=".workweaver.ai",
    )


def _set_runtime_provisioning_cookie(resp: Response, *, tenant_id: str) -> None:
    from apps.backend.services.runtime.provisioning_token import (
        mint_workweaver_runtime_provisioning_cookie,
    )

    token = mint_workweaver_runtime_provisioning_cookie(tenant_id=tenant_id)
    cookie_name = _provisioning_cookie_write_name()
    if _disable_cognito():
        # Local Docker dev uses localhost origins and no TLS; use host-only cookie settings.
        resp.set_cookie(
            key=cookie_name,
            value=token,
            httponly=True,
            secure=False,
            samesite="lax",
            max_age=15 * 60,
            path="/",
        )
        return

    # Cross-site requests (hq -> api) require SameSite=None; Secure is mandatory with None.
    # Set domain to parent domain so cookie works across subdomains.
    resp.set_cookie(
        key=cookie_name,
        value=token,
        httponly=True,
        secure=True,
        samesite="none",
        max_age=15 * 60,
        path="/",
        domain=".workweaver.ai",  # Allow cookie on all subdomains
    )


def _clear_runtime_provisioning_cookie(resp: Response) -> None:
    # Clear both current and legacy cookie scopes so old and new clients are handled.
    clear_params = [
        {"path": "/", "domain": ".workweaver.ai"},
        {"path": "/", "domain": None},
        {"path": "/api/v1/auth", "domain": ".workweaver.ai"},
        {"path": "/api/v1/auth/runtime", "domain": ".workweaver.ai"},
    ]
    for cookie_name in RUNTIME_PROVISIONING_COOKIE_NAMES:
        for params in clear_params:
            kwargs = dict(params)
            if kwargs.get("domain") is None:
                kwargs.pop("domain", None)
            resp.delete_cookie(key=cookie_name, **kwargs)


def _clear_browser_session_cookie(resp: Response) -> None:
    clear_params = [
        {"path": "/", "domain": ".workweaver.ai"},
        {"path": "/", "domain": None},
    ]
    for cookie_name in BROWSER_SESSION_COOKIE_NAMES:
        for params in clear_params:
            kwargs = dict(params)
            if kwargs.get("domain") is None:
                kwargs.pop("domain", None)
            resp.delete_cookie(key=cookie_name, **kwargs)


# ============================================================================
# Domain / Region Helpers
# ============================================================================


def _email_domain(email: str) -> str:
    return email.split("@")[-1].lower().strip()


def _domain_allowed_for_provisioning(email: str, has_valid_invite: bool = False) -> bool:
    # Local Docker/dev test mode (DISABLE_COGNITO=true) should not hard-fail
    # auth-flow tests that use synthetic domains. Production still enforces
    # allowlist because DISABLE_COGNITO is ignored on ECS.
    if _disable_cognito():
        return True
    if not ALLOWED_PROVISIONING_DOMAINS:
        return True
    # Users with a valid invite token bypass domain restrictions (Level 1 access)
    if has_valid_invite:
        return True
    return _email_domain(email) in ALLOWED_PROVISIONING_DOMAINS


def _domain_not_allowed_detail() -> dict[str, str]:
    allowed_domains = ", ".join(sorted(ALLOWED_PROVISIONING_DOMAINS or INTERNAL_SIGNUP_BYPASS_DOMAINS))
    return {
        "error": "domain_not_allowed",
        "message": (f"Early access is currently limited to {allowed_domains}. Join the waitlist at {WAITLIST_URL}."),
        "waitlist_url": WAITLIST_URL,
    }


def _is_internal_bypass_email(email: str) -> bool:
    return INTERNAL_SIGNUP_SKIP_STRIPE_ENABLED and _email_domain(email) in INTERNAL_SIGNUP_BYPASS_DOMAINS


def _signup_region_options() -> list[SignupRegionOption]:
    return [SignupRegionOption(label=label, code=code) for label, code in SIGNUP_REGION_OPTIONS.items()]


def _resolve_signup_region(email: str, preferred_region: str | None) -> tuple[str, str]:
    if _is_internal_bypass_email(email):
        code = INTERNAL_SIGNUP_REGION
        return code, _region_label_for_code(code)

    code = _resolve_requested_region(preferred_region)
    return code, _region_label_for_code(code)


def _extract_user_id_from_signup(result: dict[str, Any], owner_user_id: str) -> str:
    user = result.get("user", {})
    return result.get("user_id") or user.get("user_id") or owner_user_id


def _is_lambda_environment() -> bool:
    return bool(os.environ.get("AWS_LAMBDA_FUNCTION_NAME", "").strip())


def _resume_runtime_provisioning_if_needed(
    tenant: dict[str, Any],
    *,
    task_name: str,
    force: bool = False,
    stale_after_seconds: int | None = None,
) -> bool:
    from apps.backend.services.runtime.provisioning_shared import (
        parse_runtime_checked_at,
        runtime_resume_decision,
    )

    tenant_id = str(tenant.get("tenant_id") or "").strip()
    owner_user_id = str(tenant.get("owner_user_id") or "").strip()
    owner_email = str(tenant.get("email") or "").strip().lower()
    if not tenant_id or not owner_user_id or not owner_email:
        return False

    runtime = tenant.get("runtime") if isinstance(tenant.get("runtime"), dict) else {}
    runtime_status = str(runtime.get("status") or "").strip().lower()
    tenant_status = str(tenant.get("status") or "").strip().lower()

    runtime_service = get_workweaver_runtime_provisioning_service()
    if not getattr(runtime_service, "enabled", False):
        return False

    checked_at = parse_runtime_checked_at(runtime.get("checked_at"))
    now = datetime.now(UTC)
    age_seconds = None if checked_at is None else max((now - checked_at).total_seconds(), 0.0)
    cutoff = stale_after_seconds
    if cutoff is None:
        cutoff = max(int(os.environ.get("WORKWEAVER_RUNTIME_STALE_RECOVERY_SECONDS", "600")), 60)

    should_resume, reason = runtime_resume_decision(
        status_value=runtime_status,
        checked_at_value=checked_at,
        tenant_status_value=tenant_status,
        force=force,
        stale_after_seconds=cutoff,
    )
    if not should_resume:
        return False

    preferred_region = tenant.get("preferred_region_code")
    try:
        runtime_service.mark_status(
            tenant_id=tenant_id,
            status="provisioning",
            step="queued",
            last_error=None,
        )
    except Exception as exc:
        logger.warning("Unable to queue runtime recovery for %s: %s", tenant_id, exc)

    if _is_lambda_environment():
        import concurrent.futures

        inline_timeout = max(
            int(os.environ.get("WORKWEAVER_RUNTIME_LAMBDA_INLINE_TIMEOUT_SECONDS", "25")), 5
        )
        try:
            with concurrent.futures.ThreadPoolExecutor(max_workers=1) as pool:
                fut = pool.submit(
                    runtime_service.reconcile_provisioning,
                    tenant_id=tenant_id,
                    owner_email=owner_email,
                    owner_user_id=owner_user_id,
                    region=preferred_region,
                )
                fut.result(timeout=inline_timeout)
        except concurrent.futures.TimeoutError:
            logger.info(
                "runtime_provisioning_lambda_inline_timeout tenant_id=%s timeout=%ds — "
                "reconciliation will continue on next /me call",
                tenant_id,
                inline_timeout,
            )
        except Exception:
            logger.exception(
                "runtime_provisioning_lambda_inline_error tenant_id=%s",
                tenant_id,
            )
    else:
        spawn_background_task(
            asyncio.to_thread(
                runtime_service.reconcile_provisioning,
                tenant_id=tenant_id,
                owner_email=owner_email,
                owner_user_id=owner_user_id,
                region=preferred_region,
            ),
            task_name=task_name,
            tenant_id=tenant_id,
        )

    logger.info(
        "runtime_provisioning_rearmed tenant_id=%s status=%s reason=%s age_seconds=%s lambda=%s",
        tenant_id,
        runtime_status or "missing",
        reason,
        None if age_seconds is None else int(age_seconds),
        _is_lambda_environment(),
    )
    return True


def _default_checkout_product(requested_product: str | None) -> str:
    return "workmemory" if str(requested_product or "").strip().lower() == "workmemory" else "workweaver"


def _default_checkout_tier(product: str) -> str:
    return "starter" if product == "workmemory" else "launchpad"


def _resolve_checkout_selection(
    *,
    requested_product: str | None,
    invite_product: str | None,
    workweaver_tier: str | None,
    workmemory_tier: str | None,
) -> tuple[str, str, str]:
    checkout_product = _default_checkout_product(requested_product)
    normalized_invite_product = str(invite_product or "").strip().lower()
    if normalized_invite_product in {"workweaver", "workmemory"}:
        checkout_product = normalized_invite_product

    if normalized_invite_product == "both":
        checkout_product = _default_checkout_product(requested_product)

    checkout_tier = (
        str(workmemory_tier or "").strip().lower()
        if checkout_product == "workmemory"
        else str(workweaver_tier or "").strip().lower()
    ) or _default_checkout_tier(checkout_product)
    return checkout_product, checkout_tier, "monthly"


# ============================================================================
# Core Signup Orchestration
# ============================================================================


async def _complete_signup_after_identity_verification(
    *,
    owner_user_id: str,
    email: str,
    auth_provider: AuthProvider,
    owner_name: str | None = None,
    preferred_region: str | None = None,
    product: str | None = None,
    invite_token: str | None = None,
    sub_tenant_invite_token: str | None = None,
    consent: SignupConsent | None = None,
) -> SignupResponse:
    """
    Complete signup after identity verification (Google or verified email).

    External domains:
    - Create tenant (pending payment)
    - Return Stripe checkout URL

    Internal bypass domains:
    - Create tenant
    - Provision dedicated Workweaver Runtime EC2 instance
    - Activate tenant without Stripe
    """
    # --- Invite token resolution ---
    # If the user has a valid invite token, they bypass domain restrictions and may get a coupon.
    # Validate first (before creating tenant) so we don't create orphan tenants on bad invites.
    resolved_coupon_id: str | None = None
    invite_is_free: bool = False
    invite_validated = False
    selected_checkout_product = _default_checkout_product(product)
    selected_checkout_tier = _default_checkout_tier(selected_checkout_product)
    selected_checkout_billing = "monthly"
    invite_discount_pct: int | None = None

    if sub_tenant_invite_token:
        from apps.backend.services.org_provisioning import (
            OrgInviteAlreadyClaimedError,
            OrgInviteEmailMismatchError,
            OrgInviteExpiredError,
            OrgInviteNotFoundError,
            OrgProvisioningError,
            get_org_provisioning_service,
        )

        try:
            claimed = get_org_provisioning_service().claim_sub_tenant_invite(
                invite_token=sub_tenant_invite_token,
                owner_user_id=owner_user_id,
                email=email,
                auth_provider=auth_provider.value,
                owner_name=owner_name,
                consent=consent,
            )
        except OrgInviteEmailMismatchError as exc:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "error": "sub_tenant_invite_email_mismatch",
                    "message": "This invite was issued for a different email address.",
                },
            ) from exc
        except OrgInviteExpiredError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "sub_tenant_invite_expired",
                    "message": "This sub-tenant invite has expired. Ask the org owner for a new invite.",
                },
            ) from exc
        except OrgInviteAlreadyClaimedError as exc:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail={
                    "error": "sub_tenant_invite_used",
                    "message": "This sub-tenant invite has already been used.",
                },
            ) from exc
        except OrgInviteNotFoundError as exc:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "invalid_sub_tenant_invite",
                    "message": "This sub-tenant invite is invalid. Ask the org owner for a new invite.",
                },
            ) from exc
        except OrgProvisioningError as exc:
            raise HTTPException(
                status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                detail={
                    "error": "sub_tenant_invite_unavailable",
                    "message": "Sub-tenant invite signup is temporarily unavailable. Please try again.",
                },
            ) from exc

        return SignupResponse(
            tenant_id=claimed.tenant_id,
            user_id=claimed.user_id,
            status=claimed.status,
            email=claimed.email,
            role=_admin_role_value(),
            auth_provider=claimed.auth_provider,
            next_step="complete",
            provisioning_mode="org_sub_tenant_invite",
            stripe_checkout_url=None,
            runtime_instance_id=None,
            runtime_public_ip=None,
            runtime_endpoint=None,
            runtime_launch_url=None,
            runtime_status="disabled",
            runtime_step="metadata_only",
            selected_region_code=claimed.selected_region_code,
            selected_region_label=claimed.selected_region_label,
        )

    if invite_token:
        from apps.backend.api.invites import get_invite, validate_invite, _resolve_discount_coupon_id

        validation = validate_invite(invite_token)
        if not validation.valid:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail={
                    "error": "invalid_invite_token",
                    "message": f"Invite token is {validation.error or 'invalid'}. Please request a new invite link.",
                },
            )
        invite_validated = True
        discount_pct = validation.discount_pct or 0
        invite_discount_pct = discount_pct
        selected_checkout_product, selected_checkout_tier, selected_checkout_billing = _resolve_checkout_selection(
            requested_product=product,
            invite_product=validation.product,
            workweaver_tier=validation.workweaver_tier,
            workmemory_tier=validation.workmemory_tier,
        )

        # Check if email matches pre-assigned invite
        if validation.invited_email and validation.invited_email.lower() != email.lower():
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "error": "invite_email_mismatch",
                    "message": "This invite was issued for a different email address.",
                },
            )

        if discount_pct >= 100:
            invite_is_free = True  # Skip Stripe entirely
        elif discount_pct > 0:
            # Fetch stripe coupon from stored invite record
            raw_item = get_invite(invite_token)
            resolved_coupon_id = (raw_item or {}).get("stripe_coupon_id") or _resolve_discount_coupon_id(
                discount_pct=discount_pct,
                access_code=(raw_item or {}).get("access_code") or invite_token,
                explicit_coupon_id=None,
            )
            if not resolved_coupon_id:
                raise HTTPException(
                    status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
                    detail={
                        "error": "invite_discount_not_configured",
                        "message": "This access code is valid, but its checkout discount is not configured yet.",
                    },
                )

    provisioning_service = get_tenant_provisioning_service()
    selected_region_code, selected_region_label = _resolve_signup_region(email=email, preferred_region=preferred_region)

    create_result = provisioning_service.create_tenant(
        owner_user_id=owner_user_id,
        email=email,
        auth_provider=auth_provider.value,
        owner_name=owner_name,
        product=product,
        preferred_region_code=selected_region_code,
        preferred_region_label=selected_region_label,
        consent=consent,
    )

    tenant_id = create_result["tenant_id"]
    user_id = _extract_user_id_from_signup(create_result, owner_user_id)
    tenant = create_result["tenant"]

    # --- Invite-based free signup (discount_pct == 100) ---
    # Free invites skip Stripe entirely, same as internal bypass but without runtime provisioning.
    if invite_validated and invite_is_free and not _is_internal_bypass_email(email):
        activated_tenant = provisioning_service.activate_tenant_after_payment(
            tenant_id=tenant_id,
            stripe_customer_id=f"invite-bypass:{invite_token}",
        )
        invite_token_label = invite_token[:8] + "..." if invite_token else "none"
        # Best-effort: consume the invite token post-provisioning
        from apps.backend.api.invites import consume_invite

        try:
            consume_invite(invite_token, used_by_email=email)  # type: ignore[arg-type]
        except Exception:
            logger.warning(
                "Failed to consume invite token %s for %s",
                invite_token_label,
                _redact_email(email),
            )

        logger.info(
            "Free invite signup complete: tenant=%s email=%s invite=%s",
            tenant_id,
            _redact_email(email),
            invite_token_label,
        )
        return SignupResponse(
            tenant_id=tenant_id,
            user_id=user_id,
            status=activated_tenant["status"],
            email=activated_tenant["email"],
            role=_admin_role_value(),
            auth_provider=auth_provider.value,
            next_step="complete",
            provisioning_mode="invite_bypass",
            stripe_checkout_url=None,
            selected_region_code=selected_region_code,
            selected_region_label=selected_region_label,
        )

    # Internal bypass domains can skip Stripe. Managed Workweaver signup is an org
    # workspace metadata bootstrap, not a runtime/EC2 provisioning trigger; explicit
    # runtime/self-host allocation remains owned by the runtime provisioning services.
    if _is_internal_bypass_email(email) and product == "workweaver":
        activated_tenant = provisioning_service.activate_tenant_after_payment(
            tenant_id=tenant_id,
            stripe_customer_id=f"internal-bypass:{user_id}",
        )
        return SignupResponse(
            tenant_id=tenant_id,
            user_id=user_id,
            status=activated_tenant["status"],
            email=activated_tenant["email"],
            role=_admin_role_value(),
            auth_provider=auth_provider.value,
            next_step="complete",
            provisioning_mode="org_workspace_bootstrap",
            stripe_checkout_url=None,
            runtime_instance_id=None,
            runtime_public_ip=None,
            runtime_endpoint=None,
            runtime_launch_url=None,
            runtime_status="disabled",
            runtime_provisioning_token=None,
            runtime_step="metadata_only",
            selected_region_code=selected_region_code,
            selected_region_label=selected_region_label,
        )
    elif _is_internal_bypass_email(email) and product != "workweaver":
        # Non-Workweaver Runtime product: still activate without Stripe, but do not provision runtime infra.
        activated_tenant = provisioning_service.activate_tenant_after_payment(
            tenant_id=tenant_id,
            stripe_customer_id=f"internal-bypass:{user_id}",
        )
        return SignupResponse(
            tenant_id=tenant_id,
            user_id=user_id,
            status=activated_tenant["status"],
            email=activated_tenant["email"],
            role=_admin_role_value(),
            auth_provider=auth_provider.value,
            next_step="complete",
            provisioning_mode="internal_bypass",
            stripe_checkout_url=None,
            runtime_instance_id=None,
            runtime_public_ip=None,
            runtime_endpoint=None,
            runtime_launch_url=None,
            runtime_status="disabled",
            runtime_step="disabled",
            selected_region_code=selected_region_code,
            selected_region_label=selected_region_label,
        )

    stripe_checkout_url = generate_stripe_checkout_url(
        tenant_id=tenant_id,
        email=email,
        auth_provider=auth_provider.value,
        selected_region_code=selected_region_code,
        selected_region_label=selected_region_label,
        coupon_id=resolved_coupon_id,
        invite_token=invite_token,
        product=selected_checkout_product,
        tier=selected_checkout_tier,
        billing=selected_checkout_billing,
        discount_pct=invite_discount_pct,
    )

    # Best-effort: consume paid invite token — token stays valid until payment succeeds,
    # but we don't consume it here to avoid blocking if coupon_id was already applied.
    # Token will remain active; it's single-use so re-signup would require a new invite.
    # (Full consumption happens post-payment in stripe_webhooks on checkout.session.completed)

    return SignupResponse(
        tenant_id=tenant_id,
        user_id=user_id,
        status=tenant["status"],
        email=tenant["email"],
        role=_admin_role_value(),
        auth_provider=auth_provider.value,
        next_step="stripe_checkout",
        provisioning_mode="stripe_checkout",
        stripe_checkout_url=stripe_checkout_url,
        selected_region_code=selected_region_code,
        selected_region_label=selected_region_label,
    )


def generate_stripe_checkout_url(
    tenant_id: str,
    email: str,
    auth_provider: str,
    selected_region_code: str,
    selected_region_label: str,
    coupon_id: str | None = None,
    invite_token: str | None = None,
    product: str = "workweaver",
    tier: str | None = None,
    billing: str = "monthly",
    discount_pct: int | None = None,
) -> str:
    """Generate Stripe Checkout URL for tenant using StripeCheckoutService.

    Args:
        tenant_id: Tenant ID for metadata
        email: User email for pre-filling
        auth_provider: Authentication provider used
        selected_region_code: Selected region code
        selected_region_label: Selected region label

    Returns:
        Stripe Checkout URL

    Raises:
        HTTPException: If Stripe checkout session creation fails
    """
    from apps.backend.services.billing.stripe_checkout import (
        CheckoutSessionConfig,
        CheckoutUnavailableError,
        get_stripe_checkout_service,
    )

    try:
        resolved_product = _default_checkout_product(product)
        resolved_tier = str(tier or _default_checkout_tier(resolved_product)).strip().lower()
        resolved_billing = "annual" if str(billing or "").strip().lower() == "annual" else "monthly"
        effective_coupon_id = coupon_id
        if not effective_coupon_id and _email_domain(email) in INTERNAL_SIGNUP_BYPASS_DOMAINS:
            # Safety net: if internal Stripe bypass is disabled/misconfigured, force a 100% internal coupon.
            effective_coupon_id = os.environ.get("INTERNAL_SIGNUP_FALLBACK_COUPON_ID") or STRIPE_COUPONS.get(
                "founding_50"
            )

        # Get Stripe Checkout service
        checkout_service = get_stripe_checkout_service()

        # Create checkout session configuration
        config_kwargs: dict[str, Any] = {
            "tenant_id": tenant_id,
            "customer_email": email,
            "product": resolved_product,
            "tier": resolved_tier,
            "billing": resolved_billing,
            "metadata": {
                "auth_provider": auth_provider,
                "signup_timestamp": datetime.now(UTC).isoformat(),
                "signup_region_code": selected_region_code,
                "signup_region_label": selected_region_label,
                "signup_product": resolved_product,
                "signup_tier": resolved_tier,
                "signup_billing": resolved_billing,
                **({"invite_discount_pct": discount_pct} if discount_pct is not None else {}),
                **({"invite_token": invite_token} if invite_token else {}),
            },
        }
        if effective_coupon_id:
            config_kwargs["coupon_id"] = effective_coupon_id
        config = CheckoutSessionConfig(**config_kwargs)

        # Create checkout session
        result = checkout_service.create_checkout_session(config)

        logger.info(f"Generated Stripe Checkout URL for tenant={tenant_id}, session_id={result.session_id}")

        return result.checkout_url

    except CheckoutUnavailableError as e:
        logger.error(f"Checkout temporarily unavailable for tenant={tenant_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail={
                "error": "checkout_unavailable",
                "message": "Checkout is temporarily unavailable. Please try again.",
            },
            headers={"Retry-After": "30"},
        )
    except Exception as e:
        logger.error(f"Failed to generate Stripe Checkout URL for tenant={tenant_id}: {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail={
                "error": "checkout_error",
                "message": "Failed to create checkout session. Please try again.",
            },
        )
