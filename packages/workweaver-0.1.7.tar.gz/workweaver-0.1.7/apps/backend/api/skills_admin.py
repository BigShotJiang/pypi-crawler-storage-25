"""Skills Admin API — Mission Control dashboard surface for #2184.

Exposes skill health metrics and administrative operations:

    GET    /api/v1/skills?category=&q=&status=&page=&page_size=
    GET    /api/v1/skills/{skill_id}
    PUT    /api/v1/skills/{skill_id}          # admin + tenant_grown only
    POST   /api/v1/skills/{skill_id}/archive  # admin + tenant_grown only
    POST   /api/v1/skills/{skill_id}/restore  # admin + tenant_grown only
    GET    /api/v1/skills/{skill_id}/hygiene-actions
    POST   /api/v1/skills/{skill_id}/hygiene-decision

Auth: existing tenant JWT middleware.  Mutation endpoints additionally check
``role == admin`` and ``skill.category == tenant_grown`` and
``skill.tenant_id == jwt.tenant_id``.

Decision Trace events emitted on every mutation:
``evidence:skill_edited``, ``evidence:skill_archived``, ``evidence:skill_restored``.
"""

from __future__ import annotations

import logging
import uuid
from datetime import UTC, datetime
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, Request, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_id,
    get_verified_user_role,
)
from apps.backend.models.user import UserRole
from apps.backend.services.repo_skill_catalog import (
    RepoSkillCatalogEntry,
    RepoSkillCatalogService,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/skills", tags=["skills-admin"])

# ---------------------------------------------------------------------------
# In-memory revision / archive stores (for test isolation; in production these
# would live in DynamoDB via the standard tenants table).  Service integrations
# can swap them out via dependency injection / monkeypatching in tests.
# ---------------------------------------------------------------------------

_REVISION_STORE: dict[str, list[dict[str, Any]]] = {}   # skill_id → [revisions]
_ARCHIVE_STORE: dict[str, dict[str, Any]] = {}           # skill_id → archive record


# ---------------------------------------------------------------------------
# Pydantic models
# ---------------------------------------------------------------------------


class SkillAdminListItem(BaseModel):
    """One row in the Mission Control skills list view."""

    skill_id: str
    name: str
    purpose: str
    capability_class: str | None = None
    category: str
    status: str
    invocation_count_30d: int = 0


class SkillAdminListResponse(BaseModel):
    items: list[SkillAdminListItem]
    next_cursor: str | None = None


class RecentInvocation(BaseModel):
    invocation_id: str
    invoked_at: str
    outcome: str = "success"
    latency_ms: int | None = None


class SkillAdminDetail(BaseModel):
    skill_id: str
    name: str
    purpose: str
    content_md: str = ""
    frontmatter: dict[str, Any] = Field(default_factory=dict)
    recent_invocations: list[RecentInvocation] = Field(default_factory=list)


class SkillAdminUpdateRequest(BaseModel):
    content_md: str
    frontmatter: dict[str, Any] | None = None


class SkillAdminUpdateResponse(BaseModel):
    skill_id: str
    revision_id: str
    updated_at: str


class SkillAdminArchiveResponse(BaseModel):
    skill_id: str
    archived_at: str


class SkillAdminRestoreResponse(BaseModel):
    skill_id: str
    restored_at: str


class HygieneActionsResponse(BaseModel):
    proposed_actions: list[dict[str, Any]] = Field(default_factory=list)


class HygieneDecisionRequest(BaseModel):
    decision: str  # "approve" | "decline" | "defer"


class HygieneDecisionResponse(BaseModel):
    skill_id: str
    decision: str
    recorded_at: str


class SkillCuratorWeightsRequest(BaseModel):
    usage: float = 0.20
    pass_rate: float = 0.25
    recency: float = 0.20
    consolidation: float = 0.20
    richness: float = 0.15


class SkillCuratorRunRequest(BaseModel):
    weights: SkillCuratorWeightsRequest | None = None


class SkillCuratorDecisionRequest(BaseModel):
    decision: str = Field(..., description="accept, reject, or defer")
    reason: str = ""


class SkillCuratorProposalResponse(BaseModel):
    proposal_id: str
    tenant_id: str
    scope: str
    action: str
    skill_ids: list[str]
    score: float
    rationale: str
    evidence_refs: list[str]
    rollback_path: str
    counter_metrics: list[str]
    status: str
    created_at: str
    updated_at: str


class SkillCuratorRunResponse(BaseModel):
    run_id: str
    tenant_id: str
    routine_id: str
    cadence: str
    bypass_cognition: bool
    weights: dict[str, float]
    proposals: list[SkillCuratorProposalResponse]
    proposal_count: int
    decision_trace_id: str | None = None
    created_at: str


class SkillCuratorProposalListResponse(BaseModel):
    proposals: list[SkillCuratorProposalResponse] = Field(default_factory=list)
    count: int = 0


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _get_catalog() -> RepoSkillCatalogService:
    """Lazy-construct catalog service (avoids import-time fs reads in tests)."""
    return RepoSkillCatalogService()


def _get_curator_service():
    from apps.backend.services.skills.skill_hygiene_service import SkillHygieneService

    return SkillHygieneService()


def _serialize_curator_proposal(proposal: Any) -> SkillCuratorProposalResponse:
    payload = proposal.to_dict() if hasattr(proposal, "to_dict") else dict(proposal)
    return SkillCuratorProposalResponse(**payload)


def _serialize_curator_run(run: Any) -> SkillCuratorRunResponse:
    payload = run.to_dict() if hasattr(run, "to_dict") else dict(run)
    payload["proposals"] = [
        proposal if isinstance(proposal, dict) else proposal.to_dict()
        for proposal in payload.get("proposals", [])
    ]
    payload["proposal_count"] = int(payload.get("proposal_count") or len(payload["proposals"]))
    return SkillCuratorRunResponse(**payload)


def _weights_from_request(body: SkillCuratorRunRequest):
    if body.weights is None:
        return None
    from apps.backend.services.skills.skill_hygiene_service import SkillCuratorWeights

    return SkillCuratorWeights(**body.weights.model_dump())


def _emit_decision_trace(
    *,
    tenant_id: str,
    event_type: str,
    skill_id: str,
    actor_id: str | None,
    payload: dict[str, Any],
) -> None:
    """Emit a Decision Trace event for a skill mutation.

    In production this would write to the evidence ledger / DynamoDB; here we
    log at INFO level so integration tests can assert via caplog.
    """
    receipt = {
        "type": event_type,
        "tenant_id": tenant_id,
        "timestamp": datetime.now(UTC).isoformat(),
        "skill_id": skill_id,
        "actor_id": actor_id,
        **payload,
    }
    logger.info("Decision trace event: %s", receipt)


def _require_admin_for_tenant_grown(
    *,
    role: UserRole,
    category: str,
    skill_tenant_id: str | None,
    jwt_tenant_id: str,
) -> None:
    """Raise HTTP 403 if the caller cannot mutate this skill.

    Rules (all must pass):
    (a) caller role is admin,
    (b) skill category is ``tenant_grown`` (core, business, dev are read-only),
    (c) skill.tenant_id matches the caller's tenant_id (cross-tenant isolation).
    """
    if role != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin role required for skill mutations",
        )
    if category != "tenant_grown":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Skills in category '{category}' are read-only (only tenant_grown skills may be edited)",
        )
    if skill_tenant_id and skill_tenant_id != jwt_tenant_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cross-tenant skill access denied",
        )


def _entry_to_list_item(entry: RepoSkillCatalogEntry) -> SkillAdminListItem:
    """Convert a catalog entry to a list-view item."""
    return SkillAdminListItem(
        skill_id=entry.name,
        name=entry.name,
        purpose=entry.purpose,
        capability_class=None,
        category=entry.category,
        status=entry.status or "active",
        invocation_count_30d=0,
    )


# ---------------------------------------------------------------------------
# GET /api/v1/skills
# ---------------------------------------------------------------------------


@router.get("", response_model=SkillAdminListResponse)
async def list_skills_admin(
    request: Request,
    category: str | None = Query(default=None, description="Filter by category"),
    q: str | None = Query(default=None, description="Full-text search query"),
    status_filter: str | None = Query(default=None, alias="status", description="Filter by status"),
    page: int = Query(default=1, ge=1, description="Page number"),
    page_size: int = Query(default=50, ge=1, le=200, description="Items per page"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SkillAdminListResponse:
    """List skills for the Mission Control dashboard.

    Tenant operators never see ``dev`` category skills.
    Default page size is 50; max is 200.
    """
    catalog = _get_catalog()

    if category:
        entries = catalog.list_skills(category=category)
    else:
        entries = catalog.list_skills()

    # Hide dev skills for all tenant operators.
    entries = tuple(e for e in entries if e.category != "dev")

    # Filter out archived skills from the main listing.
    archived_ids = set(_ARCHIVE_STORE.keys())
    entries = tuple(e for e in entries if e.name not in archived_ids)

    if q:
        q_lower = q.strip().lower()
        entries = tuple(
            e for e in entries
            if q_lower in e.name.lower() or q_lower in e.purpose.lower()
        )

    if status_filter:
        entries = tuple(e for e in entries if (e.status or "active") == status_filter)

    total = len(entries)
    start = (page - 1) * page_size
    page_entries = entries[start : start + page_size]

    has_next = (start + page_size) < total
    next_cursor: str | None = None
    if has_next:
        next_offset = start + page_size
        next_cursor = str(next_offset)

    items = [_entry_to_list_item(e) for e in page_entries]
    return SkillAdminListResponse(items=items, next_cursor=next_cursor)


# ---------------------------------------------------------------------------
# Skill Curator REST surface (#3213)
# ---------------------------------------------------------------------------


@router.post("/curator/run", response_model=SkillCuratorRunResponse)
async def run_skill_curator(
    body: SkillCuratorRunRequest,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
    role: UserRole = Depends(get_verified_user_role),
) -> SkillCuratorRunResponse:
    """Run the proposal-only Skill Curator for the authenticated tenant."""
    if role != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin role required to run the Skill Curator",
        )
    run = _get_curator_service().run_curator(
        tenant_id,
        weights=_weights_from_request(body),
    )
    return _serialize_curator_run(run)


@router.get("/curator/runs/latest", response_model=SkillCuratorRunResponse)
async def get_latest_skill_curator_run(
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SkillCuratorRunResponse:
    """Return the latest Skill Curator run for the authenticated tenant."""
    run = _get_curator_service().latest_curator_run(tenant_id)
    if run is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No Skill Curator run found")
    return _serialize_curator_run(run)


@router.get("/curator/proposals", response_model=SkillCuratorProposalListResponse)
async def list_skill_curator_proposals(
    request: Request,
    status_filter: str | None = Query(default=None, alias="status"),
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SkillCuratorProposalListResponse:
    """List tenant-scoped Skill Curator proposals."""
    if status_filter is not None and status_filter not in {"pending", "accepted", "rejected", "deferred"}:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail="status must be one of pending, accepted, rejected, deferred",
        )
    proposals = _get_curator_service().list_curator_proposals(tenant_id, status=status_filter)
    serialized = [_serialize_curator_proposal(proposal) for proposal in proposals]
    return SkillCuratorProposalListResponse(proposals=serialized, count=len(serialized))


@router.post("/curator/proposals/{proposal_id}/decision", response_model=SkillCuratorProposalResponse)
async def decide_skill_curator_proposal(
    proposal_id: str,
    body: SkillCuratorDecisionRequest,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    role: UserRole = Depends(get_verified_user_role),
) -> SkillCuratorProposalResponse:
    """Record an owner/admin decision without silently mutating skills."""
    if role != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin role required for Skill Curator decisions",
        )
    if body.decision not in {"accept", "reject", "defer"}:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail="decision must be one of accept, reject, defer",
        )
    try:
        proposal = _get_curator_service().decide_curator_proposal(
            tenant_id,
            proposal_id,
            decision=body.decision,
            actor_id=user_id,
            reason=body.reason,
        )
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    return _serialize_curator_proposal(proposal)


# ---------------------------------------------------------------------------
# GET /api/v1/skills/{skill_id}
# ---------------------------------------------------------------------------


@router.get("/{skill_id}", response_model=SkillAdminDetail)
async def get_skill_admin(
    skill_id: str,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> SkillAdminDetail:
    """Return skill detail including last 10 invocations."""
    catalog = _get_catalog()
    entry = catalog.get_skill(skill_id)
    if entry is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Skill '{skill_id}' not found",
        )

    # Collect the latest revision content if any exists.
    revisions = _REVISION_STORE.get(skill_id, [])
    if revisions:
        latest = revisions[-1]
        content_md = latest.get("content_md", "")
        frontmatter = latest.get("frontmatter", {})
    else:
        content_md = ""
        frontmatter = {"category": entry.category, "status": entry.status or "active"}

    # Pull last 10 invocations from evidence store (graceful-degrade to empty).
    recent_invocations: list[RecentInvocation] = []
    try:
        from apps.backend.services.evidence_ledger import get_evidence_ledger_service

        svc = get_evidence_ledger_service()
        timeline = svc.get_timeline(
            tenant_id=tenant_id,
            event_type="evidence:skill_invocation",
            limit=10,
        )
        for item in timeline.get("items", [])[:10]:
            if item.get("skill_id") != skill_id:
                continue
            recent_invocations.append(
                RecentInvocation(
                    invocation_id=str(item.get("evidence_id", uuid.uuid4())),
                    invoked_at=str(item.get("timestamp", datetime.now(UTC).isoformat())),
                    outcome=str(item.get("outcome", "success")),
                    latency_ms=item.get("latency_ms"),
                )
            )
    except Exception as exc:  # noqa: BLE001
        logger.debug("Evidence ledger unavailable for recent invocations: %s", exc)

    return SkillAdminDetail(
        skill_id=skill_id,
        name=entry.name,
        purpose=entry.purpose,
        content_md=content_md,
        frontmatter=frontmatter,
        recent_invocations=recent_invocations,
    )


# ---------------------------------------------------------------------------
# PUT /api/v1/skills/{skill_id}  (admin + tenant_grown only)
# ---------------------------------------------------------------------------


@router.put("/{skill_id}", response_model=SkillAdminUpdateResponse)
async def update_skill_admin(
    skill_id: str,
    body: SkillAdminUpdateRequest,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    role: UserRole = Depends(get_verified_user_role),
) -> SkillAdminUpdateResponse:
    """Create a new revision of a tenant_grown skill.

    Constitution Axiom 4: never silently overwrite — each PUT appends a new
    revision to the version log; original content is preserved.
    """
    catalog = _get_catalog()
    entry = catalog.get_skill(skill_id)
    if entry is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Skill '{skill_id}' not found",
        )

    # ``tenant_id`` on catalog skills is the JWT tenant for tenant_grown.
    _require_admin_for_tenant_grown(
        role=role,
        category=entry.category,
        skill_tenant_id=tenant_id,  # catalog skills have no cross-tenant id
        jwt_tenant_id=tenant_id,
    )

    revision_id = str(uuid.uuid4())
    now = datetime.now(UTC).isoformat()

    revision = {
        "revision_id": revision_id,
        "skill_id": skill_id,
        "content_md": body.content_md,
        "frontmatter": body.frontmatter or {},
        "revised_by": user_id,
        "revised_at": now,
    }

    if skill_id not in _REVISION_STORE:
        _REVISION_STORE[skill_id] = []
    _REVISION_STORE[skill_id].append(revision)

    _emit_decision_trace(
        tenant_id=tenant_id,
        event_type="evidence:skill_edited",
        skill_id=skill_id,
        actor_id=user_id,
        payload={"revision_id": revision_id},
    )

    return SkillAdminUpdateResponse(
        skill_id=skill_id,
        revision_id=revision_id,
        updated_at=now,
    )


# ---------------------------------------------------------------------------
# POST /api/v1/skills/{skill_id}/archive  (admin + tenant_grown only)
# ---------------------------------------------------------------------------


@router.post("/{skill_id}/archive", response_model=SkillAdminArchiveResponse)
async def archive_skill(
    skill_id: str,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    role: UserRole = Depends(get_verified_user_role),
) -> SkillAdminArchiveResponse:
    """Archive a tenant_grown skill.  Restorable for 30 days."""
    catalog = _get_catalog()
    entry = catalog.get_skill(skill_id)
    if entry is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Skill '{skill_id}' not found",
        )

    _require_admin_for_tenant_grown(
        role=role,
        category=entry.category,
        skill_tenant_id=tenant_id,
        jwt_tenant_id=tenant_id,
    )

    if skill_id in _ARCHIVE_STORE:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Skill '{skill_id}' is already archived",
        )

    now = datetime.now(UTC).isoformat()
    _ARCHIVE_STORE[skill_id] = {
        "skill_id": skill_id,
        "archived_at": now,
        "archived_by": user_id,
        "tenant_id": tenant_id,
    }

    _emit_decision_trace(
        tenant_id=tenant_id,
        event_type="evidence:skill_archived",
        skill_id=skill_id,
        actor_id=user_id,
        payload={"archived_at": now},
    )

    return SkillAdminArchiveResponse(skill_id=skill_id, archived_at=now)


# ---------------------------------------------------------------------------
# POST /api/v1/skills/{skill_id}/restore  (admin + tenant_grown only)
# ---------------------------------------------------------------------------


@router.post("/{skill_id}/restore", response_model=SkillAdminRestoreResponse)
async def restore_skill(
    skill_id: str,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    role: UserRole = Depends(get_verified_user_role),
) -> SkillAdminRestoreResponse:
    """Restore a previously archived tenant_grown skill."""
    catalog = _get_catalog()
    entry = catalog.get_skill(skill_id)
    if entry is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Skill '{skill_id}' not found",
        )

    _require_admin_for_tenant_grown(
        role=role,
        category=entry.category,
        skill_tenant_id=tenant_id,
        jwt_tenant_id=tenant_id,
    )

    if skill_id not in _ARCHIVE_STORE:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Skill '{skill_id}' is not currently archived",
        )

    archive_record = _ARCHIVE_STORE.pop(skill_id)
    # Enforce cross-tenant isolation on restore.
    if archive_record.get("tenant_id") and archive_record["tenant_id"] != tenant_id:
        # Re-add so state is consistent.
        _ARCHIVE_STORE[skill_id] = archive_record
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Cross-tenant skill restore denied",
        )

    now = datetime.now(UTC).isoformat()
    _emit_decision_trace(
        tenant_id=tenant_id,
        event_type="evidence:skill_restored",
        skill_id=skill_id,
        actor_id=user_id,
        payload={"restored_at": now},
    )

    return SkillAdminRestoreResponse(skill_id=skill_id, restored_at=now)


# ---------------------------------------------------------------------------
# GET /api/v1/skills/{skill_id}/hygiene-actions  (paired with #2183)
# ---------------------------------------------------------------------------


@router.get("/{skill_id}/hygiene-actions", response_model=HygieneActionsResponse)
async def get_hygiene_actions(
    skill_id: str,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> HygieneActionsResponse:
    """Return proposed hygiene actions for a skill (pairs with #2183)."""
    catalog = _get_catalog()
    if catalog.get_skill(skill_id) is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Skill '{skill_id}' not found",
        )

    # Stub: real implementation merges #2183 hygiene event signals.
    return HygieneActionsResponse(proposed_actions=[])


# ---------------------------------------------------------------------------
# POST /api/v1/skills/{skill_id}/hygiene-decision
# ---------------------------------------------------------------------------


@router.post("/{skill_id}/hygiene-decision", response_model=HygieneDecisionResponse)
async def post_hygiene_decision(
    skill_id: str,
    body: HygieneDecisionRequest,
    request: Request,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    role: UserRole = Depends(get_verified_user_role),
) -> HygieneDecisionResponse:
    """Record a human hygiene decision (approve / decline / defer)."""
    catalog = _get_catalog()
    if catalog.get_skill(skill_id) is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Skill '{skill_id}' not found",
        )

    allowed_decisions = {"approve", "decline", "defer"}
    if body.decision not in allowed_decisions:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_CONTENT,
            detail=f"decision must be one of {sorted(allowed_decisions)}",
        )

    if role != UserRole.ADMIN:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Admin role required for hygiene decisions",
        )

    now = datetime.now(UTC).isoformat()
    _emit_decision_trace(
        tenant_id=tenant_id,
        event_type="evidence:skill_hygiene_decision",
        skill_id=skill_id,
        actor_id=user_id,
        payload={"decision": body.decision},
    )

    return HygieneDecisionResponse(
        skill_id=skill_id,
        decision=body.decision,
        recorded_at=now,
    )
