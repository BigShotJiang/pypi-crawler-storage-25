"""Agent Email API endpoint.

Provides POST /api/v1/email/send for Workweaver Runtime email tool.
Response includes the dispatch result plus the PolicyDecisionEnvelope used
before the send.

Multi-provider routing (Gmail → Graph → Zoho → SES) lives in
apps.backend.services.agent_email_service.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, status

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

# Canonical Email models and routing logic live in agent_email_service.
from apps.backend.services.agent_email_service import (
    EmailAttachment,
    EmailSendRequest,
    EmailSendResponse,
    send_agent_email,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/email", tags=["agent-email"])

__all__ = ["EmailAttachment", "EmailSendRequest", "EmailSendResponse", "router"]


@router.post("/send", response_model=EmailSendResponse)
async def send_email(
    request: EmailSendRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> EmailSendResponse:
    """Send an email on behalf of an AI agent.

    Provider routing priority:
      1. Gmail (Google OAuth with gmail.send scope)
      2. Microsoft Graph (Microsoft OAuth with Mail.Send scope)
      3. Zoho Mail
      4. SES fallback (real AWS SES send)
    """
    try:
        return await send_agent_email(tenant_id, request)

    except RuntimeError as exc:
        error_str = str(exc)

        if error_str.startswith("suppressed_recipients:"):
            # Parse blocked list from the RuntimeError message
            import ast as _ast
            try:
                blocked = _ast.literal_eval(error_str[len("suppressed_recipients:"):])
            except Exception:
                blocked = []
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail={
                    "error_code": "SUPPRESSED_RECIPIENT",
                    "message": "Delivery blocked by suppression policy",
                    "suppressed_recipients": blocked,
                },
            )

        if error_str.startswith("delivery_rate_limited:"):
            parts = error_str.split(":", 2)
            reason = parts[1] if len(parts) > 1 else ""
            retry_after: int | None = None
            try:
                retry_after = int(parts[2]) if len(parts) > 2 else None
            except (ValueError, IndexError):
                pass
            raise HTTPException(
                status_code=status.HTTP_429_TOO_MANY_REQUESTS,
                detail={
                    "error_code": "DELIVERY_RATE_LIMITED",
                    "message": "Email delivery temporarily throttled by policy",
                    "reason": reason,
                    "retry_after_seconds": retry_after,
                },
            )

        if error_str.startswith("outbound_compliance_blocked:"):
            parts = error_str.split(":", 2)
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail={
                    "error_code": "OUTBOUND_COMPLIANCE_BLOCKED",
                    "message": "Email delivery blocked by outbound compliance preflight",
                    "final_verdict": parts[1] if len(parts) > 1 else "DENY",
                    "evidence": parts[2] if len(parts) > 2 else "",
                },
            )

        logger.error("Agent email send failed for tenant %s: %s", tenant_id, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Email send failed",
        )

    except Exception:
        logger.exception("Unexpected error sending agent email for tenant %s", tenant_id)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Email send failed",
        )
