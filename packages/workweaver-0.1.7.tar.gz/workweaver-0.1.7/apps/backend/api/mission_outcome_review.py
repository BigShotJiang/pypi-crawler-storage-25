"""Mission outcome review API."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, get_verified_user_id
from apps.backend.services.mission_outcome_review import (
    MissionOutcomeReviewRequest,
    MissionOutcomeReviewResponse,
    get_mission_outcome_review_service,
)

router = APIRouter(prefix="/api/v1/missions", tags=["missions"])


def _get_review_service() -> Any:
    return get_mission_outcome_review_service()


@router.post("/{mission_id}/outcome-review", response_model=MissionOutcomeReviewResponse)
async def review_mission_outcome(
    mission_id: str,
    request: MissionOutcomeReviewRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    actor_id: str = Depends(get_verified_user_id),
) -> MissionOutcomeReviewResponse:
    if request.mission_id != mission_id:
        raise HTTPException(status_code=400, detail="mission_id path/body mismatch")
    try:
        return _get_review_service().review_outcome(
            tenant_id=tenant_id,
            actor_id=actor_id,
            request=request,
        )
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


__all__ = [
    "MissionOutcomeReviewRequest",
    "MissionOutcomeReviewResponse",
    "review_mission_outcome",
    "router",
    "_get_review_service",
]
