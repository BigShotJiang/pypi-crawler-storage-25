"""Typed routine facade over canonical schedules and TimeBlock lineage."""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, get_verified_user_id
from apps.backend.services.scheduling.routines import (
    RoutineAction,
    RoutineMutationResult,
    RoutineView,
    get_routine_service,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/mission/routines", tags=["routines"])


class RoutineListResponse(BaseModel):
    routines: list[RoutineView] = Field(default_factory=list)
    count: int = 0
    audit: dict[str, object] = Field(default_factory=dict)


class RoutineActionRequest(BaseModel):
    action: str = Field(..., description="Routine action")
    note: str = Field("", description="Optional operator note")
    recommendation_signature: str | None = Field(None, description="Recommendation signature being acted on")
    cron_expression: str | None = Field(None, description="New cron expression for cadence updates")
    timezone_name: str | None = Field(None, description="IANA timezone for cadence updates")


def _routine_service():
    return get_routine_service()


@router.get("/", response_model=RoutineListResponse)
async def list_routines(
    tenant_id: str = Depends(get_verified_tenant_id),
    status: str | None = Query(None, description="Optional schedule status filter"),
    health_status: str | None = Query(None, description="Optional routine health filter"),
) -> RoutineListResponse:
    try:
        routines = _routine_service().list_routines(tenant_id)
        if status:
            routines = [routine for routine in routines if routine.status == status]
        if health_status:
            routines = [routine for routine in routines if routine.health_status.value == health_status]
        return RoutineListResponse(
            routines=routines,
            count=len(routines),
            audit=_routine_service().build_audit_summary(tenant_id),
        )
    except Exception as exc:
        logger.error("Failed to list routines for tenant=%s: %s", tenant_id, exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to load routines") from exc


@router.get("/{routine_id}", response_model=RoutineView)
async def get_routine(
    routine_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> RoutineView:
    try:
        return _routine_service().get_routine(tenant_id, routine_id)
    except ValueError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc
    except Exception as exc:
        logger.error("Failed to load routine %s for tenant=%s: %s", routine_id, tenant_id, exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to load routine") from exc


@router.post("/{routine_id}/actions", response_model=RoutineMutationResult)
async def mutate_routine(
    routine_id: str,
    request: RoutineActionRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    authenticated_user_id: str = Depends(get_verified_user_id),
) -> RoutineMutationResult:
    try:
        resolved_action = request.action
        if resolved_action == "delete":
            # Soft-delete semantics preserve canonical restore/audit paths.
            resolved_action = RoutineAction.CANCEL.value
        return _routine_service().mutate(
            tenant_id=tenant_id,
            schedule_id=routine_id,
            action=resolved_action,
            actor_id=authenticated_user_id,
            note=request.note,
            recommendation_signature=request.recommendation_signature,
            cron_expression=request.cron_expression,
            timezone_name=request.timezone_name,
        )
    except ValueError as exc:
        detail = str(exc)
        lowered = detail.lower()
        if "not found" in lowered:
            status_code = 404
        elif "revision mismatch" in lowered:
            status_code = 409
        else:
            status_code = 400
        raise HTTPException(status_code=status_code, detail=detail) from exc
    except Exception as exc:
        logger.error("Failed to mutate routine %s for tenant=%s: %s", routine_id, tenant_id, exc, exc_info=True)
        raise HTTPException(status_code=500, detail="Failed to update routine") from exc
