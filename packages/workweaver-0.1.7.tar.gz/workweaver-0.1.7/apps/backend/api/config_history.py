"""Config History API (Track 11.3) - Config safety baseline endpoints.

Provides config snapshot browsing, dry-run preview, and point-in-time
restore for agent profiles.
"""

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.schemas.error_response import safe_error_detail

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/mission/agents", tags=["config-history"])


# ---------------------------------------------------------------------------
# Request / Response models
# ---------------------------------------------------------------------------


class RestoreRequest(BaseModel):
    """Request body for config-restore and config-preview."""

    snapshot_id: str = Field(..., max_length=100, description="Snapshot ID to restore/preview")


class SnapshotResponse(BaseModel):
    """Single snapshot entry."""

    snapshot_id: str
    agent_id: str
    changed_fields: list[str]
    previous_values: dict[str, Any]
    actor: str
    timestamp: str


class SnapshotListResponse(BaseModel):
    """Response for config-history endpoint."""

    snapshots: list[SnapshotResponse]
    count: int


class PreviewResponse(BaseModel):
    """Response for config-preview endpoint."""

    preview: dict[str, Any]


class RestoreResponse(BaseModel):
    """Response for config-restore endpoint."""

    restored: bool
    snapshot_id: str
    changes: list[str]


# ---------------------------------------------------------------------------
# Lazy store getter (patchable in tests)
# ---------------------------------------------------------------------------


def _get_profile_store():  # type: ignore[no-untyped-def]
    """Lazy import to avoid circular dependencies at module load time."""
    from apps.backend.services.agent_profile_store import get_agent_profile_store

    return get_agent_profile_store()


# ---------------------------------------------------------------------------
# Endpoints
# ---------------------------------------------------------------------------


@router.get("/{agent_id}/config-history", response_model=SnapshotListResponse)
async def get_config_history(
    agent_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> SnapshotListResponse:
    """Return all config snapshots for an agent."""
    try:
        store = _get_profile_store()
        snapshots = store.get_snapshots(tenant_id, agent_id)
        items = [
            SnapshotResponse(
                snapshot_id=s["snapshot_id"],
                agent_id=s["agent_id"],
                changed_fields=s["changed_fields"],
                previous_values=s["previous_values"],
                actor=s["actor"],
                timestamp=s["timestamp"],
            )
            for s in snapshots
        ]
        paged_items, _total = paginate_items(items, pagination)
        return SnapshotListResponse(snapshots=paged_items, count=len(paged_items))
    except Exception as e:
        logger.error("Failed to get config history: %s", e)
        raise HTTPException(status_code=500, detail="Failed to get config history")


@router.post("/{agent_id}/config-preview", response_model=PreviewResponse)
async def config_preview(
    agent_id: str,
    request: RestoreRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> PreviewResponse:
    """Dry-run: show what would change if a snapshot were restored."""
    try:
        store = _get_profile_store()
        preview = store.preview_restore(tenant_id, agent_id, request.snapshot_id)
        return PreviewResponse(preview=preview)
    except ValueError as e:
        raise HTTPException(status_code=404, detail=safe_error_detail(e))
    except Exception as e:
        logger.error("Failed to preview config restore: %s", e)
        raise HTTPException(status_code=500, detail="Failed to preview config restore")


@router.post("/{agent_id}/config-restore", response_model=RestoreResponse)
async def config_restore(
    agent_id: str,
    request: RestoreRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> RestoreResponse:
    """Restore agent profile to a previous snapshot state."""
    try:
        store = _get_profile_store()
        result = store.restore_agent_profile(tenant_id, agent_id, request.snapshot_id)
        return RestoreResponse(
            restored=result["restored"],
            snapshot_id=result["snapshot_id"],
            changes=result["changes"],
        )
    except ValueError as e:
        raise HTTPException(status_code=404, detail=safe_error_detail(e))
    except Exception as e:
        logger.error("Failed to restore config: %s", e)
        raise HTTPException(status_code=500, detail="Failed to restore config")
