"""Canonical tenant capability registry — single source of truth.

Every tenant-facing capability must be registered here. The runtime UI,
CLI, MCP, and REST API all derive from this registry. A parity test
validates that all surfaces stay in sync.

Adding a new capability:
  1. Add an entry to TENANT_CAPABILITIES below
  2. Implement the REST endpoint in the appropriate api/ module
  3. Add the CLI subcommand in apps/cli/ww/commands/<dock>.py
  4. Add the MCP tool in apps/backend/api/public_mcp.py or core_tools.py
  5. Run test_tenant_parity.py to verify drift is caught
"""

from __future__ import annotations

from typing import Any


class TenantCapability:
    """One tenant capability exposed across UI, CLI, MCP, REST."""

    __slots__ = (
        "name",
        "dock",
        "category",
        "method",
        "path",
        "description",
        "side_effects",
        "parameters",
        "cli_command",
        "mcp_tool",
        "ui_dock_panel",
    )

    def __init__(
        self,
        *,
        name: str,
        dock: str,
        category: str,
        method: str,
        path: str,
        description: str,
        side_effects: str = "read_only",
        parameters: dict[str, Any] | None = None,
        cli_command: str = "",
        mcp_tool: str = "",
        ui_dock_panel: str = "",
    ) -> None:
        self.name = name
        self.dock = dock
        self.category = category
        self.method = method
        self.path = path
        self.description = description
        self.side_effects = side_effects
        self.parameters = parameters or {}
        self.cli_command = cli_command
        self.mcp_tool = mcp_tool
        self.ui_dock_panel = ui_dock_panel

    def __repr__(self) -> str:
        return f"TenantCapability({self.name!r}, dock={self.dock!r})"


# ---------------------------------------------------------------------------
# Tenant capabilities indexed by runtime dock.
#
# dock:     Runtime dock panel (mission, inbox, zara, memory, connectors,
#            evidence, identity, entity, swarm, upgrades, wallet)
# category: Functional grouping within a dock
# method:   HTTP method for the REST endpoint
# path:     REST API path
# cli_command: `ww <command>` CLI invocation
# mcp_tool: MCP tool name (from public_mcp.py or core_tools.py)
# ---------------------------------------------------------------------------

TENANT_CAPABILITIES: list[TenantCapability] = [
    # ── MISSION DOCK ─────────────────────────────────────────────────────
    TenantCapability(
        name="mission_list",
        dock="mission",
        category="mission",
        method="GET",
        path="/api/v1/missions",
        description="List missions with status filtering",
        cli_command="ww mission list",
        mcp_tool="ww.mission.list",
        ui_dock_panel="mission",
    ),
    TenantCapability(
        name="mission_create",
        dock="mission",
        category="mission",
        method="POST",
        path="/api/v1/missions",
        description="Create a new mission",
        side_effects="mutation",
        parameters={"title": "str", "description": "str", "deadline": "str", "priority": "str"},
        cli_command="ww mission create",
        mcp_tool="ww.mission.list",
        ui_dock_panel="mission",
    ),
    TenantCapability(
        name="mission_get",
        dock="mission",
        category="mission",
        method="GET",
        path="/api/v1/missions/{mission_id}",
        description="Get mission details by ID",
        cli_command="ww mission show",
        mcp_tool="ww.mission.show",
        ui_dock_panel="mission",
    ),
    TenantCapability(
        name="mission_update",
        dock="mission",
        category="mission",
        method="PATCH",
        path="/api/v1/missions/{mission_id}",
        description="Update mission fields",
        side_effects="mutation",
        cli_command="ww mission show",
        mcp_tool="ww.mission.show",
        ui_dock_panel="mission",
    ),
    TenantCapability(
        name="mission_delete",
        dock="mission",
        category="mission",
        method="DELETE",
        path="/api/v1/missions/{mission_id}",
        description="Soft-delete a mission",
        side_effects="mutation",
        cli_command="ww mission halt",
        mcp_tool="ww.mission.halt",
        ui_dock_panel="mission",
    ),
    TenantCapability(
        name="workitem_create",
        dock="mission",
        category="workitem",
        method="POST",
        path="/api/v1/work-items",
        description="Create a work item under a mission",
        side_effects="mutation",
        cli_command="ww workitem create",
        mcp_tool="ww.workitem.create",
        ui_dock_panel="mission",
    ),
    TenantCapability(
        name="schedule_create",
        dock="mission",
        category="schedule",
        method="POST",
        path="/api/v1/schedules",
        description="Create a recurring schedule",
        side_effects="mutation",
        cli_command="ww schedule create",
        mcp_tool="ww.schedule.create",
        ui_dock_panel="mission",
    ),
    TenantCapability(
        name="schedule_trigger",
        dock="mission",
        category="schedule",
        method="POST",
        path="/api/v1/schedules/{schedule_id}/trigger",
        description="Manually trigger a schedule",
        side_effects="mutation",
        cli_command="ww schedule trigger",
        mcp_tool="ww.schedule.trigger",
        ui_dock_panel="mission",
    ),
    # ── INBOX DOCK ───────────────────────────────────────────────────────
    TenantCapability(
        name="inbox_list",
        dock="inbox",
        category="inbox",
        method="GET",
        path="/api/v1/inbox",
        description="List pending inbox items",
        cli_command="ww inbox list",
        mcp_tool="ww.inbox.list",
        ui_dock_panel="inbox",
    ),
    TenantCapability(
        name="inbox_approve",
        dock="inbox",
        category="inbox",
        method="POST",
        path="/api/v1/inbox/{item_id}/approve",
        description="Approve a pending inbox item",
        side_effects="mutation",
        cli_command="ww inbox approve",
        mcp_tool="ww.inbox.approve",
        ui_dock_panel="inbox",
    ),
    TenantCapability(
        name="inbox_reject",
        dock="inbox",
        category="inbox",
        method="POST",
        path="/api/v1/inbox/{item_id}/reject",
        description="Reject a pending inbox item",
        side_effects="mutation",
        cli_command="ww inbox reject",
        mcp_tool="ww.inbox.reject",
        ui_dock_panel="inbox",
    ),
    TenantCapability(
        name="inbox_conversations",
        dock="inbox",
        category="conversations",
        method="GET",
        path="/api/v1/inbox/conversations",
        description="List inbox conversations",
        cli_command="ww inbox conversations",
        mcp_tool="ww.inbox.conversations",
        ui_dock_panel="inbox",
    ),
    # ── ZARA DOCK ────────────────────────────────────────────────────────
    TenantCapability(
        name="zara_command",
        dock="zara",
        category="zara",
        method="POST",
        path="/api/v1/zara",
        description="Send natural-language command to Zara",
        side_effects="mutation",
        cli_command="ww zara",
        mcp_tool="ww.zara.chat",
        ui_dock_panel="zara",
    ),
    TenantCapability(
        name="zara_status",
        dock="zara",
        category="zara",
        method="GET",
        path="/api/v1/zara/status/{command_id}",
        description="Check status of a Zara command",
        cli_command="ww zara",
        mcp_tool="ww.zara.chat",
        ui_dock_panel="zara",
    ),
    TenantCapability(
        name="zara_recall",
        dock="zara",
        category="zara",
        method="POST",
        path="/api/v1/zara/recall",
        description="Historical recall via Zara",
        cli_command="ww zara recall",
        mcp_tool="ww.zara.recall",
        ui_dock_panel="zara",
    ),
    TenantCapability(
        name="agent_list",
        dock="zara",
        category="agents",
        method="GET",
        path="/api/v1/agents",
        description="List configured agents",
        cli_command="ww agent list",
        mcp_tool="ww.agent.list",
        ui_dock_panel="zara",
    ),
    TenantCapability(
        name="agent_run",
        dock="zara",
        category="agents",
        method="POST",
        path="/api/v1/agents/{agent_id}/run",
        description="Run an agent task",
        side_effects="mutation",
        cli_command="ww agent run",
        mcp_tool="ww.agent.list",
        ui_dock_panel="zara",
    ),
    # ── MEMORY DOCK ──────────────────────────────────────────────────────
    TenantCapability(
        name="memory_remember",
        dock="memory",
        category="memory",
        method="POST",
        path="/api/v1/memory",
        description="Store a fact in persistent memory",
        side_effects="mutation",
        cli_command="ww memory remember",
        mcp_tool="ww.memory.remember",
        ui_dock_panel="memory",
    ),
    TenantCapability(
        name="memory_search",
        dock="memory",
        category="memory",
        method="GET",
        path="/api/v1/memory/search",
        description="Search stored memories",
        cli_command="ww memory search",
        mcp_tool="ww.memory.search",
        ui_dock_panel="memory",
    ),
    TenantCapability(
        name="memory_recall",
        dock="memory",
        category="memory",
        method="GET",
        path="/api/v1/memory/{memory_id}",
        description="Recall a specific memory by ID",
        cli_command="ww memory read",
        mcp_tool="ww.memory.remember",
        ui_dock_panel="memory",
    ),
    TenantCapability(
        name="memory_forget",
        dock="memory",
        category="memory",
        method="DELETE",
        path="/api/v1/memory/{memory_id}",
        description="Remove a memory entry",
        side_effects="mutation",
        cli_command="ww memory forget",
        mcp_tool="ww.memory.forget",
        ui_dock_panel="memory",
    ),
    TenantCapability(
        name="memory_status",
        dock="memory",
        category="memory",
        method="GET",
        path="/api/v1/memory/status",
        description="Check WorkMemory health and usage",
        cli_command="ww memory audit",
        mcp_tool="ww.memory.status",
        ui_dock_panel="memory",
    ),
    TenantCapability(
        name="memory_session_start",
        dock="memory",
        category="session",
        method="POST",
        path="/api/v1/sessions",
        description="Start a rolling context session",
        side_effects="mutation",
        cli_command="ww memory session start",
        mcp_tool="ww.memory.session",
        ui_dock_panel="memory",
    ),
    TenantCapability(
        name="memory_consolidate",
        dock="memory",
        category="memory",
        method="POST",
        path="/api/v1/memory/consolidate",
        description="Trigger memory consolidation",
        side_effects="mutation",
        cli_command="ww memory audit",
        mcp_tool="ww.memory.audit",
        ui_dock_panel="memory",
    ),
    # ── CONNECTORS DOCK ──────────────────────────────────────────────────
    TenantCapability(
        name="connector_list",
        dock="connectors",
        category="connectors",
        method="GET",
        path="/api/v1/connectors",
        description="List installed connectors",
        cli_command="ww connector list",
        mcp_tool="ww.connector.list",
        ui_dock_panel="connectors",
    ),
    TenantCapability(
        name="connector_install",
        dock="connectors",
        category="connectors",
        method="POST",
        path="/api/v1/connectors/install",
        description="Install a connector from marketplace",
        side_effects="mutation",
        cli_command="ww connector install",
        mcp_tool="ww.connector.install",
        ui_dock_panel="connectors",
    ),
    TenantCapability(
        name="connector_execute",
        dock="connectors",
        category="connectors",
        method="POST",
        path="/api/v1/connectors/{connector_id}/execute",
        description="Execute a connector operation",
        side_effects="mutation",
        cli_command="ww connector execute",
        mcp_tool="ww.connector.execute",
        ui_dock_panel="connectors",
    ),
    TenantCapability(
        name="connector_health",
        dock="connectors",
        category="connectors",
        method="GET",
        path="/api/v1/connectors/{connector_id}/health",
        description="Check connector health",
        cli_command="ww connector health",
        mcp_tool="ww.connector.health",
        ui_dock_panel="connectors",
    ),
    # ── EVIDENCE DOCK ────────────────────────────────────────────────────
    TenantCapability(
        name="evidence_query",
        dock="evidence",
        category="evidence",
        method="GET",
        path="/api/v1/evidence",
        description="Query evidence store",
        cli_command="ww evidence trace",
        mcp_tool="ww.evidence.trace",
        ui_dock_panel="evidence",
    ),
    TenantCapability(
        name="evidence_trace",
        dock="evidence",
        category="evidence",
        method="GET",
        path="/api/v1/evidence/{entity_id}/trace",
        description="Trace decision provenance chain",
        cli_command="ww evidence trace",
        mcp_tool="ww.evidence.trace",
        ui_dock_panel="evidence",
    ),
    TenantCapability(
        name="evidence_export",
        dock="evidence",
        category="evidence",
        method="GET",
        path="/api/v1/evidence/export",
        description="Export audit bundle",
        cli_command="ww evidence export",
        mcp_tool="ww.evidence.export",
        ui_dock_panel="evidence",
    ),
    # ── ENTITY SYSTEM ────────────────────────────────────────────────────
    TenantCapability(
        name="entity_list",
        dock="entity",
        category="entity",
        method="GET",
        path="/api/v1/entities",
        description="List entity instances",
        cli_command="ww entity list",
        mcp_tool="ww.entity.record.list",
        ui_dock_panel="entity",
    ),
    TenantCapability(
        name="entity_create",
        dock="entity",
        category="entity",
        method="POST",
        path="/api/v1/entities",
        description="Create an entity instance",
        side_effects="mutation",
        cli_command="ww entity create",
        mcp_tool="ww.entity.record.create",
        ui_dock_panel="entity",
    ),
    TenantCapability(
        name="entity_get",
        dock="entity",
        category="entity",
        method="GET",
        path="/api/v1/entities/{entity_id}",
        description="Get entity instance details",
        cli_command="ww entity get",
        mcp_tool="ww.entity.record.get",
        ui_dock_panel="entity",
    ),
    TenantCapability(
        name="entity_schema_list",
        dock="entity",
        category="schema",
        method="GET",
        path="/api/v1/entity-schemas",
        description="List entity schemas",
        cli_command="ww entity-schema list",
        mcp_tool="ww.entity_schema.list",
        ui_dock_panel="entity",
    ),
    # ── SWARM ────────────────────────────────────────────────────────────
    TenantCapability(
        name="swarm_status",
        dock="swarm",
        category="swarm",
        method="GET",
        path="/api/v1/swarm",
        description="List active swarm executions",
        cli_command="ww swarm list",
        mcp_tool="ww.swarm.status",
        ui_dock_panel="swarm",
    ),
    TenantCapability(
        name="swarm_spawn",
        dock="swarm",
        category="swarm",
        method="POST",
        path="/api/v1/swarm/spawn",
        description="Spawn a new swarm execution",
        side_effects="mutation",
        cli_command="ww swarm spawn",
        mcp_tool="ww.swarm.spawn",
        ui_dock_panel="swarm",
    ),
    TenantCapability(
        name="swarm_cancel",
        dock="swarm",
        category="swarm",
        method="POST",
        path="/api/v1/swarm/{swarm_id}/cancel",
        description="Cancel a swarm execution",
        side_effects="mutation",
        cli_command="ww swarm cancel",
        mcp_tool="ww.swarm.cancel",
        ui_dock_panel="swarm",
    ),
    # ── UPGRADES ─────────────────────────────────────────────────────────
    TenantCapability(
        name="swarm_constitution",
        dock="swarm",
        category="swarm",
        method="POST",
        path="/api/v1/swarm/constitution",
        description="Create and version a shared swarm constitution",
        side_effects="mutation",
        cli_command="ww swarm constitution create",
        mcp_tool="ww.swarm.constitution.create",
        ui_dock_panel="operational-context",
    ),
    TenantCapability(
        name="swarm_constitution_active",
        dock="swarm",
        category="swarm",
        method="GET",
        path="/api/v1/swarm/constitution/active",
        description="Read active shared swarm constitution",
        cli_command="ww swarm constitution active",
        mcp_tool="ww.swarm.constitution.active",
        ui_dock_panel="operational-context",
    ),
    TenantCapability(
        name="upgrades_list",
        dock="upgrades",
        category="upgrades",
        method="GET",
        path="/api/v1/upgrades",
        description="List Weekly Upgrade Digest proposals",
        cli_command="ww upgrades list",
        mcp_tool="ww.upgrades.list",
        ui_dock_panel="upgrades",
    ),
    TenantCapability(
        name="upgrades_approve",
        dock="upgrades",
        category="upgrades",
        method="POST",
        path="/api/v1/upgrades/{proposal_id}/approve",
        description="Approve an upgrade proposal",
        side_effects="mutation",
        cli_command="ww upgrades approve",
        mcp_tool="ww.upgrades.approve",
        ui_dock_panel="upgrades",
    ),
    TenantCapability(
        name="upgrades_dismiss",
        dock="upgrades",
        category="upgrades",
        method="POST",
        path="/api/v1/upgrades/{proposal_id}/dismiss",
        description="Dismiss an upgrade for 90 days",
        side_effects="mutation",
        cli_command="ww upgrades dismiss",
        mcp_tool="ww.upgrades.dismiss",
        ui_dock_panel="upgrades",
    ),
    # ── WALLET ───────────────────────────────────────────────────────────
    TenantCapability(
        name="wallet_readiness",
        dock="wallet",
        category="wallet",
        method="GET",
        path="/api/v1/wallet/readiness",
        description="Check wallet subsystem readiness",
        cli_command="ww wallet readiness",
        mcp_tool="ww.wallet.readiness",
        ui_dock_panel="wallet",
    ),
    TenantCapability(
        name="wallet_balance",
        dock="wallet",
        category="wallet",
        method="GET",
        path="/api/v1/wallet/balance",
        description="Query on-chain balance",
        cli_command="ww wallet balance",
        mcp_tool="ww.wallet.balance",
        ui_dock_panel="wallet",
    ),
    TenantCapability(
        name="wallet_sign",
        dock="wallet",
        category="wallet",
        method="POST",
        path="/api/v1/wallet/sign",
        description="Sign a message (guarded)",
        side_effects="mutation",
        cli_command="ww wallet sign",
        mcp_tool="ww.wallet.sign",
        ui_dock_panel="wallet",
    ),
    # ── GOVERNANCE ───────────────────────────────────────────────────────
    TenantCapability(
        name="governance_check",
        dock="governance",
        category="governance",
        method="POST",
        path="/api/v1/governance/check",
        description="Check policy authority for an action",
        cli_command="ww governance check",
        mcp_tool="ww.policy.authority",
        ui_dock_panel="governance",
    ),
]


# ---------------------------------------------------------------------------
# Helper functions for parity tests and progressive disclosure
# ---------------------------------------------------------------------------

def get_tenant_capabilities_by_dock(dock: str) -> list[TenantCapability]:
    return [c for c in TENANT_CAPABILITIES if c.dock == dock]


def get_tenant_docks() -> list[str]:
    seen: list[str] = []
    for c in TENANT_CAPABILITIES:
        if c.dock not in seen:
            seen.append(c.dock)
    return seen


def get_mutation_capabilities() -> list[TenantCapability]:
    return [c for c in TENANT_CAPABILITIES if c.side_effects == "mutation"]


def get_read_only_capabilities() -> list[TenantCapability]:
    return [c for c in TENANT_CAPABILITIES if c.side_effects == "read_only"]
