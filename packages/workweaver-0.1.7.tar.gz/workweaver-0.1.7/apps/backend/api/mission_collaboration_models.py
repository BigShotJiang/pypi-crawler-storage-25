"""Request and response models for Mission Control collaboration endpoints."""

from __future__ import annotations


from pydantic import BaseModel, Field


class CreateChannelRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=120)
    scope: str = Field("org", description="team|department|org")
    topic: str = Field("", max_length=500)
    member_agent_ids: list[str] = Field(default_factory=list)


class ChannelMembershipRequest(BaseModel):
    agent_id: str = Field(..., min_length=1, max_length=120)


class SendChannelMessageRequest(BaseModel):
    from_agent: str = Field(..., min_length=1, max_length=200)
    content: str = Field(..., min_length=1, max_length=10000)
    message_type: str = Field("broadcast", max_length=64)
    to_agent: str | None = Field(None, max_length=200)


class AddReactionRequest(BaseModel):
    message_id: str = Field(..., min_length=1, max_length=128)
    agent_id: str = Field(..., min_length=1, max_length=200)
    emoji: str = Field(..., min_length=1, max_length=32)


class MarkReadRequest(BaseModel):
    agent_id: str = Field(..., min_length=1, max_length=200)
    timestamp: float | None = Field(None, ge=0)


class ResolveEscalationRequest(BaseModel):
    decided_by: str = Field(..., min_length=1, max_length=200)
    decision: str = Field(..., min_length=1, max_length=32)
    reasoning: str = Field("", max_length=5000)


class ChannelResponse(BaseModel):
    channel_id: str
    name: str
    scope: str
    topic: str = ""
    member_agent_ids: list[str] = Field(default_factory=list)
    created_at: str
    updated_at: str
    unread_count: int | None = None


class ChannelListResponse(BaseModel):
    channels: list[ChannelResponse]
    count: int


class ChannelMessageResponse(BaseModel):
    channel_id: str
    message_id: str
    from_agent: str
    to_agent: str | None = None
    content: str
    message_type: str
    timestamp: str
    mentions: list[str] = Field(default_factory=list)
    reactions: list[dict] = Field(default_factory=list)


class ChannelMessagesResponse(BaseModel):
    channel_id: str
    messages: list[ChannelMessageResponse]
    count: int


class UnreadCountResponse(BaseModel):
    channel_id: str
    agent_id: str
    unread_count: int


class EscalationListResponse(BaseModel):
    escalations: list[ChannelMessageResponse]
    count: int


class EscalationDecisionResponse(BaseModel):
    success: bool
    message_id: str
    decision: str
    decided_by: str
    resolved_at: str
    decision_message_id: str | None = None
    evidence_id: str | None = None


class AgentStatusItemResponse(BaseModel):
    agent_id: str
    name: str
    role: str
    status: str
    parent_node_id: str | None = None


class AgentStatusBoardResponse(BaseModel):
    agents: list[AgentStatusItemResponse]
    count: int


class StartCrossTeamHandoffRequest(BaseModel):
    from_agent: str = Field(..., min_length=1, max_length=200)
    target_channel_id: str = Field(..., min_length=1, max_length=128)
    content: str = Field(..., min_length=1, max_length=10000)
    origin_channel_id: str = Field(..., min_length=1, max_length=128)


class CompleteCrossTeamHandoffRequest(BaseModel):
    from_agent: str = Field(..., min_length=1, max_length=200)
    result: str = Field(..., min_length=1, max_length=10000)


class CrossTeamHandoffResponse(BaseModel):
    handoff_id: str
    status: str
    origin_agent: str
    target_channel_id: str
    request_message_id: str
    relay_message_id: str | None = None
    evidence_id: str | None = None


class StartEscalationChainRequest(BaseModel):
    source_agent: str = Field(..., min_length=1, max_length=200)
    reason: str = Field(..., min_length=1, max_length=10000)
    timeout_seconds: int = Field(300, ge=30, le=86400)


class EscalationChainResponse(BaseModel):
    chain_id: str
    status: str
    source_agent: str
    resolver_chain: list[str] = Field(default_factory=list)
    current_level: int
    no_resolver: bool
    next_escalation_at: str | None = None


class AdvanceEscalationChainsRequest(BaseModel):
    now_timestamp: float | None = Field(None, ge=0)


class AdvanceEscalationChainsResponse(BaseModel):
    advanced: list[EscalationChainResponse] = Field(default_factory=list)
    count: int


class RunHealthMonitorResponse(BaseModel):
    tenant_id: str
    findings: list[dict] = Field(default_factory=list)
    message_ids: list[str] = Field(default_factory=list)
    channel_id: str


class UpsertPlatformMappingRequest(BaseModel):
    external_channel_id: str = Field(..., min_length=1, max_length=255)
    mention_map: dict[str, str] = Field(default_factory=dict)
    enabled: bool = True


class PlatformMappingResponse(BaseModel):
    channel_id: str
    platform: str
    external_channel_id: str
    mention_map: dict[str, str] = Field(default_factory=dict)
    enabled: bool
    created_at: str
    updated_at: str


class PlatformMappingListResponse(BaseModel):
    mappings: list[PlatformMappingResponse]
    count: int


class IngestPlatformEventRequest(BaseModel):
    raw_event: dict = Field(default_factory=dict)


__all__ = [
    "CreateChannelRequest",
    "ChannelMembershipRequest",
    "SendChannelMessageRequest",
    "AddReactionRequest",
    "MarkReadRequest",
    "ResolveEscalationRequest",
    "ChannelResponse",
    "ChannelListResponse",
    "ChannelMessageResponse",
    "ChannelMessagesResponse",
    "UnreadCountResponse",
    "EscalationListResponse",
    "EscalationDecisionResponse",
    "AgentStatusItemResponse",
    "AgentStatusBoardResponse",
    "StartCrossTeamHandoffRequest",
    "CompleteCrossTeamHandoffRequest",
    "CrossTeamHandoffResponse",
    "StartEscalationChainRequest",
    "EscalationChainResponse",
    "AdvanceEscalationChainsRequest",
    "AdvanceEscalationChainsResponse",
    "RunHealthMonitorResponse",
    "UpsertPlatformMappingRequest",
    "PlatformMappingResponse",
    "PlatformMappingListResponse",
    "IngestPlatformEventRequest",
]
