"""Skill Activation API for Workweaver "Company as a Service" Architecture.

This module provides REST API endpoints for activating skills, including:
- Activate skill (set operational status, assign manager/department)
- Get skill operational status
- Update skill operation (transfer, promote, etc.)

Reference: docs/PRODUCT.md P1.7.4 — "Company as a Service" Architecture
"""

import logging

from fastapi import APIRouter, HTTPException, Path, status, Request
from pydantic import BaseModel, Field, field_validator

from apps.backend.services.skills.skill_query import (
    SkillQueryService,
)
from apps.backend.services.skills.skill_activation import (
    SkillActivationService,
    ActivateSkillRequest,
    ActivationError,
    SkillAlreadyActiveError,
    InvalidManagerError,
    CrossTenantActivationError,
)
from apps.backend.services.skills.skill_registrar import SkillRegistrar
from apps.backend.middleware.tenant_isolation import get_tenant_id
from apps.backend.schemas.agent_profile import AgentProfile
from apps.backend.schemas.error_response import safe_error_detail

# Configure logging
logger = logging.getLogger(__name__)

# Create router
router = APIRouter(prefix="/api/v1/org", tags=["skill-activation"])


def _normalize_profile(profile) -> AgentProfile | None:
    """Normalize profile to AgentProfile object.

    Handles AgentProfile objects, dicts (from Skill.skill_metadata), and
    legacy Employment dataclass objects.

    Args:
        profile: AgentProfile object, dict, or legacy Employment dataclass

    Returns:
        AgentProfile object or None
    """
    if profile is None:
        return None
    if isinstance(profile, AgentProfile):
        return profile
    if isinstance(profile, dict):
        try:
            return AgentProfile.from_dict(profile)
        except Exception:
            logger.warning("Failed to convert profile dict to AgentProfile object")
            return None
    # Handle legacy Employment dataclass or any object with to_dict()
    if hasattr(profile, "to_dict"):
        try:
            return AgentProfile.from_dict(profile.to_dict())
        except Exception:
            logger.warning("Failed to convert legacy profile to AgentProfile")
            return None
    return None


# ============================================================================
# Pydantic Models for API
# ============================================================================


class ActivateSkillRequestModel(BaseModel):
    """Request model for activating a skill.

    Attributes:
        manager_skill_id: Skill ID of the manager (optional for top-level skills)
        department: Department to assign the skill to
        operational_type: Type of operation (full_time, part_time, contract, on_demand)
        performance_review_cycle_days: Days between performance reviews
        role_id: Role template ID — binds capabilities and governance on activation.
    """

    manager_skill_id: str | None = Field(
        default=None,
        max_length=100,
        description="Skill ID of the manager (optional for top-level skills)",
    )
    department: str = Field(..., max_length=200, description="Department to assign the skill to")
    operational_type: str = Field(default="full_time", max_length=50, description="Type of operation")
    performance_review_cycle_days: int = Field(default=90, description="Days between performance reviews")
    role_id: str | None = Field(
        default=None,
        max_length=100,
        description="Role template ID (capabilities + governance bound on activation)",
    )

    @field_validator("operational_type")
    @classmethod
    def validate_operational_type(cls, v: str) -> str:
        """Validate operational type."""
        allowed = {"full_time", "part_time", "contract", "on_demand"}
        if v not in allowed:
            raise ValueError(f"Invalid operational_type: '{v}'. Must be one of: {allowed}")
        return v

    @field_validator("performance_review_cycle_days")
    @classmethod
    def validate_cycle_days(cls, v: int) -> int:
        """Validate performance review cycle days."""
        if v < 1:
            raise ValueError("performance_review_cycle_days must be at least 1 day")
        if v > 365:
            raise ValueError("performance_review_cycle_days must not exceed 365 days")
        return v

    @field_validator("department")
    @classmethod
    def validate_department(cls, v: str) -> str:
        """Validate department name."""
        if not v or not v.strip():
            raise ValueError("department must not be empty")
        return v.strip()


# Backward-compatible alias
HireSkillRequestModel = ActivateSkillRequestModel


class ActivationResponseModel(BaseModel):
    """Response model for activating a skill.

    Attributes:
        skill_id: ID of the activated skill
        operational_status: New operational status
        activated_at: ISO8601 timestamp of activation
        department: Assigned department
        manager_skill_id: Assigned manager (if any)
        operational_type: Type of operation
        next_review_date: ISO8601 timestamp of next performance review
        role_id: Role template ID that was bound on activation (if any)
    """

    skill_id: str
    operational_status: str
    activated_at: str
    department: str
    manager_skill_id: str | None
    operational_type: str
    next_review_date: str
    role_id: str | None = None


# Backward-compatible alias
HiringResponseModel = ActivationResponseModel


class OperationalStatusResponseModel(BaseModel):
    """Response model for skill operational status.

    Attributes:
        skill_id: ID of the skill
        operational_status: Current operational status
        activated_at: ISO8601 timestamp of activation
        department: Assigned department
        manager_skill_id: Assigned manager (if any)
        operational_type: Type of operation
        performance_review_cycle_days: Days between performance reviews
        next_review_date: ISO8601 timestamp of next performance review
        last_review_date: ISO8601 timestamp of last performance review (if any)
    """

    skill_id: str
    operational_status: str | None
    activated_at: str | None
    department: str | None
    manager_skill_id: str | None
    operational_type: str | None
    performance_review_cycle_days: int | None
    next_review_date: str | None
    last_review_date: str | None


# Backward-compatible alias
EmploymentStatusResponseModel = OperationalStatusResponseModel


# ============================================================================
# API Endpoints
# ============================================================================


@router.post(
    "/skills/{skill_id}/activate",
    response_model=ActivationResponseModel,
    status_code=status.HTTP_200_OK,
    summary="Activate a skill",
    description="Activate a skill by setting operational status, assigning manager and department",
)
async def activate_skill(
    request: Request,
    skill_id: str = Path(..., description="ID of the skill to activate"),
    activate_request: ActivateSkillRequestModel = ...,
) -> ActivationResponseModel:
    """Activate a skill into the organization.

    Args:
        request: FastAPI request (for tenant_id)
        skill_id: ID of the skill to activate
        activate_request: Activation request with department, manager, etc.

    Returns:
        ActivationResponseModel with updated operational information

    Raises:
        HTTPException 400: Invalid activation request
        HTTPException 404: Skill not found
        HTTPException 409: Skill already active
        HTTPException 422: Validation error
    """
    tenant_id = get_tenant_id(request)

    logger.info(
        f"Received activation request for skill '{skill_id}' "
        f"in department '{activate_request.department}' "
        f"for tenant '{tenant_id}'"
    )

    # Create service dependencies
    query_service = SkillQueryService()
    registrar = SkillRegistrar()
    activation_service = SkillActivationService(query_service, registrar)

    # Convert Pydantic model to internal request
    internal_request = ActivateSkillRequest(
        department=activate_request.department,
        manager_skill_id=activate_request.manager_skill_id,
        operational_type=activate_request.operational_type,
        performance_review_cycle_days=activate_request.performance_review_cycle_days,
        role_id=activate_request.role_id,
    )

    try:
        result = activation_service.activate_skill(
            tenant_id=tenant_id,
            skill_id=skill_id,
            request=internal_request,
        )

        logger.info(f"Successfully activated skill '{skill_id}'")

        return ActivationResponseModel(
            skill_id=result.skill_id,
            operational_status=result.operational_status,
            activated_at=result.activated_at,
            department=result.department,
            manager_skill_id=result.manager_skill_id,
            operational_type=result.operational_type,
            next_review_date=result.next_review_date,
            role_id=result.role_id,
        )

    except SkillAlreadyActiveError as e:
        logger.warning(f"Skill already active: {e}")
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=safe_error_detail(e),
        )

    except InvalidManagerError as e:
        logger.warning(f"Invalid manager: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=safe_error_detail(e),
        )

    except CrossTenantActivationError as e:
        logger.error(f"Cross-tenant activation attempt: {e}")
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=safe_error_detail(e),
        )

    except ActivationError as e:
        if getattr(e, "code", None) == "ROLE_NOT_FOUND":
            logger.warning(f"Role not found during activation: {e}")
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=safe_error_detail(e),
            )
        logger.error(f"Activation error: {e}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=safe_error_detail(e),
        )

    except Exception as e:
        logger.exception(f"Unexpected error activating skill '{skill_id}': {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to activate skill",
        )


@router.get(
    "/skills/{skill_id}/status",
    response_model=OperationalStatusResponseModel,
    status_code=status.HTTP_200_OK,
    summary="Get skill operational status",
    description="Get the current operational status and details of a skill",
)
async def get_skill_operational_status(
    request: Request,
    skill_id: str = Path(..., description="ID of the skill"),
) -> OperationalStatusResponseModel:
    """Get the operational status of a skill.

    Args:
        request: FastAPI request (for tenant_id)
        skill_id: ID of the skill

    Returns:
        OperationalStatusResponseModel with operational details

    Raises:
        HTTPException 404: Skill not found
        HTTPException 403: Cross-tenant access
    """
    tenant_id = get_tenant_id(request)

    logger.info(f"Fetching operational status for skill '{skill_id}' for tenant '{tenant_id}'")

    # Create service dependencies
    query_service = SkillQueryService()

    try:
        # Get the skill
        skill = query_service.get_skill(tenant_id, skill_id)
        if not skill:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Skill '{skill_id}' not found",
            )

        # Extract operational details and normalize to AgentProfile object
        profile = _normalize_profile(skill.employment if skill and skill.employment else None)

        return OperationalStatusResponseModel(
            skill_id=skill_id,
            operational_status=profile.operational_status.value
            if profile and hasattr(profile.operational_status, "value")
            else str(profile.operational_status)
            if profile
            else None,
            activated_at=profile.activated_at if profile else None,
            department=profile.department if profile else None,
            manager_skill_id=profile.manager_skill_id if profile else None,
            operational_type=profile.operational_type.value
            if profile and hasattr(profile.operational_type, "value")
            else str(profile.operational_type)
            if profile
            else None,
            performance_review_cycle_days=profile.performance_review_cycle_days if profile else None,
            next_review_date=profile.next_review_at if profile else None,
            last_review_date=profile.last_review_at if profile else None,
        )

    except HTTPException:
        raise

    except Exception as e:
        logger.exception(f"Error fetching operational status for skill '{skill_id}': {e}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to fetch operational status",
        )
