"""Skill Templates API.

Provides endpoints for:
- List available skill templates
- Get template details
- Create skill from template

Templates are pre-configured skill definitions that users can instantiate.
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Body, Depends, HTTPException, Path, Query, Request, status
from pydantic import BaseModel, Field
from ulid import new as new_ulid

from apps.backend.middleware.tenant_isolation import get_tenant_id
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.services.skills.skill_registrar import CompiledSkill, SkillRegistrar

logger = logging.getLogger(__name__)

router = APIRouter(
    prefix="/api/v1/templates",
    tags=["Templates"],
)


class TemplateListItem(BaseModel):
    """Template list item for marketplace view."""

    template_id: str = Field(..., description="Template identifier")
    name: str = Field(..., description="Template display name")
    description: str = Field(..., description="Template description")
    vertical: str = Field(..., description="Business vertical")
    category: str = Field(..., description="Template category")
    install_count: int = Field(default=0, description="Number of installs")
    icon: str = Field(default="fa-cube", description="FontAwesome icon class")
    gradient: str = Field(
        default="linear-gradient(135deg, #10B981 0%, #059669 100%)",
        description="CSS gradient for card",
    )
    badge: str | None = Field(
        default=None, description="Badge label (Popular, New, etc.)"
    )
    badge_type: str | None = Field(
        default=None, description="Badge CSS class (success, info, warning)"
    )


class TemplateDetail(BaseModel):
    """Detailed template information."""

    template_id: str
    name: str
    description: str
    vertical: str
    category: str
    install_count: int
    icon: str
    gradient: str
    badge: str | None
    badge_type: str | None
    prompt_template: str = Field(..., description="LLM prompt template")
    input_schema: dict = Field(..., description="Input JSON schema")
    output_schema: dict = Field(..., description="Output JSON schema")
    triggers: list[str] = Field(..., description="Default trigger types")
    tags: list[str] = Field(default_factory=list, description="Template tags")


class CreateFromTemplateRequest(BaseModel):
    """Request to create skill from template."""

    template_id: str = Field(..., description="Template identifier")
    skill_id: str = Field(..., description="New skill identifier")
    display_name: str = Field(..., description="Skill display name")
    customize_prompt: str | None = Field(
        default=None, description="Optional custom prompt (overrides template)"
    )


class CreateFromTemplateResponse(BaseModel):
    """Response after creating skill from template."""

    success: bool
    skill_id: str
    skill_instance_id: str
    message: str


# Hardcoded templates (in a real system, these would come from a database)
TEMPLATES = [
    TemplateListItem(
        template_id="lead-qualification",
        name="Lead Qualification",
        description="Automatically qualify leads through conversational AI. Score and route hot prospects.",
        vertical="real-estate",
        category="lead-management",
        install_count=1200,
        icon="fa-user-plus",
        gradient="linear-gradient(135deg, #10B981 0%, #059669 100%)",
        badge="Popular",
        badge_type="success",
    ),
    TemplateListItem(
        template_id="appointment-booking",
        name="Appointment Booking",
        description="Handle appointment scheduling through natural conversations. Sync with calendar.",
        vertical="general",
        category="scheduling",
        install_count=856,
        icon="fa-calendar-check",
        gradient="linear-gradient(135deg, #3B82F6 0%, #2563EB 100%)",
        badge="New",
        badge_type="info",
    ),
    TemplateListItem(
        template_id="customer-support",
        name="Customer Support",
        description="Handle common customer queries across all channels. Escalate complex issues.",
        vertical="general",
        category="customer-service",
        install_count=2300,
        icon="fa-headset",
        gradient="linear-gradient(135deg, #8B5CF6 0%, #7C3AED 100%)",
        badge="Popular",
        badge_type="success",
    ),
    TemplateListItem(
        template_id="marketing-campaigns",
        name="Marketing Campaigns",
        description="Run automated marketing campaigns across multiple channels with personalized messaging.",
        vertical="general",
        category="campaigns",
        install_count=645,
        icon="fa-bullhorn",
        gradient="linear-gradient(135deg, #F59E0B 0%, #D97706 100%)",
    ),
    TemplateListItem(
        template_id="invoice-collection",
        name="Invoice Collection",
        description="Automate payment reminders and invoice collection through friendly conversations.",
        vertical="legal",
        category="collections",
        install_count=432,
        icon="fa-file-invoice-dollar",
        gradient="linear-gradient(135deg, #EC4899 0%, #DB2777 100%)",
    ),
    TemplateListItem(
        template_id="survey-feedback",
        name="Survey & Feedback",
        description="Collect customer feedback through conversational surveys. Analyze results automatically.",
        vertical="healthcare",
        category="feedback",
        install_count=278,
        icon="fa-clipboard-list",
        gradient="linear-gradient(135deg, #06B6D4 0%, #0891B2 100%)",
    ),
]

# Template details with full configuration
TEMPLATE_DETAILS = {
    "lead-qualification": TemplateDetail(
        **TEMPLATES[0].model_dump(),
        prompt_template="""You are a lead qualification assistant. Your job is to:
1. Engage prospects in natural conversation
2. Ask qualifying questions about budget, timeline, decision-making authority
3. Score leads based on BANT criteria (Budget, Authority, Need, Timeline)
4. Route hot leads to sales team

Be conversational, friendly, and respectful of the prospect's time.""",
        input_schema={
            "type": "object",
            "properties": {
                "prospect_name": {"type": "string"},
                "prospect_email": {"type": "string"},
                "prospect_phone": {"type": "string"},
                "source": {"type": "string"},
            },
            "required": ["prospect_name"],
        },
        output_schema={
            "type": "object",
            "properties": {
                "lead_score": {"type": "number", "minimum": 0, "maximum": 100},
                "qualification_status": {
                    "type": "string",
                    "enum": ["hot", "warm", "cold", "unqualified"],
                },
                "notes": {"type": "string"},
                "next_action": {"type": "string"},
            },
            "required": ["lead_score", "qualification_status"],
        },
        triggers=["event:phone", "event:whatsapp", "event:webhook"],
        tags=["sales", "lead-gen", "qualification"],
    ),
    "appointment-booking": TemplateDetail(
        **TEMPLATES[1].model_dump(),
        prompt_template="""You are an appointment scheduling assistant. Your responsibilities:
1. Check calendar availability
2. Propose time slots that work for both parties
3. Handle rescheduling and cancellations
4. Send confirmation and reminder messages

Be flexible, accommodating, and clear about scheduling details.""",
        input_schema={
            "type": "object",
            "properties": {
                "customer_name": {"type": "string"},
                "preferred_times": {"type": "array", "items": {"type": "string"}},
                "appointment_type": {"type": "string"},
                "duration_minutes": {"type": "number"},
            },
            "required": ["customer_name", "appointment_type"],
        },
        output_schema={
            "type": "object",
            "properties": {
                "appointment_scheduled": {"type": "boolean"},
                "scheduled_time": {"type": "string", "format": "date-time"},
                "confirmation_sent": {"type": "boolean"},
                "calendar_event_id": {"type": "string"},
            },
            "required": ["appointment_scheduled"],
        },
        triggers=["event:phone", "event:sms", "event:whatsapp"],
        tags=["scheduling", "calendar", "appointments"],
    ),
}


@router.get(
    "",
    response_model=list[TemplateListItem],
    status_code=status.HTTP_200_OK,
    summary="List available skill templates",
    description="Returns all available skill templates for the marketplace",
)
async def list_templates(
    vertical: str | None = Query(default=None, description="Filter by vertical"),
    category: str | None = Query(default=None, description="Filter by category"),
    search: str | None = Query(default=None, description="Search query"),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=24, max_limit=100)),
) -> list[TemplateListItem]:
    """List all available skill templates.

    Args:
        vertical: Optional vertical filter
        category: Optional category filter
        search: Optional search query

    Returns:
        List of TemplateListItem objects
    """
    templates = TEMPLATES.copy()

    # Apply filters
    if vertical:
        templates = [t for t in templates if t.vertical == vertical]
    if category:
        templates = [t for t in templates if t.category == category]
    if search:
        search_lower = search.lower()
        templates = [
            t
            for t in templates
            if search_lower in t.name.lower()
            or search_lower in t.description.lower()
        ]

    # Sort by install count (most popular first)
    templates.sort(key=lambda t: t.install_count, reverse=True)

    paged_templates, _total = paginate_items(templates, pagination)
    return paged_templates


@router.get(
    "/{template_id}",
    response_model=TemplateDetail,
    status_code=status.HTTP_200_OK,
    summary="Get template details",
    description="Returns detailed configuration for a specific template",
)
async def get_template(
    template_id: str = Path(..., description="Template identifier"),
) -> TemplateDetail:
    """Get detailed template information.

    Args:
        template_id: Template identifier

    Returns:
        TemplateDetail object

    Raises:
        HTTPException: If template not found
    """
    # Check if we have details for this template
    if template_id in TEMPLATE_DETAILS:
        return TEMPLATE_DETAILS[template_id]

    # Check if template exists but doesn't have details yet
    template = next((t for t in TEMPLATES if t.template_id == template_id), None)
    if template:
        # Return basic template with minimal defaults
        return TemplateDetail(
            **template.model_dump(),
            prompt_template="You are a helpful AI assistant.",
            input_schema={"type": "object", "properties": {}},
            output_schema={"type": "object", "properties": {}},
            triggers=["event:phone"],
            tags=[],
        )

    raise HTTPException(
        status_code=status.HTTP_404_NOT_FOUND,
        detail=f"Template not found: {template_id}",
    )


@router.post(
    "/create-from-template",
    response_model=CreateFromTemplateResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create skill from template",
    description="Instantiate a new skill from a template",
)
async def create_from_template(
    request: Request,
    body: CreateFromTemplateRequest = Body(...),
) -> CreateFromTemplateResponse:
    """Create a new skill from a template.

    Args:
        request: FastAPI request object
        body: Create from template request

    Returns:
        CreateFromTemplateResponse

    Raises:
        HTTPException: If template not found or creation fails
    """
    tenant_id = get_tenant_id(request)

    try:
        # Get template details
        if body.template_id not in TEMPLATE_DETAILS:
            raise HTTPException(
                status_code=status.HTTP_404_NOT_FOUND,
                detail=f"Template not found: {body.template_id}",
            )

        template = TEMPLATE_DETAILS[body.template_id]

        # Map template categories to role categories
        role_category_map = {
            "lead-management": "sales",
            "scheduling": "receptionist",
            "customer-service": "support",
            "campaigns": "automation",
            "collections": "coordinator",
            "feedback": "analyst",
        }
        role_category = role_category_map.get(template.category, "automation")

        compiled_skill = CompiledSkill(
            skill_id=body.skill_id,
            skill_instance_id=str(new_ulid()),
            display_name=body.display_name,
            description=template.description,
            vertical=template.vertical,
            role_category=role_category,
            triggers=template.triggers,
            prompt=body.customize_prompt or template.prompt_template,
            input_schema_ref=f"template:{body.template_id}:input",
            output_schema_ref=f"template:{body.template_id}:output",
            version="1.0.0",
            status="active",
            visibility_scope="tenant",
            tags=template.tags,
            localization=None,
        )

        registrar = SkillRegistrar()
        result = registrar.register_skill(
            compiled_skill=compiled_skill,
            tenant_id=tenant_id,
        )

        if not result.success or result.skill_registry is None:
            raise HTTPException(
                status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
                detail=result.error or "Failed to register skill from template",
            )

        return CreateFromTemplateResponse(
            success=True,
            skill_id=body.skill_id,
            skill_instance_id=result.skill_registry.skill_instance_id,
            message=f"Skill '{body.display_name}' created successfully from template '{body.template_id}'",
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.error(f"Failed to create skill from template: {e}", exc_info=True)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Failed to create skill from template",
        )
