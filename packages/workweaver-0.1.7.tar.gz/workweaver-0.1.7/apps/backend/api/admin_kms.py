"""Admin KMS status API — per-tenant TSMK isolation status.

Issue #3189: Provides visibility into KMS encryption mode, tenant key
provisioning, and cost telemetry for the TSMK envelope encryption system.
"""

from fastapi import APIRouter, Depends

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.api.founder_admin import require_founder
from apps.backend.services.admin.admin_permission import AdminPermission
from apps.backend.services.key_custody.tsmk_isolation import get_tsmk_key_manager

router = APIRouter(prefix="/api/v1/admin/kms", tags=["admin-kms"])


@router.get("/status")
async def kms_status(
    _admin: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.SECRETS_READ)),
) -> dict:
    return get_tsmk_key_manager().get_status()
