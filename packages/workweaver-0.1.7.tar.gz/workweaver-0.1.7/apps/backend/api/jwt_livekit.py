"""
LiveKit JWT + Agent Dispatch (FastAPI)

AWS matches:
  POST /jwt/livekit-token  (API Gateway → Lambda in dev)

Local Docker:
  Landing nginx proxies /jwt/* to backend-api so the landing can do same-origin
  pre-warm on page load without CORS.
"""

from __future__ import annotations
from apps.backend.utils.b64url import b64url_decode, b64url_encode

import asyncio
import json
import logging
import os
from apps.backend.config.region import AWS_REGION
import time
import aiohttp
import hashlib
import hmac
from datetime import timedelta
from functools import lru_cache
from typing import Any

import boto3
from botocore.exceptions import ClientError
from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field
from livekit.api import (
    AccessToken,
    CreateAgentDispatchRequest,
    CreateRoomRequest,
    DeleteRoomRequest,
    ListParticipantsRequest,
    LiveKitAPI,
    VideoGrants,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/jwt", tags=["jwt"])

from apps.backend.api.rate_limit import limiter
from apps.backend.api.dependencies.tenant_auth import resolve_optional_verified_tenant_id

# Default to the same agent name the AWS Lambda uses.
DEFAULT_AGENT_NAME = os.environ.get("DEFAULT_AGENT_NAME", "workweaver-xai-agent")

# 24h to match lambda defaults.
TOKEN_EXPIRATION_SECONDS = int(os.environ.get("TOKEN_EXPIRATION", "86400"))

# AWS Secrets Manager config (same structure as config/secrets.py).
# Region imported from config.region
from apps.backend.config.environment import get_environment as _get_env

ENVIRONMENT = _get_env()
ZARA_ACCESS_TOKEN_ISSUER = os.environ.get("ZARA_ACCESS_TOKEN_ISSUER", "workweaver")
ZARA_ACCESS_TOKEN_AUDIENCE = os.environ.get("ZARA_ACCESS_TOKEN_AUDIENCE", "zara_demo")
_ZARA_ACCESS_KEY_CONTEXT = b"workweaver-zara-access-v1"


def _env_agent_fallbacks() -> tuple[str, ...]:
    raw = os.environ.get("LIVEKIT_AGENT_FALLBACKS", "")
    seen: set[str] = set()
    ordered: list[str] = []
    for item in raw.split(","):
        candidate = str(item or "").strip()
        if not candidate or candidate in seen:
            continue
        seen.add(candidate)
        ordered.append(candidate)
    return tuple(ordered)


def _derive_zara_access_key(api_secret: str) -> bytes:
    return hmac.new(str(api_secret).encode("utf-8"), _ZARA_ACCESS_KEY_CONTEXT, hashlib.sha256).digest()


def _verify_zara_access_token(token: str, api_secret: str) -> dict[str, Any]:
    raw = str(token or "").strip()
    if not raw:
        raise ValueError("missing token")

    parts = raw.split(".")
    if len(parts) != 3:
        raise ValueError("invalid token format")
    header_b64, claims_b64, sig_b64 = parts

    try:
        header = json.loads(b64url_decode(header_b64).decode("utf-8"))
        claims = json.loads(b64url_decode(claims_b64).decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError, ValueError) as e:
        raise ValueError("invalid token encoding") from e

    if not isinstance(header, dict) or header.get("alg") != "HS256":
        raise ValueError("unsupported token algorithm")
    if not isinstance(claims, dict):
        raise ValueError("invalid token claims")

    if str(claims.get("iss") or "") != ZARA_ACCESS_TOKEN_ISSUER:
        raise ValueError("invalid token issuer")
    if str(claims.get("aud") or "") != ZARA_ACCESS_TOKEN_AUDIENCE:
        raise ValueError("invalid token audience")

    exp = int(claims.get("exp") or 0)
    if exp <= 0 or int(time.time()) >= exp:
        raise ValueError("token expired")

    signing_input = f"{header_b64}.{claims_b64}".encode()
    key = _derive_zara_access_key(api_secret)
    expected_sig = b64url_encode(hmac.new(key, signing_input, hashlib.sha256).digest())
    if not hmac.compare_digest(str(sig_b64 or ""), expected_sig):
        raise ValueError("invalid token signature")

    return claims


AGENT_FALLBACKS = _env_agent_fallbacks()
ALLOW_FALLBACK_FOR_EXPLICIT_AGENT = os.environ.get(
    "LIVEKIT_AGENT_ALLOW_FALLBACK_FOR_EXPLICIT",
    "0",
).strip().lower() in ("1", "true", "yes")
DISPATCH_TASK_TIMEOUT_SECONDS = float(os.environ.get("LIVEKIT_DISPATCH_TASK_TIMEOUT_SECONDS", "3.2"))
AGENT_READY_WAIT_SECONDS = float(os.environ.get("LIVEKIT_AGENT_READY_WAIT_SECONDS", "1.2"))
AGENT_POLL_INTERVAL_SECONDS = float(os.environ.get("LIVEKIT_AGENT_POLL_INTERVAL_SECONDS", "0.2"))
DISPATCH_RUNNING_WAIT_SECONDS = float(os.environ.get("LIVEKIT_DISPATCH_RUNNING_WAIT_SECONDS", "2.4"))
MIN_DISPATCH_TIMEOUT_SECONDS = float(os.environ.get("LIVEKIT_DISPATCH_MIN_TIMEOUT_SECONDS", "12.0"))


def _dispatch_timeout_seconds() -> float:
    # Keep timeout >= internal poll windows so dispatch tasks are not cancelled mid-cleanup.
    return max(
        MIN_DISPATCH_TIMEOUT_SECONDS,
        0.5,
        DISPATCH_TASK_TIMEOUT_SECONDS,
        DISPATCH_RUNNING_WAIT_SECONDS + AGENT_READY_WAIT_SECONDS + 0.6,
    )


class LiveKitTokenRequest(BaseModel):
    room_name: str = Field(..., min_length=1, max_length=255)
    participant_name: str = Field(..., min_length=1, max_length=255)
    tenant_id: str | None = Field(default=None, min_length=1, max_length=255)
    metadata: dict[str, Any] = Field(default_factory=dict)
    zara_access_token: str | None = Field(
        default=None, max_length=2048, description="Waitlist access token for landing widget"
    )
    agent_id: str | None = Field(default=None, max_length=255, description="Agent NAME to dispatch")


class LiveKitTokenResponse(BaseModel):
    token: str
    room_url: str
    room_name: str
    participant_name: str
    agent_id: str | None = None
    dispatch_success: bool | None = None
    agent_ready: bool | None = None
    expires_in: int = TOKEN_EXPIRATION_SECONDS


def _secret_client():
    # Prefer explicit env credentials (works reliably in containers where SSO refresh may not).
    if os.environ.get("AWS_ACCESS_KEY_ID") and os.environ.get("AWS_SECRET_ACCESS_KEY"):
        session = boto3.Session()
        return session.client("secretsmanager", region_name=AWS_REGION)

    # Otherwise, use profile if provided (for local Docker with mounted ~/.aws).
    profile = os.environ.get("AWS_PROFILE")
    session = boto3.Session(profile_name=profile) if profile else boto3.Session()
    return session.client("secretsmanager", region_name=AWS_REGION)


def _get_secret_value(secret_id: str) -> str | None:
    try:
        client = _secret_client()
        resp = client.get_secret_value(SecretId=secret_id)
        return resp.get("SecretString")
    except ClientError:
        return None


@lru_cache(maxsize=8)
def _get_livekit_credentials() -> tuple[str, str, str]:
    """
    Resolve LiveKit Cloud credentials.

    Priority:
      1) /workweaver/{ENV}/livekit/* (preferred)
      2) workweaver-{ENV}/livekit-* (legacy)
      3) env vars LIVEKIT_URL/LIVEKIT_ROOM_URL + LIVEKIT_API_KEY + LIVEKIT_API_SECRET
    """
    # 1) New structure used across the repo.
    url = _get_secret_value(f"/workweaver/{ENVIRONMENT}/livekit/url")
    api_key = _get_secret_value(f"/workweaver/{ENVIRONMENT}/livekit/api_key")
    api_secret = _get_secret_value(f"/workweaver/{ENVIRONMENT}/livekit/api_secret")

    # 2) Legacy structure (still present in dev).
    if not url:
        url = _get_secret_value(f"workweaver-{ENVIRONMENT}/livekit-url")
    if not api_key:
        api_key = _get_secret_value(f"workweaver-{ENVIRONMENT}/livekit-api-key")
    if not api_secret:
        api_secret = _get_secret_value(f"workweaver-{ENVIRONMENT}/livekit-api-secret")

    # 3) Explicit env overrides (for fully offline local dev).
    url = url or os.environ.get("LIVEKIT_URL") or os.environ.get("LIVEKIT_ROOM_URL")
    api_key = api_key or os.environ.get("LIVEKIT_API_KEY")
    api_secret = api_secret or os.environ.get("LIVEKIT_API_SECRET")

    if not url or not api_key or not api_secret:
        raise ValueError("LiveKit credentials are not configured")

    return str(url), str(api_key), str(api_secret)


def _validate_room_name(room_name: str, tenant_id: str) -> bool:
    # Must start with tenant_id prefix
    if not room_name or not tenant_id:
        return False
    if not room_name.startswith(f"{tenant_id}-"):
        return False

    # Must include "-room-" immediately after tenant prefix.
    suffix = room_name[len(tenant_id) :]
    if not suffix.startswith("-room-"):
        return False

    room_id = suffix[6:]  # after "-room-"
    if not room_id:
        return False

    # Only allow alnum + hyphens.
    if not room_name.replace("-", "").isalnum():
        return False

    return True


def _create_jwt_token(
    api_key: str,
    api_secret: str,
    room_name: str,
    identity: str,
    metadata_json: str,
) -> str:
    token = (
        AccessToken(api_key, api_secret)
        .with_identity(identity)
        .with_grants(VideoGrants(room_join=True, room=room_name))
        .with_metadata(metadata_json)
        .with_ttl(timedelta(seconds=TOKEN_EXPIRATION_SECONDS))
    )
    return token.to_jwt()


async def _dispatch_agent(
    livekit_url: str,
    api_key: str,
    api_secret: str,
    room_name: str,
    requested_agent_name: str,
    participant_name: str,
    metadata: str,
    require_running: bool = False,
) -> tuple[str, bool, bool]:
    candidates = _build_agent_candidates(requested_agent_name)
    selected_agent = candidates[0] if candidates else requested_agent_name

    api_timeout = aiohttp.ClientTimeout(
        total=max(0.8, float(DISPATCH_TASK_TIMEOUT_SECONDS or 0.0)),
    )

    async with LiveKitAPI(livekit_url, api_key, api_secret, timeout=api_timeout) as lkapi:
        # Ensure room exists before dispatching to avoid dispatch/room-creation races.
        try:
            tenant_id = ""
            try:
                if "-room-" in room_name:
                    tenant_id = str(room_name).split("-room-", 1)[0]
            except Exception:
                logger.debug("Failed to parse tenant_id from room name", extra={"room_name": room_name}, exc_info=True)
                tenant_id = ""

            default_empty_timeout = 15 if tenant_id == "testing" else 60
            empty_timeout = int(
                os.environ.get(
                    "LIVEKIT_ROOM_EMPTY_TIMEOUT_SECONDS",
                    str(default_empty_timeout),
                )
            )
        except Exception:
            logger.debug("Failed to parse room empty timeout", extra={"room_name": room_name}, exc_info=True)
            empty_timeout = 60
        try:
            await lkapi.room.create_room(CreateRoomRequest(name=room_name, empty_timeout=max(5, empty_timeout)))
        except Exception:
            logger.debug("Room pre-creation failed", extra={"room_name": room_name}, exc_info=True)

        for agent_name in candidates:
            selected_agent = agent_name
            try:
                dispatch = await lkapi.agent_dispatch.create_dispatch(
                    CreateAgentDispatchRequest(
                        agent_name=agent_name,
                        room=room_name,
                        metadata=metadata,
                    )
                )
                if require_running:
                    dispatch_id = str(getattr(dispatch, "id", "") or "").strip()
                    running = await _wait_for_dispatch_running(
                        lkapi,
                        dispatch_id=dispatch_id,
                        room_name=room_name,
                    )
                    if not running:
                        logger.warning(
                            "LiveKit agent dispatch did not reach running state",
                            extra={
                                "room_name": room_name,
                                "agent_name": agent_name,
                                "dispatch_id": dispatch_id,
                            },
                        )
                        continue
                    agent_ready = await _wait_for_remote_participant(
                        lkapi,
                        room_name=room_name,
                        participant_name=participant_name,
                    )
                    return selected_agent, True, agent_ready

                return selected_agent, True, False
            except Exception as e:
                logger.warning(
                    "LiveKit agent dispatch failed",
                    extra={
                        "room_name": room_name,
                        "agent_name": agent_name,
                        "error": str(e),
                    },
                )
                continue

    return selected_agent, False, False


async def _cleanup_voice_session_after_dispatch_failure(
    *,
    livekit_url: str,
    api_key: str,
    api_secret: str,
    room_name: str,
) -> None:
    cleanup_timeout = max(
        0.5,
        float(os.environ.get("LIVEKIT_DISPATCH_CLEANUP_TIMEOUT_SECONDS", "2.5")),
    )
    try:
        await asyncio.wait_for(
            _cleanup_room_dispatches(
                livekit_url=livekit_url,
                api_key=api_key,
                api_secret=api_secret,
                room_name=room_name,
                delete_room=True,
            ),
            timeout=cleanup_timeout,
        )
    except Exception:
        logger.debug(
            "Voice-session dispatch failure cleanup timed out or failed",
            extra={"room_name": room_name},
            exc_info=True,
        )


def _voice_session_dispatch_unavailable(detail: str) -> HTTPException:
    return HTTPException(
        status_code=503,
        detail=detail,
        headers={"Retry-After": "5"},
    )


async def _cleanup_room_dispatches(
    *,
    livekit_url: str,
    api_key: str,
    api_secret: str,
    room_name: str,
    delete_room: bool = False,
) -> None:
    try:
        async with LiveKitAPI(livekit_url, api_key, api_secret) as lkapi:
            dispatches = list(await lkapi.agent_dispatch.list_dispatch(room_name) or [])
            for dispatch in dispatches:
                dispatch_id = str(getattr(dispatch, "id", "") or "").strip()
                if not dispatch_id:
                    continue
                try:
                    await lkapi.agent_dispatch.delete_dispatch(dispatch_id, room_name)
                except Exception:
                    logger.debug(
                        "Dispatch delete failed",
                        extra={"dispatch_id": dispatch_id, "room_name": room_name},
                        exc_info=True,
                    )
            if delete_room:
                try:
                    await lkapi.room.delete_room(DeleteRoomRequest(room=room_name))
                except Exception:
                    logger.debug("Room delete failed", extra={"room_name": room_name}, exc_info=True)
    except Exception:
        logger.warning(
            "LiveKit cleanup failed; orphaned resources possible", extra={"room_name": room_name}, exc_info=True
        )


def _build_agent_candidates(requested_agent_name: str) -> list[str]:
    explicit_requested = str(requested_agent_name or "").strip()
    if explicit_requested and not ALLOW_FALLBACK_FOR_EXPLICIT_AGENT:
        return [explicit_requested]

    candidates: list[str] = []

    def add(value: str | None) -> None:
        candidate = str(value or "").strip()
        if candidate and candidate not in candidates:
            candidates.append(candidate)

    add(requested_agent_name)
    add(DEFAULT_AGENT_NAME)
    for fallback in AGENT_FALLBACKS:
        add(fallback)
    return candidates


def _coerce_job_status(status: object) -> int:
    try:
        return int(status)  # type: ignore[arg-type]
    except Exception:
        try:
            return int(getattr(status, "value", 0) or 0)
        except Exception:
            return 0


async def _wait_for_dispatch_running(
    lkapi: LiveKitAPI,
    *,
    dispatch_id: str,
    room_name: str,
) -> bool:
    if not dispatch_id:
        return False

    deadline = time.monotonic() + max(0.0, DISPATCH_RUNNING_WAIT_SECONDS)
    while time.monotonic() <= deadline:
        try:
            # livekit-api==1.1.0 expects room name directly; newer variants may
            # expose shape differences on returned dispatch/job state objects.
            dispatches = list(await lkapi.agent_dispatch.list_dispatch(room_name) or [])
            for dispatch in dispatches:
                current_dispatch_id = str(getattr(dispatch, "id", "") or "")
                if current_dispatch_id != dispatch_id:
                    continue
                state = getattr(dispatch, "state", None)
                jobs = list(getattr(state, "jobs", []) or []) or list(getattr(dispatch, "jobs", []) or [])
                saw_pending_job = False
                for job in jobs:
                    status = _coerce_job_status(
                        getattr(getattr(job, "state", None), "status", None) or getattr(job, "status", None)
                    )
                    if status in (1, 2):  # JS_RUNNING | JS_SUCCESS
                        return True
                    if status == 3:  # JS_FAILED
                        return False
                    if status == 0:  # JS_PENDING
                        saw_pending_job = True
                # Keep polling while pending/queued so we do not return a false "ready".
                if saw_pending_job or not jobs:
                    break
        except Exception:
            return False

        await asyncio.sleep(max(0.05, AGENT_POLL_INTERVAL_SECONDS))

    return False


async def _wait_for_remote_participant(
    lkapi: LiveKitAPI,
    *,
    room_name: str,
    participant_name: str,
) -> bool:
    deadline = time.monotonic() + max(0.0, AGENT_READY_WAIT_SECONDS)
    while time.monotonic() <= deadline:
        try:
            response = await lkapi.room.list_participants(ListParticipantsRequest(room=room_name))
            participants = list(getattr(response, "participants", []) or [])
            for participant in participants:
                identity = str(getattr(participant, "identity", "") or "").strip()
                if identity and identity != participant_name:
                    return True
        except Exception:
            return False

        await asyncio.sleep(max(0.05, AGENT_POLL_INTERVAL_SECONDS))

    return False


@router.post("/livekit-token", response_model=LiveKitTokenResponse)
@limiter.limit("30/minute")
async def livekit_token(
    request: Request,
    req: LiveKitTokenRequest,
    authenticated_tenant_id: str | None = Depends(resolve_optional_verified_tenant_id),
) -> LiveKitTokenResponse:
    """
    Generate a LiveKit token and (best-effort) dispatch Zara's agent early.

    This is intentionally "silent" for the user: callers should not surface internal
    states like warmup/dispatch to UI. Dispatch is bounded to 2s so clicks never hang.
    """
    body_tenant_id = str(req.tenant_id or "").strip()
    verified_tenant_id = str(authenticated_tenant_id or "").strip()
    if body_tenant_id and verified_tenant_id and body_tenant_id != verified_tenant_id:
        raise HTTPException(
            status_code=403,
            detail="Tenant ID mismatch between request body and authenticated identity",
        )

    effective_tenant_id = verified_tenant_id or body_tenant_id
    if not effective_tenant_id:
        raise HTTPException(
            status_code=422,
            detail="tenant_id is required for unauthenticated requests",
        )

    if not _validate_room_name(req.room_name, effective_tenant_id):
        raise HTTPException(
            status_code=403,
            detail=f"Room name must be prefixed with tenant_id: {effective_tenant_id}-room-<uuid>",
        )

    source = str(req.metadata.get("source") or "").strip().lower()

    started = time.perf_counter()
    try:
        livekit_url, api_key, api_secret = _get_livekit_credentials()
    except Exception as e:
        logger.warning("LiveKit credentials unavailable", extra={"error": str(e)})
        raise HTTPException(status_code=503, detail="Voice demo is temporarily unavailable") from e

    metadata_dict = dict(req.metadata or {})
    metadata_dict["tenant_id"] = effective_tenant_id
    # ZARA-5: Propagate agent_id into voice session metadata
    if req.agent_id:
        metadata_dict["agent_id"] = req.agent_id

    if source == "landing_widget":
        zara_access_token = str(req.zara_access_token or "").strip()
        if not zara_access_token:
            raise HTTPException(status_code=401, detail="waitlist_required")
        try:
            zara_access_claims = _verify_zara_access_token(zara_access_token, api_secret)
        except Exception:
            raise HTTPException(status_code=401, detail="invalid_waitlist_access")

    # Server-driven landing demo guardrails (avoid browser-enforced session control).
    if source == "landing_widget":
        tenant_cfg = metadata_dict.get("tenant_config") if isinstance(metadata_dict, dict) else None
        tenant_cfg = tenant_cfg if isinstance(tenant_cfg, dict) else {}
        tenant_cfg = dict(tenant_cfg)
        tenant_cfg["hard_end_seconds"] = 60
        tenant_cfg["require_client_ready"] = False
        metadata_dict["tenant_config"] = tenant_cfg
        lead_email = str(zara_access_claims.get("sub") or "").strip().lower()
        if lead_email:
            metadata_dict["zara_user_email"] = lead_email
        if "wl_pos" in zara_access_claims:
            try:
                metadata_dict["zara_waitlist_position"] = int(zara_access_claims.get("wl_pos"))
            except Exception:
                logger.debug("Failed to parse waitlist position from zara access claims", exc_info=True)

    metadata_json = json.dumps(metadata_dict)

    requested_agent_name = (req.agent_id or DEFAULT_AGENT_NAME).strip()
    resolved_agent_name = requested_agent_name
    dispatch_meta: dict[str, Any] = {
        "tenant_id": effective_tenant_id,
        "source": "backend-api",
    }
    # ZARA-5: Include agent_id in dispatch metadata
    if req.agent_id:
        dispatch_meta["agent_id"] = req.agent_id
    dispatch_metadata = json.dumps(dispatch_meta)

    # Start dispatch in background while we generate the JWT.
    dispatch_task = asyncio.create_task(
        _dispatch_agent(
            livekit_url=livekit_url,
            api_key=api_key,
            api_secret=api_secret,
            room_name=req.room_name,
            requested_agent_name=requested_agent_name,
            participant_name=req.participant_name,
            metadata=dispatch_metadata,
        )
    )

    token = _create_jwt_token(
        api_key=api_key,
        api_secret=api_secret,
        room_name=req.room_name,
        identity=req.participant_name,
        metadata_json=metadata_json,
    )

    dispatch_success: bool | None = None
    agent_ready: bool | None = None
    try:
        resolved_agent_name, dispatch_success, agent_ready = await dispatch_task
    except Exception:
        dispatch_success = False
        agent_ready = False

    elapsed_ms = int((time.perf_counter() - started) * 1000)
    logger.info(
        "LiveKit token issued",
        extra={
            "room_name": req.room_name,
            "tenant_id": effective_tenant_id,
            "agent_name": resolved_agent_name,
            "dispatch_success": dispatch_success,
            "agent_ready": agent_ready,
            "elapsed_ms": elapsed_ms,
        },
    )

    if not dispatch_success:
        cleanup_timeout = max(
            0.5,
            float(os.environ.get("LIVEKIT_DISPATCH_CLEANUP_TIMEOUT_SECONDS", "2.5")),
        )
        try:
            await asyncio.wait_for(
                _cleanup_room_dispatches(
                    livekit_url=livekit_url,
                    api_key=api_key,
                    api_secret=api_secret,
                    room_name=req.room_name,
                    delete_room=True,
                ),
                timeout=cleanup_timeout,
            )
        except Exception:
            logger.debug(
                "Post-dispatch-failure cleanup timed out or failed", extra={"room_name": req.room_name}, exc_info=True
            )
        raise HTTPException(
            status_code=503,
            detail="Voice demo is temporarily busy. Please retry in a moment.",
        )

    return LiveKitTokenResponse(
        token=token,
        room_url=livekit_url,
        room_name=req.room_name,
        participant_name=req.participant_name,
        agent_id=resolved_agent_name,
        dispatch_success=dispatch_success,
        agent_ready=agent_ready,
        expires_in=TOKEN_EXPIRATION_SECONDS,
    )


# ---------------------------------------------------------------------------
# Authenticated voice session — Mission Control
# ---------------------------------------------------------------------------


class AuthenticatedVoiceSessionResponse(BaseModel):
    token: str
    room_url: str
    room_name: str
    participant_name: str
    agent_id: str | None = None
    dispatch_success: bool | None = None
    expires_in: int = TOKEN_EXPIRATION_SECONDS


@router.post("/voice-session", response_model=AuthenticatedVoiceSessionResponse)
@limiter.limit("10/minute")
async def authenticated_voice_session(
    request: Request,
) -> AuthenticatedVoiceSessionResponse:
    """
    Issue a LiveKit room token for an authenticated tenant session.

    Unlike /jwt/livekit-token (public landing demo), this endpoint:
    - Requires a valid session cookie / JWT (tenant extracted from request.state)
    - Issues a tenant-scoped room with no demo guardrails (no 60s hard-end)
    - Dispatches Zara in the tenant's operational context

    Used by Mission Control's "Speak to Zara" panel.
    """
    from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id  # type: ignore[import]

    tenant_id = get_verified_tenant_id(
        request=request,
        x_tenant_id=request.headers.get("x-tenant-id"),
    )

    try:
        livekit_url, api_key, api_secret = _get_livekit_credentials()
    except Exception as e:
        logger.warning("LiveKit credentials unavailable for voice session", extra={"error": str(e)})
        raise HTTPException(status_code=503, detail="Voice service temporarily unavailable") from e

    import uuid as _uuid

    room_name = f"{tenant_id}-room-{_uuid.uuid4().hex[:12]}"
    participant_name = f"{tenant_id}-user"

    # ZARA-5: Extract agent_id from request body if present
    body_agent_id: str | None = None
    try:
        body = await request.json()
        if isinstance(body, dict):
            body_agent_id = str(body.get("agent_id") or "").strip() or None
    except Exception:
        logger.debug("Request body parse failed for voice session", exc_info=True)

    metadata_dict: dict[str, Any] = {
        "tenant_id": tenant_id,
        "source": "mission_control",
    }
    if body_agent_id:
        metadata_dict["agent_id"] = body_agent_id
    metadata_json = json.dumps(metadata_dict)

    resolved_agent_name = DEFAULT_AGENT_NAME
    dispatch_success: bool | None = None
    try:
        resolved_agent_name, dispatch_success, _ = await asyncio.wait_for(
            _dispatch_agent(
                livekit_url=livekit_url,
                api_key=api_key,
                api_secret=api_secret,
                room_name=room_name,
                requested_agent_name=DEFAULT_AGENT_NAME,
                participant_name=participant_name,
                metadata=json.dumps(
                    {
                        "tenant_id": tenant_id,
                        "source": "mission_control",
                    }
                ),
                require_running=True,
            ),
            timeout=_dispatch_timeout_seconds(),
        )
    except asyncio.TimeoutError as e:
        await _cleanup_voice_session_after_dispatch_failure(
            livekit_url=livekit_url,
            api_key=api_key,
            api_secret=api_secret,
            room_name=room_name,
        )
        logger.warning(
            "LiveKit voice-session dispatch timed out before readiness",
            extra={"room_name": room_name, "tenant_id": tenant_id, "agent_name": resolved_agent_name},
        )
        raise _voice_session_dispatch_unavailable("Voice service is still starting. Please retry in a moment.") from e
    except Exception:
        dispatch_success = False
        logger.warning(
            "LiveKit voice-session dispatch failed before readiness",
            extra={"room_name": room_name, "tenant_id": tenant_id, "agent_name": resolved_agent_name},
            exc_info=True,
        )

    if not dispatch_success:
        await _cleanup_voice_session_after_dispatch_failure(
            livekit_url=livekit_url,
            api_key=api_key,
            api_secret=api_secret,
            room_name=room_name,
        )
        raise _voice_session_dispatch_unavailable("Voice service is temporarily busy. Please retry in a moment.")

    token = _create_jwt_token(
        api_key=api_key,
        api_secret=api_secret,
        room_name=room_name,
        identity=participant_name,
        metadata_json=metadata_json,
    )

    return AuthenticatedVoiceSessionResponse(
        token=token,
        room_url=livekit_url,
        room_name=room_name,
        participant_name=participant_name,
        agent_id=resolved_agent_name,
        dispatch_success=dispatch_success,
        expires_in=TOKEN_EXPIRATION_SECONDS,
    )
