"""Admin pricing catalog endpoints."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id, require_admin_user_role
from apps.backend.services.admin.admin_permission import AdminPermission
from apps.backend.api.founder_admin import require_founder
from apps.backend.api.pagination import PaginationParams, build_pagination_dependency, paginate_items
from apps.backend.services.billing.pricing_catalog import (
    MarginGuardrailError,
    PricingCatalogError,
    PricingCatalogService,
)

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/admin/pricing", tags=["admin-pricing"])


class PublishCatalogRequest(BaseModel):
    catalog_id: str = Field(..., min_length=2, max_length=128)
    effective_from: str | None = Field(
        None,
        description="ISO-8601 timestamp when this version becomes active",
    )
    payload: dict[str, Any] = Field(default_factory=dict)


class AssignTenantCatalogRequest(BaseModel):
    catalog_id: str | None = Field(
        None,
        description="Catalog ID to assign. Null clears explicit assignment.",
    )
    effective_from: str | None = Field(
        None,
        description="ISO-8601 timestamp when assignment becomes active",
    )
    overrides: dict[str, Any] = Field(default_factory=dict)


class ValidateMarginRequest(BaseModel):
    payload: dict[str, Any] = Field(default_factory=dict)


class StripeSnapshotEntry(BaseModel):
    unit_amount: int = Field(..., description="Price in the smallest currency unit (cents).")
    currency: str = Field("usd", description="ISO 4217 currency code.")


class DriftCheckRequest(BaseModel):
    """Optional request body for the drift endpoint.

    When provided, ``stripe_catalog`` becomes the live snapshot. When omitted,
    the endpoint returns a clean baseline (no drift) — useful for the admin UI
    to verify the catalog shape before wiring Stripe.
    """

    stripe_catalog: dict[str, StripeSnapshotEntry] = Field(default_factory=dict)
    canonical: dict[str, dict[str, Any]] | None = Field(
        None,
        description="Optional canonical map; defaults to the active catalog's platform_fees.",
    )
    strict: bool = Field(False, description="Treat extras in Stripe as drift instead of warnings.")


def _pricing_service() -> PricingCatalogService:
    return PricingCatalogService()


@router.get("/catalog/active")
async def get_active_catalog(
    tenant_id: str | None = Query(None, description="Optional tenant-scoped catalog resolution"),
    as_of: str | None = Query(None, description="Optional ISO-8601 effective date"),
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.PRICING_READ)),
    actor_tenant: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    del admin_role
    del actor_tenant
    service = _pricing_service()
    try:
        if tenant_id:
            return service.get_tenant_catalog(tenant_id=tenant_id, as_of=as_of)
        return service.get_active_catalog(as_of=as_of)
    except PricingCatalogError as exc:
        logger.error("get_catalog failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Pricing catalog service unavailable") from exc


@router.post("/catalog/publish")
async def publish_catalog(
    request: PublishCatalogRequest,
    founder_email: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.PRICING_WRITE)),
    actor_tenant: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    service = _pricing_service()
    try:
        catalog = service.publish_catalog(
            catalog_id=request.catalog_id,
            effective_from=request.effective_from,
            payload=request.payload,
            published_by=actor_tenant,
        )
        return {"success": True, "catalog": catalog}
    except MarginGuardrailError as exc:
        logger.warning("publish_catalog margin guardrail violation: %s", exc)
        raise HTTPException(status_code=400, detail="Catalog violates margin guardrails") from exc
    except PricingCatalogError as exc:
        logger.error("publish_catalog failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Pricing catalog service unavailable") from exc


@router.get("/catalog/{catalog_id}/versions")
async def list_catalog_versions(
    catalog_id: str,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.PRICING_READ)),
    actor_tenant: str = Depends(get_verified_tenant_id),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> dict[str, Any]:
    del admin_role
    del actor_tenant
    service = _pricing_service()
    try:
        versions = service.list_catalog_versions(catalog_id)
        paged_versions, total = paginate_items(versions, pagination)
        return {"catalog_id": catalog_id, "versions": paged_versions, "count": total}
    except PricingCatalogError as exc:
        logger.error("list_catalog_versions failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Pricing catalog service unavailable") from exc


@router.put("/tenant/{tenant_id}/assignment")
async def assign_tenant_catalog(
    tenant_id: str,
    request: AssignTenantCatalogRequest,
    founder_email: str = Depends(require_founder),
    _perm=Depends(require_admin_permission_dep(AdminPermission.PRICING_WRITE)),
    actor_tenant: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    service = _pricing_service()
    try:
        assignment = service.assign_tenant_catalog(
            tenant_id=tenant_id,
            catalog_id=request.catalog_id,
            effective_from=request.effective_from,
            overrides=request.overrides,
            updated_by=actor_tenant,
        )
        return {"success": True, "assignment": assignment}
    except PricingCatalogError as exc:
        logger.error("assign_tenant_catalog failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Pricing catalog service unavailable") from exc


@router.get("/tenant/{tenant_id}")
async def get_tenant_catalog(
    tenant_id: str,
    as_of: str | None = Query(None),
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.PRICING_READ)),
    actor_tenant: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    del admin_role
    del actor_tenant
    service = _pricing_service()
    try:
        return service.get_tenant_catalog(tenant_id=tenant_id, as_of=as_of)
    except PricingCatalogError as exc:
        logger.error("get_tenant_catalog failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Pricing catalog service unavailable") from exc


@router.post("/catalog/validate-margin")
async def validate_margin_guardrails(
    request: ValidateMarginRequest,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.PRICING_READ)),
    actor_tenant: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    del admin_role
    del actor_tenant
    service = _pricing_service()
    try:
        candidate = service._deep_merge(service.default_catalog(), request.payload)  # noqa: SLF001
        service._validate_margin_guardrails(candidate)  # noqa: SLF001
        return {"valid": True}
    except MarginGuardrailError as exc:
        return {"valid": False, "error": str(exc)}


@router.get("/drift")
async def get_pricing_drift(
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.PRICING_READ)),
    actor_tenant: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return drift between the active pricing catalog and the live Stripe map.

    GET returns a clean baseline (no Stripe snapshot provided). To submit a
    snapshot, use ``POST /api/v1/admin/pricing/drift``.
    """

    del admin_role
    del actor_tenant
    service = _pricing_service()
    try:
        return service.detect_drift()
    except PricingCatalogError as exc:
        logger.error("get_pricing_drift failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Pricing catalog service unavailable") from exc


@router.post("/drift")
async def post_pricing_drift(
    request: DriftCheckRequest,
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.PRICING_READ)),
    actor_tenant: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Return drift against a Stripe snapshot supplied in the request body."""

    del admin_role
    del actor_tenant
    service = _pricing_service()
    try:
        stripe_payload = {
            key: entry.model_dump() for key, entry in (request.stripe_catalog or {}).items()
        }
        return service.detect_drift(
            stripe_catalog=stripe_payload,
            canonical=request.canonical,
            strict=request.strict,
        )
    except PricingCatalogError as exc:
        logger.error("post_pricing_drift failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Pricing catalog service unavailable") from exc


@router.get("/catalogs")
async def list_all_catalogs(
    admin_role=Depends(require_admin_user_role),
    _perm=Depends(require_admin_permission_dep(AdminPermission.PRICING_READ)),
    actor_tenant: str = Depends(get_verified_tenant_id),
    pagination: PaginationParams = Depends(build_pagination_dependency(default_limit=50, max_limit=200)),
) -> dict[str, Any]:
    """Return every published pricing catalog with version history."""

    del admin_role
    del actor_tenant
    service = _pricing_service()
    try:
        catalogs = service.list_catalogs()
        paged, total = paginate_items(catalogs, pagination)
        return {"catalogs": paged, "count": total}
    except PricingCatalogError as exc:
        logger.error("list_all_catalogs failed: %s", exc, exc_info=True)
        raise HTTPException(status_code=503, detail="Pricing catalog service unavailable") from exc
