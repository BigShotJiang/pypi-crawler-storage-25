"""User identity endpoints — multi-provider sign-in linking (#828).

Manages sign-in method linking for authenticated users:

  GET    /api/v1/auth/identities              — list linked providers
  POST   /api/v1/auth/identities/link/start   — initiate OAuth for a new provider
  POST   /api/v1/auth/identities/link/complete — complete linking after OAuth callback
  DELETE /api/v1/auth/identities/{provider}   — unlink a provider

Original read-only slice shipped in #773 (f143e2b3).
Full multi-provider linking implemented in #828.
"""

from __future__ import annotations

import logging
import os
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_email,
)
from apps.backend.services.identity_links import (
    IdentityLinkConflictError,
    delete_identity_link,
    list_links_for_tenant,
    put_identity_link,
    supported_providers,
)
from apps.backend.services.tenant_provisioning import get_tenant_provisioning_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/auth/identities", tags=["auth", "identities"])

_PROVIDER_DISPLAY_NAMES: dict[str, str] = {
    "google": "Google",
    "microsoft": "Microsoft",
    "zoho": "Zoho",
    "github": "GitHub",
    "email": "Email & password",
    "cognito": "Email & password",
}

# OAuth authorize URLs per provider (used by link/start)
_PROVIDER_AUTHORIZE_URLS: dict[str, str] = {
    "google": "https://accounts.google.com/o/oauth2/v2/auth",
    "microsoft": "https://login.microsoftonline.com/common/oauth2/v2.0/authorize",
    "zoho": "https://accounts.zoho.com/oauth/v2/auth",
}


def _provider_display_name(provider: str) -> str:
    """Map raw provider key to a human-friendly display name."""
    return _PROVIDER_DISPLAY_NAMES.get((provider or "").lower(), provider or "Unknown")


class LinkStartRequest(BaseModel):
    """Request body for initiating a provider link."""

    provider: str


class LinkCompleteRequest(BaseModel):
    """Request body for completing a provider link."""

    provider: str
    provider_user_id: str
    email: str
    linking_state: str


@router.get("")
async def list_identities(
    tenant_id: str = Depends(get_verified_tenant_id),
    user_email: str = Depends(get_verified_user_email),
) -> dict[str, Any]:
    """Return the linked sign-in methods for the current authenticated user."""
    if not tenant_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Authenticated user has no tenant_id",
        )

    # Read from identity_links table
    links = list_links_for_tenant(tenant_id)

    if links:
        # Multi-provider mode: build identities from identity_links table
        identities = []
        for link in links:
            provider = link.get("provider", "")
            can_remove = len(links) > 1 and not link.get("is_primary", False)
            identities.append(
                {
                    "provider": provider,
                    "provider_display_name": _provider_display_name(provider),
                    "email": link.get("email", ""),
                    "is_primary": link.get("is_primary", False),
                    "linked_at": link.get("linked_at", ""),
                    "last_login_at": link.get("last_login_at", ""),
                    "can_remove": can_remove,
                    "remove_blocked_reason": "" if can_remove else "This is your only sign-in method",
                }
            )
        primary = next((i for i in identities if i["is_primary"]), identities[0] if identities else None)
        primary_provider = primary["provider"] if primary else ""
    else:
        # Fallback: single-provider mode from tenant record
        provisioning = get_tenant_provisioning_service()
        tenant: dict[str, Any] | None = None
        try:
            tenant = provisioning.get_tenant(tenant_id)
        except Exception:
            logger.exception("auth_identities.tenant_lookup_failed tenant_id=%s", tenant_id)

        auth_provider = ""
        email = (user_email or "").strip()
        linked_at = ""
        if tenant:
            auth_provider = str(tenant.get("auth_provider") or "").strip()
            if not email:
                email = str(tenant.get("owner_email") or tenant.get("email") or "").strip()
            linked_at = str(tenant.get("created_at") or "").strip()
        if not auth_provider:
            auth_provider = "email"

        primary_provider = auth_provider.lower()
        identities = [
            {
                "provider": primary_provider,
                "provider_display_name": _provider_display_name(primary_provider),
                "email": email,
                "is_primary": True,
                "linked_at": linked_at,
                "last_login_at": "",
                "can_remove": False,
                "remove_blocked_reason": "This is your only sign-in method",
            }
        ]

    # Determine which providers can still be linked
    linked_providers = {i["provider"] for i in identities}
    available_for_linking = [p for p in supported_providers() if p not in linked_providers]

    return {
        "identities": identities,
        "primary_provider": primary_provider,
        "primary_provider_display_name": _provider_display_name(primary_provider),
        "linking_supported": True,
        "supported_providers_for_linking": [
            {"provider": p, "provider_display_name": _provider_display_name(p)} for p in available_for_linking
        ],
    }


@router.post("/link/start")
async def link_start(
    body: LinkStartRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Initiate re-auth with a new provider for identity linking.

    Returns the provider-specific OAuth authorize URL the frontend
    should redirect the user to.
    """
    provider = body.provider.lower().strip()
    if provider not in supported_providers():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Provider '{provider}' is not supported for linking. Supported: {supported_providers()}",
        )

    # Check if this provider is already linked
    existing_links = list_links_for_tenant(tenant_id)
    if any(link.get("provider") == provider for link in existing_links):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Provider '{provider}' is already linked to this account.",
        )

    authorize_url = _PROVIDER_AUTHORIZE_URLS.get(provider)
    if not authorize_url:
        raise HTTPException(
            status_code=status.HTTP_501_NOT_IMPLEMENTED,
            detail=f"OAuth authorize URL not configured for provider '{provider}'.",
        )

    # Build the redirect URL with linking context
    redirect_uri = os.environ.get("AUTH_REDIRECT_URI", "https://workweaver.ai/auth/callback")
    scopes = {
        "google": "openid email profile",
        "microsoft": "openid email profile User.Read",
        "zoho": "AaaServer.profile.READ",
    }

    # Mint a signed linking state so link_complete can verify that the
    # flow was initiated by an authenticated session for this tenant.
    from apps.backend.services.session.browser_session import mint_linking_state

    linking_state = mint_linking_state(tenant_id=tenant_id, provider=provider)

    return {
        "authorize_url": authorize_url,
        "redirect_uri": redirect_uri,
        "scope": scopes.get(provider, "openid email profile"),
        "provider": provider,
        "provider_display_name": _provider_display_name(provider),
        "linking_mode": True,
        "linking_state": linking_state,
    }


@router.post("/link/complete")
async def link_complete(
    body: LinkCompleteRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    """Complete identity linking after OAuth callback.

    The frontend sends the verified provider_user_id and email from
    the OAuth callback along with the ``linking_state`` token that was
    returned by ``link/start``.  The state token proves the linking
    flow was initiated by an authenticated session for this tenant.
    """
    provider = body.provider.lower().strip()
    if provider not in supported_providers():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Provider '{provider}' is not supported for linking.",
        )

    # Verify the signed linking state before trusting client-supplied fields
    from apps.backend.services.session.browser_session import LinkingStateError, verify_linking_state

    try:
        verify_linking_state(
            body.linking_state,
            expected_tenant_id=tenant_id,
            expected_provider=provider,
        )
    except LinkingStateError as exc:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid or expired linking state: {exc}",
        )

    if not body.provider_user_id or not body.email:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="provider_user_id and email are required.",
        )

    # Check if this provider identity is already linked to a DIFFERENT tenant
    from apps.backend.services.identity_links import get_identity_link

    existing = get_identity_link(provider, body.provider_user_id)
    if existing and existing.get("tenant_id") != tenant_id:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                f"This {_provider_display_name(provider)} account is already linked to a different "
                "Workweaver account. Each provider identity can only be linked to one account."
            ),
        )

    # Ensure the primary provider is also in the links table
    existing_links = list_links_for_tenant(tenant_id)
    if not existing_links:
        # Bootstrap: migrate the primary provider from tenant record to links table
        provisioning = get_tenant_provisioning_service()
        tenant = provisioning.get_tenant(tenant_id)
        if tenant:
            primary_provider = str(tenant.get("auth_provider") or "").strip().lower()
            primary_user_id = str(tenant.get("owner_user_id") or "").strip()
            primary_email = str(tenant.get("owner_email") or tenant.get("email") or "").strip()
            if primary_provider and primary_user_id:
                # Strip provider prefix if present (e.g. "google:12345" → "12345")
                if ":" in primary_user_id:
                    primary_user_id = primary_user_id.split(":", 1)[1]
                put_identity_link(
                    tenant_id=tenant_id,
                    provider=primary_provider,
                    provider_user_id=primary_user_id,
                    email=primary_email,
                    is_primary=True,
                )
            elif primary_provider and primary_email:
                # Edge case: tenant has auth_provider but no owner_user_id
                # (e.g. email/password users provisioned before user IDs were stored).
                # Use email as a deterministic surrogate ID so the bootstrap still
                # creates a primary link and doesn't silently skip.
                logger.warning(
                    "auth_identities.bootstrap_no_user_id tenant=%s provider=%s using_email_surrogate",
                    tenant_id,
                    primary_provider,
                )
                put_identity_link(
                    tenant_id=tenant_id,
                    provider=primary_provider,
                    provider_user_id=primary_email,
                    email=primary_email,
                    is_primary=True,
                )

    # Write the new link (ConditionExpression prevents cross-tenant race)
    try:
        put_identity_link(
            tenant_id=tenant_id,
            provider=provider,
            provider_user_id=body.provider_user_id,
            email=body.email,
            is_primary=False,
        )
    except IdentityLinkConflictError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=(
                f"This {_provider_display_name(provider)} account is already linked to a different "
                "Workweaver account. Each provider identity can only be linked to one account."
            ),
        )

    # Return updated identity list
    return await list_identities(tenant_id=tenant_id, user_email=body.email)


@router.delete("/{provider}")
async def unlink_provider(
    provider: str,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_email: str = Depends(get_verified_user_email),
) -> dict[str, Any]:
    """Remove a linked sign-in provider.

    Refuses if it would leave the tenant with zero login methods.
    """
    provider = provider.lower().strip()

    links = list_links_for_tenant(tenant_id)

    if len(links) <= 1:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot remove your only sign-in method. Link another provider first.",
        )

    target_link = next((link for link in links if link.get("provider") == provider), None)
    if not target_link:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"Provider '{provider}' is not linked to this account.",
        )

    if target_link.get("is_primary", False):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Cannot remove the primary sign-in provider. Change your primary provider first.",
        )

    delete_identity_link(provider, target_link["provider_user_id"])
    logger.info("auth_identities.unlinked provider=%s tenant=%s", provider, tenant_id)

    return await list_identities(tenant_id=tenant_id, user_email=user_email)
