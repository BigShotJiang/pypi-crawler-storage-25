"""Workspace Operational Context Permission API."""

from __future__ import annotations

from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_id,
    get_verified_user_role,
)
from apps.backend.models.user import UserRole
from apps.backend.services.context_permissions import (
    ContextPermissionGrant,
    ContextPermissionScope,
    ContextPermissionService,
    get_context_permission_service,
    same_workspace,
)

router = APIRouter(prefix="/api/v1/context", tags=["context-permissions"])


class ContextShareRequest(BaseModel):
    grant_to: str = Field(..., min_length=1)
    scope: ContextPermissionScope = Field(default_factory=ContextPermissionScope)
    expires_at: str
    rights: list[str] = Field(default_factory=lambda: ["read"])


def _require_owner(user_role: UserRole) -> None:
    if user_role != UserRole.ADMIN:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Owner role required")


def _cross_workspace_guard(path_workspace_id: str, verified_workspace_id: str) -> None:
    if not same_workspace(path_workspace_id, verified_workspace_id):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Workspace mismatch")


@router.get("/workspace/{workspace_id:path}")
async def workspace_context(
    workspace_id: str,
    member_id: str | None = Query(None),
    kind: str | None = Query(None),
    entity: str | None = Query(None),
    since: str | None = Query(None),
    cursor: str | None = Query(None),
    limit: int = Query(50, ge=1, le=200),
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    user_role: UserRole = Depends(get_verified_user_role),
    service: ContextPermissionService = Depends(get_context_permission_service),
) -> dict[str, Any]:
    _cross_workspace_guard(workspace_id, tenant_id)
    try:
        return service.query_workspace_context(
            workspace_id=tenant_id,
            actor_id=user_id,
            actor_role=user_role,
            member_id=member_id,
            kind=kind,
            entity=entity,
            since=since,
            cursor=cursor,
            limit=limit,
        )
    except PermissionError as exc:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail=str(exc)) from exc


@router.post("/share", response_model=ContextPermissionGrant, status_code=status.HTTP_201_CREATED)
async def share_context(
    body: ContextShareRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
    user_id: str = Depends(get_verified_user_id),
    user_role: UserRole = Depends(get_verified_user_role),
    service: ContextPermissionService = Depends(get_context_permission_service),
) -> ContextPermissionGrant:
    _require_owner(user_role)
    try:
        return service.create_grant(
            workspace_id=tenant_id,
            grant_to=body.grant_to,
            scope=body.scope,
            expires_at=body.expires_at,
            rights=body.rights,
            created_by=user_id,
        )
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_400_BAD_REQUEST, detail=str(exc)) from exc
