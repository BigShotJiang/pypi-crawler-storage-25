"""Objective Board API (#864).

Endpoints:
    GET /api/v1/board/objectives              — full objective board
    GET /api/v1/board/objectives/{goal_id}    — single objective row
    GET /api/v1/board/objectives/deletion     — weekly deletion candidates
"""

from __future__ import annotations

import logging

from fastapi import APIRouter, Depends, HTTPException

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.models.objective_board import (
    ObjectiveBoardResponse,
    ObjectiveRow,
)
from apps.backend.services.execution_proof_gate import ExecutionProofGateService
from apps.backend.services.goal_spec_service import GoalSpecService
from apps.backend.services.objective_board_service import ObjectiveBoardService
from apps.backend.services.run_state_service import RunStateService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/board/objectives", tags=["objective-board"])

# Wire service dependencies (#873)
_goal_spec_service = GoalSpecService()
_run_state_service = RunStateService()
_epg_service = ExecutionProofGateService()
_service = ObjectiveBoardService(
    goal_spec_service=_goal_spec_service,
    run_state_service=_run_state_service,
    epg_service=_epg_service,
)


@router.get("", response_model=ObjectiveBoardResponse)
async def get_board(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ObjectiveBoardResponse:
    """Get the full objective board for the authenticated tenant."""
    return await _service.get_board(tenant_id)


@router.get("/deletion", response_model=list[ObjectiveRow])
async def get_deletion_candidates(
    tenant_id: str = Depends(get_verified_tenant_id),
) -> list[ObjectiveRow]:
    """Get objectives flagged for weekly deletion review."""
    return await _service.get_deletion_candidates(tenant_id)


@router.get("/{goal_id}", response_model=ObjectiveRow)
async def get_objective(
    goal_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ObjectiveRow:
    """Get a single objective row by goal_id."""
    row = await _service.get_objective(tenant_id, goal_id)
    if row is None:
        raise HTTPException(status_code=404, detail=f"Objective {goal_id} not found")
    return row
