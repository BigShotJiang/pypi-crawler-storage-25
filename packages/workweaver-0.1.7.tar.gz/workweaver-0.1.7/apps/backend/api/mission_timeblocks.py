"""``/api/v1/mission/timeblocks`` — timezone-aware Mission Calendar listing.

Closes #2714 acceptance:
- ``GET /api/v1/mission/timeblocks`` honors ``?tz=`` query parameter.
- Default tz = caller's ``Member.timezone``, falling back to
  ``Workspace.timezone``, falling back to ``UTC``.
- Each block surfaces ``canonical_hour_bucket`` (UTC, audit anchor) AND
  ``display_for_local`` (rendered in the requested zone). The audit anchor
  NEVER drifts.

Idiot-index discipline:
- ONE canonical resolver for the effective tz: :func:`resolve_timezone`.
- ONE library: stdlib ``zoneinfo``. NEVER ``pytz``.
- NO parallel timezone schema. The string IS the field.
"""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException, Query
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import (
    get_verified_tenant_id,
    get_verified_user_role,
)
from apps.backend.models.time_block import TimeBlock, TimeBlockState
from apps.backend.models.user import UserRole
from apps.backend.utils.timezone import is_valid_timezone, resolve_timezone

logger = logging.getLogger(__name__)

# Standalone router — mounts under ``/api/v1/mission`` directly. Tests
# instantiate a FastAPI app and ``include_router(router)`` so the full
# prefix is on the router itself; the parent ``mission.py`` aggregator
# avoids re-prefixing this module to keep the test contract simple.
router = APIRouter(prefix="/api/v1/mission", tags=["mission"])


class TimeBlockEnvelope(BaseModel):
    """A single TimeBlock plus its localized display rendering."""

    block_id: str
    state: str
    objective: str
    started_at: str
    canonical_hour_bucket: str
    display_for_local: str
    metadata: dict[str, Any] = Field(default_factory=dict)
    blocker_reason: str | None = Field(
        default=None,
        description=(
            "User-facing explanation when ``state == 'blocked'`` (#2740). "
            "Preserved verbatim from the model — frontend HTML-escapes at render."
        ),
    )
    unblockable: bool | None = Field(
        default=None,
        description=(
            "Whether the requesting Member has authority to unblock this block (#2740). "
            "Owner (UserRole.ADMIN) can always unblock; Member can unblock only "
            "TimeBlocks they own (``block.agent_id == member.member_id``). "
            "``None`` for non-blocked blocks — the field is meaningful only when "
            "``state == 'blocked'``."
        ),
    )


class TimeBlockListResponse(BaseModel):
    """Mission Calendar listing payload."""

    timezone: str = Field(
        ..., description="Effective IANA tz used to derive ``display_for_local``."
    )
    blocks: list[TimeBlockEnvelope] = Field(default_factory=list)


def _get_ledger() -> Any:
    """Indirection seam — overridable in tests via monkeypatch."""
    from apps.backend.services.agent_work_ledger import get_agent_work_ledger_service

    return get_agent_work_ledger_service()


def _is_blocked(block: TimeBlock) -> bool:
    """Return True when the block is in the BLOCKED state.

    Comparing string-coerced values keeps this robust against the
    ``use_enum_values=True`` model config that stores ``state`` as a
    plain string after validation.
    """
    return str(block.state) == TimeBlockState.BLOCKED.value


def _derive_unblockable(
    block: TimeBlock,
    *,
    user_role: UserRole | None,
    member_id: str | None,
) -> bool | None:
    """Per-request derivation of ``unblockable`` (#2740).

    Rules (Owner == UserRole.ADMIN; Member == any other role):

    * Non-BLOCKED blocks → ``None`` (field is only meaningful when blocked).
    * Owner (ADMIN) → ``True`` for every blocked block.
    * Member → ``True`` only for blocks they own
      (``block.agent_id == member_id``); ``False`` otherwise.
    * Caller without a resolvable member identity → ``False`` for safety.
    """
    if not _is_blocked(block):
        return None
    if user_role == UserRole.ADMIN:
        return True
    if not member_id:
        return False
    return str(block.agent_id) == str(member_id)


def _envelope(
    block: TimeBlock,
    tz_name: str,
    *,
    user_role: UserRole | None = None,
    member_id: str | None = None,
) -> TimeBlockEnvelope:
    return TimeBlockEnvelope(
        block_id=block.block_id,
        state=str(block.state),
        objective=block.objective,
        started_at=block.started_at.isoformat(),
        canonical_hour_bucket=block.canonical_hour_bucket.isoformat(),
        display_for_local=block.display_for(tz_name).isoformat(),
        metadata=dict(block.metadata or {}),
        blocker_reason=block.blocker_reason,
        unblockable=_derive_unblockable(
            block, user_role=user_role, member_id=member_id
        ),
    )


@router.get("/timeblocks", response_model=TimeBlockListResponse)
async def list_timeblocks(
    tenant_id: str = Depends(get_verified_tenant_id),
    user_role: UserRole = Depends(get_verified_user_role),
    tz: str | None = Query(
        default=None,
        description=(
            "IANA timezone string for rendering. "
            "Defaults to caller's Member.timezone, then Workspace.timezone, then UTC."
        ),
    ),
) -> TimeBlockListResponse:
    """Return the caller's TimeBlocks rendered in the effective timezone."""
    if tz is not None and not is_valid_timezone(tz):
        raise HTTPException(status_code=400, detail=f"unknown IANA timezone: {tz!r}")

    ledger = _get_ledger()
    workspace = None
    member = None
    if hasattr(ledger, "resolve_caller_workspace"):
        workspace = ledger.resolve_caller_workspace(tenant_id)
    if hasattr(ledger, "resolve_caller_member"):
        member = ledger.resolve_caller_member(tenant_id)

    effective_tz = tz or resolve_timezone(member=member, workspace=workspace)
    member_id = getattr(member, "member_id", None) if member is not None else None

    if hasattr(ledger, "list_timeblocks"):
        try:
            blocks: list[TimeBlock] = list(ledger.list_timeblocks(tenant_id, limit=500))
        except TypeError:
            blocks = list(ledger.list_timeblocks(tenant_id))[:500]
    else:
        blocks = list(ledger.list_blocks(tenant_id, limit=500))

    return TimeBlockListResponse(
        timezone=effective_tz,
        blocks=[
            _envelope(b, effective_tz, user_role=user_role, member_id=member_id)
            for b in blocks
        ],
    )
