"""Cadence API endpoints."""

from __future__ import annotations

import logging
from typing import Any

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/api/v1/cadence", tags=["cadence"])


def _get_service():
    from apps.backend.services.scheduling.cadence_service import get_cadence_service

    return get_cadence_service()


class CadenceStepRequest(BaseModel):
    step_id: str | None = Field(None, description="Stable step identifier")
    skill_id: str = Field(..., description="Skill to execute for this step")
    input_data: dict[str, Any] = Field(default_factory=dict, description="Skill input payload")
    branches: dict[str, Any] | None = Field(
        None,
        description=(
            "Optional conditional branches keyed by signal type. "
            'E.g. {"reply": {"goto_step": "call_followup"}, "bounce": {"goto_step": null}}'
        ),
    )


class CadenceLeadRequest(BaseModel):
    lead_id: str = Field(..., description="Lead identifier")
    attributes: dict[str, Any] = Field(default_factory=dict, description="Lead attributes available to steps")


class CreateCampaignRequest(BaseModel):
    campaign_id: str = Field(..., description="Campaign identifier")
    name: str = Field(..., description="Campaign display name")
    steps: list[CadenceStepRequest] = Field(..., min_length=1)
    leads: list[CadenceLeadRequest] = Field(..., min_length=1)


class RunCampaignRequest(BaseModel):
    lead_id: str | None = Field(None, description="Optional lead target for single-lead progression")
    limit: int = Field(100, ge=1, le=500, description="Max leads to process for campaign tick")


class LeadSignalRequest(BaseModel):
    signal_type: str = Field(..., description="One of: reply, bounce, unsubscribe")


class CampaignAuditEvent(BaseModel):
    campaign_id: str
    lead_id: str
    event_type: str
    from_status: str
    to_status: str
    step_id: str
    metadata: dict[str, Any] = Field(default_factory=dict)
    created_at: str


class CampaignAuditResponse(BaseModel):
    campaign_id: str
    tenant_id: str
    total: int
    events: list[CampaignAuditEvent]


def _http_error_from_value_error(exc: ValueError) -> HTTPException:
    detail = str(exc)
    if "not found" in detail.lower():
        return HTTPException(status_code=404, detail=detail)
    return HTTPException(status_code=400, detail=detail)


@router.post("/campaigns", status_code=201)
async def create_campaign(
    request: CreateCampaignRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    service = _get_service()
    try:
        return await service.create_campaign(
            tenant_id=tenant_id,
            campaign_id=request.campaign_id,
            name=request.name,
            steps=[step.model_dump() for step in request.steps],
            leads=[lead.model_dump() for lead in request.leads],
            created_by="api",
        )
    except ValueError as exc:
        raise _http_error_from_value_error(exc)
    except Exception:
        logger.exception("cadence.create_campaign_failed")
        raise HTTPException(status_code=500, detail="Failed to create campaign")


@router.get("/campaigns/{campaign_id}")
async def get_campaign(
    campaign_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    service = _get_service()
    try:
        campaign = await service.get_campaign(tenant_id=tenant_id, campaign_id=campaign_id, include_leads=True)
        if campaign is None:
            raise HTTPException(status_code=404, detail=f"campaign not found: {campaign_id}")
        return campaign
    except HTTPException:
        raise
    except Exception:
        logger.exception("cadence.get_campaign_failed")
        raise HTTPException(status_code=500, detail="Failed to fetch campaign")


@router.get("/campaigns/{campaign_id}/audit", response_model=CampaignAuditResponse)
async def get_campaign_audit(
    campaign_id: str,
    limit: int = 100,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> CampaignAuditResponse:
    service = _get_service()
    try:
        events = await service.list_campaign_transitions(
            tenant_id=tenant_id,
            campaign_id=campaign_id,
            limit=limit,
        )
        normalized = [
            CampaignAuditEvent(
                campaign_id=str(event.get("campaign_id") or campaign_id),
                lead_id=str(event.get("lead_id") or ""),
                event_type=str(event.get("event_type") or ""),
                from_status=str(event.get("from_status") or ""),
                to_status=str(event.get("to_status") or ""),
                step_id=str(event.get("step_id") or ""),
                metadata=event.get("metadata") if isinstance(event.get("metadata"), dict) else {},
                created_at=str(event.get("created_at") or ""),
            )
            for event in events
        ]
        return CampaignAuditResponse(
            campaign_id=campaign_id,
            tenant_id=tenant_id,
            total=len(normalized),
            events=normalized,
        )
    except ValueError as exc:
        raise _http_error_from_value_error(exc)
    except Exception:
        logger.exception("cadence.get_campaign_audit_failed")
        raise HTTPException(status_code=500, detail="Failed to fetch campaign audit")


@router.post("/campaigns/{campaign_id}/run")
async def run_campaign(
    campaign_id: str,
    request: RunCampaignRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    service = _get_service()
    try:
        if request.lead_id:
            return await service.process_lead(
                tenant_id=tenant_id,
                campaign_id=campaign_id,
                lead_id=request.lead_id,
                allow_retry=False,
                initiated_by="api_run",
            )
        return await service.run_campaign_tick(
            tenant_id=tenant_id,
            campaign_id=campaign_id,
            limit=request.limit,
            initiated_by="api_run",
        )
    except ValueError as exc:
        raise _http_error_from_value_error(exc)
    except Exception:
        logger.exception("cadence.run_campaign_failed")
        raise HTTPException(status_code=500, detail="Failed to run campaign")


@router.post("/campaigns/{campaign_id}/pause")
async def pause_campaign(
    campaign_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    service = _get_service()
    try:
        return await service.pause_campaign(tenant_id=tenant_id, campaign_id=campaign_id, actor="api")
    except ValueError as exc:
        raise _http_error_from_value_error(exc)
    except Exception:
        logger.exception("cadence.pause_campaign_failed")
        raise HTTPException(status_code=500, detail="Failed to pause campaign")


@router.post("/campaigns/{campaign_id}/resume")
async def resume_campaign(
    campaign_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    service = _get_service()
    try:
        return await service.resume_campaign(tenant_id=tenant_id, campaign_id=campaign_id, actor="api")
    except ValueError as exc:
        raise _http_error_from_value_error(exc)
    except Exception:
        logger.exception("cadence.resume_campaign_failed")
        raise HTTPException(status_code=500, detail="Failed to resume campaign")


@router.post("/campaigns/{campaign_id}/stop")
async def stop_campaign(
    campaign_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    service = _get_service()
    try:
        return await service.stop_campaign(tenant_id=tenant_id, campaign_id=campaign_id, actor="api")
    except ValueError as exc:
        raise _http_error_from_value_error(exc)
    except Exception:
        logger.exception("cadence.stop_campaign_failed")
        raise HTTPException(status_code=500, detail="Failed to stop campaign")


@router.post("/campaigns/{campaign_id}/leads/{lead_id}/skip")
async def skip_lead_step(
    campaign_id: str,
    lead_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    service = _get_service()
    try:
        return await service.skip_lead_step(
            tenant_id=tenant_id,
            campaign_id=campaign_id,
            lead_id=lead_id,
            actor="api",
        )
    except ValueError as exc:
        raise _http_error_from_value_error(exc)
    except Exception:
        logger.exception("cadence.skip_lead_step_failed")
        raise HTTPException(status_code=500, detail="Failed to skip lead step")


@router.post("/campaigns/{campaign_id}/leads/{lead_id}/retry")
async def retry_lead_step(
    campaign_id: str,
    lead_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    service = _get_service()
    try:
        return await service.retry_lead_step(
            tenant_id=tenant_id,
            campaign_id=campaign_id,
            lead_id=lead_id,
            actor="api",
        )
    except ValueError as exc:
        raise _http_error_from_value_error(exc)
    except Exception:
        logger.exception("cadence.retry_lead_step_failed")
        raise HTTPException(status_code=500, detail="Failed to retry lead step")


@router.post("/campaigns/{campaign_id}/leads/{lead_id}/signals")
async def lead_signal(
    campaign_id: str,
    lead_id: str,
    request: LeadSignalRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> dict[str, Any]:
    service = _get_service()
    try:
        return await service.record_lead_signal(
            tenant_id=tenant_id,
            campaign_id=campaign_id,
            lead_id=lead_id,
            signal_type=request.signal_type,
            actor="api",
        )
    except ValueError as exc:
        raise _http_error_from_value_error(exc)
    except Exception:
        logger.exception("cadence.lead_signal_failed")
        raise HTTPException(status_code=500, detail="Failed to register lead signal")
