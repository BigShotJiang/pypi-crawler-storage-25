"""Admin inference API — platform-level provider and model configuration.

Endpoints (all require founder auth):
  GET  /api/v1/founder/inference/providers
  POST /api/v1/founder/inference/providers/{provider_id}
  POST /api/v1/founder/inference/providers/{provider_id}/rotate-credentials
  POST /api/v1/founder/inference/providers/{provider_id}/disable
  POST /api/v1/founder/inference/providers/{provider_id}/retire
  DELETE /api/v1/founder/inference/providers/{provider_id}
  POST /api/v1/founder/inference/providers/{provider_id}/smoke-test
  GET  /api/v1/founder/inference/models
  GET  /api/v1/founder/inference/audit
  GET  /api/v1/founder/inference/audit/performance
  GET  /api/v1/founder/inference/defaults
  POST /api/v1/founder/inference/defaults
  GET  /api/v1/founder/inference/usage/resources
  GET  /api/v1/founder/inference/tenants/{tenant_id}/routing-override
  POST /api/v1/founder/inference/tenants/{tenant_id}/routing-override
  DELETE /api/v1/founder/inference/tenants/{tenant_id}/routing-override
  GET  /api/v1/founder/inference/tenants/{tenant_id}/effective-config
  GET  /api/v1/founder/inference/tenants/{tenant_id}/resources

All mutations invalidate the cached resolver so the next tenant catalog request
picks up the new config within the TTL window.

Capability eval/canary visibility:
  GET  /api/v1/founder/inference/capability-evals/{capability_class}/last-known-good
  GET  /api/v1/founder/inference/capability-evals/{capability_class}/artifacts
  POST /api/v1/founder/inference/capability-evals/{capability_class}/evaluate
"""

from __future__ import annotations

import logging
from http import HTTPStatus
from typing import Any

import re

from fastapi import APIRouter, Depends, HTTPException, Query, status
from pydantic import BaseModel, Field, field_validator, model_validator

from apps.backend.api.founder_admin import get_billing_read_models
from apps.backend.api.dependencies.admin_permissions import require_admin_permission_dep
from apps.backend.schemas.error_response import safe_error_detail
from apps.backend.services.admin.admin_permission import (
    AdminPermission,
    AdminPermissionCheck,
)
from apps.backend.services.inference.admin_store import (
    AdminInferenceStore,
    AdminInferenceStoreError,
    ProviderNotFoundError,
    get_admin_inference_store,
)
from apps.backend.services.inference.admin_resolver import (
    AdminInferenceResolver,
    SUPPORTED_CAPABILITY_CLASSES,
    get_cached_resolver,
)
from apps.backend.services.admin_inference_probe import run_platform_provider_smoke_test
from apps.backend.services.inference.capabilities import all_capabilities
from apps.backend.services.inference.service import SUPPORTED_PROVIDER_IDS
from apps.shared.llm_model_policy import normalize_capability_class
from apps.backend.services.capability_eval_canary import (
    CapabilityEvalCanaryService,
    supported_capability_classes,
)
from apps.backend.services.variant_store import VariantStore, get_variant_store
from apps.backend.services.billing.read_models import BillingReadModelService
from apps.backend.services.inference.phantom_model_guard import PhantomModelGuard, get_phantom_model_guard
from apps.backend.services.inference.dry_run_resolver import DryRunResolver

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/founder/inference", tags=["founder-admin-inference"])
_CAPABILITY_EVAL_TENANT_ID = "PLATFORM"


# ============================================================================
# Dependency helpers
# ============================================================================


def _get_store() -> AdminInferenceStore:
    return get_admin_inference_store()


def _get_resolver() -> AdminInferenceResolver:
    return AdminInferenceResolver()


def _get_variant_store() -> VariantStore:
    return get_variant_store()


def _get_billing_read_model_service() -> BillingReadModelService:
    return get_billing_read_models()


def _get_phantom_model_guard() -> PhantomModelGuard:
    return get_phantom_model_guard()


def _get_audit_log():
    from apps.backend.services.inference.inference_audit import get_inference_audit_log
    return get_inference_audit_log()


def _append_audit(
    store: AdminInferenceStore,
    *,
    actor: str,
    action: str,
    target: str,
    details: dict[str, Any] | None = None,
) -> None:
    try:
        store.append_audit_event(
            actor=actor,
            action=action,
            target=target,
            details=details,
        )
    except Exception as exc:
        logger.warning(
            "admin_inference.audit_append_failed actor=%s action=%s target=%s error=%s",
            actor,
            action,
            target,
            exc,
        )


# ============================================================================
# Request / Response models
# ============================================================================


# Pattern for safe provider IDs and model IDs (alphanumeric, dash, dot, underscore, slash).
_SAFE_ID_RE = re.compile(r"^[a-zA-Z0-9\-_./@]{1,120}$")
_SAFE_TENANT_ID_RE = re.compile(r"^[a-zA-Z0-9\-_./@#]{1,200}$")


def _validate_safe_id(v: str, field_name: str) -> str:
    v = v.strip()
    if not v:
        raise ValueError(f"{field_name} must not be empty")
    if not _SAFE_ID_RE.match(v):
        raise ValueError(
            f"{field_name} contains invalid characters or exceeds 120 chars. "
            "Only alphanumeric, dash, dot, underscore, slash, and @ are allowed."
        )
    return v


def _validate_safe_tenant_id(v: str) -> str:
    v = v.strip()
    if not v:
        raise ValueError("tenant_id must not be empty")
    if not _SAFE_TENANT_ID_RE.match(v):
        raise ValueError(
            "tenant_id contains invalid characters or exceeds 200 chars. "
            "Only alphanumeric, dash, dot, underscore, slash, @, and # are allowed."
        )
    return v


class UpsertProviderRequest(BaseModel):
    label: str = Field(..., max_length=200, description="Human-readable provider name")
    enabled: bool = Field(True, description="Whether tenants may use this provider")
    base_url: str | None = Field(
        None,
        max_length=2048,
        description="Custom base URL override (e.g. Azure endpoint)",
    )
    credentials: dict[str, Any] | None = Field(
        None,
        description=(
            "Encrypted and stored via vault.  Omit to leave existing credentials unchanged. "
            "For OpenAI-compatible providers: {api_key}.  "
            "For Bedrock: leave None — uses IAM role.  "
            "For Anthropic: {api_key}."
        ),
    )
    models_allowlist: list[str] | None = Field(
        None,
        description=(
            "Model allowlist. Bare ids allow whole model families; exact "
            "model@reasoning specs preserve reasoning-budget governance. "
            "Empty list or null = all models permitted."
        ),
    )

    @field_validator("label")
    @classmethod
    def _validate_label(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("label must not be empty or whitespace")
        return v.strip()

    @field_validator("base_url")
    @classmethod
    def _validate_base_url(cls, v: str | None) -> str | None:
        if v is None:
            return None
        v = v.strip()
        if not v:
            return None
        # Require HTTPS for platform providers — they carry credentials.
        # http:// is accepted only for localhost/127.0.0.1 (local dev).
        if not v.startswith("https://"):
            if v.startswith("http://") and (
                v.startswith("http://localhost") or v.startswith("http://127.0.0.1")
            ):
                return v  # local-dev loopback exception
            raise ValueError(
                "base_url must use https:// for platform provider configs. "
                "http:// is only permitted for localhost/127.0.0.1 in local dev."
            )
        return v

    @field_validator("models_allowlist")
    @classmethod
    def _validate_models_allowlist(cls, v: list[str] | None) -> list[str] | None:
        if v is None:
            return None
        validated: list[str] = []
        for entry in v:
            entry = entry.strip()
            if entry:
                _validate_safe_id(entry, "models_allowlist entry")
                validated.append(entry)
        return validated


class PlatformDefaultsRequest(BaseModel):
    default_provider: str = Field(..., max_length=120)
    default_model: str = Field(..., max_length=120)

    @field_validator("default_provider", "default_model")
    @classmethod
    def _validate_ids(cls, v: str) -> str:
        return _validate_safe_id(v, "default_provider/model")


class ProviderSummary(BaseModel):
    provider_id: str
    label: str
    enabled: bool
    lifecycle_state: str = "active"
    base_url: str | None = None
    has_credentials: bool
    credential_last_rotated_at: str = ""
    models_allowlist: list[str]
    retired_at: str = ""
    deleted_at: str = ""
    updated_at: str
    family: str = ""
    runtime: dict[str, Any] = Field(default_factory=dict)
    capabilities: dict[str, Any] = Field(default_factory=dict)
    transport_capabilities: dict[str, Any] = Field(default_factory=dict)
    metering: dict[str, Any] = Field(default_factory=dict)
    catalog_models: list[dict[str, Any]] = Field(default_factory=list)
    pricing: dict[str, Any] = Field(default_factory=dict)
    health: dict[str, Any] = Field(default_factory=dict)


class PlatformDefaultsResponse(BaseModel):
    default_provider: str
    default_model: str


class RotateProviderCredentialsRequest(BaseModel):
    credentials: dict[str, Any] = Field(..., description="Replacement provider credential payload.")


class RetryPolicyRequest(BaseModel):
    """Routing retry policy (issue #3512).

    All keys are optional — missing fields fall back to the documented
    defaults from :mod:`apps.backend.services.inference.fallback_chain`.
    """

    on_429: str | None = None
    on_5xx: str | None = None
    on_timeout: str | None = None
    on_auth_failure: str | None = None
    on_policy_denial: str | None = None
    on_jurisdiction_violation: str | None = None
    on_model_not_allowed: str | None = None
    max_attempts: dict[str, int] = Field(default_factory=dict)
    backoff_seconds: list[float] = Field(default_factory=list)
    override_model_not_allowed_to_advance: bool = False

    @field_validator(
        "on_429",
        "on_5xx",
        "on_timeout",
        "on_auth_failure",
        "on_policy_denial",
        "on_jurisdiction_violation",
        "on_model_not_allowed",
    )
    @classmethod
    def _validate_action(cls, value: str | None) -> str | None:
        if value is None:
            return None
        normalized = str(value).strip().lower()
        if normalized not in {"advance_chain", "retry", "stop"}:
            raise ValueError(
                f"retry policy action must be one of advance_chain|retry|stop (got {value!r})"
            )
        return normalized

    def as_storage_dict(self) -> dict[str, Any]:
        payload: dict[str, Any] = {}
        for field_name in (
            "on_429",
            "on_5xx",
            "on_timeout",
            "on_auth_failure",
            "on_policy_denial",
            "on_jurisdiction_violation",
            "on_model_not_allowed",
        ):
            value = getattr(self, field_name)
            if value is not None:
                payload[field_name] = value
        if self.max_attempts:
            payload["max_attempts"] = {str(k): int(v) for k, v in self.max_attempts.items()}
        if self.backoff_seconds:
            payload["backoff_seconds"] = [float(v) for v in self.backoff_seconds]
        if self.override_model_not_allowed_to_advance:
            payload["override_model_not_allowed_to_advance"] = True
        return payload


class RoutingProfileRequest(BaseModel):
    provider_order: list[str] = Field(default_factory=list)
    provider_models: dict[str, str] = Field(default_factory=dict)
    primary: str | None = Field(
        default=None,
        description="Primary provider_instance_id (issue #3512). When omitted, provider_order[0] is used.",
    )
    fallback_chain: list[str] = Field(
        default_factory=list,
        description="Ordered fallback chain of provider_instance_ids (issue #3512).",
    )
    retry_policy: RetryPolicyRequest | None = Field(
        default=None,
        description="Per-failure-class retry policy (issue #3512).",
    )

    @field_validator("provider_order")
    @classmethod
    def _validate_provider_order(cls, value: list[str]) -> list[str]:
        normalized: list[str] = []
        for provider_id in value:
            normalized.append(_validate_safe_id(provider_id, "routing provider"))
        return normalized

    @field_validator("fallback_chain")
    @classmethod
    def _validate_fallback_chain(cls, value: list[str]) -> list[str]:
        normalized: list[str] = []
        for provider_id in value:
            normalized.append(_validate_safe_id(provider_id, "fallback_chain provider"))
        return normalized

    @field_validator("primary")
    @classmethod
    def _validate_primary(cls, value: str | None) -> str | None:
        if value is None or value == "":
            return None
        return _validate_safe_id(value, "primary provider")

    @field_validator("provider_models")
    @classmethod
    def _validate_provider_models(cls, value: dict[str, str]) -> dict[str, str]:
        normalized: dict[str, str] = {}
        for provider_id, model_spec in value.items():
            normalized[_validate_safe_id(provider_id, "routing provider")] = _validate_safe_id(
                model_spec,
                "routing model",
            )
        return normalized

    @model_validator(mode="after")
    def _ensure_chain_present(self) -> "RoutingProfileRequest":
        if not self.provider_order and not self.primary and not self.fallback_chain:
            raise ValueError(
                "routing profile must specify provider_order or primary+fallback_chain"
            )
        return self

    def effective_primary(self) -> str:
        if self.primary:
            return self.primary
        if self.provider_order:
            return self.provider_order[0]
        if self.fallback_chain:
            return self.fallback_chain[0]
        raise ValueError("routing profile has no provider entries")

    def effective_fallback_chain(self) -> list[str]:
        primary = self.effective_primary()
        chain: list[str] = []
        # Prefer explicit fallback_chain when provided.
        if self.fallback_chain:
            for entry in self.fallback_chain:
                if entry and entry != primary and entry not in chain:
                    chain.append(entry)
            return chain
        # Otherwise derive from provider_order[1:].
        for entry in self.provider_order[1:]:
            if entry and entry != primary and entry not in chain:
                chain.append(entry)
        return chain


class PlatformRoutingRequest(BaseModel):
    capability_classes: dict[str, RoutingProfileRequest] = Field(default_factory=dict)
    intents: dict[str, RoutingProfileRequest] = Field(default_factory=dict)

    @model_validator(mode="after")
    def _validate_presence(self) -> "PlatformRoutingRequest":
        if not self.capability_classes and not self.intents:
            raise ValueError("capability_classes must contain at least one routing profile")
        return self

    def routing_entries(self) -> dict[str, RoutingProfileRequest]:
        return self.capability_classes or self.intents


class PlatformRoutingResponse(BaseModel):
    source: str
    updated_at: str
    capability_classes: dict[str, dict[str, Any]]


class TenantRoutingOverrideResponse(BaseModel):
    tenant_id: str
    source: str
    updated_at: str
    capability_classes: dict[str, dict[str, Any]] = Field(default_factory=dict)


class ResourceMeasurementResponse(BaseModel):
    metric: str
    label: str
    unit: str
    quantity: int | float


class ResourceContractResponse(BaseModel):
    resource: str
    label: str
    summary: str
    billing_meters: list[str] = Field(default_factory=list)
    aggregate_label: str
    aggregate_unit: str
    totals: dict[str, int | float] = Field(default_factory=dict)
    measurements: list[ResourceMeasurementResponse] = Field(default_factory=list)


class ResourceTenantRollupResponse(BaseModel):
    tenant_id: str
    input_tokens: int | float = 0
    output_tokens: int | float = 0
    tokens_total: int | float = 0
    compute_hours: int | float = 0
    memory_reads: int | float = 0
    memory_writes: int | float = 0
    memory_operations: int | float = 0
    storage_gb: int | float = 0
    bandwidth_gb: int | float = 0


class FounderResourceUsageOverviewResponse(BaseModel):
    year: int
    month: str
    contract_version: str
    tenant_count_with_resources: int
    resources: list[ResourceContractResponse] = Field(default_factory=list)
    by_tenant: list[ResourceTenantRollupResponse] = Field(default_factory=list)


class TenantResourceUsageResponse(BaseModel):
    tenant_id: str
    year: int
    month: str
    contract_version: str
    resources: list[ResourceContractResponse] = Field(default_factory=list)


class BlockedProviderEntry(BaseModel):
    provider_id: str
    reason: str


class SetBlockedProvidersRequest(BaseModel):
    providers: dict[str, str] = Field(
        ...,
        description="Map of provider_id → reason for blocking.",
    )


class AddBlockedProviderRequest(BaseModel):
    provider_id: str = Field(..., min_length=1, max_length=120)
    reason: str = Field(..., min_length=1, max_length=500)


class JurisdictionPolicyResponse(BaseModel):
    blocked_providers: list[BlockedProviderEntry] = Field(default_factory=list)
    default_block_reason: str = "Provider is blocked by jurisdiction/provenance policy."


@router.get("/blocked-providers", response_model=list[BlockedProviderEntry])
async def list_blocked_providers(
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    store: AdminInferenceStore = Depends(_get_store),
) -> list[dict[str, str]]:
    """Return the current list of blocked providers with reasons."""
    blocked = store.get_blocked_providers()
    return [
        {"provider_id": pid, "reason": store.get_blocked_provider_reason(pid) or ""}
        for pid in sorted(blocked)
    ]


@router.get("/jurisdiction-policy", response_model=JurisdictionPolicyResponse)
async def get_jurisdiction_policy(
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    store: AdminInferenceStore = Depends(_get_store),
) -> dict[str, Any]:
    blocked = store.get_blocked_providers()
    return {
        "blocked_providers": [
            {"provider_id": pid, "reason": store.get_blocked_provider_reason(pid) or ""}
            for pid in sorted(blocked)
        ],
        "default_block_reason": "Provider is blocked by jurisdiction/provenance policy.",
    }


@router.put("/blocked-providers")
async def set_blocked_providers(
    body: SetBlockedProvidersRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
) -> dict[str, Any]:
    """Replace the entire blocked-providers blocklist."""
    new_set = store.set_blocked_providers(body.providers)
    get_cached_resolver().invalidate()
    _append_audit(
        store,
        actor=_perm.actor_id,
        action="blocked_providers.set",
        target="platform",
        details={"providers": body.providers},
    )
    return {"blocked_providers": sorted(new_set)}


@router.put("/jurisdiction-policy", response_model=JurisdictionPolicyResponse)
async def set_jurisdiction_policy(
    body: SetBlockedProvidersRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
) -> dict[str, Any]:
    new_set = store.set_blocked_providers(body.providers)
    get_cached_resolver().invalidate()
    _append_audit(store, actor=_perm.actor_id, action="jurisdiction_policy.set", target="platform", details={"providers": body.providers})
    return {
        "blocked_providers": [
            {"provider_id": pid, "reason": store.get_blocked_provider_reason(pid) or body.providers.get(pid, "")}
            for pid in sorted(new_set)
        ],
        "default_block_reason": "Provider is blocked by jurisdiction/provenance policy.",
    }


@router.post("/blocked-providers")
async def add_blocked_provider(
    body: AddBlockedProviderRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
) -> dict[str, Any]:
    """Add a single provider to the blocklist."""
    new_set = store.add_blocked_provider(body.provider_id, body.reason)
    get_cached_resolver().invalidate()
    _append_audit(
        store,
        actor=_perm.actor_id,
        action="blocked_providers.add",
        target=body.provider_id,
        details={"reason": body.reason},
    )
    return {"blocked_providers": sorted(new_set)}


@router.delete("/blocked-providers/{provider_id}")
async def remove_blocked_provider(
    provider_id: str,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
) -> dict[str, Any]:
    """Remove a single provider from the blocklist."""
    try:
        _validate_safe_id(provider_id, "provider_id")
    except ValueError as exc:
        raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail=str(exc))
    new_set = store.remove_blocked_provider(provider_id)
    get_cached_resolver().invalidate()
    _append_audit(
        store,
        actor=_perm.actor_id,
        action="blocked_providers.remove",
        target=provider_id,
        details={},
    )
    return {"blocked_providers": sorted(new_set)}


class CapabilityEvalMetrics(BaseModel):
    """Loose metrics payload for capability eval/canary comparisons."""

    latency_p50_ms: float | None = None
    latency_p95_ms: float | None = None
    latency_ms: float | None = None
    accuracy: float | None = None
    quality_score: float | None = None
    avg_tokens_per_task: float | None = None
    token_cost: float | None = None
    sample_size: int | None = None
    window_days: int | None = None


class CapabilityEvalJudgeVote(BaseModel):
    judge_id: str = Field(..., min_length=1)
    vote: str = Field(..., min_length=1)
    rationale: str = ""


class CapabilityEvalRequest(BaseModel):
    variant_id: str = Field(..., min_length=1)
    baseline_metrics: CapabilityEvalMetrics
    candidate_metrics: CapabilityEvalMetrics
    material_change: str | None = None
    context_slice: str | None = None
    trace_envelope_id: str | None = None
    candidate_order: list[str] = Field(default_factory=list)
    judge_votes: list[CapabilityEvalJudgeVote] = Field(default_factory=list)
    boundary_conditions: dict[str, Any] = Field(default_factory=dict)


class CapabilityEvalRunResponse(BaseModel):
    capability_class: str
    tenant_id: str
    variant_id: str
    run_id: str
    passed: bool
    verdict: str
    promotion_state: str
    last_known_good_variant_id: str | None = None
    gate_summary: str
    judge_votes: list[dict[str, Any]]
    candidate_order: list[str]
    thresholds: dict[str, Any]
    experiment_run: dict[str, Any]
    variant: dict[str, Any]


class CapabilityEvalArtifactsResponse(BaseModel):
    capability_class: str
    last_known_good: dict[str, Any] | None = None
    variants: list[dict[str, Any]] = Field(default_factory=list)
    runs: list[dict[str, Any]] = Field(default_factory=list)


class ProviderSmokeTestResponse(BaseModel):
    provider_id: str
    status: str
    model: str
    checked_at: str
    latency_ms: int | None = None
    error: str | None = None
    usage: dict[str, Any] = Field(default_factory=dict)
    freshness_state: str = ""
    alert_open: bool = False
    warning_code: str = ""
    warning_summary: str = ""
    consecutive_failures: int = 0
    last_healthy_at: str = ""
    baseline_latency_ms: int | None = None


class AuditEventResponse(BaseModel):
    actor: str
    action: str
    target: str
    details: dict[str, Any] = Field(default_factory=dict)
    created_at: str


class ProviderCapabilityResponse(BaseModel):
    """Machine-readable capability entry for one provider (Issue #1200)."""

    provider_id: str
    transport_family: str
    supports_tools: bool
    supports_parallel_tools: bool
    supports_streaming: bool
    supports_multimodal_input: bool
    supports_structured_output: bool
    supports_reasoning_effort: bool
    supports_reasoning_budget: bool
    usage_contract: str
    metering_fidelity: str
    availability_restriction: str = ""
    notes: str = ""


class InferenceActivityRecordResponse(BaseModel):
    inference_audit_id: str
    tenant_id: str
    source: str
    provider: str
    model: str
    requested_model_spec: str = ""
    reasoning_profile: str = ""
    reasoning_tokens: int = 0
    capability_class: str = ""
    pricing_source: str = ""
    pricing_provider: str = ""
    pricing_model: str = ""
    latest_event_at: str
    prompt_tokens: int = 0
    completion_tokens: int = 0
    total_tokens: int = 0
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    input_uncached_tokens: int = 0
    cache_read_cogs_usd: str = "0.0000"
    cache_write_cogs_usd: str = "0.0000"
    input_uncached_cogs_usd: str = "0.0000"
    cache_pricing_source: str = ""
    cache_pricing_provider: str = ""
    cache_pricing_model: str = ""
    total_cogs_usd: str = "0.0000"


class InferenceProviderModelSpendResponse(BaseModel):
    provider: str
    model: str
    invocation_count: int
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    input_uncached_tokens: int = 0
    cache_read_cogs_usd: str = "0.0000"
    cache_write_cogs_usd: str = "0.0000"
    input_uncached_cogs_usd: str = "0.0000"
    cache_pricing_source: str = ""
    cache_pricing_provider: str = ""
    cache_pricing_model: str = ""
    total_cogs_usd: str


class InferenceTenantSpendResponse(BaseModel):
    tenant_id: str
    invocation_count: int
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    cache_read_tokens: int = 0
    cache_write_tokens: int = 0
    input_uncached_tokens: int = 0
    cache_read_cogs_usd: str = "0.0000"
    cache_write_cogs_usd: str = "0.0000"
    input_uncached_cogs_usd: str = "0.0000"
    cache_pricing_source: str = ""
    cache_pricing_provider: str = ""
    cache_pricing_model: str = ""
    total_cogs_usd: str


class FounderInferenceUsageOverviewResponse(BaseModel):
    year: int
    month: str
    invocation_count: int
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    total_cogs_usd: str
    tenant_count_with_inference: int
    by_tenant: list[InferenceTenantSpendResponse] = Field(default_factory=list)
    by_provider_model: list[InferenceProviderModelSpendResponse] = Field(default_factory=list)
    recent_activity: list[InferenceActivityRecordResponse] = Field(default_factory=list)


class TenantInferenceUsageResponse(BaseModel):
    tenant_id: str
    year: int
    month: str
    invocation_count: int
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int
    total_cogs_usd: str
    by_provider_model: list[InferenceProviderModelSpendResponse] = Field(default_factory=list)
    recent_activity: list[InferenceActivityRecordResponse] = Field(default_factory=list)


# ============================================================================
# Routing normalization helper
# ============================================================================


def _normalize_routing_payload(
    *,
    body: PlatformRoutingRequest,
    resolver: AdminInferenceResolver,
    store: AdminInferenceStore,
) -> dict[str, dict[str, Any]]:
    configured_providers = {row["provider_id"]: row for row in resolver.get_platform_providers()}
    normalized_capability_classes: dict[str, dict[str, Any]] = {}

    for raw_capability_class, profile in body.routing_entries().items():
        raw_capability_class_value = str(raw_capability_class or "").strip()
        if not raw_capability_class_value:
            raise HTTPException(
                status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
                detail="Routing capability-class keys must not be empty.",
            )
        normalized_capability_class = normalize_capability_class(raw_capability_class)
        if not normalized_capability_class:
            raise HTTPException(
                status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
                detail=(
                    f"Routing capability class {raw_capability_class!r} is not supported. "
                    f"Supported capability classes: {', '.join(SUPPORTED_CAPABILITY_CLASSES)}."
                ),
            )

        # Normalize the v2 surface (primary + fallback_chain) and project it
        # back onto provider_order so legacy consumers (admin_resolver, the
        # founder UI v1 path) keep working without code changes.
        primary_provider_id = profile.effective_primary()
        fallback_chain = profile.effective_fallback_chain()
        provider_order_union: list[str] = []
        for provider_id in [primary_provider_id, *fallback_chain]:
            if provider_id and provider_id not in provider_order_union:
                provider_order_union.append(provider_id)
        # Honor the explicit provider_order if a caller passed one without
        # primary/fallback_chain — don't drop entries when the v1 path is used.
        for provider_id in profile.provider_order:
            if provider_id and provider_id not in provider_order_union:
                provider_order_union.append(provider_id)
        provider_order = provider_order_union
        if not provider_order:
            raise HTTPException(
                status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
                detail="provider_order must contain at least one provider",
            )
        provider_models = {
            provider_id: model_spec
            for provider_id, model_spec in profile.provider_models.items()
            if provider_id in provider_order
        }

        for provider_id in provider_order:
            provider_row = configured_providers.get(provider_id)
            if provider_row is None and provider_id not in SUPPORTED_PROVIDER_IDS:
                raise HTTPException(
                    status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
                    detail=f"Provider {provider_id!r} is not supported by the runtime inference catalog.",
                )
            if provider_row is None:
                raise HTTPException(
                    status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
                    detail=f"Provider {provider_id!r} is not configured in the platform provider catalog.",
                )
            if provider_row is not None and not provider_row.get("enabled", False):
                raise HTTPException(
                    status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
                    detail=f"Provider {provider_id!r} is disabled and cannot be used in routing policy.",
                )
            model_spec = provider_models.get(provider_id)
            if model_spec and not store.is_model_allowed(provider_id, model_spec):
                raise HTTPException(
                    status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
                    detail=f"Model {model_spec!r} is not allowed for provider {provider_id!r}.",
                )

        retry_policy_payload: dict[str, Any] = (
            profile.retry_policy.as_storage_dict() if profile.retry_policy is not None else {}
        )
        normalized_capability_classes[normalized_capability_class] = {
            "provider_order": provider_order,
            "primary": primary_provider_id,
            "fallback_chain": fallback_chain,
            "provider_models": provider_models,
            "retry_policy": retry_policy_payload,
        }

    return normalized_capability_classes


# ============================================================================
# Endpoints
# ============================================================================


@router.get("/providers", response_model=list[ProviderSummary])
async def list_providers(
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    resolver: AdminInferenceResolver = Depends(_get_resolver),
) -> list[dict[str, Any]]:
    """List all platform inference providers with catalog metadata."""
    return resolver.get_platform_providers()


@router.post("/providers/{provider_id}", response_model=ProviderSummary)
async def upsert_provider(
    provider_id: str,
    body: UpsertProviderRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
) -> dict[str, Any]:
    """Create or update a platform inference provider.

    Posting credentials replaces the existing vault entry.  Omitting credentials
    leaves the existing vault entry untouched.
    """
    # Validate path param before it reaches the store.
    try:
        _validate_safe_id(provider_id, "provider_id")
    except ValueError as exc:
        raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail=str(exc))

    try:
        result = store.upsert_provider(
            provider_id=provider_id,
            label=body.label,
            enabled=body.enabled,
            base_url=body.base_url,
            credentials=body.credentials,
            models_allowlist=body.models_allowlist,
        )
    except AdminInferenceStoreError as exc:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=safe_error_detail(exc))

    get_cached_resolver().invalidate()
    logger.info("admin_inference.upsert_provider provider=%s founder=%s", provider_id, _perm.actor_id)
    _append_audit(
        store,
        actor=_perm.actor_id,
        action="provider.upsert",
        target=provider_id,
        details={
            "enabled": body.enabled,
            "base_url": body.base_url or "",
            "models_allowlist": list(body.models_allowlist or []),
            "credentials_updated": body.credentials is not None,
        },
    )
    # Scrub vault ref before returning — pop once, derive has_credentials from it.
    vault_ref = result.pop("credential_vault_ref", None)
    result["has_credentials"] = bool(vault_ref is not None or body.credentials is not None)
    enriched = next(
        (
            row
            for row in AdminInferenceResolver(store=store).get_platform_providers()
            if row.get("provider_id") == provider_id
        ),
        None,
    )
    if enriched:
        enriched["has_credentials"] = result["has_credentials"]
        return enriched
    return result


@router.post("/providers/{provider_id}/rotate-credentials", response_model=ProviderSummary)
async def rotate_provider_credentials(
    provider_id: str,
    body: RotateProviderCredentialsRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
) -> dict[str, Any]:
    try:
        _validate_safe_id(provider_id, "provider_id")
    except ValueError as exc:
        raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail=str(exc))
    try:
        result = store.rotate_provider_credentials(provider_id, credentials=body.credentials)
    except ValueError as exc:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail=str(exc))
    except ProviderNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
    except AdminInferenceStoreError as exc:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=safe_error_detail(exc))

    get_cached_resolver().invalidate()
    _append_audit(
        store,
        actor=_perm.actor_id,
        action="provider.rotate_credentials",
        target=provider_id,
        details={},
    )
    enriched = next(
        (
            row
            for row in AdminInferenceResolver(store=store).get_platform_providers()
            if row.get("provider_id") == provider_id
        ),
        None,
    )
    return enriched or {**result, "has_credentials": bool(result.get("credential_vault_ref"))}


@router.post("/providers/{provider_id}/disable", status_code=HTTPStatus.NO_CONTENT)
async def disable_provider(
    provider_id: str,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
) -> None:
    """Disable a platform provider without deleting credentials."""
    try:
        _validate_safe_id(provider_id, "provider_id")
        store.disable_provider(provider_id)
    except ValueError as exc:
        raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail=str(exc))
    except ProviderNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
    except AdminInferenceStoreError as exc:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=safe_error_detail(exc))

    get_cached_resolver().invalidate()
    logger.info("admin_inference.disable_provider provider=%s founder=%s", provider_id, _perm.actor_id)
    _append_audit(
        store,
        actor=_perm.actor_id,
        action="provider.disable",
        target=provider_id,
        details={},
    )


@router.post("/providers/{provider_id}/enable", status_code=HTTPStatus.NO_CONTENT)
async def enable_provider(
    provider_id: str,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
) -> None:
    """Re-enable a previously-disabled platform provider.

    Mirrors :func:`disable_provider`. Issue #3505: founder admin UI was wired to
    POST /enable but no symmetric verb existed, producing silent 404s on every
    enable click. Each verb is its own audit-log entry so the lifecycle history
    stays explicit.
    """
    try:
        _validate_safe_id(provider_id, "provider_id")
        store.enable_provider(provider_id)
    except ValueError as exc:
        raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail=str(exc))
    except ProviderNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
    except AdminInferenceStoreError as exc:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=safe_error_detail(exc))

    get_cached_resolver().invalidate()
    logger.info("admin_inference.enable_provider provider=%s founder=%s", provider_id, _perm.actor_id)
    _append_audit(
        store,
        actor=_perm.actor_id,
        action="provider.enable",
        target=provider_id,
        details={},
    )


@router.post("/providers/{provider_id}/retire", response_model=ProviderSummary)
async def retire_provider(
    provider_id: str,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
) -> dict[str, Any]:
    try:
        _validate_safe_id(provider_id, "provider_id")
        result = store.retire_provider(provider_id)
    except ValueError as exc:
        raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail=str(exc))
    except ProviderNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
    except AdminInferenceStoreError as exc:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=safe_error_detail(exc))

    get_cached_resolver().invalidate()
    _append_audit(
        store,
        actor=_perm.actor_id,
        action="provider.retire",
        target=provider_id,
        details={"dependencies_cleared": True},
    )
    enriched = next(
        (
            row
            for row in AdminInferenceResolver(store=store).get_platform_providers()
            if row.get("provider_id") == provider_id
        ),
        None,
    )
    return enriched or {**result, "has_credentials": bool(result.get("credential_vault_ref"))}


@router.delete("/providers/{provider_id}", response_model=ProviderSummary)
async def delete_provider(
    provider_id: str,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
) -> dict[str, Any]:
    try:
        _validate_safe_id(provider_id, "provider_id")
        result = store.delete_provider(provider_id)
    except ValueError as exc:
        raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail=str(exc))
    except ProviderNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
    except AdminInferenceStoreError as exc:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=safe_error_detail(exc))

    get_cached_resolver().invalidate()
    _append_audit(
        store,
        actor=_perm.actor_id,
        action="provider.delete",
        target=provider_id,
        details={"soft_deleted": True},
    )
    return {**result, "has_credentials": False}


@router.post("/providers/{provider_id}/smoke-test", response_model=ProviderSmokeTestResponse)
async def smoke_test_provider(
    provider_id: str,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
) -> dict[str, Any]:
    """Run a founder-admin smoke test against a configured platform provider."""
    try:
        _validate_safe_id(provider_id, "provider_id")
    except ValueError as exc:
        raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail=str(exc))

    try:
        result = await run_platform_provider_smoke_test(provider_id, store=store)
    except ProviderNotFoundError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc))
    except AdminInferenceStoreError as exc:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=safe_error_detail(exc))

    get_cached_resolver().invalidate()
    _append_audit(
        store,
        actor=_perm.actor_id,
        action="provider.smoke_test",
        target=provider_id,
        details={
            "status": result.get("status"),
            "model": result.get("model"),
            "latency_ms": result.get("latency_ms"),
            "error": result.get("error"),
        },
    )
    return result


@router.get("/models")
async def list_allowed_models(
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    resolver: AdminInferenceResolver = Depends(_get_resolver),
) -> dict[str, list[str]]:
    """Return {provider_id: [model_spec, ...]} for all enabled providers.

    An empty list for a provider means all catalog models are permitted.
    """
    return resolver.get_allowed_models()


@router.get("/capabilities", response_model=list[ProviderCapabilityResponse])
async def list_provider_capabilities(
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
) -> list[dict[str, Any]]:
    """Return the full provider capability catalog (Issue #1200).

    Machine-readable support matrix — routing, admin UI, and tenant
    surfaces consume this to expose support limitations truthfully.
    Founder-only because it exposes the full upstream provider landscape.
    """
    return [cap.to_dict() for cap in all_capabilities().values()]


# ---------------------------------------------------------------------------
# Provider Registry (runtime provider metadata — Plugin-style)
# ---------------------------------------------------------------------------


class RegisterProviderRequest(BaseModel):
    """Request body for registering a new provider at runtime."""
    label: str = Field(..., min_length=1, max_length=100)
    base_url: str = Field("", max_length=500)
    auth_header_name: str = Field("Authorization", max_length=100)
    auth_header_prefix: str = Field("Bearer ", max_length=50)
    reasoning_param: str = Field("", max_length=50)
    default_model: str = Field("", max_length=200)
    base_url_placeholder: str = Field("", max_length=500)
    api_key_placeholder: str = Field("", max_length=200)
    supports_tools: bool = True
    supports_parallel_tools: bool = True
    supports_streaming: bool = True
    supports_multimodal_input: bool = False
    supports_structured_output: bool = True
    supports_reasoning_effort: bool = False
    supports_reasoning_budget: bool = False
    notes: str = Field("", max_length=500)


@router.get("/registry", response_model=list[dict[str, Any]])
async def list_registry_providers(
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
) -> list[dict[str, Any]]:
    """Return all providers in the runtime ProviderRegistry.

    This is the plugin-style view: every provider's metadata, transport,
    capabilities, and builder type in a single endpoint.
    """
    from apps.backend.services.inference.provider_config import get_provider_registry  # noqa: PLC0415

    registry = get_provider_registry()
    return [
        {
            **cfg.to_preset_dict(),
            **cfg.to_capability_dict(),
            "builder_type": cfg.builder_type,
            "enabled": cfg.enabled,
        }
        for cfg in registry.list_all()
    ]


@router.get("/registry/{provider_id}", response_model=dict[str, Any])
async def get_registry_provider(
    provider_id: str,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
) -> dict[str, Any]:
    """Return a single provider's full metadata from the runtime registry."""
    from apps.backend.services.inference.provider_config import get_provider_registry  # noqa: PLC0415

    registry = get_provider_registry()
    config = registry.get(provider_id)
    if config is None:
        raise HTTPException(status_code=HTTPStatus.NOT_FOUND, detail=f"Provider '{provider_id}' not in registry.")
    return {
        **config.to_preset_dict(),
        **config.to_capability_dict(),
        "builder_type": config.builder_type,
        "enabled": config.enabled,
    }


@router.post("/registry", status_code=HTTPStatus.GONE, response_model=dict[str, Any])
async def register_provider(
    body: RegisterProviderRequest,  # noqa: ARG001 — kept for OpenAPI parity during migration
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
) -> dict[str, Any]:
    """Deprecated since Issue #3509 — returns 410 Gone.

    The in-memory ``ProviderRegistry`` POST never persisted across process
    restarts. Custom providers now live as durable rows in
    ``ProviderProfileStore`` (``INFERENCE#PROVIDER_PROFILE#{provider_instance_id}``).

    Migration:
        * CLI:  ``ww inference provider profile add --kind custom_openai ...``
        * MCP:  ``ww.inference.provider.profile.add``
        * REST: ``POST /api/v1/settings/ai/inference/provider-profiles``
    """
    raise HTTPException(
        status_code=HTTPStatus.GONE,
        detail={
            "reason": "endpoint_removed",
            "message": (
                "POST /registry was removed in Issue #3509. Use "
                "POST /api/v1/settings/ai/inference/provider-profiles to add "
                "a durable, free-form custom provider."
            ),
            "replacement_endpoint": "/api/v1/settings/ai/inference/provider-profiles",
            "replacement_cli": "ww inference provider profile add",
            "replacement_mcp": "ww.inference.provider.profile.add",
            "issue": 3509,
        },
    )


@router.delete("/registry/{provider_id}", status_code=HTTPStatus.NO_CONTENT)
async def unregister_provider(
    provider_id: str,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
) -> None:
    """Remove a runtime-registered provider from the registry.

    Seeded providers (the built-in defaults) cannot be removed.
    """
    from apps.backend.services.inference.provider_config import get_provider_registry  # noqa: PLC0415

    registry = get_provider_registry()
    if not registry.is_registered(provider_id):
        raise HTTPException(status_code=HTTPStatus.NOT_FOUND, detail=f"Provider '{provider_id}' not in registry.")
    removed = registry.unregister(provider_id)
    if removed is None:
        raise HTTPException(status_code=HTTPStatus.NOT_FOUND, detail=f"Provider '{provider_id}' not in registry.")
    logger.info("admin_inference.unregister_provider provider=%s founder=%s", provider_id, _perm.actor_id)


@router.get("/audit", response_model=list[AuditEventResponse])
async def list_audit_events(
    limit: int = 50,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    store: AdminInferenceStore = Depends(_get_store),
) -> list[dict[str, Any]]:
    """Return recent founder-admin audit events for the inference control plane."""
    try:
        return store.list_audit_events(limit=limit)
    except AdminInferenceStoreError as exc:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=safe_error_detail(exc))


@router.get("/usage/overview", response_model=FounderInferenceUsageOverviewResponse)
async def get_founder_inference_usage_overview(
    year: int | None = None,
    month: int | None = None,
    recent_limit: int = Query(25, ge=1, le=200),
    tenant_limit: int = Query(10, ge=1, le=100),
    provider_limit: int = Query(10, ge=1, le=100),
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    read_models: BillingReadModelService = Depends(_get_billing_read_model_service),
) -> dict[str, Any]:
    """Return founder-grade inference spend and activity visibility."""
    try:
        return read_models.founder_inference_overview(
            year=year,
            month=month,
            recent_limit=recent_limit,
            tenant_limit=tenant_limit,
            provider_limit=provider_limit,
        )
    except Exception as exc:
        logger.error("Failed to compute founder inference usage overview: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to compute founder inference usage overview")


@router.get("/usage/resources", response_model=FounderResourceUsageOverviewResponse)
async def get_founder_resource_usage_overview(
    year: int | None = None,
    month: int | None = None,
    tenant_limit: int = Query(10, ge=1, le=100),
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    read_models: BillingReadModelService = Depends(_get_billing_read_model_service),
) -> dict[str, Any]:
    """Return founder-grade resource usage envelopes for tokens, compute, memory, storage, and bandwidth."""
    try:
        return read_models.founder_resource_usage_overview(
            year=year,
            month=month,
            tenant_limit=tenant_limit,
        )
    except Exception as exc:
        logger.error("Failed to compute founder resource usage overview: %s", exc)
        raise HTTPException(status_code=500, detail="Failed to compute founder resource usage overview")


@router.get("/defaults", response_model=PlatformDefaultsResponse)
async def get_platform_defaults(
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    store: AdminInferenceStore = Depends(_get_store),
) -> dict[str, str]:
    """Return platform-wide default provider and model."""
    defaults = store.get_platform_defaults()
    if not defaults:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Platform defaults not configured yet.",
        )
    return defaults


@router.get("/routing/fallback-events")
async def get_routing_fallback_events(
    tenant_id: str | None = None,
    limit: int = 100,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
) -> dict[str, Any]:
    """Return recent fallback-chain audit events (issue #3512).

    Founder-admin grid surfaces these distinct from primary inference calls
    so reviewers can see when a request advanced through the chain or was
    halted by a stop-class failure (auth/policy/jurisdiction).
    """
    from apps.backend.services.inference.inference_audit import (
        list_inference_fallback_events,
    )

    events = list_inference_fallback_events(tenant_id=tenant_id, limit=max(1, min(int(limit), 500)))
    return {"events": events, "count": len(events)}


@router.get("/routing", response_model=PlatformRoutingResponse)
async def get_platform_routing(
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    resolver: AdminInferenceResolver = Depends(_get_resolver),
) -> dict[str, Any]:
    """Return platform routing policy, falling back to the current static defaults."""
    return resolver.get_platform_routing()


@router.post("/defaults", response_model=PlatformDefaultsResponse)
async def set_platform_defaults(
    body: PlatformDefaultsRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
) -> dict[str, str]:
    """Set platform-wide default provider and model.

    Validates that the provider exists, is enabled, and that the model is
    permitted by the allowlist before persisting — prevents orphaned defaults
    that reference a non-existent or disabled provider/model combination.
    """
    # Validate provider exists and is enabled.
    try:
        provider_config = store.get_provider(body.default_provider)
    except ProviderNotFoundError:
        raise HTTPException(
            status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
            detail=f"Provider {body.default_provider!r} is not configured. "
                   "Create it first via POST /providers/{provider_id}.",
        )
    except AdminInferenceStoreError as exc:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=safe_error_detail(exc))

    if not provider_config.get("enabled", False):
        raise HTTPException(
            status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
            detail=f"Provider {body.default_provider!r} is currently disabled. Enable it before setting as default.",
        )

    # Validate model is allowed for the provider.
    if not store.is_model_allowed(body.default_provider, body.default_model):
        raise HTTPException(
            status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
            detail=f"Model {body.default_model!r} is not in the allowlist for provider {body.default_provider!r}.",
        )

    store.set_platform_defaults(
        default_provider=body.default_provider,
        default_model=body.default_model,
    )
    get_cached_resolver().invalidate()
    logger.info("admin_inference.set_defaults provider=%s model=%s founder=%s",
                body.default_provider, body.default_model, _perm.actor_id)
    _append_audit(
        store,
        actor=_perm.actor_id,
        action="platform_defaults.set",
        target=body.default_provider,
        details={"default_model": body.default_model},
    )
    return {"default_provider": body.default_provider, "default_model": body.default_model}


@router.post("/routing", response_model=PlatformRoutingResponse)
async def set_platform_routing(
    body: PlatformRoutingRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
    resolver: AdminInferenceResolver = Depends(_get_resolver),
) -> dict[str, Any]:
    """Persist capability-class routing defaults for the platform."""
    normalized_capability_classes = _normalize_routing_payload(
        body=body,
        resolver=resolver,
        store=store,
    )

    persisted = store.set_platform_routing(capability_classes=normalized_capability_classes)
    get_cached_resolver().invalidate()
    logger.info(
        "admin_inference.set_routing capability_classes=%s founder=%s",
        sorted(normalized_capability_classes),
        _perm.actor_id,
    )
    _append_audit(
        store,
        actor=_perm.actor_id,
        action="platform_routing.set",
        target="platform",
        details={"capability_classes": normalized_capability_classes},
    )
    return {
        "source": "platform",
        "updated_at": str(persisted.get("updated_at") or ""),
        "capability_classes": normalized_capability_classes,
    }


@router.get("/tenants/{tenant_id}/routing-override", response_model=TenantRoutingOverrideResponse)
async def get_tenant_routing_override(
    tenant_id: str,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    resolver: AdminInferenceResolver = Depends(_get_resolver),
) -> dict[str, Any]:
    try:
        _validate_safe_id(tenant_id, "tenant_id")
    except ValueError as exc:
        raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail=str(exc))
    return resolver.get_tenant_routing_override(tenant_id)


@router.post("/tenants/{tenant_id}/routing-override", response_model=TenantRoutingOverrideResponse)
async def set_tenant_routing_override(
    tenant_id: str,
    body: PlatformRoutingRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
    resolver: AdminInferenceResolver = Depends(_get_resolver),
) -> dict[str, Any]:
    try:
        _validate_safe_id(tenant_id, "tenant_id")
    except ValueError as exc:
        raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail=str(exc))

    normalized_capability_classes = _normalize_routing_payload(
        body=body,
        resolver=resolver,
        store=store,
    )
    persisted = store.set_tenant_routing_override(
        tenant_id=tenant_id,
        capability_classes=normalized_capability_classes,
    )
    get_cached_resolver().invalidate()
    _append_audit(
        store,
        actor=_perm.actor_id,
        action="tenant_routing_override.set",
        target=tenant_id,
        details={"capability_classes": normalized_capability_classes},
    )
    return {
        "tenant_id": str(persisted.get("tenant_id") or tenant_id),
        "source": "founder_tenant_override",
        "updated_at": str(persisted.get("updated_at") or ""),
        "capability_classes": normalized_capability_classes,
    }


@router.delete("/tenants/{tenant_id}/routing-override", status_code=HTTPStatus.NO_CONTENT)
async def delete_tenant_routing_override(
    tenant_id: str,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
) -> None:
    try:
        _validate_safe_id(tenant_id, "tenant_id")
    except ValueError as exc:
        raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail=str(exc))
    deleted = store.delete_tenant_routing_override(tenant_id)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No founder tenant routing override exists for {tenant_id!r}.",
        )
    get_cached_resolver().invalidate()
    _append_audit(
        store,
        actor=_perm.actor_id,
        action="tenant_routing_override.delete",
        target=tenant_id,
        details={},
    )


@router.get("/tenants/{tenant_id}/platform-policy")
async def get_tenant_platform_policy(
    tenant_id: str,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    resolver: AdminInferenceResolver = Depends(_get_resolver),
) -> dict[str, Any]:
    """Return the platform-level inference policy that applies to a tenant.

    Shows which providers are enabled and what model allowlists are in effect.
    This is the admin's view of policy — it does NOT include what the tenant
    has actually selected (tenant selections live in tenant AI settings).
    Does NOT return credentials.
    """
    try:
        _validate_safe_id(tenant_id, "tenant_id")
    except ValueError as exc:
        raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail=str(exc))

    defaults = resolver.get_platform_defaults()
    allowed = resolver.get_allowed_models()
    return {
        "tenant_id": tenant_id,
        "platform_defaults": defaults,
        "enabled_providers": list(allowed.keys()),
        "allowed_models_by_provider": allowed,
    }


@router.get("/tenants/{tenant_id}/effective-config")
async def get_tenant_effective_config(
    tenant_id: str,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    resolver: AdminInferenceResolver = Depends(_get_resolver),
) -> dict[str, Any]:
    """Return the effective founder-visible inference config for a tenant."""
    try:
        _validate_safe_id(tenant_id, "tenant_id")
    except ValueError as exc:
        raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail=str(exc))
    return resolver.get_tenant_effective_config(tenant_id)


@router.get("/tenants/{tenant_id}/usage", response_model=TenantInferenceUsageResponse)
async def get_tenant_inference_usage(
    tenant_id: str,
    year: int | None = None,
    month: int | None = None,
    limit: int = Query(25, ge=1, le=200),
    provider_limit: int = Query(10, ge=1, le=100),
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    read_models: BillingReadModelService = Depends(_get_billing_read_model_service),
) -> dict[str, Any]:
    """Return normalized inference spend/activity for one tenant."""
    try:
        _validate_safe_id(tenant_id, "tenant_id")
    except ValueError as exc:
        raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail=str(exc))
    try:
        return read_models.tenant_inference_activity(
            tenant_id,
            year=year,
            month=month,
            limit=limit,
            provider_limit=provider_limit,
        )
    except Exception as exc:
        logger.error("Failed to compute tenant inference usage tenant=%s: %s", tenant_id, exc)
        raise HTTPException(status_code=500, detail="Failed to compute tenant inference usage")


@router.get("/tenants/{tenant_id}/resources", response_model=TenantResourceUsageResponse)
async def get_tenant_resource_usage(
    tenant_id: str,
    year: int | None = None,
    month: int | None = None,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    read_models: BillingReadModelService = Depends(_get_billing_read_model_service),
) -> dict[str, Any]:
    """Return the tenant resource envelope for tokens, compute, memory, storage, and bandwidth."""
    try:
        _validate_safe_id(tenant_id, "tenant_id")
    except ValueError as exc:
        raise HTTPException(status_code=HTTPStatus.UNPROCESSABLE_ENTITY, detail=str(exc))
    try:
        return read_models.tenant_resource_usage(
            tenant_id,
            year=year,
            month=month,
        )
    except Exception as exc:
        logger.error("Failed to compute tenant resource usage tenant=%s: %s", tenant_id, exc)
        raise HTTPException(status_code=500, detail="Failed to compute tenant resource usage")


@router.get("/capability-evals/{capability_class}/last-known-good")
async def get_last_known_good_capability_variant(
    capability_class: str,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    store: VariantStore = Depends(_get_variant_store),
) -> dict[str, Any]:
    """Return the latest LIVE variant for a capability class."""
    normalized = capability_class.strip()
    if normalized not in supported_capability_classes():
        raise HTTPException(
            status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
            detail=(
                f"Unsupported capability class {normalized!r}. "
                f"Supported classes: {', '.join(supported_capability_classes())}."
            ),
        )
    variant = store.get_last_known_good_variant(_CAPABILITY_EVAL_TENANT_ID, normalized)
    if variant is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No LIVE variant recorded for capability class {normalized!r}.",
        )
    return variant.to_dict()


@router.get("/capability-evals/{capability_class}/artifacts", response_model=CapabilityEvalArtifactsResponse)
async def list_capability_eval_artifacts(
    capability_class: str,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    store: VariantStore = Depends(_get_variant_store),
) -> dict[str, Any]:
    """Return capability-class variants and runs from the shared store."""
    normalized = capability_class.strip()
    if normalized not in supported_capability_classes():
        raise HTTPException(
            status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
            detail=(
                f"Unsupported capability class {normalized!r}. "
                f"Supported classes: {', '.join(supported_capability_classes())}."
            ),
    )
    service = CapabilityEvalCanaryService(store=store)
    return service.list_artifacts(_CAPABILITY_EVAL_TENANT_ID, normalized)


@router.post("/capability-evals/{capability_class}/evaluate", response_model=CapabilityEvalRunResponse)
async def evaluate_capability_variant(
    capability_class: str,
    body: CapabilityEvalRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: VariantStore = Depends(_get_variant_store),
) -> dict[str, Any]:
    """Run a bounded capability-class eval/canary on an existing Variant."""
    normalized = capability_class.strip()
    if normalized not in supported_capability_classes():
        raise HTTPException(
            status_code=HTTPStatus.UNPROCESSABLE_ENTITY,
            detail=(
                f"Unsupported capability class {normalized!r}. "
                f"Supported classes: {', '.join(supported_capability_classes())}."
            ),
        )
    service = CapabilityEvalCanaryService(store=store)
    outcome = service.evaluate(
        tenant_id=_CAPABILITY_EVAL_TENANT_ID,
        capability_class=normalized,
        variant_id=body.variant_id,
        baseline_metrics=body.baseline_metrics.model_dump(exclude_none=True),
        candidate_metrics=body.candidate_metrics.model_dump(exclude_none=True),
        material_change=body.material_change,
        context_slice=body.context_slice,
        trace_envelope_id=body.trace_envelope_id,
        judge_votes=[vote.model_dump(exclude_none=True) for vote in body.judge_votes],
        candidate_order=body.candidate_order,
        boundary_conditions=body.boundary_conditions,
    )
    return {
        "capability_class": outcome.capability_class,
        "tenant_id": outcome.tenant_id,
        "variant_id": outcome.variant_id,
        "run_id": outcome.run_id,
        "passed": outcome.passed,
        "verdict": outcome.verdict,
        "promotion_state": outcome.promotion_state,
        "last_known_good_variant_id": outcome.last_known_good_variant_id,
        "gate_summary": outcome.gate_summary,
        "judge_votes": outcome.judge_votes,
        "candidate_order": outcome.candidate_order,
        "thresholds": outcome.thresholds,
        "experiment_run": outcome.experiment_run,
        "variant": outcome.variant,
    }



# ============================================================================
# Dry-run request / response models (Issue #2524)
# ============================================================================


class DryRunChainEntry(BaseModel):
    provider: str = Field(..., min_length=1, max_length=120)
    model: str = Field(..., min_length=1, max_length=200)

    @field_validator("provider")
    @classmethod
    def _validate_provider(cls, v: str) -> str:
        return _validate_safe_id(v, "provider")

    @field_validator("model")
    @classmethod
    def _validate_model(cls, v: str) -> str:
        return _validate_safe_id(v, "model")


class DryRunRequest(BaseModel):
    tenant_id: str = Field(..., min_length=1, max_length=200)
    purpose: str = Field(..., min_length=1, max_length=200)
    proposed_chain: list[DryRunChainEntry] = Field(..., min_length=1)
    required_capabilities: dict[str, bool] | None = Field(default=None)

    @field_validator("tenant_id")
    @classmethod
    def _validate_tenant_id_field(cls, v: str) -> str:
        return _validate_safe_tenant_id(v)


class DryRunBulkRequest(BaseModel):
    items: list[DryRunRequest] = Field(..., min_length=1, max_length=50)


def _get_dry_run_resolver(store: AdminInferenceStore) -> DryRunResolver:
    return DryRunResolver(store=store)


@router.post("/dry-run")
async def inference_dry_run(
    body: DryRunRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
) -> dict[str, Any]:
    """Validate a proposed inference binding without persisting changes."""
    resolver = _get_dry_run_resolver(store)
    result = resolver.dry_run(
        tenant_id=body.tenant_id,
        purpose=body.purpose,
        proposed_chain=[{"provider": e.provider, "model": e.model} for e in body.proposed_chain],
        required_capabilities=body.required_capabilities,
    )
    _append_audit(
        store,
        actor=_perm.actor_id,
        action="inference.dry_run",
        target=body.tenant_id,
        details={
            "purpose": body.purpose,
            "proposed_chain": [{"provider": e.provider, "model": e.model} for e in body.proposed_chain],
            "would_satisfy_slo": result["would_satisfy_slo"],
            "evidence_id": result["evidence_id"],
        },
    )
    return result


@router.post("/dry-run/bulk")
async def inference_dry_run_bulk(
    body: DryRunBulkRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
) -> dict[str, Any]:
    """Bulk dry-run for applying platform defaults across tenants/purposes."""
    resolver = _get_dry_run_resolver(store)
    results: list[dict[str, Any]] = []
    for item in body.items:
        result = resolver.dry_run(
            tenant_id=item.tenant_id,
            purpose=item.purpose,
            proposed_chain=[{"provider": e.provider, "model": e.model} for e in item.proposed_chain],
            required_capabilities=item.required_capabilities,
        )
        results.append(result)
    passed = sum(1 for r in results if r["would_satisfy_slo"])
    return {
        "total": len(results),
        "passed": passed,
        "failed": len(results) - passed,
        "results": results,
    }

class PhantomModelAckRequest(BaseModel):
    provider: str = Field(..., min_length=1, max_length=120)
    requested_model: str = Field(..., min_length=1, max_length=200)
    confirmed_by: str = Field(default="founder", max_length=120)

    @field_validator("provider", "requested_model", "confirmed_by")
    @classmethod
    def _trim_required(cls, value: str) -> str:
        stripped = value.strip()
        if not stripped:
            raise ValueError("field must not be empty")
        return stripped


def _phantom_baseline_payload(row: Any) -> dict[str, Any]:
    return {
        "provider": row.provider,
        "requested_model": row.requested_model,
        "served_model": row.served_model,
        "first_seen_at": row.first_seen_at,
        "last_seen_at": row.last_seen_at,
        "confirmed_by": row.confirmed_by,
        "drift_served_model": row.drift_served_model,
        "drift_detected_at": row.drift_detected_at,
    }


@router.get("/phantom-model-drift")
async def list_phantom_model_drift(
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    guard: PhantomModelGuard = Depends(_get_phantom_model_guard),
) -> dict[str, Any]:
    """Return pending provider served-model drifts."""
    rows = [_phantom_baseline_payload(row) for row in guard.list_unconfirmed()]
    return {"items": rows, "count": len(rows)}


@router.post("/phantom-model-drift/ack")
async def ack_phantom_model_drift(
    body: PhantomModelAckRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    guard: PhantomModelGuard = Depends(_get_phantom_model_guard),
) -> dict[str, Any]:
    """Accept the drifted served model as the new baseline."""
    confirmed_by = body.confirmed_by or _perm.actor_id
    try:
        row = guard.ack(
            provider=body.provider,
            requested_model=body.requested_model,
            confirmed_by=confirmed_by,
        )
    except KeyError as exc:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(exc)) from exc
    return _phantom_baseline_payload(row)


# ---------------------------------------------------------------------------
# Dogfood tenant overrides (#2521)
# ---------------------------------------------------------------------------


class DogfoodOverrideRequest(BaseModel):
    purpose: str = Field(..., min_length=1)
    provider: str = Field(..., min_length=1)
    model: str = Field(..., min_length=1)


class DogfoodBulkApplyRequest(BaseModel):
    defaults: list[DogfoodOverrideRequest] = Field(..., min_length=1)


class DogfoodPromoteRequest(BaseModel):
    purpose: str = Field(..., min_length=1)


@router.get("/dogfood/{tenant_id}")
async def get_dogfood_overrides(
    tenant_id: str,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    store: AdminInferenceStore = Depends(get_admin_inference_store),
) -> dict[str, Any]:
    """List all dogfood model overrides for a tenant."""
    overrides = store.get_tenant_dogfood_overrides(tenant_id)
    return {"tenant_id": tenant_id, "overrides": overrides, "count": len(overrides)}


@router.post("/dogfood/{tenant_id}")
async def set_dogfood_override(
    tenant_id: str,
    body: DogfoodOverrideRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(get_admin_inference_store),
) -> dict[str, Any]:
    """Set a dogfood model override for a specific purpose."""
    result = store.set_tenant_dogfood_override(
        tenant_id=tenant_id,
        purpose=body.purpose,
        provider=body.provider,
        model=body.model,
    )
    return {"status": "ok", **result}


@router.delete("/dogfood/{tenant_id}/{purpose}")
async def delete_dogfood_override(
    tenant_id: str,
    purpose: str,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(get_admin_inference_store),
) -> dict[str, Any]:
    """Remove a dogfood override for a tenant+purpose."""
    deleted = store.delete_tenant_dogfood_override(tenant_id, purpose)
    if not deleted:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No override found for tenant={tenant_id}, purpose={purpose}",
        )
    return {"status": "deleted", "tenant_id": tenant_id, "purpose": purpose}


@router.post("/dogfood/{tenant_id}/bulk-apply")
async def bulk_apply_dogfood(
    tenant_id: str,
    body: DogfoodBulkApplyRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(get_admin_inference_store),
) -> dict[str, Any]:
    """Bulk-apply platform defaults as dogfood overrides for a tenant."""
    defaults = [
        {"purpose": d.purpose, "provider": d.provider, "model": d.model}
        for d in body.defaults
    ]
    applied = store.bulk_apply_dogfood_defaults(
        tenant_id=tenant_id,
        defaults=defaults,
    )
    return {"status": "ok", "applied": applied, "count": len(applied)}


@router.post("/dogfood/{tenant_id}/promote")
async def promote_dogfood_override(
    tenant_id: str,
    body: DogfoodPromoteRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(get_admin_inference_store),
) -> dict[str, Any]:
    """Promote a dogfood override to platform default (with guardrails).

    Guardrails:
      - Override must have been active for >= 7 days
      - Override must have at least 1 successful probe
    """
    from apps.backend.services.inference.dogfood_promotion import (
        DogfoodPromotionGuard,
    )

    overrides = store.get_tenant_dogfood_overrides(tenant_id)
    guard = DogfoodPromotionGuard(store=store)
    result = guard.check_promotion(
        tenant_id=tenant_id,
        purpose=body.purpose,
        overrides=overrides,
    )
    if not result.allowed:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Promotion blocked: {result.reason.value} — {result.detail}",
        )

    matching = [o for o in overrides if o.get("purpose") == body.purpose]
    if not matching:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail=f"No override found for purpose '{body.purpose}'",
        )
    override = matching[0]
    store.set_platform_default_model(
        purpose=body.purpose,
        provider=override["provider"],
        model=override["model"],
    )
    return {
        "status": "promoted",
        "purpose": body.purpose,
        "provider": override["provider"],
        "model": override["model"],
    }


# ============================================================================
# Purpose-granular endpoints (Issue #2518)
# ============================================================================


class PurposePlatformDefaultRequest(BaseModel):
    provider: str = Field(..., min_length=1)
    model: str = Field(..., min_length=1)


class TenantPurposeOverrideRequest(BaseModel):
    provider: str = Field(..., min_length=1)
    model: str = Field(..., min_length=1)


class TenantPurposeBulkRequest(BaseModel):
    purposes: list[dict[str, str]] = Field(..., min_length=1)
    provider: str = Field(..., min_length=1)
    model: str = Field(..., min_length=1)


@router.get("/purposes")
async def list_purposes(
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
) -> dict[str, Any]:
    """List all purposes with their requirements and platform defaults."""
    from apps.backend.services.inference.purposes import (
        PURPOSE_REQUIREMENTS,
        _DEFAULT_PURPOSE_MODELS,
        _PURPOSE_INTERFACE,
        Purpose,
    )

    purposes: list[dict[str, Any]] = []
    for purpose in Purpose:
        reqs = PURPOSE_REQUIREMENTS.get(purpose)
        default_model = _DEFAULT_PURPOSE_MODELS.get(purpose, "")
        interface = _PURPOSE_INTERFACE.get(purpose)
        purposes.append({
            "purpose": purpose.value,
            "interface": interface.value if interface else None,
            "default_model": default_model,
            "requirements": {
                "tool_call": reqs.tool_call if reqs else False,
                "multimodal": reqs.multimodal if reqs else False,
                "json_mode": reqs.json_mode if reqs else False,
                "max_input_tokens": reqs.max_input_tokens if reqs else 8192,
                "latency_p95_ms_slo": reqs.latency_p95_ms_slo if reqs else None,
                "streaming": reqs.streaming if reqs else False,
                "embedding_dim": reqs.embedding_dim if reqs else None,
            } if reqs else None,
        })

    return {"purposes": purposes, "total": len(purposes)}


@router.get("/purposes/{purpose}/effective")
async def get_effective_purpose_config(
    purpose: str,
    tenant_id: str = Query(""),
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
) -> dict[str, Any]:
    """Resolve the effective model chain for a purpose, optionally for a tenant."""
    from apps.backend.services.inference.purposes import (
        PURPOSE_REQUIREMENTS,
        Purpose,
        PurposeRouter,
    )

    try:
        p = Purpose(purpose)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unknown purpose: {purpose}",
        )

    router = PurposeRouter(tenant_id=tenant_id or None)
    resolved_model = router.resolve_model(p, enforce_jurisdiction=False)
    resolved_chain = router.resolve_model_chain(p, enforce_jurisdiction=False)
    reqs = PURPOSE_REQUIREMENTS.get(p)

    result: dict[str, Any] = {
        "purpose": p.value,
        "resolved_model": resolved_model,
        "resolved_chain": list(resolved_chain),
        "requirements": {
            "tool_call": reqs.tool_call,
            "multimodal": reqs.multimodal,
            "json_mode": reqs.json_mode,
            "max_input_tokens": reqs.max_input_tokens,
            "latency_p95_ms_slo": reqs.latency_p95_ms_slo,
            "streaming": reqs.streaming,
            "embedding_dim": reqs.embedding_dim,
        } if reqs else None,
    }

    if tenant_id:
        result["tenant_id"] = tenant_id

    return result


@router.post("/purposes/{purpose}/platform-default")
async def set_purpose_platform_default(
    purpose: str,
    body: PurposePlatformDefaultRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(get_admin_inference_store),
) -> dict[str, Any]:
    """Set the platform-default model for a purpose."""
    from apps.backend.services.inference.purposes import Purpose

    try:
        p = Purpose(purpose)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unknown purpose: {purpose}",
        )

    store.set_platform_default_model(
        purpose=p.value,
        provider=body.provider,
        model=body.model,
    )
    return {
        "status": "updated",
        "purpose": p.value,
        "provider": body.provider,
        "model": body.model,
    }


@router.post("/tenants/{tenant_id}/purposes/bulk")
async def bulk_set_tenant_purposes(
    tenant_id: str,
    body: TenantPurposeBulkRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(get_admin_inference_store),
) -> dict[str, Any]:
    """Bulk-apply a provider+model to multiple purposes for a tenant."""
    from apps.backend.services.inference.purposes import Purpose

    applied: list[str] = []
    errors: list[dict[str, str]] = []

    for entry in body.purposes:
        purpose_str = entry.get("purpose", "")
        try:
            Purpose(purpose_str)
        except ValueError:
            errors.append({"purpose": purpose_str, "error": "Unknown purpose"})
            continue

        store.set_tenant_purpose_override(
            tenant_id=tenant_id,
            purpose=purpose_str,
            provider=body.provider,
            model=body.model,
        )
        applied.append(purpose_str)

    return {
        "status": "applied",
        "tenant_id": tenant_id,
        "applied": applied,
        "errors": errors,
    }


@router.post("/tenants/{tenant_id}/purposes/{purpose}")
async def set_tenant_purpose_override(
    tenant_id: str,
    purpose: str,
    body: TenantPurposeOverrideRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(get_admin_inference_store),
) -> dict[str, Any]:
    """Set a tenant-specific model override for a purpose."""
    from apps.backend.services.inference.purposes import Purpose

    try:
        p = Purpose(purpose)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unknown purpose: {purpose}",
        )

    store.set_tenant_purpose_override(
        tenant_id=tenant_id,
        purpose=p.value,
        provider=body.provider,
        model=body.model,
    )
    return {
        "status": "updated",
        "tenant_id": tenant_id,
        "purpose": p.value,
        "provider": body.provider,
        "model": body.model,
    }


# ============================================================================
# SLO enforcement endpoint (Issue #2518)
# ============================================================================


@router.get("/purposes/slo-violations")
async def get_slo_violations(
    tenant_id: str = Query(""),
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
) -> dict[str, Any]:
    """Check observed inference latency against purpose SLOs."""
    from datetime import UTC, datetime

    from apps.backend.services.inference.inference_audit import get_inference_audit_log

    log = get_inference_audit_log()
    if not tenant_id:
        return {"violations": [], "tenant_id": ""}

    violations = log.check_slo_violations(tenant_id)
    return {
        "tenant_id": tenant_id,
        "violations": violations,
        "checked_at": datetime.now(UTC).isoformat(),
    }


# ============================================================================
# Platform-wide per-purpose model defaults (Issue #2689)
# ============================================================================


class PlatformPurposeDefaultsRequest(BaseModel):
    """Request to set platform-wide default model for a purpose."""

    purpose: str = Field(..., description="Purpose enum value (e.g., 'workmemory.query_expansion')")
    model: str = Field(..., description="Model ID (e.g., 'grok-4-1-fast')")


@router.get("/purpose-defaults")
async def get_platform_purpose_defaults(
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
) -> dict[str, Any]:
    """Return all platform-wide per-purpose model defaults.

    Returns the hardcoded defaults from purposes.py as the source of truth,
    along with any platform-wide overrides that have been configured.
    """
    from apps.backend.services.inference.purposes import Purpose, _DEFAULT_PURPOSE_MODELS

    defaults = {}
    for purpose in Purpose:
        defaults[purpose.value] = _DEFAULT_PURPOSE_MODELS.get(purpose, "")

    return {
        "purpose_defaults": defaults,
        "total_purposes": len(defaults),
    }


@router.get("/purpose-defaults/{purpose}")
async def get_platform_purpose_default(
    purpose: str,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
) -> dict[str, Any]:
    """Return the platform-wide default model for a specific purpose."""
    from apps.backend.services.inference.purposes import Purpose, _DEFAULT_PURPOSE_MODELS

    try:
        p = Purpose(purpose)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Unknown purpose: {purpose}",
        )

    default_model = _DEFAULT_PURPOSE_MODELS.get(p, "")
    return {
        "purpose": p.value,
        "default_model": default_model,
    }


# ============================================================================
# Provider audit dashboard (Issue #3215)
# ============================================================================


class AuditDefaultSetRequest(BaseModel):
    purpose: str = Field(..., min_length=1, max_length=200)
    provider: str = Field(..., min_length=1, max_length=120)
    model: str = Field(..., min_length=1, max_length=200)

    @field_validator("provider")
    @classmethod
    def _validate_provider(cls, v: str) -> str:
        return _validate_safe_id(v, "provider")

    @field_validator("model")
    @classmethod
    def _validate_model(cls, v: str) -> str:
        return _validate_safe_id(v, "model")


class AuditGridColumn(BaseModel):
    provider_id: str
    label: str
    pricing: dict[str, Any] = Field(default_factory=dict)
    health: dict[str, Any] = Field(default_factory=dict)


class AuditGridRow(BaseModel):
    purpose: str
    default_model: str = ""
    requirements: dict[str, Any] | None = None


class AuditGridCell(BaseModel):
    cost_per_m_tokens: float = 0.0
    latency_p50_ms: float = 0.0
    latency_p95_ms: float = 0.0
    quality_score: float | None = None
    jurisdiction: str = ""
    call_count: int = 0
    total_cost_usd: float = 0.0
    total_tokens: int = 0


class AuditGridResponse(BaseModel):
    rows: list[AuditGridRow]
    columns: list[AuditGridColumn]
    grid: dict[str, dict[str, dict[str, Any]]]
    generated_at: str


# Provider jurisdiction mapping for audit grid
_PROVIDER_JURISDICTION: dict[str, str] = {
    "openai": "US",
    "anthropic": "US",
    "openrouter": "US",
    "opencode_zen": "US",
    "bedrock": "US",
    "grok": "US",
    "deepseek": "CN",
    "qwen": "CN",
    "moonshot": "CN",
    "google": "US",
    "mistral": "EU",
}


def build_audit_grid(
    *,
    resolver: AdminInferenceResolver,
    tenant_id: str = "",
    purpose: str = "",
) -> dict[str, Any]:
    """Build the per-Purpose x per-provider audit grid response payload.

    Shared helper used by both the REST audit-grid endpoint and the public MCP
    handler so both surfaces project the same canonical view.

    Args:
        resolver: AdminInferenceResolver for platform provider catalog reads.
        tenant_id: Optional tenant filter; when empty, aggregates platform-wide.
        purpose: Optional purpose filter (case-sensitive Purpose enum value);
            when set, only that row is included.

    Returns:
        Dict with ``rows``, ``columns``, ``grid``, ``generated_at`` keys —
        ready for both the REST AuditGridResponse and MCP tool result.
    """
    from datetime import UTC, datetime

    from apps.backend.services.inference.inference_audit import get_inference_audit_log
    from apps.backend.services.inference.purposes import (
        PURPOSE_REQUIREMENTS,
        Purpose,
        _DEFAULT_PURPOSE_MODELS,
    )

    providers = resolver.get_platform_providers()
    enabled_providers = [p for p in providers if p.get("enabled", False)]

    # Build columns
    columns = [
        AuditGridColumn(
            provider_id=p["provider_id"],
            label=p.get("label", p["provider_id"]),
            pricing=p.get("pricing", {}),
            health=p.get("health", {}),
        )
        for p in enabled_providers
    ]
    # Build rows (all Purpose enum values, optionally filtered)
    rows: list[AuditGridRow] = []
    for purpose_enum in Purpose:
        if purpose and purpose_enum.value != purpose:
            continue
        reqs = PURPOSE_REQUIREMENTS.get(purpose_enum)
        rows.append(AuditGridRow(
            purpose=purpose_enum.value,
            default_model=_DEFAULT_PURPOSE_MODELS.get(purpose_enum, ""),
            requirements={
                "tool_call": reqs.tool_call if reqs else False,
                "multimodal": reqs.multimodal if reqs else False,
                "json_mode": reqs.json_mode if reqs else False,
                "max_input_tokens": reqs.max_input_tokens if reqs else 8192,
                "latency_p95_ms_slo": reqs.latency_p95_ms_slo if reqs else None,
                "streaming": reqs.streaming if reqs else False,
                "embedding_dim": reqs.embedding_dim if reqs else None,
            } if reqs else None,
        ))

    # Build grid cells from audit data
    audit_log = get_inference_audit_log()
    stats = audit_log.get_purpose_provider_stats(tenant_id=tenant_id or None)

    grid: dict[str, dict[str, dict[str, Any]]] = {}
    for row in rows:
        purpose_str = row.purpose
        purpose_stats = stats.get(purpose_str, {})
        grid[purpose_str] = {}
        for col in columns:
            provider_stats = purpose_stats.get(col.provider_id, {})
            pricing = col.pricing
            # Compute cost per M tokens from pricing or audit data
            cost_per_m = 0.0
            if pricing.get("input_per_1k_usd") and pricing.get("output_per_1k_usd"):
                try:
                    cost_per_m = (
                        float(pricing["input_per_1k_usd"]) + float(pricing["output_per_1k_usd"])
                    ) / 2.0 * 1000.0  # average of input+output per 1k, scaled to per M
                except (ValueError, TypeError):
                    cost_per_m = 0.0

            cell = AuditGridCell(
                cost_per_m_tokens=round(cost_per_m, 4),
                latency_p50_ms=round(provider_stats.get("latency_p50_ms", 0.0), 1),
                latency_p95_ms=round(provider_stats.get("latency_p95_ms", 0.0), 1),
                jurisdiction=_PROVIDER_JURISDICTION.get(col.provider_id, ""),
                call_count=provider_stats.get("call_count", 0),
                total_cost_usd=round(provider_stats.get("total_cost_usd", 0.0), 6),
                total_tokens=provider_stats.get("total_tokens", 0),
            )
            grid[purpose_str][col.provider_id] = cell.model_dump()

    return {
        "rows": [r.model_dump() for r in rows],
        "columns": [c.model_dump() for c in columns],
        "grid": grid,
        "generated_at": datetime.now(UTC).isoformat(),
    }


@router.get("/audit-grid", response_model=AuditGridResponse)
async def get_audit_grid(
    tenant_id: str = Query("", description="Optional tenant ID to scope cost/latency data"),
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    resolver: AdminInferenceResolver = Depends(_get_resolver),
    store: AdminInferenceStore = Depends(_get_store),
) -> dict[str, Any]:
    """Return per-Purpose x per-provider cost/quality/latency audit grid.

    Rows = Purpose enum values.
    Columns = enabled providers from the platform catalog.
    Cells = cost_per_m_tokens, latency_p50/p95, jurisdiction, call_count.
    Optional tenant_id filter scopes audit data to that tenant.
    """
    return build_audit_grid(resolver=resolver, tenant_id=tenant_id)


@router.put("/audit-default")
async def set_audit_default(
    body: AuditDefaultSetRequest,
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_WRITE)),
    store: AdminInferenceStore = Depends(_get_store),
) -> dict[str, Any]:
    """Set the default provider/model for a specific purpose.

    Validates that the provider exists, is enabled, and the model is in the
    allowlist before persisting. Emits an audit event for the change.
    """
    from apps.backend.services.inference.purposes import Purpose

    # Validate purpose
    try:
        p = Purpose(body.purpose)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Unknown purpose: {body.purpose}",
        )

    # Validate provider exists and is enabled
    try:
        provider_config = store.get_provider(body.provider)
    except ProviderNotFoundError:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Provider {body.provider!r} is not configured.",
        )
    except AdminInferenceStoreError as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=safe_error_detail(exc),
        )

    if not provider_config.get("enabled", False):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Provider {body.provider!r} is currently disabled.",
        )

    # Validate model is allowed
    if not store.is_model_allowed(body.provider, body.model):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Model {body.model!r} is not in the allowlist for provider {body.provider!r}.",
        )

    store.set_platform_default_model(
        purpose=p.value,
        provider=body.provider,
        model=body.model,
    )

    logger.info(
        "admin_inference.set_audit_default purpose=%s provider=%s model=%s founder=%s",
        p.value, body.provider, body.model, _perm.actor_id,
    )

    _append_audit(
        store,
        actor=_perm.actor_id,
        action="inference.default.changed",
        target=f"{p.value}/{body.provider}/{body.model}",
        details={
            "purpose": p.value,
            "provider": body.provider,
            "model": body.model,
        },
    )

    return {
        "status": "updated",
        "purpose": p.value,
        "provider": body.provider,
        "model": body.model,
    }


# ============================================================================
# Provider performance audit API (Issue #3215 — audit dashboard endpoint)
# ============================================================================


import uuid as _uuid


class AuditPerformanceResponse(BaseModel):
    providers: list[dict[str, Any]] = Field(default_factory=list)
    decision_trace_id: str = ""
    query_context: dict[str, Any] = Field(default_factory=dict)
    generated_at: str = ""


@router.get("/audit/performance", response_model=AuditPerformanceResponse)
async def get_audit_performance(
    tenant_id: str = Query("", description="Optional tenant ID to scope audit data"),
    purpose: str = Query("", description="Optional purpose filter"),
    _perm: AdminPermissionCheck = Depends(require_admin_permission_dep(AdminPermission.INFERENCE_READ)),
    store: AdminInferenceStore = Depends(_get_store),
) -> dict[str, Any]:
    """Return per-provider performance metrics for the audit dashboard.

    Per-provider: total calls, avg latency, error rate, cost (last 24h).
    Per-Purpose x per-tenant breakdown.
    Emits a Decision Trace event on each query.
    """
    from datetime import UTC, datetime

    from apps.backend.services.inference.inference_audit import get_inference_audit_log

    audit_log = get_inference_audit_log()
    trace_id = f"audit-perf-{_uuid.uuid4().hex[:12]}"

    stats = audit_log.get_provider_performance_stats(
        tenant_id=tenant_id or None,
        purpose=purpose or None,
    )

    query_context: dict[str, Any] = {}
    if tenant_id:
        query_context["tenant_id"] = tenant_id
    if purpose:
        query_context["purpose"] = purpose

    # Emit Decision Trace via audit store
    _append_audit(
        store,
        actor=_perm.actor_id,
        action="inference.audit_performance_query",
        target="platform",
        details={
            "decision_trace_id": trace_id,
            "query_context": query_context,
            "provider_count": len(stats),
            "permission": _perm.permission.value,
        },
    )

    return {
        "providers": stats,
        "decision_trace_id": trace_id,
        "query_context": query_context,
        "generated_at": datetime.now(UTC).isoformat(),
    }
