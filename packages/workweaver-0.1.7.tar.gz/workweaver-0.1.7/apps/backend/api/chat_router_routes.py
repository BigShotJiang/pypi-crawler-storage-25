"""``/api/v1/chat/route`` and ``/api/v1/chat/rollback/{decision_id}`` —
REST surface over :class:`ChatRouterService`.

Backend half of IMPLEMENTATION_LOG slices 9 + 11. Wires the chat router
primitives that landed in slice 1.1 into a callable REST endpoint:

- ``POST /api/v1/chat/route`` — classify a message + return the
  ``ChatRouterDecision`` envelope.
- ``POST /api/v1/chat/rollback/{decision_id}`` — reverse all card
  placements created by a ``KNOWLEDGE_WORK`` plan within the 5-minute
  ``undo_token`` validity window.

The route handler layer is intentionally thin: validation + dependency
extraction + service dispatch. Heavy logic lives in
:mod:`apps.backend.services.chat_router.router_service` and
:mod:`apps.backend.services.zara.plan_rollback_service`.
"""

from __future__ import annotations

import logging
from datetime import datetime, timedelta
from typing import Any

from fastapi import APIRouter, Depends
from pydantic import BaseModel, ConfigDict, Field

from apps.backend.api.dependencies.tenant_auth import get_verified_tenant_id
from apps.backend.services.chat_router.contract import (
    CardLifecycleState,
    ChatRouterDecision,
    ChatScope,
    ChatScopeType,
    ScopeInferredFrom,
    WorkspaceContext,
)
from apps.backend.services.chat_router.router_service import (
    RouteRequest,
    get_chat_router_service,
)

logger = logging.getLogger(__name__)


router = APIRouter(prefix="/api/v1/chat", tags=["chat-router"])


# ---------------------------------------------------------------------------
# Wire models
# ---------------------------------------------------------------------------


class WorkspaceContextPayload(BaseModel):
    """Wire shape for the :class:`WorkspaceContext` snapshot.

    Strict subset of the contract type — datetime fields are accepted as
    ISO 8601 strings or naive datetimes and normalised to UTC server-side.
    """

    model_config = ConfigDict(extra="forbid")

    currently_open_card_id: str | None = None
    currently_open_goal_id: str | None = None
    recently_viewed_card_ids: list[str] = Field(default_factory=list)
    active_card_states: dict[str, str] = Field(default_factory=dict)
    visible_calendar_window: tuple[datetime, datetime] | None = None
    open_card_iframe_section: str | None = None


class PriorScopePayload(BaseModel):
    """Wire shape for the optional ``prior_scope`` carryover hint."""

    model_config = ConfigDict(extra="forbid")

    type: str
    id: str | None = None
    name: str | None = None
    confidence: float = Field(ge=0.0, le=1.0)
    rationale: str = ""


class ChatRouteRequest(BaseModel):
    """Body for ``POST /api/v1/chat/route``."""

    model_config = ConfigDict(extra="forbid")

    message: str = Field(
        ...,
        min_length=1,
        max_length=4000,
        description="Raw user message text. Will be safety-checked before any LLM call.",
    )
    thread_id: str = Field(
        ...,
        min_length=1,
        max_length=256,
        description="Conversation thread identifier (durable across messages).",
    )
    workspace_context: WorkspaceContextPayload = Field(
        default_factory=WorkspaceContextPayload,
        description="Snapshot of what the user is looking at right now.",
    )
    expected_state_hash: str | None = Field(
        default=None,
        max_length=128,
        description=(
            "For EXECUTE_NOW: hash of the target card's state at classification "
            "time. The executor rejects + re-routes if the card mutated since."
        ),
    )
    prior_scope: PriorScopePayload | None = Field(
        default=None,
        description="Optional scope carryover hint for short / pronominal turns.",
    )


class ChatRouteResponse(BaseModel):
    """Wire envelope for the router decision.

    Mirrors :class:`ChatRouterDecision` 1:1 with action fields flattened
    so consumers don't have to walk three levels of polymorphism.
    """

    model_config = ConfigDict(extra="forbid")

    intent: str
    scope: dict[str, Any]
    confidence: float
    rationale: str
    suggested_action: dict[str, Any]
    classified_at: str
    classifier_version: str
    latency_ms: int
    message_id: str
    thread_id: str
    tenant_id: str
    undo_token: str | None = None
    undo_expires_at: str | None = None


class ChatRollbackResponse(BaseModel):
    """Wire envelope for ``POST /api/v1/chat/rollback/{decision_id}``."""

    model_config = ConfigDict(extra="forbid")

    decision_id: str
    rolled_back_card_ids: list[str]
    rolled_back_count: int
    status: str   # "ok" / "expired" / "not_found" / "not_knowledge_work"
    message: str


# ---------------------------------------------------------------------------
# Route handlers
# ---------------------------------------------------------------------------


@router.post("/route", response_model=ChatRouteResponse)
async def route_chat_message(
    body: ChatRouteRequest,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ChatRouteResponse:
    """Classify a chat message + return the router decision envelope.

    Latency targets:
      - p95 ≤ 600 ms for the rule-based path
      - p95 ≤ 600 ms / hard ceiling 2.5 s when LLM augmentation runs

    See CHAT_ROUTER_CONTRACT.md § 7.
    """
    workspace_context = _to_workspace_context(body.workspace_context)
    prior_scope = _to_prior_scope(body.prior_scope)

    service = get_chat_router_service()
    decision = await service.route(
        RouteRequest(
            message=body.message,
            thread_id=body.thread_id,
            tenant_id=tenant_id,
            workspace_context=workspace_context,
            expected_state_hash=body.expected_state_hash,
            prior_scope=prior_scope,
        )
    )

    return _envelope_from_decision(decision)


@router.post(
    "/rollback/{decision_id}",
    response_model=ChatRollbackResponse,
)
async def rollback_chat_decision(
    decision_id: str,
    tenant_id: str = Depends(get_verified_tenant_id),
) -> ChatRollbackResponse:
    """Reverse all card placements created by a ``KNOWLEDGE_WORK`` decision.

    Rollback is only valid within the 5-minute ``undo_token`` window
    (CHAT_ROUTER_CONTRACT § 6, § 9). After that the call fails-closed
    with ``status='expired'``.

    Returns:
        :class:`ChatRollbackResponse` describing what was rolled back. The
        HTTP status is always 200; failure modes (expired, not found,
        wrong intent) surface in ``status``.
    """
    # Lazy import — the rollback service has heavier dependencies (ledger,
    # decision capture) and we don't want to pull them in on every import.
    from apps.backend.services.zara.plan_rollback_service import (
        get_plan_rollback_service,
    )

    rollback_service = get_plan_rollback_service()
    result = await rollback_service.rollback(
        decision_id=decision_id,
        tenant_id=tenant_id,
        actor="user",
    )

    return ChatRollbackResponse(
        decision_id=decision_id,
        rolled_back_card_ids=result.rolled_back_card_ids,
        rolled_back_count=len(result.rolled_back_card_ids),
        status=result.status,
        message=result.message,
    )


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _to_workspace_context(
    payload: WorkspaceContextPayload,
) -> WorkspaceContext:
    """Convert the wire payload to the strong-typed contract model."""
    active_card_states: dict[str, CardLifecycleState] = {}
    for card_id, state_str in payload.active_card_states.items():
        try:
            active_card_states[card_id] = CardLifecycleState(state_str)
        except ValueError:
            logger.warning(
                "ignoring unknown card lifecycle state %r for card %s",
                state_str,
                card_id,
            )

    return WorkspaceContext(
        currently_open_card_id=payload.currently_open_card_id,
        currently_open_goal_id=payload.currently_open_goal_id,
        recently_viewed_card_ids=list(payload.recently_viewed_card_ids),
        active_card_states=active_card_states,
        visible_calendar_window=payload.visible_calendar_window,
        open_card_iframe_section=payload.open_card_iframe_section
        if payload.open_card_iframe_section
        in ("plan", "connectors", "files", "decision_trace", "memories")
        else None,
    )


def _to_prior_scope(payload: PriorScopePayload | None) -> ChatScope | None:
    if payload is None:
        return None
    try:
        scope_type = ChatScopeType(payload.type)
    except ValueError:
        return None
    if scope_type in {
        ChatScopeType.GOAL,
        ChatScopeType.CARD,
        ChatScopeType.TOOL,
        ChatScopeType.SKILL,
    } and not payload.id:
        # Insufficient information; treat as no prior scope.
        return None
    return ChatScope(
        type=scope_type,
        id=payload.id,
        name=payload.name,
        confidence=payload.confidence,
        rationale=payload.rationale or "prior scope from caller",
        inferred_from=ScopeInferredFrom.HISTORY_CARRYOVER,
    )


def _envelope_from_decision(decision: ChatRouterDecision) -> ChatRouteResponse:
    suggested_action: dict[str, Any] = {}
    undo_token: str | None = None
    undo_expires_at: str | None = None
    if decision.suggested_action.knowledge_work is not None:
        kw = decision.suggested_action.knowledge_work
        suggested_action["knowledge_work"] = {
            "goal_text": kw.goal_text,
            "starting_from": kw.starting_from.isoformat(),
            "priority": kw.priority,
            "horizon_days": kw.horizon_days,
            "force_capacity": kw.force_capacity,
            "undo_token": kw.undo_token,
        }
        undo_token = kw.undo_token
        expires = decision.classified_at + timedelta(minutes=5)
        undo_expires_at = expires.isoformat()
    if decision.suggested_action.status_query is not None:
        sq = decision.suggested_action.status_query
        suggested_action["status_query"] = {
            "question": sq.question,
            "include_decision_trace": sq.include_decision_trace,
        }
    if decision.suggested_action.execute_now is not None:
        ex = decision.suggested_action.execute_now
        suggested_action["execute_now"] = {
            "card_id": ex.card_id,
            "card_state": ex.card_state.value,
            "steer": ex.steer,
            "expected_state_hash": ex.expected_state_hash,
            "undo_token": ex.undo_token,
            "pre_execution_hold_seconds": ex.pre_execution_hold_seconds,
        }
        undo_token = ex.undo_token
        expires = decision.classified_at + timedelta(seconds=60)
        undo_expires_at = expires.isoformat()
    if decision.suggested_action.generic_chat is not None:
        gc = decision.suggested_action.generic_chat
        suggested_action["generic_chat"] = {
            "message": gc.message,
            "enable_web_search": gc.enable_web_search,
            "enable_memory_recall": gc.enable_memory_recall,
        }
    if decision.suggested_action.ambiguity is not None:
        amb = decision.suggested_action.ambiguity
        suggested_action["ambiguity"] = {
            "fallback_question": amb.fallback_question,
            "candidate_scopes": [
                {
                    "type": s.type.value,
                    "id": s.id,
                    "name": s.name,
                    "confidence": s.confidence,
                }
                for s in amb.candidate_scopes
            ],
            "candidate_intents": [i.value for i in amb.candidate_intents],
            "safety_concern": amb.safety_concern,
        }

    scope_envelope = {
        "type": decision.scope.type.value,
        "id": decision.scope.id,
        "name": decision.scope.name,
        "confidence": decision.scope.confidence,
        "rationale": decision.scope.rationale,
        "inferred_from": decision.scope.inferred_from.value,
    }

    return ChatRouteResponse(
        intent=decision.intent.value,
        scope=scope_envelope,
        confidence=decision.confidence,
        rationale=decision.rationale,
        suggested_action=suggested_action,
        classified_at=decision.classified_at.isoformat(),
        classifier_version=decision.classifier_version,
        latency_ms=decision.latency_ms,
        message_id=decision.message_id,
        thread_id=decision.thread_id,
        tenant_id=decision.tenant_id,
        undo_token=undo_token,
        undo_expires_at=undo_expires_at,
    )


__all__ = ["router"]
