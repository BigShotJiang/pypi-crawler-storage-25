"""Enum types for Workweaver backend."""
