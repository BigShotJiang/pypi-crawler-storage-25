"""Skill type enumerations for Workweaver.

This module defines the different types of skills that can be created
in the Skills-First AI Platform.
"""
from enum import Enum


class SkillType(str, Enum):
    """Enumeration of possible skill types.

    Skill types determine how a skill is invoked and what components it requires.

    Types:
        - voice: Voice-based skill (phone calls, audio interactions)
        - chat: Chat-based skill (text messaging, WhatsApp, SMS)
        - scheduled: Scheduled execution skill (cron jobs, timed tasks)
        - api: REST API-based skill (HTTP endpoints, webhooks)
        - mcp: MCP tool-based skill (Model Context Protocol tools)
    """
    VOICE = "voice"
    CHAT = "chat"
    SCHEDULED = "scheduled"
    API = "api"
    MCP = "mcp"


class SkillStatus(str, Enum):
    """Enumeration of skill lifecycle status.

    Status values:
        - active: Skill is live and available for execution
        - draft: Skill is under development, not production-ready
        - deprecated: Skill is outdated, will be removed in future
    """
    ACTIVE = "active"
    DRAFT = "draft"
    DEPRECATED = "deprecated"


class Vertical(str, Enum):
    """Enumeration of supported business verticals.

    Verticals represent different industries or business domains.
    """
    REAL_ESTATE = "real-estate"
    HEALTHCARE = "healthcare"
    LEGAL = "legal"
    GENERAL = "general"


class RoleCategory(str, Enum):
    """Enumeration of skill role categories.

    Role categories group skills by their functional role in the organization.
    """
    RECEPTIONIST = "receptionist"
    SALES = "sales"
    SUPPORT = "support"
    ANALYST = "analyst"
    COORDINATOR = "coordinator"
    AUTOMATION = "automation"


class TriggerType(str, Enum):
    """Enumeration of skill trigger types.

    Triggers determine how a skill is invoked.
    """
    EVENT_PHONE = "event:phone"
    EVENT_WHATSAPP = "event:whatsapp"
    EVENT_SMS = "event:sms"
    EVENT_WEBHOOK = "event:webhook"
    MANUAL = "manual"
    SCHEDULED = "scheduled"
    API = "api"


class CompensationStrategy(str, Enum):
    """Enumeration of compensation strategies for reversible actions.

    Strategies:
        - compensating_action: Execute a separate action to undo the original
        - rollback: Restore state to previous snapshot (state machine rollback)
        - none: Action is irreversible or no compensation is defined
    """
    COMPENSATING_ACTION = "compensating_action"
    ROLLBACK = "rollback"
    NONE = "none"


class VisibilityScope(str, Enum):
    """Enumeration of skill visibility scopes.

    Scopes determine where a skill is available.
    """
    TENANT = "tenant"
    TEAM = "team"
    GLOBAL = "global"
    PRIVATE = "private"
