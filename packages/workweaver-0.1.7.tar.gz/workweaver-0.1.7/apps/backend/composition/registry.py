"""Preset and extension registry for composition manifests."""

from __future__ import annotations

from dataclasses import dataclass


COMPOSITION_SCHEMA_VERSION = "workweaver.composition.v0"
WORKWEAVER_MANIFEST_VERSION = "1"


@dataclass(frozen=True, slots=True)
class CompositionExtensionDefinition:
    """Canonical metadata for one composable extension id."""

    id: str
    display_name: str
    version: str = WORKWEAVER_MANIFEST_VERSION
    required_dependencies: tuple[str, ...] = ()
    description: str = ""


@dataclass(frozen=True, slots=True)
class CompositionPreset:
    """Named preset that expands to a canonical extension set."""

    id: str
    description: str
    extension_ids: tuple[str, ...]


DEFAULT_EXTENSION_REGISTRY: dict[str, CompositionExtensionDefinition] = {
    "workmemory": CompositionExtensionDefinition(
        id="workmemory",
        display_name="WorkMemory",
        description="Durable memory substrate.",
    ),
    "evidence-ledger": CompositionExtensionDefinition(
        id="evidence-ledger",
        display_name="Evidence Ledger",
        required_dependencies=("workmemory",),
        description="Evidence and provenance layer.",
    ),
    "ontology": CompositionExtensionDefinition(
        id="ontology",
        display_name="Ontology",
        required_dependencies=("evidence-ledger",),
        description="Primitive ontology and read-model layer.",
    ),
    "connectors": CompositionExtensionDefinition(
        id="connectors",
        display_name="Connectors",
        description="Tenant connector composition layer.",
    ),
    "zara": CompositionExtensionDefinition(
        id="zara",
        display_name="Zara",
        required_dependencies=("workmemory",),
        description="Main orchestration surface.",
    ),
    "calendar": CompositionExtensionDefinition(
        id="calendar",
        display_name="Calendar",
        description="Calendar and routine surface.",
    ),
    "self-learning": CompositionExtensionDefinition(
        id="self-learning",
        display_name="Self Learning",
        required_dependencies=("workmemory",),
        description="Long-running learning and adaptation surface.",
    ),
    "revenue-pack": CompositionExtensionDefinition(
        id="revenue-pack",
        display_name="Revenue Pack",
        required_dependencies=("connectors",),
        description="Revenue workflow extension pack.",
    ),
    "developer": CompositionExtensionDefinition(
        id="developer",
        display_name="Developer",
        required_dependencies=("computer-controller",),
        description="Developer harness extension surface.",
    ),
    "computer-controller": CompositionExtensionDefinition(
        id="computer-controller",
        display_name="Computer Controller",
        description="Desktop control extension surface.",
    ),
    "mcp-server": CompositionExtensionDefinition(
        id="mcp-server",
        display_name="MCP Server",
        description="MCP transport exposure surface.",
    ),
}


DEFAULT_PRESET_REGISTRY: dict[str, CompositionPreset] = {
    "base": CompositionPreset(
        id="base",
        description="Minimal runtime with no optional extensions.",
        extension_ids=(),
    ),
    "developer-cli": CompositionPreset(
        id="developer-cli",
        description="Base runtime plus developer, computer-controller, and MCP exposure.",
        extension_ids=("developer", "computer-controller", "mcp-server"),
    ),
    "founder-complete": CompositionPreset(
        id="founder-complete",
        description="WorkMemory plus evidence, ontology, connectors, Zara, calendar, and self-learning.",
        extension_ids=("workmemory", "evidence-ledger", "ontology", "connectors", "zara", "calendar", "self-learning"),
    ),
    "sales-pack": CompositionPreset(
        id="sales-pack",
        description="WorkMemory plus connectors and revenue-pack.",
        extension_ids=("workmemory", "connectors", "revenue-pack"),
    ),
}


def known_extension_ids(registry: dict[str, CompositionExtensionDefinition] | None = None) -> tuple[str, ...]:
    source = registry or DEFAULT_EXTENSION_REGISTRY
    return tuple(source.keys())


def known_preset_ids(registry: dict[str, CompositionPreset] | None = None) -> tuple[str, ...]:
    source = registry or DEFAULT_PRESET_REGISTRY
    return tuple(source.keys())


__all__ = [
    "COMPOSITION_SCHEMA_VERSION",
    "CompositionExtensionDefinition",
    "CompositionPreset",
    "DEFAULT_EXTENSION_REGISTRY",
    "DEFAULT_PRESET_REGISTRY",
    "WORKWEAVER_MANIFEST_VERSION",
    "known_extension_ids",
    "known_preset_ids",
]
