"""Composition-facing capability parity manifest.

The canonical capability registry is the source of truth for which operator
capability rows expose backend, MCP, and UI surfaces. This module gives runtime
and audit callers a typed view over that registry instead of making each caller
parse generated projection files independently.
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_PARITY_REGISTRY = REPO_ROOT / "apps" / "cli" / "parity.json"
DEFAULT_CAPABILITY_REGISTRY = REPO_ROOT / "docs" / "reference" / "runtime" / "capabilities.registry.yaml"
REQUIRED_PARITY_SURFACES = ("backend", "mcp", "ui")
_SLUG_RE = re.compile(r"[^a-z0-9]+")


def _slug(value: str) -> str:
    slug = _SLUG_RE.sub("_", value.strip().lower()).strip("_")
    return slug or "unknown"


def _issue_to_int(value: Any) -> int | None:
    if isinstance(value, int) and value > 0:
        return value
    if isinstance(value, str):
        cleaned = value.strip().lstrip("#")
        if cleaned.isdigit():
            return int(cleaned)
    return None


@dataclass(frozen=True, slots=True)
class CapabilitySurfaceSet:
    """Surface pointers for one capability row."""

    backend: str | None = None
    mcp: str | None = None
    ui: str | None = None

    def has(self, surface: str) -> bool:
        return bool(getattr(self, surface))

    def missing(self, required: tuple[str, ...] = REQUIRED_PARITY_SURFACES) -> tuple[str, ...]:
        return tuple(surface for surface in required if not self.has(surface))


@dataclass(frozen=True, slots=True)
class CapabilityParityRow:
    """One machine-checkable capability-to-surface mapping."""

    capability_id: str
    family: str
    action: str
    description: str
    owner: str | None
    surfaces: CapabilitySurfaceSet
    missing_surface_issues: dict[str, int] = field(default_factory=dict)
    parity_exemption_reason: str | None = None

    @property
    def cli_command(self) -> str:
        return f"ww {self.family} {self.action}".strip()

    @property
    def canonical_mcp_tool(self) -> str:
        return self.surfaces.mcp or f"ww.{_slug(self.family)}.{_slug(self.action)}"

    def unresolved_surfaces(self, required: tuple[str, ...] = REQUIRED_PARITY_SURFACES) -> tuple[str, ...]:
        if self.parity_exemption_reason:
            return ()
        missing = []
        for surface in self.surfaces.missing(required):
            if surface not in self.missing_surface_issues:
                missing.append(surface)
        return tuple(missing)


@dataclass(frozen=True, slots=True)
class CapabilityParityManifest:
    """Typed registry view keyed by capability id."""

    rows: tuple[CapabilityParityRow, ...]
    source_path: Path

    def by_id(self) -> dict[str, CapabilityParityRow]:
        return {row.capability_id: row for row in self.rows}

    def find(self, capability_id: str) -> CapabilityParityRow:
        rows = self.by_id()
        if capability_id not in rows:
            raise KeyError(capability_id)
        return rows[capability_id]

    def backend_route_index(self) -> dict[str, CapabilityParityRow]:
        return {row.surfaces.backend: row for row in self.rows if row.surfaces.backend}


def _load_from_capability_registry(path: Path) -> CapabilityParityManifest:
    from apps.backend.services.capability_registry import load_capability_registry

    registry = load_capability_registry(path)
    rows = tuple(
        CapabilityParityRow(
            capability_id=row.capability_id,
            family=row.family,
            action=row.action,
            description=row.description,
            owner=row.owner,
            surfaces=CapabilitySurfaceSet(
                backend=row.surfaces.get("api"),
                mcp=row.surfaces.get("mcp"),
                ui=row.surfaces.get("dashboard"),
            ),
            missing_surface_issues={
                str(surface): issue
                for surface, raw_issue in row.missing_surfaces.items()
                if (issue := _issue_to_int(raw_issue)) is not None
            },
            parity_exemption_reason=row.parity.get("parity_exemption_reason"),
        )
        for row in registry.rows
    )
    return CapabilityParityManifest(rows=rows, source_path=path)


def _load_from_parity_json(path: Path) -> CapabilityParityManifest:
    registry = json.loads(path.read_text(encoding="utf-8"))
    rows: list[CapabilityParityRow] = []
    for family_entry in registry.get("families", []):
        if not isinstance(family_entry, dict):
            continue
        family = str(family_entry.get("family") or "").strip()
        if not family:
            continue
        description = str(family_entry.get("description") or "").strip()
        for subcommand in family_entry.get("subcommands", []):
            if not isinstance(subcommand, dict):
                continue
            action = str(subcommand.get("name") or "").strip()
            if not action:
                continue
            missing_surface_issues = {
                str(surface): issue
                for surface, raw_issue in (subcommand.get("missing_surface_issues") or {}).items()
                if (issue := _issue_to_int(raw_issue)) is not None
            }
            rows.append(
                CapabilityParityRow(
                    capability_id=f"{_slug(family)}.{_slug(action)}",
                    family=family,
                    action=action,
                    description=description,
                    owner=subcommand.get("owner"),
                    surfaces=CapabilitySurfaceSet(
                        backend=subcommand.get("backend"),
                        mcp=subcommand.get("mcp"),
                        ui=subcommand.get("ui"),
                    ),
                    missing_surface_issues=missing_surface_issues,
                    parity_exemption_reason=subcommand.get("parity_exemption_reason"),
                )
            )
    return CapabilityParityManifest(rows=tuple(rows), source_path=path)


def load_capability_parity_manifest(path: Path | None = None) -> CapabilityParityManifest:
    """Load typed capability parity rows.

    Defaults to the canonical capability registry. Passing ``apps/cli/parity.json``
    remains supported for tests and compatibility callers that intentionally want
    to inspect the generated projection.
    """

    source_path = path or DEFAULT_CAPABILITY_REGISTRY
    if source_path.suffix == ".json":
        return _load_from_parity_json(source_path)
    return _load_from_capability_registry(source_path)


__all__ = [
    "CapabilityParityManifest",
    "CapabilityParityRow",
    "CapabilitySurfaceSet",
    "DEFAULT_CAPABILITY_REGISTRY",
    "DEFAULT_PARITY_REGISTRY",
    "REQUIRED_PARITY_SURFACES",
    "load_capability_parity_manifest",
]
