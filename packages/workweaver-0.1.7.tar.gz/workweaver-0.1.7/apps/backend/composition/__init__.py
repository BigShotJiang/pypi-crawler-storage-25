"""Composition manifest contract surface."""

from .loader import (
    CompositionExtension,
    CompositionHarness,
    CompositionManifest,
    CompositionManifestError,
    explain_composition_manifest,
    load_composition_manifest,
    parse_composition_manifest,
)
from .capability_manifest import (
    CapabilityParityManifest,
    CapabilityParityRow,
    CapabilitySurfaceSet,
    load_capability_parity_manifest,
)
from .registry import (
    COMPOSITION_SCHEMA_VERSION,
    DEFAULT_EXTENSION_REGISTRY,
    DEFAULT_PRESET_REGISTRY,
    WORKWEAVER_MANIFEST_VERSION,
    CompositionExtensionDefinition,
    CompositionPreset,
)

__all__ = [
    "COMPOSITION_SCHEMA_VERSION",
    "CapabilityParityManifest",
    "CapabilityParityRow",
    "CapabilitySurfaceSet",
    "CompositionExtension",
    "CompositionExtensionDefinition",
    "CompositionHarness",
    "CompositionManifest",
    "CompositionManifestError",
    "CompositionPreset",
    "DEFAULT_EXTENSION_REGISTRY",
    "DEFAULT_PRESET_REGISTRY",
    "WORKWEAVER_MANIFEST_VERSION",
    "explain_composition_manifest",
    "load_capability_parity_manifest",
    "load_composition_manifest",
    "parse_composition_manifest",
]
