"""Composition manifest parser, loader, and validator."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Mapping

try:
    import tomllib
except ModuleNotFoundError:  # pragma: no cover - py<3.11 fallback not used in CI
    tomllib = None  # type: ignore[assignment]

from .registry import (
    COMPOSITION_SCHEMA_VERSION,
    DEFAULT_EXTENSION_REGISTRY,
    DEFAULT_PRESET_REGISTRY,
    WORKWEAVER_MANIFEST_VERSION,
    CompositionExtensionDefinition,
    CompositionPreset,
)


class CompositionManifestError(ValueError):
    """Raised when a composition manifest is malformed or inconsistent."""


@dataclass(frozen=True, slots=True)
class CompositionExtension:
    """One extension entry declared by a composition manifest."""

    id: str
    version: str
    enabled: bool = True
    config: dict[str, Any] = field(default_factory=dict)
    source: str = "explicit"

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "id": self.id,
            "version": self.version,
            "enabled": self.enabled,
            "config": dict(self.config),
            "source": self.source,
        }
        return {key: value for key, value in payload.items() if value not in (None, {}, [])}


@dataclass(frozen=True, slots=True)
class CompositionHarness:
    """Optional harness transport hints."""

    cli: tuple[str, ...] = ()
    mcp: tuple[str, ...] = ()

    def to_dict(self) -> dict[str, Any]:
        payload = {"cli": list(self.cli), "mcp": list(self.mcp)}
        return {key: value for key, value in payload.items() if value}


@dataclass(frozen=True, slots=True)
class CompositionManifest:
    """Normalized composition manifest."""

    schema_version: str
    profile: str | None
    extensions: tuple[CompositionExtension, ...]
    harness: CompositionHarness = field(default_factory=CompositionHarness)
    source_path: str | None = None

    def extension_ids(self) -> tuple[str, ...]:
        return tuple(extension.id for extension in self.extensions if extension.enabled)

    def disabled_extension_ids(self) -> tuple[str, ...]:
        return tuple(extension.id for extension in self.extensions if not extension.enabled)

    def to_dict(self) -> dict[str, Any]:
        payload = {
            "schema_version": self.schema_version,
            "profile": self.profile,
            "extensions": [extension.to_dict() for extension in self.extensions],
            "harness": self.harness.to_dict(),
            "source_path": self.source_path,
        }
        return {key: value for key, value in payload.items() if value not in (None, {}, [])}


def load_composition_manifest(
    path: Path | str,
    *,
    extension_registry: Mapping[str, CompositionExtensionDefinition] | None = None,
    preset_registry: Mapping[str, CompositionPreset] | None = None,
) -> CompositionManifest:
    manifest_path = Path(path).expanduser()
    if not manifest_path.exists():
        raise FileNotFoundError(manifest_path)
    raw = _load_toml(manifest_path)
    return parse_composition_manifest(
        raw,
        source_path=str(manifest_path),
        extension_registry=extension_registry,
        preset_registry=preset_registry,
    )


def parse_composition_manifest(
    raw: Any,
    *,
    source_path: str | None = None,
    extension_registry: Mapping[str, CompositionExtensionDefinition] | None = None,
    preset_registry: Mapping[str, CompositionPreset] | None = None,
) -> CompositionManifest:
    if not isinstance(raw, dict):
        raise CompositionManifestError("composition manifest must be an object")

    extension_registry = dict(extension_registry or DEFAULT_EXTENSION_REGISTRY)
    preset_registry = dict(preset_registry or DEFAULT_PRESET_REGISTRY)

    workweaver = raw.get("workweaver") or {}
    if not isinstance(workweaver, dict):
        raise CompositionManifestError("[workweaver] must be an object")

    schema_version = str(workweaver.get("version") or "").strip()
    if schema_version != WORKWEAVER_MANIFEST_VERSION:
        raise CompositionManifestError(
            f"invalid workweaver.version {schema_version!r}; expected {WORKWEAVER_MANIFEST_VERSION!r}"
        )

    profile = _normalize_profile(workweaver, preset_registry)
    preset_extension_ids = _expand_preset(profile, preset_registry)

    harness = _parse_harness(raw.get("harness"))
    declared_extensions = _parse_extensions(raw.get("extensions"), extension_registry)

    all_extensions = _merge_extensions(
        preset_extension_ids=preset_extension_ids,
        declared_extensions=declared_extensions,
        extension_registry=extension_registry,
    )

    return CompositionManifest(
        schema_version=COMPOSITION_SCHEMA_VERSION,
        profile=profile,
        extensions=tuple(all_extensions),
        harness=harness,
        source_path=source_path,
    )


def explain_composition_manifest(manifest: CompositionManifest) -> dict[str, Any]:
    enabled = [extension.id for extension in manifest.extensions if extension.enabled]
    disabled = [extension.id for extension in manifest.extensions if not extension.enabled]
    return {
        "schema_version": manifest.schema_version,
        "profile": manifest.profile,
        "enabled_extensions": enabled,
        "disabled_extensions": disabled,
        "harness": manifest.harness.to_dict(),
        "source_path": manifest.source_path,
    }


def _load_toml(path: Path) -> dict[str, Any]:
    if tomllib is None:
        raise RuntimeError("tomllib is unavailable")
    with path.open("rb") as fh:
        return tomllib.load(fh)


def _normalize_profile(
    workweaver: Mapping[str, Any],
    preset_registry: Mapping[str, CompositionPreset],
) -> str | None:
    profile = str(workweaver.get("profile") or workweaver.get("preset") or "").strip()
    if not profile:
        return None
    if workweaver.get("profile") and workweaver.get("preset"):
        profile_name = str(workweaver.get("profile") or "").strip()
        preset_name = str(workweaver.get("preset") or "").strip()
        if profile_name != preset_name:
            raise CompositionManifestError(
                f"workweaver.profile {profile_name!r} does not match workweaver.preset {preset_name!r}"
            )
    if profile not in preset_registry:
        raise CompositionManifestError(
            f"unknown composition preset {profile!r}; known presets: {', '.join(preset_registry)}"
        )
    return profile


def _expand_preset(
    profile: str | None,
    preset_registry: Mapping[str, CompositionPreset],
) -> list[CompositionExtension]:
    if profile is None:
        return []
    preset = preset_registry.get(profile)
    if preset is None:
        raise CompositionManifestError(f"unknown composition preset {profile!r}")
    extension_ids: list[CompositionExtension] = []
    for extension_id in preset.extension_ids:
        extension_ids.append(
            CompositionExtension(
                id=extension_id,
                version=WORKWEAVER_MANIFEST_VERSION,
                enabled=True,
                config={},
                source="preset",
            )
        )
    return extension_ids


def _parse_harness(raw: Any) -> CompositionHarness:
    if raw in (None, ""):
        return CompositionHarness()
    if not isinstance(raw, dict):
        raise CompositionManifestError("harness must be an object")
    cli = _validate_string_list(raw.get("cli"), field_name="harness.cli")
    mcp = _validate_string_list(raw.get("mcp"), field_name="harness.mcp")
    for cli_value in cli:
        if cli_value != "ww":
            raise CompositionManifestError("harness.cli only supports 'ww' in v0")
    for transport in mcp:
        if transport not in {"stdio", "http"}:
            raise CompositionManifestError("harness.mcp only supports 'stdio' and 'http' in v0")
    return CompositionHarness(cli=cli, mcp=mcp)


def _parse_extensions(
    raw: Any,
    extension_registry: Mapping[str, CompositionExtensionDefinition],
) -> list[CompositionExtension]:
    if raw in (None, ""):
        return []
    if not isinstance(raw, dict):
        raise CompositionManifestError("extensions must be an object")

    parsed: list[CompositionExtension] = []
    for extension_id, payload in raw.items():
        normalized_id = str(extension_id).strip()
        if not normalized_id:
            raise CompositionManifestError("extension ids must be non-empty")
        definition = extension_registry.get(normalized_id)
        if definition is None:
            raise CompositionManifestError(
                f"unknown extension id {normalized_id!r}; known extensions: {', '.join(extension_registry)}"
            )
        if payload in (None, ""):
            payload = {}
        if not isinstance(payload, dict):
            raise CompositionManifestError(f"extension {normalized_id!r} must be an object")
        version = str(payload.get("version") or definition.version).strip()
        if version != definition.version:
            raise CompositionManifestError(
                f"extension {normalized_id!r} has unsupported version {version!r}; expected {definition.version!r}"
            )
        enabled = payload.get("enabled", True)
        if not isinstance(enabled, bool):
            raise CompositionManifestError(f"extension {normalized_id!r}.enabled must be a boolean")
        config = payload.get("config") or {}
        if not isinstance(config, dict):
            raise CompositionManifestError(f"extension {normalized_id!r}.config must be an object")
        parsed.append(
            CompositionExtension(
                id=normalized_id,
                version=version,
                enabled=enabled,
                config=dict(config),
                source="explicit",
            )
        )
    return parsed


def _merge_extensions(
    *,
    preset_extension_ids: list[CompositionExtension],
    declared_extensions: list[CompositionExtension],
    extension_registry: Mapping[str, CompositionExtensionDefinition],
) -> list[CompositionExtension]:
    merged: list[CompositionExtension] = []
    seen: set[str] = set()

    for extension in [*preset_extension_ids, *declared_extensions]:
        if extension.id in seen:
            raise CompositionManifestError(f"duplicate extension id {extension.id!r}")
        seen.add(extension.id)
        merged.append(extension)

    merged_ids = set(seen)
    for extension in merged:
        definition = extension_registry.get(extension.id)
        if definition is None:
            raise CompositionManifestError(f"unknown extension id {extension.id!r}")
        missing = [dependency for dependency in definition.required_dependencies if dependency not in merged_ids]
        if missing:
            raise CompositionManifestError(
                f"extension {extension.id!r} requires missing dependencies: {', '.join(missing)}"
            )
    return merged


def _validate_string_list(raw: Any, *, field_name: str) -> tuple[str, ...]:
    if raw in (None, ""):
        return ()
    if not isinstance(raw, list):
        raise CompositionManifestError(f"{field_name} must be an array")
    values = tuple(str(item).strip() for item in raw if str(item).strip())
    return values


__all__ = [
    "CompositionExtension",
    "CompositionHarness",
    "CompositionManifest",
    "CompositionManifestError",
    "explain_composition_manifest",
    "load_composition_manifest",
    "parse_composition_manifest",
]
