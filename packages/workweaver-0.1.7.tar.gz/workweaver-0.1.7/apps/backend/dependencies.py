"""Public dependency facade for the Workweaver FastAPI backend.

The import contract stays here: callers should continue importing
``apps.backend.dependencies``. The implementation is split into grouped
modules under ``apps.backend.dependency_factories`` to keep the surface
operable without changing any endpoint or service wiring.
"""

from __future__ import annotations

from typing import Any

from apps.backend.dependency_factories.agents import (
    get_agent_profile_store,
    get_approval_gates,
    get_hire_employee_service,
    get_lead_scorer,
    get_unified_skill_registry,
)
from apps.backend.dependency_factories.business import (
    get_audit_logger,
    get_payment_event_resource_store,
    get_email_threading_service,
    get_evidence_ledger_service,
    get_memory_service,
    get_metering_service,
    get_mission_contracts_service,
    get_thread_service,
    get_usage_tracker,
)
from apps.backend.dependency_factories.config import (
    load_auth_identity_contract,
)
from apps.backend.dependency_factories.connectors import (
    get_connector_policy_broker,
    get_connector_sdk,
    get_marketplace,
)
from apps.backend.dependency_factories.core import (
    get_degradation_notifier,
    get_event_bus,
    get_telemetry_policy,
    get_tenants_table,
)
from apps.backend.dependency_factories.cowork import (
    get_clarification_protocol,
    get_customer_context_store,
    get_employee_context_store,
    get_employee_learning_loop,
    get_session_continuity_service,
    get_skill_guidance_store,
)
from apps.backend.dependency_factories.intelligence import (
    get_batch_orchestrator,
    get_developmental_intelligence_service,
    get_intelligence_aggregator,
    get_proactive_intelligence_engine,
    get_skill_selector,
    get_workweaver_runtime_provisioning_service,
)
from apps.backend.dependency_factories.learning import (
    get_calendar_service,
    get_cross_loop_compounding_service,
    get_developer_loop_service,
    get_learning_loop_service,
)
from apps.backend.dependency_factories.notifications import (
    get_compensation_service,
    get_notification_service,
)
from apps.backend.dependency_factories.runtime import (
    get_agent_instance_manager,
    get_connector_executor,
)
from apps.backend.dependency_factories.skills import (
    get_repo_skill_catalog_service,
)
from apps.backend.dependency_factories.standalone import (
    get_async_scheduler,
    get_company_graph,
    get_metric_registry,
    get_online_eval_service,
    get_regulated_action_rails,
    get_zara_goal_intake,
)
from apps.backend.dependency_factories.stores import (
    get_meeting_session_store,
    get_mission_node_store,
    get_role_store,
    get_schedule_store,
    get_task_store,
    get_whatsapp_message_store,
)
from apps.backend.dependency_factories.tenant import (
    get_stripe_checkout_service,
    get_subscription_manager,
    get_tenant_provisioning_service,
)
from apps.backend.dependency_factories.trace import (
    get_action_discovery_service,
    get_capability_manifest_service,
    get_checkpoint_service,
    get_drift_detection_service,
    get_domain_provisioner,
    get_domain_provisioning_handler,
    get_goal_cascade_service,
    get_human_override_service,
    get_inference_trace_store,
    get_strategy_miner,
    get_strategy_retriever,
    get_strategy_store,
    get_time_rollup_service,
)


def get_tenant_improvement_service() -> Any:
    """Return a TenantImprovementService wired to the public evidence getter."""
    from apps.backend.services.tenant_improvement_loop import TenantImprovementService

    return TenantImprovementService(evidence_service=get_evidence_ledger_service())


__all__ = [
    "get_action_discovery_service",
    "get_agent_instance_manager",
    "get_agent_profile_store",
    "get_approval_gates",
    "get_async_scheduler",
    "get_audit_logger",
    "get_batch_orchestrator",
    "get_calendar_service",
    "get_capability_manifest_service",
    "get_checkpoint_service",
    "get_clarification_protocol",
    "get_company_graph",
    "get_compensation_service",
    "get_connector_executor",
    "get_connector_policy_broker",
    "get_connector_sdk",
    "get_payment_event_resource_store",
    "get_cross_loop_compounding_service",
    "get_customer_context_store",
    "get_degradation_notifier",
    "get_developer_loop_service",
    "get_developmental_intelligence_service",
    "get_drift_detection_service",
    "get_domain_provisioner",
    "get_domain_provisioning_handler",
    "get_email_threading_service",
    "get_employee_context_store",
    "get_employee_learning_loop",
    "get_evidence_ledger_service",
    "get_event_bus",
    "get_goal_cascade_service",
    "get_hire_employee_service",
    "get_human_override_service",
    "get_inference_trace_store",
    "get_intelligence_aggregator",
    "get_learning_loop_service",
    "get_lead_scorer",
    "get_marketplace",
    "get_meeting_session_store",
    "get_memory_service",
    "get_metering_service",
    "get_metric_registry",
    "get_mission_contracts_service",
    "get_mission_node_store",
    "get_notification_service",
    "get_online_eval_service",
    "get_proactive_intelligence_engine",
    "get_regulated_action_rails",
    "get_repo_skill_catalog_service",
    "get_role_store",
    "get_schedule_store",
    "get_session_continuity_service",
    "get_skill_guidance_store",
    "get_skill_selector",
    "get_strategy_miner",
    "get_strategy_retriever",
    "get_strategy_store",
    "get_stripe_checkout_service",
    "get_subscription_manager",
    "get_task_store",
    "get_telemetry_policy",
    "get_tenant_improvement_service",
    "get_tenant_provisioning_service",
    "get_tenants_table",
    "get_thread_service",
    "get_time_rollup_service",
    "get_unified_skill_registry",
    "get_usage_tracker",
    "get_whatsapp_message_store",
    "get_workweaver_runtime_provisioning_service",
    "get_zara_goal_intake",
    "load_auth_identity_contract",
]
