"""Compatibility wrapper for the canonical backend app and Lambda handler.

Historically this module built a second FastAPI shell with a divergent
middleware stack and partially duplicated routes. The canonical API app now
lives in ``apps.backend.main``; this module re-exports that app for legacy
entrypoints that still import ``lambda_handler`` directly.
"""

from __future__ import annotations

try:  # pragma: no cover - fallback is for direct module execution contexts
    from apps.backend.main import app, lambda_handler
except ImportError:  # pragma: no cover
    from main import app, lambda_handler  # type: ignore[no-redef]


__all__ = ["app", "lambda_handler"]
