"""Canonical LLM inference COGS resolver.

This module is the sole runtime authority for per-model LLM COGS resolution.
Everything else in billing and founder-admin should project from this contract
instead of carrying parallel LLM pricing logic.

Structure: ``{(provider, model_id): {"input_per_1k": Decimal,
"output_per_1k": Decimal}}`` where costs are USD per 1,000 tokens.
"""

from __future__ import annotations

from dataclasses import dataclass
from decimal import Decimal
from typing import Literal

from apps.backend.services.inference.service import (
    DEFAULT_GROQ_MODEL_SPEC,
    DEFAULT_DEEPSEEK_MODEL_SPEC,
    DEFAULT_MISTRAL_MODEL_SPEC,
    DEFAULT_FIREWORKS_MODEL_SPEC,
    PLAYGROUND_MODEL_GROK_FAST,
)

# Default blended rate when provider/model is unknown.
# Matches the existing ``cogs_usd`` in ``billable_meter_registry.py`` for
# ``llm_inference_tokens_in`` and ``llm_inference_tokens_out``.
DEFAULT_LLM_COST: dict[str, Decimal] = {
    "input_per_1k": Decimal("0.003"),
    "output_per_1k": Decimal("0.003"),
}

# Provider-aware COGS lookup table.
# Key: (provider_name_lowercase, model_id)
# Value: dict with ``input_per_1k`` and ``output_per_1k`` as Decimal USD.
LLM_PROVIDER_COSTS: dict[tuple[str, str], dict[str, Decimal]] = {
    # Bedrock — Moonshot Kimi K2.5
    ("bedrock", "moonshotai.kimi-k2.5"): {
        "input_per_1k": Decimal("0.00072"),
        "output_per_1k": Decimal("0.00360"),
    },
    # xAI — Grok 4.1 Fast
    ("grok", PLAYGROUND_MODEL_GROK_FAST): {
        "input_per_1k": Decimal("0.002"),
        "output_per_1k": Decimal("0.008"),
    },
    # Bedrock — Anthropic Claude Sonnet 4.6
    ("bedrock", "anthropic.claude-sonnet-4-6"): {
        "input_per_1k": Decimal("0.003"),
        "output_per_1k": Decimal("0.015"),
    },
    # OpenAI — GPT-5.4
    ("openai", "gpt-5.4"): {
        "input_per_1k": Decimal("0.0025"),
        "output_per_1k": Decimal("0.015"),
    },
    # OpenAI — GPT-5.4 Mini
    ("openai", "gpt-5.4-mini"): {
        "input_per_1k": Decimal("0.00075"),
        "output_per_1k": Decimal("0.0045"),
    },
    # Anthropic direct API — Claude Opus 4.7
    ("anthropic", "claude-opus-4-7"): {
        "input_per_1k": Decimal("0.015"),
        "output_per_1k": Decimal("0.075"),
    },
    # Anthropic direct API — Claude Sonnet 4.6
    ("anthropic", "claude-sonnet-4-6"): {
        "input_per_1k": Decimal("0.003"),
        "output_per_1k": Decimal("0.015"),
    },
    # Google AI — Gemini 3.1 Pro Preview
    ("google_ai", "gemini-3.1-pro-preview"): {
        "input_per_1k": Decimal("0.002"),
        "output_per_1k": Decimal("0.012"),
    },
    # Google AI — Gemini 3.1 Flash-Lite Preview
    ("google_ai", "gemini-3.1-flash-lite-preview"): {
        "input_per_1k": Decimal("0.00025"),
        "output_per_1k": Decimal("0.0015"),
    },
    # Google AI — Gemini 2.5 Pro
    ("google_ai", "gemini-2.5-pro"): {
        "input_per_1k": Decimal("0.00125"),
        "output_per_1k": Decimal("0.010"),
    },
    # Google AI — Gemini 2.5 Flash
    ("google_ai", "gemini-2.5-flash"): {
        "input_per_1k": Decimal("0.00030"),
        "output_per_1k": Decimal("0.00250"),
    },
    # Bedrock — Amazon Nova 2 Lite
    ("bedrock", "us.amazon.nova-2-lite-v1:0"): {
        "input_per_1k": Decimal("0.0008"),
        "output_per_1k": Decimal("0.0032"),
    },
    # Bedrock — Amazon Nova Lite
    ("bedrock", "amazon.nova-lite-v1:0"): {
        "input_per_1k": Decimal("0.00006"),
        "output_per_1k": Decimal("0.00024"),
    },
    # Groq hosted open models
    ("groq", DEFAULT_GROQ_MODEL_SPEC): {
        "input_per_1k": Decimal("0.00059"),
        "output_per_1k": Decimal("0.00079"),
    },
    # DeepSeek direct API (cache-miss pricing for canonical COGS)
    ("deepseek", DEFAULT_DEEPSEEK_MODEL_SPEC): {
        "input_per_1k": Decimal("0.00027"),
        "output_per_1k": Decimal("0.00110"),
    },
    ("deepseek", "deepseek-reasoner"): {
        "input_per_1k": Decimal("0.00055"),
        "output_per_1k": Decimal("0.00219"),
    },
    # Mistral direct API
    ("mistral", DEFAULT_MISTRAL_MODEL_SPEC): {
        "input_per_1k": Decimal("0.00050"),
        "output_per_1k": Decimal("0.00150"),
    },
    ("mistral", "codestral-latest"): {
        "input_per_1k": Decimal("0.00030"),
        "output_per_1k": Decimal("0.00090"),
    },
    ("mistral", "mistral-small-latest"): {
        "input_per_1k": Decimal("0.00015"),
        "output_per_1k": Decimal("0.00060"),
    },
    # Together hosted model rate card
    ("together_ai", "meta-llama/llama-4-maverick-17b-128e-instruct-fp8"): {
        "input_per_1k": Decimal("0.00027"),
        "output_per_1k": Decimal("0.00085"),
    },
    # Fireworks hosted model rate card
    ("fireworks", DEFAULT_FIREWORKS_MODEL_SPEC): {
        "input_per_1k": Decimal("0.00022"),
        "output_per_1k": Decimal("0.00088"),
    },
    # OpenCode-Zen (US-hosted Kimi access, Issue #3197)
    ("opencode_zen", "kimi-k2.5"): {
        "input_per_1k": Decimal("0.00060"),
        "output_per_1k": Decimal("0.00300"),
    },
    ("opencode_zen", "kimi-k2.6"): {
        "input_per_1k": Decimal("0.00080"),
        "output_per_1k": Decimal("0.00400"),
    },
}

_PROVIDER_COST_ALIASES = {
    "openai_api": "openai",
    "azure_openai": "openai",
    "vertex_ai": "google_ai",
}

_MODEL_COST_ALIASES = {
    ("anthropic", "claude-opus-4-1-20250805"): "claude-opus-4-7",
    ("anthropic", "claude-sonnet-4-20250514"): "claude-sonnet-4-6",
    ("anthropic", "claude-opus-4.7"): "claude-opus-4-7",
    ("anthropic", "claude-sonnet-4.6"): "claude-sonnet-4-6",
    ("together_ai", "meta-llama/llama-4-maverick-17b-128e-instruct-turbo"): (
        "meta-llama/llama-4-maverick-17b-128e-instruct-fp8"
    ),
}

_DIRECT_MODEL_RATE_PROVIDERS = {
    "openai",
    "anthropic",
    "google_ai",
    "deepseek",
    "mistral",
    "grok",
}

_GATEWAY_RATE_PROVIDERS = {
    "bedrock",
    "groq",
    "together_ai",
    "fireworks",
    "opencode_zen",
}

_UNDERLYING_MODEL_RATE_GATEWAYS = {
    "openrouter": {
        "openai": "openai",
        "anthropic": "anthropic",
        "google": "google_ai",
    },
    "vercel_inference": {
        "openai": "openai",
        "anthropic": "anthropic",
        "google": "google_ai",
    },
}

_FALLBACK_NOTES = {
    "opencode_zen": (
        "Fallback blended rate. The Z.AI coding PaaS surface does not yet have a"
        " canonical public per-token rate in this contract."
    ),
}

_CACHE_RATE_FACTORS: dict[tuple[str, str], tuple[Decimal, Decimal]] = {
    ("anthropic", "claude-opus-4-7"): (Decimal("0.10"), Decimal("1.25")),
    ("anthropic", "claude-sonnet-4-6"): (Decimal("0.10"), Decimal("1.25")),
    ("bedrock", "anthropic.claude-sonnet-4-6"): (Decimal("0.10"), Decimal("1.25")),
}

PricingRateSource = Literal[
    "direct_model_rate",
    "gateway_rate",
    "underlying_model_rate",
    "fallback_blended_rate",
]


@dataclass(frozen=True)
class ResolvedLLMProviderCost:
    """Resolved COGS plus provenance for a provider/model pair."""

    requested_provider: str
    requested_model: str
    normalized_provider: str
    normalized_model: str
    pricing_provider: str
    pricing_model: str
    input_per_1k: Decimal
    output_per_1k: Decimal
    known: bool
    rate_source: PricingRateSource
    notes: str
    underlying_provider: str | None = None
    underlying_model: str | None = None
    cache_read_per_1k: Decimal | None = None
    cache_write_per_1k: Decimal | None = None

    @property
    def cost(self) -> dict[str, Decimal]:
        return {
            "input_per_1k": self.input_per_1k,
            "output_per_1k": self.output_per_1k,
        }


def _build_resolved_cost(
    *,
    requested_provider: str,
    requested_model: str,
    normalized_provider: str,
    normalized_model: str,
    pricing_provider: str,
    pricing_model: str,
    input_per_1k: Decimal,
    output_per_1k: Decimal,
    known: bool,
    rate_source: PricingRateSource,
    notes: str,
    underlying_provider: str | None = None,
    underlying_model: str | None = None,
    cache_read_per_1k: Decimal | None = None,
    cache_write_per_1k: Decimal | None = None,
) -> ResolvedLLMProviderCost:
    return ResolvedLLMProviderCost(
        requested_provider=requested_provider,
        requested_model=requested_model,
        normalized_provider=normalized_provider,
        normalized_model=normalized_model,
        pricing_provider=pricing_provider,
        pricing_model=pricing_model,
        input_per_1k=input_per_1k,
        output_per_1k=output_per_1k,
        cache_read_per_1k=cache_read_per_1k,
        cache_write_per_1k=cache_write_per_1k,
        known=known,
        rate_source=rate_source,
        notes=notes,
        underlying_provider=underlying_provider,
        underlying_model=underlying_model,
    )


def _direct_rate_source(provider: str) -> PricingRateSource:
    if provider in _GATEWAY_RATE_PROVIDERS:
        return "gateway_rate"
    return "direct_model_rate"


def _source_note(rate_source: PricingRateSource, provider: str, pricing_provider: str) -> str:
    if rate_source == "underlying_model_rate":
        if provider == "openrouter":
            return "OpenRouter passes through the underlying provider price without markup."
        if provider == "vercel_inference":
            return "Vercel AI Gateway currently applies no added gateway fee beyond the provider list price."
        return "Gateway pricing resolves to the underlying model rate."
    if rate_source == "gateway_rate":
        return f"{pricing_provider} hosted-model rate card."
    if rate_source == "direct_model_rate":
        return f"{pricing_provider} direct model list price."
    return _FALLBACK_NOTES.get(
        provider,
        "Fallback blended rate. This provider/model still needs an explicit canonical mapping.",
    )


def _cache_rate_quote(
    pricing_provider: str,
    pricing_model: str,
    input_per_1k: Decimal,
) -> tuple[Decimal | None, Decimal | None]:
    factors = _CACHE_RATE_FACTORS.get((pricing_provider, pricing_model))
    if factors is None:
        return (None, None)
    cache_read_factor, cache_write_factor = factors
    return (input_per_1k * cache_read_factor, input_per_1k * cache_write_factor)


def normalize_pricing_provider(provider: str) -> str:
    normalized = provider.lower().strip()
    return _PROVIDER_COST_ALIASES.get(normalized, normalized)


def _strip_reasoning_suffix(model: str) -> str:
    return str(model or "").strip().split("@", 1)[0].strip()


def _strip_vendor_prefix_for_provider(provider: str, model: str) -> str:
    normalized_model = _strip_reasoning_suffix(model)
    if "/" not in normalized_model:
        return normalized_model
    vendor, _, vendor_model = normalized_model.partition("/")
    vendor = vendor.strip().lower()
    provider = normalize_pricing_provider(provider)
    if provider == "google_ai" and vendor in {"google", "vertex"}:
        return vendor_model.strip()
    return normalized_model


def normalize_pricing_model(provider: str, model: str) -> str:
    normalized_provider = normalize_pricing_provider(provider)
    normalized_model = _strip_vendor_prefix_for_provider(normalized_provider, model).strip().lower()
    return _MODEL_COST_ALIASES.get((normalized_provider, normalized_model), normalized_model)


def _lookup_direct_cost(provider: str, model: str) -> dict[str, Decimal] | None:
    return LLM_PROVIDER_COSTS.get((provider, model))


def _resolve_underlying_cost(provider: str, model: str) -> ResolvedLLMProviderCost | None:
    vendor_map = _UNDERLYING_MODEL_RATE_GATEWAYS.get(provider)
    if not vendor_map or "/" not in model:
        return None
    vendor, _, vendor_model = model.partition("/")
    underlying_provider = vendor_map.get(vendor.lower().strip())
    if not underlying_provider:
        return None
    underlying_model = normalize_pricing_model(underlying_provider, vendor_model)
    cost = _lookup_direct_cost(underlying_provider, underlying_model)
    if cost is None:
        return None
    cache_read_per_1k, cache_write_per_1k = _cache_rate_quote(
        underlying_provider,
        underlying_model,
        cost["input_per_1k"],
    )
    return _build_resolved_cost(
        requested_provider=provider,
        requested_model=model,
        normalized_provider=provider,
        normalized_model=model,
        pricing_provider=underlying_provider,
        pricing_model=underlying_model,
        input_per_1k=cost["input_per_1k"],
        output_per_1k=cost["output_per_1k"],
        known=True,
        rate_source="underlying_model_rate",
        notes=_source_note("underlying_model_rate", provider, underlying_provider),
        underlying_provider=underlying_provider,
        underlying_model=underlying_model,
        cache_read_per_1k=cache_read_per_1k,
        cache_write_per_1k=cache_write_per_1k,
    )


def resolve_llm_pricing(provider: str, model: str) -> ResolvedLLMProviderCost:
    """Resolve canonical COGS plus pricing provenance for a provider/model pair."""
    normalized_provider = normalize_pricing_provider(provider)
    normalized_model = normalize_pricing_model(normalized_provider, model)
    direct_cost = _lookup_direct_cost(normalized_provider, normalized_model)
    if direct_cost is not None:
        rate_source = _direct_rate_source(normalized_provider)
        cache_read_per_1k, cache_write_per_1k = _cache_rate_quote(
            normalized_provider,
            normalized_model,
            direct_cost["input_per_1k"],
        )
        return _build_resolved_cost(
            requested_provider=str(provider or ""),
            requested_model=str(model or ""),
            normalized_provider=normalized_provider,
            normalized_model=normalized_model,
            pricing_provider=normalized_provider,
            pricing_model=normalized_model,
            input_per_1k=direct_cost["input_per_1k"],
            output_per_1k=direct_cost["output_per_1k"],
            cache_read_per_1k=cache_read_per_1k,
            cache_write_per_1k=cache_write_per_1k,
            known=True,
            rate_source=rate_source,
            notes=_source_note(rate_source, normalized_provider, normalized_provider),
        )

    underlying = _resolve_underlying_cost(normalized_provider, normalized_model)
    if underlying is not None:
        return underlying

    return _build_resolved_cost(
        requested_provider=str(provider or ""),
        requested_model=str(model or ""),
        normalized_provider=normalized_provider,
        normalized_model=normalized_model,
        pricing_provider=normalized_provider,
        pricing_model=normalized_model,
        input_per_1k=DEFAULT_LLM_COST["input_per_1k"],
        output_per_1k=DEFAULT_LLM_COST["output_per_1k"],
        cache_read_per_1k=None,
        cache_write_per_1k=None,
        known=False,
        rate_source="fallback_blended_rate",
        notes=_source_note("fallback_blended_rate", normalized_provider, normalized_provider),
    )


def get_llm_provider_cost(
    provider: str,
    model: str,
) -> dict[str, Decimal]:
    """Look up COGS for a provider/model pair.

    Args:
        provider: Provider name (e.g. ``"bedrock"``, ``"grok"``).
        model: Model identifier string.

    Returns:
        Dict with ``input_per_1k`` and ``output_per_1k`` Decimal USD values.
        Falls back to ``DEFAULT_LLM_COST`` when the pair is not in the table.
    """
    return resolve_llm_pricing(provider, model).cost


def resolve_llm_provider_cost(
    provider: str,
    model: str,
) -> tuple[dict[str, Decimal], bool]:
    """Look up COGS and report whether the rate is provider-specific truth.

    Returns:
        Tuple of ``(cost, known)`` where ``known`` is True only when the
        provider/model pair matched an explicit entry in ``LLM_PROVIDER_COSTS``.
    """
    resolved = resolve_llm_pricing(provider, model)
    return resolved.cost, resolved.known
