"""Admin host routing helpers (issue #1167, #3274).

The backend routes ``admin.workweaver.ai`` traffic to the admin SPA shell while
serving ``app.workweaver.ai`` / ``api.workweaver.ai`` traffic to the tenant
dashboard and API. That routing key — the Host / X-Forwarded-Host header — is
fragile: CloudFront/ALB pass-through quirks, port suffixes, ``www.`` aliases,
and comma-separated forwarded chains have all caused silent 404s on deep
links such as ``/admin/tenants/{id}`` in the past.

This module owns the canonical matcher so the same rule is testable in unit
tests without booting the full FastAPI app.

Issue #3274: host validation delegates to the PlatformAllowlist registry via
``admin_host_is_allowed`` with kind ADMIN_HOST. These entries are immutable —
rotated at deploy time only, never tenant-editable.
"""

from __future__ import annotations

from typing import Iterable

# Canonical admin hostnames. ``www.admin.`` exists because older email links
# and bookmarks that pre-date the shortened hostname still resolve.
# Kept for backward compat and export; actual enforcement delegates to
# PlatformAllowlist via admin_host_is_allowed().
ADMIN_HOSTS: frozenset[str] = frozenset(
    {
        "admin.workweaver.ai",
        "www.admin.workweaver.ai",
    }
)


def _normalize_host(value: str | None) -> str:
    """Strip port, whitespace, trailing dot, and lowercase a Host header value.

    Accepts ``None`` / empty strings (returns ``""``) so callers don't need to
    guard themselves; returns the leading hostname only when a comma-separated
    forwarded chain is supplied (``CloudFront, ALB`` style). Trailing dots
    are stripped so ``admin.workweaver.ai.`` (the absolute-FQDN form some
    clients emit) normalises to ``admin.workweaver.ai``.
    """
    if not value:
        return ""
    first = value.split(",", 1)[0]
    host_only = first.split(":", 1)[0]
    return host_only.strip().rstrip(".").lower()


# Host-header values that mean "this request was terminated by an internal
# proxy/load-balancer — the real public hostname lives in X-Forwarded-Host."
# Everything else is treated as a concrete public Host that MUST NOT be
# overridden by X-Forwarded-Host — otherwise a malicious caller against
# ``app.workweaver.ai`` could pass ``X-Forwarded-Host: admin.workweaver.ai``
# and receive the admin CSP/XFO headers (Codex #1167 follow-up).
_INTERNAL_PROXY_HOST_SUFFIXES: tuple[str, ...] = (
    ".elb.amazonaws.com",
    ".elbaws.com",
    ".compute.internal",
    ".compute.amazonaws.com",
    ".execute-api.",  # API Gateway v2: {id}.execute-api.{region}.amazonaws.com (issue #2691)
)
_INTERNAL_PROXY_HOST_EXACT: frozenset[str] = frozenset(
    {
        "localhost",
        "127.0.0.1",
        "0.0.0.0",
    }
)


def _is_delegating_host(normalized_host: str) -> bool:
    """True when Host is empty or is a known internal-proxy/loopback host."""
    if not normalized_host:
        return True
    if normalized_host in _INTERNAL_PROXY_HOST_EXACT:
        return True
    # Most suffixes are endswith() checks, but API Gateway v2 domains
    # have the format {id}.execute-api.{region}.amazonaws.com, so we
    # check if ".execute-api." appears anywhere in the hostname.
    for suffix in _INTERNAL_PROXY_HOST_SUFFIXES:
        if suffix == ".execute-api.":
            if ".execute-api." in normalized_host:
                return True
        elif normalized_host.endswith(suffix):
            return True
    return False


def _strip_scheme(value: str | None) -> str:
    """Remove ``https://`` or ``http://`` prefix from a header value."""
    if not value:
        return ""
    for prefix in ("https://", "http://"):
        if value.lower().startswith(prefix):
            return value[len(prefix) :]
    return value


def _host_in_allowlist(host: str, *, custom: frozenset[str] | None = None) -> bool:
    """Check if a normalized host is in the admin allowlist.

    When a custom set is provided (test override), use that directly.
    Otherwise delegate to the PlatformAllowlist registry via
    ``admin_host_is_allowed`` (#3274). The registry is seeded on first call
    with the platform-default ADMIN_HOST entries.
    """
    if custom is not None:
        return host in custom
    # Delegate to PlatformAllowlist registry — seed lazily on first call
    from apps.backend.services.policy.allowlist_adopters import admin_host_is_allowed, seed_admin_host_defaults

    seed_admin_host_defaults()
    return admin_host_is_allowed(host, record_deny=False)


def is_admin_host(
    host_header: str | None,
    forwarded_host_header: str | None = None,
    origin_header: str | None = None,
    allowed: Iterable[str] | None = None,
) -> bool:
    """Return True when the request targets the admin SPA.

    Precedence (Codex round-2 review):

    1. If ``Host`` is a concrete public hostname in the admin allowlist,
       return ``True``. Host-in-allowlist is authoritative.
    2. If ``Host`` is a concrete *non-admin* public hostname (e.g.
       ``app.workweaver.ai``), return ``False`` regardless of the value of
       ``X-Forwarded-Host`` — this closes the header-smuggling vector where
       a caller against the tenant app could inject
       ``X-Forwarded-Host: admin.workweaver.ai`` and get the admin CSP.
    3. If ``Host`` is empty or identifies an internal proxy / loopback
       (CloudFront → ALB pass-through, local dev), trust the first
       ``X-Forwarded-Host`` entry.
    4. **CloudFront + API Gateway fallback:** When behind CloudFront with the
       ``Managed-AllViewerExceptHostHeader`` origin request policy, neither
       ``Host`` nor ``X-Forwarded-Host`` carries the viewer hostname.  In this
       case the ``Origin`` header (which IS forwarded by the managed policy)
       is used as a last resort.  ``Origin`` is only trusted when ``Host``
       is a known delegated proxy, so direct API callers cannot spoof it.

    Both comparisons are port-insensitive, trailing-dot tolerant, and
    case-insensitive.
    """
    custom_allowlist = frozenset(host.lower() for host in allowed) if allowed is not None else None
    raw = _normalize_host(host_header)

    # Diagnostic logging for issue #2691
    try:
        import structlog

        logger = structlog.get_logger("admin_host")
        logger.debug(
            "admin_host_detection",
            host_header=host_header,
            forwarded_host_header=forwarded_host_header,
            origin_header=origin_header,
            normalized_raw=raw,
            using_custom_allowlist=custom_allowlist is not None,
        )
    except Exception:
        pass  # Logging not available

    if raw and _host_in_allowlist(raw, custom=custom_allowlist):
        return True
    # A concrete non-admin public Host wins — don't let X-Forwarded-Host
    # override it.
    if raw and not _is_delegating_host(raw):
        return False
    fwd = _normalize_host(forwarded_host_header)
    if fwd and _host_in_allowlist(fwd, custom=custom_allowlist):
        return True

    # CloudFront + API Gateway: Origin header fallback.
    # Only trust Origin when Host is a known delegated proxy (API Gateway
    # execute-api domain, internal ALB, etc.).  This prevents spoofing from
    # direct API callers who could set any Origin value.
    if raw and _is_delegating_host(raw):
        origin_host = _normalize_host(_strip_scheme(origin_header))
        if origin_host and _host_in_allowlist(origin_host, custom=custom_allowlist):
            return True

    return False


def is_admin_host_request(request) -> bool:
    """FastAPI-friendly wrapper around :func:`is_admin_host`.

    Accepts any object that exposes a ``.headers`` mapping with ``host`` and
    ``x-forwarded-host`` keys (``starlette.requests.Request`` works directly).
    Also passes the ``Origin`` header as a CloudFront + API Gateway fallback.
    """
    headers = getattr(request, "headers", None) or {}
    host = headers.get("host") if hasattr(headers, "get") else None
    fwd = headers.get("x-forwarded-host") if hasattr(headers, "get") else None
    origin = headers.get("origin") if hasattr(headers, "get") else None
    return is_admin_host(host, fwd, origin_header=origin)


# Admin SPA deep-link routes that must continue to resolve on the admin host
# and 404 on any other host. Exported so regression tests can assert the
# full set without duplicating literals.
ADMIN_SPA_ROUTES: tuple[str, ...] = (
    "/admin",
    "/admin/inference",
    "/admin/meeting",
    "/admin/tenants",
    "/admin/tenants/{tenant_id}",
    "/admin/feature-flags",
    "/admin/audit",
    "/admin/dashboard",
    "/admin/cost",
    "/admin/secrets",
)


__all__ = [
    "ADMIN_HOSTS",
    "ADMIN_SPA_ROUTES",
    "is_admin_host",
    "is_admin_host_request",
]
