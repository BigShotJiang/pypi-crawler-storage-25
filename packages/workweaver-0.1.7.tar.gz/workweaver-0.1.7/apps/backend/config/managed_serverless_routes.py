"""Managed SaaS serverless ingress inventory.

This inventory defines the public control-plane and admin route groups that are
canonical on the managed serverless edge. Stateful and realtime paths remain
explicitly excluded until they receive their own runtime migration.
"""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class ManagedServerlessRoute:
    path: str
    methods: tuple[str, ...]
    reason: str


INCLUDED_MANAGED_SERVERLESS_ROUTES: tuple[ManagedServerlessRoute, ...] = (
    ManagedServerlessRoute(
        path="/health",
        methods=("GET", "HEAD", "OPTIONS"),
        reason="Stateless health probe already served through the canonical FastAPI app and Lambda Mangum adapter.",
    ),
    ManagedServerlessRoute(
        path="/",
        methods=("GET", "HEAD", "OPTIONS"),
        reason="Root request handling is part of the canonical backend shell and serves either API metadata or the admin SPA by host header.",
    ),
    ManagedServerlessRoute(
        path="/jwt*",
        methods=("GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"),
        reason="JWT issuance is a stateless control-plane route and belongs on the managed serverless edge.",
    ),
    ManagedServerlessRoute(
        path="/oauth/callback*",
        methods=("GET", "HEAD", "OPTIONS"),
        reason="The unified OAuth callback dispatcher is the canonical public auth callback path.",
    ),
    ManagedServerlessRoute(
        path="/api/v1/*",
        methods=("GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"),
        reason="Canonical API surface. The Lambda runs the full FastAPI app and serves all /api/v1/* routes except the transport and stateful prefixes listed in EXCLUDED_MANAGED_SERVERLESS_ROUTE_PREFIXES.",
    ),
    ManagedServerlessRoute(
        path="/admin*",
        methods=("GET", "HEAD", "OPTIONS"),
        reason="Admin SPA history-mode routes are served by the canonical backend shell when the request host is admin.workweaver.ai.",
    ),
    ManagedServerlessRoute(
        path="/_admin-assets*",
        methods=("GET", "HEAD", "OPTIONS"),
        reason="Admin SPA static assets must stay colocated with the admin shell during the public-edge cutover.",
    ),
    ManagedServerlessRoute(
        path="/api/onboarding*",
        methods=("GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"),
        reason="Tenant onboarding flow is stateless control-plane — start, advance, skip, progress. Required for tenant provisioning to complete and move from provisioning to active state.",
    ),
    ManagedServerlessRoute(
        path="/memory*",
        methods=("GET", "POST", "PUT", "DELETE", "PATCH", "HEAD", "OPTIONS"),
        reason="WorkMemory sub-app is mounted at /memory by the canonical FastAPI app; since the managed Lambda runs the same app via Mangum, /memory/* routes are served through the same handler. Previously /memory was in EXCLUDED because the Lambda was a thin slice; now that it runs the full app, /memory must be explicitly INCLUDED to pass the fail-closed route filter.",
    ),
)


EXCLUDED_MANAGED_SERVERLESS_ROUTE_PREFIXES: tuple[ManagedServerlessRoute, ...] = (
    # NOTE: `/memory/*` is served by the Lambda because the canonical FastAPI app
    # mounts the WorkMemory sub-application at /memory. The earlier exclusion
    # existed when the Lambda was a thin slice; now that it runs the full app,
    # serving /memory through the same Mangum handler is correct and the smoke
    # test /memory/health passes.
    ManagedServerlessRoute(
        path="/api/twilio",
        methods=("ALL",),
        reason="Voice and telephony flows have transport/runtime assumptions that require a separate migration track.",
    ),
    # NOTE: /api/v1/inbox was previously excluded because "inbox send paths depend on
    # Twilio/WhatsApp transport secrets that are only injected on the ECS backend".
    # Since the managed Lambda now hydrates ALL secrets via
    # hydrate_managed_runtime_secret_env (including TWILIO_ACCOUNT_SID,
    # TWILIO_AUTH_TOKEN, TWILIO_API_KEY_SID, TWILIO_API_KEY_SECRET), inbox routes
    # are served by the canonical app on the managed edge without restriction.
    # NOTE: /api/v1/sms and /api/v1/telephony were previously excluded for the same
    # Twilio-credentials reason as inbox. Since hydrate_managed_runtime_secret_env
    # now injects all Twilio secrets, these routes are served by the managed edge.
    ManagedServerlessRoute(
        path="/api/v1/voice",
        methods=("ALL",),
        reason="Realtime and call-control paths are not part of the first stateless serverless cut.",
    ),
    ManagedServerlessRoute(
        path="/ws",
        methods=("ALL",),
        reason="WebSocket and long-lived connection paths require dedicated adapter treatment.",
    ),
)


def is_included_managed_serverless_route(path: str, method: str) -> bool:
    if exclusion_reason_for_path(path):
        return False

    normalized_method = method.upper()
    for route in INCLUDED_MANAGED_SERVERLESS_ROUTES:
        if route.path.endswith("*"):
            # /api/v1/auth/* matches both /api/v1/auth and /api/v1/auth/login
            prefix = route.path[:-1]  # "/api/v1/auth/"
            base = prefix.rstrip("/")  # "/api/v1/auth"
            if not (path.startswith(prefix) or path == base):
                continue
        elif path != route.path:
            continue
        if normalized_method in route.methods:
            return True
    return False


def exclusion_reason_for_path(path: str) -> str | None:
    for route in EXCLUDED_MANAGED_SERVERLESS_ROUTE_PREFIXES:
        if path == route.path or path.startswith(f"{route.path}/"):
            return route.reason
    return None
