"""Deployment-profile-aware table-name resolution.

Every runtime table name should resolve through this module. Production-like
profiles must receive explicit table names from the deployment environment;
local and dev profiles get deterministic ``workweaver-*-dev`` defaults.
"""

from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache

from apps.backend.config.environment import get_environment


class TableNameResolutionError(RuntimeError):
    """Raised when a production-like runtime is missing a required table name."""


@dataclass(frozen=True)
class TableNameSpec:
    """Resolution metadata for one logical table."""

    short_name: str
    env_var: str
    aliases: tuple[str, ...] = ()
    default_short_name: str | None = None

    @property
    def default_stem(self) -> str:
        return self.default_short_name or self.short_name.replace("_", "-")


_SPECS: dict[str, TableNameSpec] = {
    "action_outcomes": TableNameSpec("action_outcomes", "ACTION_OUTCOMES_TABLE"),
    "agent_awareness": TableNameSpec("agent_awareness", "AGENT_AWARENESS_TABLE"),
    "active_sessions": TableNameSpec(
        "active_sessions",
        "ACTIVE_SESSIONS_TABLE",
        default_short_name="active-sessions",
    ),
    "admin_audit": TableNameSpec("admin_audit", "ADMIN_AUDIT_TABLE"),
    "api_keys": TableNameSpec("api_keys", "API_KEYS_TABLE"),
    "approvals": TableNameSpec("approvals", "APPROVALS_TABLE"),
    "audit_log": TableNameSpec("audit_log", "AUDIT_LOG_TABLE"),
    "batch_jobs": TableNameSpec("batch_jobs", "BATCH_JOBS_TABLE"),
    "billing_events": TableNameSpec("billing_events", "BILLING_EVENTS_TABLE"),
    "capability_health_trail": TableNameSpec("capability_health_trail", "CAPABILITY_HEALTH_TRAIL_TABLE"),
    "capability_leases": TableNameSpec("capability_leases", "CAPABILITY_LEASES_TABLE"),
    "change_events": TableNameSpec("change_events", "CHANGE_EVENTS_TABLE"),
    "consent": TableNameSpec("consent", "CONSENT_TABLE"),
    "payment_event_resources": TableNameSpec(
        "payment_event_resources",
        "PAYMENT_EVENT_RESOURCES_TABLE",
    ),
    "decisions": TableNameSpec("decisions", "DECISIONS_TABLE_NAME", aliases=("DECISIONS_TABLE",)),
    "degradation_events": TableNameSpec("degradation_events", "DEGRADATION_EVENTS_TABLE"),
    "feature_flags": TableNameSpec("feature_flags", "FEATURE_FLAGS_TABLE"),
    "identity_links": TableNameSpec("identity_links", "IDENTITY_LINKS_TABLE"),
    "level2_calibration_audit": TableNameSpec("level2_calibration_audit", "LEVEL2_CALIBRATION_AUDIT_TABLE"),
    "interviews": TableNameSpec("interviews", "INTERVIEW_TABLE", default_short_name="interviews"),
    "invites": TableNameSpec("invites", "INVITES_TABLE"),
    "meeting_sessions": TableNameSpec("meeting_sessions", "MEETING_SESSIONS_TABLE"),
    "member_intake_queue": TableNameSpec(
        "member_intake_queue",
        "WORKWEAVER_MEMBER_INTAKE_QUEUE_TABLE",
        default_short_name="member-intake-queue",
    ),
    "memory": TableNameSpec("memory", "MEMORY_TABLE", default_short_name="memory-table"),
    "metric_registry": TableNameSpec("metric_registry", "METRIC_REGISTRY_TABLE_NAME"),
    "mission_contracts": TableNameSpec(
        "mission_contracts",
        "MISSION_CONTRACTS_TABLE",
        aliases=("TENANTS_TABLE",),
        default_short_name="tenants",
    ),
    "mission_run_state": TableNameSpec(
        "mission_run_state",
        "MISSION_RUN_STATE_TABLE",
        aliases=("TENANTS_TABLE",),
        default_short_name="tenants",
    ),
    "ombudsman_audit": TableNameSpec("ombudsman_audit", "OMBUDSMAN_AUDIT_TABLE"),
    "onboarding_states": TableNameSpec("onboarding_states", "ONBOARDING_STATES_TABLE"),
    "orgs": TableNameSpec("orgs", "ORGS_TABLE"),
    "pending_checkouts": TableNameSpec("pending_checkouts", "PENDING_CHECKOUTS_TABLE"),
    "phantom_model_baselines": TableNameSpec("phantom_model_baselines", "PHANTOM_MODEL_BASELINE_TABLE"),
    "policy_update_audit": TableNameSpec("policy_update_audit", "POLICY_UPDATE_AUDIT_TABLE"),
    "precedents": TableNameSpec("precedents", "PRECEDENTS_TABLE_NAME", aliases=("PRECEDENTS_TABLE",)),
    "pricing": TableNameSpec("pricing", "PRICING_TABLE"),
    "primitive_ledger": TableNameSpec("primitive_ledger", "PRIMITIVE_LEDGER_TABLE_NAME"),
    "recording_ingestion_outbox": TableNameSpec("recording_ingestion_outbox", "RECORDING_INGESTION_OUTBOX_TABLE"),
    "runtime_state": TableNameSpec("runtime_state", "DYNAMODB_TABLE", default_short_name="state"),
    "runtime_leases": TableNameSpec(
        "runtime_leases",
        "RUNTIME_LEASES_TABLE",
        default_short_name="runtime-leases",
    ),
    "mission_worker_lease": TableNameSpec(
        "mission_worker_lease",
        "MISSION_WORKER_LEASE_TABLE",
        default_short_name="mission-worker-lease",
    ),
    "schedules": TableNameSpec("schedules", "SCHEDULES_TABLE"),
    "skills": TableNameSpec("skills", "SKILLS_TABLE_NAME", aliases=("SKILLS_TABLE",)),
    "sleep_time_jobs": TableNameSpec(
        "sleep_time_jobs",
        "SLEEP_TIME_JOBS_TABLE",
        default_short_name="sleep-time-jobs",
    ),
    "skill_eval_correlation": TableNameSpec(
        "skill_eval_correlation", "SKILL_EVAL_CORRELATION_TABLE"
    ),
    "skill_marketplace": TableNameSpec(
        "skill_marketplace", "SKILL_MARKETPLACE_TABLE", aliases=("SKILL_MARKETPLACE_TABLE_NAME",)
    ),
    "support": TableNameSpec("support", "SUPPORT_TABLE", aliases=("TENANTS_TABLE",)),
    "suppression": TableNameSpec("suppression", "SUPPRESSION_TABLE"),
    "swarm_capacity": TableNameSpec("swarm_capacity", "SWARM_CAPACITY_TABLE"),
    "swarm_constitutions": TableNameSpec(
        "swarm_constitutions",
        "SWARM_CONSTITUTIONS_TABLE",
        aliases=("TENANTS_TABLE",),
        default_short_name="tenants",
    ),
    "sync_state": TableNameSpec(
        "sync_state",
        "SYNC_STATE_TABLE",
        default_short_name="sync-state",
    ),
    "tasks": TableNameSpec("tasks", "TASKS_TABLE", aliases=("TENANTS_TABLE",), default_short_name="tasks"),
    "tenant_phones": TableNameSpec("tenant_phones", "TENANT_PHONE_TABLE"),
    "tenant_retrospectives": TableNameSpec("tenant_retrospectives", "TENANT_RETROSPECTIVES_TABLE"),
    "tenants": TableNameSpec("tenants", "TENANTS_TABLE"),
    "tickets": TableNameSpec("tickets", "TICKETS_TABLE_NAME"),
    "ticket_messages": TableNameSpec("ticket_messages", "TICKET_MESSAGES_TABLE_NAME"),
    "usage": TableNameSpec("usage", "USAGE_TABLE"),
    "users": TableNameSpec("users", "USERS_TABLE"),
    "verifications": TableNameSpec("verifications", "VERIFICATIONS_TABLE"),
    "waitlist": TableNameSpec("waitlist", "WAITLIST_TABLE_NAME"),
    "whatsapp": TableNameSpec("whatsapp", "WHATSAPP_TABLE_NAME"),
    "workmemory_audit_trail": TableNameSpec("workmemory_audit_trail", "WORKMEMORY_AUDIT_TRAIL_TABLE"),
    "workmemory_billing_api_keys": TableNameSpec("workmemory_billing_api_keys", "WORKMEMORY_BILLING_APIKEYS_TABLE"),
    "workmemory_billing_usage": TableNameSpec("workmemory_billing_usage", "WORKMEMORY_BILLING_USAGE_TABLE"),
    "workmemory_embedding_cost": TableNameSpec("workmemory_embedding_cost", "WORKMEMORY_EMBEDDING_COST_TABLE"),
    "workmemory_improvements": TableNameSpec("workmemory_improvements", "WORKMEMORY_IMPROVEMENTS_TABLE"),
    "work_functions": TableNameSpec("work_functions", "WORK_FUNCTIONS_TABLE", default_short_name="work-functions"),
    # Issue #3542: WorkspacePersonaOverlay (safe SOUL.md analog).
    # Co-tenanted with the canonical TENANTS_TABLE so we inherit the same IAM
    # surface and pagination contract; pk=TENANT#<id>, sk=PERSONA#v1.
    "workspace_persona": TableNameSpec(
        "workspace_persona",
        "WORKSPACE_PERSONA_TABLE",
        aliases=("TENANTS_TABLE",),
        default_short_name="tenants",
    ),
    "workweaver_queue": TableNameSpec("workweaver_queue", "WORKWEAVER_QUEUE_TABLE"),
    "zara_plans": TableNameSpec(
        "zara_plans", "ZARA_PLANS_TABLE", aliases=("TENANTS_TABLE",), default_short_name="tenants"
    ),
    "zoho_lead_queue_dlq": TableNameSpec("zoho_lead_queue_dlq", "ZOHO_LEAD_QUEUE_DLQ_TABLE"),
    "learning_signal_dlq": TableNameSpec("learning_signal_dlq", "LEARNING_SIGNAL_DLQ_TABLE"),
}

_ENV_ALIASES = {
    "": "dev",
    "development": "dev",
    "dev": "dev",
    "local": "dev",
    "test": "dev",
    "prod": "prod",
    "production": "prod",
    "staging": "staging",
    "stage": "staging",
}


def canonical_table_environment(value: str | None = None) -> str:
    """Return the canonical table suffix for an environment value.

    Table-name fallbacks default to ``dev`` rather than ``prod`` because the
    fallback path is exercised by local-native runs and unit tests where no
    explicit ENVIRONMENT is set. Production deployments are required to set
    ENVIRONMENT=prod (or one of the canonical aliases), so this default never
    leaks into a real production runtime. ``get_environment()`` keeps its
    ``prod`` default for runtime-mode checks (auth enforcement, etc.) — table
    naming has the opposite ergonomic: an unset env should land you on the
    safe local ``-dev`` suffix instead of accidentally writing to ``-prod``.
    """

    if value is not None:
        raw = str(value).strip().lower()
    else:
        explicit_env = os.environ.get("ENVIRONMENT") or os.environ.get("WORKWEAVER_ENV")
        if explicit_env and explicit_env.strip():
            raw = str(get_environment()).strip().lower()
        else:
            raw = "dev"
    return _ENV_ALIASES.get(raw, raw or "dev")


def _deployment_profile_value() -> str:
    """Resolve the deployment profile without importing provider packages."""
    explicit = os.environ.get("WORKWEAVER_DEPLOYMENT_PROFILE", "").strip().lower()
    if explicit:
        return explicit
    standalone_profile = os.environ.get("WORKWEAVER_PROFILE", "").strip().lower()
    standalone_flag = os.environ.get("WORKWEAVER_STANDALONE", "").strip().lower()
    if standalone_profile == "standalone" or standalone_flag in {"1", "true", "yes"}:
        return "standalone"
    if os.environ.get("WORKWEAVER_SELF_HOST", "").strip().lower() in {"1", "true", "yes"}:
        return "self_host_production"
    if os.environ.get("ECS_CONTAINER_METADATA_URI"):
        return "managed_saas"
    if os.environ.get("DISABLE_COGNITO", "").strip().lower() in {"1", "true", "yes"}:
        return "local_native"
    return "managed_saas"


def _explicit_production_runtime() -> bool:
    """Return true only when the runtime is explicitly production-like.

    The provider layer defaults to ``managed_saas`` when nothing is configured,
    which is useful for production safety but too aggressive for unit tests and
    ad-hoc local scripts. Table-name fail-fast therefore requires an explicit
    production/self-host signal, not the implicit fallback.
    """

    profile = _deployment_profile_value()
    if profile not in {"managed_saas", "self_host_production"}:
        return False
    return any(
        os.environ.get(name)
        for name in (
            "WORKWEAVER_DEPLOYMENT_PROFILE",
            "WORKWEAVER_SELF_HOST",
            "ECS_CONTAINER_METADATA_URI",
            "AWS_EXECUTION_ENV",
        )
    )


def _env_value(names: tuple[str, ...]) -> tuple[str | None, str | None]:
    for name in names:
        value = str(os.environ.get(name, "")).strip()
        if value:
            return name, value
    return None, None


def get_table_name_spec(short_name: str) -> TableNameSpec:
    """Return resolution metadata for ``short_name``."""

    normalized = short_name.strip().lower().replace("-", "_")
    return _SPECS.get(
        normalized,
        TableNameSpec(
            normalized,
            f"{normalized.upper()}_TABLE",
        ),
    )


def configured_table(
    short_name: str,
    *,
    env_var: str | None = None,
    aliases: tuple[str, ...] = (),
) -> str | None:
    """Return an explicitly configured table name, if present.

    Use this for optional stores where an omitted env var intentionally means
    "stay in memory" rather than "use the local/dev DynamoDB fallback".
    """

    spec = get_table_name_spec(short_name)
    primary = env_var or spec.env_var
    alias_names = aliases or spec.aliases
    _, configured = _env_value((primary, *alias_names))
    return configured


def resolve_table(
    short_name: str,
    *,
    env_var: str | None = None,
    aliases: tuple[str, ...] = (),
    default_short_name: str | None = None,
    required: bool = True,
) -> str:
    """Resolve a logical table name.

    Args:
        short_name: Logical name such as ``tenants`` or ``billing_events``.
        env_var: Optional primary env var override. Prefer registering specs
            above for production paths.
        aliases: Optional fallback env vars. These are checked after the
            primary env var.
        default_short_name: Optional default stem, used for dev/local fallback.
        required: When false, missing production-like env vars return the dev
            fallback. This is only for optional diagnostics, not stateful writes.
    """

    spec = get_table_name_spec(short_name)
    primary = env_var or spec.env_var
    alias_names = aliases or spec.aliases
    used_env, configured = _env_value((primary, *alias_names))
    if configured:
        return configured

    if required and _explicit_production_runtime():
        raise TableNameResolutionError(
            f"{primary} must be configured for table '{spec.short_name}' in {_deployment_profile_value()} profile"
        )

    stem = default_short_name or spec.default_short_name or spec.default_stem
    return f"workweaver-{stem}-{canonical_table_environment()}"


@lru_cache(maxsize=1)
def table_resolution_specs() -> tuple[TableNameSpec, ...]:
    """Expose the registered specs for audits and diagnostics."""

    return tuple(sorted(_SPECS.values(), key=lambda spec: spec.short_name))


def reset_table_name_resolver_cache() -> None:
    """Clear resolver caches used by tests."""

    table_resolution_specs.cache_clear()
