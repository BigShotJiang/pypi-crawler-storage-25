"""Strict sender policy for automated outbound email.

Workweaver automated mail must originate only from monitored Bitfoundry inboxes.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)

ALLOWED_AUTOMATED_SENDERS: frozenset[str] = frozenset(
    {
        "workweaver@bitfoundry.ai",
        "contact@bitfoundry.ai",
    }
)
DEFAULT_AUTOMATED_SENDER = "workweaver@bitfoundry.ai"


def enforce_automated_sender(candidate: str | None, *, source: str = "unknown") -> str:
    """Return an allowed sender address, falling back to default when invalid."""
    normalized = str(candidate or "").strip().lower()
    if normalized in ALLOWED_AUTOMATED_SENDERS:
        return normalized
    if normalized:
        logger.warning(
            "Blocked unsupported automated sender '%s' (source=%s); using '%s'",
            normalized,
            source,
            DEFAULT_AUTOMATED_SENDER,
        )
    return DEFAULT_AUTOMATED_SENDER

