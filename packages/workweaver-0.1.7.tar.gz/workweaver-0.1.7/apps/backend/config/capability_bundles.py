"""Canonical capability bundle registry and parser.

Bundles are controlled by ``WORKWEAVER_BUNDLES`` and default to all-on.
Core is always enabled; ``voice`` and ``workmemory`` are the first optional
bundle boundaries used for startup/router/deploy gating.
"""

from __future__ import annotations

import os
from enum import Enum

from apps.backend.extensions import ExtensionManifest

__all__ = [
    "CapabilityBundle",
    "ALL_CAPABILITY_BUNDLES",
    "bundle_is_enabled",
    "get_enabled_capability_bundles",
    "parse_capability_bundles",
    "require_capability_bundle",
]


class CapabilityBundle(str, Enum):
    """First-class capability bundles exposed through startup wiring."""

    core = "core"
    voice = "voice"
    workmemory = "workmemory"


ALL_CAPABILITY_BUNDLES = frozenset(CapabilityBundle)
CAPABILITY_BUNDLE_EXTENSION_MANIFEST = ExtensionManifest(
    id="workweaver.capability-bundle",
    display_name="Capability Bundle",
    version="1.0.0",
    capability_class="domain",
    modality="domain",
    side_effect_tags=("capability-projection",),
)
_DEFAULT_BUNDLE_CONFIG = "all"
_ENV_VAR_NAME = "WORKWEAVER_BUNDLES"


def _normalize_bundle_token(token: str) -> str:
    return token.strip().lower()


def parse_capability_bundles(raw: str | None) -> frozenset[CapabilityBundle]:
    """Parse a comma-delimited bundle selector.

    ``all`` or a blank value keeps the current all-on behavior.
    ``core`` is always included even if omitted.
    """
    value = _DEFAULT_BUNDLE_CONFIG if raw is None else raw.strip().lower()
    if not value or value == "all":
        return ALL_CAPABILITY_BUNDLES

    tokens = {_normalize_bundle_token(token) for token in value.split(",") if token.strip()}
    if not tokens or "all" in tokens:
        return ALL_CAPABILITY_BUNDLES

    enabled = {CapabilityBundle.core}
    for token in tokens:
        if token == "none":
            continue
        try:
            enabled.add(CapabilityBundle(token))
        except ValueError as exc:
            raise ValueError(
                f"Unsupported capability bundle {token!r}. "
                f"Valid bundles: {sorted(bundle.value for bundle in CapabilityBundle)}"
            ) from exc
    return frozenset(enabled)


def get_enabled_capability_bundles() -> frozenset[CapabilityBundle]:
    """Return the active bundle set from the canonical environment variable."""
    return parse_capability_bundles(os.environ.get(_ENV_VAR_NAME))


def bundle_is_enabled(bundle: CapabilityBundle | str) -> bool:
    """Return True when a bundle is enabled by startup configuration."""
    bundle_name = bundle.value if isinstance(bundle, CapabilityBundle) else _normalize_bundle_token(bundle)
    return CapabilityBundle(bundle_name) in get_enabled_capability_bundles()


def require_capability_bundle(bundle: CapabilityBundle | str):
    """Return a FastAPI dependency that fail-closes disabled bundles with 501."""
    from fastapi import HTTPException, status

    bundle_name = bundle.value if isinstance(bundle, CapabilityBundle) else _normalize_bundle_token(bundle)

    def _dependency() -> None:
        if not bundle_is_enabled(bundle_name):
            raise HTTPException(
                status_code=status.HTTP_501_NOT_IMPLEMENTED,
                detail=f"{bundle_name} bundle is disabled",
            )

    return _dependency
