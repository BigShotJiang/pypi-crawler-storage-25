"""Centralized AWS region configuration.

Single source of truth for the default AWS region used across the backend.
All modules should import DEFAULT_AWS_REGION from here instead of
hardcoding region strings in os.getenv() fallbacks.

To change the deployment region, update:
  1. This file (DEFAULT_AWS_REGION)
  2. infra/terraform/{env}/terraform.tfvars (region = "...")
  3. .env.example (AWS_REGION=...)

The AWS_REGION environment variable always takes precedence at runtime.
"""

import os

# The canonical default region for all AWS resources.
# Environment variable AWS_REGION (or AWS_DEFAULT_REGION) overrides at runtime.
DEFAULT_AWS_REGION = "us-east-1"

# Resolved region: prefer explicit override, then runtime env, then default.
AWS_REGION = (
    os.environ.get("AWS_REGION_OVERRIDE")
    or os.environ.get("AWS_REGION")
    or os.environ.get("AWS_DEFAULT_REGION")
    or DEFAULT_AWS_REGION
)
