"""Canonical environment configuration -- single source of truth.

ALL files that need the current environment MUST import from here.
Never call os.getenv("ENVIRONMENT", ...) directly -- use get_environment().

To add a new environment:
1. Add it to VALID_ENVIRONMENTS
2. Set ENVIRONMENT env var in deployment config
3. Done -- all files automatically pick it up

Current default: "prod" (there is no dev environment in deployment)
Override: set ENVIRONMENT env var to any valid value
"""

from __future__ import annotations

import logging
import os
from enum import Enum
from functools import lru_cache

logger = logging.getLogger(__name__)

# The ONLY place the default is defined
_DEFAULT_ENVIRONMENT = "prod"


class Environment(str, Enum):
    """Valid environment names."""

    PROD = "prod"
    STAGING = "staging"
    DEV = "dev"
    LOCAL = "local"
    TEST = "test"


VALID_ENVIRONMENTS: frozenset[str] = frozenset(e.value for e in Environment)


@lru_cache(maxsize=1)
def get_environment() -> str:
    """Get the current environment. Cached after first call.

    Resolution order:
    1. ENVIRONMENT env var
    2. WORKWEAVER_ENV env var (legacy alias)
    3. Default: "prod"

    Returns lowercase, stripped value.
    """
    raw = (
        os.environ.get("ENVIRONMENT")
        or os.environ.get("WORKWEAVER_ENV")
        or _DEFAULT_ENVIRONMENT
    ).strip().lower()

    if raw not in VALID_ENVIRONMENTS:
        logger.warning(
            "Unknown environment %r -- valid: %s", raw, sorted(VALID_ENVIRONMENTS)
        )

    return raw


def is_production() -> bool:
    """Check if running in production (strict -- excludes staging)."""
    return get_environment() in ("prod", "production")


def is_production_like() -> bool:
    """Check if running in a production-like environment (includes staging)."""
    return get_environment() in ("prod", "production", "staging")


def is_development() -> bool:
    """Check if running in development/local."""
    return get_environment() in ("dev", "local", "development")


def is_test() -> bool:
    """Check if running in test."""
    return get_environment() == "test"


def environment_prefix() -> str:
    """Get environment prefix for resource naming (e.g., 'workweaver-prod-')."""
    return f"workweaver-{get_environment()}-"
