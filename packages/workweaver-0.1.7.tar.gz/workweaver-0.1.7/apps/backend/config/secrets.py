"""
Workweaver Secrets Manager

Centralized secrets loader with environment-aware path resolution.
Follows the environment strategy: /workweaver/{env}/{service}/{key}

Usage:
    from config.secrets import get_secret, get_grok_api_key, get_twilio_account_sid

    api_key = get_grok_api_key()
    account_sid = get_twilio_account_sid()

Portability:
    This module now delegates to ``apps.backend.providers.secret_provider``
    for actual secret resolution.  The public API is unchanged.
"""

import json
import os
import threading
import time
from collections import OrderedDict
from logging import getLogger

logger = getLogger(__name__)

_SECRET_CACHE_DEFAULT_TTL_SECONDS = 300.0
_SECRET_CACHE_MAX_SIZE = 128
_SECRET_CACHE: OrderedDict[tuple[str, str | None], tuple[float, str]] = OrderedDict()
_SECRET_CACHE_LOCK = threading.Lock()
_SECRET_CACHE_STATS = {
    "hits": 0,
    "misses": 0,
    "expired": 0,
    "invalidations": 0,
}


# ──────────────────────────────────────────────────────────────────────────
# Backward-compatible re-exports used by region_router.py and tests
# ──────────────────────────────────────────────────────────────────────────

# Re-export the env->secret mapping so callers that imported the private
# name (region_router.py imports _load_secret_value_by_path) keep working.
from apps.backend.providers.secret_provider import (  # noqa: F401 — re-export
    SECRET_TO_ENV as _SECRET_TO_ENV,
    SECRET_PLACEHOLDER_VALUES as _SECRET_PLACEHOLDER_VALUES,
    normalize_secret_value as _normalize_secret_value,
)


def _load_secret_value_by_path(secret_path: str) -> str | None:
    """Load secret value by full path from AWS Secrets Manager.

    Backward-compatible wrapper — ``region_router.py`` imports this.
    """
    from apps.backend.providers.secret_provider import AWSSecretsManagerProvider

    return AWSSecretsManagerProvider._load_from_aws(secret_path)


def _cache_ttl_seconds() -> float:
    raw = os.getenv("WORKWEAVER_SECRETS_CACHE_TTL", str(int(_SECRET_CACHE_DEFAULT_TTL_SECONDS)))
    try:
        return max(0.0, float(raw))
    except ValueError:
        logger.warning("secrets.cache.invalid_ttl value=%s default=%s", raw, int(_SECRET_CACHE_DEFAULT_TTL_SECONDS))
        return _SECRET_CACHE_DEFAULT_TTL_SECONDS


def _get_cached_secret(key: tuple[str, str | None], *, now: float, ttl_seconds: float) -> str | None:
    if ttl_seconds <= 0:
        return None
    with _SECRET_CACHE_LOCK:
        item = _SECRET_CACHE.get(key)
        if item is None:
            _SECRET_CACHE_STATS["misses"] += 1
            return None
        cached_at, value = item
        if now - cached_at >= ttl_seconds:
            _SECRET_CACHE.pop(key, None)
            _SECRET_CACHE_STATS["expired"] += 1
            return None
        _SECRET_CACHE.move_to_end(key)
        _SECRET_CACHE_STATS["hits"] += 1
        return value


def _cache_secret(key: tuple[str, str | None], value: str | None, *, now: float) -> None:
    if value is None:
        return
    with _SECRET_CACHE_LOCK:
        _SECRET_CACHE[key] = (now, value)
        _SECRET_CACHE.move_to_end(key)
        while len(_SECRET_CACHE) > _SECRET_CACHE_MAX_SIZE:
            _SECRET_CACHE.popitem(last=False)


def clear_secret_cache() -> None:
    """Clear the in-process secret cache without changing the active provider."""
    with _SECRET_CACHE_LOCK:
        _SECRET_CACHE.clear()
        _SECRET_CACHE_STATS["invalidations"] += 1


def invalidate_secret_cache(secret_name: str | None = None, environment: str | None = None) -> dict[str, int | bool]:
    """Invalidate matching cached secrets and report the number removed."""
    with _SECRET_CACHE_LOCK:
        if secret_name is None and environment is None:
            removed = len(_SECRET_CACHE)
            _SECRET_CACHE.clear()
        else:
            keys = [
                key
                for key in _SECRET_CACHE
                if (secret_name is None or key[0] == secret_name) and (environment is None or key[1] == environment)
            ]
            for key in keys:
                _SECRET_CACHE.pop(key, None)
            removed = len(keys)
        _SECRET_CACHE_STATS["invalidations"] += 1
    logger.info(
        "secrets.cache.invalidated secret=%s environment=%s removed=%s",
        secret_name or "*",
        environment or "*",
        removed,
    )
    return {"invalidated": True, "removed": removed}


def get_secret_cache_stats() -> dict[str, int | float]:
    """Return process-local secret cache diagnostics."""
    with _SECRET_CACHE_LOCK:
        stats = dict(_SECRET_CACHE_STATS)
        stats["size"] = len(_SECRET_CACHE)
        stats["max_size"] = _SECRET_CACHE_MAX_SIZE
    stats["ttl_seconds"] = _cache_ttl_seconds()
    return stats


def _get_secret_json_field(secret_name: str, field: str, environment: str | None = None) -> str | None:
    """Read a JSON secret and return a specific field if present."""
    raw_secret = get_secret(secret_name, environment)
    if not raw_secret:
        return None
    try:
        payload = json.loads(raw_secret)
    except Exception as exc:
        logger.error("secrets.json_parse_failed secret=%s field=%s: %s", secret_name, field, exc, exc_info=True)
        return None
    value = payload.get(field) if isinstance(payload, dict) else None
    if value is None:
        return None
    return _normalize_secret_value(str(value))


def get_secret(secret_name: str, environment: str | None = None) -> str | None:
    """
    Retrieve a secret through the active provider and cache successful reads.

    Provider precedence depends on the deployment profile. Managed SaaS reads
    AWS Secrets Manager first; self-host/local profiles may prefer env vars.
    Successful reads are cached for ``WORKWEAVER_SECRETS_CACHE_TTL`` seconds
    (default 300). Missing values are not cached, so newly-created secrets can
    become visible immediately.

    Args:
        secret_name: The secret name without prefix (e.g., 'grok/api_key', 'twilio/account_sid')
        environment: Override environment (defaults to ENVIRONMENT env var, or 'dev')

    Returns:
        Secret value as string, or None if not found
    """
    key = (secret_name, environment)
    now = time.monotonic()
    ttl_seconds = _cache_ttl_seconds()
    cached = _get_cached_secret(key, now=now, ttl_seconds=ttl_seconds)
    if cached is not None:
        return cached

    from apps.backend.providers.secret_provider import get_secret_provider

    value = get_secret_provider().get_secret(secret_name, environment)
    _cache_secret(key, value, now=now)
    return value


get_secret.cache_clear = clear_secret_cache  # type: ignore[attr-defined]


# ============================================================================
# Grok (xAI) Secrets
# ============================================================================


def get_grok_api_key(environment: str | None = None) -> str | None:
    """Get Grok (xAI) API key."""
    return get_secret("grok/api_key", environment)


# ============================================================================
# Twilio Secrets
# ============================================================================


def get_twilio_account_sid(environment: str | None = None) -> str | None:
    """Get Twilio Account SID."""
    return get_secret("twilio/account_sid", environment)


def get_twilio_auth_token(environment: str | None = None) -> str | None:
    """Get Twilio Auth Token."""
    return get_secret("twilio/auth_token", environment)


def get_twilio_api_key_sid(environment: str | None = None) -> str | None:
    """Get Twilio API Key SID."""
    return get_secret("twilio/api_key_sid", environment)


def get_twilio_api_key_secret(environment: str | None = None) -> str | None:
    """Get Twilio API Key Secret."""
    return get_secret("twilio/api_key_secret", environment)


# ============================================================================
# LiveKit Secrets
# ============================================================================


def get_livekit_url(environment: str | None = None) -> str | None:
    """Get LiveKit WebSocket URL."""
    return get_secret("livekit/url", environment)


def get_livekit_api_key(environment: str | None = None) -> str | None:
    """Get LiveKit API Key."""
    return get_secret("livekit/api_key", environment)


def get_livekit_api_secret(environment: str | None = None) -> str | None:
    """Get LiveKit API Secret."""
    return get_secret("livekit/api_secret", environment)


def get_livekit_workspace_url(environment: str | None = None) -> str | None:
    """Get LiveKit Workspace URL."""
    return get_secret("livekit/workspace_url", environment)


# ============================================================================
# Stripe Secrets
# ============================================================================


def get_stripe_secret_key(environment: str | None = None) -> str | None:
    """Get Stripe secret key (test or live based on environment)."""
    return get_secret("stripe/secret_key", environment)


def get_stripe_publishable_key(environment: str | None = None) -> str | None:
    """Get Stripe publishable key (test or live based on environment)."""
    return get_secret("stripe/publishable_key", environment)


def get_stripe_webhook_secret(environment: str | None = None) -> str | None:
    """Get Stripe webhook secret."""
    return get_secret("stripe/webhook_secret", environment)


# ============================================================================
# Google OAuth Secrets
# ============================================================================


def get_google_client_id(environment: str | None = None) -> str | None:
    """Get Google OAuth client ID."""
    return get_secret("google/client_id", environment)


def get_google_client_secret(environment: str | None = None) -> str | None:
    """Get Google OAuth client secret."""
    return get_secret("google/client_secret", environment)


# ============================================================================
# Microsoft OAuth Secrets
# ============================================================================


def get_microsoft_client_id(environment: str | None = None) -> str | None:
    """Get Microsoft OAuth client ID."""
    return get_secret("microsoft/client_id", environment) or get_secret("meeting/microsoft_client_id", environment)


def get_microsoft_client_secret(environment: str | None = None) -> str | None:
    """Get Microsoft OAuth client secret."""
    return get_secret("microsoft/client_secret", environment) or get_secret(
        "meeting/microsoft_client_secret", environment
    )


# ============================================================================
# Zoho OAuth Secrets
# ============================================================================


def get_zoho_client_id(environment: str | None = None) -> str | None:
    """Get Zoho OAuth client ID."""
    return get_secret("zoho/client_id", environment) or _get_secret_json_field(
        "zoho/credentials", "client_id", environment
    )


def get_zoho_client_secret(environment: str | None = None) -> str | None:
    """Get Zoho OAuth client secret."""
    return get_secret("zoho/client_secret", environment) or _get_secret_json_field(
        "zoho/credentials", "client_secret", environment
    )


# ============================================================================
# Cognito Secrets (if using Cognito for auth)
# ============================================================================


def get_cognito_user_pool_id(environment: str | None = None) -> str | None:
    """Get Cognito User Pool ID."""
    return get_secret("cognito/user_pool_id", environment)


def get_cognito_client_id(environment: str | None = None) -> str | None:
    """Get Cognito Client ID."""
    return get_secret("cognito/client_id", environment)


# ============================================================================
# Utility Functions
# ============================================================================


def clear_cache() -> None:
    """Clear the secrets cache. Use after updating secrets in AWS."""
    clear_secret_cache()
    from apps.backend.providers.secret_provider import reset_secret_provider

    reset_secret_provider()


def list_all_secrets_prefix(environment: str | None = None) -> list[str]:
    """
    List all secret names for a given environment prefix.
    Useful for debugging and verifying secret structure.

    Args:
        environment: Environment to list (defaults to DEFAULT_ENVIRONMENT)

    Returns:
        List of secret names (without the /workweaver/{env}/ prefix)
    """
    from apps.backend.providers.secret_provider import get_secret_provider

    return get_secret_provider().list_secrets(environment)
