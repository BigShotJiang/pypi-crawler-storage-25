"""Environment variable governance — workspace .env override ban for platform-controlled vars.

Issue #3185: Workspace-supplied .env files must not override platform-controlled
environment variables (XAI_API_KEY, DATABASE_URL, KMS_*, STRIPE_*, etc.).

Classification tiers:
- PLATFORM_RESERVED: only the platform source can set these; any attempt from
  tenant config or workspace files is rejected with a structured error.
- TENANT_OVERRIDABLE: tenant admin can override; workspace files are rejected
  if tenant config has set a value (lower priority loses silently).
- WORKSPACE_OVERRIDABLE: any source can set these; normal precedence applies.

Precedence (highest to lowest): PLATFORM > TENANT_CONFIG > WORKSPACE_FILE.

Decision Trace records env_source_rejected when a lower-priority source attempts
to shadow a higher-priority var.
"""

from __future__ import annotations

import logging
from enum import Enum
from typing import Any

from pydantic import BaseModel

logger = logging.getLogger(__name__)


class EnvClassification(str, Enum):
    """Classification of environment variable sensitivity."""

    PLATFORM_RESERVED = "platform_reserved"
    TENANT_OVERRIDABLE = "tenant_overridable"
    WORKSPACE_OVERRIDABLE = "workspace_overridable"


class EnvSource(str, Enum):
    """Source of an environment variable value."""

    PLATFORM = "platform"
    TENANT_CONFIG = "tenant_config"
    WORKSPACE_FILE = "workspace_file"


# Source priority: higher value = higher priority
_SOURCE_PRIORITY: dict[EnvSource, int] = {
    EnvSource.PLATFORM: 100,
    EnvSource.TENANT_CONFIG: 50,
    EnvSource.WORKSPACE_FILE: 10,
}

# ---------------------------------------------------------------------------
# Reserved / overridable lists — single source of truth
# ---------------------------------------------------------------------------

# These variables are exclusively platform-controlled. No workspace .env or
# tenant config may set them. If a lower-priority source provides a value for
# one of these vars, the resolver raises EnvGovernanceError.
PLATFORM_RESERVED_VARS: frozenset[str] = frozenset(
    {
        # API keys — platform secrets
        "XAI_API_KEY",
        "GROK_API_KEY",
        # Database
        "DATABASE_URL",
        "DB_PASSWORD",
        "DB_HOST",
        "DB_PORT",
        "DB_NAME",
        "DB_USER",
        # AWS credentials
        "AWS_ACCESS_KEY_ID",
        "AWS_SECRET_ACCESS_KEY",
        "AWS_SESSION_TOKEN",
        "AWS_REGION",
        "AWS_DEFAULT_REGION",
        # KMS
        "KMS_KEY_ID",
        "KMS_KEY_ARN",
        # Stripe
        "STRIPE_SECRET_KEY",
        "STRIPE_PUBLISHABLE_KEY",
        "STRIPE_WEBHOOK_SECRET",
        "ZOHO_DESK_WEBHOOK_SECRET",
        # WorkMemory
        "WORKMEMORY_AUDIO_TRANSCRIBE_BUCKET",
        # Auth / session secrets
        "JWT_SECRET",
        "SESSION_SECRET",
        "ENCRYPTION_KEY",
    }
)

# Tenant-overridable vars: tenant admin can override workspace files but not
# the platform source.
TENANT_OVERRIDABLE_VARS: frozenset[str] = frozenset(
    {
        "WORKSPACE_LOG_LEVEL",
        "WORKSPACE_FEATURE_X_ENABLED",
        "WORKSPACE_DEBUG_MODE",
        "WORKSPACE_DEFAULT_TIMEZONE",
        "WORKSPACE_LOCALE",
        "WORKSPACE_NOTIFICATION_PREFERENCES",
    }
)


class EnvGovernanceResult(BaseModel):
    """Result of resolving a single environment variable through the governance layer.

    Decision Trace fields: var_name, attempted_source, effective_source,
    rejected_source (if any), rejected_value (if any).
    """

    var_name: str
    resolved_value: str | None = None
    effective_source: EnvSource | None = None
    attempted_source: EnvSource | None = None
    rejected_source: EnvSource | None = None
    rejected_value: str | None = None
    classification: EnvClassification = EnvClassification.WORKSPACE_OVERRIDABLE


class EnvGovernanceError(Exception):
    """Raised when a lower-priority source attempts to set a reserved variable.

    Carries Decision Trace fields for audit logging.
    """

    def __init__(
        self,
        message: str,
        *,
        var_name: str,
        attempted_source: EnvSource,
        effective_source: EnvSource | None,
        rejected_source: EnvSource,
        rejected_value: str | None,
        classification: EnvClassification,
    ) -> None:
        super().__init__(message)
        self.var_name = var_name
        self.attempted_source = attempted_source
        self.effective_source = effective_source
        self.rejected_source = rejected_source
        self.rejected_value = rejected_value
        self.classification = classification


def classify_var(var_name: str) -> EnvClassification:
    """Classify an environment variable by its sensitivity tier.

    Returns the classification for the given variable name. Unknown variables
    default to WORKSPACE_OVERRIDABLE.
    """
    if var_name in PLATFORM_RESERVED_VARS:
        return EnvClassification.PLATFORM_RESERVED
    if var_name in TENANT_OVERRIDABLE_VARS:
        return EnvClassification.TENANT_OVERRIDABLE
    return EnvClassification.WORKSPACE_OVERRIDABLE


def resolve_var(
    var_name: str,
    sources: list[tuple[EnvSource, str]],
) -> EnvGovernanceResult:
    """Resolve a single variable through the governance layer.

    Args:
        var_name: Name of the environment variable.
        sources: List of (source, value) pairs, in any order. The resolver
                 sorts by priority and enforces classification rules.

    Returns:
        EnvGovernanceResult with the resolved value and trace fields.

    Raises:
        EnvGovernanceError: If a lower-priority source provides a value for
            a variable it is not allowed to set.
    """
    classification = classify_var(var_name)

    if not sources:
        return EnvGovernanceResult(
            var_name=var_name,
            classification=classification,
        )

    # Sort sources by priority (highest first)
    sorted_sources = sorted(sources, key=lambda s: _SOURCE_PRIORITY[s[0]], reverse=True)
    best_source, best_value = sorted_sources[0]
    lowest_source = sorted_sources[-1]

    # Check governance rules based on classification
    if classification == EnvClassification.PLATFORM_RESERVED:
        # Only PLATFORM source is allowed
        if best_source != EnvSource.PLATFORM:
            raise EnvGovernanceError(
                f"Variable {var_name!r} is platform-reserved and cannot be set "
                f"from {best_source.value!r} source",
                var_name=var_name,
                attempted_source=lowest_source[0],
                effective_source=None,
                rejected_source=best_source,
                rejected_value=best_value,
                classification=classification,
            )
        # Check if any lower-priority source tried to set it (for trace)
        rejected = None
        for source, value in sorted_sources[1:]:
            if source != EnvSource.PLATFORM:
                rejected = (source, value)
                break

        return EnvGovernanceResult(
            var_name=var_name,
            resolved_value=best_value,
            effective_source=best_source,
            attempted_source=rejected[0] if rejected else None,
            rejected_source=rejected[0] if rejected else None,
            rejected_value=rejected[1] if rejected else None,
            classification=classification,
        )

    if classification == EnvClassification.TENANT_OVERRIDABLE:
        # Tenant config can override workspace files; platform overrides all
        rejected = None
        for source, value in sorted_sources[1:]:
            if _SOURCE_PRIORITY[source] < _SOURCE_PRIORITY[best_source]:
                rejected = (source, value)
                break

        return EnvGovernanceResult(
            var_name=var_name,
            resolved_value=best_value,
            effective_source=best_source,
            attempted_source=rejected[0] if rejected else None,
            rejected_source=rejected[0] if rejected else None,
            rejected_value=rejected[1] if rejected else None,
            classification=classification,
        )

    # WORKSPACE_OVERRIDABLE: any source wins, record rejection for trace
    rejected = None
    for source, value in sorted_sources[1:]:
        if _SOURCE_PRIORITY[source] < _SOURCE_PRIORITY[best_source]:
            rejected = (source, value)
            break

    return EnvGovernanceResult(
        var_name=var_name,
        resolved_value=best_value,
        effective_source=best_source,
        attempted_source=rejected[0] if rejected else None,
        rejected_source=rejected[0] if rejected else None,
        rejected_value=rejected[1] if rejected else None,
        classification=classification,
    )


def resolve_vars(
    vars_with_sources: dict[str, list[tuple[EnvSource, str]]],
) -> dict[str, EnvGovernanceResult]:
    """Resolve multiple variables through the governance layer.

    Args:
        vars_with_sources: Map of var_name -> list of (source, value) pairs.

    Returns:
        Map of var_name -> EnvGovernanceResult.

    Raises:
        EnvGovernanceError: On the first variable that violates governance.
    """
    results: dict[str, Any] = {}
    for var_name, sources in vars_with_sources.items():
        results[var_name] = resolve_var(var_name, sources)
    return results
