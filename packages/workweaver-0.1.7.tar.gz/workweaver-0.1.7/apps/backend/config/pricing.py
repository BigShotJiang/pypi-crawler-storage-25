"""Pricing Configuration for Workweaver Platform.

Single source of truth for all pricing constants across the platform.

Two products:
  1. Workweaver AI Employee Platform (Launchpad / Growth / Enterprise)
  2. WorkMemory Standalone (Developer / Starter / Pro / Team / Enterprise)

WorkMemory is BUNDLED into Workweaver (not separately billed for WW customers).
WorkMemory Standalone is for developers who only need the memory API.

Usage-based rates apply on top of plan base prices (metered via Stripe).

Pricing architecture (Hormozi $100M Offers aligned):
- Workweaver plans are positioned as "AI agent that replaces $3K-8K/mo human"
- Grand Slam Offer: 14-day unconditional + 30-day conditional guarantee
- WorkMemory standalone targets developers building AI apps

To modify pricing:
1. Update constants in this file
2. Update Stripe Price IDs via env vars (STRIPE_PRICE_ID)
3. Update marketing copy in apps/landing/public/ if customer-facing
4. Regenerate invoices with new rates using InvoiceGeneratorService

Note: Invoice line items reference these constants. Historical invoices
are immutable and reflect rates at time of generation.
"""

from decimal import Decimal


# ============================================================================
# Workweaver AI Employee Platform (Launchpad / Growth / Enterprise)
# Canonical customer-facing plans. Positioned as AI agent replacement.
# ============================================================================

WORKWEAVER_PLANS: dict[str, dict] = {
    "launchpad": {
        "name": "Launchpad",
        "monthly_usd": Decimal("499.00"),
        "annual_usd": Decimal("4788.00"),  # $399/mo * 12 (20% off)
        "annual_monthly_equiv": Decimal("399.00"),
        "annual_savings_pct": 20,
        "included_meeting_hrs": 40,
        "included_emails": 500,
        "included_crm_ops": 1000,
        "ai_employees": 1,
        "workmemory_tier": "starter",
        "features": [
            "1_ai_employee",
            "mission_control",
            "zoho_crm",
            "email_in_out",
            "voice_calls",
            "workmemory_starter_bundled",
            "evidence_ledger",
            "skill_execution",
        ],
    },
    "growth": {
        "name": "Growth",
        "monthly_usd": Decimal("1499.00"),
        "annual_usd": Decimal("14388.00"),  # $1199/mo * 12 (20% off)
        "annual_monthly_equiv": Decimal("1199.00"),
        "annual_savings_pct": 20,
        "included_meeting_hrs": 200,
        "included_emails": 2500,
        "included_crm_ops": 5000,
        "ai_employees": 5,
        "workmemory_tier": "pro",
        "features": [
            "5_ai_employees",
            "mission_control",
            "zoho_crm",
            "salesforce",
            "hubspot",
            "email_in_out",
            "voice_calls",
            "meetings_bot",
            "workmemory_pro_bundled",
            "evidence_ledger",
            "skill_execution",
            "advanced_analytics",
        ],
    },
    "enterprise": {
        "name": "Enterprise",
        "monthly_usd": Decimal("4999.00"),
        "annual_usd": Decimal("47988.00"),  # $3999/mo * 12 (20% off)
        "annual_monthly_equiv": Decimal("3999.00"),
        "annual_savings_pct": 20,
        "included_meeting_hrs": 500,  # Cap: overages billed at $12/hr
        "included_emails": 25000,
        "included_crm_ops": 50000,
        "ai_employees": -1,  # Unlimited configurations
        "workmemory_tier": "team",
        "overage_meeting_rate_cents": 1200,  # $12/hr overage above 500 hrs
        "features": [
            "unlimited_ai_employees",
            "mission_control",
            "all_crm_integrations",
            "email_in_out",
            "voice_calls",
            "meetings_bot",
            "workmemory_team_bundled",
            "evidence_ledger",
            "skill_execution",
            "advanced_analytics",
            "sso",
            "audit_logs",
            "sla_support",
            "custom_integrations",
        ],
    },
}

# Add-on seats (billed in addition to platform plan)
WORKWEAVER_SEAT_ADDONS: dict[str, dict] = {
    "standard": {
        "name": "Standard Seat",
        "monthly_usd": Decimal("249.00"),
        "meeting_hrs": 40,
        "emails": 500,
        "crm_ops": 1000,
    },
    "power": {
        "name": "Power Seat",
        "monthly_usd": Decimal("599.00"),
        "meeting_hrs": -1,  # Unlimited (within fair use)
        "emails": -1,
        "crm_ops": -1,
    },
}


# ============================================================================
# WorkMemory Standalone (for developers, API-only access)
# ============================================================================

WORKMEMORY_PLANS: dict[str, dict] = {
    "developer": {
        "name": "Developer",
        "monthly_usd": Decimal("0.00"),
        "annual_usd": Decimal("0.00"),
        "memories": 2000,
        "queries_per_month": 500,
        "daily_rate_limit": 100,
        "api_keys": 1,
        "multimodal": False,
        "features": ["rest_api", "basic_search", "mcp_compatible"],
    },
    "starter": {
        "name": "Starter",
        "monthly_usd": Decimal("29.00"),
        "annual_usd": Decimal("24.00"),  # $24/mo billed annually
        "memories": 50_000,
        "queries_per_month": 10_000,
        "daily_rate_limit": 1_000,
        "api_keys": 5,
        "multimodal": True,
        "features": [
            "rest_api",
            "basic_search",
            "hybrid_search",
            "mcp_compatible",
            "multimodal_ingest",
        ],
    },
    "pro": {
        "name": "Pro",
        "monthly_usd": Decimal("99.00"),
        "annual_usd": Decimal("79.00"),  # $79/mo billed annually
        "memories": 500_000,
        "queries_per_month": 100_000,
        "daily_rate_limit": 5_000,
        "api_keys": 25,
        "multimodal": True,
        "features": [
            "rest_api",
            "basic_search",
            "hybrid_search",
            "mcp_compatible",
            "multimodal_ingest",
            "pattern_learning",
            "sleep_time_compute",
            "priority_support",
        ],
    },
    "team": {
        "name": "Team",
        "monthly_usd": Decimal("299.00"),
        "annual_usd": Decimal("239.00"),  # $239/mo billed annually
        "memories": 5_000_000,
        "queries_per_month": 1_000_000,
        "daily_rate_limit": 50_000,
        "api_keys": 100,
        "multimodal": True,
        "features": [
            "rest_api",
            "basic_search",
            "hybrid_search",
            "mcp_compatible",
            "multimodal_ingest",
            "pattern_learning",
            "sleep_time_compute",
            "business_ontology",
            "all_connectors",
            "priority_support",
            "team_namespaces",
        ],
    },
    "enterprise": {
        "name": "Enterprise",
        "monthly_usd": Decimal("999.00"),  # Starting at; custom pricing
        "annual_usd": None,  # Custom
        "memories": -1,  # Unlimited
        "queries_per_month": -1,  # Unlimited
        "daily_rate_limit": -1,  # Unlimited
        "api_keys": -1,
        "multimodal": True,
        "features": [
            "rest_api",
            "basic_search",
            "hybrid_search",
            "mcp_compatible",
            "multimodal_ingest",
            "pattern_learning",
            "sleep_time_compute",
            "business_ontology",
            "all_connectors",
            "sso",
            "audit_logs",
            "sla_support",
            "custom_deployment",
            "dedicated_support",
        ],
    },
}


# ============================================================================
# Usage-Based Metering Rates (USD, applies on top of plan base price)
# ============================================================================

# Voice & telephony
VOICE_RATE_USD_PER_MINUTE = Decimal("0.15")  # COGS $0.05/min, 3x markup

# Conversational AI (non-voice)
AI_RATE_USD_PER_CONVERSATION = Decimal("0.03")

# Messaging (per-message, not per-conversation)
WHATSAPP_RATE_USD_PER_MESSAGE = Decimal("0.05")  # COGS $0.01/msg, 5x markup

# Email overage
EMAIL_RATE_USD_PER_MESSAGE = Decimal("0.02")  # COGS $0.005/msg, 4x markup

# CRM operation overage
CRM_RATE_USD_PER_OPERATION = Decimal("0.01")  # COGS $0.002/op, 5x markup

# LLM pass-through (Anthropic token cost pass-through)
LLM_TOKEN_RATE_USD_PER_1K = Decimal("0.01")

# Meeting overage (Enterprise tier, above 500 hrs/mo base)
MEETING_OVERAGE_RATE_USD_PER_HOUR = Decimal("12.00")

# Included quantities per plan (usage up to these is included in plan fee)
PLAN_INCLUDED_QUANTITIES: dict[str, dict] = {
    "launchpad": {
        "voice_call_minutes": 500,
        "meeting_minutes": 40 * 60,  # 40 hrs -> minutes
        "grok_voice_minutes": 300,
        "transcript_minutes": 300,
        "skill_execution": 500,
        "email_outbound": 500,
        "email_inbound": 500,
        "whatsapp_message_outbound": 100,
        "whatsapp_message_inbound": 100,
    },
    "growth": {
        "voice_call_minutes": 2000,
        "meeting_minutes": 200 * 60,  # 200 hrs -> minutes
        "grok_voice_minutes": 1000,
        "transcript_minutes": 1000,
        "skill_execution": 2500,
        "email_outbound": 2500,
        "email_inbound": 2500,
        "whatsapp_message_outbound": 500,
        "whatsapp_message_inbound": 500,
    },
    "enterprise": {
        "voice_call_minutes": 10000,
        "meeting_minutes": 500 * 60,  # 500 hrs -> minutes (cap, overages billed)
        "grok_voice_minutes": 5000,
        "transcript_minutes": 5000,
        "skill_execution": 25000,
        "email_outbound": 25000,
        "email_inbound": 25000,
        "whatsapp_message_outbound": 5000,
        "whatsapp_message_inbound": 5000,
    },
}


# ============================================================================
# Currency Configuration
# ============================================================================

DEFAULT_BILLING_CURRENCY = "usd"
SUPPORTED_CURRENCIES = {"usd", "aed", "eur", "gbp", "inr", "sgd"}
REGION_CURRENCY_MAP = {
    "us-east-1": "usd",
    "eu-central-1": "eur",
    "ap-southeast-1": "sgd",
}

# Backward compatibility alias
BILLING_CURRENCY = DEFAULT_BILLING_CURRENCY


# ============================================================================
# Backward Compatibility Layer
# (for code that still references old stale plan names — remove after migration)
# ============================================================================

# Old professional plan → map to Launchpad
PLAN_PROFESSIONAL_MONTHLY_USD = WORKWEAVER_PLANS["launchpad"]["monthly_usd"]

# Old WorkMemory plan names → redirect to canonical
MEMORY_PLAN_FREE_MONTHLY_USD = WORKMEMORY_PLANS["developer"]["monthly_usd"]
MEMORY_PLAN_PRO_MONTHLY_USD = WORKMEMORY_PLANS["pro"]["monthly_usd"]
MEMORY_PLAN_SCALE_MONTHLY_USD = WORKMEMORY_PLANS["team"]["monthly_usd"]  # "Scale" → "Team"

# Old MEMORY_PLANS dict → map to WORKMEMORY_PLANS keys for any existing code
MEMORY_PLANS: dict[str, dict] = {
    "free": WORKMEMORY_PLANS["developer"],
    "pro": WORKMEMORY_PLANS["pro"],
    "scale": WORKMEMORY_PLANS["team"],  # stale name → canonical team
    "developer": WORKMEMORY_PLANS["developer"],
    "starter": WORKMEMORY_PLANS["starter"],
    "team": WORKMEMORY_PLANS["team"],
    "enterprise": WORKMEMORY_PLANS["enterprise"],
}

# Old PRODUCT_SKUS → redirect to WORKWEAVER_PLANS for existing code
PRODUCT_SKU_PERSONAL_MEMORY_USD = Decimal("0.00")
PRODUCT_SKU_AI_EMPLOYEE_OPS_USD = WORKWEAVER_PLANS["launchpad"]["monthly_usd"]
PRODUCT_SKU_MEETING_INTELLIGENCE_USD = Decimal("99.00")

PRODUCT_SKUS: dict[str, dict] = {
    # Legacy "personal_memory" maps to WorkMemory Developer (free)
    "personal_memory": {
        "name": "Personal Memory",  # legacy name preserved for backward compat
        "sku_id": "sku_personal_memory",
        "monthly_usd": PRODUCT_SKU_PERSONAL_MEMORY_USD,
        "tier_type": "standalone",
        # Extend developer features with legacy "workmemory" flag expected by old code
        "features": [*WORKMEMORY_PLANS["developer"]["features"], "workmemory"],
        "limits": {
            "memories_per_month": WORKMEMORY_PLANS["developer"]["memories"],
            "queries_per_month": WORKMEMORY_PLANS["developer"]["queries_per_month"],
            "connectors": 0,
            "agents": 0,
            "meeting_minutes": 0,
        },
    },
    # Legacy "ai_employee_ops" maps to Workweaver Launchpad
    "ai_employee_ops": {
        "name": "AI Employee Ops",  # legacy name preserved for backward compat
        "sku_id": "sku_ai_employee_ops",
        "monthly_usd": PRODUCT_SKU_AI_EMPLOYEE_OPS_USD,
        "tier_type": "standalone",
        # Extend Launchpad features with legacy flags expected by old code
        "features": [*WORKWEAVER_PLANS["launchpad"]["features"], "runtime_agents", "workmemory"],
        "limits": {
            "memories_per_month": WORKMEMORY_PLANS["starter"]["memories"],
            "queries_per_month": WORKMEMORY_PLANS["starter"]["queries_per_month"],
            "connectors": -1,
            "agents": 1,
            "meeting_minutes": WORKWEAVER_PLANS["launchpad"]["included_meeting_hrs"] * 60,
            "skill_executions": PLAN_INCLUDED_QUANTITIES["launchpad"]["skill_execution"],
        },
    },
    # Legacy "meeting_intelligence" is now an included feature, not a separate add-on
    "meeting_intelligence": {
        "name": "Meeting Intelligence",  # legacy name preserved for backward compat
        "sku_id": "sku_meeting_intelligence",
        "monthly_usd": PRODUCT_SKU_MEETING_INTELLIGENCE_USD,
        "tier_type": "add_on",
        "features": ["zara_meeting_bot", "meeting_transcription", "meeting_action_items"],
        "limits": {
            "meeting_minutes": 300,
            "transcript_minutes": 300,
        },
    },
}


def get_sku_by_id(sku_id: str) -> dict | None:
    """Look up a product SKU by its sku_id (backward compat)."""
    for sku in PRODUCT_SKUS.values():
        if sku["sku_id"] == sku_id:
            return sku
    return None


def get_tier_features(tier_key: str) -> list[str]:
    """Return the feature list for a tier, or empty list if not found.

    Checks Workweaver AI Employee plans, then WorkMemory standalone plans,
    then legacy PRODUCT_SKUS.
    """
    # Check Workweaver AI Employee plans (canonical)
    ww = WORKWEAVER_PLANS.get(tier_key)
    if ww:
        return list(ww["features"])
    # Check WorkMemory standalone plans
    wm = WORKMEMORY_PLANS.get(tier_key)
    if wm:
        return list(wm["features"])
    # Fall back to legacy PRODUCT_SKUS
    sku = PRODUCT_SKUS.get(tier_key)
    return list(sku["features"]) if sku else []


def get_plan_included_quantities(plan_key: str) -> dict:
    """Return included quantities for a Workweaver plan tier."""
    return dict(PLAN_INCLUDED_QUANTITIES.get(plan_key, {}))


def get_workmemory_plan(plan_key: str) -> dict | None:
    """Return a WorkMemory standalone plan dict by key."""
    return WORKMEMORY_PLANS.get(plan_key)


def get_workweaver_plan(plan_key: str) -> dict | None:
    """Return a Workweaver AI Employee platform plan dict by key."""
    return WORKWEAVER_PLANS.get(plan_key)


def get_annual_price(plan_key: str, product: str = "workweaver") -> Decimal | None:
    """Return the annual lump-sum price for a plan.

    Args:
        plan_key: Plan key (e.g. 'launchpad', 'growth', 'enterprise').
        product: One of 'workweaver' or 'workmemory'.

    Returns:
        Annual USD price as Decimal, or None if not applicable / custom.
    """
    if product == "workweaver":
        plan = WORKWEAVER_PLANS.get(plan_key)
    elif product == "workmemory":
        plan = WORKMEMORY_PLANS.get(plan_key)
        if plan:
            # WorkMemory annual_usd is per-month equiv; compute yearly total
            annual_mo = plan.get("annual_usd")
            return Decimal(str(annual_mo)) * 12 if annual_mo else None
    else:
        return None
    if plan is None:
        return None
    return plan.get("annual_usd")


# ============================================================================
# Stripe Price ID Mapping (lookup_key → Stripe Price ID)
#
# These are created via `stripe prices create` and referenced by checkout.
# Use lookup_keys for portability between test/live modes.
# Override any ID via env var: STRIPE_PRICE_<LOOKUP_KEY> (uppercase).
# ============================================================================

# Default test-mode Price IDs (created 2026-03-02)
_STRIPE_PRICE_DEFAULTS: dict[str, str] = {
    # Workweaver AI Employee Platform
    "ww_launchpad_monthly": "price_1T6RNEAsaucORsUGSdsiUZID",
    "ww_launchpad_annual": "price_1T6RNFAsaucORsUGxFmMmCPi",
    "ww_growth_monthly": "price_1T6RNJAsaucORsUGDFTESpnM",
    "ww_growth_annual": "price_1T6RNLAsaucORsUG1lm9cl6s",
    "ww_enterprise_monthly": "price_1T6RNOAsaucORsUGkJPuSD4h",
    "ww_enterprise_annual": "price_1T6RNQAsaucORsUGvjdxskeK",
    # Seat add-ons
    "ww_seat_standard_monthly": "price_1T6RNeAsaucORsUGW4PF7ocJ",
    "ww_seat_power_monthly": "price_1T6RNgAsaucORsUGdyRioPDT",
    # WorkMemory Standalone
    "wm_starter_monthly": "price_1T6RNuAsaucORsUGcJfl6vgP",
    "wm_starter_annual": "price_1T6RNvAsaucORsUGTAXT3bYv",
    "wm_pro_monthly": "price_1T6RNxAsaucORsUGXerFB0qS",
    "wm_pro_annual": "price_1T6RNyAsaucORsUGJKDug5a1",
    "wm_team_monthly": "price_1T6RO1AsaucORsUGMNbr6oc4",
    "wm_team_annual": "price_1T6RO2AsaucORsUG23cJ9sPg",
    "wm_enterprise_monthly": "price_1T6RO4AsaucORsUGnqfEF8Mw",
}

# Stripe Coupon IDs
STRIPE_COUPONS: dict[str, str] = {
    "founding_50": "ALPHA-WW-100",  # 100% off forever, max 50 redemptions
    "alpha_tester": "ALPHA-WW-95",  # 95% off for 6 months, max 200
    "beta_tester": "BETA-WW-50",  # 50% off for 3 months, max 500
}


def get_stripe_price_id(lookup_key: str) -> str | None:
    """Return Stripe Price ID for a lookup key.

    Checks env var STRIPE_PRICE_<KEY> first, then falls back to defaults.
    """
    import os

    env_key = f"STRIPE_PRICE_{lookup_key.upper()}"
    return os.environ.get(env_key) or _STRIPE_PRICE_DEFAULTS.get(lookup_key)


def get_stripe_price_id_for_plan(
    product: str,
    tier: str,
    billing: str = "monthly",
) -> str | None:
    """Return Stripe Price ID for a product/tier/billing combo.

    Args:
        product: 'workweaver' or 'workmemory'.
        tier: Plan tier key (e.g. 'launchpad', 'growth', 'starter', 'pro').
        billing: 'monthly' or 'annual'.

    Returns:
        Stripe Price ID string, or None if not found.
    """
    prefix = "ww" if product == "workweaver" else "wm"
    lookup_key = f"{prefix}_{tier}_{billing}"
    return get_stripe_price_id(lookup_key)
