"""Data-driven router registry for lazy service loading (#1103).

Defines ROUTER_GROUPS: a dict mapping group names to lists of router
definitions.  Each router definition is a 3-tuple of
``(module_path, attr_name, include_kwargs)``.

The registry is a pure data module with no runtime imports beyond
``typing``.  The loading machinery that consumes it lives in
``apps.backend.main`` (a separate change).
"""

from __future__ import annotations

from typing import Any

# (module_path, attr_name, include_kwargs)
#
# ``include_kwargs`` also carries a small amount of loader-only metadata:
# - ``bundle``               — capability bundle gate name
# - ``optional_deps``        — top-level dependency names that may be absent
# - ``optional_profiles``    — deployment profiles allowed to degrade instead of crash
# - ``disabled_paths``       — 501 placeholder paths to install when the router is degraded
RouterDef = tuple[str, str, dict[str, Any]]

_VOICE_OPTIONAL_DEPENDENCY_PROFILES = (
    "managed_saas",
    "local_native",
)

# ---------------------------------------------------------------------------
# Voice routers carry a ``"bundle": "voice"`` key in include_kwargs so the
# loader can gate them with ``_include_bundle_router`` at mount time.
# Two of them also have explicit prefix/tags overrides.
# ---------------------------------------------------------------------------

ROUTER_GROUPS: dict[str, list[RouterDef]] = {
    # ------------------------------------------------------------------
    # CORE -- auth, health plumbing, workspace bootstrap
    # ------------------------------------------------------------------
    "core": [
        ("apps.backend.api.auth", "router", {}),
        ("apps.backend.api.oauth_dispatcher", "router", {}),
        ("apps.backend.api.onboarding", "router", {}),
        ("apps.backend.api.workspace", "router", {}),
        ("apps.backend.api.workspace.members", "router", {}),
        # Issue #3542: WorkspacePersonaOverlay (safe SOUL.md analog).
        ("apps.backend.api.workspace_persona", "router", {}),
        ("apps.backend.api.settings", "router", {}),
        ("apps.backend.api.notifications", "router", {}),
        ("apps.backend.api.profile", "router", {}),
        ("apps.backend.api.voice_personas", "router", {}),
    ],
    # ------------------------------------------------------------------
    # BILLING -- Stripe webhooks, usage/invoice/subscription/checkout,
    #            lead magnets
    # ------------------------------------------------------------------
    "billing": [
        ("apps.backend.api.stripe_webhooks", "router", {}),
        ("apps.backend.api.billing", "usage_router", {}),
        # Per-Member live metering + pause/resume (#2728). Mounted after the
        # tenant-level usage router so the more-specific
        # `/usage/{tenant_id}/live` path is registered without colliding with
        # the tenant-level summary routes that share the prefix.
        ("apps.backend.api.billing", "usage_live_router", {}),
        ("apps.backend.api.tenant.billing", "router", {}),
        ("apps.backend.api.billing", "invoice_router", {}),
        ("apps.backend.api.billing", "subscription_router", {}),
        ("apps.backend.api.billing", "checkout_router", {}),
        ("apps.backend.api.lead_magnets", "router", {}),
    ],
    # ------------------------------------------------------------------
    # CONNECTORS -- integration catalog, connector actions, integrations
    # ------------------------------------------------------------------
    "connectors": [
        ("apps.backend.api.connectors", "router", {}),
        # Watchface canonical adapters (issue #1181): /api/v1/connectors/* URLs
        # the connector-hub UI expects. Mounted AFTER connectors.router so
        # existing canonical paths take precedence; only the 5 adapter paths
        # (/catalog, /install, /installed/{id}, /health/{id}, /test) are added.
        ("apps.backend.api.connector_watchface", "router", {}),
        ("apps.backend.api.connector_actions", "router", {}),
        ("apps.backend.api.integrations", "router", {}),
        # Issue #2747: the legacy `connector_health` router was retired.
        # The canonical `connectors` router (routes_catalog.py + routes_lifecycle.py)
        # owns both `/api/v1/connectors/health` and `/api/v1/connectors/{id}/health`
        # — its responses are now enriched by `_connector_remediation_fields`
        # so the structured remediation hints surface there instead of via
        # a duplicate route with a different contract.
    ],
    # ------------------------------------------------------------------
    # VOICE -- all telephony / WhatsApp / media-stream routers
    #
    # Every entry carries ``bundle: "voice"`` so the loader can
    # conditionally gate via ``_include_bundle_router``.
    # whatsapp and runtime_whatsapp also carry prefix/tags overrides.
    # ------------------------------------------------------------------
    "voice": [
        (
            "apps.backend.api.phone_provisioning",
            "router",
            {
                "bundle": "voice",
                "optional_deps": ("twilio",),
                "optional_profiles": _VOICE_OPTIONAL_DEPENDENCY_PROFILES,
                "disabled_paths": ("/api/provisioning/{path:path}",),
            },
        ),
        (
            "apps.backend.api.phone",
            "router",
            {
                "bundle": "voice",
                "optional_deps": ("twilio",),
                "optional_profiles": _VOICE_OPTIONAL_DEPENDENCY_PROFILES,
                "disabled_paths": ("/api/phone/{path:path}",),
            },
        ),
        (
            "apps.backend.api.whatsapp",
            "router",
            {
                "bundle": "voice",
                "prefix": "/api/whatsapp",
                "tags": ["whatsapp"],
                "optional_deps": ("twilio",),
                "optional_profiles": _VOICE_OPTIONAL_DEPENDENCY_PROFILES,
                "disabled_paths": ("/api/whatsapp/{path:path}",),
            },
        ),
        (
            "apps.backend.api.runtime_whatsapp",
            "router",
            {
                "bundle": "voice",
                "prefix": "/api/v1/runtime/whatsapp",
                "tags": ["runtime-whatsapp"],
                "optional_deps": ("twilio",),
                "optional_profiles": _VOICE_OPTIONAL_DEPENDENCY_PROFILES,
                "disabled_paths": ("/api/v1/runtime/whatsapp/{path:path}",),
            },
        ),
        ("apps.backend.api.zara_voice_ws", "router", {"bundle": "voice"}),
        (
            "apps.backend.api.jwt_livekit",
            "router",
            {
                "bundle": "voice",
                "optional_deps": ("aiohttp", "livekit"),
                "optional_profiles": _VOICE_OPTIONAL_DEPENDENCY_PROFILES,
                "disabled_paths": ("/get-token",),
            },
        ),
        (
            "apps.backend.services.channels.twilio.voice",
            "router",
            {
                "bundle": "voice",
                "optional_deps": ("twilio",),
                "optional_profiles": _VOICE_OPTIONAL_DEPENDENCY_PROFILES,
                "disabled_paths": (
                    "/api/call/{path:path}",
                    "/api/recordings/{path:path}",
                    "/api/twilio/{path:path}",
                ),
            },
        ),
        ("apps.backend.services.channels.twilio.media_stream", "router", {"bundle": "voice"}),
        ("apps.backend.api.voice_calls", "router", {"bundle": "voice"}),
        ("apps.backend.api.voice_avatar", "router", {"bundle": "voice"}),
        ("apps.backend.api.telephony", "router", {"bundle": "voice"}),
        (
            "apps.backend.services.channels.twilio.voice_inbound",
            "router",
            {
                "bundle": "voice",
                "optional_deps": ("twilio",),
                "optional_profiles": _VOICE_OPTIONAL_DEPENDENCY_PROFILES,
                "disabled_paths": ("/api/twilio/{path:path}",),
            },
        ),
        ("apps.backend.api.entity_phone", "router", {"bundle": "voice"}),
        ("apps.backend.api.campaigns", "router", {"bundle": "voice"}),
    ],
    # ------------------------------------------------------------------
    # MEMORY -- work memory, ingest pipeline
    # ------------------------------------------------------------------
    "memory": [
        ("apps.backend.api.memory", "router", {}),
        ("apps.backend.api.ingest", "router", {}),
        # Static active-session endpoints must mount before WorkMemory's
        # dynamic /api/v1/sessions/{session_id} route below.
        ("apps.backend.api.sessions_active", "router", {}),
        ("apps.backend.api.sessions_intake_queue", "router", {}),
        # WorkMemory sessions — rolling context sessions for long conversations
        # and agent handoff.  Router defines prefix="/v1/sessions"; mounting
        # with prefix="/api" yields /api/v1/sessions on the main backend.
        # Accessible at /memory/v1/sessions via the workmemory sub-app mount.
        (
            "apps.backend.workmemory.api.routes.sessions",
            "router",
            {"prefix": "/api", "tags": ["sessions"]},
        ),
        # WorkMemory API key management — create, list, rotate, revoke.
        # Router defines prefix="/v1/memory/keys"; mounting with prefix="/api"
        # yields /api/v1/memory/keys which matches the runtime JS calls.
        (
            "apps.backend.workmemory.api.routes.keys",
            "router",
            {"prefix": "/api", "tags": ["api-keys"]},
        ),
    ],
    # ------------------------------------------------------------------
    # EDGE-CLOUD -- bidirectional sync runtime (#1997, #2130, #2132)
    # ------------------------------------------------------------------
    "edge_cloud": [
        ("apps.backend.api.edge_cloud_handoff", "router", {}),
        ("apps.backend.api.sync_runtime", "router", {}),
        ("apps.backend.api.edge_snapshot", "router", {}),
        ("apps.backend.api.embeddings", "router", {}),
    ],
    # ------------------------------------------------------------------
    # GOVERNANCE -- autonomy, behavioral stops, suppression, approval,
    #               evidence, trust score
    # ------------------------------------------------------------------
    "governance": [
        ("apps.backend.api.governance", "router", {}),
        ("apps.backend.api.governance_anchor", "router", {}),
        ("apps.backend.api.autonomy", "router", {}),
        ("apps.backend.api.behavioral_stops", "router", {}),
        ("apps.backend.api.behavioral_stops", "emergency_router", {}),
        ("apps.backend.api.suppression", "router", {}),
        ("apps.backend.api.tenant.approval_queue", "router", {}),
        ("apps.backend.api.evidence", "router", {}),
        ("apps.backend.api.evidence_external", "router", {}),
        # Issue #2709: Context Graph as a Service — external read API.
        # Registered after evidence_external so the write surface is available
        # before agents query back the evidence they ingested.
        ("apps.backend.api.context_external", "router", {}),
        ("apps.backend.api.contestability", "router", {}),
        ("apps.backend.api.context_permissions", "router", {}),
        ("apps.backend.api.policy_allowlist", "router", {}),
        # Issue #3545: HEAL ladder read-only inspection of recent
        # self-healing actions classified by RemediationPosture.
        ("apps.backend.api.kernel_healing", "router", {}),
        # Issue #2788: §14 KernelSkill list/show/run surface.
        ("apps.backend.api.kernel_skills", "router", {}),
        # Issue #2879: tenant-wide zero-burn SLI summary.
        ("apps.backend.api.kernel_zero_burn", "router", {}),
        # Issue #2880: connector locality summary + explanation.
        ("apps.backend.api.kernel_connector_locality", "router", {}),
        # Issue #3544: kernel tool-call long tail —
        # capabilities.search / connector_health / capacity / otel.cost-burn.
        ("apps.backend.api.kernel_tools", "router", {}),
        # Issue #3548: tenant config × persona × governance conflict detector.
        ("apps.backend.api.tenant_conflicts", "router", {}),
        # Issue #3550: monthly healing digest read surface.
        ("apps.backend.api.tenant_healing", "router", {}),
        ("apps.backend.api.audit", "router", {}),
        ("apps.backend.api.trust_score", "router", {}),
        ("apps.backend.api.trust_posture", "router", {}),
        ("apps.backend.api.judgments", "router", {}),
        ("apps.backend.api.entity_autonomy", "router", {}),
        ("apps.backend.api.upgrades", "router", {}),
        ("apps.backend.api.optimizer_recommendations", "router", {}),
        ("apps.backend.api.investigation_consent", "router", {}),
        ("apps.backend.api.validator_pool", "router", {}),
    ],
    # ------------------------------------------------------------------
    # ANALYTICS -- analytics dashboards, funnels, visitor beacon, traces
    # ------------------------------------------------------------------
    "analytics": [
        ("apps.backend.api.analytics", "router", {}),
        ("apps.backend.api.analytics_funnel", "router", {}),
        ("apps.backend.api.visitor_beacon", "router", {}),
        ("apps.backend.api.traces", "router", {}),
        ("apps.backend.api.trace_learning", "router", {}),
        ("apps.backend.api.learning_dlq", "router", {}),
        ("apps.backend.api.learning_implicit", "router", {}),
        ("apps.backend.api.simulation", "router", {}),
        ("apps.backend.api.precedent", "router", {}),
        # Issue #3171: retrospective digest + notification prefs + skill
        # optimization apply routes consumed by retro-digest.js and
        # retro-notification-prefs.js.
        ("apps.backend.api.retro", "router", {}),
        ("apps.backend.api.retro", "skills_optimization_router", {}),
    ],
    # ------------------------------------------------------------------
    # ADMIN -- diagnostics, pricing, portal, inference, cost, secrets,
    #          meeting admin, founder admin, auth identities
    # ------------------------------------------------------------------
    "admin": [
        ("apps.backend.api.admin_analytics", "router", {}),
        ("apps.backend.api.admin_diagnostics", "router", {}),
        ("apps.backend.api.admin_runtime", "router", {}),
        ("apps.backend.api.admin_pricing", "router", {}),
        # Admin-scoped audit log mirror of /api/v1/org/{org_id}/audit-log,
        # auto-resolved to the caller's org (admin is tenant-scoped).
        ("apps.backend.api.admin.audit", "router", {}),
        # Admin-scoped tenant members + SCIM config surfaces.
        ("apps.backend.api.admin.members", "router", {}),
        ("apps.backend.api.admin.scim", "router", {}),
        # Issue #3623: founder-only signup allowlist audit endpoint, paired
        # with the daily CI gate (`.github/workflows/signup-allowlist-audit.yml`).
        ("apps.backend.api.admin.tenants_audit", "router", {}),
        # Crypto wallet policy + transaction inbox (admin-scoped).
        ("apps.backend.api.wallet", "router", {}),
        ("apps.backend.api.admin_portal", "router", {}),
        ("apps.backend.api.admin_inference", "router", {}),
        # Issue #3589: provider management plugin system
        ("apps.backend.api.provider_management", "router", {}),
        ("apps.backend.api.admin_cost_summary", "router", {}),
        ("apps.backend.api.admin_secrets_audit", "router", {}),
        ("apps.backend.api.admin_embedding", "router", {}),
        ("apps.backend.api.admin_meeting", "router", {}),
        ("apps.backend.api.founder_admin", "router", {}),
        ("apps.backend.api.admin_mcp", "router", {}),
        ("apps.backend.api.admin_kms", "router", {}),
        # #3227: admin permissions list/grant/revoke endpoints
        ("apps.backend.api.admin_permissions", "router", {}),
        ("apps.backend.api.auth_identities", "router", {}),
        # Issue #1151: UAT simulation router. Mounting is always
        # registered, but every endpoint inside checks
        # ``WORKWEAVER_UAT_MODE`` per-request and returns 404 when
        # the flag is off. This keeps the surface invisible in
        # production while letting staging flip the flag without a
        # redeploy.
        ("apps.backend.api.uat_simulation", "router", {}),
        # #3216: Transport health REST routes (summary + deep diagnostics)
        # gated by require_founder.
        ("apps.backend.api.transport_health", "router", {}),
    ],
    # ------------------------------------------------------------------
    # AGENTS -- zara, goals, briefing, supervisor, rules, capabilities,
    #           deployment, instances, collaboration, protocols
    # ------------------------------------------------------------------
    "agents": [
        ("apps.backend.api.zara", "router", {}),
        # Zara call history + human-transfer surface (admin-scoped).
        ("apps.backend.api.zara.calls", "router", {}),
        # Zara identity aggregator (email/calendar/phone/wallet/memory).
        ("apps.backend.api.zara.identity", "router", {}),
        # Per-capability provision/rotate/revoke endpoints.
        ("apps.backend.api.zara.identity_write", "router", {}),
        # Cross-tenant Zara coordination (issue #3625 / family J).
        # POST /api/v1/zara/coordinate, GET /api/v1/zara/coordinate/{id},
        # POST /api/v1/zara/coordinate/broadcast. Same-org enforced via
        # PermissionService._assert_same_org at the lease layer.
        ("apps.backend.api.zara.coordination", "router", {}),
        ("apps.backend.api.goals", "router", {}),
        ("apps.backend.api.briefing", "router", {}),
        ("apps.backend.api.task_feedback", "router", {}),
        ("apps.backend.api.supervisor_api", "router", {}),
        ("apps.backend.api.rules_api", "router", {}),
        ("apps.backend.api.capability_requests", "router", {}),
        ("apps.backend.api.capabilities_api", "router", {}),
        ("apps.backend.api.permissions_api", "router", {}),
        ("apps.backend.api.agent_deployment", "router", {}),
        ("apps.backend.api.agent_instances", "router", {}),
        ("apps.backend.api.pulse", "router", {}),
        ("apps.backend.api.collaboration", "router", {}),
        ("apps.backend.api.human_ai_collaboration", "router", {}),
        ("apps.backend.api.internal_agents", "router", {}),
        ("apps.backend.api.agent_protocol", "router", {}),
        ("apps.backend.api.agent_mesh", "router", {}),
        ("apps.backend.api.agent_email", "router", {}),
        ("apps.backend.api.agent_crm", "router", {}),
        ("apps.backend.api.agent_approval", "router", {}),
        ("apps.backend.api.agent_calendar", "router", {}),
        ("apps.backend.api.agent_work_ledger", "router", {}),
        ("apps.backend.api.work_functions", "router", {}),
        ("apps.backend.api.workflows_api", "router", {}),
        ("apps.backend.api.tenant_improvement", "router", {}),
        ("apps.backend.api.capability_setup_api", "router", {}),
        # RFC D011 slice 1 — read-only entity schema registry (#2179)
        ("apps.backend.api.entities", "router", {}),
        ("apps.backend.api.entity_schemas", "router", {}),
        ("apps.backend.api.entity_instances", "router", {}),
        ("apps.backend.api.ontology", "router", {}),
        ("apps.backend.api.operational_context", "router", {}),
    ],
    # ------------------------------------------------------------------
    # EXECUTION -- tasks, schedules, cadence, mission, events, planning,
    #              work items, batch jobs, interrupt control
    # ------------------------------------------------------------------
    "execution": [
        ("apps.backend.api.tasks", "router", {}),
        ("apps.backend.api.schedules", "router", {}),
        ("apps.backend.api.routines", "router", {}),
        ("apps.backend.api.cadence", "router", {}),
        ("apps.backend.api.mission", "router", {}),
        ("apps.backend.api.mission", "missions_router", {}),
        ("apps.backend.api.mission_outcome_review", "router", {}),
        ("apps.backend.api.mission_dashboard_bundle", "router", {}),
        # Timezone-aware Mission Calendar listing (#2714).
        ("apps.backend.api.mission_timeblocks", "router", {}),
        # TimeBlock CRUD primitive (#2785 PR A) — REST half of the
        # REST/CLI/MCP triplet under /api/v1/timeblocks.
        ("apps.backend.api.timeblocks", "router", {}),
        # Mission watchface canonical top-level adapters (issues
        # #1173/#1175-#1179): GET /api/v1/{missions,calendar,tasks,goals,health/summary}
        # at the user-mental-model URLs the frontend already calls.
        ("apps.backend.api.mission_watchface", "router", {}),
        # Issue #3240: verifier decision + steer history read APIs.
        ("apps.backend.api.mission_verifier_history", "router", {}),
        ("apps.backend.api.mission_steer_history", "router", {}),
        # Issue #3243: mission.steer — POST /api/v1/mission/{mission_id}/steer
        ("apps.backend.api.mission_steer", "router", {}),
        ("apps.backend.api.events", "router", {}),
        # Issue #3203: Google Chat webhook handler.
        ("apps.backend.api.google_chat", "router", {}),
        ("apps.backend.api.planning", "router", {}),
        ("apps.backend.api.work_items", "router", {}),
        ("apps.backend.api.batch_jobs", "router", {}),
        ("apps.backend.api.interrupt_control", "router", {}),
        ("apps.backend.api.swarm", "router", {}),
        ("apps.backend.api.swarm_constitution", "router", {}),
        # Issue #3238: ww mission criterion / ww.swarm.success_criteria_eval — REST
        # twin of the SuccessCriteriaEvaluator surfaces.
        ("apps.backend.api.swarm_criterion", "router", {}),
        # Issue #3236: ww swarm step-result / ww.swarm.record_step_result — REST
        # twin of the CompletionGate verifier-as-gate chokepoint.
        ("apps.backend.api.swarm_step_result", "router", {}),
        ("apps.backend.api.browser_workbench", "router", {}),
        ("apps.backend.api.mcp_config", "router", {}),
        ("apps.backend.api.okr", "router", {}),
        ("apps.backend.api.goal_cascade", "router", {}),
        ("apps.backend.api.objective_board", "router", {}),
    ],
    # ------------------------------------------------------------------
    # COMMUNICATION -- inbox, threads, push, sms, slack, email webhooks,
    #                  newsletter, emergency brake
    # ------------------------------------------------------------------
    "communication": [
        ("apps.backend.api.inbox", "router", {}),
        # Chat router REST surface (Slices 9 + 11): POST /api/v1/chat/route
        # + POST /api/v1/chat/rollback/{decision_id}.
        ("apps.backend.api.chat_router_routes", "router", {}),
        ("apps.backend.api.threads", "router", {}),
        ("apps.backend.api.push", "router", {}),
        ("apps.backend.api.sms", "router", {}),
        ("apps.backend.api.webhooks.slack_events", "router", {}),
        ("apps.backend.api.webhooks.email_events", "router", {}),
        ("apps.backend.api.webhooks.email_inbound", "router", {}),
        ("apps.backend.api.webhooks.sms_inbound", "router", {}),
        ("apps.backend.api.newsletter", "router", {}),
        # Cross-channel routing rules (#2999) — declarative routing with
        # Decision Trace emission per write.
        ("apps.backend.api.channel_routing", "router", {}),
        # ChannelMessage renderer surface parity (#3261) — list and send
        # ChannelMessage-renderer payloads per channel with Decision Trace.
        ("apps.backend.api.channels_messages", "router", {}),
        # ChannelMessage render endpoint (#3261) — unified render dispatcher.
        ("apps.backend.api.channels_render", "router", {}),
        # ComplianceGuard DNC management (#2795 PR A) — every outbound
        # voice / sms / whatsapp / email dispatcher consults the same store
        # via apps.backend.services.compliance.is_blocked().
        ("apps.backend.api.compliance", "router", {}),
        # Opt-out webhook (#2795 PR B) — Twilio STOP / Meta WhatsApp template-
        # stop / RFC 8058 List-Unsubscribe. Writes DNC entries via the same
        # store as the management API.
        ("apps.backend.api.webhooks.opt_out", "router", {}),
    ],
    # ------------------------------------------------------------------
    # CONTENT -- content pipeline, documents, revenue pack, templates,
    #            proactive, quick actions, intelligence
    # ------------------------------------------------------------------
    "content": [
        ("apps.backend.api.content_pipeline", "router", {}),
        ("apps.backend.api.documents.store", "router", {}),
        ("apps.backend.api.revenue_pack", "router", {}),
        ("apps.backend.api.templates", "router", {}),
        ("apps.backend.api.proactive", "router", {}),
        ("apps.backend.api.quick_actions", "router", {}),
        ("apps.backend.api.intelligence", "router", {}),
    ],
    # ------------------------------------------------------------------
    # MEETINGS -- meetings, webhooks, ingest, calendar sync, bookings,
    #             interview
    # ------------------------------------------------------------------
    "meetings": [
        ("apps.backend.api.meetings", "router", {}),
        # Watchface canonical adapters (issue #1180): /api/v1/meetings/* URLs
        # the meeting-panel UI expects but that live under different shapes
        # on the core router. Mounted AFTER meetings.router so the adapter
        # routes don't shadow existing endpoints by path collision.
        ("apps.backend.api.meeting_watchface", "router", {}),
        ("apps.backend.api.meeting_webhooks", "router", {}),
        ("apps.backend.api.meeting_ingest", "router", {}),
        ("apps.backend.api.calendar_sync", "router", {}),
        ("apps.backend.api.bookings", "router", {}),
        ("apps.backend.api.interview", "router", {}),
    ],
    # ------------------------------------------------------------------
    # WEBHOOKS -- zoho desk, webhook ingest, github, gitlab, asana, linear
    # ------------------------------------------------------------------
    "webhooks": [
        ("apps.backend.api.webhooks.zoho_desk", "router", {}),
        ("apps.backend.api.webhooks.ingest", "router", {}),
        ("apps.backend.api.webhooks.github", "router", {}),
        ("apps.backend.api.webhooks.gitlab", "router", {}),
        ("apps.backend.api.webhooks.asana_webhooks", "router", {}),
        ("apps.backend.api.webhooks.jira_webhooks", "router", {}),
        ("apps.backend.api.webhooks.teams_webhooks", "router", {}),
        ("apps.backend.api.webhooks.trello_webhooks", "router", {}),
        ("apps.backend.api.webhooks.linear_webhooks", "router", {}),
    ],
    # ------------------------------------------------------------------
    # ORGOS -- team, roles, role proposals, projects, task ingest,
    #          OrgOS entity features, domains
    # ------------------------------------------------------------------
    "orgos": [
        ("apps.backend.api.team", "router", {}),
        ("apps.backend.api.roles", "router", {}),
        ("apps.backend.api.role_proposals", "router", {}),
        ("apps.backend.api.projects", "router", {}),
        ("apps.backend.api.task_ingest", "router", {}),
        ("apps.backend.api.tenant.users", "router", {}),
        ("apps.backend.api.morning_brief", "router", {}),
        ("apps.backend.api.entity_scorecard", "router", {}),
        ("apps.backend.api.compounding", "router", {}),
        ("apps.backend.api.entity_instances", "sync_router", {}),
        ("apps.backend.api.entity_relationships", "router", {}),
        ("apps.backend.api.domains", "router", {}),
        ("apps.backend.api.domains", "workflows_router", {}),
        ("apps.backend.api.org_query", "router", {}),
        ("apps.backend.api.org.management", "router", {}),
        ("apps.backend.api.org.audit_log", "router", {}),
        ("apps.backend.api.org.capacity", "router", {}),
    ],
    # ------------------------------------------------------------------
    # MISC -- everything that doesn't belong to a domain group
    # ------------------------------------------------------------------
    "misc": [
        ("apps.backend.api.skills", "router", {}),
        ("apps.backend.api.skills_admin", "router", {}),
        ("apps.backend.api.skill_generation", "router", {}),
        ("apps.backend.api.skill_activation", "router", {}),
        ("apps.backend.api.eval_correlation", "router", {}),
        ("apps.backend.api.activity_stream", "router", {}),
        ("apps.backend.api.control", "router", {}),
        ("apps.backend.api.ai_playground", "router", {}),
        ("apps.backend.api.support.tickets", "router", {}),
        ("apps.backend.api.config_history", "router", {}),
        ("apps.backend.api.runtime", "router", {}),
        ("apps.backend.api.harness", "router", {}),
        ("apps.backend.api.harness_templates", "router", {}),
        # account.py registers /api/v1/account/status BEFORE account_lifecycle's
        # /{tenant_id} catchall — registration order is path-resolution order
        # in FastAPI (#3050).
        ("apps.backend.api.account", "router", {}),
        ("apps.backend.api.account_lifecycle", "router", {}),
        ("apps.backend.api.invites", "router", {}),
        ("apps.backend.api.agent_identity", "router", {}),
        ("apps.backend.api.omnibox", "router", {}),
        ("apps.backend.api.scheduler", "router", {}),
        ("apps.backend.api.public_api", "router", {}),
        ("apps.backend.api.public_api", "cli_router", {}),
        ("apps.backend.api.meta_observer", "router", {}),
        ("apps.backend.api.experiments", "router", {}),
    ],
}

# ---------------------------------------------------------------------------
# Loading profiles
# ---------------------------------------------------------------------------

ALL_GROUPS: list[str] = list(ROUTER_GROUPS.keys())

# First-class self-managed profiles (standalone + self_host_production) load the
# same router groups as managed SaaS. Runtime differences should come from
# bundle toggles / provider adapters, not from a reduced route graph.
STANDALONE_GROUPS: list[str] = list(ROUTER_GROUPS.keys())

# Groups required before a pod may accept customer traffic.
READINESS_CRITICAL_GROUPS: list[str] = ["core"]

# Groups that can warm after health/readiness without blocking the load balancer.
CUSTOMER_WARM_GROUPS: list[str] = ["execution", "agents", "memory", "governance"]

# Groups loaded in every deployment profile (standalone, managed_saas, etc.).
ALWAYS_GROUPS: list[str] = READINESS_CRITICAL_GROUPS + CUSTOMER_WARM_GROUPS + ["misc"]

DEFERRED_GROUPS: list[str] = [
    group for group in ALL_GROUPS if group not in READINESS_CRITICAL_GROUPS
]
