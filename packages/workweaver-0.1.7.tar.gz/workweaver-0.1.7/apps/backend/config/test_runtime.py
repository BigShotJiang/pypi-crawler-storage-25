"""Safety gates for test-only runtime shortcuts.

Unit tests need fast, hermetic adapters for DynamoDB, cloud secrets, EventBridge,
and similar external systems. Those switches must never become accidental
production behavior just because an environment variable leaked into a runtime
container.
"""

from __future__ import annotations

import os
import sys

_TRUTHY = {"1", "true", "yes", "y", "on"}
_PRODUCTION_ENVIRONMENTS = {"prod", "production", "staging"}
_PRODUCTION_DEPLOYMENT_PROFILES = {"managed_saas", "self_host_production"}
_LOCAL_OR_TEST_ENVIRONMENTS = {"dev", "development", "local", "test"}


def env_truthy(name: str) -> bool:
    """Return whether an environment flag is enabled."""
    return str(os.environ.get(name) or "").strip().lower() in _TRUTHY


def running_under_pytest() -> bool:
    """Return True when this process is pytest, including collection time."""
    return bool(os.environ.get("PYTEST_CURRENT_TEST")) or "pytest" in sys.modules


def _environment() -> str:
    return str(os.environ.get("ENVIRONMENT") or os.environ.get("WORKWEAVER_ENV") or "").strip().lower()


def _deployment_profile() -> str:
    return str(os.environ.get("WORKWEAVER_DEPLOYMENT_PROFILE") or "").strip().lower()


def _production_like_runtime() -> bool:
    return _environment() in _PRODUCTION_ENVIRONMENTS or _deployment_profile() in _PRODUCTION_DEPLOYMENT_PROFILES


def _flag_allowed(name: str, *, enabled: bool, allow_local: bool) -> bool:
    if not enabled:
        return False
    if _production_like_runtime():
        if running_under_pytest():
            return False
        raise RuntimeError(
            f"{name} is a test/local-only runtime override and cannot be enabled "
            "in a production-like environment."
        )
    if running_under_pytest():
        return True
    if allow_local and _environment() in _LOCAL_OR_TEST_ENVIRONMENTS:
        return True
    return False


def unit_test_runtime_flag_enabled(name: str, *, enabled: bool | None = None) -> bool:
    """Enable a switch only inside pytest/test runtime.

    Production-like env/profile values disable the switch under pytest and raise
    outside pytest, so tests can exercise production settings without inheriting
    in-memory adapters while real production processes fail closed.
    """
    return _flag_allowed(name, enabled=env_truthy(name) if enabled is None else enabled, allow_local=False)


def local_or_test_runtime_flag_enabled(name: str, *, enabled: bool | None = None) -> bool:
    """Enable a switch in local/dev/test runtimes, never production-like ones."""
    return _flag_allowed(name, enabled=env_truthy(name) if enabled is None else enabled, allow_local=True)
