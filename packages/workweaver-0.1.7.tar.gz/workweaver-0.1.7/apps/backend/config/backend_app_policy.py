"""Pure backend application startup policy helpers."""

from __future__ import annotations

import os

from apps.backend.config.environment import get_environment


def resolve_backend_docs_urls(
    *,
    environment: str | None = None,
    ecs_container_metadata_uri: str | None = None,
) -> tuple[str | None, str | None, str]:
    """Return FastAPI docs URLs for the requested runtime posture."""
    env = (environment if environment is not None else get_environment()).strip().lower()
    metadata_uri = (
        ecs_container_metadata_uri
        if ecs_container_metadata_uri is not None
        else os.environ.get("ECS_CONTAINER_METADATA_URI", "")
    )
    is_local = not metadata_uri and env not in {"prod", "production", "staging"}
    return (
        "/docs" if is_local else None,
        "/redoc" if is_local else None,
        "/openapi.json",
    )
