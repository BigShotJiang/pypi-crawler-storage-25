#!/bin/bash
# Docker entrypoint script for Workweaver Voice Testing Backend
#
# Routes to the correct handler based on LAMBDA_HANDLER environment variable:
# - "api" (default): Run REST API with Mangum wrapper for Lambda
# - "websocket": Run WebSocket handler for Lambda (API Gateway WebSocket)
# - "websocket-relay": Run WebSocket relay service for ECS/Fargate
#
# Reference: docs/RUNTIME.md Section 0.9.7 Voice Infrastructure Testing Framework

set -e

HANDLER=${LAMBDA_HANDLER:-api}
PORT=${PORT:-8000}

# Detect runtime environment
# ECS Fargate sets ECS_CONTAINER_METADATA_URI_V4 or ECS_TASK_DEFINITION
# Lambda sets AWS_LAMBDA_FUNCTION_API_VERSION or LAMBDA_TASK_ROOT
# Check ECS FIRST because Lambda base image may set Lambda env vars by default
if [ -n "$ECS_CONTAINER_METADATA_URI_V4" ] || [ -n "$ECS_TASK_DEFINITION" ]; then
    echo "Detected ECS/Fargate environment"
    # Don't exit - continue to handler selection below
elif [ -n "$AWS_LAMBDA_FUNCTION_API_VERSION" ] || [ -n "$LAMBDA_TASK_ROOT" ]; then
    echo "Running in Lambda environment - using Lambda handler"
    # In Lambda, the CMD from Dockerfile is used directly
    # This entrypoint is for ECS/local use only
    exec python -c "import sys; sys.path.insert(0, '/var/task'); from main import lambda_handler; import json; sys.exit(0)"
fi

echo "Starting Workweaver Voice Testing Backend..."
echo "Handler: $HANDLER"
echo "Port: $PORT"

case "$HANDLER" in
    websocket-relay)
        # Run WebSocket relay service (ECS/Fargate)
        # Bridges browser connections to xAI API
        echo "Starting WebSocket relay service on port 8081..."
        exec uvicorn websocket_relay_service:app --host 0.0.0.0 --port 8081 --log-level info
        ;;

    websocket)
        # Run WebSocket handler for Lambda (API Gateway WebSocket)
        # Bare metal handler, no FastAPI
        echo "Starting WebSocket handler for Lambda..."
        exec python -c "
from lambda_handler import lambda_handler
from mangum import Mangum
import os

# Load WebSocket handler
import sys
sys.path.insert(0, '/app')
from websocket_handler import handle_connect, handle_disconnect, handle_subscribe

# Note: Lambda routes to websocket_handler.lambda_handler directly
# This is a fallback for local testing
print('WebSocket handler loaded')
"
        ;;

    api|*)
        # Run REST API with Mangum wrapper (Lambda - default)
        echo "Starting REST API on port $PORT..."
        exec uvicorn main:app --host 0.0.0.0 --port $PORT --log-level info
        ;;
esac
