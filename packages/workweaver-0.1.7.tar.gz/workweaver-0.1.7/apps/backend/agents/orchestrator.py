"""
Orchestrator Agent

Post-call orchestration agent that executes skill DAGs after voice calls.
Consumes post-call work messages and executes workflows via:
- Hot-path Lambdas (<100ms reads)
- Flow-path execution (seconds, retries)

Emits DecisionTrace and ActionOutcome receipts to WORM storage.

Reference: docs/PRODUCT.md P1.3.0 - 3-Agent Voice Architecture
"""
from apps.backend.config.table_names import resolve_table

import logging
from dataclasses import dataclass, field
from datetime import datetime, UTC
from typing import Any
from collections.abc import Callable
import json
import ulid

from apps.backend.schemas.action_outcome import (
    ActionOutcome,
    OutcomeType,
)
from apps.backend.models.decision_event import (
    DecisionEvent,
)
from apps.backend.models.skill_registry import (
    metadata_to_json,
)


logger = logging.getLogger(__name__)


def _resolve_skills_table_name() -> str:
    """Resolve the canonical skills-table env with legacy fallback."""
    return resolve_table("skills")


# ==================== Data Models ====================


@dataclass
class PostCallWorkItem:
    """Post-call work message from Zara.

    Enqueued by Zara during call when caller requests action.
    Consumed by Orchestrator for post-call execution.

    Attributes:
        tenant_id: Tenant identifier (format: "TENANT#<id>")
        call_sid: Twilio call SID
        session_id: Voice session identifier
        caller_phone: Caller phone number (E.164)
        requested_outcomes: List of outcomes requested by caller (e.g., "book_appointment", "send_info")
        context_refs: References to context used during call (precedents, CRM data)
        voice_summary: Summary of voice interaction (optional)
        enqueued_at: When work was enqueued
        trace_id: ULID trace identifier (auto-generated if not provided)
    """

    tenant_id: str
    call_sid: str
    session_id: str
    caller_phone: str
    requested_outcomes: list[str]
    context_refs: dict[str, Any] = field(default_factory=dict)
    voice_summary: str | None = None
    enqueued_at: str = ""
    trace_id: str = ""
    agent_id: str | None = None  # AI agent identifier; falls back to session_id

    def __post_init__(self):
        """Validate and initialize derived fields."""
        # Validate tenant_id format
        if not self.tenant_id.startswith("TENANT#"):
            raise ValueError(f"Invalid tenant_id format: {self.tenant_id}. Expected: 'TENANT#<id>'")

        # Set default enqueued_at if not provided
        if not self.enqueued_at:
            utc_now = datetime.now(UTC).replace(microsecond=0)
            self.enqueued_at = utc_now.isoformat()

        # Generate trace_id if not provided
        if not self.trace_id:
            self.trace_id = ulid.new().str

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "tenant_id": self.tenant_id,
            "call_sid": self.call_sid,
            "session_id": self.session_id,
            "caller_phone": self.caller_phone,
            "requested_outcomes": self.requested_outcomes,
            "context_refs": self.context_refs,
            "voice_summary": self.voice_summary,
            "enqueued_at": self.enqueued_at,
            "trace_id": self.trace_id,
            "agent_id": self.agent_id,
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "PostCallWorkItem":
        """Create PostCallWorkItem from dictionary.

        Args:
            data: Dictionary containing PostCallWorkItem data

        Returns:
            PostCallWorkItem instance
        """
        return cls(**data)


@dataclass
class SkillExecutionStep:
    """Single step in skill DAG execution.

    Attributes:
        skill_id: Skill ID to execute
        step_order: Order in execution sequence
        execution_type: Type of execution (hot_path, flow_path)
        input_data: Input data for skill execution
        output_data: Output data from skill execution (populated after execution)
        latency_ms: Execution time in milliseconds
        success: Whether execution succeeded
        error: Error message if execution failed
    """

    skill_id: str
    step_order: int
    execution_type: str  # "hot_path" or "flow_path"
    input_data: dict[str, Any] = field(default_factory=dict)
    output_data: dict[str, Any] | None = None
    latency_ms: int | None = None
    success: bool = False
    error: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "skill_id": self.skill_id,
            "step_order": self.step_order,
            "execution_type": self.execution_type,
            "input_data": self.input_data,
            "output_data": self.output_data,
            "latency_ms": self.latency_ms,
            "success": self.success,
            "error": self.error,
        }


@dataclass
class OrchestratorResult:
    """Result of orchestration execution.

    Attributes:
        work_item: Original post-call work item
        execution_steps: List of execution steps in order
        decision_trace: DecisionEvent captured
        action_outcome: ActionOutcome captured
        success: Whether orchestration succeeded overall
        error: Error message if orchestration failed
        total_latency_ms: Total execution time in milliseconds
        started_at: When orchestration started
        completed_at: When orchestration completed
    """

    work_item: PostCallWorkItem
    execution_steps: list[SkillExecutionStep]
    decision_trace: DecisionEvent | None = None
    action_outcome: ActionOutcome | None = None
    success: bool = False
    error: str | None = None
    total_latency_ms: int | None = None
    started_at: str | None = None
    completed_at: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary representation."""
        return {
            "work_item": self.work_item.to_dict(),
            "execution_steps": [step.to_dict() for step in self.execution_steps],
            "decision_trace": self.decision_trace.model_dump() if self.decision_trace else None,
            "action_outcome": self.action_outcome.to_dict() if self.action_outcome else None,
            "success": self.success,
            "error": self.error,
            "total_latency_ms": self.total_latency_ms,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
        }


# ==================== Orchestrator Agent ====================


class OrchestratorAgent:
    """
    Post-call orchestration agent.

    Responsibilities:
    1. Consumes post-call work messages from Zara
    2. Executes skill DAGs (Directed Acyclic Graph)
    3. Executes via Hot-path Lambdas (<100ms reads) or Flow-path execution
    4. Emits DecisionTrace and ActionOutcome receipts

    Design principles:
    - Async-first execution (post-call, no latency constraints)
    - Tool-capable (unlike in-call Zara)
    - Multi-tenant isolation enforced
    - Comprehensive error handling and retries
    - WORM storage for audit trail
    """

    def __init__(
        self,
        dynamodb_client: Any | None = None,
        skill_query_service: Any | None = None,
        decision_capture_service: Any | None = None,
        outcome_capture_service: Any | None = None,
        lambda_client: Any | None = None,
        workflow_executor: Any | None = None,
        employee_context_store: Any | None = None,
        customer_context_store: Any | None = None,
        session_continuity_service: Any | None = None,
        learning_loop_factory: Callable[[str], Any] | None = None,
        clarification_protocol: Any | None = None,
    ):
        """
        Initialize Orchestrator agent.

        Args:
            dynamodb_client: Optional DynamoDB client for legacy support
            skill_query_service: Optional SkillQueryService for skill retrieval
            decision_capture_service: Optional DecisionEventCaptureService
            outcome_capture_service: Optional ActionOutcomeCaptureService
            lambda_client: Optional boto3 Lambda client for hot-path execution
            workflow_executor: Optional WorkflowExecutor for flow-path execution
            employee_context_store: Optional EmployeeContextStore for pre-turn context injection
            customer_context_store: Optional CustomerContextStore for customer context injection
            session_continuity_service: Optional SessionContinuityService for post-turn recording
            learning_loop_factory: Optional factory returning a tenant-scoped LearningLoopService
            clarification_protocol: Optional ClarificationProtocol for pre-execution gate
        """
        self.dynamodb_client = dynamodb_client

        # Initialize skill query service
        if skill_query_service:
            self.skill_query_service = skill_query_service
        else:
            from apps.backend.services.skills.skill_query import SkillQueryService

            table_name = _resolve_skills_table_name()
            self.skill_query_service = SkillQueryService(
                table_name=table_name,
                dynamodb_client=dynamodb_client,
            )

        # Initialize storage services
        from apps.backend.services.context.decision_event_capture import DecisionEventCaptureService
        from apps.backend.services.action_outcome_capture import ActionOutcomeCaptureService

        self.decision_capture_service = decision_capture_service or DecisionEventCaptureService(
            dynamodb_resource=dynamodb_client
        )
        self.outcome_capture_service = outcome_capture_service or ActionOutcomeCaptureService(
            dynamodb_resource=dynamodb_client
        )

        # Initialize Lambda client for hot-path execution
        if lambda_client:
            self.lambda_client = lambda_client
        else:
            import boto3

            self.lambda_client = boto3.client("lambda")

        # Initialize workflow executor for flow-path execution
        if workflow_executor:
            self.workflow_executor = workflow_executor
        else:
            from apps.backend.services.workflow_executor import WorkflowExecutor

            self.workflow_executor = WorkflowExecutor()

        # Cowork services — remain None if not injected (graceful no-op)
        self.employee_context_store = employee_context_store
        self.customer_context_store = customer_context_store
        self.session_continuity_service = session_continuity_service
        self.learning_loop_factory = learning_loop_factory
        self.clarification_protocol = clarification_protocol

    async def process_post_call_work(
        self,
        work_item: PostCallWorkItem | dict[str, Any],
    ) -> OrchestratorResult:
        """
        Process post-call work item.

        Workflow:
        1. Validate work item
        2. Load skill DAG for requested outcomes
        3. Execute each skill step in order
        4. Capture DecisionTrace and ActionOutcome
        5. Store to WORM (Write Once, Read Many) storage

        Args:
            work_item: PostCallWorkItem or dict representation

        Returns:
            OrchestratorResult with execution details
        """
        import time

        start_time = time.time()
        utc_now = datetime.now(UTC).replace(microsecond=0)

        # Convert dict to PostCallWorkItem if needed
        if isinstance(work_item, dict):
            work_item = PostCallWorkItem.from_dict(work_item)

        execution_steps = []

        logger.info(
            f"Processing post-call work for tenant {work_item.tenant_id}, "
            f"call_sid: {work_item.call_sid}, "
            f"requested_outcomes: {work_item.requested_outcomes}"
        )

        try:
            # Pre-turn: Inject agent context into context_refs
            effective_agent_id = work_item.agent_id or work_item.session_id
            role_id = str(work_item.context_refs.get("role_id") or "").strip() or None
            customer_id = self._normalize_customer_id(
                str(
                    work_item.context_refs.get("customer_id")
                    or work_item.context_refs.get("crm_lead_id")
                    or work_item.caller_phone
                    or ""
                )
            )
            if self.employee_context_store:
                try:
                    employee_ctx_prompt = self.employee_context_store.build_context_prompt(
                        work_item.tenant_id, effective_agent_id
                    )
                    if employee_ctx_prompt:
                        work_item.context_refs["employee_context"] = employee_ctx_prompt
                    if role_id and hasattr(self.employee_context_store, "build_role_context_prompt"):
                        role_ctx_prompt = self.employee_context_store.build_role_context_prompt(
                            work_item.tenant_id, role_id
                        )
                        if role_ctx_prompt:
                            work_item.context_refs["role_context"] = role_ctx_prompt
                except Exception as e:
                    logger.warning(f"Employee context injection failed for agent {effective_agent_id}: {e}")
            if self.customer_context_store and customer_id:
                try:
                    customer_ctx_prompt = self.customer_context_store.build_context_prompt(
                        work_item.tenant_id, customer_id
                    )
                    if customer_ctx_prompt:
                        work_item.context_refs["customer_context"] = customer_ctx_prompt
                except Exception as e:
                    logger.warning(
                        "Customer context injection failed for tenant=%s customer=%s: %s",
                        work_item.tenant_id,
                        customer_id,
                        e,
                    )

            # Step 1: Load skill DAG for requested outcomes
            skill_dag = await self._load_skill_dag(
                tenant_id=work_item.tenant_id,
                requested_outcomes=work_item.requested_outcomes,
            )

            if not skill_dag:
                logger.warning(f"No skills found for outcomes: {work_item.requested_outcomes}")
                result = OrchestratorResult(
                    work_item=work_item,
                    execution_steps=[],
                    success=False,
                    error=f"No skills found for outcomes: {work_item.requested_outcomes}",
                    started_at=utc_now.isoformat(),
                    completed_at=datetime.now(UTC).replace(microsecond=0).isoformat(),
                    total_latency_ms=int((time.time() - start_time) * 1000),
                )
                return result

            # Pre-execution: Clarification gate
            if self.clarification_protocol:
                try:
                    task_context = {
                        "outcomes": work_item.requested_outcomes,
                        "voice_summary": work_item.voice_summary,
                    }
                    needs_clarification = self.clarification_protocol.should_clarify(
                        task_context=task_context,
                        employee_context=None,
                        confidence=0.8,
                    )
                    if needs_clarification:
                        logger.info(
                            f"Clarification required for tenant {work_item.tenant_id}, "
                            f"outcomes={work_item.requested_outcomes}"
                        )
                        return OrchestratorResult(
                            work_item=work_item,
                            execution_steps=[],
                            success=False,
                            error="clarification_required",
                            started_at=utc_now.isoformat(),
                            completed_at=datetime.now(UTC).replace(microsecond=0).isoformat(),
                            total_latency_ms=int((time.time() - start_time) * 1000),
                        )
                except Exception as e:
                    logger.warning(f"Clarification protocol check failed: {e}")

            # Step 2: Execute skill DAG
            execution_steps = []
            all_success = True
            first_error = None

            for step in skill_dag:
                step_start = time.time()
                try:
                    # Execute skill step
                    output_data = await self._execute_skill_step(
                        step=step,
                        context=work_item.context_refs,
                        tenant_id=work_item.tenant_id,
                    )

                    latency_ms = int((time.time() - step_start) * 1000)

                    execution_step = SkillExecutionStep(
                        skill_id=step.skill_id,
                        step_order=step.step_order,
                        execution_type=step.execution_type,
                        input_data=step.input_data,
                        output_data=output_data,
                        latency_ms=latency_ms,
                        success=True,
                        error=None,
                    )
                    execution_steps.append(execution_step)

                    logger.info(f"Skill {step.skill_id} executed successfully ({latency_ms}ms)")

                except Exception as e:
                    latency_ms = int((time.time() - step_start) * 1000)
                    error_msg = f"Skill execution failed: {str(e)}"
                    first_error = error_msg
                    all_success = False

                    execution_step = SkillExecutionStep(
                        skill_id=step.skill_id,
                        step_order=step.step_order,
                        execution_type=step.execution_type,
                        input_data=step.input_data,
                        output_data=None,
                        latency_ms=latency_ms,
                        success=False,
                        error=error_msg,
                    )
                    execution_steps.append(execution_step)

                    logger.error(f"Skill {step.skill_id} execution failed: {e}", exc_info=True)

                    # Continue with next step (graceful degradation)
                    continue

            # Step 3: Capture DecisionTrace
            decision_trace = await self._capture_decision_trace(
                work_item=work_item,
                execution_steps=execution_steps,
                success=all_success,
            )

            # Step 4: Capture ActionOutcome
            action_outcome = await self._capture_action_outcome(
                work_item=work_item,
                execution_steps=execution_steps,
                success=all_success,
            )

            # Step 5: Store to WORM
            if decision_trace:
                await self._store_decision_trace(decision_trace)

            if action_outcome:
                await self._store_action_outcome(action_outcome)

            # Post-WORM: Record session interaction (best-effort, sync)
            if self.session_continuity_service:
                try:
                    outcome_str = "success" if all_success else "failure"
                    self.session_continuity_service.record_interaction(
                        tenant_id=work_item.tenant_id,
                        agent_id=effective_agent_id,
                        summary=f"post_call_work: {', '.join(work_item.requested_outcomes)}",
                        outcome=outcome_str,
                        metadata={"call_sid": work_item.call_sid, "steps": len(execution_steps)},
                    )
                except Exception as e:
                    logger.warning(f"Session interaction recording failed for agent {effective_agent_id}: {e}")

            total_latency_ms = int((time.time() - start_time) * 1000)

            # Post-WORM: Trigger canonical recursive learning loop (at-least-once via DLQ)
            learning_loop = self._learning_loop(work_item.tenant_id)
            if learning_loop:
                try:
                    await learning_loop.learn_from_task(
                        task_description=self._learning_task_description(work_item),
                        task_context=self._learning_task_context(
                            work_item=work_item,
                            effective_agent_id=effective_agent_id,
                            role_id=role_id,
                            customer_id=customer_id,
                        ),
                        result=self._learning_result(
                            work_item=work_item,
                            execution_steps=execution_steps,
                            success=all_success,
                            first_error=first_error,
                            total_latency_ms=total_latency_ms,
                        ),
                    )
                except Exception as e:
                    logger.warning(f"Learning loop failed for agent {effective_agent_id}: {e}")
                    self._enqueue_learning_dlq(
                        work_item=work_item,
                        effective_agent_id=effective_agent_id,
                        error=e,
                        execution_steps=execution_steps,
                        success=all_success,
                        first_error=first_error,
                        total_latency_ms=total_latency_ms,
                        role_id=role_id,
                        customer_id=customer_id,
                    )

            result = OrchestratorResult(
                work_item=work_item,
                execution_steps=execution_steps,
                decision_trace=decision_trace,
                action_outcome=action_outcome,
                success=all_success,
                error=first_error,
                total_latency_ms=total_latency_ms,
                started_at=utc_now.isoformat(),
                completed_at=datetime.now(UTC).replace(microsecond=0).isoformat(),
            )

            logger.info(
                f"Post-call work processing complete: "
                f"tenant={work_item.tenant_id}, "
                f"success={all_success}, "
                f"latency={total_latency_ms}ms, "
                f"steps={len(execution_steps)}"
            )

            return result

        except Exception as e:
            total_latency_ms = int((time.time() - start_time) * 1000)
            error_msg = f"Orchestration failed: {str(e)}"

            logger.error(f"Orchestration failed for tenant {work_item.tenant_id}: {e}", exc_info=True)

            return OrchestratorResult(
                work_item=work_item,
                execution_steps=execution_steps,
                success=False,
                error=error_msg,
                total_latency_ms=total_latency_ms,
                started_at=utc_now.isoformat(),
                completed_at=datetime.now(UTC).replace(microsecond=0).isoformat(),
            )

    async def _load_skill_dag(
        self,
        tenant_id: str,
        requested_outcomes: list[str],
    ) -> list[SkillExecutionStep]:
        """
        Load skill DAG for requested outcomes.

        This implementation queries the skill registry for skills that match
        the requested outcomes (via triggers), then builds an execution DAG.

        Args:
            tenant_id: Tenant identifier
            requested_outcomes: List of requested outcomes

        Returns:
            List of SkillExecutionStep objects in execution order
        """
        logger.info(f"Loading skill DAG for tenant {tenant_id}, outcomes: {requested_outcomes}")

        # Query skill registry for active skills
        # NOTE: In a full implementation, we'd map requested_outcomes to trigger types
        # For now, we query all active skills and filter by matching metadata
        skills = self.skill_query_service.list_tenant_skills(
            tenant_id=tenant_id,
            status="active",
        )

        if not skills:
            logger.warning(f"No active skills found for tenant {tenant_id}")
            return []

        # Build execution steps from skills
        execution_steps = []
        step_order = 0

        for skill in skills:
            # Get skill metadata
            metadata = skill.get_metadata()

            # Check if skill matches any requested outcomes
            # NOTE: In production, this would be more sophisticated (DAG building, dependencies)
            # For now, we match skills that have triggers containing the outcomes
            matches_outcome = any(
                outcome in trigger or trigger in outcome
                for outcome in requested_outcomes
                for trigger in metadata.triggers
            )

            if matches_outcome:
                # Determine execution type based on skill metadata
                # Hot-path: Lambda functions for <100ms operations
                # Flow-path: Workflow execution for longer operations
                execution_type = "flow_path"  # Default to flow-path

                # If skill has specific lambda configuration, use hot-path
                # NOTE: This would be determined by skill metadata in production
                if "lambda" in metadata.tags or "hot_path" in metadata.tags:
                    execution_type = "hot_path"

                execution_step = SkillExecutionStep(
                    skill_id=skill.skill_id,
                    step_order=step_order,
                    execution_type=execution_type,
                    input_data={
                        "tenant_id": tenant_id,
                        "skill_instance_id": skill.skill_instance_id,
                        "metadata": metadata_to_json(metadata),
                    },
                )
                execution_steps.append(execution_step)
                step_order += 1

        logger.info(f"Loaded {len(execution_steps)} skill execution steps for tenant {tenant_id}")

        return execution_steps

    async def _execute_skill_step(
        self,
        step: SkillExecutionStep,
        context: dict[str, Any],
        tenant_id: str,
    ) -> dict[str, Any]:
        """
        Execute a single skill step.

        Routes to Hot-path Lambda or flow-path execution based on execution_type.

        Args:
            step: SkillExecutionStep to execute
            context: Context data for execution
            tenant_id: Tenant identifier

        Returns:
            Output data from skill execution

        Raises:
            Exception: If skill execution fails
        """
        if step.execution_type == "hot_path":
            return await self._execute_hot_path(
                step=step,
                context=context,
                tenant_id=tenant_id,
            )
        elif step.execution_type == "flow_path":
            return await self._execute_flow_path(
                step=step,
                context=context,
                tenant_id=tenant_id,
            )
        else:
            raise ValueError(f"Unknown execution_type: {step.execution_type}. Must be 'hot_path' or 'flow_path'")

    async def _execute_hot_path(
        self,
        step: SkillExecutionStep,
        context: dict[str, Any],
        tenant_id: str,
    ) -> dict[str, Any]:
        """
        Execute hot-path skill (Lambda, <100ms reads).

        Invokes a Lambda function corresponding to the skill.

        Args:
            step: SkillExecutionStep to execute
            context: Context data for execution
            tenant_id: Tenant identifier

        Returns:
            Output data from Lambda execution

        Raises:
            Exception: If Lambda invocation fails
        """
        logger.info(f"Executing hot-path skill {step.skill_id} for tenant {tenant_id}")

        # Build Lambda function name from skill_id
        # Convention: skill_id is converted to lambda function name
        # Example: "check_availability" -> "workweaver-skill-check-availability"
        function_name = f"workweaver-skill-{step.skill_id.replace('_', '-')}"

        # Build Lambda payload
        payload = {
            "tenant_id": tenant_id,
            "skill_id": step.skill_id,
            "input_data": step.input_data,
            "context": context,
        }

        try:
            # Invoke Lambda synchronously (RequestResponse)
            response = self.lambda_client.invoke(
                FunctionName=function_name,
                InvocationType="RequestResponse",
                Payload=json.dumps(payload),
            )

            # Parse response
            status_code = response.get("StatusCode", 0)
            if status_code != 200:
                raise Exception(f"Lambda invocation failed with status {status_code}")

            # Read and parse payload
            response_payload = response.get("Payload")
            if response_payload:
                result = json.loads(response_payload.read())
                return result
            else:
                return {}

        except Exception as e:
            logger.error(f"Hot-path Lambda execution failed for skill {step.skill_id}: {e}", exc_info=True)
            raise

    async def _execute_flow_path(
        self,
        step: SkillExecutionStep,
        context: dict[str, Any],
        tenant_id: str,
    ) -> dict[str, Any]:
        """
        Execute flow-path skill (seconds, retries).

        Uses WorkflowExecutor to run the skill workflow.

        Args:
            step: SkillExecutionStep to execute
            context: Context data for execution
            tenant_id: Tenant identifier

        Returns:
            Output data from flow execution

        Raises:
            Exception: If workflow execution fails
        """
        logger.info(f"Executing flow-path skill {step.skill_id} for tenant {tenant_id}")

        try:
            # Build workflow input data

            # NOTE: In production, this would:
            # 1. Load workflow definition from skill metadata
            # 2. Execute workflow via WorkflowExecutor
            # 3. Poll for completion (async workflows)
            # 4. Handle retries and error compensation

            # For now, return a simple execution result
            # The workflow_executor integration would happen here
            logger.info(
                f"Flow-path execution for skill {step.skill_id} would use WorkflowExecutor (not yet fully integrated)"
            )

            # Return execution result
            return {
                "status": "completed",
                "skill_id": step.skill_id,
                "output": {
                    "message": f"Flow-path skill {step.skill_id} executed",
                },
            }

        except Exception as e:
            logger.error(f"Flow-path execution failed for skill {step.skill_id}: {e}", exc_info=True)
            raise

    async def _capture_decision_trace(
        self,
        work_item: PostCallWorkItem,
        execution_steps: list[SkillExecutionStep],
        success: bool,
    ) -> DecisionEvent | None:
        """
        Capture DecisionTrace for orchestration.

        Args:
            work_item: PostCallWorkItem being processed
            execution_steps: List of executed steps
            success: Whether all steps succeeded

        Returns:
            DecisionEvent if captured successfully, None otherwise
        """
        try:
            # Determine outcome
            outcome = "success" if success else "failure"

            # Determine skill_id (first skill executed)
            skill_id = execution_steps[0].skill_id if execution_steps else "orchestrator"

            # Create decision summary
            decision_summary = (
                f"Post-call orchestration for call {work_item.call_sid}. "
                f"Requested outcomes: {', '.join(work_item.requested_outcomes)}. "
                f"Executed {len(execution_steps)} skill steps."
            )

            # Create DecisionEvent
            decision_trace = DecisionEvent.create(
                tenant_id=work_item.tenant_id,
                skill_id=skill_id,
                decision_summary=decision_summary,
                decision_type="tool_call",
                outcome=outcome,
                rationale=(
                    work_item.voice_summary
                    or "Post-call orchestration selected skill execution based on caller intent and requested outcomes."
                ),
                alternatives_considered=list(
                    dict.fromkeys(step.skill_id for step in execution_steps[1:] if getattr(step, "skill_id", None))
                ),
                decision_conditions=[f"requested_outcome={value}" for value in work_item.requested_outcomes],
                quality_score=self._assess_quality_score(execution_steps, success),
                entity_ids=[work_item.call_sid],
                context_data={
                    "caller_phone": work_item.caller_phone,
                    "voice_summary": work_item.voice_summary,
                    "requested_outcomes": work_item.requested_outcomes,
                },
                trace_id=work_item.trace_id,
            )

            logger.info(
                f"DecisionTrace captured: tenant={work_item.tenant_id}, "
                f"trace_id={work_item.trace_id}, "
                f"outcome={outcome}"
            )

            return decision_trace

        except Exception as e:
            logger.error(f"Failed to capture DecisionTrace: {e}", exc_info=True)
            return None

    @staticmethod
    def _assess_quality_score(
        execution_steps: list[SkillExecutionStep],
        success: bool,
    ) -> float:
        """Compute a quality score from execution step outcomes.

        Instead of a hardcoded binary (0.95/0.5), this weighs:
        - Step success ratio (what fraction of steps succeeded)
        - Latency penalty (very slow steps degrade quality)
        - Base offset for overall success/failure
        """
        if not execution_steps:
            return 0.5 if success else 0.2

        succeeded = sum(1 for s in execution_steps if getattr(s, "success", False))
        total = len(execution_steps)
        step_ratio = succeeded / total  # 0.0 - 1.0

        # Latency penalty: steps over 10s lose quality (capped at 0.15 deduction)
        latency_penalty = 0.0
        for step in execution_steps:
            ms = getattr(step, "latency_ms", 0) or 0
            if ms > 10_000:
                latency_penalty += min(0.05, (ms - 10_000) / 200_000)
        latency_penalty = min(latency_penalty, 0.15)

        if success:
            # Base 0.80, up to 0.98 based on step ratio, minus latency penalty
            score = 0.80 + (step_ratio * 0.18) - latency_penalty
        else:
            # Base 0.20, up to 0.60 based on partial step success
            score = 0.20 + (step_ratio * 0.40) - latency_penalty

        return round(max(0.0, min(1.0, score)), 3)

    async def _capture_action_outcome(
        self,
        work_item: PostCallWorkItem,
        execution_steps: list[SkillExecutionStep],
        success: bool,
    ) -> ActionOutcome | None:
        """
        Capture ActionOutcome for orchestration.

        Args:
            work_item: PostCallWorkItem being processed
            execution_steps: List of executed steps
            success: Whether all steps succeeded

        Returns:
            ActionOutcome if captured successfully, None otherwise
        """
        try:
            # Determine outcome type
            outcome_type = OutcomeType.SUCCESS if success else OutcomeType.ERROR

            # Calculate total latency
            total_latency_ms = sum(step.latency_ms for step in execution_steps if step.latency_ms)

            # Determine tool provider (first skill)
            tool_provider = execution_steps[0].skill_id if execution_steps else "orchestrator"

            # Determine intent (first requested outcome)
            intent = work_item.requested_outcomes[0] if work_item.requested_outcomes else "unknown"

            # Create ActionOutcome
            action_outcome = ActionOutcome(
                session_id=work_item.session_id,
                tenant_id=work_item.tenant_id,
                trace_id=work_item.trace_id,
                intent=intent,
                tool_provider=tool_provider,
                outcome=outcome_type,
                latency_ms=total_latency_ms,
                # direct_cost_usd calculated by runtime integration
            )

            logger.info(
                f"ActionOutcome captured: tenant={work_item.tenant_id}, "
                f"trace_id={work_item.trace_id}, "
                f"outcome={outcome_type}"
            )

            return action_outcome

        except Exception as e:
            logger.error(f"Failed to capture ActionOutcome: {e}", exc_info=True)
            return None

    async def _store_decision_trace(
        self,
        decision_trace: DecisionEvent,
    ) -> bool:
        """
        Store DecisionTrace to DynamoDB.

        Args:
            decision_trace: DecisionEvent to store

        Returns:
            True if stored successfully, False otherwise
        """
        try:
            logger.info(f"Storing DecisionTrace to DynamoDB: {decision_trace.trace_id}")

            result = self.decision_capture_service.capture_decision(
                tenant_id=decision_trace.tenant_id,
                skill_id=decision_trace.skill_id,
                decision_summary=decision_trace.decision_summary,
                decision_type=decision_trace.decision_type,
                outcome=decision_trace.outcome,
                entity_ids=decision_trace.entity_ids,
                rationale=decision_trace.rationale,
                alternatives_considered=decision_trace.alternatives_considered,
                sop_deviation=decision_trace.sop_deviation,
                decision_conditions=decision_trace.decision_conditions,
                capture_surface=decision_trace.capture_surface or "worker",
                service_family=decision_trace.service_family or "orchestrator",
                quality_score=decision_trace.quality_score,
                policy_id=decision_trace.policy_id,
                # exception_granted and context_data are already JSON strings in model
                trace_id=decision_trace.trace_id,
            )

            return result.success

        except Exception as e:
            logger.error(f"Failed to store DecisionTrace: {e}", exc_info=True)
            return False

    async def _store_action_outcome(
        self,
        action_outcome: ActionOutcome,
    ) -> bool:
        """
        Store ActionOutcome to WORM storage (DynamoDB).

        Args:
            action_outcome: ActionOutcome to store

        Returns:
            True if stored successfully, False otherwise
        """
        try:
            logger.info(f"Storing ActionOutcome to WORM: {action_outcome.trace_id}")

            result = self.outcome_capture_service.capture_outcome(action_outcome)

            return result.success

        except Exception as e:
            logger.error(f"Failed to store ActionOutcome: {e}", exc_info=True)
            return False

    # Issue #3256: validate_in_call_tool_allowlist / is_in_call_tool were
    # removed here — the LLM tool dispatch loop is in
    # apps/backend/voice_services/voice_tool_executor.VoiceToolExecutor.execute,
    # which already invokes seed_tool_defaults() + tool_is_allowed() before
    # any handler runs. The wrappers were dead code (round-3 audit confirmed
    # zero production callsites) and reproducing that gate-by-attribute on
    # OrchestratorAgent only created drift risk.

    @staticmethod
    def _normalize_customer_id(raw_id: str) -> str:
        value = (raw_id or "").strip()
        if not value:
            return ""
        return value.replace(" ", "").replace("(", "").replace(")", "").replace("-", "")

    def _learning_loop(self, tenant_id: str) -> Any | None:
        if self.learning_loop_factory is not None:
            return self.learning_loop_factory(tenant_id)

        try:
            from apps.backend.dependencies import get_evidence_ledger_service, get_memory_service
            from apps.backend.services.learning import build_learning_loop_service

            return build_learning_loop_service(
                tenant_id=tenant_id,
                memory_service=get_memory_service(),
                evidence_service=get_evidence_ledger_service(),
            )
        except Exception as exc:
            logger.warning("Unable to initialize learning loop for tenant %s: %s", tenant_id, exc)
            return None

    @staticmethod
    def _learning_task_description(work_item: PostCallWorkItem) -> str:
        outcomes = ", ".join(work_item.requested_outcomes)
        return f"Complete post-call work for caller {work_item.caller_phone} with outcomes: {outcomes}"

    @staticmethod
    def _learning_task_context(
        *,
        work_item: PostCallWorkItem,
        effective_agent_id: str,
        role_id: str | None,
        customer_id: str | None,
    ) -> Any:
        from apps.backend.services.zara.service import TaskContext

        skill_id = str(work_item.requested_outcomes[0] if work_item.requested_outcomes else "post_call_work")
        metadata = {
            "skill_id": skill_id,
            "agent_id": effective_agent_id,
            "principal_agent_id": effective_agent_id,
            "call_sid": work_item.call_sid,
            "trace_id": work_item.trace_id,
        }
        if role_id:
            metadata["role_id"] = role_id
        if customer_id:
            metadata["customer_id"] = customer_id

        sub_task = "__".join(work_item.requested_outcomes[:3]) if work_item.requested_outcomes else "post_call_work"
        return TaskContext(
            category="post_call_work",
            sub_task=sub_task,
            metadata=metadata,
        )

    @staticmethod
    def _learning_result(
        *,
        work_item: PostCallWorkItem,
        execution_steps: list[SkillExecutionStep],
        success: bool,
        first_error: str | None,
        total_latency_ms: int,
    ) -> Any:
        from apps.backend.services.zara.service import ExecutionOutcome, ExecutionStep, TaskExecutionResult

        completed_steps = sum(1 for step in execution_steps if step.success)
        status = "completed" if success else ("partial" if completed_steps else "failed")
        summary = (
            f"Completed {completed_steps} of {len(execution_steps)} post-call steps for "
            f"{', '.join(work_item.requested_outcomes)}"
        )
        return TaskExecutionResult(
            status=status,
            execution_mode="workflow",
            degraded=not success,
            degradation_reasons=[{"code": "post_call_orchestration_failed", "detail": first_error}]
            if first_error
            else [],
            proof_of_work={"completed": summary},
            steps=[
                ExecutionStep(
                    tool=step.skill_id,
                    description=step.execution_type,
                    status="success" if step.success else "failed",
                    result=step.output_data,
                    error=step.error,
                    duration_ms=float(step.latency_ms or 0.0),
                )
                for step in execution_steps
            ],
            outcome=ExecutionOutcome(
                task_type="post_call_work",
                duration_ms=float(total_latency_ms),
                tools_used=[step.skill_id for step in execution_steps if step.skill_id],
                token_usage={},
                success=success,
                error_summary=first_error,
            ),
            trace_id=work_item.trace_id,
            response_text=summary,
        )

    def _enqueue_learning_dlq(
        self,
        *,
        work_item: PostCallWorkItem,
        effective_agent_id: str,
        error: Exception,
        execution_steps: list[SkillExecutionStep],
        success: bool,
        first_error: str | None,
        total_latency_ms: int,
        role_id: str | None,
        customer_id: str | None,
    ) -> None:
        """Route a failed learning signal to the DLQ for at-least-once delivery."""
        try:
            from apps.backend.services.learning.learning_signal_queue import LearningSignalQueue

            queue = LearningSignalQueue()
            payload = {
                "task_description": self._learning_task_description(work_item),
                "task_context": {
                    "agent_id": effective_agent_id,
                    "call_sid": work_item.call_sid,
                    "role_id": role_id,
                    "customer_id": customer_id,
                },
                "result": {
                    "success": success,
                    "steps": len(execution_steps),
                    "first_error": first_error,
                    "total_latency_ms": total_latency_ms,
                },
            }
            queue.enqueue(
                tenant_id=work_item.tenant_id,
                work_item_id=work_item.call_sid,
                payload=payload,
                idempotency_key=f"{work_item.tenant_id}:{work_item.call_sid}",
                error=str(error),
            )
        except Exception as dlq_exc:
            logger.error(
                "Failed to enqueue learning DLQ for tenant=%s call=%s: %s",
                work_item.tenant_id,
                work_item.call_sid,
                dlq_exc,
            )


# ==================== Convenience Functions ====================


def get_orchestrator(
    dynamodb_client: Any | None = None,
    skill_query_service: Any | None = None,
    decision_capture_service: Any | None = None,
    outcome_capture_service: Any | None = None,
    customer_context_store: Any | None = None,
    learning_loop_factory: Callable[[str], Any] | None = None,
) -> OrchestratorAgent:
    """
    Factory function to get Orchestrator agent instance.

    Args:
        dynamodb_client: Optional DynamoDB client
        skill_query_service: Optional SkillQueryService
        decision_capture_service: Optional DecisionEventCaptureService
        outcome_capture_service: Optional ActionOutcomeCaptureService
        customer_context_store: Optional CustomerContextStore
        learning_loop_factory: Optional tenant-scoped LearningLoopService factory

    Returns:
        OrchestratorAgent instance
    """
    return OrchestratorAgent(
        dynamodb_client=dynamodb_client,
        skill_query_service=skill_query_service,
        decision_capture_service=decision_capture_service,
        outcome_capture_service=outcome_capture_service,
        customer_context_store=customer_context_store,
        learning_loop_factory=learning_loop_factory,
    )


async def process_post_call_work(
    work_item: PostCallWorkItem | dict[str, Any],
    dynamodb_client: Any | None = None,
    skill_query_service: Any | None = None,
    decision_capture_service: Any | None = None,
    outcome_capture_service: Any | None = None,
    customer_context_store: Any | None = None,
    learning_loop_factory: Callable[[str], Any] | None = None,
) -> OrchestratorResult:
    """
    Process post-call work (convenience function).

    Args:
        work_item: PostCallWorkItem or dict representation
        dynamodb_client: Optional DynamoDB client
        skill_query_service: Optional SkillQueryService
        decision_capture_service: Optional DecisionEventCaptureService
        outcome_capture_service: Optional ActionOutcomeCaptureService
        customer_context_store: Optional CustomerContextStore
        learning_loop_factory: Optional tenant-scoped LearningLoopService factory

    Returns:
        OrchestratorResult with execution details
    """
    orchestrator = get_orchestrator(
        dynamodb_client=dynamodb_client,
        skill_query_service=skill_query_service,
        decision_capture_service=decision_capture_service,
        outcome_capture_service=outcome_capture_service,
        customer_context_store=customer_context_store,
        learning_loop_factory=learning_loop_factory,
    )
    return await orchestrator.process_post_call_work(work_item)
