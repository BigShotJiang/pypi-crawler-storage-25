"""Agents package for Workweaver.

This package contains autonomous agents that handle various tasks:
- ContextLoader: Loads context before voice calls
- Orchestrator: Coordinates skill execution
- Zara: Voice AI persona
"""
