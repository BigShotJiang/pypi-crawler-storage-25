"""Dedicated Lambda handler for the managed public-edge health route."""

from __future__ import annotations

import json
from typing import Any

try:
    from apps.backend.services.public_health_contract import build_public_health_payload
except ImportError:  # pragma: no cover - Lambda zip root import path
    from services.public_health_contract import build_public_health_payload  # type: ignore[no-redef]

_ALLOWED_ORIGINS = {"https://workweaver.ai", "https://www.workweaver.ai"}


def _trusted_origin(headers: dict[str, Any]) -> str:
    origin = str(headers.get("origin") or headers.get("Origin") or "").strip()
    return origin if origin in _ALLOWED_ORIGINS else ""


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Serve the canonical public health payload through HTTP API v2."""

    _ = context
    method = ((event.get("requestContext") or {}).get("http") or {}).get("method", "GET").upper()
    headers = event.get("headers") or {}
    origin = _trusted_origin(headers)

    if method == "OPTIONS":
        response_headers = {
            "Access-Control-Allow-Methods": "GET,OPTIONS",
            "Access-Control-Allow-Headers": "content-type,authorization,x-request-id",
            "Access-Control-Max-Age": "86400",
        }
        if origin:
            response_headers["Access-Control-Allow-Origin"] = origin
        return {
            "statusCode": 200,
            "headers": response_headers,
            "body": "",
        }

    body = build_public_health_payload()
    response_headers = {"content-type": "application/json"}
    if origin:
        response_headers["Access-Control-Allow-Origin"] = origin

    return {
        "statusCode": 200,
        "headers": response_headers,
        "body": json.dumps(body),
    }
