"""Unified Lambda Handler for Workweaver API

Thin dispatcher that routes to the appropriate entry point based on
the LAMBDA_HANDLER environment variable:

- "api" or not set: REST API handler (FastAPI with Mangum)
- "websocket": WebSocket handler for real-time latency streaming

Each entry point lives in its own module under ``apps.backend.entrypoints/``
so only the dependencies needed for the active handler are loaded:

- ``entrypoints/http.py`` — full FastAPI stack, HTTP middleware, router registry
- ``entrypoints/websocket.py`` — bare-metal WebSocket Lambda, no FastAPI imports
- ``entrypoints/_shared_startup.py`` — logging config shared by both

Issue #3795: architecture(entrypoints): split WebSocket from HTTP routing.
"""

from apps.backend.entrypoints._shared_startup import configure_logging, get_handler_type

# Configure logging before dispatching
configure_logging()

handler_type = get_handler_type()

if handler_type == "websocket":
    from apps.backend.entrypoints.websocket import lambda_handler  # noqa: F401
else:
    from apps.backend.entrypoints.http import lambda_handler  # noqa: F401

# Also export the FastAPI app for ASGI servers (uvicorn, etc.)
# that import ``app`` directly. Only available in HTTP mode.
if handler_type != "websocket":
    from apps.backend.entrypoints.http import app  # noqa: F401
