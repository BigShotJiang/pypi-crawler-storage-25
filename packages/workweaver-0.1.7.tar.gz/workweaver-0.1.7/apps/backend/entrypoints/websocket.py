"""WebSocket entrypoint for Workweaver backend.

Bare-metal Lambda handler for API Gateway WS events.
Does NOT import FastAPI, Mangum, HTTP middleware, or the router registry.

Routes:
    $connect    -> handle_connect
    $disconnect -> handle_disconnect
    subscribe   -> handle_subscribe
    default     -> 400 Unknown route

Issue #3795: architecture(entrypoints): split WebSocket from HTTP routing.
"""

import logging

from apps.backend.entrypoints._shared_startup import configure_logging

# Configure logging before any other imports
configure_logging()
logger = logging.getLogger(__name__)

logger.info("Initializing WS entrypoint")


def lambda_handler(event: dict, context) -> dict:
    """Route WS events to appropriate handler.

    This is the Lambda entry point for API Gateway WS APIs.
    It dispatches based on the routeKey in the requestContext.
    """
    from apps.backend.websocket_handler import (
        handle_connect,
        handle_disconnect,
        handle_subscribe,
    )

    route_key = (event.get("requestContext") or {}).get("routeKey", "")

    if route_key == "$connect":
        return handle_connect(event)
    elif route_key == "$disconnect":
        return handle_disconnect(event)
    elif route_key == "subscribe":
        return handle_subscribe(event)
    else:
        logger.warning("Unknown WS route: %s", route_key)
        return {"statusCode": 400, "body": f'{{"error": "Unknown route: {route_key}"}}'}
