"""Shared startup configuration for Workweaver entrypoints.

Contains configuration that both the HTTP and WS entry points
need: logging, environment validation, and common constants.

This module must NOT import HTTP-specific modules (FastAPI middleware,
router registry) or WS-specific handler modules.

Issue #3795: architecture(entrypoints): split WebSocket from HTTP routing.
"""

import logging
import os


def configure_logging() -> None:
    """Configure backend logging with structured format and noisy logger suppression.

    Both HTTP and WS Lambdas need consistent logging. This function
    sets up the root logger and quiets noisy dependency loggers that can
    leak sensitive data (Authorization headers, request bodies) at DEBUG level.
    """
    log_level = os.environ.get("LOG_LEVEL", "INFO")
    logging.basicConfig(
        level=getattr(logging, log_level),
        format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    )

    # Never allow verbose HTTP/WebSocket debug logs in the backend:
    # - AWS SDK + urllib can include request/response bodies
    # - websockets can include Authorization headers when debug is enabled
    # Keep these quiet even when LOG_LEVEL=DEBUG.
    for noisy in (
        "botocore",
        "boto3",
        "urllib3",
        "websockets",
        "websockets.client",
        "websockets.server",
        "httpx",
        "httpcore",
        "twilio",
    ):
        logging.getLogger(noisy).setLevel(logging.WARNING)


def get_handler_type() -> str:
    """Read the LAMBDA_HANDLER env var to determine which entry point to use.

    Returns:
        "websocket" or "api" (default).
    """
    return os.environ.get("LAMBDA_HANDLER", "api")
