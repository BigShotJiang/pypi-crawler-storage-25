"""Entrypoint package for Workweaver backend.

Provides separate entry points for HTTP and WebSocket handlers so
each Lambda loads only the dependencies it needs.

Issue #3795: architecture(entrypoints): split WebSocket from HTTP routing.
"""
