"""Validation package — golden trace cluster removed."""
