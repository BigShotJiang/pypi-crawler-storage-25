"""Backward-compatibility re-export of delta_j_calculator.

The canonical location is apps.backend.services.skills.promotion.delta_j_calculator.
This module exists only to keep old import paths working.
"""

from apps.backend.services.skills.promotion.delta_j_calculator import (  # noqa: F401
    DeltaJCalculator,
    DeltaJObservation,
    DeltaJResult,
    GradientEngine,
    GradientResult,
    LossSnapshot,
    LossWeights,
)
