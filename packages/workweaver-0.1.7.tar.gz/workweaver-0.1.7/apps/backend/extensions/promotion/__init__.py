"""Backward-compatibility shim for the old promotion module path.

New code should import from apps.backend.services.skills.promotion directly.
This package re-exports the full canonical API so existing ``from
apps.backend.extensions.promotion import X`` call-sites continue to work without
modification.
"""

from apps.backend.services.skills.promotion import (  # noqa: F401
    ComparisonEvidence,
    DeltaJCalculator,
    DeltaJObservation,
    GradientEngine,
    GradientResult,
    LossSnapshot,
    LossWeights,
    MirrorBuffer,
    MirroredRequest,
    SemanticComparator,
    TrafficMirrorService,
)

__all__ = [
    "ComparisonEvidence",
    "DeltaJCalculator",
    "DeltaJObservation",
    "GradientEngine",
    "GradientResult",
    "LossSnapshot",
    "LossWeights",
    "MirrorBuffer",
    "MirroredRequest",
    "SemanticComparator",
    "TrafficMirrorService",
]
