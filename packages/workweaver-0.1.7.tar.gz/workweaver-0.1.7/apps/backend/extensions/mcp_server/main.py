#!/usr/bin/env python3
"""
MCP Server - Exposes Workweaver Skills as MCP tools.

Model Context Protocol (MCP) server that allows AI agents (Claude, GPT, etc.)
to discover and invoke Workweaver skills as tools.

Implementation Reference:
- docs/PRODUCT.md P1.1.6 (lines 3050-3121)
"""

from __future__ import annotations

import logging
import sys
from pathlib import Path
from typing import Dict, Any

from fastapi import FastAPI, HTTPException, Request, status
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

logger = logging.getLogger(__name__)

# Add repo root to path for imports
repo_root = Path(__file__).resolve().parents[2]
if str(repo_root) not in sys.path:
    sys.path.insert(0, str(repo_root))

from apps.backend.services.skills.skill_query import SkillQueryService
from apps.backend.extensions.mcp.skill_to_mcp_transformer import transform_skill_to_mcp_tool


_CONTEXT_AUTH_TOOLS = frozenset(
    {
        "ww.operational_context.workspace",
        "workweaver.operational_context.workspace",
        "ww.operational_context.share",
        "workweaver.operational_context.share",
    }
)


class _UnavailableSkillQueryService:
    """Local fallback when the skill registry backend is unavailable."""

    def __init__(self, table_name: str) -> None:
        self.table_name = table_name

    def list_tenant_skills(self, **_kwargs: Any) -> list[dict[str, Any]]:
        return []


def _extract_plugin_api_key(request: Request) -> str | None:
    auth_header = str(request.headers.get("authorization") or "").strip()
    if not auth_header.lower().startswith("bearer "):
        return None
    token = auth_header.split(" ", 1)[1].strip()
    return token if token.startswith("ww_sk_") else None


def _lookup_api_key_actor_record(raw_key: str) -> dict[str, Any]:
    """Return the API-key lookup record so actor identity stays bound to the key."""
    from apps.backend.api.dependencies.plugin_auth import _lookup_api_key_record

    return _lookup_api_key_record(raw_key) or {}


def _api_key_tenant_matches(record_tenant_id: str, request_tenant_id: str) -> bool:
    from apps.backend.utils.tenant import strip_tenant_prefix

    return strip_tenant_prefix(record_tenant_id) == strip_tenant_prefix(request_tenant_id)


def _resolve_api_key_actor_role(tenant_id: str, user_id: str) -> Any:
    from apps.backend.api.dependencies.tenant_auth import _resolve_user_record
    from apps.backend.models.user import UserRole
    from apps.backend.utils.tenant import strip_tenant_prefix

    record = _resolve_user_record(strip_tenant_prefix(tenant_id), user_id)
    role_value = str(record.get("role", "")).strip().lower()
    try:
        return UserRole(role_value) if role_value else UserRole.AGENT
    except ValueError:
        return UserRole.AGENT


def _requires_plugin_api_key_auth() -> bool:
    from apps.backend.config.environment import get_environment

    return get_environment() in {"prod", "production", "staging"}


def _resolve_middleware_api_key_actor(request: Request, tenant_id: str) -> str | None:
    state_tenant_id = str(getattr(request.state, "authenticated_tenant_id", "") or "").strip()
    if not state_tenant_id:
        return None
    if not _api_key_tenant_matches(state_tenant_id, tenant_id):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Tenant ID mismatch between route and API key")

    user_id = str(
        getattr(request.state, "authenticated_user_id", None)
        or getattr(request.state, "user_id", None)
        or ""
    ).strip()
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API key is not bound to a user",
        )
    return user_id


def _resolve_api_key_bound_actor(request: Request, tenant_id: str) -> tuple[str | None, Any | None]:
    raw_key = _extract_plugin_api_key(request)
    if not raw_key:
        return None, None

    state_user_id = _resolve_middleware_api_key_actor(request, tenant_id)
    if state_user_id:
        return state_user_id, _resolve_api_key_actor_role(tenant_id, state_user_id)

    record = getattr(request.state, "plugin_api_key_record", None)
    if not isinstance(record, dict) or not record:
        if not _requires_plugin_api_key_auth():
            return None, None
        record = _lookup_api_key_actor_record(raw_key)
    if not record:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="Invalid API key")

    record_tenant_id = str(record.get("tenant_id") or "").strip()
    if not record_tenant_id or not _api_key_tenant_matches(record_tenant_id, tenant_id):
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Tenant ID mismatch between route and API key")

    user_id = str(record.get("user_id") or "").strip()
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API key is not bound to a user",
        )

    request.state.user_id = user_id
    request.state.authenticated_user_id = user_id
    return user_id, _resolve_api_key_actor_role(tenant_id, user_id)


def _resolve_context_tool_actor(request: Request, tenant_id: str) -> tuple[str | None, Any | None]:
    api_key_actor_id, api_key_actor_role = _resolve_api_key_bound_actor(request, tenant_id)
    if api_key_actor_id:
        return api_key_actor_id, api_key_actor_role

    from apps.backend.api.dependencies.tenant_auth import (
        get_verified_user_id,
        get_verified_user_role,
    )

    verified_actor_id = get_verified_user_id(
        request=request,
        x_user_id=str(request.headers.get("x-user-id") or "").strip() or None,
    )
    verified_actor_role = get_verified_user_role(
        request=request,
        tenant_id=tenant_id,
    )
    return verified_actor_id, verified_actor_role


class MCPServer:
    """
    MCP Server implementation for exposing Skills as MCP tools.
    """

    def __init__(
        self, skills_table: str | None = None, region: str = "us-east-1", host: str = "0.0.0.0", port: int = 8379
    ):
        """
        Initialize MCP server.

        Args:
            skills_table: DynamoDB table name for skills
            region: AWS region
            host: Host to bind to
            port: Port to listen on
        """
        self.host = host
        self.port = port
        self.skills_table = skills_table or "workweaver-skills-prod"

        # Initialize FastAPI app
        self.app = FastAPI(
            title="Workweaver MCP Server",
            description="Model Context Protocol server for Workweaver Skills",
            version="1.0.0",
        )

        # Initialize skill query service. Local unit/runtime smoke paths should
        # still boot if the DynamoDB resource model is unavailable.
        try:
            self.skill_query = SkillQueryService(table_name=self.skills_table, region_name=region)
        except Exception as exc:  # noqa: BLE001
            logger.warning("mcp_server.skill_query_unavailable: %s", exc)
            self.skill_query = _UnavailableSkillQueryService(self.skills_table)

        self._setup_middleware()
        self._setup_cors()
        self._setup_routes()

    def _setup_middleware(self):
        """Setup middleware for MCP server."""
        from apps.backend.extensions.mcp_server.middleware.tenant_isolation import TenantIsolationMiddleware

        # Add tenant isolation middleware
        self.app.add_middleware(TenantIsolationMiddleware)

    def _setup_cors(self):
        """Setup CORS middleware for MCP clients."""
        from apps.backend.config.environment import is_production_like

        if is_production_like():
            origins = [
                "https://workweaver.ai",
                "https://www.workweaver.ai",
                "https://infra.workweaver.ai",
            ]
        else:
            origins = [
                "http://localhost:3000",
                "http://localhost:3001",
                "http://127.0.0.1:3000",
                "http://127.0.0.1:3001",
            ]
        self.app.add_middleware(
            CORSMiddleware,
            allow_origins=origins,
            allow_credentials=True,
            allow_methods=["*"],
            allow_headers=["*"],
        )

    def _setup_routes(self):
        """Setup MCP protocol endpoints."""

        @self.app.get("/")
        async def root():
            """Root endpoint - server info."""
            return {
                "name": "Workweaver MCP Server",
                "version": "1.0.0",
                "protocol": "Model Context Protocol",
                "endpoints": {
                    "tools": "/mcp/v1/tools",
                    "tools_index": "/mcp/v1/tools/index",
                    "tools_search": "/mcp/v1/tools/search",
                    "tool_schema": "/mcp/v1/tools/{tool_name}/schema",
                    "call_tool": "/mcp/v1/tools/{tool_name}/call",
                    "skills": "/mcp/v1/skills",
                    "health": "/health",
                },
            }

        @self.app.get("/health")
        async def health():
            """Health check endpoint."""
            return {"status": "healthy", "version": "1.0.0", "skills_table": self.skills_table}

        @self.app.get("/mcp/v1/tools")
        async def list_tools(request: Request):
            """
            List available MCP tools (exposed skills + public tenant tools).

            Returns array of tool schemas according to MCP protocol.
            Includes both skill-based tools and the M5.1 public tenant tools
            (workweaver.task.*, workweaver.agent.*, etc.).
            """
            from apps.backend.extensions.mcp_server.middleware.tenant_isolation import extract_tenant_id

            tenant_id = extract_tenant_id(request)

            try:
                # Query active skills from registry
                skills = self.skill_query.list_tenant_skills(tenant_id=tenant_id, status_filter="active")

                # Transform skills to MCP tool schemas
                tools = [self._skill_to_mcp_tool(skill) for skill in skills]

                # Append canonical public tenant tools (M5.1)
                from apps.backend.api.public_mcp import PUBLIC_MCP_TOOLS

                tools.extend(PUBLIC_MCP_TOOLS)

                return {"version": "1.0", "tools": tools}
            except Exception as e:
                logger.error("Failed to list tools: %s", e)
                raise HTTPException(status_code=500, detail="Failed to list tools")

        @self.app.get("/mcp/v1/tools/index")
        async def tools_index():
            """Return a compact, progressive-disclosure index of public MCP tools."""
            from apps.backend.api.public_mcp import get_public_mcp_tool_index

            return {"version": "1.0", "tools": get_public_mcp_tool_index()}

        @self.app.post("/mcp/v1/tools/search")
        async def tools_search(request: Request):
            """Search public MCP tools by natural-language intent."""
            try:
                body = await request.json()
            except Exception as e:
                logger.error("Invalid tool search request body: %s", e)
                raise HTTPException(status_code=400, detail="Invalid request body")

            from apps.backend.api.public_mcp import search_public_mcp_tools

            intent = str(body.get("intent") or body.get("query") or "").strip()
            limit = int(body.get("limit") or 5)
            return {"version": "1.0", "matches": search_public_mcp_tools(intent, limit=limit)}

        @self.app.get("/mcp/v1/tools/{tool_name}/schema")
        async def tool_schema(tool_name: str):
            """Return the full JSON schema for one public MCP tool or compatibility alias."""
            from apps.backend.api.public_mcp import get_public_mcp_tool_schema

            try:
                return {"version": "1.0", "tool": get_public_mcp_tool_schema(tool_name)}
            except KeyError as e:
                raise HTTPException(status_code=404, detail=f"Unknown public MCP tool: {tool_name}") from e

        @self.app.get("/mcp/v1/skills")
        async def list_skills(request: Request):
            """
            List skill metadata.

            Returns detailed skill metadata for discovery.
            """
            from apps.backend.extensions.mcp_server.middleware.tenant_isolation import extract_tenant_id

            tenant_id = extract_tenant_id(request)

            try:
                skills = self.skill_query.list_tenant_skills(tenant_id=tenant_id)

                return {"version": "1.0", "skills": skills}
            except Exception as e:
                logger.error("Failed to list skills: %s", e)
                raise HTTPException(status_code=500, detail="Failed to list skills")

        @self.app.post("/mcp/v1/tools/{tool_name}/call")
        async def call_tool(tool_name: str, request: Request):
            """
            Invoke MCP tool (execute skill or public tenant tool).

            Args:
                tool_name: Name of tool to invoke.
                    - Skill tools: format workweaver_{skill_id}
                    - Public tools (M5.1): canonical format ww.{domain}.{action};
                      legacy workweaver.{domain}.{action} aliases still dispatch.
                request: HTTP request with tool parameters in body
            """
            from apps.backend.extensions.mcp_server.middleware.tenant_isolation import extract_tenant_id

            # Extract tenant_id from request state (set by middleware)
            tenant_id = extract_tenant_id(request)

            # Parse request body
            try:
                body = await request.json()
                parameters = body.get("parameters", {})
            except Exception as e:
                logger.error("Invalid request body: %s", e)
                raise HTTPException(status_code=400, detail="Invalid request body")

            # Check if this is a public tenant tool (M5.1: ww.{domain}.{action} plus legacy aliases)
            from apps.backend.api.public_mcp import is_public_mcp_tool

            if is_public_mcp_tool(tool_name):
                try:
                    from apps.backend.api.public_mcp import dispatch_mcp_tool

                    verified_actor_id = None
                    verified_actor_role = None
                    if tool_name in _CONTEXT_AUTH_TOOLS:
                        verified_actor_id, verified_actor_role = _resolve_context_tool_actor(request, tenant_id)

                    result = await dispatch_mcp_tool(
                        tool_name=tool_name,
                        tenant_id=tenant_id,
                        parameters=parameters,
                        verified_actor_id=verified_actor_id,
                        verified_actor_role=verified_actor_role,
                    )
                    return {"result": result}
                except ValueError as e:
                    raise HTTPException(status_code=404, detail=str(e))
                except KeyError as e:
                    raise HTTPException(status_code=404, detail=str(e))
                except HTTPException:
                    raise
                except PermissionError as e:
                    raise HTTPException(status_code=403, detail=str(e) or "forbidden")
                except Exception as e:
                    logger.error("Failed to invoke public tool %s: %s", tool_name, e)
                    raise HTTPException(status_code=500, detail="Failed to invoke tool")

            # Fall through to skill-based tool execution
            from apps.backend.extensions.mcp_server.endpoints.execute_tool import execute_tool

            try:
                result = await execute_tool(
                    tool_name=tool_name,
                    request=request,
                    skill_query_service=self.skill_query,
                    tenant_id=tenant_id,
                    parameters=parameters,
                )
                return result
            except HTTPException:
                raise
            except Exception as e:
                logger.error("Failed to invoke tool: %s", e)
                raise HTTPException(status_code=500, detail="Failed to invoke tool")

    def _skill_to_mcp_tool(self, skill: Dict[str, Any]) -> Dict[str, Any]:
        """
        Transform skill definition to MCP tool schema.

        Args:
            skill: Skill definition from SkillQueryService

        Returns:
            MCP tool schema (name, description, inputSchema)
        """
        # Use skill_to_mcp_tool transformer (TASK-1.8.002)
        return transform_skill_to_mcp_tool(skill)


def main():
    """Run MCP server."""
    import argparse

    parser = argparse.ArgumentParser(description="Workweaver MCP Server")
    parser.add_argument("--host", default="0.0.0.0", help="Host to bind to")
    parser.add_argument("--port", type=int, default=8379, help="Port to listen on")
    parser.add_argument("--skills-table", default="workweaver-skills-prod", help="DynamoDB table name for skills")
    parser.add_argument("--region", default="us-east-1", help="AWS region")
    parser.add_argument("--dev", action="store_true", help="Run in development mode with auto-reload")

    args = parser.parse_args()

    server = MCPServer(skills_table=args.skills_table, region=args.region, host=args.host, port=args.port)

    print("Starting Workweaver MCP Server")
    print(f"Host: {args.host}:{args.port}")
    print(f"Skills table: {args.skills_table}")
    print(f"Region: {args.region}")
    print("\nEndpoints:")
    print("  - GET /mcp/v1/tools          List MCP tools")
    print("  - GET /mcp/v1/skills         List skills metadata")
    print("  - POST /mcp/v1/tools/{tool_name}/call  Invoke tool")
    print("  - GET /health                 Health check")

    if args.dev:
        uvicorn.run(server.app, host=args.host, port=args.port, reload=True)
    else:
        uvicorn.run(server.app, host=args.host, port=args.port)


if __name__ == "__main__":
    main()
