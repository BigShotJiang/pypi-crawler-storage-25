"""
Workweaver MCP Server

Exposes Workweaver Skills as Model Context Protocol (MCP) tools.
"""

__version__ = "1.0.0"
