#!/usr/bin/env python3
"""
MCP Tool Execution Endpoint

Handles MCP tool invocation for Workweaver Skills.

Implementation Reference:
- docs/PRODUCT.md P1.1.6 (lines 3050-3121)
- TASK-1.8.003: Build MCP tool execution endpoint (skill invocation)
"""

from __future__ import annotations

import logging
from typing import Dict, Any, Optional
from fastapi import Request, HTTPException
from pydantic import BaseModel, Field
import ulid

logger = logging.getLogger(__name__)


class ToolCallRequest(BaseModel):
    """MCP tool call request body."""

    tenant_id: str = Field(..., description="Tenant ID for multi-tenancy")
    parameters: Optional[Dict[str, Any]] = Field(default_factory=dict, description="Tool input parameters")


class ToolExecutionResult(BaseModel):
    """MCP tool execution result."""

    status: str = Field(..., description="Execution status (success, failure, error)")
    tool_name: str = Field(..., description="Name of tool that was executed")
    skill_id: str = Field(..., description="ID of skill that was invoked")
    result: Optional[Dict[str, Any]] = Field(default=None, description="Execution result data (skill-specific)")
    error: Optional[str] = Field(default=None, description="Error message if execution failed")
    execution_id: str = Field(default_factory=lambda: str(ulid.new()), description="Unique execution ID for tracing")


async def execute_tool(
    tool_name: str, request: Request, skill_query_service: Any, tenant_id: str, parameters: Dict[str, Any]
) -> Dict[str, Any]:
    """
    Execute MCP tool (invoke Workweaver skill).

    Args:
        tool_name: Name of tool to invoke (format: workweaver_{skill_id})
        request: FastAPI request object
        skill_query_service: SkillQueryService instance
        tenant_id: Tenant ID for multi-tenancy
        parameters: Tool input parameters

    Returns:
        MCP tool execution result

    Example:
        ```python
        result = await execute_tool(
            tool_name="workweaver_answer_call",
            request=request,
            skill_query_service=skill_query,
            tenant_id="TENANT#demo",
            parameters={"caller_id": "+971501234567"}
        )

        # Returns:
        {
            "version": "1.0",
            "status": "success",
            "tool_name": "workweaver_answer_call",
            "skill_id": "answer_call",
            "result": {
                "intent": "schedule_viewing",
                "caller_phone": "+971501234567"
            },
            "execution_id": "01H...",  # ULID
            "metadata": {
                "execution_time_ms": 50,
                "tenant_id": "TENANT#demo"
            }
        }
        ```
    """
    # Extract skill_id from tool_name (format: workweaver_{skill_id})
    if not tool_name.startswith("workweaver_"):
        raise HTTPException(
            status_code=400, detail=f"Invalid tool name format: {tool_name}. Expected: workweaver_{{skill_id}}"
        )

    skill_id = tool_name[len("workweaver_") :]

    # Get skill from registry
    try:
        skill = skill_query_service.get_skill(tenant_id=tenant_id, skill_instance_id=skill_id)
    except Exception as e:
        logger.error("Skill not found %s: %s", skill_id, e)
        raise HTTPException(status_code=404, detail=f"Skill not found: {skill_id}")

    # Validate skill is active
    if skill.get("status") != "active":
        raise HTTPException(status_code=400, detail=f"Skill is not active: {skill_id}. Status: {skill.get('status')}")

    # Skill execution is not yet implemented (requires Grok integration).
    # Return an honest error rather than fabricated success data.
    execution_id = str(ulid.new())

    return {
        "version": "1.0",
        "status": "error",
        "tool_name": tool_name,
        "skill_id": skill_id,
        "result": None,
        "error": "Skill execution not yet available",
        "execution_id": execution_id,
        "execution_type": "not_implemented",
        "metadata": {
            "tenant_id": tenant_id,
            "skill_version": skill.get("version", "1.0.0"),
            "vertical": skill.get("vertical"),
            "role_category": skill.get("role_category"),
        },
    }


def create_execute_tool_endpoint(skill_query_service: Any):
    """
    Factory function to create FastAPI endpoint for tool execution.

    Args:
        skill_query_service: SkillQueryService instance

    Returns:
        FastAPI route handler function
    """

    async def endpoint(tool_name: str, request: Request):
        """
        MCP tool execution endpoint.

        Route: POST /mcp/v1/tools/{tool_name}/call

        Args:
            tool_name: Name of tool to invoke (format: workweaver_{skill_id})
            request: FastAPI request with tenant_id header and parameters body

        Returns:
            MCP tool execution response

        Raises:
            HTTPException: If tool name invalid, skill not found, or skill inactive
        """
        from apps.backend.extensions.mcp_server.middleware.tenant_isolation import extract_tenant_id

        tenant_id = extract_tenant_id(request)

        # Parse request body
        try:
            body = await request.json()
            parameters = body.get("parameters", {})
        except Exception:
            raise HTTPException(status_code=400, detail="Invalid request body")

        # Execute tool
        result = await execute_tool(
            tool_name=tool_name,
            request=request,
            skill_query_service=skill_query_service,
            tenant_id=tenant_id,
            parameters=parameters,
        )

        return result

    return endpoint
