#!/usr/bin/env python3
"""
Tenant Isolation Middleware for MCP Server

Enforces tenant isolation for all MCP requests.

Implementation Reference:
- docs/PRODUCT.md P1.1.6 (lines 3050-3121)
- TASK-1.8.004: Add tenant isolation to MCP tool execution
"""

from __future__ import annotations

import re
from typing import Any, Callable, Optional

from fastapi import HTTPException, Request, status
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse

from apps.backend.api.dependencies.plugin_auth import get_plugin_tenant_id


_API_KEY_ENVS = {"prod", "production", "staging"}


class TenantIsolationMiddleware(BaseHTTPMiddleware):
    """
    FastAPI middleware for enforcing tenant isolation.

    This middleware:
    1. Resolves tenant identity for each MCP request
    2. Validates tenant identifiers match the MCP tenant format
    3. Enriches request state with tenant_id for downstream endpoints
    4. Rejects cross-tenant access attempts
    """

    TENANT_ID_PATTERN = re.compile(r"^TENANT#[a-zA-Z0-9_-]+$")
    TENANT_HEADER = "x-tenant-id"

    async def dispatch(self, request: Request, call_next: Callable) -> Any:
        """Process request and enforce tenant isolation."""
        path = request.url.path
        if path in ["/", "/health"]:
            return await call_next(request)

        try:
            tenant_id = resolve_authenticated_tenant_id(request)
        except HTTPException as exc:
            return JSONResponse(status_code=exc.status_code, content={"detail": exc.detail})

        request.state.tenant_id = tenant_id
        request.state.tenant_id_valid = True

        response = await call_next(request)
        response.headers[self.TENANT_HEADER] = tenant_id
        return response


def _requires_api_key_auth() -> bool:
    """Production MCP surfaces must bind tenant identity to an API key."""
    from apps.backend.config.environment import get_environment

    return get_environment() in _API_KEY_ENVS


def _normalize_authenticated_tenant_id(tenant_id: str) -> str:
    """Normalize API-key-derived tenant ids to the MCP tenant format."""
    candidate = str(tenant_id or "").strip()
    if not candidate:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Authentication required",
        )
    if not candidate.startswith("TENANT#"):
        candidate = f"TENANT#{candidate}"
    if not TenantIsolationMiddleware.TENANT_ID_PATTERN.match(candidate):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid {TenantIsolationMiddleware.TENANT_HEADER} format: {candidate}. Expected: TENANT#<id>",
        )
    return candidate


def validate_tenant_header(tenant_id: Optional[str], required: bool = True) -> Optional[str]:
    """
    Validate tenant header format.

    Args:
        tenant_id: Tenant ID from request header
        required: Whether tenant header is required

    Returns:
        Valid tenant_id, or None if not provided (and not required)

    Raises:
        HTTPException: If tenant_id required but missing, or format invalid
    """
    if not tenant_id:
        if required:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail=f"Missing required header: {TenantIsolationMiddleware.TENANT_HEADER}",
            )
        return None

    if not TenantIsolationMiddleware.TENANT_ID_PATTERN.match(tenant_id):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid {TenantIsolationMiddleware.TENANT_HEADER} format: {tenant_id}. Expected: TENANT#<id>",
        )

    return tenant_id


def resolve_authenticated_tenant_id(request: Request) -> str:
    """Resolve tenant identity for MCP requests.

    In dev/test, the existing x-tenant-id contract stays available.
    In production-like environments, tenant identity must come from a valid
    plugin API key, and any provided x-tenant-id must match it.
    """
    header_tenant = request.headers.get(TenantIsolationMiddleware.TENANT_HEADER)
    if not _requires_api_key_auth():
        return validate_tenant_header(header_tenant)

    tenant_id = _normalize_authenticated_tenant_id(get_plugin_tenant_id(request))
    if header_tenant:
        validated_header = validate_tenant_header(header_tenant)
        if validated_header != tenant_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Tenant ID mismatch between header and API key",
            )
    return tenant_id


def extract_tenant_id(request: Request) -> str:
    """Extract tenant_id from request state or resolve it directly."""
    if hasattr(request.state, "tenant_id") and request.state.tenant_id:
        return request.state.tenant_id

    return resolve_authenticated_tenant_id(request)
