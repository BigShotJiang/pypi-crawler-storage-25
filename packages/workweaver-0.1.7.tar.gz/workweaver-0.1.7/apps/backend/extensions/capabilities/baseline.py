"""CapabilityBaseline read model (#1535).

Tracks which capabilities (skills, tools, providers) are available to each
tenant, forming the foundation for capability-aware routing and experience
scoring.

Schema:
  PK: ``<tenant_id>#CAP``
  SK: ``<capability_id>``
"""

from __future__ import annotations

from datetime import datetime
from enum import Enum
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class CapabilityStatus(str, Enum):
    """Status of a capability for a given tenant."""

    AVAILABLE = "available"
    DEGRADED = "degraded"
    UNAVAILABLE = "unavailable"
    UNKNOWN = "unknown"


class CapabilityRecord(BaseModel):
    """Frozen record representing a single capability state for a tenant."""

    model_config = ConfigDict(frozen=True)

    capability_id: str
    tenant_id: str
    status: CapabilityStatus
    last_verified_at: datetime
    metadata: dict[str, str] | None = None
    degraded_reason: str | None = None

    @property
    def pk(self) -> str:
        return f"{self.tenant_id}#CAP"

    @property
    def sk(self) -> str:
        return self.capability_id


@runtime_checkable
class BaselineStore(Protocol):
    """Storage protocol for capability baseline records."""

    def get(self, tenant_id: str, capability_id: str) -> dict[str, Any] | None: ...

    def set(self, tenant_id: str, capability_id: str, data: dict[str, Any]) -> None: ...

    def list_for_tenant(self, tenant_id: str) -> list[dict[str, Any]]: ...


class InMemoryBaselineStore:
    """In-memory store for capability baseline records (testing)."""

    def __init__(self) -> None:
        self._data: dict[str, dict[str, dict[str, Any]]] = {}

    def _pk(self, tenant_id: str) -> str:
        return f"{tenant_id}#CAP"

    def get(self, tenant_id: str, capability_id: str) -> dict[str, Any] | None:
        return self._data.get(self._pk(tenant_id), {}).get(capability_id)

    def set(self, tenant_id: str, capability_id: str, data: dict[str, Any]) -> None:
        pk = self._pk(tenant_id)
        if pk not in self._data:
            self._data[pk] = {}
        self._data[pk][capability_id] = dict(data)

    def list_for_tenant(self, tenant_id: str) -> list[dict[str, Any]]:
        pk = self._pk(tenant_id)
        return list(self._data.get(pk, {}).values())


class CapabilityBaseline:
    """Service for managing tenant capability baselines.

    Provides CRUD operations and convenience queries for checking which
    capabilities are available, degraded, or unavailable for a tenant.
    """

    def __init__(self, store: BaselineStore) -> None:
        self._store = store

    def _hydrate(self, data: dict[str, Any]) -> CapabilityRecord:
        """Reconstruct a CapabilityRecord from stored dict data."""
        d = dict(data)
        if "last_verified_at" in d and isinstance(d["last_verified_at"], str):
            d["last_verified_at"] = datetime.fromisoformat(d["last_verified_at"])
        return CapabilityRecord(**d)

    def get_capabilities(self, tenant_id: str) -> list[CapabilityRecord]:
        """Return all capability records for a tenant."""
        items = self._store.list_for_tenant(tenant_id)
        return [self._hydrate(item) for item in items]

    def get_capability(self, tenant_id: str, capability_id: str) -> CapabilityRecord | None:
        """Return a single capability record, or None if not found."""
        data = self._store.get(tenant_id, capability_id)
        if data is None:
            return None
        return self._hydrate(data)

    def update_capability(self, tenant_id: str, record: CapabilityRecord) -> None:
        """Upsert a capability record for a tenant."""
        self._store.set(tenant_id, record.capability_id, record.model_dump(mode="json"))

    def bulk_update(self, tenant_id: str, records: list[CapabilityRecord]) -> None:
        """Batch upsert capability records for a tenant."""
        for record in records:
            self._store.set(tenant_id, record.capability_id, record.model_dump(mode="json"))

    def check_capability(self, tenant_id: str, capability_id: str) -> CapabilityStatus:
        """Return the status of a capability, or UNKNOWN if not tracked."""
        record = self.get_capability(tenant_id, capability_id)
        if record is None:
            return CapabilityStatus.UNKNOWN
        return record.status

    def is_available(self, tenant_id: str, capability_id: str) -> bool:
        """Return True if the capability is AVAILABLE for the tenant."""
        return self.check_capability(tenant_id, capability_id) == CapabilityStatus.AVAILABLE
