"""Base contracts for inbound Workweaver runtime extensions.

This module intentionally defines only the shared type surface. Discovery,
tenant manifests, enable/disable state, and runtime loading belong to the
follow-up extension runtime work.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any, ClassVar, Literal, Protocol, runtime_checkable


ExtensionCapabilityClass = Literal[
    "connector",
    "domain",
    "governance",
    "memory",
    "runtime",
]
ExtensionModality = Literal[
    "api",
    "data",
    "domain",
    "governance",
    "message",
    "voice",
]


@dataclass(frozen=True, slots=True)
class ExtensionManifest:
    """Stable metadata every inbound extension exposes to the runtime."""

    id: str
    display_name: str
    version: str
    capability_class: ExtensionCapabilityClass
    modality: ExtensionModality
    side_effect_tags: tuple[str, ...] = field(default_factory=tuple)

    def to_dict(self) -> dict[str, Any]:
        """Serialize the manifest without exposing dataclass internals."""
        return {
            "id": self.id,
            "display_name": self.display_name,
            "version": self.version,
            "capability_class": self.capability_class,
            "modality": self.modality,
            "side_effect_tags": list(self.side_effect_tags),
        }


@runtime_checkable
class WorkweaverExtension(Protocol):
    """Structural supertype for inbound Workweaver extensions.

    PR1 keeps this intentionally small: identity and classification are the
    common denominator that lets scattered contracts become discoverable. The
    lifecycle runtime will depend on this protocol but is not implemented here.
    """

    @property
    def extension_manifest(self) -> ExtensionManifest:
        """Return stable extension identity and classification metadata."""
        ...


@runtime_checkable
class WorkweaverExtensionContract(Protocol):
    """Marker for existing contract classes that are extension surfaces."""

    extension_manifest: ClassVar[ExtensionManifest]


@runtime_checkable
class ExtensionLifecycle(WorkweaverExtension, Protocol):
    """Lifecycle hooks implemented by loadable runtime extensions.

    These hooks are declared for type-checking and future runtime integration
    only. No loader calls them in this PR.
    """

    def register(self, runtime: Any) -> None:
        """Register tools, hooks, resources, or capability projections."""
        ...

    def init(self, tenant_id: str) -> None:
        """Prepare tenant-scoped runtime state."""
        ...

    def install(self, config: Mapping[str, Any]) -> None:
        """Validate and persist extension configuration."""
        ...

    def enable(self) -> None:
        """Enable this extension for runtime use."""
        ...

    def disable(self) -> None:
        """Disable this extension without deleting configuration."""
        ...

    def shutdown(self) -> None:
        """Release runtime resources."""
        ...


@dataclass(frozen=True, slots=True)
class ExtensionAdapterShim:
    """Metadata shim for a contract that cannot inherit the extension base."""

    contract: type[Any]
    manifest: ExtensionManifest
    reason: str


def extension_manifest_for(target: WorkweaverExtension | type[Any]) -> ExtensionManifest:
    """Return extension metadata for an instance or contract class."""
    manifest = getattr(target, "extension_manifest", None)
    if isinstance(manifest, ExtensionManifest):
        return manifest
    raise TypeError(f"{target!r} does not expose an ExtensionManifest")
