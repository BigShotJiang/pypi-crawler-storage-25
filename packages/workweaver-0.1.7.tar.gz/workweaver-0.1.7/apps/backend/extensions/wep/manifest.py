"""Extension manifest model for WEP #1600.

A frozen Pydantic model that captures all metadata required for an extension
to register with the Workweaver kernel.  Validation enforces:
- Required fields: extension_id, name, version, entrypoint, classification
- extension_id format: ``ext::provider/name``
- version format: semver (MAJOR.MINOR.PATCH, optional pre-release/build)
- classification: one of kernel / extension / skill-candidate
"""

from __future__ import annotations

import re
from datetime import datetime
from typing import Literal

from pydantic import BaseModel, field_validator

# ---------------------------------------------------------------------------
# extension_id format: ext::provider/name  (provider and name non-empty,
# alphanumeric + hyphens + underscores, name may have additional slashes)
# ---------------------------------------------------------------------------
_EXTENSION_ID_RE = re.compile(
    r"^ext::[a-zA-Z0-9_-]+/[a-zA-Z0-9_-]+(?:/[a-zA-Z0-9_-]+)*$"
)

# Basic semver: MAJOR.MINOR.PATCH with optional pre-release / build metadata
_SEMVER_RE = re.compile(
    r"^(0|[1-9]\d*)\.(0|[1-9]\d*)\.(0|[1-9]\d*)"
    r"(?:-[a-zA-Z0-9]+(?:\.[a-zA-Z0-9]+)*)?"
    r"(?:\+[a-zA-Z0-9]+(?:\.[a-zA-Z0-9]+)*)?$"
)


class ExtensionManifest(BaseModel):
    """Frozen Pydantic model for a WEP extension manifest.

    Every extension that wants to register with the kernel must present a
    valid manifest.  The model is frozen to prevent post-registration mutation.
    """

    model_config = {"frozen": True}

    extension_id: str
    name: str
    version: str
    description: str = ""
    entrypoint: str
    classification: Literal["kernel", "extension", "skill-candidate"]
    permissions: list[str] = []
    capabilities: list[str] = []
    dependencies: list[str] = []
    author: str = ""
    created_at: datetime

    @field_validator("extension_id")
    @classmethod
    def _validate_extension_id(cls, v: str) -> str:
        if not _EXTENSION_ID_RE.match(v):
            raise ValueError(
                f"extension_id must follow 'ext::provider/name' format, got: {v!r}"
            )
        return v

    @field_validator("version")
    @classmethod
    def _validate_version(cls, v: str) -> str:
        if not _SEMVER_RE.match(v):
            raise ValueError(
                f"version must be valid semver (MAJOR.MINOR.PATCH), got: {v!r}"
            )
        return v
