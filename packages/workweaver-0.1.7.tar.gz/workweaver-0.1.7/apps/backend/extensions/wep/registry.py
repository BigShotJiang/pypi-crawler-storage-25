"""WEP Registry — tenant-scoped extension registry with dependency validation.

The registry is the central bookkeeping surface for WEP #1600.  Each tenant
gets its own isolated namespace so extensions registered under one tenant
are invisible to another.

Key responsibilities:
- Register / unregister extensions
- Validate manifests (structural + dependency resolution)
- List extensions with optional classification filter
- Reject circular and self-referential dependencies
"""

from __future__ import annotations

from typing import Any

from apps.backend.extensions.wep.manifest import (
    ExtensionManifest,
    _EXTENSION_ID_RE,
    _SEMVER_RE,
)

# Required fields for manifest validation (used by validate_manifest)
_REQUIRED_FIELDS = ("extension_id", "name", "version", "entrypoint", "classification")

_VALID_CLASSIFICATIONS = ("kernel", "extension", "skill-candidate")


class WEPRegistry:
    """Tenant-scoped registry for WEP extensions.

    The registry stores extensions keyed by ``(tenant_id, extension_id)`` so
    that tenants are fully isolated.  All public methods require an explicit
    ``tenant_id`` argument.
    """

    def __init__(self) -> None:
        self._extensions: dict[tuple[str, str], ExtensionManifest] = {}

    # -- CRUD ---------------------------------------------------------------

    def register(
        self, manifest: ExtensionManifest, *, tenant_id: str
    ) -> None:
        """Validate and register *manifest* under *tenant_id*.

        Raises:
            ValueError: If the extension is already registered, has missing
                dependencies, or introduces a circular dependency.
        """
        key = (tenant_id, manifest.extension_id)

        # Duplicate check
        if key in self._extensions:
            raise ValueError(
                f"Extension {manifest.extension_id!r} already registered "
                f"for tenant {tenant_id!r}"
            )

        # Self-dependency check
        if manifest.extension_id in manifest.dependencies:
            raise ValueError(
                f"Circular dependency: extension {manifest.extension_id!r} "
                f"depends on itself"
            )

        # Dependency resolution — every declared dependency must already be
        # registered in the same tenant.
        for dep_id in manifest.dependencies:
            dep_key = (tenant_id, dep_id)
            if dep_key not in self._extensions:
                raise ValueError(
                    f"Unresolved dependency: {manifest.extension_id!r} requires "
                    f"{dep_id!r}, which is not registered for tenant {tenant_id!r}"
                )

            # Circular dependency detection: walk the dependency graph from
            # the dependency back toward the extension being registered.
            if self._has_circular_dependency(
                tenant_id, dep_id, manifest.extension_id, set()
            ):
                raise ValueError(
                    f"Circular dependency detected: {manifest.extension_id!r} -> "
                    f"{dep_id!r} leads back to {manifest.extension_id!r}"
                )

        self._extensions[key] = manifest

    def unregister(self, extension_id: str, *, tenant_id: str) -> None:
        """Remove an extension from the registry.  Noop if not found."""
        self._extensions.pop((tenant_id, extension_id), None)

    def get(
        self, extension_id: str, *, tenant_id: str
    ) -> ExtensionManifest | None:
        """Return the manifest for *extension_id* under *tenant_id*, or None."""
        return self._extensions.get((tenant_id, extension_id))

    def list_extensions(
        self, *, tenant_id: str, classification: str | None = None
    ) -> list[ExtensionManifest]:
        """List extensions for *tenant_id*, optionally filtered by classification."""
        results: list[ExtensionManifest] = []
        for (tid, _eid), manifest in self._extensions.items():
            if tid != tenant_id:
                continue
            if classification is not None and manifest.classification != classification:
                continue
            results.append(manifest)
        return results

    # -- Static validation --------------------------------------------------

    @staticmethod
    def validate_manifest(raw: dict[str, Any]) -> list[str]:
        """Validate a raw manifest dict without registering it.

        Returns a list of human-readable error strings (empty if valid).
        """
        errors: list[str] = []

        # Required fields
        for field in _REQUIRED_FIELDS:
            if field not in raw or not raw[field]:
                errors.append(f"Missing required field: {field}")

        # If extension_id is present, check format
        ext_id = raw.get("extension_id", "")
        if ext_id and not _EXTENSION_ID_RE.match(ext_id):
            errors.append(
                f"Invalid extension_id format: {ext_id!r} "
                f"(expected 'ext::provider/name')"
            )

        # If version is present, check semver
        version = raw.get("version", "")
        if version and not _SEMVER_RE.match(version):
            errors.append(
                f"Invalid version (not semver): {version!r}"
            )

        # If classification is present, check against allowlist
        classification = raw.get("classification", "")
        if classification and classification not in _VALID_CLASSIFICATIONS:
            errors.append(
                f"Invalid classification: {classification!r} "
                f"(must be one of {_VALID_CLASSIFICATIONS})"
            )

        return errors

    # -- Internal helpers ---------------------------------------------------

    def _has_circular_dependency(
        self,
        tenant_id: str,
        start_id: str,
        target_id: str,
        visited: set[str],
    ) -> bool:
        """Walk the dependency graph from *start_id* to see if it reaches *target_id*."""
        if start_id == target_id:
            return True
        if start_id in visited:
            return False
        visited.add(start_id)

        start_manifest = self._extensions.get((tenant_id, start_id))
        if start_manifest is None:
            return False

        for dep_id in start_manifest.dependencies:
            if self._has_circular_dependency(tenant_id, dep_id, target_id, visited):
                return True

        return False
