"""Permission system for WEP #1600.

Defines the set of capabilities an extension may be granted and a
``PermissionGuard`` that enforces those grants at runtime.
"""

from __future__ import annotations

from enum import Enum


class WEPPermission(Enum):
    """Capabilities that an extension may request from the kernel."""

    READ_USAGE = "read_usage"
    WRITE_USAGE = "write_usage"
    EXECUTE_SKILL = "execute_skill"
    MANAGE_TENANT = "manage_tenant"
    READ_MEMORY = "read_memory"
    WRITE_MEMORY = "write_memory"


class PermissionDeniedError(Exception):
    """Raised when an extension attempts an action it has not been granted."""

    def __init__(self, extension_id: str, permission: WEPPermission) -> None:
        self.extension_id = extension_id
        self.permission = permission
        super().__init__(
            f"Extension {extension_id!r} lacks permission {permission.value!r}"
        )


class PermissionGuard:
    """Tracks and enforces per-extension permission grants.

    The guard is intentionally in-memory and not tenant-scoped; the
    ``WEPRegistry`` creates one guard per tenant to enforce isolation.
    """

    def __init__(self) -> None:
        self._grants: dict[str, set[WEPPermission]] = {}

    # -- Mutating API -------------------------------------------------------

    def grant(self, extension_id: str, permission: WEPPermission) -> None:
        """Grant *permission* to *extension_id*."""
        self._grants.setdefault(extension_id, set()).add(permission)

    def revoke(self, extension_id: str, permission: WEPPermission) -> None:
        """Revoke *permission* from *extension_id*."""
        if extension_id in self._grants:
            self._grants[extension_id].discard(permission)

    # -- Query API ----------------------------------------------------------

    def check(self, extension_id: str, permission: WEPPermission) -> bool:
        """Return True if *extension_id* has been granted *permission*."""
        return permission in self._grants.get(extension_id, set())

    def require(self, extension_id: str, permission: WEPPermission) -> None:
        """Raise ``PermissionDeniedError`` if the permission is not granted."""
        if not self.check(extension_id, permission):
            raise PermissionDeniedError(extension_id, permission)
