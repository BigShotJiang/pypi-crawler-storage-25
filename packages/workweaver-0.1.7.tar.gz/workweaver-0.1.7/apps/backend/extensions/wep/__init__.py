"""Workweaver Extension Protocol (WEP) — #1600.

Defines the protocol for how extensions register, validate, and interact
with the kernel.  The WEP surface consists of three modules:

- ``manifest`` — frozen Pydantic model for extension metadata
- ``permissions`` — permission enum and guard for capability gating
- ``registry`` — tenant-scoped extension registry with dependency validation
"""
