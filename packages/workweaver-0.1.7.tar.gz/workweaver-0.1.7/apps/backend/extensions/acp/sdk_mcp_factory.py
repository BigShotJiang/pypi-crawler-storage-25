"""Claude Agent SDK in-process MCP server factory for Workweaver tools."""

from __future__ import annotations

import json
from dataclasses import dataclass
from importlib import import_module
from typing import Any

from apps.backend.api.public_mcp import (
    dispatch_mcp_tool,
    get_public_mcp_tool_schema,
    get_public_mcp_tool_index,
)


_DEFAULT_TOOL_PREFIXES = (
    "ww.memory.",
    "workweaver.memory.",
    "ww.connector.",
    "workweaver.connector.",
    "ww.skill.",
    "workweaver.skill.",
)
_DEFAULT_TOOL_NAMES = frozenset({"ww.tools.search"})
_CONTEXT_WORKSPACE_TOOL_NAMES = frozenset(
    {
        "ww.operational_context.workspace",
        "workweaver.operational_context.workspace",
    }
)
_CONTEXT_SHARE_TOOL_NAMES = frozenset(
    {
        "ww.operational_context.share",
        "workweaver.operational_context.share",
    }
)
_CONTEXT_AUTH_TOOL_NAMES = _CONTEXT_WORKSPACE_TOOL_NAMES | _CONTEXT_SHARE_TOOL_NAMES


@dataclass(frozen=True)
class WorkweaverSdkMcpServer:
    """In-process SDK MCP server plus the canonical Workweaver tool names."""

    server: Any
    tool_names: list[str]


def build_workweaver_sdk_mcp_server(
    *,
    tenant_id: str,
    verified_actor_id: str | None = None,
    verified_actor_role: str | None = None,
    sdk_module: Any | None = None,
    server_name: str = "workweaver",
    version: str = "1.0.0",
    tool_names: list[str] | None = None,
    tool_catalog: list[dict[str, Any]] | None = None,
) -> WorkweaverSdkMcpServer:
    """Build an in-process Claude Agent SDK MCP server for Workweaver tools.

    The factory reuses the public MCP registry and dispatcher so SDK runs use
    the same canonical envelope, tenant scoping, policy gates, and tool names as
    HTTP/CLI MCP clients.
    """

    verified_actor_id = _normalize_optional_text(verified_actor_id)
    verified_actor_role = _normalize_optional_text(verified_actor_role)
    sdk = sdk_module or _load_claude_agent_sdk()
    catalog = tool_catalog if tool_catalog is not None else _load_public_mcp_schemas()
    selected = _select_tool_schemas(catalog, requested_tool_names=tool_names)
    if verified_actor_id is None:
        selected = [
            schema
            for schema in selected
            if str(schema.get("name") or "") not in _CONTEXT_AUTH_TOOL_NAMES
        ]
    elif verified_actor_role is None:
        selected = [
            schema
            for schema in selected
            if str(schema.get("name") or "") not in _CONTEXT_SHARE_TOOL_NAMES
        ]
    sdk_tools = [
        _build_sdk_tool(
            schema=schema,
            tenant_id=tenant_id,
            sdk=sdk,
            verified_actor_id=verified_actor_id,
            verified_actor_role=verified_actor_role,
        )
        for schema in selected
    ]
    server = sdk.create_sdk_mcp_server(
        name=server_name,
        version=version,
        tools=sdk_tools,
    )
    return WorkweaverSdkMcpServer(
        server=server,
        tool_names=[str(schema["name"]) for schema in selected],
    )


def _normalize_optional_text(value: str | None) -> str | None:
    normalized = str(value or "").strip()
    return normalized or None


def _select_tool_schemas(
    catalog: list[dict[str, Any]],
    *,
    requested_tool_names: list[str] | None,
) -> list[dict[str, Any]]:
    requested = set(requested_tool_names or [])
    selected: list[dict[str, Any]] = []
    for schema in catalog:
        name = str(schema.get("name") or "")
        if not name:
            continue
        if requested:
            if name in requested:
                selected.append(schema)
            continue
        if name in _DEFAULT_TOOL_NAMES or name.startswith(_DEFAULT_TOOL_PREFIXES):
            selected.append(schema)
    return selected


def _load_public_mcp_schemas() -> list[dict[str, Any]]:
    schemas: list[dict[str, Any]] = []
    for row in get_public_mcp_tool_index():
        name = str(row.get("name") or "")
        if not name:
            continue
        try:
            schemas.append(get_public_mcp_tool_schema(name) or row)
        except KeyError:
            schemas.append(row)
    return schemas


def _build_sdk_tool(
    *,
    schema: dict[str, Any],
    tenant_id: str,
    sdk: Any,
    verified_actor_id: str | None,
    verified_actor_role: str | None,
) -> Any:
    tool_name = str(schema["name"])
    input_schema = schema.get("inputSchema") or schema.get("input_schema") or {
        "type": "object",
        "properties": {},
    }
    description = str(schema.get("description") or f"Invoke {tool_name}.")

    @sdk.tool(tool_name, description, input_schema)
    async def _handler(args: dict[str, Any] | None = None) -> dict[str, Any]:
        parameters = dict(args or {})
        dispatch_kwargs: dict[str, Any] = {
            "tool_name": tool_name,
            "tenant_id": tenant_id,
            "parameters": parameters,
        }
        if verified_actor_id is not None:
            dispatch_kwargs["verified_actor_id"] = verified_actor_id
        if verified_actor_role is not None:
            dispatch_kwargs["verified_actor_role"] = verified_actor_role
        result = await dispatch_mcp_tool(**dispatch_kwargs)
        return {
            "content": [
                {
                    "type": "text",
                    "text": json.dumps(result, default=str, sort_keys=True),
                }
            ],
            "structuredContent": result,
        }

    return _handler


def _load_claude_agent_sdk() -> Any:
    try:
        claude_agent_sdk = import_module("claude_agent_sdk")
    except ImportError as exc:
        raise RuntimeError(
            "claude-agent-sdk is required for ACPProvider.CLAUDE_AGENT_SDK. "
            "Install the project dependency or disable this provider."
        ) from exc
    return claude_agent_sdk
