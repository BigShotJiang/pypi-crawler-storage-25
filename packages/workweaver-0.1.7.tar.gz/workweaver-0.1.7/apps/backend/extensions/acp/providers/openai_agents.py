"""OpenAI Agents Python SDK in-process ACP provider."""

from __future__ import annotations

import asyncio
import logging
import threading
import time
from collections.abc import Iterator
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import UTC, datetime
from importlib import import_module
from typing import Any


logger = logging.getLogger(__name__)
_TRACE_PROCESSOR_SCOPE_LOCK = threading.RLock()


@dataclass(frozen=True)
class OpenAIAgentsRunConfig:
    """Configuration needed to run one OpenAI Agents SDK invocation."""

    request_id: str
    tenant_id: str
    prompt: str
    provider: Any
    model: str | None
    sdk_options: dict[str, Any]


class OpenAIAgentsProvider:
    """Runs OpenAI Agents Python SDK with Workweaver MCP and evidence traces."""

    def __init__(
        self,
        *,
        decision_capture_service: Any,
        sdk_module: Any | None = None,
    ) -> None:
        self._decision_capture_service = decision_capture_service
        self._sdk = sdk_module or self._load_sdk()

    def invoke(self, config: OpenAIAgentsRunConfig) -> Any:
        """Run ``Runner.run_sync(agent, input=...)`` behind ACPClientBridge."""
        from apps.backend.extensions.acp.acp_client_adapter import ACPResponse

        t0 = time.monotonic()
        trace_processor = OpenAIAgentsDecisionTraceProcessor(
            tenant_id=config.tenant_id,
            request_id=config.request_id,
            decision_capture_service=self._decision_capture_service,
        )
        server = self._build_mcp_server(config)
        _connect_mcp_server(server)
        agent = self._build_agent(config, server=server)
        run_config = self._build_run_config(config)
        try:
            with _trace_processor_scope(self._sdk, trace_processor):
                result = self._sdk.Runner.run_sync(
                    agent,
                    input=config.prompt,
                    context=config.sdk_options.get("context"),
                    max_turns=config.sdk_options.get("max_turns"),
                    run_config=run_config,
                )
                _maybe_flush_traces(self._sdk)
        finally:
            _cleanup_mcp_server(server)
        content = _result_to_text(result)
        return ACPResponse(
            request_id=config.request_id,
            provider=config.provider,
            content=content,
            tokens_used=_estimate_tokens(result, content),
            elapsed_ms=int((time.monotonic() - t0) * 1000),
            timestamp=datetime.now(UTC),
        )

    def _build_agent(self, config: OpenAIAgentsRunConfig, *, server: Any) -> Any:
        kwargs: dict[str, Any] = {
            "name": str(config.sdk_options.get("agent_name") or "Workweaver OpenAI Agent"),
            "instructions": str(
                config.sdk_options.get("instructions")
                or "Use Workweaver MCP tools for memory, connector, skill, and evidence context."
            ),
            "mcp_servers": [server],
        }
        if config.model:
            kwargs["model"] = config.model
        if tools := config.sdk_options.get("tools"):
            kwargs["tools"] = tools
        return self._sdk.Agent(**kwargs)

    def _build_mcp_server(self, config: OpenAIAgentsRunConfig) -> Any:
        server = config.sdk_options.get("mcp_server")
        if server is not None:
            return server
        servers = config.sdk_options.get("mcp_servers")
        if isinstance(servers, list) and servers:
            return servers[0]

        mcp_url = str(
            config.sdk_options.get("mcp_url")
            or config.sdk_options.get("workweaver_mcp_url")
            or "https://api.workweaver.ai/mcp"
        )
        headers = dict(config.sdk_options.get("mcp_headers") or {})
        headers.setdefault("X-Workweaver-Tenant", config.tenant_id)
        tool_names = config.sdk_options.get("mcp_tool_names")
        tool_filter = _build_tool_filter(tool_names if isinstance(tool_names, list) else None)
        mcp_cls = _resolve_mcp_server_class(self._sdk)
        return mcp_cls(
            name=str(config.sdk_options.get("mcp_server_name") or "workweaver"),
            params={"url": mcp_url, "headers": headers},
            tool_filter=tool_filter,
            tool_meta_resolver=lambda _context: {
                "tenant_id": config.tenant_id,
                "request_id": config.request_id,
                "source": "workweaver-openai-agents",
            },
        )

    def _build_run_config(self, config: OpenAIAgentsRunConfig) -> Any | None:
        run_config_cls = getattr(self._sdk, "RunConfig", None)
        if run_config_cls is None:
            return None
        metadata = dict(config.sdk_options.get("trace_metadata") or {})
        metadata.update(
            {
                "tenant_id": config.tenant_id,
                "request_id": config.request_id,
                "provider": "openai_agents",
            }
        )
        return run_config_cls(
            workflow_name=str(config.sdk_options.get("workflow_name") or "workweaver.openai_agents"),
            group_id=config.tenant_id,
            trace_id=config.sdk_options.get("trace_id"),
            trace_metadata=metadata,
            trace_include_sensitive_data=bool(
                config.sdk_options.get("trace_include_sensitive_data", False)
            ),
        )

    @staticmethod
    def _load_sdk() -> Any:
        try:
            return import_module("agents")
        except ImportError as exc:
            raise RuntimeError(
                "openai-agents is required for ACPProvider.OPENAI_AGENTS. "
                "Install the optional SDK bridge package or disable this provider."
            ) from exc


@dataclass(frozen=True)
class OpenAIAgentsDecisionTraceProcessor:
    """OpenAI Agents tracing processor that emits Workweaver Decision Traces."""

    tenant_id: str
    request_id: str
    decision_capture_service: Any

    def on_trace_start(self, trace: Any) -> None:  # SDK processor protocol
        self._capture(kind="trace_start", exported=_export(trace))

    def on_trace_end(self, trace: Any) -> None:  # SDK processor protocol
        self._capture(kind="trace_end", exported=_export(trace))

    def on_span_start(self, span: Any) -> None:  # SDK processor protocol
        return None

    def on_span_end(self, span: Any) -> None:  # SDK processor protocol
        self._capture(kind="span_end", exported=_export(span))

    def shutdown(self) -> None:  # SDK processor protocol
        return None

    def force_flush(self) -> None:  # SDK processor protocol
        return None

    def _capture(self, *, kind: str, exported: dict[str, Any]) -> None:
        span_data = exported.get("span_data") if isinstance(exported.get("span_data"), dict) else {}
        tool_name = (
            str(span_data.get("name") or span_data.get("type") or exported.get("name") or "agent")
            if isinstance(span_data, dict)
            else str(exported.get("name") or "agent")
        )
        context_data = {
            "source": "openai_agents_python_trace_processor",
            "request_id": self.request_id,
            "event_kind": kind,
            "trace_id": exported.get("trace_id") or exported.get("traceId"),
            "span_id": exported.get("span_id") or exported.get("spanId"),
            "span_data": span_data,
        }
        try:
            self.decision_capture_service.capture_decision(
                tenant_id=self.tenant_id,
                skill_id=f"openai_agents:{tool_name}",
                decision_summary=f"OpenAI Agents Python {kind} for {tool_name}",
                decision_type="tool_call" if kind == "span_end" else "sdk_session",
                outcome=kind,
                entity_ids=[],
                rationale="OpenAI Agents Python bridge trace exported by Workweaver ACP provider.",
                alternatives_considered=[],
                sop_deviation=None,
                decision_conditions=[],
                capture_surface="openai_agents_python",
                service_family="acp_sdk_bridge",
                quality_score=1.0,
                context_data=context_data,
            )
        except Exception:
            logger.exception(
                "Failed to capture OpenAI Agents trace tenant=%s request=%s kind=%s",
                self.tenant_id,
                self.request_id,
                kind,
            )


def _resolve_mcp_server_class(sdk: Any) -> Any:
    if hasattr(sdk, "MCPServerStreamableHttp"):
        return sdk.MCPServerStreamableHttp
    mcp_module = getattr(sdk, "mcp", None)
    if mcp_module is not None and hasattr(mcp_module, "MCPServerStreamableHttp"):
        return mcp_module.MCPServerStreamableHttp
    try:
        return import_module("agents.mcp").MCPServerStreamableHttp
    except ImportError as exc:
        raise RuntimeError(
            "OpenAI Agents SDK MCP support is unavailable. "
            "Install a current openai-agents package with agents.mcp."
        ) from exc


def _build_tool_filter(tool_names: list[str] | None) -> dict[str, list[str]] | None:
    if not tool_names:
        return None
    return {"allowed_tool_names": [str(name) for name in tool_names]}


def _connect_mcp_server(server: Any) -> None:
    connect = getattr(server, "connect", None)
    if callable(connect):
        _run_async_from_sync(connect)


def _cleanup_mcp_server(server: Any) -> None:
    cleanup = getattr(server, "cleanup", None)
    if callable(cleanup):
        _run_async_from_sync(cleanup)


def _run_async_from_sync(coro_factory: Any) -> Any:
    async def _call() -> Any:
        result = coro_factory()
        if asyncio.iscoroutine(result):
            return await result
        return result

    try:
        asyncio.get_running_loop()
    except RuntimeError:
        return asyncio.run(_call())

    result: dict[str, Any] = {}
    error: dict[str, BaseException] = {}

    def _runner() -> None:
        try:
            result["value"] = asyncio.run(_call())
        except BaseException as exc:
            error["value"] = exc

    thread = threading.Thread(target=_runner, name="openai-agents-mcp-lifecycle", daemon=True)
    thread.start()
    thread.join()
    if error:
        raise error["value"]
    return result.get("value")


@contextmanager
def _trace_processor_scope(
    sdk: Any, processor: OpenAIAgentsDecisionTraceProcessor
) -> Iterator[None]:
    """Register Workweaver tracing only for one SDK invocation.

    The current OpenAI Agents Python tracing API exposes additive global
    processors plus list replacement, not a public remove call. Snapshotting
    and restoring the active list avoids per-run Workweaver processor leaks
    while preserving pre-existing SDK/default processors.
    """

    remove_trace_processor = getattr(sdk, "remove_trace_processor", None)
    add_trace_processor = getattr(sdk, "add_trace_processor", None)
    if callable(add_trace_processor) and callable(remove_trace_processor):
        with _TRACE_PROCESSOR_SCOPE_LOCK:
            add_trace_processor(processor)
            try:
                yield
            finally:
                remove_trace_processor(processor)
        return

    with _TRACE_PROCESSOR_SCOPE_LOCK:
        current_processors = _get_trace_processors(sdk)
        set_trace_processors = _resolve_set_trace_processors(sdk)
        if current_processors is None or set_trace_processors is None:
            raise RuntimeError(
                "OpenAI Agents SDK does not expose a scoped trace processor lifecycle. "
                "Refusing to register a global Workweaver trace processor without cleanup."
            )

        set_trace_processors([*current_processors, processor])
        try:
            yield
        finally:
            set_trace_processors(current_processors)


def _resolve_set_trace_processors(sdk: Any) -> Any | None:
    set_trace_processors = getattr(sdk, "set_trace_processors", None)
    if callable(set_trace_processors):
        return set_trace_processors
    tracing = getattr(sdk, "tracing", None)
    if tracing is not None:
        set_trace_processors = getattr(tracing, "set_trace_processors", None)
        if callable(set_trace_processors):
            return set_trace_processors
    provider = _resolve_trace_provider(sdk)
    if provider is not None:
        set_processors = getattr(provider, "set_processors", None)
        if callable(set_processors):
            return set_processors
    return None


def _get_trace_processors(sdk: Any) -> list[Any] | None:
    processors = getattr(sdk, "trace_processors", None)
    if isinstance(processors, list):
        return list(processors)

    provider = _resolve_trace_provider(sdk)
    if provider is None:
        return None
    containers = [provider, getattr(provider, "_multi_processor", None)]
    for container in containers:
        if container is None:
            continue
        processors = getattr(container, "_processors", None)
        if isinstance(processors, tuple | list):
            return list(processors)
    return None


def _resolve_trace_provider(sdk: Any) -> Any | None:
    get_trace_provider = getattr(sdk, "get_trace_provider", None)
    if callable(get_trace_provider):
        return get_trace_provider()
    tracing = getattr(sdk, "tracing", None)
    if tracing is not None:
        get_trace_provider = getattr(tracing, "get_trace_provider", None)
        if callable(get_trace_provider):
            return get_trace_provider()
    return None


def _maybe_flush_traces(sdk: Any) -> None:
    flush_traces = getattr(sdk, "flush_traces", None)
    if callable(flush_traces):
        flush_traces()


def _export(value: Any) -> dict[str, Any]:
    if value is None:
        return {}
    export = getattr(value, "export", None)
    if callable(export):
        exported = export()
        return exported if isinstance(exported, dict) else {"value": exported}
    if isinstance(value, dict):
        return dict(value)
    data: dict[str, Any] = {}
    for field in ("trace_id", "traceId", "span_id", "spanId", "name", "span_data"):
        if hasattr(value, field):
            data[field] = getattr(value, field)
    return data


def _result_to_text(result: Any) -> str:
    final_output = getattr(result, "final_output", None)
    if final_output is not None:
        return str(final_output).strip()
    if hasattr(result, "model_dump_json"):
        return result.model_dump_json()
    return str(result).strip()


def _estimate_tokens(result: Any, content: str) -> int:
    total = 0
    for response in getattr(result, "raw_responses", []) or []:
        usage = response.get("usage") if isinstance(response, dict) else getattr(response, "usage", None)
        if not usage:
            continue
        for field in ("input_tokens", "output_tokens", "total_tokens"):
            value = usage.get(field) if isinstance(usage, dict) else getattr(usage, field, 0)
            if isinstance(value, int):
                total += value
    return total if total > 0 else (max(1, len(content) // 4) if content else 0)
