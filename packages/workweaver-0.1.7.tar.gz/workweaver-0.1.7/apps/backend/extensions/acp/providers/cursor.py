"""Cursor TypeScript SDK ACP provider.

The Python backend does not import the TypeScript SDK directly. Instead, this
provider calls a tenant-configured HTTP adapter that runs `@cursor/sdk` and
executes the documented Agent.create -> agent.send -> run.stream flow.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any


logger = logging.getLogger(__name__)
DEFAULT_WORKWEAVER_MCP_URL = "https://api.workweaver.ai/mcp/http/v1/messages"


@dataclass(frozen=True)
class CursorAgentRunConfig:
    """Configuration needed to run one Cursor SDK invocation."""

    request_id: str
    tenant_id: str
    prompt: str
    provider: Any
    model: str | None
    endpoint_url: str
    api_key: str
    timeout_seconds: float
    sdk_options: dict[str, Any]


class CursorAgentProvider:
    """Runs Cursor Agent SDK tasks through a configured HTTP adapter."""

    def __init__(
        self,
        *,
        decision_capture_service: Any,
        http_client: Any | None = None,
    ) -> None:
        self._decision_capture_service = decision_capture_service
        self._http_client = http_client

    def invoke(self, config: CursorAgentRunConfig) -> Any:
        from apps.backend.extensions.acp.acp_client_adapter import ACPResponse

        endpoint_url = str(config.endpoint_url or "").strip().rstrip("/")
        if not endpoint_url:
            raise RuntimeError(
                "ACPProvider.CURSOR requires ACPEndpoint.endpoint_url pointing to "
                "the Cursor TypeScript SDK HTTP adapter."
            )
        api_key = str(config.api_key or "").strip()
        if not api_key:
            raise RuntimeError(
                "ACPProvider.CURSOR requires ACPEndpoint.credential_ref containing "
                "the Cursor API key or secret-store resolved value."
            )

        t0 = time.monotonic()
        payload = _build_cursor_agent_payload(config=config, api_key=api_key)
        headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
            "Authorization": f"Bearer {api_key}",
            "X-Workweaver-Tenant": config.tenant_id,
            "X-Workweaver-Request": config.request_id,
        }
        data = self._post_json(
            f"{endpoint_url}/agent-runs",
            payload=payload,
            headers=headers,
            timeout=config.timeout_seconds,
        )
        elapsed_ms = int((time.monotonic() - t0) * 1000)
        content = _cursor_response_to_text(data)
        self._capture_cursor_events(config=config, response=data)
        return ACPResponse(
            request_id=config.request_id,
            provider=config.provider,
            content=content,
            tokens_used=_estimate_tokens(data, content),
            elapsed_ms=elapsed_ms,
            timestamp=datetime.now(UTC),
        )

    def _post_json(
        self,
        url: str,
        *,
        payload: dict[str, Any],
        headers: dict[str, str],
        timeout: float,
    ) -> dict[str, Any]:
        client = self._http_client
        if client is not None:
            response = client.post(url, json=payload, headers=headers, timeout=timeout)
            response.raise_for_status()
            data = response.json()
            if not isinstance(data, dict):
                raise RuntimeError("Cursor adapter returned non-object JSON")
            return data

        try:
            import httpx
        except ImportError as exc:
            raise RuntimeError(
                "httpx is required for ACPProvider.CURSOR HTTP transport. "
                "Install it or inject a compatible http_client."
            ) from exc

        try:
            with httpx.Client(timeout=timeout) as http:
                response = http.post(url, json=payload, headers=headers)
                response.raise_for_status()
                data = response.json()
        except httpx.TimeoutException as exc:
            raise TimeoutError("Cursor adapter request timed out") from exc
        except httpx.HTTPStatusError as exc:
            raise RuntimeError(f"Cursor adapter HTTP error: {exc.response.status_code}") from exc
        except httpx.RequestError as exc:
            raise RuntimeError(f"Cursor adapter request error: {exc}") from exc
        if not isinstance(data, dict):
            raise RuntimeError("Cursor adapter returned non-object JSON")
        return data

    def _capture_cursor_events(self, *, config: CursorAgentRunConfig, response: dict[str, Any]) -> None:
        events = response.get("events") if isinstance(response.get("events"), list) else []
        if not events:
            events = [{"type": "run.completed", "run_id": response.get("run_id")}]
        for event in events:
            event_payload = event if isinstance(event, dict) else {"value": event}
            run_id = str(event_payload.get("run_id") or response.get("run_id") or "")
            event_type = str(event_payload.get("type") or "cursor.event")
            try:
                self._decision_capture_service.capture_decision(
                    tenant_id=config.tenant_id,
                    skill_id=f"cursor:{event_type}",
                    decision_summary=f"Cursor TypeScript SDK {event_type}",
                    decision_type="sdk_session",
                    outcome=event_type,
                    entity_ids=[],
                    rationale="Cursor TypeScript SDK bridge event exported by Workweaver ACP provider.",
                    alternatives_considered=[],
                    sop_deviation=None,
                    decision_conditions=[],
                    capture_surface="cursor_ts_sdk",
                    service_family="acp_sdk_bridge",
                    quality_score=1.0,
                    context_data={
                        "request_id": config.request_id,
                        "run_id": run_id,
                        "agent_id": response.get("agent_id"),
                        "event": event_payload,
                    },
                )
            except Exception:
                logger.exception(
                    "Failed to capture Cursor SDK event tenant=%s request=%s event=%s",
                    config.tenant_id,
                    config.request_id,
                    event_type,
                )


def _build_cursor_agent_payload(*, config: CursorAgentRunConfig, api_key: str) -> dict[str, Any]:
    options = dict(config.sdk_options or {})
    model_id = config.model or options.get("model") or "composer-2"
    agent: dict[str, Any] = {
        "apiKey": api_key,
        "model": {"id": str(model_id)},
        "mcpServers": _cursor_mcp_servers(config),
    }
    for key in ("local", "cloud", "hooks", "skills", "subagents"):
        if key in options:
            agent[key] = options[key]
    return {
        "agent": agent,
        "send": {"prompt": config.prompt},
        "run": {
            "stream": True,
            "autoCreatePR": bool(options.get("auto_create_pr") or options.get("autoCreatePR")),
        },
        "metadata": {
            "tenant_id": config.tenant_id,
            "request_id": config.request_id,
            "provider": "cursor",
        },
    }


def _cursor_mcp_servers(config: CursorAgentRunConfig) -> dict[str, Any]:
    options = dict(config.sdk_options or {})
    headers = dict(options.get("mcp_headers") or {})
    headers.setdefault("x-tenant-id", config.tenant_id)
    headers.setdefault("x-workmemory-no-train", "true")
    server = {
        "url": str(options.get("mcp_url") or DEFAULT_WORKWEAVER_MCP_URL),
        "headers": headers,
    }
    tool_names = options.get("mcp_tool_names")
    if isinstance(tool_names, list) and tool_names:
        server["allowedTools"] = [str(tool) for tool in tool_names]
    return {"workweaver": server}


def _cursor_response_to_text(data: dict[str, Any]) -> str:
    for key in ("content", "final_output", "text", "output"):
        value = data.get(key)
        if value is not None:
            return str(value).strip()
    return str(data).strip()


def _estimate_tokens(data: dict[str, Any], content: str) -> int:
    usage = data.get("usage") if isinstance(data.get("usage"), dict) else {}
    total_tokens = usage.get("total_tokens")
    if isinstance(total_tokens, int) and total_tokens > 0:
        return total_tokens
    total = 0
    for field in ("input_tokens", "output_tokens"):
        value = usage.get(field)
        if isinstance(value, int):
            total += value
    return total if total > 0 else (max(1, len(content) // 4) if content else 0)
