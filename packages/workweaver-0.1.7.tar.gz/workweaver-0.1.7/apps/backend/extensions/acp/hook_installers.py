"""Decision Trace hook installers for SDK-backed ACP providers."""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass
from importlib import import_module
from typing import Any


logger = logging.getLogger(__name__)


_HOOK_EVENTS = (
    "PreToolUse",
    "PostToolUse",
    "PostToolUseFailure",
    "Stop",
    "SubagentStop",
)


@dataclass(frozen=True)
class ClaudeAgentSdkDecisionTraceHooks:
    """Build Claude Agent SDK hook callbacks that emit Workweaver Decision Traces."""

    tenant_id: str
    request_id: str
    decision_capture_service: Any
    sdk_module: Any | None = None

    def build_hooks(self) -> dict[str, list[Any]]:
        sdk = self.sdk_module or _load_claude_agent_sdk()
        hook_matcher = sdk.HookMatcher
        return {
            event: [hook_matcher(matcher=".*", hooks=[self._callback_for(event)])]
            for event in _HOOK_EVENTS
        }

    def emit_lifecycle(
        self,
        hook_event_name: str,
        *,
        session_id: str | None = None,
        outcome: str | None = None,
        run_outcome: str | None = None,
    ) -> None:
        """Emit synthetic session lifecycle traces.

        Anthropic's current Python SDK hook surface does not expose
        ``SessionStart`` or ``SessionEnd`` callback events. Workweaver still
        needs those records in the Decision Trace timeline, so the provider
        emits them at the boundary around the SDK run.
        """

        self._capture(
            hook_event_name=hook_event_name,
            outcome=_outcome_for_event(hook_event_name),
            tool_name="session",
            tool_use_id=None,
            session_id=session_id,
            payload={"run_outcome": run_outcome or outcome},
        )

    def _callback_for(self, hook_event_name: str) -> Any:
        async def _callback(input_data: Any, _context: Any = None) -> dict[str, Any]:
            self._capture(
                hook_event_name=hook_event_name,
                outcome=_outcome_for_event(hook_event_name),
                tool_name=_extract(input_data, "tool_name") or "agent",
                tool_use_id=_extract(input_data, "tool_use_id"),
                session_id=_extract(input_data, "session_id"),
                payload=_payload_for(input_data),
            )
            return {}

        return _callback

    def _capture(
        self,
        *,
        hook_event_name: str,
        outcome: str,
        tool_name: str,
        tool_use_id: str | None,
        session_id: str | None,
        payload: dict[str, Any],
    ) -> None:
        context_data = {
            "request_id": self.request_id,
            "hook_event_name": hook_event_name,
            "tool_name": tool_name,
            "tool_use_id": tool_use_id,
            "session_id": session_id,
            "agent_id": payload.get("agent_id"),
            "agent_type": payload.get("agent_type"),
            "parent_tool_use_id": payload.get("parent_tool_use_id"),
            "run_outcome": payload.get("run_outcome"),
            "tool_input_hash": _hash_json(payload.get("tool_input")),
        }
        try:
            self.decision_capture_service.capture_decision(
                tenant_id=self.tenant_id,
                skill_id=f"claude_agent_sdk:{tool_name}",
                decision_summary=f"Claude Agent SDK {hook_event_name} for {tool_name}",
                decision_type="tool_call" if "ToolUse" in hook_event_name else "sdk_session",
                outcome=outcome,
                entity_ids=[],
                rationale="Claude Agent SDK bridge hook emitted by Workweaver ACP provider.",
                alternatives_considered=[],
                sop_deviation=None,
                decision_conditions=[],
                capture_surface="claude_agent_sdk",
                service_family="acp_sdk_bridge",
                quality_score=1.0,
                context_data=context_data,
            )
        except Exception:
            logger.exception(
                "Failed to capture Claude Agent SDK hook trace tenant=%s request=%s event=%s",
                self.tenant_id,
                self.request_id,
                hook_event_name,
            )


def _payload_for(input_data: Any) -> dict[str, Any]:
    return {
        "tool_input": _extract(input_data, "tool_input"),
        "agent_id": _extract(input_data, "agent_id"),
        "agent_type": _extract(input_data, "agent_type"),
        "parent_tool_use_id": _extract(input_data, "parent_tool_use_id"),
    }


def _extract(input_data: Any, field_name: str) -> Any:
    if isinstance(input_data, dict):
        return input_data.get(field_name)
    return getattr(input_data, field_name, None)


def _hash_json(payload: Any) -> str | None:
    if payload is None:
        return None
    try:
        encoded = repr(payload).encode()
    except Exception:
        encoded = str(type(payload)).encode()
    return hashlib.sha256(encoded).hexdigest()


def _outcome_for_event(hook_event_name: str) -> str:
    mapping = {
        "PreToolUse": "pre_tool_use",
        "PostToolUse": "post_tool_use",
        "PostToolUseFailure": "post_tool_use_failure",
        "Stop": "stop",
        "SubagentStop": "subagent_stop",
        "SessionStart": "session_start",
        "SessionEnd": "session_end",
    }
    return mapping.get(hook_event_name, hook_event_name.lower())


def _load_claude_agent_sdk() -> Any:
    try:
        claude_agent_sdk = import_module("claude_agent_sdk")
    except ImportError as exc:
        raise RuntimeError(
            "claude-agent-sdk is required to install Claude Agent SDK hooks."
        ) from exc
    return claude_agent_sdk
