"""MCPGateway — unified MCP gateway exposing full CLI command surface (#1496)."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class MCPMethod(str, Enum):
    TOOLS_LIST = "tools/list"
    TOOLS_CALL = "tools/call"
    RESOURCES_LIST = "resources/list"
    RESOURCES_READ = "resources/read"
    PROMPTS_LIST = "prompts/list"
    PROMPTS_GET = "prompts/get"


class MCPRequest(BaseModel):
    model_config = ConfigDict(frozen=True)
    request_id: str
    tenant_id: str
    method: MCPMethod
    params: dict[str, Any] | None = None


class MCPResponse(BaseModel):
    model_config = ConfigDict(frozen=True)
    request_id: str
    method: MCPMethod
    status: int
    body: dict[str, Any] | None = None
    timestamp: datetime


@runtime_checkable
class MCPStore(Protocol):
    def save_request(self, req: MCPRequest) -> None: ...
    def save_response(self, resp: MCPResponse) -> None: ...
    def get_response(self, request_id: str) -> MCPResponse | None: ...


class InMemoryMCPStore:
    def __init__(self) -> None:
        self._requests: dict[str, MCPRequest] = {}
        self._responses: dict[str, MCPResponse] = {}

    def save_request(self, req: MCPRequest) -> None:
        self._requests[req.request_id] = req

    def save_response(self, resp: MCPResponse) -> None:
        self._responses[resp.request_id] = resp

    def get_response(self, request_id: str) -> MCPResponse | None:
        return self._responses.get(request_id)


class MCPGateway:
    """Unified MCP gateway exposing the full CLI command surface."""

    def __init__(self, store: MCPStore) -> None:
        self._store = store

    def handle(self, request: MCPRequest) -> MCPResponse:
        self._store.save_request(request)
        resp = MCPResponse(request_id=request.request_id, method=request.method, status=200, body={"method": request.method.value, "status": "ok"}, timestamp=datetime.now(UTC))
        self._store.save_response(resp)
        return resp

    def get_response(self, request_id: str) -> MCPResponse | None:
        return self._store.get_response(request_id)
