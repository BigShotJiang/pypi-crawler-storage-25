#!/usr/bin/env python3
"""
Skill-to-MCP Tool Transformation Service

Transforms Workweaver Skill definitions into MCP (Model Context Protocol)
tool schemas for consumption by AI agents (Claude, GPT, etc.).

Implementation Reference:
- docs/PRODUCT.md P1.1.6 (lines 3050-3121)
- MCP Specification: https://modelcontextprotocol.io/
"""

from __future__ import annotations

import json
from typing import Dict, Any, List


class SkillToMCPTransformer:
    """
    Service for transforming Workweaver Skills into MCP tool schemas.

    Transforms skill definitions into MCP-compliant tool schemas
    with proper input/output schemas, descriptions, and metadata.
    """

    # MCP tool name prefix
    TOOL_NAME_PREFIX = "workweaver_"

    def __init__(
        self,
        include_tenant_param: bool = True,
        include_metadata: bool = True
    ):
        """
        Initialize transformer.

        Args:
            include_tenant_param: Whether to add tenant_id parameter to input schema
            include_metadata: Whether to include tool metadata (version, tags, etc.)
        """
        self.include_tenant_param = include_tenant_param
        self.include_metadata = include_metadata

    def transform(self, skill: Dict[str, Any]) -> Dict[str, Any]:
        """
        Transform skill definition to MCP tool schema.

        Args:
            skill: Skill definition from SkillQueryService or Skill Registry

        Returns:
            MCP tool schema with name, description, inputSchema

        Example:
            ```python
            skill = {
                "skill_id": "answer_call",
                "display_name": "Answer Call",
                "description": "Answer inbound calls and qualify intent",
                "input_schema_ref": '{"type":"object","properties":{"caller_id":{"type":"string"}}}',
                "vertical": "real-estate",
                "tags": ["voice", "inbound"]
            }

            tool = transformer.transform(skill)

            # Result:
            {
                "name": "workweaver_answer_call",
                "description": "Answer inbound calls and qualify intent",
                "inputSchema": {
                    "type": "object",
                    "properties": {
                        "tenant_id": {"type": "string", "description": "Tenant ID"},
                        "caller_id": {"type": "string", "description": "Caller ID"}
                    },
                    "required": ["tenant_id"]
                },
                "metadata": {
                    "version": "1.0.0",
                    "vertical": "real-estate",
                    "tags": ["voice", "inbound"]
                }
            }
            ```
        """
        # Extract core skill fields
        skill_id = skill.get("skill_id", "unknown")
        display_name = skill.get("display_name", "Unnamed Skill")
        description = skill.get("description", f"Workweaver skill: {display_name}")

        # Build MCP tool name
        tool_name = f"{self.TOOL_NAME_PREFIX}{skill_id}"

        # Parse input schema from skill
        input_schema = self._parse_input_schema(skill)

        # Add tenant_id parameter if enabled
        if self.include_tenant_param:
            input_schema = self._add_tenant_param(input_schema)

        # Build output schema (placeholder, will be enhanced in TASK-1.8.003)

        # Build MCP tool schema
        tool_schema = {
            "name": tool_name,
            "description": description,
            "inputSchema": input_schema
        }

        # Add metadata if enabled
        if self.include_metadata:
            metadata = self._build_metadata(skill)
            if metadata:
                tool_schema["metadata"] = metadata

        return tool_schema

    def transform_batch(self, skills: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Transform multiple skills to MCP tool schemas (batch operation).

        Args:
            skills: List of skill definitions

        Returns:
            List of MCP tool schemas
        """
        return [self.transform(skill) for skill in skills]

    def _parse_input_schema(self, skill: Dict[str, Any]) -> Dict[str, Any]:
        """
        Parse input schema from skill definition.

        Args:
            skill: Skill definition with input_schema_ref

        Returns:
            Parsed input schema as JSON object
        """
        input_schema_ref = skill.get("input_schema_ref", None)

        # Handle None input_schema_ref (use default schema)
        if input_schema_ref is None:
            return {
                "type": "object",
                "properties": {},
                "required": []
            }

        # Handle dict input_schema_ref (already parsed)
        if isinstance(input_schema_ref, dict):
            input_schema = input_schema_ref.copy()
        else:
            # Parse JSON schema reference (string)
            try:
                input_schema = json.loads(input_schema_ref)
            except json.JSONDecodeError:
                # Invalid JSON, return empty schema
                return {
                    "type": "object",
                    "properties": {},
                    "required": []
                }

        # Ensure schema has type and properties
        if "type" not in input_schema:
            input_schema["type"] = "object"
        if "properties" not in input_schema:
            input_schema["properties"] = {}
        if "required" not in input_schema:
            input_schema["required"] = []

        return input_schema

    def _add_tenant_param(self, input_schema: Dict[str, Any]) -> Dict[str, Any]:
        """
        Add tenant_id parameter to input schema.

        Args:
            input_schema: Existing input schema

        Returns:
            Updated input schema with tenant_id parameter
        """
        # Add tenant_id property
        if "properties" not in input_schema:
            input_schema["properties"] = {}

        input_schema["properties"]["tenant_id"] = {
            "type": "string",
            "description": "Tenant ID for multi-tenancy (format: TENANT#<id>)",
            "pattern": "^TENANT#"
        }

        # Add tenant_id to required list
        if "required" not in input_schema:
            input_schema["required"] = []

        if "tenant_id" not in input_schema["required"]:
            input_schema["required"].insert(0, "tenant_id")

        return input_schema

    def _build_metadata(self, skill: Dict[str, Any]) -> Dict[str, Any]:
        """
        Build tool metadata from skill definition.

        Args:
            skill: Skill definition

        Returns:
            Metadata dictionary with version, vertical, tags, etc.
        """
        metadata = {}

        # Add version
        version = skill.get("version", "1.0.0")
        metadata["version"] = version

        # Add vertical
        vertical = skill.get("vertical")
        if vertical:
            metadata["vertical"] = vertical if isinstance(vertical, str) else str(vertical)

        # Add role category
        role_category = skill.get("role_category")
        if role_category:
            metadata["role_category"] = role_category if isinstance(role_category, str) else str(role_category)

        # Add tags (always include, even if empty)
        tags = skill.get("tags", [])
        metadata["tags"] = tags

        # Add triggers
        triggers = skill.get("triggers", [])
        if triggers:
            metadata["triggers"] = [
                t if isinstance(t, str) else str(t) for t in triggers
            ]

        # Add status
        status = skill.get("status")
        if status:
            metadata["status"] = status if isinstance(status, str) else str(status)

        # Add visibility scope
        visibility = skill.get("visibility_scope")
        if visibility:
            metadata["visibility"] = visibility if isinstance(visibility, str) else str(visibility)

        # Add timestamps
        created_at = skill.get("created_at")
        if created_at:
            metadata["created_at"] = created_at

        updated_at = skill.get("updated_at")
        if updated_at:
            metadata["updated_at"] = updated_at

        return metadata


def transform_skill_to_mcp_tool(skill: Dict[str, Any]) -> Dict[str, Any]:
    """
    Convenience function to transform single skill to MCP tool schema.

    Args:
        skill: Skill definition

    Returns:
        MCP tool schema
    """
    transformer = SkillToMCPTransformer()
    return transformer.transform(skill)


def transform_skills_to_mcp_tools(skills: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
    """
    Convenience function to transform multiple skills to MCP tool schemas.

    Args:
        skills: List of skill definitions

    Returns:
        List of MCP tool schemas
    """
    transformer = SkillToMCPTransformer()
    return transformer.transform_batch(skills)
