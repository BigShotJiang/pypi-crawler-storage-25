"""TEST-ONLY: Evidence Ledger Extraction Seam.

**This package is for unit tests and product-extraction experiments only.**
Production evidence writes go through ``EvidenceLedgerService`` (S3 + DynamoDB)
located at ``apps.backend.services.evidence_ledger``, injected via
``apps.backend.dependencies.get_evidence_ledger_service()``.

Clean extraction boundary for the Evidence Ledger subsystem.
Designed for portfolio preservation: the Evidence Ledger can be extracted
as a standalone product without Workweaver-specific coupling.

The original EvidenceLedgerService (evidence_ledger.py) remains the runtime
DynamoDB/S3 implementation. This seam provides a decoupled, WORM-compliant
ledger abstraction suitable for extraction as an independent product.

Legacy requirement reference: Revenue/Proof/Portfolio Convergence - P7 Portfolio Preservation
"""

from apps.backend.extensions.evidence_ledger_seam.ledger import (
    EvidenceEntry,
    EvidenceLedger,
)
from apps.backend.extensions.evidence_ledger_seam.proof_projection import (
    project_proof_card,
)

__all__ = [
    "EvidenceEntry",
    "EvidenceLedger",
    "project_proof_card",
]
