"""TEST-ONLY: In-memory WORM Evidence Ledger.

**This module is for unit tests and product-extraction experiments only.**
Production evidence writes go through ``EvidenceLedgerService`` (S3 + DynamoDB)
located at ``apps.backend.services.evidence_ledger``, injected via
``apps.backend.dependencies.get_evidence_ledger_service()``.

Write-once, read-many ledger for evidence entries.
Records are immutable after creation -- no update or delete operations exist.

Design principles:
- EvidenceEntry is frozen (immutable Pydantic model)
- EvidenceLedger.record() only appends; no mutation methods
- query() and export() are read-only projections
- Decoupled from Workweaver-specific concerns (no tenant auth, no DynamoDB)

Legacy requirement reference: Revenue/Proof/Portfolio Convergence - P7 Portfolio Preservation
"""

from __future__ import annotations

import logging
from datetime import datetime, UTC

import ulid
from pydantic import BaseModel, Field

logger = logging.getLogger(__name__)


def _utcnow() -> datetime:
    """Return current UTC time (timezone-aware)."""
    return datetime.now(UTC)


def _generate_ulid() -> str:
    """Generate a new ULID string for entry IDs."""
    return ulid.new().str


class EvidenceEntry(BaseModel, frozen=True):
    """Immutable evidence record.

    frozen=True enforces WORM semantics at the model level:
    once created, no field can be modified.
    """

    entry_id: str = Field(default_factory=_generate_ulid, description="Unique entry ID (ULID)")
    mission_ref: str = Field(..., description="Reference to the originating mission")
    event_type: str = Field(..., description="Evidence event type (e.g. email_sent, crm_update)")
    summary: str = Field(..., description="Human-readable summary of the evidence")
    actor: str = Field(..., description="Agent or user who produced the evidence")
    recorded_at: datetime = Field(default_factory=_utcnow, description="When the entry was recorded (UTC)")
    evidence_ref: str | None = Field(default=None, description="Optional reference to external evidence artifact")
    metadata: dict[str, object] = Field(default_factory=dict, description="Arbitrary metadata")


class EvidenceLedger:
    """In-memory WORM ledger for evidence entries. TEST-ONLY.

    Append-only: record() adds entries, no update/delete methods exist.
    Thread-safe for single-writer scenarios (typical agent execution).

    Production code MUST use ``EvidenceLedgerService`` (S3 + DynamoDB) via
    ``apps.backend.dependencies.get_evidence_ledger_service()`` instead.
    """

    def __init__(self) -> None:
        self._entries: list[EvidenceEntry] = []

    @property
    def size(self) -> int:
        """Number of entries in the ledger."""
        return len(self._entries)

    def record(self, entry: EvidenceEntry) -> EvidenceEntry:
        """Append an immutable evidence entry to the ledger.

        Args:
            entry: The evidence entry to record.

        Returns:
            The recorded entry (same object, since it is frozen).
        """
        self._entries.append(entry)
        logger.debug(
            "Evidence recorded",
            extra={"entry_id": entry.entry_id, "event_type": entry.event_type},
        )
        return entry

    def query(
        self,
        *,
        mission_ref: str | None = None,
        event_type: str | None = None,
        actor: str | None = None,
        limit: int = 100,
    ) -> list[EvidenceEntry]:
        """Query entries with optional filters.

        All filters are AND-combined. Results are ordered newest-first.

        Args:
            mission_ref: Filter by mission reference.
            event_type: Filter by event type.
            actor: Filter by actor.
            limit: Maximum entries to return.

        Returns:
            Filtered list of evidence entries, newest first.
        """
        results = self._entries
        if mission_ref is not None:
            results = [e for e in results if e.mission_ref == mission_ref]
        if event_type is not None:
            results = [e for e in results if e.event_type == event_type]
        if actor is not None:
            results = [e for e in results if e.actor == actor]
        # Newest first
        results = sorted(results, key=lambda e: e.recorded_at, reverse=True)
        return results[:limit]

    def export(
        self,
        *,
        mission_ref: str | None = None,
        format: str = "dict",  # noqa: A002 -- matches export API convention
    ) -> list[dict[str, object]]:
        """Export entries as serializable dicts.

        Args:
            mission_ref: Optional filter by mission.
            format: Export format (only 'dict' supported currently).

        Returns:
            List of entry dicts suitable for JSON serialization.
        """
        entries = self.query(mission_ref=mission_ref, limit=len(self._entries))
        return [e.model_dump(mode="json") for e in entries]
