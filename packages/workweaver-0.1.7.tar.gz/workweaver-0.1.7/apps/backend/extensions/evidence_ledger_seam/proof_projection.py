"""TEST-ONLY: Proof Projection -- Evidence entries to ProofCard views.

**This module is for unit tests and product-extraction experiments only.**
Production evidence writes go through ``EvidenceLedgerService`` (S3 + DynamoDB).

Converts a list of EvidenceEntry records into a ProofCard,
connecting the extraction seam to the existing Revenue Pack P2 model.

Legacy requirement reference: Revenue/Proof/Portfolio Convergence - P7 Portfolio Preservation
"""

from __future__ import annotations

from apps.backend.models.proof_card import ProofCard, ProofCardStatus, ProofStep
from apps.backend.extensions.evidence_ledger_seam.ledger import EvidenceEntry


def project_proof_card(
    *,
    entries: list[EvidenceEntry],
    mission_ref: str,
    title: str,
    actor: str,
    tenant_id: str,
) -> ProofCard:
    """Project a list of evidence entries into a ProofCard.

    Each EvidenceEntry becomes a ProofStep in the card's chain.
    The card status is COMPLETED if there are entries, IN_PROGRESS otherwise.

    Args:
        entries: Evidence entries to project.
        mission_ref: Mission reference for the proof card.
        title: Human-readable title.
        actor: Agent or user who executed the mission.
        tenant_id: Tenant identifier.

    Returns:
        A ProofCard populated from the evidence entries.
    """
    chain = [
        ProofStep(
            action=entry.event_type,
            description=entry.summary,
            timestamp=entry.recorded_at,
            evidence_ref=entry.evidence_ref,
            metadata=dict(entry.metadata),
        )
        for entry in entries
    ]

    status = ProofCardStatus.COMPLETED if chain else ProofCardStatus.IN_PROGRESS

    return ProofCard(
        mission_ref=mission_ref,
        title=title,
        status=status,
        actor=actor,
        chain=chain,
        tenant_id=tenant_id,
    )
