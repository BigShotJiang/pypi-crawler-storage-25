"""BDISurface — explicit Belief/Desire/Intention model for Zara (#1534)."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class BDIMode(str, Enum):
    BELIEF = "belief"
    DESIRE = "desire"
    INTENTION = "intention"


class BDIState(BaseModel):
    model_config = ConfigDict(frozen=True)
    tenant_id: str
    mode: BDIMode
    content: str
    confidence: float = 1.0
    source: str = ""
    timestamp: datetime


class BDIFrame(BaseModel):
    model_config = ConfigDict(frozen=True)
    frame_id: str
    tenant_id: str
    beliefs: list[BDIState]
    desires: list[BDIState]
    intentions: list[BDIState]
    created_at: datetime


@runtime_checkable
class BDIStore(Protocol):
    def save_frame(self, frame: BDIFrame) -> None: ...
    def get_frame(self, frame_id: str) -> BDIFrame | None: ...
    def list_frames(self, tenant_id: str, limit: int = 50) -> list[BDIFrame]: ...


class InMemoryBDIStore:
    def __init__(self) -> None:
        self._frames: dict[str, BDIFrame] = {}

    def save_frame(self, frame: BDIFrame) -> None:
        self._frames[frame.frame_id] = frame

    def get_frame(self, frame_id: str) -> BDIFrame | None:
        return self._frames.get(frame_id)

    def list_frames(self, tenant_id: str, limit: int = 50) -> list[BDIFrame]:
        return [f for f in self._frames.values() if f.tenant_id == tenant_id][:limit]


class BDISurface:
    """Maintains an explicit Belief/Desire/Intention model."""

    def __init__(self, store: BDIStore) -> None:
        self._store = store

    def create_frame(self, frame_id: str, tenant_id: str, beliefs: list[BDIState] | None = None, desires: list[BDIState] | None = None, intentions: list[BDIState] | None = None) -> BDIFrame:
        frame = BDIFrame(frame_id=frame_id, tenant_id=tenant_id, beliefs=beliefs or [], desires=desires or [], intentions=intentions or [], created_at=datetime.now(UTC))
        self._store.save_frame(frame)
        return frame

    def add_state(self, frame_id: str, state: BDIState) -> BDIFrame | None:
        frame = self._store.get_frame(frame_id)
        if not frame:
            return None
        if state.mode == BDIMode.BELIEF:
            beliefs = [*frame.beliefs, state]
            updated = BDIFrame(frame_id=frame.frame_id, tenant_id=frame.tenant_id, beliefs=beliefs, desires=frame.desires, intentions=frame.intentions, created_at=frame.created_at)
        elif state.mode == BDIMode.DESIRE:
            desires = [*frame.desires, state]
            updated = BDIFrame(frame_id=frame.frame_id, tenant_id=frame.tenant_id, beliefs=frame.beliefs, desires=desires, intentions=frame.intentions, created_at=frame.created_at)
        else:
            intentions = [*frame.intentions, state]
            updated = BDIFrame(frame_id=frame.frame_id, tenant_id=frame.tenant_id, beliefs=frame.beliefs, desires=frame.desires, intentions=intentions, created_at=frame.created_at)
        self._store.save_frame(updated)
        return updated

    def get_frame(self, frame_id: str) -> BDIFrame | None:
        return self._store.get_frame(frame_id)

    def list_frames(self, tenant_id: str, limit: int = 50) -> list[BDIFrame]:
        return self._store.list_frames(tenant_id, limit)
