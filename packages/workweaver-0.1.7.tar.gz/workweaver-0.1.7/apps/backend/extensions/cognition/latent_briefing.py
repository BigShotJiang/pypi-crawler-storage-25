"""LatentBriefing — compress context for cross-agent handoff (#1532)."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class BriefingFormat(str, Enum):
    SUMMARY = "summary"
    KEY_FACTS = "key_facts"
    ACTION_ITEMS = "action_items"
    FULL = "full"


class BriefingEntry(BaseModel):
    model_config = ConfigDict(frozen=True)
    key: str
    value: str
    priority: float = 0.5
    category: str = "general"


class LatentBriefing(BaseModel):
    model_config = ConfigDict(frozen=True)
    briefing_id: str
    tenant_id: str
    source_agent: str
    target_agent: str
    entries: list[BriefingEntry]
    format: BriefingFormat
    compression_ratio: float
    created_at: datetime


@runtime_checkable
class BriefingStore(Protocol):
    def save_briefing(self, briefing: LatentBriefing) -> None: ...
    def get_briefing(self, briefing_id: str) -> LatentBriefing | None: ...
    def list_briefings(self, tenant_id: str, limit: int = 50) -> list[LatentBriefing]: ...


class InMemoryBriefingStore:
    def __init__(self) -> None:
        self._briefings: dict[str, LatentBriefing] = {}

    def save_briefing(self, briefing: LatentBriefing) -> None:
        self._briefings[briefing.briefing_id] = briefing

    def get_briefing(self, briefing_id: str) -> LatentBriefing | None:
        return self._briefings.get(briefing_id)

    def list_briefings(self, tenant_id: str, limit: int = 50) -> list[LatentBriefing]:
        return [b for b in self._briefings.values() if b.tenant_id == tenant_id][:limit]


class LatentBriefingService:
    """Compresses context for efficient cross-agent handoff."""

    def __init__(self, store: BriefingStore, max_entries: int = 20) -> None:
        self._store = store
        self._max_entries = max_entries

    def compress(self, briefing_id: str, tenant_id: str, source_agent: str, target_agent: str, context: dict[str, Any], fmt: BriefingFormat = BriefingFormat.SUMMARY) -> LatentBriefing:
        raw_count = len(context)
        entries = self._extract(context)
        entries = sorted(entries, key=lambda e: e.priority, reverse=True)[: self._max_entries]
        ratio = len(entries) / raw_count if raw_count > 0 else 0.0
        briefing = LatentBriefing(briefing_id=briefing_id, tenant_id=tenant_id, source_agent=source_agent, target_agent=target_agent, entries=entries, format=fmt, compression_ratio=ratio, created_at=datetime.now(UTC))
        self._store.save_briefing(briefing)
        return briefing

    def _extract(self, context: dict[str, Any]) -> list[BriefingEntry]:
        entries: list[BriefingEntry] = []
        for k, v in context.items():
            if isinstance(v, str):
                entries.append(BriefingEntry(key=k, value=v))
            elif isinstance(v, dict):
                for sk, sv in v.items():
                    entries.append(BriefingEntry(key=f"{k}.{sk}", value=str(sv), category=k))
            elif isinstance(v, list):
                entries.append(BriefingEntry(key=k, value=str(v)[:200], category="list"))
            else:
                entries.append(BriefingEntry(key=k, value=str(v)))
        return entries

    def get_briefing(self, briefing_id: str) -> LatentBriefing | None:
        return self._store.get_briefing(briefing_id)

    def list_briefings(self, tenant_id: str, limit: int = 50) -> list[LatentBriefing]:
        return self._store.list_briefings(tenant_id, limit)
