"""FitProbe — post-merge eval: does form resolve the misfit? (#1533)."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class FitVerdict(str, Enum):
    RESOLVED = "resolved"
    PARTIAL = "partial"
    UNRESOLVED = "unresolved"
    REGRESSION = "regression"


class FitMetric(BaseModel):
    model_config = ConfigDict(frozen=True)
    name: str
    before: float
    after: float
    target: float
    weight: float = 1.0


class FitResult(BaseModel):
    model_config = ConfigDict(frozen=True)
    probe_id: str
    tenant_id: str
    misfit_id: str
    metrics: list[FitMetric]
    verdict: FitVerdict
    score: float
    timestamp: datetime


@runtime_checkable
class FitProbeStore(Protocol):
    def save_result(self, result: FitResult) -> None: ...
    def get_result(self, probe_id: str) -> FitResult | None: ...
    def list_results(self, tenant_id: str, limit: int = 50) -> list[FitResult]: ...


class InMemoryFitProbeStore:
    def __init__(self) -> None:
        self._results: dict[str, FitResult] = {}

    def save_result(self, result: FitResult) -> None:
        self._results[result.probe_id] = result

    def get_result(self, probe_id: str) -> FitResult | None:
        return self._results.get(probe_id)

    def list_results(self, tenant_id: str, limit: int = 50) -> list[FitResult]:
        return [r for r in self._results.values() if r.tenant_id == tenant_id][:limit]


def _compute_score(metrics: list[FitMetric]) -> float:
    if not metrics:
        return 0.0
    total_weight = sum(m.weight for m in metrics)
    if total_weight == 0:
        return 0.0
    weighted_improvement = sum(
        m.weight
        * (abs(m.target - m.before) - abs(m.target - m.after))
        / max(abs(m.target - m.before), 1e-6)
        for m in metrics
    )
    return weighted_improvement / total_weight


def _verdict(score: float) -> FitVerdict:
    if score >= 0.8:
        return FitVerdict.RESOLVED
    if score >= 0.4:
        return FitVerdict.PARTIAL
    if score >= 0.0:
        return FitVerdict.UNRESOLVED
    return FitVerdict.REGRESSION


class FitProbe:
    """Evaluates whether a form actually resolves its misfit."""

    def __init__(self, store: FitProbeStore) -> None:
        self._store = store

    def probe(self, probe_id: str, tenant_id: str, misfit_id: str, metrics: list[FitMetric]) -> FitResult:
        score = _compute_score(metrics)
        result = FitResult(probe_id=probe_id, tenant_id=tenant_id, misfit_id=misfit_id, metrics=metrics, verdict=_verdict(score), score=score, timestamp=datetime.now(UTC))
        self._store.save_result(result)
        return result

    def get_result(self, probe_id: str) -> FitResult | None:
        return self._store.get_result(probe_id)

    def list_results(self, tenant_id: str, limit: int = 50) -> list[FitResult]:
        return self._store.list_results(tenant_id, limit)
