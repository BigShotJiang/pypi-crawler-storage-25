"""Workweaver inbound extension contract surface."""

from apps.backend.extensions.base import (
    ExtensionAdapterShim,
    ExtensionLifecycle,
    ExtensionManifest,
    WorkweaverExtension,
    WorkweaverExtensionContract,
    extension_manifest_for,
)

__all__ = [
    "ExtensionAdapterShim",
    "ExtensionLifecycle",
    "ExtensionManifest",
    "WorkweaverExtension",
    "WorkweaverExtensionContract",
    "extension_manifest_for",
]
