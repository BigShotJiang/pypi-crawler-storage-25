"""Payroll provider protocol for pluggable payroll backends.

Defines the contract that Gusto, Deel, and future payroll connectors
must satisfy. Uses typing.Protocol for structural subtyping so
connectors do not need to inherit from a base class.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import ClassVar, Protocol, runtime_checkable

from apps.backend.extensions import ExtensionManifest, WorkweaverExtensionContract
from .models import Employee, PayPeriod, PayStub


class TaxFilingStatus(str, Enum):
    """Outcome of a tax filing request."""

    SUBMITTED = "submitted"
    ACCEPTED = "accepted"
    REJECTED = "rejected"
    PENDING = "pending"


@dataclass(frozen=True)
class EmployeeResult:
    """Result of creating or updating an employee in the payroll provider."""

    provider_id: str
    success: bool
    error: str = ""


@dataclass(frozen=True)
class PayrollRunResult:
    """Result of executing a payroll run."""

    run_id: str
    success: bool
    gross_total: str = "0"
    net_total: str = "0"
    employee_count: int = 0
    error: str = ""


@dataclass(frozen=True)
class TaxFilingResult:
    """Result of filing taxes for a pay period."""

    filing_id: str
    status: TaxFilingStatus = TaxFilingStatus.PENDING
    confirmation_number: str = ""
    error: str = ""


@runtime_checkable
class PayrollProvider(WorkweaverExtensionContract, Protocol):
    """Protocol for payroll provider implementations.

    Any class that implements these four methods satisfies the protocol
    without needing explicit inheritance.
    """

    extension_manifest: ClassVar[ExtensionManifest] = ExtensionManifest(
        id="workweaver.payroll-provider",
        display_name="Payroll Provider",
        version="1.0.0",
        capability_class="connector",
        modality="api",
        side_effect_tags=("employee-write", "payroll-run", "tax-file"),
    )

    async def create_employee(self, employee: Employee) -> EmployeeResult:
        """Register an employee with the payroll provider."""
        ...

    async def run_payroll(
        self,
        period: PayPeriod,
        employees: list[Employee],
    ) -> PayrollRunResult:
        """Execute a payroll run for the given period and employees."""
        ...

    async def get_pay_stubs(self, period: PayPeriod) -> list[PayStub]:
        """Retrieve pay stubs for a completed pay period."""
        ...

    async def file_taxes(self, period: PayPeriod) -> TaxFilingResult:
        """File tax withholdings for a pay period."""
        ...
