"""Payroll domain models for autonomous business operations.

Covers: employees, pay periods, payroll runs, deductions, and pay stubs.
These are provider-agnostic value objects used by the PayrollProvider
protocol and all payroll connectors (Gusto, Deel, etc.).
"""

from __future__ import annotations

from dataclasses import dataclass, field
from datetime import date
from decimal import Decimal
from enum import Enum


class EmployeeStatus(str, Enum):
    """Lifecycle status of an employee."""

    ACTIVE = "active"
    INACTIVE = "inactive"
    TERMINATED = "terminated"
    ON_LEAVE = "on_leave"
    ONBOARDING = "onboarding"


class CompensationType(str, Enum):
    """How an employee is compensated."""

    SALARY = "salary"
    HOURLY = "hourly"
    CONTRACT = "contract"


class DeductionType(str, Enum):
    """Category of a payroll deduction."""

    TAX = "tax"
    INSURANCE = "insurance"
    RETIREMENT = "retirement"
    OTHER = "other"


class PayPeriodStatus(str, Enum):
    """Processing state of a pay period."""

    DRAFT = "draft"
    PROCESSING = "processing"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass(frozen=True)
class TaxInfo:
    """Employee tax information (PII-sensitive, never log raw)."""

    filing_status: str = ""
    federal_allowances: int = 0
    state_allowances: int = 0
    additional_withholding: Decimal = Decimal("0")
    tax_id_last_four: str = ""


@dataclass(frozen=True)
class BankInfo:
    """Employee bank account for direct deposit (PII-sensitive)."""

    routing_number_last_four: str = ""
    account_number_last_four: str = ""
    account_type: str = "checking"
    bank_name: str = ""


@dataclass
class Employee:
    """An employee in the payroll system."""

    id: str
    name: str
    email: str
    role: str = ""
    compensation_type: CompensationType = CompensationType.SALARY
    compensation_amount: Decimal = Decimal("0")
    tax_info: TaxInfo = field(default_factory=TaxInfo)
    bank_info: BankInfo = field(default_factory=BankInfo)
    status: EmployeeStatus = EmployeeStatus.ACTIVE
    department: str = ""
    start_date: date | None = None

    def to_dict(self) -> dict[str, object]:
        """Serialize to dict with PII fields masked."""
        return {
            "id": self.id,
            "name": self.name,
            "email": self.email,
            "role": self.role,
            "compensation_type": self.compensation_type.value,
            "compensation_amount": str(self.compensation_amount),
            "status": self.status.value,
            "department": self.department,
            "start_date": self.start_date.isoformat() if self.start_date else None,
            "tax_info": {
                "filing_status": self.tax_info.filing_status,
                "tax_id_last_four": self.tax_info.tax_id_last_four,
            },
            "bank_info": {
                "account_type": self.bank_info.account_type,
                "bank_name": self.bank_info.bank_name,
                "routing_last_four": self.bank_info.routing_number_last_four,
                "account_last_four": self.bank_info.account_number_last_four,
            },
        }


@dataclass
class Deduction:
    """A single deduction line item on a pay stub."""

    type: DeductionType
    amount: Decimal
    description: str = ""

    def to_dict(self) -> dict[str, object]:
        return {
            "type": self.type.value,
            "amount": str(self.amount),
            "description": self.description,
        }


@dataclass
class PayPeriod:
    """A pay period (e.g. biweekly, monthly)."""

    id: str
    start_date: date
    end_date: date
    status: PayPeriodStatus = PayPeriodStatus.DRAFT

    def to_dict(self) -> dict[str, object]:
        return {
            "id": self.id,
            "start_date": self.start_date.isoformat(),
            "end_date": self.end_date.isoformat(),
            "status": self.status.value,
        }


@dataclass
class PayrollRun:
    """A payroll run for a specific period."""

    id: str
    period: PayPeriod
    employee_ids: list[str] = field(default_factory=list)
    gross_total: Decimal = Decimal("0")
    deductions_total: Decimal = Decimal("0")
    net_total: Decimal = Decimal("0")
    tax_withholdings: Decimal = Decimal("0")
    status: PayPeriodStatus = PayPeriodStatus.DRAFT

    def to_dict(self) -> dict[str, object]:
        return {
            "id": self.id,
            "period": self.period.to_dict(),
            "employee_ids": self.employee_ids,
            "gross_total": str(self.gross_total),
            "deductions_total": str(self.deductions_total),
            "net_total": str(self.net_total),
            "tax_withholdings": str(self.tax_withholdings),
            "status": self.status.value,
        }


@dataclass
class PayStub:
    """An individual employee's pay stub for a period."""

    employee_id: str
    period_id: str
    gross_pay: Decimal = Decimal("0")
    deductions: list[Deduction] = field(default_factory=list)
    net_pay: Decimal = Decimal("0")
    pdf_url: str = ""

    @property
    def total_deductions(self) -> Decimal:
        return sum((d.amount for d in self.deductions), Decimal("0"))

    def to_dict(self) -> dict[str, object]:
        return {
            "employee_id": self.employee_id,
            "period_id": self.period_id,
            "gross_pay": str(self.gross_pay),
            "deductions": [d.to_dict() for d in self.deductions],
            "net_pay": str(self.net_pay),
            "total_deductions": str(self.total_deductions),
            "pdf_url": self.pdf_url,
        }
