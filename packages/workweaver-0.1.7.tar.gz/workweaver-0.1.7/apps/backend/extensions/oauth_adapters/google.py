"""Google OAuth2 + PKCE Adapter.

Implements OAuth2 authorization code flow with PKCE for Google services
(Gmail, Calendar, Drive, etc.).

Source: docs/PRODUCT.md#Part20
"""

import logging
from typing import Any
from urllib.parse import urlencode

import httpx

from apps.backend.providers.secret_provider import get_secret_from_env

logger = logging.getLogger(__name__)


class GoogleOAuthAdapter:
    """Google OAuth2 adapter with PKCE support."""

    provider_name = "google"

    # Google OAuth2 endpoints
    AUTH_URL = "https://accounts.google.com/o/oauth2/v2/auth"
    TOKEN_URL = "https://oauth2.googleapis.com/token"
    REVOKE_URL = "https://oauth2.googleapis.com/revoke"

    # Default scopes for Workweaver
    DEFAULT_SCOPES = [
        "openid",
        "email",
        "profile",
        "https://www.googleapis.com/auth/calendar",
        "https://www.googleapis.com/auth/calendar.events",
        "https://www.googleapis.com/auth/gmail.send",
    ]

    def __init__(self):
        """Initialize Google OAuth adapter with credentials from environment."""
        self.client_id = get_secret_from_env("google/client_id") or ""
        self.client_secret = get_secret_from_env("google/client_secret") or ""

        if not self.client_id:
            raise ValueError(
                "Google client ID not configured. Set WORKWEAVER_OAUTH_GOOGLE_CLIENT_ID or GOOGLE_CLIENT_ID."
            )
        if not self.client_secret:
            logger.warning(
                "Google client secret not set. Set WORKWEAVER_OAUTH_GOOGLE_CLIENT_SECRET or GOOGLE_CLIENT_SECRET."
            )

    def get_authorization_url(self, scopes: list[str], state: str, code_challenge: str, redirect_uri: str) -> str:
        """Generate Google OAuth2 authorization URL with PKCE.

        Args:
            scopes: List of OAuth scopes to request
            state: CSRF protection token
            code_challenge: PKCE code challenge (S256)
            redirect_uri: OAuth callback URL

        Returns:
            Full authorization URL to redirect user to
        """
        params = {
            "client_id": self.client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": " ".join(scopes),
            "state": state,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
            "access_type": "offline",  # Request refresh token
            "prompt": "consent",  # Force consent to ensure refresh token
        }

        url = f"{self.AUTH_URL}?{urlencode(params)}"
        logger.debug("Generated Google auth URL: %s", url)
        return url

    def exchange_code(self, code: str, code_verifier: str, redirect_uri: str) -> dict[str, Any]:
        """Exchange authorization code for access and refresh tokens.

        Args:
            code: Authorization code from callback
            code_verifier: PKCE code verifier
            redirect_uri: OAuth callback URL (must match authorization)

        Returns:
            Dict with keys: access_token, refresh_token, expires_in, scopes

        Raises:
            ValueError: If token exchange fails
        """
        data = {
            "grant_type": "authorization_code",
            "code": code,
            "code_verifier": code_verifier,
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "redirect_uri": redirect_uri,
        }

        response = httpx.post(self.TOKEN_URL, data=data)

        if response.status_code != 200:
            error_data = response.json()
            error_msg = error_data.get("error", "unknown_error")
            error_desc = error_data.get("error_description", "Token exchange failed")
            logger.error("Google token exchange failed: %s - %s", error_msg, error_desc)
            raise ValueError(f"{error_msg}: {error_desc}")

        token_data = response.json()

        # Parse scopes from space-separated string to list
        scope_str = token_data.get("scope", "")
        scopes = scope_str.split() if scope_str else []

        result = {
            "access_token": token_data["access_token"],
            "refresh_token": token_data.get("refresh_token", ""),
            "expires_in": token_data.get("expires_in", 3600),
            "scopes": scopes,
        }

        logger.info("Google token exchange successful, scopes: %s", ", ".join(scopes))
        return result

    def refresh_token(self, refresh_token_value: str) -> dict[str, Any]:
        """Refresh an expired access token.

        Args:
            refresh_token_value: Refresh token from initial authorization

        Returns:
            Dict with keys: access_token, expires_in, and optionally refresh_token

        Raises:
            ValueError: If token refresh fails
        """
        data = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token_value,
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }

        response = httpx.post(self.TOKEN_URL, data=data)

        if response.status_code != 200:
            error_data = response.json()
            error_msg = error_data.get("error", "unknown_error")
            error_desc = error_data.get("error_description", "Token refresh failed")
            logger.error("Google token refresh failed: %s - %s", error_msg, error_desc)
            raise ValueError(f"{error_msg}: {error_desc}")

        token_data = response.json()

        result = {
            "access_token": token_data["access_token"],
            "expires_in": token_data.get("expires_in", 3600),
        }

        # Google may return a new refresh token (rotated)
        if "refresh_token" in token_data:
            result["refresh_token"] = token_data["refresh_token"]

        logger.info("Google token refresh successful")
        return result

    def revoke_token(self, token: str) -> bool:
        """Revoke an access or refresh token at Google.

        Args:
            token: Access token or refresh token to revoke

        Returns:
            True if revocation successful, False otherwise
        """
        data = {"token": token}

        try:
            response = httpx.post(self.REVOKE_URL, data=data)
            success = response.status_code == 200

            if success:
                logger.info("Google token revocation successful")
            else:
                logger.warning(
                    "Google token revocation failed with status %s",
                    response.status_code,
                )

            return success
        except Exception as e:
            logger.error("Google token revocation error: %s", e)
            return False
