"""OAuth Provider Adapters.

Provider-specific OAuth2 implementations for calendar, email, and file services.
Each adapter implements the OAuthProviderAdapter protocol.
"""

from apps.backend.extensions.oauth_adapters.google import GoogleOAuthAdapter
from apps.backend.extensions.oauth_adapters.microsoft import MicrosoftOAuthAdapter

__all__ = ["GoogleOAuthAdapter", "MicrosoftOAuthAdapter"]
