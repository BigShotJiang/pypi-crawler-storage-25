"""Microsoft OAuth2 + PKCE Adapter.

Implements OAuth2 authorization code flow with PKCE for Microsoft services
(Outlook Mail send, Microsoft Calendar, Teams meetings) using Microsoft
Identity Platform v2.0. OneDrive is intentionally not supported — see
#821 (Files.ReadWrite scope drop) and #1155 (OneDriveConnector removal).

Source: docs/PRODUCT.md#Part20
"""

import logging
from typing import Any
from urllib.parse import urlencode

import httpx

from apps.backend.providers.secret_provider import get_secret_from_env

logger = logging.getLogger(__name__)


class MicrosoftOAuthAdapter:
    """Microsoft OAuth2 adapter with PKCE support."""

    provider_name = "microsoft"

    # Microsoft Identity Platform v2.0 endpoints
    AUTH_URL = "https://login.microsoftonline.com/common/oauth2/v2.0/authorize"
    TOKEN_URL = "https://login.microsoftonline.com/common/oauth2/v2.0/token"
    LOGOUT_URL = "https://login.microsoftonline.com/common/oauth2/v2.0/logout"

    # Default scopes for Workweaver (Outlook mail + Calendar)
    DEFAULT_SCOPES = [
        "openid",
        "email",
        "profile",
        "Mail.Send",
        "Calendars.ReadWrite",
        "offline_access",
    ]

    def __init__(self) -> None:
        """Initialize Microsoft OAuth adapter with credentials from environment."""
        self.client_id = get_secret_from_env("microsoft/client_id") or ""
        self.client_secret = get_secret_from_env("microsoft/client_secret") or ""

        if not self.client_id:
            raise ValueError(
                "Microsoft client ID not configured. Set WORKWEAVER_OAUTH_MICROSOFT_CLIENT_ID or MICROSOFT_CLIENT_ID."
            )
        if not self.client_secret:
            logger.warning(
                "Microsoft client secret not set. Set WORKWEAVER_OAUTH_MICROSOFT_CLIENT_SECRET or MICROSOFT_CLIENT_SECRET."
            )

    def get_authorization_url(
        self, scopes: list[str], state: str, code_challenge: str, redirect_uri: str
    ) -> str:
        """Generate Microsoft OAuth2 authorization URL with PKCE.

        Args:
            scopes: List of OAuth scopes to request
            state: CSRF protection token
            code_challenge: PKCE code challenge (S256)
            redirect_uri: OAuth callback URL

        Returns:
            Full authorization URL to redirect user to
        """
        params = {
            "client_id": self.client_id,
            "redirect_uri": redirect_uri,
            "response_type": "code",
            "scope": " ".join(scopes),
            "state": state,
            "code_challenge": code_challenge,
            "code_challenge_method": "S256",
            "prompt": "consent",
        }

        url = f"{self.AUTH_URL}?{urlencode(params)}"
        logger.debug("Generated Microsoft auth URL: %s", url)
        return url

    def exchange_code(
        self, code: str, code_verifier: str, redirect_uri: str
    ) -> dict[str, Any]:
        """Exchange authorization code for access and refresh tokens.

        Args:
            code: Authorization code from callback
            code_verifier: PKCE code verifier
            redirect_uri: OAuth callback URL (must match authorization)

        Returns:
            Dict with keys: access_token, refresh_token, expires_in, scopes

        Raises:
            ValueError: If token exchange fails
        """
        data = {
            "grant_type": "authorization_code",
            "code": code,
            "code_verifier": code_verifier,
            "client_id": self.client_id,
            "client_secret": self.client_secret,
            "redirect_uri": redirect_uri,
        }

        response = httpx.post(self.TOKEN_URL, data=data)

        if response.status_code != 200:
            error_data = response.json()
            error_msg = error_data.get("error", "unknown_error")
            error_desc = error_data.get("error_description", "Token exchange failed")
            logger.error(
                "Microsoft token exchange failed: %s - %s", error_msg, error_desc
            )
            raise ValueError(f"{error_msg}: {error_desc}")

        token_data = response.json()

        # Parse scopes from space-separated string to list
        scope_str = token_data.get("scope", "")
        scopes = scope_str.split() if scope_str else []

        result = {
            "access_token": token_data["access_token"],
            "refresh_token": token_data.get("refresh_token", ""),
            "expires_in": token_data.get("expires_in", 3600),
            "scopes": scopes,
        }

        logger.info(
            "Microsoft token exchange successful, scopes: %s", ", ".join(scopes)
        )
        return result

    def refresh_token(self, refresh_token_value: str) -> dict[str, Any]:
        """Refresh an expired access token.

        Args:
            refresh_token_value: Refresh token from initial authorization

        Returns:
            Dict with keys: access_token, expires_in, and optionally refresh_token

        Raises:
            ValueError: If token refresh fails
        """
        data = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token_value,
            "client_id": self.client_id,
            "client_secret": self.client_secret,
        }

        response = httpx.post(self.TOKEN_URL, data=data)

        if response.status_code != 200:
            error_data = response.json()
            error_msg = error_data.get("error", "unknown_error")
            error_desc = error_data.get("error_description", "Token refresh failed")
            logger.error(
                "Microsoft token refresh failed: %s - %s", error_msg, error_desc
            )
            raise ValueError(f"{error_msg}: {error_desc}")

        token_data = response.json()

        result: dict[str, Any] = {
            "access_token": token_data["access_token"],
            "expires_in": token_data.get("expires_in", 3600),
        }

        # Microsoft may return a new refresh token (rotated)
        if "refresh_token" in token_data:
            result["refresh_token"] = token_data["refresh_token"]

        logger.info("Microsoft token refresh successful")
        return result

    def revoke_token(self, token: str) -> bool:
        """Revoke a token at Microsoft.

        Microsoft Identity Platform v2.0 does not provide a simple token
        revocation endpoint like Google. The recommended approach is to use
        the logout endpoint or let tokens expire naturally.

        This method returns True and logs a warning. For full session
        invalidation, redirect users to the LOGOUT_URL.

        Args:
            token: Access token or refresh token to revoke

        Returns:
            True always (Microsoft does not support simple revocation)
        """
        logger.warning(
            "Microsoft does not support simple token revocation. "
            "Token will expire naturally. For full session invalidation, "
            "redirect user to: %s",
            self.LOGOUT_URL,
        )
        return True
