"""Ingestion substrate -- reusable file parsing, normalization, and chunking.

Shared contract between WorkMemory ingestion and product file uploads.
Provides format detection, structured parsing via pluggable handlers,
whitespace normalization, and configurable chunking strategies.
"""

from apps.backend.extensions.ingestion.substrate import (
    Chunk,
    ChunkStrategy,
    ContentFormat,
    FormatHandler,
    IngestionSubstrate,
    Metadata,
    NormalizedContent,
    ParsedContent,
)

__all__ = [
    "Chunk",
    "ChunkStrategy",
    "ContentFormat",
    "FormatHandler",
    "IngestionSubstrate",
    "Metadata",
    "NormalizedContent",
    "ParsedContent",
]
