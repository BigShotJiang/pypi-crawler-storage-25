"""Built-in format handlers for the ingestion substrate.

Each handler implements the FormatHandler protocol for a specific ContentFormat.
Where possible, handlers delegate to apps.shared.document_extraction to avoid
duplicating extraction logic.
"""

from __future__ import annotations

import json
import re
from html.parser import HTMLParser

from apps.shared.document_extraction import decode_text_bytes, extract_csv_text

from apps.backend.extensions.ingestion.substrate import (
    ContentFormat,
    IngestionSubstrate,
    Metadata,
    ParsedContent,
)


# ---------------------------------------------------------------------------
# Plaintext
# ---------------------------------------------------------------------------


class PlaintextHandler:
    """Handler for plain text files."""

    def can_handle(self, format: ContentFormat) -> bool:
        return format == ContentFormat.PLAINTEXT

    def parse(self, data: bytes) -> ParsedContent:
        text = decode_text_bytes(data)
        return ParsedContent(
            raw_text=text,
            metadata=Metadata(format=ContentFormat.PLAINTEXT, size_bytes=len(data)),
        )


# ---------------------------------------------------------------------------
# Markdown
# ---------------------------------------------------------------------------

# Matches lines starting with 1-6 # characters followed by a space.
_MD_HEADING_RE = re.compile(r"^#{1,6}\s+", re.MULTILINE)


class MarkdownHandler:
    """Handler for Markdown files with heading-based section detection."""

    def can_handle(self, format: ContentFormat) -> bool:
        return format == ContentFormat.MARKDOWN

    def parse(self, data: bytes) -> ParsedContent:
        text = decode_text_bytes(data)
        sections = self._extract_sections(text)
        return ParsedContent(
            raw_text=text,
            metadata=Metadata(format=ContentFormat.MARKDOWN, size_bytes=len(data)),
            sections=sections,
        )

    @staticmethod
    def _extract_sections(text: str) -> list[str]:
        """Split markdown into sections by headings."""
        headings = list(_MD_HEADING_RE.finditer(text))
        if not headings:
            return []

        sections: list[str] = []
        for i, match in enumerate(headings):
            start = match.start()
            end = headings[i + 1].start() if i + 1 < len(headings) else len(text)
            section = text[start:end].strip()
            if section:
                sections.append(section)
        return sections


# ---------------------------------------------------------------------------
# JSON
# ---------------------------------------------------------------------------


class JSONHandler:
    """Handler for JSON files -- pretty-prints for readability."""

    def can_handle(self, format: ContentFormat) -> bool:
        return format == ContentFormat.JSON

    def parse(self, data: bytes) -> ParsedContent:
        text = decode_text_bytes(data)
        try:
            parsed = json.loads(text)
            pretty = json.dumps(parsed, indent=2, ensure_ascii=False)
        except json.JSONDecodeError:
            pretty = text
        return ParsedContent(
            raw_text=pretty,
            metadata=Metadata(format=ContentFormat.JSON, size_bytes=len(data)),
        )


# ---------------------------------------------------------------------------
# CSV
# ---------------------------------------------------------------------------


class CSVHandler:
    """Handler for CSV files -- delegates to shared extraction."""

    def can_handle(self, format: ContentFormat) -> bool:
        return format == ContentFormat.CSV

    def parse(self, data: bytes) -> ParsedContent:
        result = extract_csv_text(data)
        return ParsedContent(
            raw_text=result.text,
            metadata=Metadata(
                format=ContentFormat.CSV,
                size_bytes=len(data),
                extra=result.metadata,
            ),
        )


# ---------------------------------------------------------------------------
# HTML
# ---------------------------------------------------------------------------


class _HTMLTextExtractor(HTMLParser):
    """Minimal HTML-to-text extractor with section detection on headings."""

    def __init__(self) -> None:
        super().__init__()
        self.parts: list[str] = []
        self.sections: list[str] = []
        self._current_section_parts: list[str] = []
        self._in_heading = False
        self._skip_tags: set[str] = {"script", "style", "head"}
        self._skip_depth = 0

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        if tag in self._skip_tags:
            self._skip_depth += 1
            return
        if tag in {"h1", "h2", "h3", "h4", "h5", "h6"}:
            # Flush previous section if any
            if self._current_section_parts:
                self.sections.append(" ".join(self._current_section_parts).strip())
                self._current_section_parts = []
            self._in_heading = True

    def handle_endtag(self, tag: str) -> None:
        if tag in self._skip_tags and self._skip_depth > 0:
            self._skip_depth -= 1
            return
        if tag in {"h1", "h2", "h3", "h4", "h5", "h6"}:
            self._in_heading = False

    def handle_data(self, data: str) -> None:
        if self._skip_depth > 0:
            return
        text = data.strip()
        if text:
            self.parts.append(text)
            self._current_section_parts.append(text)

    def finalize(self) -> None:
        """Flush any remaining section."""
        if self._current_section_parts:
            self.sections.append(" ".join(self._current_section_parts).strip())


class HTMLHandler:
    """Handler for HTML files -- strips tags, extracts text and sections."""

    def can_handle(self, format: ContentFormat) -> bool:
        return format == ContentFormat.HTML

    def parse(self, data: bytes) -> ParsedContent:
        text = decode_text_bytes(data)
        extractor = _HTMLTextExtractor()
        extractor.feed(text)
        extractor.finalize()

        raw_text = "\n".join(extractor.parts)
        # Only report sections if we found headings (more than 1 section)
        sections = extractor.sections if len(extractor.sections) > 1 else []

        return ParsedContent(
            raw_text=raw_text,
            metadata=Metadata(format=ContentFormat.HTML, size_bytes=len(data)),
            sections=sections,
        )


# ---------------------------------------------------------------------------
# Registration
# ---------------------------------------------------------------------------


def register_builtin_handlers(substrate: IngestionSubstrate) -> None:
    """Register all built-in format handlers on the given substrate."""
    substrate.register_handler(ContentFormat.PLAINTEXT, PlaintextHandler())
    substrate.register_handler(ContentFormat.MARKDOWN, MarkdownHandler())
    substrate.register_handler(ContentFormat.JSON, JSONHandler())
    substrate.register_handler(ContentFormat.CSV, CSVHandler())
    substrate.register_handler(ContentFormat.HTML, HTMLHandler())
