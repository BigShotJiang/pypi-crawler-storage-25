"""Ingestion substrate -- format detection, parsing, normalization, chunking.

This module defines the core contract and data types for file ingestion.
Format-specific parsing is delegated to FormatHandler implementations
registered via register_handler().
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, Protocol


class ContentFormat(str, Enum):
    """Recognized content formats for ingestion."""

    PLAINTEXT = "plaintext"
    MARKDOWN = "markdown"
    HTML = "html"
    JSON = "json"
    CSV = "csv"
    PDF = "pdf"
    DOCX = "docx"
    XLSX = "xlsx"
    IMAGE = "image"  # OCR/vision
    UNKNOWN = "unknown"


class ChunkStrategy(str, Enum):
    """Strategy for splitting content into chunks."""

    FIXED_SIZE = "fixed_size"
    SEMANTIC = "semantic"  # By sections/paragraphs
    SENTENCE = "sentence"
    NONE = "none"  # Don't chunk


@dataclass
class Metadata:
    """File/content metadata extracted during ingestion."""

    format: ContentFormat
    size_bytes: int = 0
    page_count: Optional[int] = None
    title: Optional[str] = None
    author: Optional[str] = None
    created_at: Optional[str] = None
    language: Optional[str] = None
    extra: dict = field(default_factory=dict)  # type: ignore[type-arg]


@dataclass
class ParsedContent:
    """Result of parsing raw bytes into structured text."""

    raw_text: str
    metadata: Metadata
    sections: list[str] = field(default_factory=list)


@dataclass
class NormalizedContent:
    """Cleaned and normalized text ready for chunking or downstream use."""

    text: str
    metadata: Metadata
    sections: list[str] = field(default_factory=list)


@dataclass
class Chunk:
    """A single chunk of content with positional metadata."""

    content: str
    index: int
    total_chunks: int
    metadata: dict = field(default_factory=dict)  # type: ignore[type-arg]


class FormatHandler(Protocol):
    """Protocol for format-specific parsers."""

    def can_handle(self, format: ContentFormat) -> bool: ...

    def parse(self, data: bytes) -> ParsedContent: ...


# Extension-to-format mapping, shared by detect_format.
_EXT_FORMAT_MAP: dict[str, ContentFormat] = {
    "txt": ContentFormat.PLAINTEXT,
    "md": ContentFormat.MARKDOWN,
    "html": ContentFormat.HTML,
    "htm": ContentFormat.HTML,
    "json": ContentFormat.JSON,
    "csv": ContentFormat.CSV,
    "pdf": ContentFormat.PDF,
    "docx": ContentFormat.DOCX,
    "xlsx": ContentFormat.XLSX,
    "png": ContentFormat.IMAGE,
    "jpg": ContentFormat.IMAGE,
    "jpeg": ContentFormat.IMAGE,
}


class IngestionSubstrate:
    """Reusable file parsing/normalization/chunking contract.

    Shared between WorkMemory ingestion and product file uploads.
    """

    def __init__(self) -> None:
        self._handlers: dict[ContentFormat, FormatHandler] = {}

    def register_handler(self, format: ContentFormat, handler: FormatHandler) -> None:
        """Register a format-specific parser."""
        self._handlers[format] = handler

    def detect_format(self, data: bytes, filename: str = "") -> ContentFormat:
        """Detect content format from filename extension."""
        ext = filename.rsplit(".", 1)[-1].lower() if "." in filename else ""
        return _EXT_FORMAT_MAP.get(ext, ContentFormat.UNKNOWN)

    def parse(self, data: bytes, format: ContentFormat) -> ParsedContent:
        """Parse raw bytes into structured content via registered handler."""
        handler = self._handlers.get(format)
        if handler:
            return handler.parse(data)
        # Default: treat as plaintext
        text = data.decode("utf-8", errors="replace")
        return ParsedContent(
            raw_text=text,
            metadata=Metadata(format=format, size_bytes=len(data)),
        )

    def normalize(self, content: ParsedContent) -> NormalizedContent:
        """Normalize parsed content: clean whitespace, standardize encoding."""
        text = content.raw_text.strip()
        # Strip leading and trailing whitespace per line
        lines = [line.strip() for line in text.splitlines()]
        text = "\n".join(lines)
        # Collapse runs of 3+ blank lines down to 2
        while "\n\n\n" in text:
            text = text.replace("\n\n\n", "\n\n")
        return NormalizedContent(
            text=text,
            metadata=content.metadata,
            sections=content.sections,
        )

    def chunk(
        self,
        content: NormalizedContent,
        strategy: ChunkStrategy = ChunkStrategy.SEMANTIC,
        max_chunk_size: int = 4000,
    ) -> list[Chunk]:
        """Chunk normalized content for downstream processing."""
        if strategy == ChunkStrategy.NONE:
            return [Chunk(content=content.text, index=0, total_chunks=1)]

        if strategy == ChunkStrategy.SEMANTIC and content.sections:
            return [
                Chunk(content=section, index=i, total_chunks=len(content.sections))
                for i, section in enumerate(content.sections)
            ]

        # Fixed-size fallback (used by FIXED_SIZE and SEMANTIC without sections)
        return self._chunk_fixed_size(content.text, max_chunk_size)

    def extract_metadata(self, data: bytes, filename: str = "") -> Metadata:
        """Extract metadata without full parsing."""
        fmt = self.detect_format(data, filename)
        return Metadata(format=fmt, size_bytes=len(data))

    def ingest(
        self,
        data: bytes,
        filename: str = "",
        chunk_strategy: ChunkStrategy = ChunkStrategy.SEMANTIC,
    ) -> tuple[NormalizedContent, list[Chunk]]:
        """Full ingestion pipeline: detect -> parse -> normalize -> chunk."""
        fmt = self.detect_format(data, filename)
        parsed = self.parse(data, fmt)
        normalized = self.normalize(parsed)
        chunks = self.chunk(normalized, chunk_strategy)
        return normalized, chunks

    @staticmethod
    def _chunk_fixed_size(text: str, max_chunk_size: int) -> list[Chunk]:
        """Split text into chunks of at most max_chunk_size chars.

        Tries to break at paragraph boundaries (\n\n) when possible.
        """
        chunks: list[Chunk] = []
        start = 0
        idx = 0
        while start < len(text):
            end = min(start + max_chunk_size, len(text))
            # Try to break at a paragraph boundary
            if end < len(text):
                last_para = text.rfind("\n\n", start, end)
                if last_para > start:
                    end = last_para + 2
            chunk_text = text[start:end].strip()
            if chunk_text:
                chunks.append(Chunk(content=chunk_text, index=idx, total_chunks=0))
                idx += 1
            start = end

        # Backfill total_chunks
        for c in chunks:
            c.total_chunks = len(chunks)
        return chunks
