"""ExecutionEnvelope — sandbox/network/fs/import policy for RLM REPL (#1553).

Defines the security boundary around RLM code execution so tenant
isolation is enforced regardless of which RLM library is used.
"""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class SandboxLevel(str, Enum):
    NONE = "none"
    RESTRICTED = "restricted"
    STRICT = "strict"
    FULL_ISOLATION = "full_isolation"


class NetworkPolicy(str, Enum):
    ALLOW_ALL = "allow_all"
    ALLOWLIST_ONLY = "allowlist_only"
    DENY_ALL = "deny_all"


class FileSystemPolicy(str, Enum):
    FULL_ACCESS = "full_access"
    READ_ONLY = "read_only"
    SANDBOX_DIR_ONLY = "sandbox_dir_only"
    NO_ACCESS = "no_access"


class ImportPolicy(str, Enum):
    ALLOW_ALL = "allow_all"
    ALLOWLIST_ONLY = "allowlist_only"
    STANDARD_LIB_ONLY = "standard_lib_only"
    NONE = "none"


class EnvelopeConfig(BaseModel):
    model_config = ConfigDict(frozen=True)
    tenant_id: str
    sandbox_level: SandboxLevel = SandboxLevel.RESTRICTED
    network: NetworkPolicy = NetworkPolicy.DENY_ALL
    filesystem: FileSystemPolicy = FileSystemPolicy.SANDBOX_DIR_ONLY
    imports: ImportPolicy = ImportPolicy.STANDARD_LIB_ONLY
    max_cpu_seconds: int = 30
    max_memory_mb: int = 512
    network_allowlist: frozenset[str] = frozenset()
    import_allowlist: frozenset[str] = frozenset()


class ExecutionAudit(BaseModel):
    model_config = ConfigDict(frozen=True)
    execution_id: str
    tenant_id: str
    envelope: EnvelopeConfig
    violations: list[str]
    cpu_used_seconds: float
    memory_peak_mb: float
    network_calls: int
    completed_at: datetime


@runtime_checkable
class EnvelopeStore(Protocol):
    def save_envelope(self, config: EnvelopeConfig) -> None: ...
    def get_envelope(self, tenant_id: str) -> EnvelopeConfig | None: ...
    def save_audit(self, audit: ExecutionAudit) -> None: ...
    def get_audits(self, tenant_id: str, limit: int = 50) -> list[ExecutionAudit]: ...


class InMemoryEnvelopeStore:
    def __init__(self) -> None:
        self._envelopes: dict[str, EnvelopeConfig] = {}
        self._audits: list[ExecutionAudit] = []

    def save_envelope(self, config: EnvelopeConfig) -> None:
        self._envelopes[config.tenant_id] = config

    def get_envelope(self, tenant_id: str) -> EnvelopeConfig | None:
        return self._envelopes.get(tenant_id)

    def save_audit(self, audit: ExecutionAudit) -> None:
        self._audits.append(audit)

    def get_audits(self, tenant_id: str, limit: int = 50) -> list[ExecutionAudit]:
        return [a for a in self._audits if a.tenant_id == tenant_id][-limit:]


class ExecutionEnvelope:
    """Manages sandbox policies and audits RLM code execution."""

    def __init__(self, store: EnvelopeStore) -> None:
        self._store = store

    def configure(self, config: EnvelopeConfig) -> None:
        self._store.save_envelope(config)

    def get_config(self, tenant_id: str) -> EnvelopeConfig:
        existing = self._store.get_envelope(tenant_id)
        if existing:
            return existing
        return EnvelopeConfig(tenant_id=tenant_id)

    def validate_network_access(self, tenant_id: str, host: str) -> bool:
        config = self.get_config(tenant_id)
        if config.network == NetworkPolicy.ALLOW_ALL:
            return True
        if config.network == NetworkPolicy.DENY_ALL:
            return False
        return host in config.network_allowlist

    def validate_import(self, tenant_id: str, module: str) -> bool:
        config = self.get_config(tenant_id)
        if config.imports == ImportPolicy.ALLOW_ALL:
            return True
        if config.imports == ImportPolicy.NONE:
            return False
        if config.imports == ImportPolicy.STANDARD_LIB_ONLY:
            import sys
            return module in sys.stdlib_module_names
        return module in config.import_allowlist

    def validate_resource(self, tenant_id: str, cpu_seconds: float, memory_mb: float) -> list[str]:
        config = self.get_config(tenant_id)
        violations: list[str] = []
        if cpu_seconds > config.max_cpu_seconds:
            violations.append(f"CPU {cpu_seconds:.1f}s exceeds limit {config.max_cpu_seconds}s")
        if memory_mb > config.max_memory_mb:
            violations.append(f"Memory {memory_mb:.1f}MB exceeds limit {config.max_memory_mb}MB")
        return violations

    def record_audit(
        self,
        execution_id: str,
        tenant_id: str,
        cpu_seconds: float,
        memory_mb: float,
        network_calls: int,
        violations: list[str] | None = None,
    ) -> ExecutionAudit:
        audit = ExecutionAudit(
            execution_id=execution_id,
            tenant_id=tenant_id,
            envelope=self.get_config(tenant_id),
            violations=violations or [],
            cpu_used_seconds=cpu_seconds,
            memory_peak_mb=memory_mb,
            network_calls=network_calls,
            completed_at=datetime.now(UTC),
        )
        self._store.save_audit(audit)
        return audit
