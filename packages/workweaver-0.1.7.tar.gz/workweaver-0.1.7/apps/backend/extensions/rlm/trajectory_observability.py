"""RLM Trajectory Observability — capture and surface reasoning traces (#1548).

Records every step of an RLM trajectory so the reasoning chain is
first-class inspectable data, not ephemeral library state.
"""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class TrajectoryStatus(str, Enum):
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class TrajectoryEvent(BaseModel):
    model_config = ConfigDict(frozen=True)
    event_id: str
    trajectory_id: str
    tenant_id: str
    step_index: int
    event_type: str
    payload: str
    timestamp: datetime


class TrajectoryRecord(BaseModel):
    model_config = ConfigDict(frozen=True)
    trajectory_id: str
    tenant_id: str
    request_id: str
    status: TrajectoryStatus
    step_count: int
    total_tokens: int
    started_at: datetime
    completed_at: datetime | None


@runtime_checkable
class TrajectoryStore(Protocol):
    def save_event(self, event: TrajectoryEvent) -> None: ...
    def get_events(self, trajectory_id: str) -> list[TrajectoryEvent]: ...
    def save_record(self, record: TrajectoryRecord) -> None: ...
    def get_record(self, trajectory_id: str) -> TrajectoryRecord | None: ...
    def list_records(self, tenant_id: str, limit: int = 50) -> list[TrajectoryRecord]: ...


class InMemoryTrajectoryStore:
    def __init__(self) -> None:
        self._events: list[TrajectoryEvent] = []
        self._records: dict[str, TrajectoryRecord] = {}

    def save_event(self, event: TrajectoryEvent) -> None:
        self._events.append(event)

    def get_events(self, trajectory_id: str) -> list[TrajectoryEvent]:
        return [e for e in self._events if e.trajectory_id == trajectory_id]

    def save_record(self, record: TrajectoryRecord) -> None:
        self._records[record.trajectory_id] = record

    def get_record(self, trajectory_id: str) -> TrajectoryRecord | None:
        return self._records.get(trajectory_id)

    def list_records(self, tenant_id: str, limit: int = 50) -> list[TrajectoryRecord]:
        return [r for r in self._records.values() if r.tenant_id == tenant_id][:limit]


class TrajectoryObservability:
    """Captures and surfaces RLM reasoning trajectories."""

    def __init__(self, store: TrajectoryStore) -> None:
        self._store = store

    def start_trajectory(self, trajectory_id: str, tenant_id: str, request_id: str) -> TrajectoryRecord:
        record = TrajectoryRecord(
            trajectory_id=trajectory_id,
            tenant_id=tenant_id,
            request_id=request_id,
            status=TrajectoryStatus.RUNNING,
            step_count=0,
            total_tokens=0,
            started_at=datetime.now(UTC),
            completed_at=None,
        )
        self._store.save_record(record)
        return record

    def record_step(self, trajectory_id: str, tenant_id: str, step_index: int, event_type: str, payload: str) -> TrajectoryEvent:
        event = TrajectoryEvent(
            event_id=f"{trajectory_id}-{step_index}",
            trajectory_id=trajectory_id,
            tenant_id=tenant_id,
            step_index=step_index,
            event_type=event_type,
            payload=payload,
            timestamp=datetime.now(UTC),
        )
        self._store.save_event(event)
        record = self._store.get_record(trajectory_id)
        if record:
            updated = TrajectoryRecord(
                trajectory_id=record.trajectory_id,
                tenant_id=record.tenant_id,
                request_id=record.request_id,
                status=record.status,
                step_count=step_index + 1,
                total_tokens=record.total_tokens,
                started_at=record.started_at,
                completed_at=record.completed_at,
            )
            self._store.save_record(updated)
        return event

    def complete_trajectory(self, trajectory_id: str, total_tokens: int = 0) -> TrajectoryRecord | None:
        record = self._store.get_record(trajectory_id)
        if not record:
            return None
        completed = TrajectoryRecord(
            trajectory_id=record.trajectory_id,
            tenant_id=record.tenant_id,
            request_id=record.request_id,
            status=TrajectoryStatus.COMPLETED,
            step_count=record.step_count,
            total_tokens=total_tokens,
            started_at=record.started_at,
            completed_at=datetime.now(UTC),
        )
        self._store.save_record(completed)
        return completed

    def fail_trajectory(self, trajectory_id: str) -> TrajectoryRecord | None:
        record = self._store.get_record(trajectory_id)
        if not record:
            return None
        failed = TrajectoryRecord(
            trajectory_id=record.trajectory_id,
            tenant_id=record.tenant_id,
            request_id=record.request_id,
            status=TrajectoryStatus.FAILED,
            step_count=record.step_count,
            total_tokens=record.total_tokens,
            started_at=record.started_at,
            completed_at=datetime.now(UTC),
        )
        self._store.save_record(failed)
        return failed

    def get_trajectory(self, trajectory_id: str) -> tuple[TrajectoryRecord | None, list[TrajectoryEvent]]:
        record = self._store.get_record(trajectory_id)
        events = self._store.get_events(trajectory_id)
        return record, events

    def list_trajectories(self, tenant_id: str, limit: int = 50) -> list[TrajectoryRecord]:
        return self._store.list_records(tenant_id, limit)
