"""ReplayCheckpoint — resume + forensics for failed RLM trajectories (#1554).

Provides deterministic checkpointing so partial RLM trajectories can be
resumed without re-running the prefix, and failures can be replayed.
"""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class CheckpointStatus(str, Enum):
    ACTIVE = "active"
    RESTORED = "restored"
    EXPIRED = "expired"


class CheckpointStep(BaseModel):
    model_config = ConfigDict(frozen=True)
    step_index: int
    action: str
    input_state: dict[str, Any]
    output_state: dict[str, Any]
    timestamp: datetime


class TrajectoryCheckpoint(BaseModel):
    model_config = ConfigDict(frozen=True)
    checkpoint_id: str
    trajectory_id: str
    tenant_id: str
    steps: list[CheckpointStep]
    status: CheckpointStatus
    created_at: datetime
    total_tokens: int


class ReplayResult(BaseModel):
    model_config = ConfigDict(frozen=True)
    trajectory_id: str
    restored_from_step: int
    steps_replayed: int
    matched_original: bool
    diverged_at_step: int | None
    completed_at: datetime


@runtime_checkable
class CheckpointStore(Protocol):
    def save_checkpoint(self, checkpoint: TrajectoryCheckpoint) -> None: ...
    def get_checkpoint(self, checkpoint_id: str) -> TrajectoryCheckpoint | None: ...
    def get_latest_checkpoint(self, trajectory_id: str) -> TrajectoryCheckpoint | None: ...
    def list_checkpoints(self, trajectory_id: str) -> list[TrajectoryCheckpoint]: ...


class InMemoryCheckpointStore:
    def __init__(self) -> None:
        self._checkpoints: dict[str, TrajectoryCheckpoint] = {}

    def save_checkpoint(self, checkpoint: TrajectoryCheckpoint) -> None:
        self._checkpoints[checkpoint.checkpoint_id] = checkpoint

    def get_checkpoint(self, checkpoint_id: str) -> TrajectoryCheckpoint | None:
        return self._checkpoints.get(checkpoint_id)

    def get_latest_checkpoint(self, trajectory_id: str) -> TrajectoryCheckpoint | None:
        matches = [c for c in self._checkpoints.values() if c.trajectory_id == trajectory_id]
        if not matches:
            return None
        return max(matches, key=lambda c: len(c.steps))

    def list_checkpoints(self, trajectory_id: str) -> list[TrajectoryCheckpoint]:
        return [c for c in self._checkpoints.values() if c.trajectory_id == trajectory_id]


class ReplayCheckpoint:
    """Checkpoint and replay RLM trajectories for resume and forensics."""

    def __init__(self, store: CheckpointStore) -> None:
        self._store = store

    def create_checkpoint(
        self,
        checkpoint_id: str,
        trajectory_id: str,
        tenant_id: str,
        steps: list[CheckpointStep],
        total_tokens: int = 0,
    ) -> TrajectoryCheckpoint:
        checkpoint = TrajectoryCheckpoint(
            checkpoint_id=checkpoint_id,
            trajectory_id=trajectory_id,
            tenant_id=tenant_id,
            steps=steps,
            status=CheckpointStatus.ACTIVE,
            created_at=datetime.now(UTC),
            total_tokens=total_tokens,
        )
        self._store.save_checkpoint(checkpoint)
        return checkpoint

    def add_step(self, checkpoint_id: str, step: CheckpointStep) -> TrajectoryCheckpoint | None:
        checkpoint = self._store.get_checkpoint(checkpoint_id)
        if not checkpoint:
            return None
        updated = TrajectoryCheckpoint(
            checkpoint_id=checkpoint.checkpoint_id,
            trajectory_id=checkpoint.trajectory_id,
            tenant_id=checkpoint.tenant_id,
            steps=[*checkpoint.steps, step],
            status=checkpoint.status,
            created_at=checkpoint.created_at,
            total_tokens=checkpoint.total_tokens,
        )
        self._store.save_checkpoint(updated)
        return updated

    def restore(self, trajectory_id: str) -> TrajectoryCheckpoint | None:
        checkpoint = self._store.get_latest_checkpoint(trajectory_id)
        if not checkpoint:
            return None
        restored = TrajectoryCheckpoint(
            checkpoint_id=checkpoint.checkpoint_id,
            trajectory_id=checkpoint.trajectory_id,
            tenant_id=checkpoint.tenant_id,
            steps=checkpoint.steps,
            status=CheckpointStatus.RESTORED,
            created_at=checkpoint.created_at,
            total_tokens=checkpoint.total_tokens,
        )
        self._store.save_checkpoint(restored)
        return restored

    def replay(self, trajectory_id: str, original_steps: list[CheckpointStep]) -> ReplayResult:
        checkpoint = self._store.get_latest_checkpoint(trajectory_id)
        if not checkpoint:
            return ReplayResult(
                trajectory_id=trajectory_id,
                restored_from_step=0,
                steps_replayed=0,
                matched_original=False,
                diverged_at_step=0,
                completed_at=datetime.now(UTC),
            )
        matched = True
        diverged_at = None
        for i, (orig, saved) in enumerate(zip(original_steps, checkpoint.steps)):
            if orig.action != saved.action or orig.input_state != saved.input_state:
                matched = False
                diverged_at = i
                break
        return ReplayResult(
            trajectory_id=trajectory_id,
            restored_from_step=len(checkpoint.steps),
            steps_replayed=len(original_steps) - len(checkpoint.steps) if len(original_steps) > len(checkpoint.steps) else 0,
            matched_original=matched,
            diverged_at_step=diverged_at,
            completed_at=datetime.now(UTC),
        )

    def get_latest(self, trajectory_id: str) -> TrajectoryCheckpoint | None:
        return self._store.get_latest_checkpoint(trajectory_id)
