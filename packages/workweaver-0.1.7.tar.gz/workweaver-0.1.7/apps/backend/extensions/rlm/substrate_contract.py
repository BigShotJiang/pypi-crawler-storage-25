"""SubstrateContract — protocol-level seam over RLM backends (#1552).

Defines the contract that every RLM provider must satisfy so the rest
of Workweaver is insulated from substrate swaps (DSPy → alexzhang →
provider-native).
"""

from __future__ import annotations

from enum import Enum
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class SubstrateBackend(str, Enum):
    DSPY_RLM = "dspy_rlm"
    ALEXZHANG = "alexzhang"
    OPENAI_NATIVE = "openai_native"
    ANTHROPIC_NATIVE = "anthropic_native"
    STUB = "stub"


class SubstrateCapability(str, Enum):
    MULTI_STEP = "multi_step"
    CODE_EXECUTION = "code_execution"
    DEEP_REASONING = "deep_reasoning"
    TOOL_USE = "tool_use"
    STREAMING = "streaming"


class SubstrateConfig(BaseModel):
    model_config = ConfigDict(frozen=True)
    backend: SubstrateBackend
    capabilities: frozenset[SubstrateCapability]
    max_context_tokens: int = 1_000_000
    timeout_seconds: int = 300
    metadata: dict[str, Any] | None = None


class SubstrateResponse(BaseModel):
    model_config = ConfigDict(frozen=True)
    backend: SubstrateBackend
    content: str
    trajectory_steps: int
    tokens_used: int
    elapsed_ms: int
    raw_output: dict[str, Any] | None = None


@runtime_checkable
class SubstrateProviderProtocol(Protocol):
    """Every RLM backend must implement this."""

    def config(self) -> SubstrateConfig: ...
    def invoke(self, prompt: str, *, max_tokens: int = 4096, context: dict[str, Any] | None = None) -> SubstrateResponse: ...
    def health_check(self) -> bool: ...


class StubSubstrateProvider:
    """Default no-op provider for testing and bootstrapping."""

    def __init__(self, capabilities: frozenset[SubstrateCapability] | None = None) -> None:
        self._caps = capabilities or frozenset()

    def config(self) -> SubstrateConfig:
        return SubstrateConfig(backend=SubstrateBackend.STUB, capabilities=self._caps)

    def invoke(self, prompt: str, *, max_tokens: int = 4096, context: dict[str, Any] | None = None) -> SubstrateResponse:
        return SubstrateResponse(
            backend=SubstrateBackend.STUB,
            content="",
            trajectory_steps=0,
            tokens_used=0,
            elapsed_ms=0,
        )

    def health_check(self) -> bool:
        return True


class SubstrateContract:
    """Registry and router for RLM substrate providers."""

    def __init__(self) -> None:
        self._providers: dict[SubstrateBackend, SubstrateProviderProtocol] = {}

    def register(self, provider: SubstrateProviderProtocol) -> None:
        cfg = provider.config()
        self._providers[cfg.backend] = provider

    def get(self, backend: SubstrateBackend) -> SubstrateProviderProtocol | None:
        return self._providers.get(backend)

    def invoke(self, prompt: str, *, backend: SubstrateBackend | None = None, max_tokens: int = 4096, context: dict[str, Any] | None = None) -> SubstrateResponse:
        if backend:
            provider = self._providers.get(backend)
            if not provider:
                raise ValueError(f"No provider registered for {backend.value}")
            return provider.invoke(prompt, max_tokens=max_tokens, context=context)
        if not self._providers:
            raise ValueError("No substrate providers registered")
        provider = next(iter(self._providers.values()))
        return provider.invoke(prompt, max_tokens=max_tokens, context=context)

    def list_backends(self) -> list[SubstrateBackend]:
        return list(self._providers.keys())

    def health_check_all(self) -> dict[SubstrateBackend, bool]:
        return {b: p.health_check() for b, p in self._providers.items()}
