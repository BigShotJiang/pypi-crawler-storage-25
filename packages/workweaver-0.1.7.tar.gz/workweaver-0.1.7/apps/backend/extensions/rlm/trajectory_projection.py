"""TrajectoryProjection — semantic compression over dense traces (#1555).

Projects raw RLM trajectories into belief/desire/intention (BDI) style
semantic states so humans can understand *why* the system acted, not just
*what* it did.
"""

from __future__ import annotations

import math
from datetime import UTC, datetime
from enum import Enum
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class SemanticType(str, Enum):
    BELIEF = "belief"
    DESIRE = "desire"
    INTENTION = "intention"
    COMMITMENT = "commitment"
    OBSERVATION = "observation"


class ProjectionStrategy(str, Enum):
    FIRST_N = "first_n"
    LAST_N = "last_n"
    KEY_FRAMES = "key_frames"
    SEMANTIC_CLUSTER = "semantic_cluster"


class SemanticNode(BaseModel):
    model_config = ConfigDict(frozen=True)
    node_id: str
    semantic_type: SemanticType
    content: str
    confidence: float
    source_step_indices: list[int]
    timestamp: datetime


class ProjectedTrace(BaseModel):
    model_config = ConfigDict(frozen=True)
    trace_id: str
    tenant_id: str
    original_step_count: int
    projected_nodes: list[SemanticNode]
    compression_ratio: float
    created_at: datetime


@runtime_checkable
class ProjectionStore(Protocol):
    def save_projection(self, trace: ProjectedTrace) -> None: ...
    def get_projection(self, trace_id: str) -> ProjectedTrace | None: ...
    def list_projections(self, tenant_id: str, limit: int = 50) -> list[ProjectedTrace]: ...


class InMemoryProjectionStore:
    def __init__(self) -> None:
        self._projections: dict[str, ProjectedTrace] = {}

    def save_projection(self, trace: ProjectedTrace) -> None:
        self._projections[trace.trace_id] = trace

    def get_projection(self, trace_id: str) -> ProjectedTrace | None:
        return self._projections.get(trace_id)

    def list_projections(self, tenant_id: str, limit: int = 50) -> list[ProjectedTrace]:
        return [p for p in self._projections.values() if p.tenant_id == tenant_id][:limit]


def _shannon_entropy(labels: list[str]) -> float:
    if not labels:
        return 0.0
    counts: dict[str, int] = {}
    for label in labels:
        counts[label] = counts.get(label, 0) + 1
    total = len(labels)
    return -sum((c / total) * math.log2(c / total) for c in counts.values() if c > 0)


def _classify_step(step_type: str) -> SemanticType:
    mapping = {
        "reasoning": SemanticType.BELIEF,
        "goal": SemanticType.DESIRE,
        "plan": SemanticType.INTENTION,
        "commit": SemanticType.COMMITMENT,
        "observe": SemanticType.OBSERVATION,
    }
    return mapping.get(step_type, SemanticType.OBSERVATION)


class TrajectoryProjection:
    """Compress raw trajectories into semantic BDI-style projections."""

    def __init__(self, store: ProjectionStore) -> None:
        self._store = store

    def project(
        self,
        trace_id: str,
        tenant_id: str,
        steps: list[dict],
        strategy: ProjectionStrategy = ProjectionStrategy.KEY_FRAMES,
        max_nodes: int = 20,
    ) -> ProjectedTrace:
        selected = self._select_steps(steps, strategy, max_nodes)
        nodes = [
            SemanticNode(
                node_id=f"{trace_id}-{i}",
                semantic_type=_classify_step(s.get("type", "observe")),
                content=s.get("content", ""),
                confidence=s.get("confidence", 1.0),
                source_step_indices=[s.get("index", i)],
                timestamp=s.get("timestamp", datetime.now(UTC)) if isinstance(s.get("timestamp"), datetime) else datetime.now(UTC),
            )
            for i, s in enumerate(selected)
        ]
        original_count = len(steps)
        compression = len(nodes) / original_count if original_count > 0 else 0.0
        trace = ProjectedTrace(
            trace_id=trace_id,
            tenant_id=tenant_id,
            original_step_count=original_count,
            projected_nodes=nodes,
            compression_ratio=compression,
            created_at=datetime.now(UTC),
        )
        self._store.save_projection(trace)
        return trace

    def _select_steps(self, steps: list[dict], strategy: ProjectionStrategy, max_nodes: int) -> list[dict]:
        if not steps:
            return []
        if strategy == ProjectionStrategy.FIRST_N:
            return steps[:max_nodes]
        if strategy == ProjectionStrategy.LAST_N:
            return steps[-max_nodes:]
        if strategy == ProjectionStrategy.KEY_FRAMES:
            return self._key_frames(steps, max_nodes)
        return self._semantic_cluster(steps, max_nodes)

    def _key_frames(self, steps: list[dict], max_nodes: int) -> list[dict]:
        if len(steps) <= max_nodes:
            return steps
        selected = [steps[0], steps[-1]]
        if max_nodes > 2:
            step = max(1, len(steps) // (max_nodes - 1))
            for i in range(step, len(steps) - 1, step):
                if len(selected) < max_nodes:
                    selected.append(steps[i])
        return selected[:max_nodes]

    def _semantic_cluster(self, steps: list[dict], max_nodes: int) -> list[dict]:
        if len(steps) <= max_nodes:
            return steps
        type_groups: dict[str, list[dict]] = {}
        for s in steps:
            t = s.get("type", "observe")
            type_groups.setdefault(t, []).append(s)
        budget = max(1, max_nodes // max(len(type_groups), 1))
        result: list[dict] = []
        for group in type_groups.values():
            result.extend(group[:budget])
        return result[:max_nodes]

    def get_projection(self, trace_id: str) -> ProjectedTrace | None:
        return self._store.get_projection(trace_id)

    def list_projections(self, tenant_id: str, limit: int = 50) -> list[ProjectedTrace]:
        return self._store.list_projections(tenant_id, limit)

    def compute_diversity(self, trace_id: str) -> float:
        trace = self._store.get_projection(trace_id)
        if not trace or not trace.projected_nodes:
            return 0.0
        labels = [n.semantic_type.value for n in trace.projected_nodes]
        max_entropy = math.log2(len(SemanticType)) if len(SemanticType) > 1 else 1.0
        return _shannon_entropy(labels) / max_entropy if max_entropy > 0 else 0.0
