"""RLM Cognition Substrate — unified reasoning interface (#1549).

Provides a single seam over RLM providers (DSPy, alexzhang13/rlm,
provider-native) so the rest of Workweaver never depends on a specific
reasoning library.
"""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
from typing import Any, Protocol, runtime_checkable
from uuid import uuid4

from pydantic import BaseModel, ConfigDict


class SubstrateProvider(str, Enum):
    DSPY = "dspy"
    ALEXZHANG = "alexzhang"
    PROVIDER_NATIVE = "provider_native"


class ReasoningMode(str, Enum):
    STANDARD = "standard"
    DEEP = "deep"
    CODE = "code"
    MULTI_STEP = "multi_step"


class CognitionRequest(BaseModel):
    model_config = ConfigDict(frozen=True)
    request_id: str
    tenant_id: str
    prompt: str
    mode: ReasoningMode = ReasoningMode.STANDARD
    max_tokens: int = 4096
    provider: SubstrateProvider = SubstrateProvider.DSPY
    context: dict[str, Any] | None = None


class TrajectoryStep(BaseModel):
    model_config = ConfigDict(frozen=True)
    step_index: int
    action: str
    input_snapshot: str
    output_snapshot: str
    reasoning: str
    timestamp: datetime


class CognitionResult(BaseModel):
    model_config = ConfigDict(frozen=True)
    request_id: str
    tenant_id: str
    response: str
    provider: SubstrateProvider
    trajectory: list[TrajectoryStep]
    total_tokens: int
    elapsed_ms: int
    completed_at: datetime


@runtime_checkable
class CognitionStore(Protocol):
    def save_result(self, result: CognitionResult) -> None: ...
    def get_result(self, request_id: str) -> CognitionResult | None: ...
    def list_results(self, tenant_id: str, limit: int = 50) -> list[CognitionResult]: ...


class InMemoryCognitionStore:
    def __init__(self) -> None:
        self._results: dict[str, CognitionResult] = {}

    def save_result(self, result: CognitionResult) -> None:
        self._results[result.request_id] = result

    def get_result(self, request_id: str) -> CognitionResult | None:
        return self._results.get(request_id)

    def list_results(self, tenant_id: str, limit: int = 50) -> list[CognitionResult]:
        return [r for r in self._results.values() if r.tenant_id == tenant_id][:limit]


class RLMCognitionSubstrate:
    """Facade over RLM providers. Real providers are injected; default is stub."""

    def __init__(self, store: CognitionStore) -> None:
        self._store = store

    def submit(self, request: CognitionRequest) -> CognitionResult:
        result = CognitionResult(
            request_id=request.request_id,
            tenant_id=request.tenant_id,
            response="",
            provider=request.provider,
            trajectory=[],
            total_tokens=0,
            elapsed_ms=0,
            completed_at=datetime.now(UTC),
        )
        self._store.save_result(result)
        return result

    def create_request(
        self,
        tenant_id: str,
        prompt: str,
        *,
        mode: ReasoningMode = ReasoningMode.STANDARD,
        provider: SubstrateProvider = SubstrateProvider.DSPY,
        max_tokens: int = 4096,
        context: dict[str, Any] | None = None,
    ) -> CognitionRequest:
        return CognitionRequest(
            request_id=uuid4().hex[:16],
            tenant_id=tenant_id,
            prompt=prompt,
            mode=mode,
            provider=provider,
            max_tokens=max_tokens,
            context=context,
        )

    def get_result(self, request_id: str) -> CognitionResult | None:
        return self._store.get_result(request_id)

    def list_results(self, tenant_id: str, limit: int = 50) -> list[CognitionResult]:
        return self._store.list_results(tenant_id, limit)
