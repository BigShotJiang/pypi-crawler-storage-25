"""WorkingSetGovernor — external cost/fairness/security controls (#1551).

Governs the external working set (which data, tools, and APIs the RLM
can access) with cost limits, fairness across tenants, and security
constraints that go beyond internal attention management.
"""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class ResourceKind(str, Enum):
    INFERENCE_TOKENS = "inference_tokens"
    TOOL_CALLS = "tool_calls"
    API_REQUESTS = "api_requests"
    CONTEXT_WINDOW = "context_window"


class GovernanceAction(str, Enum):
    ALLOW = "allow"
    THROTTLE = "throttle"
    DENY = "deny"
    QUEUE = "queue"


class ResourceBudget(BaseModel):
    model_config = ConfigDict(frozen=True)
    tenant_id: str
    resource: ResourceKind
    limit: int
    used: int = 0
    window_seconds: int = 3600


class GovernancePolicy(BaseModel):
    model_config = ConfigDict(frozen=True)
    tenant_id: str
    max_inference_tokens_per_hour: int = 100_000
    max_tool_calls_per_hour: int = 500
    max_api_requests_per_hour: int = 1000
    max_context_tokens: int = 2_000_000
    fairness_weight: float = 1.0
    security_level: str = "standard"


class GovernanceDecision(BaseModel):
    model_config = ConfigDict(frozen=True)
    action: GovernanceAction
    resource: ResourceKind
    current_usage: int
    limit: int
    reason: str
    timestamp: datetime


@runtime_checkable
class WorkingSetStore(Protocol):
    def save_budget(self, budget: ResourceBudget) -> None: ...
    def get_budget(self, tenant_id: str, resource: ResourceKind) -> ResourceBudget | None: ...
    def save_policy(self, policy: GovernancePolicy) -> None: ...
    def get_policy(self, tenant_id: str) -> GovernancePolicy | None: ...


class InMemoryWorkingSetStore:
    def __init__(self) -> None:
        self._budgets: dict[tuple[str, str], ResourceBudget] = {}
        self._policies: dict[str, GovernancePolicy] = {}

    def save_budget(self, budget: ResourceBudget) -> None:
        self._budgets[(budget.tenant_id, budget.resource.value)] = budget

    def get_budget(self, tenant_id: str, resource: ResourceKind) -> ResourceBudget | None:
        return self._budgets.get((tenant_id, resource.value))

    def save_policy(self, policy: GovernancePolicy) -> None:
        self._policies[policy.tenant_id] = policy

    def get_policy(self, tenant_id: str) -> GovernancePolicy | None:
        return self._policies.get(tenant_id)


class WorkingSetGovernor:
    """Enforces cost, fairness, and security constraints on RLM working sets."""

    def __init__(self, store: WorkingSetStore) -> None:
        self._store = store

    def set_policy(self, policy: GovernancePolicy) -> None:
        self._store.save_policy(policy)

    def get_policy(self, tenant_id: str) -> GovernancePolicy:
        return self._store.get_policy(tenant_id) or GovernancePolicy(tenant_id=tenant_id)

    def check(self, tenant_id: str, resource: ResourceKind, amount: int = 1) -> GovernanceDecision:
        policy = self.get_policy(tenant_id)
        budget = self._store.get_budget(tenant_id, resource)
        current = budget.used if budget else 0
        limit = self._get_limit(policy, resource)
        if current + amount > limit:
            if current < limit:
                return GovernanceDecision(
                    action=GovernanceAction.THROTTLE,
                    resource=resource,
                    current_usage=current,
                    limit=limit,
                    reason=f"Approaching {resource.value} limit ({current + amount}/{limit})",
                    timestamp=datetime.now(UTC),
                )
            return GovernanceDecision(
                action=GovernanceAction.DENY,
                resource=resource,
                current_usage=current,
                limit=limit,
                reason=f"{resource.value} limit exceeded ({current}/{limit})",
                timestamp=datetime.now(UTC),
            )
        return GovernanceDecision(
            action=GovernanceAction.ALLOW,
            resource=resource,
            current_usage=current,
            limit=limit,
            reason="Within budget",
            timestamp=datetime.now(UTC),
        )

    def record_usage(self, tenant_id: str, resource: ResourceKind, amount: int) -> ResourceBudget:
        budget = self._store.get_budget(tenant_id, resource)
        if budget:
            updated = ResourceBudget(
                tenant_id=budget.tenant_id,
                resource=budget.resource,
                limit=budget.limit,
                used=budget.used + amount,
                window_seconds=budget.window_seconds,
            )
            self._store.save_budget(updated)
            return updated
        limit = self._get_limit(self.get_policy(tenant_id), resource)
        new_budget = ResourceBudget(
            tenant_id=tenant_id,
            resource=resource,
            limit=limit,
            used=amount,
            window_seconds=3600,
        )
        self._store.save_budget(new_budget)
        return new_budget

    def reset_budget(self, tenant_id: str, resource: ResourceKind) -> None:
        budget = self._store.get_budget(tenant_id, resource)
        if budget:
            reset = ResourceBudget(
                tenant_id=budget.tenant_id,
                resource=budget.resource,
                limit=budget.limit,
                used=0,
                window_seconds=budget.window_seconds,
            )
            self._store.save_budget(reset)

    def _get_limit(self, policy: GovernancePolicy, resource: ResourceKind) -> int:
        limits = {
            ResourceKind.INFERENCE_TOKENS: policy.max_inference_tokens_per_hour,
            ResourceKind.TOOL_CALLS: policy.max_tool_calls_per_hour,
            ResourceKind.API_REQUESTS: policy.max_api_requests_per_hour,
            ResourceKind.CONTEXT_WINDOW: policy.max_context_tokens,
        }
        return limits.get(resource, 0)
