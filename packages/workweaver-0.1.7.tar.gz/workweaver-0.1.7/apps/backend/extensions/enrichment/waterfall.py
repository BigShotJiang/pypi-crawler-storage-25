"""Enrichment waterfall: cache -> CRM native -> Hunter -> Apollo -> PDL -> ZoomInfo.

Each provider is tried in order; first found result wins.
Unconfigured providers are skipped without error.
"""

from __future__ import annotations

import time

from apps.backend.extensions.enrichment.base import EnrichmentProvider, EnrichmentResult


class EnrichmentWaterfall:
    """Try providers in order until one finds data. Cache results."""

    def __init__(
        self,
        providers: list[EnrichmentProvider],
        cache_ttl_seconds: int = 86400,
    ) -> None:
        self._providers = providers
        self._cache_ttl = cache_ttl_seconds
        self._cache: dict[str, tuple[EnrichmentResult, float]] = {}

    def _cache_key(self, email: str | None, domain: str | None) -> str:
        return f"email:{email or ''}|domain:{domain or ''}"

    def _check_cache(self, key: str) -> EnrichmentResult | None:
        entry = self._cache.get(key)
        if entry is None:
            return None
        result, cached_at = entry
        age = time.time() - cached_at
        if age > self._cache_ttl:
            del self._cache[key]
            return None
        return EnrichmentResult(
            provider=result.provider,
            found=result.found,
            confidence=result.confidence,
            data=result.data,
            cached=True,
            cache_age_seconds=int(age),
        )

    def enrich(
        self,
        email: str | None = None,
        domain: str | None = None,
    ) -> EnrichmentResult | None:
        """Try cache, then each configured provider in order."""
        if not email and not domain:
            return None

        key = self._cache_key(email, domain)
        cached = self._check_cache(key)
        if cached is not None:
            return cached

        for provider in self._providers:
            if not provider.is_configured():
                continue
            try:
                if email:
                    result = provider.enrich_by_email(email)
                elif domain:
                    result = provider.enrich_by_domain(domain)
                else:
                    continue

                if result.found:
                    self._cache[key] = (result, time.time())
                    return result
            except Exception:
                # Provider failed; continue to next
                continue

        return None
