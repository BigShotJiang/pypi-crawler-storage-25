"""ZoomInfo enrichment provider stub."""

from __future__ import annotations

import os

from apps.backend.extensions.enrichment.base import (
    EnrichmentProvider,
    EnrichmentResult,
    ProviderNotConfiguredError,
)

_ENV_KEY = "ZOOMINFO_API_KEY"


class ZoomInfoProvider(EnrichmentProvider):
    """ZoomInfo provider. Returns found=False until API key is wired."""

    name: str = "zoominfo"

    def is_configured(self) -> bool:
        return bool(os.environ.get(_ENV_KEY))

    def enrich_by_email(self, email: str) -> EnrichmentResult:
        if not self.is_configured():
            raise ProviderNotConfiguredError(f"{_ENV_KEY} not set")
        return EnrichmentResult(provider=self.name, found=False, confidence=0.0)

    def enrich_by_domain(self, domain: str) -> EnrichmentResult:
        if not self.is_configured():
            raise ProviderNotConfiguredError(f"{_ENV_KEY} not set")
        return EnrichmentResult(provider=self.name, found=False, confidence=0.0)
