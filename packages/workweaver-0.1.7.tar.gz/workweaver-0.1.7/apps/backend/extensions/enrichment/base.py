"""Base enrichment provider interface and result model."""

from __future__ import annotations

import urllib.request
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any
from urllib.parse import urlparse


def safe_urlopen(req: urllib.request.Request, *, timeout: float = 10.0) -> Any:
    """Open a urllib Request after verifying the scheme is https.

    #370: bandit B310 flags ``urllib.request.urlopen`` because it accepts
    any scheme including ``file://`` and ``ftp://``. Enrichment providers
    only ever call explicit HTTPS API endpoints, so validate the scheme
    at the call site and reject anything else. This converts a static
    "audit" finding into a runtime guarantee.
    """
    url = req.full_url if hasattr(req, "full_url") else str(req)
    scheme = urlparse(url).scheme.lower()
    if scheme != "https":
        raise ValueError(f"Refusing to open non-https URL scheme {scheme!r}: {url}")
    return urllib.request.urlopen(req, timeout=timeout)  # noqa: S310  # nosec B310


class ProviderNotConfiguredError(Exception):
    """Raised when an enrichment provider is called without valid credentials."""


@dataclass
class EnrichmentResult:
    """Standardized result from any enrichment provider."""

    provider: str
    found: bool
    confidence: float  # 0.0-1.0
    data: dict = field(default_factory=dict)
    cached: bool = False
    cache_age_seconds: int | None = None


class EnrichmentProvider(ABC):
    """Abstract base for enrichment data providers."""

    name: str = "base"

    @abstractmethod
    def enrich_by_email(self, email: str) -> EnrichmentResult:
        """Look up enrichment data by email address."""
        ...

    @abstractmethod
    def enrich_by_domain(self, domain: str) -> EnrichmentResult:
        """Look up enrichment data by company domain."""
        ...

    def is_configured(self) -> bool:
        """Return True if API credentials are available."""
        return False
