"""Apollo.io enrichment provider with real API integration."""

from __future__ import annotations

import json
import os
import urllib.request

from apps.backend.extensions.enrichment.base import (
    EnrichmentProvider,
    EnrichmentResult,
    ProviderNotConfiguredError,
)

_ENV_KEY = "APOLLO_API_KEY"


class ApolloProvider(EnrichmentProvider):
    """Apollo.io provider. Calls Apollo API when configured, returns not-found otherwise."""

    name: str = "apollo"

    def is_configured(self) -> bool:
        return bool(os.environ.get(_ENV_KEY))

    def _get_key(self) -> str:
        key = os.environ.get(_ENV_KEY, "")
        if not key:
            raise ProviderNotConfiguredError(f"{_ENV_KEY} not set")
        return key

    def enrich_by_email(self, email: str) -> EnrichmentResult:
        """Apollo People Match: POST https://api.apollo.io/v1/people/match"""
        if not self.is_configured():
            return EnrichmentResult(provider=self.name, found=False, confidence=0.0, data={})

        url = "https://api.apollo.io/v1/people/match"
        payload = json.dumps({"email": email}).encode()

        try:
            req = urllib.request.Request(
                url,
                data=payload,
                method="POST",
                headers={
                    "Content-Type": "application/json",
                    "Cache-Control": "no-cache",
                    "X-Api-Key": self._get_key(),
                },
            )
            with safe_urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
                person = data.get("person")
                if person:
                    return EnrichmentResult(
                        provider=self.name,
                        found=True,
                        confidence=0.9,
                        data={"person": person, "organization": data.get("organization")},
                    )
                return EnrichmentResult(provider=self.name, found=False, confidence=0.0, data={})
        except Exception:
            return EnrichmentResult(provider=self.name, found=False, confidence=0.0, data={})

    def enrich_by_domain(self, domain: str) -> EnrichmentResult:
        """Apollo Organization Search: POST https://api.apollo.io/v1/organizations/enrich"""
        if not self.is_configured():
            return EnrichmentResult(provider=self.name, found=False, confidence=0.0, data={})

        url = "https://api.apollo.io/v1/organizations/enrich"
        payload = json.dumps({"domain": domain}).encode()

        try:
            req = urllib.request.Request(
                url,
                data=payload,
                method="POST",
                headers={
                    "Content-Type": "application/json",
                    "Cache-Control": "no-cache",
                    "X-Api-Key": self._get_key(),
                },
            )
            with safe_urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
                org = data.get("organization")
                if org:
                    return EnrichmentResult(
                        provider=self.name,
                        found=True,
                        confidence=0.85,
                        data={"organization": org},
                    )
                return EnrichmentResult(provider=self.name, found=False, confidence=0.0, data={})
        except Exception:
            return EnrichmentResult(provider=self.name, found=False, confidence=0.0, data={})
