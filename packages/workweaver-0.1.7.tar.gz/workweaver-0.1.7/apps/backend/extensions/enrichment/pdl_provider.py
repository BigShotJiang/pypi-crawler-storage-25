"""People Data Labs enrichment provider with real API integration."""

from __future__ import annotations

import json
import os
import urllib.request

from apps.backend.extensions.enrichment.base import (
    EnrichmentProvider,
    EnrichmentResult,
    ProviderNotConfiguredError,
)

_ENV_KEY = "PDL_API_KEY"


class PdlProvider(EnrichmentProvider):
    """People Data Labs provider. Calls PDL API when configured, returns not-found otherwise."""

    name: str = "pdl"

    def is_configured(self) -> bool:
        return bool(os.environ.get(_ENV_KEY))

    def _get_key(self) -> str:
        key = os.environ.get(_ENV_KEY, "")
        if not key:
            raise ProviderNotConfiguredError(f"{_ENV_KEY} not set")
        return key

    def enrich_by_email(self, email: str) -> EnrichmentResult:
        """PDL Person Enrich: GET https://api.peopledatalabs.com/v5/person/enrich"""
        if not self.is_configured():
            return EnrichmentResult(provider=self.name, found=False, confidence=0.0, data={})

        url = f"https://api.peopledatalabs.com/v5/person/enrich?email={email}"

        try:
            req = urllib.request.Request(
                url,
                headers={
                    "Accept": "application/json",
                    "X-Api-Key": self._get_key(),
                },
            )
            with safe_urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
                likelihood = data.get("likelihood", 0)
                if likelihood and likelihood > 0:
                    return EnrichmentResult(
                        provider=self.name,
                        found=True,
                        confidence=min(float(likelihood) / 10.0, 1.0),
                        data={
                            "full_name": data.get("full_name"),
                            "job_title": data.get("job_title"),
                            "job_company_name": data.get("job_company_name"),
                            "linkedin_url": data.get("linkedin_url"),
                        },
                    )
                return EnrichmentResult(provider=self.name, found=False, confidence=0.0, data={})
        except Exception:
            return EnrichmentResult(provider=self.name, found=False, confidence=0.0, data={})

    def enrich_by_domain(self, domain: str) -> EnrichmentResult:
        """PDL Company Enrich: GET https://api.peopledatalabs.com/v5/company/enrich"""
        if not self.is_configured():
            return EnrichmentResult(provider=self.name, found=False, confidence=0.0, data={})

        url = f"https://api.peopledatalabs.com/v5/company/enrich?website={domain}"

        try:
            req = urllib.request.Request(
                url,
                headers={
                    "Accept": "application/json",
                    "X-Api-Key": self._get_key(),
                },
            )
            with safe_urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
                name = data.get("name") or data.get("display_name")
                if name:
                    return EnrichmentResult(
                        provider=self.name,
                        found=True,
                        confidence=0.8,
                        data={
                            "name": name,
                            "industry": data.get("industry"),
                            "size": data.get("size"),
                            "website": data.get("website"),
                        },
                    )
                return EnrichmentResult(provider=self.name, found=False, confidence=0.0, data={})
        except Exception:
            return EnrichmentResult(provider=self.name, found=False, confidence=0.0, data={})
