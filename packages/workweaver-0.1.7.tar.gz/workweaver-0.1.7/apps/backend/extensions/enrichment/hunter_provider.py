"""Hunter.io enrichment provider with real API integration."""

from __future__ import annotations

import json
import os
import urllib.request

from apps.backend.extensions.enrichment.base import (
    EnrichmentProvider,
    EnrichmentResult,
    ProviderNotConfiguredError,
)

_ENV_KEY = "HUNTER_API_KEY"


class HunterProvider(EnrichmentProvider):
    """Hunter.io provider. Calls Hunter API when configured, returns not-found otherwise."""

    name: str = "hunter"

    def is_configured(self) -> bool:
        return bool(os.environ.get(_ENV_KEY))

    def _get_key(self) -> str:
        key = os.environ.get(_ENV_KEY, "")
        if not key:
            raise ProviderNotConfiguredError(f"{_ENV_KEY} not set")
        return key

    def enrich_by_email(self, email: str) -> EnrichmentResult:
        """Hunter Domain Search API: GET https://api.hunter.io/v2/domain-search"""
        if not self.is_configured():
            return EnrichmentResult(provider=self.name, found=False, confidence=0.0, data={})

        domain = email.split("@")[1] if "@" in email else email
        return self._search_domain(domain)

    def enrich_by_domain(self, domain: str) -> EnrichmentResult:
        """Hunter Domain Search API: GET https://api.hunter.io/v2/domain-search"""
        if not self.is_configured():
            return EnrichmentResult(provider=self.name, found=False, confidence=0.0, data={})

        return self._search_domain(domain)

    def _search_domain(self, domain: str) -> EnrichmentResult:
        url = f"https://api.hunter.io/v2/domain-search?domain={domain}&api_key={self._get_key()}"
        try:
            req = urllib.request.Request(url, headers={"Accept": "application/json"})
            with safe_urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read().decode())
                emails = data.get("data", {}).get("emails", [])
                if emails:
                    return EnrichmentResult(
                        provider=self.name,
                        found=True,
                        confidence=emails[0].get("confidence", 0) / 100.0,
                        data={
                            "emails": emails[:5],
                            "domain": domain,
                            "organization": data.get("data", {}).get("organization"),
                        },
                    )
                return EnrichmentResult(provider=self.name, found=False, confidence=0.0, data={"domain": domain})
        except Exception:
            return EnrichmentResult(provider=self.name, found=False, confidence=0.0, data={})
