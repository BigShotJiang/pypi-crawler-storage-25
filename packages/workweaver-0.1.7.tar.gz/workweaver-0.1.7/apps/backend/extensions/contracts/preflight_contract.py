"""PreflightContract — gate planning/execution on evals + guardrails (#1520)."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class PreflightStatus(str, Enum):
    PASS = "pass"
    SKIP = "skip"
    FAIL = "fail"
    ERROR = "error"


class PreflightCheck(BaseModel):
    model_config = ConfigDict(frozen=True)
    check_name: str
    status: PreflightStatus
    message: str = ""
    duration_ms: int = 0


class PreflightResult(BaseModel):
    model_config = ConfigDict(frozen=True)
    run_id: str
    tenant_id: str
    checks: list[PreflightCheck]
    overall: PreflightStatus
    timestamp: datetime


@runtime_checkable
class PreflightStore(Protocol):
    def save_result(self, result: PreflightResult) -> None: ...
    def get_result(self, run_id: str) -> PreflightResult | None: ...


class InMemoryPreflightStore:
    def __init__(self) -> None:
        self._results: dict[str, PreflightResult] = {}

    def save_result(self, result: PreflightResult) -> None:
        self._results[result.run_id] = result

    def get_result(self, run_id: str) -> PreflightResult | None:
        return self._results.get(run_id)


class PreflightContract:
    """Gates every planning/execution run on evals + guardrails."""

    def __init__(self, store: PreflightStore) -> None:
        self._store = store

    def run(self, run_id: str, tenant_id: str, checks: list[PreflightCheck]) -> PreflightResult:
        statuses = [c.status for c in checks]
        if any(s == PreflightStatus.ERROR for s in statuses):
            overall = PreflightStatus.ERROR
        elif any(s == PreflightStatus.FAIL for s in statuses):
            overall = PreflightStatus.FAIL
        elif any(s == PreflightStatus.SKIP for s in statuses) and all(s != PreflightStatus.FAIL for s in statuses):
            overall = PreflightStatus.SKIP
        else:
            overall = PreflightStatus.PASS
        result = PreflightResult(run_id=run_id, tenant_id=tenant_id, checks=checks, overall=overall, timestamp=datetime.now(UTC))
        self._store.save_result(result)
        return result

    def get_result(self, run_id: str) -> PreflightResult | None:
        return self._store.get_result(run_id)

    def is_pass(self, run_id: str) -> bool:
        result = self._store.get_result(run_id)
        return result is not None and result.overall == PreflightStatus.PASS
