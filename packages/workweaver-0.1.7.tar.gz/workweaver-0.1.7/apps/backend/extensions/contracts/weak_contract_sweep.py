"""WeakContractSweep — audit interfaces for evidence + decision-trace (#1521)."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class ContractStatus(str, Enum):
    PASS = "pass"
    WARN = "warn"
    FAIL = "fail"


class ContractFinding(BaseModel):
    model_config = ConfigDict(frozen=True)
    interface_name: str
    status: ContractStatus
    has_evidence: bool
    has_decision_trace: bool
    message: str


class SweepReport(BaseModel):
    model_config = ConfigDict(frozen=True)
    sweep_id: str
    tenant_id: str
    findings: list[ContractFinding]
    pass_count: int
    warn_count: int
    fail_count: int
    timestamp: datetime


@runtime_checkable
class SweepStore(Protocol):
    def save_report(self, report: SweepReport) -> None: ...
    def get_report(self, sweep_id: str) -> SweepReport | None: ...
    def list_reports(self, tenant_id: str, limit: int = 50) -> list[SweepReport]: ...


class InMemorySweepStore:
    def __init__(self) -> None:
        self._reports: dict[str, SweepReport] = {}

    def save_report(self, report: SweepReport) -> None:
        self._reports[report.sweep_id] = report

    def get_report(self, sweep_id: str) -> SweepReport | None:
        return self._reports.get(sweep_id)

    def list_reports(self, tenant_id: str, limit: int = 50) -> list[SweepReport]:
        return [r for r in self._reports.values() if r.tenant_id == tenant_id][:limit]


class WeakContractSweep:
    """Audits interfaces for evidence and decision-trace compliance."""

    def __init__(self, store: SweepStore) -> None:
        self._store = store

    def audit(self, sweep_id: str, tenant_id: str, interfaces: list[dict]) -> SweepReport:
        findings: list[ContractFinding] = []
        for iface in interfaces:
            has_evidence = iface.get("has_evidence", False)
            has_trace = iface.get("has_decision_trace", False)
            if has_evidence and has_trace:
                status = ContractStatus.PASS
            elif has_evidence or has_trace:
                status = ContractStatus.WARN
            else:
                status = ContractStatus.FAIL
            findings.append(ContractFinding(
                interface_name=iface.get("name", "unknown"),
                status=status,
                has_evidence=has_evidence,
                has_decision_trace=has_trace,
                message=iface.get("message", ""),
            ))
        report = SweepReport(
            sweep_id=sweep_id,
            tenant_id=tenant_id,
            findings=findings,
            pass_count=sum(1 for f in findings if f.status == ContractStatus.PASS),
            warn_count=sum(1 for f in findings if f.status == ContractStatus.WARN),
            fail_count=sum(1 for f in findings if f.status == ContractStatus.FAIL),
            timestamp=datetime.now(UTC),
        )
        self._store.save_report(report)
        return report

    def get_report(self, sweep_id: str) -> SweepReport | None:
        return self._store.get_report(sweep_id)
