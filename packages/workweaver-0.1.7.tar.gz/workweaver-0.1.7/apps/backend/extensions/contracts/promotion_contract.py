"""PromotionContract — Variant promotion with evidence back-links (#1519)."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class PromotionStatus(str, Enum):
    ELIGIBLE = "eligible"
    PROMOTED = "promoted"
    REJECTED = "rejected"
    PENDING = "pending"


class EvidenceLink(BaseModel):
    model_config = ConfigDict(frozen=True)
    evidence_id: str
    eval_run_id: str
    score: float
    passed: bool


class PromotionRecord(BaseModel):
    model_config = ConfigDict(frozen=True)
    promotion_id: str
    tenant_id: str
    variant_id: str
    skill_id: str
    status: PromotionStatus
    evidence: list[EvidenceLink]
    promoted_at: datetime | None
    timestamp: datetime


@runtime_checkable
class PromotionStore(Protocol):
    def save(self, record: PromotionRecord) -> None: ...
    def get(self, promotion_id: str) -> PromotionRecord | None: ...
    def list_by_tenant(self, tenant_id: str, limit: int = 50) -> list[PromotionRecord]: ...


class InMemoryPromotionStore:
    def __init__(self) -> None:
        self._records: dict[str, PromotionRecord] = {}

    def save(self, record: PromotionRecord) -> None:
        self._records[record.promotion_id] = record

    def get(self, promotion_id: str) -> PromotionRecord | None:
        return self._records.get(promotion_id)

    def list_by_tenant(self, tenant_id: str, limit: int = 50) -> list[PromotionRecord]:
        return [r for r in self._records.values() if r.tenant_id == tenant_id][:limit]


class PromotionContract:
    """Manages Variant → Skill promotion with evidence requirements."""

    def __init__(self, store: PromotionStore, min_evidence: int = 1, min_score: float = 0.8) -> None:
        self._store = store
        self._min_evidence = min_evidence
        self._min_score = min_score

    def nominate(self, promotion_id: str, tenant_id: str, variant_id: str, skill_id: str, evidence: list[EvidenceLink]) -> PromotionRecord:
        eligible = len(evidence) >= self._min_evidence and all(e.score >= self._min_score for e in evidence)
        status = PromotionStatus.ELIGIBLE if eligible else PromotionStatus.PENDING
        record = PromotionRecord(promotion_id=promotion_id, tenant_id=tenant_id, variant_id=variant_id, skill_id=skill_id, status=status, evidence=evidence, promoted_at=None, timestamp=datetime.now(UTC))
        self._store.save(record)
        return record

    def promote(self, promotion_id: str) -> PromotionRecord | None:
        record = self._store.get(promotion_id)
        if not record:
            return None
        if record.status == PromotionStatus.PENDING:
            return record
        promoted = PromotionRecord(promotion_id=record.promotion_id, tenant_id=record.tenant_id, variant_id=record.variant_id, skill_id=record.skill_id, status=PromotionStatus.PROMOTED, evidence=record.evidence, promoted_at=datetime.now(UTC), timestamp=record.timestamp)
        self._store.save(promoted)
        return promoted

    def reject(self, promotion_id: str) -> PromotionRecord | None:
        record = self._store.get(promotion_id)
        if not record:
            return None
        rejected = PromotionRecord(promotion_id=record.promotion_id, tenant_id=record.tenant_id, variant_id=record.variant_id, skill_id=record.skill_id, status=PromotionStatus.REJECTED, evidence=record.evidence, promoted_at=None, timestamp=record.timestamp)
        self._store.save(rejected)
        return rejected

    def get(self, promotion_id: str) -> PromotionRecord | None:
        return self._store.get(promotion_id)
