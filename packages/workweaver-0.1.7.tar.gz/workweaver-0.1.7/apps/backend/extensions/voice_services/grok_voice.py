"""Grok voice synthesis service (F-VO-003).

Provides text-to-speech synthesis via xAI's Grok voice API with:
- Streaming audio support (async generator yielding chunks)
- SSML parsing (extracts speech attributes, strips tags for API)
- Voice selection with validation
- Tenant-scoped rate limiting
- Metering integration
- Long text chunking (splits at sentence boundaries)

API endpoint: POST https://api.x.ai/v1/audio/speech
"""

from __future__ import annotations

import logging
import os
import re
import time
from collections import defaultdict
from typing import Any
from collections.abc import AsyncIterator, Awaitable, Callable

from apps.backend.services.inference.service import DEFAULT_GROK_VOICE_MODEL_SPEC
from apps.backend.services.voice_catalog import VoiceCatalog, get_voice_catalog

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

GROK_VOICE_API_URL = "https://api.x.ai/v1/audio/speech"
GROK_VOICE_MODEL = DEFAULT_GROK_VOICE_MODEL_SPEC

# Available voices on xAI Grok voice OpenAI-compat synth endpoint /v1/audio/speech.
# These are the canonical voices accepted by the speech-synthesis API path.
AVAILABLE_VOICES: list[dict[str, str]] = [
    {"id": "alloy", "name": "Alloy", "description": "Neutral and balanced"},
    {"id": "echo", "name": "Echo", "description": "Warm and clear"},
    {"id": "fable", "name": "Fable", "description": "Expressive and dynamic"},
    {"id": "onyx", "name": "Onyx", "description": "Deep and resonant"},
    {"id": "nova", "name": "Nova", "description": "Friendly and upbeat"},
    {"id": "shimmer", "name": "Shimmer", "description": "Soft and gentle"},
]

_OPENAI_COMPAT_VOICE_IDS: frozenset[str] = frozenset(v["id"] for v in AVAILABLE_VOICES)

# xAI realtime voice aliases. The realtime WSS path uses XAIVoice enum
# ("Ara"/"Zeus") directly and is unaffected by this map. This map only routes
# legacy / persona-template voice_ids through the OpenAI-compat /v1/audio/speech
# endpoint so personas storing "ara"/"zeus" do not raise ValueError on synth.
# Each alias resolves to its closest OpenAI-compat voice character match.
_XAI_REALTIME_ALIAS: dict[str, str] = {
    "ara": "nova",
    "Ara": "nova",
    "zeus": "onyx",
    "Zeus": "onyx",
}

# Max characters per API call before chunking
TEXT_CHUNK_LIMIT = 4096

# Rate limit window in seconds
_RATE_LIMIT_WINDOW_S = 60


# ---------------------------------------------------------------------------
# Exceptions
# ---------------------------------------------------------------------------


class VoiceSynthesisError(RuntimeError):
    """Base error for voice synthesis failures."""


class VoiceSynthesisTimeoutError(VoiceSynthesisError):
    """Raised when the voice API call times out."""


# ---------------------------------------------------------------------------
# SSML Parser
# ---------------------------------------------------------------------------


class SSMLParser:
    """Lightweight SSML parser for extracting text and speech attributes."""

    _TAG_PATTERN = re.compile(r"<[^>]+>")
    _PROSODY_PATTERN = re.compile(r"<prosody\s+([^>]*)>", re.IGNORECASE)
    _ATTR_PATTERN = re.compile(r'(\w+)\s*=\s*"([^"]*)"')

    @staticmethod
    def is_ssml(text: str) -> bool:
        """Check if text contains SSML markup."""
        stripped = text.strip()
        return stripped.startswith("<speak>") or stripped.startswith("<speak ")

    @classmethod
    def extract_text(cls, text: str) -> str:
        """Strip all SSML tags and return plain text."""
        if not cls.is_ssml(text):
            return text
        plain = cls._TAG_PATTERN.sub(" ", text)
        # Collapse multiple spaces
        return re.sub(r"\s+", " ", plain).strip()

    @classmethod
    def extract_attributes(cls, text: str) -> dict[str, str]:
        """Extract prosody attributes from SSML (rate, pitch, volume, etc.)."""
        if not cls.is_ssml(text):
            return {}

        attrs: dict[str, str] = {}
        for prosody_match in cls._PROSODY_PATTERN.finditer(text):
            attr_string = prosody_match.group(1)
            for attr_match in cls._ATTR_PATTERN.finditer(attr_string):
                attrs[attr_match.group(1)] = attr_match.group(2)
        return attrs


# ---------------------------------------------------------------------------
# Text chunking
# ---------------------------------------------------------------------------


def _chunk_text(text: str, max_chars: int = TEXT_CHUNK_LIMIT) -> list[str]:
    """Split text into chunks at sentence boundaries, respecting max_chars.

    Falls back to splitting at word boundaries if a single sentence exceeds
    the limit.
    """
    if len(text) <= max_chars:
        return [text]

    # Split at sentence boundaries (period, exclamation, question followed by space)
    sentences = re.split(r"(?<=[.!?])\s+", text)
    chunks: list[str] = []
    current: list[str] = []
    current_len = 0

    for sentence in sentences:
        sentence_len = len(sentence)
        if current_len + sentence_len + 1 > max_chars and current:
            chunks.append(" ".join(current))
            current = []
            current_len = 0

        if sentence_len > max_chars:
            # Split oversized sentence at word boundaries
            words = sentence.split()
            for word in words:
                if current_len + len(word) + 1 > max_chars and current:
                    chunks.append(" ".join(current))
                    current = []
                    current_len = 0
                current.append(word)
                current_len += len(word) + 1
        else:
            current.append(sentence)
            current_len += sentence_len + 1

    if current:
        chunks.append(" ".join(current))

    return chunks


# ---------------------------------------------------------------------------
# Rate limiter (per-tenant, in-memory sliding window)
# ---------------------------------------------------------------------------


class _TenantRateLimiter:
    """Simple sliding-window rate limiter scoped per tenant."""

    def __init__(self, max_requests: int, window_seconds: float = _RATE_LIMIT_WINDOW_S) -> None:
        self._max = max_requests
        self._window = window_seconds
        self._requests: dict[str, list[float]] = defaultdict(list)

    def check(self, tenant_id: str) -> bool:
        """Return True if the request is allowed, False if rate-limited."""
        now = time.monotonic()
        cutoff = now - self._window
        timestamps = self._requests[tenant_id]
        # Prune old entries
        self._requests[tenant_id] = [t for t in timestamps if t > cutoff]
        if len(self._requests[tenant_id]) >= self._max:
            return False
        self._requests[tenant_id].append(now)
        return True


# ---------------------------------------------------------------------------
# Main service
# ---------------------------------------------------------------------------

# Type alias for the metering callback
MeteringFn = Callable[..., Awaitable[None]]


class GrokVoiceSynthesizer:
    """Grok voice text-to-speech synthesis with streaming, SSML, and metering.

    Args:
        api_key: xAI API key. Falls back to XAI_API_KEY / GROK_API_KEY env vars.
        api_url: Override API endpoint URL.
        http_client: Injected async HTTP client (for testing).
        metering_fn: Async callback for usage metering.
        rate_limit_max_per_tenant: Max synthesis calls per tenant per minute.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        api_url: str | None = None,
        http_client: Any | None = None,
        metering_fn: MeteringFn | None = None,
        voice_catalog: VoiceCatalog | None = None,
        rate_limit_max_per_tenant: int = 100,
    ) -> None:
        self._api_key = api_key or os.environ.get("XAI_API_KEY") or os.environ.get("GROK_API_KEY") or ""
        self._api_url = api_url or os.environ.get("GROK_VOICE_API_URL") or GROK_VOICE_API_URL
        self._http_client = http_client
        self._metering_fn = metering_fn
        self._voice_catalog = voice_catalog or get_voice_catalog()
        self._rate_limiter = _TenantRateLimiter(
            max_requests=rate_limit_max_per_tenant,
        )

    def _get_client(self) -> Any:
        """Return HTTP client, creating one lazily if not injected."""
        if self._http_client is not None:
            return self._http_client
        # Lazy import to avoid circular deps at module level
        from apps.backend.services.http_client_registry import get_shared_async_client

        self._http_client = get_shared_async_client(timeout=30.0)
        return self._http_client

    def _headers(self) -> dict[str, str]:
        return {
            "Authorization": f"Bearer {self._api_key}",
            "Content-Type": "application/json",
        }

    @staticmethod
    def list_voices() -> list[dict[str, str]]:
        """Return available voice options."""
        return list(AVAILABLE_VOICES)

    @staticmethod
    def _validate_voice_id(
        voice_id: str,
        *,
        workspace_id: str = "",
        voice_catalog: VoiceCatalog | None = None,
    ) -> None:
        """Raise ValueError if VoiceCatalog does not authorize voice_id."""
        catalog = voice_catalog or get_voice_catalog()
        if not catalog.is_authorized(workspace_id=workspace_id, voice_id=voice_id):
            raise ValueError(
                f"Invalid voice_id '{voice_id}' for workspace '{workspace_id}'. "
                f"Available built-ins: {sorted(VoiceCatalog.builtin_voice_ids())}"
            )

    @staticmethod
    def _resolve_voice_id(voice_id: str) -> str:
        """Resolve an xAI realtime voice alias to its OpenAI-compat equivalent.

        Delegates to VoiceCatalog.resolve_alias().  The OpenAI-compat
        /v1/audio/speech endpoint accepts only the canonical six voices.
        Persona templates and settings sometimes carry xAI realtime voice ids
        (e.g. "ara") that are valid for the realtime WSS endpoint but not for
        /v1/audio/speech. This resolver maps them deterministically so synthesis
        succeeds without breaking realtime callers.
        """
        return VoiceCatalog.resolve_alias(voice_id)

    def _check_rate_limit(self, tenant_id: str) -> None:
        """Raise VoiceSynthesisError if tenant is rate-limited."""
        if not self._rate_limiter.check(tenant_id):
            raise VoiceSynthesisError(
                f"Tenant '{tenant_id}' has exceeded the voice synthesis rate limit. Please wait before retrying."
            )

    async def _emit_metering(
        self,
        *,
        tenant_id: str,
        text_length: int,
        voice_id: str,
        chunk_count: int,
    ) -> None:
        """Fire-and-forget metering event."""
        if self._metering_fn is None:
            return
        try:
            await self._metering_fn(
                tenant_id=tenant_id,
                provider="grok_voice",
                text_length=text_length,
                voice_id=voice_id,
                chunk_count=chunk_count,
            )
        except Exception:
            logger.warning(
                "Voice metering emission failed tenant=%s (non-blocking)",
                tenant_id,
                exc_info=True,
            )

    async def _synthesize_chunk(
        self,
        text: str,
        voice_id: str,
    ) -> bytes:
        """Send a single chunk to the Grok voice API and return audio bytes."""
        client = self._get_client()
        payload = {
            "model": GROK_VOICE_MODEL,
            "input": text,
            "voice": self._resolve_voice_id(voice_id),
            "response_format": "mp3",
        }
        try:
            response = await client.post(
                self._api_url,
                headers=self._headers(),
                json=payload,
            )
            response.raise_for_status()
            return response.content
        except TimeoutError as exc:
            raise VoiceSynthesisTimeoutError(f"Grok voice API timed out while synthesizing {len(text)} chars") from exc
        except VoiceSynthesisTimeoutError:
            raise
        except Exception as exc:
            raise VoiceSynthesisError(f"Grok voice synthesis failed: {exc}") from exc

    async def synthesize(
        self,
        *,
        text: str,
        voice_id: str,
        tenant_id: str,
    ) -> bytes:
        """Synthesize text to audio bytes.

        Handles SSML stripping, text chunking, rate limiting, and metering.

        Args:
            text: Input text or SSML markup.
            voice_id: Voice identifier (must be in AVAILABLE_VOICES).
            tenant_id: Tenant ID for rate limiting and metering.

        Returns:
            Raw audio bytes (MP3 format).

        Raises:
            ValueError: If text is empty or voice_id is invalid.
            VoiceSynthesisError: If rate-limited or API call fails.
            VoiceSynthesisTimeoutError: If API call times out.
        """
        if not text or not text.strip():
            raise ValueError("text must not be empty")

        self._validate_voice_id(
            voice_id,
            workspace_id=tenant_id,
            voice_catalog=self._voice_catalog,
        )
        self._check_rate_limit(tenant_id)

        # Process SSML
        plain_text = SSMLParser.extract_text(text)

        # Chunk long text
        chunks = _chunk_text(plain_text)

        # Synthesize each chunk
        audio_parts: list[bytes] = []
        for chunk in chunks:
            audio = await self._synthesize_chunk(chunk, voice_id)
            audio_parts.append(audio)

        result = b"".join(audio_parts)

        # Emit metering event
        await self._emit_metering(
            tenant_id=tenant_id,
            text_length=len(plain_text),
            voice_id=voice_id,
            chunk_count=len(chunks),
        )

        return result

    async def synthesize_stream(
        self,
        *,
        text: str,
        voice_id: str,
        tenant_id: str,
    ) -> AsyncIterator[bytes]:
        """Stream synthesized audio chunks.

        Yields audio data incrementally for low-latency playback.

        Args:
            text: Input text or SSML markup.
            voice_id: Voice identifier.
            tenant_id: Tenant ID for rate limiting.

        Yields:
            Audio byte chunks.

        Raises:
            ValueError: If text is empty or voice_id is invalid.
            VoiceSynthesisError: If rate-limited or API call fails.
        """
        if not text or not text.strip():
            raise ValueError("text must not be empty")

        self._validate_voice_id(
            voice_id,
            workspace_id=tenant_id,
            voice_catalog=self._voice_catalog,
        )
        self._check_rate_limit(tenant_id)

        plain_text = SSMLParser.extract_text(text)

        # Chunk long text to respect API limits (same as non-streaming path)
        chunks = _chunk_text(plain_text)

        for chunk in chunks:
            client = self._get_client()
            payload = {
                "model": GROK_VOICE_MODEL,
                "input": chunk,
                "voice": self._resolve_voice_id(voice_id),
                "response_format": "mp3",
            }

            try:
                async with client.stream(
                    "POST",
                    self._api_url,
                    headers=self._headers(),
                    json=payload,
                ) as response:
                    response.raise_for_status()
                    async for audio_chunk in response.aiter_bytes(chunk_size=4096):
                        yield audio_chunk
            except TimeoutError as exc:
                raise VoiceSynthesisTimeoutError(f"Grok voice API stream timed out for {len(chunk)} chars") from exc
            except VoiceSynthesisTimeoutError:
                raise
            except Exception as exc:
                raise VoiceSynthesisError(f"Grok voice stream failed: {exc}") from exc

        # Emit metering after stream completes
        await self._emit_metering(
            tenant_id=tenant_id,
            text_length=len(plain_text),
            voice_id=voice_id,
            chunk_count=len(chunks),
        )
