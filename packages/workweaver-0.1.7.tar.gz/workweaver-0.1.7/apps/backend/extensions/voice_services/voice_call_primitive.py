"""VoiceCallPrimitive — expose voice_call as Zara planner primitive (#1594)."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class TransportProvider(str, Enum):
    TWILIO = "twilio"
    INTERNAL = "internal"
    WHATSAPP = "whatsapp"


class VoiceCallStatus(str, Enum):
    INITIATED = "initiated"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    FAILED = "failed"


class VoiceCallRequest(BaseModel):
    model_config = ConfigDict(frozen=True)
    request_id: str
    tenant_id: str
    transport: TransportProvider = TransportProvider.TWILIO
    to_number: str = ""
    script: str = ""
    metadata: dict[str, Any] | None = None


class VoiceCallResult(BaseModel):
    model_config = ConfigDict(frozen=True)
    call_id: str
    request_id: str
    status: VoiceCallStatus
    transport: TransportProvider
    duration_seconds: int = 0
    metadata: dict[str, Any] | None = None
    timestamp: datetime


@runtime_checkable
class VoicePrimitiveStore(Protocol):
    def save_result(self, result: VoiceCallResult) -> None: ...
    def get_result(self, call_id: str) -> VoiceCallResult | None: ...
    def list_results(self, tenant_id: str, limit: int = 50) -> list[VoiceCallResult]: ...


class InMemoryVoicePrimitiveStore:
    def __init__(self) -> None:
        self._results: dict[str, VoiceCallResult] = {}

    def save_result(self, result: VoiceCallResult) -> None:
        self._results[result.call_id] = result

    def get_result(self, call_id: str) -> VoiceCallResult | None:
        return self._results.get(call_id)

    def list_results(self, tenant_id: str, limit: int = 50) -> list[VoiceCallResult]:
        return [r for r in self._results.values()][:limit]


class VoiceCallPrimitive:
    """Exposes voice_call as a Zara planner primitive with transport abstraction."""

    def __init__(self, store: VoicePrimitiveStore) -> None:
        self._store = store

    def initiate(self, call_id: str, request: VoiceCallRequest) -> VoiceCallResult:
        result = VoiceCallResult(call_id=call_id, request_id=request.request_id, status=VoiceCallStatus.INITIATED, transport=request.transport, timestamp=datetime.now(UTC))
        self._store.save_result(result)
        return result

    def complete(self, call_id: str, duration_seconds: int = 0) -> VoiceCallResult | None:
        existing = self._store.get_result(call_id)
        if not existing:
            return None
        completed = VoiceCallResult(call_id=existing.call_id, request_id=existing.request_id, status=VoiceCallStatus.COMPLETED, transport=existing.transport, duration_seconds=duration_seconds, metadata=existing.metadata, timestamp=datetime.now(UTC))
        self._store.save_result(completed)
        return completed

    def fail(self, call_id: str) -> VoiceCallResult | None:
        existing = self._store.get_result(call_id)
        if not existing:
            return None
        failed = VoiceCallResult(call_id=existing.call_id, request_id=existing.request_id, status=VoiceCallStatus.FAILED, transport=existing.transport, metadata=existing.metadata, timestamp=datetime.now(UTC))
        self._store.save_result(failed)
        return failed

    def get_result(self, call_id: str) -> VoiceCallResult | None:
        return self._store.get_result(call_id)

    def list_results(self, tenant_id: str, limit: int = 50) -> list[VoiceCallResult]:
        return self._store.list_results(tenant_id, limit)
