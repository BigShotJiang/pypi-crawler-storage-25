"""xAI Custom Voices backend — clone create/status/delete via xAI API (#3239).

Wraps POST/GET/DELETE /v1/custom-voices with:
- Multipart audio upload
- Server-side audio validation (120s max)
- Geography preflight (US-only, Illinois excluded)
- ResourcesLayer evidence retention for reference audio
- Decision Trace emission per action
"""
from __future__ import annotations

import logging
import os
import uuid
from collections.abc import Callable
from datetime import datetime, UTC
from typing import Any

logger = logging.getLogger(__name__)

XAI_CUSTOM_VOICES_URL = "https://api.x.ai/v1/custom-voices"
MAX_AUDIO_DURATION_S = 120


def check_voice_clone_geography(*, country: str, region: str) -> bool:
    """Return True if geography permits voice cloning.

    xAI Custom Voices: US-only, Illinois excluded.
    """
    if (country or "").upper() != "US":
        return False
    if (region or "").upper() in {"IL", "ILLINOIS"}:
        return False
    return True


class XAIVoiceCloneClient:
    """Async client for xAI Custom Voices API.

    Args:
        api_key: xAI API key (falls back to XAI_API_KEY env var).
        http_client: Injected async HTTP client (httpx.AsyncClient).
        resources_layer: ResourcesLayer for storing reference audio.
        trace_sink: Callable accepting a dict for Decision Trace emission.
    """

    def __init__(
        self,
        *,
        api_key: str | None = None,
        http_client: Any | None = None,
        resources_layer: Any | None = None,
        trace_sink: Callable[[dict[str, Any]], None] | None = None,
    ) -> None:
        self._api_key = api_key or os.environ.get("XAI_API_KEY") or ""
        self._http_client = http_client
        self._resources_layer = resources_layer
        self._trace_sink = trace_sink

    def _get_client(self) -> Any:
        if self._http_client is not None:
            return self._http_client
        from apps.backend.services.http_client_registry import get_shared_async_client
        self._http_client = get_shared_async_client(timeout=180.0)
        return self._http_client

    def _headers(self) -> dict[str, str]:
        return {"Authorization": f"Bearer {self._api_key}"}

    def _emit_trace(self, trace: dict[str, Any]) -> None:
        if self._trace_sink is not None:
            self._trace_sink(trace)

    async def create_voice(
        self,
        *,
        tenant_id: str,
        persona_id: str,
        audio_data: bytes,
        content_type: str,
        audio_duration_s: float,
        consent_record_id: str,
        geo_country: str = "US",
        geo_region: str = "",
    ) -> dict[str, Any]:
        """Create a custom voice via xAI API.

        Steps:
        1. Validate audio duration <= 120s
        2. Check geography (US-only, no Illinois)
        3. Store reference audio in ResourcesLayer
        4. POST multipart to xAI /v1/custom-voices
        5. Emit Decision Trace

        Returns dict with xai_voice_id, status, sample_key.
        """
        # 1. Audio duration validation
        if audio_duration_s > MAX_AUDIO_DURATION_S:
            raise ValueError(
                f"Audio duration {audio_duration_s:.1f}s exceeds {MAX_AUDIO_DURATION_S}s limit"
            )

        # 2. Geography preflight
        if not check_voice_clone_geography(country=geo_country, region=geo_region):
            reason = "Illinois" if (geo_country or "").upper() == "US" else "non-US"
            raise ValueError(
                f"Voice cloning is not available for {reason} tenants"
            )

        # 3. Store reference audio in ResourcesLayer
        sample_key = f"voice-clones/{tenant_id}/{uuid.uuid4().hex[:8]}.wav"
        if self._resources_layer is not None:
            sample_key = await self._resources_layer.store_raw(
                tenant_id=tenant_id,
                resource_type="voice_clone_sample",
                content=audio_data,
                content_type=content_type,
                container_tag="voice-clones",
                custom_id=f"{persona_id}-sample",
            )

        # 4. POST multipart to xAI
        client = self._get_client()
        files = {"file": (f"{persona_id}-sample.wav", audio_data, content_type)}
        data = {}

        response = await client.post(
            XAI_CUSTOM_VOICES_URL,
            headers=self._headers(),
            files=files,
            data=data,
        )
        response.raise_for_status()
        result = response.json()
        xai_voice_id = result.get("id", "")

        # 5. Emit Decision Trace
        self._emit_trace({
            "operation": "voice_clone_create",
            "outcome": "success",
            "tenant_id": tenant_id,
            "persona_id": persona_id,
            "xai_voice_id": xai_voice_id,
            "consent_record_id": consent_record_id,
            "policy_verdict": "allowed",
            "audio_duration_s": audio_duration_s,
            "sample_key": sample_key,
            "created_at": datetime.now(UTC).isoformat(),
        })

        return {
            "xai_voice_id": xai_voice_id,
            "status": result.get("status", "pending"),
            "sample_key": sample_key,
        }

    async def get_voice(self, *, voice_id: str) -> dict[str, Any]:
        """Get custom voice status from xAI."""
        client = self._get_client()
        response = await client.get(
            f"{XAI_CUSTOM_VOICES_URL}/{voice_id}",
            headers=self._headers(),
        )
        response.raise_for_status()
        return response.json()

    async def delete_voice(
        self,
        *,
        voice_id: str,
        tenant_id: str = "",
        persona_id: str = "",
    ) -> None:
        """Delete custom voice from xAI."""
        client = self._get_client()
        response = await client.delete(
            f"{XAI_CUSTOM_VOICES_URL}/{voice_id}",
            headers=self._headers(),
        )
        response.raise_for_status()

        if tenant_id and persona_id:
            self._emit_trace({
                "operation": "voice_clone_delete",
                "outcome": "success",
                "tenant_id": tenant_id,
                "persona_id": persona_id,
                "xai_voice_id": voice_id,
                "policy_verdict": "allowed",
                "created_at": datetime.now(UTC).isoformat(),
            })
