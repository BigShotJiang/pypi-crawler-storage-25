"""Zara Operating Kernel contract (#1313).

Implements the explicit maintenance / self-healing / failure-adjustment
pipeline that lives between planning and completion:

    detect -> classify -> contain -> repair/reroute -> verify -> escalate -> learn

This module is the single surface every failure-handling flow should call.
Prior to this contract, failure handling was spread across runtime services,
governance stops, schedulers, monitors, and post-run hooks with no unified
contract -- making it impossible to reason about end-to-end recovery.

Design notes:
    * Pure logic -- no DynamoDB or network dependency. The kernel is called
      by the API/runtime layer which supplies the raw signal.
    * Deterministic -- classification and repair rules are data-driven so
      unit tests can assert behaviour without mocks.
    * Observable -- every event carries the full phase trail via logs, so
      downstream observers (GoalCascadeService, audit logger) can consume
      a single ``KernelEvent`` stream.
"""

from __future__ import annotations

import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime
from enum import Enum
from typing import Any

from apps.backend.utils.time import utc_now

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Phase enum
# ---------------------------------------------------------------------------


class KernelPhase(str, Enum):
    """The 7 phases of the operating kernel pipeline."""

    DETECT = "detect"
    CLASSIFY = "classify"
    CONTAIN = "contain"
    REPAIR = "repair"
    VERIFY = "verify"
    ESCALATE = "escalate"
    LEARN = "learn"


# ---------------------------------------------------------------------------
# Event dataclass
# ---------------------------------------------------------------------------


# Known failure categories the kernel can classify.
_KNOWN_CATEGORIES: frozenset[str] = frozenset(
    {
        "stuck_session",
        "zombie_executor",
        "connector_failure",
        "policy_violation",
        "unknown",
    }
)

# Deterministic severity table (category -> severity). Unknown categories
# default to "low" severity so we never escalate noise by accident.
_CATEGORY_SEVERITY: dict[str, str] = {
    "stuck_session": "medium",
    "zombie_executor": "medium",
    "connector_failure": "medium",
    "policy_violation": "high",
    "unknown": "low",
}

# Categories that have a deterministic in-kernel repair path. Anything
# outside this set falls through to escalation after containment.
_REPAIRABLE_CATEGORIES: frozenset[str] = frozenset(
    {"stuck_session", "zombie_executor", "connector_failure"}
)

# Valid severity levels (ordered from least to most severe).
_SEVERITY_ORDER: tuple[str, ...] = ("low", "medium", "high", "critical")


@dataclass
class KernelEvent:
    """A single event flowing through the kernel pipeline."""

    event_id: str
    tenant_id: str
    phase: KernelPhase
    category: str  # see ``_KNOWN_CATEGORIES``
    severity: str  # "low" | "medium" | "high" | "critical"
    description: str
    context: dict[str, Any]
    timestamp: datetime
    resolved: bool = False
    escalated: bool = False
    phase_trail: list[KernelPhase] = field(default_factory=list)
    repair_error: str | None = None


# ---------------------------------------------------------------------------
# Kernel service
# ---------------------------------------------------------------------------


class ZaraOperatingKernel:
    """Explicit contract for Zara's between-planning-and-completion work.

    Implements ``detect -> classify -> contain -> repair/reroute -> verify
    -> escalate -> learn``.

    The kernel is intentionally pure: callers supply a ``raw_signal`` dict
    and a ``tenant_id`` and receive a fully-resolved :class:`KernelEvent`.
    Side effects (log emission, downstream notifications) are contained
    inside the kernel so the contract surface stays narrow.
    """

    def __init__(self, *, goal_cascade: Any | None = None) -> None:
        """Initialise the kernel.

        Args:
            goal_cascade: Optional :class:`GoalCascadeService` that will be
                notified of every repaired event so it can re-seed goals.
                Injected as ``Any`` to avoid a hard import cycle.
        """
        self._goal_cascade = goal_cascade

    # ------------------------------------------------------------------
    # Public pipeline
    # ------------------------------------------------------------------

    def process_event(self, raw_signal: dict[str, Any], tenant_id: str) -> KernelEvent:
        """Full pipeline: raw signal in -> resolved :class:`KernelEvent` out.

        The method always runs ``detect -> classify -> contain ->
        repair/reroute -> verify`` before deciding whether to escalate.
        Critical-severity events always escalate even when repair succeeds
        so operators retain an audit trail.
        """
        event = self._detect(raw_signal, tenant_id)
        event = self._classify(event)
        event = self._contain(event)
        event = self._repair_or_reroute(event)
        event = self._verify(event)

        if not event.resolved or event.severity == "critical":
            event = self._escalate(event)

        self._learn(event)
        return event

    # ------------------------------------------------------------------
    # Phase 1: DETECT
    # ------------------------------------------------------------------

    def _detect(self, raw_signal: dict[str, Any], tenant_id: str) -> KernelEvent:
        """Build an initial :class:`KernelEvent` from a raw signal."""
        if not isinstance(raw_signal, dict):
            raw_signal = {}
        category = str(raw_signal.get("category") or "unknown").strip().lower()
        if category not in _KNOWN_CATEGORIES:
            category = "unknown"

        description = str(raw_signal.get("description") or "").strip()
        context = raw_signal.get("context")
        if not isinstance(context, dict):
            context = {}

        event = KernelEvent(
            event_id=str(raw_signal.get("event_id") or uuid.uuid4()),
            tenant_id=tenant_id,
            phase=KernelPhase.DETECT,
            category=category,
            severity=_CATEGORY_SEVERITY.get(category, "low"),
            description=description,
            context=dict(context),
            timestamp=utc_now(),
        )
        event.phase_trail.append(KernelPhase.DETECT)
        logger.info(
            "zara_kernel.detect: tenant=%s event=%s category=%s",
            tenant_id,
            event.event_id,
            category,
        )
        return event

    # ------------------------------------------------------------------
    # Phase 2: CLASSIFY
    # ------------------------------------------------------------------

    def _classify(self, event: KernelEvent) -> KernelEvent:
        """Apply deterministic severity rules.

        Respects a caller-supplied ``severity_override`` in the context
        when it is one of the canonical severity levels; otherwise falls
        back to the category table.
        """
        override = str(event.context.get("severity_override") or "").strip().lower()
        if override in _SEVERITY_ORDER:
            event.severity = override
        else:
            event.severity = _CATEGORY_SEVERITY.get(event.category, "low")
        event.phase = KernelPhase.CLASSIFY
        event.phase_trail.append(KernelPhase.CLASSIFY)
        logger.info(
            "zara_kernel.classify: event=%s severity=%s",
            event.event_id,
            event.severity,
        )
        return event

    # ------------------------------------------------------------------
    # Phase 3: CONTAIN
    # ------------------------------------------------------------------

    def _contain(self, event: KernelEvent) -> KernelEvent:
        """Stop blast radius from spreading.

        Containment is a best-effort marker in the event context so
        downstream observers know the kernel acknowledged the anomaly
        before attempting repair.
        """
        event.context["contained"] = True
        event.phase = KernelPhase.CONTAIN
        event.phase_trail.append(KernelPhase.CONTAIN)
        logger.info(
            "zara_kernel.contain: event=%s category=%s",
            event.event_id,
            event.category,
        )
        return event

    # ------------------------------------------------------------------
    # Phase 4: REPAIR / REROUTE
    # ------------------------------------------------------------------

    def _repair_or_reroute(self, event: KernelEvent) -> KernelEvent:
        """Attempt an in-kernel fix or reroute.

        Only categories in ``_REPAIRABLE_CATEGORIES`` have deterministic
        repair paths. Anything else (policy violations, unknown) falls
        through unresolved so the escalation phase can take over.

        Hook: callers can inject ``context["force_repair_error"]`` to
        simulate a repair failure. This path sets ``repair_error`` and
        leaves ``resolved`` at ``False`` so the escalation phase triggers.
        """
        event.phase = KernelPhase.REPAIR
        event.phase_trail.append(KernelPhase.REPAIR)

        forced_error = event.context.get("force_repair_error")
        if forced_error:
            event.repair_error = str(forced_error)
            event.resolved = False
            logger.warning(
                "zara_kernel.repair_failed: event=%s error=%s",
                event.event_id,
                event.repair_error,
            )
            return event

        if event.category in _REPAIRABLE_CATEGORIES:
            event.resolved = True
            event.context["repair_action"] = self._repair_action_for(event.category)
            logger.info(
                "zara_kernel.repair_ok: event=%s action=%s",
                event.event_id,
                event.context["repair_action"],
            )
        else:
            event.resolved = False
            logger.info(
                "zara_kernel.repair_skipped: event=%s category=%s",
                event.event_id,
                event.category,
            )
        return event

    @staticmethod
    def _repair_action_for(category: str) -> str:
        """Return the canonical repair action name for a known category."""
        return {
            "stuck_session": "restart_session",
            "zombie_executor": "terminate_executor",
            "connector_failure": "reroute_connector",
        }.get(category, "noop")

    # ------------------------------------------------------------------
    # Phase 5: VERIFY
    # ------------------------------------------------------------------

    def _verify(self, event: KernelEvent) -> KernelEvent:
        """Confirm the repair phase actually resolved the anomaly.

        Verification is idempotent: ``resolved`` stays ``True`` if repair
        succeeded and stays ``False`` if it did not. This phase exists to
        give observers an explicit seam to plug deeper checks into later.
        """
        event.phase = KernelPhase.VERIFY
        event.phase_trail.append(KernelPhase.VERIFY)
        event.context["verified"] = bool(event.resolved)
        logger.info(
            "zara_kernel.verify: event=%s resolved=%s",
            event.event_id,
            event.resolved,
        )
        return event

    # ------------------------------------------------------------------
    # Phase 6: ESCALATE
    # ------------------------------------------------------------------

    def _escalate(self, event: KernelEvent) -> KernelEvent:
        """Flag the event for higher authority (human or supervisor agent).

        Called when repair did not resolve the event, or when severity is
        ``critical`` -- critical events always escalate for audit even
        when the kernel self-healed successfully.
        """
        event.phase = KernelPhase.ESCALATE
        event.phase_trail.append(KernelPhase.ESCALATE)
        event.escalated = True
        logger.warning(
            "zara_kernel.escalate: event=%s category=%s severity=%s resolved=%s",
            event.event_id,
            event.category,
            event.severity,
            event.resolved,
        )
        return event

    # ------------------------------------------------------------------
    # Phase 7: LEARN
    # ------------------------------------------------------------------

    def _learn(self, event: KernelEvent) -> None:
        """Emit the terminal phase record and notify downstream consumers.

        Called for every event regardless of outcome so the learning loop
        has complete data -- failed repairs are as informative as
        successful ones.
        """
        event.phase = KernelPhase.LEARN
        event.phase_trail.append(KernelPhase.LEARN)
        logger.info(
            "zara_kernel.learn: event=%s category=%s resolved=%s escalated=%s",
            event.event_id,
            event.category,
            event.resolved,
            event.escalated,
        )

        if self._goal_cascade is not None:
            try:
                self._goal_cascade.consume_kernel_event(event)
            except Exception as exc:  # pragma: no cover - defensive
                logger.warning(
                    "zara_kernel.learn_cascade_error: event=%s error=%s",
                    event.event_id,
                    exc,
                )
