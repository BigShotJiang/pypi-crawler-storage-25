"""Zara Operating Kernel package (#1313).

Explicit contract for Zara's between-planning-and-completion responsibilities:

    detect -> classify -> contain -> repair/reroute -> verify -> escalate -> learn

Before this package existed, failure-handling logic was spread across runtime
services, governance stops, schedulers, health monitors, and post-run hooks
with no unified contract. This package provides the single surface all
failure-handling flows should call.

Public surface:
    KernelPhase -- phase enum for the 7-step pipeline
    KernelEvent -- dataclass representing a single kernel event
    ZaraOperatingKernel -- the kernel service implementing the contract
"""

from apps.backend.extensions.zara_kernel.operating_kernel import (  # noqa: F401
    KernelEvent,
    KernelPhase,
    ZaraOperatingKernel,
)

__all__ = [
    "KernelEvent",
    "KernelPhase",
    "ZaraOperatingKernel",
]
