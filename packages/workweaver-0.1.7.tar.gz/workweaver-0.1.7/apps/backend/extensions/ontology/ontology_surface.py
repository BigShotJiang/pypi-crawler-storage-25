"""OntologyExternalSurface — HTTP/CLI/MCP surface over ontology (#1593)."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class SurfaceChannel(str, Enum):
    HTTP = "http"
    CLI = "cli"
    MCP = "mcp"
    DASHBOARD = "dashboard"


class SurfaceRequest(BaseModel):
    model_config = ConfigDict(frozen=True)
    request_id: str
    channel: SurfaceChannel
    tenant_id: str
    action: str
    params: dict[str, Any] | None = None


class SurfaceResponse(BaseModel):
    model_config = ConfigDict(frozen=True)
    request_id: str
    channel: SurfaceChannel
    status: int
    body: dict[str, Any] | None = None
    timestamp: datetime


@runtime_checkable
class SurfaceStore(Protocol):
    def save_request(self, req: SurfaceRequest) -> None: ...
    def save_response(self, resp: SurfaceResponse) -> None: ...
    def get_response(self, request_id: str) -> SurfaceResponse | None: ...


class InMemorySurfaceStore:
    def __init__(self) -> None:
        self._requests: dict[str, SurfaceRequest] = {}
        self._responses: dict[str, SurfaceResponse] = {}

    def save_request(self, req: SurfaceRequest) -> None:
        self._requests[req.request_id] = req

    def save_response(self, resp: SurfaceResponse) -> None:
        self._responses[resp.request_id] = resp

    def get_response(self, request_id: str) -> SurfaceResponse | None:
        return self._responses.get(request_id)


class OntologyExternalSurface:
    """Exposes ontology over HTTP, CLI, MCP, and dashboard channels."""

    def __init__(self, store: SurfaceStore) -> None:
        self._store = store

    def handle(self, request: SurfaceRequest) -> SurfaceResponse:
        self._store.save_request(request)
        response = SurfaceResponse(request_id=request.request_id, channel=request.channel, status=200, body={"action": request.action, "status": "handled"}, timestamp=datetime.now(UTC))
        self._store.save_response(response)
        return response

    def get_response(self, request_id: str) -> SurfaceResponse | None:
        return self._store.get_response(request_id)
