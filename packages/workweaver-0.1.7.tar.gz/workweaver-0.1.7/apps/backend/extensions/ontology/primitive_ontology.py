"""PrimitiveOntology — durable tenant-scoped semantic primitive graph."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
import re
from typing import Any, Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict, Field


class PrimitiveKind(str, Enum):
    ENTITY_SCHEMA = "entity_schema"
    ENTITY_INSTANCE = "entity_instance"
    SKILL = "skill"
    CAPABILITY = "capability"
    POLICY = "policy"
    WORKFLOW = "workflow"
    VARIANT = "variant"
    ARTIFACT = "artifact"
    SCHEDULED_JOB = "scheduled_job"


class PrimitiveRecord(BaseModel):
    model_config = ConfigDict(frozen=True)
    primitive_id: str
    tenant_id: str
    kind: PrimitiveKind
    name: str
    description: str = ""
    tags: frozenset[str] = frozenset()
    metadata: dict[str, str] | None = None
    refs: dict[str, str] = Field(default_factory=dict)
    created_at: datetime


class OntologyNode(BaseModel):
    model_config = ConfigDict(frozen=True)

    node_id: str
    tenant_id: str
    kind: PrimitiveKind
    name: str
    refs: dict[str, str] = Field(default_factory=dict)
    description: str = ""
    tags: list[str] = Field(default_factory=list)


class OntologyQueryResponse(BaseModel):
    model_config = ConfigDict(frozen=True)

    tenant_id: str
    matches: list[OntologyNode]
    consulted_sources: list[str]


_TEXT_QUERY_SCAN_LIMIT = 5000


@runtime_checkable
class OntologyStore(Protocol):
    def save(self, record: PrimitiveRecord) -> None: ...
    def get(self, primitive_id: str) -> PrimitiveRecord | None: ...
    def query(self, tenant_id: str, kind: PrimitiveKind | None = None, tag: str | None = None, limit: int = 100) -> list[PrimitiveRecord]: ...


class InMemoryOntologyStore:
    def __init__(self) -> None:
        self._records: dict[str, PrimitiveRecord] = {}

    def save(self, record: PrimitiveRecord) -> None:
        self._records[record.primitive_id] = record

    def get(self, primitive_id: str) -> PrimitiveRecord | None:
        return self._records.get(primitive_id)

    def query(self, tenant_id: str, kind: PrimitiveKind | None = None, tag: str | None = None, limit: int = 100) -> list[PrimitiveRecord]:
        results = [r for r in self._records.values() if r.tenant_id == tenant_id]
        if kind:
            results = [r for r in results if r.kind == kind]
        if tag:
            results = [r for r in results if tag in r.tags]
        return results[:limit]


class PortableOntologyStore:
    """PortableStore-backed ontology store for durable production paths."""

    _SK_PREFIX = "ONTOLOGY#"

    def __init__(self, store: Any | None = None) -> None:
        if store is None:
            from apps.backend.providers.portable_store import create_portable_store

            store = create_portable_store("ontology")
        self._store = store

    def save(self, record: PrimitiveRecord) -> None:
        self._store.put_item(
            f"TENANT#{record.tenant_id}",
            f"{self._SK_PREFIX}{record.primitive_id}",
            record.model_dump(mode="json"),
        )

    def get(self, primitive_id: str) -> PrimitiveRecord | None:
        raise NotImplementedError("PortableOntologyStore.get requires tenant context; use query for tenant-scoped reads")

    def get_for_tenant(self, tenant_id: str, primitive_id: str) -> PrimitiveRecord | None:
        raw = self._store.get_item(f"TENANT#{tenant_id}", f"{self._SK_PREFIX}{primitive_id}")
        return PrimitiveRecord.model_validate(raw) if raw else None

    def query(self, tenant_id: str, kind: PrimitiveKind | None = None, tag: str | None = None, limit: int = 100) -> list[PrimitiveRecord]:
        records: list[PrimitiveRecord] = []
        start_after_sk: str | None = None
        page_size = max(100, min(max(limit, 1) * 5, 500))
        while len(records) < limit:
            rows = self._store.query(
                f"TENANT#{tenant_id}",
                self._SK_PREFIX,
                limit=page_size,
                start_after_sk=start_after_sk,
            )
            if not rows:
                break
            for row in rows:
                record = PrimitiveRecord.model_validate(row)
                if kind and record.kind != kind:
                    continue
                if tag and tag not in record.tags:
                    continue
                records.append(record)
                if len(records) >= limit:
                    break
            start_after_sk = str(rows[-1].get("sk") or "")
            if len(rows) < page_size or not start_after_sk:
                break
        return records[:limit]


class PrimitiveOntology:
    """Unified read-model over all primitive types."""

    def __init__(self, store: OntologyStore) -> None:
        self._store = store

    def register(self, record: PrimitiveRecord) -> None:
        self._store.save(record)

    def get(self, primitive_id: str) -> PrimitiveRecord | None:
        return self._store.get(primitive_id)

    def query(self, tenant_id: str, kind: PrimitiveKind | None = None, tag: str | None = None, limit: int = 100) -> list[PrimitiveRecord]:
        return self._store.query(tenant_id, kind, tag, limit)

    def query_nodes(self, tenant_id: str, q: str = "", kind: PrimitiveKind | None = None, limit: int = 100) -> OntologyQueryResponse:
        tokens = _search_tokens(q)
        scan_limit = max(limit, _TEXT_QUERY_SCAN_LIMIT) if tokens else limit
        records = self.query(tenant_id, kind=kind, limit=scan_limit)
        if tokens:
            records = [
                record
                for record in records
                if tokens
                & _search_tokens(
                    " ".join(
                        [
                            record.primitive_id,
                            record.name,
                            record.description,
                            " ".join(record.tags),
                            " ".join((record.metadata or {}).values()),
                            " ".join(record.refs.values()),
                        ]
                    )
                )
            ]
        return OntologyQueryResponse(
            tenant_id=tenant_id,
            matches=[record_to_node(record) for record in records[:limit]],
            consulted_sources=["primitive_ontology"],
        )

    def list_skills(self, tenant_id: str) -> list[PrimitiveRecord]:
        return self.query(tenant_id, kind=PrimitiveKind.SKILL)

    def list_scheduled_jobs(self, tenant_id: str) -> list[PrimitiveRecord]:
        return self.query(tenant_id, kind=PrimitiveKind.SCHEDULED_JOB)


def record_to_node(record: PrimitiveRecord) -> OntologyNode:
    return OntologyNode(
        node_id=record.primitive_id,
        tenant_id=record.tenant_id,
        kind=record.kind,
        name=record.name,
        refs=record.refs or {},
        description=record.description,
        tags=sorted(record.tags),
    )


def entity_schema_to_record(descriptor: Any) -> PrimitiveRecord:
    entity_name = str(getattr(descriptor, "entity_name", "") or "")
    tenant_id = str(getattr(descriptor, "tenant_id", "") or "")
    return PrimitiveRecord(
        primitive_id=f"entity_schema:{entity_name}",
        tenant_id=tenant_id,
        kind=PrimitiveKind.ENTITY_SCHEMA,
        name=entity_name,
        description=f"Entity schema {entity_name}",
        tags=frozenset({"entity_schema", str(getattr(descriptor, "data_classification", "") or "").lower()}),
        metadata={
            "data_classification": str(getattr(descriptor, "data_classification", "") or ""),
            "version": str(getattr(descriptor, "version", "") or ""),
        },
        refs={"dynamic_entity_registry": entity_name},
        created_at=getattr(descriptor, "created_at", None) or datetime.now(UTC),
    )


def governed_entity_schema_to_record(schema: Any) -> PrimitiveRecord:
    name = str(getattr(schema, "name", "") or "")
    tenant_id = str(getattr(schema, "tenant_id", "") or "")
    status = str(getattr(schema, "status", "") or "")
    dcl = str(getattr(schema, "dcl", "") or "")
    return PrimitiveRecord(
        primitive_id=f"entity_schema:{name}:v{getattr(schema, 'version', '')}",
        tenant_id=tenant_id,
        kind=PrimitiveKind.ENTITY_SCHEMA,
        name=name,
        description=str(getattr(schema, "description", "") or f"Entity schema {name}"),
        tags=frozenset({"entity_schema", status, dcl.lower()}),
        metadata={
            "dcl": dcl,
            "status": status,
            "approval_state": str(getattr(schema, "approval_state", "") or ""),
            "version": str(getattr(schema, "version", "") or ""),
            "owner": str(getattr(schema, "owner", "") or ""),
            "field_count": str(len(getattr(schema, "fields", []) or [])),
            "relationship_count": str(len(getattr(schema, "relationships", []) or [])),
        },
        refs={"entity_schema_registry": name},
        created_at=getattr(schema, "created_at", None) or datetime.now(UTC),
    )


def entity_instance_to_record(record: Any) -> PrimitiveRecord:
    schema_name = str(getattr(record, "schema_name", "") or "")
    record_id = str(getattr(record, "record_id", "") or "")
    tenant_id = str(getattr(record, "tenant_id", "") or "")
    schema_version = str(getattr(record, "schema_version", "") or "")
    fields = getattr(record, "fields", {}) or {}
    field_text = " ".join(str(value) for value in fields.values() if value is not None)
    return PrimitiveRecord(
        primitive_id=f"entity_instance:{schema_name}:v{schema_version}:{record_id}",
        tenant_id=tenant_id,
        kind=PrimitiveKind.ENTITY_INSTANCE,
        name=record_id,
        description=f"{schema_name} record {record_id} {field_text}".strip(),
        tags=frozenset({"entity_instance", schema_name.lower()}),
        metadata={
            "schema_name": schema_name,
            "schema_version": schema_version,
            "record_id": record_id,
            "field_count": str(len(fields)),
        },
        refs={
            "entity_instance_service": record_id,
            "entity_schema_registry": schema_name,
        },
        created_at=_parse_datetime(getattr(record, "created_at", None)) or datetime.now(UTC),
    )


def capability_registry_row_to_record(row: Any, tenant_id: str) -> PrimitiveRecord:
    capability_id = str(getattr(row, "capability_id", "") or "")
    return PrimitiveRecord(
        primitive_id=f"capability:{capability_id}",
        tenant_id=tenant_id,
        kind=PrimitiveKind.CAPABILITY,
        name=capability_id,
        description=str(getattr(row, "description", "") or ""),
        tags=frozenset(
            {
                "capability",
                str(getattr(row, "family", "") or ""),
                str(getattr(row, "action", "") or ""),
                str(getattr(row, "contract_id", "") or "").lower(),
            }
        ),
        metadata={
            "family": str(getattr(row, "family", "") or ""),
            "action": str(getattr(row, "action", "") or ""),
            "owner": str(getattr(row, "owner", "") or ""),
        },
        refs={"capability_registry": capability_id},
        created_at=datetime.now(UTC),
    )


def repo_skill_catalog_entry_to_record(entry: Any, tenant_id: str) -> PrimitiveRecord:
    name = str(getattr(entry, "name", "") or "")
    return PrimitiveRecord(
        primitive_id=f"skill:{name}",
        tenant_id=tenant_id,
        kind=PrimitiveKind.SKILL,
        name=name,
        description=str(getattr(entry, "purpose", "") or ""),
        tags=frozenset({"skill", str(getattr(entry, "category", "") or ""), str(getattr(entry, "status", "") or "")}),
        metadata={"category": str(getattr(entry, "category", "") or ""), "status": str(getattr(entry, "status", "") or "")},
        refs={"repo_skill_catalog": str(getattr(entry, "path", "") or name)},
        created_at=datetime.now(UTC),
    )


def _search_tokens(value: str) -> set[str]:
    return {token for token in re.findall(r"[a-z0-9]+", str(value or "").lower()) if token}


def _parse_datetime(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value
    if isinstance(value, str) and value:
        try:
            return datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            return None
    return None
