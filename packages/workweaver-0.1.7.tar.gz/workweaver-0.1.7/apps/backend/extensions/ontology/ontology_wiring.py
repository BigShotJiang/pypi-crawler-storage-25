"""OntologyWiring — wire OntologyQueryService into planners (#1518)."""

from __future__ import annotations

from datetime import UTC, datetime
from enum import Enum
from typing import Protocol, runtime_checkable

from pydantic import BaseModel, ConfigDict


class ConsumerKind(str, Enum):
    BLOCK_PLANNER = "block_planner"
    COLLABORATIVE_PLANNER = "collaborative_planner"
    ZARA_EXECUTOR = "zara_executor"


class ConsultLog(BaseModel):
    model_config = ConfigDict(frozen=True)
    log_id: str
    tenant_id: str
    consumer: ConsumerKind
    query: str
    results_count: int
    reused: bool
    timestamp: datetime


@runtime_checkable
class WiringStore(Protocol):
    def save_log(self, log: ConsultLog) -> None: ...
    def get_logs(self, tenant_id: str, consumer: ConsumerKind | None = None, limit: int = 50) -> list[ConsultLog]: ...


class InMemoryWiringStore:
    def __init__(self) -> None:
        self._logs: list[ConsultLog] = []

    def save_log(self, log: ConsultLog) -> None:
        self._logs.append(log)

    def get_logs(self, tenant_id: str, consumer: ConsumerKind | None = None, limit: int = 50) -> list[ConsultLog]:
        results = [entry for entry in self._logs if entry.tenant_id == tenant_id]
        if consumer:
            results = [entry for entry in results if entry.consumer == consumer]
        return results[-limit:]


class OntologyWiring:
    """Tracks ontology consult calls from planners — reuse-before-new contract."""

    def __init__(self, store: WiringStore) -> None:
        self._store = store

    def consult(self, log_id: str, tenant_id: str, consumer: ConsumerKind, query: str, results_count: int, reused: bool) -> ConsultLog:
        log = ConsultLog(log_id=log_id, tenant_id=tenant_id, consumer=consumer, query=query, results_count=results_count, reused=reused, timestamp=datetime.now(UTC))
        self._store.save_log(log)
        return log

    def get_logs(self, tenant_id: str, consumer: ConsumerKind | None = None, limit: int = 50) -> list[ConsultLog]:
        return self._store.get_logs(tenant_id, consumer, limit)

    def reuse_ratio(self, tenant_id: str) -> float:
        logs = self._store.get_logs(tenant_id, limit=1000)
        if not logs:
            return 0.0
        return sum(1 for entry in logs if entry.reused) / len(logs)
