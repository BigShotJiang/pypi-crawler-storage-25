"""Managed Lambda handler for the canonical backend app.

The managed public edge uses the same FastAPI app as ECS, with a route filter
that fails closed on stateful and realtime paths not yet migrated to the
serverless edge. Before importing the app, this handler hydrates the
secret-backed env vars that ECS used to inject at task startup so the canonical
backend code can run unchanged.
"""

from __future__ import annotations

import json
import os
from copy import deepcopy
from typing import Any

try:
    from apps.backend.config.managed_serverless_routes import (
        is_included_managed_serverless_route,
    )
    from apps.backend.providers.managed_runtime_secret_env import hydrate_managed_runtime_secret_env
except ImportError:  # pragma: no cover - Lambda zip root import path
    from config.managed_serverless_routes import is_included_managed_serverless_route  # type: ignore[no-redef]
    from providers.managed_runtime_secret_env import hydrate_managed_runtime_secret_env  # type: ignore[no-redef]


def _build_404_response(path: str, method: str) -> dict[str, Any]:
    """Return a 404 for paths not served by the managed serverless handler."""
    return {
        "statusCode": 404,
        "headers": {"content-type": "application/json"},
        "body": json.dumps(
            {
                "detail": "Not Found",
                "reason": f"{method} {path} is not served by the managed serverless handler",
            }
        ),
    }


def _build_cors_response(origin: str) -> dict[str, Any]:
    """Return CORS preflight for OPTIONS requests on included routes."""
    headers: dict[str, str] = {
        "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, PATCH, OPTIONS",
        "Access-Control-Allow-Headers": "content-type, authorization, x-tenant-id, x-request-id, x-amz-date, x-api-key",
        "Access-Control-Allow-Credentials": "true",
        "Access-Control-Max-Age": "86400",
    }
    if origin:
        headers["Access-Control-Allow-Origin"] = origin
    return {"statusCode": 200, "headers": headers, "body": ""}


def _normalized_request_path(event: dict[str, Any]) -> str:
    """Return the canonical app path, stripping any API Gateway stage prefix."""
    request_context = (event.get("requestContext") or {})
    http_ctx = request_context.get("http") or {}
    raw_path = http_ctx.get("path", "/") or "/"
    stage = request_context.get("stage") or ""

    if not stage or stage == "$default":
        return raw_path

    stage_prefix = f"/{stage}"
    if raw_path == stage_prefix:
        return "/"
    if raw_path.startswith(f"{stage_prefix}/"):
        return raw_path[len(stage_prefix) :]
    return raw_path


def _normalized_event(event: dict[str, Any]) -> dict[str, Any]:
    """Return a shallow-normalized API Gateway event for Mangum/FastAPI."""
    normalized_path = _normalized_request_path(event)
    normalized = deepcopy(event)
    normalized["rawPath"] = normalized_path

    request_context = normalized.setdefault("requestContext", {})
    http_ctx = request_context.setdefault("http", {})
    http_ctx["path"] = normalized_path

    return normalized


# Lazy-load Mangum + app to keep import fast when only the route helpers are needed.
_mangum_handler: Any = None
_mangum_loaded: bool = False
_mangum_init_error: str | None = None

# CORS origin allowlist: loaded from ALLOWED_ORIGINS env var with a hardcoded
# fallback for the production domain set.
_DEFAULT_ORIGINS = frozenset(
    {
        "https://workweaver.ai",
        "https://www.workweaver.ai",
        "https://admin.workweaver.ai",
        "https://infra.workweaver.ai",
        "https://www.infra.workweaver.ai",
    }
)

_raw = __import__("os").environ.get("ALLOWED_ORIGINS", "").strip()
# Treat "*" and empty as "use defaults" — same semantics as main.py.
_LAMBDA_ALLOWED_ORIGINS: frozenset[str] = (
    frozenset(o.strip() for o in _raw.split(",") if o.strip()) if _raw and _raw != "*" else _DEFAULT_ORIGINS
)

_MEMBER_INTAKE_CONTINUATION_ACTION = "dispatch_member_intake"


def _handle_member_intake_continuation(event: dict[str, Any]) -> dict[str, Any]:
    """Drain durable member intake work from an async Lambda continuation."""

    hydrate_managed_runtime_secret_env()
    os.environ.setdefault("AWS_LAMBDA_FUNCTION_NAME", str(event.get("function_name") or "managed-continuation"))

    import asyncio

    from apps.backend.services.zara.zara_intake_service import get_zara_intake_service

    workspace_id = str(event.get("workspace_id") or "").strip()
    channel = str(event.get("channel") or "slack").strip().lower()
    limit = int(event.get("limit") or 10)
    if not workspace_id:
        return {
            "statusCode": 400,
            "body": json.dumps({"ok": False, "reason": "workspace_id required"}),
        }
    if channel != "slack":
        return {
            "statusCode": 400,
            "body": json.dumps({"ok": False, "reason": f"unsupported member intake channel: {channel}"}),
        }

    result = asyncio.run(get_zara_intake_service().dispatch_queued_intake(workspace_id=workspace_id, limit=limit))
    return {
        "statusCode": 200,
        "headers": {"content-type": "application/json"},
        "body": json.dumps({"ok": True, "action": _MEMBER_INTAKE_CONTINUATION_ACTION, "result": result}),
    }


def _ensure_mangum() -> Any:
    global _mangum_handler, _mangum_loaded, _mangum_init_error
    if _mangum_loaded:
        return _mangum_handler
    try:
        hydrate_managed_runtime_secret_env()
        from mangum import Mangum
        from apps.backend.main import app  # noqa: F811

        _mangum_handler = Mangum(app, lifespan="auto", api_gateway_base_path="/edge")
        _mangum_init_error = None
    except Exception as exc:  # noqa: BLE001 — log all failures, not just ImportError
        import logging

        logging.getLogger(__name__).error("Failed to initialize Mangum handler: %s", exc)
        _mangum_handler = None
        _mangum_init_error = f"{type(exc).__name__}: {exc}"
    _mangum_loaded = True
    return _mangum_handler


def lambda_handler(event: dict[str, Any], context: Any) -> dict[str, Any]:
    """Lambda entrypoint — route-filtered Mangum adapter for the canonical app."""

    _ = context  # unused but required by Lambda signature
    if event.get("workweaver_action") == _MEMBER_INTAKE_CONTINUATION_ACTION:
        return _handle_member_intake_continuation(event)

    http_ctx = (event.get("requestContext") or {}).get("http") or {}
    path = _normalized_request_path(event)
    method: str = http_ctx.get("method", "GET").upper()
    headers = event.get("headers") or {}
    origin: str = headers.get("origin", headers.get("Origin", ""))

    path_is_included = is_included_managed_serverless_route(path, "OPTIONS" if method == "OPTIONS" else method)

    if not path_is_included:
        return _build_404_response(path, method)

    # For OPTIONS on included paths, handle CORS directly for speed.
    if method == "OPTIONS":
        if origin and origin not in _LAMBDA_ALLOWED_ORIGINS:
            return {"statusCode": 403, "body": "Origin not allowed"}
        return _build_cors_response(origin)

    # --- Delegate to Mangum-wrapped canonical app ---
    handler = _ensure_mangum()
    if handler is None:
        return {
            "statusCode": 500,
            "headers": {"content-type": "application/json"},
            "body": json.dumps(
                {
                    "detail": "Managed public edge failed to initialize",
                    "reason": _mangum_init_error or "unknown initialization error",
                }
            ),
        }
    return handler(_normalized_event(event), context)
