"""Health Watchdog — detection and reporting of stuck/zombie processes.

Tracks:
- Stuck sessions: no progress for >10 minutes
- Zombie executors: executors that have not reported completion
- Memory usage: process RSS via ``resource`` module (no psutil dependency)
- Registered health checks: arbitrary callables that return (healthy, detail)

Exposes a ``/api/v1/health/detailed`` compatible report via ``get_report()``.

Auto-recovery is wired through
``apps.backend.services.runtime_supervisor.RuntimeSupervisor``. The watchdog
owns detection only; :meth:`HealthWatchdog.run_supervision` (also invoked
automatically at the end of :meth:`HealthWatchdog.get_report` for affected
tenants) turns detection signals into bounded remediation actions. The
remediation layer is best-effort and never mutates the detection contract.
"""

from __future__ import annotations

import logging
import time
from dataclasses import dataclass, field
from typing import Any
from collections.abc import Callable

logger = logging.getLogger(__name__)

try:
    import resource
except ImportError:  # pragma: no cover - exercised on Windows.
    resource = None  # type: ignore[assignment]

_STUCK_SESSION_THRESHOLD_SECONDS = 600  # 10 minutes
_ZOMBIE_EXECUTOR_THRESHOLD_SECONDS = 600  # 10 minutes


@dataclass
class TrackedSession:
    """A session being monitored for progress."""

    session_id: str
    tenant_id: str
    started_at: float = field(default_factory=time.monotonic)
    last_progress_at: float = field(default_factory=time.monotonic)
    description: str = ""

    def record_progress(self) -> None:
        """Record that this session made progress."""
        self.last_progress_at = time.monotonic()

    def is_stuck(self, threshold: float = _STUCK_SESSION_THRESHOLD_SECONDS) -> bool:
        """Return True if no progress recorded within threshold seconds."""
        return (time.monotonic() - self.last_progress_at) > threshold


@dataclass
class TrackedExecutor:
    """An executor being monitored for completion."""

    executor_id: str
    tenant_id: str
    started_at: float = field(default_factory=time.monotonic)
    task_description: str = ""

    def is_zombie(self, threshold: float = _ZOMBIE_EXECUTOR_THRESHOLD_SECONDS) -> bool:
        """Return True if the executor has not completed within threshold."""
        return (time.monotonic() - self.started_at) > threshold


HealthCheckFn = Callable[[], tuple[bool, str]]


class HealthWatchdog:
    """Centralized health monitoring with stuck/zombie detection.

    Usage::

        watchdog = get_health_watchdog()
        watchdog.register_session("sess-123", "TENANT#ABC")
        watchdog.record_session_progress("sess-123")

        # Periodic check
        report = watchdog.get_report()
    """

    def __init__(self) -> None:
        self._sessions: dict[str, TrackedSession] = {}
        self._executors: dict[str, TrackedExecutor] = {}
        self._health_checks: dict[str, HealthCheckFn] = {}

    # -- Session tracking ---------------------------------------------------

    def register_session(
        self,
        session_id: str,
        tenant_id: str,
        description: str = "",
    ) -> None:
        """Start tracking a session for stuck detection."""
        self._sessions[session_id] = TrackedSession(
            session_id=session_id,
            tenant_id=tenant_id,
            description=description,
        )

    def record_session_progress(self, session_id: str) -> None:
        """Record progress for a tracked session."""
        session = self._sessions.get(session_id)
        if session is not None:
            session.record_progress()

    def unregister_session(self, session_id: str) -> None:
        """Stop tracking a session (completed or cancelled)."""
        self._sessions.pop(session_id, None)

    def get_stuck_sessions(self) -> list[TrackedSession]:
        """Return all sessions that are stuck (no progress for >10min)."""
        return [s for s in self._sessions.values() if s.is_stuck()]

    # -- Executor tracking --------------------------------------------------

    def register_executor(
        self,
        executor_id: str,
        tenant_id: str,
        task_description: str = "",
    ) -> None:
        """Start tracking an executor for zombie detection."""
        self._executors[executor_id] = TrackedExecutor(
            executor_id=executor_id,
            tenant_id=tenant_id,
            task_description=task_description,
        )

    def unregister_executor(self, executor_id: str) -> None:
        """Stop tracking an executor (completed)."""
        self._executors.pop(executor_id, None)

    def get_zombie_executors(self) -> list[TrackedExecutor]:
        """Return all executors that appear to be zombies."""
        return [e for e in self._executors.values() if e.is_zombie()]

    # -- Health check registration ------------------------------------------

    def register_check(self, name: str, check_fn: HealthCheckFn) -> None:
        """Register a named health check callable.

        The callable should return (is_healthy: bool, detail: str).
        """
        self._health_checks[name] = check_fn

    def unregister_check(self, name: str) -> None:
        """Remove a registered health check."""
        self._health_checks.pop(name, None)

    # -- Memory usage -------------------------------------------------------

    @staticmethod
    def get_memory_usage_mb() -> float:
        """Return current process RSS in megabytes (using resource module)."""
        if resource is None:
            return 0.0
        # resource.getrusage returns ru_maxrss in bytes on macOS, KB on Linux
        import platform

        usage = resource.getrusage(resource.RUSAGE_SELF)
        if platform.system() == "Darwin":
            return usage.ru_maxrss / (1024 * 1024)
        return usage.ru_maxrss / 1024

    # -- Report -------------------------------------------------------------

    def get_report(self) -> dict[str, Any]:
        """Generate a detailed health report for the /api/v1/health/detailed endpoint.

        Returns a dict with:
        - status: "healthy" | "degraded" | "unhealthy"
        - stuck_sessions: list of stuck session details
        - zombie_executors: list of zombie executor details
        - memory_mb: current RSS in MB
        - active_sessions: total tracked sessions
        - active_executors: total tracked executors
        - checks: results of registered health checks
        """
        stuck = self.get_stuck_sessions()
        zombies = self.get_zombie_executors()
        memory_mb = self.get_memory_usage_mb()

        # Run registered health checks
        check_results: dict[str, dict[str, Any]] = {}
        checks_healthy = True
        for name, fn in self._health_checks.items():
            try:
                healthy, detail = fn()
                check_results[name] = {"healthy": healthy, "detail": detail}
                if not healthy:
                    checks_healthy = False
            except Exception as exc:
                check_results[name] = {"healthy": False, "detail": f"Check failed: {exc}"}
                checks_healthy = False

        # Determine overall status
        if stuck or zombies or not checks_healthy:
            status = "degraded"
        else:
            status = "healthy"

        # Memory threshold: warn above 512MB
        if memory_mb > 512:
            status = "degraded"

        now = time.monotonic()
        report: dict[str, Any] = {
            "status": status,
            "active_sessions": len(self._sessions),
            "active_executors": len(self._executors),
            "memory_mb": round(memory_mb, 2),
            "stuck_sessions": [
                {
                    "session_id": s.session_id,
                    "tenant_id": s.tenant_id,
                    "description": s.description,
                    "stuck_for_seconds": round(now - s.last_progress_at, 1),
                }
                for s in stuck
            ],
            "zombie_executors": [
                {
                    "executor_id": e.executor_id,
                    "tenant_id": e.tenant_id,
                    "task_description": e.task_description,
                    "running_for_seconds": round(now - e.started_at, 1),
                }
                for e in zombies
            ],
            "checks": check_results,
        }

        if status != "healthy":
            logger.warning(
                "Health watchdog detected issues: status=%s stuck=%d zombies=%d memory=%.1fMB",
                status,
                len(stuck),
                len(zombies),
                memory_mb,
            )
            # Best-effort: trigger structural remediation for every tenant
            # that has a pending issue. Failures inside the supervisor must
            # never affect the detection report contract.
            affected_tenants = {s.tenant_id for s in stuck} | {
                e.tenant_id for e in zombies
            }
            for tenant_id in affected_tenants:
                self._invoke_supervisor(tenant_id)

        return report

    # -- Remediation hook ---------------------------------------------------

    def run_supervision(self, tenant_id: str) -> list[Any]:
        """Run one supervision tick for ``tenant_id``.

        Delegates to :class:`RuntimeSupervisor` to translate detection
        signals into bounded remediation actions. Best-effort: swallows any
        exception and returns an empty list so the watchdog never crashes.
        """
        return self._invoke_supervisor(tenant_id)

    def _invoke_supervisor(self, tenant_id: str) -> list[Any]:
        try:
            # Import here to avoid circular imports at module load time
            # (runtime_supervisor imports the watchdog for type hints).
            from apps.backend.services.runtime.runtime_supervisor import (
                get_runtime_supervisor,
            )

            return list(get_runtime_supervisor().run_supervision_tick(tenant_id))
        except Exception:
            logger.debug(
                "health_watchdog.supervision_failed tenant_id=%s",
                tenant_id,
                exc_info=True,
            )
            return []


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_watchdog: HealthWatchdog | None = None


def get_health_watchdog() -> HealthWatchdog:
    """Return the shared HealthWatchdog singleton."""
    global _watchdog  # noqa: PLW0603
    if _watchdog is None:
        _watchdog = HealthWatchdog()
    return _watchdog
