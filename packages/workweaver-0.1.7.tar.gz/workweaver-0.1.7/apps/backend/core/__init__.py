"""Backend core utilities — cross-cutting concerns like circuit breakers."""
