#!/usr/bin/env python3
"""
Backchannel Audio Generator

Purpose: Generate backchannel audio files using AWS Polly for multi-language support

Legacy requirement reference: P1.3.4 — Real-Time Acknowledgement (Backchannel Layer)

Usage:
    python generate_backchannels.py --language en --bucket short
    python generate_backchannels.py --all  # Generate all languages and buckets

Requirements:
    pip install boto3

Environment:
    AWS credentials must be configured (aws sso login --profile workweaver-prod-admin)
"""

import argparse
import json
import sys
from pathlib import Path
from typing import Any

import boto3
from botocore.exceptions import BotoCoreError, ClientError


# Add parent directory to path for imports
sys.path.insert(0, str(Path(__file__).parent.parent.parent))

from config.logging_config import get_logger

logger = get_logger(__name__)


# Backchannel phrases by language and timing bucket
# Source: docs/PRODUCT.md P1.3.4
BACKCHANNEL_PHRASES: dict[str, dict[str, list[str]]] = {
    "en": {
        "short": [
            "Okaaay... gotcha.",
            "Mm-hmm... sure.",
            "Alrighty... yep.",
            "Ahh... I hear you.",
            "Yup... one sec.",
            "Right... understood.",
        ],
        "medium": [
            "Okay okay... let me see.",
            "Got it... just checking.",
            "Alright... give me a moment.",
            "Mhmm... I'm on it now.",
            "Okay... pulling that up.",
            "Sure... let me confirm.",
        ],
        "long": [
            "Alright... I'm just checking the options.",
            "Okay... I'm looking at the latest details.",
            "Gotcha... I'm verifying that right now.",
            "Mm-hmm... let me quickly confirm availability.",
            "Alright... I'm checking what fits best.",
            "Okay... let me line that up for you.",
        ],
        "extended": [
            "One moment—I'm checking the available listings now.",
            "Give me a bit—I'm matching this with the latest options.",
            "Just a moment—I'm confirming the best slot for you.",
            "Hang tight—I'm pulling the exact details so it's accurate.",
            "Okay—I'm double-checking so I don't misguide you.",
            "Alright—let me verify and I'll tell you clearly.",
        ],
    },
    "ar": {
        "short": [
            "تمامم… أوكي.",
            "إيه… فهمت.",
            "ممم… حاضر.",
            "زين… لحظة.",
            "أوكي… سمعك.",
            "صح… تمام.",
        ],
        "medium": [
            "تمام… خلّني أشوف.",
            "أوكي… ثواني بس.",
            "حاضر… دقيقة واحدة.",
            "زين… بأتأكد الحين.",
            "تمام… بس أشيّك.",
            "أوكي… خلّني أراجع.",
        ],
        "long": [
            "تمام… قاعد أشوف لك الخيارات الأنسب.",
            "أوكي… بأطلع لك التفاصيل الحين.",
            "حاضر… بأتأكد من التوفر بسرعة.",
            "زين… خلّني أرتّبها لك شوي.",
            "تمام… بأراجع آخر المعلومات.",
            "أوكي… دقيقة وبعطيك الرد.",
        ],
        "extended": [
            "ثواني—قاعد أشيّك على آخر العروض عشان تكون دقيقة.",
            "لحظة—أبي أتأكد من التفاصيل قبل ما أقول لك.",
            "دقيقة—قاعد أطلع لك الخيارات المتاحة الأنسب.",
            "خلّني أتأكد—أفضّل أعطيك معلومة صحيحة مو سريعة.",
            "اصبر شوي—قاعد أراجع التوفر والوقت المناسب.",
            "تمام—قاعد أرتّب لك الرد وبقول لك بكل وضوح.",
        ],
    },
    "hi": {
        "short": [
            "Haan… samjha.",
            "Acchaa… theek.",
            "Hmm… boliye.",
            "Arre… haan.",
            "Theek hai… haan.",
            "Acha… got it.",
        ],
        "medium": [
            "Haan haan… ek sec.",
            "Theek… main dekh raha.",
            "Accha… bas check karta.",
            "Haan… abhi confirm.",
            "Hmm… ek minute.",
            "Theek… main nikaal raha.",
        ],
        "long": [
            "Theek hai… main options dekh raha hoon.",
            "Haan… availability jaldi check karta hoon.",
            "Accha… latest details dekh leta hoon.",
            "Theek… main verify karke batata.",
            "Haan… main abhi match kar raha.",
            "Accha… thoda sa rukna.",
        ],
        "extended": [
            "Ek minute—main available listings check kar raha hoon.",
            "Thoda rukna—main sahi details nikaal raha hoon.",
            "Bas ek moment—main confirm karke hi bolunga.",
            "Haan—main options compare karke best bata raha.",
            "Theek hai—main latest info pull kar raha hoon.",
            "Ruk jao—main abhi proper verify kar raha.",
        ],
    },
    "ta": {
        "short": [
            "சரீ… ஓகே.",
            "ஆமா… புரிஞ்சுது.",
            "ம்ம்ம்… சொல்லுங்க.",
            "அப்படியா… ஓகே.",
            "சரி… கேக்குது.",
            "ஓ… சரி.",
        ],
        "medium": [
            "சரி… ஒரு செக் பண்ணுறேன்.",
            "ஓகே… ஒரு நிமிஷம்.",
            "ஆமா… இப்போ பார்த்துட்டேன்.",
            "சரி… கொஞ்சம் நேரம்.",
            "ம்ம்ம்… ஒரு செக்கண்ட்.",
            "ஓகே… இப்போ confirm.",
        ],
        "long": [
            "சரி… options எல்லாம் பார்த்து சொல்றேன்.",
            "ஆமா… availability சீக்கிரம் செக் பண்ணுறேன்.",
            "சரி… details எடுத்துக்கிட்டு வர்றேன்.",
            "ஓகே… verify பண்ணி சொல்றேன்.",
            "ம்ம்ம்… latest info பாக்குறேன்.",
            "சரி… கொஞ்சம் wait பண்ணுங்க.",
        ],
        "extended": [
            "ஒரு நிமிஷம்—available listings எல்லாம் பார்த்துட்டு சொல்றேன்.",
            "கொஞ்சம் நேரம்—சரியா verify பண்ணிட்டு பதில் சொல்றேன்.",
            "சரி—details எல்லாம் எடுத்துட்டு தெளிவா சொல்றேன்.",
            "ஒரு moment—options compare பண்ணிட்டு best சொல்றேன்.",
            "காத்திருங்க—latest info pull பண்ணுறேன்.",
            "சரி—உங்குக்கு சரியான தகவல் தான் சொல்லணும், அதான் செக் பண்ணுறேன்.",
        ],
    },
    "ml": {  # Malayalam - Google TTS only
        "short": [
            "ശരി… മനസ്സിലായി.",
            "മം… തീർച്ചയം.",
            "കേട്ടു… ശരി.",
            "അതെ… ഓകേ.",
            "ശരി… ഒരു നിമിഷം.",
            "മനസ്സിലായി… ശരി.",
        ],
        "medium": [
            "ശരി… ഒന്നു നോക്കാം.",
            "മനസ്സിലായി… ഇപ്പോൾ പരിശോധിക്കുന്നു.",
            "ഓകേ… ഒരു നിമിഷം.",
            "മം… ഇപ്പോൾ ചെയ്യുന്നു.",
            "ശരി… ഒന്നു കാത്തിരിക്കു.",
            "തീർച്ചയം… ഉറപ്പുള്ളതാക്കുന്നു.",
        ],
        "long": [
            "ശരി… ഞാൻ ഓപ്ഷനുകൾ നോക്കുന്നു.",
            "ഓകേ… ഞാൻ ഏറ്റവും പുതിയ വിശദാംശങ്ങൾ നോക്കുന്നു.",
            "മനസ്സിലായി… ഞാൻ ഇപ്പോൾ ഉറപ്പുള്ളതാക്കുന്നു.",
            "മം… ലഭ്യത ഉറപ്പുള്ളതാക്കണം.",
            "ശരി… ഞാൻ മികച്ച ഓപ്ഷൻ നോക്കുന്നു.",
            "ഓകേ… ഞാൻ അത് നിങ്ങൾക്ക് ഒരുക്കുന്നു.",
        ],
        "extended": [
            "ഒരു നിമിഷം—ഞാൻ ലഭ്യമായ ലിസ്റ്റിംഗുകൾ നോക്കി പറയും.",
            "കുറച്ചു നേരം—ശരിയായി ഉറപ്പുള്ളതാക്കി മറുപടി പറയും.",
            "ശരി—വിശദാംശങ്ങൾ എടുത്ത് വ്യക്തമായി പറയും.",
            "ഒരു നിമിഷം—ഓപ്ഷനുകൾ തമ്മിൽ താരതമ്യം ചെയ്ത് മികച്ചത് പറയും.",
            "കാത്തിരിക്കു—ഞാൻ ഏറ്റവും പുതിയ വിവരം എടുക്കുന്നു.",
            "ശരി—നിങ്ങൾക്ക് ശരിയായ വിവരം നൽകണം, അതിനാൽ പരിശോധിക്കുന്നു.",
        ],
    },
}

# Polly voice IDs for each language
POLLY_VOICES = {
    "en": "Joanna",  # Female, warm, professional
    "ar": "Zeina",   # Female, Gulf Arabic
    "hi": "Aditi",   # Female, Hindi
    "ta": None,      # Tamil not available in Polly - use Google TTS
    "ml": None,      # Malayalam not available in Polly - use Google TTS
}

# Google Cloud TTS language codes for languages not supported by Polly
GOOGLE_TTS_LANGUAGES = {
    "ta": "ta-IN",   # Tamil
    "ml": "ml-IN",   # Malayalam
}


class BackchannelGenerator:
    """Generate backchannel audio files using AWS Polly"""

    def __init__(self, output_dir: Path, bucket: str = "workweaver-backchannels-prod-us-east-1", use_google_tts: bool = True):
        """
        Initialize the backchannel generator.

        Args:
            output_dir: Directory to save audio files
            bucket: S3 bucket name for storage
            use_google_tts: Enable Google Cloud TTS for unsupported Polly languages
        """
        self.output_dir = Path(output_dir)
        self.bucket = bucket
        self.polly = boto3.client("polly")
        self.s3 = boto3.client("s3")
        self.use_google_tts = use_google_tts

        # Initialize Google Cloud TTS client if enabled and credentials available
        self.google_tts_client: Any | None = None
        if self.use_google_tts:
            try:
                # Import Google Cloud TTS only if needed
                from google.cloud import texttospeech
                self.google_tts_client = texttospeech.TextToSpeechClient()
                logger.info("Google Cloud TTS client initialized")
            except ImportError:
                logger.warning("google-cloud-texttospeech not installed. Tamil and Malayalam will be skipped.")
                self.use_google_tts = False
            except Exception as e:
                logger.warning(f"Failed to initialize Google Cloud TTS: {e}")
                self.use_google_tts = False

        logger.info("Initialized BackchannelGenerator")
        logger.info(f"Output directory: {self.output_dir}")
        logger.info(f"S3 bucket: {self.bucket}")
        logger.info(f"Google TTS enabled: {self.use_google_tts}")

    def generate_audio(
        self, text: str, language: str, output_path: Path
    ) -> bool:
        """
        Generate audio file for a single phrase using AWS Polly or Google Cloud TTS.

        Args:
            text: Text to synthesize
            language: Language code (en, ar, hi, ta, ml)
            output_path: Path to save audio file

        Returns:
            True if successful, False otherwise
        """
        # Try AWS Polly first
        if POLLY_VOICES.get(language) is not None:
            return self._generate_with_polly(text, language, output_path)

        # Fall back to Google Cloud TTS for unsupported languages
        if language in GOOGLE_TTS_LANGUAGES and self.use_google_tts:
            return self._generate_with_google_tts(text, language, output_path)

        logger.warning(f"Language {language} not supported by any TTS engine, skipping: {text}")
        return False

    def _generate_with_polly(self, text: str, language: str, output_path: Path) -> bool:
        """Generate audio using AWS Polly"""
        try:
            voice_id = POLLY_VOICES[language]

            # Call Polly API
            response = self.polly.synthesize_speech(
                Text=text,
                OutputFormat="mp3",
                VoiceId=voice_id,
                Engine="neural",  # Use neural engine for better quality
                LanguageCode=f"{language}-{self._get_region(language)}",
            )

            # Save audio to file
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with output_path.open("wb") as f:
                f.write(response["AudioStream"].read())

            logger.info(f"Generated (Polly): {output_path.name} - '{text}'")
            return True

        except (BotoCoreError, ClientError) as e:
            logger.error(f"Error generating audio with Polly for '{text}': {e}")
            return False

    def _generate_with_google_tts(self, text: str, language: str, output_path: Path) -> bool:
        """Generate audio using Google Cloud TTS"""
        if not self.google_tts_client:
            logger.error(f"Google TTS client not initialized for language {language}")
            return False

        try:
            from google.cloud import texttospeech
            from google.cloud.texttospeech import SsmlVoiceGender

            language_code = GOOGLE_TTS_LANGUAGES[language]

            # Build the synthesis input
            synthesis_input = texttospeech.SynthesisInput(text=text)

            # Build the voice request
            voice = texttospeech.VoiceSelectionParams(
                language_code=language_code,
                ssml_gender=SsmlVoiceGender.FEMALE,
            )

            # Select the type of audio file
            audio_config = texttospeech.AudioConfig(
                audio_encoding=texttospeech.AudioEncoding.MP3,
                speaking_rate=0.9,  # Slightly slower for better clarity
            )

            # Perform the text-to-speech request
            response = self.google_tts_client.synthesize_speech(
                input=synthesis_input,
                voice=voice,
                audio_config=audio_config
            )

            # Save audio to file
            output_path.parent.mkdir(parents=True, exist_ok=True)
            with output_path.open("wb") as f:
                f.write(response.audio_content)

            logger.info(f"Generated (Google TTS): {output_path.name} - '{text}'")
            return True

        except Exception as e:
            logger.error(f"Error generating audio with Google TTS for '{text}': {e}")
            return False

    def _get_region(self, language: str) -> str:
        """Get AWS region code for language"""
        regions = {
            "en": "US",
            "ar": "SA",  # Saudi Arabia for Gulf Arabic
            "hi": "IN",
            "ta": "IN",
        }
        return regions.get(language, "US")

    def generate_all_for_language_and_bucket(
        self, language: str, bucket: str
    ) -> list[Path]:
        """
        Generate all audio files for a specific language and timing bucket.

        Args:
            language: Language code (en, ar, hi, ta)
            bucket: Timing bucket (short, medium, long, extended)

        Returns:
            List of generated file paths
        """
        generated_files = []
        phrases = BACKCHANNEL_PHRASES.get(language, {}).get(bucket, [])

        if not phrases:
            logger.warning(f"No phrases found for {language}/{bucket}")
            return generated_files

        for idx, phrase in enumerate(phrases, start=1):
            filename = f"{idx:03d}.mp3"
            output_path = self.output_dir / language / bucket / filename

            success = self.generate_audio(phrase, language, output_path)
            if success:
                generated_files.append(output_path)

        logger.info(f"Generated {len(generated_files)} files for {language}/{bucket}")
        return generated_files

    def upload_to_s3(self, file_path: Path) -> bool:
        """
        Upload audio file to S3.

        Args:
            file_path: Path to audio file

        Returns:
            True if successful, False otherwise
        """
        try:
            # S3 key: {language}/{bucket}/{filename}
            s3_key = str(file_path.relative_to(self.output_dir))

            self.s3.upload_file(
                str(file_path),
                self.bucket,
                s3_key,
                ExtraArgs={"ContentType": "audio/mpeg"},
            )

            logger.info(f"Uploaded to S3: s3://{self.bucket}/{s3_key}")
            return True

        except (BotoCoreError, ClientError) as e:
            logger.error(f"Error uploading {file_path} to S3: {e}")
            return False

    def generate_manifest(self) -> Path:
        """
        Generate manifest JSON file with all phrase metadata.

        Returns:
            Path to manifest file
        """
        manifest = {
            "version": "1.0",
            "languages": list(BACKCHANNEL_PHRASES.keys()),
            "buckets": ["short", "medium", "long", "extended"],
            "phrases": {},
            "voices": POLLY_VOICES,
        }

        for lang, buckets in BACKCHANNEL_PHRASES.items():
            manifest["phrases"][lang] = {}
            for bucket, phrases in buckets.items():
                manifest["phrases"][lang][bucket] = [
                    {"id": f"{idx:03d}", "text": phrase}
                    for idx, phrase in enumerate(phrases, start=1)
                ]

        manifest_path = self.output_dir / "manifest.json"
        with manifest_path.open("w", encoding="utf-8") as f:
            json.dump(manifest, f, indent=2, ensure_ascii=False)

        logger.info(f"Generated manifest: {manifest_path}")
        return manifest_path


def main():
    """Main entry point"""
    parser = argparse.ArgumentParser(
        description="Generate backchannel audio files using AWS Polly and Google Cloud TTS"
    )
    parser.add_argument(
        "--language",
        choices=["en", "ar", "hi", "ta", "ml"],
        help="Language code (default: all languages)",
    )
    parser.add_argument(
        "--bucket",
        choices=["short", "medium", "long", "extended"],
        help="Timing bucket (default: all buckets)",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path(__file__).parent / "audio",
        help="Output directory for audio files",
    )
    parser.add_argument(
        "--bucket-name",
        default="workweaver-backchannels-prod-us-east-1",
        help="S3 bucket name for storage",
    )
    parser.add_argument(
        "--upload",
        action="store_true",
        help="Upload generated files to S3",
    )
    parser.add_argument(
        "--all",
        action="store_true",
        help="Generate all languages and buckets",
    )
    parser.add_argument(
        "--no-google-tts",
        action="store_true",
        help="Disable Google Cloud TTS (skip Tamil and Malayalam)",
    )

    args = parser.parse_args()

    # Initialize generator
    generator = BackchannelGenerator(
        args.output_dir,
        args.bucket_name,
        use_google_tts=not args.no_google_tts
    )

    # Generate manifest
    generator.generate_manifest()

    # Determine languages and buckets to process
    languages = [args.language] if args.language else list(BACKCHANNEL_PHRASES.keys())
    buckets = [args.bucket] if args.bucket else ["short", "medium", "long", "extended"]

    # If --all flag, process all combinations
    if args.all:
        languages = list(BACKCHANNEL_PHRASES.keys())
        buckets = ["short", "medium", "long", "extended"]

    # Generate audio files
    total_generated = 0
    for lang in languages:
        for bucket in buckets:
            logger.info(f"Processing {lang}/{bucket}...")
            files = generator.generate_all_for_language_and_bucket(lang, bucket)

            # Upload to S3 if requested
            if args.upload:
                for file_path in files:
                    generator.upload_to_s3(file_path)

            total_generated += len(files)

    logger.info(f"Total files generated: {total_generated}")
    logger.info(f"Output directory: {args.output_dir}")

    if args.upload:
        logger.info(f"Files uploaded to S3 bucket: {args.bucket_name}")


if __name__ == "__main__":
    main()
