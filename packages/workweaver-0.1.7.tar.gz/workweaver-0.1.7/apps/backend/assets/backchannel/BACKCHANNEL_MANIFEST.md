# Backchannel Audio Manifest

**Purpose**: Defines all backchannel phrases for multi-language support

**Legacy requirement reference**: P1.3.4 — Real-Time Acknowledgement (Backchannel Layer)

---

## English Phrases (en)

### 1-2 seconds (Quick backchannel) - Bucket: SHORT
1. "Okaaay... gotcha."
2. "Mm-hmm... sure."
3. "Alrighty... yep."
4. "Ahh... I hear you."
5. "Yup... one sec."
6. "Right... understood."

### 2-3 seconds (Processing check) - Bucket: MEDIUM
1. "Okay okay... let me see."
2. "Got it... just checking."
3. "Alright... give me a moment."
4. "Mhmm... I'm on it now."
5. "Okay... pulling that up."
6. "Sure... let me confirm."

### 3-4 seconds (Working on it) - Bucket: LONG
1. "Alright... I'm just checking the options."
2. "Okay... I'm looking at the latest details."
3. "Gotcha... I'm verifying that right now."
4. "Mm-hmm... let me quickly confirm availability."
5. "Alright... I'm checking what fits best."
6. "Okay... let me line that up for you."

### 4-5+ seconds (Explain delay) - Bucket: EXTENDED
1. "One moment—I'm checking the available listings now."
2. "Give me a bit—I'm matching this with the latest options."
3. "Just a moment—I'm confirming the best slot for you."
4. "Hang tight—I'm pulling the exact details so it's accurate."
5. "Okay—I'm double-checking so I don't misguide you."
6. "Alright—let me verify and I'll tell you clearly."

---

## Arabic Phrases (ar) - Gulf-leaning

### Arabic SHORT (1-2 seconds)
1. "تمامم… أوكي."
2. "إيه… فهمت."
3. "ممم… حاضر."
4. "زين… لحظة."
5. "أوكي… سمعك."
6. "صح… تمام."

### Arabic MEDIUM (2-3 seconds)
1. "تمام… خلّني أشوف."
2. "أوكي… ثواني بس."
3. "حاضر… دقيقة واحدة."
4. "زين… بأتأكد الحين."
5. "تمام… بس أشيّك."
6. "أوكي… خلّني أراجع."

### Arabic LONG (3-4 seconds)
1. "تمام… قاعد أشوف لك الخيارات الأنسب."
2. "أوكي… بأطلع لك التفاصيل الحين."
3. "حاضر… بأتأكد من التوفر بسرعة."
4. "زين… خلّني أرتّبها لك شوي."
5. "تمام… بأراجع آخر المعلومات."
6. "أوكي… دقيقة وبعطيك الرد."

### Arabic EXTENDED (4-5+ seconds)
1. "ثواني—قاعد أشيّك على آخر العروض عشان تكون دقيقة."

---

## Hindi Phrases (hi)

### Hindi SHORT (1-2 seconds)
1. "ठीक है… समझ गया."
2. "हम्म… ज़रूर."
3. "ओके… एक सेकंड."
4. "सही… पता चल गया."
5. "अच्छा… सुन लिया."
6. "हाँ… ठीक है."

### Hindi MEDIUM (2-3 seconds)
1. "ठीक है… देखता हूँ."
2. "समझ गया… अभी चेक करता हूँ."
3. "ओके… एक पल दीजिए."
4. "हम्म… अभी काम कर रहा हूँ."
5. "ठीक है… अभी लाता हूँ."
6. "ज़रूर… पुष्टि करता हूँ."

### Hindi LONG (3-4 seconds)
1. "ठीक है… मैं विकल्प देख रहा हूँ."
2. "ओके… मैं नवीनतम विवरण देख रहा हूँ."
3. "समझ गया… मैं अभी पुष्टि कर रहा हूँ."
4. "हम्म… मुझे उपलब्धता की पुष्टि करनी है."
5. "ठीक है… मैं सबसे अच्छा विकल्प देख रहा हूँ."
6. "ओके… मैं इसे आपके लिए व्यवस्थित करता हूँ."

### Hindi EXTENDED (4-5+ seconds)
1. "एक पल—मैं उपलब्ध सूची देख रहा हूँ."

---

## Tamil Phrases (ta)

### Tamil SHORT (1-2 seconds)
1. "சரி… புரிந்தது."
2. "ஹம்… நிச்சயம்."
3. "ஓகே… ஒரு நொடி."
4. "சரி… தெரிந்தது."
5. "சரி… கேட்டுக்கொண்டேன்."
6. "ஆம்… சரி."

### Tamil MEDIUM (2-3 seconds)
1. "சரி… பார்க்கிறேன்."
2. "புரிந்தது… இப்போது சரிபார்க்கிறேன்."
3. "ஓகே… ஒரு தருணம்."
4. "ஹம்… இப்போது செய்கிறேன்."
5. "சரி… இப்போது கொண்டு வருகிறேன்."
6. "நிச்சயம்… உறுதிப்படுத்துகிறேன்."

### Tamil LONG (3-4 seconds)
1. "சரி… நான் விருப்பங்களைப் பார்க்கிறேன்."
2. "ஓகே… நான் சமீபத்திய விவரங்களைப் பார்க்கிறேன்."
3. "புரிந்தது… நான் இப்போது உறுதிப்படுத்துகிறேன்."
4. "ஹம்… கிடைக்கும் நேரத்தை உறுதிப்படுத்த வேண்டும்."
5. "சரி… நான் சிறந்த விருப்பத்தைத் தேடுகிறேன்."
6. "ஓகே… நான் அதை உங்களுக்கு ஏற்பாடு செய்கிறேன்."

### Tamil EXTENDED (4-5+ seconds)
1. "ஒரு தருணம்—நான் கிடைக்கும் பட்டியலைப் பார்க்கிறேன்."

---

## Audio File Naming Convention

```
{language}/{bucket}/{phrase_id:03d}.mp3
```

Examples:
- `en/short/001.mp3` - "Okaaay... gotcha."
- `ar/medium/001.mp3` - "تمام… خلّني أشوف."
- `hi/long/001.mp3` - "ठीक है… मैं विकल्प देख रहा हूँ."
- `ta/extended/001.mp3` - "ஒரு தருணம்—நான் கிடைக்கும் பட்டியலைப் பார்க்கிறேன்."

---

## TTS Generation Notes

**Recommended TTS Services:**
1. AWS Polly (neural voices)
2. Google Cloud TTS (WaveNet voices)
3. ElevenLabs (high quality)

**Voice Selection Guidelines:**
- English: "Joanna" (Polly) - Warm, professional female
- Arabic: "Zeina" (Polly) - Gulf Arabic female
- Hindi: "Aditi" (Polly) - Hindi female
- Tamil: "unknown" - May need Google Cloud TTS

**Audio Parameters:**
- Format: MP3
- Bitrate: 128kbps
- Sample Rate: 22050Hz
- Duration: Match bucket (1s, 2s, 3s, 4s)
