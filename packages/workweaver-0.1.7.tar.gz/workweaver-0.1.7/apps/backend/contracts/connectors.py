"""Connector data contracts.

Extracted from ``apps.backend.api.connectors_contracts`` so that services
(e.g. ``shared_connector_service``, ``connector_marketplace``) can import
the models without creating a services -> api dependency.
"""

from __future__ import annotations

from pydantic import BaseModel, Field

from apps.backend.models.connector_state import ConnectorState


class ConnectionCenterItem(BaseModel):
    """User-facing connector card for the canonical connection center."""

    key: str
    display_name: str
    description: str
    category: str
    auth_type: str
    state: str
    canonical_state: ConnectorState = ConnectorState.ADVANCED_SETUP
    state_reason: str = ""
    icon_url: str = ""
    documentation_url: str = ""
    connector_id: str | None = None
    connection_id: str | None = None
    integration_name: str | None = None
    verified_path: bool = False
    surfaced: bool = False
    surface_rank: int = 999
    demand_based: bool = False
    coming_soon: bool = False
    connected: bool = False
    health_state: str | None = None
    needs_reauth: bool = False
    primary_action: str
    action_label: str
    secondary_action: str | None = None
    supported_operations: list[str] = Field(default_factory=list)


class ConnectionCenterResponse(BaseModel):
    """Canonical connector-center response for runtime and onboarding."""

    surfaced: list[ConnectionCenterItem]
    all_connectors: list[ConnectionCenterItem]
    total_supported: int
    total_verified: int
