"""Agent work ledger data contracts.

Extracted from ``apps.backend.api.agent_work_ledger`` so that services
(e.g. ``calendar_density``) can import the models without creating a
services -> api dependency.
"""

from __future__ import annotations

from pydantic import BaseModel


class CalendarDensityInfo(BaseModel):
    """Calendar density metrics for the current view."""

    total_hours_available: float
    total_hours_scheduled: float
    density_percent: float
    over_capacity: bool
