"""Pagination data contracts and helpers.

Extracted from ``apps.backend.api.pagination`` so that services can use
pagination without creating a services -> api dependency.
"""

from __future__ import annotations

from collections.abc import Sequence
from typing import Any, TypeVar

from fastapi import Query
from pydantic import BaseModel

T = TypeVar("T")


class PaginationParams(BaseModel):
    limit: int
    offset: int
    page: int
    page_size: int


def paginate_items(items: Sequence[T], pagination: PaginationParams) -> tuple[list[T], int]:
    rows = list(items)
    total = len(rows)
    start = pagination.offset
    end = start + pagination.limit
    return rows[start:end], total


def paginate_limit(total_requested: int, pagination: PaginationParams) -> int:
    return pagination.offset + pagination.limit


def resolve_pagination(value: Any, *, default_limit: int = 50) -> PaginationParams:
    if isinstance(value, PaginationParams):
        return value
    return PaginationParams(
        limit=default_limit,
        offset=0,
        page=1,
        page_size=default_limit,
    )


def build_pagination_dependency(*, default_limit: int = 50, max_limit: int = 200):
    async def _pagination(
        limit: int | None = Query(default=None, ge=1, le=max_limit),
        offset: int = Query(default=0, ge=0),
        page: int | None = Query(default=None, ge=1),
        page_size: int | None = Query(default=None, ge=1, le=max_limit),
    ) -> PaginationParams:
        if page is not None or page_size is not None:
            resolved_page_size = int(page_size or limit or default_limit)
            resolved_page = int(page or 1)
            resolved_offset = (resolved_page - 1) * resolved_page_size
            return PaginationParams(
                limit=resolved_page_size,
                offset=resolved_offset,
                page=resolved_page,
                page_size=resolved_page_size,
            )

        resolved_limit = int(limit or default_limit)
        resolved_offset = int(offset)
        return PaginationParams(
            limit=resolved_limit,
            offset=resolved_offset,
            page=(resolved_offset // resolved_limit) + 1,
            page_size=resolved_limit,
        )

    return _pagination
