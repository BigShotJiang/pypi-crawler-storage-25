"""Zara data contracts.

Extracted from ``apps.backend.api.zara.models`` so that services (e.g.
zara_intake_service) can use planning request models without creating
a services -> api dependency.

Issue #3785.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, Field


class PlanConnectorInput(BaseModel):
    """Connector spec for plan generation request."""

    id: str
    name: str
    actions: list[str] = Field(default_factory=list)
    description: str = ""


class PlanSkillInput(BaseModel):
    """Skill spec for plan generation request."""

    id: str
    name: str
    description: str = ""
    inputs: list[str] = Field(default_factory=list)
    outputs: list[str] = Field(default_factory=list)


class PlanRequest(BaseModel):
    """Request to generate a DAG execution plan from a goal."""

    goal: str = Field(..., description="Business goal to decompose into steps", min_length=1, max_length=5000)
    connectors: list[PlanConnectorInput] = Field(default_factory=list, description="Available connectors")
    skills: list[PlanSkillInput] = Field(default_factory=list, description="Available skills")
    context: dict[str, Any] = Field(default_factory=dict, description="Additional context for planning")
    planner_mode: str | None = Field(
        None, description="Optional planner mode override: rigid or self_organizing_emergent"
    )
    intake_result: dict[str, Any] | None = Field(
        None,
        description=(
            "Pre-compiled IntakeCompilerResult (serialised dict). When supplied, used as the "
            "authoritative source for skills, loss function, and composition metadata. "
            "When absent and skills==[], generate_plan invokes IntakeCompiler implicitly."
        ),
    )
