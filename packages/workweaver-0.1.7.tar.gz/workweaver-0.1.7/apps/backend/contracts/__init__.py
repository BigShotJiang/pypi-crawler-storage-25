"""Shared contracts package -- pure data models used across layers.

This package is a LEAF in the import graph.  Modules inside contracts/ must
never import from ``apps.backend.api`` or ``apps.backend.services``.  The
purpose is to break the ``services -> api`` coupling that caused circular
imports and layering violations tracked in issue #3785.
"""
