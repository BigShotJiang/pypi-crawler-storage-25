"""Settings data contracts.

Extracted from ``apps.backend.api.settings`` so that services (e.g.
voice_guardrails, morning_brief_scheduler, zara/context) can use
settings models without creating a services -> api dependency.

Issue #3785.
"""

from __future__ import annotations

from pydantic import BaseModel, Field


class VoiceSettings(BaseModel):
    """Per-tenant voice configuration.

    Controls voice agent identity, provider selection, guardrails,
    and tool bindings (email/calendar) for the tenant's voice AI agent.
    """

    tenant_id: str | None = None
    voice_agent_name: str = "Zara"
    voice_agent_company: str = ""  # Falls back to tenant company name
    voice_id: str = "ara"  # ara | zeus | provider-specific
    voice_provider_pstn: str = "xai"  # xai | gemini
    voice_provider_browser: str = "gemini"  # gemini | xai
    voice_provider_meeting: str = "gemini"  # gemini | xai
    voice_language_hints: list[str] = Field(default_factory=list)
    voice_max_concurrent: int = 5
    voice_max_duration_minutes: int = 60
    voice_spend_cap_daily_usd: float = 50.0
    voice_recording_consent: str = "required"  # required | optional | disabled
    voice_email: str = ""  # Assigned email for voice agent's email tool
    voice_calendar_id: str = ""  # Bound calendar for voice agent's calendar tool
