"""Shard helpers for the capability readiness probe (issue #3793).

Provides:
- ``assign_shard`` -- deterministic hash-bucket assignment.
- ``filter_tenants_for_shard`` -- filter tenants belonging to a specific shard.
- ``ShardLease`` -- DynamoDB-leased work claims backed by PortableStore.
- ``compute_jitter`` -- deterministic jitter to prevent thundering herd.
- ``ShardReport`` -- summary dataclass for a single shard execution.
"""

from __future__ import annotations

import hashlib
import logging
from dataclasses import dataclass
from datetime import datetime, UTC
from typing import Any

logger = logging.getLogger(__name__)


def assign_shard(tenant_id: str, shard_count: int) -> int:
    """Deterministically assign *tenant_id* to a shard in ``[0, shard_count)``."""
    digest = hashlib.sha256(tenant_id.encode()).hexdigest()
    return int(digest, 16) % shard_count


def filter_tenants_for_shard(
    tenant_ids: list[str],
    shard_index: int,
    shard_count: int,
) -> list[str]:
    """Return only the tenants whose hash bucket equals *shard_index*."""
    return [tid for tid in tenant_ids if assign_shard(tid, shard_count) == shard_index]


_LEASE_SK = "LEASE"


class ShardLease:
    """Cooperative mutex backed by PortableStore ``put_if_not_exists``."""

    def __init__(self, store: Any, *, ttl_seconds: int = 300) -> None:
        self._store = store
        self._ttl_seconds = ttl_seconds

    def claim(self, pk: str) -> bool:
        existing = self._store.get_item(pk, _LEASE_SK)
        if existing is not None:
            claimed_at_str = existing.get("claimed_at", "")
            try:
                claimed_at = datetime.fromisoformat(claimed_at_str)
                elapsed = (datetime.now(UTC) - claimed_at).total_seconds()
                if elapsed < self._ttl_seconds:
                    return False
            except (ValueError, TypeError):
                pass
            self._store.delete_item(pk, _LEASE_SK)
        now = datetime.now(UTC).isoformat()
        return self._store.put_if_not_exists(
            pk, _LEASE_SK, {"claimed_at": now, "ttl_seconds": self._ttl_seconds}
        )

    def release(self, pk: str) -> None:
        self._store.delete_item(pk, _LEASE_SK)


def compute_jitter(
    *,
    shard_index: int,
    shard_count: int,
    period_seconds: int,
) -> float:
    """Deterministic jitter for *shard_index* within +-10% of *period*."""
    seed = f"probe-jitter-shard-{shard_index}-of-{shard_count}".encode()
    digest = hashlib.sha256(seed).hexdigest()
    fraction = int(digest[:8], 16) / 0xFFFFFFFF
    return fraction * period_seconds * 0.10


@dataclass(frozen=True, slots=True)
class ShardReport:
    """Summary of a single shard execution."""

    shard_index: int
    shard_count: int
    tenants_probed: int
    outcomes_count: int
    lease_claimed: bool
