"""Capability readiness probe loop (issue #2340).

Scheduled job that periodically checks capability status by running
registered smoke probes and writing outcomes to the ``agent_awareness``
namespace.  ZaraAwarenessService consumes the resulting readiness data
so Zara's prompt includes "capability X is degraded since {timestamp}"
when a probe fails.

Probe convention: ``probe_path`` has the form ``module:callable`` where
the callable takes no arguments and returns ``True`` on success.
Exceptions are caught and mapped to ``blocked``.

Multi-tenant scan (#2340 reopen, 2026-05-10): the probe iterates the
active-tenant list from ``TenantProvisioningService.list_tenants`` and
writes one ``agent_awareness`` row per ``(tenant_id, capability_id)``
pair so tenant A probe outcomes never leak into tenant B. The default
self-host fallback continues to probe the single
``WORKWEAVER_DEFAULT_TENANT`` when no provisioning service is
configured.
"""

from __future__ import annotations

import importlib
import logging
import os
from collections.abc import Iterable
from dataclasses import dataclass
from datetime import datetime, UTC
from typing import Any

from apps.backend.providers.base import get_deployment_profile
from apps.backend.services.capability_state_machine import (
    CapabilityState as RolloutState,
    CapabilityStateMachine,
    CapabilityStateTransitionError,
)
from apps.backend.workmemory.agent_awareness_store import (
    AgentAwarenessStore,
    CapabilityState,
    Readiness,
)

# Lazy import type annotation for CapabilityHealthTrailStore (avoided at
# module level to keep the import graph clean when the trail is not wired).
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from apps.backend.workmemory.services.capability_health_trail_store import (
        CapabilityHealthTrailStore,
    )

logger = logging.getLogger(__name__)

_DEFAULT_INTERVALS: dict[str, int] = {
    "managed_saas": 15,
    "self_host_production": 60,
    "local_native": 60,
    "standalone": 60,
}

_ENV_KEY = "CAPABILITY_PROBE_INTERVAL_MINUTES"


@dataclass(frozen=True, slots=True)
class ProbeOutcome:
    """Result of a single capability probe execution."""

    capability_id: str
    passed: bool
    error: str | None = None


class CapabilityProbeRunner:
    """Execute smoke probes for capability rows and persist readiness."""

    def __init__(
        self,
        awareness_store: AgentAwarenessStore,
        trail_store: CapabilityHealthTrailStore | None = None,
    ) -> None:
        self._store = awareness_store
        self._trail_store = trail_store

    def run_all(
        self,
        tenant_id: str,
        rows: list[dict[str, Any]],
    ) -> list[ProbeOutcome]:
        """Run probes for every row that declares a ``probe_path``."""
        outcomes: list[ProbeOutcome] = []
        for row in rows:
            cap_id = row.get("capability_id", "")
            probe_path = row.get("probe_path")
            if not probe_path:
                continue

            probe_fn = self._import_probe(probe_path)
            if probe_fn is None:
                logger.warning("capability_probe.import_failed cap=%s path=%s", cap_id, probe_path)
                continue

            outcome = self._execute_probe(cap_id, probe_fn)
            outcomes.append(outcome)
            self._persist_outcome(tenant_id, cap_id, outcome)
        return outcomes

    def run_for_tenants(
        self,
        tenant_ids: Iterable[str],
        rows: list[dict[str, Any]],
    ) -> list[tuple[str, ProbeOutcome]]:
        """Run probes for every tenant in ``tenant_ids``.

        Closes the multi-tenant TODO from the round-5 audit: each tenant
        gets its own ``agent_awareness`` rows; tenant A probe outcomes
        cannot leak into tenant B because every persist call is keyed
        by the tenant the probe ran against.

        Returns ``(tenant_id, outcome)`` pairs in the order the probes
        executed so callers can replay or assert isolation in tests.
        """
        results: list[tuple[str, ProbeOutcome]] = []
        for tenant_id in tenant_ids:
            tenant = str(tenant_id or "").strip()
            if not tenant:
                continue
            outcomes = self.run_all(tenant, rows)
            results.extend((tenant, outcome) for outcome in outcomes)
        return results


    def run_shard(
        self,
        *,
        tenants: "collections.abc.Iterable[str]",
        rows: list[dict[str, Any]],
        shard_index: int,
        shard_count: int,
        lease_store: Any,
    ) -> Any:
        """Run probes for tenants belonging to a single shard."""
        from apps.backend.jobs.probe_shard_helpers import (
            ShardLease,
            ShardReport,
            filter_tenants_for_shard,
        )
        pk = f"PROBE_SHARD#{shard_index}"
        lease = ShardLease(store=lease_store, ttl_seconds=300)
        if not lease.claim(pk):
            logger.info("capability_probe.shard_lease_contention shard=%d", shard_index)
            return ShardReport(shard_index=shard_index, shard_count=shard_count, tenants_probed=0, outcomes_count=0, lease_claimed=False)
        try:
            tenant_list = list(tenants)
            filtered = filter_tenants_for_shard(tenant_list, shard_index, shard_count)
            outcomes = self.run_for_tenants(filtered, rows)
            return ShardReport(shard_index=shard_index, shard_count=shard_count, tenants_probed=len(filtered), outcomes_count=len(outcomes), lease_claimed=True)
        finally:
            lease.release(pk)
    def _import_probe(self, probe_path: str) -> Any | None:
        """Import a probe callable from a ``module:callable`` path."""
        if ":" not in probe_path:
            logger.warning("capability_probe.invalid_path path=%s", probe_path)
            return None
        module_path, _, attr_name = probe_path.rpartition(":")
        try:
            module = importlib.import_module(module_path)
            return getattr(module, attr_name, None)
        except (ImportError, AttributeError):
            logger.warning("capability_probe.import_error path=%s", probe_path, exc_info=True)
            return None

    def _execute_probe(self, cap_id: str, probe_fn: Any) -> ProbeOutcome:
        """Execute a probe function, catching exceptions."""
        try:
            result = probe_fn()
            passed = bool(result)
            return ProbeOutcome(capability_id=cap_id, passed=passed, error=None if passed else "probe returned False")
        except Exception as exc:
            logger.warning("capability_probe.exception cap=%s error=%s", cap_id, exc)
            return ProbeOutcome(capability_id=cap_id, passed=False, error=f"{type(exc).__name__}: {exc}")

    def _persist_outcome(self, tenant_id: str, cap_id: str, outcome: ProbeOutcome) -> None:
        """Write the probe outcome to the awareness store and transition rollout state."""
        now = datetime.now(UTC).isoformat()
        if outcome.passed:
            readiness = Readiness.E2E_VERIFIED
        elif outcome.error is not None and not outcome.error.startswith("probe returned"):
            readiness = Readiness.BLOCKED
        else:
            readiness = Readiness.DEGRADED

        degraded_since: str | None = now if readiness in (Readiness.DEGRADED, Readiness.BLOCKED) else None

        state = CapabilityState(
            capability_id=cap_id,
            readiness=readiness,
            last_probe_at=now,
            last_probe_outcome="pass" if outcome.passed else "fail",
            surfaces=[],
            tenant_overlay={"degraded_since": degraded_since} if degraded_since else {},
        )
        self._store.upsert_capability(tenant_id, state)
        logger.info("capability_probe.persisted tenant=%s cap=%s readiness=%s", tenant_id, cap_id, readiness.value)
        self._maybe_transition_rollout_state(
            tenant_id=tenant_id, cap_id=cap_id, readiness=readiness, outcome=outcome
        )
        self._write_trail(tenant_id=tenant_id, cap_id=cap_id, outcome=outcome)

    def _write_trail(
        self,
        *,
        tenant_id: str,
        cap_id: str,
        outcome: ProbeOutcome,
    ) -> None:
        """Best-effort write probe outcome to the CapabilityHealthTrail (#3798)."""
        if self._trail_store is None:
            return
        try:
            from apps.backend.observability.action_metrics import hash_identifier

            hour_bucket = datetime.now(UTC).strftime("%Y-%m-%dT%H")
            tenant_hash = hash_identifier(tenant_id)
            self._trail_store.upsert(
                {
                    "capability_id": cap_id,
                    "tenant_hash": tenant_hash,
                    "hour_bucket": hour_bucket,
                    "sample_count": 1,
                    "success_rate": 1.0 if outcome.passed else 0.0,
                    "latency_p95_ms": 0.0,
                    "cost_per_success_usd": 0.0,
                    "fallback_rate": 0.0,
                    "error_rate": 0.0 if outcome.passed else 1.0,
                    "trace_coverage": 0.0,
                    "rejection_rate": 0.0,
                }
            )
        except Exception:
            logger.warning(
                "capability_probe.trail_write_failed tenant=%s cap=%s",
                tenant_id,
                cap_id,
                exc_info=True,
            )

    def _maybe_transition_rollout_state(
        self,
        *,
        tenant_id: str,
        cap_id: str,
        readiness: Readiness,
        outcome: ProbeOutcome,
    ) -> None:
        """Translate per-tenant readiness into a rollout-state transition.

        Per #3543 the rollout state machine refuses regressions, so this
        only forwards probe outcomes that map onto a valid forward / DEGRADED
        / E2E_VERIFIED edge. Unknown current state is treated as CANDIDATE
        so the transition is always explicit.
        """
        existing = self._store.get_capability(tenant_id, cap_id) or {}
        current_readiness_raw = existing.get("readiness")
        current_state: RolloutState
        if current_readiness_raw:
            try:
                current_state = CapabilityStateMachine.from_readiness(
                    Readiness(current_readiness_raw)
                )
            except ValueError:
                current_state = RolloutState.CANDIDATE
        else:
            current_state = RolloutState.CANDIDATE

        target_state = CapabilityStateMachine.from_readiness(readiness)

        if not CapabilityStateMachine.can_transition(current=current_state, target=target_state):
            logger.info(
                "capability_probe.transition_skipped tenant=%s cap=%s current=%s target=%s reason=invalid_or_regression",
                tenant_id, cap_id, current_state.value, target_state.value,
            )
            return

        machine = CapabilityStateMachine(
            emit_trace=lambda payload: logger.info(
                "capability_state.trace %s", payload
            ),
            workspace_id=tenant_id,
        )
        try:
            machine.transition(
                capability_id=cap_id,
                current=current_state,
                target=target_state,
                evidence={
                    "probe_outcome": "pass" if outcome.passed else "fail",
                    "probe_error": outcome.error or "",
                },
                actor_id="job:capability_readiness_probe",
            )
        except CapabilityStateTransitionError:
            logger.info(
                "capability_probe.transition_refused tenant=%s cap=%s current=%s target=%s",
                tenant_id, cap_id, current_state.value, target_state.value,
            )


def get_probe_interval_minutes() -> int:
    """Return probe interval in minutes (env override > profile default)."""
    env_val = os.environ.get(_ENV_KEY)
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            logger.warning("capability_probe.invalid_env %s=%s", _ENV_KEY, env_val)
    profile = get_deployment_profile()
    return _DEFAULT_INTERVALS.get(profile.value, 60)


def _enumerate_active_tenants(default_tenant: str) -> list[str]:
    """Return the list of tenants the probe should run against.

    Closes the round-5 audit TODO: managed SaaS pulls the list from
    ``TenantProvisioningService.list_tenants`` (paginated, ACTIVE only);
    self-host / standalone deployments fall back to the single
    ``WORKWEAVER_DEFAULT_TENANT`` so the probe always has a tenant
    to write against. Failures fall back to the default tenant so a
    tenant-list outage never silently disables probing.
    """
    try:
        from apps.backend.services.tenant_provisioning import (
            get_tenant_provisioning_service,
        )

        service = get_tenant_provisioning_service()
        records = service.list_tenants(status="active", limit=5000)
    except Exception as exc:
        logger.warning(
            "capability_probe.tenant_enumeration_failed: %s; falling back to default tenant",
            exc,
            exc_info=True,
        )
        return [default_tenant]
    tenant_ids = [
        str(record.get("tenant_id") or "").strip()
        for record in records
        if isinstance(record, dict)
    ]
    tenant_ids = [tid for tid in tenant_ids if tid]
    if not tenant_ids:
        return [default_tenant]
    return tenant_ids


def get_probe_history_for_tenant(
    *,
    tenant_id: str,
    capability_id: str,
    store: AgentAwarenessStore,
) -> dict[str, Any]:
    """Return the most recent probe row for ``(tenant_id, capability_id)``.

    Surface backing for the audit's REST/CLI/MCP requirement
    (``GET /api/v1/capabilities/{id}/probe-history?tenant=X``,
    ``ww kernel probe history <id>``, ``ww.kernel.probe.history``).
    The awareness namespace stores one row per capability; this helper
    projects that row into a probe-history shape so the surface can
    return ``readiness``, ``last_probe_at``, ``last_probe_outcome`` in
    one read.
    """
    record = store.get_capability(tenant_id, capability_id) or {}
    return {
        "tenant_id": tenant_id,
        "capability_id": capability_id,
        "readiness": record.get("readiness"),
        "last_probe_at": record.get("last_probe_at"),
        "last_probe_outcome": record.get("last_probe_outcome"),
        "tenant_overlay": record.get("tenant_overlay") or {},
        "evidence_refs": list(record.get("evidence_refs") or []),
    }


def register_capability_readiness_probe(
    *,
    scheduler: Any,
    awareness_store: AgentAwarenessStore | None = None,
    trail_store: CapabilityHealthTrailStore | None = None,
) -> None:
    """Register the capability readiness probe as a scheduled job."""
    from apps.backend.providers.portable_store import create_portable_store

    store = awareness_store or AgentAwarenessStore(store=create_portable_store("capability-probe-awareness"))
    if trail_store is None:
        try:
            from apps.backend.workmemory.services.capability_health_trail_store import (
                CapabilityHealthTrailStore as _CTStore,
            )

            trail_store = _CTStore(store=create_portable_store("capability-probe-awareness"))
        except Exception:
            logger.debug("capability_probe.trail_store_unavailable", exc_info=True)
    runner = CapabilityProbeRunner(awareness_store=store, trail_store=trail_store)
    interval = get_probe_interval_minutes()

    def _job_handler() -> None:
        try:
            from apps.backend.services.capability_registry.registry import load_capability_registry

            registry = load_capability_registry()
            raw_rows = [
                {"capability_id": row.capability_id, "probe_path": row.parity.get("probe_path")}
                for row in registry.rows
            ]
        except Exception:
            logger.warning("capability_probe.registry_load_failed", exc_info=True)
            return
        default_tenant = os.environ.get("WORKWEAVER_DEFAULT_TENANT", "default")
        tenants = _enumerate_active_tenants(default_tenant)
        runner.run_for_tenants(tenants, raw_rows)

    cron_expr = f"*/{interval} * * * *"
    scheduler.register("capability_readiness_probe", cron_expr, _job_handler)
    logger.info("capability_probe.registered interval=%dm cron=%s", interval, cron_expr)


def register_capability_readiness_probes(
    *,
    scheduler: Any,
    awareness_store: AgentAwarenessStore | None = None,
    trail_store: CapabilityHealthTrailStore | None = None,
    shard_count: int = 8,
) -> None:
    """Register sharded capability readiness probes as N scheduled jobs.

    Each shard runs independently with its own lease, so multiple workers
    can process different shards in parallel.  The shard count defaults to 8.
    """
    from apps.backend.providers.portable_store import create_portable_store

    store = awareness_store or AgentAwarenessStore(store=create_portable_store("capability-probe-awareness"))
    if trail_store is None:
        try:
            from apps.backend.workmemory.services.capability_health_trail_store import (
                CapabilityHealthTrailStore as _CTStore,
            )

            trail_store = _CTStore(store=create_portable_store("capability-probe-awareness"))
        except Exception:
            logger.debug("capability_probe.trail_store_unavailable", exc_info=True)
    runner = CapabilityProbeRunner(awareness_store=store, trail_store=trail_store)
    interval = get_probe_interval_minutes()
    cron_expr = f"*/{interval} * * * *"

    for shard_index in range(shard_count):
        idx = shard_index

        def _shard_handler(_idx: int = idx) -> None:
            try:
                from apps.backend.services.capability_registry.registry import load_capability_registry

                registry = load_capability_registry()
                raw_rows = [
                    {"capability_id": row.capability_id, "probe_path": row.parity.get("probe_path")}
                    for row in registry.rows
                ]
            except Exception:
                logger.warning("capability_probe.registry_load_failed shard=%d", _idx, exc_info=True)
                return
            default_tenant = os.environ.get("WORKWEAVER_DEFAULT_TENANT", "default")
            tenants = _enumerate_active_tenants(default_tenant)
            runner.run_shard(
                tenants=tenants,
                rows=raw_rows,
                shard_index=_idx,
                shard_count=shard_count,
                lease_store=create_portable_store("capability-probe-awareness"),
            )

        job_name = f"capability_readiness_probe_shard_{shard_index}"
        scheduler.register(job_name, cron_expr, _shard_handler)

    logger.info(
        "capability_probe.registered_sharded shard_count=%d interval=%dm cron=%s",
        shard_count,
        interval,
        cron_expr,
    )
