"""Scheduled job for the learning-signal DLQ consumer (issue #2324).

Registers ``DLQConsumer.drain_pending`` as a periodic job via the
``ScheduleProvider`` infrastructure.  Follows the same pattern as
``apps/backend/jobs/capability_readiness_probe.py``.
"""

from __future__ import annotations

import logging
import os
from typing import Any

logger = logging.getLogger(__name__)

_DEFAULT_INTERVAL_MINUTES = 5
_ENV_KEY = "LEARNING_DLQ_CONSUMER_INTERVAL_MINUTES"


def get_dlq_consumer_interval_minutes() -> int:
    """Return the DLQ consumer interval in minutes.

    Resolution order:
      1. ``LEARNING_DLQ_CONSUMER_INTERVAL_MINUTES`` environment variable.
      2. Default of 5 minutes.
    """
    env_val = os.environ.get(_ENV_KEY)
    if env_val:
        try:
            return int(env_val)
        except ValueError:
            logger.warning(
                "learning_dlq_consumer.invalid_env %s=%s (not an int)",
                _ENV_KEY,
                env_val,
            )
    return _DEFAULT_INTERVAL_MINUTES


def register_learning_dlq_consumer(
    *,
    scheduler: Any,
) -> None:
    """Register the learning-signal DLQ consumer as a scheduled job.

    Args:
        scheduler: A ``ScheduleProvider`` implementation.
    """
    from apps.backend.services.learning.dlq_consumer import DLQConsumer
    from apps.backend.services.learning.learning_signal_queue import LearningSignalQueue

    queue = LearningSignalQueue()
    consumer = DLQConsumer(queue=queue)
    interval = get_dlq_consumer_interval_minutes()

    def _job_handler() -> None:
        """Drain pending DLQ envelopes by re-invoking learn_from_task."""
        import asyncio

        async def _drain() -> None:
            from apps.backend.services.learning.loop_core import (
                TaskSelfImprovementService,
            )

            # Build a lightweight learn_fn that the consumer can call.
            # Each tenant gets its own service instance.
            async def learn_fn(
                task_description: str,
                task_context: Any,
                result: Any,
            ) -> None:
                # task_context is a plain dict from the envelope payload.
                # Extract tenant_id from the envelope -- we use the queue's
                # pending list which already carries tenant info.
                tenant_id = str(
                    getattr(task_context, "get", lambda k, d="": d)("tenant_id", "")
                    if isinstance(task_context, dict)
                    else getattr(task_context, "tenant_id", "")
                )
                if not tenant_id:
                    logger.warning("DLQ consumer: skipping envelope with no tenant_id")
                    return

                from apps.backend.services.memory.memory_service import get_memory_service
                from apps.backend.services.evidence_ledger import get_evidence_service

                memory_service = get_memory_service()
                evidence_service = get_evidence_service()

                service = TaskSelfImprovementService(
                    tenant_id=tenant_id,
                    memory_service=memory_service,
                    evidence_service=evidence_service,
                )

                # Reconstruct TaskContext and TaskExecutionResult from the
                # serialized payload dicts.
                from apps.backend.services.zara.service import TaskContext, TaskExecutionResult

                if isinstance(task_context, dict):
                    task_context = TaskContext(
                        category=task_context.get("category", ""),
                        sub_task=task_context.get("sub_task", ""),
                        metadata=task_context.get("metadata", {}),
                    )

                if isinstance(result, dict):
                    from apps.backend.services.zara.service import TaskOutcome
                    outcome_data = result.get("outcome", {})
                    outcome = TaskOutcome(
                        task_type=outcome_data.get("task_type", "post_call_work"),
                        duration_ms=outcome_data.get("duration_ms", 0),
                        tools_used=outcome_data.get("tools_used", []),
                        success=outcome_data.get("success", False),
                        error_summary=outcome_data.get("error_summary"),
                    ) if outcome_data else None

                    result = TaskExecutionResult(
                        status=result.get("status", "unknown"),
                        execution_mode=result.get("execution_mode", "workflow"),
                    )
                    result.outcome = outcome

                await service.learn_from_task(
                    task_description=task_description,
                    task_context=task_context,
                    result=result,
                )

            drain_result = await consumer.drain_pending(learn_fn=learn_fn)
            if drain_result.drained > 0 or drain_result.failed > 0:
                logger.info(
                    "DLQ consumer: drained=%d failed=%d skipped=%d",
                    drain_result.drained,
                    drain_result.failed,
                    drain_result.skipped,
                )

        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                # If called from within an async context, schedule as task.
                asyncio.ensure_future(_drain())
            else:
                loop.run_until_complete(_drain())
        except RuntimeError:
            # No event loop -- create one.
            asyncio.run(_drain())

    cron_expr = f"*/{interval} * * * *"
    scheduler.register(
        "learning_dlq_consumer",
        cron_expr,
        _job_handler,
    )
    logger.info(
        "learning_dlq_consumer.registered interval=%dm cron=%s",
        interval,
        cron_expr,
    )
