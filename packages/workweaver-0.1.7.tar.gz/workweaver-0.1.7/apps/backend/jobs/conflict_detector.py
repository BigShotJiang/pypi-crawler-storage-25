"""Nightly conflict detector job (#3548).

Walks every active tenant via :class:`TenantProvisioningService.list_tenants`,
runs :class:`ConflictDetectorService.detect`, and persists the resulting
bundle so REST/CLI/MCP/UI surfaces can read the latest snapshot without
re-running the probe.

Idempotency: every bundle write is keyed by
``(tenant_id, conflict_id)``. Subsequent runs that surface the same
drift overwrite the row; resolved conflicts that no longer surface are
naturally aged out by the next probe.
"""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any, Iterable

from apps.backend.services.conflict_detector import (
    ConflictDetectorService,
    TenantConflictBundle,
    get_conflict_detector_service,
)

logger = logging.getLogger(__name__)


def list_active_tenant_ids() -> list[str]:
    """Best-effort active tenant enumeration."""
    try:
        from apps.backend.services.tenant_provisioning import (
            TenantProvisioningService,
        )

        service = TenantProvisioningService()
        rows = service.list_tenants(status="active")
        return [
            str(row.get("tenant_id") or row.get("id") or "")
            for row in rows
            if str(row.get("tenant_id") or row.get("id") or "").strip()
        ]
    except Exception as exc:  # noqa: BLE001 — degrade gracefully
        logger.warning("conflict_detector tenant enumeration failed: %s", exc)
        return []


def run_conflict_detection_for_tenants(
    tenant_ids: Iterable[str] | None = None,
    *,
    detector: ConflictDetectorService | None = None,
    persistor: Any | None = None,
    now: datetime | None = None,
) -> dict[str, TenantConflictBundle]:
    """Run the detector across ``tenant_ids`` and return the bundles.

    ``persistor`` is an optional callable invoked with each bundle so
    cron-mode runs can write to Inbox + WorkMemory; tests pass ``None``
    to skip persistence.
    """
    detector = detector or get_conflict_detector_service()
    target_ids = list(tenant_ids) if tenant_ids is not None else list_active_tenant_ids()
    moment = now or datetime.now(UTC)
    bundles: dict[str, TenantConflictBundle] = {}
    for tenant_id in target_ids:
        if not tenant_id:
            continue
        try:
            bundle = detector.detect(tenant_id=tenant_id)
        except Exception as exc:  # noqa: BLE001 — never let one tenant kill the loop
            logger.error(
                "conflict_detector probe failed tenant=%s err=%s",
                tenant_id,
                exc,
                exc_info=True,
            )
            continue
        bundles[tenant_id] = bundle
        if persistor is not None:
            try:
                persistor(bundle)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "conflict_detector persist failed tenant=%s err=%s",
                    tenant_id,
                    exc,
                )
    logger.info(
        "conflict_detector_run tenants=%d at=%s",
        len(bundles),
        moment.isoformat(),
    )
    return bundles
