"""Monthly healing digest cron job (#3550)."""

from __future__ import annotations

import logging
from datetime import UTC, datetime
from typing import Any, Iterable

from apps.backend.services.healing_digest import (
    HealingDigest,
    HealingDigestService,
    get_healing_digest_service,
    month_key,
)

logger = logging.getLogger(__name__)


def list_active_tenant_ids() -> list[str]:
    try:
        from apps.backend.services.tenant_provisioning import (
            TenantProvisioningService,
        )

        rows = TenantProvisioningService().list_tenants(status="active")
        return [
            str(row.get("tenant_id") or row.get("id") or "")
            for row in rows
            if str(row.get("tenant_id") or row.get("id") or "").strip()
        ]
    except Exception as exc:  # noqa: BLE001 — degrade gracefully
        logger.warning("healing_digest tenant enumeration failed: %s", exc)
        return []


def run_monthly_healing_digest(
    tenant_ids: Iterable[str] | None = None,
    *,
    service: HealingDigestService | None = None,
    month: str | None = None,
    now: datetime | None = None,
    persistor: Any | None = None,
) -> dict[str, HealingDigest]:
    target_service = service or get_healing_digest_service()
    target_month = month or month_key(now or datetime.now(UTC))
    target_ids = list(tenant_ids) if tenant_ids is not None else list_active_tenant_ids()
    digests: dict[str, HealingDigest] = {}
    for tenant_id in target_ids:
        if not tenant_id:
            continue
        try:
            digest = target_service.digest(tenant_id=tenant_id, month=target_month)
        except Exception as exc:  # noqa: BLE001 — never let one tenant kill the loop
            logger.error(
                "healing_digest probe failed tenant=%s err=%s",
                tenant_id,
                exc,
                exc_info=True,
            )
            continue
        digests[tenant_id] = digest
        if persistor is not None:
            try:
                persistor(digest)
            except Exception as exc:  # noqa: BLE001
                logger.warning(
                    "healing_digest persist failed tenant=%s err=%s",
                    tenant_id,
                    exc,
                )
    logger.info(
        "healing_digest_run tenants=%d month=%s",
        len(digests),
        target_month,
    )
    return digests
