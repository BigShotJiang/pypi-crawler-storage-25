"""
WebSocket Handler for Voice Testing API

Bare metal WebSocket implementation using API Gateway WebSocket API.
Handles connect/disconnect/subscribe routes and broadcasts latency data.

Environment Variables:
- WEBSOCKET_ENDPOINT - API Gateway WebSocket management endpoint URL
"""

import asyncio
import boto3
import json
import logging
import os

logger = logging.getLogger()
logger.setLevel(logging.INFO)

# Connection store: channel -> set of connection_ids
# For production, use DynamoDB for multi-Lambda support
_connections: dict[str, set[str]] = {"latency": set()}


def response(status_code: int, body: str) -> dict:
    """Create WebSocket API Gateway response."""
    return {"statusCode": status_code, "body": body}


def handle_connect(event: dict) -> dict:
    """Handle $connect - Accept new WebSocket connection with auth validation."""
    connection_id = event["requestContext"]["connectionId"]

    # Validate authentication via query string or authorizer
    query_params = event.get("queryStringParameters") or {}
    authorizer = event.get("requestContext", {}).get("authorizer") or {}
    token = query_params.get("token", "")
    principal = authorizer.get("principalId", "")

    if not token and not principal:
        logger.warning(f"WebSocket connect rejected (no auth): {connection_id}")
        return response(401, "Authentication required")

    logger.info(f"WebSocket connect: {connection_id}")
    return response(200, "Connected")


def handle_disconnect(event: dict) -> dict:
    """Handle $disconnect - Remove connection from all channels."""
    connection_id = event["requestContext"]["connectionId"]
    logger.info(f"WebSocket disconnect: {connection_id}")

    # Remove from all channels (parallel iteration)
    for channel in _connections:
        _connections[channel].discard(connection_id)

    return response(200, "Disconnected")


def handle_subscribe(event: dict) -> dict:
    """Handle subscribe - Add connection to a channel."""
    connection_id = event["requestContext"]["connectionId"]
    body = event.get("body", "{}")

    try:
        data = json.loads(body) if body else {}
        channel = data.get("channel", "latency")

        if channel not in _connections:
            _connections[channel] = set()

        _connections[channel].add(connection_id)
        logger.info(f"Connection {connection_id} subscribed to {channel}")
        return response(200, json.dumps({"status": "subscribed", "channel": channel}))

    except json.JSONDecodeError as e:
        logger.error(f"Invalid subscribe JSON: {e}")
        return response(400, json.dumps({"error": "Invalid JSON"}))


def get_apigateway_client():
    """Get API Gateway Management API client."""
    endpoint_url = os.getenv("WEBSOCKET_ENDPOINT")
    if not endpoint_url:
        raise ValueError("WEBSOCKET_ENDPOINT environment variable not set")
    return boto3.client("apigatewaymanagementapi", endpoint_url=endpoint_url)


def broadcast_latency(data: dict):
    """Broadcast latency data to all latency channel subscribers (parallel)."""
    connection_ids = list(_connections.get("latency", set()))
    if not connection_ids:
        logger.debug("No latency subscribers")
        return

    client = get_apigateway_client()

    # Parallel broadcast using asyncio.to_thread for blocking boto3 calls
    async def send_to_connection(conn_id: str):
        try:
            await asyncio.to_thread(
                client.post_to_connection,
                ConnectionId=conn_id,
                Data=json.dumps(data),
            )
        except client.exceptions.GoneException:
            # Connection closed - remove it
            _connections["latency"].discard(conn_id)
            logger.warning(f"Removed stale connection: {conn_id}")
        except Exception as e:
            logger.error(f"Failed to send to {conn_id}: {e}")

    # Run all sends in parallel
    asyncio.run(asyncio.gather(*[send_to_connection(c) for c in connection_ids], return_exceptions=True))
    logger.info(f"Broadcasted latency to {len(connection_ids)} connections")


def lambda_handler(event: dict, context) -> dict:
    """
    Main WebSocket Lambda handler.

    Routes WebSocket events to appropriate handler.
    """
    route_key = event["requestContext"].get("routeKey")
    logger.info(f"WebSocket route: {route_key}")

    try:
        if route_key == "$connect":
            return handle_connect(event)
        elif route_key == "$disconnect":
            return handle_disconnect(event)
        elif route_key == "subscribe":
            return handle_subscribe(event)
        else:
            return response(400, json.dumps({"error": f"Unknown route: {route_key}"}))

    except Exception as e:
        logger.exception("WebSocket handler error")
        return response(500, json.dumps({"error": str(e)}))
