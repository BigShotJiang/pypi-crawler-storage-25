---
name: workweaver-github-issue-authoring
description: Use before creating, rewriting, enriching, screening, closing, or filing follow-up Workweaver GitHub issues. Enforces code-truth intake, product alignment, issue contract completeness, dependency labels, tradeoff/SWOT/consequence analysis, testability scoring, and live GitHub verification before any gh issue create/edit/close action.
---

# Workweaver GitHub Issue Authoring

Use this before any Workweaver GitHub issue is created, rewritten, enriched, closed, or filed as follow-up scope. The goal is not prettier issues; the goal is issue bodies that are implementer-ready, code-truth grounded, product-aligned, dependency-aware, and safe for low-context agents to execute.

## Hard Rules

- Do not create a docs-only issue when code truth can be inspected.
- Do not create a duplicate issue. Search live open and recently closed issues first.
- Do not close an issue because it feels stale. Close only when it is harmful, duplicate, already completed on `main`, or negative local/global delta after code-truth review.
- If the issue is already self-contained, code-truth cited, product-aligned, dependency-aware, and testable, do nothing except report that it passed intake.
- If an issue is legitimate but malformed, edit the issue body in place rather than adding a comment-only patch unless permissions block editing.
- If the work would change behavior and product intent is genuinely ambiguous after reading docs and code, mark `NEEDS-HUMAN`; do not invent product policy.

## Intake Workflow

1. Establish live state:
   - Read `AGENTS.md`, `CODEX.md`, and `docs/PRODUCT-CONTEXT.md`.
   - Read area docs when relevant: `docs/RUNTIME.md`, `docs/CLI.md`, `docs/CAPABILITIES.md`, `docs/COMMERCIAL.md`, `.gap-audit/DEPENDENCY-MAP.md`.
   - Run `gh issue list` / `gh issue view` for duplicates, dependencies, author/source, labels, and open/closed state.
   - Search code with `rg` before making claims.

2. Falsify the premise:
   - Identify what the issue says is broken or missing.
   - Find the current code path, test path, doc claim, registry row, API/CLI/MCP/UI surface, and dependency edge.
   - Record file:line citations for current behavior. Evidence beats assertion.
   - Preserve the useful investigation context inside the issue body, not only in the agent's chat transcript. The next coding agent should not need to rediscover the same seams.

3. Classify:
   - `KEEP_AND_ENRICH`: legitimate problem, positive local/global delta, but body is incomplete or stale.
   - `DO_NOTHING`: already complete, self-contained, code-truth cited, dependency-aware, and testable.
   - `CLOSE`: duplicate, already fixed on `main`, harmful to the product, negative Delta J, or raises global idiot index.
   - `NEEDS-HUMAN`: product judgment is ambiguous or acceptance criteria cannot be made falsifiable without a decision.

4. Score the issue:
   - Product alignment: aligned / misaligned / ambiguous, with the governing doc or code citation.
   - Code-truth basis: estimate the percent grounded in code/tests/runtime evidence versus docs/claims, and state why.
   - Testable surface: estimate the percent that can be proven by automated or real-path tests, and state why.
   - Idiot-index delta: local and global, negative / neutral / positive, with named drift reduced or introduced.
   - Tradeoffs and constraints: what the recommended fix gives up.
   - SWOT: short strength, weakness, opportunity, threat for the recommended path.
   - Consequences: 2nd, 3rd, 4th, and 5th order effects.
   - Reuse context: exact searches, issue queries, files read, tests inspected, adjacent implementations, dead ends, and why rejected options were rejected.

## Issue Body Contract

Every created or rewritten issue body must contain these sections in order:

1. **Summary** - one sentence in plain language, plus intake verdict, Delta J, code-truth basis, document basis, and testability percentage.
2. **Current state (code truth)** - file:line citations for what code, tests, docs, or runtime config do today.
3. **Expected state** - exact behavior after the issue lands.
4. **Potential solutions** - at least two named options with tradeoffs; mark the one that ships and why; include SWOT, 2nd-5th order consequences, and local/global idiot-index delta.
5. **Acceptance criteria** - falsifiable checklist with atomic PR slice, exact tests to add/change, assertion shape, surface parity, and named CI gate.
6. **Dependencies** - `Blocked By`, `Unblocks`, `Can Run In Parallel With`, `Do Not Ship Before`, `Isolation Notes`, `Adversarial Review`.
7. **Labels** - at least one type label and one priority label.
8. **Related** - canonical docs, registry rows, ADRs, previous issues, PRs, or external references.
9. **Implementer's Briefing** - files to create/modify, public API contract with exact types, glossary, implementation steps, tests to add, and run-before-done commands.

If editing an existing issue, preserve useful user intent but rewrite stale prose cleanly in place. Remove completion diaries, vague future-phase language, stale path references, and obsolete dependency statements.

## Context Preservation

The issue body is the handoff artifact. Include the investigation context a coding agent would otherwise have to repeat:

- **Evidence map**: exact files/functions/tests/docs already inspected, with line citations and one-line relevance notes.
- **Search trail**: high-signal `rg`, `gh issue`, `gh pr`, or registry queries that found the relevant seams or ruled out duplicates.
- **Adjacent patterns**: similar working implementation paths, helper APIs, auth dependencies, storage adapters, route patterns, or test fixtures to reuse.
- **Negative findings**: places checked that do not solve the problem, stale paths removed, duplicate issues ruled out, and assumptions falsified.
- **Implementation shortcut**: the fastest likely path through the codebase, including which files to open first and which abstractions not to invent.
- **Verification shortcut**: the narrowest truthful test commands plus the broader CI gate, with why those commands cover the risk.

Keep this context in section 9 under `Implementer's Briefing` using compact subsections. Do not create a separate analysis document or force future agents to mine chat history.

## Closure Rules

Close an issue only when one of these is true:

- Duplicate of another live issue; link the canonical issue in the close comment.
- Already fixed on `main`; cite commit, PR, code lines, and tests.
- Harmful or negative Delta J; explain local/global product damage and the better path.
- The requested behavior conflicts with `docs/PRODUCT-CONTEXT.md` and code truth, and no aligned rewrite exists.

Never close a partially valid issue. Rewrite it to the aligned atomic slice instead.

## Verification

Before declaring issue work done:

- Re-read each live issue body with `gh issue view`.
- Confirm all nine sections exist in order.
- Confirm file paths and issue dependencies are current.
- Confirm type and priority labels exist.
- Run a drift scan for stale markers you touched, such as old absolute paths, obsolete `Blocked By` text, old doc names, or stale test paths.
- Report issue numbers, action taken, verdict, code-truth percentage, and testability percentage.
