---
name: workweaver-secret-handling
description: Mandatory Workweaver protocol for preventing secret and infrastructure identifier leakage. Use before any AWS, Terraform, deployment, CI/CD, GitHub Actions runner, GitHub variable, secret, credential, production config, registry, backend state, cloud-auth, PR, issue, comment, workflow, or cloud-infrastructure work.
---

# Workweaver Secret Handling Protocol

## Core Rule

Treat production cloud metadata as sensitive by default. Do not put cloud account identifiers, region values, backend names, registry hosts, role names, tokens, credentials, secret paths, private endpoint URLs, or production infrastructure identifiers into Git, PRs, issues, comments, visible GitHub variables, logs, screenshots, docs, or final summaries.

Use encrypted GitHub Actions secrets, local credential stores, local ignored files, or a dedicated secret manager. Visible GitHub Variables are allowed only for non-sensitive labels, timing values, booleans, and public feature switches.

## Sensitive By Default

Handle these as no-print values unless the user and repo policy explicitly classify them as public:

- Cloud account identifiers and account aliases.
- Region values and deployment geography.
- ARNs, OIDC role names, registry hostnames, bucket names, lock table names, backend keys, stack names, distribution identifiers, and hosted zone identifiers.
- Access keys, session tokens, runner registration tokens, webhook secrets, API keys, and private endpoint URLs.
- PII, tenant identifiers, customer emails, phone numbers, names, addresses, and raw logs that may contain them.
- GitHub Actions variables that identify production accounts or deployment wiring.
- Any production configuration value that helps enumerate, target, or impersonate infrastructure.

## Hard Rules

- Never print, quote, summarize, or commit access keys, secret keys, session tokens, onboarding-file contents, runner tokens, or raw secret values.
- Never ask the user to paste credentials into chat. If credentials are missing, ask them to place them in the approved local onboarding file or configure the AWS profile locally.
- Never write credentials to repo files, PR bodies, GitHub comments, issue bodies, screenshots, logs, or memory files.
- Do not duplicate account IDs, ARNs, backend names, or secret paths into new docs or skills. Read canonical values from `AGENTS.md`, GitHub variables, AWS config, or the user-provided local instruction for the current run.
- Report only what is needed: profile present/missing, account match/mismatch, variable present/missing, command pass/fail, and last four characters of an account ID when needed.
- Prefer `--query Account --output text` for STS checks and mask the result in user-facing output.
- Before mutating GitHub variables or deploy configuration, verify the command target repo and the authenticated GitHub account.
- Do not run `terraform apply`, production deploys, or raw cloud mutations unless the user explicitly asked for that operation in the current turn and the preflight below passes.

## Preflight

Before touching files, GitHub, or cloud state:

1. Identify every sensitive input and mark it no-print.
2. Prefer parameterization with secret names, environment variable names, or local profile names. Never substitute real values into tracked files or outbound GitHub text.
3. For GitHub Actions, read sensitive values from `secrets.*`, not `vars.*`. Do not echo values; log only value-free pass/fail assertions.
4. For Terraform, keep backend/account configuration in secrets, local ignored backend config, or secure operator setup. Do not commit literal backend or account metadata.
5. If existing repo files already contain sensitive values, do not expand exposure. Remove or parameterize them, and avoid quoting them in chat or PR text.

## Before Any GitHub Mutation

Scan the exact content that will leave the laptop before pushing, opening a PR, editing an issue, or posting a comment.

Minimum branch-diff scan:

```powershell
python .codex\skills\workweaver-secret-handling\scripts\scan_sensitive_diff.py --base origin/main
```

```bash
python .codex/skills/workweaver-secret-handling/scripts/scan_sensitive_diff.py --base origin/main
```

For staged changes:

```powershell
python .codex\skills\workweaver-secret-handling\scripts\scan_sensitive_diff.py --cached
```

```bash
python .codex/skills/workweaver-secret-handling/scripts/scan_sensitive_diff.py --cached
```

For PR, issue, and comment bodies, write the body to a temporary file and scan it before sending:

```powershell
python .codex\skills\workweaver-secret-handling\scripts\scan_sensitive_diff.py --file $env:TEMP\outbound-github-body.md
```

```bash
python .codex/skills/workweaver-secret-handling/scripts/scan_sensitive_diff.py --file "${TMPDIR:-/tmp}/outbound-github-body.md"
```

If a scan fails, stop and redesign the change or redact the outbound text. Do not rely on GitHub secret masking as the control.

## Local AWS Profile Preflight

Inspect profile presence without printing credential values:

```powershell
$files = @("$env:USERPROFILE\.aws\config", "$env:USERPROFILE\.aws\credentials")
foreach ($file in $files) {
  if (Test-Path -LiteralPath $file) {
    Select-String -LiteralPath $file -Pattern '^\[(profile )?[^\]]+\]' |
      ForEach-Object { $_.Line }
  }
}
```

Validate required profiles with STS, but report only match/mismatch:

```powershell
function Test-AwsProfileAccountSuffix($Profile, $ExpectedSuffix) {
  $account = aws sts get-caller-identity --profile $Profile --query Account --output text 2>$null
  if ($LASTEXITCODE -ne 0 -or -not $account) {
    Write-Output "$Profile STS failed"
    exit 1
  }
  $suffix = $account.Substring([Math]::Max(0, $account.Length - 4))
  if (-not $account.EndsWith($ExpectedSuffix)) {
    Write-Output "$Profile account mismatch ending $suffix"
    exit 2
  }
  Write-Output "$Profile account match ending $suffix"
}
```

If a role-assuming profile is missing, add only non-secret config to `$HOME\.aws\config`. Never copy access keys into repo files. Use the profile names and role ARN from the current user instruction or canonical repo context; do not echo the ARN in the final report.

If base profile credentials are missing, stop. The user must configure the base access key and secret locally from the onboarding file; Codex must not receive or transcribe those values.

## GitHub Variable Preflight

Verify GitHub auth and target repo:

```powershell
gh auth status --hostname github.com
gh repo view bitfoundry-ai/workweaver --json nameWithOwner
```

List only variable names and timestamps, not values:

```powershell
gh variable list --repo bitfoundry-ai/workweaver --json name,updatedAt
```

Set required GitHub Actions variables only when the user explicitly provided the values or the canonical repo context already contains them. Use `gh variable set`, not secrets, for non-secret deployment identifiers. Do not print the values after setting.

Re-list variable names after mutation and report `present`/`updated`, not values.

## Deploy Failure Triage

For deploy failures like missing cloud profile or account configuration:

1. Confirm whether the failure is configuration/auth, not code.
2. Check the failing job name and first error line.
3. Check whether code/test lanes passed on the same commit.
4. Validate local AWS profiles if the task involves a self-hosted runner.
5. Set or verify required GitHub variables only when the user authorized repo variable mutation.
6. Rerun the failed workflow only after variables/profiles are corrected.
7. If the workflow still fails, inspect the new failed job logs and repeat with the same masking rules.

## Incident Protocol

If sensitive data reaches GitHub or Git:

1. Stop adding commits, comments, and PR updates on the contaminated branch.
2. Remove any exposed visible GitHub Variables or public config.
3. Close the contaminated PR and delete the remote branch when safe.
4. Rotate actual credentials, session tokens, runner tokens, and webhooks immediately.
5. Create a fresh branch from clean `main` and reapply only the sanitized diff.
6. Open a fresh PR with value-free language.
7. Tell the user the residual risk: GitHub may retain old commits, events, comments, notifications, or caches. Full purge may require GitHub Support.

Never claim that force-push, branch deletion, or PR closure fully erases the exposure.

## Reporting

Final reports may include:

- `worked` / `not worked`
- Which profile names were present and whether account suffixes matched
- Which GitHub variable names are present
- Commands run, with sensitive arguments omitted or described generically
- Workflow run URL and pass/fail state
- Remaining blocker category

Final reports must not include:

- Full account IDs, role ARNs, backend names, lock table names, backend keys, access keys, secret paths, runner tokens, or raw env dumps
- Copies of onboarding-file content
- Raw command output containing sensitive environment variables
