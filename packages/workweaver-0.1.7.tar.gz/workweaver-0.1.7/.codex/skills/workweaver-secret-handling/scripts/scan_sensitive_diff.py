#!/usr/bin/env python3
"""Scan outbound GitHub content for cloud secrets and infrastructure identifiers.

The scanner is intentionally value-free: it reports the file and category, not
the matched value. It is meant for pre-push, pre-PR, pre-issue, and pre-comment
checks where printing the finding would create a second leak.
"""

from __future__ import annotations

import argparse
import re
import subprocess
import sys
from dataclasses import dataclass
from ipaddress import ip_address
from pathlib import Path
from urllib.parse import urlparse


@dataclass(frozen=True)
class Rule:
    name: str
    pattern: re.Pattern[str]


RULES = [
    Rule("access-key-prefix", re.compile(r"\bA[K]IA[0-9A-Z]{16}\b")),
    Rule("session-key-prefix", re.compile(r"\bA[S]IA[0-9A-Z]{16}\b")),
    Rule(
        "session-token-value",
        re.compile(r"(?<![A-Za-z0-9/+=])(?=[A-Za-z0-9/+=]{80,}(?![A-Za-z0-9/+=]))(?=[A-Za-z0-9/+=]*[a-z])(?=[A-Za-z0-9/+=]*[A-Z])(?=[A-Za-z0-9/+=]*(?:[0-9]|[+/=]))[A-Za-z0-9/+=]{80,}(?![A-Za-z0-9/+=])"),
    ),
    Rule(
        "secret-access-key-value",
        re.compile(r"(?<![A-Za-z0-9/+=])(?=[A-Za-z0-9/+=]{40}(?![A-Za-z0-9/+=]))(?=[A-Za-z0-9/+=]*[a-z])(?=[A-Za-z0-9/+=]*[A-Z])(?=[A-Za-z0-9/+=]*(?:[0-9]|[+/=]))[A-Za-z0-9/+=]{40}(?![A-Za-z0-9/+=])"),
    ),
    Rule(
        "token-value",
        re.compile(
            r"(?<![A-Za-z0-9_-])(?:"
            r"gh[pousr]_[A-Za-z0-9_]{20,}|"
            r"github_pat_[A-Za-z0-9_]{20,}_[A-Za-z0-9_]{20,}|"
            r"glpat-[A-Za-z0-9_-]{20,}|"
            r"npm_[A-Za-z0-9]{30,}|"
            r"pypi-[A-Za-z0-9_-]{40,}|"
            r"AIza[A-Za-z0-9_-]{35}|"
            r"SG\.[A-Za-z0-9_-]{20,}\.[A-Za-z0-9_-]{35,}|"
            r"xox[baprs]-[A-Za-z0-9-]{20,}|"
            r"whsec_[A-Za-z0-9]{20,}|"
            r"sk_live_[A-Za-z0-9]{20,}|"
            r"sk-[A-Za-z0-9_-]{32,}|"
            r"sk-(?:proj|svcacct)-[A-Za-z0-9_-]{20,}"
            r")(?![A-Za-z0-9_-])"
        ),
    ),
    Rule(
        "private-key-block",
        re.compile(
            r"-{5}BEGIN (?:"
            r"(?:RSA|DSA|EC|OPENSSH|ENCRYPTED) PRIVATE KEY|"
            r"PGP PRIVATE KEY BLOCK|"
            r"PRIVATE KEY"
            r")-{5}"
        ),
    ),
    Rule("secret-access-key-name", re.compile(r"\baws(?:[_\s-]*secret[_\s-]*access[_\s-]*key|[_\s-]*access[_\s-]*key[_\s-]*secret)\b", re.IGNORECASE)),
    Rule("cloud-account-id", re.compile(r"(?<!\d)\d{12}(?!\d)")),
    Rule("aws-arn", re.compile(r"\barn[:]aws[a-z-]*[:]")),
    Rule(
        "aws-region",
        re.compile(r"\b(?:[a-z]{2}(?:-[a-z]+)+-[0-9]|us-gov-(?:east|west)-[0-9]|eusc-[a-z]{2}-[a-z]+-[0-9])\b"),
    ),
    Rule("s3-uri", re.compile(r"\bs3://[a-z0-9][a-z0-9.-]{2,}(?:/|$)", re.IGNORECASE)),
    Rule("container-registry-host", re.compile(r"\b[0-9]{12}[.]dkr[.]ecr[.][a-z0-9-]+[.]amazonaws[.]com\b")),
    Rule("infra-config-ref", re.compile(r"\b[\w./-]*terraform[\w./-]*(?:tfstate|state|backend)[\w./-]*\b", re.IGNORECASE)),
    Rule(
        "cloud-account-alias-context",
        re.compile(
            r"\b(?i:(?:(?:aws|cloud)\s+)?account\s+alias)\s*(?i:(?:[:=]|is|as|called|named|for))?\s*[`\"']?(?!(?:names?|policy|identifiers?|values?|contexts?|wording|prose|should|must|will|can|may|redacted|masked|configured|created)\b)[a-z0-9][a-z0-9._-]{2,}\b",
        ),
    ),
    Rule(
        "secret-store-path-context",
        re.compile(
            r"\b(?i:(?:secrets?\s+manager|ssm|parameter\s+store|secret[-\s]?path|secret\s+location|parameter\s+path))[\w\s/.-]{0,40}\s*(?i:(?:[:=]|is|as|called|named|for|path))?\s*[`\"']?/[a-z0-9_-]+/[A-Za-z0-9._/-]{3,}\b",
        ),
    ),
    Rule("runner-enrollment-ref", re.compile(r"\brunner[_ -]?(?:registration[_ -]?)?token\b", re.IGNORECASE)),
    Rule(
        "cloud-role-name-context",
        re.compile(
            r"\b(?i:(?:iam|oidc|assume|deployment|deploy|runner|github actions))[\w\s/.-]{0,60}\b(?i:role)(?:[_ -]?(?i:name)(?!s\b))?\s*(?i:(?:[:=]|is|as|called|named|for))?\s*[`\"']?(?!(?:names?|contexts?|wording|prose|rules?|detectors?|tokens?|values?|identifiers?|metadata|should|must|will|can|may)\b)[A-Za-z0-9+=,.@_-]+\b",
        ),
    ),
    Rule("privileged-prod-alias", re.compile(r"\b[a-z0-9_-]*(?:prod|production)[a-z0-9_-]*(?:admin|deploy|ops|root|writer|ci)[a-z0-9_-]*\b", re.IGNORECASE)),
    Rule("state-storage-name", re.compile(r"\b[a-z0-9][a-z0-9.-]{2,}[-_.](?:state|tfstate|backend|lock|locks)[-_.a-z0-9]*\b", re.IGNORECASE)),
    Rule(
        "state-storage-name-context",
        re.compile(
            r"\b(?i:(?:(?:terraform|state|backend|s3)\s+bucket)|(?:(?:lock|locking)\s+(?:table|dynamodb\s+table))|(?:dynamodb\s+(?:lock|locking)\s+table))\s*(?i:(?:[:=]|is|as|called|named|for))?\s*[`\"']?(?!(?:names?|policy|identifiers?|values?|contexts?|wording|prose|should|must|will|can|may|redacted|masked|configured|created)\b)[a-z0-9][a-z0-9._-]{2,}\b|\b(?i:bucket)(?:\s*(?i:(?:[:=]|is|as|called|named|for))\s*[`\"']?(?!(?:names?|policy|identifiers?|values?|contexts?|wording|prose|should|must|will|can|may|redacted|masked|configured|created)\b)[a-z0-9][a-z0-9._-]{2,}\b|\s*[`\"']?(?!(?:names?|policy|identifiers?|values?|contexts?|wording|prose|should|must|will|can|may|redacted|masked|configured|created)\b)(?=[a-z0-9._-]*[0-9._-])[a-z0-9][a-z0-9._-]{2,}\b)",
        ),
    ),
    Rule("url", re.compile(r"\bhttps?://[^\s)>\"]+", re.IGNORECASE)),
    Rule("hosted-zone-id", re.compile(r"\bZ[A-Z0-9]{10,}\b")),
    Rule("distribution-id", re.compile(r"\bE[A-Z0-9]{10,}\b")),
]

ENV_TEMPLATE_SUFFIXES = (".example", ".sample", ".template", ".dist")
ENV_FILE_NAME = re.compile(
    r"^(?:\.env(?:\.[A-Za-z0-9_-]+)*|[A-Za-z0-9][A-Za-z0-9._-]*\.env(?:\.[A-Za-z0-9_-]+)*)$",
    re.IGNORECASE,
)
CREDENTIAL_CONFIG_FILE_NAMES = {".npmrc", ".pypirc", ".netrc"}
CLOUD_CREDENTIAL_DIR_NAMES = {".aws"}
CLOUD_CREDENTIAL_FILE_STEMS = {"config", "credentials"}
LOCAL_CREDENTIAL_PATH_SUFFIXES = (
    (".docker", "config.json"),
    (".kube", "config"),
    ("gcloud", "application_default_credentials.json"),
)
SSH_PRIVATE_KEY_DIR_NAMES = {".ssh"}
SSH_PRIVATE_KEY_FILE_STEMS = {
    "id_dsa",
    "id_ecdsa",
    "id_ecdsa_sk",
    "id_ed25519",
    "id_ed25519_sk",
    "id_rsa",
    "id_xmss",
    "identity",
}


def _run_git_diff(base: str, cached: bool) -> str | None:
    cmd = ["git", "diff", "--unified=0"]
    if cached:
        cmd.append("--cached")
    elif base:
        cmd.append(f"{base}...HEAD")
    result = subprocess.run(cmd, check=False, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if result.returncode != 0:
        print("sensitive-scan: git diff failed", file=sys.stderr)
        if result.stderr:
            print(result.stderr.strip(), file=sys.stderr)
        return None
    return result.stdout


def _changed_lines(diff: str) -> list[tuple[str, int | None, str]]:
    lines: list[tuple[str, int | None, str]] = []
    seen_paths: set[str] = set()
    current_file = "<diff>"
    new_line: int | None = None
    old_line: int | None = None
    scan_next_new_path = False
    pending_diff_path: str | None = None

    def add_changed_path(path: str) -> None:
        if path not in seen_paths:
            lines.append((path, None, path))
            seen_paths.add(path)

    for line in diff.splitlines():
        diff_match = re.match(r"^diff --git a/.+ b/(.+)$", line)
        if diff_match:
            pending_diff_path = diff_match.group(1)
            scan_next_new_path = False
            continue
        if line.startswith("new file mode "):
            if pending_diff_path:
                add_changed_path(pending_diff_path)
            scan_next_new_path = True
            continue
        if line.startswith("rename to "):
            add_changed_path(line[len("rename to ") :])
            continue
        if line.startswith("+++ b/"):
            current_file = line[6:]
            if scan_next_new_path:
                add_changed_path(current_file)
                scan_next_new_path = False
            continue
        if line.startswith("--- a/"):
            current_file = line[6:]
            continue
        if line.startswith("@@ "):
            old_match = re.search(r"-(\d+)(?:,(\d+))?", line)
            new_match = re.search(r"\+(\d+)(?:,(\d+))?", line)
            old_line = int(old_match.group(1)) if old_match else None
            new_line = int(new_match.group(1)) if new_match else None
            continue
        if line.startswith("+") and not line.startswith("+++"):
            lines.append((current_file, new_line, line[1:]))
            if new_line is not None:
                new_line += 1
        elif line.startswith("-") and not line.startswith("---"):
            if old_line is not None:
                old_line += 1
        elif not line.startswith(("-", "+")):
            if new_line is not None:
                new_line += 1
            if old_line is not None:
                old_line += 1

    return lines


def _file_lines(path: Path) -> list[tuple[str, int, str]]:
    return [(str(path), idx, line) for idx, line in enumerate(path.read_text(encoding="utf-8").splitlines(), 1)]


def _is_private_endpoint(url: str) -> bool:
    parsed = urlparse(url)
    host = (parsed.hostname or "").lower()
    if not host:
        return False

    if host in {"localhost", "127.0.0.1", "::1"} or host.endswith((".local", ".internal", ".lan")):
        return True

    try:
        address = ip_address(host)
        return address.is_private or address.is_loopback or address.is_link_local
    except ValueError:
        pass

    privileged_terms = ("admin", "deploy", "ops", "root", "writer", "ci")
    if ("prod" in host or "production" in host) and any(term in host for term in privileged_terms):
        return True

    return False


def _url_contains_embedded_credentials(url: str) -> bool:
    parsed = urlparse(url)
    return bool(parsed.username or parsed.password)


def _is_python_backend_reference(value: str, file_name: str, text: str) -> bool:
    escaped = re.escape(value)
    if re.search(rf"\b(?:from|import)\s+{escaped}(?:\b|\s|,|;)", text):
        return True
    return False


def _is_benign_state_storage_name(value: str, file_name: str = "", text: str = "") -> bool:
    normalized = value.lower()
    empty_key = "_".join(("empty", "state"))
    if normalized == empty_key:
        return True
    backend_package = ".".join(("apps", "backend"))
    if normalized == backend_package or normalized.startswith(f"{backend_package}."):
        sensitive_suffixes = {
            "state",
            "".join(("tf", "state")),
            "".join(("back", "end")),
            "lock",
            "".join(("lo", "cks")),
        }
        package_remainder = normalized[len(backend_package) + 1 :]
        has_sensitive_segment = any(segment in sensitive_suffixes for segment in re.split(r"[._-]+", package_remainder))
        return not has_sensitive_segment or _is_python_backend_reference(value, file_name, text)
    return False


def _is_sensitive_env_file_path(path: str) -> bool:
    file_name = re.split(r"[\\/]", path)[-1].lower()
    if not ENV_FILE_NAME.fullmatch(file_name):
        return False
    return not file_name.endswith(ENV_TEMPLATE_SUFFIXES)


def _is_sensitive_credential_config_path(path: str) -> bool:
    file_name = re.split(r"[\\/]", path)[-1].lower()
    if any(
        file_name == f"{name}{suffix}"
        for name in CREDENTIAL_CONFIG_FILE_NAMES
        for suffix in ENV_TEMPLATE_SUFFIXES
    ):
        return False
    return file_name in CREDENTIAL_CONFIG_FILE_NAMES


def _is_sensitive_cloud_credential_path(path: str) -> bool:
    parts = [part.lower() for part in re.split(r"[\\/]+", path) if part]
    if len(parts) < 2:
        return False

    file_name = parts[-1]
    if any(file_name == f"{stem}{suffix}" for stem in CLOUD_CREDENTIAL_FILE_STEMS for suffix in ENV_TEMPLATE_SUFFIXES):
        return False

    file_stem = file_name.split(".", 1)[0]
    return file_stem in CLOUD_CREDENTIAL_FILE_STEMS and any(part in CLOUD_CREDENTIAL_DIR_NAMES for part in parts[:-1])


def _has_template_suffix(file_name: str) -> bool:
    return file_name.endswith(ENV_TEMPLATE_SUFFIXES)


def _is_sensitive_local_credential_path(path: str) -> bool:
    parts = [part.lower() for part in re.split(r"[\\/]+", path) if part]
    if len(parts) < 2 or _has_template_suffix(parts[-1]):
        return False

    for suffix in LOCAL_CREDENTIAL_PATH_SUFFIXES:
        if len(parts) < len(suffix):
            continue
        if tuple(parts[-len(suffix) : -1]) != suffix[:-1]:
            continue
        file_name = parts[-1]
        if file_name == suffix[-1] or file_name.startswith(f"{suffix[-1]}."):
            return True
    return False


def _is_sensitive_ssh_private_key_path(path: str) -> bool:
    parts = [part.lower() for part in re.split(r"[\\/]+", path) if part]
    if len(parts) < 2 or not any(part in SSH_PRIVATE_KEY_DIR_NAMES for part in parts[:-1]):
        return False

    file_name = parts[-1]
    if _has_template_suffix(file_name) or ".pub" in file_name:
        return False

    file_stem = file_name.split(".", 1)[0]
    return file_stem in SSH_PRIVATE_KEY_FILE_STEMS


def _candidate_path_tokens(text: str) -> list[str]:
    return re.findall(r"[^\s`'\"<>()\[\]{},;=:]+", text)


def _contains_sensitive_local_credential_path(text: str) -> bool:
    candidates = _candidate_path_tokens(text)
    for candidate in candidates:
        normalized = candidate.rstrip(".,:").replace("\\", "/")
        if _is_sensitive_local_credential_path(normalized):
            return True
    return False


def _contains_sensitive_ssh_private_key_path(text: str) -> bool:
    candidates = _candidate_path_tokens(text)
    for candidate in candidates:
        normalized = candidate.rstrip(".,:").replace("\\", "/")
        if _is_sensitive_ssh_private_key_path(normalized):
            return True
    return False


def _scan(lines: list[tuple[str, int | None, str]]) -> list[tuple[str, int | None, str]]:
    findings: list[tuple[str, int | None, str]] = []
    for file_name, line_no, text in lines:
        if line_no is None and _is_sensitive_env_file_path(text):
            findings.append((file_name, line_no, "env-file-path"))
            continue
        if line_no is None and _is_sensitive_credential_config_path(text):
            findings.append((file_name, line_no, "credential-config-path"))
            continue
        if line_no is None and _is_sensitive_cloud_credential_path(text):
            findings.append((file_name, line_no, "cloud-credential-path"))
            continue
        if line_no is None and _is_sensitive_local_credential_path(text):
            findings.append((file_name, line_no, "local-credential-path"))
            continue
        if line_no is None and _is_sensitive_ssh_private_key_path(text):
            findings.append((file_name, line_no, "ssh-private-key-path"))
            continue
        if _contains_sensitive_local_credential_path(text):
            findings.append((file_name, line_no, "local-credential-path"))
            continue
        if _contains_sensitive_ssh_private_key_path(text):
            findings.append((file_name, line_no, "ssh-private-key-path"))
            continue
        for rule in RULES:
            if rule.name == "url":
                for match in rule.pattern.finditer(text):
                    url = match.group(0)
                    if _url_contains_embedded_credentials(url):
                        findings.append((file_name, line_no, "url-embedded-credentials"))
                        break
                    if _is_private_endpoint(url):
                        findings.append((file_name, line_no, "private-endpoint-url"))
                        break
                continue
            if rule.name == "state-storage-name":
                if any(
                    not _is_benign_state_storage_name(match.group(0), file_name, text)
                    for match in rule.pattern.finditer(text)
                ):
                    findings.append((file_name, line_no, rule.name))
                    break
                continue
            if rule.pattern.search(text):
                findings.append((file_name, line_no, rule.name))
                break
    return findings


def _path_contains_sensitive_metadata(path: str) -> bool:
    if (
        _is_sensitive_env_file_path(path)
        or _is_sensitive_credential_config_path(path)
        or _is_sensitive_cloud_credential_path(path)
        or _is_sensitive_local_credential_path(path)
        or _is_sensitive_ssh_private_key_path(path)
    ):
        return True
    for rule in RULES:
        if rule.name == "url":
            for match in rule.pattern.finditer(path):
                url = match.group(0)
                if _url_contains_embedded_credentials(url) or _is_private_endpoint(url):
                    return True
            continue
        if rule.name == "state-storage-name":
            if any(not _is_benign_state_storage_name(match.group(0), "", path) for match in rule.pattern.finditer(path)):
                return True
            continue
        if rule.pattern.search(path):
            return True
    return False


def _format_location(file_name: str, line_no: int | None) -> str:
    safe_file_name = "<redacted-sensitive-path>" if _path_contains_sensitive_metadata(file_name) else file_name
    return f"{safe_file_name}:{line_no}" if line_no else safe_file_name


def main() -> int:
    parser = argparse.ArgumentParser(description="Scan Git diff additions or outbound text for sensitive cloud values.")
    parser.add_argument("--base", default="origin/main", help="Base ref for branch diff scans.")
    parser.add_argument("--cached", action="store_true", help="Scan staged additions instead of base...HEAD.")
    parser.add_argument("--file", type=Path, help="Scan a PR, issue, or comment body file.")
    args = parser.parse_args()

    if args.file:
        lines = _file_lines(args.file)
    else:
        diff = _run_git_diff(args.base, args.cached)
        if diff is None:
            return 2
        lines = _changed_lines(diff)
    findings = _scan(lines)
    if findings:
        print(f"sensitive-scan: FAIL ({len(findings)} finding(s))")
        for file_name, line_no, rule_name in findings:
            location = _format_location(file_name, line_no)
            print(f"  - {location}: {rule_name}")
        return 1

    print("sensitive-scan: PASS (0 findings)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
