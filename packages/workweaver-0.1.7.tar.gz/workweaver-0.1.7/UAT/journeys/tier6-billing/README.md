# Tier 6 — Settings + Billing (J60–J69)

Profile, auth identities, subscription, tenant users, Stripe webhook flow.

---

## J60 — Profile API

**Strict assertions:**
- `GET /api/v1/settings/profile` → 200
- Body has `display_name`, `email`, `created_at`, `tenant_id`

---

## J61 — Auth identities list

**Strict assertions:**
- `GET /api/v1/settings/auth-identities` → 200
- Body has `identities` array
- Each identity has `provider`, `subject_id`, `linked_at`

**Note:** SMS OTP NOT supported (per #1322); ensure no SMS provider in list.

---

## J62 — Stripe webhook → tenant provision

**Primitive:** `POST /api/stripe/webhooks`.
**Status:** LIVE+TESTED.

**Strict assertions:**
- POST with `payment_intent.succeeded` from Stripe test mode → 200
- Idempotent on retry (same event_id processed once)
- Tenant subscription transitions to ACTIVE
- Outbox row written (durability)
- Evidence event `payment_completed` recorded

**Silent-failure check:** Outbox count_delta = 1 on first attempt, 0 on retry.

---

## J63 — Subscription status

**Strict assertions:**
- `GET /api/v1/billing/workspace/{tenant_id}/current` → 200
- Body has `plan`, `status` ∈ {trial, active, past_due, cancelled, grace_period}
- `current_period_end` ISO8601

---

## J64 — Tenant users list

**Strict assertions:**
- `GET /api/v1/settings/tenant/users` → 200
- Body has `users` array (length ≥ 1 for sandbox)
- Each user has `id`, `email`, `org_role`

---

## Roadmap J65–J69

Reserved for: invoice list, payment method update, plan change UI, trial → paid upgrade.

For deeper Stripe coverage see [chrome/T14](../../chrome/README.md).
