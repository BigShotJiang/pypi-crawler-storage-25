# Tier 1 — Core Primitives (J10–J19)

API health + auth + canonical-list endpoints. The "is the engine running" tier.

Migrated with strict-assertion upgrades from `.claude/uat/UAT-SUITE.md § Tier 2`.

---

## J10 — API health check

**Primitive:** Public health endpoint.
**Status:** LIVE+TESTED.
**Strict assertions:**
- `GET https://workweaver.ai/health` → 200 (not 200|503)
- Body contains `{ "status": "ok" | "ready" }`
- `x-served-from: live` (not cached)

---

## J11 — Auth session valid

**Primitive:** `GET /api/v1/auth/me`.
**Status:** LIVE+TESTED.
**Strict assertions:**
- Status 200
- Body has `tenant_id` (string, non-empty)
- Body has `user_id`
- Body has `email`
- Body has `org_role` ∈ {OWNER, SUB_TENANT}

**Silent-failure check:** No cached stale auth (`x-served-from: live`).

---

## J12 — Goal list responds

**Primitive:** `GET /api/v1/goals`.
**Status:** LIVE+TESTED.
**Strict assertions:**
- Status 200
- Body is JSON array (may be empty)
- If non-empty: each row has `id` matching `^goal_[0-9a-z]{16}$`
- Pagination header present if rows > 1 page

---

## J13 — Task list responds

**Strict assertions:**
- Status 200
- Body is JSON array
- Each task has `id`, `state` ∈ {pending, running, completed, failed, cancelled}, `goal_id` (or null), `revision` (int)

---

## J14 — Time blocks responds

**Strict assertions:**
- Status 200
- Body has `time_blocks` array
- Each block has `id`, `canonical_hour_bucket` (ISO8601 UTC), `state`, `phase`, `outcome`

---

## J15 — Pulse responds

**Strict assertions:**
- Status 200
- Body has `tenant_id`, `pulse_score` (0..1), `last_pulse_at`

---

## J16 — Connector catalog loads

**Primitive:** `GET /api/v1/connectors/catalog`.
**Status:** LIVE+TESTED.
**Strict assertions:**
- Status 200
- Body has `connectors` array, length ≥ 6 (Tier 1 connectors)
- Each connector has `id`, `name`, `auth_type` ∈ {oauth2, api_key, mcp_passthrough, device_code}

---

## J17 — Memory journal responds

**Strict assertions:**
- Status 200
- Body has `entries` array
- Each entry has `id`, `kind` ∈ {insight, pattern, anti_pattern, entity, heuristic, precedent, fact}, `created_at`

---

## J18 — Memory facts responds

**Strict assertions:**
- Status 200
- Each fact has `id`, `confidence` (0..1), `provenance` (non-empty)

---

## J19 — Billing workspace responds

**Strict assertions:**
- Status 200 OR 404 (no billing yet acceptable for free tier)
- If 200: body has `tenant_id`, `plan`, `status`, `current_period`
- If 404: body has explicit `error: no_billing_workspace`
- Forbidden: silent 200 with empty body

---

## Migration

Original assertions accepted `200 OR 404` permissively. Strict version: 200 OR 404 only (with body shape required for each); never 503.
