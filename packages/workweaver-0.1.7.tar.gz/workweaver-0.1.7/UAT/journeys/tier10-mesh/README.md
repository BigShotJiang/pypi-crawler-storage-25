# Tier 10 — Mesh + Orchestration (J100–J199)

Agent instances, swarm execution, agent ledger, swarm capacity, Zara foreground responsiveness, skills surface, evolution queue, ACP daemon contract.

---

## J100 — Agent instances list

**Strict assertions:**
- `GET /api/v1/mesh/agents` → 200
- Body has `agents` array
- Each agent has `id`, `kind`, `state`, `capability_scope`

---

## J101 — Mesh discovery

**Strict assertions:**
- `GET /api/v1/mesh/discover` → 200
- Returns reachable agents in same tenant + sub-tenants under lease

---

## J102 — Supervisor status

**Strict assertions:**
- `GET /api/v1/mesh/supervisor/status` → 200
- Reports active swarms, capacity, recent halt events

---

## J103 — Agent work ledger

**Strict assertions:**
- `GET /api/v1/mesh/agents/{id}/ledger` → 200
- Each ledger row has `event_id`, `kind`, `timestamp`

---

## J104 — Swarm execution limits

**Primitive:** Tenant capacity envelope.
**Status:** LIVE+TESTED.
**Strict assertions:**
- `GET /api/v1/swarm/capacity` → 200
- Body has `max_concurrent`, `budget_usd`, `current_concurrent`, `current_spend`
- POST swarm exceeding `max_concurrent` → rejected with `swarm_capacity_exceeded`

---

## J105 — Zara foreground responsiveness

**Strict assertions:**
- During swarm execution, foreground Zara still responds within 1 s p95
- Background swarm has `foreground_reservation_respected: true` evidence

---

## J106 — Skills list surface

**Strict assertions:**
- `GET /api/v1/skills` → 200
- Body has `skills` array
- Each skill has `id`, `status`, `capability_class`, `risk_class`

---

## J107 — WorkMemory lint

**Strict assertions:**
- `GET /api/v1/memory/lint?tenant=<x>` → 200
- Body has `issues` array (may be empty)
- Each issue has `kind`, `affected_id`, `severity`

---

## J108 — Skill evolution queue

**Strict assertions:**
- `GET /api/v1/skills/evolution-queue` → 200
- Each candidate has `proposed_skill_id`, `crystallization_state`, `proof_bundle_completeness`

---

## J109 — Agent capacity by org

**Strict assertions:**
- `GET /api/v1/org/{org_id}/capacity` → 200 (when caller is in org)
- 403 with `org_capacity_cross_org_denied` when caller is not in org (see [multi-tenant/M003](../multi-tenant/README.md#m003--cross-org-denial-writeread-attempt-codexs-j114))

---

## J110 — Swarm execution end-to-end

**Strict assertions:**
- POST swarm → 202
- Poll swarm completion → state: completed
- Each agent emits its own evidence trail (not just aggregate)
- Decision traces show admission per agent
- Stigmergy via PrimitiveLedger persists

---

## J111 — Approval gate flow

**Strict assertions:**
- An action with REQUIRE_APPROVAL verdict emits an approval-pending item
- User accepts → action proceeds
- User rejects → action transitions to `cancelled`
- Both paths leave audit trail

---

## J112 — Skill resolver match in real run

**Strict assertions:**
- Request with phrasing matching skill X's triggers → resolver invokes X
- Resolver decision recorded in evidence
- X executes within capability budget

---

## J124 — ACP daemon JSON-RPC contract (GLM's J124)

**Primitive:** `apps/cli/ww/acp_daemon.py`.
**Status:** LIVE+TESTED.

**Mode:** SHADOW.

**Setup:** Spawn `ww acp start` as subprocess; communicate over stdio.

**Strict assertions:**
- `initialize` → response with capability map (`{tools, prompts, resources}`)
- `agent/run` with valid request → response with `subscription_token`
- `agent/stream` with token → yields ≥ 1 chunk
- `agent/cancel` → halts cleanly with `cancelled: true`
- `shutdown` → exit code 0

**Silent-failure check:** Cancellation actually stops downstream work (no zombie connector calls after cancel).

---

## J125 — WorkMemory tier promotion (GLM's J125)

**Primitive:** L1 → L2 → L3 → L4 promotion.
**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Setup:** Seed 5 raw L1 facts.

**Strict assertions:**
- L1 facts present
- Trigger calibration → L2 derived entries created
- Trigger precedent detection → L3 emerges
- Each promotion is observable + traceable in evidence

---

## J126 — Evidence WORM immutability (GLM's J126; cross-link to A002)

See [adversarial/A002](../adversarial/README.md#a002--worm-evidence-poison-pill-geminis-j-adv-03--codexs-j123-silent-failure-detector). J126 is the smoke surface (PUT/DELETE return 405).

---

## J127 — Decision trace alternatives (GLM's J127; cross-link to W001)

See [whitebox-depth/W001](../whitebox-depth/README.md#w001--decision-trace-contains-alternatives_considered--2). J127 is the smoke surface.

---

## J128 — Capability lease sub-tenant (GLM's J128; cross-link to M002)

See [multi-tenant/M002](../multi-tenant/README.md#m002--capability-lease-scope-enforcement). J128 is the smoke surface.

---

## J129 — Connector fallback chain (GLM's J129) (PARTIAL)

See [ROADMAP.md § Auto-fallback](../../ROADMAP.md#auto-fallback-when-native--rest--mcp-all-unavailable-1885).

**Blocked by missing:** #1885.

---

## J130 — Swarm budget hard-stop (GLM's J130)

**Primitive:** Swarm budget enforcement.
**Status:** LIVE+UNTESTED.

**Setup:** Sandbox swarm with $5 budget.

**Strict assertions:**
- Spend approaches $5 → swarm halt + evidence
- No further connector calls after halt
- No zombie workers
- Halt reason recorded as `swarm_budget_exceeded`

---

## J131 — Voice provider failover (GLM's J131)

**Status:** LIVE+UNTESTED.

**Strict assertions:**
- Twilio degraded → routing to xAI grok-voice
- Call continuity preserved
- Failover event recorded

---

## Roadmap J132–J199

Reserved for: cross-region mesh, capacity rebalancing, supervisor restart, telemetry rollup, swarm tracing visualization.
