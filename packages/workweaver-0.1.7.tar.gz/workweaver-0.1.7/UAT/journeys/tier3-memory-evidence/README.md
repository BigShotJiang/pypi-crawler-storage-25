# Tier 3 — Memory + Evidence (J30–J39 + WB01–WB12)

WorkMemory recall, evidence ledger, decision traces. Whitebox AI presence checks (WB01–WB10) plus retrievability (WB11) and contestability surface presence (WB12).

Migrated with strict-assertion upgrades.

---

## J30 — Memory write

**Primitive:** `POST /api/v1/remember`.
**Status:** LIVE+TESTED.
**Strict assertions:**
- Status 201
- Body has `memory_id`, `evidence_id`
- Both IDs match expected pattern
- Evidence event `memory_written` count_delta = 1

---

## J31 — Memory recall returns cited results

**Strict assertions:**
- Status 200
- Each result has `entry_id`, `confidence` (0..1), `provenance` (non-empty), `evidence_refs`
- At least one result for known seed query

---

## J32 — Embedding provenance recorded

**Strict assertions:**
- Memory entry has `embedding_provenance` field
- Provenance includes `model`, `version`, `created_at`

---

## J33 — Forget endpoint quarantines (does not hard-delete)

**Strict assertions:**
- POST `/forget` with memory_id → 200
- Memory queryable with `?include_quarantined=true`
- Memory NOT in default recall results
- Evidence event `memory_forget_quarantine` recorded

---

## J34 — Decision trace API responds

**Strict assertions:**
- Status 200
- Body has `decision_id`, `subject_id`, `alternatives_considered`, `evidence_refs`, `policy_envelope_version`

---

## J35 — Memory dock UI renders

**Mode:** REPLAY (gstack browse).
**Strict assertions:**
- Memory dock visible in Mission Control
- At least one entry rendered for sandbox tenant with seeded memory
- Click expands entry detail without console errors

---

## J36 — Evidence ledger query

**Strict assertions:**
- `GET /api/v1/evidence?subject_id=<x>` → 200
- Returns ordered by created_at
- Each event has `event_id`, `kind`, `payload`, `actor`, `created_at`, `content_hash`

---

## WB01 — Evidence ledger node + edge present

**Strict assertions:**
- After action: evidence ledger has node for the action and edges to related artifacts
- Graph traversal API returns connected subgraph

---

## WB02 — Journal carries agent_id + timestamp

**Strict assertions:**
- Each journal entry has `actor.agent_id` (if agent), `actor.user_id` (if human), `timestamp` ISO8601 UTC

---

## WB03 — Memory facts carry provenance

**Strict assertions:**
- Each memory fact has provenance source (URL, document_id, evidence_id)
- Provenance is non-empty

---

## WB04 — Patterns carry confidence

**Strict assertions:**
- Pattern entries have `confidence` (0..1)
- Pattern includes `support_count` (number of corroborating instances)

---

## WB05 — `remember` returns evidence_id

**Strict assertions:** see J30.

---

## WB06 — Memory search is citeable

**Strict assertions:**
- Each search result has `evidence_refs` linking to ledger
- Following `evidence_refs[0]` returns the evidence

---

## WB07 — Decision traces queryable

**Strict assertions:** see J34.

---

## WB08 — Evidence timeline queryable

**Strict assertions:**
- `GET /api/v1/evidence/timeline?subject_id=<x>&from=<t1>&to=<t2>` → 200
- Time-bounded query returns only events in window

---

## WB09 — Task creation audit trail

**Strict assertions:**
- Task creation produces evidence chain: trace → events → memory → connector
- Chain queryable via decision_trace_map

---

## WB10 — Planning proposal traceability

**Strict assertions:**
- Plan emission produces decision trace
- Trace links to underlying interview artifact (if from interview)

---

## WB11 — Evidence retrievability (GLM's WB11)

**Primitive:** `GET /api/v1/evidence/{evidence_id}`.
**Status:** LIVE+TESTED.

**Intent:** Write evidence via WB05; read back via direct evidence_id lookup. Retrieved content matches written byte-for-byte.

**Strict assertions:**
- After WB05: `GET /api/v1/evidence/<evidence_id>` returns 200
- Body's `payload` byte-equals what was written
- `content_hash` matches sha256 of payload

**Silent-failure check:** No silent truncation, no encoding drift.

---

## WB12 — Decision contestability surface presence (PARTIAL)

**Primitive:** Contestability API.
**Status:** PARTIAL.

See [whitebox-depth/W005](../whitebox-depth/README.md#w005--decision-contestability-flow-partial--blocked) for the full flow.

WB12 here is just the surface presence check: `GET /api/v1/decisions/<id>/contestation-status` returns 200 (or explicit 404 with `feature_not_yet_available`).

**Blocked by missing:** #CONTEST-001.
