# Tenant Support Journeys (TS-001–TS-099)

Issue reporting from a tenant. Multiple intake surfaces (UI, CLI, MCP, voice via Zara). Admin triage in admin.workweaver.ai with full repro + decision-trace context. End-to-end customer-support contract.

Per [SELF-CONTAINED-FAILURE.md](../../SELF-CONTAINED-FAILURE.md), every journey here that depends on a `PARTIAL` or `ASPIRATIONAL` primitive carries a full build-kit: schemas, files to create, acceptance criteria, edge cases, evidence shape.

---

## TS-001 — Tenant opens issue via API (P0)

**Primitive:** `tenant.support.intake.api`.
**Status:** ASPIRATIONAL.
**Mode:** SHADOW, LIVE.
**Sandbox:** per-run (`uat-<run>-customer-org`).

**Intent:** Authenticated tenant POSTs to `/api/v1/support/issues` with a complete `TenantSupportTicket` payload. The system validates schema, persists, emits one evidence event, and returns the ticket_id.

**Strict assertions:**
- Status 201
- Body contains `ticket_id` matching `^tk_[0-9a-z]{16}$`
- Body has `state: "open"`, `created_at` ISO8601 UTC
- Evidence event `support_ticket_created` count_delta = 1
- Decision trace recorded (rate_limit + tenant_pause sub-verdicts present, both ALLOW)

**Silent-failure check:**
- `support_tickets` row count delta = 1
- Revision delta = 1
- No silent fallback path (`expected_path: api.native`)

**`blocked_by_missing`:** `#TENANT-SUPPORT-001`.

**`build_instructions`:** see [SELF-CONTAINED-FAILURE.md § build_instructions shape](../../SELF-CONTAINED-FAILURE.md#build_instructions-shape) — that's the canonical worked example for this journey.

**`acceptance_criteria`:**
- `ticket_created_via_api` — POST 201 + ticket_id
- `ticket_visible_to_owner_only` — GET filters to tenant scope
- `parity_across_surfaces` — UI/CLI/MCP/API produce same ticket_id namespace
- `tenant_pause_blocks` — suspended tenant → 423 `tenant_paused`
- `rate_limit_enforced` — 101st ticket/hour → 429

**`edge_cases`:**
1. Two clients open ticket with same title within 1 second → both succeed, no silent merge
2. User attaches evidence_id from a different tenant → 403 with `cross_tenant_evidence_attempt`
3. Tenant erasure → ticket persists for retention; PII redacted
4. Free plan tenant exceeds monthly free-tier ticket count → 402 with upgrade CTA
5. Empty body / null fields → 422 with field-level errors
6. Title > 200 chars → 422 with `title.too_long`
7. Description > 10000 chars → 422 with `description.too_long`

**Evidence:** see [SELF-CONTAINED-FAILURE.md § How it shows up in the run report](../../SELF-CONTAINED-FAILURE.md#how-it-shows-up-in-the-run-report).

---

## TS-002 — Tenant opens issue via CLI

**Primitive:** `tenant.support.intake.cli`.
**Status:** ASPIRATIONAL.
**Mode:** SHADOW.

**Intent:** `ww support open --kind bug --severity P1 --title "..." --description "..." --repro-step "..." --repro-step "..." --expected "..." --actual "..."` produces a ticket identical to TS-001's API path.

**Strict assertions:**
- CLI exit code 0
- Stdout contains `ticket_id`
- `ww support list` includes the new ticket
- Same DynamoDB row as TS-001's API path

**`build_instructions`:**
```yaml
files_to_create:
  - path: apps/cli/ww/commands/support.py
    purpose: |
      Click command group `ww support` with subcommands open, list, show, close.
      Open subcommand collects flags, builds TenantSupportTicket payload,
      invokes POST /api/v1/support/issues, prints result.
    reference: apps/cli/ww/commands/mission.py (similar shape)
files_to_modify:
  - path: apps/cli/ww/__init__.py
    change: register support command group
acceptance_criteria:
  - name: cli_help_includes_support
    test: "ww --help lists 'support' subcommand"
  - name: cli_open_creates_ticket
    test: "ww support open with valid flags exits 0 and prints ticket_id"
  - name: cli_offline_queues
    test: "ww support open in offline mode queues locally and syncs on reconnect (E004 pattern)"
edge_cases:
  - Multi-line description from heredoc / pipe — preserve line breaks
  - Repro steps via repeated --repro-step flag
  - Attaching local file as evidence — auto-uploads + attaches evidence_id
  - In offline mode, CLI prints a queue receipt with offline_ticket_id
```

---

## TS-003 — Tenant opens issue via MCP

**Primitive:** `tenant.support.intake.mcp`.
**Status:** ASPIRATIONAL.
**Mode:** SHADOW.

**Intent:** Cursor / Claude Code / Codex consuming Workweaver MCP can call `ww.support.open` tool with the same schema as TS-001 and receive ticket_id.

**Strict assertions:**
- MCP tool registered + listable
- Tool call returns `ticket_id`
- Same DynamoDB row as TS-001

**`build_instructions`:**
```yaml
files_to_create:
  - path: apps/backend/api/public_mcp.py (extend existing)
    add_tool: ww.support.open
    schema: same as TenantSupportTicket
    auth: get_verified_tenant_id
    guard: requires_capability=tenant.support.intake
acceptance_criteria:
  - name: mcp_tool_listed
    test: "MCP /tools/list response includes ww.support.open"
  - name: mcp_call_creates_ticket
    test: "MCP tool call with valid input returns ticket_id"
  - name: mcp_schema_drift_detected
    test: "Adding a field to TenantSupportTicket without updating MCP tool schema → drift gate fails"
edge_cases:
  - MCP consumer is itself an LLM agent that emits malformed JSON → schema validation rejects pre-execution (A005 pattern)
  - Connector budget exceeded for MCP consumer → quota error returned to consumer
```

---

## TS-004 — Tenant reports bug via Zara voice intake

**Primitive:** `tenant.support.intake.voice`.
**Status:** PARTIAL (Twilio inbound LIVE+TESTED; voice-bug-intake skill ASPIRATIONAL).
**Mode:** SHADOW.

**Intent:** Customer calls Zara, says "I want to report a bug", Zara guides through structured intake (kind, severity, title, repro steps, expected, actual), creates ticket with caller's voice transcript attached as evidence, available in admin portal.

**Strict assertions:**
- Voice intake flow opens InterviewContract (similar to OKR interview, 4 stages: classify → repro → impact → wrap)
- Final state produces ticket via TS-001 path with `actor.kind: voice_caller`, `attached_evidence_ids: [<call_recording_evidence>, <transcript_evidence>]`
- Decision trace shows alternatives_considered for severity scoring
- Same ticket appears in admin portal with full call transcript + audio link

**`build_instructions`:**
```yaml
files_to_create:
  - path: apps/backend/services/zara/voice_support_intake.py
    purpose: |
      Stage-driven interview specialised for support intake. Stages:
      classify (kind=bug|question|feature_request),
      repro (collect numbered steps),
      impact (severity scoring with examples),
      wrap (confirm + create ticket).
    reference: apps/backend/services/zara/zara_interview_contract.py
  - path: skills/dev/voice-support-intake/SKILL.md
    purpose: Skill definition for voice-driven support intake.
files_to_modify:
  - path: apps/backend/services/zara/zara_interview_contract.py
    change: register voice_support_intake as alternative interview shape
  - path: apps/backend/middleware/grok_tenant_context.py
    change: route phone calls with intent=support to voice_support_intake
acceptance_criteria:
  - name: voice_intake_resolves_to_ticket
    test: "Caller saying 'I want to report a bug' triggers voice_support_intake; final ticket has all required fields"
  - name: voice_recording_attached_as_evidence
    test: "Created ticket has attached_evidence_ids referencing call recording + transcript"
  - name: severity_scoring_judged
    test: "LLM-as-judge rubric: severity assigned matches caller's described impact (rubric in journey body)"
  - name: ticket_visible_in_admin_with_audio
    test: "Admin portal /admin/support/<ticket_id> shows audio playback link + transcript + Zara's interview turn-by-turn"
edge_cases:
  - Caller hangs up mid-intake → ticket marked draft, follow-up via inbox
  - Caller mentions PII (CC, SSN) in transcript → redacted before persist (A011 pattern)
  - Multi-language: caller speaks Spanish → transcription + intake flow in Spanish, ticket persists transcript in original + auto-translated English
  - Caller is on free plan (free voice minutes exhausted) → graceful end-of-call message, ticket via email instead
  - Caller anonymous (no tenant linkage from phone number) → ticket created in system tenant with caller phone marker
```

**Judge rubric (severity scoring):**
- C1: Severity matches described impact (P0 = system down, P1 = major feature broken, P2 = minor, P3 = cosmetic) — 0–10
- C2: Repro steps captured are reconstructable by an engineer — 0–10
- C3: Distinguishes bug from feature request from question correctly — 0–10
- C4: Doesn't escalate caller's frustration — 0–10
- C5: Confirms ticket details before submit — 0–10

Pass: all ≥ 7.

---

## TS-005 — Admin triages ticket in admin.workweaver.ai

**Primitive:** `admin.support.triage`.
**Status:** ASPIRATIONAL.
**Mode:** SHADOW.

**Intent:** Founder/admin opens admin portal, sees inbox of support tickets, opens one, reviews repro steps + evidence chain (decision trace, mission run, connector logs), assigns owner, transitions state, leaves internal note. Tenant gets state-change notification.

**Strict assertions:**
- `GET /api/v1/admin/support/tickets` returns tickets across all tenants
- `GET /api/v1/admin/support/tickets/{id}` returns ticket + evidence chain + decision-trace links
- `POST /api/v1/admin/support/tickets/{id}/transition` with `{to_state: triaging, internal_note: "..."}` succeeds
- Tenant receives notification (inbox event + email if configured)
- All transitions in admin_audit log

**`build_instructions`:** mirror of TS-001 with admin-only auth (`require_founder` or `require_support_role`).

**`acceptance_criteria`:**
- `admin_lists_tickets` — paginated list with filters (state, severity, tenant)
- `admin_views_ticket_full_context` — single page shows: payload, repro steps, evidence chain (decision_trace_id list), connected mission runs, connector logs at the timestamp range
- `admin_transitions_state` — open → triaging → in_progress → resolved → closed
- `admin_internal_notes` — admin notes are NOT visible to tenant (privilege-scoped)
- `admin_assigns_owner` — assignment recorded in audit
- `tenant_notified_on_transition` — every state change emits inbox event + (configured) email
- `parity_admin_ui_cli_mcp_api` — same operations available across surfaces (per [PARITY-CONTRACT.md](../../PARITY-CONTRACT.md))

**`edge_cases`:**
- Admin views ticket with attached PII → admin sees redacted form unless explicit security_review role grants raw access
- Two admins triage same ticket simultaneously → OCC (revision-based) prevents lost updates
- Admin attempts to view ticket from a tenant they don't have authority over → 403 with cross_org_admin_denied (M003 cross-org, but inverted: admin must have authority over tenant_org)
- Closed ticket reopened by tenant → admin notification emitted; reopen counter incremented; tracked metric
- Admin closes ticket the tenant marked as 'still broken' → escalation trace recorded; reopened-by-admin notification

---

## TS-006 — Tenant views own tickets in UI

**Primitive:** `tenant.support.list.ui`.
**Status:** ASPIRATIONAL.

**Intent:** Tenant opens `/runtime/#/support` and sees their own tickets, sortable by state/severity/created_at. Click opens detail with full history.

**Strict assertions:**
- Page title contains `Support`
- List shows only this tenant's tickets (no cross-tenant leak)
- Each row has ticket_id, title, state, severity, created_at
- Click → detail page renders without console errors

**`build_instructions`:**
```yaml
files_to_create:
  - path: apps/dashboard/runtime/support/list.html (or React component)
  - path: apps/dashboard/runtime/support/detail.html
files_to_modify:
  - path: apps/dashboard/runtime/router.js
    change: register /support routes (Cmd+K reachable, NOT primary nav per J03b)
acceptance_criteria:
  - name: support_visible_in_cmdk
    test: "Cmd+K search 'support' returns the support route"
  - name: tenant_sees_own_tickets_only
    test: "Two-tenant fixture: tenant A's UI shows A's tickets only"
  - name: detail_shows_full_history
    test: "Ticket detail shows all state transitions + admin internal notes (only ones marked tenant_visible)"
edge_cases:
  - Empty state when tenant has no tickets — meaningful empty (per A014 pattern)
  - Pagination at >50 tickets
  - Real-time updates: while tenant is viewing list, admin transitions a ticket → UI reflects via SSE within 5s
  - Search by ticket_id, title, or content
```

---

## TS-007 — Issue reporting respects tenant pause

**Primitive:** `tenant.support.intake` + tenant pause.
**Status:** ASPIRATIONAL.
**Mode:** SHADOW.

**Intent:** Suspended tenant attempts to open ticket via any surface → 423 Locked with structured `tenant_paused` reason. The exception: a tenant can ALWAYS open a billing-related ticket even when paused (so they can recover from billing issue).

**Strict assertions:**
- Pause active → 423 for any non-billing kind
- Pause active + kind=billing → 201 (special-cased)
- Audit event `support_ticket_during_pause` recorded

**`edge_cases`:**
- Tenant suspended for security violation → cannot open ticket at all (security tickets go through different escalation; admin reaches out)
- Tenant suspended for non-payment → can open billing ticket only
- Pause lifted mid-attempt → request retried automatically with success

---

## TS-008 — Issue reporting parity across UI/CLI/MCP/API

**Primitive:** `tenant.support.intake` parity.
**Status:** ASPIRATIONAL — depends on TS-001 + TS-002 + TS-003.

**Intent:** All four surfaces produce identical resulting state (same DynamoDB row, same evidence event shape, same error codes for identical inputs).

**Strict assertions:** see [PARITY-CONTRACT.md § Capability runtime parity](../../PARITY-CONTRACT.md#capability-runtime-parity-per-surface).

This journey is the parity gate. Failing this means the four surfaces drifted; the schema-driven generator is the structural fix.

---

## TS-009 — Adversarial: tenant attempts cross-tenant ticket read

**Primitive:** Tenant scope on support tickets.
**Status:** ASPIRATIONAL.
**Mode:** SHADOW.

**Intent:** Tenant A tries `GET /api/v1/support/issues/<tenant_b_ticket_id>` → 403 with `cross_tenant_support_denied`.

**Strict assertions:**
- 403 (not 404 — leaks existence)
- Tenant B's ticket payload not in response body
- Audit event `cross_tenant_support_attempt` recorded

**Silent-failure check:** No partial data leak (response body is exactly the error envelope, no shape revealing tenant B's ticket existed).

---

## TS-010 — Adversarial: AI agent (Zara) opens ticket on behalf of itself

**Primitive:** Self-reflective skill regression reporting.
**Status:** ASPIRATIONAL.

**Intent:** A Zara skill detects its own regression (e.g., gradient-descent loop produced regressed delta-J twice). Zara opens a support ticket on behalf of itself for engineering review.

**Strict assertions:**
- Ticket created with `actor.kind: agent`, `actor.agent_id: zara`
- Ticket auto-tagged for engineering routing
- Skill registry flagged for review
- Decision trace links to skill run that detected the regression

**`build_instructions`:**
```yaml
files_to_modify:
  - path: apps/backend/services/skill_hygiene.py
    change: when MCC < threshold or delta_J regression detected, open self-ticket via TS-001 path with actor.kind=agent
acceptance_criteria:
  - name: zara_self_filed_ticket_visible_to_engineering
    test: "Generated ticket appears in admin portal with auto-engineering label"
  - name: zara_self_ticket_links_to_failing_skill
    test: "Ticket payload includes failing skill_id, skill_run_id, regression delta_J value"
edge_cases:
  - Multiple sequential regressions → dedupe (one ticket per skill_id within 24h, increment counter)
  - Zara's own ticket-creation skill regresses → fail-loud guard prevents infinite recursion
```

---

## Roadmap TS-011–TS-099

Reserved for: SLA tracking, priority escalation, customer satisfaction survey post-close, multi-language ticket localization, tenant-to-tenant ticket sharing under capability_lease, ticket-attached video walkthrough, screen-recording capture, browser console capture from extension, server-side error correlation, internal-only triage notes audit.

---

## Related

- [SELF-CONTAINED-FAILURE.md](../../SELF-CONTAINED-FAILURE.md) — failure-message contract this collection demonstrates
- [PARITY-CONTRACT.md](../../PARITY-CONTRACT.md) — UI=CLI=MCP=API parity for ticketing
- [PRIMITIVES.md](../../PRIMITIVES.md) — to be updated with new `tenant.support.*` primitives once landed
- [ROADMAP.md](../../ROADMAP.md) — until #TENANT-SUPPORT-001 closes
