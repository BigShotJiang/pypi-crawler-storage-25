# Customer Support Journeys (CS-001–CS-099)

End-to-end customer-support workflow: an end customer (of a tenant) reports an issue → tenant's Zara intakes → tenant's admin triages → resolution → close → satisfaction.

This is distinct from [tenant-support/](../tenant-support/) (which covers a TENANT reporting issues to Workweaver). Here the SUBJECT is the tenant's CUSTOMER reporting issues to the tenant's Zara.

---

## CS-001 — End customer phones in with a complaint

**Primitive:** `customer.intake.voice`.
**Status:** PARTIAL (voice LIVE+TESTED; structured complaint intake skill ASPIRATIONAL).
**Mode:** SHADOW.

**Intent:** Customer dials tenant's published phone number, Twilio routes to tenant's Zara, Zara takes the complaint following an InterviewContract specialised for complaint intake (acknowledge → categorize → details → context → wrap), creates a `CustomerInquiry` record visible to tenant's admin.

**Strict assertions:**
- Twilio webhook resolves to correct tenant (J73)
- Zara opens complaint InterviewContract
- `CustomerInquiry` persisted with `tenant_id`, `caller_phone`, `category`, `summary`, `transcript_evidence_id`, `recording_evidence_id`
- Tenant's admin inbox shows the inquiry within 30s of call end

**`blocked_by_missing`:** `#CUSTOMER-INTAKE-001`.

**`build_instructions`:**
```yaml
files_to_create:
  - path: apps/backend/services/zara/customer_complaint_intake.py
    purpose: 5-stage InterviewContract (acknowledge, categorize, details, context, wrap)
  - path: apps/backend/models/customer_inquiry.py
    fields:
      - { tenant_id, caller_phone, category, severity_inferred, summary, transcript_evidence_id, recording_evidence_id, ai_assigned_owner, state, created_at }
files_to_modify:
  - path: apps/backend/middleware/grok_tenant_context.py
    change: route inbound calls to customer_complaint_intake skill when caller is unknown (anonymous customer, not tenant member)
acceptance_criteria:
  - name: anonymous_caller_routes_to_complaint_intake
    test: "Caller without tenant linkage triggers complaint intake (vs OKR interview)"
  - name: inquiry_visible_to_tenant_admin
    test: "Tenant's /admin/customer-inquiries lists the inquiry"
  - name: caller_can_get_status_callback
    test: "Caller provides callback number; Zara records it; tenant admin can trigger Zara to call back with status"
edge_cases:
  - Caller is angry/abusive — Zara remains calm; transcript flagged sentiment=hostile
  - Caller speaks language other than tenant's default — auto-transcribe + auto-translate; preserve original
  - Caller mentions PII — redacted in stored transcript; raw audio kept under tenant retention policy
  - Voice provider failure mid-call (J131) — failover preserves intake context
  - Caller hangs up before wrap — partial inquiry marked draft, Zara follows up via callback if number provided
```

---

## CS-002 — Tenant's Zara summarizes inquiry for admin

**Primitive:** `customer.inquiry.summary`.
**Status:** ASPIRATIONAL.

**Intent:** When admin opens an inquiry, Zara has pre-generated a structured summary (problem, urgency-inferred, customer's expressed need, recommended action) that's the front of the admin's view.

**Strict assertions:**
- Summary is non-empty
- Includes 4 fields above
- Decision trace records alternatives_considered for urgency inference
- LLM-judge rubric on summary quality (rubric below)

**Judge rubric:**
- C1: Captures what the customer is upset about — 0–10
- C2: Captures what the customer wants resolved — 0–10
- C3: Urgency inference is calibrated to the situation — 0–10
- C4: Recommends a concrete next action — 0–10
- C5: Doesn't hallucinate facts not in transcript — 0–10

---

## CS-003 — Admin replies to customer via tenant's Zara

**Primitive:** `customer.inquiry.outbound`.
**Status:** ASPIRATIONAL.

**Intent:** Admin clicks "Have Zara call this customer back with status update" → Zara dials customer at provided callback number, delivers tailored message, records the call, links it to the inquiry.

**Strict assertions:**
- Outbound call placed via Twilio
- Call recording linked to inquiry
- Inquiry state transitions to `customer_notified`
- Customer can press digit to escalate to a human if available

---

## CS-004 — Customer support metrics surface for tenant

**Primitive:** `customer.support.metrics`.
**Status:** ASPIRATIONAL.

**Intent:** Tenant's `/admin/customer-support/metrics` shows: intake volume by day/week, resolution time p50/p95, satisfaction score (post-call survey), repeat-caller rate, top complaint categories.

**Strict assertions:**
- All metric endpoints return JSON
- Computed against last 30/90 days
- Pagination consistent (D8 silent-failure detector)

---

## CS-005 — End customer escalates dissatisfaction

**Primitive:** Escalation path.
**Status:** ASPIRATIONAL.

**Intent:** Customer responds to satisfaction survey with low score → automatic creation of escalation ticket in tenant's admin → tenant's admin sees clearly + can reopen the inquiry chain → customer notified.

**Strict assertions:**
- Low score triggers escalation event
- Escalation event creates linked ticket via TS-001 path with `kind: customer_dissatisfaction`
- Tenant admin notified

---

## Roadmap CS-006–CS-099

Reserved for: chat-based intake, customer self-service portal, knowledge-base auto-suggest, FAQ generation from past inquiries, in-conversation voice tool calling (e.g., look up order status mid-call), CSAT trend analytics.

---

## Related

- [tenant-support/](../tenant-support/) — tenant reporting issues TO Workweaver
- [PERSONAS.md § P-CUSTOMER](../../PERSONAS.md#p-customer--end-customer-via-voice--messaging)
- [PRIMITIVES.md § 10 Voice + payments](../../PRIMITIVES.md#10-voice--payments)
