# Whitebox Depth Journeys (W001–W099)

Decision-trace **utility**, not just presence. The contestability test. Replay determinism. The 5-criterion contract from [PHILOSOPHY.md § 6](../../PHILOSOPHY.md#6-whitebox-traces-must-be-useful-not-merely-present).

These extend the legacy WB01–WB10 (which check presence) with depth.

---

## W001 — Decision trace contains alternatives_considered ≥ 2

**Primitive:** Decision capture + trace API.

**Status:** LIVE+TESTED.

**Mode:** REPLAY, SHADOW.

**Sandbox:** per-run.

**Intent:** A non-trivial action (e.g., choosing a connector path) emits a decision trace whose `alternatives_considered` array has ≥ 2 entries, each with rationale and rejection reason.

**Steps:**
1. Sandbox: tenant with multiple connector options for `email.send` (e.g., gmail, fallback)
2. Trigger `POST /missions/<id>/run` with action `send_email`
3. GET `/api/v1/evidence/<subject_id>/trace`

**Strict assertions:**
- `alternatives_considered.length >= 2`
- Each alternative has `rationale` (non-empty), `rejection_reason` (non-empty)
- `chosen_alternative.id` present and matches one of the listed
- Confidence scores present
- Evidence refs resolve to immutable artifacts (hash check)

---

## W002 — Hydrated decision trace returns evidence refs that resolve

**Primitive:** Hydrated trace API.

**Status:** LIVE+TESTED.

**Mode:** REPLAY, SHADOW.

**Intent:** A hydrated decision trace embeds the actual evidence artifacts. Each evidence_ref must resolve to its content; hash matches.

**Steps:**
1. Trigger an action that writes 3 evidence events
2. GET `/api/v1/evidence/<subject_id>/trace?hydrate=true`
3. For each `evidence_refs[i]`: hash the embedded payload, compare to `evidence_refs[i].content_hash`

**Strict assertions:**
- All embedded payloads hash to declared `content_hash`
- All embedded artifacts have non-zero size
- No `evidence_ref` is null or unresolved

---

## W003 — Strategic decision trace returns rollup

**Primitive:** Strategic decision trace.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Intent:** A goal-level strategic decision trace rolls up underlying tactical traces with deduplication and impact scoring.

**Strict assertions:**
- Strategic trace covers all tactical traces under the goal
- No duplicate tactical references
- Impact_score normalized [0, 1]

---

## W004 — Decision trace map across multi-step plan

**Primitive:** DecisionTraceMap (`apps/backend/services/zara/decision_trace_map.py`).

**Status:** LIVE+TESTED.

**Mode:** SHADOW.

**Intent:** A multi-step plan's decision trace map serializes the dependency graph correctly: each step's decision references prior steps it depended on.

**Strict assertions:**
- `decision_trace_map.nodes.length` equals number of steps
- Edges form a DAG (no cycles)
- Each edge has `dependency_kind` (e.g., `data_dependency`, `policy_gate`)

---

## W005 — Decision contestability flow (PARTIAL → blocked)

**Primitive:** Contestation API.

**Status:** PARTIAL.

**Mode:** SHADOW.

**Intent:** A user contests an existing decision. The system creates a `revised_decision_trace_id` linked via `derived_from`, scores both alternatives, and updates confidence.

**Steps:**
1. Existing decision D1 with chosen alternative A
2. POST `/api/v1/decisions/<D1.id>/contest` with body `{counter_alternative: B, rationale: "..."}`
3. GET `/api/v1/evidence/<subject_id>/trace`

**Strict assertions:**
- D1 marked `contested`
- New trace D2 created with `derived_from=D1`
- D2's `alternatives_considered` includes both A and B
- D2 chosen alternative may match A or B (system re-decides; user does not pick directly)
- Confidence scores updated

**Blocked by missing:** #CONTEST-001 — contestability API not yet exposed. Grace until issue closes.

---

## W006 — Decision-trace replay determinism

**Primitive:** Replay against pinned policy envelope.

**Status:** PARTIAL.

**Mode:** SHADOW.

**Intent:** Replay D1 against same policy_envelope_version. Reproduces same decision OR returns `policy_drift_blocked`.

**Steps:**
1. Decision D1 emitted at policy_envelope_version v3
2. POST `/api/v1/decisions/<D1.id>/replay` with envelope=v3
3. POST `/api/v1/decisions/<D1.id>/replay` with envelope=v4 (newer)

**Strict assertions:**
- v3 replay: same chosen alternative, same evidence trail
- v4 replay: returns 409 with `policy_drift_blocked`, NOT silent re-execution
- Evidence event `decision_replay_attempted` per replay

**Blocked by missing:** #REPLAY-DET-001.

---

## W007 — Policy envelope every sub-verdict

**Primitive:** PolicyDecisionEnvelope.

**Status:** LIVE+TESTED.

**Mode:** REPLAY.

**Intent:** Every governed action emits an envelope with all 10 sub-verdicts (identity, tool_scope, connector_scope, budget, risk_tier, approval, evolution, tenant_pause, side_effect_proof, on_chain_write).

**Strict assertions:**
- All 10 sub-verdict names present
- Each has verdict in {ALLOW, REQUIRE_APPROVAL, DENY, NOT_APPLICABLE}
- Final verdict consistent with sub-verdicts (any DENY → DENY; any REQUIRE_APPROVAL → REQUIRE_APPROVAL; else ALLOW)

---

## W008 — Override audit trail (PARTIAL)

**Primitive:** Manual override audit.

**Status:** PARTIAL.

**Mode:** SHADOW.

**Intent:** When a human overrides a policy verdict, an audit trail captures actor, justification, timestamp, original verdict, override verdict.

**Strict assertions:**
- Override event recorded with all fields
- Original decision still queryable
- Override surfaces in audit log

**Blocked by missing:** #OVERRIDE-AUDIT-001.

---

## W009 — Decision trace alternatives via judge rubric

**Primitive:** Decision quality.

**Status:** LIVE+TESTED.

**Mode:** SHADOW.

**Sandbox:** per-run.

**Intent:** A trace's alternatives_considered array represents real, considered alternatives — not template stuffing. LLM judge scores quality.

**Judge rubric:**
- C1: Alternatives are distinct (not paraphrases of one) — 0–10
- C2: Each alternative has a defensible rationale — 0–10
- C3: Rejection reasons are technical (not "just because") — 0–10
- C4: Chosen alternative is at least mid-pack defensible — 0–10
- C5: User reading this trace can understand why — 0–10

Pass: all ≥ 7.

---

## W010 — Decision impact aggregation

**Primitive:** Decision impact rollup.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Intent:** Decisions can be queried by impact (low / medium / high / critical) and the aggregation matches per-decision tagging.

**Strict assertions:**
- `GET /decisions?impact=critical` returns subset where each item has `impact: critical`
- Total of all impact-level subsets equals total decisions
- No decision in two impact buckets

---

## Roadmap W011–W099

Reserved for: decision-trace-as-graph rendering, audit-log search by actor type, override frequency analytics, evolution-aware trace, on-chain decision ledgering.

---

## Related

- [PRIMITIVES.md § 3 Evidence Ledger + Decision Trace](../../PRIMITIVES.md#3-evidence-ledger--decision-trace-whitebox-surface)
- [PHILOSOPHY.md § 6 Whitebox traces must be useful](../../PHILOSOPHY.md#6-whitebox-traces-must-be-useful-not-merely-present)
- [LLM-AS-JUDGE.md](../../LLM-AS-JUDGE.md)
