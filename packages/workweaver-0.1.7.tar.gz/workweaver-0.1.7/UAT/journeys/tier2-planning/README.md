# Tier 2 — Multi-Step Planning (J20–J29)

Goal/task/timeblock CRUD + plan emission. Migrated with strict-assertion upgrades.

---

## J20 — Create goal

**Primitive:** `POST /api/v1/mission/goals`.
**Status:** LIVE+TESTED.

**Strict assertions:**
- Status 201
- Body has `goal_id` matching `^goal_[0-9a-z]{16}$`
- Body has `title`, `target_metric`, `deadline`, `goal_type`
- Captured `goal_id` for downstream

**Silent-failure check:** revision_delta = 1.

---

## J21 — List goals includes created goal

**Strict assertions:**
- Status 200
- Body array contains the captured `goal_id`
- Order is consistent with `?sort=created_at:desc`

---

## J22 — Create task under goal

**Strict assertions:**
- Status 201
- `task_id` returned
- `goal_id` field equals captured
- TimeBlock auto-created with `state: planned`

---

## J23 — Task state transitions

**Strict assertions:**
- POST `/tasks/{id}/start` → `state: running`
- POST `/tasks/{id}/complete` → `state: completed`, `outcome` populated
- All transitions emit evidence event

---

## J24 — TimeBlock productivity_score updates

**Primitive:** TimeBlock value tier.
**Status:** LIVE+UNTESTED.

**Strict assertions:**
- After task completes, TimeBlock has `value_tier` ∈ {high, medium, low, zero, negative}
- TimeBlock has `productivity_score` numeric
- Mission Calendar reflects score

---

## J25 — Mission Calendar dashboard bundle

**Primitive:** `GET /api/v1/mission/dashboard-bundle`.
**Status:** LIVE+TESTED.

**Strict assertions:**
- Status 200
- Body has `kpis`, `work_items`, `activity`, `auth_expiry`
- `cache_age_seconds` ≤ 10 (private cache)

---

## J26 — Planning proposal endpoint emits CompositionPlan

**Primitive:** `POST /api/v1/zara/plan`.
**Status:** LIVE+UNTESTED. **Upgraded:** original asserted 200/202/422/503 (just "responds"). Strict version asserts the full CompositionPlan envelope.

**Strict assertions:**
- Status 201 (new plan) OR 200 (idempotent re-fetch)
- Body has `plan_id`
- Body has `composition_plan.shape` ∈ {single_pass, linear_chain, role_swarm_360, simulation, role_play, hybrid}
- Body has `composition_plan.steps`, length ≥ 1
- Evidence event `composition_plan_emitted` count_delta = 1
- LLM-as-judge rubric (Z003-style) optional

**Silent-failure check:** No silent 503 acceptance. Cold-start grace allowed once via `grace_event` linked to #ZARA-COLD-START-001.

---

## Roadmap J27–J29

Reserved for: plan revision flow (J27), gradient compute (J28), variance analysis (J29).
