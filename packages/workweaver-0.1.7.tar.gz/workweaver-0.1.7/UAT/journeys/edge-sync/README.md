# Edge ↔ Cloud Sync Journeys (E001–E099)

Two-node deterministic replay. Revision-OCC + per-field CRDT. The most subtle bug class in Workweaver, exercised here at full depth.

---

## E001 — Single-client offline edit, reconnect, sync

**Primitive:** Edge sync engine.

**Status:** LIVE+TESTED.

**Mode:** REPLAY, SHADOW.

**Sandbox:** per-run, single sync client.

**Intent:** Single client edits TimeBlock offline, reconnects, syncs. State converges with no data loss.

**Steps:**
1. Provision sandbox tenant with TimeBlock T at revision r0
2. Client A goes offline
3. Client A: PATCH T (label = "deep work")
4. Client A reconnects
5. Client A: GET sync/status
6. Cloud: GET timeblocks/T

**Strict assertions:**
- Cloud reflects label = "deep work"
- Revision incremented (r1)
- Single sync_event evidence record
- No data loss

---

## E002 — Cloud-first edit, sync to edge

**Primitive:** Cloud → edge sync direction.

**Status:** LIVE+TESTED.

**Steps:**
1. Cloud edit TimeBlock T (label = "review")
2. Edge client comes online
3. Edge syncs

**Strict assertions:**
- Edge SQLite mirror reflects "review"
- Sync direction recorded in evidence

---

## E003 — Two clients, parallel offline edits, reconnect (Codex's #J116)

**Primitive:** OCC 409 + CRDT fallback.

**Status:** LIVE+TESTED.

**Mode:** REPLAY, SHADOW.

**Sandbox:** per-run, two clients (A, B).

**Intent:** Both clients go offline. Each edits TimeBlock T. Both reconnect. Conflict resolution must be deterministic.

**Steps:**
1. T at revision r0 on both A and B
2. Both go offline
3. A: PATCH T (label = "X")
4. B: PATCH T (label = "Y")
5. A reconnects → push (no conflict yet, server commits A)
6. B reconnects → push detects OCC conflict
7. CRDT merge fallback fires
8. Both clients pull → final state

**Strict assertions:**
- Final state deterministic (defined by CRDT contract)
- Both A and B converge to same final value
- Revision count r0 + 2 (not r0 + 3, no double-commit)
- Two evidence events: `sync_commit_A`, `sync_merge_B_conflict`
- Decision trace alternatives include both A's and B's values

**Silent-failure check:**
- No silent overwrite (the rejected client gets a conflict notification)
- Final hash matches CRDT contract spec

---

## E004 — Edge offline mirror durability (5 tasks)

**Primitive:** Offline SQLite WAL mirror.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Sandbox:** per-run.

**Intent:** Client offline, creates 5 tasks, kills process mid-write, reopens. All 5 tasks persist; no duplicates on subsequent sync.

**Steps:**
1. Client offline
2. Create 5 tasks
3. Kill -9 process before sync
4. Restart
5. Reconnect
6. Sync

**Strict assertions:**
- 5 tasks visible after restart (WAL replay)
- 5 tasks pushed to cloud
- 5 tasks visible in cloud (no duplicates)
- Task IDs stable (no UUID collision)

**Silent-failure check:**
- No duplicate IDs
- Sync events count = 5

---

## E005 — Concurrent edit on same field with stale base revision (Codex's #J116 deepened)

**Primitive:** Per-field CRDT.

**Status:** LIVE+UNTESTED.

**Mode:** REPLAY, SHADOW.

**Sandbox:** per-run, 2 clients.

**Intent:** Both clients see TimeBlock at base r0. Both edit `label`. Both push. CRDT merges deterministically, not via LWW.

**Steps as E003 but specifically targets the same field.**

**Strict assertions:**
- CRDT merge function applied (verifiable in trace: `merge_strategy: per_field_crdt`)
- LWW NOT applied (forbidden_paths exclusion)
- Final value deterministic per CRDT contract (e.g., lexicographically larger wins, or content concatenation, depending on type)
- Replaying same sequence twice produces identical state

---

## E006 — Concurrent delete-vs-update (Codex's #J117)

**Primitive:** Tombstone semantics.

**Status:** LIVE+UNTESTED.

**Mode:** REPLAY, SHADOW.

**Intent:** Client A deletes TimeBlock T. Client B updates T. Both reconnect. Final state must be deterministic — typically delete-wins or per-CRDT-spec.

**Steps:**
1. T exists on both
2. A: DELETE T
3. B: PATCH T (label = "Y")
4. Both push

**Strict assertions:**
- Final state matches contract: `delete_wins: true` (T is tombstoned)
- Tombstone is queryable but not in active list
- Evidence trace records both alternatives + chosen path
- B's update is preserved in evidence even though state is deleted

**Silent-failure check:** B's update is not silently lost from audit (evidence preserves what was attempted).

---

## E007 — Semantic CRDT collision on JSON-RPC payload (Gemini's J-ADV-04)

**Primitive:** Per-field CRDT on structured JSON.

**Status:** LIVE+UNTESTED.

**Mode:** REPLAY, SHADOW.

**Intent:** A field is JSON. Two offline edits produce non-mergeable JSON shapes (object vs array; rename vs delete). System must detect semantic conflict and surface it, not silently corrupt the JSON.

**Steps:**
1. T.metadata = `{"foo": 1, "bar": 2}`
2. A offline: T.metadata.foo = 99
3. B offline: T.metadata = ["replaced", "with", "array"]  // structural change
4. Both reconnect

**Strict assertions:**
- System detects semantic conflict (not silent LWW)
- Conflict raised to user (or to Mission Calendar conflict UI)
- `unresolved_conflict: true` flag persisted on the entity
- Evidence event `entity_sync_semantic_conflict` recorded

**Blocked by missing:** semantic-conflict UI surface (#SEMANTIC-CONFLICT-UI-001). Grace until issue closes.

---

## E008 — Clock skew resilience

**Primitive:** Hybrid logical clock + wall-clock skew.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Intent:** Client A's clock is 5 minutes ahead of server. Client B is 5 minutes behind. Sync still produces deterministic order.

**Steps:**
1. Both clients edit T
2. A's wall-clock ahead, B's behind
3. Reconnect

**Strict assertions:**
- Sync uses logical clock (HLC, vector clock, or revision-based ordering), not wall-clock
- Order of operations is deterministic and consistent across replays
- No silent reordering due to skew

---

## E009 — Schema migration during active CRDT merge

**Primitive:** Schema-aware sync.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Intent:** Field renamed in schema v2 while clients have v1 data offline. Reconnect after schema migration. System detects schema mismatch and routes through migration path, not silent data loss.

**Steps:**
1. Both clients have T at schema v1 (`label` field)
2. Migration deploys v2 (`title` field replaces `label`)
3. Clients sync

**Strict assertions:**
- Migration applies field rename
- Both clients land on v2 with renamed field
- Original `label` value preserved in `title`
- Migration evidence event recorded
- Clients running v1 schema receive `schema_migration_required` response

---

## E010 — Offline queue overflow

**Primitive:** Local queue limits.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Intent:** Client offline for hours, generates 1000+ pending sync ops. Queue must persist (not OOM), and reconnect must replay all.

**Steps:**
1. Client offline
2. Generate 1000 pending sync ops
3. Reconnect
4. Wait for queue drain

**Strict assertions:**
- Local SQLite queue table contains all 1000 ops at offline end
- All 1000 replay successfully on reconnect
- No silent dropping (count after = count before)
- Evidence trail records full set

**Silent-failure check:** queue_drain_count metric == 1000.

---

## E011 — Sync conflict resolution UI

**Primitive:** Cloud entity_sync UI.

**Status:** LIVE+UNTESTED.

**Mode:** REPLAY (gstack browse).

**Intent:** A semantic conflict (E007) surfaces in UI. User picks resolution. UI persists choice and clears conflict flag.

**Steps:**
1. Force a semantic conflict via API
2. Open Mission Calendar UI
3. Verify conflict indicator visible
4. Click resolve → choose A or B
5. Verify resolution applied

**Strict assertions:**
- Conflict indicator visible in DOM
- Resolution flow renders both alternatives
- Choice persists
- Evidence event `entity_sync_conflict_resolved_by_user` recorded

**Blocked by missing:** UI for entity-sync conflict (#SEMANTIC-CONFLICT-UI-001).

---

## E012 — Sync revision overflow guard

**Primitive:** Revision counter.

**Status:** LIVE+TESTED.

**Mode:** SHADOW.

**Intent:** A long-lived entity with millions of revisions still increments correctly without overflow.

**Steps:**
- Synthetic test: revision starts at MAX_INT - 5
- Issue 10 PATCHes
- Inspect revision

**Strict assertions:**
- Revision behaves correctly past traditional overflow points
- No silent reset to 0
- No exception thrown

---

## E013 — Cross-device session attach

**Primitive:** Ambient cross-surface attach (CE-AMBIENT-ATTACH).

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Intent:** User logged in on web. CLI attaches via device-code → both surfaces share session. Mobile attaches → all three.

**Steps:**
1. Web logs in
2. CLI device-code login same user
3. Mobile attaches
4. Issue command from each — all three surfaces see consistent state

**Strict assertions:**
- All three surfaces show same active session
- Per-surface opt-out works
- Detaching one surface does not detach others
- Evidence events record per-surface attach decisions

---

## Roadmap E014–E099

Reserved for: bandwidth throttling, intermittent flap, schema downgrade reject, batch sync optimization, ACK timeout, partial sync resume, cross-region sync, sync auth-token rotation.

---

## Related

- [PRIMITIVES.md § 8 Edge↔Cloud sync](../../PRIMITIVES.md#8-edgecloud-sync-ww-cli-hybrid)
- Codex's adversarial set: J116, J117
- Gemini's J-ADV-04
