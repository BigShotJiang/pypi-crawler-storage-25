# Tier 8 — Outreach (J80–J89)

Cold-outreach campaigns, suppression, PreSendGuard compliance order.

---

## J80 — Campaigns list responds

**Strict assertions:**
- `GET /api/v1/outreach/campaigns` → 200
- Body is array, each campaign has `id`, `state`, `lead_count`, `compliance_check_status`

---

## J81 — Campaign create with PreSendGuard order (PARTIAL)

**Primitive:** PreSendGuard compliance order.
**Status:** PARTIAL.
**Blocked by missing:** #1153.

**Strict assertions:**
- POST `/api/v1/outreach/campaigns` with valid lead source
- Server applies PreSendGuard order: source provenance → suppression check → unsubscribe check → DKIM/SPF check → idempotency → send
- Each check produces an evidence event in correct order
- ANY check failure halts the chain; subsequent steps not executed

**Until #1153 closes:** Grace permitted on order enforcement; assertions on individual check existence still strict.

---

## J82 — Suppression rules

**Strict assertions:**
- POST a suppression rule (`{type: dnc, value: foo@bar}`) → 201
- GET suppression list → contains rule
- Outreach to suppressed → rejected with `suppression_match` (not silent skip)

---

## Roadmap J83–J89

Reserved for: bounce handling, unsubscribe webhook, sequence state transitions, meeting booking handoff.
