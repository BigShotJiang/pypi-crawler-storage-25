# Exploratory Journeys (EX01–EX99)

VC-grade end-to-end exploration. The "demo storyline" you'd pitch. These run in LIVE mode only on the nightly schedule because they take time and exercise live infrastructure.

Each journey is a multi-step persona arc with judge rubrics for narrative coherence.

---

## EX01 — Landing page UX in 60 seconds

**Intent:** A first-time visitor reaches the value prop, sees pricing, and clicks Get Started — all in under 60 seconds.

**Mode:** REPLAY (gstack browse + Lighthouse).

**Steps:**
1. Cold-load landing
2. LCP < 2.5 s
3. Hero text comprehensible (judge rubric)
4. CTA visible above fold
5. Click CTA

**Strict assertions:**
- LCP < 2.5 s
- CTA in viewport before scroll
- Click → signup flow loads

**Judge rubric:**
- C1: Value prop clear in hero — 0–10
- C2: Below-fold reinforces value — 0–10
- C3: Pricing is transparent and honest — 0–10
- C4: No dark patterns — 0–10
- C5: Mobile experience matches — 0–10

---

## EX02 — Onboarding flow (founder + cofounder)

**Intent:** Founder signs up. Pulls in cofounder. Both reach Mission Control with shared context.

**Mode:** SHADOW.

**Steps:** see [personas/founder.md](../../personas/founder.md) and [personas/coworker.md](../../personas/coworker.md).

---

## EX03 — Mission calendar UX

**Intent:** A weekly view of mission calendar surfaces productivity insights without overwhelming.

**Mode:** REPLAY.

**Judge rubric:**
- C1: Productive vs unproductive blocks visually distinct — 0–10
- C2: Drill into a block reveals decision trace — 0–10
- C3: TimeBlock altitude switching is fluid — 0–10
- C4: No empty-state silently-rendered — 0–10
- C5: Insights are actionable, not just descriptive — 0–10

---

## EX04 — Goal → task → execution loop

**Intent:** End-to-end goal authoring through Zara, decomposition, execution by swarm, review.

**Mode:** SHADOW.

**Steps:** OKR interview (Z001) → plan (Z003) → swarm dispatch (J110) → review (J111).

---

## EX05 — Memory compound intelligence

**Intent:** Repeated work compounds — a pattern emerges, becomes a skill (S009), is reused.

**Mode:** SHADOW.

---

## EX06 — Connector ecosystem demo

**Intent:** Walk through 5 connector OAuth flows, each completing in < 30 s.

**Mode:** SHADOW.

---

## EX07 — Zara ambient availability

**Intent:** Zara responds across web + CLI + voice within 1 s p95.

**Mode:** LIVE.

---

## EX08 — Inbox judgment flow

**Intent:** Inbox surfaces approvals; user reviews; approves / rejects; system continues.

**Mode:** SHADOW.

---

## EX09 — Settings depth

**Intent:** Every settings panel reachable, each renders without errors.

**Mode:** REPLAY.

---

## EX10 — End-to-end business workflow

**Intent:** Founder runs a 1-hour OKR cycle: input via voice → plan → outreach → meeting booked → invoice sent.

**Mode:** LIVE.

**Judge rubric:**
- C1: All 5 stages completed — 0–10
- C2: Each stage produces a decision trace — 0–10
- C3: Final outcome is concrete (a booked meeting + sent invoice) — 0–10
- C4: Total wall-clock time < 1 hour — 0–10
- C5: Mission calendar reflects the work — 0–10

---

## Related

- [PERSONAS.md](../../PERSONAS.md)
- [LLM-AS-JUDGE.md](../../LLM-AS-JUDGE.md)
