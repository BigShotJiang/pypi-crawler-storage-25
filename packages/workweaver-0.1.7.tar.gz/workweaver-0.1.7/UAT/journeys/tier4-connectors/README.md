# Tier 4 — Connectors (J40–J49)

Connector lifecycle: catalog, dock, OAuth flow, health, action execution.

---

## J40 — Connection center loads

**Primitive:** `GET /api/v1/connectors/connection-center`.
**Status:** LIVE+TESTED.

**Strict assertions:**
- Status 200
- Each connector has `state` ∈ {connected, needs_permission, advanced_setup, re_authenticate, disconnected}
- Connection center is canonical (matches `/api/v1/connectors/catalog` membership)

---

## J41 — Connector dock UI renders

**Mode:** REPLAY (gstack browse).
**Strict assertions:**
- Mission Control reachable connector dock
- Each connector shown with state chip
- Click opens dialog without console errors

---

## J42 — Connector hydrate sync

**Primitive:** `POST /memory/v1/connectors/{name}/sync`.
**Status:** LIVE+TESTED.

**Strict assertions:**
- Status 200 OR 202
- Body has `sync_id`, `connector_id`, `state` ∈ {queued, running, completed}
- If 202: poll for completion within 30 s; final state = completed
- Evidence event `connector_sync_completed` recorded

**Silent-failure check:** poll not silently swallowed; final state must be completed or failed (not stuck `running`).

---

## J43 — Connector action execute (Gmail send)

**Primitive:** `POST /api/v1/connectors/gmail/execute`.
**Status:** LIVE+TESTED in REPLAY (mocked) and SHADOW (sandbox Google project).

**Strict assertions:**
- Status 200
- Body has `provider_message_id`
- Evidence event `connector_action_executed` with `connector: gmail, action: send_message`
- Decision trace shows `connector_scope: gmail.send` ALLOW
- Connector trace shows `path: native` (NOT fallback)

**Silent-failure check:** Network witness — Gmail API actually called (non-empty path log).

---

## J44 — Connector health monitoring

**Primitive:** Connector health monitor.
**Status:** LIVE+TESTED.

**Strict assertions:**
- `GET /api/v1/connectors/{id}/health` → 200
- Body has `status` ∈ {healthy, degraded, unhealthy, unknown}
- Last probe within 10 minutes
- Circuit breaker state visible

---

## Roadmap J45–J49

Reserved for: connector connect (OAuth flow start-to-finish), disconnect, re-auth, scope re-grant, MCP passthrough.

See [contract-parity/C002](../contract-parity/README.md#c002--capability-runtime-parity-per-surface) for cross-surface parity.

See [adversarial/A009](../adversarial/README.md#a009--schema-invalid-connector-payload-codexs-j122) for schema-violation hard-fail.
