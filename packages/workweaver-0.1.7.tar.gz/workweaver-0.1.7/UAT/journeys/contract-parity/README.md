# Contract Parity Journeys (C001–C099)

Verify that surfaces claiming "do the same thing N ways" actually do. Schema-driven; see [PARITY-CONTRACT.md](../../PARITY-CONTRACT.md) for the full contract.

---

## C001 — Capability schema parity gate

**Primitive:** Admin parity surface.

**Status:** PARTIAL (auto-generation incomplete).

**Mode:** REPLAY, SHADOW.

**Sandbox:** per-run.

**Intent:** For each capability in the V1 capability matrix, all four surfaces (UI, CLI, MCP, API) declare identical inputs, outputs, preconditions, side-effects, and error codes. The static schema check is the gate.

**Strict assertions (per capability):**
- API request validation matches schema's `inputs`
- API response shape matches schema's `outputs`
- CLI argparse model has every input field
- MCP tool input schema matches inputs
- UI form has bindings for every input field
- Error codes match across all four

**Blocked by missing:** #PARITY-MATRIX-001. Until then: runs in WARN mode (drift listed but does not fail).

---

## C002 — Capability runtime parity per surface

**Primitive:** Admin parity surface.

**Status:** LIVE+TESTED for V1 admin operations.

**Mode:** SHADOW (real backend).

**Sandbox:** per-run; sandbox tenant for parity (`uat-<run>-parity`).

**Intent:** For each capability, execute via UI / CLI / MCP / API and assert identical resulting state, evidence event shape, and error codes.

**Steps (per capability, e.g., `admin.tenants.set_routing_override`):**

1. Snapshot baseline state
2. Via API: `POST /api/v1/founder/inference/tenants/<sandbox>/routing-override` → record state hash + evidence event
3. Reset state
4. Via CLI: `ww admin inference routing-override set --tenant <sandbox> --model <model>` → record
5. Reset
6. Via MCP tool call → record
7. Reset
8. Via UI (gstack browse): navigate, click, submit → record

**Strict assertions:**
- All four resulting state hashes are identical
- All four evidence events have identical kind + payload (modulo `channel` field)
- All four return identical decision-trace alternatives_considered

**Silent-failure check:** `state_unchanged` checks per surface (mutation actually happened).

---

## C003 — Founder auth gate parity

**Primitive:** Admin auth (require_founder).

**Status:** LIVE+TESTED.

**Mode:** SHADOW.

**Sandbox:** per-run with founder + non-founder.

**Intent:** Every admin endpoint denies non-founder via UI, CLI, MCP, API equally with 403.

**Steps (per endpoint):**
- As non-founder, attempt access via each surface
- Capture status code + body

**Strict assertions:**
- All four return 403 (or appropriate auth code per surface)
- All four return same `error_code`
- All four are recorded in `admin_audit` log with `result: denied`

---

## C004 — Tenant list / detail parity

**Primitive:** Admin tenant operations.

**Status:** LIVE+TESTED.

**Mode:** SHADOW.

**Sandbox:** per-run.

**Intent:** Listing and showing tenants returns identical row sets across surfaces.

**Strict assertions:**
- Set of tenant IDs returned via UI = via CLI = via MCP = via API
- Per-tenant detail fields equal across surfaces (modulo channel-specific UI rendering)

---

## C005 — Feature-flag + audit-log parity

**Primitive:** Admin feature flags + audit log.

**Status:** LIVE+TESTED.

**Mode:** SHADOW.

**Strict assertions:**
- Same flags listed across surfaces
- Same audit rows returned (rows keyed by `audit_id`)
- Mutations of flags via any surface visible to all surfaces immediately (no caching divergence)

---

## C006 — Inference control plane parity

**Primitive:** Inference admin (provider config, tenant routing override, capability eval canary).

**Status:** LIVE+UNTESTED for parity (functional code lives but parity coverage is new).

**Mode:** SHADOW, LIVE.

**Sandbox:** per-run.

**Strict assertions per operation:**
- Provider config set via any surface persists identically
- Tenant routing override applied via any surface invalidates resolver cache identically
- Capability eval canary `last_known_good` returns identical baseline across surfaces

**Silent-failure check:**
- Resolver cache invalidation witness: a `GET /inference/resolve` after each surface's mutation reflects new config

---

## C007 — CLI device-code login

**Primitive:** RFC 8628 device flow.

**Status:** LIVE+TESTED.

**Mode:** SHADOW, LIVE.

**Strict assertions:**
- `POST /api/v1/auth/cli/device/start` returns `device_code`, `user_code`, `verification_uri`, `interval`
- Polling `POST /api/v1/auth/cli/device/poll` returns `authorization_pending` until user authorizes
- After authorization, poll returns `access_token` + `refresh_token`
- Token stored to keyring (or fallback config), mode 0o600 if file
- `ww status` returns authenticated mode

**Silent-failure check:** Tokens never logged to console; redacted in tape.

---

## C008 — CLI browser PKCE login

**Primitive:** PKCE OAuth via loopback.

**Status:** LIVE+TESTED.

**Strict assertions:**
- Browser opens to consent URL
- Callback handled at `127.0.0.1:43111`
- Code-verifier discarded after token exchange
- Tokens persisted with same security as device-code

---

## C009 — Token storage hierarchy

**Primitive:** CLI token storage.

**Status:** LIVE+TESTED.

**Strict assertions:**
- Lookup order: OS keyring → `~/.workweaver/config.yaml` → env vars
- A token in keyring takes precedence over env var
- Config file is mode 0o600 (verified post-write)
- No token logged to stdout / stderr in any flow

---

## C010 — `ww status` mode awareness

**Primitive:** CLI mode awareness.

**Status:** LIVE+TESTED.

**Sandbox:** four CLI invocations under different conditions.

**Strict assertions:**
- Cloud mode: `mode: cloud` + `inference: <provider>` from cloud config
- Self-host mode: `mode: self_host` + `inference: <provider>` from local config
- Hybrid mode: `mode: hybrid` + `inference: <override>` + cloud auth
- Offline mode: `mode: offline` + no auth required

---

## C011 — MCP tool surface parity vs API

**Primitive:** MCP server tools vs API endpoints.

**Status:** LIVE+TESTED for current surface.

**Mode:** REPLAY, SHADOW.

**Strict assertions:**
- Every MCP tool maps to a documented API endpoint
- Every "guarded" operation in `apps/backend/api/public_mcp.py` is also guarded in API (auth + policy)
- Every MCP tool's auth dependency uses `get_verified_tenant_id`
- Tools that mutate state require explicit policy verdict

**Coverage:** see [PRIMITIVES.md § 6 Connectors](../../PRIMITIVES.md#6-connectors) for MCP tool list.

---

## C012 — MCP `ww.evidence.trace` vs API `GET /evidence/{id}/trace`

**Primitive:** Evidence trace via MCP.

**Status:** LIVE+TESTED.

**Strict assertions:**
- Same trace ID produces same payload across MCP and API
- Field-by-field equivalence (alternatives_considered, evidence_refs, policy_envelope_version, etc.)

---

## C013 — Cross-language CLI consistency

**Primitive:** `ww` CLI commands.

**Status:** LIVE+TESTED.

**Strict assertions:**
- `ww --help` output is consistent across stdout-tty and pipe
- `ww <subcommand> --help` provides at least: synopsis, options, examples
- Exit codes follow standard: 0 success, 1 generic, 2 usage, 64+ specific

---

## Roadmap C014–C099

Reserved for: WhatsApp/SMS/email channel parity, edge sync mode parity, voice channel parity, payment channel parity, governance channel parity, swarm channel parity, skill registry channel parity.

---

## Related

- [PARITY-CONTRACT.md](../../PARITY-CONTRACT.md) — full contract
- [PRIMITIVES.md § 9 Admin parity surface](../../PRIMITIVES.md#9-admin-parity-surface)
- [runner/parity_check.py](../../runner/parity_check.py)
