# Journeys — Master Index

This directory contains all UAT journeys, organized by tier (functional surface) and by cross-cutting concern (adversarial, parity, edge, multi-tenant, whitebox, zara, skills, exploratory).

See [TAXONOMY.md](../TAXONOMY.md) for ID conventions and [PRIMITIVES.md](../PRIMITIVES.md) for primitive cross-references.

---

## Tier-based collections (functional surfaces)

| Tier | Concern | IDs | Index |
| --- | --- | --- | --- |
| 0 | Shell integrity | J01–J09 | [tier0-shell/](./tier0-shell/) |
| 1 | Core primitives | J10–J19 | [tier1-primitives/](./tier1-primitives/) |
| 2 | Multi-step planning | J20–J29 | [tier2-planning/](./tier2-planning/) |
| 3 | Memory + evidence | J30–J39 + WB01–WB10 | [tier3-memory-evidence/](./tier3-memory-evidence/) |
| 4 | Connectors | J40–J49 | [tier4-connectors/](./tier4-connectors/) |
| 5 | Inbox / judgment | J50–J59 | [tier5-inbox/](./tier5-inbox/) |
| 6 | Settings + billing | J60–J69 | [tier6-billing/](./tier6-billing/) |
| 7 | Voice + Zara | J70–J79 | [tier7-voice/](./tier7-voice/) |
| 8 | Outreach | J80–J89 | [tier8-outreach/](./tier8-outreach/) |
| 9 | Governance + autonomy | J90–J99 | [tier9-governance/](./tier9-governance/) |
| 10 | Mesh + orchestration | J100–J199 | [tier10-mesh/](./tier10-mesh/) |
| Exploratory | VC-grade end-to-end | EX01–EX10 | [exploratory/](./exploratory/) |

## Cross-cutting collections

| Collection | IDs | Concern | Index |
| --- | --- | --- | --- |
| Adversarial | A001–A099 | Silent failures, mid-flight revocation, WORM poison, hallucination | [adversarial/](./adversarial/) |
| Contract parity | C001–C099 | UI = CLI = MCP = API | [contract-parity/](./contract-parity/) |
| Edge sync | E001–E099 | CRDT, OCC, semantic conflicts | [edge-sync/](./edge-sync/) |
| Multi-tenant | M001–M099 | Capability lease, cross-org denial | [multi-tenant/](./multi-tenant/) |
| Whitebox depth | W001–W099 | Decision trace utility, contestability, replay | [whitebox-depth/](./whitebox-depth/) |
| Zara cognition | Z001–Z099 | Interview, planning, gradient, swarm | [zara-cognition/](./zara-cognition/) |
| Skills compounding | S001–S099 | Skillify, hygiene, MCC | [skills-compounding/](./skills-compounding/) |
| Tenant support | TS-001–TS-099 | Issue reporting from tenant via UI/CLI/MCP/Zara, admin triage with full repro context | [tenant-support/](./tenant-support/) |
| Customer support | CS-001–CS-099 | End customer of tenant reports issue → tenant Zara intake → admin triage → resolution | [customer-support/](./customer-support/) |
| Metering + billing | MB-001–MB-099 | Stripe pricing, metering accuracy, invoice reconciliation, plan transitions, refunds | [metering-billing/](./metering-billing/) |

---

## Filtering by run

```bash
make uat                                  # all collections, REPLAY mode
make uat TIER=0,1,2                       # only tiers 0/1/2
make uat COLLECTIONS=adversarial,edge-sync # only those collections
make uat JOURNEYS=J122,A007,M003          # specific IDs
```

The runner resolves the union of all selectors.

---

## Run priority

| Class | Run on every PR | Run nightly | Run pre-deploy |
| --- | --- | --- | --- |
| Tier 0–2 | ✓ | ✓ | ✓ |
| Tier 3–10 | ✓ | ✓ | ✓ |
| Adversarial | (REPLAY only) | ✓ (LIVE) | ✓ (SHADOW) |
| Contract parity | (REPLAY only) | ✓ (LIVE) | ✓ (LIVE) |
| Edge sync | ✓ | ✓ | ✓ |
| Multi-tenant | ✓ | ✓ | ✓ |
| Whitebox depth | ✓ | ✓ | ✓ |
| Zara cognition | ✓ (REPLAY judge) | ✓ (LIVE judge) | ✓ |
| Skills compounding | ✓ | ✓ | ✓ |
| Self-host | (no) | ✓ | ✓ |
| Exploratory | (no) | ✓ | (no) |
| Personas | (no — too large for PR) | ✓ | ✓ |

PR-level runs aim for < 2 min total. Nightly runs aim for < 60 min. Pre-deploy aims for < 90 min.
