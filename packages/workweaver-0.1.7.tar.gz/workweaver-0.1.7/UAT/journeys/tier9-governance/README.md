# Tier 9 — Governance + Autonomy (J90–J99)

Policy authority, payment preflight, behavioral stops, trust posture, autonomy metrics.

---

## J90 — Policy authority map

**Primitive:** `GET /api/v1/governance/policy-authority`.
**Status:** LIVE+TESTED.

**Strict assertions:**
- Status 200
- Body has 10 sub-questions: identity, tool_scope, connector_scope, budget, risk_tier, approval, evolution, tenant_pause, side_effect_proof, on_chain_write
- Each lists its authority service + boundary

---

## J91 — Autonomy metrics

**Strict assertions:**
- `GET /api/v1/governance/autonomy/metrics` → 200
- Body has `autonomous_runs_completed`, `human_overrides_count`, `current_trust_posture`

---

## J92 — Payment preflight returns envelope

**Primitive:** `POST /api/v1/governance/payment-preflight`.
**Status:** LIVE+TESTED.

**Strict assertions:**
- POST with payment intent → 200
- Body has `final_verdict` ∈ {ALLOW, REQUIRE_APPROVAL, DENY, DRAFT}
- Body has `sub_verdicts` (10 entries)
- DENY case: each missing precondition listed

---

## J93 — Behavioral stops

**Status:** LIVE+UNTESTED.
**Strict assertions:**
- `GET /api/v1/governance/behavioral-stops` → 200
- Each stop has `id`, `trigger`, `actor`, `state`

---

## J94 — Trust posture

**Status:** LIVE+UNTESTED.
**Strict assertions:**
- `GET /api/v1/governance/trust-posture` → 200
- Body has `level` ∈ {bronze, silver, gold, platinum}
- Body has `escalation_threshold`, `current_metrics`

---

## Roadmap J95–J99

Reserved for: override audit (W008), trust posture transitions, evolution policy registry, approval gate UX.
