# Skills Compounding Journeys (S001–S099)

Skillify loop. 10-dimension proof bundle. Hygiene heartbeat. MCC eval correlation.

Gemini's caution: "The 10-dim proof bundle cannot be UAT'd end-to-end dynamically. Treat it as audit-only on a static fixture." This collection follows that pragmatism: most journeys are audit-on-fixture; a few exercise the live promotion gate with synthetic patterns.

---

## S001 — SkillifyService instantiates with required seams

**Primitive:** SkillifyService construction.

**Status:** LIVE+TESTED.

**Mode:** REPLAY.

**Intent:** SkillifyService constructs with: SkillCrystallizationService, UnifiedSkillRegistry, OnlineEvalService, ForgettingScheduler, TimeBlockAnalyticsService.

**Strict assertions:**
- Construction does not raise
- All 5 seams resolved
- Service responds to `health_probe()` with status `ready`

---

## S002 — ProofBundle dataclass shape

**Primitive:** ProofBundle (`apps/backend/services/skillify.py` lines 145–180).

**Status:** LIVE+TESTED.

**Mode:** REPLAY.

**Intent:** A ProofBundle has all 10 boolean dimensions. Missing any → `can_promote=False`.

**Strict assertions:**
- ProofBundle has fields: `has_skill_procedure`, `has_deterministic_code`, `has_unit_tests`, `has_integration_or_smoke_tests`, `has_evals`, `has_resolver_trigger`, `has_reachability_proof`, `has_dry_audit`, `has_smoke_or_uat_proof`, `has_filing_rules`
- All-True bundle: `can_promote=True`
- Any-False bundle: `can_promote=False`

---

## S003 — Auto-promotion gate denies incomplete bundle

**Primitive:** Auto-promotion gate.

**Status:** LIVE+UNTESTED.

**Mode:** REPLAY.

**Intent:** Skill candidate with 9 of 10 dimensions True is denied promotion with structured error.

**Steps:**
1. Synthesize candidate fixture with 1 dimension False
2. Invoke promotion path

**Strict assertions:**
- Promotion denied
- Error names the missing dimension
- Skill remains in `candidate` state, not active
- Evidence event `skill_promotion_denied` with reason

---

## S004 — Trigger resolver natural-phrase match

**Primitive:** Skill trigger resolver.

**Status:** LIVE+TESTED.

**Mode:** REPLAY.

**Intent:** A user phrasing matches the right skill's triggers; non-matching phrases do not match.

**Steps:**
1. Skill X with trigger phrases ["debug error", "fix bug"]
2. Resolver receives "I have a bug" → matches X
3. Resolver receives "send email" → does not match X

**Strict assertions:**
- Match returns skill ID + confidence ≥ threshold
- Non-match returns null OR a different skill (no false-positive on X)
- Confidence above ambiguity threshold

---

## S005 — Hygiene heartbeat detects duplicate skill

**Primitive:** Skill hygiene service.

**Status:** LIVE+UNTESTED.

**Mode:** REPLAY.

**Intent:** Two skills declare overlapping trigger phrases. Hygiene heartbeat flags them.

**Strict assertions:**
- Hygiene event `skill_hygiene_duplicate_trigger` recorded with both skill IDs
- Admin notification queued (sandbox observed)

---

## S006 — MCC correlation per-skill weekly

**Primitive:** Eval Matthews correlation.

**Status:** LIVE+UNTESTED.

**Mode:** REPLAY.

**Intent:** A skill's MCC over its evaluation runs is computed weekly. Skills below MCC threshold are flagged.

**Strict assertions:**
- MCC calculation matches reference implementation
- Skills below threshold listed in `flagged_skills`
- Threshold documented

---

## S007 — `ww skill list` reflects registry state

**Primitive:** `ww` CLI skill listing.

**Status:** LIVE+TESTED.

**Mode:** REPLAY.

**Intent:** `ww skill list` returns the skill registry rows; matches `skills/index.json` count + status filter.

**Strict assertions:**
- Number of active skills matches registry
- Each row has skill_id, status, capability_class, risk_class
- `--status active` filter works
- `--capability dev` filter works

---

## S008 — Skill candidate detection from repeated pattern (PARTIAL)

**Primitive:** Skill crystallization.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Intent:** Workweaver executes the same shape of task 3+ times. Crystallization service detects pattern and emits a skill candidate.

**Steps:**
1. Sandbox: 3 task cycles with same shape (e.g., "draft + send + log" outreach)
2. Trigger crystallization probe
3. Inspect candidate list

**Strict assertions:**
- Candidate emitted with proposed skill_procedure
- Candidate not yet active
- Repeated invocations produce 1 candidate, not 3

**Blocked by missing:** crystallization scoring threshold tuning (#CRYST-THRESHOLD-001).

---

## S009 — End-to-end Skillify cycle (audit-only fixture)

**Primitive:** Full loop on static fixture.

**Status:** LIVE+UNTESTED.

**Mode:** REPLAY.

**Intent:** Static fixture of 100 past actions → Skillify generates valid YAML proof bundle.

**Steps:**
1. Load fixture: 100 actions across 5 patterns
2. Run Skillify pipeline
3. Inspect output bundles

**Strict assertions:**
- 5 candidate skills emitted
- Each has 10/10 ProofBundle dimensions
- Auto-promotion gate accepts each
- Registry shows 5 new active skills

**Note:** Treats Skillify as audit on fixture, per Gemini's recommendation. Live multi-cycle promotion is in Roadmap (S010+).

---

## S010 — Skill registry consistency

**Primitive:** Cross-store skill registry.

**Status:** LIVE+TESTED.

**Mode:** REPLAY.

**Intent:** `skills/index.json`, `skills/SKILL-INDEX.md`, `skills/catalog.json`, and `apps/landing/public/agent-knowledge/skill-registry.json` agree on skill IDs.

**Strict assertions:**
- Skill ID set in all four sources is identical
- A skill not in `skills/<id>/SKILL.md` is not in any registry
- A skill in any registry is in `skills/<id>/SKILL.md`

**Drift gate:** if mismatch, fail with the specific diff.

---

## Roadmap S011–S099

Reserved for: shadow-mode skill execution, graduated promotion (canary then full), skill rollback, skill versioning, multi-tenant skill scoping, marketplace publish, skill auth + license.

---

## Related

- [PRIMITIVES.md § 11 Skills compounding](../../PRIMITIVES.md#11-skills-compounding-skillify)
- [ROADMAP.md § Skills compounding loop](../../ROADMAP.md#skills-compounding-loop-end-to-end)
