# Zara Cognition Journeys (Z001–Z099)

The autonomous brain. OKR interview, multi-step planning, gradient descent, swarm composition. Non-deterministic by design — graded by LLM-as-judge plus strict envelope assertions.

GLM was right: J26 in legacy suite "tests endpoint responds, not behavior." This collection fixes that.

---

## Z001 — OKR interview opens with rapport

**Primitive:** ZaraInterviewContract (5-stage).

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW (real LLM).

**Sandbox:** per-run.

**Intent:** Zara begins an OKR interview at stage RAPPORT and transitions correctly through PAIN, TOOLS, DREAM, WRAP. The interview produces a structured InterviewArtifact.

**Steps:**
1. POST `/api/v1/zara/interview/start` with seed: "Help me grow my podcast"
2. Conversational flow over 8 turns (judge model plays the user)
3. POST `/api/v1/zara/interview/finalize`

**Strict assertions:**
- Stage transitions: RAPPORT → PAIN → TOOLS → DREAM → WRAP
- Each stage has at least 1 ai turn + 1 user turn captured
- Final InterviewArtifact has: pain_summary, current_tools, dream_state, time_horizon, success_metrics

**Judge rubric:**
- C1: Rapport stage shows curiosity, not interrogation — 0–10
- C2: Pain stage uncovers concrete blocker — 0–10
- C3: Tools stage enumerates current stack — 0–10
- C4: Dream stage produces measurable target — 0–10
- C5: Wrap stage produces actionable OKR shape — 0–10

Pass: all ≥ 7.

---

## Z002 — Interview produces measurable OKR

**Primitive:** Interview → OKR shaping.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Intent:** The InterviewArtifact converts to a measurable OKR with: target metric, baseline, time horizon, accountability owner, intermediate KRs.

**Strict assertions:**
- OKR.target_metric is a number with unit
- OKR.baseline is a number with unit
- OKR.deadline is an ISO date
- OKR.key_results has ≥ 2 measurable KRs

**Judge rubric:** subset of Z001's rubric on the OKR shape only.

---

## Z003 — Multi-step plan from initial OKR (full Z003 from LLM-AS-JUDGE.md worked example)

**Primitive:** Multi-step planning.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW, LIVE.

**Intent:** Same as the worked example in [LLM-AS-JUDGE.md § Worked example: Z003](../../LLM-AS-JUDGE.md#worked-example-z003--multi-step-planning).

---

## Z004 — Plan revision under new constraint

**Primitive:** Plan revision (`revised_from`).

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Intent:** A plan v1 is in flight. New constraint introduced (e.g., budget cut). Zara revises the plan to v2; v2 references v1 via `revised_from`.

**Steps:**
1. Plan v1 emitted
2. POST `/api/v1/zara/replan` with constraint: `{budget_cut_to: $500}`
3. Plan v2 emitted

**Strict assertions:**
- Plan v2 has `revised_from: <v1.id>`
- Plan v2 respects new constraint (judged by LLM)
- Both plans queryable

**Judge rubric:**
- C1: v2 honors the new constraint — 0–10
- C2: v2 changes only what the constraint requires (not gratuitous rewrite) — 0–10
- C3: v2's reasoning trace explains the changes — 0–10
- C4: v2 emits one decision_envelope reflecting plan revision — 0–10
- C5: `revised_from` linkage is correct — 0–10

---

## Z005 — Gradient descent loop with delta-J improvement (GLM's J121)

**Primitive:** Gradient engine.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Intent:** Goal created → plan v1 → execute → measure delta-J → plan v2 → delta-J improved.

**Steps:**
1. Create goal with target metric
2. Plan v1 → execute (mocked outcome)
3. Compute delta-J via gradient_engine
4. Plan v2 → execute (better outcome)
5. Compute delta-J for v2 — should be smaller

**Strict assertions:**
- Two delta-J values computed
- v2's delta-J < v1's delta-J
- Both delta-J recorded in evidence with the loss components (task, time, human, risk, cost)
- Plan v2's `revised_from = v1`

**Silent-failure check:** delta-J does not silently equal zero (would indicate gradient broken).

---

## Z006 — Gradient regression rollback

**Primitive:** Gradient rollback watchdog.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Intent:** Plan v3 produces worse outcome than v2. Gradient rollback identifies regression and reverts to v2's plan.

**Strict assertions:**
- Rollback decision event recorded
- Active plan after rollback is v2 (not v3)
- v3 evidence preserved with `outcome: regressed`
- Loss function reflects rollback

---

## Z007 — Sub-agent spawn budget enforcement (PARTIAL)

**Primitive:** Agent instance manager spawn limits.

**Status:** PARTIAL.

**Mode:** SHADOW.

**Intent:** Zara attempts to spawn N sub-agents. Spawn limit enforced; surplus deny with `spawn_budget_exceeded`.

**Strict assertions:**
- Spawn count never exceeds limit
- Surplus rejected with structured error
- No silent partial spawn (e.g., 8 of 10 created)

**Blocked by missing:** spawn lifecycle untested (#SPAWN-LIFECYCLE-001).

---

## Z008 — Operational context composes from multiple primitives

**Primitive:** `GET /api/v1/operational-context/{subject_id}`.

**Status:** LIVE+TESTED.

**Mode:** REPLAY.

**Intent:** A subject's operational context bundle returns evidence_ids, memory_ids, decision_ids, entity_ids, timeblock_ids, variant_ids, trace_envelope_ptrs.

**Strict assertions:**
- All 7 fields present
- Each ID-list is consistent with the subject's actual records (count matches DB)
- Trace envelope pointers resolve

---

## Z009 — Composition plan emits before side effects

**Primitive:** CompositionPlan dispatch order.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Intent:** When a mission runs, the CompositionPlan is emitted (and persisted) BEFORE any side effect (connector call, tool invocation). Order is enforceable.

**Steps:**
1. Trigger mission run
2. Watch evidence event timeline
3. Confirm `composition_plan_emitted` appears before any `connector_executed` or `tool_called`

**Strict assertions:**
- Timestamp ordering: `composition_plan_emitted < connector_executed < ...`
- No connector call without prior plan
- Plan ID referenced in subsequent events

---

## Z010 — Loss function decomposition is human-readable

**Primitive:** Loss function components.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Intent:** `Loss = w_task * task_loss + w_time * time_loss + w_human * human_loss + w_risk * risk_loss + w_cost * cost_loss`. Each component is computed transparently and the formula is observable.

**Strict assertions:**
- Loss event includes per-component values
- Weights documented
- Total = weighted sum (verifiable arithmetic)

**Judge rubric (optional):**
- C1: Component values are reasonable for the input — 0–10

---

## Roadmap Z011–Z099

Reserved for: simulation-shape plan (Monte Carlo), role_play shape (debate), role_swarm_360 shape, hybrid plan composition, plan-as-graph rendering, OKR refinement after data, gradient with non-numeric KR, autonomous mode opt-in flow.

---

## Related

- [PRIMITIVES.md § 1 Zara cognition](../../PRIMITIVES.md#1-zara-cognition)
- [LLM-AS-JUDGE.md § Worked example: Z003](../../LLM-AS-JUDGE.md#worked-example-z003--multi-step-planning)
- [PERSONAS.md § P-FOUNDER](../../PERSONAS.md#p-founder--org-owner-first-week)
