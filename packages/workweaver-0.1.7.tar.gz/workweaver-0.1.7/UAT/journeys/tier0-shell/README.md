# Tier 0 — Shell Integrity (J01–J09)

Public landing + runtime auth surfaces. The "is the door open" tier. Must be green before any other tier runs.

Migrated from `.claude/uat/UAT-SUITE.md § Tier 1 Shell Integrity` with strict-assertion upgrades.

---

## J01 — Landing page loads with hero CTA

**Primitive:** Public marketing surface.
**Status:** LIVE+TESTED.
**Mode:** REPLAY (gstack browse), LIVE.

**Strict assertions:**
- HTTP status 200 (not 200|503)
- URL contains `workweaver.ai`
- DOM text contains `Get started` (hero CTA)
- Console errors: 0
- Network: zero `net::ERR_*`
- LCP < 2.5 s (LIVE only)

**Evidence:** `landing-hero.png`, console transcript.

---

## J02 — Runtime authenticates and renders Mission surface

**Primitive:** Authenticated SPA shell.
**Status:** LIVE+TESTED.
**Mode:** SHADOW, LIVE.

**Setup:** Cookie import via `tools/cookie-import.sh` (Chrome → `.workweaver.ai` domain).

**Strict assertions:**
- URL after auth = `https://workweaver.ai/runtime/#/mission`
- DOM contains `Mission`, `What gets done today?`, sidebar nav `Inbox`, `Settings`
- Cmd+K can find `Memory`, `Connected Tools`, `Plan history`, `Billing`
- Console errors: 0 after page-load stabilization (default 3 s)

**Silent-failure check:** Auth cookie freshness witness — `x-auth-cookie-age` header < 30 min.

---

## J03 — Three primary surfaces load without hard errors

**Primitive:** SPA routing.
**Status:** LIVE+TESTED.

For each in [`mission`, `inbox`, `settings`]:
- Goto `https://workweaver.ai/runtime/#/{surface}`
- HTTP status 200
- DOM text contains capitalized surface label
- Console errors: 0
- No `net::ERR_NAME_NOT_RESOLVED`

---

## J03b — Secondary capabilities reachable via Cmd+K (not primary nav)

**Primitive:** Shell coherence + command palette.
**Status:** LIVE+TESTED.

For each in [`memory`, `connected tools`, `plan history`, `billing`]:
- Open Cmd+K
- Search capability name
- Result exists
- Click → renders without console errors
- Primary nav unchanged (still exactly Mission, Inbox, Settings)

**Silent-failure check:** Primary nav DOM equality before/after Cmd+K invocation.

---

## J04 — Pricing page renders tiers

**Primitive:** Public pricing.
**Status:** LIVE+TESTED.
**Strict assertions:**
- HTTP 200
- DOM contains at least one of `Solo`, `Professional`, `Team`
- Console errors: 0
- Anchor links to billing CTA resolve

---

## J05 — Legal pages render (privacy, terms, cookies)

**Primitive:** Legal pages.
**Status:** LIVE+TESTED.

For each in [`privacy`, `terms`, `cookies`]:
- HTTP 200
- DOM contains capitalized topic label
- Console errors: 0
- `lastUpdated` field within 12 months

---

## J06 — Mission control altitudes render

**Primitive:** Mission Control timeline at 5 altitudes.
**Status:** LIVE+TESTED.

**Strict assertions:**
- DOM contains `What gets done today?`
- DOM contains `Quarter`, `Month`, `Week`, `Day`, `Hour`
- DOM contains `Memory`, `Evidence`, `Approvals`, `Tools`
- Altitude switcher click cycle does not produce console errors
- Console errors: 0

---

## J07 — Zara launcher present

**Primitive:** Zara entry surface.
**Status:** LIVE+TESTED.

**Strict assertions:**
- DOM contains `Zara`
- Click `New run` → modal opens
- Modal contains `Describe the job` prompt
- `zara_status` not equals `Listening` until `Speak` clicked

**Silent-failure check:** No accidental WebSocket open before user clicks Speak (network witness).

---

## J08 — Multi-viewport layout integrity

**Primitive:** Responsive design.
**Status:** LIVE+UNTESTED.

For each viewport in [1920x1080, 1440x900, 1280x800, 390x844, 375x667]:
- Goto `/runtime/#/mission`
- Screenshot
- Assert primary nav visible (or behind hamburger on mobile)
- Assert no horizontal overflow (`document.documentElement.scrollWidth == window.innerWidth`)
- Console errors: 0

---

## J09 — Public sitemap + robots

**Primitive:** Public discoverability.
**Status:** LIVE+TESTED.

**Strict assertions:**
- `GET /sitemap.xml` → 200, valid XML
- `GET /robots.txt` → 200
- `GET /llms.txt` → 200, contains canonical brand description
- `lastmod` in sitemap within 90 days

---

## Migration note

Original assertions used `console_errors_max 0` and free-form `text_contains`. Strict assertions here are explicit JSONPath / regex / equality. The runner accepts both forms during migration; new journeys must use strict-only.

See [STRICT-ASSERTIONS.md](../../STRICT-ASSERTIONS.md) for the contract.
