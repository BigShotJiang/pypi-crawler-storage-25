# Metering + Billing Journeys (MB-001–MB-099)

Stripe pricing config, metering accuracy, invoice reconciliation, plan transitions, dunning, refunds.

---

## MB-001 — Stripe pricing config matches PRICING.md

**Primitive:** Stripe price catalog ↔ pricing source of truth.
**Status:** PARTIAL.
**Mode:** SHADOW.

**Intent:** Every plan documented in `docs/PRICING.md` (or canonical pricing doc) has a corresponding Stripe Product + Price. Stripe Test mode mirror has same SKUs as Live mode.

**Strict assertions:**
- For each plan in pricing doc: Stripe Product exists with same `lookup_key`, monthly/annual prices match doc
- No orphan Stripe Products (in Stripe but not in doc)
- No orphan plans in doc (in doc but not in Stripe)
- Test mode = Live mode SKU set (with test mode prices for sandbox)

**`build_instructions` (if drift detected):**
```yaml
files_to_modify:
  - path: docs/PRICING.md (or canonical)
  - path: ops/scripts/sync_stripe_pricing.py (create if absent)
acceptance_criteria:
  - name: pricing_drift_detector
    test: "ops/scripts/check_stripe_pricing_drift.py exits 0 when synced, non-zero when drift"
  - name: tenant_can_subscribe_to_each_plan
    test: "POST /api/v1/billing/subscribe with each plan succeeds in test mode"
edge_cases:
  - Plan price changes between deploys — old subscriptions grandfather, new subscriptions get new price
  - Currency switch (USD↔INR) — test mode supports both; live mode tested separately
  - Annual vs monthly toggle — annual = 10x monthly (or whatever the doc says)
```

---

## MB-002 — Metering accuracy: events → counters → invoice line items

**Primitive:** Metering pipeline.
**Status:** PARTIAL.
**Mode:** SHADOW.

**Intent:** Every billable event (LLM token, voice minute, connector call, agent-hour) flows: emit → metering counter → daily rollup → monthly invoice line item. End-to-end count must reconcile.

**Strict assertions:**
- 100 metered events emitted via probe → 100 events in `workweaver-prod-metering` table
- Daily rollup produces sum that matches event count × per-event quantity
- Monthly invoice line item matches rollup sum
- Per-tenant breakdown isolated (no cross-tenant aggregation)

**Silent-failure check:**
- No silently dropped events (event_count_delta = 100)
- Reconciliation drift between metering counter and invoice = 0

**`edge_cases`:**
- Event emitted in last second of month — assigned to that month's invoice
- Tenant created mid-month — invoice prorates correctly
- Plan changes mid-month — split invoice or proration per plan policy
- Free-tier overage — events above quota counted but not charged (per plan terms)
- Stripe meter event API rate limit — backoff + retry; events queued locally
- Refund for past month — refund recorded as evidence; metering history immutable

---

## MB-003 — Stripe webhook idempotency

**Primitive:** `apps/backend/api/stripe_webhooks.py`.
**Status:** LIVE+TESTED.

(See [tier6-billing/J62](../tier6-billing/README.md#j62--stripe-webhook--tenant-provision).)

---

## MB-004 — Plan upgrade / downgrade

**Primitive:** Subscription state machine.
**Status:** PARTIAL.

**Intent:** Tenant on Free upgrades to Pro mid-month → proration applied, capabilities unlocked immediately, invoice reflects diff. Downgrade Pro → Free at end of period; no refund unless explicitly granted.

**Strict assertions:**
- State transitions per spec (Free → Pro: immediate; Pro → Free: end of period)
- Capability unlocks/locks per the new plan's policy (verified by attempting capability use)
- Invoice line items match expected proration math
- Audit event `subscription_changed` with both old + new plan

**`edge_cases`:**
- Tenant downgrades while exceeding new plan's quota — graceful warning; quotas enforced at next billing cycle
- Tenant upgrades retroactively (admin override) — historical events re-billed at new rate; evidence preserved
- Plan no longer offered — tenant grandfathered until they downgrade or churn

---

## MB-005 — Dunning + churn

**Primitive:** Failed payment recovery.
**Status:** ASPIRATIONAL.

**Intent:** Stripe payment fails → 3-attempt dunning over 14 days → if still fails, transition to GRACE_PERIOD then SUSPENDED.

**Strict assertions:**
- Dunning emails sent at d+1, d+7, d+14
- Tenant state transitions GRACE_PERIOD → SUSPENDED on final failure
- Suspended tenant API returns 423 with `payment_overdue` reason
- Resume payment → tenant SUSPENDED → ACTIVE within 30s of webhook

---

## MB-006 — Refund flow

**Primitive:** Refund processing.
**Status:** ASPIRATIONAL.

**Intent:** Admin issues refund via admin portal → Stripe refund processed → ledger credit recorded → tenant notified.

**Strict assertions:**
- `POST /api/v1/admin/billing/refund` with `{tenant_id, amount, reason}` → 200 + refund_id
- Stripe refund object created
- Evidence event `subscription_refund_issued` with reason
- Tenant inbox notification

**`edge_cases`:**
- Refund amount > original charge — rejected with `refund_overspend`
- Refund of refund (un-refund) — Stripe doesn't support; reissue charge instead
- Currency: refund must match original charge currency
- Partial refund supported

---

## MB-007 — Free-tier quota enforcement

**Primitive:** Quota middleware.
**Status:** PARTIAL.

**Intent:** Free-tier tenant attempting to exceed monthly quota (e.g., 100 free OKRs) → 402 Payment Required with upgrade CTA, NOT silent truncation.

**Strict assertions:**
- 101st free-tier action → 402 with `quota_exceeded`
- Body contains plan name, quota limit, current usage, upgrade CTA URL
- No silent truncation (silent_no_op_violation guard)

---

## MB-008 — Multi-currency + tax

**Primitive:** Currency + tax computation.
**Status:** ASPIRATIONAL.

**Intent:** EU tenant pays in EUR with VAT applied; Indian tenant pays in INR with GST applied; US tenant pays in USD without sales tax (unless physical-presence state requires it).

**Strict assertions:**
- Stripe Price selected based on tenant's billing country
- Tax line item correctly applied
- Invoice rendered in correct locale

---

## MB-009 — Crypto payment preflight (deny-by-default verification)

(See [adversarial/A019](../adversarial/README.md#a019--on-chain-write-hard-preflight-deny-by-default).)

---

## MB-010 — Customer-visible billing portal

**Primitive:** Stripe Customer Portal.
**Status:** PARTIAL.

**Intent:** Tenant clicks "Manage billing" → Stripe-hosted Customer Portal opens (verified domain) → can update payment method, view invoices, cancel.

**Strict assertions:**
- Portal URL signed and short-lived
- Portal returns to verified workweaver.ai callback after action
- Cancel from portal triggers Stripe webhook → state transition

---

## Roadmap MB-011–MB-099

Reserved for: usage-based pricing per skill, group billing (parent org pays for child sub-tenants), quote/contract for enterprise, partner / reseller commissions, marketplace billing for third-party skills.

---

## Related

- [PRIMITIVES.md § 10 Voice + payments](../../PRIMITIVES.md#10-voice--payments)
- [tier6-billing/J60–J64](../tier6-billing/) — billing surface basics
- [adversarial/A019](../adversarial/README.md#a019--on-chain-write-hard-preflight-deny-by-default) — crypto preflight
