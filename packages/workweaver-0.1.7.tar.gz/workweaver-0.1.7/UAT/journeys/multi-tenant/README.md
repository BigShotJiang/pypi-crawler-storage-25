# Multi-Tenant Journeys (M001–M099)

Org → sub-tenant via capability_lease. Cross-org denial. Shared scope semantics. The invariants that keep one tenant's data from another's.

Code truth: `apps/backend/services/capability_lease.py` (line 213–222 enforces `_assert_same_org`).

---

## M001 — Owner tenant + sub-tenant create + verify

**Primitive:** Tenant model + org role.

**Status:** LIVE+TESTED.

**Mode:** REPLAY, SHADOW.

**Sandbox:** owner + sub-tenant (`uat-<run>-founder`, `uat-<run>-coworker`).

**Intent:** Owner creates a sub-tenant via capability_lease. Sub-tenant exists, has limited scope, is queryable by owner.

**Steps:**
1. POST `/api/v1/org/sub-tenants` with `{owner: founder, sub: coworker, scope: memory.org, ttl: 4h}`
2. GET `/api/v1/org/sub-tenants?owner=founder` → list contains coworker
3. GET `/api/v1/leases?source=founder` → ACTIVE lease
4. Sub-tenant authenticates → has scope `memory.org`

**Strict assertions:**
- Lease record persisted with `state=ACTIVE`, `source_org == target_org == founder.org`
- Sub-tenant appears in owner's sub-tenant list
- Sub-tenant cannot see leases (only owner can)

---

## M002 — Capability lease scope enforcement

**Primitive:** Lease verification.

**Status:** LIVE+TESTED.

**Mode:** SHADOW.

**Sandbox:** owner + sub-tenant.

**Intent:** Sub-tenant can read shared org memory under lease, cannot read owner-private memory.

**Steps:**
1. Owner writes memory with scope=ORG → visible
2. Owner writes memory with scope=PRIVATE → not visible
3. Sub-tenant calls `GET /memory/recall?scope=org`
4. Sub-tenant calls `GET /memory/recall?scope=private` → 403

**Strict assertions:**
- Step 3: returns the ORG memory entry
- Step 3: does NOT return the PRIVATE memory entry
- Step 4: returns 403 with `lease_scope_violation`
- Evidence event `memory_lease_scope_check` for each call

---

## M003 — Cross-org denial (write/read attempt) (Codex's #J114)

**Primitive:** `_assert_same_org` guard.

**Status:** LIVE+TESTED.

**Mode:** REPLAY, SHADOW.

**Sandbox:** two unrelated org tenants in different `org_id`s.

**Intent:** Even when both tenants exist + are valid, cross-org access is impossible. The `_assert_same_org` raises `CapabilityLeaseDenied`.

**Steps:**
1. Provision tenants A (org_id=O1) and B (org_id=O2)
2. From A's auth context, attempt POST `/leases` with target=B → 403
3. From A's auth context, attempt POST `/leases` masquerading as O2 → 403
4. From A, attempt GET `/api/v1/org/<O2>/capacity` → 403

**Strict assertions:**
- All cross-org attempts return 403 with `org_capacity_cross_org_denied` or `cross_org`
- No lease record persisted
- Audit event `cross_org_access_denied` recorded
- No data from O2 leaked in any response body

**Silent-failure check:**
- No subset of O2's data returned (even partial)
- No evidence event from O2's namespace appeared

---

## M004 — Lease expiry → access revoked

**Primitive:** Lease TTL + state machine.

**Status:** LIVE+TESTED.

**Mode:** SHADOW.

**Intent:** Lease expires after TTL. Subsequent requests using that lease return 403.

**Steps:**
1. Create lease with TTL=10s
2. Wait 12s
3. Sub-tenant calls API
4. Inspect lease state

**Strict assertions:**
- Lease state transitioned to EXPIRED
- API call returns 403 with `lease_expired`
- Evidence event `lease_expired` recorded
- Lease cannot be re-activated (must create new)

---

## M005 — Sub-tenant memory quota overflow (Codex's #J115)

**Primitive:** Sub-tenant per-day write quota.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Intent:** Sub-tenant attempts to exceed `max_items_per_day` on the lease. Hard-fails with 429, no silent overflow.

**Steps:** see [adversarial/A008](../adversarial/README.md#a008--sub-tenant-memory-quota-overflow-codexs-j115). M005 covers the multi-tenant invariant view.

**Strict assertions:**
- Quota enforced exactly at `max_items_per_day`
- Evidence event `lease_quota_exceeded` records the rejection
- Quota resets at midnight (or per-day rolling window per contract)

---

## M006 — Email invitation flow (PARTIAL)

**Primitive:** UI invitation acceptance.

**Status:** PARTIAL.

**Mode:** SHADOW (gstack browse).

**Sandbox:** owner; sub-tenant invited via email.

**Intent:** Owner sends invite via UI. Recipient clicks email link, signs in, sub-tenant created automatically.

**Steps:**
1. Owner: POST `/org/invitations` with email
2. Email arrives in MailHog (or sandbox SMTP)
3. Recipient clicks link → SPA opens with token
4. Recipient signs in → sub-tenant linked to owner

**Strict assertions:**
- Email contains valid signed token
- Token consumes exactly once (replay denied)
- Sub-tenant created on accept with right org binding
- Lease created automatically with default scope

**Blocked by missing:** #INVITE-001. Until then: M006 grace permitted; CLI device-code share (M007) is the substitute.

---

## M007 — CLI device-code invitation share

**Primitive:** Sub-tenant onboarding via device code.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Intent:** Owner can grant a sub-tenant access without email, via CLI device-code share.

**Steps:**
1. Owner: `ww org invite-sub --display-name "Coworker"` → returns user_code + verification_uri
2. Sub-tenant operator: `ww org accept --user-code <code>` → completes
3. Verify both tenants

**Strict assertions:**
- One lease created
- Sub-tenant authenticated successfully
- Audit trail records both sides

---

## M008 — Sub-tenant overflow routing (capacity)

**Primitive:** OrgCapacityIndex overflow same-org.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Intent:** Sub-tenant requests capacity that exceeds its own envelope. Same-org peers with spare capacity are routed via capability_lease overflow, not cross-org.

**Steps:**
1. Sub-tenant1 capacity = 0 used / 4 max
2. Sub-tenant2 capacity = 4 used / 4 max
3. Sub-tenant2 requests work that needs +1 worker
4. Org capacity index routes to sub-tenant1 via overflow lease
5. Inspect

**Strict assertions:**
- Routing decision evidence event recorded
- Overflow lease created within org
- No cross-org routing attempted
- Capacity counters update on both ends

---

## M009 — Tenant pause / resume

**Primitive:** Tenant subscription state machine.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Intent:** Admin pauses a tenant. All in-flight missions halt; new requests return 423 Locked. Resume restores access.

**Steps:**
1. Tenant active, mission running
2. Admin: `POST /admin/tenants/{id}/pause`
3. Mission halts
4. Tenant attempts new request → 423
5. Admin: `POST /admin/tenants/{id}/resume`
6. Tenant succeeds

**Strict assertions:**
- Mission state transitions to `paused_admin` (not silently terminated)
- 423 returned with `tenant_paused`
- Audit event records pause/resume by admin actor
- Resume reactivates mission OR requires explicit user resume (per contract)

---

## M010 — Tenant suspension (irrecoverable)

**Primitive:** Tenant termination.

**Status:** LIVE+UNTESTED.

**Intent:** Admin suspends tenant. State persists for audit; tenant cannot be reactivated through self-service.

**Strict assertions:**
- Tenant state SUSPENDED
- All API calls return 423 with `tenant_suspended`
- Self-service reactivation denied (only super-admin can)
- Evidence preserved for retention period

---

## M011 — Tenant data deletion request (privacy)

**Primitive:** Right-to-erasure.

**Status:** LIVE+UNTESTED.

**Intent:** Tenant requests data deletion. Active data is purged; evidence ledger entries are tagged `redacted` (WORM cannot delete) but PII fields are scrubbed.

**Steps:**
1. Tenant: `POST /tenant/erasure`
2. Backend kicks job
3. Wait
4. Verify

**Strict assertions:**
- Active data (memory, missions, time blocks) purged
- Evidence ledger entries: PII fields replaced with `[REDACTED]`
- Evidence event `tenant_erasure_completed` recorded
- Tenant flag `erasure_completed: true`

**Blocked by missing:** Some PII scrubbing rules (#PII-SCRUB-001).

---

## Roadmap M012–M099

Reserved for: invitation token replay denial, sub-tenant chain depth limit, role transfer, sub-tenant deactivation by owner, sub-tenant rejoining org, multi-org user, audit trail completeness for tenant lifecycle, billing on tenant suspend.

---

## Related

- [PRIMITIVES.md § 7 Multi-tenant + capability_lease](../../PRIMITIVES.md#7-multi-tenant--capability_lease)
- [adversarial/A006 stale capability cache](../adversarial/README.md#a006--stale-capability-cache-leak-geminis-j-adv-02-simplified)
- [adversarial/A007 mid-flight lease revocation](../adversarial/README.md#a007--mid-flight-lease-revocation-geminis-j-adv-02-full)
- [PERSONAS.md § P-COWORKER](../../PERSONAS.md#p-coworker--invited-sub-tenant)
