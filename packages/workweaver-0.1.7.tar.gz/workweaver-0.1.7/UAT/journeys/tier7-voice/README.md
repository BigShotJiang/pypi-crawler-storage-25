# Tier 7 — Voice + Zara (J70–J79)

Twilio inbound, Zara phone identity, in-call tooling, transcription. Voice provider failover roadmap.

---

## J70 — Twilio voice inbound webhook

**Primitive:** `/api/twilio/voice/inbound`.
**Status:** LIVE+TESTED.

**Setup:** Use Twilio test number; trigger via Twilio's curl-based webhook simulator OR a tape in REPLAY.

**Strict assertions:**
- Status 200
- Response is TwiML (XML, valid)
- Response includes `<Connect>` to Zara session
- Phone number in body resolved to a tenant (`grok_tenant_context.resolve_from_twilio_phone`)
- Evidence event `twilio_voice_inbound` recorded

**Silent-failure check:** Tenant resolved is the right one (not a default catch-all).

---

## J71 — Twilio status webhook

**Strict assertions:**
- `POST /api/twilio/voice/status` → 200
- Status transitions captured (initiated → in-progress → completed)
- Evidence chain links statuses

---

## J72 — Twilio recording status

**Strict assertions:**
- Recording webhook → 200
- Recording URL stored
- Recording referenced from call evidence

---

## J73 — Zara phone identity resolves

**Strict assertions:**
- Inbound from known phone → tenant correctly identified
- Inbound from unknown phone → graceful "general inquiry" handling, not crash

---

## J74 — In-call tool calling

**Status:** LIVE+UNTESTED.
**Mode:** SHADOW.

**Strict assertions:**
- Zara invokes a tool mid-call (e.g., schedule meeting)
- Tool call recorded in evidence
- Decision trace shows ALLOW with tenant scope

---

## Roadmap J75–J79

J131 — voice provider failover (Twilio → xAI grok-voice). Tracked at [adversarial/A018+](../adversarial/README.md). Reserved for: outbound call, multi-language transcription assertion, conference join.
