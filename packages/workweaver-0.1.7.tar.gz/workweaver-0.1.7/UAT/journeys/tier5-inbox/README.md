# Tier 5 — Inbox + Judgment (J50–J59)

Inbox surface, judgment queue, emergency brake.

---

## J50 — Inbox surface API

**Strict assertions:**
- `GET /api/v1/inbox/items` → 200
- Body has `items` array
- Each item has `id`, `kind`, `priority`, `created_at`, `requires_action` ∈ {true, false}

---

## J51 — Judgment queue

**Strict assertions:**
- `GET /api/v1/inbox/judgment` → 200
- Each item has `decision_id`, `proposal`, `alternatives`, `expires_at`

---

## J52 — Emergency brake (smoke)

**Primitive:** `POST /api/v1/inbox/emergency-brake`.
**Status:** LIVE+UNTESTED.

**Strict assertions:** see [adversarial/A018](../adversarial/README.md#a018--inbox-emergency-brake) for full flow. J52 is the smoke check — endpoint accepts and returns 202.

---

## Roadmap J53–J59

Reserved for: inbox UI rendering, ack flow, snooze, escalation.
