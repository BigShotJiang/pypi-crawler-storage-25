# Adversarial Journeys (A001–A099)

The most expensive class to test, the most damaging to skip. Each journey here exercises a known failure boundary or attack vector. Coverage is **mandatory** for any primitive in `LIVE+TESTED` status.

Numbering is reserved (gaps allow growth). Cross-references in [PRIMITIVES.md](../../PRIMITIVES.md).

---

## A001 — Token / cost circuit breaker (Gemini's J-ADV-01)

**Primitive:** Zara cognition (gradient_engine), inference budget enforcement.

**Status:** LIVE+UNTESTED.

**Mode:** REPLAY, SHADOW.

**Sandbox:** per-run (founder + adversary).

**Intent:** A gradient-descent loop is given a task with an intentionally broken connector that returns retryable error indefinitely. Verify the loop circuit-breaks on token / cost limit, halts execution, alerts the founder, and records `error_code: ERR_ECONOMIC_LIMIT` in evidence.

**Setup:**
- Sandbox tenant: `uat-<run>-adversary`
- Token budget: $0.10
- Connector: mock Gmail returning 503 with `Retry-After: 1` indefinitely
- Goal: "Send 1 outreach email to mock@invalid"

**Strict assertions:**
- After ≤ 30 retries OR token spend ≥ $0.10, loop halts
- Mission state transitions to `failed`, outcome `aborted_economic_limit`
- Evidence event `economic_circuit_breaker_tripped` recorded with retry count + spend
- Subsequent `POST /missions/{id}/run` returns 423 Locked with reason `economic_limit_exceeded`
- Founder receives an inbox notification (verifiable via `GET /api/v1/inbox/items?type=alert`)

**Silent-failure check:**
- No mission silently retried after halt
- Cost meter accurately reflects spend
- No zombie agent instances in the agent_instance_manager

**Judge rubric:** none (deterministic).

---

## A002 — WORM evidence poison pill (Gemini's J-ADV-03 + Codex's #J123 silent-failure detector)

**Primitive:** Evidence Ledger immutability.

**Status:** LIVE+TESTED.

**Mode:** SHADOW (uses real S3 Object Lock semantics in shadow bucket).

**Sandbox:** per-run.

**Intent:** Adversary writes a legitimate evidence event then attempts every conceivable mutation path. Each attempt must fail with the right error and be itself recorded.

**Setup:**
- Sandbox tenant + shadow ledger
- Subject_id: `uat:<run_id>:adversary:worm-poison-pill`

**Steps:**
1. POST canonical write `e1` (kind=`adversary_probe_initial`)
2. PUT to `/evidence/{e1.id}` with new payload → expect 405 / 403
3. DELETE `/evidence/{e1.id}` → expect 405 / 403
4. POST another event with same `event_id` (forged) → expect 409 with `event_id_collision`
5. PATCH local SQLite mirror of `e1`, then POST sync → expect 422 with `evidence_immutable_remote_rejection`
6. Forge a higher revision in sync push → expect rejection
7. GET `/evidence/{e1.id}` → assert payload matches step 1 byte-for-byte (hash check)

**Strict assertions:**
- Initial hash equals final hash
- Every mutation attempt returned a non-success code (no 200/201/204 for any)
- Each attempted mutation produced its own evidence event of kind `evidence_mutation_rejected`
- The decision trace for the original write contains alternative `mutation_allowed=false, reason=worm_immutable`

**Silent-failure check:**
- No request returned 200 (even if body said "rejected")
- No event got silently dropped (rejection events are themselves persisted)
- Sync push of mutated mirror does NOT update the cloud copy

**Judge rubric:** none.

---

## A003 — Silent partial mutation detector (Codex's #J123)

**Primitive:** Mission Calendar update + decision trace.

**Status:** LIVE+TESTED.

**Mode:** REPLAY, SHADOW.

**Sandbox:** per-run.

**Intent:** Trigger a multi-field mutation that should update fields A and B atomically. Inject failure midway. Verify the system rolls back fully (no field A updated, no field B updated) OR commits fully (both updated). No half-state.

**Setup:**
- TimeBlock T with fields `label` and `phase`
- Backend instrumented to fail field B's write after field A succeeds (via injected fault, see [runner/fault_injection.py](../../runner/fault_injection.py))

**Steps:**
1. PATCH `/timeblocks/T` with `{label: "X", phase: "Y"}`
2. Server attempts write of field A → succeeds
3. Server attempts write of field B → injected failure
4. GET `/timeblocks/T`

**Strict assertions:**
- Final state = original state OR final state = both fields updated
- Final state is NEVER {label: "X", phase: original_value} (silent partial)
- Evidence event of kind `timeblock_partial_failure_rolled_back` if rollback was taken

**Silent-failure check:**
- Resource checksum delta is 0 (no fields changed) OR full delta (both fields)
- Revision delta is 0 (no commit) OR exactly +1 (atomic commit)

---

## A004 — Token-refresh race storm (Workweaver code-truth: `api-base.js:189–197`)

**Primitive:** UI auth + 401 → refresh.

**Status:** LIVE+UNTESTED.

**Mode:** REPLAY, SHADOW.

**Sandbox:** per-run.

**Intent:** Force concurrent 401s to test refresh-promise singleton behavior. If broken, multiple concurrent refreshes happen and the wrong token leaks to in-flight requests.

**Setup:**
- gstack browse session with valid cookie
- Inject expired access token via `localStorage.setItem('ww.access_token', '<expired>')`

**Steps:**
1. Open Mission Control
2. Issue 10 parallel `fetch('/api/v1/missions')` calls
3. All should hit 401
4. Refresh promise singleton handles refresh once
5. All 10 retried with new token

**Strict assertions:**
- Network log shows exactly **one** `/api/v1/auth/refresh` call (singleton enforcement)
- All 10 retried calls return 200
- No request used the old expired token after refresh completed
- No request silently failed without retry

**Silent-failure check:**
- DevTools console: no toast errors silently swallowed
- All 10 requests have a clear success/failure outcome (no `pending` after 5s)

---

## A005 — AI hallucination → schema correction loop (Gemini's J-ADV-05)

**Primitive:** ACP daemon + tool calling.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW (uses real LLM that can hallucinate; LIVE for nightly).

**Sandbox:** per-run.

**Intent:** Send Zara a deliberately ambiguous request that causes an LLM to emit an invalid JSON-RPC payload to a tool. The ACP daemon must:
1. Catch the schema violation BEFORE execution
2. Feed the schema error back to Zara
3. Zara self-corrects on next iteration without user intervention
4. Tool call eventually succeeds

**Setup:**
- ACP daemon running with strict schema validation enabled
- LLM judge model called for grading the correction quality

**Steps:**
1. ACP daemon receives `agent/run` with prompt: "send urgent message to my boss"
2. LLM generates first tool call (likely missing `to:` field)
3. ACP catches → returns `{error: schema_violation, missing: [to]}`
4. Zara generates second tool call with `to:` field guessed/inferred
5. If still wrong, repeat up to 3 times

**Strict assertions:**
- First tool call captured (may be malformed)
- Schema validator emitted a structured error
- Subsequent tool call attempts visible in trace
- Eventually a valid call lands or the loop exits with `tool_call_correction_failed` after N retries

**Judge rubric:**
- C1: Schema error returned to Zara is actionable (specific missing fields named) — score 0–10
- C2: Zara's second attempt addresses the prior error (not random retry) — score 0–10
- C3: Total iterations ≤ 3 (efficient correction) — score 0–10
- C4: Final state is either valid call OR explicit failure trace, never silent timeout — score 0–10
- C5: User-visible error is clear if correction fails — score 0–10

Pass: all ≥ 7, overall PASS.

---

## A006 — Stale capability cache leak (Gemini's J-ADV-02 simplified)

**Primitive:** Capability lease verify + cache.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Sandbox:** per-run with org owner + sub-tenant + lease.

**Intent:** A sub-tenant's capability_lease is REVOKED. Any in-flight request from the sub-tenant must respect the revocation, even if the auth token cache has not yet refreshed.

**Setup:**
- Owner tenant, sub-tenant, lease `L1` ACTIVE
- Sub-tenant initiates long-running task (e.g., outreach swarm)

**Steps:**
1. Sub-tenant POSTs `/missions/{id}/run` (returns 202 Accepted)
2. Mid-task, owner POSTs `/leases/{L1}/revoke`
3. Sub-tenant continues processing in-flight requests
4. Sub-tenant attempts next sub-action against the lease

**Strict assertions:**
- Step 4 returns 403 with `capability_lease_revoked`
- Mission state transitions to `cancelled` with reason `lease_revoked_mid_flight`
- No further connector / external calls happen after revocation timestamp
- Evidence event `capability_lease_revoked_mid_flight` recorded
- Cache is invalidated (subsequent attempt with same in-memory cache returns 403)

**Silent-failure check:**
- No connector call dated AFTER revocation timestamp
- No agent instance survives revocation
- Audit trail includes lease state at request time + state at execution time

---

## A007 — Mid-flight lease revocation (Gemini's J-ADV-02 full)

**Primitive:** Capability lease + swarm.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Sandbox:** owner + sub-tenant.

**Intent:** Sub-tenant initiates a Slack outreach swarm. Owner revokes `connector:slack` mid-execution. The swarm must:
1. Halt cleanly (no zombie workers)
2. Stop further Slack API calls
3. Mark Mission Calendar block as `unproductive` with security denial trace

**Setup:**
- Sandbox tenant + sub-tenant + capability_lease for `connector:slack`
- Sub-tenant configured with Slack connector via lease
- Mission of "Send to 5 Slack channels"

**Steps:**
1. Sub-tenant: `POST /missions/{id}/run` → swarm starts, 5 agents
2. Wait until 2 agents have called Slack
3. Owner: `POST /leases/{slack_lease_id}/revoke`
4. Wait 5 s
5. Inspect: Mission state, agent states, evidence trace

**Strict assertions:**
- Mission transitions to `cancelled`
- All 5 agents transition to `cancelled` (none stuck `running`)
- Slack API calls after revocation timestamp = 0
- Mission's TimeBlock has `outcome: aborted` and `block_type: security_revocation`
- Evidence trace shows alternative `swarm_continued=false, reason=lease_revoked`

**Silent-failure check:** see A006.

---

## A008 — Sub-tenant memory quota overflow (Codex's #J115)

**Primitive:** WorkMemory tier limits.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Sandbox:** owner + sub-tenant.

**Intent:** Sub-tenant attempts to write more memory entries than its lease's per-day quota. The system must hard-fail with bounded error, not 200-with-truncated-state.

**Setup:**
- Sub-tenant lease quota: 100 memory writes/day
- Sandbox WorkMemory pre-loaded with 99 entries

**Steps:**
1. POST 1 more (within quota) → 200
2. POST another → expect 429 with `quota_exceeded`
3. Verify count in DB = 100 exactly (no overflow, no off-by-one)

**Strict assertions:**
- Step 2 returns 429
- DB count ≤ quota
- Evidence event `memory_quota_exceeded` for step 2
- No silent truncation (either accept and overflow OR reject with 429; not "accept but only persist 99")

**Silent-failure check:**
- Resource checksum after step 2 == before step 2 (no DB write)
- Sub-tenant `last_memory_write_at` not updated after rejection

---

## A009 — Schema-invalid connector payload (Codex's #J122)

**Primitive:** Connector schema validation.

**Status:** LIVE+UNTESTED.

**Mode:** REPLAY, SHADOW.

**Sandbox:** per-run.

**Intent:** Send a connector a payload that violates its declared schema (e.g., wrong type, extra fields, missing required). The system must hard-fail at the schema boundary, not pass it through and let the upstream return 400.

**Setup:**
- Mock Gmail connector with strict schema
- Payload: `{to: 12345 /* should be string */, subject: null, body: "x"}`

**Steps:**
1. POST `/connectors/gmail/execute` with above
2. Inspect response

**Strict assertions:**
- Status 422 (not 400 from upstream, not 200)
- Body explicit: `error: schema_violation` + `field_errors: {to: ..., subject: ...}`
- No upstream API call made (network witness)
- Evidence event `connector_schema_violation_pre_dispatch` recorded

**Silent-failure check:**
- Connector's outbound network log is empty
- Upstream service was not invoked

---

## A010 — Toast suppression silent failure (Workweaver UI code-truth)

**Primitive:** UI design system toast.

**Status:** LIVE+UNTESTED.

**Mode:** REPLAY (gstack browse).

**Sandbox:** per-run.

**Intent:** Force a state where `localStorage` is full or disabled. Trigger an action that should toast. Verify that the system DOES NOT silently degrade — either toast renders, or an alternative user-visible signal fires.

**Setup:**
- gstack browse with `localStorage.clear()` + fill with junk to near quota
- Trigger 403 on a permission-denied path

**Strict assertions:**
- Either: a toast renders (visible in DOM)
- Or: a fallback indicator (modal, banner, console error visible to user) fires
- NEVER: action completed silently with no user-visible signal

**Silent-failure check:**
- DOM after action contains at least one of: toast, modal, banner, error chip
- DevTools console captured at least one user-readable error string

---

## A011 — PII leak into raw L1 WorkMemory (Gemini's #1 missing primitive)

**Primitive:** WorkMemory ingestion + PII scrubbing.

**Status:** PARTIAL (admission_service has hooks; PII scrubbing is `blocked_by_missing #PII-SCRUB-001`).

**Mode:** SHADOW.

**Sandbox:** per-run.

**Intent:** Submit a memory write that contains obvious PII (SSN, credit card, full DOB). The system must:
1. Detect PII at ingestion
2. Either redact + write OR reject with `pii_admission_blocked`
3. Record the admission decision in evidence

**Setup:**
- Memory write probe: "User john_doe SSN 123-45-6789 CC 4111-1111-1111-1111 DOB 1990-01-15"

**Strict assertions:**
- Either: stored entry has redacted form (`[REDACTED:SSN]`, `[REDACTED:CC]`)
- Or: rejection with structured `pii_admission_blocked` and a reason field
- Evidence event `memory_admission_decision` recorded with `pii_classification` field

**Blocked by missing:** #PII-SCRUB-001. Until then: this journey runs in SHADOW only and grace events are accepted (does not gate runs).

---

## A012 — SSE silent reconnect (Workweaver UI code-truth: `sse-reconnect.js`)

**Primitive:** UI server-sent events.

**Status:** LIVE+TESTED.

**Mode:** REPLAY (gstack browse).

**Sandbox:** per-run.

**Intent:** A user browses Mission Control. Backend is restarted. The SSE stream reconnects. The user must see a status indicator during reconnect.

**Steps:**
1. gstack browse → Mission Control (SSE active)
2. Restart backend container (or kill connection)
3. Wait for reconnect
4. Verify UI

**Strict assertions:**
- A status indicator (chip / toast / banner) appeared during reconnect
- The reconnect message is reasonable (not "page broken" or null)
- After reconnect, fresh data loads
- A reconnect event was recorded in evidence

**Silent-failure check:**
- DOM during reconnect shows clear "reconnecting" affordance
- After reconnect, data is fresh (revision incremented since reconnect)

---

## A013 — Memory false-memory correction race

**Primitive:** WorkMemory false-memory correction.

**Status:** PARTIAL.

**Mode:** SHADOW.

**Sandbox:** per-run.

**Intent:** Two contradictory memory entries are written close in time. The correction service must reconcile (quarantine the contradicted, mark the contradictor) without losing either.

**Steps:**
1. Memory write `M1`: "ACME Corp pricing is $99/mo"
2. Memory write `M2`: "ACME Corp pricing is $199/mo" (within 1 second)
3. Correction probe runs
4. Inspect results

**Strict assertions:**
- Both M1 and M2 persist (not silently dropped)
- One is marked `quarantined: true` with `contradicted_by` referencing the other
- Confidence scores are updated
- Decision trace explains the correction

**Silent-failure check:**
- Neither memory was silently overwritten
- Evidence event `memory_contradiction_quarantine` recorded
- Subsequent recall returns the canonical entry only

**Blocked by missing:** correction service is partial; this journey runs but grace permitted.

---

## A014 — Empty-state silent rendering

**Primitive:** UI empty states.

**Status:** PARTIAL.

**Mode:** REPLAY.

**Sandbox:** per-run (fresh tenant, no data).

**Intent:** A fresh tenant with no goals, no memory, no missions, no evidence visits each surface. Every surface must render a meaningful empty state, not a blank page or a JS error.

**Steps:**
For each surface in [`/runtime/#/mission`, `/runtime/#/inbox`, `/runtime/#/settings`, `/runtime/#/memory`]:
- gstack browse goto
- gstack screenshot
- gstack text

**Strict assertions:**
- Page title contains the surface name
- Page contains an explicit "no <noun> yet" message OR onboarding prompt
- Page does NOT contain "undefined", "null", "[object Object]", stack trace text
- Console errors max 0

**Blocked by missing:** #EMPTY-STATE-001 — empty-state components inconsistent. Grace permitted on surfaces that haven't shipped yet.

---

## A015 — Cookie staleness mid-suite

**Primitive:** Auth session + UAT runner.

**Status:** LIVE+UNTESTED.

**Mode:** LIVE.

**Sandbox:** per-run.

**Intent:** A 40-minute LIVE run experiences cookie expiry mid-suite. The runner must detect stale cookies and refresh OR halt cleanly with `auth_session_expired`.

**Setup:**
- LIVE mode
- Backend session timeout: 30 minutes
- Run a journey set whose total runtime > 35 min

**Strict assertions:**
- Cookie staleness detected
- Runner refresh path taken (or halted cleanly)
- Mid-suite journeys after staleness detection retry once with refreshed cookie
- No journey silently failed due to expired session

**Silent-failure check:**
- Cookie refresh resulted in successful retry, not silent skip
- Run report correctly attributes any failures to actual journey failure (not session)

---

## A016 — Browser resource exhaustion (Chromium OOM)

**Primitive:** UAT runner browser pool.

**Status:** LIVE+UNTESTED.

**Mode:** REPLAY, LIVE.

**Sandbox:** per-run.

**Intent:** A 200-journey LIVE suite would OOM Chromium if not properly chunked. The runner must restart Chromium between batches AND surface the restart.

**Steps:**
- Run 250 dummy journeys (each loads a full Mission Control + screenshots)
- Monitor Chromium memory + restart count

**Strict assertions:**
- Chromium memory never exceeds threshold (default 4 GiB)
- Browser restarted at least once during the run (proves chunking)
- Each restart logged with reason `browser_periodic_restart` or `browser_oom_threshold`
- All 250 journeys complete (no skipped due to OOM)

**Silent-failure check:**
- Run report shows restart count
- No journey silently quarantined due to crashed browser

---

## A017 — Connector OAuth callback replay attack

**Primitive:** Connector OAuth state validation.

**Status:** LIVE+TESTED (per #1152).

**Mode:** SHADOW.

**Sandbox:** per-run.

**Intent:** Adversary captures an OAuth `state` token from a legitimate flow and replays it. The system must reject with `oauth_state_replay_detected`.

**Steps:**
1. Initiate connector OAuth → capture `state`
2. Complete OAuth → success
3. Replay captured `state` against the callback
4. Verify rejection

**Strict assertions:**
- Step 3 returns 401 / 403 with `oauth_state_replay_detected`
- No new connector created
- Evidence event `oauth_state_replay_attempted` recorded

---

## A018 — Inbox emergency brake

**Primitive:** Inbox emergency brake.

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Sandbox:** per-run.

**Intent:** User pulls the emergency brake mid-mission. All running missions halt, all swarms cancel, no further connector calls fire.

**Steps:**
1. Sandbox: 3 active missions, each with 2 agents
2. POST `/inbox/emergency-brake`
3. Wait 5 s
4. Inspect mission states + connector logs

**Strict assertions:**
- All missions transitioned to `cancelled` with reason `emergency_brake`
- All agents stopped (no zombie)
- No connector calls dated after brake timestamp
- Evidence event `emergency_brake_engaged` per mission

---

## A019 — On-chain write hard preflight (deny-by-default)

**Primitive:** Crypto on-chain write policy (`apps/backend/services/on_chain_write_policy.py`).

**Status:** LIVE+UNTESTED.

**Mode:** SHADOW.

**Sandbox:** per-run.

**Intent:** Without a signed proposal + KeyCustody backend + active capability_lease + allow-listed address, every on-chain write attempt must DENY with structured reason.

**Steps:**
1. POST `/governance/payment-preflight` with a crypto payment intent
2. Without any of: signed_proposal, key_custody_backend, capability_lease, allowlisted_address
3. Inspect verdict

**Strict assertions:**
- Verdict: DENY
- Sub-verdicts each list the missing precondition
- Evidence event `on_chain_payment_preflight_denied` recorded
- No outbound chain RPC called (network witness)

---

## A020 — Mission run idempotency

**Primitive:** Mission run idempotent retry.

**Status:** LIVE+UNTESTED.

**Mode:** REPLAY, SHADOW.

**Sandbox:** per-run.

**Intent:** POST `/missions/{id}/run` with identical idempotency key twice. Second call must not double-execute.

**Steps:**
1. Create mission M
2. POST `/missions/M/run` with `Idempotency-Key: K1` → 202
3. POST `/missions/M/run` with `Idempotency-Key: K1` again → 200 (idempotent re-read of result) OR 409 (idempotency conflict, same)
4. Verify only ONE mission run occurred

**Strict assertions:**
- Mission run count: 1 (not 2)
- Connector calls: count from first run only
- Evidence events for run: count from first run only
- Second response either 200 (replay) or 409 (conflict)

**Silent-failure check:**
- State change between two responses == 0
- No double-emission

---

## Roadmap A021–A099

Reserved for: Stripe webhook signature replay, voice provider failover (J131), DKIM/SPF outbound enforcement, MCP tool injection attack, supply-chain skill manifest tamper, time-bomb evidence retention check, IAM role assumption boundary, connector pool exhaustion, decision-trace replay determinism (W006), gradient regression rollback (Z006), auto-promotion gate bypass attempt (S008).

Each gets its own row when written. Reserve through this README's table when claiming.

---

## Related

- [PHILOSOPHY.md § 3 Silent-failure detection is mandatory](../../PHILOSOPHY.md#3-silent-failure-detection-is-mandatory)
- [SILENT-FAILURE-DETECTOR.md](../../SILENT-FAILURE-DETECTOR.md)
- [WORM-LEDGER-FIXTURE.md](../../WORM-LEDGER-FIXTURE.md)
- [PERSONAS.md § P-ADVERSARY](../../PERSONAS.md#p-adversary--hostile--careless-user)
