# Workweaver UAT — Exploratory User Acceptance Testing

> Canonical, exploratory, adversarial. One command. Real users mimicked. Code-truth honest.

This directory is the **single source of truth** for Workweaver's user acceptance test surface. All Makefile targets, scripts, and documentation resolve from here.

---

## Quickstart

```bash
# Run the entire UAT suite in REPLAY mode (fast, mocked, deterministic)
make uat

# Live mode against workweaver.ai (nightly, hits real services)
make uat-live

# Shadow mode — live infra but isolated tenant + ephemeral evidence ledger
make uat-shadow

# Single journey
make uat JOURNEYS=J122,A003

# A persona end-to-end run
make uat PERSONA=founder
```

The runner ([runner/uat-run.sh](./runner/uat-run.sh)) handles dispatch, parallelism, sandboxing, evidence collection, and report rendering. The slash command `/uat` is equivalent.

---

## Why this exists

Workweaver is an **autonomous business operating system**, not a CRUD app. Standard UAT methodology (deterministic YAML against hand-written assertions) breaks against:

- **Gradient-descent AI loops** that legitimately revise plans mid-flight
- **WORM evidence ledgers** that cannot be polluted with test data (S3 Object Lock, 2555-day retention)
- **Multi-tenant sub-tenant capability_lease invariants** that must be adversarially exercised, not just happy-pathed
- **Edge↔Cloud OCC + per-field CRDT** semantics where the bug surface is "two-node deterministic replay," not "single-context happy path"
- **Whitebox decision traces** where presence is worthless without contestability and replay determinism

Read [PHILOSOPHY.md](./PHILOSOPHY.md) before adding journeys. The non-obvious primitives — **shadow ledger fixture**, **per-run sandbox tenant**, **record-replay mode**, **strict assertions**, **silent-failure detector**, **LLM-as-judge** — are what make this suite trust-building rather than theatre.

---

## Layout

| Path | Purpose |
| --- | --- |
| [README.md](./README.md) | This file |
| [PHILOSOPHY.md](./PHILOSOPHY.md) | Six structural principles. Read first. |
| [TAXONOMY.md](./TAXONOMY.md) | Journey ID conventions, tier system, naming |
| [PRIMITIVES.md](./PRIMITIVES.md) | Each primitive → contracts → journeys (cross-reference index) |
| [PERSONAS.md](./PERSONAS.md) | Five user personas + adversary, code-truth status per persona |
| [BLOCKERS.md](./BLOCKERS.md) | Auto-generated from GitHub issues; gates broad UAT initiation |
| [ROADMAP.md](./ROADMAP.md) | Aspirational journeys + `blocked_by_missing` markers |
| [PARITY-CONTRACT.md](./PARITY-CONTRACT.md) | Schema-driven UI/CLI/MCP/API equivalence test |
| [WORM-LEDGER-FIXTURE.md](./WORM-LEDGER-FIXTURE.md) | Shadow-ledger protocol for ephemeral test evidence |
| [SANDBOX-TENANT.md](./SANDBOX-TENANT.md) | Per-run isolated tenant lifecycle |
| [REPLAY-MODE.md](./REPLAY-MODE.md) | Connector + LLM record/replay protocol |
| [STRICT-ASSERTIONS.md](./STRICT-ASSERTIONS.md) | No-permissive-codes contract |
| [SILENT-FAILURE-DETECTOR.md](./SILENT-FAILURE-DETECTOR.md) | Checksum + revision delta + event-count assertions |
| [LLM-AS-JUDGE.md](./LLM-AS-JUDGE.md) | Non-deterministic AI grading rubric |
| [SELF-CONTAINED-FAILURE.md](./SELF-CONTAINED-FAILURE.md) | Failure-message contract: every blocked_by_missing carries a buildable AI-agent kit |
| [LAUNCH-SIGNOFF.md](./LAUNCH-SIGNOFF.md) | Honest assessment: what UATs cover vs what's missing for paid GA launch |
| [SELFHOST.md](./SELFHOST.md) | Self-host parity (15 SH tests) |
| [journeys/](./journeys/) | Tier 0-10 + cross-cutting (adversarial, parity, edge, multi-tenant, whitebox, zara, skills) |
| [personas/](./personas/) | End-to-end persona scripts (J-P-FOUNDER, J-P-COWORKER, etc.) |
| [chrome/](./chrome/) | gstack browse executable scripts (T01-T24) |
| [cli/](./cli/) | `ww` CLI scenarios |
| [selfhost/](./selfhost/) | SH01-SH15 |
| [runner/](./runner/) | Single-command runner + parallel dispatcher + judges |
| [lib/](./lib/) | Shared shell + python helpers |
| [tools/](./tools/) | Operator tooling (cookie import, tenant bootstrap) |
| [results/](./results/) | Dated evidence (gitignored except README) |

---

## What this suite tests

### Primitives covered (verified against [PRIMITIVES.md](./PRIMITIVES.md))

- **Zara cognition** — OKR interview, multi-step planning, gradient descent, swarm composition
- **WorkMemory** — L1→L2→L3→L4 tier promotion, scope (org/team/agent), false-memory correction
- **Evidence Ledger + Decision Trace** — WORM immutability, alternatives-considered, contestability, replay determinism
- **Mission Calendar** — TimeBlock productivity scoring, capacity reservations
- **ACP Daemon** — JSON-RPC 2.0 stdio, consume + be-consumed
- **Connectors** — Tier 1 OAuth (Gmail, Slack, GitHub, Zoom), Stripe, Twilio, Zoho suite, MCP passthrough, computer-use fallback chain
- **Multi-tenant** — Org owner → sub-tenant via capability_lease, cross-org denial, mid-flight revocation
- **Edge↔Cloud sync** — Revision-OCC + per-field CRDT, semantic collisions, offline resilience
- **Admin parity** — UI ↔ CLI ↔ MCP ↔ API equivalence (schema-driven contract)
- **Voice + payments** — Twilio inbound/outbound, Stripe webhooks, crypto deny-by-default
- **Skills compounding** — Skillify 10-dim proof bundle, hygiene heartbeat, MCC eval correlation
- **Whitebox AI** — Decision trace utility (not just presence), contestability, replay determinism
- **CLI auth + offline** — RFC 8628 device code, mode awareness (cloud/self-host/hybrid/offline)
- **UI/UX** — Design tokens, error boundaries, empty states, silent-failure paths, toast reliability

### Failure modes covered (per [PHILOSOPHY.md](./PHILOSOPHY.md))

- Silent partial mutations (checksum mismatch, revision delta zero)
- Mid-flight capability_lease revocation
- WORM poison-pill (attempt to mutate evidence)
- Semantic CRDT collision (LWW on JSON-RPC payload corruption)
- Token-refresh race storms
- Economic exhaustion (token burn, Stripe balance)
- AI hallucination → schema correction loop
- Cookie staleness mid-suite
- Browser resource exhaustion (Chromium OOM)

---

## Modes

| Mode | When | Cost | Side effects |
| --- | --- | --- | --- |
| **REPLAY** (default) | Every commit, CI gate | <2 min | None — fully mocked |
| **SHADOW** | Pre-merge for risky changes | ~10 min | Ephemeral tenant, shadow evidence ledger, auto-cleaned |
| **LIVE** | Nightly + pre-deploy | ~45 min | Real services hit; tenant marked `uat-live-<run-id>` for forensics |

REPLAY is the default because UAT must be fast enough to run on every PR. SHADOW gives confidence under live infra without polluting the WORM ledger. LIVE is the truth check.

---

## How to add a journey

1. Pick the right collection: existing tier (`journeys/tier*/`), cross-cutting (`adversarial/`, `contract-parity/`, etc.), or new persona.
2. Read [TAXONOMY.md](./TAXONOMY.md) for ID conventions. Don't reuse IDs.
3. Read [STRICT-ASSERTIONS.md](./STRICT-ASSERTIONS.md). No `200|201|202|503` permissive codes.
4. If the journey hits non-deterministic AI, declare an [LLM-AS-JUDGE.md](./LLM-AS-JUDGE.md) rubric.
5. If it writes to the evidence ledger, declare a shadow scope (see [WORM-LEDGER-FIXTURE.md](./WORM-LEDGER-FIXTURE.md)).
6. Add a test row to the matching collection's MD with: id, primitive, mode, sandbox required, blocking gates, assertions.
7. Cross-link the new ID in [PRIMITIVES.md](./PRIMITIVES.md).
8. If the journey requires a primitive that is `PARTIAL` or `ASPIRATIONAL`, mark `blocked_by_missing` and link the GitHub issue.

---

## Closure rule

No GitHub issue may be marked CLOSED unless the latest dated test report under [results/](./results/) contains a row for that issue with FIXED status, gstack screenshot, console transcript, network transcript, and an evidence trace ID. This rule is enforced by the runner.

---

## Don't

- Don't write a test that passes against a 5xx response (see [STRICT-ASSERTIONS.md](./STRICT-ASSERTIONS.md)).
- Don't run more than one mutation journey against the same tenant in parallel (see [SANDBOX-TENANT.md](./SANDBOX-TENANT.md)).
- Don't write evidence to the production WORM ledger from a UAT run (see [WORM-LEDGER-FIXTURE.md](./WORM-LEDGER-FIXTURE.md)).
- Don't grade Zara behavior with exact-string matchers (see [LLM-AS-JUDGE.md](./LLM-AS-JUDGE.md)).
- Don't add a journey for an aspirational primitive without `blocked_by_missing` linkage.
- Don't open a Chrome tab manually; use [tools/cookie-import.sh](./tools/cookie-import.sh) and the gstack browse harness.
