# CLI Scenarios — `ww` end-to-end

The runner exercises the `ww` CLI against the same sandbox tenant as browser tests, ensuring CLI/UI parity (see [PARITY-CONTRACT.md](../PARITY-CONTRACT.md)).

CLI scenario IDs are part of the `C` (contract-parity) prefix. See [contract-parity/C007–C010](../journeys/contract-parity/) for entry points.

---

## Test taxonomy

| ID | Concern | Mode |
| --- | --- | --- |
| C007 | Device-code login | SHADOW, LIVE |
| C008 | Browser PKCE login | SHADOW |
| C009 | Token storage hierarchy | REPLAY (file inspection) |
| C010 | Mode awareness 4 modes | REPLAY |
| C011 | MCP tool surface vs API | REPLAY |
| C012 | `ww evidence trace` parity | SHADOW |
| C013 | Cross-language CLI consistency | REPLAY |

---

## Common runner invocations (smoke)

```bash
# Status check
ww status                    # mode + tenant_id + auth_state

# Mission
ww mission list              # active missions
ww mission show <id>         # detail

# Memory
ww memory recall "query"     # cited results
ww memory remember "fact"    # write

# Evidence
ww evidence trace <id>       # decision trace
ww evidence list --subject <id>  # all events

# Swarm
ww swarm list
ww swarm show <id>
ww swarm cancel <id>

# Skill
ww skill list
ww skill show <id>

# Connector
ww connector list
ww connector connect google
ww connector status google

# Sync
ww sync status               # in hybrid / offline modes
ww sync push                 # explicit push

# ACP
ww acp start                 # JSON-RPC daemon over stdio
```

Each command's exit code, stdout shape, and stderr line are part of the contract test. The runner's `cli/run-cli.sh` exercises these under sandbox.

---

## Failure-mode coverage

The CLI scenarios also exercise:

- Auth refresh mid-command (long-running command spans token refresh)
- Mode flip mid-command (cloud → offline transition)
- Network glitch resilience (transient failure → retry → succeed)
- Permission denial (tenant suspended → 423 with clear message)
- Output formatting (TTY vs pipe; `--format json` vs default text)

---

## Authentication for CLI tests

```bash
# Use sandbox device-code flow against shadow Cognito pool
WW_API_BASE=https://api-shadow.workweaver.ai \
WW_DEVICE_CODE_URL=https://api-shadow.workweaver.ai/api/v1/auth/cli/device/start \
ww login --device-code
```

For LIVE mode, the runner uses the production `WW_API_BASE` against a `is_uat=true` tenant.

---

## Running

```bash
make uat LANE=cli            # all CLI scenarios
make uat LANE=cli JOURNEYS=C007,C012  # specific
```

---

## Related

- [PRIMITIVES.md § 12 CLI authentication + offline](../PRIMITIVES.md#12-cli-authentication--offline)
- [journeys/contract-parity/](../journeys/contract-parity/)
