# UAT Runner — Single-Command Dispatcher

The runner is the engine that resolves selectors, provisions sandboxes, dispatches journeys (parallel where safe), enforces strict assertions, runs silent-failure detectors, grades non-deterministic outputs via LLM judges, captures evidence, and renders the unified report.

```bash
make uat                       # default: REPLAY mode, all collections
make uat MODE=SHADOW           # against shadow infra
make uat MODE=LIVE             # against production-mode tenants tagged uat-live-*
make uat PERSONA=founder       # one persona end-to-end
make uat JOURNEYS=J122,A007    # specific journey IDs
make uat TIERS=0,1,2           # specific tiers
make uat COLLECTIONS=adversarial,edge-sync
make uat-record JOURNEY=Z005   # re-record cassettes
```

---

## Architecture

```
                        +---------------------+
                        |   make uat / /uat   |
                        +----------+----------+
                                   |
                                   v
                       +---------------------------+
                       |   runner/uat-run.sh       |
                       |   (orchestrator entry)    |
                       +-------------+-------------+
                                     |
                +--------------------+--------------------+
                |                                         |
                v                                         v
   +-----------------------+              +---------------------------+
   | runner/preflight.py   |              | runner/registry.py        |
   | - env check           |              | - read journeys MD index  |
   | - sandbox bootstrap   |              | - resolve selectors       |
   | - cassette validate   |              | - validate field presence |
   +-----------+-----------+              +-------------+-------------+
               |                                        |
               +----------------+-----------------------+
                                |
                                v
              +------------------------------------+
              | runner/parallel-dispatcher.py      |
              | - per-tenant lock + global sema    |
              | - resume from checkpoint           |
              | - heartbeat watchdog               |
              +-----------------+------------------+
                                |
              +-----------------+----------------------+
              v                 v                      v
        +------------+   +-------------+        +-----------+
        | strict_    |   | llm_judge   |        | parity_   |
        | assert.py  |   | .py         |        | check.py  |
        +------+-----+   +------+------+        +-----+-----+
               |                |                     |
               +-------+--------+---------+-----------+
                       |                  |
                       v                  v
              +------------------+   +-------------------+
              | silent_failure_  |   | shadow_ledger.py  |
              | detector.py      |   | + evidence_       |
              +--------+---------+   | collector.py      |
                       |             +---------+---------+
                       +---------+-------------+
                                 v
                    +----------------------------+
                    | runner/report-builder.py   |
                    | - unified summary.json     |
                    | - rendered summary.md      |
                    | - blocker drift gate       |
                    +-------------+--------------+
                                  |
                                  v
                     +-------------------------+
                     | UAT/results/<date>/     |
                     |   <run_id>/             |
                     +-------------------------+
```

---

## Files

| File | Purpose |
| --- | --- |
| [uat-run.sh](./uat-run.sh) | Top-level entry. Parses env, dispatches phases, owns trap-EXIT cleanup. |
| [preflight.py](./preflight.py) | Env + safety checks before run. |
| [registry.py](./registry.py) | Reads journey MDs, validates fields, resolves selectors. |
| [parallel-dispatcher.py](./parallel-dispatcher.py) | Per-tenant lock + global semaphore + heartbeat resume. |
| [sandbox_tenant.py](./sandbox_tenant.py) | Provision/teardown of UAT sandbox tenants. |
| [shadow_ledger.py](./shadow_ledger.py) | Routes evidence writes to in-mem / shadow bucket / production-uat. |
| [replay_mode.py](./replay_mode.py) | Cassette match/record, redaction. |
| [llm_judge.py](./llm_judge.py) | Pinned-model judge with rubric. |
| [strict_assert.py](./strict_assert.py) | Per-journey strict assertions. |
| [silent_failure_detector.py](./silent_failure_detector.py) | Composite detector. |
| [parity_check.py](./parity_check.py) | Schema-driven UI/CLI/MCP/API parity. |
| [fault_injection.py](./fault_injection.py) | Injects faults for adversarial journeys. |
| [evidence_collector.py](./evidence_collector.py) | Aggregates per-journey artifacts. |
| [report_builder.py](./report_builder.py) | Renders unified report (md + json). |
| [capability_schema.py](./capability_schema.py) | Source of truth for parity contract. |
| [drift_gate.py](./drift_gate.py) | Runner-specific drift checks (legacy permissive assertion sweep, future primitive-coverage hooks). |
| [cassettes/](./cassettes/) | REPLAY tape directory (gitignored except README). |

---

## Phases (per run)

```
1. preflight     — env check, sandbox bootstrap, cassette validate
2. registry      — read journeys MD, resolve selectors, validate
3. dispatch      — parallel execution per per-tenant lock + global sema
4. assertions    — strict + silent-failure + parity per journey
5. judging       — LLM judge for non-deterministic outputs
6. evidence      — collect artifacts per journey
7. drift gate    — runner-level + skill-level drift checks
8. report build  — unified md + json
9. teardown      — purge shadow ledger, suspend sandbox tenants
```

---

## Determinism

A run with the same `WW_UAT_RUN_ID` + same code commit + same cassettes produces identical output. Achieved by:

- Pinned LLM judge model + temp 0
- Cassette-based replay for connectors / LLM
- Stable seed for any random fixtures
- Wall-clock mocked in REPLAY
- Idempotent setup + teardown
- No reliance on third-party rate limits in REPLAY

CI runs every UAT twice in REPLAY and fails on diverged output.

---

## Resumability

Runs interrupted mid-execution resume via:

- `state.json` checkpoint after each journey
- `journal.md` running log
- Heartbeat: per-worker process; lock auto-expires after 30 min if no heartbeat
- `make uat-resume RUN_ID=<id>` re-enters at last checkpoint

---

## Modes summary

| Mode | Sandbox | Cassettes | Judge | Use |
| --- | --- | --- | --- | --- |
| REPLAY | in-memory | replay-only | tape-replayed | every PR |
| SHADOW | shadow tenant + shadow bucket | replay or live | live-cached | pre-merge |
| LIVE | production tenant tagged uat-live | bypassed | live | nightly + pre-deploy |

---

## Related

- [PHILOSOPHY.md](../PHILOSOPHY.md) — six structural principles
- [SANDBOX-TENANT.md](../SANDBOX-TENANT.md)
- [WORM-LEDGER-FIXTURE.md](../WORM-LEDGER-FIXTURE.md)
- [REPLAY-MODE.md](../REPLAY-MODE.md)
- [LLM-AS-JUDGE.md](../LLM-AS-JUDGE.md)
- [STRICT-ASSERTIONS.md](../STRICT-ASSERTIONS.md)
- [SILENT-FAILURE-DETECTOR.md](../SILENT-FAILURE-DETECTOR.md)
- [PARITY-CONTRACT.md](../PARITY-CONTRACT.md)
