# Chrome Tests (T01–T99) — gstack browse harness

Executable browser tests via the gstack harness. The runner invokes these via `lib/browse-helpers.sh`.

Migrated from `.claude/uat/UAT-CHROME-TESTS.md` with strict-assertion upgrades. T04–T24 outlines moved to [ROADMAP.md](../ROADMAP.md) until they get full executable scripts.

---

## Harness primer

```bash
# Browse binary path (canonical)
B="$HOME/.claude/skills/gstack/browse/dist/browse"

# Authenticate (cookie import)
$B goto https://workweaver.ai
$B cookie-import-browser chrome --domain .workweaver.ai

# Common operations
$B goto <url>
$B text                    # current page text
$B console --errors        # error list
$B js "<expression>"       # evaluate JS in page
$B screenshot <path>       # full-page screenshot
$B click "<selector>"
$B fill "<selector>" "<value>"
$B network                 # request log
```

The harness IS hardwired. **Never** open a headed Chrome tab. **Never** decrypt cookie DB manually. **Never** use Playwright/Puppeteer directly.

---

## Evidence convention

Every test writes to `UAT/results/<date>/<run_id>/T<NN>/` with:

- `screenshot.png`
- `console.txt`
- `network.txt`
- `text.txt` (page text)
- `evidence.json` (assertions passed/failed + trace IDs)

---

## Tests

### T01 — auth-signup-google-happy-path

Sign up via Google OAuth. Reach Mission Control. (Existing test, fully scripted in `.claude/uat/UAT-CHROME-TESTS.md`. Migrate verbatim with strict-assertion upgrades.)

### T02 — auth-signup-email-verify-mfa

Email signup + verification + optional MFA.

### T03 — auth-pwreset-replay-denied

Initiate password reset; capture link; replay; assert denied.

### T04–T06 — landing flow tests

Landing CTA, pricing, signup tile UX.

### T07 — connector-gmail-oauth-end-to-end

Gmail OAuth happy-path. Connector becomes `connected`. Sandbox Gmail account.

### T08 — connector-microsoft365-oauth

Microsoft 365 OAuth.

### T09 — connector-slack-oauth + post-message

Slack OAuth + post a message. Verify message appears in sandbox channel.

### T10 — outreach-campaign-create-and-pre-send-guard

Create cold-outreach campaign. Verify PreSendGuard order. (See [tier8/J81](../journeys/tier8-outreach/README.md#j81--campaign-create-with-presendguard-order-partial).)

### T10b — outreach-campaign-evidence-join

Verify evidence/billing/CRM/memory join after campaign.

### T11 — billing-tenant-create

Tenant creation triggers Stripe customer creation.

### T12 — tenant-suspend-restore (admin)

Admin suspends tenant; tenant API returns 423; restore reactivates.

### T13 — multi-tenant-isolation

Two tenants in different orgs. Verify zero data leak. (See [multi-tenant/M003](../journeys/multi-tenant/README.md#m003--cross-org-denial-writeread-attempt-codexs-j114).)

### T14 — billing-stripe-webhook-end-to-end

Stripe webhook → tenant provision → billing surface reflects.

### T15 — self-host-smoke

Self-host install + bootstrap probe. (See [SELFHOST.md](../SELFHOST.md).)

### T16–T24 — roadmap (moved from prose-only)

T16-T24 in legacy were prose-only outlines. They're now in [ROADMAP.md § Test infrastructure roadmap](../ROADMAP.md) until they get fully executable scripts. Each gets its own GitHub issue:

- T16 — voice provider failover #VOICE-FAILOVER-001
- T17 — meeting AI bot join sandbox #MEETING-001
- T18 — connector re-auth CTA #GAP-023
- T19 — admin impersonation V2 (ASPIRATIONAL)
- T20 — broadcast V2 (ASPIRATIONAL)
- T21 — payment refund flow #REFUND-001
- T22 — onboarding keystroke baseline #GAP-021
- T23 — wallet preflight (crypto) #CRYPTO-PREFLIGHT-001
- T24 — privacy erasure (RTBF) #ERASURE-001

---

## Migration note

T01–T03 are fully scripted in `.claude/uat/UAT-CHROME-TESTS.md`. The runner invokes them by sourcing the legacy file during the migration window. Once the runner has its own per-test scripts under `chrome/T01.sh` etc., the legacy reference can be removed.

Tracked in #FOLD-LEGACY-PROSE-T04-T24-001.
