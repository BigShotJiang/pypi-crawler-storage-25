# sebench

A Python framework for hierarchical, multi-fidelity system simulation with a hardware-in-the-loop seam.

Build abstract models of complex systems, drill down into concrete implementations, swap in real hardware without touching the rest, and get deterministic replay, trace analysis, and requirement verification along the way.

## Install

```bash
pip install sebench
```

The 3D-printer demo (`printerlab`) lives in this repo as a reference implementation. It is not published to PyPI.

## Quickstart

```bash
git clone https://github.com/<you>/sebench.git
cd sebench
make setup              # uv sync + pre-commit install
make demo-pyramid       # simulate printing a 20 mm pyramid (~10 s wall-clock)
make report-server      # open http://localhost:8765 to view the report
```

## Development workflow

### Daily work

```bash
git add <files>
git commit -m "your message"   # pre-commit runs: ruff fix, format, whitespace
git push                       # pre-push hook runs: lint + typecheck + unit tests
```

If pre-commit fixes files, re-add them and commit again:
```bash
git add <files>
git commit -m "your message"
```

### What CI does automatically (no action needed)

On every push to `main` or pull request:
- Ruff lint + format check
- Mypy type check
- Determinism lint
- Full test matrix (Python 3.11 / 3.12 / 3.13 on Ubuntu, macOS, Windows)
- Coverage report (must be ≥ 80%)
- Uploads `coverage.xml` and `test-results.xml` as artifacts

### Releasing to PyPI

1. Go to **Actions → Release sebench to PyPI → Run workflow**
2. Enter the version number (e.g. `0.2.0`)
3. Click **Run workflow** — everything else is automatic

The workflow will: bump `pyproject.toml`, commit + tag on `main`, run the full test suite, build the wheel, publish to PyPI, and create a GitHub Release with the build artifacts.

> **Prerequisite:** configure PyPI Trusted Publishing for this repo at pypi.org (Settings → Publishing).

## Docs

- **[User guide](docs/user-guide.md)** — run the demo, read the report, build a custom component
- [Vision](specs/00-vision.md) — what this is and why
- [Architecture](specs/02-architecture.md) — layered view
- [Visualization & reports](specs/08-visualization-and-reports.md) — UI reference
- [Roadmap](specs/11-roadmap.md) — milestones
- [ADRs](specs/adr/) — architectural decision records

## License

MIT. See [LICENSE](LICENSE).
