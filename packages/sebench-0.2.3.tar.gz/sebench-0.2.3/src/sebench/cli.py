"""sebench CLI — primary entry point for launching and inspecting runs."""

from __future__ import annotations

import json
from pathlib import Path

import typer
from rich.console import Console
from rich.progress import BarColumn, Progress, TextColumn, TimeElapsedColumn, TimeRemainingColumn
from rich.table import Table

app = typer.Typer(
    name="sebench",
    help="Hierarchical multi-fidelity simulation framework.",
    no_args_is_help=True,
)
console = Console()

# --- run -------------------------------------------------------------------


@app.command()
def run(
    experiment: Path = typer.Argument(..., help="Path to the experiment: YAML file"),
    system: Path = typer.Option(
        None,
        "--system",
        "-s",
        help="Path to the system: YAML. Inferred from experiment if omitted.",
    ),
    runs_dir: Path = typer.Option(Path("runs"), "--runs-dir", help="Output directory"),
) -> None:
    """Run an experiment and write artifacts to runs/<run_id>/."""
    from sebench.experiment import Runner, load_experiment

    exp_cfg = load_experiment(experiment)

    if system is None:
        # Try same directory as experiment, with the system name
        sys_path = experiment.parent.parent / "systems" / f"{exp_cfg.system}.yaml"
        if not sys_path.exists():
            sys_path = experiment.parent / f"{exp_cfg.system}.yaml"
    else:
        sys_path = system

    if not sys_path.exists():
        console.print(f"[red]System file not found:[/red] {sys_path}")
        raise typer.Exit(1)

    console.print(
        f"[bold]Running[/bold] experiment [cyan]{exp_cfg.name}[/cyan] "
        f"on system [cyan]{exp_cfg.system}[/cyan] (seed={exp_cfg.seed})"
    )

    runner = Runner(
        experiment_path=experiment,
        system_path=sys_path,
        runs_dir=runs_dir,
    )
    with Progress(
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TextColumn("{task.percentage:>5.1f}%"),
        TimeElapsedColumn(),
        TimeRemainingColumn(),
        console=console,
    ) as progress:
        task = progress.add_task("Simulating", total=exp_cfg.duration_s)

        def on_progress(t_s: float, duration_s: float) -> None:
            progress.update(task, total=duration_s, completed=t_s)

        run_id, run_dir = runner.run(progress_callback=on_progress)
    console.print(f"[green]✓[/green] Run complete: [bold]{run_id}[/bold]")
    console.print(f"  Artifacts: {run_dir}")


# --- replay ----------------------------------------------------------------


@app.command()
def replay(
    run_dir: Path = typer.Argument(..., help="Path to a run directory"),
    at: float = typer.Option(None, "--at", help="Jump to a specific simulation time"),
) -> None:
    """Open the run report in the browser (trace-level replay)."""
    meta_path = run_dir / "metadata.json"
    if not meta_path.exists():
        console.print(f"[red]Not a valid run directory:[/red] {run_dir}")
        raise typer.Exit(1)
    meta = json.loads(meta_path.read_text())
    console.print(f"Run: [bold]{meta.get('run_id', '?')}[/bold]")
    console.print(f"  System:   {meta.get('system_name')}")
    console.print(f"  Duration: {meta.get('simulated_duration_s')}s")
    console.print(f"  HIL:      {meta.get('hil_flag', False)}")
    console.print("\nOpen the report server to browse: [cyan]make report-server[/cyan]")


# --- reqs ------------------------------------------------------------------

reqs_app = typer.Typer(
    name="reqs", help="Inspect requirements for a system or run.", no_args_is_help=True
)
app.add_typer(reqs_app)


@reqs_app.command("list")
def reqs_list(
    run_dir: Path = typer.Argument(..., help="Path to a run directory"),
) -> None:
    """List requirement results for a completed run."""
    from sebench.trace import open_trace

    trace = open_trace(run_dir)
    df = trace.requirement_results()
    trace.close()

    if df.empty:
        console.print("[yellow]No requirement results found.[/yellow]")
        return

    table = Table(title=f"Requirements — {run_dir.name}")
    table.add_column("ID")
    table.add_column("Status")
    table.add_column("Severity")
    table.add_column("Origin")
    table.add_column("Summary")

    for _, row in df.iterrows():
        status = str(row["status"])
        color = {
            "pass": "green",
            "fail": "red",
            "waived": "yellow",
            "expired_waiver": "orange3",
        }.get(status, "white")
        table.add_row(
            row["req_instance_id"],
            f"[{color}]{status}[/{color}]",
            row["severity"],
            row["origin"],
            row["summary"],
        )
    console.print(table)


@reqs_app.command("export")
def reqs_export(
    run_dir: Path = typer.Argument(..., help="Path to a run directory"),
    format: str = typer.Option("json", "--format", "-f", help="Output format: json, csv, md"),
    out: Path = typer.Option(None, "--out", "-o", help="Output file (stdout if omitted)"),
) -> None:
    """Export requirement results from a run."""
    from sebench.trace import open_trace

    trace = open_trace(run_dir)
    df = trace.requirement_results()
    trace.close()

    if format == "json":
        content = df.to_json(orient="records", indent=2)
    elif format == "csv":
        content = df.to_csv(index=False)
    elif format == "md":
        content = df.to_markdown(index=False)
    else:
        console.print(f"[red]Unknown format:[/red] {format}")
        raise typer.Exit(1)

    if out:
        out.write_text(content or "")
        console.print(f"[green]✓[/green] Written to {out}")
    else:
        console.print(content)


# --- trace -----------------------------------------------------------------

trace_app = typer.Typer(name="trace", help="Inspect and export trace data.", no_args_is_help=True)
app.add_typer(trace_app)


@trace_app.command("export")
def trace_export(
    run_dir: Path = typer.Argument(..., help="Path to a run directory"),
    format: str = typer.Option("parquet", "--format", "-f", help="parquet or csv"),
    out: Path = typer.Option(Path("out"), "--out", "-o", help="Output directory"),
) -> None:
    """Export trace tables to Parquet or CSV."""
    from sebench.trace import open_trace

    trace = open_trace(run_dir)
    out.mkdir(parents=True, exist_ok=True)

    for table in ("samples", "events", "inputs", "requirement_results", "meta"):
        df = trace.conn.execute(f"SELECT * FROM {table}").df()
        if format == "parquet":
            df.to_parquet(out / f"{table}.parquet", index=False)
        elif format == "csv":
            df.to_csv(out / f"{table}.csv", index=False)

    trace.close()
    console.print(f"[green]✓[/green] Exported to {out}")


# --- report-server ---------------------------------------------------------


@app.command("report-server")
def report_server(
    port: int = typer.Option(8765, "--port", "-p"),
    runs_dir: Path = typer.Option(Path("runs"), "--runs-dir"),
    configs_dir: Path = typer.Option(
        None,
        "--configs-dir",
        "-c",
        help="Root directory to search for system YAML files. Enables the Systems view.",
    ),
    reload: bool = typer.Option(True, "--reload/--no-reload"),
) -> None:
    """Launch the FastAPI reports server."""
    import os

    import uvicorn

    os.environ.setdefault("SEBENCH_RUNS_DIR", str(runs_dir))
    if configs_dir is not None:
        os.environ["SEBENCH_CONFIGS_DIR"] = str(configs_dir)
    uvicorn.run(
        "sebench.reports.app:app",
        host="localhost",
        port=port,
        reload=reload,
    )


if __name__ == "__main__":
    app()
