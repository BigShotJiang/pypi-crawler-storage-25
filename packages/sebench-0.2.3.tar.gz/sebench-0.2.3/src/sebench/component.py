"""Core Component protocol and related data types."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Protocol, runtime_checkable


@dataclass(frozen=True)
class Event:
    """A discrete event emitted by a component during a step."""

    kind: str
    at_s: float | None = None  # None = "now" (current logical time)
    payload: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class StepResult:
    """Return type of Component.step()."""

    outputs: dict[str, Any]
    events: list[Event] = field(default_factory=list)
    # Each entry: (filename, data_bytes, mime_type).  Runner writes to run_dir/artifacts/.
    artifacts: list[tuple[str, bytes, str]] = field(default_factory=list)


@runtime_checkable
class Component(Protocol):
    """The single contract every modeling unit implements.

    Leaf components, composites, connectors, and HAL drivers all satisfy
    this protocol. The kernel knows only this.
    """

    name: str

    def declare(self) -> ComponentSpec:
        """Return ports, params schema, and declared requirements.

        Pure: must not mutate state, must be callable before reset().
        """
        ...

    def reset(self, seed: int) -> None:
        """Put the component into a well-defined initial state.

        ``seed`` is the deterministic seed derived for this instance.
        """
        ...

    def step(self, dt: float, inputs: dict[str, Any]) -> StepResult:
        """Advance this component by ``dt`` seconds of logical time."""
        ...

    def snapshot(self) -> bytes:
        """Serialize complete state for checkpoint."""
        ...

    def restore(self, state: bytes) -> None:
        """Restore state produced by snapshot()."""
        ...


# Import here to avoid circular dependency; spec needs Component in type hints.
from sebench.spec import ComponentSpec  # noqa: E402
