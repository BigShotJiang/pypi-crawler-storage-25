"""ComponentSpec: what a component declares about itself without instantiation."""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import TYPE_CHECKING, Literal

from pydantic import BaseModel

from sebench.ports import Port

if TYPE_CHECKING:
    from sebench.requirements import Requirement

Fidelity = Literal["abstract", "detailed", "hil"]


class _EmptyParams(BaseModel):
    """Default params schema for components that declare no params."""


@dataclass(frozen=True)
class ComponentSpec:
    """Static declaration of a component's interface and requirements."""

    name: str
    ports_in: dict[str, Port] = field(default_factory=dict)
    ports_out: dict[str, Port] = field(default_factory=dict)
    params_schema: type[BaseModel] = _EmptyParams
    requirements: list[Requirement] = field(default_factory=list)
    fidelity: Fidelity = "abstract"
    description: str = ""
