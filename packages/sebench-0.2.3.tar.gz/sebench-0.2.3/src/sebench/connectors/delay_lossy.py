"""Delay-and-loss connector.

Introduces propagation delay, optional jitter, and a configurable drop rate.
Values in transit are buffered; a dropped packet silently becomes None.
"""

from __future__ import annotations

import pickle
import random
from collections import deque
from typing import Any

from pydantic import BaseModel, Field

from sebench.component import StepResult
from sebench.ports import Port
from sebench.spec import ComponentSpec


class DelayLossyParams(BaseModel):
    delay_s: float = 0.0
    drop_rate: float = Field(0.0, ge=0.0, le=1.0)
    jitter_s: float = 0.0


class DelayLossyConnector:
    """Connector that introduces delay, jitter, and optional packet loss."""

    inputs: dict[str, Port] = {"value": Port(Any, "Input signal")}
    outputs: dict[str, Port] = {"value": Port(Any, "Delayed / possibly dropped signal")}
    params_schema = DelayLossyParams
    fidelity = "abstract"
    requirements: list[Any] = []

    def __init__(self, name: str, params: DelayLossyParams | None = None) -> None:
        self.name = name
        self.p = params or DelayLossyParams()  # type: ignore[call-arg]
        # buffer: list of (release_t, value)
        self._buffer: deque[tuple[float, Any]] = deque()
        self._t: float = 0.0
        self._rng: random.Random = random.Random()

    def declare(self) -> ComponentSpec:
        return ComponentSpec(
            name=self.name,
            ports_in=self.inputs,
            ports_out=self.outputs,
            params_schema=DelayLossyParams,
            fidelity="abstract",
            description="Connector with configurable delay, jitter, and loss rate.",
        )

    def reset(self, seed: int) -> None:
        self._buffer.clear()
        self._t = 0.0
        self._rng = random.Random(seed)

    def step(self, dt: float, inputs: dict[str, Any]) -> StepResult:
        self._t += dt
        val = inputs.get("value")

        # Possibly drop the incoming value
        if val is not None and self.p.drop_rate > 0.0 and self._rng.random() < self.p.drop_rate:
            val = None  # dropped

        # Enqueue (if not dropped) with a delayed release time
        if val is not None:
            jitter = self._rng.uniform(-self.p.jitter_s, self.p.jitter_s)
            release_t = self._t + self.p.delay_s + jitter
            self._buffer.append((release_t, val))

        # Dequeue any values whose release time has passed
        output: Any = None
        while self._buffer and self._buffer[0][0] <= self._t:
            _, output = self._buffer.popleft()

        return StepResult(outputs={"value": output})

    def snapshot(self) -> bytes:
        return pickle.dumps(
            {"buffer": list(self._buffer), "t": self._t, "rng": self._rng.getstate()}
        )

    def restore(self, state: bytes) -> None:
        d = pickle.loads(state)
        self._buffer = deque(d["buffer"])
        self._t = d["t"]
        self._rng.setstate(d["rng"])
