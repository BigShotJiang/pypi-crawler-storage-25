"""Disconnectable connector.

Wraps another connector and can inject a disconnection (None output) at
scheduled simulation times. Reconnection is also schedulable with optional
jitter.
"""

from __future__ import annotations

import pickle
import random
from typing import Any

from pydantic import BaseModel, Field

from sebench.component import Event, StepResult
from sebench.connectors.reliable import ReliableConnector
from sebench.ports import Port
from sebench.spec import ComponentSpec


class DisconnectableParams(BaseModel):
    disconnect_at_s: list[float] = Field(default_factory=list)
    reconnect_at_s: list[float] = Field(default_factory=list)
    reconnect_noise_s: float = 0.0  # ±noise on each reconnection time


class DisconnectableConnector:
    """Connector that can disconnect (drop all traffic) at configured times.

    Events are emitted on disconnect and reconnect.
    """

    inputs: dict[str, Port] = {"value": Port(Any, "Input signal")}
    outputs: dict[str, Port] = {
        "value": Port(Any, "Signal or None when disconnected"),
        "connected": Port(bool, "True when link is up"),
    }
    params_schema = DisconnectableParams
    fidelity = "abstract"
    requirements: list[Any] = []

    def __init__(self, name: str, params: DisconnectableParams | None = None) -> None:
        self.name = name
        self.p = params or DisconnectableParams()
        self._connected = True
        self._t = 0.0
        self._rng: random.Random = random.Random()
        self._inner = ReliableConnector(f"{name}._inner")
        # Build schedule: sorted list of (time, action) pairs
        self._schedule: list[tuple[float, str]] = sorted(
            [(t, "disconnect") for t in self.p.disconnect_at_s]
            + [(t, "reconnect") for t in self.p.reconnect_at_s]
        )
        self._sched_idx = 0

    def declare(self) -> ComponentSpec:
        return ComponentSpec(
            name=self.name,
            ports_in=self.inputs,
            ports_out=self.outputs,
            params_schema=DisconnectableParams,
            fidelity="abstract",
            description="Connector that can be disconnected at configured simulation times.",
        )

    def reset(self, seed: int) -> None:
        self._connected = True
        self._t = 0.0
        self._rng = random.Random(seed)
        self._inner.reset(seed)
        # Rebuild schedule with jitter applied to reconnect times
        sched = [(t, "disconnect") for t in self.p.disconnect_at_s]
        for rt in self.p.reconnect_at_s:
            noise = self._rng.uniform(-self.p.reconnect_noise_s, self.p.reconnect_noise_s)
            sched.append((rt + noise, "reconnect"))
        self._schedule = sorted(sched)
        self._sched_idx = 0

    def step(self, dt: float, inputs: dict[str, Any]) -> StepResult:
        self._t += dt
        events: list[Event] = []

        # Apply any scheduled state changes
        while self._sched_idx < len(self._schedule):
            event_t, action = self._schedule[self._sched_idx]
            if event_t > self._t:
                break
            self._sched_idx += 1
            if action == "disconnect" and self._connected:
                self._connected = False
                events.append(Event(kind="disconnect", payload={"t_s": self._t}))
            elif action == "reconnect" and not self._connected:
                self._connected = True
                events.append(Event(kind="reconnect", payload={"t_s": self._t}))

        if self._connected:
            inner_result = self._inner.step(dt, inputs)
            value = inner_result.outputs.get("value")
        else:
            # Disconnected: pass None but still step inner for determinism
            self._inner.step(dt, {"value": None})
            value = None

        return StepResult(
            outputs={"value": value, "connected": self._connected},
            events=events,
        )

    def snapshot(self) -> bytes:
        return pickle.dumps(
            {
                "connected": self._connected,
                "t": self._t,
                "sched_idx": self._sched_idx,
                "rng": self._rng.getstate(),
                "inner": self._inner.snapshot(),
            }
        )

    def restore(self, state: bytes) -> None:
        d = pickle.loads(state)
        self._connected = d["connected"]
        self._t = d["t"]
        self._sched_idx = d["sched_idx"]
        self._rng.setstate(d["rng"])
        self._inner.restore(d["inner"])
