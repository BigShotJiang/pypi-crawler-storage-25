"""Reliable (pass-through, zero-delay) connector.

Present for symmetry with the other connector types. The value passes
through immediately without modification.
"""

from __future__ import annotations

import pickle
from typing import Any

from pydantic import BaseModel

from sebench.component import StepResult
from sebench.ports import Port
from sebench.spec import ComponentSpec


class ReliableParams(BaseModel):
    pass


class ReliableConnector:
    """Pass-through connector. Zero delay, zero loss."""

    inputs: dict[str, Port] = {"value": Port(Any, "Signal to forward")}
    outputs: dict[str, Port] = {"value": Port(Any, "Forwarded signal")}
    params_schema = ReliableParams
    fidelity = "abstract"
    requirements: list[Any] = []

    def __init__(self, name: str, params: ReliableParams | None = None) -> None:
        self.name = name
        self.p = params or ReliableParams()
        self._last: Any = None

    def declare(self) -> ComponentSpec:
        return ComponentSpec(
            name=self.name,
            ports_in=self.inputs,
            ports_out=self.outputs,
            params_schema=ReliableParams,
            fidelity="abstract",
            description="Pass-through connector: zero delay, zero loss.",
        )

    def reset(self, seed: int) -> None:
        self._last = None

    def step(self, dt: float, inputs: dict[str, Any]) -> StepResult:
        val = inputs.get("value")
        self._last = val
        return StepResult(outputs={"value": val})

    def snapshot(self) -> bytes:
        return pickle.dumps(self._last)

    def restore(self, state: bytes) -> None:
        self._last = pickle.loads(state)
