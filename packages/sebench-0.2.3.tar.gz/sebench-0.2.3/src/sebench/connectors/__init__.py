"""Built-in connector types. All implement the Component protocol."""

from sebench.connectors.delay_lossy import DelayLossyConnector
from sebench.connectors.disconnectable import DisconnectableConnector
from sebench.connectors.reliable import ReliableConnector

__all__ = ["DelayLossyConnector", "DisconnectableConnector", "ReliableConnector"]
