"""FastAPI reports application.

Read-only in v0.1. Serves run artifacts, hierarchy diagrams, and
requirement results. All content is server-rendered HTML via Jinja2.
"""

from __future__ import annotations

import contextlib
import importlib
import inspect
import json
import mimetypes
import os
import re
from pathlib import Path
from typing import Any

import yaml
from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, HTMLResponse, PlainTextResponse
from fastapi.templating import Jinja2Templates

_RUNS_DIR = Path(os.environ.get("SEBENCH_RUNS_DIR", "runs"))
_TEMPLATES_DIR = Path(__file__).parent / "templates"

# macOS maps .obj to application/x-tgif (an ancient CAD format) — override it.
mimetypes.add_type("model/obj", ".obj")

app = FastAPI(title="sebench reports", docs_url=None, redoc_url=None)
templates = Jinja2Templates(directory=str(_TEMPLATES_DIR))


def _runs_dir() -> Path:
    return Path(os.environ.get("SEBENCH_RUNS_DIR", "runs"))


def _configs_dir() -> Path | None:
    v = os.environ.get("SEBENCH_CONFIGS_DIR", "")
    return Path(v) if v else None


def _list_runs() -> list[dict[str, Any]]:
    runs = []
    rd = _runs_dir()
    if not rd.exists():
        return []
    for run_dir in sorted(rd.iterdir(), reverse=True):
        meta_path = run_dir / "metadata.json"
        if meta_path.exists():
            try:
                meta = json.loads(meta_path.read_text())
                runs.append(meta)
            except Exception:
                pass
    return runs


def _list_systems() -> list[dict[str, Any]]:
    """Find system YAML files under SEBENCH_CONFIGS_DIR.

    Excludes experiment files (which also contain a ``system:`` reference key)
    by requiring the absence of an ``experiment:`` top-level key.
    """
    cd = _configs_dir()
    if cd is None or not cd.exists():
        return []
    cd = cd.resolve()
    systems = []
    for yaml_path in sorted(cd.rglob("*.yaml")):
        try:
            data = yaml.safe_load(yaml_path.read_text(encoding="utf-8"))
            if isinstance(data, dict) and "system" in data and "experiment" not in data:
                abs_path = yaml_path.resolve()
                systems.append(
                    {
                        "name": str(data["system"]),
                        "description": str(data.get("description", "")),
                        "path": str(abs_path),
                        "rel_path": str(abs_path.relative_to(cd)),
                    }
                )
        except Exception:
            pass
    return systems


def _load_snapshot(run_dir: Path) -> dict[str, Any]:
    snapshot_path = run_dir / "config.snapshot.yaml"
    if not snapshot_path.exists():
        return {}
    raw = snapshot_path.read_text(encoding="utf-8")
    # Snapshot may be emitted as YAML or JSON-in-YAML; safe_load handles both.
    parsed = yaml.safe_load(raw)
    return parsed if isinstance(parsed, dict) else {}


def _safe_mermaid_id(value: str) -> str:
    cleaned = re.sub(r"[^a-zA-Z0-9_]", "_", value)
    return cleaned or "node"


def _safe_label(value: str) -> str:
    return value.replace('"', "'").replace("\n", " ").strip()


def _mermaid_header(direction: str) -> list[str]:
    return [
        '%%{init: {"theme": "base", "themeVariables": {"fontSize": "14px"}, '
        '"flowchart": {"nodeSpacing": 50, "rankSpacing": 120}}}%%',
        f"graph {direction}",
    ]


def _mermaid_layout_nodes(
    children: dict[str, Any], has_layout: bool
) -> tuple[list[str], dict[int, list[tuple[int, str]]]]:
    from collections import defaultdict

    lines: list[str] = []
    cols: dict[int, list[tuple[int, str]]] = defaultdict(list)

    if has_layout:
        for child_name, child_data in children.items():
            if not isinstance(child_data, dict):
                continue
            view = child_data.get("view") or {}
            cols[int(view.get("col", 0))].append((int(view.get("row", 0)), child_name))
        for col_idx in sorted(cols.keys()):
            lines.append(f'    subgraph col_{col_idx}[" "]')
            lines.append("        direction TB")
            for _, child_name in sorted(cols[col_idx]):
                child_data = children[child_name]
                short_type = str(child_data.get("type", "")).rsplit(".", 1)[-1]
                label = _safe_label(f"{child_name}\\n{short_type}")
                lines.append(f'        {_safe_mermaid_id(child_name)}["{label}"]')
            lines.append("    end")
    else:
        for child_name, child_data in children.items():
            if not isinstance(child_data, dict):
                continue
            short_type = str(child_data.get("type", "")).rsplit(".", 1)[-1]
            label = _safe_label(f"{child_name}\\n{short_type}")
            lines.append(f'    {_safe_mermaid_id(child_name)}["{label}"]')

    return lines, cols


def _mermaid_connector_edges(connectors: Any) -> list[str]:
    lines: list[str] = []
    if not isinstance(connectors, list):
        return lines
    for conn in connectors:
        if not isinstance(conn, dict):
            continue
        from_ = str(conn.get("from_", ""))
        to = str(conn.get("to", ""))
        conn_type = str(conn.get("type", ""))
        if "." not in from_ or "." not in to:
            continue
        src_comp, src_port = from_.rsplit(".", 1)
        dst_comp, dst_port = to.rsplit(".", 1)
        edge_label = _safe_label(f"{src_port} → {dst_port}")
        if "DelayLossy" in conn_type:
            arrow = f'-. "{edge_label}" .->'
        elif "Disconnectable" in conn_type:
            arrow = f'== "{edge_label}" ==>'
        else:
            arrow = f'-- "{edge_label}" -->'
        lines.append(f"    {_safe_mermaid_id(src_comp)} {arrow} {_safe_mermaid_id(dst_comp)}")
    return lines


def _mermaid_styles_and_clicks(
    children: dict[str, Any],
    has_layout: bool,
    cols: dict[int, list[tuple[int, str]]],
) -> list[str]:
    lines: list[str] = []
    for child_name, child_data in children.items():
        if not isinstance(child_data, dict):
            continue
        color = (child_data.get("view") or {}).get("color")
        if color:
            lines.append(
                f"    style {_safe_mermaid_id(child_name)} fill:{color},stroke:#222,color:#fff"
            )
    for child_name in children:
        lines.append(f'    click {_safe_mermaid_id(child_name)} showComponentDetail "{child_name}"')
    if has_layout:
        for col_idx in sorted(cols.keys()):
            lines.append(
                f"    style col_{col_idx} fill:none,stroke:#d0d0d0,stroke-dasharray:4,color:#aaa"
            )
    return lines


def _hierarchy_mermaid(snapshot: dict[str, Any], direction: str = "LR") -> str:
    """Build a Mermaid data-flow graph: components as nodes, connectors as edges.

    When children have ``view.col`` / ``view.row`` hints the diagram uses
    Mermaid subgraphs to enforce column ordering.  Node colors and click
    handlers are added when ``view.color`` is present.

    ``direction`` is passed directly to Mermaid (``LR``, ``TD``, etc.).
    """
    system = snapshot.get("system")
    if not isinstance(system, dict):
        return ""
    children = system.get("children")
    connectors = system.get("connectors")
    if not isinstance(children, dict):
        return ""

    has_layout = any(
        isinstance(cd, dict) and isinstance(cd.get("view"), dict) and "col" in cd["view"]
        for cd in children.values()
    )

    lines = _mermaid_header(direction)
    node_lines, cols = _mermaid_layout_nodes(children, has_layout)
    lines.extend(node_lines)
    lines.extend(_mermaid_connector_edges(connectors))
    lines.extend(_mermaid_styles_and_clicks(children, has_layout, cols))
    return "\n".join(lines)


def _extract_view_data(snapshot: dict[str, Any]) -> dict[str, Any]:
    """Return per-component view metadata and per-artifact color/opacity maps."""
    system = snapshot.get("system", {})
    children = system.get("children", {}) if isinstance(system, dict) else {}
    component_views: dict[str, Any] = {}
    artifact_views: dict[str, Any] = {}
    if not isinstance(children, dict):
        return {"component_views": component_views, "artifact_views": artifact_views}
    for name, child_data in children.items():
        if not isinstance(child_data, dict):
            continue
        view = child_data.get("view") or {}
        component_views[name] = {
            "type": str(child_data.get("type", "")),
            "params": child_data.get("params") or {},
            "rate_hz": child_data.get("rate_hz"),
            "color": view.get("color", "#888888"),
            "opacity": float(view.get("opacity", 0.82)),
            "artifact": view.get("artifact"),
        }
        artifact = view.get("artifact")
        if artifact:
            artifact_views[artifact] = {
                "color": view.get("color", "#888888"),
                "opacity": float(view.get("opacity", 0.82)),
            }
    return {"component_views": component_views, "artifact_views": artifact_views}


def _load_component_specs(snapshot: dict[str, Any]) -> dict[str, Any]:
    """Instantiate each component from snapshot and call declare() for full spec.

    Returns a dict keyed by component name with description, fidelity, ports,
    requirements, and source file path. Failures are silently omitted per component.
    """
    from sebench.experiment.loader import ChildConfig, _instantiate_component

    system = snapshot.get("system", {})
    children = system.get("children", {}) if isinstance(system, dict) else {}
    specs: dict[str, Any] = {}

    for name, child_data in children.items():
        if not isinstance(child_data, dict):
            continue
        type_str = str(child_data.get("type", ""))
        params = child_data.get("params") or {}
        if not type_str:
            continue
        try:
            cfg = ChildConfig(type=type_str, params=params)
            comp = _instantiate_component(name, cfg)
            spec = comp.declare()

            # Resolve source file via inspect
            module_path, class_name = type_str.rsplit(".", 1)
            module = importlib.import_module(module_path)
            cls = getattr(module, class_name)
            source_file: str | None = None
            with contextlib.suppress(TypeError, OSError):
                source_file = inspect.getfile(cls)

            specs[name] = {
                "description": spec.description,
                "fidelity": spec.fidelity,
                "ports_in": {
                    k: {
                        "dtype": p.dtype.__name__,
                        "description": p.description,
                        "unit": p.unit or "",
                    }
                    for k, p in spec.ports_in.items()
                },
                "ports_out": {
                    k: {
                        "dtype": p.dtype.__name__,
                        "description": p.description,
                        "unit": p.unit or "",
                    }
                    for k, p in spec.ports_out.items()
                },
                "requirements": [
                    {
                        "id": r.id,
                        "description": r.description,
                        "severity": r.severity,
                    }
                    for r in spec.requirements
                ],
                "source_file": source_file,
            }
        except Exception:
            specs[name] = {}

    return specs


def _system_cfg_to_snapshot(sys_cfg: Any) -> dict[str, Any]:
    """Convert a SystemConfig to the snapshot dict shape expected by _hierarchy_mermaid."""
    children: dict[str, Any] = {}
    for name, child in sys_cfg.children.items():
        child_dict: dict[str, Any] = {
            "type": child.type,
            "params": child.params,
            "rate_hz": child.rate_hz,
        }
        # view and other extra YAML fields land in model_extra (extra="allow")
        if hasattr(child, "model_extra") and child.model_extra:
            child_dict.update(child.model_extra)
        children[name] = child_dict

    connectors = [
        {"from_": c.from_, "to": c.to, "type": c.type, "params": c.params}
        for c in sys_cfg.connectors
    ]

    return {
        "system": {
            "name": sys_cfg.name,
            "description": sys_cfg.description,
            "children": children,
            "connectors": connectors,
        }
    }


@app.get("/", response_class=HTMLResponse)
async def dashboard(request: Request) -> HTMLResponse:
    runs = _list_runs()
    systems = _list_systems()
    return templates.TemplateResponse(
        request,
        "dashboard.html",
        {"runs": runs, "systems": systems, "title": "sebench — dashboard"},
    )


@app.get("/runs/", response_class=HTMLResponse)
async def list_runs(request: Request) -> HTMLResponse:
    runs = _list_runs()
    return templates.TemplateResponse(
        request, "runs_list.html", {"runs": runs, "title": "All runs"}
    )


@app.get("/runs/{run_id}", response_class=HTMLResponse)
async def run_detail(request: Request, run_id: str) -> HTMLResponse:
    run_dir = _runs_dir() / run_id
    meta_path = run_dir / "metadata.json"
    if not meta_path.exists():
        raise HTTPException(status_code=404, detail=f"Run {run_id!r} not found")
    meta = json.loads(meta_path.read_text())
    snapshot = _load_snapshot(run_dir)
    hierarchy_mmd = _hierarchy_mermaid(snapshot)
    view_data = _extract_view_data(snapshot)
    component_specs = _load_component_specs(snapshot)

    # Load requirement results if available
    reqs: list[dict[str, Any]] = []
    try:
        from sebench.trace import open_trace

        trace = open_trace(run_dir)
        df = trace.requirement_results()
        trace.close()
        reqs = df.to_dict(orient="records")
    except Exception:
        pass

    return templates.TemplateResponse(
        request,
        "run_detail.html",
        {
            "meta": meta,
            "reqs": reqs,
            "run_id": run_id,
            "title": f"Run — {run_id}",
            "hierarchy_mmd": hierarchy_mmd,
            "component_views": view_data["component_views"],
            "artifact_views": view_data["artifact_views"],
            "component_specs": component_specs,
        },
    )


@app.get("/runs/{run_id}/report.html", response_class=HTMLResponse)
async def run_report(request: Request, run_id: str) -> HTMLResponse:
    run_dir = _runs_dir() / run_id
    report_path = run_dir / "report.html"
    if report_path.exists():
        return HTMLResponse(content=report_path.read_text())
    # Fall through to live render
    return await run_detail(request, run_id)


@app.get("/runs/{run_id}/signals")
async def run_signals(run_id: str) -> list[str]:
    """Return sorted list of 'component.port' strings recorded in the trace."""
    run_dir = _runs_dir() / run_id
    db = run_dir / "trace.duckdb"
    if not db.exists():
        raise HTTPException(status_code=404, detail=f"Trace not found for run {run_id!r}")
    try:
        import duckdb

        con = duckdb.connect(str(db), read_only=True)
        rows = con.execute(
            "SELECT DISTINCT component, port FROM samples ORDER BY component, port"
        ).fetchall()
        con.close()
        return [f"{comp}.{port}" for comp, port in rows]
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get("/runs/{run_id}/signal/{component}/{port}")
async def run_signal(run_id: str, component: str, port: str) -> list[list[float]]:
    """Return [[t_s, value], ...] for a numeric signal.

    Values are read from value_float, value_int, or value_bool columns in order.
    Non-numeric ports return an empty list.
    """
    run_dir = _runs_dir() / run_id
    db = run_dir / "trace.duckdb"
    if not db.exists():
        raise HTTPException(status_code=404, detail=f"Trace not found for run {run_id!r}")
    try:
        import duckdb

        con = duckdb.connect(str(db), read_only=True)
        rows = con.execute(
            """
            SELECT t_s,
                   COALESCE(value_float,
                            CAST(value_int AS DOUBLE),
                            CAST(value_bool AS DOUBLE)) AS v
            FROM samples
            WHERE component = ? AND port = ?
              AND (value_float IS NOT NULL
                   OR value_int IS NOT NULL
                   OR value_bool IS NOT NULL)
            ORDER BY t_s
            """,
            [component, port],
        ).fetchall()
        con.close()
        return [[t, v] for t, v in rows if v is not None]
    except Exception as exc:
        raise HTTPException(status_code=500, detail=str(exc)) from exc


@app.get("/runs/{run_id}/hierarchy.mmd", response_class=PlainTextResponse)
async def run_hierarchy(run_id: str) -> PlainTextResponse:
    run_dir = _runs_dir() / run_id
    if not run_dir.exists():
        raise HTTPException(status_code=404, detail=f"Run {run_id!r} not found")
    hierarchy = _hierarchy_mermaid(_load_snapshot(run_dir))
    if not hierarchy:
        raise HTTPException(status_code=404, detail=f"Hierarchy not available for run {run_id!r}")
    return PlainTextResponse(content=hierarchy)


@app.get("/runs/{run_id}/artifacts/")
async def list_artifacts(run_id: str) -> list[dict[str, Any]]:
    """Return [{name, size, mime_type}] for every file in run_dir/artifacts/."""
    run_dir = _runs_dir() / run_id
    artifacts_dir = run_dir / "artifacts"
    if not artifacts_dir.exists():
        return []
    result = []
    for f in sorted(artifacts_dir.iterdir()):
        if f.is_file():
            mime, _ = mimetypes.guess_type(f.name)
            result.append(
                {
                    "name": f.name,
                    "size": f.stat().st_size,
                    "mime_type": mime or "application/octet-stream",
                }
            )
    return result


@app.get("/runs/{run_id}/artifacts/{filename}")
async def get_artifact(run_id: str, filename: str) -> FileResponse:
    """Serve a single artifact file with the correct Content-Type."""
    artifacts_dir = (_runs_dir() / run_id / "artifacts").resolve()
    artifact_path = (artifacts_dir / filename).resolve()
    # Prevent path traversal
    if not str(artifact_path).startswith(str(artifacts_dir)):
        raise HTTPException(status_code=400, detail="Invalid filename")
    if not artifact_path.is_file():
        raise HTTPException(status_code=404, detail=f"Artifact {filename!r} not found")
    mime, _ = mimetypes.guess_type(filename)
    return FileResponse(str(artifact_path), media_type=mime or "application/octet-stream")


@app.get("/systems/", response_class=HTMLResponse)
async def list_systems_page(request: Request) -> HTMLResponse:
    systems = _list_systems()
    return templates.TemplateResponse(
        request,
        "systems_list.html",
        {"systems": systems, "title": "Systems"},
    )


@app.get("/system", response_class=HTMLResponse)
async def system_detail_page(request: Request, path: str) -> HTMLResponse:
    """Show a system detail page — hierarchy, component specs, system requirements."""
    from sebench.experiment.loader import load_system

    yaml_path = Path(path).resolve()
    if not yaml_path.exists():
        raise HTTPException(status_code=404, detail=f"System file not found: {path!r}")

    try:
        sys_cfg = load_system(yaml_path)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f"Failed to load system: {exc}") from exc

    snapshot = _system_cfg_to_snapshot(sys_cfg)
    hierarchy_mmd = _hierarchy_mermaid(snapshot, direction="TD")
    view_data = _extract_view_data(snapshot)
    component_specs = _load_component_specs(snapshot)

    # Serialize system requirements for the template
    sys_reqs = [
        {"id": r.id, "description": r.description, "severity": r.severity}
        for r in sys_cfg.system_requirements
    ]

    return templates.TemplateResponse(
        request,
        "system_detail.html",
        {
            "sys_name": sys_cfg.name,
            "sys_description": sys_cfg.description,
            "sys_reqs": sys_reqs,
            "yaml_path": str(yaml_path),
            "title": f"System — {sys_cfg.name}",
            "hierarchy_mmd": hierarchy_mmd,
            "component_views": view_data["component_views"],
            "component_specs": component_specs,
        },
    )


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok", "version": "0.1.0"}
