"""FastAPI-based read-only reports UI."""
