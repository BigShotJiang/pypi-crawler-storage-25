"""Requirement declaration, collection, overrides, and evaluation."""

from __future__ import annotations

import json
from collections.abc import Callable
from dataclasses import dataclass, field
from datetime import date
from typing import TYPE_CHECKING, Any, Literal

from pydantic import BaseModel, field_validator

if TYPE_CHECKING:
    from sebench.trace.reader import TraceView

Severity = Literal["critical", "major", "minor"]
Status = Literal["pass", "fail", "waived", "expired_waiver", "active"]
OverrideAction = Literal["waive", "tighten", "loosen", "replace"]

CheckFn = Callable[["TraceView"], "AssertionResult"]


@dataclass(frozen=True)
class Violation:
    """A single time window where a requirement predicate failed."""

    t_start_s: float
    t_end_s: float
    message: str
    context: dict[str, Any] = field(default_factory=dict)


@dataclass(frozen=True)
class AssertionResult:
    """Result returned by a requirement's check function."""

    passed: bool
    violations: list[Violation] = field(default_factory=list)

    @classmethod
    def ok(cls) -> AssertionResult:
        return cls(passed=True)

    @classmethod
    def fail(cls, violations: list[Violation]) -> AssertionResult:
        return cls(passed=False, violations=violations)


class Requirement(BaseModel):
    """A named, testable claim about a component or system."""

    id: str
    description: str
    severity: Severity = "major"
    check: Any  # CheckFn — not typed here to allow YAML inline strings


class RequirementOverride(BaseModel):
    """A per-instance override applied in a system YAML."""

    action: OverrideAction
    reason: str
    expires: str  # ISO date string or "never"
    approved_by: str = ""
    check: Any = None  # Required for tighten / loosen / replace

    @field_validator("reason")
    @classmethod
    def reason_nonempty(cls, v: str) -> str:
        if not v.strip():
            raise ValueError("reason must not be empty")
        return v

    @property
    def is_expired(self) -> bool:
        if self.expires == "never":
            return False
        return date.fromisoformat(self.expires) < date.today()


@dataclass
class InstantiatedRequirement:
    """A requirement bound to a specific component instance in a system."""

    instance_id: str
    source_req: Requirement
    origin: Literal["component", "system"]
    component_path: str = ""
    component_class: str = ""
    override: RequirementOverride | None = None
    eval_result: AssertionResult | None = None

    @property
    def effective_check(self) -> Any:
        if self.override and self.override.action in ("tighten", "loosen", "replace"):
            return self.override.check
        return self.source_req.check

    @property
    def is_waived(self) -> bool:
        return self.override is not None and self.override.action == "waive"

    @property
    def status(self) -> Status:
        if self.eval_result is None:
            return "active"
        if self.is_waived:
            if self.override and self.override.is_expired:
                return "expired_waiver"
            return "waived"
        return "pass" if self.eval_result.passed else "fail"

    def apply_override(self, override: RequirementOverride) -> InstantiatedRequirement:
        return InstantiatedRequirement(
            instance_id=self.instance_id,
            source_req=self.source_req,
            origin=self.origin,
            component_path=self.component_path,
            component_class=self.component_class,
            override=override,
        )


@dataclass
class RequirementsSet:
    """All requirements collected for a system, ready for evaluation."""

    system: str
    items: dict[str, InstantiatedRequirement] = field(default_factory=dict)

    def to_json(self) -> str:
        return json.dumps(
            {
                "system": self.system,
                "requirements": [
                    {
                        "instance_id": ir.instance_id,
                        "description": ir.source_req.description,
                        "severity": ir.source_req.severity,
                        "origin": ir.origin,
                        "component_path": ir.component_path,
                        "status": ir.status,
                        "override_action": ir.override.action if ir.override else None,
                        "override_reason": ir.override.reason if ir.override else None,
                        "override_expires": ir.override.expires if ir.override else None,
                    }
                    for ir in self.items.values()
                ],
            },
            indent=2,
        )

    def summary(self) -> dict[str, int]:
        statuses = [ir.status for ir in self.items.values()]
        return {
            "total": len(statuses),
            "active": statuses.count("active"),
            "pass": statuses.count("pass"),
            "fail": statuses.count("fail"),
            "waived": statuses.count("waived"),
            "expired_waiver": statuses.count("expired_waiver"),
        }
