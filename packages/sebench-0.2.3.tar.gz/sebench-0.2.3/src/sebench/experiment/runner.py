"""Experiment runner: wires components, drives the kernel, writes the trace."""

from __future__ import annotations

import hashlib
import json
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import sebench.assertions as a
from sebench.component import Event, StepResult
from sebench.experiment.loader import (
    ExperimentConfig,
    SystemConfig,
    build_component_tree,
    load_experiment,
    load_system,
)
from sebench.kernel.scheduler import Scheduler
from sebench.requirements import (
    AssertionResult,
    InstantiatedRequirement,
    Requirement,
    RequirementOverride,
    Violation,
)
from sebench.trace.reader import TraceView
from sebench.trace.writer import TraceWriter

SEBENCH_VERSION = "0.1.0"


def _run_id(experiment_name: str, system_name: str, seed: int) -> str:
    now = datetime.now(tz=UTC).strftime("%Y-%m-%dT%H-%M-%S")
    return f"{now}__{system_name}__{seed}"


def _config_hash(system_cfg: SystemConfig, exp_cfg: ExperimentConfig) -> str:
    payload = json.dumps(
        {"system": system_cfg.model_dump(), "experiment": exp_cfg.model_dump()},
        sort_keys=True,
    ).encode()
    return "sha256:" + hashlib.sha256(payload).hexdigest()[:16]


def _compile_check(check: Any) -> Any:
    if callable(check):
        return check
    if isinstance(check, str):
        return eval(check, {"__builtins__": {}}, {"a": a})
    return check


def _normalize_assertion_result(result: Any, req_id: str) -> AssertionResult:
    if isinstance(result, AssertionResult):
        return result
    if isinstance(result, bool):
        return (
            AssertionResult.ok()
            if result
            else AssertionResult.fail(
                [Violation(0.0, float("inf"), f"requirement {req_id} returned False")]
            )
        )
    return AssertionResult.fail(
        [
            Violation(
                0.0,
                float("inf"),
                f"requirement {req_id} returned unsupported result type: {type(result).__name__}",
            )
        ]
    )


def _collect_requirements(
    components: dict[str, Any],
    sys_cfg: SystemConfig,
) -> list[InstantiatedRequirement]:
    collected: list[InstantiatedRequirement] = []

    for comp_name, comp in components.items():
        spec = comp.declare()
        overrides_cfg = sys_cfg.children.get(comp_name)
        override_map = overrides_cfg.requirement_overrides if overrides_cfg else {}

        for req in spec.requirements:
            inst = InstantiatedRequirement(
                instance_id=f"{comp_name}.{req.id}",
                source_req=req,
                origin="component",
                component_path=comp_name,
                component_class=type(comp).__name__,
            )
            override_raw = override_map.get(req.id)
            if override_raw:
                inst = inst.apply_override(RequirementOverride(**override_raw))
            collected.append(inst)

    for req_cfg in sys_cfg.system_requirements:
        req = Requirement(
            id=req_cfg.id,
            description=req_cfg.description,
            severity=req_cfg.severity,  # type: ignore[arg-type]
            check=req_cfg.check,
        )
        collected.append(
            InstantiatedRequirement(
                instance_id=req_cfg.id,
                source_req=req,
                origin="system",
            )
        )

    return collected


def _evaluate_requirements(
    writer: TraceWriter,
    reqs: list[InstantiatedRequirement],
) -> None:
    for req in reqs:
        try:
            view = TraceView(writer.conn, component_path=req.component_path)
            check_fn = _compile_check(req.effective_check)
            result = check_fn(view)
            req.eval_result = _normalize_assertion_result(result, req.source_req.id)
        except Exception as exc:
            req.eval_result = AssertionResult.fail(
                [
                    Violation(
                        0.0,
                        float("inf"),
                        f"requirement evaluation error: {exc}",
                    )
                ]
            )

        violations = req.eval_result.violations if req.eval_result else []
        first_violation = violations[0].t_start_s if violations else None
        summary = (
            "Passed"
            if req.eval_result and req.eval_result.passed
            else (violations[0].message if violations else "Failed")
        )
        if req.is_waived and req.override is not None:
            summary = f"Waived: {req.override.reason}"

        writer.write_requirement_result(
            req_instance_id=req.instance_id,
            status=req.status,
            severity=req.source_req.severity,
            origin=req.origin,
            first_violation_t_s=first_violation,
            violation_count=len(violations),
            summary=summary,
            details={
                "description": req.source_req.description,
                "component_path": req.component_path,
                "component_class": req.component_class,
                "override": req.override.model_dump() if req.override else None,
                "violations": [
                    {
                        "t_start_s": v.t_start_s,
                        "t_end_s": v.t_end_s,
                        "message": v.message,
                        "context": v.context,
                    }
                    for v in violations
                ],
            },
        )


class Runner:
    """Orchestrates a single experiment run.

    Usage::

        runner = Runner(
            experiment_path=Path("configs/experiments/fdm_cube_abstract.yaml"),
            system_path=Path("configs/systems/fdm_abstract_v1.yaml"),
            runs_dir=Path("runs"),
        )
        run_id, run_dir = runner.run()
    """

    def __init__(
        self,
        experiment_path: Path,
        system_path: Path,
        runs_dir: Path = Path("runs"),
    ) -> None:
        self._exp_path = experiment_path
        self._sys_path = system_path
        self._runs_dir = runs_dir

    def run(
        self,
        progress_callback: Callable[[float, float], None] | None = None,
    ) -> tuple[str, Path]:
        """Execute the experiment and return (run_id, run_dir)."""
        exp_cfg = load_experiment(self._exp_path)
        sys_cfg = load_system(self._sys_path)

        run_id = _run_id(exp_cfg.name, sys_cfg.name, exp_cfg.seed)
        run_dir = self._runs_dir / run_id
        run_dir.mkdir(parents=True, exist_ok=True)

        config_hash = _config_hash(sys_cfg, exp_cfg)

        # Build component tree
        components = build_component_tree(sys_cfg, self._sys_path.parent)

        # Build input routes: component_path -> {input_port: (src_comp, src_port)}.
        # Built directly from connectors so fan-out (one source → many destinations) works.
        input_routes: dict[str, dict[str, tuple[str, str]]] = {}
        for conn_cfg in sys_cfg.connectors:
            src_comp, src_port = conn_cfg.from_.rsplit(".", 1)
            dst_comp, dst_port = conn_cfg.to.rsplit(".", 1)
            input_routes.setdefault(dst_comp, {})[dst_port] = (src_comp, src_port)

        # Snapshot the resolved config
        config_snapshot = {
            "system": sys_cfg.model_dump(),
            "experiment": exp_cfg.model_dump(),
        }
        (run_dir / "config.snapshot.yaml").write_text(
            json.dumps(config_snapshot, indent=2, default=str)
        )

        # Run with trace writing
        kernel = Scheduler(dt_s=exp_cfg.kernel.dt_s, seed=exp_cfg.seed)
        for comp_name, comp in components.items():
            rate_hz = sys_cfg.children[comp_name].rate_hz if comp_name in sys_cfg.children else None
            kernel.register(comp_name, comp, rate_hz=rate_hz)

        with TraceWriter(
            db_path=run_dir / "trace.duckdb",
            run_id=run_id,
            system_name=sys_cfg.name,
            seed=exp_cfg.seed,
            kernel_mode=exp_cfg.kernel.mode,
            dt_s=exp_cfg.kernel.dt_s,
            sebench_version=SEBENCH_VERSION,
            config_hash=config_hash,
            write_inputs=exp_cfg.write_inputs,
        ) as writer:
            kernel.reset()

            # Last outputs buffer for wiring
            last_outputs: dict[str, dict[str, Any]] = {name: {} for name in components}

            artifacts_dir = run_dir / "artifacts"

            def on_step(comp_path: str, t_s: float, result: StepResult) -> None:
                last_outputs[comp_path] = result.outputs
                for port, val in result.outputs.items():
                    writer.write_sample(t_s, comp_path, port, val)
                for filename, data, _mime in result.artifacts:
                    artifacts_dir.mkdir(exist_ok=True)
                    (artifacts_dir / filename).write_bytes(data)

            def on_event(comp_path: str, t_s: float, event: Event) -> None:
                writer.write_event(t_s, comp_path, event.kind, event.payload)

            def inputs_for(comp_path: str, t_s: float) -> dict[str, Any]:
                routes = input_routes.get(comp_path, {})
                resolved: dict[str, Any] = {}
                for dst_port, (src_comp, src_port) in routes.items():
                    val = last_outputs.get(src_comp, {}).get(src_port)
                    resolved[dst_port] = val
                    writer.write_input(t_s, comp_path, dst_port, val)
                return resolved

            progress_step = max(exp_cfg.kernel.dt_s, exp_cfg.duration_s / 200.0)
            last_progress_t = -progress_step

            def on_tick(t_s: float) -> None:
                nonlocal last_progress_t
                if progress_callback is None:
                    return
                if t_s - last_progress_t < progress_step and t_s < exp_cfg.duration_s:
                    return
                progress_callback(min(t_s, exp_cfg.duration_s), exp_cfg.duration_s)
                last_progress_t = t_s

            kernel.run(
                duration_s=exp_cfg.duration_s,
                on_step=on_step,
                on_event=on_event,
                inputs_provider=inputs_for,
                on_tick=on_tick,
            )
            if progress_callback is not None:
                progress_callback(exp_cfg.duration_s, exp_cfg.duration_s)

            reqs = _collect_requirements(components, sys_cfg)
            _evaluate_requirements(writer, reqs)

            writer.close(simulated_duration_s=exp_cfg.duration_s)

        # Write metadata.json
        metadata = {
            "schema_version": 1,
            "sebench_version": SEBENCH_VERSION,
            "run_id": run_id,
            "system_name": sys_cfg.name,
            "config_hash": config_hash,
            "seed": exp_cfg.seed,
            "kernel_mode": exp_cfg.kernel.mode,
            "dt_s": exp_cfg.kernel.dt_s,
            "simulated_duration_s": exp_cfg.duration_s,
            "hil_flag": False,
            "hil_components": [],
        }
        (run_dir / "metadata.json").write_text(json.dumps(metadata, indent=2))

        return run_id, run_dir
