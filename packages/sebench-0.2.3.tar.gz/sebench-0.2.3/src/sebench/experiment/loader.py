"""YAML loader for component, system, and experiment configs.

Accepts three YAML kinds (component:, system:, experiment:) and rejects
files that mix kinds or reference unknown component types.
"""

from __future__ import annotations

import importlib
from pathlib import Path
from typing import Any

import yaml
from pydantic import BaseModel, ConfigDict, Field

from sebench.component import Component


class ChildConfig(BaseModel):
    """One child entry in a system or composite YAML."""

    model_config = ConfigDict(extra="allow")

    type: str
    params: dict[str, Any] = Field(default_factory=dict)
    rate_hz: float | None = None
    requirement_overrides: dict[str, dict[str, Any]] = Field(default_factory=dict)


class ConnectorConfig(BaseModel):
    """One connector wire in a system YAML."""

    from_: str = Field(alias="from")
    to: str
    type: str = "sebench.connectors.ReliableConnector"
    params: dict[str, Any] = Field(default_factory=dict)

    model_config = ConfigDict(populate_by_name=True)


class KernelConfig(BaseModel):
    mode: str = "fixed_timestep"
    dt_s: float = 0.01
    max_dt_s: float | None = None


class SystemRequirementConfig(BaseModel):
    id: str
    description: str
    severity: str = "major"
    check: str  # Python expression string


class SystemConfig(BaseModel):
    """Parsed content of a ``system:`` YAML file."""

    name: str
    description: str = ""
    children: dict[str, ChildConfig] = Field(default_factory=dict)
    connectors: list[ConnectorConfig] = Field(default_factory=list)
    system_requirements: list[SystemRequirementConfig] = Field(default_factory=list)


class ExperimentConfig(BaseModel):
    """Parsed content of an ``experiment:`` YAML file."""

    name: str
    system: str  # path or dotted name to the system YAML/class
    duration_s: float
    seed: int = 42
    kernel: KernelConfig = Field(default_factory=KernelConfig)
    description: str = ""
    write_inputs: bool = True


def _resolve_class(type_str: str) -> type:
    """Import a class from a dotted module path.

    Example: ``'printerlab.components.heat_bed_abstract.HeatBedAbstract'``.
    """
    parts = type_str.rsplit(".", 1)
    if len(parts) != 2:
        raise ImportError(f"Cannot resolve type: {type_str!r} (expected 'module.ClassName')")
    module_path, class_name = parts
    module = importlib.import_module(module_path)
    return getattr(module, class_name)  # type: ignore[no-any-return]


def _instantiate_component(path: str, cfg: ChildConfig) -> Component:
    """Instantiate a component from its config."""
    cls = _resolve_class(cfg.type)
    # Find the params_schema on the class
    params_schema: type[BaseModel] | None = getattr(cls, "params_schema", None)
    if params_schema is not None and cfg.params:
        params_obj = params_schema(**cfg.params)
    elif params_schema is not None:
        params_obj = params_schema()
    else:
        params_obj = None

    # Construct: all components take (name, params) by convention
    if params_obj is not None:
        return cls(name=path, params=params_obj)  # type: ignore[no-any-return]
    return cls(name=path)  # type: ignore[no-any-return]


def load_yaml_file(path: Path) -> dict[str, Any]:
    with path.open() as f:
        data = yaml.safe_load(f)
    if not isinstance(data, dict):
        raise ValueError(f"{path}: expected a YAML mapping at root")
    # Determine the file kind — experiment files may also have a `system:` reference field,
    # so check in priority order rather than requiring exactly one identifier key.
    identifiers = ("experiment", "system", "component")
    if not any(k in data for k in identifiers):
        raise ValueError(f"{path}: must have one of {identifiers} as a top-level key")
    return data


def load_system(path: Path) -> SystemConfig:
    """Parse a system: YAML file into a SystemConfig."""
    data = load_yaml_file(path)
    if "system" not in data:
        raise ValueError(f"{path} is not a system: YAML (found {list(data.keys())})")
    system_data = {"name": data["system"], **{k: v for k, v in data.items() if k != "system"}}
    return SystemConfig(**system_data)


def load_experiment(path: Path) -> ExperimentConfig:
    """Parse an experiment: YAML file into an ExperimentConfig."""
    data = load_yaml_file(path)
    if "experiment" not in data:
        raise ValueError(f"{path} is not an experiment: YAML (found {list(data.keys())})")
    exp_data = {"name": data["experiment"], **{k: v for k, v in data.items() if k != "experiment"}}
    return ExperimentConfig(**exp_data)


def build_component_tree(
    system_cfg: SystemConfig,
    system_yaml_dir: Path | None = None,
) -> dict[str, Component]:
    """Instantiate all components declared in a system config.

    Returns a flat dict of {dotted_path: Component} for the scheduler.
    """
    components: dict[str, Component] = {}
    for child_name, child_cfg in system_cfg.children.items():
        if child_cfg.type.startswith("yaml:"):
            raise NotImplementedError("YAML composite references not yet supported in v0.1")
        comp = _instantiate_component(child_name, child_cfg)
        components[child_name] = comp
    return components
