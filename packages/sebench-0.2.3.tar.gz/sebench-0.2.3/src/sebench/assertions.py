"""Trace-time assertion helpers for writing requirement checks.

Usage in a Requirement:
    from sebench import assertions as a

    Requirement(
        id="REQ-001",
        description="...",
        check=a.always(lambda t: t["temp_c"] < 100.0),
    )
"""

from __future__ import annotations

from collections.abc import Callable
from typing import TYPE_CHECKING

from sebench.requirements import AssertionResult, Violation

if TYPE_CHECKING:
    from sebench.trace.reader import TraceView


def always(predicate: Callable[[TraceView], object]) -> Callable[[TraceView], AssertionResult]:
    """Predicate must hold at every sample in the trace."""

    def check(t: TraceView) -> AssertionResult:
        violations: list[Violation] = []
        series = predicate(t)
        # series is expected to be a boolean pandas Series or a scalar bool
        try:
            items = list(series.items())  # type: ignore[attr-defined]
        except AttributeError:
            # scalar — applies globally
            if not bool(series):
                violations.append(Violation(0.0, float("inf"), "predicate failed (scalar)"))
            return AssertionResult(passed=not violations, violations=violations)

        prev_t = None
        viol_start = None
        for ts, val in items:
            if not bool(val):
                if viol_start is None:
                    viol_start = ts
                prev_t = ts
            else:
                if viol_start is not None:
                    violations.append(
                        Violation(viol_start, prev_t or viol_start, "predicate failed")
                    )
                    viol_start = None
                prev_t = ts
        if viol_start is not None:
            violations.append(Violation(viol_start, prev_t or viol_start, "predicate failed"))
        return AssertionResult(passed=not violations, violations=violations)

    return check


def never(predicate: Callable[[TraceView], object]) -> Callable[[TraceView], AssertionResult]:
    """Predicate must never hold. Shorthand for always(not predicate)."""
    return always(lambda t: ~predicate(t))  # type: ignore[operator]


def eventually(
    predicate: Callable[[TraceView], object],
    before_s: float | None = None,
) -> Callable[[TraceView], AssertionResult]:
    """Predicate holds at least once (optionally before ``before_s``)."""

    def check(t: TraceView) -> AssertionResult:
        series = predicate(t)
        try:
            items = list(series.items())  # type: ignore[attr-defined]
        except AttributeError:
            if bool(series):
                return AssertionResult.ok()
            return AssertionResult.fail([Violation(0.0, float("inf"), "predicate never held")])

        for ts, val in items:
            if before_s is not None and float(ts) > before_s:
                break
            if bool(val):
                return AssertionResult.ok()
        upper = before_s if before_s is not None else float("inf")
        return AssertionResult.fail(
            [Violation(0.0, upper, f"predicate never held before t={upper}")]
        )

    return check


def after(
    trigger: Callable[[TraceView], object],
    predicate: Callable[[TraceView], object],
    within_s: float | None = None,
) -> Callable[[TraceView], AssertionResult]:
    """After ``trigger`` fires, ``predicate`` must hold within ``within_s``."""

    def check(t: TraceView) -> AssertionResult:
        violations: list[Violation] = []
        trig_series = trigger(t)
        pred_series = predicate(t)

        try:
            trig_items = list(trig_series.items())  # type: ignore[attr-defined]
        except AttributeError:
            trig_items = []

        try:
            pred_dict = dict(pred_series.items())  # type: ignore[attr-defined]
        except AttributeError:
            pred_dict = {}

        trigger_times = [float(ts) for ts, v in trig_items if bool(v)]

        for t_trig in trigger_times:
            deadline = (t_trig + within_s) if within_s is not None else float("inf")
            held = any(
                float(ts) >= t_trig and float(ts) <= deadline and bool(v)
                for ts, v in pred_dict.items()
            )
            if not held:
                violations.append(
                    Violation(
                        t_trig,
                        deadline,
                        f"predicate did not hold within {within_s}s of trigger at t={t_trig}",
                    )
                )

        return AssertionResult(passed=not violations, violations=violations)

    return check


def fraction_of_time(
    predicate: Callable[[TraceView], object],
    at_least: float = 0.95,
) -> Callable[[TraceView], AssertionResult]:
    """Predicate holds for at least ``at_least`` fraction of samples."""

    def check(t: TraceView) -> AssertionResult:
        series = predicate(t)
        try:
            vals = [bool(v) for _, v in series.items()]  # type: ignore[attr-defined]
        except AttributeError:
            vals = [bool(series)]
        if not vals:
            return AssertionResult.ok()
        frac = sum(vals) / len(vals)
        if frac >= at_least:
            return AssertionResult.ok()
        return AssertionResult.fail(
            [
                Violation(
                    0.0,
                    float("inf"),
                    f"predicate held for {frac:.1%} of samples, required {at_least:.1%}",
                )
            ]
        )

    return check


def settles_to(
    signal: Callable[[TraceView], object],
    target: float,
    tolerance: float,
    within_s: float,
) -> Callable[[TraceView], AssertionResult]:
    """Signal settles to within ``tolerance`` of ``target`` by ``within_s``."""

    def check(t: TraceView) -> AssertionResult:
        series = signal(t)
        try:
            items = [(float(ts), float(v)) for ts, v in series.items()]  # type: ignore[attr-defined]
        except AttributeError:
            return AssertionResult.ok()

        late = [(ts, v) for ts, v in items if ts > within_s]
        if not late:
            return AssertionResult.ok()
        bad = [(ts, v) for ts, v in late if abs(v - target) > tolerance]
        if not bad:
            return AssertionResult.ok()
        violations = [
            Violation(
                bad[0][0],
                bad[-1][0],
                f"signal did not settle to {target}±{tolerance} by t={within_s}",
            )
        ]
        return AssertionResult.fail(violations)

    return check


def all_of(
    *checks: Callable[[TraceView], AssertionResult],
) -> Callable[[TraceView], AssertionResult]:
    """All checks must pass."""

    def check(t: TraceView) -> AssertionResult:
        all_violations: list[Violation] = []
        for c in checks:
            r = c(t)
            all_violations.extend(r.violations)
        return AssertionResult(passed=not all_violations, violations=all_violations)

    return check


def any_of(
    *checks: Callable[[TraceView], AssertionResult],
) -> Callable[[TraceView], AssertionResult]:
    """At least one check must pass."""

    def check(t: TraceView) -> AssertionResult:
        for c in checks:
            if c(t).passed:
                return AssertionResult.ok()
        return AssertionResult.fail([Violation(0.0, float("inf"), "none of the sub-checks passed")])

    return check
