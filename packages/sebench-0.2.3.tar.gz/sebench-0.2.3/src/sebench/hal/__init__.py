"""Hardware abstraction layer.

The only place in sebench allowed to read wall-clock time, perform
OS-level I/O, or cross the sim/real boundary.

v0.1: stub module. HAL drivers ship in v0.2.
"""
