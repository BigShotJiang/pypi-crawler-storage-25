"""DuckDB trace reader and TraceView abstraction for requirements checks."""

from __future__ import annotations

from pathlib import Path
from typing import Any

import duckdb
import pandas as pd


class TraceView:
    """Lazy view over a trace, behaving like a time-indexed DataFrame.

    Used as the ``t`` argument in requirement check functions::

        check=a.always(lambda t: t["temp_c"] < 100.0)

    Supports:
        t["port_name"]                  -- signal on the subject component
        t["child.port_name"]            -- dotted path for composite checks
        t["params.xxx"]                 -- constant param series
        t["event:kind"]                 -- boolean series, True at event time
    """

    def __init__(
        self,
        conn: duckdb.DuckDBPyConnection,
        component_path: str = "",
    ) -> None:
        self._conn = conn
        self._path = component_path
        self._cache: dict[str, pd.Series] = {}

    def __getitem__(self, key: str) -> pd.Series:
        if key in self._cache:
            return self._cache[key]
        result = self._resolve(key)
        self._cache[key] = result
        return result

    def _resolve(self, key: str) -> pd.Series:
        if key.startswith("event:"):
            return self._event_series(key[6:])
        if key.startswith("params."):
            return self._param_series(key[7:])

        # Signal: component path + port
        if "." in key:
            # Explicit dotted path
            parts = key.rsplit(".", 1)
            comp_path, port = parts[0], parts[1]
        else:
            comp_path = self._path
            port = key

        return self._signal_series(comp_path, port)

    def _signal_series(self, component: str, port: str) -> pd.Series:
        """Fetch a signal from the samples table."""
        df = self._conn.execute(
            """
            SELECT t_s,
                COALESCE(value_float,
                    CAST(value_int AS DOUBLE),
                    CAST(value_bool AS DOUBLE)) AS value
            FROM samples
            WHERE component = ? AND port = ?
            ORDER BY t_s
            """,
            [component, port],
        ).df()
        if df.empty:
            # Try string values
            df = self._conn.execute(
                """
                SELECT t_s, value_str AS value
                FROM samples
                WHERE component = ? AND port = ?
                ORDER BY t_s
                """,
                [component, port],
            ).df()
        if df.empty:
            return pd.Series(dtype=float, name=f"{component}.{port}")
        return df.set_index("t_s")["value"]

    def _event_series(self, kind: str) -> pd.Series:
        """Return a boolean Series, True at timestamps where the event fired."""
        df = self._conn.execute(
            """
            SELECT t_s FROM events WHERE kind = ? ORDER BY t_s
            """,
            [kind],
        ).df()
        if df.empty:
            return pd.Series(dtype=bool, name=f"event:{kind}")
        return pd.Series(True, index=df["t_s"], name=f"event:{kind}")

    def _param_series(self, param_name: str) -> pd.Series:
        """Return a constant Series (params don't change over time)."""
        # Not yet stored in trace v0.1 — return empty series
        return pd.Series(dtype=float, name=f"params.{param_name}")


class TraceReader:
    """High-level reader for a run's trace.duckdb."""

    def __init__(self, db_path: Path) -> None:
        self._path = db_path
        self.conn = duckdb.connect(str(db_path), read_only=True)

    def close(self) -> None:
        self.conn.close()

    def __enter__(self) -> TraceReader:
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    def meta(self) -> dict[str, Any]:
        row = self.conn.execute("SELECT * FROM meta LIMIT 1").fetchone()
        if row is None:
            return {}
        cols = [d[0] for d in self.conn.description]
        return dict(zip(cols, row, strict=False))

    def samples(
        self,
        component: str | None = None,
        port: str | None = None,
        t_start: float | None = None,
        t_end: float | None = None,
    ) -> pd.DataFrame:
        """Return samples as a wide DataFrame indexed by t_s."""
        where_clauses = []
        params: list[Any] = []
        if component:
            where_clauses.append("component = ?")
            params.append(component)
        if port:
            where_clauses.append("port = ?")
            params.append(port)
        if t_start is not None:
            where_clauses.append("t_s >= ?")
            params.append(t_start)
        if t_end is not None:
            where_clauses.append("t_s <= ?")
            params.append(t_end)
        where = ("WHERE " + " AND ".join(where_clauses)) if where_clauses else ""
        return self.conn.execute(
            f"SELECT * FROM samples {where} ORDER BY t_s",
            params or None,
        ).df()

    def events(self, kind: str | None = None) -> pd.DataFrame:
        where = "WHERE kind = ?" if kind else ""
        params = [kind] if kind else None
        return self.conn.execute(
            f"SELECT * FROM events {where} ORDER BY t_s",
            params,
        ).df()

    def requirement_results(self) -> pd.DataFrame:
        return self.conn.execute("SELECT * FROM requirement_results").df()

    def view(self, component_path: str = "") -> TraceView:
        return TraceView(self.conn, component_path)


def open_trace(run_dir: str | Path) -> TraceReader:
    """Open a trace from a run directory or a direct .duckdb path."""
    p = Path(run_dir)
    if p.is_dir():
        p = p / "trace.duckdb"
    return TraceReader(p)
