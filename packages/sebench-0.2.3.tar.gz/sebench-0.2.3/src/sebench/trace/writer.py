"""Streaming DuckDB trace writer.

Values are buffered in memory and flushed at configurable intervals.
Append-only: no UPDATE or DELETE queries during a run.
"""

from __future__ import annotations

import json
from datetime import UTC, datetime
from pathlib import Path
from typing import Any

import duckdb

from sebench.trace.schema import DDL, SCHEMA_VERSION


def _classify(val: Any) -> tuple[str, Any, Any, Any, Any, Any]:  # noqa: PLR0911
    """Return (value_type, float, int, bool, str, blob) for a value."""
    if isinstance(val, bool):
        return "bool", None, None, val, None, None
    if isinstance(val, float):
        return "float", val, None, None, None, None
    if isinstance(val, int):
        return "int", None, val, None, None, None
    if isinstance(val, str):
        return "string", None, None, None, val, None
    if isinstance(val, (bytes, bytearray)):
        return "blob", None, None, None, None, bytes(val)
    # Fallback: JSON-encode to string
    try:
        return "string", None, None, None, json.dumps(val), None
    except (TypeError, ValueError):
        return "string", None, None, None, repr(val), None


class TraceWriter:
    """Writes a simulation trace to a DuckDB file.

    Usage::

        with TraceWriter(path / "trace.duckdb", run_meta) as writer:
            writer.write_sample(t, "bed", "temp_c", 23.5)
            writer.write_event(t, "bed", "watchdog_fired")
    """

    # Flush every N rows to bound memory usage
    FLUSH_EVERY = 1000

    def __init__(
        self,
        db_path: Path,
        run_id: str,
        system_name: str,
        seed: int,
        kernel_mode: str = "fixed_timestep",
        dt_s: float | None = None,
        sebench_version: str = "0.1.0",
        config_hash: str = "",
        write_inputs: bool = True,
    ) -> None:
        self._db_path = db_path
        self._run_id = run_id
        self._system_name = system_name
        self._seed = seed
        self._kernel_mode = kernel_mode
        self._dt_s = dt_s
        self._version = sebench_version
        self._config_hash = config_hash
        self._write_inputs = write_inputs
        self._started_at: datetime | None = None

        self._sample_buf: list[tuple[Any, ...]] = []
        self._event_buf: list[tuple[Any, ...]] = []
        self._input_buf: list[tuple[Any, ...]] = []

        self._conn: duckdb.DuckDBPyConnection | None = None

    def open(self) -> None:
        self._conn = duckdb.connect(str(self._db_path))
        self._conn.execute(DDL)
        self._started_at = datetime.now(tz=UTC)
        self._conn.execute(
            """
            INSERT INTO meta
                (schema_version, sebench_version, run_id, system_name,
                 config_hash, seed, kernel_mode, dt_s, started_at, hil_flag, hil_components)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, FALSE, '[]')
            """,
            [
                SCHEMA_VERSION,
                self._version,
                self._run_id,
                self._system_name,
                self._config_hash,
                self._seed,
                self._kernel_mode,
                self._dt_s,
                self._started_at,
            ],
        )

    def close(self, simulated_duration_s: float | None = None) -> None:
        self._flush_all()
        if self._conn is not None:
            ended_at = datetime.now(tz=UTC)
            self._conn.execute(
                "UPDATE meta SET ended_at=?, simulated_duration_s=?",
                [ended_at, simulated_duration_s],
            )
            self._conn.close()
            self._conn = None

    def __enter__(self) -> TraceWriter:
        self.open()
        return self

    def __exit__(self, *_: Any) -> None:
        self.close()

    @property
    def conn(self) -> duckdb.DuckDBPyConnection:
        if self._conn is None:
            raise RuntimeError("TraceWriter connection is not open")
        return self._conn

    def write_sample(
        self,
        t_s: float,
        component: str,
        port: str,
        value: Any,
    ) -> None:
        vtype, vf, vi, vb, vs, vblob = _classify(value)
        self._sample_buf.append((t_s, component, port, vtype, vf, vi, vb, vs, vblob))
        if len(self._sample_buf) >= self.FLUSH_EVERY:
            self._flush_samples()

    def write_event(
        self,
        t_s: float,
        component: str,
        kind: str,
        payload: dict[str, Any] | None = None,
    ) -> None:
        self._event_buf.append((t_s, component, kind, json.dumps(payload or {})))
        if len(self._event_buf) >= self.FLUSH_EVERY:
            self._flush_events()

    def write_input(
        self,
        t_s: float,
        component: str,
        port: str,
        value: Any,
    ) -> None:
        if not self._write_inputs:
            return
        vtype, vf, vi, vb, vs, vblob = _classify(value)
        self._input_buf.append((t_s, component, port, vtype, vf, vi, vb, vs, vblob))
        if len(self._input_buf) >= self.FLUSH_EVERY:
            self._flush_inputs()

    def write_requirement_result(
        self,
        req_instance_id: str,
        status: str,
        severity: str,
        origin: str,
        first_violation_t_s: float | None,
        violation_count: int,
        summary: str,
        details: dict[str, Any] | None = None,
    ) -> None:
        assert self._conn is not None
        self._conn.execute(
            """
            INSERT INTO requirement_results
                (req_instance_id, status, severity, origin,
                 first_violation_t_s, violation_count, summary, details_json)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            """,
            [
                req_instance_id,
                status,
                severity,
                origin,
                first_violation_t_s,
                violation_count,
                summary,
                json.dumps(details or {}),
            ],
        )

    def _flush_samples(self) -> None:
        if not self._sample_buf or self._conn is None:
            return
        self._conn.executemany(
            "INSERT INTO samples VALUES (?,?,?,?,?,?,?,?,?)",
            self._sample_buf,
        )
        self._sample_buf.clear()

    def _flush_events(self) -> None:
        if not self._event_buf or self._conn is None:
            return
        self._conn.executemany(
            "INSERT INTO events VALUES (?,?,?,?)",
            self._event_buf,
        )
        self._event_buf.clear()

    def _flush_inputs(self) -> None:
        if not self._input_buf or self._conn is None:
            return
        self._conn.executemany(
            "INSERT INTO inputs VALUES (?,?,?,?,?,?,?,?,?)",
            self._input_buf,
        )
        self._input_buf.clear()

    def _flush_all(self) -> None:
        self._flush_samples()
        self._flush_events()
        self._flush_inputs()
