"""Versioned DuckDB schema definitions for trace storage.

Schema version 1 — initial schema. Version is bumped only on breaking changes
(dropped columns, changed types). Additive changes do not bump.
"""

SCHEMA_VERSION = 1

DDL = """
CREATE TABLE IF NOT EXISTS meta (
    schema_version     INTEGER NOT NULL,
    sebench_version    VARCHAR NOT NULL,
    run_id             VARCHAR NOT NULL,
    system_name        VARCHAR NOT NULL,
    config_hash        VARCHAR NOT NULL DEFAULT '',
    seed               BIGINT  NOT NULL,
    kernel_mode        VARCHAR NOT NULL DEFAULT 'fixed_timestep',
    dt_s               DOUBLE,
    started_at         TIMESTAMP,
    ended_at           TIMESTAMP,
    simulated_duration_s DOUBLE,
    hil_flag           BOOLEAN NOT NULL DEFAULT FALSE,
    hil_components     JSON    NOT NULL DEFAULT '[]'
);

CREATE TABLE IF NOT EXISTS samples (
    t_s            DOUBLE  NOT NULL,
    component      VARCHAR NOT NULL,
    port           VARCHAR NOT NULL,
    value_type     VARCHAR NOT NULL,
    value_float    DOUBLE,
    value_int      BIGINT,
    value_bool     BOOLEAN,
    value_str      VARCHAR,
    value_blob     BLOB
);

CREATE TABLE IF NOT EXISTS events (
    t_s            DOUBLE  NOT NULL,
    component      VARCHAR NOT NULL,
    kind           VARCHAR NOT NULL,
    payload_json   VARCHAR NOT NULL DEFAULT ''
);

CREATE TABLE IF NOT EXISTS inputs (
    t_s            DOUBLE  NOT NULL,
    component      VARCHAR NOT NULL,
    port           VARCHAR NOT NULL,
    value_type     VARCHAR NOT NULL,
    value_float    DOUBLE,
    value_int      BIGINT,
    value_bool     BOOLEAN,
    value_str      VARCHAR,
    value_blob     BLOB
);

CREATE TABLE IF NOT EXISTS requirement_results (
    req_instance_id     VARCHAR NOT NULL,
    status              VARCHAR NOT NULL,
    severity            VARCHAR NOT NULL,
    origin              VARCHAR NOT NULL,
    first_violation_t_s DOUBLE,
    violation_count     INTEGER NOT NULL DEFAULT 0,
    summary             VARCHAR NOT NULL DEFAULT '',
    details_json        VARCHAR NOT NULL DEFAULT '{}'
);

CREATE INDEX IF NOT EXISTS idx_samples_t  ON samples (t_s);
CREATE INDEX IF NOT EXISTS idx_events_t   ON events  (t_s);
CREATE INDEX IF NOT EXISTS idx_inputs_t   ON inputs  (t_s);
"""
