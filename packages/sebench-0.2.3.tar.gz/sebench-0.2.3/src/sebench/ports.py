"""Port declaration types."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass(frozen=True)
class Port:
    """A named, typed connection point on a component.

    ``dtype`` is checked at wiring time; ``unit`` is purely documentary.
    """

    dtype: type
    description: str = ""
    unit: str | None = None

    def is_compatible(self, other: Port) -> bool:
        """True iff this port's dtype is compatible with ``other``.

        For now: exact match or subtype. ``Any`` is always compatible.
        """
        if self.dtype is Any or other.dtype is Any:
            return True
        return issubclass(self.dtype, other.dtype)
