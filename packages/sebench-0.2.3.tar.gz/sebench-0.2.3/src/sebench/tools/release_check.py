"""Release check: semver validity, version bump vs main, no duplicate tag.

Usage:
    python -m sebench.tools.release_check packages/sebench/pyproject.toml
"""

from __future__ import annotations

import re
import subprocess
import sys
import tomllib
from pathlib import Path


def _read_version(path: Path) -> str:
    with path.open("rb") as f:
        return str(tomllib.load(f)["project"]["version"])


def _is_valid_semver(version: str) -> bool:
    return bool(re.fullmatch(r"\d+\.\d+\.\d+(?:[-+].+)?", version))


def _version_on_main(path: Path) -> str | None:
    try:
        result = subprocess.run(
            ["git", "show", f"origin/main:{path}"],
            capture_output=True,
            text=True,
            check=True,
        )
        return str(tomllib.loads(result.stdout)["project"]["version"])
    except (subprocess.CalledProcessError, KeyError, tomllib.TOMLDecodeError):
        return None


def _tag_exists(version: str) -> bool:
    result = subprocess.run(
        ["git", "tag", "-l", f"v{version}"], capture_output=True, text=True, check=False
    )
    return bool(result.stdout.strip())


def main(argv: list[str] | None = None) -> int:
    args = argv if argv is not None else sys.argv[1:]
    if not args:
        print("Usage: python -m sebench.tools.release_check <pyproject.toml>", file=sys.stderr)
        return 1

    path = Path(args[0])
    if not path.exists():
        print(f"Error: {path} not found", file=sys.stderr)
        return 1

    version = _read_version(path)

    if not _is_valid_semver(version):
        print(f"Error: version {version!r} is not valid semver (X.Y.Z)", file=sys.stderr)
        return 1

    main_version = _version_on_main(path)
    if main_version is not None and version == main_version:
        print(
            f"Error: version {version!r} unchanged from main — bump it before releasing.",
            file=sys.stderr,
        )
        return 1

    if _tag_exists(version):
        print(
            f"Error: tag v{version} already exists — version already released.",
            file=sys.stderr,
        )
        return 1

    print(f"OK: {version} is valid semver, bumped vs main, and untagged.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
