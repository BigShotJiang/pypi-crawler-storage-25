"""Determinism linter.

Scans the framework source for patterns that break bit-exact reproducibility:
  - random.* at module scope
  - time.time() / time.monotonic() outside sebench.hal
  - set/unsorted dict iteration in hot paths
  - id() or hash() calls affecting trace order

Usage::

    python -m sebench.tools.determinism_lint packages/sebench/src
"""

from __future__ import annotations

import ast
import sys
from pathlib import Path

# Patterns that are always forbidden outside sebench/hal/
FORBIDDEN_OUTSIDE_HAL = {
    "time.time",
    "time.monotonic",
    "time.perf_counter",
}

# Module-scope random usage is forbidden everywhere
FORBIDDEN_MODULE_SCOPE = {"random.random", "random.randint", "random.choice", "random.seed"}


def _in_hal_module(path: Path) -> bool:
    return "hal" in path.parts


class DeterminismVisitor(ast.NodeVisitor):
    def __init__(self, path: Path) -> None:
        self.path = path
        self.violations: list[tuple[int, str]] = []
        self._in_function = 0

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._in_function += 1
        self.generic_visit(node)
        self._in_function -= 1

    visit_AsyncFunctionDef = visit_FunctionDef  # type: ignore[assignment]

    def visit_Call(self, node: ast.Call) -> None:
        call_str = ast.unparse(node.func) if hasattr(ast, "unparse") else ""
        if not _in_hal_module(self.path):
            for pat in FORBIDDEN_OUTSIDE_HAL:
                if call_str.startswith(pat):
                    self.violations.append(
                        (node.lineno, f"Forbidden outside sebench.hal: {call_str}()")
                    )
        # Module-scope random: check if we're NOT inside a function
        if self._in_function == 0:
            for pat in FORBIDDEN_MODULE_SCOPE:
                if call_str.startswith(pat):
                    self.violations.append(
                        (node.lineno, f"Random call at module scope: {call_str}()")
                    )
        self.generic_visit(node)


def lint_file(path: Path) -> list[tuple[Path, int, str]]:
    try:
        tree = ast.parse(path.read_text())
    except SyntaxError as e:
        return [(path, 0, f"SyntaxError: {e}")]
    visitor = DeterminismVisitor(path)
    visitor.visit(tree)
    return [(path, line, msg) for line, msg in visitor.violations]


def lint_directory(src: Path) -> list[tuple[Path, int, str]]:
    all_violations: list[tuple[Path, int, str]] = []
    for py_file in sorted(src.rglob("*.py")):
        all_violations.extend(lint_file(py_file))
    return all_violations


def main() -> int:
    if len(sys.argv) < 2:
        print(f"Usage: {sys.argv[0]} <source-dir>", file=sys.stderr)
        return 2
    src = Path(sys.argv[1])
    violations = lint_directory(src)
    if violations:
        for path, line, msg in violations:
            print(f"{path}:{line}: [DET] {msg}")
        print(f"\n{len(violations)} determinism violation(s) found.", file=sys.stderr)
        return 1
    print("No determinism violations found.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
