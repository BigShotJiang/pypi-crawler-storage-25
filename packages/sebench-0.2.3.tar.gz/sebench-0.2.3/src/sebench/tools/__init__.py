"""Developer tooling: determinism linter, scaffolders, release-check."""
