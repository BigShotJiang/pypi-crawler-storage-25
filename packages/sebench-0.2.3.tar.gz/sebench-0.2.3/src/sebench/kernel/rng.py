"""Deterministic per-component seed derivation.

HMAC-SHA256 truncated to 63 bits so seeds are always non-negative Python ints.
Changing a child's name changes its seed; adding a sibling does not perturb
existing components' seeds. This is the property that makes golden traces
stable across unrelated additions.
"""

from __future__ import annotations

import hashlib as _hashlib
import hmac as _hmac


def derive_seed(parent_seed: int, child_name: str) -> int:
    """Derive a deterministic child seed from a parent seed and a name."""
    h = _hmac.new(
        parent_seed.to_bytes(8, "little"),
        child_name.encode(),
        _hashlib.sha256,
    )
    return int.from_bytes(h.digest()[:8], "little") & ((1 << 63) - 1)
