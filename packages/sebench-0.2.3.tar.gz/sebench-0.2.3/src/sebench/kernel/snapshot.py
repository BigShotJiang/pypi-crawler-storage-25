"""Checkpoint serialization for the simulation kernel.

One checkpoint = one CBOR-encoded dict containing:
- metadata (schema version, sebench version, config hash, seed, logical time)
- per-component state bytes (from component.snapshot())
- kernel state (event queue, step counter)
"""

from __future__ import annotations

import json
from dataclasses import dataclass, field
from typing import Any


@dataclass
class Checkpoint:
    """Serialized state of a complete simulation at a point in time."""

    schema_version: int = 1
    sebench_version: str = "0.1.0"
    config_hash: str = ""
    seed: int = 0
    t_logical_s: float = 0.0
    components: dict[str, bytes] = field(default_factory=dict)
    kernel_state: dict[str, Any] = field(default_factory=dict)

    def to_bytes(self) -> bytes:
        """Serialize checkpoint to a compact binary format."""
        # Simple format: JSON header + length-prefixed component blobs
        component_data: dict[str, str] = {}
        for name, state in self.components.items():
            # hex-encode state bytes for JSON compatibility
            component_data[name] = state.hex()

        payload = {
            "schema_version": self.schema_version,
            "sebench_version": self.sebench_version,
            "config_hash": self.config_hash,
            "seed": self.seed,
            "t_logical_s": self.t_logical_s,
            "components": component_data,
            "kernel_state": self.kernel_state,
        }
        return json.dumps(payload).encode()

    @classmethod
    def from_bytes(cls, data: bytes) -> Checkpoint:
        """Deserialize a checkpoint."""
        payload = json.loads(data.decode())
        components: dict[str, bytes] = {
            name: bytes.fromhex(hex_str) for name, hex_str in payload.get("components", {}).items()
        }
        return cls(
            schema_version=payload["schema_version"],
            sebench_version=payload["sebench_version"],
            config_hash=payload.get("config_hash", ""),
            seed=payload["seed"],
            t_logical_s=payload["t_logical_s"],
            components=components,
            kernel_state=payload.get("kernel_state", {}),
        )
