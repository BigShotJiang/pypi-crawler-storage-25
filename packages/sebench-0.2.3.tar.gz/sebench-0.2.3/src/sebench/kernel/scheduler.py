"""Discrete-event simulation scheduler.

Fixed-timestep and multi-rate modes. Single-threaded, deterministic.
No wall-clock reads: logical time only.
"""

from __future__ import annotations

from collections.abc import Callable
from dataclasses import dataclass, field
from typing import Any

from sebench.component import Component, Event, StepResult
from sebench.kernel.clock import Clock
from sebench.kernel.rng import derive_seed
from sebench.kernel.snapshot import Checkpoint


@dataclass(order=True)
class _ScheduledEvent:
    """An event on the kernel's min-heap."""

    at_s: float
    seq: int  # tiebreaker for stable ordering
    kind: str = field(compare=False)
    target: str = field(compare=False)  # component path, "" = kernel-internal
    payload: dict[str, Any] = field(default_factory=dict, compare=False)


@dataclass
class ComponentEntry:
    """One registered component in the scheduler."""

    path: str
    component: Component
    rate_hz: float | None = None  # None = step at every tick
    _next_step_n: int = 0  # tick counter for multi-rate scheduling
    _step_every_n: int = 1  # set after dt_s is resolved


class Scheduler:
    """Fixed-timestep (+ multi-rate) discrete-event simulation kernel.

    Usage::

        sched = Scheduler(dt_s=0.01, seed=42)
        sched.register("bed", bed_component, rate_hz=10)
        sched.register("ctrl", ctrl_component, rate_hz=100)
        sched.reset()
        trace_cb = lambda path, t, result: ...  # write to trace
        sched.run(duration_s=60.0, on_step=trace_cb)
    """

    def __init__(
        self,
        dt_s: float = 0.01,
        seed: int = 0,
        t0: float = 0.0,
    ) -> None:
        self._dt_s = dt_s
        self._seed = seed
        self._clock = Clock(t0)
        self._entries: dict[str, ComponentEntry] = {}
        self._heap: list[_ScheduledEvent] = []
        self._seq = 0
        self._step_count = 0

    @property
    def t_s(self) -> float:
        return self._clock.t_s

    @property
    def dt_s(self) -> float:
        return self._dt_s

    @property
    def step_count(self) -> int:
        return self._step_count

    def register(
        self,
        path: str,
        component: Component,
        rate_hz: float | None = None,
    ) -> None:
        """Register a component. ``path`` is its dotted path in the system."""
        entry = ComponentEntry(path=path, component=component, rate_hz=rate_hz)
        if rate_hz is not None:
            # How many base ticks between steps for this component?
            step_period_s = 1.0 / rate_hz
            every_n = max(1, round(step_period_s / self._dt_s))
            entry._step_every_n = every_n
        self._entries[path] = entry

    def reset(self) -> None:
        """Reset all components with deterministically derived seeds."""
        self._clock.reset()
        self._heap.clear()
        self._seq = 0
        self._step_count = 0
        for name in sorted(self._entries):
            entry = self._entries[name]
            child_seed = derive_seed(self._seed, name)
            entry.component.reset(child_seed)
            entry._next_step_n = 0

    def run(
        self,
        duration_s: float,
        on_step: Callable[[str, float, StepResult], None] | None = None,
        on_event: Callable[[str, float, Event], None] | None = None,
        inputs_provider: Callable[[str, float], dict[str, Any]] | None = None,
        on_tick: Callable[[float], None] | None = None,
    ) -> None:
        """Advance the simulation for ``duration_s`` seconds.

        Args:
            duration_s: How long to simulate.
            on_step: Called after each component step with (path, t_s, result).
            on_event: Called for each emitted Event with (source_path, t_s, event).
            inputs_provider: Returns input dict for a component at a given time.
            on_tick: Called after each base tick with current logical time.
        """
        end_t = self._clock.t_s + duration_s
        # Use integer tick counting to avoid float drift
        n_ticks = round(duration_s / self._dt_s)

        for tick in range(n_ticks):
            t = self._clock.t_s
            if t >= end_t:
                break

            for name in sorted(self._entries):  # deterministic order
                entry = self._entries[name]
                # Multi-rate: only step at the right ticks
                if tick % entry._step_every_n != 0:
                    continue

                effective_dt = entry._step_every_n * self._dt_s
                inputs: dict[str, Any] = {}
                if inputs_provider is not None:
                    inputs = inputs_provider(name, t)

                result = entry.component.step(effective_dt, inputs)
                self._step_count += 1

                if on_step is not None:
                    on_step(name, t, result)

                if on_event is not None:
                    for event in result.events:
                        on_event(name, t, event)

            self._clock.advance(self._dt_s)
            if on_tick is not None:
                on_tick(self._clock.t_s)

    def snapshot(self, config_hash: str = "") -> Checkpoint:
        """Capture the full simulation state as a Checkpoint."""
        component_states: dict[str, bytes] = {}
        for name in sorted(self._entries):
            component_states[name] = self._entries[name].component.snapshot()

        return Checkpoint(
            config_hash=config_hash,
            seed=self._seed,
            t_logical_s=self._clock.t_s,
            components=component_states,
            kernel_state={
                "step_count": self._step_count,
                "dt_s": self._dt_s,
            },
        )

    def restore(self, checkpoint: Checkpoint) -> None:
        """Restore simulation state from a Checkpoint."""
        self._clock.reset(checkpoint.t_logical_s)
        self._seed = checkpoint.seed
        self._step_count = checkpoint.kernel_state.get("step_count", 0)
        for name, state_bytes in checkpoint.components.items():
            if name in self._entries:
                self._entries[name].component.restore(state_bytes)
