"""Logical simulation clock.

Tracks `t_s`, the current simulation time in seconds. The clock never
reads wall-clock time — that is the exclusive domain of sebench.hal.
"""

from __future__ import annotations


class Clock:
    """Monotonically advancing logical simulation clock."""

    def __init__(self, t0: float = 0.0) -> None:
        self._t: float = t0

    @property
    def t_s(self) -> float:
        return self._t

    def advance(self, dt: float) -> None:
        if dt < 0:
            raise ValueError(f"dt must be non-negative, got {dt}")
        self._t += dt

    def reset(self, t0: float = 0.0) -> None:
        self._t = t0

    def __repr__(self) -> str:
        return f"Clock(t_s={self._t})"
