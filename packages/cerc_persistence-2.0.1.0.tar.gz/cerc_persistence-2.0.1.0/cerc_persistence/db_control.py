"""
DBControl acts as intermediary class for using the database CRUD functions 
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2019 - 2025 Concordia CERC group
Project Coder Peter Yefi peteryefi@gmail.com
Code Contributor Koa Wells kekoa.wells@concordia.ca
"""
from pathlib import Path
from typing import Sequence
from geoalchemy2 import WKTElement
from sqlalchemy import text, Row
from hub.city_model_structure.building import Building as HubBuilding

from cerc_persistence.models.user_permission_model import UserPermissionModel
from cerc_persistence.repository import Repository
from cerc_persistence.models import UserRoles, CityModel, BuildingModel, BuildingSimulationModel, UserModel
from cerc_persistence.configuration import Models
from cerc_persistence.repositories.user_repository import UserRepository
from cerc_persistence.repositories.user_permission_repository import UserPermissionRepository
from cerc_persistence.repositories.city_repository import CityRepository
from cerc_persistence.repositories.building_repository import BuildingRepository
from cerc_persistence.repositories.building_simulation_repository import BuildingSimulationRepository


class DBControl:
  """
  DBFactory class
  """
  def __init__(self, dotenv_path: Path, app_env: str):
    """
    Initializes the repositories used for accessing the CRUD functions by the DBControl class

    :param dotenv_path: path to the .env file
    :param app_env: name of the application environment (PROD or TEST)
    """
    self._dotenv_path = dotenv_path
    self._app_env = app_env
    self._user = UserRepository(self._dotenv_path, self._app_env)
    self._user_permission = UserPermissionRepository(self._dotenv_path, self._app_env)
    self._city = CityRepository(self._dotenv_path, self._app_env)
    self._building = BuildingRepository(self._dotenv_path, self._app_env)
    self._building_simulation = BuildingSimulationRepository(self._dotenv_path, self._app_env)

  def initialize_database(self) -> None:
    """
    Creates database tables 
    """
    repository = Repository(self._dotenv_path, self._app_env)
    # ensure that postgis gets installed
    with repository.engine.begin() as conn:
      conn.execute(text("CREATE EXTENSION IF NOT EXISTS postgis"))

    # Create the tables using the models
    Models.metadata.create_all(bind=repository.engine)

  def purge_database(self) -> None:
    """
    Purges all database tables, sequences, and extensions
    """
    repository = Repository(self._dotenv_path, self._app_env)
    Models.metadata.drop_all(bind=repository.engine)
    # drops all sequences and extensions
    with repository.engine.connect() as conn:
      conn.execute(text("""
                        SELECT 'DROP SEQUENCE IF EXISTS "' || sequence_schema || '"."' || sequence_name || '" CASCADE;'
                        FROM information_schema.sequences
                        WHERE sequence_schema = 'public';
                        """))

  def persist_city(self, name: str, location: WKTElement, description: str) -> int:
    """
    Persists city into the database

    :param name: name of the city
    :param location: location of the city
    :param description: description of the city
    :return: id of the inserted city
    """
    city_id = self._city.insert(name, location, description)
    return city_id

  def persist_building(self, city_id: int, hub_city_name: str, partition_id: str, building: HubBuilding) -> int:
    """
    Persists building into the database

    :param city_id: id of the city
    :param hub_city_name: name assigned to the city by the cerc-hub package based on location
    :param partition_id: id of the city partition that owns the building
    :param building: cerc-hub Building containing pertinent data to persist the building
    :return: id of the inserted building
    """
    building_id = self._building.insert(city_id, hub_city_name, partition_id, building)
    return building_id

  def persist_building_simulation(self, building_id: int,
                                  retrofit_scenario: str,
                                  energy_simulation_source: str,
                                  energy_simulation: dict,
                                  co2_emissions: dict,
                                  costs: dict) -> int:
    """
    Persists a new building simulation into the database

    :param building_id: id of the building of which the building simulation is associated
    :param retrofit_scenario: Retrofit scenario applied to the building
    :param energy_simulation_source: Source of the energy simulation such as EnergyPlus, INSEL, etc.
    :param energy_simulation: Energy simulation result
    :param co2_emissions: Co2 emissions simulation result
    :param costs: Cost simulation result
    :return: id of the inserted building simulation
    """
    building_simulation_id = self._building_simulation.insert(building_id,
                                                              retrofit_scenario,
                                                              energy_simulation_source,
                                                              energy_simulation,
                                                              co2_emissions,
                                                              costs)
    return building_simulation_id

  def persist_user(self, username: str, password: str, role: UserRoles) -> int:
    """
    Persists user into the database

    :param username: username of the user
    :param password: password of the user
    :param role: role of the user
    :return: id of the inserted user
    """
    user_id = self._user.insert(username, password, role)
    return user_id

  def persist_user_permission(self, user_id: int, city_id: int) -> int:
    """
    Persists user permission into the database

    :param user_id: id of the user of which the user permission is associated
    :param city_id: id of the city for which the user has permission to access
    :return: id of the inserted user permission
    """
    user_permission_id = self._user_permission.insert(user_id, city_id)
    return user_permission_id

  def get_city_by_name(self, name: str) -> CityModel | None:
    """
    Fetch city from the database by name

    :param name: name of the city
    :return: desired city
    """
    city = self._city.get_by_name(name)
    return city

  def get_cities_by_city_ids(self, city_ids: list[int]) -> Sequence[CityModel] | None:
    """
    Fetch multiple cities from the database from a list of city_ids

    :param city_ids: list of city ids
    :return: list of desired cities
    """
    cities = self._city.get_multiple_by_city_ids(city_ids)
    return cities

  def get_building_by_name_and_city_name(self, name: str, city_name: str) -> BuildingModel | None:
    """
    Fetch building from the database by name and city name

    :param name: name of the building
    :param city_name: name of the city that owns the building
    :return: desired building
    """
    building = self._building.get_by_name_and_city_name(name, city_name)
    return building

  def get_buildings_by_city_name(self, city_name: str) -> Sequence[BuildingModel] | None:
    """
    Fetch buildings from the database by city_name

    :param city_name: name of the city who owns the building(s)
    :return: list of desired buildings
    """
    buildings = self._building.get_multiple_by_city_name(city_name)
    return buildings

  def get_building_simulations_by_city_name(self, city_name: str) -> Sequence[BuildingSimulationModel] | None:
    """
    Fetch building simulations from the database by city_name

    :param city_name: name of the city who owns the building_simulation(s)
    :return: list of desired building simulations
    """
    building_simulations = self._building_simulation.get_multiple_by_city_name(city_name)
    return building_simulations

  def get_buildings_with_simulations_by_city_name_and_building_ids(self, city_name: str, building_ids: list) -> (
      Sequence[BuildingSimulationModel] | None):
    """
    Fetch buildings and their associated building simulations from the database by city_name and building_ids

    :param city_name: name of the city who owns the buildings
    :param building_ids: list of building ids
    :return: list of desired buildings and their associated building simulations
    """
    buildings = self._building.get_multiple_with_simulations_by_city_name_and_building_ids(city_name, building_ids)
    return buildings

  def get_user_by_username(self, username: str) -> UserModel | None:
    """
    Fetch user from the database by username

    :param username: username of the user
    :return: desired user
    """
    user = self._user.get_by_username(username)
    return user

  def get_user_by_username_and_password(self, username: str, password: str) -> UserModel | None:
    """
    Fetch user from the database by username and password

    :param username: username of the user
    :param password: password of the user
    :return: desired user
    """
    user = self._user.get_by_username_and_password(username, password)
    return user

  def get_user_permissions_by_user_id(self, user_id: int) -> Sequence[UserPermissionModel] | None:
    """
    Fetch user permissions from the database by user_id

    :param user_id: id of the user
    :return: desired user permissions
    """
    user_permissions = self._user_permission.get_multiple_by_user_id(user_id)
    return user_permissions

  def get_buildings_within_polygon(self, city_id: int, polygon: dict) -> (
      Sequence[Row[tuple[BuildingModel, str]]] | None):
    """
    Get buildings intersecting a polygon in a city.

    :param city_id: ID of the city your polygon is in
    :param polygon: GeoJSON
    :return: list of buildings
    """
    buildings = self._building.get_multiple_within_polygon(city_id, polygon)
    return buildings
