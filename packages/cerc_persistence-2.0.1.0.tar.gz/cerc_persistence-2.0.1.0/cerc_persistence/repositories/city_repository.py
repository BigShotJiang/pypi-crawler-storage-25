"""
City repository with database CRUD operations
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2019 - 2025 Concordia CERC group
Project Coder Peter Yefi peteryefi@gmail.com
Code Contributor Koa Wells kekoa.wells@concordia.ca
"""
import datetime
import logging
from pathlib import Path
from typing import Sequence
from sqlalchemy import select, update, delete
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session
from geoalchemy2 import WKTElement

from cerc_persistence.repository import Repository
from cerc_persistence.models import CityModel


class CityRepository(Repository):
  """
  CityRepository(Repository) class
  """
  _instance = None

  def __init__(self, dotenv_path: Path, app_env: str):
    super().__init__(dotenv_path, app_env)

  def __new__(cls, dotenv_path, app_env):
    """
    Implemented for a singleton pattern
    """
    if cls._instance is None:
      cls._instance = super(CityRepository, cls).__new__(cls)
    return cls._instance

  def insert(self, name: str, location: WKTElement, description: str) -> int:
    """
    Inserts a city

    :param name: the name of the city
    :param location: coordinate of the city
    :param description: Description of the city
    :return: id of the inserted city
    """
    city = self.get_by_name(name)
    if city:
      logging.error('cerc_persistence:City already exists: %s', city)
      raise SQLAlchemyError(f'A city named {name} already exists in the database')
    try:
      city = CityModel(name, location, description)
      with Session(self.engine) as session:
        session.add(city)
        session.flush()
        session.commit()
        session.refresh(city)
        return city.id
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:An error occurred while creating a city %s', err)
      raise SQLAlchemyError from err

  def update(self, name:str, location: WKTElement, description: str) -> None:
    """
    Updates a city's location or description by name

    :param name: The name of the city to update
    :param location: location of the city to update
    :param description: description about the city to update
    """
    updated_values = {'updated': datetime.datetime.now()}
    if location:
      updated_values['location'] = location
    if description:
      updated_values['description'] = description

    try:
      with Session(self.engine) as session:
        statement = update(CityModel).where(CityModel.name == name).values(updated_values)
        session.execute(statement)
        session.commit()
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while updating city %s', err)
      raise SQLAlchemyError from err

  def delete(self, name: str) -> None:
    """
    Deletes a City with the given name

    :param name: the name of the city to delete
    """
    try:
      with Session(self.engine) as session:
        statement = delete(CityModel).where(CityModel.name == name)
        session.execute(statement)
        session.commit()
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while deleting city %s', err)
      raise SQLAlchemyError from err

  def get_by_name(self, name: str) -> CityModel | None:
    """"
    Fetch a city by name

    :param name: the name of the city
    :return: Desired city if it exists
    """
    try:
      with Session(self.engine) as session:
        query = select(CityModel).where(CityModel.name == name)
        city = session.execute(query).scalar_one_or_none()
        return city
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while fetching city by name %s', err)
      raise SQLAlchemyError from err

  def get_multiple_by_city_ids(self, city_ids: list) -> Sequence[CityModel] | None:
    """
    Fetch multiple cities from a list of city ids

    :param city_ids: list of city ids
    :return: list of cities fetched from the database if they exist
    """
    try:
      with Session(self.engine) as session:
        query = select(CityModel).where(CityModel.id.in_(city_ids))
        cities = session.execute(query).scalars().all()
        return cities
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while fetching cities by city ids %s', err)
      raise SQLAlchemyError from err
