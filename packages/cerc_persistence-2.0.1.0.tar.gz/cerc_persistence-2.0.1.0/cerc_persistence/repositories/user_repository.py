"""
User repository with database CRUD operations
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2019 - 2025 Concordia CERC group
Project Coder Peter Yefi peteryefi@gmail.com
Code Contributor Koa Wells kekoa.wells@concordia.ca
"""
import datetime
import logging
from pathlib import Path

from sqlalchemy import select, delete, func
from sqlalchemy.exc import SQLAlchemyError
from sqlalchemy.orm import Session
from hub.helpers.auth import Auth

from cerc_persistence.repository import Repository
from cerc_persistence.models import UserRoles, UserModel


class UserRepository(Repository):
  """
  UserRepository(Repository) class
  """
  _instance = None

  def __init__(self, dotenv_path: Path, app_env: str):
    super().__init__(dotenv_path, app_env)

  def __new__(cls, dotenv_path, app_env):
    """
    Implemented for a singleton pattern
    """
    if cls._instance is None:
      cls._instance = super(UserRepository, cls).__new__(cls)
    return cls._instance

  def insert(self, username: str, password: str, role: UserRoles) -> int:
    """
    Inserts a new user

    :param username: username of the new user to be inserted
    :param password: user password
    :param role: role of the user
    :return: user_id of the inserted user
    """
    user = self.get_by_username(username)
    if user is not None:
      logging.error('cerc_persistence:Username %s already exists', username)
      raise SQLAlchemyError(f'A user with the username {user.username} already exists')
    try:
      user = UserModel(username, Auth.hash_password(password), role)
      with Session(self.engine) as session:
        session.add(user)
        session.flush()
        session.commit()
        session.refresh(user)
      return user.id
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:An error occurred while creating user %s', err)
      raise SQLAlchemyError from err

  def update(self, username: str, password: str, role: UserRoles) -> None:
    """
    Updates a user

    :param username: the username of the user
    :param password: the password of the user
    :param role: the role of the user
    """
    updated_values = {'updated': datetime.datetime.now()}
    if username:
      updated_values['username'] = username
    if password:
      updated_values['password'] = Auth.hash_password(password)
    if role:
      updated_values['role'] = role

    try:
      with Session(self.engine) as session:
        session.query(UserModel).filter(UserModel.username == username).update(updated_values)
        session.commit()
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while updating user: %s', err)
      raise SQLAlchemyError from err

  def delete(self, username: str) -> None:
    """
    Deletes a user with the matching username

    :param username: username of the user to delete
    """
    try:
      with Session(self.engine) as session:
        statement = delete(UserModel).where(UserModel.username == username)
        session.execute(statement)
        session.commit()
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while fetching user: %s', err)
      raise SQLAlchemyError from err

  def get_by_username(self, username: str) -> UserModel | None:
    """
    Fetch user based with a given username
    :param username: username of the user to fetch
    :return: desired user or None
    """
    try:
      with Session(self.engine) as session:
        query = select(UserModel).where(func.lower(UserModel.username) == func.lower(username))
        user = session.execute(query).scalar_one_or_none()
        return user
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while fetching user by username: %s', err)
      raise SQLAlchemyError from err

  def get_by_username_and_password(self, username: str, password: str) -> UserModel | None:
    """
    Fetch user based on the username and password

    :param username: Username of the user
    :param password: Password of the user
    :return: desired user or None
    """
    try:
      with Session(self.engine) as session:
        query = select(UserModel).where(func.lower(UserModel.username) == func.lower(username))
        user = session.execute(query).scalar_one_or_none()
        if user is None:
          return None
        if Auth.check_password(password, user.password):
          return user
        logging.warning('cerc_persistence:Invalid password for user %s', username)
        return None
    except SQLAlchemyError as err:
      logging.error('cerc_persistence:Error while fetching user by username and password: %s', err)
      raise SQLAlchemyError from err
