"""
Sqlalchemy type decorator for float or numpy values
SPDX - License - Identifier: LGPL - 3.0 - or -later
Copyright © 2024 - 2026 Concordia CERC group
Project Coder Connor Brackley Connor.Brackley@concordia.ca
Code Contributor: Koa Wells kekoa.wells@concordia.ca
"""
import numpy as np
from sqlalchemy import Dialect, TypeDecorator, Float


class NumpyFloatToPrimitiveFloat(TypeDecorator): # pylint: disable=abstract-method,too-many-ancestors
  """
  Custom SQLAlchemy type decorator to convert np.float types to float.
  """
  impl = Float

  def process_bind_param(self, value: np.floating | None, dialect: Dialect) -> float | None:
    """
    Casts np.floating types to float.

    :param value: np.floating type to convert to float
    :param dialect: SQLAlchemy dialect
    :return: np.float value cast to float
    """
    if value is not None and isinstance(value, np.floating):
      return float(value)
    return value
