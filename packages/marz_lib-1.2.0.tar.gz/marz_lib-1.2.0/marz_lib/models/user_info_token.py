from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="UserInfoToken")


@_attrs_define
class UserInfoToken:
    access_token: str
    token_type: Union[Unset, str] = "bearer"
    expires_in_minutes: Union[None, Unset, int] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        field_dict = {"access_token": self.access_token, **self.additional_properties}
        if self.token_type is not UNSET:
            field_dict["token_type"] = self.token_type
        if self.expires_in_minutes is not UNSET:
            field_dict["expires_in_minutes"] = self.expires_in_minutes
        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        item = cls(
            access_token=d.pop("access_token"),
            token_type=d.pop("token_type", UNSET),
            expires_in_minutes=d.pop("expires_in_minutes", UNSET),
        )
        item.additional_properties = d
        return item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())
