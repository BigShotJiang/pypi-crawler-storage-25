from typing import Any, Dict, List, Type, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.user_device_response import UserDeviceResponse

T = TypeVar("T", bound="UserDevicesResponse")


@_attrs_define
class UserDevicesResponse:
    devices: List[UserDeviceResponse]
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {"devices": [item.to_dict() for item in self.devices], **self.additional_properties}

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        item = cls(devices=[UserDeviceResponse.from_dict(x) for x in d.pop("devices", [])])
        item.additional_properties = d
        return item
