import datetime
from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="UserDeviceResponse")


@_attrs_define
class UserDeviceResponse:
    hwid: str
    id: int
    first_seen: datetime.datetime
    last_seen: datetime.datetime
    device_os: Union[None, Unset, str] = UNSET
    ver_os: Union[None, Unset, str] = UNSET
    device_model: Union[None, Unset, str] = UNSET
    user_agent: Union[None, Unset, str] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict.update({
            "hwid": self.hwid,
            "id": self.id,
            "first_seen": self.first_seen.isoformat(),
            "last_seen": self.last_seen.isoformat(),
        })
        for key in ("device_os", "ver_os", "device_model", "user_agent"):
            value = getattr(self, key)
            if value is not UNSET:
                field_dict[key] = value
        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        item = cls(
            hwid=d.pop("hwid"),
            id=d.pop("id"),
            first_seen=isoparse(d.pop("first_seen")),
            last_seen=isoparse(d.pop("last_seen")),
            device_os=d.pop("device_os", UNSET),
            ver_os=d.pop("ver_os", UNSET),
            device_model=d.pop("device_model", UNSET),
            user_agent=d.pop("user_agent", UNSET),
        )
        item.additional_properties = d
        return item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())
