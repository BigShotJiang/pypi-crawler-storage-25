from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="UserDeviceCreate")


@_attrs_define
class UserDeviceCreate:
    hwid: str
    device_os: Union[None, Unset, str] = UNSET
    ver_os: Union[None, Unset, str] = UNSET
    device_model: Union[None, Unset, str] = UNSET
    user_agent: Union[None, Unset, str] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        field_dict["hwid"] = self.hwid
        if self.device_os is not UNSET:
            field_dict["device_os"] = self.device_os
        if self.ver_os is not UNSET:
            field_dict["ver_os"] = self.ver_os
        if self.device_model is not UNSET:
            field_dict["device_model"] = self.device_model
        if self.user_agent is not UNSET:
            field_dict["user_agent"] = self.user_agent
        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        item = cls(
            hwid=d.pop("hwid"),
            device_os=d.pop("device_os", UNSET),
            ver_os=d.pop("ver_os", UNSET),
            device_model=d.pop("device_model", UNSET),
            user_agent=d.pop("user_agent", UNSET),
        )
        item.additional_properties = d
        return item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
