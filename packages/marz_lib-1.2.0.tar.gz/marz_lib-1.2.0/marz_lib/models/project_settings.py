from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

T = TypeVar("T", bound="ProjectSettings")


@_attrs_define
class ProjectSettings:
    project_title: Union[None, Unset, str] = UNSET
    default_device_limit: Union[None, Unset, int] = UNSET
    support_url: Union[None, Unset, str] = UNSET
    profile_title: Union[None, Unset, str] = UNSET
    profile_update_interval: Union[None, Unset, str] = UNSET
    announced: Union[None, Unset, str] = UNSET
    happ_routing: Union[None, Unset, str] = UNSET
    fallback_vless_url_no_hwid: Union[None, Unset, str] = UNSET
    fallback_vless_url_expired: Union[None, Unset, str] = UNSET
    fallback_vless_url_traffic_limit: Union[None, Unset, str] = UNSET
    fallback_vless_url_device_limit: Union[None, Unset, str] = UNSET
    fallback_protocols: Union[Unset, List[str]] = UNSET
    allow_vless_after_expired: Union[Unset, bool] = False
    allow_vless_after_traffic_limit: Union[Unset, bool] = False
    allow_vless_after_device_limit: Union[Unset, bool] = False
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        for key in (
            "project_title",
            "default_device_limit",
            "support_url",
            "profile_title",
            "profile_update_interval",
            "announced",
            "happ_routing",
            "fallback_vless_url_no_hwid",
            "fallback_vless_url_expired",
            "fallback_vless_url_traffic_limit",
            "fallback_vless_url_device_limit",
            "fallback_protocols",
            "allow_vless_after_expired",
            "allow_vless_after_traffic_limit",
            "allow_vless_after_device_limit",
        ):
            value = getattr(self, key)
            if value is not UNSET:
                field_dict[key] = value
        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        item = cls(
            project_title=d.pop("project_title", UNSET),
            default_device_limit=d.pop("default_device_limit", UNSET),
            support_url=d.pop("support_url", UNSET),
            profile_title=d.pop("profile_title", UNSET),
            profile_update_interval=d.pop("profile_update_interval", UNSET),
            announced=d.pop("announced", UNSET),
            happ_routing=d.pop("happ_routing", UNSET),
            fallback_vless_url_no_hwid=d.pop("fallback_vless_url_no_hwid", UNSET),
            fallback_vless_url_expired=d.pop("fallback_vless_url_expired", UNSET),
            fallback_vless_url_traffic_limit=d.pop("fallback_vless_url_traffic_limit", UNSET),
            fallback_vless_url_device_limit=d.pop("fallback_vless_url_device_limit", UNSET),
            fallback_protocols=d.pop("fallback_protocols", UNSET),
            allow_vless_after_expired=d.pop("allow_vless_after_expired", UNSET),
            allow_vless_after_traffic_limit=d.pop("allow_vless_after_traffic_limit", UNSET),
            allow_vless_after_device_limit=d.pop("allow_vless_after_device_limit", UNSET),
        )
        item.additional_properties = d
        return item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
