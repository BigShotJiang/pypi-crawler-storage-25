from typing import TYPE_CHECKING, Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..types import UNSET, Unset

if TYPE_CHECKING:
    from ..models.proxy_types import ProxyTypes

T = TypeVar("T", bound="SyncInboundsRequest")


@_attrs_define
class SyncInboundsRequest:
    protocols: Union[Unset, List["ProxyTypes"]] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        protocols: Union[Unset, List[str]] = UNSET
        if not isinstance(self.protocols, Unset):
            protocols = []
            for protocol in self.protocols:
                protocols.append(protocol.value)

        field_dict: Dict[str, Any] = {}
        field_dict.update(self.additional_properties)
        if protocols is not UNSET:
            field_dict["protocols"] = protocols

        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        from ..models.proxy_types import ProxyTypes

        d = src_dict.copy()
        protocols = d.pop("protocols", UNSET)

        parsed_protocols: Union[Unset, List[ProxyTypes]]
        if isinstance(protocols, Unset):
            parsed_protocols = UNSET
        else:
            parsed_protocols = [ProxyTypes(item) for item in protocols or []]

        item = cls(protocols=parsed_protocols)
        item.additional_properties = d
        return item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())

    def __getitem__(self, key: str) -> Any:
        return self.additional_properties[key]

    def __setitem__(self, key: str, value: Any) -> None:
        self.additional_properties[key] = value

    def __delitem__(self, key: str) -> None:
        del self.additional_properties[key]

    def __contains__(self, key: str) -> bool:
        return key in self.additional_properties
