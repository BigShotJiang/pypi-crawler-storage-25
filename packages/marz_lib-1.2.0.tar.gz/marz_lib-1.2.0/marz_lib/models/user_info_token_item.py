import datetime
from typing import Any, Dict, List, Type, TypeVar, Union

from attrs import define as _attrs_define
from attrs import field as _attrs_field
from dateutil.parser import isoparse

from ..types import UNSET, Unset

T = TypeVar("T", bound="UserInfoTokenItem")


@_attrs_define
class UserInfoTokenItem:
    access_token: str
    created_by: Union[None, Unset, str] = UNSET
    scope: Union[None, Unset, str] = UNSET
    created_at: Union[None, Unset, datetime.datetime] = UNSET
    expires_in_minutes: Union[None, Unset, int] = UNSET
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        field_dict = {"access_token": self.access_token, **self.additional_properties}
        for key in ("created_by", "scope", "expires_in_minutes"):
            value = getattr(self, key)
            if value is not UNSET:
                field_dict[key] = value
        if self.created_at is not UNSET:
            field_dict["created_at"] = None if self.created_at is None else self.created_at.isoformat()
        return field_dict

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        created_at = d.pop("created_at", UNSET)
        if created_at not in (UNSET, None):
            created_at = isoparse(created_at)
        item = cls(
            access_token=d.pop("access_token"),
            created_by=d.pop("created_by", UNSET),
            scope=d.pop("scope", UNSET),
            created_at=created_at,
            expires_in_minutes=d.pop("expires_in_minutes", UNSET),
        )
        item.additional_properties = d
        return item

    @property
    def additional_keys(self) -> List[str]:
        return list(self.additional_properties.keys())
