from typing import Any, Dict, List, Type, TypeVar

from attrs import define as _attrs_define
from attrs import field as _attrs_field

from ..models.user_info_token_item import UserInfoTokenItem

T = TypeVar("T", bound="UserInfoTokensResponse")


@_attrs_define
class UserInfoTokensResponse:
    tokens: List[UserInfoTokenItem]
    additional_properties: Dict[str, Any] = _attrs_field(init=False, factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        return {"tokens": [item.to_dict() for item in self.tokens], **self.additional_properties}

    @classmethod
    def from_dict(cls: Type[T], src_dict: Dict[str, Any]) -> T:
        d = src_dict.copy()
        item = cls(tokens=[UserInfoTokenItem.from_dict(x) for x in d.pop("tokens", [])])
        item.additional_properties = d
        return item
