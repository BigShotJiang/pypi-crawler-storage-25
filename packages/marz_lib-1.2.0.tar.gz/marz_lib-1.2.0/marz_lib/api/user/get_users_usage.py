from http import HTTPStatus
from typing import Any, Dict, List, Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.users_usages_response import UsersUsagesResponse
from ...types import UNSET, Response, Unset


def _get_kwargs(*, start: Union[Unset, str] = UNSET, end: Union[Unset, str] = UNSET, admin: Union[Unset, List[str]] = UNSET) -> Dict[str, Any]:
    params: Dict[str, Any] = {}
    if start is not UNSET:
        params["start"] = start
    if end is not UNSET:
        params["end"] = end
    if admin is not UNSET:
        params["admin"] = admin
    return {"method": "get", "url": "/api/users/usage", "params": params}


def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[UsersUsagesResponse]:
    if response.status_code == HTTPStatus.OK:
        return UsersUsagesResponse.from_dict(response.json())
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[UsersUsagesResponse]:
    return Response(status_code=HTTPStatus(response.status_code), content=response.content, headers=response.headers, parsed=_parse_response(client=client, response=response))


def sync_detailed(*, client: AuthenticatedClient, start: Union[Unset, str] = UNSET, end: Union[Unset, str] = UNSET, admin: Union[Unset, List[str]] = UNSET) -> Response[UsersUsagesResponse]:
    response = client.get_httpx_client().request(**_get_kwargs(start=start, end=end, admin=admin))
    return _build_response(client=client, response=response)


def sync(*, client: AuthenticatedClient, start: Union[Unset, str] = UNSET, end: Union[Unset, str] = UNSET, admin: Union[Unset, List[str]] = UNSET) -> Optional[UsersUsagesResponse]:
    return sync_detailed(client=client, start=start, end=end, admin=admin).parsed


async def asyncio_detailed(*, client: AuthenticatedClient, start: Union[Unset, str] = UNSET, end: Union[Unset, str] = UNSET, admin: Union[Unset, List[str]] = UNSET) -> Response[UsersUsagesResponse]:
    response = await client.get_async_httpx_client().request(**_get_kwargs(start=start, end=end, admin=admin))
    return _build_response(client=client, response=response)


async def asyncio(*, client: AuthenticatedClient, start: Union[Unset, str] = UNSET, end: Union[Unset, str] = UNSET, admin: Union[Unset, List[str]] = UNSET) -> Optional[UsersUsagesResponse]:
    return (await asyncio_detailed(client=client, start=start, end=end, admin=admin)).parsed
