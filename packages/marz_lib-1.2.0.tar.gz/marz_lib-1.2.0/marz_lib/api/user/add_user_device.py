from http import HTTPStatus
from typing import Any, Dict, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.user_device_create import UserDeviceCreate
from ...models.user_device_response import UserDeviceResponse
from ...types import Response


def _get_kwargs(username: str, *, body: UserDeviceCreate) -> Dict[str, Any]:
    return {"method": "post", "url": f"/api/user/{username}/devices", "json": body.to_dict()}


def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[Union[Any, HTTPValidationError, UserDeviceResponse]]:
    if response.status_code == HTTPStatus.OK:
        return UserDeviceResponse.from_dict(response.json())
    if response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
        return HTTPValidationError.from_dict(response.json())
    if response.status_code in (HTTPStatus.BAD_REQUEST, HTTPStatus.NOT_FOUND, HTTPStatus.FORBIDDEN, HTTPStatus.CONFLICT):
        return cast(Any, None)
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Union[Any, HTTPValidationError, UserDeviceResponse]]:
    return Response(status_code=HTTPStatus(response.status_code), content=response.content, headers=response.headers, parsed=_parse_response(client=client, response=response))


def sync_detailed(username: str, *, client: AuthenticatedClient, body: UserDeviceCreate) -> Response[Union[Any, HTTPValidationError, UserDeviceResponse]]:
    response = client.get_httpx_client().request(**_get_kwargs(username, body=body))
    return _build_response(client=client, response=response)


def sync(username: str, *, client: AuthenticatedClient, body: UserDeviceCreate) -> Optional[Union[Any, HTTPValidationError, UserDeviceResponse]]:
    return sync_detailed(username, client=client, body=body).parsed


async def asyncio_detailed(username: str, *, client: AuthenticatedClient, body: UserDeviceCreate) -> Response[Union[Any, HTTPValidationError, UserDeviceResponse]]:
    response = await client.get_async_httpx_client().request(**_get_kwargs(username, body=body))
    return _build_response(client=client, response=response)


async def asyncio(username: str, *, client: AuthenticatedClient, body: UserDeviceCreate) -> Optional[Union[Any, HTTPValidationError, UserDeviceResponse]]:
    return (await asyncio_detailed(username, client=client, body=body)).parsed
