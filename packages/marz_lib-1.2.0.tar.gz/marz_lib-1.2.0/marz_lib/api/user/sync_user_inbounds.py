from http import HTTPStatus
from typing import Any, Dict, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...models.sync_inbounds_request import SyncInboundsRequest
from ...types import Response


def _get_kwargs(*, body: SyncInboundsRequest) -> Dict[str, Any]:
    return {
        "method": "post",
        "url": "/api/users/sync-inbounds",
        "json": body.to_dict(),
    }


def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[Union[Any, HTTPValidationError, Dict[str, Any]]]:
    if response.status_code == HTTPStatus.OK:
        return cast(Dict[str, Any], response.json())
    if response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
        response_422 = HTTPValidationError.from_dict(response.json())
        return response_422
    if response.status_code == HTTPStatus.FORBIDDEN:
        return cast(Any, None)
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Union[Any, HTTPValidationError, Dict[str, Any]]]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(*, client: AuthenticatedClient, body: SyncInboundsRequest) -> Response[Union[Any, HTTPValidationError, Dict[str, Any]]]:
    kwargs = _get_kwargs(body=body)
    response = client.get_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)


def sync(*, client: AuthenticatedClient, body: SyncInboundsRequest) -> Optional[Union[Any, HTTPValidationError, Dict[str, Any]]]:
    return sync_detailed(client=client, body=body).parsed


async def asyncio_detailed(*, client: AuthenticatedClient, body: SyncInboundsRequest) -> Response[Union[Any, HTTPValidationError, Dict[str, Any]]]:
    kwargs = _get_kwargs(body=body)
    response = await client.get_async_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)


async def asyncio(*, client: AuthenticatedClient, body: SyncInboundsRequest) -> Optional[Union[Any, HTTPValidationError, Dict[str, Any]]]:
    return (await asyncio_detailed(client=client, body=body)).parsed
