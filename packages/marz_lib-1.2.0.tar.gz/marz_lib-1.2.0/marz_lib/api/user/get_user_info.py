from http import HTTPStatus
from typing import Any, Dict, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...types import Response
from ...models.user_response import UserResponse


def _get_kwargs(username: str) -> Dict[str, Any]:
    _kwargs: Dict[str, Any] = {
        "method": "get",
        "url": f"/api/user-info/{username}",
    }

    return _kwargs


def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[Union[Any, HTTPValidationError, UserResponse]]:
    if response.status_code == HTTPStatus.OK:
        response_200 = UserResponse.from_dict(response.json())
        return response_200
    if response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
        response_422 = HTTPValidationError.from_dict(response.json())
        return response_422
    if response.status_code in (HTTPStatus.UNAUTHORIZED, HTTPStatus.NOT_FOUND):
        return cast(Any, None)
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Union[Any, HTTPValidationError, UserResponse]]:
    return Response(status_code=HTTPStatus(response.status_code), content=response.content, headers=response.headers, parsed=_parse_response(client=client, response=response))


def sync_detailed(username: str, *, client: AuthenticatedClient) -> Response[Union[Any, HTTPValidationError, UserResponse]]:
    kwargs = _get_kwargs(username=username)
    response = client.get_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)


def sync(username: str, *, client: AuthenticatedClient) -> Optional[Union[Any, HTTPValidationError, UserResponse]]:
    return sync_detailed(username=username, client=client).parsed


async def asyncio_detailed(username: str, *, client: AuthenticatedClient) -> Response[Union[Any, HTTPValidationError, UserResponse]]:
    kwargs = _get_kwargs(username=username)
    response = await client.get_async_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)


async def asyncio(username: str, *, client: AuthenticatedClient) -> Optional[Union[Any, HTTPValidationError, UserResponse]]:
    return (await asyncio_detailed(username=username, client=client)).parsed
