from http import HTTPStatus
from typing import Any, Dict, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import UNSET, Response, Unset


def _get_kwargs(*, op_id: Union[Unset, None, str] = UNSET) -> Dict[str, Any]:
    params: Dict[str, Any] = {}
    if op_id is not UNSET and op_id is not None:
        params["op_id"] = op_id
    return {"method": "get", "url": "/api/users/sync-inbounds/status", "params": params}


def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[Dict[str, Any]]:
    if response.status_code == HTTPStatus.OK:
        return cast(Dict[str, Any], response.json())
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Dict[str, Any]]:
    return Response(status_code=HTTPStatus(response.status_code), content=response.content, headers=response.headers, parsed=_parse_response(client=client, response=response))


def sync_detailed(*, client: AuthenticatedClient, op_id: Union[Unset, None, str] = UNSET) -> Response[Dict[str, Any]]:
    response = client.get_httpx_client().request(**_get_kwargs(op_id=op_id))
    return _build_response(client=client, response=response)


def sync(*, client: AuthenticatedClient, op_id: Union[Unset, None, str] = UNSET) -> Optional[Dict[str, Any]]:
    return sync_detailed(client=client, op_id=op_id).parsed


async def asyncio_detailed(*, client: AuthenticatedClient, op_id: Union[Unset, None, str] = UNSET) -> Response[Dict[str, Any]]:
    response = await client.get_async_httpx_client().request(**_get_kwargs(op_id=op_id))
    return _build_response(client=client, response=response)


async def asyncio(*, client: AuthenticatedClient, op_id: Union[Unset, None, str] = UNSET) -> Optional[Dict[str, Any]]:
    return (await asyncio_detailed(client=client, op_id=op_id)).parsed
