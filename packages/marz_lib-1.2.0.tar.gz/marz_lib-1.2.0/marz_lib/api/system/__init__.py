from .get_project_settings import asyncio as get_project_settings_async, sync as get_project_settings
from .update_project_settings import asyncio as update_project_settings_async, sync as update_project_settings
