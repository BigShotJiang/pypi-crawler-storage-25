from http import HTTPStatus
from typing import Any, Dict, Optional, Union, cast

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.http_validation_error import HTTPValidationError
from ...types import Response
from ...models.project_settings import ProjectSettings


def _get_kwargs(*, body: ProjectSettings) -> Dict[str, Any]:
    _kwargs: Dict[str, Any] = {
        "method": "put",
        "url": f"/api/system/project-settings",
    }
    _kwargs["json"] = body.to_dict()

    return _kwargs


def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[Union[HTTPValidationError, ProjectSettings]]:
    if response.status_code == HTTPStatus.OK:
        response_200 = ProjectSettings.from_dict(response.json())
        return response_200
    if response.status_code == HTTPStatus.UNPROCESSABLE_ENTITY:
        response_422 = HTTPValidationError.from_dict(response.json())
        return response_422
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[Union[HTTPValidationError, ProjectSettings]]:
    return Response(status_code=HTTPStatus(response.status_code), content=response.content, headers=response.headers, parsed=_parse_response(client=client, response=response))


def sync_detailed(*, client: AuthenticatedClient, body: ProjectSettings) -> Response[Union[HTTPValidationError, ProjectSettings]]:
    kwargs = _get_kwargs(body=body)
    response = client.get_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)


def sync(*, client: AuthenticatedClient, body: ProjectSettings) -> Optional[Union[HTTPValidationError, ProjectSettings]]:
    return sync_detailed(body=body, client=client).parsed


async def asyncio_detailed(*, client: AuthenticatedClient, body: ProjectSettings) -> Response[Union[HTTPValidationError, ProjectSettings]]:
    kwargs = _get_kwargs(body=body)
    response = await client.get_async_httpx_client().request(**kwargs)
    return _build_response(client=client, response=response)


async def asyncio(*, client: AuthenticatedClient, body: ProjectSettings) -> Optional[Union[HTTPValidationError, ProjectSettings]]:
    return (await asyncio_detailed(body=body, client=client)).parsed
