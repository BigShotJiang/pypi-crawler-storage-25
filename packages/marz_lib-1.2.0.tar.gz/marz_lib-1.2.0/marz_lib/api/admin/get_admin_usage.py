from http import HTTPStatus
from typing import Optional, Union

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...types import Response


def _get_kwargs(username: str):
    return {"method": "get", "url": f"/api/admin/usage/{username}"}


def _parse_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Optional[int]:
    if response.status_code == HTTPStatus.OK:
        return int(response.json())
    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    return None


def _build_response(*, client: Union[AuthenticatedClient, Client], response: httpx.Response) -> Response[int]:
    return Response(status_code=HTTPStatus(response.status_code), content=response.content, headers=response.headers, parsed=_parse_response(client=client, response=response))


def sync_detailed(username: str, *, client: AuthenticatedClient) -> Response[int]:
    response = client.get_httpx_client().request(**_get_kwargs(username))
    return _build_response(client=client, response=response)


def sync(username: str, *, client: AuthenticatedClient) -> Optional[int]:
    return sync_detailed(username, client=client).parsed


async def asyncio_detailed(username: str, *, client: AuthenticatedClient) -> Response[int]:
    response = await client.get_async_httpx_client().request(**_get_kwargs(username))
    return _build_response(client=client, response=response)


async def asyncio(username: str, *, client: AuthenticatedClient) -> Optional[int]:
    return (await asyncio_detailed(username, client=client)).parsed
