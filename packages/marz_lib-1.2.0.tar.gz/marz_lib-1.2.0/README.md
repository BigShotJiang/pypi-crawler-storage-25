# marz-lib

Python client library for the current Marzban API. Package name: `marz-lib`.

## Requirements

- Python 3.8+
- `pip`
- recommended: isolated virtualenv

## Install dependencies

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install --upgrade pip
python -m pip install build
```

If you want to work with the package locally:

```bash
python -m pip install -e .
```

## Build the library

This project uses `pyproject.toml` with `poetry-core` as the build backend.

Build both `sdist` and `wheel`:

```bash
python -m build
```

Build artifacts will appear in:

```bash
dist/
```

Typical output:

- `dist/marz_lib-<version>.tar.gz`
- `dist/marz_lib-<version>-py3-none-any.whl`

## Install the built wheel

```bash
python -m pip install dist/*.whl
```

## Rebuild from scratch

```bash
rm -rf build dist *.egg-info
python -m build
```

## Quick validation

You can validate the package modules with:

```bash
python -m py_compile marz_lib/__init__.py
```

Or install the wheel into a fresh virtualenv and import it:

```bash
python - <<'PY'
import marz_lib
print('ok')
PY
```

## Notes

- The package metadata is defined in `pyproject.toml`.
- `setup.py` is not required for this project.
- If you need to publish to PyPI, build first and then upload `dist/*` with `twine`.
