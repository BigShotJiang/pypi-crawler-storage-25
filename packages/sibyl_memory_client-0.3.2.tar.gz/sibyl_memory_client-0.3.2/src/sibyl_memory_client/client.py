"""MemoryClient: the public API for sibyl-memory-client.

Polymorphic constructor: open by local path OR by hosted-tier URL (v2+, not
implemented yet). The local-first plugin v1 only uses the local path.

The API surface mirrors the canonical sibyl_memory.* table shape so callers
can move between local-SQLite-backed and Postgres-backed clients without
re-learning the model.
"""
from __future__ import annotations

import sqlite3
from pathlib import Path
from typing import Any, Iterable

from .exceptions import ConflictError, NotFoundError, TenantError, ValidationError
from .storage import Storage, dumps, loads, new_id, _utc_now_iso

# The default tenant for single-user local installs.
DEFAULT_TENANT = "00000000-0000-0000-0000-000000000001"


def _check_json(payload: Any, field: str = "body") -> str:
    """Validate that payload is JSON-serializable, return the encoded string."""
    try:
        return dumps(payload)
    except (TypeError, ValueError) as e:
        raise ValidationError(
            f"{field} is not JSON-serializable: {e}",
            recovery=f"Pass a dict, list, or JSON primitive as {field}.",
        ) from e


class MemoryClient:
    """Single canonical interface for reading and writing Sibyl Memory state."""

    # Paid-tier-only features. Free tier raises TierGateError; upgrading to any
    # paid tier unlocks both self-learning and the memory linter.
    _PAID_ONLY_TIERS = frozenset({"sync", "team", "lifetime", "stake", "enterprise"})

    def __init__(
        self,
        storage: Storage,
        *,
        tenant_id: str = DEFAULT_TENANT,
        tier: str = "free",
        account_id: str | None = None,
        session_token: str | None = None,
        cap_gate: Any = None,
        credentials_claim: dict[str, Any] | None = None,
        credentials_signature: str | None = None,
    ) -> None:
        self._storage = storage
        self._tenant_id = tenant_id
        self._tier = tier
        self._account_id = account_id
        self._session_token = session_token

        # Cap gate — enforces the 2 MB free-tier cap with server-authoritative
        # tier verification at the boundary. See _capcheck.py for the design.
        if cap_gate is None:
            from ._capcheck import CapGate, TierCache
            cap_gate = CapGate(
                account_id=account_id,
                session_token=session_token,
                db_size_fn=lambda: (
                    Path(storage.db_path).stat().st_size
                    if Path(storage.db_path).exists() else 0
                ),
                local_tier_hint=tier,
                cache=TierCache(
                    Path(storage.db_path).parent / "tier_cache.json"
                ),
                credentials_claim=credentials_claim,
                credentials_signature=credentials_signature,
            )
        self._cap_gate = cap_gate

    # ------------------------------------------------------------------
    # Constructors
    # ------------------------------------------------------------------
    @classmethod
    def local(
        cls,
        path: str | Path = "~/.sibyl-memory/memory.db",
        *,
        tenant_id: str = DEFAULT_TENANT,
        tier: str = "free",
        account_id: str | None = None,
        session_token: str | None = None,
        credentials_claim: dict[str, Any] | None = None,
        credentials_signature: str | None = None,
    ) -> "MemoryClient":
        """Open a local SQLite-backed MemoryClient.

        The directory at ``path``'s parent is created with mode 0700 if
        missing. The schema is applied on first open and is idempotent.

        Set ``tier`` to the user's plugin tier so paid-only features
        (self-learning + memory linter) gate correctly. Defaults to "free".

        Pass ``account_id`` and ``session_token`` from credentials.json so
        the SDK can verify the user's tier against the server when they
        approach the 2 MB free-tier cap. Without these, the SDK enforces
        a strict local 2 MB cap (no server check possible).
        """
        storage = Storage(path)
        return cls(
            storage,
            tenant_id=tenant_id,
            tier=tier,
            account_id=account_id,
            session_token=session_token,
            credentials_claim=credentials_claim,
            credentials_signature=credentials_signature,
        )

    # ------------------------------------------------------------------
    # Tenant management
    # ------------------------------------------------------------------
    def get_tenant(self) -> str:
        return self._tenant_id

    def set_tenant(self, tenant_id: str) -> None:
        if not tenant_id or not isinstance(tenant_id, str):
            raise TenantError("tenant_id must be a non-empty string")
        self._tenant_id = tenant_id

    @property
    def storage(self) -> Storage:
        return self._storage

    def schema_version(self) -> int | None:
        return self._storage.schema_version()

    # ------------------------------------------------------------------
    # Tier (paid-tier-only feature gating)
    # ------------------------------------------------------------------
    def get_tier(self) -> str:
        return self._tier

    def set_tier(self, tier: str) -> None:
        """Update the user's tier. Called by the credentials loader when
        the activation flow returns a tier upgrade."""
        if not isinstance(tier, str) or not tier:
            raise ValidationError("tier must be a non-empty string")
        self._tier = tier

    def _require_paid_tier(self, feature: str) -> None:
        """Raise TierGateError if the current tier is not paid-tier."""
        from .exceptions import TierGateError
        if self._tier not in self._PAID_ONLY_TIERS:
            raise TierGateError(
                f"{feature} requires a paid tier. Current tier: {self._tier!r}.",
                feature=feature,
                current_tier=self._tier,
            )

    # ------------------------------------------------------------------
    # Entities (WARM tier) — single source of truth per rule 43
    # ------------------------------------------------------------------
    def set_entity(
        self,
        category: str,
        name: str,
        body: dict[str, Any] | list[Any],
        *,
        status: str | None = None,
    ) -> dict[str, Any]:
        """Insert or update an entity.

        UNIQUE (tenant_id, category, name) is enforced at the DB level. On
        conflict the existing row is updated (body + status + updated_at).
        Returns the resulting entity row as a dict.

        Subject to the 2 MB free-tier cap when tier='free'. Raises
        CapExceededError if the write would push the local DB past the cap
        and the server-authoritative tier check confirms the account is
        still free."""
        body_json = _check_json(body)
        # Cap gate — rough byte estimate (FTS5 + indexes add overhead)
        self._cap_gate.check(proposed_delta_bytes=len(body_json) + len(name) + len(category) + 200)
        with self._storage.transaction() as conn:
            existing = conn.execute(
                "SELECT id FROM entities WHERE tenant_id = ? AND category = ? AND name = ?",
                (self._tenant_id, category, name),
            ).fetchone()
            if existing is None:
                ent_id = new_id()
                conn.execute(
                    "INSERT INTO entities (id, tenant_id, category, name, status, body) "
                    "VALUES (?, ?, ?, ?, ?, ?)",
                    (ent_id, self._tenant_id, category, name, status, body_json),
                )
            else:
                ent_id = existing["id"]
                conn.execute(
                    "UPDATE entities SET status = ?, body = ?, "
                    "updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now') "
                    "WHERE id = ?",
                    (status, body_json, ent_id),
                )
        return self.get_entity(category, name)

    def get_entity(self, category: str, name: str) -> dict[str, Any]:
        with self._storage.connection() as conn:
            row = conn.execute(
                "SELECT id, tenant_id, category, name, status, body, created_at, updated_at "
                "FROM entities WHERE tenant_id = ? AND category = ? AND name = ?",
                (self._tenant_id, category, name),
            ).fetchone()
        if row is None:
            raise NotFoundError(f"entity {category}/{name} not found for tenant {self._tenant_id}")
        return self._row_to_entity(row)

    def list_entities(
        self,
        category: str | None = None,
        *,
        status: str | None = None,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        sql = "SELECT id, tenant_id, category, name, status, body, created_at, updated_at FROM entities WHERE tenant_id = ?"
        params: list[Any] = [self._tenant_id]
        if category is not None:
            sql += " AND category = ?"
            params.append(category)
        if status is not None:
            sql += " AND status = ?"
            params.append(status)
        sql += " ORDER BY updated_at DESC LIMIT ?"
        params.append(limit)
        with self._storage.connection() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [self._row_to_entity(r) for r in rows]

    def delete_entity(self, category: str, name: str) -> bool:
        with self._storage.transaction() as conn:
            cur = conn.execute(
                "DELETE FROM entities WHERE tenant_id = ? AND category = ? AND name = ?",
                (self._tenant_id, category, name),
            )
        return cur.rowcount > 0

    # ------------------------------------------------------------------
    # State documents (HOT tier)
    # ------------------------------------------------------------------
    def set_state(self, key: str, body: dict[str, Any] | list[Any]) -> None:
        body_json = _check_json(body)
        self._cap_gate.check(proposed_delta_bytes=len(body_json) + len(key) + 150)
        with self._storage.transaction() as conn:
            conn.execute(
                "INSERT INTO state_documents (tenant_id, document_key, body) VALUES (?, ?, ?) "
                "ON CONFLICT(tenant_id, document_key) DO UPDATE SET body = excluded.body, "
                "updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')",
                (self._tenant_id, key, body_json),
            )

    def get_state(self, key: str) -> dict[str, Any] | None:
        with self._storage.connection() as conn:
            row = conn.execute(
                "SELECT body, updated_at FROM state_documents WHERE tenant_id = ? AND document_key = ?",
                (self._tenant_id, key),
            ).fetchone()
        if row is None:
            return None
        return {"body": loads(row["body"]), "updated_at": row["updated_at"]}

    # ------------------------------------------------------------------
    # Journal (COLD tier) — append-only event log
    # ------------------------------------------------------------------
    def write_event(
        self,
        *,
        evaluated: Any = None,
        acted: Any = None,
        forward: Any = None,
        extra: Any = None,
        ts: str | None = None,
    ) -> str:
        # Estimate byte cost from each non-None payload
        delta = 200  # row + index overhead
        for payload in (evaluated, acted, forward, extra):
            if payload is not None:
                try:
                    delta += len(dumps(payload))
                except (TypeError, ValueError):
                    delta += 100  # estimate; the JSON check below will catch real failures
        self._cap_gate.check(proposed_delta_bytes=delta)
        ev_id = new_id()
        with self._storage.transaction() as conn:
            conn.execute(
                "INSERT INTO journal_events (id, tenant_id, ts, evaluated, acted, forward, extra) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (
                    ev_id,
                    self._tenant_id,
                    ts or _utc_now_iso(),
                    _check_json(evaluated, "evaluated") if evaluated is not None else None,
                    _check_json(acted, "acted") if acted is not None else None,
                    _check_json(forward, "forward") if forward is not None else None,
                    _check_json(extra, "extra") if extra is not None else None,
                ),
            )
        return ev_id

    def read_events(
        self,
        *,
        limit: int = 50,
        since: str | None = None,
        until: str | None = None,
    ) -> list[dict[str, Any]]:
        sql = "SELECT id, tenant_id, ts, evaluated, acted, forward, extra FROM journal_events WHERE tenant_id = ?"
        params: list[Any] = [self._tenant_id]
        if since is not None:
            sql += " AND ts >= ?"
            params.append(since)
        if until is not None:
            sql += " AND ts <= ?"
            params.append(until)
        sql += " ORDER BY ts DESC, id DESC LIMIT ?"
        params.append(limit)
        with self._storage.connection() as conn:
            rows = conn.execute(sql, params).fetchall()
        return [
            {
                "id": r["id"],
                "ts": r["ts"],
                "evaluated": loads(r["evaluated"]),
                "acted": loads(r["acted"]),
                "forward": loads(r["forward"]),
                "extra": loads(r["extra"]),
            }
            for r in rows
        ]

    # ------------------------------------------------------------------
    # Reference (REFERENCE tier) — static lookup documents
    # ------------------------------------------------------------------
    def set_reference(
        self,
        key: str,
        body: str,
        *,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        meta_json = _check_json(metadata, "metadata") if metadata is not None else None
        delta = len(body) + len(key) + (len(meta_json) if meta_json else 0) + 200
        self._cap_gate.check(proposed_delta_bytes=delta)
        with self._storage.transaction() as conn:
            conn.execute(
                "INSERT INTO reference_documents (tenant_id, doc_key, body, metadata) VALUES (?, ?, ?, ?) "
                "ON CONFLICT(tenant_id, doc_key) DO UPDATE SET body = excluded.body, "
                "metadata = excluded.metadata, updated_at = strftime('%Y-%m-%dT%H:%M:%fZ', 'now')",
                (self._tenant_id, key, body, meta_json),
            )

    def get_reference(self, key: str) -> dict[str, Any] | None:
        with self._storage.connection() as conn:
            row = conn.execute(
                "SELECT body, metadata, updated_at FROM reference_documents WHERE tenant_id = ? AND doc_key = ?",
                (self._tenant_id, key),
            ).fetchone()
        if row is None:
            return None
        return {"body": row["body"], "metadata": loads(row["metadata"]), "updated_at": row["updated_at"]}

    # ------------------------------------------------------------------
    # Archive
    # ------------------------------------------------------------------
    def archive_entity(self, category: str, name: str, reason: str | None = None) -> dict[str, Any]:
        """Move an entity to the archive table and delete from the active set.

        T1-3 fix: previously this bypassed the cap-gate. A free user at
        1.9 MB could archive their largest entities (body copied into
        archived_entities, doubling footprint temporarily before the
        DELETE lands) to keep writing past the 2 MB cap. Now gated on
        the size of the body being copied + 200 bytes overhead. Reads
        the body first so we know the actual delta. NotFoundError still
        raised before any cap-gate work.
        """
        # Read the row first so we can size the archive insert. NotFoundError
        # propagates as before — no cap-gate side effect for missing entities.
        with self._storage.connection() as conn:
            preview = conn.execute(
                "SELECT id, body FROM entities WHERE tenant_id = ? AND category = ? AND name = ?",
                (self._tenant_id, category, name),
            ).fetchone()
        if preview is None:
            raise NotFoundError(f"entity {category}/{name} not found")
        body_bytes = len(preview["body"] or "") if preview["body"] else 0
        # The archive insert copies the body. Delta = body + name + category
        # + reason + ~200B SQLite/row overhead. Conservative estimate.
        delta = body_bytes + len(name) + len(category) + len(reason or "") + 200
        self._cap_gate.check(proposed_delta_bytes=delta)

        with self._storage.transaction() as conn:
            row = conn.execute(
                "SELECT id, body FROM entities WHERE tenant_id = ? AND category = ? AND name = ?",
                (self._tenant_id, category, name),
            ).fetchone()
            if row is None:
                raise NotFoundError(f"entity {category}/{name} not found")
            arch_id = new_id()
            conn.execute(
                "INSERT INTO archived_entities (id, tenant_id, original_entity_id, category, name, body, archive_reason) "
                "VALUES (?, ?, ?, ?, ?, ?, ?)",
                (arch_id, self._tenant_id, row["id"], category, name, row["body"], reason),
            )
            conn.execute("DELETE FROM entities WHERE id = ?", (row["id"],))
        return {"archived_id": arch_id, "original_id": row["id"]}

    # ------------------------------------------------------------------
    # Self-learning + lint (v0.2.0) — paid-tier only
    # ------------------------------------------------------------------
    # Both convenience entrypoints below gate on tier and raise
    # TierGateError for free-tier callers. The underlying Learner / Linter
    # classes remain available for power users via direct import, but
    # the documented surface is the gated convenience API.

    def learner(self, **kwargs: Any):
        """Return a Learner bound to this client's storage + tenant.

        Paid-tier only. Lazy import so the lower SDK stays usable without
        loading the learning module. Threads the client's CapGate into
        the Learner so accept_proposal calls go through the cap-check
        (T1-3 fix). Callers can override cap_gate=None explicitly to
        opt out for tests."""
        self._require_paid_tier("self-learning")
        from .learning import Learner
        kwargs.setdefault("cap_gate", self._cap_gate)
        return Learner(self._storage, tenant_id=self._tenant_id, **kwargs)

    def learn(self, **kwargs: Any):
        """Convenience: construct a default Learner and run one pass.
        Returns a LearningRunReport. Paid-tier only."""
        return self.learner(**kwargs).run()

    def list_skill_proposals(
        self, *, status: str = "pending", limit: int = 50,
    ) -> list[Any]:
        """Paid-tier only."""
        return self.learner().list_proposals(status=status, limit=limit)

    def accept_skill_proposal(
        self, proposal_id: str, *, note: str | None = None,
    ) -> dict[str, Any]:
        """Paid-tier only."""
        return self.learner().accept_proposal(proposal_id, note=note)

    def reject_skill_proposal(
        self, proposal_id: str, *, note: str | None = None,
    ) -> dict[str, Any]:
        """Paid-tier only."""
        return self.learner().reject_proposal(proposal_id, note=note)

    def lint(self, **kwargs: Any):
        """Run the local memory linter against this tenant. Returns a
        LintReport with `.findings`, `.counts`, `.ok`, and `.to_ascii()`.

        Paid-tier only. Free-tier callers raise TierGateError pointing at
        the upgrade page.
        """
        self._require_paid_tier("memory linter")
        from .lint import Linter
        # If the caller didn't supply soft_cap_bytes, look up by tier
        if "soft_cap_bytes" not in kwargs:
            from .lint import TIER_SOFT_CAPS, DEFAULT_SOFT_CAP_BYTES
            cap = TIER_SOFT_CAPS.get(self._tier, DEFAULT_SOFT_CAP_BYTES)
            # Paid tiers map to None — pass a huge cap so the check effectively never fires
            kwargs["soft_cap_bytes"] = cap if cap is not None else (1 << 62)
        return Linter(self._storage, tenant_id=self._tenant_id, **kwargs).run()

    # ------------------------------------------------------------------
    # Free-tier read access (no gating) — visibility into the upgrade pressure
    # ------------------------------------------------------------------
    def free_tier_status(self) -> dict[str, Any]:
        """Return current free-tier state: DB size, soft cap, % used.

        Always available regardless of tier — free-tier callers use this
        to render the "you're at X% of your free cap" upgrade prompt
        without needing to call the (gated) linter.
        """
        from .lint import TIER_SOFT_CAPS, DEFAULT_SOFT_CAP_BYTES
        from pathlib import Path
        db_size = Path(self._storage.db_path).stat().st_size if Path(self._storage.db_path).exists() else 0
        cap = TIER_SOFT_CAPS.get(self._tier, DEFAULT_SOFT_CAP_BYTES)
        # Paid tier → no cap
        if cap is None:
            return {
                "tier": self._tier,
                "db_size_bytes": db_size,
                "soft_cap_bytes": None,
                "pct_used": None,
                "uncapped": True,
            }
        return {
            "tier": self._tier,
            "db_size_bytes": db_size,
            "soft_cap_bytes": cap,
            "pct_used": db_size / cap if cap else None,
            "uncapped": False,
            "at_or_above_warning": db_size >= 0.8 * cap,
            "at_or_above_cap": db_size >= cap,
            "upgrade_url": "https://sibyllabs.org/plugin#tier",
        }

    # ------------------------------------------------------------------
    # FTS5 search
    # ------------------------------------------------------------------
    def search_entities(self, query: str, *, limit: int = 20) -> list[dict[str, Any]]:
        """Full-text search over entity name + category + body via FTS5."""
        with self._storage.connection() as conn:
            rows = conn.execute(
                "SELECT e.id, e.tenant_id, e.category, e.name, e.status, e.body, e.created_at, e.updated_at "
                "FROM entities_fts f "
                "JOIN entities e ON e.id = f.entity_id "
                "WHERE entities_fts MATCH ? AND f.tenant_id = ? "
                "ORDER BY rank LIMIT ?",
                (query, self._tenant_id, limit),
            ).fetchall()
        return [self._row_to_entity(r) for r in rows]

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    def _row_to_entity(self, row: sqlite3.Row) -> dict[str, Any]:
        return {
            "id": row["id"],
            "tenant_id": row["tenant_id"],
            "category": row["category"],
            "name": row["name"],
            "status": row["status"],
            "body": loads(row["body"]),
            "created_at": row["created_at"],
            "updated_at": row["updated_at"],
        }
