from http import HTTPStatus
from typing import Any, cast
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.errors_list import ErrorsList
from ...types import Response


def _get_kwargs(
    heartbeat_id: str,
) -> dict[str, Any]:

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/heartbeats/{heartbeat_id}/ping".format(
            heartbeat_id=quote(str(heartbeat_id), safe=""),
        ),
    }

    return _kwargs


def _parse_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Any | ErrorsList | None:
    if response.status_code == 204:
        response_204 = cast(Any, None)
        return response_204

    if response.status_code == 404:
        response_404 = ErrorsList.from_dict(response.json())

        return response_404

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(*, client: AuthenticatedClient | Client, response: httpx.Response) -> Response[Any | ErrorsList]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    heartbeat_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[Any | ErrorsList]:
    """Ping a heartbeat

     Ping a specific heartbeat by id

    Args:
        heartbeat_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ErrorsList]
    """

    kwargs = _get_kwargs(
        heartbeat_id=heartbeat_id,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    heartbeat_id: str,
    *,
    client: AuthenticatedClient,
) -> Any | ErrorsList | None:
    """Ping a heartbeat

     Ping a specific heartbeat by id

    Args:
        heartbeat_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ErrorsList
    """

    return sync_detailed(
        heartbeat_id=heartbeat_id,
        client=client,
    ).parsed


async def asyncio_detailed(
    heartbeat_id: str,
    *,
    client: AuthenticatedClient,
) -> Response[Any | ErrorsList]:
    """Ping a heartbeat

     Ping a specific heartbeat by id

    Args:
        heartbeat_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[Any | ErrorsList]
    """

    kwargs = _get_kwargs(
        heartbeat_id=heartbeat_id,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    heartbeat_id: str,
    *,
    client: AuthenticatedClient,
) -> Any | ErrorsList | None:
    """Ping a heartbeat

     Ping a specific heartbeat by id

    Args:
        heartbeat_id (str):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Any | ErrorsList
    """

    return (
        await asyncio_detailed(
            heartbeat_id=heartbeat_id,
            client=client,
        )
    ).parsed
