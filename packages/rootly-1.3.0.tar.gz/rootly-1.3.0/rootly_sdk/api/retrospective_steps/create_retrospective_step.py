from http import HTTPStatus
from typing import Any
from urllib.parse import quote

import httpx

from ... import errors
from ...client import AuthenticatedClient, Client
from ...models.errors_list import ErrorsList
from ...models.new_retrospective_step import NewRetrospectiveStep
from ...models.retrospective_step_response import RetrospectiveStepResponse
from ...types import Response


def _get_kwargs(
    retrospective_process_id: str,
    *,
    body: NewRetrospectiveStep,
) -> dict[str, Any]:
    headers: dict[str, Any] = {}

    _kwargs: dict[str, Any] = {
        "method": "post",
        "url": "/v1/retrospective_processes/{retrospective_process_id}/retrospective_steps".format(
            retrospective_process_id=quote(str(retrospective_process_id), safe=""),
        ),
    }

    _kwargs["json"] = body.to_dict()

    headers["Content-Type"] = "application/vnd.api+json"

    _kwargs["headers"] = headers
    return _kwargs


def _parse_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> ErrorsList | RetrospectiveStepResponse | None:
    if response.status_code == 201:
        response_201 = RetrospectiveStepResponse.from_dict(response.json())

        return response_201

    if response.status_code == 401:
        response_401 = ErrorsList.from_dict(response.json())

        return response_401

    if response.status_code == 422:
        response_422 = ErrorsList.from_dict(response.json())

        return response_422

    if client.raise_on_unexpected_status:
        raise errors.UnexpectedStatus(response.status_code, response.content)
    else:
        return None


def _build_response(
    *, client: AuthenticatedClient | Client, response: httpx.Response
) -> Response[ErrorsList | RetrospectiveStepResponse]:
    return Response(
        status_code=HTTPStatus(response.status_code),
        content=response.content,
        headers=response.headers,
        parsed=_parse_response(client=client, response=response),
    )


def sync_detailed(
    retrospective_process_id: str,
    *,
    client: AuthenticatedClient,
    body: NewRetrospectiveStep,
) -> Response[ErrorsList | RetrospectiveStepResponse]:
    """Creates a retrospective step

     Creates a new retrospective step from provided data

    Args:
        retrospective_process_id (str):
        body (NewRetrospectiveStep):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorsList | RetrospectiveStepResponse]
    """

    kwargs = _get_kwargs(
        retrospective_process_id=retrospective_process_id,
        body=body,
    )

    response = client.get_httpx_client().request(
        **kwargs,
    )

    return _build_response(client=client, response=response)


def sync(
    retrospective_process_id: str,
    *,
    client: AuthenticatedClient,
    body: NewRetrospectiveStep,
) -> ErrorsList | RetrospectiveStepResponse | None:
    """Creates a retrospective step

     Creates a new retrospective step from provided data

    Args:
        retrospective_process_id (str):
        body (NewRetrospectiveStep):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorsList | RetrospectiveStepResponse
    """

    return sync_detailed(
        retrospective_process_id=retrospective_process_id,
        client=client,
        body=body,
    ).parsed


async def asyncio_detailed(
    retrospective_process_id: str,
    *,
    client: AuthenticatedClient,
    body: NewRetrospectiveStep,
) -> Response[ErrorsList | RetrospectiveStepResponse]:
    """Creates a retrospective step

     Creates a new retrospective step from provided data

    Args:
        retrospective_process_id (str):
        body (NewRetrospectiveStep):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        Response[ErrorsList | RetrospectiveStepResponse]
    """

    kwargs = _get_kwargs(
        retrospective_process_id=retrospective_process_id,
        body=body,
    )

    response = await client.get_async_httpx_client().request(**kwargs)

    return _build_response(client=client, response=response)


async def asyncio(
    retrospective_process_id: str,
    *,
    client: AuthenticatedClient,
    body: NewRetrospectiveStep,
) -> ErrorsList | RetrospectiveStepResponse | None:
    """Creates a retrospective step

     Creates a new retrospective step from provided data

    Args:
        retrospective_process_id (str):
        body (NewRetrospectiveStep):

    Raises:
        errors.UnexpectedStatus: If the server returns an undocumented status code and Client.raise_on_unexpected_status is True.
        httpx.TimeoutException: If the request takes longer than Client.timeout.

    Returns:
        ErrorsList | RetrospectiveStepResponse
    """

    return (
        await asyncio_detailed(
            retrospective_process_id=retrospective_process_id,
            client=client,
            body=body,
        )
    ).parsed
