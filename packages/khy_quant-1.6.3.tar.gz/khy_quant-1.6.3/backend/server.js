/**

 * KHY-Quant 量化交易系统 - 后端服务

 * Copyright (c) 2026 孔浩原 (Kong Haoyuan). All Rights Reserved.

 * 未经授权，禁止复制、修改或商业使用。

 */

require('dotenv').config();

const { applyEnvDefaults } = require('./src/config/env');

const { patchExpressAsync } = require('./src/utils/expressAsyncPatch');

applyEnvDefaults();

patchExpressAsync();



if (process.env.NODE_ENV === 'production') {

  console.log = () => {};

  console.debug = () => {};

}

const express = require('express');

const cors = require('cors');

const http = require('http');

const WebSocket = require('ws');

let { sequelize, initDatabase } = require('./src/config/database');

const models = require('./src/models'); // 加载所有模型

const realtimeDataService = require('./src/services/realtimeDataService');

const notificationService = require('./src/services/notificationService');

const instrumentSyncService = require('./src/services/instrumentSyncService'); // Instrument auto-sync service

const jwt = require('jsonwebtoken');

const { spawn } = require('child_process');

const fs = require('fs');

const path = require('path');

const logger = require('./src/utils/logger');

const requestLogger = require('./src/middleware/requestLogger');

const errorHandler = require('./src/middleware/errorHandler');

const auditLog = require('./src/middleware/auditLog');

const { apiLimiter, authLimiter, aiLimiter } = require('./src/middleware/rateLimit');



// 导入路由

const authRoutes = require('./src/routes/auth');

const userRoutes = require('./src/routes/user');

const strategyRoutes = require('./src/routes/strategy');

const backtestRoutes = require('./src/routes/backtest');

const marketDataRoutes = require('./src/routes/marketData');

const watchlistRoutes = require('./src/routes/watchlist');

const adminRoutes = require('./src/routes/admin');

const stockProxyRoutes = require('./src/routes/stockProxy');

const settingsRoutes = require('./src/routes/settings');

const dashboardRoutes = require('./src/routes/dashboard');

const passwordResetRoutes = require('./src/routes/passwordReset');



const tradeRoutes = require('./src/routes/trade');

const tradesRoutes = require('./src/routes/trades'); // 交易记录路由

const tradingAgentsRoutes = require('./src/routes/tradingAgents');

const aiRoutes = require('./src/routes/ai');

const announcementRoutes = require('./src/routes/announcement');

const feedbackRoutes = require('./src/routes/feedback');

const comprehensiveDataRoutes = require('./src/routes/comprehensiveData');

const marketRoutes = require('./src/routes/market'); // 市场数据路由

const replayRoutes = require('./src/routes/replay'); // 数据回放路由



const app = express();
app.set('trust proxy', 1); // 信任 Nginx 反向代理的 X-Forwarded-For 头

const server = http.createServer(app);

const wss = new WebSocket.Server({ server });

const parsedPort = Number.parseInt(process.env.PORT || '8080', 10);

const START_PORT = Number.isFinite(parsedPort) && parsedPort > 0 ? parsedPort : 8080;

const parsedPortRetry = Number.parseInt(process.env.PORT_AUTO_RETRY || '20', 10);

const MAX_PORT_RETRY = Number.isFinite(parsedPortRetry) && parsedPortRetry > 0 ? parsedPortRetry : 20;



// Server timeout: 180s to support large historical data loads

server.timeout = 180000;

server.keepAliveTimeout = 180000;

server.headersTimeout = 185000; // 略大于keepAliveTimeout



// Middleware

app.use(cors({

  origin: true,

  credentials: true

}));

app.use(express.json({ limit: '50mb' }));

app.use(express.urlencoded({ extended: true, limit: '50mb' }));

app.use((req, res, next) => {

  res.setHeader('Content-Type', 'application/json; charset=utf-8');

  next();

});



// Normalize API error payloads: keep JSON shape, avoid leaking raw error objects.

app.use((req, res, next) => {

  const originalJson = res.json.bind(res);

  res.json = (payload) => {

    if (payload && typeof payload === 'object' && payload.success === false) {

      if (payload.error && typeof payload.error !== 'string') {

        payload.error = undefined;

      }

      if (!payload.message) {

        payload.message = '请求处理失败';

      }

    }

    return originalJson(payload);

  };

  next();

});

app.use(requestLogger);

app.use(auditLog);

app.use('/api', apiLimiter);



// ============================================================
// API Route Registration (see thesis Chapter 4, Figure 5)
// Group 1: Authentication & Authorization (接入与路由层)
// ============================================================
app.use('/api/auth', authLimiter, authRoutes);

app.use('/api/users', userRoutes);

// ============================================================
// Group 2: Strategy Management (策略适配层 - Adapter Pattern)
// ============================================================
app.use('/api/strategies', strategyRoutes);

app.use('/api/strategy', strategyRoutes); // Singular alias for backward compatibility

app.use('/api/backtest', backtestRoutes);

app.use('/api/backtests', backtestRoutes); // Thesis alias (plural form, see thesis Ch.4)

app.use('/api/watchlist', watchlistRoutes);

app.use('/api/admin', adminRoutes);

app.use('/api/stock', stockProxyRoutes);

app.use('/api/settings', settingsRoutes);

app.use('/api/dashboard', dashboardRoutes);

app.use('/api/password-reset', passwordResetRoutes);



// ============================================================
// Group 3: Trading & Multi-Agent Collaboration (多智能体协同层)
// ============================================================
app.use('/api/trading', tradeRoutes);

app.use('/api/trades', tradesRoutes); // Trade history API

app.use('/api/trading-agents', tradingAgentsRoutes);

app.use('/api/ai', aiLimiter, aiRoutes);

app.use('/api/analysis', aiLimiter, aiRoutes); // Thesis alias (see thesis Ch.4, /api/analysis)

app.use('/api/announcements', announcementRoutes);

app.use('/api/feedback', feedbackRoutes);

// ============================================================
// Group 4: Data Governance (数据治理层 - 4-level fallback)
// ============================================================
app.use('/api/comprehensive', comprehensiveDataRoutes);

app.use('/api/comprehensive-data', comprehensiveDataRoutes); // Alias

app.use('/api/market', marketRoutes); // Market data via marketController

app.use('/api/replay', replayRoutes); // Data replay for historical analysis

app.use('/api/tick-backtest', require('./src/routes/tickBacktest')); // Tick-level backtest engine

app.use('/api/futures-tick', require('./src/routes/futuresTickData')); // Futures tick data from ZIP archives

app.use('/api/bank-transfer', require('./src/routes/bankTransfer')); // Bank transfer simulation

// ============================================================
// Group 5: Instrument & Cache Management
// ============================================================
app.use('/api/instruments', require('./src/routes/instruments')); // Instrument/security list

app.use('/api/favorites', require('./src/routes/favorites')); // User favorites

app.use('/api/kline-data', require('./src/routes/klineData')); // K-line OHLCV data

app.use('/api/cache', require('./src/routes/cache')); // Cache management

app.use('/api/instrument-sync', require('./src/routes/instrumentSync')); // Instrument auto-sync

// ============================================================
// Group 6: System & External Services
// ============================================================
app.use('/api/system', require('./src/routes/system')); // System info (LAN IP, etc.)

app.use('/api/webauthn', require('./src/routes/webauthn')); // Biometric authentication (WebAuthn)

app.use('/api/news', require('./src/routes/news')); // News data for NewsAnalyst agent

app.use('/api/external', require('./src/routes/external')); // External signal webhook (JWT-protected)

app.use('/api/api-keys', require('./src/routes/apiKey')); // API key management

app.use('/api/downloads', require('./src/routes/downloads')); // Package downloads (Windows/APK)



// Health check - enhanced with subsystem status

const healthHandler = async (req, res) => {

  const checks = {

    database: { ok: false, detail: 'disconnected' },

    cache: { ok: false, detail: 'unknown' },

    websocket: { ok: true, detail: `clients:${wss.clients?.size || 0}` },

    instrumentSync: { ok: true, detail: 'running' }

  };



  try {

    await sequelize.authenticate();

    checks.database = { ok: true, detail: 'connected' };

  } catch (error) {

    checks.database = { ok: false, detail: error.message };

  }



  try {

    const cacheStats = await require('./src/services/cacheService').getStats();

    const isCacheHealthy = cacheStats?.type === 'redis' || cacheStats?.type === 'memory';

    checks.cache = { ok: isCacheHealthy, detail: cacheStats?.type || 'unknown' };

  } catch (error) {

    checks.cache = { ok: false, detail: error.message };

  }



  const allOk = Object.values(checks).every((item) => item.ok);

  res.status(allOk ? 200 : 503).json({

    status: allOk ? 'ok' : 'degraded',

    timestamp: new Date().toISOString(),

    uptime: process.uptime(),

    dbMode: process.env.DB_MODE || 'unknown',

    memoryMB: Math.round(process.memoryUsage().rss / 1024 / 1024),

    checks

  });

};

app.get('/health', healthHandler);

app.get('/api/health', healthHandler);



// API 404 (JSON only)

app.use('/api/*', (req, res) => {

  res.status(404).json({

    success: false,

    message: '接口不存在',

    path: req.originalUrl

  });

});



// Global error handler

app.use(errorHandler);



// WebSocket连接处理

wss.on('connection', (ws, req) => {

  console.log('新的WebSocket连接');

  

  const subscriptions = new Set();

  let userId = null;

  let userRole = null;

  let isAuthenticated = false;



  ws.on('message', (message) => {

    try {

      const data = JSON.parse(message);

      

      // 处理认证

      if (data.type === 'auth') {

        try {

          const token = data.token;

          if (!token) {

            ws.send(JSON.stringify({

              type: 'auth_error',

              message: '缺少认证令牌'

            }));

            return;

          }



          const decoded = jwt.verify(token, process.env.JWT_SECRET);

          userId = decoded.userId;

          

          // 获取用户信息

          models.User.findByPk(userId).then(user => {

            if (user && user.status === 'active') {

              userRole = user.role;

              isAuthenticated = true;

              

              // 注册到通知服务

              notificationService.registerConnection(ws, userId, userRole);

              

              ws.send(JSON.stringify({

                type: 'auth_success',

                message: '认证成功',

                userId: userId,

                role: userRole

              }));



              console.log(`WebSocket用户认证成功: ${user.username} (${userRole})`);

            } else {

              ws.send(JSON.stringify({

                type: 'auth_error',

                message: '用户不存在或已被禁用'

              }));

            }

          }).catch(error => {

            console.error('WebSocket认证查询用户失败:', error);

            ws.send(JSON.stringify({

              type: 'auth_error',

              message: '认证失败'

            }));

          });

        } catch (error) {

          console.error('WebSocket认证失败:', error);

          ws.send(JSON.stringify({

            type: 'auth_error',

            message: '认证令牌无效'

          }));

        }

        return;

      }



      // 需要认证的操作

      if (!isAuthenticated) {

        ws.send(JSON.stringify({

          type: 'error',

          message: '请先进行认证'

        }));

        return;

      }

      

      if (data.type === 'subscribe') {

        // 订阅实时数据

        const symbol = data.symbol;

        subscriptions.add(symbol);

        realtimeDataService.subscribe(symbol, ws);

        

        ws.send(JSON.stringify({

          type: 'subscribed',

          symbol,

          message: `已订阅 ${symbol} 的实时数据`

        }));

      } else if (data.type === 'unsubscribe') {

        // 取消订阅

        const symbol = data.symbol;

        subscriptions.delete(symbol);

        realtimeDataService.unsubscribe(symbol, ws);

        

        ws.send(JSON.stringify({

          type: 'unsubscribed',

          symbol,

          message: `已取消订阅 ${symbol}`

        }));

      } else if (data.type === 'ping') {

        // 心跳检测

        ws.send(JSON.stringify({

          type: 'pong',

          timestamp: new Date().toISOString()

        }));

      } else if (data.type === 'get_stats' && userRole === 'admin') {

        // 管理员获取连接统计

        const stats = notificationService.getStats();

        ws.send(JSON.stringify({

          type: 'stats',

          data: stats

        }));

      }

    } catch (error) {

      console.error('WebSocket消息处理错误:', error);

      ws.send(JSON.stringify({

        type: 'error',

        message: error.message

      }));

    }

  });



  ws.on('close', () => {

    console.log('WebSocket连接关闭');

    // 清理所有订阅

    subscriptions.forEach(symbol => {

      realtimeDataService.unsubscribe(symbol, ws);

    });

    subscriptions.clear();

  });



  ws.on('error', (error) => {

    console.error('WebSocket错误:', error);

  });



  // 发送欢迎消息

  ws.send(JSON.stringify({

    type: 'connected',

    message: '已连接到实时服务，请进行认证'

  }));

});



// Auto-start PostgreSQL service (Windows only)

async function autoStartPostgreSQL() {

  return new Promise((resolve) => {

    try {

      console.log('🔍 检查 PostgreSQL 服务状态...');

      

      // 可能的 PostgreSQL 安装路径

      const possiblePaths = [

        'D:\\Program Files\\PostgreSQL\\18',

        'C:\\Program Files\\PostgreSQL\\18',

        'D:\\Program Files\\PostgreSQL\\17',

        'C:\\Program Files\\PostgreSQL\\17',

        'D:\\Program Files\\PostgreSQL\\16',

        'C:\\Program Files\\PostgreSQL\\16',

        'C:\\Program Files (x86)\\PostgreSQL\\18',

        'C:\\Program Files (x86)\\PostgreSQL\\17'

      ];

      

      let pgPath = null;

      let pgData = null;

      

      // 查找 PostgreSQL 安装路径

      for (const basePath of possiblePaths) {

        const pgCtlPath = path.join(basePath, 'bin', 'pg_ctl.exe');

        const dataPath = path.join(basePath, 'data');

        if (fs.existsSync(pgCtlPath) && fs.existsSync(dataPath)) {

          pgPath = path.join(basePath, 'bin', 'pg_ctl.exe');

          pgData = dataPath;

          console.log(`✓ 找到 PostgreSQL: ${basePath}`);

          break;

        }

      }

      

      if (!pgPath) {

        console.log('⚠️ PostgreSQL 未安装或未找到，跳过自动启动');

        resolve();

        return;

      }

      

      // 检查服务状态

      const checkProcess = spawn(pgPath, ['status', '-D', pgData], {

        stdio: ['pipe', 'pipe', 'pipe'],

        windowsHide: true

      });

      

      let checkResolved = false;

      

      checkProcess.on('exit', (code) => {

        if (checkResolved) return;

        checkResolved = true;

        

        if (code === 0) {

          console.log('✓ PostgreSQL 服务已在运行');

          resolve();

        } else {

          console.log('🚀 正在启动 PostgreSQL 服务...');

          

          // 启动 PostgreSQL

          const startProcess = spawn(pgPath, ['start', '-D', pgData], {

            stdio: ['pipe', 'pipe', 'pipe'],

            windowsHide: true

          });

          

          let startResolved = false;

          

          startProcess.on('exit', (startCode) => {

            if (startResolved) return;

            startResolved = true;

            

            if (startCode === 0) {

              console.log('✓ PostgreSQL 服务启动成功');

              // 等待服务完全启动

              setTimeout(() => resolve(), 3000);

            } else {

              console.log('⚠️ PostgreSQL 服务启动失败，但继续运行');

              resolve();

            }

          });

          

          startProcess.on('error', (error) => {

            if (!startResolved) {

              console.error('PostgreSQL 启动错误:', error.message);

              startResolved = true;

              resolve();

            }

          });

          

          // 30秒超时

          setTimeout(() => {

            if (!startResolved) {

              console.log('⏰ PostgreSQL 启动超时，但继续运行');

              startResolved = true;

              resolve();

            }

          }, 30000);

        }

      });

      

      checkProcess.on('error', (error) => {

        if (!checkResolved) {

          console.error('PostgreSQL 状态检查错误:', error.message);

          checkResolved = true;

          resolve();

        }

      });

      

      // 10秒超时

      setTimeout(() => {

        if (!checkResolved) {

          console.log('⏰ PostgreSQL 状态检查超时，尝试直接启动');

          checkResolved = true;

          

          // 直接尝试启动

          const directStartProcess = spawn(pgPath, ['start', '-D', pgData], {

            stdio: ['pipe', 'pipe', 'pipe'],

            windowsHide: true

          });

          

          directStartProcess.on('exit', () => {

            setTimeout(() => resolve(), 3000);

          });

          

          directStartProcess.on('error', () => {

            resolve();

          });

        }

      }, 10000);

      

    } catch (error) {

      console.error('自动启动 PostgreSQL 失败:', error.message);

      resolve(); // 即使失败也继续

    }

  });

}



// 启动服务器

function listenWithAutoPort(serverInstance, startPort, host = '0.0.0.0') {

  return new Promise((resolve, reject) => {

    const tryListen = (port, attempt) => {

      const onError = (error) => {

        serverInstance.off('listening', onListening);



        if (error?.code === 'EADDRINUSE' && attempt < MAX_PORT_RETRY) {

          const nextPort = port + 1;

          logger.warn('Port is in use, retrying next port', {

            port,

            nextPort,

            attempt,

            maxAttempts: MAX_PORT_RETRY

          });

          setTimeout(() => tryListen(nextPort, attempt + 1), 80);

          return;

        }



        reject(error);

      };



      const onListening = () => {

        serverInstance.off('error', onError);

        resolve(port);

      };



      serverInstance.once('error', onError);

      serverInstance.once('listening', onListening);

      serverInstance.listen(port, host);

    };



    tryListen(startPort, 1);

  });

}



async function startServer() {

  try {

    // Auto-detect database mode (postgres vs sqlite)

    // DB_TYPE=auto (default): test postgres port, fallback to sqlite

    if (process.env.DB_TYPE === 'postgres') {

      await autoStartPostgreSQL();

    }



    // Initialize database with auto-detection

    sequelize = await initDatabase();

    // Re-export for modules that already imported it

    require('./src/config/database').sequelize = sequelize;



    let dbConnected = false;

    const maxRetries = parseInt(process.env.DB_RETRY_ATTEMPTS) || 10;

    const retryDelay = parseInt(process.env.DB_RETRY_DELAY) || 3000;



    for (let attempt = 1; attempt <= maxRetries; attempt++) {

      try {

        console.log(`Connecting to database (${attempt}/${maxRetries})...`);

        await sequelize.authenticate();

        console.log('Database connected');

        dbConnected = true;

        break;

      } catch (error) {

        console.log(`Database connection failed (${attempt}/${maxRetries}):`, error.message);

        if (attempt < maxRetries) {

          console.log(`Retrying in ${retryDelay / 1000}s...`);

          await new Promise(resolve => setTimeout(resolve, retryDelay));

        } else {

          console.error('Database connection ultimately failed, server will continue');

        }

      }

    }



    // Initialize network detector

    try {

      const networkDetector = require('./src/services/networkDetector');

      await networkDetector.init();

      console.log(`Network mode: ${networkDetector.getDataMode()}`);

    } catch (err) {

      console.warn('Network detector init failed:', err.message);

    }



    // Initialize SQLite backup service

    try {

      const sqliteBackup = require('./src/services/sqliteBackupService');

      sqliteBackup.init();

    } catch (err) {

      console.warn('SQLite backup init failed:', err.message);

    }



    // Startup check: ensure Python ML dependencies are available early.

    try {

      const mlAgentService = require('./src/services/mlAgentService');

      const mlDepStatus = await mlAgentService.checkPythonRuntimeDependencies();

      if (mlDepStatus.ok) {

        logger.info('ML Python dependency check passed', {

          pythonPath: mlDepStatus.pythonPath

        });

      } else {

        const warningMessage = [

          'ML Python dependency check failed.',

          `pythonPath=${mlDepStatus.pythonPath}`,

          `missing=${(mlDepStatus.missing || []).join(', ') || 'unknown'}`,

          `detail=${mlDepStatus.message}`,

          'Local ML inference may fail until dependencies are installed.'

        ].join(' ');

        logger.warn(warningMessage);

        console.warn(warningMessage);

      }

    } catch (err) {

      logger.warn('ML Python dependency startup check failed unexpectedly', {

        error: err.message

      });

    }



    // Sync database models (safe: only creates missing tables/columns)

    if (dbConnected) {

      try {

        const useAlterSync = process.env.DB_SYNC_ALTER === 'true';

        await sequelize.sync({ alter: useAlterSync, force: false });

        logger.info('Database model sync completed', { alter: useAlterSync });

      } catch (error) {

        logger.warn('Database model sync failed', { error: error.message });

        // Fallback: try without alter

        try {

          await sequelize.sync({ force: false });

          logger.info('Database model basic sync completed');

        } catch (e2) {

          logger.error('Database model basic sync failed', { error: e2.message });

        }

      }

    }



    // Auto-seed admin user for SQLite first-run

    if (dbConnected && process.env.DB_MODE === 'sqlite') {

      try {

        const User = require('./src/models').User;

        const adminExists = await User.findOne({ where: { username: 'admin' } });

        if (!adminExists) {

          console.log('SQLite first-run: creating admin user...');

          const bcrypt = require('bcryptjs');

          const pw = await bcrypt.hash('admin123.', 10);

          const now = new Date().toISOString();

          await sequelize.query(

            'INSERT INTO users (username, password, email, role, status, created_at, updated_at) VALUES (:username, :password, :email, :role, :status, :now, :now)',

            { replacements: { username: 'admin', password: pw, email: 'admin@khy-quant.com', role: 'admin', status: 'active', now } }

          );

          console.log('Admin user created (admin / admin123.)');

        }

      } catch (err) {

        console.warn('Auto-seed failed:', err.message);

      }

    }



    // Auto-seed default instruments and watchlist

    if (dbConnected) {

      try {

        const { Instrument, Watchlist, User } = require('./src/models');

        const defaultInstruments = [

          { symbol: 'sh000300', name: '沪深300', type: 'index', market: 'SSE', category: '指数' },

          { symbol: 'sh000001', name: '上证指数', type: 'index', market: 'SSE', category: '指数' },

          { symbol: 'sz399001', name: '深证成指', type: 'index', market: 'SZSE', category: '指数' },

          { symbol: 'sz399006', name: '创业板指', type: 'index', market: 'SZSE', category: '指数' },

          { symbol: 'rb_main', name: '螺纹钢主力', type: 'futures', market: 'SHFE', category: '期货' },

          { symbol: 'rb2510', name: '螺纹钢2510', type: 'futures', market: 'SHFE', category: '期货' },

          { symbol: 'sh600519', name: '贵州茅台', type: 'stock', market: 'SSE', category: 'A股' },

          { symbol: 'sh600036', name: '招商银行', type: 'stock', market: 'SSE', category: 'A股' },

        ];

        for (const inst of defaultInstruments) {

          await Instrument.findOrCreate({ where: { symbol: inst.symbol }, defaults: inst });

        }



        // Seed default watchlist for admin

        const adminUser = await User.findOne({ where: { username: 'admin' } });

        if (adminUser) {

          const defaultWatchlist = [

            { symbol: 'sh000300', symbolName: '沪深300', instrumentType: 'index', category: '指数', basePrice: 4660 },

            { symbol: 'sh000001', symbolName: '上证指数', instrumentType: 'index', category: '指数', basePrice: 3350 },

            { symbol: 'sz399001', symbolName: '深证成指', instrumentType: 'index', category: '指数', basePrice: 10800 },

            { symbol: 'rb_main', symbolName: '螺纹钢主力', instrumentType: 'futures', category: '期货', basePrice: 3380 },

            { symbol: 'sh600519', symbolName: '贵州茅台', instrumentType: 'stock', category: '股票', basePrice: 1680 },

            { symbol: 'sh600036', symbolName: '招商银行', instrumentType: 'stock', category: '股票', basePrice: 38 },

          ];

          for (const item of defaultWatchlist) {

            await Watchlist.findOrCreate({

              where: { userId: adminUser.id, symbol: item.symbol },

              defaults: { userId: adminUser.id, ...item }

            });

          }

          console.log('Default instruments and watchlist seeded');

        }

      } catch (err) {

        console.warn('Auto-seed instruments/watchlist failed:', err.message);

      }

    }



    // Auto-seed/update rebar HFT strategy template

    if (dbConnected) {

      try {

        const Strategy = require('./src/models').Strategy;

        const rebarCode = `function strategy(data, params) {

  var emaFast = params.ema_fast || 5;

  var emaSlow = params.ema_slow || 20;

  var rsiPeriod = params.rsi_period || 6;

  var bollPeriod = params.boll_period || 20;

  var bollStd = params.boll_std || 2;

  var volRatio = params.volume_ratio || 1.3;

  var rsiOversold = params.rsi_oversold || 30;

  var rsiOverbought = params.rsi_overbought || 75;

  var signals = [];



  // EMA calculation

  function calcEMA(values, period) {

    var ema = [values[0]];

    var k = 2 / (period + 1);

    for (var i = 1; i < values.length; i++) {

      ema.push(values[i] * k + ema[i - 1] * (1 - k));

    }

    return ema;

  }



  // RSI calculation

  function calcRSI(closes, period) {

    var rsi = [];

    for (var i = 0; i < period; i++) rsi.push(50);

    var avgGain = 0, avgLoss = 0;

    for (var j = 1; j <= period; j++) {

      var diff = closes[j] - closes[j - 1];

      if (diff > 0) avgGain += diff; else avgLoss -= diff;

    }

    avgGain /= period; avgLoss /= period;

    rsi.push(avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss));

    for (var i = period + 1; i < closes.length; i++) {

      var d = closes[i] - closes[i - 1];

      avgGain = (avgGain * (period - 1) + (d > 0 ? d : 0)) / period;

      avgLoss = (avgLoss * (period - 1) + (d < 0 ? -d : 0)) / period;

      rsi.push(avgLoss === 0 ? 100 : 100 - 100 / (1 + avgGain / avgLoss));

    }

    return rsi;

  }



  // SMA calculation

  function calcSMA(values, period) {

    var sma = [];

    for (var i = 0; i < values.length; i++) {

      if (i < period - 1) { sma.push(values[i]); continue; }

      var sum = 0;

      for (var j = i - period + 1; j <= i; j++) sum += values[j];

      sma.push(sum / period);

    }

    return sma;

  }



  // Bollinger Bands

  function calcBoll(closes, period, std) {

    var mid = calcSMA(closes, period);

    var upper = [], lower = [];

    for (var i = 0; i < closes.length; i++) {

      if (i < period - 1) { upper.push(mid[i] + std * 0.01 * mid[i]); lower.push(mid[i] - std * 0.01 * mid[i]); continue; }

      var sum2 = 0;

      for (var j = i - period + 1; j <= i; j++) sum2 += (closes[j] - mid[i]) * (closes[j] - mid[i]);

      var sd = Math.sqrt(sum2 / period);

      upper.push(mid[i] + std * sd);

      lower.push(mid[i] - std * sd);

    }

    return { mid: mid, upper: upper, lower: lower };

  }



  // Volume MA

  function calcVolMA(data, period) {

    var vols = data.map(function(d) { return d.volume || 0; });

    return calcSMA(vols, period);

  }



  var closes = data.map(function(d) { return d.close; });

  var emaF = calcEMA(closes, emaFast);

  var emaS = calcEMA(closes, emaSlow);

  var rsi = calcRSI(closes, rsiPeriod);

  var boll = calcBoll(closes, bollPeriod, bollStd);

  var volMA = calcVolMA(data, 20);



  var minBars = Math.max(emaSlow, bollPeriod, rsiPeriod) + 1;



  for (var i = 0; i < data.length; i++) {

    if (i < minBars) { signals.push({ type: 'hold', index: i }); continue; }



    var c = data[i].close;

    var vol = data[i].volume || 0;

    var volRat = volMA[i] > 0 ? vol / volMA[i] : 1;

    var goldenCross = emaF[i] > emaS[i] && emaF[i - 1] <= emaS[i - 1];

    var deathCross = emaF[i] < emaS[i] && emaF[i - 1] >= emaS[i - 1];

    var emaBullish = emaF[i] > emaS[i];

    var rsiBounce = rsi[i] > rsiOversold && rsi[i - 1] <= rsiOversold && emaBullish;

    var bollBounce = c > boll.lower[i] && data[i-1].close <= boll.lower[i-1] && emaBullish;



    // Buy: golden cross OR RSI bounce from oversold (with bullish trend) OR Bollinger lower bounce

    if (goldenCross && rsi[i] > rsiOversold) {

      signals.push({ type: 'buy', index: i, price: c, time: data[i].time || data[i].date,

        reason: 'EMA golden cross, RSI=' + rsi[i].toFixed(1) + ', vol=' + volRat.toFixed(2) });

    } else if (rsiBounce) {

      signals.push({ type: 'buy', index: i, price: c, time: data[i].time || data[i].date,

        reason: 'RSI bounce from oversold=' + rsi[i].toFixed(1) + ', EMA bullish' });

    } else if (bollBounce && rsi[i] < 50) {

      signals.push({ type: 'buy', index: i, price: c, time: data[i].time || data[i].date,

        reason: 'Bollinger lower bounce, RSI=' + rsi[i].toFixed(1) });

    }

    // Sell: death cross OR RSI overbought OR stop loss below lower BB

    else if (deathCross) {

      signals.push({ type: 'sell', index: i, price: c, time: data[i].time || data[i].date,

        reason: 'EMA death cross' });

    } else if (rsi[i] > rsiOverbought) {

      signals.push({ type: 'sell', index: i, price: c, time: data[i].time || data[i].date,

        reason: 'RSI overbought=' + rsi[i].toFixed(1) });

    } else if (c < boll.lower[i] * 0.98) {

      signals.push({ type: 'sell', index: i, price: c, time: data[i].time || data[i].date,

        reason: 'Stop loss below BB lower' });

    } else {

      signals.push({ type: 'hold', index: i });

    }

  }



  signals.auxiliaryLines = {

    ema5: emaF,

    ema20: emaS,

    bollUpper: boll.upper,

    bollMid: boll.mid,

    bollLower: boll.lower

  };



  return signals;

}`;

        const rebarParams = {

          ema_fast: 5, ema_slow: 20, rsi_period: 6,

          boll_period: 20, boll_std: 2, volume_ratio: 1.3,

          rsi_oversold: 30, rsi_overbought: 75

        };

        const existing = await Strategy.findOne({ where: { name: '螺纹钢主力高频策略' } });

        if (existing) {

          await existing.update({ code: rebarCode, parameters: rebarParams });

          console.log('Rebar HFT strategy updated with correct JS format.');

        } else {

          await Strategy.create({

            user_id: 1, name: '螺纹钢主力高频策略',

            description: '基于EMA金叉死叉+布林带+RSI的高频信号策略。适用于任意K线周期，每根K线均计算信号。研究课题：高频策略在螺纹钢主力合约上的可行性。',

            type: 'trend', language: 'javascript', status: 'active', isPublic: true,

            parameters: rebarParams, code: rebarCode

          });

          console.log('Rebar HFT strategy seeded.');

        }

      } catch (err) {

        console.warn('Strategy seed failed:', err.message);

      }

    }



    // Instrument sync service

    if (dbConnected) {

      const instrumentService = require('./src/services/instrumentService');

      const cron = require('node-cron');

      

      // 启动时立即同步一次

      console.log('🔄 启动标的数据同步服务...');

      instrumentService.syncInstrumentsFromAData()

        .then(result => {

          console.log(`✅ 标的数据同步完成: ${result.successCount}个成功, ${result.failCount}个失败`);

        })

        .catch(error => {

          console.error('❌ 标的数据同步失败:', error.message);

        });

      

      // 设置定时更新 - 每天凌晨2点更新

      cron.schedule('0 2 * * *', async () => {

        console.log('🔄 定时同步标的数据...');

        try {

          const result = await instrumentService.syncInstrumentsFromAData();

          console.log(`✅ 定时同步完成: ${result.successCount}个成功, ${result.failCount}个失败`);

        } catch (error) {

          console.error('❌ 定时同步失败:', error.message);

        }

      });

      

      console.log('✅ 标的数据自动更新服务已启动 (每天凌晨2点更新)');

      

      // Schedule daily K-line data persistence at 03:00

      const cacheController = require('./src/controllers/cacheController');

      const comprehensiveDataService = require('./src/services/comprehensiveDataService');

      

      cron.schedule('0 3 * * *', async () => {

        console.log('\n🔄 定时保存K线数据到数据库...');

        try {

          // 获取所有活跃的标的

          const instruments = await instrumentService.getInstruments({ 

            status: 'active',

            limit: 100 // 每次保存前100个最重要的标的

          });

          

          console.log(`📊 准备保存 ${instruments.length} 个标的的K线数据...`);

          

          let successCount = 0;

          let failCount = 0;

          

          for (const inst of instruments) {

            try {

              // 保存日线数据

              const klineData = await comprehensiveDataService.getComprehensiveData(inst.symbol, {

                period: 'daily',

                limit: 500 // 保存最近500条

              });

              

              if (klineData && klineData.kline && klineData.kline.length > 0) {

                const klineDataService = require('./src/services/klineDataService');

                await klineDataService.saveKlineData(

                  inst.symbol,

                  inst.name,

                  'daily',

                  klineData.kline

                );

                successCount++;

                console.log(`  ✅ ${inst.symbol} ${inst.name}: ${klineData.kline.length}条`);

              } else {

                failCount++;

                console.log(`  ⚠️ ${inst.symbol} ${inst.name}: 无数据`);

              }

              

              // 避免请求过快,等待100ms

              await new Promise(resolve => setTimeout(resolve, 100));

            } catch (error) {

              failCount++;

              console.error(`  ❌ ${inst.symbol} ${inst.name}: ${error.message}`);

            }

          }

          

          console.log(`\n✅ 定时保存完成: 成功${successCount}, 失败${failCount}`);

        } catch (error) {

          console.error('❌ 定时保存失败:', error.message);

        }

      });

      

      console.log('✅ K线数据自动保存服务已启动 (每天凌晨3点保存)');

    }



    // Start instrument list auto-sync service

    console.log('\n📊 启动标的列表自动同步服务...');

    instrumentSyncService.start();



    // 启动HTTP服务器 - 监听所有网络接口，端口冲突时自动递增

    const activePort = await listenWithAutoPort(server, START_PORT, '0.0.0.0');

    const os = require('os');

    const networkInterfaces = os.networkInterfaces();

    const localIPs = [];



    // 获取所有本地IP地址

    Object.keys(networkInterfaces).forEach(interfaceName => {

      networkInterfaces[interfaceName].forEach(iface => {

        if (iface.family === 'IPv4' && !iface.internal) {

          localIPs.push(iface.address);

        }

      });

    });



    console.log('\n========================================');

    console.log('  量化交易系统后端启动成功！');

    console.log(`  本地访问: http://localhost:${activePort}`);

    if (localIPs.length > 0) {

      console.log(`  局域网访问: http://${localIPs[0]}:${activePort}`);

      localIPs.slice(1).forEach(ip => {

        console.log(`             http://${ip}:${activePort}`);

      });

    }

    console.log(`  WebSocket: ws://localhost:${activePort}`);

    console.log(`  健康检查: http://localhost:${activePort}/health`);

    console.log(`  数据库状态: ${dbConnected ? '✅ 已连接' : '❌ 未连接'}`);

    console.log('========================================\n');



    // AKShare auto-update scheduler

    const akshareUpdater = require('./src/services/akshareUpdater');

    akshareUpdater.startScheduler();

  } catch (error) {

    console.error('✗ 服务器启动失败:', error);

    process.exit(1);

  }

}



function gracefulShutdown(signal) {

  logger.warn('Shutdown signal received', { signal });

  try { realtimeDataService.cleanup(); } catch {}

  try { notificationService.cleanup(); } catch {}

  try { instrumentSyncService.stop(); } catch {}



  server.close(() => {

    logger.info('Server closed gracefully');

    process.exit(0);

  });

}



// 稳定性：捕获未处理异常，记录后继续运行（避免进程直接崩溃）

process.on('uncaughtException', (error) => {

  logger.error('uncaughtException captured', {

    message: error.message,

    stack: error.stack

  });

});



process.on('unhandledRejection', (reason) => {

  const message = reason instanceof Error ? reason.message : String(reason);

  const stack = reason instanceof Error ? reason.stack : undefined;

  logger.error('unhandledRejection captured', { message, stack });

});



// 优雅关闭

process.on('SIGTERM', () => gracefulShutdown('SIGTERM'));

process.on('SIGINT', () => gracefulShutdown('SIGINT'));



// Global crash handlers — log and recover instead of silent exit

process.on('uncaughtException', (err) => {

  console.error('[FATAL] Uncaught exception:', err.message);

  console.error(err.stack);

  // Stay alive — the error is logged, Express keeps serving

});



process.on('unhandledRejection', (reason) => {

  console.error('[WARN] Unhandled promise rejection:', reason);

});



startServer();

 

