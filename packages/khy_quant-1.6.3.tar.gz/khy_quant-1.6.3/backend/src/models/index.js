/**
 * Model Registry & Entity Relationships
 *
 * Defines the six core entities described in the thesis E-R diagram
 * (Chapter 4, Tables 16-21): User, Strategy, Backtest, Trade,
 * KlineCache, and AISuggestion.  Plus auxiliary entities for
 * announcements, feedback, watchlists, and system settings.
 *
 * Relationship chain: User -> Strategy -> Backtest -> Trade
 *                     User -> AISuggestion
 *                     KlineCache (standalone, composite key on symbol+period+date)
 */
const { sequelize } = require('../config/database');
const User = require('./User');
const Strategy = require('./Strategy');
const Backtest = require('./Backtest');
const Trade = require('./Trade');
const AISuggestion = require('./AISuggestion');
const Announcement = require('./Announcement');
const AnnouncementRead = require('./AnnouncementRead');
const Feedback = require('./Feedback');
const UserLog = require('./UserLog');
const Watchlist = require('./Watchlist');
const MarketData = require('./MarketData');
const SystemSetting = require('./SystemSetting');
const KlineCache = require('./KlineCache');
const Instrument = require('./Instrument');
const KlineData = require('./KlineData');
const UserFavorite = require('./UserFavorite');
const BankTransfer = require('./BankTransfer');
const Signal = require('./Signal');
const ApiKey = require('./ApiKey');

// 定义关联关系
User.hasMany(Strategy, { foreignKey: 'user_id', as: 'strategies' });
Strategy.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

User.hasMany(Backtest, { foreignKey: 'user_id', as: 'backtests' });
Backtest.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

Strategy.hasMany(Backtest, { foreignKey: 'strategy_id', as: 'backtests' });
Backtest.belongsTo(Strategy, { foreignKey: 'strategy_id', as: 'strategy' });

User.hasMany(Trade, { foreignKey: 'user_id', as: 'trades' });
Trade.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

Strategy.hasMany(Trade, { foreignKey: 'strategy_id', as: 'trades' });
Trade.belongsTo(Strategy, { foreignKey: 'strategy_id', as: 'strategy' });

User.hasMany(AISuggestion, { foreignKey: 'user_id', as: 'aiSuggestions' });
AISuggestion.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

User.hasMany(Announcement, { foreignKey: 'author_id', as: 'announcements' });
Announcement.belongsTo(User, { foreignKey: 'author_id', as: 'author' });

User.hasMany(AnnouncementRead, { foreignKey: 'user_id', as: 'announcementReads' });
AnnouncementRead.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

Announcement.hasMany(AnnouncementRead, { foreignKey: 'announcement_id', as: 'reads' });
AnnouncementRead.belongsTo(Announcement, { foreignKey: 'announcement_id', as: 'announcement' });

// Feedback 关联关系
User.hasMany(Feedback, { foreignKey: 'userId', as: 'feedbacks' });
Feedback.belongsTo(User, { foreignKey: 'userId', as: 'user' });

User.hasMany(Feedback, { foreignKey: 'adminId', as: 'adminFeedbacks' });
Feedback.belongsTo(User, { foreignKey: 'adminId', as: 'admin' });

// UserLog 关联关系
User.hasMany(UserLog, { foreignKey: 'userId', as: 'logs' });
UserLog.belongsTo(User, { foreignKey: 'userId', as: 'user' });

// Watchlist 关联关系
User.hasMany(Watchlist, { foreignKey: 'userId', as: 'watchlists' });
Watchlist.belongsTo(User, { foreignKey: 'userId', as: 'user' });

// BankTransfer 关联关系
User.hasMany(BankTransfer, { foreignKey: 'userId', as: 'bankTransfers' });
BankTransfer.belongsTo(User, { foreignKey: 'userId', as: 'user' });

// Signal 关联关系
User.hasMany(Signal, { foreignKey: 'user_id', as: 'signals' });
Signal.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

// ApiKey 关联关系
User.hasMany(ApiKey, { foreignKey: 'user_id', as: 'apiKeys' });
ApiKey.belongsTo(User, { foreignKey: 'user_id', as: 'user' });

module.exports = {
  sequelize,
  User,
  Strategy,
  Backtest,
  Trade,
  AISuggestion,
  Announcement,
  AnnouncementRead,
  Feedback,
  UserLog,
  Watchlist,
  MarketData,
  SystemSetting,
  KlineCache,
  Instrument,
  KlineData,
  UserFavorite,
  BankTransfer,
  Signal,
  ApiKey
};
