const { DataTypes } = require('sequelize');
const { sequelize } = require('../config/database');

const ApiKey = sequelize.define('ApiKey', {
  id: {
    type: DataTypes.INTEGER,
    primaryKey: true,
    autoIncrement: true
  },
  userId: {
    type: DataTypes.INTEGER,
    allowNull: false,
    field: 'user_id',
    comment: 'Owner of this API key'
  },
  key: {
    type: DataTypes.STRING(64),
    allowNull: false,
    unique: true,
    comment: 'Full API key value (khy_ prefix + 48 hex chars)'
  },
  keyPrefix: {
    type: DataTypes.STRING(16),
    allowNull: false,
    field: 'key_prefix',
    comment: 'First 12 chars of key — safe to display in UI/logs'
  },
  label: {
    type: DataTypes.STRING(100),
    defaultValue: 'default',
    comment: 'User-friendly label for this key'
  },
  isActive: {
    type: DataTypes.BOOLEAN,
    defaultValue: true,
    field: 'is_active',
    comment: 'false = revoked / rotated out'
  },
  lastUsedAt: {
    type: DataTypes.DATE,
    allowNull: true,
    field: 'last_used_at',
    comment: 'Timestamp of last successful authentication with this key'
  }
}, {
  tableName: 'api_keys',
  timestamps: true
});

module.exports = ApiKey;
