/**
 * Resource Guard — prevent terminal/computer freezing.
 *
 * Provides:
 *   - Watchdog timer for long-running operations
 *   - Memory usage monitoring with auto-GC
 *   - Infinite loop detection (CPU spin guard)
 *   - Network call timeouts
 *   - Graceful recovery from hangs
 *   - Child process resource limits
 */
const os = require('os');
const { execSync } = require('child_process');

// ── Limits ──────────────────────────────────────────────────────────────
const MAX_HEAP_MB = parseInt(process.env.KHY_MAX_HEAP_MB, 10) || 512;
const WATCHDOG_TIMEOUT_MS = parseInt(process.env.KHY_WATCHDOG_MS, 10) || 120_000; // 2 min
const NETWORK_TIMEOUT_MS = 60_000;     // 1 min for network calls
const SHELL_TIMEOUT_MS = 30_000;       // 30s for shell commands
const SHELL_MAX_BUFFER = 10 * 1024 * 1024; // 10 MB output buffer
const GC_CHECK_INTERVAL_MS = 30_000;   // Check memory every 30s
const GC_THRESHOLD_PERCENT = 80;       // Trigger GC at 80% of limit

let _watchdogTimer = null;
let _watchdogCallback = null;
let _gcTimer = null;
let _operationStack = [];

// ── Watchdog Timer ──────────────────────────────────────────────────────

/**
 * Start a watchdog timer for a named operation.
 * If the operation doesn't complete within timeoutMs, the callback fires.
 * @param {string} operationName
 * @param {number} [timeoutMs]
 * @param {function} [onTimeout] - Called if timeout fires
 * @returns {object} Guard handle with .done() method
 */
function startWatchdog(operationName, timeoutMs = WATCHDOG_TIMEOUT_MS, onTimeout = null) {
  const startTime = Date.now();
  const entry = { name: operationName, startTime, done: false };
  _operationStack.push(entry);

  const timer = setTimeout(() => {
    if (!entry.done) {
      const elapsed = ((Date.now() - startTime) / 1000).toFixed(1);
      const msg = `[ResourceGuard] Operation "${operationName}" timed out after ${elapsed}s`;

      // Log warning
      try { console.error(`\n  ⚠ ${msg}\n`); } catch { /* ignore */ }

      if (onTimeout) {
        try { onTimeout(operationName, elapsed); } catch { /* ignore */ }
      }
    }
  }, timeoutMs);

  timer.unref(); // Don't block process exit

  return {
    done() {
      entry.done = true;
      clearTimeout(timer);
      const idx = _operationStack.indexOf(entry);
      if (idx >= 0) _operationStack.splice(idx, 1);
    },
    elapsed() {
      return Date.now() - startTime;
    },
  };
}

// ── Memory Monitor ──────────────────────────────────────────────────────

/**
 * Get current memory usage stats.
 */
function getMemoryUsage() {
  const usage = process.memoryUsage();
  return {
    heapUsedMB: Math.round(usage.heapUsed / (1024 * 1024)),
    heapTotalMB: Math.round(usage.heapTotal / (1024 * 1024)),
    rssMB: Math.round(usage.rss / (1024 * 1024)),
    externalMB: Math.round((usage.external || 0) / (1024 * 1024)),
    limitMB: MAX_HEAP_MB,
    percentUsed: Math.round((usage.heapUsed / (MAX_HEAP_MB * 1024 * 1024)) * 100),
  };
}

/**
 * Check if memory is critically high and attempt GC.
 * @returns {boolean} true if memory was freed
 */
function checkMemoryPressure() {
  const mem = getMemoryUsage();

  if (mem.percentUsed > GC_THRESHOLD_PERCENT) {
    // Try to trigger GC if exposed
    if (global.gc) {
      global.gc();
      return true;
    }

    // Clear module caches for non-essential modules
    const expendable = [
      '../services/strategyRecommender',
      '../services/finlightNewsService',
    ];
    for (const mod of expendable) {
      try {
        const resolved = require.resolve(mod);
        if (require.cache[resolved]) {
          delete require.cache[resolved];
        }
      } catch { /* module not loaded */ }
    }

    return false;
  }

  return false;
}

/**
 * Start periodic memory monitoring.
 */
function startMemoryMonitor() {
  if (_gcTimer) return;
  _gcTimer = setInterval(() => {
    try {
      const mem = getMemoryUsage();
      if (mem.percentUsed > 95) {
        console.error(`\n  ⚠ 内存使用过高: ${mem.heapUsedMB}/${mem.limitMB} MB (${mem.percentUsed}%)`);
        console.error('  建议: 减少并发操作或重启终端\n');
        checkMemoryPressure();
      }
    } catch { /* monitor must never crash */ }
  }, GC_CHECK_INTERVAL_MS);
  _gcTimer.unref();
}

function stopMemoryMonitor() {
  if (_gcTimer) { clearInterval(_gcTimer); _gcTimer = null; }
}

// ── Safe Shell Execution ────────────────────────────────────────────────

/**
 * Execute a shell command with resource limits.
 * Prevents: infinite loops, excessive output, excessive runtime, fork bombs.
 *
 * @param {string} command - Shell command to execute
 * @param {object} [opts]
 * @param {number} [opts.timeout] - Max execution time in ms
 * @param {number} [opts.maxBuffer] - Max output buffer in bytes
 * @param {string} [opts.cwd] - Working directory
 * @returns {{ stdout: string, stderr: string, exitCode: number }}
 */
function safeExec(command, opts = {}) {
  const timeout = opts.timeout || SHELL_TIMEOUT_MS;
  const maxBuffer = opts.maxBuffer || SHELL_MAX_BUFFER;
  const cwd = opts.cwd || process.cwd();

  // Build resource-limited command on Linux
  let wrappedCommand = command;
  if (process.platform !== 'win32') {
    // ulimit: 30s CPU time, 512MB virtual memory, 1024 max processes, 100MB file size
    const limits = [
      'ulimit -t 30',          // 30 second CPU time limit
      'ulimit -v 524288',      // 512 MB virtual memory
      'ulimit -u 50',          // Max 50 child processes (prevent fork bomb)
      'ulimit -f 102400',      // 100 MB max file size
      'ulimit -n 256',         // Max 256 file descriptors
    ].join(' 2>/dev/null; ');

    wrappedCommand = `bash -c '${limits}; ${command.replace(/'/g, "'\\''")}'`;
  }

  try {
    const stdout = execSync(wrappedCommand, {
      encoding: 'utf-8',
      timeout,
      maxBuffer,
      cwd,
      stdio: ['pipe', 'pipe', 'pipe'],
      // Ensure child is killed on timeout
      killSignal: 'SIGKILL',
    });
    return { stdout, stderr: '', exitCode: 0 };
  } catch (err) {
    if (err.killed) {
      return {
        stdout: (err.stdout || '').slice(0, 1000),
        stderr: `Command killed: exceeded ${timeout / 1000}s timeout or resource limit`,
        exitCode: 137,
      };
    }
    return {
      stdout: (err.stdout || '').slice(0, maxBuffer),
      stderr: (err.stderr || '').slice(0, 2000),
      exitCode: err.status || 1,
    };
  }
}

/**
 * Wrap a Promise with a timeout.
 * @param {Promise} promise
 * @param {number} ms - Timeout in milliseconds
 * @param {string} [label] - Operation label for error message
 * @returns {Promise}
 */
function withTimeout(promise, ms, label = 'Operation') {
  let timer;
  const timeoutPromise = new Promise((_, reject) => {
    timer = setTimeout(() => reject(new Error(`${label} timed out after ${ms / 1000}s`)), ms);
    timer.unref?.();
  });

  return Promise.race([promise, timeoutPromise]).finally(() => clearTimeout(timer));
}

/**
 * Wrap an async function so it can't run forever.
 * Returns a new function that automatically aborts after timeoutMs.
 */
function timeoutWrap(fn, timeoutMs = WATCHDOG_TIMEOUT_MS, label = '') {
  return async function (...args) {
    return withTimeout(fn(...args), timeoutMs, label || fn.name || 'async operation');
  };
}

// ── Active Operation Tracking ───────────────────────────────────────────

/**
 * Get list of currently active (in-progress) operations.
 */
function getActiveOperations() {
  return _operationStack
    .filter(op => !op.done)
    .map(op => ({
      name: op.name,
      elapsedMs: Date.now() - op.startTime,
      elapsedStr: `${((Date.now() - op.startTime) / 1000).toFixed(1)}s`,
    }));
}

/**
 * Cancel all active watchdogs (for graceful shutdown).
 */
function cancelAll() {
  for (const op of _operationStack) op.done = true;
  _operationStack = [];
  stopMemoryMonitor();
}

// ── System Resource Check ───────────────────────────────────────────────

/**
 * Quick system health check: RAM, CPU load, disk space.
 */
function systemHealthCheck() {
  const totalMem = os.totalmem();
  const freeMem = os.freemem();
  const memPercent = Math.round(((totalMem - freeMem) / totalMem) * 100);
  const loadAvg = os.loadavg();
  const cpuCount = os.cpus().length;
  const loadPercent = Math.round((loadAvg[0] / cpuCount) * 100);

  const warnings = [];

  if (memPercent > 90) {
    warnings.push(`系统内存使用过高: ${memPercent}% (${Math.round(freeMem / (1024 * 1024))} MB 可用)`);
  }
  if (loadPercent > 80) {
    warnings.push(`CPU 负载过高: ${loadPercent}% (1min avg: ${loadAvg[0].toFixed(1)})`);
  }

  // Check disk space (Linux/Mac)
  try {
    const df = execSync('df -h / 2>/dev/null | tail -1', { encoding: 'utf-8', timeout: 3000 });
    const parts = df.trim().split(/\s+/);
    const usePercent = parseInt(parts[4]) || 0;
    if (usePercent > 90) {
      warnings.push(`磁盘空间不足: 已用 ${usePercent}% (${parts[3]} 可用)`);
    }
  } catch { /* ignore */ }

  return {
    healthy: warnings.length === 0,
    memPercent,
    loadPercent,
    warnings,
  };
}

module.exports = {
  // Watchdog
  startWatchdog,
  getActiveOperations,
  cancelAll,

  // Memory
  getMemoryUsage,
  checkMemoryPressure,
  startMemoryMonitor,
  stopMemoryMonitor,

  // Safe execution
  safeExec,
  withTimeout,
  timeoutWrap,

  // System health
  systemHealthCheck,

  // Constants
  WATCHDOG_TIMEOUT_MS,
  NETWORK_TIMEOUT_MS,
  SHELL_TIMEOUT_MS,
  SHELL_MAX_BUFFER,
};
