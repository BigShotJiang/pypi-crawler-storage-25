/**
 * Network Detector Service
 * Tests connectivity to push2.eastmoney.com to determine online/offline mode.
 * Caches result for 5 minutes, re-checks every 5 minutes.
 */
const http = require('http');
const logger = require('../utils/logger');

class NetworkDetector {
  constructor() {
    this._online = false;
    this._lastCheck = 0;
    this._cacheTTL = 5 * 60 * 1000; // 5 minutes
    this._checking = false;
    this._initialized = false;
    this._intervalHandle = null;
  }

  /**
   * Initialize: run first check and start periodic re-check.
   */
  async init() {
    if (this._initialized) return;
    this._initialized = true;
    await this._doCheck();
    this._intervalHandle = setInterval(() => this._doCheck(), this._cacheTTL);
  }

  /**
   * Test connectivity to push2.eastmoney.com with 2s timeout.
   */
  _doCheck() {
    if (this._checking) return Promise.resolve();
    this._checking = true;

    return new Promise(resolve => {
      const req = http.request(
        {
          hostname: 'push2.eastmoney.com',
          port: 80,
          path: '/',
          method: 'HEAD',
          timeout: 2000,
        },
        res => {
          this._online = true;
          this._lastCheck = Date.now();
          this._checking = false;
          logger.info('Network check: ONLINE (eastmoney reachable)');
          res.resume();
          resolve();
        }
      );

      req.on('error', () => {
        this._online = false;
        this._lastCheck = Date.now();
        this._checking = false;
        logger.info('Network check: OFFLINE (eastmoney unreachable)');
        resolve();
      });

      req.on('timeout', () => {
        req.destroy();
        this._online = false;
        this._lastCheck = Date.now();
        this._checking = false;
        logger.info('Network check: OFFLINE (timeout)');
        resolve();
      });

      req.setTimeout(2000);
      req.end();
    });
  }

  /**
   * @returns {boolean} Whether the system is online.
   */
  isOnline() {
    // If never checked, assume offline until first check completes
    if (!this._initialized) return false;
    return this._online;
  }

  /**
   * @returns {'online'|'offline'} Current data mode.
   */
  getDataMode() {
    return this.isOnline() ? 'online' : 'offline';
  }

  /**
   * Stop periodic checks (for graceful shutdown).
   */
  stop() {
    if (this._intervalHandle) {
      clearInterval(this._intervalHandle);
      this._intervalHandle = null;
    }
  }
}

// Singleton
const detector = new NetworkDetector();

module.exports = detector;
