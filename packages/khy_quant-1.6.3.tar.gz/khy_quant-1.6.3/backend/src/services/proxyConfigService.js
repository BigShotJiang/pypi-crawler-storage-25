/**
 * Proxy Configuration Service — configure HTTP/SOCKS5 proxies for
 * accessing foreign AI model APIs.
 *
 * Supports:
 *   - Auto-detection of Clash, ClashX, Clash Verge, Clash Meta
 *   - Manual HTTP/SOCKS5 proxy configuration
 *   - Subscription URL management
 *   - Environment variable injection (http_proxy, https_proxy, all_proxy)
 */
const fs = require('fs');
const path = require('path');
const os = require('os');
const http = require('http');
const https = require('https');

const KHY_DIR = path.join(os.homedir(), '.khyquant');
const PROXY_CONFIG_PATH = path.join(KHY_DIR, 'proxy.json');

// Default Clash ports by client
const CLASH_PORTS = {
  http: [7890, 7891, 7892, 8080, 8888],
  socks: [7891, 7893, 1080],
  mixed: [7890],
};

let _activeProxy = null;

/**
 * Load proxy configuration from disk.
 */
function loadConfig() {
  try {
    if (fs.existsSync(PROXY_CONFIG_PATH)) {
      return JSON.parse(fs.readFileSync(PROXY_CONFIG_PATH, 'utf8'));
    }
  } catch { /* corrupted config */ }
  return { enabled: false, type: 'http', host: '127.0.0.1', port: 7890, subscriptions: [] };
}

/**
 * Save proxy configuration to disk.
 */
function saveConfig(config) {
  try {
    fs.mkdirSync(KHY_DIR, { recursive: true });
    fs.writeFileSync(PROXY_CONFIG_PATH, JSON.stringify(config, null, 2));
  } catch { /* ignore write errors */ }
}

/**
 * Test if a proxy is reachable by connecting to it.
 */
function testProxy(host, port, timeout = 3000) {
  return new Promise((resolve) => {
    const net = require('net');
    const socket = net.createConnection({ host, port }, () => {
      socket.destroy();
      resolve(true);
    });
    socket.on('error', () => resolve(false));
    socket.setTimeout(timeout, () => { socket.destroy(); resolve(false); });
  });
}

/**
 * Auto-detect running Clash proxy.
 * Checks common ports in order.
 */
async function detectClash() {
  for (const port of CLASH_PORTS.http) {
    if (await testProxy('127.0.0.1', port)) {
      return { type: 'http', host: '127.0.0.1', port, detected: true };
    }
  }
  for (const port of CLASH_PORTS.socks) {
    if (await testProxy('127.0.0.1', port)) {
      return { type: 'socks5', host: '127.0.0.1', port, detected: true };
    }
  }
  return null;
}

/**
 * Apply proxy settings to the process environment.
 * This affects all outgoing HTTP/HTTPS requests via Node.js.
 */
function applyProxy(config) {
  if (!config || !config.enabled) {
    // Clear proxy env vars
    delete process.env.http_proxy;
    delete process.env.https_proxy;
    delete process.env.HTTP_PROXY;
    delete process.env.HTTPS_PROXY;
    delete process.env.all_proxy;
    delete process.env.ALL_PROXY;
    _activeProxy = null;
    return;
  }

  const proxyUrl = config.type === 'socks5'
    ? `socks5://${config.host}:${config.port}`
    : `http://${config.host}:${config.port}`;

  process.env.http_proxy = proxyUrl;
  process.env.https_proxy = proxyUrl;
  process.env.HTTP_PROXY = proxyUrl;
  process.env.HTTPS_PROXY = proxyUrl;
  process.env.all_proxy = proxyUrl;
  process.env.ALL_PROXY = proxyUrl;

  // No-proxy for local addresses
  const noProxy = '127.0.0.1,localhost,::1,10.0.0.0/8,172.16.0.0/12,192.168.0.0/16';
  process.env.no_proxy = noProxy;
  process.env.NO_PROXY = noProxy;

  _activeProxy = { ...config, url: proxyUrl };
}

/**
 * Get current active proxy info.
 */
function getActiveProxy() {
  return _activeProxy;
}

/**
 * Enable proxy with given settings.
 */
async function enableProxy(opts = {}) {
  let config = loadConfig();

  if (opts.type) config.type = opts.type;
  if (opts.host) config.host = opts.host;
  if (opts.port) config.port = parseInt(opts.port, 10);

  config.enabled = true;

  // Test connectivity
  const reachable = await testProxy(config.host, config.port);
  if (!reachable) {
    return { success: false, error: `代理不可达: ${config.host}:${config.port}` };
  }

  applyProxy(config);
  saveConfig(config);
  return { success: true, proxy: _activeProxy };
}

/**
 * Disable proxy.
 */
function disableProxy() {
  const config = loadConfig();
  config.enabled = false;
  applyProxy(null);
  saveConfig(config);
  return { success: true };
}

/**
 * Auto-detect and enable Clash proxy.
 */
async function autoDetectAndEnable() {
  const clash = await detectClash();
  if (!clash) {
    return { success: false, error: '未检测到 Clash 代理。请确保 Clash 已启动并开启系统代理。' };
  }

  const config = {
    ...loadConfig(),
    enabled: true,
    type: clash.type,
    host: clash.host,
    port: clash.port,
  };

  applyProxy(config);
  saveConfig(config);
  return { success: true, proxy: _activeProxy, detected: true };
}

/**
 * Add a subscription URL to the config.
 */
function addSubscription(url, name = '') {
  const config = loadConfig();
  if (!config.subscriptions) config.subscriptions = [];
  config.subscriptions.push({ url, name: name || url.slice(0, 30), addedAt: new Date().toISOString() });
  saveConfig(config);
  return { success: true, count: config.subscriptions.length };
}

/**
 * Initialize proxy from saved config on startup.
 */
function initFromConfig() {
  const config = loadConfig();
  if (config.enabled) {
    applyProxy(config);
  }
}

/**
 * Get proxy status for display.
 */
function getStatus() {
  const config = loadConfig();
  return {
    enabled: config.enabled,
    type: config.type,
    host: config.host,
    port: config.port,
    active: !!_activeProxy,
    url: _activeProxy?.url || null,
    subscriptions: (config.subscriptions || []).length,
  };
}

module.exports = {
  loadConfig,
  saveConfig,
  detectClash,
  testProxy,
  applyProxy,
  getActiveProxy,
  enableProxy,
  disableProxy,
  autoDetectAndEnable,
  addSubscription,
  initFromConfig,
  getStatus,
};
