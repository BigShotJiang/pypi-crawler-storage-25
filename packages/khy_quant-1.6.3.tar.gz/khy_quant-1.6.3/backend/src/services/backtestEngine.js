/**
 * Real backtest engine
 * Runs a strategy's signal function against historical kline data and computes
 * equity curve, drawdown, Sharpe ratio, and trade log.
 */
const vm = require('vm');
const klineDataService = require('./klineDataService');
const comprehensiveDataService = require('./comprehensiveDataService');
const logger = require('../utils/logger');

class BacktestEngine {
  /**
   * Run a backtest
   * @param {Object} options
   * @param {string} options.symbol - Instrument symbol
   * @param {string} options.startDate - ISO date string
   * @param {string} options.endDate - ISO date string
   * @param {number} options.initialCapital - Starting capital (default 100000)
   * @param {Function|string} options.signalFn - Function(bar, i, bars) => 'buy'|'sell'|null
   * @param {Object} options.params - Strategy parameters
   * @returns {Object} Backtest results
   */
  async run({ symbol, startDate, endDate, initialCapital = 100000, signalFn, params = {} }) {
    // 1. Load historical data
    let bars = await klineDataService.getKlineData(symbol, 'daily', startDate, endDate, 10000);

    // Fallback: pull from comprehensive source (which includes mock/hybrid fallback).
    if (!bars || bars.length < 2) {
      try {
        const comprehensive = await comprehensiveDataService.getComprehensiveData(symbol, {
          startDate,
          endDate,
          period: 'daily'
        });
        bars = (comprehensive?.kline || []).map((item) => ({
          date: item.time,
          open: Number(item.open),
          high: Number(item.high),
          low: Number(item.low),
          close: Number(item.close),
          volume: Number(item.volume || 0)
        }));
      } catch (fallbackError) {
        logger.warn('Backtest comprehensive fallback failed', {
          symbol,
          error: fallbackError.message
        });
      }
    }

    if (!bars || bars.length < 2) {
      throw Object.assign(new Error(`Insufficient data for ${symbol}: ${bars?.length || 0} bars`), { status: 400 });
    }

    // 2. Compile signal function if string (using vm sandbox for security)
    let signal;
    if (typeof signalFn === 'string') {
      try {
        const script = new vm.Script(`(function(bar, i, bars, params) { ${signalFn} })`);
        const sandbox = Object.create(null);
        // Wrap every function to cut prototype chain (.constructor.constructor → Function escape)
        const w = (fn) => { const f = (...args) => fn(...args); Object.setPrototypeOf(f, null); return f; };
        sandbox.Math = Object.freeze({
          abs: w(Math.abs), ceil: w(Math.ceil), floor: w(Math.floor),
          max: w(Math.max), min: w(Math.min), pow: w(Math.pow),
          round: w(Math.round), sqrt: w(Math.sqrt), log: w(Math.log),
          random: w(Math.random), PI: Math.PI, E: Math.E,
        });
        sandbox.Number = w(Number);
        sandbox.parseFloat = w(parseFloat);
        sandbox.parseInt = w(parseInt);
        sandbox.isNaN = w(isNaN);
        sandbox.isFinite = w(isFinite);
        const ctx = vm.createContext(sandbox);
        signal = script.runInContext(ctx, { timeout: 5000 });
      } catch (e) {
        throw Object.assign(new Error('Invalid strategy code: ' + e.message), { status: 400 });
      }
    } else if (typeof signalFn === 'function') {
      signal = signalFn;
    } else {
      throw Object.assign(new Error('signalFn must be a function or string'), { status: 400 });
    }

    // 3. Simulate
    let cash = initialCapital;
    let position = 0;
    let entryPrice = 0;
    const trades = [];
    const equity = [];
    let peakEquity = initialCapital;
    let maxDrawdown = 0;
    const dailyReturns = [];
    const frozenBars = Object.freeze(bars.map(b => Object.freeze({ ...b })));
    const frozenParams = Object.freeze({ ...params });

    for (let i = 0; i < bars.length; i++) {
      const bar = bars[i];
      const portfolioValue = cash + position * bar.close;
      equity.push({ date: bar.date, value: portfolioValue });

      // Track drawdown
      if (portfolioValue > peakEquity) peakEquity = portfolioValue;
      const dd = (peakEquity - portfolioValue) / peakEquity;
      if (dd > maxDrawdown) maxDrawdown = dd;

      // Daily return
      if (i > 0) {
        const prevValue = equity[i - 1].value;
        dailyReturns.push((portfolioValue - prevValue) / prevValue);
      }

      // Generate signal
      let sig = null;
      try {
        sig = signal(bar, i, frozenBars, frozenParams);
      } catch { /* ignore signal errors */ }

      if (sig === 'buy' && position === 0) {
        // Buy with all available cash
        const qty = Math.floor(cash / bar.close / 100) * 100; // Round to lots of 100
        if (qty > 0) {
          position = qty;
          entryPrice = bar.close;
          cash -= qty * bar.close;
          trades.push({ date: bar.date, side: 'buy', price: bar.close, quantity: qty });
        }
      } else if (sig === 'sell' && position > 0) {
        const profit = (bar.close - entryPrice) * position;
        cash += position * bar.close;
        trades.push({ date: bar.date, side: 'sell', price: bar.close, quantity: position, profit });
        position = 0;
        entryPrice = 0;
      }
    }

    // Force close remaining position at last bar
    if (position > 0) {
      const lastBar = bars[bars.length - 1];
      const profit = (lastBar.close - entryPrice) * position;
      cash += position * lastBar.close;
      trades.push({ date: lastBar.date, side: 'sell', price: lastBar.close, quantity: position, profit, forced: true });
      position = 0;
    }

    // 4. Compute metrics
    const finalCapital = cash;
    const totalReturn = (finalCapital - initialCapital) / initialCapital;
    const tradingDays = bars.length;
    const annualizedReturn = Math.pow(1 + totalReturn, 252 / tradingDays) - 1;
    const winningTrades = trades.filter(t => t.side === 'sell' && (t.profit || 0) > 0);
    const losingTrades = trades.filter(t => t.side === 'sell' && (t.profit || 0) <= 0);
    const sellCount = trades.filter(t => t.side === 'sell').length;
    const winRate = sellCount > 0 ? winningTrades.length / sellCount : 0;

    // Sharpe ratio (annualized, risk-free rate = 0)
    const avgReturn = dailyReturns.length > 0 ? dailyReturns.reduce((a, b) => a + b, 0) / dailyReturns.length : 0;
    const stdReturn = dailyReturns.length > 1
      ? Math.sqrt(dailyReturns.reduce((s, r) => s + (r - avgReturn) ** 2, 0) / (dailyReturns.length - 1))
      : 0;
    const sharpeRatio = stdReturn > 0 ? (avgReturn / stdReturn) * Math.sqrt(252) : 0;

    const result = {
      symbol,
      startDate,
      endDate,
      initialCapital,
      finalCapital: parseFloat(finalCapital.toFixed(2)),
      totalReturn: parseFloat((totalReturn * 100).toFixed(2)),
      annualizedReturn: parseFloat((annualizedReturn * 100).toFixed(2)),
      maxDrawdown: parseFloat((maxDrawdown * 100).toFixed(2)),
      sharpeRatio: parseFloat(sharpeRatio.toFixed(4)),
      totalTrades: trades.length,
      winningTrades: winningTrades.length,
      losingTrades: losingTrades.length,
      winRate: parseFloat((winRate * 100).toFixed(2)),
      trades,
      equity,
      tradingDays
    };

    logger.info('Backtest completed', { symbol, totalReturn: result.totalReturn, sharpe: result.sharpeRatio });
    return result;
  }
}

module.exports = new BacktestEngine();
