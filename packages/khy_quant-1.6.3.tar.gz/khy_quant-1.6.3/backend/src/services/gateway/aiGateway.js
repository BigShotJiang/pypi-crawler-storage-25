/**
 * AI Gateway — central service that routes AI requests through
 * a priority-ordered cascade of adapters:
 *   1. CLI tools (Claude Code, Codex, Aider)
 *   2. Cloud API providers (MultiFreeService)
 *   3. Web relay (manual browser-based relay, always available)
 *
 * Singleton export — matches project convention.
 */
const cliToolAdapter = require('./adapters/cliToolAdapter');
const kiroAdapter = require('./adapters/kiroAdapter');
const cursorAdapter = require('./adapters/cursorAdapter');
const traeAdapter = require('./adapters/traeAdapter');
const claudeAdapter = require('./adapters/claudeAdapter');
const codexAdapter = require('./adapters/codexAdapter');
const windsurfAdapter = require('./adapters/windsurfAdapter');
const vscodeAdapter = require('./adapters/vscodeAdapter');
const ollamaAdapter = require('./adapters/ollamaAdapter');
const apiAdapter = require('./adapters/apiAdapter');
const webRelayAdapter = require('./adapters/webRelayAdapter');

// ── Error classification ─────────────────────────────────────────────
function classifyError(status, message = '') {
  if (status === 401 || status === 403) return 'auth';
  if (status === 429) return 'rate_limit';
  if (status === 400) return 'bad_request';
  if (status === 529) return 'overloaded';
  if (status >= 500 && status < 600) return 'server_error';

  const msg = (message || '').toLowerCase();
  if (msg.includes('etimedout') || msg.includes('timeout') || msg.includes('aborted')) return 'timeout';
  if (msg.includes('econnrefused') || msg.includes('enotfound') || msg.includes('network')) return 'network';
  if (msg.includes('rate') && msg.includes('limit')) return 'rate_limit';
  if (msg.includes('unauthorized') || /invalid.*key/i.test(msg) || msg.includes('api key')) return 'auth';

  return 'unknown';
}

class AIGateway {
  constructor() {
    this._adapters = [
      { key: 'cli', adapter: cliToolAdapter, priority: 1, enabled: true },
      { key: 'kiro', adapter: kiroAdapter, priority: 2, enabled: true },
      { key: 'cursor', adapter: cursorAdapter, priority: 3, enabled: true },
      { key: 'trae', adapter: traeAdapter, priority: 4, enabled: true },
      { key: 'claude', adapter: claudeAdapter, priority: 5, enabled: true },
      { key: 'codex', adapter: codexAdapter, priority: 6, enabled: true },
      { key: 'windsurf', adapter: windsurfAdapter, priority: 7, enabled: true },
      { key: 'vscode', adapter: vscodeAdapter, priority: 8, enabled: true },
      { key: 'ollama', adapter: ollamaAdapter, priority: 9, enabled: true },
      { key: 'api', adapter: apiAdapter, priority: 10, enabled: true },
      { key: 'relay', adapter: webRelayAdapter, priority: 11, enabled: true },
    ];
    this._initialized = false;
    this._initPromise = null;
  }

  /**
   * Initialize the gateway: detect available adapters.
   * Safe to call multiple times (idempotent after first, race-safe).
   */
  async init() {
    if (this._initialized) return;
    if (this._initPromise) return this._initPromise;
    this._initPromise = this._doInit();
    return this._initPromise;
  }

  async _doInit() {

    // Respect environment toggles
    if (process.env.GATEWAY_CLI_ENABLED === 'false') {
      this._adapters.find(a => a.key === 'cli').enabled = false;
    }
    if (process.env.GATEWAY_OLLAMA_ENABLED === 'false') {
      this._adapters.find(a => a.key === 'ollama').enabled = false;
    }
    if (process.env.GATEWAY_RELAY_ENABLED === 'false') {
      this._adapters.find(a => a.key === 'relay').enabled = false;
    }

    // Respect IDE adapter toggles
    for (const ideKey of ['kiro', 'cursor', 'trae', 'claude', 'codex', 'windsurf', 'vscode']) {
      const envKey = `GATEWAY_${ideKey.toUpperCase()}_ENABLED`;
      if (process.env[envKey] === 'false') {
        const entry = this._adapters.find(a => a.key === ideKey);
        if (entry) entry.enabled = false;
      }
    }

    // Run detection on each enabled adapter
    for (const entry of this._adapters) {
      if (!entry.enabled) continue;
      try {
        // Async detection for adapters that need network calls
        if (entry.adapter.detectAsync) {
          entry.available = await entry.adapter.detectAsync();
        } else {
          entry.available = entry.adapter.detect();
        }
      } catch {
        entry.available = false;
      }
    }

    this._initialized = true;
    this._initPromise = null;
  }

  /**
   * Generate a response by cascading through adapters.
   * Returns the same shape as MultiFreeService.generateResponse().
   */
  async generate(prompt, options = {}) {
    if (!this._initialized) await this.init();

    const allAttempts = [];

    // Use preferred adapter/model from env if set
    const preferredAdapter = process.env.GATEWAY_PREFERRED_ADAPTER;
    const preferredModel = process.env.GATEWAY_PREFERRED_MODEL;

    // Auto mode: select best adapter for this task
    let orderedAdapters = this._adapters;
    if (preferredAdapter === 'auto') {
      const autoResult = this.autoSelectModel(options.taskType || 'conversation');
      if (autoResult.adapter !== 'relay') {
        options = { ...options, model: autoResult.model || options.model };
        // Reorder to try auto-selected first
        orderedAdapters = [
          ...this._adapters.filter(a => a.key === autoResult.adapter),
          ...this._adapters.filter(a => a.key !== autoResult.adapter),
        ];
      }
    } else if (preferredAdapter) {
      if (!options.model && preferredModel) {
        options = { ...options, model: preferredModel };
      }
      orderedAdapters = [
        ...this._adapters.filter(a => a.key === preferredAdapter),
        ...this._adapters.filter(a => a.key !== preferredAdapter),
      ];
    } else {
      // Habit-based preference: if no env override, use learned preference
      let habitPreferred = null;
      try {
        const { getPreferredModel } = require('../usageHabitService');
        habitPreferred = getPreferredModel('conversation');
      } catch { /* best effort */ }

      if (habitPreferred && habitPreferred.adapter) {
        orderedAdapters = [
          ...this._adapters.filter(a => a.key === habitPreferred.adapter),
          ...this._adapters.filter(a => a.key !== habitPreferred.adapter),
        ];
        if (habitPreferred.model && !options.model) {
          options = { ...options, model: habitPreferred.model };
        }
      }
    }

    for (const entry of orderedAdapters) {
      if (!entry.enabled) continue;

      // Re-check availability for api adapter (keys might have changed)
      if (entry.key === 'api') {
        entry.available = entry.adapter.detect();
      }

      if (!entry.available && entry.key !== 'relay') continue;

      // Attempt with one auto-retry for transient errors
      for (let attempt = 0; attempt < 2; attempt++) {
        try {
          const result = await entry.adapter.generate(prompt, { ...options });
          if (result.attempts) allAttempts.push(...result.attempts);

          if (result.success) {
            return {
              success: true,
              content: result.content,
              provider: result.provider,
              adapter: result.adapter,
              model: result.model || null,
              tokenUsage: result.tokenUsage || null,
              attempts: allAttempts,
            };
          }

          // Not success but no exception — extract error info if present
          const errType = result.errorType || classifyError(result.statusCode, result.error);
          allAttempts.push({
            provider: entry.adapter.getStatus().name,
            success: false,
            error: result.error || 'unknown',
            statusCode: result.statusCode,
            errorType: errType,
          });
          break; // non-exception failure, move to next adapter
        } catch (err) {
          const status = err.status || err.statusCode || err.response?.status;
          const errorType = classifyError(status, err.message);

          allAttempts.push({
            provider: entry.adapter.getStatus().name,
            success: false,
            error: err.message,
            statusCode: status,
            errorType,
          });

          // Auto-retry once for transient errors (rate_limit, server_error, overloaded)
          if (attempt === 0 && (errorType === 'rate_limit' || errorType === 'server_error' || errorType === 'overloaded')) {
            const delay = errorType === 'rate_limit' ? 3000 : 1500;
            await new Promise(r => setTimeout(r, delay));
            continue; // retry same adapter
          }
          break; // non-retryable or already retried, move to next adapter
        }
      }
    }

    // All adapters failed — build detailed failure report
    return {
      success: false,
      content: '所有 AI 通道均不可用。请检查 CLI 工具、API 密钥或启动 Web 中转服务。',
      provider: 'none',
      adapter: 'none',
      attempts: allAttempts,
      errorType: allAttempts.length > 0 ? allAttempts[allAttempts.length - 1].errorType : 'unknown',
    };
  }

  /**
   * Auto-select the best available model.
   * Priority: user preference > habit > capability score > priority order.
   * @param {string} [taskType] - 'conversation', 'analysis', 'code', 'reasoning'
   * @returns {{ adapter: string, model: string|null, reason: string }}
   */
  autoSelectModel(taskType = 'conversation') {
    if (!this._initialized) {
      // Quick sync check
      for (const entry of this._adapters) {
        if (entry.enabled && entry.adapter.detect()) {
          entry.available = true;
        }
      }
    }

    // 1. Check user preference
    const preferred = process.env.GATEWAY_PREFERRED_ADAPTER;
    if (preferred && preferred !== 'auto') {
      const entry = this._adapters.find(a => a.key === preferred && a.enabled);
      if (entry && (entry.available || entry.adapter.detect())) {
        return {
          adapter: preferred,
          model: process.env.GATEWAY_PREFERRED_MODEL || null,
          reason: 'user_preference',
        };
      }
    }

    // 2. Check habit-based preference
    try {
      const { getPreferredModel } = require('../usageHabitService');
      const habit = getPreferredModel(taskType);
      if (habit && habit.adapter) {
        const entry = this._adapters.find(a => a.key === habit.adapter && a.enabled);
        if (entry && entry.available) {
          return { adapter: habit.adapter, model: habit.model || null, reason: 'learned_habit' };
        }
      }
    } catch { /* best effort */ }

    // 3. Task-based capability matching
    const TASK_PREFERENCES = {
      reasoning: ['claude', 'codex', 'cursor', 'api', 'ollama'],
      code: ['claude', 'codex', 'cursor', 'kiro', 'api'],
      analysis: ['api', 'claude', 'cursor', 'ollama', 'windsurf'],
      conversation: null, // use default priority
    };

    const taskOrder = TASK_PREFERENCES[taskType];
    if (taskOrder) {
      for (const key of taskOrder) {
        const entry = this._adapters.find(a => a.key === key && a.enabled && a.available);
        if (entry) {
          return { adapter: key, model: null, reason: `best_for_${taskType}` };
        }
      }
    }

    // 4. Fallback: first available by priority
    for (const entry of this._adapters) {
      if (!entry.enabled || !entry.available) continue;
      if (entry.key === 'relay') continue; // relay is last resort
      return { adapter: entry.key, model: null, reason: 'priority_order' };
    }

    // 5. Relay as absolute fallback
    return { adapter: 'relay', model: null, reason: 'fallback' };
  }

  /**
   * Generate with a specific sub-model (for delegation from main model).
   * @param {string} prompt
   * @param {string} adapterKey - specific adapter to use
   * @param {object} [options]
   * @returns {Promise<object>}
   */
  async generateWithSubModel(prompt, adapterKey, options = {}) {
    if (!this._initialized) await this.init();

    const entry = this._adapters.find(a => a.key === adapterKey && a.enabled);
    if (!entry || !entry.available) {
      return {
        success: false,
        content: `Sub-model adapter "${adapterKey}" is not available.`,
        provider: 'none',
        adapter: adapterKey,
        attempts: [{ provider: adapterKey, success: false, error: 'not_available' }],
      };
    }

    try {
      const result = await entry.adapter.generate(prompt, options);
      return result;
    } catch (err) {
      return {
        success: false,
        content: err.message,
        provider: entry.adapter.getStatus().name,
        adapter: adapterKey,
        attempts: [{ provider: adapterKey, success: false, error: err.message }],
      };
    }
  }

  /**
   * Get status of all adapters (for display).
   */
  getStatus() {
    return this._adapters.map(entry => {
      const status = entry.adapter.getStatus();
      return {
        ...status,
        enabled: entry.enabled,
        priority: entry.priority,
      };
    });
  }

  /**
   * Get the first available adapter (for banner display).
   * Returns status object with activeModel if a preferred model is set.
   */
  getActiveAdapter() {
    const preferredAdapter = process.env.GATEWAY_PREFERRED_ADAPTER;
    const preferredModel = process.env.GATEWAY_PREFERRED_MODEL;

    if (!this._initialized) {
      // Quick sync detection (no async needed for status display)
      try {
        for (const entry of this._adapters) {
          if (!entry.enabled) continue;
          if (entry.adapter.detect()) {
            const status = entry.adapter.getStatus();
            status.activeModel = preferredModel || null;
            return status;
          }
        }
      } catch { /* ignore */ }
      return null;
    }

    // If preferred adapter is set, try it first
    if (preferredAdapter) {
      const entry = this._adapters.find(a => a.key === preferredAdapter && a.enabled);
      if (entry) {
        const status = entry.adapter.getStatus();
        if (status.available) {
          status.activeModel = preferredModel || null;
          return status;
        }
      }
    }

    for (const entry of this._adapters) {
      if (!entry.enabled) continue;
      const status = entry.adapter.getStatus();
      if (status.available) {
        status.activeModel = preferredModel || null;
        return status;
      }
    }
    return null;
  }

  /**
   * Get the web relay adapter directly (for `gateway relay` command).
   */
  getRelayAdapter() {
    return webRelayAdapter;
  }

  /**
   * Get a specific adapter by key (for IDE commands).
   */
  getAdapter(key) {
    const entry = this._adapters.find(a => a.key === key);
    return entry ? entry.adapter : null;
  }

  /**
   * Generate using a specific adapter + model (for IDE commands).
   */
  async generateWithAdapter(adapterKey, prompt, options = {}) {
    const adapter = this.getAdapter(adapterKey);
    if (!adapter) throw new Error(`Adapter "${adapterKey}" not found`);
    return adapter.generate(prompt, options);
  }

  /**
   * List models from a specific IDE adapter.
   */
  async listModels(adapterKey) {
    const adapter = this.getAdapter(adapterKey);
    if (!adapter?.listModels) return [];
    return adapter.listModels();
  }

  /**
   * Tear down all adapters.
   */
  async destroy() {
    for (const entry of this._adapters) {
      if (entry.adapter.destroy) {
        await entry.adapter.destroy();
      }
    }
    this._initialized = false;
  }
}

const gateway = new AIGateway();
gateway.classifyError = classifyError;
module.exports = gateway;
