/**
 * Uninstall Service — clean removal of KHY-Quant data.
 *
 * Removes all user data stored by KHY-Quant:
 *   - ~/.khyquant/ (config, conversations, credentials)
 *   - ~/.khyquant_history (command history)
 *   - OS temp files (khy_*, khyquant_*)
 *   - Backend temp/logs/cache directories
 *
 * Does NOT remove:
 *   - The pip package itself (user should run pip uninstall)
 *   - node_modules (removed when pip package is removed)
 */
const fs = require('fs');
const path = require('path');
const os = require('os');

const HOME = os.homedir();
const KHY_DIR = path.join(HOME, '.khyquant');
const HISTORY_FILE = path.join(HOME, '.khyquant_history');
const BACKEND_ROOT = process.env.KHYQUANT_ROOT || path.resolve(__dirname, '..', '..');

/**
 * List all KHY-Quant data locations and their sizes.
 */
function listDataLocations() {
  const locations = [];

  // ~/.khyquant/
  locations.push({
    path: KHY_DIR,
    type: 'directory',
    description: 'Configuration, credentials, conversations',
    exists: fs.existsSync(KHY_DIR),
    size: dirSizeRecursive(KHY_DIR),
  });

  // ~/.khyquant_history
  locations.push({
    path: HISTORY_FILE,
    type: 'file',
    description: 'Command history',
    exists: fs.existsSync(HISTORY_FILE),
    size: safeSize(HISTORY_FILE),
  });

  // backend/temp/
  const tempDir = path.join(BACKEND_ROOT, 'temp');
  locations.push({
    path: tempDir,
    type: 'directory',
    description: 'Temporary files',
    exists: fs.existsSync(tempDir),
    size: dirSizeRecursive(tempDir),
  });

  // backend/logs/
  const logsDir = path.join(BACKEND_ROOT, 'logs');
  locations.push({
    path: logsDir,
    type: 'directory',
    description: 'Log files',
    exists: fs.existsSync(logsDir),
    size: dirSizeRecursive(logsDir),
  });

  // backend/data/cache/
  const cacheDir = path.join(BACKEND_ROOT, 'data', 'cache');
  locations.push({
    path: cacheDir,
    type: 'directory',
    description: 'Data cache',
    exists: fs.existsSync(cacheDir),
    size: dirSizeRecursive(cacheDir),
  });

  // OS temp
  const tmpFiles = countTempFiles();
  locations.push({
    path: os.tmpdir(),
    type: 'partial',
    description: `OS temp (khy_* files: ${tmpFiles.count})`,
    exists: tmpFiles.count > 0,
    size: tmpFiles.size,
  });

  // .khy_quant_bootstrapped marker
  const marker = path.join(BACKEND_ROOT, '.khy_quant_bootstrapped');
  locations.push({
    path: marker,
    type: 'file',
    description: 'Bootstrap marker',
    exists: fs.existsSync(marker),
    size: safeSize(marker),
  });

  return locations;
}

/**
 * Remove all KHY-Quant data.
 * @param {object} opts
 * @param {boolean} opts.keepCredentials - Keep credentials.json
 * @returns {{ removed: string[], errors: string[], totalBytes: number }}
 */
function cleanAll(opts = {}) {
  const removed = [];
  const errors = [];
  let totalBytes = 0;

  // Remove temp and cache dirs (safe — always regenerated)
  for (const relDir of ['temp', 'logs', 'data/cache', 'ml/data/cache']) {
    const dirPath = path.join(BACKEND_ROOT, relDir);
    if (fs.existsSync(dirPath)) {
      try {
        const size = dirSizeRecursive(dirPath);
        rmRecursive(dirPath, true); // keep the directory, remove contents
        removed.push(dirPath);
        totalBytes += size;
      } catch (e) { errors.push(`${dirPath}: ${e.message}`); }
    }
  }

  // Remove OS temp files
  const tmpClean = cleanTempFiles();
  totalBytes += tmpClean.size;
  if (tmpClean.count > 0) removed.push(`OS temp: ${tmpClean.count} files`);

  // Remove history
  if (fs.existsSync(HISTORY_FILE)) {
    try {
      const size = safeSize(HISTORY_FILE);
      fs.unlinkSync(HISTORY_FILE);
      removed.push(HISTORY_FILE);
      totalBytes += size;
    } catch (e) { errors.push(`${HISTORY_FILE}: ${e.message}`); }
  }

  // Remove bootstrap marker
  const marker = path.join(BACKEND_ROOT, '.khy_quant_bootstrapped');
  if (fs.existsSync(marker)) {
    try { fs.unlinkSync(marker); removed.push(marker); } catch { /* skip */ }
  }

  // Remove ~/.khyquant/ (the big one)
  if (fs.existsSync(KHY_DIR)) {
    if (opts.keepCredentials) {
      // Remove everything except credentials.json
      try {
        const entries = fs.readdirSync(KHY_DIR);
        for (const entry of entries) {
          if (entry === 'credentials.json') continue;
          const fp = path.join(KHY_DIR, entry);
          const size = safeSize(fp) || dirSizeRecursive(fp);
          try {
            const stat = fs.statSync(fp);
            if (stat.isDirectory()) { rmRecursive(fp); } else { fs.unlinkSync(fp); }
            removed.push(fp);
            totalBytes += size;
          } catch (e) { errors.push(`${fp}: ${e.message}`); }
        }
      } catch (e) { errors.push(`${KHY_DIR}: ${e.message}`); }
    } else {
      try {
        const size = dirSizeRecursive(KHY_DIR);
        rmRecursive(KHY_DIR);
        removed.push(KHY_DIR);
        totalBytes += size;
      } catch (e) { errors.push(`${KHY_DIR}: ${e.message}`); }
    }
  }

  return { removed, errors, totalBytes };
}

// ── Helpers ─────────────────────────────────────────────────────────────

function safeSize(filePath) {
  try { return fs.statSync(filePath).size; } catch { return 0; }
}

function dirSizeRecursive(dirPath) {
  let total = 0;
  try {
    for (const entry of fs.readdirSync(dirPath)) {
      const fp = path.join(dirPath, entry);
      try {
        const stat = fs.statSync(fp);
        if (stat.isDirectory()) total += dirSizeRecursive(fp);
        else total += stat.size;
      } catch { /* skip */ }
    }
  } catch { /* dir doesn't exist */ }
  return total;
}

function rmRecursive(dirPath, contentsOnly = false) {
  if (!fs.existsSync(dirPath)) return;
  for (const entry of fs.readdirSync(dirPath)) {
    const fp = path.join(dirPath, entry);
    const stat = fs.statSync(fp);
    if (stat.isDirectory()) {
      rmRecursive(fp);
    } else {
      fs.unlinkSync(fp);
    }
  }
  if (!contentsOnly) fs.rmdirSync(dirPath);
}

function countTempFiles() {
  let count = 0, size = 0;
  try {
    for (const entry of fs.readdirSync(os.tmpdir())) {
      if (entry.startsWith('khy_') || entry.startsWith('khyquant_')) {
        count++;
        size += safeSize(path.join(os.tmpdir(), entry));
      }
    }
  } catch { /* ignore */ }
  return { count, size };
}

function cleanTempFiles() {
  let count = 0, size = 0;
  try {
    for (const entry of fs.readdirSync(os.tmpdir())) {
      if (entry.startsWith('khy_') || entry.startsWith('khyquant_')) {
        const fp = path.join(os.tmpdir(), entry);
        try {
          const s = safeSize(fp);
          fs.unlinkSync(fp);
          count++; size += s;
        } catch { /* skip */ }
      }
    }
  } catch { /* ignore */ }
  return { count, size };
}

module.exports = { listDataLocations, cleanAll };
