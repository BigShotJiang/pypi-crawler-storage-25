const axios = require('axios');
const jwt = require('jsonwebtoken');

class MultiFreeService {
  constructor() {
    this.baiduToken = null;
    this.baiduTokenExpireAt = 0;

    this.providers = {
      google: {
        name: 'Google Gemini',
        apiKey: process.env.GOOGLE_GEMINI_API_KEY || process.env.GEMINI_API_KEY,
        enabled: !!(process.env.GOOGLE_GEMINI_API_KEY || process.env.GEMINI_API_KEY),
        model: 'gemini-2.5-flash',
        priority: 1,
        supportsVision: true,
      },
      groq: {
        name: 'Groq',
        apiKey: process.env.GROQ_API_KEY,
        enabled: !!process.env.GROQ_API_KEY,
        model: 'llama-3.3-70b-versatile',
        priority: 2,
        supportsVision: false,
      },
      openrouter: {
        name: 'OpenRouter',
        apiKey: process.env.OPENROUTER_API_KEY,
        enabled: !!process.env.OPENROUTER_API_KEY,
        model: 'meta-llama/llama-3.3-70b-instruct',
        priority: 3,
        supportsVision: false,
      },
      openai: {
        name: 'OpenAI',
        apiKey: process.env.OPENAI_API_KEY,
        enabled: !!process.env.OPENAI_API_KEY,
        model: 'gpt-4o-mini',
        priority: 4,
        supportsVision: true,
      },
      anthropic: {
        name: 'Anthropic',
        apiKey: process.env.ANTHROPIC_API_KEY,
        enabled: !!process.env.ANTHROPIC_API_KEY,
        model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-4-6',
        priority: 4,
        supportsVision: true,
        availableModels: [
          { id: 'claude-opus-4-6', name: 'Claude Opus 4.6', tier: 'ultra' },
          { id: 'claude-sonnet-4-6', name: 'Claude Sonnet 4.6', tier: 'high' },
          { id: 'claude-haiku-4-5-20251001', name: 'Claude Haiku 4.5', tier: 'medium' },
        ],
      },
      zhipu: {
        name: '智谱AI',
        apiKey: process.env.ZHIPU_API_KEY,
        enabled: !!process.env.ZHIPU_API_KEY,
        model: process.env.ZHIPU_MODEL || 'glm-4-plus',
        priority: 5,
        supportsVision: true,
        availableModels: [
          { id: 'glm-4-plus', name: 'GLM-4-Plus', tier: 'ultra' },
          { id: 'glm-4-0520', name: 'GLM-4', tier: 'high' },
          { id: 'glm-4-air', name: 'GLM-4-Air', tier: 'medium' },
          { id: 'glm-4-airx', name: 'GLM-4-AirX', tier: 'high' },
          { id: 'glm-4-long', name: 'GLM-4-Long (1M tokens)', tier: 'high' },
          { id: 'glm-4-flash', name: 'GLM-4-Flash (Free)', tier: 'low' },
          { id: 'glm-4v-plus', name: 'GLM-4V-Plus (Vision)', tier: 'ultra' },
        ],
      },
      xunfei: {
        name: '讯飞星火',
        apiKey: process.env.XUNFEI_API_KEY,
        enabled: !!process.env.XUNFEI_API_KEY,
        model: 'lite',
        priority: 6,
        supportsVision: false,
      },
      baidu: {
        name: '百度文心',
        apiKey: process.env.BAIDU_API_KEY,
        secretKey: process.env.BAIDU_SECRET_KEY || process.env.BAIDU_API_SECRET || process.env.BAIDU_SECRET || '',
        enabled: !!process.env.BAIDU_API_KEY,
        model: 'ERNIE-Bot',
        priority: 7,
        supportsVision: false,
      },
      alibaba: {
        name: '通义千问',
        apiKey: process.env.ALIBABA_API_KEY || process.env.DASHSCOPE_API_KEY,
        enabled: !!(process.env.ALIBABA_API_KEY || process.env.DASHSCOPE_API_KEY),
        model: process.env.QWEN_MODEL || 'qwen-max',
        priority: 8,
        supportsVision: true,
        availableModels: [
          { id: 'qwen-max', name: 'Qwen-Max', tier: 'ultra' },
          { id: 'qwen-plus', name: 'Qwen-Plus', tier: 'high' },
          { id: 'qwen-turbo', name: 'Qwen-Turbo', tier: 'medium' },
          { id: 'qwen-long', name: 'Qwen-Long (10M tokens)', tier: 'high' },
          { id: 'qwen-vl-max', name: 'Qwen-VL-Max (Vision)', tier: 'ultra' },
          { id: 'qwen-vl-plus', name: 'Qwen-VL-Plus (Vision)', tier: 'high' },
          { id: 'qwen-coder-plus', name: 'Qwen-Coder-Plus', tier: 'high' },
          { id: 'qwen2.5-72b-instruct', name: 'Qwen2.5-72B', tier: 'ultra' },
          { id: 'qwen2.5-32b-instruct', name: 'Qwen2.5-32B', tier: 'high' },
          { id: 'qwen2.5-14b-instruct', name: 'Qwen2.5-14B', tier: 'medium' },
          { id: 'qwen2.5-7b-instruct', name: 'Qwen2.5-7B', tier: 'low' },
        ],
      },
      huggingface: {
        name: 'HuggingFace',
        apiKey: process.env.HUGGINGFACE_TOKEN,
        enabled: !!process.env.HUGGINGFACE_TOKEN,
        model: 'mistralai/Mistral-7B-Instruct-v0.2',
        priority: 9,
        supportsVision: false,
      }
    };
  }

  getAvailableProviders() {
    return Object.entries(this.providers)
      .filter(([, provider]) => provider.enabled)
      .sort(([, a], [, b]) => a.priority - b.priority)
      .map(([key, provider]) => ({ key, ...provider }));
  }

  getAvailableProvider() {
    const providers = this.getAvailableProviders();
    return providers.length > 0 ? providers[0] : null;
  }

  getStatus() {
    const available = this.getAvailableProviders();
    return {
      available: available.length > 0,
      provider: available[0]?.name || 'local-fallback',
      configuredProviders: available.map((p) => p.name),
      message: available.length > 0
        ? `${available.length} provider(s) configured`
        : 'No cloud providers configured, using local fallback'
    };
  }

  async testConnection() {
    const availableProviders = this.getAvailableProviders().map((p) => p.name);
    if (availableProviders.length === 0) {
      return {
        success: false,
        message: 'No LLM providers configured',
        provider: 'local-fallback',
        response: null,
        availableProviders,
        results: []
      };
    }

    const result = await this.generateResponse('Reply with one short sentence: connection ok.', {
      temperature: 0,
      maxTokens: 64
    });

    return {
      success: result.success,
      message: result.success ? 'LLM connection test completed' : 'LLM connection test failed',
      provider: result.provider,
      response: result.content,
      availableProviders,
      results: result.attempts || []
    };
  }

  async analyze(payload = {}) {
    const prompt = typeof payload.prompt === 'string' ? payload.prompt : '';
    const stockCode = payload.stockCode || 'UNKNOWN';
    const result = await this.generateResponse(prompt, {
      temperature: payload.temperature ?? 0.4,
      maxTokens: payload.maxTokens ?? 1500
    });

    if (result.success && result.content) {
      return result.content;
    }

    return this.localFallback(payload.agentId, stockCode);
  }

  async generateResponse(prompt, options = {}) {
    const temperature = options.temperature ?? 0.4;
    const maxTokens = options.maxTokens ?? 1024;

    if (!prompt || !prompt.trim()) {
      return {
        success: false,
        content: 'Prompt is empty',
        provider: 'none',
        attempts: []
      };
    }

    const providers = this.getAvailableProviders();
    const attempts = [];

    for (const provider of providers) {
      // Skip non-vision providers when images are present
      if (options.images && options.images.length > 0 && !provider.supportsVision) {
        attempts.push({ provider: provider.name, success: false, error: 'No vision support' });
        continue;
      }

      try {
        const result = await this.callProvider(provider, prompt, { temperature, maxTokens, images: options.images });
        // callProvider now returns { content, tokenUsage } or a plain string (legacy)
        const content = typeof result === 'string' ? result : result?.content;
        const tokenUsage = typeof result === 'object' ? result?.tokenUsage : null;

        if (typeof content === 'string' && content.trim()) {
          attempts.push({ provider: provider.name, success: true });
          return {
            success: true,
            content: content.trim(),
            provider: provider.name,
            model: provider.model,
            tokenUsage: tokenUsage || null,
            attempts,
            availableProviders: providers.map((p) => p.name)
          };
        }

        attempts.push({ provider: provider.name, success: false, error: 'Empty response' });
      } catch (error) {
        attempts.push({ provider: provider.name, success: false, error: error.message });
      }
    }

    return {
      success: false,
      content: this.localFallback('general', 'UNKNOWN'),
      provider: 'local-fallback',
      attempts,
      availableProviders: providers.map((p) => p.name)
    };
  }

  async callProvider(provider, prompt, opts) {
    switch (provider.key) {
      case 'google':
        return this.callGoogle(provider, prompt, opts);
      case 'groq':
        return this.callGroq(provider, prompt, opts);
      case 'openrouter':
        return this.callOpenRouter(provider, prompt, opts);
      case 'openai':
        return this.callOpenAI(provider, prompt, opts);
      case 'anthropic':
        return this.callAnthropic(provider, prompt, opts);
      case 'zhipu':
        return this.callZhipu(provider, prompt, opts);
      case 'xunfei':
        return this.callXunfei(provider, prompt, opts);
      case 'baidu':
        return this.callBaidu(provider, prompt, opts);
      case 'alibaba':
        return this.callAlibaba(provider, prompt, opts);
      case 'huggingface':
        return this.callHuggingFace(provider, prompt, opts);
      default:
        throw new Error(`Unsupported provider: ${provider.key}`);
    }
  }

  async callGoogle(provider, prompt, opts) {
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=${provider.apiKey}`;

    // Build parts: images first (if any), then text
    const parts = [];
    if (opts.images && opts.images.length > 0) {
      for (const img of opts.images) {
        parts.push({ inlineData: { mimeType: img.mimeType, data: img.base64 } });
      }
    }
    parts.push({ text: prompt });

    const response = await axios.post(url, {
      contents: [{ parts }],
      generationConfig: {
        temperature: opts.temperature,
        maxOutputTokens: opts.maxTokens
      }
    }, {
      headers: { 'Content-Type': 'application/json' },
      timeout: 30000
    });

    const content = response.data?.candidates?.[0]?.content?.parts?.[0]?.text || '';
    const meta = response.data?.usageMetadata;
    const tokenUsage = meta ? {
      inputTokens: meta.promptTokenCount || 0,
      outputTokens: meta.candidatesTokenCount || 0,
      totalTokens: meta.totalTokenCount || 0,
    } : null;
    return { content, tokenUsage };
  }

  async callGroq(provider, prompt, opts) {
    const response = await axios.post('https://api.groq.com/openai/v1/chat/completions', {
      model: 'llama-3.3-70b-versatile',
      messages: [{ role: 'user', content: prompt }],
      temperature: opts.temperature,
      max_tokens: opts.maxTokens
    }, {
      headers: {
        Authorization: `Bearer ${provider.apiKey}`,
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });

    const content = response.data?.choices?.[0]?.message?.content || '';
    const usage = response.data?.usage;
    const tokenUsage = usage ? {
      inputTokens: usage.prompt_tokens || 0,
      outputTokens: usage.completion_tokens || 0,
      totalTokens: usage.total_tokens || 0,
    } : null;
    return { content, tokenUsage };
  }

  async callOpenRouter(provider, prompt, opts) {
    const response = await axios.post('https://openrouter.ai/api/v1/chat/completions', {
      model: provider.model,
      messages: [{ role: 'user', content: prompt }],
      temperature: opts.temperature,
      max_tokens: opts.maxTokens
    }, {
      headers: {
        Authorization: `Bearer ${provider.apiKey}`,
        'Content-Type': 'application/json',
        'HTTP-Referer': 'https://khyquant.com',
        'X-Title': 'KHY-Quant'
      },
      timeout: 30000
    });

    const content = response.data?.choices?.[0]?.message?.content || '';
    const usage = response.data?.usage;
    const tokenUsage = usage ? {
      inputTokens: usage.prompt_tokens || 0,
      outputTokens: usage.completion_tokens || 0,
      totalTokens: usage.total_tokens || 0,
    } : null;
    return { content, tokenUsage };
  }

  async callOpenAI(provider, prompt, opts) {
    // Support custom base URL (relay/proxy) via OPENAI_BASE_URL env
    const baseUrl = process.env.OPENAI_BASE_URL || 'https://api.openai.com';

    // Build message content: multimodal array if images present, plain string otherwise
    let messageContent;
    if (opts.images && opts.images.length > 0) {
      messageContent = [
        ...opts.images.map(img => ({
          type: 'image_url',
          image_url: { url: `data:${img.mimeType};base64,${img.base64}`, detail: 'auto' },
        })),
        { type: 'text', text: prompt },
      ];
    } else {
      messageContent = prompt;
    }

    const response = await axios.post(`${baseUrl}/v1/chat/completions`, {
      model: provider.model,
      messages: [{ role: 'user', content: messageContent }],
      temperature: opts.temperature,
      max_tokens: opts.maxTokens
    }, {
      headers: {
        Authorization: `Bearer ${provider.apiKey}`,
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });

    const content = response.data?.choices?.[0]?.message?.content || '';
    const usage = response.data?.usage;
    const tokenUsage = usage ? {
      inputTokens: usage.prompt_tokens || 0,
      outputTokens: usage.completion_tokens || 0,
      totalTokens: usage.total_tokens || 0,
    } : null;
    return { content, tokenUsage };
  }

  async callAnthropic(provider, prompt, opts) {
    // Support custom base URL (relay/proxy) via ANTHROPIC_BASE_URL env
    const baseUrl = process.env.ANTHROPIC_BASE_URL || 'https://api.anthropic.com';
    const isRelay = !baseUrl.includes('api.anthropic.com');

    // Build message content: multimodal array if images present, plain string otherwise
    let messageContent;
    if (opts.images && opts.images.length > 0 && !isRelay) {
      messageContent = [
        ...opts.images.map(img => ({
          type: 'image',
          source: { type: 'base64', media_type: img.mimeType, data: img.base64 },
        })),
        { type: 'text', text: prompt },
      ];
    } else {
      messageContent = prompt;
    }

    const body = {
      model: opts.model || provider.model,
      max_tokens: opts.maxTokens,
      temperature: opts.temperature,
      messages: [{ role: 'user', content: messageContent }],
    };

    // If relay doesn't support thinking, strip it; if official, could add thinking support
    // Relay compatibility: don't include extended_thinking or thinking fields
    if (isRelay) {
      // Some relays fail on unknown fields — keep request minimal
      delete body.thinking;
      delete body.extended_thinking;
    }

    let response;
    try {
      response = await axios.post(`${baseUrl}/v1/messages`, body, {
        headers: {
          'x-api-key': provider.apiKey,
          'anthropic-version': '2024-10-22',
          'Content-Type': 'application/json'
        },
        timeout: 30000
      });
    } catch (err) {
      // If relay returns 400 due to unsupported field, retry with minimal body
      if (isRelay && err.response?.status === 400) {
        // Strip any extra fields and retry
        const minimalBody = {
          model: provider.model,
          max_tokens: opts.maxTokens,
          messages: [{ role: 'user', content: prompt }],
        };
        response = await axios.post(`${baseUrl}/v1/messages`, minimalBody, {
          headers: {
            'x-api-key': provider.apiKey,
            'anthropic-version': '2024-10-22',
            'Content-Type': 'application/json'
          },
          timeout: 30000
        });
      } else {
        throw err;
      }
    }

    // Extract content: handle both thinking blocks and text blocks
    let content = '';
    const contentBlocks = response.data?.content || [];
    for (const block of contentBlocks) {
      if (block.type === 'text') {
        content += block.text;
      }
      // Ignore thinking blocks in output (already streamed separately)
    }
    if (!content) content = response.data?.content?.[0]?.text || '';

    const usage = response.data?.usage;
    const tokenUsage = usage ? {
      inputTokens: usage.input_tokens || 0,
      outputTokens: usage.output_tokens || 0,
      totalTokens: (usage.input_tokens || 0) + (usage.output_tokens || 0),
    } : null;
    return { content, tokenUsage };
  }

  generateZhipuJWT(apiKey) {
    const [id, secret] = apiKey.split('.');
    if (!id || !secret) {
      throw new Error('Invalid Zhipu API key format, expected id.secret');
    }

    const payload = {
      api_key: id,
      exp: Math.round(Date.now() / 1000) + 3600,
      timestamp: Math.round(Date.now() / 1000)
    };

    return jwt.sign(payload, secret, {
      algorithm: 'HS256',
      header: { alg: 'HS256', sign_type: 'SIGN' }
    });
  }

  async callZhipu(provider, prompt, opts) {
    const model = opts.model || provider.model;
    const token = this.generateZhipuJWT(provider.apiKey);

    // Build multimodal content for vision models
    let messageContent = prompt;
    if (opts.images && opts.images.length > 0 && /glm-4v/i.test(model)) {
      messageContent = [
        ...opts.images.map(img => ({
          type: 'image_url',
          image_url: { url: `data:${img.mimeType};base64,${img.base64}` },
        })),
        { type: 'text', text: prompt },
      ];
    }

    const response = await axios.post('https://open.bigmodel.cn/api/paas/v4/chat/completions', {
      model,
      messages: [{ role: 'user', content: messageContent }],
      temperature: opts.temperature,
      max_tokens: opts.maxTokens
    }, {
      headers: {
        Authorization: `Bearer ${token}`,
        'Content-Type': 'application/json'
      },
      timeout: 60000
    });

    const content = response.data?.choices?.[0]?.message?.content || '';
    const usage = response.data?.usage;
    const tokenUsage = usage ? {
      inputTokens: usage.prompt_tokens || 0,
      outputTokens: usage.completion_tokens || 0,
      totalTokens: usage.total_tokens || 0,
    } : null;
    return { content, tokenUsage };
  }

  async callXunfei(provider, prompt, opts) {
    const response = await axios.post('https://spark-api-open.xf-yun.com/v1/chat/completions', {
      model: 'lite',
      messages: [{ role: 'user', content: prompt }],
      temperature: opts.temperature,
      max_tokens: opts.maxTokens
    }, {
      headers: {
        Authorization: `Bearer ${provider.apiKey}`,
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });

    const content = response.data?.choices?.[0]?.message?.content || response.data?.result || '';
    const usage = response.data?.usage;
    const tokenUsage = usage ? {
      inputTokens: usage.prompt_tokens || 0,
      outputTokens: usage.completion_tokens || 0,
      totalTokens: usage.total_tokens || 0,
    } : null;
    return { content, tokenUsage };
  }

  async callAlibaba(provider, prompt, opts) {
    const model = opts.model || provider.model;

    // Use OpenAI-compatible API for newer models (qwen-max, qwen-plus, etc.)
    const useCompatible = /^qwen[2-]/.test(model) || ['qwen-max', 'qwen-plus', 'qwen-turbo', 'qwen-long', 'qwen-vl-max', 'qwen-vl-plus', 'qwen-coder-plus'].includes(model);

    if (useCompatible) {
      const response = await axios.post('https://dashscope.aliyuncs.com/compatible-mode/v1/chat/completions', {
        model,
        messages: [{ role: 'user', content: prompt }],
        temperature: opts.temperature,
        max_tokens: opts.maxTokens,
      }, {
        headers: {
          Authorization: `Bearer ${provider.apiKey}`,
          'Content-Type': 'application/json',
        },
        timeout: 60000,
      });

      const content = response.data?.choices?.[0]?.message?.content || '';
      const usage = response.data?.usage;
      const tokenUsage = usage ? {
        inputTokens: usage.prompt_tokens || 0,
        outputTokens: usage.completion_tokens || 0,
        totalTokens: usage.total_tokens || 0,
      } : null;
      return { content, tokenUsage };
    }

    // Legacy DashScope API
    const response = await axios.post('https://dashscope.aliyuncs.com/api/v1/services/aigc/text-generation/generation', {
      model,
      input: {
        messages: [{ role: 'user', content: prompt }]
      },
      parameters: {
        result_format: 'message',
        temperature: opts.temperature,
        max_tokens: opts.maxTokens
      }
    }, {
      headers: {
        Authorization: `Bearer ${provider.apiKey}`,
        'Content-Type': 'application/json'
      },
      timeout: 30000
    });

    const content = response.data?.output?.choices?.[0]?.message?.content || '';
    const usage = response.data?.usage;
    const tokenUsage = usage ? {
      inputTokens: usage.input_tokens || 0,
      outputTokens: usage.output_tokens || 0,
      totalTokens: usage.total_tokens || (usage.input_tokens || 0) + (usage.output_tokens || 0),
    } : null;
    return { content, tokenUsage };
  }

  async getBaiduAccessToken(provider) {
    const now = Date.now();
    if (this.baiduToken && now < this.baiduTokenExpireAt) {
      return this.baiduToken;
    }

    if (!provider.secretKey) {
      throw new Error('Missing BAIDU_SECRET_KEY for OAuth flow');
    }

    const tokenUrl = `https://aip.baidubce.com/oauth/2.0/token?grant_type=client_credentials&client_id=${provider.apiKey}&client_secret=${provider.secretKey}`;
    const tokenResponse = await axios.get(tokenUrl, { timeout: 20000 });
    const accessToken = tokenResponse.data?.access_token;

    if (!accessToken) {
      throw new Error('Failed to obtain Baidu access token');
    }

    const expiresIn = Number(tokenResponse.data?.expires_in || 2592000);
    this.baiduToken = accessToken;
    this.baiduTokenExpireAt = now + Math.max(60, expiresIn - 300) * 1000;
    return accessToken;
  }

  async callBaidu(provider, prompt, opts) {
    const accessToken = await this.getBaiduAccessToken(provider);
    const response = await axios.post(
      `https://aip.baidubce.com/rpc/2.0/ai_custom/v1/wenxinworkshop/chat/completions?access_token=${accessToken}`,
      {
        messages: [{ role: 'user', content: prompt }],
        temperature: opts.temperature,
        top_p: 0.8
      },
      {
        headers: { 'Content-Type': 'application/json' },
        timeout: 30000
      }
    );

    const content = response.data?.result || '';
    const usage = response.data?.usage;
    const tokenUsage = usage ? {
      inputTokens: usage.prompt_tokens || 0,
      outputTokens: usage.completion_tokens || 0,
      totalTokens: usage.total_tokens || 0,
    } : null;
    return { content, tokenUsage };
  }

  async callHuggingFace(provider, prompt, opts) {
    const response = await axios.post(
      `https://api-inference.huggingface.co/models/${provider.model}`,
      {
        inputs: prompt,
        parameters: {
          max_new_tokens: Math.min(opts.maxTokens, 512),
          temperature: opts.temperature
        }
      },
      {
        headers: {
          Authorization: `Bearer ${provider.apiKey}`,
          'Content-Type': 'application/json'
        },
        timeout: 45000
      }
    );

    let content = '';
    if (Array.isArray(response.data) && response.data[0]?.generated_text) {
      content = response.data[0].generated_text;
    } else if (typeof response.data?.generated_text === 'string') {
      content = response.data.generated_text;
    }

    // HuggingFace does not return token counts; estimate
    const { estimateTokens } = require('./tokenUsageService');
    const tokenUsage = {
      inputTokens: estimateTokens(prompt),
      outputTokens: estimateTokens(content),
      totalTokens: estimateTokens(prompt) + estimateTokens(content),
    };
    return { content, tokenUsage };
  }

  localFallback(agentId = 'general', stockCode = 'UNKNOWN') {
    const templates = {
      fundamentals: `【基本面分析】${stockCode} 估值与盈利能力处于可追踪区间，建议结合季报数据和行业对比后再做加仓决策。`,
      market: `【市场分析】${stockCode} 当前处于震荡整理结构，建议等待放量突破信号确认后再积极布局。`,
      social: `【情绪分析】${stockCode} 市场情绪分歧较大，建议避免情绪化操作，严格执行既定交易规则。`,
      news: `【新闻分析】${stockCode} 当前暂无明确单边催化剂，建议密切关注官方公告及政策变化动向。`,
      strategy: `【策略分析】${stockCode} 适合采用分批建仓策略，严格设置止损位并控制风险预算。`,
      risk: `【风险分析】${stockCode} 主要风险来自波动率扩张和流动性变化，建议保持保守仓位管理。`
    };

    return templates[agentId] || `【综合分析】${stockCode} 在线大模型服务暂时不可用，已返回本地规则兜底分析结果。`;
  }
}

module.exports = MultiFreeService;
