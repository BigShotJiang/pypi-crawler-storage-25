/**
 * Hardware Profile Service — detect and profile hardware capabilities.
 *
 * Guides model selection, memory limits, and feature enablement
 * based on actual hardware rather than guesswork.
 *
 * Profiles:
 *   - server-minimal: 4C/4G Ubuntu VPS (lightweight mode)
 *   - desktop-cpu:    i5/Ryzen, 8-16G RAM, no GPU
 *   - desktop-gpu:    with NVIDIA GPU (4-8G VRAM)
 *   - workstation:    32G+ RAM, 12G+ VRAM
 */
const os = require('os');
const { execSync } = require('child_process');

let _cachedProfile = null;

/**
 * Detect full hardware profile.
 * @returns {object} Complete hardware profile
 */
function detectProfile() {
  if (_cachedProfile) return _cachedProfile;

  const totalRamMB = Math.round(os.totalmem() / (1024 * 1024));
  const freeRamMB = Math.round(os.freemem() / (1024 * 1024));
  const totalRamGB = Math.round(totalRamMB / 1024);
  const cpuCount = os.cpus().length;
  const cpuModel = os.cpus()[0]?.model?.trim() || 'unknown';
  const platform = os.platform();
  const arch = os.arch();

  // Detect CPU generation and capabilities
  const cpuInfo = parseCpuInfo(cpuModel);

  // Detect GPU
  const gpu = detectGpu();

  // Detect disk space
  const disk = detectDisk();

  // Detect swap
  const swap = detectSwap();

  // Determine profile tier
  const profile = classifyProfile({ totalRamGB, cpuCount, gpu, cpuInfo });

  // Calculate safe limits
  const limits = calculateLimits(profile, { totalRamMB, freeRamMB, cpuCount, gpu });

  // Determine recommended local models
  const localModels = recommendLocalModels(profile, { totalRamGB, gpu, cpuInfo });

  _cachedProfile = {
    profile,
    cpu: {
      model: cpuModel,
      cores: cpuCount,
      generation: cpuInfo.generation,
      brand: cpuInfo.brand,
      hasAvx2: cpuInfo.hasAvx2,
    },
    memory: {
      totalMB: totalRamMB,
      totalGB: totalRamGB,
      freeMB: freeRamMB,
      freeGB: Math.round(freeRamMB / 1024),
    },
    gpu,
    disk,
    swap,
    platform,
    arch,
    limits,
    localModels,
    isServer: profile === 'server-minimal' || profile === 'server-standard',
    isLightweight: totalRamGB <= 4 || profile === 'server-minimal',
  };

  return _cachedProfile;
}

/**
 * Parse CPU model string for useful info.
 */
function parseCpuInfo(cpuModel) {
  const lower = cpuModel.toLowerCase();
  let brand = 'unknown', generation = 0, hasAvx2 = false;

  // Intel detection
  const intelMatch = cpuModel.match(/i([3579])-(\d{2,5})/);
  if (intelMatch) {
    brand = `Intel Core i${intelMatch[1]}`;
    const modelNum = parseInt(intelMatch[2]);
    // Intel generations: 10xxx=10th, 11xxx=11th, 12xxx=12th, 13xxx=13th, 14xxx=14th
    if (modelNum >= 14000) generation = 14;
    else if (modelNum >= 13000) generation = 13;
    else if (modelNum >= 12000) generation = 12;
    else if (modelNum >= 11000) generation = 11;
    else if (modelNum >= 10000) generation = 10;
    else if (modelNum >= 8000) generation = 8;
    hasAvx2 = generation >= 4; // Haswell (4th gen) introduced AVX2
  }

  // AMD detection
  const amdMatch = cpuModel.match(/Ryzen\s+([3579])\s+(\d{4})/i);
  if (amdMatch) {
    brand = `AMD Ryzen ${amdMatch[1]}`;
    const modelNum = parseInt(amdMatch[2]);
    if (modelNum >= 7000) generation = 7;
    else if (modelNum >= 5000) generation = 5;
    else if (modelNum >= 3000) generation = 3;
    hasAvx2 = true; // All Ryzen have AVX2
  }

  // ARM detection (Apple Silicon / server ARM)
  if (lower.includes('apple m') || lower.includes('arm') || lower.includes('aarch64')) {
    brand = 'ARM';
    hasAvx2 = false; // ARM uses NEON instead
  }

  // Check AVX2 on Linux if not already determined
  if (!hasAvx2 && os.platform() === 'linux') {
    try {
      const flags = execSync('grep -m1 flags /proc/cpuinfo 2>/dev/null', { encoding: 'utf-8', timeout: 2000 });
      hasAvx2 = flags.includes('avx2');
    } catch { /* ignore */ }
  }

  return { brand, generation, hasAvx2 };
}

/**
 * Detect NVIDIA GPU if present.
 */
function detectGpu() {
  try {
    const output = execSync(
      'nvidia-smi --query-gpu=name,memory.total,driver_version --format=csv,noheader,nounits 2>/dev/null',
      { encoding: 'utf-8', timeout: 5000 }
    ).trim();

    if (!output) return null;

    const [name, vramMB, driver] = output.split(', ').map(s => s.trim());
    return {
      name,
      vramMB: parseInt(vramMB) || 0,
      vramGB: Math.round((parseInt(vramMB) || 0) / 1024),
      driver,
      available: true,
    };
  } catch {
    return null;
  }
}

/**
 * Detect available disk space.
 */
function detectDisk() {
  try {
    const output = execSync('df -BM / 2>/dev/null | tail -1', { encoding: 'utf-8', timeout: 3000 });
    const parts = output.trim().split(/\s+/);
    return {
      totalMB: parseInt(parts[1]) || 0,
      usedMB: parseInt(parts[2]) || 0,
      availMB: parseInt(parts[3]) || 0,
      usePercent: parseInt(parts[4]) || 0,
    };
  } catch {
    return { totalMB: 0, usedMB: 0, availMB: 0, usePercent: 0 };
  }
}

/**
 * Detect swap configuration.
 */
function detectSwap() {
  try {
    const output = execSync('free -m 2>/dev/null | grep Swap', { encoding: 'utf-8', timeout: 2000 });
    const parts = output.trim().split(/\s+/);
    return {
      totalMB: parseInt(parts[1]) || 0,
      usedMB: parseInt(parts[2]) || 0,
      freeMB: parseInt(parts[3]) || 0,
    };
  } catch {
    return { totalMB: 0, usedMB: 0, freeMB: 0 };
  }
}

/**
 * Classify hardware into a named profile.
 */
function classifyProfile({ totalRamGB, cpuCount, gpu, cpuInfo }) {
  if (gpu && gpu.vramGB >= 12) return 'workstation';
  if (gpu && gpu.vramGB >= 4) return 'desktop-gpu';
  if (totalRamGB <= 4 || cpuCount <= 2) return 'server-minimal';
  if (totalRamGB <= 8) return 'server-standard';
  if (totalRamGB <= 16) return 'desktop-cpu';
  if (totalRamGB <= 32) return 'desktop-cpu';     // no GPU, lots of RAM
  return 'workstation';
}

/**
 * Calculate safe resource limits based on profile.
 */
function calculateLimits(profile, { totalRamMB, freeRamMB, cpuCount, gpu }) {
  switch (profile) {
    case 'server-minimal':
      return {
        nodeHeapMB: Math.min(256, Math.round(totalRamMB * 0.3)),
        ollamaRamMB: 0,      // no local model on 4G server
        maxConcurrency: 1,    // single request at a time
        maxAgents: 1,         // no parallel agents
        enableBacktest: false,
        enableLocalModel: false,
        enableMultiAgent: false,
        enablePeriodicScan: false,   // save resources
        cleanupIntervalMs: 7200_000, // every 2h
        shellTimeoutMs: 15_000,
        aiTimeoutMs: 60_000,
      };
    case 'server-standard':
      return {
        nodeHeapMB: Math.min(512, Math.round(totalRamMB * 0.4)),
        ollamaRamMB: Math.min(2048, Math.round(totalRamMB * 0.4)),
        maxConcurrency: 2,
        maxAgents: 2,
        enableBacktest: true,
        enableLocalModel: true,
        enableMultiAgent: false,
        enablePeriodicScan: true,
        cleanupIntervalMs: 3600_000,
        shellTimeoutMs: 30_000,
        aiTimeoutMs: 120_000,
      };
    case 'desktop-cpu':
      return {
        nodeHeapMB: Math.min(1024, Math.round(totalRamMB * 0.3)),
        ollamaRamMB: Math.min(8192, Math.round(totalRamMB * 0.5)),
        maxConcurrency: Math.min(3, cpuCount),
        maxAgents: 3,
        enableBacktest: true,
        enableLocalModel: true,
        enableMultiAgent: true,
        enablePeriodicScan: true,
        cleanupIntervalMs: 7200_000,
        shellTimeoutMs: 30_000,
        aiTimeoutMs: 120_000,
      };
    case 'desktop-gpu':
      return {
        nodeHeapMB: Math.min(1024, Math.round(totalRamMB * 0.25)),
        ollamaRamMB: gpu ? gpu.vramMB : 4096,
        maxConcurrency: Math.min(4, cpuCount),
        maxAgents: 4,
        enableBacktest: true,
        enableLocalModel: true,
        enableMultiAgent: true,
        enablePeriodicScan: true,
        cleanupIntervalMs: 7200_000,
        shellTimeoutMs: 30_000,
        aiTimeoutMs: 120_000,
      };
    case 'workstation':
    default:
      return {
        nodeHeapMB: Math.min(2048, Math.round(totalRamMB * 0.2)),
        ollamaRamMB: gpu ? gpu.vramMB : Math.min(16384, Math.round(totalRamMB * 0.5)),
        maxConcurrency: Math.min(6, cpuCount),
        maxAgents: 6,
        enableBacktest: true,
        enableLocalModel: true,
        enableMultiAgent: true,
        enablePeriodicScan: true,
        cleanupIntervalMs: 7200_000,
        shellTimeoutMs: 30_000,
        aiTimeoutMs: 120_000,
      };
  }
}

/**
 * Recommend local models that will run well on this hardware.
 */
function recommendLocalModels(profile, { totalRamGB, gpu, cpuInfo }) {
  const models = [];

  switch (profile) {
    case 'server-minimal':
      // 4GB RAM: no local models, use API only
      models.push({
        recommendation: 'api-only',
        reason: '4GB RAM 不足以运行本地模型，建议使用云端 API (Gemini/Qwen/GLM 免费额度)',
        models: [],
      });
      break;

    case 'server-standard':
      models.push(
        { id: 'qwen2.5:1.5b', name: 'Qwen 2.5 1.5B', sizeGB: 1.0, reason: '极轻量，8GB 服务器可用' },
        { id: 'phi3:mini', name: 'Phi-3 Mini 3.8B', sizeGB: 2.3, reason: '微软小模型，推理高效' },
      );
      break;

    case 'desktop-cpu':
      // i5 11th, 16GB RAM, no GPU — CPU inference, max ~7B quantized
      if (cpuInfo.hasAvx2) {
        models.push(
          { id: 'qwen2.5:3b', name: 'Qwen 2.5 3B', sizeGB: 2.0, reason: '推荐首选 — 中文好，CPU 友好', recommended: true },
          { id: 'qwen2.5:7b-q4_0', name: 'Qwen 2.5 7B (Q4)', sizeGB: 4.0, reason: '4-bit 量化，16GB 可跑但较慢' },
          { id: 'llama3.2:3b', name: 'Llama 3.2 3B', sizeGB: 2.0, reason: '英文优秀，速度快' },
          { id: 'phi3:mini', name: 'Phi-3 Mini', sizeGB: 2.3, reason: '微软推理模型，平衡好' },
          { id: 'deepseek-coder:1.3b', name: 'DeepSeek Coder 1.3B', sizeGB: 0.8, reason: '代码分析专用，极轻量' },
        );
      } else {
        models.push(
          { id: 'qwen2.5:1.5b', name: 'Qwen 2.5 1.5B', sizeGB: 1.0, reason: '无 AVX2 环境推荐' },
          { id: 'phi3:mini', name: 'Phi-3 Mini', sizeGB: 2.3, reason: '兼容性好' },
        );
      }
      break;

    case 'desktop-gpu':
      // With GPU — can run larger models
      if (gpu && gpu.vramGB >= 8) {
        models.push(
          { id: 'qwen2.5:7b', name: 'Qwen 2.5 7B', sizeGB: 4.7, reason: '推荐首选 — GPU 加速，中文最佳', recommended: true },
          { id: 'llama3.1:8b', name: 'Llama 3.1 8B', sizeGB: 4.7, reason: '通用能力强' },
          { id: 'deepseek-coder-v2:lite', name: 'DeepSeek Coder V2', sizeGB: 8.9, reason: '代码分析利器' },
        );
      } else {
        models.push(
          { id: 'qwen2.5:3b', name: 'Qwen 2.5 3B', sizeGB: 2.0, reason: '推荐 — 小显存首选', recommended: true },
          { id: 'qwen2.5:7b', name: 'Qwen 2.5 7B', sizeGB: 4.7, reason: '需要 6GB+ VRAM' },
        );
      }
      break;

    case 'workstation':
      models.push(
        { id: 'qwen2.5:14b', name: 'Qwen 2.5 14B', sizeGB: 9.0, reason: '推荐首选 — 中文量化分析最佳', recommended: true },
        { id: 'qwen2.5:32b', name: 'Qwen 2.5 32B', sizeGB: 20, reason: '顶级中文模型' },
        { id: 'deepseek-v3:latest', name: 'DeepSeek V3', sizeGB: 16, reason: '最强中文开源' },
        { id: 'llama3.1:70b', name: 'Llama 3.1 70B', sizeGB: 39, reason: '需要 48GB+ RAM/VRAM' },
      );
      break;
  }

  return models;
}

/**
 * Get a human-readable hardware summary for display.
 */
function getHardwareSummary() {
  const p = detectProfile();
  const lines = [];

  lines.push(`CPU: ${p.cpu.model} (${p.cpu.cores} cores)`);
  lines.push(`RAM: ${p.memory.totalGB}GB (${p.memory.freeGB}GB free)`);

  if (p.gpu) {
    lines.push(`GPU: ${p.gpu.name} (${p.gpu.vramGB}GB VRAM)`);
  } else {
    lines.push('GPU: none (CPU inference only)');
  }

  if (p.swap.totalMB > 0) {
    lines.push(`Swap: ${Math.round(p.swap.totalMB / 1024)}GB`);
  }

  if (p.disk.availMB > 0) {
    lines.push(`Disk: ${Math.round(p.disk.availMB / 1024)}GB free`);
  }

  lines.push(`Profile: ${p.profile}`);

  return { lines, profile: p };
}

/**
 * Apply hardware-based limits to the current process.
 * Call during startup to configure memory/concurrency limits.
 */
function applyLimits() {
  const p = detectProfile();

  // Set Node.js heap limit via env (for child processes)
  if (!process.env.KHY_MAX_HEAP_MB) {
    process.env.KHY_MAX_HEAP_MB = String(p.limits.nodeHeapMB);
  }

  // Disable heavy features on minimal servers
  if (p.isLightweight) {
    process.env.KHY_LIGHTWEIGHT = 'true';
  }

  return p.limits;
}

/**
 * Clear cached profile (for testing or after hardware changes).
 */
function resetCache() {
  _cachedProfile = null;
}

module.exports = {
  detectProfile,
  getHardwareSummary,
  applyLimits,
  resetCache,
  recommendLocalModels,
};
