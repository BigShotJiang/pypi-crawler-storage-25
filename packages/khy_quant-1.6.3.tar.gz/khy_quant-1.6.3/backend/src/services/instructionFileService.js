/**
 * Multi-level khy.md instruction file discovery and loading.
 *
 * Mirrors CLAUDE.md / CLAW.md pattern — discovers instruction files
 * at three levels (global, project, cwd) and merges them into a
 * single block for injection into the AI system prompt.
 *
 * Levels (all loaded, bottom-up):
 *   ~/.khyquant/khy.md        → global user instructions
 *   <git-root>/khy.md         → project-level instructions
 *   <cwd>/khy.md              → directory-level (when cwd ≠ git-root)
 *
 * Limits:
 *   - Single file: max 4000 chars (truncated with warning)
 *   - Total merged: max 12000 chars
 */
const path = require('path');
const fs = require('fs');
const os = require('os');
const { execSync } = require('child_process');

const MAX_FILE_CHARS = 4000;
const MAX_TOTAL_CHARS = 12000;
const FILENAME = 'khy.md';

// ── Helpers ─────────────────────────────────────────────────────────────

function findGitRoot(from) {
  try {
    const root = execSync('git rev-parse --show-toplevel', {
      cwd: from,
      encoding: 'utf-8',
      stdio: ['pipe', 'pipe', 'pipe'],
    }).trim();
    return root || null;
  } catch {
    return null;
  }
}

function readFileSafe(filePath, maxChars = MAX_FILE_CHARS) {
  try {
    if (!fs.existsSync(filePath)) return null;
    const stat = fs.statSync(filePath);
    if (!stat.isFile()) return null;

    let content = fs.readFileSync(filePath, 'utf-8');
    let truncated = false;
    if (content.length > maxChars) {
      content = content.slice(0, maxChars);
      truncated = true;
    }
    return { content, truncated, size: stat.size };
  } catch {
    return null;
  }
}

// ── Core API ────────────────────────────────────────────────────────────

/**
 * Discover all khy.md files for the given working directory.
 * @param {string} [cwd] - defaults to process.cwd()
 * @returns {Array<{ path: string, content: string, level: string, truncated: boolean, size: number }>}
 */
function discoverInstructionFiles(cwd) {
  cwd = cwd || process.cwd();
  const results = [];
  const seen = new Set();

  // 1. Global: ~/.khyquant/khy.md
  const globalPath = path.join(os.homedir(), '.khyquant', FILENAME);
  const globalFile = readFileSafe(globalPath);
  if (globalFile) {
    results.push({
      path: globalPath,
      content: globalFile.content,
      level: 'global',
      truncated: globalFile.truncated,
      size: globalFile.size,
    });
    seen.add(path.resolve(globalPath));
  }

  // 2. Project: <git-root>/khy.md
  const gitRoot = findGitRoot(cwd);
  if (gitRoot) {
    const projectPath = path.join(gitRoot, FILENAME);
    const resolved = path.resolve(projectPath);
    if (!seen.has(resolved)) {
      const projectFile = readFileSafe(projectPath);
      if (projectFile) {
        results.push({
          path: projectPath,
          content: projectFile.content,
          level: 'project',
          truncated: projectFile.truncated,
          size: projectFile.size,
        });
        seen.add(resolved);
      }
    }
  }

  // 3. CWD: <cwd>/khy.md (only if different from git root)
  const cwdPath = path.join(cwd, FILENAME);
  const cwdResolved = path.resolve(cwdPath);
  if (!seen.has(cwdResolved)) {
    const cwdFile = readFileSafe(cwdPath);
    if (cwdFile) {
      results.push({
        path: cwdPath,
        content: cwdFile.content,
        level: 'directory',
        truncated: cwdFile.truncated,
        size: cwdFile.size,
      });
    }
  }

  return results;
}

/**
 * Load and merge all khy.md instructions into a single string.
 * Suitable for direct injection into the AI system prompt.
 *
 * @param {string} [cwd]
 * @returns {string} merged instructions (empty string if none found)
 */
function loadInstructions(cwd) {
  const files = discoverInstructionFiles(cwd);
  if (files.length === 0) return '';

  const LEVEL_LABELS = {
    global: '全局指令',
    project: '项目指令',
    directory: '目录指令',
  };

  const sections = [];
  let totalChars = 0;

  for (const file of files) {
    const label = LEVEL_LABELS[file.level] || file.level;
    const header = `[${label} - ${file.path}]`;
    let content = file.content;

    // Enforce total limit
    const remaining = MAX_TOTAL_CHARS - totalChars - header.length - 2;
    if (remaining <= 0) break;
    if (content.length > remaining) {
      content = content.slice(0, remaining);
    }

    const section = `${header}\n${content}`;
    sections.push(section);
    totalChars += section.length;

    if (totalChars >= MAX_TOTAL_CHARS) break;
  }

  return sections.join('\n\n');
}

/**
 * Get a summary of loaded instruction files (for /memory command).
 * @param {string} [cwd]
 * @returns {Array<{ path: string, level: string, size: number, truncated: boolean }>}
 */
function getInstructionSummary(cwd) {
  return discoverInstructionFiles(cwd).map(({ path: p, level, size, truncated }) => ({
    path: p,
    level,
    size,
    truncated,
  }));
}

module.exports = {
  discoverInstructionFiles,
  loadInstructions,
  getInstructionSummary,
  MAX_FILE_CHARS,
  MAX_TOTAL_CHARS,
};
