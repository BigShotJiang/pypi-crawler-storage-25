/**
 * Account Pool Service — manage IDE account rotation with anti-ban measures.
 *
 * Inspired by Nirvana's lease-based architecture:
 * - Lease-based account acquisition with heartbeat renewal
 * - Cooldown enforcement to prevent rapid rotation triggering bans
 * - Immediate replacement when accounts are banned (skip cooldown)
 * - Periodic GC to reclaim expired leases
 *
 * Uses SQLite via Sequelize (existing project DB infrastructure).
 */
const crypto = require('crypto');

const LEASE_DURATION_MS = 2 * 60 * 60 * 1000; // 2 hours
const DEFAULT_COOLDOWN_MS = 60 * 60 * 1000; // 60 minutes
const HEARTBEAT_TIMEOUT_MS = 10 * 60 * 1000; // 10 minutes
const GC_INTERVAL_MS = 5 * 60 * 1000; // 5 minutes

let _db = null;
let _gcTimer = null;

/**
 * Initialize the account pool tables (auto-create if not exist).
 */
async function init(sequelize) {
  _db = sequelize;

  await _db.query(`
    CREATE TABLE IF NOT EXISTS account_pool (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      pool_type TEXT NOT NULL,
      email TEXT,
      password TEXT,
      access_token TEXT,
      refresh_token TEXT,
      auth_data TEXT,
      account_type TEXT DEFAULT 'FREE',
      status TEXT DEFAULT 'available',
      leased_by TEXT,
      lease_until TEXT,
      last_used_at TEXT,
      created_at TEXT DEFAULT (datetime('now')),
      UNIQUE(email, pool_type)
    )
  `);

  await _db.query(`
    CREATE TABLE IF NOT EXISTS account_leases (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      request_id TEXT UNIQUE NOT NULL,
      account_id INTEGER REFERENCES account_pool(id),
      pool_type TEXT NOT NULL,
      status TEXT DEFAULT 'active',
      acquired_at TEXT DEFAULT (datetime('now')),
      lease_until TEXT,
      last_heartbeat TEXT,
      released_at TEXT
    )
  `);

  // Start GC timer
  startGC();
}

/**
 * Acquire an account from the pool.
 * Reuses active lease if available, otherwise allocates new.
 */
async function acquire(poolType, userId = 'default') {
  if (!_db) throw new Error('Account pool not initialized');

  // Check for existing active lease
  const [existing] = await _db.query(`
    SELECT l.*, a.email, a.password, a.access_token, a.refresh_token, a.auth_data, a.account_type
    FROM account_leases l
    JOIN account_pool a ON a.id = l.account_id
    WHERE l.pool_type = :poolType AND l.status = 'active'
      AND l.lease_until > datetime('now')
    ORDER BY l.acquired_at DESC LIMIT 1
  `, { replacements: { poolType } });

  if (existing.length > 0) {
    return formatLease(existing[0]);
  }

  // Check cooldown (skip for banned replacements)
  const [lastPull] = await _db.query(`
    SELECT released_at FROM account_leases
    WHERE pool_type = :poolType AND status IN ('released', 'expired')
    ORDER BY released_at DESC LIMIT 1
  `, { replacements: { poolType } });

  if (lastPull.length > 0) {
    const releasedAt = new Date(lastPull[0].released_at).getTime();
    const cooldownMs = parseInt(process.env.POOL_COOLDOWN_MS, 10) || DEFAULT_COOLDOWN_MS;
    if (Date.now() - releasedAt < cooldownMs) {
      const remaining = Math.ceil((cooldownMs - (Date.now() - releasedAt)) / 60000);
      throw new Error(`Cooldown active (${remaining} min remaining). Use pool switch for immediate replacement.`);
    }
  }

  // Allocate random available account
  const [accounts] = await _db.query(`
    SELECT * FROM account_pool
    WHERE pool_type = :poolType AND status = 'available'
    ORDER BY RANDOM() LIMIT 1
  `, { replacements: { poolType } });

  if (accounts.length === 0) {
    throw new Error(`No available accounts in ${poolType} pool`);
  }

  const account = accounts[0];
  const requestId = crypto.randomUUID();
  const leaseUntil = new Date(Date.now() + LEASE_DURATION_MS).toISOString();

  await _db.query(`
    UPDATE account_pool SET status = 'leased', leased_by = :userId,
      lease_until = :leaseUntil, last_used_at = datetime('now')
    WHERE id = :id
  `, { replacements: { userId, leaseUntil, id: account.id } });

  await _db.query(`
    INSERT INTO account_leases (request_id, account_id, pool_type, status, lease_until, last_heartbeat)
    VALUES (:requestId, :accountId, :poolType, 'active', :leaseUntil, datetime('now'))
  `, { replacements: { requestId, accountId: account.id, poolType, leaseUntil } });

  return formatLease({ ...account, request_id: requestId, lease_until: leaseUntil });
}

/**
 * Release an account back to the pool.
 */
async function release(requestId) {
  if (!_db) throw new Error('Account pool not initialized');

  const [leases] = await _db.query(`
    SELECT * FROM account_leases WHERE request_id = :requestId AND status = 'active'
  `, { replacements: { requestId } });

  if (leases.length === 0) throw new Error('Lease not found or already released');

  const lease = leases[0];
  await _db.query(`
    UPDATE account_pool SET status = 'available', leased_by = NULL, lease_until = NULL
    WHERE id = :id
  `, { replacements: { id: lease.account_id } });

  await _db.query(`
    UPDATE account_leases SET status = 'released', released_at = datetime('now')
    WHERE request_id = :requestId
  `, { replacements: { requestId } });
}

/**
 * Heartbeat to extend a lease.
 */
async function heartbeat(requestId) {
  if (!_db) throw new Error('Account pool not initialized');

  const leaseUntil = new Date(Date.now() + LEASE_DURATION_MS).toISOString();
  await _db.query(`
    UPDATE account_leases SET last_heartbeat = datetime('now'), lease_until = :leaseUntil
    WHERE request_id = :requestId AND status = 'active'
  `, { replacements: { requestId, leaseUntil } });

  await _db.query(`
    UPDATE account_pool SET lease_until = :leaseUntil
    WHERE id = (SELECT account_id FROM account_leases WHERE request_id = :requestId)
  `, { replacements: { requestId, leaseUntil } });
}

/**
 * Report account status (banned/invalid/exhausted).
 * Banned accounts get immediate replacement without cooldown.
 */
async function reportStatus(requestId, status, userId = 'default') {
  if (!_db) throw new Error('Account pool not initialized');

  const [leases] = await _db.query(`
    SELECT * FROM account_leases WHERE request_id = :requestId AND status = 'active'
  `, { replacements: { requestId } });

  if (leases.length === 0) throw new Error('Lease not found');

  const lease = leases[0];

  // Mark account
  await _db.query(`
    UPDATE account_pool SET status = :status WHERE id = :id
  `, { replacements: { status, id: lease.account_id } });

  // Close lease
  await _db.query(`
    UPDATE account_leases SET status = 'released', released_at = datetime('now')
    WHERE request_id = :requestId
  `, { replacements: { requestId } });

  // Auto-switch: immediately acquire new account (skip cooldown for banned)
  if (status === 'banned' || status === 'invalid') {
    try {
      return await acquireSkipCooldown(lease.pool_type, userId);
    } catch {
      return null; // No more accounts
    }
  }
  return null;
}

/**
 * Acquire without cooldown (for banned replacement).
 */
async function acquireSkipCooldown(poolType, userId) {
  const [accounts] = await _db.query(`
    SELECT * FROM account_pool
    WHERE pool_type = :poolType AND status = 'available'
    ORDER BY RANDOM() LIMIT 1
  `, { replacements: { poolType } });

  if (accounts.length === 0) throw new Error(`No available accounts in ${poolType} pool`);

  const account = accounts[0];
  const requestId = crypto.randomUUID();
  const leaseUntil = new Date(Date.now() + LEASE_DURATION_MS).toISOString();

  await _db.query(`
    UPDATE account_pool SET status = 'leased', leased_by = :userId,
      lease_until = :leaseUntil, last_used_at = datetime('now')
    WHERE id = :id
  `, { replacements: { userId, leaseUntil, id: account.id } });

  await _db.query(`
    INSERT INTO account_leases (request_id, account_id, pool_type, status, lease_until, last_heartbeat)
    VALUES (:requestId, :accountId, :poolType, 'active', :leaseUntil, datetime('now'))
  `, { replacements: { requestId, accountId: account.id, poolType, leaseUntil } });

  return formatLease({ ...account, request_id: requestId, lease_until: leaseUntil });
}

/**
 * Switch: release current + acquire new.
 */
async function switchAccount(requestId, poolType, userId = 'default') {
  await release(requestId);
  return acquireSkipCooldown(poolType, userId);
}

/**
 * Get pool statistics.
 */
async function getStats(poolType) {
  if (!_db) return {};

  const where = poolType ? `WHERE pool_type = ?` : '';
  const params = poolType ? [poolType] : [];
  const [rows] = await _db.query(`
    SELECT pool_type,
      COUNT(*) as total,
      SUM(CASE WHEN status = 'available' THEN 1 ELSE 0 END) as available,
      SUM(CASE WHEN status = 'leased' THEN 1 ELSE 0 END) as leased,
      SUM(CASE WHEN status = 'banned' THEN 1 ELSE 0 END) as banned,
      SUM(CASE WHEN status = 'invalid' THEN 1 ELSE 0 END) as invalid,
      SUM(CASE WHEN status = 'exhausted' THEN 1 ELSE 0 END) as exhausted
    FROM account_pool ${where}
    GROUP BY pool_type
  `, params);
  return rows;
}

/**
 * Batch add accounts.
 */
async function addAccounts(poolType, accounts) {
  if (!_db) throw new Error('Account pool not initialized');

  let added = 0;
  for (const acct of accounts) {
    try {
      await _db.query(`
        INSERT OR IGNORE INTO account_pool (pool_type, email, password, access_token, refresh_token, auth_data, account_type)
        VALUES (:poolType, :email, :password, :accessToken, :refreshToken, :authData, :accountType)
      `, {
        replacements: {
          poolType,
          email: acct.email || null,
          password: acct.password || null,
          accessToken: acct.access_token || null,
          refreshToken: acct.refresh_token || null,
          authData: acct.auth_data ? JSON.stringify(acct.auth_data) : null,
          accountType: acct.account_type || 'FREE',
        },
      });
      added++;
    } catch { /* duplicate or error, skip */ }
  }
  return added;
}

/**
 * Reset account status to available.
 */
async function resetAccounts(poolType, emails) {
  if (!_db) throw new Error('Account pool not initialized');

  if (emails?.length) {
    const placeholders = emails.map(() => '?').join(',');
    await _db.query(`
      UPDATE account_pool SET status = 'available', leased_by = NULL, lease_until = NULL
      WHERE pool_type = ? AND email IN (${placeholders})
    `, { replacements: [poolType, ...emails] });
  } else {
    await _db.query(`
      UPDATE account_pool SET status = 'available', leased_by = NULL, lease_until = NULL
      WHERE pool_type = :poolType AND status IN ('leased', 'exhausted')
    `, { replacements: { poolType } });
  }
}

// ── Lease GC ─────────────────────────────────────────────────────────────

function startGC() {
  if (_gcTimer) clearInterval(_gcTimer);
  _gcTimer = setInterval(runGC, GC_INTERVAL_MS);
  _gcTimer.unref(); // Don't prevent process exit
}

async function runGC() {
  if (!_db) return;
  try {
    // Expire leases past their lease_until
    const [expired] = await _db.query(`
      SELECT request_id, account_id FROM account_leases
      WHERE status = 'active' AND (
        lease_until < datetime('now')
        OR last_heartbeat < datetime('now', '-10 minutes')
      )
    `);

    for (const lease of expired) {
      await _db.query(`
        UPDATE account_pool SET status = 'available', leased_by = NULL, lease_until = NULL
        WHERE id = :id
      `, { replacements: { id: lease.account_id } });
      await _db.query(`
        UPDATE account_leases SET status = 'expired', released_at = datetime('now')
        WHERE request_id = :requestId
      `, { replacements: { requestId: lease.request_id } });
    }
  } catch { /* GC errors are non-fatal */ }
}

function stopGC() {
  if (_gcTimer) { clearInterval(_gcTimer); _gcTimer = null; }
}

// ── Helpers ──────────────────────────────────────────────────────────────

function formatLease(row) {
  return {
    requestId: row.request_id,
    poolType: row.pool_type,
    email: row.email,
    password: row.password,
    accessToken: row.access_token,
    refreshToken: row.refresh_token,
    authData: row.auth_data ? JSON.parse(row.auth_data) : null,
    accountType: row.account_type,
    leaseUntil: row.lease_until,
  };
}

module.exports = {
  init, acquire, release, heartbeat, reportStatus, switchAccount,
  getStats, addAccounts, resetAccounts, runGC, stopGC,
};
