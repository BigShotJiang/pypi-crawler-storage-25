/**
 * Centralized auto-cleanup service for ~/.khyquant/ persistent data.
 *
 * Manages:
 *  - Security log rotation (5 MB cap, gzip, keep 2 archives)
 *  - Growth snapshots pruning (max 10)
 *  - Training interaction records trimming (10 000 lines / 50 MB)
 *  - Telemetry export pruning (max 5 files)
 *
 * Already self-cleaning (not touched here):
 *  - Conversations (MAX_SAVED_CONVERSATIONS = 20)
 *  - Command history (MAX_HISTORY = 500)
 *  - Token usage (90-day daily / 6-month monthly)
 *  - Growth strategies (500) / analysis patterns (200)
 *  - Knowledge base (200 entries)
 */
const path = require('path');
const fs = require('fs');
const os = require('os');
const zlib = require('zlib');

const BASE_DIR = path.join(os.homedir(), '.khyquant');
const BACKEND_ROOT = process.env.KHYQUANT_ROOT || path.resolve(__dirname, '..', '..');

// ── Limits ──────────────────────────────────────────────────────────────
const SECURITY_LOG_MAX_BYTES = 5 * 1024 * 1024;   // 5 MB
const SECURITY_LOG_KEEP_ARCHIVES = 2;
const SNAPSHOTS_MAX_KEEP = 10;
const TRAINING_MAX_LINES = 10_000;
const TRAINING_MAX_BYTES = 50 * 1024 * 1024;       // 50 MB
const TELEMETRY_MAX_FILES = 5;
const TEMP_MAX_AGE_HOURS = 24;
const LOG_MAX_AGE_HOURS = 168;  // 7 days
const LOG_MAX_FILES = 20;
const TEMP_MAX_SIZE_BYTES = 100 * 1024 * 1024;  // 100 MB
const LOG_MAX_SIZE_BYTES = 50 * 1024 * 1024;     // 50 MB

// File extensions that are always safe to clean
const JUNK_EXTENSIONS = new Set([
  '.tmp', '.temp', '.bak', '.swp', '.swo', '.pid',
  '.log.1', '.log.2', '.log.3', '.log.4', '.log.5',
]);

let _periodicTimer = null;

// ── Helpers ─────────────────────────────────────────────────────────────

function safeSize(filePath) {
  try { return fs.statSync(filePath).size; } catch { return 0; }
}

function safeLs(dir) {
  try { return fs.readdirSync(dir); } catch { return []; }
}

function humanSize(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// ── Security log rotation ───────────────────────────────────────────────

function rotateSecurityLog() {
  const logPath = path.join(BASE_DIR, 'security.log');
  const size = safeSize(logPath);
  if (size <= SECURITY_LOG_MAX_BYTES) return { rotated: false, size };

  try {
    // Shift existing archives: .2.gz → delete, .1.gz → .2.gz
    for (let i = SECURITY_LOG_KEEP_ARCHIVES; i >= 1; i--) {
      const src = path.join(BASE_DIR, `security.log.${i}.gz`);
      if (i === SECURITY_LOG_KEEP_ARCHIVES) {
        try { fs.unlinkSync(src); } catch { /* OK */ }
      } else {
        const dst = path.join(BASE_DIR, `security.log.${i + 1}.gz`);
        try { fs.renameSync(src, dst); } catch { /* OK */ }
      }
    }

    // Compress current log → .1.gz
    const raw = fs.readFileSync(logPath);
    const compressed = zlib.gzipSync(raw);
    fs.writeFileSync(path.join(BASE_DIR, 'security.log.1.gz'), compressed);
    fs.writeFileSync(logPath, ''); // truncate
    return { rotated: true, originalSize: size, compressedSize: compressed.length };
  } catch (err) {
    return { rotated: false, error: err.message };
  }
}

// ── Growth snapshots pruning ────────────────────────────────────────────

function cleanSnapshots(maxKeep = SNAPSHOTS_MAX_KEEP) {
  const dir = path.join(BASE_DIR, 'growth', 'snapshots');
  const files = safeLs(dir).filter(f => f.endsWith('.json')).sort();

  if (files.length <= maxKeep) return { removed: 0, kept: files.length };

  const toRemove = files.slice(0, files.length - maxKeep);
  let removed = 0;
  for (const f of toRemove) {
    try { fs.unlinkSync(path.join(dir, f)); removed++; } catch { /* skip */ }
  }
  return { removed, kept: files.length - removed };
}

// ── Training data trimming ──────────────────────────────────────────────

function trimTrainingData(maxLines = TRAINING_MAX_LINES) {
  const filePath = path.join(BASE_DIR, 'training', 'interaction_records.jsonl');
  const size = safeSize(filePath);
  if (size === 0) return { trimmed: false, lines: 0, size: 0 };

  // If under size cap, only trim by line count
  if (size <= TRAINING_MAX_BYTES) {
    try {
      const content = fs.readFileSync(filePath, 'utf-8');
      const lines = content.split('\n').filter(Boolean);
      if (lines.length <= maxLines) return { trimmed: false, lines: lines.length, size };

      const kept = lines.slice(-maxLines);
      fs.writeFileSync(filePath, kept.join('\n') + '\n', 'utf-8');
      return { trimmed: true, before: lines.length, after: kept.length, freedBytes: size - safeSize(filePath) };
    } catch (err) {
      return { trimmed: false, error: err.message };
    }
  }

  // Over size cap — aggressive trim
  try {
    const content = fs.readFileSync(filePath, 'utf-8');
    const lines = content.split('\n').filter(Boolean);
    const half = Math.min(maxLines, Math.floor(lines.length / 2));
    const kept = lines.slice(-half);
    fs.writeFileSync(filePath, kept.join('\n') + '\n', 'utf-8');
    return { trimmed: true, before: lines.length, after: kept.length, freedBytes: size - safeSize(filePath) };
  } catch (err) {
    return { trimmed: false, error: err.message };
  }
}

// ── Telemetry exports pruning ───────────────────────────────────────────

function cleanTelemetry(maxFiles = TELEMETRY_MAX_FILES) {
  const dir = path.join(BASE_DIR, 'telemetry');
  const files = safeLs(dir).sort();

  if (files.length <= maxFiles) return { removed: 0, kept: files.length };

  const toRemove = files.slice(0, files.length - maxFiles);
  let removed = 0;
  for (const f of toRemove) {
    try { fs.unlinkSync(path.join(dir, f)); removed++; } catch { /* skip */ }
  }
  return { removed, kept: files.length - removed };
}

// ── Storage report ──────────────────────────────────────────────────────

function getStorageReport() {
  const report = {};

  // Security log
  const logPath = path.join(BASE_DIR, 'security.log');
  report.securityLog = { size: safeSize(logPath), path: logPath };

  // Security log archives
  let archiveSize = 0;
  for (let i = 1; i <= SECURITY_LOG_KEEP_ARCHIVES; i++) {
    archiveSize += safeSize(path.join(BASE_DIR, `security.log.${i}.gz`));
  }
  report.securityLogArchives = { size: archiveSize };

  // Growth snapshots
  const snapDir = path.join(BASE_DIR, 'growth', 'snapshots');
  const snapFiles = safeLs(snapDir);
  let snapSize = 0;
  for (const f of snapFiles) snapSize += safeSize(path.join(snapDir, f));
  report.growthSnapshots = { count: snapFiles.length, size: snapSize, path: snapDir };

  // Training data
  const trainPath = path.join(BASE_DIR, 'training', 'interaction_records.jsonl');
  report.trainingData = { size: safeSize(trainPath), path: trainPath };

  // Telemetry
  const telDir = path.join(BASE_DIR, 'telemetry');
  const telFiles = safeLs(telDir);
  let telSize = 0;
  for (const f of telFiles) telSize += safeSize(path.join(telDir, f));
  report.telemetry = { count: telFiles.length, size: telSize, path: telDir };

  // Conversations
  const convoDir = path.join(BASE_DIR, 'conversations');
  const convoFiles = safeLs(convoDir);
  let convoSize = 0;
  for (const f of convoFiles) convoSize += safeSize(path.join(convoDir, f));
  report.conversations = { count: convoFiles.length, size: convoSize };

  // Total
  report.total = Object.values(report).reduce((acc, v) => acc + (v.size || 0), 0);
  report.totalHuman = humanSize(report.total);

  return report;
}

// ── Run all cleanup ─────────────────────────────────────────────────────

/**
 * Clean a backend directory by file age, count, and total size.
 */
function cleanBackendDir(relDir, { maxAgeHours = TEMP_MAX_AGE_HOURS, maxFiles = Infinity, maxSizeBytes = TEMP_MAX_SIZE_BYTES } = {}) {
  const dirPath = path.join(BACKEND_ROOT, relDir);
  let removed = 0, bytes = 0;
  if (!fs.existsSync(dirPath)) return { removed, bytes };

  try {
    const entries = fs.readdirSync(dirPath);
    const files = [];
    for (const entry of entries) {
      if (entry === '.gitkeep' || entry === '.env') continue;
      const fp = path.join(dirPath, entry);
      try {
        const stat = fs.statSync(fp);
        if (stat.isFile()) files.push({ path: fp, name: entry, size: stat.size, mtime: stat.mtimeMs });
      } catch { /* skip */ }
    }
    files.sort((a, b) => a.mtime - b.mtime); // oldest first

    // Remove old and junk files
    for (const file of files) {
      const ageH = (Date.now() - file.mtime) / (1000 * 60 * 60);
      const ext = path.extname(file.name).toLowerCase();
      if (ageH > maxAgeHours || JUNK_EXTENSIONS.has(ext)) {
        try { fs.unlinkSync(file.path); removed++; bytes += file.size; } catch { /* skip */ }
      }
    }

    // Cap file count
    const remaining = files.filter(f => fs.existsSync(f.path));
    if (remaining.length > maxFiles) {
      for (const file of remaining.slice(0, remaining.length - maxFiles)) {
        try { fs.unlinkSync(file.path); removed++; bytes += file.size; } catch { /* skip */ }
      }
    }

    // Cap total size
    let currentSize = 0;
    for (const entry of safeLs(dirPath)) {
      currentSize += safeSize(path.join(dirPath, entry));
    }
    if (currentSize > maxSizeBytes) {
      const stillExist = files.filter(f => fs.existsSync(f.path));
      for (const file of stillExist) {
        if (currentSize <= maxSizeBytes) break;
        try { fs.unlinkSync(file.path); currentSize -= file.size; removed++; bytes += file.size; } catch { /* skip */ }
      }
    }
  } catch { /* access error */ }

  return { removed, bytes };
}

/**
 * Clean KHY-Quant specific files from OS temp directory.
 */
function cleanOsTempFiles() {
  let removed = 0, bytes = 0;
  const tmpDir = os.tmpdir();
  try {
    for (const entry of fs.readdirSync(tmpDir)) {
      if (!entry.startsWith('khy_') && !entry.startsWith('khyquant_')) continue;
      const fp = path.join(tmpDir, entry);
      try {
        const stat = fs.statSync(fp);
        const ageH = (Date.now() - stat.mtimeMs) / (1000 * 60 * 60);
        if (ageH > 1 && stat.isFile()) {
          fs.unlinkSync(fp); removed++; bytes += stat.size;
        }
      } catch { /* skip */ }
    }
  } catch { /* ignore */ }
  return { removed, bytes };
}

function runCleanup() {
  const results = {
    securityLog: rotateSecurityLog(),
    snapshots: cleanSnapshots(),
    trainingData: trimTrainingData(),
    telemetry: cleanTelemetry(),
  };

  // Clean backend temp/intermediate directories
  const backendTargets = [
    { dir: 'temp', maxAgeHours: TEMP_MAX_AGE_HOURS, maxSizeBytes: TEMP_MAX_SIZE_BYTES },
    { dir: 'logs', maxAgeHours: LOG_MAX_AGE_HOURS, maxFiles: LOG_MAX_FILES, maxSizeBytes: LOG_MAX_SIZE_BYTES },
    { dir: 'data/cache', maxAgeHours: 72, maxSizeBytes: TEMP_MAX_SIZE_BYTES },
    { dir: 'ml/data/cache', maxAgeHours: 168, maxSizeBytes: TEMP_MAX_SIZE_BYTES },
  ];

  results.backendCleanup = [];
  for (const target of backendTargets) {
    const r = cleanBackendDir(target.dir, target);
    if (r.removed > 0) results.backendCleanup.push({ dir: target.dir, ...r });
  }

  // Clean OS temp
  const osTmp = cleanOsTempFiles();
  if (osTmp.removed > 0) results.backendCleanup.push({ dir: 'os-temp', ...osTmp });

  // Calculate total freed
  let freedBytes = 0;
  if (results.securityLog.rotated) {
    freedBytes += (results.securityLog.originalSize || 0) - (results.securityLog.compressedSize || 0);
  }
  if (results.trainingData.trimmed) {
    freedBytes += results.trainingData.freedBytes || 0;
  }

  results.summary = {
    freedBytes,
    freedHuman: humanSize(freedBytes),
    actions: [],
  };

  if (results.securityLog.rotated) {
    results.summary.actions.push(`Security log rotated (${humanSize(results.securityLog.originalSize)})`);
  }
  if (results.snapshots.removed > 0) {
    results.summary.actions.push(`Removed ${results.snapshots.removed} old snapshots`);
  }
  if (results.trainingData.trimmed) {
    results.summary.actions.push(`Training data trimmed: ${results.trainingData.before} → ${results.trainingData.after} lines`);
  }
  if (results.telemetry.removed > 0) {
    results.summary.actions.push(`Removed ${results.telemetry.removed} old telemetry exports`);
  }
  for (const bc of results.backendCleanup) {
    if (bc.removed > 0) {
      results.summary.actions.push(`Cleaned ${bc.dir}: ${bc.removed} files (${humanSize(bc.bytes)})`);
      freedBytes += bc.bytes;
    }
  }
  results.summary.freedBytes = freedBytes;
  results.summary.freedHuman = humanSize(freedBytes);

  return results;
}

/**
 * Start periodic cleanup (every 2 hours). Non-blocking.
 */
function startPeriodicCleanup() {
  if (_periodicTimer) return;
  // Initial cleanup on startup
  try { runCleanup(); } catch { /* ignore */ }
  _periodicTimer = setInterval(() => {
    try { runCleanup(); } catch { /* ignore */ }
  }, 2 * 60 * 60 * 1000);
  _periodicTimer.unref(); // Don't block process exit
}

/**
 * Stop periodic cleanup.
 */
function stopPeriodicCleanup() {
  if (_periodicTimer) {
    clearInterval(_periodicTimer);
    _periodicTimer = null;
  }
}

module.exports = {
  runCleanup,
  startPeriodicCleanup,
  stopPeriodicCleanup,
  rotateSecurityLog,
  cleanSnapshots,
  trimTrainingData,
  cleanTelemetry,
  cleanBackendDir,
  cleanOsTempFiles,
  getStorageReport,
  humanSize,
};
