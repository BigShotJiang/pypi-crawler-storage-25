/**
 * Frontend Detector — check if the KHY-Quant web frontend is available.
 *
 * Checks in order:
 *   1. Bundled frontend (monorepo / full pip install)
 *   2. Separate pip package (khy-quant-frontend)
 *   3. Development mode (frontend/dist/ in project root)
 */
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');

let _cachedResult = null;

/**
 * Detect frontend availability and return its dist path.
 * @returns {{ available: boolean, source: string, distPath: string|null }}
 */
function detect() {
  if (_cachedResult) return _cachedResult;

  // 1. Bundled frontend (monorepo install)
  const bundledDist = path.resolve(__dirname, '..', '..', '..', 'frontend', 'dist');
  if (fs.existsSync(path.join(bundledDist, 'index.html'))) {
    _cachedResult = { available: true, source: 'bundled', distPath: bundledDist };
    return _cachedResult;
  }

  // 2. Separate pip package — ask Python
  try {
    const result = execSync(
      'python3 -c "from khy_quant_frontend import get_frontend_dir; p=get_frontend_dir(); print(p or \'\')"',
      { timeout: 5000, encoding: 'utf-8', stdio: ['pipe', 'pipe', 'pipe'] },
    ).trim();
    if (result && fs.existsSync(path.join(result, 'index.html'))) {
      _cachedResult = { available: true, source: 'pip-package', distPath: result };
      return _cachedResult;
    }
  } catch { /* pip package not installed */ }

  // 3. Development mode (project root)
  const devDist = path.resolve(__dirname, '..', '..', '..', '..', 'frontend', 'dist');
  if (fs.existsSync(path.join(devDist, 'index.html'))) {
    _cachedResult = { available: true, source: 'development', distPath: devDist };
    return _cachedResult;
  }

  _cachedResult = { available: false, source: 'none', distPath: null };
  return _cachedResult;
}

/**
 * Clear cached detection result (e.g., after installing frontend package).
 */
function resetCache() {
  _cachedResult = null;
}

module.exports = { detect, resetCache };
