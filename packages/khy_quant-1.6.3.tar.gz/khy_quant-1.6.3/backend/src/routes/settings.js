const express = require('express');
const router = express.Router();
const SystemSettingService = require('../services/systemSettingService');
const { isAllowedSettingKey } = require('../config/settingsWhitelist');

// 获取公开的系统设置（无需认证）
router.get('/public', async (req, res) => {
  try {
    const { category } = req.query;
    const settings = await SystemSettingService.getAllSettings({ 
      category, 
      isPublic: true 
    });

    res.json({
      success: true,
      data: settings,
      message: '获取公开设置成功'
    });
  } catch (error) {
    console.error('获取公开设置失败:', error);
    res.status(500).json({
      success: false,
      message: '获取公开设置失败',
      error: error.message
    });
  }
});

// 获取单个公开设置（仅允许访问标记为 public 的设置）
router.get('/public/:key', async (req, res) => {
  try {
    const { key } = req.params;

    // Direct DB lookup by key + isPublic check
    const { SystemSetting } = require('../models');
    const setting = await SystemSetting.findOne({ where: { key, isPublic: true } });

    if (!setting) {
      return res.status(404).json({
        success: false,
        message: '设置项不存在或非公开设置'
      });
    }

    res.json({
      success: true,
      data: { key, value: setting.getParsedValue() },
      message: '获取设置成功'
    });
  } catch (error) {
    console.error('获取设置失败:', error);
    res.status(500).json({
      success: false,
      message: '获取设置失败',
      error: error.message
    });
  }
});

// Admin: update a single setting by key
const { authenticateToken, requireAdmin } = require('../middleware/auth');

router.put('/:key', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { key } = req.params;
    const { value, type, category, description } = req.body;

    if (value === undefined) {
      return res.status(400).json({ success: false, message: 'Missing value' });
    }

    // Validate key against allowed prefixes
    if (!isAllowedSettingKey(key)) {
      return res.status(400).json({ success: false, message: `Not allowed setting key: ${key}` });
    }

    const { isPublic } = req.body;
    const result = await SystemSettingService.setSetting(key, value, {
      type: type || 'string',
      category: category || 'general',
      description: description || '',
      isPublic: isPublic !== undefined ? !!isPublic : false
    });

    res.json({ success: true, data: { key, value: result }, message: 'Setting updated' });
  } catch (error) {
    console.error('Update setting failed:', error);
    res.status(500).json({ success: false, message: 'Update setting failed', error: error.message });
  }
});

module.exports = router;
