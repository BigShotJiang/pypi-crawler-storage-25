/**
 * 标的列表路由
 */
const express = require('express');
const router = express.Router();
const instrumentController = require('../controllers/instrumentController');

// 获取统计信息 (必须在 /:symbol 之前)
router.get('/statistics', instrumentController.getStatistics.bind(instrumentController));

// 手动同步标的列表
router.post('/sync', instrumentController.syncInstruments.bind(instrumentController));

// 批量保存标的
router.post('/batch', instrumentController.batchSaveInstruments.bind(instrumentController));

// 获取标的列表
router.get('/', instrumentController.getInstruments.bind(instrumentController));

// 获取单个标的
router.get('/:symbol', instrumentController.getInstrument.bind(instrumentController));

// 更新标的信息
router.put('/:symbol', instrumentController.updateInstrument.bind(instrumentController));

// 删除标的
router.delete('/:symbol', instrumentController.deleteInstrument.bind(instrumentController));

module.exports = router;
