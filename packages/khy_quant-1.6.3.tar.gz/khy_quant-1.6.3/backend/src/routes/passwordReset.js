const express = require('express');
const router = express.Router();
const { User } = require('../models');
const bcrypt = require('bcryptjs');

/**
 * 获取用户的密保问题
 * POST /api/password-reset/get-question
 */
router.post('/get-question', async (req, res) => {
  try {
    const { username, email } = req.body;

    if (!username && !email) {
      return res.status(400).json({
        success: false,
        message: '请提供用户名或邮箱'
      });
    }

    // 查找用户
    const whereClause = {};
    if (username) whereClause.username = username;
    if (email) whereClause.email = email;

    const user = await User.findOne({ where: whereClause });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: '用户不存在'
      });
    }

    if (!user.securityQuestion) {
      return res.status(400).json({
        success: false,
        message: '该用户未设置密保问题，请联系管理员重置密码'
      });
    }

    res.json({
      success: true,
      data: {
        username: user.username,
        securityQuestion: user.securityQuestion
      }
    });
  } catch (error) {
    console.error('获取密保问题失败:', error);
    res.status(500).json({
      success: false,
      message: '获取密保问题失败',
      error: error.message
    });
  }
});

/**
 * 验证密保答案并重置密码
 * POST /api/password-reset/reset
 */
router.post('/reset', async (req, res) => {
  try {
    const { username, securityAnswer, newPassword } = req.body;

    // 验证必填字段
    if (!username || !securityAnswer || !newPassword) {
      return res.status(400).json({
        success: false,
        message: '请填写所有必填字段'
      });
    }

    // 验证新密码强度
    if (newPassword.length < 6) {
      return res.status(400).json({
        success: false,
        message: '新密码长度至少为6位'
      });
    }

    // 查找用户
    const user = await User.findOne({ where: { username } });

    if (!user) {
      return res.status(404).json({
        success: false,
        message: '用户不存在'
      });
    }

    if (!user.securityQuestion || !user.securityAnswer) {
      return res.status(400).json({
        success: false,
        message: '该用户未设置密保问题'
      });
    }

    // 验证密保答案
    const isAnswerValid = await user.compareSecurityAnswer(securityAnswer);

    if (!isAnswerValid) {
      return res.status(401).json({
        success: false,
        message: '密保答案错误'
      });
    }

    // 更新密码
    user.password = newPassword;
    await user.save();

    res.json({
      success: true,
      message: '密码重置成功，请使用新密码登录'
    });
  } catch (error) {
    console.error('重置密码失败:', error);
    res.status(500).json({
      success: false,
      message: '重置密码失败',
      error: error.message
    });
  }
});

/**
 * 设置或更新密保问题（需要登录）
 * POST /api/password-reset/set-security
 */
router.post('/set-security', async (req, res) => {
  try {
    const { userId, securityQuestion, securityAnswer, currentPassword } = req.body;

    if (!userId || !securityQuestion || !securityAnswer || !currentPassword) {
      return res.status(400).json({
        success: false,
        message: '请填写所有必填字段'
      });
    }

    // 查找用户
    const user = await User.findByPk(userId);

    if (!user) {
      return res.status(404).json({
        success: false,
        message: '用户不存在'
      });
    }

    // 验证当前密码
    const isPasswordValid = await user.comparePassword(currentPassword);

    if (!isPasswordValid) {
      return res.status(401).json({
        success: false,
        message: '当前密码错误'
      });
    }

    // 更新密保问题和答案
    user.securityQuestion = securityQuestion;
    user.securityAnswer = securityAnswer;
    await user.save();

    res.json({
      success: true,
      message: '密保问题设置成功'
    });
  } catch (error) {
    console.error('设置密保问题失败:', error);
    res.status(500).json({
      success: false,
      message: '设置密保问题失败',
      error: error.message
    });
  }
});

module.exports = router;
