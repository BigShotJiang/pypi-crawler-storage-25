const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const { authMiddleware } = require('../middleware/auth');
const { ApiKey } = require('../models');

// Helper: generate a khy_-prefixed API key with 192-bit entropy.
function generateKey() {
  return 'khy_' + crypto.randomBytes(24).toString('hex');
}

// --------------------------------------------------------------------
// POST /api/api-keys/generate — Create a new API key (JWT required)
// --------------------------------------------------------------------
router.post('/generate', authMiddleware, async (req, res) => {
  try {
    const label = req.body.label || 'default';

    // Deactivate any existing active keys for this user.
    await ApiKey.update(
      { isActive: false },
      { where: { userId: req.user.id, isActive: true } }
    );

    const key = generateKey();
    const record = await ApiKey.create({
      userId: req.user.id,
      key,
      keyPrefix: key.slice(0, 12),
      label
    });

    res.status(201).json({
      success: true,
      message: 'API key generated — copy it now, it will not be shown again in full',
      data: {
        id: record.id,
        key,                     // Full key — shown only on creation
        keyPrefix: record.keyPrefix,
        label: record.label,
        isActive: record.isActive,
        createdAt: record.createdAt
      }
    });
  } catch (error) {
    console.error('API key generation error:', error);
    res.status(500).json({ success: false, message: 'Failed to generate API key' });
  }
});

// --------------------------------------------------------------------
// POST /api/api-keys/refresh — Rotate: revoke old key, issue new one
// --------------------------------------------------------------------
router.post('/refresh', authMiddleware, async (req, res) => {
  try {
    const current = await ApiKey.findOne({
      where: { userId: req.user.id, isActive: true }
    });

    if (!current) {
      return res.status(404).json({
        success: false,
        message: 'No active API key to refresh — generate one first'
      });
    }

    // Revoke the old key.
    await current.update({ isActive: false });

    // Issue a new one.
    const key = generateKey();
    const record = await ApiKey.create({
      userId: req.user.id,
      key,
      keyPrefix: key.slice(0, 12),
      label: current.label       // Carry forward the label
    });

    res.json({
      success: true,
      message: 'API key refreshed — old key revoked, copy the new one now',
      data: {
        id: record.id,
        key,
        keyPrefix: record.keyPrefix,
        label: record.label,
        isActive: record.isActive,
        createdAt: record.createdAt,
        previousKeyPrefix: current.keyPrefix
      }
    });
  } catch (error) {
    console.error('API key refresh error:', error);
    res.status(500).json({ success: false, message: 'Failed to refresh API key' });
  }
});

// --------------------------------------------------------------------
// POST /api/api-keys/revoke — Disable the active key
// --------------------------------------------------------------------
router.post('/revoke', authMiddleware, async (req, res) => {
  try {
    const current = await ApiKey.findOne({
      where: { userId: req.user.id, isActive: true }
    });

    if (!current) {
      return res.status(404).json({
        success: false,
        message: 'No active API key to revoke'
      });
    }

    await current.update({ isActive: false });

    res.json({
      success: true,
      message: `API key ${current.keyPrefix}... revoked`
    });
  } catch (error) {
    console.error('API key revocation error:', error);
    res.status(500).json({ success: false, message: 'Failed to revoke API key' });
  }
});

// --------------------------------------------------------------------
// GET /api/api-keys/current — Metadata only (no full key)
// --------------------------------------------------------------------
router.get('/current', authMiddleware, async (req, res) => {
  try {
    const current = await ApiKey.findOne({
      where: { userId: req.user.id, isActive: true },
      attributes: ['id', 'keyPrefix', 'label', 'isActive', 'lastUsedAt', 'createdAt']
    });

    res.json({
      success: true,
      data: current   // null if no active key
    });
  } catch (error) {
    console.error('API key lookup error:', error);
    res.status(500).json({ success: false, message: 'Failed to retrieve API key info' });
  }
});

module.exports = router;
