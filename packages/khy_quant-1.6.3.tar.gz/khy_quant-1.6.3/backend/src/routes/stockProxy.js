const express = require('express');
const router = express.Router();
const freeStockDataService = require('../services/freeStockDataService');

// 获取股票实时数据
router.get('/:symbol', async (req, res) => {
  try {
    const { symbol } = req.params;
    
    if (!symbol) {
      return res.status(400).json({
        success: false,
        message: '股票代码不能为空'
      });
    }

    console.log(`获取股票数据: ${symbol}`);
    
    const data = await freeStockDataService.getStockData(symbol);
    
    res.json({
      success: true,
      data: data,
      message: '获取股票数据成功'
    });

  } catch (error) {
    console.error('获取股票数据失败:', error);
    res.status(500).json({
      success: false,
      message: '获取股票数据失败',
      error: error.message
    });
  }
});

// 批量获取股票数据
router.post('/', async (req, res) => {
  try {
    const { symbols } = req.body;
    
    if (!symbols || !Array.isArray(symbols)) {
      return res.status(400).json({
        success: false,
        message: '股票代码列表格式错误'
      });
    }

    console.log(`批量获取股票数据: ${symbols.join(', ')}`);
    
    const results = {};
    
    // 并发获取多个股票数据
    const promises = symbols.map(async (symbol) => {
      try {
        const data = await freeStockDataService.getStockData(symbol);
        results[symbol] = data;
      } catch (error) {
        console.error(`获取${symbol}数据失败:`, error);
        results[symbol] = {
          error: error.message,
          source: '获取失败'
        };
      }
    });

    await Promise.all(promises);
    
    res.json({
      success: true,
      data: results,
      message: '批量获取股票数据完成'
    });

  } catch (error) {
    console.error('批量获取股票数据失败:', error);
    res.status(500).json({
      success: false,
      message: '批量获取股票数据失败',
      error: error.message
    });
  }
});

// 获取热门股票列表
router.get('/hot-stocks', async (req, res) => {
  try {
    const hotStocks = [
      'sh000300', // 沪深300
      'sh000001', // 上证指数
      'sz399001', // 深证成指
      'sz399006', // 创业板指
      '600519',   // 贵州茅台
      '000858',   // 五粮液
      '600036',   // 招商银行
      '000001',   // 平安银行
      '000002',   // 万科A
      '600276'    // 恒瑞医药
    ];

    const results = {};
    
    // 获取热门股票的基本信息
    for (const symbol of hotStocks.slice(0, 5)) { // 只获取前5个，避免请求过多
      try {
        const data = await freeStockDataService.getStockData(symbol);
        results[symbol] = {
          symbol,
          name: getStockName(symbol),
          currentPrice: data.currentPrice,
          change: data.change,
          source: data.source
        };
      } catch (error) {
        console.error(`获取${symbol}数据失败:`, error);
      }
    }
    
    res.json({
      success: true,
      data: results,
      message: '获取热门股票数据成功'
    });

  } catch (error) {
    console.error('获取热门股票失败:', error);
    res.status(500).json({
      success: false,
      message: '获取热门股票失败',
      error: error.message
    });
  }
});

// 清理缓存
router.delete('/cache', (req, res) => {
  try {
    freeStockDataService.clearExpiredCache();
    res.json({
      success: true,
      message: '缓存清理成功'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '缓存清理失败',
      error: error.message
    });
  }
});

// 检查AKShare环境
router.get('/akshare/status', async (req, res) => {
  try {
    const status = await freeStockDataService.checkAKShareEnvironment();
    res.json({
      success: true,
      data: status,
      message: 'AKShare环境检查完成'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'AKShare环境检查失败',
      error: error.message
    });
  }
});

// 安装AKShare依赖
router.post('/akshare/install', async (req, res) => {
  try {
    const result = await freeStockDataService.installAKShareDependencies();
    res.json({
      success: true,
      data: result,
      message: 'AKShare依赖安装成功'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'AKShare依赖安装失败',
      error: error.message
    });
  }
});

// 启用/禁用AKShare
router.put('/akshare/toggle', (req, res) => {
  try {
    const { enabled } = req.body;
    freeStockDataService.setAKShareEnabled(enabled);
    res.json({
      success: true,
      message: `AKShare已${enabled ? '启用' : '禁用'}`,
      data: { enabled }
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: 'AKShare状态切换失败',
      error: error.message
    });
  }
});

// 获取所有数据源状态
router.get('/datasources', (req, res) => {
  try {
    const status = freeStockDataService.getDataSourceStatus();
    res.json({
      success: true,
      data: status,
      message: '数据源状态获取成功'
    });
  } catch (error) {
    res.status(500).json({
      success: false,
      message: '数据源状态获取失败',
      error: error.message
    });
  }
});

// 获取股票名称
function getStockName(symbol) {
  const nameMap = {
    'sh000300': '沪深300',
    'sh000001': '上证指数',
    'sz399001': '深证成指',
    'sz399006': '创业板指',
    '600519': '贵州茅台',
    '000858': '五粮液',
    '600036': '招商银行',
    '000001': '平安银行',
    '000002': '万科A',
    '600276': '恒瑞医药'
  };
  return nameMap[symbol] || '未知股票';
}

module.exports = router;