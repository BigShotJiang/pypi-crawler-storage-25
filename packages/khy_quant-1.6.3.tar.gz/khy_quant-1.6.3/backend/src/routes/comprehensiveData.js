/**
 * 综合数据路由
 */
const express = require('express');
const router = express.Router();
const comprehensiveDataController = require('../controllers/comprehensiveDataController');

// 获取K线数据（新增）
router.get('/kline', comprehensiveDataController.getKlineData);

// 获取综合金融数据
router.get('/data/:symbol', comprehensiveDataController.getComprehensiveData);

// 获取数据源状态
router.get('/sources/status', comprehensiveDataController.getDataSourceStatus);

// 获取支持的金融标的
router.get('/instruments', comprehensiveDataController.getSupportedInstruments);

// 搜索金融标的
router.get('/instruments/search', comprehensiveDataController.searchInstruments);

// 获取市场信息
router.get('/markets/:marketCode?', comprehensiveDataController.getMarketInfo);

// 获取数据范围
router.get('/range/:symbol', comprehensiveDataController.getDataRange);

// 批量获取数据
router.post('/batch', comprehensiveDataController.getBatchData);

// 清理缓存
router.post('/cache/clear', comprehensiveDataController.clearCache);

// 测试单个数据源
router.post('/sources/test', comprehensiveDataController.testDataSource);

// 批量测试数据源
router.post('/sources/test-all', comprehensiveDataController.testAllDataSources);

// 测试单个数据源（GET方法，用于前端数据源管理页面）
router.get('/test-source/:sourceId', comprehensiveDataController.testSingleSource);

// 获取数据源配置（GET方法）
router.get('/sources/config', comprehensiveDataController.getDataSourceConfig);

// 更新数据源配置（激活/禁用数据源）
router.post('/sources/config', comprehensiveDataController.updateDataSourceConfig);

// 获取已启用的数据源列表
router.get('/sources/enabled', comprehensiveDataController.getEnabledDataSources);

// 切换数据源
router.post('/sources/switch', comprehensiveDataController.switchDataSource);

module.exports = router;