const express = require('express');
const router = express.Router();
const UserLogService = require('../services/userLogService');
const SystemSettingService = require('../services/systemSettingService');
const { authenticateToken, requireAdmin } = require('../middleware/auth');
const { isAllowedSettingKey } = require('../config/settingsWhitelist');
const bcrypt = require('bcryptjs');
const { User } = require('../models');
const { Op } = require('sequelize');
const { sequelize, Strategy, Announcement, Feedback, Trade } = require('../models');

// GET /api/admin/stats — real counts from database
router.get('/stats', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const [totalUsers, totalStrategies, totalAnnouncements] = await Promise.all([
      User.count(),
      Strategy.count().catch(() => 0),
      Announcement.count().catch(() => 0)
    ]);
    res.json({
      success: true,
      data: {
        totalUsers,
        totalStrategies,
        totalAnnouncements,
        onlineUsers: 0
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/admin/activities — recent user registrations and actions
router.get('/activities', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const recentUsers = await User.findAll({
      order: [['created_at', 'DESC']],
      limit: 10,
      attributes: ['id', 'username', 'created_at']
    });
    const activities = recentUsers.map(u => ({
      id: u.id,
      type: 'user',
      description: `新用户 ${u.username} 注册成功`,
      createdAt: u.created_at
    }));
    res.json({ success: true, data: activities });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/admin/system-status — real system health check
router.get('/system-status', authenticateToken, requireAdmin, async (req, res) => {
  try {
    let dbOk = false;
    try {
      await sequelize.authenticate();
      dbOk = true;
    } catch (e) {}
    res.json({
      success: true,
      data: {
        database: dbOk,
        websocket: true,
        aiService: false,
        load: '正常'
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// 创建测试管理员（仅开发环境可用）
router.post('/create-test-admin', async (req, res) => {
  if (process.env.NODE_ENV !== 'development') {
    return res.status(403).json({ success: false, message: 'Only available in development mode' });
  }

  try {
    // 检查是否已存在管理员
    const existingAdmin = await User.findOne({ where: { role: 'admin' } });
    
    if (existingAdmin) {
      return res.json({
        success: true,
        message: '管理员账号已存在'
      });
    }

    // 创建测试管理员
    const hashedPassword = await bcrypt.hash('admin123.', 10);
    
    const admin = await User.create({
      username: 'admin',
      email: 'admin@khyquant.com',
      password: hashedPassword,
      role: 'admin',
      status: 'active'
    });

    res.json({
      success: true,
      message: '测试管理员创建成功',
      username: 'admin',
      password: 'admin123.'
    });

  } catch (error) {
    console.error('创建测试管理员失败:', error);
    res.status(500).json({
      success: false,
      message: '创建测试管理员失败',
      error: error.message
    });
  }
});

// 获取用户日志列表
router.get('/user-logs', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const {
      page = 1,
      limit = 20,
      userId,
      action,
      status,
      startDate,
      endDate,
      search
    } = req.query;

    const result = await UserLogService.getUserLogs({
      page: parseInt(page),
      limit: parseInt(limit),
      userId: userId ? parseInt(userId) : undefined,
      action,
      status,
      startDate,
      endDate,
      search
    });

    res.json({
      success: true,
      data: result,
      message: '获取用户日志成功'
    });
  } catch (error) {
    console.error('获取用户日志失败:', error);
    res.status(500).json({
      success: false,
      message: '获取用户日志失败',
      error: error.message
    });
  }
});

// 获取用户活动统计
router.get('/user-activity-stats', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { days = 30 } = req.query;
    const stats = await UserLogService.getUserActivityStats(parseInt(days));

    res.json({
      success: true,
      data: stats,
      message: '获取用户活动统计成功'
    });
  } catch (error) {
    console.error('获取用户活动统计失败:', error);
    res.status(500).json({
      success: false,
      message: '获取用户活动统计失败',
      error: error.message
    });
  }
});

// 清理旧日志
router.delete('/user-logs/cleanup', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { daysToKeep = 90 } = req.body;
    const deletedCount = await UserLogService.cleanOldLogs(parseInt(daysToKeep));

    res.json({
      success: true,
      data: { deletedCount },
      message: `成功清理 ${deletedCount} 条旧日志记录`
    });
  } catch (error) {
    console.error('清理旧日志失败:', error);
    res.status(500).json({
      success: false,
      message: '清理旧日志失败',
      error: error.message
    });
  }
});

// 导出用户日志
router.get('/user-logs/export', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const {
      userId,
      action,
      status,
      startDate,
      endDate,
      search
    } = req.query;

    const result = await UserLogService.getUserLogs({
      page: 1,
      limit: 10000, // 导出大量数据
      userId: userId ? parseInt(userId) : undefined,
      action,
      status,
      startDate,
      endDate,
      search
    });

    // 设置CSV响应头
    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename=user-logs.csv');

    // CSV头部
    const csvHeader = 'ID,用户ID,用户名,操作类型,操作描述,IP地址,状态,时间\n';
    res.write('\uFEFF' + csvHeader); // 添加BOM以支持中文

    // CSV数据
    result.logs.forEach(log => {
      const row = [
        log.id,
        log.userId,
        log.username,
        log.action,
        log.actionDescription || '',
        log.ipAddress || '',
        log.status,
        new Date(log.timestamp).toLocaleString('zh-CN')
      ].map(field => `"${String(field).replace(/"/g, '""')}"`).join(',');
      
      res.write(row + '\n');
    });

    res.end();
  } catch (error) {
    console.error('导出用户日志失败:', error);
    res.status(500).json({
      success: false,
      message: '导出用户日志失败',
      error: error.message
    });
  }
});

// 更新用户信息
router.put('/users/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { username, email, role, status } = req.body;

    const user = await User.findByPk(id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: '用户不存在'
      });
    }

    // 更新用户信息
    await user.update({
      username: username || user.username,
      email: email || user.email,
      role: role || user.role,
      status: status || user.status
    });

    // 记录操作日志
    await UserLogService.logUserAction({
      userId: user.id,
      username: user.username,
      action: 'profile_update_by_admin',
      actionDescription: `管理员更新用户信息`,
      ipAddress: req.ip,
      userAgent: req.get('User-Agent'),
      status: 'success',
      details: { updatedBy: req.user.id, updatedFields: Object.keys(req.body) }
    });

    res.json({
      success: true,
      data: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        status: user.status,
        lastLoginAt: user.lastLoginAt,
        createdAt: user.createdAt,
        updatedAt: user.updatedAt
      },
      message: '用户信息更新成功'
    });
  } catch (error) {
    console.error('更新用户信息失败:', error);
    res.status(500).json({
      success: false,
      message: '更新用户信息失败',
      error: error.message
    });
  }
});

// 删除用户
router.delete('/users/:id', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;

    // 不能删除自己
    if (parseInt(id) === req.user.id) {
      return res.status(400).json({
        success: false,
        message: '不能删除自己的账号'
      });
    }

    const user = await User.findByPk(id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: '用户不存在'
      });
    }

    // 记录操作日志
    await UserLogService.logUserAction({
      userId: user.id,
      username: user.username,
      action: 'account_deleted_by_admin',
      actionDescription: `管理员删除用户账号`,
      ipAddress: req.ip,
      userAgent: req.get('User-Agent'),
      status: 'success',
      details: { deletedBy: req.user.id }
    });

    await user.destroy();

    res.json({
      success: true,
      message: '用户删除成功'
    });
  } catch (error) {
    console.error('删除用户失败:', error);
    res.status(500).json({
      success: false,
      message: '删除用户失败',
      error: error.message
    });
  }
});

// 重置用户密码
router.post('/users/:id/reset-password', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { id } = req.params;
    const { newPassword } = req.body;

    if (!newPassword || newPassword.length < 6) {
      return res.status(400).json({
        success: false,
        message: '新密码长度至少6位'
      });
    }

    const user = await User.findByPk(id);
    if (!user) {
      return res.status(404).json({
        success: false,
        message: '用户不存在'
      });
    }

    // 更新密码
    const hashedPassword = await bcrypt.hash(newPassword, 10);
    await user.update({ password: hashedPassword });

    // 记录操作日志
    await UserLogService.logUserAction({
      userId: user.id,
      username: user.username,
      action: 'password_reset_by_admin',
      actionDescription: `管理员重置用户密码`,
      ipAddress: req.ip,
      userAgent: req.get('User-Agent'),
      status: 'success',
      details: { resetBy: req.user.id }
    });

    res.json({
      success: true,
      message: '密码重置成功'
    });
  } catch (error) {
    console.error('重置密码失败:', error);
    res.status(500).json({
      success: false,
      message: '重置密码失败',
      error: error.message
    });
  }
});

// 创建新用户
router.post('/users', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { username, email, password, role = 'user', status = 'active' } = req.body;

    // 验证必填字段
    if (!username || !email || !password) {
      return res.status(400).json({
        success: false,
        message: '用户名、邮箱和密码为必填项'
      });
    }

    // 检查用户名和邮箱是否已存在
    const existingUser = await User.findOne({
      where: {
        [Op.or]: [
          { username },
          { email }
        ]
      }
    });

    if (existingUser) {
      return res.status(400).json({
        success: false,
        message: '用户名或邮箱已存在'
      });
    }

    // 创建用户
    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await User.create({
      username,
      email,
      password: hashedPassword,
      role,
      status
    });

    // 记录操作日志
    await UserLogService.logUserAction({
      userId: user.id,
      username: user.username,
      action: 'account_created_by_admin',
      actionDescription: `管理员创建用户账号`,
      ipAddress: req.ip,
      userAgent: req.get('User-Agent'),
      status: 'success',
      details: { createdBy: req.user.id }
    });

    res.status(201).json({
      success: true,
      data: {
        id: user.id,
        username: user.username,
        email: user.email,
        role: user.role,
        status: user.status,
        createdAt: user.createdAt
      },
      message: '用户创建成功'
    });
  } catch (error) {
    console.error('创建用户失败:', error);
    res.status(500).json({
      success: false,
      message: '创建用户失败',
      error: error.message
    });
  }
});

// ========================================
//              系统设置管理
// ========================================

// 获取系统设置
router.get('/system/settings', authenticateToken, requireAdmin, async (req, res) => {
  try {
    // Try real DB settings first
    let data;
    try {
      data = await SystemSettingService.getAllSettings({ includePrivate: true });
    } catch (dbErr) {
      console.warn('DB settings unavailable, using fallback:', dbErr.message);
      data = null;
    }

    if (data && Object.keys(data).length > 0) {
      return res.json({ success: true, data, message: '获取系统设置成功' });
    }

    // Fallback mock data
    const mockSettings = {
      system: [
        { key: 'system.name', value: 'KHY-Quant 量化交易系统', type: 'string', description: '系统名称', isEditable: true },
        { key: 'system.version', value: '1.0.0', type: 'string', description: '系统版本', isEditable: false },
        { key: 'system.description', value: '专业的量化交易平台', type: 'text', description: '系统描述', isEditable: true },
        { key: 'system.maintenance_mode', value: false, type: 'boolean', description: '维护模式', isEditable: true }
      ],
      user: [
        { key: 'user.registration_enabled', value: true, type: 'boolean', description: '允许用户注册', isEditable: true },
        { key: 'user.session_timeout', value: 7, type: 'number', description: '会话超时时间（天）', isEditable: true }
      ],
      security: [
        { key: 'security.password_min_length', value: 6, type: 'number', description: '密码最小长度', isEditable: true },
        { key: 'security.login_attempts_limit', value: 5, type: 'number', description: '登录尝试次数限制', isEditable: true }
      ],
      trading: [
        { key: 'trading.default_commission', value: 0.0003, type: 'number', description: '默认手续费率', isEditable: true },
        { key: 'trading.max_positions', value: 10, type: 'number', description: '最大持仓数量', isEditable: true },
        { key: 'kline.enabled_periods', value: ['daily'], type: 'json', description: 'K线允许显示的时间周期', isEditable: true }
      ]
    };

    res.json({
      success: true,
      data: mockSettings,
      message: '获取系统设置成功'
    });
  } catch (error) {
    console.error('获取系统设置失败:', error);
    res.status(500).json({
      success: false,
      message: '获取系统设置失败',
      error: error.message
    });
  }
});

// 更新系统设置
router.put('/system/settings', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { settings } = req.body;

    if (!settings || typeof settings !== 'object') {
      return res.status(400).json({
        success: false,
        message: '设置数据格式错误'
      });
    }

    // Validate setting keys against allowed prefixes
    const invalidKeys = Object.keys(settings).filter(k => !isAllowedSettingKey(k));
    if (invalidKeys.length > 0) {
      return res.status(400).json({
        success: false,
        message: `不允许的设置项: ${invalidKeys.join(', ')}`
      });
    }

    // Save settings via SystemSettingService
    const results = {};
    for (const [key, value] of Object.entries(settings)) {
      results[key] = await SystemSettingService.setSetting(key, value);
    }

    // Log admin action
    await UserLogService.logUserAction({
      userId: req.user.id,
      username: req.user.username,
      action: 'system_settings_update',
      actionDescription: '管理员更新系统设置',
      ipAddress: req.ip,
      userAgent: req.get('User-Agent'),
      status: 'success',
      details: { updatedSettings: Object.keys(settings) }
    });

    res.json({
      success: true,
      data: settings,
      message: '系统设置更新成功'
    });
  } catch (error) {
    console.error('更新系统设置失败:', error);
    res.status(500).json({
      success: false,
      message: '更新系统设置失败',
      error: error.message
    });
  }
});

// 获取系统信息
router.get('/system/info', authenticateToken, requireAdmin, async (req, res) => {
  try {
    // 获取系统统计信息
    const [userCount, strategyCount, backtestCount, tradeCount] = await Promise.all([
      User.count(),
      // 暂时使用固定值，避免模型依赖问题
      Promise.resolve(0), // Strategy.count(),
      Promise.resolve(0), // Backtest.count(),
      Promise.resolve(0)  // Trade.count()
    ]);

    const systemInfo = {
      settings: {
        system: [
          { key: 'system.name', value: 'KHY-Quant 量化交易系统' },
          { key: 'system.version', value: '1.0.0' }
        ]
      },
      statistics: {
        userCount,
        strategyCount,
        backtestCount,
        tradeCount
      },
      systemInfo: {
        nodeVersion: process.version,
        platform: process.platform,
        uptime: process.uptime(),
        memoryUsage: process.memoryUsage()
      }
    };

    res.json({
      success: true,
      data: systemInfo,
      message: '获取系统信息成功'
    });
  } catch (error) {
    console.error('获取系统信息失败:', error);
    res.status(500).json({
      success: false,
      message: '获取系统信息失败',
      error: error.message
    });
  }
});

// 重置设置为默认值
router.post('/system/settings/reset', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { key } = req.body;

    if (!key) {
      return res.status(400).json({
        success: false,
        message: '请指定要重置的设置项'
      });
    }

    // 暂时模拟重置成功
    const defaultValues = {
      'system.name': 'KHY-Quant 量化交易系统',
      'system.maintenance_mode': false,
      'user.registration_enabled': true,
      'security.password_min_length': 6,
      'trading.default_commission': 0.0003
    };

    const defaultValue = defaultValues[key] || null;

    // 记录操作日志
    await UserLogService.logUserAction({
      userId: req.user.id,
      username: req.user.username,
      action: 'system_setting_reset',
      actionDescription: `管理员重置系统设置: ${key}`,
      ipAddress: req.ip,
      userAgent: req.get('User-Agent'),
      status: 'success',
      details: { resetKey: key }
    });

    res.json({
      success: true,
      data: { key, value: defaultValue },
      message: '设置重置成功'
    });
  } catch (error) {
    console.error('重置设置失败:', error);
    res.status(500).json({
      success: false,
      message: '重置设置失败',
      error: error.message
    });
  }
});

// 初始化默认设置
router.post('/system/settings/initialize', authenticateToken, requireAdmin, async (req, res) => {
  try {
    // 暂时模拟初始化成功
    console.log('初始化默认设置...');

    // 记录操作日志
    await UserLogService.logUserAction({
      userId: req.user.id,
      username: req.user.username,
      action: 'system_settings_initialize',
      actionDescription: '管理员初始化系统默认设置',
      ipAddress: req.ip,
      userAgent: req.get('User-Agent'),
      status: 'success'
    });

    res.json({
      success: true,
      message: '默认设置初始化成功'
    });
  } catch (error) {
    console.error('初始化默认设置失败:', error);
    res.status(500).json({
      success: false,
      message: '初始化默认设置失败',
      error: error.message
    });
  }
});

// ========================================
//         资金管理 & 交易记录
// ========================================

// GET /api/admin/users/:userId/account — get one user's fund summary
router.get('/users/:userId/account', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { userId } = req.params;
    const user = await User.findByPk(userId);
    if (!user) return res.status(404).json({ success: false, message: '用户不存在' });

    const trades = await Trade.findAll({
      where: { user_id: userId, status: 'filled' }
    });

    const initialFunds = 1000000.00;
    let totalProfit = 0, positionCost = 0, positionValue = 0;
    const today = new Date(); today.setHours(0, 0, 0, 0);
    let todayProfit = 0;

    trades.forEach(trade => {
      if (trade.isClosed && trade.profit) {
        totalProfit += parseFloat(trade.profit);
        if (trade.closedAt && new Date(trade.closedAt) >= today) {
          todayProfit += parseFloat(trade.profit);
        }
      } else if (!trade.isClosed && trade.side === 'buy') {
        positionCost += parseFloat(trade.amount);
        positionValue += parseFloat(trade.amount);
      }
    });

    const availableFunds = initialFunds + totalProfit - positionCost;
    res.json({
      success: true,
      data: {
        userId: parseInt(userId),
        username: user.username,
        initialFunds,
        availableFunds: parseFloat(availableFunds.toFixed(2)),
        totalAssets: parseFloat((availableFunds + positionValue).toFixed(2)),
        totalProfit: parseFloat(totalProfit.toFixed(2)),
        todayProfit: parseFloat(todayProfit.toFixed(2)),
        positionValue: parseFloat(positionValue.toFixed(2)),
        tradeCount: trades.length
      }
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/admin/funds — all users fund overview
router.get('/funds', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const users = await User.findAll({
      attributes: ['id', 'username', 'email', 'status', 'createdAt']
    });

    const initialFunds = 1000000.00;
    const fundsData = await Promise.all(users.map(async (user) => {
      const trades = await Trade.findAll({
        where: { user_id: user.id, status: 'filled' }
      });
      let totalProfit = 0, positionCost = 0;
      trades.forEach(trade => {
        if (trade.isClosed && trade.profit) totalProfit += parseFloat(trade.profit);
        else if (!trade.isClosed && trade.side === 'buy') positionCost += parseFloat(trade.amount);
      });
      const availableFunds = initialFunds + totalProfit - positionCost;
      return {
        userId: user.id,
        username: user.username,
        email: user.email,
        status: user.status,
        initialFunds,
        availableFunds: parseFloat(availableFunds.toFixed(2)),
        totalProfit: parseFloat(totalProfit.toFixed(2)),
        tradeCount: trades.length,
        registeredAt: user.createdAt
      };
    }));

    res.json({ success: true, data: fundsData });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/admin/trades — all users trade records with filters
router.get('/trades', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { userId, symbol, side, status, type, startDate, endDate, page = 1, pageSize = 20 } = req.query;
    const where = {};
    if (userId) where.user_id = userId;
    if (symbol) where.symbol = { [Op.like]: `%${symbol}%` };
    if (side) where.side = side;
    if (status) where.status = status;
    if (type) where.type = type;
    if (startDate || endDate) {
      where.createdAt = {};
      if (startDate) where.createdAt[Op.gte] = new Date(startDate);
      if (endDate) where.createdAt[Op.lte] = new Date(endDate + ' 23:59:59');
    }

    const offset = (parseInt(page) - 1) * parseInt(pageSize);
    const { count, rows } = await Trade.findAndCountAll({
      where,
      include: [{ model: User, attributes: ['username', 'email'], as: 'user' }],
      order: [['createdAt', 'DESC']],
      limit: parseInt(pageSize),
      offset
    });

    res.json({
      success: true,
      data: rows,
      total: count,
      page: parseInt(page),
      pageSize: parseInt(pageSize)
    });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// GET /api/admin/users/:userId/trades — one user's trade records
router.get('/users/:userId/trades', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const { userId } = req.params;
    const { page = 1, pageSize = 20 } = req.query;
    const offset = (parseInt(page) - 1) * parseInt(pageSize);

    const { count, rows } = await Trade.findAndCountAll({
      where: { user_id: userId },
      order: [['createdAt', 'DESC']],
      limit: parseInt(pageSize),
      offset
    });

    res.json({ success: true, data: rows, total: count });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// ============ AKShare Version Management ============
const akshareUpdater = require('../services/akshareUpdater');

// GET /api/admin/akshare/status
router.get('/akshare/status', authenticateToken, requireAdmin, async (req, res) => {
  try {
    const status = akshareUpdater.getStatus();
    res.json({ success: true, data: status });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

// POST /api/admin/akshare/check — manual trigger
router.post('/akshare/check', authenticateToken, requireAdmin, async (req, res) => {
  try {
    console.log('🔧 Admin triggered AKShare version check');
    const result = await akshareUpdater.checkAndUpdate(true);
    res.json({ success: true, data: result });
  } catch (error) {
    res.status(500).json({ success: false, error: error.message });
  }
});

module.exports = router;