/**
 * Database Configuration & Factory (数据治理层 - 数据库工厂)
 *
 * Implements the Factory pattern for dual database support:
 *   - PostgreSQL (production, Docker deployment)
 *   - SQLite (development, standalone deployment)
 * Auto-detects PostgreSQL availability and falls back to SQLite.
 * See thesis Chapter 4.5 (DatabaseFactory pattern).
 */
const { Sequelize } = require('sequelize');
const path = require('path');
const net = require('net');
const logger = require('../utils/logger');
require('dotenv').config({ path: path.join(__dirname, '../../.env') });

/**
 * Test TCP connectivity to PostgreSQL (localhost:5432) with 2s timeout.
 * Returns true if reachable.
 */
function testPostgresPort(host, port, timeout) {
  return new Promise(resolve => {
    const sock = new net.Socket();
    let done = false;
    const finish = ok => { if (!done) { done = true; sock.destroy(); resolve(ok); } };
    sock.setTimeout(timeout);
    sock.on('connect', () => finish(true));
    sock.on('error', () => finish(false));
    sock.on('timeout', () => finish(false));
    sock.connect(port, host);
  });
}

/**
 * Determine the SQLite database file path.
 * Prefers SQLITE_DB_PATH env, then Electron userData via DB_SQLITE_PATH env,
 * then falls back to backend/data/khy-quant.db.
 */
function getSQLitePath() {
  if (process.env.SQLITE_DB_PATH) return process.env.SQLITE_DB_PATH;
  if (process.env.DB_PATH) return process.env.DB_PATH;
  return path.join(__dirname, '../../data/khy-quant.db');
}

let sequelize;
let dbMode = process.env.DB_TYPE || 'auto'; // 'postgres', 'sqlite', or 'auto'

console.log('Database config:');
console.log('  DB_TYPE:', dbMode);

/**
 * Create Sequelize instance.
 * 重要：server.js 会在初始化前加载路由与模型，因此 auto 模式必须先给出稳定方言。
 * 这里默认让 auto 直接走 SQLite，避免“模型先绑定 Postgres、后切 SQLite”导致的运行期 500。
 */
function createPostgresSequelize() {
  const host = process.env.DB_HOST || 'localhost';
  const port = process.env.DB_PORT || 5432;
  const dbName = process.env.DB_NAME || 'quant_trading';
  const user = process.env.DB_USER || 'postgres';
  const password = process.env.DB_PASSWORD || '';
  const queryTimeoutMs = parseInt(process.env.DB_QUERY_TIMEOUT_MS || '30000', 10);

  console.log('  DB_HOST:', host);
  console.log('  DB_PORT:', port);
  console.log('  DB_NAME:', dbName);
  console.log('  DB_USER:', user);

  return new Sequelize(dbName, user, password, {
    host,
    port,
    dialect: 'postgres',
    dialectOptions: {
      charset: 'utf8mb4',
      client_encoding: 'UTF8',
      statement_timeout: queryTimeoutMs,
      query_timeout: queryTimeoutMs,
    },
    logging: process.env.NODE_ENV === 'development'
      ? (sql, timing) => logger.debug('sequelize query', { sql, timing })
      : false,
    pool: {
      max: parseInt(process.env.DB_POOL_MAX || '10', 10),
      min: parseInt(process.env.DB_POOL_MIN || '0', 10),
      acquire: queryTimeoutMs,
      idle: parseInt(process.env.DB_POOL_IDLE_MS || '10000', 10)
    },
    define: {
      timestamps: true,
      underscored: true,
      charset: 'utf8mb4',
      collate: 'utf8mb4_unicode_ci',
    },
  });
}

function createSQLiteSequelize() {
  const dbPath = getSQLitePath();
  console.log('  Using SQLite:', dbPath);
  let dialectModule;
  try {
    // 优先使用 sqlite3（若环境已安装）
    dialectModule = require('sqlite3');
  } catch (error) {
    // 在缺少 sqlite3 时，退化到 better-sqlite3 兼容层，避免服务无法启动
    console.warn('  sqlite3 不可用，切换到 better-sqlite3 兼容层:', error.message);
    dialectModule = require('./sqliteCompat');
  }

  // Ensure directory exists
  const fs = require('fs');
  const dir = path.dirname(dbPath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  return new Sequelize({
    dialect: 'sqlite',
    dialectModule,
    storage: dbPath,
    logging: process.env.NODE_ENV === 'development'
      ? (sql, timing) => logger.debug('sequelize sqlite query', { sql, timing })
      : false,
    define: {
      timestamps: true,
      underscored: true,
    },
    pool: {
      acquire: parseInt(process.env.DB_QUERY_TIMEOUT_MS || '30000', 10)
    }
  });
}

// Initial creation based on explicit config
if (dbMode === 'sqlite' || dbMode === 'auto') {
  sequelize = createSQLiteSequelize();
} else {
  // Explicit postgres mode
  sequelize = createPostgresSequelize();
}

/**
 * Initialize database connection.
 * In 'auto' mode: tests PostgreSQL port first; if unreachable, switches to SQLite.
 * Sets process.env.DB_MODE for other services to read.
 */
async function initDatabase() {
  if (dbMode === 'sqlite') {
    process.env.DB_MODE = 'sqlite';
    console.log('  DB_MODE: sqlite (explicit)');
    return sequelize;
  }

  if (dbMode === 'auto') {
    process.env.DB_MODE = 'sqlite';
    process.env.DB_TYPE = 'sqlite';
    console.log('  DB_MODE: sqlite (auto-default)');
    return sequelize;
  }

  if (dbMode === 'postgres') {
    const host = process.env.DB_HOST || 'localhost';
    const port = parseInt(process.env.DB_PORT || '5432');
    const reachable = await testPostgresPort(host, port, 2000);

    if (reachable) {
      try {
        await sequelize.authenticate();
        process.env.DB_MODE = 'postgres';
        console.log('  DB_MODE: postgres (connected)');
        return sequelize;
      } catch (err) {
        console.warn('  PostgreSQL auth failed:', err.message);
      }
    } else {
      console.warn(`  PostgreSQL unreachable at ${host}:${port}`);
    }

    // Explicit postgres mode but failed — keep postgres sequelize, let caller handle retries
    process.env.DB_MODE = 'postgres';
    return sequelize;
  }

  process.env.DB_MODE = dbMode;
  return sequelize;
}

module.exports = { sequelize, initDatabase, getSQLitePath };
