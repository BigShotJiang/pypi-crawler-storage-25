/**
 * Apply backend environment defaults once at startup.
 */
function applyEnvDefaults() {
  const defaults = {
    NODE_ENV: 'development',
    PORT: '8080',
    DB_TYPE: 'auto',
    DB_QUERY_TIMEOUT_MS: '30000',
    AKSHARE_SCRIPT_TIMEOUT_MS: '30000',
    RATE_LIMIT_API_MAX: '600',
    RATE_LIMIT_AUTH_MAX: '30',
    RATE_LIMIT_AI_MAX: '120',
    TRADING_AGENT_ANALYZE_TIMEOUT_MS: '30000',
    TRADING_AGENT_ML_TIMEOUT_MS: '20000',
    TRADING_AGENT_STOCK_TIMEOUT_MS: '15000',
    DB_SYNC_ALTER: 'false'
  };

  for (const [key, value] of Object.entries(defaults)) {
    if (process.env[key] === undefined || process.env[key] === '') {
      process.env[key] = value;
    }
  }
}

module.exports = { applyEnvDefaults };
