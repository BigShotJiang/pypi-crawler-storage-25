/**
 * Resolve KHY-Quant data home directory.
 *
 * Priority:
 *   1. KHY_DATA_HOME environment variable (explicit override)
 *   2. D:\.khyquant (Windows, if D: exists and has >1GB free)
 *   3. ~/.khyquant  (default fallback)
 *
 * All services should use getDataHome() instead of hardcoding os.homedir() + '.khyquant'.
 */
const os = require('os');
const path = require('path');
const fs = require('fs');

const MIN_FREE_BYTES = 1024 * 1024 * 1024; // 1 GB minimum

let _cached = null;

/**
 * Get the KHY-Quant data home directory path.
 * @returns {string} Absolute path to data directory (created if necessary)
 */
function getDataHome() {
  if (_cached) return _cached;

  // 1. Explicit override
  if (process.env.KHY_DATA_HOME) {
    _cached = process.env.KHY_DATA_HOME;
    _ensureDir(_cached);
    return _cached;
  }

  // 2. Windows: prefer D: drive if available and has space
  if (process.platform === 'win32') {
    const dDrive = 'D:\\';
    try {
      if (fs.existsSync(dDrive) && fs.statSync(dDrive).isDirectory()) {
        // Check free space on D:
        const { execSync } = require('child_process');
        try {
          const wmicOut = execSync('wmic logicaldisk where "DeviceID=\'D:\'" get FreeSpace /format:value', {
            encoding: 'utf-8', timeout: 5000, stdio: ['pipe', 'pipe', 'pipe'],
          });
          const match = wmicOut.match(/FreeSpace=(\d+)/);
          if (match && parseInt(match[1], 10) > MIN_FREE_BYTES) {
            _cached = path.join(dDrive, '.khyquant');
            _ensureDir(_cached);
            process.env.KHY_DATA_HOME = _cached;
            return _cached;
          }
        } catch { /* wmic failed, fall through */ }
      }
    } catch { /* D: not accessible, fall through */ }
  }

  // 3. Default: ~/.khyquant
  _cached = path.join(os.homedir(), '.khyquant');
  _ensureDir(_cached);
  process.env.KHY_DATA_HOME = _cached;
  return _cached;
}

/**
 * Get a subdirectory under data home.
 * @param {...string} segments Path segments relative to data home
 * @returns {string} Absolute path (directory created)
 */
function getDataDir(...segments) {
  const dir = path.join(getDataHome(), ...segments);
  _ensureDir(dir);
  return dir;
}

function _ensureDir(dir) {
  try { fs.mkdirSync(dir, { recursive: true }); } catch { /* ignore */ }
}

module.exports = { getDataHome, getDataDir };
