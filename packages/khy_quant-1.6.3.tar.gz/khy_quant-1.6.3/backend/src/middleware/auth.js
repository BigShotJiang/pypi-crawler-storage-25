/**
 * JWT Authentication Guard Middleware
 *
 * Access & Routing Layer (接入与路由层) - Step 5 of 5.
 * Verifies JWT token from the Authorization header and attaches
 * the decoded user to req.user. Also supports API key authentication.
 * See thesis Chapter 5.1 (JWT auth flow, Code Block 3).
 */
const jwt = require('jsonwebtoken');
const { User, ApiKey } = require('../models');

const authMiddleware = async (req, res, next) => {
  try {
    const token = req.headers.authorization?.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({
        success: false,
        message: '未提供认证令牌'
      });
    }

    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findByPk(decoded.userId);

    if (!user) {
      return res.status(401).json({
        success: false,
        message: '用户不存在'
      });
    }

    if (user.status !== 'active') {
      return res.status(403).json({
        success: false,
        message: '账户已被禁用'
      });
    }

    req.user = user;
    next();
  } catch (error) {
    return res.status(401).json({
      success: false,
      message: '认证失败',
      error: error.message
    });
  }
};

const adminMiddleware = (req, res, next) => {
  if (req.user.role !== 'admin') {
    return res.status(403).json({
      success: false,
      message: '需要管理员权限'
    });
  }
  next();
};

// Flexible auth: accepts JWT Bearer token OR X-API-Key header.
// Use this on endpoints that external scripts/services call.
const flexibleAuth = async (req, res, next) => {
  // --- Path A: JWT Bearer token ---
  const bearerToken = req.headers.authorization?.split(' ')[1];
  if (bearerToken) {
    try {
      const decoded = jwt.verify(bearerToken, process.env.JWT_SECRET);
      const user = await User.findByPk(decoded.userId);
      if (!user) {
        return res.status(401).json({ success: false, message: 'User not found' });
      }
      if (user.status !== 'active') {
        return res.status(403).json({ success: false, message: 'Account disabled' });
      }
      req.user = user;
      req.authMethod = 'jwt';
      return next();
    } catch {
      // JWT present but invalid — fall through to API key check
    }
  }

  // --- Path B: X-API-Key header ---
  const apiKeyValue = req.headers['x-api-key'];
  if (apiKeyValue) {
    try {
      const record = await ApiKey.findOne({
        where: { key: apiKeyValue, isActive: true },
        include: [{ model: User, as: 'user' }]
      });
      if (!record || !record.user) {
        return res.status(401).json({ success: false, message: 'Invalid or revoked API key' });
      }
      if (record.user.status !== 'active') {
        return res.status(403).json({ success: false, message: 'Account disabled' });
      }
      req.user = record.user;
      req.authMethod = 'apiKey';
      // Update lastUsedAt (fire-and-forget)
      record.update({ lastUsedAt: new Date() }).catch(() => {});
      return next();
    } catch {
      return res.status(401).json({ success: false, message: 'API key verification failed' });
    }
  }

  // --- Neither auth method provided ---
  return res.status(401).json({ success: false, message: 'Authentication required (Bearer token or X-API-Key)' });
};

// 别名导出以兼容不同的使用方式
const authenticateToken = authMiddleware;
const requireAdmin = adminMiddleware;

module.exports = {
  authMiddleware,
  adminMiddleware,
  flexibleAuth,
  authenticateToken,
  requireAdmin
};
