/**
 * Interactive REPL — the heart of the CLI.
 * Combines command mode, menu mode, and AI conversation mode.
 *
 * All heavy modules are lazy-loaded for fast cold start.
 */
const readline = require('readline');
const fs = require('fs');
const path = require('path');

// ── Lazy module loaders (Claude-style: zero top-level heavy requires) ──
let _chalk, _inquirer, _formatters, _router, _ai, _menu, _userProfile;
const chalk = () => (_chalk ??= require('chalk'));
const inquirer = () => (_inquirer ??= require('inquirer'));
const fmt = () => (_formatters ??= require('./formatters'));
const router = () => (_router ??= require('./router'));
const ai = () => (_ai ??= require('./ai'));
const menu = () => (_menu ??= require('./menu'));
const userProfile = () => (_userProfile ??= require('../services/userProfile'));

const os = require('os');
const HISTORY_FILE = path.join(os.homedir(), '.khyquant_history');
const MAX_HISTORY = 500;
const VERSION = process.env.KHYQUANT_PKG_VERSION || require('../../package.json').version;

// ── Terminal title (ANSI escape) ────────────────────────────────────────

function setTerminalTitle(title) {
  if (process.stdout.isTTY) {
    process.stdout.write(`\x1b]0;${title}\x07`);
  }
}

function updateTitleFromConversation(userMessage) {
  const topic = (userMessage || '').replace(/\n/g, ' ').slice(0, 30).trim();
  setTerminalTitle(topic ? `KHY-Quant · ${topic}` : 'KHY-Quant');
}

/**
 * Load command history from file.
 */
function loadHistory() {
  try {
    if (fs.existsSync(HISTORY_FILE)) {
      return fs.readFileSync(HISTORY_FILE, 'utf-8').split('\n').filter(Boolean);
    }
  } catch { /* ignore */ }
  return [];
}

/**
 * Save command history to file.
 */
function saveHistory(history) {
  try {
    const lines = history.slice(-MAX_HISTORY);
    fs.writeFileSync(HISTORY_FILE, lines.join('\n') + '\n');
  } catch { /* ignore */ }
}

/**
 * Offer interactive model selection at startup.
 * Shows a dropdown if multiple adapters/models are available.
 */
async function offerModelSelection() {
  try {
    const aiGateway = require('../services/gateway/aiGateway');

    // Quick sync detection of available adapters
    const allStatus = aiGateway.getStatus();
    const availableAdapters = allStatus.filter(s => s.enabled && s.available);

    if (availableAdapters.length === 0) return;

    // Gather models from all available adapters that support listModels
    const modelChoices = [];
    for (const adapter of availableAdapters) {
      if (adapter.refreshModels) {
        try {
          const models = await adapter.refreshModels();
          for (const model of models) {
            modelChoices.push({
              name: `${adapter.name} → ${model.name || model.id}${model.isDefault ? ' (默认)' : ''}`,
              value: { adapter: adapter.type, model: model.id },
            });
          }
        } catch { /* skip */ }
      } else {
        // Adapter without model list — add as single entry
        modelChoices.push({
          name: `${adapter.name}`,
          value: { adapter: adapter.type, model: null },
        });
      }
    }

    if (modelChoices.length <= 1) return; // No choice needed

    // Check if user has a saved preference — skip selection if so
    const currentAdapter = process.env.GATEWAY_PREFERRED_ADAPTER;
    const currentModel = process.env.GATEWAY_PREFERRED_MODEL;
    if (currentAdapter && currentModel) {
      // Already configured, show current and offer quick switch
      fmt().printInfo(`当前模型: ${currentAdapter}/${currentModel} — 输入 gateway model 切换`);
      return;
    }

    // Show interactive selection
    const inq = inquirer();
    console.log('');
    const { selected } = await inq.prompt([{
      type: 'list',
      name: 'selected',
      message: '选择 AI 模型 (上下箭头选择，回车确认，Esc跳过):',
      choices: [
        ...modelChoices,
        new inq.Separator(),
        { name: '跳过 (稍后用 gateway model 设置)', value: null },
      ],
      pageSize: 10,
    }]);

    if (selected) {
      process.env.GATEWAY_PREFERRED_ADAPTER = selected.adapter;
      if (selected.model) process.env.GATEWAY_PREFERRED_MODEL = selected.model;
      fmt().printSuccess(`已选择: ${selected.adapter}${selected.model ? '/' + selected.model : ''}`);
    }
  } catch {
    // Non-critical — silently skip if anything fails
  }
}

/**
 * Execute a menu result by mapping it back to command handlers.
 */
async function executeMenuResult(result) {
  if (!result) return;

  switch (result.action) {
    case 'quote': {
      const { handleQuote } = require('./handlers/data');
      await handleQuote(result.symbol);
      break;
    }
    case 'backtest-run': {
      const { handleBacktestRun } = require('./handlers/backtest');
      await handleBacktestRun(result.symbol, {
        strategy: result.strategy,
        start: result.start,
        end: result.end,
        capital: result.capital,
      });
      break;
    }
    case 'data-fetch': {
      const { handleDataFetch } = require('./handlers/data');
      await handleDataFetch(result.symbol);
      break;
    }
    case 'data-list': {
      const { handleDataList } = require('./handlers/data');
      await handleDataList();
      break;
    }
    case 'cache-clear': {
      const { handleCacheClear } = require('./handlers/data');
      await handleCacheClear();
      break;
    }
    case 'server-start': {
      const { handleServerStart } = require('./handlers/service');
      await handleServerStart();
      break;
    }
    case 'server-status': {
      const { handleServerStatus } = require('./handlers/service');
      await handleServerStatus();
      break;
    }
    case 'db-init': {
      const { handleDbInit } = require('./handlers/service');
      await handleDbInit();
      break;
    }
    case 'db-seed': {
      const { handleDbSeed } = require('./handlers/service');
      await handleDbSeed();
      break;
    }
    case 'db-status': {
      const { handleDbStatus } = require('./handlers/service');
      await handleDbStatus();
      break;
    }
    case 'ai-status':
      await ai().handleAiStatus();
      break;
    case 'ai-config':
      await ai().handleAiConfig();
      break;
    case 'doctor': {
      const { handleDoctor } = require('./handlers/init');
      await handleDoctor();
      break;
    }
    case 'gateway-status': {
      const { handleGatewayStatus } = require('./handlers/gateway');
      await handleGatewayStatus();
      break;
    }
    case 'gateway-config': {
      const { handleGatewayConfig } = require('./handlers/gateway');
      await handleGatewayConfig();
      break;
    }
    case 'gateway-relay': {
      const { handleGatewayRelay } = require('./handlers/gateway');
      await handleGatewayRelay();
      break;
    }
    case 'gateway-select-model': {
      const { handleGatewaySelectModel } = require('./handlers/gateway');
      await handleGatewaySelectModel();
      break;
    }
    case 'docs-quickstart': {
      const { handleDocsQuickstart } = require('./handlers/docs');
      await handleDocsQuickstart();
      break;
    }
    case 'docs-claude': {
      const { handleDocsClaude } = require('./handlers/docs');
      await handleDocsClaude();
      break;
    }
    case 'docs-gateway': {
      const { handleDocsGateway } = require('./handlers/docs');
      await handleDocsGateway();
      break;
    }
    case 'docs-strategy': {
      const { handleDocsStrategy } = require('./handlers/docs');
      await handleDocsStrategy();
      break;
    }
    case 'docs-faq': {
      const { handleDocsFaq } = require('./handlers/docs');
      await handleDocsFaq();
      break;
    }
  }
}

/**
 * Start the interactive REPL loop.
 */
async function startRepl() {
  // Load formatters + chalk now (needed for REPL UI)
  const { printBanner, printError, printSuccess, printInfo, ICON_PROMPT, ICON_BOT, MASCOT_MINI, getRandomFarewell } = fmt();
  const c = chalk();
  const { parseInput, route, getCompletions } = router();

  // Load renderer constants for inline use
  const { DOT_PENDING, DOT_ACTIVE, DOT_SUCCESS, DOT_ERROR } = require('./aiRenderer');
  const TREE_LAST = '└';

  // Set terminal window title
  setTerminalTitle('KHY-Quant');

  // Show banner
  const aiProvider = ai().getActiveProvider();
  printBanner(VERSION, aiProvider);

  // Display first-run getting-started guide (only on first ever launch)
  try {
    const gettingStarted = require('../services/gettingStartedService');
    gettingStarted.displayGettingStarted();
  } catch { /* non-critical */ }

  // Initialize proxy configuration from saved settings
  try {
    const proxyConfig = require('../services/proxyConfigService');
    proxyConfig.initFromConfig();
  } catch { /* proxy init is non-critical */ }

  // ── State variables (must be before setTimeout calls and renderStatusBar) ──
  let _busy = false;
  let _aiMode = process.env.KHYQUANT_AI_MODE === 'true' || userProfile().getAiModePreference();
  let _planMode = false;
  let _ctrlCCount = 0;
  let _ctrlCTimer = null;
  let _recentCommands = [];
  const PATTERN_WINDOW = 5;
  const _startupTimers = [];

  // Non-blocking: run data cleanup on startup + start periodic cleanup
  _startupTimers.push(setTimeout(() => {
    try {
      const cleanup = require('../services/cleanupService');
      const result = cleanup.runCleanup();
      cleanup.startPeriodicCleanup(); // Every 2 hours
      if (result.summary.actions.length > 0) {
        console.log(c.dim(`  ℹ 自动清理: ${result.summary.actions.join(', ')} (释放 ${result.summary.freedHuman})`));
      }
    } catch { /* cleanup failure is non-critical */ }
  }, 3000));

  // Non-blocking: start resource guard memory monitor
  _startupTimers.push(setTimeout(() => {
    try {
      const { startMemoryMonitor } = require('../services/resourceGuard');
      startMemoryMonitor();
    } catch { /* resource guard init is non-critical */ }
  }, 4000));

  // Non-blocking: apply hardware-based limits
  _startupTimers.push(setTimeout(() => {
    try {
      const hw = require('../services/hardwareProfileService');
      const profile = hw.detectProfile();
      hw.applyLimits();
      if (profile.isLightweight) {
        console.log(c.dim(`  ℹ 轻量模式: ${profile.profile} (${profile.memory.totalGB}GB RAM, ${profile.cpu.cores} cores)`));
      }
    } catch { /* hardware detection is non-critical */ }
  }, 2000));

  // Non-blocking: verify file integrity on startup
  _startupTimers.push(setTimeout(() => {
    try {
      const integrity = require('../services/fileIntegrityService');
      const ok = integrity.verifyOnStartup();
      if (!ok) {
        console.log(c.red('  ⚠ 文件完整性校验异常 — 部分核心文件已被修改'));
        console.log(c.dim('    运行 security 命令查看详情'));
        try { rl.prompt(); } catch { /* ignore */ }
      }
    } catch { /* integrity check is non-critical */ }
  }, 5000));

  // Non-blocking: check for updates
  _startupTimers.push(setTimeout(() => {
    try {
      const { getUpdateNotice } = require('../services/versionService');
      const notice = getUpdateNotice();
      if (notice && !_busy) {
        console.log(c.yellow(`  🔄 ${notice}`));
        try { rl.prompt(); } catch { /* ignore */ }
      }
    } catch { /* version check is non-critical */ }
  }, 5000));

  // Non-blocking: IDE adapter recovery check
  _startupTimers.push(setTimeout(async () => {
    try {
      const { recoverIdeAdapters, formatRecoveryMessage } = require('../services/versionService');
      const result = await recoverIdeAdapters();
      const msg = formatRecoveryMessage(result);
      if (msg && !_busy) {
        console.log(c.dim(`  ℹ IDE 适配器: ${msg}`));
        try { rl.prompt(); } catch { /* ignore */ }
      }
    } catch { /* IDE recovery is non-critical */ }
  }, 6000));

  // Non-blocking: prune old project memories
  _startupTimers.push(setTimeout(() => {
    try {
      const { pruneProjects } = require('../services/projectMemoryService');
      pruneProjects();
    } catch { /* non-critical */ }
  }, 4000));

  // Offer interactive model selection if multiple models are available
  await offerModelSelection();

  // Setup readline
  const history = loadHistory();

  const rl = readline.createInterface({
    input: process.stdin,
    output: process.stdout,
    prompt: c.cyan(MASCOT_MINI + ' khy') + c.dim(` ${ICON_PROMPT} `),
    historySize: MAX_HISTORY,
    completer: (line) => {
      const completions = getCompletions(line);
      return [completions.length > 0 ? completions : [], line];
    },
  });

  // Prepopulate history
  history.forEach(line => rl.history.push(line));

  // ── ESC key exit support (shares double-press counter with Ctrl+C) ──
  readline.emitKeypressEvents(process.stdin);
  if (process.stdin.isTTY && process.stdin.setRawMode) {
    // setRawMode is handled by readline internally, but we hook keypress
  }
  process.stdin.on('keypress', (_str, key) => {
    if (!key || key.name !== 'escape') return;
    _ctrlCCount++;
    if (_ctrlCCount >= 2) {
      ai().saveConversation();
      saveHistory(history);
      setTerminalTitle(''); // restore terminal title
      console.log('');
      console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
      console.log(c.dim('  对话已保存'));
      console.log('');
      process.exit(0);
    }
    console.log(c.yellow('\n  ⚠ 再按一次 ESC 或 Ctrl+C 退出'));
    if (_ctrlCTimer) clearTimeout(_ctrlCTimer);
    _ctrlCTimer = setTimeout(() => { _ctrlCCount = 0; }, 2000);
    try { rl.prompt(); } catch { /* readline might be closed */ }
  });

  // ── Status Bar (Claude Code style) ──────────────────────────────────
  let _statusBarEnabled = process.stdout.isTTY && process.stdout.columns > 60;

  function renderStatusBar() {
    if (!_statusBarEnabled) return;
    const cols = process.stdout.columns || 80;

    // Left side: shortcuts
    const left = c.bgBlack(
      c.dim(' /huifu') + c.dim(' 恢复上下文') +
      c.dim(' · ') +
      c.dim('/cost') + c.dim(' 费用') +
      c.dim(' · ') +
      c.dim('Ctrl+C×2') + c.dim(' 退出')
    );

    // Right side: context label
    const aiProvider = _aiMode ? (ai().getActiveProvider() || 'AI') : 'cmd';
    const tokenSvc = require('../services/tokenUsageService');
    const session = tokenSvc.getSessionUsage();
    const quota = tokenSvc.getRemainingQuota();
    let rightText = `${aiProvider}`;
    if (session.totalTokens > 0) {
      rightText += ` · ${session.totalTokens.toLocaleString()} tokens`;
    }
    if (quota.limit !== -1 && quota.limit > 0) {
      const pct = Math.round((quota.used / quota.limit) * 100);
      rightText += ` · ${100 - pct}% 余额`;
    }
    const right = c.bgBlack(c.cyan(` ${rightText} `));

    // Render at bottom
    const leftClean = left.replace(/\x1b\[[0-9;]*m/g, '');
    const rightClean = rightText;
    const padding = Math.max(0, cols - leftClean.length - rightClean.length - 4);

    // Save cursor, move to last row, print, restore cursor
    const statusLine = c.bgBlack(
      c.dim(' /huifu') + c.dim(' 恢复') +
      c.dim(' · /cost') + c.dim(' 费用') +
      c.dim(' · 2×Ctrl+C') + c.dim(' 退出') +
      ' '.repeat(Math.max(1, padding)) +
      c.cyan(rightText + ' ')
    );

    process.stdout.write(`\x1b[s\x1b[${process.stdout.rows};0H\x1b[K${statusLine}\x1b[u`);
  }

  // Refresh status bar periodically and on prompt
  const _origPrompt = rl.prompt.bind(rl);
  rl.prompt = (...args) => {
    _origPrompt(...args);
    renderStatusBar();
  };

  // Handle terminal resize
  if (process.stdout.on) {
    process.stdout.on('resize', () => {
      _statusBarEnabled = process.stdout.isTTY && process.stdout.columns > 60;
      renderStatusBar();
    });
  }

  rl.prompt();

  // Track session start
  userProfile().trackSessionStart();

  // Non-blocking: fetch remote config & announcements
  const cloudSync = require('../services/cloudSync');
  if (cloudSync.isEnabled()) {
    cloudSync.fetchRemoteConfig().catch(() => {});
    cloudSync.flushTelemetry().catch(() => {});
  }

  // Non-blocking: sync telemetry for admin (if enabled)
  try {
    const adminSvc = require('../services/adminService');
    adminSvc.syncTelemetry().catch(() => {});
  } catch { /* best effort */ }

  // Non-blocking: show skill learning suggestions (delayed, not intrusive)
  _startupTimers.push(setTimeout(() => {
    try {
      const { getSuggestedLearning } = require('../services/skillLearningService');
      const suggestions = getSuggestedLearning();
      if (suggestions.length > 0 && !_busy) {
        const s = suggestions[0]; // Show only the first suggestion
        console.log('');
        console.log(c.yellow(`  💡 学习建议: `) + c.white(s.name));
        console.log(c.dim(`     ${s.reason}`));
        console.log(c.dim(`     → ${s.action}`));
        console.log('');
        rl.prompt();
      }
    } catch { /* best effort */ }
  }, 8000)); // Show after 8 seconds

  // Non-blocking: start background security monitor (anti-mining, anti-trojan)
  try {
    const { startSecurityMonitor } = require('../services/securityGuardService');
    startSecurityMonitor();
  } catch { /* best effort */ }

  // /btw hint queue — non-interrupting hints queued while AI is working
  let _btwQueue = [];

  rl.on('line', async (line) => {
    const trimmed = line.trim();
    if (!trimmed) {
      rl.prompt();
      return;
    }

    // Slash command menu — when user types exactly "/"
    if (trimmed === '/') {
      try {
        const { SLASH_COMMANDS } = router();
        const inq = inquirer();
        console.log('');
        const { selected } = await inq.prompt([{
          type: 'list',
          name: 'selected',
          message: '选择命令:',
          choices: SLASH_COMMANDS.map(sc => ({
            name: `${c.cyan(sc.cmd.padEnd(14))} ${sc.label.padEnd(10)} ${c.dim(sc.desc)}`,
            value: sc,
          })),
          pageSize: 15,
          loop: false,
        }]);

        if (selected) {
          if (selected.flag) {
            // Handle special flags
            if (selected.flag.startsWith('effort-')) {
              const level = selected.flag.replace('effort-', '');
              if (ai().setEffort(level)) {
                const presets = ai().getEffortPresets();
                const p = presets[level];
                printSuccess(`模型精度已切换: ${level} (${p.label}) — temp=${p.temperature}, maxTokens=${p.maxTokens}`);
              }
            } else if (selected.flag === 'plan') {
              // Enter plan mode — next AI call will generate a structured plan
              _planMode = true;
              printInfo('计划模式已开启 — 下次 AI 回复将先制定执行计划');
            } else if (selected.flag === 'image') {
              // Prompt for image file path
              printInfo('用法: image <文件路径> <分析提示>  或  paste <分析提示>');
            } else if (selected.flag === 'paste') {
              // Trigger clipboard paste
              _btwQueue.push('paste');
              printInfo('已排队剪贴板粘贴 — 下次输入时自动执行');
            } else if (selected.flag === 'proxy') {
              // Proxy configuration (Clash / HTTP / SOCKS5)
              try {
                const proxyConfig = require('../services/proxyConfigService');
                const status = proxyConfig.getStatus();
                if (status.active) {
                  printSuccess(`代理已启用: ${status.url}`);
                  const { action } = await inquirer().prompt([{
                    type: 'list', name: 'action', message: '代理操作:',
                    choices: [
                      { name: '关闭代理', value: 'off' },
                      { name: '重新检测 Clash', value: 'detect' },
                      { name: '取消', value: 'cancel' },
                    ],
                  }]);
                  if (action === 'off') { proxyConfig.disableProxy(); printSuccess('代理已关闭'); }
                  else if (action === 'detect') {
                    const r = await proxyConfig.autoDetectAndEnable();
                    r.success ? printSuccess(`已检测并启用: ${r.proxy.url}`) : printError(r.error);
                  }
                } else {
                  const { action } = await inquirer().prompt([{
                    type: 'list', name: 'action', message: '代理设置:',
                    choices: [
                      { name: '自动检测 Clash', value: 'detect' },
                      { name: '手动配置 HTTP 代理', value: 'http' },
                      { name: '手动配置 SOCKS5 代理', value: 'socks5' },
                      { name: '取消', value: 'cancel' },
                    ],
                  }]);
                  if (action === 'detect') {
                    printInfo('正在检测 Clash...');
                    const r = await proxyConfig.autoDetectAndEnable();
                    r.success ? printSuccess(`已检测并启用: ${r.proxy.url}`) : printError(r.error);
                  } else if (action === 'http' || action === 'socks5') {
                    const { port } = await inquirer().prompt([{
                      type: 'input', name: 'port', message: `端口 (默认 ${action === 'http' ? '7890' : '1080'}):`,
                      default: action === 'http' ? '7890' : '1080',
                    }]);
                    const r = await proxyConfig.enableProxy({ type: action, host: '127.0.0.1', port });
                    r.success ? printSuccess(`代理已启用: ${r.proxy.url}`) : printError(r.error);
                  }
                }
              } catch (e) { printError(`代理配置失败: ${e.message}`); }
            } else if (selected.flag === 'models') {
              // Ollama / NVIDIA model management
              try {
                const ollamaMgr = require('../services/ollamaModelManager');
                const running = await ollamaMgr.isOllamaRunning();
                const hw = ollamaMgr.detectHardware();

                console.log('');
                printInfo(`硬件: ${hw.totalRamGB} GB RAM · ${hw.cpuCount} CPUs` + (hw.gpu ? ` · GPU: ${hw.gpu.name} (${(hw.gpu.vramMB / 1024).toFixed(1)} GB)` : ''));
                printInfo(`硬件等级: ${hw.tier.toUpperCase()} — Ollama ${running ? c.green('运行中') : c.yellow('未运行')}`);
                console.log('');

                if (running) {
                  const models = await ollamaMgr.listModels();
                  if (models.length > 0) {
                    printSuccess(`已安装 ${models.length} 个模型:`);
                    for (const m of models) {
                      console.log(c.dim(`    ${m.name}  (${m.size}, ${m.paramSize})`));
                    }
                  } else {
                    printInfo('暂无已安装模型');
                  }
                }

                const { recommended } = ollamaMgr.getRecommendations();
                console.log('');
                printInfo(`推荐模型 (${hw.tier} 级别):`);
                const choices = recommended.map((m, i) => ({
                  name: `${m.name} (${m.size}) — ${m.reason}`,
                  value: m.id,
                }));
                choices.push({ name: '取消', value: 'cancel' });

                const { modelId } = await inquirer().prompt([{
                  type: 'list', name: 'modelId', message: '选择要下载的模型:',
                  choices,
                }]);

                if (modelId !== 'cancel' && running) {
                  printInfo(`正在下载 ${modelId}...`);
                  await ollamaMgr.pullModel(modelId, (progress) => {
                    if (progress.total > 0 && process.stdout.isTTY) {
                      process.stdout.write(`\r  ⟳ ${progress.status} ${progress.percent}%`);
                    }
                  });
                  console.log('');
                  printSuccess(`模型 ${modelId} 下载完成!`);
                } else if (modelId !== 'cancel') {
                  printError('Ollama 未运行。请先安装并启动: https://ollama.ai');
                  printInfo(`或手动执行: ollama pull ${modelId}`);
                }
              } catch (e) { printError(`模型管理失败: ${e.message}`); }
            } else if (selected.flag === 'scan') {
              // Antivirus scan
              try {
                const av = require('../services/antivirusService');
                const tools = av.detectTools();
                if (!tools.hasClamAV) {
                  printError('ClamAV 未安装');
                  const inst = av.getInstallInstructions();
                  printInfo(`安装命令: ${inst.install}`);
                } else {
                  printInfo('正在扫描项目文件...');
                  const result = av.scanProject();
                  if (result.clean) {
                    printSuccess(`扫描完成: 未发现威胁 (${(result.elapsed / 1000).toFixed(1)}s)`);
                  } else {
                    printError(`发现 ${result.infected} 个威胁!`);
                    for (const t of result.threats) {
                      console.log(c.red(`    ${t.virus} → ${t.file}`));
                    }
                    printInfo('已隔离到 ~/.khyquant/quarantine/');
                  }
                }
              } catch (e) { printError(`扫描失败: ${e.message}`); }
            } else if (selected.flag === 'security-full') {
              // Full security status
              try {
                const secGuard = require('../services/securityGuardService');
                const integrity = require('../services/fileIntegrityService');
                const resGuard = require('../services/resourceGuard');

                // 1. File integrity
                console.log('');
                printInfo('文件完整性校验...');
                const intResult = integrity.verify();
                if (intResult.verified) {
                  printSuccess(`完整性: ${intResult.unchanged} 文件无改动`);
                } else {
                  printError(`完整性异常: ${intResult.modified.length} 修改, ${intResult.removed.length} 删除`);
                  for (const f of intResult.modified.slice(0, 5)) console.log(c.yellow(`    修改: ${f}`));
                  for (const f of intResult.removed.slice(0, 5)) console.log(c.red(`    删除: ${f}`));
                }
                if (intResult.added.length > 0) {
                  printInfo(`新增文件: ${intResult.added.length} (正常更新)`);
                }

                // 2. Threat scan
                printInfo('威胁扫描...');
                const threats = secGuard.scanForThreats();
                if (threats.clean) {
                  printSuccess('威胁扫描: 未发现异常');
                } else {
                  printError(`发现 ${threats.threats.length} 个威胁:`);
                  for (const t of threats.threats) {
                    console.log(c.red(`    [${t.severity}] ${t.type}: ${t.detail}`));
                  }
                }

                // 3. System health
                const health = resGuard.systemHealthCheck();
                if (health.healthy) {
                  printSuccess('系统资源: 正常');
                } else {
                  for (const w of health.warnings) printWarn(w);
                }

                // 4. Security stats
                const stats = secGuard.getSecurityStats();
                if (stats.totalEvents > 0) {
                  printInfo(`安全事件: ${stats.totalEvents} 总计, ${stats.last24h} 近24小时`);
                }
                console.log('');
              } catch (e) { printError(`安全检查失败: ${e.message}`); }
            } else if (selected.flag === 'hardware') {
              // Hardware info and local model recommendations
              try {
                const hw = require('../services/hardwareProfileService');
                const { lines, profile } = hw.getHardwareSummary();

                console.log('');
                printInfo('硬件配置:');
                for (const line of lines) console.log(c.dim(`    ${line}`));
                console.log('');

                if (profile.localModels.length > 0) {
                  printInfo('推荐本地模型:');
                  for (const m of profile.localModels) {
                    const rec = m.recommended ? c.green(' ★ 推荐') : '';
                    if (m.recommendation === 'api-only') {
                      console.log(c.yellow(`    ${m.reason}`));
                    } else {
                      console.log(c.dim(`    ${m.name} (${m.sizeGB}GB)`) + rec);
                      console.log(c.dim(`      ${m.reason}`));
                    }
                  }
                }

                console.log('');
                printInfo('资源限制:');
                const lim = profile.limits;
                console.log(c.dim(`    Node.js 堆: ${lim.nodeHeapMB}MB`));
                console.log(c.dim(`    并发数: ${lim.maxConcurrency}`));
                console.log(c.dim(`    多智能体: ${lim.enableMultiAgent ? '启用' : '禁用'}`));
                console.log(c.dim(`    本地模型: ${lim.enableLocalModel ? '启用' : '禁用'}`));
                console.log('');
              } catch (e) { printError(`硬件检测失败: ${e.message}`); }
            } else if (selected.flag === 'review') {
              // AI code review on current git changes
              try {
                const { execSync } = require('child_process');
                let diff = '';
                try {
                  diff = execSync('git diff --stat && echo "---DIFF---" && git diff', {
                    encoding: 'utf-8', timeout: 15000, maxBuffer: 2 * 1024 * 1024,
                  });
                } catch {
                  // Try staged changes
                  try {
                    diff = execSync('git diff --cached --stat && echo "---DIFF---" && git diff --cached', {
                      encoding: 'utf-8', timeout: 15000, maxBuffer: 2 * 1024 * 1024,
                    });
                  } catch { diff = ''; }
                }
                if (!diff.trim()) {
                  printInfo('没有检测到 Git 改动，无需审查');
                } else {
                  // Truncate if too large
                  const maxLen = 12000;
                  const truncated = diff.length > maxLen
                    ? diff.slice(0, maxLen) + `\n... (truncated, ${diff.length} chars total)`
                    : diff;
                  printInfo('正在审查代码改动...');
                  _busy = true;
                  const reviewPrompt = `你是一位专业的代码审查员。请审查以下 Git diff，给出：
1. 改动概述
2. 代码质量和风格分析
3. 具体改进建议
4. 潜在的问题和风险（安全、性能、逻辑错误）

请用中文回复，保持简洁专业。

\`\`\`diff
${truncated}
\`\`\``;
                  const result = await ai().chat(reviewPrompt, {
                    onChunk: (chunk) => {
                      if (chunk && chunk.text) process.stdout.write(chunk.text);
                    },
                  });
                  if (result && result.reply && !result.streamed) {
                    console.log(result.reply);
                  }
                  console.log('');
                  _busy = false;
                }
              } catch (e) { printError(`代码审查失败: ${e.message}`); _busy = false; }
            }
          } else if (selected.route) {
            // Parse and execute the route command
            const cmdParsed = parseInput(selected.route);
            if (cmdParsed) {
              const result = await route(cmdParsed);
              if (result === 'exit') {
                ai().saveConversation();
                saveHistory(history);
                setTerminalTitle('');
                console.log('');
                console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
                console.log(c.dim('  对话已保存'));
                console.log('');
                process.exit(0);
              }
            }
          }
        }
      } catch { /* menu cancelled or error */ }
      rl.prompt();
      return;
    }

    // /btw — queue hint without interrupting current AI work
    if (trimmed.startsWith('/btw ')) {
      const hint = trimmed.slice(5).trim();
      if (hint) {
        _btwQueue.push(hint);
        console.log(c.dim(`  📌 提示已排队 (当前队列: ${_btwQueue.length})`));
      }
      rl.prompt();
      return;
    }

    // /max, /high, /medium, /low — effort level switching
    const effortMatch = trimmed.match(/^\/(max|high|medium|low)$/);
    if (effortMatch) {
      const level = effortMatch[1];
      if (ai().setEffort(level)) {
        const presets = ai().getEffortPresets();
        const p = presets[level];
        printSuccess(`模型精度已切换: ${level} (${p.label}) — temp=${p.temperature}, maxTokens=${p.maxTokens}`);
      } else {
        printError('无效的精度级别');
      }
      rl.prompt();
      return;
    }

    // Image analysis — file path or clipboard paste
    const imageMatch = trimmed.match(/^(?:image|图片|img)\s+(.+?\.(png|jpg|jpeg|gif|webp))\s*(.*)/i);
    const pasteMatch = /^(?:paste|粘贴|clipboard|剪贴板)(?:\s+(.*))?$/i.exec(trimmed);

    if (imageMatch || pasteMatch) {
      try {
        const imageService = require('../services/imageService');
        const renderer = require('./aiRenderer');
        let image, prompt;

        if (imageMatch) {
          // File path mode
          const filePath = imageMatch[1];
          prompt = imageMatch[3] || '请分析这张图片';
          renderer.printToolCallStart('Read', { path: filePath });
          const readStart = Date.now();
          image = imageService.readImageFromFile(filePath);
          renderer.printToolCallResult('Read', { path: filePath }, 'success',
            `${image.format.toUpperCase()}, ${(image.sizeBytes / 1024).toFixed(0)}KB`,
            Date.now() - readStart
          );
        } else {
          // Clipboard paste mode
          prompt = pasteMatch[1] || '请分析这张图片';
          renderer.printToolCallStart('Clipboard', '读取剪贴板图片');
          const readStart = Date.now();
          image = imageService.readImageFromClipboard();
          renderer.printToolCallResult('Clipboard', '剪贴板', 'success',
            `${image.format.toUpperCase()}, ${(image.sizeBytes / 1024).toFixed(0)}KB`,
            Date.now() - readStart
          );
        }

        // Show preview
        imageService.printImagePreview(image);

        // Send to AI with vision
        _busy = true;
        const tracker = new renderer.ProcessTracker();
        tracker.start('请求 AI', ai().getActiveProvider() || 'Vision AI');

        const aiResult = await ai().chat(prompt, {
          images: [{ base64: image.base64, mimeType: image.mimeType }],
        });

        if (tracker.isActive) tracker.complete();

        if (aiResult.reply) {
          renderer.printStepLine('success', 'AI 图片分析', aiResult.provider || 'vision');
          console.log(c.dim('  ┌──'));
          const rendered = renderer.renderAiResponse(aiResult.reply);
          rendered.split('\n').forEach(l => console.log(c.dim('  │ ') + l));
          console.log(c.dim('  └──'));
        } else {
          printInfo('AI 未返回分析结果 — 当前 AI 服务可能不支持图片分析');
        }
        console.log('');
      } catch (imgErr) {
        printError(`图片处理失败: ${imgErr.message}`);
      } finally {
        _busy = false;
      }
      rl.prompt();
      return;
    }

    // Prevent concurrent command execution
    if (_busy) {
      // Queue input without interrupting current work (like Claude Code's /btw)
      _btwQueue.push(trimmed);
      console.log(c.dim(`  ${DOT_PENDING} 已排队: "${trimmed.slice(0, 40)}${trimmed.length > 40 ? '...' : ''}" (队列: ${_btwQueue.length})`));
      console.log(c.dim(`    ${TREE_LAST} AI 完成当前工作后自动处理，Ctrl+C 可中断`));
      return;
    }
    _busy = true;

    // Save to history
    history.push(trimmed);

    // Parse and route the command
    const parsed = parseInput(trimmed);
    if (!parsed) {
      _busy = false;
      rl.prompt();
      return;
    }

    try {
      const result = await route(parsed);

      if (result === 'exit') {
        ai().saveConversation();
        saveHistory(history);
        setTerminalTitle(''); // restore terminal title
        console.log('');
        console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
        console.log(c.dim('  对话已保存，下次可用 history resume 恢复上下文'));
        console.log('');
        process.exit(0);
      }

      if (result === 'menu') {
        let menuResult;
        do {
          menuResult = await menu().runMenuLoop();
          await executeMenuResult(menuResult);
        } while (menuResult !== null);
        rl.prompt();
        return;
      }

      if (result === 'ai-status') {
        await ai().handleAiStatus();
        rl.prompt();
        return;
      }

      if (result === 'ai-config') {
        await ai().handleAiConfig();
        rl.prompt();
        return;
      }

      if (result === 'ai-on') {
        _aiMode = true;
        userProfile().setAiModePreference(true);
        printSuccess('AI 对话模式已开启 — 输入自然语言即可与 AI 交流');
        printInfo('输入 ai off 关闭 AI 模式');
        rl.prompt();
        return;
      }

      if (result === 'ai-off') {
        _aiMode = false;
        userProfile().setAiModePreference(false);
        printSuccess('AI 对话模式已关闭 — 仅响应内置命令');
        printInfo('输入 ai on 重新开启');
        rl.prompt();
        return;
      }

      if (result === true) {
        // Command was handled — track it
        if (parsed && parsed.command) userProfile().trackCommand(parsed.command);

        // Record command sequence for pattern learning
        if (parsed && parsed.command) {
          _recentCommands.push(trimmed);
          if (_recentCommands.length > PATTERN_WINDOW) _recentCommands.shift();

          // Record workflow step for habit optimization
          try {
            const { recordWorkflowStep, recordInteraction: recordHabit } = require('../services/usageHabitService');
            recordHabit(trimmed);
            if (_recentCommands.length >= 2) {
              recordWorkflowStep(_recentCommands.slice(-2));
            }
          } catch { /* best effort */ }

          // Check for patterns when we have enough commands
          if (_recentCommands.length >= 2) {
            try {
              const { recordCommandSequence } = require('../services/skillLearningService');
              const suggestion = recordCommandSequence(_recentCommands.slice(-3));
              if (suggestion && suggestion.suggest) {
                console.log('');
                console.log(c.yellow(`  ⚡ 检测到重复操作模式 (${suggestion.count} 次):`));
                console.log(c.dim(`     ${suggestion.sequence.join(' → ')}`));
                console.log(c.dim(`     输入 skill learn workflow "${suggestion.sequence.join(' → ')}" 自动化`));
                console.log('');
              }
            } catch { /* pattern learning is best-effort */ }
          }
        }

        rl.prompt();
        return;
      }

      // result.aiForward → a command generated a prompt for AI
      const aiInput = (result && result.aiForward) ? result.aiForward : trimmed;

      // Check if AI mode is enabled
      if (!_aiMode && !result?.aiForward) {
        // AI mode disabled and no explicit aiForward — show hint
        printError(`未知命令: ${trimmed}`);
        printInfo('输入 help 查看可用命令，或输入 ai on 开启 AI 对话模式');
        rl.prompt();
        return;
      }

      // result === false or aiForward → send to AI
      let streamState = { phase: 'idle', thinkingStarted: false, textStarted: false };

      // Merge any queued /btw hints into the input
      let finalAiInput = aiInput;
      if (_btwQueue.length > 0) {
        const hints = _btwQueue.splice(0).join('\n');
        finalAiInput = `${aiInput}\n\n[附加提示]\n${hints}`;
      }

      // Check for multi-agent trigger
      const agentRunner = require('../services/cliAgentRunner');
      if (agentRunner.shouldUseMultiAgent(finalAiInput)) {
        const agentDisplay = require('./agentRenderer');
        const renderer = require('./aiRenderer');

        // Decompose task into sub-tasks
        const subtasks = agentRunner.decomposeTask(finalAiInput);
        let renderedLines = 0;

        // Show initial agent display
        renderedLines = agentDisplay.renderAgentDisplay(subtasks.map(st => ({
          name: st.name, status: 'pending', toolCalls: 0, tokens: 0, elapsed: 0, detail: '',
        })));

        // Run agents with progress updates
        const agentResults = await agentRunner.runAgents(subtasks, {
          ai: ai(),
          onProgress: (states) => {
            renderedLines = agentDisplay.rerenderAgentDisplay(states, renderedLines);
          },
        });

        // Show final state
        agentDisplay.rerenderAgentDisplay(agentResults, renderedLines, true);
        agentDisplay.renderAgentSummary(agentResults);

        // Synthesize results
        renderer.printToolCallStart('Synthesize', '综合分析');
        const synthStart = Date.now();
        const synthesized = await agentRunner.synthesizeResults(agentResults, finalAiInput, ai());
        renderer.printToolCallResult('Synthesize', '综合分析', 'success', '合成完成', Date.now() - synthStart);

        // Display synthesized result
        agentDisplay.renderSynthesisResult(synthesized, agentResults);
        console.log('');
        _busy = false;
        rl.prompt();
        return;
      }

      // Check for plan mode trigger
      const planService = require('../services/planModeService');
      let needsPlan = false;
      try {
        const { preprocess } = require('../services/inputPreprocessor');
        const pp = preprocess(aiInput);
        needsPlan = pp.needsPlan || _planMode;
      } catch { /* best effort */ }

      if (needsPlan || _planMode) {
        const renderer = require('./aiRenderer');
        _planMode = false; // Reset after use

        // Step 1: Generate plan
        renderer.printStepLine('active', '计划模式', '生成执行计划...');
        const { plan, rawResponse, provider, elapsed } = await planService.enterPlanMode(finalAiInput, ai());

        if (plan && plan.steps.length > 0) {
          if (process.stdout.isTTY) {
            process.stdout.write('\x1b[1A\r\x1b[K');
          }
          renderer.printStepLine('success', '计划模式', `生成 ${plan.steps.length} 步执行计划`);

          // Step 2: Present for approval
          const approval = await planService.presentForApproval(plan, renderer, rl);

          if (approval.approved) {
            // Step 3: Execute step by step
            console.log('');
            renderer.printStepLine('active', '执行计划', `${plan.steps.filter(s => s.status !== 'skipped').length} 步骤`);

            const results = await planService.executePlanSteps(plan, {
              ai: ai(),
              renderer,
              rl,
              route,
              parseInput,
            });

            if (process.stdout.isTTY) {
              process.stdout.write('\x1b[1A\r\x1b[K');
            }
            renderer.printStepLine('success', '计划执行完成', `${results.filter(r => r.step.status === 'completed').length}/${results.length} 成功`);

            // Show final results
            for (const { step, result } of results) {
              if (result.reply) {
                console.log(c.dim(`  ┌── 步骤 ${step.id}: ${step.description}`));
                const rendered = renderer.renderAiResponse(result.reply);
                rendered.split('\n').forEach(l => console.log(c.dim('  │ ') + l));
                console.log(c.dim('  └──'));
              }
            }
            renderer.renderAgentDone({
              toolCalls: results.length,
              elapsedMs: elapsed,
            });
          } else {
            printInfo('计划已取消');
          }
        } else {
          // Plan generation failed — fall through to normal AI
          if (rawResponse) {
            const renderer2 = require('./aiRenderer');
            console.log(c.dim('  ┌──'));
            const rendered = renderer2.renderAiResponse(rawResponse);
            rendered.split('\n').forEach(l => console.log(c.dim('  │ ') + l));
            console.log(c.dim('  └──'));
          }
        }
        planService.reset();
        console.log('');
        _busy = false;
        rl.prompt();
        return;
      }

      // Load AI renderer for rich output
      const renderer = require('./aiRenderer');
      const spinner = new renderer.DynamicSpinner();
      const tracker = new renderer.ProcessTracker();

      // Step 0: Show intent understanding (brief local analysis)
      try {
        const intents = [];
        const lower = aiInput.toLowerCase();
        if (/回测|backtest/.test(lower))       intents.push('回测分析');
        if (/行情|quote|价格|涨跌/.test(lower))   intents.push('行情查询');
        if (/数据|data|下载|fetch/.test(lower))   intents.push('数据获取');
        if (/策略|strategy|信号/.test(lower))     intents.push('策略分析');
        if (/分析|analyze|评估|诊断/.test(lower))  intents.push('深度分析');
        if (/对比|比较|vs/.test(lower))           intents.push('对比分析');
        if (/推荐|建议|suggest/.test(lower))      intents.push('推荐建议');
        if (/解释|什么是|如何|怎么/.test(lower))   intents.push('知识问答');

        if (intents.length > 0) {
          renderer.printStepLine('active', '理解', aiInput.slice(0, 30).replace(/\n/g, ' '));
          renderer.printStepDetail(`意图: ${intents.join(' + ')}`);
          // Overwrite the active line with success
          if (process.stdout.isTTY) {
            process.stdout.write('\x1b[2A\r\x1b[K');
          }
          renderer.printStepLine('success', '理解', aiInput.slice(0, 30).replace(/\n/g, ' '));
          renderer.printStepDetail(`意图: ${intents.join(' + ')}`);
        }
      } catch { /* best effort */ }

      // Step 1: Preprocessing — detect complexity for display
      let complexTask = false;
      try {
        const { preprocess } = require('../services/inputPreprocessor');
        const pp = preprocess(aiInput);
        complexTask = pp.needsPlan;
      } catch { /* best effort */ }

      if (complexTask) {
        tracker.start('分析', aiInput.slice(0, 40), '复杂任务检测');
        tracker.complete('AI 将先制定执行计划');
      }

      // Step 2: AI request
      tracker.start('请求 AI', ai().getActiveProvider() || 'AI 服务');

      const onChunk = (chunk) => {
        if (chunk.type === 'thinking') {
          // Complete the request step, start thinking step
          if (tracker.isActive) tracker.complete();
          spinner.stop();
          if (!streamState.thinkingStarted) {
            streamState.thinkingStarted = true;
            streamState.phase = 'thinking';
            tracker.start('思考', '', '深度分析中...');
            console.log('');
            console.log(c.yellow(`  ${ICON_BOT} 思考过程:`));
            console.log(c.dim('  ┌──'));
          }
          const thinkLines = chunk.text.split('\n');
          thinkLines.forEach(l => process.stdout.write(c.dim('  │ ') + c.yellow(l) + '\n'));
        } else if (chunk.type === 'text') {
          if (streamState.phase === 'thinking') {
            console.log(c.dim('  └──'));
            console.log('');
            if (tracker.isActive) tracker.complete('思考完成');
            streamState.phase = 'text';
            spinner.setPhase('generating', '生成回复');
          }
          if (!streamState.textStarted) {
            streamState.textStarted = true;
            if (tracker.isActive) tracker.complete();
            spinner.stop();
            tracker.start('生成', '', '输出回复...');
          }
        } else if (chunk.type === 'cost') {
          streamState.cost = chunk.cost;
        }
      };

      // Start dynamic spinner
      spinner.start('request');

      let aiResult;
      try {
        const { startWatchdog, WATCHDOG_TIMEOUT_MS } = require('../services/resourceGuard');
        const wd = startWatchdog('ai-chat', WATCHDOG_TIMEOUT_MS, () => {
          spinner.stop();
          console.log(c.red('\n  ⚠ AI 请求超时，已自动取消'));
        });
        aiResult = await ai().chat(finalAiInput, { onChunk });
        wd.done();
      } catch (wdErr) {
        spinner.stop();
        if (tracker.isActive) tracker.complete();
        throw wdErr;
      }

      spinner.stop();
      if (tracker.isActive) tracker.complete();

      // Close thinking block if it was still open
      if (streamState.phase === 'thinking') {
        console.log(c.dim('  └──'));
        console.log('');
      }

      if (aiResult.reply) {
        // Update terminal title with conversation topic
        updateTitleFromConversation(aiInput);

        // Build meta info line (Claude Code style)
        const elapsedSec = aiResult.elapsed ? `${(aiResult.elapsed / 1000).toFixed(1)}s` : '';
        const tokenCount = aiResult.tokenUsage
          ? `↑ ${aiResult.tokenUsage.totalTokens?.toLocaleString() || '?'} tokens` : '';
        const thinkTime = streamState.thinkingStarted ? 'thought' : '';
        const metaParts = [elapsedSec, tokenCount, thinkTime].filter(Boolean);
        const metaTag = metaParts.length > 0 ? c.dim(` (${metaParts.join(' · ')})`) : '';

        // Show response header with green dot (completed)
        renderer.printStepLine('success', 'AI 回复', aiResult.provider || 'local', metaParts.join(' · '));

        // Render with diff highlighting and markdown-lite
        console.log(c.dim('  ┌──'));
        const rendered = renderer.renderAiResponse(aiResult.reply);
        const lines = rendered.split('\n');
        lines.forEach(l => console.log(c.dim('  │ ') + l));
        console.log(c.dim('  └──'));

        // Compacting notice when conversation history is long
        try {
          const historyLen = aiResult.tokenUsage?.totalTokens || 0;
          if (historyLen > 3000) {
            renderer.printCompactingNotice({
              elapsed: elapsedSec,
              tokens: aiResult.tokenUsage?.totalTokens?.toLocaleString() || '?',
              thought: streamState.thinkingStarted ? `${((aiResult.elapsed || 0) * 0.3 / 1000).toFixed(0)}s` : undefined,
              tip: '使用 /btw 在 AI 工作时插入不打断的提示',
            });
          }
        } catch { /* best effort */ }

        // Extract and display task plan if AI response contains numbered steps
        try {
          const planPattern = /执行计划|分析步骤|操作步骤|回测计划|分步/;
          if (planPattern.test(aiResult.reply) || needsPlan) {
            const planTracker = new renderer.TaskPlanTracker();
            if (planTracker.extractFromResponse(aiResult.reply)) {
              planTracker.render();
            }
          }
        } catch { /* best effort */ }

        // Show knowledge tip (contextual, throttled)
        try {
          const { getContextualTip } = require('../services/knowledgeTeachingService');
          const tip = getContextualTip(aiInput, aiResult.reply);
          if (tip) {
            console.log(c.yellow(`  💡 量化小知识: `) + c.white(tip.content.slice(0, 120) + (tip.content.length > 120 ? '...' : '')));
            console.log(c.dim(`     (${tip.category} · ${tip.level})`));
          }
        } catch { /* knowledge tips are best-effort */ }

        // Detect inline options in AI response (numbered lists ending with ?)
        // Pattern: AI asks a question with numbered options like "1. xxx\n2. xxx\n请选择"
        try {
          const optionPattern = /(?:^|\n)\s*(\d)\.\s+(.+)/g;
          const questionPattern = /请选择|你想|哪个|选哪|怎么做|如何选/;
          const hasQuestion = questionPattern.test(aiResult.reply);

          if (hasQuestion) {
            const matches = [...aiResult.reply.matchAll(optionPattern)];
            if (matches.length >= 2 && matches.length <= 6) {
              const options = matches.map(m => ({ label: m[2].trim() }));
              const selection = await renderer.askInlineQuestion(
                'AI 需要你的选择:',
                options,
                { rl }
              );
              if (selection) {
                // Send selection back to AI as follow-up
                _btwQueue.push(`我选择: ${Array.isArray(selection) ? selection.join(', ') : selection}`);
                console.log(c.green(`  ✓ 已选择: ${Array.isArray(selection) ? selection.join(', ') : selection}`));
                console.log(c.dim('  下次输入将自动附带你的选择'));
              }
            }
          }
        } catch { /* interactive selection is best-effort */ }

        console.log('');
      } else {
        // Empty reply — inform user
        printInfo('AI 未返回有效回复 — 请重试或检查连接');
        console.log('');
      }

      // Execute any embedded commands with Claude Code-style tool call display
      if (aiResult.commands && aiResult.commands.length > 0) {
        console.log('');
        const toolCallStats = { toolCalls: 0, startTime: Date.now() };
        for (const cmd of aiResult.commands) {
          const cmdParts = cmd.split(/\s+/);
          const cmdLabel = cmdParts[0] || cmd;
          const cmdTarget = cmdParts.slice(1).join(' ') || '';
          toolCallStats.toolCalls++;

          // Show Claude Code-style tool call start
          renderer.printToolCallStart(cmdLabel, cmdTarget || cmd);
          const cmdStart = Date.now();

          try {
            const cmdParsed = parseInput(cmd);
            if (cmdParsed) {
              // Capture output by temporarily redirecting console.log
              const origLog = console.log;
              const output = [];
              console.log = (...args) => {
                const line = args.map(a => typeof a === 'string' ? a : String(a)).join(' ');
                output.push(line);
              };
              try {
                await route(cmdParsed);
              } finally {
                console.log = origLog;
              }

              const cmdElapsed = Date.now() - cmdStart;

              // Show condensed result via tool call result display
              const condensed = output.filter(l => l.trim()).slice(0, 5);
              const cleanLines = condensed.map(l => l.replace(/\x1b\[[0-9;]*m/g, '').trim().slice(0, 80));
              const detail = cleanLines.length > 0 ? cleanLines[0] : `${cmdLabel} completed`;
              const moreLines = output.filter(l => l.trim()).length;

              renderer.printToolCallResult(
                cmdLabel,
                cmdTarget || cmd,
                'success',
                moreLines > 1 ? `${detail} (+${moreLines - 1} more lines)` : detail,
                cmdElapsed
              );
            } else {
              renderer.printToolCallResult(cmdLabel, cmd, 'error', 'Cannot parse command', 0);
            }
          } catch (cmdErr) {
            renderer.printToolCallResult(
              cmdLabel, cmd, 'error',
              cmdErr.message || 'Execution failed',
              Date.now() - cmdStart
            );
          }
        }
        // Show completion summary
        renderer.renderAgentDone({
          toolCalls: toolCallStats.toolCalls,
          elapsedMs: Date.now() - toolCallStats.startTime,
        });
      }

    } catch (err) {
      try { printError(err?.message || String(err) || '执行出错'); } catch { /* ignore */ }
    } finally {
      _busy = false;
      try { rl.prompt(); } catch { /* readline may be destroyed */ }
    }
  });

  // Handle Ctrl+C — require double-press within 2s to exit (prevent accidental exit)
  rl.on('SIGINT', () => {
    if (_busy) {
      // If a command is running, just cancel it
      _busy = false;
      console.log(c.yellow('\n  ⚠ 操作已中断'));
      rl.prompt();
      return;
    }

    _ctrlCCount++;
    if (_ctrlCCount >= 2) {
      // Double Ctrl+C confirmed — exit
      ai().saveConversation();
      saveHistory(history);
      setTerminalTitle(''); // restore terminal title
      console.log('');
      console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
      console.log(c.dim('  对话已保存'));
      console.log('');
      process.exit(0);
    } else {
      console.log(c.yellow('\n  ⚠ 再按一次 Ctrl+C 或 ESC 退出 (对话会自动保存)，或输入 history resume 下次恢复'));
      if (_ctrlCTimer) clearTimeout(_ctrlCTimer);
      _ctrlCTimer = setTimeout(() => { _ctrlCCount = 0; }, 2000);
      rl.prompt();
    }
  });

  // Handle Ctrl+D (EOF) — save and exit gracefully
  rl.on('close', () => {
    // Cancel all startup timers
    for (const t of _startupTimers) clearTimeout(t);
    if (_ctrlCTimer) clearTimeout(_ctrlCTimer);
    // Cancel all resource guard timers before exit
    try { require('../services/resourceGuard').cancelAll(); } catch { /* ignore */ }
    ai().saveConversation();
    saveHistory(history);
    setTerminalTitle(''); // restore terminal title
    if (!rl._exiting) {
      console.log('');
      console.log(c.cyan(`  ${MASCOT_MINI} `) + c.dim(getRandomFarewell()));
      console.log(c.dim('  对话已保存，下次可用 history resume 恢复'));
      console.log('');
    }
    process.exit(0);
  });
}

module.exports = { startRepl };
