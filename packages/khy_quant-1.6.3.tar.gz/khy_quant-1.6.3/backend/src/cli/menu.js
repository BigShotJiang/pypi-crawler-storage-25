/**
 * Interactive menu system using inq().
 * Lazy-loaded for fast cold start.
 */
let _inquirer;
const inq = () => (_inquirer ??= require('inquirer'));
const { printInfo } = require('./formatters');

async function showMainMenu() {
  const { action } = await inq().prompt([{
    type: 'list',
    name: 'action',
    message: '请选择操作:',
    choices: [
      { name: '📈 实时行情查询', value: 'quote' },
      { name: '📊 策略回测', value: 'backtest' },
      { name: '💾 数据管理', value: 'data' },
      { name: '⚙️  系统管理', value: 'system' },
      { name: '🤖 AI 助手设置', value: 'ai' },
      { name: '🌐 AI 网关 / 中转', value: 'gateway' },
      { name: '🔧 环境诊断', value: 'doctor' },
      { name: '📚 教程文档', value: 'docs' },
      new inq().Separator(),
      { name: '↩️  返回命令行', value: 'back' },
    ],
  }]);
  return action;
}

async function showQuoteMenu() {
  const userProfile = require('../services/userProfile');
  const suggested = userProfile.getSuggestedSymbols(1);
  const defaultSymbol = suggested[0] || 'sh600519';

  const { symbol } = await inq().prompt([{
    type: 'input',
    name: 'symbol',
    message: '输入股票/期货代码:',
    default: defaultSymbol,
    validate: v => v.trim().length > 0 || '请输入代码',
  }]);
  return { action: 'quote', symbol };
}

async function showBacktestMenu() {
  const { Strategy } = require('../models');
  const userProfile = require('../services/userProfile');
  let strategies = [];
  try {
    strategies = await Strategy.findAll({ order: [['id', 'ASC']], raw: true });
  } catch { /* DB not ready */ }

  const strategyChoices = strategies.length > 0
    ? strategies.map(s => ({ name: `[${s.id}] ${s.name}`, value: String(s.id) }))
    : [{ name: '(无可用策略)', value: null }];

  const suggested = userProfile.getSuggestedSymbols(1);
  const defaultSymbol = suggested[0] || 'sh000300';
  const defaultCapital = String(userProfile.getDefaultCapital());

  const answers = await inq().prompt([
    {
      type: 'input',
      name: 'symbol',
      message: '回测品种代码:',
      default: defaultSymbol,
    },
    {
      type: 'list',
      name: 'strategy',
      message: '选择策略:',
      choices: strategyChoices,
    },
    {
      type: 'input',
      name: 'start',
      message: '开始日期:',
      default: '2024-01-01',
    },
    {
      type: 'input',
      name: 'end',
      message: '结束日期:',
      default: new Date().toISOString().slice(0, 10),
    },
    {
      type: 'input',
      name: 'capital',
      message: '初始资金:',
      default: defaultCapital,
    },
  ]);

  return { action: 'backtest-run', ...answers };
}

async function showDataMenu() {
  const { action } = await inq().prompt([{
    type: 'list',
    name: 'action',
    message: '数据管理:',
    choices: [
      { name: '下载K线数据', value: 'data-fetch' },
      { name: '查看品种列表', value: 'data-list' },
      { name: '清理缓存', value: 'cache-clear' },
      new inq().Separator(),
      { name: '↩️  返回主菜单', value: 'back' },
    ],
  }]);

  if (action === 'data-fetch') {
    const { symbol } = await inq().prompt([{
      type: 'input',
      name: 'symbol',
      message: '输入品种代码:',
      default: 'sh000001',
    }]);
    return { action, symbol };
  }

  return { action };
}

async function showSystemMenu() {
  const { action } = await inq().prompt([{
    type: 'list',
    name: 'action',
    message: '系统管理:',
    choices: [
      { name: '启动后端服务', value: 'server-start' },
      { name: '查看服务状态', value: 'server-status' },
      { name: '初始化数据库', value: 'db-init' },
      { name: '填充示例数据', value: 'db-seed' },
      { name: '查看数据库状态', value: 'db-status' },
      new inq().Separator(),
      { name: '↩️  返回主菜单', value: 'back' },
    ],
  }]);
  return { action };
}

async function showAiMenu() {
  const { action } = await inq().prompt([{
    type: 'list',
    name: 'action',
    message: 'AI 助手:',
    choices: [
      { name: '查看AI服务状态', value: 'ai-status' },
      { name: '配置API密钥', value: 'ai-config' },
      new inq().Separator(),
      { name: '↩️  返回主菜单', value: 'back' },
    ],
  }]);
  return { action };
}

async function showGatewayMenu() {
  const { action } = await inq().prompt([{
    type: 'list',
    name: 'action',
    message: 'AI 网关:',
    choices: [
      { name: '查看网关状态', value: 'gateway-status' },
      { name: '选择 AI 模型', value: 'gateway-select-model' },
      { name: '配置网关参数', value: 'gateway-config' },
      { name: '启动 Web 中转服务', value: 'gateway-relay' },
      new inq().Separator(),
      { name: '↩️  返回主菜单', value: 'back' },
    ],
  }]);
  return { action };
}

/**
 * Run the full menu loop. Returns the action result for the REPL to execute.
 */
async function runMenuLoop() {
  while (true) {
    const mainAction = await showMainMenu();

    if (mainAction === 'back') return null;

    let result;
    switch (mainAction) {
      case 'quote':
        result = await showQuoteMenu();
        return result;

      case 'backtest':
        result = await showBacktestMenu();
        if (!result.strategy) {
          printInfo('请先运行 db seed 创建示例策略');
          continue;
        }
        return result;

      case 'data': {
        result = await showDataMenu();
        if (result.action === 'back') continue;
        return result;
      }

      case 'system': {
        result = await showSystemMenu();
        if (result.action === 'back') continue;
        return result;
      }

      case 'ai': {
        result = await showAiMenu();
        if (result.action === 'back') continue;
        return result;
      }

      case 'gateway': {
        result = await showGatewayMenu();
        if (result.action === 'back') continue;
        return result;
      }

      case 'doctor':
        return { action: 'doctor' };

      case 'docs': {
        result = await showDocsMenu();
        if (result.action === 'back') continue;
        return result;
      }
    }
  }
}

async function showDocsMenu() {
  const { action } = await inq().prompt([{
    type: 'list',
    name: 'action',
    message: '📚 教程文档:',
    choices: [
      { name: '🚀 快速开始 (5分钟上手)', value: 'docs-quickstart' },
      { name: '📖 Claude Code 使用教程', value: 'docs-claude' },
      { name: '🤖 AI 网关使用指南', value: 'docs-gateway' },
      { name: '📊 量化策略入门', value: 'docs-strategy' },
      { name: '🔧 常见问题 FAQ', value: 'docs-faq' },
      new inq().Separator(),
      { name: '↩️  返回主菜单', value: 'back' },
    ],
  }]);
  return { action };
}

module.exports = { runMenuLoop };
