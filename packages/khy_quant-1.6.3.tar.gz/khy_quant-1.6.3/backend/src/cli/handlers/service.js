/**
 * Service management CLI handlers: server start/status, db init/seed/status.
 */
const { execFileSync } = require('child_process');
const path = require('path');
const http = require('http');
const chalk = require('chalk');
const { bootstrap } = require('../bootstrap');
const { printSuccess, printError, printInfo, printTable, withSpinner } = require('../formatters');

const BACKEND_DIR = path.resolve(__dirname, '../../../');

async function handleServerStart(options = {}) {
  if (options.port) process.env.PORT = String(options.port);
  printInfo('启动后端服务...');
  // Require server.js which auto-starts the Express server
  require(path.join(BACKEND_DIR, 'server.js'));
}

async function handleServerStatus() {
  const port = process.env.PORT || 8080;
  const url = `http://localhost:${port}/health`;

  return new Promise((resolve) => {
    const req = http.get(url, { timeout: 3000 }, (res) => {
      let body = '';
      res.on('data', chunk => { body += chunk; });
      res.on('end', () => {
        try {
          const data = JSON.parse(body);
          printSuccess(`服务运行中 (端口 ${port})`);
          printTable(
            ['项目', '状态'],
            [
              ['状态', chalk.green(data.status || 'ok')],
              ['端口', String(port)],
              ['数据库', data.database || data.db || '-'],
              ['运行时间', data.uptime ? Math.floor(data.uptime) + 's' : '-'],
            ]
          );
        } catch {
          printSuccess(`服务运行中 (端口 ${port})`);
        }
        resolve();
      });
    });

    req.on('error', () => {
      printError(`服务未运行 (端口 ${port})`);
      printInfo('运行 server start 启动服务');
      resolve();
    });

    req.on('timeout', () => {
      req.destroy();
      printError(`服务响应超时 (端口 ${port})`);
      resolve();
    });
  });
}

async function handleDbInit() {
  await withSpinner('初始化数据库...', () => bootstrap({ syncSchema: true }));
  const mode = process.env.DB_MODE || 'sqlite';
  printSuccess(`数据库已初始化 (${mode})`);
}

async function handleDbSeed() {
  await bootstrap({ syncSchema: true, silent: true });

  printInfo('填充示例数据...');
  try {
    execFileSync('node', ['scripts/seed.js'], {
      cwd: BACKEND_DIR,
      stdio: 'inherit',
      timeout: 30000,
    });
    printSuccess('示例数据填充完成');
  } catch (err) {
    printError('数据填充失败: ' + (err.message || 'unknown error'));
  }
}

async function handleDbStatus() {
  await bootstrap({ silent: true });

  const { sequelize, User, Strategy, Instrument, Backtest, Trade } = require('../../models');
  const mode = process.env.DB_MODE || 'unknown';

  printSuccess(`数据库连接正常 (${mode})`);

  const counts = await Promise.all([
    User.count().catch(() => 0),
    Strategy.count().catch(() => 0),
    Instrument.count().catch(() => 0),
    Backtest.count().catch(() => 0),
    Trade.count().catch(() => 0),
  ]);

  printTable(
    ['表', '记录数'],
    [
      ['用户 (User)', String(counts[0])],
      ['策略 (Strategy)', String(counts[1])],
      ['品种 (Instrument)', String(counts[2])],
      ['回测 (Backtest)', String(counts[3])],
      ['交易 (Trade)', String(counts[4])],
    ]
  );

  if (mode === 'sqlite') {
    const { getSQLitePath } = require('../../config/database');
    printInfo(`SQLite 路径: ${getSQLitePath()}`);
  }
}

module.exports = {
  handleServerStart,
  handleServerStatus,
  handleDbInit,
  handleDbSeed,
  handleDbStatus,
};
