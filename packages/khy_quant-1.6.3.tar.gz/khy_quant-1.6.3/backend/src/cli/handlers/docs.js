/**
 * CLI Handlers for built-in documentation / tutorials.
 * Renders markdown docs directly in the terminal.
 */
const chalk = require('chalk');
const fs = require('fs');
const path = require('path');
const { printInfo, printSuccess } = require('../formatters');

const DOCS_DIR = path.resolve(__dirname, '../../../docs');
const BUNDLED_DOCS_DIR = path.resolve(__dirname, '../../bundled/docs');

function getDocsDir() {
  if (fs.existsSync(DOCS_DIR)) return DOCS_DIR;
  if (fs.existsSync(BUNDLED_DOCS_DIR)) return BUNDLED_DOCS_DIR;
  return null;
}

/**
 * Render a markdown file as terminal-friendly output.
 */
function renderMarkdown(content) {
  const lines = content.split('\n');
  const output = [];

  for (const line of lines) {
    if (line.startsWith('# ')) {
      output.push('');
      output.push(chalk.cyan.bold('  ' + line.slice(2)));
      output.push(chalk.dim('  ' + '─'.repeat(50)));
    } else if (line.startsWith('## ')) {
      output.push('');
      output.push(chalk.yellow.bold('  ' + line.slice(3)));
    } else if (line.startsWith('### ')) {
      output.push(chalk.green('  ' + line.slice(4)));
    } else if (line.startsWith('```')) {
      output.push(chalk.dim('  ┄┄┄'));
    } else if (line.startsWith('- ')) {
      output.push('  ' + chalk.dim('•') + ' ' + line.slice(2));
    } else if (line.startsWith('> ')) {
      output.push(chalk.dim('  │ ') + chalk.italic(line.slice(2)));
    } else if (line.trim() === '') {
      output.push('');
    } else {
      output.push('  ' + line);
    }
  }

  return output.join('\n');
}

async function handleDocsQuickstart() {
  console.log('');
  console.log(chalk.cyan.bold('  🚀 KHY-Quant 快速开始'));
  console.log(chalk.dim('  ' + '─'.repeat(50)));
  console.log('');
  console.log('  ' + chalk.bold('5 分钟上手：'));
  console.log('');
  console.log('  ' + chalk.green('Step 1') + ' — 查询行情:');
  console.log(chalk.dim('    $ khy hq 茅台'));
  console.log(chalk.dim('    $ khy hq sh000300'));
  console.log('');
  console.log('  ' + chalk.green('Step 2') + ' — 与 AI 对话:');
  console.log(chalk.dim('    $ khy'));
  console.log(chalk.dim('    ◉ khy ❯ 分析一下沪深300最近的走势'));
  console.log('');
  console.log('  ' + chalk.green('Step 3') + ' — 策略回测:');
  console.log(chalk.dim('    $ khy bt sh000300 --strategy 1'));
  console.log('');
  console.log('  ' + chalk.green('Step 4') + ' — 网关配置 (选择 AI 通道):');
  console.log(chalk.dim('    $ khy gateway model'));
  console.log('');
  console.log(chalk.dim('  ' + '─'.repeat(50)));
  console.log('');
  console.log('  ' + chalk.bold('常用命令:'));
  console.log('');
  console.log('  ' + chalk.cyan('hq <代码|名称>') + '  查询实时行情');
  console.log('  ' + chalk.cyan('bt <代码>') + '       快速回测');
  console.log('  ' + chalk.cyan('menu') + '            打开交互式菜单');
  console.log('  ' + chalk.cyan('gateway model') + '   选择 AI 模型');
  console.log('  ' + chalk.cyan('doctor') + '          环境诊断');
  console.log('  ' + chalk.cyan('help') + '            查看全部命令');
  console.log('');
  console.log(chalk.dim('  💡 提示: 直接输入中文问题，AI 会理解并执行'));
  console.log('');
}

async function handleDocsClaude() {
  const docsDir = getDocsDir();
  if (!docsDir) {
    printInfo('教程文件未安装。请使用完整版: pip install "khy-quant[all]"');
    return;
  }

  const claudeDir = path.join(docsDir, 'claude-code');
  if (!fs.existsSync(claudeDir)) {
    printInfo('Claude Code 教程文件未找到');
    return;
  }

  const files = fs.readdirSync(claudeDir)
    .filter(f => f.endsWith('.md'))
    .sort();

  const inquirer = require('inquirer');
  const { doc } = await inquirer.prompt([{
    type: 'list',
    name: 'doc',
    message: '选择教程:',
    choices: [
      ...files.map(f => ({
        name: f.replace('.md', '').replace(/^\d+-/, ''),
        value: f,
      })),
      { name: '↩️  返回', value: 'back' },
    ],
    pageSize: 15,
  }]);

  if (doc === 'back') return;

  const content = fs.readFileSync(path.join(claudeDir, doc), 'utf-8');
  // Show first 80 lines as preview
  const preview = content.split('\n').slice(0, 80).join('\n');
  console.log(renderMarkdown(preview));
  console.log('');
  printInfo(`完整文档: ${path.join(claudeDir, doc)}`);
  console.log('');
}

async function handleDocsGateway() {
  console.log('');
  console.log(chalk.cyan.bold('  🌐 AI 网关使用指南'));
  console.log(chalk.dim('  ' + '─'.repeat(50)));
  console.log('');
  console.log('  KHY-Quant 支持多种 AI 通道，按优先级自动选择:');
  console.log('');
  console.log('  ' + chalk.bold('通道优先级 (从高到低):'));
  console.log('  ' + chalk.green('1.') + ' CLI 工具桥接 — 复用已登录的 Claude/Codex');
  console.log('  ' + chalk.green('2.') + ' Kiro IDE — Amazon Q Developer (免费)');
  console.log('  ' + chalk.green('3.') + ' Cursor IDE — 复用 Cursor 订阅');
  console.log('  ' + chalk.green('4.') + ' Claude Code — 复用 Claude 订阅');
  console.log('  ' + chalk.green('5.') + ' Ollama 本地 — 完全离线，无需API密钥');
  console.log('  ' + chalk.green('6.') + ' API 云端 — 需配置密钥');
  console.log('  ' + chalk.green('7.') + ' Web 中转 — 手动复制粘贴到网页AI');
  console.log('');
  console.log('  ' + chalk.bold('配置方法:'));
  console.log(chalk.dim('    gateway status    查看所有通道状态'));
  console.log(chalk.dim('    gateway model     选择使用哪个模型'));
  console.log(chalk.dim('    gateway config    配置参数'));
  console.log(chalk.dim('    gateway relay     启动 Web 中转'));
  console.log('');
  console.log('  ' + chalk.bold('Ollama 本地部署 (推荐):'));
  console.log(chalk.dim('    1. 安装 Ollama: https://ollama.com'));
  console.log(chalk.dim('    2. 拉取模型: ollama pull qwen2.5:7b'));
  console.log(chalk.dim('    3. 重启 khy，自动检测'));
  console.log('');
}

async function handleDocsStrategy() {
  console.log('');
  console.log(chalk.cyan.bold('  📊 量化策略入门'));
  console.log(chalk.dim('  ' + '─'.repeat(50)));
  console.log('');
  console.log('  ' + chalk.bold('内置策略:'));
  console.log('');
  console.log('  ' + chalk.green('1.') + ' 双均线交叉 — MA5/MA20 金叉死叉');
  console.log('  ' + chalk.green('2.') + ' RSI 超买超卖 — RSI > 70 卖 / RSI < 30 买');
  console.log('  ' + chalk.green('3.') + ' MACD 信号 — MACD 金叉做多');
  console.log('  ' + chalk.green('4.') + ' 布林带突破 — 突破上/下轨交易');
  console.log('  ' + chalk.green('5.') + ' ML 机器学习 — 基于 XGBoost 预测');
  console.log('');
  console.log('  ' + chalk.bold('回测示例:'));
  console.log(chalk.dim('    khy bt sh000300 --strategy 1 --start 2024-01-01'));
  console.log(chalk.dim('    khy bt sh600519 --strategy 3 --capital 200000'));
  console.log('');
  console.log('  ' + chalk.bold('指标说明:'));
  console.log('  • ' + chalk.yellow('年化收益率') + ' — 策略的年化投资回报');
  console.log('  • ' + chalk.yellow('夏普比率') + ' — 每承受1单位风险获得的超额收益');
  console.log('  • ' + chalk.yellow('最大回撤') + ' — 净值从最高点的最大跌幅');
  console.log('  • ' + chalk.yellow('胜率') + ' — 盈利交易占总交易数的比例');
  console.log('');
}

async function handleDocsFaq() {
  console.log('');
  console.log(chalk.cyan.bold('  🔧 常见问题 FAQ'));
  console.log(chalk.dim('  ' + '─'.repeat(50)));
  console.log('');
  console.log(chalk.bold('  Q: 安装时报 "WinError 5 拒绝访问"?'));
  console.log(chalk.dim('  A: Windows 文件被占用。解决方法:'));
  console.log(chalk.dim('     1. 关闭所有 Python 进程: taskkill /F /IM python.exe'));
  console.log(chalk.dim('     2. 关闭 VSCode / Jupyter'));
  console.log(chalk.dim('     3. 以管理员身份运行 PowerShell'));
  console.log(chalk.dim('     4. 或使用: pip install --user khy-quant'));
  console.log('');
  console.log(chalk.bold('  Q: 行情显示乱码?'));
  console.log(chalk.dim('  A: Windows 终端编码问题。运行:'));
  console.log(chalk.dim('     chcp 65001'));
  console.log(chalk.dim('     或使用 Windows Terminal (推荐)'));
  console.log('');
  console.log(chalk.bold('  Q: AI 不回复?'));
  console.log(chalk.dim('  A: 检查网关状态: gateway status'));
  console.log(chalk.dim('     优先使用 Ollama 本地模型 (无需网络)'));
  console.log(chalk.dim('     或启动 Web 中转: gateway relay'));
  console.log('');
  console.log(chalk.bold('  Q: 如何升级?'));
  console.log(chalk.dim('  A: pip install --upgrade khy-quant --no-cache-dir'));
  console.log(chalk.dim('     如遇权限问题加 --user'));
  console.log('');
  console.log(chalk.bold('  Q: 如何配置 API 密钥?'));
  console.log(chalk.dim('  A: 运行 ai config，按提示输入密钥'));
  console.log(chalk.dim('     或直接设置环境变量: OPENAI_API_KEY=sk-xxx'));
  console.log('');
}

module.exports = {
  handleDocsQuickstart,
  handleDocsClaude,
  handleDocsGateway,
  handleDocsStrategy,
  handleDocsFaq,
};
