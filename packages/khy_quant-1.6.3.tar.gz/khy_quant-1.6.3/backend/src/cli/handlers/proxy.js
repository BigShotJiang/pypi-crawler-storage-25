/**
 * CLI Handlers for the Reverse Proxy server.
 * Commands: proxy start, proxy stop, proxy status
 */
const chalk = require('chalk');
const { printSuccess, printError, printInfo } = require('../formatters');

function getProxy() {
  return require('../../services/gateway/proxyServer');
}

async function handleProxyStart(options = {}) {
  const proxy = getProxy();

  if (proxy.isRunning()) {
    printInfo(`代理服务已在运行: http://localhost:${proxy.getPort()}`);
    return;
  }

  try {
    const port = await proxy.start(options.port ? parseInt(options.port, 10) : undefined);
    console.log('');
    printSuccess('反向代理已启动');
    console.log('');
    console.log(`  ${chalk.gray('Chat:')}    ${chalk.cyan(`http://localhost:${port}/v1/chat/completions`)}`);
    console.log(`  ${chalk.gray('Models:')}  ${chalk.cyan(`http://localhost:${port}/v1/models`)}`);
    console.log(`  ${chalk.gray('Health:')} ${chalk.cyan(`http://localhost:${port}/health`)}`);
    console.log('');
    console.log(chalk.dim('  模型格式: kiro/claude-sonnet-4, cursor/gpt-4o, claude/claude-opus-4-6'));
    console.log(chalk.dim('  无前缀时按网关优先级级联'));
    console.log('');
  } catch (err) {
    printError(`启动失败: ${err.message}`);
  }
}

async function handleProxyStop() {
  const proxy = getProxy();
  if (!proxy.isRunning()) {
    printInfo('代理服务未运行');
    return;
  }
  await proxy.stop();
  printSuccess('反向代理已停止');
}

async function handleProxyStatus() {
  const proxy = getProxy();
  if (proxy.isRunning()) {
    printSuccess(`反向代理运行中: http://localhost:${proxy.getPort()}`);
  } else {
    printInfo('反向代理未运行 — 使用 proxy start 启动');
  }
}

module.exports = { handleProxyStart, handleProxyStop, handleProxyStatus };
