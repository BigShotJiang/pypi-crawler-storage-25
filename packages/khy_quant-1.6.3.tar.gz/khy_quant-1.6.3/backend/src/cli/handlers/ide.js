/**
 * IDE Command Handlers — kiro, cursor, claude, codex
 *
 * Each command lists available models from the IDE adapter,
 * lets the user select one, then enters a conversation using that model.
 */
const chalk = require('chalk');
const readline = require('readline');
const { printSuccess, printError, printInfo, printTable, withSpinner } = require('../formatters');

/**
 * Handle an IDE command: list models → select → chat.
 *
 * @param {string} ideName - 'kiro' | 'cursor' | 'claude' | 'codex'
 * @param {object} [options] - { model, list }
 * @param {object} context - { rl } from REPL
 */
async function handleIdeCommand(ideName, options = {}, context = {}) {
  const gateway = require('../../services/gateway/aiGateway');
  if (!gateway._initialized) await gateway.init();

  const adapter = gateway.getAdapter(ideName);
  if (!adapter) {
    printError(`未找到 ${ideName} 适配器`);
    return;
  }

  // Check availability
  const status = adapter.getStatus();
  if (!status.available) {
    printError(`${status.name} 不可用: ${status.detail}`);
    return;
  }

  // List models
  let models;
  try {
    models = await withSpinner(`获取 ${status.name} 模型列表...`, () => adapter.listModels());
  } catch (err) {
    printError(`获取模型列表失败: ${err.message}`);
    return;
  }

  if (!models || models.length === 0) {
    printError(`${status.name} 无可用模型`);
    return;
  }

  // If --list flag, just display and return
  if (options.list) {
    displayModelList(status.name, models);
    return;
  }

  // If --model specified, use it directly
  if (options.model) {
    const found = models.find(m => m.id === options.model || m.name === options.model);
    if (!found) {
      printError(`模型 "${options.model}" 不存在`);
      displayModelList(status.name, models);
      return;
    }
    await startChat(ideName, found, context);
    return;
  }

  // Interactive model selection
  displayModelList(status.name, models);

  const selected = await promptModelSelection(models, context);
  if (!selected) return;

  await startChat(ideName, selected, context);
}

/**
 * Display model list as a table.
 */
function displayModelList(adapterName, models) {
  console.log('');
  console.log(`  ${chalk.cyan.bold(adapterName)} 可用模型`);
  console.log('');
  printTable(
    ['#', '模型 ID', '名称', '默认'],
    models.map((m, i) => [
      String(i + 1),
      m.id,
      m.name || m.id,
      m.isDefault ? chalk.green('✓') : '',
    ])
  );
  console.log('');
}

/**
 * Prompt user to select a model by number.
 */
function promptModelSelection(models, context) {
  return new Promise((resolve) => {
    const rl = context.rl || readline.createInterface({
      input: process.stdin,
      output: process.stdout,
    });
    const ownRl = !context.rl;

    rl.question(chalk.cyan('选择模型编号 (输入数字，回车取消): '), (answer) => {
      if (ownRl) rl.close();

      const num = parseInt(answer, 10);
      if (isNaN(num) || num < 1 || num > models.length) {
        if (answer.trim()) printError('无效选择');
        resolve(null);
        return;
      }
      resolve(models[num - 1]);
    });
  });
}

/**
 * Start a chat session with the selected model.
 */
async function startChat(adapterKey, model, context) {
  const gateway = require('../../services/gateway/aiGateway');
  const { chat } = require('../ai');

  printSuccess(`已选择 ${model.name || model.id}，输入问题开始对话 (输入 exit 退出)`);
  console.log('');

  const rl = context.rl || readline.createInterface({
    input: process.stdin,
    output: process.stdout,
  });
  const ownRl = !context.rl;

  const prompt = () => {
    rl.question(chalk.gray(`[${adapterKey}] > `), async (input) => {
      const trimmed = input.trim();
      if (!trimmed || trimmed === 'exit' || trimmed === 'quit') {
        printInfo('退出 IDE 对话模式');
        if (ownRl) rl.close();
        return;
      }

      try {
        // Use the specific adapter with the selected model
        const result = await gateway.generateWithAdapter(adapterKey, trimmed, {
          model: model.id,
          onChunk: (chunk) => {
            if (chunk.type === 'text') process.stdout.write(chunk.text);
          },
        });

        if (result.success) {
          // Only print newline if streaming was used (content already output)
          if (!result.content) console.log('');
          else console.log('\n' + result.content);
        } else {
          printError('请求失败: ' + (result.attempts?.[0]?.error || '未知错误'));
        }
      } catch (err) {
        printError(err.message);
      }

      console.log('');
      prompt();
    });
  };

  prompt();
}

module.exports = { handleIdeCommand };
