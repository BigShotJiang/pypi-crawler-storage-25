/**
 * CLI Handlers for the AI Gateway system.
 * Commands: gateway status, gateway config, gateway relay
 */
const chalk = require('chalk');
const { printSuccess, printError, printInfo, printTable, ICON_GATEWAY } = require('../formatters');

/**
 * Display status of all gateway adapters.
 */
async function handleGatewayStatus() {
  const gateway = require('../../services/gateway/aiGateway');
  if (!gateway._initialized) await gateway.init();

  const statuses = gateway.getStatus();

  // Refresh model counts for available adapters that expose it
  for (const s of statuses) {
    if (s.available && s.refreshModels) {
      try { await s.refreshModels(); } catch { /* ignore */ }
    }
  }

  // Re-fetch after model refresh to get updated details
  const refreshedStatuses = gateway.getStatus();

  console.log('');
  console.log(`  ${ICON_GATEWAY} ${chalk.cyan.bold('AI 网关状态')}`);
  console.log('');

  printTable(
    ['优先级', '适配器', '类型', '状态', '详情'],
    refreshedStatuses.map(s => [
      String(s.priority),
      s.name,
      s.type,
      s.enabled
        ? (s.available ? chalk.green('✓ 可用') : chalk.yellow('⚠ 不可用'))
        : chalk.dim('已禁用'),
      s.detail,
    ])
  );

  const active = gateway.getActiveAdapter();
  if (active) {
    console.log('');
    printSuccess(`当前活跃通道: ${active.name} (${active.type})`);
  } else {
    console.log('');
    printInfo('无活跃通道 — 可用 gateway relay 启动 Web 中转');
  }
  console.log('');
}

/**
 * Interactive gateway configuration.
 */
async function handleGatewayConfig() {
  const inquirer = require('inquirer');
  const fs = require('fs');
  const path = require('path');
  const envPath = path.resolve(__dirname, '../../../.env');

  let envContent = '';
  try { envContent = fs.readFileSync(envPath, 'utf-8'); } catch { /* no .env */ }

  const { action } = await inquirer.prompt([{
    type: 'list',
    name: 'action',
    message: '网关配置:',
    choices: [
      { name: '设置 CLI 工具桥接 (开/关)', value: 'cli-toggle' },
      { name: '配置 Ollama 本地模型', value: 'ollama-config' },
      { name: '设置 Web 中转端口', value: 'relay-port' },
      { name: '设置中转超时时间', value: 'relay-timeout' },
      { name: '↩️  返回', value: 'back' },
    ],
  }]);

  if (action === 'back') return;

  function setEnvVar(key, value) {
    const regex = new RegExp(`^${key}=.*$`, 'm');
    const line = `${key}=${value}`;
    if (regex.test(envContent)) {
      envContent = envContent.replace(regex, line);
    } else {
      envContent = envContent.trimEnd() + '\n' + line + '\n';
    }
    fs.writeFileSync(envPath, envContent);
    process.env[key] = String(value);
  }

  if (action === 'cli-toggle') {
    const current = process.env.GATEWAY_CLI_ENABLED !== 'false';
    const { enabled } = await inquirer.prompt([{
      type: 'confirm',
      name: 'enabled',
      message: `CLI 工具桥接当前${current ? '已开启' : '已关闭'}，是否开启?`,
      default: true,
    }]);
    setEnvVar('GATEWAY_CLI_ENABLED', enabled);
    printSuccess(`CLI 工具桥接已${enabled ? '开启' : '关闭'}`);
  }

  if (action === 'ollama-config') {
    const ollamaAdapter = require('../../services/gateway/adapters/ollamaAdapter');
    const available = ollamaAdapter.detect(true); // force refresh
    const models = ollamaAdapter.getModels();

    if (!available) {
      printError('Ollama 服务未运行');
      printInfo('安装: https://ollama.com');
      printInfo('启动: ollama serve');
      printInfo('拉取模型: ollama pull qwen2.5:7b');
      return;
    }

    printSuccess(`Ollama 运行中，${models.length} 个模型可用`);

    if (models.length > 0) {
      const { model } = await inquirer.prompt([{
        type: 'list',
        name: 'model',
        message: '选择默认模型:',
        choices: models.map(m => ({ name: m, value: m })),
        default: process.env.OLLAMA_MODEL || 'qwen2.5:7b',
      }]);
      setEnvVar('OLLAMA_MODEL', model);
      printSuccess(`默认模型已设为 ${model}`);
    }

    const { host } = await inquirer.prompt([{
      type: 'input',
      name: 'host',
      message: 'Ollama 地址:',
      default: process.env.OLLAMA_HOST || 'http://localhost:11434',
    }]);
    if (host !== 'http://localhost:11434') {
      setEnvVar('OLLAMA_HOST', host);
      printSuccess(`Ollama 地址已设为 ${host}`);
    }
    return;
  }

  if (action === 'relay-port') {
    const { port } = await inquirer.prompt([{
      type: 'input',
      name: 'port',
      message: '中转服务端口:',
      default: process.env.GATEWAY_RELAY_PORT || '9099',
      validate: v => /^\d+$/.test(v) ? true : '请输入数字',
    }]);
    setEnvVar('GATEWAY_RELAY_PORT', port);
    printSuccess(`中转端口已设为 ${port}`);
    printInfo('重启中转服务后生效');
  }

  if (action === 'relay-timeout') {
    const { minutes } = await inquirer.prompt([{
      type: 'input',
      name: 'minutes',
      message: '中转超时 (分钟):',
      default: String(Math.round((parseInt(process.env.GATEWAY_RELAY_TIMEOUT, 10) || 600000) / 60000)),
      validate: v => /^\d+$/.test(v) ? true : '请输入数字',
    }]);
    setEnvVar('GATEWAY_RELAY_TIMEOUT', parseInt(minutes, 10) * 60000);
    printSuccess(`中转超时已设为 ${minutes} 分钟`);
  }
}

/**
 * Select AI model from available adapters.
 */
async function handleGatewaySelectModel() {
  const inquirer = require('inquirer');
  const gateway = require('../../services/gateway/aiGateway');
  if (!gateway._initialized) await gateway.init();

  const statuses = gateway.getStatus();
  const availableAdapters = statuses.filter(s => s.available && s.enabled);

  if (availableAdapters.length === 0) {
    printError('无可用 AI 通道');
    return;
  }

  // Collect models from all available adapters
  const modelChoices = [];
  for (const s of availableAdapters) {
    try {
      const models = await gateway.listModels(s.type);
      if (models && models.length > 0) {
        for (const m of models) {
          modelChoices.push({
            name: `${m.name || m.id} ${chalk.dim('(' + s.name + ')')}${m.isDefault ? chalk.green(' ✓ 当前') : ''}`,
            value: { adapter: s.type, model: m.id },
          });
        }
      } else {
        // Adapter available but no model list (e.g. relay)
        modelChoices.push({
          name: `${s.name} ${chalk.dim('(默认模型)')}`,
          value: { adapter: s.type, model: null },
        });
      }
    } catch {
      // Skip adapters that fail to list models
    }
  }

  if (modelChoices.length === 0) {
    printInfo('当前可用通道未提供模型列表');
    return;
  }

  const { selected } = await inquirer.prompt([{
    type: 'list',
    name: 'selected',
    message: '选择 AI 模型:',
    choices: [
      ...modelChoices,
      new inquirer.Separator(),
      { name: '↩️  返回', value: null },
    ],
  }]);

  if (!selected) return;

  // Save selection to .env
  const fs = require('fs');
  const path = require('path');
  const envPath = path.resolve(__dirname, '../../../.env');
  let envContent = '';
  try { envContent = fs.readFileSync(envPath, 'utf-8'); } catch { /* no .env */ }

  function setEnvVar(key, value) {
    const regex = new RegExp(`^${key}=.*$`, 'm');
    const line = `${key}=${value}`;
    if (regex.test(envContent)) {
      envContent = envContent.replace(regex, line);
    } else {
      envContent = envContent.trimEnd() + '\n' + line + '\n';
    }
    process.env[key] = String(value);
  }

  setEnvVar('GATEWAY_PREFERRED_ADAPTER', selected.adapter);
  if (selected.model) setEnvVar('GATEWAY_PREFERRED_MODEL', selected.model);
  fs.writeFileSync(envPath, envContent);

  printSuccess(`已选择: ${selected.model || '默认模型'} (${selected.adapter})`);
  console.log('');
}

/**
 * Explicitly start the web relay server.
 */
async function handleGatewayRelay() {
  const gateway = require('../../services/gateway/aiGateway');
  const relay = gateway.getRelayAdapter();

  if (relay.isRunning()) {
    printInfo(`中转服务已在运行: http://localhost:${relay.getPort()}`);
    return;
  }

  const port = await relay.start();
  console.log('');
  printSuccess(`AI 中转服务已启动`);
  console.log('');
  console.log(chalk.bold(`  🌐 打开浏览器访问: ${chalk.cyan(`http://localhost:${port}`)}`));
  console.log('');
  console.log(chalk.dim('  使用方式:'));
  console.log(chalk.dim('    1. 终端发送 AI 请求后，提示会出现在网页上'));
  console.log(chalk.dim('    2. 点击「一键复制」将提示复制到剪贴板'));
  console.log(chalk.dim('    3. 粘贴到任意 AI 网页（ChatGPT、Claude、Gemini 等）'));
  console.log(chalk.dim('    4. 复制 AI 回复，粘贴到网页文本框，点击「提交」'));
  console.log(chalk.dim('    5. 回复将自动返回到终端'));
  console.log('');
}

/**
 * Detect IDE installations and allow manual path configuration.
 */
async function handleGatewayDetect() {
  const { detectAll, setCustomPath, findInstallation, findDataPath } = require('../../services/gateway/adapters/ideDetector');

  const results = detectAll();

  console.log('');
  console.log(`  ${chalk.cyan.bold('IDE 安装检测')}`);
  console.log('');

  printTable(
    ['IDE', '安装路径', '数据路径', '状态'],
    results.map(r => [
      r.name.charAt(0).toUpperCase() + r.name.slice(1),
      r.installPath || chalk.dim('未找到'),
      r.dataPath ? chalk.dim('✓') : chalk.dim('—'),
      r.available ? chalk.green('✓ 已检测') : chalk.yellow('⚠ 未检测到'),
    ])
  );
  console.log('');

  // Offer to set custom paths for missing IDEs
  const missing = results.filter(r => !r.available);
  if (missing.length > 0) {
    printInfo('未检测到的 IDE 可手动设置安装路径');
    const inquirer = require('inquirer');

    const { action } = await inquirer.prompt([{
      type: 'list',
      name: 'action',
      message: '操作:',
      choices: [
        ...missing.map(r => ({
          name: `设置 ${r.name} 安装路径`,
          value: r.name,
        })),
        { name: '↩️  返回', value: 'back' },
      ],
    }]);

    if (action !== 'back') {
      const { customPath } = await inquirer.prompt([{
        type: 'input',
        name: 'customPath',
        message: `输入 ${action} 安装路径:`,
        validate: (v) => {
          if (!v.trim()) return '路径不能为空';
          return true;
        },
      }]);

      const fs = require('fs');
      const pathModule = require('path');
      const envPath = pathModule.resolve(__dirname, '../../../.env');
      let envContent = '';
      try { envContent = fs.readFileSync(envPath, 'utf-8'); } catch { /* no .env */ }

      const envKey = `${action.toUpperCase()}_INSTALL_PATH`;
      const regex = new RegExp(`^${envKey}=.*$`, 'm');
      const line = `${envKey}=${customPath.trim()}`;

      if (regex.test(envContent)) {
        envContent = envContent.replace(regex, line);
      } else {
        envContent = envContent.trimEnd() + '\n' + line + '\n';
      }

      fs.writeFileSync(envPath, envContent);
      process.env[envKey] = customPath.trim();
      setCustomPath(action, customPath.trim());

      printSuccess(`${action} 安装路径已设为: ${customPath.trim()}`);
    }
  }
}

module.exports = { handleGatewayStatus, handleGatewayConfig, handleGatewayRelay, handleGatewayDetect, handleGatewaySelectModel };
