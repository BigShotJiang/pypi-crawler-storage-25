/**
 * CLI Handlers for Account Pool management.
 * Commands: pool status, pool add, pool list, pool reset
 */
const chalk = require('chalk');
const { printSuccess, printError, printInfo, printTable } = require('../formatters');

function getPool() {
  return require('../../services/accountPool');
}

/**
 * Display account pool statistics.
 */
async function handlePoolStatus() {
  const pool = getPool();
  try {
    const stats = await pool.getStats();
    if (!stats || stats.length === 0) {
      printInfo('帐号池为空 — 使用 pool add <type> 添加帐号');
      return;
    }

    console.log('');
    console.log(`  ${chalk.cyan.bold('帐号池统计')}`);
    console.log('');
    printTable(
      ['类型', '总计', '可用', '已租', '被封', '无效', '耗尽'],
      stats.map(s => [
        s.pool_type,
        String(s.total),
        chalk.green(String(s.available)),
        chalk.yellow(String(s.leased)),
        chalk.red(String(s.banned)),
        chalk.dim(String(s.invalid)),
        chalk.dim(String(s.exhausted)),
      ])
    );
    console.log('');
  } catch (err) {
    printError(`获取帐号池状态失败: ${err.message}`);
  }
}

/**
 * Add accounts to the pool.
 */
async function handlePoolAdd(poolType, options = {}) {
  if (!poolType) {
    printError('用法: pool add <kiro|cursor|claude|codex>');
    return;
  }

  const pool = getPool();
  const readline = require('readline');
  const rl = readline.createInterface({ input: process.stdin, output: process.stdout });

  const ask = (q) => new Promise(r => rl.question(q, r));

  printInfo(`添加帐号到 ${poolType} 池 (输入空行结束)`);
  const accounts = [];

  try {
    while (true) {
      const email = await ask(chalk.gray('Email: '));
      if (!email.trim()) break;

      const password = await ask(chalk.gray('Password (可选): '));
      const accessToken = await ask(chalk.gray('Access Token (可选): '));
      const accountType = await ask(chalk.gray('类型 [FREE/PRO]: ')) || 'FREE';

      accounts.push({
        email: email.trim(),
        password: password.trim() || null,
        access_token: accessToken.trim() || null,
        account_type: accountType.trim().toUpperCase(),
      });
    }
  } finally {
    rl.close();
  }

  if (accounts.length === 0) {
    printInfo('未添加任何帐号');
    return;
  }

  const added = await pool.addAccounts(poolType, accounts);
  printSuccess(`已添加 ${added} 个帐号到 ${poolType} 池`);
}

/**
 * List accounts in the pool (masked).
 */
async function handlePoolList(poolType, options = {}) {
  if (!poolType) {
    printError('用法: pool list <kiro|cursor|claude|codex>');
    return;
  }

  const pool = getPool();

  // Direct query for listing
  try {
    const sequelize = require('../../models').sequelize;
    const [rows] = await sequelize.query(`
      SELECT id, email, account_type, status, leased_by, last_used_at
      FROM account_pool WHERE pool_type = :poolType
      ORDER BY status, id
    `, { replacements: { poolType } });

    if (rows.length === 0) {
      printInfo(`${poolType} 池中无帐号`);
      return;
    }

    printTable(
      ['ID', 'Email', '类型', '状态', '租用者', '最后使用'],
      rows.map(r => [
        String(r.id),
        maskEmail(r.email || '—'),
        r.account_type || 'FREE',
        statusBadge(r.status),
        r.leased_by || '—',
        r.last_used_at ? new Date(r.last_used_at).toLocaleDateString('zh-CN') : '—',
      ])
    );
  } catch (err) {
    printError(`查询失败: ${err.message}`);
  }
}

/**
 * Reset account statuses.
 */
async function handlePoolReset(poolType, options = {}) {
  if (!poolType) {
    printError('用法: pool reset <kiro|cursor|claude|codex>');
    return;
  }

  const pool = getPool();
  await pool.resetAccounts(poolType);
  printSuccess(`已重置 ${poolType} 池中所有已租/耗尽帐号为可用`);
}

// ── Helpers ──

function maskEmail(email) {
  if (!email || !email.includes('@')) return email;
  const [user, domain] = email.split('@');
  return user.slice(0, 2) + '***@' + domain;
}

function statusBadge(status) {
  switch (status) {
    case 'available': return chalk.green('可用');
    case 'leased': return chalk.yellow('已租');
    case 'banned': return chalk.red('被封');
    case 'invalid': return chalk.red('无效');
    case 'exhausted': return chalk.dim('耗尽');
    default: return status;
  }
}

module.exports = { handlePoolStatus, handlePoolAdd, handlePoolList, handlePoolReset };
