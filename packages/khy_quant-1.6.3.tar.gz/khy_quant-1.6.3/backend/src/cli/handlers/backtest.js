/**
 * Backtest CLI handlers: backtest run, backtest list, strategy list.
 */
const fs = require('fs');
const path = require('path');
const { bootstrap, muteDbLogs, restoreDbLogs } = require('../bootstrap');
const { printBacktestResult, printTable, printSuccess, printError, withSpinner } = require('../formatters');

async function handleBacktestRun(symbol, options = {}) {
  await bootstrap({ silent: true });

  // Mute module-level logs from backtestEngine → klineDataService → pythonPath
  muteDbLogs();
  const backtestEngine = require('../../services/backtestEngine');
  const { Strategy } = require('../../models');
  restoreDbLogs();

  // Resolve strategy code
  let signalFn;
  let strategyName = 'custom';
  const strategyRef = options.strategy;

  if (strategyRef) {
    // Numeric ID → load from database
    if (/^\d+$/.test(strategyRef)) {
      const dbStrategy = await Strategy.findByPk(parseInt(strategyRef));
      if (!dbStrategy) {
        printError(`策略 ID ${strategyRef} 不存在`);
        return;
      }
      signalFn = dbStrategy.code;
      strategyName = dbStrategy.name;
    } else {
      // File path → read file
      const filePath = path.resolve(strategyRef);
      if (!fs.existsSync(filePath)) {
        printError(`策略文件不存在: ${filePath}`);
        return;
      }
      signalFn = fs.readFileSync(filePath, 'utf-8');
      strategyName = path.basename(filePath, path.extname(filePath));
    }
  } else {
    // Default: load first strategy from DB
    const first = await Strategy.findOne({ order: [['id', 'ASC']] });
    if (!first) {
      printError('没有可用策略，请通过 --strategy <id|file> 指定');
      return;
    }
    signalFn = first.code;
    strategyName = first.name;
  }

  const startDate = options.start || '2024-01-01';
  const endDate = options.end || new Date().toISOString().slice(0, 10);
  const initialCapital = parseInt(options.capital) || 100000;

  console.log(`  策略: ${strategyName}`);

  const result = await withSpinner(
    `回测 ${symbol} (${startDate} → ${endDate})...`,
    () => backtestEngine.run({ symbol, startDate, endDate, initialCapital, signalFn }),
    { muteOutput: true }
  );

  printBacktestResult(result);

  // Print trade log if verbose
  if (options.verbose && result.trades && result.trades.length > 0) {
    const chalk = require('chalk');
    console.log(chalk.bold('  交易记录'));
    printTable(
      ['日期', '方向', '价格', '数量', '盈亏'],
      result.trades.map(t => [
        t.date || '-',
        t.side === 'buy' ? chalk.red('买入') : chalk.green('卖出'),
        '¥' + Number(t.price).toFixed(2),
        String(t.quantity),
        t.profit !== undefined ? (t.profit >= 0 ? '+' : '') + Number(t.profit).toFixed(2) : '-',
      ])
    );
  }
}

async function handleBacktestList(options = {}) {
  await bootstrap({ silent: true });

  const { Backtest } = require('../../models');
  const limit = parseInt(options.limit) || 20;

  const where = {};
  if (options.status) where.status = options.status;

  const backtests = await Backtest.findAll({
    where,
    order: [['created_at', 'DESC']],
    limit,
    raw: true,
  });

  if (!backtests || backtests.length === 0) {
    printError('暂无回测记录');
    return;
  }

  printSuccess(`共 ${backtests.length} 条回测记录`);
  printTable(
    ['ID', '名称', '品种', '状态', '收益率', '夏普', '创建时间'],
    backtests.map(b => [
      String(b.id),
      (b.name || '-').substring(0, 16),
      b.symbol || '-',
      b.status || '-',
      b.totalReturn !== undefined ? b.totalReturn + '%' : '-',
      b.sharpeRatio !== undefined ? String(b.sharpeRatio) : '-',
      b.created_at ? new Date(b.created_at).toLocaleDateString('zh-CN') : '-',
    ])
  );
}

async function handleStrategyList() {
  await bootstrap({ silent: true });

  const { Strategy } = require('../../models');

  const strategies = await Strategy.findAll({
    order: [['id', 'ASC']],
    raw: true,
  });

  if (!strategies || strategies.length === 0) {
    printError('暂无策略，请先运行 db seed');
    return;
  }

  printSuccess(`共 ${strategies.length} 个策略`);
  printTable(
    ['ID', '名称', '语言', '类型', '状态'],
    strategies.map(s => [
      String(s.id),
      (s.name || '-').substring(0, 20),
      s.language || 'javascript',
      s.type || '-',
      s.status || 'active',
    ])
  );
}

module.exports = { handleBacktestRun, handleBacktestList, handleStrategyList };
