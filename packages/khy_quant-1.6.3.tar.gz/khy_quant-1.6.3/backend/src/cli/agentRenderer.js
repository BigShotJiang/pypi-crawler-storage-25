/**
 * Agent Renderer — tree-style display for multi-agent parallel execution.
 *
 * Shows Claude Code-style agent progress:
 *   ● Running 3 agents...  (ctrl+o to expand)
 *     ├ 基本面分析师 · 5 tool uses · 2.1k tokens
 *     │ └ Done
 *     ├ 技术面分析师 · 3 tool uses · 1.8k tokens
 *     │ └ Running...
 *     └ 风控经理 · pending
 *
 * Lazy-loads chalk for fast cold start.
 */
let _chalk;
const c = () => (_chalk ??= require('chalk'));

const DOT_PENDING  = '○';
const DOT_ACTIVE   = '●';
const DOT_SUCCESS  = '●';
const DOT_ERROR    = '●';

/**
 * Render the full agent tree display.
 * @param {Array<{name: string, status: string, toolCalls?: number, tokens?: number, elapsed?: number, detail?: string}>} agents
 * @returns {number} number of lines rendered
 */
function renderAgentTree(agents) {
  let lines = 0;

  for (let i = 0; i < agents.length; i++) {
    const agent = agents[i];
    const isLast = i === agents.length - 1;
    const branch = isLast ? '└' : '├';

    let dot, nameColor;
    switch (agent.status) {
      case 'completed':
        dot = c().green(DOT_SUCCESS);
        nameColor = c().green;
        break;
      case 'error':
        dot = c().red(DOT_ERROR);
        nameColor = c().red;
        break;
      case 'running':
        dot = c().dim(DOT_ACTIVE);
        nameColor = c().bold.white;
        break;
      default:
        dot = c().dim(DOT_PENDING);
        nameColor = c().dim;
        break;
    }

    // Build stats string
    const stats = [];
    if (agent.toolCalls > 0) stats.push(`${agent.toolCalls} tool uses`);
    if (agent.tokens > 0) {
      stats.push(agent.tokens >= 1000
        ? `${(agent.tokens / 1000).toFixed(1)}k tokens`
        : `${agent.tokens} tokens`);
    }
    if (agent.elapsed > 0) {
      const sec = (agent.elapsed / 1000).toFixed(1);
      stats.push(`${sec}s`);
    }
    const statsStr = stats.length > 0 ? c().dim(` · ${stats.join(' · ')}`) : '';

    console.log(`    ${branch} ${nameColor(agent.name)}${statsStr}`);
    lines++;

    // Detail sub-line
    if (agent.detail) {
      const subBranch = isLast ? ' ' : '│';
      console.log(`    ${subBranch} ${c().dim(`└ ${agent.detail}`)}`);
      lines++;
    }
  }

  return lines;
}

/**
 * Render the agent header: "Running N agents... (ctrl+o to expand)"
 * @param {number} count
 * @param {boolean} [finished=false]
 */
function renderAgentHeader(count, finished = false) {
  if (finished) {
    console.log(`  ${c().green(DOT_SUCCESS)} ${c().green(`${count} agents finished`)} ${c().dim('(ctrl+o to expand)')}`);
  } else {
    console.log(`  ${c().dim(DOT_ACTIVE)} ${c().bold(`Running ${count} agents...`)} ${c().dim('(ctrl+o to expand)')}`);
  }
}

/**
 * Render complete agent progress display with header + tree.
 * @param {Array} agents - agent state array
 * @param {boolean} [finished=false]
 * @returns {number} total lines rendered
 */
function renderAgentDisplay(agents, finished = false) {
  renderAgentHeader(agents.length, finished);
  const treeLines = renderAgentTree(agents);
  return 1 + treeLines;
}

/**
 * Re-render agent display by moving cursor up and clearing.
 * @param {Array} agents
 * @param {number} previousLines - how many lines the previous render produced
 * @param {boolean} [finished=false]
 * @returns {number} new line count
 */
function rerenderAgentDisplay(agents, previousLines, finished = false) {
  if (process.stdout.isTTY && previousLines > 0) {
    for (let i = 0; i < previousLines; i++) {
      process.stdout.write('\x1b[1A\r\x1b[K');
    }
  }
  return renderAgentDisplay(agents, finished);
}

/**
 * Render the synthesis result with attribution.
 * @param {string} synthesized - synthesized text
 * @param {Array<{name: string, status: string}>} agents
 */
function renderSynthesisResult(synthesized, agents) {
  const renderer = require('./aiRenderer');

  // Show which agents contributed
  const contributors = agents.filter(a => a.status === 'completed').map(a => a.name);
  console.log('');
  console.log(c().dim(`  综合来源: ${contributors.join(' · ')}`));
  console.log(c().dim('  ┌──'));

  const rendered = renderer.renderAiResponse(synthesized);
  rendered.split('\n').forEach(l => console.log(c().dim('  │ ') + l));
  console.log(c().dim('  └──'));
}

/**
 * Render agent completion summary.
 * @param {Array} agents
 */
function renderAgentSummary(agents) {
  const completed = agents.filter(a => a.status === 'completed').length;
  const failed = agents.filter(a => a.status === 'error').length;
  const totalTokens = agents.reduce((sum, a) => sum + (a.tokens || 0), 0);
  const totalToolCalls = agents.reduce((sum, a) => sum + (a.toolCalls || 0), 0);
  const maxElapsed = Math.max(...agents.map(a => a.elapsed || 0));

  const parts = [];
  parts.push(`${completed} completed`);
  if (failed > 0) parts.push(`${failed} failed`);
  if (totalToolCalls > 0) parts.push(`${totalToolCalls} tool uses`);
  if (totalTokens > 0) parts.push(`${(totalTokens / 1000).toFixed(1)}k tokens`);
  if (maxElapsed > 0) parts.push(`${(maxElapsed / 1000).toFixed(1)}s`);

  console.log(`  ${c().dim('└')} ${c().green('Done')} ${c().dim(`(${parts.join(' · ')})`)}`);
}

module.exports = {
  renderAgentTree,
  renderAgentHeader,
  renderAgentDisplay,
  rerenderAgentDisplay,
  renderSynthesisResult,
  renderAgentSummary,
};
