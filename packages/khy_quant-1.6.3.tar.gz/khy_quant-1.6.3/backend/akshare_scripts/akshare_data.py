
import akshare as ak
import json
import sys
import pandas as pd
from datetime import datetime, timedelta

def get_stock_realtime(symbol):
    """获取股票实时数据"""
    try:
        # 去掉 sh/sz 前缀
        pure_code = symbol.lower().lstrip('sh').lstrip('sz') if symbol[:2].lower() in ('sh', 'sz') else symbol
        # 获取实时数据
        df = ak.stock_zh_a_spot_em()
        stock_data = df[df['代码'] == pure_code]
        
        if stock_data.empty:
            return {"error": "股票代码不存在: " + pure_code}
        
        row = stock_data.iloc[0]
        
        result = {
            "symbol": symbol,
            "name": row['名称'],
            "current_price": float(row['最新价']),
            "open": float(row['今开']),
            "high": float(row['最高']),
            "low": float(row['最低']),
            "close": float(row['昨收']),
            "volume": int(row['成交量']),
            "amount": float(row['成交额']),
            "change": float(row['涨跌额']),
            "change_percent": float(row['涨跌幅']),
            "source": "AKShare实时数据"
        }
        
        return result
        
    except Exception as e:
        return {"error": str(e)}

def get_stock_kline(symbol, period='daily', count=100):
    """获取股票K线数据"""
    try:
        # 去掉 sh/sz 前缀
        pure_code = symbol.lower().lstrip('sh').lstrip('sz') if symbol[:2].lower() in ('sh', 'sz') else symbol
        # 根据周期选择不同的接口
        if period == 'daily':
            df = ak.stock_zh_a_hist(symbol=pure_code, period="daily", adjust="qfq")
        elif period == 'weekly':
            df = ak.stock_zh_a_hist(symbol=pure_code, period="weekly", adjust="qfq")
        elif period == 'monthly':
            df = ak.stock_zh_a_hist(symbol=pure_code, period="monthly", adjust="qfq")
        else:
            df = ak.stock_zh_a_hist(symbol=pure_code, period="daily", adjust="qfq")
        
        if df.empty:
            return {"error": "无法获取K线数据"}
        
        # 取最近的数据
        df = df.tail(count)
        
        kline_data = []
        for _, row in df.iterrows():
            kline_data.append({
                "time": row['日期'].strftime('%Y-%m-%d'),
                "open": float(row['开盘']),
                "high": float(row['最高']),
                "low": float(row['最低']),
                "close": float(row['收盘']),
                "volume": int(row['成交量'])
            })
        
        return {
            "symbol": symbol,
            "kline": kline_data,
            "source": "AKShare历史数据"
        }
        
    except Exception as e:
        return {"error": str(e)}

def get_index_realtime(symbol):
    """获取指数实时数据"""
    try:
        # 去掉 sh/sz 前缀，akshare 只用纯数字代码
        pure_code = symbol.lower().lstrip('sh').lstrip('sz') if symbol[:2].lower() in ('sh', 'sz') else symbol
        # 获取指数实时数据
        df = ak.stock_zh_index_spot_em()
        index_data = df[df['代码'] == pure_code]
        
        if index_data.empty:
            return {"error": "指数代码不存在: " + pure_code}
        
        row = index_data.iloc[0]
        
        result = {
            "symbol": symbol,
            "name": row['名称'],
            "current_price": float(row['最新价']),
            "open": float(row['今开']),
            "high": float(row['最高']),
            "low": float(row['最低']),
            "close": float(row['昨收']),
            "volume": int(row['成交量']) if '成交量' in row else 0,
            "amount": float(row['成交额']) if '成交额' in row else 0,
            "change": float(row['涨跌额']),
            "change_percent": float(row['涨跌幅']),
            "source": "AKShare指数数据"
        }
        
        return result
        
    except Exception as e:
        return {"error": str(e)}

if __name__ == "__main__":
    if len(sys.argv) < 3:
        print(json.dumps({"error": "参数不足"}))
        sys.exit(1)
    
    action = sys.argv[1]
    symbol = sys.argv[2]
    
    if action == "realtime":
        result = get_stock_realtime(symbol)
    elif action == "kline":
        count = int(sys.argv[3]) if len(sys.argv) > 3 else 100
        period = sys.argv[4] if len(sys.argv) > 4 else 'daily'
        result = get_stock_kline(symbol, period, count)
    elif action == "index":
        result = get_index_realtime(symbol)
    else:
        result = {"error": "未知操作"}
    
    print(json.dumps(result, ensure_ascii=False, default=str))
