"""
KHY-Quant CLI entry point.

Thin Python shim that:
1. Checks Node.js >= 18
2. Locates the bundled backend/ directory
3. Runs first-time bootstrap if needed
4. Execs into the Node.js CLI (bin/khyquant.js)
"""
import os
import subprocess
import sys
from pathlib import Path

try:
    from importlib import metadata as importlib_metadata
except ImportError:  # pragma: no cover - Python < 3.8 fallback
    import importlib_metadata  # type: ignore


def get_bundle_dir() -> Path:
    """Return the path to the bundled backend/ directory."""
    # Try split backend package first (pip install khy-quant-backend)
    try:
        from khy_quant_backend.cli import get_bundle_dir as _backend_get
        return _backend_get()
    except ImportError:
        pass

    # Pip-installed mode: khy_quant/bundled/backend/
    bundled = Path(__file__).parent / "bundled" / "backend"
    if bundled.exists():
        return bundled

    # Development / editable mode: project_root/backend/
    dev = Path(__file__).parent.parent / "backend"
    if dev.exists():
        return dev

    print("Error: Cannot locate KHY-Quant backend directory.", file=sys.stderr)
    print("  If you installed via pip, the package may be corrupted.", file=sys.stderr)
    print("  Try: pip install --force-reinstall khy-quant", file=sys.stderr)
    sys.exit(1)


def check_node() -> str:
    """Check Node.js is installed and >= 18. Return the node binary path."""
    for cmd in ("node", "node.exe"):
        try:
            result = subprocess.run(
                [cmd, "--version"],
                capture_output=True,
                text=True,
                encoding="utf-8",
                errors="replace",
                timeout=10,
            )
            if result.returncode == 0:
                version = result.stdout.strip().lstrip("v")
                major = int(version.split(".")[0])
                if major >= 18:
                    return cmd
                print(
                    f"Error: Node.js v{version} found but >= 18 required.",
                    file=sys.stderr,
                )
                _print_node_install_hint()
                sys.exit(1)
        except (FileNotFoundError, subprocess.TimeoutExpired):
            continue

    print("Error: Node.js not found.", file=sys.stderr)
    print("  KHY-Quant requires Node.js >= 18.", file=sys.stderr)
    _print_node_install_hint()
    sys.exit(1)


def get_installed_version() -> str:
    """Return installed khy-quant package version, or empty string if unknown."""
    try:
        return importlib_metadata.version("khy-quant")
    except Exception:
        return ""


def _print_node_install_hint():
    """Print platform-specific Node.js install instructions."""
    # Detect Chinese locale for mirror suggestion
    lang = os.environ.get("LANG", "") + os.environ.get("LC_ALL", "")
    tz = os.environ.get("TZ", "")
    is_china = lang.startswith("zh") or "Shanghai" in tz or "Chongqing" in tz

    if is_china:
        print("  Install from: https://npmmirror.com/mirrors/node/", file=sys.stderr)
    else:
        print("  Install from: https://nodejs.org/", file=sys.stderr)

    plat = sys.platform
    if plat == "darwin":
        print("  Or: brew install node", file=sys.stderr)
    elif plat.startswith("linux"):
        print("  Or: curl -fsSL https://deb.nodesource.com/setup_22.x | sudo bash -", file=sys.stderr)
    elif plat == "win32":
        print("  Or: winget install OpenJS.NodeJS.LTS", file=sys.stderr)


def main():
    """Entry point registered as console_scripts."""
    node = check_node()
    backend_dir = get_bundle_dir()

    # First-run bootstrap
    from khy_quant._bootstrap import ensure_bootstrapped
    ensure_bootstrapped(backend_dir, node)

    # Exec into Node.js CLI, passing through all arguments
    cli_script = backend_dir / "bin" / "khyquant.js"
    if not cli_script.exists():
        print(f"Error: CLI script not found at {cli_script}", file=sys.stderr)
        sys.exit(1)

    args = [node, str(cli_script)] + sys.argv[1:]
    env = os.environ.copy()
    env["KHYQUANT_ROOT"] = str(backend_dir)
    pkg_version = get_installed_version()
    if pkg_version:
        env["KHYQUANT_PKG_VERSION"] = pkg_version

    if os.name == "nt":
        # Windows: subprocess (os.execvpe not available)
        result = subprocess.run(args, env=env, cwd=str(backend_dir))
        sys.exit(result.returncode)
    else:
        # Unix: replace process entirely (best for REPL signal handling)
        os.execvpe(node, args, env)
