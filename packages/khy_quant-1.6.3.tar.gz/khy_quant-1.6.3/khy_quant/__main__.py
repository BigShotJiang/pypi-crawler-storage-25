"""Support for python -m khy_quant."""
from khy_quant.cli import main

main()
