"""
Custom build command to bundle backend/ and frontend/ into the Python package.

At build time:
1. Copies source files (excluding node_modules, .env, logs, etc.) into khy_quant/bundled/
2. Obfuscates all JS files in bundled/backend/src/ (javascript-obfuscator)
3. Compiles Python launcher files to .pyc and removes .py source

Install modes (via pip extras):
  pip install khy-quant          — Core CLI + backend (minimal)
  pip install khy-quant[data]    — + Python data analysis libraries
  pip install khy-quant[ml]      — + Machine learning strategies
  pip install khy-quant[full]    — Everything (backend + frontend + ML)
  pip install khy-quant[frontend]— + Web frontend
  pip install khy-quant[backend] — CLI + backend + data
  pip install khy-quant[dev]     — + Development tools

The wheel always includes backend; frontend is included in the build
so users can optionally serve it. Component selection at runtime is
handled by the CLI entry point based on what's available.
"""
import compileall
import os
import shutil
import subprocess
import sys
from pathlib import Path

from setuptools import setup
from setuptools.command.build_py import build_py

ROOT = Path(__file__).parent

# Try to find the original project root (for isolated builds where ROOT is a temp copy)
_ORIGINAL_ROOT = Path(os.environ.get("KHY_PROJECT_ROOT", str(ROOT)))
if not (_ORIGINAL_ROOT / "backend" / "node_modules").exists():
    # Fallback: try the real path from common locations
    for candidate in [Path.cwd(), Path(__file__).resolve().parent]:
        if (candidate / "backend" / "node_modules").exists():
            _ORIGINAL_ROOT = candidate
            break

# Patterns to exclude from the bundle
EXCLUDE_PATTERNS = (
    "node_modules",
    "__pycache__",
    ".env",
    ".env.local",
    "logs",
    "temp",
    "data",
    ".DS_Store",
    "Thumbs.db",
    "*.pyc",
    "*.db",
    "*.sqlite",
    "*.sqlite3",
    "*.joblib",
    "*.log",
    "INTERNAL_CREDENTIALS*",
)

# Directories to skip entirely
PRUNE_DIRS = {
    "node_modules",
    "__pycache__",
    "logs",
    "temp",
    "data",
    ".git",
    "android",
    "android-sdk",
    "dist",
}


def _find_obfuscate_script() -> Path | None:
    """Locate obfuscate.js — may be in ROOT (normal build) or a sibling of the
    isolated build directory (when python -m build creates a temp copy)."""
    candidates = [
        ROOT / "scripts" / "obfuscate.js",
        # Original project directory (for isolated builds)
        Path(__file__).resolve().parent / "scripts" / "obfuscate.js",
    ]
    for p in candidates:
        if p.exists():
            return p
    return None


def _obfuscate_js(bundled_backend: Path):
    """Run javascript-obfuscator on all JS files in bundled backend."""
    obfuscate_script = _find_obfuscate_script()
    target_dir = bundled_backend / "src"

    if not obfuscate_script or not target_dir.exists():
        print("  [SKIP] JS obfuscation: missing script or target")
        return

    node_cmd = "node"

    # Obfuscate backend/src/ (main application code)
    try:
        # Ensure node can find javascript-obfuscator in backend/node_modules
        env = os.environ.copy()
        node_paths = [
            str(_ORIGINAL_ROOT / "backend" / "node_modules"),
            str(_ORIGINAL_ROOT / "node_modules"),
            str(ROOT / "backend" / "node_modules"),
            str(ROOT / "node_modules"),
        ]
        env["NODE_PATH"] = os.pathsep.join(node_paths)
        result = subprocess.run(
            [node_cmd, str(obfuscate_script), str(target_dir)],
            cwd=str(ROOT),
            env=env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=600,  # 10 min for ~200 files
        )
        print(result.stdout)
        if result.stderr:
            print(result.stderr, file=sys.stderr)
        if result.returncode != 0:
            print("  [WARN] JS obfuscation exited with errors", file=sys.stderr)
    except FileNotFoundError:
        print("  [WARN] node not found — skipping JS obfuscation", file=sys.stderr)
        return
    except subprocess.TimeoutExpired:
        print("  [WARN] JS obfuscation timed out", file=sys.stderr)

    # Obfuscate other JS directories
    for subdir in ("bin", "scripts"):
        sub = bundled_backend / subdir
        if sub.exists():
            _run_obfuscate(node_cmd, obfuscate_script, sub)

    # Top-level JS files (server.js etc.)
    _run_obfuscate(node_cmd, obfuscate_script, bundled_backend)


def _run_obfuscate(node_cmd: str, script: Path, target_dir: Path):
    """Run obfuscation script on a directory."""
    try:
        env = os.environ.copy()
        node_paths = [
            str(_ORIGINAL_ROOT / "backend" / "node_modules"),
            str(_ORIGINAL_ROOT / "node_modules"),
            str(ROOT / "backend" / "node_modules"),
            str(ROOT / "node_modules"),
        ]
        env["NODE_PATH"] = os.pathsep.join(node_paths)
        result = subprocess.run(
            [node_cmd, str(script), str(target_dir)],
            cwd=str(ROOT),
            env=env,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="replace",
            timeout=120,
        )
        if result.stdout.strip():
            print(f"  {result.stdout.strip()}")
    except Exception:
        pass


def _compile_python_to_pyc(package_dir: Path):
    """Compile .py files to .pyc and remove source for the khy_quant package.

    This makes the Python launcher code harder to read, though .pyc can be
    decompiled. The real protection is on the JS side.
    """
    # Compile all .py files in the package
    compileall.compile_dir(
        str(package_dir),
        force=True,
        quiet=1,
        optimize=2,  # Remove docstrings and assert statements
    )

    # Move .pyc files from __pycache__/ up to the package directory
    # and remove .py source (except __init__.py which pip needs)
    for pyc_dir in package_dir.rglob("__pycache__"):
        for pyc_file in pyc_dir.glob("*.pyc"):
            # __pycache__/foo.cpython-XY.opt-2.pyc → foo.pyc
            original_name = pyc_file.name.split(".")[0] + ".pyc"
            target = pyc_dir.parent / original_name
            shutil.copy2(str(pyc_file), str(target))

    # Remove .py source files (keep __init__.py for package discovery)
    for py_file in package_dir.glob("*.py"):
        if py_file.name == "__init__.py":
            continue
        pyc_counterpart = py_file.with_suffix(".pyc")
        if pyc_counterpart.exists():
            py_file.unlink()

    # Clean up __pycache__ directories
    for pyc_dir in package_dir.rglob("__pycache__"):
        shutil.rmtree(str(pyc_dir), ignore_errors=True)


class BuildWithBundle(build_py):
    """Copy backend/ and frontend/ into khy_quant/bundled/ before building,
    then obfuscate JS and compile Python."""

    def run(self):
        bundled = ROOT / "khy_quant" / "bundled"

        for name in ("backend", "frontend", "docs"):
            src = ROOT / name
            dst = bundled / name
            if src.exists() and not dst.exists():
                shutil.copytree(
                    src,
                    dst,
                    ignore=shutil.ignore_patterns(*EXCLUDE_PATTERNS),
                    dirs_exist_ok=False,
                )

                # Remove pruned directories that ignore_patterns may have missed
                for prune_dir in PRUNE_DIRS:
                    for match in dst.rglob(prune_dir):
                        if match.is_dir():
                            shutil.rmtree(match, ignore_errors=True)

        # ── Obfuscate JS files ────────────────────────────────────────
        bundled_backend = bundled / "backend"
        if bundled_backend.exists():
            print("\n  Obfuscating JavaScript files...")
            _obfuscate_js(bundled_backend)

        # ── Strip comments from Vue files ─────────────────────────────
        bundled_frontend = bundled / "frontend"
        if bundled_frontend.exists():
            print("  Processing frontend files...")
            _strip_vue_comments(bundled_frontend)

        # Ensure bundled dirs are included as package data
        self.package_data = self.package_data or {}
        self.package_data.setdefault("khy_quant", []).append("bundled/**/*")

        super().run()

        # ── Compile Python .pyc (after build_py copies files) ─────────
        # The build_lib is where setuptools stages the final package
        khy_quant_build = Path(self.build_lib) / "khy_quant"
        if khy_quant_build.exists():
            print("  Compiling Python to .pyc...")
            _compile_python_to_pyc(khy_quant_build)


def _strip_vue_comments(frontend_dir: Path):
    """Remove comments from Vue/JS/TS files to reduce readability."""
    count = 0
    for ext in ("*.vue", "*.js", "*.ts"):
        for f in frontend_dir.rglob(ext):
            try:
                content = f.read_text(encoding="utf-8")
                # Remove multi-line comments (/* ... */)
                import re
                cleaned = re.sub(r'/\*[\s\S]*?\*/', '', content)
                # Remove single-line comments (// ...) but not URLs (://)
                cleaned = re.sub(r'(?<!:)//(?!/).*$', '', cleaned, flags=re.MULTILINE)
                if cleaned != content:
                    f.write_text(cleaned, encoding="utf-8")
                    count += 1
            except Exception:
                pass
    if count > 0:
        print(f"  Stripped comments from {count} frontend files")


setup(
    cmdclass={"build_py": BuildWithBundle},
    package_data={"khy_quant": ["bundled/**/*"]},
)
