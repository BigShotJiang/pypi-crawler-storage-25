import { createRouter, createWebHistory } from 'vue-router'
import { useUserStore } from '@/stores/user'

const routes = [
  {
    path: '/login',
    name: 'Login',
    component: () => import('@/views/Login.vue'),
    meta: { requiresAuth: false }
  },
  {
    path: '/admin-login',
    name: 'AdminLogin',
    component: () => import('@/views/AdminLogin.vue'),
    meta: { requiresAuth: false }
  },
  {
    path: '/register',
    name: 'Register',
    component: () => import('@/views/Register.vue'),
    meta: { requiresAuth: false }
  },
  {
    path: '/forgot-password',
    name: 'ForgotPassword',
    component: () => import('@/views/ForgotPassword.vue'),
    meta: { requiresAuth: false }
  },
  {
    path: '/',
    component: () => import('@/views/Layout.vue'),
    redirect: '/dashboard',
    meta: { requiresAuth: true },
    children: [
      {
        path: 'dashboard',
        name: 'Dashboard',
        component: () => import('@/views/Dashboard.vue')
      },
      {
        path: 'market-quotes',
        name: 'MarketQuotes',
        component: () => import('@/views/MarketQuotes.vue')
      },
      {
        path: 'trading',
        name: 'Trading',
        component: () => import('@/views/Trading.vue')
      },
      {
        path: 'strategies',
        name: 'Strategies',
        component: () => import('@/views/Strategies.vue')
      },
      {
        path: 'backtest',
        name: 'Backtest',
        component: () => import('@/views/BacktestAnalysis.vue')
      },
      {
        path: 'backtest-analysis',
        name: 'BacktestAnalysis',
        component: () => import('@/views/BacktestAnalysis.vue')
      },
      {
        path: 'backtest-detail/:id',
        name: 'BacktestDetail',
        component: () => import('@/views/BacktestDetail.vue')
      },
      {
        path: 'trades',
        name: 'Trades',
        component: () => import('@/views/Trades.vue')
      },

      {
        path: 'announcements',
        name: 'Announcements',
        component: () => import('@/views/Announcements.vue')
      },
      {
        path: 'feedback',
        name: 'Feedback',
        component: () => import('@/views/Feedback.vue')
      },
      {
        path: 'profile',
        name: 'Profile',
        component: () => import('@/views/Profile.vue')
      },
      {
        path: 'api-keys',
        name: 'ApiKeyManage',
        component: () => import('@/views/ApiKeyManage.vue')
      },
      {
        path: 'about',
        name: 'About',
        component: () => import('@/views/About.vue'),
        meta: { requiresAdmin: true }
      },
      {
        path: 'debug',
        name: 'Debug',
        component: () => import('@/views/Debug.vue')
      },
      {
        path: 'data-sources',
        name: 'DataSources',
        component: () => import('@/views/DataSourceManagement-Multi.vue')
      }
    ]
  },
  {
    path: '/admin',
    component: () => import('@/views/AdminLayout.vue'),
    redirect: '/admin/dashboard',
    meta: { requiresAuth: true, requiresAdmin: true },
    children: [
      {
        path: 'dashboard',
        name: 'AdminDashboard',
        component: () => import('@/views/admin/Dashboard.vue')
      },
      { path: 'announcements', redirect: '/admin/dashboard' },
      { path: 'feedback', redirect: '/admin/dashboard' },
      { path: 'users', redirect: '/admin/dashboard' },
      { path: 'system', redirect: '/admin/dashboard' },
      { path: 'logs', redirect: '/admin/dashboard' }
    ]
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

// 路由守卫
router.beforeEach(async (to, from, next) => {
  const userStore = useUserStore()
  
  // 如果有token但没有用户信息，先获取用户信息
  if (userStore.token && !userStore.user) {
    try {
      await userStore.fetchUserInfo()
    } catch (error) {
      console.error('获取用户信息失败:', error)
      // 如果获取用户信息失败，清除token并跳转到登录页
      await userStore.logout({ skipRemote: true })
      if (to.meta.requiresAuth) {
        next('/login')
        return
      }
    }
  }
  
  if (to.meta.requiresAuth && !userStore.isAuthenticated()) {
    next('/login')
  } else if (to.meta.requiresAdmin && userStore.user?.role !== 'admin') {
    // 如果需要管理员权限但用户不是管理员
    next('/dashboard')
  } else if ((to.path === '/login' || to.path === '/register' || to.path === '/admin-login') && userStore.isAuthenticated()) {
    // 如果已登录用户访问登录页面，根据角色重定向
    if (userStore.user?.role === 'admin') {
      next('/admin/dashboard')
    } else {
      next('/dashboard')
    }
  } else {
    next()
  }
})

export default router
