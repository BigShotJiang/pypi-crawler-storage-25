// 开发环境专用配置
// 这个文件只在开发环境使用,不会被打包到生产构建中

/**
 * 获取API基础URL - 开发环境版本
 */
export function getApiBaseUrl() {
  return 'http://localhost:3000'
}

/**
 * 获取WebSocket URL - 开发环境版本
 */
export function getWsUrl() {
  return 'ws://localhost:3000'
}

export default {
  getApiBaseUrl,
  getWsUrl
}
