// API配置 - 统一管理API基础URL
import { getApiBaseUrl as getRuntimeApiBaseUrl } from '@/utils/connectionMode'

/**
 * 获取API基础URL
 * 开发环境: 使用相对路径 /api，由Vite代理转发到后端3000端口
 * 生产环境: 使用相对路径 /api
 */
export function getApiBaseUrl() {
  return getRuntimeApiBaseUrl()
}

/**
 * 获取WebSocket URL
 * 生产环境使用当前域名的 ws/wss 协议
 */
export function getWsUrl() {
  const { protocol, host } = window.location
  const wsProtocol = protocol === 'https:' ? 'wss:' : 'ws:'
  return `${wsProtocol}//${host}/ws`
}

// 默认导出 - 只导出函数，不导出常量（避免构建时内联）
export default {
  getApiBaseUrl,
  getWsUrl
}
