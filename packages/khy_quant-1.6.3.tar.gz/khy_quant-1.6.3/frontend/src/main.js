/**
 * KHY-Quant 量化交易系统 - 前端
 * Copyright (c) 2026 孔浩原 (Kong Haoyuan). All Rights Reserved.
 * 未经授权，禁止复制、修改或商业使用。
 */
import { createApp } from 'vue'
import { createPinia } from 'pinia'
import ElementPlus from 'element-plus'
import 'element-plus/dist/index.css'
import * as ElementPlusIconsVue from '@element-plus/icons-vue'
import zhCn from 'element-plus/dist/locale/zh-cn.mjs'

import App from './App.vue'
import router from './router'
import websocketService from './services/websocketService'
import { ElMessage } from 'element-plus'
import { getFriendlyErrorMessage } from './utils/errorMessage'
import { Capacitor } from '@capacitor/core'
import { SplashScreen } from '@capacitor/splash-screen'

// 生产环境移除调试日志，保留错误日志
if (import.meta.env.PROD) {
  console.log = () => {}
  console.info = () => {}
  console.debug = () => {}
}

// 屏蔽浏览器扩展噪声日志
const originalError = console.error
console.error = (...args) => {
  // 过滤掉 "Unchecked runtime.lastError" 错误
  const errorMessage = args[0]?.toString() || ''
  if (errorMessage.includes('runtime.lastError') || 
      errorMessage.includes('can not use with devtools') ||
      errorMessage.includes('ERR_CONNECTION_REFUSED') ||
      errorMessage.includes('WebSocket connection')) {
    return // 忽略这些错误
  }
  originalError.apply(console, args)
}

// 引入全局主题样式
import './styles/theme.css'
// 引入移动端响应式样式
import './styles/mobile.css'
// 引入移动端滚动优化样式
import './styles/mobile-scroll.css'
// Responsive breakpoint overrides
import './styles/responsive.css'

// 🔧 引入网络监控和请求拦截器 (暂时禁用,可能导致加载问题)
// import networkMonitor from './utils/networkMonitor'
// import { setupRequestInterceptor } from './utils/requestInterceptor'

const app = createApp(App)
const pinia = createPinia()

// 注册所有图标
for (const [key, component] of Object.entries(ElementPlusIconsVue)) {
  app.component(key, component)
}

app.use(pinia)
app.use(router)
app.use(ElementPlus, { locale: zhCn })

// 🔥 添加全局错误处理器
app.config.errorHandler = (err, instance, info) => {
  // 🔇 过滤 Element Plus 已知问题 (不影响功能)
  if (err && err.message && err.message.includes('getBoundingClientRect is not a function')) {
    // 这是 Element Plus 的已知问题,不影响核心功能,可以忽略
    // 如需修复,请升级 Element Plus 到最新版本
    return
  }
  
  // 捕获 "slice is not a function" 错误
  if (err && err.message && err.message.includes('slice is not a function')) {
    console.error('❌❌❌ [Global Error Handler] Caught "slice is not a function" error:')
    console.error('  消息:', err.message)
    console.error('  组件:', instance?.$options?.name || 'Unknown')
    console.error('  信息:', info)
    console.error('  堆栈:', err.stack)
    console.error('  时间:', new Date().toISOString())
    
    // 在开发模式下显示详细错误
    if (import.meta.env.DEV) {
      console.error('🔍 错误详情:', {
        error: err,
        component: instance,
        errorInfo: info
      })
    }
  } else {
    // 记录其他错误 - 显示详细信息
    const errorDetails = {
      type: err?.constructor?.name || 'Unknown',
      message: err?.message || String(err) || 'Unknown error',
      stack: err?.stack || 'No stack trace',
      componentName: instance?.$options?.name || 'Unknown',
      info: info,
      timestamp: new Date().toISOString()
    }
    
    console.error('❌ [Global Error Handler] Caught error:')
    console.error('  类型:', errorDetails.type)
    console.error('  消息:', errorDetails.message)
    console.error('  组件:', errorDetails.componentName)
    console.error('  信息:', errorDetails.info)
    console.error('  堆栈:', errorDetails.stack)
    
    // 在开发模式下显示完整错误对象
    if (import.meta.env.DEV) {
      console.error('🔍 完整错误对象:', err)
      console.error('🔍 错误详情:', JSON.stringify(errorDetails, null, 2))
    }
  }

  ElMessage.error(getFriendlyErrorMessage(err, '页面发生异常，请稍后重试'))
}

window.addEventListener('unhandledrejection', (event) => {
  const reason = event?.reason
  console.error('未处理的Promise异常:', reason)
  ElMessage.error(getFriendlyErrorMessage(reason, '请求异常，请稍后重试'))
})

window.addEventListener('error', (event) => {
  const err = event?.error || new Error(event?.message || '未知错误')
  console.error('全局运行时错误:', err)
})

// 🔥 添加全局警告处理器（开发模式）
if (import.meta.env.DEV) {
  app.config.warnHandler = (msg, instance, trace) => {
    if (msg.includes('slice') || msg.includes('array')) {
      console.warn('⚠️ [Global Warn Handler] Array-related warning:', {
        message: msg,
        componentName: instance?.$options?.name || 'Unknown',
        trace: trace
      })
    }
  }
}

// 全局提供WebSocket服务
app.provide('websocketService', websocketService)

// 🔧 设置请求拦截器(统一处理网络错误) - 暂时禁用
// setupRequestInterceptor()

// 🔧 启动网络监控(定期检查后端连接状态) - 暂时禁用
// 延迟5秒启动,避免应用初始化时的误报
// setTimeout(() => {
//   networkMonitor.startMonitoring()
//   console.log('✅ 网络监控已启动')
// }, 5000)

// 路由守卫：登录后自动连接WebSocket
router.afterEach((to, from) => {
  // 检查用户是否已登录
  const userStore = pinia._s.get('user')
  if (userStore && userStore.token && !websocketService.isConnected) {
    console.log('用户已登录，连接WebSocket...')
    websocketService.connect().catch(error => {
      console.error('WebSocket连接失败:', error)
    })
  }
})

app.mount('#app')

if (Capacitor.isNativePlatform()) {
  const hideNativeSplash = () => {
    SplashScreen.hide().catch(() => {})
  }

  window.addEventListener('khy-app-ready', hideNativeSplash, { once: true })
  // 兜底：避免异常导致原生启动页不消失
  setTimeout(hideNativeSplash, 8000)
}
