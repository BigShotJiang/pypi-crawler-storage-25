<template>
  <div class="dashboard">
    <!-- 欢迎横幅 -->
    <div class="welcome-banner">
      <div class="welcome-content">
        <h1 class="welcome-title">欢迎回来！</h1>
        <p class="welcome-subtitle">开始您的量化交易之旅</p>
      </div>
      
      <!-- 呼叫小K按钮 -->
      <button class="call-ai-btn" @click="callAIAssistant" title="呼叫小K智能助手">
        <div class="ai-icon-wrapper">
          <img src="/robot-avatar.jpg" alt="小K" class="ai-avatar" />
          <div class="ai-pulse"></div>
        </div>
        <span class="ai-text">呼叫小K</span>
      </button>
      
      <!-- 局域网访问信息 -->
      <div class="lan-access-info" v-if="lanIpAddress">
        <div class="lan-ip-label">
          <el-icon><Monitor /></el-icon>
          <span>其它设备可访问下面这个IP进行登录</span>
        </div>
        <div class="lan-ip-address" @click="copyLanUrl">
          <span class="ip-text">{{ lanAccessUrl }}</span>
          <el-icon class="copy-icon"><CopyDocument /></el-icon>
        </div>
        <div class="lan-qr-code" v-if="showQrCode">
          <canvas ref="qrCodeCanvas"></canvas>
        </div>
        <el-button 
          size="small" 
          text 
          @click="toggleQrCode"
          class="qr-toggle-btn"
        >
          <el-icon><Picture /></el-icon>
          {{ showQrCode ? '隐藏' : '显示' }}二维码
        </el-button>
      </div>
      
      <div class="welcome-actions">
        <el-button type="primary" size="large" @click="router.push('/strategies')">
          <el-icon><Plus /></el-icon>
          创建策略
        </el-button>
        <el-button size="large" @click="router.push('/trading')">
          <el-icon><TrendCharts /></el-icon>
          开始交易
        </el-button>
      </div>
    </div>

    <!-- 统计卡片 -->
    <div class="stats-grid" v-loading="loading">
      <div class="stat-card stat-card-primary hover-lift">
        <div class="stat-icon-wrapper gradient-bg-primary">
          <el-icon class="stat-icon-large"><Document /></el-icon>
        </div>
        <div class="stat-content">
          <div class="stat-value">{{ stats.strategies }}</div>
          <div class="stat-label">策略总数</div>
        </div>
        <div class="stat-trend" v-if="trends.strategies !== 0">
          <el-icon :class="trends.strategies > 0 ? 'text-up' : 'text-down'">
            <CaretTop v-if="trends.strategies > 0" />
            <CaretBottom v-else />
          </el-icon>
          <span :class="trends.strategies > 0 ? 'text-up' : 'text-down'">
            {{ Math.abs(trends.strategies) }}%
          </span>
        </div>
      </div>
      <div class="stat-card stat-card-success hover-lift">
        <div class="stat-icon-wrapper gradient-bg-success">
          <el-icon class="stat-icon-large"><DataAnalysis /></el-icon>
        </div>
        <div class="stat-content">
          <div class="stat-value">{{ stats.backtests }}</div>
          <div class="stat-label">回测次数</div>
        </div>
        <div class="stat-trend" v-if="trends.backtests !== 0">
          <el-icon :class="trends.backtests > 0 ? 'text-up' : 'text-down'">
            <CaretTop v-if="trends.backtests > 0" />
            <CaretBottom v-else />
          </el-icon>
          <span :class="trends.backtests > 0 ? 'text-up' : 'text-down'">
            {{ Math.abs(trends.backtests) }}%
          </span>
        </div>
      </div>
      <div class="stat-card stat-card-warning hover-lift">
        <div class="stat-icon-wrapper gradient-bg-warning">
          <el-icon class="stat-icon-large"><ShoppingCart /></el-icon>
        </div>
        <div class="stat-content">
          <div class="stat-value">{{ stats.trades }}</div>
          <div class="stat-label">交易记录</div>
        </div>
        <div class="stat-trend" v-if="trends.trades !== 0">
          <el-icon :class="trends.trades > 0 ? 'text-up' : 'text-down'">
            <CaretTop v-if="trends.trades > 0" />
            <CaretBottom v-else />
          </el-icon>
          <span :class="trends.trades > 0 ? 'text-up' : 'text-down'">
            {{ Math.abs(trends.trades) }}%
          </span>
        </div>
      </div>
    </div>
    
    <!-- 内容区域 -->
    <el-row :gutter="20" class="content-row">
      <!-- 市场行情 -->
      <el-col :xs="24" :sm="24" :md="24" class="market-quotes-col">
        <el-card class="content-card hover-lift" v-loading="quotesLoading">
          <template #header>
            <div class="card-header-custom">
              <div class="card-title-wrapper">
                <el-icon class="card-icon"><Histogram /></el-icon>
                <span class="card-title-text">实时行情</span>
                <el-button 
                  link 
                  type="primary" 
                  @click="showSearchDialog = true"
                  style="margin-left: 8px"
                >
                  <el-icon><Search /></el-icon>
                  搜索
                </el-button>
                <el-tag size="small" type="success" style="margin-left: 10px" v-if="currentCategory === 'all'">
                  共 {{ totalItems }} 个标的
                </el-tag>
                <el-tag size="small" type="success" style="margin-left: 10px" v-else>
                  {{ getCategoryName(currentCategory) }}: {{ totalItems }} 个
                </el-tag>
                <el-tag 
                  v-if="marketQuotes.length > 0 && marketQuotes[0].dataSource" 
                  size="small" 
                  :type="getDataSourceType(marketQuotes[0].dataSource)"
                  style="margin-left: 10px"
                >
                  {{ marketQuotes[0].dataSource }}
                </el-tag>
              </div>
              <div class="header-actions">
                <el-button 
                  link 
                  :type="currentCategory === 'favorite' ? 'success' : 'primary'" 
                  @click="switchCategory('favorite')"
                >
                  <el-icon><Star /></el-icon>
                  {{ currentCategory === 'favorite' ? '✓ 自选' : '自选' }}
                </el-button>
                <el-button 
                  link 
                  :type="currentCategory === 'all' ? 'success' : 'primary'" 
                  @click="switchCategory('all')"
                >
                  <el-icon><Grid /></el-icon>
                  {{ currentCategory === 'all' ? '✓ 所有' : '所有' }}
                </el-button>
                <el-button 
                  link 
                  :type="currentCategory === 'stock' ? 'success' : 'primary'" 
                  @click="switchCategory('stock')"
                >
                  <el-icon><List /></el-icon>
                  {{ currentCategory === 'stock' ? '✓ 股票' : '股票' }}
                </el-button>
                <el-button 
                  link 
                  :type="currentCategory === 'index' ? 'success' : 'primary'" 
                  @click="switchCategory('index')"
                >
                  <el-icon><TrendCharts /></el-icon>
                  {{ currentCategory === 'index' ? '✓ 指数' : '指数' }}
                </el-button>
                <el-button 
                  link 
                  :type="currentCategory === 'etf' ? 'success' : 'primary'" 
                  @click="switchCategory('etf')"
                >
                  <el-icon><Coin /></el-icon>
                  {{ currentCategory === 'etf' ? '✓ ETF' : 'ETF' }}
                </el-button>
                <el-button
                  link
                  :type="currentCategory === 'bond' ? 'success' : 'primary'"
                  @click="switchCategory('bond')"
                >
                  <el-icon><Document /></el-icon>
                  {{ currentCategory === 'bond' ? '✓ 可转债' : '可转债' }}
                </el-button>
                <el-button
                  link
                  :type="currentCategory === 'futures' ? 'success' : 'primary'"
                  @click="switchCategory('futures')"
                >
                  <el-icon><Histogram /></el-icon>
                  {{ currentCategory === 'futures' ? '✓ 期货' : '期货' }}
                </el-button>
                <el-button link type="primary" @click="loadMarketQuotes" :loading="quotesLoading">
                  <el-icon><Refresh /></el-icon>
                  刷新
                </el-button>
              </div>
            </div>
          </template>
          <div v-if="displayedQuotes.length === 0 && !quotesLoading" class="empty-state-quotes">
            <div class="empty-icon">
              <el-icon :size="80" color="#909399"><TrendCharts /></el-icon>
            </div>
            <div class="empty-title">暂无行情数据</div>
            <div class="empty-description">
              {{ currentCategory === 'favorite' ? '请先添加自选标的' : '正在加载行情数据...' }}
            </div>
            <div class="empty-actions" v-if="currentCategory === 'favorite'">
              <el-button size="large" @click="router.push('/trading')">
                <el-icon><View /></el-icon>
                前往交易页面
              </el-button>
            </div>
          </div>
          <div v-else-if="quotesLoading" class="empty-state-quotes">
            <div class="empty-icon">
              <el-icon :size="80" color="#409eff"><Loading /></el-icon>
            </div>
            <div class="empty-title">正在加载行情数据...</div>
            <div class="empty-description">请稍候</div>
          </div>
          <div v-else>
            <!-- 统一的行情列表显示 -->
            <div class="quotes-section">
              <div class="section-header">
                <el-icon v-if="currentCategory === 'all'"><Grid /></el-icon>
                <el-icon v-else-if="currentCategory === 'stock'"><List /></el-icon>
                <el-icon v-else-if="currentCategory === 'index'"><TrendCharts /></el-icon>
                <el-icon v-else-if="currentCategory === 'etf'"><Coin /></el-icon>
                <el-icon v-else-if="currentCategory === 'bond'"><Document /></el-icon>
                <span>{{ getCategoryName(currentCategory) }}</span>
                <el-tag size="small" type="success">共 {{ totalItems }} 个标的</el-tag>
                <el-tag size="small" type="info" v-if="totalItems > pageSize">第 {{ currentPage }} 页</el-tag>
              </div>
              <div class="quotes-list">
                <div 
                  v-for="quote in displayedQuotes" 
                  :key="quote.symbol" 
                  class="quote-item"
                  @click="viewQuoteDetail(quote)"
                >
                  <div class="quote-left">
                    <div class="quote-name">
                      {{ quote.name }}
                      <el-tag v-if="quote.isDemo" size="small" type="info" style="margin-left:4px;font-size:10px;">模拟</el-tag>
                    </div>
                    <div class="quote-code">{{ quote.symbol }}</div>
                  </div>
                  <div class="quote-right">
                    <div class="quote-price-info">
                      <div class="quote-price" :class="getChangeClass(quote.change)">
                        {{ quote.price.toFixed(quote.type === 'etf' ? 3 : 2) }}
                      </div>
                      <div class="quote-change" :class="getChangeClass(quote.change)">
                        {{ quote.change > 0 ? '+' : '' }}{{ quote.changePercent.toFixed(2) }}%
                      </div>
                    </div>
                    <el-button
                      :icon="isFavorite(quote.symbol) ? StarFilled : Star"
                      :type="isFavorite(quote.symbol) ? 'warning' : 'default'"
                      size="small"
                      circle
                      @click="toggleFavorite(quote.symbol, $event)"
                      class="favorite-btn"
                      :title="isFavorite(quote.symbol) ? '取消自选' : '加入自选标的'"
                    />
                  </div>
                </div>
              </div>
              <!-- 分页组件 -->
              <div v-if="totalItems > pageSize" class="pagination-wrapper">
                <el-pagination
                  v-model:current-page="currentPage"
                  :page-size="pageSize"
                  :total="totalItems"
                  layout="total, prev, pager, next"
                  @current-change="handlePageChange"
                />
              </div>
            </div>
          </div>
        </el-card>
      </el-col>
      
      <el-col :xs="24" :sm="24" :md="24">
        <el-card class="content-card hover-lift" v-loading="loading">
          <template #header>
            <div class="card-header-custom">
              <div class="card-title-wrapper">
                <el-icon class="card-icon"><TrendCharts /></el-icon>
                <span class="card-title-text">最近策略</span>
              </div>
              <el-button link type="primary" @click="router.push('/strategies')">
                查看全部
                <el-icon><ArrowRight /></el-icon>
              </el-button>
            </div>
          </template>
          <div v-if="recentStrategies.length === 0" class="empty-state">
            <div class="empty-state-custom">
              <img src="/empty-state.jpg" alt="暂无数据" class="empty-image" />
              <p class="empty-text">暂无策略数据</p>
              <el-button type="primary" @click="router.push('/strategies')">
                创建第一个策略
              </el-button>
            </div>
          </div>
          <el-table v-else :data="recentStrategies" style="width: 100%" :show-header="true">
            <el-table-column prop="name" label="策略名称" min-width="120">
              <template #default="scope">
                <div class="strategy-name">
                  <el-icon color="#409eff"><Document /></el-icon>
                  <span>{{ scope.row.name }}</span>
                </div>
              </template>
            </el-table-column>
            <el-table-column prop="type" label="类型" width="100">
              <template #default="scope">
                <el-tag size="small" type="info">{{ scope.row.type }}</el-tag>
              </template>
            </el-table-column>
            <el-table-column prop="status" label="状态" width="80">
              <template #default="scope">
                <el-tag 
                  size="small" 
                  :type="scope.row.status === 'active' ? 'success' : 'info'"
                >
                  {{ scope.row.status === 'active' ? '活跃' : '草稿' }}
                </el-tag>
              </template>
            </el-table-column>
            <el-table-column label="操作" width="80" align="center">
              <template #default="scope">
                <el-button link type="primary" size="small" @click="viewStrategy(scope.row)">
                  查看
                </el-button>
              </template>
            </el-table-column>
          </el-table>
        </el-card>
      </el-col>
    </el-row>

    <!-- 搜索对话框 -->
    <el-dialog
      v-model="showSearchDialog"
      title="搜索标的"
      width="600px"
      :close-on-click-modal="false"
    >
      <div class="search-dialog-content">
        <el-input
          v-model="searchKeyword"
          placeholder="输入股票代码或名称搜索..."
          clearable
          @input="handleSearch"
          size="large"
        >
          <template #prefix>
            <el-icon><Search /></el-icon>
          </template>
        </el-input>
        
        <div class="search-results" v-loading="searchLoading">
          <div v-if="searchResults.length === 0 && searchKeyword" class="empty-search">
            <div class="empty-state-custom">
              <img src="/empty-state.jpg" alt="暂无数据" class="empty-image" />
              <p class="empty-text">未找到匹配的标的</p>
            </div>
          </div>
          <div v-else-if="searchResults.length === 0" class="search-tips">
            <el-icon :size="48" color="#909399"><Search /></el-icon>
            <p>输入股票代码或名称开始搜索</p>
            <div class="search-examples">
              <span>例如: </span>
              <el-tag size="small" @click="searchKeyword = '贵州茅台'">贵州茅台</el-tag>
              <el-tag size="small" @click="searchKeyword = '600519'">600519</el-tag>
              <el-tag size="small" @click="searchKeyword = '沪深300'">沪深300</el-tag>
            </div>
          </div>
          <div v-else class="search-result-list">
            <div 
              v-for="item in searchResults" 
              :key="item.symbol"
              class="search-result-item"
              @click="handleSelectSearchResult(item)"
            >
              <div class="result-left">
                <div class="result-name">{{ item.name }}</div>
                <div class="result-code">{{ item.symbol }}</div>
              </div>
              <div class="result-right">
                <el-tag size="small" :type="item.type === 'index' ? 'primary' : 'success'">
                  {{ item.type === 'index' ? '指数' : item.type === 'stock' ? 'A股' : '期货' }}
                </el-tag>
                <el-button
                  :icon="isFavorite(item.symbol) ? StarFilled : Star"
                  :type="isFavorite(item.symbol) ? 'warning' : 'default'"
                  size="small"
                  circle
                  @click.stop="toggleFavorite(item.symbol, $event)"
                  :title="isFavorite(item.symbol) ? '取消自选' : '加入自选标的'"
                />
              </div>
            </div>
          </div>
        </div>
      </div>
    </el-dialog>
  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted, computed, nextTick } from 'vue'
import { useRouter } from 'vue-router'
import { ElMessage } from 'element-plus'
import { getApiBaseUrl } from '@/config/api'
import { 
  Plus, 
  TrendCharts, 
  Document, 
  DataAnalysis, 
  ShoppingCart,
  CaretTop,
  CaretBottom,
  Histogram,
  Refresh,
  ArrowRight,
  View,
  DataLine,
  List,
  Star,
  StarFilled,
  Search,
  Grid,
  Coin,
  Monitor,
  CopyDocument,
  Picture
} from '@element-plus/icons-vue'
import axios from 'axios'
import { getMarketQuotes } from '@/api/marketData'
import QRCode from 'qrcode'

const router = useRouter()

// 局域网访问相关
const lanIpAddress = ref('')
const showQrCode = ref(false)
const qrCodeCanvas = ref(null)

const lanAccessUrl = computed(() => {
  if (!lanIpAddress.value) return ''
  
  // 判断是否是域名（不是IP地址）
  const isDomain = !lanIpAddress.value.match(/^\d+\.\d+\.\d+\.\d+$/)
  
  // 如果是域名，使用标准HTTP端口（80），不显示端口号
  // 如果是IP地址，使用8080端口
  if (isDomain) {
    return `http://${lanIpAddress.value}`
  } else {
    return `http://${lanIpAddress.value}:8080`
  }
})

const stats = ref({
  strategies: 0,
  backtests: 0,
  trades: 0
})

const trends = ref({
  strategies: 0,
  backtests: 0,
  trades: 0
})

const recentStrategies = ref([])
const recentBacktests = ref([])
const marketQuotes = ref([])
const stockList = ref([])
const indexList = ref([])
const etfList = ref([])
const bondList = ref([])
const futuresList = ref([])
const currentCategory = ref('favorite') // 🔥 默认显示自选标的
const loading = ref(true)
const quotesLoading = ref(false)
const indexLoading = ref(false)
const stockLoading = ref(false)
const etfLoading = ref(false)
const bondLoading = ref(false)

// 分页相关
const currentPage = ref(1)
const pageSize = ref(20)
const totalItems = ref(0)
const favoriteStocks = ref(new Set()) // 自选标的集合
const showSearchDialog = ref(false) // 搜索对话框显示状态
const searchKeyword = ref('') // 搜索关键词
const searchResults = ref([]) // 搜索结果
const searchLoading = ref(false) // 搜索加载状态
let refreshTimer = null
let searchTimer = null // 搜索防抖定时器

// 计算属性:根据当前分类显示对应的标的列表
const displayedQuotes = computed(() => {
  let allData = []
  
  console.log('🔍 displayedQuotes 计算中...')
  console.log('  - currentCategory:', currentCategory.value)
  console.log('  - stockList.length:', stockList.value.length)
  console.log('  - indexList.length:', indexList.value.length)
  console.log('  - etfList.length:', etfList.value.length)
  console.log('  - bondList.length:', bondList.value.length)
  console.log('  - favoriteQuotesList.length:', favoriteQuotesList.value.length)
  
  if (currentCategory.value === 'favorite') {
    // 🔥 显示自选标的
    allData = favoriteQuotesList.value
    console.log('  ✅ 使用 favoriteQuotesList:', allData.length)
  } else if (currentCategory.value === 'all') {
    // 显示所有标的
    allData = [...stockList.value, ...indexList.value, ...etfList.value, ...bondList.value, ...futuresList.value]
    console.log('  ✅ 使用 all (合并所有列表):', allData.length)
  } else if (currentCategory.value === 'stock') {
    allData = stockList.value
    console.log('  ✅ 使用 stockList:', allData.length)
  } else if (currentCategory.value === 'index') {
    allData = indexList.value
    console.log('  ✅ 使用 indexList:', allData.length)
  } else if (currentCategory.value === 'etf') {
    allData = etfList.value
    console.log('  ✅ 使用 etfList:', allData.length)
  } else if (currentCategory.value === 'bond') {
    allData = bondList.value
    console.log('  ✅ 使用 bondList:', allData.length)
  } else if (currentCategory.value === 'futures') {
    allData = futuresList.value
    console.log('  ✅ 使用 futuresList:', allData.length)
  }
  
  // 更新总数
  totalItems.value = allData.length
  console.log('  - totalItems:', totalItems.value)
  
  // 分页处理
  const start = (currentPage.value - 1) * pageSize.value
  const end = start + pageSize.value
  console.log('  - 分页: start=', start, ', end=', end)
  
  const result = allData.slice(start, end)
  console.log('  ✅ 最终返回:', result.length, '个标的')
  
  return result
})

// 计算属性:自选标的列表
const favoriteQuotesList = computed(() => {
  // 合并所有标的列表
  const allQuotes = [
    ...marketQuotes.value,
    ...stockList.value,
    ...indexList.value,
    ...etfList.value,
    ...bondList.value
  ]
  
  // 去重并筛选自选标的
  const uniqueQuotes = Array.from(
    new Map(allQuotes.map(item => [item.symbol, item])).values()
  )
  
  return uniqueQuotes.filter(quote => favoriteStocks.value.has(quote.symbol))
})

// 加载主页数据
const loadDashboardData = async () => {
  try {
    loading.value = true
    const token = localStorage.getItem('token')
    
    if (!token) {
      ElMessage.error('请先登录')
      router.push('/login')
      return
    }

    const response = await axios.get('/api/dashboard/stats', {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    })

    if (response.data.success) {
      const data = response.data.data;
      
      console.log('📊 后端返回的数据:', {
        stats: data.stats,
        strategiesCount: data.recentStrategies?.length,
        backtestsCount: data.recentBacktests?.length,
        backtests: data.recentBacktests
      })
      
      // 更新统计数据
      stats.value = data.stats
      trends.value = data.trends
      
      // 更新最近策略
      recentStrategies.value = data.recentStrategies.map(s => ({
        id: s.id,
        name: s.name,
        type: getStrategyTypeLabel(s.type),
        status: s.status,
        language: s.language,
        updatedAt: formatDate(s.updatedAt)
      }))
      
      // 更新最近回测
      recentBacktests.value = data.recentBacktests.map(b => ({
        id: b.id,
        name: b.name,
        status: b.status,
        totalReturn: b.totalReturn,
        createdAt: formatDate(b.createdAt)
      }))
      
      console.log('✅ 主页数据加载成功:', {
        strategies: recentStrategies.value.length,
        backtests: recentBacktests.value.length,
        stats: stats.value
      })
    }
  } catch (error) {
    console.error('加载主页数据失败:', error)
    ElMessage.error(error.response?.data?.message || '加载数据失败')
  } finally {
    loading.value = false
  }
}

// 加载市场行情
const loadMarketQuotes = async () => {
  try {
    quotesLoading.value = true
    
    // 定义要获取行情的标的列表
    const symbols = [
      'sh000001', 'sh000300', 'sz399001', 'sz399006', // 指数
      'sh600519', 'sz000858', 'sh600036', 'sz000001', // 股票
      'sh600000', 'sh601318', 'sz000333', 'sz002594'
    ]
    
    // 并发获取所有标的的K线数据
    const promises = symbols.map(async (symbol) => {
      try {
        // 🔥 修复: 获取最近30天的历史数据,避免请求未来日期
        const endDate = new Date()
        endDate.setDate(endDate.getDate() - 1) // 结束日期设为昨天
        const startDate = new Date()
        startDate.setDate(startDate.getDate() - 30) // 开始日期设为30天前
        
        const response = await fetch(`${getApiBaseUrl()}/comprehensive-data/kline?symbol=${symbol}&startDate=${startDate.toISOString().split('T')[0]}&endDate=${endDate.toISOString().split('T')[0]}&period=daily`)
        
        if (response.ok) {
          const data = await response.json()
          if (data.kline && data.kline.length > 0) {
            const lastCandle = data.kline[data.kline.length - 1]
            const prevCandle = data.kline.length > 1 ? data.kline[data.kline.length - 2] : lastCandle
            
            const price = parseFloat(lastCandle.close)
            const prevClose = parseFloat(prevCandle.close)
            const change = price - prevClose
            const changePercent = (change / prevClose) * 100
            
            return {
              symbol: symbol,
              name: data.name || symbol,
              type: symbol.includes('000') || symbol.includes('399') ? 'index' : 'stock',
              category: symbol.includes('000') || symbol.includes('399') ? '指数' : 'A股',
              price: price,
              open: parseFloat(lastCandle.open),
              high: parseFloat(lastCandle.high),
              low: parseFloat(lastCandle.low),
              volume: parseInt(lastCandle.volume || 0),
              change: change,
              changePercent: changePercent,
              time: lastCandle.time,
              dataSource: data.source // 记录数据源
            }
          }
        }
        return null
      } catch (error) {
        console.warn(`获取 ${symbol} 数据失败:`, error.message)
        return null
      }
    })
    
    const results = await Promise.all(promises)
    const validResults = results.filter(r => r !== null)
    
    if (validResults.length > 0) {
      marketQuotes.value = validResults
      console.log(`✅ 使用真实数据源加载行情，共 ${validResults.length} 个标的`)
      console.log(`📊 数据源: ${validResults[0].dataSource}`)
      return
    }
    
    // 如果所有API都失败,使用模拟数据
    console.warn('⚠️ 所有API调用失败,使用模拟数据')
    
    // 如果API失败,使用模拟数据作为后备
    const mockQuotes = [
      { symbol: 'sh000001', name: '上证指数', basePrice: 3100, type: 'index' },
      { symbol: 'sh000300', name: '沪深300', basePrice: 3650, type: 'index' },
      { symbol: 'sz399001', name: '深证成指', basePrice: 10500, type: 'index' },
      { symbol: 'sz399006', name: '创业板指', basePrice: 2100, type: 'index' },
      { symbol: 'sh600519', name: '贵州茅台', basePrice: 1680, type: 'stock' },
      { symbol: 'sz000858', name: '五粮液', basePrice: 158, type: 'stock' },
      { symbol: 'sh600036', name: '招商银行', basePrice: 35, type: 'stock' },
      { symbol: 'sz000001', name: '平安银行', basePrice: 12.8, type: 'stock' },
      { symbol: 'sh600000', name: '浦发银行', basePrice: 8.5, type: 'stock' },
      { symbol: 'sh601318', name: '中国平安', basePrice: 45.6, type: 'stock' },
      { symbol: 'sz000333', name: '美的集团', basePrice: 58.9, type: 'stock' },
      { symbol: 'sz002594', name: '比亚迪', basePrice: 245.8, type: 'stock' }
    ]
    
    console.log('⚠️ 使用模拟数据')
    marketQuotes.value = mockQuotes.map(item => {
      const changePercent = (Math.random() - 0.5) * 6 // -3% 到 +3%
      const price = item.basePrice * (1 + changePercent / 100)
      const change = price - item.basePrice
      
      return {
        symbol: item.symbol,
        name: item.name,
        type: item.type,
        category: item.type === 'index' ? '指数' : 'A股',
        price: parseFloat(price.toFixed(2)),
        open: parseFloat((item.basePrice * (1 + (Math.random() - 0.5) * 0.02)).toFixed(2)),
        high: parseFloat((price * (1 + Math.random() * 0.02)).toFixed(2)),
        low: parseFloat((price * (1 - Math.random() * 0.02)).toFixed(2)),
        volume: Math.floor(Math.random() * 10000000) + 1000000,
        change: parseFloat(change.toFixed(2)),
        changePercent: parseFloat(changePercent.toFixed(2)),
        time: new Date().toISOString()
      }
    })
    
  } catch (error) {
    console.error('加载市场行情失败:', error)
  } finally {
    quotesLoading.value = false
  }
}

// 切换分类
const switchCategory = async (category) => {
  console.log('🔍 切换分类:', category)
  currentCategory.value = category
  currentPage.value = 1 // 重置到第一页
  
  // 根据分类自动加载对应数据
  if (category === 'favorite') {
    // 自选标的:重新加载行情数据
    console.log(`📊 显示自选标的: ${favoriteQuotesList.value.length} 个`)
    if (favoriteStocks.value.size > 0) {
      await loadFavoriteQuotesData()
    }
  } else if (category === 'all') {
    // 🔥 修复: 强制重新加载所有分类数据
    console.log('📊 加载所有分类数据...')
    await loadAllCategories()
  } else if (category === 'stock') {
    // 🔥 修复: 强制重新加载股票数据
    console.log('📊 加载股票数据...')
    await loadStockList()
    // 🔥 调试: 输出加载后的数据
    console.log(`✅ 股票数据加载完成: ${stockList.value.length} 个`)
    console.log(`📊 displayedQuotes 应该显示: ${displayedQuotes.value.length} 个`)
  } else if (category === 'index') {
    // 🔥 修复: 强制重新加载指数数据
    console.log('📊 加载指数数据...')
    await loadIndexList()
  } else if (category === 'etf') {
    // 🔥 修复: 强制重新加载ETF数据
    console.log('📊 加载ETF数据...')
    await loadETFList()
  } else if (category === 'bond') {
    // 🔥 修复: 强制重新加载可转债数据
    console.log('📊 加载可转债数据...')
    await loadBondList()
  } else if (category === 'futures') {
    console.log('📊 加载期货数据...')
    await loadFuturesList()
  }
}

// 分页切换
const handlePageChange = (page) => {
  currentPage.value = page
  console.log('📄 切换到第', page, '页')
}

// 三级数据降级策略:数据库 → 模拟数据
const loadDataWithFallback = async (type, mockDataFn) => {
  console.log(`📊 开始加载${type}数据,使用降级策略...`)
  
  try {
    // 第一级:尝试从数据库API获取
    console.log(`💾 第一级:尝试从数据库获取${type}数据...`)
    const response = await axios.get(`${getApiBaseUrl()}/instruments`, {
      params: {
        type: type,
        limit: 10000
      },
      timeout: 10000
    })
    
    if (response.data.success && response.data.data && response.data.data.instruments && response.data.data.instruments.length > 0) {
      console.log(`✅ 成功从数据库获取${type}数据:`, response.data.data.instruments.length, '条')
      
      // 转换数据格式并添加模拟价格
      const dataWithPrices = response.data.data.instruments.map(item => {
        const basePrice = type === 'etf' ? Math.random() * 3 + 0.5 : Math.random() * 150 + 80
        const changePercent = (Math.random() - 0.5) * 6
        const price = basePrice * (1 + changePercent / 100)
        
        return {
          symbol: item.symbol,
          name: item.name,
          type: type,
          category: type === 'etf' ? 'ETF' : type === 'bond' ? '可转债' : '未知',
          price: parseFloat(price.toFixed(type === 'etf' ? 3 : 2)),
          open: parseFloat((basePrice * (1 + (Math.random() - 0.5) * 0.02)).toFixed(type === 'etf' ? 3 : 2)),
          high: parseFloat((price * (1 + Math.random() * 0.02)).toFixed(type === 'etf' ? 3 : 2)),
          low: parseFloat((price * (1 - Math.random() * 0.02)).toFixed(type === 'etf' ? 3 : 2)),
          volume: Math.floor(Math.random() * 50000000) + 5000000,
          change: parseFloat((price - basePrice).toFixed(type === 'etf' ? 3 : 2)),
          changePercent: parseFloat(changePercent.toFixed(2)),
          time: new Date().toISOString(),
          dataSource: 'Database'
        }
      })
      
      return {
        success: true,
        data: dataWithPrices,
        source: 'database',
        message: `数据库 (${dataWithPrices.length}条)`
      }
    }
  } catch (error) {
    console.warn(`⚠️ 数据库获取${type}数据失败:`, error.message)
  }
  
  // 第二级:使用模拟数据
  console.log(`🎭 第二级:使用模拟${type}数据...`)
  const mockData = mockDataFn()
  console.log(`✅ 生成模拟${type}数据:`, mockData.length, '条')
  
  return {
    success: true,
    data: mockData,
    source: 'mock',
    message: `模拟数据 (${mockData.length}条)`
  }
}

// 获取分类名称
const getCategoryName = (category) => {
  const names = {
    'favorite': '自选标的',
    'all': '所有标的',
    'stock': 'A股市场',
    'index': '指数市场',
    'etf': 'ETF基金',
    'bond': '可转债',
    'futures': '期货市场'
  }
  return names[category] || '未知分类'
}

// 加载所有分类数据
const loadAllCategories = async () => {
  quotesLoading.value = true
  try {
    await Promise.all([
      stockList.value.length === 0 ? loadStockList() : Promise.resolve(),
      indexList.value.length === 0 ? loadIndexList() : Promise.resolve(),
      etfList.value.length === 0 ? loadETFList() : Promise.resolve(),
      bondList.value.length === 0 ? loadBondList() : Promise.resolve(),
      futuresList.value.length === 0 ? loadFuturesList() : Promise.resolve()
    ])
  } finally {
    quotesLoading.value = false
  }
}

// 加载指数列表 - 从数据库API加载
const loadIndexList = async () => {
  try {
    indexLoading.value = true
    console.log('📊 开始从数据库加载指数列表...')
    
    // 第一级: 从数据库API获取
    try {
      const response = await axios.get(`${getApiBaseUrl()}/instruments`, {
        params: { 
          type: 'index',
          limit: 10000  // 获取所有指数
        },
        timeout: 10000
      })
      
      if (response.data.success && response.data.data && response.data.data.instruments && response.data.data.instruments.length > 0) {
        console.log(`✅ 从数据库获取 ${response.data.data.instruments.length} 个指数`)
        
        // 转换数据格式并添加模拟价格
        indexList.value = response.data.data.instruments.map(item => {
          const basePrice = item.symbol === '000300' ? 4660 : 
                           item.symbol === '000001' ? 3100 :
                           item.symbol === '399001' ? 10500 :
                           item.symbol === '399006' ? 2100 : 3000
          const changePercent = (Math.random() - 0.5) * 4
          const price = basePrice * (1 + changePercent / 100)
          
          return {
            symbol: item.symbol,
            name: item.name,
            type: 'index',
            category: '指数',
            price: parseFloat(price.toFixed(2)),
            open: parseFloat((basePrice * (1 + (Math.random() - 0.5) * 0.01)).toFixed(2)),
            high: parseFloat((price * (1 + Math.random() * 0.02)).toFixed(2)),
            low: parseFloat((price * (1 - Math.random() * 0.02)).toFixed(2)),
            volume: Math.floor(Math.random() * 100000000) + 10000000,
            change: parseFloat((price - basePrice).toFixed(2)),
            changePercent: parseFloat(changePercent.toFixed(2)),
            time: new Date().toISOString(),
            dataSource: 'Database'
          }
        })
        
        ElMessage.success(`已加载 ${indexList.value.length} 个指数 (数据库)`)
        return
      }
    } catch (apiError) {
      console.warn('⚠️ 从数据库加载失败:', apiError.message)
    }
    
    // 第二级: 降级到模拟数据
    console.warn('⚠️ 数据库无数据,使用模拟数据')
    const mockData = [
      { symbol: '000300', name: '沪深300', basePrice: 4660 },
      { symbol: '000001', name: '上证指数', basePrice: 3100 },
      { symbol: '399001', name: '深证成指', basePrice: 10500 },
      { symbol: '399006', name: '创业板指', basePrice: 2100 }
    ]
    
    indexList.value = mockData.map(index => {
      const changePercent = (Math.random() - 0.5) * 4
      const price = index.basePrice * (1 + changePercent / 100)
      return {
        symbol: index.symbol,
        name: index.name,
        type: 'index',
        category: '指数',
        price: parseFloat(price.toFixed(2)),
        change: parseFloat((price - index.basePrice).toFixed(2)),
        changePercent: parseFloat(changePercent.toFixed(2)),
        volume: Math.floor(Math.random() * 100000000),
        dataSource: 'Mock'
      }
    })
    
    ElMessage.warning(`已加载 ${indexList.value.length} 个指数 (模拟数据)`)
    
  } catch (error) {
    console.error('加载指数列表失败:', error)
    ElMessage.error('加载指数列表失败')
  } finally {
    indexLoading.value = false
  }
}

// 加载股票列表 - 从数据库API加载
const loadStockList = async () => {
  try {
    stockLoading.value = true
    console.log('📊 开始从数据库加载股票列表...')
    
    // 第一级: 从数据库API获取
    try {
      const apiUrl = `${getApiBaseUrl()}/instruments`
      console.log('🔍 API URL:', apiUrl)
      console.log('🔍 请求参数:', { type: 'stock', limit: 10000 })
      
      const response = await axios.get(apiUrl, {
        params: { 
          type: 'stock',
          limit: 10000  // 获取所有股票
        },
        timeout: 10000
      })
      
      console.log('🔍 API响应:', response.data)
      
      if (response.data.success && response.data.data && response.data.data.instruments && response.data.data.instruments.length > 0) {
        console.log(`✅ 从数据库获取 ${response.data.data.instruments.length} 个股票`)
        
        // 转换数据格式并添加模拟价格
        stockList.value = response.data.data.instruments.map(item => {
          // 根据股票代码生成基础价格
          const basePrice = Math.random() * 200 + 10
          const changePercent = (Math.random() - 0.5) * 10
          const price = basePrice * (1 + changePercent / 100)
          
          return {
            symbol: item.symbol,
            name: item.name,
            type: 'stock',
            category: 'A股',
            price: parseFloat(price.toFixed(2)),
            open: parseFloat((basePrice * (1 + (Math.random() - 0.5) * 0.02)).toFixed(2)),
            high: parseFloat((price * (1 + Math.random() * 0.02)).toFixed(2)),
            low: parseFloat((price * (1 - Math.random() * 0.02)).toFixed(2)),
            volume: Math.floor(Math.random() * 10000000) + 1000000,
            change: parseFloat((price - basePrice).toFixed(2)),
            changePercent: parseFloat(changePercent.toFixed(2)),
            time: new Date().toISOString(),
            dataSource: 'Database'
          }
        })
        
        ElMessage.success(`已加载 ${stockList.value.length} 个股票 (数据库)`)
        return
      }
    } catch (apiError) {
      console.warn('⚠️ 从数据库加载失败:', apiError.message)
    }
    
    // 第二级: 降级到模拟数据
    console.warn('⚠️ 数据库无数据,使用模拟数据')
    const mockData = [
      { symbol: '600519', name: '贵州茅台', basePrice: 1680.0 },
      { symbol: '600036', name: '招商银行', basePrice: 35.2 },
      { symbol: '000858', name: '五粮液', basePrice: 158.5 },
      { symbol: '000333', name: '美的集团', basePrice: 58.9 }
    ]
    
    stockList.value = mockData.map(stock => {
      const changePercent = (Math.random() - 0.5) * 10
      const price = stock.basePrice * (1 + changePercent / 100)
      return {
        symbol: stock.symbol,
        name: stock.name,
        type: 'stock',
        category: 'A股',
        price: parseFloat(price.toFixed(2)),
        change: parseFloat((price - stock.basePrice).toFixed(2)),
        changePercent: parseFloat(changePercent.toFixed(2)),
        volume: Math.floor(Math.random() * 10000000),
        dataSource: 'Mock'
      }
    })
    
    ElMessage.warning(`已加载 ${stockList.value.length} 个股票 (模拟数据)`)
    
  } catch (error) {
    console.error('加载股票列表失败:', error)
    ElMessage.error('加载股票列表失败')
  } finally {
    stockLoading.value = false
  }
}

// 加载ETF列表 - 使用三级降级策略
const loadETFList = async () => {
  try {
    etfLoading.value = true
    console.log('📊 开始加载ETF列表...')
    
    // 生成模拟数据的函数
    const generateMockETFData = () => {
      const etfSymbols = [
        { symbol: '510300', name: '沪深300ETF', basePrice: 4.72 },
        { symbol: '510500', name: '中证500ETF', basePrice: 6.85 },
        { symbol: '159915', name: '创业板ETF', basePrice: 2.15 },
        { symbol: '512880', name: '证券ETF', basePrice: 0.85 },
        { symbol: '515050', name: '5GETF', basePrice: 1.25 },
        { symbol: '512690', name: '酒ETF', basePrice: 1.18 },
        { symbol: '512660', name: '军工ETF', basePrice: 1.05 },
        { symbol: '512480', name: '半导体ETF', basePrice: 1.35 },
        { symbol: '159928', name: '消费ETF', basePrice: 2.85 },
        { symbol: '512010', name: '医药ETF', basePrice: 1.65 },
        { symbol: '515030', name: '新能源车ETF', basePrice: 0.95 },
        { symbol: '516160', name: '新能源ETF', basePrice: 0.88 },
        { symbol: '159949', name: '创业板50', basePrice: 1.45 },
        { symbol: '510050', name: '上证50ETF', basePrice: 2.68 },
        { symbol: '588000', name: '科创50ETF', basePrice: 0.98 }
      ]
      
      return etfSymbols.map(etf => {
        const changePercent = (Math.random() - 0.5) * 6 // -3% 到 +3%
        const price = etf.basePrice * (1 + changePercent / 100)
        const change = price - etf.basePrice
        
        return {
          symbol: etf.symbol,
          name: etf.name,
          type: 'etf',
          category: 'ETF',
          price: parseFloat(price.toFixed(3)),
          open: parseFloat((etf.basePrice * (1 + (Math.random() - 0.5) * 0.02)).toFixed(3)),
          high: parseFloat((price * (1 + Math.random() * 0.02)).toFixed(3)),
          low: parseFloat((price * (1 - Math.random() * 0.02)).toFixed(3)),
          volume: Math.floor(Math.random() * 50000000) + 5000000,
          change: parseFloat(change.toFixed(3)),
          changePercent: parseFloat(changePercent.toFixed(2)),
          time: new Date().toISOString(),
          dataSource: 'Mock'
        }
      })
    }
    
    // 使用三级降级策略加载数据
    const result = await loadDataWithFallback('etf', generateMockETFData)
    
    etfList.value = result.data
    console.log(`✅ 成功加载 ${etfList.value.length} 个ETF [${result.source}]`)
    ElMessage.success(`已加载 ${etfList.value.length} 个ETF (${result.message})`)
    
  } catch (error) {
    console.error('加载ETF列表失败:', error)
    ElMessage.error('加载ETF列表失败')
  } finally {
    etfLoading.value = false
  }
}

// 加载可转债列表 - 使用三级降级策略
const loadBondList = async () => {
  try {
    bondLoading.value = true
    console.log('📊 开始加载可转债列表...')
    
    // 生成模拟数据的函数
    const generateMockBondData = () => {
      const bondSymbols = [
        { symbol: '113700', name: '海天转债', basePrice: 125.50 },
        { symbol: '118065', name: '艾为转债', basePrice: 118.80 },
        { symbol: '110100', name: '龙建转债', basePrice: 102.30 },
        { symbol: '127112', name: '尚太转债', basePrice: 115.60 },
        { symbol: '123265', name: '耐普转02', basePrice: 108.90 },
        { symbol: '128136', name: '立讯转债', basePrice: 132.50 },
        { symbol: '113050', name: '南银转债', basePrice: 110.20 },
        { symbol: '110061', name: '川投转债', basePrice: 105.80 },
        { symbol: '113616', name: '韦尔转债', basePrice: 128.30 },
        { symbol: '123107', name: '温氏转债', basePrice: 98.50 },
        { symbol: '127018', name: '本钢转债', basePrice: 112.60 },
        { symbol: '113044', name: '大秦转债', basePrice: 119.80 },
        { symbol: '110059', name: '浦发转债', basePrice: 106.50 },
        { symbol: '113021', name: '中信转债', basePrice: 114.20 },
        { symbol: '110053', name: '苏银转债', basePrice: 103.90 }
      ]
      
      return bondSymbols.map(bond => {
        const changePercent = (Math.random() - 0.5) * 4 // -2% 到 +2%
        const price = bond.basePrice * (1 + changePercent / 100)
        const change = price - bond.basePrice
        
        return {
          symbol: bond.symbol,
          name: bond.name,
          type: 'bond',
          category: '可转债',
          price: parseFloat(price.toFixed(2)),
          open: parseFloat((bond.basePrice * (1 + (Math.random() - 0.5) * 0.01)).toFixed(2)),
          high: parseFloat((price * (1 + Math.random() * 0.015)).toFixed(2)),
          low: parseFloat((price * (1 - Math.random() * 0.015)).toFixed(2)),
          volume: Math.floor(Math.random() * 5000000) + 500000,
          change: parseFloat(change.toFixed(2)),
          changePercent: parseFloat(changePercent.toFixed(2)),
          time: new Date().toISOString(),
          dataSource: 'Mock'
        }
      })
    }
    
    // 使用三级降级策略加载数据
    const result = await loadDataWithFallback('bond', generateMockBondData)
    
    bondList.value = result.data
    console.log(`✅ 成功加载 ${bondList.value.length} 个可转债 [${result.source}]`)
    ElMessage.success(`已加载 ${bondList.value.length} 个可转债 (${result.message})`)
    
  } catch (error) {
    console.error('加载可转债列表失败:', error)
    ElMessage.error('加载可转债列表失败')
  } finally {
    bondLoading.value = false
  }
}

// 加载期货列表 - 内置常见期货合约
const loadFuturesList = async () => {
  const commonFutures = [
    { symbol: 'rb_main', name: '螺纹钢主力', basePrice: 3380 },
    { symbol: 'hc_main', name: '热卷主力', basePrice: 3520 },
    { symbol: 'i_main', name: '铁矿石主力', basePrice: 780 },
    { symbol: 'j_main', name: '焦炭主力', basePrice: 2150 },
    { symbol: 'jm_main', name: '焦煤主力', basePrice: 1580 },
    { symbol: 'cu_main', name: '沪铜主力', basePrice: 69500 },
    { symbol: 'al_main', name: '沪铝主力', basePrice: 19800 },
    { symbol: 'zn_main', name: '沪锌主力', basePrice: 22500 },
    { symbol: 'au_main', name: '沪金主力', basePrice: 580 },
    { symbol: 'ag_main', name: '沪银主力', basePrice: 7200 },
    { symbol: 'IF_main', name: '沪深300股指', basePrice: 4660 },
    { symbol: 'IC_main', name: '中证500股指', basePrice: 6200 },
    { symbol: 'IH_main', name: '上证50股指', basePrice: 2750 },
    { symbol: 'IM_main', name: '中证1000股指', basePrice: 6800 },
    { symbol: 'sc_main', name: '原油主力', basePrice: 560 },
    { symbol: 'fu_main', name: '燃油主力', basePrice: 3100 },
    { symbol: 'MA_main', name: '甲醇主力', basePrice: 2650 },
    { symbol: 'TA_main', name: 'PTA主力', basePrice: 5800 },
    { symbol: 'SR_main', name: '白糖主力', basePrice: 6500 },
    { symbol: 'CF_main', name: '棉花主力', basePrice: 14500 },
    { symbol: 'a_main', name: '豆一主力', basePrice: 4800 },
    { symbol: 'm_main', name: '豆粕主力', basePrice: 3200 },
    { symbol: 'p_main', name: '棕榈油主力', basePrice: 7600 },
    { symbol: 'y_main', name: '豆油主力', basePrice: 7800 },
  ]

  futuresList.value = commonFutures.map(item => {
    const change = (Math.random() - 0.5) * (item.basePrice * 0.03)
    const price = item.basePrice + change
    return {
      symbol: item.symbol,
      name: item.name,
      price: parseFloat(price.toFixed(2)),
      change: parseFloat(change.toFixed(2)),
      changePercent: parseFloat((change / item.basePrice * 100).toFixed(2)),
      volume: Math.floor(Math.random() * 500000) + 50000,
      category: '期货',
      type: 'futures',
      isDemo: true
    }
  })
  console.log(`✅ 已加载 ${futuresList.value.length} 个期货合约`)
}


// 格式化日期
const formatDate = (dateString) => {
  if (!dateString) return '-'
  const date = new Date(dateString)
  return date.toLocaleDateString('zh-CN', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit'
  })
}

// 获取策略类型标签
const getStrategyTypeLabel = (type) => {
  const typeMap = {
    'trend': '趋势',
    'mean_reversion': '均值回归',
    'breakout': '突破',
    'custom': '自定义',
    'grid': '网格',
    'arbitrage': '套利'
  }
  return typeMap[type] || type || '自定义'
}

// 查看策略详情
const viewStrategy = (strategy) => {
  router.push(`/strategies?id=${strategy.id}`)
}

// 查看回测详情
const viewBacktest = (backtest) => {
  router.push(`/backtest-analysis?id=${backtest.id}`)
}

// 查看标的详情
const viewQuoteDetail = (quote) => {
  // 跳转到交易界面,并传递股票代码
  router.push(`/trading?symbol=${quote.symbol}`)
}

// 获取涨跌颜色类
const getChangeClass = (change) => {
  if (change > 0) return 'price-up'
  if (change < 0) return 'price-down'
  return 'price-neutral'
}

// 获取数据源标签类型
const getDataSourceType = (source) => {
  if (!source) return 'info'
  const sourceLower = source.toLowerCase()
  // 🔥 修复:正确判断真实数据源
  if (sourceLower.includes('adata') || sourceLower.includes('akshare') || 
      sourceLower.includes('database')) {
    return 'success' // 真实数据源用绿色
  }
  if (sourceLower.includes('模拟') || sourceLower.includes('mock')) {
    return 'warning' // 增强模拟数据用橙色
  }
  return 'info'
}

// 启动定时刷新
const startAutoRefresh = () => {
  // 每30秒刷新一次行情
  refreshTimer = setInterval(() => {
    loadMarketQuotes()
  }, 30000)
}

// 停止定时刷新
const stopAutoRefresh = () => {
  if (refreshTimer) {
    clearInterval(refreshTimer)
    refreshTimer = null
  }
}

// 切换自选标的状态
const toggleFavorite = async (symbol, event) => {
  event.stopPropagation() // 阻止事件冒泡,避免触发查看详情
  
  const isFav = favoriteStocks.value.has(symbol)
  
  if (isFav) {
    favoriteStocks.value.delete(symbol)
    ElMessage.success('已取消自选')
  } else {
    favoriteStocks.value.add(symbol)
    ElMessage.success('已加入自选标的')
  }
  
  // 保存到localStorage和数据库
  await saveFavoriteStocks()
}

// 检查是否为自选标的
const isFavorite = (symbol) => {
  return favoriteStocks.value.has(symbol)
}

// 呼叫AI助手
const callAIAssistant = () => {
  // 触发全局事件显示AI助手
  window.dispatchEvent(new Event('show-ai-assistant'))
  ElMessage.success('小K助手已唤出')
}

// 保存自选标的到localStorage和数据库
const saveFavoriteStocks = async () => {
  const favorites = Array.from(favoriteStocks.value)
  
  // 1. 保存到localStorage作为备份
  localStorage.setItem('favoriteStocks', JSON.stringify(favorites))
  
  // 如果没有自选标的,不需要保存到数据库
  if (favorites.length === 0) {
    console.log('⚠️ 没有自选标的,跳过保存')
    return
  }
  
  // 2. 保存到数据库
  try {
    const token = localStorage.getItem('token')
    if (!token) {
      console.warn('未登录,只保存到localStorage')
      return
    }
    
    // 需要将symbol转换为完整的对象格式
    // 从当前的标的列表中查找对应的信息
    const allQuotes = [
      ...marketQuotes.value,
      ...stockList.value,
      ...indexList.value,
      ...etfList.value,
      ...bondList.value
    ]
    
    // 如果标的列表还没加载,延迟保存
    if (allQuotes.length === 0) {
      console.warn('⚠️ 标的列表还未加载,延迟保存到数据库')
      // 等待1秒后重试
      setTimeout(() => saveFavoriteStocks(), 1000)
      return
    }
    
    const favoritesData = favorites.map(symbol => {
      // 查找对应的标的信息
      const quote = allQuotes.find(q => q.symbol === symbol)
      return {
        symbol: symbol,
        name: quote?.name || symbol,
        type: quote?.type || 'stock'
      }
    })
    
    // 再次检查,确保有数据
    if (favoritesData.length === 0) {
      console.warn('⚠️ 无法找到标的信息,只保存到localStorage')
      return
    }
    
    console.log('📤 准备发送到后端的数据:', {
      favorites: favoritesData,
      count: favoritesData.length
    })
    
    const response = await axios.post('/api/favorites/batch', {
      favorites: favoritesData  // 注意:后端期望的是favorites数组,不是symbols
    }, {
      headers: {
        'Authorization': `Bearer ${token}`
      }
    })
    
    if (response.data.success) {
      console.log('✅ 自选标的已保存到数据库:', response.data)
    }
  } catch (error) {
    console.error('保存自选标的到数据库失败:', error)
    console.error('错误详情:', error.response?.data)
    console.error('请求配置:', error.config)
    // 失败了也没关系,至少localStorage有备份
  }
}

// 从localStorage和数据库加载自选标的
const loadFavoriteStocks = async () => {
  try {
    const token = localStorage.getItem('token')
    
    if (token) {
      // 1. 优先从数据库加载
      try {
        const response = await axios.get('/api/favorites', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        })
        
        if (response.data.success && response.data.data) {
          const favorites = response.data.data.map(f => f.symbol)
          favoriteStocks.value = new Set(favorites)
          console.log(`✅ 从数据库加载 ${favorites.length} 个自选标的`)
          
          // 同步到localStorage
          localStorage.setItem('favoriteStocks', JSON.stringify(favorites))
          return
        }
      } catch (dbError) {
        console.warn('从数据库加载自选标的失败:', dbError.message)
      }
    }
    
    // 2. 降级到localStorage
    const saved = localStorage.getItem('favoriteStocks')
    if (saved) {
      const favorites = JSON.parse(saved)
      favoriteStocks.value = new Set(favorites)
      console.log(`⚠️ 从localStorage加载 ${favorites.length} 个自选标的`)
    }
  } catch (error) {
    console.error('加载自选标的失败:', error)
  }
}

// 🔥 新增: 加载自选标的的行情数据
const loadFavoriteQuotesData = async () => {
  if (favoriteStocks.value.size === 0) {
    console.log('⚠️ 没有自选标的,跳过加载行情')
    return
  }
  
  console.log(`📊 开始加载 ${favoriteStocks.value.size} 个自选标的的行情数据...`)
  quotesLoading.value = true
  
  try {
    // 获取自选标的的symbol列表
    const favoriteSymbols = Array.from(favoriteStocks.value)
    
    // 为每个自选标的加载行情数据(使用三级降级策略)
    const promises = favoriteSymbols.map(async (symbol) => {
      // 添加前缀(如果没有)
      const fullSymbol = symbol.match(/^(sh|sz)/) ? symbol : 
                        (symbol.startsWith('6') ? `sh${symbol}` : `sz${symbol}`)
      
      try {
        // 第一级: 尝试从真实API获取
        // 🔥 修复: 获取最近30天的历史数据,避免请求未来日期
        const endDate = new Date()
        endDate.setDate(endDate.getDate() - 1) // 结束日期设为昨天
        const startDate = new Date()
        startDate.setDate(startDate.getDate() - 30) // 开始日期设为30天前
        
        const response = await fetch(
          `${getApiBaseUrl()}/comprehensive-data/kline?symbol=${fullSymbol}&startDate=${startDate.toISOString().split('T')[0]}&endDate=${endDate.toISOString().split('T')[0]}&period=daily`,
          { timeout: 3000 }
        )
        
        if (response.ok) {
          const data = await response.json()
          if (data.kline && data.kline.length > 0) {
            const lastCandle = data.kline[data.kline.length - 1]
            const prevCandle = data.kline.length > 1 ? data.kline[data.kline.length - 2] : lastCandle
            
            const price = parseFloat(lastCandle.close)
            const prevClose = parseFloat(prevCandle.close)
            const change = price - prevClose
            const changePercent = (change / prevClose) * 100
            
            return {
              symbol: fullSymbol,
              name: data.name || symbol,
              type: fullSymbol.includes('000') || fullSymbol.includes('399') ? 'index' : 'stock',
              category: fullSymbol.includes('000') || fullSymbol.includes('399') ? '指数' : 'A股',
              price: price,
              open: parseFloat(lastCandle.open),
              high: parseFloat(lastCandle.high),
              low: parseFloat(lastCandle.low),
              volume: parseInt(lastCandle.volume || 0),
              change: change,
              changePercent: changePercent,
              time: lastCandle.time,
              dataSource: data.source || 'AData' // 🔥 修复:使用API返回的真实数据源
            }
          }
        }
      } catch (error) {
        console.warn(`获取 ${fullSymbol} 真实数据失败:`, error.message)
      }
      
      // 第二级: 尝试从缓存获取(这里可以添加缓存逻辑)
      // TODO: 实现缓存逻辑
      
      // 第三级: 使用模拟数据
      console.log(`⚠️ ${fullSymbol} 使用模拟数据`)
      const dashPriceMap = {
        'sh000300': 4660, '000300': 4660, 'sh000001': 3350, '000001': 3350,
        'sz399001': 10800, '399001': 10800, 'sz399006': 2100, '399006': 2100,
        'sh600519': 1680, '600519': 1680, 'sh600036': 38, '600036': 38,
        'sz000001': 11, 'sz000858': 148, 'sh600000': 7.8, 'sh601318': 52,
        'sz002594': 280, 'sz000002': 8.5,
        'rb_main': 3380, 'rb2510': 3380,
      }
      const cleanSym = fullSymbol.replace(/^(sh|sz)/i, '')
      const basePrice = dashPriceMap[fullSymbol] || dashPriceMap[cleanSym] || 50
      const changePercent = (Math.random() - 0.5) * 4
      const price = basePrice * (1 + changePercent / 100)
      const change = price - basePrice
      
      return {
        symbol: fullSymbol,
        name: symbol,
        type: fullSymbol.includes('000') || fullSymbol.includes('399') ? 'index' : 'stock',
        category: fullSymbol.includes('000') || fullSymbol.includes('399') ? '指数' : 'A股',
        price: parseFloat(price.toFixed(2)),
        open: parseFloat((basePrice * (1 + (Math.random() - 0.5) * 0.02)).toFixed(2)),
        high: parseFloat((price * (1 + Math.random() * 0.02)).toFixed(2)),
        low: parseFloat((price * (1 - Math.random() * 0.02)).toFixed(2)),
        volume: Math.floor(Math.random() * 10000000) + 1000000,
        change: parseFloat(change.toFixed(2)),
        changePercent: parseFloat(changePercent.toFixed(2)),
        time: new Date().toISOString(),
        dataSource: '增强模拟数据'
      }
    })
    
    const results = await Promise.all(promises)
    const validResults = results.filter(r => r !== null)
    
    // 更新marketQuotes(用于显示)
    marketQuotes.value = validResults
    
    // 同时更新到对应的分类列表
    validResults.forEach(quote => {
      if (quote.type === 'index') {
        const existingIndex = indexList.value.findIndex(i => i.symbol === quote.symbol)
        if (existingIndex >= 0) {
          indexList.value[existingIndex] = quote
        } else {
          indexList.value.push(quote)
        }
      } else if (quote.type === 'stock') {
        const existingStock = stockList.value.findIndex(s => s.symbol === quote.symbol)
        if (existingStock >= 0) {
          stockList.value[existingStock] = quote
        } else {
          stockList.value.push(quote)
        }
      }
    })
    
    console.log(`✅ 成功加载 ${validResults.length} 个自选标的行情`)
    const realDataCount = validResults.filter(r => r.dataSource !== '增强模拟数据' && r.dataSource !== '模拟数据' && r.dataSource !== 'Mock').length
    const mockDataCount = validResults.filter(r => r.dataSource === '增强模拟数据' || r.dataSource === '模拟数据' || r.dataSource === 'Mock').length
    console.log(`📊 数据来源: 真实数据 ${realDataCount} 个, 增强模拟数据 ${mockDataCount} 个`)
    
  } catch (error) {
    console.error('加载自选标的行情失败:', error)
    ElMessage.error('加载自选标的行情失败')
  } finally {
    quotesLoading.value = false
  }
}

// 搜索标的
const handleSearch = () => {
  // 清除之前的定时器
  if (searchTimer) {
    clearTimeout(searchTimer)
  }
  
  // 如果搜索关键词为空,清空结果
  if (!searchKeyword.value.trim()) {
    searchResults.value = []
    return
  }
  
  // 防抖处理,500ms后执行搜索
  searchTimer = setTimeout(() => {
    performSearch()
  }, 500)
}

// 执行搜索
const performSearch = () => {
  searchLoading.value = true
  
  try {
    const keyword = searchKeyword.value.trim().toLowerCase()
    
    // 合并所有标的列表进行搜索
    const allInstruments = [
      ...marketQuotes.value,
      ...stockList.value,
      ...indexList.value,
      ...etfList.value,
      ...bondList.value
    ]
    
    // 去重
    const uniqueInstruments = Array.from(
      new Map(allInstruments.map(item => [item.symbol, item])).values()
    )
    
    // 搜索匹配
    searchResults.value = uniqueInstruments.filter(item => {
      // 🔧 修复：检查 name 和 symbol 是否存在，避免 null 错误
      const name = item.name || ''
      const symbol = item.symbol || ''
      const nameMatch = name.toLowerCase().includes(keyword)
      const symbolMatch = symbol.toLowerCase().includes(keyword)
      const codeMatch = symbol.replace(/[a-z]/gi, '').includes(keyword) // 只匹配数字部分
      
      return nameMatch || symbolMatch || codeMatch
    }).slice(0, 20) // 限制最多显示20个结果
    
    console.log(`🔍 搜索 "${keyword}" 找到 ${searchResults.value.length} 个结果`)
  } catch (error) {
    console.error('搜索失败:', error)
    ElMessage.error('搜索失败')
  } finally {
    searchLoading.value = false
  }
}

// 选择搜索结果
const handleSelectSearchResult = (item) => {
  console.log('选择搜索结果:', item)
  
  // 关闭搜索对话框
  showSearchDialog.value = false
  
  // 跳转到交易界面
  viewQuoteDetail(item)
  
  // 清空搜索
  searchKeyword.value = ''
  searchResults.value = []
}

// 获取局域网IP地址
const getLanIpAddress = async () => {
  try {
    // 🔥 优先判断：如果当前是通过域名访问，直接使用域名
    const currentHostname = window.location.hostname
    const currentPort = window.location.port || (window.location.protocol === 'https:' ? '443' : '80')
    
    // 如果是通过域名访问（不是IP地址），直接使用域名
    if (currentHostname && 
        !currentHostname.match(/^\d+\.\d+\.\d+\.\d+$/) && // 不是IP地址
        currentHostname !== 'localhost') {
      lanIpAddress.value = currentHostname
      console.log('✅ 使用当前访问域名:', currentHostname)
      return
    }
    
    // 方法1: 通过后端API获取（最可靠）- 仅用于局域网访问
    try {
      const response = await axios.get('/api/system/network-info')
      if (response.data && response.data.data && response.data.data.lanIp) {
        lanIpAddress.value = response.data.data.lanIp
        console.log('✅ 从后端获取局域网IP:', lanIpAddress.value)
        
        // 如果后端返回了所有候选IP，打印出来供调试
        if (response.data.data.allCandidates) {
          console.log('📋 所有候选IP:', response.data.data.allCandidates)
        }
        return
      }
    } catch (apiError) {
      console.log('⚠️ 后端API获取IP失败，尝试前端方法')
    }
    
    // 方法2: 通过WebRTC获取本地IP（备选）
    const pc = new RTCPeerConnection({ iceServers: [] })
    pc.createDataChannel('')
    
    pc.createOffer().then(offer => pc.setLocalDescription(offer))
    
    const candidateIps = []
    
    pc.onicecandidate = (ice) => {
      if (!ice || !ice.candidate || !ice.candidate.candidate) return
      
      const ipRegex = /([0-9]{1,3}(\.[0-9]{1,3}){3})/
      const match = ipRegex.exec(ice.candidate.candidate)
      
      if (match && match[1]) {
        const ip = match[1]
        
        // 过滤掉无效IP
        if (ip === '127.0.0.1' || ip.startsWith('169.254')) {
          return
        }
        
        // 优先级判断
        let priority = 99
        if (ip.startsWith('192.168')) {
          priority = 1  // 最高优先级
        } else if (ip.startsWith('10.')) {
          priority = 2
        } else if (ip.startsWith('172.')) {
          const secondOctet = parseInt(ip.split('.')[1])
          if (secondOctet >= 16 && secondOctet <= 31) {
            priority = 3  // 172.16-31是私有IP，但优先级较低
          }
        }
        
        candidateIps.push({ ip, priority })
        console.log('🔍 WebRTC检测到IP:', ip, '优先级:', priority)
      }
    }
    
    // 超时处理：选择最优IP
    setTimeout(() => {
      if (!lanIpAddress.value && candidateIps.length > 0) {
        // 按优先级排序
        candidateIps.sort((a, b) => a.priority - b.priority)
        lanIpAddress.value = candidateIps[0].ip
        console.log('✅ 通过WebRTC选择局域网IP:', lanIpAddress.value)
        console.log('📋 所有候选IP:', candidateIps.map(c => `${c.ip} (优先级${c.priority})`).join(', '))
      }
      
      // 方法3: 使用window.location.hostname作为最后备选
      if (!lanIpAddress.value) {
        const hostname = window.location.hostname
        if (hostname !== 'localhost' && hostname !== '127.0.0.1') {
          lanIpAddress.value = hostname
          console.log('✅ 使用hostname作为IP:', hostname)
        }
      }
      
      pc.close()
    }, 2000)
    
  } catch (error) {
    console.error('❌ 获取局域网IP失败:', error)
  }
}

// 复制局域网访问地址
const copyLanUrl = async () => {
  try {
    await navigator.clipboard.writeText(lanAccessUrl.value)
    ElMessage.success('已复制局域网访问地址')
  } catch (error) {
    // 备用方案：使用传统方法复制
    const textarea = document.createElement('textarea')
    textarea.value = lanAccessUrl.value
    textarea.style.position = 'fixed'
    textarea.style.opacity = '0'
    document.body.appendChild(textarea)
    textarea.select()
    document.execCommand('copy')
    document.body.removeChild(textarea)
    ElMessage.success('已复制局域网访问地址')
  }
}

// 切换二维码显示
const toggleQrCode = async () => {
  showQrCode.value = !showQrCode.value
  
  if (showQrCode.value) {
    await nextTick()
    generateQrCode()
  }
}

// 生成二维码
const generateQrCode = async () => {
  if (!qrCodeCanvas.value || !lanAccessUrl.value) return
  
  try {
    await QRCode.toCanvas(qrCodeCanvas.value, lanAccessUrl.value, {
      width: 200,
      margin: 1,
      color: {
        dark: '#000000',
        light: '#ffffff'
      }
    })
    console.log('✅ 二维码生成成功')
  } catch (error) {
    console.error('❌ 二维码生成失败:', error)
    ElMessage.error('二维码生成失败')
  }
}

onMounted(async () => {
  // 🔥 步骤0: 获取局域网IP
  await getLanIpAddress()
  
  // 🔥 步骤1: 加载自选标的列表
  await loadFavoriteStocks()
  
  // 🔥 步骤2: 加载Dashboard统计数据
  loadDashboardData()
  
  // 🔥 步骤3: 自动加载自选标的的行情数据
  console.log('📊 自动加载自选标的行情数据...')
  await loadFavoriteQuotesData()
  
  // 🔥 步骤4: 切换到自选标的分类显示
  currentCategory.value = 'favorite'
  
  // 🔥 步骤5: 启动定时刷新
  startAutoRefresh()
})

onUnmounted(() => {
  stopAutoRefresh()
  
  // 清除搜索定时器
  if (searchTimer) {
    clearTimeout(searchTimer)
  }
})
</script>

<style scoped>
.dashboard {
  padding: 0;
}

/* Welcome banner: fluid, capped height */
.welcome-banner {
  background: url('/dashboard-bg.jpg') center/cover no-repeat;
  border-radius: var(--radius-xl);
  padding: var(--content-padding) var(--spacing-xl);
  margin-bottom: var(--card-gap);
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: var(--card-gap);
  box-shadow: var(--shadow-lg);
  color: white;
  position: relative;
  overflow: visible;
  width: 100%;
  min-height: 140px;
  flex-wrap: wrap;
}

.welcome-banner::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: linear-gradient(135deg, rgba(102, 126, 234, 0.4) 0%, rgba(118, 75, 162, 0.4) 100%);
  z-index: 1;
  border-radius: inherit;
}

.welcome-content {
  flex: 1;
  position: relative;
  z-index: 2;
}

.welcome-title {
  font-size: 32px;
  font-weight: 700;
  margin: 0 0 var(--spacing-sm) 0;
  color: white;
  text-shadow: 2px 2px 4px rgba(0, 0, 0, 0.3);
}

.welcome-subtitle {
  font-size: 16px;
  margin: 0;
  opacity: 0.95;
  text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.3);
}

.welcome-actions {
  display: flex;
  gap: var(--spacing-md);
  position: relative;
  z-index: 2;
}

.welcome-actions :deep(.el-button) {
  height: 44px;
  padding: 0 var(--spacing-lg);
  font-size: 16px;
  border-radius: var(--radius-md);
}

.welcome-actions :deep(.el-button--primary) {
  background: white;
  color: #667eea;
  border: none;
}

.welcome-actions :deep(.el-button--primary:hover) {
  background: rgba(255, 255, 255, 0.9);
  transform: translateY(-2px);
}

/* 局域网访问信息 */
.lan-access-info {
  position: relative;
  z-index: 2;
  background: rgba(255, 255, 255, 0.15);
  backdrop-filter: blur(10px);
  border-radius: var(--radius-md);
  padding: 16px;
  border: 1px solid rgba(255, 255, 255, 0.3);
  display: flex;
  flex-direction: column;
  gap: var(--spacing-sm);
  min-width: 280px;
  overflow: visible;
}

.lan-ip-label {
  display: flex;
  align-items: center;
  gap: var(--spacing-xs);
  font-size: 13px;
  opacity: 0.9;
  font-weight: 500;
}

.lan-ip-address {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--spacing-sm);
  background: rgba(255, 255, 255, 0.2);
  padding: var(--spacing-sm) var(--spacing-md);
  border-radius: var(--radius-sm);
  cursor: pointer;
  transition: all 0.3s ease;
  font-family: 'Consolas', 'Monaco', monospace;
  font-size: 14px;
  font-weight: 600;
}

.lan-ip-address:hover {
  background: rgba(255, 255, 255, 0.3);
  transform: translateY(-1px);
}

.lan-ip-address .ip-text {
  flex: 1;
  user-select: all;
}

.lan-ip-address .copy-icon {
  opacity: 0.7;
  transition: opacity 0.3s ease;
}

.lan-ip-address:hover .copy-icon {
  opacity: 1;
}

.lan-qr-code {
  display: flex;
  justify-content: center;
  align-items: center;
  padding: 14px;
  background: white;
  border-radius: var(--radius-sm);
  margin-top: var(--spacing-xs);
  overflow: visible;
  min-height: 212px;
}

.lan-qr-code canvas {
  display: block;
  width: 200px;
  height: 200px;
  max-width: 100%;
  min-height: 200px;
  border-radius: var(--radius-xs);
}

.qr-toggle-btn {
  color: white !important;
  opacity: 0.9;
}

.qr-toggle-btn:hover {
  opacity: 1;
  background: rgba(255, 255, 255, 0.1) !important;
}

/* 呼叫小K按钮 */
.call-ai-btn {
  position: absolute;
  right: 32px;
  top: 50%;
  transform: translateY(-50%);
  display: flex;
  align-items: center;
  gap: 12px;
  padding: 12px 24px;
  background: linear-gradient(135deg, #1a1a1a 0%, #2d2d2d 100%);
  border: 3px solid #FFD700;
  border-radius: 50px;
  color: #FFD700;
  font-size: 16px;
  font-weight: 600;
  cursor: pointer;
  transition: all 0.3s cubic-bezier(0.4, 0, 0.2, 1);
  box-shadow: 0 4px 16px rgba(255, 215, 0, 0.3);
  z-index: 10;
}

.call-ai-btn:hover {
  transform: translateY(-50%) scale(1.05);
  box-shadow: 0 8px 24px rgba(255, 215, 0, 0.5);
  border-color: #FFA500;
  color: #FFA500;
}

.call-ai-btn:active {
  transform: translateY(-50%) scale(0.98);
}

.ai-icon-wrapper {
  position: relative;
  width: 40px;
  height: 40px;
  flex-shrink: 0;
}

.ai-avatar {
  width: 100%;
  height: 100%;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid #FFD700;
}

.ai-pulse {
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  border-radius: 50%;
  border: 2px solid #FFD700;
  animation: ai-pulse 2s ease-out infinite;
}

@keyframes ai-pulse {
  0% {
    transform: scale(1);
    opacity: 1;
  }
  100% {
    transform: scale(1.5);
    opacity: 0;
  }
}

.ai-text {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, sans-serif;
  letter-spacing: 0.5px;
}

/* 响应式:移动端调整按钮位置 */
@media (max-width: 768px) {
  .call-ai-btn {
    right: 16px;
    padding: 10px 16px;
    font-size: 14px;
  }
  
  .ai-icon-wrapper {
    width: 32px;
    height: 32px;
  }
  
  .ai-text {
    display: none;
  }
}

.welcome-actions :deep(.el-button--primary:hover) {
  background: rgba(255, 255, 255, 0.9);
  transform: translateY(-2px);
  box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
}

.welcome-actions :deep(.el-button--default) {
  background: rgba(255, 255, 255, 0.2);
  color: white;
  border: 1px solid rgba(255, 255, 255, 0.3);
  backdrop-filter: blur(10px);
}

.welcome-actions :deep(.el-button--default:hover) {
  background: rgba(255, 255, 255, 0.3);
  transform: translateY(-2px);
}

/* Stats grid: fluid auto-fit */
.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: var(--card-gap);
  margin-bottom: var(--card-gap);
}

/* 统计卡片 */
.stat-card {
  background: white;
  border-radius: var(--radius-lg);
  padding: var(--spacing-lg);
  box-shadow: var(--shadow-sm);
  transition: all var(--transition-base);
  position: relative;
  overflow: hidden;
  border: 1px solid var(--border-light);
}

.stat-card::before {
  content: '';
  position: absolute;
  top: 0;
  left: 0;
  right: 0;
  height: 4px;
  background: linear-gradient(90deg, var(--primary-color), var(--primary-light));
}

.stat-card-primary::before {
  background: linear-gradient(90deg, #409eff, #66b1ff);
}

.stat-card-success::before {
  background: linear-gradient(90deg, #67c23a, #85ce61);
}

.stat-card-warning::before {
  background: linear-gradient(90deg, #e6a23c, #ebb563);
}

.stat-card-danger::before {
  background: linear-gradient(90deg, #f56c6c, #f78989);
}

.stat-icon-wrapper {
  width: 56px;
  height: 56px;
  border-radius: var(--radius-lg);
  display: flex;
  align-items: center;
  justify-content: center;
  margin-bottom: var(--spacing-md);
  box-shadow: var(--shadow-md);
}

.stat-icon-large {
  font-size: 28px;
  color: white;
}

.stat-content {
  margin-bottom: var(--spacing-sm);
}

.stat-value {
  font-size: 36px;
  font-weight: 700;
  color: var(--text-primary);
  line-height: 1;
  margin-bottom: var(--spacing-xs);
}

.stat-label {
  font-size: 14px;
  color: var(--text-secondary);
  font-weight: 500;
}

.stat-trend {
  display: flex;
  align-items: center;
  gap: 4px;
  font-size: 14px;
  font-weight: 600;
}

/* Content row */
.content-row {
  margin-top: var(--card-gap);
}

/* 内容卡片 */
.content-card {
  border-radius: var(--radius-lg);
  box-shadow: var(--shadow-sm);
  border: 1px solid var(--border-light);
  transition: all var(--transition-base);
}

.content-card :deep(.el-card__header) {
  background: linear-gradient(135deg, var(--bg-secondary) 0%, var(--bg-tertiary) 100%);
  border-bottom: 2px solid var(--border-light);
  padding: var(--spacing-md) var(--spacing-lg);
}

.card-header-custom {
  display: flex;
  justify-content: space-between;
  align-items: center;
}

.card-title-wrapper {
  display: flex;
  align-items: center;
  gap: var(--spacing-sm);
}

.card-icon {
  font-size: 20px;
  color: var(--primary-color);
}

.card-title-text {
  font-size: 16px;
  font-weight: 600;
  color: var(--text-primary);
}

/* 策略名称 */
.strategy-name {
  display: flex;
  align-items: center;
  gap: var(--spacing-sm);
}

/* 表格优化 */
.content-card :deep(.el-table) {
  font-size: 14px;
}

.content-card :deep(.el-table th) {
  background: var(--bg-secondary);
  color: var(--text-secondary);
  font-weight: 600;
}

.content-card :deep(.el-table td) {
  padding: 12px 0;
}

.content-card :deep(.el-table__row:hover) {
  background: var(--bg-secondary);
}

/* 响应式 */
@media (max-width: 768px) {
  .welcome-banner {
    flex-direction: column;
    text-align: center;
    padding: var(--spacing-xl) var(--spacing-lg);
  }
  
  .welcome-title {
    font-size: 24px;
  }
  
  .welcome-actions {
    margin-top: var(--spacing-lg);
    width: 100%;
    flex-direction: column;
  }
  
  .welcome-actions :deep(.el-button) {
    width: 100%;
  }
  
  /* 移动端局域网访问信息 */
  .lan-access-info {
    width: 100%;
    min-width: auto;
    order: 2; /* 放在中间位置 */
  }
  
  .lan-ip-address {
    font-size: 13px;
  }
  
  .lan-qr-code canvas {
    width: 160px !important;
    height: 160px !important;
    min-height: 160px !important;
  }
  
  .stat-value {
    font-size: 28px;
  }
  
  .content-row {
    margin-top: var(--spacing-lg);
  }
  
  .quote-item {
    padding: var(--spacing-sm) var(--spacing-md);
  }
  
  .quote-name {
    font-size: 14px;
  }
  
  .quote-price {
    font-size: 16px;
  }
}

@media (max-width: 480px) {
  .quote-price {
    font-size: 15px;
  }
  
  .quote-change {
    font-size: 12px;
  }
}

/* 搜索对话框样式 */
.search-dialog-content {
  padding: var(--spacing-md) 0;
}

.search-dialog-content .el-input {
  margin-bottom: var(--spacing-lg);
}

.search-results {
  min-height: 300px;
  max-height: 500px;
  overflow-y: auto;
}

.empty-search {
  display: flex;
  justify-content: center;
  align-items: center;
  min-height: 300px;
}

.search-tips {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  min-height: 300px;
  color: var(--text-secondary);
}

.search-tips p {
  margin: var(--spacing-md) 0;
  font-size: 16px;
}

.search-examples {
  display: flex;
  align-items: center;
  gap: var(--spacing-sm);
  margin-top: var(--spacing-md);
}

.search-examples .el-tag {
  cursor: pointer;
  transition: all var(--transition-base);
}

.search-examples .el-tag:hover {
  transform: translateY(-2px);
  box-shadow: var(--shadow-sm);
}

.search-result-list {
  display: flex;
  flex-direction: column;
  gap: var(--spacing-sm);
}

.search-result-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: var(--spacing-md);
  background: var(--bg-secondary);
  border-radius: var(--radius-md);
  cursor: pointer;
  transition: all var(--transition-base);
  border: 1px solid var(--border-light);
}

.search-result-item:hover {
  background: var(--bg-tertiary);
  transform: translateX(4px);
  box-shadow: var(--shadow-sm);
  border-color: var(--primary-color);
}

.result-left {
  flex: 1;
}

.result-name {
  font-size: 16px;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: 4px;
}

.result-code {
  font-size: 13px;
  color: var(--text-secondary);
  font-family: 'Courier New', monospace;
}

.result-right {
  display: flex;
  align-items: center;
  gap: var(--spacing-sm);
}

/* 市场行情列表 */
.market-quotes-col {
  margin-bottom: var(--spacing-xl);
}

.header-actions {
  display: flex;
  gap: var(--spacing-sm);
  align-items: center;
}

/* 行情列表样式 - 简洁版 */
.quotes-list {
  padding: 0;
}

.quote-item {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: var(--spacing-md) var(--spacing-lg);
  border-bottom: 1px solid var(--border-light);
  cursor: pointer;
  transition: all var(--transition-base);
}

.quote-item:hover {
  background: var(--bg-secondary);
}

.quote-item:last-child {
  border-bottom: none;
}

.quote-left {
  flex: 1;
  display: flex;
  flex-direction: column;
  gap: 4px;
}

.quote-name {
  font-size: 15px;
  font-weight: 600;
  color: var(--text-primary);
}

.quote-code {
  font-size: 12px;
  color: var(--text-tertiary);
}

.quote-right {
  display: flex;
  align-items: center;
  gap: var(--spacing-md);
}

.quote-price-info {
  display: flex;
  flex-direction: column;
  align-items: flex-end;
  gap: 4px;
}

.quote-price {
  font-size: 18px;
  font-weight: 700;
  line-height: 1;
}

.quote-change {
  font-size: 13px;
  font-weight: 600;
}

.favorite-btn {
  flex-shrink: 0;
  transition: all var(--transition-base);
}

.favorite-btn:hover {
  transform: scale(1.1);
}

.favorite-btn :deep(.el-icon) {
  font-size: 16px;
}

.price-up {
  color: #f56c6c;
}

.price-down {
  color: #67c23a;
}

.price-neutral {
  color: var(--text-primary);
}

/* 空状态样式 */
.empty-state {
  padding: var(--spacing-xl) 0;
  text-align: center;
}

.empty-state :deep(.el-empty__description) {
  color: var(--text-secondary);
  font-size: 14px;
}

.empty-state :deep(.el-button) {
  margin-top: var(--spacing-md);
}

/* 自定义空状态样式 */
.empty-state-custom {
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  padding: 40px 20px;
}

.empty-image {
  width: 200px;
  height: auto;
  max-width: 100%;
  border-radius: 8px;
  margin-bottom: 20px;
  opacity: 0.9;
}

.empty-text {
  font-size: 16px;
  color: #909399;
  margin-bottom: 20px;
  font-weight: 500;
}

/* 行情空状态样式 */
.empty-state-quotes {
  padding: var(--spacing-3xl) var(--spacing-xl);
  text-align: center;
  background: linear-gradient(135deg, #f5f7fa 0%, #e8eef5 100%);
  border-radius: var(--radius-lg);
  margin: var(--spacing-md);
}

.empty-icon {
  margin-bottom: var(--spacing-lg);
  opacity: 0.6;
}

.empty-title {
  font-size: 20px;
  font-weight: 600;
  color: var(--text-primary);
  margin-bottom: var(--spacing-sm);
}

.empty-description {
  font-size: 14px;
  color: var(--text-secondary);
  margin-bottom: var(--spacing-xl);
}

.empty-actions {
  display: flex;
  gap: var(--spacing-md);
  justify-content: center;
  flex-wrap: wrap;
}

.empty-actions :deep(.el-button) {
  min-width: 140px;
  height: 44px;
  font-size: 15px;
  border-radius: var(--radius-md);
}

.empty-actions :deep(.el-button--primary) {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border: none;
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
}

.empty-actions :deep(.el-button--primary:hover) {
  transform: translateY(-2px);
  box-shadow: 0 6px 16px rgba(102, 126, 234, 0.5);
}

.empty-actions :deep(.el-button--default) {
  background: white;
  border: 1px solid var(--border-base);
}

.empty-actions :deep(.el-button--default:hover) {
  border-color: var(--primary-color);
  color: var(--primary-color);
  transform: translateY(-2px);
}

/* 加载状态优化 */
:deep(.el-loading-mask) {
  background-color: rgba(255, 255, 255, 0.8);
  backdrop-filter: blur(2px);
}

/* 自选标的区域样式 */
.favorite-section {
  background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%);
  border-radius: var(--radius-lg);
  padding: var(--spacing-lg);
  margin-top: var(--spacing-md);
  box-shadow: 0 4px 12px rgba(245, 87, 108, 0.15);
}

.favorite-section .section-header {
  display: flex;
  align-items: center;
  gap: var(--spacing-sm);
  margin-bottom: var(--spacing-md);
  color: white;
  font-size: 18px;
  font-weight: 600;
}

.favorite-section .section-header .el-icon {
  font-size: 24px;
}

.favorite-section .empty-favorites {
  background: rgba(255, 255, 255, 0.95);
  border-radius: var(--radius-md);
  padding: var(--spacing-xl);
  text-align: center;
}

.favorite-section .quotes-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: var(--spacing-md);
}

.favorite-section .quote-item {
  background: rgba(255, 255, 255, 0.95);
  padding: var(--spacing-md);
  border-radius: var(--radius-md);
  cursor: pointer;
  transition: all var(--transition-base);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.favorite-section .quote-item:hover {
  transform: translateY(-4px);
  box-shadow: 0 6px 20px rgba(245, 87, 108, 0.25);
  background: white;
}

/* 指数区域样式 */
.index-section {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  border-radius: var(--radius-lg);
  padding: var(--spacing-lg);
  margin-top: var(--spacing-md);
  box-shadow: 0 4px 12px rgba(102, 126, 234, 0.15);
}

.index-section .section-header {
  display: flex;
  align-items: center;
  gap: var(--spacing-sm);
  margin-bottom: var(--spacing-md);
  color: white;
  font-size: 18px;
  font-weight: 600;
}

.index-section .section-header .el-icon {
  font-size: 24px;
}

.index-section .quotes-list {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: var(--spacing-md);
}

.index-section .quote-item {
  background: rgba(255, 255, 255, 0.95);
  padding: var(--spacing-md);
  border-radius: var(--radius-md);
  cursor: pointer;
  transition: all var(--transition-base);
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
}

.index-section .quote-item:hover {
  transform: translateY(-4px);
  box-shadow: 0 6px 20px rgba(102, 126, 234, 0.25);
  background: white;
}

/* A股区域样式 */
.a-stock-section {
  margin-top: var(--spacing-md);
}

.section-header {
  display: flex;
  align-items: center;
  gap: var(--spacing-sm);
  padding: var(--spacing-md) var(--spacing-lg);
  background: linear-gradient(135deg, #f5f7fa 0%, #e8eef5 100%);
  border-radius: var(--radius-md);
  margin-bottom: var(--spacing-md);
  font-size: 16px;
  font-weight: 600;
  color: var(--text-primary);
}

.section-header .el-icon {
  font-size: 20px;
  color: var(--primary-color);
}

/* 分页样式 */
.pagination-wrapper {
  display: flex;
  justify-content: center;
  padding: var(--spacing-lg) 0;
  margin-top: var(--spacing-md);
  border-top: 1px solid var(--border-color);
}

.pagination-wrapper :deep(.el-pagination) {
  font-weight: 500;
}

.pagination-wrapper :deep(.el-pager li) {
  min-width: 32px;
  height: 32px;
  line-height: 32px;
  border-radius: var(--radius-sm);
}

.pagination-wrapper :deep(.el-pager li.is-active) {
  background: var(--primary-color);
  color: white;
}

</style>
