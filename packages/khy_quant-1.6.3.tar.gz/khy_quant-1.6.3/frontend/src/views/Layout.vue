<template>
  <!-- 全局小K助手（移动端和桌面端都可用） -->
  <TradingAgentsBot />

  <!-- 移动端布局 -->
  <MobileLayout v-if="isMobileDevice">
    <router-view />
  </MobileLayout>
  
  <!-- 桌面端布局 -->
  <el-container v-else class="layout-container">
    <!-- 顶部导航栏 -->
    <el-header class="top-header" :class="{ 'is-collapsed': isHeaderCollapsed }">
      <div class="header-content">
        <!-- 左侧Logo和标题 -->
        <div class="header-left">
          <div class="logo-section">
            <img src="/logo.png" alt="KHY量化交易系统" class="logo-image" />
          </div>
          
          <!-- 顶部导航菜单 -->
          <el-menu
            :default-active="activeMenu"
            mode="horizontal"
            router
            background-color="transparent"
            text-color="#fff"
            active-text-color="#409eff"
            class="top-menu"
          >
            <el-menu-item index="/dashboard">
              <el-icon><Odometer /></el-icon>
              <span>主页</span>
            </el-menu-item>
            <el-menu-item index="/trading">
              <el-icon><TrendCharts /></el-icon>
              <span>智能交易</span>
            </el-menu-item>
            <el-menu-item index="/strategies">
              <el-icon><Document /></el-icon>
              <span>策略管理</span>
            </el-menu-item>
            <el-menu-item index="/backtest">
              <el-icon><DataAnalysis /></el-icon>
              <span>回测分析</span>
            </el-menu-item>
            <el-menu-item index="/trades">
              <el-icon><ShoppingCart /></el-icon>
              <span>交易记录</span>
            </el-menu-item>
            <el-menu-item index="/data-sources">
              <el-icon><DataBoard /></el-icon>
              <span>数据源</span>
            </el-menu-item>
            <el-menu-item index="/announcements">
              <el-icon><Bell /></el-icon>
              <span>通知公告</span>
            </el-menu-item>
            <el-menu-item index="/feedback">
              <el-icon><ChatDotRound /></el-icon>
              <span>意见反馈</span>
            </el-menu-item>
            <el-menu-item index="/profile">
              <img src="/school-badge.svg" alt="个人中心" class="menu-badge-icon" />
              <span>个人中心</span>
            </el-menu-item>
            <el-menu-item index="/api-keys">
              <el-icon><Key /></el-icon>
              <span>API Key</span>
            </el-menu-item>
            <el-menu-item v-if="isAdmin" index="/about">
              <el-icon><InfoFilled /></el-icon>
              <span>关于</span>
            </el-menu-item>
          </el-menu>
        </div>
        
        <!-- 右侧用户信息 -->
        <div class="header-actions">
          <!-- 管理员入口 -->
          <div v-if="isAdmin" class="admin-entrance">
            <el-button 
              type="primary" 
              size="small" 
              @click="goToAdmin"
              class="admin-btn"
            >
              <el-icon><Setting /></el-icon>
              管理后台
            </el-button>
          </div>
          
          <el-dropdown @command="handleCommand">
            <span class="user-info">
              <img src="/school-badge.svg" alt="用户" class="user-badge" />
              {{ userStore.user?.username }}
              <el-icon><ArrowDown /></el-icon>
            </span>
            <template #dropdown>
              <el-dropdown-menu>
                <el-dropdown-item command="profile">个人中心</el-dropdown-item>
                <el-dropdown-item command="api-keys">API Key 管理</el-dropdown-item>
                <el-dropdown-item v-if="isAdmin" command="admin" divided>
                  <el-icon><Setting /></el-icon>
                  管理后台
                </el-dropdown-item>
                <el-dropdown-item command="logout" divided>退出登录</el-dropdown-item>
              </el-dropdown-menu>
            </template>
          </el-dropdown>
        </div>
      </div>
    </el-header>
    
    <!-- 顶部导航栏收缩按钮 -->
    <div class="header-toggle-btn" @click="toggleHeader">
      <el-icon>
        <ArrowDownBold v-if="isHeaderCollapsed" />
        <ArrowUpBold v-else />
      </el-icon>
    </div>
    
    <!-- 主内容区 -->
    <div class="main-content" :class="{ 'header-collapsed': isHeaderCollapsed }">
      <router-view />
    </div>
  </el-container>
</template>

<script setup>
import { ref, computed, onMounted, onUnmounted } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useUserStore } from '@/stores/user'
import { ElMessage } from 'element-plus'
import TradingAgentsBot from '@/components/TradingAgentsBotSimple.vue'
import MobileLayout from '@/components/MobileLayout.vue'
import { isMobile } from '@/utils/device'
import {
  Bell,
  User,
  ArrowDown,
  Odometer,
  TrendCharts,
  Document,
  DataAnalysis,
  ShoppingCart,
  ChatDotRound,
  InfoFilled,
  Setting,
  DataBoard,
  ArrowDownBold,
  ArrowUpBold,
  Key
} from '@element-plus/icons-vue'

const route = useRoute()
const router = useRouter()
const userStore = useUserStore()

// 设备检测
const isMobileDevice = ref(false)

// 检测设备类型
const checkDevice = () => {
  isMobileDevice.value = isMobile()
  console.log('📱 设备检测:', isMobileDevice.value ? '移动端' : '桌面端')
}

// 顶部导航栏收缩状态
const isHeaderCollapsed = ref(false)

const activeMenu = computed(() => route.path)

// 判断是否为管理员
const isAdmin = computed(() => {
  return userStore.user?.role === 'admin'
})

// 切换顶部导航栏
const toggleHeader = () => {
  isHeaderCollapsed.value = !isHeaderCollapsed.value
}

const handleCommand = (command) => {
  if (command === 'logout') {
    userStore.logout()
    ElMessage.success('已退出登录')
    router.push('/login')
  } else if (command === 'profile') {
    router.push('/profile')
  } else if (command === 'api-keys') {
    router.push('/api-keys')
  } else if (command === 'admin') {
    goToAdmin()
  }
}

const goToAdmin = () => {
  if (userStore.user?.role === 'admin') {
    router.push('/admin/dashboard')
    ElMessage.success('正在跳转到管理后台')
  } else {
    ElMessage.error('权限不足，无法访问管理后台')
  }
}

// 生命周期
onMounted(() => {
  checkDevice()
  window.addEventListener('resize', checkDevice)
  window.addEventListener('orientationchange', checkDevice)
})

onUnmounted(() => {
  window.removeEventListener('resize', checkDevice)
  window.removeEventListener('orientationchange', checkDevice)
})
</script>

<style scoped>
.layout-container {
  height: 100vh;
  display: flex;
  flex-direction: column;
}

/* 顶部导航栏 */
.top-header {
  background: linear-gradient(135deg, #304156 0%, #1f2d3d 100%);
  border-bottom: 2px solid #409eff;
  padding: 0;
  height: 42px;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 1000;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
  transition: all 0.3s ease;
}

.top-header.is-collapsed {
  transform: translateY(-42px);
}

/* 顶部导航栏收缩按钮 */
.header-toggle-btn {
  position: fixed;
  top: 42px;
  left: 50%;
  transform: translateX(-50%);
  width: 50px;
  height: 20px;
  background: linear-gradient(135deg, #304156 0%, #1f2d3d 100%);
  border: 1px solid #409eff;
  border-top: none;
  border-radius: 0 0 10px 10px;
  display: flex;
  align-items: center;
  justify-content: center;
  cursor: pointer;
  z-index: 998;
  transition: all 0.3s ease;
  box-shadow: 0 2px 8px rgba(0, 0, 0, 0.15);
}

.top-header.is-collapsed + .header-toggle-btn {
  top: 0;
  z-index: 1001;
}

.header-toggle-btn:hover {
  background: linear-gradient(135deg, #409eff 0%, #2d7dd2 100%);
  height: 24px;
}

.header-toggle-btn .el-icon {
  color: #fff;
  font-size: 14px;
  transition: color 0.3s;
}

.header-toggle-btn:hover .el-icon {
  color: #fff;
}

.header-content {
  display: flex;
  justify-content: space-between;
  align-items: center;
  height: 100%;
  padding: 0 20px;
}

.header-left {
  display: flex;
  align-items: center;
  gap: 30px;
  flex: 1;
}

.logo-section {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 5px 0;
}

.logo-image {
  height: 32px;
  max-height: 32px;
  width: auto;
  max-width: 180px; /* 🔥 限制最大宽度，防止logo过宽 */
  object-fit: contain; /* 🔥 保持logo完整，不裁剪 */
  object-position: left center; /* 🔥 左对齐 */
  cursor: pointer;
  transition: transform 0.3s ease;
  display: block;
}

.logo-image:hover {
  transform: scale(1.05);
}

/* 顶部菜单 */
.top-menu {
  border-bottom: none;
  background: transparent;
  flex: 1;
}

.top-menu .el-menu-item {
  color: rgba(255, 255, 255, 0.8);
  border-bottom: 2px solid transparent;
  height: 42px;
  line-height: 42px;
  padding: 0 12px;
  display: flex;
  align-items: center;
  gap: 5px;
}

.top-menu .el-menu-item:hover {
  background-color: rgba(255, 255, 255, 0.1);
  color: #fff;
}

.top-menu .el-menu-item.is-active {
  background-color: rgba(64, 158, 255, 0.2);
  color: #409eff;
  border-bottom-color: #409eff;
}

.top-menu .el-menu-item .el-icon {
  font-size: 16px;
}

.top-menu .el-menu-item span {
  font-size: 13px;
}

.menu-badge-icon {
  width: 16px;
  height: 16px;
  object-fit: contain;
  vertical-align: middle;
}

/* 右侧操作区 */
.header-actions {
  display: flex;
  align-items: center;
  gap: 15px;
}

.admin-entrance {
  display: flex;
  align-items: center;
}

.admin-btn {
  background: linear-gradient(135deg, #ff6b6b, #ee5a24);
  border: none;
  border-radius: 20px;
  padding: 8px 16px;
  font-size: 12px;
  font-weight: 600;
  box-shadow: 0 2px 8px rgba(255, 107, 107, 0.3);
  transition: all 0.3s ease;
}

.admin-btn:hover {
  background: linear-gradient(135deg, #ee5a24, #ff6b6b);
  transform: translateY(-1px);
  box-shadow: 0 4px 12px rgba(255, 107, 107, 0.4);
}

.admin-btn:active {
  transform: translateY(0);
}

.user-info {
  display: flex;
  align-items: center;
  gap: 8px;
  cursor: pointer;
  color: #fff;
  padding: 8px 12px;
  border-radius: 4px;
  transition: all 0.3s;
}

.user-info:hover {
  background-color: rgba(255, 255, 255, 0.1);
}

.user-badge {
  width: 28px;
  height: 28px;
  border-radius: 50%;
  object-fit: cover;
  border: 2px solid rgba(255, 255, 255, 0.3);
  transition: all 0.3s ease;
}

.user-info:hover .user-badge {
  border-color: rgba(255, 255, 255, 0.6);
  transform: scale(1.05);
}

/* 主内容区 */
.main-content {
  background-color: #f5f7fa;
  padding: 0;
  margin-top: 42px;
  height: calc(100vh - 42px);
  overflow: auto;
  position: relative;
  transition: all 0.3s ease;
  z-index: 1;
}

.main-content.header-collapsed {
  margin-top: 0;
  height: 100vh;
}

/* Content area: fluid padding, full-width */
.main-content > :not(.professional-trading) {
  padding: var(--content-padding);
  min-height: 100%;
  width: 100%;
}

/* 响应式 - 移动端 */
@media (max-width: 1200px) {
  .top-menu .el-menu-item span {
    display: none;
  }
  
  .top-menu .el-menu-item {
    padding: 0 8px;
  }
  
  .logo-image {
    height: 28px;
    max-height: 28px;
    max-width: 140px; /* 🔥 中等屏幕限制宽度 */
  }
}

@media (max-width: 768px) {
  .header-left {
    gap: 8px;
  }

  .logo-image {
    height: 26px;
    max-height: 26px;
    max-width: 100px;
  }

  .main-content > :not(.professional-trading) {
    padding: var(--content-padding);
  }

  .top-menu {
    overflow-x: auto;
    overflow-y: hidden;
  }

  .top-menu::-webkit-scrollbar {
    height: 3px;
  }

  .top-menu::-webkit-scrollbar-thumb {
    background-color: rgba(255, 255, 255, 0.3);
    border-radius: 2px;
  }
}
</style>
