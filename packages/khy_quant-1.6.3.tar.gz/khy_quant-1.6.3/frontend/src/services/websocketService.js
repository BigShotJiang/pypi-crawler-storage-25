import { ElMessage, ElNotification } from 'element-plus'
import { useUserStore } from '@/stores/user'

class WebSocketService {
  constructor() {
    this.ws = null
    this.reconnectAttempts = 0
    this.maxReconnectAttempts = 12
    this.baseReconnectInterval = 1000
    this.maxReconnectInterval = 30000
    this.isConnected = false
    this.isAuthenticated = false
    this.messageHandlers = new Map()
    this.heartbeatInterval = null
    this.heartbeatTimer = 30000 // 30秒心跳
  }

  /**
   * 连接WebSocket
   */
  connect() {
    // 在生产环境中禁用WebSocket（如果没有配置WebSocket服务器）
    if (import.meta.env.PROD && !import.meta.env.VITE_WS_ENABLED) {
      console.log('WebSocket在生产环境中已禁用')
      return Promise.resolve()
    }

    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      console.log('WebSocket已连接')
      return Promise.resolve()
    }

    return new Promise((resolve, reject) => {
      try {
        const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:'
        const host = window.location.hostname
        const port = '3000' // 后端端口
        const wsUrl = `${protocol}//${host}:${port}`
        
        console.log('连接WebSocket:', wsUrl)
        this.ws = new WebSocket(wsUrl)

        this.ws.onopen = () => {
          console.log('WebSocket连接成功')
          this.isConnected = true
          this.reconnectAttempts = 0
          this.startHeartbeat()
          
          // 自动认证
          this.authenticate().then(() => {
            resolve()
          }).catch(reject)
        }

        this.ws.onmessage = (event) => {
          try {
            const data = JSON.parse(event.data)
            this.handleMessage(data)
          } catch (error) {
            console.error('解析WebSocket消息失败:', error)
          }
        }

        this.ws.onclose = (event) => {
          console.log('WebSocket连接关闭:', event.code, event.reason)
          this.isConnected = false
          this.isAuthenticated = false
          this.stopHeartbeat()
          
          // 在生产环境中不自动重连（避免控制台错误）
          if (import.meta.env.PROD && !import.meta.env.VITE_WS_ENABLED) {
            console.log('WebSocket在生产环境中已禁用，不进行重连')
            return
          }
          
          // 自动重连
          if (this.reconnectAttempts < this.maxReconnectAttempts) {
            this.reconnectAttempts++
            const exponentialDelay = Math.min(
              this.baseReconnectInterval * (2 ** (this.reconnectAttempts - 1)),
              this.maxReconnectInterval
            )
            const jitter = Math.floor(Math.random() * 500)
            const delay = exponentialDelay + jitter
            console.log(`尝试重连 (${this.reconnectAttempts}/${this.maxReconnectAttempts})，${delay}ms后重试...`)
            setTimeout(() => {
              this.connect()
            }, delay)
          } else {
            console.log('WebSocket重连失败，已达到最大重连次数')
          }
        }

        this.ws.onerror = (error) => {
          console.log('❌ WebSocket错误:', error)
          reject(error)
        }

      } catch (error) {
        console.error('创建WebSocket连接失败:', error)
        reject(error)
      }
    })
  }

  /**
   * 认证WebSocket连接
   */
  async authenticate() {
    const userStore = useUserStore()
    const token = userStore.token

    if (!token) {
      throw new Error('缺少认证令牌')
    }

    return new Promise((resolve, reject) => {
      // 设置认证超时
      const authTimeout = setTimeout(() => {
        reject(new Error('认证超时'))
      }, 5000)

      // 监听认证结果
      const handleAuthResult = (data) => {
        clearTimeout(authTimeout)
        if (data.type === 'auth_success') {
          console.log('WebSocket认证成功:', data)
          this.isAuthenticated = true
          this.removeMessageHandler('auth_success')
          this.removeMessageHandler('auth_error')
          resolve(data)
        } else if (data.type === 'auth_error') {
          console.error('WebSocket认证失败:', data.message)
          this.removeMessageHandler('auth_success')
          this.removeMessageHandler('auth_error')
          reject(new Error(data.message))
        }
      }

      this.addMessageHandler('auth_success', handleAuthResult)
      this.addMessageHandler('auth_error', handleAuthResult)

      // 发送认证消息
      this.send({
        type: 'auth',
        token: token
      })
    })
  }

  /**
   * 处理接收到的消息
   */
  handleMessage(data) {
    console.log('收到WebSocket消息:', data)

    // 调用注册的消息处理器
    if (this.messageHandlers.has(data.type)) {
      const handlers = this.messageHandlers.get(data.type)
      handlers.forEach(handler => {
        try {
          handler(data)
        } catch (error) {
          console.error('消息处理器执行失败:', error)
        }
      })
    }

    // 默认消息处理
    switch (data.type) {
      case 'connected':
        console.log('WebSocket服务器消息:', data.message)
        break

      case 'announcement':
        this.handleAnnouncementNotification(data)
        break

      case 'system':
        this.handleSystemNotification(data)
        break

      case 'pong':
        // 心跳响应
        break

      case 'error':
        console.error('WebSocket服务器错误:', data.message)
        ElMessage.error(data.message)
        break

      default:
        console.log('未处理的消息类型:', data.type, data)
    }
  }

  /**
   * 处理公告通知
   */
  handleAnnouncementNotification(data) {
    const announcement = data.data
    
    console.log('收到新公告通知:', announcement.title)

    // 显示通知
    ElNotification({
      title: '📢 新公告通知',
      message: announcement.title,
      type: this.getNotificationType(announcement.type),
      duration: 5000,
      onClick: () => {
        // 点击通知跳转到公告页面
        this.navigateToAnnouncements()
      }
    })

    // 如果是弹窗公告，显示弹窗
    if (announcement.isPopup) {
      this.showAnnouncementPopup(announcement)
    }

    // 触发自定义事件，让其他组件可以监听
    window.dispatchEvent(new CustomEvent('newAnnouncement', {
      detail: announcement
    }))
  }

  /**
   * 处理系统通知
   */
  handleSystemNotification(data) {
    const notification = data.data
    
    ElNotification({
      title: notification.title || '系统通知',
      message: notification.message,
      type: notification.type || 'info',
      duration: 4000
    })
  }

  /**
   * 显示公告弹窗
   */
  showAnnouncementPopup(announcement) {
    import('element-plus').then(({ ElMessageBox }) => {
      ElMessageBox.alert(
        announcement.content.length > 200 
          ? announcement.content.substring(0, 200) + '...' 
          : announcement.content,
        announcement.title,
        {
          confirmButtonText: '查看详情',
          type: this.getNotificationType(announcement.type),
          dangerouslyUseHTMLString: false,
          callback: () => {
            this.navigateToAnnouncements()
          }
        }
      )
    })
  }

  /**
   * 获取通知类型
   */
  getNotificationType(announcementType) {
    const typeMap = {
      'system': 'error',
      'maintenance': 'warning',
      'feature': 'success',
      'warning': 'warning',
      'info': 'info'
    }
    return typeMap[announcementType] || 'info'
  }

  /**
   * 跳转到公告页面
   */
  navigateToAnnouncements() {
    // 这里需要根据你的路由配置来实现
    if (window.location.pathname !== '/announcements') {
      window.location.href = '/announcements'
    }
  }

  /**
   * 发送消息
   */
  send(data) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify(data))
      return true
    } else {
      console.warn('WebSocket未连接，无法发送消息:', data)
      return false
    }
  }

  /**
   * 添加消息处理器
   */
  addMessageHandler(type, handler) {
    if (!this.messageHandlers.has(type)) {
      this.messageHandlers.set(type, new Set())
    }
    this.messageHandlers.get(type).add(handler)
  }

  /**
   * 移除消息处理器
   */
  removeMessageHandler(type, handler) {
    if (this.messageHandlers.has(type)) {
      if (handler) {
        this.messageHandlers.get(type).delete(handler)
      } else {
        this.messageHandlers.delete(type)
      }
    }
  }

  /**
   * 开始心跳
   */
  startHeartbeat() {
    this.stopHeartbeat()
    this.heartbeatInterval = setInterval(() => {
      if (this.isAuthenticated) {
        this.send({ type: 'ping' })
      }
    }, this.heartbeatTimer)
  }

  /**
   * 停止心跳
   */
  stopHeartbeat() {
    if (this.heartbeatInterval) {
      clearInterval(this.heartbeatInterval)
      this.heartbeatInterval = null
    }
  }

  /**
   * 断开连接
   */
  disconnect() {
    this.stopHeartbeat()
    if (this.ws) {
      this.ws.close()
      this.ws = null
    }
    this.isConnected = false
    this.isAuthenticated = false
    this.messageHandlers.clear()
  }

  /**
   * 获取连接状态
   */
  getStatus() {
    return {
      isConnected: this.isConnected,
      isAuthenticated: this.isAuthenticated,
      readyState: this.ws ? this.ws.readyState : WebSocket.CLOSED
    }
  }
}

// 创建单例实例
const websocketService = new WebSocketService()

export default websocketService
