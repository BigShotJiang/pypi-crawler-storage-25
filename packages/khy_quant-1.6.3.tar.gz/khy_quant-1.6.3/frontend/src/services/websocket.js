import { WS_URL } from '@/config/api'

/**
 * WebSocket 实时数据服务
 */
class WebSocketService {
  constructor() {
    this.ws = null
    this.reconnectTimer = null
    this.reconnectAttempts = 0
    this.maxReconnectAttempts = 12
    this.baseReconnectDelay = 1000
    this.maxReconnectDelay = 30000
    this.subscribers = new Map() // symbol -> Set of callbacks
    this.isConnecting = false
    this.isConnected = false
  }

  /**
   * 连接 WebSocket
   */
  connect() {
    // 在生产环境中禁用WebSocket（如果没有配置WebSocket服务器）
    if (import.meta.env.PROD && !import.meta.env.VITE_WS_ENABLED) {
      console.log('WebSocket在生产环境中已禁用')
      return Promise.resolve()
    }

    if (this.isConnecting || this.isConnected) {
      console.log('WebSocket 已连接或正在连接')
      return Promise.resolve()
    }

    return new Promise((resolve, reject) => {
      this.isConnecting = true
      const wsUrl = WS_URL

      console.log('正在连接 WebSocket:', wsUrl)
      this.ws = new WebSocket(wsUrl)

      this.ws.onopen = () => {
        console.log('✓ WebSocket 连接成功')
        this.isConnecting = false
        this.isConnected = true
        this.reconnectAttempts = 0

        // 重新订阅所有之前的订阅
        this.resubscribeAll()
        resolve()
      }

      this.ws.onmessage = (event) => {
        try {
          const message = JSON.parse(event.data)
          this.handleMessage(message)
        } catch (error) {
          console.error('WebSocket 消息解析失败:', error)
        }
      }

      this.ws.onerror = (error) => {
        console.log('WebSocket 错误:', error)
        this.isConnecting = false
        reject(error)
      }

      this.ws.onclose = () => {
        console.log('WebSocket 连接关闭')
        this.isConnected = false
        this.isConnecting = false
        this.ws = null

        // 在生产环境中不自动重连（避免控制台错误）
        if (import.meta.env.PROD && !import.meta.env.VITE_WS_ENABLED) {
          console.log('WebSocket在生产环境中已禁用，不进行重连')
          return
        }

        // 尝试重连
        this.attemptReconnect()
      }
    })
  }

  /**
   * 处理消息
   */
  handleMessage(message) {
    const { type, symbol, data } = message

    switch (type) {
      case 'connected':
        console.log('WebSocket 服务器消息:', message.message)
        break

      case 'subscribed':
        console.log(`✓ 已订阅 ${symbol} 的实时数据`)
        break

      case 'unsubscribed':
        console.log(`已取消订阅 ${symbol}`)
        break

      case 'realtime':
        // 推送实时数据给订阅者
        if (this.subscribers.has(symbol)) {
          this.subscribers.get(symbol).forEach(callback => {
            callback(data)
          })
        }
        break

      case 'error':
        console.error('WebSocket 错误:', message.message)
        break

      default:
        console.log('未知消息类型:', type)
    }
  }

  /**
   * 订阅实时数据
   */
  subscribe(symbol, callback) {
    if (!this.subscribers.has(symbol)) {
      this.subscribers.set(symbol, new Set())
    }

    this.subscribers.get(symbol).add(callback)

    // 如果已连接，立即发送订阅请求
    if (this.isConnected && this.ws) {
      this.sendSubscribe(symbol)
    } else {
      // 否则先连接
      this.connect().then(() => {
        this.sendSubscribe(symbol)
      }).catch(error => {
        console.error('连接失败，无法订阅:', error)
      })
    }
  }

  /**
   * 取消订阅
   */
  unsubscribe(symbol, callback) {
    if (this.subscribers.has(symbol)) {
      this.subscribers.get(symbol).delete(callback)

      // 如果没有订阅者了，取消服务器订阅
      if (this.subscribers.get(symbol).size === 0) {
        this.subscribers.delete(symbol)

        if (this.isConnected && this.ws) {
          this.sendUnsubscribe(symbol)
        }
      }
    }
  }

  /**
   * 发送订阅请求
   */
  sendSubscribe(symbol) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        type: 'subscribe',
        symbol
      }))
    }
  }

  /**
   * 发送取消订阅请求
   */
  sendUnsubscribe(symbol) {
    if (this.ws && this.ws.readyState === WebSocket.OPEN) {
      this.ws.send(JSON.stringify({
        type: 'unsubscribe',
        symbol
      }))
    }
  }

  /**
   * 重新订阅所有
   */
  resubscribeAll() {
    this.subscribers.forEach((callbacks, symbol) => {
      if (callbacks.size > 0) {
        this.sendSubscribe(symbol)
      }
    })
  }

  /**
   * 尝试重连
   */
  attemptReconnect() {
    if (this.reconnectAttempts >= this.maxReconnectAttempts) {
      console.error('WebSocket 重连次数已达上限')
      return
    }

    this.reconnectAttempts++
    const exponentialDelay = Math.min(
      this.baseReconnectDelay * (2 ** (this.reconnectAttempts - 1)),
      this.maxReconnectDelay
    )
    const jitter = Math.floor(Math.random() * 500)
    const delay = exponentialDelay + jitter

    console.log(`尝试重连 WebSocket (${this.reconnectAttempts}/${this.maxReconnectAttempts})，${delay}ms 后重试...`)

    this.reconnectTimer = setTimeout(() => {
      this.connect().catch(error => {
        console.error('重连失败:', error)
      })
    }, delay)
  }

  /**
   * 断开连接
   */
  disconnect() {
    if (this.reconnectTimer) {
      clearTimeout(this.reconnectTimer)
      this.reconnectTimer = null
    }

    if (this.ws) {
      this.ws.close()
      this.ws = null
    }

    this.isConnected = false
    this.isConnecting = false
    this.subscribers.clear()
  }

  /**
   * 获取连接状态
   */
  getConnectionState() {
    return {
      isConnected: this.isConnected,
      isConnecting: this.isConnecting,
      reconnectAttempts: this.reconnectAttempts
    }
  }
}

// 导出单例
export default new WebSocketService()
