import axios from 'axios'
import { ElLoading, ElMessage } from 'element-plus'
import { useUserStore } from '@/stores/user'
import { getFriendlyErrorMessage } from './errorMessage'
import { getApiBaseUrl, getRequestTimeoutMs, isMobileViewport, getConnectionMode } from './connectionMode'
import { isLocalToken } from '@/services/localAuthService'

const request = axios.create({
  baseURL: getApiBaseUrl(),
  timeout: getRequestTimeoutMs(),
  headers: {
    'Content-Type': 'application/json'
  }
})

let pendingCount = 0
let loadingInstance = null
let loadingTimer = null
let handlingAuthExpired = false

function isLogoutRequest(config) {
  const url = String(config?.url || '')
  return url.includes('/auth/logout')
}

function shouldSkipAuthErrorHandling(config) {
  return Boolean(config?.__skipAuthErrorHandling) || isLogoutRequest(config)
}

function startGlobalLoading(config) {
  if (config?.silentLoading) return
  if (isMobileViewport()) return
  pendingCount += 1
  if (pendingCount === 1 && !loadingTimer) {
    // Delay showing loading by 300ms to avoid flash for fast requests
    loadingTimer = setTimeout(() => {
      if (pendingCount > 0 && !loadingInstance) {
        loadingInstance = ElLoading.service({
          lock: true,
          text: '加载中...',
          background: 'rgba(255, 255, 255, 0.45)'
        })
      }
      loadingTimer = null
    }, 300)
  }
}

function stopGlobalLoading(config) {
  if (config?.silentLoading) return
  pendingCount = Math.max(0, pendingCount - 1)
  if (pendingCount === 0) {
    if (loadingTimer) {
      clearTimeout(loadingTimer)
      loadingTimer = null
    }
    if (loadingInstance) {
      loadingInstance.close()
      loadingInstance = null
    }
  }
}

// 请求拦截器
request.interceptors.request.use(
  (config) => {
    startGlobalLoading(config)
    config.baseURL = getApiBaseUrl()
    config.timeout = getRequestTimeoutMs()
    // 从pinia store获取token
    const userStore = useUserStore()
    const token = typeof userStore.token === 'string' ? userStore.token.replace(/^Bearer\s+/i, '').trim() : ''

    if (token && !isLocalToken(token)) {
      config.headers.Authorization = `Bearer ${token}`
    } else if (config.headers?.Authorization) {
      delete config.headers.Authorization
    }
    
    return config
  },
  (error) => {
    stopGlobalLoading(error?.config)
    console.error('请求拦截器错误:', error)
    return Promise.reject(error)
  }
)

// 响应拦截器
request.interceptors.response.use(
  (response) => {
    stopGlobalLoading(response?.config)
    // 直接返回响应数据
    return response.data
  },
  (error) => {
    stopGlobalLoading(error?.config)

    // silentError: skip all error toasts — caller handles the error itself
    if (error?.config?.silentError) {
      return Promise.reject(error)
    }

    console.error('响应拦截器错误:', error)

    // 处理不同的错误状态码
    if (error.response) {
      const { status, data } = error.response
      
      switch (status) {
        case 401:
          if (shouldSkipAuthErrorHandling(error?.config)) {
            break
          }
          if (handlingAuthExpired) {
            break
          }
          // 未授权，清除token并跳转到登录页
          const userStore = useUserStore()
          if (!isLocalToken(userStore.token)) {
            handlingAuthExpired = true
            userStore.logout({ skipRemote: true }).finally(() => {
              handlingAuthExpired = false
            })
            ElMessage.error('登录已过期，请重新登录')
            // 如果不在登录页面，则跳转到登录页面
            if (window.location.hash !== '#/login') {
              window.location.href = '/#/login'
            }
          }
          break
        case 403:
          ElMessage.error('权限不足')
          break
        case 404:
          ElMessage.error('请求的资源不存在')
          break
        case 500:
          ElMessage.error(data?.message || data?.error || '服务器内部错误，请稍后重试')
          break
        default:
          ElMessage.error(data?.message || getFriendlyErrorMessage(error, '请求失败'))
      }
    } else if (error.request) {
      // 网络错误
      if (getConnectionMode() === 'local') {
        ElMessage.warning('当前处于单机模式，云端接口不可用')
      } else {
        ElMessage.error(getFriendlyErrorMessage(error, '网络连接失败，请检查网络'))
      }
    } else {
      // 其他错误
      ElMessage.error(getFriendlyErrorMessage(error, '请求配置错误'))
    }
    
    return Promise.reject(error)
  }
)

export default request
