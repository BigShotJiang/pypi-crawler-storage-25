# KHY-Quant 项目文档中心

## 架构设计

| 文档 | 内容 |
|------|------|
| [SaaS 总体架构](architecture/SAAS_ARCHITECTURE.md) | 系统架构、数据模型、API、安全 |
| [订阅层级](architecture/SUBSCRIPTION_TIERS.md) | Free/Pro/Enterprise 功能矩阵 |
| [组件市场](architecture/COMPONENT_MARKETPLACE.md) | SDK、发布流程、分成模式 |
| [多租户](architecture/MULTI_TENANCY.md) | 组织、角色、数据隔离 |
| [惊艳特性](architecture/WOW_FEATURES.md) | 差异化亮点、生态圈、安全防护 |
| [路线图](architecture/ROADMAP.md) | 分阶段实施计划 |

## 部署与运维

| 文档 | 内容 |
|------|------|
| [服务器部署](deployment/SERVER_DEPLOY.md) | Docker 一键部署、域名、SSL、防护 |
| [更新策略](deployment/UPDATE_STRATEGY.md) | 热更新、回滚、灰度发布 |
| [安全防护](deployment/SECURITY.md) | DDoS、WAF、防止滥用 |
| [自修复系统](deployment/SELF_HEALING.md) | 健康检查、自动重启、错误恢复 |

## 用户指南

| 文档 | 内容 |
|------|------|
| [快速开始](guides/QUICKSTART.md) | 5分钟上手 |
| [CLI 教程](guides/CLI_TUTORIAL.md) | 命令行使用 |
| [AI 网关](guides/AI_GATEWAY.md) | 模型配置 |
| [策略入门](guides/STRATEGY_GUIDE.md) | 量化策略 |

## 开发者

| 文档 | 内容 |
|------|------|
| [SDK 开发](developer/SDK.md) | 二次开发指南 |
| [MCP 集成](developer/MCP.md) | MCP 工具服务器 |
| [插件开发](developer/PLUGINS.md) | 自定义命令 |

---

**QQ 交流群**: 1083973296
**官网**: https://khyquant.top
**安装**: `pip install khy-quant`
