# KHY-xxx 模型能力说明

## 模型命名

训练完成的模型使用 `khy-<版本号>` 命名，例如：
- `khy-1.0` — 第一版基础模型
- `khy-1.1` — 第一版迭代优化
- `khy-2.0` — 第二版（更大数据量或新基座）

版本号随每次训练自动递增。

---

## 模型能力

### 1. 量化交易分析

| 能力 | 说明 |
|------|------|
| 技术分析 | 识别 K 线形态、趋势判断、支撑/阻力位 |
| 策略推荐 | 根据行情推荐适合的交易策略和参数 |
| 风险评估 | 评估当前持仓风险、建议仓位比例 |
| 回测解读 | 解读回测报告，指出改进方向 |

### 2. 市场理解

| 能力 | 说明 |
|------|------|
| A 股 | 沪深主板、创业板、科创板个股分析 |
| 期货 | 商品期货、股指期货的趋势研判 |
| 加密货币 | BTC/ETH 等主流币种技术分析 |
| 基本面 | 财报数据、行业对比、估值分析 |

### 3. 策略生成

| 能力 | 说明 |
|------|------|
| 自然语言→策略 | 描述交易想法，自动生成可执行策略代码 |
| 参数优化建议 | 根据回测结果建议参数调整方向 |
| 多策略对比 | 比较不同策略在同一品种上的表现 |
| 风控规则 | 生成止损止盈、仓位管理规则 |

### 4. 交互能力

| 能力 | 说明 |
|------|------|
| 中文对话 | 流畅的中文量化交易对话 |
| 工具调用 | 调用行情查询、回测执行等内置工具 |
| 上下文记忆 | 在会话内保持对话上下文连贯 |
| 解释推理 | 解释分析逻辑和决策依据 |

---

## 训练数据来源

模型使用以下数据自动训练（使用过程中被动收集）：

1. **AI 对话记录** — 用户与 AI 的交互问答
2. **策略回测结果** — 策略参数与对应的表现指标
3. **分析反馈** — 用户对 AI 分析质量的评价
4. **市场数据** — 历史行情数据上的分析推理

训练数据存储在 `~/.khyquant/training/` 目录。

---

## 支持的基座模型

| 标识 | 模型 | 参数量 | 显存需求 |
|------|------|--------|----------|
| `qwen-1.5b` | Qwen2.5-1.5B-Instruct | 1.5B | 6GB |
| `qwen-3b` | Qwen2.5-3B-Instruct | 3B | 8GB |
| `qwen-7b` | Qwen2.5-7B-Instruct | 7B | 16GB |
| `llama-3b` | Llama-3.2-3B-Instruct | 3B | 8GB |
| `llama-8b` | Llama-3.1-8B-Instruct | 8B | 20GB |
| `deepseek-1.5b` | DeepSeek-R1-Distill-Qwen-1.5B | 1.5B | 6GB |
| `deepseek-7b` | DeepSeek-R1-Distill-Qwen-7B | 7B | 16GB |
| `mistral-7b` | Mistral-7B-Instruct-v0.3 | 7B | 16GB |

---

## 训练方式

### LoRA 微调（推荐）
- 只训练少量参数（< 1% 模型总量）
- 显存占用低，速度快
- 效果好，适合特定任务优化

### 全量微调
- 训练所有参数
- 需要更多显存和时间
- 适合有大量数据的场景

### 知识蒸馏
- 用大模型（Claude/GPT）生成高质量回答
- 用这些回答训练小模型
- 让小模型获得接近大模型的量化分析能力

---

## 导出格式

### GGUF (推荐)
- 适用于 **Ollama**、llama.cpp
- 支持量化：q4_k_m (小)、q5_k_m (中)、q8_0 (大)、f16 (无损)
- 导出后自动注册到本地 Ollama

### Safetensors
- 适用于 **HuggingFace**、vLLM、TGI
- 可上传到 HuggingFace Hub 分享
- 适合云端部署

---

## 中转站/代理兼容

khy-xxx 模型使用标准 OpenAI Chat Completion 格式，兼容：
- 任何 OpenAI 兼容 API 中转站
- Ollama API (`/api/chat`)
- vLLM OpenAI 兼容端点
- LiteLLM 代理

**如果 Claude 能通过某个中转站使用，khy-xxx 模型也能通过同一中转站使用。**

---

## 版本管理

```bash
# 查看已训练模型
train list

# 回退到旧版本
train rollback khy-1.0

# 设为活跃模型
train activate khy-2.0
```

---

## 导出密码

模型导出需要输入密码验证，防止未授权导出：

```bash
train export khy-1.0 --format gguf
# 系统提示: 🔐 请输入导出密码:
```

---

## 使用示例

```bash
# 查看算力
compute

# 查看训练数据统计
train data

# 本地微调 (Qwen 3B)
train start --base qwen-3b --preset standard

# 云端训练 (Qwen 7B)
train cloud --base qwen-7b

# 知识蒸馏
train distill --student qwen-1.5b

# 列出已训练模型
train list

# 导出到 Ollama (需要密码)
train export khy-1.0 --format gguf

# 导出到 HuggingFace (需要密码)
train export khy-1.0 --format safetensors

# 用 Ollama 运行训练好的模型
ollama run khy-1.0
```

---

QQ 群: 1083973296
