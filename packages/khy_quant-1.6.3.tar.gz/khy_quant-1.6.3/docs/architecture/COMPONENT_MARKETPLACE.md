# Component Marketplace & SDK Design

> Enable developers to build, publish, and monetize extensions for KHY-Quant.

## 1. Overview

The marketplace transforms KHY-Quant from a product into a **platform**. Third-party developers can create and sell:

- **Strategies** — Trading algorithms (JS/Python/TDX)
- **Indicators** — Custom technical indicators
- **Data Sources** — Connect new market data providers
- **Skills** — CLI commands and AI capabilities
- **Themes** — UI customization for the web frontend
- **Connectors** — Broker/exchange integrations

---

## 2. SDK Architecture

### Package Structure

```
@khy/sdk                 — Core SDK (required)
@khy/sdk-strategies      — Strategy development kit
@khy/sdk-indicators      — Indicator development kit
@khy/sdk-data            — Data source plugin kit
@khy/sdk-skills          — Skill/CLI extension kit
@khy/sdk-ui              — UI component kit (Vue 3)
```

### Developer Experience

```bash
# Install SDK
npm install @khy/sdk

# Scaffold a new component
npx @khy/create-component my-strategy --type strategy

# Test locally
khy dev ./my-strategy

# Publish to marketplace
khy publish ./my-strategy
```

### SDK Core API

```javascript
const { defineStrategy, defineIndicator, defineSkill } = require('@khy/sdk');

// Example: Custom strategy
module.exports = defineStrategy({
  name: 'golden-cross-enhanced',
  version: '1.0.0',
  description: 'Enhanced golden cross with volume confirmation',
  author: 'trader-zhang',
  tags: ['trend', 'moving-average', 'volume'],
  pricing: 'paid',       // free | paid | subscription
  price: 2999,           // in cents (¥29.99)

  params: {
    fastPeriod: { type: 'number', default: 5, min: 2, max: 50 },
    slowPeriod: { type: 'number', default: 20, min: 10, max: 200 },
    volumeThreshold: { type: 'number', default: 1.5 },
  },

  init(context) {
    // Called once at strategy start
    this.fastMA = context.indicator('SMA', this.params.fastPeriod);
    this.slowMA = context.indicator('SMA', this.params.slowPeriod);
  },

  onBar(bar, context) {
    const fast = this.fastMA.value;
    const slow = this.slowMA.value;
    const volRatio = bar.volume / context.avgVolume(20);

    if (fast > slow && volRatio > this.params.volumeThreshold) {
      context.buy({ reason: 'Golden cross + volume surge' });
    } else if (fast < slow) {
      context.sell({ reason: 'Death cross' });
    }
  },
});
```

---

## 3. Marketplace Backend

### API Endpoints

```
GET    /v1/marketplace                    — List/search components
GET    /v1/marketplace/featured           — Editor's picks
GET    /v1/marketplace/trending           — Popular this week
GET    /v1/marketplace/:slug              — Component detail
GET    /v1/marketplace/:slug/versions     — Version history
POST   /v1/marketplace/publish            — Publish new version
POST   /v1/marketplace/:slug/install      — Install (track download)
POST   /v1/marketplace/:slug/purchase     — Buy paid component
POST   /v1/marketplace/:slug/review       — Submit rating/review
GET    /v1/marketplace/my/published       — My published components
GET    /v1/marketplace/my/purchased       — My purchases
GET    /v1/marketplace/my/earnings        — Developer earnings
POST   /v1/marketplace/my/withdraw        — Request payout
```

### Data Model

```
marketplace_components:
  id, author_id, type, name, slug, description, readme,
  version, code (encrypted for paid), metadata (JSON),
  pricing_type (free|paid|subscription), price_cents,
  downloads, rating, review_count, revenue_total,
  status (draft|pending|approved|rejected|suspended),
  published_at, created_at, updated_at

component_versions:
  id, component_id, version, code, changelog, created_at

component_purchases:
  id, component_id, user_id, price_paid, purchased_at, expires_at

component_reviews:
  id, component_id, user_id, rating (1-5), title, comment, created_at
```

---

## 4. Revenue Sharing

| Party | Share | Notes |
|-------|-------|-------|
| Developer | 70% | Paid monthly, min ¥100 for withdrawal |
| Platform | 30% | Covers hosting, review, payment fees |

### Payout Schedule

- Earnings accumulated monthly
- Payout on 15th of following month
- WeChat Pay / Alipay / Bank transfer
- Tax withholding: Developer responsible for self-reporting

---

## 5. Quality & Trust System

### Submission Review Process

```
[Developer submits]
  → Automated checks (lint, security scan, sandboxed test)
  → Manual review queue (for paid components)
  → Approved / Rejected with feedback
  → Published to marketplace
```

### Automated Checks

1. **Security scan** — No network calls outside declared endpoints
2. **Sandbox test** — Execute in isolated environment, check for crashes
3. **Code quality** — Basic linting, no obvious antipatterns
4. **Performance** — Backtest completes within 60s for 1 year of data
5. **Metadata** — Description, readme, valid version, tags present

### Trust Signals

- **Verified Author** badge (linked GitHub + real name)
- **Download count** (social proof)
- **Star rating** (1-5 with review text)
- **Response time** (how fast author fixes bugs)
- **Last updated** (staleness indicator)

---

## 6. Component Discovery

### Search & Browse

```
khy marketplace search "momentum"
khy marketplace trending
khy marketplace category strategies
khy marketplace author trader-zhang
```

### Recommendation Engine

Based on:
- User's trading style (from userProfile adaptive learning)
- Instruments traded (suggest relevant strategies)
- Skill level (beginner → simpler components)
- Popular in user's peer group

---

## 7. CLI Integration

```
# Browse marketplace
khy marketplace                    # Interactive browser
khy marketplace search <keyword>   # Text search

# Install
khy marketplace install golden-cross-enhanced
khy marketplace install @trader-zhang/momentum-scanner

# Use installed component
khy backtest sh600519 --strategy golden-cross-enhanced

# Publish your own
khy marketplace publish ./my-strategy
khy marketplace publish --update ./my-strategy  # New version

# Manage
khy marketplace my                 # My published/installed
khy marketplace uninstall <slug>   # Remove
khy marketplace update <slug>      # Update to latest
```

---

## 8. Extensibility Points for Developers

### Strategy Hooks

```javascript
{
  init(context),              // Strategy initialization
  onBar(bar, context),        // Called every candle
  onTick(tick, context),      // Called every tick (Pro+)
  onSignal(signal, context),  // External signal received
  onRiskAlert(alert, context),// Risk limit triggered
  destroy(context),           // Cleanup
}
```

### Data Source Plugin

```javascript
defineDataSource({
  name: 'binance-futures',
  type: 'datasource',
  markets: ['crypto'],

  async connect(config) { ... },
  async fetchKline(symbol, timeframe, start, end) { ... },
  async subscribe(symbol, onTick) { ... },
  async disconnect() { ... },
});
```

### Skill Plugin

```javascript
defineSkill({
  id: 'portfolio-optimizer',
  trigger: '/optimize',
  aliases: ['/opt', '/优化'],

  async handler(args, context) {
    const portfolio = await context.getPositions();
    const optimized = optimize(portfolio, args);
    return { type: 'display', content: formatResult(optimized) };
  },
});
```

---

## 9. Security for Paid Components

- Source code **encrypted at rest** for paid components
- Delivered to clients as **obfuscated bundles** (not raw source)
- License key verification at runtime
- Server-side execution option for Enterprise (code never leaves server)
- DMCA-style takedown process for IP violations

---

## 10. Analytics for Authors

Dashboard showing:
- Downloads over time
- Revenue per component
- User retention (how many keep using after install)
- Ratings trend
- Popular parameter configurations
- Geographic distribution of users

---

## Community

- QQ Group: 1083973296
- Developer Docs: https://khyquant.top/docs/sdk
