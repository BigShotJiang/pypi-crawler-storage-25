# KHY-Quant SaaS Architecture Design

> Version: 1.0 | Date: 2026-05-03 | Author: khy-qqb

## 1. Vision

Transform KHY-Quant from a standalone quantitative trading tool into a **commercial SaaS platform** that developers and traders cannot live without. The platform should feel like "having a senior quant engineer in your pocket" — intelligent, fast, extensible, and collaborative.

**Core Values:**
- **Instant Wow** — Users feel value within 30 seconds of first use
- **Sticky by Design** — Every day of use makes the system more valuable (adaptive learning)
- **Community Flywheel** — Users create content (strategies, skills) that attracts more users
- **Developer-First** — Open SDK + component marketplace for third-party extensibility

---

## 2. System Architecture Overview

```
┌─────────────────────────────────────────────────────────────────┐
│                        CLIENT LAYER                              │
├───────────────┬───────────────┬──────────────┬─────────────────┤
│   CLI (khy)   │  Web App (Vue)│ Mobile (Cap) │  SDK (@khy/*)   │
└───────┬───────┴───────┬───────┴──────┬───────┴────────┬────────┘
        │               │              │                │
        ▼               ▼              ▼                ▼
┌─────────────────────────────────────────────────────────────────┐
│                      API GATEWAY LAYER                           │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌───────────────┐  │
│  │ Auth/JWT │  │Rate Limit│  │Tier Check│  │Usage Metering │  │
│  └──────────┘  └──────────┘  └──────────┘  └───────────────┘  │
└─────────────────────────────┬───────────────────────────────────┘
                              │
┌─────────────────────────────┴───────────────────────────────────┐
│                      SERVICE LAYER                               │
├──────────────┬──────────────┬──────────────┬───────────────────┤
│ Trading Core │  AI Gateway  │  Marketplace │  Subscription     │
│ • Strategy   │  • Multi-LLM │  • Registry  │  • Billing        │
│ • Backtest   │  • Streaming │  • Publish   │  • Usage Quota    │
│ • Execution  │  • Agent Sys │  • Purchase  │  • Feature Flags  │
│ • Risk Mgmt  │  • RAG       │  • Reviews   │  • Org Mgmt       │
├──────────────┴──────────────┴──────────────┴───────────────────┤
│                      DATA LAYER                                  │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌───────────────┐  │
│  │PostgreSQL│  │  Redis   │  │  S3/OSS  │  │ TimescaleDB   │  │
│  │User/Trade│  │ Cache/Q  │  │ Backups  │  │ Market Data   │  │
│  └──────────┘  └──────────┘  └──────────┘  └───────────────┘  │
└─────────────────────────────────────────────────────────────────┘
```

---

## 3. Core Domains

### 3.1 Identity & Subscription

| Component | Responsibility |
|-----------|---------------|
| Auth Service | Registration, login (password/WebAuthn/OAuth), JWT issuance |
| Subscription Service | Tier management, upgrade/downgrade, billing cycle |
| Usage Metering | Track API calls, backtests, AI tokens, storage |
| Organization Service | Multi-user teams, role-based access, data isolation |

### 3.2 Trading Engine

| Component | Responsibility |
|-----------|---------------|
| Strategy Engine | Execute JS/Python/TDX strategies in sandbox |
| Backtest Engine | Historical simulation with tick-level precision |
| Risk Management | Position limits, drawdown alerts, auto-stop-loss |
| Execution Bridge | Paper trading → Real broker connections |

### 3.3 AI Intelligence

| Component | Responsibility |
|-----------|---------------|
| AI Gateway | Route requests through Kiro/Cursor/Trae/Claude/Ollama cascade |
| Strategy Generator | Natural language → executable strategy code |
| Smart Analyst | Technical analysis, pattern recognition, sentiment |
| Trading Agent | Autonomous decision-making with human oversight |

### 3.4 Marketplace

| Component | Responsibility |
|-----------|---------------|
| Component Registry | Publish/search/install strategies, indicators, plugins |
| Review System | Star ratings, usage stats, trust verification |
| Revenue Sharing | 70% developer / 30% platform split |
| SDK | `@khy/sdk` for third-party developers |

---

## 4. Data Model Extensions

### New Models Required

```sql
-- Subscription tracking
CREATE TABLE subscriptions (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  org_id INTEGER REFERENCES organizations(id),
  tier VARCHAR(20) NOT NULL DEFAULT 'free',  -- free|pro|enterprise
  status VARCHAR(20) NOT NULL DEFAULT 'active',
  started_at TIMESTAMP NOT NULL,
  expires_at TIMESTAMP,
  payment_provider VARCHAR(20),  -- stripe|alipay|wechat
  payment_id VARCHAR(255),
  metadata JSONB DEFAULT '{}'
);

-- Organization (multi-tenancy)
CREATE TABLE organizations (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(50) UNIQUE NOT NULL,
  owner_id INTEGER REFERENCES users(id),
  tier VARCHAR(20) NOT NULL DEFAULT 'free',
  max_members INTEGER DEFAULT 5,
  settings JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW()
);

-- Org membership
CREATE TABLE org_members (
  id SERIAL PRIMARY KEY,
  org_id INTEGER REFERENCES organizations(id),
  user_id INTEGER REFERENCES users(id),
  role VARCHAR(20) NOT NULL DEFAULT 'trader',  -- owner|admin|trader|viewer
  joined_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(org_id, user_id)
);

-- Usage metering
CREATE TABLE usage_records (
  id SERIAL PRIMARY KEY,
  user_id INTEGER REFERENCES users(id),
  org_id INTEGER,
  metric VARCHAR(50) NOT NULL,  -- api_calls|backtests|ai_tokens|storage_mb
  value NUMERIC NOT NULL DEFAULT 1,
  recorded_at TIMESTAMP DEFAULT NOW()
);

-- Marketplace components
CREATE TABLE marketplace_components (
  id SERIAL PRIMARY KEY,
  author_id INTEGER REFERENCES users(id),
  type VARCHAR(30) NOT NULL,  -- strategy|indicator|datasource|skill|theme
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(100) UNIQUE NOT NULL,
  description TEXT,
  version VARCHAR(20) NOT NULL,
  code TEXT,
  metadata JSONB DEFAULT '{}',
  pricing_type VARCHAR(20) DEFAULT 'free',  -- free|paid|subscription
  price_cents INTEGER DEFAULT 0,
  downloads INTEGER DEFAULT 0,
  rating NUMERIC(3,2) DEFAULT 0,
  status VARCHAR(20) DEFAULT 'pending',  -- pending|approved|rejected
  published_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

-- Component reviews
CREATE TABLE component_reviews (
  id SERIAL PRIMARY KEY,
  component_id INTEGER REFERENCES marketplace_components(id),
  user_id INTEGER REFERENCES users(id),
  rating INTEGER CHECK (rating BETWEEN 1 AND 5),
  comment TEXT,
  created_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(component_id, user_id)
);
```

### User Model Extensions

```sql
ALTER TABLE users ADD COLUMN subscription_tier VARCHAR(20) DEFAULT 'free';
ALTER TABLE users ADD COLUMN org_id INTEGER REFERENCES organizations(id);
ALTER TABLE users ADD COLUMN stripe_customer_id VARCHAR(255);
ALTER TABLE users ADD COLUMN usage_limits JSONB DEFAULT '{}';
```

---

## 5. API Design (New Endpoints)

### Billing & Subscription

```
POST   /api/v1/billing/subscribe     — Create subscription
POST   /api/v1/billing/cancel        — Cancel subscription
GET    /api/v1/billing/usage         — Current usage metrics
GET    /api/v1/billing/invoices      — Payment history
POST   /api/v1/billing/webhook       — Stripe/Alipay webhook

GET    /api/v1/subscription/status   — Current tier + limits
POST   /api/v1/subscription/upgrade  — Upgrade tier
```

### Organization

```
POST   /api/v1/org/create            — Create organization
GET    /api/v1/org/:id               — Org details
POST   /api/v1/org/:id/invite        — Invite member
DELETE /api/v1/org/:id/members/:uid  — Remove member
PATCH  /api/v1/org/:id/members/:uid  — Update role
```

### Marketplace

```
GET    /api/v1/marketplace           — Search/browse components
GET    /api/v1/marketplace/:slug     — Component detail
POST   /api/v1/marketplace/publish   — Publish component (author)
POST   /api/v1/marketplace/:slug/install — Install component
POST   /api/v1/marketplace/:slug/review  — Submit review
GET    /api/v1/marketplace/my        — My published components
```

### SDK / Developer API

```
POST   /api/v1/sdk/backtest          — Run backtest via API
POST   /api/v1/sdk/strategy/execute  — Execute strategy
GET    /api/v1/sdk/data/:symbol      — Get market data
POST   /api/v1/sdk/ai/generate       — AI generation
WS     /api/v1/sdk/stream            — Real-time data stream
```

---

## 6. Middleware Architecture

```javascript
// Tier enforcement middleware stack
app.use('/api/v1', [
  authMiddleware,           // JWT verification
  tierCheckMiddleware,      // Check subscription tier
  rateLimitByTier,          // Rate limit based on tier
  usageMeteringMiddleware,  // Track usage for billing
  orgIsolationMiddleware,   // Multi-tenant data isolation
]);
```

### Rate Limits by Tier

| Tier | API/min | Backtests/month | AI Tokens/month | Storage |
|------|---------|-----------------|-----------------|---------|
| Free | 30 | 50 | 10K | 50MB |
| Pro | 300 | Unlimited | 500K | 5GB |
| Enterprise | 3000 | Unlimited | Unlimited | 100GB |

---

## 7. Security Architecture

- **Authentication**: JWT + WebAuthn + OAuth (GitHub, WeChat)
- **Authorization**: RBAC (role-based) + ABAC (attribute-based for org features)
- **API Keys**: Scoped keys with expiry (already exists in apiKey.js)
- **Data Isolation**: Row-level security via org_id middleware
- **Encryption**: AES-256 for secrets at rest, TLS 1.3 in transit
- **Audit**: All sensitive operations logged (userLogService.js)
- **Sandbox**: Strategy execution in isolated Node.js/Python workers

---

## 8. Deployment Architecture

### Production (khyquant.top)

```yaml
# docker-compose.production.yml
services:
  api:
    image: khy-quant/api:latest
    replicas: 3
    resources:
      limits: { cpus: '2', memory: '4G' }

  worker:
    image: khy-quant/worker:latest  # Backtest/strategy execution
    replicas: 5
    resources:
      limits: { cpus: '4', memory: '8G' }

  frontend:
    image: khy-quant/web:latest
    replicas: 2

  postgres:
    image: postgres:16-alpine
    volumes: [pgdata:/var/lib/postgresql/data]

  redis:
    image: redis:7-alpine

  timescaledb:
    image: timescale/timescaledb:latest-pg16
    # For high-performance market data storage
```

### CLI Distribution

```
pip install khy-quant          # Core CLI
pip install khy-quant[full]    # Everything
pip install khy-quant[data]    # + Data analysis
pip install khy-quant[ml]      # + Machine learning
```

---

## 9. Revenue Model

| Stream | Pricing | Target |
|--------|---------|--------|
| Pro Subscription | ¥49/month | Individual traders |
| Enterprise | ¥399/month | Teams & funds |
| Marketplace Commission | 30% of sales | Component developers |
| API Usage (overage) | ¥0.01/call over limit | Heavy API users |
| White-label License | ¥9,999/year | Institutions |
| Training & Consulting | Custom | Enterprise clients |

**Projected Revenue (Year 1):**
- 1000 free users → 100 Pro conversions → ¥4,900/month
- 10 Enterprise → ¥3,990/month
- Marketplace (50 paid components) → ¥1,000/month
- **Total: ~¥10K/month by month 12**

---

## 10. Related Documents

- [Subscription Tiers](./SUBSCRIPTION_TIERS.md) — Detailed feature matrix
- [Component Marketplace](./COMPONENT_MARKETPLACE.md) — SDK & marketplace design
- [Multi-Tenancy](./MULTI_TENANCY.md) — Organization & isolation design
- [WOW Features](./WOW_FEATURES.md) — Differentiating features for retention
- [Roadmap](./ROADMAP.md) — Implementation timeline

---

## 11. Community

- **QQ Group**: 1083973296
- **Website**: https://khyquant.top
- **Package**: `pip install khy-quant`
