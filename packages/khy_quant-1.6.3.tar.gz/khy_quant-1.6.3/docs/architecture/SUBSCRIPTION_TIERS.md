# Subscription Tiers Design

> Pricing strategy: Generous free tier to drive adoption, Pro for serious traders, Enterprise for teams.

## Tier Matrix

| Feature | Free | Pro (¥49/mo) | Enterprise (¥399/mo) |
|---------|------|--------------|---------------------|
| **Strategies** | 10 | Unlimited | Unlimited |
| **Backtests / month** | 50 | Unlimited | Unlimited |
| **Strategy Languages** | JavaScript only | JS + Python + TDX | All + Custom |
| **Market Data** | Delayed 15min | Real-time | Real-time + Tick |
| **Data History** | 1 year | 10 years | Full history |
| **AI Requests / month** | 100 | 5,000 | Unlimited |
| **AI Models** | Ollama (local) | Claude/GPT/Doubao | All + Custom fine-tuned |
| **Cloud Storage** | 50MB | 5GB | 100GB |
| **Devices** | 1 | 5 | Unlimited |
| **API Access** | Read only | Full (300/min) | Full (3000/min) |
| **Marketplace** | Browse free | Buy + Sell | Custom marketplace |
| **Skills (Plugins)** | Built-in only | Community | Custom + Private |
| **Collaboration** | - | - | Team sharing |
| **Organization** | - | - | Multi-user |
| **Priority Support** | Community QQ | Email (48h) | Dedicated (4h SLA) |
| **White-label** | - | - | Available |
| **Webhooks** | - | 5 | Unlimited |
| **Export Formats** | CSV | CSV + Excel + PDF | All + API |
| **Risk Alerts** | Basic | Advanced | Custom rules |

---

## Free Tier Strategy

The free tier is intentionally generous to maximize adoption:

1. **No credit card required** — Zero friction signup
2. **Full CLI experience** — The terminal feels complete
3. **Basic AI** — Ollama/local models work without limits
4. **JavaScript strategies** — Most common use case covered
5. **Community skills** — Access to free marketplace content

### Conversion Triggers (Free → Pro)

| Trigger | UX |
|---------|-----|
| Hit 50 backtest limit | "You've used 50/50 backtests this month. Upgrade for unlimited." |
| Try Python strategy | "Python strategies are a Pro feature. Try 3 free, then upgrade." |
| Need real-time data | "Real-time data available with Pro. Currently showing 15min delay." |
| 5+ devices | "You've synced to 5 devices. Add more with Pro." |
| AI quota exceeded | "AI credits for this month used. Resets in X days or upgrade." |

### Upgrade Flow

```
[User hits limit]
  → Soft notification (not blocking)
  → Show what they're missing
  → One-click upgrade (khy upgrade / web button)
  → Stripe/Alipay/WeChat Pay
  → Immediate unlock (no restart needed)
```

---

## Pro Tier Value Proposition

**Tagline**: "Everything a serious quant trader needs"

Key differentiators over Free:
1. **Python strategy engine** — Write strategies in pandas/numpy
2. **Real-time data** — No delay, tick-level for futures
3. **Cloud AI** — Access Claude, GPT-4, Doubao without own API keys
4. **Multi-device sync** — Trade on desktop, monitor on mobile
5. **Marketplace** — Buy proven strategies from other traders
6. **Webhooks** — Push signals to WeChat, Telegram, Discord

---

## Enterprise Tier Value Proposition

**Tagline**: "Run your quant fund on KHY-Quant"

Key differentiators over Pro:
1. **Team collaboration** — Share strategies, review trades together
2. **Organizational isolation** — Each team member's data is separate
3. **Custom AI models** — Fine-tune on your own trading data
4. **White-label** — Deploy under your own brand
5. **Compliance tools** — Audit logs, trade approvals, risk limits
6. **Dedicated support** — Named account manager, 4h response SLA
7. **API priority** — 10x rate limits, dedicated endpoints

---

## Implementation: Tier Check Middleware

```javascript
// backend/src/middleware/tierCheck.js
const TIER_LIMITS = {
  free: {
    strategies: 10,
    backtests_monthly: 50,
    ai_requests_monthly: 100,
    storage_mb: 50,
    api_rate_per_min: 30,
    devices: 1,
    languages: ['javascript'],
  },
  pro: {
    strategies: Infinity,
    backtests_monthly: Infinity,
    ai_requests_monthly: 5000,
    storage_mb: 5120,
    api_rate_per_min: 300,
    devices: 5,
    languages: ['javascript', 'python', 'tdx'],
  },
  enterprise: {
    strategies: Infinity,
    backtests_monthly: Infinity,
    ai_requests_monthly: Infinity,
    storage_mb: 102400,
    api_rate_per_min: 3000,
    devices: Infinity,
    languages: ['javascript', 'python', 'tdx', 'custom'],
  },
};

function tierCheck(requiredTier) {
  return (req, res, next) => {
    const userTier = req.user?.subscriptionTier || 'free';
    const tierRank = { free: 0, pro: 1, enterprise: 2 };

    if (tierRank[userTier] >= tierRank[requiredTier]) {
      return next();
    }

    res.status(403).json({
      error: 'upgrade_required',
      message: `This feature requires ${requiredTier} tier`,
      currentTier: userTier,
      requiredTier,
      upgradeUrl: 'https://khyquant.top/pricing',
    });
  };
}
```

---

## Payment Integration

### Supported Providers (Priority Order)

1. **WeChat Pay** — Dominant in China (QR code in terminal)
2. **Alipay** — Secondary Chinese payment
3. **Stripe** — International cards
4. **USDT/Crypto** — Optional for privacy-conscious users

### CLI Payment Flow

```
$ khy upgrade

  ┌─ 升级到 Pro ─────────────────────────┐
  │                                       │
  │  ¥49/月 · 年付 ¥468 (省20%)          │
  │                                       │
  │  选择支付方式:                         │
  │  [1] 微信支付 (扫码)                   │
  │  [2] 支付宝                            │
  │  [3] 国际信用卡 (Stripe)               │
  │                                       │
  │  ▼ 扫描下方二维码                      │
  │  [QR CODE RENDERED IN TERMINAL]        │
  │                                       │
  └───────────────────────────────────────┘
```

---

## Quota Enforcement Strategy

| Approach | Behavior |
|----------|----------|
| **Soft Limit** | Warn at 80%, allow overage up to 120% |
| **Hard Limit** | Block at 100% (backtests, AI) |
| **Graceful** | Degrade (show delayed data instead of blocking) |
| **Carryover** | Unused AI tokens roll over 1 month (Pro only) |

---

## Referral Program

```
Invite a friend → Both get 1 month Pro free
  - Unique referral code per user
  - Track in user profile
  - Cap: 6 months free per user (6 referrals)
  - Display in CLI: "khy invite" generates link
```

---

## Community

- QQ Group: 1083973296
- Website: https://khyquant.top/pricing
