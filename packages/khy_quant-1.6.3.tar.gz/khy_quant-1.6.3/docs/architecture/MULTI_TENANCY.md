# Multi-Tenancy & Enterprise Design

> Enable teams and organizations to collaborate on KHY-Quant with data isolation and access control.

## 1. Organization Model

```
Organization
  ├── Owner (1 user, full control)
  ├── Admins (manage members, settings)
  ├── Traders (create/execute strategies)
  └── Viewers (read-only dashboard access)
```

### Roles & Permissions Matrix

| Permission | Owner | Admin | Trader | Viewer |
|-----------|-------|-------|--------|--------|
| Manage org settings | ✓ | ✓ | - | - |
| Invite/remove members | ✓ | ✓ | - | - |
| Change member roles | ✓ | ✓ | - | - |
| Create strategies | ✓ | ✓ | ✓ | - |
| Run backtests | ✓ | ✓ | ✓ | - |
| Execute trades | ✓ | ✓ | ✓ | - |
| View all trades | ✓ | ✓ | Own only | ✓ |
| Access shared strategies | ✓ | ✓ | ✓ | ✓ |
| View reports | ✓ | ✓ | ✓ | ✓ |
| Manage billing | ✓ | - | - | - |
| Delete organization | ✓ | - | - | - |
| Audit logs | ✓ | ✓ | - | - |
| API key management | ✓ | ✓ | Own only | - |

---

## 2. Data Isolation Strategy

### Row-Level Security

Every data-bearing table gets an `org_id` column:

```sql
-- Middleware automatically filters:
-- SELECT * FROM strategies WHERE org_id = :current_org_id
-- INSERT sets org_id automatically

ALTER TABLE strategies ADD COLUMN org_id INTEGER REFERENCES organizations(id);
ALTER TABLE trades ADD COLUMN org_id INTEGER;
ALTER TABLE backtests ADD COLUMN org_id INTEGER;
ALTER TABLE watchlists ADD COLUMN org_id INTEGER;
ALTER TABLE signals ADD COLUMN org_id INTEGER;
```

### Middleware Implementation

```javascript
// orgIsolationMiddleware.js
function orgIsolation(req, res, next) {
  if (!req.user?.org_id) return next(); // Individual user, no filtering

  // Inject org filter into all queries
  req.orgFilter = { org_id: req.user.org_id };
  // Sequelize scope: Model.scope({ where: req.orgFilter })
  next();
}
```

### Cross-Org Data Access

- **Never** — User data in one org is invisible to another
- **Exception** — Platform admin can view all for support
- **Marketplace** — Published components are global (by design)
- **Shared strategies** — Marked `shared: true` within an org

---

## 3. Organization Lifecycle

### Creation

```
POST /v1/org/create
{
  "name": "Alpha Quant Fund",
  "slug": "alpha-quant",  // unique subdomain: alpha-quant.khyquant.top
}
```

### Invitation Flow

```
[Owner/Admin invites email]
  → System sends invite email/QQ message
  → Invitee clicks link → Register/Login
  → Auto-joined to org with specified role
  → Welcome onboarding for new org members
```

### Offboarding

- When member leaves: their strategies stay (org owns them)
- Member's personal strategies (created before joining) remain with user
- Trade history: anonymized but retained for compliance
- API keys: immediately revoked on removal

---

## 4. Shared Resources

### Strategy Library

- Strategies can be `private` (user only) or `shared` (org-wide)
- Shared strategies have version history
- Fork: any member can fork a shared strategy into their private space
- Merge: propose changes back to shared version (like a PR)

### Trading Accounts

- Org can have multiple connected broker accounts
- Allocation: Admin assigns trading limits per member
- Consolidated P&L dashboard for org-wide performance

### AI Quota

- Org-level AI token pool
- Admin can set per-member allocation
- Overage: charged to org billing

---

## 5. White-Label Deployment

Enterprise tier includes self-hosted option:

```yaml
# White-label configuration
whitelabel:
  brand_name: "Alpha Quant Platform"
  logo_url: "https://alpha-quant.com/logo.png"
  primary_color: "#1a5276"
  domain: "platform.alpha-quant.com"
  support_email: "support@alpha-quant.com"
  hide_khy_branding: true
```

### Deployment Options

| Option | Description | Use Case |
|--------|-------------|----------|
| Cloud (multi-tenant) | Shared infrastructure, data isolation | Most enterprises |
| Dedicated Cloud | Isolated VPC, dedicated DB | Compliance-heavy |
| On-Premise | Docker/K8s in customer's infra | Banks, hedge funds |
| Hybrid | Cloud API + on-prem data | Data sovereignty |

---

## 6. Compliance & Audit

### Audit Log

Every mutation operation is logged:

```json
{
  "timestamp": "2026-05-03T10:30:00Z",
  "org_id": 42,
  "user_id": 123,
  "action": "strategy.execute",
  "resource": "strategy:golden-cross-v2",
  "details": { "symbol": "sh600519", "side": "buy", "qty": 100 },
  "ip": "203.0.113.42",
  "user_agent": "khy-quant-cli/1.3.0"
}
```

### Retention

| Tier | Audit Retention | Trade History |
|------|-----------------|---------------|
| Pro | 90 days | 2 years |
| Enterprise | 7 years | Unlimited |

### Export

- CSV/JSON export of all audit logs
- Compliance report generation (PDF)
- Integration with SIEM systems (Enterprise)

---

## 7. Admin Dashboard

Enterprise admin panel features:

- **Member Management** — Invite, roles, activity status
- **Usage Dashboard** — API calls, backtests, AI tokens per member
- **Cost Center** — Billing breakdown by team/member
- **Strategy Governance** — Approve/review strategies before live trading
- **Risk Limits** — Set max position, daily loss limit per trader
- **Alert Rules** — Notify admins on unusual activity

---

## 8. CLI Multi-Tenancy

```bash
# Switch organization context
khy org switch alpha-quant
khy org list                 # My organizations

# Org management (admin only)
khy org invite user@email.com --role trader
khy org members
khy org settings

# Context indicator in prompt
◉ khy [alpha-quant] ❯ backtest sh600519
```

---

## 9. Database Schema

```sql
CREATE TABLE organizations (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  slug VARCHAR(50) UNIQUE NOT NULL,
  owner_id INTEGER NOT NULL REFERENCES users(id),
  tier VARCHAR(20) DEFAULT 'enterprise',
  max_members INTEGER DEFAULT 10,
  settings JSONB DEFAULT '{}',
  branding JSONB DEFAULT '{}',
  created_at TIMESTAMP DEFAULT NOW(),
  updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE org_members (
  id SERIAL PRIMARY KEY,
  org_id INTEGER NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id INTEGER NOT NULL REFERENCES users(id),
  role VARCHAR(20) NOT NULL DEFAULT 'trader',
  invited_by INTEGER REFERENCES users(id),
  joined_at TIMESTAMP DEFAULT NOW(),
  UNIQUE(org_id, user_id)
);

CREATE TABLE org_invitations (
  id SERIAL PRIMARY KEY,
  org_id INTEGER NOT NULL REFERENCES organizations(id),
  email VARCHAR(255) NOT NULL,
  role VARCHAR(20) NOT NULL DEFAULT 'trader',
  token VARCHAR(64) UNIQUE NOT NULL,
  invited_by INTEGER REFERENCES users(id),
  expires_at TIMESTAMP NOT NULL,
  accepted_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE audit_logs (
  id BIGSERIAL PRIMARY KEY,
  org_id INTEGER REFERENCES organizations(id),
  user_id INTEGER REFERENCES users(id),
  action VARCHAR(100) NOT NULL,
  resource VARCHAR(255),
  details JSONB DEFAULT '{}',
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_audit_org_time ON audit_logs(org_id, created_at DESC);
CREATE INDEX idx_audit_user ON audit_logs(user_id, created_at DESC);
```

---

## Community

- QQ Group: 1083973296
- Enterprise Sales: enterprise@khyquant.top
