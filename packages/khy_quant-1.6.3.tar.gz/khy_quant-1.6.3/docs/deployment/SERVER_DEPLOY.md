# 服务器部署指南

## 一键部署 (推荐)

```bash
# 在服务器上执行 (需要 Docker + Docker Compose)
curl -fsSL https://khyquant.top/install.sh | bash

# 或手动:
git clone https://github.com/khyquant/khy-quant-server.git
cd khy-quant-server
cp .env.example .env        # 编辑配置
docker compose up -d        # 启动所有服务
```

## 架构

```
                   ┌─ Cloudflare (CDN + WAF + DDoS Protection) ─┐
                   │                                              │
                   ▼                                              ▼
              ┌─ nginx ─┐                                   ┌─ nginx ─┐
              │ (前端)   │                                   │ (API)   │
              └────┬─────┘                                   └────┬────┘
                   │                                              │
              ┌────▼─────┐                                   ┌────▼────┐
              │ Vue SPA  │                                   │ Express │
              │ (静态CDN) │                                   │ (x3 副本)│
              └──────────┘                                   └────┬────┘
                                                                  │
                                              ┌───────────────────┼──────────────┐
                                              ▼                   ▼              ▼
                                         ┌─────────┐     ┌──────────┐    ┌──────────┐
                                         │PostgreSQL│     │  Redis   │    │TimescaleDB│
                                         │  (主从)  │     │ (缓存+队列)│    │ (行情数据)│
                                         └─────────┘     └──────────┘    └──────────┘
```

## Docker Compose 配置

```yaml
# docker-compose.production.yml
version: '3.8'

services:
  # ── Frontend (Nginx + Vue SPA) ──
  frontend:
    build: ./frontend
    ports: ['80:80', '443:443']
    volumes:
      - ./nginx/conf.d:/etc/nginx/conf.d:ro
      - ./ssl:/etc/ssl/khy:ro
    restart: always
    depends_on: [api]

  # ── Backend API (Node.js) ──
  api:
    build: ./backend
    environment:
      - NODE_ENV=production
      - DB_HOST=postgres
      - REDIS_URL=redis://redis:6379
      - JWT_SECRET=${JWT_SECRET}
      - DEPLOY_KEY=${DEPLOY_KEY}
    deploy:
      replicas: 3
      resources:
        limits: { cpus: '2', memory: '4G' }
    restart: always
    depends_on:
      postgres: { condition: service_healthy }
      redis: { condition: service_healthy }

  # ── Database ──
  postgres:
    image: postgres:16-alpine
    environment:
      POSTGRES_DB: khyquant
      POSTGRES_USER: khy
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    volumes: [pgdata:/var/lib/postgresql/data]
    healthcheck:
      test: ['CMD-SHELL', 'pg_isready -U khy']
      interval: 10s
    restart: always

  # ── Cache & Queue ──
  redis:
    image: redis:7-alpine
    command: redis-server --requirepass ${REDIS_PASSWORD}
    volumes: [redisdata:/data]
    healthcheck:
      test: ['CMD', 'redis-cli', 'ping']
      interval: 10s
    restart: always

  # ── Worker (Backtest execution) ──
  worker:
    build: ./backend
    command: node src/workers/backtestWorker.js
    environment:
      - NODE_ENV=production
      - DB_HOST=postgres
      - REDIS_URL=redis://redis:6379
    deploy:
      replicas: 2
    restart: always

volumes:
  pgdata:
  redisdata:
```

## 部署密钥保护

**防止任何人用 pip 自行搭建云端服务:**

```javascript
// backend/src/middleware/deployKeyCheck.js
// 服务器启动时验证部署密钥
const DEPLOY_KEY = process.env.DEPLOY_KEY;

function validateDeployKey() {
  if (!DEPLOY_KEY) {
    console.error('FATAL: DEPLOY_KEY not set. Server cannot start.');
    console.error('This is a licensed deployment. Contact enterprise@khyquant.top');
    process.exit(1);
  }

  // Validate key with license server
  // Key is issued per-domain and tied to machine fingerprint
}
```

- pip 安装的是 **CLI 客户端** (连接官方云或本地模式)
- **服务端代码**单独仓库，不在 pip 包中
- 启动服务端需要 `DEPLOY_KEY` (向我们申请)
- 部署密钥绑定域名 + 机器指纹

## 域名 & SSL

```bash
# Cloudflare 托管 DNS
# 自动 SSL (Cloudflare Full Strict)
# 或 Let's Encrypt:
certbot certonly --nginx -d khyquant.top -d api.khyquant.top
```

## 防火墙

```bash
# UFW 基础配置
ufw default deny incoming
ufw allow 22/tcp        # SSH
ufw allow 80/tcp        # HTTP (redirect to HTTPS)
ufw allow 443/tcp       # HTTPS
ufw enable
```

---

## 更新部署

```bash
# 自动更新 (通过 webhook)
# GitHub push → webhook → 服务器 pull + rebuild

# 手动更新
cd /opt/khy-quant
git pull origin main
docker compose build --no-cache
docker compose up -d --remove-orphans

# 回滚
docker compose down
git checkout v1.2.3
docker compose up -d
```

---

QQ 群: 1083973296
