# 自修复系统设计

> KHY-Quant 内置自修复能力，减少人工运维干预。

## 1. CLI 自修复 (本地)

当 CLI 检测到异常时自动尝试修复:

```javascript
// backend/src/services/selfHealing.js
const HEAL_STRATEGIES = {
  // 数据库损坏 → 自动重建
  'db_corrupted': async () => {
    const dbPath = getDbPath();
    fs.renameSync(dbPath, dbPath + '.bak.' + Date.now());
    await initDatabase();
    return '数据库已重建 (旧文件已备份)';
  },

  // node_modules 缺失 → 自动安装
  'missing_deps': async () => {
    execSync('npm install --production', { cwd: ROOT });
    return '依赖已重新安装';
  },

  // 配置文件损坏 → 重置为默认
  'config_corrupted': async () => {
    generateDefaultEnv();
    return '配置文件已重置';
  },

  // 缓存异常 → 清理
  'cache_error': async () => {
    clearAllCaches();
    return '缓存已清理';
  },

  // AI 网关全部失败 → 降级到本地模式
  'ai_all_failed': async () => {
    process.env.GATEWAY_PREFERRED_ADAPTER = 'ollama';
    return '已降级到本地 AI (Ollama)';
  },

  // 端口被占用 → 自动切换
  'port_in_use': async (context) => {
    const newPort = context.port + 1;
    process.env.PORT = String(newPort);
    return `端口 ${context.port} 被占用, 已切换到 ${newPort}`;
  },
};
```

### 触发方式

```bash
# 手动触发
khy doctor --fix        # 检测问题并自动修复
khy repair              # 全面修复

# 自动触发 (启动时)
# 检测到问题 → 提示用户 → 用户确认 → 执行修复
```

---

## 2. 服务端自修复 (Docker)

### 健康检查 + 自动重启

```yaml
# docker-compose.yml
services:
  api:
    healthcheck:
      test: ['CMD', 'curl', '-f', 'http://localhost:3000/health']
      interval: 30s
      timeout: 5s
      retries: 3
      start_period: 10s
    restart: always
    # Docker 会在 healthcheck 失败 3 次后自动重启容器
```

### 应用级健康检查

```javascript
// backend/src/routes/health.js
app.get('/health', async (req, res) => {
  const checks = {
    database: await checkDatabase(),
    redis: await checkRedis(),
    memory: process.memoryUsage().heapUsed < 1.5e9, // < 1.5GB
    uptime: process.uptime() > 0,
  };

  const healthy = Object.values(checks).every(Boolean);
  res.status(healthy ? 200 : 503).json({
    status: healthy ? 'healthy' : 'degraded',
    checks,
    uptime: process.uptime(),
    version: require('../../package.json').version,
  });
});
```

### 自动恢复策略

| 场景 | 检测方式 | 自动操作 |
|------|----------|----------|
| 内存泄漏 | heapUsed > 1.5GB | 优雅重启 worker |
| 数据库连接丢失 | Sequelize ping 失败 | 重建连接池 |
| Redis 断连 | ioredis 错误事件 | 自动重连 (已内置) |
| 磁盘满 | df 检查 | 清理日志 + 告警 |
| 进程卡死 | 30s 无响应 | Docker 重启容器 |
| SSL 证书过期 | certbot timer | 自动续期 |
| 数据库迁移落后 | 版本检查 | 自动执行 migration |

### Watchdog 进程

```javascript
// backend/src/workers/watchdog.js
// 独立于主进程的守护进程

setInterval(async () => {
  // 1. Check API responsiveness
  const apiOk = await pingEndpoint('http://localhost:3000/health');
  if (!apiOk) {
    log.error('API unresponsive, triggering restart');
    execSync('docker compose restart api');
  }

  // 2. Check disk space
  const diskFree = getDiskFreePercent();
  if (diskFree < 10) {
    log.warn('Disk space low, cleaning logs');
    execSync('find /var/log -name "*.log" -mtime +7 -delete');
  }

  // 3. Check memory
  const memUsage = getMemoryUsagePercent();
  if (memUsage > 90) {
    log.warn('Memory high, clearing caches');
    await clearRedisCache('transient:*');
  }

  // 4. Check certificate expiry
  const certExpiry = getCertExpiryDays();
  if (certExpiry < 14) {
    execSync('certbot renew --quiet');
  }
}, 60000); // Every minute
```

---

## 3. 客户端自修复

### pip 安装恢复

```python
# khy_quant/_bootstrap.py 中的修复逻辑
def ensure_bootstrapped(backend_dir, node_cmd):
    """First-run bootstrap + self-healing."""

    # Check node_modules integrity
    marker = backend_dir / 'node_modules' / '.khy_installed'
    if not marker.exists():
        # Auto-install dependencies
        subprocess.run([node_cmd, '-e', 'require("./package.json")'],
                      cwd=str(backend_dir), check=False)
        run_npm_install(backend_dir, node_cmd)

    # Check for corrupted modules
    try:
        subprocess.run([node_cmd, '-e', 'require("chalk")'],
                      cwd=str(backend_dir), capture_output=True,
                      check=True, timeout=5)
    except:
        # Module resolution failed → reinstall
        shutil.rmtree(backend_dir / 'node_modules', ignore_errors=True)
        run_npm_install(backend_dir, node_cmd)
```

### CLI 启动自检

```
[khy 启动]
  → 检查 Node 版本 ✓
  → 检查 node_modules ✓ (缺失则自动安装)
  → 检查配置文件 ✓ (损坏则重生成)
  → 检查数据库 ✓ (损坏则备份+重建)
  → 检查网络连接 → (失败则切本地模式)
  → 一切正常 → 显示 Banner → 进入 REPL
```

---

## 4. 更新时的自修复

```javascript
// 版本升级后首次启动
async function postUpdateHeal() {
  const lastVersion = readLastVersion();
  const currentVersion = require('../../package.json').version;

  if (lastVersion !== currentVersion) {
    log.info(`Upgraded from ${lastVersion} to ${currentVersion}`);

    // Run migrations
    await runPendingMigrations();

    // Clear stale caches
    await clearAllCaches();

    // Rebuild indexes if needed
    await rebuildSearchIndex();

    // Save new version marker
    writeLastVersion(currentVersion);
  }
}
```

---

## 5. 用户可见的修复提示

```
◉ khy ❯ doctor --fix

  💚 KHY-Quant 环境修复

  🔍 检测问题中...
    ✓ Node.js v22.0.0
    ✗ node_modules 不完整 (缺少 chalk)
    ✓ 数据库正常
    ⚠ AI 网关: Claude 不可用

  🔧 自动修复:
    ✓ 已重新安装 node_modules
    ℹ Claude 需要 API key，运行 ai config 配置

  ✓ 修复完成，2 个问题已解决
```

---

QQ 群: 1083973296
