# 更新策略

## 1. 服务端更新 (Docker)

### 零停机更新 (Rolling Update)

```bash
# 拉取最新代码
cd /opt/khy-quant
git pull origin main

# 构建新镜像
docker compose build api worker

# 滚动更新 (逐个替换副本, 不中断服务)
docker compose up -d --no-deps api
docker compose up -d --no-deps worker

# 或一键:
./scripts/deploy.sh
```

### Webhook 自动部署

```bash
# GitHub push → webhook → 服务器自动更新
# POST /deploy/webhook (验证 secret)
# → git pull → docker build → rolling restart
```

### 回滚

```bash
# 快速回滚到上一版本
docker compose down
git checkout HEAD~1
docker compose up -d

# 回滚到指定版本
git checkout v1.3.0
docker compose up -d
```

### 灰度发布

```
1. 新版本先部署到 canary 实例 (5% 流量)
2. 监控 1h 无异常 → 扩展到 50%
3. 再观察 1h → 全量发布
4. 任何异常 → 立即回滚 canary
```

---

## 2. CLI 客户端更新

### pip 用户

```bash
# 检查更新 (CLI 启动时自动检查, 不阻塞)
khy update check

# 执行更新
pip install --upgrade khy-quant

# 或:
khy update install
```

### 自动更新检查

```javascript
// 每次启动时后台检查 (不阻塞 REPL)
async function checkForUpdate() {
  const current = require('../../package.json').version;
  const latest = await fetchLatestVersion(); // from PyPI API

  if (semver.gt(latest, current)) {
    // 非阻塞提示
    printInfo(`新版本 v${latest} 可用，运行 pip install --upgrade khy-quant 更新`);
  }
}
```

### 增量更新

- 大版本 (1.x → 2.x): 需要用户手动 `pip install --upgrade`
- 小版本 (1.3.x → 1.3.y): Skill/Plugin 热更新无需重装
- 远程配置: 通过 `fetchRemoteConfig()` 实时更新功能开关

---

## 3. 前端更新

### SPA 热更新

```javascript
// 前端检测到新版本:
// 1. Service Worker 检测到新资源
// 2. 弹窗提示 "新版本可用, 刷新页面即可"
// 3. 用户刷新 → 新版本立即生效
// 4. 无需重新登录 (token 不变)
```

### CDN 缓存策略

```nginx
# 静态资源: 长期缓存 (带 hash)
location /assets/ {
    expires 1y;
    add_header Cache-Control "public, immutable";
}

# index.html: 不缓存 (每次获取最新)
location / {
    add_header Cache-Control "no-cache, no-store, must-revalidate";
    try_files $uri /index.html;
}
```

---

## 4. 数据库迁移

```bash
# 自动执行 pending migrations
# 在 API 容器启动时自动运行:
npx sequelize-cli db:migrate

# 迁移文件格式:
# backend/migrations/20260503-add-subscription-tier.js
```

### 向后兼容原则

- 新增字段: 带默认值, 不影响旧数据
- 删除字段: 先标记废弃 → 下个版本再删
- 改字段类型: 新建字段 → 迁移数据 → 删旧字段 (三步)

---

## 5. 随 Claude 更新

部分能力可以通过更新上游 AI 模型自动获得:

```javascript
// AI Gateway 自动检测最新可用模型
// 当 Claude 发布新版本:
// 1. Adapter 自动检测 (ideDetector.js)
// 2. 新模型出现在可用列表中
// 3. 用户可立即选择使用
// 无需更新 KHY-Quant 本身
```

- **模型列表**: 从服务端远程获取 (不硬编码)
- **工具定义**: 可远程推送新工具 schema
- **Prompt 优化**: 系统提示词从云端加载, 随时优化

---

QQ 群: 1083973296
