# 安全防护方案

## 1. 网络层防护

### Cloudflare WAF + DDoS

```
用户请求 → Cloudflare (全球 CDN)
  → WAF 规则过滤 (SQL注入/XSS/Bot)
  → DDoS 缓解 (L3/L4/L7)
  → Rate Limiting (全局)
  → 到源站 (API 服务器)
```

### 源站隐藏

- DNS 通过 Cloudflare 代理 (不暴露真实 IP)
- 源站仅允许 Cloudflare IP 访问
- SSH 通过 Cloudflare Tunnel 或跳板机

---

## 2. 应用层防护

### Rate Limiting (分层)

```javascript
// 全局: 100 requests/min per IP
app.use(rateLimit({ windowMs: 60000, max: 100 }));

// 登录: 5 attempts/15min per IP
app.use('/api/auth/login', rateLimit({ windowMs: 900000, max: 5 }));

// AI: Per-tier limits
app.use('/api/ai', tierRateLimit());

// Registration: 3/hour per IP (防止批量注册)
app.use('/api/auth/register', rateLimit({ windowMs: 3600000, max: 3 }));
```

### 输入验证

```javascript
// 所有 API 输入使用 express-validator 白名单验证
// 拒绝未知字段
// 强类型检查
// SQL 注入: Sequelize ORM 参数化查询 (不拼接 SQL)
// XSS: helmet + CSP headers + sanitize-html
```

### 认证安全

| 措施 | 实现 |
|------|------|
| JWT 短过期 | Access Token 15min, Refresh Token 7d |
| Token 轮换 | 每次 refresh 生成新 refresh token |
| WebAuthn | 无密码认证 (硬件密钥/生物识别) |
| CAPTCHA | hCaptcha on registration + failed logins |
| 密码策略 | bcrypt (12 rounds), 最少 8 字符 |
| Session 单一 | 新登录使旧 session 失效 |

---

## 3. 防止 pip 用户私搭服务器

### 策略: 服务端代码分离

```
PyPI 包 (khy-quant):
  - Python launcher (cli.py)
  - Node.js backend (CLI + 本地引擎)
  - 前端静态文件 (可选)
  - ❌ 不包含服务端部署脚本
  - ❌ 不包含 docker-compose
  - ❌ 不包含数据库 migration
  - ❌ 不包含 DEPLOY_KEY 验证逻辑

服务端仓库 (私有):
  - docker-compose.production.yml
  - 数据库 migrations
  - Admin API
  - 计费/支付集成
  - 部署自动化脚本
  - 需要 DEPLOY_KEY 才能启动
```

### DEPLOY_KEY 验证

```javascript
// 服务端启动时:
// 1. 检查 DEPLOY_KEY 环境变量
// 2. 向 license.khyquant.top 验证 key 有效性
// 3. 绑定机器指纹 (MAC + hostname + disk serial)
// 4. 验证失败 → 拒绝启动
// 5. 定期心跳 (24h) 确认仍有效
```

### 混淆保护

```
pip 包中的 JS 代码已混淆 (javascript-obfuscator):
  - RC4 字符串加密
  - 控制流平坦化
  - 死代码注入
  - 变量重命名

即使本地可运行, 想要修改启动一个完整云服务:
  - 缺少数据库 schema / migrations
  - 缺少 Admin API
  - 缺少支付集成
  - 缺少部署密钥
  - 缺少服务端中间件
```

---

## 4. 数据安全

| 数据类型 | 保护措施 |
|----------|----------|
| 密码 | bcrypt hash, 从不明文存储 |
| API Keys | AES-256 加密存储, 仅显示前 4 + 后 4 |
| 交易数据 | 用户级隔离 (org_id), TLS 传输 |
| 用户 Token | httpOnly + Secure + SameSite cookies |
| 备份 | 加密后上传 OSS, 保留 30 天 |
| 日志 | 脱敏 (不记录密码/token/敏感参数) |

---

## 5. 运维安全

```bash
# 服务器基线
- Ubuntu 22.04 LTS (长期维护)
- 定期 apt upgrade
- fail2ban (SSH 暴力破解防护)
- unattended-upgrades (安全补丁自动)
- 非 root 用户运行服务
- Docker rootless mode
- 审计日志 (auditd)
```

---

## 6. 开发模式安全

开发模式下保持云端/单机登录能力:

```javascript
// 开发环境检测
const isDev = process.env.NODE_ENV === 'development';

if (isDev) {
  // 允许本地单机登录 (不需要云端验证)
  // 允许 HTTP (不强制 HTTPS)
  // 降低 rate limit
  // 但仍然需要认证 (不跳过 auth)
}
```

---

QQ 群: 1083973296
