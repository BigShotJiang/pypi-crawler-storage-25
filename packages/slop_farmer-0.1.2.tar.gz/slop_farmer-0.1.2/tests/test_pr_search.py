from __future__ import annotations

import json
import threading
from collections.abc import Mapping
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from slop_farmer.config import PrSearchRefreshOptions
from slop_farmer.data.ghreplica_api import GhrProbeClient
from slop_farmer.data.parquet_io import write_json, write_parquet
from slop_farmer.reports.pr_search_service import (
    explain_pr_search_pair,
    get_pr_search_candidate_clusters,
    get_pr_search_cluster,
    get_pr_search_clusters,
    get_pr_search_contributor,
    get_pr_search_contributor_pulls,
    get_pr_search_pull_contributor,
    get_pr_search_similar,
    get_pr_search_similar_lookup,
    get_pr_search_status,
    list_pr_search_clusters,
    probe_pr_search_github,
    probe_pr_search_live,
    run_pr_search_refresh,
)


def test_pr_search_refresh_materializes_neighbors_and_clusters(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"

    refresh = run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    assert refresh["repo"] == "huggingface/transformers"
    assert refresh["snapshot_id"] == "20260415T000000Z"
    assert refresh["row_counts"]["documents"] == 3
    assert refresh["row_counts"]["clusters"] == 1
    assert refresh["row_counts"]["run_artifacts"] == 1

    similar = get_pr_search_similar(db_path, pr_number=10)
    assert similar["pr"]["title"] == "Fix tokenizer edge case"
    assert [row["neighbor_pr_number"] for row in similar["similar_prs"]] == [11]
    assert similar["similar_prs"][0]["shared_filenames"] == [
        "src/tokenizer.py",
        "tests/test_tokenizer.py",
    ]

    candidate_clusters = get_pr_search_candidate_clusters(db_path, pr_number=10)
    assert len(candidate_clusters["candidate_clusters"]) == 1
    candidate = candidate_clusters["candidate_clusters"][0]
    assert candidate["assigned"] is True
    assert candidate["representative_pr_number"] in {10, 11}
    assert candidate["matched_member_pr_numbers"] == [11]

    cluster = get_pr_search_cluster(db_path, cluster_id=candidate["cluster_id"])
    assert cluster["cluster"]["cluster_size"] == 2
    assert [member["pr_number"] for member in cluster["members"]] == [10, 11]

    status = get_pr_search_status(db_path)
    assert status["repo"] == "huggingface/transformers"
    assert status["row_counts"]["neighbors"] == 1
    assert status["row_counts"]["cluster_members"] == 2
    assert status["row_counts"]["contributors"] == 2


def test_pr_search_contributor_lookup_and_pull_listing(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    contributor = get_pr_search_contributor(db_path, author_login="alice")
    assert contributor["contributor"]["author_login"] == "alice"
    assert contributor["contributor"]["automation_risk_signal"] == "low"
    assert contributor["pull_count"] == 2
    assert [row["pr_number"] for row in contributor["pulls"]] == [11, 10]

    contributor_prs = get_pr_search_contributor_pulls(db_path, author_login="alice", limit=1)
    assert contributor_prs["pull_count"] == 1
    assert contributor_prs["pulls"][0]["pr_number"] == 11

    pr_contributor = get_pr_search_pull_contributor(db_path, pr_number=10)
    assert pr_contributor["contributor"]["author_login"] == "alice"
    assert pr_contributor["pr"]["pr_number"] == 10


def test_pr_search_explain_pair_falls_back_to_feature_scoring(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    explanation = explain_pr_search_pair(
        db_path,
        left_pr_number=10,
        right_pr_number=20,
    )

    assert explanation["materialized"] is False
    assert explanation["pair"]["similarity"] < 0.3
    assert explanation["pair"]["shared_filenames"] == []
    assert explanation["shared_cluster_ids"] == []


def test_pr_search_probe_github_compares_live_pr_against_index(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    result = probe_pr_search_github(
        db_path,
        pr_number=99,
        repo="huggingface/transformers",
        limit=3,
        client=_GitHubProbeClient(),
    )

    assert result["probe_pr"]["pr_number"] == 99
    assert result["similar_prs"][0]["neighbor_pr_number"] == 10
    assert result["candidate_clusters"][0]["cluster_id"].startswith("pr-scope-10-2")

    (snapshot_dir / "pr_files.parquet").unlink()
    cached_result = probe_pr_search_github(
        db_path,
        pr_number=99,
        repo="huggingface/transformers",
        limit=3,
        client=_GitHubProbeClient(),
    )

    assert cached_result["probe_pr"]["pr_number"] == 99
    assert cached_result["similar_prs"][0]["neighbor_pr_number"] == 10
    assert result["similar_prs"][1]["neighbor_pr_number"] == 11
    assert result["similar_prs"][0]["shared_filenames"] == [
        "src/tokenizer.py",
        "tests/test_tokenizer.py",
    ]
    assert result["candidate_clusters"][0]["assigned"] is False
    assert cached_result["candidate_clusters"][0]["cluster_id"].startswith("pr-scope-10-2")


def test_pr_search_probe_live_alias_uses_same_transport_shape(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    result = probe_pr_search_live(
        db_path,
        pr_number=99,
        repo="huggingface/transformers",
        limit=3,
        client=_GitHubProbeClient(),
    )

    assert result["probe_pr"]["pr_number"] == 99
    assert result["similar_prs"][0]["neighbor_pr_number"] == 10


def test_pr_search_probe_live_with_ghreplica_client_includes_probe_source(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    routes = {
        "/v1/github/repos/huggingface/transformers/pulls/99": {
            "id": 999,
            "node_id": "PR_probe_99",
            "number": 99,
            "html_url": "https://example.invalid/pr/99",
            "url": "https://api.example.invalid/pr/99",
            "title": "Fix tokenizer edge case live probe",
            "body": "Probe query",
            "state": "open",
            "state_reason": None,
            "locked": False,
            "comments": 0,
            "labels": [],
            "assignees": [],
            "created_at": "2026-04-15T00:00:00Z",
            "updated_at": "2026-04-15T00:00:00Z",
            "closed_at": None,
            "author_association": "NONE",
            "merged_at": None,
            "merge_commit_sha": None,
            "merged": False,
            "mergeable": True,
            "mergeable_state": "clean",
            "draft": False,
            "additions": 11,
            "deletions": 1,
            "changed_files": 2,
            "commits": 1,
            "review_comments": 0,
            "maintainer_can_modify": True,
            "head": {"ref": "probe", "sha": "headsha", "repo": {"full_name": "probe/repo"}},
            "base": {"ref": "main", "sha": "basesha", "repo": {"full_name": "upstream/repo"}},
            "user": {"login": "probe-user", "id": 1, "node_id": "U_1", "type": "User"},
        },
        "/v1/changes/repos/huggingface/transformers/pulls/99/files": [
            {
                "path": "src/tokenizer.py",
                "status": "modified",
                "additions": 6,
                "deletions": 0,
                "changes": 6,
                "patch": _patch(11, 6),
            },
            {
                "path": "tests/test_tokenizer.py",
                "status": "modified",
                "additions": 4,
                "deletions": 0,
                "changes": 4,
                "patch": _patch(27, 4),
            },
        ],
        "/v1/changes/repos/huggingface/transformers/pulls/99/status": {
            "indexed": True,
            "index_freshness": "stale_head_changed",
            "last_indexed_at": "2026-04-15T18:39:16.306232Z",
        },
    }
    with _json_server(routes) as base_url:
        result = probe_pr_search_live(
            db_path,
            pr_number=99,
            repo="huggingface/transformers",
            limit=3,
            client=GhrProbeClient(base_url=base_url),
        )

    assert result["probe_pr"]["pr_number"] == 99
    assert result["similar_prs"][0]["neighbor_pr_number"] == 10
    assert result["probe_source"] == {
        "provider": "ghreplica",
        "base_url": base_url,
        "indexed": True,
        "index_freshness": "stale_head_changed",
        "last_indexed_at": "2026-04-15T18:39:16.306232Z",
    }


def test_pr_search_similar_lookup_auto_falls_back_to_live(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    result = get_pr_search_similar_lookup(
        db_path,
        pr_number=99,
        repo="huggingface/transformers",
        limit=3,
        client=_GitHubProbeClient(),
    )

    assert result["query"] == {
        "pr_number": 99,
        "mode_requested": "auto",
        "mode_used": "live",
        "source": "live",
    }
    assert result["pr"]["pr_number"] == 99
    assert result["similar_prs"][0]["neighbor_pr_number"] == 10


def test_pr_search_clusters_returns_assigned_and_candidate_clusters(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    result = get_pr_search_clusters(db_path, pr_number=10)

    assert result["query"]["mode_used"] == "indexed"
    assert result["assigned_clusters"][0]["cluster_id"].startswith("pr-scope-10-2")
    assert result["candidate_clusters"][0]["cluster_id"].startswith("pr-scope-10-2")
    assert result["assigned_cluster_count"] == 1
    assert result["candidate_cluster_count"] == 1


def test_pr_search_cluster_list_returns_clusters(tmp_path) -> None:
    snapshot_dir = _write_snapshot(tmp_path)
    db_path = tmp_path / "state" / "pr-search.duckdb"
    run_pr_search_refresh(
        PrSearchRefreshOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            db=db_path,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    result = list_pr_search_clusters(db_path, limit=10)

    assert result["repo"] == "huggingface/transformers"
    assert result["cluster_count"] == 1
    assert len(result["clusters"]) == 1
    assert result["clusters"][0]["rank"] == 1
    assert result["clusters"][0]["cluster_id"].startswith("pr-scope-10-2")
    assert result["clusters"][0]["representative_title"]


def _write_snapshot(tmp_path):
    snapshot_dir = tmp_path / "snapshots" / "20260415T000000Z"
    snapshot_dir.mkdir(parents=True)
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260415T000000Z",
        },
        snapshot_dir / "manifest.json",
    )
    write_parquet(
        [
            {
                **_pr_row(
                    10,
                    title="Fix tokenizer edge case",
                    state="open",
                    draft=False,
                    additions=10,
                    deletions=2,
                    changed_files=2,
                    author_login="alice",
                ),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_row(
                    11,
                    title="Fix tokenizer cache edge case",
                    state="open",
                    draft=False,
                    additions=9,
                    deletions=3,
                    changed_files=2,
                    author_login="alice",
                ),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_row(
                    20,
                    title="Refactor modeling utils",
                    state="open",
                    draft=False,
                    additions=12,
                    deletions=4,
                    changed_files=1,
                    author_login="bob",
                ),
                "repo": "huggingface/transformers",
            },
        ],
        snapshot_dir / "pull_requests.parquet",
        "pull_requests",
    )
    write_parquet(
        [
            _contributor_row("alice", snapshot_pr_count=2, risk="low"),
            _contributor_row("bob", snapshot_pr_count=1, risk="medium"),
        ],
        snapshot_dir / "new_contributors.parquet",
        "new_contributors",
    )
    write_parquet(
        [
            {
                **_pr_file_row(10, "src/tokenizer.py", start=10, count=6),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_file_row(10, "tests/test_tokenizer.py", start=25, count=4),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_file_row(11, "src/tokenizer.py", start=12, count=5),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_file_row(11, "tests/test_tokenizer.py", start=28, count=4),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_file_row(20, "src/modeling_utils.py", start=180, count=8),
                "repo": "huggingface/transformers",
            },
        ],
        snapshot_dir / "pr_files.parquet",
        "pr_files",
    )
    return snapshot_dir


def _pr_row(
    number: int,
    *,
    title: str,
    state: str,
    draft: bool,
    additions: int,
    deletions: int,
    changed_files: int,
    author_login: str,
) -> dict[str, object]:
    return {
        "number": number,
        "title": title,
        "state": state,
        "draft": draft,
        "merged": False,
        "additions": additions,
        "deletions": deletions,
        "changed_files": changed_files,
        "comments_count": 0,
        "review_comments_count": 0,
        "html_url": f"https://example.invalid/pr/{number}",
        "base_ref": "main",
        "created_at": "2026-04-15T00:00:00Z",
        "updated_at": "2026-04-15T00:00:00Z",
        "merged_at": None,
        "author_login": author_login,
    }


def _pr_file_row(pr_number: int, filename: str, *, start: int, count: int) -> dict[str, object]:
    return {
        "pull_request_number": pr_number,
        "filename": filename,
        "additions": count,
        "deletions": 0,
        "changes": count,
        "patch": _patch(start, count),
    }


def _patch(start: int, count: int) -> str:
    header = f"@@ -1,{count} +{start},{count} @@"
    body = "\n".join(f"+line_{index}" for index in range(count))
    return f"{header}\n{body}"


def _contributor_row(login: str, *, snapshot_pr_count: int, risk: str) -> dict[str, object]:
    return {
        "repo": "huggingface/transformers",
        "snapshot_id": "20260415T000000Z",
        "report_generated_at": "2026-04-15T00:00:00Z",
        "window_days": 42,
        "author_login": login,
        "name": login.title(),
        "profile_url": f"https://github.com/{login}",
        "repo_pull_requests_url": f"https://github.com/huggingface/transformers/pulls?q=author%3A{login}",
        "repo_issues_url": f"https://github.com/huggingface/transformers/issues?q=author%3A{login}",
        "repo_first_seen_at": "2026-04-15T00:00:00Z",
        "repo_last_seen_at": "2026-04-15T00:00:00Z",
        "repo_primary_artifact_count": snapshot_pr_count,
        "repo_artifact_count": snapshot_pr_count,
        "snapshot_issue_count": 0,
        "snapshot_pr_count": snapshot_pr_count,
        "snapshot_comment_count": 0,
        "snapshot_review_count": 0,
        "snapshot_review_comment_count": 0,
        "repo_association": "CONTRIBUTOR",
        "new_to_repo": True,
        "first_seen_in_snapshot": True,
        "report_reason": "first_seen_in_snapshot",
        "account_age_days": 120,
        "young_account": True,
        "follow_through_score": "strong",
        "breadth_score": "low",
        "automation_risk_signal": risk,
        "heuristic_note": "note",
        "public_orgs": ["org-a"] if login == "alice" else [],
        "visible_authored_pr_count": snapshot_pr_count,
        "merged_pr_count": 0,
        "closed_unmerged_pr_count": 0,
        "open_pr_count": snapshot_pr_count,
        "merged_pr_rate": 0.0,
        "closed_unmerged_pr_rate": 0.0,
        "still_open_pr_rate": 1.0,
        "distinct_repos_with_authored_prs": 1,
        "distinct_repos_with_open_prs": 1,
        "fetch_error": None,
    }


class _GitHubProbeClient:
    def get_pull_request(self, owner: str, repo: str, number: int) -> dict[str, object]:
        assert (owner, repo, number) == ("huggingface", "transformers", 99)
        return {
            "id": 999,
            "node_id": "PR_probe_99",
            "number": 99,
            "html_url": "https://example.invalid/pr/99",
            "url": "https://api.example.invalid/pr/99",
            "title": "Fix tokenizer edge case live probe",
            "body": "Probe query",
            "state": "open",
            "state_reason": None,
            "locked": False,
            "comments": 0,
            "labels": [],
            "assignees": [],
            "created_at": "2026-04-15T00:00:00Z",
            "updated_at": "2026-04-15T00:00:00Z",
            "closed_at": None,
            "author_association": "NONE",
            "merged_at": None,
            "merge_commit_sha": None,
            "merged": False,
            "mergeable": True,
            "mergeable_state": "clean",
            "draft": False,
            "additions": 11,
            "deletions": 1,
            "changed_files": 2,
            "commits": 1,
            "review_comments": 0,
            "maintainer_can_modify": True,
            "head": {"ref": "probe", "sha": "headsha", "repo": {"full_name": "probe/repo"}},
            "base": {"ref": "main", "sha": "basesha", "repo": {"full_name": "upstream/repo"}},
            "user": {"login": "probe-user", "id": 1, "node_id": "U_1", "type": "User"},
        }

    def iter_pull_files(self, owner: str, repo: str, number: int):
        assert (owner, repo, number) == ("huggingface", "transformers", 99)
        yield {
            "sha": "sha1",
            "filename": "src/tokenizer.py",
            "status": "modified",
            "additions": 6,
            "deletions": 0,
            "changes": 6,
            "blob_url": None,
            "raw_url": None,
            "contents_url": None,
            "previous_filename": None,
            "patch": _patch(11, 6),
        }
        yield {
            "sha": "sha2",
            "filename": "tests/test_tokenizer.py",
            "status": "modified",
            "additions": 4,
            "deletions": 0,
            "changes": 4,
            "blob_url": None,
            "raw_url": None,
            "contents_url": None,
            "previous_filename": None,
            "patch": _patch(27, 4),
        }


@contextmanager
def _json_server(routes: Mapping[str, object]):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            payload = routes.get(self.path)
            if payload is None:
                self.send_response(404)
                self.end_headers()
                return
            body = json.dumps(payload).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, format: str, *args: object) -> None:
            del format, args

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_address[1]}"
    finally:
        server.shutdown()
        thread.join()
        server.server_close()
