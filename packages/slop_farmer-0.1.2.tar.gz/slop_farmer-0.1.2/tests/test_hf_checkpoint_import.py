from pathlib import Path
from typing import Any

import pyarrow as pa
import pyarrow.parquet as pq

from slop_farmer.app.hf_checkpoint_import import (
    _select_checkpoint,
    materialize_checkpoint_snapshot,
)
from slop_farmer.data.parquet_io import read_json, read_parquet_rows, write_parquet


def test_select_checkpoint_prefers_latest_viable_checkpoint() -> None:
    siblings = [
        "_checkpoints/20260325T020023Z/issues.parquet",
        "_checkpoints/20260325T020023Z/pull_requests.parquet",
        "_checkpoints/20260325T020023Z/comments.parquet",
        "_checkpoints/20260325T020023Z/reviews.parquet",
        "_checkpoints/20260325T020023Z/review_comments.parquet",
        "_checkpoints/20260325T020023Z/pr_files.parquet",
        "_checkpoints/20260325T020023Z/pr_diffs.parquet",
        "_checkpoints/20260325T020023Z/events.parquet",
        "checkpoints/20260320T095625Z/issues.parquet",
        "checkpoints/20260320T095625Z/pull_requests.parquet",
        "checkpoints/20260320T095625Z/comments.parquet",
        "checkpoints/20260320T095625Z/reviews.parquet",
        "checkpoints/20260320T095625Z/review_comments.parquet",
        "checkpoints/20260320T095625Z/pr_files.parquet",
        "checkpoints/20260320T095625Z/pr_diffs.parquet",
        "checkpoints/20260320T095625Z/events.parquet",
    ]

    checkpoint_root, checkpoint_id = _select_checkpoint(
        siblings, checkpoint_id=None, checkpoint_root=None
    )

    assert checkpoint_root == "_checkpoints"
    assert checkpoint_id == "20260325T020023Z"


def test_materialize_checkpoint_snapshot_writes_clean_snapshot(tmp_path: Path) -> None:
    source_dir = tmp_path / "source"
    source_dir.mkdir()
    checkpoint_files = _write_checkpoint_files(source_dir)

    snapshot_dir = materialize_checkpoint_snapshot(
        checkpoint_files,
        output_root=tmp_path / "imported",
        source_repo_id="burtenshaw/transformers-pr-slop-dataset",
        checkpoint_root="_checkpoints",
        checkpoint_id="20260325T020023Z",
        source_manifest={
            "repo": "huggingface/transformers",
            "extracted_at": "2026-03-25T02:00:23Z",
        },
        source_progress={
            "counts": {
                "issues": 1,
                "pull_requests": 2,
            }
        },
    )

    manifest = read_json(snapshot_dir / "manifest.json")
    issues = read_parquet_rows(snapshot_dir / "issues.parquet")
    pull_requests = read_parquet_rows(snapshot_dir / "pull_requests.parquet")
    links = read_parquet_rows(snapshot_dir / "links.parquet")
    issue_comments = read_parquet_rows(snapshot_dir / "issue_comments.parquet")
    pr_comments = read_parquet_rows(snapshot_dir / "pr_comments.parquet")

    assert snapshot_dir.name == "hf-burtenshaw--transformers-pr-slop-dataset-20260325T020023Z"
    assert manifest["repo"] == "huggingface/transformers"
    assert manifest["snapshot_id"] == "20260325T020023Z"
    assert manifest["source_hf_repo_id"] == "burtenshaw/transformers-pr-slop-dataset"
    assert manifest["source_checkpoint_root"] == "_checkpoints"
    assert manifest["counts"]["links"] >= 3
    assert issues[0]["author_association"] is None
    assert pull_requests[0]["author_association"] is None
    assert {row["link_type"] for row in links} >= {
        "closing_reference",
        "shared_issue_target",
        "timeline:cross-referenced",
    }
    assert len(issue_comments) == 1
    assert len(pr_comments) == 1


def _write_checkpoint_files(source_dir: Path) -> dict[str, Path]:
    issue_rows = [
        {
            "repo": "huggingface/transformers",
            "github_id": 1,
            "github_node_id": "I_1",
            "number": 1,
            "html_url": "https://example.com/issues/1",
            "api_url": "https://api.example.com/issues/1",
            "title": "Tokenizer bug",
            "body": "Crash on empty input.",
            "state": "open",
            "state_reason": None,
            "locked": False,
            "comments_count": 1,
            "labels": [],
            "assignees": [],
            "created_at": "2026-03-25T01:00:00Z",
            "updated_at": "2026-03-25T01:00:00Z",
            "closed_at": None,
            "milestone_title": None,
            "snapshot_id": "20260325T020023Z",
            "extracted_at": "2026-03-25T02:00:23Z",
            "author_login": "alice",
            "author_id": 10,
            "author_node_id": "U_10",
            "author_type": "User",
            "author_site_admin": False,
        }
    ]
    pull_request_rows = [
        {
            "repo": "huggingface/transformers",
            "github_id": 10,
            "github_node_id": "PR_10",
            "number": 10,
            "html_url": "https://example.com/pulls/10",
            "api_url": "https://api.example.com/pulls/10",
            "title": "Fix tokenizer crash",
            "body": "Fixes #1",
            "state": "open",
            "state_reason": None,
            "locked": False,
            "comments_count": 1,
            "labels": [],
            "assignees": [],
            "created_at": "2026-03-25T01:00:00Z",
            "updated_at": "2026-03-25T01:00:00Z",
            "closed_at": None,
            "merged_at": None,
            "merge_commit_sha": None,
            "merged": False,
            "mergeable": True,
            "mergeable_state": "clean",
            "draft": False,
            "additions": 6,
            "deletions": 1,
            "changed_files": 1,
            "commits": 1,
            "review_comments_count": 0,
            "maintainer_can_modify": True,
            "head_ref": "branch-10",
            "head_sha": "head-10",
            "head_repo_full_name": "fork/repo",
            "base_ref": "main",
            "base_sha": "base-10",
            "base_repo_full_name": "huggingface/transformers",
            "snapshot_id": "20260325T020023Z",
            "extracted_at": "2026-03-25T02:00:23Z",
            "author_login": "alice",
            "author_id": 10,
            "author_node_id": "U_10",
            "author_type": "User",
            "author_site_admin": False,
        },
        {
            "repo": "huggingface/transformers",
            "github_id": 11,
            "github_node_id": "PR_11",
            "number": 11,
            "html_url": "https://example.com/pulls/11",
            "api_url": "https://api.example.com/pulls/11",
            "title": "Alternate tokenizer fix",
            "body": "Fixes #1",
            "state": "open",
            "state_reason": None,
            "locked": False,
            "comments_count": 1,
            "labels": [],
            "assignees": [],
            "created_at": "2026-03-25T01:05:00Z",
            "updated_at": "2026-03-25T01:05:00Z",
            "closed_at": None,
            "merged_at": None,
            "merge_commit_sha": None,
            "merged": False,
            "mergeable": True,
            "mergeable_state": "clean",
            "draft": False,
            "additions": 5,
            "deletions": 1,
            "changed_files": 1,
            "commits": 1,
            "review_comments_count": 0,
            "maintainer_can_modify": True,
            "head_ref": "branch-11",
            "head_sha": "head-11",
            "head_repo_full_name": "fork/repo",
            "base_ref": "main",
            "base_sha": "base-11",
            "base_repo_full_name": "huggingface/transformers",
            "snapshot_id": "20260325T020023Z",
            "extracted_at": "2026-03-25T02:00:23Z",
            "author_login": "bob",
            "author_id": 11,
            "author_node_id": "U_11",
            "author_type": "User",
            "author_site_admin": False,
        },
    ]

    _write_old_schema_parquet(
        source_dir / "issues.parquet", "issues", issue_rows, missing_field="author_association"
    )
    _write_old_schema_parquet(
        source_dir / "pull_requests.parquet",
        "pull_requests",
        pull_request_rows,
        missing_field="author_association",
    )
    write_parquet(
        [
            {
                "repo": "huggingface/transformers",
                "github_id": 100,
                "github_node_id": "C_100",
                "parent_kind": "issue",
                "parent_number": 1,
                "html_url": "https://example.com/comments/100",
                "api_url": "https://api.example.com/comments/100",
                "issue_api_url": "https://api.example.com/issues/1",
                "body": "Also affects tokenizer edge cases.",
                "created_at": "2026-03-25T01:10:00Z",
                "updated_at": "2026-03-25T01:10:00Z",
                "author_association": "CONTRIBUTOR",
                "snapshot_id": "20260325T020023Z",
                "extracted_at": "2026-03-25T02:00:23Z",
                "author_login": "eve",
                "author_id": 100,
                "author_node_id": "U_100",
                "author_type": "User",
                "author_site_admin": False,
            },
            {
                "repo": "huggingface/transformers",
                "github_id": 101,
                "github_node_id": "C_101",
                "parent_kind": "pull_request",
                "parent_number": 10,
                "html_url": "https://example.com/comments/101",
                "api_url": "https://api.example.com/comments/101",
                "issue_api_url": "https://api.example.com/issues/10",
                "body": "Fixes #1 confirmed.",
                "created_at": "2026-03-25T01:11:00Z",
                "updated_at": "2026-03-25T01:11:00Z",
                "author_association": "CONTRIBUTOR",
                "snapshot_id": "20260325T020023Z",
                "extracted_at": "2026-03-25T02:00:23Z",
                "author_login": "mallory",
                "author_id": 101,
                "author_node_id": "U_101",
                "author_type": "User",
                "author_site_admin": False,
            },
        ],
        source_dir / "comments.parquet",
        "comments",
    )
    write_parquet([], source_dir / "reviews.parquet", "reviews")
    write_parquet([], source_dir / "review_comments.parquet", "review_comments")
    write_parquet(
        [
            {
                "repo": "huggingface/transformers",
                "pull_request_number": 10,
                "sha": "sha-10",
                "filename": "src/tokenizer.py",
                "status": "modified",
                "additions": 6,
                "deletions": 1,
                "changes": 7,
                "blob_url": "https://example.com/blob/src/tokenizer.py",
                "raw_url": "https://example.com/raw/src/tokenizer.py",
                "contents_url": "https://api.example.com/contents/src/tokenizer.py",
                "previous_filename": None,
                "patch": "@@ -1,1 +10,6 @@\n+line",
                "snapshot_id": "20260325T020023Z",
                "extracted_at": "2026-03-25T02:00:23Z",
            }
        ],
        source_dir / "pr_files.parquet",
        "pr_files",
    )
    write_parquet(
        [
            {
                "repo": "huggingface/transformers",
                "pull_request_number": 10,
                "html_url": "https://example.com/pulls/10",
                "api_url": "https://api.example.com/pulls/10",
                "diff": "@@ -1,1 +10,6 @@\n+line",
                "snapshot_id": "20260325T020023Z",
                "extracted_at": "2026-03-25T02:00:23Z",
            }
        ],
        source_dir / "pr_diffs.parquet",
        "pr_diffs",
    )
    write_parquet(
        [
            {
                "repo": "huggingface/transformers",
                "parent_kind": "pull_request",
                "parent_number": 10,
                "event": "cross-referenced",
                "created_at": "2026-03-25T01:12:00Z",
                "actor_login": "maintainer",
                "source_issue_number": 1,
                "source_issue_title": "Tokenizer bug",
                "source_issue_url": "https://example.com/issues/1",
                "commit_id": None,
                "label_name": None,
                "snapshot_id": "20260325T020023Z",
                "extracted_at": "2026-03-25T02:00:23Z",
            }
        ],
        source_dir / "events.parquet",
        "events",
    )
    return {
        f"{name}.parquet": source_dir / f"{name}.parquet"
        for name in (
            "issues",
            "pull_requests",
            "comments",
            "reviews",
            "review_comments",
            "pr_files",
            "pr_diffs",
            "events",
        )
    }


def _write_old_schema_parquet(
    path: Path, table_name: str, rows: list[dict[str, Any]], *, missing_field: str
) -> None:
    fields = [field for field in read_schema(table_name) if field.name != missing_field]
    table = pa.Table.from_pylist(
        [{field.name: row.get(field.name) for field in fields} for row in rows],
        schema=pa.schema(fields),
    )
    path.parent.mkdir(parents=True, exist_ok=True)
    pq.write_table(table, path)


def read_schema(table_name: str) -> pa.Schema:
    from slop_farmer.data.parquet_io import SCHEMAS

    return SCHEMAS[table_name]
