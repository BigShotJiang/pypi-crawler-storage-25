from __future__ import annotations

import http.client
from contextlib import nullcontext

import pytest

from slop_farmer.data.http import urlopen_with_retry


def test_urlopen_with_retry_retries_remote_disconnect() -> None:
    attempts = {"count": 0}

    def opener(request, timeout=0):  # type: ignore[no-untyped-def]
        attempts["count"] += 1
        if attempts["count"] < 3:
            raise http.client.RemoteDisconnected("boom")
        return nullcontext("ok")

    with urlopen_with_retry(
        "https://example.com", timeout=1, max_retries=3, opener=opener, sleep=lambda _seconds: None
    ) as response:
        assert response == "ok"

    assert attempts["count"] == 3


def test_urlopen_with_retry_raises_after_retry_budget() -> None:
    def opener(request, timeout=0):  # type: ignore[no-untyped-def]
        raise http.client.RemoteDisconnected("boom")

    with pytest.raises(RuntimeError, match="after 2 retries"):
        urlopen_with_retry(
            "https://example.com",
            timeout=1,
            max_retries=2,
            opener=opener,
            sleep=lambda _seconds: None,
        )
