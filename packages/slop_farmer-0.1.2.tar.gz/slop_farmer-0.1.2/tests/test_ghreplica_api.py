from __future__ import annotations

import json
import threading
from collections.abc import Mapping
from contextlib import contextmanager
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from slop_farmer.data.ghreplica_api import GhReplicaProbeUnavailableError, GhrProbeClient

RoutePayload = object | tuple[int, object]


def test_ghreplica_probe_client_maps_probe_endpoints() -> None:
    routes = {
        "/v1/github/repos/evalstate/fast-agent/pulls/7": {
            "number": 7,
            "title": "Add smoke test",
            "state": "open",
        },
        "/v1/changes/repos/evalstate/fast-agent/pulls/7/files": [
            {
                "path": "src/cli.py",
                "status": "modified",
                "additions": 8,
                "deletions": 3,
                "patch": "@@ -1,2 +1,2 @@\n-old\n+new",
            }
        ],
        "/v1/changes/repos/evalstate/fast-agent/pulls/7/status": {
            "indexed": True,
            "index_freshness": "fresh",
            "last_indexed_at": "2026-04-16T12:00:00Z",
        },
    }
    with _json_server(routes) as base_url:
        client = GhrProbeClient(base_url=base_url)

        pr = client.get_pull_request("evalstate", "fast-agent", 7)
        files = list(client.iter_pull_files("evalstate", "fast-agent", 7))
        status = client.get_pull_request_status("evalstate", "fast-agent", 7)

    assert pr["title"] == "Add smoke test"
    assert files == [
        {
            "sha": None,
            "filename": "src/cli.py",
            "status": "modified",
            "additions": 8,
            "deletions": 3,
            "changes": 11,
            "blob_url": None,
            "raw_url": None,
            "contents_url": None,
            "previous_filename": None,
            "patch": "@@ -1,2 +1,2 @@\n-old\n+new",
        }
    ]
    assert status == {
        "indexed": True,
        "index_freshness": "fresh",
        "last_indexed_at": "2026-04-16T12:00:00Z",
    }


def test_ghreplica_probe_client_reports_missing_files_more_clearly() -> None:
    routes = {
        "/v1/github/repos/evalstate/fast-agent/pulls/7": {
            "number": 7,
            "title": "Add smoke test",
            "state": "open",
        },
        "/v1/changes/repos/evalstate/fast-agent/pulls/7/files": (404, {"message": "Not Found"}),
        "/v1/changes/repos/evalstate/fast-agent/pulls/7/status": {
            "indexed": False,
            "backfill_in_progress": True,
            "changed_files": 0,
            "indexed_file_count": 0,
        },
    }
    with _json_server(routes) as base_url:
        client = GhrProbeClient(base_url=base_url)
        try:
            list(client.iter_pull_files("evalstate", "fast-agent", 7))
        except GhReplicaProbeUnavailableError as exc:
            assert exc.status_code == 503
            assert (
                str(exc) == "PR #7 is not available in ghreplica yet (indexed=False, "
                "backfill_in_progress=True, changed_files=0, indexed_file_count=0)."
            )
        else:
            raise AssertionError("Expected GhReplicaProbeUnavailableError")


@contextmanager
def _json_server(routes: Mapping[str, RoutePayload]):
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:
            payload = routes.get(self.path)
            if payload is None:
                self.send_response(404)
                self.end_headers()
                return
            status_code, body_obj = _route_response(payload)
            body = json.dumps(body_obj).encode("utf-8")
            self.send_response(status_code)
            self.send_header("Content-Type", "application/json")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, format: str, *args: object) -> None:
            del format, args

    server = ThreadingHTTPServer(("127.0.0.1", 0), Handler)
    thread = threading.Thread(target=server.serve_forever, daemon=True)
    thread.start()
    try:
        yield f"http://127.0.0.1:{server.server_address[1]}"
    finally:
        server.shutdown()
        thread.join()
        server.server_close()


def _route_response(payload: RoutePayload) -> tuple[int, object]:
    if isinstance(payload, tuple):
        if len(payload) != 2 or not isinstance(payload[0], int):
            raise TypeError(f"invalid route payload: {payload!r}")
        return payload[0], payload[1]
    return 200, payload
