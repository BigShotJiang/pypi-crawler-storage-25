from slop_farmer.config import PrScopeOptions
from slop_farmer.data.parquet_io import read_json, write_json, write_parquet
from slop_farmer.reports.pr_scope import build_pr_scope_clusters, run_pr_scope_report


def test_build_pr_scope_clusters_groups_open_prs_with_exact_file_overlap() -> None:
    pull_requests = [
        _pr_row(10, state="open", draft=False, additions=10, deletions=2, changed_files=2),
        _pr_row(11, state="open", draft=False, additions=9, deletions=3, changed_files=2),
        _pr_row(20, state="open", draft=False, additions=12, deletions=4, changed_files=1),
        _pr_row(99, state="closed", draft=False, additions=10, deletions=2, changed_files=2),
    ]
    pr_files = [
        _pr_file_row(10, "src/tokenizer.py", start=10, count=6),
        _pr_file_row(10, "tests/test_tokenizer.py", start=25, count=4),
        _pr_file_row(11, "src/tokenizer.py", start=12, count=5),
        _pr_file_row(11, "tests/test_tokenizer.py", start=28, count=4),
        _pr_file_row(20, "src/modeling_utils.py", start=180, count=8),
        _pr_file_row(99, "src/tokenizer.py", start=10, count=6),
        _pr_file_row(99, "tests/test_tokenizer.py", start=25, count=4),
    ]

    clusters = build_pr_scope_clusters(pull_requests, pr_files)

    assert [cluster.pr_numbers for cluster in clusters] == [[10, 11]]
    assert clusters[0].representative_pr_number in {10, 11}
    assert "src/tokenizer.py" in clusters[0].shared_filenames
    assert clusters[0].pairwise[0].similarity >= 0.6


def test_build_pr_scope_clusters_uses_directory_overlap_when_files_differ() -> None:
    pull_requests = [
        _pr_row(30, state="open", draft=False, additions=12, deletions=2, changed_files=2),
        _pr_row(31, state="open", draft=False, additions=11, deletions=3, changed_files=2),
        _pr_row(40, state="open", draft=False, additions=14, deletions=3, changed_files=1),
    ]
    pr_files = [
        _pr_file_row(30, "src/tokenizers/fast.py", start=20, count=7),
        _pr_file_row(30, "tests/tokenizers/test_fast.py", start=10, count=4),
        _pr_file_row(31, "src/tokenizers/slow.py", start=24, count=7),
        _pr_file_row(31, "tests/tokenizers/test_slow.py", start=12, count=4),
        _pr_file_row(40, "src/models/llama/modeling_llama.py", start=200, count=10),
    ]

    clusters = build_pr_scope_clusters(pull_requests, pr_files)

    assert [cluster.pr_numbers for cluster in clusters] == [[30, 31]]
    assert "src/tokenizers" in clusters[0].shared_directories
    assert clusters[0].pairwise[0].shared_filenames == []
    assert clusters[0].pairwise[0].similarity >= 0.4


def test_build_pr_scope_clusters_downweights_ubiquitous_files() -> None:
    pull_requests = [
        _pr_row(50, state="open", draft=False, additions=6, deletions=1, changed_files=2),
        _pr_row(51, state="open", draft=False, additions=9, deletions=2, changed_files=2),
        _pr_row(52, state="open", draft=False, additions=10, deletions=2, changed_files=2),
    ]
    pr_files = [
        _pr_file_row(50, "README.md", start=1, count=2),
        _pr_file_row(50, "docs/faq.md", start=40, count=5),
        _pr_file_row(51, "README.md", start=3, count=2),
        _pr_file_row(51, "src/tokenizers/a.py", start=60, count=7),
        _pr_file_row(52, "README.md", start=5, count=2),
        _pr_file_row(52, "src/tokenizers/b.py", start=65, count=7),
    ]

    clusters = build_pr_scope_clusters(pull_requests, pr_files)

    assert [cluster.pr_numbers for cluster in clusters] == [[51, 52]]
    assert "README.md" not in clusters[0].shared_filenames
    assert "src/tokenizers" in clusters[0].shared_directories


def test_build_pr_scope_clusters_skips_suppressed_routine_release_prs() -> None:
    pull_requests = [
        _pr_row(60, state="open", draft=False, additions=6, deletions=1, changed_files=2)
        | {"title": "post release 0.1.0", "body": "automation"},
        _pr_row(70, state="open", draft=False, additions=10, deletions=2, changed_files=2)
        | {"title": "Fix tokenizer cache", "body": "real work"},
        _pr_row(71, state="open", draft=False, additions=9, deletions=3, changed_files=2)
        | {"title": "Fix tokenizer cache path", "body": "real work"},
        _pr_row(80, state="open", draft=False, additions=12, deletions=4, changed_files=1)
        | {"title": "Refactor modeling utils", "body": "different work"},
    ]
    pr_files = [
        _pr_file_row(60, "setup.py", start=1, count=3),
        _pr_file_row(60, "src/diffusers/__init__.py", start=10, count=3),
        _pr_file_row(70, "src/tokenizer.py", start=10, count=6),
        _pr_file_row(70, "tests/test_tokenizer.py", start=25, count=4),
        _pr_file_row(71, "src/tokenizer.py", start=12, count=5),
        _pr_file_row(71, "tests/test_tokenizer.py", start=28, count=4),
        _pr_file_row(80, "src/modeling_utils.py", start=180, count=8),
    ]

    clusters = build_pr_scope_clusters(
        pull_requests,
        pr_files,
        suppression_rules=({"id": "post_release", "title_patterns": [r"\bpost[- ]release\b"]},),
    )

    assert [cluster.pr_numbers for cluster in clusters] == [[70, 71]]


def test_run_pr_scope_report_writes_json(tmp_path) -> None:
    snapshot_dir = tmp_path / "snapshots" / "20260324T000000Z"
    snapshot_dir.mkdir(parents=True)
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260324T000000Z",
        },
        snapshot_dir / "manifest.json",
    )
    write_parquet(
        [
            {
                **_pr_row(
                    10, state="open", draft=False, additions=10, deletions=2, changed_files=2
                ),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_row(11, state="open", draft=False, additions=9, deletions=3, changed_files=2),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_row(
                    20, state="open", draft=False, additions=12, deletions=4, changed_files=1
                ),
                "repo": "huggingface/transformers",
            },
        ],
        snapshot_dir / "pull_requests.parquet",
        "pull_requests",
    )
    write_parquet(
        [
            {
                **_pr_file_row(10, "src/tokenizer.py", start=10, count=6),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_file_row(10, "tests/test_tokenizer.py", start=25, count=4),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_file_row(11, "src/tokenizer.py", start=12, count=5),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_file_row(11, "tests/test_tokenizer.py", start=28, count=4),
                "repo": "huggingface/transformers",
            },
            {
                **_pr_file_row(20, "src/modeling_utils.py", start=180, count=8),
                "repo": "huggingface/transformers",
            },
        ],
        snapshot_dir / "pr_files.parquet",
        "pr_files",
    )

    output_path = run_pr_scope_report(
        PrScopeOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path,
            output=None,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    payload = read_json(output_path)
    assert output_path == snapshot_dir / "pr-scope-clusters.json"
    assert payload["repo"] == "huggingface/transformers"
    assert payload["snapshot_id"] == "20260324T000000Z"
    assert payload["cluster_count"] == 1
    assert payload["pr_scope_clusters"][0]["pr_numbers"] == [10, 11]


def _pr_row(
    number: int,
    *,
    state: str,
    draft: bool,
    additions: int,
    deletions: int,
    changed_files: int,
) -> dict[str, object]:
    return {
        "number": number,
        "state": state,
        "draft": draft,
        "additions": additions,
        "deletions": deletions,
        "changed_files": changed_files,
    }


def _pr_file_row(pr_number: int, filename: str, *, start: int, count: int) -> dict[str, object]:
    return {
        "pull_request_number": pr_number,
        "filename": filename,
        "additions": count,
        "deletions": 0,
        "changes": count,
        "patch": _patch(start, count),
    }


def _patch(start: int, count: int) -> str:
    header = f"@@ -1,{count} +{start},{count} @@"
    body = "\n".join(f"+line_{index}" for index in range(count))
    return f"{header}\n{body}"
