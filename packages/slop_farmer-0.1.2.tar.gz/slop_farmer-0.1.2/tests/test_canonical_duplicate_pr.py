import json
import os
import re
import subprocess
import sys
from pathlib import Path
from typing import Any

import pytest

import slop_farmer.app.duplicate_prs as app_duplicate_prs
import slop_farmer.reports.duplicate_prs as report_duplicate_prs
from slop_farmer.app.cli import main as cli_main
from slop_farmer.data.parquet_io import read_json, write_json, write_parquet, write_text
from slop_farmer.reports.canonical_duplicate_pr import (
    load_snapshot_bundle,
    prepare_publish_artifacts,
    select_ranked_duplicate_pr_cluster,
    stage_run_bundle,
)


def test_select_ranked_duplicate_pr_cluster_uses_example_report() -> None:
    report_path = Path("eval_data/snapshots/gh-live-latest-100x100/analysis-report.json")
    bundle = load_snapshot_bundle(report_path)

    selected = select_ranked_duplicate_pr_cluster(bundle)

    assert selected["cluster_id"] == "cluster-31515-97"
    assert selected["canonical_pr_number"] == 44452
    assert len(selected["source_pr_numbers"]) == 23
    assert all(number in selected["all_pr_numbers"] for number in selected["source_pr_numbers"])


def test_select_ranked_duplicate_pr_cluster_filters_closed_and_draft_prs(tmp_path: Path) -> None:
    report_path = _write_duplicate_pr_snapshot(
        tmp_path,
        with_aux_context=True,
        cluster_specs=[
            {
                "cluster_id": "cluster-draft-3",
                "canonical_pr_number": 10,
                "target_issue_number": 1,
                "pr_numbers": [10, 11, 12],
                "open_pr_numbers": [10],
                "draft_pr_numbers": [12],
            },
            {
                "cluster_id": "cluster-open-3",
                "canonical_pr_number": 20,
                "target_issue_number": 2,
                "pr_numbers": [20, 21, 22],
                "open_pr_numbers": [20, 21],
                "draft_pr_numbers": [],
            },
        ],
    )

    bundle = load_snapshot_bundle(report_path)
    selected = select_ranked_duplicate_pr_cluster(bundle)

    assert selected["cluster_id"] == "cluster-open-3"
    assert selected["source_pr_numbers"] == [20, 21]


def test_stage_run_bundle_prefers_snapshot_context_without_github_fallback(tmp_path: Path) -> None:
    report_path = _write_duplicate_pr_snapshot(
        tmp_path,
        with_aux_context=True,
        cluster_specs=[
            {
                "cluster_id": "cluster-open-3",
                "canonical_pr_number": 20,
                "target_issue_number": 2,
                "pr_numbers": [20, 21, 22],
                "open_pr_numbers": [20, 21],
                "draft_pr_numbers": [],
            }
        ],
    )
    run_dir = tmp_path / "run"

    class NoGithubFallback:
        def iter_pull_files(self, owner: str, repo: str, number: int) -> list[dict[str, Any]]:
            raise AssertionError("Unexpected GitHub fallback call: iter_pull_files")

        def get_pull_request_diff(self, owner: str, repo: str, number: int) -> str:
            raise AssertionError("Unexpected GitHub fallback call: get_pull_request_diff")

        def iter_issue_comments_for_number(
            self, owner: str, repo: str, number: int, since: str | None
        ) -> list[dict[str, Any]]:
            raise AssertionError("Unexpected GitHub fallback call: iter_issue_comments_for_number")

        def iter_pull_reviews(self, owner: str, repo: str, number: int) -> list[dict[str, Any]]:
            raise AssertionError("Unexpected GitHub fallback call: iter_pull_reviews")

        def iter_pull_review_comments(
            self, owner: str, repo: str, number: int
        ) -> list[dict[str, Any]]:
            raise AssertionError("Unexpected GitHub fallback call: iter_pull_review_comments")

    manifest = stage_run_bundle(report_path, run_dir, github_client=NoGithubFallback())
    cluster_context = read_json(Path(manifest["artifacts"]["cluster_context_path"]))
    pr_context_dir = Path(manifest["artifacts"]["pr_context_dir"])
    pr_context = read_json(pr_context_dir / "pr-20.json")

    assert manifest["selected_cluster"]["cluster_id"] == "cluster-open-3"
    assert cluster_context["selected_cluster"]["source_pr_numbers"] == [20, 21]
    assert pr_context["context_source"] == {
        "files": "snapshot",
        "diff": "snapshot",
        "discussion_comments": "snapshot",
        "reviews": "snapshot",
        "review_comments": "snapshot",
    }
    assert Path(manifest["artifacts"]["prompt_path"]).exists()


def test_stage_run_bundle_templates_repo_branch_and_file_policy(tmp_path: Path) -> None:
    report_path = _write_duplicate_pr_snapshot(
        tmp_path,
        with_aux_context=True,
        cluster_specs=[
            {
                "cluster_id": "cluster-open-3",
                "canonical_pr_number": 20,
                "target_issue_number": 2,
                "pr_numbers": [20, 21, 22],
                "open_pr_numbers": [20, 21],
                "draft_pr_numbers": [],
            }
        ],
    )
    run_dir = tmp_path / "run"

    manifest = stage_run_bundle(
        report_path,
        run_dir,
        prompt_repo="acme/widgets",
        prompt_default_branch="trunk",
        prompt_file_policy_instruction="Documentation changes are allowed when required for the same fix.",
    )
    prompt_text = Path(manifest["artifacts"]["prompt_path"]).read_text(encoding="utf-8")

    assert manifest["prompt_repo"] == "acme/widgets"
    assert manifest["default_branch"] == "trunk"
    assert "acme/widgets" in prompt_text
    assert "acme/widgets:trunk" in prompt_text
    assert "Documentation changes are allowed when required for the same fix." in prompt_text


def test_stage_run_bundle_falls_back_to_github_when_snapshot_context_missing(
    tmp_path: Path,
) -> None:
    report_path = _write_duplicate_pr_snapshot(
        tmp_path,
        with_aux_context=False,
        cluster_specs=[
            {
                "cluster_id": "cluster-open-3",
                "canonical_pr_number": 20,
                "target_issue_number": 2,
                "pr_numbers": [20, 21, 22],
                "open_pr_numbers": [20, 21],
                "draft_pr_numbers": [],
            }
        ],
    )
    run_dir = tmp_path / "run"

    class StubGithubClient:
        def __init__(self) -> None:
            self.calls: list[tuple[str, int]] = []

        def iter_pull_files(self, owner: str, repo: str, number: int):
            self.calls.append(("files", number))
            yield {
                "sha": f"sha-{number}",
                "filename": f"src/pr_{number}.py",
                "status": "modified",
                "additions": 1,
                "deletions": 0,
                "changes": 1,
                "blob_url": f"https://example.com/blob/{number}",
                "raw_url": f"https://example.com/raw/{number}",
                "contents_url": f"https://example.com/contents/{number}",
                "previous_filename": None,
                "patch": "@@ -1 +1 @@\n-old\n+new\n",
            }

        def get_pull_request_diff(self, owner: str, repo: str, number: int) -> str:
            self.calls.append(("diff", number))
            return f"diff --git a/src/pr_{number}.py b/src/pr_{number}.py\n"

        def iter_issue_comments_for_number(self, owner: str, repo: str, number: int, since=None):
            self.calls.append(("comments", number))
            yield {
                "id": number * 1000 + 1,
                "node_id": f"C_{number}",
                "html_url": f"https://example.com/comments/{number}",
                "url": f"https://api.example.com/comments/{number}",
                "issue_url": f"https://api.example.com/issues/{number}",
                "body": f"Comment for PR {number}",
                "created_at": "2026-03-20T00:00:00Z",
                "updated_at": "2026-03-20T00:00:00Z",
                "author_association": "CONTRIBUTOR",
                "user": {
                    "login": "commenter",
                    "id": number,
                    "node_id": f"U_{number}",
                    "type": "User",
                    "site_admin": False,
                },
            }

        def iter_pull_reviews(self, owner: str, repo: str, number: int):
            self.calls.append(("reviews", number))
            yield {
                "id": number * 1000 + 2,
                "node_id": f"R_{number}",
                "html_url": f"https://example.com/reviews/{number}",
                "url": f"https://api.example.com/reviews/{number}",
                "body": f"Review for PR {number}",
                "state": "COMMENTED",
                "submitted_at": "2026-03-20T00:00:00Z",
                "commit_id": f"commit-{number}",
                "author_association": "CONTRIBUTOR",
                "user": {
                    "login": "reviewer",
                    "id": number + 100,
                    "node_id": f"U_{number + 100}",
                    "type": "User",
                    "site_admin": False,
                },
            }

        def iter_pull_review_comments(self, owner: str, repo: str, number: int):
            self.calls.append(("review_comments", number))
            yield {
                "id": number * 1000 + 3,
                "node_id": f"RC_{number}",
                "pull_request_review_id": number * 1000 + 2,
                "html_url": f"https://example.com/review-comments/{number}",
                "url": f"https://api.example.com/review-comments/{number}",
                "pull_request_url": f"https://api.example.com/pulls/{number}",
                "body": f"Review comment for PR {number}",
                "path": f"src/pr_{number}.py",
                "commit_id": f"commit-{number}",
                "original_commit_id": f"commit-{number}",
                "position": 1,
                "original_position": 1,
                "line": 1,
                "start_line": None,
                "side": "RIGHT",
                "start_side": None,
                "subject_type": "line",
                "created_at": "2026-03-20T00:00:00Z",
                "updated_at": "2026-03-20T00:00:00Z",
                "author_association": "CONTRIBUTOR",
                "user": {
                    "login": "reviewer",
                    "id": number + 200,
                    "node_id": f"U_{number + 200}",
                    "type": "User",
                    "site_admin": False,
                },
            }

    client = StubGithubClient()
    manifest = stage_run_bundle(report_path, run_dir, github_client=client)
    pr_context = read_json(Path(manifest["artifacts"]["pr_context_dir"]) / "pr-20.json")

    assert pr_context["context_source"] == {
        "files": "github_api",
        "diff": "github_api",
        "discussion_comments": "github_api",
        "reviews": "github_api",
        "review_comments": "github_api",
    }
    assert ("files", 20) in client.calls
    assert ("reviews", 21) in client.calls


def test_prepare_publish_artifacts_appends_source_prs(tmp_path: Path) -> None:
    report_path = _write_duplicate_pr_snapshot(
        tmp_path,
        with_aux_context=True,
        cluster_specs=[
            {
                "cluster_id": "cluster-open-3",
                "canonical_pr_number": 20,
                "target_issue_number": 2,
                "pr_numbers": [20, 21, 22],
                "open_pr_numbers": [20, 21],
                "draft_pr_numbers": [],
            }
        ],
    )
    run_dir = tmp_path / "run"
    manifest = stage_run_bundle(report_path, run_dir)
    result_path = Path(manifest["artifacts"]["result_path"])
    result_path.write_text(
        json.dumps(
            {
                "status": "success",
                "cluster_id": "cluster-open-3",
                "source_pr_numbers": [20, 21],
                "tests_run": ["python -m pytest tests/test_example.py"],
                "commit_message": "Synthesize canonical PR",
                "pr_title": "Canonical fix for duplicate PRs",
                "pr_body": "This is the synthesized fix.",
                "summary": "Merged the two open PRs.",
            }
        ),
        encoding="utf-8",
    )

    publish_metadata = prepare_publish_artifacts(Path(run_dir / "run-manifest.json"), result_path)
    body = Path(publish_metadata["pr_body_path"]).read_text(encoding="utf-8")

    assert publish_metadata["pr_title"] == "Canonical fix for duplicate PRs"
    assert "Merged the two open PRs." in body
    assert "Target issue: #2." in body
    assert "- `python -m pytest tests/test_example.py`" in body
    assert "- #20" in body
    assert "- #21" in body


def test_validate_codex_result_accepts_and_normalizes_subset_of_selected_prs(
    tmp_path: Path,
) -> None:
    report_path = _write_duplicate_pr_snapshot(
        tmp_path,
        with_aux_context=True,
        cluster_specs=[
            {
                "cluster_id": "cluster-open-4",
                "canonical_pr_number": 20,
                "target_issue_number": 2,
                "pr_numbers": [20, 21, 22, 23],
                "open_pr_numbers": [20, 21, 23],
                "draft_pr_numbers": [],
            }
        ],
    )
    run_dir = tmp_path / "run"
    manifest = stage_run_bundle(report_path, run_dir)
    result_path = Path(manifest["artifacts"]["result_path"])
    result_path.write_text(
        json.dumps(
            {
                "status": "success",
                "cluster_id": "cluster-open-4",
                "source_pr_numbers": [23, 20],
                "tests_run": ["python -m pytest tests/test_example.py"],
                "commit_message": "Synthesize canonical PR",
                "pr_title": "Canonical fix for duplicate PRs",
                "summary": "Merged the selected duplicate PR work into one minimal patch.",
            }
        ),
        encoding="utf-8",
    )

    result = app_duplicate_prs.validate_codex_result(
        Path(run_dir / "run-manifest.json"), result_path
    )

    assert result["source_pr_numbers"] == [20, 23]


def test_validate_codex_result_rejects_prs_outside_selected_cluster(tmp_path: Path) -> None:
    report_path = _write_duplicate_pr_snapshot(
        tmp_path,
        with_aux_context=True,
        cluster_specs=[
            {
                "cluster_id": "cluster-open-3",
                "canonical_pr_number": 20,
                "target_issue_number": 2,
                "pr_numbers": [20, 21, 22],
                "open_pr_numbers": [20, 21],
                "draft_pr_numbers": [],
            }
        ],
    )
    run_dir = tmp_path / "run"
    manifest = stage_run_bundle(report_path, run_dir)
    result_path = Path(manifest["artifacts"]["result_path"])
    result_path.write_text(
        json.dumps(
            {
                "status": "success",
                "cluster_id": "cluster-open-3",
                "source_pr_numbers": [20, 99],
                "tests_run": ["python -m pytest tests/test_example.py"],
                "commit_message": "Synthesize canonical PR",
                "pr_title": "Canonical fix for duplicate PRs",
                "summary": "Merged the selected duplicate PR work into one minimal patch.",
            }
        ),
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="outside the selected open PR set: 99"):
        app_duplicate_prs.validate_codex_result(Path(run_dir / "run-manifest.json"), result_path)


def test_validate_codex_result_requires_at_least_two_source_prs(tmp_path: Path) -> None:
    report_path = _write_duplicate_pr_snapshot(
        tmp_path,
        with_aux_context=True,
        cluster_specs=[
            {
                "cluster_id": "cluster-open-3",
                "canonical_pr_number": 20,
                "target_issue_number": 2,
                "pr_numbers": [20, 21, 22],
                "open_pr_numbers": [20, 21],
                "draft_pr_numbers": [],
            }
        ],
    )
    run_dir = tmp_path / "run"
    manifest = stage_run_bundle(report_path, run_dir)
    result_path = Path(manifest["artifacts"]["result_path"])
    result_path.write_text(
        json.dumps(
            {
                "status": "success",
                "cluster_id": "cluster-open-3",
                "source_pr_numbers": [20],
                "tests_run": ["python -m pytest tests/test_example.py"],
                "commit_message": "Synthesize canonical PR",
                "pr_title": "Canonical fix for duplicate PRs",
                "summary": "Merged the selected duplicate PR work into one minimal patch.",
            }
        ),
        encoding="utf-8",
    )

    with pytest.raises(ValueError, match="at least two open source PRs"):
        app_duplicate_prs.validate_codex_result(Path(run_dir / "run-manifest.json"), result_path)


def test_run_canonical_duplicate_pr_script_happy_path(tmp_path: Path) -> None:
    report_path = _write_duplicate_pr_snapshot(
        tmp_path / "fixture",
        with_aux_context=True,
        cluster_specs=[
            {
                "cluster_id": "cluster-open-3",
                "canonical_pr_number": 20,
                "target_issue_number": 2,
                "pr_numbers": [20, 21, 22],
                "open_pr_numbers": [20, 21],
                "draft_pr_numbers": [],
            }
        ],
    )
    script_path = Path("scripts/run_canonical_duplicate_pr.sh").resolve()
    runs_dir = tmp_path / "runs"
    transformers_repo = tmp_path / "transformers"
    transformers_repo.mkdir()

    log_path = tmp_path / "stub.log"
    stub_dir = tmp_path / "stubs"
    result_payload_path = tmp_path / "codex-result.json"
    result_payload_path.write_text(
        json.dumps(
            {
                "status": "success",
                "cluster_id": "cluster-open-3",
                "source_pr_numbers": [20, 21],
                "tests_run": ["python -m pytest tests/test_example.py"],
                "commit_message": "Synthesize canonical duplicate PR",
                "pr_title": "Canonical duplicate PR fix",
                "pr_body": "This patch combines the duplicate open PRs.",
                "summary": "Combined the open PR implementations into one branch.",
            }
        ),
        encoding="utf-8",
    )
    _write_stub_commands(stub_dir, log_path, result_payload_path)

    env = os.environ.copy()
    env.update(
        {
            "PATH": f"{stub_dir}:{env['PATH']}",
            "REPORT_PATH": str(report_path),
            "TRANSFORMERS_REPO": str(transformers_repo),
            "RUNS_DIR": str(runs_dir),
            "FORK_OWNER": "burtenshaw",
            "STUB_LOG_PATH": str(log_path),
            "GIT_STUB_FORK_URL_FILE": str(tmp_path / "fork-remote.txt"),
            "CODEX_STUB_RESULT_FILE": str(result_payload_path),
        }
    )

    result = subprocess.run(
        ["bash", str(script_path)],
        cwd=Path.cwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    run_dirs = sorted(path for path in runs_dir.iterdir() if path.is_dir())
    assert len(run_dirs) == 1
    run_dir = run_dirs[0]
    assert (run_dir / "pr-url.txt").read_text(
        encoding="utf-8"
    ).strip() == "https://github.com/huggingface/transformers/pull/99999"
    log_text = log_path.read_text(encoding="utf-8")
    assert "git -C" in log_text
    assert "fetch origin main" in log_text
    assert re.search(r"worktree add -B codex/cluster-open-3-", log_text)
    assert "push -u fork codex/cluster-open-3-" in log_text
    assert (
        "gh pr create --repo huggingface/transformers --base main --head burtenshaw:codex/cluster-open-3-"
        in log_text
    )


def test_run_canonical_duplicate_pr_script_failed_codex_keeps_artifacts_and_skips_publish(
    tmp_path: Path,
) -> None:
    report_path = _write_duplicate_pr_snapshot(
        tmp_path / "fixture",
        with_aux_context=True,
        cluster_specs=[
            {
                "cluster_id": "cluster-open-3",
                "canonical_pr_number": 20,
                "target_issue_number": 2,
                "pr_numbers": [20, 21, 22],
                "open_pr_numbers": [20, 21],
                "draft_pr_numbers": [],
            }
        ],
    )
    script_path = Path("scripts/run_canonical_duplicate_pr.sh").resolve()
    runs_dir = tmp_path / "runs"
    transformers_repo = tmp_path / "transformers"
    transformers_repo.mkdir()

    log_path = tmp_path / "stub.log"
    stub_dir = tmp_path / "stubs"
    result_payload_path = tmp_path / "codex-result.json"
    result_payload_path.write_text(
        json.dumps(
            {
                "status": "failed",
                "cluster_id": "cluster-open-3",
                "source_pr_numbers": [20, 21],
                "tests_run": ["python -m pytest tests/test_example.py"],
                "commit_message": "",
                "pr_title": "",
                "pr_body": "",
                "summary": "Targeted tests failed.",
            }
        ),
        encoding="utf-8",
    )
    _write_stub_commands(stub_dir, log_path, result_payload_path)

    env = os.environ.copy()
    env.update(
        {
            "PATH": f"{stub_dir}:{env['PATH']}",
            "REPORT_PATH": str(report_path),
            "TRANSFORMERS_REPO": str(transformers_repo),
            "RUNS_DIR": str(runs_dir),
            "FORK_OWNER": "burtenshaw",
            "STUB_LOG_PATH": str(log_path),
            "GIT_STUB_FORK_URL_FILE": str(tmp_path / "fork-remote.txt"),
            "CODEX_STUB_RESULT_FILE": str(result_payload_path),
        }
    )

    result = subprocess.run(
        ["bash", str(script_path)],
        cwd=Path.cwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode != 0
    run_dirs = sorted(path for path in runs_dir.iterdir() if path.is_dir())
    assert len(run_dirs) == 1
    run_dir = run_dirs[0]
    assert (run_dir / "worktree").exists()
    assert (run_dir / "codex-final.json").exists()
    log_text = log_path.read_text(encoding="utf-8")
    assert "worktree add -B codex/cluster-open-3-" in log_text
    assert "gh pr create" not in log_text
    assert "push -u fork" not in log_text


def test_ensure_hybrid_report_reruns_analysis_when_input_not_hybrid(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    report_path = _write_duplicate_pr_snapshot(
        tmp_path,
        with_aux_context=True,
        cluster_specs=[
            {
                "cluster_id": "cluster-open-3",
                "canonical_pr_number": 20,
                "target_issue_number": 2,
                "pr_numbers": [20, 21],
                "open_pr_numbers": [20, 21],
                "draft_pr_numbers": [],
            }
        ],
        llm_enrichment=False,
    )
    captured: dict[str, object] = {}

    def fake_run_analysis(options: Any) -> Path:
        captured["output"] = options.output
        output = Path(options.output)
        payload = read_json(report_path)
        payload["llm_enrichment"] = True
        write_json(payload, output)
        return output

    monkeypatch.setattr(
        report_duplicate_prs,
        "assert_hybrid_analysis_prerequisites",
        lambda: None,
    )
    monkeypatch.setattr(report_duplicate_prs, "run_analysis", fake_run_analysis)

    result = report_duplicate_prs.ensure_hybrid_report(report_path=report_path, snapshot_dir=None)

    assert result.name == "analysis-report-hybrid.json"
    assert captured["output"] == report_path.parent / "analysis-report-hybrid.json"


def test_duplicate_prs_cli_merge_happy_path_allows_docs(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
    capsys: pytest.CaptureFixture[str],
) -> None:
    report_path = _write_duplicate_pr_snapshot(
        tmp_path / "fixture",
        with_aux_context=True,
        cluster_specs=[
            {
                "cluster_id": "cluster-open-3",
                "canonical_pr_number": 20,
                "target_issue_number": 2,
                "pr_numbers": [20, 21, 22],
                "open_pr_numbers": [20, 21],
                "draft_pr_numbers": [],
            }
        ],
        llm_enrichment=True,
        report_filename="analysis-report-hybrid.json",
    )
    repo_dir = tmp_path / "transformers"
    repo_dir.mkdir()
    log_path = tmp_path / "stub.log"
    stub_dir = tmp_path / "stubs"
    result_payload_path = tmp_path / "codex-result.json"
    result_payload_path.write_text(
        json.dumps(
            {
                "status": "success",
                "cluster_id": "cluster-open-3",
                "source_pr_numbers": [20, 21],
                "tests_run": ["python -m pytest tests/test_example.py"],
                "commit_message": "Synthesize canonical duplicate PR",
                "pr_title": "Canonical duplicate PR fix",
                "summary": "Combined the open PR implementations into one branch.",
            }
        ),
        encoding="utf-8",
    )
    _write_duplicate_pr_merge_stub_commands(stub_dir, log_path, result_payload_path)

    monkeypatch.setattr(
        report_duplicate_prs,
        "assert_hybrid_analysis_prerequisites",
        lambda: None,
    )
    monkeypatch.setattr(
        report_duplicate_prs,
        "assess_duplicate_pr_cluster_mergeability",
        lambda _bundle, _candidate, *, model: (
            report_duplicate_prs.DuplicatePrClusterMergeabilityResponse(
                accept=True,
                confidence=0.9,
                reason="Same fix path.",
            )
        ),
    )
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("PATH", f"{stub_dir}:{os.environ['PATH']}")
    monkeypatch.setenv("STUB_LOG_PATH", str(log_path))
    monkeypatch.setenv("GIT_STUB_ORIGIN_URL", "https://github.com/huggingface/transformers.git")
    monkeypatch.setenv("GIT_STUB_FORK_URL_FILE", str(tmp_path / "fork-remote.txt"))
    monkeypatch.setenv("GIT_STUB_AHEAD_COUNT", "1")
    monkeypatch.setenv("GIT_STUB_HEAD_SUBJECT", "Synthesize canonical duplicate PR")
    monkeypatch.setenv("GIT_STUB_DIFF_FILES", "README.md\nsrc/example.py\n")
    monkeypatch.setenv("GH_STUB_AUTH_OK", "1")
    monkeypatch.setenv("GH_STUB_AUTH_LOGIN", "burtenshaw")
    monkeypatch.setenv("GH_STUB_DEFAULT_BRANCH", "main")
    monkeypatch.setenv("GH_STUB_FORK_EXISTS", "1")
    monkeypatch.setattr(
        sys,
        "argv",
        [
            "slop-farmer",
            "duplicate-prs",
            "merge",
            "--report",
            str(report_path),
            "--repo-dir",
            str(repo_dir),
            "--file-policy",
            "allow-docs",
        ],
    )

    cli_main()
    payload = json.loads(capsys.readouterr().out)

    assert payload["file_policy"] == "allow-docs"
    assert "README.md" in payload["changed_paths"]
    log_text = log_path.read_text(encoding="utf-8")
    assert "gh pr create" in log_text
    assert "push -u fork codex/cluster-open-3-" in log_text


def _write_duplicate_pr_snapshot(
    base_dir: Path,
    *,
    with_aux_context: bool,
    cluster_specs: list[dict[str, Any]],
    llm_enrichment: bool = False,
    report_filename: str = "analysis-report.json",
) -> Path:
    snapshot_dir = base_dir / "snapshots" / "20260320T000000Z"
    issues = [_issue_row(1), _issue_row(2)]
    pull_requests: list[dict[str, object]] = []
    comments: list[dict[str, object]] = []
    reviews: list[dict[str, object]] = []
    review_comments: list[dict[str, object]] = []
    pr_files: list[dict[str, object]] = []
    pr_diffs: list[dict[str, object]] = []
    meta_bugs: list[dict[str, object]] = []
    duplicate_prs: list[dict[str, object]] = []

    for spec in cluster_specs:
        cluster_id = str(spec["cluster_id"])
        canonical_pr_number = int(spec["canonical_pr_number"])
        pr_numbers = [int(number) for number in spec["pr_numbers"]]
        open_pr_numbers = {int(number) for number in spec["open_pr_numbers"]}
        draft_pr_numbers = {int(number) for number in spec["draft_pr_numbers"]}
        target_issue_number = int(spec["target_issue_number"])
        meta_bugs.append(
            {
                "cluster_id": cluster_id,
                "summary": f"Summary for {cluster_id}",
                "status": "open",
                "confidence": 0.9,
                "canonical_issue_number": target_issue_number,
                "canonical_pr_number": canonical_pr_number,
                "issue_numbers": [target_issue_number],
                "pr_numbers": pr_numbers,
                "evidence_types": ["closing_reference"],
            }
        )
        duplicate_prs.append(
            {
                "cluster_id": cluster_id,
                "canonical_pr_number": canonical_pr_number,
                "duplicate_pr_numbers": [
                    number for number in pr_numbers if number != canonical_pr_number
                ],
                "target_issue_number": target_issue_number,
                "reason": f"Reason for {cluster_id}",
            }
        )
        for number in pr_numbers:
            state = "open" if number in open_pr_numbers or number in draft_pr_numbers else "closed"
            draft = number in draft_pr_numbers
            pull_requests.append(
                _pr_row(
                    number,
                    state=state,
                    draft=draft,
                    merged=False,
                    body=f"Fixes #{target_issue_number}",
                )
            )
            if with_aux_context and number in open_pr_numbers:
                comments.append(
                    _comment_row(1000 + number, "pull_request", number, f"Comment for PR {number}")
                )
                reviews.append(_review_row(2000 + number, number))
                review_comments.append(_review_comment_row(3000 + number, number, 2000 + number))
                pr_files.append(_pr_file_row(number))
                pr_diffs.append(_pr_diff_row(number))

    write_parquet(issues, snapshot_dir / "issues.parquet", "issues")
    write_parquet(pull_requests, snapshot_dir / "pull_requests.parquet", "pull_requests")
    write_parquet(comments, snapshot_dir / "comments.parquet", "comments")
    write_parquet(reviews, snapshot_dir / "reviews.parquet", "reviews")
    write_parquet(review_comments, snapshot_dir / "review_comments.parquet", "review_comments")
    write_parquet(pr_files, snapshot_dir / "pr_files.parquet", "pr_files")
    write_parquet(pr_diffs, snapshot_dir / "pr_diffs.parquet", "pr_diffs")
    write_parquet([], snapshot_dir / "links.parquet", "links")
    write_parquet([], snapshot_dir / "events.parquet", "events")
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260320T000000Z",
            "extracted_at": "2026-03-20T00:00:00Z",
        },
        snapshot_dir / "manifest.json",
    )
    report_path = snapshot_dir / report_filename
    write_json(
        {
            "schema_version": "1.0",
            "repo": "huggingface/transformers",
            "snapshot_id": "20260320T000000Z",
            "generated_at": "2026-03-20T00:00:00Z",
            "evidence_quality": "partial",
            "llm_enrichment": llm_enrichment,
            "meta_bugs": meta_bugs,
            "duplicate_issues": [],
            "duplicate_prs": duplicate_prs,
            "best_issue": None,
            "best_pr": None,
        },
        report_path,
    )
    return report_path


def _issue_row(number: int) -> dict[str, object]:
    return {
        "repo": "huggingface/transformers",
        "github_id": number,
        "github_node_id": f"I_{number}",
        "number": number,
        "html_url": f"https://example.com/issues/{number}",
        "api_url": f"https://api.example.com/issues/{number}",
        "title": f"Issue {number}",
        "body": f"Body for issue {number}",
        "state": "open",
        "state_reason": None,
        "locked": False,
        "comments_count": 0,
        "labels": [],
        "assignees": [],
        "created_at": "2026-03-20T00:00:00Z",
        "updated_at": "2026-03-20T00:00:00Z",
        "closed_at": None,
        "milestone_title": None,
        "snapshot_id": "20260320T000000Z",
        "extracted_at": "2026-03-20T00:00:00Z",
        "author_login": f"user{number}",
        "author_id": number,
        "author_node_id": f"U_{number}",
        "author_type": "User",
        "author_site_admin": False,
    }


def _pr_row(number: int, *, state: str, draft: bool, merged: bool, body: str) -> dict[str, object]:
    return {
        "repo": "huggingface/transformers",
        "github_id": number,
        "github_node_id": f"PR_{number}",
        "number": number,
        "html_url": f"https://example.com/pulls/{number}",
        "api_url": f"https://api.example.com/pulls/{number}",
        "title": f"PR {number}",
        "body": body,
        "state": state,
        "state_reason": None,
        "locked": False,
        "comments_count": 1,
        "labels": [],
        "assignees": [],
        "created_at": "2026-03-20T00:00:00Z",
        "updated_at": "2026-03-20T00:00:00Z",
        "closed_at": None if state == "open" else "2026-03-21T00:00:00Z",
        "merged_at": None,
        "merge_commit_sha": None,
        "merged": merged,
        "mergeable": True,
        "mergeable_state": "clean",
        "draft": draft,
        "additions": 2,
        "deletions": 1,
        "changed_files": 1,
        "commits": 1,
        "review_comments_count": 1,
        "maintainer_can_modify": True,
        "head_ref": f"branch-{number}",
        "head_sha": f"head-{number}",
        "head_repo_full_name": "fork/repo",
        "base_ref": "main",
        "base_sha": f"base-{number}",
        "base_repo_full_name": "huggingface/transformers",
        "snapshot_id": "20260320T000000Z",
        "extracted_at": "2026-03-20T00:00:00Z",
        "author_login": f"user{number}",
        "author_id": number,
        "author_node_id": f"U_{number}",
        "author_type": "User",
        "author_site_admin": False,
    }


def _comment_row(
    github_id: int, parent_kind: str, parent_number: int, body: str
) -> dict[str, object]:
    return {
        "repo": "huggingface/transformers",
        "github_id": github_id,
        "github_node_id": f"C_{github_id}",
        "parent_kind": parent_kind,
        "parent_number": parent_number,
        "html_url": f"https://example.com/comments/{github_id}",
        "api_url": f"https://api.example.com/comments/{github_id}",
        "issue_api_url": f"https://api.example.com/issues/{parent_number}",
        "body": body,
        "created_at": "2026-03-20T00:00:00Z",
        "updated_at": "2026-03-20T00:00:00Z",
        "author_association": "CONTRIBUTOR",
        "snapshot_id": "20260320T000000Z",
        "extracted_at": "2026-03-20T00:00:00Z",
        "author_login": f"user{github_id}",
        "author_id": github_id,
        "author_node_id": f"U_{github_id}",
        "author_type": "User",
        "author_site_admin": False,
    }


def _review_row(github_id: int, pr_number: int) -> dict[str, object]:
    return {
        "repo": "huggingface/transformers",
        "github_id": github_id,
        "github_node_id": f"R_{github_id}",
        "pull_request_number": pr_number,
        "html_url": f"https://example.com/reviews/{github_id}",
        "api_url": f"https://api.example.com/reviews/{github_id}",
        "body": f"Review for PR {pr_number}",
        "state": "COMMENTED",
        "submitted_at": "2026-03-20T00:00:00Z",
        "commit_id": f"commit-{pr_number}",
        "author_association": "CONTRIBUTOR",
        "snapshot_id": "20260320T000000Z",
        "extracted_at": "2026-03-20T00:00:00Z",
        "author_login": "reviewer",
        "author_id": github_id,
        "author_node_id": f"U_{github_id}",
        "author_type": "User",
        "author_site_admin": False,
    }


def _review_comment_row(github_id: int, pr_number: int, review_id: int) -> dict[str, object]:
    return {
        "repo": "huggingface/transformers",
        "github_id": github_id,
        "github_node_id": f"RC_{github_id}",
        "pull_request_number": pr_number,
        "review_id": review_id,
        "html_url": f"https://example.com/review-comments/{github_id}",
        "api_url": f"https://api.example.com/review-comments/{github_id}",
        "pull_request_api_url": f"https://api.example.com/pulls/{pr_number}",
        "body": f"Review comment for PR {pr_number}",
        "path": f"src/pr_{pr_number}.py",
        "commit_id": f"commit-{pr_number}",
        "original_commit_id": f"commit-{pr_number}",
        "position": 1,
        "original_position": 1,
        "line": 1,
        "start_line": None,
        "side": "RIGHT",
        "start_side": None,
        "subject_type": "line",
        "created_at": "2026-03-20T00:00:00Z",
        "updated_at": "2026-03-20T00:00:00Z",
        "author_association": "CONTRIBUTOR",
        "snapshot_id": "20260320T000000Z",
        "extracted_at": "2026-03-20T00:00:00Z",
        "author_login": "reviewer",
        "author_id": github_id,
        "author_node_id": f"U_{github_id}",
        "author_type": "User",
        "author_site_admin": False,
    }


def _pr_file_row(pr_number: int) -> dict[str, object]:
    return {
        "repo": "huggingface/transformers",
        "pull_request_number": pr_number,
        "sha": f"sha-{pr_number}",
        "filename": f"src/pr_{pr_number}.py",
        "status": "modified",
        "additions": 1,
        "deletions": 0,
        "changes": 1,
        "blob_url": f"https://example.com/blob/{pr_number}",
        "raw_url": f"https://example.com/raw/{pr_number}",
        "contents_url": f"https://example.com/contents/{pr_number}",
        "previous_filename": None,
        "patch": "@@ -1 +1 @@\n-old\n+new\n",
        "snapshot_id": "20260320T000000Z",
        "extracted_at": "2026-03-20T00:00:00Z",
    }


def _pr_diff_row(pr_number: int) -> dict[str, object]:
    return {
        "repo": "huggingface/transformers",
        "pull_request_number": pr_number,
        "html_url": f"https://example.com/pulls/{pr_number}",
        "api_url": f"https://api.example.com/pulls/{pr_number}",
        "diff": f"diff --git a/src/pr_{pr_number}.py b/src/pr_{pr_number}.py\n",
        "snapshot_id": "20260320T000000Z",
        "extracted_at": "2026-03-20T00:00:00Z",
    }


def _write_stub_commands(stub_dir: Path, log_path: Path, result_payload_path: Path) -> None:
    stub_dir.mkdir(parents=True, exist_ok=True)
    _write_executable(
        stub_dir / "git",
        """#!/usr/bin/env bash
set -euo pipefail
printf '%s\\n' "git $*" >> "${STUB_LOG_PATH}"
if [[ "$1" == "-C" ]]; then
  shift
  cwd="$1"
  shift
fi
cmd="${1:-}"
shift || true
case "${cmd}" in
  fetch)
    exit 0
    ;;
  worktree)
    if [[ "${1:-}" == "add" ]]; then
      shift
      if [[ "${1:-}" == "-B" ]]; then
        shift
        branch="$1"
        shift
      fi
      worktree_dir="$1"
      mkdir -p "${worktree_dir}"
      exit 0
    fi
    ;;
  remote)
    subcmd="${1:-}"
    shift || true
    case "${subcmd}" in
      get-url)
        if [[ -f "${GIT_STUB_FORK_URL_FILE}" ]]; then
          cat "${GIT_STUB_FORK_URL_FILE}"
          exit 0
        fi
        exit 2
        ;;
      add)
        remote_name="${1:-}"
        remote_url="${2:-}"
        printf '%s' "${remote_url}" > "${GIT_STUB_FORK_URL_FILE}"
        exit 0
        ;;
    esac
    ;;
  push)
    exit 0
    ;;
esac
exit 0
""",
    )
    _write_executable(
        stub_dir / "gh",
        """#!/usr/bin/env bash
set -euo pipefail
printf '%s\\n' "gh $*" >> "${STUB_LOG_PATH}"
if [[ "${1:-}" == "repo" && "${2:-}" == "view" ]]; then
  echo '{"nameWithOwner":"burtenshaw/transformers"}'
  exit 0
fi
if [[ "${1:-}" == "repo" && "${2:-}" == "fork" ]]; then
  exit 0
fi
if [[ "${1:-}" == "pr" && "${2:-}" == "create" ]]; then
  echo 'https://github.com/huggingface/transformers/pull/99999'
  exit 0
fi
exit 0
""",
    )
    _write_executable(
        stub_dir / "codex",
        f"""#!/usr/bin/env bash
set -euo pipefail
printf '%s\\n' "codex $*" >> "${{STUB_LOG_PATH}}"
output=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    -o|--output-last-message)
      output="$2"
      shift 2
      ;;
    *)
      shift
      ;;
  esac
done
cat >/dev/null
cp "{result_payload_path}" "${{output}}"
""",
    )


def _write_duplicate_pr_merge_stub_commands(
    stub_dir: Path, log_path: Path, result_payload_path: Path
) -> None:
    stub_dir.mkdir(parents=True, exist_ok=True)
    _write_executable(
        stub_dir / "git",
        """#!/usr/bin/env bash
set -euo pipefail
printf '%s\\n' "git $*" >> "${STUB_LOG_PATH}"
cwd=""
if [[ "${1:-}" == "-C" ]]; then
  shift
  cwd="$1"
  shift
fi
cmd="${1:-}"
shift || true
case "${cmd}" in
  fetch)
    exit 0
    ;;
  worktree)
    if [[ "${1:-}" == "add" ]]; then
      shift
      if [[ "${1:-}" == "-B" ]]; then
        shift
        branch="$1"
        shift
      fi
      worktree_dir="$1"
      mkdir -p "${worktree_dir}"
      exit 0
    fi
    ;;
  remote)
    subcmd="${1:-}"
    shift || true
    case "${subcmd}" in
      get-url)
        remote_name="${1:-}"
        if [[ "${remote_name}" == "origin" || "${remote_name}" == "upstream" ]]; then
          printf '%s\\n' "${GIT_STUB_ORIGIN_URL:-https://github.com/huggingface/transformers.git}"
          exit 0
        fi
        if [[ -f "${GIT_STUB_FORK_URL_FILE:-}" ]]; then
          cat "${GIT_STUB_FORK_URL_FILE}"
          exit 0
        fi
        exit 2
        ;;
      add)
        remote_name="${1:-}"
        remote_url="${2:-}"
        printf '%s' "${remote_url}" > "${GIT_STUB_FORK_URL_FILE}"
        exit 0
        ;;
    esac
    ;;
  rev-list)
    printf '%s\\n' "${GIT_STUB_AHEAD_COUNT:-1}"
    exit 0
    ;;
  log)
    printf '%s\\n' "${GIT_STUB_HEAD_SUBJECT:-Synthesize canonical duplicate PR}"
    exit 0
    ;;
  status)
    printf '%s' "${GIT_STUB_STATUS:-}"
    exit 0
    ;;
  diff)
    printf '%s' "${GIT_STUB_DIFF_FILES:-src/example.py\\n}"
    exit 0
    ;;
  push)
    exit 0
    ;;
esac
exit 0
""",
    )
    _write_executable(
        stub_dir / "gh",
        """#!/usr/bin/env bash
set -euo pipefail
printf '%s\\n' "gh $*" >> "${STUB_LOG_PATH}"
if [[ "${1:-}" == "auth" && "${2:-}" == "status" ]]; then
  [[ "${GH_STUB_AUTH_OK:-1}" == "1" ]] && exit 0
  exit 1
fi
if [[ "${1:-}" == "api" && "${2:-}" == "user" ]]; then
  printf '%s\\n' "${GH_STUB_AUTH_LOGIN:-burtenshaw}"
  exit 0
fi
if [[ "${1:-}" == "repo" && "${2:-}" == "view" ]]; then
  if printf '%s' "$*" | grep -q 'defaultBranchRef'; then
    printf '%s\\n' "${GH_STUB_DEFAULT_BRANCH:-main}"
    exit 0
  fi
  [[ "${GH_STUB_FORK_EXISTS:-1}" == "1" ]] || exit 1
  echo '{"nameWithOwner":"burtenshaw/transformers"}'
  exit 0
fi
if [[ "${1:-}" == "repo" && "${2:-}" == "fork" ]]; then
  exit 0
fi
if [[ "${1:-}" == "pr" && "${2:-}" == "create" ]]; then
  echo 'https://github.com/huggingface/transformers/pull/99999'
  exit 0
fi
exit 0
""",
    )
    _write_executable(
        stub_dir / "codex",
        f"""#!/usr/bin/env bash
set -euo pipefail
printf '%s\\n' "codex $*" >> "${{STUB_LOG_PATH}}"
output=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    -o)
      output="$2"
      shift 2
      ;;
    *)
      shift
      ;;
  esac
done
cat >/dev/null
cp "{result_payload_path}" "${{output}}"
""",
    )


def _write_executable(path: Path, content: str) -> None:
    write_text(content, path)
    path.chmod(0o755)
