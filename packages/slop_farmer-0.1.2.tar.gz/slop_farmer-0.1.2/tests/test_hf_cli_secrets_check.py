from __future__ import annotations

import subprocess
import sys
from pathlib import Path


def test_hf_cli_secrets_check_rejects_inline_secret_values(tmp_path: Path) -> None:
    (tmp_path / "safe.sh").write_text(
        """
#!/usr/bin/env bash
hf jobs uv run --secrets HF_TOKEN --secrets GITHUB_TOKEN jobs/update_dataset.py
""".strip()
        + "\n",
        encoding="utf-8",
    )
    (tmp_path / "unsafe.sh").write_text(
        """
#!/usr/bin/env bash
hf jobs uv run --secrets "HF_TOKEN=$HF_SECRET" --secrets GITHUB_TOKEN jobs/update_dataset.py
""".strip()
        + "\n",
        encoding="utf-8",
    )

    result = subprocess.run(
        [sys.executable, str(Path("scripts/check_hf_cli_secrets.py").resolve()), str(tmp_path)],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 1
    assert "unsafe.sh:2" in result.stderr
    assert f"{tmp_path / 'safe.sh'}:2 uses" not in result.stderr


def test_hf_cli_secrets_check_accepts_named_secret_forwarding(tmp_path: Path) -> None:
    (tmp_path / "submit_dataset_job.sh").write_text(
        """
#!/usr/bin/env bash
hf jobs scheduled uv run @daily --secrets HF_TOKEN --secrets GITHUB_TOKEN jobs/update_dataset.py
""".strip()
        + "\n",
        encoding="utf-8",
    )

    result = subprocess.run(
        [sys.executable, str(Path("scripts/check_hf_cli_secrets.py").resolve()), str(tmp_path)],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0
    assert "HF CLI secret usage OK." in result.stdout
