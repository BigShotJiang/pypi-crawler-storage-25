from __future__ import annotations

from dataclasses import replace
from pathlib import Path
from typing import Any

from slop_farmer.reports.analysis_cache import (
    HYBRID_REVIEW_CACHE_SCHEMA_VERSION,
    PREPARED_REVIEW_UNIT_SCHEMA_VERSION,
    HybridReviewCacheEntry,
    HybridReviewCacheManifest,
    HybridReviewCacheStore,
    HybridReviewSettingsFingerprint,
    build_hybrid_review_cache_key,
    prepared_review_unit_hash,
)


def test_hybrid_review_cache_key_uses_explicit_named_inputs() -> None:
    manifest = _manifest()
    prepared_review_unit = _prepared_review_unit()

    base = build_hybrid_review_cache_key(
        manifest=manifest,
        model="gpt-5.4-mini?service_tier=flex",
        prepared_review_unit=prepared_review_unit,
    )

    assert base == build_hybrid_review_cache_key(
        manifest=manifest,
        model="gpt-5.4-mini?service_tier=flex",
        prepared_review_unit=_prepared_review_unit(),
    )
    assert base != build_hybrid_review_cache_key(
        manifest=manifest,
        model="gpt-5.4-mini",
        prepared_review_unit=prepared_review_unit,
    )
    assert base != build_hybrid_review_cache_key(
        manifest=replace(manifest, analyst_prompt_version="2.0"),
        model="gpt-5.4-mini?service_tier=flex",
        prepared_review_unit=prepared_review_unit,
    )
    assert base != build_hybrid_review_cache_key(
        manifest=replace(manifest, prepared_review_unit_schema_version="2.0"),
        model="gpt-5.4-mini?service_tier=flex",
        prepared_review_unit=prepared_review_unit,
    )
    assert base != build_hybrid_review_cache_key(
        manifest=replace(
            manifest,
            hybrid_review_settings=replace(
                manifest.hybrid_review_settings,
                llm_skip_evaluator_above_tokens=7_000,
            ),
        ),
        model="gpt-5.4-mini?service_tier=flex",
        prepared_review_unit=prepared_review_unit,
    )


def test_prepared_review_unit_hash_changes_when_review_payload_changes() -> None:
    base = prepared_review_unit_hash(_prepared_review_unit())
    same = prepared_review_unit_hash(_prepared_review_unit())
    diff_preview_changed = prepared_review_unit_hash(_prepared_review_unit(diff_preview="beta"))
    filenames_changed = prepared_review_unit_hash(
        _prepared_review_unit(filenames=("src/alpha.py", "src/beta.py"))
    )

    assert base == same
    assert diff_preview_changed != base
    assert filenames_changed != base


def test_prepared_review_unit_hash_ignores_order_only_changes() -> None:
    base = _prepared_review_unit()
    reordered = _prepared_review_unit()
    reordered["packet"]["nodes"] = ["pull_request:11", "pull_request:10"]
    reordered["packet"]["items"] = list(reversed(reordered["packet"]["items"]))
    reordered["packet"]["pair_evidence"] = {
        "pull_request:10|pull_request:11": ["soft_similarity", "shared_issue_target"]
    }
    reordered["packet"]["soft_pairs"] = [
        {
            **reordered["packet"]["soft_pairs"][0],
            "evidence_types": ["soft_similarity", "shared_issue_target"],
            "shared_targets": [2, 1],
            "shared_filenames": ["src/beta.py", "src/alpha.py"],
        }
    ]
    base["packet"]["pair_evidence"] = {
        "pull_request:10|pull_request:11": ["shared_issue_target", "soft_similarity"]
    }
    base["packet"]["soft_pairs"] = [
        {
            **base["packet"]["soft_pairs"][0],
            "evidence_types": ["shared_issue_target", "soft_similarity"],
            "shared_targets": [1, 2],
            "shared_filenames": ["src/alpha.py", "src/beta.py"],
        }
    ]

    assert prepared_review_unit_hash(base) == prepared_review_unit_hash(reordered)


def test_hybrid_review_cache_store_round_trips_and_invalidates_on_manifest_mismatch(
    tmp_path: Path,
) -> None:
    cache_dir = tmp_path / "analysis-state"
    manifest = _manifest()
    prepared_review_unit = _prepared_review_unit()
    key = build_hybrid_review_cache_key(
        manifest=manifest,
        model="gpt-5.4-mini?service_tier=flex",
        prepared_review_unit=prepared_review_unit,
    )
    entry = HybridReviewCacheEntry(
        key=key,
        result={
            "analyst_result": {
                "summary": "cached",
                "confidence": 0.9,
                "soft_edge_verdicts": [],
            },
            "evaluator_result": None,
            "error_kind": None,
            "error_message": None,
            "evaluator_used": False,
            "retried": False,
        },
        cached_at="2026-04-09T00:00:00Z",
        nodes=("pull_request:10", "pull_request:11"),
        soft_pairs=("pull_request:10|pull_request:11",),
        budget={
            "node_count": 2,
            "item_count": 2,
            "soft_pair_count": 1,
            "serialized_chars": 100,
            "estimated_input_tokens": 25,
            "estimated_eval_tokens": 306,
        },
    )

    store = HybridReviewCacheStore(cache_dir, manifest)
    store.put(entry)

    reloaded = HybridReviewCacheStore(cache_dir, manifest)
    mismatch = HybridReviewCacheStore(
        cache_dir,
        replace(manifest, analyst_prompt_version="2.0"),
    )

    assert reloaded.get(key) == entry
    assert mismatch.get(key) is None
    assert mismatch.has_entries is False
    assert mismatch.invalidation_reason == "manifest_mismatch"


def _manifest() -> HybridReviewCacheManifest:
    return HybridReviewCacheManifest(
        cache_schema_version=HYBRID_REVIEW_CACHE_SCHEMA_VERSION,
        prepared_review_unit_schema_version=PREPARED_REVIEW_UNIT_SCHEMA_VERSION,
        analyst_prompt_version="1.0",
        evaluator_prompt_version="1.0",
        hybrid_review_settings=HybridReviewSettingsFingerprint(
            llm_max_input_tokens=60_000,
            llm_max_nodes_per_packet=48,
            llm_max_soft_pairs_per_packet=72,
            llm_max_diff_chars_per_item=1_200,
            llm_max_filenames_per_item=16,
            llm_skip_evaluator_above_tokens=60_000,
            llm_overflow_policy="truncate_then_skip",
        ),
    )


def _prepared_review_unit(
    *,
    diff_preview: str = "alpha",
    filenames: tuple[str, ...] = ("src/alpha.py",),
) -> dict[str, Any]:
    return {
        "packet": {
            "nodes": ["pull_request:10", "pull_request:11"],
            "items": [
                {
                    "node_id": "pull_request:10",
                    "filenames": list(filenames),
                    "diff_preview": diff_preview,
                },
                {
                    "node_id": "pull_request:11",
                    "filenames": list(filenames),
                    "diff_preview": diff_preview,
                },
            ],
            "pair_evidence": {"pull_request:10|pull_request:11": ["soft_similarity"]},
            "soft_pairs": [
                {
                    "left": "pull_request:10",
                    "right": "pull_request:11",
                    "score": 8.0,
                    "jaccard": 0.7,
                    "evidence_types": ["soft_similarity"],
                    "shared_targets": [1],
                    "shared_filenames": list(filenames),
                    "deterministic_accept": False,
                }
            ],
        },
        "budget": {
            "node_count": 2,
            "item_count": 2,
            "soft_pair_count": 1,
            "serialized_chars": 100,
            "estimated_input_tokens": 25,
            "estimated_eval_tokens": 306,
        },
        "original_budget": {
            "node_count": 2,
            "item_count": 2,
            "soft_pair_count": 1,
            "serialized_chars": 100,
            "estimated_input_tokens": 25,
            "estimated_eval_tokens": 306,
        },
        "trimmed": False,
        "aggressively_trimmed": False,
        "split": False,
    }
