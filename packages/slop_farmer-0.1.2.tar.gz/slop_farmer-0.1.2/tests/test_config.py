from __future__ import annotations

import os
from pathlib import Path

import pytest

from slop_farmer.app.cli import build_parser
from slop_farmer.app_config import command_defaults
from slop_farmer.config import AnalysisOptions, resolve_github_token


def test_resolve_github_token_reads_dotenv(tmp_path: Path) -> None:
    previous = Path.cwd()
    previous_tokens = {
        key: os.environ.get(key) for key in ("GITHUB_TOKEN", "GRAPHQL_TOKEN", "GH_TOKEN")
    }
    try:
        os.chdir(tmp_path)
        for key in previous_tokens:
            os.environ.pop(key, None)
        (tmp_path / ".env").write_text("GRAPHQL_TOKEN=dotenv-token\n", encoding="utf-8")
        assert resolve_github_token() == "dotenv-token"
    finally:
        for key, value in previous_tokens.items():
            if value is None:
                os.environ.pop(key, None)
            else:
                os.environ[key] = value
        os.chdir(previous)


def test_command_defaults_reads_pyproject(tmp_path: Path) -> None:
    previous = Path.cwd()
    try:
        os.chdir(tmp_path)
        (tmp_path / "pyproject.toml").write_text(
            """
[tool.slop-farmer.analyze]
hf-repo-id = "evalstate/transformers-pr"
model = "gpt-5.4-mini?service_tier=flex"
""".strip()
            + "\n",
            encoding="utf-8",
        )
        defaults = command_defaults("analyze")
        assert defaults["hf-repo-id"] == "evalstate/transformers-pr"
        assert defaults["model"] == "gpt-5.4-mini?service_tier=flex"
    finally:
        os.chdir(previous)


def test_build_parser_uses_project_analyze_defaults(tmp_path: Path) -> None:
    previous = Path.cwd()
    try:
        os.chdir(tmp_path)
        (tmp_path / "pyproject.toml").write_text(
            """
[tool.slop-farmer.analyze]
output-dir = "eval_data"
hf-repo-id = "evalstate/transformers-pr"
ranking-backend = "hybrid"
model = "gpt-5.4-mini?service_tier=flex"
max-clusters = 12
hybrid-llm-concurrency = 4
""".strip()
            + "\n",
            encoding="utf-8",
        )
        args = build_parser().parse_args(["analyze"])
        assert args.output_dir == Path("eval_data")
        assert args.hf_repo_id == "evalstate/transformers-pr"
        assert args.ranking_backend == "hybrid"
        assert args.model == "gpt-5.4-mini?service_tier=flex"
        assert args.max_clusters == 12
        assert args.hybrid_llm_concurrency == 4
    finally:
        os.chdir(previous)


def test_build_parser_exposes_scrape_age_caps(tmp_path: Path) -> None:
    previous = Path.cwd()
    try:
        os.chdir(tmp_path)
        (tmp_path / "pyproject.toml").write_text(
            """
[tool.slop-farmer.scrape]
issue-max-age-days = 30
pr-max-age-days = 14
""".strip()
            + "\n",
            encoding="utf-8",
        )
        args = build_parser().parse_args(["scrape"])
        assert args.issue_max_age_days == 30
        assert args.pr_max_age_days == 14
    finally:
        os.chdir(previous)


def test_build_parser_exposes_analyze_open_prs_only_flag(tmp_path: Path) -> None:
    previous = Path.cwd()
    try:
        os.chdir(tmp_path)
        args = build_parser().parse_args(["analyze", "--open-prs-only"])
        assert args.open_prs_only is True
    finally:
        os.chdir(previous)


def test_build_parser_rejects_invalid_hybrid_llm_concurrency(tmp_path: Path) -> None:
    previous = Path.cwd()
    try:
        os.chdir(tmp_path)
        with pytest.raises(SystemExit):
            build_parser().parse_args(["analyze", "--hybrid-llm-concurrency", "0"])
    finally:
        os.chdir(previous)


def test_analysis_options_reject_invalid_hybrid_llm_concurrency(tmp_path: Path) -> None:
    with pytest.raises(ValueError, match="hybrid_llm_concurrency must be >= 1"):
        AnalysisOptions(
            snapshot_dir=None,
            output_dir=tmp_path,
            output=None,
            hf_repo_id=None,
            hf_revision=None,
            hf_materialize_dir=None,
            ranking_backend="hybrid",
            model="gpt-5.4-mini?service_tier=flex",
            max_clusters=10,
            hybrid_llm_concurrency=0,
        )


def test_command_defaults_reads_yaml_dashboard_config(tmp_path: Path) -> None:
    config_path = tmp_path / "diffusers.yaml"
    config_path.write_text(
        r"""
repo: huggingface/diffusers
workspace: runs/diffusers
dataset_id: evalstate/diffusers-pr
dashboard:
  space_id: evalstate/diffusers-dashboard
  title: Diffusers Dashboard
  window_days: 60
  contributor_window_days: 60
  contributor_max_authors: 0
pull-requests:
  template_cleanup:
    mode: merge_defaults
    strip_html_comments: true
    trim_closing_reference_prefix: true
    line_patterns:
      - '^d(?:o not merge|ontmerge)\.?$'
  cluster_suppression_rules:
    - id: diffusers_post_release
      title_patterns:
        - '\bpost[- ]release\b'
analysis:
  model: gpt-5.4-mini
  hybrid_llm_concurrency: 3
  cached_analysis: true
scrape:
  max-issue-comments: 123
  max-reviews-per-pr: 17
  max-review-comments-per-pr: 31
""".strip()
        + "\n",
        encoding="utf-8",
    )

    scrape_defaults = command_defaults("scrape", config_path=config_path)
    refresh_defaults = command_defaults("refresh-dataset", config_path=config_path)
    dashboard_defaults = command_defaults("dashboard-data", config_path=config_path)
    publish_defaults = command_defaults("publish-analysis-artifacts", config_path=config_path)
    save_cache_defaults = command_defaults("save-cache", config_path=config_path)
    deploy_defaults = command_defaults("deploy-dashboard", config_path=config_path)
    analyze_defaults = command_defaults("analyze", config_path=config_path)
    pr_scope_defaults = command_defaults("pr-scope", config_path=config_path)
    pr_search_defaults = command_defaults("pr-search", config_path=config_path)
    contributor_defaults = command_defaults("new-contributor-report", config_path=config_path)
    dataset_status_defaults = command_defaults("dataset-status", config_path=config_path)

    assert scrape_defaults["repo"] == "huggingface/diffusers"
    assert scrape_defaults["output-dir"].endswith("runs/diffusers/data")
    assert scrape_defaults["hf-repo-id"] == "evalstate/diffusers-pr"
    assert refresh_defaults["hf-repo-id"] == "evalstate/diffusers-pr"
    assert refresh_defaults["max-issue-comments"] == 123
    assert refresh_defaults["max-reviews-per-pr"] == 17
    assert refresh_defaults["max-review-comments-per-pr"] == 31
    assert refresh_defaults["cluster-suppression-rules"][0]["id"] == "diffusers_post_release"
    assert dashboard_defaults["window-days"] == 60
    assert dashboard_defaults["output-dir"].endswith("runs/diffusers/web/public/data")
    assert dashboard_defaults["snapshot-root"].endswith("runs/diffusers/data/snapshots")
    assert dashboard_defaults["hf-repo-id"] == "evalstate/diffusers-pr"
    assert publish_defaults["output-dir"].endswith("runs/diffusers/data")
    assert publish_defaults["hf-repo-id"] == "evalstate/diffusers-pr"
    assert save_cache_defaults["output-dir"].endswith("runs/diffusers/data")
    assert save_cache_defaults["hf-repo-id"] == "evalstate/diffusers-pr"
    assert deploy_defaults["space-id"] == "evalstate/diffusers-dashboard"
    assert deploy_defaults["contributor-window-days"] == 60
    assert deploy_defaults["hf-repo-id"] == "evalstate/diffusers-pr"
    assert analyze_defaults["hf-repo-id"] == "evalstate/diffusers-pr"
    assert analyze_defaults["hybrid-llm-concurrency"] == 3
    assert analyze_defaults["cached_analysis"] is True
    assert pr_scope_defaults["cluster-suppression-rules"][0]["id"] == "diffusers_post_release"
    assert pr_scope_defaults["cluster-suppression-rules"][0]["title_patterns"] == [
        r"\bpost[- ]release\b"
    ]
    assert pr_scope_defaults["hf-repo-id"] == "evalstate/diffusers-pr"
    assert pr_search_defaults["hf-repo-id"] == "evalstate/diffusers-pr"
    assert contributor_defaults["hf-repo-id"] == "evalstate/diffusers-pr"
    assert dataset_status_defaults["hf-repo-id"] == "evalstate/diffusers-pr"
    assert analyze_defaults["pr-template-cleanup-mode"] == "merge_defaults"
    assert analyze_defaults["pr-template-strip-html-comments"] is True
    assert analyze_defaults["pr-template-trim-closing-reference-prefix"] is True
    assert analyze_defaults["pr-template-line-patterns"] == (r"^d(?:o not merge|ontmerge)\.?$",)


def test_build_parser_uses_yaml_config_defaults(tmp_path: Path) -> None:
    config_path = tmp_path / "diffusers.yaml"
    config_path.write_text(
        """
repo: huggingface/diffusers
workspace: runs/diffusers
dataset_id: evalstate/diffusers-pr
dashboard:
  space_id: evalstate/diffusers-dashboard
  title: Diffusers Dashboard
  window_days: 60
  contributor_window_days: 60
analysis:
  model: gpt-5.4-mini
  hybrid_llm_concurrency: 3
  cached_analysis: true
scrape:
  fetch-timeline: true
  max-issue-comments: 123
  max-reviews-per-pr: 17
  max-review-comments-per-pr: 31
""".strip()
        + "\n",
        encoding="utf-8",
    )

    args = build_parser(config_path=config_path).parse_args(["dashboard-data"])
    assert args.output_dir == (tmp_path / "runs/diffusers/web/public/data").resolve()
    assert args.window_days == 60

    scrape_args = build_parser(config_path=config_path).parse_args(["scrape"])
    assert scrape_args.fetch_timeline is True

    deploy_args = build_parser(config_path=config_path).parse_args(["deploy-dashboard"])
    assert deploy_args.space_id == "evalstate/diffusers-dashboard"
    assert deploy_args.web_dir == (tmp_path / "runs/diffusers/web").resolve()
    assert deploy_args.pr_scope_input is None

    publish_args = build_parser(config_path=config_path).parse_args(["publish-analysis-artifacts"])
    assert publish_args.output_dir == (tmp_path / "runs/diffusers/data").resolve()
    assert publish_args.hf_repo_id == "evalstate/diffusers-pr"
    assert publish_args.analysis_id is None

    save_cache_args = build_parser(config_path=config_path).parse_args(["save-cache"])
    assert save_cache_args.output_dir == (tmp_path / "runs/diffusers/data").resolve()
    assert save_cache_args.hf_repo_id == "evalstate/diffusers-pr"

    analyze_args = build_parser(config_path=config_path).parse_args(["analyze"])
    assert analyze_args.hf_repo_id == "evalstate/diffusers-pr"
    assert analyze_args.hybrid_llm_concurrency == 3

    pr_scope_args = build_parser(config_path=config_path).parse_args(["pr-scope"])
    assert pr_scope_args.hf_repo_id == "evalstate/diffusers-pr"

    pr_search_args = build_parser(config_path=config_path).parse_args(["pr-search", "refresh"])
    assert pr_search_args.hf_repo_id == "evalstate/diffusers-pr"

    contributor_args = build_parser(config_path=config_path).parse_args(["new-contributor-report"])
    assert contributor_args.hf_repo_id == "evalstate/diffusers-pr"

    refresh_args = build_parser(config_path=config_path).parse_args(["refresh-dataset"])
    assert refresh_args.hf_repo_id == "evalstate/diffusers-pr"
    assert refresh_args.max_issue_comments == 123
    assert refresh_args.max_reviews_per_pr == 17
    assert refresh_args.max_review_comments_per_pr == 31

    dataset_status_args = build_parser(config_path=config_path).parse_args(["dataset-status"])
    assert dataset_status_args.hf_repo_id == "evalstate/diffusers-pr"


def test_openclaw_config_uses_dataset_id_for_analyze_defaults() -> None:
    config_path = Path(__file__).resolve().parents[1] / "configs" / "openclaw.yaml"
    args = build_parser(config_path=config_path).parse_args(["analyze"])
    assert args.hf_repo_id == "evalstate/openclaw-pr"
    deploy_args = build_parser(config_path=config_path).parse_args(["deploy-dashboard"])
    assert deploy_args.space_id == "evalstate/openclaw-pr-report"


def test_yaml_config_paths_resolve_from_project_root(tmp_path: Path) -> None:
    (tmp_path / "pyproject.toml").write_text(
        "[project]\nname='x'\nversion='0.0.0'\n", encoding="utf-8"
    )
    config_dir = tmp_path / "configs"
    config_dir.mkdir()
    config_path = config_dir / "transformers.yaml"
    config_path.write_text(
        """
repo: huggingface/transformers
workspace: runs/transformers-recent-60d
dataset_id: evalstate/transformers-pr
""".strip()
        + "\n",
        encoding="utf-8",
    )

    scrape_defaults = command_defaults("scrape", config_path=config_path)

    assert scrape_defaults["output-dir"] == str(
        (tmp_path / "runs/transformers-recent-60d/data").resolve()
    )
