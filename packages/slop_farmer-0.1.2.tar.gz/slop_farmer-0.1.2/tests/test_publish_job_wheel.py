from __future__ import annotations

import json
import os
import stat
import subprocess
import tomllib
from pathlib import Path


def _write_executable(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")
    path.chmod(path.stat().st_mode | stat.S_IXUSR)


def test_publish_job_wheel_builds_uploads_and_prints_versioned_url(tmp_path: Path) -> None:
    pyproject = tomllib.loads(Path("pyproject.toml").read_text(encoding="utf-8"))
    version = pyproject["project"]["version"]

    stub_dir = tmp_path / "stubs"
    stub_dir.mkdir()
    call_dir = tmp_path / "hf-calls"
    call_dir.mkdir()
    uv_args_path = tmp_path / "uv-args.txt"
    latest_capture_path = tmp_path / "latest.json"

    _write_executable(
        stub_dir / "uv",
        f"""#!/usr/bin/env bash
set -euo pipefail
printf '%s\\n' "$@" >"$UV_ARGS_PATH"
out_dir=""
while [[ $# -gt 0 ]]; do
  case "$1" in
    --out-dir|-o)
      out_dir="$2"
      shift 2
      ;;
    *)
      shift
      ;;
  esac
done
[[ -n "$out_dir" ]] || {{ echo "missing --out-dir" >&2; exit 1; }}
mkdir -p "$out_dir"
: >"$out_dir/slop_farmer-{version}-py3-none-any.whl"
""",
    )

    _write_executable(
        stub_dir / "hf",
        """#!/usr/bin/env bash
set -euo pipefail
counter_file="$HF_CALL_DIR/counter.txt"
if [[ -f "$counter_file" ]]; then
  count="$(cat "$counter_file")"
else
  count=0
fi
count="$((count + 1))"
printf '%s' "$count" >"$counter_file"
printf '%s\n' "$@" >"$HF_CALL_DIR/call-$count.txt"
if [[ "${1:-}" == "upload" && "${4:-}" == "wheels/latest.json" ]]; then
  cp "$3" "$HF_LATEST_CAPTURE_PATH"
fi
""",
    )

    env = os.environ.copy()
    env["UV_ARGS_PATH"] = str(uv_args_path)
    env["HF_CALL_DIR"] = str(call_dir)
    env["HF_LATEST_CAPTURE_PATH"] = str(latest_capture_path)
    env["HF_REPO_ID"] = "evalstate/test-job-artifacts"
    env["PATH"] = f"{stub_dir}:{env['PATH']}"

    result = subprocess.run(
        ["bash", str(Path("scripts/publish_job_wheel.sh").resolve())],
        cwd=Path.cwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr

    uv_args = uv_args_path.read_text(encoding="utf-8").splitlines()
    assert uv_args[:3] == ["build", str(Path.cwd()), "--wheel"]
    assert "--out-dir" in uv_args

    create_args = (call_dir / "call-1.txt").read_text(encoding="utf-8").splitlines()
    assert create_args == [
        "repo",
        "create",
        "evalstate/test-job-artifacts",
        "--type",
        "dataset",
        "--exist-ok",
    ]

    wheel_upload_args = (call_dir / "call-2.txt").read_text(encoding="utf-8").splitlines()
    assert wheel_upload_args[0] == "upload"
    assert wheel_upload_args[1] == "evalstate/test-job-artifacts"
    assert wheel_upload_args[3] == f"wheels/slop_farmer-{version}-py3-none-any.whl"
    assert wheel_upload_args[4:8] == [
        "--repo-type",
        "dataset",
        "--commit-message",
        f"Publish slop-farmer {version}",
    ]

    latest_upload_args = (call_dir / "call-3.txt").read_text(encoding="utf-8").splitlines()
    assert latest_upload_args == [
        "upload",
        "evalstate/test-job-artifacts",
        latest_upload_args[2],
        "wheels/latest.json",
        "--repo-type",
        "dataset",
        "--commit-message",
        f"Publish slop-farmer {version}",
    ]

    latest_payload = json.loads(latest_capture_path.read_text(encoding="utf-8"))
    assert latest_payload["package"] == "slop-farmer"
    assert latest_payload["version"] == version
    assert latest_payload["wheel_filename"] == f"slop_farmer-{version}-py3-none-any.whl"
    assert latest_payload["wheel_path"] == f"wheels/slop_farmer-{version}-py3-none-any.whl"
    assert (
        latest_payload["wheel_url"]
        == f"https://huggingface.co/datasets/evalstate/test-job-artifacts/resolve/main/wheels/slop_farmer-{version}-py3-none-any.whl"
    )

    assert f"Published slop-farmer {version}" in result.stdout
    assert (
        f"https://huggingface.co/datasets/evalstate/test-job-artifacts/resolve/main/wheels/slop_farmer-{version}-py3-none-any.whl"
        in result.stdout
    )
