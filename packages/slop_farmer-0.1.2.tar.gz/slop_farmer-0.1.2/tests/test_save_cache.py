from __future__ import annotations

from pathlib import Path

import pytest

from slop_farmer.app.save_cache import _resolve_cache_snapshot_dir, _save_analysis_cache_api
from slop_farmer.config import SaveCacheOptions
from slop_farmer.data.parquet_io import write_json


class FakeHfApi:
    def __init__(self) -> None:
        self.calls: list[tuple[str, tuple, dict]] = []

    def create_repo(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        self.calls.append(("create_repo", args, kwargs))

    def upload_folder(self, *args, **kwargs) -> None:  # type: ignore[no-untyped-def]
        self.calls.append(("upload_folder", args, kwargs))


def test_save_analysis_cache_uploads_analysis_state(tmp_path: Path) -> None:
    snapshot_dir = tmp_path / "snapshots" / "20260415T000000Z"
    snapshot_dir.mkdir(parents=True)
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260415T000000Z",
        },
        snapshot_dir / "manifest.json",
    )
    cache_dir = snapshot_dir / "analysis-state"
    (cache_dir / "nested").mkdir(parents=True)
    write_json({"cache_schema_version": "1.0"}, cache_dir / "hybrid-review-cache-manifest.json")
    (cache_dir / "nested" / "reviews.json").write_text("[]", encoding="utf-8")
    api = FakeHfApi()
    logs: list[str] = []

    result = _save_analysis_cache_api(
        api,
        snapshot_dir=snapshot_dir,
        hf_repo_id="evalstate/transformers-pr",
        private=False,
        log=logs.append,
    )

    assert result == {
        "repo": "huggingface/transformers",
        "dataset_id": "evalstate/transformers-pr",
        "snapshot_id": "20260415T000000Z",
        "artifact_paths": [
            "analysis-state/hybrid-review-cache-manifest.json",
            "analysis-state/nested/reviews.json",
        ],
    }
    assert api.calls == [
        (
            "create_repo",
            ("evalstate/transformers-pr",),
            {"repo_type": "dataset", "private": False, "exist_ok": True},
        ),
        (
            "upload_folder",
            (),
            {
                "repo_id": "evalstate/transformers-pr",
                "folder_path": cache_dir,
                "path_in_repo": "analysis-state",
                "repo_type": "dataset",
                "commit_message": "Save analysis cache for snapshot 20260415T000000Z",
            },
        ),
    ]
    assert logs == [
        "Ensuring Hub dataset repo exists: evalstate/transformers-pr",
        "Saving analysis cache for snapshot 20260415T000000Z",
        "Saved analysis cache to evalstate/transformers-pr",
    ]


def test_save_analysis_cache_requires_existing_non_empty_directory(tmp_path: Path) -> None:
    snapshot_dir = tmp_path / "snapshots" / "20260415T000000Z"
    snapshot_dir.mkdir(parents=True)
    write_json({"snapshot_id": "20260415T000000Z"}, snapshot_dir / "manifest.json")
    api = FakeHfApi()

    with pytest.raises(FileNotFoundError, match="Analysis cache directory is missing"):
        _save_analysis_cache_api(
            api,
            snapshot_dir=snapshot_dir,
            hf_repo_id="evalstate/transformers-pr",
            private=False,
        )

    (snapshot_dir / "analysis-state").mkdir()
    with pytest.raises(ValueError, match="Analysis cache directory is empty"):
        _save_analysis_cache_api(
            api,
            snapshot_dir=snapshot_dir,
            hf_repo_id="evalstate/transformers-pr",
            private=False,
        )


def test_save_cache_prefers_existing_local_materialized_snapshot(
    tmp_path: Path,
    monkeypatch: pytest.MonkeyPatch,
) -> None:
    output_dir = tmp_path / "data"
    snapshot_dir = output_dir / "snapshots" / "hf-evalstate--transformers-pr"
    (snapshot_dir / "analysis-state").mkdir(parents=True)
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260415T000000Z",
        },
        snapshot_dir / "manifest.json",
    )
    monkeypatch.setattr(
        "slop_farmer.app.save_cache.resolve_snapshot_source_dir",
        lambda **kwargs: (_ for _ in ()).throw(AssertionError("should not rematerialize")),
    )

    resolved = _resolve_cache_snapshot_dir(
        SaveCacheOptions(
            output_dir=output_dir,
            snapshot_dir=None,
            hf_repo_id="evalstate/transformers-pr",
            hf_revision=None,
            hf_materialize_dir=None,
        )
    )

    assert resolved == snapshot_dir.resolve()
