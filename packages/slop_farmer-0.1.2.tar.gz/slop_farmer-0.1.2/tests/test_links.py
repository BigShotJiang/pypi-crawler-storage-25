from slop_farmer.data.links import build_pr_duplicate_candidate_rows, extract_references


def test_extract_references_captures_mentions_and_closing_keywords() -> None:
    refs = extract_references(
        "Fixes #123 and see huggingface/transformers#456", "huggingface", "transformers"
    )
    assert any(
        ref["target_number"] == 123 and ref["reference_kind"] == "closing_reference" for ref in refs
    )
    assert any(ref["target_number"] == 456 and ref["reference_kind"] == "mention" for ref in refs)


def test_extract_references_captures_duplicate_references() -> None:
    refs = extract_references(
        "Duplicate of huggingface/transformers#789", "huggingface", "transformers"
    )
    assert any(
        ref["target_number"] == 789 and ref["reference_kind"] == "duplicate_reference"
        for ref in refs
    )


def test_build_pr_duplicate_candidate_rows_groups_prs_by_shared_target() -> None:
    pull_requests = [{"number": 10}, {"number": 11}, {"number": 12}]
    links = [
        {
            "source_type": "pull_request",
            "source_number": 10,
            "target_owner": "huggingface",
            "target_repo": "transformers",
            "target_number": 99,
        },
        {
            "source_type": "pull_request",
            "source_number": 11,
            "target_owner": "huggingface",
            "target_repo": "transformers",
            "target_number": 99,
        },
        {
            "source_type": "pull_request",
            "source_number": 12,
            "target_owner": "huggingface",
            "target_repo": "transformers",
            "target_number": 100,
        },
    ]
    rows = build_pr_duplicate_candidate_rows(
        repo="huggingface/transformers",
        pull_requests=pull_requests,
        link_rows=links,
        snapshot_id="snap",
        extracted_at="2026-03-19T00:00:00Z",
    )
    assert len(rows) == 2
    assert {row["source_number"] for row in rows} == {10, 11}
