from __future__ import annotations

import importlib.util
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def test_fast_agent_setup_schema_uses_provider_friendly_boolean_enum() -> None:
    schema_path = (
        ROOT / "skills" / "farmer-setup" / "references" / "fast-agent-config-synthesis.schema.json"
    )
    schema = json.loads(schema_path.read_text(encoding="utf-8"))

    assert schema["type"] == "object"
    assert schema["properties"]["issues"]["properties"]["advisory_only"] == {
        "type": "boolean",
        "enum": [True],
    }
    assert schema["properties"]["pull_requests"]["required"] == [
        "template_cleanup",
        "cluster_suppression_rules",
    ]


def test_fast_agent_setup_prompt_relies_on_json_schema_contract() -> None:
    prompt_path = (
        ROOT / "skills" / "farmer-setup" / "references" / "fast-agent-config-synthesis-prompt.md"
    )
    prompt = prompt_path.read_text(encoding="utf-8")

    assert "matches the provided JSON Schema" in prompt
    assert "Return exactly this JSON shape" not in prompt


def _load_suggest_setup_config_module():
    script_dir = ROOT / "skills" / "farmer-setup" / "scripts"
    module_path = script_dir / "suggest_setup_config.py"
    sys.path.insert(0, str(script_dir))
    try:
        spec = importlib.util.spec_from_file_location("suggest_setup_config", module_path)
        assert spec is not None
        assert spec.loader is not None
        module = importlib.util.module_from_spec(spec)
        sys.modules[spec.name] = module
        spec.loader.exec_module(module)
        return module
    finally:
        sys.path.pop(0)


def test_farmer_setup_heuristics_keep_summary_but_strip_low_signal_sections() -> None:
    module = _load_suggest_setup_config_module()
    evidence = {
        "repo": "openclaw/openclaw",
        "templates": {
            "effective": {
                "pull_request_templates": [
                    {
                        "headings": [
                            "Summary",
                            "Change Type (select all)",
                            "Scope (select all touched areas)",
                            "Review Conversations",
                        ]
                    }
                ]
            }
        },
        "pull_requests": {
            "body_patterns": {
                "headings": [
                    {"text": "Summary", "pattern": "^#{1,6}\\s*Summary\\s*$", "count": 96},
                    {
                        "text": "Change Type (select all)",
                        "pattern": "^#{1,6}\\s*Change\\s+Type\\s+\\(select\\s+all\\)\\s*$",
                        "count": 33,
                    },
                    {
                        "text": "Scope (select all touched areas)",
                        "pattern": "^#{1,6}\\s*Scope\\s+\\(select\\s+all\\s+touched\\s+areas\\)\\s*$",
                        "count": 33,
                    },
                    {
                        "text": "Review Conversations",
                        "pattern": "^#{1,6}\\s*Review\\s+Conversations\\s*$",
                        "count": 27,
                    },
                    {
                        "text": "Failure Recovery (if this breaks)",
                        "pattern": "^#{1,6}\\s*Failure\\s+Recovery\\s+\\(if\\s+this\\s+breaks\\)\\s*$",
                        "count": 4,
                    },
                ],
                "checklist_lines": [],
                "repeated_lines": [
                    {
                        "text": "Describe the problem and fix in 2\u20135 bullets:",
                        "pattern": "^Describe\\s+the\\s+problem\\s+and\\s+fix\\s+in\\s+2[-]5\\s+bullets:\\s*$",
                        "count": 20,
                    }
                ],
            },
            "routine_title_hints": [],
        },
        "issues": {
            "body_patterns": {
                "headings": [],
                "repeated_lines": [],
            }
        },
    }

    heuristics = module.build_heuristic_suggestions(evidence)
    section_texts = [
        item["text"] for item in heuristics["pull_requests"]["template_cleanup"]["section_patterns"]
    ]
    line_texts = [
        item["text"] for item in heuristics["pull_requests"]["template_cleanup"]["line_patterns"]
    ]

    assert "Summary" not in section_texts
    assert "Change Type (select all)" in section_texts
    assert "Scope (select all touched areas)" in section_texts
    assert "Review Conversations" in section_texts
    assert "Failure Recovery (if this breaks)" in section_texts
    assert "Describe the problem and fix in 2\u20135 bullets:" in line_texts
    pattern_by_text = {
        item["text"]: item["pattern"]
        for item in heuristics["pull_requests"]["template_cleanup"]["line_patterns"]
    }
    assert pattern_by_text["Describe the problem and fix in 2\u20135 bullets:"] == (
        "^Describe\\s+the\\s+problem\\s+and\\s+fix\\s+in\\s+2[\u2013-]5\\s+bullets:\\s*$"
    )
