from __future__ import annotations

import os
import stat
import subprocess
from pathlib import Path


def _write_executable(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")
    path.chmod(path.stat().st_mode | stat.S_IXUSR)


def test_submit_dataset_job_uses_named_secrets_and_accepts_graphql_token(tmp_path: Path) -> None:
    stub_dir = tmp_path / "stubs"
    stub_dir.mkdir()
    args_path = tmp_path / "hf-args.txt"
    github_token_path = tmp_path / "hf-github-token.txt"
    hf_token_path = tmp_path / "hf-hf-token.txt"

    _write_executable(
        stub_dir / "hf",
        """#!/usr/bin/env bash
set -euo pipefail
printf '%s\n' "$@" >"$HF_ARGS_PATH"
printf '%s\n' "${GITHUB_TOKEN:-}" >"$HF_GITHUB_TOKEN_PATH"
printf '%s\n' "${HF_TOKEN:-__MISSING__}" >"$HF_HF_TOKEN_PATH"
""",
    )

    env = os.environ.copy()
    env.pop("HF_TOKEN", None)
    env.pop("GITHUB_TOKEN", None)
    env["GRAPHQL_TOKEN"] = "graphql-only-token"
    env["HF_ARGS_PATH"] = str(args_path)
    env["HF_GITHUB_TOKEN_PATH"] = str(github_token_path)
    env["HF_HF_TOKEN_PATH"] = str(hf_token_path)
    env["PATH"] = f"{stub_dir}:{env['PATH']}"
    env["MODE"] = "run"
    env["CONFIG_PATH"] = "configs/transformers.yaml"

    result = subprocess.run(
        ["bash", str(Path("scripts/submit_dataset_job.sh").resolve())],
        cwd=Path.cwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    args = args_path.read_text(encoding="utf-8").splitlines()
    assert "--secrets" in args
    assert "HF_TOKEN" in args
    assert "GITHUB_TOKEN" in args
    assert "HF_TOKEN=graphql-only-token" not in result.stdout
    assert "GITHUB_TOKEN=graphql-only-token" not in result.stdout
    assert github_token_path.read_text(encoding="utf-8").strip() == "graphql-only-token"
    assert hf_token_path.read_text(encoding="utf-8").strip() == "__MISSING__"
