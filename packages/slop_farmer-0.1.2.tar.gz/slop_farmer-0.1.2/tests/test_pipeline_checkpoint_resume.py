from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

import pytest

from slop_farmer.app.pipeline import run_pipeline
from slop_farmer.config import PipelineOptions, RepoRef
from slop_farmer.data.parquet_io import read_json, read_parquet_rows


def _user(login: str, user_id: int) -> dict[str, object]:
    return {
        "login": login,
        "id": user_id,
        "node_id": f"U_{user_id}",
        "type": "User",
        "site_admin": False,
    }


def _issue_stub(number: int, *, is_pr: bool = False, comments: int = 0) -> dict[str, object]:
    payload: dict[str, object] = {
        "id": number,
        "node_id": f"N_{number}",
        "number": number,
        "html_url": f"https://example.test/issues/{number}",
        "url": f"https://api.example.test/issues/{number}",
        "title": f"Item {number}",
        "body": f"Body for #{number}",
        "state": "open",
        "state_reason": None,
        "locked": False,
        "comments": comments,
        "labels": [],
        "assignees": [],
        "created_at": "2026-03-25T00:00:00Z",
        "updated_at": "2026-03-25T00:00:00Z",
        "closed_at": None,
        "author_association": "CONTRIBUTOR",
        "milestone": None,
        "user": _user("author", number),
    }
    if is_pr:
        payload["pull_request"] = {"url": f"https://api.example.test/pulls/{number}"}
    return payload


def _pr_detail(number: int) -> dict[str, object]:
    return {
        "id": number,
        "node_id": f"PR_{number}",
        "merged_at": None,
        "merge_commit_sha": f"merge-{number}",
        "merged": False,
        "mergeable": True,
        "mergeable_state": "clean",
        "draft": False,
        "additions": 3,
        "deletions": 1,
        "changed_files": 1,
        "commits": 1,
        "review_comments": 1,
        "maintainer_can_modify": True,
        "head": {
            "ref": f"feature-{number}",
            "sha": f"head-{number}",
            "repo": {"full_name": "octo/widgets"},
        },
        "base": {
            "ref": "main",
            "sha": f"base-{number}",
            "repo": {"full_name": "octo/widgets"},
        },
    }


def _review(number: int) -> dict[str, object]:
    return {
        "id": number,
        "node_id": f"R_{number}",
        "html_url": f"https://example.test/reviews/{number}",
        "url": f"https://api.example.test/reviews/{number}",
        "body": "Looks good",
        "state": "APPROVED",
        "submitted_at": "2026-03-25T00:10:00Z",
        "commit_id": f"review-{number}",
        "author_association": "MEMBER",
        "user": _user("reviewer", number),
    }


def _review_comment(number: int, pr_number: int) -> dict[str, object]:
    return {
        "id": number,
        "node_id": f"RC_{number}",
        "pull_request_review_id": number,
        "html_url": f"https://example.test/review-comments/{number}",
        "url": f"https://api.example.test/review-comments/{number}",
        "pull_request_url": f"https://api.example.test/pulls/{pr_number}",
        "body": "Nit",
        "path": "src/app.py",
        "commit_id": f"commit-{number}",
        "original_commit_id": f"orig-{number}",
        "position": 1,
        "original_position": 1,
        "line": 1,
        "start_line": None,
        "side": "RIGHT",
        "start_side": None,
        "subject_type": "line",
        "created_at": "2026-03-25T00:11:00Z",
        "updated_at": "2026-03-25T00:11:00Z",
        "author_association": "MEMBER",
        "user": _user("reviewer", number),
    }


def _pr_file(number: int) -> dict[str, object]:
    return {
        "sha": f"sha-{number}",
        "filename": f"src/file_{number}.py",
        "status": "modified",
        "additions": 3,
        "deletions": 1,
        "changes": 4,
        "blob_url": f"https://example.test/blob/{number}",
        "raw_url": f"https://example.test/raw/{number}",
        "contents_url": f"https://example.test/contents/{number}",
        "previous_filename": None,
        "patch": "@@ -1 +1 @@",
    }


def _timeline_event(number: int) -> dict[str, object]:
    return {
        "event": "cross-referenced",
        "created_at": "2026-03-25T00:20:00Z",
        "actor": {"login": "bot"},
        "source": {
            "issue": {
                "number": number - 1,
                "title": f"Linked {number - 1}",
                "html_url": f"https://example.test/issues/{number - 1}",
            }
        },
        "commit_id": None,
        "label": None,
    }


class SimulatedGitHubClient:
    def __init__(
        self,
        *,
        issue_stubs: list[dict[str, object]],
        issue_comments: dict[int, list[dict[str, object]]] | None = None,
        timelines: dict[int, list[dict[str, object]]] | None = None,
        crash_on_pr: int | None = None,
        crash_on_issue_timeline: int | None = None,
    ) -> None:
        self.issue_stubs = issue_stubs
        self.issue_comments = issue_comments or {}
        self.timelines = timelines or {}
        self.crash_on_pr = crash_on_pr
        self.crash_on_issue_timeline = crash_on_issue_timeline
        self.get_pull_request_calls: list[int] = []
        self.issue_timeline_calls: list[int] = []

    def iter_repo_issues(self, owner: str, repo: str, since: str | None, limit: int | None):
        del owner, repo, since
        items = self.issue_stubs if limit is None else self.issue_stubs[:limit]
        yield from items

    def iter_issue_comments_for_number(
        self, owner: str, repo: str, number: int, since: str | None, limit: int | None = None
    ):
        del owner, repo, since
        items = self.issue_comments.get(number, [])
        if limit is not None:
            items = items[:limit]
        yield from items

    def get_pull_request(self, owner: str, repo: str, number: int) -> dict[str, object]:
        del owner, repo
        self.get_pull_request_calls.append(number)
        if self.crash_on_pr == number:
            raise RuntimeError(f"boom during PR #{number}")
        return _pr_detail(number)

    def iter_pull_reviews(self, owner: str, repo: str, number: int, limit: int | None = None):
        del owner, repo, limit
        yield _review(number)

    def iter_pull_review_comments(
        self, owner: str, repo: str, number: int, limit: int | None = None
    ):
        del owner, repo, limit
        yield _review_comment(number, number)

    def iter_pull_files(self, owner: str, repo: str, number: int, limit: int | None = None):
        del owner, repo, limit
        yield _pr_file(number)

    def get_pull_request_diff(self, owner: str, repo: str, number: int) -> str:
        del owner, repo
        return f"diff for {number}"

    def iter_issue_timeline(self, owner: str, repo: str, number: int, limit: int | None = None):
        del owner, repo, limit
        self.issue_timeline_calls.append(number)
        if self.crash_on_issue_timeline == number:
            raise RuntimeError(f"boom during issue timeline #{number}")
        yield from self.timelines.get(number, [])


def _options(output_dir: Path, *, fetch_timeline: bool = True) -> PipelineOptions:
    return PipelineOptions(
        repo=RepoRef.parse("octo/widgets"),
        output_dir=output_dir,
        since=None,
        resume=True,
        http_timeout=10,
        http_max_retries=1,
        max_issues=None,
        max_prs=None,
        max_issue_comments=None,
        max_reviews_per_pr=None,
        max_review_comments_per_pr=None,
        fetch_timeline=fetch_timeline,
        new_contributor_report=False,
        new_contributor_window_days=42,
        new_contributor_max_authors=25,
        issue_max_age_days=None,
        pr_max_age_days=None,
    )


def test_run_pipeline_resumes_pull_request_hydration_from_checkpoint(tmp_path: Path) -> None:
    issue_stubs = [_issue_stub(101)] + [
        _issue_stub(number, is_pr=True) for number in range(201, 207)
    ]
    options = _options(tmp_path)

    with pytest.raises(RuntimeError, match="boom during PR #206"):
        run_pipeline(
            options,
            client=SimulatedGitHubClient(issue_stubs=issue_stubs, crash_on_pr=206),
        )

    checkpoint = read_json(tmp_path / "state" / "in_progress.json")
    assert checkpoint["completed_pr_numbers"] == [201, 202, 203, 204, 205]

    resumed_client = SimulatedGitHubClient(issue_stubs=issue_stubs)
    snapshot_dir = run_pipeline(options, client=resumed_client)

    assert resumed_client.get_pull_request_calls == [206]
    assert len(read_parquet_rows(snapshot_dir / "pull_requests.parquet")) == 6
    assert not (tmp_path / "state" / "in_progress.json").exists()


def test_run_pipeline_resumes_issue_timeline_fetch_from_checkpoint(tmp_path: Path) -> None:
    issue_numbers = list(range(101, 127))
    issue_stubs = [_issue_stub(number) for number in issue_numbers] + [_issue_stub(201, is_pr=True)]
    timelines = {126: [_timeline_event(126)]}
    options = _options(tmp_path)

    with pytest.raises(RuntimeError, match="boom during issue timeline #126"):
        run_pipeline(
            options,
            client=SimulatedGitHubClient(
                issue_stubs=issue_stubs,
                timelines=timelines,
                crash_on_issue_timeline=126,
            ),
        )

    checkpoint = read_json(tmp_path / "state" / "in_progress.json")
    assert checkpoint["completed_issue_timeline_numbers"] == list(range(101, 126))

    resumed_client = SimulatedGitHubClient(issue_stubs=issue_stubs, timelines=timelines)
    snapshot_dir = run_pipeline(options, client=resumed_client)

    assert 201 not in resumed_client.get_pull_request_calls
    assert resumed_client.issue_timeline_calls == [126]
    events = read_parquet_rows(snapshot_dir / "events.parquet")
    assert len(events) == 1
    assert events[0]["parent_number"] == 126
    assert not (tmp_path / "state" / "in_progress.json").exists()


def test_run_pipeline_reuses_original_age_cap_reference_time_on_resume(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    class FrozenDateTime(datetime):
        current = datetime(2026, 3, 26, 0, 0, tzinfo=UTC)

        @classmethod
        def now(cls, tz=None):
            value = cls.current
            if tz is None:
                return value.replace(tzinfo=None)
            return value.astimezone(tz)

    monkeypatch.setattr("slop_farmer.app.pipeline.datetime", FrozenDateTime)

    issue_stubs = [_issue_stub(101), _issue_stub(201, is_pr=True)]
    options = _options(tmp_path)
    options.issue_max_age_days = 1
    options.pr_max_age_days = 1

    with pytest.raises(RuntimeError, match="boom during PR #201"):
        run_pipeline(
            options,
            client=SimulatedGitHubClient(issue_stubs=issue_stubs, crash_on_pr=201),
        )

    checkpoint = read_json(tmp_path / "state" / "in_progress.json")
    assert checkpoint["crawl_started_at"] == "2026-03-26T00:00:00Z"

    FrozenDateTime.current = datetime(2026, 3, 27, 0, 0, tzinfo=UTC)
    resumed_client = SimulatedGitHubClient(issue_stubs=issue_stubs)
    snapshot_dir = run_pipeline(options, client=resumed_client)

    assert resumed_client.get_pull_request_calls == [201]
    assert len(read_parquet_rows(snapshot_dir / "issues.parquet")) == 1
    assert len(read_parquet_rows(snapshot_dir / "pull_requests.parquet")) == 1
