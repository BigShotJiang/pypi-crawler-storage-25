from __future__ import annotations

import json
import os
import shutil
import stat
import subprocess
from pathlib import Path

import pytest

SCRIPT_PATHS = [
    Path("scripts/update_transformers_dashboard.sh").resolve(),
    Path("scripts/update_diffusers_dashboard.sh").resolve(),
    Path("scripts/update_openclaw_dashboard.sh").resolve(),
]


def _write_executable(path: Path, content: str) -> None:
    path.write_text(content, encoding="utf-8")
    path.chmod(path.stat().st_mode | stat.S_IXUSR)


@pytest.fixture
def uv_stub(tmp_path: Path) -> tuple[Path, Path]:
    real_uv = shutil.which("uv")
    assert real_uv is not None

    stub_dir = tmp_path / "stubs"
    stub_dir.mkdir()
    log_path = tmp_path / "uv.log"
    _write_executable(
        stub_dir / "uv",
        f"""#!/usr/bin/env bash
set -euo pipefail
if [[ "$#" -ge 2 && "$1" == "run" && "$2" == "python" ]]; then
  exec "{real_uv}" "$@"
fi
printf '%q ' "$@" >>"$UV_LOG_PATH"
printf '\\n' >>"$UV_LOG_PATH"
""",
    )
    return stub_dir, log_path


def _write_latest_pointer(latest_json: Path, snapshot_dir: str) -> Path:
    latest_json.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "repo": "huggingface/example",
        "latest_snapshot_id": "20260418T120000Z",
        "snapshot_dir": snapshot_dir,
    }
    latest_json.write_text(json.dumps(payload), encoding="utf-8")
    return latest_json


@pytest.mark.parametrize("script_path", SCRIPT_PATHS)
def test_update_dashboard_scripts_resolve_relative_latest_snapshot_pointer(
    tmp_path: Path, uv_stub: tuple[Path, Path], script_path: Path
) -> None:
    stub_dir, log_path = uv_stub
    pipeline_data_dir = tmp_path / "runs" / "repo" / "data"
    snapshot_dir = pipeline_data_dir / "snapshots" / "20260418T120000Z"
    snapshot_dir.mkdir(parents=True)
    latest_json = _write_latest_pointer(
        pipeline_data_dir / "snapshots" / "latest.json",
        "snapshots/20260418T120000Z",
    )
    config_path = tmp_path / "config.yaml"
    config_path.write_text("analysis: {}\n", encoding="utf-8")

    env = os.environ.copy()
    env["PATH"] = f"{stub_dir}:{env['PATH']}"
    env["UV_LOG_PATH"] = str(log_path)
    env["CONFIG_PATH"] = str(config_path)
    env["LATEST_JSON"] = str(latest_json)

    result = subprocess.run(
        ["bash", str(script_path)],
        cwd=Path.cwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    log_text = log_path.read_text(encoding="utf-8")
    expected_snapshot = str(snapshot_dir.resolve())
    assert f"analyze --snapshot-dir {expected_snapshot}" in log_text
    assert f"--output {expected_snapshot}/analysis-report-hybrid.json" in log_text
    assert f"pr-scope --snapshot-dir {expected_snapshot}" in log_text
    assert f"deploy-dashboard --snapshot-dir {expected_snapshot}" in log_text
    assert f"--analysis-input {expected_snapshot}/analysis-report-hybrid.json" in log_text


@pytest.mark.parametrize("script_path", SCRIPT_PATHS)
def test_update_dashboard_scripts_use_configured_deterministic_backend(
    tmp_path: Path, uv_stub: tuple[Path, Path], script_path: Path
) -> None:
    stub_dir, log_path = uv_stub
    pipeline_data_dir = tmp_path / "runs" / "repo" / "data"
    snapshot_dir = pipeline_data_dir / "snapshots" / "20260418T120000Z"
    snapshot_dir.mkdir(parents=True)
    latest_json = _write_latest_pointer(
        pipeline_data_dir / "snapshots" / "latest.json",
        str(snapshot_dir.resolve()),
    )
    config_path = tmp_path / "config.yaml"
    config_path.write_text("analysis:\n  ranking_backend: deterministic\n", encoding="utf-8")

    env = os.environ.copy()
    env["PATH"] = f"{stub_dir}:{env['PATH']}"
    env["UV_LOG_PATH"] = str(log_path)
    env["CONFIG_PATH"] = str(config_path)
    env["LATEST_JSON"] = str(latest_json)
    env["ANALYSIS_ID"] = "should-fail"

    result = subprocess.run(
        ["bash", str(script_path)],
        cwd=Path.cwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode != 0
    assert (
        "ANALYSIS_ID requires hybrid analysis publication; got ranking backend: deterministic"
        in (result.stderr)
    )


@pytest.mark.parametrize("script_path", SCRIPT_PATHS)
def test_update_dashboard_scripts_name_deterministic_analysis_outputs_correctly(
    tmp_path: Path, uv_stub: tuple[Path, Path], script_path: Path
) -> None:
    stub_dir, log_path = uv_stub
    pipeline_data_dir = tmp_path / "runs" / "repo" / "data"
    snapshot_dir = pipeline_data_dir / "snapshots" / "20260418T120000Z"
    snapshot_dir.mkdir(parents=True)
    latest_json = _write_latest_pointer(
        pipeline_data_dir / "snapshots" / "latest.json",
        str(snapshot_dir.resolve()),
    )
    config_path = tmp_path / "config.yaml"
    config_path.write_text("analysis:\n  ranking_backend: deterministic\n", encoding="utf-8")

    env = os.environ.copy()
    env["PATH"] = f"{stub_dir}:{env['PATH']}"
    env["UV_LOG_PATH"] = str(log_path)
    env["CONFIG_PATH"] = str(config_path)
    env["LATEST_JSON"] = str(latest_json)

    result = subprocess.run(
        ["bash", str(script_path)],
        cwd=Path.cwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    log_text = log_path.read_text(encoding="utf-8")
    expected_snapshot = str(snapshot_dir.resolve())
    assert f"--output {expected_snapshot}/analysis-report.json" in log_text
    assert "analysis-report-hybrid.json" not in log_text


@pytest.mark.parametrize("script_path", SCRIPT_PATHS)
def test_update_dashboard_scripts_honor_extra_args_backend_override_for_safety_check(
    tmp_path: Path, uv_stub: tuple[Path, Path], script_path: Path
) -> None:
    stub_dir, _ = uv_stub
    pipeline_data_dir = tmp_path / "runs" / "repo" / "data"
    snapshot_dir = pipeline_data_dir / "snapshots" / "20260418T120000Z"
    snapshot_dir.mkdir(parents=True)
    latest_json = _write_latest_pointer(
        pipeline_data_dir / "snapshots" / "latest.json",
        str(snapshot_dir.resolve()),
    )
    config_path = tmp_path / "config.yaml"
    config_path.write_text("analysis:\n  ranking_backend: hybrid\n", encoding="utf-8")

    env = os.environ.copy()
    env["PATH"] = f"{stub_dir}:{env['PATH']}"
    env["UV_LOG_PATH"] = str(tmp_path / "uv.log")
    env["CONFIG_PATH"] = str(config_path)
    env["LATEST_JSON"] = str(latest_json)
    env["ANALYZE_EXTRA_ARGS"] = "--ranking-backend deterministic"
    env["ANALYSIS_ID"] = "should-fail"

    result = subprocess.run(
        ["bash", str(script_path)],
        cwd=Path.cwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode != 0
    assert (
        "ANALYSIS_ID requires hybrid analysis publication; got ranking backend: deterministic"
        in result.stderr
    )


@pytest.mark.parametrize("script_path", SCRIPT_PATHS)
def test_update_dashboard_scripts_honor_extra_args_backend_override_for_output_name(
    tmp_path: Path, uv_stub: tuple[Path, Path], script_path: Path
) -> None:
    stub_dir, log_path = uv_stub
    pipeline_data_dir = tmp_path / "runs" / "repo" / "data"
    snapshot_dir = pipeline_data_dir / "snapshots" / "20260418T120000Z"
    snapshot_dir.mkdir(parents=True)
    latest_json = _write_latest_pointer(
        pipeline_data_dir / "snapshots" / "latest.json",
        str(snapshot_dir.resolve()),
    )
    config_path = tmp_path / "config.yaml"
    config_path.write_text("analysis:\n  ranking_backend: hybrid\n", encoding="utf-8")

    env = os.environ.copy()
    env["PATH"] = f"{stub_dir}:{env['PATH']}"
    env["UV_LOG_PATH"] = str(log_path)
    env["CONFIG_PATH"] = str(config_path)
    env["LATEST_JSON"] = str(latest_json)
    env["ANALYZE_EXTRA_ARGS"] = "--ranking-backend deterministic"

    result = subprocess.run(
        ["bash", str(script_path)],
        cwd=Path.cwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    log_text = log_path.read_text(encoding="utf-8")
    expected_snapshot = str(snapshot_dir.resolve())
    assert f"--output {expected_snapshot}/analysis-report.json" in log_text
    assert "--ranking-backend deterministic" in log_text
    assert "analysis-report-hybrid.json" not in log_text


@pytest.mark.parametrize("script_path", SCRIPT_PATHS)
def test_update_dashboard_scripts_pass_custom_analysis_output_to_publish_and_deploy(
    tmp_path: Path, uv_stub: tuple[Path, Path], script_path: Path
) -> None:
    stub_dir, log_path = uv_stub
    pipeline_data_dir = tmp_path / "runs" / "repo" / "data"
    snapshot_dir = pipeline_data_dir / "snapshots" / "20260418T120000Z"
    snapshot_dir.mkdir(parents=True)
    latest_json = _write_latest_pointer(
        pipeline_data_dir / "snapshots" / "latest.json",
        str(snapshot_dir.resolve()),
    )
    config_path = tmp_path / "config.yaml"
    config_path.write_text("analysis:\n  ranking_backend: hybrid\n", encoding="utf-8")
    analysis_output = tmp_path / "exports" / "custom-analysis-report.json"

    env = os.environ.copy()
    env["PATH"] = f"{stub_dir}:{env['PATH']}"
    env["UV_LOG_PATH"] = str(log_path)
    env["CONFIG_PATH"] = str(config_path)
    env["LATEST_JSON"] = str(latest_json)
    env["ANALYSIS_ID"] = "hybrid-gpt54mini-v3"
    env["ANALYSIS_OUTPUT"] = str(analysis_output)

    result = subprocess.run(
        ["bash", str(script_path)],
        cwd=Path.cwd(),
        env=env,
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0, result.stderr
    log_text = log_path.read_text(encoding="utf-8")
    assert f"--output {analysis_output}" in log_text
    assert (
        f"publish-analysis-artifacts --snapshot-dir {snapshot_dir.resolve()} "
        f"--analysis-input {analysis_output} --analysis-id hybrid-gpt54mini-v3 --canonical --save-cache"
    ) in log_text
    assert (
        f"deploy-dashboard --snapshot-dir {snapshot_dir.resolve()} --analysis-input {analysis_output}"
        in log_text
    )
