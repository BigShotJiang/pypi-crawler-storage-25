from __future__ import annotations

import subprocess
import sys
from contextlib import suppress

from slop_farmer.app.cli import build_parser


def test_module_cli_help_smoke() -> None:
    result = subprocess.run(
        [sys.executable, "-m", "slop_farmer.app.cli", "--help"],
        capture_output=True,
        text=True,
        check=False,
    )

    assert result.returncode == 0
    assert "usage: slop-farmer" in result.stdout
    assert "duplicate-prs" in result.stdout
    assert "pr-search" in result.stdout
    assert "refresh-dataset" in result.stdout
    assert "publish-analysis-artifacts" in result.stdout
    assert "save-cache" in result.stdout
    assert "dataset-status" in result.stdout
    assert "full-pipeline" not in result.stdout


def test_dashboard_help_strings_are_architecture_aligned(capsys) -> None:
    parser = build_parser()
    with suppress(SystemExit):
        parser.parse_args(["dashboard-data", "--help"])
    dashboard_help = capsys.readouterr().out
    assert "canonical published current analysis" in dashboard_help
    assert "analysis-report.json in the snapshot" not in dashboard_help

    with suppress(SystemExit):
        parser.parse_args(["deploy-dashboard", "--help"])
    deploy_help = capsys.readouterr().out
    assert "canonical published current analysis" in deploy_help

    with suppress(SystemExit):
        parser.parse_args(["scrape", "--help"])
    scrape_help = capsys.readouterr().out
    assert "--publish" not in scrape_help
