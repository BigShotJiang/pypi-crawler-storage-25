from __future__ import annotations

from slop_farmer.data.snapshot_paths import (
    ANALYSIS_MANIFEST_SCHEMA_VERSION,
    ANALYSIS_REPORT_FILENAME_BY_VARIANT,
    CURRENT_ANALYSIS_MANIFEST_PATH,
    HYBRID_ANALYSIS_REVIEWS_FILENAME,
    NEW_CONTRIBUTORS_PARQUET_FILENAME,
    NEW_CONTRIBUTORS_REPORT_JSON_FILENAME,
    NEW_CONTRIBUTORS_REPORT_MARKDOWN_FILENAME,
    PR_SCOPE_CLUSTERS_FILENAME,
    SNAPSHOTS_LATEST_PATH,
    analysis_run_artifact_path,
    build_archived_analysis_run_manifest,
    build_current_analysis_manifest,
    current_analysis_artifact_path,
    model_key,
    repo_key,
    snapshot_artifact_path,
)


def test_published_layout_uses_expected_canonical_filenames() -> None:
    assert SNAPSHOTS_LATEST_PATH == "snapshots/latest.json"
    assert CURRENT_ANALYSIS_MANIFEST_PATH == "analysis/current/manifest.json"
    assert ANALYSIS_REPORT_FILENAME_BY_VARIANT == {
        "deterministic": "analysis-report.json",
        "hybrid": "analysis-report-hybrid.json",
    }
    assert HYBRID_ANALYSIS_REVIEWS_FILENAME == "analysis-report-hybrid.llm-reviews.json"
    assert PR_SCOPE_CLUSTERS_FILENAME == "pr-scope-clusters.json"
    assert NEW_CONTRIBUTORS_PARQUET_FILENAME == "new_contributors.parquet"
    assert NEW_CONTRIBUTORS_REPORT_JSON_FILENAME == "new-contributors-report.json"
    assert NEW_CONTRIBUTORS_REPORT_MARKDOWN_FILENAME == "new-contributors-report.md"


def test_published_layout_builds_snapshot_and_analysis_paths() -> None:
    assert snapshot_artifact_path("20260418T120000Z", "manifest.json") == (
        "snapshots/20260418T120000Z/manifest.json"
    )
    assert current_analysis_artifact_path("analysis-report-hybrid.json") == (
        "analysis/current/analysis-report-hybrid.json"
    )
    assert analysis_run_artifact_path(
        "20260418T120000Z",
        "hybrid-gpt54mini-v3",
        "analysis-report-hybrid.json",
    ) == (
        "snapshots/20260418T120000Z/analysis-runs/hybrid-gpt54mini-v3/analysis-report-hybrid.json"
    )


def test_published_layout_builds_valid_current_manifest_payload() -> None:
    payload = build_current_analysis_manifest(
        repo="openclaw/openclaw",
        snapshot_id="20260418T120000Z",
        analysis_id="hybrid-gpt54mini-v3",
        variant="hybrid",
        channel="canonical",
        model="gpt-5.4-mini",
        published_at="2026-04-18T12:34:56Z",
        include_hybrid_reviews=True,
    )

    assert payload["schema_version"] == ANALYSIS_MANIFEST_SCHEMA_VERSION
    assert payload["artifacts"] == {
        "hybrid": "analysis/current/analysis-report-hybrid.json",
        "hybrid_reviews": "analysis/current/analysis-report-hybrid.llm-reviews.json",
    }
    assert payload["archived_artifacts"] == {
        "hybrid": (
            "snapshots/20260418T120000Z/analysis-runs/hybrid-gpt54mini-v3/analysis-report-hybrid.json"
        ),
        "hybrid_reviews": (
            "snapshots/20260418T120000Z/analysis-runs/hybrid-gpt54mini-v3/analysis-report-hybrid.llm-reviews.json"
        ),
    }


def test_published_layout_builds_valid_archived_manifest_payload() -> None:
    payload = build_archived_analysis_run_manifest(
        repo="openclaw/openclaw",
        snapshot_id="20260418T120000Z",
        analysis_id="hybrid-gpt54mini-v3",
        variant="hybrid",
        channel="comparison",
        model=None,
        published_at="2026-04-18T12:34:56Z",
        include_hybrid_reviews=False,
    )

    assert payload["schema_version"] == ANALYSIS_MANIFEST_SCHEMA_VERSION
    assert payload["artifacts"] == {
        "hybrid": (
            "snapshots/20260418T120000Z/analysis-runs/hybrid-gpt54mini-v3/analysis-report-hybrid.json"
        )
    }
    assert "archived_artifacts" not in payload


def test_repo_and_model_keys_are_stable_and_path_safe() -> None:
    assert repo_key("OpenClaw/OpenClaw") == "openclaw-openclaw"
    assert model_key("gpt-5.4-mini?reasoning=low") == "gpt-5-4-mini-reasoning-low"
    assert model_key("gpt-5.4-mini?reasoning=low") == model_key("gpt-5.4-mini?reasoning=low")
