from __future__ import annotations

from pathlib import Path

from slop_farmer.app.dataset_status import format_dataset_status, get_dataset_status
from slop_farmer.config import DatasetStatusOptions
from slop_farmer.data.parquet_io import write_json


def test_dataset_status_reports_remote_and_local_state(monkeypatch, tmp_path: Path) -> None:
    output_dir = tmp_path / "data"
    snapshot_dir = output_dir / "snapshots" / "20260324T000000Z"
    snapshot_dir.mkdir(parents=True)
    write_json(
        {"repo": "huggingface/transformers", "snapshot_id": "20260324T000000Z"},
        snapshot_dir / "manifest.json",
    )
    write_json(
        {
            "repo": "huggingface/transformers",
            "latest_snapshot_id": "20260324T000000Z",
            "snapshot_dir": str(snapshot_dir),
        },
        output_dir / "snapshots" / "latest.json",
    )

    monkeypatch.setattr(
        "slop_farmer.app.dataset_status._remote_status",
        lambda repo_id, revision: {
            "dataset_id": repo_id,
            "revision": revision,
            "latest_pointer": {
                "latest_snapshot_id": "20260324T000000Z",
                "next_since": "2026-03-24T00:00:00Z",
            },
            "watermark": {"next_since": "2026-03-24T00:00:00Z"},
            "manifest": {
                "repo": "huggingface/transformers",
                "snapshot_id": "20260324T000000Z",
                "extracted_at": "2026-03-24T00:00:00Z",
            },
            "contributors_present": True,
            "remote_path_count": 12,
            "age": {"seconds": 3600, "summary": "1h", "staleness": "fresh"},
        },
    )

    status = get_dataset_status(
        DatasetStatusOptions(
            repo=None,
            output_dir=output_dir,
            hf_repo_id="evalstate/transformers-pr",
            hf_revision="main",
        )
    )

    text = format_dataset_status(status)
    assert status["repo"] == "huggingface/transformers"
    assert status["local"]["snapshot_id"] == "20260324T000000Z"
    assert "Dataset: evalstate/transformers-pr" in text
    assert "Remote latest snapshot: 20260324T000000Z" in text
    assert "Local latest pointer:" in text


def test_remote_status_handles_missing_latest_pointer(monkeypatch) -> None:
    monkeypatch.setattr("slop_farmer.app.dataset_status.HfApi", lambda: object())
    monkeypatch.setattr(
        "slop_farmer.app.dataset_status.list_remote_paths",
        lambda api, repo_id, revision=None: {"state/watermark.json"},
    )

    def stub_load_remote_json_file(api, repo_id, path_in_repo, root, revision=None):
        del api, repo_id, root, revision
        if path_in_repo == "state/watermark.json":
            return {"next_since": "2026-03-24T00:00:00Z"}
        return None

    monkeypatch.setattr(
        "slop_farmer.app.dataset_status.load_remote_json_file",
        stub_load_remote_json_file,
    )

    status = get_dataset_status(
        DatasetStatusOptions(
            repo=None,
            output_dir=Path("/tmp/nonexistent"),
            hf_repo_id="evalstate/transformers-pr",
            hf_revision="main",
        )
    )

    assert status["remote"]["latest_pointer"] is None
    assert status["remote"]["cheap_artifacts"]["contributors"] is False
