from pathlib import Path

from slop_farmer.app.snapshot_state import adopt_snapshot_for_pipeline
from slop_farmer.config import SnapshotAdoptOptions
from slop_farmer.data.parquet_io import read_json, write_json, write_parquet


def test_adopt_snapshot_for_pipeline_writes_latest_and_watermark(tmp_path: Path) -> None:
    snapshot_dir = (
        tmp_path
        / "imported"
        / "snapshots"
        / "hf-burtenshaw--transformers-pr-slop-dataset-20260325T020023Z"
    )
    snapshot_dir.mkdir(parents=True)
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260325T020023Z",
            "extracted_at": "2026-03-25T02:00:23Z",
            "imported_at": "2026-03-25T12:00:00Z",
        },
        snapshot_dir / "manifest.json",
    )

    latest_path = adopt_snapshot_for_pipeline(
        SnapshotAdoptOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path / "runs" / "transformers" / "data",
            next_since=None,
        )
    )

    latest = read_json(latest_path)
    watermark = read_json(tmp_path / "runs" / "transformers" / "data" / "state" / "watermark.json")
    assert latest["repo"] == "huggingface/transformers"
    assert latest["latest_snapshot_id"] == "20260325T020023Z"
    assert latest["snapshot_dir"] == str(snapshot_dir.resolve())
    assert latest["next_since"] == "2026-03-25T02:00:23Z"
    assert watermark["last_successful_snapshot_id"] == "20260325T020023Z"
    assert watermark["snapshot_dir"] == str(snapshot_dir.resolve())
    assert watermark["next_since"] == "2026-03-25T02:00:23Z"


def test_adopt_snapshot_for_pipeline_uses_max_content_timestamp_for_imports(tmp_path: Path) -> None:
    snapshot_dir = (
        tmp_path
        / "imported"
        / "snapshots"
        / "hf-burtenshaw--transformers-pr-slop-dataset-20260325T020023Z"
    )
    snapshot_dir.mkdir(parents=True)
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260325T020023Z",
            "extracted_at": "2026-03-25T02:00:23Z",
            "imported_at": "2026-03-25T12:00:00Z",
            "source_type": "hf_checkpoint_import",
        },
        snapshot_dir / "manifest.json",
    )
    write_parquet(
        [
            {
                "repo": "huggingface/transformers",
                "number": 39390,
                "updated_at": "2025-07-14T06:32:53Z",
                "created_at": "2025-07-14T02:43:59Z",
            }
        ],
        snapshot_dir / "pull_requests.parquet",
        "pull_requests",
    )
    write_parquet([], snapshot_dir / "issues.parquet", "issues")
    write_parquet([], snapshot_dir / "comments.parquet", "comments")
    write_parquet([], snapshot_dir / "reviews.parquet", "reviews")
    write_parquet([], snapshot_dir / "review_comments.parquet", "review_comments")
    write_parquet([], snapshot_dir / "events.parquet", "events")

    latest_path = adopt_snapshot_for_pipeline(
        SnapshotAdoptOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path / "runs" / "transformers" / "data",
            next_since=None,
        )
    )

    latest = read_json(latest_path)
    watermark = read_json(tmp_path / "runs" / "transformers" / "data" / "state" / "watermark.json")
    assert latest["next_since"] == "2025-07-14T06:32:53Z"
    assert watermark["next_since"] == "2025-07-14T06:32:53Z"


def test_adopt_snapshot_for_pipeline_prefers_pull_request_watermark_for_imports(
    tmp_path: Path,
) -> None:
    snapshot_dir = (
        tmp_path
        / "imported"
        / "snapshots"
        / "hf-burtenshaw--transformers-pr-slop-dataset-20260325T020023Z"
    )
    snapshot_dir.mkdir(parents=True)
    write_json(
        {
            "repo": "huggingface/transformers",
            "snapshot_id": "20260325T020023Z",
            "extracted_at": "2026-03-25T02:00:23Z",
            "imported_at": "2026-03-25T12:00:00Z",
            "source_type": "hf_checkpoint_import",
        },
        snapshot_dir / "manifest.json",
    )
    write_parquet(
        [
            {
                "repo": "huggingface/transformers",
                "number": 39390,
                "updated_at": "2025-07-14T07:47:40Z",
                "created_at": "2025-07-14T02:43:59Z",
            }
        ],
        snapshot_dir / "pull_requests.parquet",
        "pull_requests",
    )
    write_parquet(
        [
            {
                "repo": "huggingface/transformers",
                "number": 44910,
                "updated_at": "2026-03-25T02:03:24Z",
                "created_at": "2026-03-25T01:40:00Z",
            }
        ],
        snapshot_dir / "issues.parquet",
        "issues",
    )
    write_parquet(
        [
            {
                "repo": "huggingface/transformers",
                "github_id": 44957,
                "updated_at": "2026-03-25T09:11:28Z",
                "created_at": "2026-03-25T09:11:28Z",
            }
        ],
        snapshot_dir / "comments.parquet",
        "comments",
    )
    write_parquet([], snapshot_dir / "reviews.parquet", "reviews")
    write_parquet([], snapshot_dir / "review_comments.parquet", "review_comments")
    write_parquet([], snapshot_dir / "events.parquet", "events")

    latest_path = adopt_snapshot_for_pipeline(
        SnapshotAdoptOptions(
            snapshot_dir=snapshot_dir,
            output_dir=tmp_path / "runs" / "transformers" / "data",
            next_since=None,
        )
    )

    latest = read_json(latest_path)
    assert latest["next_since"] == "2025-07-14T07:47:40Z"
